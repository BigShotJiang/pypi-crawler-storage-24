"""Tests for AuditLogger ZKAT + Examiner Export methods."""

import json

import httpx
import pytest

from conftest import make_client, ok_response


# ── Sample data factories ────────────────────────────────────────────────


def sample_chain_verify(valid: bool = True) -> dict:
    return {
        "valid": valid,
        "total_records": 128,
        "first_hash": "a1b2c3d4",
        "last_hash": "e5f6a7b8",
        "broken_at": None,
        "verified_at": "2026-03-01T12:00:00Z",
    }


def sample_epoch(epoch_id: int = 1) -> dict:
    return {
        "epoch_id": epoch_id,
        "tenant_id": "tenant-1",
        "record_count": 1024,
        "merkle_root": "deadbeef01234567",
        "prev_epoch_hash": "0000000000000000",
        "sealed_at": "2026-03-01T12:00:00Z",
    }


def sample_epoch_verify(valid: bool = True) -> dict:
    return {
        "valid": valid,
        "total_epochs": 5,
        "verified_epochs": 5,
        "first_broken_epoch": None,
        "verified_at": "2026-03-01T12:00:00Z",
    }


# ── Tests ────────────────────────────────────────────────────────────────


class TestAuditZkat:
    def test_verify_chain(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert "/tenants/tenant-1/audit/chain-verify" in str(request.url)
            return ok_response(sample_chain_verify())

        client = make_client(handler)
        result = client.audit.verify_chain("tenant-1")
        assert result.valid is True
        assert result.total_records == 128
        assert result.first_hash == "a1b2c3d4"
        assert result.last_hash == "e5f6a7b8"
        assert result.broken_at is None

    def test_verify_chain_broken(self):
        data = sample_chain_verify(valid=False)
        data["broken_at"] = 42

        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(data)

        client = make_client(handler)
        result = client.audit.verify_chain("tenant-1")
        assert result.valid is False
        assert result.broken_at == 42

    def test_list_epochs(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert "/tenants/tenant-1/audit/zkat/epochs" in str(request.url)
            return ok_response([sample_epoch(1), sample_epoch(2)])

        client = make_client(handler)
        epochs = client.audit.list_epochs("tenant-1")
        assert len(epochs) == 2
        assert epochs[0].epoch_id == 1
        assert epochs[0].record_count == 1024
        assert epochs[0].merkle_root == "deadbeef01234567"
        assert epochs[1].epoch_id == 2

    def test_list_epochs_empty(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([])

        client = make_client(handler)
        epochs = client.audit.list_epochs("tenant-1")
        assert epochs == []

    def test_verify_epochs(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert "/tenants/tenant-1/audit/zkat/verify" in str(request.url)
            return ok_response(sample_epoch_verify())

        client = make_client(handler)
        result = client.audit.verify_epochs("tenant-1")
        assert result.valid is True
        assert result.total_epochs == 5
        assert result.verified_epochs == 5
        assert result.first_broken_epoch is None

    def test_verify_epochs_broken(self):
        data = sample_epoch_verify(valid=False)
        data["verified_epochs"] = 3
        data["first_broken_epoch"] = 4

        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(data)

        client = make_client(handler)
        result = client.audit.verify_epochs("tenant-1")
        assert result.valid is False
        assert result.verified_epochs == 3
        assert result.first_broken_epoch == 4


class TestExaminerExport:
    def test_export_examiner_returns_bytes(self):
        zip_content = b"PK\x03\x04fake-zip-data"

        def handler(request: httpx.Request) -> httpx.Response:
            assert "/tenants/tenant-1/compliance/examiner-export" in str(request.url)
            body = json.loads(request.content)
            assert body["start_date"] == "2026-01-01"
            assert body["end_date"] == "2026-03-01"
            assert body["include_zkat"] is False
            return httpx.Response(200, content=zip_content)

        client = make_client(handler)
        result = client.audit.export_examiner("tenant-1", "2026-01-01", "2026-03-01")
        assert result == zip_content

    def test_export_examiner_with_zkat(self):
        zip_content = b"PK\x03\x04fake-zip-with-zkat"

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["include_zkat"] is True
            return httpx.Response(200, content=zip_content)

        client = make_client(handler)
        result = client.audit.export_examiner(
            "tenant-1", "2026-01-01", "2026-03-01", include_zkat=True
        )
        assert result == zip_content
        assert len(result) > 0
