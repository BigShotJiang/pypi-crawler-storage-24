"""Tests for AdminClient."""

import httpx
import pytest

from conftest import make_client, ok_response, sample_agent
from forgememory_enterprise import AuthenticationError
from conftest import error_response


class TestAdminClient:
    def test_health(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response({"status": "ok", "version": "0.1.0", "uptime_secs": 3600})

        client = make_client(handler)
        health = client.admin.health()
        assert health.status == "ok"
        assert health.version == "0.1.0"

    def test_agent_dashboard(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_agent(), sample_agent(id="agent-2", name="other")])

        client = make_client(handler)
        agents = client.admin.agent_dashboard()
        assert len(agents) == 2

    def test_audit_stats(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response({
                "total_actions": 50, "total_memory_accesses": 25,
                "total_delegations": 5, "total_cost_usd": 0.5,
            })

        client = make_client(handler)
        stats = client.admin.audit_stats()
        assert stats.total_actions == 50

    def test_pool_stats(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response({
                "active_connections": 5, "total_hits": 100,
                "total_misses": 10, "evictions": 2,
            })

        client = make_client(handler)
        stats = client.admin.pool_stats()
        assert stats.active_connections == 5
        assert stats.total_hits == 100

    def test_pool_close_all(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            return ok_response("All connections closed")

        client = make_client(handler)
        result = client.admin.pool_close_all()
        assert result == "All connections closed"

    def test_health_unauthenticated(self):
        """Health endpoint should work even without auth — but if server rejects, we handle it."""
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("Unauthorized", 401)

        client = make_client(handler)
        with pytest.raises(AuthenticationError):
            client.admin.health()

    # ── Vector admin tests ────────────────────────────────────────────────

    def test_vector_stats(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/api/v1/admin/vector/stats"
            return ok_response({
                "vector_enabled": True,
                "backend_type": "brute_force",
                "tenants": [
                    {
                        "tenant_id": "t1",
                        "total_memories": 100,
                        "embedded_memories": 80,
                        "failed_embeddings": 2,
                        "pending_embeddings": 18,
                        "index_type": "brute_force",
                    },
                ],
            })

        client = make_client(handler)
        resp = client.admin.vector_stats()
        assert resp.vector_enabled is True
        assert resp.backend_type == "brute_force"
        assert len(resp.tenants) == 1
        assert resp.tenants[0].tenant_id == "t1"
        assert resp.tenants[0].total_memories == 100
        assert resp.tenants[0].embedded_memories == 80
        assert resp.tenants[0].pending_embeddings == 18

    def test_vector_backfill(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert request.url.path == "/api/v1/admin/vector/backfill"
            return ok_response("Backfill started")

        client = make_client(handler)
        result = client.admin.vector_backfill()
        assert result == "Backfill started"

    def test_vector_rebuild(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/api/v1/admin/vector/rebuild/" in str(request.url)
            return ok_response("Index rebuilt")

        client = make_client(handler)
        result = client.admin.vector_rebuild("tenant-1")
        assert result == "Index rebuilt"

    # ── Distillation admin tests ───────────────────────────────────────

    def test_distillation_stats(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/api/v1/admin/distillation/stats"
            return ok_response({
                "pending": 5,
                "completed": 20,
                "skipped": 3,
                "failed": 1,
                "total": 29,
            })

        client = make_client(handler)
        stats = client.admin.distillation_stats()
        assert stats.pending == 5
        assert stats.completed == 20
        assert stats.skipped == 3
        assert stats.failed == 1
        assert stats.total == 29

    def test_trigger_distillation(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert request.url.path == "/api/v1/admin/distillation/trigger"
            return ok_response({"message": "Distillation sweep triggered"})

        client = make_client(handler)
        result = client.admin.trigger_distillation()
        assert result == "Distillation sweep triggered"
