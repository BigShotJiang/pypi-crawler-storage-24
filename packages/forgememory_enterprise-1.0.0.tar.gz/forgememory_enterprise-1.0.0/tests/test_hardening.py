"""Tests for SDK hardening: input validation, 5xx retry, new endpoints.

Covers:
- Input validation (tenant_id, query, limit, memory_id)
- 5xx retry with exponential backoff
- Memory compression and history endpoints
- Entity extract-all
- Legal holds CRUD (low-level and matters)
- Gateway conversation and analytics endpoints
- Agent log_cost, get_session, list_active_sessions
- Audit delegation chain
- Admin daily_costs, tenant_costs, tiered_index_seed, global_stats
- Tenant archive_tenant, get_usage
"""

from __future__ import annotations

import json

import httpx
import pytest

from conftest import (
    error_response,
    make_client,
    ok_response,
    sample_memory,
)
from forgememory_enterprise import (
    AuthenticationError,
    EnterpriseError,
    NotFoundError,
    RateLimitedError,
)
from forgememory_enterprise._http import request_with_retry
from forgememory_enterprise.types import CreateMemoryRequest


# ── Input Validation Tests ─────────────────────────────────────────────────


class TestMemoryValidation:
    """Ensure MemoryClient rejects bad inputs before hitting the server."""

    def _never_call(self, request: httpx.Request) -> httpx.Response:
        raise AssertionError("HTTP call should not have been made")

    def test_create_empty_tenant_id(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="tenant_id"):
            client.memory.create("", CreateMemoryRequest(content="test"))

    def test_create_whitespace_tenant_id(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="tenant_id"):
            client.memory.create("   ", CreateMemoryRequest(content="test"))

    def test_get_empty_tenant_id(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="tenant_id"):
            client.memory.get("", "mem-1")

    def test_get_empty_memory_id(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="memory_id"):
            client.memory.get("tenant-1", "")

    def test_delete_empty_memory_id(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="memory_id"):
            client.memory.delete("tenant-1", "")

    def test_search_empty_tenant_id(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="tenant_id"):
            client.memory.search("", "query")

    def test_search_empty_query(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="query"):
            client.memory.search("tenant-1", "")

    def test_search_zero_limit(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="limit"):
            client.memory.search("tenant-1", "test", limit=0)

    def test_search_negative_limit(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="limit"):
            client.memory.search("tenant-1", "test", limit=-5)

    def test_context_empty_tenant_id(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="tenant_id"):
            client.memory.context("", "query")

    def test_context_empty_query(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="query"):
            client.memory.context("tenant-1", "")

    def test_context_zero_max_tokens(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="max_tokens"):
            client.memory.context("tenant-1", "query", max_tokens=0)

    def test_facts_empty_tenant_id(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="tenant_id"):
            client.memory.facts("", limit=10)

    def test_facts_negative_limit(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="limit"):
            client.memory.facts("tenant-1", limit=-1)

    def test_get_history_empty_tenant_id(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="tenant_id"):
            client.memory.get_history("", "mem-1")

    def test_get_history_empty_memory_id(self):
        client = make_client(self._never_call)
        with pytest.raises(ValueError, match="memory_id"):
            client.memory.get_history("tenant-1", "")


# ── 5xx Retry Tests ────────────────────────────────────────────────────────


class TestFiveHundredRetry:
    """Verify that 5xx errors trigger exponential backoff retry."""

    def test_500_retries_and_eventually_succeeds(self):
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            if call_count["n"] < 3:
                # First two calls: 500
                return httpx.Response(
                    500,
                    text=json.dumps({"error": "internal server error"}),
                    headers={"content-type": "application/json"},
                )
            # Third call succeeds
            return ok_response({"id": "mem-1", "content": "ok"})

        client = make_client(handler)
        # Use request_with_retry directly (memory.search is fine too, but
        # we call it indirectly to test the transport)
        from forgememory_enterprise._http import request_with_retry as rwr

        resp = rwr(client._client, "GET", "/health")
        # Either the 500 was retried and we got the 200, or we got a 500 on max retries
        # The key assertion: it was called multiple times
        assert call_count["n"] >= 2

    def test_503_retries_up_to_max(self):
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            return httpx.Response(
                503,
                text=json.dumps({"error": "service unavailable"}),
                headers={"content-type": "application/json"},
            )

        from forgememory_enterprise._http import MAX_RETRIES, request_with_retry as rwr, make_client as mc_http
        # Use the transport via httpx.Client directly
        transport = httpx.MockTransport(handler)
        http_client = httpx.Client(
            base_url="http://fme-test:8201",
            headers={"X-API-Key": "fme_test"},
            transport=transport,
        )
        resp = rwr(http_client, "GET", "/health")
        # Should have been called MAX_RETRIES + 1 times total
        assert call_count["n"] == MAX_RETRIES + 1
        assert resp.status_code == 503

    def test_502_is_retried(self):
        """502 Bad Gateway should be retried."""
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            if call_count["n"] == 1:
                return httpx.Response(
                    502,
                    text=json.dumps({"error": "bad gateway"}),
                    headers={"content-type": "application/json"},
                )
            return ok_response({"status": "ok"})

        from forgememory_enterprise._http import request_with_retry as rwr
        transport = httpx.MockTransport(handler)
        http_client = httpx.Client(
            base_url="http://fme-test:8201",
            headers={"X-API-Key": "fme_test"},
            transport=transport,
        )
        resp = rwr(http_client, "GET", "/health")
        assert call_count["n"] == 2
        assert resp.status_code == 200

    def test_400_is_not_retried(self):
        """Client errors (4xx except 429) should NOT be retried."""
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            return httpx.Response(
                400,
                text=json.dumps({"error": "bad request"}),
                headers={"content-type": "application/json"},
            )

        from forgememory_enterprise._http import request_with_retry as rwr
        transport = httpx.MockTransport(handler)
        http_client = httpx.Client(
            base_url="http://fme-test:8201",
            headers={"X-API-Key": "fme_test"},
            transport=transport,
        )
        resp = rwr(http_client, "GET", "/health")
        assert call_count["n"] == 1  # No retry for 400
        assert resp.status_code == 400

    def test_404_is_not_retried(self):
        """Not found errors should NOT be retried."""
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            return httpx.Response(
                404,
                text=json.dumps({"error": "not found"}),
                headers={"content-type": "application/json"},
            )

        from forgememory_enterprise._http import request_with_retry as rwr
        transport = httpx.MockTransport(handler)
        http_client = httpx.Client(
            base_url="http://fme-test:8201",
            headers={"X-API-Key": "fme_test"},
            transport=transport,
        )
        resp = rwr(http_client, "GET", "/health")
        assert call_count["n"] == 1
        assert resp.status_code == 404


# ── Memory Compression Tests ───────────────────────────────────────────────


class TestMemoryCompression:
    def test_compress_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/tenants/t1/memories/compress" in str(request.url)
            return ok_response({"merged_count": 5, "retained_count": 20})

        client = make_client(handler)
        result = client.memory.compress("t1")
        assert result["merged_count"] == 5
        assert result["retained_count"] == 20

    def test_compress_with_client_id(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_body.update(json.loads(request.content))
            return ok_response({"merged_count": 2, "retained_count": 8})

        client = make_client(handler)
        client.memory.compress("t1", client_id="c-1")
        assert received_body.get("client_id") == "c-1"

    def test_compress_empty_tenant_id(self):
        def never_call(req): raise AssertionError()
        client = make_client(never_call)
        with pytest.raises(ValueError, match="tenant_id"):
            client.memory.compress("")

    def test_compression_stats_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/t1/memories/compression-stats" in str(request.url)
            return ok_response({"total_compressed": 10, "average_ratio": 0.75})

        client = make_client(handler)
        result = client.memory.compression_stats("t1")
        assert result["total_compressed"] == 10

    def test_compression_stats_empty_tenant_id(self):
        def never_call(req): raise AssertionError()
        client = make_client(never_call)
        with pytest.raises(ValueError, match="tenant_id"):
            client.memory.compression_stats("")


# ── Memory History Tests ───────────────────────────────────────────────────


class TestMemoryHistory:
    def test_get_history_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/t1/memories/m-1/history" in str(request.url)
            return ok_response([
                {"version": 1, "content": "original", "actor": "user", "created_at": "2026-01-01T00:00:00Z"},
                {"version": 2, "content": "updated", "actor": "user", "created_at": "2026-02-01T00:00:00Z"},
            ])

        client = make_client(handler)
        result = client.memory.get_history("t1", "m-1")
        assert len(result) == 2
        assert result[0]["version"] == 1
        assert result[1]["content"] == "updated"

    def test_get_history_not_found(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("Memory not found", 404)

        client = make_client(handler)
        with pytest.raises(NotFoundError):
            client.memory.get_history("t1", "nonexistent")


# ── Entity Extract All Tests ───────────────────────────────────────────────


class TestEntityExtractAll:
    def test_extract_all_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/tenants/t1/entities/extract-all" in str(request.url)
            return ok_response({"extracted_count": 15, "skipped_count": 2})

        client = make_client(handler)
        result = client.entities.extract_all("t1")
        assert result["extracted_count"] == 15
        assert result["skipped_count"] == 2


# ── Legal Hold Tests ───────────────────────────────────────────────────────


class TestLegalHolds:
    def test_create_hold_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/tenants/t1/legal-holds" in str(request.url)
            body = json.loads(request.content)
            assert body["scope"] == "client_id:c-123"
            assert body["reason"] == "SEC investigation"
            return ok_response({"id": "hold-1", "scope": "client_id:c-123", "created_at": "2026-01-01"})

        client = make_client(handler)
        result = client.legal_holds.create_hold("t1", "client_id:c-123", "SEC investigation", "admin")
        assert result["id"] == "hold-1"

    def test_create_hold_empty_tenant_raises(self):
        def never_call(req): raise AssertionError()
        client = make_client(never_call)
        with pytest.raises(ValueError, match="tenant_id"):
            client.legal_holds.create_hold("", "scope", "reason", "admin")

    def test_create_hold_empty_scope_raises(self):
        def never_call(req): raise AssertionError()
        client = make_client(never_call)
        with pytest.raises(ValueError, match="scope"):
            client.legal_holds.create_hold("t1", "", "reason", "admin")

    def test_list_holds_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/t1/legal-holds" in str(request.url)
            return ok_response([{"id": "hold-1"}, {"id": "hold-2"}])

        client = make_client(handler)
        result = client.legal_holds.list_holds("t1")
        assert len(result) == 2
        assert result[0]["id"] == "hold-1"

    def test_release_hold_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "DELETE"
            assert "/tenants/t1/legal-holds/hold-1" in str(request.url)
            return ok_response("Hold released")

        client = make_client(handler)
        result = client.legal_holds.release_hold("t1", "hold-1")
        assert result == "Hold released"

    def test_release_hold_empty_hold_id_raises(self):
        def never_call(req): raise AssertionError()
        client = make_client(never_call)
        with pytest.raises(ValueError, match="hold_id"):
            client.legal_holds.release_hold("t1", "")

    def test_create_matter_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/tenants/t1/legal-holds/matters" in str(request.url)
            body = json.loads(request.content)
            assert body["name"] == "SEC 2026-001"
            return ok_response({"id": "matter-1", "name": "SEC 2026-001", "status": "open"})

        client = make_client(handler)
        result = client.legal_holds.create_matter("t1", "SEC 2026-001", "SEC investigation")
        assert result["id"] == "matter-1"
        assert result["status"] == "open"

    def test_list_matters_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            return ok_response([{"id": "matter-1"}, {"id": "matter-2"}])

        client = make_client(handler)
        result = client.legal_holds.list_matters("t1")
        assert len(result) == 2

    def test_get_matter_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/t1/legal-holds/matters/matter-1" in str(request.url)
            return ok_response({"id": "matter-1", "name": "SEC 2026-001"})

        client = make_client(handler)
        result = client.legal_holds.get_matter("t1", "matter-1")
        assert result["name"] == "SEC 2026-001"

    def test_release_matter_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/matters/matter-1/release" in str(request.url)
            return ok_response("Matter released")

        client = make_client(handler)
        result = client.legal_holds.release_matter("t1", "matter-1")
        assert result == "Matter released"

    def test_assign_memories_path(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/matters/matter-1/assign" in str(request.url)
            received_body.update(json.loads(request.content))
            return ok_response({"assigned_count": 3})

        client = make_client(handler)
        result = client.legal_holds.assign_memories("t1", "matter-1", ["m-1", "m-2", "m-3"])
        assert result["assigned_count"] == 3
        assert received_body["memory_ids"] == ["m-1", "m-2", "m-3"]

    def test_search_assign_path(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/matters/matter-1/search-assign" in str(request.url)
            received_body.update(json.loads(request.content))
            return ok_response({"assigned_count": 7})

        client = make_client(handler)
        result = client.legal_holds.search_assign_memories("t1", "matter-1", "quarterly report")
        assert result["assigned_count"] == 7
        assert received_body["query"] == "quarterly report"

    def test_search_assign_empty_query_raises(self):
        def never_call(req): raise AssertionError()
        client = make_client(never_call)
        with pytest.raises(ValueError, match="query"):
            client.legal_holds.search_assign_memories("t1", "matter-1", "")


# ── Gateway Tests ──────────────────────────────────────────────────────────


class TestGatewayClient:
    def test_ingest_conversation_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/tenants/t1/gateway/conversations" in str(request.url)
            return ok_response({"id": "conv-1", "memories_created": 2})

        client = make_client(handler)
        result = client.gateway.ingest_conversation("t1", {
            "messages": [{"role": "user", "content": "hello"}],
            "model": "qwen",
        })
        assert result["id"] == "conv-1"
        assert result["memories_created"] == 2

    def test_ingest_conversation_empty_tenant_raises(self):
        def never_call(req): raise AssertionError()
        client = make_client(never_call)
        with pytest.raises(ValueError, match="tenant_id"):
            client.gateway.ingest_conversation("", {"messages": []})

    def test_list_conversations_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/t1/gateway/conversations" in str(request.url)
            return ok_response([{"id": "conv-1"}, {"id": "conv-2"}])

        client = make_client(handler)
        result = client.gateway.list_conversations("t1")
        assert len(result) == 2

    def test_list_conversations_pagination_params(self):
        received_url = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_url["url"] = str(request.url)
            return ok_response([])

        client = make_client(handler)
        client.gateway.list_conversations("t1", limit=5, offset=10)
        assert "limit=5" in received_url["url"]
        assert "offset=10" in received_url["url"]

    def test_analytics_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/t1/gateway/analytics" in str(request.url)
            return ok_response({"request_count": 100, "cache_hit_rate": 0.42})

        client = make_client(handler)
        result = client.gateway.analytics("t1")
        assert result["request_count"] == 100
        assert result["cache_hit_rate"] == pytest.approx(0.42)

    def test_analytics_empty_tenant_raises(self):
        def never_call(req): raise AssertionError()
        client = make_client(never_call)
        with pytest.raises(ValueError, match="tenant_id"):
            client.gateway.analytics("")


# ── Agent New Endpoint Tests ───────────────────────────────────────────────


class TestAgentNewEndpoints:
    def test_get_session_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/sessions/sess-1" in str(request.url)
            return ok_response({
                "id": "sess-1", "agent_id": "a-1", "tenant_id": "t-1",
                "status": "active", "started_at": "2026-01-01T00:00:00Z",
                "ended_at": None, "last_heartbeat": "2026-01-01T00:00:00Z",
                "metadata_json": "{}",
            })

        client = make_client(handler)
        from forgememory_enterprise.types import AgentSession
        result = client.agents.get_session("sess-1")
        assert isinstance(result, AgentSession)
        assert result.id == "sess-1"
        assert result.status == "active"

    def test_list_active_sessions_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/sessions/active" in str(request.url)
            return ok_response([
                {"id": "s-1", "agent_id": "a-1", "tenant_id": "t-1",
                 "status": "active", "started_at": "2026-01-01T00:00:00Z",
                 "ended_at": None, "last_heartbeat": "2026-01-01T00:00:00Z", "metadata_json": "{}"},
                {"id": "s-2", "agent_id": "a-2", "tenant_id": "t-1",
                 "status": "active", "started_at": "2026-01-01T00:00:00Z",
                 "ended_at": None, "last_heartbeat": "2026-01-01T00:00:00Z", "metadata_json": "{}"},
            ])

        client = make_client(handler)
        results = client.agents.list_active_sessions()
        assert len(results) == 2
        assert all(s.status == "active" for s in results)

    def test_log_cost_path(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/agents/a-1/costs" in str(request.url)
            received_body.update(json.loads(request.content))
            return ok_response("Cost recorded")

        client = make_client(handler)
        result = client.agents.log_cost("a-1", 250, "GPT-4 call for analysis")
        assert result == "Cost recorded"
        assert received_body["amount_cents"] == 250
        assert received_body["description"] == "GPT-4 call for analysis"
        assert received_body["agent_id"] == "a-1"


# ── Audit Delegation Chain Tests ───────────────────────────────────────────


class TestAuditDelegationChain:
    def test_get_delegation_chain_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/audit/delegations/chain/corr-abc" in str(request.url)
            return ok_response([
                {"id": 1, "from_agent_id": "a-root", "to_agent_id": "a-child",
                 "session_id": "s-1", "task": "analyze", "status": "completed",
                 "created_at": "2026-01-01T00:00:00Z", "completed_at": "2026-01-01T00:01:00Z"},
                {"id": 2, "from_agent_id": "a-child", "to_agent_id": "a-leaf",
                 "session_id": "s-1", "task": "summarize", "status": "completed",
                 "created_at": "2026-01-01T00:01:00Z", "completed_at": "2026-01-01T00:02:00Z"},
            ])

        client = make_client(handler)
        from forgememory_enterprise.types import Delegation
        results = client.audit.get_delegation_chain("corr-abc")
        assert len(results) == 2
        assert isinstance(results[0], Delegation)
        assert results[0].from_agent_id == "a-root"
        assert results[1].to_agent_id == "a-leaf"


# ── Admin New Endpoint Tests ───────────────────────────────────────────────


class TestAdminNewEndpoints:
    def test_daily_costs_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/admin/costs/daily" in str(request.url)
            return ok_response([
                {"agent_id": "a-1", "date": "2026-03-13", "total_cost_usd": 0.05},
                {"agent_id": "a-2", "date": "2026-03-13", "total_cost_usd": 0.12},
            ])

        client = make_client(handler)
        results = client.admin.daily_costs()
        assert len(results) == 2
        assert results[0]["agent_id"] == "a-1"

    def test_daily_costs_with_date_filter(self):
        received_url = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_url["url"] = str(request.url)
            return ok_response([])

        client = make_client(handler)
        client.admin.daily_costs(date="2026-03-01")
        assert "date=2026-03-01" in received_url["url"]

    def test_tenant_costs_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/admin/costs/by-tenant" in str(request.url)
            return ok_response([
                {"tenant_id": "t-1", "total_cost_usd": 1.50},
                {"tenant_id": "t-2", "total_cost_usd": 0.75},
            ])

        client = make_client(handler)
        results = client.admin.tenant_costs()
        assert len(results) == 2
        assert results[0]["tenant_id"] == "t-1"

    def test_tiered_index_seed_path(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/admin/tiered-index/seed" in str(request.url)
            if request.content:
                received_body.update(json.loads(request.content))
            return ok_response({"tenants_seeded": 3, "topics_created": 45})

        client = make_client(handler)
        result = client.admin.tiered_index_seed()
        assert result["tenants_seeded"] == 3

    def test_tiered_index_seed_with_tenant_id(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_body.update(json.loads(request.content))
            return ok_response({"tenants_seeded": 1, "topics_created": 12})

        client = make_client(handler)
        client.admin.tiered_index_seed(tenant_id="t-1")
        assert received_body.get("tenant_id") == "t-1"

    def test_global_stats_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/admin/stats" in str(request.url)
            return ok_response({
                "total_memories": 5000,
                "total_tenants": 12,
                "total_agents": 7,
            })

        client = make_client(handler)
        result = client.admin.global_stats()
        assert result["total_memories"] == 5000
        assert result["total_tenants"] == 12


# ── Tenant New Endpoint Tests ──────────────────────────────────────────────


class TestTenantNewEndpoints:
    def test_archive_tenant_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/tenants/t-1/archive" in str(request.url)
            return ok_response("Tenant archived")

        client = make_client(handler)
        result = client.tenants.archive_tenant("t-1")
        assert result == "Tenant archived"

    def test_archive_tenant_with_idempotency_key(self):
        received_headers = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_headers.update(dict(request.headers))
            return ok_response("Tenant archived")

        client = make_client(handler)
        client.tenants.archive_tenant("t-1", idempotency_key="idem-archive-t1")
        assert received_headers.get("idempotency-key") == "idem-archive-t1"

    def test_get_usage_path(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/t-1/usage" in str(request.url)
            return ok_response({
                "memory_count": 1250,
                "max_memories": 5000,
                "storage_bytes": 52428800,
                "quota_used_pct": 0.25,
            })

        client = make_client(handler)
        result = client.tenants.get_usage("t-1")
        assert result["memory_count"] == 1250
        assert result["max_memories"] == 5000
        assert result["quota_used_pct"] == pytest.approx(0.25)


# ── Client Wiring Tests ────────────────────────────────────────────────────


class TestClientWiring:
    """Verify that new sub-clients are accessible from EnterpriseClient."""

    def _dummy_handler(self, request: httpx.Request) -> httpx.Response:
        return ok_response({})

    def test_legal_holds_accessible(self):
        from forgememory_enterprise.legal_holds import LegalHoldClient
        client = make_client(self._dummy_handler)
        assert isinstance(client.legal_holds, LegalHoldClient)

    def test_gateway_accessible(self):
        from forgememory_enterprise.gateway import GatewayClient
        client = make_client(self._dummy_handler)
        assert isinstance(client.gateway, GatewayClient)

    def test_legal_holds_cached(self):
        """Property must return the same instance on repeated access."""
        client = make_client(self._dummy_handler)
        assert client.legal_holds is client.legal_holds

    def test_gateway_cached(self):
        client = make_client(self._dummy_handler)
        assert client.gateway is client.gateway


# ── Validation utility Tests ───────────────────────────────────────────────


class TestValidationHelpers:
    """Unit tests for require_non_empty and require_positive."""

    def test_require_non_empty_valid(self):
        from forgememory_enterprise._http import require_non_empty
        require_non_empty("hello", "field")  # Should not raise

    def test_require_non_empty_empty_string(self):
        from forgememory_enterprise._http import require_non_empty
        with pytest.raises(ValueError, match="field"):
            require_non_empty("", "field")

    def test_require_non_empty_whitespace(self):
        from forgememory_enterprise._http import require_non_empty
        with pytest.raises(ValueError, match="field"):
            require_non_empty("   ", "field")

    def test_require_positive_valid(self):
        from forgememory_enterprise._http import require_positive
        require_positive(1, "limit")  # Should not raise
        require_positive(100, "limit")  # Should not raise

    def test_require_positive_zero(self):
        from forgememory_enterprise._http import require_positive
        with pytest.raises(ValueError, match="limit"):
            require_positive(0, "limit")

    def test_require_positive_negative(self):
        from forgememory_enterprise._http import require_positive
        with pytest.raises(ValueError, match="limit"):
            require_positive(-5, "limit")
