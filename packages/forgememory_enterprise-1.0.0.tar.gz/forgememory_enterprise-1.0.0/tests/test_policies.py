"""Tests for PolicyClient — compliance policy engine CRUD."""

import json

import httpx
import pytest

from conftest import make_client, ok_response


# ── Sample data factories ────────────────────────────────────────────────


def sample_policy(
    id: str = "pol-1",
    tenant_id: str = "tenant-1",
    name: str = "Block PII writes",
    policy_type: str = "sensitivity_gate",
) -> dict:
    return {
        "id": id,
        "tenant_id": tenant_id,
        "name": name,
        "policy_type": policy_type,
        "config": {"max_sensitivity": "confidential"},
        "action": "deny",
        "enabled": True,
        "created_at": "2026-03-01T12:00:00Z",
        "updated_at": "2026-03-01T12:00:00Z",
    }


# ── Tests ────────────────────────────────────────────────────────────────


class TestPolicyClient:
    def test_create_policy(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/tenants/tenant-1/policies" in str(request.url)
            body = json.loads(request.content)
            assert body["name"] == "Block PII writes"
            assert body["policy_type"] == "sensitivity_gate"
            assert json.loads(body["config_json"]) =={"max_sensitivity": "confidential"}
            assert body["action"] == "deny"
            return ok_response(sample_policy())

        client = make_client(handler)
        policy = client.policies.create(
            "tenant-1",
            name="Block PII writes",
            policy_type="sensitivity_gate",
            config={"max_sensitivity": "confidential"},
        )
        assert policy.id == "pol-1"
        assert policy.name == "Block PII writes"
        assert policy.policy_type == "sensitivity_gate"
        assert policy.config == {"max_sensitivity": "confidential"}
        assert policy.action == "deny"
        assert policy.enabled is True

    def test_create_policy_custom_action(self):
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["action"] == "warn"
            result = sample_policy()
            result["action"] = "warn"
            return ok_response(result)

        client = make_client(handler)
        policy = client.policies.create(
            "tenant-1",
            name="Warn on high sensitivity",
            policy_type="sensitivity_gate",
            config={"max_sensitivity": "restricted"},
            action="warn",
        )
        assert policy.action == "warn"

    def test_list_policies(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/tenant-1/policies" in str(request.url)
            return ok_response([sample_policy(), sample_policy(id="pol-2", name="Retention override")])

        client = make_client(handler)
        policies = client.policies.list("tenant-1")
        assert len(policies) == 2
        assert policies[0].id == "pol-1"
        assert policies[1].id == "pol-2"
        assert policies[1].name == "Retention override"

    def test_list_policies_empty(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([])

        client = make_client(handler)
        policies = client.policies.list("tenant-1")
        assert policies == []

    def test_get_policy(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/tenant-1/policies/pol-1" in str(request.url)
            return ok_response(sample_policy())

        client = make_client(handler)
        policy = client.policies.get("tenant-1", "pol-1")
        assert policy.id == "pol-1"
        assert policy.name == "Block PII writes"

    def test_update_policy(self):
        updated = sample_policy()
        updated["name"] = "Updated policy name"
        updated["enabled"] = False

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "PATCH"
            assert "/tenants/tenant-1/policies/pol-1" in str(request.url)
            body = json.loads(request.content)
            assert body["name"] == "Updated policy name"
            assert body["enabled"] is False
            # Should only contain fields that were passed
            assert "policy_type" not in body
            return ok_response(updated)

        client = make_client(handler)
        policy = client.policies.update("tenant-1", "pol-1", name="Updated policy name", enabled=False)
        assert policy.name == "Updated policy name"
        assert policy.enabled is False

    def test_update_policy_config(self):
        updated = sample_policy()
        updated["config"] = {"max_sensitivity": "restricted", "alert": True}

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert json.loads(body["config_json"]) =={"max_sensitivity": "restricted", "alert": True}
            return ok_response(updated)

        client = make_client(handler)
        policy = client.policies.update(
            "tenant-1", "pol-1",
            config={"max_sensitivity": "restricted", "alert": True},
        )
        assert policy.config["alert"] is True

    def test_delete_policy(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "DELETE"
            assert "/tenants/tenant-1/policies/pol-1" in str(request.url)
            return ok_response(None)

        client = make_client(handler)
        # Should not raise
        client.policies.delete("tenant-1", "pol-1")
