"""Tests for Aegis SandboxClient."""

from __future__ import annotations

import pytest

from conftest import error_response, make_client, ok_response


# ── Sample data ──────────────────────────────────────────────────────────────


def sample_session(
    session_id: str = "sbox_sess_abc123",
    tenant_id: str = "tenant-1",
    status: str = "active",
) -> dict:
    return {
        "session_id": session_id,
        "session_token": "sbox_tok_xyz789",
        "tenant_id": tenant_id,
        "status": status,
        "expires_at": "2026-03-22T12:00:00Z",
        "rate_limit_rpm": 60,
        "max_queries": None,
        "sensitivity_ceiling": 1,
        "dlp_mode": "strict",
        "query_count": 0,
    }


def sample_query_result() -> dict:
    return {
        "results": [{"id": "mem-1", "content": "Test memory", "score": 0.95}],
        "query_id": "qry_001",
        "dlp_entities_removed": 0,
        "policies_evaluated": 2,
        "policies_blocked": 0,
        "receipt_hash": "sha256:abc123",
        "queries_remaining": 19,
    }


def sample_receipt() -> dict:
    return {
        "session_id": "sbox_sess_abc123",
        "query_count": 1,
        "total_dlp_removals": 0,
        "zkat_epoch_ids": ["epoch-1"],
        "chain_proof": "merkle:abc123",
        "session_log": [{"query_id": "qry_001", "hash": "sha256:abc123"}],
    }


# ── Tests ─────────────────────────────────────────────────────────────────────


def test_create_session_success():
    """create_session POSTs to the correct URL and returns session data."""
    def handler(request):
        assert request.method == "POST"
        assert "/api/v1/tenants/tenant-1/sandbox/sessions" in str(request.url)
        return ok_response(sample_session())

    client = make_client(handler)
    result = client.sandbox.create_session("tenant-1")
    assert result["session_id"] == "sbox_sess_abc123"
    assert result["session_token"] == "sbox_tok_xyz789"
    assert result["status"] == "active"


def test_create_session_with_options():
    """create_session passes optional params correctly."""
    def handler(request):
        import json
        body = json.loads(request.content)
        assert body["expires_in_secs"] == 7200
        assert body["rate_limit_rpm"] == 30
        assert body["max_queries"] == 100
        assert body["sensitivity_ceiling"] == 2
        assert body["dlp_mode"] == "detect"
        assert body["agent_id"] == "agent-1"
        return ok_response(sample_session())

    client = make_client(handler)
    result = client.sandbox.create_session(
        "tenant-1",
        expires_in_secs=7200,
        rate_limit_rpm=30,
        max_queries=100,
        sensitivity_ceiling=2,
        dlp_mode="detect",
        agent_id="agent-1",
    )
    assert result["session_id"] == "sbox_sess_abc123"


def test_list_sessions():
    """list_sessions GETs the correct URL and returns a list."""
    def handler(request):
        assert request.method == "GET"
        assert "/api/v1/tenants/tenant-1/sandbox/sessions" in str(request.url)
        return ok_response([sample_session()])

    client = make_client(handler)
    result = client.sandbox.list_sessions("tenant-1")
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0]["session_id"] == "sbox_sess_abc123"


def test_get_session():
    """get_session GETs the correct session URL."""
    def handler(request):
        assert request.method == "GET"
        assert "/api/v1/tenants/tenant-1/sandbox/sessions/sbox_sess_abc123" in str(request.url)
        return ok_response(sample_session())

    client = make_client(handler)
    result = client.sandbox.get_session("tenant-1", "sbox_sess_abc123")
    assert result["session_id"] == "sbox_sess_abc123"
    assert result["tenant_id"] == "tenant-1"


def test_revoke_session():
    """revoke_session DELETEs the correct session URL."""
    def handler(request):
        assert request.method == "DELETE"
        assert "/api/v1/tenants/tenant-1/sandbox/sessions/sbox_sess_abc123" in str(request.url)
        return ok_response({"revoked": True, "session_id": "sbox_sess_abc123"})

    client = make_client(handler)
    result = client.sandbox.revoke_session("tenant-1", "sbox_sess_abc123")
    assert result["revoked"] is True


def test_execute_query_uses_session_token_as_bearer():
    """execute_query must use session_token (not API key) as Authorization Bearer."""
    def handler(request):
        assert request.method == "POST"
        assert "/api/v1/tenants/tenant-1/sandbox/sessions/sbox_sess_abc123/query" in str(request.url)
        # Critical: session token as Bearer, NOT the API key
        auth = request.headers.get("Authorization", "")
        assert auth == "Bearer sbox_tok_xyz789", f"Expected session token Bearer, got: {auth}"
        return ok_response(sample_query_result())

    client = make_client(handler)
    result = client.sandbox.execute_query(
        "tenant-1",
        "sbox_sess_abc123",
        "sbox_tok_xyz789",
        "What are the recent client interactions?",
    )
    assert result["query_id"] == "qry_001"
    assert result["dlp_entities_removed"] == 0
    assert result["queries_remaining"] == 19
    assert isinstance(result["results"], list)


def test_get_receipt():
    """get_receipt GETs the tamper-evident ZKAT receipt for a session."""
    def handler(request):
        assert request.method == "GET"
        assert "/api/v1/tenants/tenant-1/sandbox/sessions/sbox_sess_abc123/receipt" in str(request.url)
        return ok_response(sample_receipt())

    client = make_client(handler)
    result = client.sandbox.get_receipt("tenant-1", "sbox_sess_abc123")
    assert result["session_id"] == "sbox_sess_abc123"
    assert result["query_count"] == 1
    assert "chain_proof" in result
    assert "session_log" in result


def test_create_session_rejects_empty_tenant():
    """create_session raises an error for empty tenant_id."""
    client = make_client(lambda r: ok_response({}))
    with pytest.raises(Exception):
        client.sandbox.create_session("")


def test_execute_query_with_detail_and_limit():
    """execute_query forwards detail and limit params correctly."""
    import json
    def handler(request):
        body = json.loads(request.content)
        assert body["query"] == "recent transactions"
        assert body["detail"] == "summary"
        assert body["limit"] == 5
        return ok_response({"results": [], "query_id": "qry_002",
                            "dlp_entities_removed": 0, "policies_evaluated": 1,
                            "policies_blocked": 0, "receipt_hash": "sha256:xyz",
                            "queries_remaining": 14})
    client = make_client(handler)
    result = client.sandbox.execute_query(
        "tenant-1", "sbox_sess_abc123", "sbox_tok_xyz789",
        "recent transactions", detail="summary", limit=5
    )
    assert result["query_id"] == "qry_002"
    assert result["queries_remaining"] == 14


def test_execute_query_returns_receipt_hash():
    """execute_query result includes a sha256 receipt_hash."""
    def handler(request):
        return ok_response({
            "results": [{"id": "m1", "content": "Account balance Q4", "score": 0.91}],
            "query_id": "qry_003",
            "dlp_entities_removed": 2,
            "policies_evaluated": 3,
            "policies_blocked": 1,
            "receipt_hash": "sha256:deadbeef1234567890abcdef",
            "queries_remaining": 8,
        })
    client = make_client(handler)
    result = client.sandbox.execute_query(
        "tenant-1", "sbox_sess_abc123", "sbox_tok_xyz789", "account balance"
    )
    # Content assertions — not just status
    assert result["receipt_hash"].startswith("sha256:")
    assert result["dlp_entities_removed"] == 2
    assert result["policies_blocked"] == 1
    assert len(result["results"]) == 1
    assert result["results"][0]["content"] == "Account balance Q4"


def test_create_session_policy_preset_forwarded():
    """create_session forwards policy_preset list correctly."""
    import json
    def handler(request):
        body = json.loads(request.content)
        assert body.get("policy_preset") == ["OutboundPiiGate", "SensitivityGate"]
        return ok_response({
            "session_id": "sbox_sess_policy123",
            "session_token": "sbox_tok_aaa",
            "tenant_id": "tenant-1",
            "status": "active",
            "expires_at": "2026-03-22T13:00:00Z",
        })
    client = make_client(handler)
    result = client.sandbox.create_session(
        "tenant-1",
        policy_preset=["OutboundPiiGate", "SensitivityGate"],
    )
    assert result["session_id"] == "sbox_sess_policy123"
    assert result["status"] == "active"


def test_get_receipt_fields_validated():
    """get_receipt returns all required ZKAT receipt fields with correct types."""
    def handler(request):
        return ok_response({
            "session_id": "sbox_sess_abc123",
            "query_count": 5,
            "total_dlp_removals": 3,
            "zkat_epoch_ids": ["epoch-1", "epoch-2"],
            "chain_proof": "sha256:aaabbbccc",
            "session_log": [
                {"query_id": "qry_001", "hash": "sha256:aaa"},
                {"query_id": "qry_002", "hash": "sha256:bbb"},
            ],
        })
    client = make_client(handler)
    result = client.sandbox.get_receipt("tenant-1", "sbox_sess_abc123")
    # Content validation — exact values
    assert result["query_count"] == 5
    assert result["total_dlp_removals"] == 3
    assert len(result["zkat_epoch_ids"]) == 2
    assert result["chain_proof"].startswith("sha256:")
    assert len(result["session_log"]) == 2
    assert result["session_log"][0]["query_id"] == "qry_001"


def test_revoke_session_rejects_empty_session_id():
    """revoke_session raises for empty session_id."""
    client = make_client(lambda r: ok_response({}))
    with pytest.raises(Exception):
        client.sandbox.revoke_session("tenant-1", "")


def test_get_session_rejects_empty_tenant():
    """get_session raises for empty tenant_id."""
    client = make_client(lambda r: ok_response({}))
    with pytest.raises(Exception):
        client.sandbox.get_session("", "sbox_sess_abc123")
