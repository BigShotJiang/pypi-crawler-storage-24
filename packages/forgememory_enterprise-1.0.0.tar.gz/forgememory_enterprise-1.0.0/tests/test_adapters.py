"""Tests for framework adapters."""

import json

import httpx
import pytest

from conftest import make_client, ok_response, sample_memory


class TestCrewAIAdapter:
    def test_search_command(self):
        def handler(request: httpx.Request) -> httpx.Response:
            if "search" in str(request.url):
                return ok_response([sample_memory(content="Found result")])
            return ok_response(sample_memory())

        client = make_client(handler)
        from forgememory_enterprise.adapters.crewai_adapter import ForgeMemoryTool

        tool = ForgeMemoryTool(client, tenant_id="tenant-1")
        result = tool.run("search:test query")
        assert "Found result" in result

    def test_store_command(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_memory(id="mem-new"))

        client = make_client(handler)
        from forgememory_enterprise.adapters.crewai_adapter import ForgeMemoryTool

        tool = ForgeMemoryTool(client, tenant_id="tenant-1")
        result = tool.run("store:important fact")
        assert "mem-new" in result

    def test_unknown_command(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response("ok")

        client = make_client(handler)
        from forgememory_enterprise.adapters.crewai_adapter import ForgeMemoryTool

        tool = ForgeMemoryTool(client, tenant_id="tenant-1")
        result = tool.run("invalid command")
        assert "Unknown command" in result

    def test_search_no_results(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([])

        client = make_client(handler)
        from forgememory_enterprise.adapters.crewai_adapter import ForgeMemoryTool

        tool = ForgeMemoryTool(client, tenant_id="tenant-1")
        result = tool.run("search:nothing here")
        assert "No memories found" in result

    def test_observer_on_tool_use(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            calls.append(body.get("action_type"))
            return ok_response({"id": 1, "agent_id": "a", "session_id": "s", "action_type": "tool_call",
                               "detail": "", "tokens_in": 0, "tokens_out": 0, "cost_usd": 0,
                               "created_at": ""})

        client = make_client(handler)
        from forgememory_enterprise.adapters.crewai_adapter import FMECrewObserver

        observer = FMECrewObserver(client, "agent-1", "sess-1")
        observer.on_tool_use("search", "test query")
        assert "tool_call" in calls

    def test_observer_on_llm_call(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            calls.append(body)
            return ok_response({"id": 1, "agent_id": "a", "session_id": "s", "action_type": "llm_request",
                               "detail": "", "tokens_in": 100, "tokens_out": 50, "cost_usd": 0.001,
                               "created_at": ""})

        client = make_client(handler)
        from forgememory_enterprise.adapters.crewai_adapter import FMECrewObserver

        observer = FMECrewObserver(client, "agent-1", "sess-1")
        observer.on_llm_call(tokens_in=100, tokens_out=50, cost_usd=0.001)
        assert calls[0]["tokens_in"] == 100


class TestLangGraphAdapter:
    def test_retrieve_node(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_memory(content="relevant info")])

        client = make_client(handler)
        from forgememory_enterprise.adapters.langgraph_adapter import make_memory_retrieve_node

        node = make_memory_retrieve_node(client, tenant_id="tenant-1")
        result = node({"query": "test"})
        assert "relevant info" in result["memory_context"]

    def test_retrieve_node_empty_query(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([])

        client = make_client(handler)
        from forgememory_enterprise.adapters.langgraph_adapter import make_memory_retrieve_node

        node = make_memory_retrieve_node(client, tenant_id="tenant-1")
        result = node({"query": ""})
        assert result["memory_context"] == ""

    def test_store_node(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_memory(id="new-mem"))

        client = make_client(handler)
        from forgememory_enterprise.adapters.langgraph_adapter import make_memory_store_node

        node = make_memory_store_node(client, tenant_id="tenant-1")
        result = node({"memory_to_store": "important fact"})
        assert result["memory_stored_id"] == "new-mem"

    def test_store_node_empty_content(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_memory())

        client = make_client(handler)
        from forgememory_enterprise.adapters.langgraph_adapter import make_memory_store_node

        node = make_memory_store_node(client, tenant_id="tenant-1")
        result = node({"memory_to_store": ""})
        assert result["memory_stored_id"] is None

    def test_context_node(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response({"context": "assembled context", "memories_used": 3})

        client = make_client(handler)
        from forgememory_enterprise.adapters.langgraph_adapter import make_memory_context_node

        node = make_memory_context_node(client, tenant_id="tenant-1")
        result = node({"query": "project status"})
        assert result["memory_context"] == "assembled context"


class TestAutoGenAdapter:
    def test_fme_tool_decorator(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_memory(content="found via autogen")])

        client = make_client(handler)
        from forgememory_enterprise.adapters.autogen_adapter import fme_tool

        @fme_tool(client, tenant_id="tenant-1")
        def search_memory(query: str) -> str:
            """Search organizational memory."""
            ...

        result = search_memory("test")
        assert "found via autogen" in result

    def test_fme_tool_no_results(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([])

        client = make_client(handler)
        from forgememory_enterprise.adapters.autogen_adapter import fme_tool

        @fme_tool(client, tenant_id="tenant-1")
        def search_memory(query: str) -> str:
            """Search."""
            ...

        result = search_memory("nothing")
        assert "No relevant memories" in result

    def test_inject_context(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response({"context": "some context", "memories_used": 2})

        client = make_client(handler)
        from forgememory_enterprise.adapters.autogen_adapter import inject_context

        result = inject_context(client, "tenant-1", "status")
        assert "Relevant Memory Context" in result
        assert "some context" in result

    def test_inject_context_empty(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response({"context": "", "memories_used": 0})

        client = make_client(handler)
        from forgememory_enterprise.adapters.autogen_adapter import inject_context

        result = inject_context(client, "tenant-1", "nothing")
        assert result == ""

    def test_store_conversation_memory(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_memory(id="conv-mem"))

        client = make_client(handler)
        from forgememory_enterprise.adapters.autogen_adapter import store_conversation_memory

        mem_id = store_conversation_memory(client, "tenant-1", "conversation summary")
        assert mem_id == "conv-mem"


class TestOpenClawAdapter:
    def test_get_context(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response({"context": "openclaw context", "memories_used": 5})

        client = make_client(handler)
        from forgememory_enterprise.adapters.openclaw_adapter import get_openclaw_context

        result = get_openclaw_context(client, "tenant-1", "preferences")
        assert "ForgeMemory Context (5 memories)" in result
        assert "openclaw context" in result

    def test_get_context_empty(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response({"context": "", "memories_used": 0})

        client = make_client(handler)
        from forgememory_enterprise.adapters.openclaw_adapter import get_openclaw_context

        result = get_openclaw_context(client, "tenant-1", "nothing")
        assert result == ""

    def test_store_session(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_memory(id="oc-mem"))

        client = make_client(handler)
        from forgememory_enterprise.adapters.openclaw_adapter import store_openclaw_session

        mem_id = store_openclaw_session(client, "tenant-1", "session summary")
        assert mem_id == "oc-mem"

    def test_search_memories(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([
                sample_memory(content="result 1"),
                sample_memory(id="mem-2", content="result 2"),
            ])

        client = make_client(handler)
        from forgememory_enterprise.adapters.openclaw_adapter import search_openclaw_memories

        results = search_openclaw_memories(client, "tenant-1", "test")
        assert results == ["result 1", "result 2"]
