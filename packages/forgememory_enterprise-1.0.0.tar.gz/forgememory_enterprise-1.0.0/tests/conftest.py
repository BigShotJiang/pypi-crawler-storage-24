"""Shared test fixtures using httpx.MockTransport."""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from forgememory_enterprise import EnterpriseClient


def ok_response(data: Any, status: int = 200) -> httpx.Response:
    """Create a successful ApiResponse envelope."""
    body = json.dumps({"success": True, "data": data, "error": None})
    return httpx.Response(status, text=body, headers={"content-type": "application/json"})


def error_response(error: str, status: int = 400) -> httpx.Response:
    """Create an error ApiResponse envelope."""
    body = json.dumps({"success": False, "data": None, "error": error})
    return httpx.Response(status, text=body, headers={"content-type": "application/json"})


def make_mock_transport(handler) -> httpx.MockTransport:
    """Create a MockTransport from a request handler function."""
    return httpx.MockTransport(handler)


def make_client(handler) -> EnterpriseClient:
    """Create an EnterpriseClient with a mock transport."""
    transport = make_mock_transport(handler)
    return EnterpriseClient(
        api_key="fme_test_key_123",
        base_url="http://fme-test:8201",
        transport=transport,
    )


# ── Sample data factories ────────────────────────────────────────────────


def sample_org(id: str = "org-1", name: str = "Acme Corp", slug: str = "acme") -> dict:
    return {"id": id, "name": name, "slug": slug, "active": True, "created_at": "2026-01-01T00:00:00Z"}


def sample_user(
    id: str = "user-1",
    org_id: str = "org-1",
    email: str = "alice@acme.com",
    display_name: str = "Alice",
    role: str = "admin",
) -> dict:
    return {
        "id": id, "org_id": org_id, "email": email,
        "display_name": display_name, "role": role,
        "active": True, "created_at": "2026-01-01T00:00:00Z",
    }


def sample_branch(id: str = "branch-1", org_id: str = "org-1", name: str = "main") -> dict:
    return {"id": id, "org_id": org_id, "name": name, "parent_id": None, "created_at": "2026-01-01T00:00:00Z"}


def sample_tenant(id: str = "tenant-1", org_id: str = "org-1") -> dict:
    return {
        "id": id, "org_id": org_id, "branch_id": None, "user_id": None,
        "scope": "individual", "mode": "per_org", "status": "active",
        "created_at": "2026-01-01T00:00:00Z",
    }


def sample_api_key_created(id: str = "key-1", org_id: str = "org-1") -> dict:
    return {
        "id": id, "raw_key": "fme_raw_abc123", "org_id": org_id,
        "user_id": None, "role": "admin", "label": "test-key",
        "tenant_ids": [], "created_at": "2026-01-01T00:00:00Z", "expires_at": None,
    }


def sample_api_key_row(id: str = "key-1", org_id: str = "org-1") -> dict:
    return {
        "id": id, "org_id": org_id, "user_id": None, "role": "admin",
        "label": "test-key", "key_hash": "abc123hash", "tenant_ids": "",
        "revoked": False, "created_at": "2026-01-01T00:00:00Z",
        "expires_at": None, "last_used_at": None,
    }


def sample_agent(
    id: str = "agent-1", org_id: str = "org-1", name: str = "test-agent"
) -> dict:
    return {
        "id": id, "org_id": org_id, "name": name, "framework": "custom",
        "model_id": "qwen-8b", "capabilities": "read,write",
        "allowed_tenants": "", "status": "active",
        "api_key_hash": "hash123", "created_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-01-01T00:00:00Z",
    }


def sample_session(
    id: str = "sess-1", agent_id: str = "agent-1", tenant_id: str = "tenant-1"
) -> dict:
    return {
        "id": id, "agent_id": agent_id, "tenant_id": tenant_id,
        "status": "active", "started_at": "2026-01-01T00:00:00Z",
        "ended_at": None, "last_heartbeat": "2026-01-01T00:00:00Z",
        "metadata_json": "{}",
    }


def sample_action(
    agent_id: str = "agent-1", session_id: str = "sess-1", action_type: str = "tool_call"
) -> dict:
    return {
        "id": 1, "agent_id": agent_id, "session_id": session_id,
        "action_type": action_type, "detail": "search", "tokens_in": 100,
        "tokens_out": 50, "cost_usd": 0.001, "created_at": "2026-01-01T00:00:00Z",
    }


def sample_memory(
    id: str = "mem-1", tenant_id: str = "tenant-1", content: str = "Test memory",
    client_id: str | None = None, source_channel: str | None = None,
    source_ref: str | None = None, app: str | None = None,
    visibility: str | None = None, thread_id: str | None = None,
    sensitivity: str | None = None,
) -> dict:
    return {
        "id": id, "tenant_id": tenant_id, "content": content,
        "memory_type": "semantic", "importance": 5, "source": "test",
        "tags": "tag1,tag2", "user_id": None, "metadata_json": "{}",
        "content_hash": "abc123", "access_count": 0,
        "last_accessed": "2026-01-01T00:00:00Z",
        "created_at": "2026-01-01T00:00:00Z", "updated_at": "2026-01-01T00:00:00Z",
        "client_id": client_id, "source_channel": source_channel,
        "source_ref": source_ref, "app": app, "visibility": visibility,
        "thread_id": thread_id, "sensitivity": sensitivity,
    }


def sample_memory_access(
    agent_id: str = "agent-1", memory_id: str = "mem-1"
) -> dict:
    return {
        "id": 1, "agent_id": agent_id, "session_id": "sess-1",
        "tenant_id": "tenant-1", "memory_id": memory_id,
        "access_type": "read", "created_at": "2026-01-01T00:00:00Z",
    }


def sample_delegation(
    from_agent: str = "agent-1", to_agent: str = "agent-2"
) -> dict:
    return {
        "id": 1, "from_agent_id": from_agent, "to_agent_id": to_agent,
        "session_id": "sess-1", "task": "summarize document",
        "status": "pending", "created_at": "2026-01-01T00:00:00Z",
        "completed_at": None,
    }


def sample_cost(agent_id: str = "agent-1") -> dict:
    return {
        "agent_id": agent_id, "date": "2026-01-01",
        "total_tokens_in": 1000, "total_tokens_out": 500,
        "total_cost_usd": 0.01, "request_count": 5,
    }
