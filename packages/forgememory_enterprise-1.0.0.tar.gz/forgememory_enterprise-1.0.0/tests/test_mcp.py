"""Tests for ForgeMemory Enterprise MCP server."""

import json
import os
import sys

import pytest

# Add parent dir to path so we can import the MCP module
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import forgememory_enterprise_mcp as mcp


# ── Protocol Tests ──

class TestHandleRequest:
    def test_initialize(self):
        resp = mcp.handle_request({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
        assert resp["id"] == 1
        assert resp["result"]["protocolVersion"] == "2024-11-05"
        assert resp["result"]["serverInfo"]["name"] == "forgememory-enterprise"

    def test_tools_list(self):
        resp = mcp.handle_request({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
        tools = resp["result"]["tools"]
        assert len(tools) == 30  # includes fme_get_topics
        names = {t["name"] for t in tools}
        assert "fme_search_memories" in names
        assert "fme_add_memory" in names
        assert "fme_get_context" in names
        assert "fme_register_agent" in names
        assert "fme_log_action" in names
        assert "fme_dashboard" in names
        assert "fme_gdpr_erasure" in names
        # New Week 2 tools
        assert "fme_get_thread" in names
        assert "fme_link_thread" in names
        assert "fme_create_dsr" in names
        assert "fme_list_dsr" in names
        assert "fme_approve_dsr" in names
        assert "fme_compliance_posture" in names
        assert "fme_compliance_evidence" in names
        assert "fme_rotate_key" in names
        assert "fme_health_ready" in names

    def test_tools_list_all_have_schemas(self):
        resp = mcp.handle_request({"jsonrpc": "2.0", "id": 3, "method": "tools/list", "params": {}})
        for tool in resp["result"]["tools"]:
            assert "inputSchema" in tool, f"Tool {tool['name']} missing inputSchema"
            assert "type" in tool["inputSchema"], f"Tool {tool['name']} schema missing type"
            assert tool["inputSchema"]["type"] == "object"

    def test_resources_list_empty(self):
        resp = mcp.handle_request({"jsonrpc": "2.0", "id": 4, "method": "resources/list", "params": {}})
        assert resp["result"]["resources"] == []

    def test_ping(self):
        resp = mcp.handle_request({"jsonrpc": "2.0", "id": 5, "method": "ping", "params": {}})
        assert resp["result"] == {}

    def test_unknown_method(self):
        resp = mcp.handle_request({"jsonrpc": "2.0", "id": 6, "method": "nonexistent", "params": {}})
        assert resp["error"]["code"] == -32601
        assert "nonexistent" in resp["error"]["message"]

    def test_notification_returns_none(self):
        resp = mcp.handle_request({"method": "notifications/initialized", "params": {}})
        assert resp is None

    def test_tool_call_unknown_tool(self):
        resp = mcp.handle_request({
            "jsonrpc": "2.0", "id": 7,
            "method": "tools/call",
            "params": {"name": "nonexistent_tool", "arguments": {}},
        })
        text = resp["result"]["content"][0]["text"]
        data = json.loads(text)
        assert "error" in data
        assert "Unknown tool" in data["error"]


# ── Tool Schema Validation ──

class TestToolSchemas:
    def _get_tool(self, name: str) -> dict:
        for t in mcp.TOOLS:
            if t["name"] == name:
                return t
        raise ValueError(f"Tool {name} not found")

    def test_search_requires_tenant_and_query(self):
        tool = self._get_tool("fme_search_memories")
        assert tool["inputSchema"]["required"] == ["tenant_id", "query"]

    def test_add_memory_requires_tenant_and_content(self):
        tool = self._get_tool("fme_add_memory")
        assert "tenant_id" in tool["inputSchema"]["required"]
        assert "content" in tool["inputSchema"]["required"]

    def test_register_agent_requires_name_org_framework(self):
        tool = self._get_tool("fme_register_agent")
        required = tool["inputSchema"]["required"]
        assert "name" in required
        assert "org_id" in required
        assert "framework" in required

    def test_gdpr_erasure_requires_tenant_client_requestedby(self):
        tool = self._get_tool("fme_gdpr_erasure")
        required = tool["inputSchema"]["required"]
        assert "tenant_id" in required
        assert "client_id" in required
        assert "requested_by" in required

    def test_start_session_requires_agent_and_tenant(self):
        tool = self._get_tool("fme_start_session")
        required = tool["inputSchema"]["required"]
        assert "agent_id" in required
        assert "tenant_id" in required

    def test_log_action_requires_all_fields(self):
        tool = self._get_tool("fme_log_action")
        required = tool["inputSchema"]["required"]
        assert "agent_id" in required
        assert "session_id" in required
        assert "action_type" in required
        assert "description" in required

    def test_log_cost_requires_agent_amount_description(self):
        tool = self._get_tool("fme_log_cost")
        required = tool["inputSchema"]["required"]
        assert "agent_id" in required
        assert "amount_cents" in required
        assert "description" in required

    def test_dashboard_requires_nothing(self):
        tool = self._get_tool("fme_dashboard")
        assert "required" not in tool["inputSchema"] or tool["inputSchema"].get("required") is None

    def test_all_tools_have_descriptions(self):
        for tool in mcp.TOOLS:
            assert len(tool["description"]) > 10, f"Tool {tool['name']} has a short description"

    def test_memory_type_enum_consistent(self):
        """All tools with memory_type should have the same enum values."""
        expected = ["semantic", "episodic", "procedural"]
        for tool in mcp.TOOLS:
            props = tool["inputSchema"].get("properties", {})
            if "memory_type" in props and "enum" in props["memory_type"]:
                assert props["memory_type"]["enum"] == expected, f"Tool {tool['name']} has wrong enum"


# ── Network Detection ──

class TestNetworkDetection:
    def test_check_host_unreachable(self):
        result = mcp._check_host("192.0.2.1", 99999, timeout=0.1)
        assert result is False

    def test_detect_base_url_caching(self):
        original_url = mcp._cached_url
        original_at = mcp._cached_at

        mcp._cached_url = "http://test-cached:8201"
        mcp._cached_at = mcp.time.time()  # fresh cache
        try:
            url = mcp.detect_base_url()
            assert url == "http://test-cached:8201"
        finally:
            mcp._cached_url = original_url
            mcp._cached_at = original_at

    def test_detect_base_url_expired_cache(self):
        original_url = mcp._cached_url
        original_at = mcp._cached_at
        original_lan = mcp.LAN_HOST
        original_ts = mcp.TAILSCALE_HOST

        mcp._cached_url = "http://old-cache:8201"
        mcp._cached_at = 0  # expired
        # Supply host values so the detection path is exercised rather than the
        # "no hosts configured" early-exit branch.
        mcp.LAN_HOST = "192.0.2.1"      # TEST-NET — unreachable
        mcp.TAILSCALE_HOST = "192.0.2.2"  # TEST-NET — unreachable
        try:
            # Both hosts are unreachable (TEST-NET), so ConnectionError is expected.
            with pytest.raises(ConnectionError) as exc_info:
                mcp.detect_base_url()
            assert "8201" in str(exc_info.value)
        finally:
            mcp._cached_url = original_url
            mcp._cached_at = original_at
            mcp.LAN_HOST = original_lan
            mcp.TAILSCALE_HOST = original_ts


# ── Tenant Resolution ──

class TestTenantResolution:
    def test_resolve_from_args(self):
        assert mcp._resolve_tenant({"tenant_id": "t-123"}) == "t-123"

    def test_resolve_fallback_to_default(self):
        original = mcp.DEFAULT_TENANT
        mcp.DEFAULT_TENANT = "default-tenant"
        try:
            assert mcp._resolve_tenant({}) == "default-tenant"
        finally:
            mcp.DEFAULT_TENANT = original

    def test_resolve_args_override_default(self):
        original = mcp.DEFAULT_TENANT
        mcp.DEFAULT_TENANT = "default-tenant"
        try:
            assert mcp._resolve_tenant({"tenant_id": "override"}) == "override"
        finally:
            mcp.DEFAULT_TENANT = original


# ── Execute Tool (path construction, no live server) ──

class TestExecuteToolPaths:
    """Test that execute_tool builds correct URL paths.
    These will fail the HTTP call but we verify the path construction."""

    def _mock_api_call(self, method: str, path: str, body: dict | None = None) -> dict:
        """Capture the call and return a mock."""
        self.last_call = {"method": method, "path": path, "body": body}
        return {"success": True, "data": {"id": "mock-id"}}

    def setup_method(self):
        self.original_api_call = mcp.api_call
        mcp.api_call = self._mock_api_call
        self.last_call = None

    def teardown_method(self):
        mcp.api_call = self.original_api_call

    def test_search_path(self):
        mcp.execute_tool("fme_search_memories", {"tenant_id": "t1", "query": "test"})
        assert self.last_call["method"] == "POST"
        assert self.last_call["path"] == "/api/v1/tenants/t1/memories/search"
        assert self.last_call["body"]["query"] == "test"

    def test_add_memory_path(self):
        mcp.execute_tool("fme_add_memory", {"tenant_id": "t1", "content": "hello"})
        assert self.last_call["method"] == "POST"
        assert self.last_call["path"] == "/api/v1/tenants/t1/memories"
        assert self.last_call["body"]["content"] == "hello"

    def test_add_memory_with_all_fields(self):
        mcp.execute_tool("fme_add_memory", {
            "tenant_id": "t1", "content": "test", "memory_type": "episodic",
            "importance": 8, "tags": "a,b", "user_id": "u1", "client_id": "c1",
        })
        body = self.last_call["body"]
        assert body["memory_type"] == "episodic"
        assert body["importance"] == 8
        assert body["tags"] == ["a", "b"]
        assert body["user_id"] == "u1"
        assert body["client_id"] == "c1"

    def test_get_context_path(self):
        mcp.execute_tool("fme_get_context", {"tenant_id": "t1", "query": "what", "max_tokens": 200})
        assert self.last_call["method"] == "GET"
        assert "/api/v1/tenants/t1/context" in self.last_call["path"]
        assert "query=what" in self.last_call["path"]
        assert "max_tokens=200" in self.last_call["path"]

    def test_get_memory_path(self):
        mcp.execute_tool("fme_get_memory", {"tenant_id": "t1", "memory_id": "m-abc"})
        assert self.last_call["path"] == "/api/v1/tenants/t1/memories/m-abc"
        assert self.last_call["method"] == "GET"

    def test_delete_memory_path(self):
        mcp.execute_tool("fme_delete_memory", {"tenant_id": "t1", "memory_id": "m-xyz"})
        assert self.last_call["path"] == "/api/v1/tenants/t1/memories/m-xyz"
        assert self.last_call["method"] == "DELETE"

    def test_register_agent_path(self):
        mcp.execute_tool("fme_register_agent", {
            "name": "test-agent", "org_id": "org-1", "framework": "crewai",
        })
        assert self.last_call["path"] == "/api/v1/agents"
        assert self.last_call["body"]["name"] == "test-agent"

    def test_list_agents_with_filters(self):
        mcp.execute_tool("fme_list_agents", {"org_id": "org-1", "framework": "langgraph", "limit": 10})
        assert self.last_call["method"] == "GET"
        assert "org_id=org-1" in self.last_call["path"]
        assert "framework=langgraph" in self.last_call["path"]
        assert "limit=10" in self.last_call["path"]

    def test_start_session_path(self):
        mcp.execute_tool("fme_start_session", {"agent_id": "a1", "tenant_id": "t1"})
        assert self.last_call["path"] == "/api/v1/agents/a1/sessions"
        assert self.last_call["body"]["agent_id"] == "a1"

    def test_end_session_path(self):
        mcp.execute_tool("fme_end_session", {"session_id": "s-123", "status": "failed"})
        assert self.last_call["path"] == "/api/v1/sessions/s-123/end"
        assert self.last_call["body"]["status"] == "failed"

    def test_log_action_path(self):
        mcp.execute_tool("fme_log_action", {
            "agent_id": "a1", "session_id": "s1",
            "action_type": "tool_call", "description": "called search",
        })
        assert self.last_call["path"] == "/api/v1/agents/a1/actions"

    def test_log_cost_path(self):
        mcp.execute_tool("fme_log_cost", {
            "agent_id": "a1", "amount_cents": 150, "description": "gpt-4 call",
        })
        assert self.last_call["path"] == "/api/v1/agents/a1/costs"
        assert self.last_call["body"]["amount_cents"] == 150

    def test_list_tenants_path(self):
        mcp.execute_tool("fme_list_tenants", {"limit": 20, "offset": 5})
        assert self.last_call["method"] == "GET"
        assert "limit=20" in self.last_call["path"]
        assert "offset=5" in self.last_call["path"]

    def test_get_tenant_path(self):
        mcp.execute_tool("fme_get_tenant", {"tenant_id": "t-abc"})
        assert self.last_call["path"] == "/api/v1/tenants/t-abc"

    def test_dashboard_path(self):
        mcp.execute_tool("fme_dashboard", {})
        assert self.last_call["path"] == "/api/v1/admin/dashboard"

    def test_gdpr_erasure_path(self):
        mcp.execute_tool("fme_gdpr_erasure", {
            "tenant_id": "t1", "client_id": "c1", "requested_by": "admin",
        })
        assert self.last_call["path"] == "/api/v1/tenants/t1/gdpr/erasure"
        assert self.last_call["body"]["client_id"] == "c1"

    def test_unknown_tool_returns_error(self):
        result = json.loads(mcp.execute_tool("nonexistent", {}))
        assert "error" in result


# ── Auth Header ──

class TestAuthHeaders:
    def test_api_key_in_env(self):
        original = mcp.API_KEY
        mcp.API_KEY = "test-key-abc"
        try:
            # We can't easily test urllib.request headers without mocking,
            # but we can verify the key is read
            assert mcp.API_KEY == "test-key-abc"
        finally:
            mcp.API_KEY = original

    def test_default_tenant_from_env(self):
        original = mcp.DEFAULT_TENANT
        mcp.DEFAULT_TENANT = "env-tenant"
        try:
            assert mcp._resolve_tenant({}) == "env-tenant"
        finally:
            mcp.DEFAULT_TENANT = original


# ── JSON-RPC Response Format ──

class TestResponseFormat:
    def setup_method(self):
        self.original_api_call = mcp.api_call
        mcp.api_call = lambda m, p, b=None: {"success": True, "data": []}

    def teardown_method(self):
        mcp.api_call = self.original_api_call

    def test_tool_call_response_has_content(self):
        resp = mcp.handle_request({
            "jsonrpc": "2.0", "id": 10,
            "method": "tools/call",
            "params": {"name": "fme_dashboard", "arguments": {}},
        })
        assert "result" in resp
        assert "content" in resp["result"]
        assert len(resp["result"]["content"]) == 1
        assert resp["result"]["content"][0]["type"] == "text"

    def test_tool_call_error_has_isError(self):
        def failing_call(m, p, b=None):
            raise RuntimeError("connection refused")
        mcp.api_call = failing_call

        resp = mcp.handle_request({
            "jsonrpc": "2.0", "id": 11,
            "method": "tools/call",
            "params": {"name": "fme_dashboard", "arguments": {}},
        })
        assert resp["result"]["isError"] is True
        text = resp["result"]["content"][0]["text"]
        assert "connection refused" in text


# ── New Tool Schema Tests ──

class TestNewToolSchemas:
    """Schema validation for the 9 new Week 2 tools."""

    def _get_tool(self, name: str) -> dict:
        for t in mcp.TOOLS:
            if t["name"] == name:
                return t
        raise ValueError(f"Tool {name} not found")

    def test_get_thread_requires_tenant_and_thread(self):
        tool = self._get_tool("fme_get_thread")
        required = tool["inputSchema"]["required"]
        assert "tenant_id" in required
        assert "thread_id" in required

    def test_link_thread_requires_tenant_thread_and_memory_ids(self):
        tool = self._get_tool("fme_link_thread")
        required = tool["inputSchema"]["required"]
        assert "tenant_id" in required
        assert "thread_id" in required
        assert "memory_ids" in required

    def test_link_thread_memory_ids_is_array(self):
        tool = self._get_tool("fme_link_thread")
        schema = tool["inputSchema"]["properties"]["memory_ids"]
        assert schema["type"] == "array"
        assert schema["items"]["type"] == "string"

    def test_create_dsr_requires_tenant_type_subject(self):
        tool = self._get_tool("fme_create_dsr")
        required = tool["inputSchema"]["required"]
        assert "tenant_id" in required
        assert "request_type" in required
        assert "subject_id" in required

    def test_create_dsr_request_type_enum(self):
        tool = self._get_tool("fme_create_dsr")
        enum_vals = tool["inputSchema"]["properties"]["request_type"]["enum"]
        assert "erasure" in enum_vals
        assert "access" in enum_vals
        assert "rectification" in enum_vals
        assert "portability" in enum_vals

    def test_list_dsr_requires_tenant(self):
        tool = self._get_tool("fme_list_dsr")
        assert "tenant_id" in tool["inputSchema"]["required"]

    def test_approve_dsr_requires_tenant_and_dsr_id(self):
        tool = self._get_tool("fme_approve_dsr")
        required = tool["inputSchema"]["required"]
        assert "tenant_id" in required
        assert "dsr_id" in required

    def test_approve_dsr_reviewer_notes_optional(self):
        tool = self._get_tool("fme_approve_dsr")
        props = tool["inputSchema"]["properties"]
        required = tool["inputSchema"].get("required", [])
        assert "reviewer_notes" in props
        assert "reviewer_notes" not in required

    def test_compliance_posture_requires_nothing(self):
        tool = self._get_tool("fme_compliance_posture")
        assert "required" not in tool["inputSchema"] or not tool["inputSchema"].get("required")

    def test_compliance_evidence_requires_nothing(self):
        tool = self._get_tool("fme_compliance_evidence")
        assert "required" not in tool["inputSchema"] or not tool["inputSchema"].get("required")

    def test_rotate_key_requires_key_id(self):
        tool = self._get_tool("fme_rotate_key")
        assert tool["inputSchema"]["required"] == ["key_id"]

    def test_rotate_key_grace_period_optional(self):
        tool = self._get_tool("fme_rotate_key")
        props = tool["inputSchema"]["properties"]
        required = tool["inputSchema"].get("required", [])
        assert "grace_period_hours" in props
        assert "grace_period_hours" not in required

    def test_health_ready_requires_nothing(self):
        tool = self._get_tool("fme_health_ready")
        assert "required" not in tool["inputSchema"] or not tool["inputSchema"].get("required")

    def test_all_new_tools_have_descriptions(self):
        new_tools = [
            "fme_get_thread", "fme_link_thread", "fme_create_dsr", "fme_list_dsr",
            "fme_approve_dsr", "fme_compliance_posture", "fme_compliance_evidence",
            "fme_rotate_key", "fme_health_ready",
        ]
        for name in new_tools:
            tool = self._get_tool(name)
            assert len(tool["description"]) > 10, f"{name} has a short description"


# ── New Tool Execution Path Tests ──

class TestNewToolPaths:
    """Test URL path construction for the 9 new tools (no live server)."""

    def _mock_api_call(self, method: str, path: str, body: dict | None = None) -> dict:
        self.last_call = {"method": method, "path": path, "body": body}
        return {"success": True, "data": {}}

    def setup_method(self):
        self.original_api_call = mcp.api_call
        mcp.api_call = self._mock_api_call
        self.last_call = None

    def teardown_method(self):
        mcp.api_call = self.original_api_call

    def test_get_thread_path(self):
        mcp.execute_tool("fme_get_thread", {"tenant_id": "t1", "thread_id": "thread-abc"})
        assert self.last_call["method"] == "GET"
        assert self.last_call["path"] == "/api/v1/tenants/t1/threads/thread-abc"

    def test_link_thread_path(self):
        mcp.execute_tool("fme_link_thread", {
            "tenant_id": "t1", "thread_id": "th-1", "memory_ids": ["m-a", "m-b"],
        })
        assert self.last_call["method"] == "POST"
        assert self.last_call["path"] == "/api/v1/tenants/t1/threads"
        assert self.last_call["body"]["thread_id"] == "th-1"
        assert self.last_call["body"]["memory_ids"] == ["m-a", "m-b"]

    def test_create_dsr_path(self):
        mcp.execute_tool("fme_create_dsr", {
            "tenant_id": "t1", "request_type": "erasure", "subject_id": "sub-1",
        })
        assert self.last_call["method"] == "POST"
        assert self.last_call["path"] == "/api/v1/tenants/t1/dsr/request"
        assert self.last_call["body"]["request_type"] == "erasure"
        assert self.last_call["body"]["subject_id"] == "sub-1"

    def test_create_dsr_with_reason(self):
        mcp.execute_tool("fme_create_dsr", {
            "tenant_id": "t1", "request_type": "access", "subject_id": "sub-2",
            "reason": "annual review",
        })
        assert self.last_call["body"]["reason"] == "annual review"

    def test_list_dsr_path(self):
        mcp.execute_tool("fme_list_dsr", {"tenant_id": "t1"})
        assert self.last_call["method"] == "GET"
        assert self.last_call["path"] == "/api/v1/tenants/t1/dsr"

    def test_approve_dsr_path(self):
        mcp.execute_tool("fme_approve_dsr", {"tenant_id": "t1", "dsr_id": "dsr-xyz"})
        assert self.last_call["method"] == "POST"
        assert self.last_call["path"] == "/api/v1/tenants/t1/dsr/dsr-xyz/approve"

    def test_approve_dsr_with_notes(self):
        mcp.execute_tool("fme_approve_dsr", {
            "tenant_id": "t1", "dsr_id": "dsr-xyz", "reviewer_notes": "verified identity",
        })
        assert self.last_call["body"]["reviewer_notes"] == "verified identity"

    def test_approve_dsr_without_notes_sends_empty_body(self):
        mcp.execute_tool("fme_approve_dsr", {"tenant_id": "t1", "dsr_id": "dsr-xyz"})
        assert self.last_call["body"] == {}

    def test_compliance_posture_path(self):
        mcp.execute_tool("fme_compliance_posture", {})
        assert self.last_call["method"] == "GET"
        assert self.last_call["path"] == "/api/v1/admin/compliance-posture"

    def test_compliance_evidence_path(self):
        mcp.execute_tool("fme_compliance_evidence", {})
        assert self.last_call["method"] == "GET"
        assert self.last_call["path"] == "/api/v1/admin/compliance-evidence"

    def test_rotate_key_path(self):
        mcp.execute_tool("fme_rotate_key", {"key_id": "key-abc"})
        assert self.last_call["method"] == "POST"
        assert self.last_call["path"] == "/api/v1/api-keys/key-abc/rotate"

    def test_rotate_key_default_grace_period(self):
        mcp.execute_tool("fme_rotate_key", {"key_id": "key-abc"})
        assert self.last_call["body"]["grace_period_hours"] == 24

    def test_rotate_key_custom_grace_period(self):
        mcp.execute_tool("fme_rotate_key", {"key_id": "key-abc", "grace_period_hours": 48})
        assert self.last_call["body"]["grace_period_hours"] == 48

    def test_health_ready_path(self):
        mcp.execute_tool("fme_health_ready", {})
        assert self.last_call["method"] == "GET"
        assert self.last_call["path"] == "/health/ready"
