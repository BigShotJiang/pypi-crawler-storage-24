"""Tests for OrgManager."""

import httpx
import pytest

from conftest import (
    error_response,
    make_client,
    ok_response,
    sample_branch,
    sample_org,
    sample_tenant,
    sample_user,
)
from forgememory_enterprise import NotFoundError
from forgememory_enterprise.types import GlobalStats


class TestOrgManager:
    def test_create_org(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/api/v1/orgs" in str(request.url)
            return ok_response(sample_org())

        client = make_client(handler)
        org = client.orgs.create_org("Acme Corp", "acme")
        assert org.id == "org-1"
        assert org.name == "Acme Corp"
        assert org.slug == "acme"

    def test_list_orgs(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_org(), sample_org(id="org-2", name="Beta Inc", slug="beta")])

        client = make_client(handler)
        orgs = client.orgs.list_orgs()
        assert len(orgs) == 2
        assert orgs[1].slug == "beta"

    def test_get_org(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_org())

        client = make_client(handler)
        org = client.orgs.get_org("acme")
        assert org.id == "org-1"

    def test_get_org_not_found(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("Org not found", 404)

        client = make_client(handler)
        with pytest.raises(NotFoundError):
            client.orgs.get_org("nonexistent")

    def test_create_user(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_user())

        client = make_client(handler)
        user = client.orgs.create_user("org-1", "alice@acme.com", "Alice", "admin")
        assert user.id == "user-1"
        assert user.email == "alice@acme.com"

    def test_list_users(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_user()])

        client = make_client(handler)
        users = client.orgs.list_users("org-1")
        assert len(users) == 1

    def test_create_branch(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_branch())

        client = make_client(handler)
        branch = client.orgs.create_branch("org-1", "main")
        assert branch.id == "branch-1"

    def test_provision(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_tenant())

        client = make_client(handler)
        tenant = client.orgs.provision("org-1", mode="per_org")
        assert tenant.id == "tenant-1"
        assert tenant.status == "active"

    def test_global_stats(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response({
                "total_orgs": 3, "total_users": 10, "total_branches": 5,
                "total_tenants": 8, "total_api_keys": 12,
                "active_tenants": 6, "suspended_tenants": 2,
            })

        client = make_client(handler)
        stats = client.orgs.global_stats()
        assert stats.total_orgs == 3
        assert stats.active_tenants == 6
