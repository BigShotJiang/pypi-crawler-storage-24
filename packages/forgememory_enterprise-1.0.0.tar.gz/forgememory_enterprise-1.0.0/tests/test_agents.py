"""Tests for AgentRegistry and AgentSessionContext."""

import json
import threading
import time

import httpx
import pytest

from conftest import error_response, make_client, ok_response, sample_agent, sample_session
from forgememory_enterprise import AuthenticationError, BudgetExceededError, NotFoundError
from forgememory_enterprise.agents import AgentSessionContext
from forgememory_enterprise.types import AgentRegistration, AgentUpdate


class TestAgentRegistry:
    def test_register_agent(self):
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["name"] == "my-agent"
            assert body["framework"] == "crewai"
            return ok_response(sample_agent(name="my-agent"))

        client = make_client(handler)
        reg = AgentRegistration(org_id="org-1", name="my-agent", framework="crewai")
        agent = client.agents.register(reg)
        assert agent.name == "my-agent"

    def test_get_agent(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_agent())

        client = make_client(handler)
        agent = client.agents.get("agent-1")
        assert agent.id == "agent-1"

    def test_get_agent_not_found(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("Agent not found", 404)

        client = make_client(handler)
        with pytest.raises(NotFoundError):
            client.agents.get("nonexistent")

    def test_update_agent(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_agent())

        client = make_client(handler)
        agent = client.agents.update("agent-1", AgentUpdate(model_id="new-model"))
        assert agent.id == "agent-1"

    def test_list_agents(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_agent(), sample_agent(id="agent-2", name="other")])

        client = make_client(handler)
        agents = client.agents.list()
        assert len(agents) == 2

    def test_list_agents_by_framework(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert "framework=crewai" in str(request.url)
            return ok_response([sample_agent()])

        client = make_client(handler)
        agents = client.agents.list(framework="crewai")
        assert len(agents) == 1

    def test_delete_agent(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "DELETE"
            return ok_response("Agent deleted")

        client = make_client(handler)
        result = client.agents.delete("agent-1")
        assert result == "Agent deleted"

    def test_disable_enable_agent(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            calls.append(body.get("status"))
            return ok_response(sample_agent())

        client = make_client(handler)
        client.agents.disable("agent-1")
        client.agents.enable("agent-1")
        assert calls == ["disabled", "active"]

    def test_start_session(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_session())

        client = make_client(handler)
        session = client.agents.start_session("agent-1", "tenant-1")
        assert session.id == "sess-1"
        assert session.status == "active"

    def test_end_session(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert "/end" in str(request.url)
            return ok_response("Session ended")

        client = make_client(handler)
        result = client.agents.end_session("sess-1")
        assert result == "Session ended"

    def test_heartbeat(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert "/heartbeat" in str(request.url)
            return ok_response("Heartbeat recorded")

        client = make_client(handler)
        result = client.agents.heartbeat("sess-1")
        assert result == "Heartbeat recorded"

    def test_list_sessions(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_session()])

        client = make_client(handler)
        sessions = client.agents.list_sessions("agent-1")
        assert len(sessions) == 1

    def test_authenticate(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_agent())

        client = make_client(handler)
        agent = client.agents.authenticate("fme_test_key")
        assert agent.id == "agent-1"

    def test_authenticate_fails(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("Invalid agent key", 401)

        client = make_client(handler)
        with pytest.raises(AuthenticationError):
            client.agents.authenticate("bad_key")

    def test_check_budget(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response("Within budget")

        client = make_client(handler)
        result = client.agents.check_budget("agent-1", daily_budget=10.0)
        assert result == "Within budget"

    def test_check_budget_exceeded(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("Agent exceeded budget", 402)

        client = make_client(handler)
        with pytest.raises(BudgetExceededError):
            client.agents.check_budget("agent-1", daily_budget=0.01)


class TestAgentSessionContext:
    def test_session_context_normal_flow(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            if request.method == "POST" and "sessions" in url:
                if "/end" in url:
                    body = json.loads(request.content)
                    calls.append(f"end:{body['status']}")
                    return ok_response("ended")
                if "/heartbeat" in url:
                    calls.append("heartbeat")
                    return ok_response("ok")
                calls.append("start")
                return ok_response(sample_session())
            return ok_response("ok")

        client = make_client(handler)
        with client.session("agent-1", "tenant-1", heartbeat_interval=999) as sess:
            assert sess.id == "sess-1"
            calls.append("work")

        assert "start" in calls
        assert "work" in calls
        assert "end:completed" in calls

    def test_session_context_exception_sets_failed(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            if request.method == "POST" and "sessions" in url:
                if "/end" in url:
                    body = json.loads(request.content)
                    calls.append(f"end:{body['status']}")
                    return ok_response("ended")
                return ok_response(sample_session())
            return ok_response("ok")

        client = make_client(handler)
        with pytest.raises(ValueError):
            with client.session("agent-1", "tenant-1", heartbeat_interval=999) as sess:
                raise ValueError("something broke")

        assert "end:failed" in calls

    def test_session_id_raises_before_start(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_session())

        client = make_client(handler)
        ctx = client.session("agent-1", "tenant-1")
        with pytest.raises(RuntimeError, match="Session not started"):
            _ = ctx.id
