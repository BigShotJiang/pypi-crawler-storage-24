"""Tests for EntityGraphClient — Dynamic Entity Graph SDK."""

import json

import httpx
import pytest

from conftest import error_response, make_client, ok_response
from forgememory_enterprise import NotFoundError
from forgememory_enterprise.types import (
    CreateEdgeRequest,
    CreateEntityRequest,
    EntityNode,
    GraphEdge,
    TraversalResult,
    UpdateEntityRequest,
)


# ── Sample data factories ────────────────────────────────────────────────


def sample_entity(
    name: str = "Martinez Family",
    entity_type: str = "household",
    user_id: str | None = None,
    relationship: str | None = None,
    notes: str | None = None,
) -> dict:
    return {
        "name": name,
        "entity_type": entity_type,
        "user_id": user_id,
        "relationship": relationship,
        "metadata_json": '{"household_type": "family", "primary_advisor": "Jane Smith"}',
        "notes": notes,
        "created_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-01-01T00:00:00Z",
    }


def sample_edge(
    id: str = "edge-1",
    source_id: str = "Martinez Family",
    target_id: str = "Johnson Corp",
    relationship: str = "member_of",
    memory_id: str | None = None,
) -> dict:
    return {
        "id": id,
        "source_id": source_id,
        "target_id": target_id,
        "relationship": relationship,
        "weight": 1.0,
        "memory_id": memory_id,
        "created_at": "2026-01-01T00:00:00Z",
    }


def sample_traversal(
    root: str = "Martinez Family",
    nodes: list | None = None,
    edges: list | None = None,
) -> dict:
    return {
        "root": root,
        "nodes": nodes or [],
        "edges": edges or [],
    }


# ── Entity CRUD Tests ────────────────────────────────────────────────────


class TestEntityCRUD:
    def test_create_entity(self):
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["name"] == "Martinez Family"
            assert body["entity_type"] == "household"
            assert request.method == "POST"
            assert "/entities" in str(request.url)
            return ok_response(sample_entity(), status=201)

        client = make_client(handler)
        req = CreateEntityRequest(name="Martinez Family", entity_type="household")
        entity = client.entities.create_entity("tenant-1", req)
        assert entity.name == "Martinez Family"
        assert entity.entity_type == "household"

    def test_create_entity_with_metadata(self):
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["metadata"]["primary_advisor"] == "Jane Smith"
            return ok_response(sample_entity(), status=201)

        client = make_client(handler)
        req = CreateEntityRequest(
            name="Martinez Family",
            entity_type="household",
            metadata={"primary_advisor": "Jane Smith"},
        )
        entity = client.entities.create_entity("tenant-1", req)
        assert entity.name == "Martinez Family"

    def test_create_entity_with_relationship_and_notes(self):
        """relationship and notes are optional fields on create."""
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["relationship"] == "client_of"
            assert body["notes"] == "High net worth"
            return ok_response(
                sample_entity(relationship="client_of", notes="High net worth"),
                status=201,
            )

        client = make_client(handler)
        req = CreateEntityRequest(
            name="Martinez Family",
            entity_type="household",
            relationship="client_of",
            notes="High net worth",
        )
        entity = client.entities.create_entity("tenant-1", req)
        assert entity.relationship == "client_of"
        assert entity.notes == "High net worth"

    def test_create_entity_strips_none_optional_fields(self):
        """None optional fields (relationship, notes) should not appear in the payload."""
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert "relationship" not in body
            assert "notes" not in body
            return ok_response(sample_entity(), status=201)

        client = make_client(handler)
        req = CreateEntityRequest(name="Martinez Family", entity_type="household")
        client.entities.create_entity("tenant-1", req)

    def test_get_entity(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/entities/Martinez%20Family" in str(request.url) or \
                   "/entities/Martinez Family" in str(request.url)
            return ok_response(sample_entity())

        client = make_client(handler)
        result = client.entities.get_entity("tenant-1", "Martinez Family")
        assert isinstance(result, EntityNode)
        assert result.name == "Martinez Family"

    def test_get_entity_not_found(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("Entity not found", 404)

        client = make_client(handler)
        with pytest.raises(NotFoundError):
            client.entities.get_entity("tenant-1", "nonexistent")

    def test_list_entities(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/entities" in str(request.url)
            return ok_response([
                sample_entity(),
                sample_entity(name="Johnson Corp", entity_type="contact"),
            ])

        client = make_client(handler)
        entities = client.entities.list_entities("tenant-1")
        assert len(entities) == 2
        assert entities[0].name == "Martinez Family"
        assert entities[1].name == "Johnson Corp"

    def test_list_entities_filter_by_type(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert "entity_type=household" in str(request.url)
            return ok_response([sample_entity()])

        client = make_client(handler)
        entities = client.entities.list_entities("tenant-1", entity_type="household")
        assert len(entities) == 1
        assert entities[0].entity_type == "household"

    def test_list_entities_limit_param(self):
        """list_entities sends limit but NOT offset (Rust API doesn't support offset)."""
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "limit=25" in url
            assert "offset" not in url
            return ok_response([])

        client = make_client(handler)
        entities = client.entities.list_entities("tenant-1", limit=25)
        assert entities == []

    def test_update_entity(self):
        updated = sample_entity(entity_type="contact")

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert request.method == "PATCH"
            assert "/entities/Martinez%20Family" in str(request.url) or \
                   "/entities/Martinez Family" in str(request.url)
            assert body["entity_type"] == "contact"
            return ok_response(updated)

        client = make_client(handler)
        req = UpdateEntityRequest(entity_type="contact")
        entity = client.entities.update_entity("tenant-1", "Martinez Family", req)
        assert entity.entity_type == "contact"

    def test_update_entity_partial(self):
        """Only the non-None fields should be sent in the PATCH payload."""
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert "entity_type" in body
            # relationship, metadata, notes should be absent when None
            assert "relationship" not in body
            assert "metadata" not in body
            assert "notes" not in body
            return ok_response(sample_entity())

        client = make_client(handler)
        req = UpdateEntityRequest(entity_type="contact")
        client.entities.update_entity("tenant-1", "Martinez Family", req)

    def test_delete_entity(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "DELETE"
            assert "/entities/Martinez%20Family" in str(request.url) or \
                   "/entities/Martinez Family" in str(request.url)
            return ok_response({"deleted": "Martinez Family"})

        client = make_client(handler)
        result = client.entities.delete_entity("tenant-1", "Martinez Family")
        assert result == "Martinez Family"


# ── Edge CRUD Tests ───────────────────────────────────────────────────────


class TestEdgeCRUD:
    def test_create_edge(self):
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["source"] == "Martinez Family"
            assert body["target"] == "Johnson Corp"
            assert body["relationship"] == "member_of"
            assert request.method == "POST"
            assert "/edges" in str(request.url)
            return ok_response(sample_edge(), status=201)

        client = make_client(handler)
        req = CreateEdgeRequest(
            source="Martinez Family",
            target="Johnson Corp",
            relationship="member_of",
        )
        edge = client.entities.create_edge("tenant-1", req)
        assert edge.id == "edge-1"
        assert edge.relationship == "member_of"

    def test_create_edge_strips_none_optional_fields(self):
        """weight=None and memory_id=None should not appear in the payload."""
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert "memory_id" not in body
            assert "weight" not in body
            return ok_response(sample_edge(), status=201)

        client = make_client(handler)
        req = CreateEdgeRequest(
            source="Martinez Family",
            target="Johnson Corp",
            relationship="member_of",
            memory_id=None,
        )
        client.entities.create_edge("tenant-1", req)

    def test_create_edge_with_memory_id(self):
        """memory_id should be included in the payload when explicitly set."""
        edge_data = sample_edge(memory_id="mem-42")

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["memory_id"] == "mem-42"
            return ok_response(edge_data, status=201)

        client = make_client(handler)
        req = CreateEdgeRequest(
            source="Martinez Family",
            target="Johnson Corp",
            relationship="member_of",
            memory_id="mem-42",
        )
        edge = client.entities.create_edge("tenant-1", req)
        assert edge.memory_id == "mem-42"

    def test_create_edge_with_weight(self):
        """Explicit weight should be sent in the payload."""
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["weight"] == 0.75
            return ok_response(sample_edge(), status=201)

        client = make_client(handler)
        req = CreateEdgeRequest(
            source="Martinez Family",
            target="Johnson Corp",
            relationship="member_of",
            weight=0.75,
        )
        client.entities.create_edge("tenant-1", req)

    def test_list_edges(self):
        """list_edges uses GET /edges?entity_type=... (not /entities/{id}/edges)."""
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            url = str(request.url)
            assert "/edges" in url
            assert "/entities/" not in url
            return ok_response([
                sample_edge(),
                sample_edge(id="edge-2", relationship="spouse_of"),
            ])

        client = make_client(handler)
        edges = client.entities.list_edges("tenant-1")
        assert len(edges) == 2
        assert edges[0].id == "edge-1"
        assert edges[1].relationship == "spouse_of"

    def test_list_edges_filter_by_entity_type(self):
        """list_edges can filter by entity_type via query param."""
        def handler(request: httpx.Request) -> httpx.Response:
            assert "entity_type=household" in str(request.url)
            return ok_response([sample_edge()])

        client = make_client(handler)
        edges = client.entities.list_edges("tenant-1", entity_type="household")
        assert len(edges) == 1

    def test_delete_edge(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "DELETE"
            assert "/edges/edge-1" in str(request.url)
            return ok_response({"deleted": "edge-1"})

        client = make_client(handler)
        result = client.entities.delete_edge("tenant-1", "edge-1")
        assert result == "edge-1"


# ── Graph Traversal Tests ─────────────────────────────────────────────────


class TestGraphTraversal:
    def test_traverse_default_depth(self):
        """traverse uses GET /entities/{name}/graph with depth param."""
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "/entities/" in url
            assert "/graph" in url
            assert "depth=2" in url
            return ok_response(sample_traversal())

        client = make_client(handler)
        result = client.entities.traverse("tenant-1", "Martinez Family")
        assert isinstance(result, TraversalResult)
        assert result.root == "Martinez Family"

    def test_traverse_custom_depth(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert "depth=3" in str(request.url)
            return ok_response(sample_traversal())

        client = make_client(handler)
        result = client.entities.traverse("tenant-1", "Martinez Family", depth=3)
        assert result.root == "Martinez Family"

    def test_traverse_with_relationship_filter(self):
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "relationship=member_of" in url
            return ok_response(sample_traversal())

        client = make_client(handler)
        result = client.entities.traverse(
            "tenant-1", "Martinez Family", relationship="member_of"
        )
        assert result.root == "Martinez Family"

    def test_traverse_returns_nodes_and_edges(self):
        nodes = [
            sample_entity(name="Martinez Family"),
            sample_entity(name="Carlos Martinez", entity_type="contact"),
        ]
        edges = [sample_edge()]

        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_traversal(nodes=nodes, edges=edges))

        client = make_client(handler)
        result = client.entities.traverse("tenant-1", "Martinez Family", depth=1)
        assert len(result.nodes) == 2
        assert len(result.edges) == 1
        assert result.nodes[0].name == "Martinez Family"
        assert result.edges[0].relationship == "member_of"

    def test_traverse_endpoint_uses_graph_not_traverse(self):
        """Rust uses /graph endpoint, not /traverse."""
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "/graph" in url
            assert "/traverse" not in url
            return ok_response(sample_traversal())

        client = make_client(handler)
        client.entities.traverse("tenant-1", "Martinez Family")

    def test_traverse_empty_graph(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_traversal(nodes=[], edges=[]))

        client = make_client(handler)
        result = client.entities.traverse("tenant-1", "orphan-entity")
        assert result.nodes == []
        assert result.edges == []


# ── Model / Type Tests ────────────────────────────────────────────────────


class TestEntityModels:
    def test_entity_node_defaults(self):
        node = EntityNode(name="Test")
        assert node.entity_type == "entity"
        assert node.user_id is None
        assert node.relationship is None
        assert node.metadata_json == "{}"
        assert node.notes is None
        assert node.created_at == ""
        assert node.updated_at == ""

    def test_entity_node_name_is_pk(self):
        """EntityNode uses name as primary key — no separate id field."""
        node = EntityNode(name="Martinez Family")
        assert node.name == "Martinez Family"
        assert not hasattr(node, "id") or "id" not in node.model_fields

    def test_create_entity_request_defaults(self):
        req = CreateEntityRequest(name="Test Entity")
        assert req.entity_type == "entity"
        assert req.metadata == {}
        assert req.relationship is None
        assert req.notes is None

    def test_graph_edge_defaults(self):
        edge = GraphEdge(
            id="e-1",
            source_id="entity-a",
            target_id="entity-b",
            relationship="owns",
        )
        assert edge.weight == 1.0
        assert edge.memory_id is None
        assert edge.created_at == ""

    def test_graph_edge_no_metadata_field(self):
        """GraphEdge mirrors Rust EdgeResponse — no metadata dict."""
        edge = GraphEdge(
            id="e-1",
            source_id="entity-a",
            target_id="entity-b",
            relationship="owns",
        )
        assert not hasattr(edge, "metadata") or "metadata" not in edge.model_fields

    def test_update_entity_all_none(self):
        """UpdateEntityRequest should allow all fields to be None."""
        req = UpdateEntityRequest()
        assert req.entity_type is None
        assert req.relationship is None
        assert req.metadata is None
        assert req.notes is None

    def test_update_entity_no_name_field(self):
        """UpdateEntityRequest does NOT include name — entity is addressed by name in URL."""
        req = UpdateEntityRequest()
        assert not hasattr(req, "name") or "name" not in req.model_fields

    def test_traversal_result_defaults(self):
        result = TraversalResult(root="Martinez Family")
        assert result.root == "Martinez Family"
        assert result.nodes == []
        assert result.edges == []

    def test_traversal_result_no_depth_field(self):
        """TraversalResult mirrors Rust TraversalResponse — no depth field."""
        result = TraversalResult(root="entity-a")
        assert not hasattr(result, "depth") or "depth" not in result.model_fields

    def test_create_edge_request_fields(self):
        """CreateEdgeRequest uses source/target (not source_id/target_id)."""
        req = CreateEdgeRequest(
            source="entity-a",
            target="entity-b",
            relationship="owns",
        )
        assert req.source == "entity-a"
        assert req.target == "entity-b"
        assert req.weight is None  # optional, not defaulting to 1.0
        assert req.memory_id is None

    def test_entity_node_metadata_json_is_string(self):
        """metadata_json is a raw JSON string, not a parsed dict."""
        node = EntityNode(
            name="Test",
            metadata_json='{"key": "value"}',
        )
        assert isinstance(node.metadata_json, str)
        assert node.metadata_json == '{"key": "value"}'
