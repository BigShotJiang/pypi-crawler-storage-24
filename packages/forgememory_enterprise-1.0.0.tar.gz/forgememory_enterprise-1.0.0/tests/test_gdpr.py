"""Tests for GDPR and Compliance workflows (DSR, Compliance, Retention)."""

import json

import httpx
import pytest

from conftest import make_client, ok_response, error_response


class TestDsrClient:
    def test_create_request(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert request.url.path == "/api/v1/tenants/t-1/dsr/request"
            payload = json.loads(request.content)
            assert payload["request_type"] == "erasure"
            assert payload["subject_id"] == "user123"
            assert payload["reason"] == "User requested deletion"
            return ok_response({
                "id": "dsr-1", "tenant_id": "t-1", "subject_email": "fake@test.com",
                "request_type": "erasure", "status": "pending",
                "description": "", "notes": "", "reason": "User requested deletion",
                "created_at": "2026-01-01", "updated_at": "2026-01-01", "completed_at": None
            })

        client = make_client(handler)
        record = client.dsr.create_request("t-1", "erasure", "user123", reason="User requested deletion")
        assert record.id == "dsr-1"
        assert record.status == "pending"
        assert record.reason == "User requested deletion"

    def test_list_requests(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert request.url.path == "/api/v1/tenants/t-1/dsr"
            return ok_response([{
                "id": "dsr-1", "tenant_id": "t-1", "subject_email": "fake@test.com",
                "request_type": "erasure", "status": "pending",
                "description": "", "notes": "", "reason": "",
                "created_at": "2026-01-01", "updated_at": "2026-01-01", "completed_at": None
            }])

        client = make_client(handler)
        records = client.dsr.list_requests("t-1")
        assert len(records) == 1
        assert records[0].id == "dsr-1"

    def test_get_request(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert request.url.path == "/api/v1/tenants/t-1/dsr/dsr-1"
            return ok_response({
                "id": "dsr-1", "tenant_id": "t-1", "subject_email": "fake@test.com",
                "request_type": "erasure", "status": "pending",
                "description": "", "notes": "", "reason": "",
                "created_at": "2026-01-01", "updated_at": "2026-01-01", "completed_at": None
            })

        client = make_client(handler)
        record = client.dsr.get_request("t-1", "dsr-1")
        assert record.id == "dsr-1"

    def test_approve_request(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert request.url.path == "/api/v1/tenants/t-1/dsr/dsr-1/approve"
            return ok_response({
                "id": "dsr-1", "tenant_id": "t-1", "subject_email": "fake@test.com",
                "request_type": "erasure", "status": "approved",
                "description": "", "notes": "Approved", "reason": "",
                "created_at": "2026-01-01", "updated_at": "2026-01-01", "completed_at": None
            })

        client = make_client(handler)
        record = client.dsr.approve_request("t-1", "dsr-1", reviewer_notes="Approved")
        assert record.status == "approved"

    def test_reject_request(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert request.url.path == "/api/v1/tenants/t-1/dsr/dsr-1/reject"
            payload = json.loads(request.content)
            assert payload["reason"] == "Not found"
            return ok_response({
                "id": "dsr-1", "tenant_id": "t-1", "subject_email": "fake@test.com",
                "request_type": "erasure", "status": "rejected",
                "description": "", "notes": "", "reason": "Not found",
                "created_at": "2026-01-01", "updated_at": "2026-01-01", "completed_at": None
            })

        client = make_client(handler)
        record = client.dsr.reject_request("t-1", "dsr-1", reason="Not found")
        assert record.status == "rejected"

    def test_execute_request(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert request.url.path == "/api/v1/tenants/t-1/dsr/dsr-1/execute"
            return ok_response({
                "id": "dsr-1", "tenant_id": "t-1", "subject_email": "fake@test.com",
                "request_type": "erasure", "status": "completed",
                "description": "", "notes": "", "reason": "",
                "created_at": "2026-01-01", "updated_at": "2026-01-01", "completed_at": "2026-01-02"
            })

        client = make_client(handler)
        record = client.dsr.execute_request("t-1", "dsr-1")
        assert record.status == "completed"


class TestComplianceClient:
    def test_get_audit_trail(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert request.url.path == "/api/v1/tenants/t-1/reports/audit-trail"
            assert request.url.params["start"] == "2026-01-01"
            return ok_response({
                "tenant_id": "t-1", "period_start": "2026-01-01", "period_end": "2026-02-01",
                "total_events": 100, "events_by_type": [], "records": [], "chain_hash": "abc", "generated_at": ""
            })

        client = make_client(handler)
        report = client.compliance.get_audit_trail("t-1", start="2026-01-01")
        assert report.total_events == 100

    def test_export_audit_trail_csv(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert request.url.path == "/api/v1/tenants/t-1/reports/audit-trail/export"
            assert request.url.params["format"] == "csv"
            return httpx.Response(200, text="id,event\n1,test")

        client = make_client(handler)
        csv_data = client.compliance.export_audit_trail("t-1", format="csv")
        assert csv_data == "id,event\n1,test"

    def test_export_audit_trail_json(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert request.url.path == "/api/v1/tenants/t-1/reports/audit-trail/export"
            return ok_response({"tenant_id": "t-1", "total_events": 50})

        client = make_client(handler)
        data = client.compliance.export_audit_trail("t-1", format="json")
        assert data["tenant_id"] == "t-1"

    def test_get_data_access_report(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert request.url.path == "/api/v1/tenants/t-1/reports/data-access"
            return ok_response({
                "tenant_id": "t-1", "period_start": "", "period_end": "",
                "total_accesses": 50, "unique_actors": 5, "actor_summaries": [], "generated_at": ""
            })

        client = make_client(handler)
        report = client.compliance.get_data_access_report("t-1")
        assert report.total_accesses == 50

    def test_get_dsar_report(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert request.url.path == "/api/v1/tenants/t-1/reports/dsar"
            assert request.url.params["client_id"] == "client-1"
            return ok_response({
                "request_id": "req-1", "tenant_id": "t-1", "client_id": "client-1",
                "total_memories": 10, "memories": [], "audit_trail": [],
                "data_subject_requests": [], "generated_at": ""
            })

        client = make_client(handler)
        report = client.compliance.get_dsar_report("t-1", "client-1")
        assert report.total_memories == 10

    def test_get_retention_compliance(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert request.url.path == "/api/v1/tenants/t-1/reports/retention"
            return ok_response({
                "tenant_id": "t-1", "total_memories": 1000, "with_retention_policy": 900,
                "without_retention_policy": 100, "compliance_pct": 90.0,
                "under_legal_hold": 5, "under_retention_hold": 50, "expired_pending_sweep": 2, "generated_at": ""
            })

        client = make_client(handler)
        report = client.compliance.get_retention_compliance("t-1")
        assert report.compliance_pct == 90.0


class TestRetentionClient:
    def test_get_status(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert request.url.path == "/api/v1/tenants/t-1/retention/status"
            return ok_response({
                "tenant_id": "t-1", "retention_days": 365,
                "memories_eligible_for_sweep": 10, "last_sweep_at": "2026-01-01"
            })

        client = make_client(handler)
        status = client.retention.get_status("t-1")
        assert status.retention_days == 365
        assert status.memories_eligible_for_sweep == 10

    def test_set_policy(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert request.url.path == "/api/v1/tenants/t-1/retention/set"
            payload = json.loads(request.content)
            assert "retention_until" in payload, f"Expected retention_until in payload, got: {list(payload.keys())}"
            assert payload.get("actor") == "sdk"
            return ok_response({})

        client = make_client(handler)
        client.retention.set_policy("t-1", 365)

    def test_trigger_sweep(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert request.url.path == "/api/v1/tenants/t-1/retention/sweep"
            return ok_response({})

        client = make_client(handler)
        client.retention.trigger_sweep("t-1")
