"""Tests for SupervisorClient — alerts, rules, and status."""

import json

import httpx
import pytest

from conftest import make_client, ok_response


# ── Sample data factories ────────────────────────────────────────────────


def sample_alert(
    id: str = "alert-1",
    tenant_id: str = "tenant-1",
    severity: str = "high",
    status: str = "open",
) -> dict:
    return {
        "id": id,
        "tenant_id": tenant_id,
        "rule_id": "rule-1",
        "severity": severity,
        "title": "Anomalous write spike detected",
        "detail": "50 writes in 60s exceeds threshold of 20",
        "status": status,
        "resolved_by": None,
        "created_at": "2026-03-01T12:00:00Z",
        "updated_at": "2026-03-01T12:00:00Z",
    }


def sample_rule(
    id: str = "rule-1",
    name: str = "Write spike detector",
    rule_type: str = "anomaly_spike",
    severity: str = "high",
) -> dict:
    return {
        "id": id,
        "name": name,
        "rule_type": rule_type,
        "config": {"threshold": 20, "window_secs": 60},
        "severity": severity,
        "enabled": True,
        "created_at": "2026-03-01T12:00:00Z",
        "updated_at": "2026-03-01T12:00:00Z",
    }


def sample_status() -> dict:
    return {
        "enabled": True,
        "total_rules": 5,
        "active_rules": 4,
        "total_alerts": 12,
        "open_alerts": 3,
        "last_sweep_at": "2026-03-01T12:00:00Z",
    }


# ── Tests: Alerts ────────────────────────────────────────────────────────


class TestSupervisorAlerts:
    def test_list_alerts(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/tenant-1/supervisor/alerts" in str(request.url)
            return ok_response([sample_alert(), sample_alert(id="alert-2", severity="medium")])

        client = make_client(handler)
        alerts = client.supervisor.list_alerts("tenant-1")
        assert len(alerts) == 2
        assert alerts[0].id == "alert-1"
        assert alerts[0].severity == "high"
        assert alerts[0].title == "Anomalous write spike detected"
        assert alerts[1].id == "alert-2"
        assert alerts[1].severity == "medium"

    def test_list_alerts_with_status_filter(self):
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "status=open" in url
            return ok_response([sample_alert()])

        client = make_client(handler)
        alerts = client.supervisor.list_alerts("tenant-1", status="open")
        assert len(alerts) == 1

    def test_list_alerts_with_severity_filter(self):
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "severity=critical" in url
            return ok_response([])

        client = make_client(handler)
        alerts = client.supervisor.list_alerts("tenant-1", severity="critical")
        assert alerts == []

    def test_list_alerts_with_both_filters(self):
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "status=resolved" in url
            assert "severity=high" in url
            return ok_response([sample_alert(status="resolved")])

        client = make_client(handler)
        alerts = client.supervisor.list_alerts("tenant-1", status="resolved", severity="high")
        assert len(alerts) == 1
        assert alerts[0].status == "resolved"

    def test_list_alerts_empty(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([])

        client = make_client(handler)
        alerts = client.supervisor.list_alerts("tenant-1")
        assert alerts == []

    def test_update_alert_acknowledge(self):
        acknowledged = sample_alert(status="acknowledged")

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "PATCH"
            assert "/tenants/tenant-1/supervisor/alerts/alert-1" in str(request.url)
            body = json.loads(request.content)
            assert body["status"] == "acknowledged"
            assert "resolved_by" not in body
            return ok_response(acknowledged)

        client = make_client(handler)
        alert = client.supervisor.update_alert("tenant-1", "alert-1", status="acknowledged")
        assert alert.status == "acknowledged"

    def test_update_alert_resolve(self):
        resolved = sample_alert(status="resolved")
        resolved["resolved_by"] = "admin@acme.com"

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["status"] == "resolved"
            assert body["resolved_by"] == "admin@acme.com"
            return ok_response(resolved)

        client = make_client(handler)
        alert = client.supervisor.update_alert(
            "tenant-1", "alert-1", status="resolved", resolved_by="admin@acme.com"
        )
        assert alert.status == "resolved"
        assert alert.resolved_by == "admin@acme.com"


# ── Tests: Rules ─────────────────────────────────────────────────────────


class TestSupervisorRules:
    def test_list_rules(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/supervisor/rules" in str(request.url)
            return ok_response([sample_rule(), sample_rule(id="rule-2", name="Sensitivity breach")])

        client = make_client(handler)
        rules = client.supervisor.list_rules()
        assert len(rules) == 2
        assert rules[0].id == "rule-1"
        assert rules[0].name == "Write spike detector"
        assert rules[0].config == {"threshold": 20, "window_secs": 60}
        assert rules[1].id == "rule-2"

    def test_list_rules_empty(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([])

        client = make_client(handler)
        rules = client.supervisor.list_rules()
        assert rules == []

    def test_create_rule(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/supervisor/rules" in str(request.url)
            body = json.loads(request.content)
            assert body["name"] == "Write spike detector"
            assert body["rule_type"] == "anomaly_spike"
            assert body["config"] == {"threshold": 20, "window_secs": 60}
            assert body["severity"] == "high"
            return ok_response(sample_rule())

        client = make_client(handler)
        rule = client.supervisor.create_rule(
            name="Write spike detector",
            rule_type="anomaly_spike",
            config={"threshold": 20, "window_secs": 60},
            severity="high",
        )
        assert rule.id == "rule-1"
        assert rule.name == "Write spike detector"
        assert rule.rule_type == "anomaly_spike"
        assert rule.severity == "high"
        assert rule.enabled is True

    def test_create_rule_default_severity(self):
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["severity"] == "medium"
            result = sample_rule(severity="medium")
            return ok_response(result)

        client = make_client(handler)
        rule = client.supervisor.create_rule(
            name="Low priority rule",
            rule_type="info_check",
            config={},
        )
        assert rule.severity == "medium"

    def test_update_rule(self):
        updated = sample_rule()
        updated["name"] = "Updated rule"
        updated["enabled"] = False

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "PATCH"
            assert "/supervisor/rules/rule-1" in str(request.url)
            body = json.loads(request.content)
            assert body["name"] == "Updated rule"
            assert body["enabled"] is False
            assert "rule_type" not in body
            return ok_response(updated)

        client = make_client(handler)
        rule = client.supervisor.update_rule("rule-1", name="Updated rule", enabled=False)
        assert rule.name == "Updated rule"
        assert rule.enabled is False

    def test_update_rule_config(self):
        updated = sample_rule()
        updated["config"] = {"threshold": 50, "window_secs": 120}

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["config"] == {"threshold": 50, "window_secs": 120}
            return ok_response(updated)

        client = make_client(handler)
        rule = client.supervisor.update_rule(
            "rule-1", config={"threshold": 50, "window_secs": 120}
        )
        assert rule.config["threshold"] == 50

    def test_delete_rule(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "DELETE"
            assert "/supervisor/rules/rule-1" in str(request.url)
            return ok_response(None)

        client = make_client(handler)
        # Should not raise
        client.supervisor.delete_rule("rule-1")


# ── Tests: Status ────────────────────────────────────────────────────────


class TestSupervisorStatus:
    def test_status(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/supervisor/status" in str(request.url)
            return ok_response(sample_status())

        client = make_client(handler)
        status = client.supervisor.status()
        assert status.enabled is True
        assert status.total_rules == 5
        assert status.active_rules == 4
        assert status.total_alerts == 12
        assert status.open_alerts == 3
        assert status.last_sweep_at == "2026-03-01T12:00:00Z"

    def test_status_disabled(self):
        data = {
            "enabled": False,
            "total_rules": 0,
            "active_rules": 0,
            "total_alerts": 0,
            "open_alerts": 0,
            "last_sweep_at": None,
        }

        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(data)

        client = make_client(handler)
        status = client.supervisor.status()
        assert status.enabled is False
        assert status.total_rules == 0
        assert status.last_sweep_at is None
