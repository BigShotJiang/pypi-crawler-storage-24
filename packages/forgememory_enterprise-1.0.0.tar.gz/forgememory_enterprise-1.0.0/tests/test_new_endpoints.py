"""Tests for Week 1 + Week 2 new endpoints.

Covers:
- Key rotation (POST /api/v1/api-keys/{id}/rotate)
- Liveness probe (GET /health/live)
- Readiness probe (GET /health/ready)
- Thread operations (GET + POST /api/v1/tenants/{tid}/threads/...)
- DSR lifecycle (create, list, get, approve, reject)
- Compliance posture and evidence
- Idempotency-Key header support
- Rate limit header parsing
- Intelligent 429 backoff + retry
"""

from __future__ import annotations

import json
import time

import httpx
import pytest

from conftest import (
    error_response,
    make_client,
    ok_response,
    sample_api_key_created,
    sample_memory,
    sample_tenant,
)
from forgememory_enterprise import (
    NotFoundError,
    RateLimitedError,
)
from forgememory_enterprise.types import (
    ApiKeyRotated,
    ComplianceEvidence,
    CompliancePosture,
    DsrRecord,
    LivenessResponse,
    ReadinessResponse,
    ThreadMemories,
)
from forgememory_enterprise._http import RateLimitState


# ── Sample data factories ──────────────────────────────────────────────────


def sample_api_key_rotated(key_id: str = "key-1", org_id: str = "org-1") -> dict:
    return {
        "new_key": "fme_new_raw_xyz789",
        "new_key_id": key_id,
        "old_key_expires_at": "2026-02-25T00:00:00Z",
        "old_key_id": "key-1-old",
    }


def sample_dsr(
    id: str = "dsr-1",
    tenant_id: str = "tenant-1",
    status: str = "pending",
    request_type: str = "erasure",
) -> dict:
    return {
        "id": id,
        "tenant_id": tenant_id,
        "subject_email": "alice@example.com",
        "request_type": request_type,
        "status": status,
        "description": "User requested data erasure",
        "notes": "",
        "reason": "",
        "created_at": "2026-02-20T00:00:00Z",
        "updated_at": "2026-02-20T00:00:00Z",
        "completed_at": None,
    }


def sample_thread_memories() -> dict:
    return {
        "thread_id": "thread-abc",
        "memories": [sample_memory(), sample_memory(id="mem-2", content="Second")],
        "total": 2,
    }


def sample_compliance_posture() -> dict:
    return {
        "overall_status": "pass",
        "frameworks": [
            {
                "framework": "gdpr",
                "status": "pass",
                "controls_passed": 12,
                "controls_failed": 0,
                "controls_warned": 1,
                "last_assessed_at": "2026-02-20T00:00:00Z",
            },
            {
                "framework": "hipaa",
                "status": "warn",
                "controls_passed": 8,
                "controls_failed": 0,
                "controls_warned": 2,
                "last_assessed_at": "2026-02-20T00:00:00Z",
            },
        ],
        "generated_at": "2026-02-20T00:00:00Z",
    }


def sample_compliance_evidence() -> dict:
    return {
        "records": [
            {
                "id": "ev-1",
                "evidence_type": "audit_log",
                "framework": "gdpr",
                "tenant_id": "tenant-1",
                "description": "Memory access logged",
                "recorded_at": "2026-02-20T00:00:00Z",
                "metadata": {},
            }
        ],
        "total": 1,
        "framework": "gdpr",
        "generated_at": "2026-02-20T00:00:00Z",
    }


# ── Key Rotation Tests ─────────────────────────────────────────────────────


class TestKeyRotation:
    def test_rotate_returns_new_key(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/api-keys/key-1/rotate" in str(request.url)
            return ok_response(sample_api_key_rotated())

        client = make_client(handler)
        result = client.api_keys.rotate("key-1")
        assert isinstance(result, ApiKeyRotated)
        assert result.new_key_id == "key-1"
        assert result.new_key == "fme_new_raw_xyz789"
        assert result.old_key_expires_at == "2026-02-25T00:00:00Z"

    def test_rotate_with_grace_period(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_body.update(json.loads(request.content))
            return ok_response(sample_api_key_rotated())

        client = make_client(handler)
        client.api_keys.rotate("key-1", grace_period_secs=600)
        assert received_body.get("grace_period_secs") == 600

    def test_rotate_with_idempotency_key(self):
        received_headers = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_headers.update(dict(request.headers))
            return ok_response(sample_api_key_rotated())

        client = make_client(handler)
        client.api_keys.rotate("key-1", idempotency_key="idem-rotate-key-1")
        assert received_headers.get("idempotency-key") == "idem-rotate-key-1"

    def test_rotate_not_found(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("API key not found", 404)

        client = make_client(handler)
        with pytest.raises(NotFoundError):
            client.api_keys.rotate("nonexistent-key")


# ── Health Probe Tests ─────────────────────────────────────────────────────


class TestHealthProbes:
    def test_liveness(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/health/live" in str(request.url)
            return ok_response({"alive": True, "status": "ok"})

        client = make_client(handler)
        result = client.admin.liveness()
        assert isinstance(result, LivenessResponse)
        assert result.alive is True
        assert result.status == "ok"

    def test_readiness_all_ok(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert "/health/ready" in str(request.url)
            return ok_response({
                "ready": True,
                "status": "ok",
                "components": [
                    {"name": "database", "status": "ok", "detail": ""},
                    {"name": "vector_store", "status": "ok", "detail": ""},
                ],
            })

        client = make_client(handler)
        result = client.admin.readiness()
        assert isinstance(result, ReadinessResponse)
        assert result.ready is True
        assert len(result.components) == 2
        assert result.components[0].name == "database"
        assert result.components[0].status == "ok"

    def test_readiness_degraded(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response({
                "ready": False,
                "status": "degraded",
                "components": [
                    {"name": "database", "status": "ok", "detail": ""},
                    {"name": "vector_store", "status": "unavailable", "detail": "LanceDB index missing"},
                ],
            })

        client = make_client(handler)
        result = client.admin.readiness()
        assert result.ready is False
        assert result.status == "degraded"
        degraded = [c for c in result.components if c.status != "ok"]
        assert len(degraded) == 1
        assert degraded[0].name == "vector_store"


# ── Thread Operation Tests ─────────────────────────────────────────────────


class TestThreadOperations:
    def test_get_thread(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/tenant-1/threads/thread-abc" in str(request.url)
            return ok_response(sample_thread_memories())

        client = make_client(handler)
        result = client.tenants.get_thread("tenant-1", "thread-abc")
        assert isinstance(result, ThreadMemories)
        assert result.thread_id == "thread-abc"
        assert len(result.memories) == 2
        assert result.total == 2

    def test_get_thread_not_found(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("Thread not found", 404)

        client = make_client(handler)
        with pytest.raises(NotFoundError):
            client.tenants.get_thread("tenant-1", "nonexistent-thread")

    def test_link_memories_to_thread(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/tenants/tenant-1/threads" in str(request.url)
            received_body.update(json.loads(request.content))
            return ok_response("Memories linked to thread")

        client = make_client(handler)
        result = client.tenants.link_memories_to_thread(
            "tenant-1", "thread-abc", ["mem-1", "mem-2", "mem-3"]
        )
        assert result == "Memories linked to thread"
        assert received_body["thread_id"] == "thread-abc"
        assert received_body["memory_ids"] == ["mem-1", "mem-2", "mem-3"]

    def test_link_memories_with_idempotency_key(self):
        received_headers = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_headers.update(dict(request.headers))
            return ok_response("Memories linked to thread")

        client = make_client(handler)
        client.tenants.link_memories_to_thread(
            "tenant-1", "thread-abc", ["mem-1"],
            idempotency_key="idem-link-thread-1",
        )
        assert received_headers.get("idempotency-key") == "idem-link-thread-1"


# ── DSR Lifecycle Tests ────────────────────────────────────────────────────


class TestDsrLifecycle:
    def test_create_dsr(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/tenants/tenant-1/dsr/request" in str(request.url)
            received_body.update(json.loads(request.content))
            return ok_response(sample_dsr())

        client = make_client(handler)
        result = client.tenants.create_dsr(
            "tenant-1",
            subject_email="alice@example.com",
            request_type="erasure",
            description="User requested data erasure",
        )
        assert isinstance(result, DsrRecord)
        assert result.id == "dsr-1"
        assert result.status == "pending"
        assert result.subject_email == "alice@example.com"
        assert received_body["request_type"] == "erasure"

    def test_create_dsr_with_idempotency_key(self):
        received_headers = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_headers.update(dict(request.headers))
            return ok_response(sample_dsr())

        client = make_client(handler)
        client.tenants.create_dsr(
            "tenant-1", "alice@example.com", "erasure",
            idempotency_key="idem-dsr-alice-erasure",
        )
        assert received_headers.get("idempotency-key") == "idem-dsr-alice-erasure"

    def test_list_dsrs(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/tenant-1/dsr" in str(request.url)
            return ok_response([sample_dsr(), sample_dsr(id="dsr-2", status="approved")])

        client = make_client(handler)
        results = client.tenants.list_dsrs("tenant-1")
        assert len(results) == 2
        assert results[0].id == "dsr-1"
        assert results[1].status == "approved"

    def test_get_dsr(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/tenants/tenant-1/dsr/dsr-1" in str(request.url)
            return ok_response(sample_dsr())

        client = make_client(handler)
        result = client.tenants.get_dsr("tenant-1", "dsr-1")
        assert result.id == "dsr-1"
        assert result.request_type == "erasure"

    def test_get_dsr_not_found(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("DSR not found", 404)

        client = make_client(handler)
        with pytest.raises(NotFoundError):
            client.tenants.get_dsr("tenant-1", "nonexistent-dsr")

    def test_approve_dsr(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/dsr/dsr-1/approve" in str(request.url)
            received_body.update(json.loads(request.content))
            return ok_response(sample_dsr(status="approved"))

        client = make_client(handler)
        result = client.tenants.approve_dsr(
            "tenant-1", "dsr-1", notes="Verified identity, proceeding with erasure."
        )
        assert result.status == "approved"
        assert received_body.get("notes") == "Verified identity, proceeding with erasure."

    def test_reject_dsr(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/dsr/dsr-1/reject" in str(request.url)
            received_body.update(json.loads(request.content))
            return ok_response(sample_dsr(status="rejected"))

        client = make_client(handler)
        result = client.tenants.reject_dsr(
            "tenant-1", "dsr-1", reason="Unable to verify identity."
        )
        assert result.status == "rejected"
        assert received_body.get("reason") == "Unable to verify identity."

    def test_approve_dsr_with_idempotency_key(self):
        received_headers = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_headers.update(dict(request.headers))
            return ok_response(sample_dsr(status="approved"))

        client = make_client(handler)
        client.tenants.approve_dsr("tenant-1", "dsr-1", idempotency_key="idem-approve-dsr-1")
        assert received_headers.get("idempotency-key") == "idem-approve-dsr-1"


# ── Compliance Tests ───────────────────────────────────────────────────────


class TestCompliance:
    def test_compliance_posture(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/api/v1/admin/compliance-posture" in str(request.url)
            return ok_response(sample_compliance_posture())

        client = make_client(handler)
        result = client.admin.compliance_posture()
        assert isinstance(result, CompliancePosture)
        assert result.overall_status == "pass"
        assert len(result.frameworks) == 2
        gdpr = next(f for f in result.frameworks if f.framework == "gdpr")
        assert gdpr.status == "pass"
        assert gdpr.controls_passed == 12

    def test_compliance_evidence_no_filter(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert "/api/v1/admin/compliance-evidence" in str(request.url)
            return ok_response(sample_compliance_evidence())

        client = make_client(handler)
        result = client.admin.compliance_evidence()
        assert isinstance(result, ComplianceEvidence)
        assert result.total == 1
        assert len(result.records) == 1
        assert result.records[0].evidence_type == "audit_log"

    def test_compliance_evidence_with_framework_filter(self):
        received_url = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_url["url"] = str(request.url)
            return ok_response(sample_compliance_evidence())

        client = make_client(handler)
        client.admin.compliance_evidence(framework="gdpr", tenant_id="tenant-1")
        assert "framework=gdpr" in received_url["url"]
        assert "tenant_id=tenant-1" in received_url["url"]


# ── Rate Limit and Idempotency Tests ──────────────────────────────────────


class TestRateLimitAndIdempotency:
    def test_rate_limit_state_parsing(self):
        """RateLimitState updates correctly from response headers."""
        state = RateLimitState()
        response = httpx.Response(
            200,
            text=json.dumps({"success": True, "data": "ok", "error": None}),
            headers={
                "content-type": "application/json",
                "X-RateLimit-Remaining": "42",
                "Retry-After": "5",
            },
        )
        state.update(response)
        assert state.remaining == 42
        assert state.retry_after == 5

    def test_rate_limit_state_ignores_missing_headers(self):
        """RateLimitState stays None when headers are absent."""
        state = RateLimitState()
        response = httpx.Response(
            200,
            text=json.dumps({"success": True, "data": "ok", "error": None}),
            headers={"content-type": "application/json"},
        )
        state.update(response)
        assert state.remaining is None
        assert state.retry_after is None

    def test_idempotency_key_sent_on_post(self):
        """Idempotency-Key header is included on POST mutating requests."""
        received_headers = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_headers.update(dict(request.headers))
            return ok_response("Tenant suspended")

        client = make_client(handler)
        client.tenants.suspend_tenant("tenant-1", idempotency_key="idem-suspend-t1")
        assert received_headers.get("idempotency-key") == "idem-suspend-t1"

    def test_idempotency_key_sent_on_delete(self):
        """Idempotency-Key header is included on DELETE requests."""
        received_headers = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_headers.update(dict(request.headers))
            return ok_response("Tenant deleted")

        client = make_client(handler)
        client.tenants.delete_tenant("tenant-1", idempotency_key="idem-delete-t1")
        assert received_headers.get("idempotency-key") == "idem-delete-t1"

    def test_429_raises_rate_limited_error_after_retry(self):
        """When retry also returns 429, RateLimitedError is raised."""
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            return httpx.Response(
                429,
                text=json.dumps({"success": False, "data": None, "error": "Too many requests"}),
                headers={
                    "content-type": "application/json",
                    "Retry-After": "0",  # 0-second sleep so test is fast
                },
            )

        client = make_client(handler)
        with pytest.raises(RateLimitedError):
            client.api_keys.rotate("key-1")
        # request_with_retry makes the initial call + MAX_RETRIES (3) retries = 4 total
        assert call_count["n"] == 4

    def test_429_retries_once_and_succeeds(self):
        """When retry succeeds after 429, the result is returned normally."""
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            if call_count["n"] == 1:
                return httpx.Response(
                    429,
                    text=json.dumps({"success": False, "data": None, "error": "Too many requests"}),
                    headers={
                        "content-type": "application/json",
                        "Retry-After": "0",
                    },
                )
            # Second call succeeds
            return ok_response(sample_api_key_rotated())

        client = make_client(handler)
        result = client.api_keys.rotate("key-1")
        assert call_count["n"] == 2
        assert result.new_key == "fme_new_raw_xyz789"
