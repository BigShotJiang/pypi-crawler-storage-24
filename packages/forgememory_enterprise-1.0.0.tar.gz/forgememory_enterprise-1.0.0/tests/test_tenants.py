"""Tests for TenantManager."""

import httpx
import pytest

from conftest import error_response, make_client, ok_response, sample_tenant
from forgememory_enterprise import ForbiddenError, NotFoundError


class TestTenantManager:
    def test_list_tenants(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_tenant(), sample_tenant(id="tenant-2")])

        client = make_client(handler)
        tenants = client.tenants.list_tenants()
        assert len(tenants) == 2

    def test_list_tenants_by_org(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert "org_id=org-1" in str(request.url)
            return ok_response([sample_tenant()])

        client = make_client(handler)
        tenants = client.tenants.list_tenants(org_id="org-1")
        assert len(tenants) == 1

    def test_get_tenant(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_tenant())

        client = make_client(handler)
        tenant = client.tenants.get_tenant("tenant-1")
        assert tenant.id == "tenant-1"

    def test_get_tenant_not_found(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("Tenant not found", 404)

        client = make_client(handler)
        with pytest.raises(NotFoundError):
            client.tenants.get_tenant("nonexistent")

    def test_suspend_tenant(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/suspend" in str(request.url)
            return ok_response("Tenant suspended")

        client = make_client(handler)
        result = client.tenants.suspend_tenant("tenant-1")
        assert result == "Tenant suspended"

    def test_reactivate_tenant(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response("Tenant reactivated")

        client = make_client(handler)
        result = client.tenants.reactivate_tenant("tenant-1")
        assert result == "Tenant reactivated"

    def test_delete_tenant(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "DELETE"
            return ok_response("Tenant deleted")

        client = make_client(handler)
        result = client.tenants.delete_tenant("tenant-1")
        assert result == "Tenant deleted"

    def test_set_quota(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response("Quota set")

        client = make_client(handler)
        result = client.tenants.set_quota("tenant-1", max_memories=1000)
        assert result == "Quota set"

    def test_suspend_forbidden(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("Insufficient permissions", 403)

        client = make_client(handler)
        with pytest.raises(ForbiddenError):
            client.tenants.suspend_tenant("tenant-1")
