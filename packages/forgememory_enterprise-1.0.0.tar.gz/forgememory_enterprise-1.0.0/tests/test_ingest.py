"""Tests for IngestClient — Data Ingestion Pipeline SDK."""

from __future__ import annotations

import json

import httpx
import pytest

from conftest import error_response, make_client, ok_response
from forgememory_enterprise.exceptions import EnterpriseError
from forgememory_enterprise.types import (
    CalendarEventRequest,
    CallTranscriptRequest,
    ChannelInfo,
    CrmEventRequest,
    DocumentIngestRequest,
    EmailIngestRequest,
    IngestResponse,
    MeetingNoteRequest,
    PlanningSessionRequest,
)


# ── Sample data helpers ────────────────────────────────────────────────────


def sample_ingest_response(channel: str = "crm_sync", count: int = 1) -> dict:
    return {
        "memories_created": count,
        "memory_ids": [f"mem-{i}" for i in range(count)],
        "channel": channel,
    }


def sample_channel_info(channel: str = "crm_sync") -> dict:
    return {
        "channel": channel,
        "default_importance": 7,
        "default_memory_type": "semantic",
    }


ALL_CHANNELS = [
    "crm_sync",
    "email_intelligence",
    "call_transcript",
    "calendar_context",
    "planning_session",
    "meeting_notes",
    "document_processing",
]


# ── TestIngestRaw ──────────────────────────────────────────────────────────


class TestIngestRaw:
    def test_ingest_crm_raw(self):
        """POST to /ingest/crm_sync with a raw dict payload."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = json.loads(request.content)
            return ok_response(sample_ingest_response("crm_sync", 2))

        client = make_client(handler)
        payload = {"record_id": "lead-42", "event_type": "created", "summary": "New lead"}
        result = client.ingest.ingest("tenant-1", "crm_sync", payload)

        assert "/api/v1/tenants/tenant-1/ingest/crm_sync" in captured["url"]
        assert captured["body"]["record_id"] == "lead-42"
        assert isinstance(result, IngestResponse)
        assert result.memories_created == 2
        assert result.channel == "crm_sync"
        assert result.memory_ids == ["mem-0", "mem-1"]

    def test_ingest_email_raw(self):
        """POST to /ingest/email_intelligence with a raw dict payload."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return ok_response(sample_ingest_response("email_intelligence"))

        client = make_client(handler)
        payload = {
            "message_id": "msg-99",
            "from": "sender@example.com",
            "to": ["recipient@example.com"],
            "subject": "Q1 Review",
            "body": "Please review the attached report.",
        }
        result = client.ingest.ingest("tenant-1", "email_intelligence", payload)

        assert "/api/v1/tenants/tenant-1/ingest/email_intelligence" in captured["url"]
        assert isinstance(result, IngestResponse)
        assert result.channel == "email_intelligence"

    def test_ingest_invalid_channel(self):
        """Server returns 400 for an unknown channel; raises EnterpriseError."""
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("unknown channel: bad_channel", 400)

        client = make_client(handler)
        with pytest.raises(EnterpriseError, match="unknown channel"):
            client.ingest.ingest("tenant-1", "bad_channel", {})


# ── TestIngestTyped ────────────────────────────────────────────────────────


class TestIngestTyped:
    def test_ingest_typed_crm(self):
        """Auto-detects crm_sync channel from CrmEventRequest."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return ok_response(sample_ingest_response("crm_sync"))

        client = make_client(handler)
        req = CrmEventRequest(
            record_id="acct-1",
            event_type="updated",
            summary="Account status changed to active",
        )
        result = client.ingest.ingest_typed("tenant-1", req)

        assert "/ingest/crm_sync" in captured["url"]
        assert isinstance(result, IngestResponse)
        assert result.channel == "crm_sync"

    def test_ingest_typed_email(self):
        """Auto-detects email_intelligence channel from EmailIngestRequest."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = json.loads(request.content)
            return ok_response(sample_ingest_response("email_intelligence"))

        client = make_client(handler)
        req = EmailIngestRequest(
            message_id="msg-1",
            **{"from": "alice@example.com"},
            to=["bob@example.com"],
            subject="Hello",
            body="Hi there",
        )
        result = client.ingest.ingest_typed("tenant-1", req)

        assert "/ingest/email_intelligence" in captured["url"]
        # by_alias=True means the field is serialized as "from" not "from_addr"
        assert captured["body"].get("from") == "alice@example.com"
        assert isinstance(result, IngestResponse)

    def test_ingest_typed_call(self):
        """Auto-detects call_transcript channel from CallTranscriptRequest."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return ok_response(sample_ingest_response("call_transcript"))

        client = make_client(handler)
        req = CallTranscriptRequest(
            call_id="call-77",
            caller="Alice",
            callee="Bob",
            duration_secs=300,
            transcript="Alice: Hello. Bob: Hi.",
        )
        result = client.ingest.ingest_typed("tenant-1", req)

        assert "/ingest/call_transcript" in captured["url"]
        assert isinstance(result, IngestResponse)

    def test_ingest_typed_calendar(self):
        """Auto-detects calendar_context channel from CalendarEventRequest."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return ok_response(sample_ingest_response("calendar_context"))

        client = make_client(handler)
        req = CalendarEventRequest(
            event_id="evt-1",
            title="Strategy Meeting",
            start_time="2026-03-01T09:00:00Z",
            end_time="2026-03-01T10:00:00Z",
        )
        result = client.ingest.ingest_typed("tenant-1", req)

        assert "/ingest/calendar_context" in captured["url"]
        assert isinstance(result, IngestResponse)

    def test_ingest_typed_planning(self):
        """Auto-detects planning_session channel from PlanningSessionRequest."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return ok_response(sample_ingest_response("planning_session"))

        client = make_client(handler)
        req = PlanningSessionRequest(
            session_id="plan-5",
            advisor="Jane Smith",
            notes="Client wants conservative allocation.",
            goals=["retirement by 60"],
            action_items=["rebalance portfolio"],
        )
        result = client.ingest.ingest_typed("tenant-1", req)

        assert "/ingest/planning_session" in captured["url"]
        assert isinstance(result, IngestResponse)

    def test_ingest_typed_meeting(self):
        """Auto-detects meeting_notes channel from MeetingNoteRequest."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return ok_response(sample_ingest_response("meeting_notes"))

        client = make_client(handler)
        req = MeetingNoteRequest(
            content="Discussed Q1 budget. Action: prepare slide deck by Friday.",
            entities=["Alice", "Bob"],
        )
        result = client.ingest.ingest_typed("tenant-1", req)

        assert "/ingest/meeting_notes" in captured["url"]
        assert isinstance(result, IngestResponse)

    def test_ingest_typed_document(self):
        """Auto-detects document_processing channel from DocumentIngestRequest."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return ok_response(sample_ingest_response("document_processing"))

        client = make_client(handler)
        req = DocumentIngestRequest(
            document_id="doc-100",
            title="Annual Report 2025",
            document_type="pdf",
            content="This document summarizes our 2025 fiscal year performance.",
        )
        result = client.ingest.ingest_typed("tenant-1", req)

        assert "/ingest/document_processing" in captured["url"]
        assert isinstance(result, IngestResponse)

    def test_ingest_typed_unknown(self):
        """Raises ValueError for an unrecognized request type."""
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            return ok_response({})

        client = make_client(handler)

        class UnknownRequest:
            pass

        with pytest.raises(ValueError, match="Unknown ingest request type"):
            client.ingest.ingest_typed("tenant-1", UnknownRequest())  # type: ignore[arg-type]


# ── TestIngestConvenience ──────────────────────────────────────────────────


class TestIngestConvenience:
    def test_ingest_crm_method(self):
        """ingest_crm convenience method posts to crm_sync."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = json.loads(request.content)
            return ok_response(sample_ingest_response("crm_sync"))

        client = make_client(handler)
        req = CrmEventRequest(
            record_id="contact-5",
            event_type="deleted",
            summary="Contact removed from CRM",
            field_changes={"status": "deleted"},
            related_contacts=["mgr-1"],
        )
        result = client.ingest.ingest_crm("tenant-1", req)

        assert "/ingest/crm_sync" in captured["url"]
        assert captured["body"]["record_id"] == "contact-5"
        assert captured["body"]["field_changes"] == {"status": "deleted"}
        assert isinstance(result, IngestResponse)

    def test_ingest_email_method(self):
        """ingest_email convenience method posts to email_intelligence with alias."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = json.loads(request.content)
            return ok_response(sample_ingest_response("email_intelligence"))

        client = make_client(handler)
        req = EmailIngestRequest(
            message_id="msg-42",
            **{"from": "advisor@firm.com"},
            to=["client@example.com"],
            subject="Portfolio Update",
            body="Your Q1 allocation is attached.",
            related_contacts=["client-1"],
        )
        result = client.ingest.ingest_email("tenant-1", req)

        assert "/ingest/email_intelligence" in captured["url"]
        # by_alias=True means "from" not "from_addr" in the JSON body
        assert captured["body"].get("from") == "advisor@firm.com"
        assert captured["body"]["subject"] == "Portfolio Update"
        assert isinstance(result, IngestResponse)


# ── TestListChannels ───────────────────────────────────────────────────────


class TestListChannels:
    def test_list_channels(self):
        """Returns a list of ChannelInfo objects."""
        channels_data = [sample_channel_info(ch) for ch in ALL_CHANNELS[:3]]

        def handler(request: httpx.Request) -> httpx.Response:
            assert "/api/v1/tenants/tenant-1/ingest" in str(request.url)
            return ok_response(channels_data)

        client = make_client(handler)
        result = client.ingest.list_channels("tenant-1")

        assert len(result) == 3
        for item in result:
            assert isinstance(item, ChannelInfo)
        assert result[0].channel == "crm_sync"
        assert result[0].default_importance == 7
        assert result[0].default_memory_type == "semantic"

    def test_list_channels_all_seven(self):
        """All 7 channels are returned when server reports them all."""
        channels_data = [sample_channel_info(ch) for ch in ALL_CHANNELS]

        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(channels_data)

        client = make_client(handler)
        result = client.ingest.list_channels("tenant-1")

        assert len(result) == 7
        returned_channels = {item.channel for item in result}
        assert returned_channels == set(ALL_CHANNELS)


# ── TestIngestModels ───────────────────────────────────────────────────────


class TestIngestModels:
    def test_ingest_response_defaults(self):
        """IngestResponse has sensible defaults when all fields are omitted."""
        resp = IngestResponse()
        assert resp.memories_created == 0
        assert resp.memory_ids == []
        assert resp.channel == ""

    def test_channel_info_defaults(self):
        """ChannelInfo uses default_importance=5 when not provided."""
        info = ChannelInfo(channel="crm_sync")
        assert info.default_importance == 5
        assert info.default_memory_type == "semantic"

    def test_crm_request_defaults(self):
        """CrmEventRequest field_changes and related_contacts default to empty."""
        req = CrmEventRequest(record_id="r1", event_type="created", summary="New record")
        assert req.field_changes == {}
        assert req.related_contacts == []

    def test_email_request_alias(self):
        """EmailIngestRequest 'from' alias works via model_config populate_by_name."""
        # Construct via alias ("from")
        req = EmailIngestRequest(
            message_id="m1",
            **{"from": "sender@x.com"},
            to=["r@x.com"],
            subject="Hi",
            body="Hello",
        )
        assert req.from_addr == "sender@x.com"

        # Construct via field name ("from_addr")
        req2 = EmailIngestRequest(
            message_id="m2",
            from_addr="sender2@x.com",
            to=["r2@x.com"],
            subject="Hi2",
            body="Hello2",
        )
        assert req2.from_addr == "sender2@x.com"

        # Serialized with alias
        dumped = req.model_dump(by_alias=True)
        assert "from" in dumped
        assert dumped["from"] == "sender@x.com"

    def test_meeting_note_defaults(self):
        """MeetingNoteRequest entities defaults to empty list."""
        req = MeetingNoteRequest(content="Discussed budget.")
        assert req.entities == []

    def test_planning_session_risk_tolerance_optional(self):
        """PlanningSessionRequest risk_tolerance is optional (None by default)."""
        req = PlanningSessionRequest(
            session_id="s1",
            advisor="Jane",
            notes="Moderate risk appetite.",
        )
        assert req.risk_tolerance is None
        assert req.goals == []
        assert req.action_items == []
        assert req.clients == []

    def test_call_transcript_related_contacts_default(self):
        """CallTranscriptRequest related_contacts defaults to empty list."""
        req = CallTranscriptRequest(
            call_id="c1",
            caller="Alice",
            callee="Bob",
            duration_secs=120,
            transcript="...",
        )
        assert req.related_contacts == []

    def test_calendar_event_optional_fields(self):
        """CalendarEventRequest description and location default to empty strings."""
        req = CalendarEventRequest(
            event_id="e1",
            title="Team Sync",
            start_time="2026-03-01T09:00:00Z",
            end_time="2026-03-01T09:30:00Z",
        )
        assert req.description == ""
        assert req.location == ""
        assert req.attendees == []

    def test_document_ingest_related_contacts_default(self):
        """DocumentIngestRequest related_contacts defaults to empty list."""
        req = DocumentIngestRequest(
            document_id="d1",
            title="Prospectus",
            document_type="pdf",
            content="Full document text here.",
        )
        assert req.related_contacts == []
