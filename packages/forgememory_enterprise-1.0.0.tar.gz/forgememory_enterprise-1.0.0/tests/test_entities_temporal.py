"""Tests for temporal Knowledge Graph SDK methods — update_edge, as_of, include_superseded, force."""

import json

import httpx
import pytest

from conftest import error_response, make_client, ok_response
from forgememory_enterprise.types import (
    CreateEdgeRequest,
    EntityNode,
    GraphEdge,
    TraversalResult,
    UpdateEdgeRequest,
)


# ── Sample data factories ────────────────────────────────────────────────


def sample_edge(
    id: str = "edge-1",
    source_id: str = "Martinez Family",
    target_id: str = "Johnson Corp",
    relationship: str = "member_of",
    weight: float = 1.0,
    memory_id: str | None = None,
    valid_from: str | None = "2026-01-01T00:00:00Z",
    valid_to: str | None = None,
    recorded_at: str | None = "2026-01-01T00:00:00Z",
) -> dict:
    return {
        "id": id,
        "source_id": source_id,
        "target_id": target_id,
        "relationship": relationship,
        "weight": weight,
        "memory_id": memory_id,
        "valid_from": valid_from,
        "valid_to": valid_to,
        "recorded_at": recorded_at,
        "created_at": "2026-01-01T00:00:00Z",
    }


def sample_traversal(
    root: str = "Martinez Family",
    nodes: list | None = None,
    edges: list | None = None,
) -> dict:
    return {
        "root": root,
        "nodes": nodes or [],
        "edges": edges or [],
    }


# ── update_edge Tests ────────────────────────────────────────────────────


class TestUpdateEdge:
    def test_update_edge_valid_to(self):
        """PATCH /edges/{edge_id} with valid_to closes the edge."""
        updated = sample_edge(valid_to="2026-06-01T00:00:00Z")

        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "PATCH"
            assert "/edges/edge-1" in str(request.url)
            body = json.loads(request.content)
            assert body["valid_to"] == "2026-06-01T00:00:00Z"
            assert "weight" not in body
            return ok_response(updated)

        client = make_client(handler)
        req = UpdateEdgeRequest(valid_to="2026-06-01T00:00:00Z")
        edge = client.entities.update_edge("tenant-1", "edge-1", req)
        assert isinstance(edge, GraphEdge)
        assert edge.valid_to == "2026-06-01T00:00:00Z"
        assert edge.id == "edge-1"

    def test_update_edge_weight(self):
        """PATCH /edges/{edge_id} with weight adjusts the edge weight."""
        updated = sample_edge(weight=0.5)

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["weight"] == 0.5
            assert "valid_to" not in body
            return ok_response(updated)

        client = make_client(handler)
        req = UpdateEdgeRequest(weight=0.5)
        edge = client.entities.update_edge("tenant-1", "edge-1", req)
        assert edge.weight == 0.5

    def test_update_edge_both_fields(self):
        """PATCH /edges/{edge_id} with both valid_to and weight."""
        updated = sample_edge(valid_to="2026-06-01T00:00:00Z", weight=0.3)

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["valid_to"] == "2026-06-01T00:00:00Z"
            assert body["weight"] == 0.3
            return ok_response(updated)

        client = make_client(handler)
        req = UpdateEdgeRequest(valid_to="2026-06-01T00:00:00Z", weight=0.3)
        edge = client.entities.update_edge("tenant-1", "edge-1", req)
        assert edge.valid_to == "2026-06-01T00:00:00Z"
        assert edge.weight == 0.3

    def test_update_edge_strips_none_fields(self):
        """None fields should not appear in the PATCH payload."""
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            # Both fields are None, so payload should be empty
            assert "valid_to" not in body
            assert "weight" not in body
            return ok_response(sample_edge())

        client = make_client(handler)
        req = UpdateEdgeRequest()
        client.entities.update_edge("tenant-1", "edge-1", req)

    def test_update_edge_url_format(self):
        """Verify the PATCH URL is /api/v1/tenants/{tid}/edges/{edge_id}."""
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "/api/v1/tenants/tenant-1/edges/edge-42" in url
            assert request.method == "PATCH"
            return ok_response(sample_edge(id="edge-42"))

        client = make_client(handler)
        req = UpdateEdgeRequest(valid_to="2026-12-31T00:00:00Z")
        edge = client.entities.update_edge("tenant-1", "edge-42", req)
        assert edge.id == "edge-42"


# ── create_edge with force Tests ─────────────────────────────────────────


class TestCreateEdgeForce:
    def test_create_edge_with_force_true(self):
        """force=True should be included in the POST payload."""
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["force"] is True
            assert body["source"] == "Alice"
            assert body["target"] == "Bob"
            assert body["relationship"] == "spouse_of"
            return ok_response(sample_edge(source_id="Alice", target_id="Bob"), status=201)

        client = make_client(handler)
        req = CreateEdgeRequest(
            source="Alice",
            target="Bob",
            relationship="spouse_of",
            force=True,
        )
        edge = client.entities.create_edge("tenant-1", req)
        assert edge.source_id == "Alice"

    def test_create_edge_force_false_omitted(self):
        """force=None (default) should not appear in the payload."""
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert "force" not in body
            return ok_response(sample_edge(), status=201)

        client = make_client(handler)
        req = CreateEdgeRequest(
            source="Martinez Family",
            target="Johnson Corp",
            relationship="member_of",
        )
        client.entities.create_edge("tenant-1", req)

    def test_create_edge_with_valid_from(self):
        """valid_from should be sent when explicitly set."""
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["valid_from"] == "2026-03-01T00:00:00Z"
            return ok_response(sample_edge(valid_from="2026-03-01T00:00:00Z"), status=201)

        client = make_client(handler)
        req = CreateEdgeRequest(
            source="Martinez Family",
            target="Johnson Corp",
            relationship="member_of",
            valid_from="2026-03-01T00:00:00Z",
        )
        edge = client.entities.create_edge("tenant-1", req)
        assert edge.valid_from == "2026-03-01T00:00:00Z"

    def test_create_edge_with_valid_from_and_valid_to(self):
        """Both valid_from and valid_to can be set on creation."""
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["valid_from"] == "2026-01-01T00:00:00Z"
            assert body["valid_to"] == "2026-06-01T00:00:00Z"
            return ok_response(
                sample_edge(valid_from="2026-01-01T00:00:00Z", valid_to="2026-06-01T00:00:00Z"),
                status=201,
            )

        client = make_client(handler)
        req = CreateEdgeRequest(
            source="A", target="B", relationship="r",
            valid_from="2026-01-01T00:00:00Z",
            valid_to="2026-06-01T00:00:00Z",
        )
        edge = client.entities.create_edge("tenant-1", req)
        assert edge.valid_from == "2026-01-01T00:00:00Z"
        assert edge.valid_to == "2026-06-01T00:00:00Z"


# ── list_edges with temporal params Tests ────────────────────────────────


class TestListEdgesTemporal:
    def test_list_edges_with_as_of(self):
        """as_of query param should be sent."""
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "as_of=2026-03-01T00%3A00%3A00Z" in url or "as_of=2026-03-01T00:00:00Z" in url
            return ok_response([sample_edge()])

        client = make_client(handler)
        edges = client.entities.list_edges("tenant-1", as_of="2026-03-01T00:00:00Z")
        assert len(edges) == 1

    def test_list_edges_with_include_superseded(self):
        """include_superseded=true query param should be sent."""
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "include_superseded=true" in url
            return ok_response([
                sample_edge(),
                sample_edge(id="edge-2", valid_to="2025-12-31T00:00:00Z"),
            ])

        client = make_client(handler)
        edges = client.entities.list_edges("tenant-1", include_superseded=True)
        assert len(edges) == 2
        # Second edge has valid_to set (it's superseded)
        assert edges[1].valid_to == "2025-12-31T00:00:00Z"

    def test_list_edges_include_superseded_false(self):
        """include_superseded=False should send 'false' in the query."""
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "include_superseded=false" in url
            return ok_response([sample_edge()])

        client = make_client(handler)
        edges = client.entities.list_edges("tenant-1", include_superseded=False)
        assert len(edges) == 1

    def test_list_edges_with_as_of_and_include_superseded(self):
        """Both as_of and include_superseded can be sent together."""
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "as_of=" in url
            assert "include_superseded=true" in url
            return ok_response([sample_edge()])

        client = make_client(handler)
        edges = client.entities.list_edges(
            "tenant-1",
            as_of="2026-02-15T00:00:00Z",
            include_superseded=True,
        )
        assert len(edges) == 1

    def test_list_edges_without_temporal_params(self):
        """Default list_edges should NOT include as_of or include_superseded."""
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "as_of" not in url
            assert "include_superseded" not in url
            return ok_response([sample_edge()])

        client = make_client(handler)
        edges = client.entities.list_edges("tenant-1")
        assert len(edges) == 1


# ── traverse with as_of Tests ────────────────────────────────────────────


class TestTraverseAsOf:
    def test_traverse_with_as_of(self):
        """as_of query param should be sent in /graph traversal."""
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "/graph" in url
            assert "as_of=2026-02-01T00%3A00%3A00Z" in url or "as_of=2026-02-01T00:00:00Z" in url
            return ok_response(sample_traversal())

        client = make_client(handler)
        result = client.entities.traverse(
            "tenant-1", "Martinez Family", as_of="2026-02-01T00:00:00Z"
        )
        assert isinstance(result, TraversalResult)
        assert result.root == "Martinez Family"

    def test_traverse_with_as_of_and_relationship(self):
        """as_of and relationship can be combined."""
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "as_of=" in url
            assert "relationship=member_of" in url
            assert "depth=3" in url
            return ok_response(sample_traversal())

        client = make_client(handler)
        result = client.entities.traverse(
            "tenant-1",
            "Martinez Family",
            depth=3,
            relationship="member_of",
            as_of="2026-01-15T12:00:00Z",
        )
        assert result.root == "Martinez Family"

    def test_traverse_without_as_of(self):
        """Default traverse should NOT include as_of."""
        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            assert "as_of" not in url
            assert "depth=2" in url  # default depth
            return ok_response(sample_traversal())

        client = make_client(handler)
        result = client.entities.traverse("tenant-1", "Martinez Family")
        assert result.root == "Martinez Family"


# ── Model Tests ──────────────────────────────────────────────────────────


class TestTemporalModels:
    def test_graph_edge_temporal_fields(self):
        """GraphEdge should have valid_from, valid_to, recorded_at."""
        edge = GraphEdge(
            id="e-1",
            source_id="a",
            target_id="b",
            relationship="r",
            valid_from="2026-01-01T00:00:00Z",
            valid_to="2026-06-01T00:00:00Z",
            recorded_at="2026-01-01T00:00:01Z",
        )
        assert edge.valid_from == "2026-01-01T00:00:00Z"
        assert edge.valid_to == "2026-06-01T00:00:00Z"
        assert edge.recorded_at == "2026-01-01T00:00:01Z"

    def test_graph_edge_temporal_defaults_none(self):
        """Temporal fields default to None."""
        edge = GraphEdge(id="e-1", source_id="a", target_id="b", relationship="r")
        assert edge.valid_from is None
        assert edge.valid_to is None
        assert edge.recorded_at is None

    def test_create_edge_request_force_field(self):
        """CreateEdgeRequest has force, valid_from, valid_to."""
        req = CreateEdgeRequest(source="a", target="b", relationship="r")
        assert req.force is None
        assert req.valid_from is None
        assert req.valid_to is None

    def test_create_edge_request_force_true(self):
        req = CreateEdgeRequest(source="a", target="b", relationship="r", force=True)
        assert req.force is True

    def test_update_edge_request_defaults(self):
        """UpdateEdgeRequest allows all fields to be None."""
        req = UpdateEdgeRequest()
        assert req.valid_to is None
        assert req.weight is None

    def test_update_edge_request_both_fields(self):
        req = UpdateEdgeRequest(valid_to="2026-06-01T00:00:00Z", weight=0.5)
        assert req.valid_to == "2026-06-01T00:00:00Z"
        assert req.weight == 0.5

    def test_update_edge_request_model_dump_strips_none(self):
        """model_dump() should include all fields; None is filtered by the SDK method."""
        req = UpdateEdgeRequest(valid_to="2026-06-01T00:00:00Z")
        dumped = {k: v for k, v in req.model_dump().items() if v is not None}
        assert "valid_to" in dumped
        assert "weight" not in dumped

    def test_graph_edge_superseded_at_field(self):
        """GraphEdge should have superseded_at field (set when force-superseded)."""
        edge = GraphEdge(
            id="e-1",
            source_id="a",
            target_id="b",
            relationship="r",
            superseded_at="2026-05-01T00:00:00Z",
        )
        assert edge.superseded_at == "2026-05-01T00:00:00Z"

    def test_graph_edge_superseded_at_defaults_none(self):
        """superseded_at defaults to None for active edges."""
        edge = GraphEdge(id="e-1", source_id="a", target_id="b", relationship="r")
        assert edge.superseded_at is None

    def test_graph_edge_all_temporal_fields(self):
        """All temporal fields coexist correctly on a fully-populated edge."""
        edge = GraphEdge(
            id="e-1",
            source_id="Alice",
            target_id="Bob",
            relationship="spouse_of",
            valid_from="2020-06-01T00:00:00Z",
            valid_to="2026-01-01T00:00:00Z",
            recorded_at="2020-06-01T00:00:01Z",
            superseded_at="2026-01-01T00:00:00Z",
        )
        assert edge.valid_from == "2020-06-01T00:00:00Z"
        assert edge.valid_to == "2026-01-01T00:00:00Z"
        assert edge.recorded_at == "2020-06-01T00:00:01Z"
        assert edge.superseded_at == "2026-01-01T00:00:00Z"


# ── EntityNode temporal fields ────────────────────────────────────────────


class TestEntityNodeTemporalFields:
    def test_entity_node_has_first_seen_and_last_seen(self):
        """EntityNode should expose first_seen and last_seen timestamps."""
        entity = EntityNode(
            name="Martinez Family",
            entity_type="household",
            first_seen="2026-01-01T00:00:00Z",
            last_seen="2026-03-01T00:00:00Z",
        )
        assert entity.first_seen == "2026-01-01T00:00:00Z"
        assert entity.last_seen == "2026-03-01T00:00:00Z"

    def test_entity_node_temporal_defaults_none(self):
        """first_seen and last_seen default to None."""
        entity = EntityNode(name="Johnson Corp", entity_type="company")
        assert entity.first_seen is None
        assert entity.last_seen is None

    def test_entity_node_parses_from_api_response(self):
        """EntityNode.model_validate() correctly parses a full API response dict."""
        data = {
            "name": "ACME Trucking",
            "entity_type": "fleet",
            "user_id": None,
            "relationship": None,
            "metadata_json": "{}",
            "notes": None,
            "first_seen": "2025-06-01T00:00:00Z",
            "last_seen": "2026-02-28T00:00:00Z",
            "created_at": "2025-06-01T00:00:00Z",
            "updated_at": "2026-02-28T00:00:00Z",
        }
        entity = EntityNode.model_validate(data)
        assert entity.name == "ACME Trucking"
        assert entity.first_seen == "2025-06-01T00:00:00Z"
        assert entity.last_seen == "2026-02-28T00:00:00Z"

    def test_entity_node_parses_without_temporal_fields(self):
        """EntityNode.model_validate() succeeds when first_seen/last_seen are absent."""
        data = {
            "name": "River Corp",
            "entity_type": "contact",
            "metadata_json": "{}",
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        }
        entity = EntityNode.model_validate(data)
        assert entity.name == "River Corp"
        assert entity.first_seen is None
        assert entity.last_seen is None

    def test_get_entity_returns_temporal_fields(self):
        """get_entity SDK call returns EntityNode with first_seen/last_seen populated."""
        entity_data = {
            "name": "Martinez Family",
            "entity_type": "household",
            "metadata_json": "{}",
            "first_seen": "2025-01-01T00:00:00Z",
            "last_seen": "2026-03-01T00:00:00Z",
            "created_at": "2025-01-01T00:00:00Z",
            "updated_at": "2026-03-01T00:00:00Z",
        }

        def handler(request: httpx.Request) -> httpx.Response:
            assert "/entities/Martinez%20Family" in str(request.url)
            return ok_response(entity_data)

        client = make_client(handler)
        entity = client.entities.get_entity("tenant-1", "Martinez Family")
        assert entity.first_seen == "2025-01-01T00:00:00Z"
        assert entity.last_seen == "2026-03-01T00:00:00Z"

    def test_list_entities_returns_temporal_fields(self):
        """list_entities returns EntityNodes with first_seen/last_seen."""
        entities_data = [
            {
                "name": "Alice",
                "entity_type": "contact",
                "metadata_json": "{}",
                "first_seen": "2025-03-01T00:00:00Z",
                "last_seen": "2026-01-15T00:00:00Z",
                "created_at": "2025-03-01T00:00:00Z",
                "updated_at": "2026-01-15T00:00:00Z",
            },
            {
                "name": "Bob",
                "entity_type": "contact",
                "metadata_json": "{}",
                "first_seen": None,
                "last_seen": None,
                "created_at": "2026-01-01T00:00:00Z",
                "updated_at": "2026-01-01T00:00:00Z",
            },
        ]

        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(entities_data)

        client = make_client(handler)
        entities = client.entities.list_entities("tenant-1")
        assert len(entities) == 2
        assert entities[0].first_seen == "2025-03-01T00:00:00Z"
        assert entities[0].last_seen == "2026-01-15T00:00:00Z"
        assert entities[1].first_seen is None
        assert entities[1].last_seen is None

    def test_list_edges_returns_superseded_at(self):
        """list_edges with include_superseded=True returns edges with superseded_at set."""
        edges_data = [
            {
                "id": "edge-1",
                "source_id": "Alice",
                "target_id": "Bob",
                "relationship": "spouse_of",
                "weight": 1.0,
                "memory_id": None,
                "valid_from": "2020-01-01T00:00:00Z",
                "valid_to": "2026-01-01T00:00:00Z",
                "recorded_at": "2020-01-01T00:00:00Z",
                "superseded_at": "2026-01-01T00:00:00Z",
                "created_at": "2020-01-01T00:00:00Z",
            },
            {
                "id": "edge-2",
                "source_id": "Alice",
                "target_id": "Carol",
                "relationship": "spouse_of",
                "weight": 1.0,
                "memory_id": None,
                "valid_from": "2026-01-01T00:00:00Z",
                "valid_to": None,
                "recorded_at": "2026-01-01T00:00:00Z",
                "superseded_at": None,
                "created_at": "2026-01-01T00:00:00Z",
            },
        ]

        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(edges_data)

        client = make_client(handler)
        edges = client.entities.list_edges("tenant-1", include_superseded=True)
        assert len(edges) == 2
        # First edge is superseded
        assert edges[0].superseded_at == "2026-01-01T00:00:00Z"
        assert edges[0].valid_to == "2026-01-01T00:00:00Z"
        # Second edge is active
        assert edges[1].superseded_at is None
        assert edges[1].valid_to is None
