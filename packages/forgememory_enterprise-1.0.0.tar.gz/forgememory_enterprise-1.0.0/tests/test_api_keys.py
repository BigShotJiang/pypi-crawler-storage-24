"""Tests for ApiKeyManager."""

import httpx
import pytest

from conftest import make_client, ok_response, sample_api_key_created, sample_api_key_row


class TestApiKeyManager:
    def test_create_api_key(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            return ok_response(sample_api_key_created())

        client = make_client(handler)
        key = client.api_keys.create("org-1", "admin", "test-key")
        assert key.id == "key-1"
        assert key.raw_key == "fme_raw_abc123"
        assert key.role == "admin"

    def test_create_api_key_with_options(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            import json
            received_body.update(json.loads(request.content))
            return ok_response(sample_api_key_created())

        client = make_client(handler)
        client.api_keys.create(
            "org-1", "manager", "scoped-key",
            tenant_ids=["t-1", "t-2"],
            user_id="user-1",
            expires_at="2027-01-01T00:00:00Z",
        )
        assert received_body["tenant_ids"] == ["t-1", "t-2"]
        assert received_body["user_id"] == "user-1"
        assert received_body["expires_at"] == "2027-01-01T00:00:00Z"

    def test_list_api_keys(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_api_key_row(), sample_api_key_row(id="key-2")])

        client = make_client(handler)
        keys = client.api_keys.list("org-1")
        assert len(keys) == 2

    def test_revoke_api_key(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert "/api-keys/key-1/revoke" in str(request.url)
            return ok_response("API key revoked")

        client = make_client(handler)
        result = client.api_keys.revoke("key-1")
        assert result == "API key revoked"
