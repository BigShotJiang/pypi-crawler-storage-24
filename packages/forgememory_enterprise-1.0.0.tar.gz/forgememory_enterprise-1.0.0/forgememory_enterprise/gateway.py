"""BYOM RAG Gateway — conversation log ingestion and analytics."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ._http import require_non_empty, unwrap

if TYPE_CHECKING:
    import httpx


class GatewayClient:
    """Access gateway conversation logs and analytics.

    The FME gateway sits in front of your LLM provider and captures every
    conversation for memory ingestion, DLP scrubbing, and RAG enrichment.
    This client provides access to the stored conversation logs and analytics.
    """

    def __init__(self, client: httpx.Client) -> None:
        self._c = client

    def ingest_conversation(
        self,
        tenant_id: str,
        conversation: dict[str, Any],
    ) -> dict[str, Any]:
        """POST /api/v1/tenants/{tenant_id}/gateway/conversations — Ingest a conversation log.

        Manually ingest a gateway conversation log into the memory system.
        Useful for importing conversations from external LLM providers that
        don't route through the FME gateway proxy.

        Args:
            tenant_id: The tenant to ingest the conversation for.
            conversation: Conversation payload. Expected fields:
                - messages (list): List of {role, content} dicts.
                - model (str, optional): LLM model used.
                - session_id (str, optional): Agent session ID.
                - metadata (dict, optional): Arbitrary metadata.

        Returns:
            Dict with ingested conversation ID and extraction summary.
        """
        require_non_empty(tenant_id, "tenant_id")
        resp = self._c.post(
            f"/api/v1/tenants/{tenant_id}/gateway/conversations",
            json=conversation,
        )
        return unwrap(resp)

    def list_conversations(
        self,
        tenant_id: str,
        limit: int = 20,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """GET /api/v1/tenants/{tenant_id}/gateway/conversations — List conversation logs.

        Returns gateway conversation logs stored for this tenant.

        Args:
            tenant_id: The tenant to query.
            limit: Maximum number of conversations to return (default 20).
            offset: Pagination offset (default 0).

        Returns:
            List of conversation log dicts ordered by recency.
        """
        require_non_empty(tenant_id, "tenant_id")
        resp = self._c.get(
            f"/api/v1/tenants/{tenant_id}/gateway/conversations",
            params={"limit": limit, "offset": offset},
        )
        data = unwrap(resp)
        return data if isinstance(data, list) else data.get("items", [])

    def analytics(self, tenant_id: str) -> dict[str, Any]:
        """GET /api/v1/tenants/{tenant_id}/gateway/analytics — Gateway analytics.

        Returns aggregated analytics for gateway traffic including:
        - Request counts by model and time period
        - Average latency and token counts
        - Cache hit rate (if semantic caching is enabled)
        - Memory injection rate (RAG enrichment)

        Args:
            tenant_id: The tenant to get analytics for.

        Returns:
            Dict with analytics fields.
        """
        require_non_empty(tenant_id, "tenant_id")
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/gateway/analytics")
        return unwrap(resp)
