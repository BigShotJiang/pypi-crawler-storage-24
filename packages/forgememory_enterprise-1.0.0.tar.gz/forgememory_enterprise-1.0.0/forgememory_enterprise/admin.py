"""Admin dashboard, pool management, health probes, and compliance."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ._http import unwrap
from .types import AgentAuditStats, AgentRecord, ComplianceEvidence, CompliancePosture, DistillationStats, HealthResponse, LivenessResponse, PoolStats, ReadinessResponse, VectorStats, VectorStatsResponse

if TYPE_CHECKING:
    import httpx


class AdminClient:
    """Health checks, agent dashboard, pool stats, and compliance posture."""

    def __init__(self, client: httpx.Client) -> None:
        self._c = client

    def health(self) -> HealthResponse:
        """GET /health — Basic health check."""
        resp = self._c.get("/health")
        return HealthResponse.model_validate(unwrap(resp))

    def liveness(self) -> LivenessResponse:
        """GET /health/live — Kubernetes-style liveness probe.

        Returns a minimal response indicating the process is alive.
        Suitable for liveness probes in container orchestration systems.
        """
        resp = self._c.get("/health/live")
        return LivenessResponse.model_validate(unwrap(resp))

    def readiness(self) -> ReadinessResponse:
        """GET /health/ready — Kubernetes-style readiness probe with component status.

        Returns the status of each internal component (database, vector store, etc.).
        A 503 response means the server is alive but not yet ready to serve traffic.
        """
        resp = self._c.get("/health/ready")
        return ReadinessResponse.model_validate(unwrap(resp))

    def agent_dashboard(self) -> list[AgentRecord]:
        """GET /api/v1/agents — List all registered agents."""
        resp = self._c.get("/api/v1/agents")
        data = unwrap(resp)
        return [AgentRecord.model_validate(a) for a in data]

    def audit_stats(self) -> AgentAuditStats:
        """GET /api/v1/admin/audit-stats — Global audit statistics."""
        resp = self._c.get("/api/v1/admin/audit-stats")
        return AgentAuditStats.model_validate(unwrap(resp))

    def pool_stats(self) -> PoolStats:
        """GET /api/v1/pool/stats — Connection pool statistics.

        NOTE: Server route not yet implemented.
        """
        # NOTE: Server route not yet implemented
        resp = self._c.get("/api/v1/pool/stats")
        return PoolStats.model_validate(unwrap(resp))

    def pool_close_all(self) -> str:
        """POST /api/v1/pool/close-all — Close all pooled connections.

        NOTE: Server route not yet implemented.
        """
        # NOTE: Server route not yet implemented
        resp = self._c.post("/api/v1/pool/close-all")
        return unwrap(resp)

    def compliance_posture(self) -> CompliancePosture:
        """GET /api/v1/admin/compliance-posture — Overall compliance posture summary.

        Returns high-level compliance status across all regulatory frameworks
        (GDPR, HIPAA, SOX, FINRA, MiFID II) with pass/fail/warn indicators.
        """
        resp = self._c.get("/api/v1/admin/compliance-posture")
        return CompliancePosture.model_validate(unwrap(resp))

    def compliance_evidence(
        self,
        framework: str | None = None,
        tenant_id: str | None = None,
    ) -> ComplianceEvidence:
        """GET /api/v1/admin/compliance-evidence — Compliance evidence artifacts.

        NOTE: Server route not yet implemented.

        Returns audit trail records, data access logs, and control evidence
        suitable for regulatory reporting or external auditors.

        Args:
            framework: Optional regulatory framework filter (e.g. "gdpr", "hipaa").
            tenant_id: Optional tenant filter.

        Returns:
            ComplianceEvidence with evidence records and metadata.

        Note:
            The SSE events stream at GET /api/v1/events is not wrapped here
            because httpx's streaming API differs from the sync request pattern.
            Use ``client._client.stream("GET", "/api/v1/events")`` directly
            for server-sent events.
        """
        # NOTE: Server route not yet implemented
        params: dict[str, Any] = {}
        if framework is not None:
            params["framework"] = framework
        if tenant_id is not None:
            params["tenant_id"] = tenant_id
        resp = self._c.get("/api/v1/admin/compliance-evidence", params=params)
        return ComplianceEvidence.model_validate(unwrap(resp))

    # ── Vector search admin ────────────────────────────────────────────────

    def vector_stats(self) -> VectorStatsResponse:
        """GET /api/v1/admin/vector/stats — Per-tenant vector search statistics."""
        resp = self._c.get("/api/v1/admin/vector/stats")
        return VectorStatsResponse.model_validate(unwrap(resp))

    def vector_backfill(self) -> str:
        """POST /api/v1/admin/vector/backfill — Trigger backfill of un-embedded memories."""
        resp = self._c.post("/api/v1/admin/vector/backfill")
        return unwrap(resp)

    def vector_rebuild(self, tenant_id: str) -> str:
        """POST /api/v1/admin/vector/rebuild/{tenant_id} — Rebuild vector index for a tenant."""
        resp = self._c.post(f"/api/v1/admin/vector/rebuild/{tenant_id}")
        return unwrap(resp)

    # ── Distillation admin ─────────────────────────────────────────────

    def distillation_stats(self) -> DistillationStats:
        """GET /api/v1/admin/distillation/stats — Distillation pipeline statistics."""
        resp = self._c.get("/api/v1/admin/distillation/stats")
        return DistillationStats.model_validate(unwrap(resp))

    def trigger_distillation(self) -> str:
        """POST /api/v1/admin/distillation/trigger — Trigger an on-demand distillation sweep."""
        resp = self._c.post("/api/v1/admin/distillation/trigger")
        data = unwrap(resp)
        if isinstance(data, dict):
            return data.get("message", str(data))
        return str(data)

    def daily_costs(self, date: str | None = None) -> list[Any]:
        """GET /api/v1/admin/costs/daily — Daily cost breakdown across all agents."""
        params: dict[str, Any] = {}
        if date is not None:
            params["date"] = date
        resp = self._c.get("/api/v1/admin/costs/daily", params=params)
        data = unwrap(resp)
        return data if isinstance(data, list) else data.get("items", [])

    def tenant_costs(self, date: str | None = None) -> list[Any]:
        """GET /api/v1/admin/costs/by-tenant — Cost breakdown grouped by tenant."""
        params: dict[str, Any] = {}
        if date is not None:
            params["date"] = date
        resp = self._c.get("/api/v1/admin/costs/by-tenant", params=params)
        data = unwrap(resp)
        return data if isinstance(data, list) else data.get("items", [])

    def tiered_index_seed(self, tenant_id: str | None = None) -> dict[str, Any]:
        """POST /api/v1/admin/tiered-index/seed — Seed topic catalog and memory summaries.

        Populates the tiered search index (topic_catalog, memory_summaries tables)
        from existing memories without requiring an LLM.

        Args:
            tenant_id: Optional — limit seeding to a single tenant.

        Returns:
            Dict with tenants_seeded and topics_created counts.
        """
        payload: dict[str, Any] = {}
        if tenant_id is not None:
            payload["tenant_id"] = tenant_id
        resp = self._c.post("/api/v1/admin/tiered-index/seed", json=payload)
        data = unwrap(resp)
        return data if isinstance(data, dict) else {}

    def global_stats(self) -> dict[str, Any]:
        """GET /api/v1/admin/stats — Global system statistics."""
        resp = self._c.get("/api/v1/admin/stats")
        data = unwrap(resp)
        return data if isinstance(data, dict) else {}
