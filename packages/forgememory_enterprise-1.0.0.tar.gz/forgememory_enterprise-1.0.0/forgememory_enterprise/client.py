"""Main entry point for the ForgeMemory Enterprise Python SDK."""

from __future__ import annotations

from typing import Any

import httpx

from ._http import make_client
from .admin import AdminClient
from .agents import AgentRegistry, AgentSessionContext
from .api_keys import ApiKeyManager
from .audit import AuditLogger
from .entities import EntityGraphClient
from .gateway import GatewayClient
from .ingest import IngestClient
from .legal_holds import LegalHoldClient
from .memory import MemoryClient
from .orgs import OrgManager
from .tenants import TenantManager
from .dsr import DsrClient
from .compliance import ComplianceClient
from .policies import PolicyClient
from .retention import RetentionClient
from .supervisor import SupervisorClient
from .sandbox import SandboxClient


class EnterpriseClient:
    """ForgeMemory Enterprise SDK client.

    Provides lazy sub-managers for all FME operations. The httpx.Client
    is shared across all managers for connection pooling.

    Args:
        api_key: FME API key (from create_api_key).
        base_url: Server URL (required). Example: 'https://your-server:8201'.
            No default is provided — the SDK never embeds server addresses.
        timeout: HTTP timeout in seconds.
        transport: Optional httpx transport (for testing with MockTransport).
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        timeout: float = 30.0,
        transport: httpx.BaseTransport | None = None,
        agent_type: str | None = None,
        strict_dlp: bool = False,
    ) -> None:
        if not base_url:
            raise ValueError(
                "base_url is required. Example: "
                "EnterpriseClient(base_url='https://your-server:8201')"
            )
        self._client = make_client(
            base_url, 
            api_key, 
            timeout=timeout, 
            transport=transport,
            agent_type=agent_type,
            strict_dlp=strict_dlp,
        )
        self._orgs: OrgManager | None = None
        self._tenants: TenantManager | None = None
        self._api_keys: ApiKeyManager | None = None
        self._agents: AgentRegistry | None = None
        self._audit: AuditLogger | None = None
        self._memory: MemoryClient | None = None
        self._admin: AdminClient | None = None
        self._entities: EntityGraphClient | None = None
        self._ingest: IngestClient | None = None
        self._dsr: DsrClient | None = None
        self._compliance: ComplianceClient | None = None
        self._policies: PolicyClient | None = None
        self._retention: RetentionClient | None = None
        self._supervisor: SupervisorClient | None = None
        self._legal_holds: LegalHoldClient | None = None
        self._gateway: GatewayClient | None = None
        self._sandbox: SandboxClient | None = None

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> EnterpriseClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── Lazy sub-managers ─────────────────────────────────────────────

    @property
    def orgs(self) -> OrgManager:
        if self._orgs is None:
            self._orgs = OrgManager(self._client)
        return self._orgs

    @property
    def tenants(self) -> TenantManager:
        if self._tenants is None:
            self._tenants = TenantManager(self._client)
        return self._tenants

    @property
    def api_keys(self) -> ApiKeyManager:
        if self._api_keys is None:
            self._api_keys = ApiKeyManager(self._client)
        return self._api_keys

    @property
    def agents(self) -> AgentRegistry:
        if self._agents is None:
            self._agents = AgentRegistry(self._client)
        return self._agents

    @property
    def audit(self) -> AuditLogger:
        if self._audit is None:
            self._audit = AuditLogger(self._client)
        return self._audit

    @property
    def memory(self) -> MemoryClient:
        if self._memory is None:
            self._memory = MemoryClient(self._client)
        return self._memory

    @property
    def admin(self) -> AdminClient:
        if self._admin is None:
            self._admin = AdminClient(self._client)
        return self._admin

    @property
    def entities(self) -> EntityGraphClient:
        if self._entities is None:
            self._entities = EntityGraphClient(self._client)
        return self._entities

    @property
    def ingest(self) -> IngestClient:
        if self._ingest is None:
            self._ingest = IngestClient(self._client)
        return self._ingest

    @property
    def dsr(self) -> DsrClient:
        if self._dsr is None:
            self._dsr = DsrClient(self._client)
        return self._dsr

    @property
    def compliance(self) -> ComplianceClient:
        if self._compliance is None:
            self._compliance = ComplianceClient(self._client)
        return self._compliance

    @property
    def policies(self) -> PolicyClient:
        if self._policies is None:
            self._policies = PolicyClient(self._client)
        return self._policies

    @property
    def retention(self) -> RetentionClient:
        if self._retention is None:
            self._retention = RetentionClient(self._client)
        return self._retention

    @property
    def supervisor(self) -> SupervisorClient:
        if self._supervisor is None:
            self._supervisor = SupervisorClient(self._client)
        return self._supervisor

    @property
    def legal_holds(self) -> LegalHoldClient:
        if self._legal_holds is None:
            self._legal_holds = LegalHoldClient(self._client)
        return self._legal_holds

    @property
    def gateway(self) -> GatewayClient:
        if self._gateway is None:
            self._gateway = GatewayClient(self._client)
        return self._gateway

    @property
    def sandbox(self) -> SandboxClient:
        if self._sandbox is None:
            self._sandbox = SandboxClient(self._client)
        return self._sandbox

    def session(
        self,
        agent_id: str,
        tenant_id: str,
        heartbeat_interval: float = 30.0,
        metadata: dict | None = None,
    ) -> AgentSessionContext:
        """Create an agent session context manager.

        Usage:
            with client.session("agent-1", "tenant-1") as sess:
                # sess.id is the active session
                client.audit.log_action(agent_id, sess.id, "tool_call", "search")
        """
        return AgentSessionContext(
            self.agents,
            agent_id,
            tenant_id,
            heartbeat_interval=heartbeat_interval,
            metadata=metadata,
        )
