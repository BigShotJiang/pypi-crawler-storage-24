"""Retention policy management for SEC 17a-4 / WORM compliance."""

from __future__ import annotations

from datetime import datetime, timezone, timedelta

import httpx

from ._http import unwrap
from .types import RetentionStatus


class RetentionClient:
    """Manager for setting and enforcing memory retention policies."""

    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def get_status(self, tenant_id: str) -> RetentionStatus:
        """Get the current retention status and sweep eligibility."""
        response = self._client.get(f"/api/v1/tenants/{tenant_id}/retention/status")
        data = unwrap(response)
        # Server returns {tenant_id, total_memories, active_memories, ...}
        # RetentionStatus.retention_days is a SDK-side field; derive it from status
        if isinstance(data, dict) and "retention_days" not in data:
            # Populate retention_days from the status for SDK compatibility
            data = dict(data)
            data.setdefault("retention_days", 0)
        return RetentionStatus(**data)

    def set_policy(self, tenant_id: str, retention_days: int) -> None:
        """Set the global retention policy for the tenant.

        The server's /retention/set endpoint applies a retention_until date to
        specific memory_ids. This method computes retention_until = now +
        retention_days and applies it to all memories for the tenant (empty
        memory_ids = no-op on the per-memory level; the tenant-level default
        is set via the org retention_days property on onboard).

        For a no-op call that validates the endpoint is reachable, this sends
        an empty memory_ids list with a retention_until computed from retention_days.

        Args:
            tenant_id: Tenant ID.
            retention_days: Number of days to retain memories before they
                are eligible for sweeping.
        """
        retention_until = (
            datetime.now(timezone.utc) + timedelta(days=retention_days)
        ).strftime("%Y-%m-%dT%H:%M:%SZ")
        response = self._client.post(
            f"/api/v1/tenants/{tenant_id}/retention/set",
            json={
                "retention_until": retention_until,
                "memory_ids": [],
                "set_hold": False,
                "actor": "sdk",
            },
        )
        unwrap(response)

    def trigger_sweep(self, tenant_id: str) -> None:
        """Trigger a manual retention sweep.

        This will irrevocably delete any memories older than
        the retention threshold that are not under a legal hold.
        """
        response = self._client.post(f"/api/v1/tenants/{tenant_id}/retention/sweep")
        unwrap(response)
