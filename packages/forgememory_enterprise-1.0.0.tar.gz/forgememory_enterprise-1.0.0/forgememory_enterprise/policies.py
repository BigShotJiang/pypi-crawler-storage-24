"""Compliance policy engine — CRUD for per-tenant policy rules."""

from __future__ import annotations

from typing import Any

import httpx

from ._http import unwrap
from .types import Policy


class PolicyClient:
    """Manager for per-tenant compliance policies (data governance, retention, sensitivity)."""

    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def create(
        self,
        tenant_id: str,
        name: str,
        policy_type: str,
        config: dict[str, Any],
        action: str = "deny",
    ) -> Policy:
        """Create a new compliance policy for a tenant.

        Args:
            tenant_id: Tenant ID.
            name: Human-readable policy name.
            policy_type: Policy type (e.g., 'sensitivity_gate', 'retention_override').
            config: Policy configuration dict (schema depends on policy_type).
            action: Enforcement action — 'deny', 'warn', or 'log'. Defaults to 'deny'.
        """
        import json as _json
        response = self._client.post(
            f"/api/v1/tenants/{tenant_id}/policies",
            json={
                "name": name,
                "policy_type": policy_type,
                "config_json": _json.dumps(config) if isinstance(config, dict) else config,
                "action": action,
            },
        )
        return Policy.model_validate(unwrap(response))

    def list(self, tenant_id: str) -> list[Policy]:
        """List all policies for a tenant."""
        response = self._client.get(f"/api/v1/tenants/{tenant_id}/policies")
        data = unwrap(response)
        return [Policy.model_validate(p) for p in data]

    def get(self, tenant_id: str, policy_id: str) -> Policy:
        """Get a specific policy by ID."""
        response = self._client.get(f"/api/v1/tenants/{tenant_id}/policies/{policy_id}")
        return Policy.model_validate(unwrap(response))

    def update(self, tenant_id: str, policy_id: str, **kwargs: Any) -> Policy:
        """Update a policy (partial update).

        Supported kwargs: name, policy_type, config, action, enabled.
        """
        import json as _json
        payload: dict[str, Any] = {}
        for key in ("name", "policy_type", "action", "enabled"):
            if key in kwargs:
                payload[key] = kwargs[key]
        if "config" in kwargs:
            config = kwargs["config"]
            payload["config_json"] = _json.dumps(config) if isinstance(config, dict) else config

        response = self._client.patch(
            f"/api/v1/tenants/{tenant_id}/policies/{policy_id}",
            json=payload,
        )
        return Policy.model_validate(unwrap(response))

    def delete(self, tenant_id: str, policy_id: str) -> None:
        """Delete a policy."""
        response = self._client.delete(f"/api/v1/tenants/{tenant_id}/policies/{policy_id}")
        unwrap(response)
