"""Legal hold and litigation matter management.

Provides scope-based low-level holds and high-level matter management for
FINRA, SEC, and GDPR litigation freeze workflows.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ._http import require_non_empty, unwrap

if TYPE_CHECKING:
    import httpx


class LegalHoldClient:
    """Manage legal holds and litigation matters for compliance freeze workflows.

    Two abstraction layers are provided:

    - **Low-level holds** — scope-based freezes created directly on a tenant.
      Prevents modification or deletion of memories matching the scope.
    - **High-level matters** — named legal cases that group holds together.
      Matters can have assigned memories, custom metadata, and lifecycle states.
    """

    def __init__(self, client: httpx.Client) -> None:
        self._c = client

    # ── Low-level scope-based holds ───────────────────────────────────

    def create_hold(
        self,
        tenant_id: str,
        scope: str,
        reason: str,
        created_by: str,
    ) -> dict[str, Any]:
        """POST /api/v1/tenants/{tenant_id}/legal-holds — Create a legal hold.

        Creates a scope-based freeze that prevents modification or deletion
        of memories matching the scope until the hold is released.

        Args:
            tenant_id: The tenant to place under hold.
            scope: Scope expression (e.g. "client_id:c-123", "tag:litigation").
            reason: Human-readable reason for the hold (audit trail).
            created_by: Identity of the person or system creating the hold.

        Returns:
            Dict with hold ID, scope, reason, and created_at timestamp.
        """
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(scope, "scope")
        resp = self._c.post(
            f"/api/v1/tenants/{tenant_id}/legal-holds",
            json={"scope": scope, "reason": reason, "created_by": created_by},
        )
        return unwrap(resp)

    def list_holds(self, tenant_id: str) -> list[dict[str, Any]]:
        """GET /api/v1/tenants/{tenant_id}/legal-holds — List all legal holds.

        Args:
            tenant_id: The tenant to list holds for.

        Returns:
            List of hold records (id, scope, reason, created_at).
        """
        require_non_empty(tenant_id, "tenant_id")
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/legal-holds")
        data = unwrap(resp)
        return data if isinstance(data, list) else data.get("items", [])

    def release_hold(self, tenant_id: str, hold_id: str) -> str:
        """DELETE /api/v1/tenants/{tenant_id}/legal-holds/{id} — Release a legal hold.

        Lifting a hold does not restore deleted memories — it only allows future
        modifications and deletions to proceed normally.

        Args:
            tenant_id: The tenant owning the hold.
            hold_id: The hold ID to release.

        Returns:
            Confirmation message from the server.
        """
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(hold_id, "hold_id")
        resp = self._c.delete(f"/api/v1/tenants/{tenant_id}/legal-holds/{hold_id}")
        return unwrap(resp)

    # ── High-level matter management ──────────────────────────────────

    def create_matter(
        self,
        tenant_id: str,
        name: str,
        description: str = "",
        matter_type: str = "litigation",
    ) -> dict[str, Any]:
        """POST /api/v1/tenants/{tenant_id}/legal-holds/matters — Create a legal matter.

        A matter is a named legal case that groups holds and assigned memories.
        Suitable for FINRA/SEC investigation tracking and e-discovery workflows.

        Args:
            tenant_id: The tenant to create the matter for.
            name: Unique matter name (e.g. "SEC Investigation 2026-001").
            description: Optional description of the matter.
            matter_type: Type of matter ("litigation", "investigation", "regulatory").

        Returns:
            Dict with matter ID, name, status, and created_at timestamp.
        """
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(name, "name")
        resp = self._c.post(
            f"/api/v1/tenants/{tenant_id}/legal-holds/matters",
            json={"name": name, "description": description, "matter_type": matter_type},
        )
        return unwrap(resp)

    def list_matters(self, tenant_id: str) -> list[dict[str, Any]]:
        """GET /api/v1/tenants/{tenant_id}/legal-holds/matters — List all matters.

        Args:
            tenant_id: The tenant to list matters for.

        Returns:
            List of matter records (id, name, status, memory_count, etc.).
        """
        require_non_empty(tenant_id, "tenant_id")
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/legal-holds/matters")
        data = unwrap(resp)
        return data if isinstance(data, list) else data.get("items", [])

    def get_matter(self, tenant_id: str, matter_id: str) -> dict[str, Any]:
        """GET /api/v1/tenants/{tenant_id}/legal-holds/matters/{matter_id} — Get a matter.

        Args:
            tenant_id: The tenant owning the matter.
            matter_id: The matter ID.

        Returns:
            Dict with matter details including assigned memory IDs.
        """
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(matter_id, "matter_id")
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/legal-holds/matters/{matter_id}")
        return unwrap(resp)

    def update_matter(
        self,
        tenant_id: str,
        matter_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """PATCH /api/v1/tenants/{tenant_id}/legal-holds/matters/{matter_id} — Update a matter.

        Supports partial updates. Common fields: name, description, status.

        Args:
            tenant_id: The tenant owning the matter.
            matter_id: The matter ID.
            **kwargs: Fields to update (name, description, status, etc.).

        Returns:
            Updated matter dict.
        """
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(matter_id, "matter_id")
        resp = self._c.patch(
            f"/api/v1/tenants/{tenant_id}/legal-holds/matters/{matter_id}",
            json=kwargs,
        )
        return unwrap(resp)

    def release_matter(self, tenant_id: str, matter_id: str) -> str:
        """POST /api/v1/tenants/{tenant_id}/legal-holds/matters/{matter_id}/release — Release.

        Marks the matter as closed and releases all associated holds.

        Args:
            tenant_id: The tenant owning the matter.
            matter_id: The matter ID to release.

        Returns:
            Confirmation message from the server.
        """
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(matter_id, "matter_id")
        resp = self._c.post(
            f"/api/v1/tenants/{tenant_id}/legal-holds/matters/{matter_id}/release",
            json={},
        )
        return unwrap(resp)

    def assign_memories(
        self,
        tenant_id: str,
        matter_id: str,
        memory_ids: list[str],
    ) -> dict[str, Any]:
        """POST /api/v1/tenants/{tenant_id}/legal-holds/matters/{matter_id}/assign — Assign memories.

        Explicitly assigns specific memories to a matter, placing them under
        the matter's legal hold.

        Args:
            tenant_id: The tenant owning the matter.
            matter_id: The matter ID.
            memory_ids: List of memory IDs to assign to this matter.

        Returns:
            Dict with assigned_count and any skipped_ids (already assigned).
        """
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(matter_id, "matter_id")
        resp = self._c.post(
            f"/api/v1/tenants/{tenant_id}/legal-holds/matters/{matter_id}/assign",
            json={"memory_ids": memory_ids},
        )
        return unwrap(resp)

    def search_assign_memories(
        self,
        tenant_id: str,
        matter_id: str,
        query: str,
        limit: int = 100,
    ) -> dict[str, Any]:
        """POST /tenants/{tid}/legal-holds/matters/{mid}/search-assign — Search and assign.

        Searches the tenant's memories and assigns all matching results to the
        matter. Useful for bulk assignment during e-discovery.

        Args:
            tenant_id: The tenant owning the matter.
            matter_id: The matter ID.
            query: Search query used to find memories to assign.
            limit: Maximum number of memories to assign (default 100).

        Returns:
            Dict with assigned_count and the matched memory IDs.
        """
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(matter_id, "matter_id")
        require_non_empty(query, "query")
        resp = self._c.post(
            f"/api/v1/tenants/{tenant_id}/legal-holds/matters/{matter_id}/search-assign",
            json={"query": query, "limit": limit},
        )
        return unwrap(resp)
