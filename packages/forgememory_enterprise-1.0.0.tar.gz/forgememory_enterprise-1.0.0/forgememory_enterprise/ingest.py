"""Data ingestion pipeline client — 7 channel types."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Union

from ._http import unwrap
from .types import (
    CalendarEventRequest,
    CallTranscriptRequest,
    ChannelInfo,
    CrmEventRequest,
    DocumentIngestRequest,
    EmailIngestRequest,
    IngestResponse,
    MeetingNoteRequest,
    PlanningSessionRequest,
)

if TYPE_CHECKING:
    import httpx


# Type alias for any ingest request
IngestRequest = Union[
    CrmEventRequest,
    EmailIngestRequest,
    CallTranscriptRequest,
    CalendarEventRequest,
    PlanningSessionRequest,
    MeetingNoteRequest,
    DocumentIngestRequest,
]

# Map request types to channel slugs
_CHANNEL_MAP: dict[type, str] = {
    CrmEventRequest: "crm_sync",
    EmailIngestRequest: "email_intelligence",
    CallTranscriptRequest: "call_transcript",
    CalendarEventRequest: "calendar_context",
    PlanningSessionRequest: "planning_session",
    MeetingNoteRequest: "meeting_notes",
    DocumentIngestRequest: "document_processing",
}


class IngestClient:
    """Ingest data into ForgeMemory via 7 channel types.

    Each channel type maps to a specific business data source:
    CRM, Email, Call Transcripts, Calendar, Planning Sessions,
    Meeting Notes, and Documents.
    """

    def __init__(self, client: httpx.Client) -> None:
        self._c = client

    def ingest(self, tenant_id: str, channel: str, payload: dict[str, Any]) -> IngestResponse:
        """Ingest raw data through a named channel.

        Args:
            tenant_id: Target tenant.
            channel: Channel slug (e.g., "crm_sync", "email_intelligence").
            payload: Channel-specific JSON payload.
        """
        resp = self._c.post(f"/api/v1/tenants/{tenant_id}/ingest/{channel}", json=payload)
        return IngestResponse.model_validate(unwrap(resp))

    def ingest_typed(self, tenant_id: str, req: IngestRequest) -> IngestResponse:
        """Ingest a typed request — channel is auto-detected from the request type.

        Args:
            tenant_id: Target tenant.
            req: A typed ingest request (CrmEventRequest, EmailIngestRequest, etc.).
        """
        channel = _CHANNEL_MAP.get(type(req))
        if channel is None:
            raise ValueError(f"Unknown ingest request type: {type(req).__name__}")
        payload = req.model_dump(by_alias=True)
        return self.ingest(tenant_id, channel, payload)

    def list_channels(self, tenant_id: str) -> list[ChannelInfo]:
        """List available ingest channels with their defaults."""
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/ingest")
        data = unwrap(resp)
        return [ChannelInfo.model_validate(ch) for ch in data]

    # ── Convenience methods for each channel ─────────────────────────

    def ingest_crm(self, tenant_id: str, req: CrmEventRequest) -> IngestResponse:
        """Ingest a CRM event."""
        return self.ingest(tenant_id, "crm_sync", req.model_dump())

    def ingest_email(self, tenant_id: str, req: EmailIngestRequest) -> IngestResponse:
        """Ingest an email message."""
        return self.ingest(tenant_id, "email_intelligence", req.model_dump(by_alias=True))

    def ingest_call(self, tenant_id: str, req: CallTranscriptRequest) -> IngestResponse:
        """Ingest a call transcript."""
        return self.ingest(tenant_id, "call_transcript", req.model_dump())

    def ingest_calendar(self, tenant_id: str, req: CalendarEventRequest) -> IngestResponse:
        """Ingest a calendar event."""
        return self.ingest(tenant_id, "calendar_context", req.model_dump())

    def ingest_planning(self, tenant_id: str, req: PlanningSessionRequest) -> IngestResponse:
        """Ingest a planning session."""
        return self.ingest(tenant_id, "planning_session", req.model_dump())

    def ingest_meeting_note(self, tenant_id: str, req: MeetingNoteRequest) -> IngestResponse:
        """Ingest a meeting note."""
        return self.ingest(tenant_id, "meeting_notes", req.model_dump())

    def ingest_document(self, tenant_id: str, req: DocumentIngestRequest) -> IngestResponse:
        """Ingest a document."""
        return self.ingest(tenant_id, "document_processing", req.model_dump())
