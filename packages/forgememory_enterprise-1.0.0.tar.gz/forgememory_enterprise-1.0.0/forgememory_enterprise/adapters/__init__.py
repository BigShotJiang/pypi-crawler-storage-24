"""Framework adapters for ForgeMemory Enterprise SDK.

All adapters use lazy imports — the framework packages are only
imported when the adapter methods are actually called. This lets the
SDK be installed without any framework dependency.
"""
