"""AutoGen adapter for ForgeMemory Enterprise.

Provides a decorator to create AutoGen-compatible tool functions,
and a helper to inject memory context into agent system messages.

Usage:
    from forgememory_enterprise.adapters.autogen_adapter import fme_tool, inject_context

    @fme_tool(client, tenant_id="t-123")
    def search_memory(query: str) -> str:
        '''Search organizational memory.'''
        ...  # Implementation is provided by the decorator

    # Or inject context into an AutoGen agent's system message:
    context = inject_context(client, tenant_id="t-123", query="project status")
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from ..client import EnterpriseClient


def fme_tool(
    client: EnterpriseClient,
    tenant_id: str,
    limit: int = 5,
) -> Callable:
    """Decorator that creates an AutoGen-compatible memory search tool.

    The decorated function's body is replaced with a memory search call.
    The function signature and docstring are preserved for AutoGen's
    tool schema generation.
    """

    def decorator(func: Callable) -> Callable:
        def wrapper(query: str) -> str:
            results = client.memory.search(tenant_id, query, limit=limit)
            if not results:
                return "No relevant memories found."
            return "\n".join(f"- [{m.memory_type}] {m.content}" for m in results)

        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper

    return decorator


def inject_context(
    client: EnterpriseClient,
    tenant_id: str,
    query: str,
    max_tokens: int = 500,
) -> str:
    """Get memory context to inject into an AutoGen agent's system message.

    Returns a formatted string suitable for appending to a system prompt.
    """
    ctx = client.memory.context(tenant_id, query, max_tokens=max_tokens)
    if not ctx.context:
        return ""
    return f"\n\n## Relevant Memory Context\n{ctx.context}"


def store_conversation_memory(
    client: EnterpriseClient,
    tenant_id: str,
    content: str,
    source: str = "autogen",
) -> str:
    """Store a conversation summary as an episodic memory.

    Returns the new memory ID.
    """
    from ..types import CreateMemoryRequest

    mem = client.memory.create(
        tenant_id,
        CreateMemoryRequest(
            content=content,
            memory_type="episodic",
            source=source,
        ),
    )
    return mem.id
