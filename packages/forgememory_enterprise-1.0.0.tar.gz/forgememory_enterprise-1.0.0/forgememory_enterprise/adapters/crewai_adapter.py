"""CrewAI adapter for ForgeMemory Enterprise.

Provides a CrewAI-compatible tool and an observer for automatic audit logging.

Usage:
    from forgememory_enterprise.adapters.crewai_adapter import ForgeMemoryTool

    tool = ForgeMemoryTool(client, tenant_id="t-123")
    # Use as a CrewAI tool in your crew
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..client import EnterpriseClient


class ForgeMemoryTool:
    """CrewAI-compatible tool that searches and stores memories.

    This can be registered as a tool in a CrewAI crew. It exposes
    `search` and `store` operations via the standard tool interface.
    """

    name: str = "forgememory"
    description: str = (
        "Search and store information in ForgeMemory Enterprise. "
        "Use 'search:<query>' to find memories or 'store:<content>' to save."
    )

    def __init__(self, client: EnterpriseClient, tenant_id: str) -> None:
        self.client = client
        self.tenant_id = tenant_id

    def _run(self, command: str) -> str:
        """Execute a memory command. Format: 'search:<query>' or 'store:<content>'."""
        if command.startswith("search:"):
            query = command[7:].strip()
            results = self.client.memory.search(self.tenant_id, query, limit=5)
            if not results:
                return "No memories found."
            return "\n".join(f"- [{m.memory_type}] {m.content}" for m in results)

        if command.startswith("store:"):
            content = command[6:].strip()
            from ..types import CreateMemoryRequest
            mem = self.client.memory.create(
                self.tenant_id,
                CreateMemoryRequest(content=content, source="crewai"),
            )
            return f"Stored memory {mem.id}"

        return f"Unknown command format. Use 'search:<query>' or 'store:<content>'. Got: {command[:50]}"

    def run(self, command: str) -> str:
        """CrewAI tool interface."""
        return self._run(command)


class FMECrewObserver:
    """Observer that logs CrewAI agent actions to FME audit trail.

    Usage:
        observer = FMECrewObserver(client, agent_id="crew-agent-1", session_id="sess-1")
        observer.on_tool_use("forgememory", "search:test query")
        observer.on_llm_call(tokens_in=100, tokens_out=50, cost_usd=0.001)
    """

    def __init__(self, client: EnterpriseClient, agent_id: str, session_id: str) -> None:
        self.client = client
        self.agent_id = agent_id
        self.session_id = session_id

    def on_tool_use(self, tool_name: str, tool_input: str = "") -> None:
        self.client.audit.log_action(
            self.agent_id,
            self.session_id,
            action_type="tool_call",
            detail=f"{tool_name}: {tool_input[:200]}",
        )

    def on_llm_call(
        self, tokens_in: int = 0, tokens_out: int = 0, cost_usd: float = 0.0
    ) -> None:
        self.client.audit.log_action(
            self.agent_id,
            self.session_id,
            action_type="llm_request",
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            cost_usd=cost_usd,
        )

    def on_memory_read(self, tenant_id: str, memory_id: str) -> None:
        self.client.audit.log_memory_access(
            self.agent_id, self.session_id, tenant_id, memory_id, "read"
        )

    def on_memory_write(self, tenant_id: str, memory_id: str) -> None:
        self.client.audit.log_memory_access(
            self.agent_id, self.session_id, tenant_id, memory_id, "write"
        )
