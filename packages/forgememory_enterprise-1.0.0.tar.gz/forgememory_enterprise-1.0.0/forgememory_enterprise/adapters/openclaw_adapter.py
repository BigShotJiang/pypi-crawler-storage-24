"""OpenClaw adapter for ForgeMemory Enterprise.

Provides helpers for OpenClaw agents to load memory context
and store session summaries.

Usage:
    from forgememory_enterprise.adapters.openclaw_adapter import (
        get_openclaw_context,
        store_openclaw_session,
    )

    context = get_openclaw_context(client, tenant_id="t-123", query="user preferences")
    # Inject `context` into OpenClaw's system prompt or skill
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import EnterpriseClient


def get_openclaw_context(
    client: EnterpriseClient,
    tenant_id: str,
    query: str,
    max_tokens: int = 500,
) -> str:
    """Retrieve memory context formatted for OpenClaw system prompt injection.

    Returns empty string if no relevant memories found.
    """
    ctx = client.memory.context(tenant_id, query, max_tokens=max_tokens)
    if not ctx.context:
        return ""
    return f"## ForgeMemory Context ({ctx.memories_used} memories)\n{ctx.context}"


def store_openclaw_session(
    client: EnterpriseClient,
    tenant_id: str,
    summary: str,
    agent_id: str = "openclaw",
) -> str:
    """Store an OpenClaw session summary as episodic memory.

    Returns the new memory ID.
    """
    from ..types import CreateMemoryRequest

    mem = client.memory.create(
        tenant_id,
        CreateMemoryRequest(
            content=summary,
            memory_type="episodic",
            source=f"openclaw:{agent_id}",
            importance=7,
        ),
    )
    return mem.id


def search_openclaw_memories(
    client: EnterpriseClient,
    tenant_id: str,
    query: str,
    limit: int = 5,
) -> list[str]:
    """Search memories and return a simple list of content strings.

    Useful for OpenClaw skills that need a flat list of results.
    """
    results = client.memory.search(tenant_id, query, limit=limit)
    return [m.content for m in results]
