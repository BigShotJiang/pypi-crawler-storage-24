"""LangGraph adapter for ForgeMemory Enterprise.

Provides node factories for memory retrieval and storage in LangGraph workflows.

Usage:
    from forgememory_enterprise.adapters.langgraph_adapter import (
        make_memory_retrieve_node,
        make_memory_store_node,
    )

    retrieve = make_memory_retrieve_node(client, tenant_id="t-123")
    store = make_memory_store_node(client, tenant_id="t-123")

    # Add to your LangGraph graph:
    graph.add_node("retrieve_memory", retrieve)
    graph.add_node("store_memory", store)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from ..client import EnterpriseClient


def make_memory_retrieve_node(
    client: EnterpriseClient,
    tenant_id: str,
    limit: int = 5,
    state_query_key: str = "query",
    state_context_key: str = "memory_context",
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Create a LangGraph node that retrieves memory context.

    The node reads `state[state_query_key]` and writes the assembled
    context to `state[state_context_key]`.
    """

    def retrieve_node(state: dict[str, Any]) -> dict[str, Any]:
        query = state.get(state_query_key, "")
        if not query:
            return {state_context_key: ""}

        results = client.memory.search(tenant_id, query, limit=limit)
        context_parts = []
        for mem in results:
            context_parts.append(f"[{mem.memory_type}] {mem.content}")

        return {state_context_key: "\n".join(context_parts)}

    return retrieve_node


def make_memory_store_node(
    client: EnterpriseClient,
    tenant_id: str,
    state_content_key: str = "memory_to_store",
    state_result_key: str = "memory_stored_id",
    source: str = "langgraph",
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Create a LangGraph node that stores a memory.

    The node reads `state[state_content_key]` and writes the new
    memory ID to `state[state_result_key]`.
    """

    def store_node(state: dict[str, Any]) -> dict[str, Any]:
        content = state.get(state_content_key, "")
        if not content:
            return {state_result_key: None}

        from ..types import CreateMemoryRequest

        mem = client.memory.create(
            tenant_id,
            CreateMemoryRequest(content=content, source=source),
        )
        return {state_result_key: mem.id}

    return store_node


def make_memory_context_node(
    client: EnterpriseClient,
    tenant_id: str,
    max_tokens: int = 500,
    state_query_key: str = "query",
    state_context_key: str = "memory_context",
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Create a LangGraph node that gets assembled LLM context.

    Uses the server-side context assembly endpoint which applies
    Stanford scoring (recency + importance + relevance).
    """

    def context_node(state: dict[str, Any]) -> dict[str, Any]:
        query = state.get(state_query_key, "")
        if not query:
            return {state_context_key: ""}

        ctx = client.memory.context(tenant_id, query, max_tokens=max_tokens)
        return {state_context_key: ctx.context}

    return context_node
