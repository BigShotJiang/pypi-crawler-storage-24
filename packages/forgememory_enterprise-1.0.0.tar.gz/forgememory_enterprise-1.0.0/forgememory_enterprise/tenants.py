"""Tenant management, thread operations, and DSR (data subject requests)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._http import request_with_retry, unwrap
from .types import DsrRecord, Memory, TenantSummary, ThreadMemories

if TYPE_CHECKING:
    import httpx


class TenantManager:
    """Manages tenant lifecycle, threads, quota, and DSR workflows."""

    def __init__(self, client: httpx.Client) -> None:
        self._c = client

    # ── Tenant lifecycle ──────────────────────────────────────────────────

    def list_tenants(self, org_id: str | None = None) -> list[TenantSummary]:
        params = {}
        if org_id:
            params["org_id"] = org_id
        resp = self._c.get("/api/v1/tenants", params=params)
        data = unwrap(resp)
        # Server may return {items: [...], total: N} or a flat list
        items = data.get("items", data) if isinstance(data, dict) else data
        return [TenantSummary.model_validate(t) for t in items]

    def get_tenant(self, tenant_id: str) -> TenantSummary:
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}")
        return TenantSummary.model_validate(unwrap(resp))

    def suspend_tenant(self, tenant_id: str, idempotency_key: str | None = None) -> str:
        resp = request_with_retry(
            self._c, "POST", f"/api/v1/tenants/{tenant_id}/suspend",
            idempotency_key=idempotency_key,
        )
        return unwrap(resp)

    def reactivate_tenant(self, tenant_id: str, idempotency_key: str | None = None) -> str:
        resp = request_with_retry(
            self._c, "POST", f"/api/v1/tenants/{tenant_id}/reactivate",
            idempotency_key=idempotency_key,
        )
        return unwrap(resp)

    def delete_tenant(self, tenant_id: str, idempotency_key: str | None = None) -> str:
        resp = request_with_retry(
            self._c, "DELETE", f"/api/v1/tenants/{tenant_id}",
            idempotency_key=idempotency_key,
        )
        return unwrap(resp)

    def archive_tenant(self, tenant_id: str, idempotency_key: str | None = None) -> str:
        """POST /api/v1/tenants/{tenant_id}/archive — Archive a tenant (soft-delete)."""
        resp = request_with_retry(
            self._c, "POST", f"/api/v1/tenants/{tenant_id}/archive",
            json={}, idempotency_key=idempotency_key,
        )
        return unwrap(resp)

    def get_usage(self, tenant_id: str) -> dict:
        """GET /api/v1/tenants/{tenant_id}/usage — Get tenant quota usage."""
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/usage")
        data = unwrap(resp)
        return data if isinstance(data, dict) else {}

    def set_quota(self, tenant_id: str, max_memories: int, idempotency_key: str | None = None) -> str:
        resp = request_with_retry(
            self._c, "PATCH", f"/api/v1/tenants/{tenant_id}/quota",
            json={"max_memories": max_memories}, idempotency_key=idempotency_key,
        )
        return unwrap(resp)

    # ── Thread operations ─────────────────────────────────────────────────

    def get_thread(self, tenant_id: str, thread_id: str) -> ThreadMemories:
        """GET /api/v1/tenants/{tid}/threads/{thread_id} — Get all memories in a thread.

        A thread groups related memories (e.g. a conversation, a workflow run)
        under a shared thread_id for contextual retrieval.

        The server returns: {"summary": {"thread_id": ..., ...}, "memories": [...]}
        This method flattens the response into ThreadMemories.

        Args:
            tenant_id: The tenant owning the memories.
            thread_id: The thread identifier.

        Returns:
            ThreadMemories with thread_id and an ordered list of Memory objects.
        """
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/threads/{thread_id}")
        data = unwrap(resp)
        # Server returns {summary: {thread_id: ...}, memories: [...]}
        # Flatten into the ThreadMemories shape
        if isinstance(data, dict) and "summary" in data:
            summary = data.get("summary", {})
            flat = {
                "thread_id": summary.get("thread_id", thread_id),
                "memories": data.get("memories", []),
                "total": summary.get("memory_count", len(data.get("memories", []))),
            }
            return ThreadMemories.model_validate(flat)
        return ThreadMemories.model_validate(data)

    def link_memories_to_thread(
        self,
        tenant_id: str,
        thread_id: str,
        memory_ids: list[str],
        idempotency_key: str | None = None,
    ) -> str:
        """POST /api/v1/tenants/{tid}/threads — Link memories to a thread.

        Associates one or more existing memories with a thread_id so they can
        be retrieved together via get_thread().

        Args:
            tenant_id: The tenant owning the memories.
            thread_id: The thread identifier to link memories to.
            memory_ids: List of memory IDs to associate with this thread.
            idempotency_key: Optional idempotency key to prevent duplicate links.

        Returns:
            Confirmation message string from the server.
        """
        payload = {"thread_id": thread_id, "memory_ids": memory_ids}
        resp = request_with_retry(
            self._c, "POST", f"/api/v1/tenants/{tenant_id}/threads",
            json=payload, idempotency_key=idempotency_key,
        )
        return unwrap(resp)

    # ── DSR (Data Subject Requests) ───────────────────────────────────────

    def create_dsr(
        self,
        tenant_id: str,
        subject_email: str,
        request_type: str,
        description: str = "",
        idempotency_key: str | None = None,
    ) -> DsrRecord:
        """POST /api/v1/tenants/{tid}/dsr/request — Create a DSR.

        Creates a Data Subject Request (GDPR Article 15/17) for erasure,
        access, portability, or rectification of personal data.

        Args:
            tenant_id: The tenant scope for this DSR.
            subject_email: Email address of the data subject.
            request_type: One of "erasure", "access", "portability", "rectification".
            description: Optional human-readable description of the request.
            idempotency_key: Optional idempotency key to prevent duplicate requests.

        Returns:
            DsrRecord with the new DSR ID, status, and metadata.
        """
        payload: dict = {"subject_email": subject_email, "request_type": request_type}
        if description:
            payload["description"] = description
        resp = request_with_retry(
            self._c, "POST", f"/api/v1/tenants/{tenant_id}/dsr/request",
            json=payload, idempotency_key=idempotency_key,
        )
        return DsrRecord.model_validate(unwrap(resp))

    def list_dsrs(self, tenant_id: str) -> list[DsrRecord]:
        """GET /api/v1/tenants/{tid}/dsr — List all DSRs for a tenant.

        Args:
            tenant_id: The tenant to list DSRs for.

        Returns:
            List of DsrRecord objects ordered by creation time (newest first).
        """
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/dsr")
        data = unwrap(resp)
        return [DsrRecord.model_validate(d) for d in data]

    def get_dsr(self, tenant_id: str, dsr_id: str) -> DsrRecord:
        """GET /api/v1/tenants/{tid}/dsr/{dsr_id} — Get a specific DSR.

        Args:
            tenant_id: The tenant owning the DSR.
            dsr_id: The DSR identifier.

        Returns:
            DsrRecord with current status and all metadata.
        """
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/dsr/{dsr_id}")
        return DsrRecord.model_validate(unwrap(resp))

    def approve_dsr(
        self,
        tenant_id: str,
        dsr_id: str,
        notes: str = "",
        idempotency_key: str | None = None,
    ) -> DsrRecord:
        """POST /api/v1/tenants/{tid}/dsr/{dsr_id}/approve — Approve a DSR.

        Approving an erasure DSR triggers deletion of all memories belonging
        to the subject. Other request types produce an export or acknowledgment.

        Args:
            tenant_id: The tenant owning the DSR.
            dsr_id: The DSR identifier to approve.
            notes: Optional compliance notes recorded with the approval.
            idempotency_key: Optional idempotency key.

        Returns:
            Updated DsrRecord with status set to "approved".
        """
        payload: dict = {}
        if notes:
            payload["notes"] = notes
        resp = request_with_retry(
            self._c, "POST", f"/api/v1/tenants/{tenant_id}/dsr/{dsr_id}/approve",
            json=payload, idempotency_key=idempotency_key,
        )
        return DsrRecord.model_validate(unwrap(resp))

    def reject_dsr(
        self,
        tenant_id: str,
        dsr_id: str,
        reason: str = "",
        idempotency_key: str | None = None,
    ) -> DsrRecord:
        """POST /api/v1/tenants/{tid}/dsr/{dsr_id}/reject — Reject a DSR.

        Args:
            tenant_id: The tenant owning the DSR.
            dsr_id: The DSR identifier to reject.
            reason: Required rejection reason recorded for compliance audit.
            idempotency_key: Optional idempotency key.

        Returns:
            Updated DsrRecord with status set to "rejected".
        """
        payload: dict = {}
        if reason:
            payload["reason"] = reason
        resp = request_with_retry(
            self._c, "POST", f"/api/v1/tenants/{tenant_id}/dsr/{dsr_id}/reject",
            json=payload, idempotency_key=idempotency_key,
        )
        return DsrRecord.model_validate(unwrap(resp))
