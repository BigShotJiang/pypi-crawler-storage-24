"""Compliance reporting and evidence for GDPR, SOX, and FINRA."""

from __future__ import annotations

import httpx

from ._http import unwrap
from .types import (
    AuditTrailReport,
    DataAccessReport,
    DsarReport,
    RetentionComplianceReport,
)


class ComplianceClient:
    """Manager for generating compliance and regulatory reports."""

    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def get_audit_trail(
        self, tenant_id: str, start: str | None = None, end: str | None = None
    ) -> AuditTrailReport:
        """Get an audit trail report with chain-of-custody hash.
        
        Args:
            tenant_id: Tenant ID.
            start: Optional start time (ISO 8601).
            end: Optional end time (ISO 8601).
        """
        params = {}
        if start:
            params["start"] = start
        if end:
            params["end"] = end

        response = self._client.get(f"/api/v1/tenants/{tenant_id}/reports/audit-trail", params=params)
        return AuditTrailReport(**unwrap(response))

    def export_audit_trail(
        self, tenant_id: str, start: str | None = None, end: str | None = None, format: str = "json"
    ) -> str | dict:
        """Export the audit trail to CSV or JSON.
        
        Args:
            tenant_id: Tenant ID.
            start: Optional start time.
            end: Optional end time.
            format: 'json' or 'csv'.
        """
        params = {"format": format}
        if start:
            params["start"] = start
        if end:
            params["end"] = end

        response = self._client.get(f"/api/v1/tenants/{tenant_id}/reports/audit-trail/export", params=params)
        if format == "csv":
            response.raise_for_status()
            return response.text
        return unwrap(response)

    def get_data_access_report(
        self, tenant_id: str, start: str | None = None, end: str | None = None
    ) -> DataAccessReport:
        """Get a report of who accessed data within the tenant."""
        params = {}
        if start:
            params["start"] = start
        if end:
            params["end"] = end

        response = self._client.get(f"/api/v1/tenants/{tenant_id}/reports/data-access", params=params)
        return DataAccessReport(**unwrap(response))

    def get_dsar_report(self, tenant_id: str, client_id: str) -> DsarReport:
        """Get a Data Subject Access Request (DSAR) report."""
        params = {"client_id": client_id}
        response = self._client.get(f"/api/v1/tenants/{tenant_id}/reports/dsar", params=params)
        return DsarReport(**unwrap(response))

    def get_retention_compliance(self, tenant_id: str) -> RetentionComplianceReport:
        """Get a retention policy compliance summary."""
        response = self._client.get(f"/api/v1/tenants/{tenant_id}/reports/retention")
        return RetentionComplianceReport(**unwrap(response))
