"""ForgeMemory Enterprise SDK exceptions."""


class EnterpriseError(Exception):
    """Base exception for all FME SDK errors."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class AuthenticationError(EnterpriseError):
    """API key is missing, invalid, expired, or revoked (401)."""

    def __init__(self, message: str = "Authentication failed"):
        super().__init__(message, status_code=401)


class ForbiddenError(EnterpriseError):
    """Caller lacks permission for this operation (403)."""

    def __init__(self, message: str = "Forbidden"):
        super().__init__(message, status_code=403)


class NotFoundError(EnterpriseError):
    """Requested resource does not exist (404)."""

    def __init__(self, message: str = "Not found"):
        super().__init__(message, status_code=404)


class BudgetExceededError(EnterpriseError):
    """Agent has exceeded its daily or monthly cost budget (402)."""

    def __init__(self, message: str = "Budget exceeded"):
        super().__init__(message, status_code=402)


class RateLimitedError(EnterpriseError):
    """Too many requests — rate limit exceeded (429)."""

    def __init__(self, message: str = "Rate limited"):
        super().__init__(message, status_code=429)


class LegalHoldError(EnterpriseError):
    """Operation blocked by a GDPR legal hold (403)."""

    def __init__(self, message: str = "Blocked by legal hold"):
        super().__init__(message, status_code=403)
