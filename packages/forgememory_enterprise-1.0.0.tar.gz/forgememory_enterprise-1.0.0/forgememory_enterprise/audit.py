"""Agent audit logging — actions, memory access, delegations, costs, ZKAT."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._http import unwrap
from .types import (
    AgentAuditStats,
    AuditAction,
    ChainVerifyResult,
    CostEntry,
    Delegation,
    Epoch,
    EpochVerifyResult,
    MemoryAccess,
)

if TYPE_CHECKING:
    import httpx


class AuditLogger:
    """Log and query agent audit trail (append-only)."""

    def __init__(self, client: httpx.Client) -> None:
        self._c = client

    # ── Actions ───────────────────────────────────────────────────────

    def log_action(
        self,
        agent_id: str,
        session_id: str,
        action_type: str,
        detail: str = "",
        tokens_in: int = 0,
        tokens_out: int = 0,
        cost_usd: float = 0.0,
    ) -> AuditAction:
        resp = self._c.post(
            "/api/v1/audit/actions",
            json={
                "agent_id": agent_id,
                "session_id": session_id,
                "action_type": action_type,
                "detail": detail,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "cost_usd": cost_usd,
            },
        )
        return AuditAction.model_validate(unwrap(resp))

    def get_session_actions(self, session_id: str) -> list[AuditAction]:
        resp = self._c.get(f"/api/v1/audit/actions/session/{session_id}")
        data = unwrap(resp)
        return [AuditAction.model_validate(a) for a in data]

    def get_session_timeline(self, session_id: str) -> list[AuditAction]:
        # NOTE: Server route not yet implemented
        resp = self._c.get(f"/api/v1/audit/timeline/{session_id}")
        data = unwrap(resp)
        return [AuditAction.model_validate(a) for a in data]

    # ── Memory Access ─────────────────────────────────────────────────

    def log_memory_access(
        self,
        agent_id: str,
        session_id: str,
        tenant_id: str,
        memory_id: str,
        access_type: str,
    ) -> MemoryAccess:
        resp = self._c.post(
            "/api/v1/audit/memory-access",
            json={
                "agent_id": agent_id,
                "session_id": session_id,
                "tenant_id": tenant_id,
                "memory_id": memory_id,
                "access_type": access_type,
            },
        )
        return MemoryAccess.model_validate(unwrap(resp))

    def get_agent_memory_access(self, memory_id: str) -> list[MemoryAccess]:
        """Get memory access records for a given memory_id.

        Note: The server route parameter is memory_id, not agent_id.
        Route: GET /api/v1/audit/memory-access/{memory_id}
        """
        resp = self._c.get(f"/api/v1/audit/memory-access/{memory_id}")
        data = unwrap(resp)
        return [MemoryAccess.model_validate(a) for a in data]

    def get_memory_access_by_memory(self, memory_id: str) -> list[MemoryAccess]:
        # NOTE: Server route not yet implemented — use get_agent_memory_access(memory_id) instead
        resp = self._c.get(f"/api/v1/audit/memory-access/{memory_id}")
        data = unwrap(resp)
        return [MemoryAccess.model_validate(a) for a in data]

    # ── Delegations ───────────────────────────────────────────────────

    def log_delegation(
        self,
        from_agent_id: str,
        to_agent_id: str,
        session_id: str,
        task: str,
    ) -> Delegation:
        resp = self._c.post(
            "/api/v1/audit/delegations",
            json={
                "from_agent_id": from_agent_id,
                "to_agent_id": to_agent_id,
                "session_id": session_id,
                "task": task,
            },
        )
        return Delegation.model_validate(unwrap(resp))

    def complete_delegation(self, delegation_id: int, status: str = "completed") -> str:
        resp = self._c.post(
            f"/api/v1/audit/delegations/{delegation_id}/complete",
            json={"status": status},
        )
        return unwrap(resp)

    def get_delegation_chain(self, correlation_id: str) -> list[Delegation]:
        """GET /api/v1/audit/delegations/chain/{correlation_id} — Get a full delegation chain."""
        resp = self._c.get(f"/api/v1/audit/delegations/chain/{correlation_id}")
        data = unwrap(resp)
        return [Delegation.model_validate(d) for d in data]

    # ── Costs ─────────────────────────────────────────────────────────

    def get_cost_summary(self, agent_id: str) -> list[CostEntry]:
        """Get daily cost breakdown for an agent (legacy list format).

        Route: GET /api/v1/costs/budget/{agent_id}
        """
        resp = self._c.get(f"/api/v1/costs/budget/{agent_id}")
        data = unwrap(resp)
        return [CostEntry.model_validate(c) for c in data]

    def get_agent_cost_summary(self, agent_id: str, days: int = 30) -> "AgentCostSummary":
        """Get aggregate cost summary for an agent over the last N days.

        Route: GET /api/v1/costs/budget/{agent_id}
        """
        from .types import AgentCostSummary

        resp = self._c.get(
            f"/api/v1/costs/budget/{agent_id}",
            params={"days": str(days)},
        )
        data = unwrap(resp)
        return AgentCostSummary.model_validate(data)

    # ── Stats ─────────────────────────────────────────────────────────

    def stats(self) -> AgentAuditStats:
        resp = self._c.get("/api/v1/admin/audit-stats")
        return AgentAuditStats.model_validate(unwrap(resp))

    # ── ZKAT (Zero-Knowledge Audit Trail) ──────────────────────────────

    def verify_chain(self, tenant_id: str) -> ChainVerifyResult:
        """Verify the append-only audit chain integrity for a tenant.

        Route: GET /api/v1/tenants/{tenant_id}/audit/chain-verify
        """
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/audit/chain-verify")
        return ChainVerifyResult.model_validate(unwrap(resp))

    def list_epochs(self, tenant_id: str) -> list[Epoch]:
        """List all sealed ZKAT Merkle tree epochs for a tenant.

        Route: GET /api/v1/tenants/{tenant_id}/audit/zkat/epochs
        """
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/audit/zkat/epochs")
        data = unwrap(resp)
        return [Epoch.model_validate(e) for e in data]

    def verify_epochs(self, tenant_id: str) -> EpochVerifyResult:
        """Verify all ZKAT epochs for a tenant.

        Route: GET /api/v1/tenants/{tenant_id}/audit/zkat/verify
        """
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/audit/zkat/verify")
        return EpochVerifyResult.model_validate(unwrap(resp))

    # ── Examiner Export ────────────────────────────────────────────────

    def export_examiner(
        self,
        tenant_id: str,
        start_date: str,
        end_date: str,
        include_zkat: bool = False,
    ) -> bytes:
        """Export a compliance examiner package as a ZIP archive.

        Route: POST /api/v1/tenants/{tenant_id}/compliance/examiner-export

        Args:
            tenant_id: Tenant ID.
            start_date: Start date (ISO 8601).
            end_date: End date (ISO 8601).
            include_zkat: Whether to include ZKAT epoch data in the export.

        Returns:
            Raw ZIP bytes.
        """
        resp = self._c.post(
            f"/api/v1/tenants/{tenant_id}/compliance/examiner-export",
            json={
                "start_date": start_date,
                "end_date": end_date,
                "include_zkat": include_zkat,
            },
        )
        resp.raise_for_status()
        return resp.content
