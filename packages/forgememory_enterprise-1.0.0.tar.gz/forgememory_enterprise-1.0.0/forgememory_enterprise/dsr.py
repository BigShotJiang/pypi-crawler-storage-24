"""DSR (Data Subject Request) management for GDPR compliance."""

from __future__ import annotations

from typing import Any

import httpx

from ._http import unwrap
from .types import DsrRecord


class DsrClient:
    """Manager for Data Subject Requests (DSRs) such as GDPR erasure or access."""

    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def create_request(
        self,
        tenant_id: str,
        request_type: str,
        subject_id: str,
        subject_type: str = "client",
        reason: str | None = None,
    ) -> DsrRecord:
        """Submit a new Data Subject Request.
        
        Args:
            tenant_id: Tenant ID.
            request_type: Type of request (e.g., 'erasure', 'access').
            subject_id: ID of the data subject (e.g. user_id or client_id).
            subject_type: Type of subject, defaults to 'client'.
            reason: Optional justification.
        """
        payload = {"request_type": request_type, "subject_id": subject_id, "subject_type": subject_type}
        if reason is not None:
            payload["reason"] = reason

        response = self._client.post(f"/api/v1/tenants/{tenant_id}/dsr/request", json=payload)
        return DsrRecord(**unwrap(response))

    def list_requests(self, tenant_id: str) -> list[DsrRecord]:
        """List all DSRs for a tenant."""
        response = self._client.get(f"/api/v1/tenants/{tenant_id}/dsr")
        data = unwrap(response)
        return [DsrRecord(**item) for item in data]

    def get_request(self, tenant_id: str, dsr_id: str) -> DsrRecord:
        """Get a specific DSR."""
        response = self._client.get(f"/api/v1/tenants/{tenant_id}/dsr/{dsr_id}")
        return DsrRecord(**unwrap(response))

    def approve_request(
        self, tenant_id: str, dsr_id: str, reviewer_notes: str | None = None
    ) -> DsrRecord:
        """Approve a DSR."""
        payload = {}
        if reviewer_notes is not None:
            payload["reviewer_notes"] = reviewer_notes

        response = self._client.post(f"/api/v1/tenants/{tenant_id}/dsr/{dsr_id}/approve", json=payload)
        return DsrRecord(**unwrap(response))

    def reject_request(self, tenant_id: str, dsr_id: str, reason: str) -> DsrRecord:
        """Reject a DSR with a required reason."""
        response = self._client.post(f"/api/v1/tenants/{tenant_id}/dsr/{dsr_id}/reject", json={"reason": reason})
        return DsrRecord(**unwrap(response))

    def execute_request(self, tenant_id: str, dsr_id: str) -> DsrRecord:
        """Execute an approved DSR."""
        response = self._client.post(f"/api/v1/tenants/{tenant_id}/dsr/{dsr_id}/execute")
        return DsrRecord(**unwrap(response))
