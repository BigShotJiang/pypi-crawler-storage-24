"""Aegis sandbox sessions — isolated agent query execution with DLP + policy enforcement."""

from __future__ import annotations

from typing import Any

import httpx

from ._http import require_non_empty, unwrap


class SandboxClient:
    """Manager for Aegis sandbox sessions and sandboxed query execution."""

    def __init__(self, client: httpx.Client) -> None:
        self._c = client

    # ── Session lifecycle ──────────────────────────────────────────────

    def create_session(
        self,
        tenant_id: str,
        *,
        expires_in_secs: int = 3600,
        rate_limit_rpm: int = 60,
        max_queries: int | None = None,
        sensitivity_ceiling: int = 1,
        dlp_mode: str = "strict",
        policy_preset: list[str] | None = None,
        agent_id: str | None = None,
    ) -> dict:
        """Create a new sandbox session for isolated agent query execution.

        Returns dict with session_id, session_token, expires_at, tenant_id, status.
        """
        require_non_empty(tenant_id, "tenant_id")
        payload: dict[str, Any] = {
            "expires_in_secs": expires_in_secs,
            "rate_limit_rpm": rate_limit_rpm,
            "sensitivity_ceiling": sensitivity_ceiling,
            "dlp_mode": dlp_mode,
        }
        if max_queries is not None:
            payload["max_queries"] = max_queries
        if policy_preset is not None:
            payload["policy_preset"] = policy_preset
        if agent_id is not None:
            payload["agent_id"] = agent_id
        resp = self._c.post(
            f"/api/v1/tenants/{tenant_id}/sandbox/sessions",
            json=payload,
        )
        return unwrap(resp)

    def list_sessions(self, tenant_id: str) -> list:
        """List all sandbox sessions for a tenant."""
        require_non_empty(tenant_id, "tenant_id")
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/sandbox/sessions")
        return unwrap(resp)

    def get_session(self, tenant_id: str, session_id: str) -> dict:
        """Get a single sandbox session by ID."""
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(session_id, "session_id")
        resp = self._c.get(
            f"/api/v1/tenants/{tenant_id}/sandbox/sessions/{session_id}"
        )
        return unwrap(resp)

    def revoke_session(self, tenant_id: str, session_id: str) -> dict:
        """Revoke (delete) a sandbox session. Requires Admin or Manager role."""
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(session_id, "session_id")
        resp = self._c.delete(
            f"/api/v1/tenants/{tenant_id}/sandbox/sessions/{session_id}"
        )
        return unwrap(resp)

    def execute_query(
        self,
        tenant_id: str,
        session_id: str,
        session_token: str,
        query: str,
        *,
        detail: str = "full",
        limit: int = 20,
    ) -> dict:
        """Execute a sandboxed query using the session token (not API key).

        The session token (sbox_tok_...) is sent as Authorization: Bearer.
        DLP scrubbing and policy enforcement apply to the response.

        Returns dict with results, query_id, dlp_entities_removed,
        policies_evaluated, policies_blocked, receipt_hash, queries_remaining.
        """
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(session_id, "session_id")
        require_non_empty(session_token, "session_token")
        require_non_empty(query, "query")
        resp = self._c.post(
            f"/api/v1/tenants/{tenant_id}/sandbox/sessions/{session_id}/query",
            json={"query": query, "detail": detail, "limit": limit},
            headers={"Authorization": f"Bearer {session_token}"},
        )
        return unwrap(resp)

    def get_receipt(self, tenant_id: str, session_id: str) -> dict:
        """Get the tamper-evident ZKAT audit receipt for a sandbox session.

        Returns dict with session_id, query_count, total_dlp_removals,
        zkat_epoch_ids, chain_proof, session_log.
        """
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(session_id, "session_id")
        resp = self._c.get(
            f"/api/v1/tenants/{tenant_id}/sandbox/sessions/{session_id}/receipt"
        )
        return unwrap(resp)
