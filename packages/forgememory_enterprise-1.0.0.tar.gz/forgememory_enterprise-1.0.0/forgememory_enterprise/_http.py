"""Shared HTTP client and response unwrapping for FME SDK."""

from __future__ import annotations

import random
import time
from typing import Any

import httpx

from .exceptions import (
    AuthenticationError,
    BudgetExceededError,
    EnterpriseError,
    ForbiddenError,
    LegalHoldError,
    NotFoundError,
    RateLimitedError,
)


def make_client(
    base_url: str,
    api_key: str,
    timeout: float = 30.0,
    transport: httpx.BaseTransport | None = None,
    agent_type: str | None = None,
    strict_dlp: bool = False,
) -> httpx.Client:
    """Create an httpx.Client configured for FME."""
    headers = {"X-API-Key": api_key, "Content-Type": "application/json"}
    if agent_type:
        headers["X-FME-Agent-Type"] = agent_type
    if strict_dlp:
        headers["X-FME-Strict-DLP"] = "true"

    kwargs: dict[str, Any] = {
        "base_url": base_url,
        "headers": headers,
        "timeout": timeout,
    }
    if transport is not None:
        kwargs["transport"] = transport
    return httpx.Client(**kwargs)


class RateLimitState:
    """Tracks rate limit state parsed from response headers."""

    def __init__(self) -> None:
        self.remaining: int | None = None
        self.retry_after: int | None = None

    def update(self, response: httpx.Response) -> None:
        """Parse X-RateLimit-Remaining and Retry-After headers from a response."""
        raw_remaining = response.headers.get("X-RateLimit-Remaining")
        if raw_remaining is not None:
            try:
                self.remaining = int(raw_remaining)
            except ValueError:
                pass

        raw_retry = response.headers.get("Retry-After")
        if raw_retry is not None:
            try:
                self.retry_after = int(raw_retry)
            except ValueError:
                pass


def unwrap(response: httpx.Response, rate_limit_state: RateLimitState | None = None) -> Any:
    """Unwrap an ApiResponse<T> envelope, raising on errors.

    The server returns: {"success": bool, "data": T | null, "error": str | null}

    If rate_limit_state is provided, X-RateLimit-Remaining and Retry-After headers
    are parsed and stored on it after every response.
    """
    # Always parse rate limit headers when state tracker is provided
    if rate_limit_state is not None:
        rate_limit_state.update(response)

    status = response.status_code

    if status == 401:
        raise AuthenticationError(_extract_error(response))
    if status == 402:
        raise BudgetExceededError(_extract_error(response))
    if status == 403:
        msg = _extract_error(response)
        if "legal hold" in msg.lower() or "retention" in msg.lower():
            raise LegalHoldError(msg)
        raise ForbiddenError(msg)
    if status == 404:
        raise NotFoundError(_extract_error(response))
    if status == 429:
        raise RateLimitedError(_extract_error(response))

    if status >= 400:
        raise EnterpriseError(_extract_error(response), status_code=status)

    body = response.json()

    # Handle ApiResponse wrapper
    if isinstance(body, dict) and "success" in body:
        if not body["success"]:
            raise EnterpriseError(body.get("error", "Unknown error"))
        return body.get("data")

    return body


# Allowed characters for idempotency keys
_IDEMPOTENCY_KEY_CHARS = frozenset(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-"
)

MAX_RETRIES = 3

# Transient 5xx status codes that are safe to retry
_RETRYABLE_5XX = frozenset({500, 502, 503, 504})


def _should_retry(status_code: int) -> bool:
    """Return True if the HTTP status code warrants a retry."""
    return status_code == 429 or status_code in _RETRYABLE_5XX


def _retry_delay(status_code: int, attempt: int, retry_after_header: str | None) -> float:
    """Calculate retry delay in seconds using exponential backoff with jitter."""
    if status_code == 429 and retry_after_header is not None:
        try:
            base = float(retry_after_header)
        except ValueError:
            base = 1.0
    else:
        # For 5xx, use a shorter fixed base backoff: 0.5, 1, 2 seconds
        base = 0.5
    return min(base * (2 ** attempt) + random.uniform(0.0, 1.0), 60.0)


def request_with_retry(
    client: httpx.Client,
    method: str,
    url: str,
    rate_limit_state: RateLimitState | None = None,
    idempotency_key: str | None = None,
    **kwargs: Any,
) -> httpx.Response:
    """Make an HTTP request with automatic retry for 429 and transient 5xx errors.

    Retries up to MAX_RETRIES times on HTTP 429 and transient 5xx (500, 502, 503, 504).
    Each retry waits using exponential backoff with jitter.

    The idempotency key is validated before sending and attached to mutating
    requests (POST, PUT, PATCH, DELETE).

    Args:
        client: The httpx.Client to use.
        method: HTTP method (GET, POST, PATCH, DELETE, etc.).
        url: Request URL (relative to client base_url).
        rate_limit_state: Optional RateLimitState to update from response headers.
        idempotency_key: Optional idempotency key for mutating requests.
            Must be <= 128 chars, alphanumeric plus dash/underscore only.
        **kwargs: Additional kwargs forwarded to client.request().

    Returns:
        The httpx.Response (possibly from a retry).

    Raises:
        ValueError: If idempotency_key fails validation.
    """
    # Validate idempotency key before sending any request
    if idempotency_key is not None:
        if len(idempotency_key) > 128:
            raise ValueError(
                f"Idempotency key too long ({len(idempotency_key)} chars, max 128)"
            )
        invalid_chars = set(idempotency_key) - _IDEMPOTENCY_KEY_CHARS
        if invalid_chars:
            raise ValueError(
                f"Idempotency key contains invalid characters: {invalid_chars!r}. "
                "Only alphanumeric, dash, and underscore are allowed."
            )

    headers = dict(kwargs.pop("headers", {}) or {})
    if idempotency_key is not None and method.upper() in ("POST", "PATCH", "DELETE", "PUT"):
        headers["Idempotency-Key"] = idempotency_key

    for attempt in range(MAX_RETRIES + 1):
        response = client.request(method, url, headers=headers, **kwargs)

        if not _should_retry(response.status_code) or attempt == MAX_RETRIES:
            break

        # Exponential backoff with jitter
        retry_after_raw = response.headers.get("Retry-After")
        sleep_time = _retry_delay(response.status_code, attempt, retry_after_raw)
        time.sleep(sleep_time)

    if rate_limit_state is not None:
        rate_limit_state.update(response)

    return response


def require_non_empty(value: str, name: str) -> None:
    """Raise ValueError if value is None, empty, or whitespace-only."""
    if not value or not value.strip():
        raise ValueError(f"{name} must be a non-empty string, got {value!r}")


def require_positive(value: int, name: str) -> None:
    """Raise ValueError if value is not a positive integer (> 0)."""
    if value <= 0:
        raise ValueError(f"{name} must be a positive integer, got {value!r}")


def _extract_error(response: httpx.Response) -> str:
    """Extract error message from response body.

    Handles two server error formats:
    - Legacy envelope: {"error": "string message"}
    - Structured errors: {"error": {"code": "...", "message": "..."}}
    """
    try:
        body = response.json()
        if isinstance(body, dict):
            err = body.get("error", body.get("message", response.text))
            if isinstance(err, dict):
                err = err.get("message", str(err))
            return err
    except Exception:
        pass
    return response.text or f"HTTP {response.status_code}"
