"""Dynamic Entity Graph operations — nodes, edges, and traversal."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ._http import unwrap
from .types import (
    CreateEdgeRequest,
    CreateEntityRequest,
    EntityNode,
    GraphEdge,
    TraversalResult,
    UpdateEdgeRequest,
    UpdateEntityRequest,
)

if TYPE_CHECKING:
    import httpx


class EntityGraphClient:
    """CRUD for the dynamic entity graph — nodes, edges, and BFS traversal.

    The entity graph is vertical-agnostic: households, contacts, products,
    fleets, and any business concept are all represented as typed nodes
    connected by relationship edges.
    """

    def __init__(self, client: httpx.Client) -> None:
        self._c = client

    # ── Entity (Node) CRUD ───────────────────────────────────────────

    def create_entity(self, tenant_id: str, req: CreateEntityRequest) -> EntityNode:
        """Create a new entity node."""
        payload = {k: v for k, v in req.model_dump().items() if v is not None}
        resp = self._c.post(f"/api/v1/tenants/{tenant_id}/entities", json=payload)
        return EntityNode.model_validate(unwrap(resp))

    def get_entity(self, tenant_id: str, name: str) -> EntityNode:
        """Get an entity by name (the entity's primary key)."""
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/entities/{name}")
        return EntityNode.model_validate(unwrap(resp))

    def list_entities(
        self,
        tenant_id: str,
        entity_type: str | None = None,
        limit: int = 100,
    ) -> list[EntityNode]:
        """List entities, optionally filtered by type."""
        params: dict[str, str] = {"limit": str(limit)}
        if entity_type:
            params["entity_type"] = entity_type
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/entities", params=params)
        data = unwrap(resp)
        return [EntityNode.model_validate(e) for e in data]

    def update_entity(self, tenant_id: str, name: str, req: UpdateEntityRequest) -> EntityNode:
        """Partially update an entity node."""
        payload = {k: v for k, v in req.model_dump().items() if v is not None}
        resp = self._c.patch(f"/api/v1/tenants/{tenant_id}/entities/{name}", json=payload)
        return EntityNode.model_validate(unwrap(resp))

    def delete_entity(self, tenant_id: str, name: str) -> str:
        """Delete an entity and its edges. Returns the deleted entity name."""
        resp = self._c.delete(f"/api/v1/tenants/{tenant_id}/entities/{name}")
        data = unwrap(resp)
        if isinstance(data, dict):
            return data.get("deleted", name)
        return data

    # ── Edge CRUD ────────────────────────────────────────────────────

    def create_edge(self, tenant_id: str, req: CreateEdgeRequest) -> GraphEdge:
        """Create an edge (relationship) between two entities.

        When ``req.force`` is ``True``, any existing active edge with the same
        (source, target, relationship) triple is automatically superseded before
        creating the new one.
        """
        payload = {k: v for k, v in req.model_dump().items() if v is not None}
        resp = self._c.post(f"/api/v1/tenants/{tenant_id}/edges", json=payload)
        return GraphEdge.model_validate(unwrap(resp))

    def update_edge(
        self,
        tenant_id: str,
        edge_id: str,
        req: UpdateEdgeRequest,
    ) -> GraphEdge:
        """Partially update an edge (close it or adjust its weight).

        Args:
            tenant_id: The tenant.
            edge_id: Edge UUID.
            req: Fields to update (``valid_to`` and/or ``weight``).
        """
        payload = {k: v for k, v in req.model_dump().items() if v is not None}
        resp = self._c.patch(
            f"/api/v1/tenants/{tenant_id}/edges/{edge_id}",
            json=payload,
        )
        return GraphEdge.model_validate(unwrap(resp))

    def list_edges(
        self,
        tenant_id: str,
        entity_type: str | None = None,
        limit: int = 100,
        as_of: str | None = None,
        include_superseded: bool | None = None,
    ) -> list[GraphEdge]:
        """List edges, optionally filtered by entity_type.

        Args:
            tenant_id: The tenant.
            entity_type: Optional type filter.
            limit: Maximum number of edges to return (default 100).
            as_of: ISO 8601 timestamp — return only edges that were
                active at this point in time (valid_from <= as_of < valid_to).
            include_superseded: If ``True``, also return edges that have
                been closed (valid_to is set). Default server behaviour is
                to show only active edges.
        """
        params: dict[str, str] = {"limit": str(limit)}
        if entity_type:
            params["entity_type"] = entity_type
        if as_of is not None:
            params["as_of"] = as_of
        if include_superseded is not None:
            params["include_superseded"] = str(include_superseded).lower()
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/edges", params=params)
        data = unwrap(resp)
        return [GraphEdge.model_validate(e) for e in data]

    def delete_edge(self, tenant_id: str, edge_id: str) -> str:
        """Delete an edge by ID. Returns the deleted edge ID."""
        resp = self._c.delete(f"/api/v1/tenants/{tenant_id}/edges/{edge_id}")
        data = unwrap(resp)
        if isinstance(data, dict):
            return data.get("deleted", edge_id)
        return data

    # ── Graph Traversal ──────────────────────────────────────────────

    def traverse(
        self,
        tenant_id: str,
        name: str,
        depth: int = 2,
        relationship: str | None = None,
        as_of: str | None = None,
    ) -> TraversalResult:
        """BFS traverse the graph from a starting entity.

        Args:
            tenant_id: The tenant.
            name: Starting entity name (the entity's primary key).
            depth: Maximum traversal depth (default 2).
            relationship: Optional filter — only follow edges of this type.
            as_of: ISO 8601 timestamp — traverse the graph as it existed
                at this point in time. Edges whose ``valid_from`` / ``valid_to``
                window does not contain ``as_of`` are excluded.
        """
        params: dict[str, str] = {"depth": str(depth)}
        if relationship:
            params["relationship"] = relationship
        if as_of is not None:
            params["as_of"] = as_of
        resp = self._c.get(
            f"/api/v1/tenants/{tenant_id}/entities/{name}/graph",
            params=params,
        )
        return TraversalResult.model_validate(unwrap(resp))

    def extract_all(self, tenant_id: str) -> dict[str, Any]:
        """POST /api/v1/tenants/{tid}/entities/extract-all — Extract entities from all memories.

        Runs entity extraction on all memories in the tenant that have not yet
        been processed for entity mentions.

        Returns:
            Dict with extracted_count and skipped_count.
        """
        resp = self._c.post(f"/api/v1/tenants/{tenant_id}/entities/extract-all", json={})
        data = unwrap(resp)
        return data if isinstance(data, dict) else {}
