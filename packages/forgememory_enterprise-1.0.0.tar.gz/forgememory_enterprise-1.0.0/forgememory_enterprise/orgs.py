"""Organization, user, and branch management."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._http import unwrap
from .types import Branch, GlobalStats, Org, TenantSummary, User

if TYPE_CHECKING:
    import httpx


class OrgManager:
    """Manages organizations, users, branches, and provisioning."""

    def __init__(self, client: httpx.Client) -> None:
        self._c = client

    # ── Orgs ──────────────────────────────────────────────────────────

    def create_org(self, name: str, slug: str) -> Org:
        resp = self._c.post("/api/v1/orgs", json={"name": name, "slug": slug})
        return Org.model_validate(unwrap(resp))

    def list_orgs(self) -> list[Org]:
        resp = self._c.get("/api/v1/orgs")
        data = unwrap(resp)
        items = data.get("items", data) if isinstance(data, dict) else data
        return [Org.model_validate(o) for o in items]

    def get_org(self, slug: str) -> Org:
        resp = self._c.get(f"/api/v1/orgs/{slug}")
        return Org.model_validate(unwrap(resp))

    # ── Users ─────────────────────────────────────────────────────────

    def create_user(self, org_id: str, email: str, display_name: str, role: str = "viewer") -> User:
        resp = self._c.post(
            f"/api/v1/orgs/{org_id}/users",
            json={"org_id": org_id, "email": email, "display_name": display_name, "role": role},
        )
        return User.model_validate(unwrap(resp))

    def list_users(self, org_id: str) -> list[User]:
        resp = self._c.get(f"/api/v1/orgs/{org_id}/users")
        data = unwrap(resp)
        return [User.model_validate(u) for u in data]

    # ── Branches ──────────────────────────────────────────────────────

    def create_branch(self, org_id: str, name: str, parent_id: str | None = None) -> Branch:
        # NOTE: Server route not yet implemented
        payload: dict = {"org_id": org_id, "name": name}
        if parent_id:
            payload["parent_id"] = parent_id
        resp = self._c.post("/api/v1/branches", json=payload)
        return Branch.model_validate(unwrap(resp))

    # ── Provisioning ──────────────────────────────────────────────────

    def provision(
        self,
        org_id: str,
        user_id: str | None = None,
        branch_id: str | None = None,
        mode: str = "per_org",
        scope: str = "individual",
    ) -> TenantSummary:
        payload: dict = {"org_id": org_id, "mode": mode, "scope": scope}
        if user_id:
            payload["user_id"] = user_id
        if branch_id:
            payload["branch_id"] = branch_id
        # NOTE: Server route not yet implemented (use POST /api/v1/tenants to create tenants directly)
        resp = self._c.post("/api/v1/provision", json=payload)
        return TenantSummary.model_validate(unwrap(resp))

    # ── Stats ─────────────────────────────────────────────────────────

    def global_stats(self) -> GlobalStats:
        # NOTE: Server route not yet implemented (use GET /api/v1/admin/stats for aggregate stats)
        resp = self._c.get("/api/v1/stats")
        return GlobalStats.model_validate(unwrap(resp))
