"""Agent registry and session management."""

from __future__ import annotations

import threading
import time
from contextlib import contextmanager
from typing import TYPE_CHECKING, Generator

from ._http import unwrap
from .types import AgentRecord, AgentRegistration, AgentSession, AgentUpdate

if TYPE_CHECKING:
    import httpx


class AgentRegistry:
    """Register, update, list, and manage AI agents."""

    def __init__(self, client: httpx.Client) -> None:
        self._c = client

    def register(self, reg: AgentRegistration) -> AgentRecord:
        payload = reg.model_dump()
        if not payload.get("display_name"):
            payload["display_name"] = payload.get("name", "")
        # Map SDK field names to Rust RegisterAgentRequest field names
        if "model_id" in payload:
            payload.setdefault("model", payload.pop("model_id"))
        if "allowed_tenants" in payload:
            payload.setdefault("allowed_tenant_ids", payload.pop("allowed_tenants"))
        resp = self._c.post("/api/v1/agents", json=payload)
        return AgentRecord.model_validate(unwrap(resp))

    def get(self, agent_id: str) -> AgentRecord:
        resp = self._c.get(f"/api/v1/agents/{agent_id}")
        return AgentRecord.model_validate(unwrap(resp))

    def update(self, agent_id: str, update: AgentUpdate) -> AgentRecord:
        payload = {k: v for k, v in update.model_dump().items() if v is not None}
        resp = self._c.patch(f"/api/v1/agents/{agent_id}", json=payload)
        return AgentRecord.model_validate(unwrap(resp))

    def list(
        self,
        org_id: str | None = None,
        framework: str | None = None,
        status: str | None = None,
    ) -> list[AgentRecord]:
        params: dict = {}
        if org_id:
            params["org_id"] = org_id
        if framework:
            params["framework"] = framework
        if status:
            params["status"] = status
        resp = self._c.get("/api/v1/agents", params=params)
        data = unwrap(resp)
        items = data.get("items", data) if isinstance(data, dict) else data
        return [AgentRecord.model_validate(a) for a in items]

    def delete(self, agent_id: str) -> str:
        resp = self._c.delete(f"/api/v1/agents/{agent_id}")
        return unwrap(resp)

    def disable(self, agent_id: str) -> AgentRecord:
        return self.update(agent_id, AgentUpdate(status="disabled"))

    def enable(self, agent_id: str) -> AgentRecord:
        return self.update(agent_id, AgentUpdate(status="active"))

    # ── Sessions ──────────────────────────────────────────────────────

    def start_session(self, agent_id: str, tenant_id: str, metadata: dict | None = None,
                      org_id: str | None = None) -> AgentSession:
        import json as _json
        payload: dict = {"tenant_id": tenant_id}
        if org_id:
            payload["org_id"] = org_id
        if metadata:
            payload["metadata_json"] = _json.dumps(metadata) if isinstance(metadata, dict) else metadata
        resp = self._c.post(f"/api/v1/agents/{agent_id}/sessions", json=payload)
        return AgentSession.model_validate(unwrap(resp))

    def end_session(self, session_id: str, status: str = "completed") -> str:
        resp = self._c.post(f"/api/v1/sessions/{session_id}/end", json={"status": status})
        return unwrap(resp)

    def heartbeat(self, session_id: str) -> str:
        resp = self._c.post(f"/api/v1/sessions/{session_id}/heartbeat", json={})
        return unwrap(resp)

    def list_sessions(self, agent_id: str, active_only: bool = False) -> list[AgentSession]:
        params: dict = {}
        if active_only:
            params["active_only"] = "true"
        resp = self._c.get(f"/api/v1/agents/{agent_id}/sessions", params=params)
        data = unwrap(resp)
        items = data.get("items", data) if isinstance(data, dict) else data
        return [AgentSession.model_validate(s) for s in items]

    def authenticate(self, api_key: str) -> AgentRecord:
        # NOTE: Server route not yet implemented
        resp = self._c.post("/api/v1/agents/authenticate", json={"api_key": api_key})
        return AgentRecord.model_validate(unwrap(resp))

    def check_budget(
        self,
        agent_id: str,
        daily_budget: float | None = None,
        monthly_budget: float | None = None,
    ) -> str:
        params: dict = {}
        if daily_budget is not None:
            params["daily_budget"] = str(daily_budget)
        if monthly_budget is not None:
            params["monthly_budget"] = str(monthly_budget)
        resp = self._c.get(f"/api/v1/costs/budget/{agent_id}", params=params)
        return unwrap(resp)

    def get_session(self, session_id: str) -> AgentSession:
        """GET /api/v1/sessions/{session_id} — Get a specific session by ID."""
        resp = self._c.get(f"/api/v1/sessions/{session_id}")
        return AgentSession.model_validate(unwrap(resp))

    def list_active_sessions(self) -> list[AgentSession]:
        """GET /api/v1/sessions/active — List all currently active sessions."""
        resp = self._c.get("/api/v1/sessions/active")
        data = unwrap(resp)
        items = data.get("items", data) if isinstance(data, dict) else data
        return [AgentSession.model_validate(s) for s in items]

    def log_cost(self, agent_id: str, amount_cents: int, description: str) -> str:
        """POST /api/v1/agents/{agent_id}/costs — Record a cost event for an agent."""
        resp = self._c.post(
            f"/api/v1/agents/{agent_id}/costs",
            json={"agent_id": agent_id, "amount_cents": amount_cents, "description": description},
        )
        return unwrap(resp)


class AgentSessionContext:
    """Context manager for agent sessions with background heartbeat.

    Usage:
        with AgentSessionContext(registry, agent_id, tenant_id) as session:
            # session.id is the active session ID
            # heartbeat runs automatically every `heartbeat_interval` seconds
            do_work(session.id)
        # session is ended automatically (status=completed or failed on exception)
    """

    def __init__(
        self,
        registry: AgentRegistry,
        agent_id: str,
        tenant_id: str,
        heartbeat_interval: float = 30.0,
        metadata: dict | None = None,
    ) -> None:
        self.registry = registry
        self.agent_id = agent_id
        self.tenant_id = tenant_id
        self.heartbeat_interval = heartbeat_interval
        self.metadata = metadata
        self.session: AgentSession | None = None
        self._stop_event = threading.Event()
        self._heartbeat_thread: threading.Thread | None = None

    @property
    def id(self) -> str:
        if self.session is None:
            raise RuntimeError("Session not started")
        return self.session.id

    def __enter__(self) -> AgentSessionContext:
        self.session = self.registry.start_session(
            self.agent_id, self.tenant_id, self.metadata
        )
        self._stop_event.clear()
        self._heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop, daemon=True, name="fme-heartbeat"
        )
        self._heartbeat_thread.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self._stop_event.set()
        if self._heartbeat_thread:
            self._heartbeat_thread.join(timeout=5.0)

        status = "failed" if exc_type is not None else "completed"
        try:
            self.registry.end_session(self.id, status=status)
        except Exception:
            pass  # Best effort — session will timeout on server

    def _heartbeat_loop(self) -> None:
        while not self._stop_event.wait(timeout=self.heartbeat_interval):
            try:
                self.registry.heartbeat(self.id)
            except Exception:
                break  # Server unreachable — stop heartbeat
