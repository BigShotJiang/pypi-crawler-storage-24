"""Per-tenant memory CRUD and search."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ._http import require_non_empty, require_positive, unwrap
from .types import ContextResponse, CreateMemoryRequest, Memory, UpdateMemoryRequest

if TYPE_CHECKING:
    import httpx


class MemoryClient:
    """Create, read, update, delete, search, and build context for tenant memories."""

    def __init__(self, client: httpx.Client) -> None:
        self._c = client

    def create(self, tenant_id: str, req: CreateMemoryRequest) -> Memory:
        require_non_empty(tenant_id, "tenant_id")
        payload = req.model_dump()
        # Server accepts tags as a JSON array
        tags = payload.pop("tags", [])
        payload["tags"] = tags if isinstance(tags, list) else [tags]
        # Server accepts metadata as a JSON object directly (not metadata_json string)
        if not payload.get("metadata"):
            payload.pop("metadata", None)
        # Strip optional fields that are None/default so the server uses its own defaults
        for field in ("client_id", "source_channel", "source_ref", "app", "thread_id", "user_id",
                       "visibility", "sensitivity"):
            if payload.get(field) is None:
                payload.pop(field, None)
        resp = self._c.post(f"/api/v1/tenants/{tenant_id}/memories", json=payload)
        return Memory.model_validate(unwrap(resp))

    def get(self, tenant_id: str, memory_id: str) -> Memory:
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(memory_id, "memory_id")
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/memories/{memory_id}")
        return Memory.model_validate(unwrap(resp))

    def update(self, tenant_id: str, memory_id: str, req: UpdateMemoryRequest) -> Memory:
        payload = {k: v for k, v in req.model_dump().items() if v is not None}
        # Server accepts tags as a JSON array — keep as list
        if "metadata" in payload:
            import json
            payload["metadata_json"] = json.dumps(payload.pop("metadata"))
        resp = self._c.patch(f"/api/v1/tenants/{tenant_id}/memories/{memory_id}", json=payload)
        return Memory.model_validate(unwrap(resp))

    def delete(self, tenant_id: str, memory_id: str) -> str:
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(memory_id, "memory_id")
        resp = self._c.delete(f"/api/v1/tenants/{tenant_id}/memories/{memory_id}")
        return unwrap(resp)

    def search(
        self,
        tenant_id: str,
        query: str,
        limit: int = 10,
        memory_type: str | None = None,
        user_id: str | None = None,
        client_id: str | None = None,
        source_channel: str | None = None,
        app: str | None = None,
        visibility: str | None = None,
        sensitivity: str | None = None,
        search_strategy: str | None = None,
        detail: str | None = None,
    ) -> list[Memory] | list[dict[str, Any]]:
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(query, "query")
        require_positive(limit, "limit")
        payload: dict[str, Any] = {"query": query, "tenant_id": tenant_id, "limit": limit}
        if memory_type:
            payload["memory_type"] = memory_type
        if user_id:
            payload["user_id"] = user_id
        if client_id:
            payload["client_id"] = client_id
        if source_channel:
            payload["source_channel"] = source_channel
        if app:
            payload["app"] = app
        if visibility:
            payload["visibility"] = visibility
        if sensitivity:
            payload["sensitivity"] = sensitivity
        if search_strategy:
            payload["search_strategy"] = search_strategy
        if detail:
            payload["detail"] = detail
        resp = self._c.post(f"/api/v1/tenants/{tenant_id}/memories/search", json=payload)
        data = unwrap(resp)
        if detail in ("outline", "summary"):
            return data
        return [Memory.model_validate(m) for m in data]

    def context(
        self,
        tenant_id: str,
        query: str,
        max_tokens: int = 500,
        detail: str | None = None,
        context_budget_tokens: int | None = None,
    ) -> ContextResponse:
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(query, "query")
        require_positive(max_tokens, "max_tokens")
        params: dict[str, str | int] = {"query": query, "max_tokens": max_tokens}
        if detail:
            params["detail"] = detail
        if context_budget_tokens:
            params["context_budget_tokens"] = context_budget_tokens
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/context", params=params)
        return ContextResponse.model_validate(unwrap(resp))

    def get_topics(self, tenant_id: str, query: str = "", limit: int = 10) -> list[dict[str, Any]]:
        resp = self._c.get(
            f"/api/v1/tenants/{tenant_id}/search/topics",
            params={"query": query, "limit": limit},
        )
        return unwrap(resp)

    def facts(self, tenant_id: str, limit: int = 20) -> list[Memory]:
        require_non_empty(tenant_id, "tenant_id")
        require_positive(limit, "limit")
        # NOTE: Server route not yet implemented
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/memories/facts", params={"limit": str(limit)})
        data = unwrap(resp)
        return [Memory.model_validate(m) for m in data]

    def get_history(self, tenant_id: str, memory_id: str) -> list[dict[str, Any]]:
        """GET /api/v1/tenants/{tid}/memories/{mid}/history — Version history for a memory."""
        require_non_empty(tenant_id, "tenant_id")
        require_non_empty(memory_id, "memory_id")
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/memories/{memory_id}/history")
        data = unwrap(resp)
        return data if isinstance(data, list) else []

    def compress(
        self,
        tenant_id: str,
        client_id: str | None = None,
    ) -> dict[str, Any]:
        """POST /api/v1/tenants/{tid}/memories/compress — Merge similar/duplicate memories."""
        require_non_empty(tenant_id, "tenant_id")
        payload: dict[str, Any] = {}
        if client_id:
            payload["client_id"] = client_id
        resp = self._c.post(f"/api/v1/tenants/{tenant_id}/memories/compress", json=payload)
        data = unwrap(resp)
        return data if isinstance(data, dict) else {}

    def compression_stats(self, tenant_id: str) -> dict[str, Any]:
        """GET /api/v1/tenants/{tid}/memories/compression-stats — Memory compression statistics."""
        require_non_empty(tenant_id, "tenant_id")
        resp = self._c.get(f"/api/v1/tenants/{tenant_id}/memories/compression-stats")
        data = unwrap(resp)
        return data if isinstance(data, dict) else {}
