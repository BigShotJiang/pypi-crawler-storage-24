"""Network auto-detection for ForgeMemory Enterprise server.

Tries LAN first (fast), falls back to Tailscale HTTPS, caches the result
for 5 minutes.

NOTE: Callers must supply their own ``lan_host`` and ``tailscale_host``.
No default server addresses are embedded in this library.  Prefer using
``EnterpriseClient(base_url='https://your-server:8201')`` directly instead
of calling this function at all.
"""

import time

import httpx

_DEFAULT_PORT = 8201

_cached_base_url: str | None = None
_cache_expires: float = 0.0
_CACHE_TTL = 300.0  # 5 minutes


def detect_base_url(
    *,
    lan_host: str,
    tailscale_host: str,
    port: int = _DEFAULT_PORT,
    lan_timeout: float = 1.5,
    tailscale_timeout: float = 3.0,
) -> str:
    """Auto-detect the best base URL for the FME server.

    Tries LAN first (fast), falls back to Tailscale HTTPS.
    Caches the result for 5 minutes.

    Args:
        lan_host: LAN hostname or IP of the FME server (required).
        tailscale_host: Tailscale hostname of the FME server (required).
        port: Port number (default 8201).
        lan_timeout: Timeout in seconds for LAN probe.
        tailscale_timeout: Timeout in seconds for Tailscale probe.

    Note:
        Use ``EnterpriseClient(base_url='...')`` directly instead of
        auto-detection wherever possible.  This function exists for
        environments that need dynamic LAN/Tailscale routing.
    """
    global _cached_base_url, _cache_expires

    now = time.monotonic()
    if _cached_base_url and now < _cache_expires:
        return _cached_base_url

    # Try LAN first
    lan_url = f"http://{lan_host}:{port}"
    try:
        resp = httpx.get(f"{lan_url}/health", timeout=lan_timeout)
        if resp.status_code == 200:
            _cached_base_url = lan_url
            _cache_expires = now + _CACHE_TTL
            return lan_url
    except (httpx.ConnectError, httpx.TimeoutException, httpx.ConnectTimeout):
        pass

    # Fall back to Tailscale HTTPS
    ts_url = f"https://{tailscale_host}:{port}"
    try:
        resp = httpx.get(f"{ts_url}/health", timeout=tailscale_timeout)
        if resp.status_code == 200:
            _cached_base_url = ts_url
            _cache_expires = now + _CACHE_TTL
            return ts_url
    except (httpx.ConnectError, httpx.TimeoutException, httpx.ConnectTimeout):
        pass

    raise ConnectionError(
        f"Cannot reach ForgeMemory Enterprise at {lan_url} (LAN) or {ts_url} (Tailscale)"
    )


def clear_cache() -> None:
    """Clear the cached base URL, forcing re-detection on next call."""
    global _cached_base_url, _cache_expires
    _cached_base_url = None
    _cache_expires = 0.0
