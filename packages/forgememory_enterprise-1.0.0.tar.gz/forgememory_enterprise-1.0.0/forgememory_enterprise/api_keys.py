"""API key management."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._http import request_with_retry, unwrap
from .types import ApiKeyCreated, ApiKeyRotated, ApiKeyRow

if TYPE_CHECKING:
    import httpx


class ApiKeyManager:
    """Create, list, revoke, and rotate API keys."""

    def __init__(self, client: httpx.Client) -> None:
        self._c = client

    def create(
        self,
        org_id: str,
        role: str,
        label: str,
        tenant_ids: list[str] | None = None,
        user_id: str | None = None,
        expires_at: str | None = None,
        idempotency_key: str | None = None,
    ) -> ApiKeyCreated:
        payload: dict = {"org_id": org_id, "role": role, "label": label}
        if tenant_ids:
            payload["tenant_ids"] = tenant_ids
        if user_id:
            payload["user_id"] = user_id
        if expires_at:
            payload["expires_at"] = expires_at
        resp = request_with_retry(self._c, "POST", "/api/v1/api-keys", json=payload, idempotency_key=idempotency_key)
        return ApiKeyCreated.model_validate(unwrap(resp))

    def list(self, org_id: str) -> list[ApiKeyRow]:
        resp = self._c.get("/api/v1/api-keys", params={"org_id": org_id})
        data = unwrap(resp)
        return [ApiKeyRow.model_validate(k) for k in data]

    def revoke(self, key_id: str, idempotency_key: str | None = None) -> str:
        resp = request_with_retry(self._c, "POST", f"/api/v1/api-keys/{key_id}/revoke", idempotency_key=idempotency_key)
        return unwrap(resp)

    def rotate(
        self,
        key_id: str,
        grace_period_secs: int | None = None,
        idempotency_key: str | None = None,
    ) -> ApiKeyRotated:
        """Rotate an API key, issuing a new secret while the old one remains valid
        for an optional grace period.

        Args:
            key_id: The ID of the API key to rotate.
            grace_period_secs: Seconds the old key stays valid after rotation.
                               Defaults to server-side default (typically 300s).
            idempotency_key: Optional idempotency key to prevent double-rotation.

        Returns:
            ApiKeyRotated with the new raw key and expiry of the old key.
        """
        payload: dict = {}
        if grace_period_secs is not None:
            payload["grace_period_secs"] = grace_period_secs
        resp = request_with_retry(
            self._c, "POST", f"/api/v1/api-keys/{key_id}/rotate",
            json=payload, idempotency_key=idempotency_key,
        )
        return ApiKeyRotated.model_validate(unwrap(resp))
