"""Pydantic v2 models mirroring all FME Rust types."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, model_validator


# ── Enums ─────────────────────────────────────────────────────────────────


class UserRole(str, Enum):
    VIEWER = "viewer"
    MANAGER = "manager"
    ADVISOR = "advisor"
    ADMIN = "admin"
    COMPLIANCE = "compliance"
    SUPER_ADMIN = "super_admin"


class TenantMode(str, Enum):
    PER_ORG = "per_org"
    PER_USER = "per_user"


class TenantStatus(str, Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    PENDING_DELETE = "pending_delete"


class ScopeType(str, Enum):
    INDIVIDUAL = "individual"
    SHARED = "shared"
    TEAM = "team"


class AgentFramework(str, Enum):
    CREWAI = "crewai"
    LANGGRAPH = "langgraph"
    AUTOGEN = "autogen"
    OPENCLAW = "openclaw"
    AGENT_ZERO = "agent_zero"
    CUSTOM = "custom"


class AgentStatus(str, Enum):
    ACTIVE = "active"
    DISABLED = "disabled"


class ActionType(str, Enum):
    TOOL_CALL = "tool_call"
    LLM_REQUEST = "llm_request"
    MEMORY_READ = "memory_read"
    MEMORY_WRITE = "memory_write"
    DELEGATION = "delegation"
    ERROR = "error"


class SearchStrategy(str, Enum):
    KEYWORD_ONLY = "keyword_only"
    HYBRID_FTS5_FIRST = "hybrid_fts5_first"
    HYBRID_PARALLEL = "hybrid_parallel"
    VECTOR_ONLY = "vector_only"


class MemoryAccessType(str, Enum):
    READ = "read"
    WRITE = "write"
    SEARCH = "search"
    DELETE = "delete"


class DelegationStatus(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    COMPLETED = "completed"
    FAILED = "failed"
    REJECTED = "rejected"


class MemoryType(str, Enum):
    SEMANTIC = "semantic"
    EPISODIC = "episodic"
    PROCEDURAL = "procedural"


class IngestChannel(str, Enum):
    CRM = "crm"
    EMAIL = "email"
    CALL = "call"
    CALENDAR = "calendar"
    PLANNING = "planning"
    MEETING = "meeting"
    DOCS = "docs"


# ── Ingest Pipeline Types ─────────────────────────────────────────────────


class IngestResponse(BaseModel):
    """Response from a successful ingest request."""
    memories_created: int = 0
    memory_ids: list[str] = Field(default_factory=list)
    channel: str = ""


class ChannelInfo(BaseModel):
    """Information about an available ingest channel."""
    channel: str
    default_importance: int = 5
    default_memory_type: str = "semantic"


class CrmEventRequest(BaseModel):
    """CRM event to ingest."""
    record_id: str
    event_type: str
    summary: str
    field_changes: dict = Field(default_factory=dict)
    related_contacts: list[str] = Field(default_factory=list)


class EmailIngestRequest(BaseModel):
    """Email message to ingest."""
    message_id: str
    from_addr: str = Field(alias="from")
    to: list[str]
    subject: str
    body: str
    related_contacts: list[str] = Field(default_factory=list)

    model_config = {"populate_by_name": True}


class CallTranscriptRequest(BaseModel):
    """Call transcript to ingest."""
    call_id: str
    caller: str
    callee: str
    duration_secs: int
    transcript: str
    related_contacts: list[str] = Field(default_factory=list)


class CalendarEventRequest(BaseModel):
    """Calendar event to ingest."""
    event_id: str
    title: str
    description: str = ""
    location: str = ""
    attendees: list[str] = Field(default_factory=list)
    start_time: str
    end_time: str


class PlanningSessionRequest(BaseModel):
    """Financial planning session to ingest."""
    session_id: str
    advisor: str
    notes: str
    goals: list[str] = Field(default_factory=list)
    action_items: list[str] = Field(default_factory=list)
    risk_tolerance: int | None = None
    clients: list[str] = Field(default_factory=list)


class MeetingNoteRequest(BaseModel):
    """Simple meeting note to ingest."""
    content: str
    entities: list[str] = Field(default_factory=list)


class DocumentIngestRequest(BaseModel):
    """Document to ingest."""
    document_id: str
    title: str
    document_type: str
    content: str
    related_contacts: list[str] = Field(default_factory=list)


# ── Org / User / Branch / Tenant ──────────────────────────────────────────


class Org(BaseModel):
    id: str
    name: str
    slug: str
    active: bool = True
    created_at: str = ""


class User(BaseModel):
    id: str
    org_id: str
    email: str
    display_name: str
    role: str = "viewer"
    active: bool = True
    created_at: str = ""


class Branch(BaseModel):
    id: str
    org_id: str
    name: str
    parent_id: str | None = None
    created_at: str = ""


class TenantSummary(BaseModel):
    model_config = {"extra": "allow"}

    id: str
    org_id: str = ""
    branch_id: str | None = None
    user_id: str | None = None
    name: str = ""
    scope: str = "individual"
    mode: str = "per_org"
    status: str = "active"
    created_at: str = ""
    vector_search_enabled: bool = False
    embedding_model: str = "all-MiniLM-L6-v2"
    search_strategy: str = "keyword_only"


class GlobalStats(BaseModel):
    total_orgs: int = 0
    total_users: int = 0
    total_branches: int = 0
    total_tenants: int = 0
    total_api_keys: int = 0
    active_tenants: int = 0
    suspended_tenants: int = 0


# ── API Keys ──────────────────────────────────────────────────────────────


class ApiKeyCreated(BaseModel):
    """Returned when a new API key is created.

    The Rust server returns ``{"plaintext": "fme_...", "record": {...}}``
    so we flatten that into a single model via a model_validator.
    """
    model_config = {"extra": "allow"}

    id: str = ""
    raw_key: str = ""
    org_id: str = ""
    user_id: str | None = None
    role: str = ""
    label: str = ""
    tenant_ids: list[str] = Field(default_factory=list)
    created_at: str = ""
    expires_at: str | None = None

    @model_validator(mode="before")
    @classmethod
    def _flatten_server_response(cls, data: Any) -> Any:
        """Handle the Rust ``{plaintext, record}`` envelope."""
        if isinstance(data, dict) and "plaintext" in data and "record" in data:
            record = data["record"] if isinstance(data["record"], dict) else {}
            flat = {**record}
            flat["raw_key"] = data["plaintext"]
            # Normalise role from Rust enum (e.g. "admin" or {"Admin": ...}) to string
            role = flat.get("role", "")
            if isinstance(role, dict):
                flat["role"] = next(iter(role), "")
            elif isinstance(role, str):
                flat["role"] = role.lower()
            return flat
        return data


class ApiKeyRow(BaseModel):
    id: str
    org_id: str
    user_id: str | None = None
    role: str
    label: str
    key_hash: str = ""
    tenant_ids: str = ""  # comma-separated
    revoked: bool = False
    created_at: str = ""
    expires_at: str | None = None
    last_used_at: str | None = None


# ── Agent Registry ────────────────────────────────────────────────────────


class AgentRecord(BaseModel):
    model_config = {"extra": "allow"}

    id: str
    org_id: str = ""
    name: str = ""
    framework: str | dict = "custom"  # Rust serializes Custom(String) as {"custom": "val"}
    model_id: str = ""
    capabilities: str | list = ""  # may be comma-separated string or JSON array
    allowed_tenants: str | list = ""  # may be comma-separated string or JSON array
    status: str = "active"
    api_key_hash: str = ""
    created_at: str = ""
    updated_at: str = ""


class AgentSession(BaseModel):
    model_config = {"extra": "allow"}

    id: str
    agent_id: str = ""
    tenant_id: str = ""
    status: str = "active"
    started_at: str = ""
    ended_at: str | None = None
    last_heartbeat: str = ""
    metadata_json: str = "{}"


class AgentRegistration(BaseModel):
    """Request body for registering a new agent."""
    org_id: str
    name: str
    display_name: str = ""
    framework: str = "custom"
    api_key: str = ""
    model_id: str = ""
    capabilities: list[str] = Field(default_factory=list)
    allowed_tenants: list[str] = Field(default_factory=list)


class AgentUpdate(BaseModel):
    """Request body for updating an agent."""
    model_id: str | None = None
    capabilities: list[str] | None = None
    allowed_tenants: list[str] | None = None
    status: str | None = None


# ── Agent Audit ───────────────────────────────────────────────────────────


class AuditAction(BaseModel):
    model_config = {"extra": "allow"}

    id: int | str = 0
    agent_id: str
    session_id: str
    action_type: str
    detail: str = ""
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    created_at: str = ""


class MemoryAccess(BaseModel):
    model_config = {"extra": "allow"}

    id: int | str = 0
    agent_id: str
    session_id: str
    tenant_id: str
    memory_id: str
    access_type: str
    created_at: str = ""


class Delegation(BaseModel):
    id: int = 0
    from_agent_id: str
    to_agent_id: str
    session_id: str
    task: str
    status: str = "pending"
    created_at: str = ""
    completed_at: str | None = None


class CostEntry(BaseModel):
    agent_id: str
    date: str
    total_tokens_in: int = 0
    total_tokens_out: int = 0
    total_cost_usd: float = 0.0
    request_count: int = 0


class AgentCostSummary(BaseModel):
    """Aggregate cost summary for an agent over a time period.

    Returned by GET /api/v1/costs/agent/{agent_id}.
    """
    agent_id: str
    agent_name: str = ""
    total_actions: int = 0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_cost_usd: float = 0.0
    daily_budget_usd: float | None = None
    monthly_budget_usd: float | None = None
    period_start: str = ""
    period_end: str = ""


class AgentAuditStats(BaseModel):
    total_actions: int = 0
    total_memory_accesses: int = 0
    total_delegations: int = 0
    total_cost_usd: float = 0.0


# ── Memory ────────────────────────────────────────────────────────────────


class Memory(BaseModel):
    model_config = {"extra": "allow"}

    id: str = ""
    tenant_id: str = ""
    content: str
    memory_type: str = "semantic"
    importance: int = 5
    source: str = ""
    tags: str | list = ""
    user_id: str | None = None
    metadata_json: str = "{}"
    content_hash: str = ""
    access_count: int = 0
    last_accessed: str = ""
    created_at: str = ""
    updated_at: str = ""
    client_id: str | None = None
    source_channel: str | None = None
    source_ref: str | None = None
    app: str | None = None
    visibility: str | None = None
    thread_id: str | None = None
    sensitivity: str | None = None


class CreateMemoryRequest(BaseModel):
    content: str
    memory_type: str = "semantic"
    importance: int = 5
    source: str = ""
    tags: list[str] = Field(default_factory=list)
    user_id: str | None = None
    metadata: dict = Field(default_factory=dict)
    client_id: str | None = None
    source_channel: str | None = None
    source_ref: str | None = None
    app: str | None = None
    visibility: str = "normal"
    thread_id: str | None = None
    sensitivity: str = "internal"


class UpdateMemoryRequest(BaseModel):
    content: str | None = None
    importance: int | None = None
    tags: list[str] | None = None
    metadata: dict | None = None


class SearchRequest(BaseModel):
    query: str
    tenant_id: str
    limit: int = 10
    memory_type: str | None = None
    user_id: str | None = None
    search_strategy: str | None = None
    detail: str | None = None


class ContextResponse(BaseModel):
    model_config = {"extra": "allow"}

    context: str = ""
    memories_used: int = 0


# ── Admin / Health ────────────────────────────────────────────────────────


class HealthResponse(BaseModel):
    status: str = "ok"
    version: str = ""
    uptime_secs: int = 0


class LivenessResponse(BaseModel):
    """Response from GET /health/live — minimal liveness probe."""
    alive: bool = True
    status: str = "ok"


class ReadinessComponent(BaseModel):
    """Status of a single internal component."""
    name: str
    status: str  # "ok", "degraded", "unavailable"
    detail: str = ""


class ReadinessResponse(BaseModel):
    """Response from GET /health/ready — readiness probe with component breakdown."""
    ready: bool = True
    status: str = "ok"
    components: list[ReadinessComponent] = Field(default_factory=list)


class VectorStats(BaseModel):
    """Per-tenant vector search statistics."""
    tenant_id: str = ""
    total_memories: int = 0
    embedded_memories: int = 0
    failed_embeddings: int = 0
    pending_embeddings: int = 0
    index_type: str = "brute_force"


class VectorStatsResponse(BaseModel):
    """Response from GET /api/v1/admin/vector/stats."""
    vector_enabled: bool = False
    backend_type: str = "none"
    tenants: list[VectorStats] = []


class PoolStats(BaseModel):
    active_connections: int = 0
    total_hits: int = 0
    total_misses: int = 0
    evictions: int = 0


# ── API Key Rotation ───────────────────────────────────────────────────────


class ApiKeyRotated(BaseModel):
    """Response from POST /api/v1/api-keys/{id}/rotate."""
    new_key: str
    new_key_id: str
    old_key_expires_at: str | None = None  # when the old key stops working
    old_key_id: str = ""


# ── Thread Operations ──────────────────────────────────────────────────────


class ThreadMemories(BaseModel):
    """Response from GET /api/v1/tenants/{tid}/threads/{thread_id}."""
    model_config = {"extra": "allow"}

    thread_id: str
    memories: list[Memory] = Field(default_factory=list)
    total: int = 0


# ── DSR (Data Subject Requests) ────────────────────────────────────────────


class DsrStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    COMPLETED = "completed"


class DsrRecord(BaseModel):
    """A Data Subject Request record (GDPR Article 15/17)."""
    model_config = {"extra": "allow"}

    id: str
    tenant_id: str
    subject_email: str = ""
    subject_id: str = ""
    subject_type: str = ""
    request_type: str  # "erasure", "access", "portability", "rectification"
    status: str = "pending"
    description: str = ""
    notes: str = ""
    reason: str = ""
    created_at: str = ""
    updated_at: str = ""
    completed_at: str | None = None


# ── Compliance ─────────────────────────────────────────────────────────────


class ComplianceFrameworkStatus(BaseModel):
    """Status of a single regulatory framework."""
    framework: str  # "gdpr", "hipaa", "sox", "finra", "mifid2"
    status: str  # "pass", "warn", "fail"
    controls_passed: int = 0
    controls_failed: int = 0
    controls_warned: int = 0
    last_assessed_at: str = ""


class CompliancePosture(BaseModel):
    """Overall compliance posture across all frameworks.

    Returned by GET /api/v1/admin/compliance-posture.
    """
    overall_status: str = "pass"  # "pass", "warn", "fail"
    frameworks: list[ComplianceFrameworkStatus] = Field(default_factory=list)
    generated_at: str = ""


class ComplianceEvidenceRecord(BaseModel):
    """A single compliance evidence artifact."""
    id: str = ""
    evidence_type: str = ""  # "audit_log", "data_access", "retention", "dsr"
    framework: str = ""
    tenant_id: str = ""
    description: str = ""
    recorded_at: str = ""
    metadata: dict = Field(default_factory=dict)


class ComplianceEvidence(BaseModel):
    """Collection of compliance evidence artifacts.

    Returned by GET /api/v1/admin/compliance-evidence.
    """
    records: list[ComplianceEvidenceRecord] = Field(default_factory=list)
    total: int = 0
    framework: str | None = None
    generated_at: str = ""


# ── Entity Graph ──────────────────────────────────────────────────────────


class EntityNode(BaseModel):
    """A node in the dynamic entity graph.

    Mirrors the Rust EntityResponse. The ``name`` field is the primary key —
    there is no separate ``id`` field. ``metadata_json`` is a raw JSON string
    (as returned by the Rust API) rather than a parsed dict.

    Entities are generic — they can represent households, contacts, products,
    fleets, or any business concept. The entity_type and metadata determine
    the semantics.

    Temporal fields:
        first_seen: ISO 8601 — earliest memory timestamp linked to this entity.
        last_seen: ISO 8601 — most recent memory timestamp linked to this entity.
    """
    model_config = {"extra": "allow"}

    name: str  # PK — no separate "id" field
    entity_type: str = "entity"  # e.g., "household", "contact", "product", "fleet"
    user_id: str | None = None
    relationship: str | None = None
    metadata_json: str = "{}"  # raw JSON string, not a parsed object
    notes: str | None = None
    first_seen: str | None = None  # ISO 8601 — earliest linked memory timestamp
    last_seen: str | None = None  # ISO 8601 — most recent linked memory timestamp
    created_at: str = ""
    updated_at: str = ""


class CreateEntityRequest(BaseModel):
    """Request to create a new entity node."""
    name: str
    entity_type: str = "entity"
    relationship: str | None = None
    metadata: dict = Field(default_factory=dict)  # sent as JSON Value, parsed server-side
    notes: str | None = None


class UpdateEntityRequest(BaseModel):
    """Request to update an entity node (partial update)."""
    entity_type: str | None = None
    relationship: str | None = None
    metadata: dict | None = None
    notes: str | None = None


class GraphEdge(BaseModel):
    """An edge (relationship) between two entity nodes.

    Mirrors the Rust EdgeResponse. ``source_id`` / ``target_id`` hold the
    entity names (which are the PKs in the Rust layer).

    Bi-temporal fields: ``valid_from`` / ``valid_to`` represent business-time
    validity. ``recorded_at`` is system-time (when the row was recorded).
    ``superseded_at`` is set when a ``force``-create supersedes this edge.
    """
    model_config = {"extra": "allow"}

    id: str
    source_id: str
    target_id: str
    relationship: str  # e.g., "member_of", "spouse_of", "owns", "beneficiary_of"
    weight: float = 1.0
    memory_id: str | None = None  # optional linked memory
    valid_from: str | None = None  # ISO 8601 — when the edge became valid
    valid_to: str | None = None  # ISO 8601 — when the edge stopped being valid
    recorded_at: str | None = None  # ISO 8601 — system-time recording
    superseded_at: str | None = None  # ISO 8601 — set when force-superseded
    created_at: str = ""


class CreateEdgeRequest(BaseModel):
    """Request to create an edge between two entities.

    When ``force=True``, any existing active edge with the same
    (source, target, relationship) triple is automatically superseded
    (its ``valid_to`` is set to now) before the new edge is created.
    """
    source: str  # entity name (PK)
    target: str  # entity name (PK)
    relationship: str
    weight: float | None = None
    memory_id: str | None = None
    valid_from: str | None = None  # ISO 8601
    valid_to: str | None = None  # ISO 8601
    force: bool | None = None  # auto-supersede existing active edge


class UpdateEdgeRequest(BaseModel):
    """Request to update an edge (partial update via PATCH).

    Used to close (supersede) an edge by setting ``valid_to``, or to
    adjust its ``weight``.
    """
    valid_to: str | None = None  # ISO 8601 — close the edge at this time
    weight: float | None = None


class TraversalResult(BaseModel):
    """Result of a BFS graph traversal from a starting entity.

    Mirrors the Rust TraversalResponse. ``root`` is the name of the starting
    entity (the PK). There is no separate ``depth`` field in the Rust response.
    """
    root: str
    nodes: list[EntityNode] = Field(default_factory=list)
    edges: list[GraphEdge] = Field(default_factory=list)

# ── Missing Workflow Types ───────────────────────────────────────────────────


class RetentionStatus(BaseModel):
    model_config = {"extra": "allow"}

    tenant_id: str
    retention_days: int = 0
    memories_eligible_for_sweep: int = 0
    last_sweep_at: str | None = None


class AuditTrailReport(BaseModel):
    model_config = {"extra": "allow"}

    tenant_id: str
    period_start: str
    period_end: str
    total_events: int = 0
    events_by_type: list[dict] = Field(default_factory=list)
    records: list[dict] = Field(default_factory=list)
    chain_hash: str = ""
    generated_at: str = ""


class DataAccessReport(BaseModel):
    model_config = {"extra": "allow"}

    tenant_id: str
    period_start: str
    period_end: str
    total_accesses: int = 0
    unique_actors: int = 0
    actor_summaries: list[dict] = Field(default_factory=list)
    generated_at: str = ""


class DsarReport(BaseModel):
    model_config = {"extra": "allow"}

    request_id: str
    tenant_id: str
    client_id: str
    total_memories: int = 0
    memories: list[dict] = Field(default_factory=list)
    audit_trail: list[dict] = Field(default_factory=list)
    data_subject_requests: list[dict] = Field(default_factory=list)
    generated_at: str = ""


class RetentionComplianceReport(BaseModel):
    model_config = {"extra": "allow"}

    tenant_id: str
    total_memories: int = 0
    with_retention_policy: int = 0
    without_retention_policy: int = 0
    compliance_pct: float = 0.0
    under_legal_hold: int = 0
    under_retention_hold: int = 0
    expired_pending_sweep: int = 0
    generated_at: str = ""


# ── ZKAT (Zero-Knowledge Audit Trail) ───────────────────────────────────────


class ChainVerifyResult(BaseModel):
    """Result of verifying the append-only audit chain integrity."""
    valid: bool = True
    total_records: int = 0
    first_hash: str = ""
    last_hash: str = ""
    broken_at: int | None = None
    verified_at: str = ""


class Epoch(BaseModel):
    """A sealed ZKAT Merkle tree epoch."""
    epoch_id: int = 0
    tenant_id: str = ""
    record_count: int = 0
    merkle_root: str = ""
    prev_epoch_hash: str = ""
    sealed_at: str = ""


class EpochVerifyResult(BaseModel):
    """Result of verifying all ZKAT epochs for a tenant."""
    valid: bool = True
    total_epochs: int = 0
    verified_epochs: int = 0
    first_broken_epoch: int | None = None
    verified_at: str = ""


# ── Policy Engine ────────────────────────────────────────────────────────────


class Policy(BaseModel):
    """A compliance policy rule for a tenant."""
    id: str = ""
    tenant_id: str = ""
    name: str = ""
    policy_type: str = ""
    config: dict = Field(default_factory=dict)
    config_json: str = ""
    action: str = "deny"
    enabled: bool = True
    created_at: str = ""
    updated_at: str = ""

    def model_post_init(self, __context: Any) -> None:
        """Parse config_json into config dict if config is empty."""
        if not self.config and self.config_json:
            import json
            try:
                self.config = json.loads(self.config_json)
            except (json.JSONDecodeError, TypeError):
                pass


# ── Supervisor ───────────────────────────────────────────────────────────────


class SupervisorAlert(BaseModel):
    """An alert raised by the supervisory agent."""
    id: str = ""
    tenant_id: str = ""
    rule_id: str = ""
    severity: str = "medium"
    title: str = ""
    detail: str = ""
    status: str = "open"
    resolved_by: str | None = None
    created_at: str = ""
    updated_at: str = ""


class SupervisorRule(BaseModel):
    """A supervisory rule that generates alerts when triggered."""
    id: str = ""
    name: str = ""
    rule_type: str = ""
    config: dict = Field(default_factory=dict)
    severity: str = "medium"
    enabled: bool = True
    created_at: str = ""
    updated_at: str = ""


class SupervisorStatus(BaseModel):
    """Overall status of the supervisor subsystem."""
    enabled: bool = False
    total_rules: int = 0
    active_rules: int = 0
    total_alerts: int = 0
    open_alerts: int = 0
    last_sweep_at: str | None = None


# ── Distillation ────────────────────────────────────────────────────────────


class DistillationStats(BaseModel):
    """Stats from GET /api/v1/admin/distillation/stats."""
    model_config = {"extra": "allow"}

    pending: int = 0
    completed: int = 0
    skipped: int = 0
    failed: int = 0
    total: int = 0

