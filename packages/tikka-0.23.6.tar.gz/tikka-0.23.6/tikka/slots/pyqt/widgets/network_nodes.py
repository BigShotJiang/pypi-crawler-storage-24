# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import sys
from typing import Optional

from PyQt5.QtCore import QPoint, Qt
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import QApplication, QMainWindow, QStyledItemDelegate, QWidget

from tikka.domains.application import Application
from tikka.domains.entities.constants import (
    DATA_PATH,
)
from tikka.domains.entities.events import (
    NodesEvent,
)
from tikka.domains.entities.node import Node
from tikka.slots.pyqt.entities.constants import (
    NODES_TABLE_SORT_COLUMN_PREFERENCES_KEY,
    NODES_TABLE_SORT_ORDER_PREFERENCES_KEY,
)
from tikka.slots.pyqt.entities.event_bus import EventBus
from tikka.slots.pyqt.entities.worker import ThreadManager
from tikka.slots.pyqt.models.nodes import NodesTableModel
from tikka.slots.pyqt.resources.gui.widgets.network_nodes_rc import (
    Ui_NetworkNodesWidget,
)
from tikka.slots.pyqt.widgets.node_menu import NodePopupMenu
from tikka.slots.pyqt.windows.node_add import NodeAddWindow


class HighlightNodeDelegate(QStyledItemDelegate):
    """
    Class to highlight connected node row
    """

    def __init__(self, table_model, application):
        """
        Initialize HighlightNodeDelegate instance

        :param table_model: TableModel of
        :param application:
        """
        super().__init__()
        self.table_model = table_model
        self.application = application

    def paint(self, painter, option, index):
        # get current url/row node
        current_node_url = self.application.nodes.get_current_url()
        node = self.table_model.nodes[index.row()]
        # check connection...
        if node.url == current_node_url:
            color = (
                QColor("lightgreen")
                if self.application.connections.node.is_connected()
                else QColor("lightcoral")
            )
            painter.fillRect(option.rect, color)

        # paint rectangle
        super().paint(painter, option, index)


class NetworkNodesWidget(QWidget, Ui_NetworkNodesWidget):
    """
    NetworkNodesWidget class
    """

    def __init__(
        self,
        application: Application,
        parent: Optional[QWidget] = None,
    ) -> None:
        """
        Init NetworkNodesWidget instance

        :param application: Application instance
        :param parent: MainWindow instance
        """
        super().__init__(parent=parent)
        self.setupUi(self)

        self.application = application
        self._ = self.application.translator.gettext

        self.event_bus = EventBus.instance()
        self.event_bus.node_connected.connect(self.on_node_connection_event)
        self.event_bus.node_disconnected.connect(self.on_node_connection_event)
        self.event_bus.repository_data_updated.connect(
            self.on_repository_data_updated_event
        )
        self.event_bus.currency_opened.connect(self.on_repository_data_updated_event)

        self.selected_node: Optional[Node] = None

        self.nodes_table_model = NodesTableModel(self.application)
        self.nodesTableView.setModel(self.nodes_table_model)
        self.nodesTableView.resizeColumnsToContents()
        self.nodesTableView.customContextMenuRequested.connect(
            self.on_node_context_menu
        )
        self.nodesTableView.setItemDelegate(
            HighlightNodeDelegate(self.nodes_table_model, self.application)
        )
        pref_sort_column = self.application.repository.preferences.get(
            NODES_TABLE_SORT_COLUMN_PREFERENCES_KEY
        )
        if pref_sort_column is None:
            sort_column = 0
        else:
            sort_column = int(pref_sort_column)

        pref_sort_order = self.application.repository.preferences.get(
            NODES_TABLE_SORT_ORDER_PREFERENCES_KEY
        )
        if pref_sort_order is None:
            sort_order = int(Qt.SortOrder.AscendingOrder)
        else:
            sort_order = int(pref_sort_order)
        self.nodesTableView.sortByColumn(sort_column, sort_order)

        # events
        self.addNodeButton.clicked.connect(self._on_add_node_button_clicked)
        self.nodesTableView.doubleClicked.connect(self.on_node_table_double_click)

        # subscribe to application events
        self.application.event_dispatcher.add_event_listener(
            NodesEvent.EVENT_TYPE_LIST_CHANGED, self._on_node_list_changed_event
        )

        ##############################
        # ASYNC METHODS
        ##############################
        self.thread_manager: ThreadManager = ThreadManager(self)

    def on_node_connection_event(self):
        """
        Triggered when node connection has changed

        :return:
        """
        self.nodesTableView.viewport().update()

    def _on_add_node_button_clicked(self):
        """
        Trigger when user click on add node button

        :return:
        """
        NodeAddWindow(self.application, self).exec_()

    def on_repository_data_updated_event(self, _=None):
        """
        When a currency opened event is triggered

        :param _: CurrencyEvent instance
        :return:
        """
        # update model
        self.nodesTableView.model().init_data()

        # resize view
        self.nodesTableView.resizeColumnsToContents()

    def _on_node_list_changed_event(self, _):
        """
        When the node list has changed

        :param _: NodesEvent instance
        :return:
        """
        # update model
        self.nodesTableView.model().init_data()
        # resize view
        self.nodesTableView.resizeColumnsToContents()

    def on_node_context_menu(self, position: QPoint):
        """
        When right button on node table view

        :param position: QPoint instance
        :return:
        """
        index = self.nodesTableView.indexAt(position)
        if index.isValid():
            # get selected node
            row = index.row()
            node = self.nodes_table_model.nodes[row]
            # display popup menu at click position
            NodePopupMenu(self.application, node).exec_(
                self.nodesTableView.mapToGlobal(position)
            )

    def on_node_table_double_click(self, index):
        """
        Triggered when user double-click on a row of node table view
        """
        row = index.row()
        # check index...
        if 0 <= row < len(self.nodes_table_model.nodes):
            self.selected_node = self.nodes_table_model.nodes[row]
            self.thread_manager.start(
                self.toggle_node_connection, self._on_finished_toggle_node_connection
            )

    def toggle_node_connection(self):
        """
        Toggle node connection

        :return:
        """
        if self.selected_node is None:
            return
        # current url connected
        current_node_url = self.application.nodes.get_current_url()

        # if same server...
        if self.selected_node.url == current_node_url:
            # toggle connection...
            if self.application.connections.node.is_connected():
                self.application.nodes.network_disconnect()
            else:
                self.application.nodes.network_connect()
        else:
            # connect to another server...
            self.application.nodes.set_current_url(self.selected_node.url)
            self.application.nodes.network_connect()

    def _on_finished_toggle_node_connection(self):
        """
        Triggered when toggle_node_connection is finished

        :return:
        """
        if self.application.connections.node.is_connected():
            self.event_bus.node_connected.emit()
        else:
            self.event_bus.node_disconnected.emit()


if __name__ == "__main__":
    qapp = QApplication(sys.argv)

    application_ = Application(DATA_PATH)

    main_window = QMainWindow()
    main_window.show()

    main_window.setCentralWidget(NetworkNodesWidget(application_, main_window))

    sys.exit(qapp.exec_())
