"""SVS unit tests."""
