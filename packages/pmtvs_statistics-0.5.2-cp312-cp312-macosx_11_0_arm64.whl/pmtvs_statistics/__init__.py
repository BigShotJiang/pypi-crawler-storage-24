"""
pmtvs-statistics — Statistics and calculus primitives for signal analysis.

numpy in, number out.
"""

__version__ = "0.5.1"
BACKEND = "rust"

try:
    import pmtvs_statistics._rust  # noqa: F401 — validates Rust extension is loadable
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-statistics && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

# --- Public API ---
from pmtvs_statistics.statistics import (
    mean,
    std,
    variance,
    min_max,
    percentiles,
    skewness,
    kurtosis,
    rms,
    peak_to_peak,
    crest_factor,
    pulsation_index,
    zero_crossings,
    mean_crossings,
)

from pmtvs_statistics.calculus import (
    derivative,
    integral,
    curvature,
    rate_of_change,
)

from pmtvs_statistics.derivatives import (
    first_derivative,
    second_derivative,
    gradient,
    laplacian,
    finite_difference,
    velocity,
    acceleration,
    jerk,
    smoothed_derivative,
)

from pmtvs_statistics.normalization import (
    zscore_normalize,
    robust_normalize,
    mad_normalize,
    minmax_normalize,
    quantile_normalize,
    inverse_normalize,
    normalize,
    recommend_method,
)

__all__ = [
    "__version__",
    "BACKEND",
    # Statistics
    "mean",
    "std",
    "variance",
    "min_max",
    "percentiles",
    "skewness",
    "kurtosis",
    "rms",
    "peak_to_peak",
    "crest_factor",
    "pulsation_index",
    "zero_crossings",
    "mean_crossings",
    # Calculus
    "derivative",
    "integral",
    "curvature",
    "rate_of_change",
    # Derivatives
    "first_derivative",
    "second_derivative",
    "gradient",
    "laplacian",
    "finite_difference",
    "velocity",
    "acceleration",
    "jerk",
    "smoothed_derivative",
    # Normalization
    "zscore_normalize",
    "robust_normalize",
    "mad_normalize",
    "minmax_normalize",
    "quantile_normalize",
    "inverse_normalize",
    "normalize",
    "recommend_method",
]
