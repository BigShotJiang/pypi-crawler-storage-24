"""
Calculus Primitives

Derivatives, integrals, and curvature for signal analysis.
"""

import numpy as np

import pmtvs_statistics._rust as _rust


def derivative(signal: np.ndarray, order: int = 1, dt: float = 1.0) -> np.ndarray:
    """
    Compute numerical derivative of signal.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    order : int
        Derivative order (1 = first derivative, 2 = second, etc.)
    dt : float
        Time step between samples

    Returns
    -------
    np.ndarray
        Derivative (length = len(signal) - order)
    """
    if order == 1:
        return _rust.derivative(signal, dt)

    signal = np.asarray(signal).flatten()
    result = signal.copy()

    for _ in range(order):
        if len(result) < 2:
            return np.array([np.nan])
        result = np.diff(result) / dt

    return result


def integral(signal: np.ndarray, dt: float = 1.0) -> np.ndarray:
    """
    Compute cumulative integral of signal (trapezoidal rule).

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    dt : float
        Time step between samples

    Returns
    -------
    np.ndarray
        Cumulative integral
    """
    return _rust.integral(signal, dt)


def curvature(signal: np.ndarray, dt: float = 1.0) -> np.ndarray:
    """
    Compute curvature of signal.

    Curvature = |y''| / (1 + y'^2)^(3/2)

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    dt : float
        Time step between samples

    Returns
    -------
    np.ndarray
        Curvature values
    """
    return _rust.curvature(signal, dt)


def rate_of_change(signal: np.ndarray, window: int = 1) -> np.ndarray:
    """
    Compute rate of change over a sliding window.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    window : int
        Window size for computing rate of change

    Returns
    -------
    np.ndarray
        Rate of change values
    """
    if window == 1:
        return _rust.rate_of_change(signal)

    signal = np.asarray(signal).flatten()
    if len(signal) <= window:
        return np.array([np.nan])

    roc = np.zeros(len(signal) - window)
    for i in range(len(signal) - window):
        if signal[i] != 0:
            roc[i] = (signal[i + window] - signal[i]) / abs(signal[i])
        else:
            roc[i] = np.nan

    return roc
