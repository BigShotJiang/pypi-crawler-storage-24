"""
Statistics Primitives

Basic statistical measures for signal analysis.
"""

import numpy as np
from typing import Tuple

import pmtvs_statistics._rust as _rust


def mean(signal: np.ndarray) -> float:
    """
    Compute mean of signal.

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    float
        Mean value
    """
    return _rust.mean(signal)


def std(signal: np.ndarray, ddof: int = 1) -> float:
    """
    Compute standard deviation of signal.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    ddof : int
        Delta degrees of freedom (default: 1 for sample std)

    Returns
    -------
    float
        Standard deviation
    """
    return _rust.std(signal, ddof)


def variance(signal: np.ndarray, ddof: int = 1) -> float:
    """
    Compute variance of signal.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    ddof : int
        Delta degrees of freedom (default: 1 for sample variance)

    Returns
    -------
    float
        Variance
    """
    return _rust.variance(signal, ddof)


def min_max(signal: np.ndarray) -> Tuple[float, float]:
    """
    Compute minimum and maximum of signal.

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    tuple
        (min, max)
    """
    return _rust.min_max(signal)


def percentiles(signal: np.ndarray, q: Tuple[float, ...] = (25, 50, 75)) -> Tuple[float, ...]:
    """
    Compute percentiles of signal.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    q : tuple
        Percentiles to compute (default: 25, 50, 75)

    Returns
    -------
    tuple
        Percentile values
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    result = _rust.percentiles(signal, list(q))
    return tuple(float(v) for v in result)


def skewness(signal: np.ndarray) -> float:
    """
    Compute skewness of signal.

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    float
        Skewness (0 = symmetric, >0 = right tail, <0 = left tail)
    """
    return _rust.skewness(signal)


def kurtosis(signal: np.ndarray, fisher: bool = True) -> float:
    """
    Compute kurtosis of signal.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fisher : bool
        If True, return excess kurtosis (normal = 0)

    Returns
    -------
    float
        Kurtosis
    """
    return _rust.kurtosis(signal, fisher)


def rms(signal: np.ndarray) -> float:
    """
    Compute root mean square of signal.

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    float
        RMS value
    """
    return _rust.rms(signal)


def peak_to_peak(signal: np.ndarray) -> float:
    """
    Compute peak-to-peak amplitude.

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    float
        Peak-to-peak value (max - min)
    """
    return _rust.peak_to_peak(signal)


def crest_factor(signal: np.ndarray) -> float:
    """
    Compute crest factor (peak / RMS).

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    float
        Crest factor
    """
    return _rust.crest_factor(signal)


def pulsation_index(signal: np.ndarray) -> float:
    """
    Compute pulsation index (peak-to-peak / mean).

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    float
        Pulsation index
    """
    return _rust.pulsation_index(signal)


def zero_crossings(signal: np.ndarray) -> int:
    """
    Count zero crossings in signal.

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    int
        Number of zero crossings
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    return int(_rust.zero_crossings(signal))


def mean_crossings(signal: np.ndarray) -> int:
    """
    Count mean crossings in signal.

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    int
        Number of mean crossings
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    return int(_rust.mean_crossings(signal))
