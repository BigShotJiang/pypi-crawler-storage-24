"""Contract verification for ticket acceptance criteria.

After a ticket executes, this module programmatically verifies that acceptance
criteria are actually satisfied in the repo — not just claimed in the prompt.

Supported patterns (parsed from acceptance criteria strings):
  - "function <name> exists [in <file>]"  → AST: def <name> in .py files
  - "class <name> exists [in <file>]"     → AST: class <name> in .py files
  - "file <path> exists"                  → filesystem presence check
  - "test <name> exists [in <file>]"      → AST: def test_<name>/ test_<name> in test files

The verifier is intentionally conservative: a contract that cannot be parsed
from a criterion string is skipped (not failed), so noise is kept low.
"""

from __future__ import annotations

import ast
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class Contract:
    """A single verifiable acceptance criterion extracted from a ticket.

    Attributes:
        kind: Category of the contract: ``"function"``, ``"class"``,
            ``"file"``, or ``"test"``.
        name: The symbol or path to verify.
        file_hint: Optional file path extracted from the criterion string.
            Used as the first lookup target before falling back to repo scan.
        source: The original acceptance criterion string, for diagnostics.
    """

    kind: str
    name: str
    file_hint: str = ""
    source: str = ""


@dataclass
class ContractResult:
    """Outcome of verifying a single contract.

    Attributes:
        contract: The contract that was verified.
        verified: ``True`` if the contract is satisfied in the repo.
        detail: Human-readable explanation of the outcome (pass or fail reason).
    """

    contract: Contract
    verified: bool
    detail: str = ""


# ---------------------------------------------------------------------------
# Regex patterns for criterion parsing
# ---------------------------------------------------------------------------

# "function add exists" / "function add exists in math.py"
_RE_FUNCTION = re.compile(
    r"\bfunction\s+([\w.]+)\s+exists(?:\s+in\s+(\S+))?",
    re.IGNORECASE,
)
# "class Foo exists" / "class Foo exists in models.py"
_RE_CLASS = re.compile(
    r"\bclass\s+([\w.]+)\s+exists(?:\s+in\s+(\S+))?",
    re.IGNORECASE,
)
# "file config.yaml exists" / "file src/foo.py exists"
_RE_FILE = re.compile(
    r"\bfile\s+(\S+)\s+exists",
    re.IGNORECASE,
)
# "test test_add_two exists" / "test add_two exists" / "test function test_add_two"
_RE_TEST = re.compile(
    r"\btest(?:\s+function)?\s+(test_[\w]+|[\w]+)\s+exists(?:\s+in\s+(\S+))?",
    re.IGNORECASE,
)

# Directories to skip when searching the repo
_SKIP_DIRS = frozenset({
    ".git", ".venv", "venv", "__pycache__", "node_modules",
    "runs", ".saturnday", ".pytest_cache",
})


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def extract_contracts(acceptance_criteria: tuple[str, ...]) -> list[Contract]:
    """Parse acceptance criterion strings into verifiable ``Contract`` objects.

    Each criterion string is matched against known patterns.  Unrecognised
    strings produce no contracts (they are silently skipped to keep noise low).

    Args:
        acceptance_criteria: Tuple of criterion strings from ``TicketSpec``.

    Returns:
        List of ``Contract`` objects, one per matched pattern per criterion.
        May be empty if no criterion string matches a known pattern.
    """
    contracts: list[Contract] = []
    seen: set[tuple[str, str]] = set()

    for criterion in acceptance_criteria:
        if not isinstance(criterion, str) or not criterion.strip():
            continue

        _parse_criterion(criterion, contracts, seen)

    logger.debug(
        "extract_contracts: %d criterion(s) → %d contract(s)",
        len(acceptance_criteria), len(contracts),
    )
    return contracts


def verify_contracts(
    contracts: list[Contract],
    repo_path: Path,
) -> list[ContractResult]:
    """Verify each contract against the actual state of the repo.

    Args:
        contracts: Contracts extracted by ``extract_contracts``.
        repo_path: Absolute path to the repository root.

    Returns:
        One ``ContractResult`` per contract, in the same order.
        Results include pass/fail and a human-readable detail string.
    """
    results: list[ContractResult] = []
    for c in contracts:
        try:
            result = _dispatch(c, repo_path)
        except Exception as exc:
            logger.warning(
                "verify_contracts: unexpected error verifying %s %r: %s",
                c.kind, c.name, exc,
            )
            result = ContractResult(
                contract=c,
                verified=False,
                detail=f"Verification error: {exc}",
            )
        results.append(result)
    return results


# ---------------------------------------------------------------------------
# Criterion parsing internals
# ---------------------------------------------------------------------------

def _parse_criterion(
    criterion: str,
    out: list[Contract],
    seen: set[tuple[str, str]],
) -> None:
    """Try every pattern against *criterion* and append matched contracts."""
    for m in _RE_FUNCTION.finditer(criterion):
        _add(out, seen, "function", m.group(1), m.group(2) or "", criterion)
    for m in _RE_CLASS.finditer(criterion):
        _add(out, seen, "class", m.group(1), m.group(2) or "", criterion)
    for m in _RE_FILE.finditer(criterion):
        _add(out, seen, "file", m.group(1), "", criterion)
    for m in _RE_TEST.finditer(criterion):
        raw_name = m.group(1)
        # Normalise: "add_two" → "test_add_two" if not already prefixed
        name = raw_name if raw_name.startswith("test_") else f"test_{raw_name}"
        _add(out, seen, "test", name, m.group(2) or "", criterion)


def _add(
    out: list[Contract],
    seen: set[tuple[str, str]],
    kind: str,
    name: str,
    file_hint: str,
    source: str,
) -> None:
    key = (kind, name)
    if key in seen:
        return
    seen.add(key)
    out.append(Contract(kind=kind, name=name, file_hint=file_hint, source=source))


# ---------------------------------------------------------------------------
# Verification dispatch
# ---------------------------------------------------------------------------

def _dispatch(contract: Contract, repo_path: Path) -> ContractResult:
    """Route a contract to the appropriate verifier."""
    kind = contract.kind
    if kind == "function":
        return _verify_function(contract, repo_path)
    elif kind == "class":
        return _verify_class(contract, repo_path)
    elif kind == "file":
        return _verify_file(contract, repo_path)
    elif kind == "test":
        return _verify_test(contract, repo_path)
    else:
        return ContractResult(
            contract=contract,
            verified=False,
            detail=f"Unknown contract kind: {kind!r}",
        )


# ---------------------------------------------------------------------------
# AST helpers
# ---------------------------------------------------------------------------

def _parse_file(path: Path) -> ast.Module | None:
    """Parse a Python file; return None on any error."""
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        return ast.parse(source, filename=str(path))
    except Exception:
        return None


def _collect_functions(tree: ast.Module) -> set[str]:
    """Return all function/method names in the AST (top-level and nested)."""
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            names.add(node.name)
    return names


def _collect_classes(tree: ast.Module) -> set[str]:
    """Return all class names in the AST."""
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            names.add(node.name)
    return names


def _py_files(repo_path: Path) -> list[Path]:
    """Yield .py files under repo_path, skipping build/cache directories."""
    try:
        return [
            p for p in repo_path.rglob("*.py")
            if not any(part in _SKIP_DIRS for part in p.parts)
        ]
    except Exception:
        return []


def _test_files(repo_path: Path) -> list[Path]:
    """Yield test_*.py files under repo_path, skipping build/cache dirs."""
    try:
        return [
            p for p in repo_path.rglob("test_*.py")
            if not any(part in _SKIP_DIRS for part in p.parts)
        ]
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Per-kind verifiers
# ---------------------------------------------------------------------------

def _verify_function(contract: Contract, repo_path: Path) -> ContractResult:
    """Verify that a function with ``contract.name`` exists somewhere in the repo."""
    # Try file hint first
    if contract.file_hint:
        target = repo_path / contract.file_hint
        if target.exists():
            tree = _parse_file(target)
            if tree is not None and contract.name in _collect_functions(tree):
                return ContractResult(
                    contract=contract, verified=True,
                    detail=f"function {contract.name!r} found in {contract.file_hint}",
                )

    # Fallback: scan all .py files
    for py in _py_files(repo_path):
        tree = _parse_file(py)
        if tree is None:
            continue
        if contract.name in _collect_functions(tree):
            rel = _rel(py, repo_path)
            return ContractResult(
                contract=contract, verified=True,
                detail=f"function {contract.name!r} found in {rel}",
            )

    return ContractResult(
        contract=contract, verified=False,
        detail=f"function {contract.name!r} not found in repo",
    )


def _verify_class(contract: Contract, repo_path: Path) -> ContractResult:
    """Verify that a class with ``contract.name`` exists somewhere in the repo."""
    if contract.file_hint:
        target = repo_path / contract.file_hint
        if target.exists():
            tree = _parse_file(target)
            if tree is not None and contract.name in _collect_classes(tree):
                return ContractResult(
                    contract=contract, verified=True,
                    detail=f"class {contract.name!r} found in {contract.file_hint}",
                )

    for py in _py_files(repo_path):
        tree = _parse_file(py)
        if tree is None:
            continue
        if contract.name in _collect_classes(tree):
            rel = _rel(py, repo_path)
            return ContractResult(
                contract=contract, verified=True,
                detail=f"class {contract.name!r} found in {rel}",
            )

    return ContractResult(
        contract=contract, verified=False,
        detail=f"class {contract.name!r} not found in repo",
    )


def _verify_file(contract: Contract, repo_path: Path) -> ContractResult:
    """Verify that the file at ``contract.name`` exists relative to repo_path."""
    target = repo_path / contract.name
    if target.exists():
        return ContractResult(
            contract=contract, verified=True,
            detail=f"file {contract.name!r} exists",
        )
    return ContractResult(
        contract=contract, verified=False,
        detail=f"file {contract.name!r} does not exist at {target}",
    )


def _verify_test(contract: Contract, repo_path: Path) -> ContractResult:
    """Verify that a test function with ``contract.name`` exists in any test file."""
    if contract.file_hint:
        target = repo_path / contract.file_hint
        if target.exists():
            tree = _parse_file(target)
            if tree is not None and contract.name in _collect_functions(tree):
                return ContractResult(
                    contract=contract, verified=True,
                    detail=f"test {contract.name!r} found in {contract.file_hint}",
                )

    for tf in _test_files(repo_path):
        tree = _parse_file(tf)
        if tree is None:
            continue
        if contract.name in _collect_functions(tree):
            rel = _rel(tf, repo_path)
            return ContractResult(
                contract=contract, verified=True,
                detail=f"test {contract.name!r} found in {rel}",
            )

    return ContractResult(
        contract=contract, verified=False,
        detail=f"test {contract.name!r} not found in any test file",
    )


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def _rel(path: Path, base: Path) -> str:
    """Return path relative to base; fall back to str(path) if not possible."""
    try:
        return str(path.relative_to(base))
    except ValueError:
        return str(path)


def format_contract_results(results: list[ContractResult]) -> str:
    """Format contract results into a compact multi-line string for repair context.

    Args:
        results: List of ``ContractResult`` objects.

    Returns:
        Human-readable string summarising each result, one per line.
    """
    lines: list[str] = []
    for r in results:
        status = "PASS" if r.verified else "FAIL"
        lines.append(f"  [{status}] {r.contract.kind} {r.contract.name!r}: {r.detail}")
    return "\n".join(lines)
