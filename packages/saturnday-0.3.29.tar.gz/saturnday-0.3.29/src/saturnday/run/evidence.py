"""Per-ticket evidence recording and run summary output.

Writes a JSON evidence file per ticket and a final run summary, providing
an audit trail of what each coder attempt produced and how governance
ruled on it.

Directory structure produced:
    <output_dir>/
      run-metadata.json          # run-level info (config, plan, start time)
      run-summary.json           # final run outcome
      analytics.json             # computed run analytics
      tickets/
        <ticket_id>/
          attempt_1.json
          attempt_2.json
      phases/
        phase-<n>.json           # per-phase ticket outcomes
      evidence/
        run/
          ledger.json
          report.md
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

from saturnday._types import CoderConfig, RunResult, TicketResult
from saturnday.shared.evidence_schema import SCHEMA_VERSION  # noqa: F401 — shared schema constant

if TYPE_CHECKING:
    from saturnday.run.run_ledger import RunLedger

logger = logging.getLogger(__name__)

_SATURNDAY_VERSION = "0.1.0"


@dataclass
class TicketEvidence:
    """Audit trail for a single ticket execution.

    Attributes:
        ticket_id: The ticket identifier.
        attempt: Attempt number (1-based).
        coder_response: Raw text from the coder (truncated for storage).
        changed_files: Files written by the coder.
        governance_disposition: ``PASS`` or ``FAIL`` from governance.
        governance_findings: Governance check findings.
        governance_evidence_path: Filesystem path to the raw governance
            evidence JSON produced by ``run_governance_check``. Empty string
            when governance did not run or produced no path (e.g. error paths).
        error: Error message if the attempt failed.
        timestamp: UTC timestamp of the attempt.
    """

    ticket_id: str
    attempt: int
    coder_response: str = ""
    changed_files: list[str] = field(default_factory=list)
    governance_disposition: str = ""
    governance_findings: list[dict[str, Any]] = field(default_factory=list)
    governance_evidence_path: str = ""
    error: str = ""
    timestamp: str = ""

    def __post_init__(self) -> None:
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def write_ticket_evidence(evidence: TicketEvidence, output_dir: Path) -> Path:
    """Write a ticket evidence JSON file.

    Writes to ``<output_dir>/tickets/<ticket_id>/attempt_<n>.json``.
    Intermediate directories are created automatically.

    Args:
        evidence: The ticket evidence to record.
        output_dir: Base output directory (not the tickets subdir).

    Returns:
        Path to the written evidence file.
    """
    ticket_dir = output_dir / "tickets" / evidence.ticket_id
    ticket_dir.mkdir(parents=True, exist_ok=True)
    filename = f"attempt_{evidence.attempt}.json"
    path = ticket_dir / filename

    # Truncate coder response for storage
    data = asdict(evidence)
    if len(data.get("coder_response", "")) > 50_000:
        data["coder_response"] = data["coder_response"][:50_000] + "\n... (truncated)"

    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    logger.info("Wrote ticket evidence: %s", path)
    return path


def write_run_metadata(
    config: CoderConfig,
    plan_path: str | Path,
    output_dir: Path,
    auth_mode: str = "",
    backend_capabilities: dict[str, bool] | None = None,
) -> Path:
    """Write a JSON file with run-level metadata at run start.

    Written to ``<output_dir>/run-metadata.json``.  Called once before the
    ticket loop begins so that a run can be identified even if it crashes.

    Args:
        config: The coder configuration for this run.
        plan_path: Path to the plan JSON file that was loaded.
        output_dir: Base output directory.
        auth_mode: The detected auth mode for the backend (e.g. ``api_key``,
            ``local_interactive``).  Empty string when not provided.
        backend_capabilities: Capability flags for the backend as returned by
            ``capability_matrix``.  ``None`` is written as an empty dict.

    Returns:
        Path to the written metadata file.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "run-metadata.json"

    data: dict[str, Any] = {
        "start_time": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "plan_path": str(plan_path),
        "backend": config.backend,
        "auth_mode": auth_mode,
        "backend_capabilities": backend_capabilities if backend_capabilities is not None else {},
        "saturnday_version": _SATURNDAY_VERSION,
    }

    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    logger.info("Wrote run metadata: %s", path)
    return path


def write_phase_summary(ledger: "RunLedger", output_dir: Path) -> list[Path]:
    """Write per-phase outcome JSON files.

    Writes one file per phase to ``<output_dir>/phases/phase-<phase_id>.json``.
    If the ledger has no phases, returns an empty list and writes nothing.

    The phase file contains the phase metadata (id, name, status, timestamps)
    plus per-ticket outcomes drawn from the ledger's ticket statuses.

    Args:
        ledger: The completed run ledger with phase and ticket outcomes.
        output_dir: Base output directory.

    Returns:
        List of paths written (one per phase).
    """
    if not ledger.phase_statuses:
        return []

    phases_dir = output_dir / "phases"
    phases_dir.mkdir(parents=True, exist_ok=True)

    written: list[Path] = []
    for phase in ledger.phase_statuses:
        ticket_outcomes: list[dict[str, Any]] = []
        for tid in phase.ticket_ids:
            ts = ledger.ticket_statuses.get(tid)
            if ts is not None:
                ticket_outcomes.append({
                    "ticket_id": ts.ticket_id,
                    "disposition": ts.disposition,
                    "failure_category": ts.failure_category,
                })
            else:
                ticket_outcomes.append({
                    "ticket_id": tid,
                    "disposition": "PENDING",
                    "failure_category": "",
                })

        data: dict[str, Any] = {
            "phase_id": phase.phase_id,
            "name": phase.name,
            "status": phase.status,
            "started_utc": phase.started_utc,
            "completed_utc": phase.completed_utc,
            "tickets": ticket_outcomes,
        }

        path = phases_dir / f"phase-{phase.phase_id}.json"
        path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
        logger.info("Wrote phase summary: %s", path)
        written.append(path)

    return written


def compute_run_analytics(run_result: RunResult) -> dict[str, Any]:
    """Compute analytics from a completed RunResult.

    Returns a flat analytics dict suitable for JSON serialisation and
    downstream dashboards.  Fields ``backend`` and ``auth_mode`` are left as
    empty strings; the caller may populate them from their CoderConfig if
    desired.

    Args:
        run_result: The completed run result.

    Returns:
        Analytics dict with acceptance rate, retry stats, failure breakdown,
        and a senior quality verdict.
    """
    total = run_result.total_tickets
    avg_retries = (
        sum(tr.attempts for tr in run_result.ticket_results) / total
        if total
        else 0.0
    )
    return {
        "acceptance_rate": run_result.passed / total if total else 0.0,
        "avg_retries": avg_retries,
        "failure_category_distribution": _count_failure_categories(run_result),
        "total_tickets": total,
        "passed": run_result.passed,
        "failed": run_result.failed,
        "skipped": run_result.skipped,
        "stop_reason": run_result.stop_reason,
        "definition_of_done_met": run_result.definition_of_done_met,
        "backend": "",
        "auth_mode": "",
        "cost_tracking": "partial",  # CLI backends don't expose token usage yet
        "senior_quality_verdict": _compute_quality_verdict(run_result),
    }


def _count_failure_categories(run_result: RunResult) -> dict[str, int]:
    """Count occurrences of each failure_category across all ticket results.

    Only failed tickets with a non-empty failure_category are counted.
    Tickets without a category contribute to an ``"uncategorised"`` bucket
    when they have a FAIL disposition.

    Args:
        run_result: The completed run result.

    Returns:
        Mapping of category name to occurrence count.
    """
    counts: dict[str, int] = {}
    for tr in run_result.ticket_results:
        if tr.disposition != "FAIL":
            continue
        category = tr.failure_category or "uncategorised"
        counts[category] = counts.get(category, 0) + 1
    return counts


def _compute_quality_verdict(run_result: RunResult) -> dict[str, Any]:
    """Summarise senior quality gate outcomes across all ticket results.

    Post-check data is not stored directly on TicketResult (it is embedded in
    the per-attempt evidence JSON files).  This verdict is therefore derived
    from governance_disposition and error fields, which do capture post-check
    failures when they trigger a retry or final FAIL.

    Returns:
        Dict with:
        - ``governance_pass_count``: tickets with governance PASS
        - ``governance_fail_count``: tickets with governance FAIL
        - ``error_count``: tickets whose error field is non-empty
        - ``quality_level``: ``"green"``, ``"yellow"``, or ``"red"`` summary
    """
    gov_pass = sum(
        1 for tr in run_result.ticket_results if tr.governance_disposition == "PASS"
    )
    gov_fail = sum(
        1 for tr in run_result.ticket_results if tr.governance_disposition == "FAIL"
    )
    error_count = sum(1 for tr in run_result.ticket_results if tr.error)

    total = run_result.total_tickets
    pass_rate = run_result.passed / total if total else 0.0

    if pass_rate >= 0.9 and gov_fail == 0:
        quality_level = "green"
    elif pass_rate >= 0.5:
        quality_level = "yellow"
    else:
        quality_level = "red"

    return {
        "governance_pass_count": gov_pass,
        "governance_fail_count": gov_fail,
        "error_count": error_count,
        "quality_level": quality_level,
    }


def write_analytics(analytics: dict[str, Any], output_dir: Path) -> Path:
    """Write run analytics to ``<output_dir>/analytics.json``.

    Args:
        analytics: The analytics dict produced by ``compute_run_analytics``.
        output_dir: Base output directory.

    Returns:
        Path to the written analytics file.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "analytics.json"
    path.write_text(json.dumps(analytics, indent=2) + "\n", encoding="utf-8")
    logger.info("Wrote run analytics: %s", path)
    return path


def write_run_summary(result: RunResult, output_dir: Path) -> Path:
    """Write a JSON summary of the complete plan execution.

    Args:
        result: The run result to summarize.
        output_dir: Directory for the summary file.

    Returns:
        Path to the written summary file.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "run-summary.json"

    data: dict[str, Any] = {
        "project_id": result.project_id,
        "total_tickets": result.total_tickets,
        "passed": result.passed,
        "failed": result.failed,
        "skipped": result.skipped,
        "definition_of_done_met": result.definition_of_done_met,
        "stop_reason": result.stop_reason,
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "ticket_results": [],
    }

    # Compute failure category breakdown
    failure_categories: dict[str, int] = {}
    for tr in result.ticket_results:
        data["ticket_results"].append({
            "ticket_id": tr.ticket_id,
            "disposition": tr.disposition,
            "attempts": tr.attempts,
            "changed_files": list(tr.changed_files),
            "governance_disposition": tr.governance_disposition,
            "governance_evidence_path": tr.governance_evidence_path,
            "error": tr.error,
            "failure_category": tr.failure_category,
        })
        if tr.failure_category:
            failure_categories[tr.failure_category] = (
                failure_categories.get(tr.failure_category, 0) + 1
            )

    if failure_categories:
        data["failure_categories"] = failure_categories

    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    logger.info("Wrote run summary: %s", path)
    return path
