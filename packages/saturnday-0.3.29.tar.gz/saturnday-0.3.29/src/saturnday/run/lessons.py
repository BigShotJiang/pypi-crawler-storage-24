"""Lessons database — learn from past failures.

SQLite-backed storage at ~/.saturnday/lessons.db. Records failure patterns
from ticket runs so future runs can avoid repeating the same mistakes.

Lessons are advisory only: they are injected into coder prompts as context,
never as hard gates. Confidence increments when the same rule fires again
for the same project.
"""

from __future__ import annotations

import logging
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

_DEFAULT_DB_PATH = Path.home() / ".saturnday" / "lessons.db"


@dataclass
class Lesson:
    """A single lesson recorded from a failed ticket run.

    Attributes:
        project_id: Identifier for the project (e.g. repo name or plan project_id).
        ticket_id: The ticket that produced this failure.
        failure_type: Category of failure — one of: governance_fail,
            post_check_fail, coder_error, contract_fail.
        rule: The specific check or pattern that failed (stable identifier,
            used for deduplication across runs).
        description: Human-readable description of the failure.
        confidence: Number of times this rule has fired for the project.
            Starts at 1, incremented on each recurrence.
    """

    project_id: str
    ticket_id: str
    failure_type: str  # governance_fail | post_check_fail | coder_error | contract_fail
    rule: str  # the specific check/pattern that failed
    description: str
    confidence: int = 1  # incremented on repeated failures


def init_db(db_path: Path = _DEFAULT_DB_PATH) -> sqlite3.Connection:
    """Create or open the lessons database.

    Creates the database file and parent directories if they do not exist.
    Idempotent — safe to call on an already-initialised database.

    Args:
        db_path: Path to the SQLite database file. Defaults to
            ``~/.saturnday/lessons.db``.

    Returns:
        Open connection to the lessons database.
    """
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS lessons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id TEXT NOT NULL,
            ticket_id TEXT NOT NULL,
            failure_type TEXT NOT NULL,
            rule TEXT NOT NULL,
            description TEXT NOT NULL,
            confidence INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_lessons_rule ON lessons(rule)"
    )
    conn.commit()
    logger.debug("Lessons DB opened at %s", db_path)
    return conn


def store_lesson(conn: sqlite3.Connection, lesson: Lesson) -> None:
    """Store a lesson. If same rule exists for this project, increment confidence.

    Deduplication key is ``(project_id, rule)``. On a match the confidence
    counter is incremented and the description is updated to the latest
    failure description. ticket_id is not part of the key so cross-ticket
    recurrences still accumulate confidence.

    Args:
        conn: Open database connection from :func:`init_db`.
        lesson: The lesson to persist.
    """
    now = datetime.now(timezone.utc).isoformat()
    existing = conn.execute(
        "SELECT id, confidence FROM lessons WHERE project_id = ? AND rule = ?",
        (lesson.project_id, lesson.rule),
    ).fetchone()

    if existing:
        conn.execute(
            "UPDATE lessons SET confidence = ?, description = ?, updated_at = ? WHERE id = ?",
            (existing[1] + 1, lesson.description, now, existing[0]),
        )
        logger.debug(
            "Lesson confidence incremented: rule=%s project=%s new_confidence=%d",
            lesson.rule,
            lesson.project_id,
            existing[1] + 1,
        )
    else:
        conn.execute(
            """INSERT INTO lessons
               (project_id, ticket_id, failure_type, rule, description, confidence, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                lesson.project_id,
                lesson.ticket_id,
                lesson.failure_type,
                lesson.rule,
                lesson.description,
                lesson.confidence,
                now,
                now,
            ),
        )
        logger.debug(
            "New lesson stored: rule=%s project=%s", lesson.rule, lesson.project_id
        )
    conn.commit()


def load_lessons(
    conn: sqlite3.Connection,
    *,
    project_id: str = "",
    min_confidence: int = 1,
) -> list[Lesson]:
    """Load lessons, optionally filtered by project and minimum confidence.

    Results are sorted by confidence descending so the most frequently
    repeated failures appear first.

    Args:
        conn: Open database connection from :func:`init_db`.
        project_id: If non-empty, restrict to lessons for this project.
        min_confidence: Only return lessons with confidence >= this value.

    Returns:
        List of :class:`Lesson` objects ordered by confidence descending.
    """
    query = (
        "SELECT project_id, ticket_id, failure_type, rule, description, confidence "
        "FROM lessons WHERE confidence >= ?"
    )
    params: list[object] = [min_confidence]

    if project_id:
        query += " AND project_id = ?"
        params.append(project_id)

    query += " ORDER BY confidence DESC"
    rows = conn.execute(query, params).fetchall()
    return [Lesson(*row) for row in rows]


def format_lessons_for_prompt(lessons: list[Lesson]) -> str:
    """Format lessons as context for the coder prompt.

    Caps output at the 10 most confident lessons to avoid bloating the
    context window. Returns an empty string when there are no lessons so
    callers can skip injection cleanly.

    Args:
        lessons: Lessons from :func:`load_lessons`, already sorted by
            confidence descending.

    Returns:
        Formatted string suitable for prepending to a coder prompt, or
        empty string when ``lessons`` is empty.
    """
    if not lessons:
        return ""
    lines = ["LESSONS FROM PAST FAILURES (avoid repeating these patterns):"]
    for lesson in lessons[:10]:  # cap at 10 most confident
        lines.append(
            f"- [{lesson.failure_type}] {lesson.rule}: "
            f"{lesson.description} (seen {lesson.confidence}x)"
        )
    return "\n".join(lines)
