"""Shared evidence schema constants.

Both the Guard evidence module (``saturnday.evidence``) and the Run evidence
module (``saturnday.run.evidence``) import from here so that schema versioning
stays in one place.  Update ``SCHEMA_VERSION`` here when the evidence format
changes; both modules will pick it up automatically.
"""

SCHEMA_VERSION = "1.0.0"

# Canonical output sub-directory names within any evidence root.
# These are conventions, not enforcement — callers decide their root.
EVIDENCE_DIR_GUARD = "evidence/governance"
EVIDENCE_DIR_RUN = "evidence/run"
EVIDENCE_DIR_REPAIR = "evidence/repair"
