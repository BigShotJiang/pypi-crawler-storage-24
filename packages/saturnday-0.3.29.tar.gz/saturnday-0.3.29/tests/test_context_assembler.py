"""Tests for saturnday.context_assembler."""

from pathlib import Path

from saturnday._types import TicketSpec
from saturnday.context_assembler import (
    assemble_messages,
    build_system_prompt,
    build_ticket_prompt,
    load_standards_context,
)


class TestLoadStandardsContext:
    def test_loads_existing_standards(self, tmp_path: Path) -> None:
        (tmp_path / "coder_standards_v1.txt").write_text("Rule 1: be good")
        load_standards_context.cache_clear()
        result = load_standards_context(str(tmp_path))
        assert "Rule 1: be good" in result

    def test_missing_dir_returns_empty(self, tmp_path: Path) -> None:
        load_standards_context.cache_clear()
        result = load_standards_context(str(tmp_path / "nonexistent"))
        assert result == ""

    def test_result_is_cached(self, tmp_path: Path) -> None:
        (tmp_path / "coder_standards_v1.txt").write_text("cached")
        load_standards_context.cache_clear()
        r1 = load_standards_context(str(tmp_path))
        r2 = load_standards_context(str(tmp_path))
        assert r1 is r2  # Same object = cached


class TestBuildSystemPrompt:
    def test_includes_standards(self, tmp_path: Path) -> None:
        (tmp_path / "coder_standards_v1.txt").write_text("Standard A")
        prompts_dir = tmp_path / "prompts"
        prompts_dir.mkdir()
        (prompts_dir / "coder_system_senior_v1.txt").write_text("You are an engineer.")
        load_standards_context.cache_clear()
        build_system_prompt.cache_clear()
        result = build_system_prompt(str(tmp_path))
        assert "You are an engineer." in result
        assert "Standard A" in result

    def test_works_without_prompt_file(self, tmp_path: Path) -> None:
        (tmp_path / "coder_standards_v1.txt").write_text("Standard B")
        load_standards_context.cache_clear()
        build_system_prompt.cache_clear()
        result = build_system_prompt(str(tmp_path))
        assert "Standard B" in result


class TestBuildTicketPrompt:
    def test_includes_goal(self) -> None:
        ticket = TicketSpec(ticket_id="T001", goal="Create scaffold")
        result = build_ticket_prompt(ticket, "", "")
        assert "T001" in result
        assert "Create scaffold" in result

    def test_includes_plan_notes(self) -> None:
        ticket = TicketSpec(ticket_id="T001", goal="Test")
        result = build_ticket_prompt(ticket, "", "Use absolute imports")
        assert "Use absolute imports" in result

    def test_includes_state_summary(self) -> None:
        ticket = TicketSpec(ticket_id="T002", goal="Add feature")
        result = build_ticket_prompt(ticket, "Existing modules: foo.py", "")
        assert "Existing modules: foo.py" in result

    def test_includes_output_format(self) -> None:
        ticket = TicketSpec(ticket_id="T001", goal="Test")
        result = build_ticket_prompt(ticket, "", "")
        assert "FILE:" in result
        assert "END FILE" in result


class TestAssembleMessages:
    def test_basic_messages(self) -> None:
        msgs = assemble_messages("system text", "user text")
        assert len(msgs) == 2
        assert msgs[0]["role"] == "system"
        assert msgs[1]["role"] == "user"

    def test_repair_context_adds_messages(self) -> None:
        msgs = assemble_messages("sys", "usr", repair_context="Fix lint errors")
        assert len(msgs) == 4
        assert "Fix lint errors" in msgs[3]["content"]
        assert "GOVERNANCE FINDINGS" in msgs[3]["content"]


class TestSaturndayContextIntegration:
    """Tests that verify Saturnday-specific content in the assembled prompt."""

    def _make_standards_dir(self, tmp_path: Path) -> Path:
        """Create a minimal standards dir with the real coder_system_senior_v1.txt."""
        import shutil

        real_prompt = (
            Path(__file__).parent.parent
            / "senior_engineering_standards"
            / "prompts"
            / "coder_system_senior_v1.txt"
        )
        prompts_dir = tmp_path / "prompts"
        prompts_dir.mkdir()
        if real_prompt.exists():
            shutil.copy(real_prompt, prompts_dir / "coder_system_senior_v1.txt")
        else:
            (prompts_dir / "coder_system_senior_v1.txt").write_text(
                "SATURNDAY EXECUTION CONTEXT\ngovernance_judge\nOpenClaw"
            )
        return tmp_path

    def test_coder_prompt_includes_saturnday_context(self, tmp_path: Path) -> None:
        """System prompt includes Saturnday execution context."""
        standards_dir = self._make_standards_dir(tmp_path)
        load_standards_context.cache_clear()
        build_system_prompt.cache_clear()
        prompt = build_system_prompt(str(standards_dir))
        assert "SATURNDAY EXECUTION CONTEXT" in prompt
        assert "governance_judge" in prompt
        assert "OpenClaw" in prompt

    def test_corpus_excludes_reviewer_and_data(self, tmp_path: Path) -> None:
        """Standards corpus does not include reviewer prompt or data files."""
        # Populate a standards dir mirroring the real layout
        (tmp_path / "prompts").mkdir()
        (tmp_path / "prompts" / "coder_system_senior_v1.txt").write_text("coder prompt")
        (tmp_path / "prompts" / "reviewer_system_senior_v1.txt").write_text(
            "reviewer_system_senior_v1 content"
        )
        corpus_dir = tmp_path / "corpus"
        corpus_dir.mkdir()
        (corpus_dir / "exclusion_rules.yaml").write_text("exclusion_rules: []")
        (corpus_dir / "permissive_repos.yaml").write_text("permissive_repos: []")
        evals_dir = tmp_path / "evals"
        evals_dir.mkdir()
        (evals_dir / "senior_style_rubric.yaml").write_text("senior_style_rubric: {}")
        load_standards_context.cache_clear()
        corpus = load_standards_context(str(tmp_path))
        assert "reviewer_system_senior_v1" not in corpus
        assert "exclusion_rules" not in corpus
        assert "permissive_repos" not in corpus
        assert "senior_style_rubric" not in corpus


class TestSeniorJudgmentIntegration:
    def test_critical_rules_included_when_file_exists(self, tmp_path: Path) -> None:
        style_dir = tmp_path / "docs" / "style"
        style_dir.mkdir(parents=True)
        (style_dir / "senior_judgment_rules.md").write_text("Never swallow exceptions.")
        prompts_dir = tmp_path / "prompts"
        prompts_dir.mkdir()
        (prompts_dir / "coder_system_senior_v1.txt").write_text("You are an engineer.")
        load_standards_context.cache_clear()
        build_system_prompt.cache_clear()
        result = build_system_prompt(str(tmp_path))
        assert "CRITICAL SENIOR JUDGMENT RULES" in result
        assert "Never swallow exceptions." in result

    def test_common_mistakes_always_present(self, tmp_path: Path) -> None:
        (tmp_path / "coder_standards_v1.txt").write_text("Standard A")
        load_standards_context.cache_clear()
        build_system_prompt.cache_clear()
        result = build_system_prompt(str(tmp_path))
        assert "COMMON MISTAKES TO AVOID" in result
        # Verify all 8 lines are present
        assert "Centralize domain constants" in result
        assert "never commit agent artifacts" in result
