"""Tests for saturnday.shared.backend_auth."""

import os

from saturnday._types import CoderConfig
from saturnday.shared.backend_auth import (
    capability_matrix,
    detect_auth_mode,
    validate_auth,
)


class TestDetectAuthMode:
    def test_cli_local(self) -> None:
        config = CoderConfig(backend="claude-cli")
        mode = detect_auth_mode(config)
        assert mode == "local_interactive"

    def test_api_with_key(self) -> None:
        config = CoderConfig(backend="openai", api_key="sk-test")
        mode = detect_auth_mode(config)
        assert mode == "api_key"

    def test_api_without_key(self) -> None:
        config = CoderConfig(backend="anthropic")
        mode = detect_auth_mode(config)
        assert mode == "unsupported"


class TestValidateAuth:
    def test_valid_cli(self) -> None:
        config = CoderConfig(backend="codex-cli")
        result = validate_auth(config)
        assert result.valid is True
        assert result.mode == "local_interactive"

    def test_invalid_api_no_key(self) -> None:
        config = CoderConfig(backend="openai")
        result = validate_auth(config)
        assert result.valid is False
        assert "API key" in result.reason

    def test_valid_api_with_key(self) -> None:
        config = CoderConfig(backend="anthropic", api_key="sk-ant-test")
        result = validate_auth(config)
        assert result.valid is True


class TestCapabilityMatrix:
    def test_codex_cli_caps(self) -> None:
        caps = capability_matrix("codex-cli")
        assert caps["local_interactive"] is True
        assert caps["api_key"] is False
        assert caps["file_writes"] is True

    def test_openai_caps(self) -> None:
        caps = capability_matrix("openai")
        assert caps["api_key"] is True
        assert caps["file_writes"] is False
        assert caps["multi_turn"] is True

    def test_unknown_backend(self) -> None:
        caps = capability_matrix("unknown")
        assert caps == {}
