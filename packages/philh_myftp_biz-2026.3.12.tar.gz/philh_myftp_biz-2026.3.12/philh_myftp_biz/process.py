from typing import Literal, TYPE_CHECKING, Any, Callable, Iterator

if TYPE_CHECKING:
    from psutil import Process as __Process
    from .pc import Path

#========================================================

class Thread:
    """
    Quickly Start a Thread
    """

    def __init__(self,
        func: Callable,
        *args: str,
        **kwargs: str
    ) -> None:
        from threading import Thread

        # Create new thread
        self._t = Thread(
            target = func,
            kwargs = kwargs,
            args = args
        )

        # Close when main execution ends
        self._t.daemon = True

        # start the thread
        self._t.start()

        self.wait = self._t.join

        self.running = self._t.is_alive

class Sleeper:
    """
    Call a function before exiting after main thread has ended
    """

    def __init__(self,
        func: Callable,
        *args: str,
        **kwargs: str
    ) -> None:
        from threading import Thread

        self.func = func
        self.args = args
        self.kwargs = kwargs

        # Create new thread
        self._thread = Thread(target=self._main)
        
        self._thread.start()

    def _main(self) -> None:
        from time import sleep

        while Alive():
            sleep(.1)

        self.func(*self.args, **self.kwargs)

def Alive() -> bool:
    """
    Check if the main thread is running
    """
    from threading import main_thread

    return main_thread().is_alive()

#========================================================

class SubProcess:
    """
    Subprocess Wrapper
    """

    _hide: bool
    _wait: bool

    def __init__(self,
        args: 'list|tuple|str|Path',
        terminal: None|Literal['cmd', 'ps', 'psfile', 'py', 'pym', 'vbs'] = 'cmd',
        dir: 'Path|None' = None
    ) -> None:
        from subprocess import Popen, PIPE
        from .array import stringify
        from sys import executable
        from .terminal import Log
        from .pc import Path, cwd

        # =====================================

        if dir is None:
            dir = cwd()
                    
        # =====================================

        if isinstance(args, (tuple, list)):
            args = stringify(args)
        else:
            args = [str(args)]

        if terminal is None:

            match Path(args[0]).ext:

                case 'ps1': terminal='psfile'

                case 'py': terminal='py'

                case 'exe': terminal='cmd'

                case 'bat': terminal='cmd'

                case 'vbs': terminal='vbs'

                case _: terminal='cmd'

        match terminal:

            case 'cmd':
                args = ['cmd', '/c', *args]

            case 'ps':
                args = ['Powershell', '-Command', *args]

            case 'psfile':
                args = ['Powershell', '-File', *args]

            case 'py':
                args = [executable, *args]

            case 'pym':
                args = [executable, '-m', *args]
        
            case 'vbs':
                args = ['wscript', *args]

        # =====================================

        Log.VERB(f'Running Subprocess:\n{args=}\n{dir=}\nhide={self._hide}\nwait={self._wait}')

        self._process = Popen(
            args = args,
            cwd = str(dir),
            stdout = PIPE,
            stderr = PIPE,
            text = True,
            errors = 'ignore'
        )

        self._task = SysTask(self._process.pid)

        self.wait = self._process.wait

        self.stop = self._task.stop

        # =====================================

        self.stdout  = ''
        self.stderr  = ''
        self.stdcomb = ''

        # Start Status Monitor
        Thread(self.__monitor)

        # =====================================

        # Wait for process to complete if required
        if self._wait:
            self.wait()

    def __monitor(self) -> None:
        from .terminal import _cls_cmd, cls, write

        stdout = iter(self._process.stdout.read, -1)
        stderr = iter(self._process.stderr.read, -1)

        while self.running and Alive():

            outline = next(stdout, '')

            if _cls_cmd in outline:

                # Reset stream buffers
                self.stdout = ''
                self.stderr = ''
                self.stdcomb = ''

                #
                if not self._hide:
                    cls()

            elif len(outline) > 0:

                #
                self.stdout += outline
                self.stdcomb += outline

                #
                if not self._hide:
                    write(outline, 'out')

            errline = next(stderr, '')

            if len(errline) > 0:

                self.stderr += errline
                self.stdcomb += errline

                if not self._hide:
                    write(errline, 'err')

        #
        self.stop()

    @property
    def finished(self) -> bool:
        """
        Check if the subprocess is finished
        """
        return (not self.running)

    def output(self,
        format: Literal['json', 'hex'] = None,
        stream: Literal['out', 'err', 'comb'] = 'out'
    ) -> 'str | dict | list | bool | Any':
        """
        Read the output from the Subprocess
        """
        from .text import hex
        from . import json

        _stream: str = getattr(self, 'std'+stream)

        output = _stream.encode().strip()

        if format == 'json':
            return json.loads(output)
        
        elif format == 'hex':
            return hex.decode(output)
        
        else:
            return output.decode()

    @property
    def running(self) -> bool:
        return self._task.exists

class Run(SubProcess):
    _hide = False
    _wait = True

class RunHidden(SubProcess):
    _hide = True
    _wait = True

class Start(SubProcess):
    _hide = False
    _wait = False

class StartHidden(SubProcess):
    _hide = True
    _wait = False

#========================================================

class SysTask:
    """
    System Task

    Wrapper for psutil.Process
    """

    pid = None
    """Process ID"""

    name = None
    """Process Name"""
    
    pat = None
    """Process Name [Wildcard]"""

    def __init__(self,
        id: str | int
    ) -> None:
        
        self.id = id

        if isinstance(id, int):
            self.pid = id

        elif '*' in id:
            self.pat = id.lower()
        
        else:                
            self.name = id.lower()

    @property
    def _main(self) -> '__Process|None':
        from psutil import process_iter, Process, NoSuchProcess
        from .text import like

        if self.pid:

            try:
                return Process(self.pid)
            
            except NoSuchProcess:
                pass

        else:

            for proc in process_iter():

                pname = proc.name().lower()

                if self.name and (self.name == pname):

                    return proc
                
                elif self.pat and like(pname, self.pat):

                    return proc

    def __iter__(self) -> 'Iterator[__Process]':
        from psutil import NoSuchProcess
        
        main = self._main

        # IF main process found
        if main:

            processes = [main]

            try:
                processes += main.children(recursive=True)

            except NoSuchProcess:
                pass

            return iter(filter(
                lambda p: p.is_running(),    
                reversed(processes)
            )) # pyright: ignore[reportReturnType]
        
        else:

            return iter([])

    def stop(self) -> None:
        """Stop Process and all of it's children"""
        from .terminal import Log

        Log.VERB(f'Stopping Process: {self.id}')

        for p in self:
            
            p.terminate()

    @property
    def exists(self) -> bool:
        """Check if the process is running"""

        return len(list(self)) > 0
    
    @property
    def PIDs(self):
        
        for process in self:

            yield process.pid

#========================================================