from __future__ import annotations

from dataclasses import dataclass

import pytest
from motosan_ai.types import Message as AiMessage

from motosan_chat.agent import Message, StreamChunk
from motosan_chat.ai import MotosanAiClient, _to_ai_message, _to_ai_tool
from motosan_chat.tool import ToolDef


@dataclass
class MockToolCall:
    id: str
    name: str
    input: dict


@dataclass
class MockChatResp:
    content: str
    tool_calls: list[MockToolCall]


@dataclass
class MockStreamEvent:
    content: str
    done: bool = False
    event_type: str = "text"
    tool_call_id: str | None = None
    tool_call_name: str | None = None
    tool_call_args_delta: str | None = None


class MockAiClient:
    def __init__(self) -> None:
        self.chat_response = MockChatResp(content="hello", tool_calls=[])
        self.stream_events: list[MockStreamEvent] = [
            MockStreamEvent(content="A"),
            MockStreamEvent(content="B"),
        ]

    async def chat(self, messages, tools=None, system=None):  # type: ignore[no-untyped-def]
        _ = (messages, tools, system)
        return self.chat_response

    async def stream(self, messages, tools=None, system=None):  # type: ignore[no-untyped-def]
        _ = (messages, tools, system)
        for event in self.stream_events:
            yield event


@pytest.mark.asyncio
async def test_chat_maps_message_response() -> None:
    client = MotosanAiClient(MockAiClient())
    response = await client.chat([Message.user("hi")], [])
    assert response.kind == "message"
    assert response.content == "hello"


@pytest.mark.asyncio
async def test_chat_maps_tool_call_response() -> None:
    ai = MockAiClient()
    ai.chat_response = MockChatResp(
        content="",
        tool_calls=[MockToolCall(id="tc-1", name="echo", input={"x": 1})],
    )
    client = MotosanAiClient(ai)
    response = await client.chat([Message.user("hi")], [])
    assert response.kind == "tool_call"
    assert response.tool_call_id == "tc-1"
    assert response.tool_name == "echo"
    assert response.tool_args == {"x": 1}


@pytest.mark.asyncio
async def test_stream_passthrough() -> None:
    client = MotosanAiClient(MockAiClient())
    chunks = [chunk async for chunk in client.stream([Message.user("hi")])]
    assert chunks == ["A", "B"]


def test_to_ai_conversions() -> None:
    tool = _to_ai_tool(ToolDef(name="lookup", description="desc", schema={"type": "object"}))
    assert tool.name == "lookup"

    assistant_with_tool = Message.assistant_with_tool_call("tc-1", "echo")
    converted = _to_ai_message(assistant_with_tool)
    assert converted.tool_calls[0].id == "tc-1"

    tool_msg = Message.tool_result("tc-1", "ok")
    converted_tool = _to_ai_message(tool_msg)
    assert converted_tool.role == "tool"


def test_to_ai_message_keeps_tool_calls_for_multi_turn_chain() -> None:
    assistant_tool_call = Message.assistant_with_tool_call("call-1", "echo")
    converted_assistant = _to_ai_message(assistant_tool_call)
    assert isinstance(converted_assistant, AiMessage)
    assert converted_assistant.tool_calls[0].id == "call-1"
    assert converted_assistant.tool_calls[0].name == "echo"

    tool_result = Message.tool_result("call-1", "result")
    converted_tool_result = _to_ai_message(tool_result)
    assert isinstance(converted_tool_result, AiMessage)
    assert converted_tool_result.role == "tool"
    assert converted_tool_result.tool_call_id == "call-1"


# ---------------------------------------------------------------------------
# stream_with_tools tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_stream_with_tools_text_chunks() -> None:
    """Text StreamEvents map to StreamChunk(kind='text')."""
    client = MotosanAiClient(MockAiClient())
    chunks = [chunk async for chunk in client.stream_with_tools([Message.user("hi")], [])]
    assert len(chunks) == 2
    assert all(c.kind == "text" for c in chunks)
    assert chunks[0].content == "A"
    assert chunks[1].content == "B"


@pytest.mark.asyncio
async def test_stream_with_tools_skips_empty_text() -> None:
    """Empty text content is skipped."""
    ai = MockAiClient()
    ai.stream_events = [
        MockStreamEvent(content="hello"),
        MockStreamEvent(content=""),
        MockStreamEvent(content="world"),
    ]
    client = MotosanAiClient(ai)
    chunks = [chunk async for chunk in client.stream_with_tools([Message.user("hi")], [])]
    assert len(chunks) == 2
    assert chunks[0].content == "hello"
    assert chunks[1].content == "world"


@pytest.mark.asyncio
async def test_stream_with_tools_tool_call_events() -> None:
    """Tool call StreamEvents map to corresponding StreamChunk kinds."""
    ai = MockAiClient()
    ai.stream_events = [
        MockStreamEvent(content="thinking", event_type="text"),
        MockStreamEvent(
            content="",
            event_type="tool_call_start",
            tool_call_id="tc-1",
            tool_call_name="echo",
        ),
        MockStreamEvent(
            content="",
            event_type="tool_call_args",
            tool_call_id="tc-1",
            tool_call_args_delta='{"value":',
        ),
        MockStreamEvent(
            content="",
            event_type="tool_call_args",
            tool_call_id="tc-1",
            tool_call_args_delta=' "hi"}',
        ),
        MockStreamEvent(
            content="",
            event_type="tool_call_end",
            tool_call_id="tc-1",
        ),
    ]
    client = MotosanAiClient(ai)
    chunks = [chunk async for chunk in client.stream_with_tools([Message.user("hi")], [])]

    assert len(chunks) == 5  # text + start + args + args + end
    assert chunks[0] == StreamChunk(kind="text", content="thinking")
    assert chunks[1] == StreamChunk(kind="tool_call_start", tool_id="tc-1", tool_name="echo")
    assert chunks[2] == StreamChunk(kind="tool_call_args", content='{"value":', tool_id="tc-1")
    assert chunks[3] == StreamChunk(kind="tool_call_args", content=' "hi"}', tool_id="tc-1")
    assert chunks[4] == StreamChunk(kind="tool_call_end", tool_id="tc-1")


@pytest.mark.asyncio
async def test_stream_with_tools_full_tool_call_sequence() -> None:
    """Full sequence: text + tool_call_start + args + end."""
    ai = MockAiClient()
    ai.stream_events = [
        MockStreamEvent(content="Let me check.", event_type="text"),
        MockStreamEvent(
            content="",
            event_type="tool_call_start",
            tool_call_id="tc-1",
            tool_call_name="search",
        ),
        MockStreamEvent(
            content="",
            event_type="tool_call_args",
            tool_call_id="tc-1",
            tool_call_args_delta='{"q": "test"}',
        ),
        MockStreamEvent(
            content="",
            event_type="tool_call_end",
            tool_call_id="tc-1",
        ),
    ]
    client = MotosanAiClient(ai)
    chunks = [chunk async for chunk in client.stream_with_tools([Message.user("hi")], [])]

    assert len(chunks) == 4
    assert chunks[0].kind == "text"
    assert chunks[0].content == "Let me check."
    assert chunks[1].kind == "tool_call_start"
    assert chunks[1].tool_id == "tc-1"
    assert chunks[1].tool_name == "search"
    assert chunks[2].kind == "tool_call_args"
    assert chunks[2].content == '{"q": "test"}'
    assert chunks[2].tool_id == "tc-1"
    assert chunks[3].kind == "tool_call_end"
    assert chunks[3].tool_id == "tc-1"
