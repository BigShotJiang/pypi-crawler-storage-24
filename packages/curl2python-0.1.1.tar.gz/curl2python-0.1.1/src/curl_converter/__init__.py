from .extract_configs import get_configs

__all__ = ["get_configs"]