from playwright.sync_api import sync_playwright

def curl_to_python(curl_text):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)  # must be False
        context = browser.new_context(permissions=["clipboard-read", "clipboard-write"])
        page = context.new_page()

        page.goto("https://curlconverter.com/")

        page.fill("#curl-code", curl_text)

        page.click("#copy-to-clipboard a")

        copied = page.evaluate("navigator.clipboard.readText()")
        return copied
