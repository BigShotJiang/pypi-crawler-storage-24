import ast
from using_playwright import curl_to_python
def extract_request_details(code):
    tree = ast.parse(code)

    result = {
        "method": None,
        "url": None,
        "headers": None,
        "cookies": None,
        "params": None,
        "data": None,
        "json": None,
        "files": None
    }

    variables = {}

    class Visitor(ast.NodeVisitor):
        def visit_Assign(self, node):
            if isinstance(node.targets[0], ast.Name):
                name = node.targets[0].id
                try:
                    variables[name] = ast.literal_eval(node.value)
                except:
                    pass
            self.generic_visit(node)

        def visit_Call(self, node):
            if isinstance(node.func, ast.Attribute):

                if node.func.attr in [
                    "get", "post", "put", "delete", "patch", "request"
                ]:
                    result["method"] = node.func.attr.upper()

                    if node.args:
                        result["url"] = ast.literal_eval(node.args[0])

                    for kw in node.keywords:
                        key = kw.arg

                        try:
                            value = ast.literal_eval(kw.value)
                        except:
                            if isinstance(kw.value, ast.Name):
                                value = variables.get(kw.value.id)
                            else:
                                value = None

                        if key in result:
                            result[key] = value

            self.generic_visit(node)

    Visitor().visit(tree)
    return result

def get_configs(curl_text):
    # Example usage
    code = curl_to_python(curl_text)

    details = extract_request_details(code)

    return details