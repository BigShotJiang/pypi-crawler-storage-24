import argparse
from .extract_configs import get_configs

def main():
    parser = argparse.ArgumentParser(description="Convert curl to Python requests")
    parser.add_argument("curl", help="curl command")

    args = parser.parse_args()

    result = get_configs(args.curl)

    print(result)

if __name__ == "__main__":
    main()