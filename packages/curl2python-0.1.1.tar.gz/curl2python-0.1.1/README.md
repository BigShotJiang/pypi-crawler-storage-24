# curl-converter

Convert curl commands into Python requests code.

## Installation

```bash
pip install curl2python