from imdb import IMDB
import json

name = "Skyscraper"
proxy = "https://scraper.apio.space/get-html-content?url="
def proxy_fn(res):
#    print(f'response is: {res}')
   return res.get('content')



i = IMDB(proxy=proxy,proxy_res_parser=proxy_fn, timeout=20, debug=True)
# i = IMDB()

m1 = i.get_by_name(name,year=2018)
print(m1)
