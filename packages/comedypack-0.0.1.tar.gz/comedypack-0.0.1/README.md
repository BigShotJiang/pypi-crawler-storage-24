# comedypack 🤣

> *The all time meant to be **Funny** library.*
> *Small. Fast. Offline. Zero dependencies. Maximum chaos.*

---

## ⚠️ Funny Warnings

- Do NOT run `DiscoDanceFloor(100, 100, fps=60)` unless you hate your computer. 💀
- Do NOT ask `Jokes(1000)`. It will fight back. 🤣
- Do NOT use `AsciiArt("cat")` in a serious meeting. We warned you. 🐱
- `RandomColours(20, 20)` may make you question why you ever used numpy. 🎨
- Side effects may include: uncontrollable laughter, terminal addiction, and forgetting serious libraries exist.

---

## 📦 Installation

```bash
pip install funny
```

That's it. No dependencies. No drama. Just funny. 😂

---

## 🚀 Usage

```python
from funny import *
```

One line. You're in. Welcome to the chaos. 🎉

---

## 🎤 Jokes(num, mode)

Prints `num` jokes. Don't ask for 1000. It will not end well.

```python
Jokes()       # 3 jokes by default
Jokes(5)      # 5 jokes
Jokes(3, mode='return')  # returns instead of printing
```

---

## 🖼️ AsciiArt(category, num, mode)

Funny ASCII art for your terminal gallery. Pass a keyword or go random.

```python
AsciiArt()              # random category, 1 art
AsciiArt("cat")         # a judgy cat 🐱
AsciiArt("dragon", 3)   # 3 dragon variations
AsciiArt("robot", mode='return')  # returns the art
```

Supported categories: `cat`, `dog`, `robot`, `snake`, `skull`, `dragon`, `pizza`, `burger`, `rocket`, `penguin`, `ghost`, `alien`... and 30+ more! 😄

---

## 🔑 Passwords(num, mode)

Password ideas so good, even YOU won't know you're saying your password.

```python
Passwords()     # 3 passwords by default
Passwords(5)    # 5 passwords

# Real conversation this will cause:
# Person 1: "What's the WiFi password?"
# Person 2: "AreYouSerious?"
# Person 1: "YES I'M SERIOUS!"
# Person 2: 💀
```

---

## 🎲 RandomStuff(w, h, mode)

A grid of pure chaos. Letters, emojis, symbols — all mixed together.

```python
RandomStuff(10, 10)   # 10x10 grid of chaos
RandomStuff(5, 5)     # smaller chaos
```

Example output:
```
§ % 🔱 P °
Q ↔ ♦ 🎯 N
🌤️ ↕ w @ I
j ⚫ × A ⚪
🐬 ( [ C 🔆
```

---

## 🌈 RandomColour(w, h, mode)

16 MILLION colours. Even Leonardo Da Vinci would have needed minimum 10 days to finish this artwork. You? 0.3 seconds. 😂

```python
RandomColour()          # 5x5 colour plate
RandomColour(20, 20)    # full painting 🖼️
RandomColour(10, 10, mode='return')  # returns the string
```

---

## 🪩 DiscoDanceFloor(w, h, frames, fps)

Live colour animation in your terminal. Your terminal will never be the same. 🕺

```python
DiscoDanceFloor()                    # 5x5, infinite, 10fps
DiscoDanceFloor(20, 20)              # bigger floor
DiscoDanceFloor(10, 10, frames=30)   # 30 frames then stops
DiscoDanceFloor(10, 10, fps=30)      # faster disco 🔥
```

> ⚠️ fps > 60 = connection glitch vibes. fps = 0 = you want a still image??? 😂

---

## ❓ Help()

You already know what this does. Just run it. 🤣

```python
Help()  # the program of help is literally running!!!
```

---

## 👨‍💻 Credits & Author

Built with absolutely no chill by **Swastik Bachhar**. 😄

> *"Small, fast, offline, zero dependencies, feature-packed, and actually funny — unlike your code."*

---

*funny v0.0.1 — because Python deserves to laugh too.* 🐍🤣