print('''
\033[1mFunny Help\033[0m - Don't worry cause everything is valid here. 🤣🤣\033[0m
\033[1m———————————————————————————————————————————————————————————————————\033[0m

🖼️  AsciiArt(category, num, mode) - Let us get you some Ascii Arts for your project or terminal gallery.
🎤  Jokes(num) - Mic Testing! Mic Testing! Wanna hear some jokes??? They are quite funny. 😂😂😂🤣
🔑  Password(num, mode) - Wanna get some Password Ideas? They are gonna make you roll on floor.
🌈  RandomColour - This Module has got two functions, what to say???? Let me say both.
      🎨 RandomColour(w, h, mode) - This generates you a plate full of colours, Even Leonardo Da Vinci would have needed minimum 10 days to finish the artwork.
      🪩  DiscoDanceFloor(w, h, frames, fps) - Wanna make an colour animation out of RandomColour? You have got this helping you in just 1 line.
🎲  RandomStuff - Where random things in a grid of chaos.
❓  Help - This may be the last but not the least. The program of help is litterally running!!!🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣

\033[1m———————————————————————————————————————————————————————————————————\033[0m
The all time meant to be \033[1mFunny\033[0m library. 😂😂😂😂
''')