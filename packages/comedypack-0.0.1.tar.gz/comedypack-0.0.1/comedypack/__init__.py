from comedypack import Jokes, AsciiArt, Password, RandomColour, RandomStuff, Help

__author__ = "Swastik Bachhar"
__version__ = "0.0.1"
__readme__ = "README.md"

__all__ = ['Jokes', 'AsciiArt', 'Password', 'RandomStuff', 'RandomColour', 'Help']