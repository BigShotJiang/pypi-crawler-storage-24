"""Tests for context loader module."""

import json

from getinvoke.context import (
    ProjectMetadata,
    _find_project_root,
    _read_truncated,
    extract_project_metadata,
    format_context_for_llm,
    generate_project_vocabulary,
    load_project_context,
)


def test_load_context_with_claude_md(tmp_path):
    """Should find and include CLAUDE.md content."""
    (tmp_path / "CLAUDE.md").write_text("# My Project\n\nSome context here.")
    result = load_project_context(str(tmp_path))
    assert "[CLAUDE.md]" in result
    assert "My Project" in result


def test_load_context_with_package_json(tmp_path):
    """Should find and include package.json content."""
    (tmp_path / "package.json").write_text('{"name": "test-app", "version": "1.0.0"}')
    result = load_project_context(str(tmp_path))
    assert "[package.json]" in result
    assert "test-app" in result


def test_load_context_multiple_files(tmp_path):
    """Should include all found context files."""
    (tmp_path / "CLAUDE.md").write_text("# Instructions")
    (tmp_path / "package.json").write_text('{"name": "multi"}')
    result = load_project_context(str(tmp_path))
    assert "[CLAUDE.md]" in result
    assert "[package.json]" in result


def test_load_context_no_files(tmp_path, monkeypatch):
    """Should return empty string when no context files found above CWD."""
    # Create an isolated dir tree with no context files anywhere up
    isolated = tmp_path / "a" / "b" / "c"
    isolated.mkdir(parents=True)
    # Patch home so _find_project_root stops early
    monkeypatch.setattr("getinvoke.context.Path.home", lambda: tmp_path / "a")
    result = load_project_context(str(isolated))
    assert result == ""


def test_load_context_nonexistent_path():
    """Should return empty string for nonexistent path."""
    result = load_project_context("/this/path/does/not/exist")
    assert result == ""


def test_load_context_truncation(tmp_path):
    """Should truncate context exceeding MAX_CONTEXT_LENGTH."""
    (tmp_path / "CLAUDE.md").write_text("x" * 3000)
    result = load_project_context(str(tmp_path))
    assert "...(truncated)" in result
    assert len(result) < 3000


def test_find_project_root_walks_up(tmp_path):
    """Should walk up to find project root."""
    (tmp_path / "package.json").write_text("{}")
    subdir = tmp_path / "src" / "components"
    subdir.mkdir(parents=True)
    root = _find_project_root(subdir)
    assert root == tmp_path


def test_find_project_root_none(tmp_path):
    """Should return None when no context files found."""
    subdir = tmp_path / "empty" / "nested"
    subdir.mkdir(parents=True)
    # This will walk up to tmp_path and beyond, but won't find anything
    # until it hits home or root. The result depends on the actual filesystem.
    # Just verify it doesn't crash.
    _find_project_root(subdir)


def test_read_truncated(tmp_path):
    """Should read and truncate long files."""
    f = tmp_path / "test.txt"
    f.write_text("a" * 500)
    assert len(_read_truncated(f, max_chars=100)) < 200
    assert "...(truncated)" in _read_truncated(f, max_chars=100)


def test_read_truncated_short_file(tmp_path):
    """Should return full content for short files."""
    f = tmp_path / "short.txt"
    f.write_text("hello world")
    assert _read_truncated(f) == "hello world"


# --- ProjectMetadata tests ---


def test_extract_metadata_package_json(tmp_path):
    """Should parse name and dependencies from package.json."""
    pkg = {"name": "my-app", "dependencies": {"react": "^18", "next": "^14"}, "devDependencies": {"typescript": "^5"}}
    (tmp_path / "package.json").write_text(json.dumps(pkg))
    meta = extract_project_metadata(str(tmp_path), use_cache=False)
    assert meta is not None
    assert meta.name == "my-app"
    assert "react" in meta.dependencies
    assert "next" in meta.dependencies
    assert "typescript" in meta.dependencies


def test_extract_metadata_pyproject(tmp_path):
    """Should parse name and dependencies from pyproject.toml."""
    toml = '[project]\nname = "my-tool"\ndependencies = ["fastapi>=0.100", "pydantic"]\n'
    (tmp_path / "pyproject.toml").write_text(toml)
    meta = extract_project_metadata(str(tmp_path), use_cache=False)
    assert meta is not None
    assert meta.name == "my-tool"
    assert "fastapi" in meta.dependencies
    assert "pydantic" in meta.dependencies


def test_stack_detection(tmp_path):
    """Should detect tech stack from config files."""
    (tmp_path / "tsconfig.json").write_text("{}")
    (tmp_path / "package.json").write_text('{"name": "ts-app", "dependencies": {"react": "^18"}}')
    meta = extract_project_metadata(str(tmp_path), use_cache=False)
    assert meta is not None
    assert "TypeScript" in meta.stack
    assert "Node" in meta.stack
    assert "React" in meta.stack


def test_convention_inference(tmp_path):
    """Should infer naming conventions from stack."""
    (tmp_path / "tsconfig.json").write_text("{}")
    (tmp_path / "package.json").write_text('{"name": "ts-app"}')
    meta = extract_project_metadata(str(tmp_path), use_cache=False)
    assert meta is not None
    assert "camelCase" in meta.conventions

    # Python project
    (tmp_path / "pyproject.toml").write_text('[project]\nname = "py-app"\n')
    (tmp_path / "tsconfig.json").unlink()
    (tmp_path / "package.json").unlink()
    meta = extract_project_metadata(str(tmp_path), use_cache=False)
    assert meta is not None
    assert "snake_case" in meta.conventions


def test_file_manifest_flat(tmp_path):
    """Should produce a flat list of relative file paths."""
    (tmp_path / "package.json").write_text('{"name": "test"}')
    src = tmp_path / "src"
    src.mkdir()
    (src / "index.ts").write_text("")
    (src / "utils.ts").write_text("")
    meta = extract_project_metadata(str(tmp_path), use_cache=False)
    assert meta is not None
    assert any("src/index.ts" in f for f in meta.file_manifest)
    assert any("src/utils.ts" in f for f in meta.file_manifest)


def test_file_manifest_capped(tmp_path):
    """Should cap file manifest at _MAX_FILE_MANIFEST."""
    (tmp_path / "package.json").write_text('{"name": "big-project"}')
    for i in range(150):
        (tmp_path / f"file_{i}.ts").write_text("")
    meta = extract_project_metadata(str(tmp_path), use_cache=False)
    assert meta is not None
    assert len(meta.file_manifest) <= 100


def test_extract_metadata_no_project(tmp_path, monkeypatch):
    """Should return None when no project root found."""
    isolated = tmp_path / "a" / "b"
    isolated.mkdir(parents=True)
    monkeypatch.setattr("getinvoke.context.Path.home", lambda: tmp_path / "a")
    meta = extract_project_metadata(str(isolated))
    assert meta is None


def test_extract_metadata_active_file(tmp_path):
    """Should include the active file in metadata."""
    (tmp_path / "package.json").write_text('{"name": "test"}')
    meta = extract_project_metadata(str(tmp_path), active_file="src/app.tsx", use_cache=False)
    assert meta is not None
    assert meta.active_file == "src/app.tsx"


def test_extract_metadata_ai_instructions(tmp_path):
    """Should extract first meaningful line from CLAUDE.md."""
    (tmp_path / "CLAUDE.md").write_text("# My Project\n\nThis is a TypeScript monorepo for SEO tools.")
    meta = extract_project_metadata(str(tmp_path), use_cache=False)
    assert meta is not None
    assert "TypeScript monorepo" in meta.ai_instructions


# --- format_context_for_llm tests ---


def test_format_context_for_llm_full():
    """Should format all metadata fields into compact context block."""
    meta = ProjectMetadata(
        name="keygrip",
        stack=["TypeScript", "React", "Node"],
        conventions="camelCase/PascalCase",
        dependencies=["react", "next", "prisma"],
        file_manifest=["src/api/routes.ts", "src/components/App.tsx"],
        active_file="src/api/routes.ts",
    )
    result = format_context_for_llm(meta)
    assert "Project: keygrip" in result
    assert "Stack: TypeScript, React, Node" in result
    assert "Conventions: camelCase/PascalCase" in result
    assert "Active file: src/api/routes.ts" in result
    assert "Files: src/api/routes.ts" in result
    assert "Deps: react, next, prisma" in result


def test_format_context_for_llm_minimal():
    """Should handle minimal metadata gracefully."""
    meta = ProjectMetadata(name="test")
    result = format_context_for_llm(meta)
    assert "Project: test" in result
    assert "Files:" not in result  # empty manifest


# --- generate_project_vocabulary tests ---


def test_generate_vocab_from_deps():
    """Should include dependency names as vocabulary."""
    meta = ProjectMetadata(dependencies=["react", "prisma", "next", "ai"])
    vocab = generate_project_vocabulary(meta)
    assert "react" in vocab
    assert "prisma" in vocab
    assert "next" in vocab
    assert "ai" not in vocab  # too short (len <= 2)


def test_generate_vocab_stack_terms():
    """Should include stack-specific programming terms."""
    meta = ProjectMetadata(stack=["React", "TypeScript"])
    vocab = generate_project_vocabulary(meta)
    assert "useState" in vocab
    assert "useEffect" in vocab
    assert "interface" in vocab


def test_generate_vocab_from_file_stems():
    """Should include file stems from manifest."""
    meta = ProjectMetadata(file_manifest=["src/hooks/useAuth.ts", "src/components/Settings.tsx", "src/index.ts"])
    vocab = generate_project_vocabulary(meta)
    assert "useAuth" in vocab
    assert "Settings" in vocab
    assert "index" not in vocab  # generic name excluded


def test_vocab_capped_at_200():
    """Should never return more than 200 terms."""
    meta = ProjectMetadata(
        dependencies=[f"pkg-{i}" for i in range(250)],
        stack=["React", "TypeScript", "Next.js"],
    )
    vocab = generate_project_vocabulary(meta)
    assert len(vocab) <= 200


def test_vocab_merges_with_manual():
    """Manual and auto vocab should merge without duplicates."""
    meta = ProjectMetadata(dependencies=["react", "prisma"], stack=["React"])
    auto = generate_project_vocabulary(meta)
    manual = ["KeyGrip", "Invoke", "react"]  # "react" overlaps
    merged = list(set(manual + auto))[:50]
    assert "KeyGrip" in merged
    assert "react" in merged
    assert "useState" in merged
    # No duplicates
    assert len(merged) == len(set(merged))
