"""Tests for clipboard image capture module."""

import time
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def mock_settings(tmp_path):
    """Mock settings with tmp_path as save dir."""
    with patch("getinvoke.image_capture.settings") as mock:
        mock.IMAGE_SAVE_DIR = str(tmp_path)
        mock.IMAGE_RETENTION_DAYS = 30
        yield mock


def test_capture_saves_png_linux_wayland(tmp_path, mock_settings):
    """Mock wl-paste --list-types + wl-paste --type, verify path returned."""
    from getinvoke.image_capture import capture_clipboard_image

    # First call: wl-paste --list-types
    mock_types = MagicMock()
    mock_types.returncode = 0
    mock_types.stdout = "image/png\ntext/plain\n"

    # Second call: wl-paste --type image/png
    mock_data = MagicMock()
    mock_data.returncode = 0
    mock_data.stdout = b"\x89PNG\r\n\x1a\nfake"

    with (
        patch("platform.system", return_value="Linux"),
        patch.dict("os.environ", {"WAYLAND_DISPLAY": "wayland-0"}),
        patch("getinvoke.image_capture.subprocess.run", side_effect=[mock_types, mock_data]),
    ):
        result = capture_clipboard_image()

    assert result is not None
    assert "clip_" in result
    assert result.endswith(".png")


def test_capture_saves_png_windows(tmp_path, mock_settings):
    """Mock PowerShell returning 'saved', verify path returned."""
    from getinvoke.image_capture import capture_clipboard_image

    mock_result = MagicMock()
    mock_result.stdout = "saved\r\n"
    mock_result.stderr = ""

    def fake_run(cmd, **kwargs):
        if "wslpath" in cmd:
            result = MagicMock()
            result.stdout = "C:\\fake\\path.png"
            return result
        # Pre-create the file that PowerShell would have created
        from datetime import datetime

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        (tmp_path / f"clip_{timestamp}.png").write_bytes(b"fake png data")
        return mock_result

    with (
        patch("platform.system", return_value="Windows"),
        patch("getinvoke.image_capture.subprocess.run", side_effect=fake_run),
    ):
        result = capture_clipboard_image()

    assert result is not None
    assert "clip_" in result
    assert result.endswith(".png")


def test_capture_no_image_returns_none(mock_settings):
    """Mock wl-paste --list-types returning no image types, verify None."""
    from getinvoke.image_capture import capture_clipboard_image

    mock_types = MagicMock()
    mock_types.returncode = 0
    mock_types.stdout = "text/plain\n"  # no image type

    with (
        patch("platform.system", return_value="Linux"),
        patch.dict("os.environ", {"WAYLAND_DISPLAY": "wayland-0"}),
        patch("getinvoke.image_capture.subprocess.run", return_value=mock_types),
    ):
        result = capture_clipboard_image()

    assert result is None


def test_capture_creates_directory(tmp_path, mock_settings):
    """Verify save_dir created if missing."""
    from getinvoke.image_capture import capture_clipboard_image

    new_dir = tmp_path / "new_subdir"
    mock_settings.IMAGE_SAVE_DIR = str(new_dir)

    mock_types = MagicMock()
    mock_types.returncode = 0
    mock_types.stdout = "text/plain\n"  # no image

    with (
        patch("platform.system", return_value="Linux"),
        patch.dict("os.environ", {"WAYLAND_DISPLAY": "wayland-0"}),
        patch("getinvoke.image_capture.subprocess.run", return_value=mock_types),
    ):
        capture_clipboard_image()

    assert new_dir.exists()


def test_capture_wl_paste_not_found(mock_settings):
    """Verify graceful handling when wl-paste isn't available."""
    from getinvoke.image_capture import capture_clipboard_image

    with (
        patch("platform.system", return_value="Linux"),
        patch.dict("os.environ", {"WAYLAND_DISPLAY": "wayland-0"}),
        patch("getinvoke.image_capture.subprocess.run", side_effect=FileNotFoundError("wl-paste not found")),
    ):
        result = capture_clipboard_image()

    assert result is None


def test_cleanup_deletes_old_images(tmp_path):
    """Create files with old timestamps, verify cleanup removes them."""
    from getinvoke.image_capture import cleanup_old_images

    # Create old file (40 days ago)
    old_file = tmp_path / "clip_20200101_120000.png"
    old_file.write_bytes(b"old")
    old_time = time.time() - (40 * 86400)
    import os

    os.utime(old_file, (old_time, old_time))

    # Create recent file
    new_file = tmp_path / "clip_20991231_120000.png"
    new_file.write_bytes(b"new")

    deleted = cleanup_old_images(str(tmp_path), retention_days=30)

    assert deleted == 1
    assert not old_file.exists()
    assert new_file.exists()


def test_cleanup_keeps_recent_images(tmp_path):
    """Verify cleanup doesn't delete recent files."""
    from getinvoke.image_capture import cleanup_old_images

    recent = tmp_path / "clip_20991231_120000.png"
    recent.write_bytes(b"recent")

    deleted = cleanup_old_images(str(tmp_path), retention_days=30)

    assert deleted == 0
    assert recent.exists()


def test_cleanup_zero_retention_skips(tmp_path):
    """Retention of 0 means keep forever."""
    from getinvoke.image_capture import cleanup_old_images

    old_file = tmp_path / "clip_20200101_120000.png"
    old_file.write_bytes(b"old")
    old_time = time.time() - (400 * 86400)
    import os

    os.utime(old_file, (old_time, old_time))

    deleted = cleanup_old_images(str(tmp_path), retention_days=0)

    assert deleted == 0
    assert old_file.exists()
