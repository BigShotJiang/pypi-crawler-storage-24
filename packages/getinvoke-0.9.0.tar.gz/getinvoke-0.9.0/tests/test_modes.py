"""Tests for target modes."""

from getinvoke.modes import MODES, get_mode, get_system_prompt, list_modes
from getinvoke.modes.prompts import (
    CLAUDE_CODE_PROMPT,
    COMMIT_PROMPT,
    CURSOR_PROMPT,
    PR_PROMPT,
    RAW_PROMPT,
)


def test_all_modes_registered():
    """Should have exactly 8 modes."""
    assert len(MODES) == 8
    assert set(MODES.keys()) == {"claude-code", "cursor", "windsurf", "copilot", "codex", "raw", "commit", "pr"}


def test_get_mode_default():
    """Should return claude-code mode for unknown names."""
    mode = get_mode("nonexistent")
    assert mode.name == "claude-code"


def test_get_mode_by_name():
    """Should return the correct mode."""
    mode = get_mode("cursor")
    assert mode.name == "cursor"
    assert mode.label == "Cursor"
    assert "@file" in mode.description.lower() or "cursor" in mode.description.lower()


def test_list_modes():
    """Should return all modes as a list."""
    modes = list_modes()
    assert len(modes) == 8
    names = [m.name for m in modes]
    assert "claude-code" in names
    assert "raw" in names


def test_system_prompts_are_unique():
    """Each mode should have a distinct system prompt."""
    prompts = [get_system_prompt(name) for name in MODES]
    assert len(set(prompts)) == 8


def test_claude_code_prompt_has_examples():
    """Claude Code prompt should include worked examples."""
    assert "Input" in CLAUDE_CODE_PROMPT
    assert "Output" in CLAUDE_CODE_PROMPT


def test_cursor_prompt_has_file_refs():
    """Cursor prompt should mention @file references."""
    assert "@file" in CURSOR_PROMPT or "@src" in CURSOR_PROMPT


def test_commit_prompt_has_conventional():
    """Commit prompt should mention conventional commit format."""
    assert "feat" in COMMIT_PROMPT
    assert "fix" in COMMIT_PROMPT


def test_pr_prompt_has_summary():
    """PR prompt should mention summary section."""
    assert "## Summary" in PR_PROMPT


def test_raw_prompt_no_structure():
    """Raw prompt should emphasize no formatting."""
    assert "no structure" in RAW_PROMPT.lower() or "just clean" in RAW_PROMPT.lower()


def test_all_prompts_have_shared_rules():
    """All prompts should include the shared rules."""
    for name, mode in MODES.items():
        assert "faithful to intent" in mode.prompt, f"{name} missing shared rules"
        assert "filler" in mode.prompt, f"{name} missing filler removal rule"


def test_code_aware_rules_in_ide_modes():
    """IDE modes should include code-aware rules for identifier conversion and file resolution."""
    ide_modes = ["claude-code", "cursor", "windsurf", "copilot", "commit", "pr"]
    for name in ide_modes:
        prompt = get_system_prompt(name)
        assert "code identifiers" in prompt.lower(), f"{name} missing code-aware rules"
        assert "file" in prompt.lower(), f"{name} missing file resolution"
        assert "tech" in prompt.lower(), f"{name} missing tech vocab"
        assert "package" in prompt.lower() or "deps" in prompt.lower(), f"{name} missing dep awareness"


def test_raw_mode_no_code_aware_rules():
    """Raw mode should NOT include code-aware rules — it's a cleanup-only mode."""
    prompt = get_system_prompt("raw")
    assert "Convert spoken code identifiers" not in prompt
    assert "Resolve file references" not in prompt


def test_code_aware_examples_in_ide_modes():
    """IDE modes should have examples showing identifier conversion."""
    for name in ["claude-code", "cursor", "windsurf", "copilot"]:
        prompt = get_system_prompt(name)
        assert "useEffect" in prompt, f"{name} missing code-aware example"
