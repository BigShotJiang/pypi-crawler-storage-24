"""Tests for config module."""

import json
from unittest.mock import patch


def test_settings_defaults():
    """Settings should have sensible defaults."""
    with patch.dict("os.environ", {}, clear=True):
        with patch("getinvoke.config._load_config_file", return_value={}):
            from getinvoke.config import Settings

            s = Settings()
            assert s.WHISPER_MODEL == "distil-large-v3"
            assert s.REFORMATTER_BACKEND == "none"
            assert s.HOTKEY == "mouse5"
            assert s.LOG_LEVEL == "INFO"
            assert s.DICTATION_MODEL == "anthropic/claude-sonnet-4-6"
            assert s.MODE == "claude-code"
            assert s.OLLAMA_URL == "http://localhost:11434"
            assert s.OLLAMA_MODEL == "llama3.2"
            assert s.HISTORY_ENABLED is True
            assert s.HISTORY_RETENTION_DAYS == 30
            assert s.CUSTOM_VOCAB == ""
            assert s.hotwords == []


def test_settings_from_env():
    """Settings should read from environment variables."""
    env = {
        "WHISPER_MODEL": "tiny",
        "REFORMATTER_BACKEND": "ollama",
        "LOG_LEVEL": "DEBUG",
        "HOTKEY": "mouse4",
        "MODE": "cursor",
        "CUSTOM_VOCAB": "KeyGrip,FastAPI,pyproject",
        "HISTORY_ENABLED": "false",
    }
    with patch.dict("os.environ", env, clear=True):
        with patch("getinvoke.config._load_config_file", return_value={}):
            from getinvoke.config import Settings

            s = Settings()
            assert s.WHISPER_MODEL == "tiny"
            assert s.REFORMATTER_BACKEND == "local"  # "ollama" normalized to "local"
            assert s.LOG_LEVEL == "DEBUG"
            assert s.HOTKEY == "mouse4"
            assert s.MODE == "cursor"
            assert s.hotwords == ["KeyGrip", "FastAPI", "pyproject"]
            assert s.HISTORY_ENABLED is False


def test_settings_config_file_overrides_env():
    """Config file values should take precedence over env vars."""
    cfg = {"whisper_model": "large-v3", "hotkey": "mouse5", "mode": "windsurf"}
    env = {"WHISPER_MODEL": "tiny", "HOTKEY": "mouse4", "MODE": "raw"}
    with patch.dict("os.environ", env, clear=True):
        with patch("getinvoke.config._load_config_file", return_value=cfg):
            from getinvoke.config import Settings

            s = Settings()
            assert s.WHISPER_MODEL == "large-v3"
            assert s.HOTKEY == "mouse5"
            assert s.MODE == "windsurf"


def test_settings_save(tmp_path):
    """Settings.save() should write config.json with all fields."""
    with patch.dict("os.environ", {}, clear=True):
        with patch("getinvoke.config._load_config_file", return_value={}):
            with patch("getinvoke.config._config_dir", return_value=tmp_path):
                from getinvoke.config import Settings

                s = Settings()
                s.save()

                config_file = tmp_path / "config.json"
                assert config_file.exists()
                data = json.loads(config_file.read_text())
                assert data["whisper_model"] == "distil-large-v3"
                assert data["hotkey"] == "mouse5"
                assert data["mode"] == "claude-code"
                assert data["ollama_url"] == "http://localhost:11434"
                assert data["history_enabled"] == "true"


def test_whisper_compute_type():
    """Should return float16 for cuda, int8 for cpu."""
    with patch.dict("os.environ", {}, clear=True):
        with patch("getinvoke.config._load_config_file", return_value={}):
            with patch("getinvoke.config._detect_whisper_device", return_value="cuda"):
                from getinvoke.config import Settings

                s = Settings()
                assert s.whisper_compute_type == "float16"

            with patch("getinvoke.config._detect_whisper_device", return_value="cpu"):
                s2 = Settings()
                assert s2.whisper_compute_type == "int8"


def test_db_path(tmp_path):
    """db_path should be in the config directory."""
    with patch.dict("os.environ", {}, clear=True):
        with patch("getinvoke.config._load_config_file", return_value={}):
            with patch("getinvoke.config._config_dir", return_value=tmp_path):
                from getinvoke.config import Settings

                s = Settings()
                assert s.db_path.name == "history.db"
                assert s.db_path.parent == s.config_dir
