"""First-run setup wizard (tkinter)."""

import logging
import tkinter as tk
from tkinter import ttk

logger = logging.getLogger(__name__)


def run_wizard() -> None:
    """Launch the first-run setup wizard. Blocks until complete."""
    logger.info("Launching first-run wizard...")
    app = WizardApp()
    app.mainloop()
    logger.info("Wizard complete")


class WizardApp(tk.Tk):
    """Multi-step setup wizard."""

    def __init__(self) -> None:
        super().__init__()
        self.attributes("-alpha", 0)  # Fully transparent while building
        self.withdraw()  # Also withdraw to prevent white flash
        self.title("Invoke Setup")
        self.geometry("520x480")
        self.resizable(False, False)
        # Center on screen
        self.update_idletasks()
        x = (self.winfo_screenwidth() - 520) // 2
        y = (self.winfo_screenheight() - 480) // 2
        self.geometry(f"+{x}+{y}")

        # Collected settings
        self._settings: dict = {}

        # Apply Patina theme
        from getinvoke.theme import apply_theme

        apply_theme(self)

        # Save whatever we have if user closes the window early
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # Container
        self._container = ttk.Frame(self)
        self._container.pack(fill="both", expand=True, padx=32, pady=24)

        # Steps
        self._steps = [
            self._step_welcome,
            self._step_license,
            self._step_gpu,
            self._step_audio,
            self._step_reformatter,
            self._step_hotkey,
            self._step_project,
            self._step_done,
        ]
        self._current_step = 0
        self._show_step()
        self.deiconify()  # Show now that all widgets are styled
        self.attributes("-alpha", 1.0)  # Fade in after styling complete

    def _clear(self) -> None:
        for w in self._container.winfo_children():
            w.destroy()

    def _show_step(self) -> None:
        self._clear()
        self._steps[self._current_step]()

    def _next(self) -> None:
        self._current_step += 1
        self._show_step()

    def _add_nav(self, next_text: str = "Next") -> None:
        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        btn = ttk.Button(nav, text=next_text, command=self._next, style="Gold.TButton")
        btn.pack(side="right")

    # --- Step 1: Welcome ---
    def _step_welcome(self) -> None:
        from getinvoke.theme import TEAL_BRIGHT

        ttk.Label(self._container, text="> invoke", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self._container, text="Voice-to-prompt for developers", style="Sub.TLabel").pack(
            anchor="w", pady=(4, 16)
        )

        ttk.Label(
            self._container,
            text="Hold a hotkey, speak, release.\n"
            "Your speech is transcribed on-device, cleaned up by AI,\n"
            "and pasted wherever your cursor is.",
            foreground=TEAL_BRIGHT,
            wraplength=440,
        ).pack(anchor="w", pady=(0, 12))

        ttk.Label(
            self._container,
            text="No audio ever leaves your machine.",
            foreground="#D4943A",
            wraplength=440,
        ).pack(anchor="w", pady=(0, 16))

        import platform

        if platform.system() == "Darwin":
            ttk.Label(
                self._container,
                text="macOS will ask for Accessibility and Microphone permissions\n"
                "on first use \u2014 grant both for hotkeys and recording to work.",
                foreground="#888888",
                wraplength=440,
            ).pack(anchor="w", pady=(0, 4))

        ttk.Label(
            self._container,
            text="Let's set up your GPU, microphone, and AI engine.",
            style="Sub.TLabel",
        ).pack(anchor="w")

        self._add_nav("Get started")

    # --- Step 2: License ---
    def _step_license(self) -> None:
        ttk.Label(self._container, text="License", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            self._container,
            text="Invoke includes a 7-day free trial. Enter a license key\nto activate, or start your trial now.",
            style="Sub.TLabel",
            wraplength=440,
        ).pack(anchor="w", pady=(4, 16))

        # License key entry
        ttk.Label(self._container, text="License Key:").pack(anchor="w", pady=(0, 4))
        self._license_key_var = tk.StringVar()
        key_entry = ttk.Entry(self._container, textvariable=self._license_key_var, width=48, show="*")
        key_entry.pack(anchor="w")

        self._license_status_var = tk.StringVar()
        self._license_status_label = ttk.Label(
            self._container, textvariable=self._license_status_var, style="Sub.TLabel"
        )
        self._license_status_label.pack(anchor="w", pady=(4, 0))

        def _activate_and_next() -> None:
            key = self._license_key_var.get().strip()
            if not key:
                self._license_status_var.set("Please enter a key, or start your trial below.")
                return

            self._license_status_var.set("Activating...")

            import threading

            def _do_activate():
                from getinvoke.license import LicenseManager

                lm = LicenseManager()
                success, msg = lm.activate(key)
                self.after(0, lambda: _on_activate_done(success, msg))

            def _on_activate_done(success, msg):
                if success:
                    self._settings["license_activated"] = True
                    self._next()
                else:
                    self._license_status_var.set(msg)

            threading.Thread(target=_do_activate, daemon=True).start()

        def _start_trial() -> None:
            import threading

            def _do_trial():
                from getinvoke.license import LicenseManager

                lm = LicenseManager()
                lm.check()  # Creates trial if no license.json
                self.after(0, self._next)

            threading.Thread(target=_do_trial, daemon=True).start()

        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        ttk.Button(nav, text="Activate", command=_activate_and_next, style="Gold.TButton").pack(side="right")
        ttk.Button(nav, text="Start 7-day trial", command=_start_trial).pack(side="right", padx=(0, 8))

    # --- Step 3: GPU Detection ---
    def _step_gpu(self) -> None:
        ttk.Label(self._container, text="GPU Detection", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self._container, text="Checking for GPU acceleration...", style="Sub.TLabel").pack(
            anchor="w", pady=(4, 16)
        )

        status_frame = ttk.Frame(self._container)
        status_frame.pack(anchor="w", fill="x", pady=(0, 8))

        # Detect GPU: Apple Silicon MLX, then CUDA
        import shutil

        gpu_available = False
        detection_method = ""
        device = "cpu"

        # Check Apple Silicon + MLX
        import platform as _plat

        if _plat.system() == "Darwin" and _plat.machine() == "arm64":
            try:
                import mlx_whisper  # noqa: F401

                gpu_available = True
                detection_method = "Apple Silicon (MLX)"
                device = "mlx"
            except ImportError:
                pass

        if not gpu_available:
            try:
                import ctranslate2

                cuda_types = ctranslate2.get_supported_compute_types("cuda")
                if cuda_types:
                    gpu_available = True
                    detection_method = "ctranslate2 CUDA support"
                    device = "cuda"
            except Exception:
                pass

        if not gpu_available:
            import os

            cuda_path = os.environ.get("CUDA_PATH", "")
            if cuda_path and os.path.isdir(cuda_path):
                gpu_available = True
                detection_method = f"CUDA Toolkit at {cuda_path}"
                device = "cuda"

        if not gpu_available and shutil.which("nvidia-smi"):
            gpu_available = True
            detection_method = "nvidia-smi (NVIDIA driver)"
            device = "cuda"

        if gpu_available:
            label = "Apple Silicon GPU detected!" if device == "mlx" else "CUDA GPU detected!"
            ttk.Label(status_frame, text=label, style="Green.TLabel").pack(anchor="w")
            ttk.Label(
                status_frame,
                text=f"Transcription will run on your GPU for sub-second speed.\n({detection_method})",
                wraplength=440,
                style="Sub.TLabel",
            ).pack(anchor="w", pady=(4, 0))
            self._settings["whisper_device"] = device
        else:
            ttk.Label(status_frame, text="No GPU acceleration found", style="Sub.TLabel").pack(anchor="w")
            ttk.Label(
                status_frame,
                text="Transcription will run on CPU. Slower but fully functional.",
                style="Sub.TLabel",
                wraplength=440,
            ).pack(anchor="w", pady=(4, 0))
            self._settings["whisper_device"] = "cpu"

        self._add_nav()

    # --- Step 3: Audio Device ---
    def _step_audio(self) -> None:
        ttk.Label(self._container, text="Audio Device", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self._container, text="Select your microphone", style="Sub.TLabel").pack(anchor="w", pady=(4, 16))

        from getinvoke.recorder import list_devices

        devices = list_devices()
        device_names = [f"[{d['index']}] {d['name']}" for d in devices]

        if not device_names:
            ttk.Label(self._container, text="No audio input devices found!", style="Warn.TLabel").pack(anchor="w")
            self._settings["audio_device"] = ""
            self._add_nav()
            return

        self._audio_var = tk.StringVar(value=device_names[0])
        combo = ttk.Combobox(
            self._container,
            textvariable=self._audio_var,
            values=device_names,
            state="readonly",
            width=50,
        )
        combo.pack(anchor="w", pady=(0, 8))

        ttk.Label(
            self._container,
            text="Tip: Pick your primary microphone. You can change this later in Settings.",
            style="Sub.TLabel",
            wraplength=440,
        ).pack(anchor="w")

        def _next_with_device() -> None:
            selected = self._audio_var.get()
            if selected:
                # Extract device index from "[N] Name"
                idx = selected.split("]")[0].strip("[")
                self._settings["audio_device"] = idx
            self._next()

        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        ttk.Button(nav, text="Next", command=_next_with_device, style="Gold.TButton").pack(side="right")

    # --- Step 4: AI Processing ---
    def _step_reformatter(self) -> None:
        import shutil
        import webbrowser

        ttk.Label(self._container, text="AI Processing", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            self._container,
            text="After Whisper transcribes your speech, an AI can clean it up\n"
            "— fix grammar, remove filler words, and format it for your coding tool.",
            style="Sub.TLabel",
            wraplength=440,
        ).pack(anchor="w", pady=(4, 12))

        # Auto-detect available backends
        has_claude_cli = shutil.which("claude") is not None
        # Default to no AI — let user opt in to a backend
        default_backend = "none"
        self._backend_var = tk.StringVar(value=default_backend)

        options = [
            (
                "openrouter",
                "OpenRouter (fastest)",
                "~1 second. Uses Claude via cloud API (~$0.001/dictation). Needs an API key.",
            ),
            (
                "local",
                "Local LLM (fast + private)",
                "~1\u20133 seconds. Fully offline. Works with Ollama, LM Studio, or any local server.",
            ),
            (
                "claude-cli",
                "Claude Code CLI (slower)" + (" (detected)" if has_claude_cli else ""),
                "~5\u201315 seconds. No extra API key — uses your Claude Code subscription.",
            ),
            (
                "none",
                "No AI — raw transcription only",
                "Instant. Whisper output goes straight to clipboard, no cleanup.",
            ),
        ]

        for value, label, desc in options:
            frame = ttk.Frame(self._container)
            frame.pack(anchor="w", fill="x", pady=(0, 2))
            ttk.Radiobutton(frame, text=label, variable=self._backend_var, value=value).pack(anchor="w")
            ttk.Label(frame, text=desc, style="Sub.TLabel", wraplength=420).pack(anchor="w", padx=(24, 0))

        # OpenRouter API key entry (shown only when openrouter selected)
        self._api_frame = ttk.Frame(self._container)
        self._api_var = tk.StringVar()
        key_row = ttk.Frame(self._api_frame)
        key_row.pack(anchor="w", fill="x")
        ttk.Label(key_row, text="OpenRouter API Key:").pack(side="left")
        ttk.Button(
            key_row,
            text="Get key",
            command=lambda: webbrowser.open("https://openrouter.ai/keys"),
        ).pack(side="left", padx=(8, 0))
        ttk.Entry(self._api_frame, textvariable=self._api_var, width=50, show="*").pack(anchor="w", pady=(4, 0))
        self._api_warn_var = tk.StringVar()
        ttk.Label(self._api_frame, textvariable=self._api_warn_var, foreground="#E67E80").pack(anchor="w", pady=(2, 0))

        def _on_backend_change(*_args: object) -> None:
            if self._backend_var.get() == "openrouter":
                self._api_frame.pack(anchor="w", fill="x", pady=(8, 0))
            else:
                self._api_frame.pack_forget()

        self._backend_var.trace_add("write", _on_backend_change)
        _on_backend_change()  # Set initial visibility

        def _next_with_backend() -> None:
            backend = self._backend_var.get()
            # Warn if OpenRouter selected without API key
            if backend == "openrouter" and not self._api_var.get().strip():
                self._api_warn_var.set("API key required for OpenRouter. Enter a key or choose another option.")
                return
            self._settings["reformatter_backend"] = backend
            if backend == "openrouter":
                self._settings["openrouter_api_key"] = self._api_var.get().strip()
            self._next()

        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        ttk.Button(nav, text="Next", command=_next_with_backend, style="Gold.TButton").pack(side="right")

    # --- Step 5: Hotkey ---
    def _step_hotkey(self) -> None:
        ttk.Label(self._container, text="Hotkey", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self._container, text="Choose your push-to-talk button", style="Sub.TLabel").pack(
            anchor="w", pady=(4, 12)
        )

        self._hotkey_var = tk.StringVar(value="mouse5")

        options = [
            ("mouse5", "Mouse 5 (thumb forward)", "Popular push-to-talk. May trigger forward in browsers."),
            ("mouse4", "Mouse 4 (thumb back)", "Alternative thumb button. May trigger back in browsers."),
            ("ctrl+shift+d", "Ctrl+Shift+D", "Keyboard shortcut. Works everywhere, no conflicts."),
        ]

        for value, label, desc in options:
            frame = ttk.Frame(self._container)
            frame.pack(anchor="w", fill="x", pady=(0, 3))
            ttk.Radiobutton(frame, text=label, variable=self._hotkey_var, value=value).pack(anchor="w")
            ttk.Label(frame, text=desc, style="Sub.TLabel", wraplength=420).pack(anchor="w", padx=(24, 0))

        # Record custom hotkey
        custom_frame = ttk.Frame(self._container)
        custom_frame.pack(anchor="w", fill="x", pady=(8, 0))
        ttk.Label(custom_frame, text="Or record your own:", style="Sub.TLabel").pack(side="left")
        self._wizard_record_btn = ttk.Button(
            custom_frame, text="Record...", command=self._wizard_record_hotkey, width=10
        )
        self._wizard_record_btn.pack(side="left", padx=(8, 0))
        self._wizard_custom_label = ttk.Label(custom_frame, text="", foreground="#5FC8C8")
        self._wizard_custom_label.pack(side="left", padx=(8, 0))

        # Auto-paste toggle
        self._autopaste_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            self._container,
            text="Auto-paste at cursor (recommended)",
            variable=self._autopaste_var,
        ).pack(anchor="w", pady=(12, 0))
        ttk.Label(
            self._container,
            text="Text appears at your cursor automatically. Uncheck to use Ctrl+V manually.",
            style="Sub.TLabel",
            wraplength=440,
        ).pack(anchor="w", padx=(24, 0))

        def _next_with_hotkey() -> None:
            self._settings["hotkey"] = self._hotkey_var.get()
            self._settings["auto_paste"] = self._autopaste_var.get()
            self._next()

        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        ttk.Button(nav, text="Next", command=_next_with_hotkey, style="Gold.TButton").pack(side="right")

    def _wizard_record_hotkey(self) -> None:
        """Record a custom hotkey in the wizard."""
        from pynput import keyboard
        from pynput import mouse as pynput_mouse

        from getinvoke.hotkey import MOUSE_BUTTON_MAP, format_key_combo

        self._wizard_record_btn.configure(text="Press...")
        held: set = set()
        _done = [False]
        _button_to_name = {v: k for k, v in MOUSE_BUTTON_MAP.items()}
        _listeners: list = []

        def _finish(combo_str: str | None) -> None:
            if _done[0]:
                return
            _done[0] = True
            for lst in _listeners:
                try:
                    lst.stop()
                except Exception:
                    pass
            if combo_str is not None:
                self._hotkey_var.set(combo_str)
                self.after(0, lambda s=combo_str: self._wizard_custom_label.configure(text=f"Set: {s}"))
            self.after(0, lambda: self._wizard_record_btn.configure(text="Record..."))

        def on_press(key: keyboard.Key | keyboard.KeyCode) -> bool | None:
            if _done[0]:
                return False
            if key == keyboard.Key.esc:
                _finish(None)
                return False
            held.add(key)
            return None

        def on_release(key: keyboard.Key | keyboard.KeyCode) -> None:
            if _done[0] or not held:
                return False
            _finish(format_key_combo(held))
            held.clear()
            return False

        def on_click(x: int, y: int, button: pynput_mouse.Button, pressed: bool) -> None:
            if _done[0] or not pressed:
                return
            name = _button_to_name.get(button)
            if name and name not in ("left", "right"):
                _finish(name)
                return False

        kb_listener = keyboard.Listener(on_press=on_press, on_release=on_release)
        ms_listener = pynput_mouse.Listener(on_click=on_click)
        ms_listener.daemon = True
        _listeners.extend([kb_listener, ms_listener])
        kb_listener.start()
        ms_listener.start()

        def _timeout() -> None:
            _finish(None)

        self.after(5000, _timeout)

    # --- Step 6: Project Directory ---
    def _step_project(self) -> None:
        ttk.Label(self._container, text="Project Directory", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            self._container,
            text="Point Invoke at your project so AI has context about your codebase.",
            style="Sub.TLabel",
        ).pack(anchor="w", pady=(4, 16))

        # Try auto-detection first
        from getinvoke.window import get_active_cwd

        auto_cwd = get_active_cwd()

        status_frame = ttk.Frame(self._container)
        status_frame.pack(anchor="w", fill="x", pady=(0, 8))

        if auto_cwd:
            ttk.Label(
                status_frame,
                text=f"Auto-detected: {auto_cwd}",
                foreground="#5FC8C8",
                wraplength=440,
            ).pack(anchor="w")
            ttk.Label(
                status_frame,
                text="You can change this below or leave it.",
                style="Sub.TLabel",
            ).pack(anchor="w", pady=(2, 0))

        self._project_var = tk.StringVar(value=auto_cwd or "")

        entry_frame = ttk.Frame(self._container)
        entry_frame.pack(anchor="w", fill="x", pady=(0, 4))
        ttk.Entry(entry_frame, textvariable=self._project_var, width=38).pack(side="left")

        def _browse() -> None:
            from tkinter import filedialog

            path = filedialog.askdirectory()
            if path:
                self._project_var.set(path)

        ttk.Button(entry_frame, text="Browse...", command=_browse, width=8).pack(side="left", padx=(6, 0))

        ttk.Label(
            self._container,
            text="The path to your project's root folder (where .git, package.json,\n"
            "or pyproject.toml lives). This helps the AI understand your code\n"
            "when formatting your dictation.",
            style="Sub.TLabel",
            wraplength=440,
        ).pack(anchor="w", pady=(4, 0))

        if not auto_cwd:
            ttk.Label(
                self._container,
                text="Could not auto-detect your project. Browse to set it,\n"
                "or leave blank and set it later in Settings.",
                foreground="#D4943A",
                wraplength=440,
            ).pack(anchor="w", pady=(8, 0))

        def _next_with_project() -> None:
            project_dir = self._project_var.get().strip()
            if project_dir:
                self._settings["project_dir"] = project_dir
            self._next()

        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        ttk.Button(nav, text="Next", command=_next_with_project, style="Gold.TButton").pack(side="right")
        if not auto_cwd:
            ttk.Button(nav, text="Skip", command=self._next).pack(side="right", padx=(0, 8))

    # --- Step 7: Done ---
    def _step_done(self) -> None:
        ttk.Label(self._container, text="You're all set!", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self._container, text="Saving your configuration...", style="Sub.TLabel").pack(
            anchor="w", pady=(4, 16)
        )

        # Save settings
        self._save_settings()

        # Summary
        device = self._settings.get("whisper_device", "cpu")
        backend = self._settings.get("reformatter_backend", "none")
        hotkey = self._settings.get("hotkey", "mouse5")
        autopaste = self._settings.get("auto_paste", True)

        summary = [
            f"GPU: {'Apple Silicon (MLX)' if device == 'mlx' else 'CUDA' if device == 'cuda' else 'CPU'}",
            f"Reformatter: {backend}",
            f"Hotkey: {hotkey}",
            f"Auto-paste: {'on' if autopaste else 'off'}",
        ]
        for line in summary:
            ttk.Label(self._container, text=f"  > {line}", style="Green.TLabel").pack(anchor="w", pady=(2, 0))

        # Quick tips
        ttk.Label(self._container, text="\nQuick tips:", style="Sub.TLabel").pack(anchor="w", pady=(8, 0))
        tips = [
            f"Hold {hotkey} to speak, release to transcribe",
            "Right-click the tray icon to switch modes",
            "Run 'dictate health' in terminal to check your setup",
            "Change settings anytime from the tray menu",
        ]
        for tip in tips:
            ttk.Label(self._container, text=f"  > {tip}", style="Sub.TLabel", wraplength=420).pack(
                anchor="w", pady=(2, 0)
            )

        nav = ttk.Frame(self._container)
        nav.pack(side="bottom", fill="x", pady=(16, 0))
        ttk.Button(nav, text="Launch Invoke", command=self.destroy, style="Gold.TButton").pack(side="right")

    def _on_close(self) -> None:
        """Handle early window close — save whatever settings were collected."""
        if self._settings:
            self._save_settings()
        self.destroy()

    def _save_settings(self) -> None:
        """Write collected settings to config.json."""
        from getinvoke.config import settings

        if "whisper_device" in self._settings:
            settings.WHISPER_DEVICE = self._settings["whisper_device"]
        if "audio_device" in self._settings:
            settings.AUDIO_DEVICE = self._settings["audio_device"] or None
        if "reformatter_backend" in self._settings:
            settings.REFORMATTER_BACKEND = self._settings["reformatter_backend"]
        if "openrouter_api_key" in self._settings:
            settings.OPENROUTER_API_KEY = self._settings["openrouter_api_key"]
        if "hotkey" in self._settings:
            settings.HOTKEY = self._settings["hotkey"]
        if "auto_paste" in self._settings:
            settings.AUTO_PASTE = self._settings["auto_paste"]
        if "project_dir" in self._settings:
            settings.PROJECT_DIR = self._settings["project_dir"]

        settings.save()
        safe = {k: ("***" if "key" in k.lower() else v) for k, v in self._settings.items()}
        logger.info(f"Wizard saved config: {safe}")
