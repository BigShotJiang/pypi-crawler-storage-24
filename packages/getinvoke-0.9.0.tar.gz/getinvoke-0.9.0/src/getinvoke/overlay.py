"""Recording overlay — small floating bar showing recording state and duration."""

import logging
import os
import platform
import threading
import time
import tkinter as tk

from getinvoke.theme import FONT_FAMILY

# On Wayland, pynput's Xlib record extension only receives mouse events when an
# X11 window is mapped. We keep the overlay window mapped at all times (moved
# off-screen when "hidden") instead of using withdraw(), so XWayland stays
# active and global mouse hotkeys work.
_ON_WAYLAND = platform.system() == "Linux" and bool(os.environ.get("WAYLAND_DISPLAY"))
_OFFSCREEN_GEOMETRY = "+99999+99999"

logger = logging.getLogger(__name__)


class RecordingOverlay:
    """Always-on-top floating bar that shows recording/processing state.

    Runs tkinter in its own thread. All UI updates are dispatched
    via root.after() for thread safety.
    """

    def __init__(self) -> None:
        self._root: tk.Tk | None = None
        self._label: tk.Label | None = None
        self._thread: threading.Thread | None = None
        self._ready = threading.Event()
        self._recording_start: float = 0
        self._timer_running = False
        self._processing = False
        self._auto_hide_id: str | None = None

    def start(self) -> None:
        """Start the overlay thread. Call once at app startup."""
        self._thread = threading.Thread(target=self._run_tk, daemon=True)
        self._thread.start()
        self._ready.wait(timeout=5)
        logger.info("Recording overlay started")

    def stop(self) -> None:
        """Stop the overlay."""
        self._timer_running = False
        if self._root is not None:
            self._root.after(0, self._root.destroy)
            self._root = None

    def show_recording(self) -> None:
        """Show 'Recording...' with a live timer."""
        self._recording_start = time.time()
        self._timer_running = True
        self._processing = False
        self._dispatch(self._show_recording_ui)

    def show_processing(self) -> None:
        """Show 'Processing...' state with live timer."""
        # Keep timer running so user can see it's not frozen
        self._processing = True
        self._dispatch(self._show_processing_ui)

    def show_done(self, preview: str = "") -> None:
        """Show 'Done!' briefly, then hide."""
        self._timer_running = False
        self._processing = False
        self._dispatch(lambda: self._show_done_ui(preview))

    def show_error(self, message: str = "Error") -> None:
        """Show error briefly, then hide."""
        self._timer_running = False
        self._processing = False
        self._dispatch(lambda: self._show_error_ui(message))

    def hide(self) -> None:
        """Hide the overlay."""
        self._timer_running = False
        self._dispatch(self._hide_ui)

    def _dispatch(self, func) -> None:
        """Thread-safe dispatch to tkinter main loop."""
        if self._root is not None:
            try:
                self._root.after(0, func)
            except tk.TclError:
                pass

    def _run_tk(self) -> None:
        """Tkinter main loop (runs in its own thread)."""
        try:
            self._root = tk.Tk()
            if _ON_WAYLAND:
                # Keep the window mapped so XWayland routes mouse events to pynput.
                # Move off-screen instead of withdrawing.
                self._root.geometry(_OFFSCREEN_GEOMETRY)
            else:
                self._root.withdraw()
            self._root.overrideredirect(True)
            self._root.attributes("-topmost", True)
            self._root.configure(bg="#0D1B1E")

            # Try to set transparency (platform-dependent)
            try:
                self._root.attributes("-alpha", 0.92)
            except tk.TclError:
                pass

            # Main frame with border
            frame = tk.Frame(self._root, bg="#0D1B1E", highlightbackground="#3D9DAA", highlightthickness=1)
            frame.pack(fill="both", expand=True)

            self._label = tk.Label(
                frame,
                text="",
                font=(FONT_FAMILY, 11),
                fg="#D4D4CC",
                bg="#0D1B1E",
                padx=16,
                pady=8,
            )
            self._label.pack()

            self._ready.set()
            self._root.mainloop()
        except Exception as e:
            logger.error(f"Overlay error: {e}")
            self._ready.set()

    def _position_window(self) -> None:
        """Position overlay in bottom-right corner above taskbar."""
        if self._root is None:
            return
        self._root.update_idletasks()
        w = self._root.winfo_width()
        h = self._root.winfo_height()
        screen_w = self._root.winfo_screenwidth()
        screen_h = self._root.winfo_screenheight()
        x = screen_w - w - 20
        y = screen_h - h - 60
        self._root.geometry(f"+{x}+{y}")

    def _cancel_auto_hide(self) -> None:
        """Cancel any pending auto-hide timer."""
        if self._auto_hide_id and self._root:
            try:
                self._root.after_cancel(self._auto_hide_id)
            except (tk.TclError, ValueError):
                pass
            self._auto_hide_id = None

    def _show_window(self) -> None:
        """Show and position the overlay."""
        if self._root is None:
            return
        self._cancel_auto_hide()
        if _ON_WAYLAND:
            # Window is already mapped; just reposition it.
            self._position_window()
        else:
            self._root.deiconify()
            self._position_window()

    def _hide_ui(self) -> None:
        if self._root is not None:
            if _ON_WAYLAND:
                self._root.geometry(_OFFSCREEN_GEOMETRY)
            else:
                self._root.withdraw()

    def _show_recording_ui(self) -> None:
        if self._label is None:
            return
        self._label.configure(text="  Recording...  0.0s", fg="#5FC8C8")
        self._show_window()
        self._update_timer()

    def _update_timer(self) -> None:
        """Update the duration display during recording and processing."""
        if not self._timer_running or self._label is None or self._root is None:
            return
        elapsed = time.time() - self._recording_start
        if self._processing:
            self._label.configure(text=f"  Processing...  {elapsed:.1f}s")
        else:
            self._label.configure(text=f"  Recording...  {elapsed:.1f}s")
        self._root.after(100, self._update_timer)

    def _show_processing_ui(self) -> None:
        if self._label is None:
            return
        elapsed = time.time() - self._recording_start
        self._label.configure(text=f"  Processing...  {elapsed:.1f}s", fg="#D4943A")
        self._show_window()

    def _show_done_ui(self, preview: str) -> None:
        if self._label is None:
            return
        text = "  Done!"
        if preview:
            text = f"  Done! — {preview[:40]}"
        self._label.configure(text=text, fg="#5FC8C8")
        self._show_window()
        # Auto-hide after 1.5s
        if self._root is not None:
            self._auto_hide_id = self._root.after(1500, self._hide_ui)

    def _show_error_ui(self, message: str) -> None:
        if self._label is None:
            return
        self._label.configure(text=f"  {message}", fg="#E67E80")
        self._show_window()
        # Auto-hide after 3s
        if self._root is not None:
            self._auto_hide_id = self._root.after(3000, self._hide_ui)
