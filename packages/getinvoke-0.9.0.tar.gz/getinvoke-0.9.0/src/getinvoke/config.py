"""Settings from config.json + env vars + CLI args."""

import json
import logging
import os
import platform
from pathlib import Path

from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# Load .env from CWD for development
load_dotenv()


def _config_dir() -> Path:
    """Platform-appropriate config directory."""
    if platform.system() == "Windows":
        base = os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming")
        return Path(base) / "Invoke"
    if platform.system() == "Darwin":
        return Path.home() / "Library" / "Application Support" / "invoke"
    return Path.home() / ".config" / "invoke"


def _load_config_file() -> dict:
    """Load config.json if it exists."""
    path = _config_dir() / "config.json"
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"Failed to load config.json: {e}")
    return {}


def _detect_whisper_device() -> str:
    """Auto-detect best device for Whisper inference."""
    # Method 0: Apple Silicon with MLX acceleration
    if platform.system() == "Darwin" and platform.machine() == "arm64":
        try:
            import mlx_whisper  # noqa: F401

            logger.info("Apple Silicon detected with MLX — using GPU acceleration")
            return "mlx"
        except ImportError:
            logger.info("Apple Silicon detected but mlx-whisper not installed — using CPU")

    # Method 1: ctranslate2 reports CUDA compute types
    try:
        import ctranslate2

        cuda_types = ctranslate2.get_supported_compute_types("cuda")
        if cuda_types:
            return "cuda"
    except Exception:
        pass
    # Method 2: torch CUDA check
    try:
        import torch

        if torch.cuda.is_available():
            return "cuda"
    except ImportError:
        pass
    # Method 3: check for CUDA Toolkit on system (Windows — PyInstaller bundles
    # may not include ctranslate2 CUDA libs, but system CUDA Toolkit works at runtime)
    if platform.system() == "Windows":
        cuda_path = os.environ.get("CUDA_PATH", "")
        if cuda_path and os.path.isdir(cuda_path):
            logger.info(f"CUDA Toolkit found at {cuda_path}, enabling GPU")
            return "cuda"
    # Method 4: nvidia-smi exists (GPU driver installed, CUDA likely available)
    import shutil

    if shutil.which("nvidia-smi"):
        logger.info("nvidia-smi found on PATH, enabling GPU")
        return "cuda"
    return "cpu"


class Settings:
    """App settings with config file -> env var -> default precedence."""

    def __init__(self) -> None:
        cfg = _load_config_file()

        def _get(key: str, default: str = "") -> str:
            return cfg.get(key, os.getenv(key.upper(), default))

        # Reformatter
        self.OPENROUTER_API_KEY: str = _get("openrouter_api_key")
        self.DICTATION_MODEL: str = _get("dictation_model", "anthropic/claude-sonnet-4-6")
        self.REFORMATTER_BACKEND: str = _get("reformatter_backend", "none")
        self.CLAUDE_CLI_PATH: str = _get("claude_cli_path", "claude")
        self.CLAUDE_CLI_MODEL: str = _get("claude_cli_model", "haiku")

        # Local LLM
        self.LOCAL_LLM_PROVIDER: str = _get("local_llm_provider", "ollama")
        self.OLLAMA_URL: str = _get("ollama_url", "http://localhost:11434")
        self.OLLAMA_MODEL: str = _get("ollama_model", "llama3.2")
        self.LMSTUDIO_URL: str = _get("lmstudio_url", "http://localhost:1234")
        self.LMSTUDIO_MODEL: str = _get("lmstudio_model", "")

        # Backward compat: "ollama" backend → "local" with provider=ollama
        if self.REFORMATTER_BACKEND == "ollama":
            self.REFORMATTER_BACKEND = "local"
            self.LOCAL_LLM_PROVIDER = "ollama"

        # Whisper
        self.WHISPER_MODEL: str = _get("whisper_model", "distil-large-v3")
        self.WHISPER_DEVICE: str = _get("whisper_device", "auto")

        # Mode
        self.MODE: str = _get("mode", "claude-code")

        # Hotkey + audio
        self.HOTKEY: str = _get("hotkey", "mouse5")
        self.AUDIO_DEVICE: str | None = _get("audio_device") or None

        # Auto-paste (simulate Ctrl+V after copying to clipboard)
        self.AUTO_PASTE: bool = _get("auto_paste", "false").lower() in ("true", "1", "yes")

        # Language (Whisper transcription language, "auto" for auto-detect)
        self.LANGUAGE: str = _get("language", "en")

        # Custom vocabulary (comma-separated hotwords for Whisper)
        self.CUSTOM_VOCAB: str = _get("custom_vocab")

        # History
        self.HISTORY_ENABLED: bool = _get("history_enabled", "true").lower() in ("true", "1", "yes")
        self.HISTORY_RETENTION_DAYS: int = int(_get("history_retention_days", "30"))

        # Audio feedback
        self.BEEP_ENABLED: bool = _get("beep_enabled", "true").lower() in ("true", "1", "yes")
        self.SOUND_PRESET: str = _get("sound_preset", "default")

        # Image capture
        self.IMAGE_CAPTURE_ENABLED: bool = _get("image_capture_enabled", "true").lower() in ("true", "1", "yes")
        self.IMAGE_HOTKEY: str = _get("image_hotkey", "middle")
        self.IMAGE_SAVE_DIR: str = _get("image_save_dir", "~/.screenshots")
        self.IMAGE_RETENTION_DAYS: int = int(_get("image_retention_days", "30"))

        # Project directory (manual override for context detection)
        self.PROJECT_DIR: str = _get("project_dir", "")

        # Privacy mode (forces local-only processing)
        self.PRIVACY_MODE: bool = _get("privacy_mode", "false").lower() in ("true", "1", "yes")

        # General
        self.LOG_LEVEL: str = _get("log_level", "INFO")

        # Preserve raw setting before auto-resolution (for save/settings GUI)
        self._whisper_device_setting: str = self.WHISPER_DEVICE

        # Resolve auto device
        if self.WHISPER_DEVICE == "auto":
            self.WHISPER_DEVICE = _detect_whisper_device()

    @property
    def config_dir(self) -> Path:
        return _config_dir()

    @property
    def config_file(self) -> Path:
        return self.config_dir / "config.json"

    @property
    def log_dir(self) -> Path:
        return self.config_dir / "logs"

    @property
    def db_path(self) -> Path:
        return self.config_dir / "history.db"

    @property
    def whisper_compute_type(self) -> str:
        if self.WHISPER_DEVICE in ("cuda", "mlx"):
            return "float16"
        return "int8"

    @property
    def hotwords(self) -> list[str]:
        """Parse custom vocabulary into a list."""
        if not self.CUSTOM_VOCAB:
            return []
        return [w.strip() for w in self.CUSTOM_VOCAB.split(",") if w.strip()]

    def save(self) -> None:
        """Write current settings to config.json."""
        self.config_dir.mkdir(parents=True, exist_ok=True)
        data = {
            "openrouter_api_key": self.OPENROUTER_API_KEY,
            "dictation_model": self.DICTATION_MODEL,
            "reformatter_backend": self.REFORMATTER_BACKEND,
            "claude_cli_path": self.CLAUDE_CLI_PATH,
            "claude_cli_model": self.CLAUDE_CLI_MODEL,
            "local_llm_provider": self.LOCAL_LLM_PROVIDER,
            "ollama_url": self.OLLAMA_URL,
            "ollama_model": self.OLLAMA_MODEL,
            "lmstudio_url": self.LMSTUDIO_URL,
            "lmstudio_model": self.LMSTUDIO_MODEL,
            "whisper_model": self.WHISPER_MODEL,
            "whisper_device": self._whisper_device_setting,
            "mode": self.MODE,
            "hotkey": self.HOTKEY,
            "audio_device": self.AUDIO_DEVICE or "",
            "auto_paste": str(self.AUTO_PASTE).lower(),
            "language": self.LANGUAGE,
            "custom_vocab": self.CUSTOM_VOCAB,
            "history_enabled": str(self.HISTORY_ENABLED).lower(),
            "history_retention_days": str(self.HISTORY_RETENTION_DAYS),
            "beep_enabled": str(self.BEEP_ENABLED).lower(),
            "sound_preset": self.SOUND_PRESET,
            "image_capture_enabled": str(self.IMAGE_CAPTURE_ENABLED).lower(),
            "image_hotkey": self.IMAGE_HOTKEY,
            "image_save_dir": self.IMAGE_SAVE_DIR,
            "image_retention_days": str(self.IMAGE_RETENTION_DAYS),
            "project_dir": self.PROJECT_DIR,
            "privacy_mode": str(self.PRIVACY_MODE).lower(),
            "log_level": self.LOG_LEVEL,
        }
        self.config_file.write_text(json.dumps(data, indent=2), encoding="utf-8")

        # Restrict file permissions on Unix (contains API keys)
        if platform.system() != "Windows":
            import stat

            os.chmod(self.config_file, stat.S_IRUSR | stat.S_IWUSR)

        logger.info(f"Config saved to {self.config_file}")


settings = Settings()
