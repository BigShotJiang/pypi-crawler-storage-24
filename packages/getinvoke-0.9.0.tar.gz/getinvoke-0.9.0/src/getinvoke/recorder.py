"""Push-to-talk audio capture via sounddevice."""

import io
import logging
import threading

import numpy as np
import sounddevice as sd
from scipy.io import wavfile
from scipy.signal import resample_poly

logger = logging.getLogger(__name__)

WHISPER_RATE = 16000  # Whisper expects 16kHz
CHANNELS = 1
DTYPE = "int16"


_cached_sample_rates: dict[str | int | None, int] = {}


def _get_device_sample_rate(device: str | int | None) -> int:
    """Get a working sample rate for the device, preferring 16kHz. Cached after first probe."""
    if device in _cached_sample_rates:
        return _cached_sample_rates[device]

    for rate in [16000, 44100, 48000]:
        try:
            sd.check_input_settings(device=device, samplerate=rate, channels=CHANNELS, dtype=DTYPE)
            _cached_sample_rates[device] = rate
            return rate
        except sd.PortAudioError:
            continue
    # Fallback: use the device's default
    info = sd.query_devices(device, kind="input")
    rate = int(info["default_samplerate"])
    _cached_sample_rates[device] = rate
    return rate


class Recorder:
    """Thread-safe push-to-talk audio recorder.

    Keeps the audio stream open persistently to avoid ALSA/PulseAudio
    stream creation latency on every hotkey press (~1-2s on Linux).
    """

    def __init__(self, device: str | int | None = None) -> None:
        # sounddevice needs int index, not string — string triggers name matching
        if device is not None and isinstance(device, str) and device.isdigit():
            device = int(device)
        self._device = device
        self._frames: list[np.ndarray] = []
        self._stream: sd.InputStream | None = None
        self._lock = threading.Lock()
        self._recording = threading.Event()
        self._capture_rate: int = _get_device_sample_rate(device)
        self._keepalive_timer: threading.Timer | None = None

    def open(self) -> None:
        """Open the audio stream (call once at startup). Keeps stream hot for instant recording."""
        if self._stream is not None:
            return
        try:
            self._stream = sd.InputStream(
                samplerate=self._capture_rate,
                channels=CHANNELS,
                dtype=DTYPE,
                device=self._device,
                callback=self._audio_callback,
            )
            self._stream.start()
            self._start_keepalive()
            logger.info(f"Audio stream opened (capture rate: {self._capture_rate}Hz)")
        except Exception as e:
            logger.error(f"Failed to open audio stream: {e}")
            self._stream = None

    def close(self) -> None:
        """Close the audio stream (call on shutdown)."""
        self._stop_keepalive()
        if self._stream is not None:
            self._stream.stop()
            self._stream.close()
            self._stream = None
            logger.info("Audio stream closed")

    def _start_keepalive(self) -> None:
        """Ping the stream every 30s to prevent PipeWire/PulseAudio from suspending it."""

        def _keepalive():
            if self._stream is not None and not self._stream.active:
                logger.debug("Audio stream went inactive, reopening...")
                self.close()
                self.open()
                return  # open() starts a new keepalive
            self._keepalive_timer = threading.Timer(30.0, _keepalive)
            self._keepalive_timer.daemon = True
            self._keepalive_timer.start()

        self._keepalive_timer = threading.Timer(30.0, _keepalive)
        self._keepalive_timer.daemon = True
        self._keepalive_timer.start()

    def _stop_keepalive(self) -> None:
        if self._keepalive_timer is not None:
            self._keepalive_timer.cancel()
            self._keepalive_timer = None

    def start_recording(self) -> None:
        """Start capturing audio frames."""
        # Reopen if stream was closed/suspended by the OS
        if self._stream is None or not self._stream.active:
            logger.debug("Audio stream not active, reopening...")
            self.close()
            self.open()
        with self._lock:
            self._frames = []
            self._recording.set()
        logger.info("Recording started")

    def stop_recording(self) -> bytes:
        """Stop capturing and return WAV bytes at 16kHz (resampled if needed)."""
        with self._lock:
            self._recording.clear()

            if not self._frames:
                logger.warning("No audio frames captured")
                return b""

            audio = np.concatenate(self._frames, axis=0)
            self._frames = []

        # Resample to 16kHz if device used a different rate
        if self._capture_rate != WHISPER_RATE:
            from math import gcd

            g = gcd(WHISPER_RATE, self._capture_rate)
            audio = resample_poly(audio.flatten(), WHISPER_RATE // g, self._capture_rate // g).astype(np.int16)
            logger.debug(f"Resampled {self._capture_rate}Hz → {WHISPER_RATE}Hz")

        # Convert to WAV bytes
        buf = io.BytesIO()
        wavfile.write(buf, WHISPER_RATE, audio)
        wav_bytes = buf.getvalue()
        duration = len(audio) / WHISPER_RATE
        logger.info(f"Recording stopped: {duration:.1f}s, {len(wav_bytes)} bytes")
        return wav_bytes

    @property
    def is_recording(self) -> bool:
        return self._recording.is_set()

    def _audio_callback(self, indata: np.ndarray, frames: int, time_info: object, status: object) -> None:
        if status:
            logger.warning(f"Audio callback status: {status}")
        if self._recording.is_set():
            with self._lock:
                self._frames.append(indata.copy())


def list_devices() -> list[dict]:
    """List available audio input devices."""
    devices = sd.query_devices()
    inputs = []
    for i, dev in enumerate(devices):
        if dev["max_input_channels"] > 0:
            inputs.append({"index": i, "name": dev["name"], "channels": dev["max_input_channels"]})
    return inputs
