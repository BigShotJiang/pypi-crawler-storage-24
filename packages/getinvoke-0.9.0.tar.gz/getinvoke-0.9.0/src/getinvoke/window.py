"""Active window CWD and file detection."""

import logging
import platform
import re
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

_IS_WINDOWS = platform.system() == "Windows"

# Regex patterns to extract CWD from terminal window titles
_CWD_PATTERNS = [
    re.compile(r":\s+(/.+?)(?:\s*[-]|$)"),  # /path/to/dir - Terminal
    re.compile(r":\s+(~[^\s]*)"),  # ~/project - Terminal
    re.compile(r"([A-Z]:\\[^\s]+)"),  # C:\Users\... (Windows paths)
]

# Patterns to extract active file from IDE/editor window titles
_FILE_PATTERNS = [
    # VS Code / Cursor: "filename.ts — project — Visual Studio Code" or "filename.ts - project - Cursor"
    re.compile(r"^(.+?\.\w+)\s+[—\-]\s+.+?\s+[—\-]\s+(?:Visual Studio Code|Cursor|Windsurf)"),
    # VS Code with path: "src/file.ts — project"
    re.compile(r"^([\w./\\]+\.\w+)\s+[—\-]"),
    # Vim/Neovim: "filename.ts - NVIM" or "filename.ts (+) - VIM"
    re.compile(r"^(.+?\.\w+)(?:\s+\([+]\))?\s+[—\-]\s+N?VIM"),
    # Generic: anything.ext at the start of a title
    re.compile(r"^([\w\-./\\]+\.\w{1,10})\b"),
]


def get_active_cwd() -> str | None:
    """Get the working directory from the active terminal/IDE window.

    Detection chain (first match wins):
    1. Manual project_dir setting (user explicitly set it)
    2. .dictation_cwd hook file (Claude Code integration)
    3. Linux: /proc/{pid}/cwd of focused window
    4. Window title parsing (all platforms)
    5. Walk up from any detected dir to find project root (.git, package.json, etc.)
    """
    from getinvoke.config import settings

    # 1. Manual override from settings
    if settings.PROJECT_DIR:
        project_path = Path(settings.PROJECT_DIR).expanduser()
        if project_path.is_dir():
            return str(project_path)

    # 2. Hook file (Claude Code integration)
    cwd = _read_dictation_cwd_file()
    if cwd:
        return _find_project_root(cwd) or cwd

    # 3. Linux: /proc/{pid}/cwd of active window
    if platform.system() == "Linux":
        cwd = _get_cwd_from_proc()
        if cwd:
            return _find_project_root(cwd) or cwd

    # 4. Window title parsing (all platforms)
    cwd = _get_cwd_from_window_title()
    if cwd:
        return _find_project_root(cwd) or cwd

    return None


# Project root markers — if any of these exist in a directory, it's a project root
_PROJECT_MARKERS = {
    ".git",
    "package.json",
    "pyproject.toml",
    "Cargo.toml",
    "go.mod",
    "Gemfile",
    "pom.xml",
    "CLAUDE.md",
    ".cursorrules",
}


def _find_project_root(start: str) -> str | None:
    """Walk up from start to find the nearest project root."""
    current = Path(start)
    home = Path.home()
    while current != current.parent and current != home:
        if any((current / m).exists() for m in _PROJECT_MARKERS):
            return str(current)
        current = current.parent
    return None


def _get_cwd_from_proc() -> str | None:
    """Linux: get CWD of the active window's process via /proc."""
    try:
        result = subprocess.run(
            ["xdotool", "getactivewindow", "getwindowpid"],
            capture_output=True,
            text=True,
            timeout=2,
        )
        pid = result.stdout.strip()
        if pid and pid.isdigit():
            proc_cwd = Path(f"/proc/{pid}/cwd")
            if proc_cwd.exists():
                resolved = proc_cwd.resolve()
                if resolved.is_dir() and str(resolved) != "/":
                    logger.debug(f"CWD from /proc/{pid}/cwd: {resolved}")
                    return str(resolved)
    except Exception as e:
        logger.debug(f"Failed to get CWD from /proc: {e}")
    return None


def get_active_file() -> str | None:
    """Get the active file path from the foreground window title.

    Returns:
        File path string (may be relative), or None if not detected.
    """
    title = _get_window_title()
    if not title:
        return None

    for pattern in _FILE_PATTERNS:
        match = pattern.search(title)
        if match:
            filepath = match.group(1).strip()
            # Sanity check: should look like a file (has extension, not too long)
            if "." in filepath and len(filepath) < 200:
                logger.debug(f"Active file from window title: {filepath}")
                return filepath

    return None


def _get_window_title() -> str | None:
    """Get the foreground window title."""
    if _IS_WINDOWS:
        try:
            import ctypes

            user32 = ctypes.windll.user32
            hwnd = user32.GetForegroundWindow()
            length = user32.GetWindowTextLengthW(hwnd)
            if length == 0:
                return None

            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            return buf.value or None
        except Exception as e:
            logger.debug(f"Failed to get window title: {e}")
            return None

    if platform.system() == "Darwin":
        try:
            result = subprocess.run(
                [
                    "osascript",
                    "-e",
                    'tell application "System Events" to get name of first window'
                    " of (first application process whose frontmost is true)",
                ],
                capture_output=True,
                text=True,
                timeout=2,
            )
            title = result.stdout.strip()
            if title:
                logger.debug(f"Window title (macOS): {title}")
                return title
        except Exception as e:
            logger.debug(f"Failed to get macOS window title: {e}")
        return None

    return None


def _read_dictation_cwd_file() -> str | None:
    """Read CWD from the dictation temp file.

    Uses a user-private path to prevent other users from injecting
    arbitrary directories via a shared /tmp location.
    """
    import os

    if _IS_WINDOWS:
        path = Path(os.environ.get("TEMP", "C:\\Temp")) / ".dictation_cwd"
    else:
        # Use the platform-appropriate config dir (macOS: ~/Library/Application Support/invoke)
        from getinvoke.config import settings

        path = settings.config_dir / ".dictation_cwd"
        # Also check legacy /tmp path but only if owned by current user
        legacy_path = Path("/tmp/.dictation_cwd")
        if not path.exists() and legacy_path.exists():
            try:
                stat = legacy_path.stat()
                if stat.st_uid == os.getuid():
                    path = legacy_path
                else:
                    logger.warning("Ignoring /tmp/.dictation_cwd — not owned by current user")
                    return None
            except OSError:
                return None

    try:
        cwd = path.read_text().strip()
        # Validate: must be an existing directory, not a special path
        cwd_path = Path(cwd)
        if cwd and cwd_path.is_dir() and cwd_path.is_absolute():
            logger.debug(f"CWD from dictation file: {cwd}")
            return cwd
    except (OSError, FileNotFoundError):
        pass
    return None


def _get_cwd_from_window_title() -> str | None:
    """Parse CWD from the foreground window title (all platforms)."""
    title = _get_window_title()
    if not title:
        return None

    logger.debug(f"Window title: {title}")

    for pattern in _CWD_PATTERNS:
        match = pattern.search(title)
        if match:
            cwd = match.group(1)
            # Expand ~
            if cwd.startswith("~"):
                cwd = str(Path.home() / cwd[2:]) if len(cwd) > 1 else str(Path.home())
            if Path(cwd).exists():
                logger.debug(f"CWD from window title: {cwd}")
                return cwd

    return None
