"""Clipboard image capture — grabs image from clipboard, saves as PNG."""

import logging
import os
import subprocess
from datetime import datetime, timedelta
from pathlib import Path

from getinvoke.config import settings

logger = logging.getLogger(__name__)


def capture_clipboard_image() -> str | None:
    """Grab image from clipboard, save as PNG, return file path.

    Dispatches to platform-specific implementation (macOS or Windows/WSL2).
    Returns None if no image is in the clipboard.
    """
    import platform

    save_dir = Path(os.path.expanduser(settings.IMAGE_SAVE_DIR))
    save_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"clip_{timestamp}.png"
    filepath = save_dir / filename

    if platform.system() == "Darwin":
        return _capture_macos(filepath)
    if platform.system() == "Linux":
        return _capture_linux(filepath)
    return _capture_windows(filepath)


_IMAGE_TYPES = ["image/png", "image/jpeg", "image/bmp", "image/gif", "image/webp"]


def _capture_linux(filepath: Path) -> str | None:
    """Capture clipboard image on Linux via wl-paste (Wayland) or xclip (X11)."""
    import os

    on_wayland = bool(os.environ.get("WAYLAND_DISPLAY"))

    if on_wayland:
        try:
            # Check which types are actually on the clipboard before trying to read.
            types_result = subprocess.run(
                ["wl-paste", "--list-types"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            available = types_result.stdout.splitlines() if types_result.returncode == 0 else []
            mime = next((t for t in _IMAGE_TYPES if t in available), None)
            if mime is None:
                logger.debug("No image in Wayland clipboard (types: %s)", available)
                return None

            result = subprocess.run(
                ["wl-paste", "--no-newline", "--type", mime],
                capture_output=True,
                timeout=5,
            )
            if result.returncode != 0 or not result.stdout:
                logger.debug("wl-paste returned nothing for type %s", mime)
                return None

            # Convert to PNG via Pillow if needed so we always save a .png.
            if mime == "image/png":
                filepath.write_bytes(result.stdout)
            else:
                import io

                from PIL import Image

                Image.open(io.BytesIO(result.stdout)).save(filepath, format="PNG")

            logger.info(f"Image saved: {filepath} ({filepath.stat().st_size / 1024:.0f} KB)")
            return str(filepath)
        except FileNotFoundError:
            logger.error("wl-paste not found — install wl-clipboard: sudo dnf install wl-clipboard")
            return None
        except Exception as e:
            logger.error(f"Image capture error (wl-paste): {e}")
            return None
    else:
        # X11: use xclip to read image/png from clipboard
        try:
            result = subprocess.run(
                ["xclip", "-selection", "clipboard", "-t", "image/png", "-o"],
                capture_output=True,
                timeout=5,
            )
            if result.returncode != 0 or not result.stdout:
                logger.debug("No image in X11 clipboard (xclip returned nothing)")
                return None
            filepath.write_bytes(result.stdout)
            logger.info(f"Image saved: {filepath} ({filepath.stat().st_size / 1024:.0f} KB)")
            return str(filepath)
        except FileNotFoundError:
            logger.error("xclip not found — install it: sudo apt install xclip")
            return None
        except Exception as e:
            logger.error(f"Image capture error (xclip): {e}")
            return None


def _capture_macos(filepath: Path) -> str | None:
    """Capture clipboard image on macOS via osascript + NSPasteboard."""
    # Escape filepath for AppleScript string literal (replace \ and " )
    safe_path = str(filepath).replace("\\", "\\\\").replace('"', '\\"')
    script = (
        'use framework "AppKit"\n'
        "set pb to current application's NSPasteboard's generalPasteboard()\n"
        "set imgTypes to {current application's NSPasteboardTypePNG, current application's NSPasteboardTypeTIFF}\n"
        "set bestType to pb's availableTypeFromArray:imgTypes\n"
        'if bestType is missing value then return "no_image"\n'
        "set imgData to pb's dataForType:bestType\n"
        "set img to current application's NSImage's alloc()'s initWithData:imgData\n"
        "set bmp to (img's TIFFRepresentation())\n"
        "set rep to current application's NSBitmapImageRep's imageRepWithData:bmp\n"
        "set pngData to (rep's representationUsingType:"
        "(current application's NSBitmapImageFileTypePNG) properties:(missing value))\n"
        f'pngData\'s writeToFile:"{safe_path}" atomically:true\n'
        'return "saved"'
    )

    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except FileNotFoundError:
        logger.error("osascript not found — image capture requires macOS")
        return None
    except subprocess.TimeoutExpired:
        logger.error("osascript timed out during image capture")
        return None
    except Exception as e:
        logger.error(f"Image capture error: {e}")
        return None

    output = result.stdout.strip()
    if output == "saved" and filepath.exists():
        logger.info(f"Image saved: {filepath} ({filepath.stat().st_size / 1024:.0f} KB)")
        return str(filepath)

    if output == "no_image":
        logger.debug("No image in clipboard")
    else:
        logger.warning(f"Unexpected osascript output: {output}")
        if result.stderr.strip():
            logger.warning(f"osascript stderr: {result.stderr.strip()}")

    return None


def _capture_windows(filepath: Path) -> str | None:
    """Capture clipboard image on Windows/WSL2 via PowerShell."""
    # Convert WSL path to Windows path for PowerShell
    try:
        win_path = subprocess.run(
            ["wslpath", "-w", str(filepath)],
            capture_output=True,
            text=True,
            timeout=5,
        ).stdout.strip()
    except FileNotFoundError:
        # Not running under WSL — try native Windows path
        win_path = str(filepath)
    except Exception as e:
        logger.error(f"Failed to convert path: {e}")
        return None

    if not win_path:
        logger.error("Empty Windows path from wslpath")
        return None

    # PowerShell: grab clipboard image, save as PNG
    ps_script = (
        "Add-Type -AssemblyName System.Windows.Forms;"
        "$img = [System.Windows.Forms.Clipboard]::GetImage();"
        "if ($img) {"
        f"  $img.Save('{win_path}', [System.Drawing.Imaging.ImageFormat]::Png);"
        "  Write-Output 'saved'"
        "} else {"
        "  Write-Output 'no_image'"
        "}"
    )

    # CREATE_NO_WINDOW prevents the PowerShell console from flashing
    creationflags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0

    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", ps_script],
            capture_output=True,
            text=True,
            timeout=10,
            creationflags=creationflags,
        )
    except FileNotFoundError:
        logger.error("powershell.exe not found — image capture requires Windows/WSL2")
        return None
    except subprocess.TimeoutExpired:
        logger.error("PowerShell timed out during image capture")
        return None
    except Exception as e:
        logger.error(f"Image capture error: {e}")
        return None

    output = result.stdout.strip().replace("\r", "")
    if output == "saved" and filepath.exists():
        logger.info(f"Image saved: {filepath} ({filepath.stat().st_size / 1024:.0f} KB)")
        return str(filepath)

    if output == "no_image":
        logger.debug("No image in clipboard")
    else:
        logger.warning(f"Unexpected PowerShell output: {output}")
        if result.stderr.strip():
            logger.warning(f"PowerShell stderr: {result.stderr.strip()}")

    return None


def cleanup_old_images(save_dir: str | None = None, retention_days: int | None = None) -> int:
    """Delete images older than retention_days from save_dir. Returns count deleted."""
    dir_path = Path(os.path.expanduser(save_dir or settings.IMAGE_SAVE_DIR))
    days = retention_days if retention_days is not None else settings.IMAGE_RETENTION_DAYS

    if not dir_path.exists() or days <= 0:
        return 0

    cutoff = datetime.now() - timedelta(days=days)
    deleted = 0

    try:
        for f in dir_path.glob("clip_*.png"):
            try:
                if datetime.fromtimestamp(f.stat().st_mtime) < cutoff:
                    f.unlink()
                    deleted += 1
            except OSError:
                pass
    except Exception as e:
        logger.warning(f"Image cleanup error: {e}")

    if deleted:
        logger.info(f"Cleaned up {deleted} old screenshot(s) from {dir_path}")
    return deleted
