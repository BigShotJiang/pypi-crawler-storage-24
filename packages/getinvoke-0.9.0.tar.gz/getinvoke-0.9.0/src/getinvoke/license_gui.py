"""License activation dialog — tkinter UI for entering license keys."""

from __future__ import annotations

import logging
import tkinter as tk
import webbrowser
from tkinter import ttk

logger = logging.getLogger(__name__)

PURCHASE_URL = "https://getinvoke.dev/download"


def show_activation_dialog(
    license_manager,
    message: str = "",
    allow_trial: bool = False,
    trial_days_left: int = 0,
) -> bool:
    """Show the activation dialog. Returns True if activated (or trial continued), False if quit."""
    dialog = ActivationDialog(
        license_manager,
        message=message,
        allow_trial=allow_trial,
        trial_days_left=trial_days_left,
    )
    dialog.mainloop()
    return dialog.activated


class ActivationDialog(tk.Tk):
    """License key activation window."""

    def __init__(
        self,
        license_manager,
        message: str = "",
        allow_trial: bool = False,
        trial_days_left: int = 0,
    ) -> None:
        super().__init__()
        self.license_manager = license_manager
        self.activated = False

        self.title("Activate Invoke")
        self.geometry("440x340")
        self.resizable(False, False)
        # Center on screen
        self.update_idletasks()
        x = (self.winfo_screenwidth() - 440) // 2
        y = (self.winfo_screenheight() - 340) // 2
        self.geometry(f"+{x}+{y}")

        # Apply Patina theme
        from getinvoke.theme import apply_theme

        apply_theme(self)

        container = ttk.Frame(self)
        container.pack(fill="both", expand=True, padx=32, pady=24)

        # Title
        ttk.Label(container, text="Activate Invoke", style="Title.TLabel").pack(anchor="w")

        if message:
            ttk.Label(container, text=message, style="Sub.TLabel", wraplength=380).pack(anchor="w", pady=(4, 12))
        else:
            ttk.Label(
                container,
                text="Enter your license key to activate Invoke.",
                style="Sub.TLabel",
            ).pack(anchor="w", pady=(4, 12))

        # License key entry
        ttk.Label(container, text="License Key:").pack(anchor="w", pady=(8, 4))
        self._key_var = tk.StringVar(master=self)
        self._key_entry = ttk.Entry(container, textvariable=self._key_var, width=48, show="*")
        self._key_entry.pack(anchor="w", fill="x")
        self._key_entry.focus_set()

        # Show/hide toggle
        self._show_key = tk.BooleanVar(master=self, value=False)

        def _toggle_visibility() -> None:
            self._key_entry.configure(show="" if self._show_key.get() else "*")

        ttk.Checkbutton(container, text="Show key", variable=self._show_key, command=_toggle_visibility).pack(
            anchor="w", pady=(4, 0)
        )

        # Status label (for errors/success)
        self._status_var = tk.StringVar(master=self)
        self._status_label = ttk.Label(container, textvariable=self._status_var, wraplength=380)
        self._status_label.pack(anchor="w", pady=(8, 0))

        # Buttons
        btn_frame = ttk.Frame(container)
        btn_frame.pack(fill="x", pady=(16, 0))

        self._activate_btn = ttk.Button(btn_frame, text="Activate", command=self._do_activate, style="Gold.TButton")
        self._activate_btn.pack(side="right")

        # Buy link
        buy_label = ttk.Label(btn_frame, text="Buy a license", style="Link.TLabel")
        buy_label.pack(side="left")
        buy_label.bind("<Button-1>", lambda e: webbrowser.open(PURCHASE_URL))

        # Trial button (if applicable)
        if allow_trial and trial_days_left > 0:
            ttk.Button(
                btn_frame,
                text=f"Continue trial ({trial_days_left} days left)",
                command=self._continue_trial,
            ).pack(side="right", padx=(0, 8))

        # Enter key activates
        self.bind("<Return>", lambda e: self._do_activate())

        # Handle window close as quit (not activated)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _do_activate(self) -> None:
        key = self._key_var.get().strip()
        if not key:
            self._status_var.set("Please enter a license key.")
            self._status_label.configure(style="Error.TLabel")
            return

        self._activate_btn.configure(state="disabled")
        self._status_var.set("Activating...")
        self._status_label.configure(style="Sub.TLabel")

        import threading

        def _run() -> None:
            success, message = self.license_manager.activate(key)
            self.after(0, lambda: self._on_activate_result(success, message))

        threading.Thread(target=_run, daemon=True).start()

    def _on_activate_result(self, success: bool, message: str) -> None:
        if success:
            self._status_var.set(message)
            self._status_label.configure(style="Success.TLabel")
            self.activated = True
            self.after(1000, self.destroy)
        else:
            self._status_var.set(message)
            self._status_label.configure(style="Error.TLabel")
            self._activate_btn.configure(state="normal")

    def _continue_trial(self) -> None:
        self.activated = True
        self.destroy()

    def _on_close(self) -> None:
        self.activated = False
        self.destroy()
