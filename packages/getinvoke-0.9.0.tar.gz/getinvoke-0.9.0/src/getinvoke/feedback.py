"""Audio feedback cues (beeps/chirps) with selectable sound presets."""

import logging
import platform
import threading

logger = logging.getLogger(__name__)

_IS_WINDOWS = platform.system() == "Windows"

# Sound presets — each maps event names to lists of (frequency_hz, duration_ms) tones.
# "default" matches the original hardcoded sounds.
SOUND_PRESETS = {
    "default": {
        "start": [(1200, 60)],
        "success": [(880, 80), (1320, 120)],
        "error": [(300, 150), (200, 250)],
    },
    "subtle": {
        "start": [(800, 40)],
        "success": [(600, 60), (900, 80)],
        "error": [(250, 100)],
    },
    "arcade": {
        "start": [(1600, 50)],
        "success": [(523, 60), (659, 60), (784, 60), (1047, 100)],
        "error": [(440, 100), (349, 100), (261, 200)],
    },
    "minimal": {
        "start": [(1000, 30)],
        "success": [(1000, 30)],
        "error": [(400, 80)],
    },
}


def _beep(freq: int, duration_ms: int) -> None:
    """Play a beep at given frequency and duration."""
    if _IS_WINDOWS:
        import winsound

        winsound.Beep(freq, duration_ms)
    else:
        try:
            import numpy as np
            import sounddevice as sd

            t = np.linspace(0, duration_ms / 1000, int(16000 * duration_ms / 1000), endpoint=False)
            wave = (np.sin(2 * np.pi * freq * t) * 0.3 * 32767).astype(np.int16)
            sd.play(wave, samplerate=16000, blocking=True)
        except Exception:
            pass  # Silent fallback on non-Windows without audio


def _play_sound(event: str) -> None:
    """Play the tones for an event using the active sound preset."""
    from getinvoke.config import settings

    preset = SOUND_PRESETS.get(settings.SOUND_PRESET, SOUND_PRESETS["default"])
    tones = preset.get(event, [])
    if not tones:
        return

    def _play() -> None:
        for freq, dur in tones:
            _beep(freq, dur)

    threading.Thread(target=_play, daemon=True).start()


def play_start_beep() -> None:
    """Short high tick — recording started."""
    _play_sound("start")


def play_stop_beep() -> None:
    """Silent — no sound needed on release."""
    pass


def play_success_chirp() -> None:
    """Rising two-tone chirp — done, clipboard ready."""
    _play_sound("success")


def play_error_buzz() -> None:
    """Low descending buzz — error."""
    _play_sound("error")


def preview_preset(preset_name: str) -> None:
    """Play start → success → error sequence for a preset (for settings preview)."""
    preset = SOUND_PRESETS.get(preset_name, SOUND_PRESETS["default"])

    def _play() -> None:
        import time

        for event in ("start", "success", "error"):
            tones = preset.get(event, [])
            for freq, dur in tones:
                _beep(freq, dur)
            time.sleep(0.3)

    threading.Thread(target=_play, daemon=True).start()
