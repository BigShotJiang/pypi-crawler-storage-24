"""Click CLI: run, devices, install, health, transcribe, modes, history, config, license."""

import logging
import platform
import sys
from pathlib import Path

import click


def _gui_available() -> bool:
    """Check if GUI dependencies (pystray, Pillow, tkinter) are installed."""
    try:
        import tkinter  # noqa: F401

        import PIL  # noqa: F401
        import pystray  # noqa: F401

        return True
    except ImportError:
        return False


@click.group(invoke_without_command=True)
@click.pass_context
def main(ctx: click.Context) -> None:
    """Dictate — Voice-to-prompt for developers."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(run)


@main.command()
@click.option("--headless", is_flag=True, help="Force headless mode (no GUI)")
@click.option("--no-beep", is_flag=True, help="Disable audio feedback beeps")
def run(headless: bool, no_beep: bool) -> None:
    """Start Invoke (default command)."""
    from getinvoke.config import settings

    if no_beep:
        settings.BEEP_ENABLED = False

    is_frozen = getattr(sys, "_MEIPASS", None) is not None

    if headless:
        from getinvoke.engine import InvokeEngine
        from getinvoke.terminal import TerminalFrontend

        frontend = TerminalFrontend()
        engine = InvokeEngine(frontend)
        engine.run()
    elif is_frozen or _gui_available():
        from getinvoke.app import InvokeApp

        app = InvokeApp()
        app.run()
    else:
        from getinvoke.engine import InvokeEngine
        from getinvoke.terminal import TerminalFrontend

        frontend = TerminalFrontend()
        engine = InvokeEngine(frontend)
        engine.run()


@main.command()
def devices() -> None:
    """List available audio input devices."""
    from rich.console import Console
    from rich.table import Table

    from getinvoke.recorder import list_devices

    console = Console()
    devs = list_devices()
    if not devs:
        console.print("[yellow]No audio input devices found.[/yellow]")
        return

    table = Table(title=f"Audio Input Devices ({len(devs)} found)")
    table.add_column("Index", style="cyan", justify="right")
    table.add_column("Name", style="white")
    table.add_column("Channels", style="dim", justify="right")

    for dev in devs:
        table.add_row(str(dev["index"]), dev["name"], f"{dev['channels']}ch")

    console.print(table)


@main.command()
def modes() -> None:
    """List available target modes."""
    from rich.console import Console
    from rich.table import Table

    from getinvoke.config import settings
    from getinvoke.modes import list_modes

    console = Console()
    table = Table(title="Available Modes")
    table.add_column("Mode", style="cyan")
    table.add_column("Description", style="white")
    table.add_column("Active", style="green", justify="center")

    for mode in list_modes():
        active = "*" if mode.name == settings.MODE else ""
        table.add_row(mode.name, mode.description, active)

    console.print(table)


@main.command()
@click.option("-n", "--limit", default=10, help="Number of entries to show")
@click.option("-s", "--search", "query", default=None, help="Search history")
def history(limit: int, query: str | None) -> None:
    """View dictation history."""
    from rich.console import Console
    from rich.table import Table

    from getinvoke import history as hist

    console = Console()
    hist.init_db()

    if query:
        entries = hist.search(query, limit=limit)
        title = f"Search results for '{query}'"
    else:
        entries = hist.get_recent(limit=limit)
        total = hist.count()
        title = f"Recent Dictations ({total} total)"

    if not entries:
        console.print(f"[dim]{title}[/dim]")
        console.print("  No entries found.")
        hist.close_db()
        return

    table = Table(title=title)
    table.add_column("Time", style="dim")
    table.add_column("Mode", style="cyan")
    table.add_column("Duration", style="yellow", justify="right")
    table.add_column("Raw", style="white", max_width=40)
    table.add_column("Output", style="bold white", max_width=50)

    for entry in entries:
        ts = entry["timestamp"][:19]
        mode = entry["mode"]
        raw = entry["raw_text"][:40]
        reformatted = entry["reformatted"][:50]
        duration = f"{entry['duration_ms']}ms" if entry["duration_ms"] else "?"
        table.add_row(ts, mode, duration, raw, reformatted)

    console.print(table)
    hist.close_db()


@main.command()
def health() -> None:
    """Check system health: GPU, model, API key, audio devices."""
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text

    from getinvoke.config import settings
    from getinvoke.recorder import list_devices

    console = Console()
    output = Text()

    # Python version
    output.append("System\n", style="bold")
    output.append(f"  Python: {sys.version.split()[0]}\n")
    output.append(f"  Platform: {platform.system()} {platform.release()}\n")

    # GPU detection
    output.append("\nTranscription\n", style="bold")
    output.append(f"  Whisper device: {settings.WHISPER_DEVICE}\n")
    output.append(f"  Whisper model: {settings.WHISPER_MODEL}\n")
    output.append(f"  Compute type: {settings.whisper_compute_type}\n")

    if settings.WHISPER_DEVICE == "mlx":
        output.append("  GPU: ", style="dim")
        output.append("Apple Silicon (MLX)\n", style="green")
        try:
            import mlx_whisper  # noqa: F401

            output.append("  mlx-whisper: ", style="dim")
            output.append("installed\n", style="green")
        except ImportError:
            output.append("  mlx-whisper: ", style="dim")
            output.append("NOT INSTALLED\n", style="red")
    else:
        try:
            from faster_whisper import WhisperModel  # noqa: F401

            output.append("  faster-whisper: ", style="dim")
            output.append("installed\n", style="green")
        except ImportError:
            output.append("  faster-whisper: ", style="dim")
            output.append("NOT INSTALLED\n", style="red")

        # CUDA check
        try:
            import ctranslate2

            cuda_types = ctranslate2.get_supported_compute_types("cuda")
            output.append(f"  CUDA compute types: {', '.join(cuda_types)}\n")

            if settings.WHISPER_DEVICE == "cuda":
                try:
                    import numpy as np

                    ctranslate2.StorageView.from_array(np.zeros(10, dtype=np.float32), "cuda")
                    output.append("  CUDA runtime: ", style="dim")
                    output.append("working\n", style="green")
                except RuntimeError as e:
                    output.append("  CUDA runtime: ", style="dim")
                    output.append(f"BROKEN — {e}\n", style="red")
        except Exception:
            output.append("  CUDA: ", style="dim")
            output.append("not available (will use CPU)\n", style="yellow")

    # Reformatter backend
    output.append("\nReformatter\n", style="bold")
    output.append(f"  Backend: {settings.REFORMATTER_BACKEND}\n")
    if settings.REFORMATTER_BACKEND == "openrouter":
        has_key = bool(settings.OPENROUTER_API_KEY)
        key_style = "green" if has_key else "red"
        output.append("  API key: ", style="dim")
        output.append(f"{'set' if has_key else 'NOT SET'}\n", style=key_style)
        output.append(f"  Model: {settings.DICTATION_MODEL}\n")
    elif settings.REFORMATTER_BACKEND == "claude-cli":
        output.append(f"  CLI path: {settings.CLAUDE_CLI_PATH}\n")
        output.append(f"  Model: {settings.CLAUDE_CLI_MODEL}\n")
    elif settings.REFORMATTER_BACKEND == "ollama":
        output.append(f"  URL: {settings.OLLAMA_URL}\n")
        output.append(f"  Model: {settings.OLLAMA_MODEL}\n")
        try:
            import httpx

            r = httpx.get(f"{settings.OLLAMA_URL}/api/tags", timeout=3.0)
            models = [m["name"] for m in r.json().get("models", [])]
            output.append(f"  Available: {', '.join(models[:5]) or 'none'}\n")
        except Exception:
            output.append("  Status: ", style="dim")
            output.append("NOT REACHABLE\n", style="red")

    # Mode + vocab
    output.append(f"\nMode: {settings.MODE}\n", style="bold")
    if settings.hotwords:
        output.append(f"  Custom vocabulary: {', '.join(settings.hotwords)}\n", style="dim")

    # Audio devices
    output.append("\nAudio\n", style="bold")
    output.append(f"  Configured device: {settings.AUDIO_DEVICE or 'default'}\n")
    devs = list_devices()
    output.append(f"  Available inputs: {len(devs)}\n")
    for dev in devs[:5]:
        output.append(f"    [{dev['index']}] {dev['name']}\n", style="dim")

    # Hotkey + paste
    output.append(f"\n  Hotkey: {settings.HOTKEY}\n")
    output.append(f"  Auto-paste: {'on' if settings.AUTO_PASTE else 'off'}\n")
    output.append(f"  Audio beeps: {'on' if settings.BEEP_ENABLED else 'off'}\n")

    # History
    output.append("\nHistory\n", style="bold")
    output.append(f"  Enabled: {'yes' if settings.HISTORY_ENABLED else 'no'}\n")
    if settings.HISTORY_ENABLED:
        output.append(f"  Retention: {settings.HISTORY_RETENTION_DAYS} days\n", style="dim")
        output.append(f"  Database: {settings.db_path}\n", style="dim")

    # Config + logs
    output.append("\nPaths\n", style="bold")
    log_file = settings.log_dir / "invoke.log"
    output.append(f"  Config: {settings.config_file}")
    output.append(f" ({'exists' if settings.config_file.exists() else 'not created'})\n", style="dim")
    output.append(f"  Log: {log_file}")
    output.append(f" ({'exists' if log_file.exists() else 'not yet created'})\n", style="dim")

    # GUI availability
    output.append("\nGUI\n", style="bold")
    if _gui_available():
        output.append("  GUI dependencies: ", style="dim")
        output.append("available\n", style="green")
    else:
        output.append("  GUI dependencies: ", style="dim")
        output.append("not installed (headless only)\n", style="yellow")
        output.append("  Install with: pip install getinvoke[gui]\n", style="dim")

    # Wayland + mouse hotkey check
    import os as _os

    _wayland = platform.system() == "Linux" and bool(_os.environ.get("WAYLAND_DISPLAY"))
    _mouse_hotkey = settings.HOTKEY.startswith("mouse") or settings.HOTKEY in ("left", "right", "middle")
    if _wayland and _mouse_hotkey:
        output.append("\nWayland\n", style="bold")
        try:
            import evdev  # noqa: F401
            import evdev as _evdev

            devices = _evdev.list_devices()
            if devices:
                output.append("  evdev: ", style="dim")
                output.append("installed, devices readable\n", style="green")
            else:
                output.append("  evdev: ", style="dim")
                output.append("installed but no devices readable\n", style="red")
                output.append("  Fix: sudo usermod -a -G input $USER  (then reboot)\n", style="dim")
        except ImportError:
            output.append("  evdev: ", style="dim")
            output.append("NOT INSTALLED — mouse hotkeys won't work on Wayland\n", style="red")
            output.append("  Fix: pip install getinvoke[wayland]\n", style="dim")
            output.append("       sudo usermod -a -G input $USER  (then reboot)\n", style="dim")

    console.print(Panel(output, title="Invoke Health Check", border_style="cyan"))


@main.command()
@click.option("--cli", "use_cli", is_flag=True, help="Force CLI wizard (no GUI)")
def setup(use_cli: bool) -> None:
    """Run the first-run setup wizard (can be re-run anytime)."""
    from getinvoke.config import settings

    if use_cli or not _gui_available():
        from getinvoke.setup_cli import run_cli_wizard

        run_cli_wizard()
    else:
        from getinvoke.wizard import run_wizard

        run_wizard()

    # Reload settings from the newly saved config
    settings.__init__()
    click.echo("Setup complete! Restart Invoke to apply changes.")


@main.command()
@click.argument("key", required=False)
@click.argument("value", required=False)
def config(key: str | None, value: str | None) -> None:
    """View or set configuration values.

    \b
    Examples:
      dictate config              # Show all settings
      dictate config mode         # Show current mode
      dictate config mode cursor  # Set mode to cursor
    """
    from rich.console import Console
    from rich.table import Table

    from getinvoke.config import settings

    console = Console()

    # Settable config keys mapped to Settings attributes
    config_map = {
        "mode": "MODE",
        "hotkey": "HOTKEY",
        "reformatter_backend": "REFORMATTER_BACKEND",
        "whisper_model": "WHISPER_MODEL",
        "whisper_device": "WHISPER_DEVICE",
        "auto_paste": "AUTO_PASTE",
        "audio_device": "AUDIO_DEVICE",
        "openrouter_api_key": "OPENROUTER_API_KEY",
        "dictation_model": "DICTATION_MODEL",
        "claude_cli_path": "CLAUDE_CLI_PATH",
        "claude_cli_model": "CLAUDE_CLI_MODEL",
        "local_llm_provider": "LOCAL_LLM_PROVIDER",
        "ollama_url": "OLLAMA_URL",
        "ollama_model": "OLLAMA_MODEL",
        "lmstudio_url": "LMSTUDIO_URL",
        "lmstudio_model": "LMSTUDIO_MODEL",
        "custom_vocab": "CUSTOM_VOCAB",
        "language": "LANGUAGE",
        "log_level": "LOG_LEVEL",
        "history_enabled": "HISTORY_ENABLED",
        "history_retention_days": "HISTORY_RETENTION_DAYS",
        "beep_enabled": "BEEP_ENABLED",
        "sound_preset": "SOUND_PRESET",
        "image_capture_enabled": "IMAGE_CAPTURE_ENABLED",
        "image_hotkey": "IMAGE_HOTKEY",
        "image_save_dir": "IMAGE_SAVE_DIR",
        "image_retention_days": "IMAGE_RETENTION_DAYS",
        "project_dir": "PROJECT_DIR",
        "privacy_mode": "PRIVACY_MODE",
    }

    if key is None:
        # Show all settings
        table = Table(title="Configuration")
        table.add_column("Key", style="cyan")
        table.add_column("Value", style="white")

        for config_key, attr in config_map.items():
            val = getattr(settings, attr, "")
            # Mask API keys
            if "key" in config_key.lower() and val:
                display = val[:8] + "..." if len(str(val)) > 8 else "***"
            else:
                display = str(val) if val is not None else ""
            table.add_row(config_key, display)

        console.print(table)
        console.print(f"\n[dim]Config file: {settings.config_file}[/dim]")
        return

    if key not in config_map:
        console.print(f"[red]Unknown config key: {key}[/red]")
        console.print(f"[dim]Available keys: {', '.join(sorted(config_map.keys()))}[/dim]")
        return

    if value is None:
        # Show single value
        val = getattr(settings, config_map[key], "")
        console.print(f"  {key} = {val}")
        return

    # Set value
    attr = config_map[key]
    current = getattr(settings, attr, "")

    # Type coercion
    if isinstance(current, bool):
        value = value.lower() in ("true", "1", "yes")
    elif isinstance(current, int):
        try:
            value = int(value)
        except ValueError:
            console.print(f"[red]Invalid integer: {value}[/red]")
            return

    setattr(settings, attr, value)
    settings.save()
    console.print(f"  [green]{key}[/green] = {value}")


@main.command()
@click.argument("action", type=click.Choice(["activate", "status", "deactivate"]))
@click.argument("key", required=False)
def license(action: str, key: str | None) -> None:
    """Manage license activation.

    \b
    Commands:
      dictate license status                # Show license status
      dictate license activate <key>        # Activate with license key
      dictate license deactivate            # Deactivate current license
    """
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text

    from getinvoke.license import LicenseManager, LicenseStatus

    console = Console()
    lm = LicenseManager()

    if action == "status":
        status = lm.check()
        output = Text()
        output.append("License Status\n\n", style="bold")

        status_colors = {
            LicenseStatus.ACTIVE: "green",
            LicenseStatus.TRIAL: "yellow",
            LicenseStatus.GRACE: "yellow",
            LicenseStatus.EXPIRED_TRIAL: "red",
            LicenseStatus.INVALID: "red",
        }
        color = status_colors.get(status, "white")
        output.append("  Status: ", style="dim")
        output.append(f"{status.value}\n", style=color)

        if status == LicenseStatus.TRIAL:
            output.append(f"  Trial days remaining: {lm.trial_days_left}\n")
        if status == LicenseStatus.ACTIVE:
            output.append(f"  Updates eligible: {'yes' if lm.updates_eligible else 'no'}\n")

        console.print(Panel(output, border_style="cyan"))

    elif action == "activate":
        if not key:
            key = click.prompt("License key")
        success, msg = lm.activate(key)
        if success:
            console.print(f"[green]{msg}[/green]")
        else:
            console.print(f"[red]{msg}[/red]")

    elif action == "deactivate":
        if not click.confirm("Deactivate your license?"):
            return
        success, msg = lm.deactivate()
        if success:
            console.print(f"[green]{msg}[/green]")
        else:
            console.print(f"[red]{msg}[/red]")


@main.command()
def install() -> None:
    """Create Windows Startup folder shortcut for auto-launch."""
    if platform.system() != "Windows":
        click.echo("Install command is Windows-only. Use your platform's autostart mechanism.")
        return

    import os

    startup_dir = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    if not startup_dir.exists():
        click.echo(f"Startup folder not found: {startup_dir}")
        return

    bat_path = startup_dir / "dictate.bat"
    pythonw = Path(sys.executable).parent / "pythonw.exe"
    if pythonw.exists():
        bat_content = f'@echo off\nstart "" "{pythonw}" -m getinvoke run\n'
    else:
        bat_content = f'@echo off\nstart /min "" "{sys.executable}" -m getinvoke run\n'
    bat_path.write_text(bat_content)
    click.echo(f"Startup shortcut created: {bat_path}")


@main.command()
@click.option("-n", "--lines", default=50, help="Number of lines to show")
@click.option("-f", "--follow", is_flag=True, help="Follow log output (like tail -f)")
def logs(lines: int, follow: bool) -> None:
    """View Invoke log file."""
    from getinvoke.config import settings

    log_file = settings.log_dir / "invoke.log"
    if not log_file.exists():
        click.echo(f"No log file found at {log_file}")
        click.echo("Run 'dictate run' first to generate logs.")
        return

    click.echo(f"Log file: {log_file}\n")

    with open(log_file, encoding="utf-8") as f:
        all_lines = f.readlines()
    for line in all_lines[-lines:]:
        click.echo(line, nl=False)

    if follow:
        import time

        click.echo("\n--- Following log (Ctrl+C to stop) ---\n")
        with open(log_file, encoding="utf-8") as f:
            f.seek(0, 2)
            try:
                while True:
                    line = f.readline()
                    if line:
                        click.echo(line, nl=False)
                    else:
                        time.sleep(0.5)
            except KeyboardInterrupt:
                pass


@main.command()
@click.argument("wav_file", type=click.Path(exists=True))
def transcribe(wav_file: str) -> None:
    """One-shot transcription of a WAV file (for debugging)."""
    from getinvoke.transcriber import load_model
    from getinvoke.transcriber import transcribe as do_transcribe

    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    click.echo("Loading Whisper model...")
    load_model()

    click.echo(f"Transcribing: {wav_file}")
    text = do_transcribe(wav_file)
    click.echo(f"\nResult:\n{text}")


if __name__ == "__main__":
    main()
