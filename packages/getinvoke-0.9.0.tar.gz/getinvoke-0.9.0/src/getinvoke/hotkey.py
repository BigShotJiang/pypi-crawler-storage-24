"""Global hotkey listener via pynput."""

import logging
import os
import platform
import select
import threading
from collections.abc import Callable

from pynput import keyboard, mouse

logger = logging.getLogger(__name__)

# On Wayland, pynput's Xlib record extension only receives mouse events when an
# X11 window has pointer focus — useless for a global hotkey. Use evdev instead,
# which reads directly from /dev/input and works regardless of compositor focus.
_ON_WAYLAND = platform.system() == "Linux" and bool(os.environ.get("WAYLAND_DISPLAY"))

# evdev button codes corresponding to each config name.
# Requires the user to be in the 'input' group (or have a udev rule).
_EVDEV_CODES: dict[str, int] | None = None


def _get_evdev_codes() -> dict[str, int] | None:
    """Return evdev button-code map, or None if evdev is not installed."""
    global _EVDEV_CODES
    if _EVDEV_CODES is not None:
        return _EVDEV_CODES
    try:
        from evdev import ecodes  # type: ignore[import-untyped]

        _EVDEV_CODES = {
            "left": ecodes.BTN_LEFT,
            "right": ecodes.BTN_RIGHT,
            "middle": ecodes.BTN_MIDDLE,
            "mouse4": ecodes.BTN_SIDE,
            "mouse5": ecodes.BTN_EXTRA,
        }
        return _EVDEV_CODES
    except ImportError:
        return None


# Map config strings to pynput buttons.
# mouse.Button.x1/x2 exist on Windows; on Linux/macOS pynput 1.8+ uses
# named members button8/button9 (X11 button numbers 8 and 9).
MOUSE_BUTTON_MAP: dict[str, mouse.Button] = {
    "left": mouse.Button.left,
    "right": mouse.Button.right,
    "middle": mouse.Button.middle,
}
# Windows side buttons (x1/x2)
if getattr(mouse.Button, "x1", None):
    MOUSE_BUTTON_MAP["mouse4"] = mouse.Button.x1
if getattr(mouse.Button, "x2", None):
    MOUSE_BUTTON_MAP["mouse5"] = mouse.Button.x2

# Linux/macOS: side buttons are X11 button numbers 8 (back) and 9 (forward).
# pynput 1.8+ exposes these as Button.button8 / Button.button9.
for _name, _num in (("mouse4", 8), ("mouse5", 9)):
    if _name not in MOUSE_BUTTON_MAP:
        try:
            MOUSE_BUTTON_MAP[_name] = mouse.Button(_num)
        except ValueError:
            logger.debug("pynput: mouse button %d not available on this platform", _num)


# Modifier key names for formatting captured hotkeys
_MODIFIER_NAMES = {
    keyboard.Key.ctrl_l: "ctrl",
    keyboard.Key.ctrl_r: "ctrl",
    keyboard.Key.shift_l: "shift",
    keyboard.Key.shift_r: "shift",
    keyboard.Key.alt_l: "alt",
    keyboard.Key.alt_r: "alt",
    keyboard.Key.cmd_l: "cmd",
    keyboard.Key.cmd_r: "cmd",
}

# Canonical modifier order for display
_MODIFIER_ORDER = ["ctrl", "shift", "alt", "cmd", "super"]


def format_key_combo(keys: set) -> str:
    """Convert a set of pynput key objects to a hotkey string like 'ctrl+shift+d'."""
    modifiers = []
    regular = []
    for key in keys:
        if key in _MODIFIER_NAMES:
            mod = _MODIFIER_NAMES[key]
            if mod not in modifiers:
                modifiers.append(mod)
        elif isinstance(key, keyboard.Key):
            name = key.name.lower()
            if name in ("ctrl_l", "ctrl_r", "shift_l", "shift_r", "alt_l", "alt_r", "cmd_l", "cmd_r"):
                mod = name.rsplit("_", 1)[0]
                if mod not in modifiers:
                    modifiers.append(mod)
            else:
                regular.append(name)
        elif isinstance(key, keyboard.KeyCode) and key.char:
            regular.append(key.char.lower())
        elif isinstance(key, keyboard.KeyCode) and key.vk:
            regular.append(f"<{key.vk}>")

    # Sort modifiers in canonical order
    modifiers.sort(key=lambda m: _MODIFIER_ORDER.index(m) if m in _MODIFIER_ORDER else 99)
    return "+".join(modifiers + regular)


class HotkeyListener:
    """Listens for push-to-talk hotkey events."""

    def __init__(
        self,
        hotkey: str,
        on_press: Callable[[], None],
        on_release: Callable[[], None],
    ) -> None:
        self._hotkey = hotkey.lower()
        self._on_press = on_press
        self._on_release = on_release
        self._listener: mouse.Listener | keyboard.Listener | None = None
        self._stop_event = threading.Event()
        self._pressed = False

    def start(self) -> None:
        """Start listening in a background thread."""
        if self._hotkey in MOUSE_BUTTON_MAP:
            self._start_mouse_listener()
        else:
            self._start_keyboard_listener()

    def stop(self) -> None:
        """Stop the listener."""
        self._stop_event.set()
        if self._listener is not None:
            self._listener.stop()
            self._listener = None

    def _fire_press(self) -> None:
        if not self._pressed:
            self._pressed = True
            logger.debug("Hotkey pressed: %s", self._hotkey)
            try:
                self._on_press()
            except Exception:
                logger.error("Error in hotkey press callback", exc_info=True)
                self._pressed = False

    def _fire_release(self) -> None:
        if self._pressed:
            self._pressed = False
            logger.debug("Hotkey released: %s", self._hotkey)
            try:
                self._on_release()
            except Exception:
                logger.error("Error in hotkey release callback", exc_info=True)

    def _start_mouse_listener(self) -> None:
        # On Wayland, pynput's Xlib record only fires when an X11 window has
        # pointer focus. Use evdev for reliable global capture instead.
        if _ON_WAYLAND:
            codes = _get_evdev_codes()
            if codes is not None and self._hotkey in codes:
                self._start_evdev_listener(codes[self._hotkey])
                return
            else:
                logger.warning(
                    "Wayland detected but evdev is not installed — mouse hotkey will "
                    "only work when an X11 window has focus. "
                    "Fix: pip install getinvoke[wayland] && sudo usermod -a -G input $USER (then reboot)"
                )
        self._start_pynput_mouse_listener()

    def _start_pynput_mouse_listener(self) -> None:
        target_button = MOUSE_BUTTON_MAP[self._hotkey]

        def on_click(x: int, y: int, button: mouse.Button, pressed: bool) -> None:
            try:
                if button != target_button:
                    return
            except (NotImplementedError, ValueError):
                # pynput can't convert some exotic mouse events on Windows
                return
            if pressed:
                self._fire_press()
            else:
                self._fire_release()

        class _ResilientMouseListener(mouse.Listener):
            """Mouse listener that survives pynput internal errors.

            pynput throws NotImplementedError for exotic mouse buttons
            (DPI switches, macro keys on gaming mice). The default Listener
            treats any unhandled exception as fatal and kills the thread.
            """

            def _handle(self, *args, **kwargs):  # type: ignore[no-untyped-def]
                try:
                    return super()._handle(*args, **kwargs)
                except (NotImplementedError, ValueError):
                    pass  # Exotic button — ignore

        self._listener = _ResilientMouseListener(on_click=on_click)
        self._listener.daemon = True
        self._listener.start()
        logger.info("Mouse hotkey listener started: %s (pynput/Xlib)", self._hotkey)

    def _start_evdev_listener(self, target_code: int) -> None:
        import evdev  # type: ignore[import-untyped]

        # Find all input devices that report the target button.
        try:
            all_paths = evdev.list_devices()
        except Exception:
            logger.error("evdev: failed to list devices — check /dev/input permissions", exc_info=True)
            return

        mice: list[evdev.InputDevice] = []
        for path in all_paths:
            try:
                dev = evdev.InputDevice(path)
                caps = dev.capabilities()
                has_button = target_code in caps.get(evdev.ecodes.EV_KEY, [])
                # Only include pointer/mouse devices — skip keyboards, gamepads, etc.
                # EV_REL with REL_X means the device moves a pointer (i.e. it's a mouse).
                is_pointer = evdev.ecodes.REL_X in caps.get(evdev.ecodes.EV_REL, [])
                if has_button and is_pointer:
                    mice.append(dev)
                else:
                    dev.close()
            except (PermissionError, OSError):
                pass

        if not mice:
            logger.error(
                "evdev: no device found with button code %d for '%s'. "
                "Add yourself to the input group: sudo usermod -a -G input $USER (then reboot)",
                target_code,
                self._hotkey,
            )
            return

        stop_event = self._stop_event

        def _run() -> None:
            try:
                while not stop_event.is_set():
                    try:
                        ready, _, _ = select.select(mice, [], [], 0.5)
                    except (ValueError, OSError):
                        break
                    for dev in ready:
                        try:
                            for event in dev.read():
                                if event.type != evdev.ecodes.EV_KEY or event.code != target_code:
                                    continue
                                if event.value == 1:  # key down
                                    self._fire_press()
                                elif event.value == 0:  # key up
                                    self._fire_release()
                        except OSError:
                            pass
            finally:
                for dev in mice:
                    try:
                        dev.close()
                    except OSError:
                        pass

        t = threading.Thread(target=_run, daemon=True)
        t.start()
        logger.info("Mouse hotkey listener started: %s (evdev, %d device(s))", self._hotkey, len(mice))

    @staticmethod
    def _parse_keyboard_combo(hotkey: str) -> set | None:
        """Parse a hotkey string into a set of pynput keys."""
        # Method 1: pynput's HotKey.parse with angle bracket notation
        try:
            if "+" not in hotkey:
                hotkey_str = f"<{hotkey}>"
            else:
                parts = []
                for part in hotkey.split("+"):
                    p = part.strip()
                    if p in ("ctrl", "shift", "alt", "cmd", "super"):
                        parts.append(f"<{p}>")
                    else:
                        parts.append(p)
                hotkey_str = "+".join(parts)
            return set(keyboard.HotKey.parse(hotkey_str))
        except (ValueError, AttributeError):
            pass

        # Method 2: Manual key mapping (fallback for pynput compat issues)
        try:
            _key_map = {
                "ctrl": keyboard.Key.ctrl_l,
                "shift": keyboard.Key.shift,
                "alt": keyboard.Key.alt_l,
                "cmd": keyboard.Key.cmd,
                "super": keyboard.Key.cmd,
            }
            keys = set()
            for part in hotkey.split("+"):
                p = part.strip().lower()
                if p in _key_map:
                    keys.add(_key_map[p])
                elif len(p) == 1:
                    keys.add(keyboard.KeyCode.from_char(p))
                else:
                    key_attr = getattr(keyboard.Key, p, None)
                    if key_attr:
                        keys.add(key_attr)
                    else:
                        return None
            return keys if keys else None
        except Exception:
            return None

    def _start_keyboard_listener(self) -> None:
        # Parse keyboard combo (e.g. "ctrl+shift+d" -> set of pynput Key/KeyCode)
        combo_keys = self._parse_keyboard_combo(self._hotkey)

        if combo_keys is None:
            logger.error(f"Could not parse keyboard hotkey: {self._hotkey}")
            return

        # Track which combo keys are currently held — bypass pynput HotKey
        # state machine which adds 1-2s latency on Linux
        held_keys: set = set()

        def on_key_press(key: keyboard.Key | keyboard.KeyCode) -> None:
            canonical = self._listener.canonical(key)
            if canonical in combo_keys:
                held_keys.add(canonical)
            # Fire immediately when all combo keys are held
            if not self._pressed and held_keys >= combo_keys:
                self._fire_press()

        def on_key_release(key: keyboard.Key | keyboard.KeyCode) -> None:
            canonical = self._listener.canonical(key)
            if canonical in combo_keys:
                held_keys.discard(canonical)
            # Release when any combo key is lifted while recording
            if self._pressed and not (held_keys >= combo_keys):
                self._fire_release()

        self._listener = keyboard.Listener(on_press=on_key_press, on_release=on_key_release)
        self._listener.daemon = True
        self._listener.start()
        logger.info(f"Keyboard hotkey listener started: {self._hotkey}")
