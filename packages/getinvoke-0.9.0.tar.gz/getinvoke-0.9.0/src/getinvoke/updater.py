"""Auto-updater — checks GitHub releases, downloads with integrity checks, and applies on exit."""

from __future__ import annotations

import hashlib
import logging
import platform
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import httpx

from getinvoke import __version__
from getinvoke.config import settings

logger = logging.getLogger(__name__)

GITHUB_REPO = "zmroth/invoke"
_RELEASES_URL = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"

# Only trust downloads from these domains
_TRUSTED_DOWNLOAD_DOMAINS = (
    "https://github.com/",
    "https://objects.githubusercontent.com/",
)

# Module-level state
pending_update: Path | None = None


def is_pip_installed() -> bool:
    """Check if running from a pip install (vs PyInstaller bundle)."""
    return not getattr(sys, "_MEIPASS", None)


@dataclass
class UpdateInfo:
    version: str
    download_url: str
    asset_name: str
    sha256_expected: str | None = None


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse version string like '0.2.0' or 'v0.2.0' into comparable tuple."""
    v = v.lstrip("v")
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0,)


def check_for_update() -> UpdateInfo | None:
    """Check GitHub releases for a newer version. Returns None if up-to-date."""
    try:
        response = httpx.get(
            _RELEASES_URL,
            headers={"Accept": "application/vnd.github+json"},
            timeout=10.0,
        )
        if response.status_code == 403:
            logger.debug("GitHub API rate limited, skipping update check")
            return None
        response.raise_for_status()
        data = response.json()
    except httpx.TimeoutException:
        logger.debug("Update check timed out")
        return None
    except httpx.ConnectError:
        logger.debug("No internet connection for update check")
        return None
    except Exception as e:
        logger.debug(f"Update check failed: {e}")
        return None

    tag = data.get("tag_name", "")
    if not tag:
        return None

    remote_version = _parse_version(tag)
    local_version = _parse_version(__version__)

    if remote_version <= local_version:
        logger.debug(f"Up to date (local={__version__}, remote={tag})")
        return None

    # Look for SHA256 hash in release body (format: "SHA256: <hash> invoke-setup-*.exe")
    sha256_expected = None
    body = data.get("body", "") or ""
    for line in body.splitlines():
        if line.strip().upper().startswith("SHA256:"):
            parts = line.strip().split()
            if len(parts) >= 2 and len(parts[1]) == 64:
                sha256_expected = parts[1].lower()
                break

    # For pip installs, just report the available version (no .exe download)
    if is_pip_installed():
        logger.info(f"Update available: {tag} (current: v{__version__}). Run: pip install --upgrade getinvoke")
        return UpdateInfo(
            version=tag.lstrip("v"),
            download_url="",
            asset_name="",
            sha256_expected=sha256_expected,
        )

    # Find the installer asset (PyInstaller builds only)
    for asset in data.get("assets", []):
        name = asset.get("name", "")
        if name.startswith("invoke-setup-") and name.endswith(".exe"):
            download_url = asset["browser_download_url"]

            # Validate download URL is from a trusted domain
            if not download_url.startswith(_TRUSTED_DOWNLOAD_DOMAINS):
                logger.warning(f"Update download URL from untrusted domain, skipping: {download_url}")
                return None

            logger.info(f"Update available: {tag} (current: v{__version__})")
            return UpdateInfo(
                version=tag.lstrip("v"),
                download_url=download_url,
                asset_name=name,
                sha256_expected=sha256_expected,
            )

    # Look for macOS installer (.dmg)
    if platform.system() == "Darwin":
        for asset in data.get("assets", []):
            name = asset.get("name", "")
            if name.startswith("invoke-") and name.endswith(".dmg"):
                download_url = asset["browser_download_url"]
                if not download_url.startswith(_TRUSTED_DOWNLOAD_DOMAINS):
                    logger.warning(f"Update download URL from untrusted domain, skipping: {download_url}")
                    return None
                logger.info(f"Update available: {tag} (current: v{__version__})")
                return UpdateInfo(
                    version=tag.lstrip("v"),
                    download_url=download_url,
                    asset_name=name,
                    sha256_expected=sha256_expected,
                )

    logger.debug(f"Update {tag} found but no installer asset")
    return None


async def download_update(info: UpdateInfo) -> Path | None:
    """Download the update installer with integrity verification. Returns path to downloaded file."""
    global pending_update

    # For pip installs, skip download — user upgrades via pip
    if is_pip_installed() or not info.download_url:
        logger.info(f"Update v{info.version} available. Upgrade via: pip install --upgrade getinvoke")
        return None

    updates_dir = settings.config_dir / "updates"
    updates_dir.mkdir(parents=True, exist_ok=True)
    dest = updates_dir / info.asset_name

    # Already downloaded and verified?
    if dest.exists() and dest.stat().st_size > 1_000_000:
        if info.sha256_expected and _verify_sha256(dest, info.sha256_expected):
            logger.info(f"Update already downloaded and verified: {dest}")
            pending_update = dest
            return dest
        elif not info.sha256_expected:
            logger.warning(f"Update already downloaded but no SHA256 to verify: {dest}")
            return None  # Don't auto-apply without verification
        else:
            logger.warning("Existing download failed hash check, re-downloading")
            dest.unlink(missing_ok=True)

    logger.info(f"Downloading update: {info.download_url}")
    try:
        async with httpx.AsyncClient(timeout=120.0, follow_redirects=True) as client:
            response = await client.get(info.download_url)
            response.raise_for_status()
            dest.write_bytes(response.content)
    except Exception as e:
        logger.error(f"Update download failed: {e}")
        if dest.exists():
            dest.unlink(missing_ok=True)
        return None

    # Verify integrity
    if info.sha256_expected:
        if not _verify_sha256(dest, info.sha256_expected):
            logger.error("Update download FAILED integrity check — file deleted")
            dest.unlink(missing_ok=True)
            return None
        logger.info("Update integrity verified (SHA256 match)")

    file_size_mb = dest.stat().st_size / 1024 / 1024
    if file_size_mb < 1:
        logger.error(f"Update file suspiciously small ({file_size_mb:.1f} MB) — deleted")
        dest.unlink(missing_ok=True)
        return None

    # Require integrity hash for executable downloads
    if not info.sha256_expected:
        logger.warning(
            f"Update v{info.version} downloaded but no SHA256 hash in release notes — "
            "skipping auto-apply for safety. Verify manually."
        )
        # Don't set pending_update — the file stays but won't auto-execute
        return None

    logger.info(f"Update downloaded: {dest} ({file_size_mb:.1f} MB)")
    pending_update = dest
    return dest


def _verify_sha256(path: Path, expected: str) -> bool:
    """Verify file SHA256 hash matches expected value."""
    sha256 = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    actual = sha256.hexdigest()
    if actual != expected:
        logger.error(f"SHA256 mismatch: expected {expected}, got {actual}")
        return False
    return True


def apply_pending_update() -> None:
    """Launch the downloaded installer silently and exit. Called during shutdown."""
    global pending_update

    if pending_update is None or not pending_update.exists():
        return

    logger.info(f"Applying update: {pending_update}")
    try:
        if sys.platform == "darwin":
            # macOS: open the .dmg for user to drag-install
            subprocess.Popen(["open", str(pending_update)])
            logger.info("DMG opened for installation")
        else:
            # Windows: launch Inno Setup installer silently
            subprocess.Popen(
                [str(pending_update), "/VERYSILENT", "/NORESTART", "/SUPPRESSMSGBOXES"],
                creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
                if sys.platform == "win32"
                else 0,
            )
            logger.info("Installer launched, Invoke will restart after update")
    except Exception as e:
        logger.error(f"Failed to launch installer: {e}")
    finally:
        pending_update = None


async def check_and_download() -> UpdateInfo | None:
    """Full check + download flow. Run as background task on startup."""
    info = check_for_update()
    if info is None:
        return None

    await download_update(info)
    return info
