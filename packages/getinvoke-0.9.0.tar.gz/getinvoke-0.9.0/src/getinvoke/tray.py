"""System tray icon via pystray."""

import logging
import platform
import threading
from collections.abc import Callable
from pathlib import Path

import pystray
from PIL import Image, ImageDraw

logger = logging.getLogger(__name__)

# Icon states -> chevron colors
STATE_COLORS = {
    "idle": "#22c55e",  # Green
    "recording": "#5FC8C8",  # Bright teal
    "processing": "#D4943A",  # Gold
    "error": "#E67E80",  # Muted coral
}


def _create_icon_image(color: str, size: int = 64) -> Image.Image:
    """Generate the Invoke icon: dark box with colored '>' chevron."""
    # Render at 4x then downsample for anti-aliasing
    rs = size * 4
    img = Image.new("RGBA", (rs, rs), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    radius = max(rs // 8, 4)
    draw.rounded_rectangle([0, 0, rs - 1, rs - 1], radius=radius, fill="#0D1B1E")

    # Solid chevron polygon
    left = rs * 0.32
    right = rs * 0.68
    top = rs * 0.20
    bottom = rs * 0.80
    cy = rs * 0.50
    t = rs * 0.11

    draw.polygon(
        [
            (left, top - t),
            (right + t, cy),
            (left, bottom + t),
            (left, bottom - t),
            (right - t * 1.5, cy),
            (left, top + t),
        ],
        fill=color,
    )

    return img.resize((size, size), Image.LANCZOS)


class TrayApp:
    """System tray icon with state management and mode selection."""

    def __init__(
        self,
        on_quit: Callable[[], None] | None = None,
        on_mode_change: Callable[[str], None] | None = None,
    ) -> None:
        self._state = "idle"
        self._on_quit = on_quit
        self._on_mode_change = on_mode_change
        self._tooltip = "Invoke — Ready"
        self._icon: pystray.Icon | None = None
        self._thread: threading.Thread | None = None
        self._license_manager = None
        self._update_version: str | None = None

    def start(self) -> None:
        """Start the tray icon in a background thread."""
        from getinvoke.config import settings
        from getinvoke.modes import MODES

        # Build mode submenu with descriptions
        def _make_mode_handler(mode_name: str) -> Callable:
            def handler(icon: pystray.Icon, item: pystray.MenuItem) -> None:
                self._handle_mode_change(mode_name)

            return handler

        def _mode_checked(mode_name: str) -> Callable:
            def checked(item: pystray.MenuItem) -> bool:
                return settings.MODE == mode_name

            return checked

        # AI coding environments, then clean-up, then git utilities
        ide_modes = ["claude-code", "cursor", "windsurf", "copilot", "codex"]
        general_modes = ["raw"]
        git_modes = ["commit", "pr"]

        mode_items = []
        for name in ide_modes:
            mode = MODES[name]
            mode_items.append(
                pystray.MenuItem(
                    mode.label,
                    _make_mode_handler(mode.name),
                    checked=_mode_checked(mode.name),
                    radio=True,
                )
            )
        for name in general_modes:
            mode = MODES[name]
            mode_items.append(
                pystray.MenuItem(
                    mode.label,
                    _make_mode_handler(mode.name),
                    checked=_mode_checked(mode.name),
                    radio=True,
                )
            )
        mode_items.append(pystray.Menu.SEPARATOR)
        for name in git_modes:
            mode = MODES[name]
            mode_items.append(
                pystray.MenuItem(
                    mode.label,
                    _make_mode_handler(mode.name),
                    checked=_mode_checked(mode.name),
                    radio=True,
                )
            )

        mode_submenu = pystray.Menu(*mode_items)

        def _backend_label(item: pystray.MenuItem) -> str:
            b = settings.REFORMATTER_BACKEND.lower()
            if b == "none":
                return "AI:  off"
            if b == "openrouter":
                return "AI:  OpenRouter"
            if b == "claude-cli":
                return f"AI:  Claude CLI ({settings.CLAUDE_CLI_MODEL})"
            if b in ("local", "ollama"):
                provider = settings.LOCAL_LLM_PROVIDER
                if provider == "lmstudio":
                    return "AI:  LM Studio"
                return "AI:  Ollama"
            return f"AI:  {b}"

        # Build AI Backend submenu
        def _make_backend_handler(backend_name: str) -> Callable:
            def handler(icon: pystray.Icon, item: pystray.MenuItem) -> None:
                self._handle_backend_change(backend_name)

            return handler

        def _backend_checked(backend_name: str) -> Callable:
            def checked(item: pystray.MenuItem) -> bool:
                b = settings.REFORMATTER_BACKEND.lower()
                if backend_name == "local-ollama":
                    return b in ("local", "ollama") and settings.LOCAL_LLM_PROVIDER == "ollama"
                if backend_name == "local-lmstudio":
                    return b in ("local", "ollama") and settings.LOCAL_LLM_PROVIDER == "lmstudio"
                return b == backend_name

            return checked

        def _make_local_handler(provider: str) -> Callable:
            def handler(icon: pystray.Icon, item: pystray.MenuItem) -> None:
                settings.LOCAL_LLM_PROVIDER = provider
                self._handle_backend_change("local")

            return handler

        backend_items = [
            pystray.MenuItem(
                "OpenRouter (fastest)",
                _make_backend_handler("openrouter"),
                checked=_backend_checked("openrouter"),
                radio=True,
            ),
            pystray.MenuItem(
                lambda item: f"Claude CLI (slower, {settings.CLAUDE_CLI_MODEL})",
                _make_backend_handler("claude-cli"),
                checked=_backend_checked("claude-cli"),
                radio=True,
            ),
            pystray.MenuItem(
                "Ollama (fast, private)",
                _make_local_handler("ollama"),
                checked=_backend_checked("local-ollama"),
                radio=True,
            ),
            pystray.MenuItem(
                "LM Studio (fast, private)",
                _make_local_handler("lmstudio"),
                checked=_backend_checked("local-lmstudio"),
                radio=True,
            ),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(
                "Off (raw transcription only)",
                _make_backend_handler("none"),
                checked=_backend_checked("none"),
                radio=True,
            ),
        ]
        backend_submenu = pystray.Menu(*backend_items)

        def _mode_label(item: pystray.MenuItem) -> str:
            return f"Mode:  {settings.MODE}"

        def _project_label(item: pystray.MenuItem) -> str:
            if settings.PROJECT_DIR:
                return f"Project:  {Path(settings.PROJECT_DIR).expanduser().name}"
            return "Project:  not set"

        def _privacy_label(item: pystray.MenuItem) -> str:
            if settings.PRIVACY_MODE:
                return "Private:  all processing local"
            return ""

        menu = pystray.Menu(
            pystray.MenuItem("> invoke", None, enabled=False),
            pystray.MenuItem(_mode_label, None, enabled=False),
            pystray.MenuItem(_backend_label, None, enabled=False),
            pystray.MenuItem(_project_label, None, enabled=False),
            pystray.MenuItem(
                _privacy_label,
                None,
                enabled=False,
                visible=lambda item: settings.PRIVACY_MODE,
            ),
            pystray.MenuItem(
                lambda item: f"\u2191 Update to v{self._update_version}" if self._update_version else "",
                self._handle_quit,
                visible=lambda item: self._update_version is not None,
            ),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Mode", mode_submenu),
            pystray.MenuItem("AI Engine", backend_submenu),
            pystray.MenuItem(
                lambda item: f"Private Mode:  {'On' if settings.PRIVACY_MODE else 'Off'}",
                self._handle_toggle_privacy,
            ),
            pystray.MenuItem(
                lambda item: f"Image Capture:  {'On' if settings.IMAGE_CAPTURE_ENABLED else 'Off'}",
                self._handle_toggle_image_capture,
            ),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("License", self._handle_open_license),
            pystray.MenuItem("Settings", self._handle_open_settings),
            pystray.MenuItem("Logs", self._handle_open_logs),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit", self._handle_quit),
        )

        self._icon = pystray.Icon(
            "invoke",
            icon=_create_icon_image(STATE_COLORS["idle"]),
            title=self._tooltip,
            menu=menu,
        )

        self._thread = threading.Thread(target=self._icon.run, daemon=True)
        self._thread.start()
        logger.info("Tray icon started")

    def stop(self) -> None:
        """Stop the tray icon."""
        if self._icon is not None:
            self._icon.stop()
            self._icon = None
        logger.info("Tray icon stopped")

    def set_state(self, state: str) -> None:
        """Update tray icon state (idle, recording, processing, error)."""
        self._state = state
        color = STATE_COLORS.get(state, STATE_COLORS["idle"])
        if self._icon is not None:
            self._icon.icon = _create_icon_image(color)
            self._icon.title = self._tooltip

    def set_tooltip(self, text: str) -> None:
        """Update the tooltip text."""
        self._tooltip = f"Invoke — {text}"
        if self._icon is not None:
            self._icon.title = self._tooltip

    def notify(self, message: str, title: str = "Invoke") -> None:
        """Show a system notification (toast on Windows)."""
        if self._icon is not None:
            try:
                self._icon.notify(message, title)
            except Exception as e:
                logger.debug(f"Notification failed: {e}")

    def set_license_manager(self, lm) -> None:
        """Set the license manager for tooltip display."""
        self._license_manager = lm
        # Update tooltip based on license state
        from getinvoke.license import LicenseStatus

        if lm.status == LicenseStatus.TRIAL:
            self.set_tooltip(f"Trial — {lm.trial_days_left} days left")
        elif lm.status == LicenseStatus.GRACE:
            self.set_tooltip("License — offline grace period")

    def set_update_available(self, version: str) -> None:
        """Signal that an update has been downloaded and is ready."""
        self._update_version = version
        if self._icon is not None:
            self._icon.update_menu()

    def _handle_open_license(self, icon: pystray.Icon, item: pystray.MenuItem) -> None:
        """Open the license activation dialog."""
        if self._license_manager is None:
            return

        from getinvoke.license import LicenseStatus
        from getinvoke.license_gui import show_activation_dialog

        allow_trial = self._license_manager.status == LicenseStatus.TRIAL
        days_left = self._license_manager.trial_days_left

        def _run() -> None:
            show_activation_dialog(
                self._license_manager,
                allow_trial=allow_trial,
                trial_days_left=days_left,
            )
            # Refresh tooltip after dialog closes
            if self._license_manager.status == LicenseStatus.ACTIVE:
                self.set_tooltip("Ready")
            elif self._license_manager.status == LicenseStatus.TRIAL:
                self.set_tooltip(f"Trial — {self._license_manager.trial_days_left} days left")

        threading.Thread(target=_run, daemon=True).start()

    def _handle_toggle_privacy(self, icon: pystray.Icon, item: pystray.MenuItem) -> None:
        from getinvoke.config import settings

        if settings.PRIVACY_MODE:
            # Turn off — restore previous backend
            prev = getattr(self, "_pre_privacy_backend", "openrouter")
            settings.REFORMATTER_BACKEND = prev
            settings.PRIVACY_MODE = False
            settings.save()
            logger.info(f"Private mode off, backend restored to: {prev}")
            self.notify(f"Private mode off \u2014 AI: {prev}", "Invoke")
        else:
            # Turn on — save current backend, force local
            self._pre_privacy_backend = settings.REFORMATTER_BACKEND
            settings.REFORMATTER_BACKEND = "local"
            settings.PRIVACY_MODE = True
            settings.save()
            logger.info("Private mode on — all processing local")
            provider = settings.LOCAL_LLM_PROVIDER
            provider_name = "LM Studio" if provider == "lmstudio" else "Ollama"
            self.notify(
                f"Private mode on \u2014 using {provider_name}.\nChange provider in Settings > AI Processing.",
                "Invoke",
            )
        if self._icon is not None:
            self._icon.update_menu()

    def _handle_backend_change(self, backend_name: str) -> None:
        from getinvoke.config import settings

        # Manual backend change clears privacy mode
        if settings.PRIVACY_MODE and backend_name not in ("local", "ollama"):
            settings.PRIVACY_MODE = False
            logger.info("Private mode disabled (manual backend change)")

        settings.REFORMATTER_BACKEND = backend_name
        settings.save()
        logger.info(f"AI backend changed to: {backend_name}")
        if self._icon is not None:
            self._icon.update_menu()

        # Notify user
        if backend_name == "openrouter" and not settings.OPENROUTER_API_KEY:
            self.notify("OpenRouter needs an API key. Open Settings to add one.", "Invoke — Setup Needed")
        elif backend_name == "none":
            self.notify("AI off — raw Whisper output only", "Invoke")
        else:
            self.notify(f"AI engine: {backend_name}", "Invoke")

    def _handle_toggle_image_capture(self, icon: pystray.Icon, item: pystray.MenuItem) -> None:
        from getinvoke.config import settings

        settings.IMAGE_CAPTURE_ENABLED = not settings.IMAGE_CAPTURE_ENABLED
        settings.save()
        state = "enabled" if settings.IMAGE_CAPTURE_ENABLED else "disabled"
        logger.info(f"Image capture {state}")
        self.notify(f"Image capture {state}. Restart to apply.", "Invoke")
        if self._icon is not None:
            self._icon.update_menu()

    def _handle_mode_change(self, mode_name: str) -> None:
        from getinvoke.config import settings

        settings.MODE = mode_name
        settings.save()
        logger.info(f"Mode changed to: {mode_name}")
        self.notify(f"Mode: {mode_name}", "Invoke")
        if self._on_mode_change:
            self._on_mode_change(mode_name)

    def _handle_quit(self, icon: pystray.Icon, item: pystray.MenuItem) -> None:
        if self._on_quit:
            self._on_quit()
        self.stop()

    def _handle_open_settings(self, icon: pystray.Icon, item: pystray.MenuItem) -> None:
        from getinvoke.settings_gui import open_settings

        def _on_save() -> None:
            logger.info("Settings saved, updating tray state")
            # Update tray mode display after settings change
            if self._icon is not None:
                self._icon.update_menu()

        open_settings(on_save=_on_save)

    def _handle_open_logs(self, icon: pystray.Icon, item: pystray.MenuItem) -> None:
        from getinvoke.config import settings

        log_dir = settings.log_dir
        log_dir.mkdir(parents=True, exist_ok=True)
        self._open_path(log_dir)

    @staticmethod
    def _open_path(path) -> None:
        import subprocess

        if platform.system() == "Windows":
            subprocess.Popen(["explorer", str(path)])
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
