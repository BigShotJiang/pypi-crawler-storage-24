# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec file for Invoke — macOS .app bundle.

Usage:
    cd invoke/
    pyinstaller installer/invoke-macos.spec
"""

from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files

block_cipher = None

ROOT = Path(SPECPATH).parent
SRC = ROOT / "src"

# Collect data files that PyInstaller misses
datas = []
datas += collect_data_files("faster_whisper")  # Includes assets/silero_vad_v6.onnx (VAD model)
datas += collect_data_files("_sounddevice_data")  # PortAudio dylibs

a = Analysis(
    [str(SRC / "getinvoke" / "__main__.py")],
    pathex=[str(SRC)],
    binaries=[],
    datas=datas,
    hiddenimports=[
        # pynput platform backends
        "pynput.keyboard._darwin",
        "pynput.mouse._darwin",
        # pystray platform backend
        "pystray._darwin",
        # sounddevice/PortAudio
        "sounddevice",
        "_sounddevice_data",
        # faster-whisper / ctranslate2
        "faster_whisper",
        "ctranslate2",
        # tkinter (for wizard, settings, overlay)
        "tkinter",
        "tkinter.ttk",
        # click CLI
        "click",
        # other deps
        "httpx",
        "pyperclip",
        "dotenv",
        "PIL",
        "scipy.signal",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Exclude PyTorch — we use CTranslate2 directly
        "torch",
        "torchvision",
        "torchaudio",
        # Test / dev tools
        "pytest",
        "ruff",
        "setuptools",
        "pip",
    ],
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="invoke",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,  # UPX not reliable on macOS
    console=False,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    name="invoke",
)

app = BUNDLE(
    coll,
    name="Invoke.app",
    icon=str(ROOT / "installer" / "invoke.icns") if (ROOT / "installer" / "invoke.icns").exists() else None,
    bundle_identifier="dev.getinvoke.invoke",
    info_plist={
        "CFBundleDisplayName": "Invoke",
        "CFBundleShortVersionString": "0.6.2",
        "CFBundleName": "Invoke",
        "NSMicrophoneUsageDescription": "Invoke needs microphone access to record your voice for transcription.",
        "NSAppleEventsUsageDescription": "Invoke uses AppleScript for auto-paste and clipboard image capture.",
        "LSBackgroundOnly": False,
        "LSUIElement": True,  # Menu bar app — no Dock icon
    },
)
