# CLAUDE.md — Invoke

## Project Overview

Invoke (PyPI: `getinvoke`, CLI command: `dictate`) is a voice-to-prompt desktop app for developers. Hold a hotkey, speak, release — structured prompts on clipboard. Local Whisper transcription + optional AI reformatting.

## Architecture

- **Engine pattern**: `engine.py` is the orchestrator. Frontends implement `FrontendProtocol`. Two frontends exist: `GuiFrontend` (tray + overlay) and `TerminalFrontend` (Rich console).
- **Pipeline**: hotkey press -> recorder -> Whisper transcribe -> AI reformat -> clipboard/auto-paste
- **Audio**: Persistent `sounddevice.InputStream` stays open for app lifetime (avoids ALSA latency). 30s keepalive timer prevents PipeWire suspension.
- **Threading**: pynput listener runs in its own thread. Audio callback runs in sounddevice's thread. Pipeline processing runs in asyncio executor. tkinter GUIs run in their own threads. All shared state needs locks or thread-safe patterns.

## Dev Setup

```bash
pip install -e ".[dev,gui]"
```

## Testing / Linting

```bash
ruff check src/ tests/
ruff format src/ tests/
pytest
```

Python is at `.venv/bin/python`. Tests: 88 passing.

## Key Conventions

- **tkinter threading**: Never use `StringVar(value=...)` in threaded tkinter — use empty constructor + `.set()`. Always `withdraw()` before building widgets, `deiconify()` after.
- **Blocking calls in tkinter**: Never call network/device APIs on the tkinter main thread. Use `threading.Thread` + `self.after(0, callback)` pattern.
- **Cross-platform**: Guard `mouse.Button.x1/x2` with `getattr` (Windows-only). Use `platform.system()` checks. Linux auto-paste uses `xdotool` subprocess, not pynput keyboard.
- **Settings reload**: Don't call `settings.__init__()` — use the live singleton directly.
- **Config file**: `config.json` in `%APPDATA%\Invoke` (Windows) or `~/.config/invoke` (Linux). Contains API keys — restricted file permissions on Unix.

## Distribution

- **PyPI**: `getinvoke` via trusted publishing (GitHub Actions OIDC). Tag `vX.Y.Z` triggers publish.
- **Windows installer**: PyInstaller + Inno Setup. CI workflow `build-installer.yml`. Must install `[gui,dev]` extras.
- **CLI command**: `dictate` (not `invoke` — conflicts with pyinvoke).

## Licensing

Lemon Squeezy (store ID 314146). 7-day trial, $49 lifetime. `license.py` handles validation with offline grace period. `license_gui.py` is the activation dialog.
