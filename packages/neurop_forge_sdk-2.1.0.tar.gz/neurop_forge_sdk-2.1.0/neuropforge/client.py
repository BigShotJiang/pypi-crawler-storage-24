"""
Neurop Forge API Client.

A thin wrapper around the Neurop Forge hosted API for deterministic
block execution with full audit trail.
"""
import os
from typing import Any, Dict, List, Optional
from dataclasses import dataclass
import httpx


class NeuropForgeError(Exception):
    """Base exception for Neurop Forge errors."""
    pass


class BlockNotFoundError(NeuropForgeError):
    """Raised when a block doesn't exist."""
    pass


class ExecutionError(NeuropForgeError):
    """Raised when block execution fails."""
    pass


class AuthenticationError(NeuropForgeError):
    """Raised when API key is invalid."""
    pass


class RateLimitError(NeuropForgeError):
    """Raised when rate limit is exceeded."""
    pass


@dataclass
class DomainInfo:
    """Information about a domain."""
    domain: str
    block_count: int
    description: str


@dataclass
class BlockInfo:
    """Information about a block."""
    name: str
    category: str
    description: str
    inputs: List[str]
    domain: Optional[str] = None


@dataclass
class ExecutionResult:
    """Result of block execution."""
    success: bool
    block_name: str
    result: Any
    execution_time_ms: float
    audit_hash: Optional[str] = None
    block_id: Optional[str] = None
    error: Optional[str] = None


@dataclass
class SearchResult:
    """Result of block search."""
    name: str
    domain: str
    operation: str
    why_selected: str


def _check_response(response: httpx.Response) -> None:
    """Check response for common error status codes."""
    if response.status_code == 401:
        raise AuthenticationError("Missing or invalid API key")
    if response.status_code == 403:
        raise AuthenticationError("Forbidden — check your API key permissions")
    if response.status_code == 429:
        raise RateLimitError("Rate limit exceeded. Try again later.")
    if response.status_code == 503:
        raise NeuropForgeError("Service unavailable — library may not be loaded")
    if response.status_code >= 400:
        body = response.text[:200] if response.text else "No response body"
        raise NeuropForgeError(f"HTTP {response.status_code}: {body}")


class NeuropForge:
    """
    Neurop Forge API Client.

    Provides deterministic execution of 5,175+ pre-verified, hash-locked
    function blocks across 5 domains. AI agents can search, compose, and
    execute blocks — but never modify them.

    Args:
        api_key: Your Neurop Forge API key. Defaults to NEUROP_API_KEY env var.
        base_url: API base URL. Defaults to production API.
        timeout: Request timeout in seconds. Default 30.

    Example:
        >>> client = NeuropForge(api_key="your_key")
        >>> result = client.execute("to_uppercase", text="hello")
        >>> print(result.result)  # "HELLO"
    """

    DEFAULT_URL = "https://neurop-forge.onrender.com"

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ):
        self.api_key = api_key or os.environ.get("NEUROP_API_KEY")
        if not self.api_key:
            raise NeuropForgeError(
                "API key required. Pass api_key or set NEUROP_API_KEY env var."
            )

        self.base_url = (
            base_url or os.environ.get("NEUROP_API_URL") or self.DEFAULT_URL
        ).rstrip("/")
        self.timeout = timeout
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "X-API-Key": self.api_key,
                "User-Agent": "neuropforge-sdk/2.1.0",
            },
            timeout=timeout,
        )

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        """Close the HTTP client."""
        self._client.close()

    def health(self) -> Dict[str, Any]:
        """
        Check API health status.

        Returns:
            Dict with status, library_loaded, block_count, version.
        """
        response = self._client.get("/health")
        _check_response(response)
        return response.json()

    def execute(self, block_name: str, **inputs) -> ExecutionResult:
        """
        Execute a block by exact name.

        This is the primary method. AI agents call blocks by exact name
        for deterministic, auditable execution.

        Args:
            block_name: Exact name of the block to execute.
            **inputs: Keyword arguments for block inputs.

        Returns:
            ExecutionResult with success status, result, and audit hash.

        Raises:
            BlockNotFoundError: If block doesn't exist.
            ExecutionError: If execution fails.
            AuthenticationError: If API key is invalid.

        Example:
            >>> result = client.execute("to_uppercase", text="hello")
            >>> result.result  # "HELLO"
        """
        response = self._client.post(
            "/execute-block",
            json={"block_name": block_name, "inputs": inputs},
        )
        _check_response(response)

        data = response.json()

        if not data.get("success"):
            error = data.get("error", "Unknown error")
            if "not found" in str(error).lower():
                raise BlockNotFoundError(f"Block '{block_name}' not found")
            raise ExecutionError(error)

        result_data = data.get("result", {})
        result_value = result_data.get("result") if isinstance(result_data, dict) else result_data

        return ExecutionResult(
            success=True,
            block_name=block_name,
            result=result_value,
            execution_time_ms=data.get("execution_time_ms", 0),
            audit_hash=data.get("audit_hash") or data.get("audit", {}).get("hash"),
            block_id=data.get("debug_info", {}).get("block_id"),
        )

    def search(self, query: str, limit: int = 10) -> List[SearchResult]:
        """
        Search for blocks by natural language query.

        The domain router automatically detects which domain your query
        targets and boosts relevant blocks.

        Args:
            query: Natural language description of what you need.
            limit: Maximum results to return.

        Returns:
            List of SearchResult with matching blocks.

        Example:
            >>> results = client.search("calculate gas fee ethereum")
            >>> results[0].name  # "calculate_gas_fee"
            >>> results[0].domain  # "crypto"
        """
        response = self._client.post(
            "/search",
            json={"query": query, "limit": limit},
        )
        _check_response(response)

        data = response.json()
        return [
            SearchResult(
                name=b["name"],
                domain=b.get("domain", ""),
                operation=b.get("operation", ""),
                why_selected=b.get("why_selected", ""),
            )
            for b in data.get("blocks", [])
        ]

    def domains(self) -> List[DomainInfo]:
        """
        List all available domains with block counts.

        Neurop Forge organizes 5,175+ blocks into 5 domains:
        data, crypto, payments, auth, integrations.

        Returns:
            List of DomainInfo objects.

        Example:
            >>> for d in client.domains():
            ...     print(f"{d.domain}: {d.block_count} blocks")
        """
        response = self._client.get("/domains")
        _check_response(response)

        data = response.json()
        return [
            DomainInfo(
                domain=d["domain"],
                block_count=d["block_count"],
                description=d.get("description", ""),
            )
            for d in data.get("domains", [])
        ]

    def domain_blocks(
        self, domain: str, limit: int = 50
    ) -> List[BlockInfo]:
        """
        List blocks in a specific domain.

        Args:
            domain: Domain name (data, crypto, payments, auth, integrations).
            limit: Maximum blocks to return.

        Returns:
            List of BlockInfo objects.

        Example:
            >>> blocks = client.domain_blocks("crypto", limit=5)
            >>> for b in blocks:
            ...     print(f"{b.name}: {b.description}")
        """
        response = self._client.get(
            f"/domains/{domain}/blocks", params={"limit": limit}
        )
        _check_response(response)

        if response.status_code == 404:
            raise NeuropForgeError(f"Domain '{domain}' not found")

        data = response.json()
        return [
            BlockInfo(
                name=b["name"],
                category=b["category"],
                description=b["description"],
                inputs=b["inputs"],
                domain=domain,
            )
            for b in data.get("blocks", [])
        ]

    def list_blocks(
        self, limit: int = 50, category: Optional[str] = None
    ) -> List[BlockInfo]:
        """
        List available blocks.

        Args:
            limit: Maximum blocks to return.
            category: Filter by category (e.g., "validation", "crypto_wallet").

        Returns:
            List of BlockInfo objects.
        """
        params = {"limit": limit}
        if category:
            params["category"] = category

        response = self._client.get("/blocks", params=params)
        _check_response(response)

        data = response.json()
        return [
            BlockInfo(
                name=b["name"],
                category=b["category"],
                description=b["description"],
                inputs=b["inputs"],
            )
            for b in data.get("blocks", [])
        ]

    def stats(self) -> Dict[str, Any]:
        """
        Get library and usage statistics, including domain breakdown.

        Returns:
            Dict with library stats (categories, domains), usage metrics, version.
        """
        response = self._client.get("/stats")
        _check_response(response)
        return response.json()

    def audit_chain(self) -> Dict[str, Any]:
        """
        Get audit chain for verification.

        Returns:
            Dict with chain_hash, event_count, integrity_valid.
        """
        response = self._client.get("/audit/chain")
        _check_response(response)
        return response.json()

    def register_key(self, name: str, email: str) -> Dict[str, Any]:
        """
        Register a new API key.

        Args:
            name: Display name for the key owner.
            email: Email address for the key owner.

        Returns:
            Dict with api_key and registration details.
        """
        response = self._client.post(
            "/api-keys/register",
            json={"name": name, "email": email},
        )
        _check_response(response)
        return response.json()

    def rotate_key(self, current_key: str) -> Dict[str, Any]:
        """
        Rotate an existing API key.

        Args:
            current_key: The current API key to rotate.

        Returns:
            Dict with new_api_key and rotation details.
        """
        response = self._client.post(
            "/api-keys/rotate",
            json={"current_key": current_key},
        )
        _check_response(response)
        return response.json()

    def revoke_key(self) -> Dict[str, Any]:
        """
        Revoke the current API key.

        Returns:
            Dict with revocation confirmation.
        """
        response = self._client.request("DELETE", "/api-keys/revoke")
        _check_response(response)
        return response.json()

    def key_info(self) -> Dict[str, Any]:
        """
        Get metadata about the current API key.

        Returns:
            Dict with key metadata (name, email, created_at, etc.).
        """
        response = self._client.get("/api-keys/info")
        _check_response(response)
        return response.json()

    def usage(self) -> Dict[str, Any]:
        """
        Get usage data for the current API key.

        Returns:
            Dict with usage statistics and history.
        """
        response = self._client.get("/usage")
        _check_response(response)
        return response.json()
