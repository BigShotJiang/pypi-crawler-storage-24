"""
Neurop Forge Async API Client.

Async version of the Neurop Forge client for use with asyncio,
LangChain, CrewAI, and other async agent frameworks.
"""
import os
from typing import Any, Dict, List, Optional

import httpx

from .client import (
    AuthenticationError,
    BlockInfo,
    BlockNotFoundError,
    DomainInfo,
    ExecutionError,
    ExecutionResult,
    NeuropForgeError,
    RateLimitError,
    SearchResult,
)


def _check_response(response: httpx.Response) -> None:
    """Check response for common error status codes."""
    if response.status_code == 401:
        raise AuthenticationError("Missing or invalid API key")
    if response.status_code == 403:
        raise AuthenticationError("Forbidden — check your API key permissions")
    if response.status_code == 429:
        raise RateLimitError("Rate limit exceeded. Try again later.")
    if response.status_code == 503:
        raise NeuropForgeError("Service unavailable — library may not be loaded")
    if response.status_code >= 400:
        body = response.text[:200] if response.text else "No response body"
        raise NeuropForgeError(f"HTTP {response.status_code}: {body}")


class AsyncNeuropForge:
    """
    Async Neurop Forge API Client.

    Provides async deterministic execution of 5,175+ pre-verified, hash-locked
    function blocks across 5 domains. Designed for use with asyncio-based
    agent frameworks like LangChain, CrewAI, and AutoGen.

    Args:
        api_key: Your Neurop Forge API key. Defaults to NEUROP_API_KEY env var.
        base_url: API base URL. Defaults to production API.
        timeout: Request timeout in seconds. Default 30.

    Example:
        >>> async with AsyncNeuropForge(api_key="your_key") as client:
        ...     result = await client.execute("to_uppercase", text="hello")
        ...     print(result.result)  # "HELLO"
    """

    DEFAULT_URL = "https://neurop-forge.onrender.com"

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ):
        self.api_key = api_key or os.environ.get("NEUROP_API_KEY")
        if not self.api_key:
            raise NeuropForgeError(
                "API key required. Pass api_key or set NEUROP_API_KEY env var."
            )

        self.base_url = (
            base_url or os.environ.get("NEUROP_API_URL") or self.DEFAULT_URL
        ).rstrip("/")
        self.timeout = timeout
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "X-API-Key": self.api_key,
                "User-Agent": "neuropforge-sdk/2.1.0",
            },
            timeout=timeout,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def close(self):
        """Close the async HTTP client."""
        await self._client.aclose()

    async def health(self) -> Dict[str, Any]:
        """Check API health status."""
        response = await self._client.get("/health")
        _check_response(response)
        return response.json()

    async def execute(self, block_name: str, **inputs) -> ExecutionResult:
        """
        Execute a block by exact name.

        Args:
            block_name: Exact name of the block to execute.
            **inputs: Keyword arguments for block inputs.

        Returns:
            ExecutionResult with success status, result, and audit hash.

        Example:
            >>> result = await client.execute("calculate_gas_fee", gas_limit=21000, gas_price_gwei=30.5)
            >>> result.result  # 0.0006405
        """
        response = await self._client.post(
            "/execute-block",
            json={"block_name": block_name, "inputs": inputs},
        )
        _check_response(response)

        data = response.json()

        if not data.get("success"):
            error = data.get("error", "Unknown error")
            if "not found" in str(error).lower():
                raise BlockNotFoundError(f"Block '{block_name}' not found")
            raise ExecutionError(error)

        result_data = data.get("result", {})
        result_value = result_data.get("result") if isinstance(result_data, dict) else result_data

        return ExecutionResult(
            success=True,
            block_name=block_name,
            result=result_value,
            execution_time_ms=data.get("execution_time_ms", 0),
            audit_hash=data.get("audit_hash") or data.get("audit", {}).get("hash"),
            block_id=data.get("debug_info", {}).get("block_id"),
        )

    async def search(self, query: str, limit: int = 10) -> List[SearchResult]:
        """
        Search for blocks by natural language query.

        Args:
            query: Natural language description of what you need.
            limit: Maximum results to return.

        Returns:
            List of SearchResult with matching blocks.
        """
        response = await self._client.post(
            "/search",
            json={"query": query, "limit": limit},
        )
        _check_response(response)

        data = response.json()
        return [
            SearchResult(
                name=b["name"],
                domain=b.get("domain", ""),
                operation=b.get("operation", ""),
                why_selected=b.get("why_selected", ""),
            )
            for b in data.get("blocks", [])
        ]

    async def domains(self) -> List[DomainInfo]:
        """
        List all available domains with block counts.

        Returns:
            List of DomainInfo objects.
        """
        response = await self._client.get("/domains")
        _check_response(response)

        data = response.json()
        return [
            DomainInfo(
                domain=d["domain"],
                block_count=d["block_count"],
                description=d.get("description", ""),
            )
            for d in data.get("domains", [])
        ]

    async def domain_blocks(
        self, domain: str, limit: int = 50
    ) -> List[BlockInfo]:
        """
        List blocks in a specific domain.

        Args:
            domain: Domain name (data, crypto, payments, auth, integrations).
            limit: Maximum blocks to return.

        Returns:
            List of BlockInfo objects.
        """
        response = await self._client.get(
            f"/domains/{domain}/blocks", params={"limit": limit}
        )
        _check_response(response)

        if response.status_code == 404:
            raise NeuropForgeError(f"Domain '{domain}' not found")

        data = response.json()
        return [
            BlockInfo(
                name=b["name"],
                category=b["category"],
                description=b["description"],
                inputs=b["inputs"],
                domain=domain,
            )
            for b in data.get("blocks", [])
        ]

    async def list_blocks(
        self, limit: int = 50, category: Optional[str] = None
    ) -> List[BlockInfo]:
        """
        List available blocks.

        Args:
            limit: Maximum blocks to return.
            category: Filter by category.

        Returns:
            List of BlockInfo objects.
        """
        params = {"limit": limit}
        if category:
            params["category"] = category

        response = await self._client.get("/blocks", params=params)
        _check_response(response)

        data = response.json()
        return [
            BlockInfo(
                name=b["name"],
                category=b["category"],
                description=b["description"],
                inputs=b["inputs"],
            )
            for b in data.get("blocks", [])
        ]

    async def stats(self) -> Dict[str, Any]:
        """Get library and usage statistics, including domain breakdown."""
        response = await self._client.get("/stats")
        _check_response(response)
        return response.json()

    async def audit_chain(self) -> Dict[str, Any]:
        """Get audit chain for verification."""
        response = await self._client.get("/audit/chain")
        _check_response(response)
        return response.json()

    async def register_key(self, name: str, email: str) -> Dict[str, Any]:
        """
        Register a new API key.

        Args:
            name: Display name for the key owner.
            email: Email address for the key owner.

        Returns:
            Dict with api_key and registration details.
        """
        response = await self._client.post(
            "/api-keys/register",
            json={"name": name, "email": email},
        )
        _check_response(response)
        return response.json()

    async def rotate_key(self, current_key: str) -> Dict[str, Any]:
        """
        Rotate an existing API key.

        Args:
            current_key: The current API key to rotate.

        Returns:
            Dict with new_api_key and rotation details.
        """
        response = await self._client.post(
            "/api-keys/rotate",
            json={"current_key": current_key},
        )
        _check_response(response)
        return response.json()

    async def revoke_key(self) -> Dict[str, Any]:
        """
        Revoke the current API key.

        Returns:
            Dict with revocation confirmation.
        """
        response = await self._client.request("DELETE", "/api-keys/revoke")
        _check_response(response)
        return response.json()

    async def key_info(self) -> Dict[str, Any]:
        """
        Get metadata about the current API key.

        Returns:
            Dict with key metadata (name, email, created_at, etc.).
        """
        response = await self._client.get("/api-keys/info")
        _check_response(response)
        return response.json()

    async def usage(self) -> Dict[str, Any]:
        """
        Get usage data for the current API key.

        Returns:
            Dict with usage statistics and history.
        """
        response = await self._client.get("/usage")
        _check_response(response)
        return response.json()
