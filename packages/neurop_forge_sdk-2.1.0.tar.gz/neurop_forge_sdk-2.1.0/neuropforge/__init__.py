"""
Neurop Forge SDK - Python client for the Neurop Forge API.

Execute 5,175+ pre-verified, hash-locked function blocks across 5 domains
with full audit trail. AI agents can search, compose, and execute blocks —
but never modify them.

Sync usage:
    from neuropforge import NeuropForge

    client = NeuropForge(api_key="your_key")
    result = client.execute("to_uppercase", text="hello world")
    print(result.result)  # "HELLO WORLD"

Async usage:
    from neuropforge import AsyncNeuropForge

    async with AsyncNeuropForge(api_key="your_key") as client:
        result = await client.execute("calculate_gas_fee", gas_limit=21000, gas_price_gwei=30.5)
        print(result.result)  # 0.0006405
"""
from .client import (
    NeuropForge,
    NeuropForgeError,
    BlockNotFoundError,
    ExecutionError,
    AuthenticationError,
    RateLimitError,
    BlockInfo,
    DomainInfo,
    ExecutionResult,
    SearchResult,
)
from .async_client import AsyncNeuropForge

__version__ = "2.1.0"
__all__ = [
    "NeuropForge",
    "AsyncNeuropForge",
    "NeuropForgeError",
    "BlockNotFoundError",
    "ExecutionError",
    "AuthenticationError",
    "RateLimitError",
    "BlockInfo",
    "DomainInfo",
    "ExecutionResult",
    "SearchResult",
]
