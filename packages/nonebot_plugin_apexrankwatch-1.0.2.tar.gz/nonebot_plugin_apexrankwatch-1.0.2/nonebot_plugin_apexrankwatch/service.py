from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import httpx

TRANSLATIONS_FILE = Path(__file__).with_name("translations.json")

JSONLD_SCRIPT_RE = re.compile(
    r'<script\s+type="application/ld\+json">(.*?)</script>',
    re.IGNORECASE | re.DOTALL,
)
SEASON_LIVE_RE = re.compile(
    r"Season\s+(\d+)\s+[·•\-]\s+([^\n]+?)\s+is live now",
    re.IGNORECASE,
)
SEASON_STARTED_RE = re.compile(
    r"Season\s+(\d+)\s+[·•\-]\s+([^\n]+?)\s+Started",
    re.IGNORECASE,
)
SEASON_NAME_RE = re.compile(r"Season\s+(\d+)\s+[·•\-]\s+(.+)", re.IGNORECASE)
DATE_RANGE_RE = re.compile(
    r"Started\s+([A-Za-z]{3}\s+\d{1,2})\s+(\d{4})\s+Ends\s+([A-Za-z]{3}\s+\d{1,2})\s+(\d{4})",
    re.IGNORECASE | re.DOTALL,
)
DATE_RANGE_LONG_RE = re.compile(
    r"Started\s+([A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4}).*?Ends\s+([A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4})",
    re.IGNORECASE | re.DOTALL,
)
TIMEZONE_RE = re.compile(r"Timezone\s+[·•\-]\s+([^\n]+)", re.IGNORECASE)
TIMEZONE_PAGE_RE = re.compile(r"Timezone\s*:?\s*([^\n<]+)", re.IGNORECASE)
UPDATE_HINT_RE = re.compile(
    r"Respawn\s+deploys\s+all\s+major\s+updates\s+at\s+([^\n\.]+)",
    re.IGNORECASE,
)
COUNTDOWN_ARRAY_RE = re.compile(r'targetDate"\s*:\s*\[0\s*,\s*"([^"]+)"\]', re.IGNORECASE)
COUNTDOWN_STRING_RE = re.compile(r'targetDate"\s*:\s*"([^"]+)"', re.IGNORECASE)

NAME_MAP: dict[str, str] = {
    "Unranked": "菜鸟",
    "Bronze": "青铜",
    "Silver": "白银",
    "Gold": "黄金",
    "Platinum": "白金",
    "Diamond": "钻石",
    "Master": "大师",
    "Apex Predator": "Apex 猎杀者",
    "offline": "离线",
    "online": "在线",
    "inLobby": "在大厅",
    "in Lobby": "在大厅",
    "In lobby": "在大厅",
    "In Lobby": "在大厅",
    "inMatch": "比赛中",
    "in Match": "比赛中",
    "In match": "比赛中",
    "In Match": "比赛中",
}


@dataclass
class LegendKillsRank:
    value: int
    global_percent: str


@dataclass
class ApexPlayerStats:
    name: str
    uid: str
    level: int
    rank_score: int
    rank_name: str
    rank_div: int
    global_rank_percent: str
    is_online: bool
    selected_legend: str
    legend_kills_rank: LegendKillsRank | None
    current_state: str
    is_in_lobby_or_match: bool
    platform: str


@dataclass
class SeasonInfo:
    season_number: int | None
    season_name: str
    start_date: str
    end_date: str
    timezone: str
    update_time_hint: str
    source: str
    season_url: str
    start_iso: str
    end_iso: str


class PlayerNotFoundError(Exception):
    pass


class ApexApiClient:
    def __init__(
        self,
        api_key: str,
        timeout_ms: int,
        max_retries: int,
        debug_enabled: bool = False,
    ) -> None:
        self._api_key = api_key
        self._timeout = max(1, timeout_ms) / 1000
        self._max_retries = max(0, max_retries)
        self._debug_enabled = debug_enabled
        self._client = httpx.AsyncClient(
            timeout=self._timeout,
            follow_redirects=True,
            headers={"User-Agent": "NoneBot-ApexRankWatch/1.0"},
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def fetch_player_stats_auto(
        self, identifier: str, platform: str | None = None, use_uid: bool = False
    ) -> tuple[ApexPlayerStats, str]:
        if platform:
            normalized = normalize_platform(platform)
            stats = await self._fetch_player(identifier, normalized, use_uid)
            return stats, normalized

        for candidate in ("PC", "PS4", "X1", "SWITCH"):
            try:
                return await self._fetch_player(identifier, candidate, use_uid), candidate
            except PlayerNotFoundError:
                continue
        raise PlayerNotFoundError(identifier)

    async def fetch_current_season_info(self) -> SeasonInfo:
        html = await self._request_text_with_retry("https://apexseasons.online/")
        season_info = _parse_current_season(html)
        if season_info.season_url:
            season_html = await self._request_text_with_retry(season_info.season_url)
            _apply_season_page_overrides(season_info, season_html)
        return season_info

    async def _fetch_player(
        self, identifier: str, platform: str, use_uid: bool
    ) -> ApexPlayerStats:
        params = {"auth": self._api_key, "platform": platform}
        if use_uid:
            params["uid"] = identifier
        else:
            params["player"] = identifier
        data = await self._request_player_data("https://api.mozambiquehe.re/bridge", params)
        return _parse_player_stats(data, platform, identifier)

    async def _request_player_data(self, url: str, params: dict[str, Any]) -> dict[str, Any]:
        try:
            data = await self._request_json_with_retry(url, params)
        except httpx.HTTPStatusError as exc:
            if exc.response is not None and exc.response.status_code in {400, 404}:
                raise PlayerNotFoundError(params.get("player") or params.get("uid") or "") from exc
            raise
        if _is_player_not_found(data):
            raise PlayerNotFoundError(params.get("player") or params.get("uid") or "")
        return data

    async def _request_json_with_retry(self, url: str, params: dict[str, Any]) -> dict[str, Any]:
        last_error: Exception | None = None
        for attempt in range(self._max_retries + 1):
            if attempt:
                await asyncio.sleep(self._retry_delay(attempt))
            try:
                response = await self._client.get(url, params=params)
                if response.status_code == 429 or response.status_code >= 500:
                    raise httpx.HTTPStatusError(
                        "retryable status", request=response.request, response=response
                    )
                response.raise_for_status()
                return response.json()
            except (httpx.HTTPStatusError, httpx.RequestError) as exc:
                last_error = exc
                if (
                    isinstance(exc, httpx.HTTPStatusError)
                    and exc.response is not None
                    and exc.response.status_code not in {429}
                    and exc.response.status_code < 500
                ) or attempt >= self._max_retries:
                    raise
        if last_error:
            raise last_error
        raise RuntimeError("request failed")

    async def _request_text_with_retry(self, url: str) -> str:
        last_error: Exception | None = None
        for attempt in range(self._max_retries + 1):
            if attempt:
                await asyncio.sleep(self._retry_delay(attempt))
            try:
                response = await self._client.get(url)
                if response.status_code == 429 or response.status_code >= 500:
                    raise httpx.HTTPStatusError(
                        "retryable status", request=response.request, response=response
                    )
                response.raise_for_status()
                return response.text
            except (httpx.HTTPStatusError, httpx.RequestError) as exc:
                last_error = exc
                if (
                    isinstance(exc, httpx.HTTPStatusError)
                    and exc.response is not None
                    and exc.response.status_code not in {429}
                    and exc.response.status_code < 500
                ) or attempt >= self._max_retries:
                    raise
        if last_error:
            raise last_error
        raise RuntimeError("request failed")

    @staticmethod
    def _retry_delay(attempt: int) -> int:
        return min(5, max(1, 2 ** (attempt - 1)))


def _load_external_name_map() -> dict[str, str]:
    try:
        raw = json.loads(TRANSLATIONS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return raw if isinstance(raw, dict) else {}


EXTERNAL_NAME_MAP = _load_external_name_map()


def translate(name: str) -> str:
    return EXTERNAL_NAME_MAP.get(name) or NAME_MAP.get(name, name)


def translate_state(state_text: Any) -> str:
    if not state_text:
        return "离线"
    text = str(state_text).strip()
    numeric_state = _to_int(text)
    if numeric_state is not None and text.isdigit():
        text = {1: "online", 2: "inLobby", 3: "inMatch"}.get(numeric_state, "offline")
    time_suffix = ""
    match = re.search(r"\((\d{1,2}:\d{2})\)\s*$", text)
    if match:
        time_suffix = f" ({match.group(1)})"
        text = text[: match.start()].strip()
    return f"{translate(text)}{time_suffix}"


def normalize_platform(platform: str) -> str:
    key = platform.strip().lower()
    mapping = {
        "pc": "PC",
        "ps": "PS4",
        "ps4": "PS4",
        "ps5": "PS4",
        "playstation": "PS4",
        "xbox": "X1",
        "x1": "X1",
        "switch": "SWITCH",
        "ns": "SWITCH",
        "nintendo": "SWITCH",
    }
    return mapping.get(key, platform.strip().upper())


def is_score_drop_abnormal(old_score: int, new_score: int) -> bool:
    return old_score > 1000 and new_score < 10 and new_score < old_score


def is_likely_season_reset(old_score: int, new_score: int) -> bool:
    return new_score < old_score and (old_score - new_score) > 1000 and new_score >= 10


def _is_player_not_found(data: dict[str, Any]) -> bool:
    if not isinstance(data, dict):
        return True
    for key in ("Error", "error", "message"):
        value = data.get(key)
        if isinstance(value, str) and "not found" in value.lower():
            return True
    global_data = data.get("global")
    return not isinstance(global_data, dict) or not global_data.get("name")


def _parse_player_stats(
    data: dict[str, Any], platform: str, fallback_name: str
) -> ApexPlayerStats:
    global_data = data.get("global", {})
    realtime_data = data.get("realtime", {})
    rank_data = global_data.get("rank", {})
    legends_data = data.get("legends", {})
    selected_legend = translate(str(realtime_data.get("selectedLegend", "") or ""))
    legend_kills_rank = None
    legend_stats_data = (
        legends_data.get("selected", {}).get("data", [])
        if isinstance(legends_data, dict)
        else []
    )
    for stat in legend_stats_data:
        if not isinstance(stat, dict):
            continue
        if stat.get("name") == "BR Kills" or stat.get("key") == "specialEvent_kills":
            rank = stat.get("rank") or {}
            top_percent = _to_float(rank.get("topPercent"))
            if top_percent is not None:
                legend_kills_rank = LegendKillsRank(
                    value=_to_int(stat.get("value", 0)) or 0,
                    global_percent=f"{top_percent:.2f}",
                )
                break
    current_state = translate_state(
        realtime_data.get("currentStateAsText") or realtime_data.get("currentState") or "offline"
    )
    return ApexPlayerStats(
        name=str(global_data.get("name") or fallback_name),
        uid=str(global_data.get("uid") or ""),
        level=_to_int(global_data.get("level")) or 0,
        rank_score=_to_int(rank_data.get("rankScore")) or 0,
        rank_name=translate(str(rank_data.get("rankName") or "Unranked")),
        rank_div=_to_int(rank_data.get("rankDiv")) or 0,
        global_rank_percent=str(rank_data.get("ALStopPercentGlobal") or "未知"),
        is_online=_to_int(realtime_data.get("isOnline", 0)) == 1,
        selected_legend=selected_legend,
        legend_kills_rank=legend_kills_rank,
        current_state=current_state,
        is_in_lobby_or_match=("大厅" in current_state) or ("比赛" in current_state),
        platform=platform,
    )


def _to_int(value: Any) -> int | None:
    if value is None or value == "":
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        pass
    text = str(value).strip().replace(",", "").replace("，", "")
    try:
        return int(float(text))
    except (TypeError, ValueError):
        match = re.search(r"-?\d+(?:\.\d+)?", text)
        return int(float(match.group(0))) if match else None


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _parse_current_season(html: str) -> SeasonInfo:
    season_number: int | None = None
    season_name = ""
    season_url = ""
    start_date = "未知"
    end_date = "未知"
    timezone = "未知"
    update_time_hint = "未知"
    start_iso = ""
    end_iso = ""
    jsonld_blocks = JSONLD_SCRIPT_RE.findall(html)
    season_number, season_name, season_url = _extract_current_season_identity(html, jsonld_blocks)
    start_date, end_date, end_iso = _extract_current_season_dates(html)
    timezone, update_time_hint = _extract_current_season_metadata(html)
    return SeasonInfo(
        season_number=season_number,
        season_name=season_name,
        start_date=start_date,
        end_date=end_date,
        timezone=timezone,
        update_time_hint=update_time_hint,
        source="apexseasons.online",
        season_url=season_url,
        start_iso=start_iso,
        end_iso=end_iso,
    )


def _extract_current_season_identity(
    html: str, jsonld_blocks: list[str]
) -> tuple[int | None, str, str]:
    season_number, season_name, season_url = _extract_season_from_jsonld(jsonld_blocks)
    if season_number is not None and season_name:
        return season_number, season_name, season_url
    match = SEASON_LIVE_RE.search(html) or SEASON_STARTED_RE.search(html)
    if not match:
        return season_number, season_name, season_url
    return _to_int(match.group(1)), match.group(2).strip(), season_url


def _extract_current_season_dates(html: str) -> tuple[str, str, str]:
    start_date = "未知"
    end_date = "未知"
    end_iso = _extract_countdown_target(html) or ""
    if end_iso:
        end_date = _format_iso_date(end_iso)
    match = DATE_RANGE_RE.search(html)
    if match:
        start_date = f"{match.group(1)} {match.group(2)}"
        end_date = f"{match.group(3)} {match.group(4)}"
    return start_date, end_date, end_iso


def _extract_current_season_metadata(html: str) -> tuple[str, str]:
    timezone = "未知"
    update_time_hint = "未知"
    tz_match = TIMEZONE_RE.search(html)
    if tz_match:
        timezone = _clean_timezone(tz_match.group(1))
    hint_match = UPDATE_HINT_RE.search(html)
    if hint_match:
        update_time_hint = hint_match.group(1).strip()
    return timezone, update_time_hint


def _extract_season_from_jsonld(blocks: list[str]) -> tuple[int | None, str, str]:
    best_number: int | None = None
    best_name = ""
    best_url = ""
    best_position: int | None = None
    for block in blocks:
        try:
            data = json.loads(block)
        except Exception:
            continue
        items = [data] if isinstance(data, dict) else [item for item in data if isinstance(item, dict)]
        for item in items:
            if item.get("@type") != "ItemList":
                continue
            for element in item.get("itemListElement") or []:
                if not isinstance(element, dict):
                    continue
                number, name = _parse_season_name(str(element.get("name", "")))
                if number is None:
                    continue
                position = _to_int(element.get("position"))
                if best_position is None or (position is not None and position < best_position):
                    best_position = position
                    best_number = number
                    best_name = name
                    best_url = str(element.get("url", ""))
    return best_number, best_name, best_url


def _parse_season_name(text: str) -> tuple[int | None, str]:
    match = SEASON_NAME_RE.search(text)
    if not match:
        return None, ""
    return _to_int(match.group(1)), match.group(2).strip()


def _apply_season_page_overrides(season_info: SeasonInfo, html: str) -> None:
    start_iso, end_iso = _extract_event_dates_from_jsonld(html)
    if start_iso:
        season_info.start_iso = start_iso
        season_info.start_date = _format_iso_date(start_iso)
    if end_iso:
        season_info.end_iso = end_iso
        season_info.end_date = _format_iso_date(end_iso)
    start = _extract_date(html, "Start Date")
    end = _extract_date(html, "End Date")
    if start:
        season_info.start_date = start
    if end:
        season_info.end_date = end
    if season_info.start_date == "未知" or season_info.end_date == "未知":
        match = DATE_RANGE_LONG_RE.search(html)
        if match:
            season_info.start_date = match.group(1).strip()
            season_info.end_date = match.group(2).strip()
    tz_match = TIMEZONE_PAGE_RE.search(html)
    if tz_match:
        season_info.timezone = _clean_timezone(tz_match.group(1))


def _extract_event_dates_from_jsonld(html: str) -> tuple[str | None, str | None]:
    for block in JSONLD_SCRIPT_RE.findall(html):
        try:
            data = json.loads(block)
        except Exception:
            continue
        items = [data] if isinstance(data, dict) else [item for item in data if isinstance(item, dict)]
        for item in items:
            if item.get("@type") == "Event":
                return item.get("startDate"), item.get("endDate")
    return None, None


def _extract_countdown_target(html: str) -> str | None:
    match = COUNTDOWN_ARRAY_RE.search(html) or COUNTDOWN_STRING_RE.search(html)
    return match.group(1).strip() if match else None


def _extract_date(html: str, label: str) -> str | None:
    match = re.search(
        rf"{re.escape(label)}\s*:?\s*([A-Za-z]{{3,9}}\s+\d{{1,2}},?\s+\d{{4}})",
        html,
        re.IGNORECASE,
    )
    return match.group(1).strip() if match else None


def _format_iso_date(value: str) -> str:
    try:
        if value.endswith("Z"):
            value = value[:-1] + "+00:00"
        dt = datetime.fromisoformat(value)
        return dt.strftime("%Y-%m-%d %H:%M %Z").strip()
    except Exception:
        return value


def _clean_timezone(value: str) -> str:
    return re.sub(r"\s+", " ", value.replace("<!-- -->", " ").lstrip("·•-").strip()) or "未知"
