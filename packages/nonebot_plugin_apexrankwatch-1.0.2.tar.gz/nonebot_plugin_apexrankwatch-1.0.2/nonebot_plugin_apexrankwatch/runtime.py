from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import ClassVar
from zoneinfo import ZoneInfo

import nonebot
from nonebot import require
from nonebot.adapters import Event
from nonebot.adapters.onebot.v11 import Bot, GroupMessageEvent, Message, MessageEvent
from nonebot.log import logger

from .config import ApexRankWatchSettings
from .service import (
    ApexApiClient,
    ApexPlayerStats,
    PlayerNotFoundError,
    SeasonInfo,
    is_likely_season_reset,
    is_score_drop_abnormal,
    normalize_platform,
)
from .storage import GroupRecord, GroupStore, PlayerRecord
from .utils import now_epoch_ms, now_str, split_csv


@dataclass
class SessionContext:
    bot_id: str
    user_id: str
    group_id: str
    sender_role: str
    is_private: bool

    @property
    def is_group(self) -> bool:
        return bool(self.group_id)


@dataclass
class PollFetchResult:
    group_id: str
    group: GroupRecord
    player: PlayerRecord
    platform: str
    player_data: ApexPlayerStats | None = None
    not_found: bool = False
    error: Exception | None = None


class ApexRankWatchRuntime:
    keyword_command_blocklist: ClassVar[set[str]] = {
        "apexrank",
        "apexrankwatch",
        "apexranklist",
        "apexrankremove",
        "apexseason",
        "apextest",
        "apexhelp",
        "apex帮助",
        "apexrankhelp",
        "apexblacklist",
        "apex监控",
        "apex列表",
        "apex移除",
        "apex查询",
        "视奸",
        "持续视奸",
        "取消持续视奸",
        "apex赛季",
        "新赛季",
        "apex测试",
        "apex黑名单",
        "不准视奸",
        "apexban",
        "赛季关闭",
        "赛季开启",
    }

    def __init__(self, settings: ApexRankWatchSettings) -> None:
        self.settings = settings
        self.data_dir, self.settings_file, groups_file = self._resolve_data_files(settings.data_dir)
        self.store = GroupStore(groups_file)
        self.store.load()
        raw_settings = self._load_settings()
        self.runtime_blacklist = self._normalize_settings_list(
            raw_settings.get("runtime_blacklist", []),
            lowercase=True,
        )
        self.season_keyword_disabled_groups = self._normalize_settings_list(
            raw_settings.get("season_keyword_disabled_groups", []),
            lowercase=False,
        )
        self.api = ApexApiClient(
            api_key=settings.api_key,
            timeout_ms=settings.timeout_ms,
            max_retries=settings.max_retries,
            debug_enabled=settings.debug_logging,
        )
        self._stop_event = asyncio.Event()
        self._poll_task: asyncio.Task[None] | None = None
        self._poll_semaphore = asyncio.Semaphore(settings.poll_concurrency)
        self._runtime_started = False
        self._migrate_store_keys()

    async def startup(self) -> None:
        if self._runtime_started:
            return
        self._runtime_started = True
        self._ensure_poll_task()

    async def shutdown(self) -> None:
        self._stop_event.set()
        if self._poll_task is not None:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
        await self.api.close()

    def build_context(self, event: MessageEvent) -> SessionContext:
        sender = getattr(event, "sender", None)
        sender_role = str(getattr(sender, "role", "") or "").lower()
        group_id = str(event.group_id) if isinstance(event, GroupMessageEvent) else ""
        return SessionContext(
            bot_id=str(event.self_id),
            user_id=str(event.user_id),
            group_id=group_id,
            sender_role=sender_role,
            is_private=not group_id,
        )

    def command_args_to_text(self, args: Message | str | None) -> str:
        if args is None:
            return ""
        if isinstance(args, str):
            return args.strip()
        return args.extract_plain_text().strip()

    def extract_first_arg(self, text: str) -> tuple[str, str]:
        stripped = text.strip()
        if not stripped:
            return "", ""
        parts = stripped.split(maxsplit=1)
        return parts[0], parts[1] if len(parts) > 1 else ""

    def is_keyword_query(self, event: Event) -> bool:
        text = getattr(event, "get_plaintext", lambda: "")().strip()
        if not text or "赛季" not in text or text.startswith("/"):
            return False
        first = text.split(maxsplit=1)[0].lstrip("/").strip().lower()
        return first not in self.keyword_command_blocklist

    async def handle_help(self, ctx: SessionContext) -> str:
        deny = self.guard_access(ctx)
        if deny:
            return self.compose_time_message(deny)
        lines = [
            self.time_line(),
            "📘 nonebot-plugin-apexrankwatch 帮助",
            "——",
            "【查询】",
            "/apexrank <玩家|uid:...> [平台]",
            "别名: /apex查询 /视奸",
            "【监控】",
            "/apexrankwatch <玩家|uid:...> [平台]",
            "/apexranklist",
            "/apexrankremove <玩家|uid:...> [平台]",
            "【赛季】",
            "/apexseason",
            "群内消息包含“赛季”会自动回复，可用 /赛季关闭 和 /赛季开启 控制",
            "【管理】",
            "/apexblacklist <add|remove|list|clear> <玩家ID>",
            f"⏱️ 监控间隔: {self.settings.check_interval} 分钟",
            f"🎯 最小有效分数: {self.settings.min_valid_score}",
            "🎮 平台: PC / PS4 / X1 / SWITCH",
        ]
        return "\n".join(lines)

    async def handle_test(self, ctx: SessionContext) -> str:
        deny = self.guard_access(ctx)
        if deny:
            return self.compose_time_message(deny)
        if ctx.is_group:
            sent = await self.send_active_message(
                ctx.group_id, ctx.bot_id, "✅ Apex Legends 排名监控测试消息"
            )
            if sent:
                return self.compose_time_message(
                    "✅ 插件运行正常，测试主动消息已发送到当前群。"
                )
            return self.compose_time_message(
                "⚠️ 命令可用，但当前环境无法发送主动群消息。"
            )
        return self.compose_time_message("✅ 插件运行正常。")

    async def handle_rank(self, ctx: SessionContext, raw_args: str) -> str:
        deny = self.guard_access(ctx)
        if deny:
            return self.compose_time_message(deny)
        player_name, platform = self.parse_player_platform(raw_args)
        if not player_name:
            return self.compose_time_message(
                "⚠️ 请提供玩家名称，例如: /apexrank moeneri"
            )
        if self.is_blacklisted(player_name) or self.is_query_blocked(player_name):
            return self.compose_time_message(
                f"🚫 {player_name} 已被管理员加入黑名单，禁止查询。"
            )
        if not self.settings.api_key:
            return self.missing_api_key_text()
        identifier, use_uid = self.parse_identifier(player_name)
        if not identifier:
            return self.compose_time_message("⚠️ 请提供有效的玩家名称或 UID。")
        try:
            player_data, used_platform = await self.api.fetch_player_stats_auto(
                identifier, platform, use_uid
            )
        except PlayerNotFoundError:
            return self.compose_time_message(
                "⚠️ 未找到该玩家，请检查名称或显式指定平台。"
            )
        except Exception as exc:
            logger.error(f"apexrank request failed: {exc}")
            return self.api_request_failed_text("查询")
        if player_data.rank_score < self.settings.min_valid_score:
            return self.compose_time_message(
                f"⚠️ 查询到的分数为 {player_data.rank_score}，低于最小有效分数 {self.settings.min_valid_score}。"
            )
        player_data.platform = used_platform
        return self.format_player_rank_text(player_data)

    async def handle_season(self, ctx: SessionContext) -> str:
        deny = self.guard_access(ctx)
        if deny:
            return self.compose_time_message(deny)
        try:
            season_info = await self.api.fetch_current_season_info()
        except Exception as exc:
            logger.error(f"apexseason request failed: {exc}")
            return self.compose_time_message("❌ 查询失败，无法获取赛季信息。")
        return self.format_season_info(season_info)

    async def handle_watch(self, ctx: SessionContext, raw_args: str) -> str:
        deny = self.guard_access(ctx, require_group=True)
        if deny:
            return self.compose_time_message(deny)
        player_name, platform = self.parse_player_platform(raw_args)
        if not player_name:
            return self.compose_time_message(
                "⚠️ 请提供要监控的玩家名称，例如: /apexrankwatch moeneri"
            )
        if self.is_blacklisted(player_name) or self.is_query_blocked(player_name):
            return self.compose_time_message(
                f"🚫 {player_name} 已被管理员加入黑名单，禁止监控。"
            )
        if not self.settings.api_key:
            return self.missing_api_key_text()
        identifier, use_uid = self.parse_identifier(player_name)
        if not identifier:
            return self.compose_time_message("⚠️ 请提供有效的玩家名称或 UID。")
        try:
            player_data, used_platform = await self.api.fetch_player_stats_auto(
                identifier, platform, use_uid
            )
        except PlayerNotFoundError:
            return self.compose_time_message(
                "⚠️ 未找到该玩家，请检查名称或显式指定平台。"
            )
        except Exception as exc:
            logger.error(f"apexrankwatch request failed: {exc}")
            return self.api_request_failed_text("添加监控")
        if player_data.rank_score < self.settings.min_valid_score:
            return self.compose_time_message(
                f"⚠️ 查询到的分数为 {player_data.rank_score}，低于最小有效分数 {self.settings.min_valid_score}。"
            )
        normalized_platform = normalize_platform(used_platform)
        player_key = self.build_player_key(identifier, normalized_platform, use_uid)
        group = self.store.ensure_group(ctx.group_id, ctx.bot_id)
        if player_key in group.players:
            return self.compose_time_message(f"ℹ️ 本群已经在监控 {player_data.name} 了。")
        self.store.set_player(
            ctx.group_id,
            ctx.bot_id,
            player_key,
            PlayerRecord(
                player_name=player_data.name,
                platform=normalized_platform,
                lookup_id=identifier,
                use_uid=use_uid,
                rank_score=player_data.rank_score,
                rank_name=player_data.rank_name,
                rank_div=player_data.rank_div,
                last_checked=now_epoch_ms(),
                global_rank_percent=player_data.global_rank_percent,
                selected_legend=player_data.selected_legend,
                legend_kills_percent=player_data.legend_kills_rank.global_percent
                if player_data.legend_kills_rank
                else "",
            ),
        )
        self.store.save()
        await self.send_active_message(
            ctx.group_id, ctx.bot_id, f"测试消息: 已添加对 {player_data.name} 的排位监控。"
        )
        return "\n".join(
            [
                self.time_line(),
                f"✅ 成功添加对 {player_data.name} 的排位监控。",
                f"🕹️ 平台: {self.format_platform(normalized_platform)}",
                f"🏆 当前段位: {self.get_rank_display_text(player_data)}",
            ]
        )

    async def handle_list(self, ctx: SessionContext) -> str:
        deny = self.guard_access(ctx, require_group=True)
        if deny:
            return self.compose_time_message(deny)
        group = self.store.get_group(ctx.group_id)
        if group and ctx.bot_id and group.bot_id != ctx.bot_id:
            group.bot_id = ctx.bot_id
            self.store.save()
        if group is None or not group.players:
            return self.compose_time_message("ℹ️ 本群目前没有监控任何玩家。")
        lines = [self.time_line(), "📋 本群 Apex 排位监控列表"]
        for index, player in enumerate(group.players.values(), start=1):
            rank_display = (
                f"{player.rank_name} {player.rank_div}"
                if player.rank_div
                else player.rank_name
            )
            lines.extend(
                [
                    f"👤 玩家 {index}: {player.player_name}",
                    f"🕹️ 平台: {self.format_platform(player.platform)}",
                    f"🏆 段位: {rank_display}",
                    f"🎯 分数: {player.rank_score}",
                ]
            )
            if player.global_rank_percent and player.global_rank_percent != "未知":
                lines.append(f"🌐 全球排名: {player.global_rank_percent}%")
            if player.selected_legend:
                lines.append(f"🎭 当前英雄: {player.selected_legend}")
            lines.append("---")
        lines.append(f"🔢 总计: {len(group.players)} 个玩家")
        return "\n".join(lines)

    async def handle_remove(self, ctx: SessionContext, raw_args: str) -> str:
        deny = self.guard_access(ctx, require_group=True)
        if deny:
            return self.compose_time_message(deny)
        player_name, platform = self.parse_player_platform(raw_args)
        if not player_name:
            return self.compose_time_message(
                "⚠️ 请提供要移除监控的玩家名称，例如: /apexrankremove moeneri"
            )
        identifier, use_uid = self.parse_identifier(player_name)
        if not identifier:
            return self.compose_time_message("⚠️ 请提供有效的玩家名称或 UID。")
        group = self.store.get_group(ctx.group_id)
        if group and ctx.bot_id and group.bot_id != ctx.bot_id:
            group.bot_id = ctx.bot_id
            self.store.save()
        if group is None:
            return self.compose_time_message(f"ℹ️ 本群没有监控 {player_name}。")
        lookup_name = f"uid:{identifier}" if use_uid else identifier
        player_key = self.find_player_key(group, lookup_name, platform, use_uid)
        if player_key == "__MULTI__":
            return self.compose_time_message(
                "⚠️ 检测到同名多平台监控，请补充平台参数再移除。"
            )
        if not player_key or not self.store.remove_player(ctx.group_id, player_key):
            return self.compose_time_message(f"ℹ️ 本群没有监控 {player_name}。")
        self.store.save()
        return self.compose_time_message(f"✅ 已移除本群对 {player_name} 的监控。")

    async def handle_blacklist(self, ctx: SessionContext, raw_args: str) -> str:
        deny = self.guard_access(ctx)
        if deny:
            return self.compose_time_message(deny)
        admin_deny = self.guard_admin(ctx)
        if admin_deny:
            return self.compose_time_message(admin_deny)
        action, player_name = self.extract_first_arg(raw_args)
        action = action.lower()
        config_blacklist = self.get_config_blacklist()

        def format_items(items: set[str]) -> str:
            return "、".join(sorted(items)) if items else "无"

        if not action or action in {"help", "?", "h", "帮助"}:
            return "\n".join(
                [
                    self.time_line(),
                    "📛 Apex 黑名单管理",
                    "用法: /apexblacklist add <玩家ID>",
                    "用法: /apexblacklist remove <玩家ID>",
                    "用法: /apexblacklist list",
                    "用法: /apexblacklist clear",
                    f"配置黑名单: {format_items(config_blacklist)}",
                    f"动态黑名单: {format_items(self.runtime_blacklist)}",
                ]
            )
        if action in {"list", "ls", "查看", "列表"}:
            return "\n".join(
                [
                    self.time_line(),
                    "📛 Apex 黑名单列表",
                    f"配置黑名单: {format_items(config_blacklist)}",
                    f"动态黑名单: {format_items(self.runtime_blacklist)}",
                ]
            )
        if action in {"clear", "清空", "clean"}:
            if not self.runtime_blacklist:
                return self.compose_time_message("ℹ️ 动态黑名单已经为空。")
            self.runtime_blacklist.clear()
            self.save_settings()
            return self.compose_time_message("✅ 已清空动态黑名单。")
        items = sorted(split_csv(player_name))
        if not items:
            return self.compose_time_message(
                "⚠️ 请提供玩家 ID，例如: /apexblacklist add uid:1010153800824"
            )
        if action in {"add", "+", "新增", "添加", "加入"}:
            added: set[str] = set()
            existed_config: set[str] = set()
            existed_runtime: set[str] = set()
            for raw in items:
                name = self.normalize_lookup_value(raw)
                if name in config_blacklist:
                    existed_config.add(name)
                elif name in self.runtime_blacklist:
                    existed_runtime.add(name)
                else:
                    self.runtime_blacklist.add(name)
                    added.add(name)
            if added:
                self.save_settings()
            lines = [self.time_line(), f"✅ 已新增 {len(added)} 个动态黑名单 ID"]
            if added:
                lines.append(f"新增: {format_items(added)}")
            if existed_config:
                lines.append(f"已在配置黑名单中: {format_items(existed_config)}")
            if existed_runtime:
                lines.append(f"已在动态黑名单中: {format_items(existed_runtime)}")
            return "\n".join(lines)
        if action in {"remove", "del", "delete", "rm", "-", "移除", "删除"}:
            removed: set[str] = set()
            not_found: set[str] = set()
            in_config: set[str] = set()
            for raw in items:
                name = self.normalize_lookup_value(raw)
                if name in self.runtime_blacklist:
                    self.runtime_blacklist.remove(name)
                    removed.add(name)
                elif name in config_blacklist:
                    in_config.add(name)
                else:
                    not_found.add(name)
            if removed:
                self.save_settings()
            lines = [self.time_line(), f"✅ 已移除 {len(removed)} 个动态黑名单 ID"]
            if removed:
                lines.append(f"移除: {format_items(removed)}")
            if in_config:
                lines.append(f"以下 ID 来自配置黑名单，请改配置删除: {format_items(in_config)}")
            if not_found:
                lines.append(f"未找到: {format_items(not_found)}")
            return "\n".join(lines)
        return self.compose_time_message("⚠️ 未知操作，请使用 add/remove/list/clear。")

    async def handle_season_keyword_toggle(
        self, ctx: SessionContext, enabled: bool
    ) -> str:
        deny = self.guard_access(ctx, require_group=True)
        if deny:
            return self.compose_time_message(deny)
        admin_deny = self.guard_admin(ctx)
        if admin_deny:
            return self.compose_time_message(admin_deny)
        self.set_season_keyword_disabled(ctx.group_id, not enabled)
        if enabled:
            return self.compose_time_message("✅ 已开启本群“赛季”关键词自动回复。")
        return self.compose_time_message("🔕 已关闭本群“赛季”关键词自动回复。")

    async def handle_keyword_message(self, ctx: SessionContext) -> str | None:
        if ctx.group_id and self.is_season_keyword_disabled(ctx.group_id):
            return None
        deny = self.guard_access(ctx)
        if deny:
            return None
        try:
            season_info = await self.api.fetch_current_season_info()
        except Exception as exc:
            logger.error(f"keyword season request failed: {exc}")
            return None
        message = self.format_season_info(season_info)
        if ctx.group_id:
            message = f"{message}\n关闭自动回复: /赛季关闭"
        return message

    async def send_active_message(self, group_id: str, bot_id: str, message: str) -> bool:
        bot = self.select_bot(bot_id)
        if bot is None:
            logger.warning("no available onebot v11 bot found for proactive message")
            return False
        try:
            target = int(group_id) if group_id.isdigit() else group_id
            await bot.send_group_msg(group_id=target, message=message)
            return True
        except Exception as exc:
            logger.error(f"failed to send proactive group message: {exc}")
            return False

    def select_bot(self, bot_id: str) -> Bot | None:
        bots = nonebot.get_bots()
        if bot_id and bot_id in bots and isinstance(bots[bot_id], Bot):
            return bots[bot_id]
        for bot in bots.values():
            if isinstance(bot, Bot):
                return bot
        return None

    def parse_identifier(self, player_name: str) -> tuple[str, bool]:
        name = player_name.strip()
        lowered = name.lower()
        if lowered.startswith("uid:"):
            return name[4:].strip(), True
        if lowered.startswith("uuid:"):
            return name[5:].strip(), True
        return name, False

    def parse_player_platform(self, raw_args: str) -> tuple[str, str]:
        text = raw_args.strip()
        if not text:
            return "", ""
        parts = text.split()
        if len(parts) >= 2 and self.is_platform_token(parts[-1]):
            return " ".join(parts[:-1]).strip(), normalize_platform(parts[-1])
        return text, ""

    def is_platform_token(self, token: str) -> bool:
        return normalize_platform(token) in {"PC", "PS4", "X1", "SWITCH"}

    def build_player_key(self, lookup_id: str, platform: str, use_uid: bool) -> str:
        prefix = "uid:" if use_uid else "name:"
        return f"{prefix}{lookup_id.strip().lower()}@{platform}"

    def find_player_key(
        self, group: GroupRecord, player_name: str, platform: str, use_uid: bool
    ) -> str:
        identifier, inferred_uid = self.parse_identifier(player_name)
        use_uid = use_uid or inferred_uid
        if platform:
            key = self.build_player_key(identifier, normalize_platform(platform), use_uid)
            return key if key in group.players else ""
        prefix = "uid:" if use_uid else "name:"
        key_base = f"{prefix}{identifier.strip().lower()}@"
        matches = [key for key in group.players if key.startswith(key_base)]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            return "__MULTI__"
        return ""

    def get_config_blacklist(self) -> set[str]:
        return {
            self.normalize_lookup_value(item)
            for item in split_csv(self.settings.blacklist, lowercase=False)
        }

    def normalize_lookup_value(self, value: str) -> str:
        identifier, _ = self.parse_identifier(value)
        return (identifier or value).strip().lower()

    def is_blacklisted(self, player_name: str) -> bool:
        return self.normalize_lookup_value(player_name) in (
            self.get_config_blacklist() | self.runtime_blacklist
        )

    def is_query_blocked(self, player_name: str) -> bool:
        blocked = {
            self.normalize_lookup_value(item)
            for item in split_csv(self.settings.query_blocklist)
        }
        return self.normalize_lookup_value(player_name) in blocked

    def is_owner(self, user_id: str) -> bool:
        owners = split_csv(self.settings.owner_qq)
        superusers = {str(item) for item in nonebot.get_driver().config.superusers}
        return user_id in owners or user_id in superusers

    def is_admin(self, ctx: SessionContext) -> bool:
        return self.is_owner(ctx.user_id) or ctx.sender_role in {"admin", "owner"}

    def is_user_blacklisted(self, user_id: str) -> bool:
        return user_id in split_csv(self.settings.user_blacklist)

    def is_group_allowed(self, group_id: str) -> bool:
        if not self.settings.whitelist_enabled:
            return True
        return group_id in split_csv(self.settings.whitelist_groups)

    def guard_access(self, ctx: SessionContext, require_group: bool = False) -> str | None:
        if self.is_owner(ctx.user_id):
            return None
        if self.is_user_blacklisted(ctx.user_id):
            return "你的 QQ 已被禁止使用本插件。"
        if require_group and not ctx.is_group:
            return "该命令仅可在群聊中使用。"
        if ctx.is_private and not self.settings.allow_private:
            return "当前不允许私聊使用，请在群聊中使用。"
        if ctx.is_group and not self.is_group_allowed(ctx.group_id):
            return "本群不在白名单中，无法使用此插件。"
        return None

    def guard_admin(self, ctx: SessionContext) -> str | None:
        if self.is_admin(ctx):
            return None
        return "该命令仅管理员可用，请配置 owner_qq 或使用群管理员账号。"

    def _load_settings(self) -> dict:
        defaults = {"runtime_blacklist": [], "season_keyword_disabled_groups": []}
        if not self.settings_file.exists():
            return defaults
        raw = json.loads(self.settings_file.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            return defaults
        defaults.update(raw)
        return defaults

    def save_settings(self) -> None:
        payload = {
            "runtime_blacklist": sorted(self.runtime_blacklist),
            "season_keyword_disabled_groups": sorted(self.season_keyword_disabled_groups),
        }
        self.settings_file.parent.mkdir(parents=True, exist_ok=True)
        tmp_file = self.settings_file.with_suffix(".tmp")
        tmp_file.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        tmp_file.replace(self.settings_file)

    def _normalize_settings_list(self, value: object, *, lowercase: bool) -> set[str]:
        if not isinstance(value, list):
            return set()
        items = set()
        for item in value:
            text = str(item).strip()
            if not text:
                continue
            items.add(text.lower() if lowercase else text)
        return items

    def is_season_keyword_disabled(self, group_id: str) -> bool:
        return group_id in self.season_keyword_disabled_groups

    def set_season_keyword_disabled(self, group_id: str, disabled: bool) -> None:
        if disabled:
            self.season_keyword_disabled_groups.add(group_id)
        else:
            self.season_keyword_disabled_groups.discard(group_id)
        self.save_settings()

    def _resolve_data_files(self, data_dir: str) -> tuple[Path, Path, Path]:
        if data_dir:
            resolved_dir = Path(data_dir)
            return resolved_dir, resolved_dir / "settings.json", resolved_dir / "groups.json"

        require("nonebot_plugin_localstore")
        import nonebot_plugin_localstore as store

        settings_file = store.get_plugin_data_file("settings.json")
        groups_file = store.get_plugin_data_file("groups.json")
        resolved_dir = settings_file.parent

        legacy_candidates = [
            Path.cwd() / "data" / "apexrankwatch",
            Path.cwd() / "data" / "apex_rank_watch",
            resolved_dir.parent / "nonebot_plugin_apex_rank_watch",
        ]
        if settings_file.exists() or groups_file.exists():
            return resolved_dir, settings_file, groups_file
        for legacy_dir in legacy_candidates:
            legacy_settings_file = legacy_dir / "settings.json"
            legacy_groups_file = legacy_dir / "groups.json"
            if legacy_settings_file.exists() or legacy_groups_file.exists():
                return legacy_dir, legacy_settings_file, legacy_groups_file
        return resolved_dir, settings_file, groups_file

    def _migrate_store_keys(self) -> None:
        changed = False
        for _, group in self.store.iter_groups():
            new_players: dict[str, PlayerRecord] = {}
            for key, record in group.players.items():
                normalized_platform = normalize_platform(record.platform or "PC")
                lookup_id = record.lookup_id or record.player_name
                new_key = self.build_player_key(
                    lookup_id, normalized_platform, record.use_uid
                )
                record.platform = normalized_platform
                record.lookup_id = lookup_id
                new_players[new_key] = record
                if new_key != key:
                    changed = True
            group.players = new_players
        if changed:
            self.store.save()

    def _ensure_poll_task(self) -> None:
        if self._poll_task is not None and not self._poll_task.done():
            return
        self._poll_task = asyncio.create_task(self._poll_loop())

    async def _poll_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                await self._poll_once()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.error(f"poll loop failed: {exc}")
            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=self.settings.check_interval * 60,
                )
            except asyncio.TimeoutError:
                continue

    async def _poll_fetch_player(
        self,
        group_id: str,
        group: GroupRecord,
        player: PlayerRecord,
    ) -> PollFetchResult:
        async with self._poll_semaphore:
            try:
                player_data, _ = await self.api.fetch_player_stats_auto(
                    player.lookup_id,
                    player.platform,
                    player.use_uid,
                )
                return PollFetchResult(
                    group_id=group_id,
                    group=group,
                    player=player,
                    platform=player.platform,
                    player_data=player_data,
                )
            except PlayerNotFoundError:
                return PollFetchResult(
                    group_id=group_id,
                    group=group,
                    player=player,
                    platform=player.platform,
                    not_found=True,
                )
            except Exception as exc:
                return PollFetchResult(
                    group_id=group_id,
                    group=group,
                    player=player,
                    platform=player.platform,
                    error=exc,
                )

    async def _poll_once(self) -> None:
        if not self.settings.api_key:
            return
        jobs = [
            self._poll_fetch_player(group_id, group, player)
            for group_id, group in self.store.iter_groups()
            for player in group.players.values()
            if not self.is_blacklisted(player.player_name)
            and not self.is_query_blocked(player.player_name)
        ]
        if not jobs:
            return
        dirty = False
        results = await asyncio.gather(*jobs)
        for result in results:
            player = result.player
            if result.not_found:
                logger.warning(f"player not found during polling: {player.player_name}")
                continue
            if result.error or result.player_data is None:
                logger.error(f"poll fetch failed for {player.player_name}: {result.error}")
                continue
            player_data = result.player_data
            new_score = player_data.rank_score
            old_score = player.rank_score
            is_valid_score = new_score >= self.settings.min_valid_score
            is_abnormal_drop = is_score_drop_abnormal(old_score, new_score)
            is_season_reset = is_likely_season_reset(old_score, new_score)
            if is_valid_score and not is_abnormal_drop and new_score != old_score:
                diff = new_score - old_score
                diff_text = f"上升 {diff}" if diff > 0 else f"下降 {abs(diff)}"
                player.rank_score = new_score
                player.rank_name = player_data.rank_name
                player.rank_div = player_data.rank_div
                player.global_rank_percent = player_data.global_rank_percent
                player.selected_legend = player_data.selected_legend
                player.legend_kills_percent = (
                    player_data.legend_kills_rank.global_percent
                    if player_data.legend_kills_rank
                    else ""
                )
                player.last_checked = now_epoch_ms()
                dirty = True
                rank_display = (
                    f"{player.rank_name} {player.rank_div}"
                    if player.rank_div
                    else player.rank_name
                )
                lines = [
                    "📈 Apex 排位分数变化",
                    f"🕒 时间: {now_str()}",
                    f"👤 玩家: {player.player_name}",
                    f"🕹️ 平台: {self.format_platform(result.platform)}",
                    f"🎯 原分数: {old_score}",
                    f"🎯 当前分数: {new_score}",
                    f"🏆 段位: {rank_display}",
                    f"📊 变化: {diff_text}",
                ]
                if is_season_reset:
                    lines.append("⚠️ 注意: 检测到大幅分数下降，可能是赛季重置。")
                if (
                    player_data.global_rank_percent
                    and player_data.global_rank_percent != "未知"
                ):
                    lines.append(f"🌐 全球排名: {player_data.global_rank_percent}%")
                if player_data.is_online and player_data.selected_legend:
                    lines.append(f"🎭 当前英雄: {player_data.selected_legend}")
                if player_data.is_online and player_data.current_state:
                    lines.append(f"🎮 当前状态: {player_data.current_state}")
                await self.send_active_message(
                    result.group_id, result.group.bot_id, "\n".join(lines)
                )
        if dirty:
            self.store.save()

    def time_line(self) -> str:
        return f"🕒 时间: {now_str()}"

    def compose_time_message(self, text: str) -> str:
        return "\n".join([self.time_line(), text])

    def missing_api_key_text(self) -> str:
        return "\n".join(
            [
                self.time_line(),
                "⚠️ 请先在插件配置中填写 API Key。",
                "🔑 申请地址: https://portal.apexlegendsapi.com/",
            ]
        )

    def api_request_failed_text(self, action: str) -> str:
        return "\n".join(
            [
                self.time_line(),
                f"❌ {action}失败，请检查网络、API Key 是否有效，或稍后再试。",
                "🔑 申请地址: https://portal.apexlegendsapi.com/",
            ]
        )

    def format_platform(self, platform: str) -> str:
        return {
            "PC": "PC",
            "PS4": "PlayStation",
            "X1": "Xbox",
            "SWITCH": "Switch",
        }.get(platform, platform)

    def get_rank_display_text(self, player_data: ApexPlayerStats) -> str:
        rank_display = (
            f"{player_data.rank_name} {player_data.rank_div}"
            if player_data.rank_div
            else player_data.rank_name
        )
        return f"{rank_display} ({player_data.rank_score}分)"

    def format_player_rank_text(self, player_data: ApexPlayerStats) -> str:
        rank_display = (
            f"{player_data.rank_name} {player_data.rank_div}"
            if player_data.rank_div
            else player_data.rank_name
        )
        lines = [
            "🏅 Apex 段位信息",
            self.time_line(),
            f"👤 玩家: {player_data.name}",
            f"🕹️ 平台: {self.format_platform(player_data.platform)}",
            f"🆔 UID: {player_data.uid or '未知'}",
            f"🏆 段位: {rank_display}",
            f"🎯 分数: {player_data.rank_score}",
            f"📈 等级: {player_data.level}",
            f"🟢 在线状态: {'在线' if player_data.is_online else '离线'}",
        ]
        if player_data.global_rank_percent and player_data.global_rank_percent != "未知":
            lines.append(f"🌐 全球排名: {player_data.global_rank_percent}%")
        if player_data.selected_legend:
            lines.append(f"🎭 当前英雄: {player_data.selected_legend}")
        if player_data.legend_kills_rank:
            lines.append(f"🔫 击杀排名: 全球 {player_data.legend_kills_rank.global_percent}%")
        if player_data.current_state and player_data.is_online:
            lines.append(f"🎮 当前状态: {player_data.current_state}")
        return "\n".join(lines)

    def format_season_info(self, season_info: SeasonInfo) -> str:
        season_label = "未知"
        if season_info.season_number is not None:
            season_label = (
                f"S{season_info.season_number} · {season_info.season_name}"
                if season_info.season_name
                else f"S{season_info.season_number}"
            )
        lines = [
            self.time_line(),
            "🗓️ Apex 赛季时间信息",
            f"🏷️ 当前赛季: {season_label}",
        ]
        start_bj = self.to_beijing_time(season_info.start_iso)
        end_bj = self.to_beijing_time(season_info.end_iso)
        if start_bj:
            lines.append(f"🟢 开始时间(北京时间): {start_bj}")
        elif season_info.start_date and season_info.start_date != "未知":
            lines.append(f"🟢 开始时间: {season_info.start_date}")
        if end_bj:
            lines.append(f"🔴 结束时间(北京时间): {end_bj}")
        elif season_info.end_date and season_info.end_date != "未知":
            lines.append(f"🔴 结束时间: {season_info.end_date}")
        remaining = self.format_remaining(season_info.end_iso)
        if remaining:
            lines.append(f"⏳ 剩余时间: {remaining}")
        progress = self.format_progress(season_info.start_iso, season_info.end_iso)
        if progress:
            lines.append(f"📊 赛季进度: {progress}")
        lines.append(f"ℹ️ 数据来源: {season_info.source}")
        lines.append("⚠️ 提示: 赛季数据来自第三方站点，仅供参考。")
        return "\n".join(lines)

    def to_beijing_time(self, iso_value: str) -> str:
        if not iso_value:
            return ""
        try:
            value = iso_value[:-1] + "+00:00" if iso_value.endswith("Z") else iso_value
            dt = datetime.fromisoformat(value)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            bj = dt.astimezone(ZoneInfo("Asia/Shanghai"))
            return bj.strftime("%Y-%m-%d %H:%M")
        except Exception:
            return ""

    def format_remaining(self, end_iso: str) -> str:
        if not end_iso:
            return ""
        try:
            value = end_iso[:-1] + "+00:00" if end_iso.endswith("Z") else end_iso
            end_dt = datetime.fromisoformat(value)
            if end_dt.tzinfo is None:
                end_dt = end_dt.replace(tzinfo=timezone.utc)
            delta = int((end_dt - datetime.now(timezone.utc)).total_seconds())
            if delta <= 0:
                return "已结束"
            days = delta // 86400
            hours = (delta % 86400) // 3600
            minutes = (delta % 3600) // 60
            return f"{days} 天 {hours} 小时 {minutes} 分钟"
        except Exception:
            return ""

    def format_progress(self, start_iso: str, end_iso: str) -> str:
        if not start_iso or not end_iso:
            return ""
        try:
            start_value = start_iso[:-1] + "+00:00" if start_iso.endswith("Z") else start_iso
            end_value = end_iso[:-1] + "+00:00" if end_iso.endswith("Z") else end_iso
            start_dt = datetime.fromisoformat(start_value)
            end_dt = datetime.fromisoformat(end_value)
            if start_dt.tzinfo is None:
                start_dt = start_dt.replace(tzinfo=timezone.utc)
            if end_dt.tzinfo is None:
                end_dt = end_dt.replace(tzinfo=timezone.utc)
            total_seconds = (end_dt - start_dt).total_seconds()
            if total_seconds <= 0:
                return ""
            elapsed_seconds = max(
                0.0,
                min(
                    total_seconds,
                    (datetime.now(timezone.utc) - start_dt).total_seconds(),
                ),
            )
            percent = elapsed_seconds / total_seconds * 100
            return f"{percent:.2f}%"
        except Exception:
            return ""
