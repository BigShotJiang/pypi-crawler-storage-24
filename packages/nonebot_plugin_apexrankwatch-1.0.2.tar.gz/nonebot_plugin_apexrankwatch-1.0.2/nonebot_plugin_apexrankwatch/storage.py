from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass
class PlayerRecord:
    player_name: str
    platform: str
    lookup_id: str
    use_uid: bool
    rank_score: int
    rank_name: str
    rank_div: int
    last_checked: int
    global_rank_percent: str = "未知"
    selected_legend: str = ""
    legend_kills_percent: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> PlayerRecord:
        return cls(
            player_name=str(data.get("player_name", "")),
            platform=str(data.get("platform", "PC") or "PC"),
            lookup_id=str(data.get("lookup_id", data.get("player_name", ""))),
            use_uid=bool(data.get("use_uid", False)),
            rank_score=int(data.get("rank_score", 0) or 0),
            rank_name=str(data.get("rank_name", "")),
            rank_div=int(data.get("rank_div", 0) or 0),
            last_checked=int(data.get("last_checked", 0) or 0),
            global_rank_percent=str(data.get("global_rank_percent", "未知")),
            selected_legend=str(data.get("selected_legend", "")),
            legend_kills_percent=str(data.get("legend_kills_percent", "")),
        )


@dataclass
class GroupRecord:
    group_id: str
    bot_id: str
    players: dict[str, PlayerRecord]

    def to_dict(self) -> dict:
        return {
            "group_id": self.group_id,
            "bot_id": self.bot_id,
            "players": {key: record.to_dict() for key, record in self.players.items()},
        }

    @classmethod
    def from_dict(cls, group_id: str, data: dict) -> GroupRecord:
        players_raw = data.get("players", {}) if isinstance(data, dict) else {}
        return cls(
            group_id=group_id,
            bot_id=str(data.get("bot_id", "")),
            players={
                key: PlayerRecord.from_dict(value)
                for key, value in players_raw.items()
                if isinstance(value, dict)
            },
        )


class GroupStore:
    def __init__(self, data_file: Path) -> None:
        self._data_file = data_file
        self._groups: dict[str, GroupRecord] = {}

    def load(self) -> None:
        if not self._data_file.exists():
            return
        raw = json.loads(self._data_file.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("groups.json root node must be an object")
        self._groups = {
            key: GroupRecord.from_dict(key, value)
            for key, value in raw.items()
            if isinstance(value, dict)
        }

    def save(self) -> None:
        self._data_file.parent.mkdir(parents=True, exist_ok=True)
        payload = {key: group.to_dict() for key, group in self._groups.items()}
        tmp_file = self._data_file.with_suffix(".tmp")
        tmp_file.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        tmp_file.replace(self._data_file)

    def get_group(self, group_id: str) -> GroupRecord | None:
        return self._groups.get(group_id)

    def ensure_group(self, group_id: str, bot_id: str) -> GroupRecord:
        group = self._groups.get(group_id)
        if group is None:
            group = GroupRecord(group_id=group_id, bot_id=bot_id, players={})
            self._groups[group_id] = group
        elif bot_id:
            group.bot_id = bot_id
        return group

    def set_player(self, group_id: str, bot_id: str, player_key: str, record: PlayerRecord) -> None:
        group = self.ensure_group(group_id, bot_id)
        group.players[player_key] = record

    def remove_player(self, group_id: str, player_key: str) -> bool:
        group = self._groups.get(group_id)
        if group is None or player_key not in group.players:
            return False
        del group.players[player_key]
        if not group.players:
            del self._groups[group_id]
        return True

    def iter_groups(self) -> list[tuple[str, GroupRecord]]:
        return list(self._groups.items())
