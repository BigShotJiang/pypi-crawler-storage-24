from __future__ import annotations

from datetime import datetime, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

try:
    SHANGHAI_TZ = ZoneInfo("Asia/Shanghai")
except ZoneInfoNotFoundError:
    SHANGHAI_TZ = timezone.utc


def split_csv(raw: str, *, lowercase: bool = False) -> set[str]:
    if not raw:
        return set()
    normalized = str(raw).replace("，", ",")
    values: set[str] = set()
    for item in normalized.split(","):
        text = item.strip()
        if not text:
            continue
        values.add(text.lower() if lowercase else text)
    return values


def now_shanghai() -> datetime:
    return datetime.now(SHANGHAI_TZ)


def now_str() -> str:
    return now_shanghai().strftime("%Y/%m/%d %H:%M:%S")


def now_epoch_ms() -> int:
    return int(now_shanghai().timestamp() * 1000)
