from __future__ import annotations

from nonebot.compat import BaseModel, field_validator, model_dump, type_validate_python


class ApexRankWatchSettings(BaseModel):
    api_key: str = ""
    debug_logging: bool = False
    check_interval: int = 2
    timeout_ms: int = 10000
    max_retries: int = 3
    min_valid_score: int = 1
    blacklist: str = ""
    query_blocklist: str = ""
    user_blacklist: str = ""
    owner_qq: str = ""
    whitelist_enabled: bool = False
    whitelist_groups: str = ""
    allow_private: bool = True
    data_dir: str = ""
    command_priority: int = 10
    keyword_priority: int = 20
    poll_concurrency: int = 5

    @field_validator("check_interval")
    @classmethod
    def validate_check_interval(cls, value: int) -> int:
        return max(1, value)

    @field_validator("timeout_ms")
    @classmethod
    def validate_timeout_ms(cls, value: int) -> int:
        return max(1000, value)

    @field_validator("max_retries", "min_valid_score", "command_priority", "keyword_priority")
    @classmethod
    def validate_non_negative(cls, value: int) -> int:
        return max(0, value)

    @field_validator("poll_concurrency")
    @classmethod
    def validate_poll_concurrency(cls, value: int) -> int:
        return max(1, value)


class Config(BaseModel):
    apexrankwatch: ApexRankWatchSettings = ApexRankWatchSettings()
    apex_rank_watch: ApexRankWatchSettings | None = None

    def resolve(self) -> ApexRankWatchSettings:
        data: dict[str, object] = {}
        if self.apex_rank_watch is not None:
            data.update(model_dump(self.apex_rank_watch))
        data.update(model_dump(self.apexrankwatch, exclude_unset=True))
        return type_validate_python(ApexRankWatchSettings, data)
