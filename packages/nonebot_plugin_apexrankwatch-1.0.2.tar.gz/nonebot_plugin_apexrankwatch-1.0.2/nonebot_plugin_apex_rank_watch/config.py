from apexrankwatch_shared.config import *  # noqa: F401,F403
