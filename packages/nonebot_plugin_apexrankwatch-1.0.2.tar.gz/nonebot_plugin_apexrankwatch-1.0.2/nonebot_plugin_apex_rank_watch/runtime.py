from __future__ import annotations

from pathlib import Path

from nonebot import require

from apexrankwatch_shared.runtime import *  # noqa: F401,F403
from apexrankwatch_shared.runtime import ApexRankWatchRuntime as BaseApexRankWatchRuntime


class ApexRankWatchRuntime(BaseApexRankWatchRuntime):
    def _resolve_data_files(self, data_dir: str) -> tuple[Path, Path, Path]:
        if data_dir:
            resolved_dir = Path(data_dir)
            return resolved_dir, resolved_dir / "settings.json", resolved_dir / "groups.json"

        require("nonebot_plugin_localstore")
        import nonebot_plugin_localstore as store

        settings_file = store.get_plugin_data_file("settings.json")
        groups_file = store.get_plugin_data_file("groups.json")
        resolved_dir = settings_file.parent

        legacy_candidates = [
            Path.cwd() / "data" / "apexrankwatch",
            Path.cwd() / "data" / "apex_rank_watch",
            resolved_dir.parent / "nonebot_plugin_apexrankwatch",
        ]
        if settings_file.exists() or groups_file.exists():
            return resolved_dir, settings_file, groups_file
        for legacy_dir in legacy_candidates:
            legacy_settings_file = legacy_dir / "settings.json"
            legacy_groups_file = legacy_dir / "groups.json"
            if legacy_settings_file.exists() or legacy_groups_file.exists():
                return legacy_dir, legacy_settings_file, legacy_groups_file
        return resolved_dir, settings_file, groups_file
