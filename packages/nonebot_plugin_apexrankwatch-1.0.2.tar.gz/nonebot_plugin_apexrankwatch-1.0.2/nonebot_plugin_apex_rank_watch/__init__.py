from __future__ import annotations

from nonebot import get_driver, get_plugin_config, on_command, on_message
from nonebot.adapters.onebot.v11 import GroupMessageEvent, Message, MessageEvent
from nonebot.params import CommandArg
from nonebot.plugin import PluginMetadata
from nonebot.rule import Rule

from .config import Config
from .runtime import ApexRankWatchRuntime

plugin_config = get_plugin_config(Config).resolve()
runtime = ApexRankWatchRuntime(plugin_config)

__plugin_meta__ = PluginMetadata(
    name="nonebot-plugin-apexrankwatch",
    description="查询 Apex Legends 排位并在群内持续监控 RP 变化。",
    usage=(
        "/apexrank <玩家|uid:...> [平台]\n"
        "/apexrankwatch <玩家|uid:...> [平台]\n"
        "/apexranklist\n"
        "/apexrankremove <玩家|uid:...> [平台]\n"
        "/apexseason\n"
        "/apexblacklist <add|remove|list|clear> <玩家ID>"
    ),
    type="application",
    homepage="https://github.com/moeneri/nonebot-plugin-apexwatch",
    config=Config,
    supported_adapters={"~onebot.v11"},
)


async def _is_season_keyword(event: MessageEvent) -> bool:
    return runtime.is_keyword_query(event)


help_matcher = on_command(
    "apexhelp",
    aliases={"apex帮助", "apexrankhelp"},
    priority=plugin_config.command_priority,
    block=True,
)
test_matcher = on_command(
    "apextest",
    aliases={"apex测试"},
    priority=plugin_config.command_priority,
    block=True,
)
rank_matcher = on_command(
    "apexrank",
    aliases={"apex查询", "视奸"},
    priority=plugin_config.command_priority,
    block=True,
)
season_matcher = on_command(
    "apexseason",
    aliases={"apex赛季", "新赛季"},
    priority=plugin_config.command_priority,
    block=True,
)
watch_matcher = on_command(
    "apexrankwatch",
    aliases={"apex监控", "持续视奸"},
    priority=plugin_config.command_priority,
    block=True,
)
list_matcher = on_command(
    "apexranklist",
    aliases={"apex列表"},
    priority=plugin_config.command_priority,
    block=True,
)
remove_matcher = on_command(
    "apexrankremove",
    aliases={"apex移除", "取消持续视奸"},
    priority=plugin_config.command_priority,
    block=True,
)
blacklist_matcher = on_command(
    "apexblacklist",
    aliases={"apex黑名单", "不准视奸", "apexban"},
    priority=plugin_config.command_priority,
    block=True,
)
season_off_matcher = on_command("赛季关闭", priority=plugin_config.command_priority, block=True)
season_on_matcher = on_command("赛季开启", priority=plugin_config.command_priority, block=True)
keyword_matcher = on_message(
    rule=Rule(_is_season_keyword),
    priority=plugin_config.keyword_priority,
    block=False,
)


@help_matcher.handle()
async def _(event: MessageEvent) -> None:
    await help_matcher.finish(await runtime.handle_help(runtime.build_context(event)))


@test_matcher.handle()
async def _(event: MessageEvent) -> None:
    await test_matcher.finish(await runtime.handle_test(runtime.build_context(event)))


@rank_matcher.handle()
async def _(event: MessageEvent, args: Message = CommandArg()) -> None:
    await rank_matcher.finish(
        await runtime.handle_rank(runtime.build_context(event), runtime.command_args_to_text(args))
    )


@season_matcher.handle()
async def _(event: MessageEvent) -> None:
    await season_matcher.finish(await runtime.handle_season(runtime.build_context(event)))


@watch_matcher.handle()
async def _(event: GroupMessageEvent, args: Message = CommandArg()) -> None:
    await watch_matcher.finish(
        await runtime.handle_watch(runtime.build_context(event), runtime.command_args_to_text(args))
    )


@list_matcher.handle()
async def _(event: GroupMessageEvent) -> None:
    await list_matcher.finish(await runtime.handle_list(runtime.build_context(event)))


@remove_matcher.handle()
async def _(event: GroupMessageEvent, args: Message = CommandArg()) -> None:
    await remove_matcher.finish(
        await runtime.handle_remove(runtime.build_context(event), runtime.command_args_to_text(args))
    )


@blacklist_matcher.handle()
async def _(event: MessageEvent, args: Message = CommandArg()) -> None:
    await blacklist_matcher.finish(
        await runtime.handle_blacklist(runtime.build_context(event), runtime.command_args_to_text(args))
    )


@season_off_matcher.handle()
async def _(event: GroupMessageEvent) -> None:
    await season_off_matcher.finish(
        await runtime.handle_season_keyword_toggle(runtime.build_context(event), False)
    )


@season_on_matcher.handle()
async def _(event: GroupMessageEvent) -> None:
    await season_on_matcher.finish(
        await runtime.handle_season_keyword_toggle(runtime.build_context(event), True)
    )


@keyword_matcher.handle()
async def _(event: MessageEvent) -> None:
    message = await runtime.handle_keyword_message(runtime.build_context(event))
    if message:
        await keyword_matcher.finish(message)


driver = get_driver()
driver.on_startup(runtime.startup)
driver.on_shutdown(runtime.shutdown)
