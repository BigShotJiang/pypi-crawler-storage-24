# nonebot-plugin-apexrankwatch

使用了 CodeX vibe coding。

一个基于 `NoneBot2` 和 `OneBot V11` 的 Apex Legends 排位查询与群监控插件，保留了常用中文别名与 emoji 风格消息，适合群内快速查询、持续监控 RP 变化和查看赛季信息。

## 功能

- 查询玩家排位、RP、等级、在线状态、当前英雄
- 支持玩家名查询，也支持 `uid:` / `uuid:` 查询
- 支持群内持续监控，RP 变化后自动推送通知
- 支持查询当前赛季信息
- 支持赛季关键词自动回复，可按群开启或关闭
- 支持玩家黑名单、查询黑名单、用户黑名单、群白名单
- 保留常用中文别名和 emoji 风格消息

## 环境要求

- Python `3.10+`
- NoneBot2 `2.4.4+`
- OneBot V11 适配器

## 安装

发布到 PyPI 后可使用：

```bash
pip install nonebot-plugin-apexrankwatch
```

也可使用 `nb-cli` 安装：

```bash
nb plugin install nonebot-plugin-apexrankwatch
```

## 加载插件

在 `pyproject.toml` 中添加：

```toml
[tool.nonebot]
plugins = ["nonebot_plugin_apexrankwatch"]
```

## 配置

推荐将配置写入 `.env`、`.env.prod` 或你自己的环境配置文件。

最小配置：

```dotenv
APEXRANKWATCH__API_KEY=your_apex_api_key
APEXRANKWATCH__CHECK_INTERVAL=2
APEXRANKWATCH__TIMEOUT_MS=10000
APEXRANKWATCH__MAX_RETRIES=3
APEXRANKWATCH__MIN_VALID_SCORE=1
APEXRANKWATCH__ALLOW_PRIVATE=true
```

配置项：

| 环境变量 | 默认值 | 说明 |
| --- | --- | --- |
| `APEXRANKWATCH__API_KEY` | 空 | Apex API Key |
| `APEXRANKWATCH__DEBUG_LOGGING` | `false` | 是否开启调试日志 |
| `APEXRANKWATCH__CHECK_INTERVAL` | `2` | 轮询间隔，单位分钟 |
| `APEXRANKWATCH__TIMEOUT_MS` | `10000` | HTTP 请求超时，单位毫秒 |
| `APEXRANKWATCH__MAX_RETRIES` | `3` | 请求失败重试次数 |
| `APEXRANKWATCH__MIN_VALID_SCORE` | `1` | 最小有效分数 |
| `APEXRANKWATCH__BLACKLIST` | 空 | 禁止查询和监控的玩家 ID，逗号分隔 |
| `APEXRANKWATCH__QUERY_BLOCKLIST` | 空 | 仅禁止查询的玩家 ID，逗号分隔 |
| `APEXRANKWATCH__USER_BLACKLIST` | 空 | 禁止使用插件的用户 ID，逗号分隔 |
| `APEXRANKWATCH__OWNER_QQ` | 空 | 插件管理员 QQ，逗号分隔 |
| `APEXRANKWATCH__WHITELIST_ENABLED` | `false` | 是否启用群白名单模式 |
| `APEXRANKWATCH__WHITELIST_GROUPS` | 空 | 允许使用插件的群号，逗号分隔 |
| `APEXRANKWATCH__ALLOW_PRIVATE` | `true` | 是否允许私聊使用 |

## 触发示例

- `/apexrank 玩家名`
- `/apexrank uid:100123456 pc`
- `/apexrankwatch 玩家名`
- `/apexseason`

## 命令

- `/apexhelp`
- `/apextest`
- `/apexrank <玩家名|uid:...> [平台]`
- `/apexrankwatch <玩家名|uid:...> [平台]`
- `/apexranklist`
- `/apexrankremove <玩家名|uid:...> [平台]`
- `/apexseason`
- `/apexblacklist <add|remove|list|clear> <玩家ID>`
- `/赛季关闭`
- `/赛季开启`

常用别名：

- 查询：`/apex查询`、`/视奸`
- 监控：`/apex监控`、`/持续视奸`
- 移除：`/apex移除`、`/取消持续视奸`
- 赛季：`/apex赛季`、`/新赛季`
- 帮助：`/apex帮助`
- 黑名单：`/apex黑名单`、`/不准视奸`、`/apexban`

## 仓库

- GitHub: [moeneri/nonebot-plugin-apexwatch](https://github.com/moeneri/nonebot-plugin-apexwatch)
- PyPI: [nonebot-plugin-apexrankwatch](https://pypi.org/project/nonebot-plugin-apexrankwatch/)

## License

MIT
