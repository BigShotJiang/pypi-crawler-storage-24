# -*- coding: utf-8 -*-
"""
Factory Queue 框架全面测试脚本
测试各种常用场景和边界情况
"""
import time
import sys
from datetime import datetime
from pathlib import Path

# 添加模块路径
sys.path.insert(0, str(Path(__file__).parent))

from factory_queue import Factory, ResourceConfig


class TestResult:
    """测试结果记录"""
    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.error = None
        self.duration = 0
        self.details = {}
    
    def __str__(self):
        status = "✓ 通过" if self.passed else "✗ 失败"
        result = f"[{status}] {self.name} (耗时: {self.duration:.2f}秒)"
        if self.error:
            result += f"\n  错误: {self.error}"
        if self.details:
            for key, value in self.details.items():
                result += f"\n  {key}: {value}"
        return result


def test_simple_chain():
    """测试1: 简单链式流水线"""
    result = TestResult("简单链式流水线")
    start_time = time.time()
    
    try:
        process_times = []
        
        def producer(data):
            """生产数据"""
            t = time.time()
            time.sleep(0.01)  # 模拟处理
            process_times.append(('producer', time.time() - t))
            return data * 2
        
        def processor(data):
            """处理数据"""
            t = time.time()
            time.sleep(0.01)
            process_times.append(('processor', time.time() - t))
            return data + 10
        
        def consumer(data):
            """消费数据"""
            t = time.time()
            time.sleep(0.01)
            process_times.append(('consumer', time.time() - t))
        
        # 创建流水线
        config = ResourceConfig(max_queue_size=100, max_memory_mb=500)
        factory = Factory(resource_config=config)
        
        head = factory.head(producer, name="producer")
        node1 = head.create_node(processor, name="processor")
        node2 = node1.create_node(consumer, name="consumer")
        
        # 启动并投喂数据
        factory.start()
        
        test_data = list(range(10))
        for data in test_data:
            factory.feed(data)
        
        factory.end_feed()
        factory.wait_complete(timeout=30)
        
        # 验证
        stats = factory.stats
        result.details['队列统计'] = len(stats.get('queues', {}))
        result.details['处理节点数'] = len(process_times)
        result.details['平均处理时间'] = f"{sum(t for _, t in process_times) / len(process_times):.4f}秒"
        
        if len(process_times) >= 30:  # 至少处理了30次（10条数据 * 3个节点）
            result.passed = True
        else:
            result.error = f"处理次数不足: {len(process_times)}"
        
        factory.close()
        
    except Exception as e:
        result.error = str(e)
    
    result.duration = time.time() - start_time
    return result


def test_fork_chain():
    """测试2: 分叉链式流水线"""
    result = TestResult("分叉链式流水线")
    start_time = time.time()
    
    try:
        counters = {'branch_a': 0, 'branch_b': 0}
        
        def producer(data):
            """生产数据，返回元组分发到不同分支"""
            return (data * 2, data * 3)  # 位置0->feed0, 位置1->feed1
        
        def branch_a(data):
            """分支A处理"""
            time.sleep(0.01)
            counters['branch_a'] += 1
        
        def branch_b(data):
            """分支B处理"""
            time.sleep(0.01)
            counters['branch_b'] += 1
        
        config = ResourceConfig(max_queue_size=100, max_memory_mb=500)
        factory = Factory(resource_config=config)
        
        head = factory.head(producer, name="producer")
        node_a = head.create_node(branch_a, feed=0, name="branch_a")
        node_b = head.create_node(branch_b, feed=1, name="branch_b")
        
        factory.start()
        
        for i in range(10):
            factory.feed(i)
        
        factory.end_feed()
        factory.wait_complete(timeout=30)
        
        result.details['分支A处理数'] = counters['branch_a']
        result.details['分支B处理数'] = counters['branch_b']
        
        if counters['branch_a'] == 10 and counters['branch_b'] == 10:
            result.passed = True
        else:
            result.error = f"分支处理数不匹配"
        
        factory.close()
        
    except Exception as e:
        result.error = str(e)
    
    result.duration = time.time() - start_time
    return result


def test_yield_generator():
    """测试3: 生成器yield流式处理"""
    result = TestResult("生成器yield流式处理")
    start_time = time.time()
    
    try:
        consumer_count = 0
        
        def producer_with_yield(data):
            """使用yield产生多个数据"""
            t = time.time()
            for i in range(5):
                time.sleep(0.005)
                yield data * 10 + i
        
        def consumer(data):
            """消费数据"""
            nonlocal consumer_count
            time.sleep(0.01)
            consumer_count += 1
        
        config = ResourceConfig(max_queue_size=100, max_memory_mb=500)
        factory = Factory(resource_config=config)
        
        head = factory.head(producer_with_yield, name="producer")
        node1 = head.create_node(consumer, name="consumer")
        
        factory.start()
        
        for i in range(10):
            factory.feed(i)
        
        factory.end_feed()
        factory.wait_complete(timeout=30)
        
        result.details['消费数据量'] = consumer_count
        result.details['期望数据量'] = 50  # 10条输入 * 5次yield
        
        if consumer_count == 50:
            result.passed = True
        else:
            result.error = f"数据量不匹配: 期望50, 实际{consumer_count}"
        
        factory.close()
        
    except Exception as e:
        result.error = str(e)
    
    result.duration = time.time() - start_time
    return result


def test_queue_full_backpressure():
    """测试4: 队列满载背压控制"""
    result = TestResult("队列满载背压控制")
    start_time = time.time()
    
    try:
        queue_sizes = []
        
        def fast_producer(data):
            """快速生产者"""
            return data
        
        def slow_consumer(data):
            """慢速消费者"""
            time.sleep(0.1)  # 故意慢速处理
        
        config = ResourceConfig(max_queue_size=20, max_memory_mb=500)  # 小队列
        factory = Factory(resource_config=config)
        
        head = factory.head(fast_producer, name="producer", node_num=2)
        node1 = head.create_node(slow_consumer, name="consumer", 
                                 output_queue_size=20, node_num=1)  # 单线程慢速消费
        
        factory.start()
        
        # 快速投喂大量数据
        for i in range(50):
            factory.feed(i)
            # 定期检查队列大小
            if i % 10 == 0:
                stats = factory.stats
                for q_name, q_stats in stats.get('queues', {}).items():
                    if 'producer_feed' in q_name:
                        queue_sizes.append(q_stats['pending'])
        
        factory.end_feed()
        factory.wait_complete(timeout=60)
        
        stats = factory.stats
        max_queue_size = 0
        for q_name, q_stats in stats.get('queues', {}).items():
            max_queue_size = max(max_queue_size, q_stats.get('pending', 0))
        
        result.details['最大队列大小'] = max_queue_size
        result.details['队列大小限制'] = 20
        result.details['队列大小采样'] = queue_sizes
        
        # 验证背压是否生效（队列不应该无限增长）
        if max_queue_size <= 25:  # 允许一些缓冲
            result.passed = True
        else:
            result.error = f"队列大小超限: {max_queue_size}"
        
        factory.close()
        
    except Exception as e:
        result.error = str(e)
    
    result.duration = time.time() - start_time
    return result


def test_batch_processing():
    """测试5: 批量处理"""
    result = TestResult("批量处理")
    start_time = time.time()
    
    try:
        batch_sizes = []
        total_items = 0
        
        def producer(data):
            """生产数据"""
            return data
        
        def batch_consumer(batch):
            """批量消费"""
            nonlocal total_items
            batch_sizes.append(len(batch))
            total_items += len(batch)
            time.sleep(0.02)
        
        config = ResourceConfig(max_queue_size=1000, max_memory_mb=500)
        factory = Factory(resource_config=config)
        
        head = factory.head(producer, name="producer")
        node1 = head.create_node(batch_consumer, name="consumer", 
                                batch_size=10, node_num=2)  # 批量大小10
        
        factory.start()
        
        # 投喂100条数据
        for i in range(100):
            factory.feed(i)
        
        factory.end_feed()
        factory.wait_complete(timeout=30)
        
        result.details['批次数量'] = len(batch_sizes)
        result.details['总处理数据'] = total_items
        result.details['平均批次大小'] = f"{sum(batch_sizes) / len(batch_sizes):.1f}" if batch_sizes else 0
        
        if total_items == 100:
            result.passed = True
        else:
            result.error = f"数据处理不完整: {total_items}/100"
        
        factory.close()
        
    except Exception as e:
        result.error = str(e)
    
    result.duration = time.time() - start_time
    return result


def test_bulk_feed():
    """测试6: 批量投喂"""
    result = TestResult("批量投喂")
    start_time = time.time()
    
    try:
        processed = []
        
        def producer(data):
            """处理数据"""
            return data * 2
        
        def consumer(data):
            """消费数据"""
            processed.append(data)
        
        config = ResourceConfig(max_queue_size=10000, max_memory_mb=500)
        factory = Factory(resource_config=config)
        
        head = factory.head(producer, name="producer")
        node1 = head.create_node(consumer, name="consumer")
        
        # 批量投喂
        bulk_data = list(range(1000))
        factory.bulk_feed(bulk_data)
        
        factory.start()
        factory.end_feed()  # 手动结束投喂
        factory.wait_complete(timeout=30)
        
        result.details['投喂数据量'] = len(bulk_data)
        result.details['处理数据量'] = len(processed)
        
        if len(processed) == 1000:
            result.passed = True
        else:
            result.error = f"数据处理不完整: {len(processed)}/1000"
        
        factory.close()
        
    except Exception as e:
        result.error = str(e)
    
    result.duration = time.time() - start_time
    return result


def test_multi_worker():
    """测试7: 多工位并行处理"""
    result = TestResult("多工位并行处理")
    start_time = time.time()
    
    try:
        worker_ids = set()
        
        def producer(data, worker):
            """记录工位ID"""
            worker_ids.add(worker.worker_id)
            time.sleep(0.01)
            return data
        
        def consumer(data):
            """消费数据"""
            time.sleep(0.01)
        
        config = ResourceConfig(max_queue_size=200, max_memory_mb=500)
        factory = Factory(resource_config=config)
        
        head = factory.head(producer, name="producer", node_num=5)  # 5个工位
        node1 = head.create_node(consumer, name="consumer", node_num=3)  # 3个工位
        
        factory.start()
        
        for i in range(50):
            factory.feed(i)
        
        factory.end_feed()
        factory.wait_complete(timeout=30)
        
        result.details['生产者工位数'] = len([w for w in worker_ids if 'producer' in w])
        result.details['期望工位数'] = 5
        
        if len([w for w in worker_ids if 'producer' in w]) == 5:
            result.passed = True
        else:
            result.error = f"工位数不匹配"
        
        factory.close()
        
    except Exception as e:
        result.error = str(e)
    
    result.duration = time.time() - start_time
    return result


def test_different_queue_sizes():
    """测试8: 不同队列大小配置"""
    result = TestResult("不同队列大小配置")
    start_time = time.time()
    
    try:
        def producer(data):
            return data
        
        def processor(data):
            time.sleep(0.01)
            return data * 2
        
        def consumer(data):
            time.sleep(0.01)
        
        config = ResourceConfig(max_queue_size=1000, max_memory_mb=500)
        factory = Factory(resource_config=config)
        
        head = factory.head(producer, name="producer")
        # 第一个节点输出队列大小为50
        node1 = head.create_node(processor, name="processor", output_queue_size=50)
        # 第二个节点输出队列大小为100
        node2 = node1.create_node(consumer, name="consumer")
        
        factory.start()
        
        for i in range(100):
            factory.feed(i)
        
        factory.end_feed()
        factory.wait_complete(timeout=30)
        
        stats = factory.stats
        result.details['队列数量'] = len(stats.get('queues', {}))
        
        # 检查是否有队列统计信息
        if len(stats.get('queues', {})) >= 2:
            result.passed = True
        else:
            result.error = "队列配置异常"
        
        factory.close()
        
    except Exception as e:
        result.error = str(e)
    
    result.duration = time.time() - start_time
    return result


def test_error_handling():
    """测试9: 错误处理"""
    result = TestResult("错误处理")
    start_time = time.time()
    
    try:
        success_count = 0
        error_count = 0
        
        def producer(data):
            """偶尔抛出异常"""
            if data % 5 == 0:
                raise ValueError(f"测试错误: {data}")
            return data
        
        def consumer(data):
            """消费数据"""
            nonlocal success_count
            success_count += 1
        
        config = ResourceConfig(max_queue_size=100, max_memory_mb=500)
        factory = Factory(resource_config=config, enable_monitor=False)  # 关闭监控减少日志
        
        head = factory.head(producer, name="error_test_producer")
        node1 = head.create_node(consumer, name="error_test_consumer")
        
        factory.start()
        
        for i in range(20):
            factory.feed(i)
        
        factory.end_feed()
        factory.wait_complete(timeout=30)
        
        result.details['成功处理'] = success_count
        result.details['预期成功'] = 16  # 20条数据，4条会出错
        result.details['错误数据'] = '0, 5, 10, 15'
        
        # 框架应该能够处理异常而不崩溃
        if success_count >= 15:  # 允许一些容错
            result.passed = True
        else:
            result.error = f"成功处理数过少: {success_count}"
        
        factory.close()
        
    except Exception as e:
        result.error = str(e)
    
    result.duration = time.time() - start_time
    return result


def test_list_return():
    """测试10: 列表返回值处理"""
    result = TestResult("列表返回值处理")
    start_time = time.time()
    
    try:
        received_count = 0
        
        def producer(data):
            """返回列表，框架会逐个元素放入队列"""
            return [data * 10 + i for i in range(3)]
        
        def consumer(data):
            """消费数据"""
            nonlocal received_count
            received_count += 1
        
        config = ResourceConfig(max_queue_size=100, max_memory_mb=500)
        factory = Factory(resource_config=config)
        
        head = factory.head(producer, name="producer")
        node1 = head.create_node(consumer, name="consumer")
        
        factory.start()
        
        for i in range(10):
            factory.feed(i)
        
        factory.end_feed()
        factory.wait_complete(timeout=30)
        
        result.details['接收数据量'] = received_count
        result.details['期望数据量'] = 30  # 10条输入 * 3个元素
        
        if received_count == 30:
            result.passed = True
        else:
            result.error = f"数据量不匹配: {received_count}/30"
        
        factory.close()
        
    except Exception as e:
        result.error = str(e)
    
    result.duration = time.time() - start_time
    return result


def test_none_return():
    """测试11: None返回值处理"""
    result = TestResult("None返回值处理")
    start_time = time.time()
    
    try:
        consumer_count = 0
        
        def producer(data):
            """过滤数据，偶数返回None"""
            if data % 2 == 0:
                return None
            return data
        
        def consumer(data):
            """消费数据"""
            nonlocal consumer_count
            consumer_count += 1
        
        config = ResourceConfig(max_queue_size=100, max_memory_mb=500)
        factory = Factory(resource_config=config)
        
        head = factory.head(producer, name="producer")
        node1 = head.create_node(consumer, name="consumer")
        
        factory.start()
        
        for i in range(20):
            factory.feed(i)
        
        factory.end_feed()
        factory.wait_complete(timeout=30)
        
        result.details['消费数据量'] = consumer_count
        result.details['期望数据量'] = 10  # 20条数据，10条被过滤
        
        if consumer_count == 10:
            result.passed = True
        else:
            result.error = f"数据量不匹配: {consumer_count}/10"
        
        factory.close()
        
    except Exception as e:
        result.error = str(e)
    
    result.duration = time.time() - start_time
    return result


def test_setup_teardown():
    """测试12: setup和teardown函数"""
    result = TestResult("setup和teardown函数")
    start_time = time.time()
    
    try:
        setup_called = []
        teardown_called = []
        
        def setup(worker):
            """初始化函数"""
            setup_called.append(worker.worker_id)
            worker.set_attr('initialized', True)
        
        def teardown(worker):
            """清理函数"""
            teardown_called.append(worker.worker_id)
        
        def consumer(data, worker):
            """消费数据"""
            assert worker.get_attr('initialized') == True
        
        config = ResourceConfig(max_queue_size=100, max_memory_mb=500)
        factory = Factory(resource_config=config)
        
        head = factory.head(lambda x: x, name="producer")
        node1 = head.create_node(consumer, name="consumer", 
                                setup_func=setup, teardown_func=teardown,
                                node_num=3)
        
        factory.start()
        
        for i in range(10):
            factory.feed(i)
        
        factory.end_feed()
        factory.wait_complete(timeout=30)
        factory.close()
        
        result.details['setup调用次数'] = len(setup_called)
        result.details['teardown调用次数'] = len(teardown_called)
        result.details['工位数'] = 3
        
        if len(setup_called) == 3 and len(teardown_called) == 3:
            result.passed = True
        else:
            result.error = f"setup/teardown调用次数不匹配"
        
    except Exception as e:
        result.error = str(e)
    
    result.duration = time.time() - start_time
    return result


def main():
    """运行所有测试"""
    print("=" * 70)
    print(f"Factory Queue 框架测试")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    print()
    
    # 定义所有测试
    tests = [
        test_simple_chain,
        test_fork_chain,
        test_yield_generator,
        test_queue_full_backpressure,
        test_batch_processing,
        test_bulk_feed,
        test_multi_worker,
        test_different_queue_sizes,
        test_error_handling,
        test_list_return,
        test_none_return,
        test_setup_teardown,
    ]
    
    results = []
    
    # 运行所有测试
    for i, test_func in enumerate(tests, 1):
        print(f"运行测试 {i}/{len(tests)}: {test_func.__doc__.split(':')[1].strip()}")
        try:
            result = test_func()
            results.append(result)
            print(f"  状态: {'✓ 通过' if result.passed else '✗ 失败'}")
            print(f"  耗时: {result.duration:.2f}秒")
        except Exception as e:
            result = TestResult(test_func.__doc__)
            result.error = str(e)
            results.append(result)
            print(f"  状态: ✗ 失败")
            print(f"  错误: {e}")
        print()
    
    # 汇总结果
    print("=" * 70)
    print("测试结果汇总")
    print("=" * 70)
    print()
    
    passed = sum(1 for r in results if r.passed)
    failed = len(results) - passed
    total_time = sum(r.duration for r in results)
    
    for result in results:
        print(result)
        print()
    
    print("=" * 70)
    print(f"总计: {len(results)} 个测试")
    print(f"通过: {passed} 个")
    print(f"失败: {failed} 个")
    print(f"总耗时: {total_time:.2f}秒")
    print(f"成功率: {passed/len(results)*100:.1f}%")
    print("=" * 70)
    
    # 返回退出码
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
