# -*- coding: utf-8 -*-
"""
Factory Queue - 高层接口 (High-Level API)
流水线工厂模块 - 基于 core.py 的简化封装
提供链式配置接口，自动管理节点依赖和队列
支持多节点、多工位、多类型产物的流水线处理
"""
import inspect
import json
import logging
import pickle
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Callable, Optional, Union

import psutil

from .core import (
    BaseFactory,  # 底层工厂
    ResourceConfig,
    Producer,
    Consumer,
    logger
)


# 自定义日志过滤器：替换技术词汇为业务名称
class _NodeLogFilter(logging.Filter):
    """将底层技术词汇替换为流水线节点名称"""

    def filter(self, record):
        if hasattr(record, 'msg') and isinstance(record.msg, str):
            # 替换技术词汇
            msg = record.msg
            msg = msg.replace('生产者组', '节点组')
            msg = msg.replace('消费者组', '节点组')
            msg = msg.replace('生产者', '节点')
            msg = msg.replace('消费者', '节点')
            msg = msg.replace('_producer_', '_')
            msg = msg.replace('_consumer_', '_')
            msg = msg.replace('producer', '')
            msg = msg.replace('consumer', '')
            record.msg = msg
        return True


class GroupTracker:
    """
    数据组追踪器 - 追踪某一输入参数产生的所有产物的消费情况
    当所有产物都被消费完毕时，触发 finish_func
    """
    
    def __init__(self, group_id: int, original_data: Any, 
                 finish_func: Callable, finish_args: Dict[str, Any],
                 worker: Any, node_name: str, log_finish: bool = True):
        """
        初始化追踪器
        
        Args:
            group_id: 组 ID（唯一标识）
            original_data: 原始输入数据（将传递给 finish_func）
            finish_func: 完成回调函数
            finish_args: 传递给 finish_func 的额外参数
            worker: Producer 或 Consumer 对象（可以访问 setup 设置的值）
            node_name: 节点名称（用于日志）
            log_finish: 是否打印完成日志
        """
        self.group_id = group_id
        self.original_data = original_data
        self.finish_func = finish_func
        self.finish_args = finish_args
        self.worker = worker
        self.node_name = node_name
        self.log_finish = log_finish
        
        # 按 feed 分支计数：{feed_key: {'produced': count, 'consumed': count}}
        self.feed_counters: Dict[int, Dict[str, int]] = {}
        self.lock = threading.Lock()
        self._finished = False  # 标记是否已触发 finish
    
    def add_feed(self, feed_key: int, count: int) -> None:
        """添加某个 feed 分支的生产计数"""
        import threading
        thread_name = threading.current_thread().name
        with self.lock:
            if feed_key not in self.feed_counters:
                self.feed_counters[feed_key] = {'produced': 0, 'consumed': 0}
            self.feed_counters[feed_key]['produced'] += count
            logger.debug(f"[{self.node_name}] 组 {self.group_id} add_feed (thread={thread_name}): feed_key={feed_key}, count={count}, 当前计数={self.feed_counters[feed_key]}")
    
    def mark_consumed(self, feed_key: int, count: int = 1) -> bool:
        """
        标记某个 feed 分支的消费
        
        Args:
            feed_key: feed 索引
            count: 消费数量
        
        Returns:
            是否触发了 finish_func
        """
        should_finish = False
        
        with self.lock:
            if self._finished:
                logger.debug(f"[{self.node_name}] 组 {self.group_id} 已触发过 finish，跳过")
                return False  # 已经触发过 finish，不再重复触发
            
            if feed_key in self.feed_counters:
                self.feed_counters[feed_key]['consumed'] += count
                logger.debug(f"[{self.node_name}] 组 {self.group_id} feed {feed_key} 消费计数：{self.feed_counters[feed_key]}")
                
                # 检查是否所有 feed 都消费完毕
                if self._is_fully_consumed():
                    should_finish = True
                    self._finished = True
                    logger.debug(f"[{self.node_name}] 组 {self.group_id} 所有产物已消费完毕，准备触发 finish")
        
        # 在锁外执行 finish_func，避免阻塞其他 worker
        if should_finish:
            self._execute_finish()
        
        return should_finish
    
    def _is_fully_consumed(self) -> bool:
        """检查所有 feed 分支是否都已消费完毕"""
        if not self.feed_counters:
            return False
        
        return all(
            counter['consumed'] >= counter['produced']
            for counter in self.feed_counters.values()
        )
    
    def _execute_finish(self) -> None:
        """执行 finish_func"""
        try:
            if self.finish_func:
                # 调用 finish_func(original_data, worker, **finish_args)
                self.finish_func(self.original_data, self.worker, **self.finish_args)
                
                if self.log_finish:
                    logger.info(f"[{self.node_name}] 组 {self.group_id} 的所有产物已消费完毕")
        except Exception as e:
            logger.error(f"[{self.node_name}] finish_func 执行失败：{e}", exc_info=True)


# 全局日志过滤器实例
_log_filter_instance = None


class Node:
    """
    流水线节点 - 封装节点配置和处理逻辑
    支持链式创建下游节点
    """

    def __init__(self, factory: 'Factory', name: str,
                 func: Callable, args: Dict[str, Any] = None,
                 node_num: int = 1, is_head: bool = False,
                 save_result: bool = False, print_processing: bool = True,
                 batch_size: int = 1,
                 setup_func: Callable[[Consumer], None] = None,
                 teardown_func: Callable[[Consumer], None] = None,
                 output_queue_size: int = None,
                 # 新增：完成回调函数参数
                 finish_func: Callable = None,
                 finish_args: Dict[str, Any] = None,
                 log_finish: bool = True):
        """
        初始化节点
            
        Args:
            factory: 流水线工厂实例
            name: 节点名称
            func: 处理函数，签名为 func(data, **kwargs) 或 func(batch, **kwargs)
            args: 传递给处理函数的额外参数
            node_num: 工位数量（并行线程数）
            is_head: 是否为头节点
            save_result: 是否保存处理结果到文件
            print_processing: 是否打印处理日志（默认 True）
            batch_size: 每次从上游队列拿取多少个值（默认 1，仅叶子节点有效）
            setup_func: 初始化函数，每个线程启动时调用一次（仅叶子节点有效）
            teardown_func: 清理函数，每个线程结束时调用一次（仅叶子节点有效）
            output_queue_size: 输出队列大小（可选，不指定则使用全局配置）
            finish_func: 完成回调函数，当该节点产生的所有产物被下游消费完后调用
            finish_args: 传递给 finish_func 的额外参数
            log_finish: 是否打印完成日志（默认 True）
        """
        self.factory = factory
        self.name = name
        self.func = func
        self.args = args or {}
        self.node_num = node_num
        self.is_head = is_head
        self.save_result = save_result
        self.print_processing = print_processing
        self.batch_size = batch_size
        self.setup_func = setup_func
        self.teardown_func = teardown_func
        self.output_queue_size = output_queue_size
        # 新增：完成回调相关属性
        self.finish_func = finish_func
        self.finish_args = finish_args or {}
        self.log_finish = log_finish

        # 节点输出类型：每个feed索引对应一个队列名
        self._output_feeds: Dict[int, str] = {}
        # 下游节点列表
        self._downstream_nodes: List['Node'] = []
        # 上游节点
        self._upstream_node: Optional['Node'] = None
        # 输入队列名称（由上游节点设置）
        self._input_queue_name: Optional[str] = None
        # 内部组名称（用于底层调度）
        self._group_name: Optional[str] = None
        # 缓存节点路径（性能优化）
        self._cached_path: Optional[str] = None
        # 数据追踪器注册表（用于按参数分组追踪产物消费情况）
        self._data_trackers: Dict[int, 'GroupTracker'] = {}

        # 在工厂中注册节点
        self.factory.register_node(self)

    def _get_node_path(self) -> List[str]:
        """获取从头节点到当前节点的路径"""
        path = []
        current = self
        while current is not None:
            path.insert(0, current.name)
            current = current._upstream_node
        return path

    def _get_save_filename(self) -> str:
        """
        生成保存文件名（根据节点路径）
        使用缓存以提高性能
        """
        if self._cached_path is None:
            path = self._get_node_path()
            self._cached_path = "_".join(path)
        return self._cached_path

    @property
    def input_queue_name(self) -> Optional[str]:
        """获取输入队列名称"""
        return self._input_queue_name

    @property
    def output_feeds(self) -> Dict[int, str]:
        """获取输出队列映射"""
        return self._output_feeds

    @property
    def downstream_nodes(self) -> List['Node']:
        """获取下游节点列表"""
        return self._downstream_nodes

    @property
    def upstream_node(self) -> Optional['Node']:
        """获取上游节点"""
        return self._upstream_node

    @property
    def group_name(self) -> Optional[str]:
        """获取内部组名称"""
        return self._group_name

    def set_input_queue_name(self, queue_name: str) -> None:
        """设置输入队列名称"""
        self._input_queue_name = queue_name

    def set_group_name(self, group_name: str) -> None:
        """设置内部组名称"""
        self._group_name = group_name

    def set_upstream_node(self, upstream: 'Node') -> None:
        """设置上游节点"""
        self._upstream_node = upstream

    def add_downstream_node(self, downstream: 'Node') -> None:
        """添加下游节点"""
        self._downstream_nodes.append(downstream)

    def register_tracker(self, tracker: 'GroupTracker') -> None:
        """注册数据追踪器"""
        self._data_trackers[tracker.group_id] = tracker
    
    def unregister_tracker(self, group_id: int) -> None:
        """注销数据追踪器"""
        if group_id in self._data_trackers:
            del self._data_trackers[group_id]

    def has_downstream(self) -> bool:
        """判断是否有下游节点"""
        return len(self._downstream_nodes) > 0

    def create_node(self, func: Callable, args: Dict[str, Any] = None,
                    node_num: int = 1, feed: Union[int, str] = 0,
                    name: str = None, save_result: bool = False,
                    print_processing: bool = True, batch_size: int = 1,
                    setup_func: Callable[[Consumer], None] = None,
                    teardown_func: Callable[[Consumer], None] = None,
                    output_queue_size: int = None,
                    # 新增：完成回调函数参数
                    finish_func: Callable = None,
                    finish_args: Dict[str, Any] = None,
                    log_finish: bool = True) -> 'Node':
        """
        从当前节点创建下游节点，支持链式调用
            
        Args:
            func: 处理函数，签名为 func(data, **kwargs) 或 func(batch, **kwargs)
            args: 传递给处理函数的额外参数（字典）
            node_num: 工位数量（并行线程数）
            feed: 使用上游的哪个产物（索引或名称），默认 0 表示第一个产物
            name: 节点名称（可选，不指定则自动生成）
            save_result: 是否保存处理结果到文件（默认 False）
            print_processing: 是否打印处理日志（默认 True）
            batch_size: 每次从上游队列拿取多少个值（默认 1，仅叶子节点有效）
            setup_func: 初始化函数，每个线程启动时调用一次（仅叶子节点有效）
            teardown_func: 清理函数，每个线程结束时调用一次（仅叶子节点有效）
            output_queue_size: 该节点输出队列的大小（可选，不指定则使用全局配置）
            finish_func: 完成回调函数，当该节点产生的所有产物被下游消费完后调用
            finish_args: 传递给 finish_func 的额外参数
            log_finish: 是否打印完成日志（默认 True）
            
        Returns:
            新创建的节点对象，可继续链式调用
        """
        # 生成下游节点名称
        if name is None:
            node_name = f"{self.name}_node_{len(self._downstream_nodes)}"
        else:
            node_name = name

        # 创建新节点
        new_node = Node(
            factory=self.factory,
            name=node_name,
            func=func,
            args=args,
            node_num=node_num,
            is_head=False,
            save_result=save_result,
            print_processing=print_processing,
            batch_size=batch_size,
            setup_func=setup_func,
            teardown_func=teardown_func,
            output_queue_size=output_queue_size,
            # 新增参数
            finish_func=finish_func,
            finish_args=finish_args,
            log_finish=log_finish
        )

        # 建立上下游关系
        new_node.set_upstream_node(self)
        self.add_downstream_node(new_node)

        # 确定使用哪个feed（队列）
        feed_key = feed if isinstance(feed, int) else feed

        # 确保上游节点有对应的输出feed
        if feed_key not in self._output_feeds:
            feed_queue_name = f"{self.name}_feed_{feed_key}"
            self._output_feeds[feed_key] = feed_queue_name

        # 新节点的输入队列就是上游的输出队列
        new_node.set_input_queue_name(self._output_feeds[feed_key])

        return new_node

    def build_process_func(self) -> Callable:
        """构建节点处理函数（公共接口）"""
        return self._build_process_func()

    def build_consume_func(self) -> Callable:
        """构建叶子节点处理函数（公共接口）"""
        return self._build_consume_func()

    def _build_process_func(self) -> Callable:
        """
        构建节点处理函数，将用户函数包装为内部格式
        
        返回值处理规则：
        1. None: 不输出任何数据
        2. 字典: 按键匹配feed（向后兼容）
        3. 元组(tuple): 按位置分发到不同feed（位置0→feed=0, 位置1→feed=1...）
           - 每个位置的值如果是列表，底层会逐个元素放入队列
           - 每个位置的值如果是单个元素，直接放入队列
        4. 列表(list): 整个列表放入feed=0，底层会逐个元素放入队列
        5. 单个值: 放入feed=0
        
        示例：
        - return [1,2,3] → 1、2、3依次进入feed=0的队列
        - return (val1, val2) → val1进feed=0, val2进feed=1
        - return ([1,2], 'aa') → [1,2]的元素进feed=0, 'aa'进feed=1
        - return 'single' → 'single'进feed=0
        - yield item → 生成器的所有值会被收集为列表后放入feed=0（注意：是逐个处理）
        """
        # 提前捕获变量，避免闭包引用 self
        node_name = self.name
        save_result_flag = self.save_result
        print_log = self.print_processing  # 是否打印处理日志
        node_args = self.args
        user_func = self.func
        output_feeds = self._output_feeds
        # 预先计算 feed 键集合（性能优化）
        output_feed_keys = frozenset(output_feeds.keys())
        has_args = bool(node_args)
                        
        # 捕获 finish_func 相关变量
        finish_func = self.finish_func
        finish_args = self.finish_args
        log_finish = self.log_finish
        node_name_for_closure = self.name
        
        # 检查用户函数是否接受 worker 参数
        sig = inspect.signature(user_func)
        params = list(sig.parameters.keys())
        # 判断是否有第二个参数（worker）或使用了 **kwargs
        accepts_worker = (
            len(params) >= 2 or 
            any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
        )

        # 如果需要保存结果，预先捕获保存方法（绑定self）
        if save_result_flag:
            # 使用lambda捕获self，保持实例方法的绑定
            save_func = lambda result, worker_num: self._save_result_to_file(result, worker_num)
        else:
            save_func = None

        def wrapper(data: Any, producer: Producer) -> Dict[str, Any]:
            try:
                # 提取 worker 编号用于显示
                worker_id = producer.worker_id
                # 优化：使用 rsplit 代替 split，只分割一次
                worker_num = worker_id.rsplit('_', 1)[-1] if '_' in worker_id else '0'
                display_name = f"{node_name}_{worker_num}"
                        
                # 解包数据（如果是包装后的数据）
                actual_data = data
                input_tracker = None
                input_feed_key = None
                        
                if isinstance(data, tuple) and len(data) == 3:
                    actual_data, input_tracker, input_feed_key = data
                    logger.debug(f"[{node_name}] 解包输入数据：tracker={input_tracker}, feed_key={input_feed_key}")
        
                # 根据函数签名智能调用
                if accepts_worker:
                    # 函数接受 worker 参数
                    result = user_func(actual_data, producer, **node_args) if has_args else user_func(actual_data, producer)
                else:
                    # 函数不接受 worker 参数
                    result = user_func(actual_data, **node_args) if has_args else user_func(actual_data)

                # 打印处理日志（如果启用）
                if print_log:
                    logger.info(f"[{display_name}] 处理: {data}")

                # 保存处理结果（如果启用）
                if save_func and result is not None:
                    save_func(result, worker_num)

                # 确定使用哪个追踪器：优先使用节点的 finish_func 创建的，否则使用输入数据中的
                tracker = None
                created_new_tracker = False  # 标记是否创建了新追踪器
                if finish_func is not None:
                    # 为本节点的输入创建新的追踪器
                    group_id = id(actual_data)
                    tracker = GroupTracker(
                        group_id=group_id,
                        original_data=actual_data,
                        finish_func=finish_func,
                        finish_args=finish_args,
                        worker=producer,
                        node_name=node_name_for_closure,
                        log_finish=log_finish
                    )
                    self.register_tracker(tracker)
                    created_new_tracker = True
                    logger.debug(f"[{node_name_for_closure}] worker={producer.worker_id} 创建追踪器：group_id={group_id}, data={actual_data}")
                elif input_tracker is not None:
                    # 没有自己的 finish_func，但输入有追踪器，继续使用它
                    tracker = input_tracker

                # 检查返回值是否为生成器类型
                import types
                if isinstance(result, types.GeneratorType):
                    # 为了实现真正的流式处理，我们在这里逐个处理生成器的值
                    for yielded_value in result:
                        if yielded_value is not None:
                            # 如果 yield 的是元组，按位置分发到不同 feed（与 return 元组逻辑一致）
                            if isinstance(yielded_value, tuple):
                                for idx, item in enumerate(yielded_value):
                                    if item is None:
                                        continue
                                    if idx in output_feeds:
                                        queue_name = output_feeds[idx]
                                        target_queue = producer.output_queues[queue_name]
                                        while target_queue.qsize() >= target_queue.max_size * 0.8:
                                            time.sleep(0.1)
                                        
                                        # 包装数据
                                        if tracker is not None and created_new_tracker:
                                            tracker.add_feed(idx, 1 if not isinstance(item, list) else len(item))
                                            if isinstance(item, list):
                                                for sub_item in item:
                                                    tagged_item = (sub_item, tracker, idx)
                                                    target_queue.put(tagged_item)
                                            else:
                                                tagged_item = (item, tracker, idx)
                                                target_queue.put(tagged_item)
                                        elif tracker is not None:
                                            # 只是传递追踪器
                                            if isinstance(item, list):
                                                for sub_item in item:
                                                    tagged_item = (sub_item, tracker, idx)
                                                    target_queue.put(tagged_item)
                                            else:
                                                tagged_item = (item, tracker, idx)
                                                target_queue.put(tagged_item)
                                        else:
                                            target_queue.put(item)
                            # 如果不是元组，默认放入 feed=0
                            elif 0 in output_feeds:
                                queue_name = output_feeds[0]
                                target_queue = producer.output_queues[queue_name]
                                while target_queue.qsize() >= target_queue.max_size * 0.8:
                                    time.sleep(0.1)
                                
                                # 包装数据
                                if tracker is not None and created_new_tracker:
                                    tracker.add_feed(0, 1 if not isinstance(yielded_value, list) else len(yielded_value))
                                    if isinstance(yielded_value, list):
                                        for sub_item in yielded_value:
                                            tagged_item = (sub_item, tracker, 0)
                                            target_queue.put(tagged_item)
                                    else:
                                        tagged_item = (yielded_value, tracker, 0)
                                        target_queue.put(tagged_item)
                                elif tracker is not None:
                                    # 只是传递追踪器
                                    if isinstance(yielded_value, list):
                                        for sub_item in yielded_value:
                                            tagged_item = (sub_item, tracker, 0)
                                            target_queue.put(tagged_item)
                                    else:
                                        tagged_item = (yielded_value, tracker, 0)
                                        target_queue.put(tagged_item)
                                else:
                                    target_queue.put(yielded_value)
                    return {}
                
                # 将结果转换为队列分发格式（非生成器的情况）
                if result is None:
                    return {}

                output_dict = {}

                # 情况 1：字典返回值（按键匹配 feed）
                if isinstance(result, dict):
                    if output_feed_keys & result.keys():
                        for feed_key, queue_name in output_feeds.items():
                            if feed_key in result and result[feed_key] is not None:
                                feed_data = result[feed_key]
                                if tracker is not None and created_new_tracker:
                                    if isinstance(feed_data, list):
                                        tracker.add_feed(feed_key, len(feed_data))
                                        for item in feed_data:
                                            tagged_item = (item, tracker, feed_key)
                                            output_dict.setdefault(queue_name, []).append(tagged_item)
                                    else:
                                        tracker.add_feed(feed_key, 1)
                                        tagged_item = (feed_data, tracker, feed_key)
                                        output_dict[queue_name] = tagged_item
                                elif tracker is not None:
                                    # 只是传递追踪器
                                    if isinstance(feed_data, list):
                                        for item in feed_data:
                                            tagged_item = (item, tracker, feed_key)
                                            output_dict.setdefault(queue_name, []).append(tagged_item)
                                    else:
                                        tagged_item = (feed_data, tracker, feed_key)
                                        output_dict[queue_name] = tagged_item
                                else:
                                    output_dict[queue_name] = feed_data
                        return output_dict
                    # 继续往下执行单一返回值的逻辑

                # 情况 2：元组返回值
                if isinstance(result, tuple):
                    for idx, item in enumerate(result):
                        if item is None:
                            continue
                        if idx in output_feeds:
                            queue_name = output_feeds[idx]
                            if tracker is not None and created_new_tracker:
                                if isinstance(item, list):
                                    tracker.add_feed(idx, len(item))
                                    for sub_item in item:
                                        tagged_item = (sub_item, tracker, idx)
                                        output_dict.setdefault(queue_name, []).append(tagged_item)
                                else:
                                    tracker.add_feed(idx, 1)
                                    tagged_item = (item, tracker, idx)
                                    output_dict[queue_name] = tagged_item
                            elif tracker is not None:
                                # 只是传递追踪器
                                if isinstance(item, list):
                                    for sub_item in item:
                                        tagged_item = (sub_item, tracker, idx)
                                        output_dict.setdefault(queue_name, []).append(tagged_item)
                                else:
                                    tagged_item = (item, tracker, idx)
                                    output_dict[queue_name] = tagged_item
                            else:
                                output_dict[queue_name] = item
                    return output_dict

                # 情况 3：列表返回值
                if isinstance(result, list):
                    if 0 in output_feeds:
                        queue_name = output_feeds[0]
                        if tracker is not None and created_new_tracker:
                            tracker.add_feed(0, len(result))
                            output_dict[queue_name] = [(item, tracker, 0) for item in result]
                        elif tracker is not None:
                            # 只是传递追踪器
                            output_dict[queue_name] = [(item, tracker, 0) for item in result]
                        else:
                            output_dict[queue_name] = result
                    return output_dict

                # 情况 4：单一返回值
                if 0 in output_feeds:
                    queue_name = output_feeds[0]
                    if tracker is not None and created_new_tracker:
                        tracker.add_feed(0, 1)
                        output_dict[queue_name] = (result, tracker, 0)
                    elif tracker is not None:
                        # 只是传递追踪器
                        output_dict[queue_name] = (result, tracker, 0)
                    else:
                        output_dict[queue_name] = result

                # 在将结果放入队列前检查队列大小
                for queue_name, result_item in output_dict.items():
                    if queue_name in producer.output_queues:
                        target_queue = producer.output_queues[queue_name]
                        # 检查队列大小，如果接近满载则等待一段时间（80%阈值）
                        while target_queue.qsize() >= target_queue.max_size * 0.8:
                            time.sleep(0.1)  # 等待0.1秒再检查

                return output_dict

            except Exception as e:
                logger.error(f"节点 [{node_name}] 处理函数执行失败: {e}")
                return {}

        return wrapper

    def _build_consume_func(self) -> Callable:
        """
        构建叶子节点处理函数
        叶子节点不产生输出，仅处理数据
        """
        node_name = self.name
        save_result_flag = self.save_result
        print_log = self.print_processing  # 是否打印处理日志
        node_args = self.args
        user_func = self.func
        
        # 检查用户函数是否接受 worker 参数
        sig = inspect.signature(user_func)
        params = list(sig.parameters.keys())
        # 判断是否有第二个参数（worker）或使用了 **kwargs
        accepts_worker = (
            len(params) >= 2 or 
            any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
        )

        def wrapper(data: Any, consumer: Consumer):
            try:
                # 提取 worker 编号用于显示
                worker_id = consumer.worker_id
                worker_num = worker_id.split('_')[-1] if '_' in worker_id else '0'
                display_name = f"{node_name}_{worker_num}"
        
                # 打印处理日志（如果启用）
                if print_log:
                    logger.info(f"[{display_name}] 处理：{data}")
        
                # 解包数据（如果是包装后的数据）
                actual_data = data
                tracker = None
                feed_key = None
                        
                if isinstance(data, tuple) and len(data) == 3:
                    actual_data, tracker, feed_key = data
        
                # 根据函数签名智能调用
                if accepts_worker:
                    # 函数接受 worker 参数
                    result = user_func(actual_data, consumer, **node_args) if node_args else user_func(actual_data, consumer)
                else:
                    # 函数不接受 worker 参数
                    result = user_func(actual_data, **node_args) if node_args else user_func(actual_data)
        
                # 保存处理结果（如果启用）
                if save_result_flag and result is not None:
                    self._save_result_to_file(result, worker_num)
        
                # 如果有追踪器，标记消费完成
                if tracker is not None and feed_key is not None:
                    try:
                        logger.debug(f"[{node_name}] 标记消费：feed_key={feed_key}, data={actual_data}, tracker={tracker}")
                        result = tracker.mark_consumed(feed_key, count=1)
                        logger.debug(f"[{node_name}] mark_consumed 返回：{result}")
                    except Exception as e:
                        logger.error(f"[{node_name}] 标记消费完成失败：{e}")
                else:
                    if tracker is not None:
                        logger.warning(f"[{node_name}] 追踪器存在但 feed_key 为 None: tracker={tracker}, data={actual_data}")
                    if feed_key is not None:
                        logger.warning(f"[{node_name}] feed_key 存在但 tracker 为 None: feed_key={feed_key}, data={actual_data}")
        
            except Exception as e:
                logger.error(f"节点 [{node_name}] 消费函数执行失败：{e}", exc_info=True)

        return wrapper

    def _save_result_to_file(self, result: Any, worker_num: str) -> None:
        """
        保存处理结果到文件
        
        Args:
            result: 要保存的结果数据
            worker_num: 工位编号
        """
        try:
            # 获取并创建temp_dir
            temp_dir = Path(self.factory.get_temp_dir())
            temp_dir.mkdir(parents=True, exist_ok=True)

            # 生成唯一文件名
            base_filename = self._get_save_filename()
            timestamp = int(time.time() * 1000)

            # 根据数据类型选择保存格式
            if isinstance(result, (dict, list)):
                # JSON格式（可读性好）
                filename = f"{base_filename}_w{worker_num}_{timestamp}.json"
                filepath = temp_dir / filename
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(result, f, ensure_ascii=False, indent=2)
            else:
                # Pickle格式（支持任意Python对象）
                filename = f"{base_filename}_w{worker_num}_{timestamp}.pkl"
                filepath = temp_dir / filename
                with open(filepath, 'wb') as f:
                    pickle.dump(result, f)

            logger.debug(f"节点 [{self.name}] 保存结果到: {filepath}")
        except Exception as e:
            logger.error(f"节点 [{self.name}] 保存结果失败: {e}", exc_info=True)


class Factory:
    """
    流水线工厂 - 基于原有BaseFactory的简化封装
    提供链式配置接口，自动管理节点依赖和队列
    """

    def __init__(self, resource_config: ResourceConfig = None,
                 enable_monitor: bool = True, monitor_interval: float = 10.0,
                 max_memory_percent: float = None,
                 disable_disk_mode: bool = False,
                 hide_technical_terms: bool = True):
        """
        初始化流水线工厂
        
        Args:
            resource_config: 资源配置
            enable_monitor: 是否启用监控
            monitor_interval: 监控间隔（秒）
            max_memory_percent: 最大内存使用比例（0-1之间），如0.5表示使用50%系统内存
                               如果指定，会覆盖resource_config中的max_memory_mb
            disable_disk_mode: 是否禁用磁盘模式，当设置为True时，队列会在内存满时阻塞等待
                               而不是将数据写入磁盘（默认False）
            hide_technical_terms: 是否隐藏底层技术词汇（默认True，将底层术语替换为节点）
        """
        global _log_filter_instance
        # 如果启用隐藏技术词汇，添加日志过滤器（只添加一次）
        if hide_technical_terms and _log_filter_instance is None:
            _log_filter_instance = _NodeLogFilter()
            # 将过滤器添加到 core 模块的 logger
            factory_logger = logging.getLogger('factory_queue.core')
            factory_logger.addFilter(_log_filter_instance)

        # 处理内存比例配置
        if max_memory_percent is not None:
            if not (0 < max_memory_percent <= 1):
                raise ValueError(f"max_memory_percent必须在0-1之间，当前值: {max_memory_percent}")

            # 获取系统总内存
            total_memory_mb = psutil.virtual_memory().total / (1024 * 1024)
            calculated_memory_mb = int(total_memory_mb * max_memory_percent)

            logger.info(
                f"系统总内存: {total_memory_mb:.0f}MB, 配置使用比例: {max_memory_percent * 100:.0f}%, 计算得: {calculated_memory_mb}MB")

            # 如果没有提供resource_config，创建一个
            if resource_config is None:
                resource_config = ResourceConfig(max_memory_mb=calculated_memory_mb)
            else:
                # 覆盖max_memory_mb
                resource_config.max_memory_mb = calculated_memory_mb
        
        # 如果启用了禁用磁盘模式，将内存限制设置为系统总内存的90%
        if disable_disk_mode:
            total_memory_mb = psutil.virtual_memory().total / (1024 * 1024)
            calculated_memory_mb = int(total_memory_mb * 0.9)  # 使用90%系统内存
            
            if resource_config is None:
                resource_config = ResourceConfig(max_memory_mb=calculated_memory_mb)
            else:
                resource_config.max_memory_mb = calculated_memory_mb
            
            logger.info(f"禁用磁盘模式已启用，内存限制设置为: {calculated_memory_mb}MB")

        # 创建底层工厂
        self._base_factory = BaseFactory(
            resource_config=resource_config,
            enable_monitor=enable_monitor,
            monitor_interval=monitor_interval
        )

        # 头节点
        self._head_node: Optional[Node] = None
        # 所有节点（包括头节点）
        self._all_nodes: List[Node] = []
        # 输入队列名称（固定）
        self._input_queue_name = "pipeline_input"

        # 是否已构建
        self._built = False
        
        # 存储批量投喂的数据，用于在构建后处理
        self._bulk_feed_data = None

    def head(self, func: Callable, args: Dict[str, Any] = None,
             node_num: int = 1, name: str = "head",
             save_result: bool = False, print_processing: bool = True,
             setup_func: Callable[[Consumer], None] = None,
             teardown_func: Callable[[Consumer], None] = None,
             # 新增：完成回调函数参数
             finish_func: Callable = None,
             finish_args: Dict[str, Any] = None,
             log_finish: bool = True) -> Node:
        """
        创建头节点（流水线起点）
            
        Args:
            func: 处理函数
            args: 函数参数
            node_num: 工位数量
            name: 节点名称（默认"head"）
            save_result: 是否保存处理结果到文件（默认 False）
            print_processing: 是否打印处理日志（默认 True）
            setup_func: 初始化函数（头节点通常不需要，保留以保持接口一致性）
            teardown_func: 清理函数（头节点通常不需要，保留以保持接口一致性）
            finish_func: 完成回调函数，当该节点产生的所有产物被下游消费完后调用
            finish_args: 传递给 finish_func 的额外参数
            log_finish: 是否打印完成日志（默认 True）
            
        Returns:
            头节点对象
        """
        if self._head_node is not None:
            raise ValueError("头节点已存在，不能重复创建")

        self._head_node = Node(
            factory=self,
            name=name,
            func=func,
            args=args,
            node_num=node_num,
            is_head=True,
            save_result=save_result,
            print_processing=print_processing,
            setup_func=setup_func,
            teardown_func=teardown_func,
            # 新增参数
            finish_func=finish_func,
            finish_args=finish_args,
            log_finish=log_finish
        )

        # 头节点的输入队列是固定的
        self._head_node.set_input_queue_name(self._input_queue_name)

        return self._head_node

    def register_node(self, node: Node) -> None:
        """注册节点到工厂"""
        self._all_nodes.append(node)

    def get_temp_dir(self) -> str:
        """获取临时目录路径"""
        return self._base_factory.resource_config.temp_dir

    def _register_node(self, node: Node):
        """私有方法，已弃用，使用 register_node 代替"""
        self.register_node(node)

    def _build(self):
        """
        构建流水线：创建所有队列和节点组
        在start()时自动调用
        """
        if self._built:
            return

        if self._head_node is None:
            raise ValueError("请先创建头节点")

        logger.info("开始构建流水线...")

        # 创建输入队列
        self._base_factory.create_queue(self._input_queue_name, max_size=5000)

        # 遍历所有节点，创建对应的节点组
        for node in self._all_nodes:
            self._build_node(node)

        self._built = True
        logger.info(f"流水线构建完成，共 {len(self._all_nodes)} 个节点")

    def _build_node(self, node: Node) -> None:
        """
        为单个节点创建内部处理组
        
        - 中间节点：有下游节点，需要传递数据
        - 叶子节点：无下游节点，仅处理数据
        
        Args:
            node: 要构建的节点
        """
        # 获取节点输入队列
        input_queue_name = node.input_queue_name

        # 判断节点类型：是否有下游
        has_downstream = node.has_downstream()

        if has_downstream:
            # 中间节点：创建内部处理组
            output_queue_names = list(node.output_feeds.values())

            # 为每个输出队列创建队列对象
            # 使用节点指定的队列大小，如果没有指定则使用全局配置
            queue_size = node.output_queue_size if node.output_queue_size is not None else self._base_factory.resource_config.max_queue_size
            for queue_name in output_queue_names:
                self._base_factory.create_queue(queue_name, max_size=queue_size)

            # 创建内部处理组（使用节点名作为组名，这样worker_id就是节点名_工位号）
            producer_group_name = f"{node.name}_producer_group"
            node.set_group_name(producer_group_name)

            self._base_factory.create_producer_group(
                name=node.name,  # 使用节点名，生成简洁的worker_id
                input_queue_name=input_queue_name,
                output_consumer_names=output_queue_names,
                process_func=node.build_process_func(),
                num_workers=node.node_num,
                process_func_args={},
                setup_func=node.setup_func,
                teardown_func=node.teardown_func
            )
            # 更新组名为实际创建的组名（用于内部引用）
            node.set_group_name(node.name)

            logger.info(
                f"节点 [{node.name}] 创建为节点组，"
                f"工位数={node.node_num}, 输出队列={output_queue_names}, 队列大小={queue_size}"
            )
        else:
            # 叶子节点：创建内部处理组（使用节点名作为组名）
            consumer_group_name = f"{node.name}_consumer_group"
            node.set_group_name(consumer_group_name)

            # 绑定上游节点（使用上游节点的group_name）
            bind_names = None
            upstream = node.upstream_node
            if upstream and upstream.group_name:
                bind_names = [upstream.group_name]

            self._base_factory.create_consumer_group(
                name=input_queue_name,  # 队列名
                consume_func=node.build_consume_func(),
                num_workers=node.node_num,
                batch_size=node.batch_size,
                batch_timeout=None,
                bind_producer_names=bind_names,
                consume_func_args={},
                setup_func=node.setup_func,
                teardown_func=node.teardown_func
            )
            # 更新组名为实际的组名（就是input_queue_name）
            node.set_group_name(input_queue_name)

            logger.info(
                f"节点 [{node.name}] 创建为节点组，"
                f"工位数={node.node_num}, 绑定上游={bind_names}, 批量大小={node.batch_size}"
            )

    def feed(self, data: Any) -> bool:
        """
        向流水线投放数据
        
        Args:
            data: 要处理的数据
        
        Returns:
            是否投放成功
        """
        if not self._built:
            raise RuntimeError("请先调用 start() 启动流水线")
        return self._base_factory.feed(self._input_queue_name, data)

    def feed_batch(self, data_list: List[Any]) -> None:
        """
        批量投放数据
        
        Args:
            data_list: 数据列表
        """
        if not self._built:
            raise RuntimeError("请先调用 start() 启动流水线")
        self._base_factory.feed_batch(self._input_queue_name, data_list)

    def bulk_feed(self, data_list: List[Any]) -> None:
        """
        批量投放数据（仅允许在启动前）
        注意：使用bulk_feed后，仍需手动调用end_feed()来结束投喂
        
        Args:
            data_list: 数据列表
        """
        if self._built:
            raise RuntimeError("流水线已启动，不允许批量投喂数据，请使用feed方法逐个投喂")
        
        # 如果尚未构建，存储数据，稍后在start时处理
        if self._bulk_feed_data is not None:
            raise RuntimeError("已经设置了一次批量投喂数据，不能重复设置")
        self._bulk_feed_data = data_list

    def end_feed(self) -> None:
        """
        通知头节点：没有更多数据了
        """
        if self._head_node and self._head_node.group_name:
            self._base_factory.end_feed(self._head_node.group_name)
            logger.info(f"已通知头节点 [{self._head_node.name}] 结束投喂")
        else:
            logger.warning("头节点不存在或未构建，无法通知结束投喂")

    def start(self) -> None:
        """启动流水线，自动构建所有节点"""
        self._build()
        
        # 如果有批量投喂的数据，先投喂数据
        if self._bulk_feed_data is not None:
            # 将数据批量放入输入队列
            self._base_factory.bulk_feed(self._input_queue_name, self._bulk_feed_data)
            self._bulk_feed_data = None  # 清除数据
        
        self._base_factory.start()
        logger.info("流水线已启动")

    def wait_complete(self, timeout: float = None) -> None:
        """
        等待流水线处理完成
        
        实现逻辑：
        1. 启动监控线程，检测中间节点完成并自动通知下游
        2. 等待所有叶子节点完成
        3. 停止监控线程
        
        Args:
            timeout: 超时时间（秒），默认无限等待
        """
        # 启动自动通知线程
        stop_monitor = threading.Event()

        def auto_notify_downstream():
            """监控中间节点，完成后自动通知下游"""
            notified = set()  # 已通知的节点

            while not stop_monitor.is_set():
                time.sleep(0.5)  # 检查间隔

                # 遍历所有中间节点
                for node in self._all_nodes:
                    if not node.group_name:
                        continue

                    # 跳过已通知的节点
                    if node.group_name in notified:
                        continue

                    # 只处理中间节点
                    if not node.has_downstream():
                        continue

                    # 检查该节点是否完成
                    stats = self._base_factory.stats
                    pg_stats = stats.get("producer_groups", {}).get(node.group_name)

                    if pg_stats and pg_stats.get("finished"):
                        # 该节点已完成，通知所有下游节点
                        for downstream_node in node.downstream_nodes:
                            if downstream_node.group_name and downstream_node.has_downstream():
                                # 下游也是中间节点
                                self._base_factory.end_feed(downstream_node.group_name)
                                logger.info(
                                    f"节点 [{node.name}] 完成，自动通知下游节点 [{downstream_node.name}] 结束投喂"
                                )

                        notified.add(node.group_name)

                # 检查是否所有节点都已完成，如果是则退出循环
                all_completed = True
                for node in self._all_nodes:
                    if node.group_name:
                        stats = self._base_factory.stats
                        if node.has_downstream():
                            # 中间节点
                            pg_stats = stats.get("producer_groups", {}).get(node.group_name)
                            if not (pg_stats and pg_stats.get("finished")):
                                all_completed = False
                                break
                        else:
                            # 叶子节点
                            cg_stats = stats.get("consumer_groups", {}).get(node.group_name)
                            if not (cg_stats and cg_stats.get("finished")):
                                all_completed = False
                                break
                
                # 如果所有节点都完成了，设置停止事件
                if all_completed:
                    stop_monitor.set()

        # 启动监控线程
        monitor_thread = threading.Thread(target=auto_notify_downstream, daemon=True)
        monitor_thread.start()

        try:
            # 等待底层工厂完成（等待所有节点）
            self._base_factory.wait_complete(timeout=timeout)
        finally:
            # 停止监控线程
            stop_monitor.set()
            monitor_thread.join(timeout=1)

    def stop(self) -> None:
        """停止流水线，中断所有处理线程"""
        self._base_factory.stop()

    def close(self) -> None:
        """关闭流水线，清理资源"""
        self._base_factory.close()

    @property
    def stats(self) -> Dict:
        """
        获取流水线统计信息
        只返回队列统计信息，不包含生产者/消费者组详情
        """
        raw_stats = self._base_factory.stats
        # 只返回队列统计信息
        return {
            'queues': raw_stats.get('queues', {})
        }

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
