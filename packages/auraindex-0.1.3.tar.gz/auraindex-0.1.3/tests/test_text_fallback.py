from pathlib import Path

from auraindex.extractors.text_fallback import extract_text_fallback_file


def test_text_fallback_extracts_raw_sql_literals(tmp_path: Path) -> None:
    sample = tmp_path / "repo.js"
    sample.write_text(
        """
const sql = "SELECT id FROM users WHERE status = 'active' ORDER BY created_at DESC";
db.query(sql);
""".strip(),
        encoding="utf-8",
    )

    candidates, warnings = extract_text_fallback_file(sample, language="javascript")
    assert not warnings
    assert any("SELECT id FROM users" in item.sql for item in candidates)


def test_text_fallback_extracts_builder_chain_pseudo_sql(tmp_path: Path) -> None:
    sample = tmp_path / "repo.php"
    sample.write_text(
        """
<?php
$rows = DB::table('orders')->where('user_id', $uid)->where('status', 'paid')->orderBy('created_at')->get();
""".strip(),
        encoding="utf-8",
    )

    candidates, warnings = extract_text_fallback_file(sample, language="php")
    assert not warnings
    assert any("FROM orders" in item.sql and "WHERE user_id = ? AND status = ?" in item.sql for item in candidates)
