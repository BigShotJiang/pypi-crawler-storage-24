from pathlib import Path

from auraindex.analyzers.sql_ast import analyze_sql_candidates
from auraindex.extractors.sql_files import extract_sql_file


def test_sql_file_extractor_strips_dump_comments_before_parsing(tmp_path: Path) -> None:
    dump = tmp_path / "anime.sql"
    dump.write_text(
        """
--
-- Dumping data for table `admins`
--
INSERT INTO `admins` (`id`, `email`) VALUES (1, 'admin@example.com');
""".strip(),
        encoding="utf-8",
    )

    candidates = extract_sql_file(dump)
    assert len(candidates) == 1
    assert candidates[0].sql.lower().startswith("insert into `admins`")
    assert "-- dumping data" not in candidates[0].sql.lower()

    parsed, failures = analyze_sql_candidates(candidates, dialect="postgres")
    assert len(parsed) == 1
    assert not failures
