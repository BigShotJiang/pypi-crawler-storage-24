# Changelog

## 0.0.3 (2026-03-14)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/brand-dot-dev/context-python-sdk/compare/v0.0.2...v0.0.3)

### Chores

* update SDK settings ([0c90793](https://github.com/brand-dot-dev/context-python-sdk/commit/0c90793462f3394063c47abf0bfb3b2bed60b685))

## 0.0.2 (2026-03-14)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/brand-dot-dev/context-python-sdk/compare/v0.0.1...v0.0.2)

### Chores

* configure new SDK language ([0277c2c](https://github.com/brand-dot-dev/context-python-sdk/commit/0277c2c3a9c03e58f50a2628c133612140dd6f73))
* update SDK settings ([154e20a](https://github.com/brand-dot-dev/context-python-sdk/commit/154e20a04eed818849ddcada3f11d97b918abf46))
* update SDK settings ([212e987](https://github.com/brand-dot-dev/context-python-sdk/commit/212e987d1d5d6dbbf0bc5f5a1a6eab6a69e67775))
