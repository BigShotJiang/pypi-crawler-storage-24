"""Framework integrations for vertaling."""
