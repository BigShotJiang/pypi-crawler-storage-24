from setuptools import setup, find_packages

setup(
    name="neeleshsingour",
    version="1.0.3",  # 👈 वर्ज़न बढ़ा दिया है
    packages=find_packages(),
    description="A simple Python Desktop Framework with HTML/CSS/JS and SQLite Support",
    long_description="A framework to build lightweight desktop apps using Python and Web technologies.",
    long_description_content_type="text/markdown",
    author="Neelesh Singour",
    install_requires=[
        "pywebview",
        "pyinstaller",
        "watchdog",
    ],
    entry_points={
        "console_scripts": [
            "nsx = nsx.cli:main", # पक्का करें कि आपका फोल्डर 'nsx' नाम का है और उसमें cli.py है
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
    ],
)