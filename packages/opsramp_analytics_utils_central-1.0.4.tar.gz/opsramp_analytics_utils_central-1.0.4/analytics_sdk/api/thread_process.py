from queue import Queue
from threading import Thread


class Worker(Thread):
    """Thread executing tasks from a given tasks queue"""
    def __init__(self, tasks, config=None):
        Thread.__init__(self)
        self.tasks = tasks
        self._config = config
        self.daemon = True
        self.start()

    def run(self):
        # Propagate parent thread's config into this worker thread's local storage
        if self._config is not None:
            from analytics_sdk.utilities import _thread_initializer
            _thread_initializer(self._config)
        while True:
            func, args, kargs = self.tasks.get()
            try:
                func(*args, **kargs)
            except Exception as e:
                print (e)
            finally:
                self.tasks.task_done()


class ThreadPool:
    """Pool of threads consuming tasks from a queue"""
    def __init__(self, num_threads, config=None):
        self.tasks = Queue(num_threads)
        for _ in range(num_threads): Worker(self.tasks, config=config)

    def add_task(self, func, *args, **kargs):
        """Add a task to the queue"""
        self.tasks.put((func, args, kargs))

    def wait_completion(self):
        """Wait for completion of all the tasks in the queue"""
        self.tasks.join()