"""CLI entry point — setup wizard and MCP server runner."""

from __future__ import annotations

import json
import os
import platform
import sys
from pathlib import Path

from agentping.config import DEFAULT_RELAY_URL, get_api_key, load_config, save_config

# IDE auto-config targets
def _claude_code_path() -> Path:
    return Path.home() / ".claude.json"

def _cursor_path() -> Path:
    return Path.home() / ".cursor" / "mcp.json"

def _claude_desktop_path() -> Path:
    if platform.system() == "Darwin":
        return Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    elif platform.system() == "Windows":
        return Path(os.environ.get("APPDATA", "")) / "Claude" / "claude_desktop_config.json"
    return Path.home() / ".config" / "Claude" / "claude_desktop_config.json"

def _vscode_path() -> Path:
    if platform.system() == "Darwin":
        return Path.home() / "Library" / "Application Support" / "Code" / "User" / "mcp.json"
    elif platform.system() == "Windows":
        return Path(os.environ.get("APPDATA", "")) / "Code" / "User" / "mcp.json"
    return Path.home() / ".config" / "Code" / "User" / "mcp.json"


IDES = [
    ("1", "Claude Code",    "claude_code"),
    ("2", "Cursor",         "cursor"),
    ("3", "Claude Desktop", "claude_desktop"),
    ("4", "VS Code",        "vscode"),
    ("5", "Other / manual", "manual"),
]


def _write_mcp_config(ide: str, api_key: str, agent_name: str) -> bool:
    """Write MCP config for the chosen IDE. Returns True on success."""
    mcp_block = {
        "mcpServers": {
            "agentping": {
                "command": "agentping",
                "env": {
                    "AGENTPING_API_KEY": api_key,
                    "AGENTPING_AGENT_NAME": agent_name,
                },
            }
        }
    }

    try:
        if ide == "claude_code":
            path = _claude_code_path()
            if path.exists():
                config = json.loads(path.read_text())
            else:
                config = {}
            config.setdefault("mcpServers", {})["agentping"] = mcp_block["mcpServers"]["agentping"]
            path.write_text(json.dumps(config, indent=4))
            print(f"\n  ✓ Written to {path}")
            print("  Restart Claude Code to apply.")

        elif ide in ("cursor", "vscode", "claude_desktop"):
            path = _cursor_path() if ide == "cursor" else (
                _vscode_path() if ide == "vscode" else _claude_desktop_path()
            )
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.exists():
                existing = json.loads(path.read_text())
                existing.setdefault("mcpServers", {})["agentping"] = mcp_block["mcpServers"]["agentping"]
                path.write_text(json.dumps(existing, indent=2))
            else:
                path.write_text(json.dumps(mcp_block, indent=2))
            print(f"\n  ✓ Written to {path}")
            print("  Restart your IDE to apply.")

        else:
            return False

        return True

    except Exception as e:
        print(f"\n  ✗ Could not write config: {e}")
        return False


def setup() -> None:
    """Interactive setup wizard."""
    print()
    print("  AgentPing Setup")
    print("  " + "─" * 40)
    print()

    existing = load_config()

    # API Key
    current_key = existing.get("api_key", "")
    masked = f"{current_key[:12]}...{current_key[-4:]}" if len(current_key) > 16 else "(not set)"
    print(f"  Get your API key at: https://app.agentping.dev/settings")
    print()
    api_key = input(f"  API Key [{masked}]: ").strip()
    if not api_key:
        api_key = current_key
    if not api_key:
        print("\n  Error: API key is required.")
        sys.exit(1)
    if not api_key.startswith("sk-ap_"):
        print("\n  Warning: Key doesn't start with 'sk-ap_'. Double-check you copied the full key.")

    # Agent name
    current_name = existing.get("agent_name", "")
    agent_name = input(f"  Agent name [{current_name or 'my-agent'}]: ").strip()
    if not agent_name:
        agent_name = current_name or "my-agent"

    # Save to config file
    save_config({"api_key": api_key, "agent_name": agent_name, "relay_url": DEFAULT_RELAY_URL})
    print()
    print("  ✓ Config saved to ~/.agentping/config.json")
    print()

    # IDE selection
    print("  Which IDE should AgentPing be added to?")
    print()
    for num, name, _ in IDES:
        print(f"    {num}) {name}")
    print()
    choice = input("  Choose [1]: ").strip() or "1"

    ide = next((key for num, _, key in IDES if num == choice), "manual")

    mcp_config = {
        "mcpServers": {
            "agentping": {
                "command": "agentping",
                "env": {
                    "AGENTPING_API_KEY": api_key,
                    "AGENTPING_AGENT_NAME": agent_name,
                },
            }
        }
    }

    if ide == "manual":
        print()
        print("  Add this to your IDE's MCP config file:")
        print()
        print(json.dumps(mcp_config, indent=2))
        print()
    else:
        success = _write_mcp_config(ide, api_key, agent_name)
        if not success:
            print()
            print("  Add this manually to your IDE's MCP config:")
            print()
            print(json.dumps(mcp_config, indent=2))
            print()

    # Per-IDE: explain AgentPing-as-gatekeeper pattern
    AGENTPING_RULE = (
        "When you need approval or have a question, use bridge_send_approval() or\n"
        "  bridge_ask_question() to notify the developer's phone, then immediately ask\n"
        "  the same question directly in the terminal. Use whichever response comes\n"
        "  first, and call bridge_dismiss() to cancel the other channel."
    )

    ide_gatekeeper = {
        "claude_code": {
            "rules_file": "CLAUDE.md (project root)",
            "bypass": (
                "  Both channels work simultaneously — terminal prompt is the local\n"
                "  channel, AgentPing is the remote channel (phone/browser).\n"
                "  No extra config needed.\n"
                "\n"
                "  If you previously ran `agentping gatekeeper on`, run:\n"
                "    agentping gatekeeper off"
            ),
        },
        "cursor": {
            "rules_file": ".cursor/rules (project root)",
            "bypass": (
                "  Cursor runs in agent mode — the rule above handles dual-channel.\n"
                "  No extra config needed."
            ),
        },
        "vscode": {
            "rules_file": ".github/copilot-instructions.md",
            "bypass": (
                "  VS Code Copilot will use both channels automatically.\n"
                "  No extra config needed."
            ),
        },
        "claude_desktop": {
            "rules_file": "System prompt in Claude Desktop settings",
            "bypass": (
                "  Paste the rule above into your Claude Desktop system prompt.\n"
                "  Both phone and chat channels will be active."
            ),
        },
    }

    tip = ide_gatekeeper.get(ide)
    if tip:
        print()
        print("  " + "─" * 40)
        print("  Let AgentPing be your approval gatekeeper")
        print("  " + "─" * 40)
        print()
        print(f"  Add this rule to {tip['rules_file']}:")
        print()
        print(f"    {AGENTPING_RULE}")
        print()
        print(tip["bypass"])
        print()

    print()
    print("  All done! Your agent can now use bridge_* tools to reach you.")
    print("  Test it anytime: bridge_ping()")
    print()


def gatekeeper(enable: bool, global_mode: bool = False) -> None:
    """Toggle Claude Code auto-approve (AgentPing gatekeeper mode)."""
    if global_mode:
        settings_path = _claude_code_path()  # ~/.claude.json
        label = "global (~/.claude.json)"
    else:
        settings_path = Path.cwd() / ".claude" / "settings.json"
        label = f"project ({settings_path})"

    if enable:
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        existing = json.loads(settings_path.read_text()) if settings_path.exists() else {}
        existing["permissions"] = {"allow": ["*"]}
        settings_path.write_text(json.dumps(existing, indent=2))
        print()
        print(f"  ✓ Gatekeeper ON  [{label}]")
        print("  Claude Code will skip terminal prompts.")
        print("  All approvals flow through AgentPing.")
        print()
    else:
        if settings_path.exists():
            existing = json.loads(settings_path.read_text())
            existing.pop("permissions", None)
            if existing:
                settings_path.write_text(json.dumps(existing, indent=2))
            else:
                settings_path.unlink()
        print()
        print(f"  ✓ Gatekeeper OFF  [{label}]")
        print("  Claude Code will resume showing terminal prompts.")
        print()


def main() -> None:
    """CLI entry point."""
    args = sys.argv[1:]

    if args and args[0] == "setup":
        setup()
        return

    if args and args[0] == "gatekeeper":
        if len(args) < 2 or args[1] not in ("on", "off"):
            print("Usage: agentping gatekeeper on|off [--global]")
            sys.exit(1)
        enable = args[1] == "on"
        global_mode = "--global" in args
        gatekeeper(enable, global_mode)
        return

    if args and args[0] in ("-h", "--help", "help"):
        print("Usage:")
        print("  agentping                      Run the MCP server")
        print("  agentping setup                Configure API key and IDE config")
        print("  agentping gatekeeper on        Skip Claude Code prompts (use AgentPing instead)")
        print("  agentping gatekeeper off       Restore Claude Code terminal prompts")
        print("  agentping gatekeeper on --global   Apply to all projects (~/.claude.json)")
        return

    # Default: run as MCP server
    api_key = get_api_key()
    if not api_key:
        print("Error: No API key configured.")
        print("Run `agentping setup` or set AGENTPING_API_KEY env var.")
        sys.exit(1)

    from agentping.server import main as server_main
    server_main()
