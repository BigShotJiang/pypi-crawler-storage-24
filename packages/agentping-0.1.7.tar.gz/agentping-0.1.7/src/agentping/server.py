"""MCP server exposing 9 bridge tools via the AgentPing relay."""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from mcp.server.fastmcp import FastMCP
from agentping.config import get_agent_name, get_api_key, get_relay_url
from agentping.ws_client import RelayClient

logger = logging.getLogger("agentping")
mcp = FastMCP("AgentPing")
_client: Optional[RelayClient] = None


async def _get_client() -> RelayClient:
    global _client
    if _client is None:
        api_key = get_api_key()
        if not api_key:
            raise RuntimeError("No API key. Run `agentping setup` or set AGENTPING_API_KEY.")
        _client = RelayClient(get_relay_url(), api_key, get_agent_name())
        await _client.connect()
    return _client


def _err(msg: str) -> Dict[str, Any]:
    return {"status": "error", "error": msg}


async def _send(msg_type: str, title: str, **kwargs) -> Dict[str, Any]:
    """Helper: connect, send message, return result."""
    try:
        client = await _get_client()
        if not await client.wait_connected(timeout=10.0):
            return _err("Not connected to relay")
        mid = await client.send_message(message_type=msg_type, title=title, **kwargs)
        if mid:
            return {"status": "sent", "request_id": mid} if msg_type in ("approval", "question") \
                else {"status": "sent", "message_id": mid}
        return _err(f"Failed to send {msg_type} (no ack)")
    except Exception as e:
        return _err(str(e))


@mcp.tool()
async def bridge_ping() -> Dict[str, Any]:
    """Test connectivity to the AgentPing relay service."""
    try:
        client = await _get_client()
        if await client.wait_connected(timeout=10.0):
            return {"status": "connected", "relay": client._relay_url,
                    "connection_id": client._connection_id}
        return _err("Could not connect to relay within 10 seconds")
    except Exception as e:
        return _err(str(e))


@mcp.tool()
async def bridge_send_approval(
    title: str, description: str = "", options: Optional[List[str]] = None,
    code_context: str = "", urgency: str = "medium",
) -> Dict[str, Any]:
    """Send an approval request to the developer's phone/browser via AgentPing.
    Returns a request_id immediately (non-blocking).

    IMPORTANT — Dual-channel approval pattern:
    1. Call this tool to send the approval to the developer's phone.
    2. Immediately ALSO ask the user the same question directly in your chat/terminal.
    3. If the user responds locally first, call bridge_dismiss(request_id) to cancel the phone notification.
    4. If the phone response arrives first (check with bridge_check_response), use that response.

    This ensures the developer can respond from whichever device is most convenient."""
    return await _send("approval", title, description=description or None,
                       code_context=code_context or None, options=options, urgency=urgency)


@mcp.tool()
async def bridge_ask_question(
    question: str, context: str = "", options: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Ask the developer a question via AgentPing (phone/browser).
    Returns a request_id immediately (non-blocking).

    IMPORTANT — Dual-channel pattern:
    1. Call this tool to send the question to the developer's phone.
    2. Immediately ALSO ask the user the same question directly in your chat/terminal.
    3. First response wins — call bridge_dismiss(request_id) to cancel the other channel."""
    return await _send("question", question, description=context or None, options=options)


@mcp.tool()
async def bridge_wait_response(request_id: str, timeout: int = 300) -> Dict[str, Any]:
    """Block until the developer responds to a request."""
    try:
        client = await _get_client()
        result = await client.wait_response(request_id, timeout=float(timeout))
        if result.get("has_response"):
            return {"status": result["status"], "response": result.get("response_text"),
                    "responder": "developer"}
        return {"status": "timeout", "response": None, "responder": None}
    except Exception as e:
        return _err(str(e))


@mcp.tool()
async def bridge_check_response(request_id: str) -> Dict[str, Any]:
    """Non-blocking check if the developer has responded."""
    try:
        client = await _get_client()
        result = await client.check_response(request_id)
        if result is None:
            return _err("Failed to check response (relay timeout)")
        return {"has_response": result.get("has_response", False),
                "status": result.get("status", "pending"),
                "response": result.get("response_text")}
    except Exception as e:
        return _err(str(e))


@mcp.tool()
async def bridge_dismiss(request_id: str) -> Dict[str, Any]:
    """Dismiss a pending approval/question on the developer's phone/inbox.
    Call this after the user responds locally in the terminal, so the
    phone notification is cleared and the request no longer appears in the inbox."""
    try:
        client = await _get_client()
        result = await client.dismiss_message(request_id)
        if result and not result.get("error"):
            return {"status": "dismissed", "request_id": request_id}
        return _err(result.get("error", "Failed to dismiss"))
    except Exception as e:
        return _err(str(e))


@mcp.tool()
async def bridge_approve_and_wait(
    title: str, description: str = "", options: Optional[List[str]] = None,
    code_context: str = "", urgency: str = "medium", timeout: int = 300,
) -> Dict[str, Any]:
    """Send an approval request and block until the developer responds via phone/browser.
    WARNING: This blocks — the user cannot respond in the terminal while waiting.
    Prefer bridge_send_approval() + asking the user directly for dual-channel approval."""
    result = await bridge_send_approval(title, description, options, code_context, urgency)
    if result.get("status") == "error":
        return result
    return await bridge_wait_response(result["request_id"], timeout)


@mcp.tool()
async def bridge_send_update(
    title: str, details: str = "", progress_pct: Optional[int] = None, status: str = "in_progress",
) -> Dict[str, Any]:
    """Send a progress update to the developer (fire-and-forget, no response needed)."""
    return await _send("update", title, description=details or None, progress_pct=progress_pct,
                       urgency="low", metadata={"status_label": status} if status else None)


@mcp.tool()
async def bridge_task_complete(
    title: str, summary: str = "", files_changed: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Notify the developer that a task is complete (fire-and-forget)."""
    return await _send("task_complete", title, description=summary or None,
                       files_changed=files_changed, urgency="low")


@mcp.tool()
async def bridge_list_pending() -> Dict[str, Any]:
    """List all unanswered requests waiting for developer response."""
    try:
        client = await _get_client()
        if not await client.wait_connected(timeout=10.0):
            return _err("Not connected to relay")
        msgs = await client.list_pending()
        return {"status": "ok", "pending": msgs, "count": len(msgs)}
    except Exception as e:
        return _err(str(e))


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(name)s: %(message)s")
    mcp.run()
