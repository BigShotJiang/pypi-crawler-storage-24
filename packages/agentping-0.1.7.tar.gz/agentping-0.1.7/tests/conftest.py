"""Test fixtures and mcp module mock for Python <3.10 environments."""

from __future__ import annotations

import sys
from unittest.mock import MagicMock

# Mock the mcp module if not installed (Python <3.10)
if "mcp" not in sys.modules:
    mcp_mock = MagicMock()

    # Mock FastMCP so @mcp.tool() decorators pass through
    class FakeFastMCP:
        def __init__(self, *args, **kwargs):
            pass

        def tool(self, *args, **kwargs):
            def decorator(fn):
                return fn
            return decorator

        def run(self):
            pass

    mcp_mock.server.fastmcp.FastMCP = FakeFastMCP
    sys.modules["mcp"] = mcp_mock
    sys.modules["mcp.server"] = mcp_mock.server
    sys.modules["mcp.server.fastmcp"] = mcp_mock.server.fastmcp
