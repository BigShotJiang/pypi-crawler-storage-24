"""Tests for MCP server tool functions."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

import agentping.server as server_module
from agentping.server import (
    bridge_ask_question,
    bridge_check_response,
    bridge_list_pending,
    bridge_ping,
    bridge_send_approval,
    bridge_send_update,
    bridge_task_complete,
    bridge_wait_response,
)


@pytest.fixture(autouse=True)
def reset_client():
    """Reset the global client before each test."""
    server_module._client = None
    yield
    server_module._client = None


@pytest.fixture
def mock_client():
    """Create a mock RelayClient."""
    client = AsyncMock()
    client._relay_url = "wss://test/ws"
    client._connection_id = "conn-123"
    client.is_connected = True
    client.wait_connected = AsyncMock(return_value=True)
    return client


class TestBridgePing:
    @pytest.mark.asyncio
    async def test_ping_connected(self, mock_client):
        with patch.object(server_module, "_client", mock_client):
            result = await bridge_ping()
            assert result["status"] == "connected"
            assert result["connection_id"] == "conn-123"

    @pytest.mark.asyncio
    async def test_ping_not_connected(self, mock_client):
        mock_client.wait_connected = AsyncMock(return_value=False)
        with patch.object(server_module, "_client", mock_client):
            result = await bridge_ping()
            assert result["status"] == "error"


class TestBridgeSendApproval:
    @pytest.mark.asyncio
    async def test_send_approval_success(self, mock_client):
        mock_client.send_message = AsyncMock(return_value="msg-456")
        with patch.object(server_module, "_client", mock_client):
            result = await bridge_send_approval(
                title="Refactor auth module",
                description="Extract into service",
                urgency="high",
            )
            assert result["status"] == "sent"
            assert result["request_id"] == "msg-456"

    @pytest.mark.asyncio
    async def test_send_approval_no_ack(self, mock_client):
        mock_client.send_message = AsyncMock(return_value=None)
        with patch.object(server_module, "_client", mock_client):
            result = await bridge_send_approval(title="Test")
            assert result["status"] == "error"


class TestBridgeAskQuestion:
    @pytest.mark.asyncio
    async def test_ask_question_success(self, mock_client):
        mock_client.send_message = AsyncMock(return_value="msg-789")
        with patch.object(server_module, "_client", mock_client):
            result = await bridge_ask_question(
                question="Which DB driver?",
                options=["psycopg2", "asyncpg"],
            )
            assert result["status"] == "sent"
            assert result["request_id"] == "msg-789"


class TestBridgeWaitResponse:
    @pytest.mark.asyncio
    async def test_wait_response_approved(self, mock_client):
        mock_client.wait_response = AsyncMock(return_value={
            "has_response": True,
            "status": "approved",
            "response_text": None,
        })
        with patch.object(server_module, "_client", mock_client):
            result = await bridge_wait_response(request_id="msg-456", timeout=10)
            assert result["status"] == "approved"
            assert result["responder"] == "developer"

    @pytest.mark.asyncio
    async def test_wait_response_timeout(self, mock_client):
        mock_client.wait_response = AsyncMock(return_value={
            "has_response": False,
            "status": "timeout",
            "message_id": "msg-456",
        })
        with patch.object(server_module, "_client", mock_client):
            result = await bridge_wait_response(request_id="msg-456", timeout=1)
            assert result["status"] == "timeout"


class TestBridgeCheckResponse:
    @pytest.mark.asyncio
    async def test_check_response_pending(self, mock_client):
        mock_client.check_response = AsyncMock(return_value={
            "has_response": False,
            "status": "pending",
        })
        with patch.object(server_module, "_client", mock_client):
            result = await bridge_check_response(request_id="msg-456")
            assert result["has_response"] is False
            assert result["status"] == "pending"

    @pytest.mark.asyncio
    async def test_check_response_replied(self, mock_client):
        mock_client.check_response = AsyncMock(return_value={
            "has_response": True,
            "status": "replied",
            "response_text": "Use asyncpg",
        })
        with patch.object(server_module, "_client", mock_client):
            result = await bridge_check_response(request_id="msg-456")
            assert result["has_response"] is True
            assert result["response"] == "Use asyncpg"


class TestBridgeSendUpdate:
    @pytest.mark.asyncio
    async def test_send_update(self, mock_client):
        mock_client.send_message = AsyncMock(return_value="msg-upd")
        with patch.object(server_module, "_client", mock_client):
            result = await bridge_send_update(
                title="Running tests",
                progress_pct=65,
            )
            assert result["status"] == "sent"


class TestBridgeTaskComplete:
    @pytest.mark.asyncio
    async def test_task_complete(self, mock_client):
        mock_client.send_message = AsyncMock(return_value="msg-done")
        with patch.object(server_module, "_client", mock_client):
            result = await bridge_task_complete(
                title="Auth refactoring complete",
                files_changed=["auth.py", "tests/test_auth.py"],
            )
            assert result["status"] == "sent"


class TestBridgeListPending:
    @pytest.mark.asyncio
    async def test_list_pending(self, mock_client):
        mock_client.list_pending = AsyncMock(return_value=[
            {"message_id": "1", "type": "approval", "title": "Approve refactor"},
            {"message_id": "2", "type": "question", "title": "Which driver?"},
        ])
        with patch.object(server_module, "_client", mock_client):
            result = await bridge_list_pending()
            assert result["status"] == "ok"
            assert result["count"] == 2
            assert len(result["pending"]) == 2
