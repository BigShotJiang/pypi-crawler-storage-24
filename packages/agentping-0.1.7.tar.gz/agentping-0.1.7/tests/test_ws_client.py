"""Tests for WebSocket client — message construction, queue, and state."""

from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from agentping.ws_client import RelayClient


class TestRelayClientState:
    def test_initial_state(self):
        client = RelayClient("wss://test/ws", "sk-ap_test", "test-agent")
        assert not client.is_connected
        assert client._queue == []
        assert client._reconnect_attempt == 0

    def test_envelope(self):
        env = RelayClient._envelope("send_message", "msg-1", payload={"title": "test"})
        assert env["type"] == "send_message"
        assert env["id"] == "msg-1"
        assert "timestamp" in env
        assert env["payload"]["title"] == "test"


class TestMessageQueue:
    @pytest.mark.asyncio
    async def test_queue_when_disconnected(self):
        client = RelayClient("wss://test/ws", "sk-ap_test")
        # Not connected, so message should be queued
        frame = {"type": "send_message", "id": "1"}
        await client._send_or_queue(frame)
        assert len(client._queue) == 1
        assert client._queue[0] == frame

    @pytest.mark.asyncio
    async def test_queue_max_size(self):
        client = RelayClient("wss://test/ws", "sk-ap_test")
        for i in range(105):
            await client._send_or_queue({"type": "send_message", "id": str(i)})
        # Should cap at 100, dropping oldest
        assert len(client._queue) == 100
        assert client._queue[0]["id"] == "5"  # first 5 dropped

    @pytest.mark.asyncio
    async def test_send_when_connected(self):
        client = RelayClient("wss://test/ws", "sk-ap_test")
        mock_ws = AsyncMock()
        client._ws = mock_ws
        client._connected.set()

        frame = {"type": "send_message", "id": "1"}
        await client._send_or_queue(frame)

        mock_ws.send.assert_called_once_with(json.dumps(frame))
        assert len(client._queue) == 0

    @pytest.mark.asyncio
    async def test_queue_on_send_failure(self):
        client = RelayClient("wss://test/ws", "sk-ap_test")
        mock_ws = AsyncMock()
        mock_ws.send.side_effect = Exception("connection lost")
        client._ws = mock_ws
        client._connected.set()

        frame = {"type": "send_message", "id": "1"}
        await client._send_or_queue(frame)

        # Should fall back to queue
        assert len(client._queue) == 1

    @pytest.mark.asyncio
    async def test_flush_queue(self):
        client = RelayClient("wss://test/ws", "sk-ap_test")
        client._queue = [
            {"type": "send_message", "id": "1"},
            {"type": "send_message", "id": "2"},
        ]
        mock_ws = AsyncMock()
        client._ws = mock_ws

        await client._flush_queue()

        assert len(client._queue) == 0
        assert mock_ws.send.call_count == 2


class TestCloseAndCleanup:
    @pytest.mark.asyncio
    async def test_close(self):
        client = RelayClient("wss://test/ws", "sk-ap_test")
        client._connected.set()
        mock_ws = AsyncMock()
        client._ws = mock_ws

        await client.close()

        assert client._closing is True
        assert not client.is_connected
        mock_ws.close.assert_called_once()

    @pytest.mark.asyncio
    async def test_wait_connected_timeout(self):
        client = RelayClient("wss://test/ws", "sk-ap_test")
        result = await client.wait_connected(timeout=0.1)
        assert result is False

    @pytest.mark.asyncio
    async def test_wait_connected_already_connected(self):
        client = RelayClient("wss://test/ws", "sk-ap_test")
        client._connected.set()
        result = await client.wait_connected(timeout=1.0)
        assert result is True
