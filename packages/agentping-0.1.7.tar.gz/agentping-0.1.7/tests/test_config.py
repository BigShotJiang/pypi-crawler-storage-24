"""Tests for config loading and saving."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

from agentping.config import (
    DEFAULT_RELAY_URL,
    get_agent_name,
    get_api_key,
    get_relay_url,
    load_config,
    save_config,
)


class TestConfig:
    def test_get_api_key_from_env(self):
        with patch.dict(os.environ, {"AGENTPING_API_KEY": "sk-ap_live_test123"}):
            assert get_api_key() == "sk-ap_live_test123"

    def test_get_relay_url_from_env(self):
        with patch.dict(os.environ, {"AGENTPING_RELAY_URL": "wss://custom.relay.dev/ws"}):
            assert get_relay_url() == "wss://custom.relay.dev/ws"

    def test_get_relay_url_default(self):
        with patch.dict(os.environ, {}, clear=True):
            with patch("agentping.config.load_config", return_value={}):
                assert get_relay_url() == DEFAULT_RELAY_URL

    def test_get_agent_name_from_env(self):
        with patch.dict(os.environ, {"AGENTPING_AGENT_NAME": "claude-code"}):
            assert get_agent_name() == "claude-code"

    def test_get_agent_name_default(self):
        with patch.dict(os.environ, {}, clear=True):
            with patch("agentping.config.load_config", return_value={}):
                assert get_agent_name() == "unknown"

    def test_save_and_load_config(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_dir = tmp_path

        with patch("agentping.config._CONFIG_DIR", config_dir), \
             patch("agentping.config._CONFIG_FILE", config_file):
            save_config({"api_key": "sk-ap_test", "relay_url": "wss://test/ws"})

            loaded = load_config()
            assert loaded["api_key"] == "sk-ap_test"
            assert loaded["relay_url"] == "wss://test/ws"

            # Check file permissions (0o600)
            mode = config_file.stat().st_mode & 0o777
            assert mode == 0o600

    def test_load_config_missing_file(self, tmp_path):
        config_file = tmp_path / "nonexistent.json"
        with patch("agentping.config._CONFIG_FILE", config_file):
            assert load_config() == {}

    def test_load_config_invalid_json(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_file.write_text("not json")
        with patch("agentping.config._CONFIG_FILE", config_file):
            assert load_config() == {}

    def test_env_overrides_config_file(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"api_key": "from-file"}))

        with patch("agentping.config._CONFIG_FILE", config_file), \
             patch.dict(os.environ, {"AGENTPING_API_KEY": "from-env"}):
            assert get_api_key() == "from-env"
