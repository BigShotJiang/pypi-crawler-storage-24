from datetime import datetime, timedelta
from enum import Enum
from typing import Literal, Optional

from pydantic import BaseModel, model_validator

from nuclia_models.common.pagination import Pagination


class ContextRelevanceQuery(BaseModel):
    value: int
    operation: Literal["gt", "lt", "eq"]
    aggregation: Literal["average", "max", "min"]


class Status(Enum):
    SUCCESS = "SUCCESS"
    ERROR = "ERROR"
    NO_CONTEXT = "NO_CONTEXT"

    def get_value(self) -> int:
        mapping = {
            Status.SUCCESS: 0,
            Status.ERROR: -1,
            Status.NO_CONTEXT: -2,
        }
        return mapping[self]


class RemiQuery(BaseModel):
    context_relevance: Optional[ContextRelevanceQuery] = None
    month: str
    from_date: Optional[datetime] = None
    to_date: Optional[datetime] = None
    feedback_good: Optional[bool] = None
    status: Optional[Status] = None
    pagination: Pagination = Pagination()

    @model_validator(mode="after")
    def validate_date_range(self) -> "RemiQuery":
        if self.from_date is None and self.to_date is None:
            return self

        try:
            month_start = datetime.strptime(self.month, "%Y-%m")
        except ValueError as err:
            msg = f"month '{self.month}' must be in YYYY-MM format"
            raise ValueError(msg) from err

        month_end = (month_start.replace(day=28) + timedelta(days=4)).replace(day=1)

        def _validate_boundary(dt: datetime, field_name: str):
            dt_naive = dt.replace(tzinfo=None) if dt.tzinfo else dt
            if dt_naive < month_start or dt_naive >= month_end:
                msg = f"{field_name} must be within the month {self.month}"
                raise ValueError(msg)

        if self.from_date is not None:
            _validate_boundary(self.from_date, "from_date")

        if self.to_date is not None:
            _validate_boundary(self.to_date, "to_date")

        if self.from_date is not None and self.to_date is not None and self.from_date > self.to_date:
            msg = "from_date must be before or equal to to_date"
            raise ValueError(msg)

        return self


class RetrievedContext(BaseModel):
    text: str
    text_block_id: Optional[str] = None


class RemiAnswerRelevance(BaseModel):
    score: int
    reason: str


class RemiScores(BaseModel):
    answer_relevance: RemiAnswerRelevance
    context_relevance: list[int]
    groundedness: list[int]


class RemiQueryResult(BaseModel):
    id: int
    question: str
    date: datetime
    answer: Optional[str]
    remi: Optional[RemiScores]


class RemiQueryResultWithContext(RemiQueryResult):
    context: list[RetrievedContext]


class RemiQueryResults(BaseModel):
    data: list[RemiQueryResult]
    has_more: bool


class AggregatedRemiScoreValues(BaseModel):
    name: str
    min: float
    max: float
    average: float


class AggregatedRemiScoreMetric(BaseModel):
    timestamp: datetime
    metrics: list[AggregatedRemiScoreValues]
