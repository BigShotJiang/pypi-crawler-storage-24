# Intercom Docs Exporter

Export your Intercom Help Center article URLs into a single file. Filter by tags, collections, and publish state. Output as TXT or CSV.

Built to quickly feed help center docs into AI tools like NotebookLM.

## Features

- Filter articles by publish state, tags, and collections
- Export as plain URL list (TXT) or with metadata (CSV)
- Web interface for non-technical users
- CLI for automation and scripting
- Stateless: your API token is never stored

## Quick Start (Web)

Visit **[intercom-docs-exporter.onrender.com](https://intercom-docs-exporter.onrender.com)** and paste your Intercom API token.

## Quick Start (CLI)

```bash
pip install intercom-docs-exporter

# Export all published articles
intercom-docs-exporter --token $INTERCOM_TOKEN

# Export with filters
intercom-docs-exporter --token $INTERCOM_TOKEN --include-tag Internal --format csv -o articles.csv

# List collections
intercom-docs-exporter --token $INTERCOM_TOKEN --list-collections
```

## Examples

**Feed your help center into NotebookLM:**
```bash
# Export all published article URLs to a file
intercom-docs-exporter --token $INTERCOM_TOKEN -o urls.txt
# Upload urls.txt to NotebookLM as a source
```

**Export only public-facing docs as CSV:**
```bash
intercom-docs-exporter --token $INTERCOM_TOKEN \
  --exclude-tag Internal \
  --exclude-tag Draft \
  --format csv \
  -o public_articles.csv
```

**Export a specific collection:**
```bash
intercom-docs-exporter --token $INTERCOM_TOKEN \
  --collection "Getting Started" \
  -o getting_started.txt
```

**Export everything except one collection:**
```bash
intercom-docs-exporter --token $INTERCOM_TOKEN \
  --exclude-collection "Internal Docs" \
  --format csv \
  -o external.csv
```

**Combine tag and collection filters:**
```bash
intercom-docs-exporter --token $INTERCOM_TOKEN \
  --collection "API Reference" \
  --include-tag "v2" \
  --exclude-tag "deprecated" \
  -o api_v2.txt
```

**Include draft articles too:**
```bash
intercom-docs-exporter --token $INTERCOM_TOKEN --state both -o all_articles.txt
```

## Help

```
intercom-docs-exporter --help
```

| Option | Description | Default |
|--------|-------------|---------|
| `--token` | Intercom API access token | *required* |
| `--state` | `published`, `draft`, or `both` | `published` |
| `--include-tag` | Only include articles with this tag (repeatable) | all |
| `--exclude-tag` | Exclude articles with this tag (repeatable) | none |
| `--collection` | Only include this collection (repeatable) | all |
| `--exclude-collection` | Exclude this collection (repeatable) | none |
| `--format` | `txt` or `csv` | `txt` |
| `-o, --output` | Output file path | stdout |
| `--list-collections` | List available collections and exit | |

**Getting your API token:**
1. Go to your Intercom Developer Hub
2. Select your app → Authentication
3. Copy your access token

Your token is only used for the current request and is never stored.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

MIT
