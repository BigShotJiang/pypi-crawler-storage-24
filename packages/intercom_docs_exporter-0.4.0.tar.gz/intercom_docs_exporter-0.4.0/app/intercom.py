"""Intercom API client with pagination support."""

import time

import requests

BASE_URL = "https://api.intercom.io"


class IntercomAPIError(Exception):
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(message)


class IntercomClient:
    """Thin wrapper around the Intercom REST API.

    Handles authentication and cursor-based pagination so callers
    can simply iterate over the full result set.
    """

    def __init__(self, token: str) -> None:
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------------
    # Generic paginated fetcher
    # ------------------------------------------------------------------

    def _fetch_all_pages(self, url: str, params: dict | None = None, sleep_s: float = 0.2) -> list[dict]:
        """Walk through every page of an Intercom list endpoint.

        Intercom returns a ``pages.next`` URL when more results are
        available.  This method follows that cursor until all pages have
        been consumed.

        Args:
            url: The initial API endpoint URL.
            params: Optional query-string parameters for the first request.
            sleep_s: Seconds to wait between requests to stay under rate limits.

        Returns:
            A flat list containing all ``data`` items across every page.
        """
        results: list[dict] = []

        while url:
            resp = requests.get(url, headers=self.headers, params=params)
            if resp.status_code == 401:
                raise IntercomAPIError(401, "Invalid API token. Please check your Intercom access token.")
            if resp.status_code == 429:
                raise IntercomAPIError(429, "Rate limited by Intercom. Please wait and try again.")
            resp.raise_for_status()
            payload = resp.json()

            results.extend(payload.get("data", []))

            pages = payload.get("pages") or {}
            url = pages.get("next")
            params = None  # subsequent pages carry cursor in the URL

            if url:
                time.sleep(sleep_s)

        return results

    # ------------------------------------------------------------------
    # Convenience methods for specific resources
    # ------------------------------------------------------------------

    def fetch_articles(self) -> list[dict]:
        """Return all articles across every page."""
        return self._fetch_all_pages(
            f"{BASE_URL}/articles",
            params={"per_page": 60},
        )

    def fetch_collections(self) -> list[dict]:
        """Return all help-center collections across every page."""
        return self._fetch_all_pages(
            f"{BASE_URL}/help_center/collections",
            params={"per_page": 60},
        )

    def fetch_tags(self) -> list[dict]:
        """Return all tags (single request — Intercom returns them all at once)."""
        resp = requests.get(f"{BASE_URL}/tags", headers=self.headers)
        if resp.status_code == 401:
            raise IntercomAPIError(401, "Invalid API token. Please check your Intercom access token.")
        if resp.status_code == 429:
            raise IntercomAPIError(429, "Rate limited by Intercom. Please wait and try again.")
        resp.raise_for_status()
        payload = resp.json()
        return payload.get("data", [])
