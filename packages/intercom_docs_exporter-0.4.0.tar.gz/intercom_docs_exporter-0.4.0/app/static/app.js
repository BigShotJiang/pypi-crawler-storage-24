/* Intercom Docs Exporter — frontend logic */

document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("tokenInput").addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault();
      loadMeta();
    }
  });
});

function getToken() {
  return document.getElementById("tokenInput").value.trim();
}

function showError(msg) {
  var el = document.getElementById("error");
  el.textContent = msg;
  el.classList.remove("hidden");
}

function hideError() {
  var el = document.getElementById("error");
  el.textContent = "";
  el.classList.add("hidden");
}

function setLoading(on, msg) {
  var loader = document.getElementById("loading");
  var loadBtn = document.getElementById("loadBtn");
  var exportBtn = document.getElementById("exportBtn");

  if (on) {
    loader.textContent = msg || "Loading...";
    loader.classList.remove("hidden");
  } else {
    loader.classList.add("hidden");
  }

  loadBtn.disabled = on;
  if (exportBtn) {
    exportBtn.disabled = on;
    exportBtn.textContent = on ? "Exporting..." : "Export";
  }
}

function toggleTokenVisibility() {
  var input = document.getElementById("tokenInput");
  var eyeIcon = document.getElementById("eyeIcon");
  var eyeOffIcon = document.getElementById("eyeOffIcon");
  if (input.type === "password") {
    input.type = "text";
    eyeIcon.classList.add("hidden");
    eyeOffIcon.classList.remove("hidden");
  } else {
    input.type = "password";
    eyeIcon.classList.remove("hidden");
    eyeOffIcon.classList.add("hidden");
  }
}

/* ── Tri-state pills (shared for collections & tags) ── */
// States: "neutral" → "include" → "exclude" → "neutral"

function renderPills(containerId, items) {
  var container = document.getElementById(containerId);
  container.innerHTML = "";

  if (!items || items.length === 0) {
    container.innerHTML = '<span class="empty-msg">None found</span>';
    return;
  }

  items.forEach(function (item) {
    var pill = document.createElement("button");
    pill.type = "button";
    pill.className = "tag-pill";
    pill.textContent = item.name;
    pill.dataset.name = item.name;
    pill.dataset.state = "neutral";
    pill.addEventListener("click", function () {
      cycleState(pill);
    });
    container.appendChild(pill);
  });
}

function cycleState(pill) {
  var current = pill.dataset.state;
  var next;
  if (current === "neutral") next = "include";
  else if (current === "include") next = "exclude";
  else next = "neutral";

  pill.dataset.state = next;
  pill.className = "tag-pill";
  if (next !== "neutral") pill.classList.add("tag-pill--" + next);
  updateSummary();
}

function getPillsByState(containerId, state) {
  var pills = document.querySelectorAll("#" + containerId + " .tag-pill");
  var result = [];
  pills.forEach(function (pill) {
    if (pill.dataset.state === state) result.push(pill.dataset.name);
  });
  return result;
}

function filterPills(containerId, query) {
  var pills = document.querySelectorAll("#" + containerId + " .tag-pill");
  var q = query.toLowerCase();
  pills.forEach(function (pill) {
    pill.style.display = pill.textContent.toLowerCase().includes(q) ? "" : "none";
  });
}

function clearAllPills(containerId) {
  var pills = document.querySelectorAll("#" + containerId + " .tag-pill");
  pills.forEach(function (pill) {
    pill.dataset.state = "neutral";
    pill.className = "tag-pill";
  });
  updateSummary();
}

/* ── Summary ── */

function updateSummary() {
  var incCols = getPillsByState("collectionPills", "include");
  var excCols = getPillsByState("collectionPills", "exclude");
  var incTags = getPillsByState("tagPills", "include");
  var excTags = getPillsByState("tagPills", "exclude");

  var parts = [];
  if (incCols.length > 0) parts.push(incCols.length + " collection" + (incCols.length > 1 ? "s" : "") + " included");
  if (excCols.length > 0) parts.push(excCols.length + " collection" + (excCols.length > 1 ? "s" : "") + " excluded");
  if (incTags.length > 0) parts.push(incTags.length + " tag" + (incTags.length > 1 ? "s" : "") + " included");
  if (excTags.length > 0) parts.push(excTags.length + " tag" + (excTags.length > 1 ? "s" : "") + " excluded");

  var el = document.getElementById("filterSummary");
  if (parts.length === 0) {
    el.textContent = "No filters — all articles will be exported.";
    el.className = "filter-summary filter-summary--none";
  } else {
    el.textContent = parts.join("  ·  ");
    el.className = "filter-summary filter-summary--active";
  }
}

/* ── Load metadata ── */

function loadMeta() {
  var token = getToken();
  if (!token) {
    showError("Please enter your API token.");
    return;
  }

  hideError();
  setLoading(true, "Connecting to Intercom...");

  var headers = { "Content-Type": "application/json" };
  var body = JSON.stringify({ token: token });

  Promise.all([
    fetch("/api/collections", { method: "POST", headers: headers, body: body }),
    fetch("/api/tags", { method: "POST", headers: headers, body: body }),
  ])
    .then(function (responses) {
      for (var i = 0; i < responses.length; i++) {
        if (responses[i].status === 401) {
          throw new Error("Invalid token. Please check your Intercom API token and try again.");
        }
        if (!responses[i].ok) {
          throw new Error("Failed to load metadata (HTTP " + responses[i].status + ")");
        }
      }
      return Promise.all(responses.map(function (r) { return r.json(); }));
    })
    .then(function (data) {
      var collections = data[0];
      var tags = data[1];

      renderPills("collectionPills", collections);
      renderPills("tagPills", tags);

      // Hide empty cards
      document.getElementById("collectionsCard").classList.toggle("hidden", collections.length === 0);
      document.getElementById("tagsCard").classList.toggle("hidden", tags.length === 0);

      // Collapse token card
      document.getElementById("tokenCard").classList.add("is-collapsed");

      // Show filters with animation
      var filters = document.getElementById("filtersSection");
      filters.classList.remove("hidden");
      requestAnimationFrame(function () {
        filters.classList.add("is-visible");
      });

      document.getElementById("result").classList.add("hidden");
      updateSummary();
      setLoading(false);
    })
    .catch(function (err) {
      setLoading(false);
      showError(err.message || "Failed to load metadata.");
    });
}

/* ── Export ── */

function doExport() {
  var token = getToken();
  if (!token) {
    showError("Please enter your API token.");
    return;
  }

  hideError();
  setLoading(true, "Exporting articles...");

  var stateRadios = document.querySelectorAll('input[name="state"]');
  var state = "published";
  stateRadios.forEach(function (r) {
    if (r.checked) state = r.value;
  });

  var formatRadios = document.querySelectorAll('input[name="format"]');
  var format = "txt";
  formatRadios.forEach(function (r) {
    if (r.checked) format = r.value;
  });

  var includeTags = getPillsByState("tagPills", "include");
  var excludeTags = getPillsByState("tagPills", "exclude");
  var includeCollections = getPillsByState("collectionPills", "include");
  var excludeCollections = getPillsByState("collectionPills", "exclude");

  var payload = {
    token: token,
    format: format,
    state: state,
  };

  if (includeTags.length > 0) payload.include_tags = includeTags;
  if (excludeTags.length > 0) payload.exclude_tags = excludeTags;
  if (includeCollections.length > 0) payload.include_collections = includeCollections;
  if (excludeCollections.length > 0) payload.exclude_collections = excludeCollections;

  fetch("/api/export", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  })
    .then(function (response) {
      if (response.status === 401) {
        throw new Error("Invalid token");
      }
      if (!response.ok) {
        throw new Error("Export failed (HTTP " + response.status + ")");
      }
      return response.blob();
    })
    .then(function (blob) {
      var filename = format === "csv" ? "intercom_articles.csv" : "intercom_articles.txt";

      blob.text().then(function (text) {
        var lines = text.trim().split("\n").filter(function (l) { return l.length > 0; });
        var count = format === "csv" ? Math.max(0, lines.length - 1) : lines.length;

        var resultEl = document.getElementById("result");
        resultEl.textContent = "Exported " + count + " article" + (count !== 1 ? "s" : "") + ". Download started.";
        resultEl.classList.remove("hidden");
      });

      // Trigger download
      var url = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setLoading(false);
    })
    .catch(function (err) {
      setLoading(false);
      showError(err.message || "Export failed.");
    });
}
