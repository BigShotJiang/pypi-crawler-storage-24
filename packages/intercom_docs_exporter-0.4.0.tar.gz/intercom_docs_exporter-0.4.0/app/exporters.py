"""Export formatters for articles: plain-text URL list and CSV."""

import csv
import io
from typing import List, Optional


def _resolve_collection_name(
    article: dict, collections: List[dict]
) -> str:
    """Return the name of the first collection whose id appears in the
    article's ``parent_ids``.  Returns an empty string when no match is
    found.
    """
    parent_ids = article.get("parent_ids") or []
    parent_id_strs = {str(pid) for pid in parent_ids}
    for col in collections:
        if str(col.get("id", "")) in parent_id_strs:
            return col.get("name", "")
    return ""


def export_txt(articles: list) -> str:
    """Return sorted URLs, one per line.

    Only articles that have a truthy ``url`` field are included.
    Returns an empty string for an empty (or fully-filtered) list.
    """
    urls = sorted(a["url"] for a in articles if a.get("url"))
    if not urls:
        return ""
    return "\n".join(urls) + "\n"


def export_csv(articles: list, collections: list) -> str:
    """Return CSV content with header ``url,title,collection,state``.

    * Collection name is resolved via :func:`_resolve_collection_name`.
    * Rows are sorted by URL.
    * Properly escapes commas (and other special characters) in fields
      using Python's :mod:`csv` module.
    * Returns just the header row when the article list is empty.
    """
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["url", "title", "collection", "state"])

    sorted_articles = sorted(articles, key=lambda a: a.get("url", ""))
    for article in sorted_articles:
        collection_name = _resolve_collection_name(article, collections)
        writer.writerow([
            article.get("url", ""),
            article.get("title", ""),
            collection_name,
            article.get("state", ""),
        ])

    return output.getvalue()
