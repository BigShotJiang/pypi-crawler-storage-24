"""Click CLI for exporting Intercom Help Center article URLs."""

import click

from app.intercom import IntercomClient
from app.filters import filter_articles
from app.exporters import export_txt, export_csv


@click.command()
@click.option("--token", required=True, help="Intercom API access token")
@click.option(
    "--format",
    "fmt",
    default="txt",
    type=click.Choice(["txt", "csv"]),
    help="Output format",
)
@click.option(
    "--state",
    default="published",
    type=click.Choice(["published", "draft", "both"]),
)
@click.option(
    "--include-tag",
    multiple=True,
    help="Only include articles with this tag (repeatable)",
)
@click.option(
    "--exclude-tag",
    multiple=True,
    help="Exclude articles with this tag (repeatable)",
)
@click.option(
    "--collection",
    "include_col",
    multiple=True,
    help="Only include this collection (repeatable)",
)
@click.option(
    "--exclude-collection",
    multiple=True,
    help="Exclude this collection (repeatable)",
)
@click.option(
    "--output",
    "-o",
    default=None,
    help="Output file path (default: stdout)",
)
@click.option(
    "--list-collections",
    is_flag=True,
    help="List available collections and exit",
)
def main(
    token,
    fmt,
    state,
    include_tag,
    exclude_tag,
    include_col,
    exclude_collection,
    output,
    list_collections,
):
    """Export Intercom Help Center article URLs."""
    client = IntercomClient(token)

    if list_collections:
        collections = client.fetch_collections()
        for col in collections:
            click.echo(f"{col.get('id')}\t{col.get('name')}")
        return

    articles = client.fetch_articles()
    collections = client.fetch_collections()

    filtered = filter_articles(
        articles,
        state=state,
        include_tags=list(include_tag) or None,
        exclude_tags=list(exclude_tag) or None,
        collections=collections,
        include_collections=list(include_col) or None,
        exclude_collections=list(exclude_collection) or None,
    )

    if fmt == "csv":
        content = export_csv(filtered, collections)
    else:
        content = export_txt(filtered)

    if output:
        with open(output, "w") as f:
            f.write(content)
    else:
        click.echo(content, nl=False)


if __name__ == "__main__":
    main()
