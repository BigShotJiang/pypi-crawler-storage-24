"""Filtering engine for Intercom articles.

Provides ``filter_articles`` which applies a pipeline of filters in this
fixed order:

    state -> URL exists -> tag include -> tag exclude
          -> collection include -> collection exclude
"""

from __future__ import annotations


# ── Internal helpers ──────────────────────────────────────────────────────


def _has_tag(article: dict, tag_name: str) -> bool:
    """Return *True* if *article* carries *tag_name* (case-insensitive).

    Intercom represents tags in several shapes:

    * ``{"type": "tag.list", "tags": [{"name": "Internal"}]}``  (nested dict)
    * ``[{"name": "Internal"}]``  (list of dicts)
    * ``["Internal"]``  (list of strings)
    """
    tags = article.get("tags")
    if tags is None:
        return False

    target = tag_name.lower()

    # Nested dict format: {"type": "tag.list", "tags": [...]}
    if isinstance(tags, dict):
        inner = tags.get("tags", [])
        return any(
            (t.get("name") or "").lower() == target
            for t in inner
            if isinstance(t, dict)
        )

    # List format
    if isinstance(tags, list):
        for item in tags:
            if isinstance(item, dict):
                if (item.get("name") or "").lower() == target:
                    return True
            elif isinstance(item, str):
                if item.lower() == target:
                    return True

    return False


def _collection_name_to_ids(
    collections: list[dict] | None,
    names: list[str],
) -> set[str]:
    """Map a list of human-readable collection *names* to a set of IDs.

    Matching is exact (case-sensitive) against the ``name`` field of each
    collection dict.
    """
    if not collections:
        return set()
    name_set = set(names)
    return {
        str(c["id"])
        for c in collections
        if c.get("name") in name_set
    }


# ── Public API ────────────────────────────────────────────────────────────


def filter_articles(
    articles: list,
    *,
    state: str = "published",
    include_tags: list[str] | None = None,
    exclude_tags: list[str] | None = None,
    collections: list | None = None,
    include_collections: list[str] | None = None,
    exclude_collections: list[str] | None = None,
) -> list[dict]:
    """Filter *articles* through a fixed pipeline.

    Pipeline order:
        1. state (``"published"``, ``"draft"``, or ``"both"``)
        2. URL exists (article must have a truthy ``url`` value)
        3. include_tags – keep only articles that carry at least one tag
        4. exclude_tags – drop articles that carry any of these tags
        5. include_collections – keep only articles in at least one collection
        6. exclude_collections – drop articles in any of these collections
    """
    result = list(articles)

    # 1. State filter
    if state != "both":
        result = [a for a in result if a.get("state") == state]

    # 2. URL exists
    result = [a for a in result if a.get("url")]

    # 3. Tag include
    if include_tags is not None:
        result = [
            a for a in result
            if any(_has_tag(a, t) for t in include_tags)
        ]

    # 4. Tag exclude
    if exclude_tags is not None:
        result = [
            a for a in result
            if not any(_has_tag(a, t) for t in exclude_tags)
        ]

    # 5. Collection include
    if include_collections is not None:
        ids = _collection_name_to_ids(collections, include_collections)
        result = [
            a for a in result
            if ids & {str(pid) for pid in (a.get("parent_ids") or [])}
        ]

    # 6. Collection exclude
    if exclude_collections is not None:
        ids = _collection_name_to_ids(collections, exclude_collections)
        result = [
            a for a in result
            if not (ids & {str(pid) for pid in (a.get("parent_ids") or [])})
        ]

    return result
