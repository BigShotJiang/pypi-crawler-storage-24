import csv
import io

from app.exporters import export_txt, export_csv


class TestExportTxt:
    def test_basic_txt_export(self):
        """Verify sorted output with multiple URLs."""
        articles = [
            {"url": "https://example.com/c-article", "title": "C"},
            {"url": "https://example.com/a-article", "title": "A"},
            {"url": "https://example.com/b-article", "title": "B"},
        ]
        result = export_txt(articles)
        lines = result.strip().split("\n")
        assert lines == [
            "https://example.com/a-article",
            "https://example.com/b-article",
            "https://example.com/c-article",
        ]

    def test_empty_txt_list(self):
        """Empty list returns empty string."""
        assert export_txt([]) == ""

    def test_txt_skips_articles_without_url(self):
        """Articles missing a url field are excluded."""
        articles = [
            {"url": "https://example.com/has-url", "title": "Has URL"},
            {"title": "No URL field"},
            {"url": None, "title": "Null URL"},
            {"url": "", "title": "Empty URL"},
        ]
        result = export_txt(articles)
        lines = result.strip().split("\n")
        assert lines == ["https://example.com/has-url"]


class TestExportCsv:
    def test_basic_csv_export(self):
        """Verify header + data rows with collection resolution."""
        collections = [
            {"id": "col1", "name": "Getting Started"},
            {"id": "col2", "name": "Advanced"},
        ]
        articles = [
            {
                "url": "https://example.com/z-article",
                "title": "Z Article",
                "parent_ids": ["col2"],
                "state": "published",
            },
            {
                "url": "https://example.com/a-article",
                "title": "A Article",
                "parent_ids": ["col1"],
                "state": "draft",
            },
        ]
        result = export_csv(articles, collections)
        reader = csv.reader(io.StringIO(result))
        rows = list(reader)

        # Header
        assert rows[0] == ["url", "title", "collection", "state"]
        # Sorted by URL — a-article first
        assert rows[1] == [
            "https://example.com/a-article",
            "A Article",
            "Getting Started",
            "draft",
        ]
        assert rows[2] == [
            "https://example.com/z-article",
            "Z Article",
            "Advanced",
            "published",
        ]

    def test_empty_csv_list(self):
        """Empty article list returns just the header row."""
        result = export_csv([], [])
        lines = result.strip().split("\n")
        assert len(lines) == 1
        assert lines[0] == "url,title,collection,state"

    def test_csv_escapes_commas_in_title(self):
        """Titles containing commas are properly escaped by csv module."""
        collections = [{"id": "col1", "name": "Docs"}]
        articles = [
            {
                "url": "https://example.com/article",
                "title": "Hello, World",
                "parent_ids": ["col1"],
                "state": "published",
            },
        ]
        result = export_csv(articles, collections)
        reader = csv.reader(io.StringIO(result))
        rows = list(reader)
        assert rows[1][1] == "Hello, World"
        # The raw CSV line should have quoted the title
        csv_lines = result.strip().split("\n")
        assert '"Hello, World"' in csv_lines[1]
