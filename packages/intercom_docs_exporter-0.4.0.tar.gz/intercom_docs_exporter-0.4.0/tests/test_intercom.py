"""Tests for the IntercomClient API client."""

import pytest
from unittest.mock import MagicMock, patch

from app.intercom import IntercomClient, IntercomAPIError


def _mock_response(data, next_url=None, status_code=200):
    """Build a mock requests.Response with Intercom-style pagination."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.raise_for_status = MagicMock()
    payload = {"data": data, "pages": {}}
    if next_url:
        payload["pages"]["next"] = next_url
    resp.json.return_value = payload
    return resp


def _mock_401_response():
    """Build a mock 401 Unauthorized response."""
    resp = MagicMock()
    resp.status_code = 401
    resp.raise_for_status.side_effect = Exception("401 Unauthorized")
    resp.json.return_value = {
        "type": "error.list",
        "errors": [{"code": "unauthorized", "message": "Unauthorized"}],
    }
    return resp


class TestIntercomClient:
    """Tests for IntercomClient."""

    def test_auth_header_is_set(self):
        """Verify that the Bearer token is set correctly in headers."""
        client = IntercomClient(token="test-token-123")
        assert client.headers["Authorization"] == "Bearer test-token-123"
        assert client.headers["Accept"] == "application/json"
        assert client.headers["Content-Type"] == "application/json"

    @patch("app.intercom.requests.get")
    def test_fetch_articles_single_page(self, mock_get):
        """Fetch articles that fit in a single page (no pagination)."""
        articles = [
            {"id": "1", "title": "Getting Started", "state": "published"},
            {"id": "2", "title": "FAQ", "state": "published"},
        ]
        mock_get.return_value = _mock_response(articles)

        client = IntercomClient(token="tok")
        result = client.fetch_articles()

        assert result == articles
        assert mock_get.call_count == 1
        # Verify correct URL was called
        call_args = mock_get.call_args
        assert "articles" in call_args[0][0]

    @patch("app.intercom.requests.get")
    def test_fetch_articles_pagination(self, mock_get):
        """Fetch articles spanning 2 pages via cursor pagination."""
        page1_data = [{"id": "1", "title": "Article A"}]
        page2_data = [{"id": "2", "title": "Article B"}]

        next_url = "https://api.intercom.io/articles?per_page=60&starting_after=cursor1"

        mock_get.side_effect = [
            _mock_response(page1_data, next_url=next_url),
            _mock_response(page2_data),
        ]

        client = IntercomClient(token="tok")
        result = client.fetch_articles()

        assert len(result) == 2
        assert result[0] == page1_data[0]
        assert result[1] == page2_data[0]
        assert mock_get.call_count == 2

        # Second call should use the next_url directly
        second_call_url = mock_get.call_args_list[1][0][0]
        assert second_call_url == next_url

    @patch("app.intercom.requests.get")
    def test_fetch_collections(self, mock_get):
        """Fetch help center collections."""
        collections = [
            {"id": "100", "name": "User Guides"},
            {"id": "101", "name": "API Reference"},
        ]
        mock_get.return_value = _mock_response(collections)

        client = IntercomClient(token="tok")
        result = client.fetch_collections()

        assert result == collections
        assert mock_get.call_count == 1
        call_url = mock_get.call_args[0][0]
        assert "help_center/collections" in call_url

    @patch("app.intercom.requests.get")
    def test_fetch_tags(self, mock_get):
        """Fetch tags (single request, no pagination)."""
        tags = [
            {"id": "10", "name": "Internal"},
            {"id": "11", "name": "Public"},
        ]
        mock_get.return_value = _mock_response(tags)

        client = IntercomClient(token="tok")
        result = client.fetch_tags()

        assert result == tags
        assert mock_get.call_count == 1
        call_url = mock_get.call_args[0][0]
        assert "tags" in call_url

    @patch("app.intercom.requests.get")
    def test_invalid_token_raises(self, mock_get):
        """A 401 response should raise an exception."""
        mock_get.return_value = _mock_401_response()

        client = IntercomClient(token="bad-token")
        with pytest.raises(IntercomAPIError, match="Invalid API token"):
            client.fetch_articles()
