"""Comprehensive tests for the filtering engine."""

import pytest

from app.filters import filter_articles


# ── Test helpers ──────────────────────────────────────────────────────────


def _article(id, title="Test", url="https://ex.com/1", state="published", tags=None, parent_ids=None):
    a = {"id": id, "title": title, "url": url, "state": state}
    if tags is not None:
        a["tags"] = tags
    if parent_ids is not None:
        a["parent_ids"] = parent_ids
    return a


def _tag_list(*names):
    return {"type": "tag.list", "tags": [{"name": n} for n in names]}


# ── Collections fixture ──────────────────────────────────────────────────

COLLECTIONS = [
    {"id": "c1", "name": "Getting Started"},
    {"id": "c2", "name": "Advanced"},
    {"id": "c3", "name": "Internal Docs"},
]


# ── Tests ─────────────────────────────────────────────────────────────────


def test_filter_published_only():
    articles = [
        _article(1, state="published"),
        _article(2, state="draft"),
        _article(3, state="published"),
    ]
    result = filter_articles(articles, state="published")
    assert [a["id"] for a in result] == [1, 3]


def test_filter_draft_only():
    articles = [
        _article(1, state="published"),
        _article(2, state="draft"),
        _article(3, state="draft"),
    ]
    result = filter_articles(articles, state="draft")
    assert [a["id"] for a in result] == [2, 3]


def test_filter_both_states():
    articles = [
        _article(1, state="published"),
        _article(2, state="draft"),
        _article(3, state="published"),
    ]
    result = filter_articles(articles, state="both")
    assert [a["id"] for a in result] == [1, 2, 3]


def test_include_tags():
    articles = [
        _article(1, tags=_tag_list("Public")),
        _article(2, tags=_tag_list("Internal")),
        _article(3, tags=_tag_list("Public", "Featured")),
        _article(4),  # no tags
    ]
    result = filter_articles(articles, include_tags=["Public"])
    assert [a["id"] for a in result] == [1, 3]


def test_exclude_tags():
    articles = [
        _article(1, tags=_tag_list("Public")),
        _article(2, tags=_tag_list("Internal")),
        _article(3, tags=_tag_list("Public", "Internal")),
        _article(4),  # no tags
    ]
    result = filter_articles(articles, exclude_tags=["Internal"])
    assert [a["id"] for a in result] == [1, 4]


def test_include_collections():
    articles = [
        _article(1, parent_ids=["c1"]),
        _article(2, parent_ids=["c2"]),
        _article(3, parent_ids=["c1", "c3"]),
        _article(4),  # no parent_ids
    ]
    result = filter_articles(
        articles,
        collections=COLLECTIONS,
        include_collections=["Getting Started"],
    )
    assert [a["id"] for a in result] == [1, 3]


def test_exclude_collections():
    articles = [
        _article(1, parent_ids=["c1"]),
        _article(2, parent_ids=["c2"]),
        _article(3, parent_ids=["c1", "c3"]),
        _article(4),  # no parent_ids
    ]
    result = filter_articles(
        articles,
        collections=COLLECTIONS,
        exclude_collections=["Internal Docs"],
    )
    assert [a["id"] for a in result] == [1, 2, 4]


def test_removes_articles_without_url():
    articles = [
        _article(1, url="https://ex.com/1"),
        _article(2, url=None),
        _article(3, url=""),
        _article(4, url="https://ex.com/4"),
    ]
    result = filter_articles(articles, state="published")
    assert [a["id"] for a in result] == [1, 4]


def test_tag_matching_case_insensitive():
    # tag.list format (nested dict)
    articles_dict = [
        _article(1, tags=_tag_list("Internal")),
        _article(2, tags=_tag_list("public")),
    ]
    result = filter_articles(articles_dict, include_tags=["internal"])
    assert [a["id"] for a in result] == [1]

    result = filter_articles(articles_dict, include_tags=["PUBLIC"])
    assert [a["id"] for a in result] == [2]

    # list of dicts format
    articles_list_dicts = [
        _article(1, tags=[{"name": "Internal"}]),
        _article(2, tags=[{"name": "public"}]),
    ]
    result = filter_articles(articles_list_dicts, include_tags=["INTERNAL"])
    assert [a["id"] for a in result] == [1]

    # list of strings format
    articles_list_str = [
        _article(1, tags=["Internal"]),
        _article(2, tags=["public"]),
    ]
    result = filter_articles(articles_list_str, include_tags=["internal"])
    assert [a["id"] for a in result] == [1]


def test_include_collections_with_integer_parent_ids():
    """Intercom API returns parent_ids as integers, collection IDs as strings."""
    collections = [
        {"id": "14685179", "name": "Analytics"},
        {"id": "13367187", "name": "Replenishment"},
    ]
    articles = [
        _article(1, parent_ids=[14685179]),
        _article(2, parent_ids=[13367187]),
        _article(3, parent_ids=[99999]),
    ]
    result = filter_articles(
        articles,
        collections=collections,
        include_collections=["Analytics"],
    )
    assert [a["id"] for a in result] == [1]


def test_combined_filters():
    """State → URL exists → tag include → tag exclude → collection include → collection exclude."""
    articles = [
        _article(1, state="published", url="https://ex.com/1", tags=_tag_list("Public"), parent_ids=["c1"]),
        _article(2, state="draft", url="https://ex.com/2", tags=_tag_list("Public"), parent_ids=["c1"]),
        _article(3, state="published", url=None, tags=_tag_list("Public"), parent_ids=["c1"]),
        _article(4, state="published", url="https://ex.com/4", tags=_tag_list("Internal"), parent_ids=["c1"]),
        _article(5, state="published", url="https://ex.com/5", tags=_tag_list("Public"), parent_ids=["c3"]),
        _article(6, state="published", url="https://ex.com/6", tags=_tag_list("Public", "Deprecated"), parent_ids=["c1"]),
    ]
    result = filter_articles(
        articles,
        state="published",
        include_tags=["Public"],
        exclude_tags=["Deprecated"],
        collections=COLLECTIONS,
        include_collections=["Getting Started"],
        exclude_collections=["Internal Docs"],
    )
    # 1: published, has url, has "Public", no "Deprecated", in c1 (Getting Started), not in c3 -> PASS
    # 2: draft -> filtered by state
    # 3: no url -> filtered by url
    # 4: no "Public" tag -> filtered by include_tags
    # 5: in c3 (Internal Docs) -> filtered by exclude_collections
    # 6: has "Deprecated" -> filtered by exclude_tags
    assert [a["id"] for a in result] == [1]
