"""Tests for FastAPI endpoints."""

from unittest.mock import patch, MagicMock

import pytest
from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


# ── Mock data helpers ────────────────────────────────────────────────────


def _mock_client_articles():
    return [
        {
            "id": "1",
            "title": "Art 1",
            "url": "https://ex.com/1",
            "state": "published",
            "tags": {"type": "tag.list", "tags": [{"name": "Internal"}]},
            "parent_ids": ["c1"],
        },
        {
            "id": "2",
            "title": "Art 2",
            "url": "https://ex.com/2",
            "state": "published",
            "tags": {"type": "tag.list", "tags": []},
            "parent_ids": ["c1"],
        },
        {
            "id": "3",
            "title": "Art 3",
            "url": "https://ex.com/3",
            "state": "draft",
            "tags": {"type": "tag.list", "tags": []},
            "parent_ids": [],
        },
    ]


def _mock_collections():
    return [
        {"id": "c1", "name": "Getting Started"},
        {"id": "c2", "name": "Advanced"},
    ]


def _mock_tags():
    return [
        {"id": "t1", "name": "Internal"},
        {"id": "t2", "name": "Public"},
    ]


def _make_mock_client():
    """Return a mock IntercomClient whose fetch methods return canned data."""
    instance = MagicMock()
    instance.fetch_articles.return_value = _mock_client_articles()
    instance.fetch_collections.return_value = _mock_collections()
    instance.fetch_tags.return_value = _mock_tags()
    return instance


# ── Tests ────────────────────────────────────────────────────────────────


@patch("app.main.IntercomClient")
def test_export_txt(MockClient):
    instance = _make_mock_client()
    MockClient.return_value = instance

    resp = client.post("/api/export", json={"token": "tok", "format": "txt"})

    assert resp.status_code == 200
    assert resp.headers["content-type"] == "text/plain; charset=utf-8"
    assert "content-disposition" in resp.headers
    body = resp.text
    # Only published articles with URLs should appear (Art 1 and Art 2)
    assert "https://ex.com/1" in body
    assert "https://ex.com/2" in body
    # Draft article should NOT appear
    assert "https://ex.com/3" not in body


@patch("app.main.IntercomClient")
def test_export_csv(MockClient):
    instance = _make_mock_client()
    MockClient.return_value = instance

    resp = client.post("/api/export", json={"token": "tok", "format": "csv"})

    assert resp.status_code == 200
    assert resp.headers["content-type"] == "text/csv; charset=utf-8"
    assert "content-disposition" in resp.headers
    body = resp.text
    assert "url,title,collection,state" in body
    assert "https://ex.com/1" in body
    assert "https://ex.com/2" in body


@patch("app.main.IntercomClient")
def test_export_with_tag_filter(MockClient):
    instance = _make_mock_client()
    MockClient.return_value = instance

    resp = client.post(
        "/api/export",
        json={"token": "tok", "format": "txt", "exclude_tags": ["Internal"]},
    )

    assert resp.status_code == 200
    body = resp.text
    # Art 1 has "Internal" tag, should be excluded
    assert "https://ex.com/1" not in body
    # Art 2 has no tags, should remain
    assert "https://ex.com/2" in body


def test_export_missing_token():
    resp = client.post("/api/export", json={"format": "txt"})
    assert resp.status_code == 422


@patch("app.main.IntercomClient")
def test_list_collections(MockClient):
    instance = _make_mock_client()
    MockClient.return_value = instance

    resp = client.post("/api/collections", json={"token": "tok"})

    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 2
    assert data[0] == {"id": "c1", "name": "Getting Started"}
    assert data[1] == {"id": "c2", "name": "Advanced"}


@patch("app.main.IntercomClient")
def test_list_tags(MockClient):
    instance = _make_mock_client()
    MockClient.return_value = instance

    resp = client.post("/api/tags", json={"token": "tok"})

    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 2
    assert data[0] == {"id": "t1", "name": "Internal"}
    assert data[1] == {"id": "t2", "name": "Public"}


def test_root_returns_html():
    resp = client.get("/")
    assert resp.status_code == 200
    assert "text/html" in resp.headers["content-type"]
    assert "<html" in resp.text.lower()
