"""Tests for the click CLI."""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli import main


# ── Helpers ──────────────────────────────────────────────────────────────

SAMPLE_ARTICLES = [
    {
        "id": "1",
        "title": "Getting Started",
        "url": "https://help.example.com/getting-started",
        "state": "published",
        "parent_ids": ["col1"],
    },
    {
        "id": "2",
        "title": "Advanced Usage",
        "url": "https://help.example.com/advanced-usage",
        "state": "published",
        "parent_ids": ["col2"],
    },
]

SAMPLE_COLLECTIONS = [
    {"id": "col1", "name": "Basics"},
    {"id": "col2", "name": "Advanced"},
]


def _mock_client_instance():
    """Return a mock IntercomClient whose fetch methods return sample data."""
    instance = MagicMock()
    instance.fetch_articles.return_value = SAMPLE_ARTICLES
    instance.fetch_collections.return_value = SAMPLE_COLLECTIONS
    return instance


# ── Tests ────────────────────────────────────────────────────────────────


@patch("cli.IntercomClient")
def test_basic_txt_export(MockClient, tmp_path):
    """TXT export writes sorted URLs to the output file."""
    MockClient.return_value = _mock_client_instance()

    outfile = tmp_path / "output.txt"
    runner = CliRunner()
    result = runner.invoke(main, ["--token", "fake-token", "--output", str(outfile)])

    assert result.exit_code == 0, result.output
    content = outfile.read_text()
    lines = content.strip().split("\n")
    assert "https://help.example.com/advanced-usage" in lines
    assert "https://help.example.com/getting-started" in lines
    # URLs should be sorted
    assert lines == sorted(lines)


@patch("cli.IntercomClient")
def test_csv_format(MockClient):
    """CSV export prints header + data rows to stdout."""
    MockClient.return_value = _mock_client_instance()

    runner = CliRunner()
    result = runner.invoke(main, ["--token", "fake-token", "--format", "csv"])

    assert result.exit_code == 0, result.output
    lines = result.output.strip().split("\n")
    assert lines[0] == "url,title,collection,state"
    assert len(lines) == 3  # header + 2 articles


@patch("cli.IntercomClient")
def test_list_collections(MockClient):
    """--list-collections prints collection names and exits."""
    MockClient.return_value = _mock_client_instance()

    runner = CliRunner()
    result = runner.invoke(main, ["--token", "fake-token", "--list-collections"])

    assert result.exit_code == 0, result.output
    assert "Basics" in result.output
    assert "Advanced" in result.output
