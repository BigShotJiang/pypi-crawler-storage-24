"""Compare f1 profiles across H4i variants to calibrate bond zone decay.

Overlays normalised profiles (d_bar/s_m vs f1/f1_bar) from:
  - H4i:      375x750, db=11, centroidal bar
  - H4i-deep: 375x1500, db=11, centroidal bar
  - H4i-bigbar: 375x750, db=25, centroidal bar
  - H4i-sym:  375x750, db=11, two symmetric bars

If profiles collapse when normalised by s_m_bar, the bond zone is
controlled by crack spacing. If bigbar shifts, db matters independently.
"""
import json
import math
import sys
sys.path.insert(0, "src")


def load_profile(json_path, stage_idx=0):
    """Load f1 and e1 profiles at a given stage (first trace only)."""
    with open(json_path) as f:
        d = json.load(f)

    stage = d["stages"][stage_idx]

    # f1 profile (first trace of dual-trace)
    for p in stage["profiles"]:
        if p["title"] == "Principal Tensile Stress":
            n = len(p["y"]) // 2
            y_min = min(p["y"][:n])
            f1_pts = [(yi - y_min, xi) for yi, xi in zip(p["y"][:n], p["x"][:n])]
            break
    else:
        return None, None, None

    # e1 (uniform for axial)
    for p in stage["profiles"]:
        if p["title"] == "Principal Tensile Strain":
            e1 = p["x"][0] * 1e-3  # mm/m -> absolute
            break
    else:
        e1 = None

    return f1_pts, e1, stage.get("stage", stage_idx)


def analyse_variant(label, json_path, z_bar, s_m_bar, stage_idx=0):
    """Print normalised bond zone profile for one variant."""
    f1_pts, e1, ctrl_idx = load_profile(json_path, stage_idx)
    if f1_pts is None:
        print(f"  {label}: no data")
        return []

    # Find f1 at bar
    f1_bar = max(f1 for z, f1 in f1_pts if abs(z - z_bar) < 15)

    results = []
    for z, f1 in f1_pts:
        d_bar = abs(z - z_bar)
        if z > z_bar:
            continue  # bottom half only (symmetric)
        if f1 < 0.01:
            continue
        xi = d_bar / s_m_bar
        results.append((d_bar, xi, f1, f1 / f1_bar))

    print(f"\n{label} (z_bar={z_bar}, s_m={s_m_bar:.0f}mm, e1={e1*1000:.2f}mm/m, f1_bar={f1_bar:.4f}):")
    print(f"  {'d_bar':>6} {'d/s_m':>6} {'f1':>8} {'f1/f1b':>7}")
    for d_bar, xi, f1, f1_norm in results:
        print(f"  {d_bar:6.0f} {xi:6.3f} {f1:8.4f} {f1_norm:7.3f}")

    return results


def main():
    from mcft.io import read_rsp
    from mcft.section import build_layers, crack_spacing_x, build_outline

    variants = [
        ("H4i",      "results/synth/synth_H4i_r2k.json",      "tools/synth_H4i.rsp",      375.0),
        ("Deep",     "results/synth/synth_H4i_deep_r2k.json",  "tools/synth_H4i_deep.rsp",  750.0),
        ("Bigbar",   "results/synth/synth_H4i_bigbar_r2k.json","tools/synth_H4i_bigbar.rsp",375.0),
        ("Sym",      "results/synth/synth_H4i_sym_r2k.json",   "tools/synth_H4i_sym.rsp",   187.5),
    ]

    all_results = {}
    for label, json_path, rsp_path, z_bar in variants:
        try:
            model = read_rsp(rsp_path)
            beam = model.sections[0]
            outline = build_outline(beam)
            h = outline.height
            s_m = crack_spacing_x(z_bar, beam.long_reinf, outline, h)
            results = analyse_variant(label, json_path, z_bar, s_m)
            all_results[label] = results
        except FileNotFoundError:
            print(f"\n{label}: JSON not found (not yet extracted)")

    # Overlay comparison
    if len(all_results) >= 2:
        print(f"\n{'='*60}")
        print("Normalised overlay (d/s_m vs f1/f1_bar):")
        print(f"{'d/s_m':>6}", end="")
        for label in all_results:
            print(f" {label:>8}", end="")
        print()

        # Sample at common d/s_m values
        for xi_target in [0.0, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30,
                          0.35, 0.40, 0.45, 0.50, 0.55, 0.60]:
            print(f"{xi_target:6.2f}", end="")
            for label, results in all_results.items():
                # Find closest point
                if results:
                    closest = min(results, key=lambda r: abs(r[1] - xi_target))
                    if abs(closest[1] - xi_target) < 0.03:
                        print(f" {closest[3]:8.3f}", end="")
                    else:
                        print(f" {'---':>8}", end="")
                else:
                    print(f" {'---':>8}", end="")
            print()


if __name__ == "__main__":
    main()
