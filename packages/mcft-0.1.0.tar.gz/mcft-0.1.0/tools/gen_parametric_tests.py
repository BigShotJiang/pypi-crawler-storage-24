"""Generate parametric H-series variants for formula verification.

Each variant changes ONE parameter from the H4i baseline to test whether
R2K responds as our formulas predict. The prediction is documented in the
output so we can check it against extraction results.

Baseline H4i: 375×750mm, 4 bars db=11mm, A=2000mm², centroidal (z=375),
fcp=36MPa, pure axial, material 4 (Popovics, no softening, TS on).

Run from project root:
    python tools/gen_parametric_tests.py
"""
import math
from pathlib import Path

OUT = Path(__file__).parent

# ============================================================================
# Baseline parameters
# ============================================================================
BASELINE = {
    "width": 375.0,
    "depth": 750.0,
    "z_bar": 375.0,
    "num": 4,
    "A": 2000.0,
    "db": 11.0,
    "fcp": 36.0,
}


def _crack_spacing(z_bar, width, depth, num, A, db):
    """Predict s_m at the bar using CEB formula."""
    half_w = width / 2.0
    c = math.sqrt(half_w**2)  # diagonal distance to nearest face (side)
    # ρ within 7.5·db zone
    zone_half = 7.5 * db
    zone_h = min(2 * zone_half, depth)
    zone_area = width * zone_h
    rho = A / zone_area if zone_area > 0 else 0
    if rho <= 0:
        return 5 * depth
    return 2 * c + 0.1 * db / rho


def _bond_param(width, depth, num, A, db, zone_depth=143.0):
    """Predict m at the bar."""
    sum_pi_db = num * math.pi * db
    Ac = width * min(2 * zone_depth, depth)
    return Ac / sum_pi_db if sum_pi_db > 0 else 0


def _predict(params):
    """Compute predicted s_m, m, bond zone extent."""
    s_m = _crack_spacing(params["z_bar"], params["width"], params["depth"],
                         params["num"], params["A"], params["db"])
    m = _bond_param(params["width"], params["depth"], params["num"],
                    params["A"], params["db"])
    bz = 0.625 * s_m
    ft = 0.45 * math.sqrt(params["fcp"])
    return s_m, m, bz, ft


def _build_rsp(name, params, comment=""):
    """Build an .rsp file for an H-series parametric variant."""
    w = params["width"]
    d = params["depth"]
    z = params["z_bar"]
    fcp = params["fcp"]

    return f"""<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<!DOCTYPE suite_3g SYSTEM "r3g.dtd">
<!-- {comment} -->

<document>
\t<r3g_beam\tname\t\t="{name}"
\t\t\tdoneby\t="mcft-test"
\t\t\tdate\t\t="2026/3/22"\t>
\t\t<concrete\tfcp\t\t="{fcp:.1f}"
\t\t\t\tmaxagg\t="20.0"
\t\t\t\tc_soft\t="1"
\t\t\t\ttsfactor\t="1.0"
\t\t\t\tname\t\t="Concrete"\t/>
\t\t<rebar\t\tfy\t\t="10000.0"
\t\t\t\tfu\t\t="12000.0"
\t\t\t\tesh\t\t="50.0"
\t\t\t\teu\t\t="100.0"
\t\t\t\tname\t\t="Long"\t/>
\t\t<prestress\tfu\t\t="1860.0"\t/>
\t\t<sectionSOLID\t\t>
\t\t\t\t\t{d:.1f}\t{w:.1f}
\t\t\t\t\t0.0\t{w:.1f}\t"Concrete"
\t\t\t</sectionSOLID>
\t\t<shapesection\tname\t\t="RECT"
\t\t\t\tpar1\t\t="{w:.1f}"
\t\t\t\tpar2\t\t="{d:.1f}"\t/>
\t\t<longreinfx\tz\t\t="{z:.2f}"
\t\t\t\ttype\t\t="Long"
\t\t\t\tnum\t\t="{params['num']}"
\t\t\t\tA\t\t="{params['A']:.1f}"
\t\t\t\tdb\t\t="{params['db']:.1f}"
\t\t\t\tname\t\t="mid"\t/>
\t\t<sectloading\tMN\t\t="1.000"
\t\t\t\tMM\t\t="0.000"\t/>

\t</r3g_beam>
</document>
"""


# ============================================================================
# Parametric variants
# ============================================================================
VARIANTS = [
    # (filename_suffix, parameter_overrides, description)

    # --- Crack spacing sensitivity (s_m = 2c + 0.1·db/ρ) ---
    ("2bar", {"num": 2, "db": 15.7},
     "2 bars db=15.7 (same A=2000): changes Σ(πdb) and bar spacing"),

    ("8bar", {"num": 8, "db": 7.8},
     "8 bars db=7.8 (same A=2000): denser bars, smaller c between bars"),

    ("narrow", {"width": 200.0},
     "Narrow section (200mm): smaller c to side → smaller s_m"),

    ("wide", {"width": 600.0},
     "Wide section (600mm): larger c to side → larger s_m"),

    # --- Bar position (asymmetric bond zone) ---
    ("offcentre", {"z_bar": 100.0},
     "Bar at z=100 (near bottom): asymmetric, bond zone truncated at face?"),

    ("offcentre_high", {"z_bar": 600.0},
     "Bar at z=600 (near top): same as offcentre, opposite side"),

    # --- Concrete strength (ft, Ec, e_cr) ---
    ("lowfc", {"fcp": 20.0},
     "Low strength (fcp=20): lower ft, lower Ec, larger e_cr"),

    ("highfc", {"fcp": 60.0},
     "High strength (fcp=60): higher ft, higher Ec, smaller e_cr"),

    # --- Bar area (reinforcement ratio) ---
    ("lowrho", {"A": 500.0},
     "Low reo (A=500, ρ≈0.18%): larger s_m, wider bond zone"),

    ("highrho", {"A": 4000.0},
     "High reo (A=4000, ρ≈1.4%): smaller s_m, narrower bond zone"),

    # --- Bar diameter at same ρ (isolates db from ρ) ---
    ("bigdb_samerho", {"num": 2, "db": 25.2, "A": 2000.0},
     "2 bars db=25.2 (same A): larger db, same ρ, tests db/ρ ratio in s_m"),
]

# B-series parametric variants (bar position in bending)
B_VARIANTS = [
    ("deepbar", {"z_bar": 100.0},
     "Bar at z=100 (deeper cover): larger s_m, wider bond zone, more TS moment"),

    ("shallbar", {"z_bar": 40.0},
     "Bar at z=40 (shallow cover): smaller s_m, narrower bond zone"),
]


def main():
    generated = []

    print("=" * 70)
    print("H-SERIES PARAMETRIC VARIANTS")
    print("=" * 70)

    # Baseline predictions
    s_m0, m0, bz0, ft0 = _predict(BASELINE)
    print(f"\nBaseline H4i: s_m={s_m0:.0f}mm, m={m0:.0f}, "
          f"bond_zone={bz0:.0f}mm, ft={ft0:.3f}MPa")

    for suffix, overrides, desc in VARIANTS:
        params = {**BASELINE, **overrides}
        s_m, m, bz, ft = _predict(params)
        name = f"Synth H4i-{suffix}"
        fname = f"synth_H4i_{suffix}.rsp"
        comment = f"{desc}\nPrediction: s_m={s_m:.0f}mm (was {s_m0:.0f}), " \
                  f"m={m:.0f} (was {m0:.0f}), bond_zone={bz:.0f}mm (was {bz0:.0f})"

        content = _build_rsp(name, params, comment)
        path = OUT / fname
        path.write_text(content)
        generated.append(fname)

        ratio_sm = s_m / s_m0
        ratio_bz = bz / bz0
        print(f"\n  {fname}:")
        print(f"    {desc}")
        print(f"    s_m={s_m:.0f}mm ({ratio_sm:.2f}×), "
              f"bond_zone={bz:.0f}mm ({ratio_bz:.2f}×), m={m:.0f}")

    print(f"\n{'=' * 70}")
    print("B-SERIES PARAMETRIC VARIANTS")
    print("=" * 70)

    b_base = {**BASELINE, "z_bar": 65.0, "depth": 750.0}
    s_m_b, m_b, bz_b, ft_b = _predict(b_base)
    print(f"\nBaseline B4i: bar at z=65, s_m={s_m_b:.0f}mm, bond_zone={bz_b:.0f}mm")

    for suffix, overrides, desc in B_VARIANTS:
        params = {**b_base, **overrides}
        s_m, m, bz, ft = _predict(params)
        name = f"Synth B4i-{suffix}"
        fname = f"synth_B4i_{suffix}.rsp"

        # B-series uses pure bending, not axial
        content = _build_rsp(name, params,
                             f"{desc}\ns_m={s_m:.0f}mm, bond_zone={bz:.0f}mm")
        # Override loading to pure bending
        content = content.replace('MN\t\t="1.000"', 'MM\t\t="1.000"')
        content = content.replace('MM\t\t="0.000"', 'MV\t\t="0.000"')

        path = OUT / fname
        path.write_text(content)
        generated.append(fname)

        print(f"\n  {fname}:")
        print(f"    {desc}")
        print(f"    s_m={s_m:.0f}mm, bond_zone={bz:.0f}mm")

    print(f"\n{'=' * 70}")
    print(f"Generated {len(generated)} parametric test files.")
    for f in generated:
        print(f"  {f}")


if __name__ == "__main__":
    main()
