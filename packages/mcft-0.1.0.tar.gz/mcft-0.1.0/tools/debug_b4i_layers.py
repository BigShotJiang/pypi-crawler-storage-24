"""Layer-by-layer comparison of our solver vs R2K for B4i cracking transition.

R2K profiles for 'Principal Tensile Stress' and 'Principal Compressive Stress'
have DUAL traces (actual + capacity). We need only the first half (actual values).
"""
import json
import sys
sys.path.insert(0, "src")

from mcft.io import read_rsp
from mcft.r2k_validation import load_r2k_stages
from mcft.solver import analyse_section_staged, SolverConfig
from mcft.section import build_layers

# Profiles known to have dual traces (2x points)
DUAL_TRACE_PROFILES = {"Principal Tensile Stress", "Principal Compressive Stress"}
# Profiles with triple traces (3x points)
TRIPLE_TRACE_PROFILES = {"Shear Strain", "Transverse Strain"}

# Load
model = read_rsp("tools/synth_B4i.rsp")
beam = model.sections[0]
stages = load_r2k_stages("results/synth/synth_B4i_r2k.json")

with open("results/synth/synth_B4i_r2k.json") as f:
    raw = json.load(f)

# Run staged analysis
config = SolverConfig()
result = analyse_section_staged(beam, stages, config)


def get_r2k_profile_as_z(stage_idx, title):
    """Get R2K profile as {z_from_bottom: value} dict (first trace only)."""
    stage_data = raw["stages"][stage_idx]
    for p in stage_data["profiles"]:
        if p["title"] == title:
            y_vals = p["y"]
            x_vals = p["x"]
            n = len(y_vals)

            # Take first trace only for dual/triple-trace profiles
            if title in DUAL_TRACE_PROFILES:
                n = n // 2
            elif title in TRIPLE_TRACE_PROFILES:
                n = n // 3

            y_min = min(y_vals[:n])
            result = {}
            for i in range(n):
                z = round(y_vals[i] - y_min, 2)
                result[z] = x_vals[i]
            return result
    return {}


# Overview table
print("=" * 90)
print(f"{'Stage':>5} {'phi mrad/m':>10} {'M_r2k kNm':>10} {'M_ours kNm':>11} {'ratio':>7}")
print("=" * 90)
for i, (stg, step) in enumerate(zip(stages, result.steps)):
    if i > 30:
        break
    M_r2k = stg.M_r2k / 1e6
    M_ours = step.M / 1e6
    ratio = M_ours / M_r2k if abs(M_r2k) > 1 else float("nan")
    phi_mrad = stg.phi * 1e6
    tag = " <<<" if abs(ratio) < 0.9 and abs(M_r2k) > 1 else ""
    print(f"{i:5d} {phi_mrad:10.3f} {M_r2k:10.2f} {M_ours:11.2f} {ratio:7.3f}{tag}")

# Detailed layer-by-layer at key stages
for stage_idx in [13, 15, 20]:
    if stage_idx >= len(stages):
        continue
    stg = stages[stage_idx]
    step = result.steps[stage_idx]
    phi_mrad = stg.phi * 1e6

    ratio = step.M / stg.M_r2k if abs(stg.M_r2k) > 1 else float("nan")
    print(f"\n{'=' * 120}")
    print(f"STAGE {stage_idx}: phi = {phi_mrad:.3f} mrad/m, "
          f"M_r2k = {stg.M_r2k/1e6:.2f} kNm, M_ours = {step.M/1e6:.2f} kNm, "
          f"ratio = {ratio:.3f}")
    print(f"{'=' * 120}")

    # R2K profiles (first trace only)
    r2k_f1 = get_r2k_profile_as_z(stage_idx, "Principal Tensile Stress")
    r2k_ex = get_r2k_profile_as_z(stage_idx, "Longitudinal Strain")
    r2k_e1 = get_r2k_profile_as_z(stage_idx, "Principal Tensile Strain")

    # Rebuild layers to get rho_x
    outline, layers = build_layers(beam, node_depths=stg.layer_depths, nodal=False)

    print(f"  R2K profile points: {len(r2k_f1)}, Our layers: {len(step.layer_states)}")
    print(f"{'idx':>4} {'z_mid':>7} {'rho_x':>8} "
          f"{'ex_r2k':>8} {'ex_ours':>8} "
          f"{'e1_r2k':>8} {'e1_ours':>8} "
          f"{'f1_r2k':>8} {'f1_ours':>8} {'df1':>8}")
    print("-" * 120)

    for j, (lay, st) in enumerate(zip(layers, step.layer_states)):
        z_mid = lay.z_mid
        z_key = round(z_mid, 2)

        # Find nearest R2K z
        if r2k_f1:
            nearest_z = min(r2k_f1.keys(), key=lambda zr: abs(zr - z_key))
            if abs(nearest_z - z_key) < 5.0:
                f1_r = r2k_f1[nearest_z]
                ex_r = r2k_ex.get(nearest_z, float("nan"))
                e1_r = r2k_e1.get(nearest_z, float("nan"))
            else:
                f1_r = ex_r = e1_r = float("nan")
        else:
            f1_r = ex_r = e1_r = float("nan")

        rho = lay.node_mat.rho_x if lay.node_mat else 0.0
        ex_o = st.ex * 1000  # mm/m
        e1_o = st.e1 * 1000
        f1_o = st.f1

        df1 = f1_o - f1_r if (f1_r == f1_r and f1_o == f1_o) else float("nan")
        marker = ""
        if df1 == df1:
            if abs(df1) > 0.5:
                marker = " ***"
            elif abs(df1) > 0.2:
                marker = " **"
            elif abs(df1) > 0.1:
                marker = " *"
        print(f"{j:4d} {z_mid:7.1f} {rho:8.5f} "
              f"{ex_r:8.4f} {ex_o:8.4f} "
              f"{e1_r:8.4f} {e1_o:8.4f} "
              f"{f1_r:8.4f} {f1_o:8.4f} {df1:8.4f}{marker}")
