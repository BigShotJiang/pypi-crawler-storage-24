"""Generate synthetic .rsp test files for the MCFT validation matrix.

Section/Loading axis (A-G) × Material axis (1-6) × Steel sub-axis (i-iii).

Run from project root:
    python tools/gen_synth_tests.py
"""

from pathlib import Path

OUT = Path(__file__).parent

# ---------------------------------------------------------------------------
# Section definitions
# ---------------------------------------------------------------------------
# Each section is a dict with:
#   name_prefix: str (e.g. "A")
#   section_name: str (human label)
#   section_xml: str (sectionSOLID block)
#   long_reinf: str (longreinfx elements, empty string if none)
#   trans_reinf: str (transreinfz elements, empty string if none)
#   loading: dict with MM, MV

SECTIONS = {
    "A": {
        "label": "Unreinf Rect 375x750",
        # 750mm high, 375mm wide rectangle
        "section_xml": """\t\t<sectionSOLID\t\t>
\t\t\t\t\t750.0\t375.0
\t\t\t\t\t0.0\t375.0\t"Concrete"
\t\t\t</sectionSOLID>""",
        "long_reinf": "",
        "trans_reinf": "",
        "loading_pure_bending": {"MM": "1.0", "MV": "0.0"},
        "loading_shear": None,   # no shear for unreinforced
        "loading_high_shear": None,
    },
    "B": {
        "label": "SingReinf 375x750 bot",
        "section_xml": """\t\t<sectionSOLID\t\t>
\t\t\t\t\t750.0\t375.0
\t\t\t\t\t0.0\t375.0\t"Concrete"
\t\t\t</sectionSOLID>""",
        "long_reinf": """\t\t<longreinfx\tz\t\t="65.00"
\t\t\t\ttype\t\t="Long"
\t\t\t\tnum\t\t="4"
\t\t\t\tA\t\t="2000.0"
\t\t\t\tname\t\t="bot"  />""",
        "trans_reinf": "",
        "loading_pure_bending": {"MM": "1.0", "MV": "0.0"},
        "loading_shear": None,
        "loading_high_shear": None,
    },
    "C": {
        "label": "DoubReinf 375x750",
        "section_xml": """\t\t<sectionSOLID\t\t>
\t\t\t\t\t750.0\t375.0
\t\t\t\t\t0.0\t375.0\t"Concrete"
\t\t\t</sectionSOLID>""",
        "long_reinf": """\t\t<longreinfx\tz\t\t="65.00"
\t\t\t\ttype\t\t="Long"
\t\t\t\tnum\t\t="4"
\t\t\t\tA\t\t="2000.0"
\t\t\t\tname\t\t="bot"  />
\t\t<longreinfx\tz\t\t="685.00"
\t\t\t\ttype\t\t="Long"
\t\t\t\tnum\t\t="2"
\t\t\t\tA\t\t="400.0"
\t\t\t\tname\t\t="top"  />""",
        "trans_reinf": "",
        "loading_pure_bending": {"MM": "1.0", "MV": "0.0"},
        "loading_shear": None,
        "loading_high_shear": None,
    },
    "D": {
        "label": "SingReinf+Stir 375x750",
        "section_xml": """\t\t<sectionSOLID\t\t>
\t\t\t\t\t750.0\t375.0
\t\t\t\t\t0.0\t375.0\t"Concrete"
\t\t\t</sectionSOLID>""",
        "long_reinf": """\t\t<longreinfx\tz\t\t="65.00"
\t\t\t\ttype\t\t="Long"
\t\t\t\tnum\t\t="4"
\t\t\t\tA\t\t="2000.0"
\t\t\t\tname\t\t="bot"  />""",
        "trans_reinf": """\t\t<transreinfz\tA\t\t="100.0"
\t\t\t\ttype\t\t="Trans"
\t\t\t\tpattern\t="2"
\t\t\t\tspace\t\t="200.0"
\t\t\t\tdisttop\t="714.0"
\t\t\t\tdistbot\t="44.0"
\t\t\t\tAi\t\t="50.0"
\t\t\t\tdb\t\t="10.0"
\t\t\t\tname\t\t="stirr" />""",
        "loading_pure_bending": {"MM": "1.0", "MV": "0.0"},
        "loading_low_shear": {"MM": "10.0", "MV": "1.0"},   # av=10000mm
        "loading_med_shear": {"MM": "5.0", "MV": "1.0"},    # av=5000mm
        "loading_shear": {"MM": "1.5", "MV": "1.0"},        # av=1500mm
        "loading_high_shear": {"MM": "0.5", "MV": "1.0"},   # av=500mm
    },
    # H - centroidal bar, pure axial (bond zone calibration)
    # NOTE: H-series .rsp files require manual R2K setup (member length,
    # supports, MN loading) before extraction. See docs/synthetic-test-design.md.
    "H": {
        "label": "CentRebar 375x750 axial",
        "section_xml": """\t\t<sectionSOLID\t\t>
\t\t\t\t\t750.0\t375.0
\t\t\t\t\t0.0\t375.0\t"Concrete"
\t\t\t</sectionSOLID>""",
        "long_reinf": """\t\t<longreinfx\tz\t\t="375.00"
\t\t\t\ttype\t\t="Long"
\t\t\t\tnum\t\t="4"
\t\t\t\tA\t\t="2000.0"
\t\t\t\tname\t\t="mid"  />""",
        "trans_reinf": "",
        "loading_pure_bending": {"MM": "0.0", "MV": "0.0"},  # axial only
        "loading_shear": None,
        "loading_high_shear": None,
    },
    # H+stir - centroidal bar + stirrups, pure axial
    "Hs": {
        "label": "CentRebar+Stir 375x750 axial",
        "section_xml": """\t\t<sectionSOLID\t\t>
\t\t\t\t\t750.0\t375.0
\t\t\t\t\t0.0\t375.0\t"Concrete"
\t\t\t</sectionSOLID>""",
        "long_reinf": """\t\t<longreinfx\tz\t\t="375.00"
\t\t\t\ttype\t\t="Long"
\t\t\t\tnum\t\t="4"
\t\t\t\tA\t\t="2000.0"
\t\t\t\tname\t\t="mid"  />""",
        "trans_reinf": """\t\t<transreinfz\tA\t\t="100.0"
\t\t\t\ttype\t\t="Trans"
\t\t\t\tpattern\t="2"
\t\t\t\tspace\t\t="200.0"
\t\t\t\tdisttop\t="714.0"
\t\t\t\tdistbot\t="44.0"
\t\t\t\tAi\t\t="50.0"
\t\t\t\tdb\t\t="10.0"
\t\t\t\tname\t\t="stirr" />""",
        "loading_pure_bending": {"MM": "0.0", "MV": "0.0"},
        "loading_shear": None,
        "loading_high_shear": None,
    },
    "F": {
        "label": "SingReinf+Stir shear av=1500",
        "section_xml": """\t\t<sectionSOLID\t\t>
\t\t\t\t\t750.0\t375.0
\t\t\t\t\t0.0\t375.0\t"Concrete"
\t\t\t</sectionSOLID>""",
        "long_reinf": """\t\t<longreinfx\tz\t\t="65.00"
\t\t\t\ttype\t\t="Long"
\t\t\t\tnum\t\t="4"
\t\t\t\tA\t\t="2000.0"
\t\t\t\tname\t\t="bot"  />""",
        "trans_reinf": """\t\t<transreinfz\tA\t\t="100.0"
\t\t\t\ttype\t\t="Trans"
\t\t\t\tpattern\t="2"
\t\t\t\tspace\t\t="200.0"
\t\t\t\tdisttop\t="714.0"
\t\t\t\tdistbot\t="44.0"
\t\t\t\tAi\t\t="50.0"
\t\t\t\tdb\t\t="10.0"
\t\t\t\tname\t\t="stirr" />""",
        "loading_pure_bending": None,
        "loading_shear": {"MM": "1.5", "MV": "1.0"},      # av=1500mm
        "loading_high_shear": {"MM": "0.5", "MV": "1.0"}, # av=500mm
    },
}

# Additional loading types for graduated shear introduction
LOADING_LOW_SHEAR = {"MM": "10.0", "MV": "1.0"}   # av=10000mm (very gentle)
LOADING_MED_SHEAR = {"MM": "5.0", "MV": "1.0"}    # av=5000mm (moderate)

# ---------------------------------------------------------------------------
# Material configurations
# ---------------------------------------------------------------------------
# c_mod: 1=Linear, 2=Parabolic/Popovics (R2K default), 3=Popovics explicit
# c_soft: 1=None, 18=Collins-Bentz (R2K default)
# ft: cracking strength (None=auto, 0.001=negligible)
# tsfactor: tension stiffening scale (0.0=off, 1.0=on)

MATERIALS = {
    "1": {
        "label": "LinElastic",
        "fcp": "200.0",
        "c_mod": "1",      # Linear
        "c_soft": "1",     # None
        "ft": "0.001",     # negligible
        "tsfactor": "0.0",
        "extra_attrs": "",
    },
    "2": {
        "label": "ParabNoTens",
        "fcp": "36.0",
        "c_mod": "2",      # Parabolic/Popovics (default)
        "c_soft": "1",     # None
        "ft": "0.001",     # negligible tension
        "tsfactor": "0.0",
        "extra_attrs": "",
    },
    "3": {
        "label": "ElastBrit",
        "fcp": "36.0",
        "c_mod": "2",
        "c_soft": "1",     # None
        "ft": None,        # auto = 0.33*sqrt(fcp)
        "tsfactor": "0.0", # no tension stiffening (brittle)
        "extra_attrs": "",
    },
    "4": {
        "label": "TensStiff",
        "fcp": "36.0",
        "c_mod": "2",
        "c_soft": "1",     # None (isolate tension stiffening effect)
        "ft": None,        # auto
        "tsfactor": "1.0",
        "extra_attrs": "",
    },
    "5": {
        "label": "PlusSoften",
        "fcp": "36.0",
        "c_mod": "2",
        "c_soft": "18",    # Collins-Bentz 2011 (R2K default softening)
        "ft": None,
        "tsfactor": "1.0",
        "extra_attrs": "",
    },
    "6": {
        "label": "Full",
        "fcp": "36.0",
        "c_mod": "2",
        "c_soft": "18",    # default
        "ft": None,
        "tsfactor": "1.0",
        "extra_attrs": "",
    },
}

# ---------------------------------------------------------------------------
# Steel sub-axis
# ---------------------------------------------------------------------------
STEEL = {
    "i": {
        "label": "ElasticSteel",
        "fy": "10000.0",  # very high — no yielding
        "fu": "12000.0",
        "esh": "10.0",
        "eu": "100.0",
    },
    "ii": {
        "label": "EPSteel",
        "fy": "400.0",
        "fu": "400.0",    # fu=fy → no hardening
        "esh": "10.0",
        "eu": "100.0",
    },
    "iii": {
        "label": "TrilinSteel",
        "fy": "400.0",
        "fu": "600.0",
        "esh": "10.0",
        "eu": "100.0",
    },
}

# For transverse steel we use the "ii" (EP) properties always
TRANS_STEEL = STEEL["ii"]

# ---------------------------------------------------------------------------
# Cases to generate: (section_key, mat_key, steel_key, loading_type)
# loading_type: "pb" = pure bending, "sh" = shear, "hs" = high shear
# ---------------------------------------------------------------------------
CASES = [
    # ---------------------------------------------------------------
    # A - unreinforced (steel irrelevant, use i)
    #   Validates: geometry, Ec, ft, cracking detection, integration
    # ---------------------------------------------------------------
    ("A", "1", "i", "pb"),
    ("A", "2", "i", "pb"),
    ("A", "3", "i", "pb"),
    ("A", "4", "i", "pb"),
    ("A", "5", "i", "pb"),
    ("A", "6", "i", "pb"),

    # ---------------------------------------------------------------
    # B - singly reinforced, pure bending
    #   Validates: compression models, tension stiffening (Eq 5-8/5-9)
    #   Predecessor: A
    # ---------------------------------------------------------------
    ("B", "1", "i", "pb"),
    ("B", "2", "i", "pb"),
    ("B", "2", "ii", "pb"),
    ("B", "3", "i", "pb"),     # brittle cracking baseline for B4
    ("B", "3", "ii", "pb"),
    ("B", "4", "i", "pb"),     # KEY: tension stiffening isolation
    ("B", "4", "ii", "pb"),
    ("B", "4", "iii", "pb"),
    ("B", "6", "i", "pb"),
    ("B", "6", "ii", "pb"),
    ("B", "6", "iii", "pb"),

    # ---------------------------------------------------------------
    # H - centroidal bar, pure axial (bond zone calibration)
    #   Validates: Eq 5-9 decay shape, bond zone extent, s_m_bar scaling
    #   Predecessor: A
    #   NOTE: H-series need manual R2K setup (MN loading, supports)
    # ---------------------------------------------------------------
    ("H", "3", "i", "pb"),     # brittle axial — baseline for H4
    ("H", "4", "i", "pb"),     # KEY: bond zone shape calibration
    ("H", "6", "i", "pb"),     # full model — does comp softening affect f1?
    ("Hs", "4", "i", "pb"),    # +stirrups — isolates rho_y under axial

    # ---------------------------------------------------------------
    # C - doubly reinforced, pure bending
    #   Validates: compression bar effect, bond zone interaction
    #   Predecessor: B + H (bond zone calibrated)
    # ---------------------------------------------------------------
    ("C", "1", "i", "pb"),
    ("C", "2", "i", "pb"),     # compression bar effect (no TS)
    ("C", "2", "ii", "pb"),
    ("C", "3", "i", "pb"),     # brittle + comp bar — baseline for C4
    ("C", "4", "i", "pb"),     # KEY: bond zone interaction in bending
    ("C", "4", "ii", "pb"),
    ("C", "6", "i", "pb"),
    ("C", "6", "ii", "pb"),

    # ---------------------------------------------------------------
    # D - singly reinforced + stirrups, pure bending
    #   Validates: stirrup crack check, s_y, ey equilibrium with rho_y
    #   Predecessor: B (no stirrups) + Hs (stirrups axial)
    # ---------------------------------------------------------------
    ("D", "1", "i", "pb"),
    ("D", "2", "i", "pb"),     # stirrups + compression model (no TS)
    ("D", "3", "i", "pb"),     # KEY: stirrup crack check, brittle
    ("D", "4", "i", "pb"),     # KEY: stirrups + tension stiffening
    ("D", "4", "ii", "pb"),
    ("D", "6", "i", "pb"),
    ("D", "6", "ii", "pb"),

    # ---------------------------------------------------------------
    # Shear introduction — graduated M/V ratios
    #   Uses D section (bot bar + stirrups)
    #   Validates: Idle-Dual loop, shear profile, Phase B Newton
    #   Predecessor: D (pure bending with stirrups)
    # ---------------------------------------------------------------

    # Low shear (av=10000mm) — gentle introduction
    ("D", "2", "i", "ls"),     # minimal shear, no TS
    ("D", "3", "i", "ls"),     # minimal shear, brittle cracking
    ("D", "4", "i", "ls"),     # KEY: minimal shear + TS

    # Medium shear (av=5000mm) — theta starts rotating
    ("D", "4", "i", "ms"),     # KEY: moderate shear + TS
    ("D", "6", "i", "ms"),     # full model, moderate shear

    # F - full shear (av=1500mm)
    ("F", "1", "i", "sh"),
    ("F", "2", "i", "sh"),
    ("F", "4", "i", "sh"),     # KEY: full shear + TS
    ("F", "4", "ii", "sh"),
    ("F", "5", "i", "sh"),
    ("F", "5", "ii", "sh"),
    ("F", "6", "i", "sh"),
    ("F", "6", "ii", "sh"),
    ("F", "6", "iii", "sh"),

    # G - high shear (av=500mm)
    ("F", "1", "i", "hs"),
    ("F", "4", "i", "hs"),
    ("F", "5", "i", "hs"),
    ("F", "6", "i", "hs"),
]


def _loading_key(loading_type: str) -> str:
    return {
        "pb": "loading_pure_bending",
        "sh": "loading_shear",
        "hs": "loading_high_shear",
        "ls": "loading_low_shear",
        "ms": "loading_med_shear",
    }[loading_type]


def _section_label(loading_type: str, sec_key: str) -> str:
    if loading_type == "hs":
        return "G"  # high shear uses F section, labeled G
    if loading_type == "ls":
        return sec_key + "ls"  # e.g. "Dls" for low shear
    if loading_type == "ms":
        return sec_key + "ms"  # e.g. "Dms" for medium shear
    return sec_key


def build_rsp(sec_key: str, mat_key: str, steel_key: str, loading_type: str) -> str:
    sec = SECTIONS[sec_key]
    mat = MATERIALS[mat_key]
    st = STEEL[steel_key]
    loading_k = _loading_key(loading_type)
    loading = sec[loading_k]
    if loading is None:
        return ""

    sl = _section_label(loading_type, sec_key)
    name = f"Synth {sl}{mat_key}"
    if sec["long_reinf"] or sec_key in ("D", "F"):
        name += f"-{steel_key}"
    name += f" {mat['label']}"

    # Build concrete attributes
    c_attrs = [
        f'\t\t\t\tfcp\t\t="{mat["fcp"]}"',
        f'\t\t\t\tmaxagg\t="20.0"',
        f'\t\t\t\tc_mod\t\t="{mat["c_mod"]}"',
        f'\t\t\t\tc_soft\t="{mat["c_soft"]}"',
    ]
    if mat["ft"] is not None:
        c_attrs.append(f'\t\t\t\tft\t\t="{mat["ft"]}"')
    c_attrs.append(f'\t\t\t\ttsfactor\t="{mat["tsfactor"]}"')
    c_attrs.append('\t\t\t\tname\t\t="Concrete"')

    conc_xml = '\t\t<concrete\t' + '\n'.join(c_attrs) + '\t/>'

    # Long steel
    long_xml = ""
    if sec["long_reinf"]:
        long_xml_raw = sec["long_reinf"]
        long_xml = f"\t\t<rebar\t\tfy\t\t=\"{st['fy']}\"\n"
        long_xml += f"\t\t\t\tfu\t\t=\"{st['fu']}\"\n"
        long_xml += f"\t\t\t\tesh\t\t=\"{st['esh']}\"\n"
        long_xml += f"\t\t\t\teu\t\t=\"{st['eu']}\"\n"
        long_xml += f"\t\t\t\tname\t\t=\"Long\"\t/>\n"
        long_xml += long_xml_raw

    # Trans steel (always EP)
    trans_xml = ""
    if sec["trans_reinf"]:
        trans_xml = f"\t\t<rebar\t\tfy\t\t=\"{TRANS_STEEL['fy']}\"\n"
        trans_xml += f"\t\t\t\tfu\t\t=\"{TRANS_STEEL['fu']}\"\n"
        trans_xml += f"\t\t\t\tesh\t\t=\"{TRANS_STEEL['esh']}\"\n"
        trans_xml += f"\t\t\t\teu\t\t=\"{TRANS_STEEL['eu']}\"\n"
        trans_xml += f"\t\t\t\tname\t\t=\"Trans\"\t/>\n"
        trans_xml += sec["trans_reinf"]

    # DTD requires rebar+ (at least one rebar element) even for unreinforced sections
    rebar_sections = ""
    if long_xml:
        rebar_sections += "\n" + long_xml
    else:
        # Unreinforced: add dummy rebar to satisfy DTD (no longreinfx uses it)
        rebar_sections += (
            f"\n\t\t<rebar\t\tfy\t\t=\"{st['fy']}\"\n"
            f"\t\t\t\tfu\t\t=\"{st['fu']}\"\n"
            f"\t\t\t\tesh\t\t=\"{st['esh']}\"\n"
            f"\t\t\t\teu\t\t=\"{st['eu']}\"\n"
            f"\t\t\t\tname\t\t=\"Steel\"\t/>"
        )
    if trans_xml:
        rebar_sections += "\n" + trans_xml

    lines = [
        '<?xml version="1.0" encoding="UTF-8" standalone="no" ?>',
        '<!DOCTYPE suite_3g SYSTEM "r3g.dtd">',
        '',
        '<document>',
        f'\t<r3g_beam\tname\t\t="{name}"',
        f'\t\t\tdoneby\t="mcft-test"',
        f'\t\t\tdate\t\t="2026/3/21"\t>',
        conc_xml,          # concrete+ (first, per DTD order)
        rebar_sections,    # rebar+ (second)
        '\t\t<prestress\tfu\t\t="1860.0"\t/>',  # prestress+ (third)
        sec["section_xml"],
        f'\t\t<sectloading\tMM\t\t="{loading["MM"]}"',
        f'\t\t\t\tMV\t\t="{loading["MV"]}"\t/>',
        '\t</r3g_beam>',
        '</document>',
        '',
    ]
    return '\n'.join(lines)


def _fname(sec_key: str, mat_key: str, steel_key: str, loading_type: str) -> str:
    sl = _section_label(loading_type, sec_key)
    has_reinf = SECTIONS[sec_key]["long_reinf"] or sec_key in ("D", "F")
    if has_reinf:
        return f"synth_{sl}{mat_key}{steel_key}.rsp"
    return f"synth_{sl}{mat_key}.rsp"


def main():
    generated = []
    skipped = []
    for args in CASES:
        sec_key, mat_key, steel_key, loading_type = args
        content = build_rsp(*args)
        if not content:
            skipped.append(_fname(*args))
            continue
        fname = _fname(*args)
        path = OUT / fname
        path.write_text(content)
        generated.append(fname)

    print(f"Generated {len(generated)} files:")
    for f in generated:
        print(f"  {f}")
    if skipped:
        print(f"\nSkipped {len(skipped)} (no loading defined):")
        for f in skipped:
            print(f"  {f}")


if __name__ == "__main__":
    main()
