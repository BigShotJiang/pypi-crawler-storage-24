"""Automate Response-2000 via Wine+xdotool to extract analysis results.

Runs on a virtual display (Xvfb) to isolate from the real desktop.
Use --no-xvfb to run on the real display instead.

Usage:
    # Extract M-phi and V-gamma control curves only:
    python tools/r2k_extract.py examples/dm-n1n.rsp -o results/dm-n1n.json

    # Extract all cross-section profiles at all load stages:
    python tools/r2k_extract.py examples/dm-n1n.rsp --full -o results/dm-n1n_full.json

    # Calibrate coordinates via VNC:
    python tools/r2k_extract.py --calibrate

Requires: wine, xdotool, xclip, Xvfb (sudo apt install xvfb x11vnc).
"""

from __future__ import annotations

import argparse
import atexit
import json
import os
import signal
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path


# Module-level state for cleanup
_xvfb_proc: subprocess.Popen | None = None
_original_display: str | None = None


def _cleanup():
    """Force-kill Wine and Xvfb. Called on exit to prevent zombies."""
    for proc_name in ["r2k.exe", "wine", "wineserver"]:
        subprocess.run(["killall", "-9", proc_name],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    global _xvfb_proc
    if _xvfb_proc is not None:
        _xvfb_proc.terminate()
        try:
            _xvfb_proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            _xvfb_proc.kill()
        _xvfb_proc = None
    # Restore original display
    if _original_display is not None:
        os.environ["DISPLAY"] = _original_display


atexit.register(_cleanup)
for _sig in (signal.SIGTERM, signal.SIGINT):
    signal.signal(_sig, lambda s, f: (os._exit(1),))


# ---------------------------------------------------------------------------
# Xvfb virtual display management
# ---------------------------------------------------------------------------

def _find_free_display(start: int = 99, end: int = 109) -> str:
    """Find the next free X display number."""
    for n in range(start, end + 1):
        lock = Path(f"/tmp/.X{n}-lock")
        if not lock.exists():
            return f":{n}"
    return f":{start}"  # fallback


def _start_xvfb(display: str = ":99",
                 resolution: str = "1920x1080x24") -> subprocess.Popen:
    """Start Xvfb on the given display. Returns the process."""
    if not shutil.which("Xvfb"):
        raise RuntimeError("Xvfb not found. Install: sudo apt install xvfb")

    proc = subprocess.Popen(
        ["Xvfb", display, "-screen", "0", resolution,
         "-ac", "-nolisten", "tcp"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(0.5)
    if proc.poll() is not None:
        raise RuntimeError(f"Xvfb failed to start on {display}")
    return proc


# ============================================================================
# Configuration — adjust these for different machines/displays
# ============================================================================

@dataclass
class R2KConfig:
    """Screen layout and path configuration.

    All coordinates are ABSOLUTE SCREEN positions for a 1920x1080 display.
    With Xvfb, the virtual display replicates this exact geometry so
    all coordinates remain valid.
    """

    # R2K executable location
    r2k_dir: str = str(Path(__file__).resolve().parent.parent / "r2k")
    r2k_exe: str = "r2k.exe"

    # Virtual display
    use_xvfb: bool = True
    xvfb_display: str = ":99"
    xvfb_resolution: str = "1920x1080x24"
    hard_timeout: float = 900.0  # 15 min hard kill

    # Window geometry (R2K opens here on this system)
    win_x: int = 0          # window left edge
    win_y: int = 551        # window top edge (including title bar)
    title_bar_h: int = 30   # title bar height (GNOME default)

    # Control graphs in the left panel (absolute screen coords)
    # Measured from screenshot of 1-plot view, 2026-03-21
    ctrl_shear_x: int = 200
    ctrl_shear_y: int = 1010
    ctrl_moment_x: int = 200
    ctrl_moment_y: int = 1320

    # Main plot area centre (for 1-plot view, absolute screen coords)
    # Measured from full screenshot of 1-plot view, 2026-03-21
    main_plot_x: int = 1100
    main_plot_y: int = 790

    # Dropdown combo box (for selecting plot type in 1-plot view)
    dropdown_x: int = 251
    dropdown_y: int = 768

    # Timing
    analysis_wait: float = 1.5     # seconds to wait after starting analysis
    action_delay: float = 0.15     # default delay between xdotool actions
    menu_delay: float = 0.2        # delay between menu keystrokes
    clipboard_delay: float = 0.3   # delay after copy before reading clipboard


# Default config for current system
CFG = R2KConfig()

# Plot types available in the 1-plot dropdown (in order as they appear).
# Indexed from 0.  Verified by full enumeration with Up/Down on 2026-03-21.
# 24 entries total.
PROFILE_PLOTS = [
    "Average Angle",                  # 0
    "Crack Widths",                   # 1
    "Diagonal Spacing",               # 2
    "Long. Average Bond",             # 3
    "Long. Crack Spacing",            # 4
    "Long. Reinf Stress at Crack",    # 5
    "Long. Reinforcement Stress",     # 6
    "Longitudinal Concrete Stress",   # 7
    "Longitudinal Strain",            # 8
    "Max Allowable Comp. Stress",     # 9
    "Principal Compressive Strain",   # 10
    "Principal Compressive Stress",   # 11
    "Principal Tensile Strain",       # 12
    "Principal Tensile Stress",       # 13
    "Shear on Crack",                 # 14
    "Shear Strain",                   # 15
    "Shear Stress",                   # 16
    "Shrinkage & Thermal Strain",     # 17
    "Stirrup Strain",                 # 18
    "Stirrup Stress",                 # 19
    "Stirrup Stress at Crack",        # 20
    "Transverse Average Bond",        # 21
    "Transverse Crack Spacing",       # 22
    "Transverse Strain",              # 23
]

# Subset of plots most useful for reverse-engineering the solver algorithm
KEY_PROFILES = [0, 7, 8, 10, 11, 12, 13, 14, 15, 16, 18, 23]
#  0  Average Angle — theta (crack angle vs depth)
#  7  Longitudinal Concrete Stress — fx profile
#  8  Longitudinal Strain — ex = e0 - phi*z
# 10  Principal Compressive Strain — e2
# 11  Principal Compressive Stress — f2 (compression softening)
# 12  Principal Tensile Strain — e1
# 13  Principal Tensile Stress — f1 (tension stiffening + crack check)
# 14  Shear on Crack — vci limit
# 15  Shear Strain — gamma_xy profile (the shear shape)
# 16  Shear Stress — tau profile (from longitudinal stiffness method)
# 18  Stirrup Strain — transverse steel strain
# 23  Transverse Strain — ey (transverse equilibrium result)


# ============================================================================
# Low-level helpers
# ============================================================================

def _run(cmd: str, timeout: float = 10.0) -> str:
    """Run shell command, return stdout."""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return ""


def _xdotool(args: str, delay: float | None = None):
    """Run xdotool command with post-delay (min 50ms for interruptibility)."""
    _run(f"xdotool {args}")
    time.sleep(max(delay if delay is not None else CFG.action_delay, 0.05))


def _get_clipboard() -> str:
    """Get X11 clipboard content."""
    return _run("xclip -selection clipboard -o", timeout=3)


def _find_r2k_window(timeout: float = 15.0) -> int | None:
    """Wait for R2K window to appear, return window ID.

    Wine creates two windows with the same name (frame + client).
    We want the one at win_y (the frame/toplevel), which has the
    smaller window ID.

    While waiting, dismisses any popup dialogs (e.g. "Full Member
    Properties") that may block R2K from fully loading.
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        out = _run('xdotool search --name "Response  -  "', timeout=3)
        if out:
            wids = []
            for wid in out.strip().split("\n"):
                wid = wid.strip()
                if wid.isdigit():
                    wids.append(int(wid))
            if wids:
                return min(wids)  # lowest ID = toplevel frame
        # Dismiss any blocking dialogs while waiting
        _dismiss_dialogs(max_attempts=3)
        time.sleep(0.5)
    return None


def _activate(wid: int):
    """Activate and focus the R2K window."""
    _xdotool(f"windowactivate {wid}", delay=0.2)


def _dismiss_dialogs(max_attempts: int = 10):
    """Dismiss any unexpected R2K popup dialogs by pressing Enter/Return.

    R2K shows warning dialogs (e.g. 'Could not open file', tension stiffening
    warnings, 'Waiting for the tide to turn') that block automation.
    Finds and focuses dialog windows before pressing Return.
    """
    for _ in range(max_attempts):
        # Find all windows — look for small dialog windows (not the main R2K)
        out = _run('xdotool search --onlyvisible --name ""', timeout=2)
        if out:
            for wid_str in out.strip().split("\n"):
                wid_str = wid_str.strip()
                if not wid_str.isdigit():
                    continue
                wid = int(wid_str)
                name = _run(f'xdotool getwindowname {wid}', timeout=2)
                # Dialog windows: "melanie", "Error in geometry", empty, etc.
                # Skip the main R2K window (has "Response" in title)
                if "Response" in name:
                    continue
                if name or True:  # focus ANY non-main window
                    _xdotool(f"windowactivate {wid}", delay=0.1)
                    _xdotool("key Return", delay=0.2)
        else:
            # No windows found, try blind Return anyway
            _xdotool("key Return", delay=0.2)


# ============================================================================
# Menu navigation
# ============================================================================

def _menu_navigate(keys: list[str]):
    """Navigate R2K menus via F10 + arrow keys.

    keys: list of key names, e.g. ["Right", "Right", "Down", "Return"]
    """
    _xdotool("key F10", delay=CFG.menu_delay)
    for key in keys:
        _xdotool(f"key {key}", delay=CFG.menu_delay)


def _run_sectional_response(wid: int):
    """Solve → Sectional Response."""
    _activate(wid)
    # Menu: File, Define, Loads, Catalog, Solve(4th Right), Down(1st item), Enter
    _menu_navigate(["Right"] * 4 + ["Down", "Return"])


def _switch_to_1_plot(wid: int):
    """View → 1 Cross Section Plot."""
    _activate(wid)
    # Menu: File, Define, Loads, Catalog, Solve, View(5th Right)
    # Items: Cross Section, View Cross Section (XML), 1 Cross Section Plot(3rd Down)
    _menu_navigate(["Right"] * 5 + ["Down"] * 3 + ["Return"])
    time.sleep(0.3)


def _switch_to_9_plots(wid: int):
    """View → 9 Cross Section Plots."""
    _activate(wid)
    _menu_navigate(["Right"] * 5 + ["Down"] * 4 + ["Return"])
    time.sleep(0.3)


def _next_load_stage(wid: int):
    """Go to next (higher) load stage.

    R2K convention: PgUp = Next Load Stage, PgDn = Previous Load Stage.
    (Opposite to what you might expect.)
    """
    _xdotool("key Prior", delay=0.15)  # Prior = PgUp = Next stage in R2K


def _prev_load_stage(wid: int):
    """Go to previous (lower) load stage."""
    _xdotool("key Next", delay=0.15)  # Next = PgDn = Previous stage in R2K


def _go_to_first_load_stage(wid: int):
    """Go to first load stage by pressing PgDn many times."""
    _activate(wid)
    for _ in range(50):
        _xdotool("key Next", delay=0.05)  # PgDn = Previous = towards first
    time.sleep(0.3)


# ============================================================================
# Data extraction
# ============================================================================

def _copy_chart_data_at(screen_x: int, screen_y: int) -> str:
    """Right-click on a chart at given screen coords, select Copy Chart Data."""
    _xdotool(f"mousemove {screen_x} {screen_y}", delay=0.05)
    _xdotool("click 3", delay=0.25)
    # Context menu: Copy Chart Picture, Copy Chart Data(2nd), View Data
    _xdotool("key Down Down", delay=0.1)
    _xdotool("key Return", delay=CFG.clipboard_delay)
    return _get_clipboard()


def _select_dropdown_item(index: int):
    """Select an item from the 1-plot dropdown by index (0-based).

    Click to open list, Home to jump to top, Down×index, Return to select.
    """
    _xdotool(f"mousemove {CFG.dropdown_x} {CFG.dropdown_y}", delay=0.1)
    _xdotool("click 1", delay=0.2)
    _xdotool("key Home", delay=0.1)
    for _ in range(index):
        _xdotool("key Down", delay=0.03)
    _xdotool("key Return", delay=0.2)


def _parse_chart_data(raw: str) -> dict:
    """Parse R2K chart data text into structured dict."""
    lines = raw.strip().split("\n")
    result = {"title": "", "x_label": "", "y_label": "", "x": [], "y": []}

    for line in lines:
        line = line.strip()
        if line.startswith("Title"):
            result["title"] = line.split(":", 1)[1].strip()
        elif line.startswith("X Axis Title"):
            result["x_label"] = line.split(":", 1)[1].strip()
        elif line.startswith("Y Axis Title"):
            result["y_label"] = line.split(":", 1)[1].strip()
        elif line and (line[0].isdigit() or line[0] == "-"):
            parts = line.split()
            if len(parts) >= 2:
                try:
                    result["x"].append(float(parts[0]))
                    result["y"].append(float(parts[1]))
                except ValueError:
                    pass

    return result


# ============================================================================
# High-level extraction
# ============================================================================

def _extract_control_curves(wid: int) -> dict:
    """Extract M-phi and V-gamma from left panel control graphs."""
    _activate(wid)
    shear_raw = _copy_chart_data_at(CFG.ctrl_shear_x, CFG.ctrl_shear_y)
    shear = _parse_chart_data(shear_raw)

    _activate(wid)
    moment_raw = _copy_chart_data_at(CFG.ctrl_moment_x, CFG.ctrl_moment_y)
    moment = _parse_chart_data(moment_raw)

    return {"shear": shear, "moment": moment}


def _extract_current_profiles(wid: int, plot_indices: list[int] | None = None
                              ) -> list[dict]:
    """Extract cross-section profiles at current load stage via 1-plot view.

    Parameters
    ----------
    wid : R2K window ID
    plot_indices : which plots to extract (indices into PROFILE_PLOTS).
                   None = KEY_PROFILES.

    Returns list of parsed chart data dicts.
    """
    if plot_indices is None:
        plot_indices = KEY_PROFILES

    profiles = []
    for idx in plot_indices:
        _activate(wid)
        _select_dropdown_item(idx)
        time.sleep(0.1)

        raw = _copy_chart_data_at(CFG.main_plot_x, CFG.main_plot_y)
        data = _parse_chart_data(raw)
        if not data["title"]:
            data["title"] = (PROFILE_PLOTS[idx]
                             if idx < len(PROFILE_PLOTS)
                             else f"Plot {idx}")
        profiles.append(data)

    return profiles


def _count_load_stages(wid: int) -> int:
    """Estimate number of load stages by stepping through with PgDn.

    Goes to first stage, then counts PgDn presses until the displayed
    data stops changing (detected via clipboard content).
    """
    _activate(wid)
    _go_to_first_load_stage(wid)
    time.sleep(0.3)

    last_clip = ""
    count = 0
    max_stages = 200  # safety limit

    for _ in range(max_stages):
        # Copy current chart data to detect changes
        raw = _copy_chart_data_at(CFG.main_plot_x, CFG.main_plot_y)
        if raw == last_clip and count > 0:
            break  # No change = we've gone past the last stage
        last_clip = raw
        count += 1
        _next_load_stage(wid)
        time.sleep(0.2)

    return count


# ============================================================================
# Main extraction functions
# ============================================================================

def extract_r2k(rsp_path: str | Path, full: bool = False,
                max_stages: int | None = 15,
                plot_indices: list[int] | None = None,
                min_moment: float = 1.0,
                config: R2KConfig | None = None,
                output_path: str | Path | None = None) -> dict:
    """Launch R2K, run Sectional Response, extract results.

    Parameters
    ----------
    rsp_path : path to .rsp file
    full : if True, extract all profiles at all load stages
    config : screen layout config (uses default if None)

    Returns
    -------
    dict with extracted data.
    """
    global CFG, _xvfb_proc, _original_display
    if config is not None:
        CFG = config

    rsp_path = Path(rsp_path).resolve()
    r2k_dir = Path(CFG.r2k_dir)
    r2k_exe = r2k_dir / CFG.r2k_exe

    # --- Start virtual display ---
    xvfb_proc = None
    display_env = os.environ.copy()
    if CFG.use_xvfb:
        display = _find_free_display(
            int(CFG.xvfb_display.lstrip(":")))
        xvfb_proc = _start_xvfb(display, CFG.xvfb_resolution)
        _xvfb_proc = xvfb_proc
        _original_display = os.environ.get("DISPLAY")
        os.environ["DISPLAY"] = display
        display_env["DISPLAY"] = display
        print(f"Xvfb started on {display}")

    # --- Hard timeout watchdog ---
    if CFG.hard_timeout > 0:
        def _watchdog():
            time.sleep(CFG.hard_timeout)
            print(f"\nHARD TIMEOUT ({CFG.hard_timeout}s) — killing everything")
            os._exit(2)
        threading.Thread(target=_watchdog, daemon=True).start()

    # Copy .rsp to R2K directory so it can find support files
    dest_rsp = r2k_dir / rsp_path.name
    if dest_rsp.resolve() != rsp_path.resolve():
        shutil.copy2(rsp_path, dest_rsp)

    # Launch R2K (on the virtual display if Xvfb is active)
    proc = subprocess.Popen(
        ["wine", str(r2k_exe), rsp_path.name],
        cwd=str(r2k_dir),
        env=display_env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    try:
        # Wait for window (Xvfb needs longer for Wine to initialise)
        wid = _find_r2k_window(timeout=30 if CFG.use_xvfb else 15)
        if wid is None:
            raise RuntimeError("R2K window did not appear")
        print(f"R2K window found: {wid}")

        # Position window at the expected geometry.
        # On Xvfb this replicates the real-desktop layout so all
        # absolute coordinates remain valid.
        time.sleep(0.5)
        subprocess.run(
            ["xdotool", "windowmove", "--sync", str(wid),
             str(CFG.win_x), str(CFG.win_y)],
            check=False,
        )
        subprocess.run(
            ["xdotool", "windowsize", "--sync", str(wid), "1920", "529"],
            check=False,
        )
        time.sleep(0.5)

        # Dismiss any file-open dialogs before solving
        _activate(wid)
        _dismiss_dialogs()

        # Run Sectional Response
        _run_sectional_response(wid)

        # Dismiss dialogs that R2K shows after Solve is clicked:
        # "Waiting for the tide to turn" (melanie), tension stiffening warnings,
        # geometry errors, etc.  Try multiple times with delays.
        for _attempt in range(3):
            time.sleep(1.0)
            _dismiss_dialogs()
        _activate(wid)

        # Wait for analysis to complete: switch to 1-plot view, then poll
        # the moment control curve until it has valid data.
        print("Waiting for analysis to complete...")
        time.sleep(CFG.analysis_wait)
        _switch_to_1_plot(wid)

        controls = None
        for attempt in range(20):  # up to ~40s total
            _activate(wid)
            controls = _extract_control_curves(wid)
            n_moment = len(controls["moment"]["x"])
            if n_moment >= 5:
                break
            print(f"  ... not ready ({n_moment} pts), retrying")
            time.sleep(2.0)
        else:
            raise RuntimeError(
                f"Analysis did not complete (only {n_moment} moment pts after retries)")

        n_shear = len(controls["shear"]["x"])
        print(f"  Top graph: {n_shear} pts, "
              f"peak = {max(controls['shear']['y']) if controls['shear']['y'] else 'N/A'}")
        m_peak = max(controls['moment']['y']) if controls['moment']['y'] else 0.0
        print(f"  Moment: {n_moment} pts, peak = {m_peak:.3f} kNm")

        result = {
            "rsp_file": str(rsp_path),
            "controls": controls,
        }

        if full and m_peak < min_moment:
            print(f"  SKIP profiles: M_peak={m_peak:.3f} kNm < threshold {min_moment} kNm "
                  f"(section has negligible capacity)")
            result["_skipped_profiles"] = f"M_peak={m_peak:.3f} < {min_moment} kNm"
            return result

        if full:
            # Extract profiles at sampled load stages
            _activate(wid)
            _go_to_first_load_stage(wid)
            time.sleep(0.3)

            n_total = n_moment  # total load stages from M-phi curve
            # Sample up to max_stages evenly across all stages
            if max_stages and max_stages < n_total:
                step = n_total / max_stages
                sample_indices = sorted(set(
                    min(int(i * step), n_total - 1)
                    for i in range(max_stages)
                ))
            else:
                sample_indices = list(range(n_total))

            print(f"  {n_total} total stages, extracting {len(sample_indices)} "
                  f"with {len(plot_indices or KEY_PROFILES)} profiles each")

            all_stages = []
            current = 0
            for target in sample_indices:
                # Step forward to target stage
                while current < target:
                    _next_load_stage(wid)
                    current += 1

                print(f"  Stage {target + 1}/{n_total}...", end="", flush=True)
                _activate(wid)
                profiles = _extract_current_profiles(wid, plot_indices)
                all_stages.append({
                    "stage": target,
                    "profiles": profiles,
                })
                print(f" {len(profiles)} profiles")

                # Incremental save after each stage so data is never lost
                if output_path is not None:
                    result["stages"] = all_stages
                    result["_note"] = (
                        f"{n_total} total stages; "
                        f"{len(all_stages)}/{len(sample_indices)} extracted so far"
                    )
                    _out = Path(output_path)
                    _out.parent.mkdir(parents=True, exist_ok=True)
                    with open(_out, "w") as _f:
                        json.dump(result, _f, indent=2)

            result["stages"] = all_stages
            result["_note"] = (f"{n_total} total stages; "
                               f"{len(sample_indices)} sampled for profiles")

        return result

    finally:
        # Always close R2K
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        # Clean up Xvfb
        if xvfb_proc is not None:
            xvfb_proc.terminate()
            try:
                xvfb_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                xvfb_proc.kill()
            _xvfb_proc = None
        # Restore real display
        if _original_display is not None:
            os.environ["DISPLAY"] = _original_display


def _calibrate(cfg: R2KConfig):
    """Launch R2K on Xvfb with VNC for coordinate calibration."""
    display = _find_free_display(int(cfg.xvfb_display.lstrip(":")))
    xvfb = _start_xvfb(display, cfg.xvfb_resolution)
    global _xvfb_proc
    _xvfb_proc = xvfb
    os.environ["DISPLAY"] = display
    print(f"Xvfb started on {display}")

    # Start VNC server
    vnc = subprocess.Popen(
        ["x11vnc", "-display", display, "-forever", "-nopw",
         "-localhost"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    print(f"VNC server running. Connect with:  vncviewer localhost:5900")
    print("Press Ctrl+C to stop.\n")

    # Launch R2K
    r2k_dir = Path(cfg.r2k_dir)
    r2k_exe = r2k_dir / cfg.r2k_exe
    proc = subprocess.Popen(
        ["wine", str(r2k_exe)],
        cwd=str(r2k_dir),
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )

    try:
        proc.wait()
    except KeyboardInterrupt:
        pass
    finally:
        proc.terminate()
        vnc.terminate()
        xvfb.terminate()


def main():
    parser = argparse.ArgumentParser(
        description="Extract Response-2000 analysis results (runs on Xvfb)"
    )
    parser.add_argument("rsp", nargs="?", help="Path to .rsp file (single mode)")
    parser.add_argument("-o", "--output", help="Output JSON file (single mode)", default=None)
    parser.add_argument("--full", action="store_true",
                        help="Extract cross-section profiles at sampled load stages")
    parser.add_argument("--max-stages", type=int, default=15, metavar="N",
                        help="Max load stages to sample for profiles "
                             "(default 15, 0 = all stages)")
    parser.add_argument("--min-moment", type=float, default=1.0, metavar="kNm",
                        help="Skip profile extraction if M_peak < this (default 1.0 kNm)")
    parser.add_argument("--plots", type=str, default=None, metavar="INDICES",
                        help="Comma-separated plot indices to extract "
                             "(default: KEY_PROFILES). "
                             "Pure-bending subset: '0,7,8,11,12,13'")
    parser.add_argument("--batch", metavar="GLOB",
                        help="Batch mode: glob pattern of .rsp files "
                             "(e.g. 'tools/synth_A*.rsp'). "
                             "Saves each to results/synth/<stem>_r2k.json")
    parser.add_argument("--no-xvfb", action="store_true",
                        help="Run on real display (no Xvfb isolation)")
    parser.add_argument("--timeout", type=float, default=900, metavar="SEC",
                        help="Hard timeout in seconds (default 900 = 15min, 0 = none)")
    parser.add_argument("--calibrate", action="store_true",
                        help="Launch R2K on Xvfb with VNC for coordinate calibration")
    args = parser.parse_args()

    # Apply config overrides from CLI
    global CFG
    CFG = R2KConfig(
        use_xvfb=not args.no_xvfb,
        hard_timeout=args.timeout if args.timeout > 0 else 0,
    )

    if args.calibrate:
        _calibrate(CFG)
        return

    plot_indices = None
    if args.plots:
        plot_indices = [int(x.strip()) for x in args.plots.split(",")]

    # --max-stages 0 means all stages
    max_stages = args.max_stages if args.max_stages > 0 else None

    if args.batch:
        import glob as _glob
        rsp_files = sorted(_glob.glob(args.batch))
        if not rsp_files:
            print(f"No files matched: {args.batch}")
            return
        out_dir = Path("results/synth")
        out_dir.mkdir(parents=True, exist_ok=True)
        print(f"Batch mode: {len(rsp_files)} files → {out_dir}/")
        for rsp in rsp_files:
            stem = Path(rsp).stem
            out_path = out_dir / f"{stem}_r2k.json"
            if out_path.exists():
                print(f"  SKIP {stem} (already exists)")
                continue
            print(f"\n{'='*60}")
            print(f"  Processing: {rsp}")
            print(f"{'='*60}")
            try:
                result = extract_r2k(rsp, full=args.full,
                                     max_stages=max_stages,
                                     plot_indices=plot_indices,
                                     min_moment=args.min_moment,
                                     output_path=out_path)
                with open(out_path, "w") as f:
                    json.dump(result, f, indent=2)
                print(f"  Saved → {out_path}")
            except Exception as e:
                print(f"  ERROR: {e}")
                import traceback
                traceback.print_exc()
            finally:
                # Brief pause between cases for Wine cleanup
                time.sleep(2)
        return

    if not args.rsp:
        parser.error("Provide either a .rsp file or --batch GLOB")

    out_path = Path(args.output) if args.output else None
    result = extract_r2k(args.rsp, full=args.full,
                         max_stages=max_stages,
                         plot_indices=plot_indices,
                         min_moment=args.min_moment,
                         output_path=out_path)

    if out_path:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "w") as f:
            json.dump(result, f, indent=2)
        print(f"Results saved to {out_path}")
    else:
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
