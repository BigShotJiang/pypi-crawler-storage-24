#!/bin/bash
# Run R2K extraction in parallel across multiple Xvfb displays.
#
# Usage:
#   ./tools/run_batch_parallel.sh [MAX_JOBS] [GLOB]
#
# Examples:
#   ./tools/run_batch_parallel.sh 4 'tools/synth_B*.rsp'   # 4 parallel, B-series
#   ./tools/run_batch_parallel.sh 15 'tools/synth_*.rsp'   # 15 parallel, all
#   ./tools/run_batch_parallel.sh                          # auto cores/2, all
#
# Each job runs on its own Xvfb display, fully isolated.
# Results saved to results/synth/<stem>_r2k.json (skips existing).
# Incremental saves: partial data is preserved if a job crashes.
#
# Requirements: wine, xdotool, xclip, Xvfb, python3

set -euo pipefail

# --- Check dependencies ---
MISSING=()
for cmd in wine Xvfb xdotool xclip python3; do
    command -v "$cmd" >/dev/null 2>&1 || MISSING+=("$cmd")
done
# Check wine32 (library, not command)
if ! dpkg -l wine32 2>/dev/null | grep -q '^ii'; then
    MISSING+=("wine32")
fi
if [ ${#MISSING[@]} -gt 0 ]; then
    echo "ERROR: Missing dependencies: ${MISSING[*]}"
    echo "Install with: sudo dpkg --add-architecture i386 && sudo apt update && sudo apt install -y wine wine32 xvfb xdotool xclip python3"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"

# --- Check R2K exists ---
if [ ! -f "r2k/r2k.exe" ]; then
    echo "ERROR: r2k/r2k.exe not found. Place R2K in the r2k/ directory."
    exit 1
fi

# --- Configuration ---
MAX_JOBS="${1:-$(( $(nproc) / 2 ))}"
GLOB_PATTERN="${2:-tools/synth_*.rsp}"
OUT_DIR="results/synth"
TIMEOUT=900  # 15 min per file

mkdir -p "$OUT_DIR"

# --- Collect files to process ---
FILES=()
SKIPPED=0
for rsp in $GLOB_PATTERN; do
    [ -f "$rsp" ] || continue
    stem=$(basename "$rsp" .rsp)
    out="$OUT_DIR/${stem}_r2k.json"
    if [ -f "$out" ]; then
        SKIPPED=$((SKIPPED + 1))
        continue
    fi
    FILES+=("$rsp")
done

TOTAL=${#FILES[@]}
GRN='\033[0;32m'
RED='\033[0;31m'
YEL='\033[0;33m'
CYN='\033[0;36m'
BLD='\033[1m'
DIM='\033[2m'
RST='\033[0m'

echo ""
printf "  ${BLD}${CYN}R2K Parallel Batch Extraction${RST}\n"
echo "  ──────────────────────────────────────────"
printf "  Files to process: ${BLD}%d${RST}\n" "$TOTAL"
printf "  Already done:     ${DIM}%d${RST}\n" "$SKIPPED"
printf "  Max parallel:     ${BLD}%d${RST}\n" "$MAX_JOBS"
printf "  Timeout per file: ${DIM}%ds${RST}\n" "$TIMEOUT"
printf "  Output dir:       ${DIM}%s${RST}\n" "$OUT_DIR"
echo "  ──────────────────────────────────────────"
echo ""

if [ "$TOTAL" -eq 0 ]; then
    echo "Nothing to do."
    exit 0
fi

# --- Run in parallel using xargs ---
# Each job gets a unique display via the extraction tool's _find_free_display()
# Progress tracking: each job writes status to a shared directory
PROGRESS_DIR=$(mktemp -d)
trap "rm -rf $PROGRESS_DIR" EXIT

printf '%s\n' "${FILES[@]}" | xargs -P "$MAX_JOBS" -I {} bash -c '
    rsp="{}"
    stem=$(basename "$rsp" .rsp)
    out="'"$OUT_DIR"'/${stem}_r2k.json"
    log="'"$OUT_DIR"'/${stem}_r2k.log"
    prog="'"$PROGRESS_DIR"'/${stem}"

    echo "starting" > "$prog"

    python tools/r2k_extract.py "$rsp" \
        --full --max-stages 0 \
        --timeout '"$TIMEOUT"' \
        -o "$out" \
        > "$log" 2>&1 &
    PID=$!

    # Monitor progress from log file while extraction runs
    while kill -0 $PID 2>/dev/null; do
        if [ -f "$log" ]; then
            latest=$(grep -oP "Stage \K[0-9]+/[0-9]+" "$log" 2>/dev/null | tail -1)
            if [ -n "$latest" ]; then
                echo "$latest" > "$prog"
            fi
        fi
        sleep 2
    done
    wait $PID
    status=$?

    if [ $status -eq 0 ]; then
        echo "done" > "$prog"
        printf "\033[0;32m  ✓ %-25s complete\033[0m\n" "$stem"
    else
        echo "FAIL" > "$prog"
        printf "\033[0;31m  ✗ %-25s FAILED (see %s)\033[0m\n" "$stem" "$log"
    fi
' &

XARGS_PID=$!

# --- Live progress display ---
_show_progress() {
    local prev_done=0
    while kill -0 $XARGS_PID 2>/dev/null; do
        sleep 3
        n_done=0; n_fail=0; n_active=0; active_list=""
        for f in "$PROGRESS_DIR"/*; do
            [ -f "$f" ] || continue
            status=$(cat "$f" 2>/dev/null)
            name=$(basename "$f")
            case "$status" in
                done)     n_done=$((n_done + 1)) ;;
                FAIL)     n_fail=$((n_fail + 1)) ;;
                starting) n_active=$((n_active + 1))
                          active_list="$active_list ${CYN}${name}${RST}" ;;
                *)        n_active=$((n_active + 1))
                          active_list="$active_list ${CYN}${name}${DIM}[${status}]${RST}" ;;
            esac
        done

        # Build progress bar
        pct=0
        if [ "$TOTAL" -gt 0 ]; then
            pct=$(( (n_done + n_fail) * 100 / TOTAL ))
        fi
        bar_len=20
        filled=$(( pct * bar_len / 100 ))
        empty=$(( bar_len - filled ))
        bar="${GRN}$(printf '█%.0s' $(seq 1 $filled 2>/dev/null))${DIM}$(printf '░%.0s' $(seq 1 $empty 2>/dev/null))${RST}"

        printf "\r  ${bar} ${BLD}%3d%%${RST}  ${GRN}%d${RST}/${BLD}%d${RST} done" \
            "$pct" "$n_done" "$TOTAL"
        if [ "$n_fail" -gt 0 ]; then
            printf "  ${RED}%d failed${RST}" "$n_fail"
        fi
        printf "  ${DIM}%d active${RST} %b    " "$n_active" "$active_list"
    done
    echo ""
}

_show_progress &
PROGRESS_PID=$!

wait $XARGS_PID 2>/dev/null
kill $PROGRESS_PID 2>/dev/null
wait $PROGRESS_PID 2>/dev/null
echo ""

# --- Summary ---
echo ""
echo "  ──────────────────────────────────────────"
printf "  ${BLD}Batch complete${RST}\n"
echo "  ──────────────────────────────────────────"
DONE=0
FAILED=0
for rsp in $GLOB_PATTERN; do
    [ -f "$rsp" ] || continue
    stem=$(basename "$rsp" .rsp)
    out="$OUT_DIR/${stem}_r2k.json"
    if [ -f "$out" ]; then
        DONE=$((DONE + 1))
    else
        FAILED=$((FAILED + 1))
        printf "  ${RED}✗ MISSING: %s${RST}\n" "$stem"
    fi
done
echo ""
printf "  ${GRN}✓ Done: %d${RST}  " "$DONE"
if [ "$FAILED" -gt 0 ]; then
    printf "${RED}✗ Missing: %d${RST}" "$FAILED"
else
    printf "${GRN}All complete!${RST}"
fi
echo ""

# --- Cleanup any stray processes ---
killall -9 wine wineserver r2k.exe Xvfb 2>/dev/null || true
printf "  ${DIM}Cleanup: killed stray Wine/Xvfb processes${RST}\n"
echo ""
