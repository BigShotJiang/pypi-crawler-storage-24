# response2k: Implementation Specification
**Source:** Bentz (2000), *Sectional Analysis of Reinforced Concrete Members*, PhD Thesis,
University of Toronto. All equation numbers refer to that thesis unless otherwise noted.

---

## 0. Package Overview

**Working name:** `response2k`  
**Language:** Python 3.11+, typed throughout  
**Optional backend:** C++ via pybind11 for the MCFT inner loop if profiling warrants it  
**GUI:** Streamlit (first version); core package must be fully independent of GUI layer  
**Scope of first version:** Response-2000 equivalent only. No Shell-2000, Triax-2000, or
Membrane-2000 extensions. No time-dependent effects in v1.

---

## 1. Module Structure

```
response2k/
  materials.py          # All constitutive relations (no cross-module deps)
  mcft.py               # MCFT inner loop: strain -> stress, crack check, stiffness matrices
  section.py            # Section geometry, layer discretisation, crack spacing
  longitudinal_stiffness.py   # Chapter 6 method: shear stress profile
  solver.py             # Outer loops: load stepping, section equilibrium, failure detection
  io.py                 # XML (.rsp) parser, legacy .r2t parser, output writers
  gui/                  # Streamlit app (separate, depends on above)
```

---

## 2. Constitutive Relations (`materials.py`)

### 2.1 Concrete compression base curve

Two options (selected via `C_MOD` flag, default = Popovics):

**Popovics/Thorenfeldt/Collins** (recommended, `C_MOD=2`):

```
f_c = f_c' * (e_c/e_c') * n / (n - 1 + (e_c/e_c')^(n*k))
```

where:
- `n = 0.8 + f_c'/17`  (f_c' in MPa)
- `k = 0.67 + f_c'/62`  for post-peak (e_c > e_c'), else `k = 1.0`

**Parabolic** (`C_MOD=1`):

```
f_c = f_c' * [2*(e_c/e_c') - (e_c/e_c')^2]   for e_c <= e_c'
f_c = f_c' * [1 - 0.15*(e_c/e_c' - 1)/(e_cu/e_c' - 1)]   post-peak
```

**Linear to peak** (`C_MOD=0`): for simple/degenerate cases only.

**Strain at peak stress** (if not user-specified):

```
e_c' = f_c' * n / (Ec * (n - 1))
```

where `Ec` (initial tangent, MPa) defaults to `3320*sqrt(f_c') + 6900` (Collins & Mitchell).
If Ec not given, `Ec = (f_c'/10 + 0.7) * 3000` (approximate, MPa units).

### 2.2 Compression softening

Applied as a multiplier on the base compression curve: `f_2_max = beta * f_c'`

**Normal strength concrete** (f_c' <= 60 MPa, Ch. 3 / Fig. 3-1):

```
beta = 1 / (0.8 + 170*e1)    [cap at 1.0]
```

where `e1` is the principal tensile strain.

**High strength concrete** (f_c' >= 90 MPa, Porasz 1989):

```
beta = (1 / (0.8 + 170*e1)) * (0.9 - f_c'/250)   [cap at 1.0]
```

**Transition** (60 < f_c' < 90 MPa): linear interpolation between the two.

**Effective aggregate size for aggregate interlock** (§5-5):
- `a_eff = a` for `f_c' <= 60 MPa`
- `a_eff = a * (1 - (f_c' - 60)/20)` for `60 < f_c' < 80 MPa`
- `a_eff = 0` for `f_c' >= 80 MPa`  (crack cuts through aggregate in HSC)

### 2.3 Cracking strength (§5-2, Eq. 5-3)

```
f_t = 0.45 * (f_c')^0.4    [MPa]
```

**Not** the ACI value `0.33*sqrt(f_c')`. This is derived from large-element data.  
User may override via `FT` parameter in input file.  
Note: only apply the +25% young concrete adjustment if explicitly requested (v2 feature).

### 2.4 Tension stiffening — well-reinforced zones (§5-3, Eq. 5-8)

```
f_1 = f_t / (1 + sqrt(500 * e1))      [Vecchio 1982, base MCFT - reference only]

f_1 = f_t / (1 + sqrt(3.6*m * e1))    [Bentz 2000 - USE THIS]
```

where the bond parameter `m` (mm) is:

```
m = A_c / sum(pi * d_b_i)
```

- `A_c` = area of concrete effectively bonded to bars in the relevant zone (mm²)
- `d_b_i` = diameter of each bar bonded to that zone (mm)
- For biaxial/triaxial cases: use the **minimum** m across all reinforcement directions

The `TSFACTOR` input parameter (0.0 to 1.0) scales the tension stiffening result:
```
f_1_effective = TSFACTOR * f_1
```
Default `TSFACTOR = 1.0`.

### 2.5 Tension stiffening — poorly-reinforced zones (§5-4, Eq. 5-9)

For concrete more than `2 * s_x` (twice crack spacing at bar) from any reinforcing bar:

```
f_1(z) = 2 * f_t / (1 + sqrt(3.6*m * e1)) * curve_fit(z/s_x)
```

where `curve_fit` comes from the FE tooth analysis (Fig. 5-15):

```
curve_fit(xi) = 0.0 for xi > 0.5   (effectively zero average tension beyond half crack spacing)
curve_fit(xi) = 1 - 2*xi  for xi <= 0.5   (linear approximation)
```

The factor of 2.0 converts from average to local (§5-4 explanation).  
Between zones (within `2*s_x` of bar): use the well-reinforced equation above.  
If no reinforcement at all: `f_1 = 0` after cracking.

### 2.6 Aggregate interlock / shear on crack (§3-2-5, Walraven equation)

Maximum shear stress transferable across a crack:

```
v_ci_max = 0.18*sqrt(f_c') / (0.31 + 24*w / (a_eff + 16))    [MPa]
```

where:
- `w` = crack width (mm) = `e1 * s_theta` (principal tensile strain × diagonal crack spacing)
- `a_eff` = effective aggregate size (see §2.2 above)
- `f_c'` in MPa

### 2.7 Reinforcement (bare bar)

```
f_s = E_s * e_s                    for e_s <= e_y
f_s = f_y                          for e_y < e_s <= e_sh
f_s = f_y + (f_u - f_y) * ((e_s - e_sh)/(e_u - e_sh))^0.5   for e_s > e_sh
```

Default values if not specified:
- `E_s = 200,000 MPa`
- `f_u = 1.5 * f_y` (§App A: assumed 50% above yield)
- `e_sh` and `e_u`: user input or defaults from bar type table

**Prestressed steel** (Ramberg-Osgood, three parameters A, B, C from input):

```
f_p = E_p * e_p * [A + (1-A) / (1 + (B * e_p)^C)^(1/C)]
```

where `E_p`, `A`, `B`, `C` come from the MATERIAL PRESTRESS block.
Default: low-relaxation strand, `f_pu = 1860 MPa`.

---

## 3. MCFT Inner Loop (`mcft.py`)

### 3.1 State variables per node

Each biaxial node carries:
- `ex`, `ey` or equivalently `e1`, `e2`, `theta` (principal strains and angle)
- `f1`, `f2` (principal concrete stresses)
- `f_sx`, `f_sy` (average steel stresses)
- crack width `w`, crack spacing `s_theta`

### 3.2 Stress from strain (§3-4-1 procedure)

Given strain state `(ex, ey, gamma_xy)`:

1. Compute principal strains `e1, e2` and angle `theta` via Mohr's circle:
   ```
   e1,e2 = (ex+ey)/2 ± sqrt(((ex-ey)/2)^2 + (gamma_xy/2)^2)
   tan(2*theta) = gamma_xy / (ex - ey)
   ```

2. Compute principal concrete stresses:
   - `f1`: tension stiffening (§2.4 or §2.5 depending on zone)
   - `f2 = beta * f_c_base(e2)` where `beta` from compression softening (§2.2)

3. Perform crack check (§3.1 below).

4. Rotate principal concrete stresses back to x-y frame.

5. Add average steel stresses: `f_x += rho_x * f_sx`, etc.

### 3.3 Crack check (Chapter 4)

The crack check ensures average stresses are compatible with local crack equilibrium.

**Crack spacing** `s_theta` (see §5.1):
```
s_theta = 1 / (sin(theta)/s_x + cos(theta)/s_y)
```
where `s_x`, `s_y` are crack spacings in x and y directions from §5 (crack spacing model).

**Crack width:**
```
w = e1 * s_theta
```

**Maximum shear on crack** `v_ci_max` from Walraven (§2.6).

**Local stress equilibrium at crack** (2D, Table 3-1):

For each reinforcement direction i:
```
f_s_cr_i = (f_i_avg - f_ci) / rho_i + f_si_avg
```

The crack check requires:
1. `f_s_cr_i <= f_y_i` for all directions (steel not over-yielded at crack)
2. `v_ci <= v_ci_max` (aggregate interlock not exceeded)

If condition 2 governs, reduce `f1` (average principal tensile stress) to the value
consistent with equilibrium:
```
f1_reduced = rho_x*(f_y_x - f_sx)*cos²theta + rho_y*(f_y_y - f_sy)*sin²theta + v_ci_max*sin(2*theta)
```
This reduced value replaces `f1` for the current iteration step.

**Explicit steps for 2D crack check** (Table 4-1 in thesis):
1. Calculate `s_theta`, `w`, `v_ci_max`
2. Calculate `v_ci` required from equilibrium
3. If `v_ci > v_ci_max`: reduce `f1` as above
4. Recheck steel stresses at crack; if any `f_s_cr > f_y`: reduce `f1` further

### 3.4 Secant stiffness (§3-5)

The [D] matrix relates stress to strain via secant moduli. In principal directions:

```
[Dc]' = diag(Ec1_sec, Ec2_sec)
```

where:
```
Ec1_sec = f1 / e1     (if e1 > 0, else initial tangent)
Ec2_sec = f2 / e2
Gc12_sec = 0.5 * (f1 - f2) / (e1 - e2)    [if e1 != e2]
```

For each steel direction: `Ds_i_sec = f_si / e_si`

Full [D] in x-y frame via rotation with transformation matrix T (§3-5, full matrix given).

For 2D, use columns/rows 1,2,4 only and substitute sin/cos of theta directly.

### 3.5 Tangent stiffness (§3-6)

Required by the longitudinal stiffness method (Chapter 6).

**Non-symmetric** because compression softening depends asymmetrically on e1 and e2.

Principal direction tangent stiffnesses:
```
Et1 = df1/de1    (from tension stiffening or crack-check equation, whichever governs)
Et2 = df2/de2    (from compression base curve, with e1 held fixed for the e2 derivative)
```

The cross-term (effect of e1 on f2 through softening):
```
df2/de1 = (df2/d_beta) * (d_beta/de1)
```
where `d_beta/de1 = -170*beta^2` for NSC.

The full tangent [D] matrix is **not symmetric**. For 2D, assemble row by row,
computing derivative of each stress component with respect to each strain component
numerically if the algebraic form is unwieldy.

Shear tangent modulus:
```
Gc12_tan = 0.5*(f1 - f2) / (e1 - e2)    [same as secant for this formulation]
```

---

## 4. Section Geometry and Crack Spacing (`section.py`)

### 4.1 Section definition

The cross-section is defined as a series of (depth, width) pairs from bottom to top,
forming a piecewise-linear outline. Multiple concrete material types allowed (up to 5).

Dynamic layering (binary tree subdivision):
- Start with 8 layers
- Check stress at quarter-points of each layer by quadratic interpolation
- If interpolation error exceeds tolerance: subdivide layer in two
- Typical result: ~50 layers for a complex section

### 4.2 Crack spacing (§7-5, CEB model, Eq. 7-6)

```
s = 2*c + 0.1 * d_b / p
```

where:
- `c` = diagonal distance from the point of interest to nearest reinforcing bar (mm)
- `d_b` = diameter of nearest bar (mm)
- `p` = reinforcement ratio within 7.5*d_b above and below that bar

**For Response-2000** (varies over depth):
- `c` = largest diagonal distance from current depth z to any reinforcing bar
- `p` computed within ±7.5*d_b of each bar layer
- Between bar layers: linearly interpolate the `0.1*d_b/p` term
- **Cap:** crack spacing cannot exceed member depth for beams in flexure
- **No reinforcement:** `s = 5 * h` (five times section depth)

`s_x` = crack spacing in longitudinal (x) direction  
`s_y` = crack spacing in transverse (y) direction (stirrup spacing governs here)

### 4.3 Hoop reinforcement (§7-6, Eq. 7-7)

For closed hoops, only the component in the shear direction contributes:

```
e_hoop = e_t * sin²(alpha)
f_hoop_effective = f_hoop * sin(alpha)
```

where `alpha` = angle between hoop leg and shear direction.

---

## 5. Longitudinal Stiffness Method (`longitudinal_stiffness.py`)

### 5.1 Reduced nodal tangent stiffness (§6-5, Eq. 6-2)

Each node has a 3×3 tangent stiffness Ki in (ex, ey, gamma_xy):

```
Ki = [[a, b, c],
      [d, e, f],
      [g, h, k]]   (non-symmetric in general)
```

Impose zero transverse stress (`dNy = 0`) to get reduced 2×2 matrix Ki' in (ex, gamma):

```
Ki'[j][0] = a - b*d/e      Ki'[j][2] = c - b*f/e
Ki'[m][0] = g - h*d/e      Ki'[m][2] = k - h*f/e
```

(using the labelling in §6-5; j,k are longitudinal stiffness terms; m,n are shear terms)

### 5.2 Global stiffness matrix J (§6-5)

Integrated over all layers using Simpson's rule (quadratic per layer, 3 points):

```
J[0][0] += (j1*b1 + 4*j2*b2 + j3*b3) * dz/6          [axial-axial]
J[0][1] += (j1*b1*z1 + 4*j2*b2*z2 + j3*b3*z3) * dz/6 [axial-curvature]
J[0][2] += (k1*b1*s1 + 4*k2*b2*s2 + k3*b3*s3) * dz/6 [axial-shear]
J[1][0] += ... (moment-axial)
J[1][1] += ... (moment-curvature, with second-order correction terms)
J[1][2] += ... (moment-shear)
J[2][0] += (m1*b1 + 4*m2*b2 + m3*b3) * dz/6          [shear-axial]
J[2][1] += ...                                          [shear-curvature]
J[2][2] += (n1*b1*s1 + 4*n2*b2*s2 + n3*b3*s3) * dz/6 [shear-shear]
```

where `b` = layer width, `z` = depth, `s` = shear strain shape multiplier,
`j,k,m,n` = terms from Ki'.

Include longitudinal steel stiffness with the same virtual strain concept.

### 5.3 Virtual strain and shear stress profile (§6-6)

Solve for virtual strain `[de0, dphi, dgamma_avg]` from:

```
J * [de0, dphi, dgamma_avg]^T = [0, V*1m, 0]^T
```

Rate of change of shear flow at depth z:

```
dq/dz = j(z)*de0_virt + k(z)*dphi_virt*z   (+ contribution from virtual gamma and steel)
```

Integrate `dq/dz` over depth to get shear flow `q(z)`.  
Divide by local width: `tau(z) = q(z) / b(z)`.

**Boundary condition:** `tau = 0` at top and bottom faces.  
**Failure mode:** method fails only if `det(J) = 0` (full-depth cracking + all steel yielded).

### 5.4 Shear strain profile

The shear strain profile has shape function with average = 1.0 and zero at top/bottom.  
Initial estimate (first load step): elastic parabola with maximum = 1.5 (rectangular section).  
Subsequent steps: use converged profile from previous load step.  
Convert shear stress profile to shear strain profile using secant stiffness at each node.

---

## 6. Solver — Nested Iteration Loops (`solver.py`)

Four nested loops (Fig. 7-1), outer to inner:

### Loop 1: Idle-Dual (shear strain profile iteration)
- **Input:** assumed shear strain profile
- **Action:** call Solve-Beam, then recalculate profile via longitudinal stiffness method
- **Convergence:** profile shape changes < tolerance
- **Drive variable:** curvature phi (strain-controlled increment)

### Loop 2: Solve-Beam (global strain state)
- **Input:** target load ratios (N:M:V)
- **State:** `(e_x0, phi, gamma_avg)` — centroid strain, curvature, average shear strain
- **Method:** tangent stiffness update via J matrix to minimise load error
- **Calls:** get-forces

### Loop 3: Get-Forces (sectional force integration)
- **Input:** global strain state `(e_x0, phi, gamma_avg)` + shear strain profile
- **Action:** for each layer, compute `(ex, gamma_xy)` from global state + profile
- **Inner call:** transverse equilibrium (secant) to find `ey` such that `Ny_node = 0`
- **Dynamic layering:** binary tree subdivision on interpolation error check
- **Output:** `(N, M, V)` integrated over all layers

### Loop 4: Transverse equilibrium (Membrane-2000 equivalent)
- **Input:** `(ex, gamma_xy)` at a single node, with `ey` as unknown
- **Method:** secant stiffness iteration on `ey` until `fy_total = 0`
- **This is the MCFT inner loop** (calls `mcft.py` on each iteration)

### Load stepping

- Drive variable: curvature `phi`, incremented in small steps
- Automatic step size control (reduce if convergence is slow)
- Track: `(N, M, V, phi, gamma_avg)` at each converged load step
- Failure detection: when solution fails to converge at reduced step size, last converged state = capacity

---

## 7. Member Response (§7-7)

For load-deflection output (optional, v1):

1. Compute full M-V interaction diagram (grid of solved states).
2. Divide beam into 20 segments; for each segment, determine (M, V) from applied loading.
3. Interpolate curvature and shear strain from interaction diagram using FE shape functions.
4. Integrate curvature with moment-area method to get deflection.
5. Apply "active shear zone" clipping: shear set to zero within distance `d` of supports/loads.

---

## 8. Long-Term Effects (§7-4) — v2 only

Shrinkage:
```
shrink = -0.000051 * k_s * k_h * t / (t + 35)
```

Creep factor, strand relaxation: per CEB-FIP MC90 provisions.

---

## 9. Input/Output (`io.py`)

### Primary input format: XML (.rsp)

The actual R2000 file format (v1.9.6+) is XML with DOCTYPE `suite_3g`. The `.r2t` text
format described in the thesis Appendix A is a legacy v0.8 format; support it as secondary.

**Top-level structure:**

```xml
<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<!DOCTYPE suite_3g SYSTEM "r3g.dtd">
<document>
  <r3g_beam name="..." doneby="..." date="...">
    <!-- materials, section, reinforcement, loading for one cross-section -->
  </r3g_beam>
  <!-- more r3g_beam elements for additional sections -->
  <R2010_Analysis length="..." topplatesize="..." displocate="...">
    <!-- member-level analysis: BMD, supports, section zone assignments -->
  </R2010_Analysis>
</document>
```

**Concrete material:**
```xml
<concrete fcp="56.9" maxagg="10.0" c_mod="2" c_soft="0" ft="2.20" name="Concrete" />
<!-- c_mod: 0=linear, 1=parabolic, 2=Popovics, 4=segmental (user curve) -->
<!-- c_soft: 0=default MCFT, 5=?? (additional variants in software, to be resolved) -->
<!-- Segmental model: strain-stress pairs as text content inside element -->
<concrete fcp="66.0" c_mod="4" name="confined">
  0.000  0.00
  0.098  3.12
  ...
</concrete>
```

**Rebar material:**
```xml
<rebar fy="400.0" fu="640.0" esh="20.0" eu="100.0" name="Steel" />
<!-- E defaults to 200000 MPa if omitted -->
```

**Prestress material (Ramberg-Osgood):**
```xml
<prestress fu="1843.3" E="190000" A="0.030" B="121.0" C="6.0" eu="40.0" name="P-Steel" />
```

**Section geometry:**
```xml
<sectionSOLID>
  900.0  900.0
  750.0  900.0  "Concrete"
  750.0  173.0
  225.0  175.0  "Concrete"
  150.0  450.0  "confined"
  0.0    450.0  "confined"
</sectionSOLID>
```
Each line: `depth  width  ["concrete_type_name"]`. Type name on the line where it changes.
Depths are from bottom of section (mm). Where type name is absent, previous type continues.

**Longitudinal reinforcement:**
```xml
<longreinfx z="50.0" type="Steel" num="4" A="200.0" Ai="50.0" db="8.0"
            dep="0.0" drape="0.0" bartitle="8M" name="label" />
<!-- z: depth from bottom (mm) -->
<!-- A: total area (mm²), Ai: individual bar area, db: bar diameter -->
<!-- dep: prestrain delta-epsilon-p (x1e-3), for prestressed only -->
<!-- drape: tendon slope (rise/run), for draped prestress tendons -->
```

**Transverse reinforcement:**
```xml
<transreinfz A="100.0" type="8M" pattern="3" space="145.0"
             disttop="870.0" distbot="30.0" Ai="50.0" db="8.0" name="web" />
<!-- pattern: 0=single leg, 1=open stirrup, 2=closed stirrup, 3=hoop -->
<!-- disttop/distbot: extent of stirrup zone from bottom (mm) -->
<!-- A: total area of all legs (mm²) -->
```

**Sectional loading (load ratios for single-section analysis):**
```xml
<sectloading MM="-1100.0" MV="775.0" />
<!-- MM: moment component, MV: shear component (ratio, not absolute) -->
<!-- If only MM given: pure moment/flexure analysis -->
```

**Member-level analysis (R2010_Analysis):**
```xml
<R2010_Analysis length="11000" topplatesize="200" displocate="570.0">
  <BMD>
    <!-- depth_mm  moment_kNm  flag -->
    570.0    0.000   0
    2820.0  -1687.5  1
  </BMD>
  <BMD isconstant="1" type="dead">
    <!-- permanent/dead load BMD as separate block -->
  </BMD>
  <mattypes>
    <!-- position_mm  "section_name" — assigns r3g_beam to zones along beam -->
    0.0      "CM6: Panel A"
    2820.0   "CM6: Panel B"
    4750.0   "CM6: Panel C"
  </mattypes>
  <supports which="left"  platesize="200.0" platelocate="2820.0" support="pin" />
  <supports which="right" platesize="200.0" platelocate="10320.0" />
</R2010_Analysis>
```

### Legacy text input format (.r2t, §5-12)

Full format documented in thesis Appendix A §5-12. Key blocks:

```
INPUT-LABEL  <id>
UNITS  METRIC | USCUSTOMARY | OLDMETRIC
MATERIAL CONCRETE <name>
  FCP <f_c' MPa>
  [FT <f_t MPa>]
  [EO <e_c' x1e-3>]
  [TSFACTOR <0-1>]
  [MAXAGG <mm>]
  [C_MOD <0|1|2>]    // 0=linear, 1=parabolic, 2=Popovics
  [T_STIFF <0..n>]   // tension stiffening model selector
ENDMAT
MATERIAL REBAR <name>
  EY <f_y MPa>
  [E <E_s MPa>]
  [FU <f_u MPa>]
  [ESH <e_sh x1e-3>]
  [EU <e_u x1e-3>]
ENDMAT
MATERIAL PRESTRESS <name>
  FU <f_pu MPa>
  [E <E_p MPa>]
  [A, B, C  <Ramberg-Osgood params>]
ENDMAT
SECTION SOLID
  <depth> <width> <concrete_type>   // from bottom, as many pairs as needed
ENDSECTION
LONGREINF <name>
  Z <depth from bottom mm>
  A <area mm²>
  TYPE <material_name>
  [NUM <n_bars>]  [AI <bar_area>]  [DB <bar_diam>]
ENDLONG
TRANSREINF <name>
  A <total area all legs mm²>
  TYPE <material_name>
  PATTERN <0=single|1=open|2=closed|3=hoop>
  SPACE <spacing mm>
  [DISTTOP <mm>]  [DISTBOT <mm>]
  [DB <bar_diam>]
ENDTRANS
LOADING
  [CONSTANT  <N>  <M>  <V>]
  VARIABLE   <N>  <M>  <V>   // ratios; at least one non-zero
ENDLOAD
ANALYSIS
  TYPECODE <type> [params]
  // 1=full response, 2=one load, 5=M-N interaction, 6=M-V interaction
ENDANALYSIS
ENDINPUT
```

### Additional XML schema elements (from real case files)

**`eleminfo`** — single-section member geometry (used when no `R2010_Analysis` block):
```xml
<eleminfo L="2230.0" mido2="0.0" lplate="0.0" rplate="0.0" />
<!-- L: shear span (mm), mido2: constant moment zone half-length (mm) -->
<!-- lplate/rplate: bearing plate sizes at left/right supports (mm) -->
```

**`shapesection`** — named predefined section shape (appears alongside `sectionSOLID`):
```xml
<shapesection name="RECT" par1="295.0" par2="1000.0" par3="0.0" ... />
<!-- name: shape type from shapes.dat (RECT, INTER, etc.) -->
<!-- par1..par6: shape parameters (width, height, etc., shape-dependent) -->
<!-- Parser should read sectionSOLID geometry; shapesection is display metadata only -->
```

**`sectloading` extended attributes:**
```xml
<sectloading BN="-804.0" BM="0.0" MM="0.7" MV="1.0" />
<!-- BN: constant baseline axial force (kN, applied before variable load path) -->
<!-- BM: constant baseline moment (kN·m) -->
<!-- MM, MV: variable load ratios (moment:shear) -->
<!-- Empty sectloading element is valid: <sectloading /> means no load defined -->
```

**`shrinktherm`** — initial shrinkage/thermal strain profile:
```xml
<shrinktherm>
  500.0  -0.690
    0.0  -0.690
</shrinktherm>
<!-- depth(mm)  strain(x1e-3) pairs, from top to bottom -->
```

**`e0` on concrete** — direct override of strain at peak stress:
```xml
<concrete fcp="65.2" e0="2.10" maxagg="5.0" />
<!-- e0: strain at peak stress x1e-3, overrides calculated value -->
```

**`space` on `longreinfx`** — bar spacing within layer (mm), used for crack spacing `m` parameter:
```xml
<longreinfx z="33.0" type="15M" space="100.0" num="6" A="1200.0" ... />
```

**`AxialLoad` on `BMD`** — constant axial load for that load case:
```xml
<BMD isconstant="1" AxialLoad="-804.0" type="dead"> ... </BMD>
```

**`pattern=7` on `transreinfz`** — unknown type (T-headed bars or similar). Not in thesis.
Treat as: log warning, fall back to open stirrup (`pattern=1`) behaviour for now.

**`leftanchor` / `rightanchor` on `R2010_Analysis`**:
```xml
<R2010_Analysis length="5000" leftanchor="straightbar" rightanchor="straightbar">
<!-- anchorage condition at beam ends, affects longitudinal steel stress -->
```

**`support` types on `<supports>`:**
```xml
<supports which="right" platelocate="2110.0" support="fixedverticalroller" />
<!-- Known values: "pin", "fixedverticalroller" -->
<!-- fixedverticalroller: vertical reaction only, free horizontal and rotation -->
<!-- (models elastomeric bearing pad) -->
<!-- Default (attribute absent): roller support -->
```

---

### Binary format (.rsp, pre-2011) — v2 only

Files with header `"Response for Windows file v0.8"` are the older binary format used
by Response-2000 prior to the XML migration (~2011). These include real project files
such as the Super-T girder series, pier crosshead assessments, and older PSC cases.

The binary format stores data as IEEE 754 doubles packed in fixed-width struct records,
with null-terminated strings in fixed-length fields. It is not documented in the thesis.
Reverse-engineering is feasible but not a v1 priority.

**Workaround for existing binary files:** open in R2000 v1.9.6+ and re-save; the
program will write the XML format. All binary files in the validation set should be
converted this way before use.

---

### Output

Minimum for v1: Python objects / pandas DataFrames with:
- Per load step: `phi, gamma, N, M, V, e_x0`
- Per layer at each step: `ex, ey, gamma_xy, e1, e2, theta, f1, f2, f_sx, f_sy, w, tau`
- Failure mode flag and governing mechanism (crack check / compression softening / steel yield / longitudinal yield)

---

## 10. Validation Plan

Five canonical cases, all in XML format. Convert any binary files in R2000 first.

| Priority | File | Section | Key features | Purpose |
|----------|------|---------|--------------|---------|
| 1 | `dm-n1n.rsp` | 375×750 mm rect, NSC 36 MPa | Standard rebar, closed stirrups, M:V=1.5 | Core MCFT, tension stiffening, crack check. Simplest possible case. |
| 2 | `Marshall.rsp` "Both" | 305×610 mm rect, NSC 44 MPa | Asymmetric top/bottom steel, hoops | Symmetric then asymmetric section response |
| 3 | `se100am69.rsp` "4 bars" | 295×1000 mm rect, HSC 75 MPa | `c_mod=1`, sparse stirrups | HSC compression softening transition branch |
| 4 | `dm-n1n.rsp` full member | As above + `R2010_Analysis` | Simple symmetric BMD | Member-level shear zone clipping |
| 5 | `Liping_LB1.rsp` "V_ult=137 kN" | I-section, axial load, prestress | `BN=-804 kN`, M:V=0.7:1 | Axial + shear + prestress interaction |
| 6 | `Super-T1.r2t` through `Super-T5.r2t` | Super-T girder, 5 depths 930–1980mm | HSC 65 MPa, `c_soft=2`, no stirrups, 3×25M | Size effect in shear: all 5 should show decreasing shear stress at failure with depth. Strong validation of poorly-reinforced tension stiffening model. |

For each: run full response in R2000 and export via right-click > Copy Chart Data:
- V vs. midspan deflection (or V vs. curvature for sectional cases)
- Shear stress profile at ~50%, ~80%, ~100% of capacity
- Longitudinal strain profile at same levels
- Layer-by-layer state at peak load

Save as CSVs alongside the `.rsp` files. These are the regression targets.

---

## 11. Known Uncertainties / Items to Resolve

1. **Convergence tolerances:** thesis gives no explicit values. Start with 1e-4 on
   normalised force error; tune empirically against R2000 output.

2. **Tension stiffening model selector** (`T_STIFF`): multiple models in software.
   Implement Bentz 3.6m first. Add Vecchio 1982 and Collins-Mitchell 1987 as
   selectable alternatives for cross-checking.

3. **Transverse equilibrium solver:** starting point and relaxation not specified.
   Start: `ey = -nu*ex` (Poisson, uncracked); secant update, under-relaxation 0.5.

4. **Dynamic layering tolerance:** not stated. Initial target: quadratic interpolation
   error < 5% of peak stress in layer.

5. **Load step size:** not specified. Start `d_phi = phi_yield / 50`; auto-halve on
   non-convergence up to 5 halvings before declaring failure.

6. **`c_soft` integer codes:** values 0, 2, and 5 seen in files. Thesis only describes
   NSC/HSC variants. Additional codes likely post-thesis additions. `c_soft=2` appears
   in all Super-T cases (65 MPa HSC with 14–19mm aggregate). Resolve by running cases
   with each value in R2000 and observing behaviour change.

7. **`pattern=7` transverse reinforcement:** unknown type. Log warning, treat as
   open stirrup until clarified.

8. **`leftanchor` / `rightanchor`:** effect on longitudinal steel curtailment not
   documented. Observe R2000 output with and without; defer to Bentz if unclear.

9. **Interaction with Evan Bentz:** flag all items above for resolution at 95% stage.

---

## 12. Deferred (v2+)

- Time-dependent effects (§7-4): shrinkage, creep, relaxation
- Young concrete strength adjustment (§5-6)
- Strain discontinuity for composite construction (§5-7)
- Binary .rsp format reader (pre-2011 files)
- Membrane-2000, Triax-2000, Shell-2000 equivalents
- Column pushover / yield penetration (§7-8)
- M-V interaction diagram computation
- Member load-deflection integration (§7-7)
- DSFM elements
- C++ pybind11 backend (profile first)
- Qt/PySide6 desktop GUI
- Segmental concrete model (`c_mod=4`) with user-defined stress-strain curve
