# R2K Design Decisions: What We Know

A catalogue of specific implementation choices in Response-2000, determined
through reverse engineering via synthetic test cases. Each entry documents
what R2K does, how we discovered it, and whether we reproduce it.

---

## 1. Cracking Strength

**R2K**: ft = 0.45 × √fcp

**How discovered**: A-series unreinforced sections. Cracking moment
M_cr = ft × bh²/6. Our A3–A6 cases match R2K to 0.003% with this formula.
Alternatives tested: 0.33×√fcp (ACI), 0.45×fcp^0.4 (Collins & Mitchell) —
both fail to match.

**Status**: ✅ Reproduced

---

## 2. Concrete Compression Model

**R2K**: XML `c_mod=2` = Thorenfeldt/Popovics (labelled "Parabolic" in R2K)

**How discovered**: A2 and B2 series. The XML code maps directly to our
internal code (no offset). A previous -1 offset broke Marshall validation
by 47%.

**Status**: ✅ Reproduced

---

## 3. Compression Softening

**R2K**: XML `c_soft=18` = Collins-Bentz 2011 (internal code 1).
Formula: β = 1/(0.8 + 0.34·ε₁/ε₀).

**How discovered**: B2 vs B4 comparison. Collins & Mitchell 1987 p.740 has a
**typo** in this formula (0.8 - 0.34 instead of +). Confirmed by Aquino &
Erdem 2007 who also had the wrong sign.

**Status**: ✅ Reproduced

---

## 4. Outer-Fiber Cracking Detection

**R2K**: Checks cracking at the **outer face** of each layer (z_bot for
tensile layers), not the centroid.

**How discovered**: A-series cracking moment timing. With centroid-based
detection, the peak moment step shifts. Outer-fiber detection makes step 50
(φ = φ_cr) be the peak, matching R2K.

**Status**: ✅ Reproduced

---

## 5. Layering: 30 Uniform Midpoint Layers

**R2K**: Default 30 layers with midpoint integration rule.

**How discovered**: A-series moment of inertia comparison. Midpoint rule with
n=30 gives I/I_exact ≈ 0.99889, matching R2K's slight M_cr underestimate.

**Status**: ✅ Reproduced (but staged analysis uses R2K's dynamic layers)

---

## 6. Tension Stiffening at Reinforced Layers (Eq 5-8)

**R2K**: f1 = ft / (1 + sqrt(3.6·m·e1)) at layers where rebar crosses the crack.

**How discovered**: B4i reinforced layer comparison. With m = bond parameter =
Ac/Σ(πdb), computed using zone_depth ≈ 143mm (= 0.35 × s_m_bar).

**Nuance**: R2K's actual response at the reinforced layer follows e1^0.42,
not sqrt(e1) = e1^0.50. The implied m decreases from 782 to 417 across a
50× strain increase. This may be an R2K evolution beyond Bentz's thesis.

**Status**: ⚠️ Partially reproduced (sqrt formula matches at low strains,
diverges at high strains)

---

## 7. Tension Stiffening at Unreinforced Layers (Eq 5-9)

**R2K**: Maintains non-zero f1 at cracked unreinforced layers. The f1 profile
decays with distance from the nearest bar, reaching zero at ~0.625 × s_m_bar.

**How discovered**: H4i pure axial test case. The f1(depth) profile shows a
characteristic shoulder shape: flat near the bar, steep decay near the
boundary, then a sharp cutoff.

**Bentz thesis**: Eq 5-9 with Fig 5-13 decay function:
val = clamp(1/(8·d/s_m) - 0.2, 0, 1), applied to M under a power.

**R2K also has "Restriction 3"** (thesis p.55): "If there are no bars crossing
the crack face, the concrete stress is not reduced." This maintains a small
residual f1 (≈0.013 MPa) even beyond the bond zone — an admitted equilibrium
violation for stability.

**Status**: ⚠️ Implemented with Eq 5-9 (power 0.35). Matches H4i profile
shape. B4i cracking transition overshoots (r15 ≈ 1.3).

---

## 8. Crack Check at Unreinforced Layers

**R2K**: Does NOT apply the crack check (local equilibrium at crack surface)
at layers with no reinforcement. These layers keep whatever f1 the tension
stiffening model gives.

**How discovered**: B4i layer comparison. Applying the crack check at
unreinforced layers would set f1 = 0 (no rebar to carry tension across crack).
R2K's non-zero f1 at these layers confirms the crack check is skipped.

**Status**: ✅ Reproduced (crack check skipped when rho_x = rho_y = 0)

---

## 9. Crack Spacing Formula

**R2K**: CEB model: s_x = 2c + 0.1·db/ρ, where c = diagonal distance to
nearest bar, ρ = steel ratio within 7.5·db zone.

**How discovered**: H4i bond zone boundary position. Our s_m_bar = 409mm gives
bond zone at 0.625 × 409 = 256mm. R2K shows boundary at ~261mm (2% match).

**Key**: Crack spacing varies with depth (increases further from bar), which
determines the bond zone extent and the decay rate through the depth.

**Status**: ✅ Reproduced

---

## 10. Shear Stress Profile (Longitudinal Stiffness Method)

**R2K**: Uses J matrix (Bentz Ch.6, Eq 6-6) to compute shear stress profile.
J is used for the shear PROFILE (Idle-Dual loop), NOT as the Newton Jacobian
for Solve-Beam.

**How discovered**: Attempted J-based Newton → diverged. The J matrix
linearises without re-solving transverse equilibrium, creating a mismatch
with _get_forces. FD Newton works.

**Key**: J[2][0] and J[2][1] have NO s factor; J[2][2] has ONE s factor.
An earlier bug had extra s factors that silently corrupted the shear profile.

**Status**: ✅ Reproduced

---

## 11. Solve-Beam Newton Method

**R2K**: Uses "tangent technique" (thesis p.92) but never specifies the
exact update formula. Our implementation uses finite-difference Newton:
Phase A (e0 for N=target), Phase B (γ for V=M/av).

**How discovered**: Multiple attempts at J-based Newton all failed. The
analytical tangent from K'i doesn't match the full nonlinear _get_forces
response (which includes crack check, compression softening, transverse
equilibrium re-iteration).

**Status**: ✅ FD Newton works. Exact R2K method unknown.

---

## 12. Load Stepping and Control

**R2K**: Curvature-controlled stepping. For axial loading, uses MN (axial
increment) parameter. Analysis produces 50-100 load stages with adaptive
refinement near cracking.

**R2K quirk**: "Waiting for the tide to turn" dialog on first solve of some
sections — likely an Easter egg from Evan Bentz.

**R2K quirk**: The `.rsp` `Ai` field in `longreinfx` is NOT individual bar
area. R2K uses it for positioning and recomputes total area `A` on save.

**Status**: ⚠️ Our solver uses fixed φ stepping. Staged analysis follows
R2K's prescribed stages.

---

## Decisions Still Under Investigation

### Bond Parameter m Computation
Our zone_depth = 143mm matches H4i but may not generalise. Need to verify
with H4i-bigbar (db=25) and different section geometries.

### Strain Exponent in Tension Stiffening
R2K appears to use e1^0.42 rather than Bentz's published sqrt(e1).
This is a second-order effect for bending but significant for axial.

### Bond Zone Interaction
When multiple bars have overlapping bond zones, R2K shows nearly uniform f1.
Our nearest-bar approach may need superposition for doubly-reinforced sections.

### Dynamic Crack Spacing
R2K may update crack spacing as secondary cracks form during loading.
This would explain the strain-dependent implied m.
