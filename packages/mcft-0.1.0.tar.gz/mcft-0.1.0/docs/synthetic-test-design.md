# Synthetic Test Case Design

## Philosophy

Each test case isolates ONE variable while holding everything else constant.
When a discrepancy is found, we know exactly which R2K design decision causes
it. This is achieved through a matrix of section geometry × material model ×
steel model, where each axis varies independently.

---

## File Naming Convention

```
synth_{Section}{Material}{Steel}.rsp
```

Examples:
- `synth_A3.rsp` — Unreinforced rect, elastic-brittle concrete
- `synth_B4i.rsp` — Singly reinforced, tension stiffening, elastic steel
- `synth_H4i.rsp` — Centroidal bar axial, tension stiffening, elastic steel
- `synth_H4i_deep.rsp` — Deep variant of H4i (1500mm height)

R2K extraction results: `results/synth/{stem}_r2k.json`

---

## Section Axis Details

### A: Unreinforced Rectangle (375×750mm)

**Purpose**: Validate basic section mechanics — elastic modulus, cracking
strength, moment of inertia, outer-fiber cracking detection.

**What it tests**:
- Cracking moment = ft × bh²/6
- Layer discretisation accuracy (midpoint rule, n=30)
- Sign conventions (positive M = sagging)

**Key result**: M_cr matches R2K to 0.003% with ft = 0.45√fcp.

### B: Singly Reinforced Rectangle (375×750mm, bar at z=65mm)

**Purpose**: Introduce tension stiffening at ONE bar location.

**What it tests**:
- Eq 5-8 tension stiffening at the reinforced layer
- Eq 5-9 depth-varying tension stiffening at unreinforced layers
- Crack check interaction with tension stiffening
- Compression model (via B2/B3 material axis)

**Key result**: B2i/B3i match within 1%. B4i overshoots at cracking
transition due to Eq 5-9 onset.

**Test progression** (material axis):
1. B1i (linear elastic) — section stiffness only
2. B2i (Popovics, no TS) — compression model
3. B3i (Popovics, brittle tension) — cracking without stiffening
4. B4i (Popovics + TS) — **tension stiffening in isolation**
5. B6i (full model) — all effects combined

### H: Axial Tension (Pure Bond Zone Calibration)

**Purpose**: Eliminate bending completely. Uniform strain at all layers.
The ONLY f1 variation through the depth comes from the bond zone effect.

**What it tests**:
- Eq 5-9 decay function shape
- Bond zone extent (0.625 × s_m_bar)
- Crack spacing dependence (via bar diameter variation)
- Bond zone interaction (via symmetric double bar)

**Variants**:

| Variant | Section | Bar | db | Purpose |
|---------|---------|-----|----|---------|
| H4i | 375×750 | centroid | 11mm | Baseline |
| H4i-deep | 375×1500 | centroid | 11mm | Confirm zone is local, not section-dependent |
| H4i-bigbar | 375×750 | centroid | 25mm | Confirm zone scales with s_m_bar |
| H4i-sym | 375×750 | 2 bars symmetric | 11mm | Test zone superposition |

**Loading**: MN = 1.0 (axial increment), MM = 0.0.
Member length: 1000–2000mm.

### C–G: Increasing Complexity (Future)

Each builds on the previous validated series:

- **C** (doubly reinforced): bond zone superposition in bending
- **D** (stirrups): transverse reinforcement, shear capacity
- **F** (moderate shear): M/V interaction, shear profile
- **G** (high shear): aggregate interlock, diagonal compression

---

## Material Axis Details

### Material 1: Linear Elastic

`fcp=200, c_mod=1, c_soft=1, ft=0.001, tsfactor=0.0`

Very high fcp with linear model — effectively linear elastic with negligible
cracking. Tests pure geometry and integration.

### Material 2: Popovics, No Tension

`fcp=36, c_mod=2, c_soft=1, ft=0.001, tsfactor=0.0`

Popovics/Thorenfeldt compression curve with negligible tension. Tests the
compression constitutive model in isolation.

### Material 3: Elastic-Brittle

`fcp=36, c_mod=2, c_soft=1, ft=auto, tsfactor=0.0`

Normal cracking strength but NO tension stiffening. After cracking, f1 → 0.
Tests cracking detection and brittle tension behaviour.

### Material 4: Tension Stiffening (Key for B4/H4)

`fcp=36, c_mod=2, c_soft=1, ft=auto, tsfactor=1.0`

**This is the key material for isolating tension stiffening.** No compression
softening (c_soft=1 = None), so the ONLY post-cracking effect is tension
stiffening. Any discrepancy with R2K is purely from the TS model.

### Material 5: Plus Softening

`fcp=36, c_mod=2, c_soft=18, ft=auto, tsfactor=1.0`

Adds Collins-Bentz 2011 compression softening to Material 4. Tests the
interaction between tension stiffening and compression softening.

### Material 6: Full R2K Default

`fcp=36, c_mod=2, c_soft=18, ft=auto, tsfactor=1.0`

Same as Material 5 (R2K default settings). Used as the "real-world" check.

---

## R2K Data Extraction Protocol

### Per-Case Extraction

```bash
# Single case, all stages, all key profiles:
python tools/r2k_extract.py tools/synth_B4i.rsp \
    --full --max-stages 0 \
    -o results/synth/synth_B4i_r2k.json

# Batch extraction:
python tools/r2k_extract.py --batch 'tools/synth_B*.rsp' --full
```

### Important Notes

1. **Xvfb isolation**: extraction runs on virtual display by default.
   Use `--no-xvfb` only for debugging.

2. **Dual-trace profiles**: "Principal Tensile Stress" and "Principal
   Compressive Stress" have two traces (actual + capacity). Use first half only.

3. **Axial cases**: the "moment" control curve shows axial force (kN).

4. **R2K .rsp saves**: opening and saving in R2K may change field values
   (e.g., `Ai` recomputes `A`). Always verify bar areas after R2K save.

5. **Member length**: R2K requires R2010_Analysis block with member length.
   Files without this block show a "Full Member Properties" dialog that
   blocks automation.

---

## Validation Comparison Workflow

1. **Generate .rsp** via `tools/gen_synth_tests.py` or manually
2. **Open in R2K**, set member length/supports, solve, save
3. **Extract** via `tools/r2k_extract.py --full --max-stages 0`
4. **Run staged analysis**: `analyse_section_staged(beam, r2k_stages)`
5. **Compare layer-by-layer**: per-depth f1, ex, e1 at each stage
6. **Identify discrepancy**: which layers, which stages, which quantity
7. **Isolate cause**: change one parameter and re-test
8. **Fix and back-test**: verify all simpler series still pass
