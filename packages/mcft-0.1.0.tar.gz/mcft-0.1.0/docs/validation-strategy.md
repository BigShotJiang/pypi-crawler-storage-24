# MCFT Validation Strategy

## Objective

Reproduce the sectional analysis results of Response-2000 (R2K) — the research
standard implementation of the Modified Compression Field Theory by Evan Bentz
(PhD thesis, University of Toronto, 2000).

R2K is a closed-source Windows application. Our validation approach
reverse-engineers its behaviour through systematic test cases, isolating each
design decision encoded in the software. Once we match R2K, we can diverge on
the basis of better physics with confidence that differences are intentional.

---

## Methodology: Isolation by Synthetic Test Matrix

### Principle

Each R2K design decision (constitutive model, crack check, tension stiffening,
compression softening, etc.) is tested in isolation using synthetic `.rsp` files
where all OTHER decisions are held constant. This prevents compensating errors
from masking individual discrepancies.

### Test Matrix Axes

**Section axis (A–H)**: increasing geometric complexity

| Code | Section | Rebar | Loading | Purpose |
|------|---------|-------|---------|---------|
| A | 375×750 rect | None | Pure bending | Baseline: elastic, cracking moment |
| B | 375×750 rect | Single bottom bar | Pure bending | Tension stiffening, bond zone |
| C | 375×750 rect | Top + bottom bars | Pure bending | Doubly reinforced interaction |
| D | 375×750 rect | Bottom bar + stirrups | Pure bending | Transverse reinforcement effect |
| F | 375×750 rect | Bottom bar + stirrups | M/V = 1.5m | Shear + bending |
| G | 375×750 rect | Bottom bar + stirrups | M/V = 0.5m | High shear |
| H | 375×750 rect | Centroidal bar | Pure axial | Bond zone calibration |

**Material axis (1–6)**: incremental constitutive model activation

| Code | Concrete | Compression softening | Tension stiffening | Purpose |
|------|----------|----------------------|-------------------|---------|
| 1 | Linear elastic | None | None | Pure geometry check |
| 2 | Popovics | None | None | Compression model only |
| 3 | Popovics | None | Brittle (f1→0) | Cracking without TS |
| 4 | Popovics | None | Bentz 1999 | **Tension stiffening isolation** |
| 5 | Popovics | Collins-Bentz 2011 | Bentz 1999 | + compression softening |
| 6 | Popovics | Collins-Bentz 2011 | Bentz 1999 | Full model (R2K default) |

**Steel axis (i–iii)**: rebar constitutive model

| Code | fy (MPa) | fu (MPa) | Purpose |
|------|----------|----------|---------|
| i | 10000 | 12000 | Elastic (no yielding) — isolate concrete |
| ii | 400 | 400 | Elastic-perfectly-plastic |
| iii | 400 | 600 | Trilinear with hardening |

### Back-Testing Rule

When working on series N, only validate against series ≤ N:
- Working on B → check A and B only
- Working on D → check A, B, C, D only

More complex cases have additional unresolved issues. Testing against them
adds noise and false negatives. This rule prevents chasing phantoms.

---

## H-Series: Bond Zone Calibration

### Rationale

The B-series showed a 30% moment deficit at the cracking transition (B4i
ratio = 0.705 at stage 15). Investigation revealed that R2K maintains non-zero
f1 at cracked unreinforced layers — our solver was setting f1 = 0.

To calibrate the tension stiffening decay away from reinforcement, we created
the H-series: pure axial tension with controlled bar placement. This eliminates
bending complications (no cracking front, no neutral axis movement, uniform
strain) and isolates the bond zone effect.

### H-Series Test Cases

| Case | Section | Bar position | Bar area | db | Purpose |
|------|---------|-------------|----------|------|---------|
| H4i | 375×750 | z=375 (centroid) | 2000mm² | 11mm | Baseline bond zone |
| H4i-deep | 375×1500 | z=750 (centroid) | 400mm² | 11mm | Confirm zone is local |
| H4i-bigbar | 375×750 | z=375 (centroid) | 400mm² | 25mm | Test s_m_bar scaling |
| H4i-sym | 375×750 | z=187.5, z=562.5 | 200mm² each | 11mm | Bond zone interaction |

All use material 4 (Popovics, no compression softening, tension stiffening on)
and elastic steel (fy = 10000 MPa, no yielding).

### Key Findings from H4i

1. **Bond zone is local**: extends ~0.625 × s_m_bar from the bar (~255mm for
   H4i), independent of section depth (confirmed by H4i-deep)

2. **f1 profile shape**: characteristic "shoulder" — flat near bar (f1 ≈ f1_bar),
   then steepening decay, then sharp cutoff at the bond zone boundary

3. **R2K's "Restriction 3"** (Bentz thesis p.55): R2K intentionally does NOT
   set f1 = 0 at unreinforced layers. This is an admitted equilibrium violation
   for computational stability. The residual f1 ≈ 0.013 MPa in the far field
   is this stability hack, not real tension stiffening.

4. **Strain-dependent effective m**: R2K's implied bond parameter at the bar
   decreases with strain (m = 782 at e1 = 0.63‰ → 417 at e1 = 32‰). Analysis
   shows this is because R2K's response follows e1^0.42, not sqrt(e1) = e1^0.50.
   Fitting f1 = ft/(1 + 28.9·e1^0.4245) gives 5.2% max error across all strains.

5. **Overlapping bond zones** (H4i-sym): when bars are close enough that their
   bond zones overlap, f1 is nearly uniform between them. The zones superpose.

### Bentz Eq 5-9: Through-Depth Tension Stiffening

Bentz thesis Chapter 5, Fig 5-13/5-15 describes tension stiffening variation
through the section depth:

```
f1 = ft / (1 + sqrt(M_eff · e1))
M_eff = 3.6 · m_bar / val^p
val = clamp(1/(8 · d_bar/s_m_bar) - 0.2, 0, 1)
```

Where:
- `d_bar` = distance from nearest reinforcing bar (mm)
- `s_m_bar` = crack spacing at the bar location (mm)
- `m_bar` = bond parameter at the bar location
- `val` = decay factor from Fig 5-13 fit, capped to [0, 1]
- `p` = power (Bentz thesis: 0.5; calibrated to R2K: 0.35)

The decay function gives:
- val = 1.0 for d_bar/s_m ≤ 0.104 (flat shoulder near bar)
- val = 0.0 for d_bar/s_m ≥ 0.625 (bond zone boundary)
- Smooth decay between

### Bond Parameter Computation

The bond parameter `m = Ac / Σ(π·db)` depends on the effective concrete area
`Ac` around the bars. Our `bond_parameter()` function uses a `zone_depth`
parameter:

```
Ac = width × min(2 × zone_depth, section_height)
```

R2K's implied m at the H4i bar = 782, achieved with zone_depth = 143mm
(≈ 0.35 × s_m_bar). The default was 100mm.

### Crack Spacing Formula

CEB model (Bentz Eq 7-6):
```
s_x = 2c + 0.1 · db / ρ
```
Where c = diagonal distance to nearest bar, ρ = steel ratio within 7.5·db zone.

For H4i (centroidal bar, db=11): s_m_bar ≈ 409mm, giving bond zone extent
of 0.625 × 409 = 256mm. R2K shows the boundary at ~261mm. Close match.

---

## R2K Extraction Infrastructure

### Automation Tool

`tools/r2k_extract.py` automates R2K via Wine + xdotool:

1. Launches R2K with an `.rsp` file
2. Runs Sectional Response analysis
3. Extracts control curves (M-φ, V-γ, or N-ε)
4. Optionally extracts cross-section profiles at each load stage
5. Saves structured JSON output

### Xvfb Isolation (Critical)

R2K runs in a Wine virtual display (Xvfb) to prevent desktop crashes.
Previous sessions where R2K ran on the real display caused system-level
hangs requiring hard reboots.

```bash
# Normal usage (Xvfb, safe):
python tools/r2k_extract.py file.rsp --full --max-stages 0 -o output.json

# Real display (unsafe, only for debugging):
python tools/r2k_extract.py file.rsp --no-xvfb

# Calibrate coordinates via VNC:
python tools/r2k_extract.py --calibrate
# Then connect: vncviewer localhost:5901
```

Safety features:
- **Hard timeout**: 15 minutes default (--timeout)
- **atexit handler**: kills Wine + Xvfb on any exit
- **Signal handler**: catches SIGTERM/SIGINT
- **Minimum 50ms between xdotool calls** for interruptibility

### Profile Data Structure

R2K profiles for some plot types have **dual traces** (actual + capacity):
- "Principal Tensile Stress": 2× points (first half = actual f1)
- "Principal Compressive Stress": 2× points
- "Shear Strain": 3× points
- "Transverse Strain": 3× points

Always use the first trace (first n/2 or n/3 points) for actual values.

### R2K Control Curve Interpretation

The extraction tool reads the left-panel graphs as "shear" (top) and "moment"
(bottom). For axial-loaded sections, the "moment" curve actually contains
**axial force in kN**, not moment in kNm.

---

## Staged Analysis: Layer-by-Layer Matching

### Approach

`analyse_section_staged()` uses R2K's prescribed curvature (φ) and layer
positions at each load stage. This eliminates layering differences and isolates
constitutive model discrepancies.

### Requirements

1. **Always use R2K's dynamic layers** — never uniform n=30 layers
2. **Layer-by-layer comparison** — median M ratio is not sufficient
3. **Compare per-layer**: f1, f2, ex, e1, shear stress vs R2K profile data

### R2K Stage Data (JSON structure)

```
d["stages"][i]["stage"]  → control curve index
d["stages"][i]["profiles"]  → list of {title, x, y, x_label, y_label}
d["controls"]["moment"]["x"]  → phi values (mrad/m)
d["controls"]["moment"]["y"]  → M values (kNm) or N values (kN)
```

Units: phi in mrad/m, M in kNm, V in kN. Profile x = MCFT value
(strain in mm/m, stress in MPa), y = depth from centroid in mm.

---

## Current Validation Status

### A-Series (Unreinforced)

All A3–A6 cases match R2K cracking moment to 0.003%. This validates:
- Section discretisation (30 uniform midpoint layers)
- Elastic concrete modulus (Ec = 4500√fcp)
- Cracking strength (ft = 0.45√fcp)
- Outer-fiber cracking detection
- Moment integration

### B-Series (Singly Reinforced, Pure Bending)

| Case | Material | med | min | max | Notes |
|------|----------|-----|-----|-----|-------|
| B2i | Popovics + C-B softening | 1.006 | — | 1.08 | Near-perfect ✓ |
| B3i | Popovics + VC1982 | 1.005 | — | 1.05 | Near-perfect ✓ |
| B4i | Popovics + TS (no soft) | 1.022 | 0.975 | 1.31 | Cracking transition overshoot |

B2i/B3i validate the compression models. B4i isolates tension stiffening and
shows the cracking transition overshoot (r15 ≈ 1.3) driven by the abrupt onset
of Eq 5-9 at many layers simultaneously.

### H-Series (Axial, Bond Zone Calibration)

H4i matches R2K's f1 profile within ~5% at low strains (stage 0) using the
Eq 5-9 formula with power 0.35. Discrepancy grows at higher strains due to
R2K's sub-sqrt response (e1^0.42 vs e1^0.50).

---

## What NOT to Change (Validated Decisions)

These settings have been calibrated and verified against R2K:

- **ft = 0.45 × √fcp** — not 0.33 or 0.45×fcp^0.4
- **c_mod=2 → Popovics (no offset)** — XML code maps directly
- **J shear row s-factors**: J[2][0] and J[2][1] have no s; J[2][2] has one s
- **Crack check skipped at unreinforced layers** — rho_x = rho_y = 0
- **Phase A/B FD Newton** in _solve_beam — J-based Newton diverges
- **Outer-fiber cracking detection** — not centroid

---

## Known Gaps and Next Steps

1. **Eq 5-9 power calibration**: Bentz thesis uses p=0.5; R2K data fits p=0.35.
   Need to verify with H4i-bigbar (different db → different s_m_bar).

2. **Strain exponent**: R2K uses e1^0.42, not sqrt(e1). This is a second-order
   effect for bending but matters for axial. Could be an R2K evolution.

3. **Cracking transition overshoot**: B4i r15 ≈ 1.3. Many layers simultaneously
   gain Eq 5-9 tension stiffening when cracking propagates. May need cracking
   persistence (once cracked, stays cracked) or damped onset.

4. **Bond zone interaction**: When bars are close, zones overlap and f1
   becomes uniform. Current implementation uses nearest bar only — may need
   superposition for doubly-reinforced sections (C-series).

5. **R2K .rsp field parsing**: `Ai` in `longreinfx` is NOT individual bar area.
   R2K recomputes `A` from `Ai` and `num` on save, changing the total area.

6. **Axial loading in extraction tool**: Control curve for MN-loaded sections
   shows axial force (kN), not moment (kNm). Tool should detect this.
