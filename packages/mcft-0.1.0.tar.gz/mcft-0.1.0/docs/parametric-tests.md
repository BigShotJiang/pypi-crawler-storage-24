# Parametric Tests: HX and BX Series

## Purpose

Each parametric test changes ONE parameter from a validated baseline to test
whether R2K responds as our formulas predict. If the prediction is wrong,
we've found a gap in our understanding of R2K's algorithm.

**Naming**: HX = H-series cross-section variant (axial). BX = B-series variant
(bending). The suffix describes what changed.

---

## Baseline

**H4i**: 375×750mm, 4 bars db=11mm, A=2000mm², z=375 (centroid), fcp=36MPa.
- Predicted: s_m = 409mm, m = 776, bond_zone = 256mm, ft = 2.700 MPa

**B4i**: Same section, bar at z=65mm, pure bending.

---

## HX Series: Crack Spacing Sensitivity

### HX4i-narrow (width = 200mm)
- **Changes**: c to side face = 100mm (was 187.5mm)
- **Predicted**: s_m = 218mm (0.53×), bond_zone = 136mm (0.53×)
- **Tests**: Does the bond zone shrink proportionally with s_m?
- **If wrong**: c calculation in s_m formula differs from CEB

### HX4i-wide (width = 600mm)
- **Changes**: c to side face = 300mm (was 187.5mm)
- **Predicted**: s_m = 654mm (1.60×), bond_zone = 409mm (1.60×)
- **Tests**: Does the bond zone expand proportionally?
- **If wrong**: s_m may be capped or c computed differently

### HX4i-2bar (2 bars db=15.7mm, same A=2000)
- **Changes**: Σ(πdb) = 98.6 (was 138.2), individual bars larger
- **Predicted**: s_m = 444mm (1.09×), m = 1087 (1.40×)
- **Tests**: Does m scale with Σ(πdb)? Does s_m depend on db/ρ correctly?
- **If wrong**: m formula uses different Ac or perimeter calculation

### HX4i-8bar (8 bars db=7.8mm, same A=2000)
- **Changes**: Σ(πdb) = 196 (was 138.2), many small bars
- **Predicted**: s_m = 392mm (0.96×), m = 547 (0.70×)
- **Tests**: Opposite of 2bar — denser bars, lower m, more TS
- **If wrong**: Bond density scaling is nonlinear

### HX4i-bigdb_samerho (2 bars db=25.2mm, same A=2000)
- **Changes**: Much larger db, same total area, only 2 bars
- **Predicted**: s_m = 554mm (1.35×), bond_zone = 346mm (1.35×)
- **Tests**: Isolates db effect from ρ effect in s_m formula
- **Critical**: Combined with H4i-bigbar (db=25, 4 bars) this separates
  the db and num contributions

---

## HX Series: Bar Position (Asymmetry)

### HX4i-offcentre (bar at z=100)
- **Changes**: 100mm from bottom face, 650mm from top
- **Predicted**: s_m = 409mm (same c to side), bond_zone = 256mm
- **Tests**: Is the bond zone truncated at the bottom face (only 100mm
  clearance vs 256mm zone extent)?
- **Critical**: Tests whether R2K clips the bond zone at section boundaries

### HX4i-offcentre_high (bar at z=600)
- **Changes**: 150mm from top, 600mm from bottom
- **Tests**: Same as offcentre but opposite side — symmetry check

---

## HX Series: Concrete Strength

### HX4i-lowfc (fcp = 20 MPa)
- **Changes**: ft = 2.01 MPa (was 2.70), Ec = 20125 MPa (was 27000)
- **Predicted**: s_m unchanged (depends on geometry, not fcp)
- **Tests**: Does the normalised profile shape (f1/ft vs d/s_m) change with
  concrete strength? It shouldn't if the formula is correct.
- **If wrong**: R2K's TS formula has an fcp-dependent term we're missing

### HX4i-highfc (fcp = 60 MPa)
- **Changes**: ft = 3.49 MPa, Ec = 34856 MPa
- **Tests**: Same hypothesis, opposite direction
- **Combined**: lowfc + baseline + highfc gives three-point calibration of
  any fcp dependence

---

## HX Series: Reinforcement Ratio

### HX4i-lowrho (A = 500mm², ρ ≈ 0.18%)
- **Changes**: ρ/4, same db
- **Predicted**: s_m = 511mm (1.25×), m unchanged (same Ac and Σπdb)
- **Tests**: Does very low ρ change the TS decay shape? Bentz discusses
  "poorly-reinforced" zones — is there a threshold?
- **If wrong**: R2K applies a different formula at low ρ

### HX4i-highrho (A = 4000mm², ρ ≈ 1.4%)
- **Changes**: ρ×2, same db (implies more bars or larger bars)
- **Predicted**: s_m = 392mm (0.96×)
- **Tests**: High ρ regime — is the TS formula the same?

---

## BX Series: Bar Position in Bending

### BX4i-deepbar (bar at z=100)
- **Changes**: 100mm cover (was 65mm) — deeper bar
- **Predicted**: Larger c → larger s_m → wider bond zone → more TS
  contribution to moment (more layers within bond zone)
- **Tests**: Does the bending response scale with bond zone extent?

### BX4i-shallbar (bar at z=40)
- **Changes**: 40mm cover — shallower bar
- **Predicted**: Smaller c → smaller s_m → narrower bond zone
- **Tests**: Opposite of deepbar — fewer layers in bond zone

---

## Predictions to Verify

For each HX case, after R2K extraction we check:

1. **Bond zone boundary position**: does it match 0.625 × s_m_predicted?
2. **f1 at bar**: does it match ft/(1 + sqrt(3.6·m·e1)) with our m?
3. **Normalised profile collapse**: does f1/f1_bar vs d/s_m overlay with H4i?
4. **Shape consistency**: does the shoulder shape change with parameters?

If the normalised profiles collapse across all HX variants, our formulas are
correct. If they don't, the deviation tells us which parameter R2K treats
differently.

---

## Execution Plan

**Phase 1** (verify s_m formula):
HX4i-narrow, HX4i-wide, HX4i-2bar — biggest s_m variation

**Phase 2** (verify m and Eq 5-9):
HX4i-lowrho, HX4i-highrho — changes ρ without changing geometry

**Phase 3** (verify boundary behaviour):
HX4i-offcentre — does the bond zone clip at the face?

**Phase 4** (verify universality):
HX4i-lowfc, HX4i-highfc — does concrete strength affect the decay shape?

All HX files require manual R2K setup (MN loading, member length) before
automated extraction.
