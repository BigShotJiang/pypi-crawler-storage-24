# Experimental Designs: Variable Isolation Tests

Each test adds exactly ONE new variable on top of a validated predecessor.
When a test fails, the root cause is unambiguous.

---

## Dependency Graph

```
A1-6 ─── geometry, Ec, ft, cracking ─────────────────────────────────┐
  │                                                                   │
  ├─ B2i ── compression model (Popovics) ──────────────────────┐      │
  │   └─ C2i ── + compression bar ───────────────────────┐     │      │
  │       └─ D2i ── + stirrups (compression, no TS) ─┐   │     │      │
  │           └─ Dls2i ── + gentle shear (av=10m)     │   │     │      │
  │                                                   │   │     │      │
  ├─ B3i ── brittle cracking ─────────────────────┐   │   │     │      │
  │   ├─ C3i ── + compression bar, brittle ──┐    │   │   │     │      │
  │   └─ D3i ── + stirrups, brittle ─────┐   │    │   │   │     │      │
  │       └─ Dls3i ── + gentle shear     │   │    │   │   │     │      │
  │                                      │   │    │   │   │     │      │
  ├─ H3i ── brittle axial ──────────┐    │   │    │   │   │     │      │
  │                                 │    │   │    │   │   │     │      │
  └─ H4i ── TS axial (bond zone) ──┤    │   │    │   │   │     │      │
      │                             │    │   │    │   │   │     │      │
      ├─ H6i ── + comp softening   │    │   │    │   │   │     │      │
      ├─ Hs4i ── + stirrups axial  │    │   │    │   │   │     │      │
      ├─ H4i-sym ── zone overlap   │    │   │    │   │   │     │      │
      ├─ H4i-bigbar ── s_m scaling │    │   │    │   │   │     │      │
      │                             │    │   │    │   │   │     │      │
      └─ B4i ── TS in bending ─────┘    │   │    │   │   │     │      │
          │                              │   │    │   │   │     │      │
          └─ C4i ── two bond zones ──────┘   │    │   │   │     │      │
              │                               │   │   │   │     │      │
              └─ D4i ── + stirrups + TS ──────┘   │   │   │     │      │
                  │                                │   │   │     │      │
                  ├─ Dls4i ── + gentle shear ──────┘   │   │     │      │
                  │   │                                 │   │     │      │
                  │   └─ Dms4i ── + moderate shear ─────┘   │     │      │
                  │       │                                  │     │      │
                  │       └─ F4i ── + full shear ────────────┘     │      │
                  │           │                                    │      │
                  │           └─ G4i ── + high shear ──────────────┘      │
                  │                                                       │
                  └─ D6i ── full model bending ───────────────────────────┘
                      └─ Dms6i ── full model + moderate shear
                          └─ F6i ── full model + full shear
                              └─ G6i ── full model + high shear
```

---

## Test Details

### H3i: Brittle Axial
- **Section**: 375×750, centroidal bar (z=375), A=2000mm²
- **Material**: Popovics, no softening, NO tension stiffening (tsfactor=0)
- **Loading**: Pure axial (MN=1.0)
- **Adds over A3**: Reinforcement under axial — does the bar affect anything when there's no TS?
- **Expected**: Pre-cracking identical to A. Post-cracking: f1=0 everywhere (brittle), steel carries all load. Simple elastic-then-cracked response.
- **If it fails**: Our rebar smearing or steel stress calculation is wrong.

### H4i: Tension Stiffening Axial (Bond Zone Calibration)
- **Section**: Same as H3i
- **Material**: Popovics, no softening, tension stiffening ON (tsfactor=1.0)
- **Loading**: Pure axial
- **Adds over H3i**: Tension stiffening — the ONLY new variable
- **Expected**: f1 profile shows bond zone decay from bar. Calibrates Eq 5-9.
- **If it fails**: Eq 5-9 formula, m_bar, s_m_bar, or zone_depth is wrong.

### H6i: Full Model Axial
- **Section**: Same as H3i
- **Material**: Popovics, Collins-Bentz softening, tension stiffening ON
- **Loading**: Pure axial
- **Adds over H4i**: Compression softening — does β affect the tension side?
- **Expected**: Under pure tension, compression softening should have zero effect (no compression). f1 profile should be identical to H4i.
- **If it fails**: Compression softening is leaking into the tension calculation.

### Hs4i: Stirrups Under Axial
- **Section**: 375×750, centroidal bar + stirrups (200mm spacing)
- **Material**: Same as H4i (TS on, no softening)
- **Loading**: Pure axial
- **Adds over H4i**: Transverse reinforcement (rho_y, s_y)
- **Expected**: Under pure axial, stirrups should not change the f1 profile significantly. ey equilibrium might differ slightly (steel in y-direction).
- **If it fails**: Stirrup contribution to ey equilibrium or crack spacing is wrong.

### C3i: Compression Bar + Brittle Cracking
- **Section**: 375×750, bars at z=65 and z=685
- **Material**: Popovics, brittle (no TS)
- **Loading**: Pure bending
- **Adds over B3i**: Compression reinforcement — does the top bar change M?
- **Expected**: Slightly higher post-cracking M due to compression bar contribution. f1 should still be 0 at cracked layers (brittle).
- **If it fails**: Compression bar smearing or steel stress is wrong.

### C4i: Bond Zone Interaction in Bending
- **Section**: Same as C3i
- **Material**: Popovics, tension stiffening ON
- **Loading**: Pure bending
- **Adds over C3i**: Tension stiffening with TWO bar layers
- **Expected**: Bottom bar's bond zone provides TS in tension zone. Top bar's bond zone is in compression — should it contribute? Tests zone interaction.
- **If it fails**: Bond zone superposition or nearest-bar logic is wrong. Cross-check with H4i-sym.

### D2i: Stirrups + Compression Model
- **Section**: 375×750, bot bar + stirrups
- **Material**: Popovics, no TS, no softening
- **Loading**: Pure bending
- **Adds over C2i**: Stirrups (but no TS, so stirrup effect on crack check is muted)
- **Expected**: Similar to B2i — stirrups don't contribute much in pure bending without TS.
- **If it fails**: Transverse reinforcement interfering with bending equilibrium.

### D3i: Stirrup Crack Check (KEY)
- **Section**: 375×750, bot bar + stirrups
- **Material**: Popovics, brittle (no TS)
- **Loading**: Pure bending
- **Adds over B3i**: Stirrups with brittle concrete — crack check has rho_y > 0
- **Expected**: Crack check now has stirrup contribution. Under pure bending (low shear), effect should be small.
- **If it fails**: Crack check formula with rho_y is wrong.

### D4i: Stirrups + Tension Stiffening (KEY)
- **Section**: 375×750, bot bar + stirrups
- **Material**: Popovics, TS on
- **Loading**: Pure bending
- **Adds over D3i**: Tension stiffening — combines stirrups with TS
- **Expected**: Similar to B4i but with stirrup contribution to crack check and s_y.
- **If it fails**: Stirrup-TS interaction is wrong.

### Dls2i: Gentle Shear Introduction (av=10m)
- **Section**: D section (bot bar + stirrups)
- **Material**: Popovics, no TS
- **Loading**: M/V = 10.0m (very low shear demand)
- **Adds over D2i**: First non-zero gamma_xy — Idle-Dual loop activates
- **Expected**: Shear effect is negligible (V ≈ M/10000). Idle-Dual should converge in 1-2 iterations.
- **If it fails**: Idle-Dual loop has a fundamental bug (even at trivial shear).

### Dls3i: Gentle Shear + Brittle Cracking
- **Section**: D section
- **Material**: Popovics, brittle
- **Loading**: M/V = 10.0m
- **Adds over D3i**: Gentle shear with cracking
- **Expected**: Cracking + trivial shear. Theta should be near 90° (vertical cracks).
- **If it fails**: Shear-cracking interaction at low shear levels.

### Dls4i: Gentle Shear + TS (KEY)
- **Section**: D section
- **Material**: Popovics, TS on
- **Loading**: M/V = 10.0m
- **Adds over D4i**: Gentle shear with full tension stiffening
- **Expected**: The Idle-Dual loop with TS at trivial shear. Should be nearly identical to D4i.
- **If it fails**: TS + shear profile interaction even at low shear.

### Dms4i: Moderate Shear (KEY, av=5m)
- **Section**: D section
- **Material**: Popovics, TS on
- **Loading**: M/V = 5.0m
- **Adds over Dls4i**: Increased shear — theta starts rotating
- **Expected**: Noticeable shear effect. Idle-Dual should converge but may take more iterations.
- **If it fails**: Shear profile convergence issue at moderate shear. Compare with Dls4i to isolate the shear magnitude effect.

### F4i: Full Shear (av=1.5m)
- **Section**: F section (same geometry as D)
- **Material**: Popovics, TS on
- **Loading**: M/V = 1.5m
- **Adds over Dms4i**: High shear demand — aggregate interlock is structural
- **Expected**: Full shear response. Idle-Dual convergence is the main risk.
- **If it fails**: Compare with Dms4i — if moderate shear works but full fails, the issue is shear magnitude, not mechanism.

### G4i: High Shear (av=0.5m)
- **Section**: F section
- **Material**: Popovics, TS on
- **Loading**: M/V = 0.5m
- **Adds over F4i**: Very high shear — diagonal compression may govern
- **Expected**: Challenging for convergence. Compression softening matters here.
- **If it fails**: Diagonal compression failure mode, maximum shear strain.

---

## Execution Priority

Run in this order (each depends on predecessors passing):

1. **H3i** — quick check, should be trivial
2. **H6i** — verify compression softening doesn't leak into tension
3. **Hs4i** — verify stirrups don't affect axial
4. **C3i** — compression bar baseline
5. **D3i** — stirrup crack check
6. **Dls4i** — first shear test (gentle)
7. **Dms4i** — moderate shear
8. **C4i** — bond zone interaction
9. **D4i** — stirrups + TS
10. **F4i** — full shear (the big test)

---

## Back-Testing Matrix

When validating test X, always verify all predecessors still pass:

| Working on | Must also pass |
|-----------|---------------|
| H4i | A3-A6 |
| B4i | A3-A6, H4i |
| C4i | A, B4i, H4i, H4i-sym, C3i |
| D4i | A, B4i, D3i, Hs4i |
| Dls4i | A, B4i, D4i |
| Dms4i | A, B4i, D4i, Dls4i |
| F4i | A, B4i, D4i, Dls4i, Dms4i |
| G4i | A, B4i, D4i, F4i |
