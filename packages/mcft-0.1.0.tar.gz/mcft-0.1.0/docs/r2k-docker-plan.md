# R2K Docker Container Plan

## Vision

Package R2K + Wine + Xvfb into a Docker container that exposes R2K as an
API. Any machine with Docker can extract R2K analysis results without
installing Wine, configuring displays, or risking desktop crashes.

```bash
# Single file
docker run mcft-r2k extract tools/synth_B4i.rsp -o results/B4i.json

# Batch (20 parallel)
docker run mcft-r2k batch 'tools/synth_*.rsp' --jobs 20

# CI validation
docker run mcft-r2k validate tests/
```

---

## Architecture

```
┌─────────────────────────────────────────┐
│  Docker Container                        │
│                                          │
│  ┌──────────┐  ┌──────────┐             │
│  │  Xvfb :99│  │  Xvfb :100│  ...       │
│  │  ┌─────┐ │  │  ┌─────┐ │            │
│  │  │ R2K │ │  │  │ R2K │ │            │
│  │  │Wine │ │  │  │Wine │ │            │
│  │  └─────┘ │  │  └─────┘ │            │
│  └──────────┘  └──────────┘             │
│        │              │                  │
│        └──────┬───────┘                  │
│               │                          │
│     r2k_extract.py                       │
│     run_batch_parallel.sh                │
│               │                          │
│          results/*.json                  │
└───────────────┼──────────────────────────┘
                │
          mounted volume
```

---

## Dockerfile

```dockerfile
FROM ubuntu:22.04

ENV DEBIAN_FRONTEND=noninteractive
ENV WINEDEBUG=-all
ENV WINEPREFIX=/opt/wine

# Install dependencies
RUN dpkg --add-architecture i386 && \
    apt-get update && \
    apt-get install -y --no-install-recommends \
        wine wine32 wine64 \
        xvfb xdotool xclip \
        python3 python3-pip \
    && rm -rf /var/lib/apt/lists/*

# Initialise Wine prefix (headless)
RUN Xvfb :0 -screen 0 1920x1080x24 & \
    sleep 1 && \
    DISPLAY=:0 wineboot --init && \
    sleep 5 && \
    kill %1

# Copy R2K and extraction tools
COPY r2k/ /opt/r2k/
COPY tools/r2k_extract.py /opt/tools/
COPY tools/run_batch_parallel.sh /opt/tools/

# Working directory
WORKDIR /opt

ENTRYPOINT ["python3", "/opt/tools/r2k_extract.py"]
```

---

## Volume Mounts

```bash
docker run -v $(pwd)/tools:/data/rsp:ro \
           -v $(pwd)/results:/data/results \
           mcft-r2k \
           /data/rsp/synth_B4i.rsp --full --max-stages 0 \
           -o /data/results/synth_B4i_r2k.json
```

---

## Batch Mode

```bash
docker run -v $(pwd):/project \
           --cpus 20 \
           mcft-r2k batch \
           --glob '/project/tools/synth_*.rsp' \
           --jobs 15 \
           --out /project/results/synth/
```

---

## CI Integration

```yaml
# .github/workflows/validate.yml
name: R2K Validation
on: [push]
jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build R2K container
        run: docker build -t mcft-r2k .
      - name: Extract reference data
        run: |
          docker run -v $PWD:/project mcft-r2k batch \
            --glob '/project/tools/synth_A*.rsp' \
            --jobs 4 \
            --out /project/results/synth/
      - name: Run validation tests
        run: python -m pytest tests/test_validation.py
```

---

## Implementation Steps

### Phase 1: Local Docker (Current Machine)
1. Write Dockerfile
2. Build image: `docker build -t mcft-r2k .`
3. Test single extraction: `docker run mcft-r2k synth_H4i.rsp ...`
4. Test parallel batch: `docker run mcft-r2k batch ...`
5. Verify results match non-Docker extraction

### Phase 2: CI Pipeline
1. Push image to GitHub Container Registry
2. Add GitHub Actions workflow
3. Cache extracted R2K results (they don't change unless .rsp changes)
4. Run validation tests against cached results

### Phase 3: Cloud Scaling
1. Run on cloud VM with 32+ cores
2. Extract entire 67-file test matrix in one batch
3. Store reference results in the repo
4. Any code change triggers re-validation

---

## Known Issues

### Wine Prefix Conflicts
Multiple Wine instances sharing one prefix can corrupt it. Solutions:
- Use `WINEPREFIX=/tmp/wine_$$` per instance (slow: initialisation)
- Use a read-only shared prefix with copy-on-write overlay
- R2K is read-only so conflicts are unlikely in practice

### Window Positioning on Different Wine Versions
Wine window management varies between versions. The Xvfb approach (same
virtual resolution) should be stable, but coordinates may need recalibration
if Wine's OWL toolkit renders differently.

### R2K License
R2K is freeware but not open-source. Distributing it in a Docker image may
have legal implications. The Dockerfile should COPY from a local directory,
not download from the internet. Users provide their own R2K copy.

---

## Dependencies to Install on New Machine

```bash
# Ubuntu/Debian
sudo dpkg --add-architecture i386
sudo apt update
sudo apt install -y wine wine32 xvfb xdotool xclip x11vnc python3

# For Docker
sudo apt install -y docker.io
sudo usermod -aG docker $USER
```

**Note:** `wine32` is essential — R2K is a 32-bit Windows application.
Without it, Wine launches but R2K silently fails to start.

---

## Immediate Next Step (No Docker)

Before Docker, the `run_batch_parallel.sh` script provides parallel
extraction on any Linux machine with the dependencies installed:

```bash
# On the office PC (30 cores):
./tools/run_batch_parallel.sh 15 'tools/synth_*.rsp'
```

This runs 15 R2K instances in parallel on separate Xvfb displays.
No Docker needed. Results saved incrementally.
