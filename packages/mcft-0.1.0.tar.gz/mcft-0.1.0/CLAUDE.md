# MCFT Project — Developer Guide

Python reimplementation of Response-2000 (R2K) sectional analysis using the
Modified Compression Field Theory. Primary reference: Bentz (2000) PhD thesis,
University of Toronto.

**Package name**: `mcft` (not `response2k` — politically sensitive).

---

## Module structure

| Module | Responsibility |
|--------|---------------|
| `io.py` | Parse `.rsp` XML files into `BeamSection` dataclasses |
| `materials.py` | Constitutive relations (concrete, steel, MCFT tension/compression) |
| `mcft.py` | Membrane element: `stress_from_strain`, `secant_stiffness`, `tangent_stiffness` |
| `section.py` | Section geometry, layer discretisation, crack spacing, `build_layers` |
| `longitudinal_stiffness.py` | Global J matrix assembly, shear stress profile (Bentz Ch.6) |
| `solver.py` | Four nested loops: load stepping, equilibrium, force integration |
| `r2k_validation.py` | Read R2K `.ods` output for validation comparison |

---

## Conventions

### Units
All internal calculations use **mm, N, MPa** throughout.
- IO reads `.rsp` values as-is (already in mm/N/MPa)
- `SectLoading.av` = M/V shear span in **mm** (computed from MM[kN·m] / MV[kN] × 1000)
- Strains are **dimensionless** (absolute). Exception: `esh`, `eu` in `.rsp` are in ×10⁻³;
  `section.py` converts to absolute when building `NodeMaterial`.

### Sign convention
- **Depth axis**: z = 0 at bottom face, z = h at top face (bottom-to-top positive)
- **Curvature**: positive φ = sagging = bottom in tension, top in compression
- **Strain at layer**: `ex = e0 - φ × (z - z_centroid)`
  — negative sign because increasing φ increases tensile strain below centroid
- **Axial force**: positive N = tension
- **Moment**: positive M = sagging (bottom tension)
- **Moment integration**: `M -= fx × b × dz × (z - z_centroid)` (note minus sign)

### Bentz thesis vs solver convention
The J matrix in `longitudinal_stiffness.py` uses Bentz's sign convention
(`εx = ε0 + φ·z`), which is the **opposite** of the solver's. For the 2×2
Newton subsystem with φ fixed, J[0][0] and J[2][2] are the same in both, but
moment coupling terms flip sign: `dM_solver/de0 = -J[1][0]`.

---

## Algorithm structure (Bentz Ch.7, Fig 7-1)

```
analyse_section()
└── Loop 1: Idle-Dual — iterate shear strain profile until converged
    └── Loop 2: Solve-Beam (_solve_beam) — find e0, γ_avg for given φ
        │  Phase A: Newton on e0 for N = target_N (FD Jacobian)
        │  Phase B: Newton on γ_avg for V = M/av (FD Jacobian)
        └── Loop 3: Get-Forces (_get_forces) — integrate N, M, V over section
            └── Loop 4: Transverse equilibrium (_transverse_equilibrium)
                        find ey such that fy_total = 0 at each layer
```

`assemble_J` (Ch.6, Eq 6-6) computes the 3×3 global tangent stiffness matrix.
It is used for the **shear stress profile** (Idle-Dual), NOT as the Newton
Jacobian in Solve-Beam (J-based Newton was tried and failed — see memory).

---

## Key calibrated values (matching R2K)

### Layering: 30 uniform midpoint layers
`SolverConfig.n_layers = 30` (default). R2K uses 30 uniform layers with
midpoint integration. Verified: unreinforced 375×750mm section gives
M_cr = 94.814 kNm vs R2K 94.812 kNm (0.003% error).

Midpoint rule with n=30 gives I/I_exact ≈ 0.99889, which is intentional —
it matches R2K's slight underestimate of the moment of inertia.

### Cracking strength: `ft = 0.45 × √fcp`
**Not** `0.45 × fcp^0.4` (Collins & Mitchell) and not `0.33 × √fcp` (ACI).
Implemented in `materials.cracking_strength()`. Verified by M_cr = ft·bh²/6.

### Outer-fiber cracking detection
In `_get_forces`, cracking is checked at the **outer face** of each layer
(z_bot for tensile layers, z_top for compressive layers), not the centroid.
The `e1_crack_check` argument to `stress_from_strain` carries this outer-face
principal tensile strain. The MCFT computation still uses centroid strains.

This is what makes step 50 (φ = φ_cr) be the peak moment step rather than
a later step — critical for matching R2K's cracking moment.

### Concrete compression: `c_mod=2` is Thorenfeldt/Popovics
R2K's "Parabolic" (XML code 2) is the Thorenfeldt/Popovics formula. In
`io.py`, XML `c_mod=2` maps directly to internal code 2 (no offset).
Do NOT apply a -1 offset — it breaks Marshall validation.

### Compression softening default: Collins-Bentz 2011
XML `c_soft=18` maps to `c_soft=1` internally (Collins-Bentz normalised by e0).
Formula: `β = 1/(0.8 + 0.34·ε1/ε0)`. Collins & Mitchell 1987 p.740 has a
**typo** (`0.8 - 0.34·ε1/ε0`) — the sign must be `+`.

---

## What NOT to change

- **`ft = 0.45 × sqrt(fcp)`** — changing to `0.45 × fcp^0.4` or `0.33 × sqrt(fcp)` breaks cracking
- **`c_mod=2` → Popovics, no offset** — a -1 offset to io.py broke Marshall by 47%
- **J[2][0], J[2][1] have no `s` factor; J[2][2] has one `s`** — the extra-s bug was already fixed; restoring it silently corrupts the shear profile
- **Tension stiffening only at reinforced layers** — do NOT apply Eq 5-8 to layers with rho_x=0 and rho_y=0, even if m>0. Eq 5-9 (poorly-reinforced) is for along-beam variation, not through-depth. R2K's residual f1 at unreinforced layers near rebar is bond-zone tension softening, not smeared stiffening.
- **Phase A/B FD Newton in `_solve_beam`** — J-based Newton was tried and diverges; the FD approach is the correct one here (see memory: `solver-next.md`)

---

## Testing

```bash
python -m pytest tests/ -q                  # all tests
python -m pytest tests/test_materials.py    # constitutive relations only
python -m pytest tests/test_validation.py   # R2K comparison
```

Validation tolerances are intentionally wide to accommodate known layering
differences on reinforced sections. The unreinforced A3-A6 synthetic cases
(generated by `tools/gen_synth_tests.py`) are the tightest check.

### Current validation status
- **Unreinforced rect (A3-A6)**: 0.003% of R2K cracking moment ✓
- **dm-n1n** (375×750, NSC, M:V=1.5): ~80% of R2K peak (uniform layers)
  — needs non-uniform layering near rebar to match R2K more closely
- **Marshall** (305×610, hogging M:V=-1): ~90% ✓
- **Liping LB1** (I-section, axial): ~42% — axial + complex section

---

## R2K file format notes

`.rsp` files are XML with a custom DTD (`r3g.dtd`). Section points are stored
**top-to-bottom** in the file; `section.py` reverses them to bottom-to-top
(ascending z). Key integer codes for `<concrete>` attributes:

| Attribute | Code | Meaning |
|-----------|------|---------|
| `c_mod` | 1 | Linear |
| `c_mod` | 2 | Parabolic = Thorenfeldt/Popovics (default) |
| `c_soft` | 1 | None |
| `c_soft` | 18 | Collins-Bentz 2011 (default) |
| `t_stiff` | 1 | None |
| `t_stiff` | 7 | Bentz 1999 (default) |

Full code tables: see memory file `r2k-material-codes.md`.
