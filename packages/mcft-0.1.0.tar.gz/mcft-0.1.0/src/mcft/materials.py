"""Constitutive relations for concrete, reinforcement, and prestressing steel.

All material models from Bentz (2000) Chapters 2-3 and 5.
Pure functions — no cross-module dependencies.
"""

from __future__ import annotations

import math


# ---------------------------------------------------------------------------
# Concrete — elastic modulus and strain at peak
# ---------------------------------------------------------------------------


def concrete_elastic_modulus(fcp: float) -> float:
    """Initial tangent modulus Ec (Collins & Mitchell)."""
    return 3320.0 * math.sqrt(fcp) + 6900.0


def concrete_n(fcp: float) -> float:
    """Popovics curve-fitting parameter n."""
    return 0.8 + fcp / 17.0


def concrete_strain_at_peak(fcp: float, Ec: float | None = None) -> float:
    """Strain at peak stress e_c' (returned as a positive number).

    Uses n/(Ec*(n-1)) * fcp if Ec is provided, otherwise derives Ec first.
    """
    if Ec is None:
        Ec = concrete_elastic_modulus(fcp)
    n = concrete_n(fcp)
    return fcp * n / (Ec * (n - 1.0))


# ---------------------------------------------------------------------------
# Concrete — compression base curves
# ---------------------------------------------------------------------------


def concrete_compression_popovics(ec: float, fcp: float, e0: float, n: float) -> float:
    """Popovics/Thorenfeldt/Collins compression curve (c_mod=2).

    Parameters
    ----------
    ec : float
        Compressive strain (positive in compression).
    fcp : float
        Cylinder compressive strength f'c.
    e0 : float
        Strain at peak stress e'c (positive).
    n : float
        Popovics parameter.

    Returns
    -------
    float
        Compressive stress (positive).
    """
    if ec <= 0.0 or e0 <= 0.0:
        return 0.0
    ratio = ec / e0
    k = (0.67 + fcp / 62.0) if ec > e0 else 1.0
    return fcp * ratio * n / (n - 1.0 + ratio ** (n * k))


def concrete_compression_parabolic(
    ec: float, fcp: float, e0: float, ecu: float = 0.0035
) -> float:
    """Parabolic compression curve (c_mod=1).

    Pre-peak: Hognestad parabola.
    Post-peak: linear descending to ecu.
    """
    if ec <= 0.0 or e0 <= 0.0:
        return 0.0
    ratio = ec / e0
    if ec <= e0:
        return fcp * (2.0 * ratio - ratio * ratio)
    # Post-peak linear descent
    ecu_ratio = ecu / e0
    if ecu_ratio <= 1.0:
        return 0.0
    return fcp * max(0.0, 1.0 - 0.15 * (ratio - 1.0) / (ecu_ratio - 1.0))


def concrete_compression_linear(ec: float, fcp: float, e0: float) -> float:
    """Linear-to-peak compression (c_mod=0)."""
    if ec <= 0.0 or e0 <= 0.0:
        return 0.0
    if ec <= e0:
        return fcp * ec / e0
    return fcp


def concrete_compression(
    ec: float,
    fcp: float,
    e0: float,
    c_mod: int = 2,
    n: float | None = None,
    ecu: float = 0.0035,
) -> float:
    """Dispatch to the appropriate compression base curve.

    Parameters
    ----------
    ec : float
        Compressive strain (positive in compression).
    fcp : float
        Cylinder compressive strength.
    e0 : float
        Strain at peak stress.
    c_mod : int
        0 = linear, 1 = parabolic, 2 = Popovics.
    n : float or None
        Popovics parameter (derived from fcp if None).
    ecu : float
        Ultimate strain for parabolic post-peak.
    """
    if c_mod == 0:
        return concrete_compression_linear(ec, fcp, e0)
    elif c_mod == 1:
        return concrete_compression_parabolic(ec, fcp, e0, ecu)
    else:
        if n is None:
            n = concrete_n(fcp)
        return concrete_compression_popovics(ec, fcp, e0, n)


def concrete_compression_tangent(
    ec: float,
    fcp: float,
    e0: float,
    c_mod: int = 2,
    n: float | None = None,
    ecu: float = 0.0035,
    deps: float = 1e-8,
) -> float:
    """Numerical tangent df_c/d(ec) via central difference."""
    f_plus = concrete_compression(ec + deps, fcp, e0, c_mod, n, ecu)
    f_minus = concrete_compression(ec - deps, fcp, e0, c_mod, n, ecu)
    return (f_plus - f_minus) / (2.0 * deps)


# ---------------------------------------------------------------------------
# Concrete — compression softening (beta factor)
# ---------------------------------------------------------------------------


def compression_softening(
    e1: float, fcp: float, e0: float = 0.002, c_soft: int = 1
) -> float:
    """Compression softening factor beta.

    c_soft selects the model:
      0 = None: beta = 1.0 (no softening)
      1 = Collins-Bentz (default): 1 / (0.8 + 0.34 * e1/e0)
          Equivalent to 1/(0.8+170*e1) when e0=0.002.
      2 = Vecchio-Collins 1982: 1 / (0.8 + 170*e1)

    For HSC (fcp > 60): applies (0.9 - fcp/250) factor with
    linear transition between 60 and 90 MPa.

    Returns value in (0, 1].
    """
    if e1 <= 0.0:
        return 1.0

    if c_soft == 0:
        return 1.0
    elif c_soft == 2:
        # Vecchio-Collins 1982: hardcoded 170
        beta_nsc = 1.0 / (0.8 + 170.0 * e1)
    else:
        # Collins-Bentz (default, code 1): normalised by e0
        e0_safe = max(e0, 1e-10)
        beta_nsc = 1.0 / (0.8 + 0.34 * e1 / e0_safe)

    if fcp <= 60.0:
        return min(1.0, beta_nsc)
    beta_hsc = beta_nsc * (0.9 - fcp / 250.0)
    if fcp >= 90.0:
        return min(1.0, beta_hsc)
    # Transition: linear interpolation between 60 and 90
    t = (fcp - 60.0) / 30.0
    return min(1.0, (1.0 - t) * beta_nsc + t * beta_hsc)


def compression_softening_deriv_e1(
    e1: float, fcp: float, e0: float = 0.002, c_soft: int = 1
) -> float:
    """d(beta)/d(e1) — needed for tangent stiffness cross-term."""
    if e1 <= 0.0 or c_soft == 0:
        return 0.0

    if c_soft == 2:
        k = 170.0
    else:
        e0_safe = max(e0, 1e-10)
        k = 0.34 / e0_safe

    denom = 0.8 + k * e1
    dbeta_nsc = -k / (denom * denom)

    if fcp <= 60.0:
        beta = 1.0 / denom
        if beta >= 1.0:
            return 0.0
        return dbeta_nsc
    hsc_factor = 0.9 - fcp / 250.0
    if fcp >= 90.0:
        beta = (1.0 / denom) * hsc_factor
        if beta >= 1.0:
            return 0.0
        return dbeta_nsc * hsc_factor
    t = (fcp - 60.0) / 30.0
    beta_nsc = 1.0 / denom
    beta_hsc = beta_nsc * hsc_factor
    beta = (1.0 - t) * beta_nsc + t * beta_hsc
    if beta >= 1.0:
        return 0.0
    return (1.0 - t) * dbeta_nsc + t * dbeta_nsc * hsc_factor


# ---------------------------------------------------------------------------
# Concrete — effective aggregate size (§5-5)
# ---------------------------------------------------------------------------


def effective_aggregate_size(agg: float, fcp: float) -> float:
    """Effective aggregate size for aggregate interlock."""
    if fcp <= 60.0:
        return agg
    if fcp >= 80.0:
        return 0.0
    return agg * (1.0 - (fcp - 60.0) / 20.0)


# ---------------------------------------------------------------------------
# Concrete — cracking and tension
# ---------------------------------------------------------------------------


def cracking_strength(fcp: float) -> float:
    """Tensile cracking strength: f_t = 0.45 * sqrt(f'c)."""
    return 0.45 * math.sqrt(fcp)


def tension_stiffening(e1: float, ft: float, m: float, tsfactor: float = 1.0) -> float:
    """Average tensile stress in cracked concrete — well-reinforced zones (Eq. 5-8).

    Parameters
    ----------
    e1 : float
        Principal tensile strain (positive).
    ft : float
        Cracking strength.
    m : float
        Bond parameter = A_c / sum(pi * d_b_i).
    tsfactor : float
        Scaling factor (0 to 1), default 1.0.
    """
    if e1 <= 0.0:
        return 0.0
    if m <= 0.0:
        return 0.0
    return tsfactor * ft / (1.0 + math.sqrt(3.6 * m * e1))


def tension_stiffening_eq59(
    e1: float, ft: float, m_bar: float, d_bar: float, s_m_bar: float,
    tsfactor: float = 1.0,
) -> float:
    """Tension stiffening at unreinforced layers — Bentz Eq 5-9, Fig 5-13.

    Relative tension stiffening decays with normalised distance from bar:
      val = clamp(1/(8·x/s_m) - 0.2, 0, 1)
    where x = d_bar, s_m = s_m_bar.

    val = 1.0 for x/s_m ≤ ~0.104 (capped)
    val = 0.0 for x/s_m ≥ 0.625  (capped)

    f1 = val · f1_bar, where f1_bar is the Eq 5-8 tension stiffening
    evaluated with the bar's bond parameter.

    Parameters
    ----------
    e1 : float
        Principal tensile strain (positive).
    ft : float
        Cracking strength.
    m_bar : float
        Bond parameter at the nearest bar location.
    d_bar : float
        Distance (mm) from the nearest reinforcing bar.
    s_m_bar : float
        Crack spacing (mm) at the bar location.
    tsfactor : float
        Scaling factor (0 to 1).
    """
    if e1 <= 0.0 or m_bar <= 0.0 or s_m_bar <= 0.0:
        return 0.0

    xi = d_bar / s_m_bar
    if xi >= 0.625:
        return 0.0  # beyond bond zone

    # Fig 5-13 decay factor, capped to [0, 1]
    if xi <= 0.0:
        val = 1.0
    else:
        val = 1.0 / (8.0 * xi) - 0.2
        val = max(0.0, min(1.0, val))
    if val <= 0.0:
        return 0.0

    # Effective M increases with distance from bar (val enters as power).
    # At bar (val=1): M_eff = 3.6·m_bar (same as Eq 5-8).
    # Far from bar (val→0): M_eff → ∞, f1 → 0.
    # Power 0.35 calibrated to R2K H4i axial profile (Bentz thesis ~0.5).
    M_eff = 3.6 * m_bar / val ** 0.35
    return tsfactor * ft / (1.0 + math.sqrt(M_eff * e1))


def tension_stiffening_poor(e1: float, ft: float, m: float, xi: float) -> float:
    """Tension stiffening for poorly-reinforced zones (Eq. 5-9).

    Parameters
    ----------
    xi : float
        Normalised distance from bar: z / s_x, where z is distance
        from nearest bar and s_x is crack spacing at the bar.
    """
    if xi > 0.5 or e1 <= 0.0 or m <= 0.0:
        return 0.0
    base = ft / (1.0 + math.sqrt(3.6 * m * e1))
    return 2.0 * base * (1.0 - 2.0 * xi)


def tension_stiffening_tangent(
    e1: float, ft: float, m: float, tsfactor: float = 1.0
) -> float:
    """d(f1)/d(e1) for tension stiffening (well-reinforced)."""
    if e1 <= 0.0 or m <= 0.0:
        return 0.0
    arg = 3.6 * m * e1
    sqrt_arg = math.sqrt(arg)
    denom = 1.0 + sqrt_arg
    return -tsfactor * ft * 3.6 * m / (2.0 * sqrt_arg * denom * denom)


# ---------------------------------------------------------------------------
# Concrete — aggregate interlock (Walraven)
# ---------------------------------------------------------------------------


def aggregate_interlock(fcp: float, w: float, aeff: float) -> float:
    """Maximum shear stress on crack (Walraven equation, §2.6).

    Parameters
    ----------
    fcp : float
        Concrete compressive strength.
    w : float
        Crack width.
    aeff : float
        Effective aggregate size.
    """
    if w <= 0.0:
        return float("inf")
    return 0.18 * math.sqrt(fcp) / (0.31 + 24.0 * w / (aeff + 16.0))


# ---------------------------------------------------------------------------
# Reinforcement — bare bar (trilinear with sqrt hardening)
# ---------------------------------------------------------------------------


def rebar_stress(
    es: float,
    fy: float,
    E: float = 200_000.0,
    fu: float | None = None,
    esh: float = 10.0,
    eu: float = 100.0,
) -> float:
    """Average stress in reinforcing bar.

    Parameters
    ----------
    es : float
        Steel strain (x1e-3 if inputs are in x1e-3, but this function
        is unit-agnostic — same unit system as esh, eu).
    fy : float
        Yield stress.
    E : float
        Elastic modulus (same unit system as fy).
    fu : float or None
        Ultimate stress; defaults to 1.5 * fy.
    esh : float
        Strain at onset of hardening.
    eu : float
        Ultimate strain.
    """
    if fu is None:
        fu = 1.5 * fy
    sign = 1.0 if es >= 0.0 else -1.0
    es = abs(es)
    ey = fy / E
    if es <= ey:
        return sign * E * es
    if es <= esh:
        return sign * fy
    if es >= eu:
        return sign * fu
    # Strain hardening: sqrt curve
    return sign * (fy + (fu - fy) * math.sqrt((es - esh) / (eu - esh)))


def rebar_tangent(
    es: float,
    fy: float,
    E: float = 200_000.0,
    fu: float | None = None,
    esh: float = 10.0,
    eu: float = 100.0,
) -> float:
    """Tangent modulus df_s/d(es)."""
    if fu is None:
        fu = 1.5 * fy
    es_abs = abs(es)
    ey = fy / E
    if es_abs <= ey:
        return E
    if es_abs <= esh:
        return 0.0
    if es_abs >= eu:
        return 0.0
    # Hardening region
    denom = eu - esh
    ratio = (es_abs - esh) / denom
    if ratio <= 0.0:
        return 0.0
    return (fu - fy) / (2.0 * math.sqrt(ratio) * denom)


# ---------------------------------------------------------------------------
# Prestressing steel — Ramberg-Osgood
# ---------------------------------------------------------------------------


def prestress_stress(
    ep: float,
    fu: float,
    Ep: float = 190_000.0,
    A: float = 0.030,
    B: float = 121.0,
    C: float = 6.0,
) -> float:
    """Prestressing steel stress (Ramberg-Osgood, §2.7).

    f_p = E_p * e_p * [A + (1 - A) / (1 + (B * e_p)^C)^(1/C)]
    """
    if ep <= 0.0:
        return 0.0
    Bep_C = (B * ep) ** C
    bracket = A + (1.0 - A) / (1.0 + Bep_C) ** (1.0 / C)
    stress = Ep * ep * bracket
    return min(stress, fu)


def prestress_tangent(
    ep: float,
    fu: float,
    Ep: float = 190_000.0,
    A: float = 0.030,
    B: float = 121.0,
    C: float = 6.0,
    deps: float = 1e-8,
) -> float:
    """Numerical tangent for prestressing steel."""
    f_plus = prestress_stress(ep + deps, fu, Ep, A, B, C)
    f_minus = prestress_stress(max(0.0, ep - deps), fu, Ep, A, B, C)
    denom = (ep + deps) - max(0.0, ep - deps)
    if denom == 0.0:
        return Ep
    return (f_plus - f_minus) / denom
