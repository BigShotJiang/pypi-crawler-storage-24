"""XML (.rsp) parser for Response-2000 files.

Reads the suite_3g XML format produced by Response-2000 v1.9.6+.
Values are stored exactly as read — no unit conversion is performed.
"""

from __future__ import annotations

import logging
import re
import shlex
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class Concrete:
    name: str
    fcp: float
    maxagg: float = 20.0
    c_mod: int = 2
    c_soft: int = 1  # 0=None, 1=Collins-Bentz (default), 2=VC1982
    tsfactor: float = 1.0
    ft: float | None = None
    e0: float | None = None
    Ec: float | None = None
    curve: list[tuple[float, float]] | None = None


@dataclass
class Rebar:
    name: str
    fy: float
    E: float = 200_000.0
    fu: float | None = None
    esh: float = 10.0
    eu: float = 100.0


@dataclass
class Prestress:
    name: str
    fu: float
    E: float = 190_000.0
    A: float = 0.030
    B: float = 121.0
    C: float = 6.0
    eu: float = 40.0


@dataclass
class SectionPoint:
    depth: float
    width: float
    concrete_name: str | None = None


@dataclass
class LongReinf:
    z: float
    type: str
    A: float
    name: str = ""
    num: int = 1
    Ai: float | None = None
    db: float | None = None
    space: float = 0.0
    dep: float = 0.0
    drape: float = 0.0
    bartitle: str = ""


@dataclass
class TransReinf:
    A: float
    type: str
    pattern: int
    space: float
    disttop: float = 0.0
    distbot: float = 0.0
    name: str = ""
    Ai: float | None = None
    db: float | None = None
    dep: float = 0.0
    bartitle: str = ""


@dataclass
class ElemInfo:
    L: float
    mido2: float = 0.0
    lplate: float = 0.0
    rplate: float = 0.0


@dataclass
class SectLoading:
    MM: float = 0.0
    MV: float = 0.0
    BN: float = 0.0
    BM: float = 0.0

    @property
    def av(self) -> float:
        """Shear span M/V in analysis length units (mm).

        Derived from the load-path ratios MM and MV.
        In .rsp files MM is in kN·m and MV in kN, so MM/MV
        is in m; the factor of 1000 converts to mm.
        Returns inf for pure bending (MV == 0).
        """
        if abs(self.MV) < 1e-15:
            return float("inf")
        return self.MM / self.MV * 1000.0


@dataclass
class ShrinkTherm:
    profile: list[tuple[float, float]] = field(default_factory=list)


@dataclass
class BeamSection:
    name: str
    doneby: str = ""
    date: str = ""
    concretes: dict[str, Concrete] = field(default_factory=dict)
    rebars: dict[str, Rebar] = field(default_factory=dict)
    prestress: dict[str, Prestress] = field(default_factory=dict)
    section_points: list[SectionPoint] = field(default_factory=list)
    long_reinf: list[LongReinf] = field(default_factory=list)
    trans_reinf: list[TransReinf] = field(default_factory=list)
    elem_info: ElemInfo | None = None
    sect_loading: SectLoading | None = None
    shrink_therm: ShrinkTherm | None = None


@dataclass
class BMDPoint:
    position: float
    moment: float
    flag: int


@dataclass
class BMD:
    points: list[BMDPoint] = field(default_factory=list)
    isconstant: bool = False
    type: str = ""
    axial_load: float = 0.0


@dataclass
class MatZone:
    position: float
    section_name: str


@dataclass
class Support:
    which: str
    platelocate: float
    platesize: float = 0.0
    support: str = ""


@dataclass
class MemberAnalysis:
    length: float
    bmds: list[BMD] = field(default_factory=list)
    mat_zones: list[MatZone] = field(default_factory=list)
    supports: list[Support] = field(default_factory=list)
    topplatesize: float = 0.0
    displocate: float = 0.0
    leftanchor: str = ""
    rightanchor: str = ""


@dataclass
class R2KModel:
    sections: list[BeamSection] = field(default_factory=list)
    member_analysis: MemberAnalysis | None = None


# ---------------------------------------------------------------------------
# XML preprocessing
# ---------------------------------------------------------------------------

_DOCTYPE_RE = re.compile(r"<!DOCTYPE[^>]*>")
_TAG_RE = re.compile(r"<[^!?/][^>]*>", re.DOTALL)
_ATTR_RE = re.compile(r"""(\w+)\s*=\s*"([^"]*)"\s*""")


def _strip_doctype(xml_text: str) -> str:
    return _DOCTYPE_RE.sub("", xml_text)


def _dedup_attrs(xml_text: str) -> str:
    """Remove duplicate attributes within each XML tag, keeping last occurrence."""

    def _dedup_tag(match: re.Match) -> str:
        tag = match.group(0)
        attrs = _ATTR_RE.findall(tag)
        if not attrs:
            return tag
        seen: dict[str, str] = {}
        for name, value in attrs:
            if name in seen:
                logger.debug("Duplicate attribute %r in tag, keeping last value", name)
            seen[name] = value
        if len(seen) == len(attrs):
            return tag
        # Rebuild: take tag name portion, then unique attrs
        # Find where the tag name ends
        stripped = tag.lstrip("<")
        tag_name = stripped.split()[0].rstrip(">").rstrip("/")
        is_self_closing = tag.rstrip().endswith("/>")
        rebuilt = f"<{tag_name}"
        for aname, aval in seen.items():
            rebuilt += f' {aname}="{aval}"'
        rebuilt += " />" if is_self_closing else ">"
        return rebuilt

    return _TAG_RE.sub(_dedup_tag, xml_text)


def _preprocess(xml_text: str) -> str:
    return _dedup_attrs(_strip_doctype(xml_text))


# ---------------------------------------------------------------------------
# Text content parsers
# ---------------------------------------------------------------------------


def _parse_text_lines(text: str | None) -> list[list[str]]:
    """Split element text into tokenised lines using shlex for quoted strings."""
    if not text:
        return []
    lines: list[list[str]] = []
    for raw in text.strip().splitlines():
        raw = raw.strip()
        if not raw:
            continue
        try:
            tokens = shlex.split(raw)
        except ValueError:
            tokens = raw.split()
        lines.append(tokens)
    return lines


def _parse_section_points(text: str | None) -> list[SectionPoint]:
    points: list[SectionPoint] = []
    for tokens in _parse_text_lines(text):
        if len(tokens) < 2:
            continue
        depth = float(tokens[0])
        width = float(tokens[1])
        concrete_name = tokens[2] if len(tokens) >= 3 else None
        points.append(SectionPoint(depth=depth, width=width, concrete_name=concrete_name))
    return points


def _parse_curve(text: str | None) -> list[tuple[float, float]] | None:
    lines = _parse_text_lines(text)
    if not lines:
        return None
    curve: list[tuple[float, float]] = []
    for tokens in lines:
        if len(tokens) >= 2:
            curve.append((float(tokens[0]), float(tokens[1])))
    return curve or None


def _parse_bmd_points(text: str | None) -> list[BMDPoint]:
    points: list[BMDPoint] = []
    for tokens in _parse_text_lines(text):
        if len(tokens) >= 3:
            points.append(
                BMDPoint(
                    position=float(tokens[0]),
                    moment=float(tokens[1]),
                    flag=int(tokens[2]),
                )
            )
    return points


def _parse_mat_zones(text: str | None) -> list[MatZone]:
    zones: list[MatZone] = []
    for tokens in _parse_text_lines(text):
        if len(tokens) >= 2:
            zones.append(MatZone(position=float(tokens[0]), section_name=tokens[1]))
    return zones


def _parse_shrink_therm(text: str | None) -> list[tuple[float, float]]:
    profile: list[tuple[float, float]] = []
    for tokens in _parse_text_lines(text):
        if len(tokens) >= 2:
            profile.append((float(tokens[0]), float(tokens[1])))
    return profile


# ---------------------------------------------------------------------------
# Attribute helpers
# ---------------------------------------------------------------------------


def _float(el: ET.Element, attr: str, default: float | None = None) -> float | None:
    val = el.get(attr)
    if val is None:
        return default
    return float(val)


def _float_req(el: ET.Element, attr: str) -> float:
    val = el.get(attr)
    if val is None:
        raise ValueError(f"Required attribute {attr!r} missing on <{el.tag}>")
    return float(val)


def _int(el: ET.Element, attr: str, default: int = 0) -> int:
    val = el.get(attr)
    if val is None:
        return default
    return int(val)


def _str(el: ET.Element, attr: str, default: str = "") -> str:
    val = el.get(attr)
    return val if val is not None else default


# ---------------------------------------------------------------------------
# Element parsers
# ---------------------------------------------------------------------------

_concrete_counter: int = 0


def _map_c_soft(r2k_code: int) -> int:
    """Map R2K c_soft code (1-based) to internal code.

    Internal: 0=None (β=1), 1=Collins-Bentz (default), 2=Vecchio-Collins 1982.
    R2K: 1=None, 2=VC1982, 18=Collins-Bentz 2011 (default). Others → Collins-Bentz.
    """
    if r2k_code == 1:
        return 0  # None
    if r2k_code == 2:
        return 2  # Vecchio-Collins 1982
    return 1  # Collins-Bentz for everything else (including default 18)


def _parse_concrete(el: ET.Element) -> Concrete:
    global _concrete_counter
    _concrete_counter += 1
    name = _str(el, "name", f"Concrete {_concrete_counter}")
    c_mod_r2k = _int(el, "c_mod", 2)
    # R2K codes: 1=Linear, 2=Parabolic(Popovics), 3=Popovics/Thorenfeldt, 4=Elasto-Plastic, 5=User-Defined
    # Internal codes (materials.py): 0=Linear, 1=Parabolic, 2=Popovics
    # Empirically: R2K default c_mod=2 ("Parabolic") matches our Popovics (2) — no offset for code 2+.
    # Only special case: R2K c_mod=1 (Linear) must map to our 0 (Linear).
    c_mod = 0 if c_mod_r2k == 1 else c_mod_r2k
    curve = _parse_curve(el.text) if c_mod_r2k == 4 else None  # c_mod=4 = User-Defined in R2K
    return Concrete(
        name=name,
        fcp=_float_req(el, "fcp"),
        maxagg=_float(el, "maxagg", 20.0),  # type: ignore[arg-type]
        c_mod=c_mod,
        c_soft=_map_c_soft(_int(el, "c_soft", 18)),
        tsfactor=_float(el, "tsfactor", 1.0),  # type: ignore[arg-type]
        ft=_float(el, "ft"),
        e0=_float(el, "e0"),
        Ec=_float(el, "E"),
        curve=curve,
    )


def _parse_rebar(el: ET.Element) -> Rebar:
    return Rebar(
        name=_str(el, "name", "Steel"),
        fy=_float_req(el, "fy"),
        E=_float(el, "E", 200_000.0),  # type: ignore[arg-type]
        fu=_float(el, "fu"),
        esh=_float(el, "esh", 10.0),  # type: ignore[arg-type]
        eu=_float(el, "eu", 100.0),  # type: ignore[arg-type]
    )


def _parse_prestress(el: ET.Element) -> Prestress:
    return Prestress(
        name=_str(el, "name", "P-Steel"),
        fu=_float_req(el, "fu"),
        E=_float(el, "E", 190_000.0),  # type: ignore[arg-type]
        A=_float(el, "A", 0.030),  # type: ignore[arg-type]
        B=_float(el, "B", 121.0),  # type: ignore[arg-type]
        C=_float(el, "C", 6.0),  # type: ignore[arg-type]
        eu=_float(el, "eu", 40.0),  # type: ignore[arg-type]
    )


def _parse_long_reinf(el: ET.Element) -> LongReinf:
    return LongReinf(
        z=_float_req(el, "z"),
        type=_str(el, "type", "Steel"),
        A=_float_req(el, "A"),
        name=_str(el, "name"),
        num=_int(el, "num", 1),
        Ai=_float(el, "Ai"),
        db=_float(el, "db"),
        space=_float(el, "space", 0.0),  # type: ignore[arg-type]
        dep=_float(el, "dep", 0.0),  # type: ignore[arg-type]
        drape=_float(el, "drape", 0.0),  # type: ignore[arg-type]
        bartitle=_str(el, "bartitle"),
    )


def _parse_trans_reinf(el: ET.Element) -> TransReinf:
    pattern = _int(el, "pattern", 0)
    if pattern == 7:
        logger.warning(
            "Unknown transverse reinforcement pattern=7 on %r, treating as pattern=1 (open stirrup)",
            _str(el, "name", "<unnamed>"),
        )
    return TransReinf(
        A=_float_req(el, "A"),
        type=_str(el, "type", "Steel"),
        pattern=pattern,
        space=_float_req(el, "space"),
        disttop=_float(el, "disttop", 0.0),  # type: ignore[arg-type]
        distbot=_float(el, "distbot", 0.0),  # type: ignore[arg-type]
        name=_str(el, "name"),
        Ai=_float(el, "Ai"),
        db=_float(el, "db"),
        dep=_float(el, "dep", 0.0),  # type: ignore[arg-type]
        bartitle=_str(el, "bartitle"),
    )


def _parse_elem_info(el: ET.Element) -> ElemInfo:
    return ElemInfo(
        L=_float_req(el, "L"),
        mido2=_float(el, "mido2", 0.0),  # type: ignore[arg-type]
        lplate=_float(el, "lplate", 0.0),  # type: ignore[arg-type]
        rplate=_float(el, "rplate", 0.0),  # type: ignore[arg-type]
    )


def _parse_sect_loading(el: ET.Element) -> SectLoading:
    return SectLoading(
        MM=_float(el, "MM", 0.0),  # type: ignore[arg-type]
        MV=_float(el, "MV", 0.0),  # type: ignore[arg-type]
        BN=_float(el, "BN", 0.0),  # type: ignore[arg-type]
        BM=_float(el, "BM", 0.0),  # type: ignore[arg-type]
    )


# ---------------------------------------------------------------------------
# Top-level parsers
# ---------------------------------------------------------------------------


def _parse_beam_section(el: ET.Element) -> BeamSection:
    global _concrete_counter
    _concrete_counter = 0

    section = BeamSection(
        name=_str(el, "name", "Unnamed"),
        doneby=_str(el, "doneby"),
        date=_str(el, "date"),
    )

    for child in el:
        tag = child.tag
        if tag == "concrete":
            c = _parse_concrete(child)
            section.concretes[c.name] = c
        elif tag == "rebar":
            r = _parse_rebar(child)
            section.rebars[r.name] = r
        elif tag == "prestress":
            p = _parse_prestress(child)
            section.prestress[p.name] = p
        elif tag == "sectionSOLID":
            section.section_points = _parse_section_points(child.text)
        elif tag == "shapesection":
            pass  # display metadata only
        elif tag == "longreinfx":
            section.long_reinf.append(_parse_long_reinf(child))
        elif tag == "transreinfz":
            section.trans_reinf.append(_parse_trans_reinf(child))
        elif tag == "eleminfo":
            section.elem_info = _parse_elem_info(child)
        elif tag == "sectloading":
            section.sect_loading = _parse_sect_loading(child)
        elif tag == "shrinktherm":
            section.shrink_therm = ShrinkTherm(profile=_parse_shrink_therm(child.text))
        else:
            logger.debug("Ignoring unknown element <%s> in r3g_beam %r", tag, section.name)

    return section


def _parse_support(el: ET.Element) -> Support:
    return Support(
        which=_str(el, "which", ""),
        platelocate=_float(el, "platelocate", 0.0),  # type: ignore[arg-type]
        platesize=_float(el, "platesize", 0.0),  # type: ignore[arg-type]
        support=_str(el, "support"),
    )


def _parse_bmd(el: ET.Element) -> BMD:
    return BMD(
        points=_parse_bmd_points(el.text),
        isconstant=_str(el, "isconstant") == "1",
        type=_str(el, "type"),
        axial_load=_float(el, "AxialLoad", 0.0),  # type: ignore[arg-type]
    )


def _parse_member_analysis(el: ET.Element) -> MemberAnalysis:
    ma = MemberAnalysis(
        length=_float_req(el, "length"),
        topplatesize=_float(el, "topplatesize", 0.0),  # type: ignore[arg-type]
        displocate=_float(el, "displocate", 0.0),  # type: ignore[arg-type]
        leftanchor=_str(el, "leftanchor"),
        rightanchor=_str(el, "rightanchor"),
    )

    for child in el:
        tag = child.tag
        if tag == "BMD":
            ma.bmds.append(_parse_bmd(child))
        elif tag == "mattypes":
            ma.mat_zones = _parse_mat_zones(child.text)
        elif tag == "supports":
            ma.supports.append(_parse_support(child))
        else:
            logger.debug("Ignoring unknown element <%s> in R2010_Analysis", tag)

    return ma


def _parse_document(root: ET.Element) -> R2KModel:
    model = R2KModel()
    for child in root:
        if child.tag == "r3g_beam":
            model.sections.append(_parse_beam_section(child))
        elif child.tag == "R2010_Analysis":
            model.member_analysis = _parse_member_analysis(child)
        else:
            logger.debug("Ignoring unknown top-level element <%s>", child.tag)
    return model


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def read_rsp(path: str | Path) -> R2KModel:
    """Parse an .rsp XML file and return the complete model."""
    path = Path(path)
    xml_text = path.read_text(encoding="utf-8")
    return read_rsp_string(xml_text)


def read_rsp_string(xml_text: str) -> R2KModel:
    """Parse an .rsp XML string and return the complete model."""
    cleaned = _preprocess(xml_text)
    root = ET.fromstring(cleaned)
    return _parse_document(root)
