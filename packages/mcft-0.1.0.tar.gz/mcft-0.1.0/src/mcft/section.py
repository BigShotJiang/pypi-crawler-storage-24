"""Section geometry, layer discretisation, and crack spacing model.

Builds a layered cross-section model from parsed IO data.
Implements CEB crack spacing from Bentz (2000) Chapter 7.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from . import materials as mat
from .io import BeamSection, Concrete, LongReinf, TransReinf
from .mcft import NodeMaterial


# ---------------------------------------------------------------------------
# Section outline — width at any depth by linear interpolation
# ---------------------------------------------------------------------------


@dataclass
class SectionOutline:
    """Piecewise-linear cross-section outline.

    Stores (depth, width) pairs sorted bottom-to-top (ascending depth).
    """

    depths: list[float] = field(default_factory=list)
    widths: list[float] = field(default_factory=list)
    concrete_names: list[str] = field(default_factory=list)

    def width_at(self, z: float) -> float:
        """Interpolate width at depth z."""
        if not self.depths:
            return 0.0
        if z <= self.depths[0]:
            return self.widths[0]
        if z >= self.depths[-1]:
            return self.widths[-1]
        for i in range(len(self.depths) - 1):
            z0, z1 = self.depths[i], self.depths[i + 1]
            if z0 <= z <= z1:
                if abs(z1 - z0) < 1e-15:
                    return self.widths[i]
                t = (z - z0) / (z1 - z0)
                return self.widths[i] + t * (self.widths[i + 1] - self.widths[i])
        return self.widths[-1]

    def concrete_at(self, z: float) -> str:
        """Return concrete type name at depth z."""
        if not self.depths:
            return ""
        name = self.concrete_names[0] if self.concrete_names else ""
        for i, d in enumerate(self.depths):
            if z >= d and self.concrete_names[i]:
                name = self.concrete_names[i]
        return name

    @property
    def height(self) -> float:
        if not self.depths:
            return 0.0
        return self.depths[-1] - self.depths[0]

    @property
    def z_bot(self) -> float:
        return self.depths[0] if self.depths else 0.0

    @property
    def z_top(self) -> float:
        return self.depths[-1] if self.depths else 0.0


def build_outline(beam: BeamSection) -> SectionOutline:
    """Build section outline from parsed BeamSection data.

    Section points are stored top-to-bottom in the file; we reverse to
    bottom-to-top (ascending depth).
    """
    pts = list(reversed(beam.section_points))
    outline = SectionOutline()
    current_name = ""
    for pt in pts:
        if pt.concrete_name:
            current_name = pt.concrete_name
        outline.depths.append(pt.depth)
        outline.widths.append(pt.width)
        outline.concrete_names.append(current_name)
    return outline


# ---------------------------------------------------------------------------
# Layer discretisation
# ---------------------------------------------------------------------------


@dataclass
class Layer:
    """A single layer in the discretised cross-section."""

    z_bot: float
    z_top: float
    width: float  # width at layer centroid
    concrete_name: str = ""

    # Resolved material and reinforcement (set by build_layers)
    node_mat: NodeMaterial | None = None

    @property
    def z_mid(self) -> float:
        return 0.5 * (self.z_bot + self.z_top)

    @property
    def dz(self) -> float:
        return self.z_top - self.z_bot

    @property
    def area(self) -> float:
        return self.width * self.dz


def _initial_layers(outline: SectionOutline, n_layers: int = 40) -> list[Layer]:
    """Create uniformly spaced initial layers."""
    z_bot = outline.z_bot
    z_top = outline.z_top
    dz = (z_top - z_bot) / n_layers
    layers: list[Layer] = []
    for i in range(n_layers):
        zb = z_bot + i * dz
        zt = z_bot + (i + 1) * dz
        zm = 0.5 * (zb + zt)
        w = outline.width_at(zm)
        if w < 1e-10:
            continue
        cname = outline.concrete_at(zm)
        layers.append(Layer(z_bot=zb, z_top=zt, width=w, concrete_name=cname))
    return layers


def _layers_from_node_depths(
    outline: SectionOutline, node_depths: list[float]
) -> list[Layer]:
    """Create layers from explicit node depth positions.

    node_depths: sorted list of z-coordinates (in our convention, bottom=0 up)
    defining layer boundaries.  N depths produce N-1 layers.
    """
    depths = sorted(node_depths)
    layers: list[Layer] = []
    for i in range(len(depths) - 1):
        zb = depths[i]
        zt = depths[i + 1]
        if zt - zb < 1e-10:
            continue
        zm = 0.5 * (zb + zt)
        w = outline.width_at(zm)
        if w < 1e-10:
            continue
        cname = outline.concrete_at(zm)
        layers.append(Layer(z_bot=zb, z_top=zt, width=w, concrete_name=cname))
    return layers


def _nodes_from_depths(
    outline: SectionOutline, node_depths: list[float]
) -> list[Layer]:
    """Create nodal pseudo-layers evaluated AT node positions.

    Matches R2K's approach: MCFT element evaluated at each node position (boundary);
    forces integrated element-by-element using the exact FEM linear-element formula
    (see _get_forces in solver.py, nodal=True path).

    Each Layer has z_mid = node_z and dz = 0 (zero thickness).  Integration weights
    are computed from adjacent node spacings at integration time, not stored here.
    """
    depths = sorted(node_depths)
    layers: list[Layer] = []
    for z in depths:
        w = outline.width_at(z)
        if w < 1e-10:
            continue
        cname = outline.concrete_at(z)
        # Zero-thickness node: z_bot = z_top = z → z_mid = z, dz = 0.
        layers.append(Layer(z_bot=z, z_top=z, width=w, concrete_name=cname))
    return layers


# ---------------------------------------------------------------------------
# Crack spacing (§7-5, CEB model)
# ---------------------------------------------------------------------------


def crack_spacing_x(
    z: float,
    long_reinf: list[LongReinf],
    outline: SectionOutline,
    section_height: float,
) -> float:
    """Longitudinal crack spacing s_x at depth z.

    CEB model: s = 2*c + 0.1 * d_b / p
    """
    if not long_reinf:
        return min(5.0 * section_height, 2000.0)

    # Find nearest bar layer and compute s
    best_s = 5.0 * section_height
    half_width = outline.width_at(z) * 0.5

    for bar in long_reinf:
        dz = abs(z - bar.z)
        # Diagonal distance from centroid to bar (approximate: assume bar at edge)
        c = math.sqrt(dz * dz + half_width * half_width) if half_width > 0 else dz

        db = bar.db
        if db is None or db <= 0:
            # Estimate from area and count
            if bar.num > 0 and bar.A > 0:
                ai = bar.A / bar.num
                db = 2.0 * math.sqrt(ai / math.pi)
            else:
                continue

        # Reinforcement ratio within 7.5*db zone
        zone_half = 7.5 * db
        zone_area = 0.0
        steel_area = 0.0
        for b in long_reinf:
            if abs(b.z - bar.z) <= zone_half:
                steel_area += b.A
        zone_width = outline.width_at(bar.z)
        zone_height = min(2.0 * zone_half, section_height)
        zone_area = zone_width * zone_height
        if zone_area <= 0:
            continue
        p = steel_area / zone_area
        if p <= 0:
            continue

        s = 2.0 * c + 0.1 * db / p
        best_s = min(best_s, s)

    return min(best_s, section_height)


def crack_spacing_y(trans_reinf: list[TransReinf], z: float) -> float:
    """Transverse crack spacing s_y at depth z.

    Governed by stirrup spacing in the zone containing z.
    """
    best = float("inf")
    for tr in trans_reinf:
        if tr.distbot <= z <= tr.disttop:
            best = min(best, tr.space)
    return best if best < float("inf") else 1000.0


# ---------------------------------------------------------------------------
# Nearest bar info for Eq 5-9 depth-varying tension stiffening
# ---------------------------------------------------------------------------


def _nearest_bar_info(
    z: float,
    long_reinf: list[LongReinf],
    outline: SectionOutline,
    section_height: float,
) -> tuple[float, float, float]:
    """Return (d_bar, s_m_bar, m_bar) for depth z.

    d_bar: distance (mm) from z to the nearest longitudinal bar.
    s_m_bar: crack spacing (mm) evaluated AT the nearest bar location.
    m_bar: bond parameter evaluated AT the nearest bar location.
    """
    if not long_reinf:
        return section_height, 0.0, 0.0

    best_dist = float("inf")
    best_bar = None
    for bar in long_reinf:
        d = abs(z - bar.z)
        if d < best_dist:
            best_dist = d
            best_bar = bar

    if best_bar is None:
        return section_height, 0.0, 0.0

    # Crack spacing and bond parameter at the bar location (not at z)
    s_m_bar = crack_spacing_x(best_bar.z, long_reinf, outline, section_height)
    m_bar = bond_parameter(best_bar.z, long_reinf, outline)

    return best_dist, s_m_bar, m_bar


# ---------------------------------------------------------------------------
# Bond parameter m (§2.4)
# ---------------------------------------------------------------------------


def bond_parameter(
    z: float,
    long_reinf: list[LongReinf],
    outline: SectionOutline,
    zone_depth: float = 143.0,
) -> float:
    """Bond parameter m = A_c / sum(pi * d_b_i) for tension stiffening.

    Computed for the zone around depth z.
    """
    sum_pi_db = 0.0
    for bar in long_reinf:
        if abs(bar.z - z) > zone_depth:
            continue
        db = bar.db
        if db is None or db <= 0:
            if bar.num > 0 and bar.A > 0:
                ai = bar.A / bar.num
                db = 2.0 * math.sqrt(ai / math.pi)
            else:
                continue
        n = bar.num if bar.num > 0 else 1
        sum_pi_db += n * math.pi * db

    if sum_pi_db <= 0:
        return 0.0

    # A_c = concrete area in the zone
    w = outline.width_at(z)
    Ac = w * min(2.0 * zone_depth, outline.height)
    return Ac / sum_pi_db


# ---------------------------------------------------------------------------
# Build layers with resolved NodeMaterial
# ---------------------------------------------------------------------------


def build_layers(
    beam: BeamSection,
    n_layers: int = 40,
    node_depths: list[float] | None = None,
    nodal: bool = False,
) -> tuple[SectionOutline, list[Layer]]:
    """Build discretised cross-section with resolved material at each layer.

    Parameters
    ----------
    beam : BeamSection
        Parsed cross-section data.
    n_layers : int
        Number of uniform layers (ignored if node_depths provided).
    node_depths : list[float] or None
        Explicit node/layer-boundary positions (z, bottom=0 upward).
    nodal : bool
        If True and node_depths is provided, evaluate the MCFT element AT each
        node position with trapezoidal integration weights (R2K's approach).
        If False (default), node_depths define layer boundaries and the element
        is evaluated at layer centroids.

    Returns the outline and a list of Layer objects with node_mat populated.
    """
    outline = build_outline(beam)
    if node_depths is not None:
        if nodal:
            layers = _nodes_from_depths(outline, node_depths)
        else:
            layers = _layers_from_node_depths(outline, node_depths)
    else:
        layers = _initial_layers(outline, n_layers)
    h = outline.height

    for layer in layers:
        z = layer.z_mid
        cname = layer.concrete_name
        conc = _resolve_concrete(beam, cname)

        # Derived concrete properties
        Ec = conc.Ec if conc.Ec else mat.concrete_elastic_modulus(conc.fcp)
        if conc.e0 is not None:
            e0 = conc.e0 * 1e-3  # convert from x1e-3 to absolute
        else:
            e0 = mat.concrete_strain_at_peak(conc.fcp, Ec)
        ft = conc.ft if conc.ft is not None else mat.cracking_strength(conc.fcp)

        # Smeared reinforcement ratios at this depth
        rho_x = _smeared_rho_x(z, beam.long_reinf, layer.width, layer.dz)
        rho_y, fy_y, Es_y, fu_y, esh_y, eu_y = _smeared_trans(
            z, beam.trans_reinf, beam.rebars, layer.width
        )
        fy_x, Es_x, fu_x, esh_x, eu_x = _dominant_long_steel(
            z, beam.long_reinf, beam.rebars
        )

        # Crack spacings
        sx = crack_spacing_x(z, beam.long_reinf, outline, h)
        sy = crack_spacing_y(beam.trans_reinf, z)
        m = bond_parameter(z, beam.long_reinf, outline)

        # Distance to nearest bar and crack spacing at that bar (for Eq 5-9)
        d_bar_val, s_m_bar_val, m_bar_val = _nearest_bar_info(
            z, beam.long_reinf, outline, h
        )

        layer.node_mat = NodeMaterial(
            fcp=conc.fcp,
            e0=e0,
            Ec=Ec,
            c_mod=conc.c_mod,
            c_soft=conc.c_soft,
            ft=ft,
            maxagg=conc.maxagg,
            rho_x=rho_x,
            rho_y=rho_y,
            fy_x=fy_x,
            Es_x=Es_x,
            fu_x=fu_x,
            esh_x=esh_x,
            eu_x=eu_x,
            fy_y=fy_y,
            Es_y=Es_y,
            fu_y=fu_y,
            esh_y=esh_y,
            eu_y=eu_y,
            s_x=sx,
            s_y=sy,
            m=m,
            tsfactor=conc.tsfactor,
            d_bar=d_bar_val,
            s_m_bar=s_m_bar_val,
            m_bar=m_bar_val,
        )

    return outline, layers


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------



def _resolve_concrete(beam: BeamSection, name: str) -> Concrete:
    """Look up concrete by name, falling back to first defined."""
    if name and name in beam.concretes:
        return beam.concretes[name]
    if beam.concretes:
        return next(iter(beam.concretes.values()))
    # Absolute fallback
    from .io import Concrete as ConcDC

    return ConcDC(name="default", fcp=30.0)


def _smeared_rho_x(
    z: float, long_reinf: list[LongReinf], width: float, dz: float
) -> float:
    """Smeared longitudinal steel ratio at depth z.

    Uses point assignment: each bar's full area goes to the layer containing
    bar.z.  R2K's adaptive layering places a layer centroid at each bar
    position, so this is consistent with R2K's approach.
    """
    if width <= 0 or dz <= 0:
        return 0.0
    area = 0.0
    z_bot = z - dz * 0.5
    z_top = z + dz * 0.5
    for bar in long_reinf:
        # Right-closed interval (z_bot, z_top]: bar at a layer boundary is assigned
        # to the lower layer (z_top), preventing double-counting when profile
        # depths coincide with bar positions.  Edge case: if bar is at or below
        # the section bottom (z_bot ≤ 0 effectively), include it.
        if (z_bot < bar.z <= z_top) or (bar.z == z_bot and z_bot <= 1e-9):
            area += bar.A
    return area / (width * dz)


def _smeared_trans(
    z: float,
    trans_reinf: list[TransReinf],
    rebars: dict,
    width: float,
) -> tuple[float, float, float, float | None, float, float]:
    """Smeared transverse steel ratio and properties at depth z.

    Returns (rho_y, fy_y, Es_y, fu_y, esh_y, eu_y).
    """
    total_rho = 0.0
    fy_y = 0.0
    Es_y = 200_000.0
    fu_y = None
    esh_y = 0.01
    eu_y = 0.1

    for tr in trans_reinf:
        if tr.distbot <= z <= tr.disttop and tr.space > 0 and width > 0:
            rho = tr.A / (tr.space * width)
            if rho > total_rho:
                total_rho = rho
                # Resolve rebar properties
                rmat = rebars.get(tr.type)
                if rmat:
                    fy_y = rmat.fy
                    Es_y = rmat.E
                    fu_y = rmat.fu
                    esh_y = rmat.esh * 1e-3  # convert x1e-3 to absolute
                    eu_y = rmat.eu * 1e-3
                else:
                    fy_y = 400.0

    return total_rho, fy_y, Es_y, fu_y, esh_y, eu_y


def _dominant_long_steel(
    z: float, long_reinf: list[LongReinf], rebars: dict
) -> tuple[float, float, float | None, float, float]:
    """Properties of the nearest longitudinal steel layer.

    Returns (fy_x, Es_x, fu_x, esh_x, eu_x).
    """
    best_dist = float("inf")
    fy_x = 400.0
    Es_x = 200_000.0
    fu_x = None
    esh_x = 0.01
    eu_x = 0.1

    for bar in long_reinf:
        dist = abs(bar.z - z)
        if dist < best_dist:
            best_dist = dist
            rmat = rebars.get(bar.type)
            if rmat:
                fy_x = rmat.fy
                Es_x = rmat.E
                fu_x = rmat.fu
                esh_x = rmat.esh * 1e-3
                eu_x = rmat.eu * 1e-3

    return fy_x, Es_x, fu_x, esh_x, eu_x
