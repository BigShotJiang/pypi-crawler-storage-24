"""Parser for Response-2000 chart-data exports (ODS format) and JSON profiles.

R2K's "Copy Chart Data" pastes a fixed-format block with:
- 10 header rows (title, axis labels, column headers)
- Data rows with X in column D (index 3) and Y in column J (index 9)
- Multi-segment plots separated by "Line type : N" rows
"""

from __future__ import annotations

import csv
import json
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

_NS = {
    "office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
    "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
    "text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
}

_TABLE_NS = "{urn:oasis:names:tc:opendocument:xmlns:table:1.0}"


@dataclass
class ChartSeries:
    """One line/segment from an R2K chart export."""

    line_type: int = 0
    x: list[float] = field(default_factory=list)
    y: list[float] = field(default_factory=list)
    x_label: str = ""
    y_label: str = ""
    x_unit: str = ""
    y_unit: str = ""
    title: str = ""


def _get_row_values(row: ET.Element) -> list[str]:
    """Extract cell text values from an ODS table row, handling column repeats."""
    vals: list[str] = []
    for cell in row.findall("table:table-cell", _NS):
        rep = int(cell.get(f"{_TABLE_NS}number-columns-repeated", "1"))
        txt = cell.findtext("text:p", "", _NS)
        # Cap repeats to avoid huge empty tails
        vals.extend([txt] * min(rep, 50))
    return vals


def _cell(vals: list[str], idx: int) -> str:
    return vals[idx].strip() if idx < len(vals) else ""


def read_r2k_ods(path: str | Path) -> dict[str, list[ChartSeries]]:
    """Read all sheets from an R2K chart-data ODS export.

    Returns a dict mapping sheet name → list of ChartSeries
    (one per line-type segment in the sheet).
    """
    path = Path(path)
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("content.xml"))

    body = root.find(".//office:spreadsheet", _NS)
    result: dict[str, list[ChartSeries]] = {}

    for table in body.findall("table:table", _NS):
        sheet_name = table.get(f"{_TABLE_NS}name", "")
        rows = table.findall("table:table-row", _NS)
        if len(rows) < 10:
            continue

        # Parse header (rows 0-8)
        title = " ".join(_get_row_values(rows[3])[2:]).strip(" :")
        x_parts = _get_row_values(rows[5])
        y_parts = _get_row_values(rows[6])
        x_label = " ".join(p for p in x_parts[5:] if p).strip()
        y_label = " ".join(p for p in y_parts[5:] if p).strip()

        # Parse data rows (from row 9 onward)
        series_list: list[ChartSeries] = []
        current: ChartSeries | None = None

        for row in rows[9:]:
            vals = _get_row_values(row)
            a = _cell(vals, 0)

            # Detect "Line type : N" marker
            if a == "Line":
                lt_str = _cell(vals, 3)
                lt = int(float(lt_str)) if lt_str else 0
                current = ChartSeries(
                    line_type=lt,
                    title=title,
                    x_label=x_label,
                    y_label=y_label,
                )
                series_list.append(current)
                continue

            if current is None:
                continue

            d = _cell(vals, 3)
            j = _cell(vals, 9)
            if d and j:
                try:
                    current.x.append(float(d))
                    current.y.append(float(j))
                except ValueError:
                    pass

        result[sheet_name] = series_list

    return result


def export_csv(
    series: ChartSeries,
    path: str | Path,
    x_header: str = "x",
    y_header: str = "y",
) -> None:
    """Write a single ChartSeries to a two-column CSV."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow([x_header, y_header])
        for xi, yi in zip(series.x, series.y):
            w.writerow([xi, yi])


# ---------------------------------------------------------------------------
# R2K JSON stage loader (from r2k_extract --full output)
# ---------------------------------------------------------------------------


@dataclass
class R2KStage:
    """Per-load-stage data extracted from an r2k_extract JSON file.

    Attributes
    ----------
    phi : float
        Curvature in rad/mm (converted from mrad/m in JSON).
    M_r2k : float
        Moment in N·mm (converted from kNm in JSON).
    V_r2k : float
        Shear in N (converted from kN in JSON).
    layer_depths : list[float]
        Layer centroid z-positions in mm (bottom = 0, top = section height).
        Derived from the Long Strain profile y-values (depth-from-centroid)
        via z = y - y_min so that z=0 is the bottom face.
    """

    phi: float
    M_r2k: float
    V_r2k: float
    layer_depths: list[float]


def load_r2k_stages(json_path: str | Path) -> list[R2KStage]:
    """Load per-stage analysis data from an r2k_extract JSON file.

    Parameters
    ----------
    json_path : path
        Path to the JSON file produced by ``tools/r2k_extract.py --full``.

    Returns
    -------
    list[R2KStage]
        One entry per R2K load stage, in order.  Layer depths are unique,
        sorted bottom-to-top, with z = 0 at the section bottom face.
    """
    with open(json_path) as f:
        data = json.load(f)

    # Control curves: phi (mrad/m → rad/mm) and forces (kN → N, kNm → N·mm)
    phi_vals = [p * 1e-6 for p in data["controls"]["moment"]["x"]]
    M_vals = [m * 1e6 for m in data["controls"]["moment"]["y"]]
    V_raw = data["controls"]["shear"]["y"]
    V_vals = [v * 1e3 for v in V_raw]

    n = len(phi_vals)
    stages: list[R2KStage] = []

    for stage_data in data["stages"]:
        # Map sampled stage back to its index in the control curve arrays.
        # The extractor stores "stage": target_index in each entry.
        ctrl_idx = stage_data.get("stage", 0)
        if ctrl_idx >= n:
            continue

        # Extract layer depths from the first available profile.
        # All profiles for a given stage share the same y-axis (depths).
        profiles = stage_data.get("profiles", [])
        y_raw: list[float] = []
        for prof in profiles:
            ys = prof.get("y", [])
            if ys:
                y_raw = ys
                break

        if y_raw:
            y_min = min(y_raw)
            # z = y - y_min  →  bottom face (y_min) maps to z = 0
            z_vals = sorted(set(round(y - y_min, 6) for y in y_raw))
        else:
            z_vals = []

        stages.append(R2KStage(
            phi=phi_vals[ctrl_idx],
            M_r2k=M_vals[ctrl_idx],
            V_r2k=V_vals[ctrl_idx],
            layer_depths=z_vals,
        ))

    return stages
