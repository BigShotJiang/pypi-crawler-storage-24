"""Longitudinal stiffness method: shear stress profile computation.

Reduced tangent stiffness, global J matrix assembly, virtual strain,
and shear flow integration from Bentz (2000) Chapter 6.
"""

from __future__ import annotations

import math

from .mcft import NodeMaterial, NodeState, stress_from_strain, tangent_stiffness
from .section import Layer, SectionOutline


# ---------------------------------------------------------------------------
# Reduced 2×2 tangent stiffness per node (§6-5, Eq. 6-4)
# ---------------------------------------------------------------------------


def reduced_stiffness(
    Dt: list[list[float]],
) -> tuple[float, float, float, float]:
    """Reduce 3×3 tangent [Dt] to 2×2 by imposing dNy=0.

    Returns (j, k, m_val, n_val) where:
    - j: d(Nx)/d(ex) at dNy=0
    - k: d(Nx)/d(gamma) at dNy=0
    - m_val: d(vxy)/d(ex) at dNy=0
    - n_val: d(vxy)/d(gamma) at dNy=0
    """
    a, b, c = Dt[0][0], Dt[0][1], Dt[0][2]
    d, e, f = Dt[1][0], Dt[1][1], Dt[1][2]
    g, h, k = Dt[2][0], Dt[2][1], Dt[2][2]

    if abs(e) < 1e-15:
        return a, c, g, k

    j = a - b * d / e
    kk = c - b * f / e
    m_val = g - h * d / e
    n_val = k - h * f / e
    return j, kk, m_val, n_val


def constrained_reduced_stiffness(
    ex: float,
    gamma_xy: float,
    nmat: NodeMaterial,
    state: NodeState,
    deps: float = 1e-7,
) -> tuple[float, float, float, float]:
    """Compute K'i by finite-differencing through transverse equilibrium.

    This gives the CORRECT j,k,m,n that account for ey adjusting
    to maintain fy=0 (Bentz thesis §6-5, Eq. 6-4).

    Returns (j, k, m_val, n_val).
    """
    from .solver import _transverse_equilibrium, SolverConfig

    config = SolverConfig(max_iter_trans=30, tol_force=1e-4)
    ey_base = state.ey

    # Base state
    fx0 = state.fx
    vxy0 = state.tau_xy

    # Perturb ex
    s_ex = _transverse_equilibrium(ex + deps, gamma_xy, nmat, config, ey_base)
    j = (s_ex.fx - fx0) / deps
    m_val = (s_ex.tau_xy - vxy0) / deps

    # Perturb gamma_xy
    s_gxy = _transverse_equilibrium(ex, gamma_xy + deps, nmat, config, ey_base)
    k = (s_gxy.fx - fx0) / deps
    n_val = (s_gxy.tau_xy - vxy0) / deps

    return j, k, m_val, n_val


# ---------------------------------------------------------------------------
# Global stiffness matrix J (§6-5) — 3×3 integrated over all layers
# ---------------------------------------------------------------------------


def assemble_J(
    layers: list[Layer],
    states: list[NodeState],
    outline: SectionOutline,
    shear_shape: list[float],
    z_centroid: float,
    use_constrained: bool = False,
    e0: float = 0.0,
    phi: float = 0.0,
    gamma_avg: float = 0.0,
) -> list[list[float]]:
    """Assemble the 3×3 global tangent stiffness matrix J.

    J maps [d(e0), d(phi), d(gamma_avg)] to [dN, dM, dV].

    When use_constrained=True, computes K'i by finite-differencing
    through transverse equilibrium (correct per Bentz §6-5).
    """
    J = [[0.0] * 3 for _ in range(3)]

    for i, (layer, state) in enumerate(zip(layers, states)):
        if layer.node_mat is None:
            continue

        if use_constrained:
            z = layer.z_mid - z_centroid
            ex = e0 - phi * z
            s = shear_shape[i] if i < len(shear_shape) else 1.0
            gamma_xy = gamma_avg * s
            j, k, m, n = constrained_reduced_stiffness(
                ex, gamma_xy, layer.node_mat, state
            )
        else:
            Dt = tangent_stiffness(state, layer.node_mat)
            j, k, m, n = reduced_stiffness(Dt)

        b = layer.width
        z = layer.z_mid - z_centroid  # height relative to centroid
        dz = layer.dz
        s = shear_shape[i] if i < len(shear_shape) else 1.0
        bdz = b * dz

        # J[0][*] — axial equilibrium
        J[0][0] += j * bdz
        J[0][1] += j * bdz * z
        J[0][2] += k * bdz * s

        # J[1][*] — moment equilibrium
        J[1][0] += j * bdz * z
        J[1][1] += j * bdz * z * z
        J[1][2] += k * bdz * z * s

        # J[2][*] — shear equilibrium (Bentz Eq 6-6, p.86)
        # No s in J[2][0],J[2][1] because dex/de0=1, dex/dphi=z (no shear shape)
        # One s in J[2][2] because dgamma_xy/dgamma_avg = s (chain rule)
        J[2][0] += m * bdz
        J[2][1] += m * bdz * z
        J[2][2] += n * bdz * s

    return J


# ---------------------------------------------------------------------------
# Solve for virtual strains and compute shear stress profile (§6-6)
# ---------------------------------------------------------------------------


def solve_virtual_strains(J: list[list[float]], V: float) -> list[float]:
    """Solve J * [de0, dphi, dgamma_avg] = [0, V, 0] for virtual strains.

    Uses 3×3 Gaussian elimination.
    """
    # Build augmented matrix
    A = [row[:] + [rhs] for row, rhs in zip(J, [0.0, V, 0.0])]
    n = 3

    for col in range(n):
        # Partial pivoting
        max_row = col
        for row in range(col + 1, n):
            if abs(A[row][col]) > abs(A[max_row][col]):
                max_row = row
        A[col], A[max_row] = A[max_row], A[col]

        if abs(A[col][col]) < 1e-30:
            continue

        for row in range(col + 1, n):
            factor = A[row][col] / A[col][col]
            for k in range(col, n + 1):
                A[row][k] -= factor * A[col][k]

    # Back substitution
    x = [0.0] * n
    for row in range(n - 1, -1, -1):
        if abs(A[row][row]) < 1e-30:
            continue
        x[row] = A[row][n]
        for col in range(row + 1, n):
            x[row] -= A[row][col] * x[col]
        x[row] /= A[row][row]

    return x


def shear_stress_profile(
    layers: list[Layer],
    states: list[NodeState],
    outline: SectionOutline,
    shear_shape: list[float],
    z_centroid: float,
    V_unit: float = 1.0,
) -> list[float]:
    """Compute shear stress at each layer centroid via longitudinal stiffness method.

    Returns tau(z) at each layer.
    """
    J = assemble_J(layers, states, outline, shear_shape, z_centroid)
    virt = solve_virtual_strains(J, V_unit)
    de0, dphi, dgamma = virt

    # Integrate shear flow q(z) from bottom
    # dq/dz at each layer from virtual strains
    tau = [0.0] * len(layers)
    q = 0.0  # cumulative shear flow

    for i, (layer, state) in enumerate(zip(layers, states)):
        if layer.node_mat is None:
            continue
        Dt = tangent_stiffness(state, layer.node_mat)
        j, k, m_val, n_val = reduced_stiffness(Dt)

        b = layer.width
        z = layer.z_mid - z_centroid
        s = shear_shape[i] if i < len(shear_shape) else 1.0
        dz = layer.dz

        # Rate of change of shear flow
        dq_dz = (j * de0 + j * z * dphi + k * s * dgamma) * b
        q += dq_dz * dz

        if b > 1e-10:
            tau[i] = q / b
        else:
            tau[i] = 0.0

    return tau


# ---------------------------------------------------------------------------
# Initial shear strain shape (elastic parabola)
# ---------------------------------------------------------------------------


def parabolic_shear_shape(layers: list[Layer], outline: SectionOutline) -> list[float]:
    """Initial elastic parabolic shear strain distribution.

    Shape = 1.5 * (1 - (2*z/h - 1)^2) for rectangular section,
    normalised so average = 1.0.
    """
    h = outline.height
    z_mid_sect = 0.5 * (outline.z_bot + outline.z_top)
    shape = []
    for layer in layers:
        z = layer.z_mid
        zn = (z - outline.z_bot) / h if h > 0 else 0.5  # normalised 0..1
        s = 1.5 * (1.0 - (2.0 * zn - 1.0) ** 2)
        shape.append(max(s, 0.0))

    # Normalise to average = 1.0
    if shape:
        avg = sum(shape) / len(shape)
        if avg > 1e-10:
            shape = [s / avg for s in shape]
    return shape


def update_shear_shape(
    layers: list[Layer],
    tau: list[float],
    states: list[NodeState],
) -> list[float]:
    """Convert shear stress profile to shear strain profile.

    gamma(z) = tau(z) / G_sec(z), then normalise to average = 1.0.
    """
    raw = []
    for i, (layer, state) in enumerate(zip(layers, states)):
        if layer.node_mat is None or abs(state.e1 - state.e2) < 1e-15:
            G = layer.node_mat.Ec * 0.4 if layer.node_mat else 10000.0
        else:
            G = 0.5 * (state.f1 - state.f2) / (state.e1 - state.e2)
        if abs(G) < 1e-10:
            G = 1e-10
        raw.append(tau[i] / G)

    # Normalise
    if raw:
        avg = sum(abs(r) for r in raw) / len(raw)
        if avg > 1e-15:
            raw = [r / avg for r in raw]
    return raw
