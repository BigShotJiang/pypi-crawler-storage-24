"""Outer loops: load stepping, section equilibrium, failure detection.

Four nested loops from Bentz (2000) Chapter 7, Figure 7-1:
  Loop 1: Idle-Dual — shear strain profile iteration
  Loop 2: Solve-Beam — global strain state via tangent stiffness
  Loop 3: Get-Forces — sectional force integration
  Loop 4: Transverse equilibrium — MCFT inner loop per layer
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field

from .io import BeamSection
from .longitudinal_stiffness import (
    assemble_J,
    parabolic_shear_shape,
    shear_stress_profile,
    solve_virtual_strains,
    update_shear_shape,
)
from .mcft import NodeMaterial, NodeState, stress_from_strain
from .section import Layer, SectionOutline, build_layers

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Load step result
# ---------------------------------------------------------------------------


@dataclass
class LoadStepResult:
    """Converged state at one load step."""

    phi: float = 0.0
    e0: float = 0.0
    gamma_avg: float = 0.0
    N: float = 0.0
    M: float = 0.0
    V: float = 0.0
    layer_states: list[NodeState] = field(default_factory=list)
    converged: bool = False


@dataclass
class AnalysisResult:
    """Full analysis output."""

    steps: list[LoadStepResult] = field(default_factory=list)
    failure_step: int = -1


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class SolverConfig:
    # Convergence: normalised force error < tol_force
    # For reference, Collins & Mitchell Table A-2 "Medium":
    #   N tol ≈ compressive_capacity / 1000
    #   V tol ≈ compressive_capacity / 500
    tol_force: float = 1e-4  # N error normalised by fcp*Ac
    tol_V_rel: float = 0.02  # V error normalised by target_V
    tol_shear_shape: float = 0.02
    max_iter_beam: int = 50
    max_iter_dual: int = 10
    max_iter_trans: int = 30
    n_steps: int = 100
    n_layers: int = 30  # R2K uses 30 uniform midpoint layers
    max_halvings: int = 5
    node_depths: list[float] | None = None  # explicit node positions (overrides n_layers)
    nodal: bool = False  # if True, evaluate at node positions with trapezoidal weights (R2K mode)


# ---------------------------------------------------------------------------
# Loop 4: Transverse equilibrium at a single node
# ---------------------------------------------------------------------------


def _transverse_equilibrium(
    ex: float, gamma_xy: float, nmat: NodeMaterial, config: SolverConfig,
    ey_prev: float | None = None,
    e1_crack_check: float | None = None,
) -> NodeState:
    """Find ey such that fy_total = 0 (transverse stress equilibrium).

    Uses secant stiffness iteration per §7 Loop 4.
    e1_crack_check: outer-fiber e1 passed to stress_from_strain for cracking detection.
    """
    from .mcft import secant_stiffness

    ey = ey_prev if ey_prev is not None else -0.15 * ex
    state = stress_from_strain(ex, ey, gamma_xy, nmat, e1_crack_check)

    for _ in range(config.max_iter_trans):
        fy = state.fy
        if abs(fy) < config.tol_force * max(abs(nmat.fcp), 1.0):
            break

        # Use D[1][1] (transverse secant stiffness) as dfy/dey
        D = secant_stiffness(state, nmat)
        Eyy = D[1][1]
        if abs(Eyy) < 1e-6:
            break

        ey_new = ey - fy / Eyy
        ey = ey_new
        state = stress_from_strain(ex, ey, gamma_xy, nmat, e1_crack_check)

    return state


# ---------------------------------------------------------------------------
# Loop 3: Get-Forces — integrate sectional forces
# ---------------------------------------------------------------------------


def _get_forces(
    e0: float,
    phi: float,
    gamma_avg: float,
    layers: list[Layer],
    shear_shape: list[float],
    z_centroid: float,
    config: SolverConfig,
    prev_states: list[NodeState] | None = None,
) -> tuple[float, float, float, list[NodeState]]:
    """Compute (N, M, V) by integrating over all layers.

    For each layer, compute (ex, gamma_xy) from global state + shear profile,
    then solve transverse equilibrium for ey.

    prev_states: if provided, use each layer's ey as initial guess for
    the transverse equilibrium iteration (dramatically improves convergence).

    Returns (N, M, V, list_of_layer_states).
    """
    N = 0.0
    M = 0.0
    V = 0.0
    states: list[NodeState] = []

    if config.nodal and layers and layers[0].dz == 0.0:
        # Nodal mode: evaluate MCFT at each node position (layer boundary).
        # No outer-fiber crack check — the node IS the section boundary.
        for i, layer in enumerate(layers):
            z = layer.z_mid - z_centroid
            ex = e0 - phi * z
            s = shear_shape[i] if i < len(shear_shape) else 1.0
            gamma_xy = gamma_avg * s
            nmat = layer.node_mat
            if nmat is None:
                states.append(NodeState())
                continue
            ey_prev = None
            if prev_states and i < len(prev_states):
                ey_prev = prev_states[i].ey
            states.append(_transverse_equilibrium(ex, gamma_xy, nmat, config, ey_prev))

        # Element-exact FEM integration (exact for linear element with quadratic
        # integrand — product of linear fx(z) × linear lever arm z).
        for i in range(len(layers) - 1):
            z_i = layers[i].z_mid
            z_ip1 = layers[i + 1].z_mid
            dz_elem = z_ip1 - z_i
            b_avg = (layers[i].width + layers[i + 1].width) / 2.0
            a_i = z_i - z_centroid    # lever arm from centroid
            a_ip1 = z_ip1 - z_centroid
            fx_i = states[i].fx
            fx_ip1 = states[i + 1].fx
            tau_i = states[i].tau_xy
            tau_ip1 = states[i + 1].tau_xy
            N += b_avg * dz_elem / 2.0 * (fx_i + fx_ip1)
            M -= b_avg * dz_elem / 6.0 * (
                fx_i * (2 * a_i + a_ip1) + fx_ip1 * (a_i + 2 * a_ip1)
            )
            V += b_avg * dz_elem / 2.0 * (tau_i + tau_ip1)

        return N, M, V, states

    for i, layer in enumerate(layers):
        z = layer.z_mid - z_centroid
        # Convention: positive phi = sagging = bottom tension
        ex = e0 - phi * z
        s = shear_shape[i] if i < len(shear_shape) else 1.0
        gamma_xy = gamma_avg * s

        nmat = layer.node_mat
        if nmat is None:
            states.append(NodeState())
            continue

        ey_prev = None
        if prev_states and i < len(prev_states):
            ey_prev = prev_states[i].ey

        # Outer-fiber cracking check (R2K checks at the section boundary of the
        # layer, not just the centroid).  For tensile layers (z < 0, i.e. below
        # centroid for sagging), the outer face is z_bot; for compressive layers
        # the outer face is z_top.  Compute e1_outer from the boundary strain.
        z_outer = layer.z_bot - z_centroid if z <= 0 else layer.z_top - z_centroid
        ex_outer = e0 - phi * z_outer
        # e1_outer: for pure-bending / low shear, e1 ≈ ex when ey ≈ 0.
        # Use ex_outer as a conservative outer-fiber e1 for crack detection.
        e1_outer = ex_outer  # approximation: e1 ≈ ex at the outer face

        state = _transverse_equilibrium(ex, gamma_xy, nmat, config, ey_prev, e1_outer)
        states.append(state)

        b = layer.width
        dz = layer.dz
        N += state.fx * b * dz
        M -= state.fx * b * dz * z  # positive M = sagging = bottom tension
        V += state.tau_xy * b * dz

    return N, M, V, states


# ---------------------------------------------------------------------------
# Loop 2: Solve-Beam — find (e0, phi, gamma_avg) for target load ratios
# ---------------------------------------------------------------------------


def _solve_beam(
    phi: float,
    target_N: float,
    av: float,
    layers: list[Layer],
    outline: SectionOutline,
    shear_shape: list[float],
    z_centroid: float,
    config: SolverConfig,
    prev_e0: float = 0.0,
    prev_gamma: float = 0.0,
    prev_step_states: list[NodeState] | None = None,
) -> tuple[float, float, float, float, float, list[NodeState], bool]:
    """Solve for (e0, gamma_avg) at given curvature phi.

    Uses the global tangent stiffness matrix J (Bentz Ch.6, Eq 6-6/6-7)
    as the Jacobian for Newton iteration, solving simultaneously for
    e0 and gamma_avg.  With phi prescribed, this is a 2×2 system.

    For pure bending (av=inf): 1×1 Newton on e0 using J[0][0].

    Returns (N, M, V, e0, gamma_avg, states, converged).
    """
    e0 = prev_e0
    gamma_avg = prev_gamma
    has_shear = av < float("inf")

    fcp = layers[0].node_mat.fcp if layers and layers[0].node_mat else 30.0
    if layers and layers[0].dz == 0.0:
        # Nodal mode: zero-thickness nodes — compute area by element trapezoidal rule
        Ac = sum(
            (layers[i].width + layers[i + 1].width) / 2.0 * (layers[i + 1].z_mid - layers[i].z_mid)
            for i in range(len(layers) - 1)
        )
    else:
        Ac = sum(l.area for l in layers)
    N_cap = max(fcp * Ac, 1.0)

    carry_states: list[NodeState] | None = prev_step_states

    # --- Phase A: converge e0 for N = target_N (finite-difference Newton) ---
    for it_n in range(config.max_iter_beam):
        N, M, V, states = _get_forces(
            e0, phi, gamma_avg, layers, shear_shape, z_centroid, config, carry_states
        )
        carry_states = states
        err_N = abs(N - target_N) / N_cap
        if err_N < config.tol_force:
            break
        de0 = max(abs(e0) * 0.001, 1e-7)
        N2, _, _, _ = _get_forces(
            e0 + de0, phi, gamma_avg, layers, shear_shape, z_centroid, config, carry_states
        )
        dN_de0 = (N2 - N) / de0
        if abs(dN_de0) > 1.0:
            e0 += (target_N - N) / dN_de0

    # --- Phase B: converge gamma_avg so V = M / av ---
    if has_shear:
        for it_v in range(config.max_iter_beam):
            N, M, V, states = _get_forces(
                e0, phi, gamma_avg, layers, shear_shape, z_centroid, config, carry_states
            )
            carry_states = states
            if abs(M) < 1e-3:
                break
            target_V = M / av
            err_V = abs(V - target_V) / max(abs(target_V), 1.0)
            if err_V < config.tol_force:
                break

            # Finite-difference shear tangent (constrained: includes transverse eq.)
            dg = max(abs(gamma_avg) * 0.001, 1e-7)
            _, M2, V2, _ = _get_forces(
                e0, phi, gamma_avg + dg, layers, shear_shape, z_centroid, config, carry_states
            )
            # Effective shear tangent accounting for M/av coupling
            dV_eff = (V2 - M2 / av) - (V - M / av)
            if abs(dV_eff / dg) > 1e-6:
                gamma_avg += 0.8 * (target_V - V) / (dV_eff / dg)

            # Re-converge e0 after gamma change
            for _ in range(10):
                N, M, V, states = _get_forces(
                    e0, phi, gamma_avg, layers, shear_shape, z_centroid, config, carry_states
                )
                carry_states = states
                if abs(N - target_N) / N_cap < config.tol_force:
                    break
                de0 = max(abs(e0) * 0.001, 1e-7)
                N2, _, _, _ = _get_forces(
                    e0 + de0, phi, gamma_avg, layers, shear_shape, z_centroid, config, carry_states
                )
                dN_de0 = (N2 - N) / de0
                if abs(dN_de0) > 1.0:
                    e0 += (target_N - N) / dN_de0
    else:
        N, M, V, states = _get_forces(
            e0, phi, gamma_avg, layers, shear_shape, z_centroid, config, carry_states
        )

    # Final convergence check
    err_N = abs(N - target_N) / N_cap
    target_V = M / av if has_shear else 0.0
    err_V_rel = abs(V - target_V) / max(abs(target_V), 1.0) if has_shear else 0.0
    converged = err_N < config.tol_force and err_V_rel < config.tol_V_rel

    return N, M, V, e0, gamma_avg, states, converged


# ---------------------------------------------------------------------------
# Loop 1 + load stepping: full section analysis
# ---------------------------------------------------------------------------


def analyse_section(
    beam: BeamSection,
    config: SolverConfig | None = None,
) -> AnalysisResult:
    """Run full sectional response analysis.

    Parameters
    ----------
    beam : BeamSection
        Parsed cross-section data.
    config : SolverConfig or None
        Solver parameters (uses defaults if None).
    """
    if config is None:
        config = SolverConfig()

    outline, layers = build_layers(beam, config.n_layers, config.node_depths, config.nodal)
    result = AnalysisResult()

    # Section centroid (elastic, uncracked)
    z_centroid = _elastic_centroid(layers)

    # Loading from sect_loading
    sl = beam.sect_loading
    target_N = 0.0
    av = float("inf")  # pure bending by default
    if sl:
        target_N = sl.BN
        av = sl.av  # shear span M/V in analysis length units

    # Estimate yield curvature
    phi_y = _estimate_yield_curvature(layers, outline, z_centroid)
    dphi = phi_y / 50.0

    # Initial shear strain profile
    shear_shape = parabolic_shear_shape(layers, outline)

    e0 = 0.0
    gamma_avg = 0.0
    prev_step_states: list[NodeState] | None = None
    for step_num in range(config.n_steps):
        phi = (step_num + 1) * dphi

        # Loop 1: Idle-Dual — iterate shear strain profile
        for dual_iter in range(config.max_iter_dual):
            N, M, V, e0, gamma_avg, states, converged = _solve_beam(
                phi, target_N, av,
                layers, outline, shear_shape, z_centroid, config,
                prev_e0=e0, prev_gamma=gamma_avg,
                prev_step_states=prev_step_states,
            )

            if not converged:
                break

            # Update shear strain profile
            if av < float("inf") and len(states) == len(layers):
                tau = shear_stress_profile(
                    layers, states, outline, shear_shape, z_centroid, V_unit=1.0
                )
                new_shape = update_shear_shape(layers, tau, states)

                # Check convergence of shape
                max_diff = 0.0
                for s_old, s_new in zip(shear_shape, new_shape):
                    max_diff = max(max_diff, abs(s_new - s_old))

                shear_shape = new_shape
                if max_diff < config.tol_shear_shape:
                    break
            else:
                break

        step = LoadStepResult(
            phi=phi, e0=e0, gamma_avg=gamma_avg,
            N=N, M=M, V=V,
            layer_states=states, converged=converged,
        )
        result.steps.append(step)

        if converged:
            prev_step_states = states

        if not converged:
            # Try halving step size from last converged phi
            last_conv_phi = result.steps[-2].phi if len(result.steps) >= 2 and result.steps[-2].converged else 0.0
            dphi_try = phi - last_conv_phi  # the step that failed
            recovered = False
            for _ in range(config.max_halvings):
                dphi_try *= 0.5
                phi_retry = last_conv_phi + dphi_try
                N, M, V, e0r, gamma_r, states_r, conv_r = _solve_beam(
                    phi_retry, target_N, av,
                    layers, outline, shear_shape, z_centroid, config,
                    prev_e0=e0, prev_gamma=gamma_avg,
                    prev_step_states=prev_step_states,
                )
                if conv_r:
                    dphi = dphi_try
                    e0 = e0r
                    gamma_avg = gamma_r
                    prev_step_states = states_r
                    # Update the failed step with the recovered result
                    result.steps[-1] = LoadStepResult(
                        phi=phi_retry, e0=e0r, gamma_avg=gamma_r,
                        N=N, M=M, V=V,
                        layer_states=states_r, converged=True,
                    )
                    recovered = True
                    break

            if not recovered:
                result.failure_step = step_num
                logger.info(
                    "Analysis stopped at step %d (phi=%.6e): convergence failure",
                    step_num, phi,
                )
                break

    return result


# ---------------------------------------------------------------------------
# Staged analysis: follow R2K's prescribed curvatures and layer positions
# ---------------------------------------------------------------------------


def analyse_section_staged(
    beam: BeamSection,
    r2k_stages: list,
    config: SolverConfig | None = None,
) -> AnalysisResult:
    """Run analysis at R2K's prescribed curvatures using R2K's layer positions.

    Parameters
    ----------
    beam : BeamSection
        Parsed cross-section data.
    r2k_stages : list[R2KStage]
        Ordered R2K stages from ``load_r2k_stages``.  Each must have:
        ``phi`` (rad/mm), ``layer_depths`` (list[float], mm, bottom=0).
    config : SolverConfig or None
        Solver parameters.  ``n_steps`` and ``n_layers`` are ignored;
        staging is driven entirely by ``r2k_stages``.

    Returns
    -------
    AnalysisResult
        One LoadStepResult per R2K stage; ``converged`` flag indicates
        whether our solver matched the prescribed equilibrium.
    """
    if config is None:
        config = SolverConfig()

    result = AnalysisResult()

    sl = beam.sect_loading
    target_N = sl.BN if sl else 0.0
    av = sl.av if sl else float("inf")

    e0 = 0.0
    gamma_avg = 0.0
    prev_step_states: list[NodeState] | None = None
    prev_n_layers = -1
    for stage_i, stage in enumerate(r2k_stages):
        phi = stage.phi

        # Rebuild layers from R2K's profile depths at this stage
        if stage.layer_depths and len(stage.layer_depths) >= 2:
            outline, layers = build_layers(
                beam, node_depths=stage.layer_depths, nodal=False
            )
        else:
            outline, layers = build_layers(beam, config.n_layers)

        z_centroid = _elastic_centroid(layers)
        shear_shape = parabolic_shear_shape(layers, outline)

        # Don't carry layer states across stages when layer count changes
        if len(layers) != prev_n_layers:
            prev_step_states = None
        prev_n_layers = len(layers)

        N, M, V = 0.0, 0.0, 0.0
        states: list[NodeState] = []
        converged = False

        # Loop 1: Idle-Dual
        for _dual_iter in range(config.max_iter_dual):
            N, M, V, e0, gamma_avg, states, converged = _solve_beam(
                phi, target_N, av,
                layers, outline, shear_shape, z_centroid, config,
                prev_e0=e0, prev_gamma=gamma_avg,
                prev_step_states=prev_step_states,
            )

            if not converged:
                break

            if av < float("inf") and len(states) == len(layers):
                tau = shear_stress_profile(
                    layers, states, outline, shear_shape, z_centroid, V_unit=1.0
                )
                new_shape = update_shear_shape(layers, tau, states)
                max_diff = 0.0
                for s_old, s_new in zip(shear_shape, new_shape):
                    max_diff = max(max_diff, abs(s_new - s_old))
                shear_shape = new_shape
                if max_diff < config.tol_shear_shape:
                    break
            else:
                break

        step = LoadStepResult(
            phi=phi, e0=e0, gamma_avg=gamma_avg,
            N=N, M=M, V=V,
            layer_states=states, converged=converged,
        )
        result.steps.append(step)

        if converged:
            prev_step_states = states
        else:
            if result.failure_step < 0:
                result.failure_step = stage_i
            # Continue — don't abort staged analysis on non-convergence

    return result


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _elastic_centroid(layers: list[Layer]) -> float:
    """Compute elastic centroid height."""
    # Nodal mode: layers have dz=0, use element-by-element integration.
    if layers and layers[0].dz == 0.0:
        sum_Az = 0.0
        sum_A = 0.0
        for i in range(len(layers) - 1):
            z_i = layers[i].z_mid
            z_ip1 = layers[i + 1].z_mid
            b_avg = (layers[i].width + layers[i + 1].width) / 2.0
            dz = z_ip1 - z_i
            sum_A += b_avg * dz
            # ∫z dz from z_i to z_{i+1} = (z_{i+1}^2 - z_i^2)/2
            sum_Az += b_avg * (z_ip1 * z_ip1 - z_i * z_i) / 2.0
        return sum_Az / sum_A if sum_A > 0 else 0.0

    sum_Az = 0.0
    sum_A = 0.0
    for layer in layers:
        A = layer.area
        sum_Az += A * layer.z_mid
        sum_A += A
    return sum_Az / sum_A if sum_A > 0 else 0.0


def _estimate_yield_curvature(
    layers: list[Layer], outline: SectionOutline, z_centroid: float
) -> float:
    """Rough estimate of yield curvature for step sizing.

    phi_y ≈ ey / (d - z_centroid) where d = depth to tension steel.
    """
    # Find deepest tension steel
    d = outline.z_bot
    ey = None
    for layer in layers:
        if layer.node_mat and layer.node_mat.rho_x > 0:
            if layer.z_mid < z_centroid:
                d = min(d, layer.z_mid)
                ey = layer.node_mat.fy_x / layer.node_mat.Es_x

    if ey is None:
        # Unreinforced section: use cracking curvature phi_cr = ft / (Ec * h/2).
        # With dphi = phi_cr/50 and 100 steps, covers ~2× phi_cr matching R2K range.
        ft = 2.7  # approximate fallback (0.45*sqrt(36))
        Ec = 27000.0
        for layer in layers:
            if layer.node_mat:
                ft = layer.node_mat.ft
                Ec = layer.node_mat.Ec
                break
        half_h = max(outline.height / 2.0, 1.0)
        return ft / (Ec * half_h)

    lever = abs(z_centroid - d)
    if lever < 1.0:
        lever = outline.height * 0.8
    return ey / lever
