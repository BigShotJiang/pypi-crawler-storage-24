"""MCFT inner loop: strain → stress, crack check, stiffness matrices.

Implements the biaxial stress-strain procedure from Bentz (2000) Chapters 3-4.
Operates on a single biaxial node / layer element.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from . import materials as mat


# ---------------------------------------------------------------------------
# Mohr's circle utilities
# ---------------------------------------------------------------------------


def principal_strains(
    ex: float, ey: float, gamma_xy: float
) -> tuple[float, float, float]:
    """Compute principal strains and angle from Cartesian strains.

    Returns
    -------
    e1 : float
        Principal tensile strain (algebraically larger).
    e2 : float
        Principal compressive strain (algebraically smaller).
    theta : float
        Angle (radians) of principal compression direction from x-axis.
    """
    avg = 0.5 * (ex + ey)
    diff = 0.5 * (ex - ey)
    radius = math.sqrt(diff * diff + (0.5 * gamma_xy) ** 2)
    e1 = avg + radius
    e2 = avg - radius
    if abs(ex - ey) < 1e-15:
        theta = math.pi / 4.0 if gamma_xy > 0 else -math.pi / 4.0
    else:
        theta = 0.5 * math.atan2(gamma_xy, ex - ey)
    return e1, e2, theta


def cartesian_from_principal(
    f1: float, f2: float, theta: float
) -> tuple[float, float, float]:
    """Rotate principal stresses back to x-y frame.

    Returns (fx, fy, tau_xy).
    """
    c = math.cos(theta)
    s = math.sin(theta)
    c2 = c * c
    s2 = s * s
    cs = c * s
    fx = f1 * c2 + f2 * s2
    fy = f1 * s2 + f2 * c2
    tau_xy = (f1 - f2) * cs
    return fx, fy, tau_xy


# ---------------------------------------------------------------------------
# Node material parameters — collected for convenience
# ---------------------------------------------------------------------------


@dataclass
class NodeMaterial:
    """Material and reinforcement properties at a single biaxial node."""

    # Concrete
    fcp: float
    e0: float
    Ec: float
    c_mod: int = 2
    c_soft: int = 1  # 0=None, 1=Collins-Bentz (default), 2=VC1982
    ft: float | None = None
    maxagg: float = 20.0

    # Reinforcement ratios (smeared)
    rho_x: float = 0.0
    rho_y: float = 0.0

    # Rebar x-direction
    fy_x: float = 0.0
    Es_x: float = 200_000.0
    fu_x: float | None = None
    esh_x: float = 0.01
    eu_x: float = 0.1

    # Rebar y-direction (transverse)
    fy_y: float = 0.0
    Es_y: float = 200_000.0
    fu_y: float | None = None
    esh_y: float = 0.01
    eu_y: float = 0.1

    # Crack spacings
    s_x: float = 300.0
    s_y: float = 300.0

    # Bond parameter and tension stiffening
    m: float = 100.0
    tsfactor: float = 1.0
    d_bar: float = 0.0      # distance (mm) to nearest longitudinal bar
    s_m_bar: float = 300.0   # crack spacing (mm) at the nearest bar location
    m_bar: float = 0.0      # bond parameter at the nearest bar location

    def __post_init__(self):
        if self.ft is None:
            self.ft = mat.cracking_strength(self.fcp)


# ---------------------------------------------------------------------------
# Node state — result of stress-from-strain
# ---------------------------------------------------------------------------


@dataclass
class NodeState:
    """Complete stress-strain state at a biaxial node."""

    # Input strains (Cartesian)
    ex: float = 0.0
    ey: float = 0.0
    gamma_xy: float = 0.0

    # Principal strains and angle
    e1: float = 0.0
    e2: float = 0.0
    theta: float = 0.0

    # Principal concrete stresses
    f1: float = 0.0
    f2: float = 0.0

    # Average steel stresses
    fsx: float = 0.0
    fsy: float = 0.0

    # Crack quantities
    s_theta: float = 0.0
    w: float = 0.0
    vci_max: float = 0.0

    # Total Cartesian stresses (concrete + steel)
    fx: float = 0.0
    fy: float = 0.0
    tau_xy: float = 0.0

    # Whether crack check governed f1 reduction
    crack_check_governed: bool = False


# ---------------------------------------------------------------------------
# Crack spacing at angle theta
# ---------------------------------------------------------------------------


def crack_spacing_theta(theta: float, s_x: float, s_y: float) -> float:
    """Diagonal crack spacing from x and y spacings (§5.1)."""
    sin_t = abs(math.sin(theta))
    cos_t = abs(math.cos(theta))
    denom = 0.0
    if s_x > 0:
        denom += sin_t / s_x
    if s_y > 0:
        denom += cos_t / s_y
    if denom < 1e-15:
        return max(s_x, s_y) if max(s_x, s_y) > 0 else 1000.0
    return 1.0 / denom


# ---------------------------------------------------------------------------
# Stress from strain — the core MCFT procedure (§3-4-1)
# ---------------------------------------------------------------------------


def stress_from_strain(
    ex: float, ey: float, gamma_xy: float, nmat: NodeMaterial,
    e1_crack_check: float | None = None,
) -> NodeState:
    """Compute complete stress state from strain state at a biaxial node.

    Implements §3-4-1 procedure:
    1. Principal strains via Mohr's circle
    2. Concrete principal stresses (compression + tension stiffening)
    3. Crack check
    4. Rotate back and add steel
    """
    state = NodeState(ex=ex, ey=ey, gamma_xy=gamma_xy)

    # 1. Principal strains
    e1, e2, theta = principal_strains(ex, ey, gamma_xy)
    state.e1 = e1
    state.e2 = e2
    state.theta = theta

    # 2a. Compressive principal stress f2 (e2 is compressive → positive for compression)
    ec = -e2  # convert to positive compression
    beta = mat.compression_softening(max(e1, 0.0), nmat.fcp, nmat.e0, nmat.c_soft)
    n = mat.concrete_n(nmat.fcp)
    f2_base = mat.concrete_compression(ec, nmat.fcp, nmat.e0, nmat.c_mod, n)
    f2 = -beta * f2_base  # negative = compression in our sign convention

    # 2b. Tensile principal stress f1
    # e1_crack_check: outer-fiber e1 for cracking condition (R2K checks outer fiber);
    # if None, uses centroid e1 (legacy behaviour).
    e1_chk = e1_crack_check if e1_crack_check is not None else e1
    if e1 <= 0.0:
        f1 = nmat.Ec * e1  # uncracked, linear elastic tension
    elif e1_chk <= nmat.ft / nmat.Ec:
        f1 = nmat.Ec * e1  # pre-cracking (outer fiber hasn't cracked)
    elif nmat.rho_x > 0 or nmat.rho_y > 0:
        # Tension stiffening at reinforced layers (Bentz Eq 5-8)
        f1 = mat.tension_stiffening(e1, nmat.ft, nmat.m, nmat.tsfactor)
    else:
        # Cracked, unreinforced layer — Bentz Eq 5-9:
        # Tension stiffening decays with distance from bar (Fig 5-15).
        # M_eff increases with distance, giving more softening.
        f1 = mat.tension_stiffening_eq59(
            e1, nmat.ft, nmat.m_bar, nmat.d_bar, nmat.s_m_bar, nmat.tsfactor,
        )

    state.f1 = f1
    state.f2 = f2

    # 3. Crack check
    state = _crack_check(state, nmat)

    # 4. Average steel stresses
    if nmat.rho_x > 0:
        state.fsx = mat.rebar_stress(ex, nmat.fy_x, nmat.Es_x, nmat.fu_x, nmat.esh_x, nmat.eu_x)
    if nmat.rho_y > 0:
        state.fsy = mat.rebar_stress(ey, nmat.fy_y, nmat.Es_y, nmat.fu_y, nmat.esh_y, nmat.eu_y)

    # 5. Rotate concrete stresses to x-y and add steel
    fcx, fcy, tau_c = cartesian_from_principal(state.f1, state.f2, theta)
    state.fx = fcx + nmat.rho_x * state.fsx
    state.fy = fcy + nmat.rho_y * state.fsy
    state.tau_xy = tau_c

    return state


# ---------------------------------------------------------------------------
# Crack check (Chapter 4, Table 4-1)
# ---------------------------------------------------------------------------


def _crack_check(state: NodeState, nmat: NodeMaterial) -> NodeState:
    """Check and enforce local equilibrium at crack surface.

    Only applies to layers with reinforcement — the crack check ensures
    that average stresses can be transmitted across a crack via steel
    and aggregate interlock.  Unreinforced layers have no cracks to check;
    their tension capacity is governed by the tension stiffening model.
    """
    e1 = state.e1
    if e1 <= 0.0:
        return state

    # Skip crack check for unreinforced layers
    if nmat.rho_x <= 0.0 and nmat.rho_y <= 0.0:
        return state

    theta = state.theta
    s_theta = crack_spacing_theta(theta, nmat.s_x, nmat.s_y)
    w = e1 * s_theta
    aeff = mat.effective_aggregate_size(nmat.maxagg, nmat.fcp)
    vci_max = mat.aggregate_interlock(nmat.fcp, w, aeff)

    state.s_theta = s_theta
    state.w = w
    state.vci_max = vci_max

    f1 = state.f1
    f2 = state.f2

    # Steel stresses at crack (local, not average)
    cos_t = math.cos(theta)
    sin_t = math.sin(theta)
    cos2 = cos_t * cos_t
    sin2 = sin_t * sin_t

    # Average steel stresses for crack check
    fsx_avg = mat.rebar_stress(
        state.ex, nmat.fy_x, nmat.Es_x, nmat.fu_x, nmat.esh_x, nmat.eu_x
    ) if nmat.rho_x > 0 else 0.0
    fsy_avg = mat.rebar_stress(
        state.ey, nmat.fy_y, nmat.Es_y, nmat.fu_y, nmat.esh_y, nmat.eu_y
    ) if nmat.rho_y > 0 else 0.0

    # Maximum f1 from aggregate interlock + reserve steel capacity
    fy_x = nmat.fy_x
    fy_y = nmat.fy_y
    rho_x = nmat.rho_x
    rho_y = nmat.rho_y

    # f1 limited by aggregate interlock (Eq. from §3.3)
    sin2t = math.sin(2.0 * theta)
    f1_agg = (
        rho_x * (fy_x - fsx_avg) * cos2
        + rho_y * (fy_y - fsy_avg) * sin2
        + vci_max * abs(sin2t)
    )

    # f1 limited by steel yielding at crack
    f1_steel_x = rho_x * (fy_x - fsx_avg) / cos2 if rho_x > 0 and cos2 > 1e-10 else float("inf")
    f1_steel_y = rho_y * (fy_y - fsy_avg) / sin2 if rho_y > 0 and sin2 > 1e-10 else float("inf")

    f1_max = min(f1, f1_agg, f1_steel_x, f1_steel_y)
    f1_max = max(f1_max, 0.0)

    if f1_max < f1:
        state.f1 = f1_max
        state.crack_check_governed = True

    return state


# ---------------------------------------------------------------------------
# Secant stiffness matrix (§3-5)
# ---------------------------------------------------------------------------


def secant_stiffness(state: NodeState, nmat: NodeMaterial) -> list[list[float]]:
    """3x3 secant stiffness [D] in x-y frame.

    Returns D such that {fx, fy, tau_xy} ≈ [D] * {ex, ey, gamma_xy}.
    Rows/cols ordered: [x, y, xy].
    """
    e1, e2, theta = state.e1, state.e2, state.theta

    # Concrete secant moduli in principal directions
    if abs(e1) > 1e-15:
        Ec1 = state.f1 / e1
    else:
        Ec1 = nmat.Ec

    if abs(e2) > 1e-15:
        Ec2 = state.f2 / e2
    else:
        Ec2 = nmat.Ec

    if abs(e1 - e2) > 1e-15:
        Gc12 = 0.5 * (state.f1 - state.f2) / (e1 - e2)
    else:
        Gc12 = 0.5 * nmat.Ec

    # Rotate to x-y frame
    c = math.cos(theta)
    s = math.sin(theta)
    c2 = c * c
    s2 = s * s
    cs = c * s

    D = [[0.0] * 3 for _ in range(3)]

    # [D_concrete] in x-y via rotation
    D[0][0] = Ec1 * c2 * c2 + Ec2 * s2 * s2 + 2 * Gc12 * (2 * cs) ** 2 / 4
    D[0][1] = Ec1 * c2 * s2 + Ec2 * s2 * c2 - 2 * Gc12 * (2 * cs) ** 2 / 4
    D[0][2] = (Ec1 - Ec2) * c2 * cs - (Ec1 - Ec2) * s2 * cs
    # Simplify: D[0][2] = (Ec1 - Ec2) * cs * (c2 - s2)

    D[1][0] = D[0][1]
    D[1][1] = Ec1 * s2 * s2 + Ec2 * c2 * c2 + 2 * Gc12 * (2 * cs) ** 2 / 4
    D[1][2] = (Ec1 - Ec2) * s2 * cs - (Ec1 - Ec2) * c2 * cs
    # Simplify: D[1][2] = -(Ec1 - Ec2) * cs * (c2 - s2)

    D[2][0] = D[0][2]
    D[2][1] = D[1][2]
    D[2][2] = (Ec1 + Ec2 - 2 * Gc12) * cs * cs + Gc12

    # Actually, use the standard rotation properly.
    # D_xy = T^T * D_princ * T, but for secant formulation it's simpler:
    # Using direct rotation of diagonal + shear modulus
    D[0][0] = Ec1 * c2 * c2 + Ec2 * s2 * s2 + Gc12 * 4 * c2 * s2
    D[0][1] = Ec1 * c2 * s2 + Ec2 * c2 * s2 - Gc12 * 4 * c2 * s2
    D[0][2] = Ec1 * c2 * cs - Ec2 * s2 * cs - Gc12 * 2 * cs * (c2 - s2)
    D[1][0] = D[0][1]
    D[1][1] = Ec1 * s2 * s2 + Ec2 * c2 * c2 + Gc12 * 4 * c2 * s2
    D[1][2] = Ec1 * s2 * cs - Ec2 * c2 * cs + Gc12 * 2 * cs * (c2 - s2)
    D[2][0] = D[0][2]
    D[2][1] = D[1][2]
    D[2][2] = (Ec1 + Ec2) * c2 * s2 + Gc12 * (c2 - s2) ** 2

    # Add steel contribution (diagonal)
    if nmat.rho_x > 0:
        Esx = mat.rebar_tangent(state.ex, nmat.fy_x, nmat.Es_x, nmat.fu_x, nmat.esh_x, nmat.eu_x)
        # Secant: use f/e if strain nonzero
        if abs(state.ex) > 1e-15:
            Esx_sec = state.fsx / state.ex
        else:
            Esx_sec = nmat.Es_x
        D[0][0] += nmat.rho_x * Esx_sec

    if nmat.rho_y > 0:
        if abs(state.ey) > 1e-15:
            Esy_sec = state.fsy / state.ey
        else:
            Esy_sec = nmat.Es_y
        D[1][1] += nmat.rho_y * Esy_sec

    return D


# ---------------------------------------------------------------------------
# Tangent stiffness matrix (§3-6)
# ---------------------------------------------------------------------------


def tangent_stiffness(
    state: NodeState, nmat: NodeMaterial, deps: float = 1e-8
) -> list[list[float]]:
    """3x3 tangent stiffness [Dt] in x-y frame (non-symmetric).

    Computed numerically: column j = d{stress}/d(strain_j).
    """
    ex, ey, gxy = state.ex, state.ey, state.gamma_xy
    strains = [ex, ey, gxy]
    Dt = [[0.0] * 3 for _ in range(3)]

    base = stress_from_strain(ex, ey, gxy, nmat)
    f_base = [base.fx, base.fy, base.tau_xy]

    for j in range(3):
        perturbed = list(strains)
        perturbed[j] += deps
        sp = stress_from_strain(perturbed[0], perturbed[1], perturbed[2], nmat)
        f_pert = [sp.fx, sp.fy, sp.tau_xy]
        for i in range(3):
            Dt[i][j] = (f_pert[i] - f_base[i]) / deps

    return Dt
