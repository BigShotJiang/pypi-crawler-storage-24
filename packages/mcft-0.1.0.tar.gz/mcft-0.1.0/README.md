# mcft

MCFT — Modified Compression Field Theory sectional analysis for Python
