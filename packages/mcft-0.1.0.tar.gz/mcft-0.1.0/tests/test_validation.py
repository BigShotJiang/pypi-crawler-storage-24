"""Validation tests — compare solver output against Response-2000 reference data."""

import csv
from pathlib import Path

import pytest

from mcft.io import read_rsp
from mcft.r2k_validation import read_r2k_ods
from mcft.solver import SolverConfig, analyse_section

EXAMPLES = Path(__file__).resolve().parent.parent / "examples"
VALIDATION = Path(__file__).resolve().parent / "validation"


def _load_csv(path):
    x, y = [], []
    with open(path) as f:
        for row in csv.DictReader(f):
            vals = list(row.values())
            x.append(float(vals[0]))
            y.append(float(vals[1]))
    return x, y


def _interpolate(x_target, xs, ys):
    """Linear interpolation of ys at x_target given sorted xs."""
    if x_target <= xs[0]:
        return ys[0]
    if x_target >= xs[-1]:
        return ys[-1]
    for i in range(len(xs) - 1):
        if xs[i] <= x_target <= xs[i + 1]:
            t = (x_target - xs[i]) / (xs[i + 1] - xs[i])
            return ys[i] + t * (ys[i + 1] - ys[i])
    return ys[-1]


def _run_case(rsp_path, section_idx=0, **config_kw):
    """Run solver and return converged steps."""
    model = read_rsp(rsp_path)
    beam = model.sections[section_idx]
    defaults = dict(n_steps=50, n_layers=30, max_iter_beam=80, max_halvings=8)
    defaults.update(config_kw)
    config = SolverConfig(**defaults)
    result = analyse_section(beam, config)
    return [s for s in result.steps if s.converged]


# ---------------------------------------------------------------------------
# dm-n1n.rsp — 375x750 rect, NSC 36 MPa, M:V=1.5:1.0
# R2K peak: M=555 kNm, V=370 kN
# ---------------------------------------------------------------------------


class TestDmN1NValidation:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.conv = _run_case(EXAMPLES / "dm-n1n.rsp")
        self.r2k_phi, self.r2k_M = _load_csv(VALIDATION / "dm-n1n_M_phi.csv")

    def test_has_converged_steps(self):
        assert len(self.conv) >= 10

    def test_peak_moment_order_of_magnitude(self):
        our_peak = max(s.M * 1e-6 for s in self.conv)
        assert 0.7 < our_peak / max(self.r2k_M) < 1.3

    def test_moment_curvature_midrange(self):
        our_phi = [s.phi * 1e6 for s in self.conv]
        our_M = [s.M * 1e-6 for s in self.conv]
        r2k_val = _interpolate(0.5, self.r2k_phi, self.r2k_M)
        our_val = _interpolate(0.5, our_phi, our_M)
        if r2k_val > 1.0:
            assert abs(our_val - r2k_val) / r2k_val < 0.25

    def test_mv_ratio(self):
        for s in self.conv:
            if abs(s.V) > 100.0:
                assert s.M / s.V == pytest.approx(1500.0, rel=0.10)


# ---------------------------------------------------------------------------
# Marshall.rsp — 305x610 rect, NSC 44 MPa, hogging M:V=-1:1
# R2K peak: |M|=477 kNm, |V|=477 kN
# ---------------------------------------------------------------------------


class TestMarshallValidation:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.conv = _run_case(EXAMPLES / "Marshall.rsp", section_idx=0)
        sheets = read_r2k_ods(VALIDATION / "Marshall.ods")
        self.r2k_V = [abs(v) for v in sheets["V_phi"][0].y]

    def test_has_converged_steps(self):
        assert len(self.conv) >= 15

    def test_peak_shear(self):
        """Peak |V| should match R2K within 10%."""
        our_peak = max(abs(s.V) * 1e-3 for s in self.conv)
        r2k_peak = max(self.r2k_V)
        ratio = our_peak / r2k_peak
        assert 0.85 < ratio < 1.15, f"|V| ratio: {ratio:.2f}"

    def test_mv_ratio(self):
        """M/V should equal av = MM/MV*1000 = -1000 mm (hogging)."""
        for s in self.conv:
            if abs(s.V) > 100.0:
                assert s.M / s.V == pytest.approx(-1000.0, rel=0.10)


# ---------------------------------------------------------------------------
# Liping LB1 V_ult=137kN — I-section, BN=-804 kN, M:V=0.7:1.0
# R2K peak: M=104 kNm, V=148 kN
# ---------------------------------------------------------------------------


class TestLipingLB1Validation:
    @pytest.fixture(autouse=True)
    def setup(self):
        # Section index 3 = "LB1 V_ult = 137 kN"
        self.conv = _run_case(EXAMPLES / "Liping LB1.rsp", section_idx=3)
        sheets = read_r2k_ods(VALIDATION / "Liping LB1 V_ult=137kN.ods")
        self.r2k_M = [abs(v) for v in sheets["M_phi"][0].y]
        self.r2k_V = [abs(v) for v in sheets["V_phi"][0].y]

    def test_has_converged_steps(self):
        assert len(self.conv) >= 5

    def test_peak_moment_order_of_magnitude(self):
        """Peak |M| within 50% of R2K (wide tolerance — axial + I-section)."""
        our_peak = max(abs(s.M) * 1e-6 for s in self.conv)
        r2k_peak = max(self.r2k_M)
        ratio = our_peak / r2k_peak
        assert 0.3 < ratio < 1.5, f"|M| ratio: {ratio:.2f}"


# ---------------------------------------------------------------------------
# R2K ODS parser tests
# ---------------------------------------------------------------------------


class TestR2KOdsParser:
    def test_reads_all_sheets(self):
        sheets = read_r2k_ods(VALIDATION / "dm-n1n.ods")
        assert "M_phi" in sheets
        assert "V_phi" in sheets

    def test_m_phi_data_count(self):
        sheets = read_r2k_ods(VALIDATION / "dm-n1n.ods")
        assert len(sheets["M_phi"][0].x) == 30

    def test_m_phi_peak(self):
        sheets = read_r2k_ods(VALIDATION / "dm-n1n.ods")
        assert max(sheets["M_phi"][0].y) == pytest.approx(555.4, rel=0.01)

    def test_marshall_parses(self):
        sheets = read_r2k_ods(VALIDATION / "Marshall.ods")
        assert "V_phi" in sheets
        assert max(abs(v) for v in sheets["V_phi"][0].y) == pytest.approx(476.5, rel=0.01)

    def test_liping_parses(self):
        sheets = read_r2k_ods(VALIDATION / "Liping LB1 V_ult=137kN.ods")
        assert "M_phi" in sheets

    def test_multi_segment_sheets(self):
        sheets = read_r2k_ods(VALIDATION / "dm-n1n.ods")
        assert len(sheets["gamma_100"]) >= 2
