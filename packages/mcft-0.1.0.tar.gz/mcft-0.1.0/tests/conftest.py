"""Shared test fixtures."""

from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
EXAMPLES_DIR = REPO_ROOT / "examples"
VALIDATION_DIR = Path(__file__).resolve().parent / "validation"


@pytest.fixture
def examples_dir():
    return EXAMPLES_DIR


@pytest.fixture
def validation_dir():
    return VALIDATION_DIR
