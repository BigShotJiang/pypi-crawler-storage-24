"""Tests for mcft.section — geometry, layering, crack spacing."""

from pathlib import Path

import pytest

from mcft.io import read_rsp
from mcft.section import build_layers, build_outline

EXAMPLES = Path(__file__).resolve().parent.parent / "examples"


class TestOutlineDmN1N:
    @pytest.fixture(autouse=True)
    def setup(self):
        model = read_rsp(EXAMPLES / "dm-n1n.rsp")
        self.beam = model.sections[0]
        self.outline = build_outline(self.beam)

    def test_height(self):
        assert self.outline.height == pytest.approx(750.0)

    def test_width_at_mid(self):
        assert self.outline.width_at(375.0) == pytest.approx(375.0)

    def test_width_at_bottom(self):
        assert self.outline.width_at(0.0) == pytest.approx(375.0)

    def test_width_at_top(self):
        assert self.outline.width_at(750.0) == pytest.approx(375.0)


class TestLayersDmN1N:
    @pytest.fixture(autouse=True)
    def setup(self):
        model = read_rsp(EXAMPLES / "dm-n1n.rsp")
        self.beam = model.sections[0]
        self.outline, self.layers = build_layers(self.beam)

    def test_layer_count(self):
        assert len(self.layers) == 40

    def test_layers_span_full_depth(self):
        assert self.layers[0].z_bot == pytest.approx(0.0)
        assert self.layers[-1].z_top == pytest.approx(750.0)

    def test_all_layers_have_node_mat(self):
        for layer in self.layers:
            assert layer.node_mat is not None
            assert layer.node_mat.fcp == 36.0
            assert layer.node_mat.Ec > 0

    def test_bottom_reinf_layer(self):
        # Bars at z=65 and z=125 — find layers containing them
        reinf_layers = [l for l in self.layers if l.node_mat.rho_x > 0]
        assert len(reinf_layers) >= 2  # at least the two bottom bar layers

    def test_transverse_reinf(self):
        # Stirrups from 44 to 714 — mid layers should have rho_y > 0
        mid = self.layers[len(self.layers) // 2]
        assert mid.node_mat.rho_y > 0

    def test_crack_spacing_positive(self):
        for layer in self.layers:
            assert layer.node_mat.s_x > 0
            assert layer.node_mat.s_y > 0


class TestOutlineISection:
    """Test I-section geometry from Liping LB1."""

    @pytest.fixture(autouse=True)
    def setup(self):
        model = read_rsp(EXAMPLES / "Liping LB1.rsp")
        self.beam = model.sections[0]
        self.outline = build_outline(self.beam)

    def test_height(self):
        assert self.outline.height == pytest.approx(500.0)

    def test_narrow_web(self):
        # Web at z=200 should be narrow (~75mm)
        w = self.outline.width_at(200.0)
        assert w < 100.0

    def test_wide_flange(self):
        # Top flange at z=480 should be wide (~350mm)
        w = self.outline.width_at(480.0)
        assert w > 300.0
