"""Tests for mcft.materials — constitutive relations."""

import math

import pytest

from mcft.materials import (
    aggregate_interlock,
    compression_softening,
    compression_softening_deriv_e1,
    concrete_compression,
    concrete_compression_parabolic,
    concrete_compression_popovics,
    concrete_elastic_modulus,
    concrete_n,
    concrete_strain_at_peak,
    cracking_strength,
    effective_aggregate_size,
    prestress_stress,
    rebar_stress,
    rebar_tangent,
    tension_stiffening,
    tension_stiffening_poor,
)


# ---------------------------------------------------------------------------
# Concrete elastic properties
# ---------------------------------------------------------------------------


class TestConcreteElastic:
    def test_Ec_36MPa(self):
        Ec = concrete_elastic_modulus(36.0)
        assert Ec == pytest.approx(3320 * math.sqrt(36) + 6900, rel=1e-6)

    def test_n_36MPa(self):
        assert concrete_n(36.0) == pytest.approx(0.8 + 36 / 17, rel=1e-6)

    def test_n_75MPa(self):
        assert concrete_n(75.0) == pytest.approx(0.8 + 75 / 17, rel=1e-6)

    def test_strain_at_peak(self):
        fcp = 36.0
        Ec = concrete_elastic_modulus(fcp)
        n = concrete_n(fcp)
        expected = fcp * n / (Ec * (n - 1.0))
        assert concrete_strain_at_peak(fcp) == pytest.approx(expected, rel=1e-6)


# ---------------------------------------------------------------------------
# Compression base curves
# ---------------------------------------------------------------------------


class TestConcreteCompression:
    def test_popovics_at_peak(self):
        fcp, e0 = 36.0, 0.002
        n = concrete_n(fcp)
        # At ec = e0, ratio=1, fc = fcp * 1 * n / (n - 1 + 1) = fcp
        assert concrete_compression_popovics(e0, fcp, e0, n) == pytest.approx(fcp, rel=1e-6)

    def test_popovics_zero_strain(self):
        assert concrete_compression_popovics(0.0, 36.0, 0.002, 2.9) == 0.0

    def test_popovics_post_peak_drops(self):
        fcp, e0 = 36.0, 0.002
        n = concrete_n(fcp)
        at_peak = concrete_compression_popovics(e0, fcp, e0, n)
        past_peak = concrete_compression_popovics(2 * e0, fcp, e0, n)
        assert past_peak < at_peak

    def test_parabolic_at_peak(self):
        fcp, e0 = 75.0, 0.0025
        # At peak: 2*1 - 1^2 = 1, so fc = fcp
        assert concrete_compression_parabolic(e0, fcp, e0) == pytest.approx(fcp, rel=1e-6)

    def test_parabolic_at_half_peak(self):
        fcp, e0 = 75.0, 0.002
        ec = e0 / 2.0
        r = 0.5
        expected = fcp * (2 * r - r * r)
        assert concrete_compression_parabolic(ec, fcp, e0) == pytest.approx(expected, rel=1e-6)

    def test_parabolic_post_peak_descends(self):
        fcp, e0 = 75.0, 0.002
        at_peak = concrete_compression_parabolic(e0, fcp, e0)
        past = concrete_compression_parabolic(0.003, fcp, e0)
        assert past < at_peak

    def test_linear_at_peak(self):
        assert concrete_compression(0.002, 36.0, 0.002, c_mod=0) == pytest.approx(36.0)

    def test_linear_half(self):
        assert concrete_compression(0.001, 36.0, 0.002, c_mod=0) == pytest.approx(18.0)

    def test_dispatch_c_mod_2(self):
        fcp, e0 = 36.0, 0.002
        assert concrete_compression(e0, fcp, e0, c_mod=2) == pytest.approx(fcp, rel=1e-6)


# ---------------------------------------------------------------------------
# Compression softening
# ---------------------------------------------------------------------------


class TestCompressionSoftening:
    def test_no_tension(self):
        assert compression_softening(0.0, 36.0) == 1.0

    def test_collins_bentz_default(self):
        """Default (c_soft=1): beta = 1/(0.8 + 0.34*e1/e0)."""
        e1, e0 = 0.002, 0.002
        expected = 1.0 / (0.8 + 0.34 * e1 / e0)
        assert compression_softening(e1, 36.0, e0) == pytest.approx(expected, rel=1e-6)

    def test_c_soft_none(self):
        """c_soft=0 (None): beta = 1.0, no compression softening."""
        e1 = 0.003
        assert compression_softening(e1, 36.0, e0=0.002, c_soft=0) == pytest.approx(1.0)

    def test_collins_bentz_equals_vc82_at_e0_002(self):
        """When e0=0.002, Collins-Bentz gives same result as VC1982."""
        e1 = 0.003
        beta_cb = compression_softening(e1, 36.0, e0=0.002, c_soft=1)
        beta_vc = compression_softening(e1, 36.0, e0=0.002, c_soft=2)
        assert beta_cb == pytest.approx(beta_vc, rel=1e-6)

    def test_vecchio_collins_1982(self):
        """c_soft=2: beta = 1/(0.8 + 170*e1), independent of e0."""
        e1 = 0.002
        expected = 1.0 / (0.8 + 170 * e1)
        assert compression_softening(e1, 36.0, c_soft=2) == pytest.approx(expected, rel=1e-6)

    def test_capped_at_one(self):
        assert compression_softening(1e-10, 36.0) == pytest.approx(1.0, abs=1e-6)

    def test_hsc_90(self):
        e1 = 0.001
        beta_nsc = 1.0 / (0.8 + 0.34 * e1 / 0.002)
        hsc_factor = 0.9 - 90.0 / 250.0
        expected = beta_nsc * hsc_factor
        assert compression_softening(e1, 90.0, e0=0.002) == pytest.approx(expected, rel=1e-6)

    def test_transition_between_nsc_and_hsc(self):
        e1 = 0.002
        beta_60 = compression_softening(e1, 60.0)
        beta_90 = compression_softening(e1, 90.0)
        beta_75 = compression_softening(e1, 75.0)
        assert beta_90 < beta_75 < beta_60

    def test_derivative_collins_bentz(self):
        e1, e0 = 0.002, 0.002
        k = 0.34 / e0
        dbeta = compression_softening_deriv_e1(e1, 36.0, e0)
        denom = 0.8 + k * e1
        expected = -k / (denom * denom)
        assert dbeta == pytest.approx(expected, rel=1e-6)


# ---------------------------------------------------------------------------
# Effective aggregate size
# ---------------------------------------------------------------------------


class TestEffectiveAggregate:
    def test_nsc(self):
        assert effective_aggregate_size(20.0, 36.0) == 20.0

    def test_hsc_80(self):
        assert effective_aggregate_size(20.0, 80.0) == 0.0

    def test_hsc_100(self):
        assert effective_aggregate_size(20.0, 100.0) == 0.0

    def test_transition_70(self):
        expected = 20.0 * (1.0 - (70.0 - 60.0) / 20.0)
        assert effective_aggregate_size(20.0, 70.0) == pytest.approx(expected)


# ---------------------------------------------------------------------------
# Cracking and tension stiffening
# ---------------------------------------------------------------------------


class TestTension:
    def test_cracking_strength_36(self):
        expected = 0.45 * math.sqrt(36.0)
        assert cracking_strength(36.0) == pytest.approx(expected, rel=1e-6)

    def test_tension_stiffening_at_crack(self):
        ft = 2.0
        m = 50.0
        e1 = 0.0001
        expected = ft / (1.0 + math.sqrt(3.6 * m * e1))
        assert tension_stiffening(e1, ft, m) == pytest.approx(expected, rel=1e-6)

    def test_tension_stiffening_zero_strain(self):
        assert tension_stiffening(0.0, 2.0, 50.0) == 0.0

    def test_tension_stiffening_no_reinforcement(self):
        assert tension_stiffening(0.001, 2.0, 0.0) == 0.0

    def test_tsfactor(self):
        ft, m, e1 = 2.0, 50.0, 0.001
        full = tension_stiffening(e1, ft, m, tsfactor=1.0)
        half = tension_stiffening(e1, ft, m, tsfactor=0.5)
        assert half == pytest.approx(0.5 * full, rel=1e-6)

    def test_poor_zone_at_bar(self):
        # xi=0 should give 2x the well-reinforced value
        ft, m, e1 = 2.0, 50.0, 0.001
        well = tension_stiffening(e1, ft, m)
        poor_at_bar = tension_stiffening_poor(e1, ft, m, xi=0.0)
        assert poor_at_bar == pytest.approx(2.0 * well, rel=1e-6)

    def test_poor_zone_beyond(self):
        assert tension_stiffening_poor(0.001, 2.0, 50.0, xi=0.6) == 0.0


# ---------------------------------------------------------------------------
# Aggregate interlock
# ---------------------------------------------------------------------------


class TestAggregateInterlock:
    def test_basic(self):
        fcp, w, aeff = 36.0, 0.1, 20.0
        expected = 0.18 * math.sqrt(36.0) / (0.31 + 24.0 * 0.1 / (20.0 + 16.0))
        assert aggregate_interlock(fcp, w, aeff) == pytest.approx(expected, rel=1e-6)

    def test_zero_width(self):
        assert aggregate_interlock(36.0, 0.0, 20.0) == float("inf")

    def test_larger_crack_lower_interlock(self):
        v1 = aggregate_interlock(36.0, 0.1, 20.0)
        v2 = aggregate_interlock(36.0, 0.5, 20.0)
        assert v2 < v1


# ---------------------------------------------------------------------------
# Reinforcement
# ---------------------------------------------------------------------------


class TestRebar:
    def test_elastic(self):
        E = 200_000.0
        fy = 400.0
        es = fy / (2 * E)  # half yield
        assert rebar_stress(es, fy, E) == pytest.approx(E * es, rel=1e-6)

    def test_yield_plateau(self):
        fy, E = 400.0, 200_000.0
        ey = fy / E
        es = ey + 0.005  # on plateau (esh=10e-3)
        assert rebar_stress(es, fy, E, esh=0.01) == pytest.approx(fy, rel=1e-6)

    def test_hardening(self):
        fy, E, fu = 400.0, 200_000.0, 600.0
        esh, eu = 0.01, 0.1
        es = 0.055  # midpoint of hardening
        fs = rebar_stress(es, fy, E, fu, esh, eu)
        assert fy < fs < fu

    def test_ultimate(self):
        fy, fu = 400.0, 600.0
        # All strains in absolute units: esh=0.01, eu=0.1, es=0.15 > eu
        assert rebar_stress(0.15, fy, fu=fu, esh=0.01, eu=0.1) == pytest.approx(fu)

    def test_compression(self):
        fy, E = 400.0, 200_000.0
        es = -fy / (2 * E)
        assert rebar_stress(es, fy, E) == pytest.approx(-E * abs(es), rel=1e-6)

    def test_tangent_elastic(self):
        assert rebar_tangent(0.0005, 400.0) == pytest.approx(200_000.0)

    def test_tangent_plateau(self):
        fy, E = 400.0, 200_000.0
        ey = fy / E
        assert rebar_tangent(ey + 0.005, fy, E, esh=0.01) == 0.0

    def test_default_fu(self):
        fy = 400.0
        # fu defaults to 1.5*fy = 600, es=0.15 > eu=0.1 → returns fu
        fs = rebar_stress(0.15, fy, esh=0.01, eu=0.1)
        assert fs == pytest.approx(600.0)


# ---------------------------------------------------------------------------
# Prestressing steel
# ---------------------------------------------------------------------------


class TestPrestress:
    def test_initial_slope(self):
        Ep = 190_000.0
        ep = 0.0001  # small strain → should approach Ep * ep
        fp = prestress_stress(ep, fu=1860.0, Ep=Ep)
        assert fp == pytest.approx(Ep * ep, rel=0.01)

    def test_capped_at_fu(self):
        fp = prestress_stress(0.1, fu=1860.0)
        assert fp <= 1860.0

    def test_zero_strain(self):
        assert prestress_stress(0.0, fu=1860.0) == 0.0

    def test_monotonic_increase(self):
        strains = [0.001, 0.003, 0.005, 0.008, 0.01, 0.02]
        stresses = [prestress_stress(e, fu=1860.0) for e in strains]
        for i in range(len(stresses) - 1):
            assert stresses[i + 1] >= stresses[i]
