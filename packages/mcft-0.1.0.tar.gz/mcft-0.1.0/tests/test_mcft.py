"""Tests for mcft.mcft — MCFT inner loop."""

import math

import pytest

from mcft.mcft import (
    NodeMaterial,
    cartesian_from_principal,
    crack_spacing_theta,
    principal_strains,
    secant_stiffness,
    stress_from_strain,
    tangent_stiffness,
)


# ---------------------------------------------------------------------------
# Mohr's circle
# ---------------------------------------------------------------------------


class TestPrincipalStrains:
    def test_uniaxial_tension(self):
        e1, e2, theta = principal_strains(0.001, 0.0, 0.0)
        assert e1 == pytest.approx(0.001)
        assert e2 == pytest.approx(0.0)
        assert theta == pytest.approx(0.0, abs=1e-10)

    def test_uniaxial_compression(self):
        e1, e2, theta = principal_strains(-0.002, 0.0, 0.0)
        assert e1 == pytest.approx(0.0)
        assert e2 == pytest.approx(-0.002)

    def test_pure_shear(self):
        e1, e2, theta = principal_strains(0.0, 0.0, 0.002)
        assert e1 == pytest.approx(0.001)
        assert e2 == pytest.approx(-0.001)
        assert abs(theta) == pytest.approx(math.pi / 4, rel=1e-6)

    def test_equal_biaxial(self):
        e1, e2, _ = principal_strains(0.001, 0.001, 0.0)
        assert e1 == pytest.approx(0.001)
        assert e2 == pytest.approx(0.001)

    def test_round_trip(self):
        """Principal stresses rotated back should match original."""
        f1, f2, theta = 5.0, -30.0, math.radians(35)
        fx, fy, tau = cartesian_from_principal(f1, f2, theta)
        # Recover principals from Cartesian via Mohr's circle on stresses
        avg = 0.5 * (fx + fy)
        diff = 0.5 * (fx - fy)
        radius = math.sqrt(diff**2 + tau**2)
        assert avg + radius == pytest.approx(f1, rel=1e-10)
        assert avg - radius == pytest.approx(f2, rel=1e-10)


# ---------------------------------------------------------------------------
# Crack spacing
# ---------------------------------------------------------------------------


class TestCrackSpacing:
    def test_45_degrees(self):
        s_x, s_y = 200.0, 150.0
        theta = math.pi / 4
        expected = 1.0 / (math.sin(theta) / s_x + math.cos(theta) / s_y)
        assert crack_spacing_theta(theta, s_x, s_y) == pytest.approx(expected)

    def test_zero_angle(self):
        # theta=0 → sin=0, cos=1 → s_theta = s_y
        assert crack_spacing_theta(0.0, 200.0, 150.0) == pytest.approx(150.0)

    def test_90_degrees(self):
        # theta=pi/2 → sin=1, cos=0 → s_theta = s_x
        assert crack_spacing_theta(math.pi / 2, 200.0, 150.0) == pytest.approx(200.0)


# ---------------------------------------------------------------------------
# Stress from strain — basic cases
# ---------------------------------------------------------------------------


def _make_rc_node(
    fcp: float = 36.0,
    rho_x: float = 0.025,
    rho_y: float = 0.003,
    fy_x: float = 400.0,
    fy_y: float = 400.0,
) -> NodeMaterial:
    """Standard RC node for testing."""
    Ec = 3320 * math.sqrt(fcp) + 6900
    e0 = fcp * (0.8 + fcp / 17) / (Ec * (0.8 + fcp / 17 - 1))
    return NodeMaterial(
        fcp=fcp,
        e0=e0,
        Ec=Ec,
        rho_x=rho_x,
        rho_y=rho_y,
        fy_x=fy_x,
        fy_y=fy_y,
        Es_x=200_000.0,
        Es_y=200_000.0,
        esh_x=0.01,
        eu_x=0.1,
        esh_y=0.01,
        eu_y=0.1,
        s_x=200.0,
        s_y=150.0,
        m=80.0,
    )


class TestStressFromStrain:
    def test_uncracked_elastic(self):
        nmat = _make_rc_node()
        # Small strain — should be in uncracked regime
        state = stress_from_strain(0.00005, -0.00001, 0.0, nmat)
        # Check stresses are reasonable
        assert state.f1 > 0
        assert state.f2 < 0 or abs(state.f2) < 1e-6
        assert state.e1 >= state.e2

    def test_cracked_with_shear(self):
        nmat = _make_rc_node()
        # Larger strains with shear — cracked regime
        state = stress_from_strain(0.002, -0.001, 0.003, nmat)
        assert state.e1 > 0
        assert state.e2 < 0
        assert state.w > 0
        assert state.s_theta > 0

    def test_zero_strain(self):
        nmat = _make_rc_node()
        state = stress_from_strain(0.0, 0.0, 0.0, nmat)
        assert state.fx == pytest.approx(0.0, abs=1e-10)
        assert state.fy == pytest.approx(0.0, abs=1e-10)
        assert state.tau_xy == pytest.approx(0.0, abs=1e-10)

    def test_pure_compression(self):
        nmat = _make_rc_node(rho_x=0.0, rho_y=0.0)
        state = stress_from_strain(-0.002, 0.0, 0.0, nmat)
        # fx should be compressive (negative)
        assert state.fx < 0

    def test_transverse_stress_unreinforced(self):
        nmat = _make_rc_node(rho_y=0.0)
        state = stress_from_strain(0.001, -0.0005, 0.001, nmat)
        # fy should have no steel contribution
        # Just check it runs without error
        assert isinstance(state.fy, float)

    def test_crack_check_reduces_f1(self):
        nmat = _make_rc_node(rho_y=0.001)  # light stirrups
        # Large tensile strain and shear → crack check likely governs
        state = stress_from_strain(0.005, -0.001, 0.008, nmat)
        # If crack check governed, f1 should be limited
        # Just verify it runs and f1 >= 0
        assert state.f1 >= 0


# ---------------------------------------------------------------------------
# Stiffness matrices
# ---------------------------------------------------------------------------


class TestSecantStiffness:
    def test_shape(self):
        nmat = _make_rc_node()
        state = stress_from_strain(0.001, -0.0005, 0.001, nmat)
        D = secant_stiffness(state, nmat)
        assert len(D) == 3
        assert all(len(row) == 3 for row in D)

    def test_positive_diagonal(self):
        nmat = _make_rc_node()
        state = stress_from_strain(0.001, -0.0005, 0.001, nmat)
        D = secant_stiffness(state, nmat)
        # Diagonal should be positive (stiffness)
        for i in range(3):
            assert D[i][i] > 0


class TestTangentStiffness:
    def test_shape(self):
        nmat = _make_rc_node()
        state = stress_from_strain(0.001, -0.0005, 0.001, nmat)
        Dt = tangent_stiffness(state, nmat)
        assert len(Dt) == 3
        assert all(len(row) == 3 for row in Dt)

    def test_matches_secant_at_small_strain(self):
        nmat = _make_rc_node()
        # At very small strain, secant ≈ tangent
        state = stress_from_strain(1e-6, -1e-7, 1e-7, nmat)
        D = secant_stiffness(state, nmat)
        Dt = tangent_stiffness(state, nmat)
        # Should be similar (not exact due to numerical differences)
        for i in range(3):
            if abs(D[i][i]) > 1:
                assert Dt[i][i] == pytest.approx(D[i][i], rel=0.1)
