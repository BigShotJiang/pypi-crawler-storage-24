"""Integration test — parse and analyse dm-n1n.rsp end-to-end."""

from pathlib import Path

import pytest

from mcft.io import read_rsp
from mcft.solver import SolverConfig, analyse_section

EXAMPLES = Path(__file__).resolve().parent.parent / "examples"


class TestDmN1NAnalysis:
    """Run a short analysis on dm-n1n.rsp (validation priority 1).

    375x750 mm rect, NSC 36 MPa, MM=1.5, MV=1.0.
    """

    @pytest.fixture(autouse=True)
    def run_analysis(self):
        model = read_rsp(EXAMPLES / "dm-n1n.rsp")
        beam = model.sections[0]
        config = SolverConfig(n_steps=10, n_layers=20, max_iter_beam=50)
        self.result = analyse_section(beam, config)

    def test_has_converged_steps(self):
        conv = [s for s in self.result.steps if s.converged]
        assert len(conv) >= 5

    def test_first_step_converged(self):
        assert self.result.steps[0].converged

    def test_moment_increases(self):
        moments = [s.M for s in self.result.steps if s.converged]
        assert moments[-1] > moments[0]

    def test_shear_proportional_to_moment(self):
        """M/V should equal the shear span av = MM/MV * 1000 = 1500 mm."""
        for s in self.result.steps:
            if s.converged and abs(s.V) > 1.0:
                av = s.M / s.V
                assert av == pytest.approx(1500.0, rel=0.05)

    def test_layer_states_populated(self):
        assert len(self.result.steps[0].layer_states) == 20
