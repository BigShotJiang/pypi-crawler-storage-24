"""Tests for mcft.io — XML .rsp parser."""

from pathlib import Path

import pytest

from mcft.io import read_rsp

EXAMPLES = Path(__file__).resolve().parent.parent / "examples"


# ---------------------------------------------------------------------------
# dm-n1n.rsp — simplest case, validation priority 1
# ---------------------------------------------------------------------------


class TestDmN1N:
    @pytest.fixture(autouse=True)
    def model(self):
        self.m = read_rsp(EXAMPLES / "dm-n1n.rsp")

    def test_section_count(self):
        assert len(self.m.sections) == 1

    def test_beam_name(self):
        assert "N1-N" in self.m.sections[0].name

    def test_concrete(self):
        s = self.m.sections[0]
        assert len(s.concretes) == 1
        c = s.concretes["Concrete"]
        assert c.fcp == 36.0
        assert c.maxagg == 20.0
        assert c.c_mod == 2  # default Popovics
        assert c.ft is None
        assert c.e0 is None

    def test_rebars(self):
        s = self.m.sections[0]
        assert len(s.rebars) == 3
        assert s.rebars["long"].fy == 410.0
        assert s.rebars["No 8"].fu == 504.0
        assert s.rebars["No 9.5"].eu == 170.0

    def test_prestress(self):
        s = self.m.sections[0]
        assert len(s.prestress) == 1

    def test_section_geometry(self):
        pts = self.m.sections[0].section_points
        assert len(pts) == 2
        assert pts[0].depth == 750.0
        assert pts[0].width == 375.0
        assert pts[1].depth == 0.0
        assert pts[1].width == 375.0
        assert pts[1].concrete_name == "Concrete"

    def test_long_reinf(self):
        lr = self.m.sections[0].long_reinf
        assert len(lr) == 3
        assert lr[0].z == 65.0
        assert lr[0].A == 3500.0
        assert lr[0].num == 5
        assert lr[0].type == "long"
        assert lr[2].z == 705.0
        assert lr[2].A == 200.0
        assert lr[2].num == 2

    def test_trans_reinf(self):
        tr = self.m.sections[0].trans_reinf
        assert len(tr) == 1
        assert tr[0].A == 100.0
        assert tr[0].pattern == 2  # closed stirrup
        assert tr[0].space == 325.0
        assert tr[0].Ai == 50.0
        assert tr[0].db == 8.0

    def test_elem_info(self):
        ei = self.m.sections[0].elem_info
        assert ei is not None
        assert ei.L == 2122.5

    def test_sect_loading(self):
        sl = self.m.sections[0].sect_loading
        assert sl is not None
        assert sl.MM == 1.5
        assert sl.MV == 1.0
        assert sl.BN == 0.0

    def test_member_analysis(self):
        ma = self.m.member_analysis
        assert ma is not None
        assert ma.length == 5000.0
        assert ma.leftanchor == "straightbar"

    def test_bmd_count(self):
        ma = self.m.member_analysis
        assert len(ma.bmds) == 2
        assert not ma.bmds[0].isconstant
        assert ma.bmds[1].isconstant
        assert ma.bmds[1].type == "dead"

    def test_bmd_variable_points(self):
        pts = self.m.member_analysis.bmds[0].points
        assert len(pts) == 3
        assert pts[0].position == 350.0
        assert pts[1].moment == 1.0
        assert pts[2].flag == 0

    def test_mat_zones(self):
        zones = self.m.member_analysis.mat_zones
        assert len(zones) == 1
        assert "N1-N" in zones[0].section_name

    def test_supports(self):
        sups = self.m.member_analysis.supports
        assert len(sups) == 2
        assert sups[0].which == "left"
        assert sups[0].platelocate == 350.0
        assert sups[1].support == "pin"


# ---------------------------------------------------------------------------
# Marshall.rsp — multiple sections, hoops, empty sectloading
# ---------------------------------------------------------------------------


class TestMarshall:
    @pytest.fixture(autouse=True)
    def model(self):
        self.m = read_rsp(EXAMPLES / "Marshall.rsp")

    def test_section_count(self):
        assert len(self.m.sections) == 5

    def test_concrete_fcp(self):
        assert self.m.sections[0].concretes["Concrete 1"].fcp == 44.0

    def test_hoop_pattern(self):
        tr = self.m.sections[0].trans_reinf[0]
        assert tr.pattern == 3  # hoop

    def test_empty_sectloading(self):
        # "Jeff Marshall:Positive-high" has <sectloading />
        sl = self.m.sections[3].sect_loading
        assert sl is not None
        assert sl.MM == 0.0
        assert sl.MV == 0.0

    def test_member_analysis_displocate(self):
        ma = self.m.member_analysis
        assert ma.displocate == 3429.0
        assert ma.topplatesize == 279.0

    def test_mat_zone_names(self):
        zones = self.m.member_analysis.mat_zones
        assert len(zones) == 5
        assert "Both" in zones[2].section_name


# ---------------------------------------------------------------------------
# se100am69.rsp — HSC, c_mod=1, prestress with Ramberg-Osgood
# ---------------------------------------------------------------------------


class TestSe100am69:
    @pytest.fixture(autouse=True)
    def model(self):
        self.m = read_rsp(EXAMPLES / "se100am69.rsp")

    def test_section_count(self):
        assert len(self.m.sections) == 2

    def test_c_mod_linear(self):
        # se100am69.rsp has c_mod=1 (R2K "Linear") → internal 0 (Linear)
        c = self.m.sections[0].concretes["Beam"]
        assert c.c_mod == 0
        assert c.fcp == 75.0

    def test_second_section_default_c_mod(self):
        # "8 bars" concrete has no c_mod attr → default Popovics (2)
        c = self.m.sections[1].concretes["Beam"]
        assert c.c_mod == 2

    def test_prestress_ramberg_osgood(self):
        p = self.m.sections[0].prestress["P-Steel"]
        assert p.A == 0.030
        assert p.B == 121.0
        assert p.C == 6.0
        assert p.eu == 40.0


# ---------------------------------------------------------------------------
# Liping LB1.rsp — axial load, e0 override, pattern=7, shrinktherm
# ---------------------------------------------------------------------------


class TestLipingLB1:
    @pytest.fixture(autouse=True)
    def model(self):
        self.m = read_rsp(EXAMPLES / "Liping LB1.rsp")

    def test_section_count(self):
        assert len(self.m.sections) == 5

    def test_axial_load(self):
        sl = self.m.sections[0].sect_loading
        assert sl.BN == -804.0

    def test_e0_override(self):
        c = list(self.m.sections[0].concretes.values())[0]
        assert c.e0 == 2.10

    def test_pattern_7(self):
        # Should parse without error; pattern stored as 7
        tr = self.m.sections[0].trans_reinf[0]
        assert tr.pattern == 7

    def test_shrink_therm(self):
        # "LB1 With Shrinkage" section (index 4)
        st = self.m.sections[4].shrink_therm
        assert st is not None
        assert len(st.profile) == 2
        assert st.profile[0] == (500.0, -0.690)

    def test_rebar_custom_E(self):
        r = self.m.sections[0].rebars["15M"]
        assert r.E == 201_100.0

    def test_i_section_geometry(self):
        pts = self.m.sections[0].section_points
        assert len(pts) == 23
        assert pts[0].depth == 500.0
        assert pts[-1].depth == 0.0

    def test_member_axial_load_on_bmd(self):
        ma = self.m.member_analysis
        dead_bmd = [b for b in ma.bmds if b.isconstant][0]
        assert dead_bmd.axial_load == -804.0


# ---------------------------------------------------------------------------
# Cm4.rsp — segmental concrete (c_mod=4), prestress with drape, c_soft=5
# ---------------------------------------------------------------------------


class TestCm4:
    @pytest.fixture(autouse=True)
    def model(self):
        self.m = read_rsp(EXAMPLES / "Cm4.rsp")

    def test_section_count(self):
        assert len(self.m.sections) == 5

    def test_segmental_concrete(self):
        c = self.m.sections[0].concretes["confined"]
        assert c.c_mod == 4
        assert c.curve is not None
        assert len(c.curve) == 27
        assert c.curve[0] == (0.0, 0.0)
        assert c.curve[-1] == (10.0, 50.0)

    def test_ft_override(self):
        c = self.m.sections[0].concretes["confined"]
        assert c.ft == 2.20

    def test_c_soft_5(self):
        # Panel D has R2K c_soft=5 (Maekawa et al), mapped to internal 1 (Collins-Bentz fallback)
        c = self.m.sections[4].concretes["Concrete"]
        assert c.c_soft == 1

    def test_prestress_drape(self):
        lr = self.m.sections[1].long_reinf
        drape_bars = [b for b in lr if b.drape != 0.0]
        assert len(drape_bars) >= 1
        # Panel A bottom tendon drape = 1.49
        bot = next(b for b in lr if b.name == "bottom")
        assert bot.drape == pytest.approx(1.49)

    def test_prestress_dep(self):
        lr = self.m.sections[0].long_reinf
        bot = next(b for b in lr if b.name == "bottom")
        assert bot.dep == 6.40

    def test_member_analysis(self):
        ma = self.m.member_analysis
        assert ma.length == 11000.0
        assert ma.topplatesize == 200.0
        assert len(ma.mat_zones) == 4

    def test_multiple_trans_reinf(self):
        tr = self.m.sections[0].trans_reinf
        assert len(tr) == 3


# ---------------------------------------------------------------------------
# Super-T1.r2t — no stirrups, c_soft=2, fixedverticalroller support
# ---------------------------------------------------------------------------


class TestSuperT1:
    @pytest.fixture(autouse=True)
    def model(self):
        self.m = read_rsp(EXAMPLES / "Super-T1.r2t")

    def test_section_count(self):
        assert len(self.m.sections) == 1

    def test_c_soft_2(self):
        c = list(self.m.sections[0].concretes.values())[0]
        assert c.c_soft == 2
        assert c.fcp == 65.0
        assert c.maxagg == 19.0

    def test_no_stirrups(self):
        assert len(self.m.sections[0].trans_reinf) == 0

    def test_empty_sectloading(self):
        sl = self.m.sections[0].sect_loading
        assert sl is not None
        assert sl.MM == 0.0

    def test_support_type(self):
        sups = self.m.member_analysis.supports
        roller = next(s for s in sups if s.which == "right")
        assert roller.support == "fixedverticalroller"

    def test_section_geometry(self):
        pts = self.m.sections[0].section_points
        assert len(pts) == 9
        assert pts[0].depth == 930.0
        assert pts[0].width == 2100.0
