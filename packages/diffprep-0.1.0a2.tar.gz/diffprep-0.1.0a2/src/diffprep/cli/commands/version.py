from importlib.metadata import PackageNotFoundError, version

import typer

try:
    VERSION = version("diffprep")
except PackageNotFoundError:
    VERSION = "0.0.0-dev"


def version_command() -> None:
    if version:
        typer.echo(VERSION)
        raise typer.Exit()
