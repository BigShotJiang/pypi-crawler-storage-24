"""Custom exceptions for db-test-helpers."""


class UnsupportedError(Exception):
    """Raised when an adapter does not support a requested feature."""
