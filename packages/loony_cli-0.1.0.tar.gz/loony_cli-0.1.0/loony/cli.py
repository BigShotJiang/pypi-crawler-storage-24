"""Loony CLI — governed data services for agents."""

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from . import __version__, api, auth, config

app = typer.Typer(
    name="loony",
    help="Governed data services for agents.",
    no_args_is_help=True,
)
console = Console()


@app.callback(invoke_without_command=True)
def main(
    version: bool = typer.Option(False, "--version", "-v", help="Show version"),
):
    if version:
        console.print(f"loony {__version__}")
        raise typer.Exit()


@app.command()
def login(
    env: Optional[str] = typer.Option(None, "--env", "-e", help="Environment to login to"),
):
    """Authenticate with loony.dev via browser."""
    env = env or config.get_current_env()
    console.print(f"Logging into [bold]{env}[/bold]...")
    console.print("Opening browser...")

    try:
        user = auth.login(env)
        console.print(f"\n[green]✓[/green] Logged in as [bold]{user['email']}[/bold]")
        console.print(f"  User ID: {user['user_id']}")
        console.print(f"  Environment: {env}")
    except Exception as e:
        console.print(f"\n[red]✗[/red] Login failed: {e}")
        raise typer.Exit(1)


@app.command()
def logout(
    env: Optional[str] = typer.Option(None, "--env", "-e", help="Environment to logout from"),
):
    """Clear stored credentials."""
    env = env or config.get_current_env()
    config.clear_credentials(env)
    console.print(f"[green]✓[/green] Logged out from [bold]{env}[/bold]")


@app.command()
def env(
    name: Optional[str] = typer.Argument(None, help="Environment to switch to"),
):
    """Show or switch the current environment."""
    if name:
        config.set_current_env(name)
        console.print(f"[green]✓[/green] Switched to [bold]{name}[/bold]")
    else:
        current = config.get_current_env()
        cfg = config.load()
        envs = cfg.get("environments", {})

        table = Table(title="Environments")
        table.add_column("Name")
        table.add_column("Endpoint")
        table.add_column("User")
        table.add_column("Active")

        for env_name in set(config.DEFAULTS.keys()) | set(envs.keys()):
            env_config = config.get_env_config(env_name)
            endpoint = env_config.get("endpoint", "")
            email = env_config.get("email", "")
            active = "→" if env_name == current else ""
            table.add_row(env_name, endpoint or "(not configured)", email or "(not logged in)", active)

        console.print(table)


@app.command()
def status():
    """Check connection to control plane and show user info."""
    current = config.get_current_env()
    env_config = config.get_env_config()

    console.print(f"Environment: [bold]{current}[/bold]")
    console.print(f"Endpoint: {env_config.get('endpoint', '(not configured)')}")
    console.print()

    # Health check
    try:
        h = api.health()
        console.print(f"[green]✓[/green] Control plane: {h.get('status', 'unknown')}")
    except Exception as e:
        console.print(f"[red]✗[/red] Control plane: {e}")
        raise typer.Exit(1)

    # Auth check
    try:
        user = api.me()
        console.print(f"[green]✓[/green] Authenticated as: {user.get('email')}")
        console.print(f"  User ID: {user.get('user_id')}")
    except ValueError as e:
        console.print(f"[yellow]⚠[/yellow] {e}")
    except Exception as e:
        console.print(f"[red]✗[/red] Auth failed: {e}")


if __name__ == "__main__":
    app()
