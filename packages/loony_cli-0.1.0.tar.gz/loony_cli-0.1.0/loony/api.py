"""HTTP client for talking to the control plane."""

import httpx

from . import config


def _get_client(env: str | None = None) -> tuple[httpx.Client, dict]:
    env_config = config.get_env_config(env)
    endpoint = env_config.get("endpoint")
    token = env_config.get("access_token")

    if not endpoint:
        raise ValueError(f"No endpoint configured for environment '{config.get_current_env()}'")
    if not token:
        raise ValueError("Not logged in. Run 'loony login' first.")

    client = httpx.Client(
        base_url=endpoint,
        headers={"Authorization": f"Bearer {token}"},
        timeout=30,
    )
    return client, env_config


def me(env: str | None = None) -> dict:
    client, _ = _get_client(env)
    resp = client.get("/api/me")
    resp.raise_for_status()
    return resp.json()


def health(env: str | None = None) -> dict:
    env_config = config.get_env_config(env)
    endpoint = env_config.get("endpoint")
    if not endpoint:
        raise ValueError(f"No endpoint configured for environment '{config.get_current_env()}'")

    resp = httpx.get(f"{endpoint}/healthz", timeout=10)
    resp.raise_for_status()
    return resp.json()
