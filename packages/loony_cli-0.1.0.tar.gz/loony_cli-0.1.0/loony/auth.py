"""WorkOS browser-redirect login flow.

The CLI handles the browser redirect and captures the auth code.
The control plane exchanges the code for tokens (it has the API key).
"""

import http.server
import urllib.parse
import webbrowser

import httpx

from . import config

REDIRECT_URI = "http://localhost:9876/callback"


def login(env: str | None = None):
    """Open browser for WorkOS login, send code to control plane, save credentials."""
    env = env or config.get_current_env()
    env_config = config.get_env_config(env)

    endpoint = env_config.get("endpoint")
    if not endpoint:
        raise ValueError(f"No endpoint configured for environment '{env}'")

    # Step 1: Get auth URL from control plane
    resp = httpx.get(f"{endpoint}/api/auth/url", params={"redirect_uri": REDIRECT_URI}, timeout=10)
    resp.raise_for_status()
    auth_url = resp.json()["url"]

    # Step 2: Open browser + capture callback code
    result = {}

    class CallbackHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)

            if "code" in params:
                result["code"] = params["code"][0]
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    b"<html><body style='font-family:system-ui;text-align:center;padding:60px'>"
                    b"<h1>Logged in!</h1><p>You can close this tab.</p></body></html>"
                )
            else:
                error = params.get("error", ["unknown"])[0]
                result["error"] = error
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(f"<html><body>Error: {error}</body></html>".encode())

        def log_message(self, format, *args):
            pass

    server = http.server.HTTPServer(("localhost", 9876), CallbackHandler)
    webbrowser.open(auth_url)
    server.handle_request()
    server.server_close()

    if "error" in result:
        raise RuntimeError(f"Login failed: {result['error']}")

    # Step 3: Send code to control plane for exchange
    resp = httpx.post(
        f"{endpoint}/api/auth/callback",
        json={"code": result["code"], "redirect_uri": REDIRECT_URI},
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()

    # Step 4: Save credentials
    config.save_credentials(env, {
        "user_id": data["user_id"],
        "email": data["email"],
        "first_name": data.get("first_name"),
        "last_name": data.get("last_name"),
        "access_token": data["access_token"],
        "refresh_token": data.get("refresh_token"),
    })

    return data
