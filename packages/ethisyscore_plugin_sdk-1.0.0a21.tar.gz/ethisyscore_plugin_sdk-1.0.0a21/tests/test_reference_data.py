"""
Comprehensive tests for CachedReferenceData.

Covers: warm, get (L1/L2), query, handle_invalidation, _find_bucket,
request_sync, ambiguity warnings, and MaxMemoryEntries partial marking.
"""

from __future__ import annotations

import json
import logging
from typing import Any

import pytest

from ethisyscore_plugin_sdk.reference_data import CachedReferenceData
from ethisyscore_plugin_sdk.types import (
    ReferenceDataSubscription,
    ReferenceDataSubscriptionOptions,
    RefDataInvalidationSignal,
)

ORGANISATION_ID = "11111111-1111-1111-1111-111111111111"


# ── Mock Helpers ─────────────────────────────────────────────────────────────


class MockDataStore:
    """In-memory data store that satisfies PluginDataStoreProtocol."""

    def __init__(self) -> None:
        self._store: dict[str, Any] = {}

    def seed(self, key: str, value: Any) -> None:
        """Pre-populate a key for testing."""
        self._store[key] = value

    async def get(self, key: str) -> Any:
        return self._store.get(key)

    async def set(self, key: str, value: Any) -> None:
        self._store[key] = value

    async def delete(self, key: str) -> bool:
        return self._store.pop(key, None) is not None

    async def exists(self, key: str) -> bool:
        return key in self._store

    async def list_keys(self, prefix: str) -> list[str]:
        return [k for k in self._store if k.startswith(prefix)]

    async def query(self, prefix: str) -> list[dict[str, Any]]:
        return [
            {"key": k, "value": v}
            for k, v in self._store.items()
            if k.startswith(prefix)
        ]


class MockLogger:
    """Captures log calls for assertion."""

    def __init__(self) -> None:
        self.messages: list[tuple[str, str]] = []

    def info(self, message: str, *args: Any) -> None:
        self.messages.append(("info", message))

    def warning(self, message: str, *args: Any) -> None:
        self.messages.append(("warning", message))

    def error(self, message: str, *args: Any) -> None:
        self.messages.append(("error", message))

    def debug(self, message: str, *args: Any) -> None:
        self.messages.append(("debug", message))


# ── Fixtures ─────────────────────────────────────────────────────────────────


def _make_sub(
    module_prefix: str = "hr",
    entity_type: str = "employees",
    fields: list[str] | None = None,
    max_memory_entries: int = 5_000,
    reconciliation_interval_seconds: int = 30,
) -> ReferenceDataSubscription:
    return ReferenceDataSubscription(
        module_prefix=module_prefix,
        entity_type=entity_type,
        fields=fields or ["id", "name"],
        options=ReferenceDataSubscriptionOptions(
            max_memory_entries=max_memory_entries,
            reconciliation_interval_seconds=reconciliation_interval_seconds,
        ),
    )


def _make_signal(
    module_prefix: str = "hr",
    entity_type: str = "employees",
    sequence_number: int = 2,
    sync_token: str = "tok-1",
    change_type: str = "Updated",
    entity_id: str | None = "emp-1",
    projected_fields_json: str | None = None,
) -> RefDataInvalidationSignal:
    return RefDataInvalidationSignal(
        module_prefix=module_prefix,
        entity_type=entity_type,
        sequence_number=sequence_number,
        sync_token=sync_token,
        change_type=change_type,
        organisation_id=ORGANISATION_ID,
        entity_id=entity_id,
        projected_fields_json=projected_fields_json,
    )


def _seed_l2_entries(
    store: MockDataStore,
    module: str,
    entity: str,
    entries: dict[str, dict[str, Any]],
    seq: int = 1,
    sync_token: str = "tok-1",
) -> None:
    """Seed L2 DataStore with reference data entries and _meta."""
    for eid, value in entries.items():
        store.seed(f"_ref/{module}/{entity}/{eid}", value)
    store.seed(f"_ref/{module}/{entity}/_meta", {
        "sequenceNumber": seq,
        "syncToken": sync_token,
    })


# ── Tests: warm ──────────────────────────────────────────────────────────────


class TestWarm:
    """Tests for CachedReferenceData.warm()."""

    @pytest.mark.asyncio
    async def test_warm_loads_entries_reads_meta_skips_tombstones(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        # Seed: 2 live entries, 1 tombstone, plus _meta
        store.seed("_ref/hr/employees/emp-1", {"id": "emp-1", "name": "Alice"})
        store.seed("_ref/hr/employees/emp-2", {"id": "emp-2", "name": "Bob"})
        store.seed("_ref/hr/employees/emp-3", {"id": "emp-3", "_deleted": True})
        store.seed("_ref/hr/employees/_meta", {"sequenceNumber": 5, "syncToken": "abc"})

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        # Should have loaded 2 live entries
        result = await cache.query("employees")
        assert len(result) == 2
        ids = {r["id"] for r in result}
        assert ids == {"emp-1", "emp-2"}

        # Sequence and sync token should be set from _meta
        seq = await cache.get_sequence_number("employees")
        assert seq == 5

    @pytest.mark.asyncio
    async def test_warm_skips_meta_entry_in_data(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        store.seed("_ref/hr/employees/emp-1", {"id": "emp-1", "name": "Alice"})
        store.seed("_ref/hr/employees/_meta", {"sequenceNumber": 1, "syncToken": "t"})

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        result = await cache.query("employees")
        assert len(result) == 1
        assert result[0]["id"] == "emp-1"

    @pytest.mark.asyncio
    async def test_warm_max_memory_entries_marks_partial_and_trims(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        # Seed 5 entries but limit to 3
        for i in range(5):
            store.seed(f"_ref/hr/employees/emp-{i}", {"id": f"emp-{i}", "name": f"E{i}"})
        store.seed("_ref/hr/employees/_meta", {"sequenceNumber": 1, "syncToken": "t"})

        cache = CachedReferenceData(store, logger)
        sub = _make_sub(max_memory_entries=3)
        await cache.warm([sub])

        # query() should raise because bucket is partial
        with pytest.raises(RuntimeError, match="PartialDataSet"):
            await cache.query("employees")

        # But individual get() should still work for entries that made it into L1
        # The bucket has exactly 3 entries (trimmed)
        bucket = cache._buckets.get("hr:employees")
        assert bucket is not None
        assert bucket.is_partial is True
        assert len(bucket.entries) == 3

    @pytest.mark.asyncio
    async def test_warm_empty_store_creates_bucket_with_zero_entries(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        result = await cache.query("employees")
        assert result == []
        seq = await cache.get_sequence_number("employees")
        assert seq == 0


# ── Tests: get ───────────────────────────────────────────────────────────────


class TestGet:
    """Tests for CachedReferenceData.get()."""

    @pytest.mark.asyncio
    async def test_get_l1_hit(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        _seed_l2_entries(store, "hr", "employees", {
            "emp-1": {"id": "emp-1", "name": "Alice"},
        })

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        result = await cache.get("employees", "emp-1")
        assert result is not None
        assert result["name"] == "Alice"

    @pytest.mark.asyncio
    async def test_get_returns_none_for_missing(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        result = await cache.get("employees", "nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_returns_none_for_unregistered_entity_type(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        cache = CachedReferenceData(store, logger)
        result = await cache.get("unknown_type", "id-1")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_l2_fallback(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        # Only seed _meta so the bucket is created, but emp-99 not in L2 during warm
        store.seed("_ref/hr/employees/_meta", {"sequenceNumber": 1, "syncToken": "t"})

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        # Now add emp-99 to L2 AFTER warm (simulates a write after warm)
        store.seed("_ref/hr/employees/emp-99", {"id": "emp-99", "name": "Late"})

        result = await cache.get("employees", "emp-99")
        assert result is not None
        assert result["name"] == "Late"

        # Second get should be L1 hit (promoted from L2)
        # Clear L2 to prove it comes from L1
        await store.delete("_ref/hr/employees/emp-99")
        result2 = await cache.get("employees", "emp-99")
        assert result2 is not None
        assert result2["name"] == "Late"

    @pytest.mark.asyncio
    async def test_get_l2_fallback_skips_deleted(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        store.seed("_ref/hr/employees/_meta", {"sequenceNumber": 1, "syncToken": "t"})

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        # Add a deleted entry to L2
        store.seed("_ref/hr/employees/emp-del", {"id": "emp-del", "_deleted": True})

        result = await cache.get("employees", "emp-del")
        assert result is None


# ── Tests: query ─────────────────────────────────────────────────────────────


class TestQuery:
    """Tests for CachedReferenceData.query()."""

    @pytest.mark.asyncio
    async def test_query_returns_all_entries(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        _seed_l2_entries(store, "hr", "employees", {
            "e1": {"id": "e1", "name": "A"},
            "e2": {"id": "e2", "name": "B"},
            "e3": {"id": "e3", "name": "C"},
        })

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        result = await cache.query("employees")
        assert len(result) == 3

    @pytest.mark.asyncio
    async def test_query_returns_empty_for_unregistered_type(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        cache = CachedReferenceData(store, logger)
        result = await cache.query("unknown_type")
        assert result == []

    @pytest.mark.asyncio
    async def test_query_raises_runtime_error_when_partial(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        for i in range(10):
            store.seed(f"_ref/hr/employees/e-{i}", {"id": f"e-{i}"})
        store.seed("_ref/hr/employees/_meta", {"sequenceNumber": 1, "syncToken": "t"})

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub(max_memory_entries=3)])

        with pytest.raises(RuntimeError, match="PartialDataSet"):
            await cache.query("employees")


# ── Tests: handle_invalidation ───────────────────────────────────────────────


class TestHandleInvalidation:
    """Tests for CachedReferenceData.handle_invalidation()."""

    @pytest.mark.asyncio
    async def test_projected_fields_json_direct_update(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        _seed_l2_entries(store, "hr", "employees", {
            "emp-1": {"id": "emp-1", "name": "Alice"},
        })

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        # Send signal with inline projected_fields_json
        new_data = json.dumps({"id": "emp-1", "name": "Alice Updated"})
        signal = _make_signal(
            sequence_number=2,
            entity_id="emp-1",
            projected_fields_json=new_data,
        )
        await cache.handle_invalidation(signal)

        result = await cache.get("employees", "emp-1")
        assert result is not None
        assert result["name"] == "Alice Updated"

    @pytest.mark.asyncio
    async def test_delete_removes_entry_from_l1(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        _seed_l2_entries(store, "hr", "employees", {
            "emp-1": {"id": "emp-1", "name": "Alice"},
        })

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        signal = _make_signal(
            sequence_number=2,
            entity_id="emp-1",
            change_type="Deleted",
        )
        await cache.handle_invalidation(signal)

        # Verify L1 entry was removed (check directly, not via get() which triggers L2 fallback)
        bucket = cache._buckets.get("hr:employees")
        assert "emp-1" not in bucket.entries

    @pytest.mark.asyncio
    async def test_delete_returns_none_when_l2_also_cleared(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        _seed_l2_entries(store, "hr", "employees", {
            "emp-1": {"id": "emp-1", "name": "Alice"},
        })

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        signal = _make_signal(
            sequence_number=2,
            entity_id="emp-1",
            change_type="Deleted",
        )
        await cache.handle_invalidation(signal)

        # Also clear L2 to simulate real platform behavior (L2 is updated before signal)
        await store.delete("_ref/hr/employees/emp-1")

        result = await cache.get("employees", "emp-1")
        assert result is None

    @pytest.mark.asyncio
    async def test_full_resync_when_no_entity_id(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        _seed_l2_entries(store, "hr", "employees", {
            "emp-1": {"id": "emp-1", "name": "Alice"},
        })

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        # Add a new entry to L2 before the full re-sync signal
        store.seed("_ref/hr/employees/emp-2", {"id": "emp-2", "name": "Bob"})

        signal = _make_signal(
            sequence_number=2,
            entity_id=None,  # Full re-sync
        )
        await cache.handle_invalidation(signal)

        # After full re-sync, both entries should be present
        result = await cache.query("employees")
        assert len(result) == 2

    @pytest.mark.asyncio
    async def test_stale_sequence_rejected(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        _seed_l2_entries(store, "hr", "employees", {
            "emp-1": {"id": "emp-1", "name": "Alice"},
        }, seq=5)

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        # Signal with sequence <= current (5) should be rejected
        signal = _make_signal(
            sequence_number=5,  # Not greater than current 5
            entity_id="emp-1",
            projected_fields_json=json.dumps({"id": "emp-1", "name": "Stale"}),
        )
        await cache.handle_invalidation(signal)

        result = await cache.get("employees", "emp-1")
        assert result["name"] == "Alice"  # Unchanged

    @pytest.mark.asyncio
    async def test_stale_sequence_less_than_current_rejected(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        _seed_l2_entries(store, "hr", "employees", {
            "emp-1": {"id": "emp-1", "name": "Alice"},
        }, seq=10)

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        signal = _make_signal(
            sequence_number=3,  # Less than 10
            entity_id="emp-1",
            projected_fields_json=json.dumps({"id": "emp-1", "name": "Old"}),
        )
        await cache.handle_invalidation(signal)

        result = await cache.get("employees", "emp-1")
        assert result["name"] == "Alice"

    @pytest.mark.asyncio
    async def test_invalidation_for_unknown_bucket_is_noop(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        cache = CachedReferenceData(store, logger)

        signal = _make_signal(
            module_prefix="unknown",
            entity_type="things",
            sequence_number=1,
            entity_id="x",
        )
        # Should not raise
        await cache.handle_invalidation(signal)

    @pytest.mark.asyncio
    async def test_invalidation_l2_fallback_when_no_projected_fields(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        _seed_l2_entries(store, "hr", "employees", {
            "emp-1": {"id": "emp-1", "name": "Alice"},
        })

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        # Update L2 value, then signal without projected_fields_json
        store.seed("_ref/hr/employees/emp-1", {"id": "emp-1", "name": "Updated via L2"})

        signal = _make_signal(
            sequence_number=2,
            entity_id="emp-1",
            change_type="Updated",
            projected_fields_json=None,
        )
        await cache.handle_invalidation(signal)

        result = await cache.get("employees", "emp-1")
        assert result is not None
        assert result["name"] == "Updated via L2"

    @pytest.mark.asyncio
    async def test_sync_token_mismatch_triggers_request_sync(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        _seed_l2_entries(store, "hr", "employees", {
            "emp-1": {"id": "emp-1", "name": "Alice"},
        }, sync_token="tok-1")

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        # Manually confirm sync_token was loaded
        bucket = cache._buckets["hr:employees"]
        assert bucket.sync_token == "tok-1"

        # Send signal with mismatched sync_token
        signal = _make_signal(
            sequence_number=2,
            sync_token="tok-DIFFERENT",
            entity_id="emp-1",
            projected_fields_json=json.dumps({"id": "emp-1", "name": "New"}),
        )
        await cache.handle_invalidation(signal)

        # Original data should remain (signal was rejected due to mismatch)
        result = await cache.get("employees", "emp-1")
        assert result["name"] == "Alice"

    @pytest.mark.asyncio
    async def test_invalidation_updates_sequence_number(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        _seed_l2_entries(store, "hr", "employees", {
            "emp-1": {"id": "emp-1", "name": "Alice"},
        }, seq=1)

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])
        assert await cache.get_sequence_number("employees") == 1

        signal = _make_signal(
            sequence_number=7,
            entity_id="emp-1",
            projected_fields_json=json.dumps({"id": "emp-1", "name": "New"}),
        )
        await cache.handle_invalidation(signal)

        assert await cache.get_sequence_number("employees") == 7


# ── Tests: _find_bucket ──────────────────────────────────────────────────────


class TestFindBucket:
    """Tests for CachedReferenceData._find_bucket()."""

    @pytest.mark.asyncio
    async def test_qualified_form(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        store.seed("_ref/hr/employees/_meta", {"sequenceNumber": 1, "syncToken": "t"})

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        bucket = cache._find_bucket("hr:employees")
        assert bucket is not None
        assert bucket.entity_type == "employees"

    @pytest.mark.asyncio
    async def test_short_form(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        store.seed("_ref/hr/employees/_meta", {"sequenceNumber": 1, "syncToken": "t"})

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        bucket = cache._find_bucket("employees")
        assert bucket is not None
        assert bucket.module_prefix == "hr"

    @pytest.mark.asyncio
    async def test_unknown_type_returns_none(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        cache = CachedReferenceData(store, logger)
        bucket = cache._find_bucket("nonexistent")
        assert bucket is None

    @pytest.mark.asyncio
    async def test_qualified_form_wrong_module_returns_none(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        store.seed("_ref/hr/employees/_meta", {"sequenceNumber": 1, "syncToken": "t"})

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        bucket = cache._find_bucket("proj:employees")
        assert bucket is None


# ── Tests: request_sync ──────────────────────────────────────────────────────


class TestRequestSync:
    """Tests for CachedReferenceData.request_sync()."""

    @pytest.mark.asyncio
    async def test_request_sync_fires_callback(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        cache = CachedReferenceData(store, logger)
        called_with: list[str] = []

        async def mock_callback(entity_type: str) -> None:
            called_with.append(entity_type)

        cache._request_sync_callback = mock_callback

        await cache.request_sync("employees")

        assert called_with == ["employees"]

    @pytest.mark.asyncio
    async def test_request_sync_logs_without_callback(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        cache = CachedReferenceData(store, logger)
        # No callback set (default None)

        await cache.request_sync("employees")

        # Should have logged the info messages
        info_msgs = [msg for level, msg in logger.messages if level == "info"]
        assert any("Manual sync requested" in msg for msg in info_msgs)
        assert any("No RequestSync callback" in msg for msg in info_msgs)

    @pytest.mark.asyncio
    async def test_request_sync_callback_failure_logs_warning(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        cache = CachedReferenceData(store, logger)

        async def failing_callback(entity_type: str) -> None:
            raise ConnectionError("host unreachable")

        cache._request_sync_callback = failing_callback

        # Should not raise
        await cache.request_sync("employees")

        warning_msgs = [msg for level, msg in logger.messages if level == "warning"]
        assert any("RequestSync callback failed" in msg for msg in warning_msgs)


# ── Tests: ambiguity warning ─────────────────────────────────────────────────


class TestAmbiguityWarning:
    """Tests for ambiguity warnings when two modules register the same entityType."""

    @pytest.mark.asyncio
    async def test_two_modules_same_entity_type_logs_warning(self, caplog: pytest.LogCaptureFixture) -> None:
        store = MockDataStore()
        logger = MockLogger()

        store.seed("_ref/hr/employees/_meta", {"sequenceNumber": 1, "syncToken": "t"})
        store.seed("_ref/proj/employees/_meta", {"sequenceNumber": 1, "syncToken": "t"})

        cache = CachedReferenceData(store, logger)

        sub_hr = _make_sub(module_prefix="hr", entity_type="employees")
        sub_proj = _make_sub(module_prefix="proj", entity_type="employees")

        with caplog.at_level(logging.WARNING, logger="ethisyscore.refdata"):
            await cache.warm([sub_hr, sub_proj])

        # The module-level logger should have emitted an ambiguity warning
        assert any("registered by both" in record.message for record in caplog.records)

    @pytest.mark.asyncio
    async def test_same_module_same_entity_no_warning(self, caplog: pytest.LogCaptureFixture) -> None:
        store = MockDataStore()
        logger = MockLogger()

        store.seed("_ref/hr/employees/_meta", {"sequenceNumber": 1, "syncToken": "t"})

        cache = CachedReferenceData(store, logger)

        # Warming twice with the same sub should NOT trigger ambiguity warning
        sub = _make_sub(module_prefix="hr", entity_type="employees")

        with caplog.at_level(logging.WARNING, logger="ethisyscore.refdata"):
            await cache.warm([sub])
            await cache.warm([sub])

        ambiguity_records = [r for r in caplog.records if "registered by both" in r.message]
        assert len(ambiguity_records) == 0


# ── Tests: get_sequence_number ───────────────────────────────────────────────


class TestGetSequenceNumber:
    """Tests for CachedReferenceData.get_sequence_number()."""

    @pytest.mark.asyncio
    async def test_returns_zero_for_unregistered_type(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        cache = CachedReferenceData(store, logger)
        seq = await cache.get_sequence_number("unknown")
        assert seq == 0

    @pytest.mark.asyncio
    async def test_returns_sequence_from_meta(self) -> None:
        store = MockDataStore()
        logger = MockLogger()

        _seed_l2_entries(store, "hr", "employees", {}, seq=42)

        cache = CachedReferenceData(store, logger)
        await cache.warm([_make_sub()])

        seq = await cache.get_sequence_number("employees")
        assert seq == 42
