"""
EthisysCore Plugin SDK for Python.

Build container-hosted plugins by extending ``PluginBase`` and starting with ``PluginHost``.

Example::

    from ethisyscore_plugin_sdk import PluginBase, PluginHost, PluginManifest, ToolResult

    class MyPlugin(PluginBase):
        @property
        def manifest(self) -> PluginManifest:
            return PluginManifest(
                id="11111111-1111-1111-1111-111111111111", name="My Plugin", version="1.0.0",
                type="TENANT_APP", owner="acme",
                compatible_core_version=">=1.0.0", mcp_version="1.0",
                execution_mode="Container",
                mcp_tools=[{"name": "greet", "description": "Say hello", "inputSchemaJson": "{}"}],
            )

        async def on_invoke_tool(self, tool_name: str, args: dict, context) -> ToolResult:
            return ToolResult(success=True, result_json='{"greeting": "Hello!"}')

    PluginHost(MyPlugin()).start()
"""

from .types import (
    ToolPermission,
    PluginType,
    PluginManifest,
    McpToolDefinition,
    McpResourceDefinition,
    ReferenceDataSubscription,
    PluginNotification,
    NotificationContext,
    RefDataInvalidationSignal,
    ToolResult,
    ResourceResult,
    HealthResult,
    PluginContext,
    DataStoreFieldFilter,
    DataStoreFieldSort,
    DataStoreQueryOptions,
    DataStorePagedResult,
    PluginStorageInfo,
    UiContributions,
    UiNavigationContribution,
    UiNavigationItem,
    UiPageContribution,
    UiWidgetContribution,
    UiSurfaceContribution,
    UiConfigContribution,
)
from .plugin_base import PluginBase
from .plugin_host import PluginHost
from .dapr_host_client import DaprHostClient
from .reference_data import CachedReferenceData, NullReferenceData

__all__ = [
    "PluginBase",
    "PluginHost",
    "DaprHostClient",
    "CachedReferenceData",
    "NullReferenceData",
    "ToolPermission",
    "PluginType",
    "PluginManifest",
    "McpToolDefinition",
    "McpResourceDefinition",
    "ReferenceDataSubscription",
    "PluginNotification",
    "NotificationContext",
    "RefDataInvalidationSignal",
    "ToolResult",
    "ResourceResult",
    "HealthResult",
    "PluginContext",
    "DataStoreFieldFilter",
    "DataStoreFieldSort",
    "DataStoreQueryOptions",
    "DataStorePagedResult",
    "PluginStorageInfo",
    "UiContributions",
    "UiNavigationContribution",
    "UiNavigationItem",
    "UiPageContribution",
    "UiWidgetContribution",
    "UiSurfaceContribution",
    "UiConfigContribution",
]
