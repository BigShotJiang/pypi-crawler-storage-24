"""
Dapr-backed client for calling back to EthisysCore host services.

Enterprise hardening:
- Correlation ID on every request (ENT-1)
- Exponential backoff retry for transient failures (PERF-4)
- Batch MCP operations (ENT-15)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from typing import Any

import httpx

from ethisyscore_plugin_sdk.types import DataStorePagedResult, normalize_uuid_string

DAPR_HTTP_PORT = os.environ.get("DAPR_HTTP_PORT", "3500")
DAPR_BASE_URL = f"http://localhost:{DAPR_HTTP_PORT}"
DAPR_API_TOKEN = os.environ.get("DAPR_API_TOKEN", "")

_logger = logging.getLogger("ethisyscore.plugin")

_MAX_RETRIES = 3
_REQUEST_TIMEOUT = 30.0


class DaprHostClient:
    """
    Calls back to EthisysCore host services via Dapr service invocation.

    Provides DataStore access, MCP client, logging, and event publishing
    for container plugins.
    """

    def __init__(self, host_app_id: str, extension_id: str) -> None:
        self.host_app_id = host_app_id
        self.extension_id = normalize_uuid_string(extension_id, "DaprHostClient.extension_id")
        self._client: httpx.AsyncClient | None = None

    async def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=_REQUEST_TIMEOUT)
        return self._client

    async def close(self) -> None:
        """Close the underlying HTTP client. Call on shutdown to prevent resource leaks."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    # ── DataStore Operations ─────────────────────────────────────────────────

    @property
    def data_store(self) -> _DataStore:
        return _DataStore(self)

    # ── Logging ──────────────────────────────────────────────────────────────

    @property
    def logger(self) -> _PluginLogger:
        return _PluginLogger(self)

    # ── MCP Client ───────────────────────────────────────────────────────────

    @property
    def mcp_client(self) -> _McpClient:
        return _McpClient(self)

    # ── Event Publishing ─────────────────────────────────────────────────────

    async def publish_event(self, event_type: str, payload: Any) -> None:
        event_json = json.dumps({"eventType": event_type, "payload": payload})
        await self._invoke_host("event/publish", {
            "extensionId": self.extension_id,
            "eventJson": event_json,
        })

    # ── Internal ─────────────────────────────────────────────────────────────

    async def _invoke_host(self, endpoint: str, body: dict) -> dict:
        """Invoke host callback with retry and correlation ID."""
        client = await self._ensure_client()
        url = f"{DAPR_BASE_URL}/v1.0/invoke/{self.host_app_id}/method/api/v1/plugin-callbacks/{endpoint}"
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "x-extension-id": self.extension_id,
            # Correlation ID for distributed tracing (ENT-1)
            "x-correlation-id": str(uuid.uuid4()),
        }
        if DAPR_API_TOKEN:
            headers["dapr-api-token"] = DAPR_API_TOKEN

        # Retry with exponential backoff for transient failures (PERF-4)
        last_error: Exception | None = None
        for attempt in range(_MAX_RETRIES):
            try:
                response = await client.post(
                    url,
                    json=body,
                    headers=headers,
                )
                response.raise_for_status()
                return response.json()  # type: ignore[no-any-return]
            except (httpx.ConnectError, httpx.TimeoutException) as exc:
                last_error = exc
                if attempt < _MAX_RETRIES - 1:
                    delay = 2 ** attempt
                    _logger.warning(
                        "Host callback to %s failed (attempt %d/%d), retrying in %ds: %s",
                        endpoint, attempt + 1, _MAX_RETRIES, delay, exc,
                    )
                    await asyncio.sleep(delay)
                    continue
                raise
            except httpx.HTTPStatusError:
                # Don't retry on 4xx/5xx — only connection/timeout errors
                raise

        raise last_error or httpx.ConnectError("Host callback failed after retries")


class _DataStore:
    """DataStore operations backed by Dapr → host callbacks."""

    def __init__(self, client: DaprHostClient) -> None:
        self._client = client

    async def get(self, key: str) -> Any | None:
        res = await self._client._invoke_host("data/get", {
            "extensionId": self._client.extension_id, "key": key,
        })
        if res.get("found") and res.get("valueJson"):
            return json.loads(res["valueJson"])
        return None

    async def set(self, key: str, value: Any) -> None:
        await self._client._invoke_host("data/set", {
            "extensionId": self._client.extension_id,
            "key": key,
            "valueJson": json.dumps(value),
        })

    async def delete(self, key: str) -> bool:
        res = await self._client._invoke_host("data/delete", {
            "extensionId": self._client.extension_id, "key": key,
        })
        return bool(res.get("deleted", False))

    async def exists(self, key: str) -> bool:
        res = await self._client._invoke_host("data/exists", {
            "extensionId": self._client.extension_id, "key": key,
        })
        return bool(res.get("exists", False))

    async def query(self, key_prefix: str) -> list[dict[str, Any]]:
        res = await self._client._invoke_host("data/query", {
            "extensionId": self._client.extension_id, "keyPrefix": key_prefix,
        })
        entries = res.get("entries", [])
        return [{"key": e["key"], "value": json.loads(e["valueJson"])} for e in entries]

    async def list_keys(self, prefix: str = "") -> list[str]:
        res = await self._client._invoke_host("data/list-keys", {
            "extensionId": self._client.extension_id, "prefix": prefix,
        })
        return res.get("keys", [])  # type: ignore[no-any-return]

    async def set_batch(self, entries: list[dict[str, Any]]) -> None:
        serialized = [
            {"key": e["key"], "valueJson": json.dumps(e["value"])}
            for e in entries
        ]
        await self._client._invoke_host("data/set-batch", {
            "extensionId": self._client.extension_id, "entries": serialized,
        })

    async def delete_by_prefix(self, prefix: str) -> int:
        res = await self._client._invoke_host("data/delete-by-prefix", {
            "extensionId": self._client.extension_id, "prefix": prefix,
        })
        return int(res.get("deletedCount", 0))

    async def query_filtered(
        self,
        key_prefix: str,
        options: Any,
    ) -> DataStorePagedResult:
        """Query entries matching key_prefix with filtering, sorting, and pagination.

        Parameters
        ----------
        key_prefix:
            The key prefix to match.
        options:
            A ``DataStoreQueryOptions`` Pydantic model (or plain dict) with
            filters, sort, take, pageToken, and includeTotalCount.

        Returns
        -------
        DataStorePagedResult
            Typed result with ``items``, ``total_count``, and ``next_page_token``.
        """
        # Accept both Pydantic models and raw dicts
        if hasattr(options, "model_dump"):
            options_dict = options.model_dump(by_alias=True, exclude_none=True)
        else:
            options_dict = dict(options)

        res = await self._client._invoke_host("data/query-filtered", {
            "extensionId": self._client.extension_id,
            "keyPrefix": key_prefix,
            "options": options_dict,
        })
        return DataStorePagedResult(
            items=res.get("items", []),
            total_count=res.get("totalCount"),
            next_page_token=res.get("nextPageToken"),
        )

    async def count(
        self,
        key_prefix: str,
        filters: list[Any] | None = None,
    ) -> int:
        """Count entries matching the key prefix and optional filters.

        Parameters
        ----------
        key_prefix:
            The key prefix to match.
        filters:
            Optional list of ``DataStoreFieldFilter`` models (or dicts).

        Returns
        -------
        int
            The number of matching entries.
        """
        serialized_filters: list[dict[str, Any]] | None = None
        if filters is not None:
            serialized_filters = [
                f.model_dump(by_alias=True, exclude_none=True) if hasattr(f, "model_dump") else dict(f)
                for f in filters
            ]

        res = await self._client._invoke_host("data/count", {
            "extensionId": self._client.extension_id,
            "keyPrefix": key_prefix,
            "filters": serialized_filters,
        })
        return int(res.get("count", 0))

    async def get_storage_info(self) -> dict[str, Any]:
        return await self._client._invoke_host("data/storage-info", {
            "extensionId": self._client.extension_id,
        })


class _PluginLogger:
    """
    Plugin logger backed by Dapr → host callbacks.

    Methods are synchronous for ergonomic use (no ``await`` needed).
    Host log delivery is fire-and-forget via ``asyncio.create_task``.
    Local Python logging is always emitted regardless of host callback success.
    """

    def __init__(self, client: DaprHostClient) -> None:
        self._client = client

    def debug(self, message: str) -> None:
        _logger.debug(message)
        self._fire_and_forget("log", {
            "extensionId": self._client.extension_id,
            "level": 0,
            "message": message,
        })

    def info(self, message: str) -> None:
        _logger.info(message)
        self._fire_and_forget("log", {
            "extensionId": self._client.extension_id,
            "level": 1,
            "message": message,
        })

    def warning(self, message: str) -> None:
        _logger.warning(message)
        self._fire_and_forget("log", {
            "extensionId": self._client.extension_id,
            "level": 2,
            "message": message,
        })

    def error(self, message: str, exception: str | None = None) -> None:
        _logger.error(message, exc_info=exception is not None)
        self._fire_and_forget("log", {
            "extensionId": self._client.extension_id,
            "level": 3,
            "message": message,
            "exception": exception,
        })

    def _fire_and_forget(self, endpoint: str, body: dict) -> None:
        """Schedule host log delivery as a background task, if an event loop is running."""
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self._safe_invoke(endpoint, body))
        except RuntimeError:
            pass  # No running event loop — local log already emitted

    async def _safe_invoke(self, endpoint: str, body: dict) -> None:
        """Invoke host and suppress errors to avoid unhandled task exceptions."""
        try:
            await self._client._invoke_host(endpoint, body)
        except Exception:
            _logger.debug("Failed to send log to host", exc_info=True)


class _McpClient:
    """MCP client for inter-plugin tool invocation and resource access."""

    def __init__(self, client: DaprHostClient) -> None:
        self._client = client

    async def invoke_tool(self, tool_name: str, arguments_json: str = "{}") -> dict:
        """Invoke another plugin's tool via the host MCP router."""
        return await self._client._invoke_host("mcp/invoke-tool", {
            "extensionId": self._client.extension_id,
            "toolName": tool_name,
            "argumentsJson": arguments_json,
        })

    async def list_tools(self) -> list[dict[str, Any]]:
        """List all available MCP tools visible to this plugin."""
        res = await self._client._invoke_host("mcp/list-tools", {
            "extensionId": self._client.extension_id,
        })
        return res.get("tools", [])  # type: ignore[no-any-return]

    async def get_resource(self, resource_uri: str) -> dict:
        """Read a resource from another plugin via the host MCP router."""
        return await self._client._invoke_host("mcp/get-resource", {
            "extensionId": self._client.extension_id,
            "resourceUri": resource_uri,
        })

    async def list_resources(self) -> list[dict[str, Any]]:
        """List all available MCP resources visible to this plugin."""
        res = await self._client._invoke_host("mcp/list-resources", {
            "extensionId": self._client.extension_id,
        })
        return res.get("resources", [])  # type: ignore[no-any-return]

    async def batch_invoke_tools(
        self, requests: list[dict[str, str]],
    ) -> list[dict]:
        """Invoke multiple tools in parallel — errors don't abort other results (ENT-15).
        Each result includes _toolName for caller correlation."""
        results = await asyncio.gather(
            *(
                self.invoke_tool(
                    req.get("toolName", ""),
                    req.get("argumentsJson", "{}"),
                )
                for req in requests
            ),
            return_exceptions=True,
        )
        return [
            {**(r if isinstance(r, dict) else {"success": False, "error": str(r)}), "_toolName": requests[i].get("toolName", "")}
            for i, r in enumerate(results)
        ]
