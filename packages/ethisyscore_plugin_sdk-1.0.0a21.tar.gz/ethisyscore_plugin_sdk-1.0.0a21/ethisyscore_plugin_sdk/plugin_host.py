"""
HTTP server implementing the EthisysCore container plugin contract.

Security hardening:
- dapr-api-token validation when DAPR_API_TOKEN env var is set (constant-time)
- Request body size limit (1 MB)
- Graceful SIGTERM handling for container shutdown
"""

from __future__ import annotations

import asyncio
import hmac
import json
import logging
import os
import signal
import sys
import time
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from .dapr_host_client import DaprHostClient
from .plugin_base import PluginBase
from .reference_data import CachedReferenceData, NullReferenceData
from .types import PluginContext, PluginNotification, RefDataInvalidationSignal

_logger = logging.getLogger("ethisyscore.plugin")

# Maximum request body size (1 MB)
_MAX_BODY_SIZE = 1_048_576


class PluginHost:
    """
    HTTP server that implements the EthisysCore container plugin contract.

    Maps all required endpoints and delegates to a PluginBase instance.

    Example::

        from ethisyscore_plugin_sdk import PluginBase, PluginHost

        class MyPlugin(PluginBase):
            ...

        PluginHost(MyPlugin()).start()
    """

    def __init__(self, plugin: PluginBase, port: int | None = None) -> None:
        self.plugin = plugin
        self.port = port or int(os.environ.get("DAPR_APP_PORT", "8080"))
        self._context: PluginContext | None = None
        self._host_client: DaprHostClient | None = None

        @asynccontextmanager
        async def lifespan(_app: FastAPI):  # type: ignore[no-untyped-def]
            yield
            if self._host_client is not None:
                await self._host_client.close()

        self._app = FastAPI(
            title=f"EthisysCore Plugin: {plugin.manifest.name}",
            lifespan=lifespan,
        )
        self._register_middleware()
        self._register_routes()

    def start(self) -> None:
        """Start the plugin HTTP server with graceful shutdown handling."""
        import uvicorn

        # Handle SIGTERM (Kubernetes) for graceful shutdown
        signal.signal(signal.SIGTERM, lambda _s, _f: sys.exit(0))

        _logger.info(
            "Starting plugin %s v%s on port %d",
            self.plugin.manifest.name,
            self.plugin.manifest.version,
            self.port,
        )
        uvicorn.run(self._app, host="0.0.0.0", port=self.port, log_level="info")

    def _register_middleware(self) -> None:
        expected_token = os.environ.get("DAPR_API_TOKEN")

        @self._app.middleware("http")
        async def security_middleware(request: Request, call_next):  # type: ignore[no-untyped-def]
            # Body size limit — check Content-Length first, then verify actual body.
            # Starlette caches request.body() internally, so downstream request.json() still works.
            if request.method in ("POST", "PUT", "PATCH"):
                content_length = request.headers.get("content-length")
                if content_length and int(content_length) > _MAX_BODY_SIZE:
                    return JSONResponse(
                        {"success": False, "error": "Request body too large"},
                        status_code=413,
                    )
                # Also check actual body to prevent chunked-encoding Content-Length bypass
                body = await request.body()
                if len(body) > _MAX_BODY_SIZE:
                    return JSONResponse(
                        {"success": False, "error": "Request body too large"},
                        status_code=413,
                    )

            # dapr-api-token validation (skip health/heartbeat probes)
            if expected_token and request.url.path.startswith("/plugin/"):
                if request.url.path not in ("/plugin/health", "/plugin/heartbeat"):
                    token = request.headers.get("dapr-api-token", "")
                    if not hmac.compare_digest(token, expected_token):
                        return JSONResponse(
                            {"success": False, "error": "Unauthorized"},
                            status_code=401,
                        )

            return await call_next(request)

    def _register_routes(self) -> None:
        app = self._app

        @app.post("/plugin/initialize")
        async def initialize(request: Request) -> JSONResponse:
            try:
                body = await request.json()
                extension_id = body.get("extensionId", "")
                host_app_id = body.get("hostAppId", "")
                host_client = DaprHostClient(host_app_id, extension_id)
                self._host_client = host_client

                # Build reference data client — warm from L2 if subscriptions exist
                subs = self.plugin.manifest.reference_data_subscriptions
                if subs:
                    ref_data: Any = CachedReferenceData(host_client.data_store, host_client.logger)

                    # Wire request_sync callback so CachedReferenceData.request_sync()
                    # can publish a re-sync event to the host via publish_event.
                    # Standardized contract: all SDKs publish same event name + payload shape.
                    async def _request_sync_callback(entity_type: str) -> None:
                        bucket = ref_data._find_bucket(entity_type)
                        await host_client.publish_event(
                            "request-ref-data-sync",
                            {
                                "type": "request-ref-data-sync",
                                "modulePrefix": bucket.module_prefix if bucket else "",
                                "entityType": entity_type,
                                "currentSequenceNumber": bucket.sequence_number if bucket else 0,
                            },
                        )

                    ref_data._request_sync_callback = _request_sync_callback

                    await ref_data.warm(subs)
                    ref_data.start_reconciliation()
                else:
                    ref_data = NullReferenceData()
                self._ref_data = ref_data

                self._context = PluginContext(
                    extension_id=extension_id,
                    organisation_id=body.get("organisationId", ""),
                    tenant_id=body.get("tenantId", ""),
                    host_app_id=host_app_id,
                    data_store=host_client.data_store,
                    reference_data=ref_data,
                    logger=host_client.logger,
                    mcp_client=host_client.mcp_client,
                    publish_event=host_client.publish_event,
                )

                await self.plugin.on_initialize(self._context)

                manifest_json = self.plugin.manifest.model_dump_json(by_alias=True)
                return JSONResponse({"success": True, "manifestJson": manifest_json})
            except Exception as exc:
                return JSONResponse({"success": False, "error": str(exc)})

        @app.post("/plugin/enable")
        async def enable() -> JSONResponse:
            if not self._context:
                return JSONResponse({"success": False, "error": "Plugin not initialized"})
            try:
                await self.plugin.on_enable(self._context)
                return JSONResponse({"success": True})
            except Exception as exc:
                return JSONResponse({"success": False, "error": str(exc)})

        @app.post("/plugin/disable")
        async def disable() -> JSONResponse:
            if not self._context:
                return JSONResponse({"success": False, "error": "Plugin not initialized"})
            try:
                await self.plugin.on_disable(self._context)
                return JSONResponse({"success": True})
            except Exception as exc:
                return JSONResponse({"success": False, "error": str(exc)})

        @app.post("/plugin/update")
        async def update(request: Request) -> JSONResponse:
            if not self._context:
                return JSONResponse({"success": False, "error": "Plugin not initialized"})
            try:
                body = await request.json()
                from_version: str = body.get("fromVersion", "")
                to_version: str = body.get("toVersion", "")
                await self.plugin.on_update(from_version, to_version, self._context)
                return JSONResponse({"success": True})
            except Exception as exc:
                return JSONResponse({"success": False, "error": str(exc)})

        @app.post("/plugin/shutdown")
        async def shutdown() -> JSONResponse:
            if not self._context:
                return JSONResponse({"success": True})
            try:
                # Stop reconciliation timers before plugin shutdown
                if hasattr(self._ref_data, "stop_reconciliation"):
                    self._ref_data.stop_reconciliation()
                await self.plugin.on_shutdown(self._context)
                return JSONResponse({"success": True})
            except Exception as exc:
                return JSONResponse({"success": False, "error": str(exc)})

        @app.post("/plugin/invoke-tool")
        async def invoke_tool(request: Request) -> JSONResponse:
            if not self._context:
                return JSONResponse({"success": False, "error": "Plugin not initialized"})
            try:
                body = await request.json()
                tool_name: str = body.get("toolName", "")
                arguments_json: str = body.get("argumentsJson", "{}")
                args: dict[str, Any] = json.loads(arguments_json)

                # Auto-validate against manifest schema if available (ENT-5)
                tool_def = next(
                    (t for t in self.plugin.manifest.mcp_tools if t.name == tool_name),
                    None,
                )
                if tool_def and tool_def.input_schema_json:
                    try:
                        schema = json.loads(tool_def.input_schema_json)
                        required_fields = schema.get("required", [])
                        for field in required_fields:
                            if field not in args or args[field] is None:
                                return JSONResponse({
                                    "success": False,
                                    "error": f"Missing required field: {field}",
                                    "errorCode": "INVALID_ARGUMENTS",
                                })
                    except (json.JSONDecodeError, TypeError):
                        pass  # Schema parse failure — skip validation

                # Per-tool timeout to prevent runaway handlers (ENT-14)
                _TOOL_TIMEOUT = 30.0
                result = await asyncio.wait_for(
                    self.plugin.on_invoke_tool(tool_name, args, self._context),
                    timeout=_TOOL_TIMEOUT,
                )
                return JSONResponse(result.model_dump(by_alias=True))
            except asyncio.TimeoutError:
                return JSONResponse({"success": False, "error": "Tool invocation timed out", "errorCode": "TIMEOUT"})
            except Exception as exc:
                return JSONResponse({"success": False, "error": str(exc)})

        @app.post("/plugin/get-resource")
        async def get_resource(request: Request) -> JSONResponse:
            if not self._context:
                return JSONResponse({"success": False, "error": "Plugin not initialized"})
            try:
                body = await request.json()
                resource_uri: str = body.get("resourceUri", "")

                result = await self.plugin.on_get_resource(resource_uri, self._context)
                return JSONResponse(result.model_dump(by_alias=True))
            except Exception as exc:
                return JSONResponse({"success": False, "error": str(exc)})

        @app.get("/plugin/health")
        async def health() -> JSONResponse:
            try:
                result = await self.plugin.on_check_health()
                return JSONResponse(result.model_dump())
            except Exception as exc:
                return JSONResponse({"status": 2, "message": str(exc)})

        @app.get("/plugin/heartbeat")
        async def heartbeat() -> JSONResponse:
            return JSONResponse({"timestamp": int(time.time() * 1000)})

        @app.post("/plugin/notify")
        async def notify(request: Request) -> JSONResponse:
            try:
                body = await request.json()
                notification = PluginNotification(**body)

                # Auto-handle reference data invalidation signals
                if notification.type == "ref-data-invalidate" and notification.payload_json:
                    signal = RefDataInvalidationSignal.model_validate_json(notification.payload_json)
                    if hasattr(self._ref_data, "handle_invalidation"):
                        await self._ref_data.handle_invalidation(signal)

                # Forward to plugin's notification handler (if overridden)
                if self._context:
                    await self.plugin.on_notification(notification, self._context)

                return JSONResponse({"success": True})
            except Exception as exc:
                _logger.error("Notification handling failed: %s", exc)
                return JSONResponse({"success": True})  # Don't fail — reconciliation recovers
