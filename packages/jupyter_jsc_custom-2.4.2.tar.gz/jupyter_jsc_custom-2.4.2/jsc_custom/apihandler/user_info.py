from jupyterhub.apihandlers import APIHandler
from jupyterhub.apihandlers import default_handlers
from tornado import web


class UserEmailAPIHandler(APIHandler):
    async def get(self):
        user = self.current_user
        if user is None:
            raise web.HTTPError(403)
        email = [
            g.name.split("email:")[1]
            for g in user.groups
            if g.name.startswith("email:")
        ]
        self.set_status(200)
        self.set_header("Content-Type", "text/plain")
        if email:
            self.write(email[0])
        else:
            self.write(
                "AAI did not provide an email address. Please use a different login method or contact support. (Link available in the footer on the home page)"
            )
        return


class UserIDAPIHandler(APIHandler):
    async def get(self):
        user = self.current_user
        if user is None:
            raise web.HTTPError(403)
        user_id = user.orm_user.id
        self.write(str(user_id))
        self.set_header("Content-Type", "text/plain")
        self.set_status(200)
        return


class UserRolesAPIHandler(APIHandler):
    async def get(self):
        user = self.current_user
        if user is None:
            raise web.HTTPError(403)
        groups = [g.name for g in user.groups]
        assurances = [
            g.split("eduperson_assurance:")[1]
            for g in groups
            if g.startswith("eduperson_assurance:")
        ]
        roles = [
            g.split("voperson_external_affiliation_role:")[1]
            for g in groups
            if g.startswith("voperson_external_affiliation_role:")
        ]
        domains = [
            g.split("voperson_external_affiliation_domain:")[1]
            for g in groups
            if g.startswith("voperson_external_affiliation_domain:")
        ]

        if "last_idp:https://judoor.fz-juelich.de/oauth2/access_token" in groups:
            roles.append("JSC-Account User")
        elif "last_idp:https://login.helmholtz.de/oauth2/token" in groups:
            roles.append("Helmholtz AAI User")
        elif "last_idp:https://proxy.myaccessid.org/OIDC/token" in groups:
            roles.append("MyAccessID User")

        s = ""
        if domains:
            s += f"Domains: \n - {'\n - '.join(domains)} \n"
        if roles:
            s += f"Roles: \n - {'\n - '.join(roles)} \n"
        if assurances:
            s += f"Assurances: \n - {'\n - '.join(assurances)}"
        if s:
            self.write(s)
        else:
            self.write("Could not find any roles or assurances.")
        self.set_header("Content-Type", "text/plain")
        self.set_status(200)
        return


default_handlers.append((r"/api/user_email", UserEmailAPIHandler))
default_handlers.append((r"/api/user_id", UserIDAPIHandler))
default_handlers.append((r"/api/user_roles", UserRolesAPIHandler))
