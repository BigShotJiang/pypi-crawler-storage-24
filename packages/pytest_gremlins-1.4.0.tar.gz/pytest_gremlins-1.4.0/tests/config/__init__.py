"""Tests for configuration loading."""
