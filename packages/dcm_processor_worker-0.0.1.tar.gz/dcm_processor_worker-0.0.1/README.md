# dcm-processor-worker

`dcm-processor-worker` is the execution layer for queued jobs in the dcm-processor platform.

It is responsible for taking scheduled work and actually running the service code.

## Role In The Bigger Picture

This module sits at the end of the scheduling chain.

The high-level flow is:

1. DICOM data is ingested and stored
2. the scheduler creates queued jobs
3. worker consumers pick up those jobs
4. this module executes the requested callback

So this package is the runtime engine that turns job definitions into actual code execution.

## Main Responsibilities

### 1. Worker Type Registration

The package supports different worker implementations and registers them through `WorkerManager`.

Currently supported types include:

- venv-based workers
- Docker-based workers
- the default local service execution path

### 2. Worker Installation

The module installs worker environments from package content.

This includes:

- building or pulling Docker images
- creating Python virtual environments
- installing Python dependencies
- storing worker-side support files

### 3. Job Execution

When a queued job is consumed, this module:

- loads the job record
- loads the service module artifact
- prepares the runtime environment
- injects service runtime env vars
- executes the requested callback
- returns the result or error payload

### 4. Pre/Post Service Hooks

The module also exposes entry points for:

- pre-service execution
- post-service execution

These are scheduled by the job scheduler around the main service jobs.

## Key Internal Areas

- `dcm_processor_worker/manager.py`
  - central worker dispatch and environment preparation
- `dcm_processor_worker/venv_worker.py`
  - Python virtual environment worker implementation
- `dcm_processor_worker/docker_worker.py`
  - Docker-based worker implementation
- `dcm_processor_worker/venv_worker_lib.py`
  - venv creation and generated wrapper execution helpers
- `dcm_processor_worker/base.py`
  - base worker contract

## Dependencies On Other Modules

This module depends mainly on:

- `dcm-processor-db-provider`
  - for job, service, and worker data plus component files
- `dcm-processor-utils`
  - for shared helpers such as device and archive logic

It works directly with:

- `dcm-processor-job-scheduler`
  - which creates the jobs this module executes
- `dcm-processor-service`
  - which is the runtime helper layer available to executed service code

## What This Module Is Not

This package is not:

- the scheduler
- the DICOM listener
- the main CLI
- the persistence layer

It is the execution runtime for scheduled processing work.

## Summary

Use this module when you need to install or run worker environments for dcm-processor jobs.

It is the piece of the system that actually runs the processing callbacks defined by installed packages.
