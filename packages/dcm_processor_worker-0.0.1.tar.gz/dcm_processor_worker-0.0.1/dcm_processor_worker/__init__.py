from .manager import WorkerManager
from .venv_worker import VenvWorker
from .docker_worker import DockerWorker

WorkerManager.register_provider("venv", VenvWorker)
WorkerManager.register_provider("virtualenv", VenvWorker)
WorkerManager.register_provider("docker", DockerWorker)

def controller(*args, **kwargs):
    return WorkerManager.worker_callback(*args, **kwargs)

def pre_services(*args, **kwargs):
    return WorkerManager.default_service_callback(
        "run_pre_services",
        *args,
        **kwargs
    )

def post_services(*args, **kwargs):
    return WorkerManager.default_service_callback(
        "run_post_services",
        *args,
        **kwargs
    )

def logger(*args, **kwargs):
    print("Logger called with", args, flush=True)