import subprocess, sys, os, json, tempfile, zipfile
from pathlib import Path
from functools import lru_cache
from dcm_processor_db_provider import DBManager
import re

def run(cmd):
    return subprocess.check_output(cmd, text=True).strip()

@lru_cache(maxsize=1)
def installed_pyenv_versions():
    """
    Cached list of installed pyenv versions.
    """
    try:
        out = run(["pyenv", "versions", "--bare"])
        return [v.strip() for v in out.splitlines() if v.strip()]
    except Exception:
        raise RuntimeError("pyenv not installed or not in PATH")

PYTHON_VERSION_PATTERN = re.compile(r"^\d+(?:\.\d+){1,2}$")

def _is_real_python_version(value: str) -> bool:
    candidate = str(value).strip()
    if candidate == "" or "/" in candidate:
        return False
    return PYTHON_VERSION_PATTERN.match(candidate) is not None

def _version_sort_key(value: str):
    return tuple(int(part) for part in str(value).split("."))

def resolve_install_version(requested: str) -> str:
    """
    Resolve version and install if missing.
    """
    installed = [v for v in installed_pyenv_versions() if _is_real_python_version(v)]

    # exact match
    if requested in installed:
        return requested

    # try prefix match (3.10 -> 3.10.13)
    matches = [v for v in installed if v.startswith(requested)]

    if matches:
        matches.sort(key=_version_sort_key)
        return matches[-1]

    # not installed → install latest patch
    install_target = f"{requested}:latest"

    print(f"Installing Python {install_target} via pyenv...")
    subprocess.run(["pyenv", "install", install_target], check=True)

    # refresh cache
    installed_pyenv_versions.cache_clear()
    installed = [v for v in installed_pyenv_versions() if _is_real_python_version(v)]

    matches = [v for v in installed if v.startswith(requested)]
    matches.sort(key=_version_sort_key)

    return matches[-1]

def get_python_path(version: str) -> Path:
    """
    Return python executable path for resolved version.
    """
    prefix = run(["pyenv", "prefix", version])

    if sys.platform.startswith("win"):
        return Path(prefix) / "python.exe"
    else:
        return Path(prefix) / "bin" / "python"

def create_venv_at(python_version: str, target_dir: str):
    """
    Create venv using requested Python version.
    """
    try:
        target_dir = Path(target_dir)
        target_dir.mkdir(parents=True, exist_ok=True)

        resolved = resolve_install_version(python_version)
        python_bin = get_python_path(resolved)

        subprocess.run(
            [str(python_bin), "-m", "venv", str(target_dir)],
            check=True
        )

        if sys.platform.startswith("win"):
            venv_python = target_dir / "Scripts" / "python.exe"
        else:
            venv_python = target_dir / "bin" / "python"

        # Update pip
        subprocess.run(
            [str(venv_python), "-m", "pip", "install", "-U", "pip"],
            check=True
        )

        return resolved, str(venv_python)
    
    except Exception as ex:
        print(f"Error creating venv: {ex}")
    
    return None, None

def extract_zip_bytes(zip_bytes, output_dir: str):
    output_root = Path(output_dir).resolve()
    output_root.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_bytes) as zf:
        for member in zf.infolist():
            member_path = output_root / member.filename
            resolved_path = member_path.resolve()

            if output_root not in resolved_path.parents and resolved_path != output_root:
                raise RuntimeError(f"Unsafe archive entry: {member.filename}")

            if member.is_dir():
                resolved_path.mkdir(parents=True, exist_ok=True)
                continue

            resolved_path.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(member) as src, open(resolved_path, "wb") as dst:
                dst.write(src.read())

def is_pyenv_available() -> bool:
    try:
        subprocess.run(["pyenv", "--version"], check=True, capture_output=True)
        return True
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False
    
def is_python_version_installed(version: str) -> bool:
    result = subprocess.run(["pyenv", "versions", "--bare"], capture_output=True, text=True)
    installed_versions = [v.strip() for v in result.stdout.splitlines()]
    return version in installed_versions

def install_python_version(version: str) -> bool:
    try:
        subprocess.run(["pyenv", "install", "-s", version], check=True)
        return True
    except subprocess.CalledProcessError:
        return False
    
def write_main_file(temp_dir, module_name, func_name, args, kwargs, db_provider):

    python_filename = os.path.join(temp_dir, "main.py")
    result_filename = os.path.join(temp_dir, "result.json")
    args_str = DBManager.to_json(args, db_provider)
    kwargs_str = DBManager.to_json(kwargs, db_provider)

    code = f'''

import json, traceback, os
from {module_name} import {func_name}

try:
    from dcm_processor_db_provider import DBManager
    def from_json(data, prov):
        return DBManager.from_json(data, prov)
except:
    def from_json(data, prov):
        return json.loads(data)


ARGS = from_json("""{ args_str }""", "{db_provider}")
KWARGS = from_json("""{ kwargs_str }""", "{db_provider}")

try:
    res = {func_name}(*ARGS, **KWARGS)
    data = dict(result=res)
except Exception as ex:
    data = dict(error=dict(message=str(ex), traceback=traceback.format_exc()))

res_filename = os.path.join(os.path.dirname(__file__), "result.json")
with open(res_filename, 'w') as f:
    json.dump(data, f)

'''
    with open(python_filename, 'w') as f:
        f.write(code)

    return python_filename, result_filename

def execute_code_with_python(python_path, tmpdir, module_name, func_name, args, kwargs, dbprovider, env):
    
    python_file, result_file = write_main_file(
        temp_dir=tmpdir,
        module_name=module_name,
        func_name=func_name,
        args=args,
        kwargs=kwargs,
        db_provider=dbprovider
    )

    patched_env = os.environ.copy()
    for k in env:
        patched_env[k] = env[k]

    command = [
        python_path,
        python_file
    ]
    
    subprocess.run(command, env=patched_env, stdout=sys.stdout, stderr=sys.stderr)

    result = {}
    with open(result_file, 'r') as f:
        result = json.load(f)

    return result
