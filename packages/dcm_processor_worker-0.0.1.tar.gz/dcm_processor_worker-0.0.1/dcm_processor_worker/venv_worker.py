from .base import BaseWorker
from .venv_worker_lib import create_venv_at, write_main_file, extract_zip_bytes
import os, json, subprocess, tempfile, zipfile, shutil, sys, copy
from dcm_processor_utils import get_device_id
from dcm_processor_db_provider import DBManager

DEFAULT_PACKAGES = [
    "dcm-processor-service"
]

REQUIREMENTS = ""

README = """
"""

class VenvWorker(BaseWorker):
    def __init__(self):
        super().__init__()

    @classmethod
    def __get_files(self, name):

        files = [
            {
                "path": ["requirements.txt"],
                "mode": "w",
                "data": REQUIREMENTS
            },
            {
                "path": ["README.md"],
                "mode": "w",
                "data": README
            }
        ]

        return files

    @classmethod
    def create(cls, name: str):
        files =  cls.__get_files(name=name)

        return {
            "files": files,
            "settings": {
                "name": name,
                "params": {},
                "python_version": "3.10"
            }
        }

    def install(self, dcm_settings: dict, dirname: str, worker_path: str):
        settings_path = os.path.join(dirname, "settings.json")
        settings = {}

        with open(settings_path, 'r') as f:
            settings = json.load(f)

        # create venv environment
        res = copy.deepcopy(settings)
        res["device_id"] = get_device_id()

        python_version = settings.get("python_version", "3.10")
        venv_path = os.path.join(worker_path, "venv")
        os.makedirs(worker_path, exist_ok=True)

        resolved_version, venv_python = create_venv_at(python_version=python_version, target_dir=venv_path)

        if venv_python is None or resolved_version is None:
            raise RuntimeError(f"Unable to create venv for worker '{settings.get('name')}'.")

        full_venv_python = venv_python
        if len(DEFAULT_PACKAGES) > 0:
            subprocess.run([full_venv_python, "-m", "pip", "install"] + DEFAULT_PACKAGES, check=True)

        requirements_path = os.path.join(dirname, "requirements.txt")
        if os.path.exists(requirements_path) and os.path.isfile(requirements_path):
            subprocess.run([full_venv_python, "-m", "pip", "install", "-r", requirements_path], check=True)
        
        res.update({
            "device_id": get_device_id(),
            "python_version": resolved_version,
            "venv_path": "venv",
            "venv_python_path": venv_python
        })
        
        return res, None
        
    def remove(self, settings: dict, worker_path: str):
        venv_path = os.path.join(worker_path, "venv")

        try:
            if os.path.exists(venv_path):
                shutil.rmtree(venv_path, ignore_errors=True)
        except:
            pass

        return None
        
    def execute(self, job_info, worker_info, service_info, args, kwargs, env, dbMgr: DBManager, **_kwargs):
        print("In Worker execute", flush=True)
        worker_path = worker_info.get("path")
        venv_path = worker_info.get("venv_path")
        python_path = worker_info.get("venv_python_path")

        full_python_path = os.path.join(worker_path, venv_path, python_path)
        service_module_file_id = service_info.get("module")
        
        with tempfile.TemporaryDirectory() as tmpdir:
            # 1. Extract zip to temp folder
            module_name = "service_module"
            func_name = job_info.get("job_worker_entry")

            full_path = os.path.join(tmpdir, module_name)
            os.makedirs(full_path, exist_ok=True)

            module_bytes = dbMgr.download_component_file(service_module_file_id)

            extract_zip_bytes(module_bytes, full_path)
            
            python_file, result_file = write_main_file(
                temp_dir=tmpdir,
                module_name=module_name,
                func_name=func_name,
                args=args,
                kwargs=kwargs,
                db_provider=dbMgr.dbprovider
            )

            patched_env = os.environ.copy()
            for k in env:
                patched_env[k] = env[k]

            command = [
                full_python_path,
                python_file
            ]
            
            subprocess.run(command, env=patched_env, stderr=sys.stderr, stdout=sys.stdout)

            result = {}
            with open(result_file, 'r') as f:
                result = json.load(f)

            if "error" in result:
                error = result.get("error", {})
                print(f"[{job_info.get('_id')}]: Error processing job", flush=True)
                print(f"[{job_info.get('_id')}]:", error.get("message"), flush=True)
                print(f"[{job_info.get('_id')}]:", error.get("traceback"), flush=True)

            return result
