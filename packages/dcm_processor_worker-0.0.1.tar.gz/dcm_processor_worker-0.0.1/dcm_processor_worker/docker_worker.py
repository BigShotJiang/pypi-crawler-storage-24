from .base import BaseWorker
from .venv_worker_lib import create_venv_at, write_main_file, execute_code_with_python, extract_zip_bytes
import os, json, subprocess, docker, copy, shutil, tempfile, zipfile, sys
from dcm_processor_utils import get_device_id, zip_directory
from dcm_processor_db_provider import DBManager

PRE = """
def callback(session_id, job_name, headers, params, added_params, session_dir, **kwargs):
    pass
    
"""

POST = """
def callback(session_id, job_name, headers, params, added_params, session_dir, **kwargs):
    pass
    
"""

DOCKERFILE = """
FROM python:3.10-slim
# can also use full python images e.g. python:3.10

# Install pip and build dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \\
    build-essential \\
    wget \\
    curl \\
    ca-certificates \\
    && rm -rf /var/lib/apt/lists/*

# Upgrade pip
RUN python -m pip install --upgrade pip

# Install dcm-processor packages packages
RUN pip install --no-cache-dir dcm-processor-service

# Optional: set working directory
WORKDIR /module

CMD ["python", "/module/main.py"]
"""

REQUIREMENTS = """
"""
DATA_README = """
All data files needed for processing can be put in this file.  
This is mounted by default to the /data path in the docker container. You can change this from the settings.json file `data_dir_mount`.
"""

MAIN_README = """
"""

DEFAULT_PACKAGES = [
    "dcm-processor-service",
    "docker"
]

class DockerWorker(BaseWorker):
    def __init__(self):
        super().__init__()

    @classmethod
    def __get_files(cls, name):

        files = [
            {
                "path": ["requirements.txt"],
                "mode": "w",
                "data": REQUIREMENTS
            },
            {
                "path": ["Dockerfile"],
                "mode": "w",
                "data": DOCKERFILE
            },
            {
                "path": ["pre.py"],
                "mode": "w",
                "data": PRE
            },
            {
                "path": ["post.py"],
                "mode": "w",
                "data": POST
            },
            {
                "path": ["data", "README.md"],
                "mode": "w",
                "data": DATA_README
            },
            {
                "path": ["README.md"],
                "mode": "w",
                "data": MAIN_README
            }
        ]

        return files

    @classmethod
    def create(cls, name: str):
        files =  cls.__get_files(name=name)

        return {
            "files": files,
            "settings": {
                "name": name,
                "image": "python:3.10-slim",
                "build": "Dockerfile",
                "params": {
                    "command": [],
                    "run_kwargs": {},
                },
                "build_kwargs": {},
                "pre_scripts": ["pre.py"],
                "post_scripts": ["post.py"],
                "data_dir": "data",
                "module_dir_mount": "/module",
                "data_dir_mount": "/data",
                "session_dir_mount": "/session",
                "python_version": "3.10",
            }
        }

    def install(self, dcm_settings: dict, dirname: str, worker_path: str):
        settings_path = os.path.join(dirname, "settings.json")
        settings = {}
        files = {}

        with open(settings_path, 'r') as f:
            settings = json.load(f)

        res = copy.deepcopy(settings)
        res["device_id"] = get_device_id()

        # Pull or build docker image
        docker_client = docker.from_env()

        if not settings.get("build") is None:
            build_kwargs = settings.get("build_kwargs", {})
            if not isinstance(build_kwargs, dict):
                build_kwargs = {}

            dockerfile = settings.get("build")
            image_name = f'{settings.get("name", dcm_settings.get("name"))}:{settings.get("version", dcm_settings.get("version"))}'

            req_kwargs = dict(
                path=dirname,
                dockerfile=dockerfile,
                tag=image_name,
                pull=True,
                forcerm=True,
                rm=True,
                decode=True
            )

            build_kwargs.update(req_kwargs)
            docker_res = docker_client.api.build(**build_kwargs)
            for chunk in docker_res:
                if "stream" in chunk:
                    print(chunk["stream"], end="")
                elif "error" in chunk:
                    raise RuntimeError(chunk["error"])

            res["image"] = image_name

        elif not settings.get("image") is None:

            image_name = settings.get("image")
            repository = str(image_name).strip().split(":")[0]
            tag_name = "".join(str(image_name).strip().split(":")[1:])

            if tag_name == "":
                tag_name = None
            
            print(f"Pulling docker image...", flush=True)
            docker_res = docker_client.api.pull(
                repository=repository,
                tag=tag_name,
                stream=True,
                decode=True
            )

            for chunk in docker_res:
                status = chunk.get("status")
                progress = chunk.get("progress")

                if progress:
                    sys.stdout.write(f"\r{status} {progress}")
                    sys.stdout.flush()
                elif status:
                    print(status)

            res["image"] = image_name
        else:
            raise RuntimeError("'image' and 'build' are missing from settings file for docker worker.")

        # create venv environment
        python_version = settings.get("python_version", "3.10")
        venv_path = os.path.join(worker_path, "venv")
        os.makedirs(worker_path, exist_ok=True)

        resolved_version, venv_python = create_venv_at(python_version=python_version, target_dir=venv_path)

        if venv_python is None or resolved_version is None:
            raise RuntimeError(f"Unable to create venv for worker '{settings.get('name')}'.")

        full_venv_python = venv_python
        if len(DEFAULT_PACKAGES) > 0:
            subprocess.run([full_venv_python, "-m", "pip", "install"] + DEFAULT_PACKAGES, check=True)

        requirements_path = os.path.join(dirname, "requirements.txt")
        if os.path.exists(requirements_path) and os.path.isfile(requirements_path):
            subprocess.run([full_venv_python, "-m", "pip", "install", "-r", requirements_path], check=True)
        
        res.update({
            "python_version": resolved_version,
            "venv_path": "venv",
            "venv_python_path": venv_python
        })

        script_files = settings.get("pre_scripts", []) + settings.get("post_scripts", [])
        for fn in script_files:
            full_path = os.path.join(dirname, fn)
            if os.path.exists(full_path) and os.path.isfile(full_path):
                files[fn] = full_path

        if "data_dir" in settings:
            data_dir = settings.get("data_dir")
            if str(data_dir).strip() != "":
                data_dir_path = os.path.join(dirname, data_dir)

                if os.path.exists(data_dir_path):
                    if os.path.isdir(data_dir_path):
                        files["data_dir"] = zip_directory(data_dir_path, f"{data_dir_path}.zip")
                    elif os.path.isfile(data_dir_path) and str(data_dir_path).endswith((".zip", ".tar.gz", ".tgz", ".tar.bz2", ".tar.xz")):
                        files["data_dir"] = data_dir_path
        
        return res, files

    def remove(self, settings: dict, worker_path):
        # remove venv
        venv_path = os.path.join(worker_path, "venv")

        try:
            if os.path.exists(venv_path):
                shutil.rmtree(venv_path, ignore_errors=True)
        except:
            pass

        # Remove docker images
        
        image_name = settings.get("image")
        if not image_name is None:
            docker_client = docker.from_env()
            try:     
                docker_client.images.remove(
                    image=image_name,
                    force=True,
                    noprune=False
                )
            except Exception as e:
                print(f"Error removing worker image {e}")

        return None
    
    def execute(self, job_info, worker_info, service_info, args, kwargs, env, dbMgr: DBManager, **_kwargs):
        worker_path = worker_info.get("path")
        venv_path = worker_info.get("venv_path")
        python_path = worker_info.get("venv_python_path")

        full_python_path = os.path.join(worker_path, venv_path, python_path)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create session directory
            temp_session_dir = os.path.join(tmpdir, "session")
            os.makedirs(temp_session_dir, exist_ok=True)
            kwargs["session_dir"] = temp_session_dir

            worker_files = worker_info.get("worker_files", {})

            # 1. Execute pre scripts
            pre_scripts = worker_info.get("pre_scripts", [])
            for script in pre_scripts:
                if script in worker_files:
                    script_file_id = worker_files[script]
                    script_bytes = dbMgr.download_component_file(script_file_id)
                    script_filename = os.path.join(tmpdir, "runnable_script.py")

                    with open(script_filename, "wb") as f:
                        f.write(script_bytes.getvalue())

                    module_name = "runnable_script"
                    func_name = "callback"

                    res = execute_code_with_python(
                        python_path=full_python_path,
                        tmpdir=tmpdir,
                        module_name=module_name,
                        func_name=func_name,
                        args=args,
                        kwargs=kwargs,
                        dbprovider=dbMgr.dbprovider,
                        env=env
                    )

                    if "error" in res:
                        error = res.get("error", {})
                        print(f"[{job_info.get('_id')}]: Error processing pre script {script}", flush=True)
                        print(f"[{job_info.get('_id')}]:", error.get("message"), flush=True)
                        print(f"[{job_info.get('_id')}]:", error.get("traceback"), flush=True)


            temp_module_parent = os.path.join(tmpdir, "module")

            # 2. Extract service zip to temp folder
            service_module_name = "service_module"
            service_func_name = job_info.get("job_worker_entry")

            service_module_file_id = service_info.get("module")
            if not service_module_file_id is None:
                service_module_full_path = os.path.join(temp_module_parent, service_module_name)
                os.makedirs(service_module_full_path, exist_ok=True)
                service_module_bytes = dbMgr.download_component_file(service_module_file_id)
                extract_zip_bytes(service_module_bytes, service_module_full_path)

            # 3. Extract worker data zip to temp folder
            worker_data_file_id = worker_files.get("data_dir")
            worker_data_full_path = None
            if not worker_data_file_id is None:
                worker_data_full_path = os.path.join(tmpdir, "worker_data")
                os.makedirs(worker_data_full_path, exist_ok=True)
                worker_data_bytes = dbMgr.download_component_file(worker_data_file_id)
                extract_zip_bytes(worker_data_bytes, worker_data_full_path)

            # 4. Prepare docker and execute
            _, result_filename = write_main_file(
                temp_dir=temp_module_parent,
                module_name=service_module_name,
                func_name=service_func_name,
                args=args,
                kwargs=kwargs,
                db_provider=dbMgr.dbprovider
            )

            docker_client = docker.from_env()

            worker_image = worker_info.get("image")
            docker_command = worker_info.get("params", {}).get("command", [])
            run_kwargs = worker_info.get("params", {}).get("run_kwargs", {})

            data_mount = worker_info.get("data_dir_mount", "/data")
            module_mount = worker_info.get("module_dir_mount", "/module")
            session_mount = worker_info.get("session_dir_mount", "/session")

            docker_volumes = {
                temp_module_parent: {"bind": module_mount, "mode": "rw"},
                temp_session_dir: {"bind": session_mount, "mode": "rw"}
            }

            if not worker_data_full_path is None:
                docker_volumes[worker_data_full_path] = {"bind": data_mount, "mode": "rw"}

            if (docker_command is None) or (len(docker_command) == 0) or (str(docker_command).strip() == ""):
                docker_command = [
                    "python",
                    os.path.join(module_mount, "main.py")
                ]

            docker_env = copy.deepcopy(env)
            docker_env["PYTHONPATH"] = module_mount
            docker_env["PYTHONUNBUFFERED"] = "1"

            container = docker_client.containers.run(
                image=worker_image,
                command=docker_command,
                volumes=docker_volumes,
                environment=docker_env,
                working_dir=module_mount,
                detach=True,
                tty=False,
                stdout=True,
                stderr=True,
                user=f"{os.getuid()}:{os.getgid()}",
                **run_kwargs
            )

            for line in container.logs(stream=True):
                print(line.decode(), end="")

            container.wait()
            container.remove()

            # 5. Read result from docker

            result = {}

            with open(result_filename, 'r') as f:
                result = json.load(f)

            if "error" in result:
                error = result.get("error", {})
                print(f"[{job_info.get('_id')}]: Error processing job", flush=True)
                print(f"[{job_info.get('_id')}]:", error.get("message"), flush=True)
                print(f"[{job_info.get('_id')}]:", error.get("traceback"), flush=True)

            # 6. Execute post scripts
            post_scripts = worker_info.get("post_scripts", [])
            for script in post_scripts:
                if script in worker_files:
                    script_file_id = worker_files[script]
                    script_bytes = dbMgr.download_component_file(script_file_id)
                    script_filename = os.path.join(tmpdir, "runnable_script.py")

                    with open(script_filename, "wb") as f:
                        f.write(script_bytes.getvalue())

                    module_name = "runnable_script"
                    func_name = "callback"

                    res = execute_code_with_python(
                        python_path=full_python_path,
                        tmpdir=tmpdir,
                        module_name=module_name,
                        func_name=func_name,
                        args=args,
                        kwargs=kwargs,
                        dbprovider=dbMgr.dbprovider,
                        env=env
                    )

                    if "error" in res:
                        error = res.get("error", {})
                        print(f"[{job_info.get('_id')}]: Error processing post script {script}", flush=True)
                        print(f"[{job_info.get('_id')}]:", error.get("message"), flush=True)
                        print(f"[{job_info.get('_id')}]:", error.get("traceback"), flush=True)

            return result
