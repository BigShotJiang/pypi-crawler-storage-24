from dcm_processor_db_provider import DBManager

class BaseWorker:
    def __init__(self):
        pass

    @classmethod
    def create(cls, name: str) -> dict:
        ''' 
        This method should return a worker template for the given template type.
        Should return a dict objects defining the files for the template in the format
        {
            "settings": {}, # Any settings you want to write into the settings.json file
            "files": [
                {
                    "path": ["requirements.txt"],
                    "mode": "w",
                    "data": REQUIREMENTS
                },
            ]
        }
        '''
        pass

    @classmethod
    def initialize_system(cls, system_dir: str):
        pass

    @classmethod
    def initialize_app(cls, app_dir: str):
        pass

    def install(self, dcm_settings: dict, dirname: str, worker_path: str) -> dict:
        '''
        This method takes an implemented worker template and install it and return a dict object which represents this worker.
        The dict will then be provided as worker_info during execute.
        
        :param dirname: directory with the worker files
        :type dirname: str
        :param worker_path: Path to the worker base directory for this worker to be installed
        :type worker_path: str
        :return: Dict with information about the worker to be persisted in DB
        :rtype: dict
        '''
        pass

    def remove(self, settings: dict, worker_path: str) -> list|None:
        '''
        This method takes an implemented worker template and install it and return a dict object which represents this worker.
        The dict will then be provided as worker_info during execute.
        
        :param dirname: directory with the worker files
        :type dirname: str
        :param worker_path: Path to the worker base directory for this worker to be installed
        :type worker_path: str
        :return: list of file fields to be removed from DB
        :rtype: list or None
        '''
        pass

    def execute(self, job_info: dict, worker_info: dict, service_info: dict, args: list, kwargs: dict, env: dict, dbMgr: DBManager, **_kwargs):
        '''
        This method should execute the service based on the params above.
        
        :param worker_info: Dict containing the information store during installation, this could be path to certain executables or anything
        :type worker_info: dict
        :param service_info: Information about the service to be executed
        :type service_info: dict
        :param args: positional arguments for the execution
        :type args: list
        :param kwargs: name arguments for the execution
        :type kwargs: dict
        '''
        pass