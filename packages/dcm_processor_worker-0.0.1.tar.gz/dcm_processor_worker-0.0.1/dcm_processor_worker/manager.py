from typing import Type, TypeVar
import os, pathlib, json, tempfile, subprocess, sys, zipfile
from .base import BaseWorker
from .venv_worker_lib import write_main_file, extract_zip_bytes
from dcm_processor_db_provider import DBManager

T = TypeVar("T", bound=BaseWorker)

DOWNLOAD_API = "https://downloads.dcm-processor.com"
DICOMFILEBUCKET = "dicomfiles"
PEERSCOLL = "peers"
SERIESCOLL = "series"
STUDYCOLL = "studies"
PATIENTCOLL = "patients"
LOGSCOLL = "systemlogs"
SESSIONCOLL = "sessions"
JOBSCOLL = "jobs"

SERIES_TAGS = []
STUDY_TAGS = []
PATIENT_TAGS = []

class WorkerManager:
    
    worker_providers: dict[str, Type[T]] = {}

    @classmethod
    def register_provider(cls, provider, definition: Type[T]):
        
        if not isinstance(definition, type) or not issubclass(definition, BaseWorker):
            raise TypeError("definition must be a class derived from BaseWorker")
        
        cls.worker_providers[provider] = definition

    @staticmethod
    def __job_value(job_info, *keys):
        if job_info is None:
            return None

        for key in keys:
            if key in job_info and job_info.get(key) is not None:
                return job_info.get(key)

        return None

    @classmethod
    def __job_env_value(cls, job_info, *keys):
        value = cls.__job_value(job_info, *keys)
        return "" if value is None else str(value)

    @classmethod
    def __make_service_env(cls, job_info, dbprovider, dburl, dbname):
        return {
            "DCM-PROCESSOR-SERVICE-DB-PROVIDER": dbprovider,
            "DCM-PROCESSOR-SERVICE-DB-URL": dburl,
            "DCM-PROCESSOR-SERVICE-DB-NAME": dbname,
            "DCM-PROCESSOR-SERVICE-SESSION-ID": cls.__job_env_value(job_info, "sessionId", "session_id"),
            "DCM-PROCESSOR-SERVICE-JOB-ID": cls.__job_env_value(job_info, "_id", "job_id"),
            "DCM-PROCESSOR-SERVICE-JOB-EVENT": cls.__job_env_value(job_info, "job_event", "event"),
            "DCM-PROCESSOR-SERVICE-JOB-NAME": cls.__job_env_value(job_info, "job_name", "jobName"),
            "DCM-PROCESSOR-SERVICE-JOB-SERVICE-NAME": cls.__job_env_value(job_info, "service_name", "serviceName"),
            "DCM-PROCESSOR-SERVICE-PEER-ID": cls.__job_env_value(job_info, "peer_id", "PeerUID"),
        }

    @classmethod
    def __execute_default(self, job_info, service_info, args, kwargs, env, dbMgr: DBManager):

        full_python_path = sys.executable
        service_module_file_id = service_info.get("module")
        
        with tempfile.TemporaryDirectory() as tmpdir:
            # 1. Extract zip to temp folder
            module_name = "service_module"
            func_name = job_info.get("job_worker_entry")

            full_path = os.path.join(tmpdir, module_name)
            os.makedirs(full_path, exist_ok=True)

            module_bytes = dbMgr.download_component_file(service_module_file_id)

            extract_zip_bytes(module_bytes, full_path)
            
            python_file, result_file = write_main_file(
                temp_dir=tmpdir,
                module_name=module_name,
                func_name=func_name,
                args=args,
                kwargs=kwargs,
                db_provider=dbMgr.dbprovider
            )

            patched_env = os.environ.copy()
            for k in env:
                patched_env[k] = env[k]

            command = [
                full_python_path,
                python_file
            ]
            
            subprocess.run(command, env=patched_env, stderr=sys.stderr, stdout=sys.stdout)

            result = {}
            with open(result_file, 'r') as f:
                result = json.load(f)

            if "error" in result:
                error = result.get("error", {})
                print(f"[{job_info.get('_id')}]: Error processing job", flush=True)
                print(f"[{job_info.get('_id')}]:", error.get("message"), flush=True)
                print(f"[{job_info.get('_id')}]:", error.get("traceback"), flush=True)
            
            return result
    
    @classmethod
    def handle_default_worker(cls, *args, **kwargs):
        job_id = kwargs.get("job_id")
        dburl = kwargs.get("db_url")
        dbname = kwargs.get("db_name")
        dbprovider = kwargs.get("db_provider")

        dbMgr = DBManager(
            dburl=dburl,
            dbname=dbname,
            dbprovider=dbprovider
        )
        
        service_info = dbMgr.get_service_by_id(service_id=kwargs.get("service_id"))
        job_info = dbMgr.get_job_by_id(job_id=job_id)

        env_vars = cls.__make_service_env(job_info, dbprovider, dburl, dbname)

        return cls.__execute_default(
            service_info=service_info,
            job_info=job_info,
            args=args,
            kwargs=kwargs,
            env=env_vars,
            dbMgr=dbMgr
        )
    
    @classmethod
    def worker_callback(cls, *args, **kwargs):
        job_id = kwargs.get("job_id")
        print(f"Started processing job with id {job_id}", flush=True)

        worker_id = kwargs.get('worker_id')
        worker_type = kwargs.get("worker_type")
        if (worker_id is None) or (worker_type is None):
            # handle this with local/default worker
            print("No worker or worker type provided by service, running with default worker!")
            return cls.handle_default_worker(*args, **kwargs)
        
        if worker_type in cls.worker_providers:
            worker_mgr = cls.worker_providers[worker_type]()
            
            dburl = kwargs.get("db_url")
            dbname = kwargs.get("db_name")
            dbprovider = kwargs.get("db_provider")

            dbMgr = DBManager(
                dburl=dburl,
                dbname=dbname,
                dbprovider=dbprovider
            )
            
            worker_info = dbMgr.get_worker_by_id(worker_id=worker_id)
            service_info = dbMgr.get_service_by_id(service_id=kwargs.get("service_id"))
            job_info = dbMgr.get_job_by_id(job_id=job_id)

            env_vars = cls.__make_service_env(job_info, dbprovider, dburl, dbname)

            return worker_mgr.execute(
                worker_info=worker_info,
                service_info=service_info,
                job_info=job_info,
                args=args,
                kwargs=kwargs,
                env=env_vars,
                dbMgr=dbMgr
            )

    @classmethod
    def get_worker_path(self, name: str, dirname: str) -> pathlib.Path:
        new_path = os.path.join(dirname, 'worker')
        return pathlib.Path(new_path).resolve()

    @classmethod
    def create_worker(cls, name: str, wtype: str, dirname: str):
        base_dir = cls.get_worker_path(name, dirname)

        if wtype not in cls.worker_providers:
            print(f"Worker type {wtype} not implemented or registered!")
            return
        
        provider = cls.worker_providers[wtype]
        create_data = provider.create(name=name)

        files = create_data.get('files', [])
        settings = create_data.get('settings', {})

        for file in files:
            filename = base_dir.joinpath(*file.get("path"))
            filename.parent.mkdir(parents=True, exist_ok=True)
            with open(filename, file.get("mode", "w")) as f:
                f.write(file.get("data"))

        # Write settings files
        settings["name"] = name
        settings["type"] = wtype
        settings["version"] = "0.0.1"
        filename = base_dir.joinpath("settings.json")

        with open(filename, file.get("mode", "w")) as f:
            json.dump(settings, f, indent=4)

        return base_dir

    @classmethod
    def install_worker(cls, settings: dict, wtype: str, dirname: str, worker_dir: str, force: bool=False) -> tuple[dict, dict]:
        if wtype not in cls.worker_providers:
            print(f"No registered provided for worker type '{wtype}'")
            return
        
        # Check if worker exists
        name = settings.get("name")
        provider = cls.worker_providers[wtype]()
        worker_own_path = os.path.join(worker_dir, name)

        info, file_paths = provider.install(
            dcm_settings=settings,
            dirname=dirname,
            worker_path=worker_own_path
        )

        if info is None:
            info = {}

        info["path"] = worker_own_path
        info["name"] = name
        info["type"] = wtype

        return info, file_paths
    
    @classmethod
    def remove_worker(cls, settings: dict, wtype: str, worker_dir: str):
        if wtype not in cls.worker_providers:
            print(f"No registered provided for worker type '{wtype}'")
            return
        
        # Check if worker exists
        name = settings.get("name")
        provider = cls.worker_providers[wtype]()
        worker_own_path = os.path.join(worker_dir, name)

        files = provider.remove(
            settings=settings,
            worker_path=worker_own_path
        )

        return files
        
    @classmethod
    def default_service_callback(cls, func_name, *args, **kwargs):
        job_id = kwargs.get("job_id")
        print(f"Started processing job with id {job_id}", flush=True)

        dburl = kwargs.get("db_url")
        dbname = kwargs.get("db_name")
        dbprovider = kwargs.get("db_provider")

        dbMgr = DBManager(
            dburl=dburl,
            dbname=dbname,
            dbprovider=dbprovider
        )
        
        job_info = dbMgr.get_job_by_id(job_id=job_id)

        env = cls.__make_service_env(job_info, dbprovider, dburl, dbname)

        full_python_path = sys.executable
        
        with tempfile.TemporaryDirectory() as tmpdir:
            # 1. Extract zip to temp folder
            module_name = "dcm_processor_service"
            
            python_file, result_file = write_main_file(
                temp_dir=tmpdir,
                module_name=module_name,
                func_name=func_name,
                args=args,
                kwargs=kwargs,
                db_provider=dbMgr.dbprovider
            )

            patched_env = os.environ.copy()
            for k in env:
                patched_env[k] = env[k]

            command = [
                full_python_path,
                python_file
            ]
            
            subprocess.run(command, env=patched_env, stderr=sys.stderr, stdout=sys.stdout)

            result = {}
            with open(result_file, 'r') as f:
                result = json.load(f)

            if "error" in result:
                error = result.get("error", {})
                print(f"[{job_info.get('_id')}]: Error processing job", flush=True)
                print(f"[{job_info.get('_id')}]:", error.get("message"), flush=True)
                print(f"[{job_info.get('_id')}]:", error.get("traceback"), flush=True)
            
            return result
