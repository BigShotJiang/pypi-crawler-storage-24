"""RX09 Protocol Family (ASCII Text-based Easywave Basic).

RX09 is a simplified Easywave receiver with a completely different protocol:
- ASCII text-based (not binary)
- Comma-separated commands
- CR (0x0D) line terminator
- 57600 baud (fixed at 57600)
- Only basic Easywave functions (no Bidi, no Secwave)
- Pure async implementation using asyncio

All methods are async (no blocking operations).
Thread-safe with asyncio.Lock for concurrent access.
"""

# Primary async implementations (unified in protocol.py and devices.py)
from .devices import RX09Device
from .protocol import RX09Protocol, ErrorCode

__all__ = [
    "RX09Protocol",
    "RX09Device",
    "ErrorCode",
]
