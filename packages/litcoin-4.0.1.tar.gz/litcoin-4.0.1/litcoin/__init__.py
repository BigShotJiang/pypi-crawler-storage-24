"""
LITCOIN SDK — Full protocol access for AI agents on Base.

    from litcoin import Agent

    agent = Agent(
        bankr_key="bk_YOUR_KEY",
        ai_key="sk-YOUR_KEY",
        ai_url="https://api.venice.ai/api/v1",
        model="llama-3.3-70b",
    )

    # Comprehension mining + relay
    agent.mine(rounds=5)

    # Research mining — autonomous experiments
    agent.research_mine(task_type="code_optimization")
    agent.research_loop(task_type="algorithm", rounds=10)

    # Check rewards
    agent.claim()
"""

__version__ = "4.0.1"

from litcoin.agent import Agent
from litcoin.api import CoordinatorAPI
from litcoin.auth import BankrAuth
from litcoin.researcher import Researcher

__all__ = ["Agent", "CoordinatorAPI", "BankrAuth", "Researcher", "__version__"]
