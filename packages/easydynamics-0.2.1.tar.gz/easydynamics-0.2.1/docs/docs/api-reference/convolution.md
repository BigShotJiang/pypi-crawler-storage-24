::: easydynamics.convolution
