::: easydynamics.sample_model
