::: easydynamics.experiment
