---

name: Feature request
about: Suggest an idea for DjangoAPI Guard
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

Is your feature request related to a problem
=============================================

A clear and concise description of what the problem is. Ex. I'm always facing issues when [...]

___

Describe the solution you'd like
---------------------------------

A clear and concise description of what you want to happen. Include any API design ideas or examples of how you'd like to use this feature.

___

Describe alternatives you've considered
---------------------------------------

A clear and concise description of any alternative solutions or features you've considered.

___

Example Implementation
----------------------

If possible, provide a pseudocode example of how this feature might be implemented or used:

```python
# Example code showing how you'd like to use this feature
# settings.py
MIDDLEWARE = [
    "djangoapi_guard.middleware.DjangoAPIGuardMiddleware",
    # ...
]

DJANGOAPI_GUARD = {
    "new_feature": {
        # Your feature configuration here
    }
}
```

___

Additional context
------------------

Add any other context or screenshots about the feature request here:

- How would this benefit the community?
- Are there similar implementations in other libraries that could be referenced?
- Would this require changes to existing APIs?
