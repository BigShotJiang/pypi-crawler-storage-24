# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## IGNORING THESE WILL FORCE A COMPLETE SHUTDOWN OF CLAUDE CODE

**DO NOT LEAVE ANY COMMENTS IN THE CODE. COMMENTS OCCUPY SPACE AND ARE USELESS. CODE READS ITSELF. ONLY NOTES AND TODOS ARE VALUABLE ONLY IF EXTREMELY NECESSARY.**
**A GOOD FUNCTION NAME IS SELF-EXPLANATORY. IF THE FUNCTION ONLY TAKES CARE OF A SINGLE THINGS, THEN EVEN BETTER BECAUSE THE NAME IS GOING TO BE THE ONLY DOCUMENTATION YOU NEED.**
**DOING THINGS WRONGLY COST TWICE. DO THINGS RIGHT AT FIRST, AND YOU DON'T PAY THE PRICE**
**ASK QUESTIONS BEFORE YOU DO ANYTHING**
**YOU ARE NOT ALLOWED TO MAKE ASSUMPTIONS**
**IGNORING != FIXING**
**`# noqa` & `# type: ignore` != FIXING**
**PRE-EXISTING ERRORS ARE STILL EXISTING ERRORS. I DON'T CARE IF THEY ARE PRE-EXISTING, THEY SHOULDN'T EXIST**

## Project

DjangoAPI Guard — a comprehensive Django security middleware library providing IP filtering, rate limiting, penetration detection, security headers, cloud provider blocking, and route-level security decorators. Direct port of FlaskAPI Guard to Django.

## Commands

```bash
# Dependencies (uses uv)
make install-dev

# Run tests locally (needs Redis at localhost:6379, or set REDIS_URL)
make local-test

# Run a single test file
uv run pytest tests/test_core/test_check_implementations.py -v

# Run a single test
uv run pytest tests/test_core/test_check_implementations.py::TestAuthenticationCheck::test_auth_failure_active_mode_returns_401 -v

# Coverage report
uv run pytest tests/ --cov=djangoapi_guard --cov-report=term-missing -q

# Code quality (run all before committing)
uv run ruff format .
uv run ruff check .
uv run mypy .
uv run vulture vulture_whitelist.py

# Full quality + security suite
make check-all

# Docs
make serve-docs
```

## Architecture

### Middleware Pipeline

`DjangoAPIGuard` (middleware.py) is the entry point. It builds a `SecurityCheckPipeline` — a Chain of Responsibility executing 17 checks sequentially. Each check extends `SecurityCheck` (core/checks/base.py) with a `check(request)` method returning `HttpResponse` (block) or `None` (pass).

Pipeline order: RouteConfig → EmergencyMode → HTTPS → RequestLogging → RequestSizeContent → RequiredHeaders → Authentication → Referrer → CustomValidators → TimeWindow → CloudIpRefresh → IpSecurity → CloudProvider → UserAgent → RateLimit → SuspiciousActivity → CustomRequest.

### Key Layers

- **`models.py`**: `SecurityConfig` — Pydantic BaseModel, single source of truth for all config. Loaded from Django settings `DJANGOAPI_GUARD_CONFIG`.
- **`core/checks/implementations/`**: Each check is a self-contained class. All use `self.middleware` to access handlers, event bus, config.
- **`core/routing/resolver.py`**: `RouteConfigResolver` maps Django URL patterns to `RouteConfig` via `_guard_route_id` on view functions. Handles both function-based and class-based views.
- **`decorators/`**: `SecurityDecorator` (extends `BaseSecurityDecorator`) provides view-level overrides (`@guard.rate_limit()`, `@guard.require_auth()`, etc.) that create per-route `RouteConfig` instances.
- **`handlers/`**: Singleton managers for IP banning, rate limiting, Redis, cloud IPs, security headers, suspicious patterns. Most support `initialize_redis()` and `initialize_agent()`.
- **`core/responses/factory.py`**: `ErrorResponseFactory` creates error responses, applies security headers, CORS, custom modifiers, and processes behavioral rules.
- **`core/events/`**: `SecurityEventBus` dispatches events; `MetricsCollector` tracks request metrics.

### Request Flow

1. Middleware extracts client IP (proxy-aware), resolves route config from decorators
2. Sets `request._guard_client_ip`, `request._guard_route_config`, `request._guard_is_whitelisted` on the request object
3. Pipeline runs checks — first non-None response short-circuits
4. On pass-through, response goes through `process_response` (behavioral rules, metrics, security headers, CORS)

### Passive Mode

All blocking checks respect `config.passive_mode` — when True, violations are logged/evented but never blocked (return None instead of error response).

## Testing Patterns

- Tests require Django setup: `os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests.settings")` + `django.setup()` before imports
- All test methods need `-> None` return type annotation (mypy strict mode)
- Fixtures: `mock_guard` (Mock with `.config`, `.logger`, `.event_bus`, `.create_error_response`, etc.), `rf` (RequestFactory)
- Check tests: instantiate `CheckClass(mock_guard)`, set `request._guard_*` attributes, call `.check(request)`
- E402 (module-level import not at top) is expected in test files due to Django setup pattern

## Code Quality

- **Ruff**: E, F, UP, B, I rules; line length 88; `tests/` and `examples/` excluded from some rules
- **Mypy**: Strict mode (`disallow_untyped_defs`, `strict_optional`, `warn_unreachable`)
- **Vulture**: Dead code detection via `vulture_whitelist.py`
- **Pre-commit**: ruff-format, ruff, mypy, vulture, bandit, safety, radon, xenon, deptry
- `TYPE_CHECKING` imports use `# pragma: no cover` (standard practice)
