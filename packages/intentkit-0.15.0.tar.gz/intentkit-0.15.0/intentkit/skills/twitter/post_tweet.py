import logging
from decimal import Decimal

from langchain_core.tools import ArgsSchema, ToolException
from pydantic import BaseModel, Field

from intentkit.clients import get_twitter_client
from intentkit.clients.s3 import get_cdn_url
from intentkit.config.config import config
from intentkit.skills.twitter.base import TwitterBaseTool

NAME = "twitter_post_tweet"
PROMPT = "Post a new tweet. To attach an image, use the image parameter instead of adding a link in text."

logger = logging.getLogger(__name__)


class TwitterPostTweetInput(BaseModel):
    """Input for TwitterPostTweet tool."""

    text: str = Field(
        description="Tweet text",
        max_length=25000,
    )
    image: str | None = Field(default=None, description="Image URL to attach")


class TwitterPostTweet(TwitterBaseTool):
    """Post a new tweet to Twitter."""

    name: str = NAME
    description: str = PROMPT
    price: Decimal = Decimal("60")
    args_schema: ArgsSchema | None = TwitterPostTweetInput

    async def _arun(
        self,
        text: str,
        image: str | None = None,
        **kwargs,
    ):
        context = self.get_context()
        try:
            skill_config = context.agent.skill_config(self.category)
            twitter = get_twitter_client(
                agent_id=context.agent_id,
                config=skill_config,
            )
            client = await twitter.get_client()

            # Check rate limit only when not using OAuth
            if not twitter.use_key:
                await self.check_rate_limit(max_requests=24, interval=1440)

            media_ids = []
            image_warning = ""

            # Handle image upload if provided
            if image:
                # Validate image URL - must be from system's S3 CDN
                aws_s3_cdn_url = config.aws_s3_cdn_url
                if aws_s3_cdn_url and image.startswith(aws_s3_cdn_url):
                    # Already a full CDN URL from agent output
                    media_ids = await twitter.upload_media(context.agent_id, image)
                elif aws_s3_cdn_url and not image.startswith("http"):
                    # Relative path - build full CDN URL for upload
                    full_url = get_cdn_url(image)
                    media_ids = await twitter.upload_media(context.agent_id, full_url)
                else:
                    # Image is not from system's S3 CDN, skip upload but warn
                    image_warning = "Warning: The provided image URL is not from the system's S3 CDN and has been ignored. "
                    logger.warning(
                        f"Image URL validation failed for agent {context.agent_id}: {image}"
                    )

            # Post tweet using tweepy client
            tweet_params = {"text": text, "user_auth": twitter.use_key}
            if media_ids:
                tweet_params["media_ids"] = media_ids

            response = await client.create_tweet(**tweet_params)
            if "data" in response and "id" in response["data"]:
                # Return response with warning if image was ignored
                result = (
                    f"{image_warning}Tweet posted successfully. Response: {response}"
                )
                return result
            else:
                logger.error("Error posting tweet: %s", response)
                raise ToolException("Failed to post tweet.")

        except Exception as e:
            logger.error("Error posting tweet: %s", e)
            raise type(e)(f"[agent:{context.agent_id}]: {e}") from e
