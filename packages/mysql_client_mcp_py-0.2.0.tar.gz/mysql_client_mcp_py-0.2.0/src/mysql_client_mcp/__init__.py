"""MySQL-protocol database MCP Server."""

__version__ = "0.2.0"
