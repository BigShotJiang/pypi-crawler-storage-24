from datetime import datetime
import requests

from . import authentication, session as jms_session
from .const import DEFAULT_ORG
from .utils import record_time, import_string


class SessionClient(object):
    def __init__(self, session, *args, **kwargs):
        self.timer = 0  # 用于统计接口耗时
        self.org_id = DEFAULT_ORG
        self.session = session
        self.web_url = session.auth.web_url
        self.api_version = kwargs.pop('api_version', None)
        timeout = kwargs.pop('timeout', None)
        self.request_kwargs = {}
        if timeout is not None:
            self.request_kwargs['timeout'] = timeout

    def set_org(self, org_id):
        self.org_id = org_id

    def _build_headers(self, headers=None):
        headers = headers or {}
        request_headers = {
            'X-JMS-ORG': self.org_id,
            'Accept': 'application/json',
            'Date': datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
        }
        if self.session.token:
            request_headers['Authorization'] = self.session.token
        request_headers.update(headers)
        return request_headers

    def _request(self, url, method, headers=None, data=None, params=None, **kwargs):
        request_kwargs = dict(self.request_kwargs)
        request_kwargs.update(kwargs)
        request_headers = self._build_headers(headers=headers)

        return requests.request(
            method=method.upper(), url=f'{self.web_url}/{url}',
            auth=self.session.ak_auth, verify=False, headers=request_headers,
            json=data, params=params, **request_kwargs
        )

    @record_time
    def request(self, url, method, headers=None, data=None, params=None, **kwargs):
        return self._request(
            url=url, method=method, headers=headers,
            data=data, params=params, **kwargs
        )

    def detect_api_version(self):
        response = self._request(url='api/v1/settings/client/versions/', method='get')
        if response.status_code < 400:
            try:
                versions = response.json()
                if isinstance(versions, list) and versions:
                    return sorted(
                        map(str, versions),
                        key=lambda value: self._version_sort_key(value),
                        reverse=True,
                    )[0]
            except Exception:
                pass

        zones_response = self._request(url='api/v1/assets/zones/', method='options')
        domains_response = self._request(url='api/v1/assets/domains/', method='options')
        zones_exists = zones_response.status_code != 404
        domains_exists = domains_response.status_code != 404
        if zones_exists and not domains_exists:
            return '4.0'
        if domains_exists and not zones_exists:
            return '3.0'
        return '3.0'

    def resolve_api_version(self):
        if self.api_version:
            return self.api_version
        self.api_version = self.detect_api_version()
        return self.api_version

    @staticmethod
    def _version_sort_key(version):
        parts = []
        for piece in str(version).replace('v', '').split('.'):
            if piece.isdigit():
                parts.append(int(piece))
            else:
                digits = ''.join(filter(str.isdigit, piece))
                parts.append(int(digits) if digits else 0)
        while len(parts) < 3:
            parts.append(0)
        return tuple(parts[:3])


def construct_http_client(
        api_version=None, auth=None, auth_token=None, web_url=None,
        username=None, password=None, key_id=None, secret_id=None,
        session=None, **kwargs
):
    if not session:
        if key_id and secret_id:
            auth = authentication.AccessKey(
                web_url=web_url, key_id=key_id, secret_id=secret_id
            )
        if not auth and auth_token:
            auth = authentication.Token(web_url=web_url, auth_token=auth_token)
        elif not auth:
            auth = authentication.Password(
                web_url=web_url, username=username, password=password,
            )
        session = jms_session.Session(auth=auth)

    client = SessionClient(
        api_version=api_version, auth=auth, session=session, **kwargs
    )
    client.resolve_api_version()
    return client


def _get_client_class_and_version(version):
    # 先写死，后期换成 ApiVersion 对象管理
    return version, import_string("jms_client.v1.client.Client")


def get_client(
        version=None, username=None, password=None, web_url=None,
        access_key=None, secret_key=None, **kwargs
):
    """
    :param web_url: JumpServer 堡垒机网页地址，如 127.0.0.1：8080
    :param version: JumpServer 堡垒机版本信息，如 3.10。默认自动探测
    :param access_key: JumpServer 个人信息- API Key - ID
    :param secret_key: JumpServer 个人信息- API Key - Secret
    :param username: 登陆 JumpServer 的用户名
    :param password: 登陆 JumpServer 的密码
    :param kwargs: 其他参数
    :return: JMSClient
    """
    api_version, client_class = _get_client_class_and_version(version)
    web_url = web_url[:-1] if web_url.endswith('/') else web_url
    return client_class(
        api_version=api_version, web_url=web_url,
        username=username, password=password,
        key_id=access_key, secret_id=secret_key,
        **kwargs
    )
