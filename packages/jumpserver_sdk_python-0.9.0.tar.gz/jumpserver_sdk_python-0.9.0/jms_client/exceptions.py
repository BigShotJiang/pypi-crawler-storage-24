class JMSException(Exception):
    pass
