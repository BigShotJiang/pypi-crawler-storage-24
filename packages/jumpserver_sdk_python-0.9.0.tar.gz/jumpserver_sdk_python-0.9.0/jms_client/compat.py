import copy
import json
import re

from dataclasses import dataclass, field

from .utils.version import Version


LABEL_BIND_REQUEST = "BindLabelForResourceRequest"
V4_DOMAIN_PREFIX = "api/v1/assets/domains/"
V4_ZONE_PREFIX = "api/v1/assets/zones/"
V4_LABEL_RESOURCE_URL = "api/v1/labels/labeled-resources/"
V4_HIDDEN_SUPPORTED_URLS = {
    "api/v1/accounts/accounts/bulk/",
    "api/v1/common/resources/cache/",
}


@dataclass
class RequestOperation(object):
    url: str
    method: str
    headers: dict = field(default_factory=dict)
    data: object = field(default_factory=dict)
    params: dict = field(default_factory=dict)


@dataclass
class RequestExecutionPlan(object):
    operations: list


class MemoryResponse(object):
    def __init__(self, status_code=200, payload=None, reason=""):
        self.status_code = status_code
        self.reason = reason
        self._payload = payload
        self.text = "" if payload is None else json.dumps(payload, ensure_ascii=False)

    def json(self):
        return self._payload


def is_v4(api_version):
    if not api_version:
        return False
    try:
        return Version(api_version) >= Version("4.0")
    except Exception:
        return str(api_version).startswith("4.")


def prepare_request_plan(api_version, request_instance):
    operation = RequestOperation(
        url=request_instance.get_url(),
        method=request_instance.get_method(),
        headers=copy.deepcopy(request_instance.get_headers()),
        data=copy.deepcopy(request_instance.get_data()),
        params=copy.deepcopy(request_instance.get_params()),
    )
    if not is_v4(api_version):
        return RequestExecutionPlan(operations=[operation])

    if operation.url.startswith(V4_DOMAIN_PREFIX):
        operation.url = operation.url.replace(V4_DOMAIN_PREFIX, V4_ZONE_PREFIX, 1)

    if request_instance.__class__.__name__ == LABEL_BIND_REQUEST:
        return _prepare_v4_bind_label_plan(request_instance, operation)

    return RequestExecutionPlan(operations=[operation])


def execute_request(http_client, request_instance):
    api_version = http_client.resolve_api_version()
    plan = prepare_request_plan(api_version, request_instance)
    responses = [
        http_client.request(
            url=operation.url,
            method=operation.method,
            headers=operation.headers,
            data=operation.data,
            params=operation.params,
        )
        for operation in plan.operations
    ]
    if len(responses) == 1:
        return responses[0]
    return _aggregate_responses(responses)


def _prepare_v4_bind_label_plan(request_instance, operation):
    label_id = getattr(request_instance, "id", "")
    resource_ids = list((operation.data or {}).get("res_ids") or [])
    resource_type_id = _extract_resource_type_id(operation.url)
    if not label_id or not resource_type_id:
        return RequestExecutionPlan(operations=[operation])

    operations = [
        RequestOperation(
            url=V4_LABEL_RESOURCE_URL,
            method="post",
            headers=copy.deepcopy(operation.headers),
            data={
                "label": label_id,
                "res_type": resource_type_id,
                "res_id": resource_id,
            },
            params={},
        )
        for resource_id in resource_ids
    ]
    return RequestExecutionPlan(operations=operations)


def _extract_resource_type_id(url):
    matched = re.search(r"/resource-types/([^/]+)/resources/?$", url)
    if not matched:
        return ""
    return matched.group(1)


def _aggregate_responses(responses):
    if not responses:
        return MemoryResponse(status_code=200, payload=[])

    errors = []
    payload = []
    status_code = 200
    for index, response in enumerate(responses):
        status_code = max(status_code, response.status_code)
        if response.status_code >= 400:
            errors.append(
                {
                    "index": index,
                    "status_code": response.status_code,
                    "detail": _safe_json(response),
                }
            )
            continue
        payload.extend(_normalize_payload(response))

    if errors:
        first_error = errors[0]
        return MemoryResponse(
            status_code=first_error["status_code"],
            payload={"detail": "One or more requests failed", "errors": errors},
            reason=str(first_error["detail"]),
        )
    return MemoryResponse(status_code=status_code, payload=payload)


def _normalize_payload(response):
    if not getattr(response, "text", ""):
        return []
    try:
        data = response.json()
    except Exception:
        return []

    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        results = data.get("results")
        if results is None:
            return [data]
        if isinstance(results, list):
            return results
        return [results]
    return [data]


def _safe_json(response):
    try:
        return response.json()
    except Exception:
        return getattr(response, "reason", "")
