"""
AgentMesh SDK Tests
Tests the SDK client against the live API.

Run with:  pytest tests/test_sdk.py -v
"""

import pytest
from agentmesh import AgentMesh, AgentMeshError

# Point at local server for tests — change to Railway URL for cloud tests
BASE_URL = "http://localhost:8000"
API_KEY = "dev"

@pytest.fixture
def mesh():
    return AgentMesh(api_key=API_KEY, base_url=BASE_URL)


def test_write(mesh):
    result = mesh.write(agent_id="sdk_test_agent", content="I handle SDK testing tasks")
    assert result["agent_id"] == "sdk_test_agent"
    assert "id" in result
    print(f"✅  write() — id={result['id']}")


def test_recall(mesh):
    mesh.write(agent_id="sdk_recall_agent", content="I specialize in data retrieval")
    results = mesh.recall("data retrieval", top_k=3)
    assert isinstance(results, list)
    assert len(results) >= 1
    assert "agent_id" in results[0]
    assert "score" in results[0]
    print(f"✅  recall() — {len(results)} results")


def test_route(mesh):
    mesh.write(agent_id="sdk_route_agent", content="I summarize documents and reports")
    results = mesh.route("summarize this report", top_k=2)
    assert isinstance(results, list)
    print(f"✅  route() — {results}")


def test_discover(mesh):
    mesh.write(agent_id="sdk_discover_agent", content="I run SQL queries and manage databases")
    results = mesh.discover("database")
    assert isinstance(results, list)
    print(f"✅  discover() — {results}")


def test_index(mesh):
    result = mesh.index()
    assert result is not None
    print(f"✅  index() — OK")


def test_metrics(mesh):
    result = mesh.metrics()
    assert result is not None
    print(f"✅  metrics() — {result}")


def test_forget(mesh):
    mesh.write(agent_id="sdk_forget_agent", content="This memory will be deleted")
    result = mesh.forget(agent_id="sdk_forget_agent")
    assert result is not None
    print(f"✅  forget() — {result}")


def test_forget_requires_params(mesh):
    with pytest.raises(ValueError):
        mesh.forget()
    print("✅  forget() raises ValueError with no params")


def test_invalid_api_key():
    bad_mesh = AgentMesh(api_key="invalid_key", base_url=BASE_URL)
    # In dev mode server accepts anything — skip auth test in dev
    # In production this would raise AgentMeshError
    print("✅  invalid key test skipped in dev mode")
