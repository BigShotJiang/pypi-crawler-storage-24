"""
AgentMesh Python SDK
Shared memory + coordination layer for multi-agent AI systems.

Usage:
    from agentmesh import AgentMesh
    mesh = AgentMesh(api_key="your_key")
    mesh.write(agent_id="agent1", content="I specialize in NLP")
    results = mesh.recall("text processing")
"""

import requests
from typing import Optional


class AgentMeshError(Exception):
    """Raised when the AgentMesh API returns an error."""
    pass


class AgentMesh:
    """
    AgentMesh client — shared memory + coordination for multi-agent AI systems.

    Args:
        api_key:  Your AgentMesh API key.
        base_url: API base URL. Defaults to the hosted cloud API.
                  Set to http://localhost:8000 for local development.
        timeout:  Request timeout in seconds. Default 60.

    Example:
        mesh = AgentMesh(api_key="am_sk_...")
        mesh.write(agent_id="agent1", content="I handle NLP tasks")
        results = mesh.recall("text processing")
    """

    DEFAULT_URL = "https://agentmesh-production.up.railway.app"

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_URL,
        timeout: int = 60,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            "x-api-key": self.api_key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        })

    # ── internal ───────────────────────────────────────────────────────────────

    def _post(self, endpoint: str, payload: dict) -> dict:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            resp = self._session.post(url, json=payload, timeout=self.timeout)
            data = resp.json()
        except requests.exceptions.ConnectionError:
            raise AgentMeshError(
                f"Could not connect to AgentMesh at {self.base_url}. "
                "Check your base_url or network connection."
            )
        except requests.exceptions.Timeout:
            raise AgentMeshError(
                f"Request to {endpoint} timed out after {self.timeout}s."
            )

        if data.get("status") == "error":
            raise AgentMeshError(data.get("detail", "Unknown error"))

        return data.get("data", data)

    def _get(self, endpoint: str) -> dict:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            resp = self._session.get(url, timeout=self.timeout)
            data = resp.json()
        except requests.exceptions.ConnectionError:
            raise AgentMeshError(
                f"Could not connect to AgentMesh at {self.base_url}."
            )
        except requests.exceptions.Timeout:
            raise AgentMeshError(
                f"Request to {endpoint} timed out after {self.timeout}s."
            )

        if data.get("status") == "error":
            raise AgentMeshError(data.get("detail", "Unknown error"))

        return data.get("data", data)

    # ── public API ─────────────────────────────────────────────────────────────

    def write(
        self,
        content: str,
        agent_id: Optional[str] = None,
        memory_type: str = "general",
    ) -> dict:
        """
        Store a memory.

        Args:
            content:     What to remember.
            agent_id:    Which agent is writing this memory.
            memory_type: Category label (default: "general").

        Returns:
            dict with status, id, content, agent_id, namespace.

        Example:
            mesh.write(agent_id="agent1", content="I handle NLP tasks")
        """
        return self._post("/write", {
            "agent_id": agent_id,
            "content": content,
            "memory_type": memory_type,
        })

    def recall(
        self,
        query: str,
        top_k: int = 5,
    ) -> list:
        """
        Semantic search across all agent memories.

        Args:
            query: What to search for.
            top_k: Max number of results to return (default: 5).

        Returns:
            List of matching memories with agent_id, content, score.

        Example:
            results = mesh.recall("text processing", top_k=3)
            for r in results:
                print(r["agent_id"], r["score"], r["content"])
        """
        return self._post("/recall", {
            "query": query,
            "top_k": top_k,
        })

    def index(self) -> dict:
        """
        Show which agents know what.

        Returns:
            Dict mapping agent_id → list of memory summaries.

        Example:
            knowledge_map = mesh.index()
        """
        return self._post("/index", {})

    def route(
        self,
        task: str,
        top_k: int = 3,
    ) -> list:
        """
        Find the best agent(s) to handle a task.

        Args:
            task:  Description of the task.
            top_k: Number of agent suggestions to return (default: 3).

        Returns:
            Ranked list of agents best suited for the task.

        Example:
            agents = mesh.route("summarize this document")
            best_agent = agents[0]["agent_id"]
        """
        return self._post("/route", {
            "task": task,
            "top_k": top_k,
        })

    def discover(
        self,
        topic: str,
    ) -> list:
        """
        Discover agents that specialize in a topic.

        Args:
            topic: Topic to search for specialists.

        Returns:
            List of agents with expertise in that topic.

        Example:
            experts = mesh.discover("database queries")
        """
        return self._post("/discover", {
            "topic": topic,
        })

    def metrics(self) -> dict:
        """
        Get collaboration stats and insights.

        Returns:
            Dict with total memories, agent counts, top agents, etc.

        Example:
            stats = mesh.metrics()
            print(stats["total_memories"])
        """
        return self._get("/metrics")

    def forget(
        self,
        agent_id: Optional[str] = None,
        content_filter: Optional[str] = None,
    ) -> dict:
        """
        GDPR-compliant delete — remove memories by agent or content.

        Args:
            agent_id:       Delete all memories for this agent.
            content_filter: Delete memories containing this string.

        Returns:
            Dict with count of deleted memories.

        Example:
            mesh.forget(agent_id="agent1")
            mesh.forget(content_filter="sensitive data")
        """
        if not agent_id and not content_filter:
            raise ValueError("Provide agent_id or content_filter (or both).")
        return self._post("/forget", {
            "agent_id": agent_id,
            "content_filter": content_filter,
        })
