"""
AgentMesh — Shared memory + coordination layer for multi-agent AI systems.

Quick start:
    pip install agentmesh

    from agentmesh import AgentMesh

    mesh = AgentMesh(api_key="your_key")
    mesh.write(agent_id="agent1", content="I specialize in NLP tasks")
    results = mesh.recall("text processing")

Docs: https://agentmesh-production.up.railway.app/docs
GitHub: https://github.com/onassis-ctrl/agentmesh
"""

from .client import AgentMesh, AgentMeshError

__all__ = ["AgentMesh", "AgentMeshError"]
__version__ = "0.1.0"
