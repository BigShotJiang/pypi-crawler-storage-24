"""Shared fixtures and mock helpers."""

from noisegate.checks import ASSET_IN_SCOPE, REPRODUCTION_QUALITY, _BUILTIN_CHECK_IDS
from noisegate.models import CheckResult, ChecksResult, Verdict


def make_checks_result(verdict: Verdict = Verdict.PASS) -> ChecksResult:
    """Build a ChecksResult fixture for a given verdict."""
    checks = []
    for cid in sorted(_BUILTIN_CHECK_IDS):
        if verdict == Verdict.FAIL and cid == ASSET_IN_SCOPE:
            checks.append(CheckResult(check_id=cid, passed=False, reason="Out of scope."))
        elif verdict == Verdict.WARN and cid == REPRODUCTION_QUALITY:
            checks.append(CheckResult(check_id=cid, passed=False, reason="No steps provided."))
        else:
            checks.append(CheckResult(check_id=cid, passed=True, reason="Passed."))
    summary = "All checks passed." if verdict == Verdict.PASS else "Some checks failed."
    return ChecksResult(
        checks=checks,
        summary=summary,
        verdict=verdict,
        model_used="anthropic:claude-sonnet-4-6",
        prompt_tokens=500,
        completion_tokens=200,
    )
