"""Custom exceptions for NoiseGate."""

from __future__ import annotations

from pathlib import Path


class NoiseGateError(Exception):
    """Base exception for all NoiseGate errors."""


class NoDefaultProgramError(NoiseGateError):
    """Raised when no default program is configured."""

    def __init__(self) -> None:
        super().__init__(
            "No default program set. Run: noisegate program use <name>"
        )



class PolicyFetchError(NoiseGateError):
    """Raised when fetching a policy URL fails."""

    def __init__(self, url: str, reason: str) -> None:
        self.url = url
        super().__init__(f"Failed to fetch policy from {url}: {reason}")


class PolicyTooLargeError(NoiseGateError):
    """Raised when fetched content exceeds the size limit."""

    def __init__(self, url: str, size: int, limit: int) -> None:
        super().__init__(
            f"Content from {url} is too large ({size:,} chars > {limit:,} limit). "
            "Try a more specific policy URL."
        )


class LLMError(NoiseGateError):
    """Raised when the LLM call fails."""


class ProgramNotFoundError(NoiseGateError):
    def __init__(self, name: str) -> None:
        super().__init__(f"Program '{name}' not found at ~/.config/noisegate/programs/{name}.yaml")


class ProgramParseError(NoiseGateError):
    def __init__(self, path: Path, reason: str) -> None:
        super().__init__(f"Failed to parse program file {path}: {reason}")


class ProgramImportError(NoiseGateError):
    def __init__(self, reason: str) -> None:
        super().__init__(f"Program import failed: {reason}")


class PolicyParseError(NoiseGateError):
    def __init__(self, path: Path, reason: str) -> None:
        super().__init__(f"Failed to parse policy file {path}: {reason}")
