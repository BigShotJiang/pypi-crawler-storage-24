"""NoiseGate — LLM-powered bug bounty report triage tool."""

__version__ = "0.1.0"
