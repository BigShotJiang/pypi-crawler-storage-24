"""
:mod:`tests.unit.file.test_u_file_ods` module.

Unit tests for :mod:`etlplus.file.ods`.
"""

from __future__ import annotations

from etlplus.file import ods as mod

from .pytest_file_contracts import WritableSpreadsheetModuleContract

# SECTION: PRAGMAS ========================================================== #

# pylint: disable=import-outside-toplevel,protected-access,unused-argument

# SECTION: TESTS ============================================================ #


class TestOds(WritableSpreadsheetModuleContract):
    """Unit tests for :mod:`etlplus.file.ods`."""

    module = mod
    format_name = 'ods'
    read_engine = 'odf'
    write_engine = 'odf'
