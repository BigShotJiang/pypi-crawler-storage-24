# Getting Started

```{toctree}
:maxdepth: 1

installation
quickstart
compatibility
```
