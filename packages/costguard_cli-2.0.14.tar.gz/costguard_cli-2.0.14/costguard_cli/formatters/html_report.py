"""HTML formatter — executive/CFO-ready report for CostGuard results."""

import re

from jinja2 import Template


# ---------------------------------------------------------------------------
# Embedded Jinja2 template — self-contained HTML with inline CSS
# ---------------------------------------------------------------------------
HTML_TEMPLATE = Template("""\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CostGuard — Infrastructure Cost Analysis</title>
<style>
  /* ── CSS Custom Properties ─────────────────────────────────────── */
  :root {
    --navy:       #0f172a;
    --slate-800:  #1e293b;
    --slate-700:  #334155;
    --slate-600:  #475569;
    --slate-500:  #64748b;
    --slate-400:  #94a3b8;
    --slate-300:  #cbd5e1;
    --slate-200:  #e2e8f0;
    --slate-100:  #f1f5f9;
    --slate-50:   #f8fafc;
    --white:      #ffffff;

    --accent:     #3b82f6;
    --accent-light: #dbeafe;
    --accent-dark: #1d4ed8;

    --green:      #10b981;
    --green-light: #d1fae5;
    --green-dark: #059669;

    --amber:      #f59e0b;
    --amber-light: #fef3c7;
    --amber-dark: #d97706;

    --red:        #ef4444;
    --red-light:  #fee2e2;
    --red-dark:   #dc2626;

    --gray:       #6b7280;
    --gray-light: #f3f4f6;

    --radius-sm:  6px;
    --radius-md:  10px;
    --radius-lg:  14px;

    --shadow-sm:  0 1px 2px rgba(0,0,0,0.05);
    --shadow-md:  0 4px 6px -1px rgba(0,0,0,0.07), 0 2px 4px -2px rgba(0,0,0,0.05);
    --shadow-lg:  0 10px 15px -3px rgba(0,0,0,0.08), 0 4px 6px -4px rgba(0,0,0,0.04);

    --font-sans:  'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
                  'Helvetica Neue', Arial, sans-serif;
    --font-mono:  'JetBrains Mono', 'SF Mono', 'Fira Code', 'Cascadia Code',
                  Consolas, 'Liberation Mono', Menlo, monospace;
  }

  /* ── Reset & Base ──────────────────────────────────────────────── */
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html { -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
  body {
    font-family: var(--font-sans);
    color: var(--slate-700);
    background: var(--slate-100);
    line-height: 1.6;
    font-size: 14px;
  }

  /* ── Page Header ───────────────────────────────────────────────── */
  .page-header {
    background: linear-gradient(135deg, var(--navy) 0%, var(--slate-800) 50%, var(--slate-700) 100%);
    color: var(--white);
    padding: 40px 0 48px;
    position: relative;
    overflow: hidden;
  }
  .page-header::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -20%;
    width: 600px;
    height: 600px;
    background: radial-gradient(circle, rgba(59,130,246,0.12) 0%, transparent 70%);
    pointer-events: none;
  }
  .page-header::after {
    content: '';
    position: absolute;
    bottom: -60%;
    left: -10%;
    width: 400px;
    height: 400px;
    background: radial-gradient(circle, rgba(16,185,129,0.08) 0%, transparent 70%);
    pointer-events: none;
  }
  .header-inner {
    max-width: 1080px;
    margin: 0 auto;
    padding: 0 32px;
    position: relative;
    z-index: 1;
  }
  .brand {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 24px;
  }
  .brand-icon {
    width: 40px;
    height: 40px;
    background: rgba(59,130,246,0.2);
    border: 1px solid rgba(59,130,246,0.3);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .brand-icon svg {
    width: 22px;
    height: 22px;
    fill: var(--accent);
  }
  .brand-text {
    font-size: 13px;
    font-weight: 600;
    letter-spacing: 2.5px;
    text-transform: uppercase;
    color: var(--slate-300);
  }
  .brand-text span {
    color: var(--accent);
  }
  .header-title {
    font-size: 26px;
    font-weight: 700;
    letter-spacing: -0.3px;
    margin-bottom: 6px;
  }
  .header-subtitle {
    font-size: 14px;
    color: var(--slate-400);
    margin-bottom: 20px;
  }
  .header-meta {
    display: flex;
    gap: 24px;
    font-size: 12px;
    color: var(--slate-400);
  }
  .header-meta span {
    display: flex;
    align-items: center;
    gap: 5px;
  }
  .header-meta svg {
    width: 13px;
    height: 13px;
    fill: var(--slate-500);
  }

  /* ── Decision Banner ───────────────────────────────────────────── */
  .decision-strip {
    max-width: 1080px;
    margin: -28px auto 0;
    padding: 0 32px;
    position: relative;
    z-index: 2;
  }
  .decision-card {
    background: var(--white);
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-lg);
    padding: 20px 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 16px;
  }
  .decision-left {
    display: flex;
    align-items: center;
    gap: 16px;
  }
  .decision-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 20px;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 700;
    letter-spacing: 1.5px;
    color: var(--white);
  }
  .decision-badge svg {
    width: 18px;
    height: 18px;
    fill: currentColor;
  }
  .decision-ALLOW  { background: linear-gradient(135deg, var(--green) 0%, var(--green-dark) 100%); }
  .decision-WARN   { background: linear-gradient(135deg, var(--amber) 0%, var(--amber-dark) 100%); }
  .decision-BLOCK  { background: linear-gradient(135deg, var(--red) 0%, var(--red-dark) 100%); }
  .decision-ERROR  { background: linear-gradient(135deg, var(--gray) 0%, var(--slate-600) 100%); }
  .decision-label {
    font-size: 14px;
    color: var(--slate-600);
    font-weight: 500;
  }
  .decision-cost {
    text-align: right;
  }
  .decision-cost .cost-value {
    font-size: 28px;
    font-weight: 800;
    color: var(--navy);
    letter-spacing: -0.5px;
    font-family: var(--font-mono);
  }
  .decision-cost .cost-label {
    font-size: 12px;
    color: var(--slate-500);
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  /* ── Content Container ─────────────────────────────────────────── */
  .content {
    max-width: 1080px;
    margin: 0 auto;
    padding: 28px 32px 48px;
  }

  /* ── Stat Cards Grid ───────────────────────────────────────────── */
  .stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 28px;
  }
  .stat-card {
    background: var(--white);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    padding: 20px;
    border: 1px solid var(--slate-200);
    transition: box-shadow 0.2s, transform 0.2s;
  }
  .stat-card:hover {
    box-shadow: var(--shadow-md);
    transform: translateY(-1px);
  }
  .stat-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 10px;
  }
  .stat-icon {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .stat-icon svg {
    width: 18px;
    height: 18px;
  }
  .stat-icon.blue   { background: var(--accent-light); }
  .stat-icon.blue svg { fill: var(--accent); }
  .stat-icon.green  { background: var(--green-light); }
  .stat-icon.green svg { fill: var(--green); }
  .stat-icon.amber  { background: var(--amber-light); }
  .stat-icon.amber svg { fill: var(--amber); }
  .stat-icon.red    { background: var(--red-light); }
  .stat-icon.red svg { fill: var(--red); }
  .stat-value {
    font-size: 24px;
    font-weight: 700;
    color: var(--navy);
    font-family: var(--font-mono);
    line-height: 1.2;
  }
  .stat-label {
    font-size: 12px;
    color: var(--slate-500);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-top: 2px;
  }

  /* ── Section Card ──────────────────────────────────────────────── */
  .section {
    background: var(--white);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    border: 1px solid var(--slate-200);
    margin-bottom: 24px;
    overflow: hidden;
  }
  .section-header {
    padding: 18px 24px;
    border-bottom: 1px solid var(--slate-200);
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .section-title {
    font-size: 16px;
    font-weight: 600;
    color: var(--navy);
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .section-title svg {
    width: 18px;
    height: 18px;
    fill: var(--slate-400);
  }
  .section-badge {
    font-size: 12px;
    padding: 3px 10px;
    border-radius: 20px;
    font-weight: 500;
  }
  .badge-neutral {
    background: var(--slate-100);
    color: var(--slate-600);
  }
  .badge-success {
    background: var(--green-light);
    color: var(--green-dark);
  }
  .badge-warning {
    background: var(--amber-light);
    color: var(--amber-dark);
  }
  .badge-danger {
    background: var(--red-light);
    color: var(--red-dark);
  }
  .section-body {
    padding: 20px 24px;
  }

  /* ── Resource Table ────────────────────────────────────────────── */
  .resource-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
  }
  .resource-table thead th {
    background: var(--slate-50);
    font-weight: 600;
    text-align: left;
    padding: 10px 14px;
    color: var(--slate-500);
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid var(--slate-200);
    white-space: nowrap;
  }
  .resource-table tbody td {
    padding: 11px 14px;
    border-bottom: 1px solid var(--slate-100);
    color: var(--slate-700);
    vertical-align: middle;
  }
  .resource-table tbody tr:last-child td {
    border-bottom: none;
  }
  .resource-table tbody tr:hover td {
    background: var(--slate-50);
  }
  .resource-table .resource-name {
    font-family: var(--font-mono);
    font-size: 12px;
    font-weight: 500;
    color: var(--navy);
  }
  .resource-table .resource-type {
    font-size: 12px;
    color: var(--slate-500);
  }
  .resource-table .cost-cell {
    text-align: right;
    font-family: var(--font-mono);
    font-weight: 600;
    white-space: nowrap;
  }
  .resource-table .cost-cell.monthly {
    color: var(--navy);
    font-size: 14px;
  }
  .resource-table .cost-cell.hourly {
    color: var(--slate-400);
    font-size: 12px;
    font-weight: 400;
  }
  .resource-table tfoot td {
    padding: 12px 14px;
    font-weight: 700;
    border-top: 2px solid var(--slate-200);
    background: var(--slate-50);
    color: var(--navy);
  }
  .resource-table tfoot .cost-cell {
    font-size: 15px;
  }
  .region-tag {
    display: inline-block;
    background: var(--slate-100);
    color: var(--slate-600);
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-family: var(--font-mono);
  }
  .provider-tag {
    display: inline-block;
    background: var(--accent-light);
    color: var(--accent-dark);
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 0.3px;
  }

  /* ── Budget Section ────────────────────────────────────────────── */
  .budget-overview {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
  }
  .budget-visual {
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  .progress-track {
    background: var(--slate-100);
    border-radius: 12px;
    height: 20px;
    overflow: hidden;
    position: relative;
    margin-bottom: 10px;
  }
  .progress-fill {
    height: 100%;
    border-radius: 12px;
    transition: width 0.6s ease;
    position: relative;
  }
  .progress-fill.green  { background: linear-gradient(90deg, #34d399, var(--green)); }
  .progress-fill.amber  { background: linear-gradient(90deg, #fbbf24, var(--amber-dark)); }
  .progress-fill.red    { background: linear-gradient(90deg, #f87171, var(--red-dark)); }
  .progress-label {
    position: absolute;
    right: 8px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 10px;
    font-weight: 700;
    color: var(--white);
    text-shadow: 0 1px 2px rgba(0,0,0,0.2);
  }
  .progress-markers {
    display: flex;
    justify-content: space-between;
    font-size: 11px;
    color: var(--slate-400);
  }
  .budget-metrics {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
  }
  .budget-metric {
    padding: 12px 14px;
    border-radius: var(--radius-sm);
    background: var(--slate-50);
    border: 1px solid var(--slate-200);
  }
  .budget-metric .metric-label {
    font-size: 11px;
    color: var(--slate-500);
    text-transform: uppercase;
    letter-spacing: 0.4px;
    margin-bottom: 4px;
  }
  .budget-metric .metric-value {
    font-size: 18px;
    font-weight: 700;
    font-family: var(--font-mono);
    color: var(--navy);
  }
  .budget-metric .metric-value.positive { color: var(--green); }
  .budget-metric .metric-value.negative { color: var(--red); }
  .budget-metric .metric-value.warning  { color: var(--amber-dark); }

  /* ── Violations ────────────────────────────────────────────────── */
  .guardrail-summary {
    display: flex;
    gap: 16px;
    margin-bottom: 20px;
    padding: 14px 16px;
    background: var(--slate-50);
    border-radius: var(--radius-sm);
    border: 1px solid var(--slate-200);
  }
  .guardrail-stat {
    text-align: center;
    flex: 1;
  }
  .guardrail-stat .gs-value {
    font-size: 22px;
    font-weight: 700;
    font-family: var(--font-mono);
  }
  .guardrail-stat .gs-label {
    font-size: 11px;
    color: var(--slate-500);
    text-transform: uppercase;
    letter-spacing: 0.4px;
  }
  .gs-value.text-green  { color: var(--green); }
  .gs-value.text-red    { color: var(--red); }
  .gs-value.text-navy   { color: var(--navy); }

  .violation-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  .violation-card {
    padding: 14px 18px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--slate-200);
    border-left: 4px solid;
    background: var(--white);
    transition: box-shadow 0.2s;
  }
  .violation-card:hover {
    box-shadow: var(--shadow-sm);
  }
  .violation-card.sev-high   { border-left-color: var(--red); background: #fef8f8; }
  .violation-card.sev-medium { border-left-color: var(--amber); background: #fffdf7; }
  .violation-card.sev-low    { border-left-color: var(--accent); background: #f8faff; }
  .violation-top {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 6px;
  }
  .sev-tag {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 10px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.5px;
  }
  .sev-tag.high   { background: var(--red-light); color: var(--red-dark); }
  .sev-tag.medium { background: var(--amber-light); color: var(--amber-dark); }
  .sev-tag.low    { background: var(--accent-light); color: var(--accent-dark); }
  .violation-rule {
    font-weight: 600;
    font-size: 14px;
    color: var(--navy);
    font-family: var(--font-mono);
  }
  .violation-msg {
    font-size: 13px;
    color: var(--slate-600);
    margin-bottom: 6px;
    line-height: 1.5;
  }
  .violation-resource {
    font-size: 12px;
    color: var(--slate-500);
  }
  .violation-resource code {
    background: var(--slate-100);
    padding: 1px 6px;
    border-radius: 3px;
    font-family: var(--font-mono);
    font-size: 11px;
    color: var(--slate-700);
  }
  .violation-rec {
    margin-top: 8px;
    padding: 8px 12px;
    background: var(--green-light);
    border-radius: var(--radius-sm);
    font-size: 12px;
    color: var(--green-dark);
    display: flex;
    align-items: flex-start;
    gap: 6px;
  }
  .violation-rec svg {
    width: 14px;
    height: 14px;
    fill: var(--green);
    flex-shrink: 0;
    margin-top: 1px;
  }

  /* ── AI Analysis ───────────────────────────────────────────────── */
  .ai-block {
    background: linear-gradient(135deg, #f0f4ff 0%, #f5f3ff 100%);
    border: 1px solid #e0e7ff;
    border-left: 4px solid var(--accent);
    border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
    padding: 20px 24px;
    font-size: 14px;
    line-height: 1.8;
    color: var(--slate-700);
    white-space: pre-wrap;
    position: relative;
  }
  .ai-block::before {
    content: '';
    position: absolute;
    top: 16px;
    left: -4px;
    width: 4px;
    height: 24px;
    background: var(--accent-dark);
    border-radius: 0 2px 2px 0;
  }
  .ai-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background: var(--accent-light);
    color: var(--accent-dark);
    padding: 3px 10px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 0.5px;
    text-transform: uppercase;
    margin-bottom: 12px;
  }
  .ai-badge svg {
    width: 12px;
    height: 12px;
    fill: var(--accent);
  }

  /* ── Remediation Table ─────────────────────────────────────────── */
  .remediation-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
  }
  .remediation-table thead th {
    background: var(--slate-50);
    font-weight: 600;
    text-align: left;
    padding: 10px 14px;
    color: var(--slate-500);
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid var(--slate-200);
  }
  .remediation-table tbody td {
    padding: 11px 14px;
    border-bottom: 1px solid var(--slate-100);
    vertical-align: middle;
  }
  .remediation-table tbody tr:last-child td {
    border-bottom: none;
  }
  .priority-num {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 24px;
    height: 24px;
    border-radius: 50%;
    font-size: 12px;
    font-weight: 700;
    color: var(--white);
  }
  .priority-num.p-high   { background: var(--red); }
  .priority-num.p-medium { background: var(--amber); }
  .priority-num.p-low    { background: var(--accent); }

  /* ── Savings Projection ────────────────────────────────────────── */
  .savings-comparison {
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    gap: 20px;
    align-items: center;
  }
  .savings-box {
    padding: 24px;
    border-radius: var(--radius-md);
    text-align: center;
  }
  .savings-current {
    background: var(--red-light);
    border: 1px solid #fecaca;
  }
  .savings-optimized {
    background: var(--green-light);
    border: 1px solid #a7f3d0;
  }
  .savings-amount {
    font-size: 28px;
    font-weight: 800;
    font-family: var(--font-mono);
    letter-spacing: -0.5px;
  }
  .savings-current .savings-amount { color: var(--red-dark); }
  .savings-optimized .savings-amount { color: var(--green-dark); }
  .savings-desc {
    font-size: 12px;
    color: var(--slate-500);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-top: 4px;
  }
  .savings-arrow {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
  }
  .savings-arrow svg {
    width: 28px;
    height: 28px;
    fill: var(--green);
  }
  .savings-pct {
    font-size: 14px;
    font-weight: 700;
    color: var(--green-dark);
    font-family: var(--font-mono);
  }

  /* ── Errors ────────────────────────────────────────────────────── */
  .error-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .error-item {
    padding: 10px 14px;
    background: var(--red-light);
    border: 1px solid #fecaca;
    border-radius: var(--radius-sm);
    font-size: 13px;
    color: var(--red-dark);
    display: flex;
    align-items: flex-start;
    gap: 8px;
  }
  .error-item svg {
    width: 16px;
    height: 16px;
    fill: var(--red);
    flex-shrink: 0;
    margin-top: 1px;
  }

  /* ── Footer ────────────────────────────────────────────────────── */
  .page-footer {
    max-width: 1080px;
    margin: 0 auto;
    padding: 24px 32px 40px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-top: 1px solid var(--slate-200);
    font-size: 12px;
    color: var(--slate-400);
  }
  .footer-brand {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .footer-brand svg {
    width: 16px;
    height: 16px;
    fill: var(--slate-400);
  }
  .footer-brand strong {
    color: var(--slate-600);
  }
  .footer-meta {
    display: flex;
    gap: 20px;
    font-family: var(--font-mono);
    font-size: 11px;
  }

  /* ── Responsive ────────────────────────────────────────────────── */
  @media (max-width: 768px) {
    .stats-grid { grid-template-columns: repeat(2, 1fr); }
    .budget-overview { grid-template-columns: 1fr; }
    .savings-comparison { grid-template-columns: 1fr; }
    .savings-arrow { transform: rotate(90deg); }
    .decision-card { flex-direction: column; text-align: center; }
    .decision-cost { text-align: center; }
    .page-footer { flex-direction: column; gap: 12px; text-align: center; }
  }

  /* ── Print ─────────────────────────────────────────────────────── */
  @media print {
    body { background: var(--white); font-size: 12px; }
    .page-header { background: var(--navy) !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .section, .stat-card { box-shadow: none; border: 1px solid var(--slate-300); }
    .decision-card { box-shadow: none; border: 1px solid var(--slate-300); }
    .stat-card:hover, .violation-card:hover { transform: none; box-shadow: none; }
    .decision-badge, .sev-tag, .priority-num, .progress-fill, .provider-tag {
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    .page-footer { border-top: 1px solid var(--slate-300); }
  }
</style>
</head>
<body>

  <!-- ══════ Page Header ══════ -->
  <div class="page-header">
    <div class="header-inner">
      <div class="brand">
        <div class="brand-icon">
          <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>
        </div>
        <div class="brand-text"><span>COST</span>GUARD by SKYXOPS</div>
      </div>
      <div class="header-title">Infrastructure Cost Analysis</div>
      <div class="header-subtitle">Shift-left cost governance for cloud infrastructure</div>
      <div class="header-meta">
        {% if timestamp %}
        <span>
          <svg viewBox="0 0 24 24"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
          {{ timestamp }}
        </span>
        {% endif %}
        {% if iac_type %}
        <span>
          <svg viewBox="0 0 24 24"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13z"/></svg>
          {{ iac_type | upper }}
        </span>
        {% endif %}
        {% if request_id %}
        <span>
          <svg viewBox="0 0 24 24"><path d="M17 3H7c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2z"/></svg>
          {{ request_id }}
        </span>
        {% endif %}
      </div>
    </div>
  </div>

  <!-- ══════ Decision Strip ══════ -->
  <div class="decision-strip">
    <div class="decision-card">
      <div class="decision-left">
        <div class="decision-badge decision-{{ decision }}">
          {% if decision == 'ALLOW' %}
          <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
          {% elif decision == 'WARN' %}
          <svg viewBox="0 0 24 24"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>
          {% elif decision == 'BLOCK' %}
          <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8 0-1.85.63-3.55 1.69-4.9L16.9 18.31C15.55 19.37 13.85 20 12 20zm6.31-3.1L7.1 5.69C8.45 4.63 10.15 4 12 4c4.42 0 8 3.58 8 8 0 1.85-.63 3.55-1.69 4.9z"/></svg>
          {% else %}
          <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
          {% endif %}
          {{ decision }}
        </div>
        <div class="decision-label">
          {% if decision == 'ALLOW' %}Deployment permitted
          {% elif decision == 'WARN' %}Deployment allowed with warnings
          {% elif decision == 'BLOCK' %}Deployment blocked by guardrails
          {% else %}Validation could not complete
          {% endif %}
        </div>
      </div>
      <div class="decision-cost">
        <div class="cost-value">{{ total_cost_str }}</div>
        <div class="cost-label">Estimated Monthly Cost ({{ currency }})</div>
      </div>
    </div>
  </div>

  <!-- ══════ Content ══════ -->
  <div class="content">

    <!-- ── Stat Cards ── -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-header">
          <div class="stat-icon blue">
            <svg viewBox="0 0 24 24"><path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/></svg>
          </div>
        </div>
        <div class="stat-value">{{ total_cost_str }}</div>
        <div class="stat-label">Monthly Cost</div>
      </div>
      <div class="stat-card">
        <div class="stat-header">
          <div class="stat-icon green">
            <svg viewBox="0 0 24 24"><path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"/></svg>
          </div>
        </div>
        <div class="stat-value">{{ resource_count }}</div>
        <div class="stat-label">Resources Analyzed</div>
      </div>
      <div class="stat-card">
        <div class="stat-header">
          <div class="stat-icon {% if guardrails_failed > 0 %}amber{% else %}green{% endif %}">
            <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z"/></svg>
          </div>
        </div>
        <div class="stat-value">{{ guardrails_passed }}/{{ guardrails_total }}</div>
        <div class="stat-label">Guardrails Passed</div>
      </div>
      <div class="stat-card">
        <div class="stat-header">
          <div class="stat-icon {% if violation_count > 0 %}red{% else %}green{% endif %}">
            <svg viewBox="0 0 24 24"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>
          </div>
        </div>
        <div class="stat-value">{{ violation_count }}</div>
        <div class="stat-label">Violations</div>
      </div>
    </div>

    <!-- ── Resource Breakdown ── -->
    {% if resources %}
    <div class="section">
      <div class="section-header">
        <div class="section-title">
          <svg viewBox="0 0 24 24"><path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"/></svg>
          Per-Resource Cost Breakdown
        </div>
        <span class="section-badge badge-neutral">{{ resources | length }} resources</span>
      </div>
      <table class="resource-table">
        <thead>
          <tr>
            <th>Resource</th>
            <th>Type</th>
            <th>Provider</th>
            <th>Region</th>
            <th style="text-align:right">Hourly</th>
            <th style="text-align:right">Monthly</th>
          </tr>
        </thead>
        <tbody>
          {% for r in resources %}
          <tr>
            <td class="resource-name">{{ r.resource_name }}</td>
            <td class="resource-type">{{ r.resource_type }}</td>
            <td><span class="provider-tag">{{ r.provider }}</span></td>
            <td><span class="region-tag">{{ r.region }}</span></td>
            <td class="cost-cell hourly">{{ r.hourly_str }}</td>
            <td class="cost-cell monthly">{{ r.monthly_str }}</td>
          </tr>
          {% endfor %}
        </tbody>
        <tfoot>
          <tr>
            <td colspan="5"><strong>Total Estimated Monthly Cost</strong></td>
            <td class="cost-cell monthly">{{ total_cost_str }}</td>
          </tr>
        </tfoot>
      </table>
    </div>
    {% endif %}

    <!-- ── Budget Status ── -->
    {% if budget %}
    <div class="section">
      <div class="section-header">
        <div class="section-title">
          <svg viewBox="0 0 24 24"><path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>
          {% if budget_not_found %}Budget{% else %}Budget: {{ budget_name }}{% endif %}
        </div>
        <span class="section-badge {% if budget_pct < 70 %}badge-success{% elif budget_pct < 100 %}badge-warning{% else %}badge-danger{% endif %}">
          {{ budget_pct_display }}% consumed
        </span>
      </div>
      <div class="section-body">
        {% if budget_not_found %}
        <div style="padding: 16px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 8px;">
          <strong>Budget not found:</strong> {{ budget_decision_reason }}
          <br><span style="color: #666;">Check your <code>--budget-code</code> value or use <code>--auto-approve</code> to allow deployment without a matching budget.</span>
        </div>
        {% else %}
        <div class="budget-overview">
          <div class="budget-visual">
            <div class="progress-track">
              <div class="progress-fill {{ budget_bar_color }}" style="width: {{ budget_pct_capped }}%;">
                {% if budget_pct_capped > 15 %}
                <span class="progress-label">{{ budget_pct_display }}%</span>
                {% endif %}
              </div>
            </div>
            <div class="progress-markers">
              <span>0%</span>
              <span>50%</span>
              <span>100%</span>
            </div>
          </div>
          <div class="budget-metrics">
            {% if monthly_limit is not none %}
            <div class="budget-metric">
              <div class="metric-label">Monthly Limit</div>
              <div class="metric-value">${{ monthly_limit_str }}</div>
            </div>
            <div class="budget-metric">
              <div class="metric-label">Current Usage</div>
              <div class="metric-value">${{ current_usage_str }}</div>
            </div>
            {% if projected_usage is not none %}
            <div class="budget-metric">
              <div class="metric-label">Projected Usage</div>
              <div class="metric-value {% if projected_usage > monthly_limit %}negative{% elif projected_usage > monthly_limit * 0.8 %}warning{% endif %}">${{ projected_usage_str }}</div>
            </div>
            {% endif %}
            {% if remaining is not none %}
            <div class="budget-metric">
              <div class="metric-label">Remaining</div>
              <div class="metric-value {% if remaining > 0 %}positive{% else %}negative{% endif %}">${{ remaining_str }}</div>
            </div>
            {% endif %}
            {% elif consumption_pct is not none or headroom is not none %}
            {% if consumption_pct is not none %}
            <div class="budget-metric">
              <div class="metric-label">Consumption</div>
              <div class="metric-value {% if consumption_pct >= 100 %}negative{% elif consumption_pct >= 80 %}warning{% endif %}">{{ consumption_pct_str }}%</div>
            </div>
            {% endif %}
            {% if headroom is not none %}
            <div class="budget-metric">
              <div class="metric-label">Available Headroom</div>
              <div class="metric-value {% if headroom > 0 %}positive{% else %}negative{% endif %}">${{ headroom_str }}</div>
            </div>
            {% endif %}
            {% endif %}
          </div>
        </div>
        {% endif %}
      </div>
    </div>
    {% endif %}

    <!-- ── Guardrail Violations ── -->
    {% if violations %}
    <div class="section">
      <div class="section-header">
        <div class="section-title">
          <svg viewBox="0 0 24 24"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>
          Guardrail Violations
        </div>
        <span class="section-badge badge-danger">{{ violation_count }} issue{{ 's' if violation_count != 1 }}</span>
      </div>
      <div class="section-body">
        {% if guardrails %}
        <div class="guardrail-summary">
          <div class="guardrail-stat">
            <div class="gs-value text-navy">{{ guardrails_total }}</div>
            <div class="gs-label">Evaluated</div>
          </div>
          <div class="guardrail-stat">
            <div class="gs-value text-green">{{ guardrails_passed }}</div>
            <div class="gs-label">Passed</div>
          </div>
          <div class="guardrail-stat">
            <div class="gs-value text-red">{{ guardrails_failed }}</div>
            <div class="gs-label">Failed</div>
          </div>
        </div>
        {% endif %}

        <div class="violation-list">
          {% for v in violations_sorted %}
          <div class="violation-card sev-{{ v.severity }}">
            <div class="violation-top">
              <span class="sev-tag {{ v.severity }}">{{ v.severity_upper }}</span>
              <span class="violation-rule">{{ v.rule }}</span>
            </div>
            {% if v.message %}
            <div class="violation-msg">{{ v.message }}</div>
            {% endif %}
            {% if v.resource %}
            <div class="violation-resource">Resource: <code>{{ v.resource }}</code></div>
            {% endif %}
            {% if v.recommendation %}
            <div class="violation-rec">
              <svg viewBox="0 0 24 24"><path d="M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7z"/></svg>
              {{ v.recommendation }}
            </div>
            {% endif %}
          </div>
          {% endfor %}
        </div>
      </div>
    </div>
    {% endif %}

    <!-- ── AI Analysis ── -->
    {% if narrative %}
    <div class="section">
      <div class="section-header">
        <div class="section-title">
          <svg viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
          AI Analysis
        </div>
        <span class="ai-badge">
          <svg viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
          Powered by AI
        </span>
      </div>
      <div class="section-body">
        <div class="ai-block">{{ narrative }}</div>
      </div>
    </div>
    {% endif %}

    <!-- ── Remediation Priority ── -->
    {% if violations %}
    <div class="section">
      <div class="section-header">
        <div class="section-title">
          <svg viewBox="0 0 24 24"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13zM8 15.01l1.41 1.41L11 14.84V19h2v-4.16l1.59 1.59L16 15.01 12.01 11z"/></svg>
          Remediation Priority
        </div>
      </div>
      <table class="remediation-table">
        <thead>
          <tr>
            <th style="width:50px; text-align:center">#</th>
            <th style="width:80px; text-align:center">Severity</th>
            <th>Rule</th>
            <th>Recommended Action</th>
          </tr>
        </thead>
        <tbody>
          {% for v in violations_sorted %}
          <tr>
            <td style="text-align:center"><span class="priority-num p-{{ v.severity }}">{{ loop.index }}</span></td>
            <td style="text-align:center"><span class="sev-tag {{ v.severity }}">{{ v.severity_upper }}</span></td>
            <td style="font-family:var(--font-mono); font-size:12px;">{{ v.rule }}</td>
            <td>{{ v.recommendation if v.recommendation else 'Review and remediate' }}</td>
          </tr>
          {% endfor %}
        </tbody>
      </table>
    </div>
    {% endif %}

    <!-- ── Savings Projection ── -->
    {% if savings_pct != '0' %}
    <div class="section">
      <div class="section-header">
        <div class="section-title">
          <svg viewBox="0 0 24 24"><path d="M16 6l2.29 2.29-4.88 4.88-4-4L2 16.59 3.41 18l6-6 4 4 6.3-6.29L22 12V6z"/></svg>
          Savings Projection
        </div>
        <span class="section-badge badge-success">{{ savings_pct }}% potential savings</span>
      </div>
      <div class="section-body">
        <p style="font-size:13px; color:var(--slate-500); margin-bottom:20px;">
          Estimated monthly savings if all recommendations are implemented.
        </p>
        <div class="savings-comparison">
          <div class="savings-box savings-current">
            <div class="savings-amount">{{ total_cost_str }}</div>
            <div class="savings-desc">Current Projected</div>
          </div>
          <div class="savings-arrow">
            <svg viewBox="0 0 24 24"><path d="M16.01 11H4v2h12.01v3L20 12l-3.99-4z"/></svg>
            <div class="savings-pct">-{{ savings_pct }}%</div>
          </div>
          <div class="savings-box savings-optimized">
            <div class="savings-amount">{{ optimized_cost_str }}</div>
            <div class="savings-desc">Optimized Estimate</div>
          </div>
        </div>
        <p style="font-size:14px; color:var(--green-dark); text-align:center; margin-top:16px; font-weight:600;">
          Potential savings: {{ savings_str }}/month
        </p>
      </div>
    </div>
    {% endif %}

    <!-- ── Errors ── -->
    {% if errors %}
    <div class="section">
      <div class="section-header">
        <div class="section-title">
          <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
          Errors
        </div>
      </div>
      <div class="section-body">
        <div class="error-list">
          {% for err in errors %}
          <div class="error-item">
            <svg viewBox="0 0 24 24"><path d="M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"/></svg>
            {{ err }}
          </div>
          {% endfor %}
        </div>
      </div>
    </div>
    {% endif %}

  </div>

  <!-- ══════ Footer ══════ -->
  <div class="page-footer">
    <div class="footer-brand">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>
      Generated by <strong>CostGuard</strong> &mdash; <strong>SKYXOPS</strong> Shift-Left Cost Governance
    </div>
    <div class="footer-meta">
      {% if request_id %}<span>{{ request_id }}</span>{% endif %}
      {% if processing_time is not none %}<span>{{ processing_time }}ms</span>{% endif %}
    </div>
  </div>

</body>
</html>
""")

# Priority order for sorting violations by severity
_SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2}


class HtmlFormatter:
    """Renders CostGuard API responses as self-contained HTML reports."""

    def format(self, response: dict, **kwargs) -> str:
        """Format the full CostGuard API response as a self-contained HTML document."""
        # Support both flat (v1 API) and nested (legacy) response shapes
        if "endpoint_data" in response:
            endpoint_data = response["endpoint_data"]
            results = response.get("results") or {}
        else:
            endpoint_data = response
            results = response

        decision = (endpoint_data.get("decision") or "ERROR").upper()

        # Cost values — support both flat summary and legacy
        summary = results.get("summary") or {}
        total_monthly = summary.get("total_monthly_cost") or results.get("total_monthly_usd")
        currency = summary.get("currency") or results.get("currency", "USD")
        total_cost_str = f"${total_monthly:,.2f}" if total_monthly is not None else "N/A"
        resources_raw = results.get("resources") or []
        resource_count = summary.get("total_resources") or len(resources_raw)

        # Prepare resource rows
        resources = []
        for r in resources_raw:
            mc = r.get("monthly_cost")
            hc = r.get("hourly_cost")
            resources.append({
                "resource_name": r.get("resource_name") or r.get("resource_id", "unknown"),
                "resource_type": r.get("resource_type", "unknown"),
                "provider": (r.get("provider") or "-").upper(),
                "region": r.get("region", "-"),
                "hourly_str": f"${hc:,.4f}" if hc is not None else "-",
                "monthly_str": f"${mc:,.2f}" if mc is not None else "N/A",
            })

        # Violations
        violations_raw = endpoint_data.get("violations") or []
        violation_count = len(violations_raw)

        def _prepare_violation(v: dict) -> dict:
            severity = (v.get("severity") or "low").lower()
            return {
                "severity": severity,
                "severity_upper": severity.upper(),
                "rule": v.get("rule", "unknown"),
                "message": v.get("message", ""),
                "resource": v.get("resource", ""),
                "recommendation": v.get("recommendation", ""),
            }

        violations = [_prepare_violation(v) for v in violations_raw]
        violations_sorted = sorted(violations, key=lambda v: _SEVERITY_ORDER.get(v["severity"], 99))

        # Guardrails — support nested summary, flat CostGuard API, and legacy
        guardrails = endpoint_data.get("guardrails")
        if guardrails:
            gs = guardrails.get("summary") or {}
            guardrails_total = (
                gs.get("rules_evaluated")
                or guardrails.get("evaluated")
                or guardrails.get("total", 0)
            )
            guardrails_passed = gs.get("rules_passed") or guardrails.get("passed", 0)
            guardrails_failed = gs.get("rules_failed") or guardrails.get("failed", 0)
        else:
            guardrails_total = 0
            guardrails_passed = 0
            guardrails_failed = 0

        # Budget — support both full fields and CostGuard UnifiedResponse fields
        budget = endpoint_data.get("budget")
        budget_name = budget.get("budget_name", "Unknown") if budget else ""
        monthly_limit = budget.get("monthly_limit") if budget else None
        current_usage = budget.get("current_usage", 0) if budget else 0
        projected_usage = budget.get("projected_usage") if budget else None
        remaining = budget.get("remaining") if budget else None

        # UnifiedResponse fields
        headroom = budget.get("available_headroom") if budget else None
        consumption_pct = budget.get("projected_consumption_pct") if budget else None

        # Compute budget percentage
        if monthly_limit is None and consumption_pct is not None:
            budget_pct = consumption_pct
        elif monthly_limit and monthly_limit > 0:
            budget_pct = current_usage / monthly_limit * 100
        else:
            budget_pct = 0

        budget_pct_capped = min(budget_pct, 100)
        budget_pct_display = f"{budget_pct:.0f}"

        if budget_pct < 70:
            budget_bar_color = "green"
        elif budget_pct < 90:
            budget_bar_color = "amber"
        else:
            budget_bar_color = "red"

        monthly_limit_str = f"{monthly_limit:,.2f}" if monthly_limit is not None else "0.00"
        current_usage_str = f"{current_usage:,.2f}"
        projected_usage_str = f"{projected_usage:,.2f}" if projected_usage is not None else None
        remaining_str = f"{remaining:,.2f}" if remaining is not None else None
        headroom_str = f"{headroom:,.2f}" if headroom is not None else None
        consumption_pct_str = f"{consumption_pct:.1f}" if consumption_pct is not None else None

        # Savings projection (estimated: assume 10-40% savings based on violations)
        if total_monthly is not None and total_monthly > 0 and violation_count > 0:
            savings_ratio = min(0.10 + violation_count * 0.05, 0.40)
            optimized = total_monthly * (1 - savings_ratio)
            savings = total_monthly - optimized
            optimized_cost_str = f"${optimized:,.2f}"
            savings_str = f"${savings:,.2f}"
            savings_pct = f"{savings_ratio * 100:.0f}"
        else:
            optimized_cost_str = total_cost_str
            savings_str = "$0.00"
            savings_pct = "0"

        # Narrative — API returns dict {"html": "..."} or plain string
        narrative = results.get("narrative") or ""
        if isinstance(narrative, dict):
            narrative = narrative.get("html") or narrative.get("text", "")
        # Strip HTML tags for clean display
        if narrative:
            narrative = re.sub(r'<[^>]+>', '', narrative).strip()

        # Errors
        errors_raw = results.get("errors") or []
        errors = []
        for err in errors_raw:
            if isinstance(err, dict):
                errors.append(err.get("message", str(err)))
            else:
                errors.append(str(err))

        # IaC type
        iac_type = endpoint_data.get("iac_type", "")

        return HTML_TEMPLATE.render(
            decision=decision,
            timestamp=response.get("timestamp", ""),
            total_cost_str=total_cost_str,
            currency=currency,
            resource_count=resource_count,
            violation_count=violation_count,
            resources=resources,
            violations=violations,
            violations_sorted=violations_sorted,
            guardrails=guardrails,
            guardrails_total=guardrails_total,
            guardrails_passed=guardrails_passed,
            guardrails_failed=guardrails_failed,
            budget=budget,
            budget_not_found=budget.get("budget_found") is False if budget else False,
            budget_decision_reason=budget.get("decision_reason", "No applicable budget found") if budget else "",
            budget_name=budget_name,
            budget_pct=budget_pct,
            monthly_limit=monthly_limit,
            current_usage=current_usage,
            projected_usage=projected_usage,
            remaining=remaining,
            headroom=headroom,
            consumption_pct=consumption_pct,
            budget_pct_capped=budget_pct_capped,
            budget_pct_display=budget_pct_display,
            budget_bar_color=budget_bar_color,
            monthly_limit_str=monthly_limit_str,
            current_usage_str=current_usage_str,
            projected_usage_str=projected_usage_str,
            remaining_str=remaining_str,
            headroom_str=headroom_str,
            consumption_pct_str=consumption_pct_str,
            narrative=narrative,
            optimized_cost_str=optimized_cost_str,
            savings_str=savings_str,
            savings_pct=savings_pct,
            errors=errors,
            iac_type=iac_type,
            request_id=response.get("request_id", ""),
            processing_time=response.get("processing_time_ms"),
        )
