"""Terminal formatter — color-coded CLI output for CostGuard results."""

import os
import sys


class TerminalFormatter:
    """Renders CostGuard API responses as color-coded terminal output."""

    # ANSI color codes
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"

    def __init__(self, force_color: bool | None = None):
        """Initialize formatter. Disables color when stdout is not a terminal.

        Args:
            force_color: True=always color, False=never, None=auto-detect.
        """
        if force_color is True:
            return
        no_color = os.environ.get("NO_COLOR") is not None
        if force_color is False or no_color or not sys.stdout.isatty():
            self.RESET = self.BOLD = self.DIM = ""
            self.RED = self.GREEN = self.YELLOW = self.BLUE = ""
            self.MAGENTA = self.CYAN = self.WHITE = ""
            self.BG_RED = self.BG_GREEN = self.BG_YELLOW = self.BG_BLUE = ""

    def _decision_style(self, decision: str) -> tuple[str, str, str]:
        styles = {
            "ALLOW": (self.BG_GREEN, self.WHITE, "ALLOW"),
            "WARN": (self.BG_YELLOW, self.WHITE, "WARN"),
            "BLOCK": (self.BG_RED, self.WHITE, "BLOCK"),
            "ERROR": (self.BG_RED, self.WHITE, "ERROR"),
        }
        return styles.get(decision, (self.BG_RED, self.WHITE, decision))

    def _severity_icon(self, severity: str) -> tuple[str, str]:
        icons = {
            "high": (self.RED, "\u2717"),
            "medium": (self.YELLOW, "\u26A0"),
            "low": (self.BLUE, "\u2139"),
        }
        return icons.get(severity, (self.BLUE, "\u2139"))

    def format(self, response: dict, **kwargs) -> str:
        """Format the full CostGuard API response for terminal display."""
        lines: list[str] = []

        # Support both flat (v1 API) and nested (legacy) response shapes
        if "endpoint_data" in response:
            endpoint_data = response["endpoint_data"]
            results = response.get("results") or {}
        else:
            endpoint_data = response
            results = response

        decision = (endpoint_data.get("decision") or "ERROR").upper()

        # Decision banner
        lines.append(self._decision_banner(decision))
        lines.append("")

        # Cost summary
        lines.append(self._cost_summary(results))
        lines.append("")

        # Resource cost table
        resources = results.get("resources") or []
        if resources:
            lines.append(self._resource_table(resources))
            lines.append("")

        # Budget status
        budget = endpoint_data.get("budget")
        if budget:
            lines.append(self._budget_section(budget))
            lines.append("")

        # Guardrail summary
        guardrails = endpoint_data.get("guardrails")
        if guardrails:
            lines.append(self._guardrail_summary(guardrails))
            lines.append("")

        # Violations
        violations = endpoint_data.get("violations") or []
        if violations:
            lines.append(self._violations_section(violations))
            lines.append("")

        # AI narrative — API returns dict {"html": "..."} or plain string
        narrative = results.get("narrative")
        if narrative:
            if isinstance(narrative, dict):
                narrative = narrative.get("html") or narrative.get("text", "")
            if narrative:
                lines.append(self._narrative_box(narrative))
            lines.append("")

        # Errors
        errors = results.get("errors") or []
        if errors:
            lines.append(self._errors_section(errors))
            lines.append("")

        # Footer
        lines.append(self._footer(response))

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Section renderers
    # ------------------------------------------------------------------

    def _decision_banner(self, decision: str) -> str:
        bg, fg, label = self._decision_style(decision)
        banner_text = f"  COSTGUARD DECISION: {label}  "
        padding = " " * len(banner_text)
        return (
            f"{bg}{fg}{self.BOLD}{padding}{self.RESET}\n"
            f"{bg}{fg}{self.BOLD}{banner_text}{self.RESET}\n"
            f"{bg}{fg}{self.BOLD}{padding}{self.RESET}"
        )

    def _cost_summary(self, results: dict) -> str:
        # Support both flat summary and nested results
        summary = results.get("summary") or {}
        total = summary.get("total_monthly_cost") or results.get("total_monthly_usd")
        currency = summary.get("currency") or results.get("currency", "USD")
        resource_count = summary.get("total_resources") or len(results.get("resources") or [])

        total_str = f"${total:,.2f}" if total is not None else "N/A"
        return (
            f"{self.BOLD}{self.CYAN}MONTHLY COST ESTIMATE{self.RESET}\n"
            f"  Total: {self.BOLD}{self.WHITE}{total_str} {currency}{self.RESET}\n"
            f"  Resources: {resource_count}"
        )

    def _resource_table(self, resources: list[dict]) -> str:
        # Calculate column widths
        name_header = "Resource"
        type_header = "Type"
        cost_header = "Monthly Cost"

        names = [r.get("resource_name") or r.get("resource_id", "unknown") for r in resources]
        types = [r.get("resource_type", "unknown") for r in resources]
        costs = []
        for r in resources:
            mc = r.get("monthly_cost")
            costs.append(f"${mc:,.2f}" if mc is not None else "N/A")

        name_width = max(len(name_header), *(len(n) for n in names))
        type_width = max(len(type_header), *(len(t) for t in types))
        cost_width = max(len(cost_header), *(len(c) for c in costs))

        header = (
            f"  {self.BOLD}{name_header:<{name_width}}  "
            f"{type_header:<{type_width}}  "
            f"{cost_header:>{cost_width}}{self.RESET}"
        )
        separator = f"  {'-' * name_width}  {'-' * type_width}  {'-' * cost_width}"

        rows = []
        for name, rtype, cost_str in zip(names, types, costs):
            rows.append(f"  {name:<{name_width}}  {rtype:<{type_width}}  {cost_str:>{cost_width}}")

        return f"{self.BOLD}{self.CYAN}RESOURCE BREAKDOWN{self.RESET}\n{header}\n{separator}\n" + "\n".join(rows)

    def _budget_section(self, budget: dict) -> str:
        budget_name = budget.get("budget_name", "Unknown")
        budget_status = budget.get("budget_status", "unknown")

        lines = [f"{self.BOLD}{self.CYAN}BUDGET STATUS{self.RESET}"]

        # Budget not found — show clear message instead of confusing zero headroom
        if budget.get("budget_found") is False:
            reason = budget.get("decision_reason", "No applicable budget found")
            lines.append(f"  {self.RED}{self.BOLD}Budget not found{self.RESET}")
            lines.append(f"  {self.DIM}{reason}{self.RESET}")
            lines.append(f"  {self.YELLOW}Check your --budget-code value or use --auto-approve{self.RESET}")
            return "\n".join(lines)

        lines.append(f"  Budget: {budget_name}")

        # Full budget fields (monthly_limit, current_usage, remaining)
        monthly_limit = budget.get("monthly_limit")
        if monthly_limit is not None:
            current_usage = budget.get("current_usage", 0)
            lines.append(f"  Limit:  ${monthly_limit:,.2f}/mo")
            lines.append(f"  Used:   ${current_usage:,.2f}")
            bar = self._progress_bar(current_usage, monthly_limit, width=40)
            lines.append(f"  {bar}")

            projected_usage = budget.get("projected_usage")
            if projected_usage is not None:
                pct = (projected_usage / monthly_limit * 100) if monthly_limit > 0 else 0
                color = self.GREEN if pct < 80 else (self.YELLOW if pct < 100 else self.RED)
                lines.append(f"  Projected: {color}${projected_usage:,.2f} ({pct:.0f}%){self.RESET}")

            remaining = budget.get("remaining")
            if remaining is not None:
                rem_color = self.GREEN if remaining > 0 else self.RED
                lines.append(f"  Remaining: {rem_color}${remaining:,.2f}{self.RESET}")

        # CostGuard UnifiedResponse fields (available_headroom, projected_consumption_pct)
        headroom = budget.get("available_headroom")
        consumption_pct = budget.get("projected_consumption_pct")

        if headroom is not None and monthly_limit is None:
            headroom_color = self.GREEN if headroom > 0 else self.RED
            lines.append(f"  Headroom: {headroom_color}${headroom:,.2f}{self.RESET}")

        if consumption_pct is not None:
            pct_color = self.GREEN if consumption_pct < 80 else (self.YELLOW if consumption_pct < 100 else self.RED)
            lines.append(f"  Consumption: {pct_color}{consumption_pct:.1f}%{self.RESET}")
            # Show progress bar from consumption percentage
            if monthly_limit is None:
                bar = self._progress_bar(consumption_pct, 100, width=40)
                lines.append(f"  {bar}")

        if budget_status == "not_checked":
            lines.append(f"  {self.DIM}(Budget validation skipped){self.RESET}")

        return "\n".join(lines)

    def _progress_bar(self, current: float, total: float, width: int = 40) -> str:
        if total <= 0:
            return "[" + "?" * width + "]"

        ratio = min(current / total, 1.0)
        filled = int(ratio * width)
        empty = width - filled
        pct = ratio * 100

        if ratio < 0.7:
            color = self.GREEN
        elif ratio < 0.9:
            color = self.YELLOW
        else:
            color = self.RED

        bar = f"{color}{'█' * filled}{self.DIM}{'░' * empty}{self.RESET}"
        return f"  [{bar}] {pct:.0f}%"

    def _guardrail_summary(self, guardrails: dict) -> str:
        # Support both nested summary and flat format from CostGuard API
        gs = guardrails.get("summary") or {}
        total = (
            gs.get("rules_evaluated")
            or guardrails.get("evaluated")
            or guardrails.get("total", 0)
        )
        passed = (
            gs.get("rules_passed")
            or guardrails.get("passed", 0)
        )
        failed = (
            gs.get("rules_failed")
            or guardrails.get("failed", 0)
        )

        pass_color = self.GREEN if failed == 0 else self.YELLOW
        fail_color = self.RED if failed > 0 else self.GREEN

        return (
            f"{self.BOLD}{self.CYAN}GUARDRAILS{self.RESET}\n"
            f"  Total: {total}  "
            f"{pass_color}Passed: {passed}{self.RESET}  "
            f"{fail_color}Failed: {failed}{self.RESET}"
        )

    def _violations_section(self, violations: list[dict]) -> str:
        lines = [f"{self.BOLD}{self.RED}VIOLATIONS{self.RESET}"]

        for v in violations:
            severity = (v.get("severity") or "low").lower()
            color, icon = self._severity_icon(severity)
            rule = v.get("rule", "unknown")
            message = v.get("message", "")
            resource = v.get("resource", "")
            recommendation = v.get("recommendation", "")

            lines.append(f"  {color}{icon} [{severity.upper()}]{self.RESET} {rule}")
            if message:
                lines.append(f"    {message}")
            if resource:
                lines.append(f"    Resource: {self.DIM}{resource}{self.RESET}")
            if recommendation:
                lines.append(f"    {self.GREEN}Recommendation: {recommendation}{self.RESET}")
            lines.append("")

        return "\n".join(lines).rstrip()

    def _narrative_box(self, narrative: str) -> str:
        import re
        # Strip HTML tags for terminal display
        narrative = re.sub(r'<[^>]+>', '', narrative).strip()
        border = "─" * 60
        wrapped_lines = []
        for line in narrative.split("\n"):
            while len(line) > 58:
                wrapped_lines.append(line[:58])
                line = line[58:]
            wrapped_lines.append(line)

        body = "\n".join(f"  {self.MAGENTA}│{self.RESET} {line}" for line in wrapped_lines)

        return (
            f"{self.BOLD}{self.MAGENTA}AI ANALYSIS{self.RESET}\n"
            f"  {self.MAGENTA}┌{border}┐{self.RESET}\n"
            f"{body}\n"
            f"  {self.MAGENTA}└{border}┘{self.RESET}"
        )

    def _errors_section(self, errors: list) -> str:
        lines = [f"{self.BOLD}{self.RED}ERRORS{self.RESET}"]
        for err in errors:
            if isinstance(err, dict):
                lines.append(f"  {self.RED}\u2717{self.RESET} {err.get('message', str(err))}")
            else:
                lines.append(f"  {self.RED}\u2717{self.RESET} {err}")
        return "\n".join(lines)

    def _footer(self, response: dict) -> str:
        request_id = response.get("request_id", "")
        processing_time = response.get("processing_time_ms")
        timestamp = response.get("timestamp", "")

        parts = [f"{self.DIM}"]
        if request_id:
            parts.append(f"Request: {request_id}")
        if timestamp:
            parts.append(f"Time: {timestamp}")
        if processing_time is not None:
            parts.append(f"Processing: {processing_time}ms")
        parts.append(f"Powered by CostGuard \u2014 SKYXOPS{self.RESET}")

        return " | ".join(parts)
