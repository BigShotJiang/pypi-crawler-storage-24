
# services_show

Show service

## Usage

```console
Usage: genesis services show [OPTIONS] UUID
```

## Options

* `uuid` (REQUIRED):
    * Type: text
    * Default: `sentinel.unset`
    * Usage: `uuid`

* `help`:
    * Type: boolean
    * Default: `false`
    * Usage: `--help`

  Show this message and exit.

## CLI Help

```console
Usage: genesis services show [OPTIONS] UUID

  Show service

Options:
  --help  Show this message and exit.
```
