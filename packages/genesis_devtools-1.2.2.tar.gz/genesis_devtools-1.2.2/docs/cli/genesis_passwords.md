
# genesis_passwords

Manage passwords in the Genesis installation

## Usage

```console
Usage: genesis passwords [OPTIONS] COMMAND [ARGS]...
```

## Options

* `help`:
    * Type: boolean
    * Default: `false`
    * Usage: `--help`

  Show this message and exit.

## CLI Help

```console
Usage: genesis passwords [OPTIONS] COMMAND [ARGS]...

  Manage passwords in the Genesis installation

Options:
  --help  Show this message and exit.

Commands:
  add     Add a new password to the Genesis installation
  delete  Delete password
  list    List passwords
  show    Show password
  update  Update password
```
