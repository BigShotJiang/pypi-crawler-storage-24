#!/usr/bin/env bash

#    Copyright {{ functions.now().strftime('%Y') }} {{ author_name }}.
#
#    All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

set -eu
set -x
set -o pipefail

{% if project_node_install_redis %}
sudo mkdir -p /var/log/redis/
sudo chown redis:redis -R /var/log/redis/
sudo systemctl restart redis.service
{% endif %}
