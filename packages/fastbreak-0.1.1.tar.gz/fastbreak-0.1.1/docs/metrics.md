# fastbreak.metrics

Pure computation functions for derived basketball metrics. No async, no client, no network
calls — every function takes plain Python floats and returns a float (or None when the
denominator is zero). The module is designed to work naturally with data returned by the
fastbreak API helpers, but it has no dependency on them and can be used with any data source.

## Overview

```python
from fastbreak.metrics import (
    # Efficiency
    true_shooting, effective_fg_pct, game_score, relative_ts, relative_efg,
    # Rate stats
    per_36, per_100, free_throw_rate, three_point_rate, ast_to_tov, assist_ratio,
    # Counting / thresholds
    is_double_double, is_triple_double,
    # On-floor impact
    usage_pct, ast_pct, oreb_pct, dreb_pct, stl_pct, blk_pct,
    # PER
    pace_adjusted_per, per,
    # BPM / VORP
    BPMResult, bpm, vorp,
    # Team ratings
    ortg, drtg, net_rtg,
    # Win metrics
    offensive_win_shares, defensive_win_shares,
    win_shares, win_shares_per_48,
    # Possession estimate
    possessions,
    # Rolling / windowed
    rolling_avg, ewma,
    # Distribution
    stat_floor, stat_ceiling, stat_median, prop_hit_rate,
    percentile_rank, stat_consistency, streak_count,
    rolling_consistency, expected_stat, hit_rate_last_n,
    # League context
    LeagueAverages,
)
```

A few things to know before using:

- Every function is a pure computation — same inputs, same output, no side effects.
- Functions that divide return `None` when the denominator is zero. Exceptions: `game_score`, `is_double_double`, and `is_triple_double` never return `None`.
- `nan` and `inf` inputs produce unspecified results — sanitize before passing in.
- Scale doesn't matter as long as all inputs for one call are on the same scale (per-game, per-36, season totals, etc.).

---

## LeagueAverages

`LeagueAverages` is the league context object required by relative and normalised metrics
(`relative_ts`, `relative_efg`, and the PER pipeline). It is a frozen dataclass with
`slots=True`.

```python
from fastbreak.metrics import LeagueAverages

lg = LeagueAverages(
    lg_pts=114.0,
    lg_fga=88.5,
    lg_fta=22.0,
    lg_ftm=17.5,
    lg_oreb=10.5,
    lg_treb=44.0,
    lg_ast=26.0,
    lg_fgm=42.0,
    lg_fg3m=13.0,
    lg_tov=13.5,
    lg_pf=19.5,
)
```

### Fields

All fields are `float`. Pass per-team-per-game averages (the scale used by
`get_league_averages()`), or whole-league totals — as long as the scale is consistent
across all fields.

| Field | Description |
|---|---|
| `lg_pts` | League average points per team per game |
| `lg_fga` | League average field goal attempts |
| `lg_fta` | League average free throw attempts |
| `lg_ftm` | League average free throws made |
| `lg_oreb` | League average offensive rebounds |
| `lg_treb` | League average total rebounds |
| `lg_ast` | League average assists |
| `lg_fgm` | League average field goals made |
| `lg_fg3m` | League average 3-pointers made |
| `lg_tov` | League average turnovers |
| `lg_pf` | League average personal fouls |

### Computed properties

These are recalculated on each property access from the stored fields. They are used
internally by metric functions but are also available to callers.

| Property | Formula | Description |
|---|---|---|
| `lg_pace` | `lg_fga - lg_oreb + lg_tov + 0.44·lg_fta` | Possession estimate (Dean Oliver formula) used as the league pace proxy in PER. Numerically equivalent to possessions per game (~95–105 for modern NBA). Pass `team_pace` using the same formula applied to team totals. |
| `vop` | `lg_pts / (lg_fga - lg_oreb + lg_tov + 0.44·lg_fta)` | Value of a Possession |
| `drb_pct` | `(lg_treb - lg_oreb) / lg_treb` | League defensive rebound rate |
| `factor` | `2/3 - (0.5·(lg_ast/lg_fgm)) / (2·(lg_fgm/lg_ftm))` | Assist factor used in PER |
| `ts` | `lg_pts / (2·(lg_fga + 0.44·lg_fta))` | League average True Shooting% |
| `efg` | `(lg_fgm + 0.5·lg_fg3m) / lg_fga` | League average eFG% |

### Validation

`__post_init__` raises `ValueError` under the following conditions:

- Any field is negative.
- Any of the denominator fields (`lg_fga`, `lg_treb`, `lg_fgm`, `lg_ftm`, `lg_pf`) is zero.
- `lg_oreb > lg_treb` (offensive rebounds exceed total rebounds).
- The `vop` compound denominator (`lg_fga - lg_oreb + lg_tov + 0.44·lg_fta`) is not
  positive.

---

## Getting league averages from the API

The recommended way to populate `LeagueAverages` is via `get_league_averages()` from
`fastbreak.teams`. It fetches per-game stats for all 30 teams using `LeagueDashTeamStats`
and computes means across all teams.

```python
import asyncio
from fastbreak.clients import NBAClient
from fastbreak.teams import get_league_averages

async def main():
    async with NBAClient() as client:
        # Current season
        lg = await get_league_averages(client)

        # Specific season
        lg_2024 = await get_league_averages(client, season="2024-25")

    print(f"League TS%: {lg.ts:.3f}")
    print(f"League eFG%: {lg.efg:.3f}")
    print(f"League pace: {lg.lg_pace:.1f}")

asyncio.run(main())
```

Pace is estimated using the Dean Oliver possession formula:
`poss = fga - oreb + tov + 0.44 * fta`.

---

## FourFactors

```python
@dataclass(frozen=True, slots=True)
class FourFactors:
    efg_pct: float | None
    tov_pct: float | None
    oreb_pct: float | None
    ftr: float | None
```

Immutable result type returned by `four_factors()`.

### four_factors

```python
def four_factors(fgm: float, fg3m: float, fga: float, tov: float, fta: float, oreb: float, opp_dreb: float) -> FourFactors
```

Compute Dean Oliver's Four Factors for a single team performance.

| Factor | Field | Formula |
|---|---|---|
| Shooting efficiency | `efg_pct` | `(FGM + 0.5×FG3M) / FGA` |
| Ball security | `tov_pct` | `TOV / (FGA + 0.44×FTA + TOV)` |
| Second chances | `oreb_pct` | `OREB / (OREB + opp_DREB)` |
| Getting to the line | `ftr` | `FTA / FGA` |

Note: `oreb_pct` here is the **team-level** formula (no per-minute correction) — different from the player-level `oreb_pct()` function also in this module.

```python
ff = four_factors(fgm=40, fg3m=12, fga=88, tov=14, fta=20, oreb=10, opp_dreb=32)
print(ff.efg_pct)   # 0.523
print(ff.tov_pct)   # 0.126
```

---

## Function Reference

### Return value conventions

All functions that perform division return `float | None`. A `None` return means the
computation was not possible due to a zero denominator — most commonly because a player
did not attempt any shots, play any minutes, or face any opponent possessions in the
relevant sample. Always check for `None` before using a return value in downstream
calculations:

```python
ts = true_shooting(pts=0, fga=0, fta=0)
if ts is not None:
    rel = relative_ts(ts, lg)
```

`game_score`, `is_double_double`, and `is_triple_double` always return a value and never
return `None`.

---

### Efficiency Metrics

#### `true_shooting`

```python
def true_shooting(pts: float, fga: float, fta: float) -> float | None
```

True Shooting percentage — shooting efficiency that accounts for all three shot types
(2-pointers, 3-pointers, and free throws).

**Formula:** `TS% = pts / (2 * (fga + 0.44 * fta))`

The 0.44 multiplier on FTA reflects that not every free-throw trip consumes a full
possession (e.g., an and-one trip costs roughly 0.44 possessions rather than 1.0).

Values above 1.0 are valid in rare edge cases (player draws many and-one free throws
on a very small FGA sample). Always check before clamping.

Returns `None` when both `fga` and `fta` are zero.

```python
ts = true_shooting(pts=28, fga=18, fta=6)   # → 0.678
ts = true_shooting(pts=0,  fga=0,  fta=0)   # → None
```

---

#### `effective_fg_pct`

```python
def effective_fg_pct(fgm: float, fg3m: float, fga: float) -> float | None
```

Effective Field Goal percentage — adjusts FG% to give proper credit for 3-pointers,
which are worth 1.5× a made 2-pointer.

**Formula:** `eFG% = (fgm + 0.5 * fg3m) / fga`

Values above 1.0 are valid on small samples where a player makes many 3-pointers
relative to their total attempts (e.g., 3-for-3 from three with 0 two-point attempts).

Returns `None` when `fga` is zero.

```python
efg = effective_fg_pct(fgm=11, fg3m=4, fga=20)  # → 0.65
```

---

#### `game_score`

```python
def game_score(
    pts: float, fgm: float, fga: float, ftm: float, fta: float,
    oreb: float, dreb: float, stl: float, ast: float, blk: float,
    pf: float, tov: float,
) -> float
```

Hollinger's Game Score — a single number summarising a box score line. Roughly calibrated
so that 10 is an average game and 40+ is exceptional. Can be negative for very poor
shooting lines.

**Formula:**
```
GmSc = PTS + 0.4*FGM - 0.7*FGA - 0.4*(FTA - FTM)
       + 0.7*OREB + 0.3*DREB + STL + 0.7*AST + 0.7*BLK - 0.4*PF - TOV
```

Never returns `None`.

```python
gs = game_score(
    pts=28, fgm=11, fga=19, ftm=7, fta=9,
    oreb=1, dreb=8, stl=2, ast=8, blk=1, pf=3, tov=4,
)
# → 24.5
```

---

#### `relative_ts`

```python
def relative_ts(player_ts: float | None, lg: LeagueAverages) -> float | None
```

Player True Shooting% minus the league average TS% (`lg.ts`). A positive value means
the player is more efficient than league average.

Returns `None` when `player_ts` is `None` (no shot attempts).

```python
ts  = true_shooting(pts=30, fga=20, fta=5)
rel = relative_ts(ts, lg)   # positive → above-average shooter
```

---

#### `relative_efg`

```python
def relative_efg(player_efg: float | None, lg: LeagueAverages) -> float | None
```

Player Effective Field Goal% minus the league average eFG% (`lg.efg`). A positive value
means the player generates more value per field goal attempt than the league average.

Returns `None` when `player_efg` is `None` (no field goal attempts).

---

### Rate Stats

#### `per_36`

```python
def per_36(stat: float, minutes: float) -> float | None
```

Normalise a counting stat to a per-36-minute pace. 36 minutes is the conventional
baseline, roughly equivalent to a starter's workload.

**Formula:** `per_36 = stat * 36 / minutes`

Returns `None` when `minutes` is zero.

```python
pts_per_36 = per_36(stat=20, minutes=30)  # → 24.0
reb_per_36 = per_36(stat=8,  minutes=30)  # → 9.6
```

---

#### `per_100`

```python
def per_100(stat: float, poss: float) -> float | None
```

Normalize a counting stat to a per-100-possessions rate.

`per_100 = stat × 100 / poss`

Prefer per-100 over per-36 when comparing players across eras with different league paces (e.g., 1970s ~105 poss/game vs. 2020s ~100 poss/game).

To get team-level possessions: `possessions(fga, oreb, tov, fta)` from this module.

Returns `None` when possessions are zero.

```python
pts_per_100 = per_100(stat=25, poss=96.4)  # → 25.934
reb_per_100 = per_100(stat=10, poss=100)   # → 10.0
```

---

#### `free_throw_rate`

```python
def free_throw_rate(fta: float, fga: float) -> float | None
```

Free Throw Rate — how aggressively a player attacks the foul line relative to their
volume of field goal attempts.

**Formula:** `FTr = fta / fga`

Values above 1.0 are valid for elite attackers who draw more free throw trips than
field goal attempts. Returns `None` when `fga` is zero.

```python
ftr = free_throw_rate(fta=8, fga=15)  # → 0.533
```

---

#### `three_point_rate`

```python
def three_point_rate(fg3a: float, fga: float) -> float | None
```

Three-Point Attempt Rate — the share of a player's field goal attempts that come from
beyond the arc.

**Formula:** `3PAr = fg3a / fga`

Returns `None` when `fga` is zero.

```python
tpar = three_point_rate(fg3a=9, fga=18)  # → 0.5
```

---

#### `tov_pct`

```python
def tov_pct(fga: float, fta: float, tov: float) -> float | None
```

Turnover percentage — share of possessions ending in a turnover.

`TOV% = TOV / (FGA + 0.44 × FTA + TOV)`

The denominator is Dean Oliver's possession estimate (same 0.44 FTA multiplier as `true_shooting` and `usage_pct`). Together with `effective_fg_pct`, `free_throw_rate`, and the team offensive rebound rate, this completes the Four Factors framework.

Returns a **0–1 fraction** (e.g. `0.126` for 12.6%). This matches the scale used by `FourFactorsStatistics.teamTurnoverPercentage` (from the box score four-factors endpoint). It does **not** match `AdvancedTeamStatistics.estimatedTeamTurnoverPercentage`, which the NBA advanced box-score endpoint returns on a **0–100 scale** (e.g. `12.6`). Multiply by 100 before comparing against that field.

Returns `None` when all three inputs are zero.

---

#### `ast_to_tov`

```python
def ast_to_tov(ast: float, tov: float) -> float | None
```

Assist-to-Turnover ratio — a measure of playmaking efficiency. Higher is better; elite
playmakers typically sustain values above 3.0 for a full season.

**Formula:** `AST/TOV = ast / tov`

Returns `None` when `tov` is zero to avoid division by zero.

```python
ratio = ast_to_tov(ast=9, tov=3)  # → 3.0
```

---

#### `assist_ratio`

```python
def assist_ratio(ast: float, fga: float, fta: float, tov: float) -> float | None
```

Assist Ratio — the percentage of a player's total possessions used that end in an assist.
Unlike `ast_to_tov`, this accounts for volume by normalising against all possession-ending
events, not just turnovers.

**Formula:** `AST Ratio = AST / (FGA + 0.44×FTA + AST + TOV) × 100`

The denominator includes field goal attempts, the FTA possession estimate, assists, and
turnovers — everything that "uses" a possession for or by the player.

Returns `None` when the denominator is zero (no activity at all).

```python
ratio = assist_ratio(ast=8, fga=0, fta=0, tov=3)   # pure passer: → 72.7
ratio = assist_ratio(ast=8, fga=18, fta=6, tov=2)  # typical guard
```

---

### Counting / Thresholds

Both functions operate on the five traditional counting categories and never return `None`.

#### `is_double_double`

```python
def is_double_double(pts: float, reb: float, ast: float, stl: float, blk: float) -> bool
```

Returns `True` if at least **two** of the five counting categories (points, rebounds,
assists, steals, blocks) are at 10 or above.

```python
is_double_double(pts=22, reb=11, ast=4, stl=1, blk=0)  # → True
is_double_double(pts=18, reb=9,  ast=4, stl=1, blk=0)  # → False
```

---

#### `is_triple_double`

```python
def is_triple_double(pts: float, reb: float, ast: float, stl: float, blk: float) -> bool
```

Returns `True` if at least **three** of the five counting categories are at 10 or above.

```python
is_triple_double(pts=22, reb=11, ast=10, stl=1, blk=0)  # → True
```

---

### On-Floor Impact

These functions measure what a player contributes while on the court, expressed as a
percentage of team or opponent opportunities. All use the same scaling pattern:
`stat * (team_mp / 5) / (mp * opportunity)`, which puts individual and team counts on a
per-person scale by dividing team minutes by 5.

All return `None` when `mp` (player minutes) is zero or when the relevant opportunity
count is zero.

---

#### `usage_pct`

```python
def usage_pct(
    fga: float, fta: float, tov: float, mp: float,
    team_fga: float, team_fta: float, team_tov: float, team_mp: float,
) -> float | None
```

Usage Percentage — the share of team possessions that end with the player taking a shot,
getting to the line, or turning the ball over while they are on the floor.

**Formula:**
```
Usage% = (fga + 0.44*fta + tov) * (team_mp/5) / (mp * (team_fga + 0.44*team_fta + team_tov))
```

A usage rate of approximately 0.20 is league-average; 0.30+ is a primary scoring option.
Returns `None` when `mp` or team possessions are zero.

```python
usg = usage_pct(
    fga=18, fta=6, tov=3, mp=34,
    team_fga=88, team_fta=22, team_tov=13, team_mp=240,
)
```

---

#### `ast_pct`

```python
def ast_pct(
    ast: float, fgm: float, mp: float, team_fgm: float, team_mp: float,
) -> float | None
```

Assist Percentage — the share of teammate field goals that the player assisted while on
the floor.

**Formula:**
```
AST% = ast / ((mp / (team_mp / 5)) * team_fgm - fgm)
```

The denominator estimates how many teammate baskets the player could have assisted:
team FGM scaled to the player's on-court time, minus the player's own makes.

Returns `None` when `mp` or `team_mp` is zero, or when the denominator is non-positive
(degenerate data, e.g. a player who made every basket their team made).

---

#### `oreb_pct`

```python
def oreb_pct(
    oreb: float, mp: float, team_oreb: float, opp_dreb: float, team_mp: float,
) -> float | None
```

Offensive Rebound Percentage — the share of available offensive boards the player
grabbed while on the floor.

**Formula:** `OREB% = oreb * (team_mp/5) / (mp * (team_oreb + opp_dreb))`

The denominator is total offensive rebounds available: every offensive missed shot that
was either grabbed by the player's team or conceded to the opponent's defense.

Returns `None` when `mp` or available rebounds are zero.

---

#### `dreb_pct`

```python
def dreb_pct(
    dreb: float, mp: float, team_dreb: float, opp_oreb: float, team_mp: float,
) -> float | None
```

Defensive Rebound Percentage — the share of available defensive boards the player
grabbed while on the floor.

**Formula:** `DREB% = dreb * (team_mp/5) / (mp * (team_dreb + opp_oreb))`

The denominator is total defensive rebounds available: every opponent miss that was
either secured defensively or retrieved by the opponent.

Returns `None` when `mp` or available rebounds are zero.

---

#### `stl_pct`

```python
def stl_pct(stl: float, mp: float, team_mp: float, opp_poss: float) -> float | None
```

Steal Percentage — the share of opponent possessions that ended in a steal by the player
while on the floor.

**Formula:** `STL% = stl * (team_mp/5) / (mp * opp_poss)`

`opp_poss` is typically estimated as: `opp_fga + 0.44*opp_fta + opp_tov - opp_oreb`.

Returns `None` when `mp` or `opp_poss` is zero.

---

#### `blk_pct`

```python
def blk_pct(blk: float, mp: float, team_mp: float, opp_fg2a: float) -> float | None
```

Block Percentage — the share of opponent 2-point field goal attempts that the player
blocked while on the floor.

**Formula:** `BLK% = blk * (team_mp/5) / (mp * opp_fg2a)`

Only 2-point attempts are used because 3-pointers are almost never blocked; including
them would dilute the signal. `opp_fg2a = opp_fga - opp_fg3a`.

Returns `None` when `mp` or `opp_fg2a` is zero.

---

### PER (Player Efficiency Rating)

PER is computed in two steps. First, `pace_adjusted_per` produces an unadjusted,
pace-normalised value (aPER) for a single player. After computing aPER for all players
in the league, you calculate a minutes-weighted league average aPER (`lg_aper`), then
call `per` to normalise to the conventional 15.0 baseline.

The league average PER is exactly 15.0 by construction. A borderline All-Star typically
registers around 25; values above 30 are rare.

---

#### `pace_adjusted_per`

```python
def pace_adjusted_per(
    fgm: float, fga: float, fg3m: float, ftm: float, fta: float,
    oreb: float, treb: float, ast: float, stl: float, blk: float,
    pf: float, tov: float, mp: float,
    team_ast: float, team_fgm: float, team_pace: float,
    lg: LeagueAverages,
) -> float | None
```

Pace-adjusted PER (aPER) — the first of two steps toward a full PER. Implements
Hollinger's unadjusted PER formula then scales by `lg_pace / team_pace` to put
fast-paced and slow-paced teams on equal footing.

**Arguments:**

| Argument | Description |
|---|---|
| `fgm` | Field goals made |
| `fga` | Field goals attempted |
| `fg3m` | Three-pointers made |
| `ftm` | Free throws made |
| `fta` | Free throws attempted |
| `oreb` | Offensive rebounds |
| `treb` | Total rebounds |
| `ast` | Assists |
| `stl` | Steals |
| `blk` | Blocks |
| `pf` | Personal fouls |
| `tov` | Turnovers |
| `mp` | Minutes played |
| `team_ast` | Team assists (same game or period as the player stats) |
| `team_fgm` | Team field goals made |
| `team_pace` | Team pace using the same possession formula as `lg.lg_pace`: `fga - oreb + tov + 0.44·fta` applied to team totals |
| `lg` | `LeagueAverages` for the season |

Returns `None` when `mp`, `team_fgm`, or `team_pace` is zero.

---

#### `per`

```python
def per(aper: float, lg_aper: float) -> float | None
```

Normalise a pace-adjusted PER to the conventional 15.0 league-average baseline.

**Formula:** `PER = aper * (15 / lg_aper)`

`lg_aper` is the minutes-weighted mean of all players' aPER values for the season.

Returns `None` when `lg_aper` is zero.

| PER range | Context |
|---|---|
| < 0 | Very poor game / season |
| ~10 | Below average |
| ~15 | League average (by definition) |
| ~20 | Good starter |
| ~25 | Borderline All-Star |
| 30+ | Elite / MVP-caliber |

---

### Team Ratings

Team ratings use the Dean Oliver possession estimate:
`possessions = fga - oreb + tov + 0.44 * fta`.

#### `possessions`

```python
def possessions(fga: float, oreb: float, tov: float, fta: float) -> float
```

Estimate the number of possessions using Dean Oliver's formula. Accounts for offensive
rebounds (which extend a possession rather than ending it) and the fractional FTA
multiplier (not all free-throw trips are standalone possessions).

**Formula:** `poss = fga - oreb + tov + 0.44 × fta`

This function never returns `None` — zero inputs simply produce zero possessions. Use
the result as the denominator for `per_100`, or pass it to `ortg`/`drtg` implicitly by
passing the raw counting stats.

```python
poss = possessions(fga=88, oreb=10, tov=13, fta=22)  # → 103.68
```

---

#### `ortg`

```python
def ortg(pts: float, fga: float, oreb: float, tov: float, fta: float) -> float | None
```

Offensive Rating — points scored per 100 possessions. Accounts for possession-ending
events (shots, turnovers, and free-throw trips) to remove the effect of pace.

Returns `None` when estimated possessions are zero.

```python
off_rtg = ortg(pts=112, fga=85, oreb=9, tov=13, fta=20)
```

---

#### `drtg`

```python
def drtg(opp_pts: float, opp_fga: float, opp_oreb: float, opp_tov: float, opp_fta: float) -> float | None
```

Defensive Rating — opponent points allowed per 100 opponent possessions. Lower is better.

The possession estimate uses the opponent's own counting stats (`opp_fga`, `opp_oreb`,
`opp_tov`, `opp_fta`), mirroring the way `ortg` uses the team's own counting stats for
the offensive possession estimate.

Returns `None` when estimated possessions are zero.

---

#### `net_rtg`

```python
def net_rtg(ortg_val: float | None, drtg_val: float | None) -> float | None
```

Net Rating — offensive rating minus defensive rating. The gold-standard summary of team
quality: positive means the team outscores opponents per possession, negative means the
reverse.

Returns `None` when either input is `None`.

```python
nr = net_rtg(ortg_val=114.2, drtg_val=110.8)  # → 3.4
```

---

#### `offensive_win_shares`

```python
def offensive_win_shares(
    pts: float, fga: float, fta: float, tov: float, lg: LeagueAverages,
) -> float | None
```

Offensive Win Shares — the player's estimated contribution to team wins through offense,
following the Basketball-Reference method.

**Formula:**
```
player_poss        = 0.96 × (fga + tov + 0.44 × fta)
marginal_offense   = pts − 0.92 × lg.vop × player_poss
marginal_pts_per_win = 0.32 × lg.lg_pts
OWS = marginal_offense / marginal_pts_per_win
```

The `0.96` factor strips out team offensive rebound extensions (which belong to the team,
not the individual). `0.92 × vop` is the replacement-level threshold — a player must
generate 8% more value than average replacement level to produce positive win shares.

Returns `None` when `lg.lg_pts` is zero.

```python
ows = offensive_win_shares(pts=28, fga=18, fta=6, tov=3, lg=lg)  # positive → above replacement
```

---

#### `defensive_win_shares`

```python
def defensive_win_shares(
    stl: float, blk: float, dreb: float, mp: float, pf: float,
    team_mp: float, team_blk: float, team_stl: float,
    team_dreb: float, team_pf: float,
    opp_fga: float, opp_fgm: float, opp_fta: float, opp_ftm: float,
    opp_tov: float, opp_oreb: float, opp_pts: float,
    lg: LeagueAverages,
) -> float | None
```

Defensive Win Shares — the player's estimated contribution to team wins through defense,
following the Basketball-Reference stops-based formula.

**Formula overview (5 steps):**

1. **Stops** — individual stops from steals, blocks, defensive rebounds, and a
   personal-foul share of team-level stops not attributable to a single player.
2. **Stop%** — `(stops × team_mp) / (opp_poss × mp)` — the fraction of opponent
   possessions the player stopped while on the floor.
3. **PlayerDRtg** — blends the team defensive rating toward the player's individual
   contribution: `team_drtg + 0.2 × (100 × pts_per_sc_poss × (1 − stop_pct) − team_drtg)`.
   Team defensive rating is computed internally from `opp_pts / opp_poss × 100`.
4. **MarginalDefense** — `(mp / team_mp) × opp_poss × (1.08 × lg.vop − PlayerDRtg / 100)`.
   The `1.08` threshold is the replacement-level multiplier (slightly above 1.0 to
   account for the difficulty of attributing defense individually).
5. **DWS** — `MarginalDefense / (0.32 × lg_pts)`.

**Arguments:**

| Argument | Description |
|---|---|
| `stl` | Player steals |
| `blk` | Player blocks |
| `dreb` | Player defensive rebounds |
| `mp` | Player minutes played |
| `pf` | Player personal fouls |
| `team_mp` | Team total player-minutes (5 × 48 × games played) |
| `team_blk` | Team total blocks |
| `team_stl` | Team total steals |
| `team_dreb` | Team total defensive rebounds |
| `team_pf` | Team total personal fouls |
| `opp_fga` | Opponent field goal attempts |
| `opp_fgm` | Opponent field goals made |
| `opp_fta` | Opponent free throw attempts |
| `opp_ftm` | Opponent free throws made |
| `opp_tov` | Opponent turnovers |
| `opp_oreb` | Opponent offensive rebounds |
| `opp_pts` | Opponent points scored |
| `lg` | `LeagueAverages` for the season |

Returns `None` when `mp` is zero, `team_mp` is zero, `opp_poss` is zero, the
scoring-possession denominator is zero, or `lg.lg_pts` is zero. Can return
**negative values** for players whose individual defensive rating exceeds
`1.08 × lg.vop × 100` (below-replacement defensive efficiency).

```python
dws = defensive_win_shares(
    stl=164, blk=82, dreb=410, mp=2870, pf=164,
    team_mp=19_680, team_blk=410, team_stl=656, team_dreb=2_624, team_pf=1_640,
    opp_fga=7_380, opp_fgm=3_444, opp_fta=1_804, opp_ftm=1_394,
    opp_tov=1_148, opp_oreb=820, opp_pts=9_430,
    lg=lg,
)
```

---

#### `win_shares`

```python
def win_shares(ows: float | None, dws: float | None) -> float | None
```

Total Win Shares — the sum of offensive and defensive contributions.

**Formula:** `WS = OWS + DWS`

Returns `None` when either component is `None`, consistent with how `net_rtg` handles
missing ORTG or DRTG. This strict propagation avoids silently dropping one side of the
formula when data for only half the calculation is available.

```python
ws = win_shares(ows=4.2, dws=2.1)   # → 6.3
ws = win_shares(ows=4.2, dws=None)  # → None (DWS unavailable — don't produce a partial result)
```

---

#### `win_shares_per_48`

```python
def win_shares_per_48(ws: float | None, mp: float) -> float | None
```

Win Shares per 48 minutes — WS normalised to a full-game pace, enabling fair comparisons
across players with different minute loads.

**Formula:** `WS/48 = WS × 48 / MP`

Calibrated so that league-average ≈ 0.100. A useful rule of thumb:

| WS/48 | Context |
|---|---|
| < 0.050 | Below average / rotation player |
| ~0.100 | League average |
| ~0.150 | Solid starter |
| ~0.200 | All-Star caliber |
| 0.250+ | MVP-caliber |

Returns `None` when `ws` is `None` or `mp` is zero.

```python
ws48 = win_shares_per_48(ws=6.3, mp=2870)   # → ~0.105  (league-average territory)
ws48 = win_shares_per_48(ws=None, mp=2870)  # → None
ws48 = win_shares_per_48(ws=6.3,  mp=0)    # → None
```

---

#### `pythagorean_win_pct`

```python
def pythagorean_win_pct(pts: float, opp_pts: float, exp: float = 13.91) -> float | None
```

Expected win% from point differential (Pythagorean win expectation).

`win% = pts^exp / (pts^exp + opp_pts^exp)`

The default exponent (13.91) is the basketball-specific correction; the original Pythagorean formula uses `exp=2`.

Pairs naturally with `TeamStanding.points_pg` and `TeamStanding.opp_points_pg`:

```python
expected = pythagorean_win_pct(s.points_pg, s.opp_points_pg)
luck = s.win_pct - expected   # positive = "lucky", negative = "unlucky"
```

Returns `None` when both inputs are zero.

---

### BPM and VORP

BPM (Box Plus/Minus) v2.0 estimates a player's contribution in points per 100 possessions above a league-average player. VORP (Value Over Replacement Player) converts BPM into a counting stat proportional to playing time.

Both are pure computation functions — no API call needed beyond fetching a player's per-100 stats and their share of team totals.

```python
from fastbreak.metrics import BPMResult, bpm, vorp
```

#### `BPMResult`

```python
@dataclass(frozen=True, slots=True)
class BPMResult:
    total: float      # total BPM (raw, before team adjustment)
    offensive: float  # OBPM component
    defensive: float  # DBPM component = total - offensive
```

A frozen dataclass returned by `bpm()`. Before using these values for comparison, apply a team adjustment so that the minutes-weighted average BPM across all players on a team equals the team's actual efficiency differential. For most comparisons, `defensive` (DBPM) is unaffected by the team constant.

---

#### `bpm`

```python
def bpm(
    pts: float, fg3m: float, ast: float, tov: float,
    orb: float, drb: float, stl: float, blk: float, pf: float,
    fga: float, fta: float,
    *,
    pct_team_trb: float, pct_team_stl: float, pct_team_pf: float,
    pct_team_ast: float, pct_team_blk: float, pct_team_pts: float,
    listed_position: float = 3.0,
    mp: float = 500.0,
) -> BPMResult | None
```

Compute raw BPM (Box Plus/Minus v2.0) from per-100-possession stats and team-percentage shares.

The function implements the [Daniel Myers / Basketball Reference BPM 2.0 formula](https://www.basketball-reference.com/about/bpm2.html):

1. **Estimate position** (1=PG → 5=C) from team-rebounding, assist, steal, block, and foul percentages, smoothed against `listed_position` using a 50-minute prior.
2. **Estimate role** (1=primary creator → 5=off-ball receiver) from team assist and scoring percentages, smoothed against a league-average prior of 4.0.
3. **Linearly interpolate** coefficient sets between the PG/C and creator/receiver endpoints.
4. Compute `raw_total` (total BPM) and `raw_obpm` (offensive BPM). `defensive = total − offensive`.

The raw values are **not team-adjusted**. To match Basketball Reference numbers, compute the minutes-weighted average BPM across all players on the team and subtract the constant needed to bring that average in line with the team's actual point differential.

**Parameters:**

| Parameter | Description |
|---|---|
| `pts`, `fg3m`, `ast`, `tov`, `orb`, `drb`, `stl`, `blk`, `pf`, `fga`, `fta` | Per-100-possession stat values |
| `pct_team_trb` | Player's share of team total rebounds |
| `pct_team_stl` | Player's share of team steals |
| `pct_team_pf` | Player's share of team personal fouls |
| `pct_team_ast` | Player's share of team assists |
| `pct_team_blk` | Player's share of team blocks |
| `pct_team_pts` | Player's share of team points |
| `listed_position` | Prior for position estimate (1=PG, 5=C, 3=default) |
| `mp` | Minutes played (used to weight the position/role prior, default 500) |

**Returns:** `BPMResult` with `total`, `offensive`, `defensive`, or `None` if `mp == 0`.

```python
from fastbreak.metrics import BPMResult, bpm, vorp

# LeBron James 2009-10 per-100 stats (Cleveland Cavaliers, first MVP season)
result = bpm(
    pts=34.3, fg3m=1.6, ast=9.8, tov=3.9,
    orb=1.4, drb=7.3, stl=1.9, blk=1.1, pf=2.5,
    fga=26.5, fta=10.2,
    pct_team_trb=0.168, pct_team_stl=0.203, pct_team_pf=0.108,
    pct_team_ast=0.406, pct_team_blk=0.192, pct_team_pts=0.291,
    listed_position=3.0, mp=2966,
)
# result.total + (-7.0) ≈ +10.8  (BR published: +10.8)
# result.offensive + (-7.0) ≈ +6.5  (BR published: +6.5)
# result.defensive ≈ +4.3            (BR published: +4.3)
```

---

#### `vorp`

```python
def vorp(
    bpm_total: float,
    poss_pct: float,
    games: int,
    *,
    replacement_level: float = -2.0,
) -> float
```

Convert BPM into Value Over Replacement Player — a counting stat proportional to playing time.

```
VORP = (bpm_total − replacement_level) × poss_pct × (games / 82)
```

`poss_pct` is the player's fraction of team possessions used — typically `mp / (team_mp / 5)`, which equals `mp * 5 / team_mp`. For a player who played all 82 games at full minutes, `poss_pct ≈ 1.0`.

The default replacement level is `−2.0` (a freely available reserve-quality player). Multiply VORP by 2.7 to get Wins Above Replacement (WAR).

**Returns:** float (never `None` — all inputs are required).

```python
v = vorp(bpm_total=8.9, poss_pct=0.81, games=81)  # ≈ 8.7
war = v * 2.7                                       # ≈ 23.5 wins
```

**Gotcha:** Pass the **team-adjusted** `bpm_total`, not the raw value from `bpm()`. Raw BPM is not comparable across teams.

---

### Rolling / Windowed

#### `rolling_avg`

```python
def rolling_avg(
    values: Sequence[float | None],
    window: int,
) -> list[float | None]
```

Returns a sliding-window average over a sequence of per-game stat values. This is a
pure function — no API call is needed.

**Parameters:**

| Parameter | Type | Description |
|---|---|---|
| `values` | `Sequence[float \| None]` | Per-game stat values in chronological order. Pass `None` for games where the stat is unavailable (DNP, injury, missing data). |
| `window` | `int` | Number of consecutive games in each window. Must be ≥ 1. |

**Returns:** `list[float | None]` — same length as `values`. Each position holds the
mean of the `window` values ending at that position, or `None` in two cases:

| Cause | Description |
|---|---|
| Warm-up | Fewer than `window` games have elapsed (positions 0 through `window - 2`) |
| Propagation | At least one `None` falls within the window |

**Raises:** `ValueError` if `window < 1`.

```python
from fastbreak.metrics import rolling_avg

pts = [22.0, 18.0, 30.0, None, 25.0, 28.0, 15.0, 24.0]
avgs_3 = rolling_avg(pts, window=3)
# [None, None, 23.33, None, None, None, 22.67, 22.33]
#  ^warm ^warm  ^ok   ^DNP  ^prop ^prop  ^ok    ^ok

avgs_5 = rolling_avg(pts, window=5)
# [None, None, None, None, None, None, None, None]
# All None — the DNP at index 3 is inside every 5-game window until index 7
```

**Common pattern — rolling average from a player game log:**

```python
from fastbreak.clients import NBAClient
from fastbreak.metrics import rolling_avg
from fastbreak.players import get_player_game_log

async def main() -> None:
    async with NBAClient() as client:
        games = await get_player_game_log(client, player_id=201939)  # Curry

    # Game log is reverse-chronological; reverse for plotting
    pts = [float(g.pts) for g in reversed(games)]
    avgs = rolling_avg(pts, window=5)

    print(f"{'Game':>5}  {'Pts':>5}  {'5-game avg':>10}")
    for i, (raw, avg) in enumerate(zip(pts, avgs, strict=True), start=1):
        avg_str = f"{avg:.2f}" if avg is not None else "    warm"
        print(f"  {i:>5}  {raw:>5.1f}  {avg_str:>10}")
```

---

#### `ewma`

```python
def ewma(
    values: Sequence[float | None],
    span: int,
) -> list[float | None]
```

Returns an exponentially weighted moving average (EWMA) over a sequence of per-game stat
values. Uses the pandas-compatible smoothing factor `alpha = 2 / (span + 1)`. This is a
pure function — no API call is needed.

Unlike `rolling_avg`, which propagates `None` through windows, `ewma` **skips** `None`
entries: a `None` input produces a `None` output, but the internal running state persists
and the average resumes from its last value on the next valid observation.

**Parameters:**

| Parameter | Type | Description |
|---|---|---|
| `values` | `Sequence[float \| None]` | Per-game stat values in chronological order. Pass `None` for games where the stat is unavailable (DNP, injury, missing data). |
| `span` | `int` | Effective window size (≥ 1). Larger values produce a smoother, slower-reacting average. For the non-missing observations, this matches `pandas.Series(values, dtype="float64").ewm(span=span, adjust=False, ignore_na=True).mean()`. |

**Returns:** `list[float | None]` — same length as `values`. Each position holds the
EWMA up to and including that observation, or `None` in two cases:

| Cause | Description |
|---|---|
| Pre-seed | No valid observation has been seen yet (leading `None` entries) |
| Missing game | The input at this position is `None` (DNP / missing) |

**Raises:** `ValueError` if `span < 1`.

```python
from fastbreak.metrics import ewma

pts = [22.0, 18.0, 30.0, None, 25.0, 28.0, 15.0, 24.0]

# span=3 → alpha=0.5
smoothed = ewma(pts, span=3)
# [22.0, 20.0, 25.0, None, 25.0, 26.5, 20.75, 22.375]
#  ^seed  ^avg  ^avg  ^DNP  ^resume from 25.0

# span=5 → alpha=0.333 — reacts more slowly to new values
smoothed_5 = ewma(pts, span=5)
# [22.0, 20.67, 23.78, None, 24.19, 25.46, 21.97, 22.65]
```

**Comparison with `rolling_avg`:**

| | `rolling_avg` | `ewma` |
|---|---|---|
| **Warm-up period** | Yes — positions 0 to `window - 2` are `None` | No — the first valid observation seeds the average |
| **None handling** | Any `None` in the window → output is `None` | `None` → `None` output, but running state persists |
| **Recency bias** | Equal weight for all values in the window | More weight on recent values (`alpha` controls decay) |
| **Memory** | Only the last `window` games | All prior games, with exponential decay |

**Common pattern — EWMA from a player game log:**

```python
from fastbreak.clients import NBAClient
from fastbreak.metrics import ewma
from fastbreak.players import get_player_game_log

async def main() -> None:
    async with NBAClient() as client:
        games = await get_player_game_log(client, player_id=201939)  # Curry

    # Game log is reverse-chronological; reverse for plotting
    pts = [float(g.pts) for g in reversed(games)]
    smoothed = ewma(pts, span=5)

    print(f"{'Game':>5}  {'Pts':>5}  {'EWMA(5)':>10}")
    for i, (raw, avg) in enumerate(zip(pts, smoothed, strict=True), start=1):
        avg_str = f"{avg:.2f}" if avg is not None else "     --"
        print(f"  {i:>5}  {raw:>5.1f}  {avg_str:>10}")
```

---

---

### Distribution Statistics

These functions describe the **shape** of a player's output over a sample of games.
They all accept `Sequence[float | None]` and skip `None` entries (DNP games are excluded
from the sample rather than counted as zero). Most return `None` when the sequence
contains no non-`None` values; `streak_count` is the exception — it returns `0` rather
than `None` when there is no data.

Unlike `rolling_avg` — which propagates `None` through windows to preserve
temporal structure — distribution functions collect all valid values and compute
aggregate statistics, so a DNP only reduces the sample size.

---

#### `stat_floor`

```python
def stat_floor(values: Sequence[float | None], percentile: float = 10.0) -> float | None
```

Nth percentile of a stat sample — a downside estimate for player projection.

Uses linear interpolation (same algorithm as NumPy's default). The default of 10 follows
common usage in projection systems where the "floor" represents the low-end outcome a
player typically exceeds 90% of the time.

| Parameter | Type | Description |
|---|---|---|
| `values` | `Sequence[float \| None]` | Per-game stat values; pass `None` for DNP games. |
| `percentile` | `float` | Percentile in [0.0, 100.0]. Defaults to 10. |

Returns `None` when `values` contains no non-`None` entries.

**Raises:** `ValueError` when `percentile` is outside [0.0, 100.0].

```python
pts = [22.0, 18.0, None, 30.0, 25.0, 20.0]
stat_floor(pts)          # 10th pct ≈ 18.4  (DNP excluded)
stat_floor(pts, 25.0)    # 25th pct ≈ 19.5
stat_floor(pts, 0.0)     # minimum = 18.0
```

---

#### `stat_ceiling`

```python
def stat_ceiling(values: Sequence[float | None], percentile: float = 90.0) -> float | None
```

Nth percentile of a stat sample — an upside estimate for player projection.

Symmetric counterpart to `stat_floor`. The default of 90 represents the high-end outcome
the player achieves roughly once in every ten games.

| Parameter | Type | Description |
|---|---|---|
| `values` | `Sequence[float \| None]` | Per-game stat values; pass `None` for DNP games. |
| `percentile` | `float` | Percentile in [0.0, 100.0]. Defaults to 90. |

Returns `None` when `values` contains no non-`None` entries.

**Raises:** `ValueError` when `percentile` is outside [0.0, 100.0].

```python
pts = [22.0, 18.0, None, 30.0, 25.0, 20.0]
stat_ceiling(pts)          # 90th pct ≈ 29.6
stat_ceiling(pts, 75.0)    # 75th pct ≈ 26.5
stat_ceiling(pts, 100.0)   # maximum = 30.0
```

---

#### `stat_median`

```python
def stat_median(values: Sequence[float | None]) -> float | None
```

Median of a stat sample — central tendency estimate.

Equivalent to `stat_floor(values, 50.0)` and `stat_ceiling(values, 50.0)`. Provided as a
convenience function since the median is by far the most commonly requested single
percentile.

```python
pts = [22.0, 18.0, None, 30.0, 25.0, 20.0]
stat_median(pts)    # 22.0  (median of [18, 20, 22, 25, 30])
stat_median([10.0, 30.0])  # 20.0  (interpolated midpoint)
```

Returns `None` when `values` contains no non-`None` entries.

---

#### `prop_hit_rate`

```python
def prop_hit_rate(values: Sequence[float | None], line: float) -> float | None
```

Fraction of games where a stat value meets or exceeds a threshold.

Uses `>=` semantics: a value exactly on the line counts as a hit. Returns a fraction in
[0.0, 1.0], not a percentage — multiply by 100 to convert.

`None` values (DNPs) are excluded from **both** the numerator and denominator, so missed
games do not artificially dilute the rate. A player who played 50 games and hit the line
in 30 of them has a rate of `30/50 = 0.60`, regardless of how many games they sat out.

| Parameter | Type | Description |
|---|---|---|
| `values` | `Sequence[float \| None]` | Per-game stat values; pass `None` for DNP games. |
| `line` | `float` | Threshold to compare against (e.g., a prop bet line of 24.5). |

Returns `None` when `values` contains no non-`None` entries.

```python
pts = [22.0, 25.0, 18.0, 30.0, 25.0]
prop_hit_rate(pts, 24.5)    # 3/5 = 0.60  (25, 30, 25 qualify)
prop_hit_rate(pts, 25.0)    # 3/5 = 0.60  (>= 25 counts)
prop_hit_rate(pts, 30.0)    # 1/5 = 0.20
prop_hit_rate(pts, 31.0)    # 0/5 = 0.0

# DNPs excluded:
pts_with_dnp = [22.0, None, 25.0, 18.0, 30.0]
prop_hit_rate(pts_with_dnp, 20.0)   # 3/4 = 0.75  (4 games played, 3 qualify)
```

**Guaranteed properties:**
- Result is always in [0.0, 1.0].
- Non-increasing in `line`: raising the threshold never increases the rate.
- If `line <= min(valid values)`: rate is always 1.0.
- If `line > max(valid values)`: rate is always 0.0.

---

#### `percentile_rank`

```python
def percentile_rank(value: float, reference: Sequence[float | None]) -> float | None
```

The inverse of `stat_floor`. While `stat_floor(reference, p)` answers *"what value corresponds
to the Pth percentile?"*, `percentile_rank(value, reference)` answers *"at what percentile does
this value rank in the reference distribution?"*

`None` entries in `reference` are excluded. Values outside the reference range are clamped to
`[0.0, 100.0]`.

| Parameter | Type | Description |
|-----------|------|-------------|
| `value` | `float` | The query value to rank. |
| `reference` | `Sequence[float \| None]` | Reference distribution; `None` entries excluded. |

**Returns:** Percentile rank in `[0.0, 100.0]`, or `None` if `reference` has no non-`None` entries.

```python
ref = [10.0, 20.0, 30.0]
percentile_rank(20.0, ref)   # 50.0  — median
percentile_rank(10.0, ref)   # 0.0   — minimum
percentile_rank(30.0, ref)   # 100.0 — maximum
percentile_rank(15.0, ref)   # 25.0  — linear interpolation
percentile_rank(35.0, ref)   # 100.0 — clamped (above max)
percentile_rank(5.0,  ref)   # 0.0   — clamped (below min)
```

**Roundtrip property** (holds for unique-value references):
```python
percentile_rank(stat_floor(values, p), values) ≈ p
```

**Guaranteed properties:**
- Result is always in `[0.0, 100.0]`.
- Non-decreasing in `value`: a higher query value yields an equal or higher rank.
- `percentile_rank(min(values), values)` == 0.0.
- `percentile_rank(max(values), values)` == 100.0 (requires at least two distinct values).

---

#### `stat_consistency`

```python
def stat_consistency(values: Sequence[float | None]) -> float | None
```

Measures how variable a player's game-by-game output is, computed as the **population standard
deviation** of the valid (non-`None`) entries. A lower value indicates a more consistent player;
a higher value means boom-or-bust variance.

Uses *population* std dev (divide by *n*) rather than *sample* std dev (divide by *n − 1*)
because the game log is the full sample being analysed, not a statistical sample from a larger
population.

| Parameter | Type | Description |
|-----------|------|-------------|
| `values` | `Sequence[float \| None]` | Per-game stat values; `None` for DNP games. |

**Returns:** Population standard deviation ≥ 0.0, or `None` if no valid entries exist. A single
valid entry returns 0.0.

```python
pts = [20.0, 25.0, 18.0, 30.0, 22.0]
stat_consistency(pts)         # ≈ 4.07  (moderate variance)
stat_consistency([20.0] * 5)  # 0.0    (perfectly consistent)

# DNPs excluded:
stat_consistency([20.0, None, 30.0])   # 10.0  (std dev of [20, 30])
```

**Guaranteed properties:**
- Always ≥ 0.0.
- **Shift-invariant:** adding a constant to every value does not change the spread.
- **Scale property:** multiplying all values by *k* scales consistency by |*k*|.
- A constant sequence always returns 0.0, regardless of length.

**Coefficient of variation (CV):** divide by the mean to get a scale-free spread measure
(`stat_consistency(pts) / (sum(v for v in pts if v is not None) / count)`).

---

#### `streak_count`

```python
def streak_count(values: Sequence[float | None], line: float) -> int
```

Counts the number of consecutive recent games in which a stat met or exceeded `line`, working
backwards from the most recent entry. `None` values (DNP games) are **skipped** — a DNP does
not break an active streak.

Uses `>=` semantics: a value exactly equal to `line` counts as a hit.

| Parameter | Type | Description |
|-----------|------|-------------|
| `values` | `Sequence[float \| None]` | Per-game stats, **chronological order** (oldest first); `None` for DNP. |
| `line` | `float` | The threshold the stat must meet. |

**Returns:** Length of the current streak (≥ 0). Returns 0 if the most recent non-`None` game
missed the line, or if there are no non-`None` games.

```python
pts = [10.0, 25.0, 30.0, 28.0]
streak_count(pts, 20.0)                        # 3  (last three: 28, 30, 25 all ≥ 20)
pts[-1] = 15.0
streak_count(pts, 20.0)                        # 0  (most recent game is 15 < 20 → streak ends)

# DNPs do not break a streak:
streak_count([20.0, 25.0, None, 30.0], 20.0)   # 3  (None skipped; 30, 25, 20 all qualify)
streak_count([10.0, None, 30.0], 20.0)          # 1  (None skipped; 10 misses → streak stops)

# Boundary cases:
streak_count([], 20.0)                          # 0
streak_count([None, None], 20.0)               # 0
streak_count([20.0, 20.0], 20.0)               # 2  (>= semantics)
```

**Guaranteed properties:**
- Always ≥ 0.
- Never exceeds the number of non-`None` games in `values`.
- Non-increasing in `line`: raising the threshold never increases the streak.
- Appending `None` values at the end does not change the streak (DNPs at the end are skipped).

---

#### `rolling_consistency`

```python
def rolling_consistency(
    values: Sequence[float | None],
    window: int,
) -> list[float | None]
```

Returns a list of rolling population standard deviations over a sliding window of size `window`.
The output list has the same length as `values`.

The first `window - 1` entries are always `None` (warm-up period). Once the window is full, each
position holds the population standard deviation of the `window` most recent values. A `None`
anywhere in the window makes that output `None` too — same behavior as `rolling_avg`. If a game
is missing, the variance for that window is unknown, not zero.

| Parameter | Type | Description |
|-----------|------|-------------|
| `values` | `Sequence[float \| None]` | Per-game stats, chronological order (oldest first); `None` for DNP. |
| `window` | `int` | Sliding-window size (≥ 1). |

**Returns:** `list[float | None]` of length `len(values)`. Raises `ValueError` if `window < 1`.

```python
pts = [20.0, 25.0, 30.0, 15.0, 28.0]
rolling_consistency(pts, 3)
# [None, None, 4.08, 6.24, 6.65]
#  ^      ^     ^    ^     ^
#  warm-up      std dev of each 3-game window

# DNP in window propagates to None:
rolling_consistency([20.0, None, 30.0], 2)   # [None, None, None]
rolling_consistency([20.0, 30.0, None], 2)   # [None, 5.0, None]
```

**Guaranteed properties:**
- Always `len(result) == len(values)`.
- First `window - 1` entries are always `None`.
- All non-`None` results are ≥ 0.
- A constant window always returns 0.0.
- A `None` anywhere in a window propagates to `None` at that position.
- Shift-invariant: adding a constant to every value in a window does not change that window's consistency.

---

#### `expected_stat`

```python
def expected_stat(values: Sequence[float | None]) -> float | None
```

Returns a PERT-weighted projection from the player's floor, median, and ceiling:

```
expected = (floor + 4 * median + ceiling) / 6
```

where `floor = stat_floor(values)`, `median = stat_median(values)`, and
`ceiling = stat_ceiling(values)`. The median gets 4× the weight of either extreme, so a
one-off blowup game won't move the number as much as a straight average would.

`None` values (DNP games) are excluded from the sample.

| Parameter | Type | Description |
|-----------|------|-------------|
| `values` | `Sequence[float \| None]` | Per-game stats; `None` for DNP (skipped). |

**Returns:** `float | None`. Returns `None` if there are no non-`None` values.

```python
pts = [10.0, 25.0, 30.0, 28.0, 15.0, None, 20.0]
expected_stat(pts)                      # ≈21.9  (floor=12.5, median=22.5, ceiling=29.0)
expected_stat([25.0, 25.0, 25.0])       # 25.0   (constant: floor = median = ceiling)

# Symmetric distribution: expected == median
expected_stat([10.0, 20.0, 30.0])       # 20.0

expected_stat([])                        # None
expected_stat([None, None])              # None
```

**Guaranteed properties:**
- Always `floor ≤ expected_stat ≤ ceiling` for any non-empty sample.
- For symmetric distributions, `expected_stat == median`.
- Shift-equivariant: adding a constant `k` shifts the result by `k`.
- Scale-equivariant: multiplying every value by `k > 0` scales the result by `k`.

---

#### `hit_rate_last_n`

```python
def hit_rate_last_n(
    values: Sequence[float | None],
    line: float,
    n: int,
) -> float | None
```

Returns the prop hit rate for the last `n` games played, skipping DNPs. Useful for comparing
current form against a full-season rate — the same question `prop_hit_rate` answers, but
scoped to recent games only.

If fewer than `n` non-`None` games are available, all available games are used.

| Parameter | Type | Description |
|-----------|------|-------------|
| `values` | `Sequence[float \| None]` | Per-game stats, chronological order (oldest first); `None` for DNP. |
| `line` | `float` | The threshold the stat must meet (`>=` semantics). |
| `n` | `int` | Number of most recent non-`None` games to consider (≥ 1). |

**Returns:** Hit rate in [0, 1], or `None` if there are no non-`None` games in `values`. Raises
`ValueError` if `n < 1`.

```python
pts = [10.0, 25.0, 30.0, 15.0, 28.0]
hit_rate_last_n(pts, 20.0, 3)    # 2/3 ≈ 0.667  (last 3: 28, 15, 30; 28 and 30 hit)
hit_rate_last_n(pts, 20.0, 1)    # 1.0           (most recent: 28 >= 20)
hit_rate_last_n(pts, 20.0, 10)   # 3/5 = 0.600  (only 5 games available; uses all)

# Comparing recent vs full-season form:
full   = prop_hit_rate(pts, 20.0)          # 0.6  (3 of 5 hit over the season)
recent = hit_rate_last_n(pts, 20.0, 3)     # 0.667 (hotter recently)
```

**Guaranteed properties:**
- Result is always in [0, 1] when not `None`.
- Non-increasing in `line`: raising the threshold never raises the hit rate.
- Appending `None` values at the end does not change the result (DNPs at the end are skipped).
- Oracle: `hit_rate_last_n(values, line, n)` equals `prop_hit_rate(values, line)` when `n` is
  at least the number of non-`None` entries in `values`.

---

### Using distribution stats together

Floor, median, and ceiling form a natural three-point distribution profile. Use them
together to compare player consistency:

```python
from fastbreak.metrics import (
    stat_floor, stat_median, stat_ceiling, prop_hit_rate,
    stat_consistency, streak_count, percentile_rank,
    rolling_consistency, expected_stat, hit_rate_last_n,
)

# A streaky star and a consistent scorer with the same average
streaky    = [38.0, 12.0, 41.0, 14.0, 35.0, 9.0, 44.0, 22.0, 31.0, 18.0]
consistent = [26.0, 22.0, 28.0, 21.0, 27.0, 24.0, 25.0, 23.0, 26.0, 22.0]

for label, pts in [("Streaky", streaky), ("Consistent", consistent)]:
    print(
        f"{label}: avg={sum(pts)/len(pts):.1f}  "
        f"floor={stat_floor(pts):.1f}  median={stat_median(pts):.1f}  "
        f"ceiling={stat_ceiling(pts):.1f}  hit(20+)={prop_hit_rate(pts, 20.0):.0%}  "
        f"consistency={stat_consistency(pts):.2f}  "
        f"streak(20+)={streak_count(pts, 20.0)}  "
        f"rank(25pts)={percentile_rank(25.0, pts):.1f}th  "
        f"expected={expected_stat(pts):.1f}  "
        f"last5={hit_rate_last_n(pts, 20.0, 5):.0%}"
    )
# Streaky:    avg=26.4  floor=11.7  median=26.5  ceiling=41.3  hit(20+)=60%   consistency=12.27  streak(20+)=0  rank(25pts)=48.1th  expected=26.5  last5=60%
# Consistent: avg=24.4  floor=21.9  median=24.5  ceiling=27.1  hit(20+)=100%  consistency=2.24   streak(20+)=10 rank(25pts)=55.6th  expected=24.5  last5=100%
```

The ordering invariant `floor ≤ median ≤ ceiling` always holds for any non-empty sample. Note
that `stat_consistency` confirms what the floor/ceiling spread already implies: the consistent
scorer has a much tighter standard deviation (~2 pts) versus the streaky star (~12 pts).

Use `percentile_rank` to contextualise any individual game within the full season distribution,
`streak_count` and `hit_rate_last_n` to identify players in current form for upcoming games, and
`expected_stat` to produce a stable PERT projection that dampens outliers. `rolling_consistency`
adds a temporal dimension — tracking how a player's variance changes week-to-week can reveal
fatigue, role changes, or a genuine hot streak.

---

## Practical Examples

### Example 1: TS% for a game log, compared to league average

This example uses hardcoded numbers to show the pure-computation workflow.

```python
from fastbreak.metrics import true_shooting, relative_ts, LeagueAverages

# Approximate 2024-25 league averages
lg = LeagueAverages(
    lg_pts=113.7,
    lg_fga=88.2,
    lg_fta=21.5,
    lg_ftm=17.0,
    lg_oreb=10.3,
    lg_treb=43.5,
    lg_ast=26.1,
    lg_fgm=42.1,
    lg_fg3m=13.1,
    lg_tov=13.3,
    lg_pf=19.2,
)

# Hypothetical game log: (pts, fga, fta)
game_log = [
    (32, 22, 8),
    (18, 14, 4),
    (27, 17, 6),
    (15, 16, 2),
    (40, 25, 10),
]

print(f"League TS%: {lg.ts:.3f}")
print()

for i, (pts, fga, fta) in enumerate(game_log, 1):
    ts = true_shooting(pts=pts, fga=fga, fta=fta)
    rel = relative_ts(ts, lg)
    if ts is not None and rel is not None:
        direction = "above" if rel > 0 else "below"
        print(f"Game {i}: TS%={ts:.3f}  ({rel:+.3f} {direction} league avg)")
    else:
        print(f"Game {i}: no shot attempts")
```

### Example 2: Full PER pipeline with live API data

PER is a two-step calculation:

1. Call `pace_adjusted_per()` for **every** qualifying player in the league to produce an
   aPER value per player.
2. Compute the minutes-weighted league-average aPER (`lg_aper`), then call `per()` to
   normalise each player's aPER to the 15.0 baseline.

Using a single player's own games to compute `lg_aper` is incorrect — it normalises the
player against themselves, pushing every game's PER toward 15 regardless of quality.
`lg_aper` must be derived from **all players** for the result to be meaningful.

The example below shows step 1 (computing aPER) for one player. Step 2 requires
repeating the same loop across all qualified players.

```python
import asyncio
from fastbreak.clients import NBAClient
from fastbreak.teams import get_league_averages
from fastbreak.players import get_player_game_log
from fastbreak.metrics import pace_adjusted_per, per

PLAYER_ID = 2544   # LeBron James
TEAM_PACE = 100.0  # replace with actual team pace from box scores

async def main():
    async with NBAClient() as client:
        lg = await get_league_averages(client)
        log = await get_player_game_log(client, player_id=PLAYER_ID)

    apers: list[tuple[float, float]] = []

    for game in log:
        # For aPER we also need team_ast, team_fgm, team_pace.
        # Here we use league-average proxies; in production, join against team box scores.
        aper = pace_adjusted_per(
            fgm=game.fgm,
            fga=game.fga,
            fg3m=game.fg3m,
            ftm=game.ftm,
            fta=game.fta,
            oreb=game.oreb,
            treb=game.reb,
            ast=game.ast,
            stl=game.stl,
            blk=game.blk,
            pf=game.pf,
            tov=game.tov,
            mp=game.minutes,
            team_ast=26.0,    # league-average proxy; use actual team box score data
            team_fgm=42.0,    # league-average proxy
            team_pace=TEAM_PACE,
            lg=lg,
        )
        if aper is not None and game.minutes is not None and game.minutes > 0:
            apers.append((aper, game.minutes))

    if not apers:
        print("Insufficient data")
        return

    # Step 1 complete: print aPER per game.
    print(f"{'Min':>4}  {'aPER':>7}")
    for aper_val, minutes in apers[:5]:
        print(f"  {minutes:>4.0f}  {aper_val:>7.3f}")

    # Step 2: to convert aPER → PER you need lg_aper computed across all players:
    #
    #   all_apers = [(aper_val, minutes), ...]   # repeat above for every player
    #   total_mp  = sum(m for _, m in all_apers)
    #   lg_aper   = sum(a * m for a, m in all_apers) / total_mp
    #
    #   player_per = per(aper=aper_val, lg_aper=lg_aper)

asyncio.run(main())
```

### Example 3: Team net rating from a game's box score

This example shows how to compute ORTG, DRTG, and net rating from a single game's
counting stats, using only hardcoded numbers.

```python
from fastbreak.metrics import ortg, drtg, net_rtg

# Team's box score
team_pts  = 115
team_fga  = 87
team_oreb = 8
team_tov  = 12
team_fta  = 24

# Opponent's box score (needed for the opponent possession estimate in drtg)
opp_pts  = 108
opp_fga  = 85
opp_oreb = 9
opp_tov  = 14
opp_fta  = 20

off_rtg = ortg(pts=team_pts, fga=team_fga, oreb=team_oreb, tov=team_tov, fta=team_fta)
def_rtg = drtg(opp_pts=opp_pts, opp_fga=opp_fga, opp_oreb=opp_oreb, opp_tov=opp_tov, opp_fta=opp_fta)
net     = net_rtg(off_rtg, def_rtg)

if off_rtg and def_rtg and net:
    print(f"ORTG: {off_rtg:.1f}")
    print(f"DRTG: {def_rtg:.1f}")
    print(f"Net:  {net:+.1f}")
```

### Example 4: Double-double and triple-double detection across a season

```python
import asyncio
from fastbreak.clients import NBAClient
from fastbreak.players import get_player_game_log
from fastbreak.metrics import is_double_double, is_triple_double

PLAYER_ID = 203999  # Nikola Jokic

async def main():
    async with NBAClient() as client:
        log = await get_player_game_log(client, player_id=PLAYER_ID)

    double_doubles = 0
    triple_doubles = 0
    games_played   = 0

    for game in log:
        # game_id[:3] == "002" filters out All-Star games
        if game.game_id[:3] != "002":
            continue

        games_played += 1
        pts, reb, ast, stl, blk = (
            game.pts, game.reb, game.ast, game.stl, game.blk
        )

        if is_triple_double(pts=pts, reb=reb, ast=ast, stl=stl, blk=blk):
            triple_doubles += 1
        elif is_double_double(pts=pts, reb=reb, ast=ast, stl=stl, blk=blk):
            double_doubles += 1

    print(f"Games played:   {games_played}")
    print(f"Double-doubles: {double_doubles}")
    print(f"Triple-doubles: {triple_doubles}")
    print(f"DD/TD rate:     {(double_doubles + triple_doubles) / games_played:.1%}")

asyncio.run(main())
```

### Example 5: Distribution profile from a player game log

This example fetches a player's game log and computes their scoring distribution,
then evaluates several prop-bet lines against the historical hit rate.

```python
import asyncio
from fastbreak.clients import NBAClient
from fastbreak.players import get_player_game_log
from fastbreak.metrics import stat_floor, stat_median, stat_ceiling, prop_hit_rate

PLAYER_ID = 201939  # Stephen Curry

async def main():
    async with NBAClient() as client:
        log = await get_player_game_log(client, player_id=PLAYER_ID)

    # Filter to regular-season games only
    regular = [g for g in log if g.game_id[:3] == "002"]

    pts: list[float | None] = [float(g.pts) if g.pts is not None else None for g in regular]

    floor   = stat_floor(pts)    # 10th pct: conservative downside
    median  = stat_median(pts)   # 50th pct: typical output
    ceiling = stat_ceiling(pts)  # 90th pct: high-end upside

    print(f"Floor (10th):   {floor:.1f}")
    print(f"Median (50th):  {median:.1f}")
    print(f"Ceiling (90th): {ceiling:.1f}")
    print()

    # Prop bet hit rates — what fraction of games did he reach each threshold?
    for line in [19.5, 24.5, 29.5, 34.5]:
        rate = prop_hit_rate(pts, line)
        print(f"  >= {line}: {rate:.0%}" if rate is not None else f"  >= {line}: n/a")

asyncio.run(main())
```

---

## Adding New Metrics

Because all functions are pure Python with no hidden state, adding a new metric requires
only adding a function to `src/fastbreak/metrics.py`. Follow the existing conventions:

1. Accept raw `float` inputs, not Pydantic models.
2. Return `float | None`, with `None` reserved for zero-denominator cases.
3. Document the formula in the docstring.
4. Use a guard at the top of the function (`if denominator == 0: return None`) rather
   than relying on Python's `ZeroDivisionError`.
