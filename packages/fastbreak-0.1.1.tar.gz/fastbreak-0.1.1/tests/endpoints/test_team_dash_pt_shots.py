import pytest
from pydantic import ValidationError

from fastbreak.endpoints import TeamDashPtShots
from fastbreak.models import TeamDashPtShotsResponse
from fastbreak.seasons import get_season_from_date


class TestTeamDashPtShots:
    """Tests for TeamDashPtShots endpoint."""

    def test_init_with_defaults(self):
        """TeamDashPtShots uses sensible defaults."""
        endpoint = TeamDashPtShots(team_id=1610612747)

        assert endpoint.team_id == 1610612747
        assert endpoint.league_id == "00"
        assert endpoint.season == get_season_from_date()
        assert endpoint.season_type == "Regular Season"
        assert endpoint.per_mode == "PerGame"
        assert endpoint.month == 0
        assert endpoint.opponent_team_id == 0
        assert endpoint.period == 0
        assert endpoint.last_n_games == 0

    def test_init_with_team_id(self):
        """TeamDashPtShots accepts team_id."""
        endpoint = TeamDashPtShots(team_id=1610612743)

        assert endpoint.team_id == 1610612743

    def test_init_with_custom_season(self):
        """TeamDashPtShots accepts custom season."""
        endpoint = TeamDashPtShots(team_id=1610612747, season="2023-24")

        assert endpoint.season == "2023-24"

    def test_init_with_custom_season_type(self):
        """TeamDashPtShots accepts custom season_type."""
        endpoint = TeamDashPtShots(team_id=1610612747, season_type="Playoffs")

        assert endpoint.season_type == "Playoffs"

    def test_init_with_custom_per_mode(self):
        """TeamDashPtShots accepts custom per_mode."""
        endpoint = TeamDashPtShots(team_id=1610612747, per_mode="Totals")

        assert endpoint.per_mode == "Totals"

    def test_init_with_last_n_games(self):
        """TeamDashPtShots accepts last_n_games filter."""
        endpoint = TeamDashPtShots(team_id=1610612747, last_n_games=10)

        assert endpoint.last_n_games == 10

    def test_init_with_period(self):
        """TeamDashPtShots accepts period filter."""
        endpoint = TeamDashPtShots(team_id=1610612747, period=4)

        assert endpoint.period == 4

    def test_init_with_all_optional_params(self):
        """TeamDashPtShots accepts all optional parameters."""
        endpoint = TeamDashPtShots(
            team_id=1610612747,
            outcome="W",
            location="Home",
            season_segment="Post All-Star",
            date_from="01/01/2024",
            date_to="03/31/2024",
            vs_conference="West",
            vs_division="Pacific",
            game_segment="First Half",
        )

        assert endpoint.outcome == "W"
        assert endpoint.location == "Home"
        assert endpoint.season_segment == "Post All-Star"
        assert endpoint.date_from == "01/01/2024"
        assert endpoint.date_to == "03/31/2024"
        assert endpoint.vs_conference == "West"
        assert endpoint.vs_division == "Pacific"
        assert endpoint.game_segment == "First Half"

    def test_params_returns_correct_dict(self):
        """params() returns correctly formatted parameters."""
        endpoint = TeamDashPtShots(
            team_id=1610612743,
            season="2023-24",
            last_n_games=10,
        )

        params = endpoint.params()

        assert params["TeamID"] == "1610612743"
        assert params["LeagueID"] == "00"
        assert params["Season"] == "2023-24"
        assert params["SeasonType"] == "Regular Season"
        assert params["PerMode"] == "PerGame"
        assert params["LastNGames"] == "10"
        assert params["Month"] == "0"
        assert params["OpponentTeamID"] == "0"
        assert params["Period"] == "0"

    def test_params_includes_optional_params(self):
        """params() includes optional parameters when set."""
        endpoint = TeamDashPtShots(
            team_id=1610612747,
            outcome="W",
            location="Home",
            game_segment="First Half",
        )

        params = endpoint.params()

        assert params["Outcome"] == "W"
        assert params["Location"] == "Home"
        assert params["GameSegment"] == "First Half"

    def test_params_excludes_unset_optional_filters(self):
        """params() omits optional filter keys when not set."""
        endpoint = TeamDashPtShots(team_id=1610612747)

        params = endpoint.params()

        assert "DateFrom" not in params
        assert "DateTo" not in params
        assert "Outcome" not in params
        assert "Location" not in params
        assert "GameSegment" not in params

    def test_params_excludes_none_values(self):
        """params() excludes None optional parameters."""
        endpoint = TeamDashPtShots(team_id=1610612747)

        params = endpoint.params()

        assert "SeasonSegment" not in params
        assert "VsConference" not in params
        assert "VsDivision" not in params

    def test_path_is_correct(self):
        """TeamDashPtShots has correct API path."""
        endpoint = TeamDashPtShots(team_id=1610612747)

        assert endpoint.path == "teamdashptshots"

    def test_response_model_is_correct(self):
        """TeamDashPtShots uses TeamDashPtShotsResponse model."""
        endpoint = TeamDashPtShots(team_id=1610612747)

        assert endpoint.response_model is TeamDashPtShotsResponse

    def test_endpoint_is_frozen(self):
        """TeamDashPtShots is immutable (frozen dataclass)."""
        endpoint = TeamDashPtShots(team_id=1610612747)

        with pytest.raises((AttributeError, ValidationError)):
            endpoint.season = "2023-24"  # type: ignore[misc]
