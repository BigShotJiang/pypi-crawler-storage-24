# Model Layer Guide

이 디렉토리에는 DynamoDB 테이블과 매핑되는 데이터 모델을 정의합니다.

## 모델 작성 규칙

### 기본 구조

```python
import time
import uuid
import api
from pydantic import fields, BaseModel
from typing import Optional, Literal
from sawsi.model.base import DynamoModel, sync


@sync
class MyModel(DynamoModel):
    __dynamo__ = api.dynamo
    _table = 'my_table'
    _indexes = [
        ('partition_key', 'sort_key'),
    ]
    
    id: str = fields.Field(default_factory=lambda: str(uuid.uuid4()))
    crt: float = fields.Field(default_factory=time.time)
    name: str
    status: Optional[Literal["active", "inactive"]] = None
```

### 필수 요소

- `@sync` 데코레이터: 빌드 시 테이블/인덱스 자동 생성에 등록됨
- `__dynamo__ = api.dynamo`: DynamoDB 연결 객체
- `_table`: DynamoDB 테이블 이름
- `_indexes`: GSI 목록. `(partition_key, sort_key)` 튜플의 리스트

### 선택 요소

- `__create_default_index__ = True`: `u_b`/`crt` 기본 인덱스 생성 (전체 데이터 시간순 조회용)
- `ptn` 필드: 파티션 구분용 문자열 (같은 테이블에 여러 모델 타입 저장 시)
- `id` 필드: UUID4 랜덤 생성 값으로 기본 제공되기 때문에 오버라이딩이 필요할때만 재선언 
- `crt` 필드: 생성일시 (초단위) 값으로 기본 제공되기 때문에 오버라이딩 필요할때만 재선언
### 중첩 모델

DynamoDB에 JSON으로 저장되는 중첩 객체는 `pydantic.BaseModel`을 상속합니다 (`DynamoModel` 아님).

```python
class Address(BaseModel):
    street: str
    city: str
    country: str

@sync
class User(DynamoModel):
    address: Address  # 자동 직렬화/역직렬화
```

### 주요 메서드

| 메서드 | 설명                   |
|--------|----------------------|
| `put()` | 아이템 생성               |
| `update()` | 변경된 필드만 업데이트         |
| `delete()` | 아이템 삭제               |
| `get(id)` | ID로 조회               |
| `batch_get(id_list)` | 여러 아이템 일괄 조회         |
| `query(pk_field, pk_value, ...)` | 인덱스 쿼리 (리스트 반환)      |
| `generate(pk_field, pk_value, ...)` | 인덱스 쿼리 (제너레이터 반환)    |
| `scan()` | 풀 스캔 (사용하는걸 추천하지 않음) |
| `model_dump()` | 딕셔너리 변환              |

### view 메서드 패턴

클라이언트에 반환할 데이터를 필터링하는 `view()` 메서드를 정의하세요.
어드민에서 사용하는 경우는 admin_view() 메서드를 정의해서 따로 사용하는걸 추천합니다.

```python
def view(self) -> dict:
    return {
        'name': self.name,
        'age': self.age
    }
```

### 새 모델 추가 후 할 일

`build_keeper.py`의 `sync_all_models` 호출에 해당 모델의 모듈 경로가 포함되어 있는지 확인하세요.
