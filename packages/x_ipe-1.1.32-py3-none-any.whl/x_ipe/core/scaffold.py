"""Scaffold module for X-IPE project structure creation."""
from pathlib import Path
from typing import List, Tuple, Optional
import shutil
import os
import json


class ScaffoldManager:
    """Manages project structure creation."""
    
    DOCS_STRUCTURE = [
        "x-ipe-docs/requirements",
        "x-ipe-docs/planning",
        "x-ipe-docs/ideas",
        "x-ipe-docs/config",
        "x-ipe-docs/themes",
        "x-ipe-docs/knowledge-base",
        "x-ipe-docs/knowledge-base/.intake",
    ]
    
    GITIGNORE_ENTRIES: list = []  # No X-IPE specific gitignore entries needed
    
    def __init__(self, project_root: Path, dry_run: bool = False, force: bool = False):
        """Initialize ScaffoldManager.
        
        Args:
            project_root: Path to the project root directory.
            dry_run: If True, don't make any changes, just track what would be done.
            force: If True, overwrite existing files/folders.
        """
        self.project_root = Path(project_root).resolve()
        self.dry_run = dry_run
        self.force = force
        self.created: List[Path] = []
        self.skipped: List[Path] = []
    
    def create_docs_structure(self) -> None:
        """Create x-ipe-docs/ folder with subfolders."""
        for folder in self.DOCS_STRUCTURE:
            path = self.project_root / folder
            if path.exists():
                if not self.force:
                    self.skipped.append(path)
                    continue
            if not self.dry_run:
                path.mkdir(parents=True, exist_ok=True)
            self.created.append(path)
    
    def create_runtime_folder(self) -> None:
        """Create .x-ipe/ folder for runtime data."""
        path = self.project_root / ".x-ipe"
        if path.exists():
            if not self.force:
                self.skipped.append(path)
                return
        if not self.dry_run:
            path.mkdir(parents=True, exist_ok=True)
        self.created.append(path)
    
    def _get_resource_path(self, resource_name: str) -> Optional[Path]:
        """Get path to a bundled resource.
        
        Args:
            resource_name: Name of resource (e.g., 'skills', 'copilot-instructions.md')
            
        Returns:
            Path to resource or None if not found.
        """
        # Try importlib.resources first (installed package)
        try:
            from importlib import resources
            resource_ref = resources.files("x_ipe") / "resources" / resource_name
            if resource_ref.is_file() or resource_ref.is_dir():
                return Path(str(resource_ref))
        except (ImportError, TypeError, AttributeError):
            pass
        
        # Fall back to src layout for development
        dev_path = Path(__file__).parent.parent / "resources" / resource_name
        if dev_path.exists():
            return dev_path
        
        return None
    
    def copy_skills(self, skills_source: Optional[Path] = None, cli_name: Optional[str] = None) -> None:
        """Copy skills from source to CLI-specific skills folder.
        
        Args:
            skills_source: Path to skills source directory. If None, uses package skills.
            cli_name: CLI adapter name. Determines target folder (e.g. .opencode/skills/).
        """
        # Resolve target from adapter config
        skills_folder = ".github/skills"
        adapter = None
        if cli_name:
            try:
                from x_ipe.services.cli_adapter_service import CLIAdapterService
                adapter = CLIAdapterService().get_adapter(cli_name)
                if adapter:
                    skills_folder = adapter.skills_folder.rstrip('/')
            except Exception:
                pass
        
        target = self.project_root / skills_folder
        
        if skills_source is None:
            skills_source = self._get_resource_path("skills")
        
        if skills_source is None or not skills_source.exists():
            # No skills to copy
            return
        
        if target.exists():
            if not self.force:
                self.skipped.append(target)
                return
        
        if not self.dry_run:
            # Create parent directories
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists() and self.force:
                shutil.rmtree(target)
            
            # Use SkillTranslator for non-copilot CLIs
            if adapter and adapter.name != 'copilot':
                from x_ipe.services.skill_translator import SkillTranslator
                translator = SkillTranslator()
                translator.translate_skills(skills_source, target, adapter)
            else:
                shutil.copytree(skills_source, target, dirs_exist_ok=True)
        self.created.append(target)
    
    def copy_copilot_instructions(self, cli_name: Optional[str] = None, language: str = "en", dao_intercept: bool = False) -> None:
        """Copy or merge instructions file to CLI-specific location.
        
        Args:
            cli_name: CLI adapter name. Determines target path (e.g. .opencode/instructions.md).
            language: Language code for bilingual template extraction ('en' or 'zh').
            dao_intercept: If True, use DAO-first instruction variant; if False, use no-DAO variant.
        """
        # For non-copilot CLIs, use SkillTranslator to generate instructions
        adapter = None
        if cli_name:
            try:
                from x_ipe.services.cli_adapter_service import CLIAdapterService
                adapter = CLIAdapterService().get_adapter(cli_name)
            except Exception:
                pass
        
        if adapter and adapter.name != 'copilot':
            target = self.project_root / adapter.instructions_file
            if target.exists():
                if not self.force:
                    self.skipped.append(target)
                    return
            if not self.dry_run:
                from x_ipe.services.skill_translator import SkillTranslator
                translator = SkillTranslator()
                translator.generate_instructions(adapter, self.project_root, dao_intercept=dao_intercept)
            self.created.append(target)
            return
        
        # Default copilot behavior — load language-specific instructions file
        # Select DAO or no-DAO variant based on dao_intercept setting
        if dao_intercept:
            resource_name = f"copilot-instructions-{language}.md"
        else:
            resource_name = f"copilot-instructions-{language}-no-dao.md"
        source = self._get_resource_path(resource_name)
        if source is None or not source.exists():
            # Fallback: try the DAO variant for the language, then EN
            source = self._get_resource_path(f"copilot-instructions-{language}.md")
        if source is None or not source.exists():
            source = self._get_resource_path("copilot-instructions-en.md")
        if source is None or not source.exists():
            return
        
        target = self.project_root / ".github" / "copilot-instructions.md"
        
        xipe_content = source.read_text()
        
        if target.exists():
            if not self.force:
                # Merge: append X-IPE instructions if not already present
                if not self.dry_run:
                    existing_content = target.read_text()
                    
                    # Check if X-IPE section already exists
                    if "# Copilot Instructions" in existing_content and "## Before You Start" in existing_content:
                        self.skipped.append(target)
                        return
                    
                    # Merge by appending
                    merged = existing_content.rstrip() + "\n\n" + xipe_content
                    target.write_text(merged)
                self.created.append(target)
                return
        
        if not self.dry_run:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(xipe_content)
        self.created.append(target)
    
    def copy_mcp_config(self) -> None:
        """Copy mcp-config.json to .github/copilot/."""
        source = self._get_resource_path("copilot")
        if source is None or not source.exists():
            return
        
        source_file = source / "mcp-config.json"
        if not source_file.exists():
            return
        
        target = self.project_root / ".github" / "copilot" / "mcp-config.json"
        
        if target.exists():
            if not self.force:
                self.skipped.append(target)
                return
        
        if not self.dry_run:
            target.parent.mkdir(parents=True, exist_ok=True)
            # Resolve template variables
            content = source_file.read_text()
            resolved = content.replace(
                "${workspaceFolder}", str(self.project_root)
            )
            target.write_text(resolved)
            shutil.copystat(source_file, target)
        self.created.append(target)
    
    def get_project_mcp_servers(self) -> dict:
        """Get MCP servers from project's .github/copilot/mcp-config.json.
        
        Returns:
            Dict of server_name -> server_config, or empty dict if not found.
        """
        project_mcp = self.project_root / ".github" / "copilot" / "mcp-config.json"
        if not project_mcp.exists():
            return {}
        
        try:
            project_config = json.loads(project_mcp.read_text())
            return project_config.get("mcpServers", {})
        except (json.JSONDecodeError, IOError):
            return {}
    
    def merge_mcp_config(
        self,
        servers_to_merge: Optional[List[str]] = None,
        target_path: Optional[Path] = None,
        source_servers: Optional[dict] = None,
        mcp_format: str = 'global'
    ) -> None:
        """Merge MCP servers into target config.
        
        Args:
            servers_to_merge: List of server names to merge. If None, merges all.
            target_path: Path to target mcp-config.json. Defaults to {project_root}/.copilot/mcp-config.json.
            source_servers: Dict of server configs. If None, reads from .github/copilot/mcp-config.json.
            mcp_format: Config format - 'global'/'project' use mcpServers, 'nested' uses mcp key.
        """
        project_servers = source_servers if source_servers is not None else self.get_project_mcp_servers()
        if not project_servers:
            return
        
        # Filter to requested servers if specified
        if servers_to_merge is not None:
            project_servers = {k: v for k, v in project_servers.items() if k in servers_to_merge}
            if not project_servers:
                return
        
        # Target: configurable or default to {project_root}/.copilot/mcp-config.json
        if target_path is None:
            global_copilot_dir = self.project_root / ".copilot"
            global_mcp = global_copilot_dir / "mcp-config.json"
        else:
            global_mcp = Path(target_path)
            global_copilot_dir = global_mcp.parent
        
        if self.dry_run:
            self.created.append(global_mcp)
            return
        
        # Determine config key based on format
        use_nested = (mcp_format == 'nested')
        config_key = "mcp" if use_nested else "mcpServers"
        
        # Load or create global config
        global_config = {config_key: {}}
        if use_nested and not global_mcp.exists():
            global_config["$schema"] = "https://opencode.ai/config.json"
        if global_mcp.exists():
            try:
                global_config = json.loads(global_mcp.read_text())
                if config_key not in global_config:
                    global_config[config_key] = {}
            except (json.JSONDecodeError, IOError):
                global_config = {config_key: {}}
                if use_nested:
                    global_config["$schema"] = "https://opencode.ai/config.json"
        
        # Transform server configs for nested (opencode) format
        if use_nested:
            transformed = {}
            for name, cfg in project_servers.items():
                entry = {
                    "type": cfg.get("type", "local"),
                    "enabled": True,
                }
                cmd = cfg.get("command", "")
                args = cfg.get("args", [])
                if cmd or args:
                    entry["command"] = [cmd] + args if args else [cmd]
                if cfg.get("env"):
                    entry["environment"] = cfg["env"]
                transformed[name] = entry
            project_servers = transformed
        
        # Merge: add project servers to config
        merged_count = 0
        skipped_count = 0
        for server_name, server_config in project_servers.items():
            if server_name in global_config[config_key]:
                if self.force:
                    global_config[config_key][server_name] = server_config
                    merged_count += 1
                else:
                    skipped_count += 1
            else:
                global_config[config_key][server_name] = server_config
                merged_count += 1
        
        if merged_count > 0:
            global_copilot_dir.mkdir(parents=True, exist_ok=True)
            global_mcp.write_text(json.dumps(global_config, indent=2, ensure_ascii=False) + "\n")
            self.created.append(global_mcp)
        elif skipped_count > 0:
            self.skipped.append(global_mcp)
    
    def copy_config_files(self) -> None:
        """Copy config files (copilot-prompt.json, tools.json, .env.example) to x-ipe-docs/config/."""
        config_source = self._get_resource_path("config")
        if config_source is None or not config_source.exists():
            return
        
        target_dir = self.project_root / "x-ipe-docs" / "config"
        
        # Copy each config file individually (don't overwrite existing)
        config_files = ["copilot-prompt.json", "tools.json", "workflow-template.json", "cli-adapters.yaml", "knowledgebase-config.json", ".env.example"]
        for filename in config_files:
            source_file = config_source / filename
            target_file = target_dir / filename
            
            if not source_file.exists():
                continue
                
            if target_file.exists():
                if not self.force:
                    self.skipped.append(target_file)
                    continue
            
            if not self.dry_run:
                target_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_file, target_file)
            self.created.append(target_file)
    
    def copy_planning_templates(self) -> None:
        """Copy planning templates (features.md, task-board.md) to x-ipe-docs/planning/."""
        planning_source = self._get_resource_path("planning")
        if planning_source is None or not planning_source.exists():
            return
        
        target_dir = self.project_root / "x-ipe-docs" / "planning"
        
        # Copy each planning file individually (don't overwrite existing)
        planning_files = ["features.md", "task-board.md"]
        for filename in planning_files:
            source_file = planning_source / filename
            target_file = target_dir / filename
            
            if not source_file.exists():
                continue
                
            if target_file.exists():
                if not self.force:
                    self.skipped.append(target_file)
                    continue
            
            if not self.dry_run:
                target_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_file, target_file)
            self.created.append(target_file)
    
    def copy_themes(self) -> None:
        """Copy default theme to x-ipe-docs/themes/."""
        themes_source = self._get_resource_path("themes")
        if themes_source is None or not themes_source.exists():
            return
        
        target_dir = self.project_root / "x-ipe-docs" / "themes"
        
        # Copy entire theme-default folder
        theme_source = themes_source / "theme-default"
        theme_target = target_dir / "theme-default"
        
        if not theme_source.exists():
            return
        
        if theme_target.exists():
            if not self.force:
                self.skipped.append(theme_target)
                return
        
        if not self.dry_run:
            target_dir.mkdir(parents=True, exist_ok=True)
            if theme_target.exists() and self.force:
                shutil.rmtree(theme_target)
            shutil.copytree(theme_source, theme_target, dirs_exist_ok=True)
        self.created.append(theme_target)
    
    def create_config_file(self, config_content: Optional[str] = None, cli_name: Optional[str] = None, language: str = "en") -> None:
        """Create .x-ipe.yaml with defaults.
        
        Args:
            config_content: Optional custom config content.
            cli_name: Optional CLI adapter name to store in config (FEATURE-027-B).
            language: Language code to store in config (FEATURE-028-B).
        """
        path = self.project_root / ".x-ipe.yaml"
        
        if path.exists():
            if not self.force:
                self.skipped.append(path)
                return
        
        default_content = """# X-IPE Configuration
version: 1

paths:
  project_root: "."
  x_ipe_app: "."
  docs: "x-ipe-docs"
  skills: ".github/skills"
  runtime: ".x-ipe"

server:
  host: "127.0.0.1"
  port: 5858
  debug: false

git:
  strategy: "main-branch-only"

console:
  auto_execute_prompt: false
"""
        
        content = config_content or default_content
        if cli_name and not config_content:
            # Resolve skills folder from CLI adapter config
            skills_folder = '.github/skills'
            try:
                from x_ipe.services.cli_adapter_service import CLIAdapterService
                adapter = CLIAdapterService().get_adapter(cli_name)
                if adapter:
                    skills_folder = adapter.skills_folder.rstrip('/')
            except Exception:
                pass
            content = content.replace('skills: ".github/skills"', f'skills: "{skills_folder}"')
            content = content.rstrip() + f'\n\ncli: "{cli_name}"\n'
        
        if language and not config_content:
            content = content.rstrip() + f'\nlanguage: "{language}"\n'
        
        if not self.dry_run:
            path.write_text(content)
        self.created.append(path)
    
    def update_gitignore(self) -> None:
        """Add X-IPE patterns to .gitignore."""
        gitignore_path = self.project_root / ".gitignore"
        
        if not gitignore_path.exists():
            if not self.dry_run:
                gitignore_path.write_text("\n".join(self.GITIGNORE_ENTRIES))
            self.created.append(gitignore_path)
            return
        
        # Read existing content
        if self.dry_run:
            self.skipped.append(gitignore_path)
            return
            
        content = gitignore_path.read_text()
        
        # Check if X-IPE entries already exist
        if ".x-ipe/" in content:
            self.skipped.append(gitignore_path)
            return
        
        # Append X-IPE entries
        if self.GITIGNORE_ENTRIES:
            if not content.endswith("\n"):
                content += "\n"
            content += "\n".join(self.GITIGNORE_ENTRIES)
            gitignore_path.write_text(content)
            self.created.append(gitignore_path)
    
    def scaffold_all(self) -> Tuple[List[Path], List[Path]]:
        """Run all scaffolding operations.
        
        Returns:
            Tuple of (created_paths, skipped_paths).
        """
        self.create_docs_structure()
        self.copy_skills()
        self.copy_copilot_instructions()
        self.copy_mcp_config()
        self.copy_config_files()
        self.copy_planning_templates()
        self.copy_themes()
        self.create_config_file()
        self.merge_mcp_config()
        return self.get_summary()
    
    def get_summary(self) -> Tuple[List[Path], List[Path]]:
        """Return (created, skipped) paths."""
        return self.created, self.skipped
