"""X-IPE package defaults."""
