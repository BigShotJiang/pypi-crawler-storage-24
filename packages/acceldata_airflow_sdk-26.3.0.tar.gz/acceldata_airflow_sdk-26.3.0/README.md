# ACCELDATA-AIRFLOW-SDK

Acceldata Airflow SDK provides support for observability of airflow dags in [ADOC](https://docs.acceldata.io/documentation/adoc-architecture-an-overview).

Refer to the [documentation](https://docs.acceldata.io/documentation/airflow) for details.
---

## Changelog

<!-- BEGIN CHANGELOG -->

Version Log
========================

26.3.0 (10/03/2026)
------------------
- Released **acceldata_airflow_sdk** version 26.3.0.

<!-- END CHANGELOG -->

