<!-- PROJECT_CONFIG
runtime: python-uv
test_command: pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-fixtures
section-02-listener-map
section-03-trigger-finding
section-04-recursive-tracing
section-05-failure-detection
section-06-top-level-and-registration
section-07-verification
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-fixtures | - | all | Yes |
| section-02-listener-map | 01 | 04 | Yes |
| section-03-trigger-finding | 01 | 04 | Yes |
| section-04-recursive-tracing | 02, 03 | 05, 06 | No |
| section-05-failure-detection | 04 | 06 | No |
| section-06-top-level-and-registration | 05 | 07 | No |
| section-07-verification | 06 | - | No |

## Execution Order

1. section-01-fixtures (no dependencies)
2. section-02-listener-map, section-03-trigger-finding (parallel after 01)
3. section-04-recursive-tracing (after 02 AND 03)
4. section-05-failure-detection (after 04)
5. section-06-top-level-and-registration (after 05)
6. section-07-verification (final)

## Section Summaries

### section-01-fixtures
Create the minimal fixture project (`tests/fixtures/trace_flow/`) with cross-file signal chains, lambda connections, non-direct autoload refs, and property access patterns. Add `trace_flow_session` fixture to `tests/test_tools/conftest.py`. Create `FlowStep` and `FailurePoint` dataclasses in `src/godotiq/tools/flow/__init__.py`.

### section-02-listener-map
Implement `_build_signal_listeners()` that builds signal_name -> [(file, handler)] map from all GdSignalConnection objects. Includes lambda target filtering, qualified target filtering, and signal name extraction from qualified sources. Tests: listener map construction, lambda skip, qualified target skip, multiple listeners.

### section-03-trigger-finding
Implement `_find_trigger()` and `_find_containing_function()` helpers. Exact match on function names and signal names, with emission-to-function attribution. Tests: function name match, signal name match, unknown trigger, multiple matches, containing function lookup.

### section-04-recursive-tracing
Implement `_trace_from_function()` recursive tracer. Follows signal emissions to listeners, follows direct autoload method calls. Includes depth limiting, cycle detection, autoload pattern filtering (`ref.pattern == "direct"`), and method call verification via `(` check on source line. Tests: single step, signal chain, autoload call, depth limit, cycle detection, non-direct ref skip, property access skip, shared visited set.

### section-05-failure-detection
Implement `_detect_failure_points()` regex-based detector. Reads raw source lines (with file caching), applies 4 regex patterns for common GDScript guard patterns. Tests: each pattern detected, no-match returns empty, uses cached lines.

### section-06-top-level-and-registration
Implement `_build_trace_flow()` top-level entry point and `godotiq_trace_flow` MCP tool registration. Includes detail filtering (brief/normal/full), shared visited set, file line caching. Add import in `server.py` and prompt documentation. Tests: empty trigger, not found, full chain, files_involved count, detail modes, server registration, import check.

### section-07-verification
Run full test suite to verify zero regressions (695+ existing tests still pass). Verify all new trace_flow tests pass. Confirm import check.
