Now I have all the context I need. Let me generate the section content.

# Section 7: Verification

## Overview

This is the final verification section for Sprint 6a. It depends on all six prior sections being complete. The purpose is to run the full test suite and confirm that all new `trace_flow` tests pass, no regressions have been introduced to the existing 695+ tests, and the tool is properly registered and documented.

This section does not introduce new code. It defines the verification procedure and the expected outcomes an implementer should observe.

## Prerequisites

All of the following must be complete before running verification:

- **section-01-fixtures**: The fixture project at `tests/fixtures/trace_flow/` exists with `project.godot`, `events.gd`, `order_manager.gd`, `pipeline_controller.gd`, and `printer_manager.gd`. The `FlowStep` and `FailurePoint` dataclasses exist in `src/godotiq/tools/flow/__init__.py`. The `trace_flow_session` fixture is registered in `tests/test_tools/conftest.py`. Edge-case fixture files exist (lambda connection, `has_node`/`get_node` autoload ref, property access without parentheses).
- **section-02-listener-map**: `_build_signal_listeners()` is implemented in `src/godotiq/tools/flow/__init__.py`, correctly extracting signal names from qualified sources, skipping lambda targets and qualified targets.
- **section-03-trigger-finding**: `_find_trigger()` and `_find_containing_function()` are implemented in `src/godotiq/tools/flow/__init__.py`, supporting exact function name matching and signal name matching with emission-to-function attribution.
- **section-04-recursive-tracing**: `_trace_from_function()` is implemented in `src/godotiq/tools/flow/__init__.py`, following signal emissions to listeners, following direct autoload method calls, with depth limiting, cycle detection, `ref.pattern == "direct"` filtering, and `(` method-call verification on source lines.
- **section-05-failure-detection**: `_detect_failure_points()` is implemented in `src/godotiq/tools/flow/__init__.py`, reading raw source lines (with file caching), detecting 4 regex patterns for GDScript guard patterns.
- **section-06-top-level-and-registration**: `_build_trace_flow()` and the `godotiq_trace_flow` MCP tool wrapper are implemented. `src/godotiq/server.py` imports `from godotiq.tools import flow`. `src/godotiq/prompts/godot_development.md` includes the `godotiq_trace_flow` documentation.

## Test Files

All new tests live in a single file: `tests/test_tools/test_trace_flow.py`

This file must NOT modify or conflict with any existing test files. The existing test files that must remain untouched include:

- `tests/test_tools/test_dependency_graph.py`
- `tests/test_tools/test_signal_map.py`
- `tests/test_tools/test_spatial_audit.py`
- `tests/test_bridge/test_tools.py`
- `tests/test_bridge/test_editor_screenshot.py`
- `tests/test_bridge/test_spatial_validator.py`

## Verification Steps

### Step 1: Run the trace_flow tests in isolation

```bash
pytest tests/test_tools/test_trace_flow.py -v
```

**Expected outcome**: All tests pass. The expected test count is at least 21 tests, broken down as follows:

**Signal listener map tests (6 tests):**

| Test | Description | Expected Result |
|------|-------------|-----------------|
| Builds listener map from connections | `Events.order_accepted` connected in pipeline_controller.gd | `"order_accepted"` key maps to pipeline_controller handler |
| Extracts signal name from qualified source | `"Events.order_accepted"` | `"order_accepted"` |
| Extracts signal name from self reference | `"self.my_signal"` | `"my_signal"` |
| Skips lambda targets | Target starting with `"func"` | Not in listener map |
| Skips qualified targets | Target containing `"."` | Not in listener map |
| Multiple listeners for same signal | Two scripts connecting to same signal | Both appear in map |

**Trigger finding tests (6 tests):**

| Test | Description | Expected Result |
|------|-------------|-----------------|
| Finds trigger by exact function name | `"accept_order"` | Returns `(order_manager.gd, "accept_order")` |
| Finds trigger by signal name | `"order_accepted"` | Finds the emitting function |
| Returns empty for unknown trigger | `"nonexistent_function"` | Empty list |
| Multiple entries when name exists in multiple files | Name shared across files | All matches returned |
| `_find_containing_function` correct function | Line within function range | Returns that function |
| `_find_containing_function` returns None | Line outside any function range | Returns `None` |

**Recursive tracing tests (10 tests):**

| Test | Description | Expected Result |
|------|-------------|-----------------|
| Single step | Function with no emissions or calls | 1 `FlowStep`, no sub-steps |
| Signal chain | `accept_order` -> emits `order_accepted` -> pipeline_controller listens -> calls `PrinterManager.reserve_printer` -> printer_manager.gd | Multiple steps across files |
| Autoload call | Pipeline controller's autoload call traces into `printer_manager.gd` | Step appears for `reserve_printer` |
| Depth limit | `depth=1` stops after first step | Only 1 step returned |
| Cycle detection | `(file, func)` already visited | Returns empty, no infinite loop |
| Script not found | Unknown file path | Returns empty |
| Function not found | Unknown function in known script | Returns empty |
| Non-direct autoload ref skipped | `has_node`/`get_node` refs | Do not produce flow steps |
| Property access not traced | Autoload ref without `(` on source line | Does not produce flow step |
| Shared visited set | Multiple entry points converging on same function | No duplicate steps |

**Failure point detection tests (6 tests):**

| Test | Description | Expected Result |
|------|-------------|-----------------|
| Detects `if not X: return` | Pattern in function body | `FailurePoint` found |
| Detects `if X == null: return` | Pattern in function body | `FailurePoint` found |
| Detects `if X.is_empty(): return` | Pattern in function body | `FailurePoint` found |
| Detects `if not is_instance_valid(X): return` | Pattern in function body | `FailurePoint` found |
| No failure patterns | Clean function body | Empty list |
| Uses cached file lines | Same file accessed twice | File read only once (cache hit) |

**Top-level function tests (7 tests):**

| Test | Description | Expected Result |
|------|-------------|-----------------|
| Empty trigger | `trigger=""` | Returns error dict |
| Unknown trigger | `trigger="nonexistent"` | `flow=[]`, `error="Trigger not found"` |
| Full chain | `trigger="accept_order"` | Multi-step flow through to printer_manager with correct total_steps |
| `files_involved` count | Unique files in flow | Count matches distinct file paths |
| `detail="brief"` | Strip failure_points and extra fields | Only file/function/action in steps, no failure_points key |
| `detail="normal"` | Include all fields | Full FlowStep fields and failure_points present |
| `detail="full"` | Same as normal (per design) | Output identical to normal |

**Tool registration tests (2 tests):**

| Test | Description | Expected Result |
|------|-------------|-----------------|
| `godotiq_trace_flow` in mcp tools | Import `mcp` from `godotiq.server` | Tool name found in registered tools |
| Import check | `from godotiq.tools.flow import _build_trace_flow` | Import succeeds without error |

### Step 2: Run the full test suite

```bash
pytest tests/ -v
```

**Expected outcome**: All tests pass, zero failures. The total test count should be the prior baseline (695 tests from the end of Sprint 5f) plus all new trace_flow tests (approximately 37+). No existing tests should be broken by the changes.

**Key regression checks:**

- `tests/test_tools/test_dependency_graph.py` -- the dependency graph tool uses the same parsed data (GdScript, signal emissions, connections) and must not be affected by the new flow module.
- `tests/test_tools/test_signal_map.py` -- the signal map tool builds similar listener data and must remain unaffected.
- `tests/test_bridge/test_tools.py` -- bridge tools are unrelated to filesystem-only flow tracing and must pass unchanged.
- All parser tests (`tests/test_parsers/`) -- the gd_parser, tscn_parser, and project_index are consumed but never modified by this sprint.
- All other test files must be unaffected since no other source files were modified.

### Step 3: Verify backward compatibility

The following behavioral invariants must hold:

1. **Existing tool imports work unchanged**: The addition of `from godotiq.tools import flow` in `server.py` must not affect the registration of any existing tools. All 30 prior tools must still appear in the mcp tool registry.

2. **No parser modifications**: The `gd_parser` dataclass fields (`GdScript`, `GdFunction`, `GdSignal`, `GdSignalEmission`, `GdSignalConnection`, `GdAutoloadRef`) are consumed read-only. No field additions, no method changes, no monkey-patching.

3. **No resolver modifications**: `ProjectIndex`, `GodotIQSession`, and all resolvers remain untouched. The flow module accesses `session._gd_scripts` and `session._index.autoloads` as read-only lookups.

4. **Existing `flow/__init__.py` docstring preserved**: The original module had only a docstring (`"""Flow and Debug tools — execution flow, error tracking."""`). The new implementation should preserve or extend this docstring, not lose it.

### Step 4: Verify prompt documentation

Open `src/godotiq/prompts/godot_development.md` and confirm it contains a `godotiq_trace_flow` entry in the UNDERSTAND section that covers:

- That the tool traces how a game action flows through the entire codebase
- That it takes a trigger (function or signal name) as input
- That it follows chains of calls and signal emissions through all files
- That it returns flow steps and failure points
- That it is pure filesystem analysis (no game needed, no addon needed)

The entry should appear alongside the other UNDERSTAND tools (after `godotiq_animation_audit` or in alphabetical order within the section).

### Step 5: Verify module boundaries

Confirm that `src/godotiq/tools/flow/__init__.py`:

- Imports from `godotiq.parsers.gd_parser` for dataclass types (or accesses them via duck typing from the session)
- Imports from `godotiq.session` for `GodotIQSession` type hints
- Imports `mcp` from `godotiq.server` for `@mcp.tool()` registration
- Does NOT modify any parser or resolver code
- Does NOT import from `godotiq.tools.bridge` (flow is a filesystem-only tool)
- All private helpers (`_build_signal_listeners`, `_find_trigger`, `_find_containing_function`, `_trace_from_function`, `_detect_failure_points`) are prefixed with underscore
- `_build_trace_flow` is the sole public-ish entry point (following convention of `_build_dependency_graph`, `_build_signal_map`)

Confirm that `src/godotiq/server.py`:

- Contains `from godotiq.tools import flow  # noqa: E402, F401` alongside the existing tool imports
- No other changes were made to this file

Confirm that `tests/test_tools/conftest.py`:

- Contains the `trace_flow_session` fixture that loads from `tests/fixtures/trace_flow/`
- Existing fixtures (`session`, `sample_root`, `anim_session`, `anim_root`) are untouched

### Step 6: Verify fixture project integrity

Confirm that `tests/fixtures/trace_flow/` contains at minimum:

- `project.godot` -- declares `Events` and `PrinterManager` as autoloads
- `events.gd` -- signal bus autoload defining `signal order_accepted` and `signal printer_reserved`
- `order_manager.gd` -- has `accept_order()` function that emits `order_accepted`
- `pipeline_controller.gd` -- connects to `Events.order_accepted` in `_ready()`, handler calls `PrinterManager.reserve_printer()`
- `printer_manager.gd` -- autoload with `reserve_printer()` that emits `printer_reserved`, has an early return (`if not has_available: return`) for failure point testing

Additionally, edge-case fixtures should exist:
- A `.gd` file with a lambda connection (e.g. `signal.connect(func(): pass)`)
- A `.gd` file with a `has_node`/`get_node` autoload ref (non-direct pattern)
- A `.gd` file with autoload property access without parentheses

### Step 7: Verify import check

```bash
python -c "from godotiq.tools.flow import _build_trace_flow; print('OK')"
```

**Expected outcome**: Prints `OK` with no errors.

```bash
python -c "from godotiq.tools.flow import FlowStep, FailurePoint; print('OK')"
```

**Expected outcome**: Prints `OK` with no errors.

## Files Involved

Files created by prior sections (should all exist before verification):

- `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/flow/__init__.py` (modified from original single-line docstring)
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_tools/test_trace_flow.py`
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/trace_flow/project.godot`
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/trace_flow/events.gd`
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/trace_flow/order_manager.gd`
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/trace_flow/pipeline_controller.gd`
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/trace_flow/printer_manager.gd`

Files modified by prior sections (should contain the sprint changes):

- `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/server.py` (added `from godotiq.tools import flow` import)
- `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/prompts/godot_development.md` (added `godotiq_trace_flow` documentation)
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_tools/conftest.py` (added `trace_flow_session` fixture)

Files that must NOT have been modified:

- `/Users/salvatorefarruggio/Desktop/godotiq/godot-addon/` (entire directory)
- `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/parsers/` (entire directory)
- `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/resolvers/` (entire directory)
- `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/bridge/` (entire directory)
- `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/code/` (entire directory)
- `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/spatial/` (entire directory)
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_bridge/test_tools.py`
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_bridge/test_editor_screenshot.py`
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_bridge/test_spatial_validator.py`
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_tools/test_dependency_graph.py`
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_tools/test_signal_map.py`
- `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_tools/test_spatial_audit.py`

## Summary Checklist

- [ ] `pytest tests/test_tools/test_trace_flow.py -v` -- all new trace_flow tests pass
- [ ] `pytest tests/ -v` -- full suite passes (695+ baseline plus new tests), zero regressions
- [ ] All 30 prior MCP tools still registered (the new `godotiq_trace_flow` makes 31 total)
- [ ] `python -c "from godotiq.tools.flow import _build_trace_flow; print('OK')"` succeeds
- [ ] `python -c "from godotiq.tools.flow import FlowStep, FailurePoint; print('OK')"` succeeds
- [ ] Prompt documentation includes `godotiq_trace_flow` in the UNDERSTAND section
- [ ] `flow/__init__.py` does not import from `godotiq.tools.bridge`
- [ ] No parser or resolver files were modified
- [ ] No existing test files were modified (only `conftest.py` was extended)
- [ ] Fixture project at `tests/fixtures/trace_flow/` has all required `.gd` files and `project.godot`
- [ ] `server.py` has the `from godotiq.tools import flow` import line

## Actual Verification Results

_(To be filled in by the implementer after running verification.)_