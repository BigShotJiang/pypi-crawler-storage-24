<!-- PROJECT_CONFIG
runtime: python-uv
test_command: pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-screenshot-python
section-02-camera-python
section-03-registration
section-04-server-editor-screenshot
section-05-server-camera
section-06-prompt-update
section-07-verification
END_MANIFEST -->

# Sprint 5c Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-screenshot-python | - | 03 | Yes |
| section-02-camera-python | - | 03 | Yes |
| section-03-registration | 01, 02 | 07 | No |
| section-04-server-editor-screenshot | - | 07 | Yes |
| section-05-server-camera | - | 07 | Yes |
| section-06-prompt-update | - | 07 | Yes |
| section-07-verification | 01-06 | - | No |

## Execution Order

1. Batch 1 (parallel): section-01, section-02, section-04, section-05, section-06
2. Batch 2: section-03 (requires 01, 02)
3. Batch 3: section-07 (requires all)

## Section Summaries

### section-01-screenshot-python
Modify `screenshot.py` to add editor routing, camera params, viewport validation.

### section-02-camera-python
Create `camera.py` bridge tool with get_position, look_at, focus_node actions.

### section-03-registration
Update `bridge/__init__.py` to register camera tool and update screenshot params.

### section-04-server-editor-screenshot
Add `_handle_editor_screenshot` async handler to godotiq_server.gd with viewport capture and camera override.

### section-05-server-camera
Add `_handle_camera` handler to godotiq_server.gd with get_position, look_at, focus_node actions.

### section-06-prompt-update
Update godot_development.md with editor screenshot docs, camera tool, visual debugging workflow.

### section-07-verification
Create test files, run all tests, import smoke tests, GDScript audit.
