# Sprint 5c TDD Plan

## Testing Framework

Project uses `pytest` with `pytest-asyncio` (auto mode). Bridge tools are tested by mocking the bridge connection with `AsyncMock` and `patch`. Tests verify:
- Correct method name sent to bridge
- Correct params forwarded
- Client-side validation (error returns without bridge call)
- Backward compatibility

## Section 1: Screenshot Editor Routing Tests

**File**: `tests/test_bridge/test_editor_screenshot.py`

Test cases:
1. `test_editor_viewport` — viewport="editor" routes to "editor_screenshot" method
2. `test_editor_with_camera` — camera_position and camera_target included in params
3. `test_game_viewport_unchanged` — viewport="game" routes to "screenshot" (existing path)
4. `test_default_viewport_is_game` — default routes to "screenshot"
5. `test_editor_no_camera_params` — editor viewport without camera excludes camera params
6. `test_invalid_viewport_returns_error` — viewport="foo" returns error without bridge call
7. `test_camera_position_validation` — camera_position with != 3 elements returns error
8. `test_camera_target_validation` — camera_target with != 3 elements returns error

## Section 2: Camera Tool Tests

**File**: `tests/test_bridge/test_camera.py`

Test cases:
1. `test_get_position` — sends correct params, returns position/rotation/fov
2. `test_look_at_with_target` — position + target both in params
3. `test_look_at_without_position_returns_error` — no bridge call
4. `test_look_at_position_validation` — position with != 3 elements returns error
5. `test_focus_node` — node name in params, returns selected=True
6. `test_focus_node_missing_name_returns_error` — no bridge call
7. `test_default_action_is_get_position` — default sends "get_position"

## Section 3: MCP Registration Tests

No separate test file — registration is verified by:
- Import smoke tests in verification section
- The tool tests above implicitly test the core functions

## Section 4: GDScript Editor Screenshot Handler

No Python tests — verified by live Godot testing:
- Basic capture: editor_screenshot returns base64 image
- Camera override: capture from specific position
- Format support: webp, png, jpg

## Section 5: GDScript Camera Handler

No Python tests — verified by live Godot testing:
- get_position returns camera state
- look_at moves camera
- focus_node selects node in editor

## Section 6: Prompt Update

No tests needed — text content update.

## Section 7: Verification

- All existing tests pass
- All new tests pass (15 total)
- Import smoke tests pass
- GDScript audit clean
