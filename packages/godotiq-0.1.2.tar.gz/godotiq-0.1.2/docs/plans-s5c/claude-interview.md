# Sprint 5c Interview Transcript

## Q1: Should editor screenshots use retry pattern?
**No retry needed.** Editor screenshot is deterministic — viewport is always available. Use single `request()` call, not `request_with_retry`.

## Q2: Which Godot version does PFT target?
**Godot 4.5+.** Camera positioning persists thanks to PR #105613. The `look_at` action is reliable, not temporary.

## Q3: Should editor screenshots include gizmos?
**Include gizmos.** Capture exactly what the developer sees — gizmos provide spatial context.

## Q4: Route in existing screenshot tool or separate tool?
**Route in existing tool.** Add editor routing to existing screenshot.py — one tool, two viewports.

## Q5: Camera look_at response messaging?
**Keep warning for safety.** Still include the "may reset on some versions" note for defensive messaging across Godot versions.

## Q6: focus_node — selection only or also edit_node?
**Selection only.** Just `get_selection().add_node()` — less side effects, inspector updates on selection anyway.
