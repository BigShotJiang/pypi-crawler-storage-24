# Sprint 5c — Synthesized Specification

## Objective

Add two editor-side capabilities to give the AI agent visual awareness:

1. **Editor screenshot** — Upgrade `godotiq_screenshot` to capture the editor's 3D viewport without running the game. Add `viewport="editor"` routing with optional camera positioning for targeted captures.

2. **Camera control** — New `godotiq_camera` tool for reading/setting editor camera position, and selecting nodes. Combined with screenshot for visual debugging.

After this sprint: **30 MCP tools** (29 + camera; screenshot is an upgrade).

## Architecture Decisions

### Editor Screenshot
- Route via existing `godotiq_screenshot` tool with `viewport="editor"` parameter
- Editor path uses `bridge.request()` (no retry) — deterministic, viewport always available
- Game path unchanged: `bridge.request_with_retry()` via EngineDebugger
- GDScript server receives `"editor_screenshot"` method, handles editor-side
- Optional `camera_position` + `camera_target` for atomic move→capture→restore
- Images include editor gizmos (no attempt to hide them)
- Await `RenderingServer.frame_post_draw` (NOT `process_frame`) for correct rendering

### Camera Control
- New `godotiq_camera` tool with 3 actions: `get_position`, `look_at`, `focus_node`
- Godot 4.5+ target: camera transforms persist (PR #105613), but keep defensive warning in response
- `focus_node` uses `get_selection().add_node()` only (no `edit_node()`)
- Reuse existing `_find_node_by_name_or_path()` for node lookup

### Key Technical Constraints
- `_handle_editor_screenshot` is ASYNC (first async handler in server dispatch)
- Must use `await RenderingServer.frame_post_draw` — `process_frame` fires BEFORE rendering
- Two frame awaits: one for camera transform, one for viewport texture update
- Camera restore after capture (atomic pattern)
- No Python ternaries, no snapf(), no f-strings in GDScript

## Files to Create
- `src/godotiq/tools/bridge/camera.py`
- `tests/test_bridge/test_camera.py`
- `tests/test_bridge/test_editor_screenshot.py`

## Files to Modify
- `godot-addon/addons/godotiq/godotiq_server.gd` — add handlers + dispatch entries
- `src/godotiq/tools/bridge/screenshot.py` — add editor routing
- `src/godotiq/tools/bridge/__init__.py` — register camera, update screenshot registration
- `src/godotiq/prompts/godot_development.md` — add docs
