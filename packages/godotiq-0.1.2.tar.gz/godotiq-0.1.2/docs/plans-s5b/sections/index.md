<!-- PROJECT_CONFIG
runtime: python-uv
test_command: pytest tests/ -v
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-exec-code-python
section-02-save-scene-python
section-03-bridge-registration
section-04-server-exec-editor
section-05-server-save-scene
section-06-prompt-update
section-07-verification
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-exec-code-python | - | 03 | Yes |
| section-02-save-scene-python | - | 03 | Yes |
| section-03-bridge-registration | 01, 02 | 07 | No |
| section-04-server-exec-editor | - | 07 | Yes |
| section-05-server-save-scene | - | 07 | Yes |
| section-06-prompt-update | - | 07 | Yes |
| section-07-verification | 01-06 | - | No |

## Execution Order

1. section-01-exec-code-python, section-02-save-scene-python, section-04-server-exec-editor, section-05-server-save-scene, section-06-prompt-update (parallel — no dependencies between them)
2. section-03-bridge-registration (after 01 and 02)
3. section-07-verification (after all)

## Section Summaries

### section-01-exec-code-python
Modify `src/godotiq/tools/bridge/exec_code.py` to add `context` parameter. Create `tests/test_bridge/test_exec_editor.py` with 7 test cases. TDD: write tests first, then modify exec_code.py.

### section-02-save-scene-python
Create `src/godotiq/tools/bridge/save_scene.py` and `tests/test_bridge/test_save_scene.py` with 3 test cases. TDD: write tests first.

### section-03-bridge-registration
Modify `src/godotiq/tools/bridge/__init__.py` to update godotiq_exec registration (add context param) and add godotiq_save_scene registration with standard error handling.

### section-04-server-exec-editor
Modify `godot-addon/addons/godotiq/godotiq_server.gd` to add `exec_editor` dispatch entry, `_handle_exec_editor()` handler with dynamic compilation + fallback, and `_exec_editor_via_file()` fallback. GDScript audit for syntax traps.

### section-05-server-save-scene
Modify `godot-addon/addons/godotiq/godotiq_server.gd` to add `save_scene` dispatch entry and `_handle_save_scene()` handler using `EditorInterface.save_scene()`.

### section-06-prompt-update
Modify `src/godotiq/prompts/godot_development.md` to document exec context parameter, add save_scene tool, update workflows.

### section-07-verification
Full regression test suite, import smoke tests, GDScript audit (no ternaries, no snapf, no f-strings), dispatch table verification.
