# Opus Review

**Model:** claude-opus-4-6
**Generated:** 2026-03-05T15:00:00Z

---

## Key Findings

### 1. Critical: Blocked Patterns Are Insufficient for Security
FileAccess.open allows writing to any file the Godot process has access to. String-matching is trivially bypassable. Document editor exec as a high-trust operation.

### 2. Important: Changing Default Context Is a Breaking Change
Default `context="editor"` silently changes behavior for existing callers. Recommend keeping `context="game"` as default.

### 3. Important: Dynamic Script Cleanup on Exception
GDScript has no try/catch. If `run()` errors, cleanup (remove_child, queue_free) may not execute, leaving orphaned nodes.

### 4. Moderate: Race Condition with Temp File Fallback
Concurrent exec_editor requests could overwrite the same temp file. Use unique filenames.

### 5. Moderate: save_scene API Verification
`EditorInterface.save_scene()` return type varies across Godot versions. Add defensive check.

### 6. Moderate: Non-Serializable Return Values
`str()` on complex Godot types may produce unhelpful output. Consider richer serialization.

### 7. Minor: extends Node vs EditorScript
Document why EditorScript was rejected (requires _run() not run(), may have own dynamic compilation quirks).

### 8. Minor: Response Format Consistency
Confirm _handle_exec_editor uses send_response/send_error consistently.

### 9. Minor: Test Coverage Gaps
Missing: concurrent requests, await in user code, read-only save, save_scene idempotency annotation.

### 10. Minor: Allow Helper Functions
Relax `starts_with("func run():")` to `contains` to allow helper functions before run().

### 11. Minor: Prompt Update Details Vague
Add explicit guidance: "Prefer dedicated tools over exec_editor."

### 12. Minor: MCP Annotations Can't Change Per-Invocation
openWorldHint differs between editor/game context but can't be dynamic.
