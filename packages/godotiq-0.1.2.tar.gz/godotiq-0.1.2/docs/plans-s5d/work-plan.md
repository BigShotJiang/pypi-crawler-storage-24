# Sprint 5d — Work Plan: Stress Test Fixes + Token Optimization

## Status: DONE

## Tasks

### Task 1: Auto-switch to 3D tab [GDScript]
- **File:** `godot-addon/addons/godotiq/godotiq_server.gd`
- **Change:** Add `EditorInterface.set_main_screen_editor("3D")` at start of `_handle_editor_screenshot` (line 861) and `_handle_camera` (line 962)
- **Risk:** None — idempotent call, no-op if already on 3D

### Task 2: Screenshot quality parameter [GDScript + Python]
- **Files:**
  - `godot-addon/addons/godotiq/godotiq_server.gd` — Add `quality` param to editor screenshot, change WebP encoding to lossy
  - `godot-addon/addons/godotiq/godotiq_runtime.gd` — Add `quality` param to game screenshot
  - `src/godotiq/tools/bridge/screenshot.py` — Add `quality` param, lower editor default scale to 0.25, add size warning
- **Current state:** WebP uses `save_webp_to_buffer()` (lossless, no quality control)
- **Target:** `save_webp_to_buffer(true, quality)` — lossy with configurable quality (default 0.5)
- **Auto-downscale:** Already exists in `_do_editor_screenshot` (max 45KB, 0.7x loop) — enhance to also use lossy encoding in the loop

### Task 3: Spatial audit detail levels [Python]
- **File:** `src/godotiq/tools/spatial/__init__.py`
- **Current state:** Has `min_severity="warning"` which filters by severity level. Has 50-issue cap.
- **Change:** Add `detail` parameter ("brief"/"normal"/"full") that controls which INFO-level checks are shown:
  - `brief` → only CRITICAL + WARNING
  - `normal` → exclude z_fighting + overlapping INFO items (default)
  - `full` → everything
- **Note:** This works alongside existing min_severity, not replacing it

### Task 4: Update MCP prompt [Markdown]
- **File:** `src/godotiq/prompts/godot_development.md`
- **Changes:** Screenshot quality docs, audit detail docs, run workflow note, token efficiency tips

### Task 5: Tests [Python]
- Update `tests/test_bridge/test_editor_screenshot.py` — test quality param routing
- Update `tests/test_tools/test_spatial_audit.py` — test detail parameter filtering
- Run full suite: `pytest tests/ -v`

### Task 6: Deploy & manual test
- Copy updated `godotiq_server.gd` and `godotiq_runtime.gd` to PFT project
- Toggle plugin, verify with WebSocket test script

## DO NOT TOUCH
- `src/godotiq/parsers/`, `src/godotiq/resolvers/`
- `godotiq_plugin.gd`, `godotiq_debugger.gd`
- Existing test assertions (only add new tests)
