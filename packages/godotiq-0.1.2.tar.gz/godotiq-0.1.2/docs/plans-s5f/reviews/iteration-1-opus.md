# Opus Review

**Model:** claude-opus-4
**Generated:** 2026-03-06T11:00:00Z

---

## Critical Issues

1. **Use `resolve_scene_spatial` directly instead of `_build_scene_map`** — scene_map filters to depth<=1 and caps at 50 nodes, missing walls deeper in the tree.
2. **Node overlap false positives** — checking against ALL nodes at <0.1m will block legitimate operations (parent/child at same position, markers, collision shapes).
3. **Scene data format mismatch** — `"all_nodes"` and `"focus_node"` keys don't exist in actual _build_scene_map output. Only `"nodes"` exists. `"focus_node"` is a string, not a node list.
4. **Field name inconsistency** — plan describes abbreviated `n`, `t`, `p`, `s` but actual output uses `name`, `type`, `position`, `scale`.
5. **Missing integration tests** — only pure validator tests planned, no tests for node_ops integration.

## Important Issues

6. **Session/ctx guards** — bridge tools currently don't use ctx. Need guards for ctx=None and session=None.
7. **`_read_main_scene` duplication** — same logic exists in memory module. Should reuse or extract.
8. **XZ distance ignores Y** — multi-story scenes will false-positive on vertically separated walls.
9. **`resolve_file_path` too restrictive** — should use `session.to_res_path()` instead.
10. **Stale .tscn data** — unsaved editor changes aren't in .tscn files. Document as limitation.

## Minor Issues

11. **add_child validation not specified** — prompt says it works but Section 2 doesn't list it.
12. **Name prefix suffix length undefined** — what counts as "short"?
13. **Atomic batch behavior** — mixed validate/no-validate ops behavior needs clearer docs.
14. **Return type changes** — three possible response shapes need documenting.
15. **Threshold values are heuristic** — should be documented as such, made constants for tuning.
16. **No rotation validation** — should note as deferred to v2.
