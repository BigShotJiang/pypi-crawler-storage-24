# Integration Notes — Opus Review Feedback

## Integrating

### 1. Use `resolve_scene_spatial` directly (Issue #11)
**Integrating.** This is the most impactful improvement. `_build_scene_map` filters to depth<=1 and caps at 50 nodes — walls deeper in the tree would be invisible. Using `session.resolve_scene_spatial()` gives the full `WorldNode` list at all depths. We'll build a minimal dict list from the raw WorldNode objects.

### 2. Fix node overlap false positives (Issue #6)
**Integrating.** The reviewer is right — parent/child nodes at the same position is extremely common. Fix: only check overlap against nodes at the same tree depth (depth filtering), matching the spatial audit's approach. Also lower threshold to match `_OVERLAP_DISTANCE = 0.01` from existing audit.

### 3. Fix scene data format — drop `all_nodes`/`focus_node` (Issues #3, #4)
**Integrating.** Since we're switching to `resolve_scene_spatial` directly, the `_extract_nodes` helper becomes a WorldNode→dict converter, not a multi-format parser. Use full field names (`name`, `type`, `position`, `scale`).

### 4. Add integration tests for node_ops (Issue #12)
**Integrating.** Add tests in `test_spatial_validator.py` for the `node_ops` function with `scene_data` parameter — verifying BLOCKED prevents bridge call, WARNING allows it.

### 5. Guard ctx/session access (Issue #6)
**Integrating.** Add explicit guards: if `ctx is None` or `session is None`, skip validation and proceed without it.

### 6. `_read_main_scene` reuse (Issue #2)
**Integrating partially.** Will check if importing from memory module is clean. If it creates a circular dependency, extract a shared helper.

### 7. Use `session.to_res_path()` instead of `resolve_file_path` (Issue #10)
**Integrating.** `to_res_path` is more direct and doesn't require the scene to be in the index.

### 8. Add Y-axis sanity check for wall proximity (Issue #8)
**Integrating.** Skip wall proximity check if Y-axis difference > 3m (reasonable floor height). Simple addition.

### 9. Stale .tscn data limitation (Issue #9)
**Integrating.** Document as known limitation. Suggest `save_scene` before validated operations.

### 10. Define name prefix suffix length (Issue #7, #12)
**Integrating.** Set max suffix length to 3 characters explicitly.

### 11. Add `add_child` to validation flow (Issue #13)
**Integrating.** If add_child op has a `position` field, validate it.

### 12. Document return type changes (Issue #14)
**Integrating.** Add return format documentation to tool docstring.

## NOT Integrating

### Rotation validation (Issue #16)
Explicitly v2. The computational complexity of rotation-based intersection is much higher and not justified for v1.

### Threshold tuning (Issue #15)
Thresholds ARE already constants in the module. The reviewer's point about false positives from origin-based distance is valid but resolving it requires collision shape extents (v2). Keeping current thresholds as documented heuristics.
