<!-- PROJECT_CONFIG
runtime: python-uv
test_command: uv run pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-validator
section-02-node-ops-integration
section-03-mcp-wrapper
section-04-prompt
section-05-verification
END_MANIFEST -->

# Implementation Sections Index — Sprint 5f Spatial Validation

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-validator | - | section-02, section-05 | Yes |
| section-02-node-ops-integration | section-01 | section-03, section-05 | No |
| section-03-mcp-wrapper | section-02 | section-05 | No |
| section-04-prompt | - | - | Yes |
| section-05-verification | section-01, section-02, section-03 | - | No |

## Execution Order

1. section-01-validator, section-04-prompt (parallel — no dependencies between them)
2. section-02-node-ops-integration (after section-01)
3. section-03-mcp-wrapper (after section-02)
4. section-05-verification (after section-01, section-02, section-03)

## Section Summaries

### section-01-validator
Create `src/godotiq/tools/bridge/spatial_validator.py` — pure Python validation module with `validate_move()` and `validate_scale()` functions. Tests written first in `tests/test_bridge/test_spatial_validator.py` covering wall proximity, overlap detection, sibling outlier, scale outlier, name prefix extraction, and edge cases.

### section-02-node-ops-integration
Modify `src/godotiq/tools/bridge/node_ops.py` to accept optional `scene_data` parameter and run spatial validation for operations with `validate: true`. Implements atomic batch blocking (one BLOCKED op blocks all). Tests for integration behavior added to the same test file.

### section-03-mcp-wrapper
Modify `src/godotiq/tools/bridge/__init__.py` to add `scene` parameter to `godotiq_node_ops`, resolve scene spatial data via session, convert WorldNode list to validator dict format, and pass to node_ops. Tests for MCP wrapper behavior.

### section-04-prompt
Update `src/godotiq/prompts/godot_development.md` with a "Spatial Validation" subsection documenting usage, severity levels, atomic behavior, and recommendations. No tests needed — documentation only.

### section-05-verification
Run full test suite to verify all tests pass and no regressions. Verify test count and coverage of all validation paths.
