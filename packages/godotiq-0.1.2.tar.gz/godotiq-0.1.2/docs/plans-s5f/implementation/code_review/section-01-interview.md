# Code Review Interview: Section 01 - Spatial Validator

## User Decisions

### #1 Negative scale handling
**Decision:** Use abs(ratio) for comparison — catches extreme negative scales as outliers while still allowing valid mirroring.

## Auto-fixes Applied

### #2 Guard against empty/short scale lists
Added len check before accessing scale[0] on siblings.

### #5 Fix overlap test for proper same-depth testing
test_overlap_same_depth_blocked now includes Shelf_01 in scene data with depth=1.

### #9 Add missing Ceiling and Ground wall tests
Added test_wall_identified_by_ceiling_name and test_wall_identified_by_ground_name.

## Let Go

- #3 (_dist_3d short lists): Internal, positions always 3-element from WorldNode
- #4 (Non-list type checking): Internal API, callers always pass lists
- #6/#7 (Empty checks on early returns): No downstream code depends on it
- #8 (Wall name false positives): Matches spec, deferred to v2
- #11 (O(n^2)): Fine for typical scenes
- #12 (Docstrings on private helpers): Internal helpers, logic is self-evident
