# Code Review: Section 01 - Spatial Validator Module

## HIGH SEVERITY

### 1. validate_scale silently passes negative scale values
The condition `ratio > 0 and ratio < 1.0 / SCALE_OUTLIER_FACTOR` means that if `sx` is negative (valid in Godot for mirroring), and `avg_scale` is positive, `ratio` will be negative, bypassing the outlier check. A target_scale of [-100, -100, -100] would return OK.

### 2. validate_scale crashes with IndexError when siblings have short scale lists
The code does `s["scale"][0]` but never validates that sibling scale arrays have at least one element. If a sibling has `"scale": []`, this raises unhandled IndexError.

### 3. _dist_3d silently produces wrong results for short position lists
`zip(p1[:3], p2[:3])` on lists shorter than 3 elements will silently compute a lower-dimensional distance.

## MEDIUM SEVERITY

### 4. Missing input validation for non-list types
If `target_position` is None/string/int, `len()` will raise TypeError. Same for validate_scale.

### 5. Overlap test relies on implicit depth inference
test_overlap_same_depth_blocked: Shelf_01 is not in scene data, so self_depth is None and depth filtering is skipped. The test passes by accident.

### 6. validate_scale missing checks list in early-return paths
When prefix empty or <2 siblings, returns with checks: [] instead of a scale_outlier entry.

### 7. validate_move BLOCKED early return has empty checks list

## LOW SEVERITY

### 8. Wall name detection has false-positive risk (Groundhog, Wallpaper, etc.) -- matches spec, noted as design weakness

### 9. Missing tests for Ceiling and Ground wall name detection

### 10. _extract_nodes tested directly -- fine

### 11. O(n^2) pairwise sibling distance for large scenes

### 12. No docstrings on internal helper functions
