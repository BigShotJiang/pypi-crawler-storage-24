# Section 05 Code Review

## HIGH SEVERITY

1. **`godotiq_exec` missing `detail`** — The only bridge tool without `detail`. Plan says 13 tools but `exec` was omitted.
2. **Importing private `_CHAR_LIMITS`** — Leading underscore signals internal API. A public accessor would be cleaner.

## MEDIUM SEVERITY

3. **Scope creep in `server.py`** — Diff includes unrelated changes (logging, double-import fix) already committed previously.
4. **`file_ops` read truncation edge case** — `limit - 200` could go negative if limits change to <= 200.
5. **Mutation order dependency** — Content truncation mutates dict before `apply_output_limit` sees it.

## LOW SEVERITY

6. Plan math (13 vs 11) is confusing but coverage is correct.
7. No test for `file_ops` read with `detail='full'` (no truncation).
8. No test for `file_ops` read at `detail='normal'` threshold.
9. No negative test for error paths.
10. Tests import inside functions instead of at module level.

## CORRECT

- All high-output tools call `apply_output_limit` in try block
- All no-op tools add `detail` without filtering
- Error paths skip `apply_output_limit`
- No sub-module files modified
- `file_ops` read special case matches plan
