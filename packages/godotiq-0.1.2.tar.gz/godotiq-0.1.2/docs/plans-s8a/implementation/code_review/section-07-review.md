# Section 07 Code Review

## Issues

1. **Missing skip guards** (Medium) — Plan requires `pytest.skip` when fixtures lack data.
2. **Hardcoded paths** (Low) — Plan says "first scene from fixture"; implementation hardcodes.
3. **Incomplete tool coverage** (Medium) — "All offline tools" test misses animation_info, animation_audit, suggest_scale, impact_check.
4. **No non-empty assertions** — Empty `{}` would pass the budget test.

## Correct

- Combined workflow test calls right tools at right detail levels
- Budget thresholds match plan (30,000 combined, 10,000 individual)
- Async `trace_flow` correctly excluded from sync test
