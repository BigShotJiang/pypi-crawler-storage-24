diff --git a/tests/test_tools/test_detail_levels.py b/tests/test_tools/test_detail_levels.py
index d6ab06d..f717be1 100644
--- a/tests/test_tools/test_detail_levels.py
+++ b/tests/test_tools/test_detail_levels.py
@@ -115,6 +115,13 @@ class TestPlacementDetail:
 
 from unittest.mock import AsyncMock, patch
 
+from godotiq.tools.assets import _build_asset_registry
+from godotiq.tools.spatial import _build_scene_map, _build_spatial_audit
+from godotiq.tools.code import _build_signal_map, _build_dependency_graph, _build_validate
+from godotiq.tools.animation import _build_animation_info, _build_animation_audit
+from godotiq.tools.memory import _build_project_summary, _build_file_context
+from godotiq.tools.flow import _build_trace_flow
+
 
 class TestBridgeToolSignatures:
     """All bridge tools that need detail added have correct signatures."""
@@ -276,3 +283,125 @@ class TestBridgeNoOpTools:
         with patch("godotiq.tools.bridge._script_ops", new_callable=AsyncMock, return_value=mock_result):
             result = await godotiq_script_ops(op="read", path="res://test.gd", detail="brief")
         assert result == mock_result
+
+
+# --- Section 06: Verify existing detail implementations ---
+
+
+class TestAssetRegistryDetail:
+    """Verify asset_registry respects character limits."""
+
+    def test_brief_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_asset_registry(session, detail="brief")
+        assert _output_size(result) < BRIEF_LIMIT
+
+    def test_normal_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_asset_registry(session, detail="normal")
+        assert _output_size(result) < NORMAL_LIMIT
+
+
+class TestSceneMapDetail:
+    """Verify scene_map respects character limits."""
+
+    def test_brief_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_scene_map(session, scene_path="res://scenes/main.tscn", detail="brief")
+        assert _output_size(result) < BRIEF_LIMIT
+
+    def test_normal_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_scene_map(session, scene_path="res://scenes/main.tscn", detail="normal")
+        assert _output_size(result) < NORMAL_LIMIT
+
+    def test_full_preserves_30_node_cap(self) -> None:
+        from godotiq.tools.spatial import _MAX_NEARBY
+        assert _MAX_NEARBY["full"] == 30
+
+
+class TestSpatialAuditDetail:
+    """Verify spatial_audit respects character limits."""
+
+    def test_brief_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_spatial_audit(session, scene="res://scenes/main.tscn", detail="brief")
+        assert _output_size(result) < BRIEF_LIMIT
+
+    def test_normal_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_spatial_audit(session, scene="res://scenes/main.tscn", detail="normal")
+        assert _output_size(result) < NORMAL_LIMIT
+
+
+class TestSignalMapDetail:
+    """Verify signal_map respects character limits."""
+
+    def test_brief_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_signal_map(session, detail="brief")
+        assert _output_size(result) < BRIEF_LIMIT
+
+    def test_normal_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_signal_map(session, detail="normal")
+        assert _output_size(result) < NORMAL_LIMIT
+
+
+class TestDependencyGraphDetail:
+    """Verify dependency_graph respects character limits."""
+
+    def test_brief_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_dependency_graph(
+            session, file_path="res://scripts/autoloads/economy_manager.gd", detail="brief"
+        )
+        assert _output_size(result) < BRIEF_LIMIT
+
+    def test_normal_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_dependency_graph(
+            session, file_path="res://scripts/autoloads/economy_manager.gd", detail="normal"
+        )
+        assert _output_size(result) < NORMAL_LIMIT
+
+
+class TestTraceFlowDetail:
+    """Verify trace_flow respects character limits."""
+
+    @pytest.mark.asyncio
+    async def test_brief_under_limit(self, session: GodotIQSession) -> None:
+        result = await _build_trace_flow(session, trigger="add_cash", detail="brief")
+        assert _output_size(result) < BRIEF_LIMIT
+
+
+class TestProjectSummaryDetail:
+    """Verify project_summary respects character limits."""
+
+    def test_brief_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_project_summary(session, detail="brief")
+        assert _output_size(result) < BRIEF_LIMIT
+
+
+class TestAnimationInfoDetail:
+    """Verify animation_info respects character limits."""
+
+    def test_brief_under_limit(self, anim_session: GodotIQSession) -> None:
+        result = _build_animation_info(anim_session, scene_path="res://scenes/main.tscn", detail="brief")
+        assert _output_size(result) < BRIEF_LIMIT
+
+
+class TestAnimationAuditDetail:
+    """Verify animation_audit respects character limits."""
+
+    def test_brief_under_limit(self, anim_session: GodotIQSession) -> None:
+        result = _build_animation_audit(anim_session, detail="brief")
+        assert _output_size(result) < BRIEF_LIMIT
+
+
+class TestValidateDetail:
+    """Verify validate respects character limits."""
+
+    def test_brief_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_validate(session, detail="brief")
+        assert _output_size(result) < BRIEF_LIMIT
+
+
+class TestFileContextDetail:
+    """Verify file_context respects character limits."""
+
+    def test_brief_under_limit(self, session: GodotIQSession) -> None:
+        result = _build_file_context(
+            session, file_path="res://scripts/autoloads/economy_manager.gd", detail="brief"
+        )
+        assert _output_size(result) < BRIEF_LIMIT
