<!-- PROJECT_CONFIG
runtime: python-uv
test_command: uv run pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-output-limit
section-02-assets-tools
section-03-code-tools
section-04-spatial-tools
section-05-bridge-tools
section-06-verify-existing
section-07-tests
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-output-limit | - | 02, 03, 04, 05, 06 | Yes |
| section-02-assets-tools | 01 | 07 | Yes |
| section-03-code-tools | 01 | 07 | Yes |
| section-04-spatial-tools | 01 | 07 | Yes |
| section-05-bridge-tools | 01 | 07 | Yes |
| section-06-verify-existing | 01 | 07 | Yes |
| section-07-tests | 02, 03, 04, 05, 06 | - | No |

## Execution Order

1. section-01-output-limit (no dependencies — foundation)
2. section-02 through section-06 (parallel after 01 — all independent)
3. section-07-tests (after all implementation sections complete)

## Section Summaries

### section-01-output-limit
Add `truncate_output()` function to `output_limit.py`. Add input validation to `apply_output_limit()` for unknown detail values. This is the foundation that all other sections depend on.

### section-02-assets-tools
Add `detail` parameter to `suggest_scale` in `assets/__init__.py`. Small change — tool has fixed output, parameter is mostly for API consistency.

### section-03-code-tools
Rename `impact_check.detail` → `change_description`, add proper `detail` for output verbosity, apply `apply_output_limit()`. Most complex single-tool change due to parameter rename and behavioral change.

### section-04-spatial-tools
Add `detail` parameter to `placement` in `spatial/__init__.py`. Similar to section-02 — small change for API consistency with some brief-mode filtering.

### section-05-bridge-tools
Add `detail` parameter to all 13 remaining bridge tools plus `ping`. Split into high-output-risk tools (file_ops, node_ops, editor_context, input, watch, undo_history) that need real filtering, and no-op tools (screenshot, run, save_scene, camera, script_ops) that just get the parameter signature. Also add detail to `ping` in server.py.

### section-06-verify-existing
Review and tune all 17 existing tools that already have `detail` to ensure they respect character limits (brief≤2000, normal≤8000). Adjust truncation parameters where needed.

### section-07-tests
Add all new test files: `test_truncate_output.py` (unit tests for new function), `test_detail_levels.py` (per-tool detail tests), `test_token_budget.py` (integration test). Do not modify existing test files.
