# Integration Notes — Opus Review Feedback

## Integrating (12 suggestions)

### 1. Fix tool count arithmetic
**Integrating.** Will create explicit tool inventory in plan. `ping` gets detail as no-op. `exec` already has implicit detail per research — will formalize.

### 2. impact_check output dict field naming
**Integrating.** Will document that the returned dict field `"detail"` must also be renamed to `"change_description"`, and string interpolation in `safe_alternative` updated.

### 3. apply_output_limit behavioral change on impact_check
**Integrating.** Will note this as a behavioral change in the plan.

### 4. Bridge tools: clarify apply_output_limit location
**Integrating.** Apply in `__init__.py` wrapper (option a) — keeps changes to fewer files. Sub-modules return full data, wrapper truncates.

### 5. truncate_output scope clarification
**Integrating.** Will clarify it's for future-proofing and as a general safety net. No current callers, but it's cheap to add and matches the spec requirement.

### 6. full detail level harmonization
**Integrating.** Both functions will use `None` (unlimited) for full. The 200k cap in the spec's truncate_output was a suggestion — we'll align with existing behavior.

### 8. file_ops op="read" string truncation
**Integrating.** Will add explicit handling: if result contains a large string value, truncate it before apply_output_limit. Or wrap the string in a list-of-lines format.

### 10. Add detail parameter validation
**Integrating.** Will add validation in apply_output_limit: unknown values normalize to "normal".

### 12. Acknowledge breaking change for impact_check
**Integrating.** Will add explicit breaking change note.

### 13. scene_map full cap: keep for performance
**Integrating.** Will keep the 30-node cap for full and document the performance reason. Users can use filters for targeted queries.

### 17. File modification table: add sub-module files
**Integrating.** Will list all affected files.

### 18. ping tool in modification summary
**Integrating.** Will add server.py for ping.

## NOT Integrating (8 suggestions)

### 7. Metadata overhead in test thresholds
**Not integrating as change.** The existing 3k/10k test buffers already account for this. No plan change needed.

### 9. node_ops Godot response schema
**Not integrating.** The implementer will inspect the actual response structure. Over-specifying in the plan would be premature — this is implementation detail.

### 11. config.get_default_detail() usage
**Not integrating.** Hardcoded defaults are simpler and more predictable. Config override is a future enhancement outside this sprint's scope.

### 14. Ordering/prioritization for Section 6
**Not integrating as explicit ordering.** Section 6 is verification work — order doesn't matter. The priority order in the spec (asset_registry, scene_map, scene_tree, ui_map) serves as guidance.

### 15. Integration test fixtures
**Not integrating.** Interview decision was to use existing fixtures. If they're too small to trigger truncation, the test still validates the pipeline works. Large-project testing is manual validation.

### 16. apply_output_limit performance
**Not integrating.** Pre-existing concern, not introduced by this sprint. The tools gaining apply_output_limit have small output where binary search won't be noticeable.

### 19. Head-tail truncation
**Not integrating.** Nice-to-have future improvement, outside scope.

### 20. truncate_output line count for JSON
**Not integrating.** Minor UX issue, truncate_output is a safety net rarely triggered.
