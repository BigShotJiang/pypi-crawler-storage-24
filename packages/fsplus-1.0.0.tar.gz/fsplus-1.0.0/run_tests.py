#!/usr/bin/env python
"""
run_tests.py
------------
Run the fsplus copy_file test suite directly via pytest's Python API.

Usage:
    python run_tests.py              # all tests
    python run_tests.py -k overwrite # filter by keyword
    python run_tests.py -v --tb=long # pass any pytest flag through
"""

import sys
from pathlib import Path

import pytest

# Ensure the repo root is on sys.path so `fsplus` is importable
# even when the package is not installed.
ROOT = Path(__file__).parent.resolve()
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

TESTS_DIR = ROOT / "tests"

if __name__ == "__main__":
    extra_args = sys.argv[1:]  # forward any CLI flags the caller passed
    exit_code = pytest.main(
        [
            str(TESTS_DIR),
            "-v",
            "--tb=short",
            *extra_args,
        ]
    )
    sys.exit(exit_code)
