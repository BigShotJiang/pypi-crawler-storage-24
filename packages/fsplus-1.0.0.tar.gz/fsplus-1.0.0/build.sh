#!/usr/bin/env bash
set -euo pipefail

echo "🔨 Building fsplus..."

# Clean previous build artifacts
rm -rf dist/ build/ src/*.egg-info

# Build the package (sdist + wheel)
python -m pip install --quiet --upgrade build
python -m build

echo "Build complete. Artifacts in dist/:"
ls -lh dist/