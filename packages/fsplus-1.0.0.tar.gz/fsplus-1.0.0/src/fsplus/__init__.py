"""
fsplus — safe file system operations for Python.

A library providing robust, safety-checked wrappers around common file
system operations: creating, copying, moving, and deleting files and
directories.

Public API
----------
File operations::

    from fsplus import copy_file, move_file, create_file, create_temp_file
    from fsplus import clear_directory, delete_directory

Exceptions from the core hierarchy::

    from fsplus import FSPlusError
    from fsplus import FSPlusFileAlreadyExists, FSPlusFileNotFound
    from fsplus import FSPlusFileLocked, FSPlusFileEmpty
    from fsplus import FSPlusPathNotFound, FSPlusPathTraversal
    from fsplus import FSPlusInvalidPath, FSPlusDirNotFound
    from fsplus import FSPlusInsufficientSpace, FSPlusPermissionDenied
    from fsplus import FSPlusChecksumMismatch, FSPlusWriteTimeout

Exceptions specific to delete operations::

    from fsplus import FSPlusSystemPathBlocked, FSPlusFileLimitExceeded
"""

__version__ = "1.0.0"
__author__ = "Til Schwarze"
__email__ = "tschwarze@fsplus.org"

# ---------------------------------------------------------------------------
# Core exceptions
# ---------------------------------------------------------------------------
from fsplus.exceptions import (
    FSPlusError,
    # File errors
    FSPlusFileError,
    FSPlusFileAlreadyExists,
    FSPlusFileNotFound,
    FSPlusFileLocked,
    FSPlusFileEmpty,
    # Path errors
    FSPlusPathError,
    FSPlusPathNotFound,
    FSPlusPathTraversal,
    FSPlusInvalidPath,
    FSPlusDirNotFound,
    # I/O errors
    FSPlusIOError,
    FSPlusInsufficientSpace,
    FSPlusPermissionDenied,
    FSPlusChecksumMismatch,
    FSPlusWriteTimeout,
)

# ---------------------------------------------------------------------------
# File operations
# ---------------------------------------------------------------------------
from fsplus.fsplus_copy import copy_file
from fsplus.fsplus_move import move_file
from fsplus.fsplus_create import create_file, create_temp_file

# ---------------------------------------------------------------------------
# Directory operations + delete-specific exceptions
# ---------------------------------------------------------------------------
from fsplus.fsplus_delete import (
    clear_directory,
    delete_directory,
    FSPlusSystemPathBlocked,
    FSPlusFileLimitExceeded,
)

# ---------------------------------------------------------------------------
# Public API surface
# ---------------------------------------------------------------------------
__all__ = [
    # Metadata
    "__version__",
    "__author__",
    "__email__",
    # File operations
    "copy_file",
    "move_file",
    "create_file",
    "create_temp_file",
    # Directory operations
    "clear_directory",
    "delete_directory",
    # Core exception base
    "FSPlusError",
    # File exceptions
    "FSPlusFileError",
    "FSPlusFileAlreadyExists",
    "FSPlusFileNotFound",
    "FSPlusFileLocked",
    "FSPlusFileEmpty",
    # Path exceptions
    "FSPlusPathError",
    "FSPlusPathNotFound",
    "FSPlusPathTraversal",
    "FSPlusInvalidPath",
    "FSPlusDirNotFound",
    # I/O exceptions
    "FSPlusIOError",
    "FSPlusInsufficientSpace",
    "FSPlusPermissionDenied",
    "FSPlusChecksumMismatch",
    "FSPlusWriteTimeout",
    # Delete-specific exceptions
    "FSPlusSystemPathBlocked",
    "FSPlusFileLimitExceeded",
]
