"""
fsplus.fsplus_delete
~~~~~~~~~~~~~~~~~~~~
Safe directory deletion and clearing operations for fsplus.

Two public functions are provided:

* ``clear_directory`` — removes all files and subdirectories inside a
  directory while leaving the directory itself in place.
* ``delete_directory`` — removes a directory and everything inside it
  entirely (equivalent to ``rm -rf``).

Both operations enforce the following safety guarantees before touching
the file system:

1. **System-path protection** — a hard-coded blocklist prevents any
   operation whose resolved target begins with a well-known system root on
   Linux, macOS, or Windows (e.g. ``/etc``, ``/usr``, ``C:\\Windows``).
2. **File-count guard** — if the number of files (and symlinks) inside
   the target exceeds ``max_files`` (default: **10**), the operation is
   aborted before a single byte is deleted.  Callers who intentionally
   need to remove larger trees must pass an explicit ``max_files`` value
   to signal they understand the scope.

Both functions accept a ``dry_run`` keyword argument.  When ``True``, all
validation checks are performed exactly as in a normal call, but no files
or directories are actually deleted.  The return value mirrors the live
call: ``clear_directory`` returns the number of top-level entries *that
would have been* removed; ``delete_directory`` returns the resolved path
*that would have been* deleted.
"""

from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from typing import Optional

from fsplus.exceptions import (
    FSPlusPathNotFound,
    FSPlusPathTraversal,
)

# ---------------------------------------------------------------------------
# Internal constants
# ---------------------------------------------------------------------------

#: Paths that are unconditionally protected against deletion or clearing.
#: Resolved paths are checked with ``str(resolved_path).startswith(prefix)``.
_SYSTEM_PATH_PREFIXES: tuple[str, ...] = (
    # --- POSIX / Linux / macOS ---
    "/bin",
    "/boot",
    "/dev",
    "/etc",
    "/lib",
    "/lib32",
    "/lib64",
    "/libx32",
    "/media",
    "/mnt",
    "/opt",
    "/proc",
    "/root",
    "/run",
    "/sbin",
    "/snap",
    "/srv",
    "/sys",
    "/tmp",
    "/usr",
    "/var",
    # macOS-specific
    "/Applications",
    "/Library",
    "/Network",
    "/System",
    "/Volumes",
    "/cores",
    "/private",
    # --- Windows (resolved forward-slash form that pathlib produces) ---
    "C:/Windows",
    "C:/Program Files",
    "C:/Program Files (x86)",
    "C:/ProgramData",
    "C:/System Volume Information",
    "C:/Users/Default",
    "C:/Users/Public",
    "C:/Recovery",
)

#: Default maximum number of files (regular files + symlinks, counted
#: recursively) allowed inside a target before the operation is aborted.
_DEFAULT_MAX_FILES: int = 10


# ---------------------------------------------------------------------------
# Custom exception
# ---------------------------------------------------------------------------


class FSPlusSystemPathBlocked(Exception):
    """Raised when the target path begins with a protected system prefix.

    Attributes:
        path:   The resolved target path that was rejected.
        prefix: The system prefix that matched.

    Example::

        raise FSPlusSystemPathBlocked(path="/usr/local/bin", prefix="/usr")
    """

    def __init__(
        self,
        message: str = "Operation refused: target is inside a protected system path.",
        *,
        path: Optional[str | Path] = None,
        prefix: Optional[str] = None,
    ) -> None:
        self.path = Path(path) if path is not None else None
        self.prefix = prefix
        suffix_parts: list[str] = []
        if self.path:
            suffix_parts.append(f"path: {self.path}")
        if self.prefix:
            suffix_parts.append(f"matched prefix: {self.prefix!r}")
        if suffix_parts:
            message += f" ({', '.join(suffix_parts)})"
        super().__init__(message)


class FSPlusFileLimitExceeded(Exception):
    """Raised when the number of files inside the target directory exceeds
    the caller-configured (or default) ``max_files`` limit.

    The file count is checked *before* any deletion takes place, so the
    directory is always left completely intact when this exception is raised.

    Attributes:
        path:       The target directory.
        file_count: The actual number of files found.
        max_files:  The limit that was in effect.

    Example::

        raise FSPlusFileLimitExceeded(
            path="/data/archive",
            file_count=47,
            max_files=10,
        )
    """

    def __init__(
        self,
        message: str = "Operation refused: file count exceeds the configured limit.",
        *,
        path: Optional[str | Path] = None,
        file_count: Optional[int] = None,
        max_files: Optional[int] = None,
    ) -> None:
        self.path = Path(path) if path is not None else None
        self.file_count = file_count
        self.max_files = max_files
        suffix_parts: list[str] = []
        if self.path:
            suffix_parts.append(f"path: {self.path}")
        if file_count is not None:
            suffix_parts.append(f"found: {file_count} file(s)")
        if max_files is not None:
            suffix_parts.append(f"limit: {max_files}")
        if suffix_parts:
            message += f" ({', '.join(suffix_parts)})"
        if max_files is not None:
            message += (
                f" Pass max_files={file_count} (or higher) explicitly if you "
                f"intend to delete this many files."
            )
        super().__init__(message)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _check_system_path(path: Path) -> None:
    """Raise :exc:`FSPlusSystemPathBlocked` if *path* begins with any
    entry in :data:`_SYSTEM_PATH_PREFIXES`.

    Both the resolved path and each prefix are compared as strings so that
    the check is straightforward and cross-platform (pathlib normalises
    Windows paths to forward slashes when converting to string on all
    platforms).
    """
    tmp_real = Path(tempfile.gettempdir()).resolve()
    if path.resolve().is_relative_to(tmp_real):
        return  # temp directories are never system-critical

    path_str = str(path)
    for prefix in _SYSTEM_PATH_PREFIXES:
        # Use startswith on the string representation; ensure we are not
        # doing a false-positive match on a longer path that merely shares
        # an initial substring (e.g. /opt vs /option) by requiring the
        # next character after the prefix to be a separator or end-of-string.
        if (
            path_str == prefix
            or path_str.startswith(prefix + "/")
            or path_str.startswith(prefix + "\\")
        ):
            raise FSPlusSystemPathBlocked(
                path=path,
                prefix=prefix,
            )


def _count_files(path: Path) -> int:
    """Return the number of regular files and symlinks inside *path*,
    counted recursively across all subdirectories."""
    return sum(1 for entry in path.rglob("*") if entry.is_file() or entry.is_symlink())


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def clear_directory(
    target_dir: str | Path,
    *,
    max_files: int = _DEFAULT_MAX_FILES,
    required_partial_path: Optional[str] = None,
    dry_run: bool = False,
) -> int:
    """Remove all contents of a directory without removing the directory itself.

    Every file, symlink, and subdirectory directly inside ``target_dir`` is
    deleted.  The directory node itself is preserved, so the caller ends up
    with an empty directory at the same path.

    Safety checks (performed in order, *before* any deletion):

    1. **Existence** — ``target_dir`` must exist and be a directory.
    2. **System-path block** — the resolved path must not begin with any
       protected system prefix (see :data:`_SYSTEM_PATH_PREFIXES`).
    3. **Partial-path confirmation** — a non-empty ``required_partial_path``
       must appear as a substring of the resolved ``target_dir`` string.
       This acts as a deliberate, human-readable confirmation that the caller
       knows exactly which directory they are about to wipe.
    4. **File-count guard** — the total number of regular files and symlinks
       inside ``target_dir`` must not exceed ``max_files``.  Increase the
       limit explicitly when clearing larger trees.

    Args:
        target_dir:
            Path to the directory whose contents should be removed.
        max_files:
            Maximum number of files (regular files + symlinks, counted
            recursively) allowed before the operation is aborted.  Defaults
            to ``10``.  Pass a higher value intentionally when you know the
            directory contains more files and you still want to proceed.
        required_partial_path:
            A path fragment that must appear as a substring of the resolved
            ``target_dir`` string.  Providing this is *always* recommended
            as an explicit safety confirmation.

            Rules enforced when provided:
              - Must not be an empty string.
              - Must not equal the full resolved ``target_dir`` string.
              - Must be a substring of the resolved ``target_dir`` string.
        dry_run:
            When ``True``, all validation checks are performed but no files
            are deleted.  Returns the number of top-level entries that
            *would* have been removed.  Defaults to ``False``.

    Returns:
        The number of top-level entries (files, symlinks, subdirectories)
        that were removed (or would have been removed if ``dry_run=True``).

    Raises:
        ValueError:                 If ``required_partial_path`` is provided
                                    but violates the rules above.
        FSPlusPathNotFound:         If ``target_dir`` does not exist or is not
                                    a directory.
        FSPlusSystemPathBlocked:    If the resolved path begins with a
                                    protected system prefix.
        FSPlusPathTraversal:        If ``required_partial_path`` does not
                                    appear in the resolved ``target_dir``.
        FSPlusFileLimitExceeded:    If the file count inside ``target_dir``
                                    exceeds ``max_files``.  No files are
                                    deleted in this case.
    """
    target_dir = Path(target_dir).resolve()

    # ------------------------------------------------------------------
    # 1. Validate target directory
    # ------------------------------------------------------------------
    if not target_dir.exists():
        raise FSPlusPathNotFound(path=target_dir)
    if not target_dir.is_dir():
        raise FSPlusPathNotFound(
            "Target path exists but is not a directory.",
            path=target_dir,
        )

    # ------------------------------------------------------------------
    # 2. System-path protection
    # ------------------------------------------------------------------
    _check_system_path(target_dir)

    # ------------------------------------------------------------------
    # 3. Validate required_partial_path
    # ------------------------------------------------------------------
    if required_partial_path is not None:
        if not required_partial_path:
            raise ValueError(
                "required_partial_path must not be an empty string when provided. "
                "Supply a unique fragment of target_dir to confirm the intended destination."
            )

        target_dir_str = str(target_dir)

        if required_partial_path == target_dir_str:
            raise ValueError(
                "required_partial_path must not be identical to target_dir. "
                "It must be a distinctive sub-fragment of the path, not the full path itself."
            )

        if required_partial_path not in target_dir_str:
            raise FSPlusPathTraversal(
                f"required_partial_path {required_partial_path!r} was not found "
                f"in the resolved target directory.",
                path=target_dir,
                root=required_partial_path,
            )

    # ------------------------------------------------------------------
    # 4. File-count guard — check BEFORE any deletion
    # ------------------------------------------------------------------
    file_count = _count_files(target_dir)
    if file_count > max_files:
        raise FSPlusFileLimitExceeded(
            path=target_dir,
            file_count=file_count,
            max_files=max_files,
        )

    # ------------------------------------------------------------------
    # 5. Clear contents — remove each top-level entry (skipped on dry_run)
    # ------------------------------------------------------------------
    if dry_run:
        return sum(1 for _ in target_dir.iterdir())

    removed = 0
    for entry in target_dir.iterdir():
        if entry.is_dir() and not entry.is_symlink():
            shutil.rmtree(entry)
        else:
            entry.unlink()
        removed += 1

    return removed


def delete_directory(
    target_dir: str | Path,
    *,
    max_files: int = _DEFAULT_MAX_FILES,
    required_partial_path: Optional[str] = None,
    dry_run: bool = False,
) -> Path:
    """Completely remove a directory and everything inside it.

    This is equivalent to ``rm -rf target_dir``.  Unlike
    :func:`clear_directory`, the directory node itself is also deleted.

    Safety checks (performed in order, *before* any deletion):

    1. **Existence** — ``target_dir`` must exist and be a directory.
    2. **System-path block** — the resolved path must not begin with any
       protected system prefix (see :data:`_SYSTEM_PATH_PREFIXES`).
    3. **Partial-path confirmation** — see :func:`clear_directory` for the
       same semantics.
    4. **File-count guard** — see :func:`clear_directory`.

    Args:
        target_dir:
            Path to the directory to remove entirely.
        max_files:
            Maximum number of files (regular files + symlinks, counted
            recursively) allowed before the operation is aborted.  Defaults
            to ``10``.
        required_partial_path:
            A path fragment that must appear as a substring of the resolved
            ``target_dir`` string.  See :func:`clear_directory` for full
            semantics.
        dry_run:
            When ``True``, all validation checks are performed but the
            directory is not actually deleted.  Returns the resolved path
            *that would have been* removed.  Defaults to ``False``.

    Returns:
        The :class:`~pathlib.Path` of the directory that was deleted (which
        no longer exists on the file system after the call returns), or the
        path that *would have been* deleted when ``dry_run=True``.

    Raises:
        ValueError:                 If ``required_partial_path`` is provided
                                    but violates the rules above.
        FSPlusPathNotFound:         If ``target_dir`` does not exist or is not
                                    a directory.
        FSPlusSystemPathBlocked:    If the resolved path begins with a
                                    protected system prefix.
        FSPlusPathTraversal:        If ``required_partial_path`` does not
                                    appear in the resolved ``target_dir``.
        FSPlusFileLimitExceeded:    If the file count inside ``target_dir``
                                    exceeds ``max_files``.  No files are
                                    deleted in this case.
    """
    target_dir = Path(target_dir).resolve()

    # ------------------------------------------------------------------
    # 1. Validate target directory
    # ------------------------------------------------------------------
    if not target_dir.exists():
        raise FSPlusPathNotFound(path=target_dir)
    if not target_dir.is_dir():
        raise FSPlusPathNotFound(
            "Target path exists but is not a directory.",
            path=target_dir,
        )

    # ------------------------------------------------------------------
    # 2. System-path protection
    # ------------------------------------------------------------------
    _check_system_path(target_dir)

    # ------------------------------------------------------------------
    # 3. Validate required_partial_path
    # ------------------------------------------------------------------
    if required_partial_path is not None:
        if not required_partial_path:
            raise ValueError(
                "required_partial_path must not be an empty string when provided. "
                "Supply a unique fragment of target_dir to confirm the intended destination."
            )

        target_dir_str = str(target_dir)

        if required_partial_path == target_dir_str:
            raise ValueError(
                "required_partial_path must not be identical to target_dir. "
                "It must be a distinctive sub-fragment of the path, not the full path itself."
            )

        if required_partial_path not in target_dir_str:
            raise FSPlusPathTraversal(
                f"required_partial_path {required_partial_path!r} was not found "
                f"in the resolved target directory.",
                path=target_dir,
                root=required_partial_path,
            )

    # ------------------------------------------------------------------
    # 4. File-count guard — check BEFORE any deletion
    # ------------------------------------------------------------------
    file_count = _count_files(target_dir)
    if file_count > max_files:
        raise FSPlusFileLimitExceeded(
            path=target_dir,
            file_count=file_count,
            max_files=max_files,
        )

    # ------------------------------------------------------------------
    # 5. Delete the entire directory tree (skipped on dry_run)
    # ------------------------------------------------------------------
    if not dry_run:
        shutil.rmtree(target_dir)

    return target_dir
