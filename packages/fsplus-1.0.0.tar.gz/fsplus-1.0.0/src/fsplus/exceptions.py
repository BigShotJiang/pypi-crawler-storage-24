"""
fsplus.exceptions

Custom exception hierarchy for fsplus, a safe file system operations library.

Usage::

    from fsplus.exceptions import FSPlusFileAlreadyExists

    raise FSPlusFileAlreadyExists(path="/tmp/data.csv")
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------


class FSPlusError(Exception):
    """Root exception for all fsplus errors.

    All custom exceptions in this package inherit from this class, so callers
    can write a single broad ``except FSPlusError`` when they don't care about
    the specific sub-type.

    Attributes:
        message: Human-readable description of the error.
        path:    The file-system path involved in the operation, if applicable.
    """

    def __init__(
        self,
        message: str = "An fsplus error occurred.",
        *,
        path: Optional[str | Path] = None,
    ) -> None:
        self.path = Path(path) if path is not None else None
        suffix = f" (path: {self.path})" if self.path else ""
        super().__init__(message + suffix)


# ---------------------------------------------------------------------------
# File errors  (FSPlusFileError → FSPlusError)
# ---------------------------------------------------------------------------


class FSPlusFileError(FSPlusError):
    """Base class for errors that relate to a specific file."""


class FSPlusFileAlreadyExists(FSPlusFileError):
    """Raised when trying to create or write a file that already exists
    and ``overwrite=False`` was specified (the default).

    Example::

        raise FSPlusFileAlreadyExists(path="/data/report.csv")
    """

    def __init__(
        self,
        message: str = "File already exists and overwrite is disabled.",
        *,
        path: Optional[str | Path] = None,
    ) -> None:
        super().__init__(message, path=path)


class FSPlusFileNotFound(FSPlusFileError):
    """Raised when a required file does not exist at the given path.

    Example::

        raise FSPlusFileNotFound(path="/data/missing.txt")
    """

    def __init__(
        self,
        message: str = "File not found.",
        *,
        path: Optional[str | Path] = None,
    ) -> None:
        super().__init__(message, path=path)


class FSPlusFileLocked(FSPlusFileError):
    """Raised when a file cannot be accessed because it is held by an
    exclusive lock (another process or thread has it open).

    Example::

        raise FSPlusFileLocked(path="/tmp/db.lock")
    """

    def __init__(
        self,
        message: str = "File is locked by another process.",
        *,
        path: Optional[str | Path] = None,
    ) -> None:
        super().__init__(message, path=path)


class FSPlusFileEmpty(FSPlusFileError):
    """Raised when a file exists but contains zero bytes, and the calling
    operation requires non-empty content.

    Example::

        raise FSPlusFileEmpty(path="/uploads/payload.json")
    """

    def __init__(
        self,
        message: str = "File is empty (zero bytes).",
        *,
        path: Optional[str | Path] = None,
    ) -> None:
        super().__init__(message, path=path)


# ---------------------------------------------------------------------------
# Path errors  (FSPlusPathError → FSPlusError)
# ---------------------------------------------------------------------------


class FSPlusPathError(FSPlusError):
    """Base class for errors that relate to path resolution or validation."""


class FSPlusPathNotFound(FSPlusPathError):
    """Raised when a path (file *or* directory) cannot be resolved because
    it does not exist on the file system.

    Example::

        raise FSPlusPathNotFound(path="/mnt/archive")
    """

    def __init__(
        self,
        message: str = "Path not found.",
        *,
        path: Optional[str | Path] = None,
    ) -> None:
        super().__init__(message, path=path)


class FSPlusPathTraversal(FSPlusPathError):
    """Raised when a resolved path escapes the configured root/sandbox
    directory, typically indicating a directory-traversal attempt
    (e.g. ``../../etc/passwd``).

    Attributes:
        root: The allowed root directory.

    Example::

        raise FSPlusPathTraversal(path="../../../etc/passwd", root="/safe/root")
    """

    def __init__(
        self,
        message: str = "Path escapes the allowed root directory.",
        *,
        path: Optional[str | Path] = None,
        root: Optional[str | Path] = None,
    ) -> None:
        self.root = Path(root) if root is not None else None
        if self.root:
            message += f" (root: {self.root})"
        super().__init__(message, path=path)


class FSPlusInvalidPath(FSPlusPathError):
    """Raised when a path string is syntactically malformed or contains
    illegal characters for the current operating system.

    Example::

        raise FSPlusInvalidPath(path="con://:nul")
    """

    def __init__(
        self,
        message: str = "Path is invalid or malformed.",
        *,
        path: Optional[str | Path] = None,
    ) -> None:
        super().__init__(message, path=path)


class FSPlusDirNotFound(FSPlusPathError):
    """Raised when a required parent directory does not exist and
    ``create_parents=False`` was specified.

    Example::

        raise FSPlusDirNotFound(path="/data/nested/dir")
    """

    def __init__(
        self,
        message: str = "Directory not found. Pass create_parents=True to auto-create it.",
        *,
        path: Optional[str | Path] = None,
    ) -> None:
        super().__init__(message, path=path)


# ---------------------------------------------------------------------------
# I/O errors  (FSPlusIOError → FSPlusError)
# ---------------------------------------------------------------------------


class FSPlusIOError(FSPlusError):
    """Base class for errors that occur during the actual read/write I/O."""


class FSPlusInsufficientSpace(FSPlusIOError):
    """Raised when there is not enough disk space to complete a write
    or copy operation.

    Attributes:
        required_bytes:  How many bytes the operation needed.
        available_bytes: How many bytes were actually free.

    Example::

        raise FSPlusInsufficientSpace(
            path="/mnt/disk/bigfile.bin",
            required_bytes=10_000_000,
            available_bytes=512_000,
        )
    """

    def __init__(
        self,
        message: str = "Insufficient disk space.",
        *,
        path: Optional[str | Path] = None,
        required_bytes: Optional[int] = None,
        available_bytes: Optional[int] = None,
    ) -> None:
        self.required_bytes = required_bytes
        self.available_bytes = available_bytes
        if required_bytes is not None and available_bytes is not None:
            message += (
                f" Required: {required_bytes:,} bytes, "
                f"available: {available_bytes:,} bytes."
            )
        super().__init__(message, path=path)


class FSPlusPermissionDenied(FSPlusIOError):
    """Raised when the process lacks the necessary permissions to read,
    write, or execute a file-system entry.

    Attributes:
        operation: The attempted operation, e.g. ``"read"``, ``"write"``,
                   ``"execute"``, or ``"delete"``.

    Example::

        raise FSPlusPermissionDenied(path="/etc/shadow", operation="read")
    """

    def __init__(
        self,
        message: str = "Permission denied.",
        *,
        path: Optional[str | Path] = None,
        operation: Optional[str] = None,
    ) -> None:
        self.operation = operation
        if operation:
            message += f" Operation: {operation}."
        super().__init__(message, path=path)


class FSPlusChecksumMismatch(FSPlusIOError):
    """Raised when the checksum of a written file does not match the
    expected value, indicating data corruption during the write.

    Attributes:
        expected: The expected checksum string.
        actual:   The actual checksum computed after writing.

    Example::

        raise FSPlusChecksumMismatch(
            path="/backups/dump.tar.gz",
            expected="abc123",
            actual="deadbeef",
        )
    """

    def __init__(
        self,
        message: str = "Checksum mismatch after write – possible data corruption.",
        *,
        path: Optional[str | Path] = None,
        expected: Optional[str] = None,
        actual: Optional[str] = None,
    ) -> None:
        self.expected = expected
        self.actual = actual
        if expected and actual:
            message += f" Expected: {expected!r}, got: {actual!r}."
        super().__init__(message, path=path)


class FSPlusWriteTimeout(FSPlusIOError):
    """Raised when a write, flush, or sync operation exceeds the allowed
    timeout duration.

    Attributes:
        timeout_seconds: The timeout that was exceeded.

    Example::

        raise FSPlusWriteTimeout(path="/slow/nfs/mount/file.dat", timeout_seconds=30)
    """

    def __init__(
        self,
        message: str = "Write operation timed out.",
        *,
        path: Optional[str | Path] = None,
        timeout_seconds: Optional[float] = None,
    ) -> None:
        self.timeout_seconds = timeout_seconds
        if timeout_seconds is not None:
            message += f" Timeout: {timeout_seconds}s."
        super().__init__(message, path=path)


# ---------------------------------------------------------------------------
# Public API surface
# ---------------------------------------------------------------------------

__all__ = [
    # Base
    "FSPlusError",
    # File
    "FSPlusFileError",
    "FSPlusFileAlreadyExists",
    "FSPlusFileNotFound",
    "FSPlusFileLocked",
    "FSPlusFileEmpty",
    # Path
    "FSPlusPathError",
    "FSPlusPathNotFound",
    "FSPlusPathTraversal",
    "FSPlusInvalidPath",
    "FSPlusDirNotFound",
    # I/O
    "FSPlusIOError",
    "FSPlusInsufficientSpace",
    "FSPlusPermissionDenied",
    "FSPlusChecksumMismatch",
    "FSPlusWriteTimeout",
]
