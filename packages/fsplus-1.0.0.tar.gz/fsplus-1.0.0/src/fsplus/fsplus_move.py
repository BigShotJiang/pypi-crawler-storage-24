"""
fsplus.fsplus_move
~~~~~~~~~~~~~~~~~~
Safe file move operation for fsplus.

Moves a file by first copying it to the target directory (with all the
safety checks from ``copy_file``), verifying the copy succeeded, and only
then deleting the original.  This guarantees the source is never removed
unless a complete, readable copy exists at the destination.
"""

from __future__ import annotations

import hashlib
import shutil
from pathlib import Path
from typing import Optional

from fsplus.exceptions import (
    FSPlusChecksumMismatch,
    FSPlusFileAlreadyExists,
    FSPlusFileNotFound,
    FSPlusInvalidPath,
    FSPlusPathNotFound,
    FSPlusPathTraversal,
)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _sha256(path: Path, chunk_size: int = 65_536) -> str:
    """Return the hex-encoded SHA-256 digest of *path*."""
    h = hashlib.sha256()
    with path.open("rb") as fh:
        while chunk := fh.read(chunk_size):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def move_file(
    source: str | Path,
    target_dir: str | Path,
    *,
    overwrite: bool = False,
    required_partial_path: Optional[str] = None,
    new_name: Optional[str] = None,
    dry_run: bool = False,
) -> Path:
    """Move a file to a target directory.

    The operation is performed in three steps:

    1. **Copy** — the source file is copied to ``target_dir`` with all of
       the same safety checks as ``copy_file`` (existence, traversal guard,
       overwrite confirmation via ``required_partial_path``).
    2. **Verify** — a SHA-256 checksum of the copy is compared against the
       source to confirm the data arrived intact.
    3. **Delete** — only after a successful checksum match is the source
       file removed.

    This sequencing ensures the source is **never deleted** unless a
    complete, verified copy exists at the destination.

    Args:
        source:
            Path to the file to move. Must exist and be a regular file.
        target_dir:
            Directory to move the file into. Must exist.
        overwrite:
            Whether to overwrite the file if it already exists in
            ``target_dir``. Defaults to ``False``.
        required_partial_path:
            Required when ``overwrite=True``. A path fragment that must
            appear as a substring of ``target_dir`` (but must not be
            identical to it), acting as a deliberate confirmation that the
            caller knows which directory they are overwriting into.

            Example — if ``target_dir`` is ``/srv/apps/tmp/tools/deployment``
            you might pass ``required_partial_path="tmp/tools/deployment"``.

            Rules enforced:
              - Must be provided when ``overwrite=True``.
              - Must not be an empty string.
              - Must not equal ``target_dir`` exactly.
              - Must be a substring of the resolved ``target_dir`` string.
        new_name:
            Optional filename for the moved file. When omitted the source
            filename is preserved.
        dry_run:
            When ``True``, all validation checks and the source checksum
            computation are performed but **no file system modifications are
            made** — the source is not copied and not deleted.  Returns the
            path where the file *would* land.  Defaults to ``False``.

    Returns:
        The :class:`~pathlib.Path` of the file at its new location (or
        would-be location when ``dry_run=True``).

    Raises:
        ValueError:                 For invalid combinations of arguments
                                    (see ``required_partial_path`` rules).
        FSPlusFileNotFound:         If ``source`` does not exist or is not a
                                    regular file.
        FSPlusPathNotFound:         If ``target_dir`` does not exist or is not
                                    a directory.
        FSPlusInvalidPath:          If ``new_name`` contains path separators.
        FSPlusPathTraversal:        If the resolved destination escapes
                                    ``target_dir``.
        FSPlusFileAlreadyExists:    If the destination file exists and
                                    ``overwrite=False``.
        FSPlusChecksumMismatch:     If the SHA-256 digest of the copy does not
                                    match the source. The partial copy is
                                    removed and the source is left untouched.
                                    (Never raised when ``dry_run=True``.)
    """
    source = Path(source).resolve()
    target_dir = Path(target_dir).resolve()

    # ------------------------------------------------------------------
    # 1. Validate source
    # ------------------------------------------------------------------
    if not source.exists():
        raise FSPlusFileNotFound(path=source)
    if not source.is_file():
        raise FSPlusFileNotFound(
            "Source path exists but is not a regular file.",
            path=source,
        )

    # ------------------------------------------------------------------
    # 2. Validate target directory
    # ------------------------------------------------------------------
    if not target_dir.exists():
        raise FSPlusPathNotFound(path=target_dir)
    if not target_dir.is_dir():
        raise FSPlusPathNotFound(
            "Target path exists but is not a directory.",
            path=target_dir,
        )

    # ------------------------------------------------------------------
    # 3. Validate overwrite + required_partial_path
    # ------------------------------------------------------------------
    if overwrite:
        if not required_partial_path:
            raise ValueError(
                "required_partial_path must be provided and non-empty when overwrite=True. "
                "Supply a unique fragment of target_dir to confirm the intended destination."
            )

        target_dir_str = str(target_dir)

        if required_partial_path == target_dir_str:
            raise ValueError(
                "required_partial_path must not be identical to target_dir. "
                "It must be a distinctive sub-fragment of the path, not the full path itself."
            )

        if required_partial_path not in target_dir_str:
            raise FSPlusPathTraversal(
                f"required_partial_path {required_partial_path!r} was not found "
                f"in the resolved target directory.",
                path=target_dir,
                root=required_partial_path,
            )

    # ------------------------------------------------------------------
    # 4. Resolve destination filename
    # ------------------------------------------------------------------
    if new_name is not None:
        if "/" in new_name or "\\" in new_name:
            raise FSPlusInvalidPath(
                "new_name must be a plain filename without path separators.",
                path=new_name,
            )
        dest_name = new_name
    else:
        dest_name = source.name

    destination = (target_dir / dest_name).resolve()

    # ------------------------------------------------------------------
    # 5. Traversal guard — destination must stay inside target_dir
    # ------------------------------------------------------------------
    try:
        destination.relative_to(target_dir)
    except ValueError:
        raise FSPlusPathTraversal(
            "Resolved destination escapes the target directory.",
            path=destination,
            root=target_dir,
        )

    # ------------------------------------------------------------------
    # 6. Overwrite guard
    # ------------------------------------------------------------------
    if destination.exists() and not overwrite:
        raise FSPlusFileAlreadyExists(path=destination)

    # ------------------------------------------------------------------
    # 7. Compute source checksum before touching anything
    # ------------------------------------------------------------------
    source_checksum = _sha256(source)

    # ------------------------------------------------------------------
    # 8. Dry-run exit — all validation passed; return would-be destination
    # ------------------------------------------------------------------
    if dry_run:
        return destination

    # ------------------------------------------------------------------
    # 9. Copy
    # ------------------------------------------------------------------
    shutil.copy2(source, destination)

    # ------------------------------------------------------------------
    # 10. Verify — compare checksums; roll back the copy on mismatch
    # ------------------------------------------------------------------
    destination_checksum = _sha256(destination)

    if source_checksum != destination_checksum:
        # Remove the corrupt/incomplete copy, leave source intact.
        destination.unlink(missing_ok=True)
        raise FSPlusChecksumMismatch(
            "Checksum of the copied file does not match the source. "
            "The partial copy has been removed; the source file is untouched.",
            path=destination,
            expected=source_checksum,
            actual=destination_checksum,
        )

    # ------------------------------------------------------------------
    # 11. Delete source — only reached after a verified copy
    # ------------------------------------------------------------------
    source.unlink()
    return destination
