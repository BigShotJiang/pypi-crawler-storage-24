"""
fsplus.fsplus_copy
~~~~~~~~~~~~~~~~~~
Safe file copy operation for fsplus.
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Optional

from fsplus.exceptions import (
    FSPlusFileAlreadyExists,
    FSPlusFileNotFound,
    FSPlusInvalidPath,
    FSPlusPathNotFound,
    FSPlusPathTraversal,
)


def copy_file(
    source: str | Path,
    target_dir: str | Path,
    *,
    overwrite: bool = False,
    required_partial_path: Optional[str] = None,
    new_name: Optional[str] = None,
) -> Path:
    """Copy a file to a target directory.

    Args:
        source:
            Path to the file to copy. Must exist and be a regular file.
        target_dir:
            Directory to copy the file into. Must exist.
        overwrite:
            Whether to overwrite the file if it already exists in ``target_dir``.
            Defaults to ``False``.
        required_partial_path:
            Required when ``overwrite=True``. A path fragment that must appear
            as a substring of ``target_dir`` (but must not be identical to it),
            acting as a deliberate confirmation that the caller knows which
            directory they are overwriting into.

            Example — if ``target_dir`` is ``/srv/apps/tmp/tools/deployment``
            you might pass ``required_partial_path="tmp/tools/deployment"``.

            Rules enforced:
              - Must be provided when ``overwrite=True``.
              - Must not be an empty string.
              - Must not equal ``target_dir`` exactly (prevents the caller from
                lazily passing the same variable for both arguments).
              - Must be a substring of the resolved ``target_dir`` string.
        new_name:
            Optional filename for the copy. When omitted the source filename
            is preserved.

    Returns:
        The :class:`~pathlib.Path` of the newly written file.

    Raises:
        ValueError:                 For invalid combinations of arguments (see
                                    ``required_partial_path`` rules above).
        FSPlusFileNotFound:         If ``source`` does not exist or is not a file.
        FSPlusPathNotFound:         If ``target_dir`` does not exist or is not a
                                    directory.
        FSPlusInvalidPath:          If ``new_name`` contains path separators.
        FSPlusPathTraversal:        If the resolved destination escapes
                                    ``target_dir``.
        FSPlusFileAlreadyExists:    If the destination file exists and
                                    ``overwrite=False``.
    """
    source = Path(source).resolve()
    target_dir = Path(target_dir).resolve()

    # ------------------------------------------------------------------
    # 1. Validate source
    # ------------------------------------------------------------------
    if not source.exists():
        raise FSPlusFileNotFound(path=source)
    if not source.is_file():
        raise FSPlusFileNotFound(
            "Source path exists but is not a regular file.",
            path=source,
        )

    # ------------------------------------------------------------------
    # 2. Validate target directory
    # ------------------------------------------------------------------
    if not target_dir.exists():
        raise FSPlusPathNotFound(path=target_dir)
    if not target_dir.is_dir():
        raise FSPlusPathNotFound(
            "Target path exists but is not a directory.",
            path=target_dir,
        )

    # ------------------------------------------------------------------
    # 3. Validate overwrite + required_partial_path
    # ------------------------------------------------------------------
    if overwrite:
        if not required_partial_path:
            raise ValueError(
                "required_partial_path must be provided and non-empty when overwrite=True. "
                "Supply a unique fragment of target_dir to confirm the intended destination."
            )

        target_dir_str = str(target_dir)

        if required_partial_path == target_dir_str:
            raise ValueError(
                "required_partial_path must not be identical to target_dir. "
                "It must be a distinctive sub-fragment of the path, not the full path itself."
            )

        if required_partial_path not in target_dir_str:
            raise FSPlusPathTraversal(
                f"required_partial_path {required_partial_path!r} was not found "
                f"in the resolved target directory.",
                path=target_dir,
                root=required_partial_path,
            )

    # ------------------------------------------------------------------
    # 4. Resolve destination filename
    # ------------------------------------------------------------------
    if new_name is not None:
        if "/" in new_name or "\\" in new_name:
            raise FSPlusInvalidPath(
                "new_name must be a plain filename without path separators.",
                path=new_name,
            )
        dest_name = new_name
    else:
        dest_name = source.name

    destination = (target_dir / dest_name).resolve()

    # ------------------------------------------------------------------
    # 5. Traversal guard — destination must stay inside target_dir
    # ------------------------------------------------------------------
    try:
        destination.relative_to(target_dir)
    except ValueError:
        raise FSPlusPathTraversal(
            "Resolved destination escapes the target directory.",
            path=destination,
            root=target_dir,
        )

    # ------------------------------------------------------------------
    # 6. Overwrite guard
    # ------------------------------------------------------------------
    if destination.exists() and not overwrite:
        raise FSPlusFileAlreadyExists(path=destination)

    # ------------------------------------------------------------------
    # 7. Copy
    # ------------------------------------------------------------------
    shutil.copy2(source, destination)
    return destination
