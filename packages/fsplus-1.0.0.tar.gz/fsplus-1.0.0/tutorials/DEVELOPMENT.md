# Development Setup — fsplus

## Prerequisites

- Python 3.10 or newer
- `pip` (bundled with Python)
- Recommended: a virtual environment tool (`venv`, `virtualenv`, or `conda`)

---

## 1. Clone the repository

```bash
git clone https://github.com/justTil/fsplus.git
cd fsplus
```

---

## 2. Create and activate a virtual environment

```bash
# Create
python -m venv .venv

# Activate — Linux / macOS
source .venv/bin/activate

# Activate — Windows (PowerShell)
.venv\Scripts\Activate.ps1
```

---

## 3. Install in editable (development) mode

The `-e` flag installs the package as a live symlink into your environment.
Any change you make to `src/fsplus/` is immediately reflected — no reinstall needed.

```bash
# Core package only
pip install -e .

# Core package + all development tools (pytest, black, mypy, mkdocs, …)
pip install -e ".[dev]"

# Core package + docs dependencies only
pip install -e ".[cf_docs]"
```

> **What `-e` does**
> Instead of copying files into `site-packages`, pip writes a `.pth` file that
> points directly at `src/`. Edits to source files are active immediately.

---

## 4. Verify the installation

```bash
# Package is importable
python -c "import fsplus; print(fsplus.__version__)"

# CLI entry point is available
fsplus --help
```

---

## 5. Run the test suite

```bash
# All tests with coverage report
pytest

# Specific module
pytest tests/test_copy.py
pytest tests/test_move.py
pytest tests/test_delete.py

# Verbose output
pytest -v
```

---

## 6. Code style & type checking

```bash
# Auto-format
black src/ tests/

# Sort imports
isort src/ tests/

# Lint
flake8 src/ tests/

# Type-check
mypy src/
```

---

## 7. Build the docs locally

```bash
# Serve with live reload at http://127.0.0.1:8000
mkdocs serve

# Build static site into site/
mkdocs build
```

---

## Project layout

```
fsplus/
├── src/
│   └── fsplus/
│       ├── __init__.py        # version + public re-exports
│       ├── cli.py             # fsplus CLI entry point
│       ├── exceptions.py      # custom exception hierarchy
│       ├── fsplus_copy.py     # copy_file()
│       ├── fsplus_move.py     # move_file()
│       └── fsplus_delete.py   # delete_file()
├── tests/
│   ├── test_copy.py
│   ├── test_move.py
│   └── test_delete.py
├── docs/                      # MkDocs source
├── pyproject.toml
└── README.md
```

---

## Uninstalling

```bash
pip uninstall fsplus
```