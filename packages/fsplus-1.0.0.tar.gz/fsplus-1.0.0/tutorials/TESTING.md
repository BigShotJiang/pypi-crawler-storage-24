python run_tests.py                          # all 43 tests
python run_tests.py -k overwrite             # only overwrite tests
python run_tests.py tests/test_copy_happy_path.py   # single file
python run_tests.py -x                       # stop on first failure