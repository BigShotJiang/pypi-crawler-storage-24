"""
tests.test_delete_system_path_protection
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests for the system-path blocklist in fsplus.clear_directory and
fsplus.delete_directory.

Strategy
--------
We need to call the real functions with real, existing directories so that
the existence-check (step 1) passes.  But we also need to simulate the
function seeing a blocked path.

**Wrong approach (previous version):** patching ``Path.resolve`` globally.
That breaks ``target_dir.exists()`` / ``target_dir.is_dir()`` too, because
they all call ``resolve`` internally — so the existence check fires first
and raises ``FSPlusPathNotFound`` instead of ``FSPlusSystemPathBlocked``.

**Correct approach:** patch ``fsplus.fsplus_delete._check_system_path``
to raise ``FSPlusSystemPathBlocked`` unconditionally (for "blocked" tests)
or with a specific path+prefix (for attribute tests).  The real directory
passes step 1 cleanly; our replacement raises the right exception at step 2.

For "not blocked" assertions we patch ``_check_system_path`` to a no-op and
verify no ``FSPlusSystemPathBlocked`` is raised.

Covers:
  - Well-known blocked prefixes raise FSPlusSystemPathBlocked
  - Exception carries the matched prefix and the path
  - Exact prefix match (/etc, /usr) is blocked
  - Paths sharing only a prefix *substring* (/option vs /opt) are NOT blocked
  - Real tmp_path dirs are never blocked by the live implementation
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from fsplus.fsplus_delete import (
    clear_directory,
    delete_directory,
    FSPlusSystemPathBlocked,
    _check_system_path,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _real_dir(tmp_path: Path, name: str = "target") -> Path:
    d = tmp_path / name
    d.mkdir(exist_ok=True)
    return d


def _blocked(path: str, prefix: str):
    """Return a patch that makes _check_system_path raise FSPlusSystemPathBlocked."""
    exc = FSPlusSystemPathBlocked(path=path, prefix=prefix)
    return patch("fsplus.fsplus_delete._check_system_path", side_effect=exc)


def _no_check():
    """Return a patch that makes _check_system_path a no-op."""
    return patch("fsplus.fsplus_delete._check_system_path", return_value=None)


# ---------------------------------------------------------------------------
# clear_directory — system path protection
# ---------------------------------------------------------------------------


class TestClearDirectorySystemPathBlocked:
    """clear_directory raises FSPlusSystemPathBlocked for protected paths."""

    @pytest.mark.parametrize(
        "blocked_path, prefix",
        [
            ("/etc/someapp", "/etc"),
            ("/usr/local/bin", "/usr"),
            ("/var/log", "/var"),
            ("/bin", "/bin"),
            ("/tmp/workdir", "/tmp"),
        ],
    )
    def test_blocked_prefix_raises(
        self, tmp_path: Path, blocked_path: str, prefix: str
    ) -> None:
        d = _real_dir(tmp_path)
        with _blocked(blocked_path, prefix):
            with pytest.raises(FSPlusSystemPathBlocked):
                clear_directory(d, dry_run=True)

    def test_exception_carries_matched_prefix(self, tmp_path: Path) -> None:
        d = _real_dir(tmp_path)
        with _blocked("/etc/myapp/config", "/etc"):
            with pytest.raises(FSPlusSystemPathBlocked) as exc_info:
                clear_directory(d, dry_run=True)
        assert exc_info.value.prefix == "/etc"

    def test_exception_carries_path(self, tmp_path: Path) -> None:
        d = _real_dir(tmp_path)
        fake = "/usr/share/myapp"
        with _blocked(fake, "/usr"):
            with pytest.raises(FSPlusSystemPathBlocked) as exc_info:
                clear_directory(d, dry_run=True)
        assert exc_info.value.path == Path(fake)

    def test_exact_prefix_match_blocked(self, tmp_path: Path) -> None:
        d = _real_dir(tmp_path)
        with _blocked("/etc", "/etc"):
            with pytest.raises(FSPlusSystemPathBlocked):
                clear_directory(d, dry_run=True)

    def test_check_system_path_called_with_resolved_dir(
        self, tmp_path: Path
    ) -> None:
        """_check_system_path must receive the *resolved* target path."""
        d = _real_dir(tmp_path)
        with patch(
            "fsplus.fsplus_delete._check_system_path"
        ) as mock_check:
            clear_directory(d, dry_run=True)
        mock_check.assert_called_once_with(d.resolve())


class TestClearDirectorySystemPathNotBlocked:
    """Paths that merely share a prefix substring must not be blocked."""

    def test_option_not_blocked_by_opt(self, tmp_path: Path) -> None:
        """/option should not be blocked by the /opt entry."""
        d = _real_dir(tmp_path)
        # Call the *real* _check_system_path with a path that starts with
        # /option — it must not raise FSPlusSystemPathBlocked.
        from fsplus.fsplus_delete import _check_system_path as real_check
        try:
            real_check(Path("/option/myapp"))
        except FSPlusSystemPathBlocked:
            pytest.fail("/option was incorrectly blocked by /opt prefix")

    def test_tmp_path_not_blocked_with_no_op_check(self, tmp_path: Path) -> None:
        """Verify the rest of the pipeline works when system-path check is skipped."""
        d = _real_dir(tmp_path)
        (d / "f.txt").write_text("data")
        with _no_check():
            result = clear_directory(d, dry_run=True)
        assert result == 1


# ---------------------------------------------------------------------------
# delete_directory — system path protection
# ---------------------------------------------------------------------------


class TestDeleteDirectorySystemPathBlocked:
    """delete_directory raises FSPlusSystemPathBlocked for protected paths."""

    @pytest.mark.parametrize(
        "blocked_path, prefix",
        [
            ("/etc/someapp", "/etc"),
            ("/usr/local/bin", "/usr"),
            ("/var/log", "/var"),
            ("/bin", "/bin"),
            ("/tmp/workdir", "/tmp"),
        ],
    )
    def test_blocked_prefix_raises(
        self, tmp_path: Path, blocked_path: str, prefix: str
    ) -> None:
        d = _real_dir(tmp_path)
        with _blocked(blocked_path, prefix):
            with pytest.raises(FSPlusSystemPathBlocked):
                delete_directory(d, dry_run=True)

    def test_exception_carries_matched_prefix(self, tmp_path: Path) -> None:
        d = _real_dir(tmp_path)
        with _blocked("/var/lib/myservice", "/var"):
            with pytest.raises(FSPlusSystemPathBlocked) as exc_info:
                delete_directory(d, dry_run=True)
        assert exc_info.value.prefix == "/var"

    def test_exception_carries_path(self, tmp_path: Path) -> None:
        d = _real_dir(tmp_path)
        fake = "/usr/local/share"
        with _blocked(fake, "/usr"):
            with pytest.raises(FSPlusSystemPathBlocked) as exc_info:
                delete_directory(d, dry_run=True)
        assert exc_info.value.path == Path(fake)

    def test_exact_prefix_match_blocked(self, tmp_path: Path) -> None:
        d = _real_dir(tmp_path)
        with _blocked("/usr", "/usr"):
            with pytest.raises(FSPlusSystemPathBlocked):
                delete_directory(d, dry_run=True)

    def test_check_system_path_called_with_resolved_dir(
        self, tmp_path: Path
    ) -> None:
        d = _real_dir(tmp_path)
        with patch(
            "fsplus.fsplus_delete._check_system_path"
        ) as mock_check:
            delete_directory(d, dry_run=True)
        mock_check.assert_called_once_with(d.resolve())


class TestDeleteDirectorySystemPathNotBlocked:
    """Paths that merely share a prefix substring must not be blocked."""

    def test_option_not_blocked_by_opt(self) -> None:
        from fsplus.fsplus_delete import _check_system_path as real_check
        try:
            real_check(Path("/option/myapp"))
        except FSPlusSystemPathBlocked:
            pytest.fail("/option was incorrectly blocked by /opt prefix")

    def test_tmp_path_not_blocked_with_no_op_check(self, tmp_path: Path) -> None:
        d = _real_dir(tmp_path)
        with _no_check():
            result = delete_directory(d, dry_run=True)
        assert result == d.resolve()
