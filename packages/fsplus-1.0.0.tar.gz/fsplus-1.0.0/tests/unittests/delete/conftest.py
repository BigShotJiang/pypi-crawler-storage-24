"""
tests.conftest
~~~~~~~~~~~~~~
Shared pytest fixtures for the fsplus delete function test suite.
"""

from __future__ import annotations

from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# Basic directory fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def empty_dir(tmp_path: Path) -> Path:
    """An empty directory with no contents."""
    d = tmp_path / "target"
    d.mkdir()
    return d


@pytest.fixture()
def dir_with_files(tmp_path: Path) -> Path:
    """A directory containing a few regular files (within default max_files=10)."""
    d = tmp_path / "target"
    d.mkdir()
    for i in range(3):
        (d / f"file_{i}.txt").write_text(f"content {i}")
    return d


@pytest.fixture()
def dir_with_subdirs(tmp_path: Path) -> Path:
    """A directory containing files and nested subdirectories."""
    d = tmp_path / "target"
    d.mkdir()
    (d / "top_file.txt").write_text("top")
    sub = d / "subdir"
    sub.mkdir()
    (sub / "nested_file.txt").write_text("nested")
    return d


@pytest.fixture()
def dir_exceeding_limit(tmp_path: Path) -> Path:
    """A directory containing more than the default max_files=10 files."""
    d = tmp_path / "target"
    d.mkdir()
    for i in range(15):
        (d / f"file_{i}.txt").write_text(f"content {i}")
    return d
