"""
tests.test_delete_target_validation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests for target-path validation in fsplus.clear_directory and
fsplus.delete_directory.

Strategy
--------
Validation errors (missing path, file-as-target) are raised before the
system-path check, so ``dry_run`` is not needed here — but we still pass
it to future-proof against ordering changes.  The tests use ``dry_run=True``
to avoid touching real directories even in the non-error cases.

Covers:
  - Target does not exist         → FSPlusPathNotFound
  - Target is a file, not a dir  → FSPlusPathNotFound
  - Exception carries the path
  - Error message is descriptive for the file-as-target case
"""

from __future__ import annotations

from pathlib import Path

import pytest

from fsplus.fsplus_delete import clear_directory, delete_directory
from fsplus.exceptions import FSPlusPathNotFound


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _missing(tmp_path: Path) -> Path:
    return tmp_path / "ghost_dir"


# ---------------------------------------------------------------------------
# clear_directory — target not found
# ---------------------------------------------------------------------------


class TestClearDirectoryTargetNotFound:
    """clear_directory raises FSPlusPathNotFound when the target is missing."""

    def test_missing_target_raises(self, tmp_path: Path) -> None:
        with pytest.raises(FSPlusPathNotFound):
            clear_directory(_missing(tmp_path))

    def test_missing_target_exception_carries_path(self, tmp_path: Path) -> None:
        missing = _missing(tmp_path)
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            clear_directory(missing)
        assert exc_info.value.path == missing.resolve()

    def test_missing_target_as_string_raises(self, tmp_path: Path) -> None:
        with pytest.raises(FSPlusPathNotFound):
            clear_directory(str(_missing(tmp_path)))


# ---------------------------------------------------------------------------
# clear_directory — target exists but is a file
# ---------------------------------------------------------------------------


class TestClearDirectoryTargetNotADirectory:
    """clear_directory raises FSPlusPathNotFound when target is a regular file."""

    def test_file_target_raises(self, tmp_path: Path) -> None:
        f = tmp_path / "not_a_dir.txt"
        f.write_text("I am a file")
        with pytest.raises(FSPlusPathNotFound):
            clear_directory(f)

    def test_file_target_exception_carries_path(self, tmp_path: Path) -> None:
        f = tmp_path / "not_a_dir.txt"
        f.write_text("I am a file")
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            clear_directory(f)
        assert exc_info.value.path == f.resolve()

    def test_file_target_message_is_descriptive(self, tmp_path: Path) -> None:
        f = tmp_path / "not_a_dir.txt"
        f.write_text("I am a file")
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            clear_directory(f)
        assert "not a directory" in str(exc_info.value).lower()


# ---------------------------------------------------------------------------
# delete_directory — target not found
# ---------------------------------------------------------------------------


class TestDeleteDirectoryTargetNotFound:
    """delete_directory raises FSPlusPathNotFound when the target is missing."""

    def test_missing_target_raises(self, tmp_path: Path) -> None:
        with pytest.raises(FSPlusPathNotFound):
            delete_directory(_missing(tmp_path))

    def test_missing_target_exception_carries_path(self, tmp_path: Path) -> None:
        missing = _missing(tmp_path)
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            delete_directory(missing)
        assert exc_info.value.path == missing.resolve()

    def test_missing_target_as_string_raises(self, tmp_path: Path) -> None:
        with pytest.raises(FSPlusPathNotFound):
            delete_directory(str(_missing(tmp_path)))


# ---------------------------------------------------------------------------
# delete_directory — target exists but is a file
# ---------------------------------------------------------------------------


class TestDeleteDirectoryTargetNotADirectory:
    """delete_directory raises FSPlusPathNotFound when target is a regular file."""

    def test_file_target_raises(self, tmp_path: Path) -> None:
        f = tmp_path / "not_a_dir.txt"
        f.write_text("I am a file")
        with pytest.raises(FSPlusPathNotFound):
            delete_directory(f)

    def test_file_target_exception_carries_path(self, tmp_path: Path) -> None:
        f = tmp_path / "not_a_dir.txt"
        f.write_text("I am a file")
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            delete_directory(f)
        assert exc_info.value.path == f.resolve()

    def test_file_target_message_is_descriptive(self, tmp_path: Path) -> None:
        f = tmp_path / "not_a_dir.txt"
        f.write_text("I am a file")
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            delete_directory(f)
        assert "not a directory" in str(exc_info.value).lower()
