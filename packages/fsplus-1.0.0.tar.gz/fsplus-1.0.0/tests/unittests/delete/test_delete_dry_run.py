"""
tests.test_delete_dry_run
~~~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests specifically for the ``dry_run=True`` behaviour of
fsplus.clear_directory and fsplus.delete_directory.

These tests verify the contract that ``dry_run=True`` runs all validation
checks but never modifies the file system.

Covers:
  - Return types and values match the live call contract
  - File system is fully intact after a dry_run call
  - All validation errors are still raised under dry_run
    (missing target, file-as-target, system-path block,
     required_partial_path violations, file-limit exceeded)
  - dry_run=False is the default (live call removes files)
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from fsplus.fsplus_delete import (
    clear_directory,
    delete_directory,
    FSPlusSystemPathBlocked,
    FSPlusFileLimitExceeded,
)
from fsplus.exceptions import FSPlusPathNotFound, FSPlusPathTraversal


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

_no_system_check = patch(
    "fsplus.fsplus_delete._check_system_path",
    return_value=None,
)


# ---------------------------------------------------------------------------
# clear_directory — dry_run contract
# ---------------------------------------------------------------------------


class TestClearDirectoryDryRun:
    """dry_run=True on clear_directory: correct return value, no fs changes."""

    def test_returns_int(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        (d / "a.txt").write_text("x")
        result = clear_directory(d, dry_run=True)
        assert isinstance(result, int)

    def test_returns_top_level_count(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        for i in range(4):
            (d / f"f{i}.txt").write_text(str(i))
        result = clear_directory(d, dry_run=True)
        assert result == 4

    def test_subdirs_counted_as_single_entry(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        sub = d / "sub"
        sub.mkdir()
        (sub / "nested.txt").write_text("n")
        # 1 top-level entry (the subdir), regardless of how many files inside
        result = clear_directory(d, dry_run=True)
        assert result == 1

    def test_files_not_deleted(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        f = d / "keep.txt"
        f.write_text("keep")
        clear_directory(d, dry_run=True)
        assert f.exists()
        assert f.read_text() == "keep"

    def test_directory_node_not_removed(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        clear_directory(d, dry_run=True)
        assert d.exists()

    def test_default_is_live(self, tmp_path: Path) -> None:
        """Omitting dry_run must perform the actual deletion."""
        d = tmp_path / "t"
        d.mkdir()
        f = d / "gone.txt"
        f.write_text("bye")
        with _no_system_check:
            clear_directory(d)
        assert not f.exists()


# ---------------------------------------------------------------------------
# clear_directory — validation errors still fire under dry_run
# ---------------------------------------------------------------------------


class TestClearDirectoryDryRunValidation:
    """Validation errors are raised even with dry_run=True."""

    def test_missing_target_raises(self, tmp_path: Path) -> None:
        with pytest.raises(FSPlusPathNotFound):
            clear_directory(tmp_path / "ghost", dry_run=True)

    def test_file_as_target_raises(self, tmp_path: Path) -> None:
        f = tmp_path / "file.txt"
        f.write_text("x")
        with pytest.raises(FSPlusPathNotFound):
            clear_directory(f, dry_run=True)

    def test_system_path_blocked_raises(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        exc = FSPlusSystemPathBlocked(path="/etc/x", prefix="/etc")
        with patch(
            "fsplus.fsplus_delete._check_system_path", side_effect=exc
        ):
            with pytest.raises(FSPlusSystemPathBlocked):
                clear_directory(d, dry_run=True)

    def test_file_limit_exceeded_raises(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        for i in range(11):
            (d / f"f{i}.txt").write_text(str(i))
        with pytest.raises(FSPlusFileLimitExceeded):
            clear_directory(d, dry_run=True)

    def test_invalid_partial_path_raises(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        with pytest.raises(FSPlusPathTraversal):
            clear_directory(d, required_partial_path="no_match_xyz", dry_run=True)


# ---------------------------------------------------------------------------
# delete_directory — dry_run contract
# ---------------------------------------------------------------------------


class TestDeleteDirectoryDryRun:
    """dry_run=True on delete_directory: correct return value, no fs changes."""

    def test_returns_path(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        result = delete_directory(d, dry_run=True)
        assert isinstance(result, Path)

    def test_returns_resolved_path(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        result = delete_directory(d, dry_run=True)
        assert result == d.resolve()

    def test_directory_not_deleted(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        (d / "keep.txt").write_text("keep")
        delete_directory(d, dry_run=True)
        assert d.exists()

    def test_contents_not_deleted(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        f = d / "keep.txt"
        f.write_text("keep")
        delete_directory(d, dry_run=True)
        assert f.exists()

    def test_default_is_live(self, tmp_path: Path) -> None:
        """Omitting dry_run must perform the actual deletion."""
        d = tmp_path / "t"
        d.mkdir()
        (d / "f.txt").write_text("x")
        with _no_system_check:
            delete_directory(d)
        assert not d.exists()


# ---------------------------------------------------------------------------
# delete_directory — validation errors still fire under dry_run
# ---------------------------------------------------------------------------


class TestDeleteDirectoryDryRunValidation:
    """Validation errors are raised even with dry_run=True."""

    def test_missing_target_raises(self, tmp_path: Path) -> None:
        with pytest.raises(FSPlusPathNotFound):
            delete_directory(tmp_path / "ghost", dry_run=True)

    def test_file_as_target_raises(self, tmp_path: Path) -> None:
        f = tmp_path / "file.txt"
        f.write_text("x")
        with pytest.raises(FSPlusPathNotFound):
            delete_directory(f, dry_run=True)

    def test_system_path_blocked_raises(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        exc = FSPlusSystemPathBlocked(path="/usr/x", prefix="/usr")
        with patch(
            "fsplus.fsplus_delete._check_system_path", side_effect=exc
        ):
            with pytest.raises(FSPlusSystemPathBlocked):
                delete_directory(d, dry_run=True)

    def test_file_limit_exceeded_raises(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        for i in range(11):
            (d / f"f{i}.txt").write_text(str(i))
        with pytest.raises(FSPlusFileLimitExceeded):
            delete_directory(d, dry_run=True)

    def test_invalid_partial_path_raises(self, tmp_path: Path) -> None:
        d = tmp_path / "t"
        d.mkdir()
        with pytest.raises(FSPlusPathTraversal):
            delete_directory(d, required_partial_path="no_match_xyz", dry_run=True)
