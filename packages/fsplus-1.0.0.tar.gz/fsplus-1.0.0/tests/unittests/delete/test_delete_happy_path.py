"""
tests.test_delete_happy_path
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Integration-style unit tests for the successful execution paths of
fsplus.clear_directory and fsplus.delete_directory.

Strategy
--------
pytest's ``tmp_path`` resolves through ``/private/var/...`` on macOS, which
is covered by the ``/private`` system-path blocklist.  All tests that only
need to verify *return values*, *validation logic*, or *what would be deleted*
use ``dry_run=True`` so they pass on every platform without touching the real
file system.

Tests that specifically verify *actual deletion* (file gone, directory gone,
content wiped) use ``dry_run=False`` but patch ``_check_system_path`` to a
no-op so the real temp directory is reachable on all platforms.

Covers:
  - Basic clearing / deletion return values (dry_run)
  - Actual deletion post-conditions (patched system-path check)
  - Source directory node preserved after clear_directory
  - Directory entirely gone after delete_directory
  - Nested subdirectories are removed
  - Empty directories work
  - String paths are accepted
  - required_partial_path accepted when valid
  - Custom max_files allows larger trees
  - Symlinks inside are handled correctly
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from fsplus.fsplus_delete import clear_directory, delete_directory

# ---------------------------------------------------------------------------
# Helper: suppress system-path guard so real tmp dirs work on all platforms
# ---------------------------------------------------------------------------

_no_system_check = patch(
    "fsplus.fsplus_delete._check_system_path",
    return_value=None,
)


# ---------------------------------------------------------------------------
# clear_directory — return-value tests (dry_run, no fs side-effects needed)
# ---------------------------------------------------------------------------


class TestClearDirectoryReturnValues:
    """clear_directory return values are correct (verified via dry_run)."""

    def test_returns_count_of_entries(self, dir_with_files: Path) -> None:
        # dir_with_files has 3 top-level files
        result = clear_directory(dir_with_files, dry_run=True)
        assert result == 3

    def test_returns_zero_for_empty_directory(self, empty_dir: Path) -> None:
        result = clear_directory(empty_dir, dry_run=True)
        assert result == 0

    def test_returns_int(self, dir_with_files: Path) -> None:
        result = clear_directory(dir_with_files, dry_run=True)
        assert isinstance(result, int)

    def test_accepts_string_path(self, dir_with_files: Path) -> None:
        result = clear_directory(str(dir_with_files), dry_run=True)
        assert result == 3

    def test_nested_entries_counted_at_top_level(
        self, dir_with_subdirs: Path
    ) -> None:
        # dir_with_subdirs has 1 file + 1 subdir at the top level → 2
        result = clear_directory(dir_with_subdirs, dry_run=True)
        assert result == 2


# ---------------------------------------------------------------------------
# clear_directory — actual deletion (system-path check patched out)
# ---------------------------------------------------------------------------


class TestClearDirectoryActualDeletion:
    """clear_directory really wipes contents and leaves the directory node."""

    def test_directory_is_empty_afterwards(self, dir_with_files: Path) -> None:
        with _no_system_check:
            clear_directory(dir_with_files)
        assert list(dir_with_files.iterdir()) == []

    def test_directory_node_still_exists(self, dir_with_files: Path) -> None:
        with _no_system_check:
            clear_directory(dir_with_files)
        assert dir_with_files.exists()
        assert dir_with_files.is_dir()

    def test_nested_subdirectory_removed(self, dir_with_subdirs: Path) -> None:
        with _no_system_check:
            clear_directory(dir_with_subdirs)
        assert list(dir_with_subdirs.iterdir()) == []

    def test_dry_run_leaves_contents_intact(self, dir_with_files: Path) -> None:
        original = set(p.name for p in dir_with_files.iterdir())
        clear_directory(dir_with_files, dry_run=True)
        assert set(p.name for p in dir_with_files.iterdir()) == original


# ---------------------------------------------------------------------------
# clear_directory — symlinks
# ---------------------------------------------------------------------------


class TestClearDirectorySymlinks:
    """clear_directory removes symlinks without touching their targets."""

    def test_symlink_removed(self, tmp_path: Path) -> None:
        d = tmp_path / "target"
        d.mkdir()
        real_file = tmp_path / "real.txt"
        real_file.write_text("real")
        (d / "link.txt").symlink_to(real_file)

        with _no_system_check:
            clear_directory(d)

        assert not (d / "link.txt").exists()
        assert real_file.exists()  # original untouched

    def test_symlink_counted_as_top_level_entry(self, tmp_path: Path) -> None:
        d = tmp_path / "target"
        d.mkdir()
        real_file = tmp_path / "real.txt"
        real_file.write_text("real")
        (d / "link.txt").symlink_to(real_file)

        result = clear_directory(d, dry_run=True)
        assert result == 1


# ---------------------------------------------------------------------------
# clear_directory — required_partial_path + custom max_files (dry_run)
# ---------------------------------------------------------------------------


class TestClearDirectoryOptions:
    """clear_directory honours valid required_partial_path and custom max_files."""

    def test_valid_partial_path_accepted(self, dir_with_files: Path) -> None:
        fragment = dir_with_files.name
        result = clear_directory(
            dir_with_files, required_partial_path=fragment, dry_run=True
        )
        assert result == 3

    def test_custom_max_files_allows_larger_tree(
        self, dir_exceeding_limit: Path
    ) -> None:
        result = clear_directory(dir_exceeding_limit, max_files=20, dry_run=True)
        assert result == 15


# ---------------------------------------------------------------------------
# delete_directory — return-value tests (dry_run)
# ---------------------------------------------------------------------------


class TestDeleteDirectoryReturnValues:
    """delete_directory return value is the resolved path (verified via dry_run)."""

    def test_returns_path_object(self, dir_with_files: Path) -> None:
        result = delete_directory(dir_with_files, dry_run=True)
        assert isinstance(result, Path)

    def test_returns_resolved_path(self, dir_with_files: Path) -> None:
        result = delete_directory(dir_with_files, dry_run=True)
        assert result == dir_with_files.resolve()

    def test_accepts_string_path(self, dir_with_files: Path) -> None:
        result = delete_directory(str(dir_with_files), dry_run=True)
        assert isinstance(result, Path)

    def test_empty_directory_accepted(self, empty_dir: Path) -> None:
        result = delete_directory(empty_dir, dry_run=True)
        assert result == empty_dir.resolve()


# ---------------------------------------------------------------------------
# delete_directory — actual deletion (system-path check patched out)
# ---------------------------------------------------------------------------


class TestDeleteDirectoryActualDeletion:
    """delete_directory really removes the directory tree."""

    def test_directory_no_longer_exists(self, dir_with_files: Path) -> None:
        with _no_system_check:
            delete_directory(dir_with_files)
        assert not dir_with_files.exists()

    def test_nested_contents_removed(self, dir_with_subdirs: Path) -> None:
        with _no_system_check:
            delete_directory(dir_with_subdirs)
        assert not dir_with_subdirs.exists()

    def test_sibling_directories_untouched(self, tmp_path: Path) -> None:
        target = tmp_path / "to_delete"
        target.mkdir()
        (target / "file.txt").write_text("bye")
        sibling = tmp_path / "keep_me"
        sibling.mkdir()
        (sibling / "important.txt").write_text("important")

        with _no_system_check:
            delete_directory(target)

        assert not target.exists()
        assert sibling.exists()
        assert (sibling / "important.txt").read_text() == "important"

    def test_dry_run_leaves_directory_intact(self, dir_with_files: Path) -> None:
        delete_directory(dir_with_files, dry_run=True)
        assert dir_with_files.exists()


# ---------------------------------------------------------------------------
# delete_directory — options (dry_run)
# ---------------------------------------------------------------------------


class TestDeleteDirectoryOptions:
    """delete_directory honours valid required_partial_path and custom max_files."""

    def test_valid_partial_path_accepted(self, dir_with_files: Path) -> None:
        fragment = dir_with_files.name
        result = delete_directory(
            dir_with_files, required_partial_path=fragment, dry_run=True
        )
        assert isinstance(result, Path)

    def test_custom_max_files_allows_larger_tree(
        self, dir_exceeding_limit: Path
    ) -> None:
        result = delete_directory(dir_exceeding_limit, max_files=20, dry_run=True)
        assert result == dir_exceeding_limit.resolve()
