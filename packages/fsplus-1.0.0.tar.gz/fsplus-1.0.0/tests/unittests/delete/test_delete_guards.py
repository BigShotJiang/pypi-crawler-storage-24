"""
tests.test_delete_guards
~~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests for the two safety guards shared by fsplus.clear_directory and
fsplus.delete_directory:

1. File-count guard   — FSPlusFileLimitExceeded
2. required_partial_path validation — ValueError / FSPlusPathTraversal

Strategy
--------
On macOS, ``tmp_path`` resolves through ``/private/var/...``, which is
covered by the ``/private`` system-path blocklist.  Every test therefore
passes ``dry_run=True`` so we exercise the guard logic without ever reaching
the deletion step — and without needing to suppress the system-path check.

Both guards (file-count and required_partial_path) are checked *before* any
deletion, so ``dry_run`` does not affect whether they fire.

Covers:
  - Exceeding default limit (10) raises FSPlusFileLimitExceeded
  - Exception carries file_count, max_files, and path
  - Directory is left intact when limit is exceeded
  - Custom max_files threshold respected
  - Exactly at the limit is allowed (guard is strictly >)
  - required_partial_path: empty string → ValueError
  - required_partial_path: equals full resolved path → ValueError
  - required_partial_path: not found in path → FSPlusPathTraversal
  - required_partial_path: None (default) → no validation performed
  - Directory / files untouched when validation fails
"""

from __future__ import annotations

from pathlib import Path

import pytest

from fsplus.fsplus_delete import (
    clear_directory,
    delete_directory,
    FSPlusFileLimitExceeded,
)
from fsplus.exceptions import FSPlusPathTraversal


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _dir_with_n_files(base: Path, n: int, name: str = "target") -> Path:
    d = base / name
    d.mkdir()
    for i in range(n):
        (d / f"f{i}.txt").write_text(str(i))
    return d


# ---------------------------------------------------------------------------
# File-count guard — clear_directory
# ---------------------------------------------------------------------------


class TestClearDirectoryFileLimitExceeded:
    """clear_directory raises FSPlusFileLimitExceeded when file count > max_files."""

    def test_exceeding_default_limit_raises(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 11)  # 11 > default 10
        with pytest.raises(FSPlusFileLimitExceeded):
            clear_directory(d, dry_run=True)

    def test_directory_untouched_when_limit_exceeded(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 11)
        original = set(p.name for p in d.iterdir())
        with pytest.raises(FSPlusFileLimitExceeded):
            clear_directory(d, dry_run=True)
        assert set(p.name for p in d.iterdir()) == original

    def test_exception_carries_file_count(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 12)
        with pytest.raises(FSPlusFileLimitExceeded) as exc_info:
            clear_directory(d, dry_run=True)
        assert exc_info.value.file_count == 12

    def test_exception_carries_max_files(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 12)
        with pytest.raises(FSPlusFileLimitExceeded) as exc_info:
            clear_directory(d, max_files=5, dry_run=True)
        assert exc_info.value.max_files == 5

    def test_exception_carries_path(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 11)
        with pytest.raises(FSPlusFileLimitExceeded) as exc_info:
            clear_directory(d, dry_run=True)
        assert exc_info.value.path == d.resolve()

    def test_exactly_at_limit_is_allowed(self, tmp_path: Path) -> None:
        """Exactly max_files files must NOT raise (guard is strictly >)."""
        d = _dir_with_n_files(tmp_path, 10)
        result = clear_directory(d, max_files=10, dry_run=True)
        assert result == 10

    def test_custom_limit_respected(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 5)
        with pytest.raises(FSPlusFileLimitExceeded):
            clear_directory(d, max_files=3, dry_run=True)


# ---------------------------------------------------------------------------
# File-count guard — delete_directory
# ---------------------------------------------------------------------------


class TestDeleteDirectoryFileLimitExceeded:
    """delete_directory raises FSPlusFileLimitExceeded when file count > max_files."""

    def test_exceeding_default_limit_raises(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 11)
        with pytest.raises(FSPlusFileLimitExceeded):
            delete_directory(d, dry_run=True)

    def test_directory_untouched_when_limit_exceeded(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 11)
        with pytest.raises(FSPlusFileLimitExceeded):
            delete_directory(d, dry_run=True)
        assert d.exists()

    def test_exception_carries_file_count(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 13)
        with pytest.raises(FSPlusFileLimitExceeded) as exc_info:
            delete_directory(d, dry_run=True)
        assert exc_info.value.file_count == 13

    def test_exception_carries_max_files(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 13)
        with pytest.raises(FSPlusFileLimitExceeded) as exc_info:
            delete_directory(d, max_files=8, dry_run=True)
        assert exc_info.value.max_files == 8

    def test_exception_carries_path(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 11)
        with pytest.raises(FSPlusFileLimitExceeded) as exc_info:
            delete_directory(d, dry_run=True)
        assert exc_info.value.path == d.resolve()

    def test_exactly_at_limit_is_allowed(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 10)
        result = delete_directory(d, max_files=10, dry_run=True)
        assert d.exists()  # dry_run — nothing deleted
        assert isinstance(result, Path)

    def test_custom_limit_respected(self, tmp_path: Path) -> None:
        d = _dir_with_n_files(tmp_path, 5)
        with pytest.raises(FSPlusFileLimitExceeded):
            delete_directory(d, max_files=3, dry_run=True)


# ---------------------------------------------------------------------------
# required_partial_path — clear_directory
# ---------------------------------------------------------------------------


class TestClearDirectoryRequiredPartialPathValidation:
    """clear_directory validates required_partial_path before any deletion."""

    def test_empty_string_raises_value_error(self, tmp_path: Path) -> None:
        d = tmp_path / "target"
        d.mkdir()
        with pytest.raises(ValueError):
            clear_directory(d, required_partial_path="", dry_run=True)

    def test_full_path_raises_value_error(self, tmp_path: Path) -> None:
        d = tmp_path / "target"
        d.mkdir()
        with pytest.raises(ValueError):
            clear_directory(
                d,
                required_partial_path=str(d.resolve()),
                dry_run=True,
            )

    def test_fragment_not_in_path_raises_path_traversal(
        self, tmp_path: Path
    ) -> None:
        d = tmp_path / "target"
        d.mkdir()
        with pytest.raises(FSPlusPathTraversal):
            clear_directory(
                d,
                required_partial_path="definitely_not_in_path_xyz",
                dry_run=True,
            )

    def test_none_skips_validation(self, tmp_path: Path) -> None:
        """Default (None) must not perform any partial-path check."""
        d = tmp_path / "target"
        d.mkdir()
        (d / "file.txt").write_text("data")
        # Should not raise anything
        result = clear_directory(d, required_partial_path=None, dry_run=True)
        assert result == 1

    def test_directory_untouched_when_validation_fails(
        self, tmp_path: Path
    ) -> None:
        d = tmp_path / "target"
        d.mkdir()
        (d / "important.txt").write_text("keep me")
        with pytest.raises((ValueError, FSPlusPathTraversal)):
            clear_directory(
                d,
                required_partial_path="wrong_fragment_xyz",
                dry_run=True,
            )
        assert (d / "important.txt").exists()


# ---------------------------------------------------------------------------
# required_partial_path — delete_directory
# ---------------------------------------------------------------------------


class TestDeleteDirectoryRequiredPartialPathValidation:
    """delete_directory validates required_partial_path before any deletion."""

    def test_empty_string_raises_value_error(self, tmp_path: Path) -> None:
        d = tmp_path / "target"
        d.mkdir()
        with pytest.raises(ValueError):
            delete_directory(d, required_partial_path="", dry_run=True)

    def test_full_path_raises_value_error(self, tmp_path: Path) -> None:
        d = tmp_path / "target"
        d.mkdir()
        with pytest.raises(ValueError):
            delete_directory(
                d,
                required_partial_path=str(d.resolve()),
                dry_run=True,
            )

    def test_fragment_not_in_path_raises_path_traversal(
        self, tmp_path: Path
    ) -> None:
        d = tmp_path / "target"
        d.mkdir()
        with pytest.raises(FSPlusPathTraversal):
            delete_directory(
                d,
                required_partial_path="definitely_not_in_path_xyz",
                dry_run=True,
            )

    def test_none_skips_validation(self, tmp_path: Path) -> None:
        d = tmp_path / "target"
        d.mkdir()
        result = delete_directory(d, required_partial_path=None, dry_run=True)
        assert d.exists()  # dry_run — untouched
        assert isinstance(result, Path)

    def test_directory_untouched_when_validation_fails(
        self, tmp_path: Path
    ) -> None:
        d = tmp_path / "target"
        d.mkdir()
        (d / "important.txt").write_text("keep me")
        with pytest.raises((ValueError, FSPlusPathTraversal)):
            delete_directory(
                d,
                required_partial_path="wrong_fragment_xyz",
                dry_run=True,
            )
        assert d.exists()
        assert (d / "important.txt").exists()
