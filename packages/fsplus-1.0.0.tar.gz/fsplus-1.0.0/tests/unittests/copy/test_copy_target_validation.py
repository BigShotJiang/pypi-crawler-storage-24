"""
tests.test_copy_target_validation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests for target-directory validation in fsplus.copy_file.

Covers:
  - Target directory does not exist   → FSPlusPathNotFound
  - Target path exists but is a file  → FSPlusPathNotFound
"""

from __future__ import annotations

import pytest
from pathlib import Path

from fsplus.fsplus_copy import copy_file
from fsplus.exceptions import FSPlusPathNotFound


# ---------------------------------------------------------------------------
# Target directory does not exist
# ---------------------------------------------------------------------------

class TestTargetDirNotFound:
    """copy_file raises FSPlusPathNotFound when target_dir is missing."""

    def test_missing_target_raises(self, tmp_path: Path) -> None:
        src = tmp_path / "source.txt"
        src.write_text("hello")
        missing_dir = tmp_path / "no_such_dir"
        with pytest.raises(FSPlusPathNotFound):
            copy_file(src, missing_dir)

    def test_missing_target_exception_carries_path(self, tmp_path: Path) -> None:
        src = tmp_path / "source.txt"
        src.write_text("hello")
        missing_dir = tmp_path / "no_such_dir"
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            copy_file(src, missing_dir)
        assert exc_info.value.path == missing_dir.resolve()

    def test_missing_target_as_string_raises(self, tmp_path: Path) -> None:
        src = tmp_path / "source.txt"
        src.write_text("hello")
        with pytest.raises(FSPlusPathNotFound):
            copy_file(src, str(tmp_path / "nonexistent"))


# ---------------------------------------------------------------------------
# Target path is not a directory
# ---------------------------------------------------------------------------

class TestTargetNotADirectory:
    """copy_file raises FSPlusPathNotFound when target_dir is a regular file."""

    def test_target_is_file_raises(self, tmp_path: Path) -> None:
        src = tmp_path / "source.txt"
        src.write_text("hello")
        file_as_target = tmp_path / "not_a_dir.txt"
        file_as_target.write_text("I am a file, not a dir")
        with pytest.raises(FSPlusPathNotFound):
            copy_file(src, file_as_target)

    def test_target_is_file_message_is_descriptive(self, tmp_path: Path) -> None:
        src = tmp_path / "source.txt"
        src.write_text("hello")
        file_as_target = tmp_path / "not_a_dir.txt"
        file_as_target.write_text("content")
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            copy_file(src, file_as_target)
        assert "not a directory" in str(exc_info.value)
