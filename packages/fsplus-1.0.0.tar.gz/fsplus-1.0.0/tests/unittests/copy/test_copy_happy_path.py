"""
tests.test_copy_happy_path
~~~~~~~~~~~~~~~~~~~~~~~~~~~
Integration-style unit tests for the successful execution paths of fsplus.copy_file.

Covers:
  - Basic copy (file exists afterwards, content matches)
  - Return value is the destination Path
  - Source file is not modified or removed
  - Metadata preservation (shutil.copy2 preserves mtime)
  - Copying files with unusual names (spaces, unicode, dots)
  - Copying a zero-byte file
  - Copying a binary file
  - new_name combined with overwrite
"""

from __future__ import annotations

import time
from pathlib import Path

from fsplus import copy_file

# ---------------------------------------------------------------------------
# Basic copy behaviour
# ---------------------------------------------------------------------------


class TestBasicCopy:
    """copy_file creates a copy with correct content and return value."""

    def test_copy_creates_file(self, tmp_path: Path) -> None:
        src = tmp_path / "hello.txt"
        src.write_text("hello world")
        target = tmp_path / "dest"
        target.mkdir()
        result = copy_file(src, target)
        assert result.exists()

    def test_copy_content_matches(self, tmp_path: Path) -> None:
        src = tmp_path / "data.txt"
        src.write_text("line1\nline2\n")
        target = tmp_path / "dest"
        target.mkdir()
        result = copy_file(src, target)
        assert result.read_text() == "line1\nline2\n"

    def test_copy_returns_path_object(self, tmp_path: Path) -> None:
        src = tmp_path / "file.txt"
        src.write_text("x")
        target = tmp_path / "dest"
        target.mkdir()
        result = copy_file(src, target)
        assert isinstance(result, Path)

    def test_copy_returns_resolved_destination(self, tmp_path: Path) -> None:
        src = tmp_path / "file.txt"
        src.write_text("x")
        target = tmp_path / "dest"
        target.mkdir()
        result = copy_file(src, target)
        assert result == (target / "file.txt").resolve()

    def test_source_untouched_after_copy(self, tmp_path: Path) -> None:
        src = tmp_path / "original.txt"
        src.write_text("keep me")
        target = tmp_path / "dest"
        target.mkdir()
        copy_file(src, target)
        assert src.exists()
        assert src.read_text() == "keep me"

    def test_copy_uses_string_paths(self, tmp_path: Path) -> None:
        src = tmp_path / "f.txt"
        src.write_text("string paths")
        target = tmp_path / "dest"
        target.mkdir()
        result = copy_file(str(src), str(target))
        assert result.read_text() == "string paths"


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------


class TestMetadataPreservation:
    """shutil.copy2 is used, so modification time should be preserved."""

    def test_mtime_preserved(self, tmp_path: Path) -> None:
        src = tmp_path / "file.txt"
        src.write_text("data")
        # Set an explicit mtime in the past
        past = time.time() - 3600
        import os

        os.utime(src, (past, past))
        target = tmp_path / "dest"
        target.mkdir()
        result = copy_file(src, target)
        assert abs(result.stat().st_mtime - src.stat().st_mtime) < 2


# ---------------------------------------------------------------------------
# Edge-case file types
# ---------------------------------------------------------------------------


class TestEdgeCaseFiles:
    """copy_file handles unusual but valid file types and names."""

    def test_zero_byte_file(self, tmp_path: Path) -> None:
        src = tmp_path / "empty.txt"
        src.write_bytes(b"")
        target = tmp_path / "dest"
        target.mkdir()
        result = copy_file(src, target)
        assert result.stat().st_size == 0

    def test_binary_file(self, tmp_path: Path) -> None:
        src = tmp_path / "image.bin"
        binary_data = bytes(range(256))
        src.write_bytes(binary_data)
        target = tmp_path / "dest"
        target.mkdir()
        result = copy_file(src, target)
        assert result.read_bytes() == binary_data

    def test_filename_with_spaces(self, tmp_path: Path) -> None:
        src = tmp_path / "my file with spaces.txt"
        src.write_text("spaced")
        target = tmp_path / "dest"
        target.mkdir()
        result = copy_file(src, target)
        assert result.name == "my file with spaces.txt"

    def test_filename_with_unicode(self, tmp_path: Path) -> None:
        src = tmp_path / "données_ünïcödé.txt"
        src.write_text("unicode content", encoding="utf-8")
        target = tmp_path / "dest"
        target.mkdir()
        result = copy_file(src, target)
        assert result.read_text(encoding="utf-8") == "unicode content"

    def test_filename_with_multiple_dots(self, tmp_path: Path) -> None:
        src = tmp_path / "archive.tar.gz"
        src.write_bytes(b"\x1f\x8b")  # gzip magic bytes
        target = tmp_path / "dest"
        target.mkdir()
        result = copy_file(src, target)
        assert result.name == "archive.tar.gz"


# ---------------------------------------------------------------------------
# new_name + overwrite combined
# ---------------------------------------------------------------------------


class TestNewNameWithOverwrite:
    """new_name and overwrite=True can be combined."""

    def test_rename_and_overwrite(self, tmp_path: Path) -> None:
        src = tmp_path / "source.txt"
        src.write_text("new content")
        target = tmp_path / "dest"
        target.mkdir()
        existing = target / "renamed.txt"
        existing.write_text("old content")
        result = copy_file(
            src,
            target,
            new_name="renamed.txt",
            overwrite=True,
            required_partial_path=target.name,
        )
        assert result.name == "renamed.txt"
        assert result.read_text() == "new content"

    def test_copy_to_deeply_nested_target(self, tmp_path: Path) -> None:
        src = tmp_path / "file.txt"
        src.write_text("deep")
        nested = tmp_path / "a" / "b" / "c"
        nested.mkdir(parents=True)
        result = copy_file(src, nested)
        assert result.read_text() == "deep"
        assert result.parent == nested.resolve()
