"""
tests.test_copy_source_validation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests for source-path validation in fsplus.copy_file.

Covers:
  - Source does not exist         → FSPlusFileNotFound
  - Source is a directory         → FSPlusFileNotFound
"""

from __future__ import annotations

import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from fsplus.fsplus_copy import copy_file
from fsplus.exceptions import FSPlusFileNotFound


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_resolved(path: str) -> Path:
    return Path(path)


# ---------------------------------------------------------------------------
# Source does not exist
# ---------------------------------------------------------------------------

class TestSourceNotFound:
    """copy_file raises FSPlusFileNotFound when source is missing."""

    def test_missing_source_raises(self, tmp_path: Path) -> None:
        missing = tmp_path / "ghost.txt"
        with pytest.raises(FSPlusFileNotFound):
            copy_file(missing, tmp_path)

    def test_missing_source_exception_carries_path(self, tmp_path: Path) -> None:
        missing = tmp_path / "ghost.txt"
        with pytest.raises(FSPlusFileNotFound) as exc_info:
            copy_file(missing, tmp_path)
        assert exc_info.value.path == missing.resolve()

    def test_missing_source_as_string_raises(self, tmp_path: Path) -> None:
        missing = str(tmp_path / "no_such_file.csv")
        with pytest.raises(FSPlusFileNotFound):
            copy_file(missing, tmp_path)


# ---------------------------------------------------------------------------
# Source is not a regular file
# ---------------------------------------------------------------------------

class TestSourceNotAFile:
    """copy_file raises FSPlusFileNotFound when source exists but is a directory."""

    def test_source_is_directory_raises(self, tmp_path: Path) -> None:
        sub_dir = tmp_path / "subdir"
        sub_dir.mkdir()
        target = tmp_path / "target"
        target.mkdir()
        with pytest.raises(FSPlusFileNotFound):
            copy_file(sub_dir, target)

    def test_source_is_directory_message_is_descriptive(self, tmp_path: Path) -> None:
        sub_dir = tmp_path / "subdir"
        sub_dir.mkdir()
        target = tmp_path / "target"
        target.mkdir()
        with pytest.raises(FSPlusFileNotFound) as exc_info:
            copy_file(sub_dir, target)
        assert "not a regular file" in str(exc_info.value)
