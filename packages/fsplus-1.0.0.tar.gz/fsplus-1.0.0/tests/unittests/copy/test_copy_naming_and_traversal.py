"""
tests.test_copy_naming_and_traversal
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests for the new_name parameter and path-traversal guard in fsplus.copy_file.

Covers:
  - new_name preserves / renames file correctly
  - new_name with forward-slash separator       → FSPlusInvalidPath
  - new_name with backslash separator           → FSPlusInvalidPath
  - Resolved destination escapes target_dir     → FSPlusPathTraversal
"""

from __future__ import annotations

import pytest
from pathlib import Path

from fsplus.fsplus_copy import copy_file
from fsplus.exceptions import FSPlusInvalidPath, FSPlusPathTraversal


# ---------------------------------------------------------------------------
# new_name — happy paths
# ---------------------------------------------------------------------------

class TestNewName:
    """copy_file correctly applies or ignores new_name."""

    def test_source_name_preserved_when_new_name_omitted(self, tmp_path: Path) -> None:
        src = tmp_path / "report.csv"
        src.write_text("a,b,c")
        target = tmp_path / "out"
        target.mkdir()
        result = copy_file(src, target)
        assert result.name == "report.csv"

    def test_new_name_applied(self, tmp_path: Path) -> None:
        src = tmp_path / "report.csv"
        src.write_text("a,b,c")
        target = tmp_path / "out"
        target.mkdir()
        result = copy_file(src, target, new_name="renamed.csv")
        assert result.name == "renamed.csv"
        assert result.read_text() == "a,b,c"

    def test_new_name_does_not_affect_source(self, tmp_path: Path) -> None:
        src = tmp_path / "report.csv"
        src.write_text("data")
        target = tmp_path / "out"
        target.mkdir()
        copy_file(src, target, new_name="copy.csv")
        assert src.exists(), "Source should remain untouched"

    def test_new_name_with_different_extension(self, tmp_path: Path) -> None:
        src = tmp_path / "data.json"
        src.write_text("{}")
        target = tmp_path / "out"
        target.mkdir()
        result = copy_file(src, target, new_name="data.bak")
        assert result.suffix == ".bak"


# ---------------------------------------------------------------------------
# new_name — separator rejection
# ---------------------------------------------------------------------------

class TestNewNameInvalidSeparators:
    """FSPlusInvalidPath is raised when new_name contains path separators."""

    def test_forward_slash_in_new_name_raises(self, tmp_path: Path) -> None:
        src = tmp_path / "file.txt"
        src.write_text("x")
        target = tmp_path / "out"
        target.mkdir()
        with pytest.raises(FSPlusInvalidPath):
            copy_file(src, target, new_name="sub/dir/file.txt")

    def test_backslash_in_new_name_raises(self, tmp_path: Path) -> None:
        src = tmp_path / "file.txt"
        src.write_text("x")
        target = tmp_path / "out"
        target.mkdir()
        with pytest.raises(FSPlusInvalidPath):
            copy_file(src, target, new_name="sub\\file.txt")

    def test_invalid_path_exception_mentions_name(self, tmp_path: Path) -> None:
        src = tmp_path / "file.txt"
        src.write_text("x")
        target = tmp_path / "out"
        target.mkdir()
        with pytest.raises(FSPlusInvalidPath) as exc_info:
            copy_file(src, target, new_name="bad/name.txt")
        assert "bad/name.txt" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Path traversal guard
# ---------------------------------------------------------------------------

class TestPathTraversalGuard:
    """FSPlusPathTraversal is raised when destination escapes target_dir.

    Under normal usage this guard is hard to trigger because new_name is
    validated for separators first. The test patches the internal resolution
    to simulate a scenario where the destination ends up outside target_dir.
    """

    def test_traversal_via_symlink_escaping_target(self, tmp_path: Path) -> None:
        """Symlink inside target_dir pointing outside → traversal guard fires."""
        real_outside = tmp_path / "outside"
        real_outside.mkdir()

        target = tmp_path / "sandbox"
        target.mkdir()

        # Create a symlink inside sandbox that points to the outside directory
        link = target / "escape_link"
        link.symlink_to(real_outside)

        src = tmp_path / "payload.txt"
        src.write_text("secret")

        # Copying with new_name="escape_link" would resolve to real_outside,
        # which is outside target (sandbox). The traversal guard should fire.
        with pytest.raises(FSPlusPathTraversal):
            copy_file(src, target, new_name="escape_link")
