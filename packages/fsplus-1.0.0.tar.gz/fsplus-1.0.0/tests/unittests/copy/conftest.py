"""
tests.conftest
~~~~~~~~~~~~~~
Shared pytest fixtures for the fsplus.copy_file test suite.
"""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture()
def src_file(tmp_path: Path) -> Path:
    """A simple text file to use as a copy source."""
    f = tmp_path / "source.txt"
    f.write_text("test content")
    return f


@pytest.fixture()
def target_dir(tmp_path: Path) -> Path:
    """An empty target directory."""
    d = tmp_path / "target"
    d.mkdir()
    return d


@pytest.fixture()
def src_and_clean_target(src_file: Path, target_dir: Path):
    """(source_file, empty target_dir) — no pre-existing file in target."""
    return src_file, target_dir


@pytest.fixture()
def src_and_occupied_target(src_file: Path, target_dir: Path):
    """(source_file, target_dir) where a copy already exists in target."""
    existing = target_dir / src_file.name
    existing.write_text("old content")
    return src_file, target_dir
