"""
tests.test_copy_overwrite
~~~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests for the overwrite / required_partial_path guard in fsplus.copy_file.

Covers:
  - overwrite=True without required_partial_path  → ValueError
  - overwrite=True with empty required_partial_path → ValueError
  - required_partial_path == target_dir exactly    → ValueError
  - required_partial_path not in target_dir        → FSPlusPathTraversal
  - overwrite=True with valid partial path         → success (overwrites)
  - overwrite=False (default) with existing file   → FSPlusFileAlreadyExists
"""

from __future__ import annotations

import pytest
from pathlib import Path

from fsplus.fsplus_copy import copy_file
from fsplus.exceptions import FSPlusFileAlreadyExists, FSPlusPathTraversal


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def src_and_target(tmp_path: Path):
    """Return (source_file, target_dir) with a pre-existing copy in target."""
    src = tmp_path / "data.txt"
    src.write_text("original content")
    target = tmp_path / "destination"
    target.mkdir()
    # Pre-place a copy so overwrite scenarios have something to overwrite
    existing = target / "data.txt"
    existing.write_text("old content")
    return src, target


# ---------------------------------------------------------------------------
# overwrite=True argument validation errors
# ---------------------------------------------------------------------------

class TestOverwriteArgumentValidation:
    """ValueError is raised for invalid combinations of overwrite arguments."""

    def test_overwrite_without_partial_path_raises(self, src_and_target) -> None:
        src, target = src_and_target
        with pytest.raises(ValueError, match="required_partial_path must be provided"):
            copy_file(src, target, overwrite=True)

    def test_overwrite_with_empty_partial_path_raises(self, src_and_target) -> None:
        src, target = src_and_target
        with pytest.raises(ValueError, match="required_partial_path must be provided"):
            copy_file(src, target, overwrite=True, required_partial_path="")

    def test_overwrite_with_partial_path_equal_to_target_raises(self, src_and_target) -> None:
        src, target = src_and_target
        full_target = str(target.resolve())
        with pytest.raises(ValueError, match="must not be identical to target_dir"):
            copy_file(src, target, overwrite=True, required_partial_path=full_target)

    def test_overwrite_with_partial_path_not_in_target_raises(self, src_and_target) -> None:
        src, target = src_and_target
        with pytest.raises(FSPlusPathTraversal):
            copy_file(src, target, overwrite=True, required_partial_path="completely_wrong_fragment")


# ---------------------------------------------------------------------------
# overwrite=False (default) — existing destination
# ---------------------------------------------------------------------------

class TestOverwriteFalseBlocked:
    """FSPlusFileAlreadyExists is raised when file exists and overwrite=False."""

    def test_existing_file_no_overwrite_raises(self, src_and_target) -> None:
        src, target = src_and_target
        with pytest.raises(FSPlusFileAlreadyExists):
            copy_file(src, target, overwrite=False)

    def test_existing_file_default_overwrite_raises(self, src_and_target) -> None:
        """overwrite defaults to False."""
        src, target = src_and_target
        with pytest.raises(FSPlusFileAlreadyExists):
            copy_file(src, target)

    def test_exception_carries_destination_path(self, src_and_target) -> None:
        src, target = src_and_target
        expected_dest = (target / src.name).resolve()
        with pytest.raises(FSPlusFileAlreadyExists) as exc_info:
            copy_file(src, target)
        assert exc_info.value.path == expected_dest


# ---------------------------------------------------------------------------
# overwrite=True — success path
# ---------------------------------------------------------------------------

class TestOverwriteSuccess:
    """File is overwritten when overwrite=True and a valid partial path is supplied."""

    def test_overwrite_replaces_content(self, src_and_target) -> None:
        src, target = src_and_target
        fragment = target.name  # e.g. "destination"
        result = copy_file(src, target, overwrite=True, required_partial_path=fragment)
        assert result.read_text() == "original content"

    def test_overwrite_returns_destination_path(self, src_and_target) -> None:
        src, target = src_and_target
        fragment = target.name
        result = copy_file(src, target, overwrite=True, required_partial_path=fragment)
        assert result == (target / src.name).resolve()

    def test_overwrite_with_substring_of_target(self, tmp_path: Path) -> None:
        """A multi-segment partial path fragment is accepted."""
        nested = tmp_path / "apps" / "deploy" / "staging"
        nested.mkdir(parents=True)
        src = tmp_path / "config.yaml"
        src.write_text("key: value")
        (nested / "config.yaml").write_text("old")
        result = copy_file(
            src,
            nested,
            overwrite=True,
            required_partial_path="deploy/staging",
        )
        assert result.read_text() == "key: value"

    def test_no_overwrite_needed_when_file_absent(self, tmp_path: Path) -> None:
        """overwrite=True still works when destination does not yet exist."""
        src = tmp_path / "new_file.txt"
        src.write_text("fresh")
        target = tmp_path / "out"
        target.mkdir()
        result = copy_file(
            src,
            target,
            overwrite=True,
            required_partial_path=target.name,
        )
        assert result.read_text() == "fresh"
