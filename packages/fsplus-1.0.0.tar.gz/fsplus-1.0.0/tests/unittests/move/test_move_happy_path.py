"""
tests.test_move_happy_path
~~~~~~~~~~~~~~~~~~~~~~~~~~~
Integration-style unit tests for the successful execution paths of
fsplus.move_file.

Strategy
--------
Tests that verify *return values* and *validation logic* use ``dry_run=True``
so they run on every platform without side-effects.

Tests that verify actual file-system post-conditions (source gone, destination
present, content preserved) use ``dry_run=False`` directly — move_file has no
system-path guard, so real tmp directories are always reachable.

Covers:
  - Return value is the destination Path
  - Source filename is preserved when new_name is omitted
  - new_name renames the file at the destination
  - Source file is gone after a live move
  - Destination file exists and has identical content after a live move
  - Source directory is untouched (only the file is removed)
  - Empty-file (zero bytes) is moved successfully
  - String paths are accepted for both source and target_dir
  - Large-ish file round-trips intact
  - overwrite=True replaces an existing destination file
"""

from __future__ import annotations

from pathlib import Path

import pytest

from fsplus.fsplus_move import move_file


# ---------------------------------------------------------------------------
# Return-value tests  (dry_run — no fs side-effects)
# ---------------------------------------------------------------------------


class TestMoveFileReturnValues:
    """move_file return value is the resolved destination path."""

    def test_returns_path_object(self, src_file: Path, target_dir: Path) -> None:
        result = move_file(src_file, target_dir, dry_run=True)
        assert isinstance(result, Path)

    def test_returns_resolved_destination(
        self, src_file: Path, target_dir: Path
    ) -> None:
        result = move_file(src_file, target_dir, dry_run=True)
        assert result == (target_dir / src_file.name).resolve()

    def test_new_name_reflected_in_return_value(
        self, src_file: Path, target_dir: Path
    ) -> None:
        result = move_file(src_file, target_dir, new_name="renamed.txt", dry_run=True)
        assert result == (target_dir / "renamed.txt").resolve()

    def test_accepts_string_source(self, src_file: Path, target_dir: Path) -> None:
        result = move_file(str(src_file), target_dir, dry_run=True)
        assert isinstance(result, Path)

    def test_accepts_string_target_dir(
        self, src_file: Path, target_dir: Path
    ) -> None:
        result = move_file(src_file, str(target_dir), dry_run=True)
        assert isinstance(result, Path)

    def test_accepts_both_as_strings(
        self, src_file: Path, target_dir: Path
    ) -> None:
        result = move_file(str(src_file), str(target_dir), dry_run=True)
        assert result == (target_dir / src_file.name).resolve()


# ---------------------------------------------------------------------------
# Actual move post-conditions  (live — dry_run=False)
# ---------------------------------------------------------------------------


class TestMoveFileActualMove:
    """move_file performs a real atomic copy-verify-delete."""

    def test_source_is_gone_after_move(
        self, src_file: Path, target_dir: Path
    ) -> None:
        move_file(src_file, target_dir)
        assert not src_file.exists()

    def test_destination_exists_after_move(
        self, src_file: Path, target_dir: Path
    ) -> None:
        dest = move_file(src_file, target_dir)
        assert dest.exists()
        assert dest.is_file()

    def test_content_preserved(self, src_file: Path, target_dir: Path) -> None:
        original_content = src_file.read_bytes()
        dest = move_file(src_file, target_dir)
        assert dest.read_bytes() == original_content

    def test_source_directory_still_exists(
        self, src_file: Path, target_dir: Path
    ) -> None:
        src_dir = src_file.parent
        move_file(src_file, target_dir)
        assert src_dir.exists()
        assert src_dir.is_dir()

    def test_filename_preserved_by_default(
        self, src_file: Path, target_dir: Path
    ) -> None:
        dest = move_file(src_file, target_dir)
        assert dest.name == src_file.name

    def test_new_name_applied_at_destination(
        self, src_file: Path, target_dir: Path
    ) -> None:
        dest = move_file(src_file, target_dir, new_name="moved.dat")
        assert dest.name == "moved.dat"
        assert dest.exists()
        assert not src_file.exists()

    def test_overwrite_replaces_existing_file(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        original_content = src.read_bytes()
        fragment = dst_dir.name
        dest = move_file(src, dst_dir, overwrite=True, required_partial_path=fragment)
        assert dest.read_bytes() == original_content
        assert not src.exists()

    def test_zero_byte_file_moved(self, tmp_path: Path) -> None:
        src = tmp_path / "src" / "empty.bin"
        src.parent.mkdir()
        src.write_bytes(b"")
        dst = tmp_path / "dst"
        dst.mkdir()
        dest = move_file(src, dst)
        assert dest.exists()
        assert dest.stat().st_size == 0
        assert not src.exists()

    def test_large_file_content_intact(self, tmp_path: Path) -> None:
        src = tmp_path / "src" / "big.bin"
        src.parent.mkdir()
        data = b"x" * 512 * 1024  # 512 KiB
        src.write_bytes(data)
        dst = tmp_path / "dst"
        dst.mkdir()
        dest = move_file(src, dst)
        assert dest.read_bytes() == data


# ---------------------------------------------------------------------------
# dry_run leaves everything untouched
# ---------------------------------------------------------------------------


class TestMoveFileDryRunNoSideEffects:
    """dry_run=True never modifies the file system."""

    def test_source_still_exists(self, src_file: Path, target_dir: Path) -> None:
        move_file(src_file, target_dir, dry_run=True)
        assert src_file.exists()

    def test_source_content_unchanged(
        self, src_file: Path, target_dir: Path
    ) -> None:
        original = src_file.read_bytes()
        move_file(src_file, target_dir, dry_run=True)
        assert src_file.read_bytes() == original

    def test_destination_not_created(
        self, src_file: Path, target_dir: Path
    ) -> None:
        dest = move_file(src_file, target_dir, dry_run=True)
        assert not dest.exists()

    def test_target_dir_remains_empty(
        self, src_file: Path, target_dir: Path
    ) -> None:
        move_file(src_file, target_dir, dry_run=True)
        assert list(target_dir.iterdir()) == []

    def test_dry_run_with_new_name_no_side_effects(
        self, src_file: Path, target_dir: Path
    ) -> None:
        move_file(src_file, target_dir, new_name="other.txt", dry_run=True)
        assert src_file.exists()
        assert not (target_dir / "other.txt").exists()

    def test_default_is_live(self, src_file: Path, target_dir: Path) -> None:
        """Omitting dry_run must perform the actual move."""
        move_file(src_file, target_dir)
        assert not src_file.exists()
