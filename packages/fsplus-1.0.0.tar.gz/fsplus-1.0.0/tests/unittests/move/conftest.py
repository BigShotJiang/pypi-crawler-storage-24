"""
tests.conftest_move
~~~~~~~~~~~~~~~~~~~~
Shared pytest fixtures for the fsplus move_file test suite.
"""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture()
def src_file(tmp_path: Path) -> Path:
    """A regular file with deterministic content ready to be moved."""
    f = tmp_path / "source" / "payload.txt"
    f.parent.mkdir(parents=True)
    f.write_text("fsplus move test payload")
    return f


@pytest.fixture()
def target_dir(tmp_path: Path) -> Path:
    """An empty directory that is the move destination."""
    d = tmp_path / "destination"
    d.mkdir()
    return d


@pytest.fixture()
def pre_existing_file(tmp_path: Path) -> tuple[Path, Path]:
    """Source file + a destination dir that already contains a file of the same name."""
    src = tmp_path / "source" / "data.txt"
    src.parent.mkdir(parents=True)
    src.write_text("original source")
    dst_dir = tmp_path / "destination"
    dst_dir.mkdir()
    (dst_dir / "data.txt").write_text("already here")
    return src, dst_dir
