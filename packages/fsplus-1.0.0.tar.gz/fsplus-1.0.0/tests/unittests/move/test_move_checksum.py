"""
tests.test_move_checksum
~~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests for the copy-verify step of fsplus.move_file.

Strategy
--------
We simulate a corrupted copy by patching ``fsplus.fsplus_move._sha256`` so
that the *destination* call returns a deliberately wrong digest while the
source call returns the real digest.  This triggers ``FSPlusChecksumMismatch``
without needing broken hardware.

For the "clean copy" path we let the real checksum run (no patching) and
confirm the exception is never raised.

Covers:
  - FSPlusChecksumMismatch raised on digest mismatch
  - Exception carries expected, actual, and destination path
  - Partial copy is cleaned up (destination unlinked) on mismatch
  - Source file is left intact on mismatch
  - No exception raised when checksums match (normal live move)
  - dry_run=True never reaches the copy step — no checksum exception possible
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch, call

import pytest

from fsplus.fsplus_move import move_file
from fsplus.exceptions import FSPlusChecksumMismatch


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_REAL_DIGEST = "a" * 64
_BAD_DIGEST = "b" * 64


def _corrupt_copy_patch(src_checksum: str = _REAL_DIGEST, dst_checksum: str = _BAD_DIGEST):
    """Patch _sha256 so the first call (source) returns src_checksum and
    the second call (destination) returns dst_checksum."""
    return patch(
        "fsplus.fsplus_move._sha256",
        side_effect=[src_checksum, dst_checksum],
    )


# ---------------------------------------------------------------------------
# Checksum mismatch
# ---------------------------------------------------------------------------


class TestMoveFileChecksumMismatch:
    """FSPlusChecksumMismatch is raised and the partial copy is removed."""

    def test_mismatch_raises(self, src_file: Path, target_dir: Path) -> None:
        with _corrupt_copy_patch():
            with pytest.raises(FSPlusChecksumMismatch):
                move_file(src_file, target_dir)

    def test_exception_carries_expected_checksum(
        self, src_file: Path, target_dir: Path
    ) -> None:
        with _corrupt_copy_patch(_REAL_DIGEST, _BAD_DIGEST):
            with pytest.raises(FSPlusChecksumMismatch) as exc_info:
                move_file(src_file, target_dir)
        assert exc_info.value.expected == _REAL_DIGEST

    def test_exception_carries_actual_checksum(
        self, src_file: Path, target_dir: Path
    ) -> None:
        with _corrupt_copy_patch(_REAL_DIGEST, _BAD_DIGEST):
            with pytest.raises(FSPlusChecksumMismatch) as exc_info:
                move_file(src_file, target_dir)
        assert exc_info.value.actual == _BAD_DIGEST

    def test_exception_carries_destination_path(
        self, src_file: Path, target_dir: Path
    ) -> None:
        expected_dest = (target_dir / src_file.name).resolve()
        with _corrupt_copy_patch():
            with pytest.raises(FSPlusChecksumMismatch) as exc_info:
                move_file(src_file, target_dir)
        assert exc_info.value.path == expected_dest

    def test_partial_copy_removed_on_mismatch(
        self, src_file: Path, target_dir: Path
    ) -> None:
        dest = target_dir / src_file.name
        with _corrupt_copy_patch():
            with pytest.raises(FSPlusChecksumMismatch):
                move_file(src_file, target_dir)
        assert not dest.exists()

    def test_source_intact_on_mismatch(
        self, src_file: Path, target_dir: Path
    ) -> None:
        original_content = src_file.read_bytes()
        with _corrupt_copy_patch():
            with pytest.raises(FSPlusChecksumMismatch):
                move_file(src_file, target_dir)
        assert src_file.exists()
        assert src_file.read_bytes() == original_content


# ---------------------------------------------------------------------------
# Successful checksum (no patching — real digests)
# ---------------------------------------------------------------------------


class TestMoveFileChecksumSuccess:
    """No FSPlusChecksumMismatch is raised when the copy is intact."""

    def test_no_exception_on_matching_checksums(
        self, src_file: Path, target_dir: Path
    ) -> None:
        # Real copy — shutil.copy2 preserves content so digests must match.
        dest = move_file(src_file, target_dir)
        assert dest.exists()

    def test_source_gone_after_verified_copy(
        self, src_file: Path, target_dir: Path
    ) -> None:
        move_file(src_file, target_dir)
        assert not src_file.exists()


# ---------------------------------------------------------------------------
# dry_run never triggers checksum path
# ---------------------------------------------------------------------------


class TestMoveFileDryRunSkipsChecksumStep:
    """dry_run=True exits before the copy, so FSPlusChecksumMismatch is impossible."""

    def test_dry_run_does_not_raise_checksum_mismatch(
        self, src_file: Path, target_dir: Path
    ) -> None:
        # Even if _sha256 would return mismatched values, dry_run exits first.
        with patch("fsplus.fsplus_move._sha256", return_value=_REAL_DIGEST):
            # Only one _sha256 call happens (source pre-check); no second call
            # for destination because we never copy.
            result = move_file(src_file, target_dir, dry_run=True)
        assert isinstance(result, Path)
        assert src_file.exists()

    def test_dry_run_calls_sha256_exactly_once(
        self, src_file: Path, target_dir: Path
    ) -> None:
        """dry_run reads the source checksum but never the destination."""
        with patch("fsplus.fsplus_move._sha256", return_value=_REAL_DIGEST) as mock_hash:
            move_file(src_file, target_dir, dry_run=True)
        assert mock_hash.call_count == 1
        mock_hash.assert_called_once_with(src_file.resolve())
