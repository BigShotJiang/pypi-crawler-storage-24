"""
tests.test_move_dry_run
~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests specifically for the ``dry_run=True`` behaviour of
fsplus.move_file.

These tests verify the contract that ``dry_run=True`` runs every validation
check and computes the source checksum, but **never modifies the file system**.

Covers:
  - Return type and value match the live call contract
  - Source file still exists after dry_run
  - Source content is unchanged after dry_run
  - Destination is not created by dry_run
  - Target directory contents are unchanged by dry_run
  - All validation errors still fire under dry_run:
      * source missing         → FSPlusFileNotFound
      * source is a directory  → FSPlusFileNotFound
      * target_dir missing     → FSPlusPathNotFound
      * target_dir is a file   → FSPlusPathNotFound
      * new_name has separator → FSPlusInvalidPath
      * destination exists and overwrite=False → FSPlusFileAlreadyExists
      * required_partial_path violations       → ValueError / FSPlusPathTraversal
  - dry_run=False is the default (live call removes the source)
"""

from __future__ import annotations

from pathlib import Path

import pytest

from fsplus.fsplus_move import move_file
from fsplus.exceptions import (
    FSPlusFileNotFound,
    FSPlusPathNotFound,
    FSPlusInvalidPath,
    FSPlusFileAlreadyExists,
    FSPlusPathTraversal,
)


# ---------------------------------------------------------------------------
# dry_run return-value and no-side-effects contract
# ---------------------------------------------------------------------------


class TestMoveFileDryRunContract:
    """dry_run=True returns the would-be destination without touching anything."""

    def test_returns_path(self, src_file: Path, target_dir: Path) -> None:
        result = move_file(src_file, target_dir, dry_run=True)
        assert isinstance(result, Path)

    def test_returns_resolved_destination_path(
        self, src_file: Path, target_dir: Path
    ) -> None:
        result = move_file(src_file, target_dir, dry_run=True)
        assert result == (target_dir / src_file.name).resolve()

    def test_source_file_not_deleted(
        self, src_file: Path, target_dir: Path
    ) -> None:
        move_file(src_file, target_dir, dry_run=True)
        assert src_file.exists()

    def test_source_content_unchanged(
        self, src_file: Path, target_dir: Path
    ) -> None:
        before = src_file.read_bytes()
        move_file(src_file, target_dir, dry_run=True)
        assert src_file.read_bytes() == before

    def test_destination_file_not_created(
        self, src_file: Path, target_dir: Path
    ) -> None:
        dest = move_file(src_file, target_dir, dry_run=True)
        assert not dest.exists()

    def test_target_dir_stays_empty(
        self, src_file: Path, target_dir: Path
    ) -> None:
        move_file(src_file, target_dir, dry_run=True)
        assert list(target_dir.iterdir()) == []

    def test_new_name_reflected_in_return_no_file_created(
        self, src_file: Path, target_dir: Path
    ) -> None:
        result = move_file(src_file, target_dir, new_name="preview.txt", dry_run=True)
        assert result.name == "preview.txt"
        assert not result.exists()

    def test_default_dry_run_is_false(
        self, src_file: Path, target_dir: Path
    ) -> None:
        """Omitting dry_run must perform the actual move."""
        move_file(src_file, target_dir)
        assert not src_file.exists()


# ---------------------------------------------------------------------------
# Validation errors still fire under dry_run
# ---------------------------------------------------------------------------


class TestMoveFileDryRunValidation:
    """Every validation error is raised even when dry_run=True."""

    def test_missing_source_raises(self, tmp_path: Path) -> None:
        dst = tmp_path / "dst"
        dst.mkdir()
        with pytest.raises(FSPlusFileNotFound):
            move_file(tmp_path / "ghost.txt", dst, dry_run=True)

    def test_source_is_directory_raises(self, tmp_path: Path) -> None:
        src_dir = tmp_path / "src_dir"
        src_dir.mkdir()
        dst = tmp_path / "dst"
        dst.mkdir()
        with pytest.raises(FSPlusFileNotFound):
            move_file(src_dir, dst, dry_run=True)

    def test_missing_target_dir_raises(self, src_file: Path, tmp_path: Path) -> None:
        with pytest.raises(FSPlusPathNotFound):
            move_file(src_file, tmp_path / "no_such_dir", dry_run=True)

    def test_target_dir_is_file_raises(
        self, src_file: Path, tmp_path: Path
    ) -> None:
        f = tmp_path / "not_a_dir.txt"
        f.write_text("nope")
        with pytest.raises(FSPlusPathNotFound):
            move_file(src_file, f, dry_run=True)

    def test_invalid_new_name_raises(
        self, src_file: Path, target_dir: Path
    ) -> None:
        with pytest.raises(FSPlusInvalidPath):
            move_file(src_file, target_dir, new_name="bad/name.txt", dry_run=True)

    def test_destination_exists_raises(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        with pytest.raises(FSPlusFileAlreadyExists):
            move_file(src, dst_dir, dry_run=True)

    def test_overwrite_without_partial_path_raises(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        with pytest.raises(ValueError):
            move_file(src, dst_dir, overwrite=True, dry_run=True)

    def test_bad_partial_path_raises(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        with pytest.raises(FSPlusPathTraversal):
            move_file(
                src,
                dst_dir,
                overwrite=True,
                required_partial_path="no_match_xyz",
                dry_run=True,
            )
