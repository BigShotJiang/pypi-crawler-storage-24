"""
tests.test_move_source_target_validation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests for source-file and target-directory validation in
fsplus.move_file.

Strategy
--------
Validation errors are raised before any file-system mutation, so
``dry_run=True`` is not strictly required — but we pass it throughout
to avoid any accidental side-effects and to document that these checks
fire regardless of dry_run mode.

Covers:
  - Source does not exist             → FSPlusFileNotFound
  - Source is a directory             → FSPlusFileNotFound
  - Exception carries the source path
  - Target dir does not exist         → FSPlusPathNotFound
  - Target dir is a regular file      → FSPlusPathNotFound
  - Exception carries the target path
  - Error message is descriptive for the "not a directory" case
"""

from __future__ import annotations

from pathlib import Path

import pytest

from fsplus.fsplus_move import move_file
from fsplus.exceptions import FSPlusFileNotFound, FSPlusPathNotFound


# ---------------------------------------------------------------------------
# Source validation
# ---------------------------------------------------------------------------


class TestMoveFileSourceNotFound:
    """move_file raises FSPlusFileNotFound when source is missing."""

    def test_missing_source_raises(self, tmp_path: Path) -> None:
        dst = tmp_path / "dst"
        dst.mkdir()
        with pytest.raises(FSPlusFileNotFound):
            move_file(tmp_path / "ghost.txt", dst, dry_run=True)

    def test_missing_source_exception_carries_path(self, tmp_path: Path) -> None:
        dst = tmp_path / "dst"
        dst.mkdir()
        missing = tmp_path / "ghost.txt"
        with pytest.raises(FSPlusFileNotFound) as exc_info:
            move_file(missing, dst, dry_run=True)
        assert exc_info.value.path == missing.resolve()

    def test_missing_source_as_string_raises(self, tmp_path: Path) -> None:
        dst = tmp_path / "dst"
        dst.mkdir()
        with pytest.raises(FSPlusFileNotFound):
            move_file(str(tmp_path / "ghost.txt"), dst, dry_run=True)


class TestMoveFileSourceNotAFile:
    """move_file raises FSPlusFileNotFound when source is a directory."""

    def test_directory_source_raises(self, tmp_path: Path) -> None:
        src_dir = tmp_path / "src_dir"
        src_dir.mkdir()
        dst = tmp_path / "dst"
        dst.mkdir()
        with pytest.raises(FSPlusFileNotFound):
            move_file(src_dir, dst, dry_run=True)

    def test_directory_source_exception_carries_path(self, tmp_path: Path) -> None:
        src_dir = tmp_path / "src_dir"
        src_dir.mkdir()
        dst = tmp_path / "dst"
        dst.mkdir()
        with pytest.raises(FSPlusFileNotFound) as exc_info:
            move_file(src_dir, dst, dry_run=True)
        assert exc_info.value.path == src_dir.resolve()


# ---------------------------------------------------------------------------
# Target-directory validation
# ---------------------------------------------------------------------------


class TestMoveFileTargetDirNotFound:
    """move_file raises FSPlusPathNotFound when target_dir is missing."""

    def test_missing_target_dir_raises(self, src_file: Path, tmp_path: Path) -> None:
        with pytest.raises(FSPlusPathNotFound):
            move_file(src_file, tmp_path / "ghost_dir", dry_run=True)

    def test_missing_target_dir_exception_carries_path(
        self, src_file: Path, tmp_path: Path
    ) -> None:
        missing = tmp_path / "ghost_dir"
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            move_file(src_file, missing, dry_run=True)
        assert exc_info.value.path == missing.resolve()

    def test_missing_target_dir_as_string_raises(
        self, src_file: Path, tmp_path: Path
    ) -> None:
        with pytest.raises(FSPlusPathNotFound):
            move_file(src_file, str(tmp_path / "ghost_dir"), dry_run=True)


class TestMoveFileTargetDirNotADirectory:
    """move_file raises FSPlusPathNotFound when target_dir is a regular file."""

    def test_file_as_target_dir_raises(
        self, src_file: Path, tmp_path: Path
    ) -> None:
        not_a_dir = tmp_path / "iam_a_file.txt"
        not_a_dir.write_text("I am not a directory")
        with pytest.raises(FSPlusPathNotFound):
            move_file(src_file, not_a_dir, dry_run=True)

    def test_file_as_target_dir_exception_carries_path(
        self, src_file: Path, tmp_path: Path
    ) -> None:
        not_a_dir = tmp_path / "iam_a_file.txt"
        not_a_dir.write_text("I am not a directory")
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            move_file(src_file, not_a_dir, dry_run=True)
        assert exc_info.value.path == not_a_dir.resolve()

    def test_file_as_target_dir_message_is_descriptive(
        self, src_file: Path, tmp_path: Path
    ) -> None:
        not_a_dir = tmp_path / "iam_a_file.txt"
        not_a_dir.write_text("I am not a directory")
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            move_file(src_file, not_a_dir, dry_run=True)
        assert "not a directory" in str(exc_info.value).lower()
