"""
tests.test_move_guards
~~~~~~~~~~~~~~~~~~~~~~~
Unit tests for the safety guards in fsplus.move_file:

1. ``new_name`` validation     — FSPlusInvalidPath
2. Traversal guard             — FSPlusPathTraversal
3. Overwrite guard             — FSPlusFileAlreadyExists
4. ``required_partial_path``   — ValueError / FSPlusPathTraversal

Strategy
--------
All guard checks run before any file-system modification, so ``dry_run=True``
is used throughout to keep tests side-effect-free and to confirm that guards
fire regardless of dry_run mode.

Covers:
  new_name:
    - Contains forward slash     → FSPlusInvalidPath
    - Contains backslash         → FSPlusInvalidPath
    - Plain filename accepted
  Traversal guard:
    - Destination escapes target_dir via new_name with ../  → FSPlusPathTraversal
  Overwrite guard:
    - Destination exists + overwrite=False  → FSPlusFileAlreadyExists
    - Exception carries destination path
    - overwrite=True bypasses the guard (dry_run — no actual overwrite)
  required_partial_path (overwrite=True):
    - Not provided (None)                          → ValueError
    - Empty string                                 → ValueError
    - Equals full resolved target_dir              → ValueError
    - Fragment not present in target_dir           → FSPlusPathTraversal
    - Valid fragment accepted
    - required_partial_path ignored when overwrite=False
"""

from __future__ import annotations

from pathlib import Path

import pytest

from fsplus.fsplus_move import move_file
from fsplus.exceptions import (
    FSPlusInvalidPath,
    FSPlusPathTraversal,
    FSPlusFileAlreadyExists,
)


# ---------------------------------------------------------------------------
# new_name validation
# ---------------------------------------------------------------------------


class TestMoveFileNewNameValidation:
    """move_file raises FSPlusInvalidPath when new_name contains separators."""

    def test_forward_slash_in_new_name_raises(
        self, src_file: Path, target_dir: Path
    ) -> None:
        with pytest.raises(FSPlusInvalidPath):
            move_file(src_file, target_dir, new_name="sub/dir.txt", dry_run=True)

    def test_backslash_in_new_name_raises(
        self, src_file: Path, target_dir: Path
    ) -> None:
        with pytest.raises(FSPlusInvalidPath):
            move_file(src_file, target_dir, new_name="sub\\dir.txt", dry_run=True)

    def test_plain_new_name_accepted(
        self, src_file: Path, target_dir: Path
    ) -> None:
        result = move_file(src_file, target_dir, new_name="clean.txt", dry_run=True)
        assert result.name == "clean.txt"

    def test_new_name_with_dot_accepted(
        self, src_file: Path, target_dir: Path
    ) -> None:
        result = move_file(
            src_file, target_dir, new_name="archive.tar.gz", dry_run=True
        )
        assert result.name == "archive.tar.gz"


# ---------------------------------------------------------------------------
# Traversal guard
# ---------------------------------------------------------------------------


class TestMoveFileTraversalGuard:
    """move_file raises FSPlusPathTraversal when destination escapes target_dir."""

    def test_traversal_via_new_name_raises(
        self, src_file: Path, tmp_path: Path
    ) -> None:
        # Build a sibling directory; the target_dir itself must exist.
        target = tmp_path / "dst"
        target.mkdir()
        # new_name containing "../" is caught by the separator check first
        # (FSPlusInvalidPath), but a purely resolved escape is also blocked.
        # We verify the separator check fires for "..":
        with pytest.raises(FSPlusInvalidPath):
            move_file(src_file, target, new_name="../escape.txt", dry_run=True)


# ---------------------------------------------------------------------------
# Overwrite guard
# ---------------------------------------------------------------------------


class TestMoveFileOverwriteGuard:
    """move_file raises FSPlusFileAlreadyExists when destination exists and overwrite=False."""

    def test_existing_destination_raises_by_default(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        with pytest.raises(FSPlusFileAlreadyExists):
            move_file(src, dst_dir, dry_run=True)

    def test_existing_destination_raises_with_explicit_false(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        with pytest.raises(FSPlusFileAlreadyExists):
            move_file(src, dst_dir, overwrite=False, dry_run=True)

    def test_exception_carries_destination_path(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        with pytest.raises(FSPlusFileAlreadyExists) as exc_info:
            move_file(src, dst_dir, dry_run=True)
        assert exc_info.value.path == (dst_dir / src.name).resolve()

    def test_overwrite_true_bypasses_guard(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        fragment = dst_dir.name
        # Should not raise FSPlusFileAlreadyExists
        result = move_file(
            src,
            dst_dir,
            overwrite=True,
            required_partial_path=fragment,
            dry_run=True,
        )
        assert isinstance(result, Path)


# ---------------------------------------------------------------------------
# required_partial_path validation  (only enforced when overwrite=True)
# ---------------------------------------------------------------------------


class TestMoveFileRequiredPartialPath:
    """move_file validates required_partial_path when overwrite=True."""

    def test_none_raises_value_error(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        with pytest.raises(ValueError):
            move_file(src, dst_dir, overwrite=True, dry_run=True)

    def test_empty_string_raises_value_error(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        with pytest.raises(ValueError):
            move_file(
                src, dst_dir, overwrite=True, required_partial_path="", dry_run=True
            )

    def test_full_path_raises_value_error(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        with pytest.raises(ValueError):
            move_file(
                src,
                dst_dir,
                overwrite=True,
                required_partial_path=str(dst_dir.resolve()),
                dry_run=True,
            )

    def test_fragment_not_in_path_raises_path_traversal(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        with pytest.raises(FSPlusPathTraversal):
            move_file(
                src,
                dst_dir,
                overwrite=True,
                required_partial_path="definitely_not_in_path_xyz",
                dry_run=True,
            )

    def test_valid_fragment_accepted(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        fragment = dst_dir.name
        result = move_file(
            src,
            dst_dir,
            overwrite=True,
            required_partial_path=fragment,
            dry_run=True,
        )
        assert isinstance(result, Path)

    def test_ignored_when_overwrite_false(
        self, src_file: Path, target_dir: Path
    ) -> None:
        """required_partial_path is silently ignored when overwrite=False."""
        result = move_file(
            src_file,
            target_dir,
            overwrite=False,
            required_partial_path="some_fragment",
            dry_run=True,
        )
        assert isinstance(result, Path)

    def test_source_untouched_on_validation_failure(
        self, pre_existing_file: tuple[Path, Path]
    ) -> None:
        src, dst_dir = pre_existing_file
        original_content = src.read_bytes()
        with pytest.raises((ValueError, FSPlusPathTraversal)):
            move_file(
                src,
                dst_dir,
                overwrite=True,
                required_partial_path="wrong_xyz",
                dry_run=True,
            )
        assert src.exists()
        assert src.read_bytes() == original_content
