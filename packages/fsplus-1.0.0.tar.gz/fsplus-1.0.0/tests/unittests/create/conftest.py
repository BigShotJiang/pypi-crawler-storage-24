"""
tests.conftest
~~~~~~~~~~~~~~
Shared pytest fixtures for the fsplus.create_file / create_temp_file test suite.
"""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture()
def target_dir(tmp_path: Path) -> Path:
    """An empty directory to create files inside."""
    d = tmp_path / "target"
    d.mkdir()
    return d


@pytest.fixture()
def occupied_target(target_dir: Path) -> tuple[Path, Path]:
    """(target_dir, pre_existing_file) — a file that already lives in target_dir."""
    existing = target_dir / "existing.txt"
    existing.write_text("old content")
    return target_dir, existing


@pytest.fixture()
def nested_target(tmp_path: Path) -> Path:
    """A deeply-nested directory that does NOT exist yet (for make_parents tests)."""
    return tmp_path / "a" / "b" / "c"
