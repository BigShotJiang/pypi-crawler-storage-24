"""
tests.test_create_file_happy_path
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Integration-style unit tests for the successful execution paths of
fsplus.create_file.

Covers:
  - Basic creation (file exists, content matches, return value)
  - Filename assembly from name / prefix / suffix combinations
  - Text vs binary content
  - Zero-byte (empty) file creation
  - make_parents=True auto-creates missing parent directories
  - overwrite=True replaces an existing file
  - Unicode filenames and content
  - Return value is always a resolved Path inside target_dir
"""

from __future__ import annotations

from pathlib import Path

import pytest

from fsplus import create_file

# ---------------------------------------------------------------------------
# Basic creation behaviour
# ---------------------------------------------------------------------------


class TestBasicCreation:
    """create_file creates a file with the correct name and content."""

    def test_creates_file(self, target_dir: Path) -> None:
        result = create_file(target_dir, name="hello.txt")
        assert result.exists()

    def test_returns_path_object(self, target_dir: Path) -> None:
        result = create_file(target_dir, name="hello.txt")
        assert isinstance(result, Path)

    def test_returns_resolved_path_inside_target_dir(self, target_dir: Path) -> None:
        result = create_file(target_dir, name="hello.txt")
        assert result == (target_dir / "hello.txt").resolve()

    def test_empty_file_created_when_no_content(self, target_dir: Path) -> None:
        result = create_file(target_dir, name="empty.txt")
        assert result.stat().st_size == 0

    def test_accepts_string_path_for_target_dir(self, target_dir: Path) -> None:
        result = create_file(str(target_dir), name="str_path.txt")
        assert result.exists()

    def test_text_content_written_correctly(self, target_dir: Path) -> None:
        result = create_file(target_dir, name="data.txt", content="hello\nworld\n")
        assert result.read_text() == "hello\nworld\n"

    def test_binary_content_written_correctly(self, target_dir: Path) -> None:
        binary = bytes(range(256))
        result = create_file(target_dir, name="data.bin", content=binary)
        assert result.read_bytes() == binary

    def test_custom_encoding_respected(self, target_dir: Path) -> None:
        result = create_file(
            target_dir,
            name="latin.txt",
            content="café",
            encoding="latin-1",
        )
        assert result.read_text(encoding="latin-1") == "café"


# ---------------------------------------------------------------------------
# Filename assembly
# ---------------------------------------------------------------------------


class TestFilenameAssembly:
    """create_file assembles the filename as [prefix][name][suffix]."""

    def test_name_only(self, target_dir: Path) -> None:
        result = create_file(target_dir, name="report.csv")
        assert result.name == "report.csv"

    def test_prefix_only(self, target_dir: Path) -> None:
        result = create_file(target_dir, prefix="temp_")
        assert result.name == "temp_"

    def test_suffix_only(self, target_dir: Path) -> None:
        result = create_file(target_dir, suffix=".gitkeep")
        assert result.name == ".gitkeep"

    def test_prefix_and_name(self, target_dir: Path) -> None:
        result = create_file(target_dir, prefix="temp_", name="report.csv")
        assert result.name == "temp_report.csv"

    def test_name_and_suffix(self, target_dir: Path) -> None:
        result = create_file(target_dir, name="report.csv", suffix=".bak")
        assert result.name == "report.csv.bak"

    def test_prefix_name_suffix(self, target_dir: Path) -> None:
        result = create_file(
            target_dir, prefix="pre_", name="report.csv", suffix=".bak"
        )
        assert result.name == "pre_report.csv.bak"

    def test_prefix_and_suffix_without_name(self, target_dir: Path) -> None:
        result = create_file(target_dir, prefix="pre_", suffix=".bak")
        assert result.name == "pre_.bak"


# ---------------------------------------------------------------------------
# make_parents
# ---------------------------------------------------------------------------


class TestMakeParents:
    """create_file with make_parents=True auto-creates missing ancestors."""

    def test_make_parents_creates_missing_dirs(self, nested_target: Path) -> None:
        assert not nested_target.exists()
        result = create_file(nested_target, name="file.txt", make_parents=True)
        assert result.exists()

    def test_make_parents_file_in_correct_location(self, nested_target: Path) -> None:
        result = create_file(nested_target, name="file.txt", make_parents=True)
        assert result.parent == nested_target.resolve()

    def test_make_parents_false_by_default(self, tmp_path: Path) -> None:
        from fsplus.exceptions import FSPlusPathNotFound

        missing = tmp_path / "nonexistent_dir"
        with pytest.raises(FSPlusPathNotFound):
            create_file(missing, name="file.txt")

    def test_make_parents_with_content(self, nested_target: Path) -> None:
        result = create_file(
            nested_target, name="file.txt", content="deep", make_parents=True
        )
        assert result.read_text() == "deep"


# ---------------------------------------------------------------------------
# Overwrite
# ---------------------------------------------------------------------------


class TestOverwrite:
    """create_file with overwrite=True replaces an existing file."""

    def test_overwrite_replaces_content(
        self, occupied_target: tuple[Path, Path]
    ) -> None:
        target_dir, existing = occupied_target
        result = create_file(
            target_dir,
            name=existing.name,
            content="new content",
            overwrite=True,
            required_partial_path=target_dir.name,
        )
        assert result.read_text() == "new content"

    def test_overwrite_returns_resolved_path(
        self, occupied_target: tuple[Path, Path]
    ) -> None:
        target_dir, existing = occupied_target
        result = create_file(
            target_dir,
            name=existing.name,
            overwrite=True,
            required_partial_path=target_dir.name,
        )
        assert result == existing.resolve()

    def test_overwrite_existing_file_becomes_empty_without_content(
        self, occupied_target: tuple[Path, Path]
    ) -> None:
        target_dir, existing = occupied_target
        create_file(
            target_dir,
            name=existing.name,
            overwrite=True,
            required_partial_path=target_dir.name,
        )
        assert existing.stat().st_size == 0

    def test_overwrite_with_prefix_suffix(
        self, occupied_target: tuple[Path, Path]
    ) -> None:
        target_dir, _ = occupied_target
        # Create the file first with the compound name
        compound = target_dir / "pre_base.bak"
        compound.write_text("stale")
        result = create_file(
            target_dir,
            prefix="pre_",
            name="base",
            suffix=".bak",
            content="fresh",
            overwrite=True,
            required_partial_path=target_dir.name,
        )
        assert result.read_text() == "fresh"


# ---------------------------------------------------------------------------
# Edge-case filenames and content
# ---------------------------------------------------------------------------


class TestEdgeCases:
    """create_file handles unusual but valid filenames and content."""

    def test_filename_with_spaces(self, target_dir: Path) -> None:
        result = create_file(target_dir, name="my file.txt")
        assert result.name == "my file.txt"

    def test_filename_with_unicode(self, target_dir: Path) -> None:
        result = create_file(target_dir, name="données_ünïcödé.txt")
        assert result.name == "données_ünïcödé.txt"

    def test_filename_with_multiple_dots(self, target_dir: Path) -> None:
        result = create_file(target_dir, name="archive.tar.gz")
        assert result.name == "archive.tar.gz"

    def test_unicode_text_content(self, target_dir: Path) -> None:
        content = "日本語テスト 🎉"
        result = create_file(target_dir, name="unicode.txt", content=content)
        assert result.read_text(encoding="utf-8") == content

    def test_zero_byte_binary_content(self, target_dir: Path) -> None:
        result = create_file(target_dir, name="zero.bin", content=b"")
        assert result.stat().st_size == 0

    def test_large_text_content(self, target_dir: Path) -> None:
        big = "x" * 1_000_000
        result = create_file(target_dir, name="big.txt", content=big)
        assert len(result.read_text()) == 1_000_000
