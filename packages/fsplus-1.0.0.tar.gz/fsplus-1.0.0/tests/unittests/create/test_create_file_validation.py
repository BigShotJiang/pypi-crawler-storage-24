"""
tests.test_create_file_validation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests for argument validation and error paths of fsplus.create_file.

Covers:
  - Target directory does not exist            → FSPlusPathNotFound
  - Target path exists but is a file, not dir  → FSPlusPathNotFound
  - No name / prefix / suffix supplied         → ValueError
  - name / prefix / suffix contain separators  → FSPlusInvalidPath
  - Path traversal via crafted name            → FSPlusPathTraversal
  - Destination already exists, overwrite=False→ FSPlusFileAlreadyExists
  - overwrite=True without required_partial_path   → ValueError
  - required_partial_path equals target_dir    → ValueError
  - required_partial_path not in target_dir    → FSPlusPathTraversal
"""

from __future__ import annotations

from pathlib import Path

import pytest

from fsplus import create_file
from fsplus.exceptions import (
    FSPlusFileAlreadyExists,
    FSPlusInvalidPath,
    FSPlusPathNotFound,
    FSPlusPathTraversal,
)


# ---------------------------------------------------------------------------
# Target-directory validation
# ---------------------------------------------------------------------------


class TestTargetDirValidation:
    """create_file raises FSPlusPathNotFound for bad target directories."""

    def test_missing_target_dir_raises(self, tmp_path: Path) -> None:
        missing = tmp_path / "does_not_exist"
        with pytest.raises(FSPlusPathNotFound):
            create_file(missing, name="file.txt")

    def test_missing_target_dir_exception_carries_path(self, tmp_path: Path) -> None:
        missing = tmp_path / "does_not_exist"
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            create_file(missing, name="file.txt")
        assert exc_info.value.path == missing.resolve()

    def test_target_is_a_file_not_dir_raises(self, tmp_path: Path) -> None:
        a_file = tmp_path / "iam_a_file.txt"
        a_file.write_text("I am a file, not a dir")
        with pytest.raises(FSPlusPathNotFound):
            create_file(a_file, name="child.txt")

    def test_target_is_a_file_message_is_descriptive(self, tmp_path: Path) -> None:
        a_file = tmp_path / "iam_a_file.txt"
        a_file.write_text("")
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            create_file(a_file, name="child.txt")
        assert "not a directory" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Filename argument validation
# ---------------------------------------------------------------------------


class TestFilenameArgValidation:
    """create_file raises ValueError / FSPlusInvalidPath for bad name args."""

    def test_no_name_prefix_suffix_raises_value_error(
        self, target_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="At least one of"):
            create_file(target_dir)

    def test_name_with_forward_slash_raises(self, target_dir: Path) -> None:
        with pytest.raises(FSPlusInvalidPath):
            create_file(target_dir, name="sub/file.txt")

    def test_name_with_backslash_raises(self, target_dir: Path) -> None:
        with pytest.raises(FSPlusInvalidPath):
            create_file(target_dir, name="sub\\file.txt")

    def test_prefix_with_forward_slash_raises(self, target_dir: Path) -> None:
        with pytest.raises(FSPlusInvalidPath):
            create_file(target_dir, name="file.txt", prefix="bad/prefix_")

    def test_suffix_with_forward_slash_raises(self, target_dir: Path) -> None:
        with pytest.raises(FSPlusInvalidPath):
            create_file(target_dir, name="file.txt", suffix=".bad/ext")

    def test_invalid_path_exception_carries_path(self, target_dir: Path) -> None:
        with pytest.raises(FSPlusInvalidPath) as exc_info:
            create_file(target_dir, name="sub/file.txt")
        # The offending value should be part of the exception
        assert exc_info.value.path is not None


# ---------------------------------------------------------------------------
# Path-traversal guard
# ---------------------------------------------------------------------------


class TestPathTraversal:
    """create_file raises FSPlusPathTraversal when the resolved destination
    escapes target_dir."""

    def test_traversal_via_dotdot_in_name_raises(self, target_dir: Path) -> None:
        # On most OSes Path will normalise this, but the traversal guard
        # should catch any case where destination ends up outside target_dir.
        with pytest.raises((FSPlusPathTraversal, FSPlusInvalidPath)):
            create_file(target_dir, name="../escape.txt")


# ---------------------------------------------------------------------------
# Overwrite guard
# ---------------------------------------------------------------------------


class TestOverwriteGuard:
    """create_file raises FSPlusFileAlreadyExists when overwrite=False (default)."""

    def test_existing_file_raises_by_default(
        self, occupied_target: tuple[Path, Path]
    ) -> None:
        target_dir, existing = occupied_target
        with pytest.raises(FSPlusFileAlreadyExists):
            create_file(target_dir, name=existing.name)

    def test_exception_carries_destination_path(
        self, occupied_target: tuple[Path, Path]
    ) -> None:
        target_dir, existing = occupied_target
        with pytest.raises(FSPlusFileAlreadyExists) as exc_info:
            create_file(target_dir, name=existing.name)
        assert exc_info.value.path == existing.resolve()

    def test_existing_file_with_explicit_overwrite_false_raises(
        self, occupied_target: tuple[Path, Path]
    ) -> None:
        target_dir, existing = occupied_target
        with pytest.raises(FSPlusFileAlreadyExists):
            create_file(target_dir, name=existing.name, overwrite=False)

    def test_non_existing_file_does_not_raise(self, target_dir: Path) -> None:
        # Sanity check: no exception when the destination is fresh
        result = create_file(target_dir, name="brand_new.txt")
        assert result.exists()


# ---------------------------------------------------------------------------
# required_partial_path validation
# ---------------------------------------------------------------------------


class TestRequiredPartialPath:
    """required_partial_path rules are enforced when overwrite=True."""

    def test_overwrite_without_required_partial_path_raises_value_error(
        self, occupied_target: tuple[Path, Path]
    ) -> None:
        target_dir, existing = occupied_target
        with pytest.raises(ValueError, match="required_partial_path"):
            create_file(target_dir, name=existing.name, overwrite=True)

    def test_empty_required_partial_path_raises_value_error(
        self, occupied_target: tuple[Path, Path]
    ) -> None:
        target_dir, existing = occupied_target
        with pytest.raises(ValueError):
            create_file(
                target_dir,
                name=existing.name,
                overwrite=True,
                required_partial_path="",
            )

    def test_required_partial_path_equal_to_target_dir_raises_value_error(
        self, occupied_target: tuple[Path, Path]
    ) -> None:
        target_dir, existing = occupied_target
        with pytest.raises(ValueError, match="must not be identical"):
            create_file(
                target_dir,
                name=existing.name,
                overwrite=True,
                required_partial_path=str(target_dir.resolve()),
            )

    def test_required_partial_path_not_in_target_dir_raises_traversal(
        self, occupied_target: tuple[Path, Path]
    ) -> None:
        target_dir, existing = occupied_target
        with pytest.raises(FSPlusPathTraversal):
            create_file(
                target_dir,
                name=existing.name,
                overwrite=True,
                required_partial_path="/completely/wrong/path",
            )

    def test_valid_required_partial_path_allows_overwrite(
        self, occupied_target: tuple[Path, Path]
    ) -> None:
        target_dir, existing = occupied_target
        # Should not raise
        result = create_file(
            target_dir,
            name=existing.name,
            content="replaced",
            overwrite=True,
            required_partial_path=target_dir.name,
        )
        assert result.read_text() == "replaced"
