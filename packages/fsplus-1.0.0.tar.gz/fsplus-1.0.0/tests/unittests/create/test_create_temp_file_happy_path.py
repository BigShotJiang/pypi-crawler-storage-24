"""
tests.test_create_temp_file_happy_path
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Integration-style unit tests for the successful execution paths of
fsplus.create_temp_file.

Covers:
  - File is created inside target_dir and exists on disk
  - Return value is a resolved Path
  - Default call produces a non-empty filename
  - prefix / suffix appear in the generated filename
  - Text content is written correctly
  - Binary content is written correctly
  - Zero-byte file when no content is supplied
  - keep=False deletes the file but returns its path
  - Two successive calls always produce distinct filenames (uniqueness)
  - Custom encoding is respected
"""

from __future__ import annotations

from pathlib import Path

from fsplus import create_temp_file


# ---------------------------------------------------------------------------
# Basic creation behaviour
# ---------------------------------------------------------------------------


class TestBasicCreation:
    """create_temp_file creates a real file and returns the correct path."""

    def test_file_exists_after_creation(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir)
        assert result.exists()

    def test_returns_path_object(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir)
        assert isinstance(result, Path)

    def test_file_lives_inside_target_dir(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir)
        assert result.parent == target_dir.resolve()

    def test_filename_is_non_empty(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir)
        assert len(result.name) > 0

    def test_accepts_string_path_for_target_dir(self, target_dir: Path) -> None:
        result = create_temp_file(str(target_dir))
        assert result.exists()

    def test_returns_resolved_absolute_path(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir)
        assert result.is_absolute()


# ---------------------------------------------------------------------------
# Prefix and suffix
# ---------------------------------------------------------------------------


class TestPrefixAndSuffix:
    """The generated filename honours the requested prefix and suffix."""

    def test_prefix_appears_in_filename(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir, prefix="myprefix_")
        assert result.name.startswith("myprefix_")

    def test_suffix_appears_in_filename(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir, suffix=".json")
        assert result.name.endswith(".json")

    def test_prefix_and_suffix_together(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir, prefix="log_", suffix=".txt")
        assert result.name.startswith("log_")
        assert result.name.endswith(".txt")

    def test_no_prefix_no_suffix_still_creates_file(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir)
        assert result.exists()


# ---------------------------------------------------------------------------
# Content
# ---------------------------------------------------------------------------


class TestContent:
    """create_temp_file writes the requested content into the new file."""

    def test_text_content_written(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir, content="hello temp")
        assert result.read_text() == "hello temp"

    def test_binary_content_written(self, target_dir: Path) -> None:
        binary = bytes(range(256))
        result = create_temp_file(target_dir, content=binary)
        assert result.read_bytes() == binary

    def test_no_content_produces_zero_byte_file(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir)
        assert result.stat().st_size == 0

    def test_empty_bytes_content_produces_zero_byte_file(
        self, target_dir: Path
    ) -> None:
        result = create_temp_file(target_dir, content=b"")
        assert result.stat().st_size == 0

    def test_custom_encoding_respected(self, target_dir: Path) -> None:
        result = create_temp_file(
            target_dir, content="café", encoding="latin-1"
        )
        assert result.read_text(encoding="latin-1") == "café"

    def test_unicode_text_content(self, target_dir: Path) -> None:
        content = "日本語テスト 🎉"
        result = create_temp_file(target_dir, content=content)
        assert result.read_text(encoding="utf-8") == content

    def test_large_binary_content(self, target_dir: Path) -> None:
        big = b"\xff" * 500_000
        result = create_temp_file(target_dir, content=big)
        assert result.read_bytes() == big


# ---------------------------------------------------------------------------
# keep=False
# ---------------------------------------------------------------------------


class TestKeepFalse:
    """When keep=False the file is removed but the path is still returned."""

    def test_file_deleted_when_keep_false(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir, keep=False)
        assert not result.exists()

    def test_returns_path_even_when_keep_false(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir, keep=False)
        assert isinstance(result, Path)

    def test_path_would_have_been_inside_target_dir(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir, keep=False)
        assert result.parent == target_dir.resolve()

    def test_prefix_in_name_when_keep_false(self, target_dir: Path) -> None:
        result = create_temp_file(target_dir, prefix="gone_", keep=False)
        assert result.name.startswith("gone_")


# ---------------------------------------------------------------------------
# Uniqueness
# ---------------------------------------------------------------------------


class TestUniqueness:
    """Successive calls always produce different file names."""

    def test_two_calls_produce_distinct_names(self, target_dir: Path) -> None:
        a = create_temp_file(target_dir)
        b = create_temp_file(target_dir)
        assert a != b

    def test_many_calls_all_unique(self, target_dir: Path) -> None:
        paths = {create_temp_file(target_dir) for _ in range(20)}
        assert len(paths) == 20
