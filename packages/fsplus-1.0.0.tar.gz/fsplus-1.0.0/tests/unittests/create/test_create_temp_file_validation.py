"""
tests.test_create_temp_file_validation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Unit tests for argument validation and error paths of fsplus.create_temp_file.

Covers:
  - Target directory does not exist            → FSPlusPathNotFound
  - Target path exists but is a file, not dir  → FSPlusPathNotFound
  - prefix contains path separators            → FSPlusInvalidPath
  - suffix contains path separators            → FSPlusInvalidPath
"""

from __future__ import annotations

from pathlib import Path

import pytest

from fsplus import create_temp_file
from fsplus.exceptions import (
    FSPlusInvalidPath,
    FSPlusPathNotFound,
)


# ---------------------------------------------------------------------------
# Target-directory validation
# ---------------------------------------------------------------------------


class TestTargetDirValidation:
    """create_temp_file raises FSPlusPathNotFound for bad target directories."""

    def test_missing_target_dir_raises(self, tmp_path: Path) -> None:
        missing = tmp_path / "does_not_exist"
        with pytest.raises(FSPlusPathNotFound):
            create_temp_file(missing)

    def test_missing_target_dir_exception_carries_path(self, tmp_path: Path) -> None:
        missing = tmp_path / "does_not_exist"
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            create_temp_file(missing)
        assert exc_info.value.path == missing.resolve()

    def test_missing_target_dir_as_string_raises(self, tmp_path: Path) -> None:
        missing = str(tmp_path / "no_such_dir")
        with pytest.raises(FSPlusPathNotFound):
            create_temp_file(missing)

    def test_target_is_a_file_not_dir_raises(self, tmp_path: Path) -> None:
        a_file = tmp_path / "iam_a_file.txt"
        a_file.write_text("not a dir")
        with pytest.raises(FSPlusPathNotFound):
            create_temp_file(a_file)

    def test_target_is_a_file_message_is_descriptive(self, tmp_path: Path) -> None:
        a_file = tmp_path / "iam_a_file.txt"
        a_file.write_text("")
        with pytest.raises(FSPlusPathNotFound) as exc_info:
            create_temp_file(a_file)
        assert "not a directory" in str(exc_info.value)


# ---------------------------------------------------------------------------
# prefix / suffix validation
# ---------------------------------------------------------------------------


class TestPrefixSuffixValidation:
    """create_temp_file raises FSPlusInvalidPath for separators in prefix/suffix."""

    def test_prefix_with_forward_slash_raises(self, target_dir: Path) -> None:
        with pytest.raises(FSPlusInvalidPath):
            create_temp_file(target_dir, prefix="bad/prefix_")

    def test_prefix_with_backslash_raises(self, target_dir: Path) -> None:
        with pytest.raises(FSPlusInvalidPath):
            create_temp_file(target_dir, prefix="bad\\prefix_")

    def test_suffix_with_forward_slash_raises(self, target_dir: Path) -> None:
        with pytest.raises(FSPlusInvalidPath):
            create_temp_file(target_dir, suffix=".bad/ext")

    def test_suffix_with_backslash_raises(self, target_dir: Path) -> None:
        with pytest.raises(FSPlusInvalidPath):
            create_temp_file(target_dir, suffix=".bad\\ext")

    def test_invalid_prefix_exception_carries_value(self, target_dir: Path) -> None:
        bad_prefix = "bad/prefix_"
        with pytest.raises(FSPlusInvalidPath) as exc_info:
            create_temp_file(target_dir, prefix=bad_prefix)
        assert exc_info.value.path is not None

    def test_valid_prefix_and_suffix_do_not_raise(self, target_dir: Path) -> None:
        # Sanity check: well-formed values must not raise
        result = create_temp_file(target_dir, prefix="ok_", suffix=".txt")
        assert result.exists()
