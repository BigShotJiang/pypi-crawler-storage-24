# fsplus

Safe file system operations for Python — copy, move, create, and delete with path-traversal protection, overwrite confirmation, and checksum verification.

## Install

```bash
pip install fsplus
```

## Operations

| Function | Description |
|---|---|
| `copy_file` | Copy a file with overwrite confirmation |
| `move_file` | Move a file with checksum verification |
| `create_file` | Create a new file with content |
| `create_temp_file` | Create a temporary file |
| `clear_directory` | Remove all contents of a directory |
| `delete_directory` | Remove a directory entirely |

## Usage

```python
from fsplus import copy_file, move_file, delete_directory

# Copy a file
copy_file("/data/report.csv", "/backup/")

# Overwrite requires explicit confirmation
copy_file("/data/report.csv", "/backup/", overwrite=True, required_partial_path="backup")

# Move with automatic checksum verification
move_file("/data/report.csv", "/archive/")

# Rename on the way
move_file("/data/report.csv", "/archive/", new_name="report_2024.csv")
```

## License

MIT