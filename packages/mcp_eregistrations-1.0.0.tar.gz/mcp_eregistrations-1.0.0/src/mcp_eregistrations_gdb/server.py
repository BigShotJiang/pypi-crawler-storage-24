"""GDB MCP Server entry point."""

from fastmcp import FastMCP

mcp = FastMCP(
    "mcp-eregistrations-gdb",
    instructions=(
        "GDB (Generic Database Builder) tools for managing databases, schemas, "
        "and records in eRegistrations. Use gdb_catalog_list to discover available "
        "databases, then gdb_database_get for schema details."
    ),
)

import mcp_eregistrations_gdb.tools.catalogs  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.data  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.databases  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.system  # noqa: F401, E402


def main() -> None:
    mcp.run()
