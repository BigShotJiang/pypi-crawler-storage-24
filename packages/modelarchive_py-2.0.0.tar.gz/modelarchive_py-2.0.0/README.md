<!--  Copyright 2026 SIB - Swiss Institute of Bioinformatics and Biozentrum -
University of Basel
Copying and distribution of this file, with or without modification, are
permitted provided the copyright notice and this notice are preserved.
-->

# modelarchive - The ModelArchive Python package

https://modelarchive.org/

`modelarchive` collects all Python functionality developed for ModelArchive
in a single package - essentially the “Everything ModelArchive” toolkit.

Yes, the name is a bit long, but `ma` alone felt too short ;)
You can conveniently import it as:

```python
import modelarchive as ma
```

The package is organised into submodules covering different areas of
functionality. Currently available:

- `modelcif`: help with editing ModelCIF files, translating from legacy PDB
               format and extending existing ModelCIf-formatted files


## Installation

From [PyPI](https://pypi.org/):
```bash
pip install modelarchive-py
```

From source:
```bash
git clone https://git.scicore.unibas.ch/schwede/modelarchive-py
cd modelarchive-py
pip install .
```

For development:
- to see code changes immediately effective in your environment:
```bash
pip install -e .
```

## Versioning/ requirements.txt

`modelarchive` follows [Semantic Versioning](https://semver.org), so you can
safely depend on `modelarchive-py>=<MAJOR VERSION>.0.0` to get updates
without breaking changes.


## Developing ModelArchive

- best install the package to get all requirements resolved
- run pytest as `python -m pytest [-s]`
- in the `doc/` subdirectory, run `make html` to create the documentation
- in the `doc/` subdirectory run `make doctest` to run Doctests


<!--  LocalWords:  modelarchive ModelArchive submodules modelcif PDB ModelCIf
 -->
<!--  LocalWords:  PyPi cd pytest subdirectory html doctest Doctests
 -->
