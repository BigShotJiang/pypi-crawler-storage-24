"""Unit tests for modelarchive.modelcif.access"""

# Copyright (c) 2026, SIB - Swiss Institute of Bioinformatics and
#                     Biozentrum - University of Basel
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import unittest

from gemmi import cif

import mockup_mmcif

from modelarchive.modelcif import access


class TestGet(unittest.TestCase):
    """Test access functions."""

    def test_get_table(self):
        """Make sure retrievieng category data works as intended."""
        block = cif.read_string(mockup_mmcif.AUDIT_CONFORM_PAIR).sole_block()
        # test retrieval just by category (with '.' at the end)
        table = access.get_table(block, "_audit_conform.")
        self.assertEqual(len(table), 1)
        self.assertEqual(
            list(table.tags),
            [
                "_audit_conform.dict_location",
                "_audit_conform.dict_name",
                "_audit_conform.dict_version",
            ],
        )
        self.assertEqual(
            list(table[0]),
            ["https://mmcif.org/mmcif_ma-core.dic", "mmcif_ma.dic", "1.4.1"],
        )

        # Here we also check that the order of coluns follows the order in the
        # items list.
        table = access.get_table(
            block, "_audit_conform", ["dict_name", "dict_location"]
        )
        self.assertEqual(len(table), 1)
        self.assertEqual(
            list(table.tags),
            [
                "_audit_conform.dict_name",
                "_audit_conform.dict_location",
            ],
        )
        self.assertEqual(
            list(table[0]),
            ["mmcif_ma.dic", "https://mmcif.org/mmcif_ma-core.dic"],
        )

        # check that None is returned on missing category
        table = access.get_table(block, "_does_not_exist")
        self.assertFalse(table)

        # check that None is returned on missing item
        table = access.get_table(block, "_audit_conform", ["does_not_exist"])
        self.assertFalse(table)
        table = access.get_table(
            block, "_audit_conform", ["does_not_exist", "dict_name"]
        )
        self.assertFalse(table)

        # check that gemmi's optional tag mechanism works
        table = access.get_table(
            block, "_audit_conform", ["dict_name", "?does_not_exist"]
        )
        self.assertTrue(table)
        self.assertTrue(table.has_column(0))
        self.assertFalse(table.has_column(1))
