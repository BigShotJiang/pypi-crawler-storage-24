"""Test the modelcif_overhauling.fix_af3 functionality."""

# Copyright (c) 2026, SIB - Swiss Institute of Bioinformatics and
#                     Biozentrum - University of Basel
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import unittest

from gemmi import cif
import pytest

import af3_citations
import mockup_mmcif

from modelarchive.modelcif import access
from modelarchive.modelcif import edit
from modelarchive.modelcif import fix_af3


class TestEdit(unittest.TestCase):
    """Test editing ModelCIF files."""

    def test_quote(self):
        # Accessing private function on purpose, disable Pylint
        # pylint: disable=protected-access
        """_quote() is a private function but hard to test implicitly while it
        needs to work.
        """
        self.assertEqual(fix_af3._quote("A string"), '"A string"')
        self.assertEqual(fix_af3._quote('"A string"'), """'"A string"'""")
        self.assertEqual(fix_af3._quote("'A string'"), '''"'A string'"''')
        self.assertEqual(fix_af3._quote("Two\nlines"), ";Two\nlines\n;")

    def test_fix_model_name(self):
        """Make sure fix_model_name is working as expected."""
        # Load AUDIT_CONFORM_PAIR for raising exceptions
        block = cif.read_string(mockup_mmcif.AUDIT_CONFORM_PAIR).sole_block()
        with self.assertRaises(edit.NotFoundItemError):
            fix_af3.fix_model_name(block, 1)
        edit.add_category(block, "_ma_model_list", {"model_name": ["A", "B"]})
        with self.assertRaises(RuntimeError) as exc:
            fix_af3.fix_model_name(block, 1)
            self.assertEqual(
                str(exc), "File must have a single model in _ma_model_list."
            )
        # Load AF3 CIF document
        block = cif.read_string(mockup_mmcif.AF3).sole_block()
        table = access.get_table(block, "_ma_model_list", items=["model_name"])
        self.assertEqual(
            cif.as_string(table[0]["model_name"]), "Top ranked model"
        )
        fix_af3.fix_model_name(block, 2)
        # In theory, table is updated, so we don't need to reload it (this
        # seems to be new in gemmi).
        self.assertEqual(
            cif.as_string(table[0]["model_name"]), "#2 ranked model"
        )
        fix_af3.fix_model_name(block, 1)
        self.assertEqual(table[0]["model_name"], '"Top ranked model"')

    def check_citation(self, block, cid="1", n_citations=1, pos=0, loop=False):
        # This is a unit test function, relax Pylint
        # pylint: disable=too-many-arguments,too-many-positional-arguments
        """Helper for testing fix_citation(). Common check for non-loop
        citation.
        """
        # It's a unit test, lets ignore Pylint
        # pylint: disable=duplicate-code
        exp_cit = {
            "country": "UK",
            "journal_full": "Nature",
            "journal_id_ASTM": "NATUAS",
            "journal_id_CSD": "0006",
            "journal_id_ISSN": "0028-0836",
            "journal_volume": "630",
            "page_first": "493",
            "page_last": "500",
            "pdbx_database_id_DOI": "10.1038/s41586-024-07487-w",
            "pdbx_database_id_PubMed": "38718835",
            "title": "Accurate structure prediction of biomolecular "
            + "interactions with AlphaFold 3",
            "year": "2024",
        }

        table = access.get_table(block, "_citation")
        self.assertEqual(len(table), n_citations)
        self.assertEqual(table.tags[0], "_citation.id")
        self.assertEqual(table[pos]["id"], cid)
        if loop:
            self.assertIsNotNone(table.loop)
        else:
            self.assertIsNone(table.loop)
        for itm, val in exp_cit.items():
            self.assertEqual(cif.as_string(table[pos][itm]), val)

        return table

    def check_citation_author(self, block, cid="1", n_authors=48):
        """Common check for authors."""
        table = access.get_table(block, "_citation_author")
        assert len(table) == n_authors
        self.assertEqual(table.tags[0], "_citation_author.citation_id")
        self.assertEqual(table.tags[-1], "_citation_author.ordinal")
        self.assertEqual(table[0]["citation_id"], cid)
        self.assertIsNotNone(table.loop)
        # Lets not check all 48 authors, if the last one is in place, should
        # be fine.
        n_authors -= 1
        # fmt: off
        authors = [
            "Jumper, J.M.", "Hassabis, D.", "Jaderberg, M.", "Kohli, P.",
            "Bapst, V.", "Zidek, A.", "Zielinski, M.", "Zhong, E.D.",
            "Yakneen, S.", "Tong, C.", "Thillaisundaram, A.", "Stecula, A.",
            "Singh, S.", "Savy, P.", "Potapenko, A.", "Perlin, K.",
            "Low, C.M.R.", "Khan, Y.A.", "Jain, R.", "Gladman, H.",
            "Fuchs, F.B.", "Figurnov, M.", "Cowie, A.", "Cowen-Rivers, A.I.",
            "Congreve, M.", "Cherepanov, A.", "Bridgland, A.", "Bertolli, O.",
            "Beattie, C.", "Arvaniti, E.", "Zemgulyte, A.", "Wu, Z.",
            "Tunyasuvunakool, K.", "Reiman, D.", "O'Neill, M.", "Hung, C.C.",
            "Evans, D.A.", "Bodenstein, S.W.", "Bambrick, J.", "Ballard, A.J.",
            "Willmore, L.", "Ronneberger, O.", "Pritzel, A.", "Green, T.",
            "Evans, R.", "Dunger, J.", "Adler, J.", "Abramson, J.", "Kirby, J",
            "Lee, S",
        ]
        # fmt: on
        for i in range(n_authors, -1, -1):
            self.assertEqual(
                cif.as_string(table[i]["name"]),
                authors[n_authors - i],
            )

        return table

    def test_fix_citation(self):
        """Make sure fixing citations is working as expected."""
        # It's a unit test, lets ignore Pylint
        # pylint: disable=too-many-statements

        def _add_software(block):
            """Add a software record."""
            edit.add_rows(
                block,
                "_software",
                {
                    "classification": "other",
                    "description": "Structure prediction",
                    "name": "AlphaFold",
                    "type": "package",
                    "version": "AlphaFold-beta-20231127",
                },
                ordinal_item="pdbx_ordinal",
            )

        # Load AF3 CIF document to check the _fix_citation_fallback() branch
        block = cif.read_string(mockup_mmcif.AF3).sole_block()
        # Check no software category found raises exception
        with self.assertRaises(fix_af3.NotIdentifiedContextRecordError) as exc:
            fix_af3.fix_citation(block)
        self.assertTrue("_software" in exc.exception.category)
        # First round of fixing citation adds the citation by
        # _fix_citation_fallback
        # add _software
        _add_software(block)
        fix_af3.fix_citation(block)
        table = access.get_table(block, "_software")
        self.assertEqual(len(table), 1)
        self.assertEqual(table[0]["citation_id"], "1")
        table = self.check_citation(block)
        # Set citation to '?' for the second case in _fix_citation_fallback()
        cit_fields = [
            "country",
            "id",
            "journal_full",
            "journal_id_ASTM",
            "journal_id_CSD",
            "journal_id_ISSN",
            "journal_volume",
            "page_first",
            "page_last",
            "pdbx_database_id_DOI",
            "pdbx_database_id_PubMed",
            "title",
            "year",
        ]
        for i in cit_fields:
            table[0][i] = "?"
        fix_af3.fix_citation(block)
        table = self.check_citation(block)
        # Set citation to '?' but id to something different than '?'
        for i in cit_fields:
            table[0][i] = "?"
        table[0]["id"] = "3"
        fix_af3.fix_citation(block)
        table = self.check_citation(block, cid="3")
        # Check with correct citation but id=None
        table[0]["id"] = "?"
        fix_af3.fix_citation(block)
        table = self.check_citation(block)
        # Check exception is raised when AF3 citation record can't be found
        table[0]["pdbx_database_id_PubMed"] = "5"
        with self.assertRaises(fix_af3.NotIdentifiedSingleRecordError) as exc:
            fix_af3.fix_citation(block)
        self.assertEqual(
            str(exc.exception),
            "Could not identify record in category '_citation', mismatch at "
            + "item 'pdbx_database_id_PubMed=38718835'.",
        )
        # Check exception on missing column
        # remove pdbx_database_id_PubMed column
        col = table.find_column("pdbx_database_id_PubMed")
        col.erase()
        with self.assertRaises(fix_af3.NotIdentifiedSingleRecordError) as exc:
            fix_af3.fix_citation(block)
        self.assertEqual(
            str(exc.exception),
            "Could not identify record in category '_citation', missing item "
            + "'pdbx_database_id_PubMed'.",
        )
        # Check with id='primary' & authors
        block = cif.read_string(mockup_mmcif.AF3_CITATION).sole_block()
        table = access.get_table(block, "_citation")
        self.assertEqual(table[0]["id"], "primary")
        fix_af3.fix_citation(block)
        table = self.check_citation(block)
        self.check_citation_author(block)
        # Check multiple citations with multiple sets of authors
        table[0]["id"] = "primary"
        table = access.get_table(block, "_citation_author")
        for row in table:
            row["citation_id"] = "primary"
        edit.add_rows(
            block,
            "_citation",
            {
                "id": "1",
                "journal_full": "Amazing Fantasy",
                "title": "Spider-Man",
                "year": "1962",
                "journal_volume": "15",
            },
            ordinal_item=None,
        )
        edit.add_rows(
            block,
            "_citation_author",
            {"citation_id": ["1", "1"], "name": ["Lee, S", "Kirby, J"]},
        )
        fix_af3.fix_citation(block)
        table = self.check_citation(
            block, cid="2", n_citations=2, pos=1, loop=True
        )
        self.check_citation_author(block, n_authors=50)
        # Multiple citations with multiple authors, _fix_citation_fallback()
        table[0]["pdbx_database_id_PubMed"] = "?"
        fix_af3.fix_citation(block)
        table = self.check_citation(
            block, cid="2", n_citations=2, pos=1, loop=True
        )
        self.check_citation_author(block, n_authors=50)
        table = access.get_table(block, "_software")
        self.assertEqual(len(table), 2)
        self.assertEqual(table[0]["citation_id"], "2")
        self.assertEqual(table[1]["citation_id"], "?")
        # check sorting of citations for mix of numbers and strings
        table = access.get_table(block, "_citation")
        table[0]["id"] = "secondary"
        edit.add_rows(
            block,
            "_citation",
            {
                "id": "primary",
                "journal_full": "The X-Men",
                "title": "#1",
                "year": "1963",
                "journal_volume": "1",
            },
            ordinal_item=None,
        )
        fix_af3.fix_citation(block)
        table = access.get_table(block, "_citation")
        self.assertEqual(table[0]["id"], "primary")
        self.assertEqual(table[1]["id"], "2")
        self.assertEqual(table[2]["id"], "secondary")
        # duplicate AlphaFold software record, should throw an exception
        _add_software(block)
        with self.assertRaises(fix_af3.NotIdentifiedDuplicatedRecordError):
            fix_af3.fix_citation(block)

    def test_af3_citations(self):
        """Not a test dedicated to a function. Test various specimen of AF3
        citations. To be fixed properly."""
        for mock_file, mock_cif in af3_citations.AF3_CITATIONS:
            with self.subTest(mock_file=mock_file, mock_cif=mock_cif):
                block = cif.read_string(mock_cif).sole_block()
                fix_af3.fix_citation(block)
                self.check_citation(block)
                self.check_citation_author(block)
                table = access.get_table(block, "_software")
                self.assertEqual(len(table), 1)
                self.assertIsNone(table.loop)
                self.assertEqual(table[0]["citation_id"], "1")


# Here we start using Pytest instead of unittest. Over time, all unittest tests
# should be converted into Pytest.


def test_fix_software_location():
    """Check that fix_software_location works as expected."""
    # Load AF3 for raising exception, no _pdbx_data-usage at all
    block = cif.read_string(mockup_mmcif.AF3).sole_block()
    with pytest.raises(fix_af3.NotIdentifiedContextRecordError):
        fix_af3.fix_software_location(block)
    # Load AF3_SW_URL for raising exceptions
    block = cif.read_string(mockup_mmcif.AF3_CITATION).sole_block()
    with pytest.raises(fix_af3.NotIdentifiedContextRecordError) as exc:
        fix_af3.fix_software_location(block)
    assert exc.value.category == "_pdbx_data_usage"
    # check for server license
    table = access.get_table(block, "_pdbx_data_usage", items=["details"])
    table[0]["details"] = "RIGHT INPUT FOR alphafoldserver.com/output-terms."
    fix_af3.fix_software_location(block)
    table = access.get_table(block, "_software")
    assert len(table) == 2
    assert table[0]["name"] == "AlphaFold"
    assert table[0]["location"] == "https://alphafoldserver.com/"
    # check with license from GitHub build
    table = access.get_table(block, "_pdbx_data_usage", items=["details"])
    table[0]["details"] = "GitHub: github.com/google-deepmind/alphafold3"
    fix_af3.fix_software_location(block)
    table = access.get_table(block, "_software")
    assert len(table) == 2
    assert table[0]["name"] == "AlphaFold"
    assert (
        table[0]["location"] == "https://github.com/google-deepmind/alphafold3"
    )
    # Trigger exception when _software is not found
    table[0]["name"] = "NotAlphaFold"
    with pytest.raises(fix_af3.NotIdentifiedContextRecordError) as exc:
        fix_af3.fix_software_location(block)
    assert exc.value.category == "_software"
    # Trigger exception on multiple AlphaFold entries in _software
    table[0]["name"] = "AlphaFold"
    table[1]["name"] = "AlphaFold"
    with pytest.raises(fix_af3.NotIdentifiedDuplicatedRecordError):
        fix_af3.fix_software_location(block)


def test_notidentitifedcontextrecorderror():
    """Test exception,"""
    with pytest.raises(
        fix_af3.NotIdentifiedContextRecordError,
        match=r"^Could not identify record in category '_test1'\.$",
    ) as exc:
        raise fix_af3.NotIdentifiedContextRecordError("_test1")
    assert exc.value.category == "_test1"
    assert exc.value.item is None

    with pytest.raises(
        fix_af3.NotIdentifiedContextRecordError,
        match=r"^Could not identify record in category '_test2', item "
        + r"'test3'\.$",
    ) as exc:
        raise fix_af3.NotIdentifiedContextRecordError("_test2", item="test3")
    assert exc.value.category == "_test2"
    assert exc.value.item == "test3"

    with pytest.raises(
        fix_af3.NotIdentifiedContextRecordError,
        match=r"^Could not identify record in category '_test4': FOOBAR\.$",
    ) as exc:
        raise fix_af3.NotIdentifiedContextRecordError(
            "_test4", context=": FOOBAR"
        )
    assert exc.value.category == "_test4"
    assert exc.value.item is None

    with pytest.raises(
        fix_af3.NotIdentifiedContextRecordError,
        match=r"^Could not identify record in category '_test5', item "
        + r"'test6': BARFOO\.$",
    ) as exc:
        raise fix_af3.NotIdentifiedContextRecordError(
            "_test5", item="test6", context=": BARFOO"
        )
    assert exc.value.category == "_test5"
    assert exc.value.item == "test6"


def test_fix_protocol():
    """Test fix_protocol()."""
    # Unit tests are allowed to go a bit out of the boundaries of Pylint
    # pylint: disable=too-many-statements
    # Trigger exception on missing _entity
    block = cif.read_string(mockup_mmcif.AF3_CITATION).sole_block()
    with pytest.raises(edit.NotFoundCategoryError) as exc:
        fix_af3.fix_protocol(block)
    assert exc.value.category == ("_entity",)
    # Trigger exception on missing _ma_target_entity
    edit.add_category(block, "_entity", {"id": 1, "pdbx_description": "test"})
    with pytest.raises(edit.NotFoundCategoryError) as exc:
        fix_af3.fix_protocol(block)
    assert exc.value.category == ("_ma_target_entity",)
    # Test that everything works as expected
    block = cif.read_string(mockup_mmcif.AF3_PROTOCOL).sole_block()
    fix_af3.fix_protocol(block)
    table = access.get_table(block, "_ma_target_entity")
    assert len(table) > 0
    i = 0
    for i, row in enumerate(table, start=1):
        assert cif.as_int(row["data_id"]) == i
    table = access.get_table(block, "_ma_model_list")
    assert len(table) > 0
    for i, row in enumerate(table, start=i + 1):
        assert cif.as_int(row["data_id"]) == i
    table = access.get_table(block, "_ma_data")
    assert len(table) == 3
    assert len(table.tags) == 3
    data = {
        "content_type": ["target", "target", "model coordinates"],
        "id": [1, 2, 3],
        "name": [
            "bestest polymer in universe",
            "second best polythingi in universe",
            "Top ranked model",
        ],
    }
    for i, row in enumerate(table):
        assert cif.as_int(row["id"]) == data["id"][i]
        for itm in ["content_type", "name"]:
            assert cif.as_string(row[itm]) == data[itm][i]
    table = access.get_table(block, "_ma_data_group")
    assert len(table) == 3
    assert len(table.tags) == 3
    data = {
        "data_id": [1, 2, 3],
        "group_id": [1, 1, 2],
        "ordinal_id": [1, 2, 3],
    }
    for i, row in enumerate(table):
        for itm in ["data_id", "group_id", "ordinal_id"]:
            assert cif.as_int(row[itm]) == data[itm][i]
    table = access.get_table(block, "_ma_protocol_step")
    assert len(table) == 1
    assert len(table.tags) == 8
    cmp = {
        "ordinal_id": 1,
        "protocol_id": 1,
        "step_id": 1,
        "method_type": "modeling",
        "details": "Model generated with AlphaFold 3.",
        "software_group_id": 1,
        "input_data_group_id": 1,
        "output_data_group_id": 2,
    }
    for itm, val in cmp.items():
        try:
            tval = cif.as_int(table[0][itm])
        except ValueError:
            tval = cif.as_string(table[0][itm])
        assert tval == val, f"mismatch for '_ma_protocol_step.{itm}'"
    # Trigger exception when AF3 can't be found in _software
    table = access.get_table(block, "_software")
    for row in table:
        row["name"] = "betafold"
    with pytest.raises(fix_af3.NotIdentifiedContextRecordError):
        fix_af3.fix_protocol(block)
    # Trigger exception on duplicated AF3 software
    for row in table:
        row["name"] = "alphafold"
    with pytest.raises(fix_af3.NotIdentifiedDuplicatedRecordError):
        fix_af3.fix_protocol(block)
    # Trigger exception on missing _software
    table.erase()
    with pytest.raises(edit.NotFoundCategoryError) as exc:
        fix_af3.fix_protocol(block)
    assert exc.value.category == ("_software",)
    # Trigger exception on missing _ma_software_group
    access.get_table(block, "_ma_software_group").erase()
    with pytest.raises(edit.NotFoundCategoryError) as exc:
        fix_af3.fix_protocol(block)
    assert exc.value.category == ("_ma_software_group",)
    # Trigger exception on missing _ma_model_list.data_id & model_name
    table = access.get_table(block, "_ma_model_list")
    table.find_column("_ma_model_list.model_name").erase()
    with pytest.raises(edit.NotFoundItemError) as exc:
        fix_af3.fix_protocol(block)
    assert exc.value.item == ("_ma_model_list.model_name",)
    table.find_column("_ma_model_list.data_id").erase()
    with pytest.raises(edit.NotFoundItemError) as exc:
        fix_af3.fix_protocol(block)
    assert exc.value.item == ("_ma_model_list.data_id",)
    # Trigger exception on missing _ma_model_list
    table.erase()
    with pytest.raises(edit.NotFoundCategoryError) as exc:
        fix_af3.fix_protocol(block)
    assert exc.value.category == ("_ma_model_list",)
    # Trigger exception on missing _ma_target_entity.data_id
    table = access.get_table(block, "_ma_target_entity")
    table.find_column("_ma_target_entity.data_id").erase()
    with pytest.raises(edit.NotFoundItemError) as exc:
        fix_af3.fix_protocol(block)
    assert exc.value.item == ("_ma_target_entity.data_id",)
    # Make sure that single _ma_software_group produces the right protocol
    block = cif.read_string(mockup_mmcif.AF3_PROTOCOL).sole_block()
    table = access.get_table(block, "_ma_software_group")
    table.remove_row(1)
    fix_af3.fix_protocol(block)
    table = access.get_table(block, "_ma_protocol_step")
    assert len(table) == 1
    assert len(table.tags) == 8
    cmp = {
        "ordinal_id": 1,
        "protocol_id": 1,
        "step_id": 1,
        "method_type": "modeling",
        "details": "Model generated with AlphaFold 3.",
        "software_group_id": 1,
        "input_data_group_id": 1,
        "output_data_group_id": 2,
    }
    for itm, val in cmp.items():
        try:
            tval = cif.as_int(table[0][itm])
        except ValueError:
            tval = cif.as_string(table[0][itm])
        assert tval == val, f"mismatch for '_ma_protocol_step.{itm}'"


if __name__ == "__main__":
    unittest.main()
