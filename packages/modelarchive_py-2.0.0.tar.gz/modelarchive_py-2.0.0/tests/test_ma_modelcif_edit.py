"""Test the modelcif_overhauling.edit functionality."""

# Copyright (c) 2026, SIB - Swiss Institute of Bioinformatics and
#                     Biozentrum - University of Basel
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from contextlib import redirect_stderr
import io
import unittest

from gemmi import cif

import mockup_mmcif

from modelarchive.modelcif import access, edit


class TestEdit(unittest.TestCase):
    """Test editing ModelCIF files."""

    def test_notfounderror(self):
        """Make sure NotFoundError is working as expected."""
        # Test single vs. multiple values with multiple subjects, diff. is
        # 'does' vs. 'do' in string.
        with self.assertRaises(edit.NotFoundError) as exc:
            raise edit.NotFoundError(("Value", "Values"), "value", None)
        self.assertEqual(str(exc.exception), "Value 'value' does not exist.")
        with self.assertRaises(edit.NotFoundError) as exc:
            raise edit.NotFoundError(
                ("Value", "Values"), ["value1", "value2"], None
            )
        self.assertEqual(
            str(exc.exception), "Values 'value1', 'value2' do not exist."
        )
        # Test single vs. multiple values with single subject, diff. is 'does'
        # vs. 'do' in string.
        with self.assertRaises(edit.NotFoundError) as exc:
            raise edit.NotFoundError("Value", "value", None)
        self.assertEqual(str(exc.exception), "Value 'value' does not exist.")
        with self.assertRaises(edit.NotFoundError) as exc:
            raise edit.NotFoundError("Value(s)", ["value1", "value2"], None)
        self.assertEqual(
            str(exc.exception), "Value(s) 'value1', 'value2' do not exist."
        )

    def test_notfoundcategoryerror(self):
        """Check that deviations from NotFoundError work."""
        with self.assertRaises(edit.NotFoundCategoryError) as exc:
            raise edit.NotFoundCategoryError(category=["_cat1", "_cat2"])
        self.assertEqual(exc.exception.category, ("_cat1", "_cat2"))
        with self.assertRaises(edit.NotFoundCategoryError) as exc:
            raise edit.NotFoundCategoryError(category=("_cat3", "_cat4"))
        self.assertEqual(exc.exception.category, ("_cat3", "_cat4"))
        with self.assertRaises(edit.NotFoundCategoryError) as exc:
            raise edit.NotFoundCategoryError(category="_cat5")
        self.assertEqual(exc.exception.category, ("_cat5",))

    def test_notfounditemerror(self):
        """Check that deviations from NotFoundError work."""
        with self.assertRaises(edit.NotFoundItemError) as exc:
            raise edit.NotFoundItemError(item=["_cat1.itm1", "_cat2.itm2"])
        self.assertEqual(exc.exception.item, ("_cat1.itm1", "_cat2.itm2"))
        with self.assertRaises(edit.NotFoundItemError) as exc:
            raise edit.NotFoundItemError(item=("_cat3.itm3", "_cat4.itm4"))
        self.assertEqual(exc.exception.item, ("_cat3.itm3", "_cat4.itm4"))
        with self.assertRaises(edit.NotFoundItemError) as exc:
            raise edit.NotFoundItemError(item="_cat5.itm5")
        self.assertEqual(exc.exception.item, ("_cat5.itm5",))

    def test_move_category(self):
        """Make sure move_category is working as expected."""

        def _check_order(cat1, itms1, cat2, itms2):
            # Skip 'block' & 'self' here, not best practice but keep in simple
            # in Unit tests.
            idx = block.get_index(f"{cat1}.{itms1[0]}") + 1
            for itm in itms1[1:]:
                self.assertEqual(block.get_index(f"{cat1}.{itm}"), idx)
                idx += 1
            self.assertGreaterEqual(block.get_index(f"{cat2}.{itms2[0]}"), idx)
            idx = block.get_index(f"{cat2}.{itms2[0]}") + 1
            for itm in itms2[1:]:
                self.assertEqual(block.get_index(f"{cat2}.{itm}"), idx)
                idx += 1

        def _check_pdbx_audit_revision_history_first():
            # Check that _pdbx_audit_revision_history is before
            # _pdbx_audit_revision_group
            _check_order(
                "_pdbx_audit_revision_history",
                ["ordinal"],
                "_pdbx_audit_revision_group",
                ["ordinal"],
            )

        def _check_pdbx_audit_revision_group_first():
            # Check that _pdbx_audit_revision_group is before
            # _pdbx_audit_revision_group
            _check_order(
                "_pdbx_audit_revision_group",
                ["ordinal"],
                "_pdbx_audit_revision_history",
                ["ordinal"],
            )

        def _check_ma_data_first():
            # Check that _ma_data is before _ma_associated_archive_file_details
            _check_order(
                "_ma_data",
                ["id", "name", "content_type"],
                "_ma_associated_archive_file_details",
                [
                    "id",
                    "archive_file_id",
                    "file_path",
                    "file_format",
                    "file_content",
                    "description",
                    "data_id",
                ],
            )

        def _check_ma_associated_archive_file_details_first():
            # Check that _ma_associated_archive_file_details is before _ma_data
            _check_order(
                "_ma_associated_archive_file_details",
                [
                    "id",
                    "archive_file_id",
                    "file_path",
                    "file_format",
                    "file_content",
                    "description",
                    "data_id",
                ],
                "_ma_data",
                ["id", "name", "content_type"],
            )

        # Load REVISION with loop categories '_pdbx_audit_revision_history' and
        # '_pdbx_audit_revision_group'.
        block = cif.read_string(mockup_mmcif.REVISION).sole_block()
        # check order is as expected in test data
        _check_pdbx_audit_revision_history_first()
        # loop: move after
        edit.move_category(
            block,
            "_pdbx_audit_revision_history",
            "after:_pdbx_audit_revision_group",
        )
        _check_pdbx_audit_revision_group_first()
        # loop: move before
        edit.move_category(
            block,
            "_pdbx_audit_revision_history",
            "before:_pdbx_audit_revision_group",
        )
        _check_pdbx_audit_revision_history_first()
        # loop: move by nummerical index
        edit.move_category(block, "_pdbx_audit_revision_group", 0)
        _check_pdbx_audit_revision_group_first()
        # loop: move beyond the last position
        with self.assertRaises(edit.MoveIdxToFarError):
            edit.move_category(
                block,
                "_pdbx_audit_revision_group",
                len(block.get_mmcif_category_names()),
            )
        # Load mockup data with pair categories '_ma_data' and
        # '_ma_associated_archive_file_details'.
        block = cif.read_string(mockup_mmcif.THREE_PAIR_CATEGORIES).sole_block()
        # check order is as expected in test data
        _check_ma_data_first()
        # pair: move after
        edit.move_category(
            block,
            "_ma_data",
            "after:_ma_associated_archive_file_details",
        )
        _check_ma_associated_archive_file_details_first()
        # pair: move before
        edit.move_category(
            block,
            "_ma_data",
            "before:_ma_associated_archive_file_details",
        )
        _check_ma_data_first()
        # pair: move by nummerical index
        edit.move_category(block, "_ma_data", -1)
        _check_ma_associated_archive_file_details_first()
        # pair: move beyond the last position
        with self.assertRaises(edit.MoveIdxToFarError):
            edit.move_category(
                block,
                "_ma_associated_archive_file_details",
                block.get_index("_ma_data.content_type") + 1,
            )
        # check NotFoundCategoryError is raised
        with self.assertRaises(edit.NotFoundCategoryError):
            edit.move_category(block, "_does_not_exist", 0)
        # check ValueError on wrong placement string
        with self.assertRaises(ValueError):
            edit.move_category(
                block, "_ma_associated_archive_file_details", "iffyplacement"
            )
        # check ValueError on wrong position string in placement string
        with self.assertRaises(ValueError):
            edit.move_category(
                block,
                "_ma_associated_archive_file_details",
                "inthemiddle:_ma_data",
            )
        # Try to move with repsect to a non-existing category, should not move
        edit.move_category(block, "_audit_conform", "before:_does_not_exist")
        self.assertEqual(block.get_index("_audit_conform.dict_name"), 0)

    def test_add_column(self):
        """Check adding new columns."""

        def make_return_string(string):
            """Simply return a string as value."""

            def callback(row):
                # Pure dummy function, ignore pylint
                # pylint: disable=unused-argument
                return string

            return callback

        # test adding column to loop
        block = cif.read_string(
            mockup_mmcif.PDBX_NONPOLY_SCHEME_INCMPLTE
        ).sole_block()
        # check error is thrown on missing category
        with self.assertRaises(edit.NotFoundCategoryError):
            edit.add_column(block, "_foo", "bar", make_return_string("bar"))
        cat = "_pdbx_nonpoly_scheme"
        # make sure _pdbx_nonpoly_scheme is a loop
        self.assertNotEqual(block.find_mmcif_category(f"{cat}.").loop, None)
        edit.add_column(
            block,
            cat,
            "ndb_seq_num",
            edit.make_res_per_chain_counter("asym_id"),
            pos=4,
        )
        table = block.find_mmcif_category(f"{cat}.")
        # make sure _pdbx_nonpoly_scheme is still a loop
        self.assertNotEqual(table.loop, None)
        # check stats of table
        self.assertEqual(table.width(), 8)
        self.assertEqual(len(table), 4)
        self.assertEqual(
            list(table.tags),
            [
                f"{cat}.asym_id",
                f"{cat}.auth_seq_num",
                f"{cat}.entity_id",
                f"{cat}.ndb_seq_num",
                f"{cat}.mon_id",
                f"{cat}.pdb_ins_code",
                f"{cat}.pdb_seq_num",
                f"{cat}.pdb_strand_id",
            ],
        )
        # check values of table
        # gemmi reads data in a string, would need to be casted to int...
        exp_nsn = ["1", "1", "1", "2"]
        for i, row in enumerate(table):
            self.assertEqual(row["ndb_seq_num"], exp_nsn[i])

        # test that existing item is not overwritten (prints warning to stdout)
        edit.add_column(block, cat, "ndb_seq_num", make_return_string("bar"))
        table = block.find_mmcif_category(f"{cat}.")
        for i, row in enumerate(table):
            self.assertNotEqual(row["ndb_seq_num"], "nonumber")
            self.assertEqual(row["ndb_seq_num"], exp_nsn[i])

        # test raw-feature:
        # - turn off quoting
        # - introduce double-quoting
        # - go with quotes of value
        edit.add_column(
            block, cat, "foo", make_return_string("no quotes"), raw=True
        )
        table = block.find_mmcif_category(f"{cat}.")
        self.assertEqual(table[0]["foo"], "no quotes")
        edit.add_column(
            block,
            cat,
            "bar",
            make_return_string("'with quotes'"),
        )
        table = block.find_mmcif_category(f"{cat}.")
        self.assertEqual(table[0]["bar"], "\"'with quotes'\"")
        edit.add_column(
            block,
            cat,
            "foobar",
            make_return_string("'with quotes but raw'"),
            raw=True,
        )
        table = block.find_mmcif_category(f"{cat}.")
        self.assertEqual(table[0]["foobar"], "'with quotes but raw'")

        ## test adding column to value pair
        block = cif.read_string(mockup_mmcif.AUDIT_CONFORM_PAIR).sole_block()
        # make sure _audit_conform is paired values
        cat = "_audit_conform"
        self.assertEqual(block.find_mmcif_category(f"{cat}.").loop, None)
        # add to end
        edit.add_column(
            block,
            cat,
            "foo",
            make_return_string("bar"),
        )
        # add before end
        edit.add_column(
            block,
            cat,
            "bar",
            make_return_string("foo"),
            pos=2,
        )
        # make sure _audit_conform is still paired values
        self.assertEqual(
            block.find_mmcif_category("_audit_conform.").loop, None
        )
        # check stats of table
        table = block.find_mmcif_category(f"{cat}.")
        self.assertEqual(table.width(), 5)
        self.assertEqual(len(table), 1)
        self.assertEqual(
            list(table.tags),
            [
                f"{cat}.dict_location",
                f"{cat}.bar",
                f"{cat}.dict_name",
                f"{cat}.dict_version",
                f"{cat}.foo",
            ],
        )
        # check values
        self.assertEqual(table[0]["foo"], "bar")
        self.assertEqual(table[0][1], "foo")
        # check that position at the end of a item/ value pair works
        block = cif.read_string(mockup_mmcif.THREE_PAIR_CATEGORIES).sole_block()
        cat = "_ma_data"
        edit.add_column(block, cat, "foo", make_return_string("bar"), pos=-1)
        table = access.get_table(block, "_ma_data")
        self.assertEqual(table.tags[-1], "_ma_data.foo")

    def test_add_category(self):
        """Explore edit.add_category."""
        # `raw` parameter of add_category is not tested, it is handed over to
        # gemmi functions, so we expect gemmi to have it tested.
        # Unit tests don't care too much about Pylint...
        # pylint: disable=too-many-statements
        block = cif.read_string(mockup_mmcif.PAIR).sole_block()
        # check loops work, w/o placement param
        cat = "_loop_category"
        edit.add_category(
            block,
            cat,
            {"foo": [1, 2, 3], "bar": ["a", "b", "c"]},
        )
        table = block.find_mmcif_category(f"{cat}.")
        self.assertNotEqual(len(table), 0, msg=f"_loop '{cat}' was not created")
        self.assertNotEqual(table.loop, None)
        self.assertEqual(len(table), 3)
        self.assertEqual(table.width(), 2)
        self.assertEqual(list(table.tags), [f"{cat}.foo", f"{cat}.bar"])
        exp_vls = [("1", "a"), ("2", "b"), ("3", "c")]
        for i, row in enumerate(table):
            self.assertEqual(row[0], exp_vls[i][0])
            self.assertEqual(row["bar"], exp_vls[i][1])
        # check to not skip adding on existing category
        with redirect_stderr(io.StringIO()) as buffer:
            edit.add_category(block, cat, {"foo": 4, "bar": "d"})
        self.assertTrue(buffer.getvalue().startswith("Warning: "))
        # check to not add when item_data has no values
        buffer = None
        with redirect_stderr(io.StringIO()) as buffer:
            edit.add_category(block, "_bar", {})
        self.assertTrue(buffer.getvalue().startswith("Warning: "))
        # check named pairs work, placing by index
        table = block.find_mmcif_category("_ma_target_ref_db_details.")
        pos = block.get_index(table.tags[-1]) + 1
        cat = "_pair_category"
        edit.add_category(
            block,
            cat,
            {"foo_pr": 1, "bar_pr": "a"},
            index=pos,
        )
        table = block.find_mmcif_category(f"{cat}.")
        self.assertNotEqual(len(table), 0, msg=f"pairs '{cat}' was not created")
        self.assertEqual(table.loop, None)
        self.assertEqual(len(table), 1)
        self.assertEqual(table.width(), 2)
        self.assertEqual(list(table.tags), [f"{cat}.foo_pr", f"{cat}.bar_pr"])
        self.assertEqual(table[0][0], "1")
        self.assertEqual(table[0]["bar_pr"], "a")
        self.assertEqual(block.get_index(table.tags[0]), pos)

        # check placement with index for loops
        cat = "_pos_loop"
        edit.add_category(
            block,
            cat,
            {"pos1": [1, 4, 7], "pos2": [2, 5, 8], "pos3": [3, 6, 9]},
            index=pos,
        )
        table = block.find_mmcif_category(f"{cat}.")
        self.assertNotEqual(len(table), 0, msg=f"loop '{cat}' was not created")
        self.assertNotEqual(table.loop, None)
        self.assertEqual(len(table), 3)
        self.assertEqual(table.width(), 3)
        self.assertEqual(
            list(table.tags), [f"{cat}.pos1", f"{cat}.pos2", f"{cat}.pos3"]
        )
        exp_vls = [("1", "2", "3"), ("4", "5", "6"), ("7", "8", "9")]
        for i, row in enumerate(table):
            self.assertEqual(row[0], exp_vls[i][0])
            self.assertEqual(row["pos2"], exp_vls[i][1])
            self.assertEqual(row[2], exp_vls[i][2])
        self.assertEqual(block.get_index(table.tags[0]), pos)

        # check relative placement for pair
        cat = "_rel_pos_pair"
        edit.add_category(
            block,
            cat,
            {"rp1": ["first value"], "rp2": ["second value"]},
            index="before:_pos_loop",
        )
        table = block.find_mmcif_category(f"{cat}.")
        self.assertNotEqual(len(table), 0, msg=f"pairs '{cat}' was not created")
        self.assertEqual(table.loop, None)
        self.assertEqual(len(table), 1)
        self.assertEqual(table.width(), 2)
        self.assertEqual(list(table.tags), [f"{cat}.rp1", f"{cat}.rp2"])
        self.assertEqual(table[0][0], "'first value'")
        self.assertEqual(cif.as_string(table[0]["rp2"]), "second value")
        self.assertEqual(
            block.get_index(table.tags[-1]),
            block.get_index("_pos_loop.pos1") - 1,
        )

        # check relative placement for loop
        cat = "_rel_pos_loop"
        edit.add_category(
            block,
            cat,
            {"rl1": ["abc", "def"], "rl2": [123, 456]},
            index="after:_pair_category",
        )
        table = block.find_mmcif_category(f"{cat}.")
        self.assertNotEqual(len(table), 0, msg=f"loop '{cat}' was not created")
        self.assertNotEqual(table.loop, None)
        self.assertEqual(len(table), 2)
        self.assertEqual(table.width(), 2)
        self.assertEqual(list(table.tags), [f"{cat}.rl1", f"{cat}.rl2"])
        exp_vls = [("abc", 123), ("def", 456)]
        for i, row in enumerate(table):
            self.assertEqual(row["rl1"], exp_vls[i][0])
            self.assertEqual(cif.as_int(row[1]), exp_vls[i][1])
        self.assertEqual(
            block.get_index(table.tags[0]),
            block.get_index("_pair_category.bar_pr") + 1,
        )

    def test_add_rows(self):
        """Explore edit.add_rows."""
        block = cif.read_string(mockup_mmcif.EMPTY).sole_block()
        # make sure no empty categories are added
        edit.add_rows(block, "_foo", {}, ordinal_item=None)
        table = block.find_mmcif_category("_foo.")
        self.assertEqual(len(table), 0)
        # trigger adding a pair
        edit.add_rows(
            block, "_foo", {"bar": 1, "foo": ["BAR 1"]}, ordinal_item=None
        )
        table = block.find_mmcif_category("_foo.")
        self.assertEqual(len(table), 1)
        self.assertIsNone(table.loop)
        # trigger turning a pair into a loop and check adding to existing loop
        edit.add_rows(
            block,
            "_foo.",
            {"bar": [2, 3], "foo": ["BAR 2", "BAR3"]},
            ordinal_item=None,
        )
        table = block.find_mmcif_category("_foo.")
        self.assertEqual(len(table), 3)
        self.assertIsNotNone(table.loop)
        self.assertEqual(list(table.tags), ["_foo.bar", "_foo.foo"])
        test_data = [["1", "'BAR 1'"], ["2", "'BAR 2'"], ["3", "BAR3"]]
        for i, res in enumerate(list(table)):
            self.assertEqual(list(res), test_data[i])
        # add a new category but as loop
        edit.add_rows(
            block,
            "_bar",
            {"foo": [1, 2], "bar": ["FOO 1", "FOO2"]},
            ordinal_item=None,
        )
        table = block.find_mmcif_category("_bar")
        self.assertEqual(len(table), 2)
        self.assertIsNotNone(table.loop)
        self.assertEqual(list(table.tags), ["_bar.foo", "_bar.bar"])
        test_data = [["1", "'FOO 1'"], ["2", "FOO2"]]
        for i, res in enumerate(list(table)):
            self.assertEqual(list(res), test_data[i])
        # check that having value lists of different lengths is caught
        with self.assertRaises(ValueError):
            edit.add_rows(
                block, "_foo", {"bar": [4, 5], "foo": 6}, ordinal_item=None
            )
        # check that ordinal works
        edit.add_rows(block, "_a", {"b": "B", "c": "C"})
        table = block.find_mmcif_category("_a")
        self.assertEqual(list(table.tags), ["_a.ordinal", "_a.b", "_a.c"])
        edit.add_rows(block, "_a", {"b": "D", "c": "E"})
        table = block.find_mmcif_category("_a")
        self.assertEqual(len(table), 2)
        for i in range(1, len(table) + 1):
            self.assertEqual(table[i - 1]["ordinal"], str(i))
        # test ordinals at an unusal position
        edit.add_rows(
            block, "_b", {"c": "F", "d": 1, "e": "G"}, ordinal_item="d"
        )
        table = block.find_mmcif_category("_b")
        self.assertEqual(list(table.tags), ["_b.c", "_b.d", "_b.e"])
        self.assertEqual(list(table[0]), ["F", "1", "G"])
        edit.add_rows(block, "_b", {"c": "H", "e": "I"}, ordinal_item="d")
        table = block.find_mmcif_category("_b")
        self.assertEqual(list(table[1]), ["H", "2", "I"])
        # test missing tags to be filled with '.'
        edit.add_rows(block, "_b", {"c": "J"}, ordinal_item="d")
        table = block.find_mmcif_category("_b")
        self.assertEqual(list(table[2]), ["J", "3", "."])

    def test_sort_table(self):
        """Make sure sorting tables works as expected."""
        block = cif.read_string(mockup_mmcif.EMPTY).sole_block()
        # create a mockup table
        edit.add_rows(
            block,
            "_unique_ints",
            {
                "id": [10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
                "arbitrary": ["A", "B", "C", "D", "E", "F", "G", "H", "I", "I"],
            },
            ordinal_item=None,
        )
        table = access.get_table(block, "_unique_ints")
        # sort by number
        edit.sort(table, "id")
        result = block.get_mmcif_category("_unique_ints")
        result = [int(i) for i in result["id"]]
        self.assertEqual(result, list(range(1, len(result) + 1)))
        # trigger exception
        with self.assertRaises(ValueError):
            edit.sort(block, "arbitrary")
        # sort alphabetically
        edit.sort(block, "arbitrary", category="_unique_ints")
        result = block.get_mmcif_category("_unique_ints")
        self.assertEqual(
            result["arbitrary"],
            ["A", "B", "C", "D", "E", "F", "G", "H", "I", "I"],
        )
        # check that sorting is stable
        self.assertEqual(
            result["id"], ["10", "9", "8", "7", "6", "5", "4", "3", "1", "2"]
        )


if __name__ == "__main__":
    unittest.main()
