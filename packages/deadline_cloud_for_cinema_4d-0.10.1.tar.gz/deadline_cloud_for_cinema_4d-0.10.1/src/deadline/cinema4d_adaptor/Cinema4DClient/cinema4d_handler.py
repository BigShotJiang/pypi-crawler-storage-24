# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
from __future__ import annotations

import os
import traceback
from typing import Any, Callable, Dict

# The Cinema4D Adaptor adds the `deadline` namespace directory to PYTHONPATH,
# so that importing just the cinema4d_adaptor should work.
try:
    from cinema4d_adaptor.Cinema4DClient import tile_rendering  # type: ignore[import]
except (ImportError, ModuleNotFoundError):
    from deadline.cinema4d_adaptor.Cinema4DClient import tile_rendering  # type: ignore[import]

try:
    import c4d  # type: ignore
    import maxon
    from c4d import bitmaps
except ImportError:  # pragma: no cover
    raise OSError("Could not find the Cinema4D module. Are you running this inside of Cinema4D?")

_RENDERRESULT = {
    c4d.RENDERRESULT_OK: "Function was successful.",
    c4d.RENDERRESULT_OUTOFMEMORY: "Not enough memory.",
    c4d.RENDERRESULT_ASSETMISSING: "Assets (textures etc.) are missing.",
    c4d.RENDERRESULT_SAVINGFAILED: "Failed to save.",
    c4d.RENDERRESULT_USERBREAK: "User stopped the processing.",
    c4d.RENDERRESULT_GICACHEMISSING: "GI cache is missing.",
    c4d.RENDERRESULT_NOMACHINE: "Machine was not found. (Team Rendering only)",
    c4d.RENDERRESULT_PROJECTNOTFOUND: "Project was not found.",
    c4d.RENDERRESULT_ERRORLOADINGPROJECT: "There was an error while loading the project.",
    c4d.RENDERRESULT_NOOUTPUTSPECIFIED: "Output was not specified.",
}

USE_CACHED_TEXT_KEY = "use_cached_text"
FRAME_KEY = "frame"
OUTPUT_PATH_KEY = "output_path"
MULTIPASS_PATH_KEY = "multi_pass_path"
SCENE_FILE_KEY = "scene_file"
START_RENDER_KEY = "start_render"
ASSEMBLE_TILES_KEY = "assemble_tiles"
TAKE_KEY = "take"


def progress_callback(progress_percent, progress_type_int):
    """Function passed in RenderDocument. It will be called automatically by Cinema 4D with the current render progress.

    Args:
        progress (float): The percent of the progress for the current step
        progress_type (c4d.RENDERPROGRESSTYPE): The Main part of the current rendering step
    """
    progress_type_map = {
        c4d.RENDERPROGRESSTYPE_BEFORERENDERING: "before rendering",
        c4d.RENDERPROGRESSTYPE_DURINGRENDERING: "during rendering",
        c4d.RENDERPROGRESSTYPE_AFTERRENDERING: "after rendering",
        c4d.RENDERPROGRESSTYPE_GLOBALILLUMINATION: "global illumination",
        c4d.RENDERPROGRESSTYPE_QUICK_PREVIEW: "quick preview",
        c4d.RENDERPROGRESSTYPE_AMBIENTOCCLUSION: "ambient occlusion",
    }
    if progress_type_int in progress_type_map:
        progress_type_text = progress_type_map[progress_type_int]
    else:
        progress_type_text = f"Unknown progress type ({progress_type_int})"

    print(f"Progress update ({progress_type_text}): {progress_percent * 100.0}%")

    if progress_type_int == c4d.RENDERPROGRESSTYPE_DURINGRENDERING:
        print("ALF_PROGRESS %g" % (progress_percent * 100))


class Cinema4DHandler:
    action_dict: Dict[str, Callable[[Dict[str, Any]], None]] = {}
    render_kwargs: Dict[str, Any]
    map_path: Callable[[str], str]

    C4D_FONT_INDEX = c4d.DescID(
        c4d.DescLevel(c4d.PRIM_TEXT_FONT, c4d.FONTCHOOSER_DATA, c4d.OBJECT_SPLINETEXT)
    )

    def __init__(self, map_path: Callable[[str], str]) -> None:
        """
        Constructor for the c4dpy handler. Initializes action_dict and render variables
        """
        self.action_dict = {
            SCENE_FILE_KEY: self.set_scene_file,
            TAKE_KEY: self.set_take,
            FRAME_KEY: self.set_frame,
            START_RENDER_KEY: self.start_render,
            ASSEMBLE_TILES_KEY: self.assemble_tiles,
            OUTPUT_PATH_KEY: self.output_path,
            MULTIPASS_PATH_KEY: self.multi_pass_path,
            USE_CACHED_TEXT_KEY: self.use_cached_text,
        }
        self.render_kwargs = {}
        self.take = "Main"
        self.map_path = map_path
        self.has_unmapped_pyro = False
        self.cached_text_was_used_in_previous_frame = False

    def _remap_assets(self) -> None:
        """
        Asset references in the .c4d files are not automatically re-mapped if they are
        absolute paths. This function remaps the asset references to the new paths.
        """
        asset_list: list[Dict[str, Any]] = []
        c4d.documents.GetAllAssetsNew(
            self.doc, allowDialogs=False, lastPath="", assetList=asset_list
        )
        for asset in asset_list:
            owner = asset.get("owner")
            param_id = asset.get("paramId")
            filename = asset.get("filename")
            node_space = asset.get("nodeSpace")
            node_path = asset.get("nodePath")
            if not (owner and param_id and filename):
                # unrelated asset, e.g. the main scene which is already pathmapped
                continue
            mapped_path = self.map_path(filename)
            # note: we can't skip if mapped_path == filename because some internal
            # references in the owner nodes may need to be updated

            # whether we have done owner[param_id] = mapped_path
            attempted_basic_path_mapping_approach = False
            try:
                success = self._pathmap_recognized_types(
                    owner, param_id, node_space, node_path, mapped_path
                )

                if not success:
                    print(
                        f"WARNING: asset wasn't recognized. Attempting to path map {owner}[{param_id}] = {mapped_path}"
                    )
                    attempted_basic_path_mapping_approach = True
                    owner[param_id] = mapped_path

            except Exception as e:
                print(
                    f"WARNING: asset with asset owner '{owner}', asset paramId {param_id}, filename "
                    f"'{filename}', nodeSpace '{node_space}', and nodePath '{node_path}' could not be path "
                    f"mapped. Error: {e} {traceback.format_exc()}"
                )
                if not attempted_basic_path_mapping_approach:
                    print(
                        f"Attempting to use basic path mapping {owner}[{param_id}] = {mapped_path}"
                    )
                    try:
                        owner[param_id] = mapped_path
                    except Exception as f:
                        print(
                            f"{owner}[{param_id}] = {mapped_path} failed. Error: {f} {traceback.format_exc()}"
                        )

        if self.has_unmapped_pyro:
            print(
                "Pyro elements were detected in the scene. If the pyro is not appearing in the "
                "output, the you can use one of the following approaches to resolve the issue:\n"
                " * Update the scene assets to use localized paths (Project Asset Inspector => [select all assets] => Asset => Localize Filenames)\n"
                " * Save the scene using 'Save Project with Assets'\n"
                " * Submit the scene with the 'Save Cinema 4D project with assets before submission' option"
            )

    def _pathmap_recognized_types(
        self, owner, param_id, node_space, node_path, mapped_path
    ) -> bool:
        """
        Applies path mapping to recognized owner types.

        Returns True if the owner is recognized and has been path mapped.
        Returns False otherwise.
        """
        if isinstance(owner, c4d.BaseShader):
            # C4D classic textures
            return self._pathmap_base_shader(owner, param_id, mapped_path)

        if isinstance(owner, c4d.BaseObject):
            # Redshift light textures
            return self._pathmap_base_object(owner, mapped_path)

        if isinstance(owner, c4d.documents.BaseVideoPost):
            # PostFX, e.g. LUT files or background files
            return self._pathmap_base_video_post(owner, mapped_path)

        if isinstance(owner, c4d.BaseMaterial):
            # Redshift node-based materials
            return self._pathmap_base_material(owner, node_space, node_path, mapped_path)

        return False

    def _pathmap_base_shader(self, owner, param_id, mapped_path) -> bool:
        # C4D classic materials have a param ID other than -1
        if param_id != -1:
            owner[param_id] = mapped_path
            return True
        return False

    def _pathmap_base_object(self, owner, mapped_path) -> bool:
        # c4d.BaseObject e.g. Redshift light texture
        mapped = False
        for item in [
            c4d.REDSHIFT_LIGHT_PHYSICAL_TEXTURE,
            c4d.REDSHIFT_LIGHT_DOME_TEX0,
            c4d.REDSHIFT_LIGHT_DOME_TEX1,
        ]:
            # there are three types of textures for Redshift lights.
            # For each type of texture, we check if the texture is specified,
            # and if it is, we override the path
            desc_id = c4d.DescID(
                # 1036765 is the data type for textures
                c4d.DescLevel(item, 1036765),
                c4d.DescLevel(c4d.REDSHIFT_FILE_PATH, c4d.DTYPE_STRING, 0),
            )
            existing_path = owner[desc_id]
            if existing_path:
                owner[desc_id] = mapped_path
                mapped = True

        if hasattr(c4d, "Opyro") and owner.GetType() == c4d.Opyro:
            # Opyro (i.e. Pyro output starting in C4D 2026) actually breaks if you try
            # to pathmap it, so we will simply return True to indicate that all applicable
            # pathmapping operations (i.e. none) are complete.
            self.has_unmapped_pyro = True
            return True

        return mapped

    def _pathmap_base_video_post(self, owner, mapped_path) -> bool:
        # PostFX, e.g. LUT files or background files
        path = owner[c4d.REDSHIFT_POSTEFFECTS_LUT_FILE]
        if path:
            owner[c4d.REDSHIFT_POSTEFFECTS_LUT_FILE] = mapped_path
            return True
        return False

    def _pathmap_base_material(self, owner, node_space, node_path, mapped_path) -> bool:
        # Redshift materials
        if not (node_path and node_space == "com.redshift3d.redshift4c4d.class.nodespace"):
            return False

        # Redshift node
        node_material = owner.GetNodeMaterialReference()
        graph = node_material.GetGraph(maxon.Id(node_space))
        with graph.BeginTransaction() as transaction:
            node = graph.GetNode(maxon.NodePath(node_path))
            node_id = node.GetId().ToString()
            if node_id.split("@")[0] == "texturesampler":
                path_port = (
                    node.GetInputs()
                    .FindChild("com.redshift3d.redshift4c4d.nodes.core.texturesampler.tex0")
                    .FindChild("path")
                )
                path_port.SetDefaultValue(mapped_path)
            else:
                print(f"Unrecognized nodeId {node_id}")
                return False
            transaction.Commit()
        return True

    def start_render(self, data: dict) -> None:
        if self.cached_text_was_used_in_previous_frame:
            # Close and then reload document since we collapsed some text in the previous frame
            # and it can no longer be animated.
            # Reloading the document will allow the next frame to have correct data.
            self._reload_document()

        self.render_data = self.doc.GetActiveRenderData()
        self.render_data[c4d.RDATA_FRAMESEQUENCE] = c4d.RDATA_FRAMESEQUENCE_MANUAL
        self.render_kwargs[FRAME_KEY] = int(self.render_kwargs.get(FRAME_KEY, data[FRAME_KEY]))
        frame = self.render_kwargs[FRAME_KEY]
        fps = self.doc.GetFps()
        frame_time = c4d.BaseTime(frame, fps)
        self.render_data[c4d.RDATA_FRAMEFROM] = frame_time
        self.render_data[c4d.RDATA_FRAMETO] = frame_time
        self.render_data[c4d.RDATA_FRAMESTEP] = 1

        if self.render_data[c4d.RDATA_PATH]:
            self.render_data[c4d.RDATA_PATH] = self.map_path(self.render_data[c4d.RDATA_PATH])
        if (
            self.render_data[c4d.RDATA_MULTIPASS_SAVEIMAGE]
            and self.render_data[c4d.RDATA_MULTIPASS_FILENAME]
        ):
            self.render_data[c4d.RDATA_MULTIPASS_FILENAME] = self.map_path(
                self.render_data[c4d.RDATA_MULTIPASS_FILENAME]
            )

        # Set up tile rendering if this is a tile render action
        tile_action = data.get("tile_action", "")
        is_tile_render = tile_action == "render"
        tile_ctx = None
        if is_tile_render:
            tile_ctx = tile_rendering.setup_tile_render(self.render_data, data)

        width = int(self.render_data[c4d.RDATA_XRES])
        height = int(self.render_data[c4d.RDATA_YRES])
        if is_tile_render:
            bm = tile_rendering.create_tile_bitmap(width, height)
        else:
            bm = bitmaps.MultipassBitmap(width, height, c4d.COLORMODE_RGB)
        rd = self.render_data.GetDataInstance()

        self.cached_text_was_used_in_previous_frame = self._cache_text_if_needed(frame_time)

        result = c4d.documents.RenderDocument(
            self.doc,
            rd,
            bm,
            c4d.RENDERFLAGS_EXTERNAL | c4d.RENDERFLAGS_SHOWERRORS,
            prog=progress_callback,
        )

        result_description = _RENDERRESULT.get(result)
        if result_description is None:
            raise RuntimeError("Error: unhandled render result: %s" % result)
        if result != c4d.RENDERRESULT_OK:
            raise RuntimeError("Error: render result: %s" % result_description)

        # Post-render tile processing: OCIO bake, crop, save tile, restore paths
        if is_tile_render and tile_ctx is not None:
            tile_rendering.finalize_tile_render(bm, rd, tile_ctx, self.render_data, frame)

        print("Finished Rendering")

    def assemble_tiles(self, data: dict) -> None:
        """Assemble tile images into a single full-resolution image."""
        tile_rendering.assemble_tiles(self.doc, data, self.map_path)

    def output_path(self, data: dict) -> None:
        output_path = data.get(OUTPUT_PATH_KEY, "")
        self.render_kwargs[OUTPUT_PATH_KEY] = output_path
        if output_path:
            doc = c4d.documents.GetActiveDocument()
            render_data = doc.GetActiveRenderData()
            render_data[c4d.RDATA_PATH] = self.map_path(output_path)

    def multi_pass_path(self, data: dict) -> None:
        multi_pass_path = data.get(MULTIPASS_PATH_KEY, "")
        self.render_kwargs[MULTIPASS_PATH_KEY] = multi_pass_path
        if multi_pass_path:
            doc = c4d.documents.GetActiveDocument()
            render_data = doc.GetActiveRenderData()
            render_data[c4d.RDATA_MULTIPASS_FILENAME] = self.map_path(multi_pass_path)

    def set_take(self, data: dict) -> None:
        """
        Sets the take to render

        Args:
            data (dict):
        """
        take_name = data.get(TAKE_KEY, "")
        self.render_kwargs[TAKE_KEY] = take_name
        doc = c4d.documents.GetActiveDocument()
        take_data = doc.GetTakeData()
        if not take_data:
            return

        def get_child_takes(take):
            child_takes = take.GetChildren()
            all_takes = child_takes
            if child_takes:
                for child_take in child_takes:
                    all_takes.extend(get_child_takes(child_take))
            return all_takes

        main_take = take_data.GetCurrentTake()
        all_takes = [main_take] + get_child_takes(main_take)

        take = None
        for take in all_takes:
            if take.GetName() == take_name:
                break
        if take is None:
            print("Error: take not found: %s" % take_name)
        take_data.SetCurrentTake(take)

    def use_cached_text(self, data: dict) -> None:
        """
        Sets whether text should be cached on Linux

        Args:
            data (dict): the data of whether to cache the text in the format {USE_CACHED_TEXT_KEY: bool}
        """
        self.render_kwargs[USE_CACHED_TEXT_KEY] = bool(int(data.get(USE_CACHED_TEXT_KEY, 0)))

    def set_frame(self, data: dict) -> None:
        """
        Sets the frame to render

        Args:
            data (dict):
        """
        self.render_kwargs[FRAME_KEY] = int(data[FRAME_KEY])

    def set_scene_file(self, data: dict) -> None:
        """
        Opens the scene file in Cinema4D.

        Args:
            data (dict): The data given from the Adaptor. Keys expected: ['scene_file']

        Raises:
            FileNotFoundError: If path to the scene file does not yield a file
        """
        scene_file = data.get(SCENE_FILE_KEY, "")
        self.render_kwargs[SCENE_FILE_KEY] = data[SCENE_FILE_KEY]
        if not os.path.isfile(scene_file):
            raise FileNotFoundError(f"The scene file '{scene_file}' does not exist")
        doc = c4d.documents.LoadDocument(
            scene_file, c4d.SCENEFILTER_OBJECTS | c4d.SCENEFILTER_MATERIALS
        )
        if doc is None:
            raise RuntimeError(
                f"Failed to load the scene file '{scene_file}'. The file may be corrupt or not a valid Cinema 4D document."
            )
        # Build animations, caches and expressions for all frames in the document.
        # This is essential for dynamic content like Pyro simulations (fluid/smoke effects)
        # which would otherwise render as blank. The parameters ensure all necessary
        # elements (animation, expressions, caches) are processed.
        doc.ExecutePasses(
            bt=None, animation=True, expressions=True, caches=True, flags=c4d.BUILDFLAGS_NONE
        )

        c4d.documents.InsertBaseDocument(doc)
        c4d.documents.SetActiveDocument(doc)
        self.doc = doc
        self._remap_assets()

    def _has_cached_text(self, objects: list[Any]) -> bool:
        for obj in objects:
            font_container = obj[self.C4D_FONT_INDEX]
            font = font_container.GetFont()
            if font:
                return True
            children = obj.GetChildren()
            if children and self._has_cached_text(children):
                return True
        return False

    def _get_all_text_objects(self, objects: list[Any]) -> list[Any]:
        """
        Retrieves all text objects in the scene. They will be listed with
        all children objects AFTER (higher index in the list than) their parent objects.
        """
        text_objects = []
        for obj in objects:
            font_container = obj[self.C4D_FONT_INDEX]
            font = font_container.GetFont()
            if font:
                text_objects.append(obj)
            # all objects, including text itself, can have nested text objects that also need to be cached
            children = obj.GetChildren()
            if children:
                text_objects += self._get_all_text_objects(children)

        return text_objects

    def _cache_text_if_needed(self, frame_time: c4d.BaseTime) -> bool:
        """
        On cross-platform submissions, Cinema 4D sometimes handles fonts incorrectly.

        To work around this, the user can select the `Use cached text during render` option in the submitter
        This will convert the text to polygons for each frame, rather than procedurally generating text.

        This option is most often used on Linux, which doesn't support procedural font rendering.
        However, it is also relevant to cross-platform submissions from Mac -> Windows.

        If text caching is needed, this function will cache the text. Otherwise, it is a no-op.

        Returns True if text has been cached. Returns False otherwise.
        """
        if (
            USE_CACHED_TEXT_KEY not in self.render_kwargs
            or not self.render_kwargs[USE_CACHED_TEXT_KEY]
        ):
            print(
                "If you see incorrect fonts or missing text, try the 'Use cached text during render' option "
                "under 'Job-specific settings' in the submitter."
            )
            return False

        found_font = self._has_cached_text(self.doc.GetObjects())

        if not found_font:
            print("No fonts were found in the scene, no need to cache text.")
            return False

        print("Fonts were found in the scene")

        print("Setting the correct frame/time to determine text location.")
        c4d.documents.SetDocumentTime(self.doc, frame_time)

        print(f"Animating the text for frame {self.render_kwargs[FRAME_KEY]}.")
        self.doc.ExecutePasses(
            bt=None, animation=True, expressions=True, caches=True, flags=c4d.BUILDFLAGS_NONE
        )
        print("The location of the text was recalculated. Refreshing the text object list.")

        # we do this a second time in case objects are recalculated and have different references
        text_objects = self._get_all_text_objects(self.doc.GetObjects())

        if not text_objects:
            print("No text objects were found in the scene after animation.")
            return False

        print(f"Text objects found in scene after animation: {text_objects}")

        # The _get_all_text_objects() function returns all text objects with the parent objects first, then children
        # objects. However, in the modeling command below, we actually need to list the children objects before the
        # parent objects so that each object reference remains valid when modified in order.
        #
        # For example, if there is parent text and child text, and the parent text is made editable (converted to
        # polygons) first, then the child reference will no longer be valid. This breaks the child reference and causes
        # a segmentation fault.
        # However, if we convert the child text to polygons first, the parent text will still be valid and can be converted
        # to polygons as well.
        text_objects.reverse()

        print("Converting all parameterized text objects to polygons for correct rendering.")
        c4d.utils.SendModelingCommand(
            command=c4d.MCOMMAND_MAKEEDITABLE,  # convert the cached parameterized text to polygons
            list=text_objects,
            mode=c4d.MODELINGCOMMANDMODE_ALL,  # apply to all points/polygons
            doc=self.doc,
            flags=c4d.MODELINGCOMMANDFLAGS_CREATEUNDO,  # apply to the current document
        )
        print("Successfully converted all text objects to polygons.")

        return True

    def _reload_document(self) -> None:
        c4d.documents.KillDocument(c4d.documents.GetActiveDocument())
        for action in [SCENE_FILE_KEY, TAKE_KEY, OUTPUT_PATH_KEY, MULTIPASS_PATH_KEY]:
            if action in self.render_kwargs:
                self.action_dict[action]({action: self.render_kwargs[action]})
