"""Claude Code hooks for Crux — shipped as part of crux-sdk.

Entry points:
    crux-hook-init  → crux.hooks.session_start:main
    crux-hook-pre   → crux.hooks.pre_tool:main
    crux-hook-post  → crux.hooks.post_tool:main
"""
