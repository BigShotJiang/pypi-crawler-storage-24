# SPDX-License-Identifier: MIT
"""Shared context dependency injected into tools."""

from __future__ import annotations

from dataclasses import dataclass, field
from logging import Logger
from typing import Any

from fenix_mcp.infrastructure.config import Settings
from fenix_mcp.infrastructure.fenix_api.client import FenixApiClient


@dataclass(slots=True)
class AppContext:
    """Runtime dependencies shared by tools."""

    settings: Settings
    logger: Logger
    api_client: FenixApiClient
    active_team_id: str | None = None  # default/fallback only
    active_team_name: str | None = None  # display only
    user_teams: list[dict[str, Any]] = field(
        default_factory=list
    )  # for team resolution fallback
