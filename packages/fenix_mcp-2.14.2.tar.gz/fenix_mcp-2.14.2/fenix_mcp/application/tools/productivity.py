# SPDX-License-Identifier: MIT
"""Productivity tool implementation (TODO operations)."""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import Field

from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import (
    MERMAID_HINT,
    CategoryStr,
    DateTimeStr,
    MarkdownStr,
    TagStr,
    TitleStr,
    Tool,
    ToolRequest,
    UUIDStr,
    resolve_team_id,
)
from fenix_mcp.domain.productivity import ProductivityService
from fenix_mcp.infrastructure.context import AppContext

TodoAction = Literal[
    "todo_create",
    "todo_list",
    "todo_get",
    "todo_update",
    "todo_delete",
    "todo_stats",
    "todo_search",
    "todo_overdue",
    "todo_upcoming",
    "todo_categories",
    "todo_tags",
    "todo_help",
]

_TODO_ACTION_DESCRIPTIONS: Dict[str, str] = {
    "todo_create": "Creates a new TODO.",
    "todo_list": (
        "Lists TODOs. By default returns only pending and in_progress. "
        "To filter by status, use status parameter with values: pending (backlog), in_progress, completed, cancelled."
    ),
    "todo_get": "Gets TODO details and content by ID.",
    "todo_update": "Updates fields of an existing TODO.",
    "todo_delete": "Removes a TODO by ID.",
    "todo_stats": "Returns aggregated TODO statistics.",
    "todo_search": "Searches TODOs by text term.",
    "todo_overdue": "Lists overdue TODOs.",
    "todo_upcoming": "Lists TODOs with upcoming due dates.",
    "todo_categories": "Lists registered categories.",
    "todo_tags": "Lists registered tags.",
    "todo_help": "Shows supported actions and their uses.",
}


def _todo_action_choices() -> List[str]:
    return list(_TODO_ACTION_DESCRIPTIONS.keys())


def _todo_action_formatted_help() -> str:
    lines = [
        "| **Action** | **Description** |",
        "| --- | --- |",
    ]
    for value, desc in _TODO_ACTION_DESCRIPTIONS.items():
        lines.append(f"| `{value}` | {desc} |")
    return "\n".join(lines)


ACTION_FIELD_DESCRIPTION = (
    "Productivity action (TODO). Choose one of the values: "
    + ", ".join(
        f"`{value}` ({desc.rstrip('.')})."
        for value, desc in _TODO_ACTION_DESCRIPTIONS.items()
    )
)


class ProductivityRequest(ToolRequest):
    action: TodoAction = Field(description=ACTION_FIELD_DESCRIPTION)
    id: Optional[UUIDStr] = Field(default=None, description="TODO item ID (UUID).")
    title: Optional[TitleStr] = Field(
        default=None, description="TODO title (required for create)."
    )
    content: Optional[MarkdownStr] = Field(
        default=None,
        description=f"Markdown content (required for create).{MERMAID_HINT}",
    )
    status: Optional[str] = Field(
        default=None,
        description="TODO status. Values: pending (shown as 'backlog' in UI), in_progress, completed, cancelled.",
    )
    priority: Optional[str] = Field(
        default=None, description="TODO priority (low, medium, high, urgent)."
    )
    category: Optional[CategoryStr] = Field(
        default=None, description="Optional category."
    )
    tags: Optional[List[TagStr]] = Field(default=None, description="Tag list.")
    due_date: Optional[DateTimeStr] = Field(
        default=None, description="TODO due date (ISO 8601)."
    )
    limit: int = Field(
        default=20, ge=1, le=100, description="Result limit for list/search."
    )
    offset: int = Field(default=0, ge=0, description="Pagination offset.")
    query: Optional[str] = Field(default=None, description="Search term.")
    days: Optional[int] = Field(
        default=None, ge=1, le=30, description="Day window for upcoming."
    )
    team_id: Optional[UUIDStr] = Field(
        default=None, description="Associated team ID (UUID)."
    )


class ProductivityTool(Tool):
    name = "productivity"
    description = "Fenix Cloud productivity operations (TODOs)."
    request_model = ProductivityRequest

    def __init__(self, context: AppContext):
        self._context = context
        self._service = ProductivityService(context.api_client, context.logger)

    async def run(self, payload: ProductivityRequest, context: AppContext):
        action = payload.action
        team_id = resolve_team_id(requested_team_id=payload.team_id, context=context)
        if action == "todo_help":
            return await self._handle_help()
        if action == "todo_create":
            return await self._handle_create(payload, team_id)
        if action == "todo_list":
            return await self._handle_list(payload, team_id)
        if action == "todo_get":
            return await self._handle_get(payload, team_id)
        if action == "todo_update":
            return await self._handle_update(payload, team_id)
        if action == "todo_delete":
            return await self._handle_delete(payload, team_id)
        if action == "todo_stats":
            return await self._handle_stats(team_id)
        if action == "todo_search":
            return await self._handle_search(payload, team_id)
        if action == "todo_overdue":
            return await self._handle_overdue(team_id)
        if action == "todo_upcoming":
            return await self._handle_upcoming(payload, team_id)
        if action == "todo_categories":
            return await self._handle_categories(team_id)
        if action == "todo_tags":
            return await self._handle_tags(team_id)

    async def _handle_create(self, payload: ProductivityRequest, team_id: str):
        if not payload.title or not payload.content or not payload.due_date:
            return text("❌ Provide title, content and due_date to create a TODO.")
        todo = await self._service.create_todo(
            title=payload.title,
            content=payload.content,
            status=payload.status or "pending",
            priority=payload.priority or "medium",
            category=payload.category,
            tags=payload.tags or [],
            due_date=payload.due_date,
            team_id=team_id,
        )
        return text(self._format_single(todo, header="✅ TODO created successfully!"))

    async def _handle_list(self, payload: ProductivityRequest, team_id: str):
        # If no status filter provided, fetch pending and in_progress only
        if payload.status:
            todos = await self._service.list_todos(
                limit=payload.limit,
                offset=payload.offset,
                status=payload.status,
                priority=payload.priority,
                category=payload.category,
                team_id=team_id,
            )
        else:
            # Fetch pending and in_progress separately and merge
            pending = await self._service.list_todos(
                limit=payload.limit,
                offset=payload.offset,
                status="pending",
                priority=payload.priority,
                category=payload.category,
                team_id=team_id,
            )
            in_progress = await self._service.list_todos(
                limit=payload.limit,
                offset=payload.offset,
                status="in_progress",
                priority=payload.priority,
                category=payload.category,
                team_id=team_id,
            )
            todos = pending + in_progress
        if not todos:
            return text("📋 No TODOs found.")
        body = "\n\n".join(ProductivityService.format_todo(todo) for todo in todos)
        return text(f"📋 **TODOs ({len(todos)}):**\n\n{body}")

    async def _handle_get(self, payload: ProductivityRequest, team_id: str):
        if not payload.id:
            return text("❌ Provide the ID to get a TODO.")
        todo = await self._service.get_todo(payload.id, team_id=team_id)
        return text(
            self._format_single(todo, header="📋 TODO found", show_content=True)
        )

    async def _handle_update(self, payload: ProductivityRequest, team_id: str):
        if not payload.id:
            return text("❌ Provide the ID to update a TODO.")
        fields = {
            "title": payload.title,
            "content": payload.content,
            "status": payload.status,
            "priority": payload.priority,
            "category": payload.category,
            "tags": payload.tags,
            "due_date": payload.due_date,
        }
        todo = await self._service.update_todo(payload.id, team_id=team_id, **fields)
        return text(self._format_single(todo, header="✅ TODO updated"))

    async def _handle_delete(self, payload: ProductivityRequest, team_id: str):
        if not payload.id:
            return text("❌ Provide the ID to delete a TODO.")
        await self._service.delete_todo(payload.id, team_id=team_id)
        return text(f"🗑️ TODO {payload.id} removed successfully.")

    async def _handle_stats(self, team_id: str):
        stats = await self._service.stats(team_id=team_id)
        lines = ["📊 **TODO Statistics**"]
        for key, value in (stats or {}).items():
            lines.append(f"- {key}: {value}")
        return text("\n".join(lines))

    async def _handle_search(self, payload: ProductivityRequest, team_id: str):
        if not payload.query:
            return text("❌ Provide a search term (query).")
        todos = await self._service.search(
            payload.query, limit=payload.limit, offset=payload.offset, team_id=team_id
        )
        if not todos:
            return text("🔍 No TODOs found for the search.")
        body = "\n\n".join(ProductivityService.format_todo(todo) for todo in todos)
        return text(f"🔍 **Search results ({len(todos)}):**\n\n{body}")

    async def _handle_overdue(self, team_id: str):
        todos = await self._service.overdue(team_id=team_id)
        if not todos:
            return text("✅ No overdue TODOs at the moment.")
        body = "\n\n".join(ProductivityService.format_todo(todo) for todo in todos)
        return text(f"⏰ **Overdue TODOs ({len(todos)}):**\n\n{body}")

    async def _handle_upcoming(self, payload: ProductivityRequest, team_id: str):
        todos = await self._service.upcoming(days=payload.days, team_id=team_id)
        if not todos:
            return text("📅 No TODOs scheduled for the specified period.")
        body = "\n\n".join(ProductivityService.format_todo(todo) for todo in todos)
        header = f"📅 Scheduled TODOs ({len(todos)}):"
        if payload.days:
            header += f" next {payload.days} days"
        return text(f"{header}\n\n{body}")

    async def _handle_categories(self, team_id: str):
        categories = await self._service.categories(team_id=team_id)
        if not categories:
            return text("🌿 No categories registered yet.")
        body = "\n".join(f"- {category}" for category in categories)
        return text(f"🌿 **Categories in use:**\n{body}")

    async def _handle_tags(self, team_id: str):
        tags = await self._service.tags(team_id=team_id)
        if not tags:
            return text("🔖 No tags registered yet.")
        body = "\n".join(f"- {tag}" for tag in tags)
        return text(f"🔖 **Tags in use:**\n{body}")

    async def _handle_help(self):
        return text(
            "📚 **Available actions for productivity**\n\n"
            + _todo_action_formatted_help()
        )

    @staticmethod
    def _format_single(
        todo: Dict[str, Any], *, header: str, show_content: bool = False
    ) -> str:
        return "\n".join(
            [
                header,
                "",
                ProductivityService.format_todo(todo, show_content=show_content),
            ]
        )
