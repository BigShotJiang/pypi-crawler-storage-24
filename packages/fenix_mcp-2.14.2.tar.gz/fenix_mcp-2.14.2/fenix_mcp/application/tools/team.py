# SPDX-License-Identifier: MIT

from __future__ import annotations

import json
from typing import Literal, cast

from pydantic import ConfigDict, Field

from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import Tool, ToolRequest
from fenix_mcp.domain.team import match_team_by_name
from fenix_mcp.infrastructure.context import AppContext

MY_TEAMS_URI = "fenix://my-teams"

TeamAction = Literal["team_help", "team_switch", "team_list", "team_current"]


class TeamRequest(ToolRequest):
    model_config = ConfigDict(extra="forbid")
    action: TeamAction = "team_help"
    team_query: str | None = Field(
        default=None,
        description=(
            "Team name, prefix, or ID to switch to. "
            "Supports partial matching (e.g., 'Dev' for 'Development'). "
            "REQUIRED for team_switch."
        ),
    )


def build_my_teams_resource(context: AppContext) -> dict[str, str]:
    return {
        "uri": MY_TEAMS_URI,
        "mimeType": "application/json",
        "text": json.dumps({"teams": context.user_teams}, ensure_ascii=False, indent=2),
    }


def _format_team_list_with_active(context: AppContext) -> str:
    lines: list[str] = []
    for t in context.user_teams:
        name = str(t.get("name") or "?")
        tid = str(t.get("id") or "?")
        prefix = str(t.get("prefix") or "")
        prefix_str = f" [{prefix}]" if prefix else ""
        is_active = tid == context.active_team_id
        marker = " <- active" if is_active else ""
        icon = ">" if is_active else "-"
        lines.append(f"  {icon} {name}{prefix_str}: {tid}{marker}")
    return "\n".join(lines)


class TeamTool(Tool):
    def __init__(self, context: AppContext):
        self.name = "team"
        self.description = (
            "Manage team context. Actions: "
            "`team_switch` (switch active team by name/prefix/ID), "
            "`team_list` (list available teams), "
            "`team_current` (show active team), "
            "`team_help` (usage info)."
        )
        self.request_model = TeamRequest
        self._context = context

    @staticmethod
    def build_my_teams_resource(context: AppContext) -> dict[str, str]:
        return build_my_teams_resource(context)

    async def run(self, payload: ToolRequest, context: AppContext):
        payload = cast(TeamRequest, payload)

        if payload.action == "team_switch":
            return self._handle_switch(payload, context)

        if payload.action == "team_list":
            return self._handle_list(context)

        if payload.action == "team_current":
            return self._handle_current(context)

        if payload.action == "team_help":
            return text(
                "**Team Management**\n\n"
                "- `team_switch`: Switch active team by name, prefix, or ID. "
                + 'Example: `{"action": "team_switch", '
                + '"team_query": "Development"}`\n'
                "- `team_list`: List all available teams "
                "and show which is active.\n"
                "- `team_current`: Show the currently active team.\n"
                "- `team_help`: Show this help message.\n\n"
                "You can also read the `fenix://my-teams` resource "
                "for raw team data."
            )

        return text("Unsupported team action.")

    def _handle_switch(
        self, payload: TeamRequest, context: AppContext
    ) -> dict[str, object]:
        if not payload.team_query:
            return text(
                "Missing `team_query`. Provide the team name, prefix, "
                "or ID.\n"
                f"Available teams:\n{_format_team_list_with_active(context)}"
            )

        try:
            team = match_team_by_name(payload.team_query, context.user_teams)
        except ValueError as e:
            return text(str(e))

        team_id = str(team.get("id") or "")
        team_name = str(team.get("name") or "Unknown")
        context.active_team_id = team_id
        context.active_team_name = team_name
        context.api_client.set_active_team(team_id)

        prefix = str(team.get("prefix") or "")
        prefix_str = f" [{prefix}]" if prefix else ""

        return text(
            f"Switched to **{team_name}**{prefix_str}.\n\n"
            f"All subsequent tool calls will use this team. "
            f"You can override per-call with `team_id` parameter."
        )

    def _handle_list(self, context: AppContext) -> dict[str, object]:
        if not context.user_teams:
            return text("No teams available. Call `initialize` first.")

        header = f"**Your teams** ({len(context.user_teams)}):\n\n"
        team_list = _format_team_list_with_active(context)

        tip = (
            "\n\nUse `team_switch` with a team name to change " + "the active team."
            if not context.active_team_id
            else ""
        )

        return text(f"{header}{team_list}{tip}")

    def _handle_current(self, context: AppContext) -> dict[str, object]:
        if context.active_team_id:
            prefix = ""
            for t in context.user_teams:
                if t.get("id") == context.active_team_id:
                    p = str(t.get("prefix") or "")
                    if p:
                        prefix = f" [{p}]"
                    break
            return text(
                f"Active team: **{context.active_team_name}**{prefix} "
                f"(`{context.active_team_id}`)"
            )

        return text(
            "No active team set.\n\n"
            f"Available teams:\n"
            f"{_format_team_list_with_active(context)}\n\n"
            "Use `team_switch` to set one."
        )


__all__ = [
    "MY_TEAMS_URI",
    "TeamTool",
    "TeamAction",
    "TeamRequest",
    "build_my_teams_resource",
]
