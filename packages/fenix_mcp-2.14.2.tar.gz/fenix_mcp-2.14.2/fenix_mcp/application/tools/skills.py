# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import List, Literal, Optional, cast

from pydantic import ConfigDict, Field

from fenix_mcp.application.formatters.skill import (
    _format_marketplace_skill,
    _format_skill,
)
from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import (
    DescriptionStr,
    MERMAID_HINT,
    MarkdownStr,
    TitleStr,
    Tool,
    ToolRequest,
    UUIDStr,
    resolve_team_id,
    sanitize_null,
)
from fenix_mcp.domain.skills import SkillService
from fenix_mcp.infrastructure.context import AppContext

SkillsAction = Literal[
    "skill_create",
    "skill_list",
    "skill_get",
    "skill_update",
    "skill_delete",
    "skill_marketplace",
    "skill_fork",
    "skill_export",
    "skill_import_github",
    "skill_install",
    "skill_export_merged",
]


def _skill_action_choices() -> list[str]:
    return [
        "skill_create",
        "skill_list",
        "skill_get",
        "skill_update",
        "skill_delete",
        "skill_marketplace",
        "skill_fork",
        "skill_export",
        "skill_import_github",
        "skill_install",
        "skill_export_merged",
    ]


class SkillsRequest(ToolRequest):
    model_config = ConfigDict(extra="forbid")

    action: SkillsAction
    team_id: Optional[UUIDStr] = Field(
        default=None, description="Associated team ID (UUID)."
    )

    id: Optional[UUIDStr] = Field(
        default=None, description="Primary resource ID (UUID)."
    )
    limit: int = Field(default=20, ge=1, le=100, description="Result limit.")
    offset: int = Field(
        default=0, ge=0, description="Pagination offset (when supported)."
    )
    query: Optional[str] = Field(default=None, description="Filter/search term.")

    skill_id: Optional[UUIDStr] = Field(default=None, description="Skill ID (UUID).")
    skill_scope: Optional[str] = Field(
        default=None,
        description="Skill scope. Values: personal, team, organization, marketplace.",
    )
    skill_name: Optional[TitleStr] = Field(default=None, description="Skill name.")
    skill_slug: Optional[str] = Field(
        default=None, description="Skill slug (auto-generated if not provided)."
    )
    skill_description: Optional[DescriptionStr] = Field(
        default=None, description="Skill description."
    )
    skill_content: Optional[MarkdownStr] = Field(
        default=None, description=f"Skill content (Markdown).{MERMAID_HINT}"
    )
    skill_team_id: Optional[UUIDStr] = Field(
        default=None, description="Team ID for team-scoped skills (UUID)."
    )
    skill_export_format: Optional[str] = Field(
        default=None,
        description="Export format. Values: cursor, claude, copilot, windsurf.",
    )
    skill_is_active: Optional[bool] = Field(
        default=None, description="Whether the skill is active."
    )
    skill_category: Optional[str] = Field(
        default=None,
        description="Skill category. REQUIRED for skill_create. Values: frontend, backend, mobile, fullstack, devops, infrastructure, architecture, code_review, testing, security, documentation, performance, other.",
    )

    skill_ids: Optional[List[UUIDStr]] = Field(
        default=None,
        description="List of skill IDs for merged export.",
    )
    repo_url: Optional[str] = Field(
        default=None,
        description="GitHub repository URL for import (e.g.: https://github.com/owner/repo).",
    )


class SkillsTool(Tool):
    name = "skills"
    description = """Manage Fenix skills including CRUD, marketplace, import, install, and export workflows.

Available actions:
- `skill_create`, `skill_list`, `skill_get`, `skill_update`, `skill_delete`
- `skill_marketplace`, `skill_fork`, `skill_install`
- `skill_export`, `skill_export_merged`, `skill_import_github`

Common example:
- List team skills:
  `{"action":"skill_list"}`

Team scoping:
- Optional `team_id` can be sent in any request.
- If omitted, the tool uses the active/default team resolution from context.
"""
    request_model = SkillsRequest

    def __init__(self, context: AppContext):
        self._context = context
        self._service = SkillService(context.api_client, context.logger)

    async def run(self, payload: ToolRequest, context: AppContext):
        payload = cast(SkillsRequest, payload)
        team_id = resolve_team_id(requested_team_id=payload.team_id, context=context)
        action = payload.action

        if action == "skill_create":
            if not payload.skill_name:
                return text("❌ Provide skill_name to create the skill.")
            if not payload.skill_content:
                return text("❌ Provide skill_content to create the skill.")
            if not payload.skill_scope:
                return text(
                    "❌ Provide skill_scope to create the skill. "
                    "Values: personal, team, organization, marketplace."
                )
            if payload.skill_scope == "team" and not payload.skill_team_id:
                return text("❌ Provide skill_team_id for team-scoped skills.")
            if not payload.skill_category:
                return text(
                    "❌ Provide skill_category to create the skill. "
                    "Values: frontend, backend, mobile, fullstack, devops, infrastructure, "
                    "architecture, code_review, testing, security, documentation, performance, other."
                )

            skill = await self._service.skill_create(
                {
                    "scope": payload.skill_scope,
                    "name": payload.skill_name,
                    "slug": sanitize_null(payload.skill_slug),
                    "description": sanitize_null(payload.skill_description),
                    "content": payload.skill_content,
                    "team_id": sanitize_null(payload.skill_team_id),
                    "category": payload.skill_category,
                },
                team_id=team_id,
            )
            return text(_format_skill(skill, header="✅ Skill created"))

        if action == "skill_list":
            skills = await self._service.skill_list(
                team_id=team_id,
                limit=payload.limit,
                offset=payload.offset,
                scope=sanitize_null(payload.skill_scope),
                query=sanitize_null(payload.query),
            )
            if not skills:
                return text("🧠 No skills found.")
            body = "\n\n".join(_format_skill(skill) for skill in skills)
            return text(f"🧠 **Skills ({len(skills)}):**\n\n{body}")

        if action == "skill_get":
            skill_id = payload.skill_id or payload.id
            if not skill_id:
                return text("❌ Provide skill_id or id to get the skill.")
            skill = await self._service.skill_get(skill_id, team_id=team_id)
            return text(
                _format_skill(skill, header="🧠 Skill details", show_content=True)
            )

        if action == "skill_update":
            skill_id = payload.skill_id or payload.id
            if not skill_id:
                return text("❌ Provide skill_id or id to update the skill.")
            skill = await self._service.skill_update(
                skill_id,
                {
                    "name": sanitize_null(payload.skill_name),
                    "description": sanitize_null(payload.skill_description),
                    "content": sanitize_null(payload.skill_content),
                    "is_active": payload.skill_is_active,
                    "category": sanitize_null(payload.skill_category),
                },
                team_id=team_id,
            )
            return text(_format_skill(skill, header="✅ Skill updated"))

        if action == "skill_delete":
            skill_id = payload.skill_id or payload.id
            if not skill_id:
                return text("❌ Provide skill_id or id to delete the skill.")
            await self._service.skill_delete(skill_id, team_id=team_id)
            return text(f"🗑️ Skill {skill_id} removed.")

        if action == "skill_marketplace":
            skills = await self._service.skill_marketplace(
                team_id=team_id,
                limit=payload.limit,
                offset=payload.offset,
                query=sanitize_null(payload.query),
            )
            if not skills:
                return text("🏪 No marketplace skills found.")
            body = "\n\n".join(_format_marketplace_skill(skill) for skill in skills)
            return text(f"🏪 **Marketplace Skills ({len(skills)}):**\n\n{body}")

        if action == "skill_fork":
            skill_id = payload.skill_id or payload.id
            if not skill_id:
                return text("❌ Provide skill_id or id to fork the skill.")
            if not payload.skill_scope:
                return text(
                    "❌ Provide skill_scope for the forked skill. "
                    "Values: personal, team, organization."
                )
            skill = await self._service.skill_fork(
                skill_id,
                {
                    "scope": payload.skill_scope,
                    "name": sanitize_null(payload.skill_name),
                    "team_id": sanitize_null(payload.skill_team_id),
                    "category": sanitize_null(payload.skill_category),
                },
                team_id=team_id,
            )
            return text(_format_skill(skill, header="✅ Skill forked"))

        if action == "skill_export":
            skill_id = payload.skill_id or payload.id
            if not skill_id:
                return text("❌ Provide skill_id or id to export the skill.")
            if not payload.skill_export_format:
                return text(
                    "❌ Provide skill_export_format. "
                    "Values: cursor, claude, copilot, windsurf."
                )
            content = await self._service.skill_export(
                skill_id,
                payload.skill_export_format,
                team_id=team_id,
            )
            return text(
                f"📤 **Export ({payload.skill_export_format}):**\n\n```\n{content}\n```"
            )

        if action == "skill_import_github":
            if not payload.repo_url:
                return text("❌ Provide repo_url to import a skill from GitHub.")
            skill = await self._service.skill_import_github(
                payload.repo_url,
                team_id=team_id,
            )
            return text(_format_skill(skill, header="✅ Skill imported from GitHub"))

        if action == "skill_install":
            skill_id = payload.skill_id or payload.id
            if not skill_id:
                return text("❌ Provide skill_id or id to install the skill.")
            skill = await self._service.skill_install(skill_id, team_id=team_id)
            return text(_format_skill(skill, header="✅ Skill installed"))

        if action == "skill_export_merged":
            if not payload.skill_export_format:
                return text(
                    "❌ Provide skill_export_format. "
                    "Values: cursor, claude, copilot, windsurf."
                )
            skill_ids = payload.skill_ids or []
            if not skill_ids:
                return text("❌ Provide skill_ids to export merged skills.")
            content = await self._service.skill_export_merged(
                payload.skill_export_format,
                skill_ids,
                team_id=team_id,
            )
            return text(
                f"📤 **Merged export ({payload.skill_export_format}):**\n\n```\n{content}\n```"
            )

        return text(
            "❌ Unsupported skill action.\n\nChoose one of the values:\n"
            + "\n".join(f"- `{value}`" for value in _skill_action_choices())
        )


__all__ = ["SkillsTool", "SkillsAction", "SkillsRequest"]
