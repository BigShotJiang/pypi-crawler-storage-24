"""Tests for action builder helpers."""

from airena_sdk import (
    move,
    attack_move,
    attack_unit,
    deploy,
    stop,
    harvest,
    queue_production,
    place_building,
)


def test_move():
    result = move(1, 10, 20)
    assert result == {"action": "move", "unit_id": 1, "x": 10, "y": 20}


def test_attack_move():
    result = attack_move(2, 30, 40)
    assert result == {"action": "attack_move", "unit_id": 2, "x": 30, "y": 40}


def test_attack_unit():
    result = attack_unit(1, 99)
    assert result == {"action": "attack_unit", "unit_id": 1, "target_id": 99}


def test_deploy():
    result = deploy(5)
    assert result == {"action": "deploy", "unit_id": 5}


def test_stop():
    result = stop(7)
    assert result == {"action": "stop", "unit_id": 7}


def test_harvest():
    result = harvest(3, 50, 60)
    assert result == {"action": "harvest", "unit_id": 3, "x": 50, "y": 60}


def test_queue_production():
    result = queue_production("e1")
    assert result == {"action": "queue_production", "type_id": "e1"}


def test_place_building():
    result = place_building("powr", 100, 200)
    assert result == {"action": "place_building", "type_id": "powr", "x": 100, "y": 200}


def test_all_return_dicts():
    """Every builder must return a plain dict."""
    results = [
        move(1, 0, 0),
        attack_move(1, 0, 0),
        attack_unit(1, 2),
        deploy(1),
        stop(1),
        harvest(1, 0, 0),
        queue_production("x"),
        place_building("x", 0, 0),
    ]
    for r in results:
        assert isinstance(r, dict)
        assert "action" in r
