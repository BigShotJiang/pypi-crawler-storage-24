"""Action builder helpers for the openra.v1 protocol.

Each function returns a dict ready to be appended to the actions list.
"""


def move(unit_id: int, x: int, y: int) -> dict:
    """Move a unit to a position."""
    return {"action": "move", "unit_id": unit_id, "x": x, "y": y}


def attack_move(unit_id: int, x: int, y: int) -> dict:
    """Attack-move a unit toward a position."""
    return {"action": "attack_move", "unit_id": unit_id, "x": x, "y": y}


def attack_unit(unit_id: int, target_id: int) -> dict:
    """Order a unit to attack a specific target."""
    return {"action": "attack_unit", "unit_id": unit_id, "target_id": target_id}


def deploy(unit_id: int) -> dict:
    """Deploy a unit (e.g., MCV -> Construction Yard)."""
    return {"action": "deploy", "unit_id": unit_id}


def stop(unit_id: int) -> dict:
    """Stop a unit."""
    return {"action": "stop", "unit_id": unit_id}


def harvest(unit_id: int, x: int, y: int) -> dict:
    """Order a harvester to harvest at a position."""
    return {"action": "harvest", "unit_id": unit_id, "x": x, "y": y}


def queue_production(type_id: str) -> dict:
    """Queue production of a unit or building type."""
    return {"action": "queue_production", "type_id": type_id}


def place_building(type_id: str, x: int, y: int) -> dict:
    """Place a building at a position."""
    return {"action": "place_building", "type_id": type_id, "x": x, "y": y}
