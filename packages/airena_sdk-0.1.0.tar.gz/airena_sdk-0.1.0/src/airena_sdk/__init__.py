"""AiRENA SDK — thin protocol layer for openra.v1 bots.

Handles JSONL I/O, message dispatch, action serialization, and lifecycle.
Uses only the Python standard library.
"""

from importlib.metadata import version as _pkg_version

__version__ = _pkg_version("airena-sdk")

from airena_sdk.protocol import PROTOCOL, log, send, send_error
from airena_sdk.runner import BotRunner
from airena_sdk.actions import (
    move,
    attack_move,
    attack_unit,
    deploy,
    stop,
    harvest,
    queue_production,
    place_building,
)

__all__ = [
    "__version__",
    "PROTOCOL",
    "log",
    "send",
    "send_error",
    "BotRunner",
    "move",
    "attack_move",
    "attack_unit",
    "deploy",
    "stop",
    "harvest",
    "queue_production",
    "place_building",
]
