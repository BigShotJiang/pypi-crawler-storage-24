# airena-sdk

Thin Python SDK for AiRENA bots implementing the `openra.v1` protocol.

Handles protocol plumbing so bot authors can focus on strategy:
- JSONL I/O over stdin/stdout
- Message dispatch via `BotRunner`
- Action builder helpers

Uses only the Python standard library. No external dependencies.

## Install

```bash
pip install airena-sdk
```

## Usage

```python
from airena_sdk import BotRunner, log, send

bot = BotRunner()

@bot.on("tick")
def handle_tick(msg, state):
    tick = msg["tick"]
    log(f"Tick {tick}")
    send({"type": "actions", "tick": tick, "actions": []})

@bot.on("game_over")
def handle_game_over(msg, state):
    log(f"Game over: {msg.get('result')}")

bot.run()
```

## API

- `BotRunner` — main loop, handler registration via `@bot.on("msg_type")` or `bot.register()`
- `log(msg)` — log to stderr
- `send(obj)` — send JSON to stdout
- `send_error(msg)` — send error message
- `PROTOCOL` — protocol version string (`"openra.v1"`)
- `__version__` — package version string
- Action builders: `move()`, `attack_move()`, `attack_unit()`, `deploy()`, `stop()`, `harvest()`, `queue_production()`, `place_building()`

## Requirements

Python 3.10+, stdlib only.

## Development

```bash
# Clone and install in development mode
git clone https://github.com/tyminski/airena-sdk-python.git
cd airena-sdk-python
pip install -e ".[test]"

# Run tests
pytest -v

# Build distribution
pip install build
python -m build
```

## Release process

1. Update `version` in `pyproject.toml`.
2. Commit: `git commit -m "release: v0.X.0"`
3. Tag: `git tag v0.X.0`
4. Push: `git push origin main --tags`
5. Create a GitHub Release from the tag.
6. The `publish.yml` workflow builds and publishes to PyPI via Trusted Publishing.

### First-time PyPI setup

Before the first release, a maintainer must configure Trusted Publishing on PyPI:

1. Go to https://pypi.org and log in (or create an account).
2. Go to **Your projects** → **Publishing** → **Add a new pending publisher**.
3. Fill in:
   - **PyPI project name**: `airena-sdk`
   - **Owner**: `tyminski`
   - **Repository**: `airena-sdk-python`
   - **Workflow name**: `publish.yml`
   - **Environment name**: `pypi`
4. Submit. This registers the trust relationship.
5. In the GitHub repo, go to **Settings** → **Environments** → create an environment named `pypi`.

After this one-time setup, every GitHub Release triggers automatic publishing.

## License

MIT
