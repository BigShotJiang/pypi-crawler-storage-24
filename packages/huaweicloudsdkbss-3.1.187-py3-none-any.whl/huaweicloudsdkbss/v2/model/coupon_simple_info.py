# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CouponSimpleInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'coupon_id': 'str'
    }

    attribute_map = {
        'id': 'id',
        'coupon_id': 'coupon_id'
    }

    def __init__(self, id=None, coupon_id=None):
        r"""CouponSimpleInfo

        The model defined in huaweicloud sdk

        :param id: 批量发放优惠券成功的客户ID。
        :type id: str
        :param coupon_id: 发放成功的券ID。
        :type coupon_id: str
        """
        
        

        self._id = None
        self._coupon_id = None
        self.discriminator = None

        self.id = id
        self.coupon_id = coupon_id

    @property
    def id(self):
        r"""Gets the id of this CouponSimpleInfo.

        批量发放优惠券成功的客户ID。

        :return: The id of this CouponSimpleInfo.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this CouponSimpleInfo.

        批量发放优惠券成功的客户ID。

        :param id: The id of this CouponSimpleInfo.
        :type id: str
        """
        self._id = id

    @property
    def coupon_id(self):
        r"""Gets the coupon_id of this CouponSimpleInfo.

        发放成功的券ID。

        :return: The coupon_id of this CouponSimpleInfo.
        :rtype: str
        """
        return self._coupon_id

    @coupon_id.setter
    def coupon_id(self, coupon_id):
        r"""Sets the coupon_id of this CouponSimpleInfo.

        发放成功的券ID。

        :param coupon_id: The coupon_id of this CouponSimpleInfo.
        :type coupon_id: str
        """
        self._coupon_id = coupon_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CouponSimpleInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
