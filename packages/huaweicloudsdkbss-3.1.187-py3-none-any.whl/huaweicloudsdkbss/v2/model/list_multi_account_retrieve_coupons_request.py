# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListMultiAccountRetrieveCouponsRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'sub_customer_id': 'str',
        'offset': 'int',
        'limit': 'int'
    }

    attribute_map = {
        'sub_customer_id': 'sub_customer_id',
        'offset': 'offset',
        'limit': 'limit'
    }

    def __init__(self, sub_customer_id=None, offset=None, limit=None):
        r"""ListMultiAccountRetrieveCouponsRequest

        The model defined in huaweicloud sdk

        :param sub_customer_id: 企业子账户的账号ID。
        :type sub_customer_id: str
        :param offset: 偏移量，默认值为0。此参数不携带或携带值为空或携带值为null时，取默认值0；不支持携带值为空串。
        :type offset: int
        :param limit: 每次查询条数，默认值为10。此参数不携带或携带值为空或携带值为null时，取默认值0；不支持携带值为空串。
        :type limit: int
        """
        
        

        self._sub_customer_id = None
        self._offset = None
        self._limit = None
        self.discriminator = None

        self.sub_customer_id = sub_customer_id
        if offset is not None:
            self.offset = offset
        if limit is not None:
            self.limit = limit

    @property
    def sub_customer_id(self):
        r"""Gets the sub_customer_id of this ListMultiAccountRetrieveCouponsRequest.

        企业子账户的账号ID。

        :return: The sub_customer_id of this ListMultiAccountRetrieveCouponsRequest.
        :rtype: str
        """
        return self._sub_customer_id

    @sub_customer_id.setter
    def sub_customer_id(self, sub_customer_id):
        r"""Sets the sub_customer_id of this ListMultiAccountRetrieveCouponsRequest.

        企业子账户的账号ID。

        :param sub_customer_id: The sub_customer_id of this ListMultiAccountRetrieveCouponsRequest.
        :type sub_customer_id: str
        """
        self._sub_customer_id = sub_customer_id

    @property
    def offset(self):
        r"""Gets the offset of this ListMultiAccountRetrieveCouponsRequest.

        偏移量，默认值为0。此参数不携带或携带值为空或携带值为null时，取默认值0；不支持携带值为空串。

        :return: The offset of this ListMultiAccountRetrieveCouponsRequest.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this ListMultiAccountRetrieveCouponsRequest.

        偏移量，默认值为0。此参数不携带或携带值为空或携带值为null时，取默认值0；不支持携带值为空串。

        :param offset: The offset of this ListMultiAccountRetrieveCouponsRequest.
        :type offset: int
        """
        self._offset = offset

    @property
    def limit(self):
        r"""Gets the limit of this ListMultiAccountRetrieveCouponsRequest.

        每次查询条数，默认值为10。此参数不携带或携带值为空或携带值为null时，取默认值0；不支持携带值为空串。

        :return: The limit of this ListMultiAccountRetrieveCouponsRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListMultiAccountRetrieveCouponsRequest.

        每次查询条数，默认值为10。此参数不携带或携带值为空或携带值为null时，取默认值0；不支持携带值为空串。

        :param limit: The limit of this ListMultiAccountRetrieveCouponsRequest.
        :type limit: int
        """
        self._limit = limit

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListMultiAccountRetrieveCouponsRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
