# pypi-vzhukh

Minimal demo Python package pypi-vzhukh.