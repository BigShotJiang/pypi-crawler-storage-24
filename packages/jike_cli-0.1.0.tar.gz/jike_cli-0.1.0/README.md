# jike-cli

A CLI tool for [Jike (即刻)](https://www.okjike.com) social network.

## Install

```bash
# via uv
uv tool install jike-cli

# via pipx
pipx install jike-cli

# via pip
pip install jike-cli
```

## Usage

### Login

```bash
jike login    # Scan QR code with Jike app
jike logout   # Clear saved tokens
```

### Browse

```bash
jike feed              # View following feed
jike feed -n 10        # Limit to 10 posts
jike search "AI"       # Search posts
jike notifications     # View notifications
```

### Post

```bash
jike post "Hello from CLI!"    # Create a post
jike delete-post POST_ID       # Delete a post
```

### Comments

```bash
jike comment POST_ID "Nice!"       # Add comment
jike delete-comment COMMENT_ID     # Delete comment
```

### Users

```bash
jike profile USERNAME          # View profile
jike followers USER_ID         # List followers
jike following USER_ID         # List following
```

### JSON Output

All read commands support `--json` for machine-readable output:

```bash
jike feed --json | jq '.[] | .content'
```

Non-TTY output (pipes) automatically uses JSON format.

## Development

```bash
git clone https://github.com/case/jike-cli
cd jike-cli
pip install -e .
```

## License

MIT
