"""Rich terminal rendering — tables, panels, formatted output."""

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from jike_cli.models import Comment, Notification, Post, User

console = Console()


def _fmt_count(n: int) -> str:
    if n >= 10000:
        return f"{n / 10000:.1f}w"
    if n >= 1000:
        return f"{n / 1000:.1f}k"
    return str(n)


def _truncate(s: str, max_len: int = 80) -> str:
    if len(s) <= max_len:
        return s
    return s[: max_len - 1] + "…"


def render_post(post: Post) -> None:
    name = post.user.screen_name if post.user else "Unknown"
    username = f"@{post.user.username}" if post.user else ""

    header = Text()
    header.append(name, style="bold cyan")
    header.append(f" {username}", style="dim")
    header.append(f"  {post.created_at[:10]}", style="dim")

    content = post.content or "(no content)"
    if post.link_title:
        content += f"\n🔗 {post.link_title}"

    stats = (
        f"❤ {_fmt_count(post.like_count)}  "
        f"💬 {_fmt_count(post.comment_count)}  "
        f"🔄 {_fmt_count(post.share_count)}"
    )

    panel = Panel(
        f"{content}\n\n[dim]{stats}[/dim]",
        title=header,
        subtitle=f"[dim]{post.id}[/dim]",
        border_style="blue",
        padding=(0, 1),
    )
    console.print(panel)


def render_posts(posts: list[Post]) -> None:
    if not posts:
        console.print("[dim]No posts found.[/dim]")
        return
    for post in posts:
        render_post(post)


def render_user(user: User) -> None:
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(style="bold")
    table.add_column()

    table.add_row("Name", user.screen_name)
    table.add_row("Username", f"@{user.username}")
    table.add_row("ID", user.id)
    if user.bio:
        table.add_row("Bio", user.bio)
    if user.gender:
        table.add_row("Gender", user.gender)
    table.add_row("Followers", _fmt_count(user.followers_count))
    table.add_row("Following", _fmt_count(user.following_count))

    panel = Panel(table, title="[bold cyan]Profile[/bold cyan]", border_style="blue")
    console.print(panel)


def render_user_list(users: list[User], title: str = "Users") -> None:
    if not users:
        console.print("[dim]No users found.[/dim]")
        return

    table = Table(title=title)
    table.add_column("Name", style="cyan")
    table.add_column("Username", style="dim")
    table.add_column("Bio")

    for u in users:
        table.add_row(u.screen_name, f"@{u.username}", _truncate(u.bio, 50))

    console.print(table)


def render_notifications(notifications: list[Notification]) -> None:
    if not notifications:
        console.print("[dim]No notifications.[/dim]")
        return

    table = Table(title="Notifications")
    table.add_column("Type", style="yellow")
    table.add_column("From", style="cyan")
    table.add_column("Content")
    table.add_column("Time", style="dim")

    for n in notifications:
        name = n.user.screen_name if n.user else ""
        table.add_row(n.type, name, _truncate(n.content, 60), n.created_at[:10])

    console.print(table)


def render_comment(comment: Comment) -> None:
    name = comment.user.screen_name if comment.user else "Unknown"
    console.print(
        f"[bold cyan]{name}[/bold cyan] [dim]{comment.created_at[:10]}[/dim]"
    )
    console.print(f"  {comment.content}")
    console.print(f"  [dim]❤ {_fmt_count(comment.like_count)}  ID: {comment.id}[/dim]")
    console.print()
