"""Allow running as `python -m jike_cli`."""

from jike_cli.cli import cli

cli()
