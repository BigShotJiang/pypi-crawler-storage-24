"""Output utilities — JSON mode, TTY detection."""

import json
import sys


def is_tty() -> bool:
    return sys.stdout.isatty()


def print_json(data: object) -> None:
    if isinstance(data, list):
        output = [item.to_dict() if hasattr(item, "to_dict") else item for item in data]
    elif hasattr(data, "to_dict"):
        output = data.to_dict()
    else:
        output = data
    print(json.dumps(output, ensure_ascii=False, indent=2))
