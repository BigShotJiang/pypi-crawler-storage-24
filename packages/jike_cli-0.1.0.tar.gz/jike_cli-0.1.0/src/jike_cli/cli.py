"""Click command group — all jike CLI commands."""

import sys

import click
import requests

from jike_cli import __version__
from jike_cli._jike import JikeClient, TokenPair, authenticate
from jike_cli.auth import clear_tokens, load_tokens, save_tokens
from jike_cli.formatter import (
    console,
    render_comment,
    render_notifications,
    render_posts,
    render_user,
    render_user_list,
)
from jike_cli.models import (
    Comment,
    Post,
    User,
    parse_feed,
    parse_notifications,
    parse_search,
    parse_user_list,
)
from jike_cli.output import is_tty, print_json


def _get_client() -> JikeClient:
    tokens = load_tokens()
    if not tokens:
        console.print("[red]Not logged in. Run `jike login` first.[/red]", file=sys.stderr)
        raise SystemExit(1)
    return JikeClient(tokens)


def _save_refreshed_tokens(client: JikeClient) -> None:
    """Persist tokens if they were refreshed during the request."""
    save_tokens(client.tokens)


def _use_json(json_flag: bool) -> bool:
    return json_flag or not is_tty()


@click.group()
@click.version_option(__version__, prog_name="jike")
def cli() -> None:
    """Jike (即刻) social network CLI."""


@cli.command()
def login() -> None:
    """Login via QR code scan."""
    console.print("[bold]Scan the QR code with Jike app...[/bold]")
    try:
        tokens = authenticate()
        save_tokens(tokens)
        console.print("[green]Login successful![/green]")
    except requests.HTTPError as e:
        console.print(f"[red]Login failed: {e}[/red]", file=sys.stderr)
        raise SystemExit(1)


@cli.command()
def logout() -> None:
    """Clear saved tokens."""
    clear_tokens()
    console.print("Logged out.")


@cli.command()
@click.option("-n", "--limit", default=20, help="Number of posts to fetch.")
@click.option("--json", "json_flag", is_flag=True, help="Output as JSON.")
def feed(limit: int, json_flag: bool) -> None:
    """View your following feed."""
    client = _get_client()
    try:
        data = client.feed(limit=limit)
        _save_refreshed_tokens(client)
        posts = parse_feed(data)
        if _use_json(json_flag):
            print_json(posts)
        else:
            render_posts(posts)
    except requests.HTTPError as e:
        console.print(f"[red]Error: {e}[/red]", file=sys.stderr)
        raise SystemExit(1)


@cli.command()
@click.argument("content")
@click.option("--json", "json_flag", is_flag=True, help="Output as JSON.")
def post(content: str, json_flag: bool) -> None:
    """Create a new post."""
    client = _get_client()
    try:
        data = client.create_post(content)
        _save_refreshed_tokens(client)
        if _use_json(json_flag):
            print_json(data)
        else:
            console.print("[green]Post created![/green]")
            p = Post.from_api(data.get("data", data))
            if p.id:
                console.print(f"[dim]ID: {p.id}[/dim]")
    except requests.HTTPError as e:
        console.print(f"[red]Error: {e}[/red]", file=sys.stderr)
        raise SystemExit(1)


@cli.command("delete-post")
@click.argument("post_id")
def delete_post(post_id: str) -> None:
    """Delete a post by ID."""
    client = _get_client()
    try:
        client.delete_post(post_id)
        _save_refreshed_tokens(client)
        console.print("[green]Post deleted.[/green]")
    except requests.HTTPError as e:
        console.print(f"[red]Error: {e}[/red]", file=sys.stderr)
        raise SystemExit(1)


@cli.command()
@click.argument("post_id")
@click.argument("content")
@click.option("--json", "json_flag", is_flag=True, help="Output as JSON.")
def comment(post_id: str, content: str, json_flag: bool) -> None:
    """Add a comment to a post."""
    client = _get_client()
    try:
        data = client.add_comment(post_id, content)
        _save_refreshed_tokens(client)
        if _use_json(json_flag):
            print_json(data)
        else:
            console.print("[green]Comment added![/green]")
            c = Comment.from_api(data.get("data", data))
            if c.id:
                console.print(f"[dim]ID: {c.id}[/dim]")
    except requests.HTTPError as e:
        console.print(f"[red]Error: {e}[/red]", file=sys.stderr)
        raise SystemExit(1)


@cli.command("delete-comment")
@click.argument("comment_id")
def delete_comment(comment_id: str) -> None:
    """Delete a comment by ID."""
    client = _get_client()
    try:
        client.delete_comment(comment_id)
        _save_refreshed_tokens(client)
        console.print("[green]Comment deleted.[/green]")
    except requests.HTTPError as e:
        console.print(f"[red]Error: {e}[/red]", file=sys.stderr)
        raise SystemExit(1)


@cli.command()
@click.argument("keyword")
@click.option("-n", "--limit", default=20, help="Number of results.")
@click.option("--json", "json_flag", is_flag=True, help="Output as JSON.")
def search(keyword: str, limit: int, json_flag: bool) -> None:
    """Search for posts."""
    client = _get_client()
    try:
        data = client.search(keyword, limit=limit)
        _save_refreshed_tokens(client)
        posts = parse_search(data)
        if _use_json(json_flag):
            print_json(posts)
        else:
            render_posts(posts)
    except requests.HTTPError as e:
        console.print(f"[red]Error: {e}[/red]", file=sys.stderr)
        raise SystemExit(1)


@cli.command()
@click.argument("username")
@click.option("--json", "json_flag", is_flag=True, help="Output as JSON.")
def profile(username: str, json_flag: bool) -> None:
    """View a user's profile."""
    client = _get_client()
    try:
        data = client.profile(username)
        _save_refreshed_tokens(client)
        user = User.from_api(data.get("user", data))
        if _use_json(json_flag):
            print_json(user)
        else:
            render_user(user)
    except requests.HTTPError as e:
        console.print(f"[red]Error: {e}[/red]", file=sys.stderr)
        raise SystemExit(1)


@cli.command()
@click.argument("user_id")
@click.option("--json", "json_flag", is_flag=True, help="Output as JSON.")
def followers(user_id: str, json_flag: bool) -> None:
    """List a user's followers."""
    client = _get_client()
    try:
        data = client.followers(user_id)
        _save_refreshed_tokens(client)
        users = parse_user_list(data)
        if _use_json(json_flag):
            print_json(users)
        else:
            render_user_list(users, title="Followers")
    except requests.HTTPError as e:
        console.print(f"[red]Error: {e}[/red]", file=sys.stderr)
        raise SystemExit(1)


@cli.command()
@click.argument("user_id")
@click.option("--json", "json_flag", is_flag=True, help="Output as JSON.")
def following(user_id: str, json_flag: bool) -> None:
    """List users someone is following."""
    client = _get_client()
    try:
        data = client.following(user_id)
        _save_refreshed_tokens(client)
        users = parse_user_list(data)
        if _use_json(json_flag):
            print_json(users)
        else:
            render_user_list(users, title="Following")
    except requests.HTTPError as e:
        console.print(f"[red]Error: {e}[/red]", file=sys.stderr)
        raise SystemExit(1)


@cli.command()
@click.option("--unread-only", is_flag=True, help="Show only unread count.")
@click.option("--json", "json_flag", is_flag=True, help="Output as JSON.")
def notifications(unread_only: bool, json_flag: bool) -> None:
    """View notifications."""
    client = _get_client()
    try:
        if unread_only:
            data = client.unread_notifications()
            _save_refreshed_tokens(client)
            if _use_json(json_flag):
                print_json(data)
            else:
                console.print(f"Unread notifications: [bold]{data}[/bold]")
        else:
            data = client.list_notifications()
            _save_refreshed_tokens(client)
            notifs = parse_notifications(data)
            if _use_json(json_flag):
                print_json(notifs)
            else:
                render_notifications(notifs)
    except requests.HTTPError as e:
        console.print(f"[red]Error: {e}[/red]", file=sys.stderr)
        raise SystemExit(1)
