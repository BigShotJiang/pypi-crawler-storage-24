"""Data models and API response parsers."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class User:
    id: str
    username: str
    screen_name: str
    avatar_url: str = ""
    bio: str = ""
    gender: str = ""
    is_following: bool = False
    is_banned: bool = False
    followers_count: int = 0
    following_count: int = 0
    highlights_count: int = 0

    @classmethod
    def from_api(cls, data: dict) -> "User":
        return cls(
            id=data.get("id", ""),
            username=data.get("username", ""),
            screen_name=data.get("screenName", ""),
            avatar_url=data.get("avatarImage", {}).get("picUrl", "") if isinstance(data.get("avatarImage"), dict) else "",
            bio=data.get("bio", ""),
            gender=data.get("gender", ""),
            is_following=data.get("following", False),
            is_banned=data.get("isBanned", False),
            followers_count=data.get("statsCount", {}).get("followedCount", 0) if isinstance(data.get("statsCount"), dict) else 0,
            following_count=data.get("statsCount", {}).get("followingCount", 0) if isinstance(data.get("statsCount"), dict) else 0,
            highlights_count=data.get("statsCount", {}).get("highlightedPersonalUpdates", 0) if isinstance(data.get("statsCount"), dict) else 0,
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "username": self.username,
            "screen_name": self.screen_name,
            "bio": self.bio,
            "followers_count": self.followers_count,
            "following_count": self.following_count,
        }


@dataclass
class Post:
    id: str
    type: str
    content: str
    user: Optional[User] = None
    created_at: str = ""
    like_count: int = 0
    comment_count: int = 0
    share_count: int = 0
    pictures: list[str] = field(default_factory=list)
    link_url: str = ""
    link_title: str = ""

    @classmethod
    def from_api(cls, data: dict) -> "Post":
        user_data = data.get("user")
        pictures = []
        for pic in data.get("pictureKeys", []):
            if isinstance(pic, str):
                pictures.append(pic)
        for pic in data.get("pictures", []):
            if isinstance(pic, dict) and pic.get("picUrl"):
                pictures.append(pic["picUrl"])

        link_info = data.get("linkInfo") or {}

        return cls(
            id=data.get("id", ""),
            type=data.get("type", "ORIGINAL_POST"),
            content=data.get("content", ""),
            user=User.from_api(user_data) if user_data else None,
            created_at=data.get("createdAt", ""),
            like_count=data.get("likeCount", 0),
            comment_count=data.get("commentCount", 0),
            share_count=data.get("shareCount", 0),
            pictures=pictures,
            link_url=link_info.get("linkUrl", ""),
            link_title=link_info.get("title", ""),
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type,
            "content": self.content,
            "user": self.user.to_dict() if self.user else None,
            "created_at": self.created_at,
            "like_count": self.like_count,
            "comment_count": self.comment_count,
            "share_count": self.share_count,
            "pictures": self.pictures,
            "link_url": self.link_url,
            "link_title": self.link_title,
        }


@dataclass
class Comment:
    id: str
    content: str
    user: Optional[User] = None
    created_at: str = ""
    like_count: int = 0

    @classmethod
    def from_api(cls, data: dict) -> "Comment":
        user_data = data.get("user")
        return cls(
            id=data.get("id", ""),
            content=data.get("content", ""),
            user=User.from_api(user_data) if user_data else None,
            created_at=data.get("createdAt", ""),
            like_count=data.get("likeCount", 0),
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "content": self.content,
            "user": self.user.to_dict() if self.user else None,
            "created_at": self.created_at,
            "like_count": self.like_count,
        }


@dataclass
class Notification:
    id: str
    type: str
    content: str
    user: Optional[User] = None
    created_at: str = ""
    referral_type: str = ""

    @classmethod
    def from_api(cls, data: dict) -> "Notification":
        user_data = data.get("actionItem", {}).get("users", [None])[0] if data.get("actionItem", {}).get("users") else None
        action = data.get("actionItem", {})
        return cls(
            id=data.get("id", ""),
            type=data.get("type", ""),
            content=action.get("content", "") or data.get("content", ""),
            user=User.from_api(user_data) if user_data else None,
            created_at=data.get("createdAt", ""),
            referral_type=data.get("referralType", ""),
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type,
            "content": self.content,
            "user": self.user.to_dict() if self.user else None,
            "created_at": self.created_at,
        }


def parse_feed(data: dict) -> list[Post]:
    posts = []
    for item in data.get("data", []):
        target = item
        if item.get("type") == "REPOST" and item.get("target"):
            target = item["target"]
        posts.append(Post.from_api(target))
    return posts


def parse_search(data: dict) -> list[Post]:
    posts = []
    for item in data.get("data", []):
        if item.get("type") in ("ORIGINAL_POST", "REPOST"):
            posts.append(Post.from_api(item))
        elif item.get("target"):
            posts.append(Post.from_api(item["target"]))
    return posts


def parse_notifications(data: dict) -> list[Notification]:
    return [Notification.from_api(n) for n in data.get("data", [])]


def parse_user_list(data: dict) -> list[User]:
    return [User.from_api(u) for u in data.get("data", [])]
