"""Jike QR Authentication — scan-to-login flow."""

import json
import sys
import time
import urllib.parse
from typing import Optional

import requests

from .types import API_BASE, DEFAULT_HEADERS, TokenPair

POLL_INTERVAL_SEC = 1
POLL_TIMEOUT_SEC = 180


def _post(path: str, headers: Optional[dict] = None, **kwargs) -> requests.Response:
    merged = {**DEFAULT_HEADERS, "Content-Type": "application/json"}
    if headers:
        merged.update(headers)
    return requests.post(f"{API_BASE}{path}", headers=merged, **kwargs)


def _get(path: str) -> requests.Response:
    return requests.get(f"{API_BASE}{path}", headers={**DEFAULT_HEADERS})


def create_session() -> str:
    resp = _post("/sessions.create")
    resp.raise_for_status()
    return resp.json()["uuid"]


def build_qr_payload(uuid: str) -> str:
    scan_url = f"https://www.okjike.com/account/scan?uuid={uuid}"
    return (
        "jike://page.jk/web?url="
        + urllib.parse.quote(scan_url, safe="")
        + "&displayHeader=false&displayFooter=false"
    )


def render_qr(data: str) -> bool:
    try:
        import qrcode

        qr = qrcode.QRCode(border=1)
        qr.add_data(data)
        qr.make(fit=True)
        qr.print_ascii(out=sys.stderr)
        return True
    except ImportError:
        return False


def _extract_tokens(resp: requests.Response) -> Optional[TokenPair]:
    body: dict = {}
    try:
        body = resp.json()
    except (ValueError, KeyError):
        pass

    access = (
        body.get("x-jike-access-token")
        or body.get("access_token")
        or resp.headers.get("x-jike-access-token")
    )
    refresh = (
        body.get("x-jike-refresh-token")
        or body.get("refresh_token")
        or resp.headers.get("x-jike-refresh-token")
    )

    if access and refresh:
        return TokenPair(access_token=access, refresh_token=refresh)
    return None


def poll_confirmation(uuid: str) -> Optional[TokenPair]:
    attempts = POLL_TIMEOUT_SEC // POLL_INTERVAL_SEC

    for _ in range(attempts):
        try:
            resp = _get(f"/sessions.wait_for_confirmation?uuid={uuid}")
        except requests.RequestException:
            time.sleep(POLL_INTERVAL_SEC)
            continue

        if resp.status_code == 200:
            return _extract_tokens(resp)

        if resp.status_code == 400:
            time.sleep(POLL_INTERVAL_SEC)
            continue

        time.sleep(POLL_INTERVAL_SEC)

    return None


def refresh_tokens(token_pair: TokenPair) -> TokenPair:
    resp = _post(
        "/app_auth_tokens.refresh",
        headers={"x-jike-refresh-token": token_pair.refresh_token},
        json={},
    )
    resp.raise_for_status()

    return TokenPair(
        access_token=resp.headers.get(
            "x-jike-access-token", token_pair.access_token
        ),
        refresh_token=resp.headers.get(
            "x-jike-refresh-token", token_pair.refresh_token
        ),
    )


def authenticate() -> TokenPair:
    uuid = create_session()

    qr_payload = build_qr_payload(uuid)
    if not render_qr(qr_payload):
        print("Install 'qrcode' for terminal QR code.", file=sys.stderr)
        print(f"Or open: {qr_payload}", file=sys.stderr)

    tokens = poll_confirmation(uuid)
    if not tokens:
        print("Timeout — no scan detected.", file=sys.stderr)
        sys.exit(1)

    tokens = refresh_tokens(tokens)
    return tokens
