"""Jike API Client — feed, posts, comments, search, profiles, notifications."""

from typing import Optional

import requests

from .types import API_BASE, DEFAULT_HEADERS, TokenPair


class JikeClient:
    """Jike API client with automatic token refresh on 401."""

    def __init__(self, tokens: TokenPair):
        self._tokens = tokens

    @property
    def tokens(self) -> TokenPair:
        return self._tokens

    def _headers(self) -> dict:
        return {
            **DEFAULT_HEADERS,
            "Content-Type": "application/json",
            "x-jike-access-token": self._tokens.access_token,
        }

    def _request(
        self, method: str, path: str, retry_on_401: bool = True, **kwargs
    ) -> dict:
        resp = requests.request(
            method, f"{API_BASE}{path}", headers=self._headers(), **kwargs
        )

        if resp.status_code == 401 and retry_on_401:
            self._refresh()
            return self._request(method, path, retry_on_401=False, **kwargs)

        resp.raise_for_status()
        return resp.json() if resp.content else {}

    def _refresh(self) -> None:
        resp = requests.post(
            f"{API_BASE}/app_auth_tokens.refresh",
            headers={
                **DEFAULT_HEADERS,
                "Content-Type": "application/json",
                "x-jike-refresh-token": self._tokens.refresh_token,
            },
            json={},
        )
        resp.raise_for_status()
        self._tokens = TokenPair(
            access_token=resp.headers.get(
                "x-jike-access-token", self._tokens.access_token
            ),
            refresh_token=resp.headers.get(
                "x-jike-refresh-token", self._tokens.refresh_token
            ),
        )

    def feed(self, limit: int = 20, load_more_key: Optional[str] = None) -> dict:
        body: dict[str, object] = {"limit": limit}
        if load_more_key:
            body["loadMoreKey"] = load_more_key
        return self._request(
            "POST", "/1.0/personalUpdate/followingUpdates", json=body
        )

    def get_post(self, post_id: str) -> dict:
        return self._request("GET", f"/1.0/originalPosts/get?id={post_id}")

    def create_post(self, content: str, picture_keys: Optional[list] = None) -> dict:
        return self._request(
            "POST",
            "/1.0/originalPosts/create",
            json={"content": content, "pictureKeys": picture_keys or []},
        )

    def delete_post(self, post_id: str) -> dict:
        return self._request(
            "POST", "/1.0/originalPosts/remove", json={"id": post_id}
        )

    def add_comment(self, post_id: str, content: str) -> dict:
        return self._request(
            "POST",
            "/1.0/comments/add",
            json={
                "targetType": "ORIGINAL_POST",
                "targetId": post_id,
                "content": content,
                "syncToPersonalUpdates": False,
                "pictureKeys": [],
                "force": False,
            },
        )

    def delete_comment(self, comment_id: str) -> dict:
        return self._request(
            "POST",
            "/1.0/comments/remove",
            json={"id": comment_id, "targetType": "ORIGINAL_POST"},
        )

    def search(
        self, keyword: str, limit: int = 20, load_more_key: Optional[str] = None
    ) -> dict:
        body: dict[str, object] = {"keyword": keyword, "limit": limit}
        if load_more_key:
            body["loadMoreKey"] = load_more_key
        return self._request("POST", "/1.0/search/integrate", json=body)

    def profile(self, username: str) -> dict:
        return self._request("GET", f"/1.0/users/profile?username={username}")

    def followers(self, user_id: str, load_more_key: Optional[str] = None) -> dict:
        body: dict[str, object] = {"userId": user_id}
        if load_more_key:
            body["loadMoreKey"] = load_more_key
        return self._request(
            "POST", "/1.0/userRelation/getFollowerList", json=body
        )

    def following(self, user_id: str, load_more_key: Optional[str] = None) -> dict:
        body: dict[str, object] = {"userId": user_id}
        if load_more_key:
            body["loadMoreKey"] = load_more_key
        return self._request(
            "POST", "/1.0/userRelation/getFollowingList", json=body
        )

    def unread_notifications(self) -> dict:
        return self._request("GET", "/1.0/notifications/unread")

    def list_notifications(self, load_more_key: Optional[str] = None) -> dict:
        body: dict[str, object] = {}
        if load_more_key:
            body["loadMoreKey"] = load_more_key
        return self._request("POST", "/1.0/notifications/list", json=body)
