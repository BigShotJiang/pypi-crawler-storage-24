"""Token persistence — save/load/clear tokens to ~/.config/jike-cli/tokens.json."""

import json
import os
from pathlib import Path
from typing import Optional

from jike_cli._jike import TokenPair

CONFIG_DIR = Path(os.environ.get("JIKE_CLI_CONFIG_DIR", Path.home() / ".config" / "jike-cli"))
TOKEN_FILE = CONFIG_DIR / "tokens.json"


def save_tokens(tokens: TokenPair) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(json.dumps(tokens.to_dict(), indent=2))
    TOKEN_FILE.chmod(0o600)


def load_tokens() -> Optional[TokenPair]:
    if not TOKEN_FILE.exists():
        return None
    try:
        data = json.loads(TOKEN_FILE.read_text())
        return TokenPair(
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
        )
    except (json.JSONDecodeError, KeyError):
        return None


def clear_tokens() -> None:
    if TOKEN_FILE.exists():
        TOKEN_FILE.unlink()
