"""jike-cli — Jike (即刻) social network CLI."""

__version__ = "0.1.0"
