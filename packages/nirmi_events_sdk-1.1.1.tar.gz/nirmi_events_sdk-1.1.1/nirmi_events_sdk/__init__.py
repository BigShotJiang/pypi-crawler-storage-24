"""
Nirmi Events SDK

A Python SDK for the Nirmi AI concierge — real-time events, places, weather,
and hotel-aware recommendations. No API keys needed on the partner side.
"""

__version__ = "1.1.1"

from .client import Client
from .models import LocationData, GuestContext, HotelVenue, HotelConfig

__all__ = [
    "Client",
    "LocationData",
    "GuestContext",
    "HotelVenue",
    "HotelConfig",
]
