"""
Nirmi Events SDK — Client

Calls the Nirmi backend API (which holds all API keys).
Hotel partners need only the backend URL — no third-party keys required.
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
import requests

from .models import LocationData, GuestContext, HotelConfig

logger = logging.getLogger(__name__)

_FALLBACK_ERROR = {
    "message": "Sorry, I'm having trouble connecting to the Nirmi service.",
    "recommendations": [],
    "events": [],
    "weather": None,
    "context_used": {}
}


class Client:
    """Nirmi Events SDK client.

    Connects to the Nirmi backend API — no API keys needed on the partner side.

    Quick start::

        from nirmi_events_sdk import Client, HotelConfig, HotelVenue, GuestContext

        client = Client(
            api_key="nk_hyatt_demo_2026",
            hotel_config=HotelConfig(
                hotel_name="Hyatt Regency Barcelona",
                brand="hyatt",
                venues=[
                    HotelVenue(name="Aire Restaurant", type="restaurant", cuisine="mediterranean", price_tier="€€€"),
                    HotelVenue(name="Mosaic Bar", type="bar", description="Rooftop cocktails"),
                ]
            )
        )

        result = client.chat(
            message="Where should I eat tonight?",
            latitude=41.3851,
            longitude=2.1734,
            city="Barcelona",
            guest=GuestContext(first_name="Marco", nationality="Italian", trip_type="couple")
        )
        print(result["message"])
        print(result["recommendations"])
    """

    def __init__(
        self,
        api_key: str,
        api_base_url: str = "https://www.nirmi.ai",
        timeout: int = 30,
        hotel_config: Optional[HotelConfig] = None
    ):
        """
        Args:
            api_key: Your Nirmi API key (required). Get one at https://nirmi.ai
            api_base_url: Root URL of the Nirmi backend (default: https://www.nirmi.ai).
            timeout: Request timeout in seconds (default 30).
            hotel_config: Hotel configuration with venues, brand, and competitor rules.
        """
        if not api_key:
            raise ValueError("api_key is required. Get your API key at https://nirmi.ai")
        self.api_base_url = api_base_url.rstrip('/')
        self.api_key = api_key
        self.timeout = timeout
        self.hotel_config = hotel_config

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    # ─── Events ──────────────────────────────────────────────────────────────

    def get_events(
        self,
        latitude: float,
        longitude: float,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        radius_km: int = 50,
        city: Optional[str] = None,
        hotel_name: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Fetch upcoming events from Eventbrite + Ticketmaster.

        Args:
            latitude: Latitude of the hotel / guest location.
            longitude: Longitude of the hotel / guest location.
            start_time: Filter events starting after this time.
            end_time: Filter events starting before this time.
            radius_km: Search radius in kilometres (default 50).
            city: City name — speeds up Eventbrite lookup.
            hotel_name: Hotel name for logging / context.

        Returns:
            List of event dicts.
        """
        payload: Dict[str, Any] = {
            "location": {
                "latitude": latitude,
                "longitude": longitude,
                "city": city,
                "hotel_name": hotel_name or (self.hotel_config.hotel_name if self.hotel_config else None)
            },
            "radius_km": radius_km
        }
        if start_time:
            payload["start_time"] = start_time.isoformat()
        if end_time:
            payload["end_time"] = end_time.isoformat()

        try:
            resp = requests.post(
                f"{self.api_base_url}/events",
                json=payload,
                headers=self._headers(),
                timeout=self.timeout
            )
            if resp.status_code == 200:
                data = resp.json()
                return data.get("e", [])
            logger.error("get_events HTTP %s: %s", resp.status_code, resp.text[:200])
            return []
        except Exception as exc:
            logger.error("get_events error: %s", exc)
            return []

    # ─── Places ──────────────────────────────────────────────────────────────

    def get_places(
        self,
        latitude: float,
        longitude: float,
        place_type: str = "tourist_attraction",
        radius: int = 2000,
        keyword: Optional[str] = None,
        city: Optional[str] = None,
        hotel_name: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Fetch nearby places from Google Places API via the Nirmi backend.

        Args:
            latitude: Latitude of the hotel / guest location.
            longitude: Longitude of the hotel / guest location.
            place_type: Google Places type, e.g. ``restaurant``, ``tourist_attraction``.
            radius: Search radius in metres (default 2000).
            keyword: Free-text keyword, e.g. ``"sushi"`` or ``"rooftop bar"``.
            city: City name (optional context).
            hotel_name: Hotel name (optional context).

        Returns:
            List of place dicts.
        """
        payload = {
            "location": {
                "latitude": latitude,
                "longitude": longitude,
                "city": city,
                "hotel_name": hotel_name or (self.hotel_config.hotel_name if self.hotel_config else None)
            },
            "place_type": place_type,
            "radius": radius,
            "keyword": keyword
        }
        try:
            resp = requests.post(
                f"{self.api_base_url}/places",
                json=payload,
                headers=self._headers(),
                timeout=self.timeout
            )
            if resp.status_code == 200:
                data = resp.json()
                return data.get("places", [])
            logger.error("get_places HTTP %s: %s", resp.status_code, resp.text[:200])
            return []
        except Exception as exc:
            logger.error("get_places error: %s", exc)
            return []

    # ─── Weather ─────────────────────────────────────────────────────────────

    def get_weather(
        self,
        latitude: float,
        longitude: float,
        city: Optional[str] = None,
        hotel_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """Fetch current weather for a location via the Nirmi backend.

        Args:
            latitude: Latitude.
            longitude: Longitude.
            city: City name (optional context).
            hotel_name: Hotel name (optional context).

        Returns:
            Dict with weather data.
        """
        payload = {
            "location": {
                "latitude": latitude,
                "longitude": longitude,
                "city": city,
                "hotel_name": hotel_name or (self.hotel_config.hotel_name if self.hotel_config else None)
            }
        }
        try:
            resp = requests.post(
                f"{self.api_base_url}/weather",
                json=payload,
                headers=self._headers(),
                timeout=self.timeout
            )
            if resp.status_code == 200:
                return resp.json()
            logger.error("get_weather HTTP %s: %s", resp.status_code, resp.text[:200])
        except Exception as exc:
            logger.error("get_weather error: %s", exc)
        return {"d": "unavailable", "t": None, "h": None, "w": None}

    # ─── Chat ────────────────────────────────────────────────────────────────

    def chat(
        self,
        message: str,
        latitude: float,
        longitude: float,
        city: Optional[str] = None,
        guest: Optional[GuestContext] = None,
        conversation_history: Optional[List[Dict[str, str]]] = None
    ) -> Dict[str, Any]:
        """Send a message to the Nirmi AI concierge.

        The AI has access to real-time events, nearby places, weather,
        and knows the hotel's own venues and the guest's profile.

        Args:
            message: The guest's question or request.
            latitude: Hotel / guest latitude.
            longitude: Hotel / guest longitude.
            city: City name for better event discovery.
            guest: Guest metadata from PMS / WiPass.
            conversation_history: List of ``{"user": ..., "assistant": ...}`` dicts.

        Returns:
            Dict with:
            - ``message`` (str): AI text answer.
            - ``recommendations`` (list): Structured venue/place recommendations.
            - ``events`` (list): Structured events.
            - ``weather`` (dict): Current weather data.
            - ``guest_greeting`` (str): Guest's first name if available.
        """
        payload: Dict[str, Any] = {
            "message": message,
            "location": {
                "latitude": latitude,
                "longitude": longitude,
                "city": city,
                "hotel_name": self.hotel_config.hotel_name if self.hotel_config else None
            },
            "conversation_history": conversation_history or []
        }

        if self.hotel_config:
            payload["hotel_config"] = self.hotel_config.model_dump()

        if guest:
            payload["guest"] = guest.model_dump(exclude_none=True)

        try:
            resp = requests.post(
                f"{self.api_base_url}/chat",
                json=payload,
                headers=self._headers(),
                timeout=self.timeout
            )
            if resp.status_code == 200:
                return resp.json()
            logger.error("chat HTTP %s: %s", resp.status_code, resp.text[:200])
            return {**_FALLBACK_ERROR, "message": f"API error {resp.status_code}"}
        except Exception as exc:
            logger.error("chat error: %s", exc)
            return _FALLBACK_ERROR
