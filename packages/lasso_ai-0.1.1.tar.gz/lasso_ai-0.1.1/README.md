# lasso-ai

Official Python SDK for the [Lasso API](https://productlasso.com/docs) — AI-powered product data extraction, enrichment, and web search.

Search for products across the web and get structured results. Enrich partial product records with complete data including pricing, specs, and descriptions — all backed by citations. Extract structured data from PDFs, spreadsheets, URLs, and raw text into clean, typed tables. Export as JSON, CSV, XLSX, or images.

**Features:**

- **Search** — Find products with natural language queries, get structured data back instantly
- **Enrich** — Pass partial product info, get complete records with citations and confidence scores
- **Extract** — Pull structured data from PDFs, CSVs, URLs, and free-form text
- **Enhance** — AI-generate descriptions, translations, and computed fields for any column
- **Export** — Download tables as JSON, CSV, XLSX, or image archives
- **Schemas** — Define and reuse column structures across tables
- **Glossary** — Manage translation terms and brand-specific vocabulary

## Installation

```bash
pip install lasso-ai
```

With pandas support:

```bash
pip install lasso-ai[pandas]
```

## Usage

```python
from lasso import LassoClient

lasso = LassoClient(api_key="lasso_...")
```

### Schemas

```python
schema = lasso.schemas.create(
    name="Products",
    columns=[
        {"key": "name", "label": "Product Name", "type": "text", "required": True},
        {"key": "price", "label": "Price", "type": "number"},
        {"key": "description", "label": "Description", "type": "richtext"},
    ],
)

schemas = lasso.schemas.list()
detail = lasso.schemas.get(schema["id"])
```

### Files

```python
file = lasso.files.upload("products.pdf")
files = lasso.files.list()
```

### Tables

```python
table = lasso.tables.create(
    schema_id=schema["id"],
    name="My Products",
    file_ids=[file["id"]],
)

# Poll until extraction completes
result = lasso.tables.wait_for_completion(table["id"])

rows = lasso.tables.rows(result["id"])
```

### Enhancement

```python
job = lasso.enhance.cells(
    table["id"],
    row_ids=["row-1", "row-2"],
    column_key="description",
    prompt="Write a product description based on {{Product Name}}",
)

status = lasso.enhance.status(table["id"])
```

### Export

```python
csv_data = lasso.export.csv(table["id"])
json_data = lasso.export.json(table["id"])

# Download xlsx to disk
lasso.export.xlsx(table["id"], path="products.xlsx")
```

### Pandas integration

```python
df = lasso.tables.results_as_dataframe(table["id"])
print(df.head())
```

### Glossary

```python
lasso.glossary.create(term="LCD", type="do_not_translate")
terms = lasso.glossary.list()
```

### Credits

```python
balance = lasso.credits.balance()
usage = lasso.credits.usage(from_="2026-01-01")
```

### Search

```python
results = lasso.search(
    query="wireless noise-cancelling headphones under $200",
    max_results=5,
)

for item in results["results"]:
    print(item["data"]["name"], item["source_url"])

# With a custom schema
results = lasso.search(
    query="ergonomic office chairs",
    columns=[
        {"key": "name", "label": "Name", "type": "text"},
        {"key": "price", "label": "Price", "type": "number"},
        {"key": "rating", "label": "Rating", "type": "number"},
    ],
)
```

### Enrich

```python
enriched = lasso.enrich(
    items=[
        {"data": {"name": "Sony WH-1000XM5"}},
        {"data": {"name": "Apple AirPods Pro 2"}},
    ],
    columns=[
        {"key": "name", "label": "Name", "type": "text"},
        {"key": "price", "label": "Price", "type": "number"},
        {"key": "description", "label": "Description", "type": "richtext"},
    ],
    web_search=True,
    thinking="medium",
)

for item in enriched["items"]:
    print(item["data"]["name"], item["data"]["price"])
    for field in item["basis"]:
        print(f"  {field['field']}: {field['confidence']}", field["citations"])
```

## Context manager

```python
with LassoClient(api_key="lasso_...") as lasso:
    schemas = lasso.schemas.list()
```

## Error handling

```python
from lasso import LassoClient, LassoError

try:
    lasso.schemas.get("non-existent")
except LassoError as e:
    print(e.status_code)   # 404
    print(e.error_type)    # "not_found"
    print(e.request_id)    # "req_..."
```

## License

MIT
