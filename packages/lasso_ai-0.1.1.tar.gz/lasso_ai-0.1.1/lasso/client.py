from __future__ import annotations

import time
from typing import Any, Optional

import httpx


class LassoError(Exception):
    def __init__(self, status_code: int, error_type: str, message: str, request_id: str):
        super().__init__(message)
        self.status_code = status_code
        self.error_type = error_type
        self.request_id = request_id


class _Resource:
    def __init__(self, client: "LassoClient"):
        self._client = client

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        return self._client._request(method, path, **kwargs)


class Schemas(_Resource):
    def list(self, *, page: int = 1, limit: int = 25) -> dict:
        params = {"page": page, "limit": limit}
        return self._request("GET", "/schemas", params=params)

    def create(self, *, name: str, columns: list[dict], description: str | None = None) -> dict:
        body: dict[str, Any] = {"name": name, "columns": columns}
        if description:
            body["description"] = description
        return self._request("POST", "/schemas", json=body)

    def get(self, schema_id: str) -> dict:
        return self._request("GET", f"/schemas/{schema_id}")

    def update(self, schema_id: str, **kwargs: Any) -> dict:
        return self._request("PUT", f"/schemas/{schema_id}", json=kwargs)

    def delete(self, schema_id: str) -> None:
        self._request("DELETE", f"/schemas/{schema_id}")

    def generate(self, *, sample_data: str, name: str | None = None) -> dict:
        body: dict[str, Any] = {"sample_data": sample_data}
        if name:
            body["name"] = name
        return self._request("POST", "/schemas/generate", json=body)


class Files(_Resource):
    def list(self, *, page: int = 1, limit: int = 25) -> dict:
        return self._request("GET", "/files", params={"page": page, "limit": limit})

    def upload(self, file_path: str) -> dict:
        with open(file_path, "rb") as f:
            return self._request("POST", "/files", files={"file": f})

    def delete(self, file_id: str) -> None:
        self._request("DELETE", f"/files/{file_id}")


class Tables(_Resource):
    def create(
        self,
        *,
        schema_id: str,
        name: str,
        file_ids: list[str] | None = None,
        file_urls: list[str] | None = None,
        source_text: str | None = None,
        additional_context: str | None = None,
        enhancement_context: str | None = None,
        webhook_url: str | None = None,
    ) -> dict:
        body: dict[str, Any] = {"schema_id": schema_id, "name": name}
        if file_ids:
            body["file_ids"] = file_ids
        if file_urls:
            body["file_urls"] = file_urls
        if source_text:
            body["source_text"] = source_text
        if additional_context:
            body["additional_context"] = additional_context
        if enhancement_context:
            body["enhancement_context"] = enhancement_context
        if webhook_url:
            body["webhook_url"] = webhook_url
        return self._request("POST", "/tables", json=body)

    def list(self, *, page: int = 1, limit: int = 25, search: str | None = None, status: str | None = None) -> dict:
        params: dict[str, Any] = {"page": page, "limit": limit}
        if search:
            params["search"] = search
        if status:
            params["status"] = status
        return self._request("GET", "/tables", params=params)

    def get(self, table_id: str) -> dict:
        return self._request("GET", f"/tables/{table_id}")

    def update(self, table_id: str, **kwargs: Any) -> dict:
        return self._request("PATCH", f"/tables/{table_id}", json=kwargs)

    def delete(self, table_id: str) -> None:
        self._request("DELETE", f"/tables/{table_id}")

    def columns(self, table_id: str) -> dict:
        return self._request("GET", f"/tables/{table_id}/columns")

    def rows(self, table_id: str, *, page: int = 1, limit: int = 25, sort_by: str | None = None, sort_order: str | None = None) -> dict:
        params: dict[str, Any] = {"page": page, "limit": limit}
        if sort_by:
            params["sort_by"] = sort_by
        if sort_order:
            params["sort_order"] = sort_order
        return self._request("GET", f"/tables/{table_id}/rows", params=params)

    def get_row(self, table_id: str, row_id: str) -> dict:
        return self._request("GET", f"/tables/{table_id}/rows/{row_id}")

    def update_row(self, table_id: str, row_id: str, data: dict) -> dict:
        return self._request("PUT", f"/tables/{table_id}/rows/{row_id}", json={"data": data})

    def delete_row(self, table_id: str, row_id: str) -> None:
        self._request("DELETE", f"/tables/{table_id}/rows/{row_id}")

    def bulk_update(self, table_id: str, *, row_ids: list[str], column_key: str, value: Any) -> dict:
        return self._request("POST", f"/tables/{table_id}/rows/bulk-update",
                             json={"row_ids": row_ids, "column_key": column_key, "value": value})

    def bulk_delete(self, table_id: str, *, row_ids: list[str]) -> dict:
        return self._request("POST", f"/tables/{table_id}/rows/bulk-delete", json={"row_ids": row_ids})

    def wait_for_completion(self, table_id: str, *, interval_s: float = 3, timeout_s: float = 300) -> dict:
        start = time.time()
        while time.time() - start < timeout_s:
            table = self.get(table_id)
            if table["status"] in ("completed", "failed"):
                return table
            time.sleep(interval_s)
        raise TimeoutError("Timed out waiting for table completion")

    def results_as_dataframe(self, table_id: str):
        """Fetch all rows and return as a pandas DataFrame."""
        import pandas as pd
        all_rows = []
        page = 1
        while True:
            result = self.rows(table_id, page=page, limit=100)
            all_rows.extend([r["data"] for r in result["data"]])
            if page * 100 >= result["pagination"]["total"]:
                break
            page += 1
        return pd.DataFrame(all_rows)


class Enhance(_Resource):
    def cells(self, table_id: str, *, row_ids: list[str], column_key: str, prompt: str, **kwargs: Any) -> dict:
        body = {"row_ids": row_ids, "column_key": column_key, "prompt": prompt, **kwargs}
        return self._request("POST", f"/tables/{table_id}/enhance", json=body)

    def bulk(self, table_id: str, *, row_id: str, columns: list[dict]) -> dict:
        return self._request("POST", f"/tables/{table_id}/enhance/bulk",
                             json={"row_id": row_id, "columns": columns})

    def cancel(self, table_id: str, column_key: str | None = None) -> dict:
        body = {"column_key": column_key} if column_key else {}
        return self._request("POST", f"/tables/{table_id}/enhance/cancel", json=body)

    def status(self, table_id: str) -> dict:
        return self._request("GET", f"/tables/{table_id}/enhance/status")

    def traces(self, table_id: str, row_id: str, column_key: str | None = None) -> dict:
        params = {"column_key": column_key} if column_key else {}
        return self._request("GET", f"/tables/{table_id}/rows/{row_id}/traces", params=params)


class Export(_Resource):
    def csv(self, table_id: str, *, columns: str | None = None) -> Any:
        params: dict[str, str] = {"format": "csv"}
        if columns:
            params["columns"] = columns
        return self._request("GET", f"/tables/{table_id}/export", params=params)

    def xlsx(self, table_id: str, *, columns: str | None = None, path: str | None = None) -> bytes:
        params: dict[str, str] = {"format": "xlsx"}
        if columns:
            params["columns"] = columns
        data = self._request("GET", f"/tables/{table_id}/export", params=params, raw=True)
        if path:
            with open(path, "wb") as f:
                f.write(data)
        return data

    def json(self, table_id: str, *, columns: str | None = None) -> list:
        params: dict[str, str] = {"format": "json"}
        if columns:
            params["columns"] = columns
        return self._request("GET", f"/tables/{table_id}/export", params=params)

    def images(self, table_id: str, *, path: str | None = None) -> bytes:
        data = self._request("GET", f"/tables/{table_id}/export", params={"format": "images"}, raw=True)
        if path:
            with open(path, "wb") as f:
                f.write(data)
        return data


class Glossary(_Resource):
    def list(self, *, page: int = 1, limit: int = 25) -> dict:
        params: dict[str, Any] = {"page": page, "limit": limit}
        return self._request("GET", "/glossary", params=params)

    def create(self, *, term: str, type: str, translations: dict | None = None, **kwargs: Any) -> dict:
        body: dict[str, Any] = {"term": term, "type": type, **kwargs}
        if translations:
            body["translations"] = translations
        return self._request("POST", "/glossary", json=body)

    def update(self, term_id: str, **kwargs: Any) -> dict:
        return self._request("PUT", f"/glossary/{term_id}", json=kwargs)

    def delete(self, term_id: str) -> None:
        self._request("DELETE", f"/glossary/{term_id}")


class Credits(_Resource):
    def balance(self) -> dict:
        return self._request("GET", "/credits/balance")

    def usage(self, *, page: int = 1, limit: int = 25, **kwargs: Any) -> dict:
        params = {"page": page, "limit": limit, **kwargs}
        return self._request("GET", "/credits/usage", params=params)


class Search(_Resource):
    def __call__(
        self,
        *,
        query: str,
        schema_id: str | None = None,
        columns: list[dict] | None = None,
        max_results: int = 7,
        model: str | None = None,
        webhook_url: str | None = None,
    ) -> dict:
        body: dict[str, Any] = {"query": query, "max_results": max_results}
        if schema_id:
            body["schema_id"] = schema_id
        if columns:
            body["columns"] = columns
        if model:
            body["model"] = model
        if webhook_url:
            body["webhook_url"] = webhook_url
        return self._request("POST", "/search", json=body)


class Enrich(_Resource):
    def __call__(
        self,
        *,
        items: list[dict],
        schema_id: str | None = None,
        columns: list[dict] | None = None,
        context: str | None = None,
        model: str | None = None,
        use_glossary: bool = False,
        web_search: bool = True,
        thinking: str | None = None,
        webhook_url: str | None = None,
    ) -> dict:
        body: dict[str, Any] = {"items": items}
        if schema_id:
            body["schema_id"] = schema_id
        if columns:
            body["columns"] = columns
        if context:
            body["context"] = context
        if model:
            body["model"] = model
        if use_glossary:
            body["use_glossary"] = use_glossary
        if not web_search:
            body["web_search"] = web_search
        if thinking:
            body["thinking"] = thinking
        if webhook_url:
            body["webhook_url"] = webhook_url
        return self._request("POST", "/enrich", json=body)


class LassoClient:
    def __init__(self, api_key: str, base_url: str = "https://hub.banditshq.com/api/v1"):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._http = httpx.Client(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=60.0,
        )

        self.schemas = Schemas(self)
        self.files = Files(self)
        self.tables = Tables(self)
        self.enhance = Enhance(self)
        self.export = Export(self)
        self.glossary = Glossary(self)
        self.credits = Credits(self)
        self.search = Search(self)
        self.enrich = Enrich(self)

    def _request(self, method: str, path: str, raw: bool = False, files: dict | None = None, **kwargs: Any) -> Any:
        if files:
            resp = self._http.request(method, path, files=files, **kwargs)
        else:
            resp = self._http.request(method, path, **kwargs)

        if resp.status_code == 204:
            return None

        if raw:
            resp.raise_for_status()
            return resp.content

        if resp.status_code >= 400:
            try:
                data = resp.json()
                raise LassoError(data["status_code"], data["error_type"], data["message"], data.get("request_id", ""))
            except (KeyError, ValueError):
                resp.raise_for_status()

        return resp.json()

    def close(self):
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args: Any):
        self.close()
