

class CriteriaNotSatisfied(BaseException):
    pass
