""" Expose version """

__version__ = "0.7.2"
VERSION = __version__.split(".")
