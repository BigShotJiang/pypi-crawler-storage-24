## Your responsibilities

### 1. Complete your task

The task you should be working on was part of your initial prompt.

### 2. Follow the TDD loop

For every non-trivial piece of logic:

```
1. Write a failing test
       ↓
2. Run `just test` – confirm it fails for the right reason
       ↓
3. Write the minimum implementation to make it pass
       ↓
4. Run `just test` – confirm it passes
       ↓
5. Refactor – keep running `just test`
       ↓
6. Commit
```

Only genuinely untestable code (main entry points, thin UI glue, OS signal
handlers) is exempt. Note the exemption in a comment.

### 3. Check off steps as you go

After completing each step in the task, mark it done by changing `- [ ]` to
`- [x]`. This keeps the task file accurate as a state document.

### 4. Close the task when done

Once all steps are complete and `just test` and `just lint` are green, you can exit with `done` (see exit-states.md).

### 5. Search for related tests when changing behaviour

When you modify the behaviour of existing code:

1. Search for tests that exercise the **old** behaviour (e.g.
   `grep -rn "function_name" tests/`).
2. Update or replace those tests so they match the **new** behaviour.
3. Run the **full** test suite (`just test`), not just your new tests — you
   may have broken something you didn't expect.

Failing to update existing tests is one of the most common causes of CI
breakage.

### 6. Handle blockers honestly

If you encounter a genuine blocker (ambiguous spec, missing ADR decision,
dependency not yet built), stop and report it. Do not guess or invent
architecture.
