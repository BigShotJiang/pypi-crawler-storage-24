import sympy as sp
from cinfsymmetries import VectorField, LieBracket, Distribution, JetSpaceChart

def main():
    # 1. Define a Jet Space of order 1
    # x: independent variable, u: dependent variable, order 1 (contains x, u, u1)
    J = JetSpaceChart(x_name='x', u_name='u', order=1)
    print(f"Jet Space Chart: {J}")

    # 2. Define the Total Derivative operator D
    # D = d/dx + u1*d/du
    D_op = J.total_derivative()
    print(f"Total Derivative D: {D_op}")

    # 3. Define a Distribution spanned by the Total Derivative (representing an ODE u' = u1)
    # In differential geometry, the distribution spanned by D is the Cartan distribution.
    D = Distribution([D_op])
    print(f"\nDistribution D spanned by: {[D_op]}")

    # 4. Define a Vector Field Y = d/du (Translation in u)
    # We can access coordinates from the chart J
    Y = VectorField({J.u: 1})
    print(f"Vector Field Y: {Y}")

    # 5. Compute Lie Bracket [D_op, Y]
    # [D_op, Y] = [d/dx + u1*d/du, d/du] = 0
    bracket = LieBracket(D_op, Y)
    print(f"Lie Bracket [D, Y]: {bracket}")

    # 6. Check if Y is a symmetry of the distribution D
    is_sym = D.check_symmetry(Y)
    print(f"Is Y a symmetry of D? {is_sym}")

    # 7. Check a Scaling symmetry
    # Z = x*d/dx + u*d/du
    # Note: For it to be a symmetry of the 1st order jet space, it must be the prolongation!
    # But let's check if the basic Z is a symmetry of the distribution spanned by D.
    # [Z, D] = [x d_x + u d_u, d_x + u1 d_u] 
    # = (Z(1) - D(x)) d_x + (Z(u1) - D(u)) d_u
    # = (0 - 1) d_x + (0 - u1) d_u = - (d_x + u1 d_u) = -D
    Z = VectorField({J.x: J.x, J.u: J.u})
    print(f"\nVector Field Z (scaling): {Z}")
    is_sym_z = D.check_symmetry(Z)
    print(f"Is Z a symmetry of D? {is_sym_z}")

if __name__ == "__main__":
    main()
