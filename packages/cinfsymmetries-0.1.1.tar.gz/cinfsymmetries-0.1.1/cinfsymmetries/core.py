import sympy as sp

class VectorField:
    def __init__(self, components):
        """
        Initializes a vector field.
        
        Args:
            components: A dict mapping coordinate variables (sympy Symbols)
                        to their functional coefficients (sympy expressions).
                        Example: {x: 1, y: x*y} for d/dx + x*y d/dy
        """
        self.components = {}
        for k, v in components.items():
            val = sp.simplify(v)
            if val != 0:
                self.components[k] = val
                
    def __call__(self, expr):
        """Apply the vector field to a scalar expression"""
        expr = sp.sympify(expr)
        result = 0
        for var, coeff in self.components.items():
            result += coeff * sp.diff(expr, var)
        return sp.simplify(result)
        
    def __add__(self, other):
        if not isinstance(other, VectorField):
            raise TypeError("Can only add two vector fields")
        all_vars = set(self.components.keys()).union(other.components.keys())
        new_comp = {}
        for v in all_vars:
            val = sp.simplify(self.components.get(v, 0) + other.components.get(v, 0))
            if val != 0:
                new_comp[v] = val
        return VectorField(new_comp)

    def __mul__(self, scalar):
        """Right multiplication by a scalar function"""
        scalar = sp.sympify(scalar)
        new_comp = {k: sp.simplify(v * scalar) for k, v in self.components.items()}
        return VectorField(new_comp)

    def __rmul__(self, scalar):
        return self.__mul__(scalar)

    def __sub__(self, other):
        return self + (other * -1)

    def __repr__(self):
        terms = []
        for v, c in self.components.items():
            terms.append(f"({c})*d_{v}")
        if not terms:
            return "0"
        return " + ".join(terms)


def LieBracket(X, Y):
    """
    Computes the Lie Bracket [X, Y] = X*Y - Y*X
    """
    all_vars = set(X.components.keys()).union(Y.components.keys())
    new_comp = {}
    for var in all_vars:
        eta = Y.components.get(var, 0)
        xi = X.components.get(var, 0)
        val = sp.simplify(X(eta) - Y(xi))
        if val != 0:
            new_comp[var] = val
    return VectorField(new_comp)


class Distribution:
    def __init__(self, vector_fields):
        """
        Initializes a distribution from a list of VectorFields.
        """
        self.vector_fields = list(vector_fields)
        
    def is_in_span(self, w):
        """
        Checks if vector field w is in the span of this distribution
        (with coefficients being functions).
        """
        if not self.vector_fields:
            # If the distribution is empty, w must be exactly 0
            return all(sp.simplify(coeff) == 0 for coeff in w.components.values())

        all_vars = set(w.components.keys())
        for Z in self.vector_fields:
            all_vars.update(Z.components.keys())
        all_vars = list(all_vars)

        M_rows = []
        w_col = []
        for var in all_vars:
            M_rows.append([Z.components.get(var, 0) for Z in self.vector_fields])
            w_col.append(w.components.get(var, 0))
            
        M = sp.Matrix(M_rows)
        W = sp.Matrix(w_col)
        
        # We need to know if W is in the column space of M.
        # Check if there are symbolic functions c_i such that M * c = W
        c = sp.symbols(f'c1:{len(self.vector_fields)+1}')
        try:
            sol = sp.linsolve((M, W), c)
            if sol:
                return True
            return False
        except Exception:
            # Fallback to checking ranks of augmented matrix over the fraction field
            M_aug = M.row_join(W)
            return M.rank() == M_aug.rank()

    def is_involutive(self):
        """
        Returns True if the distribution is involutive.
        That is, [Z_i, Z_j] is in the span of the distribution for all pairs i, j.
        """
        for i in range(len(self.vector_fields)):
            for j in range(i + 1, len(self.vector_fields)):
                bracket = LieBracket(self.vector_fields[i], self.vector_fields[j])
                if not self.is_in_span(bracket):
                    return False
        return True

    def check_symmetry(self, X):
        """
        Returns True if X is a symmetry of the distribution.
        This requires [X, Z_i] to be in the span of the distribution for all Z_i.
        
        If the distribution consists of a single vector field A (rank 1, e.g., representing an ODE), 
        this checks whether X is a point symmetry of the ODE.
        """
        for Z in self.vector_fields:
            bracket = LieBracket(X, Z)
            if not self.is_in_span(bracket):
                return False
        return True
class Chart:
    def __init__(self, names):
        """
        Initializes a manifold chart with a set of coordinate variables.
        
        Args:
            names: A list of strings or sympy Symbols.
        """
        self.vars = {}
        for name in names:
            if isinstance(name, str):
                s = sp.Symbol(name)
            else:
                s = name
            self.vars[str(s)] = s
            
    def __getitem__(self, name):
        return self.vars[name]
    
    def __getattr__(self, name):
        if name in self.vars:
            return self.vars[name]
        raise AttributeError(f"Chart has no coordinate '{name}'")
        
    def __repr__(self):
        return f"Chart({list(self.vars.values())})"


class JetSpaceChart(Chart):
    def __init__(self, x_name='x', u_name='u', order=1):
        """
        Initializes a Jet Space chart of a given order.
        Coordinates: (x, u, u1, u2, ..., u_order)
        """
        self.x_name = x_name
        self.u_name = u_name
        self.order = order
        
        names = [x_name, u_name]
        for i in range(1, order + 1):
            names.append(f"{u_name}{i}")
            
        super().__init__(names)
        
    def total_derivative(self):
        """
        Returns the Total Derivative operator (truncated to the chart's order).
        D = d/dx + u1*d/du + u2*d/du1 + ... + u_order*d/du_{order-1}
        """
        x = self.vars[self.x_name]
        u = self.vars[self.u_name]
        
        components = {x: 1}
        
        # d/du component is u1
        components[u] = self.vars[f"{self.u_name}1"]
        
        # d/dui component is u_{i+1}
        for i in range(1, self.order):
            curr_u = self.vars[f"{self.u_name}{i}"]
            next_u = self.vars[f"{self.u_name}{i+1}"]
            components[curr_u] = next_u
            
        return VectorField(components)
