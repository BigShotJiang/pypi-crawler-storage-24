# cinfsymmetries

A Python library for the geometric study of differential equations, bridging the gap from `sympy` to advanced concepts such as Lie symmetries, $\lambda$-symmetries, $C^{\infty}$-structures, and solvable structures. 

Originally inspired by functionality from Maple packages for Differential Geometry.

## Features
- **VectorFields and Distributions:** Define symbolic vector fields over an arbitrary set of variables.
- **Lie Brackets:** Compute Lie Brackets of vector fields analytically.
- **Involutivity:** Check if a distribution is involutive.
- **Symmetries:** Check if a given vector field is a symmetry of a distribution (meaning the Lie bracket with any vector in the distribution remains within the distribution span).

## Installation

```bash
pip install -e .
```

## Quick Start
```python
import sympy as sp
from cinfsymmetries import VectorField, LieBracket, Distribution

x, y = sp.symbols('x y')

# Define Vector Fields X = d/dx, Y = x*d/dy
X = VectorField({x: 1})
Y = VectorField({y: x})

# Lie Bracket [X, Y] = d/dy
bracket = LieBracket(X, Y)
print(bracket) # Outputs: (1)*d_y

# Create an ODE-like rank 1 distribution (spanned by X + Y)
D = Distribution([X + Y])

# Check if X is a symmetry of D
# [X, X+Y] = [X, Y] = d/dy, which is NOT in the span of (d/dx + x*d/dy), so False.
print(D.check_symmetry(X))
```
