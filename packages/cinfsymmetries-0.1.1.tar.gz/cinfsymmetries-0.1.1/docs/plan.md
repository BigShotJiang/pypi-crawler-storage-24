# Python Geometric ODE Library Plan

This plan aims to bridge the gap in Python for the geometric study of differential equations (Lie Symmetries, $\lambda$-symmetries, $C^{\infty}$-structures, Solvable Structures), migrating the functionality from your Maple package (`CinfStructures.mpl`) into a modern Python library heavily based on `sympy`.

## Phase 1: Project Configuration & Architecture
- [x] **Project Setup**: Initialize a standard Python library layout (`pyproject.toml`) and testing infrastructure (`pytest`).
- [x] **Architecture Design**: We chose to implement custom `VectorField` and `Distribution` classes for flexibility, and added `Chart` and `JetSpaceChart` to manage coordinates.

## Phase 2: Core Primitives
- [x] **Jet Spaces Definition**: Implemented `Chart` and `JetSpaceChart` to easily define $(x, u, u_1, \dots, u_k)$.
- [x] **Vector Fields & Operations**: Implemented `VectorField` with scalar multiplication, sum, evaluation, and Lie Bracket.
- [ ] **Differential Forms**: Implement differential $k$-forms, exterior derivative ($d\omega$), and interior product.

## Phase 3: Base Geometric Operations
- [/] **Associated Vector Field**: Added `JetSpaceChart.total_derivative()`. Future: Implement `associatedField(ode, chart)` to generate the field $A$ for a given ODE.
- [ ] **Prolongations**: Implement standard prolongations and $\lambda$-prolongations (porting `lambdaprolong`).
- [x] **Involutivity**: Implemented `Distribution.is_involutive()` and `Distribution.check_symmetry(X)`.

## Phase 4: Structures & High-Level Solving
- [ ] **Structure Checking**: Implement `checkstructure` to determine automatically whether given vector fields form a Solvable Structure or a $C^{\infty}$-structure.
- [ ] **Symmetries & Invariants**: Port algorithms to check symmetry conditions and calculate invariants.
- [ ] **Integration**: Develop methods to compute first integrals from symmetry 1-forms.
- [ ] **Solving/Reduction**: Implement reduction to orbit spaces and solving procedures based on the geometric structures found (`dsolvejet`).

## Next Steps
1. **Prolongations**: This is a crucial next step to handle symmetries of higher-order ODEs.
2. **Differential Forms**: Necessary for computing first integrals and working with structural 1-forms.
3. **ODE to Vector Field Mapping**: A helper to convert a SymPy equality (ODE) into its associated vector field on a Jet Space.
