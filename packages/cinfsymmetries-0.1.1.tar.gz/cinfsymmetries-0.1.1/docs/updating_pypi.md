# How to Update `cinfsymmetries` on PyPI

When we add new features (like Jet Spaces or prolongations) and you want to release a new version to the public, follow these steps.

### 1. Update the Version Number
Open `pyproject.toml` and increase the version number.
*   If it was `0.1.0`, change it to `0.1.1` (for small fixes) or `0.2.0` (for new features).

```toml
[project]
name = "cinfsymmetries"
version = "0.2.0"  # Update this!
```

### 2. Clean Old Builds (Optional but Recommended)
Delete the old `dist/` folder to avoid confusion when uploading.
```bash
rm -rf dist/
```

### 3. Rebuild the Library
Ensure your virtual environment is active and run the build command again.
```bash
source .venv/bin/activate
python3 -m build
```

### 4. Upload the New Version
Upload the new files in the `dist/` folder.
```bash
python3 -m twine upload dist/*
```
*   **Username**: `__token__`
*   **Password**: Your PyPI API token.

### 5. Update your local installation
To test your own changes locally after building but before uploading, you can run:
```bash
pip install -e .
```
This "editable" install means that any changes we make to the code files in the `cinfsymmetries/` folder will be immediately available in your Python environment without reinstalling.
