CinfStructures := module()
description "A collection of tools for working with solvable structures and cinf-structures";
option package; #esto es para que se pueda cargar con "with"
export  ModuleLoad, 
        associatedfield, #1. Paquete original, manejar cinf-structures
        formsfromvectors,
        checkstructure,
        integratedistribution,
        symmetriesjet,
        lambdaprolong,
        parametricrep,
        dsolvejet,
        firstintegraljet,
        issymmetry,
        determiningequations,
        isinvolutive,
        #######################################################################
        lambdagenVFs,# 2. Esto es para el asunto de la formula prolongacion
        #diagonalvectorfields2,
        ####################################################################
        orbitspaceprojection, # 3. Esto para la "reducción hacia delante"
        invariants,
        invariantsBD,
        #####################################################################
        plaintext, # 4. Estas son para pasar las outputs a latex
        textToTex,
        #################################################################
        hamiltonianVF, #5. Para Hamiltonian systems
        poissonBracket:
        
local readorder, deteccion_tipo_frame:

    #Aquí va todo lo que queramos que se ejecute al arrancar
    #=====================================================
    ModuleLoad:=proc()

    end proc:

    ModuleLoad():


# 1. PAQUETE ORIGINAL
######################


    #leer orden de una ODE en formato jet (da igual la dim del frame)
    #======================
    readorder:=proc(eq)
        local varjet,F:
        F:=DGinfo("CurrentFrame"):
        varjet := DGinfo(F, "FrameJetVariables"):
        if nops(varjet)=2 then
            return difforder(FromJet(eq,[varjet[2](varjet[1])])):
        else
            return difforder(FromJet(eq,[op(0,varjet[2])(varjet[1])])):
        end if:
    end proc;


    #Procedure para convertir ODE a campo asociado A (da igual la dim del frame)
    #============================================
    associatedfield:=proc(eq)
        local orden,basev,basef,varjet,F,phii,i:
        F:=DGinfo("CurrentFrame"):
        basev := DGinfo(F, "FrameJetVectors"): 
        basef := DGinfo(F, "FrameJetForms"):
        varjet := DGinfo(F, "FrameJetVariables"):
        orden:=readorder(eq):
        if nops(varjet)=2 then
            phii:=solve(subs(varjet[2][]=varjet[2],eq),varjet[2][1]):
            return evalDG(DGzip([1,phii],basev,"plus")):
        else
            phii:=solve(eq,op(0,varjet[2])[seq(1,i=1..orden)]):
            return evalDG(DGzip([1,op(varjet[3..orden+1]),phii], basev[1..orden+1], "plus")):
        end if:     
    end proc:

    # Reconoce si estamos en un jet o en un frame normal. También especifica si es un jet de una ODE
    # ==========================================================================00
    deteccion_tipo_frame:=proc()
        local F:
        F:=DGinfo("CurrentFrame"):
        if DGinfo(F, "FrameJetDimension")=DGinfo(F, "FrameBaseDimension")+DGinfo(F, "FrameFiberDimension") then
            return 0:#es un frame normal y corriente
        else
            if DGinfo(F, "FrameBaseDimension")=1 and DGinfo(F, "FrameFiberDimension")=1 then
                return 1:#es un frame tipo jet, pero al menos es de "tipo ODE"
            else
                return 2:#es otro tipo de jet, bueno saberlo para cuando implementemos PDEs
            end if:
        end if:
    end proc:
    
    
    # Decidir si una distribución es involutiva
    # ===========================================
    isinvolutive:=proc(Z,opc:=no)
        local varjet,F,involutive,i,j,mensaje,valor:
        F:=DGinfo("CurrentFrame"):
        varjet := DGinfo(F, "FrameJetVariables"):
        involutive:=1; 
        for i from 2 to nops(Z) do 
            for j from 1 to i-1 do
                if simplify(GetComponents(LieBracket(Z[i],Z[j]), Z),symbolic)=[] then
                    involutive:=0:
                end if:
            end do:
        end do:
        if involutive=0 then
            mensaje:="It is not an involutive distribution":            
            valor:=0:
        else 
            mensaje:="It is an involutive distribution":            
            valor:=1:
        end if:
         if opc="see" then
            printf(mensaje):
            return NULL:
        else
            return valor:
        end if:
    end proc;

    # Procedure para reconocer si dos colecciones de vectores en el frame actual
    # forman solvable structure, cinf-structure o nada de nada (el frame debe tener la dim adecuada!)
    # ===================================================
    checkstructure:=proc(Zname::uneval, Xname::uneval,opc:=no)
        local Z,X,S,Sname,i,j,k,involutive,solv_structure,cinf_structure,components,F,basev,dim,mensaje,valor,d_eq_cinf,d_eq_solv,d_eq_sasa:
        Sname:=[op(Zname),op(Xname)]:
        Z:=eval(Zname):
        X:=eval(Xname):
        S:=eval(Sname):
        F:=DGinfo("CurrentFrame"):
        basev := DGinfo(F, "FrameJetVectors"): 
        dim:=nops(basev):
        d_eq_cinf:=[];
        d_eq_solv:=[];
        d_eq_sasa:=[];
        if nops(DGbasis(S))<nops(S) then #comprobar si son independientes
            mensaje:="The vector fields are not independent":
            valor:=0:
        elif nops(S)<dim then
            mensaje:="Not enough vectors":
            valor:=-1:
        else 
            involutive:=1; # Comprobar que la distribución es involutiva
            for i from 2 to nops(Z) do 
                for j from 1 to i-1 do
                    if simplify(GetComponents(LieBracket(Z[i],Z[j]), Z),symbolic)=[] then
                        involutive:=0:
                    end if:
                end do:
            end do:
            if involutive=0 then
                mensaje:="First argument is not an involutive distribution":            
                valor:=-2:
            else 
                solv_structure:=1:
                cinf_structure:=1:
                for i from nops(Z)+1 to nops(S) do
                    for j from 1 to i-1 do
                        components:=simplify(GetComponents(LieBracket(S[i],S[j]),S)):
                        if opc="see" then
                            printf(cat("[",Sname[i],",",Sname[j],"]") ):
                            printf(cat("=", components,"\n")):
                        end if:
                        #para determining equations Sasa
                        if(irem(nosp(S),2)=1) then 
                            if (i>(nops(S)+1)/2 and j<=(nops(S)+1)/2) then
                            d_eq_sasa:=[op(d_eq_sasa),op(components[(nops(S)+1)/2+1..nops(S)])]:
                            end if:
                            if (i>(nops(S)+1)/2 and j>(nops(S)+1)/2) then
                            d_eq_sasa:=[op(d_eq_sasa),op(components)]:
                            end if:
                        end if:
                        #####################
                        d_eq_solv:=[op(d_eq_solv),components[i]]:
                        if components[i]<>0 then
                            solv_structure:=0;
                        end if:
                        for k from i+1 to nops(S) do
                            #print(components[k]):#para que muestre por pantalla los coeficientes que deben ser cero
                            d_eq_cinf:=[op(d_eq_cinf),components[k]]:
                            d_eq_solv:=[op(d_eq_solv),components[k]]:
                            if components[k]<>0 then
                                solv_structure:=0:
                                cinf_structure:=0:
                            end if:
                        end do:
                    end do:
                end do:
                if solv_structure=1 then
                    mensaje:="Is a solvable structure":
                    valor:=1:
                elif cinf_structure=1 then
                    mensaje:="Is a Cinf-structure":
                    valor:=2:
                else
                    mensaje:="No relationship":
                    valor:=-3:
                end if:
            end if:
        end if:
        if opc="see" then
            printf(mensaje):
            return NULL:
        elif opc="cinf" then
            return simplify(d_eq_cinf):
        elif opc="solv" then
            return simplify(d_eq_solv):
        elif opc="sasa" then
            return simplify(d_eq_sasa):
        else
            return valor:
        end if:
    end proc:






    #Procedure para convertir los vectores de una solvable structure a 1-formas (el frame tiene que tener la dim adecuada!)
    #========================================================================
    formsfromvectors:=proc(Z,X,opc:="contraction")
        local caso,rango,dim, A,basev,basef,F,forma,volform,L,i:
        caso:=checkstructure(Z,X):
        if not(caso=1 or caso =2) then
            print("Warning: they are not a cinf-structure"):
        end if:
        rango:=nops(Z):
        F:=DGinfo("CurrentFrame"):
        basev := DGinfo(F, "FrameJetVectors"): 
        basef:= DGinfo(F, "FrameJetForms"): 
        dim:=nops(basev):
        if opc="dual" then
            return DualBasis([op(Z),op(X)])[rango+1..dim]:
        elif opc="contraction" then
            volform:=1:
            for forma in basef do
                volform:=volform &wedge forma:
            end do:
            L:=[]:
            for i from 1 to nops(X) do
                forma:=Hook([op(Z),op(X[1..i-1]),op(X[i+1..nops(X)])],volform):
                L:=[op(L),forma]:
            end do:
            return L:
        else
            print("Third argument must be 'dual' or 'contraction'"):
            return NULL:
        end if:
        
        
    end proc:

    


    # Procedure para usar el FirstIntegrals en jet space
    #====================================================
    #(estaría bien añadir búsqueda de factores integrantes especiales, como que dependan de una sola
    #variable, y cosas así...)
    firstintegraljet:=proc(omega,opt:="none")
        local F,dim,basev,basef,var,E,T,varjet,i,omega_transf,integralesprimeras,invT,dI,componentsdI,componentsOmega:
        F:=DGinfo("CurrentFrame"):
        basev := DGinfo(F, "FrameJetVectors"): 
        basef := DGinfo(F, "FrameJetForms"): 
        varjet:=DGinfo(F, "FrameJetVariables"):
        dim:=nops(basev):
        var:=[x,u,seq(cat(u, i), i = 1 .. dim-2)]:
        DGsetup(var, E):
        T:=Transformation(E,F,[seq(varjet[i]=var[i],i=1..dim)]):
        invT:=InverseTransformation(T):
        omega_transf:=Pullback(T,omega):
        integralesprimeras:=FirstIntegrals([omega_transf]):
        if integralesprimeras=NULL then
            RemoveFrame(E):
            return NULL:
        else
            integralesprimeras:=Pullback(invT,integralesprimeras[1]):
            RemoveFrame(E):
            if opt="none" then
                return integralesprimeras:
            elif opt="IF" then
                dI:=ExteriorDerivative(integralesprimeras):
                componentsdI:=GetComponents(dI,basef):
                componentsOmega:=GetComponents(omega,basef):
                i:=1:
                while componentsOmega[i]=0 do
                    i:=i+1:
                end do: 
                return simplify(componentsdI[i]/componentsOmega[i],symbolic):
            end if:
        end if:
    end proc:

    # Procedure para buscar las integral manifolds usando una cinf-structura proporcionada como parámetro

    integratedistribution:=proc(Z,X)
        local case,r,n,w,Fr,F,varjet,T,i,k,integralesprimeras,res:
        case:=checkstructure(Z,X):
        if case=1 or case=2 then
            integralesprimeras:=[];
            Fr:=DGinfo("CurrentFrame"):
            varjet:=DGinfo(Fr,"FrameJetVariables"):
            r:=nops(Z):
            n:=nops(Z)+nops(X):
            w:=formsfromvectors(Z,X):
            # OBTENER "INTEGRALES PRIMERAS"
            F:=firstintegraljet(w[n-r]):
            integralesprimeras:=[op(integralesprimeras),F=cat(C,n-r)];
            printf("Implicit expression:"):
            print(F=cat(C,n-r)): #para imprima las integrales primeras obtenidas
            for k from n-1 by -1 to r+1 do
                T:=parametricrep(integralesprimeras[n-k]):
                w:=Pullback(T,w):
                F:=firstintegraljet(w[k-r]):
                integralesprimeras:=[op(integralesprimeras),F=cat(C,k-r)];
                print(F=cat(C,k-r)): #para que imprima las integrales primeras obtenidas
            end do:
            # DESPEJAR EN LAS "INTEGRALES PRIMERAS"
            res:=convert(simplify(solve(integralesprimeras,[seq(varjet[i],i=r+1..n)]),symbolic),radical):
            if res=[] or res=[[]] or res=NULL or searchtext("rootof", convert(res, string))<>0 then
                res:=op(simplify(solve(integralesprimeras,[seq(varjet[i],i=1..n)]),symbolic)):
            else
                res:=[seq(varjet[i]=varjet[i],i=1..r),op(op(res))]:
            end if:
            print(\n):
            printf("Parametric expression:"):
            return res:
        end if
    end proc:

    # Buscar simetrías de ODES en formato jet, devolviendo vectores
    #==============================================================
    symmetriesjet:=proc(eq)
        local F,varjet,basev,coefsym,L,i,X,vardep:
        F:=DGinfo("CurrentFrame"):
        varjet := DGinfo(F, "FrameJetVariables"):
        basev := DGinfo(F, "FrameJetVectors"):        
        if nops(varjet)=2 then #Para distinguir el caso de orden 1 definido en espacio jet de orden 0
            vardep:=varjet[2]:            
        else
            vardep:=op(0,varjet[2]):            
        end if:
        coefsym:=[symgen(FromJet(eq,vardep(varjet[1])))]:#ojo, poner "",way=all" para tener todas
        L:=[]:
        if nops(varjet)>2  then
            coefsym:=subs(vardep=vardep[],coefsym):
        end if:
        for i from 1 to nops(coefsym) do
            X:=evalDG(DGzip([rhs(coefsym[i][1]), rhs(coefsym[i][2])], basev[1 .. 2])):
            L:=[op(L),X]:
        end do:
        return L:
    end proc:

    # Resolver ecuación dada en formato jet
    #==============================================================
    dsolvejet:=proc(eq)
        local F,varjet,basev,sol,i,result:
        F:=DGinfo("CurrentFrame"):
        varjet := DGinfo(F, "FrameJetVariables"):
        basev := DGinfo(F, "FrameJetVectors"):
        if nops(varjet)>2 then
            sol:=dsolve(FromJet(eq,op(0,varjet[2])(varjet[1])),op(0,varjet[2])(varjet[1])):
        else
            sol:=dsolve(subs([varjet[2][1]=diff(varjet[2](varjet[1]),varjet[1]),varjet[2][]=varjet[2](varjet[1])],eq));
        end if:
        if nops([sol])=1 then
            return ToJet(lhs(sol)=rhs(sol), op(0,varjet[2])(varjet[1]), jetnotation = jetvariableswithbrackets)
        else
            result:=[]:
            for i in sol do
                result:=[op(result),ToJet(lhs(i)=rhs(i), op(0,varjet[2])(varjet[1]), jetnotation = jetvariableswithbrackets)]:
            end do:
            return result:
        end if:
    end proc:


    # Lambdaprolongar un campo dado
    lambdaprolong:=proc(X,lambda,orden,eq:="unknown")
        local A,F,varjet,basev,i,coef,L,eta:        
   
        
        F:=DGinfo("CurrentFrame"):
        varjet := op(DGinfo(F, "FrameJetVariables")):
        basev := DGinfo(F, "FrameJetVectors"):
        if orden>(nops(basev)-2) then
            print("The vector cannot be lambdaprolonged to that order in this jet space"):
            return NULL:
        end if:
        
        coef:=simplify(expand(GetComponents(X,basev)[1..2]),symbolic):  
        if (readorder(lambda)>1 or readorder(coef[1])>1 or readorder(coef[2])>1)  and eq="unknown" then
            return "ODE needed":
        end if:
        if eq <>"unknown" then
            A:=associatedfield(eq):
        else
            A:=evalDG(DGzip([1,varjet[3..orden+2],1], basev[1..orden+2], "plus"))
        end if:        
        
        
        for i from 3 to orden+2 do
            eta:=simplify(expand(LieDerivative(A,coef[i-1])+lambda*coef[i-1]-(LieDerivative(A,coef[1])+lambda*coef[1])*varjet[i]),symbolic):
            coef:=[op(coef),eta]:
        end do:
        
        return evalDG(DGzip(coef, basev[1..orden+2], "plus")):
    end proc:


    # Intenta despejar alguna de las variables de una expresión implícita dada
    parametricrep:=proc(exp,n::expects(integer):=ign) #argumento opcional para que empiece por despejar una variable a elección nuestra
        local F,varjet,terminado,i,j,d:
        F:=DGinfo("CurrentFrame"):
        varjet := DGinfo(F, "FrameJetVariables"):
        terminado:=0:
        if n=ign then
            i:=nops(varjet);
        else
            i:=n:
        end if:
        if i<1 or i> nops(varjet) then
            print("Invalid index"):
            return NULL:
        end if:
        while terminado=0 and i>0 do
            d:=solve(exp,varjet[i]):
            if nops([d])>1 then
                d:=d[1]:
            end if:
            if d=NULL or searchtext("rootof", convert(d, string))<>0 then
                i:=i-1:
            else:
                terminado:=1:
            end if:
        end do:
        if i=0 then
            return NULL:
        else
            return Transformation(F,F,[seq(varjet[j]=varjet[j],j=1..i-1),varjet[i]=simplify(d,symbolic),seq(varjet[j]=varjet[j],j=i+1..nops(varjet))]):
        end if:
        
    end proc:



    # Comprueba si un vector es simetría o cinf-simetría de una distribucion
    issymmetry:=proc(Z,X,opc:=no)    
        local S,i,j,k,sym,cinf_sym,involutive,components,F,basev,dim,mensaje,valor:
        S:=[op(Z),X]:        
        F:=DGinfo("CurrentFrame"):
        basev := DGinfo(F, "FrameJetVectors"): 
        dim:=nops(basev):
        involutive:=1; # Comprobar que la distribución dada es involutiva
        for i from 2 to nops(Z) do 
            for j from 1 to i-1 do
                if simplify(GetComponents(LieBracket(Z[i],Z[j]), Z),symbolic)=[] then
                    involutive:=0:
                end if:
            end do:
        end do:
        if involutive=0 then
            mensaje:="First argument is not an involutive distribution":            
            valor:=-2:
        else
            sym:=1:
            cinf_sym:=1:
            # Comprobar que la distribución S=Z,X es involutiva
            for i from 2 to nops(S) do 
                for j from 1 to i-1 do
                    if simplify(GetComponents(LieBracket(S[i],S[j]), S),symbolic)=[] then
                        cinf_sym:=0:
                    end if:
                end do:
            end do:
            if cinf_sym=0 then
                mensaje:="No relationship":            
                valor:=-3:
            else
                for j from 1 to nops(Z) do
                    components:=simplify(GetComponents(LieBracket(X,Z[j]),S)):
                    if opc="see" then
                        printf(cat(components,"\n")):
                    end if:
                    if components[nops(S)]<>0 then
                        sym:=0;
                    end if:
                end do:
                if sym=0 then
                    mensaje:="Is a Cinf-symmetry":
                    valor:=2:
                else
                    mensaje:="Is a symmetry":
                    valor:=1:
                end if:
            end if:
        end if:  
        if nops(DGbasis(S))<nops(S) then
            mensaje:="The vector field is not independent of the distribution":
            valor:=0:
        end if:
        if opc="see" then
            printf(mensaje):
            return NULL:
        else
            return valor:
        end if:
    end proc:

    # Dada una involutive distribution y una lista de vectores devuelve las condiciones que se deben cumplir para que
    # estos últimos formen parte de una solv structure o una cinf-structure total o parcial
    determiningequations:=proc(Z,X,opc:="no")
        local S,involutive,n,r,k,neqsolv,neqcinf,Xc,F,basev,i,j,mensaje,eqsdev,opc2:
        S:=[op(Z),op(X)]:        
        F:=DGinfo("CurrentFrame"):
        basev := DGinfo(F, "FrameJetVectors"): 
        n:=nops(basev):
        r:=nops(Z):
        k:=nops(X):
        neqsolv:=(1/2)*n*k^2+n*r*k-(1/2)*n*k-(1/3)*k^3-k^2*r-k*r^2+(1/2)*k^2+r*k-(1/6)*k:
        neqcinf:=(1/2)*n*k^2+n*r*k-(1/2)*n*k+(1/3)*k-(1/3)*k^3-k^2*r-k*r^2:
        if opc="no" then
            opc2:="cinf":
        else
            opc2:=opc:
        end if:
        if nops(DGbasis(S))<nops(S) then #comprobar si son independientes
            mensaje:="The vector fields are not independent":
            return mensaje:
        else 
            involutive:=1; # Comprobar que la distribución es involutiva
            for i from 2 to nops(Z) do 
                for j from 1 to i-1 do
                    if simplify(GetComponents(LieBracket(Z[i],Z[j]), Z),symbolic)=[] then
                        involutive:=0:
                    end if:
                end do:
            end do:
            if involutive=0 then
                mensaje:="First argument is not an involutive distribution":            
                return mensaje:
            else 
                if nops(S)<n then #si no hay bastantes vectores...
                    Xc:=basev[r+k+1..n]:# pruebo con completar con los ultimos, que creo que dan ecuaciones más sencillas
                    if nops(DGbasis([op(S),op(Xc)]))<n then
                        Xc:=ComplementaryBasis(S, basev):# si no valen pues me conformo con estos
                    end if:
                    eqsdev:= checkstructure(Z,[op(X),op(Xc)],opc2):
                else
                    eqsdev:= checkstructure(Z,X,opc2):
                end if:
            end if:
        end if:
        if opc2="solv" then
            return eqsdev[1..neqsolv]:
        elif opc2="cinf" then
            return eqsdev[1..neqcinf]:
        elif opc2="sasa" then
            return eqsdev:
        else
            return "Invalid parameter":
        end if:
    end proc:


# 2. FUNCIONES FORMULA PROL. son funciones quizás para otro paper
##########################

    # Crea vectores en diagonal form, versión con lambdas
    lambdagenVFs:=proc(lambda,eq:="unknown")
        local A,F,varjet,basev,i,j,kgorro,L,eta,neededODE,vectortemp,coefsmatrix,coefstemp,orden:        
        orden:=nops(lambda):
        neededODE:=false:
        for i from 1 to nops(lambda) do 
            if readorder(lambda[i])>i and eq="unknown" then
                neededODE:=true:
            end if:
        end do:
        if neededODE=true then
            return "ODE needed":
        end if:
        
        F:=DGinfo("CurrentFrame"):
        varjet := op(DGinfo(F, "FrameJetVariables")):
        basev := DGinfo(F, "FrameJetVectors"):
        
        if orden>(nops(basev)-2) then
            print("The order is too big for this jet space"):
            return NULL:
        end if:

        if eq <>"unknown" then
            A:=associatedfield(eq):
        else
            A:=evalDG(DGzip([1,varjet[3..orden+2],1], basev[1..orden+2], "plus"))
        end if:        
        
        vectortemp:=lambdaprolong(basev[2],lambda[1],orden,eq):
        coefsmatrix:=[GetComponents(vectortemp,basev)]:
        L:=[vectortemp]:        
        for i from 2 to nops(lambda)+1 do
            coefsmatrix:=[op(coefsmatrix),[seq(0,j=1..i),seq(1,j=i+1..orden+2)]]:
            for kgorro from i+2 to orden+2 do
                eta:=0:
                for j from 1 to i do
                    eta:=simplify(eta+LieDerivative(A,coefsmatrix[j][kgorro-1-i+j])+lambda[j]*coefsmatrix[j][kgorro-1-i+j]):
                end do:
                coefsmatrix[i][kgorro]:=eta:
            end do:
            
            vectortemp:=evalDG(DGzip(coefsmatrix[i],basev[1..orden+2],"plus")):
            L:=[op(L),vectortemp]:
        end do:
        
        return L:
    end proc:


    # # Crea vectores en diagonal form, versión con deltas
    # diagonalvectorfields2:=proc(delta,eq:="unknown")
    #     local A,F,varjet,basev,i,j,kgorro,L,eta,neededODE,vectortemp,coefsmatrix,coefstemp,orden,lambda:        
    #     lambda:=[delta[1]]:
    #     for i from 2 to nops(delta) do
    #         lambda:=[op(lambda),delta[i]-delta[i-1]]:
    #     end do:
    #     return lambdagenVFs(lambda,eq);
    # end proc:


# 3. FUNCIONES REDUCCION HACIA DELANTE: funciones para reducir al orbit space.
##########################################################################
    invariants:=proc(Y)
        local varjet,F,G,Sol:
        F:=DGinfo("CurrentFrame"):
        varjet := DGinfo(F, "FrameJetVariables"):
        Sol:=pdsolve(LieDerivative(Y, G(op(varjet)))):
        return simplify([op(1..,rhs(Sol))]):
    end proc;

    invariantsBD:=proc(inv1,inv2,eq:="unknown")
        local varjet,F,A,basev,result, i:
        F:=DGinfo("CurrentFrame"):
        basev := DGinfo(F, "FrameJetVectors"): 
        varjet := DGinfo(F, "FrameJetVariables"):
        
        if (readorder(inv1)>1 or readorder(inv2)>1)  and eq="unknown" then
            return "ODE needed":
        end if:
        if eq <>"unknown" then
            A:=associatedfield(eq):
        else
            A:=evalDG(DGzip([1,op(varjet[3..nops(varjet)]),1], basev, "plus"));
        end if: 
        # check that the first invariant is not first integral of A or a constant
        if LieDerivative(A,inv1)=0 then
            return "The first function is a constant, is a first integral of the ODE or the current frame is not appropriate":
        end if:
        
        result:=[inv1,inv2]:
        for i from 3 to nops(varjet)-1 do
            result:=[op(result),simplify(LieDerivative(A,result[i-1])/LieDerivative(A,result[1]))];
        end do:
        return result:
    end proc;


    orbitspaceprojection:=proc(Y,{invs:="default",fname:="default"})
        local varjet,F,ecuaciones,phii,IBD,i,fnamer,invsmod,checkinv,coordsmod,proj,proj_inv:
        F:=DGinfo(Y, "ObjectAttributes")[2]:
        ChangeFrame(F):
        varjet := DGinfo(F, "FrameJetVariables"):
        # adjust the frame name if not given
        if fname="default" then
            fnamer:=cat(F,"red"):
        else
            fnamer:=fname:
        end if:

        # adjust the invariants if not given
        if invs="default" then
            # comprobamos si tiene la IBD property
            IBD:=1:
            ecuaciones:=determiningequations([associatedfield(TotalDiff(varjet[nops(varjet)],varjet[1])-phii)],[Y]):
            for i from 1 to nops(varjet)-3 do
                if ecuaciones[i]<>0 then
                    IBD:=0:
                end if:
            end do:
            if IBD=0 then
                invsmod:=invariants(Y)[1..nops(varjet)-1]:
                
            else
                invsmod:=invariants(Y);
                invsmod:=invariantsBD(op(invsmod[1..2])):
            end if:
        else
            # we check that the given functions are invariants indeed
            checkinv:=1:
            for i in invs do
                if simplify(LieDerivative(Y,i))<>0 then
                    checkinv:=0:
                end if:
            end do:
            if checkinv=1 then 
                if nops(invs)<nops(varjet)-1 then
                    return "Not enough invariants"
                end if:
                invsmod:=invs:
            else
                return "They are not invariants of the given vector field"
            end if:
        end if:

        # create the new frame and the transformation (projection) and its inverse
        
        # first, decide if we are in a jet space or not
            
        if deteccion_tipo_frame(F)=0 then
            DGsetup([seq(cat(varjet[i],"r"),i=1..nops(varjet)-1)], fnamer):
            coordsmod:=DGinfo(fnamer, "FrameJetVariables"):
            print(cat("Frame ",fnamer, " created, with coordinates ",coordsmod)):
            #print("no is jet"):
        else
            # Now decide if the provided vector has IBD property
            if simplify(invsmod)=simplify(invariantsBD(op(invsmod[1..2]))) then
                DGsetup([cat(varjet[1],"r")], [cat(op(0,varjet[2]),"r")], fnamer, nops(varjet)-3):
                coordsmod:=DGinfo(fnamer, "FrameJetVariables"):
                print(cat("Frame ",fnamer, " created, with coordinates ",coordsmod)):
                #print("Is jet, sí IBD"):
            else
                DGsetup([seq(cat(varjet[1],i,"r"),i=1..nops(varjet)-1)], fnamer):
                coordsmod:=DGinfo(fnamer, "FrameJetVariables"):
                print(cat("Frame ",fnamer, " created, with coordinates ",coordsmod)):
                #print("IS jet, no IBD"):
            end if:
        end if:
        proj:=Transformation(F,fnamer,[seq(coordsmod[i]=invsmod[i],i=1..nops(coordsmod))]):
        proj_inv:=InverseTransformation(proj):
        return proj,proj_inv:
    end proc;





# 4. FUNCIONES TEXTO: funciones para manejar la salida de los procedures y pasarlas a latex.
##########################

    # Devuelve un vector field o una 1-form o una lista de cualquiera de ambos 
    # en formato texto para copiar/pegar
    #==============================================
    plaintext:=proc(X)
        local lista,j:
        if nops(X)>1 then
            lista:=[]:
            for j from 1 to nops(X) do
                lista:=[op(lista),op(2, Typesetting:-Parse(subsindets(`print/_DG`(op(X[j])), specfunc(anything, Typesetting:-mcomplete), proc (u) options operator, arrow; op(1, u) end proc)))]:
            end do:
            return lista:
        else
            return op(2, Typesetting:-Parse(subsindets(`print/_DG`(op(X)), specfunc(anything, Typesetting:-mcomplete), proc (u) options operator, arrow; op(1, u) end proc)))
        end if:
    end proc;


    # Pasa una cadena a estilo Latex mediante las sustituciones que se indiquen en "lista"
    #==============================================
    textToTex:=proc(X) 
        local lista, prov, element:
        lista := [
                ["qz", "q_z"],
                ["rz", "r_z"],
                ["sz", "s_z"],
                ["uz", "u_z"],
                ["vz", "v_z"],
                ["wz", "w_z"],
                ["ux", "u_x"],
                ["vx", "v_x"],
                ["wx", "w_x"],
                ["qx", "q_x"],
                ["rx", "r_x"],
                ["sx", "s_x"],
                ["qy", "q_y"],
                ["ry", "r_y"],
                ["sy", "s_y"],
                ["wy", "w_y"],
                ["vt", "v_t"],
                ["ut", "u_t"],
                ["vy", "v_y"],
                ["delta","\delta"],
                ["Ux","U_x"],
                ["Uy","U_y"],
                ["(diff(lambda1(x, u[], u[1]), u[], x))", "\\lambda_{1,xu}"],
                ["(diff(lambda1(x, u[], u[1]), x, x, x))", "\\lambda_{1,xxx}"],
                ["(diff(lambda1(x, u[], u[1]), u[], u[]))", "\\lambda_{1,uu}"],
                ["(diff(lambda1(x, u[], u[1]), u[], u[], u[]))", "\\lambda_{1,uuu}"],
                ["(diff(lambda1(x, u[], u[1]), x, x))", "\\lambda_{1,xx}"],
                ["(diff(lambda1(x, u[], u[1]), u[], x, x))", "\\lambda_{1,xxu}"],
                ["(diff(lambda1(x, u[], u[1]), u[], u[], x))", "\\lambda_{1,xuu}"],
                ["(diff(lambda1(x, u[], u[1]), u[1]))", "\\lambda_{1,u_1}"],
                ["(diff(lambda1(x, u[], u[1]), x))", "\\lambda_{1,x}"],
                ["diff(lambda1(x, u[], u[1]), x)", "\\lambda_{1,x}"],
                ["(diff(lambda1(x, u[], u[1]), u[1], u[1]))", "\\lambda_{1,u_1 u_1}"],
                ["(diff(lambda1(x, u[], u[1]), u[1], u[1], x))", "\\lambda_{1,xu_1 u_1}"],
                ["(diff(lambda1(x, u[], u[1]), u[1], u[1], u[]))", "\\lambda_{1,uu_1 u_1}"],
                ["(diff(lambda1(x, u[], u[1]), u[1], u[1], u[1]))", "\\lambda_{1,u_1 u_1 u_1}"],
                ["(diff(lambda1(x, u[], u[1]), u[1], u[]))", "\\lambda_{1,uu_1}"],
                ["(diff(lambda1(x, u[], u[1]), u[1], x))", "\\lambda_{1,xu_1}"],
                ["(diff(lambda1(x, u[], u[1]), u[1], x, x))", "\\lambda_{1,xxu_1}"],
                ["(diff(lambda1(x, u[], u[1]), u[1], u[], u[]))", "\\lambda_{1,uuu_1}"],
                ["(diff(lambda1(x, u[], u[1]), u[1], u[], x))", "\\lambda_{1,xuu_1}"],
                ["(diff(lambda1(x, u[], u[1]), u[]))", "\\lambda_{1,u}"],



                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[], u[]))", "\\lambda_{2,uu}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[1, 1], u[]))", "\\lambda_{2,uu_2}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[1, 1]))", "\\lambda_{2,u_2}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[1], u[]))", "\\lambda_{2,u_1u}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[1, 1], u[]))", "\\lambda_{2,u_2u}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[1], u[1]))", "\\lambda_{2,u_1u_1}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[1, 1], u[1]))", "\\lambda_{2,u_2u_1}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[1, 1], u[1,1]))", "\\lambda_{2,u_2u_2}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), x))", "\\lambda_{2,x}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[], x))", "\\lambda_{2,ux}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[1], x))", "\\lambda_{2,u_1x}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[1, 1], x))", "\\lambda_{2,u_2x}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), x, x))", "\\lambda_{2,xx}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[]))", "\\lambda_{2,u}"],
                ["(diff(lambda2(x, u[], u[1], u[1, 1]), u[1]))", "\\lambda_{2,u_1}"],

                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[]))", "\\lambda_{3,u}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[1]))", "\\lambda_{3,u_1}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[], u[]))", "\\lambda_{3,uu}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[1, 1], u[]))", "\\lambda_{3,uu_2}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[1, 1]))", "\\lambda_{3,u_2}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[1], u[]))", "\\lambda_{3,u_1u}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[1, 1], u[]))", "\\lambda_{3,u_2u}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[1], u[1]))", "\\lambda_{3,u_1u_1}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[1, 1], u[1]))", "\\lambda_{3,u_2u_1}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[1, 1], u[1,1]))", "\\lambda_{3,u_2u_2}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), x))", "\\lambda_{3,x}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[], x))", "\\lambda_{3,ux}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[1], x))", "\\lambda_{3,u_1x}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), u[1, 1], x))", "\\lambda_{3,u_2x}"],
                ["(diff(lambda3(x, u[], u[1], u[1, 1]), x, x))", "\\lambda_{3,xx}"],



                ["lambda1(x, u[], u[1])","\\lambda_1"],
                ["lambda2(x, u[], u[1])","\\lambda_2"],
                ["lambda3(x, u[], u[1], u[1, 1])","\\lambda_3"],
                ["u[1]", "u_1"],
                ["u[1, 1]", "u_2"],
                ["u[1, 1, 1]", "u_3"],
                ["`*`",""],["*",""],
                ["1/2","\\frac{1}{2}"],
                ["[]",""],["[1]","_1"],["[1,1]","_2"],["[1,1,1]","_3"],["[1,1,1,1]","_4"],
                ["exp(x)","e^{x}"],["exp(-x)","e^{-x}"],["exp(2x)","e^{2x}"],
                ["(du)","du"],["(du_1)","du_1"],["(du_2)","du_2"],["(du_3)","du_3"],["(du_4)","du_4"],
                ["C1","C_1"],["C2","C_2"],["C3","C_3"],["C4","C_4"],
                ["(","\\left("],[")","\\right)"],
                ["Pi","\\pi"]
                ]; 
        prov := convert(X, string); 
        for element in lista do 
            prov := SubstituteAll( prov , element[1], element[2]) 
        end do; 
        return prov;
    end proc:


# 5. FUNCIONES HAMILTONIAN SYSTEMS
##########################
  #Procedure para crear un Hamiltonian VF dada la función
    #============================================
    hamiltonianVF:=proc(H)
        local orden,basev,basef,varjet,F,i,VF,q,p:
        F:=DGinfo("CurrentFrame"):
        basev := DGinfo(F, "FrameJetVectors"): 
        basef := DGinfo(F, "FrameJetForms"):
        varjet := DGinfo(F, "FrameJetVariables"):
        # detectamos si hay variable tiempo o no
        if nops(varjet) mod 2=1 then
             printf(cat(varjet[1], " interpreted as time\n")):
             printf(cat(varjet[2..(nops(varjet)+1)/2], ", interpreted as configuration variables\n")):
             printf(cat(varjet[(nops(varjet)+1)/2+1..nops(varjet)], ", interpreted as conjugate momenta\n")):
       
       VF := 0:
        q := varjet[2..(nops(varjet)+1)/2]:
        p := varjet[(nops(varjet)+1)/2+1..nops(varjet)]:
        
        for i to (nops(varjet)-1)/2 do
            VF := VF + (diff(H, p[i]) * basev[i+1] - diff(H, q[i]) * basev[i+(nops(varjet)-1)/2+1])
        end do:
        
        return evalDG(VF)
        else
          printf(cat(varjet[1..nops(varjet)/2], ", interpreted as configuration variables\n")):
        printf(cat(varjet[nops(varjet)/2+1..nops(varjet)], ", interpreted as conjugate momenta\n")):
        
        # Define the Hamiltonian vector field
        VF := 0:
        q := varjet[1..nops(varjet)/2]:
        p := varjet[nops(varjet)/2+1..nops(varjet)]:
        
        for i to nops(varjet)/2 do
            VF := VF + (diff(H, p[i]) * basev[i] - diff(H, q[i]) * basev[i+nops(varjet)/2])
        end do:
        
        return evalDG(VF)
        end if:     
    end proc:



poissonBracket := proc(f, g, opc := no)
    local varjet, F, i, q, p, PB:
    F := DGinfo("CurrentFrame"):
    varjet := DGinfo(F, "FrameJetVariables"):
    
    # Detect if there is a time variable or not
    if nops(varjet) mod 2 = 1 then
        if opc = "see" then
            printf(cat(varjet[1], " interpreted as time\n")):
            printf(cat(varjet[2..(nops(varjet)+1)/2], ", interpreted as configuration variables\n")):
            printf(cat(varjet[(nops(varjet)+1)/2+1..nops(varjet)], ", interpreted as conjugate momenta\n")):
        end if:
        
        q := varjet[2..(nops(varjet)+1)/2]:
        p := varjet[(nops(varjet)+1)/2+1..nops(varjet)]:
    else
        if opc = "see" then
            printf(cat(varjet[1..nops(varjet)/2], ", interpreted as configuration variables\n")):
            printf(cat(varjet[nops(varjet)/2+1..nops(varjet)], ", interpreted as conjugate momenta\n")):
        end if:
        
        q := varjet[1..nops(varjet)/2]:
        p := varjet[nops(varjet)/2+1..nops(varjet)]:
    end if:
    
    # Compute the Poisson bracket
    PB := 0:
    for i to nops(q) do
        PB := PB + (diff(f, q[i]) * diff(g, p[i]) - diff(f, p[i]) * diff(g, q[i])):
    end do:
    
    return simplify(PB):
end proc:



end module:


