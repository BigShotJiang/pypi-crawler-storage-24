# Youtube Autonomous Main Editor Pools Module

The pools we need to use in our editor, related to the `moderngl.Texture` instances and to our own-designed `RenderTarget` class.