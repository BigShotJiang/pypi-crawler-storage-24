from yta_editor_pools.render_target import RenderTarget
from yta_editor_pools.texture.utils import get_texture_key
from collections import defaultdict

import moderngl


class RenderTargetPool:
    """
    A pool of `RenderTarget` instances.

    These instances are built to be used by our
    nodes that will be using the shaders, uniforms
    and inputs to write with an specific FBO and a
    single texture that is attached to it.
    """

    def __init__(
        self,
        context: moderngl.Context
    ):
        self.context: moderngl.Context = context
        """
        The `moderngl` context we need to work with.
        """
        self.pool = defaultdict(list)
        """
        The internal pool to store the `RenderTarget`
        instances.
        """

    def acquire(
        self,
        width: int = 1920,
        height: int = 1080,
        number_of_components: int = 4,
        dtype: str = 'f1'
    ) -> RenderTarget:
        """
        Get a `RenderTarget` from the pool with the given
        parameters, or create a new one if non existing
        and mark in use.
        """
        key = get_texture_key(
            width = width,
            height = height,
            number_of_components = number_of_components,
            dtype = dtype
        )

        if self.pool[key]:
            render_target = self.pool[key].pop()
        else:
            texture = self.context.texture(
                (width, height),
                components = number_of_components,
                dtype = dtype
            )

            #texture.filter = (moderngl.LINEAR, moderngl.LINEAR)

            render_target = RenderTarget(
                context = self.context,
                texture = texture,
                width = width,
                height = height,
                number_of_components = number_of_components,
                dtype = dtype
            )
            
        render_target.reset_state()
        render_target.mark_in_use()

        return render_target
    
    def acquire_like(
        self,
        render_target: 'RenderTarget'
    ) -> 'RenderTarget':
        """
        Get a `RenderTarget` from the pool with the same
        parameters than the `render_target` provided, or
        create a new one if non existing and mark in use.
        """
        return self.acquire(
            width = render_target.width,
            height = render_target.height,
            number_of_components = render_target.number_of_components,
            dtype = render_target.dtype
        )

    def release(
        self,
        render_target: RenderTarget
    ) -> None:
        """
        Mark the `render_target` provided as free and
        return it to the pool.
        """
        render_target.mark_free()

        key = get_texture_key(
            width = render_target.width,
            height = render_target.height,
            number_of_components = render_target.number_of_components,
            dtype = render_target.dtype
        )

        self.pool[key].append(render_target)

    # TODO: Is it ok like this (?)
    def clear(
        self
    ):
        """
        Empty the whole pool by also freeing the resources
        of each `RenderTarget` instance.
        """
        for render_targets in self.pool.values():
            for render_target in render_targets:
                render_target.release_gpu()

        self.pool.clear()