from yta_validation.parameter import ParameterValidator

import moderngl


class RenderTarget:
    """
    An object that acts as a unit the system uses
    to render content on it, attached to a texture
    and an FBO.

    The purpose of this class is to have an object
    in which our nodes are able to write. It 
    includes a texture but it is always attached to
    it and it doesn't come from any pool.

    The `RenderTarget` itself belongs to the pool
    while it is not being used and to the consumer
    after the `.acquire()` method is called.
    """

    __slots__ = (
        'context',
        'texture',
        '_fbo',
        'width',
        'height',
        'number_of_components',
        'dtype',
        '_is_in_use'
    )

    @property
    def fbo(
        self
    ) -> moderngl.Framebuffer:
        """
        Lazy FBO.
        """
        if self._fbo is None:
            self._fbo = self.context.framebuffer(
                color_attachments = [self.texture]
            )

        return self._fbo

    def __init__(
        self,
        context: moderngl.Context,
        texture: moderngl.Texture,
        width: int,
        height: int,
        number_of_components: int,
        dtype: str
    ):
        # TODO: Add docu
        self.context = context
        self.texture: moderngl.Texture = texture
        """
        The texture of the render target, that is always
        attached to this `RenderTarget` instance.
        """
        self.width = width
        self.height = height
        self.number_of_components = number_of_components
        self.dtype = dtype

        self._fbo: moderngl.Framebuffer | None = None
        self._is_in_use: bool = False

    def reset_state(
        self
    ):
        """
        TODO: Document
        """
        self.texture.filter = (moderngl.LINEAR, moderngl.LINEAR)

    def use(
        self
    ):
        """
        Bind FBO and prepare viewport.
        """
        self.fbo.use()
        self.context.viewport = (0, 0, self.width, self.height)

    def clear(
        self
    ):
        """
        Clear the context.
        """
        self.context.clear(0.0, 0.0, 0.0, 0.0)

    def write(
        self,
        data: 'np.ndarray'
    ) -> 'RenderTarget':
        """
        Write the `data` numpy array provided directly in
        the texture, which is uploading from CPU to GPU.
        """
        ParameterValidator.validate_mandatory_numpy_array('data', data)

        """
        The `.write()` method accepts a numpy array only,
        if no we have to do `.tobytes()` to whatever we
        are trying to write.
        """
        self.texture.write(data)

        return self

    def read(
        self
    ) -> bytes:
        """
        Read the information existing in the `texture` 
        inside this `RenderTarget` instance, which is
        downloading from GPU to CPU.
        """
        return self.texture.read()

    def mark_in_use(
        self
    ) -> 'RenderTarget':
        """
        Set this `RenderTarget` instance as in use.
        """
        assert not self._is_in_use, 'RenderTarget already in use'
        self._is_in_use = True

        return self

    def mark_free(
        self
    ) -> 'RenderTarget':
        """
        Set this `RenderTarget` instance as not in use.
        """
        assert self._is_in_use, 'RenderTarget already free'
        self._is_in_use = False

        return self

    def release_gpu(
        self
    ):
        """
        Free the real GPU resources (not back to the pool).
        """
        if self._fbo:
            self._fbo.release()
            self._fbo = None

        if self.texture:
            self.texture.release()
            self.texture = None