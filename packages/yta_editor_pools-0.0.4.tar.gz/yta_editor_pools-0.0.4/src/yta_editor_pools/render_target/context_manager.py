from yta_validation.parameter import ParameterValidator
from contextlib import contextmanager


class RenderTargetContextManager:
    """
    Class to use temporary `RenderTarget` instances
    that are released automatically when used as a
    context manager.
    """

    def __init__(
        self,
        render_target_provider: 'RenderTargetProvider'
    ):
        ParameterValidator.validate_mandatory_instance_of('render_target_provider', render_target_provider, 'RenderTargetProvider')

        self.render_target_provider: 'RenderTargetProvider' = render_target_provider
        """
        The `RenderTargetProvider` instance to be able to acquire
        and release `RenderTarget` instances.
        """

    @contextmanager
    def acquire(
        self,
        width: int,
        height: int,
        number_of_components: int,
        dtype: str
    ):
        """
        Acquire a temporary `RenderTarget` instance from
        the pool that will be used and then inmediately
        released back to the pool.

        Use within a context:
        - `with instance.acquire(...) as render_target:`
        """
        with self.acquire_n(
            number_of_render_targets = 1,
            width = width,
            height = height,
            number_of_components = number_of_components,
            dtype = dtype
        ) as render_targets:
            yield render_targets[0]

    @contextmanager
    def ping_pong(
        self,
        width: int,
        height: int,
        number_of_components: int,
        dtype: str
    ):
        """
        Acquire 2 `RenderTarget` instances from the pool,
        yielded as a tuple, that will be used and then
        inmediately released back to the pool.

        Use within a context:
        - `with instance.ping_pong(...) as (rt1, rt2):`
        """
        with self.acquire_n(
            number_of_render_targets = 2,
            width = width,
            height = height,
            number_of_components = number_of_components,
            dtype = dtype
        ) as render_targets:
            yield (render_targets[0], render_targets[1])

    @contextmanager
    def acquire_n(
        self,
        number_of_render_targets: int,
        width: int,
        height: int,
        number_of_components: int,
        dtype: str
    ):
        """
        Acquire `number_of_render_targets` `RenderTarget` instances
        from the pool, yielded as an array, that will be used and
        then inmediately released back to the pool.

        Use within a context:
        - `with instance.acquire_n(...) as render_targets:`
        """
        render_targets = [
            self.render_target_provider.acquire(
                width = width,
                height = height,
                number_of_components = number_of_components,
                dtype = dtype
            )
            for _ in range(number_of_render_targets)
        ]

        try:
            yield render_targets
        finally:
            for render_target in render_targets:
                self.render_target_provider.release(render_target)