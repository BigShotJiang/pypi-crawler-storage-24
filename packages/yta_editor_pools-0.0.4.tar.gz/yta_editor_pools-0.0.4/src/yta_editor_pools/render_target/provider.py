from yta_editor_pools.render_target.pool import RenderTargetPool
from yta_validation.parameter import ParameterValidator

import moderngl


class RenderTargetProvider:
    """
    Class to provide `RenderTarget` instances by using
    a pool internally that is unique for the context
    provided.
    """

    _instances: dict[int, 'RenderTargetProvider'] = {}

    @classmethod
    def get(
        cls,
        opengl_context: moderngl.Context
    ) -> 'RenderTargetProvider':
        """
        Get the singleton instance for the specific
        `opengl_context` provided as parameter.
        """
        key = id(opengl_context)
        if key not in cls._instances:
            cls._instances[key] = cls(opengl_context)

        return cls._instances[key]

    def __init__(
        self,
        moderngl_context: 'moderngl.Context'
    ):
        ParameterValidator.validate_mandatory_instance_of('moderngl_context', moderngl_context, 'Context')
        
        self._pool: RenderTargetPool = RenderTargetPool(moderngl_context)
        """
        *For internal use only*

        The pool of `RenderTarget` instances.
        """

    def acquire(
        self,
        width: int = 1920,
        height: int = 1080,
        number_of_components: int = 4,
        dtype: str = 'f1'
    ) -> 'RenderTarget':
        """
        Get a `RenderTarget` instance with the given `width`,
        `height`, `number_of_components` and `dtype` from the
        pool, that will mark it as in use.
        """
        return self._pool.acquire(
            width = width,
            height = height,
            number_of_components = number_of_components,
            dtype = dtype
        )
    
    def acquire_like(
        self,
        render_target: 'RenderTarget'
    ) -> 'RenderTarget':
        """
        Get the `RenderTarget` instance with the same
        properties than the `render_target` provided as
        parameter.
        """
        return self._pool.acquire_like(
            render_target = render_target
        )
    
    def release(
        self,
        render_target: 'RenderTarget'
    ):
        """
        Release the `render_target` provided, making it
        available again through the pool and marking it
        as free.
        """
        self._pool.release(render_target)