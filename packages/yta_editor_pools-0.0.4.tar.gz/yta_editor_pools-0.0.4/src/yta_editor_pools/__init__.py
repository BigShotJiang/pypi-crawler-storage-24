"""
Library to include the pools we need to operate
properly, being able to avoid recreating
expensive objects.
"""