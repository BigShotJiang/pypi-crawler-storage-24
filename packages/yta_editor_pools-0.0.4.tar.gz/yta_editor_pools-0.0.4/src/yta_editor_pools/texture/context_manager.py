from yta_validation.parameter import ParameterValidator
from contextlib import contextmanager


class TextureContextManager:
    """
    Class to use temporary `moderngl.Texture`
    instances that are released automatically when
    used as a context manager.
    """

    def __init__(
        self,
        texture_provider: 'TextureProvider'
    ):
        ParameterValidator.validate_mandatory_instance_of('texture_provider', texture_provider, 'TextureProvider')

        self.texture_provider: 'TextureProvider' = texture_provider
        """
        The `TextureProvider` instance to be able to acquire
        and release `moderngl.Texture` instances.
        """

    @contextmanager
    def acquire(
        self,
        width: int,
        height: int,
        number_of_components: int,
        dtype: str
    ):
        """
        Acquire a temporary `moderngl.Texture` instance from
        the pool that will be used and then inmediately
        released back to the pool.

        Use within a context:
        - `with instance.acquire(...) as texture:`
        """
        with self.acquire_n(
            number_of_textures = 1,
            width = width,
            height = height,
            number_of_components = number_of_components,
            dtype = dtype
        ) as textures:
            yield textures[0]

    @contextmanager
    def ping_pong(
        self,
        width: int,
        height: int,
        number_of_components: int,
        dtype: str
    ):
        """
        Acquire 2 `moderngl.Texture` instances from the
        pool, yielded as a tuple, that will be used and
        then inmediately released back to the pool.

        Use within a context:
        - `with instance.ping_pong(...) as (tex1, tex2):`
        """
        with self.acquire_n(
            number_of_textures = 2,
            width = width,
            height = height,
            number_of_components = number_of_components,
            dtype = dtype
        ) as textures:
            yield (textures[0], textures[1])

    @contextmanager
    def acquire_n(
        self,
        number_of_textures: int,
        width: int,
        height: int,
        number_of_components: int,
        dtype: str
    ):
        """
        Acquire `number_of_textures` `moderngl.Texture` instances
        from the pool, yielded as an array, that will be used and
        then inmediately released back to the pool.

        Use within a context:
        - `with instance.acquire_n(...) as textures:`
        """
        textures = [
            self.texture_provider.acquire(
                width = width,
                height = height,
                number_of_components = number_of_components,
                dtype = dtype
            )
            for _ in range(number_of_textures)
        ]

        try:
            yield textures
        finally:
            for texture in textures:
                self.texture_provider.release(texture)