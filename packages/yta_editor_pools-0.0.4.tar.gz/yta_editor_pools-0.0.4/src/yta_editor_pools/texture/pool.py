from yta_editor_pools.texture.utils import get_texture_key
from collections import defaultdict

import moderngl


class TexturePool:
    """
    A pool of `TexturePool` instances.

    These instances will be used to directly write
    information on them and use, most of the times,
    for CPU to GPU uploading.
    """

    def __init__(
        self,
        context: moderngl.Context
    ):
        self.context: moderngl.Context = context
        """
        The `moderngl` context we need to work with.
        """
        self.pool = defaultdict(list)
        """
        The internal pool to store the `moderngl.Texture`
        instances.
        """

    def acquire(
        self,
        width: int = 1920,
        height: int = 1080,
        number_of_components: int = 4,
        dtype: str = 'f1'
    ) -> moderngl.Texture:
        """
        Get a `moderngl.Texture` from the pool with the
        given parameters, or create a new one if non
        existing and mark in use.
        """
        key = get_texture_key(
            width = width,
            height = height,
            number_of_components = number_of_components,
            dtype = dtype
        )

        return (
            # Obtained from pool
            self.pool[key].pop()
            if self.pool[key] else
            # Create new one
            self.context.texture(
                (width, height),
                components = number_of_components,
                dtype = dtype
            )
        )
    
    def acquire_like(
        self,
        texture: moderngl.Texture
    ) -> moderngl.Texture:
        """
        Get a `moderngl.Texture` from the pool with the same
        parameters than the `texture` provided, or
        create a new one if non existing and mark in use.
        """
        return self.acquire(
            width = texture.width,
            height = texture.height,
            number_of_components = texture.components,
            dtype = texture.dtype
        )

    def release(
        self,
        texture: moderngl.Texture
    ) -> None:
        """
        Mark the `texture` provided as free and return
        it to the pool.
        """
        key = get_texture_key(
            width = texture.width,
            height = texture.height,
            number_of_components = texture.components,
            dtype = texture.dtype
        )

        self.pool[key].append(texture)