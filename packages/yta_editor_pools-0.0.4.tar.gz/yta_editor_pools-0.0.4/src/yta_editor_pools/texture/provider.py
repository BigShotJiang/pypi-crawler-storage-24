from yta_editor_pools.texture.pool import TexturePool
from yta_validation.parameter import ParameterValidator

import moderngl


class TextureProvider:
    """
    Class to provide `moderngl.Texture` instances by
    using a pool internally that is unique for the
    context provided.
    """

    _instances: dict[int, 'TextureProvider'] = {}

    @classmethod
    def get(
        cls,
        opengl_context: moderngl.Context
    ) -> 'TextureProvider':
        """
        Get the singleton instance for the specific
        `opengl_context` provided as parameter.
        """
        key = id(opengl_context)
        if key not in cls._instances:
            cls._instances[key] = cls(opengl_context)

        return cls._instances[key]

    def __init__(
        self,
        moderngl_context: 'moderngl.Context'
    ):
        ParameterValidator.validate_mandatory_instance_of('moderngl_context', moderngl_context, 'Context')
        
        self._pool: TexturePool = TexturePool(moderngl_context)
        """
        *For internal use only*

        The pool of `moderngl.Texture` instances.
        """

    def acquire(
        self,
        width: int = 1920,
        height: int = 1080,
        number_of_components: int = 4,
        dtype: str = 'f1'
    ) -> moderngl.Texture:
        """
        Get a `moderngl.Texture` instance with the given `width`,
        `height`, `number_of_components` and `dtype` from the
        pool.
        """
        return self._pool.acquire(
            width = width,
            height = height,
            number_of_components = number_of_components,
            dtype = dtype
        )
    
    def acquire_like(
        self,
        texture: moderngl.Texture
    ) -> moderngl.Texture:
        """
        Get the `moderngl.Texture` instance with the same
        properties than the `texture` provided as
        parameter.
        """
        return self._pool.acquire_like(
            texture = texture
        )
    
    def release(
        self,
        texture: 'moderngl.Texture'
    ):
        """
        Release the `texture` provided, making it available
        again through the pool.
        """
        self._pool.release(texture)