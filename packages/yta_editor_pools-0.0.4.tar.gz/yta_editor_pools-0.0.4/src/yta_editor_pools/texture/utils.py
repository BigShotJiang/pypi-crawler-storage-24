def get_texture_key(
    width: int = 1920,
    height: int = 1080,
    number_of_components: int = 4,
    dtype: str = 'f1'
) -> tuple[int, int, int, str]:
    """
    *For internal use only*

    Get the key for the texture with the provided
    specifications.
    """
    return (width, height, number_of_components, dtype)

def get_texture_key_from_texture(
    texture: 'moderngl.Texture'
) -> tuple[int, int, int, str]:
    """
    *For internal use only*

    Get the key for the texture based on the data
    that the `texture` provided has.
    """
    return get_texture_key(
        width = texture.width,
        height = texture.height,
        number_of_components = texture.components,
        dtype = texture.dtype
    )