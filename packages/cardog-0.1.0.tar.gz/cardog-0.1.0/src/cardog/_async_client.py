from __future__ import annotations

from typing import Optional

from cardog._base_client import AsyncAPIClient
from cardog._constants import DEFAULT_BASE_URL, DEFAULT_MAX_RETRIES, DEFAULT_TIMEOUT
from cardog.resources import (
    AsyncChargingResource,
    AsyncComplaintsResource,
    AsyncEfficiencyResource,
    AsyncFuelResource,
    AsyncHistoryResource,
    AsyncListingsResource,
    AsyncLocationsResource,
    AsyncMarketResource,
    AsyncRecallsResource,
    AsyncResearchResource,
    AsyncSafetyResource,
    AsyncVinResource,
)


class AsyncCardog(AsyncAPIClient):
    """Asynchronous Cardog API client.

    Usage::

        import asyncio
        from cardog import AsyncCardog

        async def main():
            client = AsyncCardog(api_key="your-api-key")

            # Decode a VIN
            vehicle = await client.vin.decode("1HGCM82633A123456")

            # Search listings
            listings = await client.listings.search(makes=["Toyota"], year_min=2020)

            await client.close()

        asyncio.run(main())

    Args:
        api_key: Your Cardog API key.
        base_url: API base URL (default: https://api.cardog.io/v1).
        timeout: Request timeout in seconds (default: 30).
        max_retries: Max retry attempts for failed requests (default: 2).
    """

    vin: AsyncVinResource
    listings: AsyncListingsResource
    market: AsyncMarketResource
    recalls: AsyncRecallsResource
    charging: AsyncChargingResource
    fuel: AsyncFuelResource
    research: AsyncResearchResource
    locations: AsyncLocationsResource
    safety: AsyncSafetyResource
    efficiency: AsyncEfficiencyResource
    complaints: AsyncComplaintsResource
    history: AsyncHistoryResource

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        super().__init__(api_key, base_url=base_url, timeout=timeout, max_retries=max_retries)

        self.vin = AsyncVinResource(self)
        self.listings = AsyncListingsResource(self)
        self.market = AsyncMarketResource(self)
        self.recalls = AsyncRecallsResource(self)
        self.charging = AsyncChargingResource(self)
        self.fuel = AsyncFuelResource(self)
        self.research = AsyncResearchResource(self)
        self.locations = AsyncLocationsResource(self)
        self.safety = AsyncSafetyResource(self)
        self.efficiency = AsyncEfficiencyResource(self)
        self.complaints = AsyncComplaintsResource(self)
        self.history = AsyncHistoryResource(self)
