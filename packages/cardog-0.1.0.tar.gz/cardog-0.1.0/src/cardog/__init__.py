"""Cardog - Official Python SDK for the Cardog API.

Usage::

    from cardog import Cardog

    client = Cardog(api_key="your-api-key")

    # Decode a VIN
    vehicle = client.vin.decode("1HGCM82633A123456")

    # Search listings
    results = client.listings.search(makes=["Toyota"], year_min=2020, price_max=30000)

    # Market analysis
    overview = client.market.overview("Honda", "Civic", 2022)

For async usage::

    from cardog import AsyncCardog

    client = AsyncCardog(api_key="your-api-key")
    vehicle = await client.vin.decode("1HGCM82633A123456")
"""

from cardog._async_client import AsyncCardog
from cardog._client import Cardog
from cardog._constants import DEFAULT_BASE_URL
from cardog._exceptions import (
    APIError,
    AuthenticationError,
    CardogError,
    ConnectionError,
    NotFoundError,
    PermissionError,
    RateLimitError,
    ServerError,
    TimeoutError,
)

__version__ = "0.1.0"

__all__ = [
    "Cardog",
    "AsyncCardog",
    "DEFAULT_BASE_URL",
    # Exceptions
    "CardogError",
    "APIError",
    "AuthenticationError",
    "PermissionError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "ConnectionError",
    "TimeoutError",
]
