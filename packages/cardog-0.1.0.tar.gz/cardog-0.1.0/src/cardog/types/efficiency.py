from __future__ import annotations

from typing import Any, List, Optional

from cardog.types.common import CardogModel


class EfficiencyDetail(CardogModel):
    """A fuel economy / efficiency record."""

    id: int
    source: str
    source_id: str
    year: int
    make: str
    model: str
    variant: Optional[str] = None
    powertrain_type: str
    fuel_type: str
    transmission: Optional[str] = None
    drive_type: Optional[str] = None
    engine_displacement_cc: Optional[float] = None
    engine_power_kw: Optional[float] = None
    cylinders: Optional[int] = None
    combined_l_per_100km: Optional[float] = None
    city_l_per_100km: Optional[float] = None
    highway_l_per_100km: Optional[float] = None
    combined_kwh_per_100km: Optional[float] = None
    city_kwh_per_100km: Optional[float] = None
    highway_kwh_per_100km: Optional[float] = None
    co2_grams_per_km: Optional[float] = None
    electric_range_km: Optional[float] = None
    total_range_km: Optional[float] = None
    mass_kg: Optional[float] = None
    wheelbase_mm: Optional[float] = None
    test_cycle: str


class EfficiencyStats(CardogModel):
    """Aggregate efficiency statistics."""

    total_records: int
    by_source: Optional[List[dict[str, Any]]] = None
    by_powertrain: Optional[List[dict[str, Any]]] = None
    by_test_cycle: Optional[List[dict[str, Any]]] = None
    year_range: Optional[dict[str, int]] = None
    top_makes: Optional[List[dict[str, Any]]] = None


__all__ = [
    "EfficiencyDetail",
    "EfficiencyStats",
]
