from __future__ import annotations

from typing import Any, List, Optional

from cardog.types.common import CardogModel


class SafetyDetail(CardogModel):
    """NHTSA safety rating for a vehicle."""

    id: int
    make: str
    model: str
    model_year: Optional[int] = None
    body_style: Optional[str] = None
    vehicle_class: Optional[str] = None
    overall_stars: Optional[str] = None
    frontal_driver_stars: Optional[str] = None
    frontal_passenger_stars: Optional[str] = None
    overall_frontal_stars: Optional[str] = None
    side_driver_stars: Optional[str] = None
    side_passenger_stars: Optional[str] = None
    overall_side_stars: Optional[str] = None
    side_pole_stars: Optional[str] = None
    rollover_stars: Optional[str] = None
    rollover_possibility: Optional[float] = None
    front_collision_warning: Optional[str] = None
    lane_departure_warning: Optional[str] = None
    crash_imminent_brake: Optional[str] = None
    blind_spot_detection: Optional[str] = None
    backup_camera: Optional[str] = None
    abs: Optional[str] = None
    nhtsa_esc: Optional[str] = None
    head_side_airbag: Optional[str] = None
    torso_side_airbag: Optional[str] = None
    provider: str = "NHTSA"


class SafetyAdvancedFeatures(CardogModel):
    front_collision_warning: int = 0
    lane_departure_warning: int = 0
    crash_imminent_brake: int = 0
    blind_spot_detection: int = 0
    backup_camera: int = 0


class SafetyStats(CardogModel):
    """Aggregate safety statistics."""

    total_reviews: int
    reviews_with_overall_rating: int
    top_makes: Optional[List[dict[str, Any]]] = None
    top_vehicle_classes: Optional[List[dict[str, Any]]] = None
    rating_distribution: Optional[List[dict[str, Any]]] = None
    advanced_safety_features: Optional[SafetyAdvancedFeatures] = None


__all__ = [
    "SafetyDetail",
    "SafetyStats",
    "SafetyAdvancedFeatures",
]
