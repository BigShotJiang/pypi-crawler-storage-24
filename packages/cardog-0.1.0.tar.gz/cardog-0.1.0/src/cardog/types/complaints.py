from __future__ import annotations

from typing import Any, List, Optional

from cardog.types.common import CardogModel


class Complaint(CardogModel):
    """An NHTSA complaint record."""

    id: int
    nhtsa_id: Optional[str] = None
    make: str
    model: str
    model_year: Optional[int] = None
    component: Optional[str] = None
    summary: Optional[str] = None
    consequence: Optional[str] = None
    date_of_incident: Optional[str] = None
    date_complaint_filed: Optional[str] = None
    crash: Optional[bool] = None
    fire: Optional[bool] = None
    injuries: Optional[int] = None
    deaths: Optional[int] = None
    state: Optional[str] = None
    odometer: Optional[float] = None


class ComplaintStats(CardogModel):
    """Aggregate complaint statistics."""

    total_complaints: Optional[int] = None
    top_makes: Optional[List[dict[str, Any]]] = None
    top_components: Optional[List[dict[str, Any]]] = None
    top_states: Optional[List[dict[str, Any]]] = None


__all__ = [
    "Complaint",
    "ComplaintStats",
]
