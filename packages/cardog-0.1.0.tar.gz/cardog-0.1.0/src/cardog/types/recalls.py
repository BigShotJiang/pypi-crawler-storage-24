from __future__ import annotations

from typing import Any, List, Optional

from cardog.types.common import CardogModel


class TransportCanadaRecall(CardogModel):
    """A Transport Canada recall record."""

    id: str
    recall_number: str
    year: int
    manufacturer_recall_number: str
    category: str
    model: str
    make: str
    units_affected: int
    system_type: str
    notification_type: str
    comment: str
    date_year: int
    recall_date: str
    processed_at: Optional[str] = None
    provider: str = "Transport Canada"


class NHTSARecall(CardogModel):
    """An NHTSA recall record."""

    manufacturer: str
    nhtsa_campaign_number: str
    park_it: bool = False
    park_out_side: bool = False
    over_the_air_update: bool = False
    nhtsa_action_number: Optional[str] = None
    report_received_date: str
    component: str
    summary: str
    consequence: str
    remedy: str
    notes: str
    model_year: str
    make: str
    model: str
    provider: str = "NHTSA"


class RecallMeta(CardogModel):
    make: Optional[str] = None
    model: Optional[str] = None
    start_year: Optional[int] = None
    end_year: Optional[int] = None
    model_year: Optional[int] = None
    recall_number: Optional[str] = None
    campaign_number: Optional[str] = None
    count: int = 0


class RecallResponse(CardogModel):
    """Response from recall search endpoint."""

    success: bool
    provider: Optional[str] = None
    data: List[Any]
    meta: RecallMeta


class VinRecallVehicle(CardogModel):
    make: str
    model: str
    year: int


class VinRecallMeta(CardogModel):
    total_results: int
    providers_searched: List[str]


class VinRecallResponse(CardogModel):
    """Response from VIN recall lookup."""

    success: bool
    vin: str
    vehicle: VinRecallVehicle
    results: List[RecallResponse]
    meta: VinRecallMeta


__all__ = [
    "TransportCanadaRecall",
    "NHTSARecall",
    "RecallMeta",
    "RecallResponse",
    "VinRecallResponse",
    "VinRecallVehicle",
    "VinRecallMeta",
]
