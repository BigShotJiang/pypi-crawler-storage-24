from __future__ import annotations

from typing import Any, List, Optional

from pydantic import Field

from cardog.types.common import CardogModel


class ChargingPricing(CardogModel):
    cost_per_kwh: Optional[float] = Field(None, alias="costPerKWh")
    cost_per_minute: Optional[float] = None
    cost_per_session: Optional[float] = None
    currency: str = "USD"


class ChargingConnection(CardogModel):
    connection_type_id: Optional[int] = None
    connection_type: Optional[str] = None
    power_kw: Optional[float] = Field(None, alias="powerKW")
    current_type: Optional[str] = None
    level: Optional[int] = None
    voltage: Optional[float] = None
    amperage: Optional[float] = None
    pricing: Optional[ChargingPricing] = None


class ChargingStationAddress(CardogModel):
    address_line1: str
    address_line2: Optional[str] = None
    town: str
    state_or_province: str
    postcode: str
    country_code: str


class ChargingStationLocation(CardogModel):
    latitude: float
    longitude: float


class ChargingStation(CardogModel):
    """An EV charging station."""

    id: str
    name: str
    address: ChargingStationAddress
    location: ChargingStationLocation
    connections: List[ChargingConnection]
    status: str
    network: Optional[str] = None
    operator: Optional[str] = None
    date_created: Optional[str] = None
    date_last_verified: Optional[str] = None
    usage: Optional[str] = None
    support_phone: Optional[str] = None
    support_url: Optional[str] = None
    is_membership_required: bool = False
    is_pay_at_location: bool = False
    photos: Optional[List[str]] = None
    rating: Optional[float] = None


class ChargingLocationInfo(CardogModel):
    name: Optional[str] = None
    country_code: str
    region_code: Optional[str] = None


class ChargingSearchResponse(CardogModel):
    """Response from charging station search."""

    stations: List[ChargingStation]
    total_count: int
    location: ChargingLocationInfo


__all__ = [
    "ChargingConnection",
    "ChargingPricing",
    "ChargingStation",
    "ChargingStationAddress",
    "ChargingStationLocation",
    "ChargingLocationInfo",
    "ChargingSearchResponse",
]
