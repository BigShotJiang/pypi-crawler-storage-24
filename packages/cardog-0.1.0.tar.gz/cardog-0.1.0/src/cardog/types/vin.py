from __future__ import annotations

from typing import Any, List, Optional

from pydantic import Field

from cardog.types.common import CardogModel


class VinCheckDigit(CardogModel):
    position: int
    actual: str
    expected: Optional[str] = None
    is_valid: bool


class VinModelYear(CardogModel):
    year: int
    source: str
    confidence: float


class VinWMI(CardogModel):
    code: str
    manufacturer: str
    country: str
    vehicle_type: str
    region: str
    make: str


class VinVehicle(CardogModel):
    make: str
    model: str
    year: int
    series: Optional[str] = None
    trim: Optional[str] = None
    body_style: Optional[str] = None
    drive_type: Optional[str] = None
    engine_type: Optional[str] = None
    fuel_type: Optional[str] = None
    transmission: Optional[str] = None
    doors: Optional[str] = None
    gvwr: Optional[str] = None
    manufacturer: Optional[str] = None


class VinPlant(CardogModel):
    country: str
    city: Optional[str] = None
    manufacturer: Optional[str] = None
    code: str


class VinEngine(CardogModel):
    type: Optional[str] = None
    model: Optional[str] = None
    cylinders: Optional[str] = None
    displacement: Optional[str] = None
    fuel: Optional[str] = None
    power: Optional[str] = None


class VinPatternMatch(CardogModel):
    element: str
    code: str
    attribute_id: Optional[Any] = None
    value: Optional[str] = None
    confidence: float
    positions: List[int]
    schema_field: Optional[str] = Field(None, alias="schema")
    metadata: Optional[dict[str, Any]] = None


class VinComponents(CardogModel):
    check_digit: Optional[VinCheckDigit] = None
    model_year: Optional[VinModelYear] = None
    wmi: Optional[VinWMI] = None
    vehicle: Optional[VinVehicle] = None
    plant: Optional[VinPlant] = None
    engine: Optional[VinEngine] = None
    vds: Optional[dict[str, Any]] = None
    vis: Optional[dict[str, Any]] = None


class VinMetadata(CardogModel):
    processing_time: Optional[float] = None
    confidence: Optional[float] = None
    schema_version: Optional[str] = None
    matched_schema: Optional[str] = None
    total_patterns: Optional[int] = None


class VinDecodeResponse(CardogModel):
    """Response from VIN decode endpoint."""

    vin: Optional[str] = None
    valid: Optional[bool] = None
    components: Optional[VinComponents] = None
    errors: Optional[List[Any]] = None
    patterns: Optional[List[VinPatternMatch]] = None
    metadata: Optional[VinMetadata] = None
    variants: Optional[List[Any]] = None


class VinImageResponse(CardogModel):
    """Response from VIN image decode endpoint."""

    result: str
    success: bool


class VinBatchItem(CardogModel):
    vin: str
    valid: Optional[bool] = None
    components: Optional[VinComponents] = None
    errors: Optional[List[Any]] = None


class VinBatchResponse(CardogModel):
    """Response from VIN batch decode endpoint."""

    results: List[VinBatchItem]


__all__ = [
    "VinDecodeResponse",
    "VinImageResponse",
    "VinBatchItem",
    "VinBatchResponse",
    "VinComponents",
    "VinVehicle",
    "VinEngine",
    "VinPlant",
    "VinWMI",
    "VinModelYear",
    "VinCheckDigit",
    "VinMetadata",
    "VinPatternMatch",
]
