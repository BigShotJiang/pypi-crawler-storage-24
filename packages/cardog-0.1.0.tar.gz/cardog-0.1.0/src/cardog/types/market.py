from __future__ import annotations

from typing import Any, List, Optional

from cardog.types.common import CardogModel


class MarketOverview(CardogModel):
    """Market overview for a make/model/year cohort."""

    vehicle: str
    total_listings: int
    avg_price: float
    median_price: float
    min_price: float
    max_price: float
    q1_price: float
    q3_price: float
    avg_days_on_market: float
    avg_odometer: float


class PriceDistributionBucket(CardogModel):
    bucket_min: float
    bucket_max: float
    count: int
    percentage: float


class MarketPricing(CardogModel):
    """Price distribution for a make/model/year cohort."""

    distribution: List[PriceDistributionBucket]


class OdometerSegment(CardogModel):
    odometer_min: float
    odometer_max: float
    listings: int
    avg_price: float
    avg_odometer: float
    min_price: float
    max_price: float


class MarketOdometer(CardogModel):
    """Odometer analysis for a make/model/year cohort."""

    segments: List[OdometerSegment]


class GeographicMarket(CardogModel):
    state: str
    listings: int
    avg_price: float
    median_price: float
    avg_odometer: float
    avg_days_on_market: float
    center_lat: float
    center_lng: float


class MarketGeography(CardogModel):
    """Geographic market breakdown for a make/model/year cohort."""

    markets: List[GeographicMarket]


class TimeSeriesPoint(CardogModel):
    period: str
    new_listings: int
    avg_price: float
    avg_odometer: float
    price_change_pct: float


class MarketTrends(CardogModel):
    """Time series trends for a make/model/year cohort."""

    trends: List[TimeSeriesPoint]


class SimilarListing(CardogModel):
    id: str
    price: float
    odometer: float
    vin: str
    year: int
    make: str
    model: str
    trim: Optional[str] = None
    listing_date: Optional[str] = None
    days_on_market: float
    location: Optional[str] = None


class PriceAnalysis(CardogModel):
    count: int
    min: float
    max: float
    average: float
    median: float
    standard_dev: float
    price_distribution: Optional[List[dict[str, Any]]] = None


class PricingGuidance(CardogModel):
    suggested: float
    confidence: str


class MarketAnalysis(CardogModel):
    """Comprehensive market analysis for a VIN."""

    similar_listings: List[SimilarListing]
    price_analysis: PriceAnalysis
    market_trends: Optional[dict[str, Any]] = None
    pricing_guidance: Optional[PricingGuidance] = None


class MarketPosition(CardogModel):
    """A listing's position within the market."""

    id: str
    price: float
    odometer: float
    trim: Optional[str] = None
    daysonmarket: Optional[float] = None
    city: Optional[str] = None
    state: Optional[str] = None
    pricepercentile: Optional[float] = None
    pricevsmedian: Optional[float] = None
    pricecategory: Optional[str] = None
    marketaverage: Optional[float] = None


class PriceRange(CardogModel):
    range: str
    count: int


class MakeDistribution(CardogModel):
    make: str
    count: int


class ModelDistribution(CardogModel):
    model: str
    count: int


class DaysOnMarketByPrice(CardogModel):
    range: str
    avg_days: float


class MarketPulseOverview(CardogModel):
    total_listings: int
    avg_price: float
    median_price: float
    min_price: float
    max_price: float
    std_dev: float


class MarketPulse(CardogModel):
    """Market pulse / overview data."""

    overview: MarketPulseOverview
    price_distribution: List[PriceRange]
    make_distribution: List[MakeDistribution]
    model_distribution: Optional[dict[str, List[ModelDistribution]]] = None
    year_distribution: Optional[List[PriceRange]] = None
    days_on_market_by_price: Optional[List[DaysOnMarketByPrice]] = None


class TrimBreakdown(CardogModel):
    trim: Optional[str] = None
    listings: int
    avg_price: float
    median_price: float
    min_price: float
    max_price: float
    avg_odometer: float
    avg_days_on_market: float
    price_vs_market: float


class MarketBreakdown(CardogModel):
    """Trim-level breakdown for a make/model/year cohort."""

    vehicle: str
    total_listings: int
    overall_avg_price: float
    overall_median_price: float
    trims: List[TrimBreakdown]


class LocalMarketPricing(CardogModel):
    avg_price: float
    median_price: float
    min_price: float
    max_price: float
    q1_price: float
    q3_price: float


class MarketComparison(CardogModel):
    local_avg_price: float
    national_avg_price: float
    price_difference_percent: float
    local_listings: int
    national_listings: int


class LocalMarketResponse(CardogModel):
    """Local market data scoped to a geographic area."""

    vehicle: str
    location: Optional[dict[str, Any]] = None
    total_listings: int
    pricing: LocalMarketPricing
    comparison: MarketComparison
    price_distribution: Optional[List[PriceRange]] = None
    odometer: Optional[dict[str, Any]] = None
    days_on_market: Optional[dict[str, Any]] = None


class DemandMatrixCell(CardogModel):
    count: int
    avg_price: float
    avg_days_to_sell: float


class DemandMatrixRow(CardogModel):
    price_band: str
    price_min: float
    price_max: float
    cells: List[DemandMatrixCell]


class DemandMatrixSummary(CardogModel):
    median_price: float
    median_days_to_sell: float
    fastest_price_band: Optional[str] = None
    sweet_spot: Optional[dict[str, Any]] = None


class DemandMatrixResponse(CardogModel):
    """Price vs turn rate demand matrix."""

    vehicle: str
    total_listings: int
    total_sold: int
    turn_rate_bands: List[str]
    price_bands: List[DemandMatrixRow]
    summary: DemandMatrixSummary


class MarketTreemapItem(CardogModel):
    name: str
    count: int
    avg_price: Optional[float] = None


__all__ = [
    "MarketOverview",
    "MarketPricing",
    "PriceDistributionBucket",
    "MarketOdometer",
    "OdometerSegment",
    "MarketGeography",
    "GeographicMarket",
    "MarketTrends",
    "TimeSeriesPoint",
    "MarketAnalysis",
    "SimilarListing",
    "PriceAnalysis",
    "PricingGuidance",
    "MarketPosition",
    "MarketPulse",
    "MarketPulseOverview",
    "MarketBreakdown",
    "TrimBreakdown",
    "LocalMarketResponse",
    "LocalMarketPricing",
    "MarketComparison",
    "DemandMatrixResponse",
    "DemandMatrixRow",
    "DemandMatrixCell",
    "DemandMatrixSummary",
    "MarketTreemapItem",
]
