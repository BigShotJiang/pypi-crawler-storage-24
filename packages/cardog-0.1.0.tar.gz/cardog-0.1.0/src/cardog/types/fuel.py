from __future__ import annotations

from typing import Any, List, Optional

from cardog.types.common import CardogModel


class FuelBrand(CardogModel):
    id: str
    name: str
    type: str
    image_url: Optional[str] = None


class FuelReview(CardogModel):
    rating: float
    review: str
    nickname: str
    date: str


class FuelStationPrice(CardogModel):
    credit: Optional[float] = None
    cash: Optional[float] = None
    posted_time: Optional[str] = None
    formatted_price: Optional[str] = None
    reported_by: Optional[str] = None


class FuelStationAddress(CardogModel):
    line1: str
    line2: Optional[str] = None
    locality: str
    region: str
    postal_code: str
    country: str


class FuelStationLocation(CardogModel):
    latitude: float
    longitude: float


class FuelStation(CardogModel):
    """A fuel/gas station."""

    id: str
    name: str
    address: FuelStationAddress
    location: FuelStationLocation
    price: FuelStationPrice
    amenities: List[str]
    brands: List[FuelBrand]
    rating: Optional[float] = None
    ratings_count: int = 0
    reviews: Optional[List[FuelReview]] = None
    fuels: List[str]
    is_open: Optional[bool] = None


class FuelPriceHistory(CardogModel):
    date: str
    price: float
    formatted_price: str


class FuelLocationInfo(CardogModel):
    name: Optional[str] = None
    country_code: str
    region_code: Optional[str] = None
    location_type: Optional[str] = None
    nearby_localities: Optional[List[str]] = None


class FuelResponse(CardogModel):
    """Response from fuel price endpoint."""

    current: Optional[float] = None
    average: Optional[float] = None
    posted_time: Optional[str] = None
    unit: str
    is_metric: bool
    fuel_type: int
    fuel_name: str
    location: FuelLocationInfo
    history: List[FuelPriceHistory]
    stations: List[FuelStation]


__all__ = [
    "FuelStation",
    "FuelStationPrice",
    "FuelStationAddress",
    "FuelStationLocation",
    "FuelBrand",
    "FuelReview",
    "FuelPriceHistory",
    "FuelLocationInfo",
    "FuelResponse",
]
