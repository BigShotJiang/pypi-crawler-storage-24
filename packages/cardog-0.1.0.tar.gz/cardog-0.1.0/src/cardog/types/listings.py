from __future__ import annotations

from typing import Any, List, Optional

from cardog.types.common import (
    Address,
    CardogModel,
    Dealership,
    FacetItem,
    HistogramBucket,
    Media,
    Pagination,
    Seller,
    VehicleReport,
)


class Listing(CardogModel):
    """A vehicle listing."""

    id: str
    vin: str
    seller_id: str
    website_domain: str
    price: float
    currency: str = "USD"
    odometer: Optional[int] = None
    source_uri: str
    stock_number: Optional[str] = None
    score: float
    status: str
    media_count: int
    created_at: str
    updated_at: str
    removed_at: Optional[str] = None
    make: str
    model: str
    year: int
    trim: Optional[str] = None
    body_style: Optional[str] = None
    fuel_type: Optional[str] = None
    drive_train: Optional[str] = None
    transmission: Optional[str] = None
    engine_size: Optional[str] = None
    horsepower: Optional[str] = None
    torque: Optional[str] = None
    exterior_color: Optional[str] = None
    interior_color: Optional[str] = None
    condition: Optional[str] = None
    seller: Optional[Seller] = None
    media: Optional[List[Media]] = None
    dealership: Optional[Dealership] = None
    location: Optional[Address] = None
    report: Optional[VehicleReport] = None


class ListingFilters(CardogModel):
    ids: Optional[List[str]] = None
    makes: Optional[List[str]] = None
    models: Optional[dict[str, List[str]]] = None
    trims: Optional[List[str]] = None
    year: Optional[dict[str, int]] = None
    price: Optional[dict[str, float]] = None
    odometer: Optional[dict[str, int]] = None
    sale_types: Optional[List[str]] = None
    body_styles: Optional[List[str]] = None
    fuel_types: Optional[List[str]] = None
    exterior_colors: Optional[List[str]] = None
    interior_colors: Optional[List[str]] = None
    sellers: Optional[List[str]] = None
    created_after: Optional[str] = None
    created_before: Optional[str] = None
    updated_after: Optional[str] = None
    updated_before: Optional[str] = None


class ListingSearchResponse(CardogModel):
    """Response from listing search endpoint."""

    listings: List[Listing]
    pagination: Pagination
    sort: Optional[Any] = None
    filters: Optional[ListingFilters] = None


class ListingCountResponse(CardogModel):
    """Response from listing count endpoint."""

    count: int
    filters: Optional[ListingFilters] = None


class ModelFacet(CardogModel):
    make: str
    model: str
    count: int


class ListingFacetsResponse(CardogModel):
    """Response from listing facets endpoint."""

    makes: List[FacetItem]
    models: List[ModelFacet]
    body_styles: List[FacetItem]
    fuel_types: List[FacetItem]
    sale_types: List[FacetItem]
    exterior_colors: List[FacetItem]
    years: Optional[dict[str, int]] = None
    prices: Optional[dict[str, Any]] = None
    odometer: Optional[dict[str, Any]] = None
    total_count: int = 0
    filters: Optional[ListingFilters] = None


__all__ = [
    "Listing",
    "ListingFilters",
    "ListingSearchResponse",
    "ListingCountResponse",
    "ListingFacetsResponse",
    "ModelFacet",
]
