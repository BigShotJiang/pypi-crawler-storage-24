from __future__ import annotations

from typing import Any, List, Optional

from pydantic import BaseModel, ConfigDict


def _to_camel(name: str) -> str:
    parts = name.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


class CardogModel(BaseModel):
    """Base model for all Cardog API responses."""

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
        alias_generator=_to_camel,
    )


class Pagination(CardogModel):
    page: int
    limit: int


class Address(CardogModel):
    id: int
    street: str
    city: str
    state: str
    postal_code: str
    country: str
    latitude: str
    longitude: str
    location: Optional[dict[str, Any]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class Seller(CardogModel):
    id: str
    type: str
    name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    slug: Optional[str] = None
    address_id: Optional[int] = None
    dealership_id: Optional[str] = None
    gmb_phone: Optional[str] = None
    gmb_rating: Optional[str] = None
    gmb_review_count: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    deactivated_at: Optional[str] = None


class Dealership(CardogModel):
    id: str
    name: str
    primary_domain: str
    metadata: Optional[Any] = None
    is_verified: bool = False
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class Media(CardogModel):
    id: int
    listing_id: Optional[str] = None
    type: str
    url: str
    make: Optional[str] = None
    model: Optional[str] = None
    year: Optional[int] = None
    width: Optional[int] = None
    height: Optional[int] = None
    size_bytes: Optional[int] = None
    mime_type: Optional[str] = None
    source_uri: Optional[str] = None
    source_type: Optional[str] = None
    metadata: Optional[Any] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    removed_at: Optional[str] = None


class VehicleReport(CardogModel):
    id: str
    vin: str
    url: Optional[str] = None
    version: str
    type: str
    data: Optional[Any] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class FacetItem(CardogModel):
    value: str
    count: int


class HistogramBucket(CardogModel):
    min: float
    max: float
    count: int


__all__ = [
    "CardogModel",
    "Pagination",
    "Address",
    "Seller",
    "Dealership",
    "Media",
    "VehicleReport",
    "FacetItem",
    "HistogramBucket",
]
