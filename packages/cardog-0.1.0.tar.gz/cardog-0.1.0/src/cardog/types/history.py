from __future__ import annotations

from typing import Any, Optional

from cardog.types.common import CardogModel


class VehicleHistory(CardogModel):
    """Vehicle history report data."""

    vin: Optional[str] = None
    success: Optional[bool] = None
    data: Optional[Any] = None


__all__ = [
    "VehicleHistory",
]
