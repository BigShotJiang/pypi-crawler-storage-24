from __future__ import annotations

from typing import Any, List, Optional

from cardog.types.common import CardogModel


class ResearchVariant(CardogModel):
    """A vehicle variant from the research database."""

    id: Optional[str] = None
    make: Optional[str] = None
    model: Optional[str] = None
    year: Optional[int] = None
    trim: Optional[str] = None
    body_style: Optional[str] = None
    drive_type: Optional[str] = None
    engine_type: Optional[str] = None
    fuel_type: Optional[str] = None
    transmission: Optional[str] = None
    doors: Optional[int] = None
    msrp: Optional[float] = None
    metadata: Optional[Any] = None


class ResearchImage(CardogModel):
    url: str
    shot_type: Optional[str] = None
    category: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None


class ResearchColor(CardogModel):
    name: str
    hex: Optional[str] = None
    type: Optional[str] = None


class LineupResponse(CardogModel):
    """Response from research lineup endpoint."""

    data: List[ResearchVariant]
    page: Optional[int] = None
    limit: Optional[int] = None
    total: Optional[int] = None


__all__ = [
    "ResearchVariant",
    "ResearchImage",
    "ResearchColor",
    "LineupResponse",
]
