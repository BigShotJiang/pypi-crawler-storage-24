from __future__ import annotations

from typing import Any, List, Optional

from cardog.types.common import CardogModel


class LocationAddress(CardogModel):
    id: Optional[int] = None
    street: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    postal_code: Optional[str] = None
    country: Optional[str] = None
    latitude: Optional[str] = None
    longitude: Optional[str] = None


class LocationDealership(CardogModel):
    id: str
    name: str
    primary_domain: Optional[str] = None


class LocationResult(CardogModel):
    """A seller/dealership location."""

    id: str
    name: str
    slug: str
    type: str
    email: Optional[str] = None
    phone: Optional[str] = None
    gmb_phone: Optional[str] = None
    gmb_rating: Optional[str] = None
    gmb_review_count: Optional[int] = None
    address: Optional[LocationAddress] = None
    dealership: Optional[LocationDealership] = None
    total_active_listings: int = 0
    distance: Optional[float] = None


class LocationSearchResponse(CardogModel):
    """Response from location search endpoint."""

    results: List[LocationResult]
    meta: Optional[dict[str, Any]] = None


__all__ = [
    "LocationAddress",
    "LocationDealership",
    "LocationResult",
    "LocationSearchResponse",
]
