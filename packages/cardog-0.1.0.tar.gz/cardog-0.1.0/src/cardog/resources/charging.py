from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

from cardog.types.charging import ChargingSearchResponse, ChargingStation

if TYPE_CHECKING:
    from cardog._base_client import AsyncAPIClient, SyncAPIClient


class SyncChargingResource:
    """EV charging station search and lookup."""

    def __init__(self, client: SyncAPIClient) -> None:
        self._client = client

    def search(
        self,
        *,
        country: str = "US",
        region: Optional[str] = None,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        radius: Optional[float] = None,
        connector: Optional[List[int]] = None,
        min_power: Optional[float] = None,
        limit: Optional[int] = None,
        include_inactive: Optional[bool] = None,
        include_photos: Optional[bool] = None,
    ) -> ChargingSearchResponse:
        """Search for EV charging stations.

        Args:
            country: Country code (default "US").
            region: Region/state code.
            lat: Latitude for location search.
            lng: Longitude for location search.
            radius: Search radius in km.
            connector: Connector type IDs to filter.
            min_power: Minimum power output in kW.
            limit: Max results to return.
            include_inactive: Include non-operational stations.
            include_photos: Include station photos.
        """
        params: dict = {
            "country": country,
            "region": region,
            "lat": lat,
            "lng": lng,
            "radius": radius,
            "minPower": min_power,
            "limit": limit,
            "includeInactive": include_inactive,
            "includePhotos": include_photos,
        }
        if connector:
            params["connector"] = ",".join(str(c) for c in connector)
        return self._client._get("/charging", params=params, model=ChargingSearchResponse)

    def get(self, station_id: str) -> ChargingStation:
        """Get a charging station by ID.

        Args:
            station_id: The station ID.
        """
        data = self._client._get(f"/charging/{station_id}")
        if isinstance(data, dict) and "station" in data:
            return ChargingStation.model_validate(data["station"])
        return ChargingStation.model_validate(data)


class AsyncChargingResource:
    """EV charging station search and lookup (async)."""

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def search(
        self,
        *,
        country: str = "US",
        region: Optional[str] = None,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        radius: Optional[float] = None,
        connector: Optional[List[int]] = None,
        min_power: Optional[float] = None,
        limit: Optional[int] = None,
        include_inactive: Optional[bool] = None,
        include_photos: Optional[bool] = None,
    ) -> ChargingSearchResponse:
        """Search for EV charging stations."""
        params: dict = {
            "country": country,
            "region": region,
            "lat": lat,
            "lng": lng,
            "radius": radius,
            "minPower": min_power,
            "limit": limit,
            "includeInactive": include_inactive,
            "includePhotos": include_photos,
        }
        if connector:
            params["connector"] = ",".join(str(c) for c in connector)
        return await self._client._get(
            "/charging", params=params, model=ChargingSearchResponse
        )

    async def get(self, station_id: str) -> ChargingStation:
        """Get a charging station by ID."""
        data = await self._client._get(f"/charging/{station_id}")
        if isinstance(data, dict) and "station" in data:
            return ChargingStation.model_validate(data["station"])
        return ChargingStation.model_validate(data)
