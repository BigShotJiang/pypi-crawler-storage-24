from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from cardog.types.fuel import FuelResponse

if TYPE_CHECKING:
    from cardog._base_client import AsyncAPIClient, SyncAPIClient

# Valid fuel type strings
FUEL_TYPES = [
    "regular", "midgrade", "premium", "diesel",
    "e85", "e15", "propane", "biodiesel", "cng", "lng",
]


class SyncFuelResource:
    """Fuel price search and station lookup."""

    def __init__(self, client: SyncAPIClient) -> None:
        self._client = client

    def get(
        self,
        fuel_type: str = "regular",
        *,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        radius: Optional[float] = None,
        country: Optional[str] = None,
        region: Optional[str] = None,
        city: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> FuelResponse:
        """Get fuel prices and nearby stations.

        Args:
            fuel_type: Fuel type (regular, midgrade, premium, diesel, e85, e15,
                       propane, biodiesel, cng, lng).
            lat: Latitude for location search.
            lng: Longitude for location search.
            radius: Search radius in km.
            country: Country code (default "US").
            region: Region/state code.
            city: City name.
            limit: Max stations to return.
        """
        return self._client._get(
            f"/fuel/{fuel_type.lower()}",
            params={
                "lat": lat,
                "lng": lng,
                "radius": radius,
                "country": country,
                "region": region,
                "city": city,
                "limit": limit,
            },
            model=FuelResponse,
        )


class AsyncFuelResource:
    """Fuel price search and station lookup (async)."""

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def get(
        self,
        fuel_type: str = "regular",
        *,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        radius: Optional[float] = None,
        country: Optional[str] = None,
        region: Optional[str] = None,
        city: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> FuelResponse:
        """Get fuel prices and nearby stations."""
        return await self._client._get(
            f"/fuel/{fuel_type.lower()}",
            params={
                "lat": lat,
                "lng": lng,
                "radius": radius,
                "country": country,
                "region": region,
                "city": city,
                "limit": limit,
            },
            model=FuelResponse,
        )
