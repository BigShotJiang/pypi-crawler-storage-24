from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from cardog._base_client import AsyncAPIClient, SyncAPIClient


class SyncHistoryResource:
    """Vehicle history reports."""

    def __init__(self, client: SyncAPIClient) -> None:
        self._client = client

    def get_by_vin(self, vin: str) -> Any:
        """Get vehicle history by VIN.

        Args:
            vin: A 17-character VIN.
        """
        return self._client._get(f"/history/vin/{vin}")

    def get_by_plate(self, state: str, plate: str) -> Any:
        """Get vehicle history by license plate.

        Args:
            state: State/province code.
            plate: License plate number.
        """
        return self._client._get(f"/history/{state}/{plate}")


class AsyncHistoryResource:
    """Vehicle history reports (async)."""

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def get_by_vin(self, vin: str) -> Any:
        """Get vehicle history by VIN."""
        return await self._client._get(f"/history/vin/{vin}")

    async def get_by_plate(self, state: str, plate: str) -> Any:
        """Get vehicle history by license plate."""
        return await self._client._get(f"/history/{state}/{plate}")
