from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Optional

from cardog.types.efficiency import EfficiencyDetail, EfficiencyStats

if TYPE_CHECKING:
    from cardog._base_client import AsyncAPIClient, SyncAPIClient


class SyncEfficiencyResource:
    """EPA fuel economy and efficiency data."""

    def __init__(self, client: SyncAPIClient) -> None:
        self._client = client

    def search(
        self,
        *,
        makes: Optional[List[str]] = None,
        models: Optional[List[str]] = None,
        year_min: Optional[int] = None,
        year_max: Optional[int] = None,
        powertrain_types: Optional[List[str]] = None,
        fuel_types: Optional[List[str]] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        sort: Optional[str] = None,
        order: Optional[str] = None,
    ) -> Any:
        """Search fuel economy records."""
        params: dict[str, Any] = {}
        if makes:
            params["makes"] = ",".join(makes)
        if models:
            params["models"] = ",".join(models)
        if year_min is not None:
            params["yearMin"] = year_min
        if year_max is not None:
            params["yearMax"] = year_max
        if powertrain_types:
            params["powertrainTypes"] = ",".join(powertrain_types)
        if fuel_types:
            params["fuelTypes"] = ",".join(fuel_types)
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        if sort:
            params["sort"] = sort
        if order:
            params["order"] = order
        return self._client._get("/efficiency/search", params=params)

    def get_by_vehicle(
        self,
        make: str,
        model: str,
        year: int,
        trim: Optional[str] = None,
    ) -> Any:
        """Get efficiency data for a specific vehicle.

        Args:
            make: Vehicle make.
            model: Vehicle model.
            year: Model year.
            trim: Optional trim level.
        """
        path = f"/efficiency/{make}/{model}/{year}"
        if trim:
            path = f"{path}/{trim}"
        return self._client._get(path)

    def stats_overview(self) -> EfficiencyStats:
        """Get aggregate efficiency statistics."""
        data = self._client._get("/efficiency/stats/overview")
        inner = data.get("data", data) if isinstance(data, dict) else data
        return EfficiencyStats.model_validate(inner)


class AsyncEfficiencyResource:
    """EPA fuel economy and efficiency data (async)."""

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def search(
        self,
        *,
        makes: Optional[List[str]] = None,
        models: Optional[List[str]] = None,
        year_min: Optional[int] = None,
        year_max: Optional[int] = None,
        powertrain_types: Optional[List[str]] = None,
        fuel_types: Optional[List[str]] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        sort: Optional[str] = None,
        order: Optional[str] = None,
    ) -> Any:
        """Search fuel economy records."""
        params: dict[str, Any] = {}
        if makes:
            params["makes"] = ",".join(makes)
        if models:
            params["models"] = ",".join(models)
        if year_min is not None:
            params["yearMin"] = year_min
        if year_max is not None:
            params["yearMax"] = year_max
        if powertrain_types:
            params["powertrainTypes"] = ",".join(powertrain_types)
        if fuel_types:
            params["fuelTypes"] = ",".join(fuel_types)
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        if sort:
            params["sort"] = sort
        if order:
            params["order"] = order
        return await self._client._get("/efficiency/search", params=params)

    async def get_by_vehicle(
        self,
        make: str,
        model: str,
        year: int,
        trim: Optional[str] = None,
    ) -> Any:
        """Get efficiency data for a specific vehicle."""
        path = f"/efficiency/{make}/{model}/{year}"
        if trim:
            path = f"{path}/{trim}"
        return await self._client._get(path)

    async def stats_overview(self) -> EfficiencyStats:
        """Get aggregate efficiency statistics."""
        data = await self._client._get("/efficiency/stats/overview")
        inner = data.get("data", data) if isinstance(data, dict) else data
        return EfficiencyStats.model_validate(inner)
