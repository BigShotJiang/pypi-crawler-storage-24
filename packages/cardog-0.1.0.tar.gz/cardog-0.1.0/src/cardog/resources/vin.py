from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

from cardog.types.vin import VinBatchResponse, VinDecodeResponse, VinImageResponse

if TYPE_CHECKING:
    from cardog._base_client import AsyncAPIClient, SyncAPIClient


class SyncVinResource:
    """VIN decoding and lookup operations."""

    def __init__(self, client: SyncAPIClient) -> None:
        self._client = client

    def decode(self, vin: str) -> VinDecodeResponse:
        """Decode a VIN to get vehicle information, market data, and variant matches.

        Args:
            vin: A 17-character Vehicle Identification Number.
        """
        return self._client._get(f"/vin/{vin}", model=VinDecodeResponse)

    def corgi(self, vin: str) -> VinDecodeResponse:
        """Decode a VIN using the Corgi offline decoder only.

        Args:
            vin: A 17-character Vehicle Identification Number.
        """
        return self._client._get(f"/vin/corgi/{vin}", model=VinDecodeResponse)

    def nano(self, vin: str) -> VinDecodeResponse:
        """Lightweight VIN lookup with minimal data.

        Args:
            vin: A 17-character Vehicle Identification Number.
        """
        return self._client._get(f"/vin/nano/{vin}", model=VinDecodeResponse)

    def batch(self, vins: List[str]) -> VinBatchResponse:
        """Batch decode up to 1000 VINs at once.

        Args:
            vins: A list of VINs to decode (max 1000).
        """
        return self._client._post("/vin/batch", json={"vins": vins}, model=VinBatchResponse)

    def image(self, base64_image: str) -> VinImageResponse:
        """Decode a vehicle from an image using AI vision.

        Args:
            base64_image: Base64-encoded image data.
        """
        return self._client._post("/vin/image", json={"image": base64_image}, model=VinImageResponse)


class AsyncVinResource:
    """VIN decoding and lookup operations (async)."""

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def decode(self, vin: str) -> VinDecodeResponse:
        """Decode a VIN to get vehicle information, market data, and variant matches.

        Args:
            vin: A 17-character Vehicle Identification Number.
        """
        return await self._client._get(f"/vin/{vin}", model=VinDecodeResponse)

    async def corgi(self, vin: str) -> VinDecodeResponse:
        """Decode a VIN using the Corgi offline decoder only.

        Args:
            vin: A 17-character Vehicle Identification Number.
        """
        return await self._client._get(f"/vin/corgi/{vin}", model=VinDecodeResponse)

    async def nano(self, vin: str) -> VinDecodeResponse:
        """Lightweight VIN lookup with minimal data.

        Args:
            vin: A 17-character Vehicle Identification Number.
        """
        return await self._client._get(f"/vin/nano/{vin}", model=VinDecodeResponse)

    async def batch(self, vins: List[str]) -> VinBatchResponse:
        """Batch decode up to 1000 VINs at once.

        Args:
            vins: A list of VINs to decode (max 1000).
        """
        return await self._client._post("/vin/batch", json={"vins": vins}, model=VinBatchResponse)

    async def image(self, base64_image: str) -> VinImageResponse:
        """Decode a vehicle from an image using AI vision.

        Args:
            base64_image: Base64-encoded image data.
        """
        return await self._client._post(
            "/vin/image", json={"image": base64_image}, model=VinImageResponse
        )
