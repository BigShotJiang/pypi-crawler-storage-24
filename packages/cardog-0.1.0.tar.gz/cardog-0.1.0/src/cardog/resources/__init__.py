from cardog.resources.vin import SyncVinResource, AsyncVinResource
from cardog.resources.listings import SyncListingsResource, AsyncListingsResource
from cardog.resources.market import SyncMarketResource, AsyncMarketResource
from cardog.resources.recalls import SyncRecallsResource, AsyncRecallsResource
from cardog.resources.charging import SyncChargingResource, AsyncChargingResource
from cardog.resources.fuel import SyncFuelResource, AsyncFuelResource
from cardog.resources.research import SyncResearchResource, AsyncResearchResource
from cardog.resources.locations import SyncLocationsResource, AsyncLocationsResource
from cardog.resources.safety import SyncSafetyResource, AsyncSafetyResource
from cardog.resources.efficiency import SyncEfficiencyResource, AsyncEfficiencyResource
from cardog.resources.complaints import SyncComplaintsResource, AsyncComplaintsResource
from cardog.resources.history import SyncHistoryResource, AsyncHistoryResource

__all__ = [
    "SyncVinResource",
    "AsyncVinResource",
    "SyncListingsResource",
    "AsyncListingsResource",
    "SyncMarketResource",
    "AsyncMarketResource",
    "SyncRecallsResource",
    "AsyncRecallsResource",
    "SyncChargingResource",
    "AsyncChargingResource",
    "SyncFuelResource",
    "AsyncFuelResource",
    "SyncResearchResource",
    "AsyncResearchResource",
    "SyncLocationsResource",
    "AsyncLocationsResource",
    "SyncSafetyResource",
    "AsyncSafetyResource",
    "SyncEfficiencyResource",
    "AsyncEfficiencyResource",
    "SyncComplaintsResource",
    "AsyncComplaintsResource",
    "SyncHistoryResource",
    "AsyncHistoryResource",
]
