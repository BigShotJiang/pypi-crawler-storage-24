from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from cardog.types.locations import LocationResult, LocationSearchResponse

if TYPE_CHECKING:
    from cardog._base_client import AsyncAPIClient, SyncAPIClient


class SyncLocationsResource:
    """Seller and dealership location search."""

    def __init__(self, client: SyncAPIClient) -> None:
        self._client = client

    def search(
        self,
        *,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        radius: Optional[float] = None,
        name: Optional[str] = None,
        country: Optional[str] = None,
        seller_type: Optional[str] = None,
        website_domain: Optional[str] = None,
        has_active_listings: Optional[bool] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> LocationSearchResponse:
        """Search for sellers/dealerships.

        Args:
            lat: Latitude for location search.
            lng: Longitude for location search.
            radius: Search radius in km.
            name: Search by dealer name.
            country: Filter by country code.
            seller_type: Filter by type (individual, dealership, auction, aggregator).
            website_domain: Filter by website domain.
            has_active_listings: Only include sellers with active listings.
            limit: Max results (default 50, max 250).
            offset: Result offset for pagination.
        """
        return self._client._get(
            "/locations/search",
            params={
                "lat": lat,
                "lng": lng,
                "radius": radius,
                "name": name,
                "country": country,
                "sellerType": seller_type,
                "websiteDomain": website_domain,
                "hasActiveListings": has_active_listings,
                "limit": limit,
                "offset": offset,
            },
            model=LocationSearchResponse,
        )

    def get_by_id(self, seller_id: str) -> LocationResult:
        """Get a seller by ID."""
        return self._client._get(f"/locations/id/{seller_id}", model=LocationResult)

    def get_by_slug(self, slug: str) -> LocationResult:
        """Get a seller by URL slug."""
        return self._client._get(f"/locations/slug/{slug}", model=LocationResult)

    def get_by_name(self, name: str) -> LocationResult:
        """Get a seller by dealership name."""
        return self._client._get(f"/locations/name/{name}", model=LocationResult)


class AsyncLocationsResource:
    """Seller and dealership location search (async)."""

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def search(
        self,
        *,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        radius: Optional[float] = None,
        name: Optional[str] = None,
        country: Optional[str] = None,
        seller_type: Optional[str] = None,
        website_domain: Optional[str] = None,
        has_active_listings: Optional[bool] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> LocationSearchResponse:
        """Search for sellers/dealerships."""
        return await self._client._get(
            "/locations/search",
            params={
                "lat": lat,
                "lng": lng,
                "radius": radius,
                "name": name,
                "country": country,
                "sellerType": seller_type,
                "websiteDomain": website_domain,
                "hasActiveListings": has_active_listings,
                "limit": limit,
                "offset": offset,
            },
            model=LocationSearchResponse,
        )

    async def get_by_id(self, seller_id: str) -> LocationResult:
        """Get a seller by ID."""
        return await self._client._get(f"/locations/id/{seller_id}", model=LocationResult)

    async def get_by_slug(self, slug: str) -> LocationResult:
        """Get a seller by URL slug."""
        return await self._client._get(f"/locations/slug/{slug}", model=LocationResult)

    async def get_by_name(self, name: str) -> LocationResult:
        """Get a seller by dealership name."""
        return await self._client._get(f"/locations/name/{name}", model=LocationResult)
