from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Optional

from cardog.types.recalls import RecallResponse

if TYPE_CHECKING:
    from cardog._base_client import AsyncAPIClient, SyncAPIClient


def _build_recall_params(
    makes: Optional[List[str]] = None,
    models: Optional[List[str]] = None,
    year_min: Optional[int] = None,
    year_max: Optional[int] = None,
    limit: Optional[int] = None,
    offset: Optional[int] = None,
    sort: Optional[str] = None,
    order: Optional[str] = None,
) -> dict[str, Any]:
    params: dict[str, Any] = {}
    if makes:
        params["makes"] = ",".join(makes)
    if models:
        params["models"] = ",".join(models)
    if year_min is not None:
        params["yearMin"] = year_min
    if year_max is not None:
        params["yearMax"] = year_max
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    if sort:
        params["sort"] = sort
    if order:
        params["order"] = order
    return params


class SyncRecallsResource:
    """Vehicle recall search and lookup."""

    def __init__(self, client: SyncAPIClient) -> None:
        self._client = client

    def search(
        self,
        country: str = "us",
        *,
        makes: Optional[List[str]] = None,
        models: Optional[List[str]] = None,
        year_min: Optional[int] = None,
        year_max: Optional[int] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        sort: Optional[str] = None,
        order: Optional[str] = None,
    ) -> RecallResponse:
        """Search recalls by country and filters.

        Args:
            country: Country code ("us" or "ca").
            makes: Filter by makes.
            models: Filter by models.
            year_min: Minimum model year.
            year_max: Maximum model year.
            limit: Max results to return.
            offset: Offset for pagination.
            sort: Sort field (recall_date, year, make, model).
            order: Sort order (asc, desc).
        """
        params = _build_recall_params(
            makes=makes, models=models, year_min=year_min, year_max=year_max,
            limit=limit, offset=offset, sort=sort, order=order,
        )
        return self._client._get(
            f"/recalls/{country}/search", params=params, model=RecallResponse
        )

    def get(self, country: str, recall_id: str) -> Any:
        """Get a specific recall by ID.

        Args:
            country: Country code ("us" or "ca").
            recall_id: The recall ID or campaign number.
        """
        return self._client._get(f"/recalls/{country}/{recall_id}")


class AsyncRecallsResource:
    """Vehicle recall search and lookup (async)."""

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def search(
        self,
        country: str = "us",
        *,
        makes: Optional[List[str]] = None,
        models: Optional[List[str]] = None,
        year_min: Optional[int] = None,
        year_max: Optional[int] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        sort: Optional[str] = None,
        order: Optional[str] = None,
    ) -> RecallResponse:
        """Search recalls by country and filters."""
        params = _build_recall_params(
            makes=makes, models=models, year_min=year_min, year_max=year_max,
            limit=limit, offset=offset, sort=sort, order=order,
        )
        return await self._client._get(
            f"/recalls/{country}/search", params=params, model=RecallResponse
        )

    async def get(self, country: str, recall_id: str) -> Any:
        """Get a specific recall by ID."""
        return await self._client._get(f"/recalls/{country}/{recall_id}")
