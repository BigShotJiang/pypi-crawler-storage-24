from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Optional

from cardog.types.complaints import Complaint, ComplaintStats

if TYPE_CHECKING:
    from cardog._base_client import AsyncAPIClient, SyncAPIClient


class SyncComplaintsResource:
    """NHTSA vehicle complaints."""

    def __init__(self, client: SyncAPIClient) -> None:
        self._client = client

    def search(
        self,
        *,
        makes: Optional[List[str]] = None,
        models: Optional[List[str]] = None,
        year_min: Optional[int] = None,
        year_max: Optional[int] = None,
        components: Optional[List[str]] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> Any:
        """Search NHTSA complaints."""
        params: dict[str, Any] = {}
        if makes:
            params["makes"] = ",".join(makes)
        if models:
            params["models"] = ",".join(models)
        if year_min is not None:
            params["yearMin"] = year_min
        if year_max is not None:
            params["yearMax"] = year_max
        if components:
            params["components"] = ",".join(components)
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        return self._client._get("/complaints/search", params=params)

    def get(self, complaint_id: int) -> Complaint:
        """Get a complaint by ID."""
        return self._client._get(f"/complaints/{complaint_id}", model=Complaint)

    def stats_overview(self) -> ComplaintStats:
        """Get aggregate complaint statistics."""
        data = self._client._get("/complaints/stats/overview")
        inner = data.get("data", data) if isinstance(data, dict) else data
        return ComplaintStats.model_validate(inner)

    def stats_makes(self) -> Any:
        """Get top makes by complaint count."""
        return self._client._get("/complaints/stats/makes")

    def stats_components(self) -> Any:
        """Get top components by complaint count."""
        return self._client._get("/complaints/stats/components")


class AsyncComplaintsResource:
    """NHTSA vehicle complaints (async)."""

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def search(
        self,
        *,
        makes: Optional[List[str]] = None,
        models: Optional[List[str]] = None,
        year_min: Optional[int] = None,
        year_max: Optional[int] = None,
        components: Optional[List[str]] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> Any:
        """Search NHTSA complaints."""
        params: dict[str, Any] = {}
        if makes:
            params["makes"] = ",".join(makes)
        if models:
            params["models"] = ",".join(models)
        if year_min is not None:
            params["yearMin"] = year_min
        if year_max is not None:
            params["yearMax"] = year_max
        if components:
            params["components"] = ",".join(components)
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        return await self._client._get("/complaints/search", params=params)

    async def get(self, complaint_id: int) -> Complaint:
        """Get a complaint by ID."""
        return await self._client._get(f"/complaints/{complaint_id}", model=Complaint)

    async def stats_overview(self) -> ComplaintStats:
        """Get aggregate complaint statistics."""
        data = await self._client._get("/complaints/stats/overview")
        inner = data.get("data", data) if isinstance(data, dict) else data
        return ComplaintStats.model_validate(inner)

    async def stats_makes(self) -> Any:
        """Get top makes by complaint count."""
        return await self._client._get("/complaints/stats/makes")

    async def stats_components(self) -> Any:
        """Get top components by complaint count."""
        return await self._client._get("/complaints/stats/components")
