from __future__ import annotations

from typing import Optional

from cardog._base_client import SyncAPIClient
from cardog._constants import DEFAULT_BASE_URL, DEFAULT_MAX_RETRIES, DEFAULT_TIMEOUT
from cardog.resources import (
    SyncChargingResource,
    SyncComplaintsResource,
    SyncEfficiencyResource,
    SyncFuelResource,
    SyncHistoryResource,
    SyncListingsResource,
    SyncLocationsResource,
    SyncMarketResource,
    SyncRecallsResource,
    SyncResearchResource,
    SyncSafetyResource,
    SyncVinResource,
)


class Cardog(SyncAPIClient):
    """Synchronous Cardog API client.

    Usage::

        from cardog import Cardog

        client = Cardog(api_key="your-api-key")

        # Decode a VIN
        vehicle = client.vin.decode("1HGCM82633A123456")

        # Search listings
        listings = client.listings.search(makes=["Toyota"], year_min=2020)

        # Market overview
        overview = client.market.overview("Honda", "Civic", 2022)

    Args:
        api_key: Your Cardog API key.
        base_url: API base URL (default: https://api.cardog.io/v1).
        timeout: Request timeout in seconds (default: 30).
        max_retries: Max retry attempts for failed requests (default: 2).
    """

    vin: SyncVinResource
    listings: SyncListingsResource
    market: SyncMarketResource
    recalls: SyncRecallsResource
    charging: SyncChargingResource
    fuel: SyncFuelResource
    research: SyncResearchResource
    locations: SyncLocationsResource
    safety: SyncSafetyResource
    efficiency: SyncEfficiencyResource
    complaints: SyncComplaintsResource
    history: SyncHistoryResource

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        super().__init__(api_key, base_url=base_url, timeout=timeout, max_retries=max_retries)

        self.vin = SyncVinResource(self)
        self.listings = SyncListingsResource(self)
        self.market = SyncMarketResource(self)
        self.recalls = SyncRecallsResource(self)
        self.charging = SyncChargingResource(self)
        self.fuel = SyncFuelResource(self)
        self.research = SyncResearchResource(self)
        self.locations = SyncLocationsResource(self)
        self.safety = SyncSafetyResource(self)
        self.efficiency = SyncEfficiencyResource(self)
        self.complaints = SyncComplaintsResource(self)
        self.history = SyncHistoryResource(self)
