"""Contract tests for Efficiency resource against the live API."""

from __future__ import annotations

import pytest

from cardog import Cardog
from cardog.types.efficiency import EfficiencyStats


@pytest.mark.contract
class TestEfficiencyContracts:
    """Validate Efficiency endpoint response shapes match our Pydantic models."""

    def test_search_efficiency(self, client: Cardog):
        result = client.efficiency.search(makes=["Toyota"], limit=5)
        assert isinstance(result, (list, dict))

    def test_search_with_powertrain(self, client: Cardog):
        result = client.efficiency.search(
            makes=["Tesla"], powertrain_types=["bev"], limit=5
        )
        assert isinstance(result, (list, dict))

    def test_get_by_vehicle(self, client: Cardog):
        result = client.efficiency.get_by_vehicle("Toyota", "Camry", 2022)
        assert isinstance(result, (list, dict))

    def test_stats_overview(self, client: Cardog):
        result = client.efficiency.stats_overview()
        assert isinstance(result, EfficiencyStats)
        assert result.total_records >= 0
