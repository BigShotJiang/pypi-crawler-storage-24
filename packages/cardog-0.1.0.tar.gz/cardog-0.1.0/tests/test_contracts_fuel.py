"""Contract tests for Fuel resource against the live API."""

from __future__ import annotations

import pytest

from cardog import Cardog
from cardog.types.fuel import FuelResponse
from tests.conftest import TEST_LAT, TEST_LNG


@pytest.mark.contract
class TestFuelContracts:
    """Validate Fuel endpoint response shapes match our Pydantic models."""

    def test_get_regular_prices(self, client: Cardog):
        result = client.fuel.get("regular", lat=TEST_LAT, lng=TEST_LNG)
        assert isinstance(result, FuelResponse)
        assert result.fuel_name
        assert result.unit
        assert isinstance(result.stations, list)

    def test_get_premium_prices(self, client: Cardog):
        result = client.fuel.get("premium", lat=TEST_LAT, lng=TEST_LNG)
        assert isinstance(result, FuelResponse)

    def test_get_diesel_prices(self, client: Cardog):
        result = client.fuel.get("diesel", lat=TEST_LAT, lng=TEST_LNG)
        assert isinstance(result, FuelResponse)

    def test_fuel_response_has_location(self, client: Cardog):
        result = client.fuel.get("regular", lat=TEST_LAT, lng=TEST_LNG)
        assert result.location is not None
        assert result.location.country_code

    def test_fuel_station_fields(self, client: Cardog):
        result = client.fuel.get("regular", lat=TEST_LAT, lng=TEST_LNG, limit=5)
        if not result.stations:
            pytest.skip("No fuel stations found")
        station = result.stations[0]
        assert station.id
        assert station.name
        assert station.address is not None
        assert station.location is not None
        assert isinstance(station.fuels, list)

    def test_fuel_price_history(self, client: Cardog):
        result = client.fuel.get("regular", lat=TEST_LAT, lng=TEST_LNG)
        assert isinstance(result.history, list)
        if result.history:
            entry = result.history[0]
            assert entry.date
            assert entry.price >= 0
            assert entry.formatted_price
