"""Contract tests for Recalls resource against the live API."""

from __future__ import annotations

import pytest

from cardog import Cardog
from cardog.types.recalls import RecallResponse


@pytest.mark.contract
class TestRecallsContracts:
    """Validate Recalls endpoint response shapes match our Pydantic models."""

    def test_search_us_recalls(self, client: Cardog):
        result = client.recalls.search("us", makes=["Toyota"], limit=5)
        assert isinstance(result, RecallResponse)
        assert result.success is True
        assert isinstance(result.data, list)
        assert result.meta.count >= 0

    def test_search_ca_recalls(self, client: Cardog):
        result = client.recalls.search("ca", makes=["Toyota"], limit=5)
        assert isinstance(result, RecallResponse)
        assert result.success is True
        assert isinstance(result.data, list)

    def test_search_with_year_range(self, client: Cardog):
        result = client.recalls.search(
            "us", makes=["Honda"], year_min=2020, year_max=2023, limit=5
        )
        assert isinstance(result, RecallResponse)

    def test_search_with_pagination(self, client: Cardog):
        result = client.recalls.search("us", makes=["Ford"], limit=5, offset=0)
        assert isinstance(result, RecallResponse)
        assert len(result.data) <= 5

    def test_search_with_sort(self, client: Cardog):
        result = client.recalls.search(
            "ca", makes=["Toyota"], sort="recall_date", order="desc", limit=5
        )
        assert isinstance(result, RecallResponse)

    def test_recall_data_fields(self, client: Cardog):
        result = client.recalls.search("us", makes=["Tesla"], limit=1)
        assert isinstance(result, RecallResponse)
        if result.data:
            recall = result.data[0]
            assert isinstance(recall, dict)
            # NHTSA recalls should have these fields
            assert "make" in recall or "manufacturer" in recall
