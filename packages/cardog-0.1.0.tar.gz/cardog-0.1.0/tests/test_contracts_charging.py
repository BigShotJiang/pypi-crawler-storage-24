"""Contract tests for Charging resource against the live API."""

from __future__ import annotations

import pytest

from cardog import Cardog
from cardog.types.charging import ChargingSearchResponse, ChargingStation
from tests.conftest import TEST_LAT, TEST_LNG


@pytest.mark.contract
class TestChargingContracts:
    """Validate Charging endpoint response shapes match our Pydantic models."""

    def test_search_by_location(self, client: Cardog):
        result = client.charging.search(lat=TEST_LAT, lng=TEST_LNG, radius=10, limit=5)
        assert isinstance(result, ChargingSearchResponse)
        assert isinstance(result.stations, list)
        assert result.total_count >= 0

    def test_search_by_country(self, client: Cardog):
        result = client.charging.search(country="CA", region="ON", limit=5)
        assert isinstance(result, ChargingSearchResponse)

    def test_station_has_required_fields(self, client: Cardog):
        result = client.charging.search(lat=TEST_LAT, lng=TEST_LNG, limit=1)
        if not result.stations:
            pytest.skip("No stations found")
        station = result.stations[0]
        assert station.id
        assert station.name
        assert station.address is not None
        assert station.location is not None
        assert station.location.latitude != 0 or station.location.longitude != 0
        assert isinstance(station.connections, list)
        assert station.status

    def test_station_connections(self, client: Cardog):
        result = client.charging.search(lat=TEST_LAT, lng=TEST_LNG, limit=5)
        for station in result.stations:
            for conn in station.connections:
                assert conn.connection_type
                assert conn.power_kw >= 0
                assert conn.current_type in ("AC", "DC")

    def test_get_station_by_id(self, client: Cardog):
        # First find a station
        search = client.charging.search(lat=TEST_LAT, lng=TEST_LNG, limit=1)
        if not search.stations:
            pytest.skip("No stations found")
        station_id = search.stations[0].id

        result = client.charging.get(station_id)
        assert isinstance(result, ChargingStation)
        assert result.id == station_id
