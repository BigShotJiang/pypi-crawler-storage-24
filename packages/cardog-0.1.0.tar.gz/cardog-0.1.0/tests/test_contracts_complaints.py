"""Contract tests for Complaints resource against the live API."""

from __future__ import annotations

import pytest

from cardog import Cardog
from cardog.types.complaints import ComplaintStats


@pytest.mark.contract
class TestComplaintsContracts:
    """Validate Complaints endpoint response shapes match our Pydantic models."""

    def test_search_complaints(self, client: Cardog):
        result = client.complaints.search(makes=["Toyota"], limit=5)
        assert isinstance(result, (list, dict))

    def test_search_with_year_range(self, client: Cardog):
        result = client.complaints.search(
            makes=["Honda"], year_min=2018, year_max=2022, limit=5
        )
        assert isinstance(result, (list, dict))

    def test_stats_overview(self, client: Cardog):
        result = client.complaints.stats_overview()
        assert isinstance(result, ComplaintStats)

    def test_stats_makes(self, client: Cardog):
        result = client.complaints.stats_makes()
        assert isinstance(result, (list, dict))

    def test_stats_components(self, client: Cardog):
        result = client.complaints.stats_components()
        assert isinstance(result, (list, dict))
