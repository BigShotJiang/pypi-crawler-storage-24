from __future__ import annotations

import os

import pytest

from cardog import AsyncCardog, Cardog


def get_api_key() -> str:
    key = os.environ.get("CARDOG_API_KEY")
    if not key:
        pytest.skip("CARDOG_API_KEY not set")
    return key


@pytest.fixture(scope="session")
def api_key() -> str:
    return get_api_key()


@pytest.fixture(scope="session")
def client(api_key: str) -> Cardog:
    c = Cardog(api_key=api_key)
    yield c
    c.close()


@pytest.fixture
def async_client(api_key: str) -> AsyncCardog:
    return AsyncCardog(api_key=api_key)


# Well-known test fixtures
TEST_VIN = "5YJSA1E26MF420053"  # Tesla Model S
TEST_VIN_HONDA = "1HGCV1F34LA045661"  # Honda Civic
TEST_MAKE = "Toyota"
TEST_MODEL = "Camry"
TEST_YEAR = 2022
TEST_LAT = 43.6532  # Toronto
TEST_LNG = -79.3832


@pytest.fixture
def test_vin() -> str:
    return TEST_VIN


@pytest.fixture
def test_make() -> str:
    return TEST_MAKE


@pytest.fixture
def test_model() -> str:
    return TEST_MODEL


@pytest.fixture
def test_year() -> int:
    return TEST_YEAR
