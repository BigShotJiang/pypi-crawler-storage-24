"""Contract tests for async client to verify parity with sync client."""

from __future__ import annotations

import pytest

from cardog import AsyncCardog
from cardog.types.listings import ListingSearchResponse
from cardog.types.market import MarketOverview
from cardog.types.vin import VinDecodeResponse
from tests.conftest import TEST_LAT, TEST_LNG


@pytest.mark.contract
@pytest.mark.asyncio
class TestAsyncContracts:
    """Verify async client returns same response shapes as sync client."""

    async def test_vin_decode(self, async_client: AsyncCardog):
        result = await async_client.vin.decode("5YJSA1E26MF420053")
        assert isinstance(result, VinDecodeResponse)

    async def test_listings_search(self, async_client: AsyncCardog):
        result = await async_client.listings.search(makes=["Toyota"], limit=3)
        assert isinstance(result, ListingSearchResponse)
        assert isinstance(result.listings, list)

    async def test_market_overview(self, async_client: AsyncCardog):
        result = await async_client.market.overview("Toyota", "Camry", 2022)
        assert isinstance(result, MarketOverview)
        assert result.total_listings >= 0

    async def test_recalls_search(self, async_client: AsyncCardog):
        result = await async_client.recalls.search("us", makes=["Toyota"], limit=3)
        assert result.success is True

    async def test_charging_search(self, async_client: AsyncCardog):
        result = await async_client.charging.search(
            lat=TEST_LAT, lng=TEST_LNG, limit=3
        )
        assert isinstance(result.stations, list)

    async def test_fuel_get(self, async_client: AsyncCardog):
        result = await async_client.fuel.get(
            "regular", lat=TEST_LAT, lng=TEST_LNG
        )
        assert result.fuel_name

    async def test_locations_search(self, async_client: AsyncCardog):
        result = await async_client.locations.search(
            lat=TEST_LAT, lng=TEST_LNG, limit=3
        )
        assert isinstance(result.results, list)
