"""Contract tests for Research resource against the live API."""

from __future__ import annotations

import pytest

from cardog import Cardog


@pytest.mark.contract
class TestResearchContracts:
    """Validate Research endpoint response shapes match our Pydantic models."""

    def test_get_by_make(self, client: Cardog, test_make: str):
        result = client.research.get_by_make(test_make)
        assert isinstance(result, (list, dict))

    def test_get_by_make_model(self, client: Cardog, test_make: str, test_model: str):
        result = client.research.get_by_make_model(test_make, test_model)
        assert isinstance(result, (list, dict))

    def test_get_by_make_model_year(
        self, client: Cardog, test_make: str, test_model: str, test_year: int
    ):
        result = client.research.get_by_make_model_year(
            test_make, test_model, test_year
        )
        assert isinstance(result, (list, dict))

    def test_lineup(self, client: Cardog, test_make: str):
        result = client.research.lineup(test_make, limit=5)
        assert result is not None

    def test_colors(self, client: Cardog, test_make: str, test_model: str, test_year: int):
        result = client.research.colors(make=test_make, model=test_model, year=test_year)
        assert isinstance(result, (list, dict))
