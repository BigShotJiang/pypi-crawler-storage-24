"""Unit tests for client initialization and configuration."""

from __future__ import annotations

import pytest

from cardog import AsyncCardog, Cardog
from cardog._constants import DEFAULT_BASE_URL


class TestClientInit:
    def test_sync_client_creates_with_api_key(self):
        client = Cardog(api_key="test-key")
        assert client.api_key == "test-key"
        assert client.base_url == DEFAULT_BASE_URL
        client.close()

    def test_sync_client_custom_base_url(self):
        client = Cardog(api_key="test-key", base_url="https://custom.api.com/v1")
        assert client.base_url == "https://custom.api.com/v1"
        client.close()

    def test_sync_client_strips_trailing_slash(self):
        client = Cardog(api_key="test-key", base_url="https://api.cardog.io/v1/")
        assert client.base_url == "https://api.cardog.io/v1"
        client.close()

    def test_sync_client_has_all_resources(self):
        client = Cardog(api_key="test-key")
        assert client.vin is not None
        assert client.listings is not None
        assert client.market is not None
        assert client.recalls is not None
        assert client.charging is not None
        assert client.fuel is not None
        assert client.research is not None
        assert client.locations is not None
        assert client.safety is not None
        assert client.efficiency is not None
        assert client.complaints is not None
        assert client.history is not None
        client.close()

    def test_sync_client_context_manager(self):
        with Cardog(api_key="test-key") as client:
            assert client.api_key == "test-key"

    def test_async_client_creates_with_api_key(self):
        client = AsyncCardog(api_key="test-key")
        assert client.api_key == "test-key"
        assert client.base_url == DEFAULT_BASE_URL

    def test_async_client_has_all_resources(self):
        client = AsyncCardog(api_key="test-key")
        assert client.vin is not None
        assert client.listings is not None
        assert client.market is not None
        assert client.recalls is not None
        assert client.charging is not None
        assert client.fuel is not None
        assert client.research is not None
        assert client.locations is not None
        assert client.safety is not None
        assert client.efficiency is not None
        assert client.complaints is not None
        assert client.history is not None


class TestExceptions:
    def test_exception_hierarchy(self):
        from cardog._exceptions import (
            APIError,
            AuthenticationError,
            CardogError,
            ConnectionError,
            NotFoundError,
            PermissionError,
            RateLimitError,
            ServerError,
            TimeoutError,
        )

        assert issubclass(APIError, CardogError)
        assert issubclass(AuthenticationError, APIError)
        assert issubclass(PermissionError, APIError)
        assert issubclass(NotFoundError, APIError)
        assert issubclass(RateLimitError, APIError)
        assert issubclass(ServerError, APIError)
        assert issubclass(ConnectionError, CardogError)
        assert issubclass(TimeoutError, CardogError)

    def test_api_error_formatting(self):
        from cardog._exceptions import APIError

        err = APIError("Something went wrong", 400, "bad_request", {"detail": "test"})
        assert "[400]" in str(err)
        assert "(bad_request)" in str(err)
        assert "Something went wrong" in str(err)
        assert err.status_code == 400
        assert err.code == "bad_request"
        assert err.body == {"detail": "test"}
