"""Contract tests for VIN resource against the live API."""

from __future__ import annotations

import pytest

from cardog import Cardog
from cardog.types.vin import VinDecodeResponse


@pytest.mark.contract
class TestVinContracts:
    """Validate VIN endpoint response shapes match our Pydantic models."""

    def test_decode_returns_valid_response(self, client: Cardog, test_vin: str):
        result = client.vin.decode(test_vin)
        assert isinstance(result, VinDecodeResponse)

    def test_decode_has_vehicle_info(self, client: Cardog):
        result = client.vin.decode("5YJSA1E26MF420053")
        # Should have variants or components
        assert result.variants is not None or result.components is not None

    def test_corgi_decode(self, client: Cardog, test_vin: str):
        result = client.vin.corgi(test_vin)
        assert isinstance(result, VinDecodeResponse)
        if result.components and result.components.vehicle:
            assert result.components.vehicle.make is not None
            assert result.components.vehicle.model is not None
            assert result.components.vehicle.year is not None

    def test_nano_decode(self, client: Cardog, test_vin: str):
        result = client.vin.nano(test_vin)
        assert isinstance(result, VinDecodeResponse)

    def test_batch_decode(self, client: Cardog):
        vins = ["5YJSA1E26MF420053", "1HGCV1F34LA045661"]
        result = client.vin.batch(vins)
        assert result.results is not None
        assert len(result.results) == 2
        for item in result.results:
            assert item.vin in vins

    def test_decode_invalid_vin_format(self, client: Cardog):
        """API should handle invalid VINs gracefully."""
        from cardog._exceptions import APIError

        with pytest.raises(APIError):
            client.vin.decode("INVALID")
