"""Contract tests for Safety resource against the live API."""

from __future__ import annotations

import pytest

from cardog import Cardog
from cardog.types.safety import SafetyStats


@pytest.mark.contract
class TestSafetyContracts:
    """Validate Safety endpoint response shapes match our Pydantic models."""

    def test_search_safety_ratings(self, client: Cardog):
        result = client.safety.search(makes=["Toyota"], limit=5)
        assert isinstance(result, (list, dict))

    def test_search_with_year_filter(self, client: Cardog):
        result = client.safety.search(
            makes=["Honda"], year_min=2020, year_max=2023, limit=5
        )
        assert isinstance(result, (list, dict))

    def test_get_by_vehicle(self, client: Cardog):
        result = client.safety.get_by_vehicle("Toyota", "Camry", 2022)
        assert isinstance(result, (list, dict))

    def test_stats_overview(self, client: Cardog):
        result = client.safety.stats_overview()
        assert isinstance(result, SafetyStats)
        assert result.total_reviews >= 0
