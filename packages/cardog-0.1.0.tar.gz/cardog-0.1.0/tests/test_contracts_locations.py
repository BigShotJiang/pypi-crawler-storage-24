"""Contract tests for Locations resource against the live API."""

from __future__ import annotations

import pytest

from cardog import Cardog
from cardog.types.locations import LocationResult, LocationSearchResponse
from tests.conftest import TEST_LAT, TEST_LNG


@pytest.mark.contract
class TestLocationsContracts:
    """Validate Locations endpoint response shapes match our Pydantic models."""

    def test_search_by_location(self, client: Cardog):
        result = client.locations.search(lat=TEST_LAT, lng=TEST_LNG, radius=50, limit=5)
        assert isinstance(result, LocationSearchResponse)
        assert isinstance(result.results, list)

    def test_search_by_name(self, client: Cardog):
        result = client.locations.search(name="Auto", limit=5)
        assert isinstance(result, LocationSearchResponse)

    def test_search_with_active_listings(self, client: Cardog):
        result = client.locations.search(
            lat=TEST_LAT, lng=TEST_LNG, has_active_listings=True, limit=5
        )
        assert isinstance(result, LocationSearchResponse)
        for loc in result.results:
            assert loc.total_active_listings > 0

    def test_location_result_fields(self, client: Cardog):
        result = client.locations.search(lat=TEST_LAT, lng=TEST_LNG, limit=1)
        if not result.results:
            pytest.skip("No locations found")
        loc = result.results[0]
        assert isinstance(loc, LocationResult)
        assert loc.id
        assert loc.name
        assert loc.slug
        assert loc.type

    def test_get_by_slug(self, client: Cardog):
        # First find a location
        search = client.locations.search(
            lat=TEST_LAT, lng=TEST_LNG, has_active_listings=True, limit=1
        )
        if not search.results:
            pytest.skip("No locations found")
        slug = search.results[0].slug

        result = client.locations.get_by_slug(slug)
        assert isinstance(result, LocationResult)
        assert result.slug == slug
