"""CORE"""

from collections.abc import Callable, Iterator, Sequence
import enum
from typing import overload


def hello() -> None: ...

def subscribe_to_queries(arg0: "CORE::Client", arg1: int, arg2: int, /) -> list[PyCallbackHandler]: ...

class PyValueTypes(enum.Enum):
    INT64 = 0

    DOUBLE = 1

    BOOL = 2

    STRING_VIEW = 3

    DATE = 4

    PRIMARY_TIME = 5

INT64: PyValueTypes = PyValueTypes.INT64

DOUBLE: PyValueTypes = PyValueTypes.DOUBLE

BOOL: PyValueTypes = PyValueTypes.BOOL

STRING_VIEW: PyValueTypes = PyValueTypes.STRING_VIEW

DATE: PyValueTypes = PyValueTypes.DATE

PRIMARY_TIME: PyValueTypes = PyValueTypes.PRIMARY_TIME

class PyValue:
    pass

class PyIntValue(PyValue):
    def __init__(self, arg: int, /) -> None: ...

class PyStringValue(PyValue):
    def __init__(self, arg: str, /) -> None: ...

class PyDoubleValue(PyValue):
    def __init__(self, arg: float, /) -> None: ...

class PyBoolValue(PyValue):
    def __init__(self, arg: bool, /) -> None: ...

class PyDateValue(PyValue):
    def __init__(self, arg: int, /) -> None: ...

class PyAttributeInfo:
    def __init__(self, arg0: str, arg1: PyValueTypes, /) -> None: ...

    @property
    def name(self) -> str: ...

    @property
    def value_type(self) -> PyValueTypes: ...

class PyEvent:
    @overload
    def __init__(self, arg0: int, arg1: Sequence[PyValue], /) -> None: ...

    @overload
    def __init__(self, arg0: int, arg1: Sequence[PyValue], arg2: PyIntValue, /) -> None: ...

    def get_event_type_id(self) -> int: ...

    @property
    def variable_name(self) -> str: ...

    def get_attributes_as_list(self) -> list: ...

class PyEventInfoParsed:
    def __init__(self, arg0: str, arg1: Sequence[PyAttributeInfo], /) -> None: ...

    @property
    def name(self) -> str: ...

    @property
    def attributes(self) -> list[PyAttributeInfo]: ...

class PyEventInfo:
    def __init__(self, arg0: int, arg1: str, arg2: Sequence[PyAttributeInfo], /) -> None: ...

    @property
    def id(self) -> int: ...

    @property
    def name(self) -> str: ...

    @property
    def attributes_info(self) -> list[PyAttributeInfo]: ...

class PyStream:
    def __init__(self, arg0: int, arg1: Sequence[PyEvent], /) -> None: ...

    @property
    def id(self) -> int: ...

    @property
    def events(self) -> list[PyEvent]: ...

class PyStreamInfoParsed:
    def __init__(self, arg0: str, arg1: Sequence[PyEventInfoParsed], /) -> None: ...

    @property
    def name(self) -> str: ...

    @property
    def events_info(self) -> list[PyEventInfoParsed]: ...

class PyStreamInfo:
    def __init__(self, arg0: int, arg1: str, arg2: Sequence[PyEventInfo], /) -> None: ...

    @property
    def events_info(self) -> list[PyEventInfo]: ...

    @property
    def name(self) -> str: ...

    @property
    def id(self) -> int: ...

class PyStreamer:
    def __init__(self, arg0: str, arg1: int, /) -> None: ...

    @overload
    def send_stream(self, arg: PyStream, /) -> None: ...

    @overload
    def send_stream(self, stream_id: int, event: PyEvent) -> None:
        """Sends a single event to a stream."""

    def shutdown(self) -> None:
        """Shut down the streamer and release resources."""

    def __enter__(self) -> PyStreamer: ...

    def __exit__(self, *args) -> None: ...

class PyResultHandlerType(enum.Enum):
    OFFLINE = 0

    ONLINE = 1

    CUSTOM = 2

OFFLINE: PyResultHandlerType = PyResultHandlerType.OFFLINE

ONLINE: PyResultHandlerType = PyResultHandlerType.ONLINE

CUSTOM: PyResultHandlerType = PyResultHandlerType.CUSTOM

class PyQueryInfo:
    @property
    def result_handler_identifier(self) -> str: ...

    @property
    def result_handler_type(self) -> PyResultHandlerType: ...

    @property
    def query_string(self) -> str: ...

    @property
    def query_name(self) -> str: ...

    @property
    def active(self) -> bool: ...

    @property
    def attribute_projection_variable(self) -> dict[str, list[str]]: ...

    def get_attribute_projection_stream_event(self) -> list: ...

class PyClient:
    def __init__(self, arg0: str, arg1: int, /) -> None: ...

    def declare_stream(self, arg: str, /) -> PyStreamInfo: ...

    def declare_option(self, arg: str, /) -> None: ...

    def add_query(self, arg: str, /) -> int: ...

    def list_all_streams(self) -> list[PyStreamInfo]: ...

    def list_all_queries(self) -> list[PyQueryInfo]: ...

    def inactivate_query(self, arg: int, /) -> None: ...

    def subscribe_to_complex_event(self, callback: Callable[[PyEnumerator], None], port: int) -> None:
        """Subscribe to query results on a ZMQ PUB port with a callback."""

    def shutdown(self) -> None:
        """Stop all subscriptions and join threads."""

    def __enter__(self) -> PyClient: ...

    def __exit__(self, *args) -> None: ...

class PyComplexEvent:
    def to_string(self) -> str: ...

    @property
    def start(self) -> int: ...

    @property
    def end(self) -> int: ...

    @property
    def events(self) -> list[PyEvent]: ...

class PyCallbackHandler:
    @staticmethod
    def set_event_handler(arg: Callable[[PyEnumerator], None], /) -> None: ...

class PyQueryResultHandler:
    def __init__(self, arg: Callable[[PyEnumerator], None], /) -> None: ...

class PyEnumerator:
    @property
    def complex_events(self) -> list[PyComplexEvent]: ...

    def __iter__(self) -> Iterator[PyComplexEvent]: ...

class PyOfflineServer:
    def __init__(self) -> None: ...

    def declare_stream(self, arg: str, /) -> PyStreamInfo: ...

    def declare_option(self, arg: str, /) -> None: ...

    def add_query(self, arg: str, /) -> int: ...

    def send_event(self, arg: PyEvent, /) -> None: ...

    def send_events(self, arg: Sequence[PyEvent], /) -> None: ...

    def get_output(self) -> str: ...

class PyOnlineServer:
    def __init__(self, router_port: int = 5000, stream_listener_port: int = 5001, starting_query_port: int = 5002) -> None: ...

    @property
    def router_port(self) -> int: ...

    @property
    def stream_listener_port(self) -> int: ...

    def shutdown(self) -> None:
        """Shut down the server and release resources."""

    def __enter__(self) -> PyOnlineServer: ...

    def __exit__(self, *args) -> None: ...

class PyClientException(Exception):
    pass

class PyAttributeNameAlreadyDeclared(Exception):
    pass

class PyAttributeNotDefinedException(Exception):
    pass

class PyEventNameAlreadyDeclared(Exception):
    pass

class PyEventNotDefinedException(Exception):
    pass

class EventNotInStreamException(Exception):
    pass

class PyParsingSyntaxException(Exception):
    pass

class PyStreamNameAlreadyDeclaredException(Exception):
    pass

class PyStreamNotFoundException(Exception):
    pass

class PyWarningException(Exception):
    pass
