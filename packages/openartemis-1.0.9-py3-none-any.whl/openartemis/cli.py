"""CLI for OpenArtemis — Claude-like, user-friendly design."""

import json
import logging
import os
import random
import re
import subprocess
import sys
import textwrap
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from openartemis.config import get_permission_mode, load_config
from openartemis import theme

load_config()

# Reduce harvester log noise so Rich output stays clean
logging.getLogger("openartemis").setLevel(logging.WARNING)

import questionary
import typer
from prompt_toolkit.key_binding.key_bindings import KeyBindings as PtKeyBindings
from prompt_toolkit.key_binding.key_bindings import merge_key_bindings
from prompt_toolkit.keys import Keys
from prompt_toolkit.styles import Style as PtStyle
from rich.align import Align
from rich.console import Console

# Select prompts — cyan accent style via theme
_QUESTIONARY_SELECT_STYLE = theme.prompt_style()
_QUESTIONARY_SELECT_OPTS = theme.select_opts()


def _select_with_swapped_arrows(message: str, choices: list, default: str | None, **opts) -> str | None:
    """Run a questionary select but swap Up/Down key bindings (fixes inverted arrows on Windows/some terminals)."""
    q = questionary.select(message, choices=choices, default=default, **opts)
    kb = q.application.key_bindings
    up_handler = down_handler = None
    for b in kb.bindings:
        if b.keys == (Keys.Up,):
            up_handler = b.handler
        elif b.keys == (Keys.Down,):
            down_handler = b.handler
    if up_handler is not None and down_handler is not None:
        # Application key_bindings can be merged (read-only); prepend a swap layer so it takes precedence.
        swap_kb = PtKeyBindings()
        swap_kb.add(Keys.Up, eager=True)(down_handler)
        swap_kb.add(Keys.Down, eager=True)(up_handler)
        q.application.key_bindings = merge_key_bindings([swap_kb, kb])
    return q.ask()
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.tree import Tree

import openartemis.theme as theme

from openartemis.auth import (
    init_db,
    get_user_count,
    create_admin,
    reset_admin_password,
    get_session_user,
    create_session,
    revoke_session,
    login,
    redeem_invite_code,
    create_invite_code,
    create_chat_session,
    get_chat_sessions,
    get_chat_messages,
    search_chat_sessions,
    update_chat_session_title,
)
from openartemis.harvesters.social import SocialHarvester
from openartemis.harvesters.youtube import YouTubeHarvester
from openartemis.console_utils import chat_list_line as _chat_list_line
from openartemis.slash_commands import SLASH_REGISTRY, _register_builtins

app = typer.Typer(
    name="artemis",
    help="Artemis CLI - AI-powered research and development tool.",
    add_completion=False,
)
console = Console()

VALID_PLATFORMS = ["youtube", "tiktok", "instagram", "x"]


def _stream_wrap_width(console: Console) -> int:
    """Terminal width for stream wrapping; cap at 80 so CLI never overflows or double-wraps (Cursor/IDE)."""
    try:
        import shutil
        cols = shutil.get_terminal_size().columns
        if cols and 20 <= cols <= 80:
            return cols
        if cols and cols > 80:
            return 80
    except Exception:
        pass
    w = getattr(console.size, "width", None) or 80
    return max(20, min(80, w or 80))


def _terminal_width(console: Console) -> int:
    """Terminal width for alignment (user right, Artemis center)."""
    try:
        import shutil
        cols = shutil.get_terminal_size().columns
        if cols and cols >= 20:
            return cols
    except Exception:
        pass
    return getattr(console.size, "width", None) or 80


def _artemis_center_pad(console: Console) -> int:
    """Left padding so Artemis content sits in a central column."""
    tw = _terminal_width(console)
    content_width = min(72, _stream_wrap_width(console))
    return max(0, (tw - content_width) // 2)


def _clear_last_line(console: Console) -> None:
    """Clear the current line (e.g. after questionary) so we can draw only the You panel. No-op if not a TTY."""
    file = getattr(console, "file", sys.stdout)
    if not getattr(file, "isatty", lambda: False)():
        return
    try:
        file.write("\r\033[K")
        file.flush()
    except Exception:
        pass


def _wrap_text_for_panel(text: str, console: Console) -> str:
    """Wrap long text so Panel content does not force horizontal scroll."""
    w = min(100, _stream_wrap_width(console))
    return textwrap.fill(text, width=max(40, w - 2))


def _wrap_line_to_width(s: str, width: int) -> tuple[str, str]:
    """Split s at a word boundary so the first part has len <= width. Returns (line, remainder)."""
    if len(s) <= width:
        return s, ""
    chunk = s[: width + 1]
    last_space = chunk.rfind(" ")
    if last_space > 0:
        return s[:last_space], s[last_space + 1 :].lstrip()
    return s[:width], s[width:]


def _make_stream_callback(console: Console):
    """Return (callback, flush) for word-wrapped streamed output. Call flush() after send() returns."""
    buffer: list[str] = []

    def callback(t: str) -> None:
        buffer.append(t)
        s = "".join(buffer)
        width = _stream_wrap_width(console)
        while s:
            if "\n" in s:
                idx = s.index("\n")
                line, s = s[:idx], s[idx + 1 :]
                console.print(line)
                buffer.clear()
                buffer.append(s)
                return
            if len(s) > width:
                line, s = _wrap_line_to_width(s, width)
                console.print(line)
                buffer.clear()
                buffer.append(s)
            else:
                return

    def flush() -> None:
        remainder = "".join(buffer)
        buffer.clear()
        if not remainder:
            return
        width = _stream_wrap_width(console)
        while remainder:
            if "\n" in remainder:
                idx = remainder.index("\n")
                console.print(remainder[:idx])
                remainder = remainder[idx + 1 :].lstrip("\n")
                continue
            if len(remainder) > width:
                line, remainder = _wrap_line_to_width(remainder, width)
                console.print(line)
            else:
                console.print(remainder)
                break

    return callback, flush


# Typing indicator and smooth stream (speed tuned way up; fade minimal)
_STREAM_TYPING_INDICATOR = "\u258c"  # ▌ LEFT HALF BLOCK (single column)
_STREAM_FADE_MS = 0
_STREAM_CHAR_DELAY_MS_MIN = 3
_STREAM_CHAR_DELAY_MS_MAX = 12
_STREAM_PACE_BURST_CHARS = 25
_STREAM_PACE_BURST_MULT = 0.5
_STREAM_PACE_SENTENCE_EXTRA_MS = (15, 45)
_STREAM_PACE_CLAUSE_EXTRA_MS = (10, 30)
_STREAM_PACE_FINAL_PAUSE_MS = (10, 25)
_STREAM_FAST_CHUNK_DELAY_MS = (5, 15)


def _stream_next_unit_end(s: str) -> int:
    """Index of first break char (space, newline, or .,!?;:) or -1 if none."""
    for i, c in enumerate(s):
        if c in " \n.,!?;:":
            return i
    return -1


def _make_paced_stream_callback(console: Console, fast: bool = True, left_pad: int = 0):
    """Stream with word-boundary wrap, single typing indicator, and fast or smooth mode. left_pad keeps text in center column."""
    width = _stream_wrap_width(console)
    file = getattr(console, "file", sys.stdout)
    line_buffer = ""
    current_line_printed = ""
    indicator_visible = False
    buffer = ""
    unit_count = 0
    at_line_start = True   # streaming starts on its own line (after header)
    have_printed_newline = True

    def erase_indicator() -> None:
        nonlocal indicator_visible
        if indicator_visible:
            try:
                file.write("\b \b")
                file.flush()
            except Exception:
                pass
            indicator_visible = False

    def show_indicator() -> None:
        # Disabled: indicator often renders as multiple chars or doesn't erase in some terminals
        nonlocal indicator_visible
        indicator_visible = False

    def flush_full_lines() -> None:
        """Output newlines only; content already on screen from deltas."""
        nonlocal line_buffer, current_line_printed, at_line_start, have_printed_newline
        while len(line_buffer) > width:
            chunk = line_buffer[: width + 1]
            last_space = chunk.rfind(" ")
            if last_space > 0:
                line_buffer = line_buffer[last_space + 1 :].lstrip()
            else:
                line_buffer = line_buffer[width:]
            erase_indicator()
            console.print()
            if hasattr(file, "flush"):
                file.flush()
            current_line_printed = ""
            have_printed_newline = True
            at_line_start = True

    def output_delta_and_show_indicator() -> None:
        nonlocal current_line_printed, at_line_start
        delta = line_buffer[len(current_line_printed) :]
        if delta:
            erase_indicator()
            if at_line_start and left_pad > 0:
                console.print(" " * left_pad, end="")
                at_line_start = False
            console.print(delta, end="")
            if hasattr(file, "flush"):
                file.flush()
            current_line_printed = line_buffer
        show_indicator()

    def emit_unit(unit: str) -> None:
        nonlocal line_buffer, unit_count, have_printed_newline, at_line_start
        if "\n" in unit:
            idx = unit.index("\n")
            line_buffer += unit[: idx + 1]
            flush_full_lines()
            while "\n" in line_buffer:
                i = line_buffer.index("\n")
                erase_indicator()
                chunk = line_buffer[:i]
                line_buffer = line_buffer[i + 1 :]
                # Only print text that hasn't already been delta-printed
                unprinted = chunk[len(current_line_printed):]
                current_line_printed = ""
                have_printed_newline = True
                at_line_start = True
                if unprinted:
                    console.print(unprinted)
                else:
                    console.print()
                if hasattr(file, "flush"):
                    file.flush()
            output_delta_and_show_indicator()
            unit = unit[idx + 1 :]
            if not unit:
                return
        line_buffer += unit
        flush_full_lines()
        output_delta_and_show_indicator()
        unit_count += 1
        last = unit.strip()[-1] if unit.strip() else ""
        if last in ".!?":
            time.sleep(random.uniform(*_STREAM_PACE_SENTENCE_EXTRA_MS) / 1000.0)
        elif last in ",;:":
            time.sleep(random.uniform(*_STREAM_PACE_CLAUSE_EXTRA_MS) / 1000.0)

    def paced_callback(chunk: str) -> None:
        nonlocal buffer
        if not chunk:
            return
        buffer += chunk
        max_unit = 100
        while True:
            i = _stream_next_unit_end(buffer)
            if i < 0:
                if len(buffer) >= max_unit:
                    i = max_unit - 1
                    unit = buffer[: i + 1]
                    buffer = buffer[i + 1 :]
                else:
                    return
            else:
                unit = buffer[: i + 1]
                buffer = buffer[i + 1 :]
            emit_unit(unit)
            if fast:
                base_ms = random.uniform(*_STREAM_FAST_CHUNK_DELAY_MS)
            else:
                base_ms = random.uniform(_STREAM_CHAR_DELAY_MS_MIN, _STREAM_CHAR_DELAY_MS_MAX)
                if unit_count <= _STREAM_PACE_BURST_CHARS:
                    base_ms *= _STREAM_PACE_BURST_MULT
            base_ms = max(1, base_ms)
            time.sleep(base_ms / 1000.0)

    def paced_flush() -> None:
        nonlocal buffer, line_buffer, current_line_printed, at_line_start
        erase_indicator()
        if buffer:
            time.sleep(random.uniform(*_STREAM_PACE_FINAL_PAUSE_MS) / 1000.0)
            line_buffer += buffer
            buffer = ""
        flush_full_lines()
        if line_buffer:
            delta = line_buffer[len(current_line_printed) :]
            if delta:
                if at_line_start and left_pad > 0:
                    console.print(" " * left_pad, end="")
                console.print(delta, end="")
                if hasattr(file, "flush"):
                    file.flush()
        if hasattr(file, "flush"):
            file.flush()

    return paced_callback, paced_flush


WHISPER_MODELS = ["tiny", "base", "small", "medium", "large"]


def _welcome(chat: bool = False, model: str | None = None) -> None:
    """Print welcome banner — logo on first entry, compact header on re-entry."""
    ver = theme.get_version()
    theme.print_logo(console, ver)
    if chat:
        m = model or "Artemis-0.5"
        theme.info(console, f"model: {m}  ·  type [bold]/[/bold] for menu")
        console.print()


def _run_harvest(
    query: str,
    platforms: list[str],
    max_results: int,
    out_dir: Path,
    youtube_api_key: str | None,
    scrapingdog_api_key: str | None,
    whisper_model: str,
) -> int:
    """Run the harvest pipeline. Returns total posts harvested."""
    total = 0
    out_dir = out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    transcriptapi_key = os.environ.get("TRANSCRIPTAPI_API_KEY")
    for platform in platforms:
        if platform == "youtube":
            if not youtube_api_key and not transcriptapi_key:
                console.print(
                    "[red]YouTube requires an API key.[/red] Set [bold]YOUTUBE_API_KEY[/bold] (Google) "
                    "or [bold]TRANSCRIPTAPI_API_KEY[/bold] (TranscriptAPI.com). Skipping YouTube."
                )
                continue
            harvester = YouTubeHarvester(
                api_key=youtube_api_key,
                scrapingdog_api_key=scrapingdog_api_key,
                transcriptapi_api_key=transcriptapi_key,
            )
        else:
            harvester = SocialHarvester(platform=platform)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Harvesting [cyan]{platform}[/cyan]...", total=None)
            count = 0
            for _ in harvester.harvest(
                query=query,
                max_results=max_results,
                out_dir=out_dir,
                whisper_model=whisper_model,
            ):
                count += 1
                total += 1
            progress.update(task, description=f"[green]✓[/green] {platform}: {count} posts")

    return total


def _interactive_mode() -> None:
    """Run in interactive mode — guided prompts for non-coders."""
    _welcome()

    try:
        start_choice = _select_with_swapped_arrows(
            "Find videos:",
            choices=[
                questionary.Choice("Search for videos", value="search"),
                questionary.Choice("Back to mode selector", value="back"),
            ],
            default="search",
            **_QUESTIONARY_SELECT_OPTS,
        )
        if not start_choice or start_choice == "back":
            return

        query = questionary.text(
            "What would you like to find out?",
            default="",
            instruction="(e.g. mr beast, cooking tutorial, news clip)",
            qmark="",
        ).ask()
        if not query or not query.strip():
            theme.warn(console, "No query entered.")
            theme.info(console, "Tip: Try again with something you'd like to find out about.")
            raise typer.Exit(1)

        platform_choices = [
            questionary.Choice("YouTube", value="youtube"),
            questionary.Choice("TikTok", value="tiktok"),
            questionary.Choice("Instagram", value="instagram"),
            questionary.Choice("X (Twitter)", value="x"),
        ]
        platforms = questionary.checkbox(
            "Which platforms do you want to search?",
            choices=platform_choices,
            default=["youtube"],  # YouTube selected by default (list of values, not Choice objects)
        ).ask()
        if not platforms:
            theme.warn(console, "No platforms selected. Exiting.")
            raise typer.Exit(1)

        max_results_str = questionary.text(
            "How many results per platform?",
            default="5",
            qmark="",
        ).ask()
        try:
            max_results = int(max_results_str or "5")
        except ValueError:
            max_results = 5

        out_dir_str = questionary.path(
            "Where should we save the transcripts?",
            default="./transcripts",
        ).ask()
        out_dir = Path(out_dir_str or "./transcripts")

        youtube_api_key = os.environ.get("YOUTUBE_API_KEY")
        scrapingdog_api_key = os.environ.get("SCRAPINGDOG_API_KEY")

        if "youtube" in platforms and not youtube_api_key:
            youtube_api_key = questionary.password(
                "YouTube Data API key (get one at console.cloud.google.com):",
                qmark="",
            ).ask()
            if not youtube_api_key:
                theme.warn(console, "YouTube skipped \u2014 no API key.")
                platforms = [p for p in platforms if p != "youtube"]

        console.print()
        console.print(Panel(
            f"[bold]Query:[/bold] {query}\n"
            f"[bold]Platforms:[/bold] {', '.join(platforms)}\n"
            f"[bold]Max results:[/bold] {max_results}\n"
            f"[bold]Output:[/bold] {out_dir}",
            title="Starting harvest",
            border_style="green",
        ))
        console.print()

        total = _run_harvest(
            query=query,
            platforms=platforms,
            max_results=max_results,
            out_dir=out_dir,
            youtube_api_key=youtube_api_key or None,
            scrapingdog_api_key=scrapingdog_api_key or None,
            whisper_model="base",
        )

        console.print()
        console.print(Panel(
            f"[bold green]Done![/bold green]\n\n"
            f"Harvested [bold]{total}[/bold] posts.\n"
            f"Saved to: [cyan]{out_dir}[/cyan]",
            title="Success",
            border_style="green",
        ))
    except (KeyboardInterrupt, EOFError):
        console.print("\n[yellow]Cancelled.[/yellow]")
        raise typer.Exit(0)


def get_agent_output_dir() -> Path:
    """Agent output directory. Use OPENARTEMIS_AGENT_OUTPUT_DIR when set so status and background agent share the same dir."""
    raw = os.environ.get("OPENARTEMIS_AGENT_OUTPUT_DIR", "").strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return Path.home() / ".openartemis" / "agent_output"


BUILD_PROMPT_VARIANTS = [
    "What would you like to build?",
    "What do you want to build?",
    "Describe what you'd like to make.",
    "What's the project?",
    "What should we build?",
]


def _short_slug(request: str, max_words: int = 4, max_chars: int = 22) -> str:
    """Turn request into a short lowercase hyphenated slug (e.g. 'Make me flappy birds' -> 'make-me-flappy-birds')."""
    text = (request or "task").strip()
    words = re.sub(r"[^\w\s-]", " ", text).split()
    slug = "-".join(w.lower() for w in words[:max_words] if w)
    slug = re.sub(r"-+", "-", slug).strip("-")[:max_chars] or "task"
    return slug


def _agent_output_path(request: str) -> Path:
    """Generate output path for agent report. Uses short slug so names are readable (e.g. 2026-03-01_17-15_flappy-birds.md)."""
    slug = _short_slug(request)
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M")
    return get_agent_output_dir() / f"{ts}_{slug}.md"


def _run_agent_foreground(req: str, plan_mode: bool = False, direct: bool = False, auto_start: bool = False) -> None:
    """Run agent in foreground with Claude Code-style live progress UI."""
    _agent_preflight()
    from openartemis.agent.agent_orchestrator import run_agent_mode
    import time as _time
    import threading as _threading
    from rich.live import Live
    from rich.table import Table
    from rich.text import Text

    output_path = _agent_output_path(req)
    from openartemis.token_budget import reset_session_cost, get_session_cost
    reset_session_cost()
    _start_time = _time.time()
    _files_created: list[str] = []
    _total_lines = [0]  # Total lines written across all files
    _phase = ["Starting"]
    _stop_timer = _threading.Event()
    _activity: list[str] = []  # completed action log with checkmarks
    _current_action = [""]      # what's happening right now
    _live_ref: list[Any] = [None]  # mutable ref to Live object

    _PHASE_ORDER = ["Build", "Verify", "Fix", "Report"]

    def _permission_callback(name: str, args: dict) -> bool:
        mode = get_permission_mode()
        if mode == "auto-all":
            return True
        if mode == "deny-writes":
            return False
        if name == "write_file":
            path = args.get("path", "?")
            return questionary.confirm(f"Allow write_file to {path!r}?", default=True, qmark="").ask() is True
        if name == "run_terminal":
            cmd = (args.get("command") or "?")[:60]
            return questionary.confirm(f"Allow run_terminal: {cmd!r}?", default=True, qmark="").ask() is True
        if name == "search_replace":
            path = args.get("path", "?")
            return questionary.confirm(f"Allow search_replace in {path!r}?", default=True, qmark="").ask() is True
        return True

    def _elapsed() -> str:
        secs = int(_time.time() - _start_time)
        if secs < 60:
            return f"{secs}s"
        return f"{secs // 60}m {secs % 60}s"

    def _phase_icon(p: str) -> str:
        """Return ✓/●/◦ based on whether phase is done, active, or pending."""
        current = _phase[0]
        try:
            ci = _PHASE_ORDER.index(current) if current in _PHASE_ORDER else 0
            pi = _PHASE_ORDER.index(p) if p in _PHASE_ORDER else -1
        except ValueError:
            return "◦"
        if pi < ci:
            return "[green]✓[/green]"
        if pi == ci:
            return "[cyan]●[/cyan]"
        return "[dim]◦[/dim]"

    def _build_display() -> Table:
        """Build clean minimal agent display."""
        cost_info = get_session_cost()
        from rich.text import Text

        lines: list[str] = []

        # ── header row ──
        elapsed = _elapsed()
        file_count = len(_files_created)
        loc = _total_lines[0]
        calls = cost_info["calls"]
        cost = cost_info["estimated_cost_usd"]
        header = f"  [cyan]agent[/cyan]  [cyan]{'─' * 30}[/cyan]  {elapsed}"
        lines.append(header)
        lines.append("")

        # ── key-value stats ──
        lines.append(f"  [dim]phase[/dim]   [cyan]{_phase[0]}[/cyan]")
        action = (_current_action[0] or "").strip()
        if action:
            lines.append(f"  [dim]action[/dim]  {action[:60]}")
        lines.append(f"  [dim]files[/dim]   [cyan]{file_count}[/cyan] created  ·  [cyan]{loc}[/cyan] lines")
        lines.append(f"  [dim]calls[/dim]   [cyan]{calls}[/cyan]  ·  [cyan]~${cost:.3f}[/cyan]")

        # ── recent activity (last 6 events) ──
        if _activity:
            lines.append("")
            lines.append("  [dim]recent[/dim]")
            for entry in _activity[-6:]:
                lines.append(f"    [dim]{entry}[/dim]")

        grid = Table.grid(padding=0)
        grid.add_column()
        grid.add_row(Text.from_markup("\n".join(lines)))
        return grid

    def _refresh() -> None:
        if _live_ref[0] is not None:
            try:
                _live_ref[0].update(_build_display())
            except Exception:
                pass

    def _timer_thread_fn() -> None:
        """Background thread: refresh display every second for live timer."""
        while not _stop_timer.is_set():
            _refresh()
            _stop_timer.wait(1.0)

    def on_status(s: str) -> None:
        ts = _time.strftime("%H:%M:%S")
        sl = s.lower()
        # Phase detection from Agent OS status messages
        if "phase 1" in sl or "building" in sl:
            _phase[0] = "Build"
        elif "phase 2" in sl or "verifying" in sl:
            _phase[0] = "Verify"
        elif "phase 3" in sl or "fixing" in sl:
            _phase[0] = "Fix"
        elif "phase 4" in sl or "report" in sl:
            _phase[0] = "Report"
        elif "creating plan" in sl or "choosing stack" in sl:
            _phase[0] = "Build"

        # Track file writes and line counts
        if "writing " in sl or "created " in sl:
            fname = ""
            lines_match = ""
            if "Writing " in s:
                fname = s.split("Writing ")[-1].split("...")[0].strip()
                # Extract line count: "Writing foo.js (123 lines)..."
                if "(" in s and "lines)" in s:
                    try:
                        lines_match = s.split("(")[1].split(" lines)")[0]
                        _total_lines[0] += int(lines_match)
                    except (ValueError, IndexError):
                        pass
            elif "Created " in s:
                fname = s.split("Created ")[-1].strip()
            if fname and fname not in [f.name if hasattr(f, 'name') else f for f in _files_created]:
                # Create file object with metadata
                file_obj = type('File', (), {})()
                file_obj.name = fname
                file_obj._timestamp = time.time()
                file_obj._lines = int(lines_match) if lines_match else 0
                _files_created.append(file_obj)
                lines_info = f" ({_total_lines[0]} total lines)" if _total_lines[0] > 0 else ""
                _activity.append(f"{ts}  [green]+[/green] {fname}{lines_info}")

        # Current action display
        if "writing " in sl:
            fname = s.split("Writing ")[-1].split("...")[0].strip() if "Writing " in s else ""
            _current_action[0] = f"writing {fname}" if fname else s[:70]
        elif "running:" in sl:
            cmd = s.split("running: ")[-1][:50] if "running: " in s else s[:70]
            _current_action[0] = f"$ {cmd}"
        elif "verifying" in sl or "screenshot" in sl:
            _current_action[0] = "verifying..."
        elif "fixing" in sl:
            _current_action[0] = s[:70]
        elif "reading" in sl:
            fname = s.split("reading ")[-1].split("...")[0].strip() if "reading " in s else ""
            _current_action[0] = f"reading {fname}" if fname else s[:70]
        elif "phase " in sl:
            _current_action[0] = s[:70]
        elif "rate limited" in sl:
            _current_action[0] = "[yellow]rate limited — waiting...[/yellow]"
        elif "api call" in sl or "openai" in sl:
            _current_action[0] = "api call..."
        else:
            _current_action[0] = s[:70]

        # Add to activity log for non-trivial events
        if any(k in sl for k in ("running:", "verifying", "screenshot", "fixing", "created", "phase")):
            icon = "[dim]$[/dim]" if "running:" in sl else "[dim]>[/dim]" if "verifying" in sl else "[dim]~[/dim]"
            if "created" not in sl:
                _activity.append(f"{ts}  {icon} {s[:65]}")
        _refresh()

    try:
        mode_label = "Plan" if plan_mode else ("Agent OS" if direct else "Build")
        console.print(f"[dim]Mode: {mode_label}[/dim]\n")
        with Live(_build_display(), console=console, refresh_per_second=4) as live:
            _live_ref[0] = live
            # Start background timer thread
            timer_thread = _threading.Thread(target=_timer_thread_fn, daemon=True)
            timer_thread.start()
            report = run_agent_mode(
                req,
                on_status=on_status,
                output_path=output_path,
                plan_mode=plan_mode,
                permission_callback=_permission_callback,
                direct_build=direct,
            )
            _stop_timer.set()
            _phase[0] = "Report"
            _current_action[0] = "[green bold]Done![/green bold]"
            _refresh()
        # Final summary
        console.print()
        cost_info = get_session_cost()
        theme.rule(console)
        theme.ok(console, f"Done in {_elapsed()}  ·  {len(_files_created)} file(s)  ·  {cost_info['calls']} calls  ·  ~${cost_info['estimated_cost_usd']:.3f}")
        if _files_created:
            theme.info(console, f"files: {', '.join(_files_created[:10])}")
        console.print()
        console.print(Panel(Markdown(report or "(no output)"), title="[dim]report[/dim]", border_style="bright_black"))
        theme.info(console, f"saved to {output_path}")
        from openartemis.agent.agent_tools import get_agent_workspace
        from openartemis.oa_context import list_main_artifact_paths
        ws = get_agent_workspace()
        theme.info(console, f"workspace: {ws.resolve()}")
        for p in list_main_artifact_paths(ws):
            theme.info(console, f"main file: {p}")
        console.print()
    except Exception as e:
        _stop_timer.set()
        theme.err(console, f"Failed after {_elapsed()}: {_format_agent_error(e)}")


def _agent_preflight() -> None:
    """Run agent preflight checks; exit with clear message if required checks fail."""
    from openartemis.preflight import run_preflight
    from openartemis.config import get_plan_model, get_exec_model
    results = run_preflight("agent")
    for _mode, check_id, ok, msg in results:
        if not ok and check_id == "ANTHROPIC_API_KEY":
            theme.err(console, f"Agent preflight failed: {check_id} \u2014 {msg}")
            theme.info(console, "Set ANTHROPIC_API_KEY and run openartemis preflight agent to verify.")
            raise typer.Exit(1)
    plan_model = get_plan_model()
    exec_model = get_exec_model()
    if not (plan_model and str(plan_model).strip()) or not (exec_model and str(exec_model).strip()):
        theme.err(console, "Agent preflight failed: plan or exec model is empty. Set OPENARTEMIS_PLAN_MODEL / OPENARTEMIS_EXEC_MODEL or use defaults.")
        raise typer.Exit(1)
    return None


def _format_agent_error(e: BaseException) -> str:
    """Extract full error message for .done and report (including API response body if present)."""
    msg = str(e)
    body = None
    try:
        resp = getattr(e, "response", None)
        if resp is not None:
            json_fn = getattr(resp, "json", None)
            if callable(json_fn):
                body = json_fn()
    except Exception:
        pass
    if body is None:
        body = getattr(e, "body", None)
    if isinstance(body, dict) and "error" in body:
        err = body["error"]
        if isinstance(err, dict) and "message" in err:
            msg = err["message"]
        else:
            msg = str(body)
    return msg or repr(e)


def _run_agent_background(req: str, plan_mode: bool = False, direct: bool = False) -> None:
    """Run agent in background subprocess."""
    _agent_preflight()
    from openartemis.agent.agent_tools import get_agent_workspace
    output_path = _agent_output_path(req)
    out_dir = get_agent_output_dir()
    out_dir.mkdir(parents=True, exist_ok=True)
    # Write pending marker with start timestamp for accurate elapsed time
    import time as _t
    running_payload = json.dumps({"request": req, "started_at": _t.time()})
    (out_dir / f"{output_path.name}.running").write_text(running_payload, encoding="utf-8")
    workspace_path = get_agent_workspace().resolve()
    (out_dir / f"{output_path.name}.workspace").write_text(str(workspace_path), encoding="utf-8")
    cmd = [sys.executable, "-m", "openartemis", "agent-run", req, str(output_path)]
    if plan_mode:
        cmd.append("--plan")
    if direct:
        cmd.append("--direct")
    env = os.environ.copy()
    env["OPENARTEMIS_AGENT_WORKSPACE"] = str(workspace_path)
    if sys.platform == "win32":
        _CREATE_NO_WINDOW = 0x08000000
        subprocess.Popen(
            cmd,
            env=env,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | _CREATE_NO_WINDOW,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            cwd=os.getcwd(),
        )
    else:
        subprocess.Popen(
            cmd,
            env=env,
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            cwd=os.getcwd(),
        )
    console.print(Panel(
        f"[green]Agent started in background.[/green]\n\n"
        f"Results will be saved to:\n[cyan]{output_path}[/cyan]\n\n"
        f"Run [bold]openartemis agent-status[/bold] to check progress.",
        title="Background Task",
        border_style="green",
    ))


DECISIVE_BUILD_PLAN_PROMPT = """The user wants to build: {user_request}

Here is research about how to build it:
{research_report}

Commit to ONE stack only (e.g. "Vanilla Canvas in a single index.html", "Phaser 3 + Vite", "Pygame"). Do not list alternatives.
Output a short, concrete build plan:
1. State the chosen stack in one sentence.
2. List exact steps and the exact files to create (e.g. index.html, game.js, style.css). Use bullets or numbers.
Keep it concise and build-ready."""


def _get_decisive_build_plan(user_request: str, research_report: str) -> str:
    """One LLM call: turn research into a committed one-stack build plan with exact steps/files."""
    try:
        from openartemis.config import resolve_artemis_model, completion_tokens_kwarg, get_anthropic_client
        client = get_anthropic_client()
        if not client.api_key:
            return research_report
        model = resolve_artemis_model("artemis-1")
        resp = client.messages.create(
            model=model,
            max_tokens=2048,
            messages=[
                {"role": "user", "content": DECISIVE_BUILD_PLAN_PROMPT.format(
                    user_request=user_request,
                    research_report=research_report,
                )},
            ],
        )
        return (resp.content[0].text or "").strip() or research_report
    except Exception:
        return research_report


def _get_ai_clarifying_questions(user_request: str, workspace_context: str = "") -> list[dict]:
    """Call LLM to generate 0-3 clarifying questions with 4 choices each. When workspace_context is set, the model can return fewer or no questions. Returns [{\"question\": \"...\", \"choices\": [\"...\", ...]}, ...] or [] on failure."""
    if not (user_request or "").strip():
        return []
    try:
        from openartemis.config import resolve_artemis_model, completion_tokens_kwarg, get_anthropic_client
        client = get_anthropic_client()
        model = resolve_artemis_model("artemis-0.5")
        user_content = f"Build request: {user_request.strip()[:500]}"
        if (workspace_context or "").strip():
            user_content = f"Existing project context (use this to avoid asking redundant questions):\n{workspace_context.strip()[:800]}\n\n{user_content}"
        user_content += "\n\nReturn 0-3 short clarifying questions (0 if context already makes the request clear). Each question must have exactly 4 possible choices. Return only valid JSON, no markdown: a list of objects, each with \"question\" (string) and \"choices\" (array of exactly 4 strings). Example: [{\"question\": \"Art style?\", \"choices\": [\"Simple shapes\", \"Sprites\", \"Pixel art\", \"Minimal\"]}]"
        resp = client.messages.create(
            model=model,
            max_tokens=512,
            messages=[
                {"role": "system", "content": "You generate 0 to 3 short clarifying questions for a coding project. When the user's request and existing project context are already clear (e.g. continuing a known game like Flappy Bird), return an empty list []. Each question must have exactly 4 possible choices. Return only valid JSON, no markdown: a list of objects, each with \"question\" (string) and \"choices\" (array of exactly 4 strings)."},
                {"role": "user", "content": user_content},
            ],
        )
        content = (resp.content[0].text or "").strip()
        if content.startswith("```"):
            lines = content.split("\n")
            if lines and lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            content = "\n".join(lines)
        data = json.loads(content)
        if not isinstance(data, list):
            return []
        out = []
        for item in data:
            if not isinstance(item, dict):
                continue
            q = (item.get("question") or "").strip()
            choices = item.get("choices")
            if not q or not isinstance(choices, list) or len(choices) < 4:
                continue
            out.append({"question": q, "choices": [str(c).strip() for c in choices[:4]]})
        return out[:3]
    except Exception:
        return []


def _ask_one_question_4_plus_other(question: str, choices: list[str]) -> str:
    """Show arrow-key select with 4 choices + Other. If Other, prompt for short text. Returns selected or typed answer."""
    option_choices = [questionary.Choice(c, value=c) for c in choices]
    option_choices.append(questionary.Choice("Other", value="__other__"))
    ans = _select_with_swapped_arrows(question, option_choices, default=choices[0] if choices else None, **_QUESTIONARY_SELECT_OPTS)
    if ans == "__other__":
        other = questionary.text("Your answer (short):", qmark="").ask()
        return (other or "").strip() or "other"
    return (ans or "").strip() or (choices[0] if choices else "")


def _ask_spec_questions(user_request: str = "", workspace_path: Path | None = None) -> str:
    """Ask clarifying questions: AI-generated (4 choices + Other) when user_request is set, else fixed question sets. When workspace_path is set, loads .oa context so questions are context-aware (and may be skipped)."""
    if (user_request or "").strip():
        workspace_context = ""
        if workspace_path is not None and workspace_path.is_dir():
            try:
                from openartemis.oa_context import load_oa_summary, list_main_artifact_paths
                workspace_context = load_oa_summary(workspace_path, max_lines=50, max_chars=1200)
                artifacts = list_main_artifact_paths(workspace_path)
                if artifacts:
                    workspace_context = (workspace_context or "").strip()
                    if workspace_context:
                        workspace_context += "\n"
                    workspace_context += "Main files in folder: " + ", ".join(Path(p).name for p in artifacts[:8])
            except Exception:
                pass
        if workspace_context and len(workspace_context.strip()) > 80:
            return "Spec: Continuing existing project (context from .oa)."
        ai_questions = _get_ai_clarifying_questions(user_request, workspace_context=workspace_context)
        if ai_questions:
            parts = []
            for item in ai_questions:
                q = item.get("question", "")
                choices = item.get("choices", [])
                if q and choices:
                    ans = _ask_one_question_4_plus_other(q, choices)
                    parts.append(f"{q.strip().rstrip('?:')}: {ans}")
            if parts:
                return "Spec: " + ". ".join(parts) + "."

    set_name = random.choice(("A", "B", "C"))

    if set_name == "C":
        use_defaults = questionary.confirm(
            "Quick defaults? (simple shapes, snappy, auto-open in browser)",
            default=True,
            qmark="",
        ).ask()
        if use_defaults:
            return "Spec: Defaults (simple shapes, snappy, auto-open)."
        set_name = "A"

    if set_name == "A":
        art = questionary.select(
            random.choice(("Art style:", "Visual style:", "How should it look?")),
            choices=[
                questionary.Choice("Simple shapes (rectangles/circles)", value="simple shapes"),
                questionary.Choice("Sprites/images", value="sprites"),
            ],
            **_QUESTIONARY_SELECT_OPTS,
        ).ask() or "simple shapes"
        physics = questionary.select(
            random.choice(("Physics feel:", "How responsive should controls be?")),
            choices=[
                questionary.Choice("Floatier (slower tap response)", value="floaty"),
                questionary.Choice("Snappier (quick response)", value="snappy"),
            ],
            **_QUESTIONARY_SELECT_OPTS,
        ).ask() or "snappy"
        auto_open = questionary.confirm(
            random.choice((
                "Auto-launch local server and open in browser when done?",
                "Open in browser when done?",
            )),
            default=True,
        ).ask()
        return f"Spec: Art style: {art}. Physics: {physics}. Auto-open in browser: {'yes' if auto_open else 'no'}."

    # Set B: theme, sound, auto-open
    theme = questionary.select(
        "Theme:",
        choices=[
            questionary.Choice("Dark", value="dark"),
            questionary.Choice("Light", value="light"),
            questionary.Choice("System default", value="system"),
        ],
        **_QUESTIONARY_SELECT_OPTS,
    ).ask() or "system"
    sound = questionary.select(
        "Sound:",
        choices=[
            questionary.Choice("On", value="on"),
            questionary.Choice("Off", value="off"),
        ],
        **_QUESTIONARY_SELECT_OPTS,
    ).ask() or "on"
    auto_open = questionary.confirm(
        "Open in browser when done?",
        default=True,
        qmark="",
    ).ask()
    return f"Spec: Theme: {theme}. Sound: {sound}. Auto-open in browser: {'yes' if auto_open else 'no'}."


def _chat_title_from_task(req: str) -> str:
    """Generate a short chat title from an agent task request."""
    s = req.strip()
    for prefix in ("make me ", "build ", "create ", "make ", "build me ", "create me "):
        if s.lower().startswith(prefix):
            s = s[len(prefix):].strip()
            break
    s = s[:40].strip() or "Agent task"
    return (s[0].upper() + s[1:]) + " request" if s else "Agent task request"


def _clean_research_report(text: str) -> str:
    """Lightly clean a research report for display.

    - Strip trailing whitespace.
    - Drop exact duplicate consecutive lines (a common LM artifact).
    """
    if not text:
        return text
    lines = [ln.rstrip() for ln in text.splitlines()]
    cleaned: list[str] = []
    last = None
    for ln in lines:
        if ln == last:
            continue
        cleaned.append(ln)
        last = ln
    return "\n".join(cleaned).strip()


def _run_research_with_live(
    pipeline: Any,
    query: str,
    on_tool_call: Any = None,
    approve_phases: bool | None = None,
) -> str:
    """Run research pipeline with Live stage/progress/log display. Returns report or raises.
    If approve_phases is True (e.g. OPENARTEMIS_APPROVE_PHASES=1), runs in main thread and asks
    for confirmation after each phase (plan, gather)."""
    if approve_phases is None:
        approve_phases = os.environ.get("OPENARTEMIS_APPROVE_PHASES", "").strip().lower() in ("1", "true", "yes")
    state: dict = {
        "stage": "Planning…",
        "tasks_done": 0,
        "total_tasks": 0,
        "sources": 0,
        "log": [],
        "report": None,
        "done": False,
        "error": None,
    }

    def on_stage(s: str) -> None:
        state["stage"] = s

    def on_plan_done(n: int) -> None:
        state["total_tasks"] = n

    def on_task_done(_tid: int, sources_count: int) -> None:
        state["tasks_done"] = state.get("tasks_done", 0) + 1
        state["sources"] = sources_count

    def on_log(msg: str) -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        state["log"] = (state.get("log") or []) + [(ts, msg)]
        state["log"] = state["log"][-12:]

    def approve_before_phase(phase: str) -> bool:
        return bool(questionary.confirm(f"Phase '{phase}' done. Continue to next phase?", default=True, qmark="").ask())

    run_kw: dict[str, Any] = {
        "on_tool_call": on_tool_call,
        "on_stage": on_stage,
        "on_plan_done": on_plan_done,
        "on_task_done": on_task_done,
        "on_log": on_log,
    }
    if approve_phases:
        run_kw["approve_before_phase"] = approve_before_phase

    if approve_phases:
        try:
            raw = pipeline.run(query, **run_kw) or "(no report)"
            return _clean_research_report(raw)
        except Exception as e:
            raise
    else:
        def run_in_thread() -> None:
            try:
                state["report"] = pipeline.run(query, **run_kw)
            except Exception as e:
                state["error"] = e
            finally:
                state["done"] = True

        def render() -> Panel:
            stage = state.get("stage", "…")
            total = state.get("total_tasks") or 1
            done = state.get("tasks_done", 0)
            sources = state.get("sources", 0)
            phases = [
                "[green]Plan ✓[/green]" if stage != "Planning…" else "[bold]Planning…[/bold]",
                f"[green]Gather {done}/{total} ✓[/green]" if stage not in ("Planning…", "Gathering…") else (f"[bold]Gathering {done}/{total}[/bold]" if stage == "Gathering…" else "Gather"),
                "[green]Verify ✓[/green]" if stage not in ("Planning…", "Gathering…", "Verifying…") else ("[bold]Verifying…[/bold]" if stage == "Verifying…" else "Verify"),
                "[green]Synthesize ✓[/green]" if stage == "Done" else ("[bold]Synthesizing…[/bold]" if stage == "Synthesizing…" else "Synthesize"),
            ]
            phase_line = "  →  ".join(phases)
            src_line = f"[dim]{sources} sources scanned[/dim]" if sources else ""
            log_lines = state.get("log") or []
            log_text = "\n".join(f"  [dim]{ts}[/dim] {msg}" for ts, msg in log_lines[-6:])
            body = f"{phase_line}\n\n{src_line}\n\n[dim]Log:[/dim]\n{log_text or '  —'}"
            return Panel(body, title=f"[cyan]Deep Research[/cyan] — {stage}", border_style="cyan")

        thread = threading.Thread(target=run_in_thread, daemon=False)
        thread.start()
        try:
            with Live(render(), console=console, refresh_per_second=2) as live:
                while not state["done"]:
                    time.sleep(0.25)
                    live.update(render())
        except KeyboardInterrupt:
            state["error"] = KeyboardInterrupt()
        thread.join(timeout=0.5)
        if state.get("error"):
            raise state["error"]
        raw = state.get("report") or "(no report)"
        return _clean_research_report(raw)


def _get_projects_root() -> Path:
    """Return the root folder where Artemis manages its own projects.

    Defaults to ~/ArtemisProjects, overridable via OPENARTEMIS_PROJECTS_ROOT.
    """
    raw = os.environ.get("OPENARTEMIS_PROJECTS_ROOT", "").strip()
    root = Path(raw).expanduser().resolve() if raw else (Path.home() / "ArtemisProjects")
    try:
        root.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        console.print(f"[red]Could not create projects root {root}: {e}[/red]")
    return root


def _ask_agent_workspace_path() -> Path | None:
    """Ask user where the project should live and return the workspace folder.

    Options:
    - Create project folder under the Artemis projects root.
    - Use an existing project folder under the projects root.
    - Paste a custom folder path (advanced).
    """
    method = _select_with_swapped_arrows(
        "Where should the project live?",
        choices=[
            questionary.Choice("Create project folder (recommended)", value="create"),
            questionary.Choice("Use existing project folder", value="existing"),
            questionary.Choice("Paste custom folder path (advanced)", value="paste"),
            questionary.Choice("Back", value="back"),
        ],
        default="create",
        **_QUESTIONARY_SELECT_OPTS,
    )
    if not method or method == "back":
        return None

    if method in ("create", "existing"):
        projects_root = _get_projects_root()
        if method == "create":
            name = questionary.text(
                "Name your project folder (e.g. flappy-bird-game):",
                qmark="",
            ).ask()
            if not name or not name.strip():
                return None
            # Simple slug to keep folder names filesystem-friendly
            slug = re.sub(r"[^\w\-]+", "-", name.strip()).strip("-") or "project"
            workspace = projects_root / slug
            if workspace.exists() and any(workspace.iterdir()):
                reuse = questionary.confirm(
                    f"Folder {workspace} already exists and is not empty. Use it?",
                    default=True,
                    qmark="",
                ).ask()
                if not reuse:
                    return None
            workspace.mkdir(parents=True, exist_ok=True)
            return workspace.resolve()

        # existing project
        projects = sorted(
            [p for p in projects_root.iterdir() if p.is_dir()],
            key=lambda p: p.name.lower(),
        )
        if not projects:
            theme.warn(console, f"No existing project folders in {projects_root}. Creating one instead.")
            # Fall back to create flow
            name = questionary.text(
                "Name your project folder (e.g. flappy-bird-game):",
                qmark="",
            ).ask()
            if not name or not name.strip():
                return None
            slug = re.sub(r"[^\w\-]+", "-", name.strip()).strip("-") or "project"
            workspace = projects_root / slug
            workspace.mkdir(parents=True, exist_ok=True)
            return workspace.resolve()
        choices = [
            questionary.Choice(f"{p.name}  [dim]({p})[/dim]", value=str(p))
            for p in projects
        ]
        choices.append(questionary.Choice("Back", value="back"))
        selection = _select_with_swapped_arrows(
            "Select existing project folder:",
            choices=choices,
            default=choices[0].value if choices else None,
            **_QUESTIONARY_SELECT_OPTS,
        )
        if not selection or selection == "back":
            return None
        return Path(selection).expanduser().resolve()

    # method == "paste"
    path_str = questionary.text(
        "Paste folder path (e.g. C:\\Dev\\MyGame or ~/projects/myapp):",
        qmark="",
    ).ask()
    if not path_str or not path_str.strip():
        return None
    resolved = Path(path_str.strip()).expanduser().resolve()
    if not resolved.exists():
        if questionary.confirm(f"Create folder at {resolved}?", default=True, qmark="").ask():
            resolved.mkdir(parents=True, exist_ok=True)
        else:
            return None
    if not resolved.is_dir():
        theme.err(console, "Path is not a directory.")
        return None
    return resolved


def _run_o3de_agent(bridge: Any, slug: str, req: str) -> None:
    """Run the O3DE game studio agent with live dashboard output."""
    console.print()
    console.print(Panel(
        f"[bold cyan]Building: {req[:80]}[/bold cyan]\n"
        f"[dim]Project: {slug} | Engine: O3DE 25.10.2[/dim]",
        border_style="cyan",
    ))

    import time as _time
    _start = _time.time()
    _lines_coded = [0]
    _entities: list[str] = []
    _assets: list[str] = []
    _current_agent = ["Director"]
    _agent_status = {
        "Director": ">", "Engine Operator": ".",
        "Asset Artist": ".", "Gameplay Dev": ".", "QA Tester": ".",
    }

    def _elapsed() -> str:
        s = int(_time.time() - _start)
        return f"{s // 60}m {s % 60}s"

    def on_status(msg: str) -> None:
        lower = msg.lower()
        if "o3de_create_entity" in lower:
            parts = msg.split("name=")
            if len(parts) > 1:
                ename = parts[1].split(",")[0].strip("'\"")
                _entities.append(ename)
        if "o3de_write_script" in lower or "write_script" in lower:
            content_parts = msg.split("content=")
            if content_parts and len(content_parts) > 1:
                _lines_coded[0] += content_parts[1].count("\\n") + 1
        if "generate_image" in lower or "import_asset" in lower:
            _assets.append(msg.split("(")[0] if "(" in msg else "asset")
        if "phase" in lower or "director" in lower:
            _current_agent[0] = "Director"
        if "engine" in lower or "level" in lower or "entity" in lower or "terrain" in lower or "lighting" in lower:
            _current_agent[0] = "Engine Operator"
            _agent_status["Director"] = "+"
            _agent_status["Engine Operator"] = ">"
        if "asset" in lower or "texture" in lower or "material" in lower or "image" in lower:
            _current_agent[0] = "Asset Artist"
            _agent_status["Asset Artist"] = ">"
        if "script" in lower or "lua" in lower or "gameplay" in lower:
            _current_agent[0] = "Gameplay Dev"
            _agent_status["Gameplay Dev"] = ">"
        if "build" in lower or "test" in lower or "qa" in lower or "verify" in lower:
            _current_agent[0] = "QA Tester"
            _agent_status["QA Tester"] = ">"

        stats = f"{_elapsed()} | {_lines_coded[0]} lines | {len(_entities)} entities | {len(_assets)} assets"
        console.print(f"  [cyan]{_current_agent[0]}[/cyan] {stats}")
        short_msg = msg[:120] + "..." if len(msg) > 120 else msg
        console.print(f"    [dim]{short_msg}[/dim]")

    try:
        from openartemis.agent.agent_orchestrator import run_agent_o3de
        report, tracker = run_agent_o3de(req, bridge, on_status=on_status)

        for k in _agent_status:
            _agent_status[k] = "+"

        console.print()
        theme.rule(console)
        theme.ok(console, f"Done in {_elapsed()}  ·  {_lines_coded[0]} lines  ·  {len(_entities)} entities  ·  {len(_assets)} assets")
        console.print()
        console.print(Panel(Markdown(report or "(no output)"), title="[dim]report[/dim]", border_style="cyan"))

        info = bridge.get_project_info()
        console.print()
        theme.dim_kv(console, "project", info.get("name", "?"))
        theme.dim_kv(console, "path", info.get("path", ""))
        theme.info(console, f"assets: {info.get('asset_count', 0)}  scripts: {info.get('script_count', 0)}  levels: {info.get('level_count', 0)}")

    except Exception as e:
        theme.err(console, f"O3DE agent failed: {e}")

    if not bridge.project_path:
        return
    console.print()
    while True:
        action = _select_with_swapped_arrows(
            "What next?",
            choices=[
                questionary.Choice("  Open project folder", value="folder"),
                questionary.Choice("  Build game", value="build"),
                questionary.Choice("  Open in O3DE Editor", value="editor"),
                questionary.Choice("  Done", value="done"),
            ],
            default="done",
            **_QUESTIONARY_SELECT_OPTS,
        )
        if not action or action == "done":
            break
        if action == "folder":
            try:
                import subprocess as _sp
                _sp.Popen(["explorer", str(bridge.project_path)])
                theme.info(console, f"Opened: {bridge.project_path}")
            except Exception as e:
                theme.err(console, f"Failed to open folder: {e}")
        elif action == "build":
            try:
                theme.info(console, "Building game...")
                ok, build_msg = bridge.build_game(
                    on_status=lambda s: console.print(f"  [dim]{s}[/dim]"),
                )
                if ok:
                    theme.ok(console, build_msg)
                    launcher = bridge.get_game_launcher()
                    if launcher:
                        theme.dim_kv(console, "launcher", str(launcher))
                else:
                    theme.warn(console, f"Build: {build_msg}")
            except Exception as e:
                theme.err(console, f"Build error: {e}")
        elif action == "editor":
            try:
                editor_exe = bridge.get_editor_exe()
                import subprocess as _sp
                _sp.Popen([editor_exe, f"--project-path={bridge.project_path}", "--skip-welcome-screen"])
                theme.ok(console, "O3DE Editor launched.")
            except Exception as e:
                theme.err(console, f"Failed to launch editor: {e}")


def _run_o3de_mode() -> None:
    """Run O3DE AAA Game Mode — create or resume projects, build games with the O3DE engine."""
    from openartemis.o3de_bridge import O3DEBridge, O3DE_OFFLINE_INSTALLER

    console.print()
    console.print(Panel(
        "[bold magenta]🎮 AAA Game Mode — Open 3D Engine[/bold magenta]\n\n"
        "Build AAA-quality 3D games using O3DE.\n"
        "Artemis controls the engine: entities, physics, lighting, terrain, scripting, and builds.",
        border_style="magenta",
    ))

    # ── Check O3DE installation ──
    bridge = O3DEBridge()
    if not bridge.is_installed:
        console.print("[yellow]O3DE is not detected on this machine.[/yellow]")
        console.print("[dim]O3DE can be installed in various locations. Looking for files like:[/dim]")
        console.print("[dim]  • o3de.bat or o3de.exe[/dim]")
        console.print("[dim]  • Editor.exe in bin/ folder[/dim]")
        console.print("[dim]  • scripts/ or engine/ folders[/dim]")
        console.print()
        
        # Offer options to the user
        choice = _select_with_swapped_arrows(
            "How would you like to proceed?",
            choices=[
                questionary.Choice("📁 Browse to my O3DE installation", value="browse"),
                questionary.Choice("📥 Install O3DE (offline package)", value="install"),
                questionary.Choice("❌ Cancel", value="cancel"),
            ],
            default="browse",
            **_QUESTIONARY_SELECT_OPTS,
        )
        
        if choice == "browse":
            # Let user browse to O3DE installation
            from tkinter import Tk, filedialog
            root = Tk()
            root.withdraw()  # Hide the main window
            root.attributes('-topmost', True)
            
            console.print("[dim]Please select your O3DE installation directory...[/dim]")
            path_str = filedialog.askdirectory(
                title="Select O3DE Installation Directory",
                initialdir="C:/",
            )
            root.destroy()
            
            if path_str:
                path = Path(path_str)
                if bridge.set_o3de_path(path):
                    console.print(f"[green]O3DE found at:[/green] [dim]{path}[/dim]")
                else:
                    console.print(f"[red]Invalid O3DE installation at:[/red] {path}")
                    console.print("[dim]Please ensure the selected directory contains O3DE files (o3de.bat, Editor.exe, etc.)[/dim]")
                    return
            else:
                console.print("[dim]No directory selected.[/dim]")
                return
                
        elif choice == "install":
            if O3DE_OFFLINE_INSTALLER.exists():
                install = questionary.confirm(
                    "Install O3DE from offline package? (~2GB, may take a few minutes)",
                    default=True,
                    qmark="",
                ).ask()
                if install:
                    console.print("[dim]Installing O3DE... This may take a few minutes.[/dim]")
                    ok = bridge.install_from_offline(
                        on_status=lambda s: console.print(f"  [dim]{s}[/dim]"),
                    )
                    if not ok:
                        console.print("[red]Installation failed. Please install O3DE manually.[/red]")
                        return
                    console.print("[green]O3DE installed successfully![/green]")
                else:
                    console.print("[dim]O3DE required for AAA game mode.[/dim]")
                    return
            else:
                console.print("[red]O3DE offline installer not found.[/red]")
                console.print(f"[dim]Expected at: {O3DE_OFFLINE_INSTALLER}[/dim]")
                console.print("[dim]Download O3DE from https://o3de.org and install it first.[/dim]")
                return
        else:
            return
    else:
        console.print(f"[green]O3DE found:[/green] [dim]{bridge.o3de_path}[/dim]")

    # ── Bootstrap O3DE Python environment ──
    console.print("[dim]Checking O3DE environment...[/dim]")
    if not bridge.ensure_o3de_python(on_status=lambda s: console.print(f"  [dim]{s}[/dim]")):
        console.print("[red]O3DE Python environment could not be set up.[/red]")
        console.print(f"[dim]Try running manually: {bridge.o3de_path / 'python' / 'get_python.bat'}[/dim]")
        return

    # ── New or existing project? ──
    existing = bridge.scan_existing_projects()
    choices = [questionary.Choice("🆕 Create new game", value="new")]
    for proj in existing:
        label = f"📂 {proj['display_name']}"
        stats = []
        if proj.get("levels"):
            stats.append(f"{proj['levels']} levels")
        if proj.get("lua_scripts"):
            stats.append(f"{proj['lua_scripts']} scripts")
        if proj.get("built"):
            stats.append("built ✅")
        if stats:
            label += f"  [dim]({', '.join(stats)})[/dim]"
        choices.append(questionary.Choice(label, value=proj["path"]))
    choices.append(questionary.Choice("↩ Back", value="back"))

    project_choice = _select_with_swapped_arrows(
        "Select project:",
        choices=choices,
        default="new",
        **_QUESTIONARY_SELECT_OPTS,
    )
    if not project_choice or project_choice == "back":
        return

    if project_choice == "new":
        # ── Create new project ──
        name = questionary.text("Name your game (e.g. SpaceWar, DungeonCrawler):", qmark="").ask()
        if not name or not name.strip():
            return
        # Extract a clean game name from natural language input
        raw = name.strip()
        # Strip common prefixes like "make me", "build", "create", "I want"
        for prefix in ["make me a ", "make me ", "build me a ", "build me ", "build a ",
                        "create a ", "create me a ", "create me ", "i want a ", "i want ",
                        "build ", "create ", "make "]:
            if raw.lower().startswith(prefix):
                raw = raw[len(prefix):]
                break
        slug = re.sub(r"[^\w]+", "", raw.title()) or "MyGame"
        console.print(f"[dim]Creating O3DE project: {slug}...[/dim]")
        try:
            project_path = bridge.create_project(
                slug,
                on_status=lambda s: console.print(f"  [dim]{s}[/dim]"),
            )
        except Exception as e:
            console.print(f"[red]Failed to create project: {e}[/red]")
            return
        console.print(f"[green]Project created:[/green] {project_path}")
    else:
        # ── Resume existing project ──
        project_path = Path(project_choice)
        bridge.open_project(project_path)
        slug = project_path.name
        info = bridge.get_project_info()
        console.print(f"[green]Opened:[/green] {slug}")
        console.print(f"  [dim]Levels: {info.get('level_count', 0)} | Scripts: {info.get('script_count', 0)} | Assets: {info.get('asset_count', 0)}[/dim]")

    # ── Get game description ──
    req = questionary.text(
        "Describe your game (e.g. 'A horror FPS in a dark forest with zombies'):",
        qmark="",
    ).ask()
    if not req or not req.strip():
        return

    # ── Director Planning Phase ──
    console.print()
    console.print("[bold cyan]🧠 Director is planning your game...[/bold cyan]")
    try:
        from openartemis.agent.game_blueprints import detect_genre, get_blueprint
        genre_key = detect_genre(req)
        blueprint = get_blueprint(genre_key)
        console.print(f"  [dim]Genre detected:[/dim] [bold]{blueprint['genre']}[/bold]")
        console.print(f"  [dim]Entities:[/dim] {len(blueprint['required_entities'])}")
        console.print(f"  [dim]Scripts:[/dim] {len(blueprint['required_scripts'])}")
        console.print(f"  [dim]Assets:[/dim] {len(blueprint.get('required_assets', []))}")
        console.print()

        # Show entity list
        console.print("[bold]Game Plan:[/bold]")
        console.print(f"  [cyan]Genre:[/cyan] {blueprint['genre']}")
        for ent in blueprint["required_entities"]:
            comps = ", ".join(ent.get("components", [])[:4])
            scripts = ", ".join(ent.get("scripts", [])[:2])
            line = f"  • [green]{ent['name']}[/green]  [dim]({comps})[/dim]"
            if scripts:
                line += f"  [yellow]scripts: {scripts}[/yellow]"
            console.print(line)

        script_names = list(blueprint.get("required_scripts", {}).keys())
        if script_names:
            console.print(f"  [bold]Lua Scripts:[/bold] {', '.join(script_names)}")
        console.print()

        proceed = questionary.confirm("Proceed with this plan?", default=True, qmark="").ask()
        if not proceed:
            console.print("[dim]Cancelled.[/dim]")
            return
    except Exception as e:
        console.print(f"  [yellow]Planner skipped: {e}[/yellow]")

    # ── Run O3DE agent ──
    _run_o3de_agent(bridge, slug, req)


def _run_agent_mode_flow(session: Any = None, default_sub: str | None = None, auto_start: bool = False) -> None:
    """Run Agent Mode with E2B cloud sandbox. Two options:
    1. Create new project — empty E2B VM, AI codes from scratch
    2. Import existing project — upload local folder to E2B VM, AI works on it
    """
    from openartemis.agent.agent_tools import set_agent_workspace

    agent_sub = _select_with_swapped_arrows(
        "Agent Mode:",
        choices=[
            questionary.Choice("Create new project", value="create"),
            questionary.Choice("Import existing project", value="import"),
            questionary.Choice("🎮 AAA Game (O3DE Engine)", value="o3de"),
            questionary.Choice("Back", value="back"),
        ],
        default="create",
        **_QUESTIONARY_SELECT_OPTS,
    )
    if not agent_sub or agent_sub == "back":
        console.print("[dim]Back to mode selector.[/dim]\n")
        return

    # ── O3DE AAA Game Mode ──
    if agent_sub == "o3de":
        _run_o3de_mode()
        return

    # Set up local project folder (downloads will go here)
    projects_root = _get_projects_root()
    if agent_sub == "create":
        name = questionary.text("Name your project (e.g. flappy-bird):", qmark="").ask()
        if not name or not name.strip():
            return
        slug = re.sub(r"[^\w\-]+", "-", name.strip()).strip("-") or "project"
        local_project = projects_root / slug
        local_project.mkdir(parents=True, exist_ok=True)
        set_agent_workspace(local_project)
        import_folder: Path | None = None
    else:
        # Import: pick existing folder
        import_path = questionary.text(
            "Path to existing project folder:",
            qmark="",
        ).ask()
        if not import_path or not import_path.strip():
            return
        import_folder = Path(import_path.strip()).expanduser().resolve()
        if not import_folder.is_dir():
            console.print("[red]Not a valid directory.[/red]\n")
            return
        # Security: basic checks
        _DANGEROUS_PATTERNS = [".exe", ".dll", ".bat", ".cmd", ".ps1", ".vbs", ".msi"]
        dangerous_files = [
            f.name for f in import_folder.rglob("*")
            if f.is_file() and any(f.name.lower().endswith(ext) for ext in _DANGEROUS_PATTERNS)
        ]
        if dangerous_files:
            console.print(f"[yellow]Warning: Found potentially dangerous files: {', '.join(dangerous_files[:5])}[/yellow]")
            if not questionary.confirm("Continue anyway?", default=False, qmark="").ask():
                return
        # Check size
        total_size = sum(f.stat().st_size for f in import_folder.rglob("*") if f.is_file())
        if total_size > 100 * 1024 * 1024:  # 100MB limit
            console.print(f"[red]Project too large ({total_size // (1024*1024)}MB). Max 100MB for upload.[/red]\n")
            return
        local_project = import_folder
        set_agent_workspace(local_project)
        slug = local_project.name

    req = questionary.text(random.choice(BUILD_PROMPT_VARIANTS), qmark="").ask()
    if not req or not req.strip():
        return
    if session and getattr(session, "session_id", None):
        update_chat_session_title(session.session_id, _chat_title_from_task(req))

    # ── Prompt expansion: auto-detect type, features, quality gates ──
    from openartemis.agent.prompt_expander import expand_prompt
    spec = expand_prompt(req)
    _spec_label = f"{spec.project_type}"
    if spec.template_id:
        _spec_label += f" ({spec.template_id})"
    console.print(f"[dim]Detected: {_spec_label} | complexity: {spec.complexity}[/dim]")

    # ── Smart routing: simple projects skip straight to agent mode ──
    if spec.complexity == "simple" and not spec.needs_research:
        approach = "agent"
        console.print(f"[dim]Auto-routing to Agent Mode (simple project)[/dim]\n")
    elif spec.complexity == "complex" or spec.needs_research:
        approach = _select_with_swapped_arrows(
            "How should Artemis approach this?",
            choices=[
                questionary.Choice("⚡ Agent Mode (builds immediately, ~1-2 min)", value="agent"),
                questionary.Choice("🔬 Plan Mode (researches first, then builds, ~3-5 min)", value="plan"),
            ],
            default="plan",
            **_QUESTIONARY_SELECT_OPTS,
        )
        if not approach:
            return
    else:
        approach = _select_with_swapped_arrows(
            "How should Artemis approach this?",
            choices=[
                questionary.Choice("⚡ Agent Mode (builds immediately, ~1-2 min)", value="agent"),
                questionary.Choice("🔬 Plan Mode (researches first, then builds, ~3-5 min)", value="plan"),
            ],
            default="agent",
            **_QUESTIONARY_SELECT_OPTS,
        )
        if not approach:
            return

    # ── Model selection ──
    agent_model_choice = _select_with_swapped_arrows(
        "Choose a model:",
        choices=[
            questionary.Choice("Artemis-1       Flagship model (Opus 4.6)   — most capable", value="artemis-1"),
            questionary.Choice("Artemis-0.5     Balanced model (Sonnet 4.6) — fast & smart", value="artemis-0.5"),
        ],
        default="artemis-0.5",
        **_QUESTIONARY_SELECT_OPTS,
    )
    if agent_model_choice:
        from openartemis.config import resolve_artemis_model
        _chosen_model = resolve_artemis_model(agent_model_choice)
        os.environ["OPENARTEMIS_PLAN_MODEL"] = _chosen_model
        os.environ["OPENARTEMIS_EXEC_MODEL"] = _chosen_model
        os.environ["OPENARTEMIS_AGENT_MODEL"] = _chosen_model
        _display_name = "Artemis-1 (Flagship)" if agent_model_choice == "artemis-1" else "Artemis-0.5 (Balanced)"
        console.print(f"[dim]Model: {_display_name}[/dim]\n")

    plan_context = ""
    auto_start = False  # Initialize auto_start
    
    # ── Clarification Questions (only for ambiguous/complex projects) ──
    if approach == "plan" and spec.needs_clarification:
        console.print()
        console.print(Panel(
            "[bold cyan]🔬 Plan Mode[/bold cyan]\n\n"
            "Artemis will research the best approach before building.\n"
            "First, let's clarify your requirements...",
            border_style="cyan",
        ))
        
        try:
            from openartemis.agent.orchestrator import generate_clarification_questions
            questions = generate_clarification_questions(req)
            
            if questions:
                answers = {}
                console.print()
                for q in questions:
                    console.print(f"[bold]{q['question']}[/bold]")
                    choices = []
                    for i, option in enumerate(q['options']):
                        letter = chr(65 + i)  # A, B, C, D
                        choices.append(questionary.Choice(f"{letter}. {option}", value=option))
                    choices.append(questionary.Choice("E. Write something else", value="__custom__"))
                    
                    answer = questionary.select(
                        "",
                        choices=choices,
                    ).ask()
                    
                    if answer == "__custom__":
                        custom = questionary.text("Your answer:", qmark="").ask()
                        answers[q['id']] = custom
                    elif answer:
                        answers[q['id']] = answer
                
                if answers:
                    answer_text = "\n".join(f"- {k}: {v}" for k, v in answers.items())
                    req = f"{req}\n\nUser preferences:\n{answer_text}"
                    console.print("[green]Requirements clarified![/green]\n")
        except Exception as e:
            console.print(f"[dim]Could not generate clarification questions: {e}[/dim]\n")
    elif approach == "plan":
        console.print(f"[dim]Skipping clarification (project type is well-understood)[/dim]")
    
    if approach == "plan":
        plan_context = _run_plan_mode(req, local_project)
        if plan_context is None:
            return  # User cancelled

    # ── Run E2B agent with live progress ──
    full_req = req
    if plan_context:
        full_req = f"{req}\n\n=== BUILD PLAN (follow exactly) ===\n{plan_context}\n=== END PLAN ==="
    _run_agent_e2b_flow(full_req, local_project, import_folder=import_folder, project_name=slug, auto_start=auto_start)
    console.print()


def _run_plan_mode(req: str, local_project: Path) -> str | None:
    """Run Plan Mode: deep research → generate plan.md → user approval loop.
    Returns plan text to inject into agent, or None if cancelled."""
    import threading

    console.print()
    console.print(Panel(
        "[bold cyan]🔬 Plan Mode[/bold cyan]\n\n"
        "Artemis will research the best approach before building.\n"
        "This takes a bit longer but produces higher quality results.",
        border_style="cyan",
    ))

    # ── Phase 1: Research ──
    console.print("\n[bold]Phase 1: Researching...[/bold]")
    try:
        from openartemis.agent import ResearchPipeline
        pipeline = ResearchPipeline(
            youtube_api_key=os.environ.get("YOUTUBE_API_KEY"),
            scrapingdog_api_key=os.environ.get("SCRAPINGDOG_API_KEY"),
            transcriptapi_api_key=os.environ.get("TRANSCRIPTAPI_API_KEY"),
        )

        def on_tool(name: str, args: dict) -> None:
            if name == "brave_search":
                console.print(f"  [dim]🔍 Searching: {args.get('query', '')}[/dim]")
            elif name == "fetch_webpage":
                console.print(f"  [dim]🌐 Reading: {args.get('url', '')[:60]}[/dim]")

        research_report = _run_research_with_live(pipeline, f"How to build: {req}", on_tool_call=on_tool)
        console.print("[green]Research complete.[/green]\n")
    except Exception as e:
        console.print(f"[yellow]Research failed ({e}), generating plan from experience...[/yellow]\n")
        research_report = ""

    # ── Phase 2: Generate build plan ──
    console.print("[bold]Phase 2: Generating build plan...[/bold]")
    plan_text = _get_decisive_build_plan(req, research_report)

    if not plan_text or not plan_text.strip():
        console.print("[red]Could not generate plan.[/red]")
        return None

    # Save plan.md
    plan_path = local_project / "plan.md"
    plan_path.parent.mkdir(parents=True, exist_ok=True)
    plan_path.write_text(f"# Build Plan\n\n**Request**: {req}\n\n{plan_text}", encoding="utf-8")

    # ── Phase 3: User approval loop ──
    while True:
        console.print()
        console.print(Panel(
            Markdown(plan_text),
            title="[cyan]Build Plan[/cyan]",
            border_style="cyan",
        ))
        console.print(f"[dim]Plan saved to: {plan_path}[/dim]\n")

        approval = questionary.select(
            "Does this plan work?",
            choices=[
                questionary.Choice("✅ Yes, build it", value="yes"),
                questionary.Choice("✏️  No, update it", value="no"),
                questionary.Choice("❌ Cancel", value="cancel"),
            ],
        ).ask()

        if approval == "yes":
            console.print("[green]Plan approved! Starting build...[/green]\n")
            return plan_text
        elif approval == "cancel":
            console.print("[dim]Plan mode cancelled.[/dim]")
            return None
        else:
            # Get user feedback and regenerate
            feedback = questionary.text(
                "What should be changed?",
                default="",
                qmark="",
            ).ask()
            if not feedback or not feedback.strip():
                continue

            console.print("[dim]Updating plan...[/dim]")
            # Regenerate with feedback
            updated_req = f"{req}\n\nUser feedback on previous plan: {feedback}\n\nPrevious plan:\n{plan_text}"
            plan_text = _get_decisive_build_plan(updated_req, research_report)
            if plan_text:
                plan_path.write_text(f"# Build Plan\n\n**Request**: {req}\n\n{plan_text}", encoding="utf-8")


def _run_agent_e2b_flow(
    req: str,
    local_project: Path,
    import_folder: Path | None = None,
    project_name: str = "project",
    auto_start: bool = False,
) -> None:
    """Full E2B agent flow: start VM → (upload if import) → AI codes → download → compile."""
    import time as _time
    import threading as _threading
    import zipfile
    from rich.live import Live
    from rich.table import Table
    from rich.progress import Progress, BarColumn, TextColumn, DownloadColumn, TransferSpeedColumn
    from openartemis.token_budget import reset_session_cost, get_session_cost
    from openartemis.agent.agent_memory import AgentMemory

    reset_session_cost()
    
    # Initialize memory system
    memory = AgentMemory(project_name, local_project)
    
    _start_time = _time.time()
    _files_created: list[str] = []
    _total_lines = [0]  # Total lines written across all files
    _last_code_preview: list[str] = [""]  # Last few lines of code written
    _last_file_name: list[str] = [""]  # Name of last file being written
    _phase = ["Starting"]
    _stop_timer = _threading.Event()
    _current_action = [""]
    _activity: list[str] = []
    _live_ref: list[Any] = [None]
    _tracker: Any = [None]  # ActivityTracker reference
    _show_details = [False]  # Details panel toggle

    _PHASE_ORDER = ["VM Setup", "Build", "Verify", "Fix", "Manifest", "Report"]

    def _elapsed() -> str:
        secs = int(_time.time() - _start_time)
        if secs < 60:
            return f"{secs}s"
        return f"{secs // 60}m {secs % 60}s"

    def _phase_icon(p: str) -> str:
        current = _phase[0]
        try:
            ci = _PHASE_ORDER.index(current) if current in _PHASE_ORDER else 0
            pi = _PHASE_ORDER.index(p) if p in _PHASE_ORDER else -1
        except ValueError:
            return "[dim]◦[/dim]"
        if pi < ci:
            return "[green]✓[/green]"
        if pi == ci:
            return "[cyan]●[/cyan]"
        return "[dim]◦[/dim]"

    def _build_display() -> Table:
        from rich.table import Table
        from rich.panel import Panel
        from rich.columns import Columns
        from rich.text import Text
        from openartemis.agent.activity_tracker import EventType
        
        cost_info = get_session_cost()
        tracker = _tracker[0]
        
        # Build stats line - clean and non-wrapping
        stats_parts = []
        file_count = len(_files_created)
        stats_parts.append(f"{file_count} files")
        if _total_lines[0] > 0:
            stats_parts.append(f"+{_total_lines[0]} LOC")
        stats_parts.append(f"{cost_info['calls']} calls")
        stats_parts.append(_elapsed())
        if cost_info["calls"] > 0:
            stats_parts.append(f"~${cost_info['estimated_cost_usd']:.3f}")
        
        # Calculate live delta (files/LOC in last 30s)
        current_time = time.time()
        recent_files = [f for f in _files_created if hasattr(f, '_timestamp') and current_time - f._timestamp < 30]
        recent_lines = sum(getattr(f, '_lines', 0) for f in recent_files)
        if recent_files:
            stats_parts.append(f"[dim]+{len(recent_files)} files, +{recent_lines} LOC (last 30s)[/dim]")
        
        stats_line = f"Build stats: {' • '.join(stats_parts)}"
        
        # Simple phase list with timing
        phase_lines = []
        for p in _PHASE_ORDER:
            icon = _phase_icon(p)
            # TODO: Add phase timing tracking
            phase_lines.append(f"{icon} {p}")
        
        # Combine into clean display
        display_text = f"{stats_line}\n\n"
        display_text += "\n".join(phase_lines)
        
        # Add current action if available
        if _current_action[0]:
            display_text += f"\n\nCurrent: {_current_action[0]}"
        
        # Create a simple panel
        grid = Table.grid(padding=0)
        grid.add_column()
        grid.add_row(Text.from_markup(display_text))
        
        return grid

    def _refresh() -> None:
        if _live_ref[0] is not None:
            try:
                _live_ref[0].update(_build_display())
            except Exception:
                pass

    def _timer_fn() -> None:
        while not _stop_timer.is_set():
            _refresh()
            _stop_timer.wait(1.0)

    def on_status(s: str) -> None:
        ts = _time.strftime("%H:%M:%S")
        sl = s.lower()
        if "phase 1" in sl or "building" in sl:
            _phase[0] = "Build"
        elif "phase 2" in sl or "verifying" in sl:
            _phase[0] = "Verify"
        elif "phase 3" in sl or "fixing" in sl:
            _phase[0] = "Fix"
        elif "phase 4" in sl or "manifest" in sl:
            _phase[0] = "Manifest"
        elif "phase 5" in sl or "report" in sl:
            _phase[0] = "Report"
        if "writing " in sl or "created " in sl:
            fname = ""
            lines_match = ""
            if "Writing " in s:
                fname = s.split("Writing ")[-1].split("...")[0].strip()
                # Extract line count: "Writing foo.js (123 lines)..."
                if "(" in s and "lines)" in s:
                    try:
                        lines_match = s.split("(")[1].split(" lines)")[0]
                        _total_lines[0] += int(lines_match)
                    except (ValueError, IndexError):
                        pass
                _last_file_name[0] = fname.split(" (")[0] if " (" in fname else fname
            elif "Created " in s:
                fname = s.split("Created ")[-1].strip()
            if fname and fname not in [f.name if hasattr(f, 'name') else f for f in _files_created]:
                # Create file object with metadata
                file_obj = type('File', (), {})()
                file_obj.name = fname
                file_obj._timestamp = time.time()
                file_obj._lines = int(lines_match) if lines_match else 0
                _files_created.append(file_obj)
                lines_info = f" ({_total_lines[0]} total lines)" if _total_lines[0] > 0 else ""
                _activity.append(f"{ts}  [green]+[/green] {fname}{lines_info}")
        
        # Current action display (E2B cloud section)
        if "writing " in sl:
            fname = s.split("Writing ")[-1].split("...")[0].strip() if "Writing " in s else ""
            _current_action[0] = f"writing {fname}" if fname else s[:70]
        elif "running:" in sl:
            cmd = s.split("running: ")[-1][:50] if "running: " in s else s[:70]
            _current_action[0] = f"$ {cmd}"
        elif "verifying" in sl or "screenshot" in sl:
            _current_action[0] = "verifying..."
        elif "fixing" in sl:
            _current_action[0] = s[:70]
        elif "reading" in sl:
            fname = s.split("reading ")[-1].split("...")[0].strip() if "reading " in s else ""
            _current_action[0] = f"reading {fname}" if fname else s[:70]
        elif "phase " in sl:
            _current_action[0] = s[:70]
        elif "rate limited" in sl:
            _current_action[0] = "[yellow]rate limited — waiting...[/yellow]"
        elif "api call" in sl or "openai" in sl:
            _current_action[0] = "api call..."
        else:
            _current_action[0] = s[:70]
        if any(k in sl for k in ("running:", "verifying", "screenshot", "fixing", "phase")):
            icon = "[dim]$[/dim]" if "running:" in sl else "[dim]>[/dim]"
            _activity.append(f"{ts}  {icon} {s[:65]}")
        _refresh()

    # ── Start E2B sandbox ──
    from openartemis.agent.e2b_sandbox import E2BSandbox
    sandbox = E2BSandbox()

    try:
        console.print(Panel(
            "[bold cyan]Starting cloud sandbox...[/bold cyan]\n\n"
            "[dim]Artemis will code inside a secure Linux VM.\n"
            "All code runs in the cloud — nothing executes on your PC.\n"
            "You'll be able to download the project when it's done.[/dim]",
            title="Agent Mode (E2B Cloud)",
            border_style="cyan",
        ))
        with Progress(
            *Progress.get_default_columns(),
            console=console,
            transient=True,
        ) as prog:
            task = prog.add_task("[cyan]Starting VM...", total=None)
            sandbox.start()
            prog.update(task, description="[green]VM ready!")

        _phase[0] = "VM Setup"
        _activity.append(f"{_time.strftime('%H:%M:%S')}  [green]✓[/green] Cloud sandbox started")

        # Upload if importing existing project
        if import_folder is not None:
            console.print("[dim]Uploading project files to sandbox...[/dim]")
            upload_result = sandbox.upload_folder(import_folder)
            console.print(f"[dim]{upload_result}[/dim]")
            _activity.append(f"{_time.strftime('%H:%M:%S')}  [green]✓[/green] {upload_result}")

        # ── Run AI agent loop ──
        _phase[0] = "Build"
        with Live(_build_display(), console=console, refresh_per_second=4) as live:
            _live_ref[0] = live
            timer_thread = _threading.Thread(target=_timer_fn, daemon=True)
            timer_thread.start()

            from openartemis.agent.agent_orchestrator import run_agent_e2b
            
            # Add memory context to request
            context_summary = memory.get_full_context_for_agent()
            full_request = req
            if memory.has_previous_sessions():
                full_request = f"{req}\n\n--- PROJECT CONTEXT ---\n{context_summary}\n--- END CONTEXT ---"
            
            report, tracker = run_agent_e2b(full_request, sandbox, on_status=on_status)
            _tracker[0] = tracker  # Set tracker reference for UI

            # Save session to memory
            session_data = {
                "request": req,
                "files_created": _files_created,
                "duration": _elapsed(),
                "cost": get_session_cost(),
                "report": report
            }
            memory.add_session(session_data)
            memory.add_files(_files_created)

            _stop_timer.set()
            _phase[0] = "Report"
            _current_action[0] = "[green bold]Done![/green bold]"
            _refresh()

        # ── Show report ──
        cost_info = get_session_cost()
        theme.rule(console)
        theme.ok(console, f"Done in {_elapsed()}  ·  {len(_files_created)} file(s)  ·  {cost_info['calls']} calls  ·  ~${cost_info['estimated_cost_usd']:.3f}")
        console.print()
        console.print(Panel(Markdown(report or "(no output)"), title="[dim]report[/dim]", border_style="bright_black"))

        # ── Download project ──
        console.print()
        if questionary.confirm("Download project files to your PC?", default=True).ask():
            console.print("[dim]Downloading from sandbox...[/dim]")
            zip_path = local_project / f"{project_name}.zip"
            try:
                sandbox.download_project_zip(zip_path)
                # Extract zip
                with zipfile.ZipFile(str(zip_path), "r") as zf:
                    zf.extractall(str(local_project))
                zip_path.unlink(missing_ok=True)
                console.print(f"[green]Project downloaded to: {local_project}[/green]")

                # ── Check for .oac manifest and offer compilation ──
                oac_path = local_project / "build.oac"
                manifest = None  # Initialize manifest to None
                if oac_path.exists():
                    from openartemis.oac import read_oac, is_compilable, compile_project
                    manifest = read_oac(oac_path)
                    console.print(f"[dim]Build manifest found: {manifest.get('language', '?')} / {manifest.get('compile_target', 'none')}[/dim]")
                    if is_compilable(manifest):
                        if questionary.confirm(
                            f"Compile project? ({manifest.get('language', '?')} → {manifest.get('compile_target', '?')})",
                            default=True,
                        ).ask():
                            console.print("[dim]Compiling...[/dim]")
                            ok, msg, artifact = compile_project(
                                local_project,
                                manifest,
                                on_status=lambda s: console.print(f"  [dim]{s}[/dim]"),
                            )
                            if ok:
                                console.print(f"[green]{msg}[/green]")
                                if artifact:
                                    console.print(f"[green bold]Output: {artifact}[/green bold]")
                            else:
                                console.print(f"[red]{msg}[/red]")
                    else:
                        console.print(f"[dim]No compilation needed — {manifest.get('notes', 'project is ready to run') if manifest else 'project is ready to run'}[/dim]")
                else:
                    console.print("[dim]No build.oac manifest found. Project is ready as-is.[/dim]")

                console.print(f"\n[bold]Project location:[/bold] {local_project}")
                
                # Initialize manifest if not already done
                if 'manifest' not in locals():
                    manifest = None
                
                # ── Autonomous Project Management ──
                console.print("\n" + "="*80)
                console.print("[bold cyan]🚀 Project Ready![/bold cyan]")
                console.print(f"[dim]Location: {local_project}[/dim]")
                
                if auto_start:
                    # Super-auto mode - start immediately
                    console.print("[dim]Auto-starting project...[/dim]")
                    from openartemis.project_launcher import auto_start_project
                    auto_start_project(local_project)
                else:
                    # Choose launch mode
                    choice = questionary.select(
                        "How would you like to run your project?",
                        choices=[
                            questionary.Choice("🚀 Auto-Start (Easiest - runs automatically)", value="auto"),
                            questionary.Choice("📋 Interactive Menu (More options)", value="menu"),
                            questionary.Choice("📁 Manual Mode (Advanced users)", value="manual"),
                        ],
                        default="auto"
                    ).ask()
                    
                    if choice == "auto":
                        # One-click auto-start
                        from openartemis.project_launcher import auto_start_project
                        auto_start_project(local_project)
                        
                    elif choice == "menu":
                        # Interactive menu
                        from openartemis.project_launcher import show_project_menu
                        show_project_menu(local_project)
                        
                    else:
                        # Manual mode
                        console.print("\n[bold cyan]📁 Manual Mode[/bold cyan]")
                        console.print(f"[dim]Your project is at: {local_project}[/dim]")
                        console.print("[dim]You'll need to run it manually.[/dim]")
                        
                        if manifest and manifest.get('notes'):
                            console.print(f"\n[dim]How to run: {manifest['notes']}[/dim]")
                        
                        console.print("\n[dim]Press Enter to continue...[/dim]")
                        input()
                
                return  # Exit the agent flow
                
            except Exception as e:
                console.print(f"[red]Download failed: {e}[/red]")
        else:
            console.print("[dim]Skipped download. Files remain in the cloud sandbox until it expires.[/dim]")

    except Exception as e:
        _stop_timer.set()
        console.print(f"\n[red]Agent failed: {e}[/red]")
    finally:
        # Always clean up the sandbox
        try:
            sandbox.stop()
        except Exception:
            pass


# Test-login gate: set OPENARTEMIS_ALLOW_TEST_LOGIN to this value to allow headless login
# via OPENARTEMIS_TEST_USER + OPENARTEMIS_TEST_PASSWORD (e.g. for Cursor agent to test).
_TEST_LOGIN_GATE = "cursor-agent-test"

def _try_test_login() -> dict | None:
    """If test-login env is set and gate matches, log in with TEST_USER/TEST_PASSWORD. Else None."""
    if os.environ.get("OPENARTEMIS_ALLOW_TEST_LOGIN") != _TEST_LOGIN_GATE:
        return None
    username = os.environ.get("OPENARTEMIS_TEST_USER", "").strip()
    password = os.environ.get("OPENARTEMIS_TEST_PASSWORD", "")
    if not username or not password:
        return None
    user = login(username, password)
    if not user:
        return None
    create_session(user["id"])
    return user


def _get_authenticated_user() -> dict:
    """Get current user. Returns user dict if authenticated, else runs auth flow."""
    init_db()
    user = get_session_user()
    if user and user.get("approved"):
        return user
    user = _try_test_login()
    if user:
        return user
    return _auth_flow()


def _get_user_no_prompt() -> dict | None:
    """Return current user if session or test-login exists. No interactive prompts."""
    init_db()
    user = get_session_user()
    if user and user.get("approved"):
        return user
    return _try_test_login()


def _auth_flow() -> dict:
    """Run login or invite-code flow. Returns user or exits. Loops on failure until success or Exit."""
    if get_user_count() == 0:
        return _create_first_admin()
    while True:
        console.print()
        theme.rule(console, "welcome")
        console.print()
        console.print("  [dim]↑↓ navigate  ⏎ select  ctrl+c quit[/dim]")
        choice = _select_with_swapped_arrows(
            "  ",
            choices=[
                questionary.Choice("  Login                 enter your credentials", value="login"),
                questionary.Choice("  Register with invite  use a 24-char code", value="code"),
                questionary.Choice("  Exit", value="exit"),
            ],
            default=None,
            **_QUESTIONARY_SELECT_OPTS,
        )
        if not choice or choice == "exit":
            raise typer.Exit(0)
        if choice == "code":
            user = _do_redeem_code()
            if user is not None:
                return user
            continue
        user = _do_login()
        if user is not None:
            return user


def _create_first_admin() -> dict:
    """Create first admin account. Re-prompts on validation failure until valid."""
    console.print()
    theme.rule(console, "first run")
    console.print()
    theme.info(console, "No accounts found. Create your admin account.")
    console.print()
    while True:
        email    = questionary.text("  1  Email:",    style=_QUESTIONARY_SELECT_STYLE, qmark="").ask() or ""
        username = questionary.text("  2  Username:", style=_QUESTIONARY_SELECT_STYLE, qmark="").ask() or ""
        password = questionary.password("  3  Password (min 8 chars):", style=_QUESTIONARY_SELECT_STYLE, qmark="").ask() or ""
        if not username or not password:
            theme.err(console, "Username and password required.")
            continue
        if len(password) < 8:
            theme.err(console, "Password must be at least 8 characters.")
            continue
        create_admin(email, username, password)
        from openartemis.auth.db import get_user_by_username
        user = get_user_by_username(username)
        if user:
            create_session(user["id"])
            console.print()
            theme.ok(console, f"Admin account created. Welcome, {username}.")
            console.print()
            return user
        theme.err(console, "Account creation failed. Try again.")


def _do_redeem_code() -> dict | None:
    """Handle invite code redemption. Returns user dict or None on failure."""
    console.print()
    theme.rule(console, "register")
    console.print()
    theme.info(console, "24 characters  ·  uppercase + digits")
    console.print()

    code = questionary.text("  Invite code:", style=_QUESTIONARY_SELECT_STYLE, qmark="").ask() or ""
    code = code.upper().strip()
    if len(code) != 24:
        theme.err(console, "Code must be exactly 24 characters.")
        return None

    email    = questionary.text("  Email:",    style=_QUESTIONARY_SELECT_STYLE, qmark="").ask() or ""
    username = questionary.text("  Username:", style=_QUESTIONARY_SELECT_STYLE, qmark="").ask() or ""

    # Early uniqueness checks with actionable messages
    from openartemis.auth.db import get_user_by_username, get_user_by_email
    if get_user_by_username(username):
        theme.err(console, "Username already taken.")
        return None
    if get_user_by_email(email):
        theme.err(console, "Email already registered — try Login with your existing account.")
        return None

    password = questionary.password("  Password (min 8 chars):", style=_QUESTIONARY_SELECT_STYLE, qmark="").ask() or ""
    if not email or not username or not password:
        theme.err(console, "All fields required.")
        return None
    if len(password) < 8:
        theme.err(console, "Password must be at least 8 characters.")
        return None

    user, err_msg = redeem_invite_code(code, email, username, password)
    if not user:
        theme.err(console, err_msg or "Registration failed.")
        return None

    create_session(user["id"])
    console.print()
    theme.ok(console, f"Welcome, {username}. Your account is active.")
    console.print()
    return user


def _do_login() -> dict | None:
    """Handle login. Returns user dict or None on failure (caller can retry)."""
    console.print()
    theme.rule(console, "login")
    console.print()

    username = questionary.text("  Username:", style=_QUESTIONARY_SELECT_STYLE, qmark="").ask() or ""
    password = questionary.password("  Password:", style=_QUESTIONARY_SELECT_STYLE, qmark="").ask() or ""
    if not username or not password:
        theme.err(console, "Username and password required.")
        return None

    # Try proxy server login first (SaaS path — silent)
    try:
        from openartemis.config import ARTEMIS_PROXY_URL
        from openartemis.proxy_client import save_session
        import httpx
        resp = httpx.post(
            f"{ARTEMIS_PROXY_URL}/auth/login",
            json={"username": username, "password": password},
            timeout=15.0,
        )
        if resp.status_code == 200:
            data = resp.json()
            save_session(data["token"], str(data["user_id"]), data.get("role", "user"))
            user = login(username, password)
            if user:
                create_session(user["id"])
            console.print()
            theme.ok(console, f"Logged in as {username}.")
            console.print()
            return user or {"username": username, "role": data.get("role", "user"), "approved": 1}
        elif resp.status_code == 403:
            theme.err(console, "Account pending approval.")
            return None
        else:
            raise RuntimeError(f"proxy {resp.status_code}")
    except Exception:
        pass

    # Fallback: local login
    try:
        user = login(username, password)
    except RuntimeError as e:
        if "ALREADY_ACTIVE" in str(e):
            theme.err(console, "This account is already logged in on another device.")
            theme.info(console, "Run  openartemis logout  on the other device first.")
        else:
            theme.err(console, str(e))
        return None
    if not user:
        theme.err(console, "Invalid credentials.")
        return None
    create_session(user["id"])
    console.print()
    theme.ok(console, f"Logged in as {username}.")
    console.print()
    return user


def _chat_mode(user: dict) -> None:
    """Chat CLI — Artemis with research tools. Type / for mode menu."""
    from openartemis.config import load_config
    load_config()  # Ensure defaults applied (in case import order differed)
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
    if not anthropic_key:
        console.print(
            "[red]ANTHROPIC_API_KEY required for chat.[/red] Set it in .env or your environment."
        )
        raise typer.Exit(1)

    from openartemis.chat import ChatSession

    def on_tool(name: str, args: dict) -> None:
        if name == "harvest_transcripts":
            q = args.get("query", "")
            p = args.get("platforms", ["youtube"])
            console.print(f"    [dim]↳ finding videos:[/dim] [cyan]{q}[/cyan] [dim]on {', '.join(p)}[/dim]")
        elif name == "read_transcript":
            console.print(f"    [dim]↳ reading transcript...[/dim]")
        elif name == "brave_search":
            console.print(f"    [dim]↳ search:[/dim] [cyan]{args.get('q', '')}[/cyan]")
        elif name == "fetch_webpage":
            console.print(f"    [dim]↳ fetch:[/dim] [cyan]{args.get('url', '')}[/cyan]")
        elif name == "browse_webpage":
            console.print(f"    [dim]↳ browse:[/dim] [cyan]{args.get('url', '')}[/cyan]")

    is_admin = user.get("role") == "admin"
    session_id: int | None = None

    # Mode selector — dark minimal
    theme.rule(console, user.get("username", "artemis"))
    console.print()
    choice = _select_with_swapped_arrows(
        "  ",
        choices=[
            questionary.Choice("  New chat", value="new"),
            questionary.Choice("  Continue previous chat", value="continue"),
        ],
        default=None,
        **_QUESTIONARY_SELECT_OPTS,
    )

    if choice == "continue":
        sessions_list = get_chat_sessions(user["id"], limit=15)
        if not sessions_list:
            console.print("[dim]No previous chats. Starting new chat.[/dim]\n")
            session_id = create_chat_session(user["id"])
            session = ChatSession(
                on_tool_call=on_tool,
                user_id=user["id"],
                is_admin=is_admin,
                session_id=session_id,
            )
        else:
            for s in sessions_list:
                console.print(_chat_list_line(s, console))
            sid_str = questionary.text("Chat number to load (or Enter for new):").ask()
            if sid_str and sid_str.strip().isdigit():
                sid = int(sid_str.strip())
                if any(s["id"] == sid for s in sessions_list):
                    session_id = sid
                    # Full context: load all persisted messages so the user sees the full chat when returning.
                    msgs = get_chat_messages(session_id)
                    session = ChatSession(
                        on_tool_call=on_tool,
                        user_id=user["id"],
                        is_admin=is_admin,
                        session_id=session_id,
                    )
                    session.messages = [{"role": "system", "content": session.messages[0]["content"]}]
                    for m in msgs:
                        msg = {"role": m["role"], "content": m.get("content", "")}
                        if m.get("tool_calls"):
                            msg["tool_calls"] = m["tool_calls"]
                        session.messages.append(msg)
                    session._last_persisted = len(session.messages)
                else:
                    session_id = create_chat_session(user["id"])
                    session = ChatSession(
                        on_tool_call=on_tool,
                        user_id=user["id"],
                        is_admin=is_admin,
                        session_id=session_id,
                    )
            else:
                session_id = create_chat_session(user["id"])
                session = ChatSession(
                    on_tool_call=on_tool,
                    user_id=user["id"],
                    is_admin=is_admin,
                    session_id=session_id,
                )
    else:
        session_id = create_chat_session(user["id"])
        session = ChatSession(
            on_tool_call=on_tool,
            user_id=user["id"],
            is_admin=is_admin,
            session_id=session_id,
        )

    _welcome(chat=True, model=session.model_display)

    current_mode = "chat"
    stream_fast_ref: list[bool] = [True]
    last_artemis_response: list[str | None] = [None]
    while True:
        try:
            _mode_tag = "" if current_mode == "chat" else f" [{current_mode}]"
            user_input = questionary.text(f"  \u203a{_mode_tag}", default="", style=_QUESTIONARY_SELECT_STYLE, qmark="").ask()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]goodbye[/dim]")
            raise typer.Exit(0)

        if not user_input or not user_input.strip():
            continue

        # Agent-status: treat as command, never send to chat (works with or without /)
        raw = user_input.strip()
        s = raw.lower().removeprefix("openartemis ").strip()
        # Strip questionary-style prompt prefix if present (e.g. "? You: agent-status")
        for prefix in ("? ", "you: ", "you:"):
            if s.startswith(prefix):
                s = s[len(prefix):].strip().lower()
                break
        s_nodash = s.replace("-", " ").replace("_", " ").strip()
        if s in ("agent-status", "agent status", "agentstatus") or s_nodash == "agent status":
            theme.info(console, "Checking agent status (Ctrl+C to stop)…")
            _run_agent_status_continuous()
            continue

        # Slash command: extensible registry
        if user_input.strip().startswith("/"):
            cmd = user_input.strip().lower().split()[0] if user_input.strip().split() else user_input.strip().lower()
            _register_builtins()

            def _run_research_callback(query: str) -> None:
                from openartemis.agent import ResearchPipeline
                pipeline = ResearchPipeline(
                    youtube_api_key=os.environ.get("YOUTUBE_API_KEY"),
                    scrapingdog_api_key=os.environ.get("SCRAPINGDOG_API_KEY"),
                    transcriptapi_api_key=os.environ.get("TRANSCRIPTAPI_API_KEY"),
                    model=session.model,
                    out_dir=Path("./detective_output"),
                )
                def on_tool(name: str, args: dict) -> None:
                    if name == "harvest_transcripts":
                        console.print(f"  [dim]→ Harvesting: [bold]{args.get('query', '')}[/bold][/dim]")
                    elif name == "brave_search":
                        console.print(f"  [dim]→ Brave search: [bold]{args.get('q', '')}[/bold][/dim]")
                    elif name == "fetch_webpage":
                        console.print(f"  [dim]→ Fetching: [bold]{args.get('url', '')}[/bold][/dim]")
                    elif name == "browse_webpage":
                        console.print(f"  [dim]→ Browsing: [bold]{args.get('url', '')}[/bold][/dim]")
                try:
                    report = _run_research_with_live(pipeline, query, on_tool_call=on_tool)
                    console.print("[green]Report ready.[/green]\n")
                    console.print(Panel(Markdown(report or "(no report)"), title="[green]Research Report[/green]", border_style="green"))
                except Exception as e:
                    console.print(f"[red]Research failed: {e}[/red]\n")
                console.print()

            mode_state: dict[str, Any] = {"current_mode": current_mode}
            slash_ctx: dict[str, Any] = {
                "user_input": user_input,
                "session": session,
                "user": user,
                "is_admin": is_admin,
                "mode_state": mode_state,
                "console": console,
                "run_agent": lambda: _run_agent_mode_flow(session=session),
                "run_research": _run_research_callback,
                "run_agent_status": _run_agent_status_continuous,
                "stream_fast_ref": stream_fast_ref,
                "last_artemis_response": last_artemis_response,
            }
            if cmd in SLASH_REGISTRY:
                try:
                    SLASH_REGISTRY[cmd](slash_ctx)
                except typer.Exit:
                    raise
                if "current_mode" in mode_state:
                    current_mode = mode_state["current_mode"]
                continue

            # Unknown slash or "/" only: show mode menu
            console.print()
            theme.rule(console, "menu")
            console.print()
            if current_mode in ("agent", "agent_ask", "agent_plan"):
                _mode_choices = [
                    questionary.Choice("  Run another task", value="agent"),
                    questionary.Choice("  Ask mode         answer questions about your code", value="agent_ask"),
                    questionary.Choice("  Plan mode        research + plan", value="agent_plan"),
                    questionary.Choice("  Back to chat", value="chat"),
                    questionary.Choice("  Exit", value="exit"),
                ]
                _default = "agent" if current_mode == "agent" else current_mode
            else:
                _mode_choices = [
                    questionary.Choice("  Chat             ask Artemis anything", value="chat"),
                    questionary.Choice("  Research         Artemis uses tools", value="research"),
                    questionary.Choice("  Agent            build / code / write", value="agent"),
                    questionary.Choice("  Find videos      harvest transcripts", value="harvest"),
                    questionary.Choice("  Change model", value="_model"),
                    questionary.Choice("  Exit", value="exit"),
                ]
                _default = current_mode
            mode_choice = _select_with_swapped_arrows(
                "  ",
                _mode_choices,
                default=_default,
                **_QUESTIONARY_SELECT_OPTS,
            )

            if not mode_choice or mode_choice == "exit":
                theme.info(console, "Bye.")
                raise typer.Exit(0)
            if mode_choice == "chat":
                current_mode = "chat"
                continue
            if mode_choice == "_model":
                from openartemis.slash_commands import _pick_model_interactive
                chosen = _pick_model_interactive(console, session.model_display)
                if chosen:
                    from openartemis.config import resolve_artemis_model
                    session.model_display = chosen
                    session.model = resolve_artemis_model(chosen.lower().replace(" ", "-"))
                    theme.ok(console, f"Model → {chosen}")
                continue
            current_mode = mode_choice
            if mode_choice == "harvest":
                try:
                    _interactive_mode()
                except Exception as e:
                    theme.err(console, f"Find videos failed: {e}")
                _welcome(chat=True)
                current_mode = "chat"
                continue
            if mode_choice == "agent":
                _run_agent_mode_flow(session=session)
                continue
            if mode_choice == "agent_ask":
                _run_agent_mode_flow(session=session, default_sub="ask")
                continue
            if mode_choice == "agent_plan":
                _run_agent_mode_flow(session=session, default_sub="plan")
                continue
            if mode_choice == "research":
                theme.info(console, "Research mode — ask Artemis to research something.")
            continue

        # User message — plain right-aligned, no panel
        _clear_last_line(console)
        ts_user = datetime.now().strftime("%H:%M")
        tw = _terminal_width(console)
        _user_label = f"you \u00b7 {ts_user}"
        console.print(Align.right(f"[cyan]you[/cyan] [dim]\u00b7 {ts_user}[/dim]"))
        _wrapped_u = textwrap.fill(user_input, width=min(70, tw - 4))
        for _ul in _wrapped_u.splitlines():
            console.print(Align.right(_ul))
        console.print()
        num_msgs_before = len(session.messages)

        # Artemis response
        ts_artemis_start = datetime.now().strftime("%H:%M")
        try:
            console.print(f"[bold cyan]\u25c6 artemis[/bold cyan] [dim]\u00b7 {ts_artemis_start}[/dim]")
            stream_cb, stream_flush = _make_paced_stream_callback(console, fast=stream_fast_ref[0], left_pad=0)
            response = session.send(user_input, stream_callback=stream_cb)
            stream_flush()
            console.print()
            last_artemis_response[0] = response
            session.persist()
            # First exchange: name chat from context
            if num_msgs_before == 1 and session.session_id and (response or "").strip():
                try:
                    from openartemis.config import resolve_artemis_model, completion_tokens_kwarg, get_anthropic_client
                    client = get_anthropic_client()
                    model = resolve_artemis_model("artemis-0.5")
                    r = client.messages.create(
                        model=model,
                        max_tokens=64,
                        messages=[
                            {"role": "user", "content": f"Generate a short chat title (max 6 words) for this exchange. User: {user_input[:150]}. Assistant: {(response or '')[:150]}. Reply with only the title, no quotes."},
                        ],
                    )
                    title = (r.content[0].text or "").strip()[:80]
                    if title:
                        update_chat_session_title(session.session_id, title)
                except Exception:
                    pass
        except ValueError as e:
            theme.err(console, str(e))
            console.print()
            continue
        except Exception as e:
            err_msg = str(e)
            if "402" in err_msg or "insufficient" in err_msg.lower():
                theme.err(console, "Credits issue. Please try again later.")
            elif "401" in err_msg or "authentication" in err_msg.lower():
                theme.err(console, "Authentication error. Check your API key.")
            elif "rate" in err_msg.lower() or "429" in err_msg:
                theme.err(console, "Too many requests. Wait a moment and try again.")
            else:
                theme.err(console, "Something went wrong. Try again or type /help.")
            theme.info(console, err_msg[:200])
            console.print()
            continue
        if not response and num_msgs_before < len(session.messages):
            # Only re-render if streaming produced nothing (fallback for non-streamed responses)
            pass
        if response and (response or "").strip():
            theme.rule(console)
            theme.info(console, "/copy  ·  / for menu")
        if session.credits_used > 0 and not is_admin:
            from openartemis.config import get_max_credits
            max_credits = get_max_credits()
            if max_credits is not None and session.credits_used >= max_credits * 8 // 10:
                theme.warn(console, f"Approaching credits cap ({session.credits_used}/{max_credits}).")
            elif max_credits is None and session.credits_used >= 50:
                theme.warn(console, "Many credits used this session.")
        console.print()


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    """Chat with Artemis — uses research tools when you ask. Type / for menu."""
    if ctx.invoked_subcommand is not None:
        return
    while True:
        try:
            user = _get_authenticated_user()
            _chat_mode(user)
            break
        except typer.Exit:
            raise
        except Exception as e:
            err_msg = str(e)
            if "Windows console" in err_msg or "xterm" in err_msg.lower() or "NoConsoleScreenBuffer" in err_msg:
                theme.err(console, "This terminal is not a Windows console.")
                theme.info(console, "Run OpenArtemis in cmd.exe or Windows Terminal so menus and arrow keys work.")
                raise typer.Exit(1)
            theme.err(console, f"Error: {e}")
            theme.info(console, "Returning to sign in.")


@app.command(hidden=True)
def test_run() -> None:
    """Headless one-round chat test (for agent/CI). Uses session or OPENARTEMIS_TEST_* login."""
    user = _get_user_no_prompt()
    if not user:
        console.print(
            "[yellow]No session and no test login.[/yellow]\n"
            f"Log in once in a real terminal, or set [bold]OPENARTEMIS_ALLOW_TEST_LOGIN={_TEST_LOGIN_GATE}[/bold] "
            "with [bold]OPENARTEMIS_TEST_USER[/bold] and [bold]OPENARTEMIS_TEST_PASSWORD[/bold] to run this test."
        )
        raise typer.Exit(1)
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
    if not anthropic_key:
        console.print("[red]ANTHROPIC_API_KEY required for chat.[/red]")
        raise typer.Exit(1)
    from openartemis.chat import ChatSession
    session_id = create_chat_session(user["id"])
    session = ChatSession(
        user_id=user["id"],
        is_admin=user.get("role") == "admin",
        session_id=session_id,
    )
    console.print("[dim]test-run: sending 'Hi', streaming response...[/dim]")
    try:
        response = session.send("Hi", stream_callback=lambda c: console.print(c, end=""))
        console.print()
        console.print(f"[green]test-run OK[/green] — response length: {len(response or '')} chars")
        session.persist()
    except Exception as e:
        console.print(f"[red]test-run failed: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def harvest() -> None:
    """Guided harvest — step-by-step transcript download."""
    _get_authenticated_user()
    _interactive_mode()


@app.command()
def investigate(
    prompt: str = typer.Argument(None, help="What to find out (e.g. 'Find everything about what happened to John Smith')"),
    anthropic_api_key: str | None = typer.Option(
        None,
        "--anthropic-api-key",
        envvar="ANTHROPIC_API_KEY",
        help="Anthropic API key",
    ),
    model: str = typer.Option(
        "artemis-0.5",
        "--model", "-m",
        help="Artemis model (Artemis-1, Artemis-0.5, Sonnet-4.6, Opus-4.6)",
    ),
    out_dir: Path = typer.Option(
        Path("./detective_output"),
        "--out-dir", "-o",
        help="Where to save transcripts and report",
        path_type=Path,
    ),
) -> None:
    """Artemis detective — tell it what to find, it harvests and researches for you."""
    user = _get_authenticated_user()
    if not prompt or not prompt.strip():
        _welcome()
        prompt = questionary.text(
            "What would you like Artemis to find out?",
            default="",
            instruction="(e.g. Find everything about what happened to [person name])",
        ).ask()
        if not prompt or not prompt.strip():
            console.print("[yellow]No prompt entered.[/yellow]")
            raise typer.Exit(1)

    if not anthropic_api_key:
        console.print(
            "[red]Anthropic API key required.[/red] Set [bold]ANTHROPIC_API_KEY[/bold] or use [bold]--anthropic-api-key[/bold].\n"
            "[dim]Get a key at console.anthropic.com[/dim]"
        )
        raise typer.Exit(1)

    _welcome()
    console.print(Panel(
        f"[bold]Your request:[/bold] {prompt}\n\n"
        f"[dim]Artemis will search YouTube, TikTok, Instagram, X, read transcripts, and follow leads until it has answers.[/dim]",
        title="[cyan]Detective mode[/cyan]",
        border_style="cyan",
    ))
    console.print()

    from openartemis.agent import ResearchPipeline

    def on_tool(name: str, args: dict) -> None:
        if name == "harvest_transcripts":
            q = args.get("query", "")
            p = args.get("platforms", ["youtube"])
            console.print(f"  [dim]→ Finding videos: [bold]{q}[/bold] on {', '.join(p)}[/dim]")
        elif name == "read_transcript":
            console.print(f"  [dim]→ Reading transcript...[/dim]")
        elif name == "brave_search":
            console.print(f"  [dim]→ Brave search: [bold]{args.get('q', '')}[/bold][/dim]")
        elif name == "fetch_webpage":
            console.print(f"  [dim]→ Fetching: [bold]{args.get('url', '')}[/bold][/dim]")
        elif name == "browse_webpage":
            console.print(f"  [dim]→ Browsing: [bold]{args.get('url', '')}[/bold][/dim]")

    from openartemis.config import resolve_artemis_model
    pipeline = ResearchPipeline(
        anthropic_api_key=anthropic_api_key,
        youtube_api_key=os.environ.get("YOUTUBE_API_KEY"),
        scrapingdog_api_key=os.environ.get("SCRAPINGDOG_API_KEY"),
        transcriptapi_api_key=os.environ.get("TRANSCRIPTAPI_API_KEY"),
        model=resolve_artemis_model(model),
        out_dir=out_dir,
    )

    def _on_tool(name: str, args: dict) -> None:
        on_tool(name, args)
        if name == "harvest_transcripts" and user.get("role") != "admin":
            from openartemis.auth.db import log_usage
            log_usage(user["id"], 1, "investigate")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Artemis is researching...", total=None)
        report = pipeline.run(prompt, on_tool_call=_on_tool)
        progress.update(task, description="[green]✓[/green] Done")

    report_path = out_dir / "report.md"
    report_path.write_text(report, encoding="utf-8")

    console.print()
    console.print(Panel(
        f"[bold green]Report saved to:[/bold green] [cyan]{report_path}[/cyan]\n\n"
        f"[dim]Transcripts: {out_dir}[/dim]",
        title="Done",
        border_style="green",
    ))
    console.print()
    console.print(Panel(report[:2000] + ("..." if len(report) > 2000 else ""), title="Report preview", border_style="dim"))


@app.command()
def admin() -> None:
    """Admin panel — manage users, approve requests, view usage."""
    init_db()
    if get_user_count() == 0:
        console.print("[yellow]No users. Run openartemis first to create admin.[/yellow]")
        raise typer.Exit(1)
    user = get_session_user()
    if not user or user.get("role") != "admin":
        console.print("[bold]Admin login[/bold]")
        username = questionary.text("Username:").ask()
        password = questionary.password("Password:").ask()
        if not username or not password:
            raise typer.Exit(1)
        user = login(username, password)
        if not user or user.get("role") != "admin":
            console.print("[red]Admin access required.[/red]")
            raise typer.Exit(1)
        create_session(user["id"])
    _admin_loop(user)


def _admin_loop(admin_user: dict) -> None:
    """Admin menu loop."""
    from openartemis.auth.db import (
        list_users,
        revoke_user,
        create_user_direct,
        get_usage_by_user,
    )
    while True:
        choice = _select_with_swapped_arrows(
            "Admin:",
            choices=[
                questionary.Choice("Generate invite code", value="invite"),
                questionary.Choice("List all users", value="users"),
                questionary.Choice("View usage (credits per user)", value="usage"),
                questionary.Choice("Create user (direct)", value="create"),
                questionary.Choice("Revoke user access", value="revoke"),
                questionary.Choice("Back (exit admin)", value="back"),
                questionary.Choice("Logout", value="logout"),
            ],
            default=None,
            **_QUESTIONARY_SELECT_OPTS,
        )
        if not choice or choice == "back":
            return
        if choice == "logout":
            revoke_session()
            console.print("[green]Logged out.[/green]")
            raise typer.Exit(0)
        if choice == "invite":
            email = questionary.text("Email for code (optional):").ask() or None
            code, expires = create_invite_code(admin_user["id"], email)
            console.print(Panel(
                f"[bold green]Invite code:[/bold green] [cyan]{code}[/cyan]\n\n"
                f"Expires: {expires.strftime('%Y-%m-%d %H:%M')} UTC\n\n"
                f"[dim]Send this code to the user. They enter it at sign-in.[/dim]",
                title="Invite Code",
                border_style="green",
            ))
            console.print()
        elif choice == "users":
            users = list_users()
            for u in users:
                role = "[admin]" if u["role"] == "admin" else ""
                approved = "✓" if u["approved"] else "pending"
                console.print(f"  {u['id']}: {u['username']} {u['email']} {role} [{approved}]")
            console.print()
        elif choice == "usage":
            usage = get_usage_by_user()
            for u in usage:
                console.print(f"  {u['username']}: {u['total_credits']} credits")
            console.print()
        elif choice == "create":
            email = questionary.text("Email:").ask()
            username = questionary.text("Username:").ask()
            password = questionary.password("Password:").ask()
            if email and username and password:
                ok, msg = create_user_direct(email, username, password, approved=True)
                console.print(f"[green]{msg}[/green]" if ok else f"[red]{msg}[/red]")
            console.print()
        elif choice == "revoke":
            users = list_users()
            for u in users:
                if u["role"] != "admin":
                    console.print(f"  {u['id']}: {u['username']}")
            uid_str = questionary.text("User id to revoke:").ask()
            if uid_str:
                try:
                    uid = int(uid_str)
                    if revoke_user(uid):
                        console.print("[green]Revoked.[/green]")
                    else:
                        console.print("[red]Failed.[/red]")
                except ValueError:
                    console.print("[red]Invalid id.[/red]")
            console.print()


@app.command()
def agent(
    prompt: str = typer.Argument(..., help="What to build (e.g. 'Build a Flappy Bird game')"),
    background: bool = typer.Option(False, "--background", "-b", help="Run in background; check results later"),
    plan: bool = typer.Option(False, "--plan", help="Plan only (read-only); output plan for approval, then run without --plan to execute"),
    direct: bool = typer.Option(False, "--direct", help="Direct build (single model, no multi-step plan) — best for single-file tasks like one index.html"),
    auto_start: bool = typer.Option(False, "--auto-start", help="Fully autonomous: build, download, and auto-start with no prompts"),
) -> None:
    """Agent Mode — build things with AI. Runs until done; supports long tasks."""
    _get_authenticated_user()
    if background:
        _run_agent_background(prompt, plan_mode=plan, direct=direct)
    else:
        _run_agent_foreground(prompt, plan_mode=plan, direct=direct, auto_start=auto_start)


@app.command(hidden=True)
def agent_run(
    prompt: str = typer.Argument(...),
    output_path: str = typer.Argument(...),
    plan: bool = typer.Option(False, "--plan", help="Plan only; no execution"),
    direct: bool = typer.Option(False, "--direct", help="Direct build: single model, full goal, no plan (good for single-file tasks)"),
) -> None:
    """Internal: run agent in background. Do not call directly."""
    load_config()
    _agent_preflight()
    from openartemis.agent.agent_orchestrator import run_agent_mode
    from openartemis.agent.agent_tools import set_agent_workspace

    path = Path(output_path).resolve()
    running_marker = path.parent / f"{path.name}.running"
    workspace_file = path.parent / f"{path.name}.workspace"
    if workspace_file.exists():
        try:
            raw = workspace_file.read_text(encoding="utf-8-sig", errors="replace").strip()
            if raw:
                set_agent_workspace(Path(raw).expanduser().resolve())
        except Exception:
            pass
    env_workspace = os.environ.get("OPENARTEMIS_AGENT_WORKSPACE", "").strip()
    if env_workspace:
        set_agent_workspace(Path(env_workspace).expanduser().resolve())
    try:
        run_agent_mode(prompt, output_path=path, plan_mode=plan, direct_build=direct)
    except Exception as e:
        path.parent.mkdir(parents=True, exist_ok=True)
        full_error = _format_agent_error(e)
        path.write_text(f"# Error\n\n{full_error}", encoding="utf-8")
        done_path = path.parent / (path.stem + ".done")
        try:
            done_path.write_text(
                json.dumps({
                    "outcome": "error",
                    "finished_at": datetime.now().isoformat(),
                    "error": full_error,
                }),
                encoding="utf-8",
            )
        except Exception:
            pass
    finally:
        if running_marker.exists():
            running_marker.unlink(missing_ok=True)


@app.command()
def hooks(
    event: str = typer.Argument(None, help="Filter by event name (omit to list all)"),
) -> None:
    """List registered hooks and hooks.json path. Add hooks via ~/.openartemis/hooks.json."""
    from openartemis.hooks import list_hooks, HOOKS_FILE
    load_config()
    all_hooks = list_hooks()
    if event:
        event = event.strip().lower()
        if event not in all_hooks:
            console.print(f"[red]Unknown event: {event}[/red]")
            raise typer.Exit(1)
        all_hooks = {event: all_hooks[event]}
    for ev, lst in sorted(all_hooks.items()):
        console.print(f"[bold]{ev}[/bold]: {lst or '(none)'}")
    console.print(f"\n[dim]Config: {HOOKS_FILE}[/dim]")
    console.print("[dim]Format: {\"before_edit\": [\"/path/to/script.sh\"], ...}[/dim]\n")


@app.command()
def agent_undo() -> None:
    """Restore the last file edit from the session undo stack (only for edits made in this process)."""
    from openartemis.agent.agent_tools import restore_last_checkpoint
    if restore_last_checkpoint():
        console.print("[green]Restored last edit.[/green]\n")
    else:
        console.print("[yellow]Nothing to undo (stack empty or no edits in this session).[/yellow]\n")


@app.command()
def plan(
    prompt: str = typer.Option(..., "-p", "--prompt", help="What to analyze / plan for"),
) -> None:
    """Headless plan: run read-only and print proposed plan (no execution)."""
    load_config()
    _agent_preflight()
    from openartemis.agent.agent_orchestrator import run_agent_mode
    report = run_agent_mode(prompt, plan_mode=True)
    console.print(Panel(Markdown(report or "(no plan)"), title="[green]Plan[/green]", border_style="green"))
    console.print("[dim]Run the same request without --plan (e.g. openartemis agent \"...\") to execute.[/dim]\n")


@app.command()
def init(
    path: str = typer.Option(
        ".",
        "--path", "-p",
        help="Directory to create OPENARTEMIS.md in (default: current)",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite if OPENARTEMIS.md exists"),
) -> None:
    """Create a starter OPENARTEMIS.md in the project for agent project memory."""
    target = Path(path).resolve()
    if not target.is_dir():
        console.print(f"[red]Not a directory: {target}[/red]")
        raise typer.Exit(1)
    out = target / "OPENARTEMIS.md"
    if out.exists() and not force:
        console.print(f"[yellow]{out} already exists. Use --force to overwrite.[/yellow]")
        raise typer.Exit(0)
    template = """# OpenArtemis project instructions

Instructions here are loaded into the agent context so it follows your conventions.

Examples:
- Stack: "Use Vue 3 + Vite for frontend; Python FastAPI for backend."
- Style: "Prefer functional components; no class components."
- Constraints: "Never commit API keys; use get_secret()."
- Entrypoints: "Main app entry is index.html; run with npm start."
"""
    out.write_text(template, encoding="utf-8")
    console.print(f"[green]Created {out}[/green]")
    console.print("[dim]Edit it to add project conventions; the agent will see it on each run.[/dim]\n")


@app.command()
def permissions(
    mode: str = typer.Argument(
        None,
        help="Set mode: ask, auto-edit, auto-all, or deny-writes (omit to show current)",
    ),
) -> None:
    """Show or set agent permission mode (OPENARTEMIS_PERMISSION_MODE)."""
    from openartemis.config import PERMISSION_MODES
    load_config()
    if mode:
        m = mode.strip().lower()
        if m not in PERMISSION_MODES:
            console.print(f"[red]Invalid mode: {mode}. Use one of: {', '.join(PERMISSION_MODES)}[/red]")
            raise typer.Exit(1)
        os.environ["OPENARTEMIS_PERMISSION_MODE"] = m
        console.print(f"[green]Permission mode set to: {m}[/green]")
    current = get_permission_mode()
    rules = {
        "ask": "Prompt before every edit and run.",
        "auto-edit": "Apply file edits without asking; prompt before run_terminal.",
        "auto-all": "Allow all edits and runs (automation).",
        "deny-writes": "Read-only session; no writes or runs.",
    }
    console.print(f"[dim]Current: {current} — {rules.get(current, '')}[/dim]")
    console.print("[dim]Set with: openartemis permissions <mode> or OPENARTEMIS_PERMISSION_MODE=<mode>[/dim]\n")


@app.command()
def artifacts(
    directory: str = typer.Option(
        "all",
        "--dir", "-d",
        help="Which dir: all, workspace, agent_output, detective_output",
    ),
    limit: int = typer.Option(20, "--limit", "-n", help="Max files to list per dir"),
    path: str = typer.Argument(None, help="Path to a file to show (relative to workspace or absolute)"),
) -> None:
    """List or show artifacts (workspace, agent_output, detective_output)."""
    from openartemis.agent.agent_tools import get_agent_workspace
    workspace = get_agent_workspace()
    agent_out = get_agent_output_dir()
    detective_out = Path("./detective_output")
    dirs: list[tuple[str, Path]] = []
    if directory == "all":
        dirs = [("workspace", workspace), ("agent_output", agent_out), ("detective_output", detective_out)]
    elif directory == "workspace":
        dirs = [("workspace", workspace)]
    elif directory == "agent_output":
        dirs = [("agent_output", agent_out)]
    elif directory == "detective_output":
        dirs = [("detective_output", detective_out)]
    else:
        console.print("[yellow]Use --dir all|workspace|agent_output|detective_output[/yellow]")
        raise typer.Exit(1)
    if path:
        p = Path(path)
        if not p.is_absolute():
            p = (workspace / path).resolve()
        if not p.exists():
            console.print(f"[red]File not found: {p}[/red]")
            raise typer.Exit(1)
        if p.is_dir():
            console.print("[red]Path is a directory. Use list view (omit path).[/red]")
            raise typer.Exit(1)
        console.print(Panel(p.read_text(encoding="utf-8", errors="replace")[:50000], title=str(p), border_style="cyan"))
        return
    for label, base in dirs:
        if not base.exists():
            continue
        console.print(f"[bold]{label}[/bold] [dim]({base})[/dim]")
        files: list[Path] = []
        for f in base.rglob("*"):
            if f.is_file():
                files.append(f)
        files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
        for f in files[:limit]:
            try:
                mtime = datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
                rel = f.relative_to(base) if base in f.parents or f.parent == base else f.name
                console.print(f"  [cyan]{rel}[/cyan]  [dim]{mtime}[/dim]")
            except ValueError:
                console.print(f"  [cyan]{f.name}[/cyan]")
        if len(files) > limit:
            console.print(f"  [dim]... and {len(files) - limit} more[/dim]")
        console.print()


@app.command()
def export_bundle(
    report_path: str = typer.Argument(..., help="Path to agent report .md or checkpoint .checkpoint.json"),
    output_dir: str = typer.Option(None, "--output", "-o", help="Output folder (default: ./openartemis_bundle_<timestamp>)"),
) -> None:
    """Export a run as a reproducible bundle (prompt, plan, env names, re-run command)."""
    p = Path(report_path)
    if not p.exists():
        console.print(f"[red]Not found: {p}[/red]")
        raise typer.Exit(1)
    if p.suffix == ".json" and ".checkpoint" in p.stem:
        checkpoint_path = p
        output_md = p.parent / (p.stem.replace(".checkpoint", "") + ".md")
    else:
        output_md = p
        checkpoint_path = p.parent / (p.stem + ".checkpoint.json")
    try:
        data = json.loads(checkpoint_path.read_text(encoding="utf-8")) if checkpoint_path.exists() else {}
    except (json.JSONDecodeError, OSError):
        data = {}
    user_request = data.get("user_request", "")
    if not user_request and output_md.exists():
        first_line = output_md.read_text(encoding="utf-8", errors="replace").split("\n")[0]
        if first_line.startswith("# Agent Report — "):
            user_request = first_line.replace("# Agent Report — ", "").strip()
    if not user_request:
        user_request = "(unknown request)"
    out = Path(output_dir or f"./openartemis_bundle_{datetime.now().strftime('%Y%m%d_%H%M')}")
    out.mkdir(parents=True, exist_ok=True)
    (out / "prompt.txt").write_text(user_request, encoding="utf-8")
    (out / "env_vars.txt").write_text(
        "OPENAI_API_KEY\nOPENARTEMIS_PROFILE\nOPENARTEMIS_MAX_CREDITS\nOPENARTEMIS_MAX_TOKENS\n"
        "OPENARTEMIS_AGENT_OUTPUT_DIR\nOPENARTEMIS_TPM_LIMIT\n",
        encoding="utf-8",
    )
    if data.get("steps"):
        (out / "plan.json").write_text(json.dumps({"steps": data["steps"]}, indent=2), encoding="utf-8")
    prompt_preview = user_request[:200] + ("..." if len(user_request) > 200 else "")
    (out / "README.md").write_text(
        f"# OpenArtemis run bundle\n\nOriginal prompt: {prompt_preview}\n\n"
        "Re-run: `openartemis agent \"<prompt.txt content>\"`\n"
        "Resume from checkpoint: copy .checkpoint.json and .md to ~/.openartemis/agent_output/ then `openartemis agent-resume`\n",
        encoding="utf-8",
    )
    if output_md.exists():
        import shutil
        shutil.copy(output_md, out / "report.md")
    console.print(f"[green]Bundle written to {out}[/green]")
    console.print(f"  prompt.txt, env_vars.txt, README.md" + (", plan.json, report.md" if data.get("steps") else "") + "\n")


@app.command()
def agent_resume(
    checkpoint_file: str = typer.Argument(
        None,
        help="Path to .checkpoint.json (default: latest in ~/.openartemis/agent_output)",
    ),
) -> None:
    """Resume an agent run from its last checkpoint."""
    load_config()
    from openartemis.agent.agent_orchestrator import run_agent_mode

    get_agent_output_dir().mkdir(parents=True, exist_ok=True)
    checkpoints = sorted(get_agent_output_dir().glob("*.checkpoint.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not checkpoints:
        console.print("[yellow]No checkpoints found. Run an agent task first (it checkpoints after each step).[/yellow]")
        raise typer.Exit(1)
    if checkpoint_file:
        path = Path(checkpoint_file)
        if not path.exists():
            console.print(f"[red]Checkpoint file not found: {path}[/red]")
            raise typer.Exit(1)
    else:
        path = checkpoints[0]
        console.print(f"[dim]Using latest checkpoint: {path.name}[/dim]\n")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        console.print(f"[red]Invalid checkpoint: {e}[/red]")
        raise typer.Exit(1)
    user_request = data.get("user_request", "")
    if not user_request:
        console.print("[red]Checkpoint has no user_request.[/red]")
        raise typer.Exit(1)
    output_path = path.parent / (path.stem.replace(".checkpoint", "") + ".md")
    console.print(f"[dim]Resuming: {user_request[:60]}...[/dim]\n")
    try:
        report = run_agent_mode(user_request, output_path=output_path, resume_from_checkpoint=True)
        console.print(Panel(Markdown(report or "(no output)"), title="[green]Agent Report[/green]", border_style="green"))
        console.print(f"[dim]Saved to {output_path}[/dim]\n")
    except Exception as e:
        console.print(f"[red]Resume failed: {_format_agent_error(e)}[/red]")
        raise typer.Exit(1)


def _agent_job_card_data(running_path: Path) -> dict[str, Any]:
    """Given a .running path, read .status, checkpoint, .workspace, .blockers, .replay.jsonl; return dict for the Now Running card."""
    parent = running_path.parent
    base_name = running_path.name.replace(".running", "")
    base_stem = Path(base_name).stem
    status_path = parent / (base_name + ".status")
    checkpoint_path = parent / (base_stem + ".checkpoint.json")
    replay_path = parent / (base_stem + ".replay.jsonl")
    workspace_path_file = parent / (base_name + ".workspace")
    blockers_path = parent / (base_name + ".blockers")
    pause_path = parent / (base_name + ".pause")
    throttled_path = parent / (base_stem + ".throttled")

    # Read .running file — may be JSON (new format) or plain text (old format)
    _running_text = ""
    _running_started_at: float | None = None
    if running_path.exists():
        try:
            _running_text = running_path.read_text(encoding="utf-8", errors="replace").strip()
        except OSError:
            _running_text = ""
        # Try JSON format first (has started_at timestamp)
        try:
            _running_data = json.loads(_running_text)
            if isinstance(_running_data, dict):
                job_name = (_running_data.get("request") or "")[:50]
                _running_started_at = _running_data.get("started_at")
            else:
                job_name = (_running_text.splitlines() or [""])[0][:50]
        except (json.JSONDecodeError, ValueError):
            job_name = (_running_text.splitlines() or [""])[0][:50]
    else:
        md_path = parent / base_name
        job_name = (md_path.read_text(encoding="utf-8", errors="replace").strip().splitlines() or [""])[0][:50] if md_path.exists() else (base_stem[:50] or "Agent run")
    # Prefer short slug from stem for display (e.g. 2026-03-01_17-15_flappy-birds -> "flappy-birds")
    if base_stem.count("_") >= 2:
        slug = base_stem.split("_", 2)[-1].replace("_", "-")
        if slug:
            job_name = slug
    phase = "Build"
    current_step = ""
    step_index = 0
    total_steps = 0
    last_activity = ""
    last_output_line = ""
    workspace_path: str | None = None
    artifacts: list[str] = []
    blocker_text = ""
    # Use the started_at from .running JSON if available (accurate); fall back to mtime
    start_time: float | None = _running_started_at
    recent_tool_calls: list[dict[str, Any]] = []
    recent_screenshots: list[str] = []
    recent_terminal_lines: list[str] = []
    rate_limit_count = 0
    retry_count = 0
    last_heartbeat: float | None = None
    paused = pause_path.exists()
    terminal_path = parent / (base_stem + ".terminal")

    if checkpoint_path.exists():
        try:
            data = json.loads(checkpoint_path.read_text(encoding="utf-8"))
            steps = data.get("steps") or []
            step_index = min(data.get("step_index", 0), len(steps))
            total_steps = len(steps)
            if step_index == 0:
                phase = "Plan"
            if steps and 0 <= step_index < len(steps):
                current_step = (steps[step_index].get("action") or "")[:60]
        except (json.JSONDecodeError, OSError):
            pass

    recent_status_lines: list[str] = []
    if status_path.exists():
        try:
            last_heartbeat = status_path.stat().st_mtime
            lines = status_path.read_text(encoding="utf-8", errors="replace").strip().splitlines()
            if lines:
                recent_status_lines = lines[-5:]
                last_line = lines[-1]
                last_output_line = last_line.strip()
                if re.match(r"^\d{2}:\d{2}:\d{2}\s+", last_line):
                    last_activity = last_line[:8].strip()
                if not last_activity and status_path.exists():
                    last_activity = datetime.fromtimestamp(status_path.stat().st_mtime).strftime("%H:%M:%S")
                # Detect Agent OS phases from status lines
                for sline in reversed(lines[-10:]):
                    sl = sline.lower()
                    if "phase 1" in sl or "building" in sl:
                        phase = "Build"
                        break
                    elif "phase 2" in sl or "verifying" in sl:
                        phase = "Verify"
                        break
                    elif "phase 3" in sl or "fixing" in sl:
                        phase = "Fix"
                        break
                    elif "phase 4" in sl or "report complete" in sl:
                        phase = "Report"
                        break
                if start_time is None:
                    # Fall back to running file mtime if no JSON timestamp
                    try:
                        start_time = running_path.stat().st_mtime if running_path.exists() else None
                    except OSError:
                        pass
        except OSError:
            pass
    if start_time is None and running_path.exists():
        start_time = running_path.stat().st_mtime

    if workspace_path_file.exists():
        try:
            workspace_path = workspace_path_file.read_text(encoding="utf-8", errors="replace").strip()
        except OSError:
            pass
    if workspace_path:
        try:
            wp = Path(workspace_path).expanduser().resolve()
            if wp.is_dir():
                artifacts = sorted(
                    [p.name for p in wp.iterdir() if p.is_file()],
                    key=lambda n: (wp / n).stat().st_mtime,
                    reverse=True,
                )[:8]
        except OSError:
            pass

    if blockers_path.exists():
        try:
            blines = blockers_path.read_text(encoding="utf-8", errors="replace").strip().splitlines()
            if blines:
                blocker_text = blines[-1].strip()
        except OSError:
            pass

    if replay_path.exists():
        try:
            rlines = replay_path.read_text(encoding="utf-8", errors="replace").strip().splitlines()
            for line in rlines[-50:]:
                try:
                    obj = json.loads(line)
                    if not isinstance(obj, dict):
                        continue
                    if "tool" in obj:
                        raw_args = obj.get("args", {})
                        args = raw_args if isinstance(raw_args, dict) else {}
                        recent_tool_calls.append({"tool": obj["tool"], "args": args})
                        if obj.get("tool") == "take_screenshot":
                            url = args.get("url_or_path", "")
                            if url:
                                recent_screenshots.append(url)
                    if obj.get("event") == "rate_limit":
                        rate_limit_count += 1
                    if obj.get("event") == "retry":
                        retry_count += 1
                except (json.JSONDecodeError, TypeError):
                    pass
            recent_tool_calls = recent_tool_calls[-5:]
            recent_screenshots = recent_screenshots[-5:]
        except OSError:
            pass
    if terminal_path.exists():
        try:
            tlines = terminal_path.read_text(encoding="utf-8", errors="replace").strip().splitlines()
            recent_terminal_lines = tlines[-10:]
        except OSError:
            pass

    eta_seconds: int | None = None
    if total_steps and step_index < total_steps:
        eta_seconds = (total_steps - step_index) * 60

    next_up = ""
    task_list: list[tuple[int, str]] = []
    if checkpoint_path.exists() and total_steps:
        try:
            data = json.loads(checkpoint_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                data = {}
            steps = data.get("steps") or []
            for i in range(step_index, min(step_index + 5, len(steps))):
                step = steps[i] if i < len(steps) else {}
                action = (step.get("action") or "")[:55] if isinstance(step, dict) else ""
                task_list.append((i + 1, action))
            if step_index + 1 < len(steps):
                step = steps[step_index + 1]
                next_up = (step.get("action") or "")[:60] if isinstance(step, dict) else ""
        except (json.JSONDecodeError, OSError):
            pass

    throttled_retry_until: float | None = None
    if throttled_path.exists():
        try:
            raw = throttled_path.read_text(encoding="utf-8", errors="replace").strip()
            if raw.startswith("retry_until:"):
                throttled_retry_until = float(raw.split(":", 1)[1])
        except (ValueError, OSError):
            pass
    is_throttled = bool(
        throttled_retry_until is not None
        or (recent_status_lines and recent_status_lines[-1].strip().split(maxsplit=1)[-1].startswith("THROTTLED"))
    )

    return {
        "job_name": job_name,
        "phase": phase,
        "current_step": current_step,
        "next_up": next_up,
        "task_list": task_list,
        "step_index": step_index,
        "total_steps": total_steps,
        "last_activity": last_activity,
        "last_output_line": last_output_line,
        "recent_status_lines": recent_status_lines,
        "workspace_path": workspace_path,
        "artifacts": artifacts,
        "blocker_text": blocker_text,
        "start_time": start_time,
        "status_path": status_path,
        "output_stem": base_stem,
        "running_path": running_path,
        "recent_tool_calls": recent_tool_calls,
        "rate_limit_count": rate_limit_count,
        "retry_count": retry_count,
        "last_heartbeat": last_heartbeat,
        "paused": paused,
        "eta_seconds": eta_seconds,
        "recent_screenshots": recent_screenshots,
        "recent_terminal_lines": recent_terminal_lines,
        "throttled_retry_until": throttled_retry_until,
        "is_throttled": is_throttled,
    }


def _agent_watchdog_sweep(
    stale_heartbeat_sec: int = 60,
    max_age_sec: int = 30 * 60,
) -> None:
    """Mark obviously stalled agent runs as failed.

    Sweeps BOTH .status files with no heartbeat AND orphaned .running files
    with no recent .status update. This prevents "forever planning" ghosts.
    """
    out_dir = get_agent_output_dir()
    out_dir.mkdir(parents=True, exist_ok=True)
    now = time.time()

    def _mark_stale(base_name: str, base_stem: str, last_line: str = "") -> None:
        done_path = out_dir / f"{base_stem}.done"
        if done_path.exists():
            return
        msg = (
            f"Watchdog: no heartbeat for >{stale_heartbeat_sec}s "
            f"(last: {last_line or 'unknown'}). Marked as failed."
        )
        report_md = out_dir / base_name
        if not report_md.exists():
            try:
                report_md.write_text(f"# Error\n\n{msg}\n", encoding="utf-8")
            except OSError:
                pass
        try:
            done_path.write_text(json.dumps({
                "outcome": "error",
                "finished_at": datetime.now().isoformat(),
                "error": msg,
                "watchdog": True,
            }), encoding="utf-8")
        except OSError:
            pass
        running_marker = out_dir / f"{base_name}.running"
        if running_marker.exists():
            try:
                running_marker.unlink(missing_ok=True)
            except OSError:
                pass

    # Sweep 1: .status files with no heartbeat
    for status_path in out_dir.glob("*.status"):
        try:
            base_name = status_path.name.replace(".status", "")
            base_stem = Path(base_name).stem
            if (out_dir / f"{base_stem}.done").exists():
                continue
            age = now - status_path.stat().st_mtime
            if age < stale_heartbeat_sec or age > max_age_sec:
                continue
            try:
                lines = status_path.read_text(encoding="utf-8", errors="replace").strip().splitlines()
            except OSError:
                lines = []
            _mark_stale(base_name, base_stem, (lines[-1].strip() if lines else ""))
        except Exception:
            continue

    # Sweep 2: orphaned .running files with no .status or stale .status
    for running_path in out_dir.glob("*.running"):
        try:
            base_name = running_path.name.replace(".running", "")
            base_stem = Path(base_name).stem
            if (out_dir / f"{base_stem}.done").exists():
                continue
            status_path = out_dir / (base_name + ".status")
            if status_path.exists():
                age = now - status_path.stat().st_mtime
                if age < stale_heartbeat_sec:
                    continue  # has recent heartbeat, still alive
            else:
                # No .status at all — check age of .running file itself
                age = now - running_path.stat().st_mtime
                if age < stale_heartbeat_sec:
                    continue  # just started, give it time
            _mark_stale(base_name, base_stem, "no status file")
        except Exception:
            continue


def _agent_status_renderable(workspace: str | None = None):
    """Build agent status dashboard: one-line state, then Now Running (if any) and recent runs.

    When workspace is set, only show runs whose recorded workspace matches that path.
    """
    from rich.console import Group

    out_dir = get_agent_output_dir()
    out_dir.mkdir(parents=True, exist_ok=True)
    # Before building the dashboard, run a quick watchdog sweep so obviously
    # stalled runs are marked as failed rather than appearing "stuck planning".
    _agent_watchdog_sweep()
    running_list = sorted(out_dir.glob("*.running"), key=lambda p: p.stat().st_mtime, reverse=True)
    done_stems = {p.stem for p in out_dir.glob("*.done")}
    now = time.time()
    IN_PROGRESS_MD_AGE_SEC = 30 * 60
    workspace_filter: Path | None = None
    if workspace:
        try:
            workspace_filter = Path(workspace).expanduser().resolve()
        except Exception:
            workspace_filter = None

    used_fallback = False
    if not running_list:
        md_without_done = [
            p for p in out_dir.glob("*.md")
            if p.stem not in done_stems and (now - p.stat().st_mtime) < IN_PROGRESS_MD_AGE_SEC
        ]
        if md_without_done:
            newest_md = max(md_without_done, key=lambda p: p.stat().st_mtime)
            running_list = [out_dir / (newest_md.name + ".running")]
            used_fallback = True
    # Fallback 2: jobs that have .workspace/.status/checkpoint but no .running or .done yet,
    # and whose status file has been updated recently (fresh heartbeat). This avoids
    # treating long-dead jobs as "running forever".
    if not running_list:
        fresh_workspace_only: list[Path] = []
        for ws_file in out_dir.glob("*.workspace"):
            if ws_file.stem in done_stems:
                continue
            if (now - ws_file.stat().st_mtime) >= IN_PROGRESS_MD_AGE_SEC:
                continue
            status_path = out_dir / (ws_file.stem + ".status")
            if status_path.exists() and (now - status_path.stat().st_mtime) < 45:
                fresh_workspace_only.append(ws_file)
        if fresh_workspace_only:
            newest_ws = max(fresh_workspace_only, key=lambda p: p.stat().st_mtime)
            # Workspace files are named like "<basename>.md.workspace".
            # Reconstruct the synthetic .running marker as "<basename>.md.running"
            synthetic_running = out_dir / (newest_ws.stem + ".running")
            running_list = [synthetic_running]
            used_fallback = True

    if workspace_filter:
        filtered_running: list[Path] = []
        for rp in running_list:
            try:
                card = _agent_job_card_data(rp)
            except Exception:
                continue
            wp = card.get("workspace_path")
            if not wp:
                continue
            try:
                if Path(wp).expanduser().resolve() == workspace_filter:
                    filtered_running.append(rp)
            except Exception:
                continue
        running_list = filtered_running

    done_files = sorted(out_dir.glob("*.done"), key=lambda p: p.stat().st_mtime, reverse=True)
    if workspace_filter:
        filtered_done: list[Path] = []
        for df in done_files:
            base_name = df.name.replace(".done", "")
            wp_file = df.parent / (base_name + ".workspace")
            if not wp_file.exists():
                continue
            try:
                raw = wp_file.read_text(encoding="utf-8", errors="replace").strip()
                if not raw:
                    continue
                wp = Path(raw).expanduser().resolve()
            except Exception:
                continue
            if wp == workspace_filter:
                filtered_done.append(df)
        done_files = filtered_done

    parts: list[Any] = []

    if running_list:
        active = running_list[0]
        card = _agent_job_card_data(active)
        si = (card.get("step_index") or 0) + 1
        ts = card.get("total_steps") or 0
        step_label = f"step {si}/{ts}" if ts > 0 else f"step {si} (planning…)"
        state_line = f"Agent: [cyan]running[/cyan] ({step_label})"
        if used_fallback:
            state_line += " [dim](no .running marker)[/dim]"
    elif done_files:
        try:
            latest_done = done_files[0]
            data = json.loads(latest_done.read_text(encoding="utf-8", errors="replace"))
            if not isinstance(data, dict):
                data = {}
            outcome = data.get("outcome", "unknown")
            finished_at = data.get("finished_at", "")
            try:
                ts = datetime.fromisoformat(finished_at.replace("Z", "+00:00")).strftime("%H:%M")
            except Exception:
                ts = finished_at[:16] if finished_at else "—"
            stem = latest_done.stem
            short_name = stem.split("_", 2)[-1].replace("_", "-") if stem.count("_") >= 2 else stem[:30]
            if outcome == "success":
                state_line = f"Agent: last run [green]succeeded[/green] at {ts} — {short_name}"
            elif outcome == "plan":
                state_line = f"Agent: last run [green]plan ready[/green] at {ts} — {short_name} [dim](run Agent again without Plan-only to execute)[/dim]"
            elif outcome == "canceled":
                state_line = f"Agent: last run [yellow]canceled[/yellow] at {ts} — {short_name}"
            else:
                state_line = f"Agent: last run [red]failed[/red] at {ts} — {short_name}"
        except (json.JSONDecodeError, OSError):
            state_line = "Agent: [dim]idle[/dim] (no runs yet)."
    else:
        if workspace_filter:
            state_line = f"Agent: [dim]idle[/dim] (no runs yet for this workspace: {workspace_filter})."
        else:
            state_line = "Agent: [dim]idle[/dim] (no runs yet)."
    parts.append(Panel(state_line, title="[bold]Status[/bold]", border_style="dim"))
    parts.append("")

    if running_list:
        active = running_list[0]
        card = _agent_job_card_data(active)
        job_name = (card.get("job_name") or "").strip() or "Agent run"
        phase = card.get("phase") or "Build"
        step_index = card.get("step_index") or 0
        total_steps = card.get("total_steps") or 0
        current_step = (card.get("current_step") or "").strip()
        last_output = (card.get("last_output_line") or "").strip()
        last_activity = (card.get("last_activity") or "").strip()
        start_time = card.get("start_time")
        recent_lines = card.get("recent_status_lines") or []
        artifacts = card.get("artifacts") or []
        blocker_text = (card.get("blocker_text") or "").strip()
        workspace_path = card.get("workspace_path")
        recent_tool_calls = card.get("recent_tool_calls") or []
        rate_limit_count = card.get("rate_limit_count") or 0
        retry_count = card.get("retry_count") or 0
        last_heartbeat = card.get("last_heartbeat")
        paused = card.get("paused") is True
        eta_seconds = card.get("eta_seconds")
        next_up = (card.get("next_up") or "").strip()
        is_throttled = card.get("is_throttled") is True
        throttled_retry_until = card.get("throttled_retry_until")

        step_progress = f"Step {step_index + 1}/{total_steps}" if total_steps else f"Step {step_index + 1} (planning…)"
        time_since = ""
        if start_time:
            delta = time.time() - start_time
            if delta < 60:
                time_since = f"{int(delta)}s"
            else:
                time_since = f"{int(delta // 60)}m {int(delta % 60)}s"
        else:
            time_since = "—"
        heartbeat_dot = ""
        if last_heartbeat and (time.time() - last_heartbeat) < 30:
            heartbeat_dot = " [green]●[/green]"
        else:
            heartbeat_dot = " [dim]○[/dim]"

        header = f"[bold]⠋[/bold] {job_name}{heartbeat_dot}  [dim]|[/dim]  [cyan]{phase}[/cyan]  [dim]|[/dim]  {step_progress}  [dim]|[/dim]  {time_since}"
        if last_activity:
            header += f"  [dim]|[/dim]  Last: {last_activity}"
        if eta_seconds is not None:
            header += f"  [dim]|[/dim]  ETA ~{eta_seconds // 60}m"
        if rate_limit_count:
            header += f"  [yellow] Rate limited[/yellow]"
        if retry_count:
            header += f"  [dim] Retries: {retry_count}[/dim]"

        card_lines = [header]
        if last_output:
            card_lines.append(f"  [dim]{last_output[:95]}[/dim]")
        if phase == "Plan" or (start_time and (time.time() - start_time) > 60 and step_index == 0):
            card_lines.append("  [dim]Plan and first step may take 1–2 min (calling model).[/dim]")
        if is_throttled:
            countdown_s = ""
            if throttled_retry_until is not None and throttled_retry_until > time.time():
                countdown_s = f" {max(0, int(throttled_retry_until - time.time()))}s"
            card_lines.append("")
            card_lines.append("  [bold yellow]Rate limited — resuming in" + countdown_s + "[/bold yellow]")
            card_lines.append("")
        if paused:
            card_lines.append("")
            card_lines.append("  [bold yellow]⏸ Paused — run openartemis agent-unpause to continue[/bold yellow]")
            card_lines.append("")
        if total_steps and step_index <= total_steps:
            # Current step (1-based) so bar matches "Step 5/10" text
            current_one = step_index + 1
            filled = 20 * current_one // max(1, total_steps)
            prog_bar = "  " + "█" * filled + "░" * (20 - filled) + f"  {current_one}/{total_steps}"
            card_lines.append(f"  [dim]{prog_bar}[/dim]")
        task_list = card.get("task_list") or []
        if task_list and total_steps:
            card_lines.append("  [dim]Task list:[/dim]")
            for num, action in task_list:
                marker = "→" if num == step_index + 1 else " "
                card_lines.append(f"  [dim]  {marker} Step {num}/{total_steps}:[/dim] {action or '…'}")
        elif current_step:
            card_lines.append(f"  [dim]Current:[/dim] {current_step}")
        if next_up and not task_list:
            card_lines.append(f"  [dim]Next up:[/dim] {next_up}")
        if recent_tool_calls:
            toasts = []
            for tc in recent_tool_calls[-3:]:
                name = tc.get("tool", "?") if isinstance(tc, dict) else "?"
                args = tc.get("args") if isinstance(tc, dict) else None
                if not isinstance(args, dict):
                    args = {}
                cmd = (args.get("command") or args.get("path") or str(args)[:30])
                toasts.append(f"{name}({cmd}...)")
            card_lines.append(f"  [dim]Tools:[/dim] {'  →  '.join(toasts)}")
        recent_screenshots = card.get("recent_screenshots") or []
        if recent_screenshots:
            card_lines.append(f"  [dim]Screenshots:[/dim] {', '.join(recent_screenshots[-3:])}")
        recent_terminal_lines = card.get("recent_terminal_lines") or []
        if recent_terminal_lines:
            card_lines.append("")
            card_lines.append("  [dim]Terminal (last lines):[/dim]")
            for ln in recent_terminal_lines[-4:]:
                if ln.strip():
                    card_lines.append(f"  [dim]  {ln.strip()[:70]}[/dim]")
        card_lines.append("")
        for line in recent_lines:
            if line.strip():
                card_lines.append(f"  [dim]{line.strip()}[/dim]")
        if artifacts:
            card_lines.append("")
            card_lines.append(f"  [dim]Artifacts:[/dim] {', '.join(artifacts[:8])}")
        if workspace_path:
            card_lines.append(f"  [dim]Workspace:[/dim] {workspace_path}")
        if blocker_text:
            card_lines.append("")
            card_lines.append(f"  [red]{blocker_text}[/red]")
        card_lines.append("")
        card_lines.append("  [dim]Enter=refresh, R=report, L=logs. To cancel: [bold]openartemis agent-cancel[/bold]. To pause: agent-pause / agent-unpause.[/dim]")

        parts.append(Panel("\n".join(card_lines), title="[bold]Now Running[/bold]", border_style="cyan"))
        parts.append("")

    return Group(*parts) if parts else Panel("[dim]No agent runs yet.[/dim]", title="Agent status", border_style="dim")


def _agent_tree_renderable() -> Tree:
    """Build a tree view: Goal -> Step 1, Step 2, ... from checkpoints and running jobs."""
    get_agent_output_dir().mkdir(parents=True, exist_ok=True)
    tree = Tree("[bold]Agent runs[/bold]")
    running = list(get_agent_output_dir().glob("*.running"))
    checkpoints = sorted(get_agent_output_dir().glob("*.checkpoint.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:10]
    for r in running:
        req = r.read_text(encoding="utf-8", errors="replace")[:50]
        branch = tree.add(f"[yellow]Running:[/yellow] {req}...")
        base = r.stem.replace(".running", "").replace(".md", "")
        ckp = r.parent / (base + ".checkpoint.json")
        if ckp.exists():
            try:
                data = json.loads(ckp.read_text(encoding="utf-8"))
                for s in (data.get("steps") or [])[:20]:
                    step_id = s.get("id", "?")
                    action = (s.get("action") or "")[:45]
                    branch.add(f"Step {step_id}: {action}...")
            except (json.JSONDecodeError, OSError):
                pass
    for cp in checkpoints:
        try:
            data = json.loads(cp.read_text(encoding="utf-8"))
            req = (data.get("user_request") or "")[:45]
            steps = data.get("steps") or []
            idx = data.get("step_index", 0)
            label = f"[green]{cp.stem.replace('.checkpoint', '')}[/green] — {req}..."
            branch = tree.add(label)
            for i, s in enumerate(steps[:15]):
                step_id = s.get("id", i + 1)
                action = (s.get("action") or "")[:40]
                done = "[green]✓[/green] " if i < idx else ""
                branch.add(f"{done}Step {step_id}: {action}...")
        except (json.JSONDecodeError, OSError):
            tree.add(f"[dim]{cp.name}[/dim]")
    if not running and not checkpoints:
        tree.add("[dim]No agent runs or checkpoints yet.[/dim]")
    return tree


def _run_agent_status_continuous(workspace: str | None = None) -> None:
    """Show agent status in a live-updating view until the user stops.

    This keeps refreshing even after a job finishes so that new jobs
    started elsewhere become visible. Press Ctrl+C to stop watching.
    """
    get_agent_output_dir().mkdir(parents=True, exist_ok=True)
    try:
        with Live(_agent_status_renderable(workspace), console=console, refresh_per_second=4) as live:
            while True:
                time.sleep(0.25)
                live.update(_agent_status_renderable(workspace))
    except KeyboardInterrupt:
        pass
    console.print("[dim]Stopped watching.[/dim]\n")


@app.command()
def agent_status(
    tree: bool = typer.Option(False, "--tree", "-t", help="Show hierarchy (goal → steps) from checkpoints"),
    follow: bool = typer.Option(False, "--follow", "-f", help="Live refresh until no running job or Ctrl+C"),
    watch: bool = typer.Option(False, "--watch", "-w", help="Same as --follow: live refresh 4×/sec"),
    workspace: str | None = typer.Option(
        None,
        "--workspace",
        "-wsp",
        help="Only show runs whose workspace path matches this directory",
    ),
) -> None:
    """Show recent agent runs and their status."""
    if tree:
        console.print(_agent_tree_renderable())
    elif follow or watch:
        _run_agent_status_continuous(workspace)
    else:
        console.print(_agent_status_renderable(workspace))


def _agent_runs_list(limit: int = 50) -> list[tuple[Path, str, str, bool]]:
    """Return list of (path, mtime_str, title, failed) for completed .md runs, newest first."""
    get_agent_output_dir().mkdir(parents=True, exist_ok=True)
    completed = sorted(get_agent_output_dir().glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]
    out = []
    for p in completed:
        try:
            mtime_str = datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
            content = p.read_text(encoding="utf-8", errors="replace").strip()
            failed = content.strip().startswith("# Error")
            title = (content.split("\n")[0] or p.stem).replace("# ", "").replace("Agent Report — ", "").strip()[:50]
            out.append((p, mtime_str, title, failed))
        except OSError:
            out.append((p, "—", p.name, False))
    return out


@app.command()
def agent_cancel() -> None:
    """Request cancellation of the current background agent run. The run will stop after the current step."""
    get_agent_output_dir().mkdir(parents=True, exist_ok=True)
    running_list = sorted(get_agent_output_dir().glob("*.running"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not running_list:
        console.print("[yellow]No agent run in progress.[/yellow]")
        return
    active = running_list[0]
    base_name = active.name.replace(".running", "")
    cancel_file = active.parent / (base_name + ".cancel")
    try:
        cancel_file.write_text("", encoding="utf-8")
        console.print("[green]Cancel requested.[/green] The run will stop after the current step.")
    except OSError as e:
        console.print(f"[red]Could not write cancel file: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def agent_pause() -> None:
    """Pause the current background agent run. The run will wait until you run openartemis agent-unpause."""
    get_agent_output_dir().mkdir(parents=True, exist_ok=True)
    running_list = sorted(get_agent_output_dir().glob("*.running"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not running_list:
        console.print("[yellow]No agent run in progress.[/yellow]")
        return
    active = running_list[0]
    base_name = active.name.replace(".running", "")
    pause_file = active.parent / (base_name + ".pause")
    try:
        pause_file.write_text("", encoding="utf-8")
        console.print("[green]Pause requested.[/green] Run [bold]openartemis agent-unpause[/bold] to continue.")
    except OSError as e:
        console.print(f"[red]Could not write pause file: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def agent_unpause() -> None:
    """Resume a paused background agent run."""
    get_agent_output_dir().mkdir(parents=True, exist_ok=True)
    running_list = sorted(get_agent_output_dir().glob("*.running"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not running_list:
        console.print("[yellow]No agent run in progress.[/yellow]")
        return
    active = running_list[0]
    base_name = active.name.replace(".running", "")
    pause_file = active.parent / (base_name + ".pause")
    if not pause_file.exists():
        console.print("[dim]Run is not paused.[/dim]")
        return
    try:
        pause_file.unlink(missing_ok=True)
        console.print("[green]Unpaused.[/green] The run will continue.")
    except OSError as e:
        console.print(f"[red]Could not remove pause file: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def runs(
    limit: int = typer.Option(50, "--limit", "-n", help="Max number of runs to list"),
) -> None:
    """List agent run history (one line per run)."""
    rows = _agent_runs_list(limit=limit)
    if not rows:
        console.print("[dim]No agent runs yet.[/dim]")
        return
    for p, mtime_str, title, failed in rows:
        icon = "[red]✗[/red]" if failed else "[green]✓[/green]"
        console.print(f"  {mtime_str}  {icon}  {title}  [dim]{p.name}[/dim]")


@app.command()
def dashboard(
    port: int = typer.Option(8765, "--port", "-p", help="Port for local dashboard (default: 8765)"),
) -> None:
    """Run a minimal local web dashboard showing recent agent runs.

    If the Artemis daemon is running (and OPENARTEMIS_IDE_RUNTIME_ENABLED is
    set), the dashboard will try to show daemon jobs. Otherwise it falls back
    to the filesystem-based agent_output view.
    """
    from http.server import BaseHTTPRequestHandler, HTTPServer
    import json
    import os
    from urllib.request import urlopen
    from urllib.error import URLError

    out_dir = get_agent_output_dir()
    out_dir.mkdir(parents=True, exist_ok=True)

    # Try to read jobs from daemon if available.
    daemon_jobs: list[dict[str, object]] = []
    daemon_url = os.environ.get("OPENARTEMIS_DAEMON_URL", "http://127.0.0.1:8787")
    use_daemon = os.environ.get("OPENARTEMIS_IDE_RUNTIME_ENABLED", "").strip().lower() in {"1", "true", "yes", "on"}
    if use_daemon:
        try:
            with urlopen(f"{daemon_url}/jobs", timeout=1.0) as resp:  # type: ignore[attr-defined]
                data = json.loads(resp.read().decode("utf-8"))
                daemon_jobs = list(data.get("jobs") or [])
        except URLError:
            daemon_jobs = []

    rows = _agent_runs_list(limit=200)

    class _Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # type: ignore[override]
            if self.path not in ("/", "/index.html"):
                self.send_response(404)
                self.end_headers()
                return
            runs_html = ""
            if daemon_jobs:
                runs_html += "<h2>Daemon jobs</h2>"
                runs_html += "<table><tr><th>Id</th><th>Status</th><th>Mode</th><th>Prompt</th></tr>"
                for j in daemon_jobs:
                    status = str(j.get("status", "unknown"))
                    mode = str(j.get("mode", "agent"))
                    prompt = str(j.get("prompt", ""))[:80]
                    color = "#e5534b" if status in {"failed", "error"} else "#22c55e" if status in {"success"} else "#fbbf24"
                    runs_html += (
                        f"<tr><td>{j.get('id','')}</td>"
                        f"<td style='color:{color}'>{status}</td>"
                        f"<td>{mode}</td>"
                        f"<td>{prompt}</td></tr>"
                    )
                runs_html += "</table><hr />"

            if rows:
                runs_html += "<table><tr><th>When</th><th>Status</th><th>Title</th><th>File</th></tr>"
                for p, mtime_str, title, failed in rows:
                    status = "failed" if failed else "ok"
                    color = "#e5534b" if failed else "#22c55e"
                    runs_html += (
                        f"<tr><td>{mtime_str}</td>"
                        f"<td style='color:{color}'>{status}</td>"
                        f"<td>{title}</td>"
                        f"<td>{p.name}</td></tr>"
                    )
                runs_html += "</table>"
            else:
                runs_html = "<p>No agent runs yet.</p>"
            html = f"""
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Artemis Agent Runs</title>
  <style>
    body {{ font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; padding: 1.5rem; background: #0b1020; color: #f9fafb; }}
    h1 {{ margin-bottom: 0.5rem; }}
    p {{ margin: 0.25rem 0 1rem 0; color: #9ca3af; }}
    table {{ border-collapse: collapse; width: 100%; max-width: 1200px; }}
    th, td {{ border-bottom: 1px solid #1f2937; padding: 0.4rem 0.6rem; text-align: left; font-size: 0.9rem; }}
    th {{ background: #111827; position: sticky; top: 0; }}
    tr:nth-child(even) {{ background: #020617; }}
    tr:nth-child(odd) {{ background: #030712; }}
    code {{ background: #111827; padding: 0.1rem 0.3rem; border-radius: 4px; }}
  </style>
</head>
<body>
  <h1>Artemis Agent Runs</h1>
  <p>Reading reports from <code>{out_dir}</code>{' and daemon at <code>' + daemon_url + '</code>' if daemon_jobs else ''}</p>
  {runs_html}
</body>
</html>
""".encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(html)))
            self.end_headers()
            self.wfile.write(html)

        def log_message(self, fmt: str, *args) -> None:  # type: ignore[override]
            # Keep CLI output clean; omit per-request logs.
            return

    server = HTTPServer(("127.0.0.1", port), _Handler)
    console.print(
        Panel(
            f"[green]Dashboard running.[/green]\n\nOpen [cyan]http://127.0.0.1:{port}/[/cyan] in your browser.\n\nPress Ctrl+C to stop.",
            title="Dashboard",
            border_style="green",
        )
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        console.print("\n[dim]Dashboard stopped.[/dim]")
    finally:
        server.server_close()


@app.command()
def daemon(
    host: str = typer.Option("127.0.0.1", "--host", help="Daemon bind host (default: 127.0.0.1)"),
    port: int = typer.Option(8787, "--port", "-p", help="Daemon port (default: 8787)"),
) -> None:
    """Run the Artemis daemon (job registry + agent runner) on localhost."""
    from openartemis.runtime.daemon_http import run_http_daemon

    console.print(
        Panel(
            f"[green]Artemis daemon starting.[/green]\n\nListening on [cyan]http://{host}:{port}[/cyan].\n"
            "Keep this process running while using daemon-backed commands.",
            title="Daemon",
            border_style="green",
        )
    )
    try:
        run_http_daemon(host=host, port=port)
    except KeyboardInterrupt:
        console.print("\n[dim]Daemon stopped.[/dim]")


@app.command()
def run(
    id_arg: str = typer.Argument(..., help="Run id: stem (e.g. 2026-02-28_23-11_Build_me...) or 1-based index"),
) -> None:
    """Open a specific agent report by stem or index (e.g. openartemis run 1)."""
    get_agent_output_dir().mkdir(parents=True, exist_ok=True)
    md_files = sorted(get_agent_output_dir().glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not md_files:
        console.print("[red]No agent runs found.[/red]")
        raise typer.Exit(1)
    target: Path | None = None
    if id_arg.isdigit():
        idx = int(id_arg)
        if 1 <= idx <= len(md_files):
            target = md_files[idx - 1]
    if target is None:
        stem = id_arg.replace(".md", "").strip()
        for p in md_files:
            if p.stem == stem or p.name == stem or p.name.startswith(stem):
                target = p
                break
    if target is None:
        console.print(f"[red]No run matching '{id_arg}'.[/red]")
        raise typer.Exit(1)
    try:
        if sys.platform == "win32":
            os.startfile(str(target))
        elif sys.platform == "darwin":
            subprocess.run(["open", str(target)], check=False)
        else:
            subprocess.run(["xdg-open", str(target)], check=False)
        console.print(f"[dim]Opened {target.name}[/dim]")
    except Exception as e:
        console.print(f"[red]Could not open: {e}[/red]")
        raise typer.Exit(1)


@app.command(hidden=True)
def codes(
    stats: bool = typer.Option(False, "--stats", "-s", help="Show user + code statistics"),
    ahead: int = typer.Option(0, "--ahead", "-a", help="Days ahead (0=today, 1=tomorrow, …)"),
    cleanup: bool = typer.Option(False, "--cleanup", help="Remove expired legacy codes"),
) -> None:
    """Show today's invite codes (admin only). Reads codes_master.json."""
    from openartemis.admin_commands import show_todays_codes, stats_command, cleanup_command
    if stats:
        stats_command()
    elif cleanup:
        cleanup_command()
    else:
        show_todays_codes(days_ahead=ahead)


@app.command()
def reset_admin(
    username: str = typer.Argument(None, help="Admin username (default: first admin)"),
    password: str = typer.Option(..., "--password", "-p", prompt=True, hide_input=True),
) -> None:
    """Reset admin password (use when you forgot it). No login required."""
    from openartemis.auth.db import list_users
    init_db()
    if get_user_count() == 0:
        console.print("[yellow]No users. Run openartemis first to create admin.[/yellow]")
        return
    if not username:
        users = [u for u in list_users() if u.get("role") == "admin"]
        if not users:
            console.print("[red]No admin users found.[/red]")
            return
        username = users[0]["username"]
        console.print(f"[dim]Resetting password for admin: {username}[/dim]")
    ok, msg = reset_admin_password(username, password)
    if ok:
        console.print(f"[green]{msg}[/green]")
    else:
        console.print(f"[red]{msg}[/red]")


@app.command()
def logout() -> None:
    """Log out of current session."""
    revoke_session()
    theme.ok(console, "Logged out.")


@app.command(hidden=True)
def nuke() -> None:
    """Delete the local user database — fresh start (dev escape hatch)."""
    from openartemis.auth.db import DATA_DIR
    db_path = DATA_DIR / "openartemis.db"
    if not db_path.exists():
        theme.info(console, f"No database found at {db_path}")
        raise typer.Exit(0)
    console.print()
    theme.warn(console, f"This will DELETE all local users, sessions and chat history.")
    theme.info(console, f"Path: {db_path}")
    console.print()
    confirm = questionary.confirm("Are you sure?", default=False, style=_QUESTIONARY_SELECT_STYLE).ask()
    if not confirm:
        theme.info(console, "Aborted.")
        raise typer.Exit(0)
    db_path.unlink()
    theme.ok(console, "Database deleted. Run openartemis to start fresh.")


@app.command()
def search(
    query: str = typer.Argument(..., help="Search chat history by title or message content"),
    limit: int = typer.Option(30, "--limit", "-n", help="Max sessions to return"),
) -> None:
    """Search chat sessions by title or message content."""
    user = _get_authenticated_user()
    sessions_list = search_chat_sessions(user["id"], query, limit=limit)
    if not sessions_list:
        console.print("[dim]No matching chats.[/dim]\n")
        return
    console.print(f"[bold]Chats matching \"{query}\"[/bold]\n")
    for s in sessions_list:
        console.print(_chat_list_line(s, console))
    console.print("[dim]Use /load <number> in chat to open a session.[/dim]\n")


@app.command()
def preflight(
    mode: str = typer.Option(
        None,
        "--mode", "-m",
        help="Check only this mode: chat, harvest, agent, research (default: all)",
    ),
    cleanup_runtime: bool = typer.Option(
        False,
        "--cleanup-runtime",
        help="Remove cached IDE runtime (Theia backend) from ~/.openartemis/theia and exit.",
    ),
) -> None:
    """Check environment and required env vars for chat, harvest, agent, and research.

    When --cleanup-runtime is set, preflight will remove the cached IDE runtime
    bundle (if present) and report the result instead of running checks.
    """
    from openartemis.preflight import cleanup_ide_runtime, run_preflight

    if cleanup_runtime:
        ok, msg = cleanup_ide_runtime()
        if ok:
            console.print(f"[green]{msg}[/green]")
            return
        console.print(f"[red]{msg}[/red]")
        raise typer.Exit(1)

    results = run_preflight(mode)
    table = Table(title="Preflight")
    table.add_column("Mode", style="cyan")
    table.add_column("Check", style="green")
    table.add_column("Status", style="bold")
    table.add_column("Detail", style="dim")
    for m, check_id, ok, msg in results:
        status = "[green]OK[/green]" if ok else "[red]MISSING[/red]"
        table.add_row(m, check_id, status, msg)
    console.print(table)
    failed = sum(1 for _, __, ok, _ in results if not ok)
    if failed:
        console.print(f"\n[yellow]{failed} check(s) missing or invalid. Set env vars or run [bold]openartemis config[/bold] for help.[/yellow]")
    else:
        console.print("\n[green]All checks passed.[/green]")


@app.command()
def config() -> None:
    """Show configuration help and required env vars."""
    _welcome()
    table = Table(title="Configuration")
    table.add_column("Variable", style="cyan")
    table.add_column("Required for", style="green")
    table.add_column("Where to get it", style="dim")
    table.add_row(
        "ffmpeg (system)",
        "TikTok, Instagram, X, Whisper audio",
        "winget install ffmpeg | brew install ffmpeg | apt install ffmpeg",
    )
    table.add_row(
        "YOUTUBE_API_KEY",
        "YouTube (Google API, if not using TranscriptAPI)",
        "Google Cloud Console -> APIs & Services -> YouTube Data API v3",
    )
    table.add_row(
        "TRANSCRIPTAPI_API_KEY",
        "YouTube search + transcripts (TranscriptAPI.com)",
        "transcriptapi.com - replaces Google API",
    )
    table.add_row(
        "SCRAPINGDOG_API_KEY",
        "YouTube transcripts (optional, if not using TranscriptAPI)",
        "scrapingdog.com",
    )
    table.add_row(
        "OPENAI_API_KEY",
        "Artemis chat (investigate command)",
        "platform.openai.com",
    )
    table.add_row(
        "BRAVE_SEARCH_API_KEY",
        "Web search in research (brave_search tool)",
        "search.brave.com - free tier available",
    )
    table.add_row(
        "OPENARTEMIS_MAX_CREDITS",
        "Per-session credits cap for non-admin (SaaS budget)",
        "e.g. 100 - admins have no cap",
    )
    table.add_row(
        "OPENARTEMIS_MAX_TOKENS",
        "Per-completion token cap (limits response length)",
        "e.g. 2048 or 4096 - reduces token usage for non-admin",
    )
    table.add_row(
        "OPENARTEMIS_AGENT_OUTPUT_DIR",
        "Agent run output dir (so status and background agent share same dir)",
        "e.g. C:\\Users\\You\\.openartemis\\agent_output",
    )
    table.add_row(
        "OPENARTEMIS_TPM_LIMIT",
        "OpenAI tokens-per-minute cap (avoid 429; match your tier, e.g. 30000)",
        "Default 28000 - Brave Search ~1 req/s; OpenAI tier limits apply",
    )
    table.add_row(
        "OPENARTEMIS_IDE_MODE",
        "Preview: IDE runtime mode (lightweight or full)",
        "Set to 'lightweight' for headless Theia backend only; 'full' when also running a web IDE frontend.",
    )
    table.add_row(
        "OPENARTEMIS_IDE_RUNTIME_ENABLED",
        "Preview: enable Theia-based IDE runtime integrations",
        "Set to 1 to opt into experimental IDE runtime features as they become available.",
    )
    console.print(table)
    console.print("\n[dim]Set in your shell or use the corresponding --*-api-key flags[/dim]")


@app.command(hidden=True)
def playtest(
    workspace: str = typer.Option(
        "C:\\Dev\\Test\\flappy-bird-game",
        "--workspace", "-w",
        help="Default workspace for agent steps",
    ),
    bot_user: str = typer.Option(
        "playtest-bot",
        "--bot-user",
        help="Bot username (created if missing)",
    ),
    bot_password: str = typer.Option(
        None,
        "--bot-password",
        help="Bot password (default: env OPENARTEMIS_PLAYTEST_BOT_PASSWORD or playtest-bot-password)",
    ),
    scenarios: str = typer.Option(
        "default",
        "--scenarios", "-s",
        help="Scenario set (only 'default' for now)",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Print steps only, do not execute",
    ),
) -> None:
    """Run playtest bots: research, agent run, chat. Logs to ~/.openartemis/playtest_runs/. Development/training only."""
    from openartemis.playtest import run_playtest
    try:
        jsonl_path, summary_path = run_playtest(
            workspace=workspace,
            bot_user=bot_user,
            bot_password=bot_password,
            scenario_set=scenarios,
            dry_run=dry_run,
        )
        console.print(f"[green]Playtest done.[/green]")
        console.print(f"  Log: [cyan]{jsonl_path}[/cyan]")
        console.print(f"  Summary: [cyan]{summary_path}[/cyan]")
    except Exception as e:
        console.print(f"[red]Playtest failed: {e}[/red]")
        raise typer.Exit(1)


def main() -> None:
    """Entry point for openartemis command."""
    from openartemis.update_check import ensure_updated
    ensure_updated()
    app()


if __name__ == "__main__":
    main()
