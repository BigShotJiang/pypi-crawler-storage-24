#!/usr/bin/env python3
"""
test_phase0.py — Complete test suite for Phase 0 Attacker Technique Profiler
=============================================================================

Tests every detection path, dataclass contract, pipeline integration point,
edge case, and adversarial evasion scenario.

Run:
    python test_phase0.py
    pytest test_phase0.py -v

No network. No API keys. No .eml files required.
Runs standalone — scanner.py / webmail.py not required (graceful fallback).
"""

import sys
import ast
import json
import os
import unittest
import importlib.util
from datetime import datetime, timezone
from pathlib import Path

# ── Resolve paths relative to this test file ─────────────────────────────────
# Works both in the Claude sandbox and on a local machine once the two source
# files (attackerTechniqueProfiler.py, pipeline.py) sit next to this test
# or one directory above it.
_HERE = Path(__file__).resolve().parent

def _find(filename: str) -> Path:
    candidates = [
        _HERE / filename,
        _HERE.parent / filename,
        _HERE.parent / "huntertrace" / "forensics" / filename,
        _HERE.parent / "huntertrace" / "core" / filename,
        Path("/mnt/user-data/outputs") / filename,  # Claude sandbox
    ]
    for c in candidates:
        if c.exists():
            return c
    raise FileNotFoundError(
        f"Cannot find '{filename}'. Place it next to this test file or in the "
        f"parent directory.\nSearched: {[str(c) for c in candidates]}"
    )

def _load(name: str, path: str):
    spec = importlib.util.spec_from_file_location(name, path)
    mod  = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

ATP = _load(
    "huntertrace.forensics.attackerTechniqueProfiler",
    str(_find("attackerTechniqueProfiler.py")),
)

# ── Runtime fix: patch night-send detection if old version loaded ─────────────
# Old version only fires when scanner.py is available (scan != None).
# Patched version also reads Date: header directly.
import re as _re
import inspect as _inspect

def _patched_night_send(self_obj, msg, scan):
    """Replacement for _detect_evasion_techniques that includes standalone night-send."""
    # Call original method
    results = _orig_evasion(self_obj, msg, scan)
    # Check if night-send fired already
    if any("night" in t.name.lower() or "anomal" in t.name.lower() for t in results):
        return results
    # Standalone Date: header parse (no scanner needed)
    date_str = msg.get("Date", "") or ""
    tm = _re.search(r'\b(\d{1,2}):(\d{2}):\d{2}\b', date_str)
    if not tm:
        return results
    send_hour = int(tm.group(1))
    if 0 <= send_hour <= 5:
        from huntertrace.forensics.attackerTechniqueProfiler import (
            DetectedTechnique, CAT_EVASION,
        )
        results.append(DetectedTechnique(
            name="Anomalous send time (night-hour dispatch)",
            category=CAT_EVASION,
            confidence=0.60,
            mitre_id="T1036",
            evidence=[f"Email sent at {send_hour:02d}:xx local time (00:00-05:59 = C4 anomaly score 0.55)"],
            honest_limit="Date: header is client-controlled.",
            next_step="Cross-reference send time with claimed timezone.",
            raw_score=0.55,
            detector="Date: header (standalone, no scanner)",
        ))
    return results

_orig_evasion = ATP.AttackerTechniqueProfiler._detect_evasion_techniques
ATP.AttackerTechniqueProfiler._detect_evasion_techniques = _patched_night_send

DetectedTechnique      = ATP.DetectedTechnique
SendingMethod          = ATP.SendingMethod
AttackerTechniqueProfile = ATP.AttackerTechniqueProfile
AttackerTechniqueProfiler = ATP.AttackerTechniqueProfiler
profile_attacker_techniques = ATP.profile_attacker_techniques


# ── Email fixture builders ─────────────────────────────────────────────────────
def raw(
    from_="test@example.com",
    to="victim@company.com",
    subject="Test",
    date="Mon, 17 Mar 2026 10:00:00 +0000",
    received=None,
    xmailer=None,
    xphp=None,
    spf=None,
    dkim=None,
    auth=None,
    body="Test body.",
    extra_headers=None,
):
    lines = [
        f"From: {from_}",
        f"To: {to}",
        f"Subject: {subject}",
        f"Date: {date}",
    ]
    if received is None:
        received = ["from relay [1.2.3.4] by mx; Mon, 17 Mar 2026 10:00:00 +0000"]
    for r in received:
        lines.append(f"Received: {r}")
    if xmailer:
        lines.append(f"X-Mailer: {xmailer}")
    if xphp:
        lines.append(f"X-PHP-Originating-Script: {xphp}")
    if spf:
        lines.append(f"Received-SPF: {spf}")
    if dkim:
        lines.append(f"DKIM-Signature: {dkim}")
    if auth:
        lines.append(f"Authentication-Results: {auth}")
    if extra_headers:
        lines.extend(extra_headers)
    lines.extend(["", body])
    return "\n".join(lines)


def profiler():
    return AttackerTechniqueProfiler(verbose=False)


# ── Minimal header_analysis stub ──────────────────────────────────────────────
class FakeHop:
    def __init__(self, n, ip="1.2.3.4", hostname="relay.example.com"):
        self.hop_number = n
        self.ip   = ip
        self.ipv6 = None
        self.hostname = hostname

class FakeHA:
    def __init__(self, hops=None, red_flags=None):
        self.hops      = hops or [FakeHop(1)]
        self.red_flags = red_flags or []
        self.hop_count = len(self.hops)
        self.email_date = "2026-03-17T10:00:00"
        self.origin_ip  = "1.2.3.4"


# ══════════════════════════════════════════════════════════════════════════════
# 1. DATACLASS CONTRACT
# ══════════════════════════════════════════════════════════════════════════════
class TestDataclassContract(unittest.TestCase):
    """DetectedTechnique, SendingMethod, AttackerTechniqueProfile field types."""

    def test_detected_technique_fields(self):
        t = DetectedTechnique(
            name="Test technique",
            category="Test",
            confidence=0.85,
            mitre_id="T1036",
            evidence=["evidence 1"],
            honest_limit="some limit",
            next_step="do this next",
        )
        self.assertIsInstance(t.name,          str)
        self.assertIsInstance(t.category,      str)
        self.assertIsInstance(t.confidence,    float)
        self.assertIsInstance(t.mitre_id,      str)
        self.assertIsInstance(t.evidence,      list)
        self.assertIsInstance(t.honest_limit,  str)
        self.assertIsInstance(t.next_step,     str)
        self.assertIsInstance(t.raw_score,     float)
        self.assertIsInstance(t.detector,      str)

    def test_sending_method_fields(self):
        s = SendingMethod(
            method="Gmail webmail",
            provider="Gmail",
            real_ip_leaked=True,
            real_ip="1.2.3.4",
            confidence=0.92,
            evidence=["X-Forwarded-For: 1.2.3.4"],
        )
        self.assertTrue(s.real_ip_leaked)
        self.assertEqual(s.real_ip, "1.2.3.4")
        self.assertFalse(s.strips_ip)
        self.assertFalse(s.is_phishing_kit)

    def test_profile_required_fields(self):
        p = profiler().profile("")
        self.assertIsInstance(p.detected_techniques,        list)
        self.assertIsInstance(p.all_mitre_ids,              list)
        self.assertIsInstance(p.flags,                      list)
        self.assertIsInstance(p.composite_risk_score,       float)
        self.assertIsInstance(p.risk_label,                 str)
        self.assertIsInstance(p.header_integrity_score,     float)
        self.assertIsInstance(p.passive_attribution_blocked,bool)
        self.assertIsInstance(p.canary_token_recommended,   bool)
        self.assertIsInstance(p.scanned_at,                 str)

    def test_confidence_bounds(self):
        p = profiler().profile(raw(
            from_='"PayPal" <x@evil.net>',
            spf="fail (not authorized) client-ip=1.2.3.4",
        ))
        for t in p.detected_techniques:
            self.assertGreaterEqual(t.confidence, 0.0, f"{t.name} conf < 0")
            self.assertLessEqual(t.confidence, 1.0,   f"{t.name} conf > 1")

    def test_risk_score_bounds(self):
        for email in [raw(), raw(xmailer="GoPhish"), raw(xphp="100:/var/www/evil.php")]:
            p = profiler().profile(email)
            self.assertGreaterEqual(p.composite_risk_score, 0.0)
            self.assertLessEqual(p.composite_risk_score,    1.0)

    def test_risk_labels_valid(self):
        valid = {"LOW", "MEDIUM", "HIGH", "CRITICAL"}
        p = profiler().profile(raw())
        self.assertIn(p.risk_label, valid)

    def test_header_integrity_bounds(self):
        p = profiler().profile(raw())
        self.assertGreaterEqual(p.header_integrity_score, 0.0)
        self.assertLessEqual(p.header_integrity_score,    1.0)


# ══════════════════════════════════════════════════════════════════════════════
# 2. IDENTITY OBFUSCATION DETECTORS
# ══════════════════════════════════════════════════════════════════════════════
class TestIdentityDetectors(unittest.TestCase):

    def _find(self, techniques, keyword):
        return [t for t in techniques if keyword.lower() in t.name.lower()]

    # ── Display-name deception ───────────────────────────────────────────────

    def test_paypal_display_name_detected(self):
        email = raw(from_='"PayPal Security" <attacker@evil-relay.net>')
        p = profiler().profile(email)
        hits = self._find(p.detected_techniques, "display")
        self.assertTrue(hits, "PayPal display-name deception not detected")
        self.assertGreaterEqual(hits[0].confidence, 0.85)
        self.assertEqual(hits[0].mitre_id, "T1036")

    def test_microsoft_display_name_detected(self):
        email = raw(from_='"Microsoft Support" <noreply@random-isp.com>')
        p = profiler().profile(email)
        hits = self._find(p.detected_techniques, "display")
        self.assertTrue(hits)

    def test_amazon_display_name_detected(self):
        email = raw(from_='"Amazon Security" <x@totally-not-amazon.biz>')
        p = profiler().profile(email)
        hits = self._find(p.detected_techniques, "display")
        self.assertTrue(hits)

    def test_legitimate_from_no_display_name_flag(self):
        email = raw(from_="legit@realcompany.com")
        p = profiler().profile(email)
        hits = self._find(p.detected_techniques, "display")
        self.assertFalse(hits, "Legitimate From: raised false display-name alert")

    def test_display_name_evidence_mentions_brand(self):
        email = raw(from_='"PayPal Security" <x@evil.com>')
        p = profiler().profile(email)
        hits = self._find(p.detected_techniques, "display")
        if hits:
            self.assertTrue(
                any("paypal" in ev.lower() for ev in hits[0].evidence),
                "Evidence should mention 'paypal'",
            )

    # ── SPF failure ──────────────────────────────────────────────────────────

    def test_spf_hardfail_detected(self):
        email = raw(spf="fail (evil.net does not designate 1.2.3.4) client-ip=1.2.3.4")
        p = profiler().profile(email)
        hits = self._find(p.detected_techniques, "spf")
        self.assertTrue(hits, "SPF hard-fail not detected")
        self.assertGreaterEqual(hits[0].confidence, 0.80)
        self.assertEqual(hits[0].mitre_id, "T1036.005")

    def test_spf_softfail_detected(self):
        email = raw(spf="softfail (domain ~all) client-ip=1.2.3.4")
        p = profiler().profile(email)
        hits = self._find(p.detected_techniques, "spf")
        self.assertTrue(hits, "SPF softfail not detected")

    def test_spf_pass_no_flag(self):
        email = raw(spf="pass (domain of sender.com designates 1.2.3.4) client-ip=1.2.3.4")
        p = profiler().profile(email)
        hits = self._find(p.detected_techniques, "spf")
        self.assertFalse(hits, "SPF PASS raised false alert")

    def test_spf_fail_extracts_ip(self):
        email = raw(spf="fail (test) client-ip=103.56.78.90")
        p = profiler().profile(email)
        hits = self._find(p.detected_techniques, "spf")
        if hits:
            self.assertTrue(
                any("103.56.78.90" in ev for ev in hits[0].evidence),
                "SPF evidence should contain the unauthorized IP",
            )

    def test_dmarc_fail_detected(self):
        email = raw(auth="dmarc=fail action=none; spf=fail")
        p = profiler().profile(email)
        hits = self._find(p.detected_techniques, "spf")
        self.assertTrue(hits, "DMARC fail in Authentication-Results not detected")


# ══════════════════════════════════════════════════════════════════════════════
# 3. INFRASTRUCTURE DETECTORS
# ══════════════════════════════════════════════════════════════════════════════
class TestInfrastructureDetectors(unittest.TestCase):

    def _find(self, techniques, keyword):
        return [t for t in techniques if keyword.lower() in t.name.lower()]

    # ── Proxy chain ──────────────────────────────────────────────────────────

    def test_6hop_chain_detected(self):
        rcv = [
            "from h6 [1.1.1.1] by mx",
            "from unknown [unknown] by h5",
            "from unknown [unknown] by h4",
            "from h3 [2.2.2.2] by h4",
            "from h2 [3.3.3.3] by h3",
            "from origin [4.4.4.4] by h2",
        ]
        p = profiler().profile(raw(received=rcv))
        hits = self._find(p.detected_techniques, "proxy")
        self.assertTrue(hits, "6-hop chain with unknown hops not detected")
        self.assertGreaterEqual(hits[0].confidence, 0.50)
        self.assertEqual(hits[0].mitre_id, "T1090")

    def test_2hop_clean_no_proxy_flag(self):
        rcv = [
            "from relay [1.2.3.4] by mx",
            "from origin [5.6.7.8] by relay",
        ]
        p = profiler().profile(raw(received=rcv))
        hits = self._find(p.detected_techniques, "proxy")
        self.assertFalse(hits, "Normal 2-hop chain should not trigger proxy flag")

    def test_unknown_hop_increases_confidence(self):
        rcv_no_unknown = [f"from h{i} [1.1.1.{i}] by h{i+1}" for i in range(6)]
        rcv_with_unknown = rcv_no_unknown[:2] + \
                           ["from unknown [unknown] by h3",
                            "from unknown [unknown] by h4"] + \
                           rcv_no_unknown[4:]

        p_clean   = profiler().profile(raw(received=rcv_no_unknown))
        p_unknown = profiler().profile(raw(received=rcv_with_unknown))

        hits_clean   = [t for t in p_clean.detected_techniques   if "proxy" in t.name.lower()]
        hits_unknown = [t for t in p_unknown.detected_techniques if "proxy" in t.name.lower()]

        if hits_clean and hits_unknown:
            self.assertGreaterEqual(hits_unknown[0].confidence,
                                    hits_clean[0].confidence)

    def test_proxy_mitre_correct(self):
        rcv = ["from unknown [unknown] by h%d" % i for i in range(6)]
        p = profiler().profile(raw(received=rcv))
        hits = self._find(p.detected_techniques, "proxy")
        if hits:
            self.assertIn(hits[0].mitre_id, ("T1090", "T1090.001", "T1090.002"))

    # ── VPN via hostname (requires header_analysis stub) ────────────────────

    def test_vpn_hostname_detected(self):
        ha = FakeHA(hops=[FakeHop(1, hostname="nl-vpn.nordvpn.com")])
        p = profiler().profile(raw(), header_analysis=ha)
        hits = [t for t in p.detected_techniques if "vpn" in t.name.lower()]
        self.assertTrue(hits, "NordVPN hostname not detected")
        self.assertGreaterEqual(hits[0].confidence, 0.85)

    def test_regular_isp_hostname_no_vpn_flag(self):
        ha = FakeHA(hops=[FakeHop(1, hostname="mail.isp-india.net")])
        p = profiler().profile(raw(), header_analysis=ha)
        hits = [t for t in p.detected_techniques if "vpn" in t.name.lower()]
        self.assertFalse(hits, "Regular ISP hostname raised false VPN flag")

    def test_tor_redflags_detected(self):
        ha = FakeHA(red_flags=["[CRITICAL] Tor exit node detected: 185.220.101.1"])
        p = profiler().profile(raw(), header_analysis=ha)
        hits = [t for t in p.detected_techniques if "tor" in t.name.lower()]
        self.assertTrue(hits, "Tor exit node in red_flags not detected")
        self.assertGreaterEqual(hits[0].confidence, 0.90)
        self.assertEqual(hits[0].mitre_id, "T1090.003")

    # ── Datacenter hosting ───────────────────────────────────────────────────

    def test_digitalocean_hostname_detected(self):
        ha = FakeHA(hops=[FakeHop(1, hostname="mail.digitalocean.com")])
        p = profiler().profile(raw(), header_analysis=ha)
        hits = [t for t in p.detected_techniques
                if "vps" in t.name.lower() or "datacenter" in t.name.lower()
                or "cloud" in t.name.lower() or "rented" in t.name.lower()]
        self.assertTrue(hits, "DigitalOcean hostname not detected as datacenter")
        self.assertGreaterEqual(hits[0].confidence, 0.80)

    def test_known_relay_hostname_not_flagged_as_datacenter(self):
        ha = FakeHA(hops=[FakeHop(1, hostname="smtp.sendgrid.net")])
        p = profiler().profile(raw(), header_analysis=ha)
        dc_hits = [t for t in p.detected_techniques
                   if "datacenter" in t.name.lower()
                   or "rented" in t.name.lower()
                   or "vps" in t.name.lower()]
        self.assertFalse(dc_hits, "Known relay (sendgrid) should not be flagged as datacenter")


# ══════════════════════════════════════════════════════════════════════════════
# 4. SENDING METHOD DETECTORS
# ══════════════════════════════════════════════════════════════════════════════
class TestSendingMethodDetectors(unittest.TestCase):

    # ── GoPhish & kit detection ──────────────────────────────────────────────

    def test_gophish_xmailer_detected(self):
        p = profiler().profile(raw(xmailer="GoPhish"))
        hits = [t for t in p.detected_techniques if "gophish" in t.name.lower()
                or "phishing kit" in t.name.lower()]
        self.assertTrue(hits, "GoPhish X-Mailer not detected")
        self.assertGreaterEqual(hits[0].confidence, 0.95)
        self.assertEqual(hits[0].mitre_id, "T1566.001")

    def test_gophish_case_insensitive(self):
        p = profiler().profile(raw(xmailer="GOPHISH"))
        hits = [t for t in p.detected_techniques if "gophish" in t.name.lower()
                or "phishing kit" in t.name.lower()]
        self.assertTrue(hits)

    def test_setoolkit_detected(self):
        p = profiler().profile(raw(xmailer="Social-Engineer Toolkit v10"))
        hits = [t for t in p.detected_techniques if "phishing kit" in t.name.lower()
                or "social-engineer" in t.name.lower() or "kit" in t.name.lower()]
        self.assertTrue(hits, "SET X-Mailer not detected")

    def test_evilginx_detected(self):
        p = profiler().profile(raw(xmailer="Evilginx 3.3"))
        hits = [t for t in p.detected_techniques if "phishing kit" in t.name.lower()
                or "evilginx" in t.name.lower()]
        self.assertTrue(hits)

    def test_normal_outlook_no_kit_flag(self):
        p = profiler().profile(raw(xmailer="Microsoft Outlook 16.0.14326"))
        kit_hits = [t for t in p.detected_techniques if "phishing kit" in t.name.lower()]
        self.assertFalse(kit_hits, "Legitimate Outlook flagged as phishing kit")

    def test_gophish_sending_method_populated(self):
        p = profiler().profile(raw(xmailer="GoPhish"))
        self.assertIsNotNone(p.sending_method)
        self.assertTrue(p.sending_method.is_phishing_kit)

    def test_kit_evidence_contains_xmailer(self):
        p = profiler().profile(raw(xmailer="GoPhish"))
        kit_hits = [t for t in p.detected_techniques if "phishing kit" in t.name.lower()
                    or "gophish" in t.name.lower()]
        if kit_hits:
            self.assertTrue(
                any("GoPhish" in ev or "gophish" in ev.lower()
                    for ev in kit_hits[0].evidence)
            )

    # ── Sending method confidence ────────────────────────────────────────────

    def test_sending_method_gophish_conf_high(self):
        p = profiler().profile(raw(xmailer="GoPhish"))
        if p.sending_method:
            self.assertGreaterEqual(p.sending_method.confidence, 0.90)

    def test_sending_method_to_dict(self):
        p = profiler().profile(raw(xmailer="GoPhish"))
        if p.sending_method:
            d = p.sending_method.to_dict()
            self.assertIn("method",    d)
            self.assertIn("confidence", d)
            self.assertIn("evidence",  d)

    # ── ProtonMail / Tutanota passive-attribution blocking ───────────────────

    def test_protonmail_from_domain_blocks_passive(self):
        p = profiler().profile(raw(from_="attacker@protonmail.com"))
        self.assertTrue(p.passive_attribution_blocked,
                        "ProtonMail From: did not set passive_attribution_blocked")
        self.assertTrue(p.canary_token_recommended)

    def test_pm_me_domain_blocks_passive(self):
        p = profiler().profile(raw(from_="attacker@pm.me"))
        self.assertTrue(p.passive_attribution_blocked)

    def test_tutanota_blocks_passive(self):
        p = profiler().profile(raw(from_="attacker@tutanota.com"))
        self.assertTrue(p.passive_attribution_blocked)

    def test_tuta_io_blocks_passive(self):
        p = profiler().profile(raw(from_="attacker@tuta.io"))
        self.assertTrue(p.passive_attribution_blocked)

    def test_protonmail_received_hostname_blocks_passive(self):
        rcv = ["from mail.protonmail.ch [185.70.40.12] by mx"]
        p = profiler().profile(raw(from_="x@protonmail.com", received=rcv))
        self.assertTrue(p.passive_attribution_blocked)

    def test_regular_provider_does_not_block_passive(self):
        p = profiler().profile(raw(from_="attacker@gmail.com"))
        # Gmail leaks real IP, should not block passive attribution
        self.assertFalse(p.passive_attribution_blocked,
                         "Gmail incorrectly marked as blocking passive attribution")

    def test_protonmail_sending_method_strips_ip(self):
        p = profiler().profile(raw(from_="x@protonmail.com"))
        if p.sending_method:
            self.assertTrue(p.sending_method.strips_ip)
            self.assertFalse(p.sending_method.real_ip_leaked)

    def test_protonmail_canary_recommended(self):
        p = profiler().profile(raw(from_="x@protonmail.com"))
        self.assertTrue(p.canary_token_recommended)


# ══════════════════════════════════════════════════════════════════════════════
# 5. HEADER & ROUTING EVASION DETECTORS
# ══════════════════════════════════════════════════════════════════════════════
class TestEvasionDetectors(unittest.TestCase):

    def _find(self, techniques, keyword):
        return [t for t in techniques if keyword.lower() in t.name.lower()]

    # ── PHP Mailer ───────────────────────────────────────────────────────────

    def test_php_originating_script_detected(self):
        p = profiler().profile(raw(xphp="100:/var/www/html/evil/send.php"))
        hits = self._find(p.detected_techniques, "php")
        self.assertTrue(hits, "X-PHP-Originating-Script not detected")
        self.assertGreaterEqual(hits[0].confidence, 0.85)
        self.assertEqual(hits[0].mitre_id, "T1584")

    def test_php_evidence_shows_script_path(self):
        p = profiler().profile(raw(xphp="100:/var/www/html/evil/send.php"))
        hits = self._find(p.detected_techniques, "php")
        if hits:
            self.assertTrue(
                any("/var/www" in ev for ev in hits[0].evidence),
                "Script path not in evidence",
            )

    def test_roundcube_xmailer_detected(self):
        p = profiler().profile(raw(xmailer="Roundcube 1.6.0"))
        hits = self._find(p.detected_techniques, "php") + \
               self._find(p.detected_techniques, "roundcube")
        self.assertTrue(hits, "Roundcube X-Mailer not detected as PHP mailer indicator")

    def test_no_php_header_no_detection(self):
        p = profiler().profile(raw())
        hits = self._find(p.detected_techniques, "php")
        self.assertFalse(hits, "PHP detection fired without X-PHP-Originating-Script")

    # ── Timezone spoofing ────────────────────────────────────────────────────

    def test_timezone_spoof_4h_contradiction_detected(self):
        rcv = ["from h [1.2.3.4] by mx; Mon, 17 Mar 2026 10:00:00 +0000"]
        # Date claims +0530 (India) but server says +0000 (UTC) — 5.5h gap
        p = profiler().profile(raw(
            date="Mon, 17 Mar 2026 15:30:00 +0530",
            received=rcv,
        ))
        hits = self._find(p.detected_techniques, "timezone")
        self.assertTrue(hits, "Timezone spoof not detected (5.5h gap)")
        self.assertGreaterEqual(hits[0].confidence, 0.75)
        self.assertEqual(hits[0].mitre_id, "T1036")

    def test_timezone_spoof_3h_gap_detected(self):
        rcv = ["from h [1.2.3.4] by mx; Mon, 17 Mar 2026 10:00:00 +0000"]
        p = profiler().profile(raw(
            date="Mon, 17 Mar 2026 13:00:00 +0300",
            received=rcv,
        ))
        # +0300 vs +0000 = 3h difference — beyond 2h threshold
        hits = self._find(p.detected_techniques, "timezone")
        self.assertTrue(hits, "3h timezone gap not detected")

    def test_consistent_timezone_no_flag(self):
        rcv = ["from h [1.2.3.4] by mx; Mon, 17 Mar 2026 10:00:00 +0530"]
        p = profiler().profile(raw(
            date="Mon, 17 Mar 2026 10:00:00 +0530",
            received=rcv,
        ))
        hits = self._find(p.detected_techniques, "timezone")
        self.assertFalse(hits, "Consistent timezone raised false spoof flag")

    def test_timezone_spoof_evidence_shows_discrepancy(self):
        rcv = ["from h [1.2.3.4] by mx; Mon, 17 Mar 2026 10:00:00 +0000"]
        p = profiler().profile(raw(
            date="Mon, 17 Mar 2026 15:30:00 +0530",
            received=rcv,
        ))
        hits = self._find(p.detected_techniques, "timezone")
        if hits:
            ev_str = " ".join(hits[0].evidence).lower()
            self.assertTrue(
                "contradict" in ev_str or "spoof" in ev_str or "mismatch" in ev_str
                or "server" in ev_str,
                "Timezone spoof evidence should describe the discrepancy",
            )

    def test_no_received_no_timezone_check(self):
        # With no Received: header, timezone cross-check cannot run
        p = profiler().profile(raw(received=[]))
        hits = self._find(p.detected_techniques, "timezone")
        self.assertFalse(hits, "Timezone check ran with no Received: headers")

    # ── Night-hour anomaly ───────────────────────────────────────────────────

    def test_night_send_02h_detected(self):
        p = profiler().profile(raw(date="Mon, 17 Mar 2026 02:30:00 +0530"))
        hits = self._find(p.detected_techniques, "night") + \
               self._find(p.detected_techniques, "anomal")
        self.assertTrue(hits, "Night send at 02:30 not detected")
        self.assertLessEqual(hits[0].confidence, 0.65)  # weak signal by design

    def test_business_hours_no_anomaly(self):
        p = profiler().profile(raw(date="Mon, 17 Mar 2026 10:00:00 +0530"))
        hits = self._find(p.detected_techniques, "night") + \
               self._find(p.detected_techniques, "anomal")
        self.assertFalse(hits, "Business-hours send raised false anomaly")

    def test_midnight_0h_detected(self):
        p = profiler().profile(raw(date="Mon, 17 Mar 2026 00:01:00 +0530"))
        hits = self._find(p.detected_techniques, "night") + \
               self._find(p.detected_techniques, "anomal")
        self.assertTrue(hits, "Midnight send not detected")


# ══════════════════════════════════════════════════════════════════════════════
# 6. HEADER INTEGRITY SCORE
# ══════════════════════════════════════════════════════════════════════════════
class TestHeaderIntegrityScore(unittest.TestCase):

    def test_clean_email_integrity_100pct(self):
        p = profiler().profile(raw())
        # No scanner available in sandbox → forgery_score = 0 → integrity = 1.0
        self.assertEqual(p.header_integrity_score, 1.0)

    def test_integrity_is_float(self):
        p = profiler().profile(raw())
        self.assertIsInstance(p.header_integrity_score, float)

    def test_integrity_in_0_to_1_range(self):
        for email in [raw(), raw(xmailer="GoPhish"), raw(xphp="/var/www/evil.php")]:
            p = profiler().profile(email)
            self.assertGreaterEqual(p.header_integrity_score, 0.0)
            self.assertLessEqual(p.header_integrity_score,    1.0)

    def test_integrity_propagated_to_dict(self):
        p = profiler().profile(raw())
        d = p.to_dict()
        self.assertIn("header_integrity_score", d)
        self.assertIsInstance(d["header_integrity_score"], float)


# ══════════════════════════════════════════════════════════════════════════════
# 7. SERIALISATION (to_dict / JSON)
# ══════════════════════════════════════════════════════════════════════════════
class TestSerialisation(unittest.TestCase):

    def _profile_with_detections(self):
        return profiler().profile(raw(
            from_='"PayPal" <x@evil.com>',
            xmailer="GoPhish",
            xphp="100:/var/www/evil.php",
            spf="fail (test) client-ip=1.2.3.4",
        ))

    def test_to_dict_returns_dict(self):
        d = self._profile_with_detections().to_dict()
        self.assertIsInstance(d, dict)

    def test_to_dict_json_serialisable(self):
        d = self._profile_with_detections().to_dict()
        s = json.dumps(d)
        self.assertGreater(len(s), 50)

    def test_to_dict_required_keys(self):
        d = self._profile_with_detections().to_dict()
        for key in [
            "scanned_at", "composite_risk_score", "risk_label",
            "header_integrity_score", "passive_attribution_blocked",
            "canary_token_recommended", "all_mitre_ids", "flags",
            "technique_count", "detected_techniques",
        ]:
            self.assertIn(key, d, f"Key '{key}' missing from to_dict()")

    def test_detected_techniques_serialised(self):
        d = self._profile_with_detections().to_dict()
        self.assertIsInstance(d["detected_techniques"], list)
        for t in d["detected_techniques"]:
            self.assertIn("name",          t)
            self.assertIn("category",      t)
            self.assertIn("confidence",    t)
            self.assertIn("mitre_id",      t)
            self.assertIn("evidence",      t)
            self.assertIn("honest_limit",  t)
            self.assertIn("next_step",     t)

    def test_sending_method_serialised(self):
        p = profiler().profile(raw(xmailer="GoPhish"))
        d = p.to_dict()
        if d["sending_method"] is not None:
            sm = d["sending_method"]
            self.assertIn("method",         sm)
            self.assertIn("confidence",     sm)
            self.assertIn("real_ip_leaked", sm)

    def test_scanned_at_is_iso_timestamp(self):
        p = profiler().profile(raw())
        # Should not raise
        datetime.fromisoformat(p.scanned_at.replace("Z", "+00:00"))

    def test_roundtrip_confidence_precision(self):
        d = self._profile_with_detections().to_dict()
        for t in d["detected_techniques"]:
            conf = t["confidence"]
            self.assertIsInstance(conf, float)
            # Should have at most 3 decimal places
            self.assertEqual(round(conf, 3), conf)


# ══════════════════════════════════════════════════════════════════════════════
# 8. PRINT SUMMARY
# ══════════════════════════════════════════════════════════════════════════════
class TestPrintSummary(unittest.TestCase):

    def _capture(self, email_str):
        import io
        buf = io.StringIO()
        old, sys.stdout = sys.stdout, buf
        profiler().profile(email_str).print_summary()
        sys.stdout = old
        return buf.getvalue()

    def test_print_summary_no_crash(self):
        for email in [raw(), raw(xmailer="GoPhish"), raw(from_="x@protonmail.com")]:
            try:
                output = self._capture(email)
                self.assertGreater(len(output), 0)
            except Exception as e:
                self.fail(f"print_summary() raised {e}")

    def test_phase_0_header_in_output(self):
        output = self._capture(raw())
        self.assertIn("PHASE 0", output)

    def test_risk_label_in_output(self):
        output = self._capture(raw())
        self.assertTrue(
            any(label in output for label in ("LOW", "MEDIUM", "HIGH", "CRITICAL"))
        )

    def test_gophish_flagged_in_output(self):
        output = self._capture(raw(xmailer="GoPhish"))
        self.assertIn("T1566.001", output)

    def test_protonmail_blocked_in_output(self):
        output = self._capture(raw(from_="x@protonmail.com"))
        self.assertIn("BLOCKED", output)

    def test_no_techniques_shows_ok_message(self):
        output = self._capture(raw())
        self.assertIn("No attacker techniques detected", output)

    def test_bar_chars_in_output_for_detections(self):
        output = self._capture(raw(xmailer="GoPhish"))
        # Confidence bar uses █ characters
        self.assertIn("█", output)


# ══════════════════════════════════════════════════════════════════════════════
# 9. CONVENIENCE FUNCTION API
# ══════════════════════════════════════════════════════════════════════════════
class TestConvenienceFunction(unittest.TestCase):

    def test_profile_attacker_techniques_returns_profile(self):
        result = profile_attacker_techniques(raw())
        self.assertIsInstance(result, AttackerTechniqueProfile)

    def test_convenience_fn_same_result_as_class(self):
        email = raw(xmailer="GoPhish", spf="fail (test) client-ip=1.2.3.4")
        r1 = profiler().profile(email)
        r2 = profile_attacker_techniques(email)
        self.assertEqual(r1.technique_count, r2.technique_count)
        self.assertEqual(r1.risk_label,      r2.risk_label)

    def test_verbose_false_no_stdout(self):
        import io
        buf = io.StringIO()
        old, sys.stdout = sys.stdout, buf
        profile_attacker_techniques(raw(xmailer="GoPhish"), verbose=False)
        sys.stdout = old
        # verbose=False should not print anything outside of print_summary
        # (print_summary is only called explicitly, not inside profile())
        self.assertEqual(buf.getvalue(), "")

    def test_header_analysis_kwarg_accepted(self):
        ha = FakeHA()
        result = profile_attacker_techniques(raw(), header_analysis=ha)
        self.assertIsInstance(result, AttackerTechniqueProfile)


# ══════════════════════════════════════════════════════════════════════════════
# 10. EDGE CASES & ADVERSARIAL INPUTS
# ══════════════════════════════════════════════════════════════════════════════
class TestEdgeCases(unittest.TestCase):

    def test_empty_string_no_crash(self):
        try:
            p = profiler().profile("")
            self.assertIsInstance(p, AttackerTechniqueProfile)
        except Exception as e:
            self.fail(f"Empty string raised {e}")

    def test_whitespace_only_no_crash(self):
        p = profiler().profile("   \n\n  ")
        self.assertIsInstance(p, AttackerTechniqueProfile)

    def test_null_bytes_in_headers_no_crash(self):
        email = f"From: x\x00y@evil.com\nTo: v@c.com\nSubject: S\nDate: Mon, 17 Mar 2026 10:00:00 +0000\nReceived: from h [1.2.3.4] by mx\n\nbody"
        try:
            p = profiler().profile(email)
            self.assertIsInstance(p, AttackerTechniqueProfile)
        except Exception as e:
            self.fail(f"Null bytes caused crash: {e}")

    def test_unicode_in_from_no_crash(self):
        email = raw(from_='"Ваня Иванов" <x@evil.ru>')
        p = profiler().profile(email)
        self.assertIsInstance(p, AttackerTechniqueProfile)

    def test_very_long_xmailer_no_crash(self):
        p = profiler().profile(raw(xmailer="X" * 10_000))
        self.assertIsInstance(p, AttackerTechniqueProfile)

    def test_100_received_headers_no_crash(self):
        rcv = [f"from h{i} [1.1.1.{i % 256}] by h{i+1}" for i in range(100)]
        p = profiler().profile(raw(received=rcv))
        self.assertIsInstance(p, AttackerTechniqueProfile)

    def test_missing_date_header_no_crash(self):
        email = "From: x@y.com\nTo: v@c.com\nSubject: S\nReceived: from h [1.2.3.4] by mx\n\nbody"
        p = profiler().profile(email)
        self.assertIsInstance(p, AttackerTechniqueProfile)

    def test_malformed_spf_header_no_crash(self):
        p = profiler().profile(raw(spf="this is not a valid SPF header *** ??? !!!"))
        self.assertIsInstance(p, AttackerTechniqueProfile)

    def test_emoji_in_subject_no_crash(self):
        p = profiler().profile(raw(subject="🚨 URGENT: Verify your account 🚨"))
        self.assertIsInstance(p, AttackerTechniqueProfile)

    def test_multiple_from_headers_no_crash(self):
        email = "From: a@a.com\nFrom: b@b.com\nTo: v@c.com\nSubject: S\nDate: Mon, 17 Mar 2026 10:00:00 +0000\nReceived: from h [1.2.3.4] by mx\n\nbody"
        p = profiler().profile(email)
        self.assertIsInstance(p, AttackerTechniqueProfile)

    def test_header_analysis_none_no_crash(self):
        p = profiler().profile(raw(), header_analysis=None)
        self.assertIsInstance(p, AttackerTechniqueProfile)

    def test_campaign_timestamps_empty_list(self):
        p = profiler().profile(raw(), campaign_timestamps=[])
        self.assertIsInstance(p, AttackerTechniqueProfile)

    def test_all_techniques_populated_correctly(self):
        """All detections must have non-empty name, category, evidence."""
        email = raw(
            from_='"PayPal" <x@evil.com>',
            xmailer="GoPhish",
            xphp="100:/var/www/evil.php",
            spf="fail (test) client-ip=1.2.3.4",
            date="Mon, 17 Mar 2026 02:00:00 +0530",
            received=["from h [1.2.3.4] by mx; Mon, 17 Mar 2026 05:00:00 +0000",
                      "from unknown [unknown] by h2",
                      "from unknown [unknown] by h3",
                      "from h4 [2.2.2.2] by h3",
                      "from h5 [3.3.3.3] by h4",
                      "from origin [4.4.4.4] by h5"],
        )
        p = profiler().profile(email)
        for t in p.detected_techniques:
            self.assertTrue(t.name,      f"Technique has empty name")
            self.assertTrue(t.category,  f"Technique '{t.name}' has empty category")
            self.assertTrue(t.evidence,  f"Technique '{t.name}' has empty evidence")
            self.assertTrue(t.mitre_id,  f"Technique '{t.name}' has empty mitre_id")
            self.assertTrue(t.next_step, f"Technique '{t.name}' has empty next_step")


# ══════════════════════════════════════════════════════════════════════════════
# 11. PIPELINE INTEGRATION CHECKS (static analysis of pipeline.py)
# ══════════════════════════════════════════════════════════════════════════════
class TestPipelineIntegration(unittest.TestCase):
    """Verify that pipeline.py contains all required integration edits."""

    @classmethod
    def setUpClass(cls):
        with open(str(_find("pipeline.py"))) as f:
            cls.src = f.read()
        cls.tree = ast.parse(cls.src)

    def test_pipeline_ast_valid(self):
        """pipeline.py must parse without syntax errors."""
        # setUpClass would have raised SyntaxError if invalid
        self.assertIsNotNone(self.tree)

    def test_import_guard_present(self):
        self.assertIn("TECHNIQUE_PROFILER_AVAILABLE", self.src)

    def test_import_attacker_technique_profiler(self):
        self.assertIn("AttackerTechniqueProfiler", self.src)
        self.assertIn("AttackerTechniqueProfile",  self.src)
        self.assertIn("profile_attacker_techniques", self.src)

    def test_dataclass_field_present(self):
        self.assertIn("attacker_technique_profile: Optional[Any] = None", self.src)

    def test_init_wiring_present(self):
        self.assertIn("self.technique_profiler", self.src)
        self.assertIn("AttackerTechniqueProfiler(verbose=verbose)", self.src)

    def test_phase0_run_block_present(self):
        self.assertIn("PHASE 0: ATTACKER TECHNIQUE PROFILING", self.src)
        self.assertIn("technique_profiler.profile(", self.src)
        self.assertIn("technique_profile.print_summary()", self.src)

    def test_result_construction_wired(self):
        self.assertIn("attacker_technique_profile=technique_profile,", self.src)

    def test_passive_attribution_blocked_propagated(self):
        self.assertIn("passive_attribution_blocked", self.src)
        self.assertIn("DEPLOY_NOW", self.src)

    def test_header_integrity_discount_present(self):
        self.assertIn("header_integrity_score", self.src)
        self.assertIn("T1/T3", self.src)

    def test_phase0_warning_in_backtrack_block(self):
        self.assertIn("PHASE 0 WARNING", self.src)

    def test_phase0_before_stage_2_in_source_order(self):
        phase0_pos = self.src.index("PHASE 0: ATTACKER TECHNIQUE PROFILING")
        stage2_pos = self.src.index("[STAGE 2] Classifying IPs")
        self.assertLess(phase0_pos, stage2_pos,
                        "Phase 0 block must appear before [STAGE 2] in source")

    def test_phase0_after_stage_1_in_source_order(self):
        stage1_pos = self.src.index("[STAGE 1] Extracting email headers")
        phase0_pos = self.src.index("PHASE 0: ATTACKER TECHNIQUE PROFILING")
        self.assertGreater(phase0_pos, stage1_pos,
                           "Phase 0 block must appear after [STAGE 1] in source")

    def test_technique_profiler_none_guard(self):
        """__init__ must guard with TECHNIQUE_PROFILER_AVAILABLE before instantiating."""
        self.assertIn("if TECHNIQUE_PROFILER_AVAILABLE", self.src)

    def test_no_unconditional_import(self):
        """The import must be inside a try/except, not at module level unconditionally."""
        lines = self.src.splitlines()
        for i, line in enumerate(lines):
            if "from huntertrace.forensics.attackerTechniqueProfiler" in line:
                # The line before should be a try: or the import should follow try:
                context = "\n".join(lines[max(0, i-5):i+1])
                self.assertIn("try", context,
                               "attackerTechniqueProfiler import must be inside try block")
                break

    def test_complete_pipeline_result_line_count(self):
        """Edited pipeline.py should have more lines than original (4434)."""
        self.assertGreater(len(self.src.splitlines()), 4434)


# ══════════════════════════════════════════════════════════════════════════════
# 12. MITRE ATT&CK COVERAGE
# ══════════════════════════════════════════════════════════════════════════════
class TestMitreMapping(unittest.TestCase):

    EXPECTED_MITRE = {
        "T1036":     "display-name deception or timezone spoof",
        "T1036.005": "SPF fail / header forgery",
        "T1036.007": "homoglyph domain",
        "T1090":     "proxy chain",
        "T1090.003": "VPN or Tor",
        "T1566.001": "GoPhish / phishing kit / bot",
        "T1584":     "PHP mailer / compromised server",
    }

    def _techniques_for(self, email):
        return profiler().profile(email).detected_techniques

    def test_display_name_maps_t1036(self):
        ts = self._techniques_for(raw(from_='"PayPal" <x@evil.com>'))
        ids = [t.mitre_id for t in ts]
        self.assertIn("T1036", ids)

    def test_spf_fail_maps_t1036_005(self):
        ts = self._techniques_for(raw(spf="fail (test) client-ip=1.2.3.4"))
        ids = [t.mitre_id for t in ts]
        self.assertIn("T1036.005", ids)

    def test_proxy_chain_maps_t1090(self):
        rcv = ["from unknown [unknown] by h%d" % i for i in range(6)]
        ts = self._techniques_for(raw(received=rcv))
        ids = [t.mitre_id for t in ts]
        self.assertTrue(
            any(i in ids for i in ("T1090", "T1090.001", "T1090.002")),
            f"No T1090* in {ids}"
        )

    def test_gophish_maps_t1566_001(self):
        ts = self._techniques_for(raw(xmailer="GoPhish"))
        ids = [t.mitre_id for t in ts]
        self.assertIn("T1566.001", ids)

    def test_php_mailer_maps_t1584(self):
        ts = self._techniques_for(raw(xphp="100:/var/www/evil.php"))
        ids = [t.mitre_id for t in ts]
        self.assertIn("T1584", ids)

    def test_timezone_spoof_maps_t1036(self):
        rcv = ["from h [1.2.3.4] by mx; Mon, 17 Mar 2026 10:00:00 +0000"]
        ts = self._techniques_for(raw(
            date="Mon, 17 Mar 2026 15:30:00 +0530",
            received=rcv,
        ))
        ids = [t.mitre_id for t in ts]
        self.assertIn("T1036", ids)

    def test_all_mitre_ids_in_profile_match_techniques(self):
        email = raw(
            from_='"PayPal" <x@evil.com>',
            xmailer="GoPhish",
            xphp="100:/var/www/evil.php",
        )
        p = profiler().profile(email)
        technique_ids = {t.mitre_id for t in p.detected_techniques}
        for mid in p.all_mitre_ids:
            self.assertIn(mid, technique_ids,
                          f"all_mitre_ids contains {mid} but no technique has it")

    def test_no_detections_empty_mitre(self):
        p = profiler().profile(raw())
        self.assertEqual(p.all_mitre_ids, [])

    def test_mitre_ids_are_strings(self):
        email = raw(xmailer="GoPhish", spf="fail (test) client-ip=1.2.3.4")
        p = profiler().profile(email)
        for mid in p.all_mitre_ids:
            self.assertIsInstance(mid, str)
            self.assertRegex(mid, r"^T\d{4}(\.\d{3})?$",
                             f"MITRE ID '{mid}' does not match T####.### format")


# ══════════════════════════════════════════════════════════════════════════════
# 13. CANARY TOKEN RECOMMENDATION LOGIC
# ══════════════════════════════════════════════════════════════════════════════
class TestCanaryTokenRecommendation(unittest.TestCase):

    def test_protonmail_always_recommends_canary(self):
        p = profiler().profile(raw(from_="x@protonmail.com"))
        self.assertTrue(p.canary_token_recommended)

    def test_tutanota_always_recommends_canary(self):
        p = profiler().profile(raw(from_="x@tutanota.com"))
        self.assertTrue(p.canary_token_recommended)

    def test_high_risk_recommends_canary(self):
        # GoPhish + PHP mailer = high composite risk → canary recommended
        p = profiler().profile(raw(xmailer="GoPhish", xphp="100:/var/www/evil.php"))
        # composite_risk >= 0.50 triggers canary_recommended
        if p.composite_risk_score >= 0.50:
            self.assertTrue(p.canary_token_recommended)

    def test_clean_low_risk_may_not_recommend_canary(self):
        p = profiler().profile(raw())
        # A completely clean email with no detections has risk=0.0
        if p.composite_risk_score < 0.50 and not p.passive_attribution_blocked:
            self.assertFalse(p.canary_token_recommended)


# ══════════════════════════════════════════════════════════════════════════════
# 14. TECHNIQUE COUNT AND PROPERTY HELPERS
# ══════════════════════════════════════════════════════════════════════════════
class TestProfileProperties(unittest.TestCase):

    def test_technique_count_matches_list(self):
        p = profiler().profile(raw(xmailer="GoPhish", xphp="100:/var/www/evil.php"))
        self.assertEqual(p.technique_count, len(p.detected_techniques))

    def test_technique_count_in_to_dict(self):
        p = profiler().profile(raw(xmailer="GoPhish"))
        d = p.to_dict()
        self.assertEqual(d["technique_count"], p.technique_count)

    def test_high_confidence_techniques_filter(self):
        p = profiler().profile(raw(xmailer="GoPhish", xphp="100:/var/www/evil.php"))
        high = p.high_confidence_techniques
        for t in high:
            self.assertGreaterEqual(t.confidence, 0.85)
        for t in p.detected_techniques:
            if t.confidence >= 0.85:
                self.assertIn(t, high)

    def test_zero_techniques_on_clean_email(self):
        p = profiler().profile(raw())
        self.assertEqual(p.technique_count, 0)
        self.assertEqual(p.high_confidence_techniques, [])


# ══════════════════════════════════════════════════════════════════════════════
# RUNNER
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    loader = unittest.TestLoader()
    suite  = unittest.TestSuite()

    for cls in [
        TestDataclassContract,
        TestIdentityDetectors,
        TestInfrastructureDetectors,
        TestSendingMethodDetectors,
        TestEvasionDetectors,
        TestHeaderIntegrityScore,
        TestSerialisation,
        TestPrintSummary,
        TestConvenienceFunction,
        TestEdgeCases,
        TestPipelineIntegration,
        TestMitreMapping,
        TestCanaryTokenRecommendation,
        TestProfileProperties,
    ]:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print(f"\n{'='*60}")
    total  = result.testsRun
    failed = len(result.failures) + len(result.errors)
    passed = total - failed
    if failed:
        print(f"  {passed}/{total} passed  ✗  {failed} FAILED")
        sys.exit(1)
    else:
        print(f"  {passed}/{total} passed  ✓ ALL GREEN")