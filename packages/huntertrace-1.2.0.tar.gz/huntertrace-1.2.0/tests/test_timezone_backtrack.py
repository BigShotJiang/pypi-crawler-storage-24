#!/usr/bin/env python3
"""
TEST: Timezone Backtrack + Spoofing Detection — isolation test
==============================================================
Tests ONLY: _analyze_timezone_location() logic (vpnBacktrack.py)
No network, no email parsing, pure header analysis.

HOW SCORES ARE CALCULATED:
  Spoofed    (Received timestamp ≠ Date timezone): confidence = 0.10
  Unverified (no Received timestamp to compare):   confidence = 0.30
  Validated  (Received timestamp confirms Date tz): confidence = 0.65
  +0.08 bonus if VPN country ≠ inferred timezone region (capped at 0.73)

KEY BUG: vpnBacktrack.py timezone_regions dict uses colon format (+05:30)
         attribution.py TIMEZONE_COUNTRY_MAP uses no-colon format (+0530)
         → signals produced here cannot be consumed by the Bayesian engine.

Run: python test_timezone_backtrack.py
"""

import re
from typing import Optional, List, Dict, Tuple


TIMEZONE_REGIONS_VPNBACKTRACK = {
    # Format used in vpnBacktrack.py  — COLON format
    "+05:30": ("India", ["IN"]),
    "+09:00": ("Japan/Korea", ["JP", "KR"]),
    "+08:00": ("China/Singapore", ["CN", "SG", "MY"]),
    "+00:00": ("UK/UTC", ["GB", "IE"]),
    "+01:00": ("Europe", ["DE", "FR", "ES", "IT"]),
    "+05:00": ("Pakistan", ["PK"]),
    "+06:00": ("Bangladesh", ["BD"]),
    "-05:00": ("USA East", ["US"]),
    "-08:00": ("USA West", ["US"]),
}

TIMEZONE_COUNTRY_MAP_ATTRIBUTION = {
    # Format used in attribution.py — NO-COLON format
    "+0530": ["India", "Sri Lanka"],
    "+0900": ["Japan", "South Korea"],
    "+0800": ["China", "Philippines", "Singapore"],
    "+0000": ["United Kingdom", "Ireland", "Ghana", "Nigeria"],
    "+0100": ["Germany", "France", "Poland"],
    "+0500": ["Pakistan", "Uzbekistan"],
    "+0600": ["Bangladesh"],
    "-0500": ["United States", "Canada"],
    "-0800": ["United States", "Canada"],
}


def analyze_timezone(date_header: str, received_headers: List[str], vpn_country: str = "Unknown"):
    """Reproduce _analyze_timezone_location logic from vpnBacktrack.py."""
    evidence = []

    # Extract TZ from Date header
    tz_pattern = r'\s([+-]\d{1,2}):?(\d{2})\s*$'
    tz_match = re.search(tz_pattern, str(date_header))
    if not tz_match:
        tz_pattern = r'([+-]\d{1,2}):?(\d{2})'
        tz_match = re.search(tz_pattern, str(date_header))

    if not tz_match:
        return None, 0.0, ["No timezone found in Date header"]

    # VPN backtrack normalizes to COLON format
    tz_colon = f"{tz_match.group(1)}:{tz_match.group(2)}"
    # Attribution engine needs NO-COLON format
    tz_nocolon = f"{tz_match.group(1)}{tz_match.group(2)}"

    region, country_codes = TIMEZONE_REGIONS_VPNBACKTRACK.get(tz_colon, (None, None))
    if not region:
        return None, 0.0, [f"Timezone {tz_colon} not in vpnBacktrack regions map"]

    evidence.append(f"Date header timezone (colon fmt): {tz_colon}")
    evidence.append(f"No-colon format (attribution fmt): {tz_nocolon}")
    evidence.append(f"Inferred region (vpnBacktrack): {region}")

    # Check if attribution engine can consume this
    attr_regions = TIMEZONE_COUNTRY_MAP_ATTRIBUTION.get(tz_nocolon, [])
    if attr_regions:
        evidence.append(f"Attribution engine lookup OK: {tz_nocolon} → {attr_regions}")
    else:
        evidence.append(f"!!! ATTRIBUTION LOOKUP FAILS: '{tz_nocolon}' not in TIMEZONE_COUNTRY_MAP !!!")
        evidence.append(f"    This timezone signal will be SILENTLY DROPPED by the Bayesian engine.")

    # Server-side spoofing check
    spoofing_detected = False
    server_matches = False

    for rcvd in received_headers[:3]:
        rcvd_tz_match = re.search(r'([+-]\d{2}):?(\d{2})', str(rcvd))
        if rcvd_tz_match:
            rcvd_tz = f"{rcvd_tz_match.group(1)}:{rcvd_tz_match.group(2)}"
            if rcvd_tz == tz_colon:
                server_matches = True
                evidence.append(f"[VALIDATED] Received header confirms {rcvd_tz} == {tz_colon}")
                break
            else:
                spoofing_detected = True
                evidence.append(f"[SPOOFED] Received={rcvd_tz} vs Date={tz_colon}")

    if spoofing_detected:
        confidence = 0.10
        evidence.append("→ Spoofing detected: confidence = 0.10")
    elif server_matches:
        confidence = 0.65
        evidence.append("→ Server-corroborated: confidence = 0.65")
    else:
        confidence = 0.30
        evidence.append("→ Unverified (no Received timestamps): confidence = 0.30")

    # VPN mismatch bonus
    if vpn_country and region and vpn_country.lower() not in region.lower():
        evidence.append(f"VPN country ({vpn_country}) ≠ TZ region ({region}) → +0.08 bonus")
        confidence = min(confidence + 0.08, 0.73)
        evidence.append(f"→ After bonus: confidence = {confidence:.2f}")

    return tz_colon, confidence, evidence


def run_test(name: str, date_header: str, received_headers: List[str], vpn_country: str = "Unknown"):
    tz, conf, evidence = analyze_timezone(date_header, received_headers, vpn_country)
    print(f"\n{'='*65}")
    print(f"TEST: {name}")
    print(f"{'='*65}")
    print(f"  Date header:   {date_header}")
    print(f"  VPN country:   {vpn_country}")
    print(f"  Received hops: {len(received_headers)}")
    print()
    for ev in evidence:
        indent = "    " if ev.startswith("!") or ev.startswith("[") or ev.startswith("→") else "  "
        print(f"{indent}{ev}")
    print(f"\n  FINAL: timezone={tz}  confidence={conf:.3f}")


# ════════════════════════════════════════════════════════════════
#  CASE 1: Clean India email — corroborated by Received header
# ════════════════════════════════════════════════════════════════
run_test(
    "India (IST +05:30) — server-corroborated",
    date_header="Mon, 17 Mar 2026 14:32:00 +0530",
    received_headers=[
        "from smtp.gmail.com ([209.85.220.41]) by mx.victim.com; Mon, 17 Mar 2026 09:02:00 +0530",
    ],
    vpn_country="Netherlands"  # VPN is NL, TZ is India → mismatch bonus applies
)

# ════════════════════════════════════════════════════════════════
#  CASE 2: Spoofed Date header — Date says India, Received says US
# ════════════════════════════════════════════════════════════════
run_test(
    "Spoofed timezone — Date claims +05:30 (India), Received says -05:00 (US)",
    date_header="Mon, 17 Mar 2026 20:32:00 +0530",
    received_headers=[
        "from mail.provider.com ([98.12.34.56]) by mx.victim.com; Mon, 17 Mar 2026 10:32:00 -0500",
    ],
    vpn_country="Unknown"
)

# ════════════════════════════════════════════════════════════════
#  CASE 3: No Received timestamps — unverified
# ════════════════════════════════════════════════════════════════
run_test(
    "Unverified — Received header has no timestamp",
    date_header="Tue, 18 Mar 2026 19:51:57 +0530",
    received_headers=[
        "from unknown by mx.victim.com with SMTP id abc123",
    ],
    vpn_country="Japan"  # VPN ≠ India → small bonus
)

# ════════════════════════════════════════════════════════════════
#  CASE 4: THE FORMAT BUG — demonstrate colon vs no-colon mismatch
# ════════════════════════════════════════════════════════════════
print(f"\n{'='*65}")
print("FORMAT MISMATCH DEMONSTRATION")
print(f"{'='*65}")
print()
print("  vpnBacktrack.py stores timezone as: +05:30  (with colon)")
print("  attribution.py TIMEZONE_COUNTRY_MAP keys:  +0530  (no colon)")
print()

for raw in ["+05:30", "+0530", "+0300", "+03:00", "+0000", "+00:00"]:
    in_vpn = raw in TIMEZONE_REGIONS_VPNBACKTRACK
    in_attr = raw in TIMEZONE_COUNTRY_MAP_ATTRIBUTION
    status = "OK both" if (in_vpn and in_attr) else ("vpnBacktrack only" if in_vpn else ("attribution only" if in_attr else "NEITHER"))
    flag = " ← SIGNAL DROPPED" if in_vpn and not in_attr else ""
    print(f"  '{raw}':  vpnBacktrack={in_vpn}  attribution={in_attr}  → {status}{flag}")

print()
print("  FIX: In FingerprintExtractor._extract_tz_offset() (correlator.py),")
print("  the normalization already handles this (strips colons).")
print("  But vpnBacktrack.py feeds into attribution.py DIRECTLY via")
print("  SignalExtractor, which reads bt.backtrack_result signals.")
print("  The SignalExtractor must normalize tz_offset to no-colon format.")

# ════════════════════════════════════════════════════════════════
#  CASE 5: US West Coast — VPN same region, no bonus
# ════════════════════════════════════════════════════════════════
run_test(
    "US West Coast (-08:00) — VPN also in US, no mismatch bonus",
    date_header="Mon, 17 Mar 2026 10:00:00 -0800",
    received_headers=[
        "from smtp.yahoo.com ([98.137.11.70]) by mx.victim.com; Mon, 17 Mar 2026 10:00:00 -0800",
    ],
    vpn_country="United States"
)