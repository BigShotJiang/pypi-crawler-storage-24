#!/usr/bin/env python3
"""
test_active_analysis.py — Test suite for active analysis + validation
      pipeline integration (Phase: Active Analysis)
=====================================================================

Tests:
  1.  Module import guards / availability flags
  2.  ActiveAnalysisPipeline dataclass contracts
  3.  CanaryCallbackAnalyzer (offline, mock trigger)
  4.  FastFluxAnalyzer (offline, mock DNS)
  5.  ActiveVPNProbe (private IP guard, offline mock)
  6.  RTTGeolocator (offline mock)
  7.  InfrastructureGraphAnalyzer (offline mock headers)
  8.  ActiveAnalysisPipeline.run() signal aggregation
  9.  Signal merge + re-synthesis logic
  10. enable_active_analysis() / disable_active_analysis() API
  11. run_validation() API
  12. Pipeline.py static integration checks
  13. ValidationMetrics computation (offline)
  14. ValidationReport serialisation
  15. Edge cases / adversarial inputs

Run:
    python test_active_analysis.py
    pytest test_active_analysis.py -v

No live network required. All active probes are mocked.
"""

import sys
import ast
import json
import math
import time
import unittest
import importlib.util
from pathlib import Path
from unittest.mock import patch, MagicMock
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from collections import Counter

# ── Path resolver (same pattern as test_phase0.py) ────────────────────────────
_HERE = Path(__file__).resolve().parent

def _find(filename: str) -> Path:
    candidates = [
        _HERE / filename,
        _HERE.parent / filename,
        _HERE.parent / "huntertrace" / "active" / filename,
        _HERE.parent / "huntertrace" / "forensics" / filename,
        _HERE.parent / "huntertrace" / "core" / filename,
        Path("/mnt/project") / filename,
        Path("/mnt/user-data/outputs") / filename,
    ]
    for c in candidates:
        if c.exists():
            return c
    raise FileNotFoundError(
        f"Cannot find '{filename}'.\n"
        f"Searched: {[str(c) for c in candidates]}"
    )

def _load(name: str, path: str):
    spec = importlib.util.spec_from_file_location(name, path)
    mod  = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

# Load modules
AA  = _load("huntertrace.active.active_analysis",
            str(_find("activeAnalysis.py")))
AV  = _load("huntertrace.active.active_validation",
            str(_find("activeValidation.py")))

# Aliases
ActiveAnalysisPipeline      = AA.ActiveAnalysisPipeline
ActiveAnalysisResult        = AA.ActiveAnalysisResult
CanaryCallbackAnalyzer      = AA.CanaryCallbackAnalyzer
FastFluxAnalyzer            = AA.FastFluxAnalyzer
ActiveVPNProbe              = AA.ActiveVPNProbe
RTTGeolocator               = AA.RTTGeolocator
InfrastructureGraphAnalyzer = AA.InfrastructureGraphAnalyzer
patch_backtracker           = AA.patch_backtracker_with_active_analysis
_geolocate_ip               = AA._geolocate_ip
_is_private_ip              = AA._is_private_ip
CanaryCallbackResult        = AA.CanaryCallbackResult
FluxAnalysisResult          = AA.FluxAnalysisResult
VPNProbeResult              = AA.VPNProbeResult
RTTGeoResult                = AA.RTTGeoResult

ValidationRunner    = AV.ValidationRunner
ValidationReport    = AV.ValidationReport
ValidationMetrics   = AV.ValidationMetrics
CaseResult          = AV.CaseResult
MockIPGeolocation   = AV.MockIPGeolocation
compute_metrics     = AV.compute_metrics
_MOCK_GEO           = AV._MOCK_GEO
_geo_error_km       = AV._geo_error_km


# ── Minimal stub for BacktrackResult (for merge tests) ────────────────────────
@dataclass
class FakeSignal:
    real_ip:      Optional[str]
    real_country: Optional[str]
    confidence:   float
    evidence:     List[str] = field(default_factory=list)
    method:       Any = None

@dataclass
class FakeBacktrackResult:
    signals:                  List[FakeSignal]
    probable_real_ip:         Optional[str] = None
    probable_country:         Optional[str] = None
    backtracking_confidence:  float         = 0.5
    vpn_endpoint_ip:          str           = "1.2.3.4"
    vpn_country:              str           = "Netherlands"
    analysis_notes:           str           = ""


# ═══════════════════════════════════════════════════════════════════════════════
# 1. MODULE IMPORT GUARDS
# ═══════════════════════════════════════════════════════════════════════════════
class TestImportGuards(unittest.TestCase):

    def test_active_analysis_module_loaded(self):
        self.assertIsNotNone(AA)

    def test_active_validation_module_loaded(self):
        self.assertIsNotNone(AV)

    def test_active_analysis_exports(self):
        for name in ["ActiveAnalysisPipeline", "ActiveAnalysisResult",
                     "CanaryCallbackAnalyzer", "FastFluxAnalyzer",
                     "ActiveVPNProbe", "RTTGeolocator",
                     "InfrastructureGraphAnalyzer",
                     "patch_backtracker_with_active_analysis"]:
            self.assertTrue(hasattr(AA, name), f"AA missing {name}")

    def test_active_validation_exports(self):
        for name in ["ValidationRunner", "ValidationReport",
                     "ValidationMetrics", "CaseResult",
                     "MockIPGeolocation", "compute_metrics"]:
            self.assertTrue(hasattr(AV, name), f"AV missing {name}")

    def test_pipeline_availability_flags(self):
        # pipeline_active.py should declare both availability flags
        src = open(str(_find("pipeline_active.py")
                       if (_find("pipeline_active.py") if Path(_HERE / "pipeline_active.py").exists()
                           else None) else _find("pipeline.py"))).read() \
              if False else None
        try:
            path = _find("pipeline_active.py")
        except FileNotFoundError:
            path = _find("pipeline.py")
        src = path.read_text()
        self.assertIn("ACTIVE_ANALYSIS_AVAILABLE", src)
        self.assertIn("ACTIVE_VALIDATION_AVAILABLE", src)


# ═══════════════════════════════════════════════════════════════════════════════
# 2. DATACLASS CONTRACTS
# ═══════════════════════════════════════════════════════════════════════════════
class TestDataclassContracts(unittest.TestCase):

    def _make_empty_result(self):
        return ActiveAnalysisResult(
            signals=[], canary_result=None, flux_result=None,
            vpn_probe_result=None, rtt_result=None, graph_result=None,
            dominant_country=None, overall_confidence=0.0,
            analysis_notes="",
        )

    def test_active_analysis_result_fields(self):
        r = self._make_empty_result()
        self.assertIsInstance(r.signals, list)
        self.assertIsNone(r.dominant_country)
        self.assertEqual(r.overall_confidence, 0.0)
        self.assertIsInstance(r.analysis_notes, str)

    def test_canary_callback_result_fields(self):
        r = CanaryCallbackResult(
            token_id="abc", triggered=False, real_ip=None,
            country=None, user_agent=None, trigger_time=None,
        )
        self.assertFalse(r.triggered)
        self.assertIsNone(r.signal)

    def test_flux_analysis_result_fields(self):
        r = FluxAnalysisResult(
            domain="evil.com", distinct_ips=[], mean_ttl=300.0,
            flux_score=0.0, is_fast_flux=False, asn_countries={},
            dominant_country=None, confidence=0.0, evidence=[],
        )
        self.assertEqual(r.domain, "evil.com")
        self.assertFalse(r.is_fast_flux)

    def test_vpn_probe_result_fields(self):
        r = VPNProbeResult(
            ip="1.2.3.4", open_vpn_ports=[], org="", asn="",
            country=None, is_datacenter=False, is_vpn_provider=False,
            is_tor=False, confidence=0.0, evidence=[],
        )
        self.assertFalse(r.is_datacenter)
        self.assertIsNone(r.signal)

    def test_validation_metrics_fields(self):
        m = compute_metrics([])
        self.assertEqual(m.n_total, 0)
        self.assertEqual(m.attribution_accuracy, 0.0)
        self.assertIsInstance(m.per_scenario, dict)
        self.assertIsInstance(m.per_technique, dict)
        self.assertIsInstance(m.coverage, dict)


# ═══════════════════════════════════════════════════════════════════════════════
# 3. CANARY CALLBACK ANALYZER
# ═══════════════════════════════════════════════════════════════════════════════
class TestCanaryCallbackAnalyzer(unittest.TestCase):

    def setUp(self):
        # No live server — callback_host="" means _poll_http returns None
        self.analyzer = CanaryCallbackAnalyzer(callback_host="", verbose=False)

    def test_no_trigger_no_server(self):
        result = self.analyzer.check("token-abc")
        self.assertFalse(result.triggered)
        self.assertIsNone(result.real_ip)
        self.assertIsNone(result.signal)

    def test_register_trigger_returns_result(self):
        with patch.object(AA, "_geolocate_ip", return_value="India"):
            result = self.analyzer.register_trigger("token-xyz", "103.21.244.1", "Excel/15.0")
        self.assertTrue(result.triggered)
        self.assertEqual(result.real_ip, "103.21.244.1")
        self.assertIsNotNone(result.signal)

    def test_register_trigger_confidence_direct(self):
        with patch.object(AA, "_geolocate_ip", return_value="India"):
            result = self.analyzer.register_trigger("t", "103.21.244.1")
        self.assertEqual(result.signal.confidence, CanaryCallbackAnalyzer.CONF_DIRECT_IP)

    def test_register_trigger_country_geolocated(self):
        with patch.object(AA, "_geolocate_ip", return_value="Russia"):
            result = self.analyzer.register_trigger("t", "5.8.18.10")
        self.assertEqual(result.country, "Russia")

    def test_register_trigger_evidence_contains_ip(self):
        with patch.object(AA, "_geolocate_ip", return_value="Brazil"):
            result = self.analyzer.register_trigger("t", "177.71.0.1", "Adobe Acrobat")
        ev = " ".join(result.signal.evidence)
        self.assertIn("177.71.0.1", ev)

    def test_check_no_trigger_when_no_host(self):
        # With empty host, _poll_http returns None → no trigger
        result = self.analyzer.check("any-token")
        self.assertFalse(result.triggered)
        self.assertIsNone(result.signal)

    def test_signal_method_is_canarytoken_callback(self):
        with patch.object(AA, "_geolocate_ip", return_value="Germany"):
            result = self.analyzer.register_trigger("t", "185.220.101.1")
        method_name = result.signal.method.value if hasattr(result.signal.method, 'value') \
                      else str(result.signal.method)
        self.assertIn("canary", method_name.lower())

    def test_confidence_constants(self):
        self.assertEqual(CanaryCallbackAnalyzer.CONF_DIRECT_IP,  0.97)
        self.assertEqual(CanaryCallbackAnalyzer.CONF_DNS_ONLY,   0.55)
        self.assertEqual(CanaryCallbackAnalyzer.CONF_NO_TRIGGER, 0.00)


# ═══════════════════════════════════════════════════════════════════════════════
# 4. FAST-FLUX ANALYZER
# ═══════════════════════════════════════════════════════════════════════════════
class TestFastFluxAnalyzer(unittest.TestCase):

    def _mock_flux(self, ips, ttl=60):
        """Return a FluxAnalysisResult with mocked IPs and TTL."""
        analyzer = FastFluxAnalyzer(sample_count=1, verbose=False)
        with patch.object(analyzer, "_query_a_records", return_value=(ips, [ttl]*len(ips))), \
             patch.object(AA, "_geolocate_ip", side_effect=lambda ip, **kw: _MOCK_GEO.lookup(ip)):
            return analyzer.analyze("evil-domain.com")

    def test_empty_domain_no_crash(self):
        analyzer = FastFluxAnalyzer(sample_count=1, verbose=False)
        with patch.object(analyzer, "_query_a_records", return_value=([], [])):
            result = analyzer.analyze("nonexistent.invalid")
        self.assertFalse(result.is_fast_flux)
        self.assertEqual(result.confidence, 0.0)

    def test_flux_score_formula_low_ttl_many_ips(self):
        # Low TTL + many IPs → flux_score = 0.55*1.0 + 0.45*(10/10) = 1.00
        result = self._mock_flux(
            [f"94.100.{i}.1" for i in range(10)], ttl=60)
        self.assertGreater(result.flux_score, 0.55)
        self.assertTrue(result.is_fast_flux)

    def test_flux_score_formula_high_ttl_one_ip(self):
        # High TTL + 1 IP → flux_score = 0.55*0 + 0.45*0.1 = 0.045
        result = self._mock_flux(["8.8.8.8"], ttl=3600)
        self.assertLess(result.flux_score, 0.55)
        self.assertFalse(result.is_fast_flux)

    def test_dominant_country_populated(self):
        result = self._mock_flux(["94.100.1.1", "94.100.2.1", "94.100.3.1"], ttl=60)
        # All 94.100.x.x map to Russia via mock geo
        if result.dominant_country:
            self.assertIsInstance(result.dominant_country, str)

    def test_signal_produced_when_country_found(self):
        result = self._mock_flux(["8.8.8.8"], ttl=3600)
        if result.dominant_country:
            self.assertIsNotNone(result.signal)
            self.assertIsInstance(result.signal.confidence, float)
            self.assertGreater(result.signal.confidence, 0.0)

    def test_evidence_contains_citation(self):
        result = self._mock_flux(["8.8.8.8"], ttl=3600)
        ev_str = " ".join(result.evidence)
        self.assertIn("Holz", ev_str)

    def test_confidence_tiers(self):
        # flux_score > 0.7 and country → 0.70
        analyzer = FastFluxAnalyzer(sample_count=1, verbose=False)
        score = analyzer._compute_flux_score(
            [f"1.2.3.{i}" for i in range(10)], min_ttl=60)
        self.assertGreater(score, 0.7)


# ═══════════════════════════════════════════════════════════════════════════════
# 5. ACTIVE VPN PROBE
# ═══════════════════════════════════════════════════════════════════════════════
class TestActiveVPNProbe(unittest.TestCase):

    def test_private_ip_returns_no_signal(self):
        probe = ActiveVPNProbe(verbose=False)
        result = probe.probe("192.168.1.1")
        self.assertIsNone(result.signal)
        self.assertEqual(result.confidence, 0.0)

    def test_loopback_returns_no_signal(self):
        probe = ActiveVPNProbe(verbose=False)
        result = probe.probe("127.0.0.1")
        self.assertIsNone(result.signal)

    def test_datacenter_no_ports_medium_confidence(self):
        probe = ActiveVPNProbe(verbose=False)
        geo = {"status": "success", "country": "United States",
               "org": "Amazon AWS", "as": "AS16509",
               "regionName": "", "city": "", "lat": 0, "lon": 0, "isp": ""}
        with patch.object(probe, "_tcp_probe", return_value=False), \
             patch.object(AA, "_geolocate_ip_full", return_value=geo):
            result = probe.probe("52.1.2.3")
        self.assertTrue(result.is_datacenter)
        self.assertAlmostEqual(result.confidence, 0.55)

    def test_vpn_port_and_datacenter_high_confidence(self):
        probe = ActiveVPNProbe(verbose=False)
        geo = {"status": "success", "country": "Netherlands",
               "org": "DigitalOcean LLC", "as": "AS14061",
               "regionName": "", "city": "", "lat": 0, "lon": 0, "isp": ""}
        with patch.object(probe, "_tcp_probe", side_effect=lambda ip, port: port == 1194), \
             patch.object(AA, "_geolocate_ip_full", return_value=geo):
            result = probe.probe("193.138.218.1")
        self.assertIn(1194, result.open_vpn_ports)
        self.assertGreaterEqual(result.confidence, 0.90)
        self.assertIsNotNone(result.signal)

    def test_tor_org_high_confidence(self):
        probe = ActiveVPNProbe(verbose=False)
        geo = {"status": "success", "country": "Germany",
               "org": "Tor Project", "as": "AS000",
               "regionName": "", "city": "", "lat": 0, "lon": 0, "isp": ""}
        with patch.object(probe, "_tcp_probe", return_value=False), \
             patch.object(AA, "_geolocate_ip_full", return_value=geo):
            result = probe.probe("185.220.101.1")
        self.assertTrue(result.is_tor)
        self.assertAlmostEqual(result.confidence, 0.90)

    def test_residential_low_confidence(self):
        probe = ActiveVPNProbe(verbose=False)
        geo = {"status": "success", "country": "India",
               "org": "Jio Reliance", "as": "AS55836",
               "regionName": "", "city": "", "lat": 0, "lon": 0, "isp": ""}
        with patch.object(probe, "_tcp_probe", return_value=False), \
             patch.object(AA, "_geolocate_ip_full", return_value=geo):
            result = probe.probe("49.32.0.1")
        self.assertFalse(result.is_datacenter)
        self.assertFalse(result.is_vpn_provider)
        self.assertAlmostEqual(result.confidence, 0.10)

    def test_signal_confidence_inverted(self):
        """VPN signal confidence = 1 - vpn_confidence (inverse: low means real IP)."""
        probe = ActiveVPNProbe(verbose=False)
        geo = {"status": "success", "country": "Netherlands",
               "org": "NordVPN Ltd", "as": "AS0",
               "regionName": "", "city": "", "lat": 0, "lon": 0, "isp": ""}
        with patch.object(probe, "_tcp_probe", return_value=False), \
             patch.object(AA, "_geolocate_ip_full", return_value=geo):
            result = probe.probe("95.1.2.3")
        if result.signal:
            self.assertLess(result.signal.confidence, result.confidence)


# ═══════════════════════════════════════════════════════════════════════════════
# 6. RTT GEOLOCATOR
# ═══════════════════════════════════════════════════════════════════════════════
class TestRTTGeolocator(unittest.TestCase):

    def _probe_result(self, target_ip, mock_rtt_ms=50.0):
        """Run RTTGeolocator with mocked TCP RTT."""
        geo = RTTGeolocator(probe_timeout=1.0, verbose=False)
        with patch.object(geo, "_tcp_rtt", return_value=mock_rtt_ms):
            return geo.geolocate(target_ip)

    def test_private_ip_returns_zero_confidence(self):
        geo = RTTGeolocator(probe_timeout=1.0, verbose=False)
        result = geo.geolocate("192.168.1.1")
        self.assertEqual(result.confidence, 0.0)

    def test_result_fields_present(self):
        result = self._probe_result("8.8.8.8", mock_rtt_ms=20.0)
        self.assertIsInstance(result.confidence, float)
        self.assertIsInstance(result.evidence, list)
        self.assertIsInstance(result.measurements, list)

    def test_confidence_in_range(self):
        result = self._probe_result("8.8.8.8", mock_rtt_ms=20.0)
        self.assertGreaterEqual(result.confidence, 0.0)
        self.assertLessEqual(result.confidence, 1.0)

    def test_estimated_country_string_or_none(self):
        result = self._probe_result("8.8.8.8", mock_rtt_ms=20.0)
        if result.estimated_country:
            self.assertIsInstance(result.estimated_country, str)

    def test_min_probes_required_for_signal(self):
        # With only 1 measurement, confidence should be 0 (RTT_MIN_PROBES = 2)
        geo = RTTGeolocator(probe_timeout=1.0, verbose=False)
        with patch.object(geo, "_tcp_rtt", return_value=None):
            result = geo.geolocate("8.8.8.8")
        self.assertEqual(result.confidence, 0.0)
        self.assertIsNone(result.signal)

    def test_fiber_speed_constant(self):
        self.assertEqual(AA.FIBER_SPEED_KM_PER_MS, 200.0)


# ═══════════════════════════════════════════════════════════════════════════════
# 7. INFRASTRUCTURE GRAPH ANALYZER
# ═══════════════════════════════════════════════════════════════════════════════
class TestInfrastructureGraphAnalyzer(unittest.TestCase):

    def _run_graph(self, headers, mock_country="Russia"):
        analyzer = InfrastructureGraphAnalyzer(timeout=2.0, verbose=False)
        with patch.object(analyzer, "_process_ns",   side_effect=lambda *a: None), \
             patch.object(analyzer, "_process_mx",   side_effect=lambda *a: None), \
             patch.object(analyzer, "_process_spf",  side_effect=lambda *a: None), \
             patch.object(analyzer, "_process_dkim", side_effect=lambda *a: None), \
             patch.object(analyzer, "_process_received_ips",
                          side_effect=lambda hdr, nodes, edges, votes, ev:
                              votes.__setitem__(mock_country,
                                               votes.get(mock_country, 0) + 3.0)
                              or ev.append(f"Received IP → {mock_country}")):
            return analyzer.analyze(headers)

    def test_returns_infra_graph_result(self):
        headers = {"From": "a@yandex.ru", "DKIM-Signature": "v=1; d=yandex.ru; s=m"}
        result = self._run_graph(headers, "Russia")
        self.assertIsNotNone(result)
        self.assertIsInstance(result.confidence, float)

    def test_dominant_country_from_votes(self):
        headers = {"From": "a@yandex.ru"}
        result = self._run_graph(headers, "Russia")
        self.assertEqual(result.dominant_country, "Russia")

    def test_high_vote_count_gives_high_confidence(self):
        # 3+ votes → confidence 0.80
        headers = {"From": "a@yandex.ru"}
        result = self._run_graph(headers, "Russia")
        self.assertGreaterEqual(result.confidence, 0.65)

    def test_signal_produced_when_country_found(self):
        headers = {"From": "a@yandex.ru"}
        result = self._run_graph(headers, "Russia")
        if result.dominant_country:
            self.assertIsNotNone(result.signal)

    def test_no_domain_no_crash(self):
        headers = {}
        result = self._run_graph(headers, "Unknown")
        self.assertIsInstance(result.confidence, float)

    def test_evidence_contains_citation(self):
        headers = {"From": "a@yandex.ru"}
        result = self._run_graph(headers, "Russia")
        ev_str = " ".join(result.evidence)
        self.assertIn("Prasad", ev_str)

    def test_extract_domain_from_from_header(self):
        analyzer = InfrastructureGraphAnalyzer(timeout=2.0, verbose=False)
        headers = {"From": "user@evil-domain.com"}
        domain = analyzer._extract_domain(headers)
        self.assertEqual(domain, "evil-domain.com")

    def test_extract_domain_prefers_dkim(self):
        analyzer = InfrastructureGraphAnalyzer(timeout=2.0, verbose=False)
        headers = {
            "From": "user@spoofed.com",
            "DKIM-Signature": "v=1; a=rsa; d=real-domain.ru; s=sel"
        }
        domain = analyzer._extract_domain(headers)
        self.assertEqual(domain, "real-domain.ru")


# ═══════════════════════════════════════════════════════════════════════════════
# 8. ACTIVE ANALYSIS PIPELINE — run() SIGNAL AGGREGATION
# ═══════════════════════════════════════════════════════════════════════════════
class TestActiveAnalysisPipelineRun(unittest.TestCase):

    def _make_pipeline(self, **kwargs):
        defaults = dict(
            canary_host="", run_vpn_probe=False, run_rtt=False,
            run_flux=False, run_graph=False, run_canary=False,
            timeout=2.0, verbose=False,
        )
        defaults.update(kwargs)
        return ActiveAnalysisPipeline(**defaults)

    def test_all_disabled_no_signals(self):
        p = self._make_pipeline()
        result = p.run(email_headers={"From": "x@evil.com"})
        self.assertIsInstance(result, ActiveAnalysisResult)
        self.assertEqual(len(result.signals), 0)
        self.assertIsNone(result.dominant_country)
        self.assertEqual(result.overall_confidence, 0.0)

    def test_canary_triggered_adds_signal(self):
        p = self._make_pipeline(run_canary=True)
        mock_signal = FakeSignal(
            real_ip="5.8.18.10", real_country="Russia", confidence=0.97)
        mock_result = CanaryCallbackResult(
            token_id="tok", triggered=True, real_ip="5.8.18.10",
            country="Russia", user_agent="Excel", trigger_time="2026-01-01",
            signal=mock_signal,
        )
        with patch.object(p.canary_analyzer, "check", return_value=mock_result):
            result = p.run(
                email_headers={"From": "x@evil.com"},
                canary_token_id="tok-abc",
            )
        self.assertEqual(len(result.signals), 1)
        self.assertEqual(result.dominant_country, "Russia")
        self.assertAlmostEqual(result.overall_confidence, 0.97)

    def test_no_canary_token_skips_canary(self):
        p = self._make_pipeline(run_canary=True)
        with patch.object(p.canary_analyzer, "check") as mock_check:
            result = p.run(
                email_headers={"From": "x@evil.com"},
                canary_token_id=None,   # no token → skip
            )
        mock_check.assert_not_called()
        self.assertEqual(len(result.signals), 0)

    def test_graph_signal_added_when_enabled(self):
        p = self._make_pipeline(run_graph=True)
        from huntertrace.active.active_analysis import InfraGraphResult, InfraNode, InfraEdge
        mock_signal = FakeSignal(real_ip=None, real_country="India", confidence=0.65)
        mock_graph = InfraGraphResult(
            seed_domain="evil.com", nodes=[], edges={},
            country_votes={"India": 2.0}, dominant_country="India",
            confidence=0.65, evidence=["NS → India"], signal=mock_signal,
        )
        with patch.object(p.graph_analyzer, "analyze", return_value=mock_graph):
            result = p.run(email_headers={"From": "x@evil.com"})
        self.assertEqual(len(result.signals), 1)
        self.assertEqual(result.dominant_country, "India")

    def test_multiple_signals_country_aggregation(self):
        p = self._make_pipeline(run_canary=True, run_graph=True)
        canary_signal = FakeSignal(real_ip="103.21.244.1", real_country="India", confidence=0.97)
        graph_signal  = FakeSignal(real_ip=None, real_country="India", confidence=0.65)
        from huntertrace.active.active_analysis import InfraGraphResult
        mock_canary = CanaryCallbackResult(
            token_id="t", triggered=True, real_ip="103.21.244.1",
            country="India", user_agent="", trigger_time="2026-01-01",
            signal=canary_signal,
        )
        mock_graph = InfraGraphResult(
            seed_domain="x.com", nodes=[], edges={},
            country_votes={"India": 2.0}, dominant_country="India",
            confidence=0.65, evidence=[], signal=graph_signal,
        )
        with patch.object(p.canary_analyzer, "check", return_value=mock_canary), \
             patch.object(p.graph_analyzer, "analyze", return_value=mock_graph):
            result = p.run(
                email_headers={"From": "x@evil.com"},
                canary_token_id="tok",
            )
        self.assertEqual(len(result.signals), 2)
        self.assertEqual(result.dominant_country, "India")
        self.assertGreater(result.overall_confidence, 0.0)

    def test_overall_confidence_bounded(self):
        p = self._make_pipeline(run_canary=True)
        # Even with very high confidence, result is capped at 1.0
        sig = FakeSignal(real_ip="1.2.3.4", real_country="Russia", confidence=0.99)
        mock_r = CanaryCallbackResult(
            token_id="t", triggered=True, real_ip="1.2.3.4",
            country="Russia", user_agent="", trigger_time="now",
            signal=sig,
        )
        with patch.object(p.canary_analyzer, "check", return_value=mock_r):
            result = p.run({"From": "x@evil.com"}, canary_token_id="t")
        self.assertLessEqual(result.overall_confidence, 1.0)

    def test_analysis_notes_populated(self):
        p = self._make_pipeline()
        result = p.run({"From": "x@evil.com"})
        self.assertIsInstance(result.analysis_notes, str)
        self.assertGreater(len(result.analysis_notes), 0)

    def test_extract_domain_from_pipeline(self):
        domain = ActiveAnalysisPipeline._extract_domain(
            {"From": "attacker@evil.ru"}
        )
        self.assertEqual(domain, "evil.ru")

    def test_extract_domain_prefers_dkim(self):
        domain = ActiveAnalysisPipeline._extract_domain({
            "From": "x@spoof.com",
            "DKIM-Signature": "v=1; d=real.ru; s=m",
        })
        self.assertEqual(domain, "real.ru")


# ═══════════════════════════════════════════════════════════════════════════════
# 9. SIGNAL MERGE + RE-SYNTHESIS
# ═══════════════════════════════════════════════════════════════════════════════
class TestSignalMergeResynthesis(unittest.TestCase):
    """Test the merge logic from the pipeline's active analysis block."""

    def _merge(self, existing_signals, new_signals):
        """Replicate pipeline merge logic."""
        combined = list(existing_signals) + new_signals
        ip_scores:  dict = Counter()
        cty_scores: dict = Counter()
        for s in combined:
            if s.real_ip:
                ip_scores[s.real_ip]       += s.confidence
            if s.real_country:
                cty_scores[s.real_country] += s.confidence
        best_ip = (max(ip_scores, key=ip_scores.__getitem__)
                   if ip_scores and max(ip_scores.values()) > 0.60 else None)
        best_cty = (max(cty_scores, key=cty_scores.__getitem__)
                    if cty_scores and max(cty_scores.values()) > 0.50 else None)
        new_conf = min(
            sum(s.confidence for s in combined) / max(len(combined), 1), 1.0)
        return best_ip, best_cty, new_conf

    def test_dominant_country_from_high_confidence_signal(self):
        existing = [FakeSignal(None, "Netherlands", 0.60)]
        active   = [FakeSignal("5.8.18.10", "Russia", 0.97)]
        _, country, _ = self._merge(existing, active)
        self.assertEqual(country, "Russia")  # 0.97 > 0.60

    def test_ip_update_only_above_threshold(self):
        existing = [FakeSignal("1.2.3.4", "Netherlands", 0.60)]
        active   = [FakeSignal("5.8.18.10", "Russia", 0.50)]
        best_ip, _, _ = self._merge(existing, active)
        # 0.50 not > 0.60 threshold → no IP update from active alone
        self.assertIsNone(best_ip)

    def test_confidence_averaged_across_all_signals(self):
        sigs = [FakeSignal(None, "Russia", 0.80),
                FakeSignal(None, "Russia", 0.60)]
        _, _, conf = self._merge(sigs, [])
        self.assertAlmostEqual(conf, 0.70, places=5)

    def test_confidence_capped_at_1(self):
        sigs = [FakeSignal(None, "X", 1.0), FakeSignal(None, "X", 1.0)]
        _, _, conf = self._merge(sigs, [])
        self.assertLessEqual(conf, 1.0)

    def test_empty_signals_no_crash(self):
        best_ip, best_cty, conf = self._merge([], [])
        self.assertIsNone(best_ip)
        self.assertIsNone(best_cty)
        self.assertEqual(conf, 0.0)

    def test_multiple_countries_highest_wins(self):
        sigs = [
            FakeSignal(None, "Russia", 0.90),
            FakeSignal(None, "India",  0.30),
            FakeSignal(None, "Russia", 0.60),
        ]
        _, country, _ = self._merge(sigs, [])
        self.assertEqual(country, "Russia")  # 0.90 + 0.60 = 1.50 vs 0.30


# ═══════════════════════════════════════════════════════════════════════════════
# 10. enable_active_analysis() / disable_active_analysis() API
# ═══════════════════════════════════════════════════════════════════════════════
class TestEnableActiveAnalysis(unittest.TestCase):
    """Load pipeline.py and test the public opt-in API."""

    @classmethod
    def setUpClass(cls):
        try:
            path = _find("pipeline_active.py")
        except FileNotFoundError:
            path = _find("pipeline.py")
        cls.src = path.read_text()

    def test_enable_method_present(self):
        self.assertIn("def enable_active_analysis(", self.src)

    def test_disable_method_present(self):
        self.assertIn("def disable_active_analysis(", self.src)

    def test_run_validation_method_present(self):
        self.assertIn("def run_validation(", self.src)

    def test_enable_sets_active_enabled(self):
        self.assertIn("self._active_enabled = True", self.src)

    def test_disable_clears_active_enabled(self):
        self.assertIn("self._active_enabled = False", self.src)

    def test_enable_returns_self_for_chaining(self):
        # Method must return self
        # Find the enable method body
        idx = self.src.index("def enable_active_analysis(")
        snippet = self.src[idx:idx+2000]
        self.assertIn("return self", snippet)

    def test_enable_guard_checks_availability(self):
        idx = self.src.index("def enable_active_analysis(")
        snippet = self.src[idx:idx+2000]
        self.assertIn("ACTIVE_ANALYSIS_AVAILABLE", snippet)

    def test_active_pipeline_instantiated_in_enable(self):
        idx = self.src.index("def enable_active_analysis(")
        snippet = self.src[idx:idx+2000]
        self.assertIn("ActiveAnalysisPipeline(", snippet)

    def test_run_validation_calls_validation_runner(self):
        idx = self.src.index("def run_validation(")
        snippet = self.src[idx:idx+1000]
        self.assertIn("ValidationRunner", snippet)
        self.assertIn("run_all()", snippet)

    def test_active_enabled_flag_initialised_false(self):
        self.assertIn("self._active_enabled: bool = False", self.src)


# ═══════════════════════════════════════════════════════════════════════════════
# 11. PIPELINE.PY STATIC INTEGRATION CHECKS
# ═══════════════════════════════════════════════════════════════════════════════
class TestPipelineIntegration(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        try:
            path = _find("pipeline_active.py")
        except FileNotFoundError:
            path = _find("pipeline.py")
        cls.src  = path.read_text()
        cls.tree = ast.parse(cls.src)

    def test_pipeline_ast_valid(self):
        self.assertIsNotNone(self.tree)

    def test_active_analysis_import_guard(self):
        self.assertIn("ACTIVE_ANALYSIS_AVAILABLE", self.src)

    def test_active_validation_import_guard(self):
        self.assertIn("ACTIVE_VALIDATION_AVAILABLE", self.src)

    def test_active_analysis_result_field_on_dataclass(self):
        self.assertIn("active_analysis_result: Optional[Any] = None", self.src)

    def test_active_pipeline_init_member(self):
        self.assertIn("self.active_pipeline", self.src)

    def test_active_enabled_init_member(self):
        self.assertIn("self._active_enabled", self.src)

    def test_active_analysis_run_block_present(self):
        self.assertIn("ACTIVE ANALYSIS (opt-in)", self.src)
        self.assertIn("self._active_enabled and self.active_pipeline", self.src)

    def test_active_result_in_result_construction(self):
        self.assertIn("active_analysis_result=active_analysis_result,", self.src)

    def test_signal_merge_into_backtrack(self):
        self.assertIn("vpn_backtrack_analysis.signals.extend", self.src)

    def test_re_synthesis_logic_present(self):
        self.assertIn("probable_real_ip", self.src)
        self.assertIn("probable_country", self.src)
        self.assertIn("backtracking_confidence", self.src)

    def test_active_block_after_geolocation_in_source(self):
        geo_pos    = self.src.index("[GEOLOCATION] Enriching attacker IP location")
        active_pos = self.src.index("ACTIVE ANALYSIS (opt-in)")
        self.assertGreater(active_pos, geo_pos,
                           "Active analysis block must come after geolocation")

    def test_active_block_before_bayesian_in_source(self):
        # Search only within run() body — BAYESIAN ATTRIBUTION appears earlier
        # in generate_text_report(); anchor to the run() definition
        run_pos    = self.src.index("def run(self, email_file:")
        active_pos = self.src.index("ACTIVE ANALYSIS (opt-in)", run_pos)
        bayes_pos  = self.src.index("BAYESIAN ATTRIBUTION (Layer 5)", run_pos)
        self.assertLess(active_pos, bayes_pos,
                        "Active analysis block must come before Bayesian attribution in run()")

    def test_active_analysis_opt_in_not_unconditional(self):
        # Must be guarded by self._active_enabled
        idx = self.src.index("ACTIVE ANALYSIS (opt-in)")
        snippet = self.src[idx:idx+500]
        self.assertIn("_active_enabled", snippet)

    def test_canary_token_field_in_active_headers(self):
        self.assertIn("X-HunterTrace-Canary", self.src)

    def test_line_count_exceeds_original(self):
        # Edited pipeline should have more lines than the original 4525
        self.assertGreater(len(self.src.splitlines()), 4525)


# ═══════════════════════════════════════════════════════════════════════════════
# 12. VALIDATION METRICS COMPUTATION
# ═══════════════════════════════════════════════════════════════════════════════
class TestValidationMetrics(unittest.TestCase):

    def _make_result(self, pred, true, conf, scenario="normal", technique="canary"):
        correct = (pred == true) if pred else False
        in_top3 = correct
        return CaseResult(
            case_id="X", technique=technique, scenario=scenario,
            true_country=true, predicted_country=pred,
            confidence=conf, signals_fired=1 if pred else 0,
            geo_error_km=_geo_error_km(pred, true),
            country_correct=correct, in_top3=in_top3,
            elapsed_ms=1.0,
        )

    def test_empty_returns_zero_metrics(self):
        m = compute_metrics([])
        self.assertEqual(m.n_total, 0)
        self.assertEqual(m.attribution_accuracy, 0.0)

    def test_all_correct(self):
        results = [self._make_result("Russia", "Russia", 0.90) for _ in range(5)]
        m = compute_metrics(results)
        self.assertEqual(m.attribution_accuracy, 1.0)
        self.assertEqual(m.false_attribution_rate, 0.0)

    def test_all_wrong(self):
        results = [self._make_result("India", "Russia", 0.80) for _ in range(4)]
        m = compute_metrics(results)
        self.assertEqual(m.attribution_accuracy, 0.0)
        self.assertEqual(m.false_attribution_rate, 1.0)

    def test_abstention_rate(self):
        results = [
            self._make_result("Russia", "Russia", 0.90),
            self._make_result(None,     "India",  0.00),  # abstention
        ]
        m = compute_metrics(results)
        self.assertAlmostEqual(m.abstention_rate, 0.5)

    def test_per_scenario_breakdown(self):
        results = [
            self._make_result("Russia", "Russia", 0.90, scenario="normal"),
            self._make_result("India",  "Russia", 0.70, scenario="vpn"),
        ]
        m = compute_metrics(results)
        self.assertIn("normal", m.per_scenario)
        self.assertIn("vpn",    m.per_scenario)
        self.assertEqual(m.per_scenario["normal"], 1.0)
        self.assertEqual(m.per_scenario["vpn"],    0.0)

    def test_per_technique_breakdown(self):
        results = [
            self._make_result("Russia", "Russia", 0.90, technique="canary"),
            self._make_result("India",  "India",  0.65, technique="graph"),
        ]
        m = compute_metrics(results)
        self.assertIn("canary", m.per_technique)
        self.assertIn("graph",  m.per_technique)

    def test_geo_error_computed(self):
        results = [self._make_result("Russia", "Russia", 0.90)]
        m = compute_metrics(results)
        self.assertEqual(m.mean_geo_error_km, 0.0)  # same country → 0 km

    def test_geo_error_cross_country(self):
        # Russia → India error should be large
        err = _geo_error_km("Russia", "India")
        self.assertIsNotNone(err)
        self.assertGreater(err, 3000.0)  # > 3000 km

    def test_ece_in_range(self):
        results = [
            self._make_result("Russia", "Russia", 0.90),
            self._make_result("India",  "Russia", 0.80),
        ]
        m = compute_metrics(results)
        self.assertGreaterEqual(m.ece, 0.0)
        self.assertLessEqual(m.ece, 1.0)

    def test_coverage_fraction(self):
        results = [
            self._make_result("Russia", "Russia", 0.90, technique="canary"),
            self._make_result(None,     "India",  0.00, technique="canary"),
        ]
        m = compute_metrics(results)
        self.assertAlmostEqual(m.coverage["canary"], 0.5)


# ═══════════════════════════════════════════════════════════════════════════════
# 13. VALIDATION REPORT SERIALISATION
# ═══════════════════════════════════════════════════════════════════════════════
class TestValidationReport(unittest.TestCase):

    def _make_report(self):
        r = CaseResult(
            case_id="C1", technique="canary", scenario="normal",
            true_country="India", predicted_country="India",
            confidence=0.97, signals_fired=1,
            geo_error_km=0.0, country_correct=True, in_top3=True,
            elapsed_ms=5.0,
        )
        m = compute_metrics([r])
        return ValidationReport(
            timestamp="2026-03-17T10:00:00Z",
            case_results=[r],
            metrics=m,
            technique_reports={"canary": m},
        )

    def test_print_summary_no_crash(self):
        import io
        buf = io.StringIO()
        old, sys.stdout = sys.stdout, buf
        try:
            self._make_report().print_summary()
        finally:
            sys.stdout = old
        output = buf.getvalue()
        self.assertIn("HUNTЕРТRACE", output)
        self.assertIn("Accuracy", output)

    def test_save_json_produces_valid_file(self):
        import tempfile, os
        with tempfile.NamedTemporaryFile(
            suffix=".json", delete=False, mode="w"
        ) as f:
            path = f.name
        try:
            self._make_report().save_json(path)
            with open(path) as fh:
                data = json.load(fh)
            self.assertIn("timestamp", data)
            self.assertIn("metrics", data)
            self.assertIn("case_results", data)
        finally:
            os.unlink(path)

    def test_case_results_serialised(self):
        import tempfile, os
        with tempfile.NamedTemporaryFile(
            suffix=".json", delete=False, mode="w"
        ) as f:
            path = f.name
        try:
            self._make_report().save_json(path)
            with open(path) as fh:
                data = json.load(fh)
            self.assertEqual(len(data["case_results"]), 1)
            cr = data["case_results"][0]
            self.assertEqual(cr["technique"], "canary")
            self.assertEqual(cr["true_country"], "India")
        finally:
            os.unlink(path)


# ═══════════════════════════════════════════════════════════════════════════════
# 14. MOCK IP GEOLOCATION TABLE
# ═══════════════════════════════════════════════════════════════════════════════
class TestMockIPGeolocation(unittest.TestCase):

    def test_known_ip_returns_country(self):
        self.assertEqual(_MOCK_GEO.lookup("8.8.8.8"),       "United States")
        self.assertEqual(_MOCK_GEO.lookup("94.100.180.1"),   "Russia")
        self.assertEqual(_MOCK_GEO.lookup("103.21.244.1"),   "India")
        self.assertEqual(_MOCK_GEO.lookup("185.220.101.5"),  "Germany")
        self.assertEqual(_MOCK_GEO.lookup("177.71.0.1"),     "Brazil")

    def test_private_ip_returns_none(self):
        self.assertIsNone(_MOCK_GEO.lookup("192.168.1.1"))
        self.assertIsNone(_MOCK_GEO.lookup("10.0.0.1"))
        self.assertIsNone(_MOCK_GEO.lookup("172.16.0.1"))

    def test_unknown_ip_returns_unknown(self):
        result = _MOCK_GEO.lookup("200.200.200.200")
        # Not in table → "Unknown" or None
        self.assertTrue(result in (None, "Unknown"))

    def test_longer_prefix_wins(self):
        # 103.21.244.x → "India" (longer prefix wins over 103.x → "India")
        self.assertEqual(_MOCK_GEO.lookup("103.21.244.50"), "India")

    def test_empty_string_returns_none(self):
        self.assertIsNone(_MOCK_GEO.lookup(""))


# ═══════════════════════════════════════════════════════════════════════════════
# 15. EDGE CASES
# ═══════════════════════════════════════════════════════════════════════════════
class TestEdgeCases(unittest.TestCase):

    def test_is_private_ip_rfc1918(self):
        for ip in ["10.0.0.1", "172.16.5.5", "192.168.1.100"]:
            self.assertTrue(_is_private_ip(ip), f"{ip} should be private")

    def test_is_private_ip_public(self):
        for ip in ["8.8.8.8", "1.1.1.1", "94.100.180.1"]:
            self.assertFalse(_is_private_ip(ip), f"{ip} should be public")

    def test_is_private_ip_invalid(self):
        # Invalid IP strings should return True (treated as private)
        self.assertTrue(_is_private_ip("not-an-ip"))

    def test_active_pipeline_no_candidate_ip_skips_probe_and_rtt(self):
        p = ActiveAnalysisPipeline(
            run_vpn_probe=True, run_rtt=True, run_flux=False,
            run_graph=False, run_canary=False, timeout=1.0, verbose=False,
        )
        # candidate_ip=None → probe and RTT must not fire
        with patch.object(p.vpn_probe, "probe") as mock_probe, \
             patch.object(p.rtt_geo, "geolocate") as mock_rtt:
            result = p.run(email_headers={"From": "x@evil.com"}, candidate_ip=None)
        mock_probe.assert_not_called()
        mock_rtt.assert_not_called()
        self.assertEqual(len(result.signals), 0)

    def test_active_pipeline_private_candidate_skips_probe(self):
        p = ActiveAnalysisPipeline(
            run_vpn_probe=True, run_rtt=True, run_flux=False,
            run_graph=False, run_canary=False, timeout=1.0, verbose=False,
        )
        with patch.object(p.vpn_probe, "probe") as mock_probe, \
             patch.object(p.rtt_geo, "geolocate") as mock_rtt:
            result = p.run({"From": "x@evil.com"}, candidate_ip="192.168.1.1")
        mock_probe.assert_not_called()
        mock_rtt.assert_not_called()

    def test_haversine_same_point_zero(self):
        from huntertrace.active.active_validation import _haversine
        self.assertAlmostEqual(_haversine(0, 0, 0, 0), 0.0, places=5)

    def test_haversine_known_distance(self):
        from huntertrace.active.active_validation import _haversine
        # London → New York ≈ 5570 km
        dist = _haversine(51.5, -0.13, 40.71, -74.01)
        self.assertGreater(dist, 5000)
        self.assertLess(dist, 6200)

    def test_geo_error_same_country_zero(self):
        err = _geo_error_km("Russia", "Russia")
        self.assertAlmostEqual(err, 0.0, places=1)

    def test_geo_error_unknown_country_none(self):
        err = _geo_error_km("MadeUpCountry", "Russia")
        self.assertIsNone(err)

    def test_validation_runner_instantiates(self):
        runner = ValidationRunner(verbose=False)
        self.assertIsNotNone(runner)

    def test_validation_runner_run_technique_invalid(self):
        runner = ValidationRunner(verbose=False)
        with self.assertRaises(ValueError):
            runner.run_technique("invalid_technique")


# ══════════════════════════════════════════════════════════════════════════════
# RUNNER
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    loader = unittest.TestLoader()
    suite  = unittest.TestSuite()

    for cls in [
        TestImportGuards,
        TestDataclassContracts,
        TestCanaryCallbackAnalyzer,
        TestFastFluxAnalyzer,
        TestActiveVPNProbe,
        TestRTTGeolocator,
        TestInfrastructureGraphAnalyzer,
        TestActiveAnalysisPipelineRun,
        TestSignalMergeResynthesis,
        TestEnableActiveAnalysis,
        TestPipelineIntegration,
        TestValidationMetrics,
        TestValidationReport,
        TestMockIPGeolocation,
        TestEdgeCases,
    ]:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print(f"\n{'='*60}")
    total  = result.testsRun
    failed = len(result.failures) + len(result.errors)
    passed = total - failed
    if failed:
        print(f"  {passed}/{total} passed  ✗  {failed} FAILED")
        sys.exit(1)
    else:
        print(f"  {passed}/{total} passed  ✓ ALL GREEN")