"""
test_p0_regressions.py
======================
Regression tests for the two P0 fixes applied to engine.py.

  P0-A  Posterior collapse in attribute_from_profile
         The old implementation fed identical signals n_obs times via a for-loop,
         collapsing the softmax posterior to 1.0.  These tests assert the new
         behaviour produces calibrated posteriors with genuine uncertainty.

  P0-B  ACI always 1.0
         The old implementation derived obfuscation flags from opsec_score
         thresholds only, never from real vpnBacktrack / ipClassifier results.
         These tests assert obfuscation_override flows correctly to ACICalculator.

Changelog vs first delivery
───────────────────────────
  test_n1_lower_than_n10:
    Now asserts primary_probability (raw, pre-cap) instead of aci_adjusted_prob.
    Reason: with 3 signals, _conf_cap = 0.50 + 3×0.075 = 0.725. Both n=1 and
    n=10 produce raw posteriors above 0.725, so aci_adjusted_prob is clamped to
    the same ceiling for both. primary_probability correctly captures the
    corroboration_scale difference (n=1→~0.826, n=10→~0.917).

  test_vpn_interpretation:
    Fixed assertion from assertIn("VPN", ...) to assertIn("Minimal", ...).
    Reason: ACI=0.82 falls in the >=0.80 band → "Minimal obfuscation — signals
    are reliable". The word "VPN" only appears in the >=0.60 band ("Moderate").
    The test now checks (1) correct band label, (2) penalty fired (ACI < 1.0),
    (3) penalty_applied["vpn"] == 0.18.

  TestDemoOutputBehavior (new):
    6 tests derived from the 2026-03-16 live demo run. ACTOR_001: 28 emails,
    no timezone, no geo, webmail='Unknown / Unidentified' → Tier 0 correct.

Run:
    python test_p0_regressions.py
    pytest test_p0_regressions.py -v

No network required. No .eml files required.
"""

import sys
import os
import math
import types
import unittest
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any

# ── Stub heavy optional deps ──────────────────────────────────────────────────
for mod in ["requests", "maxminddb", "geoip2", "geoip2.database",
            "sklearn", "sklearn.preprocessing", "networkx"]:
    if mod not in sys.modules:
        sys.modules[mod] = types.ModuleType(mod)

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from huntertrace.attribution.engine import (
    AttributionEngine,
    ACI_LAYER_WEIGHTS,
    REGION_PRIORS,
)


# ─────────────────────────────────────────────────────────────────────────────
#  Shared mock stubs
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class FakeTemporal:
    timezone_offset: Optional[str] = None
    timezone_region: Optional[str] = None
    likely_country:  Optional[str] = None

@dataclass
class FakeInfrastructure:
    vpn_providers:   List[str] = field(default_factory=list)
    primary_webmail: Optional[str] = None
    origin_ips:      List[str] = field(default_factory=list)
    opsec_score:     int = 0

@dataclass
class FakeProfile:
    campaign_count: int = 1
    temporal:       FakeTemporal       = field(default_factory=FakeTemporal)
    infrastructure: FakeInfrastructure = field(default_factory=FakeInfrastructure)

@dataclass
class FakeResult:
    header_analysis:        Any = None
    classifications:        Dict = field(default_factory=dict)
    enrichment_results:     Dict = field(default_factory=dict)
    geolocation_results:    Dict = field(default_factory=dict)
    webmail_extraction:     Any = None
    vpn_backtrack_analysis: Any = None
    real_ip_analysis:       Any = None
    proxy_analysis:         Any = None
    unique_ipv6:            Optional[List[str]] = None

@dataclass
class FakeWE:
    provider_name:  Optional[str] = None
    real_ip_found:  bool = False
    real_ip:        Optional[str] = None


# ── Profile factories ─────────────────────────────────────────────────────────

def make_us_profile(n_obs: int = 1) -> FakeProfile:
    """3-signal US profile: timezone_offset + timezone_region + geolocation_country."""
    return FakeProfile(
        campaign_count = n_obs,
        temporal = FakeTemporal(
            timezone_offset = "-0500",
            timezone_region = "US Eastern / South America",
            likely_country  = "United States",
        ),
        infrastructure = FakeInfrastructure(),
    )

def make_ukraine_profile(n_obs: int = 1) -> FakeProfile:
    return FakeProfile(
        campaign_count = n_obs,
        temporal = FakeTemporal(
            timezone_offset = "+0200",
            timezone_region = "Eastern Europe / South Africa",
            likely_country  = "Ukraine",
        ),
        infrastructure = FakeInfrastructure(),
    )

def make_ambiguous_profile(n_obs: int = 1) -> FakeProfile:
    """UTC+0 only — UK/Nigeria/Ghana all plausible."""
    return FakeProfile(
        campaign_count = n_obs,
        temporal = FakeTemporal(
            timezone_offset = "+0000",
            timezone_region = "UTC / West Africa",
        ),
        infrastructure = FakeInfrastructure(),
    )

def make_no_signal_profile(n_obs: int = 1) -> FakeProfile:
    """
    No geographic signals — mirrors ACTOR_001 from the 2026-03-16 demo:
    28 emails, webmail='Unknown / Unidentified', no timezone, no geo.
    Expected behaviour: posterior stays at prior, Tier 0.
    """
    return FakeProfile(
        campaign_count = n_obs,
        temporal = FakeTemporal(),
        infrastructure = FakeInfrastructure(
            primary_webmail = "Unknown / Unidentified",
        ),
    )


# ── Obfuscation helpers ────────────────────────────────────────────────────────

def clean_obfuscation()   -> Dict[str, bool]: return {k: False for k in ACI_LAYER_WEIGHTS}
def vpn_obfuscation()     -> Dict[str, bool]: return {**clean_obfuscation(), "vpn": True}
def tor_vpn_obfuscation() -> Dict[str, bool]: return {**clean_obfuscation(), "tor": True, "vpn": True}
def full_obfuscation()    -> Dict[str, bool]: return {k: True for k in ACI_LAYER_WEIGHTS}


# ─────────────────────────────────────────────────────────────────────────────
#  P0-A: Posterior collapse regression tests
# ─────────────────────────────────────────────────────────────────────────────

class TestP0A_PosteriorCollapse(unittest.TestCase):

    def setUp(self):
        self.engine = AttributionEngine(verbose=False)

    def test_single_obs_not_collapsed(self):
        """n=1, 3 signals → primary_probability must be < 0.99."""
        r = self.engine.attribute_from_profile(make_us_profile(n_obs=1))
        self.assertLess(r.primary_probability, 0.99,
            f"n=1 collapsed to {r.primary_probability:.4f} — fix not applied")
        self.assertEqual(r.primary_region, "United States")

    def test_single_obs_posterior_spread(self):
        """At least 2 regions must have probability > 0.01."""
        r = self.engine.attribute_from_profile(make_us_profile(n_obs=1))
        above = [rp for rp in r.posterior if rp.probability > 0.01]
        self.assertGreaterEqual(len(above), 2,
            f"Only {len(above)} region(s) above 1%: "
            f"{[(rp.region, round(rp.probability,3)) for rp in r.posterior[:5]]}")

    def test_single_obs_tier_not_4(self):
        """n=1, 3 signals → Tier 2 or 3, not Tier 4."""
        r = self.engine.attribute_from_profile(make_us_profile(n_obs=1))
        self.assertIn(r.tier, (2, 3),
            f"n=1 gave Tier {r.tier} (aci_adj={r.aci_adjusted_prob:.4f})")

    def test_monotonic_raw_probability(self):
        """
        primary_probability (pre-cap) must increase monotonically with n_obs.

        NOTE: aci_adjusted_prob is NOT used here because it is clamped by the
        signal-count cap (_conf_cap = 0.50 + n_signals × 0.075). With 3 signals
        that cap is 0.725, and both small and large n_obs produce raw posteriors
        above that threshold — so aci_adjusted_prob is identical across n_obs
        values. primary_probability is not capped and correctly shows the
        corroboration_scale progression.
        """
        probs = []
        for n in [1, 3, 5, 10, 20]:
            r = self.engine.attribute_from_profile(make_us_profile(n_obs=n))
            probs.append((n, r.primary_probability))

        for i in range(len(probs) - 1):
            n1, p1 = probs[i]
            n2, p2 = probs[i + 1]
            self.assertLessEqual(p1, p2 + 1e-9,
                f"Raw prob decreased: n={n1} ({p1:.4f}) → n={n2} ({p2:.4f})")

    def test_n10_not_collapsed(self):
        """n=10 primary_probability < 0.99, aci_adjusted_prob < 0.96."""
        r = self.engine.attribute_from_profile(make_us_profile(n_obs=10))
        self.assertLess(r.primary_probability, 0.99,
            f"n=10 collapsed to {r.primary_probability:.4f}")
        self.assertLess(r.aci_adjusted_prob, 0.96,
            f"n=10 aci_adj={r.aci_adjusted_prob:.4f} is implausibly high")

    def test_n10_tier_3_or_4(self):
        """10 consistently agreeing observations → Tier 3 or 4."""
        r = self.engine.attribute_from_profile(make_us_profile(n_obs=10))
        self.assertGreaterEqual(r.tier, 3,
            f"n=10 gave Tier {r.tier} (aci_adj={r.aci_adjusted_prob:.4f})")

    def test_n1_lower_than_n10_raw(self):
        """
        n=1 raw posterior < n=10 raw posterior.

        Compares primary_probability (pre-cap), NOT aci_adjusted_prob.
        See test_monotonic_raw_probability docstring for the full explanation
        of why aci_adjusted_prob is the wrong metric here.

        Expected values:
            n=1:  scale=0.452  → raw_prob ≈ 0.83
            n=10: scale=0.564  → raw_prob ≈ 0.92
        """
        r1  = self.engine.attribute_from_profile(make_us_profile(n_obs=1))
        r10 = self.engine.attribute_from_profile(make_us_profile(n_obs=10))
        self.assertLess(r1.primary_probability, r10.primary_probability,
            f"n=1 raw ({r1.primary_probability:.4f}) should be < "
            f"n=10 ({r10.primary_probability:.4f}) — corroboration_scale not working")

    def test_n1_calibrated_range(self):
        """n=1, 3 signals: raw posterior in [0.60, 0.92]."""
        r = self.engine.attribute_from_profile(make_us_profile(n_obs=1))
        self.assertGreater(r.primary_probability, 0.60,
            f"n=1 too low: {r.primary_probability:.4f}")
        self.assertLess(r.primary_probability, 0.92,
            f"n=1 collapsed: {r.primary_probability:.4f}")

    def test_n5_calibrated_range(self):
        """n=5, 3 signals: raw posterior in [0.70, 0.97]."""
        r = self.engine.attribute_from_profile(make_us_profile(n_obs=5))
        self.assertGreater(r.primary_probability, 0.70,
            f"n=5 too low: {r.primary_probability:.4f}")
        self.assertLess(r.primary_probability, 0.97,
            f"n=5 collapsed: {r.primary_probability:.4f}")

    def test_ukraine_correct_country(self):
        """Ukraine profile → primary_region = Ukraine."""
        r = self.engine.attribute_from_profile(make_ukraine_profile(n_obs=5))
        self.assertEqual(r.primary_region, "Ukraine",
            f"Expected Ukraine, got {r.primary_region} "
            f"{[(rp.region, round(rp.probability,3)) for rp in r.posterior[:3]]}")

    def test_utc_ambiguous_stays_uncertain(self):
        """UTC+0 only → primary_probability < 0.80, top region is UK/Nigeria/Ghana."""
        r = self.engine.attribute_from_profile(make_ambiguous_profile(n_obs=5))
        self.assertLess(r.primary_probability, 0.80,
            f"UTC-only too confident: {r.primary_probability:.4f} on {r.primary_region}")
        self.assertIn(r.primary_region,
            ("United Kingdom", "Nigeria", "Ghana", "Other"),
            f"Unexpected top region from UTC-only: {r.primary_region}")

    def test_double_counting_ratio(self):
        """
        Old bug applied signals n+1 times → ratio n=4/n=1 ≈ 2.5.
        With sqrt scaling it should be ~1.05–1.30.
        """
        r1 = self.engine.attribute_from_profile(make_us_profile(n_obs=1))
        r4 = self.engine.attribute_from_profile(make_us_profile(n_obs=4))
        if r1.primary_probability > 0:
            ratio = r4.primary_probability / r1.primary_probability
            self.assertLess(ratio, 1.8,
                f"Raw prob ratio n=4/n=1 = {ratio:.3f} — expected < 1.8 from sqrt scaling")


# ─────────────────────────────────────────────────────────────────────────────
#  P0-B: ACI pipeline connection regression tests
# ─────────────────────────────────────────────────────────────────────────────

class TestP0B_ACIPipelineConnection(unittest.TestCase):

    def setUp(self):
        self.engine = AttributionEngine(verbose=False)

    def test_clean_aci_is_1(self):
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=5), obfuscation_override=clean_obfuscation())
        self.assertAlmostEqual(r.aci.final_aci, 1.0, places=3)

    def test_clean_all_layers_false(self):
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=5), obfuscation_override=clean_obfuscation())
        for layer, detected in r.aci.layers_detected.items():
            self.assertFalse(detected, f"Layer '{layer}' should be False")

    def test_vpn_aci_082(self):
        """VPN only → ACI = 1.0 − 0.18 = 0.82."""
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=5), obfuscation_override=vpn_obfuscation())
        self.assertAlmostEqual(r.aci.final_aci, 0.82, places=3)

    def test_vpn_flag_set_in_breakdown(self):
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=5), obfuscation_override=vpn_obfuscation())
        self.assertTrue(r.aci.layers_detected.get("vpn", False))

    def test_vpn_penalty_applied_018(self):
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=5), obfuscation_override=vpn_obfuscation())
        self.assertAlmostEqual(r.aci.penalty_applied.get("vpn", 0.0), 0.18, places=3)

    def test_vpn_reduces_aci_adj(self):
        clean = self.engine.attribute_from_profile(
            make_us_profile(n_obs=5), obfuscation_override=clean_obfuscation())
        vpn   = self.engine.attribute_from_profile(
            make_us_profile(n_obs=5), obfuscation_override=vpn_obfuscation())
        self.assertLess(vpn.aci_adjusted_prob, clean.aci_adjusted_prob)

    def test_vpn_lowers_tier(self):
        clean = self.engine.attribute_from_profile(
            make_us_profile(n_obs=10), obfuscation_override=clean_obfuscation())
        vpn   = self.engine.attribute_from_profile(
            make_us_profile(n_obs=10), obfuscation_override=vpn_obfuscation())
        self.assertLessEqual(vpn.tier, clean.tier)

    # ── ACI interpretation strings ────────────────────────────────────────────

    def test_clean_interpretation_minimal(self):
        """ACI=1.0 → 'Minimal obfuscation'."""
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=5), obfuscation_override=clean_obfuscation())
        self.assertIn("Minimal", r.aci.interpretation,
            f"ACI=1.0 should say 'Minimal', got: '{r.aci.interpretation}'")

    def test_vpn_interpretation_and_penalty(self):
        """
        ACI=0.82 interpretation is 'Minimal obfuscation', not 'Moderate VPN'.

        ACI thresholds in ACICalculator:
            >= 0.80 → "Minimal obfuscation — signals are reliable"
            >= 0.60 → "Moderate obfuscation (VPN) — signals partially reliable"

        VPN-only produces ACI=0.82, which is >=0.80 → "Minimal" band.
        The word "VPN" only appears in the Moderate (>=0.60) band.

        We verify three things:
          1. Correct band label ("Minimal") is returned.
          2. The penalty actually fired (aci.final_aci < 1.0).
          3. penalty_applied["vpn"] records the correct 0.18 deduction.
        """
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=5), obfuscation_override=vpn_obfuscation())
        # (1) band label
        self.assertIn("Minimal", r.aci.interpretation,
            f"ACI=0.82 should be in 'Minimal' band, got: '{r.aci.interpretation}'")
        # (2) penalty fired
        self.assertLess(r.aci.final_aci, 1.0,
            "VPN override should reduce ACI below 1.0")
        # (3) per-layer deduction
        self.assertAlmostEqual(r.aci.penalty_applied.get("vpn", 0.0), 0.18, places=3)

    def test_tor_only_aci_070_moderate(self):
        """Tor only: ACI = 1.0 − 0.30 = 0.70 → 'Moderate obfuscation'."""
        obf = {**clean_obfuscation(), "tor": True}
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=5), obfuscation_override=obf)
        self.assertAlmostEqual(r.aci.final_aci, 0.70, places=3)
        self.assertIn("Moderate", r.aci.interpretation,
            f"ACI=0.70 should be 'Moderate', got: '{r.aci.interpretation}'")

    def test_tor_vpn_052_significant(self):
        """Tor+VPN: ACI = 1.0 − 0.30 − 0.18 = 0.52 → 'Significant obfuscation'."""
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=5), obfuscation_override=tor_vpn_obfuscation())
        self.assertAlmostEqual(r.aci.final_aci, 0.52, places=3)
        self.assertIn("Significant", r.aci.interpretation,
            f"ACI=0.52 should be 'Significant', got: '{r.aci.interpretation}'")
        self.assertLessEqual(r.tier, 3)

    def test_all_layers_floor_007(self):
        """All 5 layers: sum=0.93 → raw=0.07 → floor stays at 0.07."""
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=10), obfuscation_override=full_obfuscation())
        self.assertAlmostEqual(r.aci.final_aci, 0.07, places=3)
        self.assertGreaterEqual(r.aci.final_aci, 0.05)  # floor never violated

    def test_full_obfuscation_tier_0_or_1(self):
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=10), obfuscation_override=full_obfuscation())
        self.assertLessEqual(r.tier, 1,
            f"Full obfuscation should cap at Tier 0–1, got Tier {r.tier}")

    # ── Fallback path ────────────────────────────────────────────────────────

    def test_none_override_clean_opsec_aci_1(self):
        profile = make_us_profile(n_obs=5)
        profile.infrastructure.vpn_providers = []
        profile.infrastructure.opsec_score   = 0
        r = self.engine.attribute_from_profile(profile, obfuscation_override=None)
        self.assertAlmostEqual(r.aci.final_aci, 1.0, places=3)

    def test_none_override_vpn_providers_fires(self):
        profile = make_us_profile(n_obs=5)
        profile.infrastructure.vpn_providers = ["NordVPN"]
        r = self.engine.attribute_from_profile(profile, obfuscation_override=None)
        self.assertLess(r.aci.final_aci, 1.0)

    def test_none_override_opsec_70_datacenter(self):
        profile = make_us_profile(n_obs=5)
        profile.infrastructure.opsec_score = 75
        r = self.engine.attribute_from_profile(profile, obfuscation_override=None)
        self.assertAlmostEqual(r.aci.final_aci, 0.92, places=2)


# ─────────────────────────────────────────────────────────────────────────────
#  P0 Combined
# ─────────────────────────────────────────────────────────────────────────────

class TestP0Combined(unittest.TestCase):

    def setUp(self):
        self.engine = AttributionEngine(verbose=False)

    def test_large_cluster_vpn_still_penalised(self):
        """n=20 + VPN: ACI must still be 0.82 (n_obs doesn't cancel obfuscation)."""
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=20), obfuscation_override=vpn_obfuscation())
        self.assertAlmostEqual(r.aci.final_aci, 0.82, places=2)
        self.assertLessEqual(r.tier, 3)

    def test_large_cluster_clean_reaches_tier_3_plus(self):
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=20), obfuscation_override=clean_obfuscation())
        self.assertGreaterEqual(r.tier, 3,
            f"n=20 clean should reach Tier 3+, got Tier {r.tier}")

    def test_tor_caps_regardless_of_size(self):
        r = self.engine.attribute_from_profile(
            make_us_profile(n_obs=50), obfuscation_override=tor_vpn_obfuscation())
        self.assertLessEqual(r.tier, 2,
            f"Tor+VPN caps at Tier ≤ 2, got Tier {r.tier}")

    def test_n_obs_does_not_compensate_obfuscation(self):
        large_clean = self.engine.attribute_from_profile(
            make_us_profile(n_obs=50), obfuscation_override=clean_obfuscation())
        small_vpn   = self.engine.attribute_from_profile(
            make_us_profile(n_obs=3),  obfuscation_override=vpn_obfuscation())
        self.assertGreater(large_clean.aci.final_aci, small_vpn.aci.final_aci,
            "Clean cluster must always have higher ACI than VPN cluster")


# ─────────────────────────────────────────────────────────────────────────────
#  Demo-driven regression — ACTOR_001 (2026-03-16 live run)
# ─────────────────────────────────────────────────────────────────────────────

class TestDemoOutputBehavior(unittest.TestCase):
    """
    Regression tests derived from the 2026-03-16 live demo run.

    ACTOR_001 — 28 emails, 1 actor cluster
      webmail    : 'Unknown / Unidentified'
      timezone   : None
      geo        : None (no timezone, no geo → no signals fire)
      obfuscation: all False, ACI = 1.0

    Observed output:
      primary_region      = Russia          (prior peak, no signal boost)
      primary_probability = 0.2222          (= Russia prior — no delta applied)
      aci_adjusted_prob   = 0.2222          (raw < 1-signal cap; ACI=1.0)
      tier                = 0  (Tier 0: aci_adj < 0.25)
      signals_used        = ['webmail_provider']  (fires but no country match)
      signals_missing     = all geographic signals

    This is CORRECT: without geographic signals the engine returns Tier 0
    rather than fabricating an attribution. These tests lock that behaviour.
    """

    def setUp(self):
        self.engine = AttributionEngine(verbose=False)

    def test_no_signal_profile_tier_0(self):
        """28-email cluster with no geographic signals → Tier 0."""
        r = self.engine.attribute_from_profile(make_no_signal_profile(n_obs=28))
        self.assertEqual(r.tier, 0,
            f"No-signal 28-email cluster should give Tier 0, "
            f"got Tier {r.tier} (aci_adj={r.aci_adjusted_prob:.4f}, "
            f"region={r.primary_region})")

    def test_no_signal_posterior_equals_prior(self):
        """
        Without geographic signals, posterior must equal the prior.
        Russia has the highest prior (0.2222) → should be top region.
        """
        r = self.engine.attribute_from_profile(make_no_signal_profile(n_obs=28))
        self.assertEqual(r.primary_region, "Russia",
            f"No signals → top region should be Russia (highest prior), "
            f"got {r.primary_region}")
        self.assertAlmostEqual(r.primary_probability, 0.2222, places=3,
            msg=f"No signals → probability should equal Russia prior 0.2222, "
                f"got {r.primary_probability:.4f}")

    def test_no_signal_aci_adj_equals_raw(self):
        """
        ACI=1.0, raw=0.2222 < 1-signal cap (0.575) → aci_adjusted_prob = 0.2222.
        The cap is not binding; aci_adj equals raw × ACI exactly.
        """
        r = self.engine.attribute_from_profile(make_no_signal_profile(n_obs=28))
        self.assertAlmostEqual(r.aci_adjusted_prob, r.primary_probability, places=4,
            msg=f"aci_adj should equal raw when uncapped: "
                f"raw={r.primary_probability:.4f}, adj={r.aci_adjusted_prob:.4f}")

    def test_no_signal_n_obs_does_not_change_posterior(self):
        """
        Corroboration scale amplifies signal delta-from-prior.
        If no signals fire, the delta is zero, so scale has no effect.
        n=1 and n=28 must give identical posteriors.
        """
        r1  = self.engine.attribute_from_profile(make_no_signal_profile(n_obs=1))
        r28 = self.engine.attribute_from_profile(make_no_signal_profile(n_obs=28))
        self.assertAlmostEqual(r1.primary_probability, r28.primary_probability, places=4,
            msg=f"No-signal posterior: n=1 ({r1.primary_probability:.4f}) "
                f"≠ n=28 ({r28.primary_probability:.4f})")

    def test_unknown_webmail_does_not_shift_posterior(self):
        """
        webmail_provider='Unknown / Unidentified' fires as a used signal
        but _get_matching_regions returns [] → no country boost → posterior
        identical to a result with no webmail signal at all.
        """
        r_with = self.engine.attribute(FakeResult(
            webmail_extraction=FakeWE(provider_name="Unknown / Unidentified"),
        ))
        r_none = self.engine.attribute(FakeResult())

        self.assertAlmostEqual(r_with.primary_probability,
                               r_none.primary_probability, places=4,
            msg="'Unknown / Unidentified' webmail must not shift posterior")
        self.assertEqual(r_with.primary_region, "Russia")

    def test_all_geographic_signals_in_missing(self):
        """
        Attribution with no geographic signals must report them all as missing —
        confirming the evaluation gap is surfaced, not silently ignored.
        """
        r = self.engine.attribute_from_profile(make_no_signal_profile(n_obs=5))
        for sig in ["geolocation_country", "timezone_offset",
                    "real_ip_country", "timezone_region"]:
            self.assertIn(sig, r.signals_missing,
                f"'{sig}' should be in signals_missing when no geographic data available")


# ─────────────────────────────────────────────────────────────────────────────
#  Orchestrator Step 2.5 — obfuscation aggregation (unit, no HunterTraceV3)
# ─────────────────────────────────────────────────────────────────────────────

class TestOrchestratorObfuscationAggregation(unittest.TestCase):

    def _aggregate_flags(self, pipeline_results: Dict) -> Dict[str, bool]:
        """Replicates the Step 2.5 OR-aggregation loop from orchestrator.py."""
        _LAYERS = ("tor", "vpn", "residential_proxy", "datacenter", "timestamp_spoof")
        flags = {layer: False for layer in _LAYERS}
        for _, pr in pipeline_results.items():
            pa = getattr(pr, "proxy_analysis", None)
            if pa:
                if getattr(pa, "tor_detected",   False): flags["tor"] = True
                if getattr(pa, "vpn_detected",   False): flags["vpn"] = True
                if getattr(pa, "proxy_detected", False): flags["residential_proxy"] = True
            bt = getattr(pr, "vpn_backtrack_analysis", None)
            if bt:
                if getattr(bt, "vpn_provider",      None): flags["vpn"] = True
                if getattr(bt, "tor_detected",      False): flags["tor"] = True
                if getattr(bt, "spoofing_detected", False): flags["timestamp_spoof"] = True
            cl = getattr(pr, "classifications", None) or {}
            for ip_cls in cl.values():
                if getattr(ip_cls, "is_tor",   False): flags["tor"] = True
                if getattr(ip_cls, "is_vpn",   False): flags["vpn"] = True
                if getattr(ip_cls, "is_proxy", False): flags["residential_proxy"] = True
                if "DATACENTER" in getattr(ip_cls, "classification", "").upper():
                    flags["datacenter"] = True
            ha = getattr(pr, "header_analysis", None)
            if ha and getattr(ha, "spoofing_risk", 0.0) > 0.6:
                flags["timestamp_spoof"] = True
        return flags

    def test_all_clean(self):
        @dataclass
        class R:
            proxy_analysis: None = None
            vpn_backtrack_analysis: None = None
            classifications: dict = field(default_factory=dict)
            header_analysis: None = None
        flags = self._aggregate_flags({"e1.eml": R(), "e2.eml": R()})
        for layer, val in flags.items():
            self.assertFalse(val)

    def test_vpn_from_proxy(self):
        @dataclass
        class PA:
            vpn_detected: bool = True; tor_detected: bool = False; proxy_detected: bool = False
        @dataclass
        class R:
            proxy_analysis: Any = field(default_factory=PA)
            vpn_backtrack_analysis: None = None
            classifications: dict = field(default_factory=dict)
            header_analysis: None = None
        flags = self._aggregate_flags({"e1.eml": R()})
        self.assertTrue(flags["vpn"])
        self.assertFalse(flags["tor"])

    def test_vpn_from_backtrack_provider(self):
        @dataclass
        class BT:
            vpn_provider: str = "NordVPN"; tor_detected: bool = False; spoofing_detected: bool = False
        @dataclass
        class R:
            proxy_analysis: None = None
            vpn_backtrack_analysis: Any = field(default_factory=BT)
            classifications: dict = field(default_factory=dict)
            header_analysis: None = None
        flags = self._aggregate_flags({"e1.eml": R()})
        self.assertTrue(flags["vpn"])

    def test_tor_from_backtrack(self):
        @dataclass
        class BT:
            vpn_provider: None = None; tor_detected: bool = True; spoofing_detected: bool = False
        @dataclass
        class R:
            proxy_analysis: None = None
            vpn_backtrack_analysis: Any = field(default_factory=BT)
            classifications: dict = field(default_factory=dict)
            header_analysis: None = None
        flags = self._aggregate_flags({"e1.eml": R()})
        self.assertTrue(flags["tor"])

    def test_datacenter_from_cls(self):
        @dataclass
        class CLS:
            is_tor: bool = False; is_vpn: bool = False; is_proxy: bool = False
            classification: str = "DATACENTER_HOSTING"
        @dataclass
        class R:
            proxy_analysis: None = None
            vpn_backtrack_analysis: None = None
            classifications: dict = field(default_factory=lambda: {"1.2.3.4": CLS()})
            header_analysis: None = None
        flags = self._aggregate_flags({"e1.eml": R()})
        self.assertTrue(flags["datacenter"])

    def test_timestamp_spoof_from_ha(self):
        @dataclass
        class HA:
            spoofing_risk: float = 0.85
        @dataclass
        class R:
            proxy_analysis: None = None
            vpn_backtrack_analysis: None = None
            classifications: dict = field(default_factory=dict)
            header_analysis: Any = field(default_factory=HA)
        flags = self._aggregate_flags({"e1.eml": R()})
        self.assertTrue(flags["timestamp_spoof"])

    def test_or_logic_one_in_five(self):
        """1 out of 5 cluster emails with VPN → vpn=True for the whole cluster."""
        @dataclass
        class PA_clean:
            vpn_detected: bool = False; tor_detected: bool = False; proxy_detected: bool = False
        @dataclass
        class PA_vpn:
            vpn_detected: bool = True; tor_detected: bool = False; proxy_detected: bool = False
        @dataclass
        class CleanR:
            proxy_analysis: Any = field(default_factory=PA_clean)
            vpn_backtrack_analysis: None = None
            classifications: dict = field(default_factory=dict)
            header_analysis: None = None
        @dataclass
        class VpnR:
            proxy_analysis: Any = field(default_factory=PA_vpn)
            vpn_backtrack_analysis: None = None
            classifications: dict = field(default_factory=dict)
            header_analysis: None = None
        results = {f"e{i}.eml": CleanR() for i in range(1, 5)}
        results["e5.eml"] = VpnR()
        flags = self._aggregate_flags(results)
        self.assertTrue(flags["vpn"])

    def test_missing_file_graceful(self):
        @dataclass
        class CleanR:
            proxy_analysis: None = None
            vpn_backtrack_analysis: None = None
            classifications: dict = field(default_factory=dict)
            header_analysis: None = None
        try:
            flags = self._aggregate_flags({"e1.eml": CleanR()})
        except Exception as e:
            self.fail(f"Aggregation raised: {e}")
        self.assertFalse(flags["vpn"])


# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    loader = unittest.TestLoader()
    suite  = unittest.TestSuite()
    for cls in [
        TestP0A_PosteriorCollapse,
        TestP0B_ACIPipelineConnection,
        TestP0Combined,
        TestDemoOutputBehavior,
        TestOrchestratorObfuscationAggregation,
    ]:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    print(f"\n{'='*65}")
    total  = result.testsRun
    failed = len(result.failures) + len(result.errors)
    passed = total - failed
    if failed == 0:
        print(f"  {passed}/{total} passed  ✓  ALL GREEN")
    else:
        print(f"  {passed}/{total} passed  ✗  {failed} FAILED")
        for f in result.failures:
            print(f"\n  FAIL: {f[0]}")
            print(f"  {f[1].splitlines()[-1]}")
        for e in result.errors:
            print(f"\n  ERROR: {e[0]}")
            print(f"  {e[1].splitlines()[-1]}")
    sys.exit(0 if failed == 0 else 1)