#!/usr/bin/env python3
"""
tests/test_active_analysis.py
==============================
Automated Test Suite — Active Geolocation Analysis
----------------------------------------------------

Runnable test file covering all five active techniques:
  1. CanaryCallbackAnalyzer
  2. FastFluxAnalyzer
  3. ActiveVPNProbe
  4. RTTGeolocator
  5. InfrastructureGraphAnalyzer
  6. ActiveAnalysisPipeline (integration)
  7. Adversarial scenarios (VPN, Tor, spoofed headers, multi-hop relay)
  8. Metric validation against minimum thresholds

Tests are designed to run without network access (mock mode) while
clearly flagging which tests require live network for full validation.

Run all tests:
    python tests/test_active_analysis.py
    pytest tests/test_active_analysis.py -v
    pytest tests/test_active_analysis.py -v --network  # includes live tests

Run a single class:
    pytest tests/test_active_analysis.py::TestCanaryCallbackAnalyzer -v
"""

from __future__ import annotations

import math
import sys
import os
import socket
import ipaddress
import types
import unittest
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from unittest.mock import patch, MagicMock

# ── Path setup ────────────────────────────────────────────────────────────────
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# ── Import modules under test ─────────────────────────────────────────────────
try:
    from huntertrace.active.activeAnalysis import (
        CanaryCallbackAnalyzer, CanaryCallbackResult,
        FastFluxAnalyzer, FluxAnalysisResult,
        ActiveVPNProbe, VPNProbeResult,
        RTTGeolocator, RTTGeoResult, RTTMeasurement, ProbePoint,
        InfrastructureGraphAnalyzer, InfraGraphResult,
        ActiveAnalysisPipeline, ActiveAnalysisResult,
        _geolocate_ip, _is_private_ip,
        COUNTRY_CENTROIDS, FAST_FLUX_TTL_THRESHOLD,
        RealIPSignal, BacktrackMethod,
    )
    _MODULE_AVAILABLE = True
except ImportError:
    _MODULE_AVAILABLE = False

try:
    from huntertrace.active.activeValidation import (
        ValidationRunner, ValidationReport, CaseResult,
        compute_metrics, _haversine, _geo_error_km,
        MockIPGeolocation, _MOCK_GEO,
        build_canary_cases, build_flux_cases,
        build_vpn_probe_cases, build_rtt_cases,
        build_graph_cases, build_adversarial_cases,
    )
    _VALIDATION_AVAILABLE = True
except ImportError:
    _VALIDATION_AVAILABLE = False

# Check network availability for live tests
_NETWORK_AVAILABLE = False
try:
    socket.setdefaulttimeout(2)
    socket.getaddrinfo("8.8.8.8", 80)
    _NETWORK_AVAILABLE = True
except Exception:
    pass
finally:
    socket.setdefaulttimeout(None)


def skip_if_no_module(fn):
    """Decorator: skip test if active_analysis.py not importable."""
    def wrapper(self, *a, **kw):
        if not _MODULE_AVAILABLE:
            self.skipTest("huntertrace.active.activeAnalysis.py not importable")
        return fn(self, *a, **kw)
    return wrapper


def skip_if_no_network(fn):
    """Decorator: skip test if no network access."""
    def wrapper(self, *a, **kw):
        if not _NETWORK_AVAILABLE:
            self.skipTest("No network access — skip live test")
        return fn(self, *a, **kw)
    return wrapper


# ─────────────────────────────────────────────────────────────────────────────
#  Shared mock helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_mock_geo(ip_country_map: Dict[str, str]):
    """
    Return a mock for _geolocate_ip_full that uses a fixed IP→country table.
    Works with both huntertrace.active.activeAnalysis.py and huntertrace.active.activeValidation.py.
    """
    def _mock_geo(ip: str, timeout: float = 5.0) -> Dict:
        for prefix, country in sorted(ip_country_map.items(),
                                      key=len, reverse=True):
            if ip.startswith(prefix):
                return {"status": "success", "country": country, "org": "",
                        "as": "", "lat": 0.0, "lon": 0.0, "isp": ""}
        return {}
    return _mock_geo


def _make_dns_mock(domain_ips: Dict[str, List[str]]):
    """Return a mock socket.getaddrinfo that serves fixed A records."""
    def _mock_gai(host, *a, **kw):
        ips = domain_ips.get(host, [])
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "",
                 (ip, 0)) for ip in ips]
    return _mock_gai


# ─────────────────────────────────────────────────────────────────────────────
#  1. CanaryCallbackAnalyzer tests
# ─────────────────────────────────────────────────────────────────────────────

class TestCanaryCallbackAnalyzer(unittest.TestCase):
    """
    Unit tests for Technique 1 — Canarytoken Callback.
    Uses register_trigger() to simulate a callback without a live server.
    """

    def setUp(self):
        if not _MODULE_AVAILABLE:
            self.skipTest("huntertrace.active.activeAnalysis.py not available")
        self.analyzer = CanaryCallbackAnalyzer(
            callback_host="", verbose=False)

    def test_register_trigger_returns_result(self):
        """register_trigger must return a CanaryCallbackResult."""
        result = self.analyzer.register_trigger(
            "test-token-001", "103.21.244.1", "Mozilla/5.0")
        self.assertIsInstance(result, CanaryCallbackResult)
        self.assertTrue(result.triggered)
        self.assertEqual(result.real_ip, "103.21.244.1")
        self.assertIsNotNone(result.trigger_time)

    def test_trigger_produces_signal(self):
        """Triggered result must produce a non-None RealIPSignal."""
        result = self.analyzer.register_trigger(
            "test-token-002", "103.21.244.1")
        self.assertIsNotNone(result.signal)
        self.assertIsInstance(result.signal, RealIPSignal)
        self.assertEqual(result.signal.confidence, 0.97)

    def test_signal_confidence_is_maximum(self):
        """Canarytoken direct callback should have confidence=0.97."""
        result = self.analyzer.register_trigger(
            "test-token-003", "5.8.18.1")
        self.assertAlmostEqual(result.signal.confidence, 0.97, places=2)

    def test_no_trigger_no_signal(self):
        """check() with no callback host returns not-triggered result."""
        result = self.analyzer.check("nonexistent-token")
        self.assertFalse(result.triggered)
        self.assertIsNone(result.signal)
        self.assertIsNone(result.real_ip)

    def test_private_ip_handled(self):
        """
        Private IP in callback is unusual (NAT edge case).
        Should still register but geo will be None.
        """
        result = self.analyzer.register_trigger(
            "test-token-004", "192.168.1.100")
        self.assertTrue(result.triggered)
        self.assertEqual(result.real_ip, "192.168.1.100")
        # Country may be None — that's OK for private IPs

    def test_evidence_includes_citation(self):
        """Signal evidence must include Jain 2025 citation."""
        result = self.analyzer.register_trigger(
            "test-token-005", "103.21.244.1")
        evidence_text = " ".join(result.signal.evidence)
        self.assertIn("Jain", evidence_text)
        self.assertIn("2025", evidence_text)

    def test_ua_captured_in_evidence(self):
        """User-agent should appear in evidence when provided."""
        result = self.analyzer.register_trigger(
            "test-token-006", "5.8.18.1", "Excel/15.0 (Windows NT 10.0)")
        evidence_text = " ".join(result.signal.evidence)
        self.assertIn("Excel", evidence_text)

    def test_high_confidence_over_vpn_ip(self):
        """
        Canarytoken captures the fetch IP directly — a different connection
        from the email delivery path. Even if attacker used VPN for email,
        the document fetch may use their real IP.
        Confidence should remain 0.97 regardless of whether the IP looks like VPN.
        """
        # 193.138.218.1 is a NordVPN datacenter IP — canary should still be 0.97
        result = self.analyzer.register_trigger(
            "test-token-007", "193.138.218.1")
        self.assertAlmostEqual(result.signal.confidence, 0.97, places=2)


# ─────────────────────────────────────────────────────────────────────────────
#  2. FastFluxAnalyzer tests
# ─────────────────────────────────────────────────────────────────────────────

class TestFastFluxAnalyzer(unittest.TestCase):
    """
    Unit tests for Technique 2 — Fast-Flux DNS Analysis.
    Uses socket mock for DNS resolution to avoid network dependency.
    """

    def setUp(self):
        if not _MODULE_AVAILABLE:
            self.skipTest("huntertrace.active.activeAnalysis.py not available")

    def _make_analyzer(self, sample_count=2):
        return FastFluxAnalyzer(
            sample_count=sample_count,
            sample_interval=0.0,
            timeout=2.0,
            verbose=False,
        )

    def test_flux_score_formula_static(self):
        """Static domain (TTL=3600, 1 IP) → flux_score ≈ 0.045."""
        fa = self._make_analyzer()
        score = fa._compute_flux_score(["1.2.3.4"], 3600.0)
        self.assertLess(score, 0.1, "Single-IP static domain should have low flux score")

    def test_flux_score_formula_fastflux(self):
        """Fast-flux domain (TTL=60, 10+ IPs) → flux_score > 0.7."""
        fa = self._make_analyzer()
        ips = [f"10.0.0.{i}" for i in range(12)]
        score = fa._compute_flux_score(ips, 60.0)
        self.assertGreater(score, 0.7,
            "Fast-flux indicator: low TTL + many IPs → score > 0.7")

    def test_flux_score_bounded(self):
        """flux_score must always be in [0.0, 1.0]."""
        fa = self._make_analyzer()
        for n_ips in [0, 1, 5, 10, 50]:
            for ttl in [10, 60, 300, 3600]:
                ips = [f"1.2.3.{i}" for i in range(n_ips)]
                s = fa._compute_flux_score(ips, ttl)
                self.assertGreaterEqual(s, 0.0)
                self.assertLessEqual(s, 1.0)

    def test_analyze_no_dns_returns_empty(self):
        """
        If DNS resolution fails completely, analyze() should return
        an empty result with flux_score=0 rather than raising.
        """
        fa = self._make_analyzer()
        with patch("socket.getaddrinfo", side_effect=socket.gaierror("nxdomain")):
            result = fa.analyze("definitely.nonexistent.invalid.")
        self.assertEqual(result.distinct_ips, [])
        self.assertEqual(result.flux_score, 0.0)
        self.assertFalse(result.is_fast_flux)
        self.assertIsNone(result.signal)

    def test_single_ip_static_domain(self):
        """Single stable IP should produce is_fast_flux=False."""
        fa = self._make_analyzer()
        with patch("socket.getaddrinfo",
                   _make_dns_mock({"example.static.": ["1.2.3.4"]})):
            with patch("huntertrace.active.activeAnalysis._geolocate_ip_full",
                       _make_mock_geo({"1.": "United States"})):
                result = fa.analyze("example.static.")
        self.assertFalse(result.is_fast_flux)
        self.assertEqual(result.dominant_country, "United States")

    def test_fast_flux_detection_low_ttl(self):
        """
        Injecting multiple IPs with low simulated TTL should trigger flux detection.
        We test the flux_score logic directly since TTL comes from dnspython
        which may not be available.
        """
        fa = self._make_analyzer()
        ips = [f"10.{i}.0.1" for i in range(8)]
        score = fa._compute_flux_score(ips, 60)   # 60s TTL < threshold
        self.assertGreater(score, 0.55)
        self.assertTrue(score > 0.55)

    def test_holz_metric_citation_in_evidence(self):
        """Evidence must cite Holz et al."""
        fa = self._make_analyzer()
        with patch("socket.getaddrinfo",
                   _make_dns_mock({"yandex.ru": ["213.180.193.1"]})):
            with patch("huntertrace.active.activeAnalysis._geolocate_ip_full",
                       _make_mock_geo({"213.": "Russia"})):
                result = fa.analyze("yandex.ru")
        evidence_text = " ".join(result.evidence)
        self.assertIn("Holz", evidence_text)

    @skip_if_no_network
    def test_live_yandex_ru(self):
        """LIVE: yandex.ru should resolve to Russian infrastructure."""
        fa = self._make_analyzer()
        result = fa.analyze("yandex.ru")
        self.assertIsNotNone(result.dominant_country)
        self.assertIn(result.dominant_country, ["Russia", "Netherlands", "Germany"])


# ─────────────────────────────────────────────────────────────────────────────
#  3. ActiveVPNProbe tests
# ─────────────────────────────────────────────────────────────────────────────

class TestActiveVPNProbe(unittest.TestCase):
    """
    Unit tests for Technique 3 — Active VPN Endpoint Fingerprinting.
    """

    def setUp(self):
        if not _MODULE_AVAILABLE:
            self.skipTest("huntertrace.active.activeAnalysis.py not available")
        self.probe = ActiveVPNProbe(port_timeout=0.5, verbose=False)

    def test_private_ip_returns_empty(self):
        """Private IPs should return a result with confidence=0.0."""
        result = self.probe.probe("192.168.1.1")
        self.assertEqual(result.confidence, 0.0)
        self.assertFalse(result.is_vpn_provider)
        self.assertFalse(result.is_datacenter)

    def test_private_ip_no_signal(self):
        """Private IPs should not produce a RealIPSignal."""
        result = self.probe.probe("10.0.0.1")
        self.assertIsNone(result.signal)

    def test_loopback_returns_empty(self):
        result = self.probe.probe("127.0.0.1")
        self.assertEqual(result.confidence, 0.0)

    def test_datacenter_org_sets_flag(self):
        """If org contains 'digitalocean', is_datacenter should be True."""
        probe = ActiveVPNProbe(port_timeout=0.1, verbose=False)
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={
            "status": "success", "country": "United States",
            "org": "AS14061 DigitalOcean LLC", "as": "AS14061",
            "lat": 37.09, "lon": -95.71, "isp": "DigitalOcean",
        }):
            with patch.object(probe, "_tcp_probe", return_value=False):
                result = probe.probe("1.2.3.4")
        self.assertTrue(result.is_datacenter)

    def test_vpn_provider_org_sets_flag(self):
        """If org contains 'nordvpn', is_vpn_provider should be True."""
        probe = ActiveVPNProbe(port_timeout=0.1, verbose=False)
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={
            "status": "success", "country": "Netherlands",
            "org": "AS9009 NordVPN", "as": "AS9009",
            "lat": 52.0, "lon": 5.0, "isp": "NordVPN",
        }):
            with patch.object(probe, "_tcp_probe", return_value=False):
                result = probe.probe("193.138.218.1")
        self.assertTrue(result.is_vpn_provider)

    def test_vpn_port_open_raises_confidence(self):
        """Open VPN port (1194) should raise confidence above 0.5."""
        probe = ActiveVPNProbe(port_timeout=0.1, verbose=False)
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={
            "status": "success", "country": "Germany",
            "org": "AS1234 Some Provider", "as": "AS1234",
            "lat": 51.0, "lon": 10.0, "isp": "ISP",
        }):
            port_results = {p: (p == 1194) for p in [1194, 1723, 4500, 500, 51820, 443]}
            with patch.object(probe, "_tcp_probe",
                               side_effect=lambda ip, port: port_results.get(port, False)):
                result = probe.probe("1.2.3.4")
        self.assertGreater(result.confidence, 0.5)
        self.assertIn(1194, result.open_vpn_ports)

    def test_vpn_signal_confidence_inverted(self):
        """
        The signal confidence represents how likely the IP is the attacker's
        REAL location. High VPN probe confidence → low signal confidence.
        """
        probe = ActiveVPNProbe(port_timeout=0.1, verbose=False)
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={
            "status": "success", "country": "Netherlands",
            "org": "AS9009 NordVPN", "as": "AS9009",
            "lat": 52.0, "lon": 5.0, "isp": "NordVPN",
        }):
            port_results = {p: True for p in [1194, 1723]}
            with patch.object(probe, "_tcp_probe",
                               side_effect=lambda ip, port: port_results.get(port, False)):
                result = probe.probe("193.138.218.1")

        self.assertIsNotNone(result.signal)
        # signal.confidence = 1.0 - vpn_probe_confidence
        # High VPN confidence → signal confidence should be LOW
        self.assertLess(result.signal.confidence, 0.5)

    def test_evidence_includes_citation(self):
        """Evidence must reference Goel et al. VPN detection paper."""
        probe = ActiveVPNProbe(port_timeout=0.1, verbose=False)
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={
            "status": "success", "country": "Germany",
            "org": "AS1234 ISP", "as": "AS1234",
            "lat": 51.0, "lon": 10.0, "isp": "ISP",
        }):
            with patch.object(probe, "_tcp_probe", return_value=False):
                result = probe.probe("1.2.3.4")
        evidence_text = " ".join(result.evidence)
        self.assertIn("Goel", evidence_text)


# ─────────────────────────────────────────────────────────────────────────────
#  4. RTTGeolocator tests
# ─────────────────────────────────────────────────────────────────────────────

class TestRTTGeolocator(unittest.TestCase):
    """
    Unit tests for Technique 4 — RTT-based geolocation.
    """

    def setUp(self):
        if not _MODULE_AVAILABLE:
            self.skipTest("huntertrace.active.activeAnalysis.py not available")
        self.geo = RTTGeolocator(probe_timeout=0.5, verbose=False)

    def test_private_ip_returns_empty(self):
        result = self.geo.geolocate("192.168.1.1")
        self.assertEqual(result.confidence, 0.0)
        self.assertIsNone(result.estimated_country)
        self.assertIsNone(result.signal)

    def test_haversine_math(self):
        """Haversine: London to Paris ≈ 340 km."""
        from huntertrace.active.activeAnalysis import RTTGeolocator as _RTT
        dist = _RTT._haversine(51.5, -0.1, 48.9, 2.3)
        self.assertAlmostEqual(dist, 340, delta=30)

    def test_haversine_same_point(self):
        from huntertrace.active.activeAnalysis import RTTGeolocator as _RTT
        dist = _RTT._haversine(51.5, -0.1, 51.5, -0.1)
        self.assertAlmostEqual(dist, 0.0, places=5)

    def test_triangulation_single_probe(self):
        """Single probe → confidence = 0.25."""
        vp = ProbePoint("test", "8.8.8.8", 37.09, -95.71, "United States")
        m  = RTTMeasurement(vp, "1.2.3.4", 50.0, 5000.0)
        lat, lon, radius = self.geo._triangulate([m])
        # Should return probe's own location as centroid
        self.assertAlmostEqual(lat, 37.09, places=1)

    def test_triangulation_two_probes_narrows(self):
        """
        Two probes from opposite sides should produce a centroid between them.
        """
        vp1 = ProbePoint("west", "1.1.1.1",  37.09,  -95.71, "US")
        vp2 = ProbePoint("east", "8.8.8.8",  51.51,   -0.13, "UK")
        m1  = RTTMeasurement(vp1, "5.8.18.1", 120.0, 12000.0)
        m2  = RTTMeasurement(vp2, "5.8.18.1",  60.0,  6000.0)
        lat, lon, radius = self.geo._triangulate([m1, m2])
        # Centroid should be between the two probes (roughly Atlantic)
        self.assertGreater(lat, 30.0)
        self.assertLess(lat, 60.0)

    def test_closest_country_russia(self):
        """Centroid near Moscow → Russia."""
        country = self.geo._closest_country(55.75, 37.62)
        self.assertEqual(country, "Russia")

    def test_closest_country_india(self):
        """Centroid near Delhi → India."""
        country = self.geo._closest_country(28.6, 77.2)
        self.assertEqual(country, "India")

    def test_closest_country_brazil(self):
        """Centroid near São Paulo → Brazil."""
        country = self.geo._closest_country(-23.5, -46.6)
        self.assertEqual(country, "Brazil")

    def test_failed_probes_produce_empty_result(self):
        """If all RTT probes fail, result should have confidence=0."""
        geo = RTTGeolocator(probe_timeout=0.01, verbose=False)
        with patch.object(geo, "_measure_rtt", return_value=None):
            result = geo.geolocate("1.2.3.4")
        self.assertEqual(result.confidence, 0.0)
        self.assertIsNone(result.signal)

    def test_single_probe_low_confidence(self):
        """One successful probe → confidence = 0.25."""
        geo = RTTGeolocator(probe_timeout=0.5, verbose=False)
        rtt_call_count = [0]

        def mock_rtt(ip, vp):
            rtt_call_count[0] += 1
            # Only first probe succeeds
            if rtt_call_count[0] == 1:
                return 80.0
            return None

        with patch.object(geo, "_measure_rtt", side_effect=mock_rtt):
            result = geo.geolocate("1.2.3.4")
        self.assertEqual(result.confidence, 0.25)

    def test_three_probes_higher_confidence(self):
        """Three successful probes with small radius → confidence >= 0.45."""
        geo = RTTGeolocator(probe_timeout=0.5, verbose=False)
        # Mock: all probes return ~20ms RTT (very close)
        with patch.object(geo, "_measure_rtt", return_value=20.0):
            result = geo.geolocate("8.8.8.8")
        self.assertGreaterEqual(result.confidence, 0.45)
        self.assertIsNotNone(result.signal)

    def test_citation_in_evidence(self):
        """RTT result evidence must cite Prasad et al."""
        geo = RTTGeolocator(probe_timeout=0.5, verbose=False)
        with patch.object(geo, "_measure_rtt", return_value=50.0):
            result = geo.geolocate("8.8.8.8")
        evidence_text = " ".join(result.evidence)
        self.assertIn("Prasad", evidence_text)

    @skip_if_no_network
    def test_live_google_dns(self):
        """LIVE: 8.8.8.8 should produce US attribution within 5000 km."""
        geo = RTTGeolocator(probe_timeout=2.0, verbose=False)
        result = geo.geolocate("8.8.8.8")
        self.assertIsNotNone(result.estimated_country)
        if result.estimated_country in ("United States", "United Kingdom",
                                        "Germany", "Netherlands"):
            pass  # anycast — all acceptable
        self.assertGreater(result.confidence, 0.0)


# ─────────────────────────────────────────────────────────────────────────────
#  5. InfrastructureGraphAnalyzer tests
# ─────────────────────────────────────────────────────────────────────────────

class TestInfrastructureGraphAnalyzer(unittest.TestCase):
    """
    Unit tests for Technique 5 — Infrastructure Graph Analysis.
    """

    def setUp(self):
        if not _MODULE_AVAILABLE:
            self.skipTest("huntertrace.active.activeAnalysis.py not available")
        self.analyzer = InfrastructureGraphAnalyzer(timeout=2.0, verbose=False)

    def _yandex_headers(self):
        return {
            "From": "user@yandex.ru",
            "DKIM-Signature": "v=1; a=rsa-sha256; d=yandex.ru; s=mail",
            "Received": ["from mail.yandex.ru [213.180.193.1] by mx.victim.com"],
        }

    def _gmail_headers(self):
        return {
            "From": "attacker@gmail.com",
            "Received": ["from smtp.gmail.com [209.85.220.1] by mx.victim.com"],
        }

    def test_domain_extraction_from_dkim(self):
        """Domain should be extracted from DKIM d= tag first."""
        domain = self.analyzer._extract_domain({
            "DKIM-Signature": "v=1; a=rsa-sha256; d=yandex.ru; s=mail; b=abc",
            "From": "user@gmail.com",  # should be ignored
        })
        self.assertEqual(domain, "yandex.ru")

    def test_domain_extraction_from_from_fallback(self):
        """Fall back to From header when no DKIM."""
        domain = self.analyzer._extract_domain({
            "From": "attacker@evil.ru",
        })
        self.assertEqual(domain, "evil.ru")

    def test_no_headers_returns_empty(self):
        """Empty headers should return empty result without crashing."""
        result = self.analyzer.analyze({})
        self.assertIsNone(result.signal)
        self.assertEqual(result.dominant_country, None)

    def test_received_ip_geo_contributes(self):
        """IPs in Received headers should vote toward country."""
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full",
                   _make_mock_geo({"213.180.193": "Russia"})):
            result = self.analyzer.analyze(self._yandex_headers())
        # Russia should appear in country_votes even if DNS fails
        if result.dominant_country:
            self.assertIn(result.dominant_country,
                          ["Russia", "United States", "Unknown"])

    def test_confidence_tiers(self):
        """
        Verify that confidence is assigned correctly by vote count.
        We inject votes directly to test the tier logic.
        """
        from collections import Counter
        # N >= 3 agreeing: 0.80
        votes = Counter({"Russia": 3.0})
        dominant = "Russia"
        # Replicate the confidence logic from analyze()
        if votes[dominant] >= 3.0:
            conf = 0.80
        elif votes[dominant] >= 2.0:
            conf = 0.65
        else:
            conf = 0.40
        self.assertEqual(conf, 0.80)

    def test_no_signal_when_no_votes(self):
        """If no nodes can be geolocated, no signal should be produced."""
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={}):
            with patch("socket.getaddrinfo", side_effect=socket.gaierror):
                result = self.analyzer.analyze(self._gmail_headers())
        # Signal may still fire from Received IP; if no country, no signal
        if result.dominant_country is None:
            self.assertIsNone(result.signal)

    def test_spf_ip_weighted_double(self):
        """
        SPF ip4: entries receive weight 2.0 (higher than NS/MX at 1.0).
        This is important for Received-only scenarios.
        """
        try:
            import dns.resolver
        except ImportError:
            self.skipTest("dnspython not available — skip SPF test")

        headers = {
            "From": "user@test-spf.example",
            "DKIM-Signature": "v=1; a=rsa-sha256; d=test-spf.example; s=main",
        }

        mock_spf_txt = "v=spf1 ip4:5.8.18.10 ~all"

        class MockDNSAnswer:
            strings = [mock_spf_txt.encode()]

        class MockDNSResolver:
            @staticmethod
            def resolve(domain, rtype, lifetime=3):
                if rtype == "TXT":
                    return [MockDNSAnswer()]
                raise Exception(f"no {rtype}")

        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full",
                   _make_mock_geo({"5.8.18": "Russia"})):
            with patch("dns.resolver.resolve",
                       MockDNSResolver.resolve):
                result = self.analyzer.analyze(headers)

        if result.country_votes:
            # Russia should have vote >= 2.0 from the SPF ip4: weight
            self.assertGreaterEqual(result.country_votes.get("Russia", 0), 2.0)

    def test_citation_in_evidence(self):
        """Evidence must cite Prasad et al. 2025."""
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full",
                   _make_mock_geo({"213.": "Russia"})):
            result = self.analyzer.analyze(self._yandex_headers())
        if result.evidence:
            evidence_text = " ".join(result.evidence)
            self.assertIn("Prasad", evidence_text)


# ─────────────────────────────────────────────────────────────────────────────
#  6. ActiveAnalysisPipeline integration tests
# ─────────────────────────────────────────────────────────────────────────────

class TestActiveAnalysisPipeline(unittest.TestCase):
    """
    Integration tests for the full pipeline.
    All five techniques run with mocked network calls.
    """

    def setUp(self):
        if not _MODULE_AVAILABLE:
            self.skipTest("huntertrace.active.activeAnalysis.py not available")

    def _make_pipeline(self, **kwargs):
        defaults = dict(
            run_vpn_probe=True, run_rtt=True,
            run_flux=True,      run_graph=True,
            run_canary=True,    timeout=2.0,
            verbose=False,
        )
        defaults.update(kwargs)
        return ActiveAnalysisPipeline(**defaults)

    def test_pipeline_returns_active_analysis_result(self):
        pipeline = self._make_pipeline()
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={}):
            with patch("socket.getaddrinfo", side_effect=socket.gaierror):
                result = pipeline.run(
                    email_headers={"From": "user@example.com"},
                    candidate_ip="1.2.3.4",
                )
        self.assertIsInstance(result, ActiveAnalysisResult)
        self.assertIsInstance(result.signals, list)

    def test_pipeline_no_candidate_ip_skips_probes(self):
        """No candidate_ip → vpn_probe and rtt should not fire."""
        pipeline = self._make_pipeline()
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={}):
            with patch("socket.getaddrinfo", side_effect=socket.gaierror):
                result = pipeline.run(
                    email_headers={"From": "user@example.com"},
                    candidate_ip=None,
                )
        self.assertIsNone(result.vpn_probe_result)
        self.assertIsNone(result.rtt_result)

    def test_pipeline_private_ip_skips_probes(self):
        """Private candidate_ip → probes should be skipped."""
        pipeline = self._make_pipeline()
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={}):
            with patch("socket.getaddrinfo", side_effect=socket.gaierror):
                result = pipeline.run(
                    email_headers={"From": "user@example.com"},
                    candidate_ip="192.168.1.1",
                )
        if result.vpn_probe_result:
            self.assertEqual(result.vpn_probe_result.confidence, 0.0)

    def test_pipeline_canary_token_integrates(self):
        """Canary trigger should inject a high-confidence signal."""
        pipeline = self._make_pipeline()
        # Inject a pre-registered canary trigger
        pipeline.canary_analyzer.register_trigger(
            "test-pipe-001", "103.21.244.1")
        # Simulate the token being present in headers
        # The pipeline checks for X-HunterTrace-Canary in headers
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={}):
            with patch.object(
                pipeline.canary_analyzer, "check",
                return_value=pipeline.canary_analyzer.register_trigger(
                    "test-pipe-001", "103.21.244.1")
            ):
                result = pipeline.run(
                    email_headers={
                        "From": "user@example.com",
                        "X-HunterTrace-Canary": "test-pipe-001",
                    },
                    candidate_ip="1.2.3.4",
                )
        # Should have at least the canary signal
        canary_signals = [
            s for s in result.signals
            if hasattr(s, "confidence") and s.confidence == 0.97
        ]
        self.assertGreater(len(canary_signals), 0)

    def test_pipeline_disabled_techniques_skip(self):
        """Disabled techniques should produce None results."""
        pipeline = self._make_pipeline(
            run_vpn_probe=False, run_rtt=False, run_flux=False)
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={}):
            result = pipeline.run(
                email_headers={"From": "user@test.com"},
                candidate_ip="8.8.8.8",
            )
        self.assertIsNone(result.flux_result)
        self.assertIsNone(result.vpn_probe_result)
        self.assertIsNone(result.rtt_result)

    def test_overall_confidence_bounded(self):
        """overall_confidence must always be in [0.0, 1.0]."""
        pipeline = self._make_pipeline()
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full",
                   _make_mock_geo({"5.": "Russia"})):
            with patch("socket.getaddrinfo",
                       _make_dns_mock({"yandex.ru": ["5.8.18.1"]})):
                with patch.object(
                    pipeline.rtt_geo, "_measure_rtt", return_value=50.0):
                    result = pipeline.run(
                        email_headers={"From": "user@yandex.ru"},
                        candidate_ip="5.8.18.1",
                    )
        self.assertGreaterEqual(result.overall_confidence, 0.0)
        self.assertLessEqual(result.overall_confidence, 1.0)


# ─────────────────────────────────────────────────────────────────────────────
#  7. Adversarial scenario tests
# ─────────────────────────────────────────────────────────────────────────────

class TestAdversarialScenarios(unittest.TestCase):
    """
    Tests verifying how the active techniques behave under adversarial
    evasion conditions: VPN, Tor, spoofed headers, multi-hop relay.

    These tests assert specific behavioral invariants:
      - VPN probe confidence must be high for known VPN exits
      - Tor org detection must fire for Tor exit IP org fields
      - Spoofed Date header must be discounted by the graph (which doesn't
        rely on Date: header at all)
      - Multi-hop relay must not prevent graph-based geo from working
        (graph uses domain infrastructure, not Received chain)
      - Fast-flux score must not confuse static domains with flux domains
    """

    def setUp(self):
        if not _MODULE_AVAILABLE:
            self.skipTest("huntertrace.active.activeAnalysis.py not available")

    # ── VPN evasion ──────────────────────────────────────────────────────────

    def test_vpn_exit_detected_as_vpn(self):
        """
        A known VPN exit IP (org='NordVPN') should be detected by the probe
        with confidence > 0.5, indicating the IP is NOT the attacker's
        real location.
        """
        probe = ActiveVPNProbe(port_timeout=0.1, verbose=False)
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={
            "status": "success", "country": "Netherlands",
            "org": "AS9009 NordVPN S.A.", "as": "AS9009",
            "lat": 52.0, "lon": 5.0, "isp": "NordVPN",
        }):
            with patch.object(probe, "_tcp_probe", return_value=True):
                result = probe.probe("193.138.218.1")
        self.assertTrue(result.is_vpn_provider or result.open_vpn_ports)
        self.assertGreater(result.confidence, 0.5)

    def test_vpn_exit_signal_has_low_location_confidence(self):
        """
        When the probe confirms a VPN endpoint, the RealIPSignal confidence
        for that IP as the real location must be < 0.5.
        """
        probe = ActiveVPNProbe(port_timeout=0.1, verbose=False)
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={
            "status": "success", "country": "Netherlands",
            "org": "AS9009 NordVPN", "as": "AS9009",
            "lat": 52.0, "lon": 5.0, "isp": "NordVPN",
        }):
            with patch.object(probe, "_tcp_probe", return_value=True):
                result = probe.probe("193.138.218.1")
        if result.signal:
            self.assertLess(result.signal.confidence, 0.5,
                "VPN exit: signal confidence for this IP as real loc must be < 0.5")

    def test_residential_ip_has_low_vpn_confidence(self):
        """
        A residential IP (no datacenter org, no VPN ports open) should
        produce a low VPN confidence, suggesting it may be the real IP.
        """
        probe = ActiveVPNProbe(port_timeout=0.1, verbose=False)
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={
            "status": "success", "country": "India",
            "org": "AS55836 BSNL", "as": "AS55836",
            "lat": 20.0, "lon": 78.0, "isp": "BSNL",
        }):
            with patch.object(probe, "_tcp_probe", return_value=False):
                result = probe.probe("103.21.244.1")
        self.assertLess(result.confidence, 0.3,
            "Residential IP should have low VPN confidence")

    # ── Tor evasion ──────────────────────────────────────────────────────────

    def test_tor_org_detected(self):
        """
        IP with org containing 'tor project' should be flagged as Tor exit.
        """
        probe = ActiveVPNProbe(port_timeout=0.1, verbose=False)
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={
            "status": "success", "country": "Germany",
            "org": "AS4766 Tor Project Inc", "as": "AS4766",
            "lat": 51.0, "lon": 10.0, "isp": "Tor Project",
        }):
            with patch.object(probe, "_tcp_probe", return_value=False):
                result = probe.probe("185.220.101.1")
        self.assertTrue(result.is_tor)
        self.assertGreater(result.confidence, 0.8)

    def test_tor_org_confidence_is_0_90(self):
        """Tor org detection → confidence = 0.90."""
        probe = ActiveVPNProbe(port_timeout=0.1, verbose=False)
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full", return_value={
            "status": "success", "country": "Germany",
            "org": "AS4766 TorServers.net", "as": "AS4766",
            "lat": 51.0, "lon": 10.0, "isp": "TorServers",
        }):
            with patch.object(probe, "_tcp_probe", return_value=False):
                result = probe.probe("185.220.101.1")
        self.assertAlmostEqual(result.confidence, 0.90, places=2)

    # ── Spoofed Date header ──────────────────────────────────────────────────

    def test_graph_independent_of_date_header(self):
        """
        The infrastructure graph does NOT use the Date: header.
        Spoofing the timezone in Date: must not affect graph output.
        """
        analyzer = InfrastructureGraphAnalyzer(timeout=2.0, verbose=False)
        headers_spoofed_tz = {
            "From": "user@yandex.ru",
            "DKIM-Signature": "v=1; a=rsa-sha256; d=yandex.ru; s=mail",
            "Date": "Mon, 5 Aug 2024 12:00:00 +05:30",  # Indian tz — spoofed
            "Received": ["from mail.yandex.ru [213.180.193.1] by mx.victim.com"],
        }
        headers_real_tz = dict(headers_spoofed_tz)
        headers_real_tz["Date"] = "Mon, 5 Aug 2024 12:00:00 +0300"  # Moscow tz

        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full",
                   _make_mock_geo({"213.180.193": "Russia"})):
            res_spoofed = analyzer.analyze(headers_spoofed_tz)
            res_real    = analyzer.analyze(headers_real_tz)

        # Both should produce the same dominant country (the Date: header
        # is irrelevant to infrastructure graph analysis)
        self.assertEqual(res_spoofed.dominant_country,
                         res_real.dominant_country)

    # ── Multi-hop relay ──────────────────────────────────────────────────────

    def test_graph_survives_relay_chain(self):
        """
        Even with 5 relay hops in the Received chain, the domain-based
        infrastructure graph should still identify the correct country
        from the DKIM domain and NS/SPF records.
        """
        analyzer = InfrastructureGraphAnalyzer(timeout=2.0, verbose=False)
        headers = {
            "From": "user@mail.ru",
            "DKIM-Signature": "v=1; a=rsa-sha256; d=mail.ru; s=mailru",
            "Received": [
                "from relay5.us.example.com [34.1.1.1]",
                "from relay4.de.example.com [52.1.1.1]",
                "from relay3.nl.example.com [95.1.1.1]",
                "from relay2.se.example.com [62.1.1.1]",
                "from mxs.mail.ru [94.100.180.1]",
            ],
        }
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full",
                   _make_mock_geo({
                       "34.": "United States",
                       "52.": "Germany",
                       "95.": "Netherlands",
                       "62.": "Sweden",
                       "94.100.180": "Russia",
                   })):
            result = analyzer.analyze(headers)

        # Russia should appear in votes from the mail.ru Received IP
        # (even if it doesn't dominate, it should be present)
        if result.country_votes:
            self.assertGreater(len(result.country_votes), 0)

    def test_flux_score_static_domain_low(self):
        """
        An attacker routing through relay chains doesn't make the sender's
        domain fast-flux. Static sending domains should have low flux score.
        """
        fa = FastFluxAnalyzer(sample_count=1, sample_interval=0.0, timeout=1.0)
        # Single IP, high TTL = static
        score = fa._compute_flux_score(["5.8.18.1"], 3600.0)
        self.assertLess(score, 0.1)
        self.assertFalse(score > 0.55)

    # ── Proxy evasion ─────────────────────────────────────────────────────────

    def test_same_country_proxy_still_identifiable(self):
        """
        Residential proxy in same country as attacker — the graph still
        identifies the correct country because it uses domain infrastructure,
        not the routing path.
        """
        analyzer = InfrastructureGraphAnalyzer(timeout=2.0, verbose=False)
        headers = {
            "From": "user@ukr.net",
            "DKIM-Signature": "v=1; a=rsa-sha256; d=ukr.net; s=main",
            "Received": ["from proxy.ua.residential [91.200.1.1]"],
        }
        with patch("huntertrace.active.activeAnalysis._geolocate_ip_full",
                   _make_mock_geo({
                       "91.200.1": "Ukraine",
                       "213.227.208": "Ukraine",
                   })):
            result = analyzer.analyze(headers)
        if result.dominant_country:
            self.assertIn(result.dominant_country,
                          ["Ukraine", "Russia", "Unknown"])


# ─────────────────────────────────────────────────────────────────────────────
#  8. Metric validation tests
# ─────────────────────────────────────────────────────────────────────────────

class TestMetricValidation(unittest.TestCase):
    """
    Validates the metric computation and that results meet minimum thresholds.
    Uses the mock-based validation framework.
    """

    def setUp(self):
        if not _VALIDATION_AVAILABLE:
            self.skipTest("activeValidation.py not available")

    def test_haversine_formula(self):
        """London to Moscow ≈ 2500 km."""
        dist = _haversine(51.5, -0.1, 55.75, 37.62)
        self.assertAlmostEqual(dist, 2500, delta=200)

    def test_haversine_nyc_london(self):
        """New York to London ≈ 5570 km."""
        dist = _haversine(40.71, -74.01, 51.51, -0.13)
        self.assertAlmostEqual(dist, 5570, delta=200)

    def test_geo_error_same_country(self):
        """Same country → distance 0."""
        err = _geo_error_km("Russia", "Russia")
        self.assertAlmostEqual(err, 0.0, places=5)

    def test_geo_error_russia_china(self):
        """Russia–China distance should be > 1000 km."""
        err = _geo_error_km("Russia", "China")
        self.assertGreater(err, 1000)

    def test_geo_error_unknown_country(self):
        """Unknown country → None (can't compute distance)."""
        err = _geo_error_km("Unknown", "Russia")
        self.assertIsNone(err)

    def test_compute_metrics_empty(self):
        """Empty results → all metrics 0.0."""
        m = compute_metrics([])
        self.assertEqual(m.n_total, 0)
        self.assertEqual(m.attribution_accuracy, 0.0)

    def test_compute_metrics_all_correct(self):
        """100% correct → attribution_accuracy = 1.0, FAR = 0.0."""
        results = [
            CaseResult(
                case_id=f"TEST-{i}", technique="test", scenario="normal",
                true_country="Russia", predicted_country="Russia",
                confidence=0.8, signals_fired=1,
                geo_error_km=0.0, country_correct=True, in_top3=True,
                elapsed_ms=10.0,
            )
            for i in range(10)
        ]
        m = compute_metrics(results)
        self.assertAlmostEqual(m.attribution_accuracy, 1.0, places=3)
        self.assertAlmostEqual(m.false_attribution_rate, 0.0, places=3)

    def test_compute_metrics_all_wrong(self):
        """0% correct → FAR = 1.0 (all confident wrong predictions)."""
        results = [
            CaseResult(
                case_id=f"TEST-{i}", technique="test", scenario="normal",
                true_country="Russia", predicted_country="China",
                confidence=0.9, signals_fired=1,
                geo_error_km=_geo_error_km("China", "Russia"),
                country_correct=False, in_top3=False, elapsed_ms=5.0,
            )
            for i in range(5)
        ]
        m = compute_metrics(results)
        self.assertAlmostEqual(m.attribution_accuracy, 0.0, places=3)
        self.assertAlmostEqual(m.false_attribution_rate, 1.0, places=3)

    def test_compute_metrics_abstention(self):
        """Abstention (no prediction) should not count against accuracy."""
        results = [
            CaseResult(
                case_id="TEST-1", technique="test", scenario="tor",
                true_country="Unknown", predicted_country=None,
                confidence=0.0, signals_fired=0,
                geo_error_km=None, country_correct=False, in_top3=False,
                elapsed_ms=5.0,
            )
        ]
        m = compute_metrics(results)
        self.assertEqual(m.abstention_rate, 1.0)
        # No predicted → attribution_accuracy denominator = 0 → 0.0
        self.assertEqual(m.attribution_accuracy, 0.0)

    def test_calibration_gap_positive_for_good_model(self):
        """
        A well-calibrated model should have higher confidence when correct.
        """
        results = (
            [CaseResult(
                case_id=f"C-{i}", technique="t", scenario="normal",
                true_country="Russia", predicted_country="Russia",
                confidence=0.85, signals_fired=1, geo_error_km=0.0,
                country_correct=True, in_top3=True, elapsed_ms=5.0,
            ) for i in range(8)]
            +
            [CaseResult(
                case_id=f"W-{i}", technique="t", scenario="normal",
                true_country="Russia", predicted_country="China",
                confidence=0.35, signals_fired=1,
                geo_error_km=_geo_error_km("China", "Russia"),
                country_correct=False, in_top3=False, elapsed_ms=5.0,
            ) for i in range(2)]
        )
        m = compute_metrics(results)
        self.assertGreater(m.calibration_gap, 0.0,
            "Correct predictions should have higher avg confidence")

    def test_mock_geo_lookup(self):
        """MockIPGeolocation should return correct country for known prefixes."""
        self.assertEqual(_MOCK_GEO.lookup("103.21.244.1"), "India")
        self.assertEqual(_MOCK_GEO.lookup("5.8.18.10"),    "Russia")
        self.assertEqual(_MOCK_GEO.lookup("209.85.220.1"), "United States")
        self.assertEqual(_MOCK_GEO.lookup("177.71.0.1"),   "Brazil")
        self.assertEqual(_MOCK_GEO.lookup("197.210.1.1"),  "Nigeria")
        self.assertIsNone(_MOCK_GEO.lookup("192.168.1.1")) # private

    def test_canary_validation_cases_run(self):
        """Canary validation cases should run without crashing."""
        from huntertrace.active.activeValidation import CanaryValidator
        validator = CanaryValidator()
        cases     = build_canary_cases()
        results   = validator.run(cases)
        self.assertEqual(len(results), len(cases))
        # All canary cases should have no Python exceptions
        errors = [r.error for r in results if r.error]
        self.assertEqual(errors, [],
            f"Canary cases raised exceptions: {errors}")

    def test_canary_triggered_cases_correct(self):
        """
        The three triggered canary cases (CANARY-001/002/003) should be
        attributed to the correct country using mock geo.
        """
        from huntertrace.active.activeValidation import CanaryValidator
        validator = CanaryValidator()
        cases     = [c for c in build_canary_cases() if c.inputs.get("trigger_ip")]
        results   = validator.run(cases)
        for r in results:
            if r.true_country != "Unknown":
                self.assertIsNotNone(r.predicted_country,
                    f"{r.case_id}: triggered case should produce a prediction")

    def test_full_validation_runner_no_crash(self):
        """
        ValidationRunner.run_all() should complete without raising even
        in offline/no-network mode.
        """
        with patch("socket.getaddrinfo", side_effect=socket.gaierror):
            with patch("activeAnalysis._geolocate_ip_full", return_value={}
                       if _MODULE_AVAILABLE else {}):
                runner = ValidationRunner(verbose=False)
                report = runner.run_all()

        self.assertIsNotNone(report)
        self.assertIsInstance(report.metrics.attribution_accuracy, float)
        self.assertGreaterEqual(report.metrics.n_total, 0)

    def test_minimum_canary_accuracy(self):
        """Canary validation: triggered cases should achieve ≥ 75% accuracy."""
        from huntertrace.active.activeValidation import CanaryValidator
        validator = CanaryValidator()
        cases     = build_canary_cases()
        results   = validator.run(cases)
        triggered = [r for r in results
                     if r.predicted_country and r.true_country != "Unknown"]
        if not triggered:
            self.skipTest("No triggered cases available")
        correct = sum(1 for r in triggered if r.country_correct)
        accuracy = correct / len(triggered)
        self.assertGreaterEqual(accuracy, 0.75,
            f"Canary accuracy {accuracy:.0%} below 75% minimum")


# ─────────────────────────────────────────────────────────────────────────────
#  9. Edge case and robustness tests
# ─────────────────────────────────────────────────────────────────────────────

class TestEdgeCases(unittest.TestCase):
    """
    Edge cases: malformed inputs, empty strings, unusual IPs, Unicode.
    """

    def setUp(self):
        if not _MODULE_AVAILABLE:
            self.skipTest("huntertrace.active.activeAnalysis.py not available")

    def test_is_private_ip_ipv4(self):
        self.assertTrue(_is_private_ip("192.168.1.1"))
        self.assertTrue(_is_private_ip("10.0.0.1"))
        self.assertTrue(_is_private_ip("172.16.0.1"))
        self.assertFalse(_is_private_ip("8.8.8.8"))

    def test_is_private_ip_loopback(self):
        self.assertTrue(_is_private_ip("127.0.0.1"))

    def test_is_private_ip_invalid(self):
        self.assertTrue(_is_private_ip("not-an-ip"))
        self.assertTrue(_is_private_ip(""))

    def test_geolocate_private_returns_none(self):
        result = _geolocate_ip("192.168.1.1")
        self.assertIsNone(result)

    def test_geolocate_loopback_returns_none(self):
        result = _geolocate_ip("127.0.0.1")
        self.assertIsNone(result)

    def test_geolocate_empty_returns_none(self):
        result = _geolocate_ip("")
        self.assertIsNone(result)

    def test_flux_empty_ip_list(self):
        fa = FastFluxAnalyzer(sample_count=1, sample_interval=0.0)
        score = fa._compute_flux_score([], 3600.0)
        self.assertEqual(score, 0.0)

    def test_rtg_geo_empty_measurements(self):
        geo = RTTGeolocator(probe_timeout=0.1)
        with patch.object(geo, "_measure_rtt", return_value=None):
            result = geo.geolocate("1.2.3.4")
        self.assertEqual(result.confidence, 0.0)
        self.assertIsNone(result.estimated_country)

    def test_graph_unicode_domain(self):
        """Unicode/IDN domain in From should not crash the analyzer."""
        analyzer = InfrastructureGraphAnalyzer(timeout=1.0)
        headers = {"From": "user@münchen.de"}  # IDN-like domain
        with patch("socket.getaddrinfo", side_effect=socket.gaierror):
            try:
                result = analyzer.analyze(headers)
                self.assertIsNotNone(result)
            except Exception as exc:
                self.fail(f"Unicode domain caused exception: {exc}")

    def test_graph_no_from_header(self):
        """Headers with no From header should not crash."""
        analyzer = InfrastructureGraphAnalyzer(timeout=1.0)
        with patch("socket.getaddrinfo", side_effect=socket.gaierror):
            result = analyzer.analyze({"Received": ["from x [1.2.3.4]"]})
        self.assertIsInstance(result, InfraGraphResult)

    def test_canary_no_callback_host(self):
        """check() with no callback host should return not-triggered."""
        analyzer = CanaryCallbackAnalyzer(callback_host="")
        result   = analyzer.check("any-token-id")
        self.assertFalse(result.triggered)

    def test_vpn_probe_malformed_ip(self):
        """Malformed IP string should not crash the probe."""
        probe = ActiveVPNProbe(port_timeout=0.1)
        try:
            result = probe.probe("not.an.ip")
            # Should return empty result (treated as private)
            self.assertIsNone(result.signal)
        except Exception as exc:
            self.fail(f"Malformed IP caused exception: {exc}")


# ─────────────────────────────────────────────────────────────────────────────
#  Entry point
# ─────────────────────────────────────────────────────────────────────────────

def _run_with_summary():
    """Run all tests and print a summary table."""
    loader = unittest.TestLoader()
    suite  = unittest.TestSuite()

    classes = [
        TestCanaryCallbackAnalyzer,
        TestFastFluxAnalyzer,
        TestActiveVPNProbe,
        TestRTTGeolocator,
        TestInfrastructureGraphAnalyzer,
        TestActiveAnalysisPipeline,
        TestAdversarialScenarios,
        TestMetricValidation,
        TestEdgeCases,
    ]
    for cls in classes:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2, stream=sys.stdout)
    result = runner.run(suite)

    print()
    print("=" * 65)
    total   = result.testsRun
    failed  = len(result.failures) + len(result.errors)
    skipped = len(result.skipped)
    passed  = total - failed - skipped
    print(f"  TOTAL : {total}")
    print(f"  PASS  : {passed}")
    print(f"  SKIP  : {skipped}  (network/module unavailable)")
    print(f"  FAIL  : {failed}")
    if failed == 0:
        print("  ✓  ALL TESTS PASSED")
    else:
        print("  ✗  FAILURES DETECTED")
        for f in result.failures + result.errors:
            short = str(f[0]).split(" ")[0]
            last  = f[1].strip().splitlines()[-1] if f[1] else ""
            print(f"     → {short}: {last[:80]}")
    print("=" * 65)
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(_run_with_summary())
    