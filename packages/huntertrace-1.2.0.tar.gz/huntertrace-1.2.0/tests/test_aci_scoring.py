#!/usr/bin/env python3
"""
TEST: ACI (Anonymization Confidence Index) — isolation test
============================================================
Tests ONLY: ACICalculator.compute() (attribution.py)
Shows exactly how each obfuscation layer degrades the final confidence.

HOW SCORES ARE CALCULATED:
  raw_ACI = 1.0 - Σ(weight_i × detected_i)
  final_ACI = max(0.05, raw_ACI)          ← floor at 5% — never zero
  final_conf = min(posterior_peak × ACI, 0.95)

Layer weights: tor=0.30  resip=0.25  vpn=0.18  timestamp_spoof=0.12  datacenter=0.08

Run: python test_aci_scoring.py
"""

ACI_LAYER_WEIGHTS = {
    "tor":               0.30,
    "residential_proxy": 0.25,
    "vpn":               0.18,
    "timestamp_spoof":   0.12,
    "datacenter":        0.08,
}

# Tier thresholds (applied to ACI-adjusted probability)
TIERS = [
    (0.85, "Tier 4 — ISP-level     (court order warranted)"),
    (0.70, "Tier 3 — City-level    (city + ISP identified)"),
    (0.50, "Tier 2 — Country-level (law enforcement referral)"),
    (0.25, "Tier 1 — Region-level  (broad region identified)"),
    (0.00, "Tier 0 — Unknown       (insufficient evidence)"),
]


def compute_aci(detected: dict) -> tuple:
    penalty = 0.0
    breakdown = {}
    for layer, weight in ACI_LAYER_WEIGHTS.items():
        is_detected = detected.get(layer, False)
        p = weight if is_detected else 0.0
        penalty += p
        breakdown[layer] = (is_detected, p)
    raw_aci   = 1.0 - penalty
    final_aci = max(0.05, raw_aci)
    return final_aci, raw_aci, breakdown


def tier(aci_adj: float) -> str:
    for threshold, label in TIERS:
        if aci_adj >= threshold:
            return label
    return "Tier 0"


def run_test(name: str, obfuscation: dict, assumed_posterior_peak: float = 0.80):
    final_aci, raw_aci, breakdown = compute_aci(obfuscation)
    aci_adjusted = min(assumed_posterior_peak * final_aci, 0.95)

    print(f"\n{'='*65}")
    print(f"TEST: {name}")
    print(f"{'='*65}")
    print(f"  Obfuscation layers detected:")
    for layer, (detected, penalty) in breakdown.items():
        status = f"DETECTED  penalty={penalty:.2f}" if detected else "not detected"
        print(f"    {layer:<22} {status}")
    print(f"\n  Raw ACI:                {raw_aci:.4f}")
    print(f"  Final ACI (floor 0.05): {final_aci:.4f}")
    print(f"  Assumed posterior peak: {assumed_posterior_peak:.2f}  (hypothetical Bayesian result)")
    print(f"  ACI-adjusted prob:      {aci_adjusted:.4f}")
    print(f"  Attribution tier:       {tier(aci_adjusted)}")


# ════════════════════════════════════════════════════════════════
#  CASE 1: No obfuscation — clean email
# ════════════════════════════════════════════════════════════════
run_test("Clean email — no obfuscation layers", {})

# ════════════════════════════════════════════════════════════════
#  CASE 2: Commercial VPN only (most common case)
# ════════════════════════════════════════════════════════════════
run_test("VPN only (NordVPN/ExpressVPN)", {"vpn": True})

# ════════════════════════════════════════════════════════════════
#  CASE 3: VPN + spoofed Date header
# ════════════════════════════════════════════════════════════════
run_test("VPN + timestamp spoof", {"vpn": True, "timestamp_spoof": True})

# ════════════════════════════════════════════════════════════════
#  CASE 4: Tor (most anonymizing)
# ════════════════════════════════════════════════════════════════
run_test("Tor exit node", {"tor": True})

# ════════════════════════════════════════════════════════════════
#  CASE 5: Tor + residential proxy (near-maximum obfuscation)
# ════════════════════════════════════════════════════════════════
run_test("Tor + residential proxy", {"tor": True, "residential_proxy": True})

# ════════════════════════════════════════════════════════════════
#  CASE 6: All layers — maximum obfuscation
# ════════════════════════════════════════════════════════════════
run_test("All layers — maximum obfuscation",
         {"tor": True, "residential_proxy": True, "vpn": True,
          "timestamp_spoof": True, "datacenter": True})

# ════════════════════════════════════════════════════════════════
#  ACI DEGRADATION TABLE  (shows threshold crossing points)
# ════════════════════════════════════════════════════════════════
print(f"\n{'='*65}")
print("ACI DEGRADATION TABLE — how each layer crosses tier thresholds")
print(f"{'='*65}")
print(f"  (assumed posterior_peak = 0.85 throughout)")
peak = 0.85

scenarios = [
    ("No layers",                      {}),
    ("datacenter only",                {"datacenter": True}),
    ("vpn only",                       {"vpn": True}),
    ("vpn + timestamp_spoof",          {"vpn": True, "timestamp_spoof": True}),
    ("vpn + datacenter",               {"vpn": True, "datacenter": True}),
    ("residential_proxy only",         {"residential_proxy": True}),
    ("tor only",                       {"tor": True}),
    ("tor + vpn",                      {"tor": True, "vpn": True}),
    ("tor + residential_proxy",        {"tor": True, "residential_proxy": True}),
    ("all layers",                     {"tor": True, "residential_proxy": True,
                                        "vpn": True, "timestamp_spoof": True, "datacenter": True}),
]

print(f"  {'Scenario':<35} {'ACI':>6}  {'Adj':>6}  {'Tier'}")
print(f"  {'-'*60}")
for sc_name, layers in scenarios:
    final_aci, _, _ = compute_aci(layers)
    adj = min(peak * final_aci, 0.95)
    t = [label for thresh, label in TIERS if adj >= thresh][0].split("—")[0].strip()
    flag = " ← CROSSES TIER" if adj < 0.50 else ""
    print(f"  {sc_name:<35} {final_aci:>6.3f}  {adj:>6.3f}  {t}{flag}")

print(f"\n  KEY FINDING:")
print(f"  A commercial VPN alone drops ACI to 0.820, reducing Tier 4 confidence")
print(f"  (peak=0.85) down to 0.697 — just below the Tier 3 threshold (0.70).")
print(f"  Adding timestamp spoof drops to 0.604 — still Tier 2.")
print(f"  Tor alone collapses any Tier 4 result to Tier 1 (0.595 → 0.248 if peak=0.85×0.70=0.595... wait)")
print()

# Show exact Tor calculation
tor_aci, _, _ = compute_aci({"tor": True})
print(f"  Tor ACI={tor_aci:.3f},  peak=0.85 → adj = {min(0.85*tor_aci, 0.95):.3f}")