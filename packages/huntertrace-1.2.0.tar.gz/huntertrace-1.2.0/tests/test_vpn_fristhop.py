#!/usr/bin/env python3
"""
TEST: VPN First-Hop ISP Extraction — isolation test
=====================================================
Tests ONLY: RealIPBacktracker._extract_first_hop_isp() (vpnBacktrack.py)
No network calls, no email parsing, no attribution engine.

HOW SCORES ARE CALCULATED:
  confidence = 0.92  if a non-private IP is found in received_list[0]
  confidence = 0.35  if no bracketed IP found (obfuscated)
  KNOWN BUG: received_list[0] is the LAST hop (recipient side), not sender.
             Should be received_list[-1].

Run: python test_vpn_firsthop.py
"""

import re
import ipaddress
from typing import Optional, List, Dict

# ────────────────────────────────────────────────────────────────────────────
# Minimal re-implementation of just the first-hop method
# ────────────────────────────────────────────────────────────────────────────

def _is_private_ip(ip: str) -> bool:
    private = ["10.0.0.0/8","172.16.0.0/12","192.168.0.0/16","127.0.0.0/8"]
    try:
        ip_obj = ipaddress.ip_address(ip)
        return any(ip_obj in ipaddress.ip_network(r, strict=False) for r in private)
    except ValueError:
        return True


def extract_first_hop_BUGGY(received_headers: List[str]):
    """Current implementation — reads index 0 (WRONG: that's the destination)."""
    if not received_headers:
        return None, None, "no Received headers"

    first_hop = str(received_headers[0])  # BUG: this is the LAST-added = recipient server
    ip_pattern = r'\[([0-9a-fA-F:.]+)\]'
    matches = re.findall(ip_pattern, first_hop)

    if matches:
        ip = matches[0]
        if not _is_private_ip(ip) and ip != "127.0.0.1":
            return ip, 0.92, f"found public IP [{ip}] in received_headers[0] (WRONG hop)"
    return None, 0.35, "no public IP found in received_headers[0]"


def extract_first_hop_FIXED(received_headers: List[str]):
    """Fixed implementation — reads index -1 (sender's ISP)."""
    if not received_headers:
        return None, None, "no Received headers"

    first_hop = str(received_headers[-1])  # FIX: last element = first-added = sender's hop
    ip_pattern = r'\[([0-9a-fA-F:.]+)\]'
    matches = re.findall(ip_pattern, first_hop)

    if matches:
        ip = matches[0]
        if not _is_private_ip(ip) and ip != "127.0.0.1":
            return ip, 0.65, f"found public IP [{ip}] in received_headers[-1] (sender ISP)"
    return None, 0.35, "no public IP found in received_headers[-1]"


def run_test(name: str, received_headers: List[str]):
    buggy_ip, buggy_conf, buggy_note = extract_first_hop_BUGGY(received_headers)
    fixed_ip, fixed_conf, fixed_note  = extract_first_hop_FIXED(received_headers)

    print(f"\n{'='*65}")
    print(f"TEST: {name}")
    print(f"{'='*65}")
    print(f"  Received headers ({len(received_headers)} hops, index 0=newest, -1=oldest):")
    for i, h in enumerate(received_headers):
        tag = " ← recipient server (newest)" if i == 0 else ""
        tag = " ← SENDER ISP (oldest)" if i == len(received_headers)-1 else tag
        print(f"    [{i}] {h[:80]}{tag}")
    print()
    print(f"  BUGGY  (index 0):  IP={buggy_ip}  conf={buggy_conf}  | {buggy_note}")
    print(f"  FIXED  (index -1): IP={fixed_ip}   conf={fixed_conf}  | {fixed_note}")
    if buggy_ip != fixed_ip:
        print(f"  *** DIFFERENCE: buggy extracts '{buggy_ip}', fixed extracts '{fixed_ip}' ***")
    else:
        print(f"  Same IP extracted (single-hop email — no difference with 1 hop)")


# ════════════════════════════════════════════════════════════════
#  CASE 1: Normal 3-hop phishing email
#  Path: attacker (1.2.3.4) → relay (5.6.7.8) → victim MX (9.10.11.12)
#  Received headers added in reverse: newest first
# ════════════════════════════════════════════════════════════════
run_test(
    "3-hop email — attacker behind relay",
    received_headers=[
        "from mail.victim.com ([9.10.11.12]) by mx.victim.com",      # hop 0 = newest
        "from relay.legit.com ([5.6.7.8]) by mail.victim.com",       # hop 1 = relay
        "from smtp.attacker-isp.ng ([1.2.3.4]) by relay.legit.com",  # hop 2 = SENDER ISP
    ]
)

# ════════════════════════════════════════════════════════════════
#  CASE 2: Gmail-routed phishing
#  Attacker uses Gmail → Gmail routes through their infra
# ════════════════════════════════════════════════════════════════
run_test(
    "Gmail-routed phishing",
    received_headers=[
        "from mx.google.com ([209.85.220.41]) by victim-mx.com",      # newest: Google MX
        "from mail-lf1-f41.google.com ([209.85.64.41]) by mx.google.com",
        "from attacker-pc ([103.240.55.12]) by smtp.gmail.com",       # SENDER's IP leaked here
    ]
)

# ════════════════════════════════════════════════════════════════
#  CASE 3: VPN-routed email (attacker → VPN exit → SMTP relay)
# ════════════════════════════════════════════════════════════════
run_test(
    "VPN-routed — attacker is behind NordVPN exit",
    received_headers=[
        "from inbound.victim-corp.com ([10.0.0.5]) by internal.victim-corp.com",  # internal relay
        "from smtp.sendgrid.net ([167.89.10.2]) by inbound.victim-corp.com",       # sendgrid
        "from nordvpn-exit.nl ([185.230.124.1]) by smtp.sendgrid.net",            # VPN exit
        "from unknown ([]) by nordvpn-exit.nl",                                    # attacker: LEAKED as unknown
    ]
)

# ════════════════════════════════════════════════════════════════
#  CASE 4: Single hop (attacker has direct SMTP access)
# ════════════════════════════════════════════════════════════════
run_test(
    "Single hop — direct MTA send",
    received_headers=[
        "from attacker-server.ru ([91.108.4.55]) by victim-mx.com",
    ]
)

# ════════════════════════════════════════════════════════════════
#  CASE 5: Obfuscated — no IP in brackets
# ════════════════════════════════════════════════════════════════
run_test(
    "Obfuscated Received headers — no IPs in brackets",
    received_headers=[
        "from mail.victim.com by mx.victim.com with SMTP",
        "from relay by mail.victim.com",
        "from unknown by relay",
    ]
)

# ════════════════════════════════════════════════════════════════
#  SUMMARY
# ════════════════════════════════════════════════════════════════
print(f"\n{'='*65}")
print("SUMMARY — Key difference between BUGGY and FIXED:")
print(f"{'='*65}")
print("  BUGGY (index 0):  Extracts the RECIPIENT server's IP.")
print("                    This is always a known legitimate mail server.")
print("                    Geolocation of this IP = victim location, not attacker.")
print()
print("  FIXED (index -1): Extracts the SENDER's first SMTP submission IP.")
print("                    This is the attacker's ISP or VPN exit.")
print("                    Correct basis for geolocation attribution.")
print()
print("  To fix in vpnBacktrack.py line 306:")
print("    CHANGE:  first_hop = str(received_list[0])")
print("    TO:      first_hop = str(received_list[-1])")
print()
print("  Also reduce confidence from 0.92 → 0.65 because even index[-1]")
print("  is often a webmail submission server (smtp.gmail.com), not the")
print("  attacker's raw ISP IP, unless a direct MTA send was used.")