#!/usr/bin/env python3
"""
TEST: Graph Centrality Boost — isolation test + no-op bug proof
================================================================
Tests ONLY: compute_attribution_boost() + integrate_graph_boost_into_attribution()
from centrality.py.

HOW SCORES ARE CALCULATED:
  ip_reuse_boost     = min(1.0 + count × 0.15,  1.5)
  domain_reuse_boost = min(1.0 + count × 0.12,  1.4)
  community_boost    = 1.0 + min(0.3, cohesion × 0.4)
  campaign_boost     = 1.0 + min(0.4, campaign_count × 0.05)
  combined_boost     = product of all boosts,  capped at 2.0

BUG PROOF: integrate_graph_boost_into_attribution() applies combined_boost
           to ALL regions uniformly. After renormalization, all relative
           probabilities are UNCHANGED. The function is a no-op.

Run: python test_graph_centrality.py
"""


def compute_ip_boost(occurrences: int) -> float:
    """IP seen in N emails → reuse boost."""
    if occurrences < 2:
        return 1.0
    return min(1.0 + (occurrences - 1) * 0.15, 1.5)


def compute_domain_boost(occurrences: int) -> float:
    if occurrences < 2:
        return 1.0
    return min(1.0 + (occurrences - 1) * 0.12, 1.4)


def compute_community_boost(cohesion: float) -> float:
    if cohesion < 0.5:
        return 1.0
    return 1.0 + min(0.3, cohesion * 0.4)


def compute_campaign_boost(campaign_count: int) -> float:
    if campaign_count < 5:
        return 1.0
    return 1.0 + min(0.4, campaign_count * 0.05)


def compute_combined_boost(ip_occ, domain_occ, cohesion, campaign_count):
    ip   = compute_ip_boost(ip_occ)
    dom  = compute_domain_boost(domain_occ)
    comm = compute_community_boost(cohesion)
    camp = compute_campaign_boost(campaign_count)
    combined = ip * dom * comm * camp
    return min(2.0, combined), ip, dom, comm, camp


# THE BUGGY INTEGRATION FUNCTION (verbatim from centrality.py)
def integrate_graph_boost_buggy(attribution_probs: dict, combined_boost: float) -> dict:
    """Applies same scalar boost to ALL regions, then renormalizes."""
    boosted = {region: prob * combined_boost for region, prob in attribution_probs.items()}
    total = sum(boosted.values())
    if total > 0:
        boosted = {r: p / total for r, p in boosted.items()}
    return boosted


# THE FIXED INTEGRATION FUNCTION (boost only the graph-supported region)
def integrate_graph_boost_fixed(attribution_probs: dict, combined_boost: float,
                                  graph_supported_region: str) -> dict:
    """Applies boost ONLY to the graph-supported region, then renormalizes."""
    boosted = {}
    for region, prob in attribution_probs.items():
        if region == graph_supported_region:
            boosted[region] = prob * combined_boost
        else:
            boosted[region] = prob
    total = sum(boosted.values())
    if total > 0:
        boosted = {r: p / total for r, p in boosted.items()}
    return boosted


def run_boost_test(name: str, ip_occ: int, domain_occ: int, cohesion: float, campaigns: int):
    combined, ip, dom, comm, camp = compute_combined_boost(ip_occ, domain_occ, cohesion, campaigns)
    print(f"\n{'='*65}")
    print(f"BOOST COMPUTATION: {name}")
    print(f"{'='*65}")
    print(f"  ip_reuse_boost     ({ip_occ} occurrences): {ip:.3f}")
    print(f"  domain_reuse_boost ({domain_occ} occurrences): {dom:.3f}")
    print(f"  community_boost    (cohesion={cohesion:.2f}): {comm:.3f}")
    print(f"  campaign_boost     ({campaigns} campaigns): {camp:.3f}")
    print(f"  combined_boost     = {ip:.3f} × {dom:.3f} × {comm:.3f} × {camp:.3f}")
    print(f"                     = {min(2.0, ip*dom*comm*camp):.4f}  (capped at 2.0)")
    return combined


def demonstrate_noop_bug(prior_probs: dict, combined_boost: float, graph_region: str):
    """Prove that buggy integration changes nothing."""
    buggy_result  = integrate_graph_boost_buggy(prior_probs, combined_boost)
    fixed_result  = integrate_graph_boost_fixed(prior_probs, combined_boost, graph_region)

    print(f"\n  {'Region':<20} {'Before':>10}  {'BUGGY':>10}  {'FIXED':>10}  {'Δ buggy':>8}  {'Δ fixed':>8}")
    print(f"  {'-'*70}")
    for region in sorted(prior_probs.keys(), key=lambda r: -prior_probs[r]):
        before = prior_probs[region]
        b_after = buggy_result[region]
        f_after = fixed_result[region]
        delta_b = b_after - before
        delta_f = f_after - before
        flag = " ← boosted" if region == graph_region else ""
        print(f"  {region:<20} {before:>10.4f}  {b_after:>10.4f}  {f_after:>10.4f}  {delta_b:>+8.4f}  {delta_f:>+8.4f}{flag}")

    print(f"\n  Buggy: top region unchanged = '{max(buggy_result, key=buggy_result.get)}'")
    print(f"  Fixed: top region is now    = '{max(fixed_result,  key=fixed_result.get)}'")

    # Prove they're identical
    diffs = {r: abs(buggy_result[r] - prior_probs[r]) for r in prior_probs}
    max_diff = max(diffs.values())
    print(f"\n  MAX absolute change in buggy output vs input: {max_diff:.10f}")
    if max_diff < 1e-9:
        print("  ✓ CONFIRMED: Buggy integration is a mathematical no-op.")
        print("    Boosting all regions by the same factor then normalizing")
        print("    is equivalent to multiplying the entire distribution by 1.")
    else:
        print(f"  Unexpected: diff={max_diff} (floating point noise)")


# ════════════════════════════════════════════════════════════════
#  BOOST COMPUTATION CASES
# ════════════════════════════════════════════════════════════════
run_boost_test("Ephemeral infra — single-use IP and domain",
               ip_occ=1, domain_occ=1, cohesion=0.2, campaigns=1)

run_boost_test("Moderate reuse — same IP in 3 emails",
               ip_occ=3, domain_occ=2, cohesion=0.6, campaigns=3)

run_boost_test("Established actor — IP reused 8×, tight cluster, 10 campaigns",
               ip_occ=8, domain_occ=6, cohesion=0.9, campaigns=10)

# ════════════════════════════════════════════════════════════════
#  NO-OP BUG DEMONSTRATION
# ════════════════════════════════════════════════════════════════
print(f"\n{'='*65}")
print("NO-OP BUG PROOF")
print(f"{'='*65}")
print("Scenario: Bayesian engine says 'India' at 45%, 'Russia' at 20%,")
print("Graph evidence strongly supports India (IP reused 8×, boost=1.75×).")
print()

prior_probs = {
    "India":        0.45,
    "Russia":       0.20,
    "Nigeria":      0.15,
    "United States":0.10,
    "Other":        0.10,
}
combined_boost = 1.75
graph_region = "India"

print(f"  Combined boost:    {combined_boost}×")
print(f"  Graph region:      {graph_region}")

demonstrate_noop_bug(prior_probs, combined_boost, graph_region)

# ════════════════════════════════════════════════════════════════
#  SHOW WHAT HAPPENS WITH REALISTIC WEAK POSTERIOR (India ~30%)
# ════════════════════════════════════════════════════════════════
print(f"\n{'='*65}")
print("REALISTIC CASE — weak posterior, graph boost should matter")
print(f"{'='*65}")
print("Bayesian output is ambiguous: India 30%, Russia 25%, Nigeria 22%")
print("Graph strongly says India (boost=1.75×). Does FIXED integration work?")
print()

prior_probs_weak = {
    "India":   0.30, "Russia": 0.25, "Nigeria": 0.22,
    "Germany": 0.13, "Other":  0.10,
}
demonstrate_noop_bug(prior_probs_weak, 1.75, "India")

print(f"\n  CONCLUSION: With FIXED integration, India rises from 0.30 → top.")
print(f"  With BUGGY integration, Russia could still be top — graph evidence wasted.")