#!/usr/bin/env python3
"""
MASTER COMPARISON RUNNER — HunterTrace Backtracking Techniques
==============================================================
Runs all isolation tests and shows the key numeric differences
between each technique's scoring approach.

Run: python test_all_techniques_compare.py

Files:
  test_bayesian_updater.py      — Bayesian log-odds, LR table, ACI tier
  test_vpn_firsthop.py          — Received header index bug + fix
  test_campaign_correlator.py   — Weighted signal similarity matrix
  test_aci_scoring.py           — ACI layer degradation table
  test_timezone_backtrack.py    — Spoofing detection + format bug
  test_graph_centrality.py      — Boost computation + no-op bug proof
"""

import math

print("""
╔══════════════════════════════════════════════════════════════════╗
║      HUNTЕРТRACE — TECHNIQUE COMPARISON MATRIX                   ║
╚══════════════════════════════════════════════════════════════════╝
""")


# ────────────────────────────────────────────────────────────────
# PART 1 — SCORE BASIS TABLE
# ────────────────────────────────────────────────────────────────
print("═" * 70)
print("PART 1 — WHAT MATRIX/FORMULA EACH TECHNIQUE IS BASED ON")
print("═" * 70)

techniques = [
    ("Bayesian updater",
     "Log-odds matrix (prior × LR_signals)",
     "P(region) = softmax(Σ log_LR)",
     "attribution.py:BayesianUpdater"),
    ("ACI scoring",
     "Additive penalty matrix (layer weights)",
     "ACI = max(0.05, 1.0 - Σ penalties)",
     "attribution.py:ACICalculator"),
    ("Campaign correlator",
     "Weighted similarity matrix (12 signals)",
     "score = Σ(w_i × match_i) / Σ(w_i present)",
     "correlator.py:SimilarityEngine"),
    ("VPN first-hop",
     "Heuristic confidence assignment",
     "conf = 0.92 (IP found) / 0.35 (no IP)",
     "vpnBacktrack.py:_extract_first_hop_isp"),
    ("Timezone backtrack",
     "Tiered confidence by server validation",
     "conf = 0.10/0.30/0.65 (3 tiers)",
     "vpnBacktrack.py:_analyze_timezone_location"),
    ("Graph centrality",
     "Multiplicative boost from reuse counts",
     "boost = ip × domain × community × campaign",
     "centrality.py:compute_attribution_boost"),
]

for name, matrix_basis, formula, location in techniques:
    print(f"\n  {name}")
    print(f"    Basis:    {matrix_basis}")
    print(f"    Formula:  {formula}")
    print(f"    File:     {location}")


# ────────────────────────────────────────────────────────────────
# PART 2 — SCORE RANGE TABLE (what scores each technique can produce)
# ────────────────────────────────────────────────────────────────
print(f"\n\n{'═'*70}")
print("PART 2 — SCORE RANGES AND MEANING")
print(f"{'═'*70}")
print(f"\n  {'Technique':<28} {'Min':>6}  {'Max':>6}  {'Unit'}")
print(f"  {'-'*55}")

ranges = [
    ("Bayesian: raw posterior",    0.001, 0.95, "P(region)"),
    ("Bayesian: ACI-adjusted",     0.001, 0.95, "P(region)×ACI"),
    ("ACI value",                  0.05,  1.00, "obfuscation penalty"),
    ("Similarity score",           0.00,  0.92, "signal match fraction"),
    ("VPN first-hop conf",         0.35,  0.92, "fixed heuristic"),
    ("Timezone conf (spoofed)",    0.10,  0.18, "0.10 + optional +0.08"),
    ("Timezone conf (unverified)", 0.30,  0.38, "0.30 + optional +0.08"),
    ("Timezone conf (validated)",  0.65,  0.73, "0.65 + optional +0.08"),
    ("Graph combined boost",       1.00,  2.00, "multiplicative factor"),
]

for name, lo, hi, unit in ranges:
    print(f"  {name:<28} {lo:>6.2f}  {hi:>6.2f}  {unit}")


# ────────────────────────────────────────────────────────────────
# PART 3 — WHAT DIFFERS BETWEEN TECHNIQUES
# ────────────────────────────────────────────────────────────────
print(f"\n\n{'═'*70}")
print("PART 3 — KEY DIFFERENCES BETWEEN TECHNIQUES")
print(f"{'═'*70}")

diffs = [
    ("Bayesian vs Timezone backtrack",
     [
         "Bayesian: produces a probability DISTRIBUTION over all regions.",
         "Timezone: produces a single confidence VALUE for ONE signal only.",
         "Bayesian: input is a dict of signals, output is a posterior list.",
         "Timezone: input is Date+Received headers, output is (region, confidence).",
         "Bayesian: confidence can INCREASE with more signals (cumulative).",
         "Timezone: confidence is CAPPED at 0.73 regardless of other evidence.",
     ]),
    ("Correlator similarity vs Bayesian probability",
     [
         "Correlator: answers 'are these two emails from the SAME actor?'",
         "Bayesian:   answers 'which COUNTRY is this actor in?'",
         "Correlator: uses 12-signal WEIGHTED MATCH (0.0–0.92).",
         "Bayesian:   uses LIKELIHOOD RATIOS applied to geographic priors.",
         "Correlator: missing signals are EXCLUDED from denominator.",
         "Bayesian:   missing signals leave log_odds unchanged (neutral).",
         "Correlator: hard cap 0.92 — email forensics cannot reach certainty.",
         "Bayesian:   hard cap 0.95 after ACI adjustment.",
     ]),
    ("ACI vs VPN first-hop confidence",
     [
         "ACI:       a multiplier that DEGRADES an existing probability.",
         "VPN hop:   an independent signal that PRODUCES a confidence value.",
         "ACI:       operates on the FINAL attribution result (post-Bayes).",
         "VPN hop:   operates on the RAW email headers (pre-Bayes).",
         "ACI:       accounts for Tor (0.30), RESIP (0.25), VPN (0.18).",
         "VPN hop:   accounts for obfuscation only via counter-penalties.",
     ]),
    ("Graph boost vs all others",
     [
         "Graph:     operates on CAMPAIGN-LEVEL infrastructure patterns.",
         "Others:    operate on SINGLE-EMAIL header signals.",
         "Graph:     needs multiple emails to build meaningful structure.",
         "Others:    produce useful output from a single email.",
         "Graph:     boost is multiplicative (1.0×–2.0×), not additive.",
         "CURRENT BUG: the graph boost is applied uniformly to ALL regions",
         "            and then renormalized — making it a mathematical no-op.",
     ]),
]

for title, points in diffs:
    print(f"\n  ┌─ {title}")
    for point in points:
        marker = "  ✗" if "BUG" in point else "  •"
        print(f"  {marker} {point}")


# ────────────────────────────────────────────────────────────────
# PART 4 — NUMERIC COMPARISON (same scenario, each technique)
# ────────────────────────────────────────────────────────────────
print(f"\n\n{'═'*70}")
print("PART 4 — SAME SCENARIO, ALL TECHNIQUES (India email, VPN in NL)")
print(f"{'═'*70}")
print("""
  Email profile:
    - Date: Mon 17 Mar 2026 14:32:00 +0530   (India timezone)
    - Received corroborates +0530
    - Origin IP: 185.220.101.x  (NordVPN exit, Netherlands)
    - From: attacker@gmail.com  (DKIM: gmail.com)
    - Real IP leaked: 103.87.xx.xx (India ASN)
    - IP reused in 4 previous emails from same campaign
""")

# Technique 1: Bayesian (simplified)
lr_real_ip = 18.0
lr_tz = 6.0
india_prior = 0.080
other_prior = 0.044

log_odds_india = math.log(india_prior / other_prior)
log_odds_india += math.log(lr_real_ip)   # real_ip_country = India
log_odds_india += math.log(lr_tz)        # timezone_offset = +0530

# Rough posterior (India vs all others combined)
exp_india = math.exp(log_odds_india)
exp_others = sum(math.exp(math.log(p/other_prior) + math.log(max(0.3, 1/lr_real_ip)) + math.log(max(0.3, 1/lr_tz)))
                 for r, p in [("Russia",0.070),("Nigeria",0.085),("China",0.065),
                               ("Romania",0.045),("Other",0.044)] )
bayesian_prob = exp_india / (exp_india + exp_others)

# Technique 2: ACI
vpn_detected = True
aci = max(0.05, 1.0 - (0.18 if vpn_detected else 0))
aci_adj = min(bayesian_prob * aci, 0.95)

# Technique 3: Correlator (vs previous email with same tz + dkim)
# tz=0.25 match + dkim=0.18 match + webmail=0.10 match + send_hour=0.08 match
total_matched = 0.25 + 0.18 + 0.10 + 0.08
total_possible = 0.25 + 0.18 + 0.10 + 0.08
sim_score = total_matched / total_possible  # = 1.0

# Technique 4: VPN first-hop (BUGGY reads index 0 = recipient server)
firsthop_buggy_conf = 0.92   # finds recipient server IP (wrong)
firsthop_fixed_conf = 0.65   # finds attacker submission IP (correct)

# Technique 5: Timezone
tz_conf = min(0.65 + 0.08, 0.73)   # validated + VPN≠India bonus

# Technique 6: Graph boost (4 IP reuses)
ip_boost = min(1.0 + 3 * 0.15, 1.5)  # 3 additional occurrences

print(f"  {'Technique':<30} {'Raw score':>12}  {'Meaning'}")
print(f"  {'-'*65}")
print(f"  {'Bayesian raw P(India)':<30} {bayesian_prob:>12.4f}  posterior probability")
print(f"  {'ACI (VPN detected)':<30} {aci:>12.4f}  obfuscation multiplier")
print(f"  {'Bayesian ACI-adjusted':<30} {aci_adj:>12.4f}  final attribution probability")
print(f"  {'Correlator vs prev email':<30} {sim_score:>12.4f}  same-actor probability")
print(f"  {'VPN first-hop (BUGGY)':<30} {firsthop_buggy_conf:>12.4f}  wrong server, overconfident")
print(f"  {'VPN first-hop (FIXED)':<30} {firsthop_fixed_conf:>12.4f}  correct server, calibrated")
print(f"  {'Timezone confidence':<30} {tz_conf:>12.4f}  validated + VPN mismatch")
print(f"  {'Graph IP reuse boost':<30} {ip_boost:>12.4f}  multiplicative factor (×)")
print()

# Tier assignment
tier = "Tier 0"
if aci_adj >= 0.85: tier = "Tier 4 — ISP-level"
elif aci_adj >= 0.70: tier = "Tier 3 — City-level"
elif aci_adj >= 0.50: tier = "Tier 2 — Country-level"
elif aci_adj >= 0.25: tier = "Tier 1 — Region-level"
print(f"  Attribution tier: {tier}")

print(f"""
  INTERPRETATION:
  • Bayesian gives India {bayesian_prob:.1%} probability from real_ip + timezone.
  • VPN penalty (ACI=0.82) reduces this to {aci_adj:.1%} → {tier}.
  • Correlator says this email is from the SAME actor as previous ones (sim={sim_score:.2f}).
  • Timezone independently corroborates India at {tz_conf:.2f} confidence.
  • Graph boost ({ip_boost:.2f}×) is computed but currently a no-op until the
    integration bug is fixed.
""")

print("Run individual test files for deeper inspection of each technique:")
print("  python test_bayesian_updater.py")
print("  python test_vpn_firsthop.py")
print("  python test_campaign_correlator.py")
print("  python test_aci_scoring.py")
print("  python test_timezone_backtrack.py")
print("  python test_graph_centrality.py")