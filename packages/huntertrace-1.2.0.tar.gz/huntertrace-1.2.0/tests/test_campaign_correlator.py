#!/usr/bin/env python3
"""
TEST: Campaign Correlator — Similarity Engine isolation test
=============================================================
Tests ONLY: SimilarityEngine.compare() + ClusterBuilder Union-Find (correlator.py)
No pipeline, no real emails, no network.

HOW SCORES ARE CALCULATED:
  score = Σ(weight_i × match_val_i) / Σ(weight_i for signals PRESENT in both)
  Missing signals are skipped (not penalized).
  prob  = min(0.92, score)
  Verdicts: ≥0.72 SAME_ACTOR  ≥0.50 LIKELY_SAME  ≥0.30 POSSIBLE  else DIFFERENT

Run: python test_campaign_correlator.py
"""

import math
import os
from dataclasses import dataclass
from typing import Optional, List, Tuple
import re
from collections import defaultdict


# ── Signal weights (from correlator.py) ─────────────────────────────────────
SIGNAL_WEIGHTS = {
    "timezone_offset": 0.25, "real_ip": 0.22,  "dkim_domain": 0.18,
    "from_domain":     0.15, "vpn_provider": 0.12, "webmail_provider": 0.10,
    "send_hour_bucket":0.08, "mail_client": 0.07, "vpn_asn": 0.06,
    "subject_pattern": 0.05, "hop_count": 0.04, "send_day_type": 0.03,
}

THRESHOLD_SAME   = 0.72
THRESHOLD_LIKELY = 0.50
THRESHOLD_POSS   = 0.30


@dataclass
class FP:
    name: str
    tz_offset: Optional[str] = None
    real_ip: Optional[str] = None
    dkim_domain: Optional[str] = None
    from_domain: Optional[str] = None
    vpn_provider: Optional[str] = None
    webmail_provider: Optional[str] = None
    send_hour: Optional[int] = None
    mail_client: Optional[str] = None
    vpn_asn: Optional[str] = None
    subject_pattern: Optional[str] = None
    hop_count: Optional[int] = None
    send_day: Optional[str] = None


def exact(a, b) -> float:
    return 1.0 if str(a).strip().lower() == str(b).strip().lower() else 0.0

def hour_bucket(a, b) -> float:
    try:
        ah, bh = int(a), int(b)
        if ah // 4 == bh // 4:  return 1.0
        if abs(ah - bh) <= 1:   return 0.5
    except: pass
    return 0.0

def day_type(a, b) -> float:
    weekend = {"Saturday","Sunday"}
    return 1.0 if (a in weekend) == (b in weekend) else 0.0

def prefix_match(a, b) -> float:
    sa, sb = str(a)[:20].lower(), str(b)[:20].lower()
    if sa == sb: return 1.0
    common = len(os.path.commonprefix([sa, sb]))
    return 0.6 if common >= 8 else 0.0

def fuzzy(a, b) -> float:
    ta, tb = set(str(a).split()), set(str(b).split())
    if not ta or not tb: return 0.0
    overlap = len(ta & tb) / max(len(ta), len(tb))
    return overlap if overlap >= 0.6 else 0.0


def compare(a: FP, b: FP) -> dict:
    checks = [
        ("timezone_offset",   a.tz_offset,       b.tz_offset,       0.25, exact),
        ("real_ip",           a.real_ip,          b.real_ip,         0.22, exact),
        ("dkim_domain",       a.dkim_domain,      b.dkim_domain,     0.18, exact),
        ("from_domain",       a.from_domain,      b.from_domain,     0.15, exact),
        ("vpn_provider",      a.vpn_provider,     b.vpn_provider,    0.12, exact),
        ("webmail_provider",  a.webmail_provider, b.webmail_provider,0.10, exact),
        ("send_hour_bucket",  a.send_hour,        b.send_hour,       0.08, hour_bucket),
        ("mail_client",       a.mail_client,      b.mail_client,     0.07, prefix_match),
        ("vpn_asn",           a.vpn_asn,          b.vpn_asn,         0.06, exact),
        ("subject_pattern",   a.subject_pattern,  b.subject_pattern, 0.05, fuzzy),
        ("hop_count",         a.hop_count,        b.hop_count,       0.04, exact),
        ("send_day_type",     a.send_day,         b.send_day,        0.03, day_type),
    ]

    total_possible = total_matched = 0.0
    matched_signals = []

    for name, va, vb, weight, matcher in checks:
        if va is None or vb is None:
            continue
        total_possible += weight
        mv = matcher(va, vb)
        if mv > 0:
            contrib = weight * mv
            total_matched += contrib
            matched_signals.append((name, mv, contrib))

    score = total_matched / total_possible if total_possible > 0 else 0.0
    prob  = min(0.92, score)

    if prob >= THRESHOLD_SAME:   verdict = "SAME_ACTOR"
    elif prob >= THRESHOLD_LIKELY: verdict = "LIKELY_SAME"
    elif prob >= THRESHOLD_POSS:   verdict = "POSSIBLE"
    else:                           verdict = "DIFFERENT"

    return {
        "score": score, "prob": prob, "verdict": verdict,
        "matched": matched_signals, "total_possible": total_possible
    }


def run_test(name: str, a: FP, b: FP):
    r = compare(a, b)
    print(f"\n{'='*65}")
    print(f"TEST: {name}")
    print(f"{'='*65}")
    print(f"  Email A: {a.name}")
    print(f"  Email B: {b.name}")
    print(f"\n  Matched signals:")
    if r["matched"]:
        for sig, mv, contrib in sorted(r["matched"], key=lambda x: -x[2]):
            print(f"    {sig:<22} match={mv:.2f}  weight_contrib={contrib:.4f}")
    else:
        print("    (none matched)")
    print(f"\n  Total possible weight: {r['total_possible']:.4f}")
    print(f"  Total matched weight:  {sum(c for _,_,c in r['matched']):.4f}")
    print(f"  Similarity score:      {r['score']:.4f}")
    print(f"  Same-actor prob:       {r['prob']:.4f}")
    print(f"  Verdict:               {r['verdict']}")


# ════════════════════════════════════════════════════════════════
#  CASE 1: Identical attacker, different VPN exit IPs
#  Expected: SAME_ACTOR (high score because timezone/dkim/domain match)
# ════════════════════════════════════════════════════════════════
run_test(
    "Same attacker, rotated VPN — should be SAME_ACTOR",
    FP("email1.eml", tz_offset="+0530", dkim_domain="gmail.com",
       from_domain="acme-invoices.com", vpn_provider="NordVPN",
       webmail_provider="Gmail", send_hour=14, hop_count=3),
    FP("email2.eml", tz_offset="+0530", dkim_domain="gmail.com",
       from_domain="acme-invoices.com", vpn_provider="ExpressVPN",  # different VPN
       webmail_provider="Gmail", send_hour=15, hop_count=3),
)

# ════════════════════════════════════════════════════════════════
#  CASE 2: Same actor, completely different campaign template
#  Key: timezone + real_ip still match → SAME_ACTOR
# ════════════════════════════════════════════════════════════════
run_test(
    "Same actor, different subject/domain — real_ip leaks identity",
    FP("email3.eml", tz_offset="+0300", real_ip="91.108.4.55",
       from_domain="fakeinvoice.com", subject_pattern="invoice # from"),
    FP("email4.eml", tz_offset="+0300", real_ip="91.108.4.55",
       from_domain="secure-payment.net", subject_pattern="urgent security alert"),
)

# ════════════════════════════════════════════════════════════════
#  CASE 3: Genuinely different attackers — timezone both +0530 but different everything
# ════════════════════════════════════════════════════════════════
run_test(
    "Different attackers — same timezone (+0530) but nothing else matches",
    FP("email5.eml", tz_offset="+0530", dkim_domain="yahoo.co.in",
       from_domain="bank-alert.in", vpn_provider="NordVPN", send_hour=9),
    FP("email6.eml", tz_offset="+0530", dkim_domain="gmail.com",
       from_domain="invoice-corp.com", vpn_provider="Mullvad", send_hour=21),
)

# ════════════════════════════════════════════════════════════════
#  CASE 4: Sparse fingerprints — most signals missing
#  Shows how normalization handles missing data
# ════════════════════════════════════════════════════════════════
run_test(
    "Sparse fingerprints — only timezone and from_domain available",
    FP("email7.eml", tz_offset="+0200", from_domain="legit-corp.ro"),
    FP("email8.eml", tz_offset="+0200", from_domain="legit-corp.ro"),
)

# ════════════════════════════════════════════════════════════════
#  CASE 5: Hour bucket test — emails 14:00 and 15:00 same bucket
# ════════════════════════════════════════════════════════════════
run_test(
    "Hour bucket matching — 14:00 and 15:00 are in same 4h bucket (12–16)",
    FP("email9.eml",  tz_offset="+0530", send_hour=14, webmail_provider="Gmail"),
    FP("email10.eml", tz_offset="+0530", send_hour=15, webmail_provider="Gmail"),
)

# ════════════════════════════════════════════════════════════════
#  CASE 6: Hour bucket test — emails 11:00 and 14:00 DIFFERENT buckets
# ════════════════════════════════════════════════════════════════
run_test(
    "Hour bucket mismatch — 11:00 is bucket 2, 14:00 is bucket 3",
    FP("email11.eml", tz_offset="+0530", send_hour=11, webmail_provider="Gmail"),
    FP("email12.eml", tz_offset="+0530", send_hour=14, webmail_provider="Gmail"),
)

# ════════════════════════════════════════════════════════════════
#  SIGNAL WEIGHT CONTRIBUTION TABLE
# ════════════════════════════════════════════════════════════════
print(f"\n{'='*65}")
print("SIGNAL WEIGHT CONTRIBUTION TABLE")
print(f"{'='*65}")
print(f"  {'Signal':<25} {'Weight':>8}  {'% of total':>12}  {'Meaning'}")
print(f"  {'-'*60}")
total_w = sum(SIGNAL_WEIGHTS.values())
for sig, w in sorted(SIGNAL_WEIGHTS.items(), key=lambda x: -x[1]):
    pct = w / total_w * 100
    print(f"  {sig:<25} {w:>8.2f}  {pct:>11.1f}%")
print(f"  {'TOTAL':<25} {total_w:>8.2f}  {'100.0':>11}%")
print()
print("  NOTE: Missing signals are NOT penalized — total_possible is the")
print("  denominator, which only includes signals PRESENT in BOTH fingerprints.")
print("  Two emails sharing only timezone_offset (w=0.25) can still score")
print("  similarity = 0.25/0.25 = 1.00 if that's the only available signal.")