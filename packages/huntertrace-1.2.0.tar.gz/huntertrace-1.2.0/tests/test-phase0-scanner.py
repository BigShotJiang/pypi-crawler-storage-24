#!/usr/bin/env python3
"""
PHASE 0 FORENSIC SCANNER — ISOLATED TEST SUITE
================================================
All 8 detectors × all confirmed bugs × all accuracy gaps.

Confirmed bugs found:
  B1 CRASH  line 375  — f-string: 'sl_cv:.2f if sl_cv else n/a' crashes on float
  B2 SILENT line 371  — `if sl_cv else None` stores None when sl_cv=0.0
  B3 SILENT line 370  — `if avg_sl else None` same falsy-zero issue
  B4 EDGE   — BotScorer mean=0 guarded correctly (no crash)
  F1 WRONG  — HomoglyphDetector: NFKD can't map Cyrillic→ASCII for brand match
  F2 MISS   — _html_body: get_payload(decode=True) returns None when email parsed
               from str without Content-Transfer-Encoding header

Usage:
    python test_phase0_scanner.py                      # auto-finds scanner
    python test_phase0_scanner.py --scanner path/to/scanner.py
"""

import sys, re, math, json, time, random
import email as _email_lib
from pathlib import Path
from datetime import datetime, timezone, timedelta
import importlib.util

# ── locate scanner ─────────────────────────────────────────────────────────────
_explicit = None
for _i, _a in enumerate(sys.argv[1:]):
    if _a == "--scanner" and _i + 2 < len(sys.argv):
        _explicit = Path(sys.argv[_i + 2]); break

_ROOTS = [Path(__file__).parent, Path(__file__).parent.parent,
          Path("/mnt/project"), Path("/home/claude")]
_spath = None
if _explicit and _explicit.exists():
    _spath = _explicit
else:
    for _d in _ROOTS:
        for _n in ("scanner_fixed.py", "scanner.py"):
            if (_d / _n).exists():
                _spath = _d / _n; break
        if _spath: break

if not _spath:
    print("[ERROR] scanner.py not found.")
    print("  Run from HunterTrace root, or: --scanner /path/to/scanner.py")
    sys.exit(1)

IS_FIXED = "scanner_fixed" in _spath.name
sys.path.insert(0, str(_spath.parent))
_spec = importlib.util.spec_from_file_location("_sc", str(_spath))
_mod  = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)

run_forensic_scan           = _mod.run_forensic_scan
HopTimestampForgeryDetector = _mod.HopTimestampForgeryDetector
BotSendPatternScorer        = _mod.BotSendPatternScorer
AIContentDetector           = _mod.AIContentDetector
TrackingPixelDetector       = _mod.TrackingPixelDetector
HTMLSmugglingDetector       = _mod.HTMLSmugglingDetector
HomoglyphDomainDetector     = _mod.HomoglyphDomainDetector
ZeroPointFontDetector       = _mod.ZeroPointFontDetector

print(f"[scanner]  {_spath}  ({'FIXED' if IS_FIXED else 'ORIGINAL'})")

# ── harness ────────────────────────────────────────────────────────────────────
PASS = FAIL = 0

def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1; print(f"  PASS  {name}")
    else:
        FAIL += 1; print(f"  FAIL  {name}" + (f"  [{detail}]" if detail else ""))

def S(title):
    print(f"\n{'='*65}\n  {title}\n{'='*65}")

def parse(raw): return _email_lib.message_from_string(raw)
def parseb(raw): return _email_lib.message_from_bytes(raw)
def scan(raw, **kw): return run_forensic_scan(raw, **kw)

BASE = datetime(2026, 3, 17, 9, 0, 0, tzinfo=timezone.utc)

# ══════════════════════════════════════════════════════════════════════════════
S("BUG REGRESSIONS")
# ══════════════════════════════════════════════════════════════════════════════

# B1 — crash: f-string conditional inside format spec
_b1 = ("From: x@x.com\nDate: Mon,17 Mar 2026 10:00:00+0000\n"
       "Content-Type: text/plain\n\n"
       "The quick brown fox jumps over the lazy dog. A stitch in time saves nine "
       "people. Every cloud has a silver lining somewhere. Better late than never "
       "they always say. The early bird always catches the worm each morning here.")
_ok = False
try:
    r = scan(_b1)
    _ok = r.ai_content.detail is not None and "SL_CV=" in r.ai_content.detail
except (ValueError, TypeError):
    pass
check("B1 — f-string conditional format spec crash fixed", _ok,
      "ValueError: Invalid format specifier '.2f if sl_cv else n/a'")

# B2 — silent: sl_cv=0.0 stored as None
_b2 = ("From: x@x.com\nDate: Mon,17 Mar 2026 10:00:00+0000\n"
       "Content-Type: text/plain\n\n"
       "Click here now please do it. Verify your account here now. Confirm details here. "
       "Update your password now here. Complete your profile here now. Submit your form now. "
       "Review your account here. Activate your card now. Access your funds here please.")
try:
    r2 = scan(_b2); _ok2 = r2.ai_content.detail is not None
except Exception: _ok2 = False
check("B2 — sl_cv=0.0 falsy guard fixed (is not None)", _ok2)

# B3 — silent: avg_sl=0.0 same issue
_b3 = ("From: x@x.com\nContent-Type: text/plain\n\n"
       "One. Two. Three. Four. Five. Six. Seven. Eight. Nine. Ten. Eleven. Twelve. "
       "Thirteen. Fourteen. Fifteen. Sixteen. Seventeen. Eighteen. Nineteen. Twenty. "
       "Twenty-one. Twenty-two. Twenty-three. Twenty-four. Twenty-five. Twenty-six.")
try:
    r3 = scan(_b3); _ok3 = r3.ai_content.detail is not None
except Exception: _ok3 = False
check("B3 — avg_sl=0.0 falsy guard fixed (is not None)", _ok3)

# B4 — edge: identical timestamps mean=0
_ids = [BASE] * 5
try:
    r4 = BotSendPatternScorer().score_campaign(_ids)
    _ok4 = r4.cv == 0.0
except ZeroDivisionError: _ok4 = False
check("B4 — identical timestamps (mean=0) guarded, no ZeroDivisionError", _ok4)

# F1 — wrong: Cyrillic lookalike brand detection (NFKD can't map Cyrillic→ASCII)
_f1 = parse("From: security@p\u0430ypal.com\n\n")
r_f1 = HomoglyphDomainDetector().detect(_f1)
check("F1 — Cyrillic а in domain → target_brand='paypal.com' detected",
      any(sd.get("target_brand") == "paypal.com" for sd in r_f1.suspect_domains),
      f"domains={r_f1.suspect_domains}")

# F2 — miss: get_payload(decode=True) returns None without CTE
# Solution: construct with explicit CTE so decode=True works
_f2_raw = (b"From: x@x.com\nContent-Type: text/html\n"
           b"Content-Transfer-Encoding: 8bit\n\n"
           b"<a href=\"https://micros\xd0\xbfft.com/verify\">Click</a>")
_f2 = parseb(_f2_raw)
r_f2 = HomoglyphDomainDetector().detect(_f2)
check("F2 — homoglyph in href (bytes+8bit CTE) → found=True",
      r_f2.found, f"suspect_domains={r_f2.suspect_domains}")


# ══════════════════════════════════════════════════════════════════════════════
S("DETECTOR 1 — HopTimestampForgeryDetector")
# ══════════════════════════════════════════════════════════════════════════════
d1 = HopTimestampForgeryDetector()

# clean 3-hop
_c = parse("From: x@x.com\n"
    "Received: from c ([1.2.3.4]) by d; Mon, 17 Mar 2026 14:00:10 +0000\n"
    "Received: from b ([5.6.7.8]) by c; Mon, 17 Mar 2026 14:00:05 +0000\n"
    "Received: from a ([9.10.11.12]) by b; Mon, 17 Mar 2026 14:00:00 +0000\n")
rc = d1.detect(_c)
check("D1 clean 3-hop → CLEAN, score=0, hops_parsed=3",
      rc.verdict == "CLEAN" and rc.forgery_score == 0.0 and rc.hops_parsed == 3,
      f"v={rc.verdict} s={rc.forgery_score} p={rc.hops_parsed}")

# timestamp regression
_reg = parse("From: x@x.com\n"
    "Received: from c ([1.2.3.4]) by d; Mon, 17 Mar 2026 14:00:00 +0000\n"
    "Received: from b ([5.6.7.8]) by c; Mon, 17 Mar 2026 14:05:00 +0000\n"
    "Received: from a ([9.10.11.12]) by b; Mon, 17 Mar 2026 13:45:00 +0000\n")
rr = d1.detect(_reg)
check("D1 timestamp regression → SUSPICIOUS/FORGED, regressions populated",
      rr.verdict in ("SUSPICIOUS","FORGED") and len(rr.regressions) > 0,
      f"v={rr.verdict} reg={rr.regressions}")

# zero-second transit
_z = parse("From: x@x.com\n"
    "Received: from b ([1.2.3.4]) by c; Mon, 17 Mar 2026 14:00:00 +0000\n"
    "Received: from a ([5.6.7.8]) by b; Mon, 17 Mar 2026 14:00:00 +0000\n")
rz = d1.detect(_z)
check("D1 zero-second transit → anomaly detected",
      any("zero-second" in a for a in rz.anomalies))

# no Received headers
rn = d1.detect(parse("From: x@x.com\n\nBody"))
check("D1 no Received → hop_count=0, CLEAN",
      rn.hop_count == 0 and rn.verdict == "CLEAN")

# private IP mid-chain
_prv = parse("From: x@x.com\n"
    "Received: from c ([1.2.3.4]) by d; Mon, 17 Mar 2026 14:00:10 +0000\n"
    "Received: from internal ([192.168.1.10]) by c; Mon, 17 Mar 2026 14:00:05 +0000\n"
    "Received: from a ([9.10.11.12]) by internal; Mon, 17 Mar 2026 14:00:00 +0000\n")
rp = d1.detect(_prv)
check("D1 private IP mid-chain → anomaly detected",
      any("private IP" in a for a in rp.anomalies))

# malformed date — no crash
_bad = parse("From: x@x.com\n"
    "Received: from b ([1.2.3.4]) by c; GARBAGE DATE\n"
    "Received: from a ([5.6.7.8]) by b; Mon, 17 Mar 2026 14:00:00 +0000\n")
try: d1.detect(_bad); _bok = True
except Exception: _bok = False
check("D1 malformed Received timestamp → no crash", _bok)

# RFC 2822 date with trailing (IST) comment
_ist = parse("From: x@x.com\n"
    "Received: from b ([1.2.3.4]) by c; Tue, 18 Mar 2026 19:51:57 +0530 (IST)\n"
    "Received: from a ([5.6.7.8]) by b; Tue, 18 Mar 2026 19:51:50 +0530 (IST)\n")
try:
    rist = d1.detect(_ist)
    _ist_ok = rist.hops_parsed >= 1
except Exception: _ist_ok = False
check("D1 RFC 2822 date with (IST) comment → parsed correctly", _ist_ok,
      f"hops_parsed={getattr(rist, 'hops_parsed', '?')}")

# excess hops
_eh = "From: x@x.com\n"
for i in range(10):
    _t = (BASE + timedelta(seconds=i*5)).strftime("%a, %d %b %Y %H:%M:%S %z")
    _eh += f"Received: from h{i} ([1.2.3.{i+1}]) by h{i+1}; {_t}\n"
rem = d1.detect(parse(_eh))
check("D1 excess hops (10) → anomaly flagged",
      any("hop count" in a.lower() or "Excess" in a for a in rem.anomalies))


# ══════════════════════════════════════════════════════════════════════════════
S("DETECTOR 2 — BotSendPatternScorer")
# ══════════════════════════════════════════════════════════════════════════════
d2 = BotSendPatternScorer()

# robotic 10-min intervals
_bot = [BASE + timedelta(minutes=10*i) for i in range(12)]
rb = d2.score_campaign(_bot)
check("D2 robot 10-min intervals → bot, CV<0.10",
      rb.verdict == "bot" and rb.cv is not None and rb.cv < 0.10,
      f"v={rb.verdict} cv={rb.cv}")

# human random
random.seed(42)
_hum = sorted(BASE + timedelta(seconds=random.randint(300,7200)*i) for i in range(1,10))
rh = d2.score_campaign(_hum)
check("D2 human random → human or scripted_human",
      rh.verdict in ("human","scripted_human"), f"v={rh.verdict} cv={rh.cv}")

# overnight → T1583
_ngt = [datetime(2026,3,17,h,0,0,tzinfo=timezone.utc) for h in [1,2,3,4,14,15,16]]
rn2 = d2.score_campaign(_ngt)
check("D2 >50% overnight → T1583 in mitre", "T1583" in rn2.mitre)

# burst
_bst = [BASE + timedelta(seconds=s) for s in [0,5,10,15,3600]]
rb2 = d2.score_campaign(_bst)
check("D2 burst <60s → burst_count>=3", rb2.burst_count >= 3)

# single email — insufficient by design
_sm = parse("From: x@x.com\nDate: Mon, 17 Mar 2026 11:30:00 +0000\n")
rs = d2.score_single(_sm)
check("D2 single email biz hours → is_business_hours=True, insufficient_data",
      rs.is_business_hours and rs.verdict == "insufficient_data")

# one timestamp
check("D2 one timestamp → insufficient_data",
      d2.score_campaign([BASE]).verdict == "insufficient_data")

# malformed Date
try:
    rbad2 = d2.score_single(parse("From: x@x.com\nDate: NOT A DATE\n"))
    _db_ok = rbad2.send_hour is None
except Exception: _db_ok = False
check("D2 malformed Date → no crash, send_hour=None", _db_ok)


# ══════════════════════════════════════════════════════════════════════════════
S("DETECTOR 3 — AIContentDetector")
# ══════════════════════════════════════════════════════════════════════════════
d3 = AIContentDetector()

# AI-like body (uniform sentences, low TTR)
_ai_body = ("Your account has been flagged for unusual activity and requires verification. "
            "Please verify your account information to restore normal access to services. "
            "Your account will be suspended if you do not verify your details promptly. "
            "Click the secure link provided to verify your account credentials now. "
            "The verification link will expire within twenty four hours of this message. "
            "Please complete the account verification process immediately without delay. "
            "Thank you for your cooperation with this important security process today.")
r3ai = d3.detect(parse(f"From: x@x.com\nContent-Type: text/plain\n\n{_ai_body}"))
check("D3 AI-like text → detail has SL_CV= and TTR= (B1 fix confirmed)",
      r3ai.detail is not None and "SL_CV=" in r3ai.detail and "TTR=" in r3ai.detail,
      f"detail={r3ai.detail}")

# human text
_hum_body = ("Hey! Noticed the Q3 report had discrepancies in vendor reconciliation — "
             "March figures don't match what Sarah sent Tuesday. Worth a quick chat? "
             "Also did you catch the match last night? Absolute wild finish. Let me know "
             "when you're free — Thursday afternoon could work if that suits.")
r3h = d3.detect(parse(f"From: x@x.com\nContent-Type: text/plain\n\n{_hum_body}"))
check("D3 human text → human_likely",
      r3h.verdict == "human_likely", f"v={r3h.verdict} p={r3h.ai_probability}")

# short text < 30 tokens
check("D3 short (<30 tokens) → insufficient_text",
      d3.detect(parse("From: x@x.com\nContent-Type: text/plain\n\nClick here now.")).verdict
      == "insufficient_text")

# exactly 30 tokens (boundary)
r3_30 = d3.detect(parse("From: x@x.com\nContent-Type: text/plain\n\n" + "word " * 30))
check("D3 exactly 30 tokens → not insufficient_text",
      r3_30.verdict != "insufficient_text", f"v={r3_30.verdict}")

# HTML-only fallback
_ho = parse("From: x@x.com\nContent-Type: text/html\n\n"
    "<html><body><p>Please verify your account by clicking the link. Your account "
    "access will be restricted unless you complete this verification step today. "
    "The process takes only a moment and ensures the security of your account "
    "information and credentials. Please click the button below to proceed now.</p></body></html>")
r3html = d3.detect(_ho)
check("D3 HTML-only → fallback runs, no crash",
      r3html.verdict in ("ai_likely","human_likely","insufficient_text"))

# empty body
check("D3 empty body → insufficient_text",
      d3.detect(parse("From: x@x.com\n\n")).verdict == "insufficient_text")


# ══════════════════════════════════════════════════════════════════════════════
S("DETECTOR 4 — TrackingPixelDetector")
# ══════════════════════════════════════════════════════════════════════════════
d4 = TrackingPixelDetector()

r4p = d4.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
    '<img src="https://track.mailchimp.com/open/v1/abc" width="1" height="1"><p>Hi</p>'))
check("D4 1×1 pixel → found, pixel_count>=1, TRACKING/BEACON",
      r4p.found and r4p.pixel_count >= 1 and r4p.verdict in ("TRACKING","BEACON"))

r4h = d4.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
    '<img src="https://beacon.evil.com/t.gif" style="display:none"><p>Hi</p>'))
check("D4 display:none → found, hidden_img_count>=1",
      r4h.found and r4h.hidden_img_count >= 1)

r4t = d4.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
    '<a href="https://click.sendgrid.net/ls/click?upn=abc">Click</a>'))
check("D4 sendgrid click domain → suspicious_domain detected",
      len(r4t.suspicious_domains) > 0)

r4c = d4.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
    '<img src="https://static.co.com/logo.png" width="200" height="80">'))
check("D4 clean logo image (200×80) → CLEAN", r4c.verdict == "CLEAN")

check("D4 no HTML → CLEAN",
      d4.detect(parse("From: x@x.com\nContent-Type: text/plain\n\nText")).verdict == "CLEAN")


# ══════════════════════════════════════════════════════════════════════════════
S("DETECTOR 5 — HTMLSmugglingDetector")
# ══════════════════════════════════════════════════════════════════════════════
d5 = HTMLSmugglingDetector()

r5b = d5.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
    "<script>var b=new Blob(['evil']);var u=URL.createObjectURL(b);</script>"))
check("D5 createObjectURL → found, SMUGGLING/SUSPICIOUS",
      r5b.found and r5b.verdict in ("SMUGGLING","SUSPICIOUS"))

check("D5 atob() → found",
      d5.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
      "<script>document.write(atob('PHNjcmlwdD4='));</script>")).found)

check("D5 eval(variable) → found",
      d5.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
      "<script>var x=decodeURI('x');eval(x);</script>")).found)

check("D5 fromCharCode → found",
      d5.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
      "<script>String.fromCharCode(60,115);</script>")).found)

r5c = d5.detect(parse("From: x@x.com\nContent-Type: text/html\n\n<p>Invoice attached.</p>"))
check("D5 clean HTML → CLEAN, risk=0",
      r5c.verdict == "CLEAN" and r5c.risk_score == 0.0)

check("D5 no HTML → CLEAN",
      d5.detect(parse("From: x@x.com\nContent-Type: text/plain\n\nText")).verdict == "CLEAN")


# ══════════════════════════════════════════════════════════════════════════════
S("DETECTOR 6 — HomoglyphDomainDetector")
# ══════════════════════════════════════════════════════════════════════════════
d6 = HomoglyphDomainDetector()

# Cyrillic а in From domain
r6c = d6.detect(parse("From: security@p\u0430ypal.com\n\n"))
check("D6 Cyrillic а → found=True, HOMOGLYPH",
      r6c.found and r6c.verdict == "HOMOGLYPH")
check("D6 Cyrillic а → target_brand='paypal.com' (F1 fix)",
      any(sd.get("target_brand") == "paypal.com" for sd in r6c.suspect_domains),
      f"domains={r6c.suspect_domains}")

# Homoglyph in href via bytes+CTE (F2 fix)
_f2b = (b"From: x@x.com\nContent-Type: text/html\nContent-Transfer-Encoding: 8bit\n\n"
        b"<a href=\"https://micros\xd0\xbfft.com/verify\">Click</a>")
r6h = d6.detect(parseb(_f2b))
check("D6 Cyrillic п in href (bytes+CTE) → found=True (F2 fix)",
      r6h.found, f"domains={r6h.suspect_domains}")

# Reply-To header
r6rt = d6.detect(parse("From: x@x.com\nReply-To: reply@p\u0430ypal.com\n\n"))
check("D6 homoglyph in Reply-To → detected", r6rt.found)

# Clean ASCII domain
check("D6 clean ASCII domain → CLEAN",
      d6.detect(parse("From: legit@company.com\n\n")).verdict == "CLEAN")

# Missing From
try: d6.detect(parse("To: y@y.com\n\n")); _nf = True
except Exception: _nf = False
check("D6 missing From header → no crash", _nf)


# ══════════════════════════════════════════════════════════════════════════════
S("DETECTOR 7 — ZeroPointFontDetector")
# ══════════════════════════════════════════════════════════════════════════════
d7 = ZeroPointFontDetector()

r7z = d7.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
    '<span style="font-size:0px">hidden injection</span><p>Real</p>'))
check("D7 font-size:0px → HIDDEN_TEXT, zero_font_count>=1",
      r7z.verdict == "HIDDEN_TEXT" and r7z.zero_font_count >= 1)

r7d = d7.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
    '<div style="display:none">Bypass content</div><p>Invoice</p>'))
check("D7 display:none div → found, hidden_text_count>=1",
      r7d.found and r7d.hidden_text_count >= 1)

r7w = d7.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
    '<span style="color:white">keyword stuffing</span><p>Click</p>'))
check("D7 white-on-white → found, white_on_white>=1",
      r7w.found and r7w.white_on_white >= 1)

r7pt = d7.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
    '<p style="font-size:0pt">hidden</p><p>Visible</p>'))
check("D7 font-size:0pt → found", r7pt.found)

r7c = d7.detect(parse("From: x@x.com\nContent-Type: text/html\n\n"
    '<p style="font-size:14px; color:#333">Hello, see your invoice.</p>'))
check("D7 font-size:14px → CLEAN (must NOT trigger)",
      r7c.verdict == "CLEAN", f"zf={r7c.zero_font_count} ht={r7c.hidden_text_count}")

check("D7 no HTML → CLEAN",
      d7.detect(parse("From: x@x.com\nContent-Type: text/plain\n\nText")).verdict == "CLEAN")


# ══════════════════════════════════════════════════════════════════════════════
S("DETECTOR 8 — ForensicScanSummary (composite)")
# ══════════════════════════════════════════════════════════════════════════════

# High-risk phish: timestamp regression + homoglyph + pixel + hidden text + smuggling
_phish = """\
From: security@p\u0430ypal.com
To: victim@corp.com
Subject: URGENT: Account Limited
Date: Mon, 17 Mar 2026 03:14:00 +0000
Content-Type: text/html; charset=utf-8
Received: from evil.net ([91.108.4.55]) by mx.corp.com; Mon, 17 Mar 2026 14:05:00 +0000
Received: from evil.com ([91.108.4.1]) by evil.net; Mon, 17 Mar 2026 13:45:00 +0000

<html><body>
<span style="font-size:0px">legitimate bank notice</span>
<img src="https://track.evil.com/open" width="1" height="1">
<p>Your p\u0430ypal account is limited.</p>
<script>var b=new Blob(['x']);var u=URL.createObjectURL(b);</script>
</body></html>
"""
rf = scan(_phish)
check("COMPOSITE full phish → HIGH or CRITICAL",
      rf.risk_label in ("HIGH","CRITICAL"),
      f"label={rf.risk_label} score={rf.risk_score}")
check("COMPOSITE full phish → flags non-empty, MITRE present",
      len(rf.flags) > 0 and len(rf.all_mitre) > 0)
check("COMPOSITE full phish → to_dict() JSON-serialisable",
      bool(json.dumps(rf.to_dict())))
check("COMPOSITE full phish → report() non-empty",
      len(rf.report()) > 50)

# Clean email
_legit = """\
From: hr@company.com
To: employee@company.com
Subject: Q1 2026 Performance Review
Date: Mon, 17 Mar 2026 11:30:00 +0000
Content-Type: text/plain; charset=utf-8
Received: from smtp.company.com ([203.0.113.5]) by mx.company.com; Mon, 17 Mar 2026 11:30:05 +0000
Received: from mail.company.com ([203.0.113.4]) by smtp.company.com; Mon, 17 Mar 2026 11:30:00 +0000

Hi Sarah,

I wanted to reach out about scheduling your Q1 performance review. We typically
hold these during the last week of the quarter, so I was hoping we could find a
slot that works for both of us. The review covers project contributions, teamwork,
and professional development goals. It takes about 45 minutes. Could you let me
know your availability for next Thursday or Friday afternoon?

Best regards, James
"""
rc2 = scan(_legit)
check("COMPOSITE clean email → LOW or MEDIUM",
      rc2.risk_label in ("LOW","MEDIUM"),
      f"label={rc2.risk_label} score={rc2.risk_score}")
check("COMPOSITE clean email → to_dict() serialisable", bool(json.dumps(rc2.to_dict())))

# Bot timestamps
_bts = [BASE + timedelta(minutes=10*i) for i in range(8)]
rb3 = scan(_legit, send_timestamps=_bts)
check("COMPOSITE bot timestamps → send_pattern.verdict=bot",
      rb3.send_pattern.verdict == "bot", f"v={rb3.send_pattern.verdict}")

# Edge: empty string
check("COMPOSITE empty string → no crash", scan("") is not None)


# ══════════════════════════════════════════════════════════════════════════════
S("REAL-WORLD ACCURACY SCENARIOS")
# ══════════════════════════════════════════════════════════════════════════════

# Nigerian BEC — plain text social engineering
_bec = """\
From: "James Cole CFO" <james.cole.cfo2024@gmail.com>
To: accounts@targetcorp.com
Subject: Urgent: Change of Bank Account Details
Date: Mon, 17 Mar 2026 10:42:33 +0100
Content-Type: text/plain; charset=UTF-8
Received: from mail-wm1-f42.google.com ([209.85.128.42]) by mx.targetcorp.com; Mon, 17 Mar 2026 09:42:41 +0000
Received: from [185.130.44.108] (nordvpn-nl-exit.nordvpn.com) by smtp.gmail.com; Mon, 17 Mar 2026 01:42:38 -0800

Dear Accounts Team,

I hope this message finds you well. I am writing to inform you that our company
bank account details have changed effective immediately. Please update your records
and ensure all pending payments are directed to our new banking details below.
We have an urgent payment of four hundred and eighty five thousand dollars due
this Friday. Please ensure this is processed before end of business Thursday.
This change is CONFIDENTIAL. Do not discuss with anyone outside the finance team.

Best regards, James Cole CFO
"""
r_bec = scan(_bec)
check("BEC Nigerian: AI detector runs without B1 crash (TTR= in detail)",
      r_bec.ai_content.detail is not None and "TTR=" in r_bec.ai_content.detail)
check("BEC Nigerian: risk LOW (plain text, no HTML exploits)",
      r_bec.risk_label in ("LOW","MEDIUM"),
      f"label={r_bec.risk_label} flags={r_bec.flags}")

# M365 phish — homoglyph + tracking pixel (no JS smuggling)
_m365 = """\
From: "Microsoft Security" <no-reply@micros\u043fft-security.com>
To: user@corp.com
Subject: Change Your Microsoft 365 Password Immediately
Date: Wed, 19 Mar 2026 09:15:00 +0000
Content-Type: text/html; charset=utf-8
Received: from phish.ru ([185.220.101.47]) by mx.corp.com; Wed, 19 Mar 2026 09:15:30 +0000
Received: from phish.ru ([185.220.101.47]) by phish.ru; Wed, 19 Mar 2026 09:15:00 +0000

<html><body>
<img src="https://open.pixel-tracker.net/t?id=abc" width="1" height="1" style="display:none">
<h2>Your Microsoft 365 password is expiring</h2>
<p>Update immediately to maintain access.</p>
<a href="https://micros\u043fft-365-verify.com/reset">Update Password Now</a>
</body></html>
"""
r_m365 = scan(_m365)
check("M365 phish: homoglyph From domain detected", r_m365.homoglyph.found)
check("M365 phish: tracking pixel detected",        r_m365.tracking_pixel.found)
# Composite score = homoglyph(0.20) + pixel(0.10) = 0.30 → MEDIUM is correct
# HIGH requires JS smuggling (0.30 weight) in addition
check("M365 phish: risk MEDIUM or above (0.30 with no JS smuggling)",
      r_m365.risk_label in ("MEDIUM","HIGH","CRITICAL"),
      f"label={r_m365.risk_label} score={r_m365.risk_score}")

# Multipart email
_mp = """\
From: x@x.com
Subject: Multipart
Content-Type: multipart/alternative; boundary="b123"

--b123
Content-Type: text/plain

Please verify your account.

--b123
Content-Type: text/html

<img src="https://track.mailchimp.com/open" width="1" height="1"><p>Verify.</p>

--b123--
"""
r_mp = scan(_mp)
check("Multipart: processes without crash", r_mp is not None)
check("Multipart: tracking pixel from HTML part detected", r_mp.tracking_pixel.found)


# ══════════════════════════════════════════════════════════════════════════════
S("EDGE CASES")
# ══════════════════════════════════════════════════════════════════════════════

# RFC 2047 encoded subject
_ec = parse("From: x@x.com\n"
    "Subject: =?windows-1251?B?0KLQtdGB0YLQvtCy0LDRjyDQv9C+0YfRgtCw?=\n"
    "Content-Type: text/plain\n\n" + "word " * 35)
try: d3.detect(_ec); _ec_ok = True
except Exception: _ec_ok = False
check("Edge: RFC 2047 encoded Subject → no crash", _ec_ok)

# Large HTML — 2000 paragraphs — no crash and < 5s
_lg = parse("From: x@x.com\nContent-Type: text/html\n\n<html><body>"
            + "<p>Content paragraph here.</p>" * 2000 + "</body></html>")
_t0 = time.time()
try:
    d4.detect(_lg); d5.detect(_lg); d7.detect(_lg)
    _lg_ok = True; _lg_t = time.time() - _t0
except Exception: _lg_ok = False; _lg_t = 0
check("Edge: 2000-paragraph HTML → all detectors complete without crash", _lg_ok)
check(f"Edge: 2000-paragraph HTML → completes <5s (took {_lg_t:.2f}s)", _lg_t < 5.0)

# Headerless string
check("Edge: headerless string → no crash", scan("just raw text no headers") is not None)

# Latin-1 encoded body
_lat = parse("From: x@x.com\nContent-Type: text/plain; charset=iso-8859-1\n\n"
    "Voici le contenu en fran\xe7ais avec des caract\xe8res sp\xe9ciaux pour tester.")
try: d3.detect(_lat); _lat_ok = True
except Exception: _lat_ok = False
check("Edge: latin-1 body → no crash in AI detector", _lat_ok)

# Legitimate Unicode domain (must not be flagged)
try:
    r_ud = d6.detect(parse("From: user@m\xfcnchen.de\n\n"))
    _ud_ok = True
except Exception: _ud_ok = False
check("Edge: legitimate Unicode domain münchen.de → no crash", _ud_ok)


# ══════════════════════════════════════════════════════════════════════════════
S("ACCURACY GAPS (not crashes — awareness items)")
# ══════════════════════════════════════════════════════════════════════════════
print("""
  A1  Short phishing emails (<30 tokens) → always 'insufficient_text' in AI
      detector. Most BEC one-liners skip AI scoring entirely.
      Consider lowering the minimum threshold to 15 tokens.

  A2  Single-email bot scoring → always 'insufficient_data'. Correct by design
      but Phase 0 output should suppress this warning unless >1 emails fed in.

  A3  Hop forgery: single-hop emails always score 0.0 (nothing to compare).
      Direct MX injection = 1 hop. Consider flagging hop_count=1 on external
      email as a low-confidence anomaly ("unusually short chain").

  A4  TrackingPixelDetector misses CSS background-image beacons:
        style="background:url(https://tracker.com/t.gif)"
      Add a CSS url() scan to TrackingPixelDetector._TRACKER_KW matching.

  A5  HopTimestampForgeryDetector._parse_ts() strips trailing (TZ) comments
      via `re.sub(r'\\s*\\([^)]*\\)\\s*$', '', ...)`. This handles single-paren
      comments but fails on nested parens or multi-word TZ names like
      "(Eastern Standard Time)". Add a fallback strip loop.

  A6  Composite risk weights: homoglyph and HTML smuggling carry the most
      weight (0.20 and 0.30). A zero-font-only email scores only 0.10 even
      with 50+ hidden text nodes. Consider raising zero_font weight to 0.15.
""")


# ══════════════════════════════════════════════════════════════════════════════
total = PASS + FAIL
print(f"{'='*65}")
print(f"  RESULTS: {PASS}/{total} passed,  {FAIL} failed")
print(f"  Scanner: {'FIXED (scanner_fixed.py)' if IS_FIXED else 'ORIGINAL (bugs present)'}")
print("="*65)
if FAIL == 0:
    print("  ALL GREEN ✓")
else:
    print(f"  {FAIL} test(s) FAILED — see FAIL lines above")

if not IS_FIXED:
    print("""
  Apply this 3-line fix in AIContentDetector.detect() (~line 367):

    # BROKEN:
    avg_sentence_len = round(avg_sl, 1) if avg_sl else None,
    sentence_len_cv  = round(sl_cv, 3) if sl_cv else None,
    detail = f"...SL_CV={sl_cv:.2f if sl_cv else 'n/a'}..."

    # FIXED:
    _sl_cv_str       = f"{sl_cv:.2f}" if sl_cv is not None else "n/a"
    avg_sentence_len = round(avg_sl, 1) if avg_sl is not None else None,
    sentence_len_cv  = round(sl_cv, 3) if sl_cv is not None else None,
    detail           = f"...SL_CV={_sl_cv_str}..."
""")