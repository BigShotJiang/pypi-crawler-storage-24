"""
CLARA Explainer — Design Specification
========================================

Rule-based, template-driven explanation generator.
Reads SolveState → produces human-readable reports.

NO LLM dependency. All text is deterministically generated from SolveState fields.

Design principles:
    1. Every sentence maps to exactly one SolveState field (traceable)
    2. XAIOR AA mapping is explicit: each report targets one AA level
    3. Two detail levels: brief (summary) vs detailed (full analysis)
    4. Two output formats: plain text (CLI default) vs JSON (programmatic)
    5. English only for MVP (i18n-ready structure for future extension)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional


# ============================================================
# 1. Public API
# ============================================================

API = """
# Module: clara/explain/explainer.py

class Explainer:
    def explain(
        self,
        state: SolveState,
        level: DetailLevel = DetailLevel.DETAILED,
    ) -> ExplanationReport:
        '''Generate a complete explanation report from a SolveState.

        Args:
            state: Immutable solver state snapshot.
            level: BRIEF or DETAILED.

        Returns:
            ExplanationReport containing all three sub-reports.
        '''

# Module: clara/explain/__init__.py
from clara.explain.explainer import Explainer, ExplanationReport, DetailLevel

# Usage:
    explainer = Explainer()
    report = explainer.explain(state, level=DetailLevel.BRIEF)
    print(report.to_text())     # plain text
    print(report.to_json())     # JSON
    print(report.binding)       # individual sub-report
"""


# ============================================================
# 2. Output Data Structures
# ============================================================

class DetailLevel(Enum):
    BRIEF = auto()      # one-paragraph summary per section
    DETAILED = auto()   # full per-item analysis


@dataclass
class BindingReport:
    """XAIOR AA: Understandability — 'What is the solution structure?'

    Answers: Which constraints are active? Which resources are fully used?
    """
    binding: list[BindingItem]
    nonbinding: list[NonBindingItem]
    summary: str                      # always present (brief mode = summary only)

    def to_text(self, level: DetailLevel) -> str: ...
    def to_dict(self) -> dict: ...


@dataclass
class BindingItem:
    name: str
    rhs: float
    dual_value: float
    rank: int               # 1 = highest shadow price


@dataclass
class NonBindingItem:
    name: str
    rhs: float
    slack: float
    utilization_pct: float  # (rhs - slack) / rhs * 100


@dataclass
class VariableReport:
    """XAIOR AA: Justifiability — 'Why is each variable at this value?'

    Answers: Why is x3 being produced? Why is x4 = 0?
    """
    basic: list[BasicVarItem]
    nonbasic: list[NonBasicVarItem]
    summary: str

    def to_text(self, level: DetailLevel) -> str: ...
    def to_dict(self) -> dict: ...


@dataclass
class BasicVarItem:
    name: str
    value: float
    contribution: float     # value * obj_coeff
    contribution_pct: float # contribution / optimal_value * 100


@dataclass
class NonBasicVarItem:
    name: str
    value: float            # typically 0 or at bound
    reduced_cost: float
    # "x4 needs its profit to increase by 2.30 before it enters production"


@dataclass
class SensitivityReport:
    """XAIOR AA: Actionability — 'What can I change without breaking the solution?'

    Answers: How much can I change a price/capacity before the solution structure changes?
    """
    obj_items: list[ObjSensItem]
    rhs_items: list[RhsSensItem]
    bottleneck: Optional[str]   # constraint with highest shadow price
    most_robust: Optional[str]  # variable with widest obj coeff range
    summary: str

    def to_text(self, level: DetailLevel) -> str: ...
    def to_dict(self) -> dict: ...


@dataclass
class ObjSensItem:
    name: str
    current: float
    lower: float
    upper: float
    range_width: float      # upper - lower
    pct_decrease: float     # (current - lower) / current * 100
    pct_increase: float     # (upper - current) / current * 100


@dataclass
class RhsSensItem:
    name: str
    current: float
    lower: float
    upper: float
    dual_value: float
    is_binding: bool
    range_width: float


@dataclass
class ExplanationReport:
    """Complete explanation report combining all three sub-reports."""
    binding: BindingReport
    variable: VariableReport
    sensitivity: SensitivityReport
    header: str                 # problem name + optimal value + solve stats

    def to_text(self, level: DetailLevel = DetailLevel.DETAILED) -> str:
        '''Full text report for CLI output.'''
        ...

    def to_dict(self) -> dict:
        '''JSON-serializable dict.'''
        ...

    def to_json(self, indent: int = 2) -> str:
        '''JSON string.'''
        ...


# ============================================================
# 3. Text Templates
# ============================================================

TEMPLATES = """

================================================================
HEADER (always shown)
================================================================

--- BRIEF ---
CLARA — {problem_name}
Optimal value: {optimal_value:.4f} ({status})
Solved in {iterations} iterations, {time:.3f}s ({engine})

--- DETAILED ---
(same as brief — header doesn't change)


================================================================
BINDING REPORT — Understandability
================================================================

--- BRIEF ---
{n_binding} of {n_total} constraints are binding.
{bottleneck_name} is the tightest bottleneck (shadow price {dual:.2f}).
{nonbinding_name} has {slack:.1f} units of unused capacity ({util_pct:.0f}% utilized).

--- DETAILED ---
Binding constraints ({n_binding} of {n_total}):

  {rank}. {name} (RHS = {rhs}): Fully utilized.
     Shadow price: {dual:.4f}
     → Each additional unit of {name} capacity increases objective by {dual:.4f}.
     [Repeat for each binding constraint, ranked by shadow price descending]

Non-binding constraints ({n_nonbinding} of {n_total}):

  {name} (RHS = {rhs}): Slack = {slack:.2f}
     → {util_pct:.0f}% utilized. Has {slack:.2f} units of unused capacity.
     [Repeat for each non-binding constraint]

Generation rules:
  - Binding: sorted by shadow price descending (rank 1 = most valuable)
  - Non-binding: sorted by utilization % descending (closest to binding first)
  - Shadow price sign: for <= constraints, positive dual means "increase RHS → improve obj"
  - If ALL constraints binding: "All constraints are binding — the solution is fully constrained."
  - If NO constraints binding: "No constraints are binding — check if the problem is unbounded."


================================================================
VARIABLE REPORT — Justifiability
================================================================

--- BRIEF ---
{n_basic} of {n_vars} variables are in the solution.
{top_contributor} contributes {contrib_pct:.0f}% of the objective.
{n_nonbasic} variables are not produced (at lower bound).

--- DETAILED ---
Variables in solution ({n_basic} of {n_vars}):

  {name} = {value:.4f} (profit = {obj_coeff})
     Contribution: {contribution:.4f} ({contrib_pct:.1f}% of objective)
     [Repeat for each basic variable, sorted by contribution descending]

Variables not in solution ({n_nonbasic} of {n_vars}):

  {name} = {value:.4f}
     Reduced cost: {rc:.4f}
     → {name}'s profit must increase by {abs(rc):.4f} (from {obj_coeff} to {obj_coeff + abs(rc):.4f}) before it enters the solution.
     [Repeat for each non-basic variable]

  [If value > 0 but at upper bound:]
  {name} = {value:.4f} (at upper bound)
     Reduced cost: {rc:.4f}
     → {name} is capped at its upper bound. Raising the cap could improve the objective.

Generation rules:
  - Basic variables: sorted by contribution descending
  - Non-basic variables: sorted by reduced cost ascending (closest to entering first)
  - Contribution = value * objective coefficient
  - Contribution % = contribution / optimal_value * 100
  - If all variables basic: "All variables are in the solution."
  - Reduced cost sign convention:
      For MAX: reduced cost <= 0 for non-basic at lower bound (need to increase obj coeff)
      Display absolute value: "must increase by |rc|"


================================================================
SENSITIVITY REPORT — Actionability
================================================================

--- BRIEF ---
Most robust: {name}'s profit can range [{lower:.2f}, {upper:.2f}] without changing the solution structure.
Bottleneck: Expanding {bottleneck_name} capacity has the highest marginal return ({dual:.4f} per unit).
Most fragile: {fragile_name}'s profit has the narrowest range (width {width:.2f}) — can only decrease by {pct_decrease:.0f}% before the solution changes.

--- DETAILED ---
Objective coefficient ranges (current basis stays optimal):

  {name} (current = {current}):
     Allowable range: [{lower:.4f}, {upper:.4f}]
     → Can decrease by {pct_decrease:.0f}% or increase by {pct_increase:.0f}% without changing the solution.
     [Repeat for each variable, sorted by range_width ascending (most fragile first)]

RHS ranges (current basis stays feasible):

  {name} (current = {current}, shadow price = {dual:.4f}):
     Allowable range: [{lower:.4f}, {upper:.4f}]
     → Within this range, each unit change in {name} changes the objective by {dual:.4f}.
     [Repeat for each constraint, sorted by dual_value descending]

  [For non-binding constraints:]
  {name} (current = {current}, shadow price = 0):
     → Non-binding. RHS can decrease by {slack:.2f} without affecting the solution.

Recommendations:
  → Bottleneck: {bottleneck} has the highest shadow price ({dual:.4f}). Expanding this constraint first gives the best return.
  → Most fragile: {fragile} has the narrowest allowable range. Monitor this parameter closely.
  → Most robust: {robust} has the widest allowable range. This parameter is stable.

Generation rules:
  - Obj coeff items: sorted by range_width ascending (most fragile first)
  - RHS items: sorted by dual_value descending (most valuable first)
  - pct_decrease = (current - lower) / |current| * 100 (handle current = 0)
  - pct_increase = (upper - current) / |current| * 100
  - inf ranges: display as "no limit" instead of "inf"
  - Bottleneck = binding constraint with max |dual_value|
  - Most fragile = variable with min range_width
  - Most robust = variable with max range_width
"""


# ============================================================
# 4. JSON Output Structure
# ============================================================

JSON_STRUCTURE = """
{
  "problem_name": "albici_base",
  "optimal_value": 3688.8889,
  "status": "OPTIMAL",
  "engine": "INTERNAL_SIMPLEX",
  "solve_time_seconds": 0.001,
  "iteration_count": 3,

  "binding_report": {
    "summary": "3 of 4 constraints are binding. ...",
    "binding": [
      {
        "name": "S3",
        "rhs": 2000,
        "dual_value": 1.1111,
        "rank": 1
      },
      ...
    ],
    "nonbinding": [
      {
        "name": "S2",
        "rhs": 1400,
        "slack": 111.11,
        "utilization_pct": 92.06
      }
    ]
  },

  "variable_report": {
    "summary": "3 of 3 variables are in the solution. ...",
    "basic": [
      {
        "name": "x1",
        "value": 755.5556,
        "obj_coeff": 3.0,
        "contribution": 2266.6667,
        "contribution_pct": 61.44
      },
      ...
    ],
    "nonbasic": []
  },

  "sensitivity_report": {
    "summary": "Most robust: x1's profit can range ...",
    "bottleneck": "S3",
    "most_robust": "x1",
    "most_fragile": "x3",
    "obj_coeff_ranges": [
      {
        "name": "x3",
        "current": 5.0,
        "lower": 3.0,
        "upper": 6.75,
        "range_width": 3.75,
        "pct_decrease": 40.0,
        "pct_increase": 35.0
      },
      {
        "name": "x1",
        "current": 3.0,
        "lower": 0.5,
        "upper": 5.0,
        "range_width": 4.5,
        "pct_decrease": 83.33,
        "pct_increase": 66.67
      },
      {
        "name": "x2",
        "current": 4.0,
        "lower": 2.8333,
        "upper": 7.3333,
        "range_width": 4.5,
        "pct_decrease": 29.17,
        "pct_increase": 83.33
      }
    ],
    "rhs_ranges": [
      {
        "name": "S3",
        "current": 2000,
        "lower": 1200.0,
        "upper": 2100.0,
        "dual_value": 1.1111,
        "is_binding": true,
        "range_width": 900.0
      },
      {
        "name": "S1",
        "current": 1200,
        "lower": 1109.0909,
        "upper": 1600.0,
        "dual_value": 0.7778,
        "is_binding": true,
        "range_width": 490.9091
      },
      {
        "name": "S4",
        "current": 800,
        "lower": 266.6667,
        "upper": 966.6667,
        "dual_value": 0.6667,
        "is_binding": true,
        "range_width": 700.0
      },
      {
        "name": "S2",
        "current": 1400,
        "lower": 1288.8889,
        "upper": null,
        "dual_value": 0.0,
        "is_binding": false,
        "range_width": null
      }
    ]
  }
}
"""


# ============================================================
# 5. Module Structure
# ============================================================

MODULE_STRUCTURE = """
clara/explain/
├── __init__.py              # re-exports: Explainer, ExplanationReport, DetailLevel
├── explainer.py             # Explainer class (orchestrator)
├── binding.py               # BindingReportGenerator
├── variable.py              # VariableReportGenerator
├── sensitivity.py           # SensitivityReportGenerator
└── types.py                 # ExplanationReport, DetailLevel, all item dataclasses

Each generator:
  class BindingReportGenerator:
      def generate(self, state: SolveState, level: DetailLevel) -> BindingReport:
          items = self._extract_items(state)
          summary = self._make_summary(items)
          return BindingReport(binding=..., nonbinding=..., summary=summary)

      def _extract_items(self, state: SolveState) -> ...:
          # Pure data extraction from SolveState fields

      def _make_summary(self, items: ...) -> str:
          # Template rendering

Explainer just orchestrates:
  class Explainer:
      def __init__(self):
          self._binding = BindingReportGenerator()
          self._variable = VariableReportGenerator()
          self._sensitivity = SensitivityReportGenerator()

      def explain(self, state, level) -> ExplanationReport:
          return ExplanationReport(
              header=self._make_header(state),
              binding=self._binding.generate(state, level),
              variable=self._variable.generate(state, level),
              sensitivity=self._sensitivity.generate(state, level),
          )
"""


# ============================================================
# 6. Formatting Rules
# ============================================================

FORMATTING_RULES = """
Numbers:
  - Optimal value: 4 decimal places (3688.8889)
  - Variable values: 4 decimal places
  - Dual values / shadow prices: 4 decimal places
  - Percentages: 0 decimal places in brief (61%), 1 in detailed (61.4%)
  - Sensitivity ranges: 4 decimal places
  - Infinity: display as "no limit" in text, null in JSON

Text:
  - Section headers: ALL CAPS with ═ underline
  - Sub-headers: Title Case with ─ underline
  - Indentation: 2 spaces per level
  - Line width: max 80 characters (wrap long lines)
  - Separator between sections: blank line

JSON:
  - Keys: snake_case
  - Numbers: full precision (no rounding)
  - Infinity: JSON null with "is_inf": true flag
  - Enums: string value (e.g., "OPTIMAL", "BASIC")
"""


# ============================================================
# 7. Test Cases
# ============================================================

TEST_CASES = """
tests/test_explainer.py

1. Albici base problem — full validation
   - test_binding_report_albici        → 3 binding (S1, S3, S4), 1 nonbinding (S2)
   - test_binding_ranked_by_shadow     → S3 rank 1 (dual=1.11), S1 rank 2, S4 rank 3
   - test_variable_report_albici       → 3 basic, 0 nonbasic
   - test_variable_contributions       → x1 contribution = 755.56 * 3 = 2266.67
   - test_sensitivity_bottleneck       → S3 (highest shadow price 1.1111)
   - test_sensitivity_most_fragile     → x3 (narrowest range_width 3.75)
   - test_sensitivity_most_robust      → x1 (widest range_width 4.50)
   - test_sensitivity_ranges_present   → all 3 vars + 4 constraints have ranges

2. Detail level
   - test_brief_binding                → only summary string, no per-item detail
   - test_detailed_binding             → per-item with shadow price and interpretation
   - test_brief_is_shorter             → len(brief.to_text()) < len(detailed.to_text())

3. Output format
   - test_to_text_not_empty            → text output is non-empty string
   - test_to_json_valid                → json.loads(report.to_json()) succeeds
   - test_to_dict_keys                 → all expected top-level keys present
   - test_json_roundtrip               → to_dict values match SolveState values

4. Edge cases
   - test_all_binding                  → "All constraints are binding" message
   - test_no_nonbasic                  → "All variables are in the solution" message
   - test_zero_obj_coeff               → handle division by zero in pct_decrease
   - test_inf_sensitivity_range        → "no limit" in text, null in JSON
   - test_single_variable              → minimal problem (1 var, 1 constraint)

5. Non-basic variable explanation
   - test_nonbasic_reduced_cost_msg    → "must increase by X before entering solution"
   - test_nonbasic_at_upper_bound      → "capped at upper bound" message

6. Recommendations
   - test_bottleneck_identified        → constraint with max |dual|
   - test_most_fragile_identified      → variable with min range_width
   - test_most_robust_identified       → variable with max range_width

7. Header
   - test_header_contains_opt_value    → optimal value in header
   - test_header_contains_engine       → engine name in header
   - test_header_contains_iterations   → iteration count in header
"""


# ============================================================
# 8. Example: Albici Base Problem Full Output
# ============================================================

EXAMPLE_BRIEF_OUTPUT = """
═══════════════════════════════════════════════════════════════
CLARA — albici_base
Optimal value: 3688.8889 (OPTIMAL)
Solved in 3 iterations, 0.001s (INTERNAL_SIMPLEX)
═══════════════════════════════════════════════════════════════

BINDING CONSTRAINTS
3 of 4 constraints are binding. S3 is the tightest bottleneck
(shadow price 1.1111). S2 has 111.11 units of unused capacity
(92% utilized).

VARIABLE STATUS
3 of 3 variables are in the solution. x1 contributes 61% of
the objective.

SENSITIVITY ANALYSIS
Most robust: x1's profit can range [0.50, 5.00] (width 4.50)
without changing the solution structure. Bottleneck: Expanding
S3 capacity has the highest marginal return (1.1111 per unit).
Most fragile: x3's profit has the narrowest range [3.00, 6.75]
— can only decrease by 40% before the solution changes.
"""

EXAMPLE_DETAILED_OUTPUT = """
═══════════════════════════════════════════════════════════════
CLARA — albici_base
Optimal value: 3688.8889 (OPTIMAL)
Solved in 3 iterations, 0.001s (INTERNAL_SIMPLEX)
═══════════════════════════════════════════════════════════════

BINDING CONSTRAINTS
─────────────────────────────────────────────────────────────
Binding constraints (3 of 4):

  1. S3 (RHS = 2000): Fully utilized.
     Shadow price: 1.1111
     → Each additional unit of S3 capacity increases
       objective by 1.1111.

  2. S1 (RHS = 1200): Fully utilized.
     Shadow price: 0.7778
     → Each additional unit of S1 capacity increases
       objective by 0.7778.

  3. S4 (RHS = 800): Fully utilized.
     Shadow price: 0.6667
     → Each additional unit of S4 capacity increases
       objective by 0.6667.

Non-binding constraints (1 of 4):

  S2 (RHS = 1400): Slack = 111.1111
     → 92.1% utilized. Has 111.1111 units of unused capacity.

VARIABLE STATUS
─────────────────────────────────────────────────────────────
Variables in solution (3 of 3):

  x1 = 755.5556 (profit = 3.0000)
     Contribution: 2266.6667 (61.4% of objective)

  x3 = 177.7778 (profit = 5.0000)
     Contribution: 888.8889 (24.1% of objective)

  x2 = 133.3333 (profit = 4.0000)
     Contribution: 533.3333 (14.5% of objective)

SENSITIVITY ANALYSIS
─────────────────────────────────────────────────────────────
Objective coefficient ranges (current basis stays optimal):

  x3 (current = 5.0000):
     Allowable range: [3.0000, 6.7500]
     → Can decrease by 40% or increase by 35% without
       changing the solution.

  x1 (current = 3.0000):
     Allowable range: [0.5000, 5.0000]
     → Can decrease by 83% or increase by 67% without
       changing the solution.

  x2 (current = 4.0000):
     Allowable range: [2.8333, 7.3333]
     → Can decrease by 29% or increase by 83% without
       changing the solution.

RHS ranges (current basis stays feasible):

  S3 (current = 2000, shadow price = 1.1111):
     Allowable range: [1200.0000, 2100.0000]
     → Within this range, each unit change in S3 changes
       the objective by 1.1111.

  S1 (current = 1200, shadow price = 0.7778):
     Allowable range: [1109.0909, 1600.0000]
     → Within this range, each unit change in S1 changes
       the objective by 0.7778.

  S4 (current = 800, shadow price = 0.6667):
     Allowable range: [266.6667, 966.6667]
     → Within this range, each unit change in S4 changes
       the objective by 0.6667.

  S2 (current = 1400, shadow price = 0.0000):
     → Non-binding. RHS can decrease by 111.1111 without
       affecting the solution.

Recommendations:
  → Bottleneck: S3 has the highest shadow price (1.1111).
    Expanding this constraint first gives the best return.
  → Most fragile: x3 has the narrowest allowable range
    (width 3.75). Monitor this parameter closely.
  → Most robust: x1 has the widest allowable range
    (width 4.50). This parameter is stable.
"""