"""
CLARA CLI — Design Specification
==================================

Wiring layer that connects: LP Parser → Solve Engine → Explainer → Output.
This is the last piece of Phase 1 MVP.

After this, `clara explain problem.lp` works end-to-end.

Dependencies: click (already in pyproject.toml)
"""


# ============================================================
# 1. Command Structure
# ============================================================

COMMANDS = """
clara                               # top-level group
├── explain <file>                  # Phase 1 MVP ← THIS IS THE PRIORITY
├── solve <file>                    # solve only, no explanation (quick mode)
├── info <file>                     # problem stats without solving
├── what-if <file>                  # Phase 1.5 (placeholder)
└── watch <file> --params <json>    # Phase 2 (placeholder)

Phase 1 implements: explain, solve, info
Phase 1.5 adds: what-if
Phase 2 adds: watch
"""


# ============================================================
# 2. `clara explain` — Main Command
# ============================================================

EXPLAIN_COMMAND = """
Usage:
  clara explain <file> [options]

Arguments:
  file                    Path to .lp file

Options:
  --engine [internal|highs]   Solve engine (default: internal)
  --level [brief|detailed]    Detail level (default: detailed)
  --format [text|json]        Output format (default: text)
  --output, -o <path>         Write to file instead of stdout
  --no-sensitivity            Skip sensitivity analysis (faster)
  --quiet, -q                 Suppress header, show results only

Examples:
  clara explain problem.lp
  clara explain problem.lp --engine highs
  clara explain problem.lp --level brief
  clara explain problem.lp --format json -o result.json
  clara explain problem.lp --level brief --quiet
"""


# ============================================================
# 3. `clara solve` — Solve Only
# ============================================================

SOLVE_COMMAND = """
Usage:
  clara solve <file> [options]

Arguments:
  file                    Path to .lp file

Options:
  --engine [internal|highs]   Solve engine (default: internal)
  --format [text|json]        Output format (default: text)
  --output, -o <path>         Write to file instead of stdout

Output (text):
  Optimal value: 3688.8889
  x1 = 755.5556
  x2 = 133.3333
  x3 = 177.7778
  Solved in 3 iterations, 0.001s (INTERNAL_SIMPLEX)

Output (json):
  {
    "status": "OPTIMAL",
    "optimal_value": 3688.8889,
    "variables": {"x1": 755.5556, "x2": 133.3333, "x3": 177.7778},
    "iterations": 3,
    "time": 0.001,
    "engine": "INTERNAL_SIMPLEX"
  }
"""


# ============================================================
# 4. `clara info` — Problem Statistics
# ============================================================

INFO_COMMAND = """
Usage:
  clara info <file>

Output:
  Problem: albici_base
  Sense: maximize
  Variables: 3 (continuous: 3, integer: 0, binary: 0)
  Constraints: 4 (<=: 4, >=: 0, =: 0)
  Nonzeros: 10
  Bounds: all default [0, +inf]

No solving — just parses the file and reports structure.
Useful for quick inspection before solving.
"""


# ============================================================
# 5. Pipeline Architecture
# ============================================================

PIPELINE = """
┌────────────┐     ┌──────────────┐     ┌────────────┐     ┌──────────────┐
│ LP Parser  │────▶│ Solve Engine │────▶│  Explainer │────▶│   Formatter  │
│ read_lp()  │     │  .solve()    │     │  .explain() │     │ text / json  │
└────────────┘     └──────────────┘     └────────────┘     └──────────────┘
    file.lp    →     LPProblem     →     SolveState    →  ExplanationReport → stdout/file

Error handling at each stage:
  1. LP Parser:   FileNotFoundError, LPParseError → user-friendly message + exit(1)
  2. Solve Engine: InfeasibleError, UnboundedError → explain what it means + exit(1)
  3. Explainer:    never fails (always produces output from valid SolveState)
  4. Formatter:    IOError on file write → message + exit(1)
"""


# ============================================================
# 6. Implementation
# ============================================================

IMPLEMENTATION = """
# clara/cli.py

import sys
from pathlib import Path

import click

from clara.io.lp_parser import read_lp, LPParseError
from clara.engine.simplex import InternalSimplex
from clara.explain.explainer import Explainer
from clara.explain.types import DetailLevel


@click.group()
@click.version_option(package_name="clara-opt")
def main():
    '''CLARA — Classical LP Analysis for Reoptimization and Attribution.

    A white-box optimization solver that explains why solutions are optimal,
    when reoptimization is needed, and what changed.
    '''
    pass


@main.command()
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--engine", type=click.Choice(["internal", "highs"]),
              default="internal", help="Solve engine.")
@click.option("--level", type=click.Choice(["brief", "detailed"]),
              default="detailed", help="Explanation detail level.")
@click.option("--format", "fmt", type=click.Choice(["text", "json"]),
              default="text", help="Output format.")
@click.option("--output", "-o", type=click.Path(), default=None,
              help="Write output to file.")
@click.option("--no-sensitivity", is_flag=True,
              help="Skip sensitivity analysis.")
@click.option("--quiet", "-q", is_flag=True,
              help="Suppress header.")
def explain(file, engine, level, fmt, output, no_sensitivity, quiet):
    '''Solve an LP and explain the solution.'''

    # 1. Parse
    try:
        problem = read_lp(file)
    except LPParseError as e:
        click.secho(f"Parse error: {e}", fg="red", err=True)
        sys.exit(1)

    # 2. Solve
    try:
        solver = _make_engine(engine)
        state = solver.solve(problem)
    except Exception as e:
        click.secho(f"Solve error: {e}", fg="red", err=True)
        sys.exit(1)

    if not state.is_optimal:
        click.secho(f"Problem is {state.status.name}.", fg="yellow", err=True)
        # Still output what we can (e.g., infeasibility info)
        sys.exit(1)

    # 3. Explain
    detail = DetailLevel.BRIEF if level == "brief" else DetailLevel.DETAILED
    explainer = Explainer()
    report = explainer.explain(state, level=detail)

    # 4. Format & output
    if fmt == "json":
        text = report.to_json()
    else:
        text = report.to_text(level=detail)
        if quiet:
            # Strip header (first section before first blank line)
            text = _strip_header(text)

    _write_output(text, output)


@main.command()
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--engine", type=click.Choice(["internal", "highs"]),
              default="internal")
@click.option("--format", "fmt", type=click.Choice(["text", "json"]),
              default="text")
@click.option("--output", "-o", type=click.Path(), default=None)
def solve(file, engine, fmt, output):
    '''Solve an LP without explanation (quick mode).'''

    try:
        problem = read_lp(file)
    except LPParseError as e:
        click.secho(f"Parse error: {e}", fg="red", err=True)
        sys.exit(1)

    try:
        solver = _make_engine(engine)
        state = solver.solve(problem)
    except Exception as e:
        click.secho(f"Solve error: {e}", fg="red", err=True)
        sys.exit(1)

    if fmt == "json":
        text = state.to_json()
    else:
        text = _format_solve_text(state)

    _write_output(text, output)


@main.command()
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
def info(file):
    '''Show problem statistics without solving.'''

    try:
        problem = read_lp(file)
    except LPParseError as e:
        click.secho(f"Parse error: {e}", fg="red", err=True)
        sys.exit(1)

    text = _format_info_text(problem)
    click.echo(text)


# --- Placeholder commands for future phases ---

@main.command(name="what-if", hidden=True)
@click.argument("file")
def what_if(file):
    '''[Phase 1.5] Interactive what-if analysis.'''
    click.secho("what-if is not yet implemented (Phase 1.5).", fg="yellow")
    sys.exit(0)


@main.command(hidden=True)
@click.argument("file")
@click.option("--params", type=click.Path(exists=True))
def watch(file, params):
    '''[Phase 2] Stream parameter changes and reoptimize.'''
    click.secho("watch is not yet implemented (Phase 2).", fg="yellow")
    sys.exit(0)


# ============================================================
# Helper functions
# ============================================================

def _make_engine(engine_name: str):
    '''Factory for solve engines.'''
    if engine_name == "internal":
        return InternalSimplex()
    elif engine_name == "highs":
        # Phase 1: HiGHS not yet implemented
        try:
            from clara.engine.highs_backend import HiGHSBackend
            return HiGHSBackend()
        except ImportError:
            click.secho(
                "HiGHS backend not yet available. Using internal engine.",
                fg="yellow", err=True,
            )
            return InternalSimplex()
    else:
        raise ValueError(f"Unknown engine: {engine_name}")


def _format_solve_text(state) -> str:
    '''Minimal text output for `clara solve`.'''
    lines = [f"Optimal value: {state.optimal_value:.4f}"]
    for v in state.variables:
        lines.append(f"  {v.name} = {v.value:.4f}")
    lines.append(
        f"Solved in {state.iteration_count} iterations, "
        f"{state.solve_time_seconds:.3f}s ({state.engine.name})"
    )
    return "\\n".join(lines)


def _format_info_text(problem) -> str:
    '''Problem statistics for `clara info`.'''
    n_cont = problem.num_variables - len(problem.integer_vars) - len(problem.binary_vars)
    n_ub = len(problem.b_ub) if problem.b_ub is not None else 0
    n_eq = len(problem.b_eq) if problem.b_eq is not None else 0

    lines = [
        f"Problem: {problem.name}",
        f"Sense: {problem.sense}",
        f"Variables: {problem.num_variables} "
        f"(continuous: {n_cont}, integer: {len(problem.integer_vars)}, "
        f"binary: {len(problem.binary_vars)})",
        f"Constraints: {n_ub + n_eq} (<=: {n_ub}, =: {n_eq})",
    ]
    return "\\n".join(lines)


def _strip_header(text: str) -> str:
    '''Remove header section (everything before first blank line).'''
    parts = text.split("\\n\\n", 1)
    return parts[1] if len(parts) > 1 else text


def _write_output(text: str, output_path: str | None) -> None:
    '''Write to file or stdout.'''
    if output_path:
        try:
            Path(output_path).write_text(text)
            click.secho(f"Written to {output_path}", fg="green", err=True)
        except IOError as e:
            click.secho(f"Write error: {e}", fg="red", err=True)
            sys.exit(1)
    else:
        click.echo(text)
"""


# ============================================================
# 7. Error Messages (user-friendly)
# ============================================================

ERROR_MESSAGES = """
Parse errors:
  $ clara explain nonexistent.lp
  Error: Path 'nonexistent.lp' does not exist.          ← click handles this

  $ clara explain broken.lp
  Parse error: line 5: Expected inequality sense (<=, >=, =)
    → "x1 + x2 1200"

Solve errors:
  $ clara explain infeasible.lp
  Problem is INFEASIBLE.

  $ clara explain unbounded.lp
  Problem is UNBOUNDED.

Engine fallback:
  $ clara explain problem.lp --engine highs
  HiGHS backend not yet available. Using internal engine.
  [proceeds with internal engine]
"""


# ============================================================
# 8. Test Cases
# ============================================================

TEST_CASES = """
tests/test_cli.py

Uses click.testing.CliRunner for isolated CLI testing.

1. End-to-end (the most important tests)
   - test_explain_albici_base          → exit 0, output contains "3688.8889"
   - test_explain_albici_base_brief    → exit 0, shorter output than detailed
   - test_explain_albici_base_json     → exit 0, valid JSON, has all report keys
   - test_explain_all_fixtures         → all .lp files in fixtures/ produce exit 0

2. Commands
   - test_solve_albici_base            → exit 0, shows optimal value + variable values
   - test_solve_json                   → valid JSON with status, optimal_value, variables
   - test_info_albici_base             → exit 0, shows "3 variables", "4 constraints"
   - test_what_if_placeholder          → exit 0, "not yet implemented"
   - test_watch_placeholder            → exit 0, "not yet implemented"

3. Options
   - test_engine_internal              → default, works
   - test_engine_highs_fallback        → falls back to internal with warning
   - test_level_brief                  → shorter output
   - test_level_detailed               → longer output
   - test_format_text                  → plain text
   - test_format_json                  → valid JSON
   - test_output_file                  → writes to file, file exists
   - test_quiet_flag                   → no header in output

4. Error handling
   - test_file_not_found               → exit != 0, error message
   - test_parse_error                  → exit 1, "Parse error" in stderr
   - test_invalid_engine               → exit != 0

5. Version
   - test_version                      → --version shows version string

6. Help
   - test_help                         → --help shows usage
   - test_explain_help                 → explain --help shows options
"""


# ============================================================
# 9. Demo Script (for README / documentation)
# ============================================================

DEMO = """
# After: pip install clara-opt

# Basic explanation (detailed, text)
$ clara explain examples/production.lp

# Brief summary
$ clara explain examples/production.lp --level brief

# JSON output piped to jq
$ clara explain examples/production.lp --format json | jq '.sensitivity_report.bottleneck'

# Solve only (no explanation)
$ clara solve examples/production.lp

# Problem info
$ clara info examples/production.lp

# Save detailed JSON report
$ clara explain examples/production.lp --format json -o report.json
"""