# 🔍 AzerAI Search Plugin

Azərbaycan dilində qabaqcıl səsli AI asistenti üçün veb axtarış plugini.

## Xüsusiyyətlər

- 🔍 **Veb axtarışı** - DuckDuckGo ilə veb axtarışı
- 📰 **Xəbər axtarışı** - Son xəbərləri tap
- 📊 **Nəticə formatı** - Səliqəli nəticə formatı
- 🎵 **Arxa plan musiqisi** - Əməliyyat zamanı C5 notası
- 🎤 **Mikrofon kontrolü** - Əməliyyat zamanı danışığı bloklayır
- 🌐 **Azərbaycan dili** - Azərbaycan dilində axtarış

## Quraşdırma

```bash
pip install azerai-search
```

## İstifadə

Plugin avtomatik olaraq AzerAI tərəfindən aşkar edilir.

### Əmrlər

- `"Azərbaycan haqqında axtar"` - Veb axtarışı
- `"Son xəbərləri göstər"` - Xəbər axtarışı
- `"İnternetsiz axtar"` - Müxtəlif nəticə tipi
- `"Google-da axtar"` - Veb axtarışı

## Fayl struktur

```
azerai_search/
├── plugins/
│   └── search/
│       ├── __init__.py
│       └── main.py
└── __init__.py
```

## Xüsusiyyətlər

### 🔍 **Veb Axtarışı**
- DuckDuckGo axtarış motoru
- 10 nəticəyə qədər
- Başlıq, snippet və URL
- Azərbaycan dilində nəticələr

### 📰 **Xəbər Axtarışı**
- Son xəbərlər
- Mövzuya görə filter
- 5 nəticəyə qədər
- Xəbər mənbəyi linkləri

### 📊 **Nəticə Formatı**
- Nəticə sayı
- Axtarış vaxtı
- Formatlanmış çıxış
- Linklər və snippetlər

## Asılılıqlar

- `livekit-agents>=1.0.0` - AI agent framework
- `requests>=2.31.0` - HTTP sorğuları
- `beautifulsoup4>=4.12.0` - HTML parsing
- `sounddevice>=0.4.6` - Audio çalma
- `scipy>=1.11.0` - Audio işləmə
- `numpy>=1.24.0` - Riyazi əməliyyatlar

## Lisenziya

MIT License
