"""
AzerAI Search Plugin - Veb axtarış plugini

Plugin əsaslı, çoxdilli AI asistenti üçün veb axtarış modulu.
"""

__version__ = "1.0.0"
__author__ = "AzStudio Dev"
__email__ = "dev@azstudio.ai"

from .plugins.search.main import web_search, search_news, get_search_results

__all__ = [
    "web_search",
    "search_news",
    "get_search_results"
]
