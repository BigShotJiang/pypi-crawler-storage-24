"""
AzerAI Search Plugin
"""

from .main import web_search, search_news, get_search_results

__all__ = [
    "web_search",
    "search_news",
    "get_search_results"
]
