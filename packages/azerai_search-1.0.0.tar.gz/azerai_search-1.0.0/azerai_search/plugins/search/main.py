"""
Search Tools - LiveKit Agent Functions
Veb axtarış sistem araçları
"""
import logging
import threading
import time
import asyncio
import requests
from bs4 import BeautifulSoup
from datetime import datetime
from typing import Dict, Any, List
from livekit.agents import function_tool, RunContext
import sounddevice as sd
import scipy.io.wavfile as wavfile
import numpy as np

logger = logging.getLogger("search-tools")


def play_search_music(stop_event):
    """
    Arama işlemleri için arka plan müziği çalar.
    """
    try:
        music_dir = Path("plugins/search/music")
        music_dir.mkdir(exist_ok=True)
        music_file = music_dir / "search.wav"
        frequency = 523  # C5 notası - arama tonu
        
        if not music_file.exists():
            sample_rate = 44100
            duration = 7.0
            
            t = np.linspace(0, duration, int(sample_rate * duration), False)
            wave = 0.3 * np.sin(2 * np.pi * frequency * t) + \
                   0.1 * np.sin(2 * np.pi * frequency * 2 * t) + \
                   0.05 * np.sin(2 * np.pi * frequency * 3 * t)
            
            envelope = 0.8 + 0.2 * np.sin(2 * np.pi * 0.4 * t)
            wave = wave * envelope
            
            wavfile.write(music_file, sample_rate, (wave * 32767).astype(np.int16))
        
        sample_rate, data = wavfile.read(str(music_file))
        
        while not stop_event.is_set():
            try:
                sd.play(data, sample_rate)
                audio_duration = len(data) / sample_rate
                start_time = time.time()
                
                while time.time() - start_time < audio_duration:
                    if stop_event.is_set():
                        sd.stop()
                        return
                    time.sleep(0.1)
                    
            except Exception as e:
                logging.error("Error playing background music: %s", e)
                break
                
    except ImportError:
        logging.warning("numpy not available for background music generation")
    except Exception as e:
        logging.error("Error in background music thread: %s", e)


class SearchTools:
    """Veb axtarış alətləri"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        logger.info("SearchTools initialized")

    def _duckduckgo_search(self, query: str, max_results: int = 10) -> List[Dict[str, str]]:
        """DuckDuckGo ile axtarış"""
        try:
            url = "https://duckduckgo.com/html/"
            params = {'q': query, 'kl': 'az-az'}
            
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            results = []
            
            # DuckDuckGo sonuçlarını parse et
            for result in soup.find_all('div', class_='result')[:max_results]:
                title_tag = result.find('a', class_='result__a')
                snippet_tag = result.find('a', class_='result__snippet')
                
                if title_tag and snippet_tag:
                    title = title_tag.get_text(strip=True)
                    url = title_tag.get('href', '')
                    snippet = snippet_tag.get_text(strip=True)
                    
                    results.append({
                        'title': title,
                        'url': url,
                        'snippet': snippet
                    })
            
            return results
            
        except Exception as e:
            logger.error(f"DuckDuckGo search error: {e}")
            return []

    def _format_search_results(self, results: List[Dict[str, str]], query: str) -> str:
        """Axtarış nəticələrini formatla"""
        if not results:
            return f"""🔍 SEARCH RESULTS

🔍 Query: {query}
📊 Results: 0 found
⏰ Search time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

❌ No results found for your search query."""
        
        formatted_results = []
        for i, result in enumerate(results, 1):
            formatted_results.append(f"{i}. {result['title']}")
            formatted_results.append(f"   {result['snippet']}")
            formatted_results.append(f"   🔗 {result['url']}")
            formatted_results.append("")
        
        return f"""🔍 SEARCH RESULTS

🔍 Query: {query}
📊 Results: {len(results)} found
⏰ Search time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

📄 Search Results:
{chr(10).join(formatted_results)}

✅ Search completed successfully"""


# Global instance
search_tools = SearchTools()


@function_tool()
async def web_search(ctx: RunContext, query: str, max_results: int = 10) -> str:
    """
    Veb'de axtarış edir.
    
    Args:
        query: Axtarış sorğusu
        max_results: Maksimum nəticə sayısı
    
    Returns:
        Axtarış nəticələri
    """
    logger = logging.getLogger("search-plugin")
    
    try:
        logger.debug("=== SEARCH START: set_audio_enabled(False) called ===")
        ctx.session.input.set_audio_enabled(False)

        stop_music = threading.Event()
        music_thread = threading.Thread(
            target=play_search_music, 
            args=(stop_music,),
            daemon=True
        )
        music_thread.start()
        
        try:
            logger.debug(f"=== SEARCH: Starting web search for '{query}' ===")
            
            results = await asyncio.to_thread(
                search_tools._duckduckgo_search, query, max_results
            )
            
            result_text = search_tools._format_search_results(results, query)
            
            logger.debug(f"=== SEARCH COMPLETE: {len(results)} results ===")
            return result_text
            
        except Exception as e:
            logger.debug(f"=== SEARCH ERROR: {str(e)} ===")
            return f"Web search failed: {str(e)}"
        finally:
            stop_music.set()
            sd.stop()
            logger.debug("=== SEARCH FINALLY: set_audio_enabled(True) called ===")
            ctx.session.input.set_audio_enabled(True)
        
    except Exception as e:
        logging.error(f"Search plugin error: {e}")
        return f"Error during web search: {str(e)}"


@function_tool()
async def search_news(ctx: RunContext, topic: str, max_results: int = 5) -> str:
    """
    Xəbər axtarışı edir.
    
    Args:
        topic: Xəbər mövzusu
        max_results: Maksimum nəticə sayısı
    
    Returns:
        Xəbər axtarış nəticələri
    """
    try:
        logger.debug(f"=== NEWS SEARCH: Searching for '{topic}' ===")
        
        # Xəbər axtarışı üçün xüsusi query
        news_query = f"{topic} news xəbər"
        
        results = await asyncio.to_thread(
            search_tools._duckduckgo_search, news_query, max_results
        )
        
        if not results:
            return f"""📰 NEWS SEARCH RESULTS

📰 Topic: {topic}
📊 Results: 0 found
⏰ Search time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

❌ No news found for this topic."""
        
        formatted_news = []
        for i, result in enumerate(results, 1):
            formatted_news.append(f"{i}. {result['title']}")
            formatted_news.append(f"   {result['snippet']}")
            formatted_news.append(f"   🔗 {result['url']}")
            formatted_news.append("")
        
        result = f"""📰 NEWS SEARCH RESULTS

📰 Topic: {topic}
📊 Results: {len(results)} found
⏰ Search time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

📄 News Results:
{chr(10).join(formatted_news)}

✅ News search completed"""
        
        logger.info(f"News search completed: {len(results)} results")
        return result
        
    except Exception as e:
        logger.error(f"Error searching news: {e}")
        return f"News search failed: {str(e)}"


@function_tool()
async def get_search_results(ctx: RunContext, query: str, result_type: str = "web") -> str:
    """
    Müxtəlif növ axtarış nəticələri alır.
    
    Args:
        query: Axtarış sorğusu
        result_type: Nəticə tipi (web, news, images)
    
    Returns:
        Axtarış nəticələri
    """
    try:
        logger.debug(f"=== GET SEARCH RESULTS: {result_type} search for '{query}' ===")
        
        if result_type.lower() == "news":
            return await search_news(ctx, query)
        else:
            return await web_search(ctx, query)
        
    except Exception as e:
        logger.error(f"Error getting search results: {e}")
        return f"Search results failed: {str(e)}"
