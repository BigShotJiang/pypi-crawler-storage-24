from transformers import PretrainedConfig
class SykoConfig(PretrainedConfig):
    model_type = "syko"
    def __init__(self, vocab_size=32000, hidden_size=768, num_hidden_layers=24, num_attention_heads=6, intermediate_size=3072, max_position_embeddings=2048, rms_norm_eps=1e-5, rope_theta=10000.0, pad_token_id=0, bos_token_id=1, eos_token_id=2, tie_word_embeddings=False, **kwargs):
        super().__init__(pad_token_id=pad_token_id, bos_token_id=bos_token_id, eos_token_id=eos_token_id, tie_word_embeddings=tie_word_embeddings, **kwargs)
        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.num_hidden_layers = num_hidden_layers
        self.num_attention_heads = num_attention_heads
        self.intermediate_size = intermediate_size
        self.max_position_embeddings = max_position_embeddings
        self.rms_norm_eps = rms_norm_eps
        self.rope_theta = rope_theta
    @classmethod
    def from_tokenizer(cls, tokenizer, **kwargs):
        return cls(vocab_size=tokenizer.vocab_size, **kwargs)
