"""Real-time pluggable dashboard with live widgets"""

__version__ = "0.0.1"
