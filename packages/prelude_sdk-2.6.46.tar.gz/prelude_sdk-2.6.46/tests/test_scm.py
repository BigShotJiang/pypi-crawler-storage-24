import json
import os
import pytest
import requests
import time

from prelude_sdk.controllers.export_controller import ExportController
from prelude_sdk.controllers.iam_controller import IAMAccountController
from prelude_sdk.controllers.jobs_controller import JobsController
from prelude_sdk.controllers.partner_controller import PartnerController
from prelude_sdk.controllers.scm_controller import ScmController
from prelude_sdk.models.codes import Control, ControlCategory, SCMCategory


@pytest.mark.order(8)
@pytest.mark.usefixtures("setup_account")
class TestScmAcrossControls:
    def setup_class(self):
        if not pytest.expected_account["features"]["policy_evaluator"]:
            pytest.skip("POLICY_EVALUATOR feature not enabled")
        if not pytest.controls:
            pytest.skip("Partners not attached")
        self.export = ExportController(pytest.account)
        self.iam_account = IAMAccountController(pytest.account)
        self.jobs = JobsController(pytest.account)
        self.partner = PartnerController(pytest.account)
        self.scm = ScmController(pytest.account)

    def test_custom_partner(self, unwrap):
        CONFIG_FILE = os.getenv("CUSTOM_PARTNER_CONFIG")
        SECRET_FILE = os.getenv("CUSTOM_PARTNER_SECRET")
        if not CONFIG_FILE or not SECRET_FILE:
            pytest.skip(
                "Custom partner config or secret not provided in environment variables"
            )

        with open(CONFIG_FILE, "r") as f:
            config = json.load(f)
        with open(SECRET_FILE, "r") as f:
            secret = json.load(f)
        assert unwrap(self.partner.attach_custom)(
            self.partner,
            config=config,
            control_category=ControlCategory.IDENTITY,
            control_name="bob's control",
            name="custom",
            secret=json.dumps(secret),
        )["connected"]

        timeout = time.time() + 300
        while (
            unwrap(self.jobs.job_statuses)(self.jobs)["UPDATE_SCM"][0]["end_time"]
            is None
        ) and time.time() < timeout:
            time.sleep(3)

        account = unwrap(self.iam_account.get_account)(self.iam_account)
        control = next(
            c for c in account["controls"] if c["id"] == Control.CUSTOM.value
        )
        assert unwrap(self.partner.detach)(
            self.partner, partner=Control.CUSTOM, instance_id=control["instance_id"]
        )["status"]

    def test_evaluation_summary(self, unwrap):
        def _compare_keys(expected, actual):
            assert set(expected.keys()) == set(
                actual.keys()
            ), f"Keys are not the same {expected.keys()} {actual.keys()}"
            for key in expected.keys():
                if isinstance(expected[key], list) and isinstance(actual[key], list):
                    nested_expected = expected[key][0]
                    if not actual[key]:
                        continue
                    nested_actual = actual[key][0]
                elif isinstance(expected[key], dict) and isinstance(actual[key], dict):
                    nested_expected = expected[key]
                    nested_actual = actual[key]
                else:
                    continue
                _compare_keys(nested_expected, nested_actual)

        summary = unwrap(self.scm.evaluation_summary)(self.scm)
        assert summary.keys() == {
            "endpoint_summary",
            "inbox_summary",
            "network_device_summary",
            "user_summary",
        }

    def test_technique_summary(self, unwrap):
        summary = unwrap(self.scm.technique_summary)(self.scm, "T1078,T1027")
        assert len(summary) > 0
        assert {"instances", "technique"} == summary[0].keys()
        assert len(summary[0]["instances"]) > 0
        assert {
            "control",
            "excepted",
            "instance_id",
            "setting_count",
            "setting_misconfiguration_count",
        } == summary[0]["instances"][0].keys()
        assert {"setting_count", "setting_misconfiguration_count"} == summary[0][
            "instances"
        ][0]["excepted"].keys()

    def test_export_endpoints_csv(self, unwrap):
        job_id = unwrap(self.export.export_scm)(
            self.export,
            SCMCategory.ENDPOINT,
            filter="contains(hostname, 'i')",
            top=1,
        )["job_id"]
        while (result := unwrap(self.jobs.job_status)(self.jobs, job_id))[
            "end_time"
        ] is None:
            time.sleep(3)
        assert result["successful"], result
        csv = requests.get(result["results"]["url"], timeout=10).content.decode("utf-8")
        assert len(csv.strip("\r\n").split("\r\n")) == 2

    def test_setup_for_per_control(self, unwrap):
        timeout = time.time() + 300
        while (
            unwrap(self.jobs.job_statuses)(self.jobs)["UPDATE_SCM"][0]["end_time"]
            is None
        ) and time.time() < timeout:
            time.sleep(3)
        if time.time() >= timeout:
            assert False, "Timed out waiting for UPDATE_SCM jobs to complete"


@pytest.mark.order(9)
@pytest.mark.usefixtures("setup_account")
@pytest.mark.parametrize(
    "control",
    [c for c in Control if c.scm_category != SCMCategory.NONE and not c.parent],
)
class TestScmPerControl:
    def setup_class(self):
        if not pytest.expected_account["features"]["policy_evaluator"]:
            pytest.skip("POLICY_EVALUATOR feature not enabled")
        self.jobs = JobsController(pytest.account)
        self.partner = PartnerController(pytest.account)
        self.scm = ScmController(pytest.account)

    @pytest.fixture(scope="function", autouse=True)
    def setup_and_teardown(self, control):
        if control.value not in pytest.controls:
            pytest.skip(f"{control.name} not attached")
        yield

    def test_update_evaluation(self, unwrap, control):
        instance_id = pytest.controls.get(control.value)
        assert instance_id
        unwrap(self.scm.update_evaluation)(self.scm, control, instance_id)

    def test_evaluation(self, unwrap, control):
        def _wait_for_policies(control, instance_id, category):
            timeout = time.time() + 300
            while time.time() < timeout:
                evaluation = unwrap(self.scm.evaluation)(self.scm, control, instance_id)
                evaluation = evaluation[f"{category}_evaluation"]
                if len(evaluation["policies"]) > 0:
                    return evaluation
                time.sleep(5)
            assert False, "Timed out waiting for policies to show up in evaluation"

        instance_id = pytest.controls.get(control.value)
        assert instance_id
        evaluation = unwrap(self.scm.evaluation)(self.scm, control, instance_id)
        if "endpoint_evaluation" in evaluation:
            evaluation = evaluation["endpoint_evaluation"]
            assert {"policies"} == evaluation.keys()
            if (
                control.control_category == ControlCategory.XDR
                or control == Control.INTUNE
            ):
                evaluation = _wait_for_policies(control, instance_id, "endpoint")
                assert {
                    "excepted",
                    "id",
                    "name",
                    "platform",
                    "settings",
                    "conflict_count",
                    "endpoint_count",
                    "success_count",
                } == evaluation["policies"][0].keys()
            elif control == Control.INTEL_INTUNE:
                evaluation = _wait_for_policies(control, instance_id, "endpoint")
                assert {
                    "active_count",
                    "excepted",
                    "id",
                    "name",
                    "not_supported_count",
                    "supported_count",
                    "techniques",
                } == evaluation["policies"][0].keys()
            else:
                assert len(evaluation["policies"]) == 0
        elif "user_evaluation" in evaluation:
            evaluation = evaluation["user_evaluation"]
            assert {"policies"} == evaluation.keys()
            evaluation = _wait_for_policies(control, instance_id, "user")
            assert {"excepted", "id", "name", "settings", "user_count"} == evaluation[
                "policies"
            ][0].keys()
        elif "inbox_evaluation" in evaluation:
            evaluation = evaluation["inbox_evaluation"]
            assert {"policies"} == evaluation.keys()
            evaluation = _wait_for_policies(control, instance_id, "inbox")
            assert {"excepted", "id", "name", "settings", "inbox_count"} == evaluation[
                "policies"
            ][0].keys()
        else:
            assert False, "No evaluation returned"


@pytest.mark.order(9)
@pytest.mark.usefixtures("setup_account")
class TestScmGroups:
    def setup_class(self):
        if not pytest.expected_account["features"]["policy_evaluator"]:
            pytest.skip("POLICY_EVALUATOR feature not enabled")
        self.jobs = JobsController(pytest.account)
        self.partner = PartnerController(pytest.account)
        self.scm = ScmController(pytest.account)

    def test_groups(self, unwrap):
        control = Control.ENTRA
        if control.value not in pytest.controls:
            pytest.skip(f"{control.name} not attached")

        instance_id = pytest.controls.get(control.value)
        groups = unwrap(self.partner.partner_groups)(
            self.partner, partner=control, instance_id=instance_id
        )
        assert len(groups) > 0, "No groups found for the partner"
        group_id = "3af0324e-0cbe-491c-8d1b-98dba25ad500"
        assert group_id in [g["id"] for g in groups]

        job_id = unwrap(self.scm.update_partner_groups)(
            self.scm,
            partner=control,
            instance_id=instance_id,
            group_ids=[group_id],
        )["job_id"]
        while (result := unwrap(self.jobs.job_status)(self.jobs, job_id))[
            "end_time"
        ] is None:
            time.sleep(3)
        assert result["successful"]

        groups = unwrap(self.scm.list_partner_groups)(self.scm)
        actual = [dict(control=g["control"], group_id=g["group_id"]) for g in groups]
        expected = dict(control=control.value, group_id=group_id)
        assert expected in actual
