from datetime import datetime, timezone

from prelude_sdk.controllers.http_controller import HttpController
from prelude_sdk.models.account import verify_credentials
from prelude_sdk.models.codes import Control, ControlCategory


class PartnerController(HttpController):

    def __init__(self, account):
        super().__init__(account)

    @verify_credentials
    def attach(
        self,
        partner: Control,
        api: str,
        user: str,
        secret: str,
        name: str | None = None,
        instance_id: str | None = None,
    ):
        """Attach a partner to your account"""
        params = dict()
        if name:
            params["name"] = name
        if api:
            params["api"] = api
        if user:
            params["user"] = user
        if secret:
            params["secret"] = secret
        extra = f"/{instance_id}" if instance_id else ""

        res = self.post(f"{self.account.hq}/partner/{partner.name}{extra}", json=params)
        return res.json()

    @verify_credentials
    def detach(self, partner: Control, instance_id: str):
        """Detach a partner from your Detect account"""
        res = self.delete(
            f"{self.account.hq}/partner/{partner.name}/{instance_id}", timeout=30
        )
        return res.json()

    @verify_credentials
    def block(self, partner: Control, test_id: str):
        """Report to a partner to block a test"""
        params = dict(test_id=test_id)

        res = self.post(
            f"{self.account.hq}/partner/block/{partner.name}", json=params, timeout=30
        )
        return res.json()

    @verify_credentials
    def endpoints(
        self,
        partner: Control,
        platform: str,
        hostname: str = "",
        offset: int = 0,
        count: int = 100,
    ):
        """Get a list of endpoints from a partner"""
        params = dict(platform=platform, hostname=hostname, offset=offset, count=count)

        res = self.get(
            f"{self.account.hq}/partner/endpoints/{partner.name}",
            params=params,
            timeout=30,
        )
        return res.json()

    @verify_credentials
    def deploy(self, partner: Control, host_ids: list):
        """Deploy probes on all specified partner endpoints"""
        params = dict(host_ids=host_ids)

        res = self.post(
            f"{self.account.hq}/partner/deploy/{partner.name}", json=params, timeout=30
        )
        return res.json()

    @verify_credentials
    def list_reports(self, partner: Control, test_id: str | None):
        """Get reports to a partner for a test"""
        params = dict(test_id=test_id) if test_id else dict()

        res = self.get(
            f"{self.account.hq}/partner/reports/{partner.name}", json=params, timeout=30
        )
        return res.json()

    @verify_credentials
    def observed_detected(self, test_id: str | None = None, hours: int | None = None):
        """Get observed_detected stats"""
        params = dict()
        if test_id:
            params["test_id"] = test_id
        if hours:
            params["start_epoch_ms"] = (
                datetime.now(timezone.utc).timestamp() - hours * 60 * 60
            ) * 1000

        res = self.get(
            f"{self.account.hq}/partner/observed_detected", json=params, timeout=30
        )
        return res.json()

    @verify_credentials
    def list_advisories(
        self, partner: Control, start: str = None, limit: int = None, offset: int = None
    ):
        """Get advisory reports provided by a partner"""
        params = dict()
        if start:
            params["start"] = start
        if limit:
            params["limit"] = limit
        if offset:
            params["offset"] = offset

        res = self.get(
            f"{self.account.hq}/partner/advisories/{partner.name}",
            params=params,
            timeout=30,
        )
        return res.json()

    @verify_credentials
    def partner_groups(self, partner: Control, instance_id: str):
        """Get a list of partner groups"""
        res = self.get(
            f"{self.account.hq}/partner/groups/{partner.name}/{instance_id}", timeout=30
        )
        return res.json()

    @verify_credentials
    def attach_custom(
        self,
        config: dict,
        control_category: ControlCategory,
        control_name: str,
        secret: str,
        name: str | None = None,
        instance_id: str | None = None,
    ):
        """Attach a custom partner to your account"""
        body = dict()
        if config:
            body["config"] = config
        if control_category:
            body["control_category"] = control_category.value
        if control_name:
            body["control_name"] = control_name
        if name:
            body["name"] = name
        if secret:
            body["secret"] = secret
        extra = f"/{instance_id}" if instance_id else ""

        res = self.post(f"{self.account.hq}/partner-custom{extra}", json=body)
        return res.json()

    @verify_credentials
    def get_custom_partner(self, instance_id: str):
        """Get a custom partner from your account"""
        res = self.get(f"{self.account.hq}/partner-custom/{instance_id}")
        return res.json()

    @verify_credentials
    def get_custom_partner_data(
        self, config: dict, secret: str, save_data_as: str | None = None
    ):
        """Get data from a custom partner"""
        body = dict(config=config)
        if secret:
            body["secret"] = secret
        if save_data_as:
            body["save_data_as"] = save_data_as

        res = self.post(f"{self.account.hq}/partner-custom/data", json=body, timeout=30)
        return res.json()
