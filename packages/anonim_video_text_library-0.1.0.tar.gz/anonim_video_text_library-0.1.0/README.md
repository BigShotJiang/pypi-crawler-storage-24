# Anonim Video Text Library

Standalone project for two related tasks:
- video/audio transcription with diarization
- text/JSON/JSONL/CSV/Markdown anonymization with persistent `people.json` mappings

`Anonim_video_text_Library` is independent from `Anonim_video_text`. A user can take this folder alone and run it without importing code from the old project.

## Project layout

- `main.py`: video/audio transcription entrypoint
- `gpu_backends/`: GPU-related transcription helpers
- `text_anonim/`: text anonymization scripts, blocklists, `people.json`, input/output folders
- `src/anonim_video_text_library/`: importable Python package for the anonymizer
- `examples/`: small Python usage examples
- `whisper.cpp/`: local copy of whisper.cpp sources

## Install for another person

If someone else wants to use only the text anonymizer as a Python library or CLI:

```bash
cd Anonim_video_text_Library
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

If they also need the video/audio transcription part:

```bash
pip install -r requirements.txt
```

## Text anonymizer CLI

Run the local wrapper:

```bash
python3 text_anonim/anonimizer.py --help
```

Or run the package directly:

```bash
python3 -m anonim_video_text_library --help
```

Default runtime root is local to this project:

```text
Anonim_video_text_Library/text_anonim
```

So by default the anonymizer uses:
- `text_anonim/files/pii`
- `text_anonim/files/pii_anonymized`
- `text_anonim/files/pii/people.json`

Example:

```bash
python3 text_anonim/anonimizer.py \
  --input-root text_anonim/files/pii/youtrack \
  --output-root text_anonim/files/pii_anonymized \
  --device mps \
  --ner-batch-size 64 \
  --jsonl-ner-chunk-size 1000 \
  --skip-existing
```

## Python library usage

The simplest external API is `TextAnonymizationSession`.

```python
from pathlib import Path
from anonim_video_text_library import TextAnonymizationSession

project_root = Path('/path/to/Anonim_video_text_Library')
runtime_root = project_root / 'text_anonim'

session = TextAnonymizationSession.from_defaults(
    runtime_root=runtime_root,
    device='auto',
    ner_batch_size=16,
)

text, replacements = session.anonymize_text(
    'Anton from Doubletapp wrote to do.doubletapp@gmail.com',
    file_id='demo.txt',
)
print(text)
print(replacements)

payload, stats = session.anonymize_value(
    {
        'title': 'Anton Riabykh',
        'body': 'Doubletapp contact: do.doubletapp@gmail.com',
    },
    file_id='demo.json',
)
print(payload)
print(stats)

session.save_people()
```

Ready example file:

```bash
python3 examples/use_text_anonymizer.py
```

## Lower-level API

If needed, the package is split into modules:
- `constants.py`: regexes, defaults, shared constants
- `utils.py`: normalization and small helpers
- `registry.py`: `NameDictionary`, `TagRegistry`
- `anonymizer.py`: `PersonAnonymizer`, NER logic, name passes
- `pipeline.py`: text replacement pipeline pieces
- `processors.py`: `json/jsonl/csv/md` processors
- `people.py`: `people.json` load/save/merge helpers
- `session.py`: high-level library session for external users
- `app.py`: CLI argument parsing and pipeline runner
- `cli.py`: package entrypoint and runtime-root configuration

## Video/audio transcription

The transcription part is still available from this folder:

```bash
python3 main.py /path/to/call.mp4
```

For that part also see:
- `requirements.txt`
- `gpu_backends/README.md`
- `whisper.cpp/README.md`

## Notes

- `text_anonim/files` may contain large working datasets.
- `whisper.cpp/models/*.bin` files were not copied automatically during the standalone migration.
- `fairseq_env` was intentionally not copied; create a local virtual environment if needed.
