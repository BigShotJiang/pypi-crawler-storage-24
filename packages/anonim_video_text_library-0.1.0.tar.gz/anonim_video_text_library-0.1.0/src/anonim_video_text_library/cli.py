from __future__ import annotations

import os
from pathlib import Path

from . import constants


def discover_runtime_root(explicit_root: str | Path | None = None) -> Path:
    if explicit_root is not None:
        return Path(explicit_root).resolve()

    env_root = os.environ.get("ANONIM_VIDEO_TEXT_ROOT")
    if env_root:
        return Path(env_root).resolve()

    project_root = Path(__file__).resolve().parents[2]
    local_text_root = project_root / "text_anonim"
    if local_text_root.exists():
        return local_text_root.resolve()

    return Path.cwd().resolve()


def configure_default_paths(base_dir: str | Path | None = None) -> Path:
    runtime_root = discover_runtime_root(base_dir)
    constants.DEFAULT_INPUT_ROOT = runtime_root / "files" / "pii"
    constants.DEFAULT_OUTPUT_ROOT = runtime_root / "files" / "pii_anonymized"
    constants.DEFAULT_PEOPLE_FILE = constants.DEFAULT_INPUT_ROOT / "people.json"
    constants.DEFAULT_PERSON_BLOCKLIST_FILE = constants.DEFAULT_INPUT_ROOT / "person_blocklist.txt"
    constants.DEFAULT_PERSON_NAME_BLOCKLIST_FILE = constants.DEFAULT_INPUT_ROOT / "person_name_blocklist.txt"
    constants.DEFAULT_ORG_BLOCKLIST_FILE = constants.DEFAULT_INPUT_ROOT / "org_blocklist.txt"
    return runtime_root


def main() -> None:
    configure_default_paths()
    from .app import main as app_main

    app_main()


if __name__ == '__main__':
    main()
