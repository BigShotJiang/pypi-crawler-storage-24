from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, Dict, List, Tuple

from .anonymizer import PersonAnonymizer, run_name_entity_pipeline
from .constants import EMAIL_RE, EMAIL_TAG_RE, GLOBAL_PERSON_TAG_RE, ORG_TAG_RE, PHONE_RE, PHONE_TAG_RE, RESOURCE_TAG_RE
from .registry import TagRegistry
from .utils import (
    empty_stats,
    extract_person_base_tag,
    is_probable_phone_candidate,
    merge_stats,
    normalize_phone_key,
    normalize_url_key,
    split_url_token_and_suffix,
)

def anonymize_resources_in_text(text: str, registry: TagRegistry, file_id: str) -> Tuple[str, int]:
    if not text:
        return text, 0

    count = 0

    def _replace(match: re.Match[str]) -> str:
        nonlocal count
        raw = match.group("url")
        token = raw[1:-1] if raw.startswith("<") and raw.endswith(">") else raw
        token_core, token_suffix = split_url_token_and_suffix(token)
        if not token_core:
            return raw
        if RESOURCE_TAG_RE.fullmatch(token_core):
            return raw

        key = normalize_url_key(token_core)
        if not key:
            return raw

        tag = registry.get_resource_tag(key=key, example=token_core, file_id=file_id)
        count += 1
        return f"{tag}{token_suffix}"

    replaced = URL_RE.sub(_replace, text)
    return replaced, count


def anonymize_resources_in_value(
    value: Any,
    registry: TagRegistry,
    file_id: str,
) -> Tuple[Any, int]:
    if isinstance(value, str):
        return anonymize_resources_in_text(value, registry, file_id)

    if isinstance(value, list):
        out: List[Any] = []
        total = 0
        for item in value:
            new_item, count = anonymize_resources_in_value(item, registry, file_id)
            out.append(new_item)
            total += count
        return out, total

    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        total = 0
        for key, item in value.items():
            new_item, count = anonymize_resources_in_value(item, registry, file_id)
            out[key] = new_item
            total += count
        return out, total

    return value, 0


def anonymize_emails_in_text(text: str, registry: TagRegistry, file_id: str) -> Tuple[str, int]:
    if not text:
        return text, 0

    count = 0

    def _replace(match: re.Match[str]) -> str:
        nonlocal count
        prefix = match.group("prefix") or ""
        raw_email = match.group("email")
        suffix = match.group("suffix") or ""
        if EMAIL_TAG_RE.fullmatch(raw_email):
            return match.group(0)

        key = normalize_email_key(raw_email)
        if not key:
            return match.group(0)

        tag = registry.get_email_tag(key=key, example=raw_email, file_id=file_id)
        count += 1
        return f"{prefix}{tag}{suffix}"

    replaced = EMAIL_RE.sub(_replace, text)
    return replaced, count


def anonymize_emails_in_value(
    value: Any,
    registry: TagRegistry,
    file_id: str,
    skip_field_names: set[str] | None = None,
) -> Tuple[Any, int]:
    skip_field_names = skip_field_names or set()

    if isinstance(value, str):
        return anonymize_emails_in_text(value, registry, file_id)

    if isinstance(value, list):
        out: List[Any] = []
        total = 0
        for item in value:
            new_item, count = anonymize_emails_in_value(item, registry, file_id, skip_field_names=skip_field_names)
            out.append(new_item)
            total += count
        return out, total

    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        total = 0
        for key, item in value.items():
            if key in skip_field_names and isinstance(item, str):
                out[key] = item
                continue
            new_item, count = anonymize_emails_in_value(item, registry, file_id, skip_field_names=skip_field_names)
            out[key] = new_item
            total += count
        return out, total

    return value, 0


def anonymize_phones_in_text(text: str, registry: TagRegistry, file_id: str) -> Tuple[str, int]:
    if not text:
        return text, 0

    count = 0

    def _replace(match: re.Match[str]) -> str:
        nonlocal count
        raw = match.group(0)
        candidate = raw.strip()
        if PHONE_TAG_RE.fullmatch(candidate):
            return raw

        trailing_keep = ""
        date_prefix_match = re.search(r"^(?P<phone>.*\d)\s(?P<day>\d{1,2})$", candidate)
        trailing_text = match.string[match.end():]
        if date_prefix_match and re.match(r"^\.\d{1,2}\.\d{2,4}(?:\b|\\[nrt]|[\s<])?", trailing_text):
            candidate = date_prefix_match.group("phone").strip()
            trailing_keep = f" {date_prefix_match.group('day')}"

        if not is_probable_phone_candidate(candidate):
            return raw

        key = normalize_phone_key(candidate)
        if not key:
            return raw

        tag = registry.get_phone_tag(key=key, example=candidate, file_id=file_id)
        count += 1
        return f"{tag}{trailing_keep}"

    replaced = PHONE_RE.sub(_replace, text)
    return replaced, count


def anonymize_phones_in_value(
    value: Any,
    registry: TagRegistry,
    file_id: str,
) -> Tuple[Any, int]:
    if isinstance(value, str):
        return anonymize_phones_in_text(value, registry, file_id)

    if isinstance(value, list):
        out: List[Any] = []
        total = 0
        for item in value:
            new_item, count = anonymize_phones_in_value(item, registry, file_id)
            out.append(new_item)
            total += count
        return out, total

    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        total = 0
        for key, item in value.items():
            new_item, count = anonymize_phones_in_value(item, registry, file_id)
            out[key] = new_item
            total += count
        return out, total

    return value, 0


def anonymize_resources_and_emails_in_value(
    value: Any,
    registry: TagRegistry,
    file_id: str,
    skip_email_field_names: set[str] | None = None,
) -> Tuple[Any, Dict[str, int]]:
    skip_email_field_names = skip_email_field_names or set()
    stats = empty_stats()

    if isinstance(value, str):
        out, resource_replacements = anonymize_resources_in_text(value, registry, file_id)
        stats["resource"] += resource_replacements
        stats["replacements"] += resource_replacements
        out, email_replacements = anonymize_emails_in_text(out, registry, file_id)
        stats["email"] += email_replacements
        stats["replacements"] += email_replacements
        return out, stats

    if isinstance(value, list):
        out: List[Any] = []
        for item in value:
            new_item, item_stats = anonymize_resources_and_emails_in_value(
                item,
                registry,
                file_id,
                skip_email_field_names=skip_email_field_names,
            )
            out.append(new_item)
            merge_stats(stats, item_stats)
        return out, stats

    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for key, item in value.items():
            if isinstance(item, str):
                new_item, resource_replacements = anonymize_resources_in_text(item, registry, file_id)
                stats["resource"] += resource_replacements
                stats["replacements"] += resource_replacements
                if key not in skip_email_field_names:
                    new_item, email_replacements = anonymize_emails_in_text(new_item, registry, file_id)
                    stats["email"] += email_replacements
                    stats["replacements"] += email_replacements
                out[key] = new_item
                continue

            new_item, item_stats = anonymize_resources_and_emails_in_value(
                item,
                registry,
                file_id,
                skip_email_field_names=skip_email_field_names,
            )
            out[key] = new_item
            merge_stats(stats, item_stats)
        return out, stats

    return value, stats


def anonymize_usernames_in_value(
    value: Any,
    registry: TagRegistry,
) -> Tuple[Any, int]:
    if isinstance(value, str):
        return registry.replace_known_usernames_in_text(value)

    if isinstance(value, list):
        out: List[Any] = []
        total = 0
        for item in value:
            new_item, count = anonymize_usernames_in_value(item, registry)
            out.append(new_item)
            total += count
        return out, total

    if isinstance(value, dict):
        out: Dict[str, Any] = dict(value)
        replacements = 0

        # Determine base person tag from sibling fields already anonymized in first pass.
        base_tag = (
            extract_person_base_tag(out.get("display_name"))
            or extract_person_base_tag(out.get("name"))
            or extract_person_base_tag(out.get("full_name"))
        )

        raw_user_id = out.get("id")
        user_id = str(raw_user_id).strip() if isinstance(raw_user_id, (str, int)) else ""

        if base_tag and user_id:
            registry.register_user_id(user_id, base_tag)
        if not base_tag and user_id:
            base_tag = registry.resolve_user_id_tag(user_id)

        for field_name in ("username", "login"):
            raw_username = out.get(field_name)
            if not isinstance(raw_username, str) or not raw_username.strip():
                continue

            username_placeholder = registry.username_placeholder_for_raw(raw_username)
            if username_placeholder is None and base_tag:
                assigned_tag = registry.register_username(raw_username, base_tag)
                username_placeholder = f"{assigned_tag}_USERNAME"

            if username_placeholder is not None and raw_username != username_placeholder:
                out[field_name] = username_placeholder
                replacements += 1

        for key, item in out.items():
            new_item, count = anonymize_usernames_in_value(item, registry)
            out[key] = new_item
            replacements += count

        return out, replacements

    return value, 0


def anonymize_path_component_text(text: str, registry: TagRegistry, file_id: str) -> str:
    if not text:
        return text

    out, _ = anonymize_emails_in_text(text, registry, file_id)
    out, _ = registry.replace_known_organizations_in_text(out, file_id=file_id)
    out, _ = registry.replace_known_organization_token_variants_in_text(out, file_id=file_id)
    out, _ = registry.replace_known_persons_in_text(out, file_id=file_id)
    out, _ = anonymize_phones_in_text(out, registry, file_id)
    out, _ = registry.replace_known_usernames_in_text(out)
    return out or "_"


def anonymize_output_relative_path(rel_path: Path, registry: TagRegistry, file_id: str) -> Path:
    return anonymize_output_relative_path_with_counters(rel_path, registry, file_id, {})


def anonymize_output_relative_path_with_counters(
    rel_path: Path,
    registry: TagRegistry,
    file_id: str,
    email_file_counters: Dict[str, int],
) -> Path:
    parts = list(rel_path.parts)
    if not parts:
        return rel_path

    output_parts: List[str] = []
    for idx, part in enumerate(parts):
        is_last = idx == len(parts) - 1
        if is_last:
            parent_component = output_parts[-1] if output_parts else ""
            if (
                EMAIL_TAG_RE.fullmatch(parent_component)
                or GLOBAL_PERSON_TAG_RE.fullmatch(parent_component)
                or ORG_TAG_RE.fullmatch(parent_component)
            ):
                suffixes = Path(part).suffix
                parent_key = "/".join(output_parts)
                next_idx = email_file_counters.get(parent_key, 1)
                email_file_counters[parent_key] = next_idx + 1
                anonymized_stem = f"{parent_component}_FILE_{next_idx:03d}"
            else:
                suffixes = "".join(Path(part).suffixes)
                stem = part[:-len(suffixes)] if suffixes else part
                anonymized_stem = anonymize_path_component_text(stem, registry, file_id) if stem else stem
            output_parts.append(f"{anonymized_stem}{suffixes}")
            continue

        output_parts.append(anonymize_path_component_text(part, registry, file_id))

    return Path(*output_parts)


def apply_full_pipeline_to_value(
    value: Any,
    anonymizer: PersonAnonymizer,
    registry: TagRegistry,
    file_id: str,
    ner_batch_size: int,
) -> Tuple[Any, Dict[str, int]]:
    stats = empty_stats()

    anonymized, pre_stats = anonymize_resources_and_emails_in_value(
        value,
        registry,
        file_id,
        skip_email_field_names={"username", "login"},
    )
    merge_stats(stats, pre_stats)

    anonymizer.prewarm_ner_cache_for_values([anonymized], file_id=file_id, ner_batch_size=ner_batch_size)
    anonymized, name_stats = run_name_entity_pipeline(
        anonymized,
        anonymizer=anonymizer,
        file_id=file_id,
    )
    merge_stats(stats, name_stats)
    anonymized, phone_replacements = anonymize_phones_in_value(anonymized, registry, file_id)
    stats["phone"] += phone_replacements
    stats["replacements"] += phone_replacements
    anonymized, username_replacements = anonymize_usernames_in_value(anonymized, registry)
    stats["username"] += username_replacements
    stats["replacements"] += username_replacements
    anonymized, residual_email_replacements = anonymize_emails_in_value(anonymized, registry, file_id)
    stats["email"] += residual_email_replacements
    stats["replacements"] += residual_email_replacements

    return anonymized, stats


def build_csv_writer_kwargs(dialect: csv.Dialect | type[csv.Dialect]) -> Dict[str, Any]:
    delimiter = getattr(dialect, "delimiter", ",") or ","
    quotechar = getattr(dialect, "quotechar", '"') or '"'
    lineterminator = getattr(dialect, "lineterminator", "\r\n") or "\r\n"
    quoting = getattr(dialect, "quoting", csv.QUOTE_MINIMAL)
    escapechar = getattr(dialect, "escapechar", None)

    kwargs: Dict[str, Any] = {
        "delimiter": delimiter,
        "quotechar": quotechar,
        "lineterminator": lineterminator,
        "quoting": quoting,
        # Safe default for anonymized output even if source dialect was stricter.
        "doublequote": True,
    }
    if quoting == csv.QUOTE_NONE:
        kwargs["escapechar"] = escapechar or "\\"
    elif escapechar:
        kwargs["escapechar"] = escapechar

    return kwargs


