from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List

from .anonymizer import PersonAnonymizer, run_name_entity_pipeline
from .constants import PROCESS_EXTENSIONS
from .pipeline import (
    anonymize_emails_in_value,
    anonymize_phones_in_value,
    anonymize_resources_and_emails_in_value,
    anonymize_usernames_in_value,
    apply_full_pipeline_to_value,
    build_csv_writer_kwargs,
)
from .registry import TagRegistry
from .utils import empty_stats, merge_stats

def discover_input_files(
    input_root: Path,
    output_root: Path,
    people_file: Path,
) -> List[Path]:
    files: List[Path] = []
    input_root_resolved = input_root.resolve()
    output_root_resolved = output_root.resolve()
    people_file_resolved = people_file.resolve()
    output_root_inside_input = False
    if output_root_resolved != input_root_resolved:
        try:
            output_root_resolved.relative_to(input_root_resolved)
            output_root_inside_input = True
        except ValueError:
            output_root_inside_input = False

    for path in sorted(input_root.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix.lower() not in PROCESS_EXTENSIONS:
            continue
        if path.resolve() == people_file_resolved:
            continue
        # Prevent re-processing output files when output lives under input root.
        if output_root_inside_input:
            try:
                path.resolve().relative_to(output_root_resolved)
                continue
            except ValueError:
                pass
        files.append(path)
    return files


def process_json_file(
    input_path: Path,
    output_path: Path,
    file_id: str,
    anonymizer: PersonAnonymizer,
    registry: TagRegistry,
    dry_run: bool,
    ner_batch_size: int = 1,
) -> Dict[str, int]:
    payload = json.loads(input_path.read_text(encoding="utf-8"))
    anonymized, stats = apply_full_pipeline_to_value(
        value=payload,
        anonymizer=anonymizer,
        registry=registry,
        file_id=file_id,
        ner_batch_size=ner_batch_size,
    )

    if not dry_run:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            json.dumps(anonymized, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return stats


def process_csv_file(
    input_path: Path,
    output_path: Path,
    file_id: str,
    anonymizer: PersonAnonymizer,
    registry: TagRegistry,
    dry_run: bool,
    ner_batch_size: int = 1,
) -> Dict[str, int]:
    with input_path.open("r", encoding="utf-8-sig", newline="") as source:
        sample = source.read(4096)
        source.seek(0)

        try:
            dialect = csv.Sniffer().sniff(sample or ",", delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel

        rows = list(csv.reader(source, dialect=dialect))

    anonymized_rows, stats = apply_full_pipeline_to_value(
        value=rows,
        anonymizer=anonymizer,
        registry=registry,
        file_id=file_id,
        ner_batch_size=ner_batch_size,
    )

    if not dry_run:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with output_path.open("w", encoding="utf-8", newline="") as target:
            writer = csv.writer(target, **build_csv_writer_kwargs(dialect))
            for row in anonymized_rows:
                writer.writerow(row)

    return stats


def process_markdown_file(
    input_path: Path,
    output_path: Path,
    file_id: str,
    anonymizer: PersonAnonymizer,
    registry: TagRegistry,
    dry_run: bool,
    ner_batch_size: int = 1,
) -> Dict[str, int]:
    payload = input_path.read_text(encoding="utf-8")
    anonymized, stats = apply_full_pipeline_to_value(
        value=payload,
        anonymizer=anonymizer,
        registry=registry,
        file_id=file_id,
        ner_batch_size=ner_batch_size,
    )

    if not dry_run:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(str(anonymized), encoding="utf-8")

    return stats


def process_jsonl_file(
    input_path: Path,
    output_path: Path,
    file_id: str,
    anonymizer: PersonAnonymizer,
    registry: TagRegistry,
    dry_run: bool,
    progress_every_lines: int = 0,
    ner_batch_size: int = 1,
    jsonl_ner_chunk_size: int = 200,
) -> Dict[str, int]:
    stats = empty_stats()
    same_file = input_path.resolve() == output_path.resolve()
    temp_output_path = output_path.with_suffix(output_path.suffix + ".anontmp") if same_file else output_path

    writer = None
    line_no = 0
    pending_payloads: List[Any] = []

    chunk_size = max(1, int(jsonl_ner_chunk_size))

    def _process_pending_payloads() -> None:
        nonlocal pending_payloads
        if not pending_payloads:
            return

        prepared_payloads: List[Any] = []
        for payload in pending_payloads:
            prepared, pre_stats = anonymize_resources_and_emails_in_value(
                payload,
                registry,
                file_id,
                skip_email_field_names={"username", "login"},
            )
            merge_stats(stats, pre_stats)
            prepared_payloads.append(prepared)

        anonymizer.prewarm_ner_cache_for_values(
            prepared_payloads,
            file_id=file_id,
            ner_batch_size=ner_batch_size,
        )

        for payload in prepared_payloads:
            anonymized, obj_stats = run_name_entity_pipeline(
                payload,
                anonymizer=anonymizer,
                file_id=file_id,
            )
            merge_stats(stats, obj_stats)
            anonymized, phone_replacements = anonymize_phones_in_value(anonymized, registry, file_id)
            stats["phone"] += phone_replacements
            stats["replacements"] += phone_replacements
            anonymized, username_replacements = anonymize_usernames_in_value(anonymized, registry)
            stats["username"] += username_replacements
            stats["replacements"] += username_replacements
            anonymized, residual_email_replacements = anonymize_emails_in_value(anonymized, registry, file_id)
            stats["email"] += residual_email_replacements
            stats["replacements"] += residual_email_replacements
            if writer is not None:
                writer.write(json.dumps(anonymized, ensure_ascii=False) + "\n")

        pending_payloads = []

    try:
        with input_path.open("r", encoding="utf-8") as source:
            if not dry_run:
                temp_output_path.parent.mkdir(parents=True, exist_ok=True)
                writer = temp_output_path.open("w", encoding="utf-8")

            for line in source:
                line_no += 1
                stripped = line.strip()
                if not stripped:
                    _process_pending_payloads()
                    if writer is not None:
                        writer.write(line)
                    if progress_every_lines > 0 and line_no % progress_every_lines == 0:
                        print(
                            f"  [jsonl] {file_id}: lines={line_no} "
                            f"repl={stats['replacements']} invalid={stats['invalid_json_lines']}"
                        )
                    continue

                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    _process_pending_payloads()
                    stats["invalid_json_lines"] += 1
                    if writer is not None:
                        writer.write(line)
                    if progress_every_lines > 0 and line_no % progress_every_lines == 0:
                        print(
                            f"  [jsonl] {file_id}: lines={line_no} "
                            f"repl={stats['replacements']} invalid={stats['invalid_json_lines']}"
                        )
                    continue

                pending_payloads.append(payload)
                if len(pending_payloads) >= chunk_size:
                    _process_pending_payloads()

                if progress_every_lines > 0 and line_no % progress_every_lines == 0:
                    print(
                        f"  [jsonl] {file_id}: lines={line_no} "
                        f"repl={stats['replacements']} invalid={stats['invalid_json_lines']}"
                    )

            _process_pending_payloads()
    finally:
        if writer is not None:
            writer.close()

    if not dry_run and same_file:
        temp_output_path.replace(output_path)

    return stats


