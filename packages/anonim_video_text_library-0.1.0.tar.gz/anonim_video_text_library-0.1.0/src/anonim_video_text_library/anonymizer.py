from __future__ import annotations

from typing import Any, Dict, Iterable, List, Tuple

from .constants import DEFAULT_DEVICE, GAP_RE, HAS_LETTERS_RE, PLACEHOLDER_RE
from .registry import NameDictionary, TagRegistry
from .utils import (
    Span,
    build_person_blocked_signatures,
    empty_stats,
    extract_tokens,
    is_valid_person_key,
    is_valid_person_name_key,
    merge_stats,
    normalize_key,
    resolve_inference_device,
)

class PersonAnonymizer:
    def __init__(
        self,
        model_name: str,
        name_dict: NameDictionary,
        registry: TagRegistry,
        device: str = DEFAULT_DEVICE,
        min_score: float = 0.8,
        min_person_name_len: int = 2,
        person_blocked_words: set[str] | None = None,
        person_name_blocked_words: set[str] | None = None,
    ) -> None:
        self.name_dict = name_dict
        self.registry = registry
        self.min_score = min_score
        self.min_person_name_len = max(1, int(min_person_name_len))
        self.person_blocked_words = person_blocked_words or set()
        self.person_blocked_signatures = build_person_blocked_signatures(self.person_blocked_words)
        self.person_name_blocked_words = person_name_blocked_words or set()
        self.device_name, pipeline_device = resolve_inference_device(device)

        try:
            from transformers import AutoModelForTokenClassification, AutoTokenizer, pipeline
        except ModuleNotFoundError as exc:
            raise SystemExit(
                "Package 'transformers' is required. "
                "Install it in the active environment, for example: pip install transformers"
            ) from exc

        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForTokenClassification.from_pretrained(model_name)
        self.ner = pipeline(
            "ner",
            model=model,
            tokenizer=tokenizer,
            aggregation_strategy="none",
            device=pipeline_device,
        )

        self._candidate_cache: Dict[str, List[Span]] = {}
        self._cache_limit = 50_000

    @staticmethod
    def _iter_string_values(value: Any) -> Iterable[str]:
        if isinstance(value, str):
            yield value
            return
        if isinstance(value, list):
            for item in value:
                yield from PersonAnonymizer._iter_string_values(item)
            return
        if isinstance(value, dict):
            for key, item in value.items():
                if key in {"username", "login", "email"} and isinstance(item, str):
                    continue
                yield from PersonAnonymizer._iter_string_values(item)

    def prewarm_ner_cache_for_values(
        self,
        values: List[Any],
        file_id: str,
        ner_batch_size: int,
    ) -> None:
        if ner_batch_size <= 1:
            return
        if not values:
            return

        unique_texts: List[str] = []
        seen: set[str] = set()
        for value in values:
            for text in self._iter_string_values(value):
                if not text or not HAS_LETTERS_RE.search(text):
                    continue
                preprocessed, _ = self.registry.replace_known_organizations_in_text(text, file_id=file_id)
                preprocessed, _ = self.registry.replace_known_organization_token_variants_in_text(
                    preprocessed,
                    file_id=file_id,
                )
                preprocessed, _ = self.registry.replace_known_persons_in_text(preprocessed, file_id=file_id)
                if not preprocessed or not HAS_LETTERS_RE.search(preprocessed):
                    continue
                if preprocessed in self._candidate_cache:
                    continue
                if preprocessed in seen:
                    continue
                seen.add(preprocessed)
                unique_texts.append(preprocessed)

        self._warm_ner_cache_for_texts(unique_texts, ner_batch_size=ner_batch_size)

    def _warm_ner_cache_for_texts(self, texts: List[str], ner_batch_size: int) -> None:
        if not texts:
            return
        batch_size = max(1, int(ner_batch_size))

        for idx in range(0, len(texts), batch_size):
            batch_texts = texts[idx: idx + batch_size]
            try:
                raw_batch = self.ner(batch_texts, batch_size=batch_size)
            except TypeError:
                raw_batch = self.ner(batch_texts)

            raw_items: List[Any]
            if len(batch_texts) == 1:
                if (
                    isinstance(raw_batch, list)
                    and raw_batch
                    and isinstance(raw_batch[0], list)
                ):
                    raw_items = [raw_batch[0]]
                else:
                    raw_items = [raw_batch]
            else:
                if (
                    isinstance(raw_batch, list)
                    and len(raw_batch) == len(batch_texts)
                    and (not raw_batch or isinstance(raw_batch[0], list))
                ):
                    raw_items = raw_batch
                else:
                    raw_items = [self.ner(text) for text in batch_texts]

            for text, raw in zip(batch_texts, raw_items):
                spans = self._extract_ner_spans_from_raw(text, raw)
                spans.extend(self._extract_alias_spans(text))
                spans = self._resolve_overlaps(spans)
                if len(self._candidate_cache) >= self._cache_limit:
                    self._candidate_cache.clear()
                self._candidate_cache[text] = spans

    def anonymize_text(self, text: str, file_id: str) -> Tuple[str, List[Dict[str, str]]]:
        if not text or not HAS_LETTERS_RE.search(text):
            return text, []

        # Deterministic pass from existing people.json mappings first.
        preprocessed_text, known_org_replacements = self.registry.replace_known_organizations_in_text(text, file_id=file_id)
        preprocessed_text, known_org_variant_replacements = self.registry.replace_known_organization_token_variants_in_text(
            preprocessed_text,
            file_id=file_id,
        )
        preprocessed_text, known_person_replacements = self.registry.replace_known_persons_in_text(preprocessed_text, file_id=file_id)
        if not HAS_LETTERS_RE.search(preprocessed_text):
            return preprocessed_text, known_org_replacements + known_org_variant_replacements + known_person_replacements

        spans = self._candidate_cache.get(preprocessed_text)
        if spans is None:
            spans = self._extract_candidates(preprocessed_text)
            if len(self._candidate_cache) >= self._cache_limit:
                self._candidate_cache.clear()
            self._candidate_cache[preprocessed_text] = spans

        replacements: List[Dict[str, str]] = []
        out = preprocessed_text

        if spans:
            for span in reversed(spans):
                if span.kind == "full":
                    tag = self.registry.get_person_tag(span.key, span.text, file_id)
                elif span.kind == "org":
                    tag = self.registry.get_organization_tag(span.key, span.text, file_id)
                else:
                    tag = self.registry.get_file_name_tag(file_id, span.key, span.text)
                if not tag:
                    continue
                out = out[:span.start] + tag + out[span.end:]
                replacements.append(
                    {
                        "kind": span.kind,
                        "source": span.text,
                        "tag": tag,
                    }
                )
            replacements.reverse()

        # Post-model deterministic sweep for known single-name forms from people.json.
        out, post_name_replacements = self.registry.replace_known_single_names_in_text(out, file_id=file_id)
        replacements.extend(post_name_replacements)

        return out, known_org_replacements + known_org_variant_replacements + known_person_replacements + replacements

    def _extract_candidates(self, text: str) -> List[Span]:
        candidates: List[Span] = []
        candidates.extend(self._extract_ner_spans(text))
        candidates.extend(self._extract_alias_spans(text))
        return self._resolve_overlaps(candidates)

    def _extract_ner_spans(self, text: str) -> List[Span]:
        raw = self.ner(text)
        return self._extract_ner_spans_from_raw(text, raw)

    def _extract_ner_spans_from_raw(self, text: str, raw: Any) -> List[Span]:
        if isinstance(raw, dict):
            tokens_raw: List[Dict[str, Any]] = [raw]
        elif isinstance(raw, list):
            if raw and isinstance(raw[0], list):
                tokens_raw = [item for group in raw for item in group if isinstance(item, dict)]
            else:
                tokens_raw = [item for item in raw if isinstance(item, dict)]
        else:
            tokens_raw = []

        per_chunks: List[Tuple[int, int, float]] = []
        org_chunks: List[Tuple[int, int, float]] = []

        for token in tokens_raw:
            label = str(token.get("entity_group") or token.get("entity") or "")
            is_per = "PER" in label
            is_org = "ORG" in label
            if not is_per and not is_org:
                continue
            score = float(token.get("score", 0.0))
            if score < self.min_score:
                continue
            start = token.get("start")
            end = token.get("end")
            if start is None or end is None:
                continue
            chunk = (int(start), int(end), score)
            if is_per:
                per_chunks.append(chunk)
            if is_org:
                org_chunks.append(chunk)

        def _merge_chunks(chunks: List[Tuple[int, int, float]]) -> List[Tuple[int, int, float]]:
            chunks.sort(key=lambda x: x[0])
            if not chunks:
                return []
            merged: List[Tuple[int, int, float]] = []
            for start, end, score in chunks:
                if not merged:
                    merged.append((start, end, score))
                    continue
                p_start, p_end, p_score = merged[-1]
                gap = text[p_end:start]
                if start <= p_end + 3 and GAP_RE.fullmatch(gap):
                    merged[-1] = (p_start, max(p_end, end), min(p_score, score))
                else:
                    merged.append((start, end, score))
            return merged

        merged_per = _merge_chunks(per_chunks)
        merged_org = _merge_chunks(org_chunks)

        spans: List[Span] = []
        for start, end, _ in merged_per:
            s, e = self._trim_span(text, start, end)
            if s >= e:
                continue
            chunk = text[s:e]
            if PLACEHOLDER_RE.fullmatch(chunk.strip()):
                continue

            tokens = [t.lower() for t in extract_tokens(chunk)]
            if not tokens:
                continue

            kind = "full" if len(tokens) >= 2 else "name"
            key = self._build_key(tokens=tokens, kind=kind)
            if not key:
                continue
            spans.append(Span(start=s, end=e, kind=kind, key=key, text=chunk))

        for start, end, _ in merged_org:
            s, e = self._trim_span(text, start, end)
            if s >= e:
                continue
            chunk = text[s:e]
            if PLACEHOLDER_RE.fullmatch(chunk.strip()):
                continue

            tokens = [t.lower() for t in extract_tokens(chunk)]
            if not tokens:
                continue

            key = normalize_key(" ".join(tokens))
            if not key or not self.registry.is_valid_organization_key(key):
                continue
            spans.append(Span(start=s, end=e, kind="org", key=key, text=chunk))

        return spans

    def _extract_alias_spans(self, text: str) -> List[Span]:
        if self.name_dict.alias_regex is None:
            return []

        spans: List[Span] = []
        for match in self.name_dict.alias_regex.finditer(text):
            start, end = match.span(1)
            chunk = text[start:end]
            if PLACEHOLDER_RE.fullmatch(chunk.strip()):
                continue
            tokens = [t.lower() for t in extract_tokens(chunk)]
            if not tokens:
                continue
            key = self._build_key(tokens=tokens, kind="name")
            if not key:
                continue
            spans.append(Span(start=start, end=end, kind="name", key=key, text=chunk))
        return spans

    def _build_key(self, tokens: List[str], kind: str) -> str:
        if not tokens:
            return ""

        if kind == "name":
            candidate = self.name_dict.canonical_single_name(tokens[0])
            if not is_valid_person_name_key(
                key=candidate,
                min_len=self.min_person_name_len,
                blocked_words=self.person_name_blocked_words,
            ):
                return ""
            return candidate

        normalized = [normalize_key(t) for t in tokens if normalize_key(t)]
        if len(normalized) < 2:
            return self.name_dict.canonical_single_name(normalized[0]) if normalized else ""

        # Two-token normalization:
        # - Name Surname
        # - Surname Name
        if len(normalized) == 2:
            first, second = normalized
            first_is_name = first in self.name_dict.alias_to_canonical
            second_is_name = second in self.name_dict.alias_to_canonical

            if second_is_name and not first_is_name:
                # Likely "Surname Name"
                canonical_first = self.name_dict.alias_to_canonical[second]
                candidate = f"{canonical_first} {first}"
                if not is_valid_person_key(
                    key=candidate,
                    blocked_words=self.person_blocked_words,
                    blocked_signatures=self.person_blocked_signatures,
                ):
                    return ""
                return candidate

            canonical_first = self.name_dict.alias_to_canonical.get(first, first)
            candidate = f"{canonical_first} {second}"
            if not is_valid_person_key(
                key=candidate,
                blocked_words=self.person_blocked_words,
                blocked_signatures=self.person_blocked_signatures,
            ):
                return ""
            return candidate

        canonical_first = self.name_dict.alias_to_canonical.get(normalized[0], normalized[0])
        tail = normalized[1:]
        candidate = " ".join([canonical_first] + tail)
        if not is_valid_person_key(
            key=candidate,
            blocked_words=self.person_blocked_words,
            blocked_signatures=self.person_blocked_signatures,
        ):
            return ""
        return candidate

    @staticmethod
    def _trim_span(text: str, start: int, end: int) -> Tuple[int, int]:
        while start < end and text[start].isspace():
            start += 1
        while end > start and text[end - 1].isspace():
            end -= 1
        while start < end and text[start] in ",.;:()[]{}\"'":
            start += 1
        while end > start and text[end - 1] in ",.;:()[]{}\"'":
            end -= 1
        return start, end

    @staticmethod
    def _resolve_overlaps(candidates: List[Span]) -> List[Span]:
        if not candidates:
            return []

        kind_priority = {"full": 3, "org": 2, "name": 1}
        dedup: Dict[Tuple[int, int], Span] = {}
        for candidate in candidates:
            key = (candidate.start, candidate.end)
            existing = dedup.get(key)
            if existing is None:
                dedup[key] = candidate
                continue
            if kind_priority.get(candidate.kind, 0) > kind_priority.get(existing.kind, 0):
                dedup[key] = candidate

        sorted_candidates = sorted(
            dedup.values(),
            key=lambda item: (item.start, -(item.end - item.start)),
        )

        accepted: List[Span] = []
        for candidate in sorted_candidates:
            has_overlap = False
            for chosen in accepted:
                if not (candidate.end <= chosen.start or candidate.start >= chosen.end):
                    has_overlap = True
                    break
            if not has_overlap:
                accepted.append(candidate)

        accepted.sort(key=lambda x: x.start)
        return accepted


def anonymize_value(
    value: Any,
    anonymizer: PersonAnonymizer,
    file_id: str,
) -> Tuple[Any, Dict[str, int]]:
    stats = empty_stats()

    if isinstance(value, str):
        stats["strings"] = 1
        replaced, items = anonymizer.anonymize_text(value, file_id=file_id)
        stats["replacements"] = len(items)
        for item in items:
            if item["kind"] == "full":
                stats["person"] += 1
            elif item["kind"] == "org":
                stats["organization"] += 1
            else:
                stats["person_name"] += 1
        return replaced, stats

    if isinstance(value, list):
        out: List[Any] = []
        for item in value:
            new_item, item_stats = anonymize_value(item, anonymizer, file_id)
            out.append(new_item)
            merge_stats(stats, item_stats)
        return out, stats

    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for key, item in value.items():
            if key in {"username", "login", "email"} and isinstance(item, str):
                out[key] = item
                continue
            new_item, item_stats = anonymize_value(item, anonymizer, file_id)
            out[key] = new_item
            merge_stats(stats, item_stats)
        return out, stats

    return value, stats


def run_name_entity_pipeline(
    value: Any,
    anonymizer: PersonAnonymizer,
    file_id: str,
) -> Tuple[Any, Dict[str, int]]:
    stats = empty_stats()

    # Pass 1: people.json pre-pass + model.
    out, pass1_stats = anonymize_value(value, anonymizer, file_id)
    merge_stats(stats, pass1_stats)

    # Pass 2: run again with enriched dictionaries from pass 1.
    out, pass2_stats = anonymize_value(out, anonymizer, file_id)
    merge_stats(stats, pass2_stats)

    return out, stats


