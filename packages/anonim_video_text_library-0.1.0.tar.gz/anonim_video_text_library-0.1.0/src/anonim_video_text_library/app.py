from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Dict

from . import constants
from .anonymizer import PersonAnonymizer
from .constants import PROCESS_EXTENSIONS
from .people import load_people_data, merge_person_tags_in_people_data, save_people_data
from .pipeline import anonymize_output_relative_path_with_counters
from .processors import discover_input_files, process_csv_file, process_json_file, process_jsonl_file, process_markdown_file
from .registry import NameDictionary, TagRegistry
from .utils import empty_stats, load_word_list, merge_stats

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Anonymize names in JSON/JSONL/CSV/Markdown using multilingual NER. "
            "Full names => PERSON_XXX (global), "
            "single names => PERSON_NAME_XXX (per-file), "
            "organizations => ORG_XXX, "
            "usernames/logins => PERSON_XXX_USERNAME, "
            "links => RESOURCE_XXX, phones => PHONE_XXX, emails => EMAIL_XXX. "
            "Use --device to run NER on CPU/CUDA/MPS."
        )
    )
    parser.add_argument("--input-root", type=Path, default=constants.DEFAULT_INPUT_ROOT)
    parser.add_argument("--output-root", type=Path, default=constants.DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--people-file", type=Path, default=constants.DEFAULT_PEOPLE_FILE)
    parser.add_argument("--person-blocklist-file", type=Path, default=constants.DEFAULT_PERSON_BLOCKLIST_FILE)
    parser.add_argument("--person-name-blocklist-file", type=Path, default=constants.DEFAULT_PERSON_NAME_BLOCKLIST_FILE)
    parser.add_argument("--org-blocklist-file", type=Path, default=constants.DEFAULT_ORG_BLOCKLIST_FILE)
    parser.add_argument("--min-person-name-len", type=int, default=2)
    parser.add_argument("--device", type=str, default=constants.DEFAULT_DEVICE, choices=["auto", "cpu", "cuda", "mps"])
    parser.add_argument("--model-name", type=str, default=constants.DEFAULT_MODEL_NAME)
    parser.add_argument("--min-score", type=float, default=0.8)
    parser.add_argument(
        "--ner-batch-size",
        type=int,
        default=16,
        help="NER inference batch size (safe batching, tags still assigned sequentially).",
    )
    parser.add_argument(
        "--jsonl-ner-chunk-size",
        type=int,
        default=200,
        help="How many valid JSONL objects to prewarm per chunk for batched NER.",
    )
    parser.add_argument("--max-files", type=int, default=0, help="0 = all files")
    parser.add_argument(
        "--jsonl-progress-every",
        type=int,
        default=0,
        help="Print in-file JSONL progress every N lines (0 = disabled).",
    )
    parser.add_argument(
        "--merge-person",
        nargs=2,
        metavar=("TARGET_TAG", "SOURCE_TAG"),
        help=(
            "Merge SOURCE_TAG into TARGET_TAG in people.json and exit. "
            "Also rewrites username/user_id references to target tag."
        ),
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--skip-existing", action="store_true")
    parser.add_argument("--progress-every", type=int, default=1)
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    input_root = args.input_root.resolve()
    output_root = args.output_root.resolve()
    people_file = args.people_file.resolve()
    person_blocklist_file = args.person_blocklist_file.resolve()
    person_name_blocklist_file = args.person_name_blocklist_file.resolve()
    org_blocklist_file = args.org_blocklist_file.resolve()

    if args.merge_person:
        people_data = load_people_data(people_file)
        target_tag, source_tag = args.merge_person
        changed, message = merge_person_tags_in_people_data(
            people_data=people_data,
            target_tag=target_tag,
            source_tag=source_tag,
        )

        print(message)
        if not changed:
            return

        if args.dry_run:
            print("Dry-run: people.json not changed.")
            return

        people_file.parent.mkdir(parents=True, exist_ok=True)
        people_file.write_text(
            json.dumps(people_data, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        print(f"Updated people map:   {people_file}")
        return

    if not input_root.exists():
        raise SystemExit(f"Input root not found: {input_root}")

    input_files = discover_input_files(input_root, output_root, people_file)
    if args.max_files > 0:
        input_files = input_files[: args.max_files]

    if not input_files:
        supported_exts = ", ".join(sorted(PROCESS_EXTENSIONS))
        print(f"No supported files found under: {input_root} (extensions: {supported_exts})")
        return

    name_dict = NameDictionary(alias_to_canonical={})
    print("Names dictionary: disabled (people.json-only mode)")

    people_data = load_people_data(people_file)
    print(f"Using people mapping file: {people_file}")
    person_blocked_words = load_word_list(person_blocklist_file)
    print(
        f"Person filters: blocked_words={len(person_blocked_words)} "
        f"({person_blocklist_file})"
    )
    person_name_blocked_words = load_word_list(person_name_blocklist_file)
    print(
        f"Person-name filters: min_len={max(1, int(args.min_person_name_len))}, "
        f"blocked_words={len(person_name_blocked_words)} "
        f"({person_name_blocklist_file})"
    )
    organization_blocked_words = load_word_list(org_blocklist_file)
    print(
        f"Organization filters: blocked_words={len(organization_blocked_words)} "
        f"({org_blocklist_file})"
    )

    print(f"Loading NER model: {args.model_name}")
    registry = TagRegistry(
        people_data=people_data,
        min_person_name_len=args.min_person_name_len,
        person_blocked_words=person_blocked_words,
        person_name_blocked_words=person_name_blocked_words,
        organization_blocked_words=organization_blocked_words,
    )
    anonymizer = PersonAnonymizer(
        model_name=args.model_name,
        name_dict=name_dict,
        registry=registry,
        device=args.device,
        min_score=args.min_score,
        min_person_name_len=args.min_person_name_len,
        person_blocked_words=person_blocked_words,
        person_name_blocked_words=person_name_blocked_words,
    )
    print(f"NER device: {anonymizer.device_name}")
    print(
        f"NER batching: batch_size={max(1, int(args.ner_batch_size))}, "
        f"jsonl_chunk={max(1, int(args.jsonl_ner_chunk_size))}"
    )

    print(f"Files to process: {len(input_files)}")
    if not args.dry_run:
        output_root.mkdir(parents=True, exist_ok=True)

    total_stats = empty_stats()
    email_file_counters: Dict[str, int] = {}

    for idx, path in enumerate(input_files, start=1):
        rel_path = path.relative_to(input_root)
        file_id = rel_path.as_posix()
        out_rel_path = anonymize_output_relative_path_with_counters(
            rel_path,
            registry,
            file_id=file_id,
            email_file_counters=email_file_counters,
        )
        out_path = output_root / out_rel_path

        if args.skip_existing and out_path.exists():
            continue

        suffix = path.suffix.lower()
        file_started = time.perf_counter()
        if suffix == ".jsonl":
            current_stats = process_jsonl_file(
                input_path=path,
                output_path=out_path,
                file_id=file_id,
                anonymizer=anonymizer,
                registry=registry,
                dry_run=args.dry_run,
                progress_every_lines=max(0, int(args.jsonl_progress_every)),
                ner_batch_size=max(1, int(args.ner_batch_size)),
                jsonl_ner_chunk_size=max(1, int(args.jsonl_ner_chunk_size)),
            )
        elif suffix == ".csv":
            current_stats = process_csv_file(
                input_path=path,
                output_path=out_path,
                file_id=file_id,
                anonymizer=anonymizer,
                registry=registry,
                dry_run=args.dry_run,
                ner_batch_size=max(1, int(args.ner_batch_size)),
            )
        elif suffix == ".md":
            current_stats = process_markdown_file(
                input_path=path,
                output_path=out_path,
                file_id=file_id,
                anonymizer=anonymizer,
                registry=registry,
                dry_run=args.dry_run,
                ner_batch_size=max(1, int(args.ner_batch_size)),
            )
        else:
            current_stats = process_json_file(
                input_path=path,
                output_path=out_path,
                file_id=file_id,
                anonymizer=anonymizer,
                registry=registry,
                dry_run=args.dry_run,
                ner_batch_size=max(1, int(args.ner_batch_size)),
            )
        file_elapsed = time.perf_counter() - file_started

        merge_stats(total_stats, current_stats)

        if idx % max(1, args.progress_every) == 0 or idx == len(input_files):
            print(
                f"[{idx}/{len(input_files)}] {file_id} | "
                f"repl={current_stats['replacements']} "
                f"(PERSON={current_stats['person']}, "
                f"PERSON_NAME={current_stats['person_name']}, "
                f"ORG={current_stats['organization']}, "
                f"USERNAME={current_stats['username']}, "
                f"RESOURCE={current_stats['resource']}, "
                f"PHONE={current_stats['phone']}, "
                f"EMAIL={current_stats['email']}) "
                f"time={file_elapsed:.1f}s"
            )

    people_changed = False
    if not args.dry_run:
        people_changed = save_people_data(people_file=people_file, registry=registry)

    print("\nDone")
    print(f"Total strings scanned: {total_stats['strings']}")
    print(f"Total replacements:   {total_stats['replacements']}")
    print(f"  PERSON:             {total_stats['person']}")
    print(f"  PERSON_NAME:        {total_stats['person_name']}")
    print(f"  ORG:                {total_stats['organization']}")
    print(f"  USERNAME:           {total_stats['username']}")
    print(f"  RESOURCE:           {total_stats['resource']}")
    print(f"  PHONE:              {total_stats['phone']}")
    print(f"  EMAIL:              {total_stats['email']}")
    print(f"Invalid JSONL lines:  {total_stats['invalid_json_lines']}")
    print(f"Unique PERSON tags:   {len(registry.person_key_to_tag)}")
    print(f"Files with PERSON_NAME tags: {len(registry.file_name_key_to_tag)}")
    print(f"Unique ORG tags:      {len(registry.organization_tag_meta)}")
    print(f"Unique PHONE tags:    {len(registry.phone_tag_meta)}")
    print(f"Unique EMAIL tags:    {len(registry.email_tag_meta)}")
    if not args.dry_run:
        print(f"Output written to:    {output_root}")
        if people_changed:
            print(f"Updated people map:   {people_file}")
        else:
            print(f"People map unchanged: {people_file}")

