from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Tuple

from .constants import PERSON_TAG_RE
from .registry import TagRegistry

def load_people_data(people_file: Path) -> Dict[str, Any]:
    if not people_file.exists():
        return {}
    try:
        raw = json.loads(people_file.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(
            f"people.json is invalid JSON and will not be overwritten: {people_file}\n"
            f"Fix the file or move it aside, then run again."
        ) from exc
    if not isinstance(raw, dict):
        raise SystemExit(
            f"people.json must contain a JSON object at top level: {people_file}"
        )
    return raw


def save_people_data(people_file: Path, registry: TagRegistry) -> bool:
    people_file.parent.mkdir(parents=True, exist_ok=True)
    payload = registry.export_people_json()
    text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"

    if people_file.exists():
        current = people_file.read_text(encoding="utf-8")
        if current == text:
            return False

    people_file.write_text(text, encoding="utf-8")
    return True


def merge_person_tags_in_people_data(
    people_data: Dict[str, Any],
    target_tag: str,
    source_tag: str,
) -> Tuple[bool, str]:
    target_tag = target_tag.strip()
    source_tag = source_tag.strip()

    if not PERSON_TAG_RE.fullmatch(target_tag):
        raise SystemExit(f"Target tag is invalid: {target_tag}")
    if not PERSON_TAG_RE.fullmatch(source_tag):
        raise SystemExit(f"Source tag is invalid: {source_tag}")
    if target_tag == source_tag:
        return False, f"No changes: target and source are identical ({target_tag})."

    person_section = people_data.setdefault("person", {})
    if not isinstance(person_section, dict):
        raise SystemExit("people.json field 'person' must be a JSON object.")

    source_meta_raw = person_section.get(source_tag)
    if source_meta_raw is None:
        return False, f"No changes: source tag {source_tag} not found in people.json."

    source_meta = source_meta_raw if isinstance(source_meta_raw, dict) else {}
    target_meta_raw = person_section.get(target_tag)
    target_meta = target_meta_raw if isinstance(target_meta_raw, dict) else {}

    def _list_of_strings(value: Any) -> List[str]:
        if not isinstance(value, list):
            return []
        out: List[str] = []
        for item in value:
            text = str(item).strip()
            if text:
                out.append(text)
        return out

    target_key = str(target_meta.get("key", "")).strip()
    source_key = str(source_meta.get("key", "")).strip()
    merged_key = target_key or source_key

    merged_examples = set(_list_of_strings(target_meta.get("examples")))
    merged_examples.update(_list_of_strings(source_meta.get("examples")))
    if source_key and source_key != merged_key:
        merged_examples.add(source_key)

    merged_files = set(_list_of_strings(target_meta.get("files")))
    merged_files.update(_list_of_strings(source_meta.get("files")))

    person_section[target_tag] = {
        "key": merged_key,
        "examples": sorted(merged_examples),
        "files": sorted(merged_files),
    }
    person_section.pop(source_tag, None)

    username_updates = 0
    username_section = people_data.get("username")
    if isinstance(username_section, dict):
        for username, tag in list(username_section.items()):
            if tag == source_tag:
                username_section[username] = target_tag
                username_updates += 1

    user_id_updates = 0
    user_id_section = people_data.get("user_id")
    if isinstance(user_id_section, dict):
        for user_id, tag in list(user_id_section.items()):
            if tag == source_tag:
                user_id_section[user_id] = target_tag
                user_id_updates += 1

    return (
        True,
        (
            f"Merged {source_tag} -> {target_tag}. "
            f"examples={len(merged_examples)}, files={len(merged_files)}, "
            f"username_refs_updated={username_updates}, user_id_refs_updated={user_id_updates}"
        ),
    )


