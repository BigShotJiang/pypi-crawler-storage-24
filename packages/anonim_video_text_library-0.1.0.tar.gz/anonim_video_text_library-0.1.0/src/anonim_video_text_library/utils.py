from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple
from urllib.parse import urlsplit, urlunsplit

from .constants import CYRILLIC_TO_LATIN, NON_WORDS_RE, PERSON_TAG_RE, PERSON_USERNAME_TAG_RE

class Span:
    start: int
    end: int
    kind: str  # "full" | "name" | "org"
    key: str
    text: str


def empty_stats() -> Dict[str, int]:
    return {
        "strings": 0,
        "replacements": 0,
        "person": 0,
        "person_name": 0,
        "organization": 0,
        "username": 0,
        "resource": 0,
        "phone": 0,
        "email": 0,
        "invalid_json_lines": 0,
    }


def merge_stats(dst: Dict[str, int], src: Dict[str, int]) -> None:
    for key in dst:
        dst[key] += src.get(key, 0)


def normalize_spaces(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def normalize_key(text: str) -> str:
    cleaned = NON_WORDS_RE.sub(" ", text).replace("_", " ")
    cleaned = normalize_spaces(cleaned)
    return cleaned.lower()


def transliterate_cyrillic_to_latin(text: str) -> str:
    if not text:
        return ""
    out: List[str] = []
    for ch in text:
        out.append(CYRILLIC_TO_LATIN.get(ch, ch))
    return "".join(out)


def build_person_signature(text: str) -> str:
    """
    Signature used to merge/resolve full-name variants across scripts.
    Example: "anton рябых" and "anton ryabykh" -> "anton ryabykh".
    """
    normalized = normalize_key(text)
    if not normalized:
        return ""

    tokens = [token for token in normalized.split() if token]
    if len(tokens) < 2:
        return ""

    latin_tokens = [transliterate_cyrillic_to_latin(token) for token in tokens]
    if len(latin_tokens) == 2:
        latin_tokens = sorted(latin_tokens)
    return " ".join(latin_tokens)


def normalize_username_key(text: str) -> str:
    return normalize_spaces(text).lower()


def extract_person_base_tag(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    candidate = value.strip()
    if PERSON_TAG_RE.fullmatch(candidate):
        return candidate
    match = PERSON_USERNAME_TAG_RE.fullmatch(candidate)
    if match:
        return match.group(1)
    return None


def normalize_url_key(url: str) -> str:
    candidate = url.strip().strip("<>").strip()
    if not candidate:
        return ""
    if candidate.startswith("www."):
        candidate = f"http://{candidate}"

    try:
        parsed = urlsplit(candidate)
    except ValueError:
        # Keep malformed URLs processable (e.g. broken IPv6 host parts) without crashing.
        return candidate.lower()
    if not parsed.scheme:
        return candidate.lower()

    normalized = urlunsplit(
        (
            parsed.scheme.lower(),
            parsed.netloc.lower(),
            parsed.path,
            parsed.query,
            parsed.fragment,
        )
    )
    return normalized


def normalize_phone_key(phone: str) -> str:
    candidate = str(phone).strip()
    if not candidate:
        return ""

    digits = "".join(ch for ch in candidate if ch.isdigit())
    if not digits:
        return ""

    if candidate.startswith("+"):
        return f"+{digits}"
    return digits


def is_probable_phone_candidate(text: str) -> bool:
    candidate = str(text).strip()
    if not candidate:
        return False

    digits = "".join(ch for ch in candidate if ch.isdigit())
    if len(digits) < 10 or len(digits) > 15:
        return False

    is_plain_digits = bool(re.fullmatch(r"\+?\d+", candidate))
    has_plus = candidate.startswith("+")
    has_formatting = bool(re.search(r"[\s()\-]", candidate))

    # Reject long raw integers like timestamps. Bare numbers are only accepted
    # for common local phone lengths; longer variants must have an explicit
    # phone-like format (`+`, spaces, parentheses, dashes).
    if is_plain_digits and not has_plus and len(digits) not in {10, 11}:
        return False
    if len(digits) >= 12 and not (has_plus or has_formatting):
        return False

    return True


def normalize_email_key(email: str) -> str:
    candidate = str(email).strip().lower()
    if candidate.startswith("mailto:"):
        candidate = candidate[len("mailto:"):].strip()
    return candidate


def split_url_token_and_suffix(url_token: str) -> Tuple[str, str]:
    core = url_token
    suffix = ""
    while core and core[-1] in URL_TRAILING_PUNCT:
        suffix = core[-1] + suffix
        core = core[:-1]
    return core, suffix


def resolve_inference_device(requested_device: str) -> Tuple[str, int | str]:
    req = (requested_device or "auto").strip().lower()
    if req not in {"auto", "cpu", "cuda", "mps"}:
        raise SystemExit(f"Unsupported device '{requested_device}'. Use one of: auto, cpu, cuda, mps")

    try:
        import torch
    except ModuleNotFoundError:
        if req in {"cuda", "mps"}:
            print("Warning: torch is not installed, falling back to CPU.")
        return "cpu", -1

    has_cuda = torch.cuda.is_available()
    has_mps = bool(
        getattr(torch.backends, "mps", None)
        and torch.backends.mps.is_available()
    )

    if req == "auto":
        if has_cuda:
            return "cuda", 0
        if has_mps:
            return "mps", "mps"
        return "cpu", -1

    if req == "cuda":
        if has_cuda:
            return "cuda", 0
        print("Warning: CUDA requested but unavailable, falling back to CPU.")
        return "cpu", -1

    if req == "mps":
        if has_mps:
            return "mps", "mps"
        print("Warning: MPS requested but unavailable, falling back to CPU.")
        return "cpu", -1

    return "cpu", -1


def load_word_list(path: Path) -> set[str]:
    if not path.exists():
        return set()

    words: set[str] = set()
    with path.open("r", encoding="utf-8") as f:
        for raw_line in f:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            words.add(normalize_key(line))
    return {word for word in words if word}


def is_valid_person_name_key(key: str, min_len: int, blocked_words: set[str]) -> bool:
    normalized = normalize_key(key)
    if not normalized:
        return False
    if len(normalized) < min_len:
        return False
    if normalized in blocked_words:
        return False
    return True


def build_person_blocked_signatures(blocked_words: set[str]) -> set[str]:
    signatures: set[str] = set()
    for raw in blocked_words:
        sig = build_person_signature(raw)
        if sig:
            signatures.add(sig)
    return signatures


def is_valid_person_key(
    key: str,
    blocked_words: set[str],
    blocked_signatures: set[str],
) -> bool:
    normalized = normalize_key(key)
    if not normalized:
        return False
    if normalized in blocked_words:
        return False
    signature = build_person_signature(normalized)
    if signature and signature in blocked_signatures:
        return False
    return True


def is_valid_organization_key(key: str, blocked_words: set[str]) -> bool:
    normalized = normalize_key(key)
    if not normalized:
        return False
    if normalized in blocked_words:
        return False
    tokens = [token for token in normalized.split() if token]
    if not tokens:
        return False
    if len(tokens) == 1 and len(tokens[0]) < 3:
        return False
    if max((len(token) for token in tokens), default=0) < 3:
        return False
    return True


def compact_org_token(text: str) -> str:
    return "".join(ch.lower() for ch in str(text) if ch.isalnum())


def extract_tokens(text: str) -> List[str]:
    return TOKEN_RE.findall(text)


def sort_by_numeric_suffix(tags: Iterable[str]) -> List[str]:
    def sort_key(tag: str) -> Tuple[int, str]:
        try:
            return int(tag.rsplit("_", 1)[-1]), tag
        except ValueError:
            return 10**9, tag

    return sorted(tags, key=sort_key)


