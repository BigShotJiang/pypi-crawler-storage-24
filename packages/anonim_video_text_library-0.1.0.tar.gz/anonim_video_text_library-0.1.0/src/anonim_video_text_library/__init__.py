from .anonymizer import PersonAnonymizer, run_name_entity_pipeline
from .people import load_people_data, merge_person_tags_in_people_data, save_people_data
from .pipeline import apply_full_pipeline_to_value
from .processors import (
    process_csv_file,
    process_json_file,
    process_jsonl_file,
    process_markdown_file,
)
from .registry import NameDictionary, TagRegistry
from .session import TextAnonymizationSession


def configure_default_paths(*args, **kwargs):
    from .cli import configure_default_paths as _configure_default_paths

    return _configure_default_paths(*args, **kwargs)


def main() -> None:
    from .cli import main as _main

    _main()


__all__ = [
    "configure_default_paths",
    "main",
    "NameDictionary",
    "PersonAnonymizer",
    "TagRegistry",
    "TextAnonymizationSession",
    "apply_full_pipeline_to_value",
    "load_people_data",
    "save_people_data",
    "merge_person_tags_in_people_data",
    "process_csv_file",
    "process_json_file",
    "process_jsonl_file",
    "process_markdown_file",
    "run_name_entity_pipeline",
]
