from __future__ import annotations

import re
from pathlib import Path

DEFAULT_MODEL_NAME = "Babelscape/wikineural-multilingual-ner"
DEFAULT_INPUT_ROOT = Path(__file__).resolve().parent / "files" / "pii"
DEFAULT_OUTPUT_ROOT = Path(__file__).resolve().parent / "files" / "pii_anonymized"
DEFAULT_PEOPLE_FILE = DEFAULT_INPUT_ROOT / "people.json"
DEFAULT_PERSON_BLOCKLIST_FILE = DEFAULT_INPUT_ROOT / "person_blocklist.txt"
DEFAULT_PERSON_NAME_BLOCKLIST_FILE = DEFAULT_INPUT_ROOT / "person_name_blocklist.txt"
DEFAULT_ORG_BLOCKLIST_FILE = DEFAULT_INPUT_ROOT / "org_blocklist.txt"
DEFAULT_DEVICE = "mps"

PROCESS_EXTENSIONS = {".json", ".jsonl", ".csv", ".md"}

HAS_LETTERS_RE = re.compile(r"[A-Za-zА-Яа-яЁё]")
TOKEN_RE = re.compile(r"[A-Za-zА-Яа-яЁё][A-Za-zА-Яа-яЁё'\-]*", flags=re.UNICODE)
GAP_RE = re.compile(r"^[\s\-.']*$", flags=re.UNICODE)
PLACEHOLDER_RE = re.compile(r"^(?:PERSON(?:_NAME)?|ORG|RESOURCE|PHONE|EMAIL)_\d+(?:_USERNAME)?$")
PERSON_TAG_RE = re.compile(r"^PERSON(?:_NAME)?_\d+$")
GLOBAL_PERSON_TAG_RE = re.compile(r"^PERSON_\d+$")
PERSON_USERNAME_TAG_RE = re.compile(r"^(PERSON(?:_NAME)?_\d+)_USERNAME$")
ORG_TAG_RE = re.compile(r"^ORG_\d+$")
RESOURCE_TAG_RE = re.compile(r"^RESOURCE_\d+$")
PHONE_TAG_RE = re.compile(r"^PHONE_\d+$")
EMAIL_TAG_RE = re.compile(r"^EMAIL_\d+$")
URL_RE = re.compile(r'(?P<url><https?://[^>\s]+>|(?:https?://|www\.)[^\s<>"\']+)', flags=re.IGNORECASE)
URL_TRAILING_PUNCT = ",.;:!?)\\]}"
PHONE_RE = re.compile(r"(?<!\w)(?:\+?\d[\d\s()\-]{7,}\d)(?!\w)")
EMAIL_RE = re.compile(r"(?P<prefix>mailto:)?(?P<email>[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,})(?P<suffix>[)\]>.,;:!?]*)", flags=re.IGNORECASE)
NON_WORDS_RE = re.compile(r"[^\w\- ]+", flags=re.UNICODE)

CYRILLIC_TO_LATIN = {
    "а": "a",
    "б": "b",
    "в": "v",
    "г": "g",
    "д": "d",
    "е": "e",
    "ё": "e",
    "ж": "zh",
    "з": "z",
    "и": "i",
    "й": "i",
    "к": "k",
    "л": "l",
    "м": "m",
    "н": "n",
    "о": "o",
    "п": "p",
    "р": "r",
    "с": "s",
    "т": "t",
    "у": "u",
    "ф": "f",
    "х": "kh",
    "ц": "ts",
    "ч": "ch",
    "ш": "sh",
    "щ": "shch",
    "ъ": "",
    "ы": "y",
    "ь": "",
    "э": "e",
    "ю": "yu",
    "я": "ya",
}
