from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple

from .constants import PERSON_TAG_RE, PLACEHOLDER_RE
from .utils import (
    build_person_blocked_signatures,
    build_person_signature,
    compact_org_token,
    extract_tokens,
    is_valid_organization_key,
    is_valid_person_key,
    is_valid_person_name_key,
    normalize_email_key,
    normalize_key,
    normalize_phone_key,
    normalize_username_key,
    sort_by_numeric_suffix,
)

class NameDictionary:
    def __init__(self, alias_to_canonical: Dict[str, str]) -> None:
        self.alias_to_canonical = alias_to_canonical
        self.aliases = sorted(alias_to_canonical.keys(), key=len, reverse=True)
        if self.aliases:
            escaped = "|".join(re.escape(alias) for alias in self.aliases)
            pattern = rf"(?<![\w\-])({escaped})(?![\w\-])"
            self.alias_regex = re.compile(pattern, flags=re.IGNORECASE | re.UNICODE)
        else:
            self.alias_regex = None

    @classmethod
    def from_json(cls, names_path: Path) -> "NameDictionary":
        raw = json.loads(names_path.read_text(encoding="utf-8"))
        alias_to_canonical: Dict[str, str] = {}
        ambiguous_aliases = set()

        for entry in raw:
            canonical = str(entry.get("en") or entry.get("ru") or "").strip().lower()
            if not canonical:
                continue
            forms: List[str] = []
            forms.extend(entry.get("forms_ru", []) or [])
            forms.extend(entry.get("forms_en", []) or [])

            for form in forms:
                form_key = str(form).strip().lower()
                if not form_key:
                    continue
                existing = alias_to_canonical.get(form_key)
                if existing and existing != canonical:
                    ambiguous_aliases.add(form_key)
                else:
                    alias_to_canonical[form_key] = canonical

        for alias in ambiguous_aliases:
            alias_to_canonical[alias] = alias

        return cls(alias_to_canonical=alias_to_canonical)

    def canonical_single_name(self, name: str) -> str:
        key = normalize_key(name)
        return self.alias_to_canonical.get(key, key)


class TagRegistry:
    def __init__(
        self,
        people_data: Dict[str, Any] | None = None,
        min_person_name_len: int = 2,
        person_blocked_words: set[str] | None = None,
        person_name_blocked_words: set[str] | None = None,
        organization_blocked_words: set[str] | None = None,
    ) -> None:
        self.person_key_to_tag: Dict[str, str] = {}
        self.person_tag_meta: Dict[str, Dict[str, Any]] = {}
        self.person_signature_to_tag: Dict[str, str] = {}

        self.file_name_key_to_tag: Dict[str, Dict[str, str]] = {}
        self.file_name_tag_meta: Dict[str, Dict[str, Dict[str, Any]]] = {}
        self.file_name_next_index: Dict[str, int] = {}
        self.person_next_index = 1

        self.username_key_to_base_tag: Dict[str, str] = {}
        self.user_id_to_base_tag: Dict[str, str] = {}
        self._username_regex: re.Pattern[str] | None = None

        self.resource_key_to_tag: Dict[str, str] = {}
        self.resource_tag_meta: Dict[str, Dict[str, Any]] = {}
        self.resource_next_index = 1

        self.organization_key_to_tag: Dict[str, str] = {}
        self.organization_tag_meta: Dict[str, Dict[str, Any]] = {}
        self.organization_next_index = 1
        self.organization_phrase_norm_to_tag: Dict[str, str] = {}
        self._organization_phrase_regex: re.Pattern[str] | None = None
        self.organization_single_token_compact_to_tag: Dict[str, str] = {}
        self._organization_variant_token_regex: re.Pattern[str] | None = None

        self.phone_key_to_tag: Dict[str, str] = {}
        self.phone_tag_meta: Dict[str, Dict[str, Any]] = {}
        self.phone_next_index = 1

        self.email_key_to_tag: Dict[str, str] = {}
        self.email_tag_meta: Dict[str, Dict[str, Any]] = {}
        self.email_next_index = 1

        self.person_phrase_norm_to_tag: Dict[str, str] = {}
        self._person_phrase_regex: re.Pattern[str] | None = None
        self.person_single_name_keys: set[str] = set()
        self._person_single_name_regex: re.Pattern[str] | None = None

        self.min_person_name_len = max(1, int(min_person_name_len))
        self.person_blocked_words = person_blocked_words or set()
        self.person_blocked_signatures = build_person_blocked_signatures(self.person_blocked_words)
        self.person_name_blocked_words = person_name_blocked_words or set()
        self.organization_blocked_words = organization_blocked_words or set()

        if people_data:
            self._load_from_people_data(people_data)

    @staticmethod
    def _extract_tag_index(tag: str, prefix: str) -> int:
        if not tag.startswith(prefix):
            return 0
        tail = tag[len(prefix):]
        return int(tail) if tail.isdigit() else 0

    def _load_from_people_data(self, people_data: Dict[str, Any]) -> None:
        person_section = people_data.get("person", {}) or {}
        max_person_idx = 0
        for tag in sort_by_numeric_suffix(person_section.keys()):
            meta = person_section.get(tag)
            max_person_idx = max(max_person_idx, self._extract_tag_index(tag, "PERSON_"))
            if not isinstance(meta, dict):
                continue
            key = normalize_key(str(meta.get("key", "")))
            if not key:
                continue
            if not is_valid_person_key(
                key=key,
                blocked_words=self.person_blocked_words,
                blocked_signatures=self.person_blocked_signatures,
            ):
                continue

            examples = set(meta.get("examples", []) or [])
            files = set(meta.get("files", []) or [])

            target_tag = self.person_key_to_tag.get(key)
            if target_tag is None:
                signature = build_person_signature(key)
                if signature:
                    target_tag = self.person_signature_to_tag.get(signature)

            if target_tag is None:
                target_tag = tag
                self.person_tag_meta[target_tag] = {
                    "key": key,
                    "examples": set(),
                    "files": set(),
                }

            self.person_key_to_tag[key] = target_tag
            target_meta = self.person_tag_meta[target_tag]
            target_meta["examples"].update(examples)
            target_meta["files"].update(files)

            self._register_person_phrase(key, target_tag, invalidate=False)
            self._register_single_name_candidates_from_phrase(key, invalidate=False)
            for example in meta.get("examples", []) or []:
                self._register_person_phrase(str(example), target_tag, invalidate=False)
                self._register_single_name_candidates_from_phrase(str(example), invalidate=False)

            signature_candidates = [key, *[str(example) for example in examples]]
            for candidate in signature_candidates:
                signature = build_person_signature(candidate)
                if not signature:
                    continue
                self.person_signature_to_tag.setdefault(signature, target_tag)
        self.person_next_index = max_person_idx + 1 if max_person_idx else 1

        person_name_section = people_data.get("person_name", {}) or {}
        for file_id, entries in person_name_section.items():
            if not isinstance(entries, dict):
                continue

            file_key_to_tag: Dict[str, str] = {}
            file_tag_meta: Dict[str, Dict[str, Any]] = {}
            max_idx = 0

            for tag, meta in entries.items():
                if not isinstance(meta, dict):
                    continue
                key = normalize_key(str(meta.get("key", "")))
                if not key:
                    continue
                if not is_valid_person_name_key(
                    key=key,
                    min_len=self.min_person_name_len,
                    blocked_words=self.person_name_blocked_words,
                ):
                    continue

                file_key_to_tag[key] = tag
                file_tag_meta[tag] = {
                    "key": key,
                    "examples": set(meta.get("examples", []) or []),
                }
                self._register_single_name_key(key, invalidate=False)
                for example in meta.get("examples", []) or []:
                    self._register_single_name_candidates_from_phrase(str(example), invalidate=False)
                max_idx = max(max_idx, self._extract_tag_index(tag, "PERSON_NAME_"))

            if file_key_to_tag:
                self.file_name_key_to_tag[file_id] = file_key_to_tag
                self.file_name_tag_meta[file_id] = file_tag_meta
                self.file_name_next_index[file_id] = max_idx + 1 if max_idx else 1

        username_section = people_data.get("username", {}) or {}
        for username, base_tag in username_section.items():
            if not isinstance(username, str) or not isinstance(base_tag, str):
                continue
            if not PERSON_TAG_RE.fullmatch(base_tag):
                continue
            key = normalize_username_key(username)
            if key:
                self.username_key_to_base_tag[key] = base_tag

        user_id_section = people_data.get("user_id", {}) or {}
        for user_id, base_tag in user_id_section.items():
            if not isinstance(user_id, str) or not isinstance(base_tag, str):
                continue
            if PERSON_TAG_RE.fullmatch(base_tag):
                self.user_id_to_base_tag[user_id] = base_tag

        resource_section = people_data.get("resource", {}) or {}
        max_resource_idx = 0
        for tag, meta in resource_section.items():
            if not isinstance(meta, dict):
                continue
            key = str(meta.get("key", "")).strip()
            if not key:
                continue

            self.resource_key_to_tag[key] = tag
            self.resource_tag_meta[tag] = {
                "key": key,
                "examples": set(meta.get("examples", []) or []),
                "files": set(meta.get("files", []) or []),
            }
            max_resource_idx = max(max_resource_idx, self._extract_tag_index(tag, "RESOURCE_"))
        self.resource_next_index = max_resource_idx + 1 if max_resource_idx else 1

        organization_section = people_data.get("organization", {}) or {}
        max_org_idx = 0
        for tag, meta in organization_section.items():
            if not isinstance(meta, dict):
                continue
            key = self._normalize_org_phrase(str(meta.get("key", "")))
            if not key:
                continue

            self.organization_key_to_tag[key] = tag
            self.organization_tag_meta[tag] = {
                "key": key,
                "examples": set(meta.get("examples", []) or []),
                "files": set(meta.get("files", []) or []),
            }
            self._register_organization_phrase(key, tag, invalidate=False)
            for example in meta.get("examples", []) or []:
                self._register_organization_phrase(str(example), tag, invalidate=False)
            max_org_idx = max(max_org_idx, self._extract_tag_index(tag, "ORG_"))
        self.organization_next_index = max_org_idx + 1 if max_org_idx else 1

        phone_section = people_data.get("phone", {}) or {}
        max_phone_idx = 0
        for tag, meta in phone_section.items():
            if not isinstance(meta, dict):
                continue
            key = normalize_phone_key(str(meta.get("key", "")))
            if not key:
                continue

            self.phone_key_to_tag[key] = tag
            self.phone_tag_meta[tag] = {
                "key": key,
                "examples": set(meta.get("examples", []) or []),
                "files": set(meta.get("files", []) or []),
            }
            max_phone_idx = max(max_phone_idx, self._extract_tag_index(tag, "PHONE_"))
        self.phone_next_index = max_phone_idx + 1 if max_phone_idx else 1

        email_section = people_data.get("email", {}) or {}
        max_email_idx = 0
        for tag, meta in email_section.items():
            if not isinstance(meta, dict):
                continue
            key = normalize_email_key(str(meta.get("key", "")))
            if not key:
                continue

            self.email_key_to_tag[key] = tag
            self.email_tag_meta[tag] = {
                "key": key,
                "examples": set(meta.get("examples", []) or []),
                "files": set(meta.get("files", []) or []),
            }
            max_email_idx = max(max_email_idx, self._extract_tag_index(tag, "EMAIL_"))
        self.email_next_index = max_email_idx + 1 if max_email_idx else 1

    def get_person_tag(self, key: str, example: str, file_id: str) -> str:
        key = normalize_key(key)
        if not key:
            key = normalize_key(example)
        if not key:
            key = "unknown_person"

        tag = self.person_key_to_tag.get(key)
        if tag is None:
            signature = build_person_signature(key)
            if signature:
                tag = self.person_signature_to_tag.get(signature)
                if tag is not None:
                    self.person_key_to_tag[key] = tag

        if tag is None:
            tag = f"PERSON_{self.person_next_index:03d}"
            self.person_next_index += 1
            self.person_key_to_tag[key] = tag
            self.person_tag_meta[tag] = {
                "key": key,
                "examples": set(),
                "files": set(),
            }
        meta = self.person_tag_meta[tag]
        meta["examples"].add(example)
        meta["files"].add(file_id)

        signature = build_person_signature(key)
        if signature:
            self.person_signature_to_tag.setdefault(signature, tag)
        example_signature = build_person_signature(example)
        if example_signature:
            self.person_signature_to_tag.setdefault(example_signature, tag)

        self._register_person_phrase(key, tag)
        self._register_person_phrase(example, tag)
        self._register_single_name_candidates_from_phrase(key)
        self._register_single_name_candidates_from_phrase(example)
        return tag

    def get_file_name_tag(self, file_id: str, key: str, example: str) -> str:
        key = normalize_key(key)
        if not key:
            key = normalize_key(example)
        file_map = self.file_name_key_to_tag.setdefault(file_id, {})
        tag = file_map.get(key)
        if tag is None:
            next_idx = self.file_name_next_index.get(file_id, 1)
            tag = f"PERSON_NAME_{next_idx:03d}"
            self.file_name_next_index[file_id] = next_idx + 1
            file_map[key] = tag
            file_meta = self.file_name_tag_meta.setdefault(file_id, {})
            file_meta[tag] = {"key": key, "examples": set()}

        file_meta = self.file_name_tag_meta[file_id][tag]
        file_meta["examples"].add(example)
        self._register_single_name_key(key)
        return tag

    def register_username(self, username: str, base_tag: str) -> str:
        key = normalize_username_key(username)
        if not key:
            return base_tag

        existing = self.username_key_to_base_tag.get(key)
        if existing is not None:
            return existing

        if PERSON_TAG_RE.fullmatch(base_tag):
            self.username_key_to_base_tag[key] = base_tag
            self._username_regex = None
            return base_tag

        return base_tag

    def username_placeholder_for_raw(self, username: str) -> str | None:
        key = normalize_username_key(username)
        if not key:
            return None
        base_tag = self.username_key_to_base_tag.get(key)
        if base_tag is None:
            return None
        return f"{base_tag}_USERNAME"

    def register_user_id(self, user_id: str, base_tag: str) -> None:
        if not user_id:
            return
        if PERSON_TAG_RE.fullmatch(base_tag):
            self.user_id_to_base_tag[user_id] = base_tag

    def resolve_user_id_tag(self, user_id: str) -> str | None:
        if not user_id:
            return None
        return self.user_id_to_base_tag.get(user_id)

    def _register_person_phrase(self, phrase: str, tag: str, invalidate: bool = True) -> None:
        if not isinstance(phrase, str):
            return

        tokens = extract_tokens(phrase)
        if len(tokens) < 2:
            return

        normalized_phrase = normalize_key(" ".join(tokens))
        if not normalized_phrase:
            return

        existing_tag = self.person_phrase_norm_to_tag.get(normalized_phrase)
        if existing_tag and existing_tag != tag:
            return
        if existing_tag == tag:
            return

        self.person_phrase_norm_to_tag[normalized_phrase] = tag
        if invalidate:
            self._person_phrase_regex = None

    def _build_person_phrase_regex(self) -> re.Pattern[str] | None:
        if self._person_phrase_regex is not None:
            return self._person_phrase_regex

        if not self.person_phrase_norm_to_tag:
            return None

        patterns: List[str] = []
        for phrase in sorted(self.person_phrase_norm_to_tag.keys(), key=len, reverse=True):
            parts = [part for part in phrase.split() if part]
            if len(parts) < 2:
                continue
            patterns.append(r"\s+".join(re.escape(part) for part in parts))

        if not patterns:
            return None

        self._person_phrase_regex = re.compile(
            rf"(?<![\w\-])(?:{'|'.join(patterns)})(?![\w\-])",
            flags=re.IGNORECASE | re.UNICODE,
        )
        return self._person_phrase_regex

    def replace_known_persons_in_text(self, text: str, file_id: str) -> Tuple[str, List[Dict[str, str]]]:
        if not text:
            return text, []

        regex = self._build_person_phrase_regex()
        if regex is None:
            return text, []

        replacements: List[Dict[str, str]] = []

        def _replace(match: re.Match[str]) -> str:
            source = match.group(0)
            source_key = normalize_key(" ".join(extract_tokens(source)))
            tag = self.person_phrase_norm_to_tag.get(source_key)
            if tag is None:
                return source

            meta = self.person_tag_meta.get(tag)
            if meta is not None:
                meta["examples"].add(source)
                meta["files"].add(file_id)

            replacements.append({"kind": "full", "source": source, "tag": tag})
            return tag

        replaced = regex.sub(_replace, text)
        return replaced, replacements

    def _register_single_name_key(self, key: str, invalidate: bool = True) -> bool:
        normalized = normalize_key(key)
        if not normalized or " " in normalized:
            return False
        if not is_valid_person_name_key(
            key=normalized,
            min_len=self.min_person_name_len,
            blocked_words=self.person_name_blocked_words,
        ):
            return False
        if normalized in self.person_single_name_keys:
            return False
        self.person_single_name_keys.add(normalized)
        if invalidate:
            self._person_single_name_regex = None
        return True

    def _register_single_name_candidates_from_phrase(self, phrase: str, invalidate: bool = True) -> None:
        if not isinstance(phrase, str) or not phrase.strip():
            return

        added = False
        for token in extract_tokens(phrase):
            if self._register_single_name_key(token, invalidate=False):
                added = True

        if added and invalidate:
            self._person_single_name_regex = None

    def _build_person_single_name_regex(self) -> re.Pattern[str] | None:
        if self._person_single_name_regex is not None:
            return self._person_single_name_regex

        if not self.person_single_name_keys:
            return None

        escaped = "|".join(re.escape(name) for name in sorted(self.person_single_name_keys, key=len, reverse=True))
        if not escaped:
            return None

        # Supports both real separators and escaped separators like "\\nName\\n".
        self._person_single_name_regex = re.compile(
            rf"(^|\\[nrt]|[^\w\-])({escaped})(?=$|\\[nrt]|[^\w\-])",
            flags=re.IGNORECASE | re.UNICODE,
        )
        return self._person_single_name_regex

    def replace_known_single_names_in_text(self, text: str, file_id: str) -> Tuple[str, List[Dict[str, str]]]:
        if not text:
            return text, []

        regex = self._build_person_single_name_regex()
        if regex is None:
            return text, []

        replacements: List[Dict[str, str]] = []

        def _replace(match: re.Match[str]) -> str:
            prefix = match.group(1)
            source = match.group(2)
            stripped = source.strip()
            if PLACEHOLDER_RE.fullmatch(stripped):
                return f"{prefix}{source}"

            key = normalize_key(source)
            if not key or " " in key:
                return f"{prefix}{source}"
            if key not in self.person_single_name_keys:
                return f"{prefix}{source}"

            tag = self.get_file_name_tag(file_id=file_id, key=key, example=source)
            replacements.append({"kind": "name", "source": source, "tag": tag})
            return f"{prefix}{tag}"

        replaced = regex.sub(_replace, text)
        return replaced, replacements

    def get_resource_tag(self, key: str, example: str, file_id: str) -> str:
        tag = self.resource_key_to_tag.get(key)
        if tag is None:
            tag = f"RESOURCE_{self.resource_next_index:03d}"
            self.resource_next_index += 1
            self.resource_key_to_tag[key] = tag
            self.resource_tag_meta[tag] = {
                "key": key,
                "examples": set(),
                "files": set(),
            }

        meta = self.resource_tag_meta[tag]
        meta["examples"].add(example)
        meta["files"].add(file_id)
        return tag

    def get_organization_tag(self, key: str, example: str, file_id: str) -> str:
        key = self._normalize_org_phrase(key)
        if not key:
            key = self._normalize_org_phrase(example)
        if not key:
            return ""

        tag = self.organization_key_to_tag.get(key)
        if tag is None:
            tag = f"ORG_{self.organization_next_index:03d}"
            self.organization_next_index += 1
            self.organization_key_to_tag[key] = tag
            self.organization_tag_meta[tag] = {
                "key": key,
                "examples": set(),
                "files": set(),
            }

        meta = self.organization_tag_meta[tag]
        meta["examples"].add(example)
        meta["files"].add(file_id)
        self._register_organization_phrase(key, tag)
        self._register_organization_phrase(example, tag)
        return tag

    def get_phone_tag(self, key: str, example: str, file_id: str) -> str:
        key = normalize_phone_key(key)
        if not key:
            key = normalize_phone_key(example)
        if not key:
            key = "unknown_phone"

        tag = self.phone_key_to_tag.get(key)
        if tag is None:
            tag = f"PHONE_{self.phone_next_index:03d}"
            self.phone_next_index += 1
            self.phone_key_to_tag[key] = tag
            self.phone_tag_meta[tag] = {
                "key": key,
                "examples": set(),
                "files": set(),
            }

        meta = self.phone_tag_meta[tag]
        meta["examples"].add(example)
        meta["files"].add(file_id)
        return tag

    def get_email_tag(self, key: str, example: str, file_id: str) -> str:
        key = normalize_email_key(key)
        if not key:
            key = normalize_email_key(example)
        if not key:
            key = "unknown_email"

        tag = self.email_key_to_tag.get(key)
        if tag is None:
            tag = f"EMAIL_{self.email_next_index:03d}"
            self.email_next_index += 1
            self.email_key_to_tag[key] = tag
            self.email_tag_meta[tag] = {
                "key": key,
                "examples": set(),
                "files": set(),
            }

        meta = self.email_tag_meta[tag]
        meta["examples"].add(example)
        meta["files"].add(file_id)
        return tag

    def _normalize_org_phrase(self, phrase: str) -> str:
        if not isinstance(phrase, str):
            return ""
        tokens = extract_tokens(phrase)
        if not tokens:
            return ""
        normalized = normalize_key(" ".join(tokens))
        if not is_valid_organization_key(normalized, self.organization_blocked_words):
            return ""
        return normalized

    def is_valid_organization_key(self, key: str) -> bool:
        return bool(self._normalize_org_phrase(key))

    def _register_organization_phrase(self, phrase: str, tag: str, invalidate: bool = True) -> None:
        normalized_phrase = self._normalize_org_phrase(phrase)
        if not normalized_phrase:
            return

        existing_tag = self.organization_phrase_norm_to_tag.get(normalized_phrase)
        if existing_tag and existing_tag != tag:
            return
        if existing_tag == tag:
            return

        self.organization_phrase_norm_to_tag[normalized_phrase] = tag
        parts = [part for part in normalized_phrase.split() if part]
        if len(parts) == 1 and len(parts[0]) >= 5:
            compact = compact_org_token(parts[0])
            if compact:
                existing_single_token_tag = self.organization_single_token_compact_to_tag.get(compact)
                if existing_single_token_tag in {None, tag}:
                    self.organization_single_token_compact_to_tag[compact] = tag
        if invalidate:
            self._organization_phrase_regex = None
            self._organization_variant_token_regex = None

    def _build_organization_phrase_regex(self) -> re.Pattern[str] | None:
        if self._organization_phrase_regex is not None:
            return self._organization_phrase_regex

        if not self.organization_phrase_norm_to_tag:
            return None

        patterns: List[str] = []
        for phrase in sorted(self.organization_phrase_norm_to_tag.keys(), key=len, reverse=True):
            parts = [part for part in phrase.split() if part]
            if not parts:
                continue
            patterns.append(r"\s+".join(re.escape(part) for part in parts))

        if not patterns:
            return None

        self._organization_phrase_regex = re.compile(
            rf"(?<![0-9A-Za-zА-Яа-яЁё])(?:{'|'.join(patterns)})(?![0-9A-Za-zА-Яа-яЁё])",
            flags=re.IGNORECASE | re.UNICODE,
        )
        return self._organization_phrase_regex

    def replace_known_organizations_in_text(self, text: str, file_id: str) -> Tuple[str, List[Dict[str, str]]]:
        if not text:
            return text, []

        regex = self._build_organization_phrase_regex()
        if regex is None:
            return text, []

        replacements: List[Dict[str, str]] = []

        def _replace(match: re.Match[str]) -> str:
            source = match.group(0)
            source_key = self._normalize_org_phrase(source)
            if not source_key:
                return source
            tag = self.organization_phrase_norm_to_tag.get(source_key)
            if tag is None:
                return source

            meta = self.organization_tag_meta.get(tag)
            if meta is not None:
                meta["examples"].add(source)
                meta["files"].add(file_id)

            replacements.append({"kind": "org", "source": source, "tag": tag})
            return tag

        replaced = regex.sub(_replace, text)
        return replaced, replacements

    def _build_organization_variant_token_regex(self) -> re.Pattern[str] | None:
        if self._organization_variant_token_regex is not None:
            return self._organization_variant_token_regex

        if not self.organization_single_token_compact_to_tag:
            return None

        self._organization_variant_token_regex = re.compile(
            r"(?<![0-9A-Za-zА-Яа-яЁё])([A-Za-zА-Яа-яЁё][A-Za-zА-Яа-яЁё'’]*)(?![0-9A-Za-zА-Яа-яЁё])",
            flags=re.IGNORECASE | re.UNICODE,
        )
        return self._organization_variant_token_regex

    def replace_known_organization_token_variants_in_text(
        self,
        text: str,
        file_id: str,
    ) -> Tuple[str, List[Dict[str, str]]]:
        if not text:
            return text, []

        regex = self._build_organization_variant_token_regex()
        if regex is None:
            return text, []

        replacements: List[Dict[str, str]] = []
        sorted_candidates = sorted(
            self.organization_single_token_compact_to_tag.items(),
            key=lambda item: len(item[0]),
            reverse=True,
        )

        def _replace(match: re.Match[str]) -> str:
            source = match.group(1)
            stripped = source.strip()
            if PLACEHOLDER_RE.fullmatch(stripped):
                return source

            source_compact = compact_org_token(source)
            if not source_compact:
                return source

            for base_compact, tag in sorted_candidates:
                if source_compact == base_compact:
                    return source
                if not source_compact.startswith(base_compact):
                    continue
                suffix = source_compact[len(base_compact):]
                if not suffix or len(suffix) > 12:
                    continue
                if not suffix.isalpha():
                    continue

                meta = self.organization_tag_meta.get(tag)
                if meta is not None:
                    meta["examples"].add(source)
                    meta["files"].add(file_id)

                replacements.append({"kind": "org", "source": source, "tag": tag})
                return tag

            return source

        replaced = regex.sub(_replace, text)
        return replaced, replacements

    def _build_username_regex(self) -> re.Pattern[str] | None:
        if self._username_regex is not None:
            return self._username_regex

        keys = [key for key in self.username_key_to_base_tag.keys() if key]
        if not keys:
            return None

        escaped = "|".join(re.escape(key) for key in sorted(keys, key=len, reverse=True))
        pattern = rf"(?<![A-Za-z0-9_.-])(@?)({escaped})(?![A-Za-z0-9_.-])"
        self._username_regex = re.compile(pattern, flags=re.IGNORECASE | re.UNICODE)
        return self._username_regex

    def replace_known_usernames_in_text(self, text: str) -> Tuple[str, int]:
        regex = self._build_username_regex()
        if regex is None:
            return text, 0

        count = 0

        def _replace(match: re.Match[str]) -> str:
            nonlocal count
            at_prefix = match.group(1)
            username_raw = match.group(2)
            key = normalize_username_key(username_raw)
            base_tag = self.username_key_to_base_tag.get(key)
            if base_tag is None:
                return match.group(0)
            count += 1
            return f"{at_prefix}{base_tag}_USERNAME"

        replaced = regex.sub(_replace, text)
        return replaced, count

    def export_people_json(self) -> Dict[str, Any]:
        person_out: Dict[str, Any] = {}
        for tag in sort_by_numeric_suffix(self.person_tag_meta.keys()):
            meta = self.person_tag_meta[tag]
            person_out[tag] = {
                "key": meta["key"],
                "examples": sorted(meta["examples"]),
                "files": sorted(meta["files"]),
            }

        person_name_out: Dict[str, Any] = {}
        for file_id in sorted(self.file_name_tag_meta.keys()):
            file_entries = self.file_name_tag_meta[file_id]
            person_name_out[file_id] = {}
            for tag in sort_by_numeric_suffix(file_entries.keys()):
                meta = file_entries[tag]
                person_name_out[file_id][tag] = {
                    "key": meta["key"],
                    "examples": sorted(meta["examples"]),
                }

        resource_out: Dict[str, Any] = {}
        for tag in sort_by_numeric_suffix(self.resource_tag_meta.keys()):
            meta = self.resource_tag_meta[tag]
            resource_out[tag] = {
                "key": meta["key"],
                "examples": sorted(meta["examples"]),
                "files": sorted(meta["files"]),
            }

        organization_out: Dict[str, Any] = {}
        for tag in sort_by_numeric_suffix(self.organization_tag_meta.keys()):
            meta = self.organization_tag_meta[tag]
            organization_out[tag] = {
                "key": meta["key"],
                "examples": sorted(meta["examples"]),
                "files": sorted(meta["files"]),
            }

        phone_out: Dict[str, Any] = {}
        for tag in sort_by_numeric_suffix(self.phone_tag_meta.keys()):
            meta = self.phone_tag_meta[tag]
            phone_out[tag] = {
                "key": meta["key"],
                "examples": sorted(meta["examples"]),
                "files": sorted(meta["files"]),
            }

        email_out: Dict[str, Any] = {}
        for tag in sort_by_numeric_suffix(self.email_tag_meta.keys()):
            meta = self.email_tag_meta[tag]
            email_out[tag] = {
                "key": meta["key"],
                "examples": sorted(meta["examples"]),
                "files": sorted(meta["files"]),
            }

        return {
            "person": person_out,
            "person_name": person_name_out,
            "username": dict(sorted(self.username_key_to_base_tag.items())),
            "user_id": dict(sorted(self.user_id_to_base_tag.items())),
            "resource": resource_out,
            "organization": organization_out,
            "phone": phone_out,
            "email": email_out,
        }


