from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Tuple

from . import constants
from .anonymizer import PersonAnonymizer
from .cli import configure_default_paths
from .people import load_people_data, save_people_data
from .pipeline import apply_full_pipeline_to_value
from .registry import NameDictionary, TagRegistry
from .utils import load_word_list


@dataclass
class TextAnonymizationSession:
    runtime_root: Path
    people_file: Path
    registry: TagRegistry
    anonymizer: PersonAnonymizer
    ner_batch_size: int = 16

    @classmethod
    def from_defaults(
        cls,
        runtime_root: str | Path | None = None,
        people_file: str | Path | None = None,
        device: str = "auto",
        model_name: str = constants.DEFAULT_MODEL_NAME,
        min_score: float = 0.8,
        min_person_name_len: int = 2,
        ner_batch_size: int = 16,
        person_blocklist_file: str | Path | None = None,
        person_name_blocklist_file: str | Path | None = None,
        org_blocklist_file: str | Path | None = None,
    ) -> "TextAnonymizationSession":
        resolved_runtime_root = configure_default_paths(runtime_root)

        resolved_people_file = Path(people_file).resolve() if people_file else constants.DEFAULT_PEOPLE_FILE.resolve()
        resolved_person_blocklist_file = (
            Path(person_blocklist_file).resolve()
            if person_blocklist_file
            else constants.DEFAULT_PERSON_BLOCKLIST_FILE.resolve()
        )
        resolved_person_name_blocklist_file = (
            Path(person_name_blocklist_file).resolve()
            if person_name_blocklist_file
            else constants.DEFAULT_PERSON_NAME_BLOCKLIST_FILE.resolve()
        )
        resolved_org_blocklist_file = (
            Path(org_blocklist_file).resolve()
            if org_blocklist_file
            else constants.DEFAULT_ORG_BLOCKLIST_FILE.resolve()
        )

        people_data = load_people_data(resolved_people_file)
        person_blocked_words = load_word_list(resolved_person_blocklist_file)
        person_name_blocked_words = load_word_list(resolved_person_name_blocklist_file)
        organization_blocked_words = load_word_list(resolved_org_blocklist_file)

        registry = TagRegistry(
            people_data=people_data,
            min_person_name_len=min_person_name_len,
            person_blocked_words=person_blocked_words,
            person_name_blocked_words=person_name_blocked_words,
            organization_blocked_words=organization_blocked_words,
        )
        anonymizer = PersonAnonymizer(
            model_name=model_name,
            name_dict=NameDictionary(alias_to_canonical={}),
            registry=registry,
            device=device,
            min_score=min_score,
            min_person_name_len=min_person_name_len,
            person_blocked_words=person_blocked_words,
            person_name_blocked_words=person_name_blocked_words,
        )
        return cls(
            runtime_root=resolved_runtime_root,
            people_file=resolved_people_file,
            registry=registry,
            anonymizer=anonymizer,
            ner_batch_size=max(1, int(ner_batch_size)),
        )

    def anonymize_text(self, text: str, file_id: str = "inline.txt") -> Tuple[str, list[dict[str, str]]]:
        return self.anonymizer.anonymize_text(text, file_id=file_id)

    def anonymize_value(self, value: Any, file_id: str = "inline.json") -> Tuple[Any, Dict[str, int]]:
        return apply_full_pipeline_to_value(
            value=value,
            anonymizer=self.anonymizer,
            registry=self.registry,
            file_id=file_id,
            ner_batch_size=self.ner_batch_size,
        )

    def save_people(self) -> bool:
        return save_people_data(self.people_file, self.registry)
