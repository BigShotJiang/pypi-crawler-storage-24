"""Compatibility package for the public pytshade API."""

from .builder import StratoScriptBuilder
from .astronomy import AstroHelper
from .version import NightshadeVersion

__version__ = "0.1.2"

