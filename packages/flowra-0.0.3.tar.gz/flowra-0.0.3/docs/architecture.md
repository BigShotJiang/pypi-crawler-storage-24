# Architecture

Overview of the `flowra` package structure, dependency graph, and how
the pieces fit together.

## Package dependency graph

```
llm            (no deps)
tools          (llm)
agent          (no deps)
runtime        (agent, llm)
lib            (agent, llm, tools, runtime)
```

No circular dependencies.

## Packages

### `llm` — LLM abstraction

Protocol layer between the SDK and any LLM. The core abstraction is `LLMProvider` —
`call(LLMRequest) → LLMResponse` for full responses, and `stream(LLMRequest) →
AsyncIterator[StreamEvent]` for real-time text/thinking deltas. Request and response use
a shared set of message and block types. Ships three providers:
`AnthropicVertexProvider` (Claude via Vertex AI), `OpenAIProvider` (OpenAI-compatible APIs),
`GoogleVertexProvider` (Gemini via Vertex AI). → [docs/llm.md](llm.md)

### `tools` — Tool system

Bridge between Python functions / MCP servers and the LLM tool-calling protocol.
The `@tool` decorator turns a function into a tool definition; `McpConnection`
connects to remote MCP servers. `ToolRegistry` collects all tools, converts them
to LLM-compatible `Tool` objects, and handles execution with DI into handlers. → [docs/tools.md](tools.md)

### `agent` — Agent framework

State-machine framework. Agents are classes whose `@step` methods form states;
transitions (`Goto`, `Spawn`, `Call`) and results (`AgentResult`) control the flow.
Each agent declares persistent state via `slot()` (scalars and append-only lists) with
dirty tracking for efficient incremental saves. The compiler discovers slots and builds
a type registry at class definition time. → [docs/agent.md](agent.md)

### `runtime` — Execution engine

Orchestrates agent execution. `AgentRuntime` is the entry point — takes agent
definitions and services, runs the agent graph, persists state incrementally,
and supports cooperative interrupts and crash recovery (save/resume). → [docs/runtime.md](runtime.md)

### `lib` — High-level agents

Pre-built agents for common patterns:

- **`ChatAgent`** — multi-turn chat with session history. Manages conversation
  persistence across turns, delegates each turn to `ToolLoopAgent`.
- **`ToolLoopAgent`** — single-turn LLM tool loop. Sends messages to the LLM,
  executes tool calls, feeds results back, repeats until done.

Also provides a generic `HookRegistry` + `Event[T]` hook system, prompt caching strategies,
and dynamic config. → [docs/lib.md](lib.md)

## Data flow

A typical chat turn flows through the layers like this:

```
User message
    │
    ▼
ChatAgent.process_message
    │  Spawns ToolLoopAgent via Call inside Spawn
    ▼
ToolLoopAgent.start
    │  Saves user message to turn messages
    ▼
ToolLoopAgent.call_llm  (loop)
    │  Calls LLMProvider, executes tool calls, repeats until done
    │  Returns ToolLoopResult
    ▼
ChatAgent.collect_result
    │  Appends turn messages to session history
    │  Returns ChatResult
```

The runtime persists state after each step — see [Persistence model](#persistence-model).

## Dependency injection

Services are injected into agent constructors by matching parameter type annotations.
The runtime maintains a service dict (`{type: instance}`) and resolves constructor
parameters automatically.

```python
runtime = AgentRuntime(
    agents={"chat": ChatAgent},
    storage=FileSessionStorage("./sessions/my-session"),
    services={
        LLMProvider: provider,
        ToolRegistry: registry,
        ChatConfig: config,
    },
)
```

Agents can also propagate services to child agents via `ServiceLocator.provide()`.
See [docs/agent.md](agent.md) and [docs/runtime.md](runtime.md) for details.

## Persistence model

State is stored in two types of stored values:
- **`Scalar[T]`** — mutable single value with dirty tracking. On save, only dirty
  scalars are written.
- **`AppendOnlyList[T]`** — append-only list. On save, only new items since last
  flush are written.

This allows efficient incremental persistence — each save only writes what changed.

`SessionStorage` has two groups of methods:
- **Execution snapshot** — temporary crash-recovery data (cleared on completion)
- **Node state** — persistent per-node state (survives across runs)

Built-in implementations: `InMemorySessionStorage` (dev/test), `FileSessionStorage`
(JSON files on disk).
