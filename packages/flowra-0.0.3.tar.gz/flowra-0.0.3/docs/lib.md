# Package `flowra.lib`

High-level agents for LLM interactions: a multi-turn chat agent and a tool-calling loop
agent with hooks, caching, and interrupt support. Built on top of the low-level
`flowra.agent` and `flowra.llm` packages.

```
flowra/lib/
├── config_value.py          # ConfigValue[T] — static or dynamic config provider
├── llm_config.py            # LLMConfig — LLM configuration (model, temperature, etc.)
├── chat/
│   ├── agent.py             # ChatAgent — multi-turn chat with session history
│   ├── config.py            # ChatConfig — chat-level configuration
│   ├── hook_events.py       # SaveTurnMessagesEvent
│   └── spec.py              # ChatSpec, ChatResult
└── tool_loop/
    ├── agent.py             # ToolLoopAgent — single-turn LLM tool loop
    ├── config.py            # ToolLoopConfig
    ├── hook_events.py       # 12 event dataclasses for hook system
    ├── spec.py              # ToolLoopSpec, ToolLoopResult, ToolLoopStatus
    ├── context.py           # ToolLoopAgentContext — tool-accessible loop context
    ├── cache.py             # CacheConfig, cache strategies and presets
    └── _tool_call_agent.py  # Internal: single tool execution sub-agent
```

## Quick start

Minimal multi-turn chat with a tool:

```python
import asyncio
import dataclasses

from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.lib import LLMConfig
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider
from flowra.runtime import AgentRuntime
from flowra.tools import ToolRegistry, get_local_tool, tool


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CalcParams:
    expression: str


@tool("calculate")
def calculate(params: CalcParams) -> str:
    """Evaluate a math expression."""
    # Use a safe evaluator — never pass LLM output to eval()
    return eval_expression(params.expression)


async def main() -> None:
    provider = AnthropicVertexProvider()

    async with await ToolRegistry.create([get_local_tool(calculate)]) as registry:
        config = ChatConfig(
            llm_config=LLMConfig(model="claude-sonnet-4-5@20250929"),
            system_messages=[
                SystemMessage(blocks=[TextBlock(text="You are a helpful assistant.")])
            ],
        )

        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                LLMProvider: provider,
                ToolRegistry: registry,
                ChatConfig: config,
            },
        )

        while True:
            user_input = input("You: ")
            if not user_input:
                break

            result = await runtime.run(
                agent=ChatAgent, step=ChatAgent.process_message,
                spec=ChatSpec(user_message=user_input),
            )

            if isinstance(result, ChatResult) and result.response:
                print(f"Assistant: {result.response}")


asyncio.run(main())
```

## ChatAgent

Multi-turn chat agent that manages session history. Each call to `ChatAgent.process_message`
is one user turn: the agent appends the user message to session history, delegates
to `ToolLoopAgent` for the LLM interaction, then saves all resulting messages
back to the session.

```python
result = await runtime.run(
    agent=ChatAgent, step=ChatAgent.process_message,
    spec=ChatSpec(user_message="Hello!"),
)
```

Session messages persist across turns, so the LLM sees the full conversation
history on every call.

### `ChatSpec`

Input for `ChatAgent.process_message`.

| Field          | Type                     | Default |
|----------------|--------------------------|---------|
| `user_message` | `str`                    | —       |
| `metadata`     | `dict[str, Any] \| None` | `None`  |

`metadata` is passed through to `ToolLoopSpec` and delivered to `MessageAcceptedEvent`
— useful for tracking message IDs in interrupt scenarios.

### `ChatResult`

Output of a chat turn.

| Field      | Type             | Default |
|------------|------------------|---------|
| `response` | `str \| None`    | `None`  |
| `usage`    | `Usage \| None`  | `None`  |

`response` contains the concatenated text blocks from the final assistant message.
`None` when the LLM didn't produce text (e.g. interrupted or max iterations).

### `ChatConfig`

Configuration for `ChatAgent`. All fields accept `ConfigValue[T]` — a plain value,
sync callable, or async callable (see [ConfigValue](#configvalue) below).

| Field                    | Type                                   | Default        |
|--------------------------|----------------------------------------|----------------|
| `llm_config`             | `ConfigValue[LLMConfig]`               | —              |
| `system_messages`        | `ConfigValue[list[Message]]`           | —              |
| `json_schema`            | `ConfigValue[dict[str, Any] \| None]`  | `None`         |
| `max_iterations`         | `ConfigValue[int]`                     | `10`           |
| `allowed_tools`          | `ConfigValue[set[str] \| None]`        | `None`         |
| `denied_tools`           | `ConfigValue[set[str] \| None]`        | `None`         |
| `cache_strategy`         | `ConfigValue[CacheConfig]`             | `CACHE_MANUAL` |
| `max_consecutive_errors` | `ConfigValue[int \| None]`             | `None`         |

`ChatConfig` differs from `ToolLoopConfig` in one key way: it has `system_messages`
instead of `session_messages`. The chat agent builds `session_messages` automatically
by prepending `system_messages` to the accumulated conversation history.

### Chat hooks

Chat-level hook events, registered on the same `HookRegistry` instance as tool loop hooks.

**`SaveTurnMessagesEvent`** — emitted before turn messages are saved into session history.
Handlers mutate `messages` in place to control what gets persisted. Useful for excluding
transient messages (e.g. dynamic context injected by hooks) from long-term session history.

| Field               | Type                      | Default |
|---------------------|---------------------------|---------|
| `messages`          | `list[Message]`           | —       |

```python
from flowra.agent import HookRegistry
from flowra.lib.chat import ChatAgent, ChatConfig, SaveTurnMessagesEvent
from flowra.llm import Message

def filter_transient(event):
    event.data.messages = [m for m in event.data.messages if not m.metadata.get("transient")]

hooks = HookRegistry()
hooks.on(SaveTurnMessagesEvent, filter_transient)

runtime = AgentRuntime(
    agents={"chat": ChatAgent},
    services={..., ChatConfig: config, HookRegistry: hooks},
)
```

## ToolLoopAgent

Lower-level agent that runs a single LLM tool loop: send messages to the LLM,
execute any requested tool calls, feed results back, repeat until the LLM returns
`END_TURN` or a limit is reached. `ChatAgent` delegates to `ToolLoopAgent` internally;
you can also use it directly for non-chat scenarios.

```python
from flowra.lib import LLMConfig
from flowra.lib.tool_loop import ToolLoopAgent, ToolLoopConfig, ToolLoopSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.runtime import AgentRuntime
from flowra.tools import ToolRegistry

config = ToolLoopConfig(
    llm_config=LLMConfig(model="claude-sonnet-4-5@20250929"),
    session_messages=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
    max_iterations=5,
)

runtime = AgentRuntime(
    agents={"loop": ToolLoopAgent},
    services={LLMProvider: provider, ToolRegistry: registry, ToolLoopConfig: config},
)

result = await runtime.run(
    agent=ToolLoopAgent, step=ToolLoopAgent.start,
    spec=ToolLoopSpec(user_message="Calculate 3 * 7"),
)
```

### `ToolLoopSpec`

Input for `ToolLoopAgent.start`.

| Field          | Type                     | Default |
|----------------|--------------------------|---------|
| `user_message` | `str`                    | —       |
| `metadata`     | `dict[str, Any] \| None` | `None`  |

### `ToolLoopResult`

Output of one tool loop execution.

| Field            | Type                        | Default |
|------------------|-----------------------------|---------|
| `messages`       | `list[Message]`             | —       |
| `status`         | `ToolLoopStatus`            | —       |
| `stop_reason`    | `StopReason \| None`        | `None`  |
| `result_message` | `AssistantMessage \| None`  | `None`  |
| `usage`          | `Usage \| None`             | `None`  |

`messages` contains all turn messages (user + assistant + tool results) in order.
`result_message` is the final assistant message when `status` is `COMPLETED`.

### `ToolLoopStatus`

`StrEnum` with four values:

| Value              | Meaning                                              |
|--------------------|------------------------------------------------------|
| `COMPLETED`        | LLM returned a final response (check `stop_reason`)  |
| `MAX_ITERATIONS`   | Iteration limit reached                              |
| `INTERRUPTED`      | `InterruptToken` was set                             |
| `FINISH_REQUESTED` | A tool or hook called `context.request_finish()`     |

### `ToolLoopConfig`

| Field                    | Type                                   | Default        |
|--------------------------|----------------------------------------|----------------|
| `llm_config`             | `ConfigValue[LLMConfig]`               | —              |
| `session_messages`       | `ConfigValue[list[Message]]`           | —              |
| `json_schema`            | `ConfigValue[dict[str, Any] \| None]`  | `None`         |
| `max_iterations`         | `ConfigValue[int]`                     | `10`           |
| `allowed_tools`          | `ConfigValue[set[str] \| None]`        | `None`         |
| `denied_tools`           | `ConfigValue[set[str] \| None]`        | `None`         |
| `cache_strategy`         | `ConfigValue[CacheConfig]`             | `CACHE_MANUAL` |
| `max_consecutive_errors` | `ConfigValue[int \| None]`             | `None`         |

`allowed_tools` / `denied_tools` filter which tools the LLM can see and call.
When `allowed_tools` is set, only those tools are included. When `denied_tools` is set,
those are excluded. If a tool is filtered out but the LLM still tries to call it,
the agent returns an error result to the LLM.

`max_consecutive_errors` — when set, if the same tool fails this many times in a row,
the agent tells the LLM to try a different approach.

### `LLMConfig`

| Field               | Type                | Default |
|---------------------|---------------------|---------|
| `model`             | `str`               | —       |
| `temperature`       | `float \| None`     | `None`  |
| `max_tokens`        | `int \| None`       | `None`  |
| `stop_sequences`    | `list[str] \| None` | `None`  |
| `additional_config` | `dict[str, Any]`    | `{}`    |

## Hooks

Lifecycle hooks use a generic `HookRegistry` + `Event[T]` pattern from `flowra.agent`.
Register handlers for typed event dataclasses. Supports multiple handlers per event,
sync/async transparency, and composition via `HookProvider`.

```python
from flowra.agent import HookRegistry
from flowra.lib.tool_loop import BeforeLLMCallEvent, AfterLLMCallEvent

hooks = HookRegistry()
hooks.on(BeforeLLMCallEvent, lambda e: print(f"Calling LLM with {len(e.data.request.messages)} messages"))
hooks.on(AfterLLMCallEvent, lambda e: print(f"LLM returned {e.data.response.stop_reason}"))

runtime = AgentRuntime(
    agents={"chat": ChatAgent},
    services={..., HookRegistry: hooks},
)
```

### `HookRegistry`

| Method                                      | Description                                      |
|---------------------------------------------|--------------------------------------------------|
| `on(event_type, handler, *, prepend=False)` | Register a handler for an event type             |
| `has_handlers(event_type) -> bool`          | Check if any handlers are registered             |
| `add(provider: HookProvider)`               | Register all hooks from a HookProvider           |
| `async emit(data: T) -> T`                  | Wrap data in `Event`, call handlers, return data |
| `propagate_to(target, *, only, exclude)`    | Forward events to another registry               |

Handlers receive `Event[T]` where `T` is the event dataclass. `Event` has two fields:
`data: T` (the event payload) and `context: HookContext | None` (metadata stamped by emit).
`HookContext` carries `agent_type: type[AbstractAgent] | None` and `agent_path: str`.
Handlers can mutate `event.data` fields to communicate results back.

### Hook events

| Event                  | Mutable fields                                   | Description                                                               |
|------------------------|--------------------------------------------------|---------------------------------------------------------------------------|
| `UserMessageEvent`     | `messages: list[UserMessage]`                    | Once at loop start. Mutate to replace or augment the initial messages.    |
| `MessageAcceptedEvent` | —                                                | After messages accepted (incl. on resume). Has `messages: list[Message]`. |
| `StartIterationEvent`  | `additional_messages: list[UserMessage]`         | At start of each iteration. Append to inject context before LLM call.     |
| `BeforeLLMCallEvent`   | —                                                | Before each LLM request. Has `request`, `context`.                        |
| `TextDeltaEvent`       | —                                                | During streaming. Has `text` (str), `context`.                            |
| `ThinkingDeltaEvent`   | —                                                | During streaming. Has `text` (str), `context`.                            |
| `AfterLLMCallEvent`    | —                                                | After each LLM response. Has `request`, `response`, `context`.            |
| `TextReasoningEvent`   | —                                                | For each `TextBlock` in response. Has `text` (TextBlock), `context`.      |
| `ThinkingEvent`        | —                                                | For each `ThinkingBlock` in response. Has `thinking`, `context`.          |
| `BeforeToolCallEvent`  | `tool_use: ToolUseBlock`                         | Before tool execution. Replace to modify tool parameters.                 |
| `AfterToolCallEvent`   | `result: ToolResultBlock`, `additional_messages` | After tool execution. Replace result or inject messages.                  |
| `ResultMessageEvent`   | `continue_messages: list[UserMessage]`           | On END_TURN. Set to continue loop instead of finishing.                   |

### Hook lifecycle

Events fire in this order during a single tool loop iteration:

1. **`UserMessageEvent`** — once at loop start, before the first iteration.
2. **`MessageAcceptedEvent`** — once after messages are accepted (including on resume).
3. **`StartIterationEvent`** — at the start of each iteration.
4. **`BeforeLLMCallEvent`** — before each LLM request.
5. **`TextDeltaEvent`** / **`ThinkingDeltaEvent`** — when handlers are registered for either,
   the agent uses `provider.stream()` instead of `provider.call()`. These fire **during**
   the LLM call, before `AfterLLMCallEvent`.
6. **`AfterLLMCallEvent`** — after each LLM response.
7. **`TextReasoningEvent`** — for each `TextBlock` in the assistant response.
8. **`ThinkingEvent`** — for each `ThinkingBlock` in the assistant response.

Then the flow branches based on stop reason:

- **If `TOOL_USE`:**
  9. **`BeforeToolCallEvent`** — before each tool execution.
  10. **`AfterToolCallEvent`** — after each tool execution.
- **If `END_TURN`:**
  11. **`ResultMessageEvent`** — set `continue_messages` to force the loop to continue.

## Prompt caching

`CacheConfig` controls prompt caching breakpoints on system prompts, tools, and messages
before each LLM call. Three strategy slots can be combined independently.

When a slot is `None`, user-provided `cache` hints are preserved as-is. When a
strategy is set, it **replaces** the caching policy for that slot — it decides
which elements get `cache=True`.

### `CacheConfig`

| Field           | Type                                | Default |
|-----------------|-------------------------------------|---------|
| `system_prompt` | `SystemPromptCacheStrategy \| None` | `None`  |
| `tools`         | `ToolsCacheStrategy \| None`        | `None`  |
| `messages`      | `MessagesCacheStrategy \| None`     | `None`  |

### Built-in strategies

Each `cache_*` strategy first clears all `cache=True` hints in its slot, then sets
its own target. This ensures exactly one cache breakpoint per slot regardless of
any pre-existing hints on input elements.

Each `no_cache_*` strategy clears all `cache=True` hints in its slot without
setting any new ones.

| Function                     | Slot            | Behavior                                                       |
|------------------------------|-----------------|----------------------------------------------------------------|
| `cache_last_system_prompt`   | `system_prompt` | Sets `cache=True` on the last block of the last system message |
| `cache_last_tool`            | `tools`         | Sets `cache=True` on the last tool                             |
| `cache_last_message`         | `messages`      | Sets `cache=True` on the last block across all messages        |
| `cache_last_session_message` | `messages`      | Same, but only within session messages (not turn messages)     |
| `no_cache_system_prompt`     | `system_prompt` | Clears all `cache=True` on system message blocks               |
| `no_cache_tools`             | `tools`         | Clears all `cache=True` on tools                               |
| `no_cache_messages`          | `messages`      | Clears all `cache=True` on message blocks                      |

### Presets

```python
from flowra.lib.tool_loop import CACHE_MANUAL, NO_CACHE, CACHE_ALL, CACHE_SESSION

# CACHE_MANUAL — preserves user-provided cache hints as-is (default)
# NO_CACHE — strips all cache hints
# CACHE_ALL — cache system prompt + tools + last message (all messages)
# CACHE_SESSION — cache system prompt + tools + last session message (excludes current turn)
```

## Tool services

Tools executed by `ToolLoopAgent` receive all services from the agent's scope —
everything registered in `AgentRuntime(services={...})` plus anything provided
by parent agents via `ServiceLocator.provide()`. Add a parameter with the desired type
to the tool handler (see `flowra.tools` docs for details on tool DI).

```python
class MyDatabase:
    def query(self, sql: str) -> list[dict]:
        ...

db = MyDatabase()

runtime = AgentRuntime(
    agents={"loop": ToolLoopAgent},
    services={..., MyDatabase: db},
)

@tool("lookup")
def lookup(params: LookupParams, db: MyDatabase) -> str:
    """Tool that uses MyDatabase — injected from runtime services."""
    rows = db.query(params.sql)
    return str(rows)
```

`ToolLoopAgent` also provides `ToolLoopAgentContext` into its scope via
`ServiceLocator.provide()`, and the runtime adds `InterruptToken` automatically.
Both are regular scope services — tools request them the same way:

```python
from flowra.agent import InterruptToken
from flowra.lib.tool_loop import ToolLoopAgentContext

@tool("long_task")
async def long_task(params: Params, interrupt: InterruptToken | None) -> str:
    """A tool that respects interrupts."""
    if interrupt is None:
        return "Done"
    try:
        await asyncio.wait_for(interrupt.wait(), timeout=5.0)
        return "Interrupted"
    except asyncio.TimeoutError:
        return "Done"

@tool("finish")
def finish(params: Params, context: ToolLoopAgentContext | None) -> str:
    """Request the loop to stop after this iteration."""
    if context:
        context.request_finish()
    return "Stopping"
```

### `ToolLoopAgentContext`

Available to tools and hooks. Methods:

- `request_finish()` — signals the loop to stop after the current iteration completes.
  The result will have `status=FINISH_REQUESTED`.
- `is_finish_requested() -> bool` — check whether `request_finish()` has been called.

## ConfigValue

A generic type for configuration fields that can be static or dynamic:

```python
type ConfigValue[T] = Callable[[], T | Awaitable[T]] | T
```

Three forms are supported:

```python
# Static value
config = ToolLoopConfig(max_iterations=10, ...)

# Sync callable
config = ToolLoopConfig(max_iterations=lambda: settings.max_iters, ...)

# Async callable
async def get_max_iterations() -> int:
    return await fetch_from_db("max_iterations")

config = ToolLoopConfig(max_iterations=get_max_iterations, ...)
```

Use `resolve_config_value()` to get the underlying value:

```python
from flowra.lib.config_value import resolve_config_value

value = await resolve_config_value(config.max_iterations)  # always returns T
```

## Type aliases

```python
# Cache strategy protocols
SystemPromptCacheStrategy   # (messages: list[SystemMessage]) -> list[SystemMessage]
ToolsCacheStrategy          # (tools: list[Tool]) -> list[Tool]
MessagesCacheStrategy       # (session_messages, turn_messages) -> list[Message]
```

## Internals

### Agent hierarchy

`ChatAgent` contains `ToolLoopAgent` as a subagent. `ToolLoopAgent` contains
`ToolCallAgent` as a subagent. Each tool call runs as a separate child node in
the execution tree, enabling parallel tool execution via `Spawn`.

```
ChatAgent
  └── ToolLoopAgent (subagent "tool_loop")
        └── ToolCallAgent (subagent "tool_call")
```

### Tool loop flow

1. `start` — accepts user message, emits `UserMessageEvent`, appends to
   `turn_messages`, flushes, emits `MessageAcceptedEvent`, then gotos `call_llm`.
2. `call_llm` — checks interrupt/finish/max_iterations, emits `StartIterationEvent`,
   builds `LLMRequest`, emits `BeforeLLMCallEvent`, calls LLM (streaming deltas via
   `TextDeltaEvent`/`ThinkingDeltaEvent` if handlers registered), emits `AfterLLMCallEvent`,
   `TextReasoningEvent`, and `ThinkingEvent`, then:
   - `END_TURN` → emits `ResultMessageEvent`, returns `ToolLoopResult` (or continues
     if `continue_messages` is non-empty)
   - `TOOL_USE` → emits `BeforeToolCallEvent` for each tool, spawns `ToolCallAgent`
     children in parallel
3. `collect_results` — gathers results from `ToolCallAgent` children, emits
   `AfterToolCallEvent` for each, applies `max_consecutive_errors` logic,
   appends tool results to `turn_messages`, gotos `call_llm`.
