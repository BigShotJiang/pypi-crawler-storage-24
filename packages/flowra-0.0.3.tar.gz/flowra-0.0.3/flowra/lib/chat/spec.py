import dataclasses
from typing import Any

from ...agent import AgentResult, StepSpec
from ...llm import Usage

__all__ = ["ChatResult", "ChatSpec"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatSpec(StepSpec):
    user_message: str
    metadata: dict[str, Any] | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatResult(AgentResult):
    response: str | None = None
    usage: Usage | None = None
