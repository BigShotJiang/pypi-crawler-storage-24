# Event dataclasses for ChatAgent hooks.
#
# NOT frozen: handlers can mutate fields to communicate
# outcomes back to the agent.

import dataclasses

from ...llm import Message

__all__ = [
    "SaveTurnMessagesEvent",
]


@dataclasses.dataclass(slots=True, kw_only=True)
class SaveTurnMessagesEvent:
    """Emitted before turn messages are saved into session history.

    Replace ``messages`` to control what gets persisted — e.g. filter out
    transient messages injected by hooks.
    """

    messages: list[Message]  # replace to filter before saving to session history
