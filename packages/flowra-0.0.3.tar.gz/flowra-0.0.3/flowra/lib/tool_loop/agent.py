import dataclasses
import logging
from typing import ClassVar

from ...agent import (
    Agent,
    AgentDefinitionRef,
    AgentStore,
    AppendOnlyList,
    Call,
    Goto,
    HookRegistry,
    InterruptToken,
    Scalar,
    ServiceLocator,
    Spawn,
    slot,
    step,
    with_interrupt,
)
from ...llm import (
    AssistantMessage,
    ContentComplete,
    LLMProvider,
    LLMRequest,
    Message,
    StopReason,
    TextBlock,
    TextDelta,
    ThinkingBlock,
    ThinkingDelta,
    ToolResultBlock,
    ToolUseBlock,
    Usage,
    UserBlock,
    UserMessage,
)
from ...tools import ToolRegistry
from ..config_value import resolve_config_value
from ._tool_call_agent import ToolCallAgent, ToolCallResult, ToolCallSpec
from .config import ToolLoopConfig
from .context import ToolLoopAgentContext
from .hook_events import (
    AfterLLMCallEvent,
    AfterToolCallEvent,
    BeforeLLMCallEvent,
    BeforeToolCallEvent,
    MessageAcceptedEvent,
    ResultMessageEvent,
    StartIterationEvent,
    TextDeltaEvent,
    TextReasoningEvent,
    ThinkingDeltaEvent,
    ThinkingEvent,
    UserMessageEvent,
)
from .spec import ToolLoopResult, ToolLoopSpec, ToolLoopStatus

__all__ = ["ToolLoopAgent"]

logger = logging.getLogger(__name__)


class ToolLoopAgent(Agent):
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
        "tool_call": ToolCallAgent,
    }

    __turn_messages: AppendOnlyList[Message] = slot("turn_messages")
    __iteration: Scalar[int] = slot("iteration")
    __usage: Scalar[Usage | None] = slot("usage")
    __consecutive_errors: Scalar[dict[str, int]] = slot("consecutive_errors")

    def __init__(
        self,
        store: AgentStore,
        services: ServiceLocator,
        registry: ToolRegistry,
        config: ToolLoopConfig,
        provider: LLMProvider,
        interrupt: InterruptToken,
        hooks: HookRegistry | None = None,
    ) -> None:
        self.__store = store
        self.__interrupt = interrupt
        self.__registry = registry
        self.__provider = provider
        self.__context = ToolLoopAgentContext()
        self.__config = config
        self.__hooks = hooks or HookRegistry()

        services.provide(ToolLoopAgentContext, self.__context)

    @step("start")
    async def start(self, spec: ToolLoopSpec) -> Goto:
        if not (accepted_messages := self.__turn_messages.get_all()):  # skip on resume — already added + flushed
            user_message = UserMessage(blocks=[TextBlock(text=spec.user_message)])

            event = await self.__hooks.emit(UserMessageEvent(messages=[user_message]))
            self.__turn_messages.extend(event.messages)
            await self.__store.flush()
            accepted_messages: list[Message] = list(event.messages)

        await self.__hooks.emit(
            MessageAcceptedEvent(
                messages=accepted_messages,
                metadata=spec.metadata or {},
            )
        )
        return Goto(step=self.call_llm)

    @step("call_llm")
    async def call_llm(self) -> Goto | Spawn | ToolLoopResult:
        if self.__interrupt.interrupted:
            return self.__result(ToolLoopStatus.INTERRUPTED)
        if self.__context.is_finish_requested():
            return self.__result(ToolLoopStatus.FINISH_REQUESTED)

        iteration = self.__iteration.get(0)
        max_iterations = await resolve_config_value(self.__config.max_iterations)
        if iteration >= max_iterations:
            return self.__result(ToolLoopStatus.MAX_ITERATIONS)

        self.__iteration.set(iteration + 1)
        logger.info("Tool loop iteration %d/%d", iteration + 1, max_iterations)

        start_event = await self.__hooks.emit(StartIterationEvent(iteration=iteration + 1, context=self.__context))
        if start_event.additional_messages:
            self.__turn_messages.extend(start_event.additional_messages)

        llm_config = await resolve_config_value(self.__config.llm_config)
        session_messages = await resolve_config_value(self.__config.session_messages)
        turn_messages = self.__turn_messages.get_all()

        tools = self.__registry.get_llm_tools()
        allowed_tools = await resolve_config_value(self.__config.allowed_tools)
        denied_tools = await resolve_config_value(self.__config.denied_tools)
        if allowed_tools is not None:
            tools = [t for t in tools if t.name in allowed_tools]
        if denied_tools is not None:
            tools = [t for t in tools if t.name not in denied_tools]

        cache_strategy = await resolve_config_value(self.__config.cache_strategy)
        messages, tools = cache_strategy.apply(session_messages, turn_messages, tools)
        json_schema = await resolve_config_value(self.__config.json_schema)

        request = LLMRequest(
            model=llm_config.model,
            messages=messages,
            tools=tools,
            json_schema=json_schema,
            temperature=llm_config.temperature,
            max_tokens=llm_config.max_tokens,
            stop_sequences=llm_config.stop_sequences,
            additional_config=llm_config.additional_config,
        )

        await self.__hooks.emit(BeforeLLMCallEvent(request=request, context=self.__context))

        if self.__hooks.has_handlers(TextDeltaEvent) or self.__hooks.has_handlers(ThinkingDeltaEvent):
            response = None
            async for event in with_interrupt(self.__provider.stream(request), self.__interrupt):
                match event:
                    case TextDelta(text=text):
                        await self.__hooks.emit(TextDeltaEvent(text=text, context=self.__context))
                    case ThinkingDelta(text=text):
                        await self.__hooks.emit(ThinkingDeltaEvent(text=text, context=self.__context))
                    case ContentComplete(response=resp):
                        response = resp
            if self.__interrupt.interrupted:
                return self.__result(ToolLoopStatus.INTERRUPTED)
            assert response is not None
        else:
            response = await self.__provider.call(request)

        await self.__hooks.emit(AfterLLMCallEvent(request=request, response=response, context=self.__context))

        if response.usage is not None:
            current_usage = self.__usage.get(None)
            self.__usage.set(current_usage + response.usage if current_usage is not None else response.usage)

        for block in response.message.blocks:
            if isinstance(block, TextBlock):
                await self.__hooks.emit(TextReasoningEvent(text=block, context=self.__context))
            elif isinstance(block, ThinkingBlock):
                await self.__hooks.emit(ThinkingEvent(thinking=block, context=self.__context))

        match response.stop_reason:
            case StopReason.END_TURN:
                self.__turn_messages.append(response.message)

                result_event = await self.__hooks.emit(
                    ResultMessageEvent(message=response.message, context=self.__context)
                )
                if result_event.continue_messages:
                    self.__turn_messages.extend(result_event.continue_messages)
                    return Goto(step=self.call_llm)

                return self.__result(
                    ToolLoopStatus.COMPLETED, stop_reason=StopReason.END_TURN, result_message=response.message
                )

            case StopReason.TOOL_USE:
                tool_uses = [block for block in response.message.blocks if isinstance(block, ToolUseBlock)]

                amendments: dict[str, ToolUseBlock] = {}
                final_tool_uses = []
                for tool_use in tool_uses:
                    before_event = await self.__hooks.emit(
                        BeforeToolCallEvent(tool_use=tool_use, context=self.__context)
                    )
                    final_tool_uses.append(before_event.tool_use)
                    if before_event.tool_use is not tool_use:
                        amendments[tool_use.id] = before_event.tool_use

                if amendments:
                    new_blocks = [
                        amendments.get(b.id, b) if isinstance(b, ToolUseBlock) else b for b in response.message.blocks
                    ]
                    self.__turn_messages.append(dataclasses.replace(response.message, blocks=new_blocks))
                else:
                    self.__turn_messages.append(response.message)

                children = [
                    Call(
                        agent=ToolCallAgent,
                        step=ToolCallAgent.execute,
                        spec=ToolCallSpec(
                            tool_use=tool_use,
                            allowed_tools=allowed_tools,
                            denied_tools=denied_tools,
                        ),
                    )
                    for tool_use in final_tool_uses
                ]
                return Spawn(children=children, then=self.collect_results)

            case (
                StopReason.MAX_TOKENS
                | StopReason.STOP_SEQUENCE
                | StopReason.SCHEMA_VALIDATION_FAILED
                | StopReason.OTHER
            ):
                self.__turn_messages.append(response.message)
                return self.__result(
                    ToolLoopStatus.COMPLETED, stop_reason=response.stop_reason, result_message=response.message
                )

    @step("collect_results")
    async def collect_results(self, results: list[ToolCallResult]) -> Goto | ToolLoopResult:
        final_blocks: list[UserBlock] = []
        all_additional_messages: list[UserMessage] = []
        consecutive_errors = dict(self.__consecutive_errors.get({}))
        max_consecutive = await resolve_config_value(self.__config.max_consecutive_errors)

        for tc_result in results:
            after_event = await self.__hooks.emit(
                AfterToolCallEvent(tool_use=tc_result.tool_use, result=tc_result.result, context=self.__context)
            )

            result_block = after_event.result
            all_additional_messages.extend(after_event.additional_messages)

            if max_consecutive is not None:
                tool_name = tc_result.tool_use.name
                if result_block.is_error:
                    consecutive_errors[tool_name] = consecutive_errors.get(tool_name, 0) + 1
                    if consecutive_errors[tool_name] >= max_consecutive:
                        result_block = ToolResultBlock(
                            tool_use_id=tc_result.tool_use.id,
                            content=f"Tool {tool_name} has failed {max_consecutive} times consecutively. "
                            f"Please try a different approach.",
                            is_error=True,
                        )
                else:
                    consecutive_errors[tool_name] = 0

            final_blocks.append(result_block)

        self.__consecutive_errors.set(consecutive_errors)
        user_message = UserMessage(blocks=final_blocks)
        self.__turn_messages.append(user_message)

        self.__turn_messages.extend(all_additional_messages)

        if self.__interrupt.interrupted:
            return self.__result(ToolLoopStatus.INTERRUPTED)
        if self.__context.is_finish_requested():
            return self.__result(ToolLoopStatus.FINISH_REQUESTED)

        return Goto(step=self.call_llm)

    def __result(
        self,
        status: ToolLoopStatus,
        stop_reason: StopReason | None = None,
        result_message: AssistantMessage | None = None,
    ) -> ToolLoopResult:
        return ToolLoopResult(
            messages=self.__turn_messages.get_all(),
            status=status,
            stop_reason=stop_reason,
            result_message=result_message,
            usage=self.__usage.get(None),
        )
