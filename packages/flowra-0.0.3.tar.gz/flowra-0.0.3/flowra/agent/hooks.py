from __future__ import annotations

import dataclasses
import inspect
from collections.abc import Callable
from typing import Any, Protocol

from .agent_def import AbstractAgent

__all__ = [
    "Event",
    "HookContext",
    "HookProvider",
    "HookRegistry",
]


@dataclasses.dataclass(slots=True, kw_only=True)
class HookContext:
    """Metadata stamped on every emitted event.

    Not frozen — may be enriched by runtime in future.
    """

    agent_type: type[AbstractAgent] | None
    agent_path: str


@dataclasses.dataclass(slots=True)
class Event[T]:
    """Generic envelope wrapping event data with optional context.

    Not frozen — context is stamped by emit().
    Not kw_only — single positional `data` arg is ergonomic for internal use.
    """

    data: T
    context: HookContext | None = None


class HookProvider(Protocol):
    """Interface for objects that register hooks on a registry."""

    def register_hooks(self, registry: HookRegistry) -> None: ...


class HookRegistry:
    """Central registry for event handlers.

    Supports multiple handlers per event type, sync/async transparency,
    composition via HookProvider, and explicit isolation via propagate_to().
    """

    __slots__ = ("__context", "__handlers")

    def __init__(self, context: HookContext | None = None) -> None:
        self.__context = context
        self.__handlers: dict[type, list[Callable[..., Any]]] = {}

    def on[E](self, event_type: type[E], handler: Callable[[Event[E]], Any], *, prepend: bool = False) -> None:
        """Register a handler for an event type."""
        handlers = self.__handlers.setdefault(event_type, [])
        if prepend:
            handlers.insert(0, handler)
        else:
            handlers.append(handler)

    def has_handlers(self, event_type: type) -> bool:
        """Check whether any handlers are registered for an event type."""
        handlers = self.__handlers.get(event_type)
        return handlers is not None and len(handlers) > 0

    def add(self, provider: HookProvider) -> None:
        """Register all hooks from a HookProvider."""
        provider.register_hooks(self)

    async def emit[T](self, data: T) -> T:
        """Wrap data in Event, call all handlers, return (potentially mutated) data."""
        event = Event(data, context=self.__context)
        handlers = self.__handlers.get(type(data))
        if handlers:
            for handler in handlers:
                result = handler(event)
                if inspect.isawaitable(result):
                    await result
        return event.data

    def propagate_to(
        self,
        target: HookRegistry,
        *,
        only: list[type] | None = None,
        exclude: list[type] | None = None,
    ) -> None:
        """Register forwarding handlers that re-emit events to target.

        Args:
            target: Registry to forward events to.
            only: If set, only forward these event types.
            exclude: If set, skip these event types.
        """
        source_types: set[type] = set(self.__handlers.keys())
        if only is not None:
            source_types = set(only)
        if exclude is not None:
            source_types -= set(exclude)

        for event_type in source_types:

            async def _forward(event: Event[Any], _target: HookRegistry = target) -> None:
                await _target.emit(event.data)

            self.on(event_type, _forward)
