"""LLM request/response logging hooks and setup for chat examples.

Usage::

    from examples.llm_logging import log_before_llm_call, log_after_llm_call, setup_file_logging
    from flowra.agent import HookRegistry
    from flowra.lib.tool_loop import BeforeLLMCallEvent, AfterLLMCallEvent

    setup_file_logging("console_chat")
    hooks = HookRegistry()
    hooks.on(BeforeLLMCallEvent, lambda e: log_before_llm_call(e.data.request, e.data.context))
    hooks.on(AfterLLMCallEvent, lambda e: log_after_llm_call(e.data.request, e.data.response, e.data.context))
"""

import datetime
import logging
import os

from flowra.llm import ImageBlock, LLMRequest, LLMResponse, TextBlock, ThinkingBlock, ToolResultBlock, ToolUseBlock
from flowra.llm.messages import Message

_LOGS_DIR = "logs"

logger = logging.getLogger(__name__)


def setup_file_logging(prefix: str) -> logging.FileHandler:
    """Configure file logging for LLM calls and return the handler.

    Creates a timestamped log file in the logs/ directory.
    The returned handler can be added to additional loggers if needed.
    """
    os.makedirs(_LOGS_DIR, exist_ok=True)
    filename = datetime.datetime.now().strftime(f"{prefix}_%Y%m%d_%H%M%S.log")
    handler = logging.FileHandler(os.path.join(_LOGS_DIR, filename), mode="w", encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s.%(msecs)03d  %(message)s", datefmt="%H:%M:%S"))

    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    return handler


def _format_messages(messages: list[Message]) -> str:
    parts: list[str] = []
    for i, msg in enumerate(messages):
        parts.append(f"  [{i}] {msg.role}:")
        for block in msg.blocks:
            match block:
                case TextBlock(text=text):
                    parts.append(f"       text: {text}")
                case ToolUseBlock(id=tid, name=name, input=inp):
                    parts.append(f"       tool_use: {name} (id={tid}) input={inp}")
                case ToolResultBlock(tool_use_id=tid, content=content, is_error=is_error):
                    error_marker = " [ERROR]" if is_error else ""
                    parts.append(f"       tool_result: (id={tid}){error_marker} {content}")
                case ThinkingBlock(text=text):
                    parts.append(f"       thinking: {text[:200]}...")
                case ImageBlock(media_type=media_type):
                    parts.append(f"       image: {media_type}")
    return "\n".join(parts)


def log_before_llm_call(request: LLMRequest, context: object) -> None:
    if not logger.isEnabledFor(logging.DEBUG):
        return
    logger.debug(
        "LLM request: model=%s, messages=%d, tools=%d\n%s",
        request.model,
        len(request.messages),
        len(request.tools) if request.tools else 0,
        _format_messages(request.messages),
    )


def log_after_llm_call(request: LLMRequest, response: LLMResponse, context: object) -> None:
    if not logger.isEnabledFor(logging.DEBUG):
        return
    logger.debug(
        "LLM response: stop_reason=%s, usage=%s\n%s",
        response.stop_reason,
        response.usage,
        _format_messages([response.message]),
    )
