# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com),
and this project adheres to [Semantic Versioning](https://semver.org).

## [Unreleased]

## [0.0.3] - 2026-03-08

### Changed
- **Hook system redesign**: replaced `ToolLoopHooks`/`ChatHooks` (24 Protocol classes, 12 executor
  functions, 5 result dataclasses) with generic `HookRegistry` + `Event[T]` pattern. Supports
  multiple handlers per event, `HookProvider` for distributable hook sets, and `propagate_to()`
  for parent/child isolation. Hook events are plain mutable dataclasses with result fields.
- `ToolLoopSpec.meta` / `ChatSpec.meta` renamed to `metadata`.

## [0.0.2] - 2026-03-08

### Added
- **Streaming**: `LLMProvider.stream()` method returns `AsyncIterator[StreamEvent]` with `TextDelta`, `ThinkingDelta`, and `ContentComplete` events. All three built-in providers implement real-time streaming. Default fallback calls `call()` and yields `ContentComplete`.
- **Anthropic thinking**: `AnthropicVertexAdditionalConfig` with `thinking_budget_tokens` enables extended thinking on Claude models. Thinking blocks are now parsed from Anthropic responses (`ThinkingBlock`).
- **Streaming hooks**: `on_text_delta` and `on_thinking_delta` hooks in `ToolLoopHooks`. When set, the agent automatically uses `stream()` instead of `call()`. Streaming respects `InterruptToken` — exits immediately even if the LLM is blocked.
- **`with_interrupt`**: Generic async iterator wrapper that races `__anext__()` against `InterruptToken.wait()` via `asyncio.wait(FIRST_COMPLETED)`. Used internally by `ToolLoopAgent` for streaming; available as `from flowra.agent import with_interrupt`.
- **Thinking model entry**: `anthropic/sonnet-4-5-think` in example model registry with 4000 token thinking budget.
- **Console/TUI streaming**: `--stream` flag for `console_chat.py` and `tui_chat.py` examples.

## [0.0.1] - 2026-03-07

Initial release.

### Added
- State machine agents with `@step` methods, `Goto`, `Spawn`, and stored values (`Scalar`, `AppendOnlyList`)
- Provider-agnostic LLM abstraction (`LLMProvider`, `LLMRequest`, `LLMResponse`)
- LLM providers: `AnthropicVertexProvider`, `GoogleVertexProvider`, `OpenAIProvider`
- Tool integration: `@tool` decorator, MCP server support, DI into tool handlers
- Execution engine with persistence, crash recovery, and cooperative interrupts
- Pre-built agents: `ChatAgent` (multi-turn chat) and `ToolLoopAgent` (tool loop with hooks)
- `ChatHooks` with `on_save_turn_messages` for transient message filtering
- Optional provider dependencies via extras: `flowra[anthropic]`, `flowra[openai]`, `flowra[google]`, `flowra[all]`
- Python 3.12, 3.13, 3.14 support
