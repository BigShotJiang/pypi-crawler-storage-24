(
    1,
    "hello",
    true,
    null,
)
