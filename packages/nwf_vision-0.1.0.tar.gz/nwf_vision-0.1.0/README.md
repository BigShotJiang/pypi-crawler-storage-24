# nwf-vision

[![PyPI version](https://badge.fury.io/py/nwf-vision.svg)](https://pypi.org/project/nwf-vision/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![Tests](https://github.com/romero19912017-ui/nwf-vision/actions/workflows/test.yml/badge.svg)](https://github.com/romero19912017-ui/nwf-vision/actions/workflows/test.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

NWF for computer vision: ConvVAE, pretrained encoders, continual learning on images.

## Installation

```bash
pip install nwf-vision
# Requires: nwf-core, torch, torchvision
```

## Quick start

```python
from nwf.vision import ConvVAEEncoder
from nwf import Charge, Field
import numpy as np

enc = ConvVAEEncoder(input_shape=(3, 32, 32), latent_dim=64)
enc.fit(images, epochs=10)

z, sigma = enc.encode(images[:5])
field = Field()
for i in range(5):
    field.add(Charge(z=z[i], sigma=sigma[i]), labels=[labels[i]])
```

## Components

- **ConvVAEEncoder** - convolutional VAE for images (CIFAR, MNIST)
- **PretrainedVisionEncoder** - ResNet/EfficientNet + (z, sigma) head
- **Examples**: Split-CIFAR-10, OOD detection, active learning

## Run example

```bash
pip install nwf-core nwf-vision
python examples/split_cifar.py --epochs 5
```

Note: if you have nwf-research in PYTHONPATH, it may shadow nwf-core. Use a clean env or install nwf-core in development mode.

## License

MIT
