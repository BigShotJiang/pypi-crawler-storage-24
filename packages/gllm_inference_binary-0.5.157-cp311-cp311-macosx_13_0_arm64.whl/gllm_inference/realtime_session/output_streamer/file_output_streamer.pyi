from gllm_inference.realtime_session.constants import InputAudioConfig as InputAudioConfig, OutputAudioConfig as OutputAudioConfig
from gllm_inference.realtime_session.output_streamer.output_streamer import BaseOutputStreamer as BaseOutputStreamer
from gllm_inference.realtime_session.schema import RealtimeActivityType as RealtimeActivityType, RealtimeDataType as RealtimeDataType, RealtimeEvent as RealtimeEvent, RealtimeEventType as RealtimeEventType
from pathlib import Path

BASE_DIR: str
TEXT_FILENAME: str
AUDIO_FILENAME: str

class FileOutputStreamer(BaseOutputStreamer):
    """[BETA] A file output streamer that saves the output events to text or audio files.

    Attributes:
        state (RealtimeState): The state of the output streamer.
        output_types (list[RealtimeDataType]): The types of output to save.
        base_dir (Path): The base directory to save the output.
        text_path (Path): The path to the text output file.
        audio_path (Path): The path to the audio output file.
    """
    output_types: list[RealtimeDataType]
    base_dir: Path
    text_path: Path
    audio_path: Path
    def __init__(self, output_types: list[RealtimeDataType] | None = None, base_dir: str | Path = ..., text_filename: str = ..., audio_filename: str = ...) -> None:
        """Initializes the FileOutputStreamer.

        Args:
            output_types (list[RealtimeDataType], optional): The types of output to save.
                Defaults to [RealtimeDataType.TEXT, RealtimeDataType.AUDIO].
            base_dir (str | Path, optional): The base directory to save the output. Defaults to BASE_DIR.
            text_filename (str, optional): The filename for the text output. Defaults to TEXT_FILENAME.
            audio_filename (str, optional): The filename for the audio output files. Defaults to AUDIO_FILENAME.
        """
    async def handle(self, event: RealtimeEvent) -> None:
        """Handles the output events.

        This method is used to handle the output events and save them to the specified files.

        Args:
            event (RealtimeEvent): The realtime events to handle.
        """
    async def close(self) -> None:
        """Closes the output streamer.

        This method closes the FileOutputStreamer and saves the audio response if audio output is configured.
        """
