from _typeshed import Incomplete
from gllm_inference.input_transformer.filter_empty_input_transformer import FilterEmptyInputTransformer as FilterEmptyInputTransformer
from gllm_inference.input_transformer.identity_input_transformer import IdentityInputTransformer as IdentityInputTransformer
from gllm_inference.input_transformer.input_transformer import BaseInputTransformer as BaseInputTransformer
from gllm_inference.schema.enums import InputTransformerType as InputTransformerType
from typing import Any

INPUT_TRANSFORMER_TYPE_MAP: Incomplete

def build_input_transformer(type: InputTransformerType, **kwargs: Any) -> BaseInputTransformer:
    """Build an input transformer based on the provided configurations.

    Examples:
        # Using identity input transformer
        ```python
        input_transformer = build_input_transformer(InputTransformerType.IDENTITY)
        ```

        # Using filter empty input transformer
        ```python
        input_transformer = build_input_transformer(InputTransformerType.FILTER_EMPTY)
        ```

    Args:
        type (InputTransformerType): The type of input transformer to use.
        **kwargs (Any): Additional keyword arguments to pass to the input transformer constructor.

    Returns:
        BaseInputTransformer: The initialized input transformer.

    Raises:
        ValueError: If the provided type is not supported.
    """
