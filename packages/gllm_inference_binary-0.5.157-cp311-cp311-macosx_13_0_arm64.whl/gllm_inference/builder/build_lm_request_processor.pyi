from gllm_inference.lm_invoker.build_lm_invoker import build_lm_invoker as build_lm_invoker
from gllm_inference.request_processor.lm_request_processor import LMRequestProcessor
from gllm_inference.schema import ModelId
from typing import Any

__all__ = ['build_lm_request_processor', 'build_lm_invoker']

def build_lm_request_processor(model_id: str | ModelId, credentials: str | dict[str, Any] | None = None, config: dict[str, Any] | None = None, system_template: str = '', user_template: str = '', key_defaults: dict[str, Any] | None = None, prompt_builder_kwargs: dict[str, Any] | None = None, output_parser_type: str = 'none') -> LMRequestProcessor:
    '''Deprecated function to build a language model request processor.

    This function is deprecated and will be removed in v0.6.0. Use
    `from gllm_inference.request_processor.build_lm_request_processor` instead.

    Args:
        model_id (str | ModelId): The model id.
        credentials (str | dict[str, Any] | None, optional): The credentials.
        config (dict[str, Any] | None, optional): Additional configuration.
        system_template (str): The system prompt template. Defaults to an empty string.
        user_template (str): The user prompt template. Defaults to an empty string.
        key_defaults (dict[str, Any] | None, optional): Default values for template keys.
        prompt_builder_kwargs (dict[str, Any] | None, optional): Additional prompt builder kwargs.
        output_parser_type (str): The output parser type. Defaults to "none".

    Returns:
        LMRequestProcessor: The initialized language model request processor.
    '''
