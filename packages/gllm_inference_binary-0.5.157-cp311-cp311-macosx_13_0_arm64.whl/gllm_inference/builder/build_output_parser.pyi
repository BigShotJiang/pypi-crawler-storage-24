from gllm_inference.output_parser.build_output_parser import OUTPUT_PARSER_TYPE_MAP as OUTPUT_PARSER_TYPE_MAP
from gllm_inference.output_parser.output_parser import BaseOutputParser

__all__ = ['OUTPUT_PARSER_TYPE_MAP', 'build_output_parser']

def build_output_parser(output_parser_type: str) -> BaseOutputParser | None:
    '''Deprecated function to build an output parser.

    Args:
        output_parser_type (str): The type of output parser to use. Supports "json" and "none".

    Returns:
        BaseOutputParser | None: The initialized output parser.
    '''
