from gllm_inference.em_invoker.build_em_invoker import PROVIDER_TO_EM_INVOKER_MAP as PROVIDER_TO_EM_INVOKER_MAP
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from gllm_inference.schema import ModelId
from typing import Any

__all__ = ['PROVIDER_TO_EM_INVOKER_MAP', 'build_em_invoker']

def build_em_invoker(model_id: str | ModelId, credentials: str | dict[str, Any] | None = None, config: dict[str, Any] | None = None) -> BaseEMInvoker:
    """Deprecated function to build an embedding model invoker.

    This function is deprecated and will be removed in v0.6.0. Use
    `from gllm_inference.em_invoker.build_em_invoker` instead.

    Args:
        model_id (str | ModelId): The model id.
        credentials (str | dict[str, Any] | None, optional): The credentials.
        config (dict[str, Any] | None, optional): Additional configuration.

    Returns:
        BaseEMInvoker: The initialized embedding model invoker.
    """
