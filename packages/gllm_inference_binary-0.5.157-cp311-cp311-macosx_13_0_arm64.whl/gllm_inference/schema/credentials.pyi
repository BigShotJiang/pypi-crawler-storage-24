from pydantic import BaseModel
from pydantic.types import SecretStr

GOOGLE_OAUTH_TOKEN_URL: str
EXPIRES_IN_BUFFER: int

class OAuthCredentials(BaseModel):
    """Defines OAuth credentials for MCP connectors.

    Sensitive fields are masked on access and serialization.
    Use .get_secret_value() only when the raw value is required.

    Attributes:
        client_id (SecretStr): The client ID (masked on access).
        client_secret (SecretStr): The client secret (masked on access).
        refresh_token (SecretStr): The refresh token (masked on access).
    """
    client_id: SecretStr
    client_secret: SecretStr
    refresh_token: SecretStr
    async def get_access_token(self) -> str:
        """Gets the access token.

        This method checks if the access token is expired or expiring and refreshes it if necessary,
        then returns the access token. Concurrent callers are serialized so only one refresh runs at a time.

        Returns:
            str: The access token.
        """
