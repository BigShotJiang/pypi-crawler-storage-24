## [1.8.1] - 2026-03-09

### Bug Fixes
- Cleanup transient resources ([862cf10](https://github.com/experimaestro/experimaestro-python/commit/862cf1074c268cdca5633f6370450815d52d9bcc))

