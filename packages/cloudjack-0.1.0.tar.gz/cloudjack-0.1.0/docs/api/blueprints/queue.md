# QueueBlueprint

::: cloud.base.queue
