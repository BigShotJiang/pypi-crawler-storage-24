# ComputeBlueprint

::: cloud.base.compute
