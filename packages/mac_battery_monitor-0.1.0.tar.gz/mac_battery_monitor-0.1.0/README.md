# mac-battery-monitor

Real-time battery charging speed monitor for macOS, showing current draw (mA), power (W), charge level, temperature, health, and estimated time to full/empty.

## Install

```bash
pip install mac-battery-monitor
```

Or from source:

```bash
git clone https://github.com/yeahea-hoque-shoumik/mac-battery-monitor.git
cd mac-battery-monitor
pip install .
```

## Usage

```bash
battery-monitor               # default 1s refresh
battery-monitor -i 0.5        # custom refresh interval (seconds)
battery-monitor --log         # also log readings to battery_log.csv
```

## Requirements

- macOS only (uses `ioreg` to read `AppleSmartBattery`)
- Python 3.10+
- No third-party dependencies

## Output

```
──────────────────────────────────────────────────────
  ⚡  macOS Battery Monitor   2026-03-23  12:00:00
──────────────────────────────────────────────────────

  Charge level        [████████████████░░░░░░░░░░░░░░]  54.3%
  Current rate        +1842 mA  charging
  Power draw          20.34 W
  Voltage             11043 mV
  Temperature         34.5 °C
  Battery health      91.2%  (8300/9100 mAh)
  Cycle count         142
  ETA                 1h 12m until full

  Plugged in: Yes   Charging: Yes   Full: No

  Refresh every 1.0s  |  No logging  |  Ctrl-C to quit
──────────────────────────────────────────────────────
```

## License

MIT
