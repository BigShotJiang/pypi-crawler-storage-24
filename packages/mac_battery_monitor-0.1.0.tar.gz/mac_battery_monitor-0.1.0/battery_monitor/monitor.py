#!/usr/bin/env python3
"""
battery_monitor.py — Real-time battery charging speed monitor for macOS
Usage:
    python battery_monitor.py           # default 1s refresh
    python battery_monitor.py -i 0.5   # custom interval in seconds
    python battery_monitor.py --log     # also write to battery_log.csv
"""

import subprocess
import re
import time
import sys
import os
import argparse
import csv
from datetime import datetime

# ── ANSI colours ────────────────────────────────────────────────────────────
RESET  = "\033[0m"
BOLD   = "\033[1m"
GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
DIM    = "\033[2m"
CLEAR  = "\033[2J\033[H"   # clear screen + move cursor to top


# ── Data layer ───────────────────────────────────────────────────────────────
def get_battery_info() -> dict:
    """Read raw values from ioreg AppleSmartBattery."""
    try:
        output = subprocess.check_output(
            ["ioreg", "-rn", "AppleSmartBattery"],
            text=True, stderr=subprocess.DEVNULL
        )
    except subprocess.CalledProcessError:
        return {}

    def extract(key):
        m = re.search(rf'"{key}"\s*=\s*(-?\d+)', output)
        return int(m.group(1)) if m else None

    def extract_bool(key):
        m = re.search(rf'"{key}"\s*=\s*(Yes|No)', output)
        return m.group(1) == "Yes" if m else None

    # Nested BatteryData block for DesignCapacity
    design = None
    bd = re.search(r'"BatteryData"\s*=\s*\{([^}]+)\}', output)
    if bd:
        m = re.search(r'"DesignCapacity"=(\d+)', bd.group(1))
        design = int(m.group(1)) if m else None

    return {
        "amperage_raw":    extract("InstantAmperage"),
        "voltage_mv":      extract("Voltage"),
        "current_mah":     extract("CurrentCapacity"),
        "max_mah":         extract("MaxCapacity"),
        "design_mah":      design or extract("DesignCapacity"),
        "temperature_raw": extract("Temperature"),
        "cycle_count":     extract("CycleCount"),
        "is_charging":     extract_bool("IsCharging"),
        "is_plugged":      extract_bool("ExternalConnected"),
        "is_full":         extract_bool("FullyCharged"),
    }


def fix_amperage(raw) -> int | None:
    """ioreg returns negative amps as unsigned 64-bit; convert back."""
    if raw is None:
        return None
    if raw > 2**63:
        return raw - 2**64
    return raw


# ── Derived metrics ──────────────────────────────────────────────────────────
def compute_metrics(info: dict) -> dict:
    ma      = fix_amperage(info.get("amperage_raw"))
    mv      = info.get("voltage_mv")
    cur     = info.get("current_mah")
    mx      = info.get("max_mah")
    tmp_raw = info.get("temperature_raw")

    watts   = abs(ma * mv) / 1_000_000 if (ma is not None and mv) else None
    pct     = cur / mx * 100           if (cur and mx)             else None
    celsius = tmp_raw / 100            if tmp_raw                  else None

    # time-to-full / time-to-empty (rough estimate)
    eta_min = None
    if ma and cur and mx:
        if ma > 0:                                    # charging
            remaining = mx - cur
            eta_min = (remaining / ma) * 60 if ma > 0 else None
        elif ma < 0:                                  # discharging
            eta_min = (cur / abs(ma)) * 60

    return {
        "ma":       ma,
        "mv":       mv,
        "watts":    watts,
        "pct":      pct,
        "celsius":  celsius,
        "eta_min":  eta_min,
    }


# ── Formatting helpers ───────────────────────────────────────────────────────
def fmt_rate(ma, is_charging, is_plugged, is_full) -> str:
    if ma is None:
        return f"{YELLOW}N/A{RESET}"
    if is_full:
        return f"{GREEN}Fully charged{RESET}"
    if ma > 50:
        return f"{GREEN}{BOLD}+{ma} mA{RESET}  {DIM}charging{RESET}"
    elif ma < -50:
        return f"{RED}{BOLD}{ma} mA{RESET}  {DIM}discharging{RESET}"
    else:
        return f"{YELLOW}{ma} mA{RESET}  {DIM}idle / standby{RESET}"


def fmt_eta(eta_min, ma) -> str:
    if eta_min is None or abs(ma or 0) < 50:
        return "—"
    h = int(eta_min // 60)
    m = int(eta_min % 60)
    label = "until full" if (ma or 0) > 0 else "remaining"
    if h:
        return f"{h}h {m:02d}m {label}"
    return f"{m}m {label}"


def bar(pct, width=30) -> str:
    if pct is None:
        return "[" + "?" * width + "]"
    filled = int(width * pct / 100)
    colour = GREEN if pct > 40 else (YELLOW if pct > 15 else RED)
    return f"{colour}[{'█' * filled}{'░' * (width - filled)}]{RESET} {pct:5.1f}%"


def fmt_watts(w) -> str:
    if w is None:
        return "N/A"
    return f"{w:.2f} W"


def fmt_temp(c) -> str:
    if c is None:
        return "N/A"
    colour = GREEN if c < 40 else (YELLOW if c < 50 else RED)
    return f"{colour}{c:.1f} °C{RESET}"


def fmt_health(cur, design) -> str:
    if not (cur and design):
        return "N/A"
    h = cur / design * 100
    colour = GREEN if h > 80 else (YELLOW if h > 60 else RED)
    return f"{colour}{h:.1f}%{RESET}  ({cur}/{design} mAh)"


# ── CSV logging ──────────────────────────────────────────────────────────────
LOG_FILE   = "battery_log.csv"
LOG_FIELDS = ["timestamp", "ma", "mv", "watts", "pct", "current_mah",
              "max_mah", "celsius", "is_charging", "is_plugged", "cycle_count"]

def init_log():
    exists = os.path.exists(LOG_FILE)
    fh = open(LOG_FILE, "a", newline="")
    writer = csv.DictWriter(fh, fieldnames=LOG_FIELDS)
    if not exists:
        writer.writeheader()
    return fh, writer


def write_log(writer, info, m):
    writer.writerow({
        "timestamp":   datetime.now().isoformat(timespec="seconds"),
        "ma":          m["ma"],
        "mv":          m["mv"],
        "watts":       round(m["watts"], 3) if m["watts"] else None,
        "pct":         round(m["pct"], 1)   if m["pct"]   else None,
        "current_mah": info.get("current_mah"),
        "max_mah":     info.get("max_mah"),
        "celsius":     m["celsius"],
        "is_charging": info.get("is_charging"),
        "is_plugged":  info.get("is_plugged"),
        "cycle_count": info.get("cycle_count"),
    })


# ── Rendering ────────────────────────────────────────────────────────────────
def render(info: dict, m: dict, elapsed: float, interval: float, logging: bool):
    now = datetime.now().strftime("%Y-%m-%d  %H:%M:%S")

    lines = [
        f"{BOLD}{CYAN}{'─' * 54}{RESET}",
        f"{BOLD}{CYAN}  ⚡  macOS Battery Monitor{RESET}   {DIM}{now}{RESET}",
        f"{BOLD}{CYAN}{'─' * 54}{RESET}",
        "",
        f"  {'Charge level':18s}  {bar(m['pct'])}",
        f"  {'Current rate':18s}  {fmt_rate(m['ma'], info.get('is_charging'), info.get('is_plugged'), info.get('is_full'))}",
        f"  {'Power draw':18s}  {fmt_watts(m['watts'])}",
        f"  {'Voltage':18s}  {m['mv']} mV" if m["mv"] else "",
        f"  {'Temperature':18s}  {fmt_temp(m['celsius'])}",
        f"  {'Battery health':18s}  {fmt_health(info.get('max_mah'), info.get('design_mah'))}",
        f"  {'Cycle count':18s}  {info.get('cycle_count', 'N/A')}",
        f"  {'ETA':18s}  {fmt_eta(m['eta_min'], m['ma'])}",
        "",
        f"  {DIM}Plugged in: {'Yes' if info.get('is_plugged') else 'No':4s}  "
        f"Charging: {'Yes' if info.get('is_charging') else 'No':4s}  "
        f"Full: {'Yes' if info.get('is_full') else 'No'}{RESET}",
        "",
        f"  {DIM}Refresh every {interval}s  |  "
        f"{'Logging → ' + LOG_FILE if logging else 'No logging'}  |  "
        f"Ctrl-C to quit{RESET}",
        f"{BOLD}{CYAN}{'─' * 54}{RESET}",
    ]

    print(CLEAR + "\n".join(l for l in lines if l is not None))


# ── Main ─────────────────────────────────────────────────────────────────────
def parse_args():
    p = argparse.ArgumentParser(
        description="Real-time battery charging speed monitor for macOS"
    )
    p.add_argument("-i", "--interval", type=float, default=1.0,
                   metavar="SEC", help="Refresh interval in seconds (default: 1)")
    p.add_argument("--log", action="store_true",
                   help=f"Append readings to {LOG_FILE}")
    return p.parse_args()


def main():
    args = parse_args()

    if sys.platform != "darwin":
        print("This tool only works on macOS.")
        sys.exit(1)

    log_fh = log_writer = None
    if args.log:
        log_fh, log_writer = init_log()

    start = time.time()
    try:
        while True:
            info = get_battery_info()
            m    = compute_metrics(info)
            render(info, m, time.time() - start, args.interval, args.log)

            if log_writer:
                write_log(log_writer, info, m)
                log_fh.flush()

            time.sleep(args.interval)

    except KeyboardInterrupt:
        print(f"\n{DIM}Stopped.{RESET}")
    finally:
        if log_fh:
            log_fh.close()
            print(f"Log saved to {LOG_FILE}")


if __name__ == "__main__":
    main()
