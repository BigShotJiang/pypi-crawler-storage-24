from setuptools import setup, find_packages

setup(
    name="lapatic-mpy",
    version="0.1.0",
    description="Automated pipeline for video creation and uploading. Needs secrets/deepgrams.txt for tts feature and secrets/client_secret.json (OAth2 set up with google cloud for uploading)",
    packages=find_packages("src"),
    package_dir={"": "src"},
)