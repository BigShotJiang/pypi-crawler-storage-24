# Development Setup

How to set up a development environment for contributing to ado-git-repo-insights.

---

## Prerequisites

| Requirement | Version |
|-------------|---------|
| Python | 3.10, 3.11, or 3.12 |
| Node.js | 16+ (for extension development) |
| Git | Any recent version |

---

## Quick Setup

```bash
# Clone the repository
git clone https://github.com/oddessentials/ado-git-repo-insights.git
cd ado-git-repo-insights

# Create and activate virtual environment
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate   # Windows

# Install Python dependencies (including dev tools)
pip install -e .[dev]

# Install Node.js dependencies (for extension development)
cd extension && pnpm install && cd ..
```

---

## Python Development

### Install Options

**Basic (for running the tool):**
```bash
pip install -e .
```

**Development (includes testing and linting tools):**
```bash
pip install -e .[dev]
```

**ML features (includes Prophet and OpenAI):**
```bash
pip install -e .[ml]
```

### Code Quality Tools

**Linting:**
```bash
ruff check .
```

**Auto-format:**
```bash
ruff format .
```

**Type checking:**
```bash
mypy src/
```

### Running Tests

```bash
# All tests
pytest

# With coverage
pytest --cov=src --cov-report=term-missing

# Specific test file
pytest tests/unit/test_cli_args.py

# Verbose output
pytest -v
```

---

## Extension Development

### Setup

```bash
cd extension
pnpm install
```

### Running Tests

```bash
pnpm test
```

### Building the VSIX

```bash
npx tfx-cli extension create --manifest-globs vss-extension.json
```

This creates `OddEssentials.ado-git-repo-insights-X.Y.Z.vsix`.

### Local Testing

Upload the VSIX to a test Azure DevOps organization:
1. Go to `https://dev.azure.com/{test-org}/_settings/extensions`
2. Click **Browse local extensions** → **Manage extensions**
3. Click **Upload extension** → Select the `.vsix` file

---

## Repo Hooks

Repo-owned hooks run automatically on `git commit` and `git push` through
Husky wrapper files under `.husky/`.
The authoritative implementation lives in:

- `scripts/run_repo_hook.py`
- `scripts/manage_generated_artifacts.py`

You do not need to run `pre-commit install` manually for normal repo usage.
`pre-commit` is still required because the repo hooks delegate Python lint/format
checks to it.

The commit/push workflow currently includes:

| Hook | Purpose |
|------|---------|
| `pre-commit` | Python formatting/lint checks, ACL health on Windows, VSS SDK drift sync, compiled artifact guard, managed UI/demo artifact sync when UI files are staged |
| `pre-push` | baseline integrity, `pre-commit --all-files`, CRLF guard, marketplace asset validation, and local PR preflight |

### Manual Run

```bash
python scripts/run_repo_hook.py pre-commit
python scripts/run_repo_hook.py pre-push

# Or via the extension package scripts
cd extension
pnpm run hooks:precommit
pnpm run hooks:prepush
```

### Skip Hooks (Not Recommended)

```bash
git commit --no-verify -m "message"
```

---

## Line Endings

This repo uses **LF line endings** for cross-platform compatibility.

**Recommended Git config:**
```bash
# Let .gitattributes be the source of truth
git config core.autocrlf false
```

If you see "CRLF will be replaced by LF" warnings, that's expected behavior.

---

## Project Structure

```
ado-git-repo-insights/
├── src/ado_git_repo_insights/    # Python package source
│   ├── cli.py                    # CLI entry point
│   ├── ado_client.py             # Azure DevOps API client
│   ├── pr_extractor.py           # Extraction logic
│   ├── repository.py             # SQLite operations
│   ├── csv_generator.py          # CSV generation
│   ├── aggregates.py             # Dashboard aggregates
│   └── ui_bundle/                # Dashboard UI (synced from extension)
├── extension/                     # Azure DevOps extension
│   ├── task/                      # Pipeline task
│   ├── ui/                        # Dashboard UI (source of truth)
│   └── hub/                       # Extension hub
├── tests/                         # Test suite
│   ├── unit/                      # Unit tests
│   ├── integration/               # Integration tests
│   └── fixtures/                  # Test data
├── scripts/                       # Build and utility scripts
├── agents/                        # Governance documents
└── docs/                          # Documentation
```

---

## See Also

- [Testing Guide](testing.md) — Test organization and patterns
- [UI Bundle Sync](ui-bundle-sync.md) — Dashboard UI synchronization
- [Contributing Guide](../../CONTRIBUTING.md) — Contribution workflow
