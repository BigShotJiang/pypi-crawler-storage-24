import sys
import platform

_messages = [
    "\nThe 'moreau' package cannot be installed directly from PyPI.",
    "Please visit https://docs.moreau.so for installation instructions.",
]

if platform.system() == "Windows":
    _messages.insert(
        1,
        "Moreau is not supported on Windows. Please use WSL (Windows Subsystem for Linux).",
    )

if sys.version_info < (3, 12):
    _messages.insert(
        1,
        f"Moreau requires Python 3.12 or later. You are running Python {sys.version_info.major}.{sys.version_info.minor}."
        " Please upgrade your Python installation.",
    )

raise ImportError("\n".join(_messages) + "\n")
