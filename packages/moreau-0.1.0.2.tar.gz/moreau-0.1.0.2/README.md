# moreau (PyPI standin)

This is a placeholder package. The `moreau` package cannot be installed directly from PyPI.

Please visit [docs.moreau.so](https://docs.moreau.so) for installation instructions.
