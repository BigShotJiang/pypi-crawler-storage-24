import iisi_app_core as core


def test_public_api_exports_expected_symbols() -> None:
    assert "autoload" in core.__all__
    assert "ModuleAutoloadError" in core.__all__
    assert "driving_port" in core.__all__
    assert "driven_port" in core.__all__
    assert "ContainerBuilder" in core.__all__
    assert "PortsAndAdaptersViolationError" in core.__all__
    assert "Principal" in core.__all__
    assert "DomainValidationError" in core.__all__
    assert "ForbiddenError" in core.__all__
    assert "build_lambda_handler" not in core.__all__
    assert "EventBridgeEventHandler" not in core.__all__
    assert "feature_enabled" not in core.__all__
