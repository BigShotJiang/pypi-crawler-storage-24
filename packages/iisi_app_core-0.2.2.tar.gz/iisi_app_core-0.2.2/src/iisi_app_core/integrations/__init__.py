"""Optional framework integrations for iisi-app-core."""

__all__: list[str] = []
