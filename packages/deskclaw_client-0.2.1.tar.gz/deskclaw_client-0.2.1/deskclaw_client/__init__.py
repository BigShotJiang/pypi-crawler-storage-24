"""DeskClaw Client — lightweight CLI for bot self-registration and test triggering."""

__version__ = "0.2.1"
