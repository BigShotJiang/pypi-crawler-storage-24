import os
from . import leangeo
import atexit
import gc
import signal
import sys
import time
import threading
import math
from typing import List, Dict, Any, Optional, Tuple
from contextlib import contextmanager
from datetime import date, datetime, timezone

# --- Cross-Platform Locking Support ---
try:
    import fcntl
    HAS_FCNTL = True
except ImportError:
    HAS_FCNTL = False

class CollectionLock:
    """File-based lock for a collection, providing both thread and process safety."""
    
    def __init__(self, collection_path: str):
        # Force absolute path to ensure all processes agree on the lock file location
        self.lock_path = os.path.abspath(os.path.join(collection_path, '.collection.lock'))
        self._thread_lock = threading.RLock()
        self._ensure_lock_file()
    
    def _ensure_lock_file(self):
        """Ensure the lock file exists."""
        try:
            os.makedirs(os.path.dirname(self.lock_path), exist_ok=True)
        except FileExistsError:
            pass
        try:
            # Open in append mode to ensure creation, but don't truncate
            with open(self.lock_path, 'a'):
                pass
        except OSError:
            pass
    
    @contextmanager
    def read_lock(self):
        """Acquire a shared read lock."""
        # Thread safety first
        with self._thread_lock:
            if HAS_FCNTL:
                # Process safety via fcntl
                # Use 'a+' (read/append) to ensure we have write access to metadata 
                # which helps stability of locks on some FS, and ensure file isn't truncated.
                f = open(self.lock_path, 'a+')
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_SH)
                    yield
                finally:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                    f.close()
            else:
                # Windows fallback (No process safety, only thread safety)
                yield
    
    @contextmanager
    def write_lock(self):
        """Acquire an exclusive write lock."""
        with self._thread_lock:
            if HAS_FCNTL:
                f = open(self.lock_path, 'a+')
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                    yield
                finally:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                    f.close()
            else:
                yield

class NoOpLock:
    """No-op lock that does nothing - for single-threaded use."""
    @contextmanager
    def read_lock(self): yield
    @contextmanager
    def write_lock(self): yield

class VersionTracker:
    """Track collection version to detect changes from other processes."""
    
    def __init__(self, collection_path: str):
        self.version_path = os.path.abspath(os.path.join(collection_path, '.version'))
        self._ensure_version_file()
    
    def _ensure_version_file(self):
        try:
            os.makedirs(os.path.dirname(self.version_path), exist_ok=True)
        except FileExistsError:
            pass
        try:
            # Initialize if missing
            if not os.path.exists(self.version_path):
                self._write_version(0)
        except OSError:
            pass
    
    def _write_version(self, version: int):
        # Atomic write pattern
        tmp_path = self.version_path + ".tmp"
        try:
            with open(tmp_path, 'w') as f:
                f.write(str(version))
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, self.version_path)
        except OSError:
            # Handle potential race where another process wrote/moved/deleted
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except OSError:
                pass
    
    def get_version(self) -> int:
        try:
            with open(self.version_path, 'r') as f:
                content = f.read().strip()
                return int(content) if content else 0
        except (FileNotFoundError, ValueError):
            return 0
    
    def increment_version(self):
        # This must be called INSIDE a write_lock
        current = self.get_version()
        self._write_version(current + 1)

class NoOpVersionTracker:
    def get_version(self) -> int: return 0
    def increment_version(self): pass

# Helper for PyGeoDB type since we can't type hint the extension module easily
_PyGeoDB = Any

class LeanGeoEngine:
    """
    A high-performance coordinate database with spatial indexing and metadata filtering.
    
    Features:
    - Automatic persistence with memory-mapped storage
    - O(1) complexity for numeric filtering via bit-sliced index
    - MongoDB-style query operators
    - Spatial queries: polygon, bounding box, radius
    - Delete by metadata filter
    - Skip indexing for specific fields
    - Thread and process safety
    """
    
    def __init__(self, path: Optional[str] = None, capacity: int = 10000, thread_safe: bool = False):
        """
        Initialize the database.
        
        Args:
            path: Optional folder path for persistent storage.
            capacity: Initial capacity hint for the database.
            thread_safe: Enable thread-safety for multiprocessing (requires path).
        """
        self._base_path = os.path.abspath(path) if path else None
        self._capacity = capacity
        self._thread_safe = thread_safe and path is not None
        self._is_closed = False
        
        self.collections: Dict[str, _PyGeoDB] = {}
        self.collection_locks: Dict[str, CollectionLock] = {}
        self.version_trackers: Dict[str, VersionTracker] = {}
        self.local_versions: Dict[str, int] = {}
        
        # Global lock for managing collections dict
        self._collections_lock = threading.RLock() if thread_safe else None
        
        # Create directory if path is provided and doesn't exist
        if self._base_path:
            os.makedirs(self._base_path, exist_ok=True)
            self._load_existing_collections()
        
        if thread_safe and not path:
            raise ValueError("thread_safe=True requires a file path")

        # Maintenance settings
        self.start_time = time.time()
        self.last_access_time = time.time()
        self.maintenance_interval = 86400  # 24 hours
        self.idle_threshold = 3600         # 1 hour
        self.stop_maintenance = False
        
        self.m_thread = threading.Thread(target=self._maintenance_loop, daemon=True)
        self.m_thread.start()

        # Signal handling
        atexit.register(self.close)
        signal.signal(signal.SIGTERM, self._handle_signal)
        signal.signal(signal.SIGINT, self._handle_signal)

    def _handle_signal(self, signum, frame):
        self.close()
        sys.exit(0)
    
    def _get_col_path(self, name: str) -> str:
        # For leangeo, we define the path as the file prefix without extension, 
        # as leangeo adds extensions (.coords.mmap, etc) internally.
        # But to allow locking/versioning folders, we treat collections as subdirectories or 
        # prefixed files in base_path.
        # Strategy: use `{base_path}/{name}` as the prefix passed to Rust
        if not self._base_path:
            return None
        return os.path.join(self._base_path, name)
    
    # For locking/versioning, we need a directory or a stable base path.
    # Since leangeo files are {name}.coords.mmap, we store locks as {name}.lock directory
    def _get_lock_path_base(self, name: str) -> str:
        if not self._base_path: return ""
        # Create a directory specifically for locks/versions to keep things clean
        lock_dir = os.path.join(self._base_path, f".{name}_meta")
        return lock_dir

    def _get_collection_lock(self, name: str):
        if not self._thread_safe:
            return NoOpLock()
        
        with self._collections_lock:
            if name not in self.collection_locks:
                path = self._get_lock_path_base(name)
                self.collection_locks[name] = CollectionLock(path)
            return self.collection_locks[name]
    
    def _get_version_tracker(self, name: str):
        if not self._thread_safe:
            return NoOpVersionTracker()
        
        with self._collections_lock:
            if name not in self.version_trackers:
                path = self._get_lock_path_base(name)
                self.version_trackers[name] = VersionTracker(path)
            return self.version_trackers[name]

    def _load_existing_collections(self):
        """Scan directory for existing DB files."""
        if not self._base_path: return
        # Simple scan: look for .coords.mmap files
        try:
            for f in os.listdir(self._base_path):
                if f.endswith(".coords.mmap"):
                    col_name = f.replace(".coords.mmap", "")
                    # Pre-register presence (lazy load)
                    if col_name not in self.collections:
                        # Just ensure lock dir exists
                        if self._thread_safe:
                            os.makedirs(self._get_lock_path_base(col_name), exist_ok=True)
        except OSError:
            pass

    def _needs_reload(self, collection: str) -> bool:
        if not self._thread_safe:
            return False
        
        if collection not in self.local_versions:
            return True
        
        tracker = self._get_version_tracker(collection)
        disk_version = tracker.get_version()
        return disk_version > self.local_versions.get(collection, -1)
    
    def _reload_collection(self, collection: str):
        """Reload collection from disk."""
        if not self._thread_safe:
            return

        def do_reload():
            if collection in self.collections:
                del self.collections[collection]
                gc.collect()
            
            path = self._get_col_path(collection)
            self.collections[collection] = leangeo.PyGeoDB(path, self._capacity)
            
            tracker = self._get_version_tracker(collection)
            self.local_versions[collection] = tracker.get_version()

        if self._collections_lock:
            with self._collections_lock:
                do_reload()
        else:
            do_reload()

    def _ensure_collection(self, name: str) -> _PyGeoDB:
        self.last_access_time = time.time()
        
        def init_col():
            if name not in self.collections:
                path = self._get_col_path(name)
                
                if self._thread_safe and self._base_path:
                    # Create meta dir for locks
                    os.makedirs(self._get_lock_path_base(name), exist_ok=True)
                
                self.collections[name] = leangeo.PyGeoDB(path, self._capacity)
                
                if self._thread_safe:
                    tracker = self._get_version_tracker(name)
                    self.local_versions[name] = tracker.get_version()

        if self._thread_safe and self._collections_lock:
            with self._collections_lock:
                init_col()
        else:
            init_col()
        
        return self.collections[name]

    def _sanitize_metadata(self, meta: Any) -> Any:
        """Recursively cleans metadata for JSON compatibility.
        
        - float NaN/Inf → None
        - datetime/date objects → UTC float timestamp
        """
        if isinstance(meta, datetime):
            if meta.tzinfo is None:
                return meta.replace(tzinfo=timezone.utc).timestamp()
            return meta.timestamp()
        elif isinstance(meta, date):
            return datetime(meta.year, meta.month, meta.day, tzinfo=timezone.utc).timestamp()
        elif isinstance(meta, float):
            if math.isnan(meta) or math.isinf(meta):
                return None
        elif isinstance(meta, dict):
            return {k: self._sanitize_metadata(v) for k, v in meta.items()}
        elif isinstance(meta, list):
            return [self._sanitize_metadata(v) for v in meta]
        return meta

    def insert(
        self,
        latitude: float,
        longitude: float,
        metadata: Dict[str, Any],
        skip_index: Optional[List[str]] = None,
        collection: str = "default"
    ) -> int:
        metadata = self._sanitize_metadata(metadata)
        col_lock = self._get_collection_lock(collection)
        
        # WRITE LOCK
        with col_lock.write_lock():
            if self._thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            result = db.insert(latitude, longitude, metadata, skip_index)
            
            if self._thread_safe:
                # Flush logic if needed (leangeo uses mmap, so OS handles flush, but we bump version)
                tracker = self._get_version_tracker(collection)
                tracker.increment_version()
                self.local_versions[collection] = tracker.get_version()
            
            return result
    
    def insert_batch(
        self,
        points: List[Tuple[float, float]],
        metadata: List[Dict[str, Any]],
        skip_index: Optional[List[str]] = None,
        collection: str = "default"
    ) -> List[int]:
        if len(points) != len(metadata):
            raise ValueError("points and metadata lists must have the same length")

        # combine coords with sanitized metadata
        combined: List[Tuple[float, float, Dict[str, Any]]] = []
        for (lat, lon), meta in zip(points, metadata):
            combined.append((lat, lon, self._sanitize_metadata(meta)))

        col_lock = self._get_collection_lock(collection)
        
        with col_lock.write_lock():
            if self._thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            result = db.insert_batch(combined, skip_index)
            
            if self._thread_safe:
                tracker = self._get_version_tracker(collection)
                tracker.increment_version()
                self.local_versions[collection] = tracker.get_version()
            
            return result
    
    def query_bbox(
        self,
        min_lat: float,
        min_lon: float,
        max_lat: float,
        max_lon: float,
        filter: Optional[Dict[str, Any]] = None,
        collection: str = "default"
    ) -> List[Dict[str, Any]]:
        if filter is not None:
            filter = self._sanitize_metadata(filter)
        col_lock = self._get_collection_lock(collection)
        
        # Compute outside the lock as an optimisation (avoids always taking write_lock).
        # The check is REPEATED inside the lock to close the TOCTOU window: another
        # thread may have already initialised the collection between the outside check
        # and lock acquisition, making a reload no longer necessary.
        requires_reload = self._thread_safe and self._needs_reload(collection)
        lock_manager = col_lock.write_lock() if requires_reload else col_lock.read_lock()

        with lock_manager:
            if self._thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            return db.query_bbox(min_lat, min_lon, max_lat, max_lon, filter)

    def query_polygon(
        self,
        coordinates: List[Tuple[float, float]],
        filter: Optional[Dict[str, Any]] = None,
        collection: str = "default"
    ) -> List[Dict[str, Any]]:
        if filter is not None:
            filter = self._sanitize_metadata(filter)
        col_lock = self._get_collection_lock(collection)
        
        requires_reload = self._thread_safe and self._needs_reload(collection)
        lock_manager = col_lock.write_lock() if requires_reload else col_lock.read_lock()

        with lock_manager:
            if self._thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            return db.query_polygon(coordinates, filter)

    def query_radius(
        self,
        center_lat: float,
        center_lon: float,
        radius_meters: float,
        filter: Optional[Dict[str, Any]] = None,
        collection: str = "default"
    ) -> List[Dict[str, Any]]:
        if filter is not None:
            filter = self._sanitize_metadata(filter)
        col_lock = self._get_collection_lock(collection)
        
        requires_reload = self._thread_safe and self._needs_reload(collection)
        lock_manager = col_lock.write_lock() if requires_reload else col_lock.read_lock()

        with lock_manager:
            if self._thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            return db.query_radius(center_lat, center_lon, radius_meters, filter)

    def query(
        self, 
        filter: Dict[str, Any], 
        limit: Optional[int] = None, 
        collection: str = "default"
    ) -> List[Dict[str, Any]]:
        filter = self._sanitize_metadata(filter)
        col_lock = self._get_collection_lock(collection)
        
        requires_reload = self._thread_safe and self._needs_reload(collection)
        lock_manager = col_lock.write_lock() if requires_reload else col_lock.read_lock()

        with lock_manager:
            if self._thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            return db.query(filter, limit)

    def exists(self, filter: Dict[str, Any], collection: str = "default") -> bool:
        filter = self._sanitize_metadata(filter)
        col_lock = self._get_collection_lock(collection)
        
        requires_reload = self._thread_safe and self._needs_reload(collection)
        lock_manager = col_lock.write_lock() if requires_reload else col_lock.read_lock()

        with lock_manager:
            if self._thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            return db.exists(filter)

    def delete_by_metadata(self, filter: Dict[str, Any], collection: str = "default") -> int:
        filter = self._sanitize_metadata(filter)
        col_lock = self._get_collection_lock(collection)
        
        with col_lock.write_lock():
            if self._thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            result = db.delete_by_metadata(filter)
            
            if self._thread_safe:
                tracker = self._get_version_tracker(collection)
                tracker.increment_version()
                self.local_versions[collection] = tracker.get_version()
            
            return result

    def count(self, collection: str = "default") -> int:
        col_lock = self._get_collection_lock(collection)
        
        requires_reload = self._thread_safe and self._needs_reload(collection)
        lock_manager = col_lock.write_lock() if requires_reload else col_lock.read_lock()

        with lock_manager:
            if self._thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            return db.count()

    def persist_all(self):
        """
        Trigger flush for all collections.
        Note: Leangeo uses mmap so OS handles flush, but we can iterate to ensure objects are alive.
        """
        # In this mmap architecture, 'persist' is implicit. 
        # But we can use this to perhaps clean up unused handles if needed in future.
        pass

    def _maintenance_loop(self):
        # Leangeo mmap relies on OS paging, so explicit maintenance is less critical 
        # than for Wal-based DBs, but kept for consistency.
        while not self.stop_maintenance:
            time.sleep(1)
            # Logic here can be expanded if explicit sync() calls are exposed by Rust
    
    def close(self):
        """Gracefully close."""
        if self._is_closed:
            return
        
        self.stop_maintenance = True
        if self.m_thread.is_alive() and self.m_thread is not threading.current_thread():
            try:
                self.m_thread.join(timeout=2.0)
            except RuntimeError:
                pass
        
        # Explicitly release Rust objects to trigger Drop / mmap flush
        self.collections.clear()
        self._is_closed = True

    def __len__(self) -> int:
        return self.count("default")