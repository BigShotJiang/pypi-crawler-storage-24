from pydantic import BaseModel
from typing import List


class NewsURL(BaseModel):
    sisyphus: str | None = None
    p11: str | None = None
    p10: str | None = None
    bugs: str | None = None


class BugsElementModel(BaseModel):
    id: int
    component: str
    priority: str
    status: str | None = None
    summary: str


class BugsModel(BaseModel):
    url: str
    quickly_resolved: List[BugsElementModel] | None = None
    new: List[BugsElementModel] | None = None
    old: List[BugsElementModel] | None = None
    resolved: List[BugsElementModel] | None = None
    reopened: List[BugsElementModel] | None = None
    random: List[BugsElementModel] | None = None


class RemovedPackageElementModel(BaseModel):
    name: str
    version: str


class PackageElementModel(BaseModel):
    name: str
    description: str
    maintainer_name: str
    maintainer_nick: str


class PackagesModel(BaseModel):
    url: str
    total: int
    added: List[PackageElementModel] | None = None
    removed: List[RemovedPackageElementModel] | None = None
    updated: List[PackageElementModel] | None = None


class FTBFSModel(BaseModel):
    name: str
    version: str
    ftbfs_weeks: int
    maintainers: List[str]


class WatchByMaintainerModel(BaseModel):
    pkg_name: str
    old_version: str
    new_version: str
    url: str


class WatchTotalModel(BaseModel):
    maintainer: str
    pkg_name: str
    old_version: str
    new_version: str
    url: str
