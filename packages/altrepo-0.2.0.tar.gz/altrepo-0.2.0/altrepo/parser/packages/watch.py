from .. import models


def watch_parser(text: str):
    return [
        models.WatchByMaintainerModel(
            pkg_name=parts[0],
            old_version=parts[1],
            new_version=parts[2],
            url=parts[3],
        )
        for parts in (line.split("\t") for line in text.strip().splitlines())
        if len(parts) == 4
    ]


def watch_total_parser(text: str):
    return [
        models.WatchTotalModel(
            maintainer=parts[0],
            pkg_name=parts[1],
            old_version=parts[2],
            new_version=parts[3],
            url=parts[4],
        )
        for parts in (line.split("\t") for line in text.strip().splitlines())
        if len(parts) == 5
    ]
