from .. import models

def ftbfs_parser(text: str):
    packages = []
    for line in text.strip().splitlines():
        parts = line.split('\t')
        if len(parts) != 4:
            continue 
        name, version, weeks, maintainers = parts
        packages.append(models.FTBFSModel(
            name = name,
            version = version,
            ftbfs_weeks = int(weeks),
            maintainers = maintainers.split(','),
        ))
    return packages
