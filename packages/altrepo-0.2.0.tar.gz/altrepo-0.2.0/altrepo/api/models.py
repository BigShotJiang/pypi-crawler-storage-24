from pydantic import BaseModel, Field
from typing import List, Dict, Any


class APIVersion(BaseModel):
    name: str
    version: str
    description: str


class SubTaskArchitectureModel(BaseModel):
    stage_status: str
    arch: str


class SubTasksElementModel(BaseModel):
    subtask_id: int
    subtask_type: str
    subtask_srpm: str
    subtask_srpm_name: str
    subtask_srpm_evr: str
    subtask_dir: str
    subtask_tag_id: str
    subtask_tag_name: str
    subtask_tag_author: str
    subtask_package: str
    subtask_pkg_from: str
    subtask_changed: str
    type: str
    archs: List[SubTaskArchitectureModel]


class TaskApprovalElementModel(BaseModel):
    type: str
    nickname: str
    message: str


class TasksListElementModel(BaseModel):
    task_id: int
    task_repo: str
    task_state: str
    task_owner: str
    task_try: int
    task_iter: int
    task_testonly: int
    task_changed: str
    task_message: str
    task_stage: str
    dependencies: List[int]
    subtasks: List[SubTasksElementModel]
    approval: list[TaskApprovalElementModel]


class SubTaskInfoElementModel(BaseModel):
    subtask_id: int
    subtask_type: str
    subtask_srpm: str
    subtask_srpm_name: str
    subtask_srpm_evr: str
    subtask_dir: str
    subtask_tag_id: str
    subtask_tag_name: str
    subtask_tag_author: str
    subtask_package: str
    subtask_pkg_from: str
    subtask_changed: str
    type: str
    src_pkg_name: str
    src_pkg_hash: str
    archs: List[SubTaskArchitectureModel]
    approval: list[TaskApprovalElementModel]


class TaskIterationsElementModel(BaseModel):
    task_try: int
    task_iter: int


class TaskProgressTaskInfoModel(BaseModel):
    task_id: int
    task_repo: str
    task_state: str
    task_owner: str
    task_try: int
    task_iter: int
    task_testonly: int
    task_changed: str
    task_message: str
    task_stage: str
    dependencies: List[int]
    subtasks: List[SubTaskInfoElementModel]
    iterations: list[TaskIterationsElementModel]


class TasksListModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    tasks: list[TasksListElementModel]


class PackageSetActivePackageSetsModel(BaseModel):
    length: int
    packagesets: List[str]


class RepositoryStatisticsPackageCountsModel(BaseModel):
    arch: str
    component: str
    count: int
    size: int
    size_hr: str
    uuid: str


class RepositoryStatisticsBranchesModel(BaseModel):
    branch: str
    date_update: str
    packages_count: List[RepositoryStatisticsPackageCountsModel]


class RepositoryStatisticsModel(BaseModel):
    length: int
    branches: List[RepositoryStatisticsBranchesModel]


class AllMaintainersElementModel(BaseModel):
    packager_name: str
    packager_nickname: str
    count_source_pkg: int


class MaintainerInfoModel(BaseModel):
    request_args: Dict[str, Any]
    information: AllMaintainersElementModel


class AllMaintainersModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    maintainers: List[AllMaintainersElementModel]


class SiteWatchByMaintainerElementModel(BaseModel):
    pkg_name: str
    old_version: str
    new_version: str
    repology_name: str
    url: str
    date_update: str


class SiteWatchByMaintainerModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[SiteWatchByMaintainerElementModel]


class BugzillaInfoElementModel(BaseModel):
    id: str
    status: str
    resolution: str
    severity: str
    product: str
    version: str | None
    platform: str | None
    component: str
    source_package_name: str
    binary_package_name: str
    reporter: str
    summary: str
    last_changed: str


class BugzillaInfoModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    bugs: List[BugzillaInfoElementModel]


class FilePackagesByFileElementModel(BaseModel):
    hash: str
    name: str
    version: str
    release: str
    arch: str


class FilePackagesByFileModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[FilePackagesByFileElementModel]


class PackageInfoChangelogElementModel(BaseModel):
    date: str | None
    name: str | None
    evr: str | None
    message: str | None


class PackageInfoDependenciesModel(BaseModel):
    require: List[str] | None
    provide: List[str] | None
    conflict: List[str] | None
    obsolete: List[str] | None


class PackageInfoPackageModel(BaseModel):
    name: str
    version: str
    release: str
    sha1: str
    packager: str
    packager_email: str
    arch: str
    epoch: int
    disttag: str
    sourcepackage: int
    filename: str
    sourcerpm: str
    serial: int | None
    buildtime: int | None
    buildhost: str | None
    size: int | None
    archivesize: int | None
    filesize: int | None
    rpmversion: str | None
    cookie: str | None
    license: str | None
    group: str | None
    url: str | None
    summary: str | None
    description: str | None
    distribution: str | None
    vendor: str | None
    os: str | None
    gif: str | None
    xpm: str | None
    icon: str | None
    prein: str | None
    postin: str | None
    preun: str | None
    postun: str | None
    preinprog: List[str] | None
    postinprog: List[str] | None
    preunprog: List[str] | None
    postunprog: List[str] | None
    buildarchs: List[str] | None
    verifyscript: str | None
    verifyscriptprog: List[str] | None
    prefixes: List[str] | None
    instprefixes: List[str] | None
    optflags: str | None
    disturl: str | None
    payloadformat: str | None
    payloadcompressor: str | None
    payloadflags: str | None
    platform: str | None
    changelog: List[PackageInfoChangelogElementModel] | PackageInfoChangelogElementModel
    files: List[str] | None
    depends: List[PackageInfoDependenciesModel] | PackageInfoDependenciesModel


class PackageInfoModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[PackageInfoPackageModel]


class PackageByFileNameElementModel(BaseModel):
    name: str
    version: str
    release: str
    disttag: str
    sha1: str
    branch: str
    arch: str
    files: List[str]


class PackagesByFileNamesJsonModel(BaseModel):
    files: List[str]
    branch: str
    arch: str | None = None


class PackageByFileNameModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[PackageByFileNameElementModel]
    not_found: List[str]


class FilesElementModel(BaseModel):
    file_name: str
    file_hashname: str
    file_class: str
    symlink: str
    file_mode: str


class FilesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    files: List[FilesElementModel]


class AclGroupsElementModel(BaseModel):
    group: str
    date: str
    maintainers: List[str]


class AclGroupsModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    groups: List[AclGroupsElementModel]


class SitePackageInfoArchsModel(BaseModel):
    name: str
    archs: list[str]
    pkghash: list[str]


class SitePackageTasksElementModel(BaseModel):
    type: str
    id: int
    date: str


class SitePackageInfoChangelogElementModel(BaseModel):
    date: str
    name: str
    nick: str
    evr: str
    message: str


class SitePackageNewVersionModel(BaseModel):
    task_id: int
    date: str
    pkghash: str
    version: str
    release: str


class SitePackageBeehiveElementModel(BaseModel):
    arch: str
    status: str
    updated: str
    build_time: float
    ftbfs_since: str
    url: str


class SitePackageDependenciesElementModel(BaseModel):
    name: str
    version: str
    type: str
    flag: int
    flag_decoded: List[str]


class SitePackageLicenseTokensElementModel(BaseModel):
    token: str
    license: str


class SitePackageInfoModel(BaseModel):
    pkghash: str
    request_args: Dict[str, Any]
    name: str
    version: str
    release: str
    arch: str
    buildtime: int
    task: int
    task_date: str
    gear: str
    license: str
    category: str
    url: str
    vcs: str
    summary: str
    description: str
    packager: str
    packager_nickname: str
    acl: List[str]
    maintainers: List[str]
    package_archs: List[SitePackageInfoArchsModel]
    tasks: List[SitePackageTasksElementModel]
    changelog: List[SitePackageInfoChangelogElementModel]
    new_version: List[SitePackageNewVersionModel]
    beehive: List[SitePackageBeehiveElementModel]
    dependencies: List[SitePackageDependenciesElementModel]
    license_tokens: List[SitePackageLicenseTokensElementModel]


class SitePackagesetPackageHashModel(BaseModel):
    request_args: Dict[str, Any]
    pkghash: str
    version: str
    release: str


class FindSourcePackageInBranch(BaseModel):
    request_args: Dict[str, Any]
    source_package: str


class AclByPackagesElementModel(BaseModel):
    name: str
    updated: str
    members: List[str]


class AclByPackagesModel(BaseModel):
    branch: str
    packages: List[AclByPackagesElementModel]


class AclMaintainerGroupsElementModel(BaseModel):
    name: str
    groups: List[str]


class AclMaintainerGroupsModel(BaseModel):
    nickname: str
    branches: List[AclMaintainerGroupsElementModel]


class AuthResponseModel(BaseModel):
    access_token: str
    refresh_token: str


class AuthLogoutResponseModel(BaseModel):
    message: str


class BackportHelperBinaryElementModel(BaseModel):
    srpm: str
    name: str
    epoch: int
    version: str
    release: str
    arch: str


class BackportHelperBinaryDepthElementModel(BaseModel):
    depth: int
    packages: List[BackportHelperBinaryElementModel]


class BackportHelperModel(BaseModel):
    request_args: Dict[str, Any]
    count: int
    maxdepth: int
    dependencies: List[BackportHelperBinaryDepthElementModel]


class DependenciesPackageDependenciesElementModel(BaseModel):
    name: str
    version: str
    type: str
    flag: int
    flag_decoded: List[str]


class DependenciesPackageDependenciesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    dependencies: List[DependenciesPackageDependenciesElementModel]


class DependenciesPackageInfoModel(BaseModel):
    name: str
    epoch: int
    version: str
    release: str
    buildtime: int


class DependenciesPackageInfoElementModel(BaseModel):
    name: str
    version: str
    release: str
    summary: str
    pkghash: str


class DependenciesPackageBuildDependenciesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    package_info: DependenciesPackageInfoModel | None
    dependencies: List[DependenciesPackageDependenciesElementModel]
    provided_by_src: List[DependenciesPackageInfoElementModel]


class FastDependencySearchElementModel(BaseModel):
    dp_name: str


class FastDependencySearchModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    dependencies: List[FastDependencySearchElementModel]


class DependenciesAllPackagasetsElementModel(BaseModel):
    branch: str
    count: int


class DependenciesPackagesElementModel(BaseModel):
    hash: str
    name: str
    version: str
    release: str
    arch: str
    sourcepackage: int
    summary: str
    buildtime: int
    category: str
    maintainer: str
    dp_types: List[str]


class DependenciesPackagesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[DependenciesPackagesElementModel]
    branches: List[DependenciesAllPackagasetsElementModel]


class PackageDependsElementModel(BaseModel):
    pkghash: str
    name: str
    arch: str
    dp_name: str
    dp_version: str
    dp_flag: int
    dp_flag_decoded: List[str]


class PackageDependsModel(BaseModel):
    requires: PackageDependsElementModel | None
    provides: PackageDependsElementModel | None


class PackageBuildDependencyElementModel(BaseModel):
    pkghash: str
    name: str
    branch: str
    buildtime: str
    acl: List[str]
    depends: List[PackageDependsModel]


class PackageBuildDependencyModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    dependencies: List[PackageBuildDependencyElementModel]


class AdvisoryErrataReferenceModel(BaseModel):
    type: str
    link: str


class AdvisoryErrataPackageVersionRangeModel(BaseModel):
    begin: str
    begin_exclude: bool
    end: str
    end_exclude: bool


class AdvisoryErrataJsonModel(BaseModel):
    type: str
    action: str
    is_public: bool
    reason: str
    description: str
    vuln_id: str
    vuln_cpe: str
    branches: List[str]
    pkg_name: str
    pkg_evr: str
    pkg_versions: List[AdvisoryErrataPackageVersionRangeModel]
    references: List[AdvisoryErrataReferenceModel]
    extra: Dict[str, Any]


class AdvisoryErrataElementModel(BaseModel):
    model_config = {"populate_by_name": True}
    id: str
    type: str
    created: str
    updated: str
    pkgset_name: str
    task_id: int
    subtask_id: int
    task_state: str
    pkg_hash: str
    pkg_name: str
    pkg_version: str
    pkg_release: str
    references: List[AdvisoryErrataReferenceModel]
    json_: AdvisoryErrataJsonModel | None = Field(None, alias="json")


class AdvisoryErrataModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    erratas: List[AdvisoryErrataElementModel]


class ErrataBranchesModel(BaseModel):
    length: int
    branches: List[str]


class ErrataJsonPostListModel(BaseModel):
    errata_ids: List[str]


class ErrataBugModel(BaseModel):
    id: int
    summary: str
    is_valid: bool


class ErrataVulnerabilityModel(BaseModel):
    id: str
    hash: str
    type: str
    summary: str
    score: float
    severity: str
    url: str
    modified_date: str
    published_date: str
    body: str
    is_valid: bool
    parsed: Dict[str, Any] | None


class ErrataPackageUpdateModel(BaseModel):
    id: str
    type: str
    created: str
    updated: str
    pkgset_name: str
    task_id: int
    subtask_id: int
    task_state: str
    pkg_hash: str
    pkg_name: str
    pkg_version: str
    pkg_release: str
    bugs: List[ErrataBugModel]
    vulns: List[ErrataVulnerabilityModel]


class ErrataBranchUpdateModel(BaseModel):
    id: str
    type: str
    pkgset_name: str
    pkgset_date: str
    packages_updates: List[ErrataPackageUpdateModel]


class ErrataBranchesUpdatesModel(BaseModel):
    branches_updates: List[ErrataBranchUpdateModel]


class ErrataPackagesUpdatesModel(BaseModel):
    packages_updates: List[ErrataPackageUpdateModel]


class OvalBranchesModel(BaseModel):
    length: int
    branches: List[str]


class VulnerabilitiesElementModel(BaseModel):
    id: str
    type: str


class PackagesElementModel(BaseModel):
    pkghash: str
    pkg_name: str
    pkg_version: str
    pkg_release: str


class ErrataLastChangedElementModel(BaseModel):
    model_config = {"populate_by_name": True}
    is_discarded: bool
    errata_id: str
    eh_type: str
    task_id: int
    changed: str
    branch: str
    json_: Dict[str, Any] = Field(default_factory=dict, alias="json")
    packages: List[PackagesElementModel]
    vulnerabilities: List[VulnerabilitiesElementModel]


class ErrataLastChangedModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    erratas: List[ErrataLastChangedElementModel]


class ImageErrataElementModel(BaseModel):
    img_hash: str
    img_version: str
    img_release: str
    pkg_name: str
    pkg_arch: str
    pkg_hash: str
    pkg_version: str
    pkg_release: str
    summary: str
    errata_id: str
    eh_type: str
    task_id: int
    changed: str
    branch: str
    is_discarded: bool
    vulnerabilities: List[VulnerabilitiesElementModel]


class ImageErrataModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    erratas: List[ImageErrataElementModel]


class ErrataIdsListModel(BaseModel):
    errata_ids: List[str]


class ErrataReferenceModel(BaseModel):
    id: str
    type: str


class ErrataModel(BaseModel):
    id: str
    type: str
    created: str
    updated: str
    pkgset_name: str
    task_id: int
    subtask_id: int
    task_state: str
    pkg_hash: str
    pkg_name: str
    pkg_version: str
    pkg_release: str
    references: List[ErrataReferenceModel]


class ErratasModel(BaseModel):
    erratas: List[ErrataModel]


class ExportBeehiveFTBFSElementModel(BaseModel):
    branch: str
    hash: str
    name: str
    epoch: int
    version: str
    release: str
    arch: str
    updated: str
    ftbfs_since: str
    url: str


class ExportBeehiveFTBFSListModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    ftbfs: List[ExportBeehiveFTBFSElementModel]


class PackagesetPackagesExportElementModel(BaseModel):
    name: str
    epoch: int
    version: str
    release: str
    arch: str
    disttag: str
    buildtime: int
    source: str


class PackagesetPackagesExportModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[PackagesetPackagesExportElementModel]


class BranchTreeTaskModel(BaseModel):
    id: int
    prev: int
    branch: str
    date: str


class BranchTreeBranchCommitModel(BaseModel):
    name: str
    date: str
    task: int


class BranchTreeBranchPointModel(BaseModel):
    branch: str
    task: BranchTreeTaskModel | None
    from_task: BranchTreeTaskModel | None


class BranchTreeModel(BaseModel):
    branches: List[str]
    tasks: List[BranchTreeTaskModel]
    branch_commits: List[BranchTreeBranchCommitModel]
    branch_points: List[BranchTreeBranchPointModel]


class RepologyExportBranchBinaryPackageElementModel(BaseModel):
    name: str
    epoch: int
    version: str
    release: str
    summary: str
    archs: List[str]


class RepologyExportBranchSourcePackageElementModel(BaseModel):
    name: str
    epoch: int
    version: str
    release: str
    url: str
    license: str
    category: str
    summary: str
    packager: str
    homepage: str
    recipe: str
    recipe_raw: str
    bugzilla: str
    CPE: List[str]
    binaries: List[RepologyExportBranchBinaryPackageElementModel]


class RepologyExportBranchStatElementModel(BaseModel):
    arch: str
    count: int


class RepologyExportModel(BaseModel):
    branch: str
    date: str
    stats: List[RepologyExportBranchStatElementModel]
    packages: List[RepologyExportBranchSourcePackageElementModel]


class SitemapPackagesElementModel(BaseModel):
    pkghash: str
    name: str
    buildtime: int


class SitemapPackagesExportModel(BaseModel):
    branch: str
    packages: List[SitemapPackagesElementModel]


class FastFileSearchElementModel(BaseModel):
    file_name: str


class FastFileSearchModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    files: List[FastFileSearchElementModel]


class ActiveImagesElementModel(BaseModel):
    edition: str
    tags: List[str]


class ActiveImagesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    images: List[ActiveImagesElementModel]


class FindImagesByPackageElementModel(BaseModel):
    pkghash: str
    name: str
    branch: str
    version: str
    release: str
    arch: str
    edition: str
    tag: str
    file: str
    date: str


class FindImagesByPackageModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    images: List[FindImagesByPackageElementModel]


class SiteImageCategoryElementModel(BaseModel):
    category: str
    count: int


class SiteImageCategoriesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    categories: List[SiteImageCategoryElementModel]


class ImageInfoComponentModel(BaseModel):
    name: str
    size: str
    packages: int
    uuid: str
    ruuid: str
    kv: Dict[str, Any]


class ImageInfoElementModel(BaseModel):
    date: str
    uuid: str
    tag: str
    branch: str
    edition: str
    flavor: str
    platform: str
    release: str
    version_major: int
    version_minor: int
    version_sub: int
    arch: str
    variant: str
    type: str
    file: str
    url: List[str]
    md5sum: str
    gost12sum: str
    sha256sum: str
    components: List[ImageInfoComponentModel]


class ImageInfoModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    images: List[ImageInfoElementModel]


class ImagePackagesElementModel(BaseModel):
    hash: str
    name: str
    version: str
    release: str
    arch: str
    summary: str
    buildtime: int
    changelog_text: str


class ImagePackagesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    subcategories: List[str]
    packages: List[ImagePackagesElementModel]


class ImagePackageSetModel(BaseModel):
    length: int
    branches: List[str]


class ImageStatusGetElementModel(BaseModel):
    model_config = {"populate_by_name": True}
    branch: str
    edition: str
    name: str
    show: str
    start_date: str
    end_date: str
    summary_ru: str
    summary_en: str
    description_ru: str
    description_en: str
    mailing_list: str
    name_bugzilla: str
    json_: Dict[str, Any] = Field(default_factory=dict, alias="json")


class ImageStatusGetModel(BaseModel):
    images: List[ImageStatusGetElementModel]


class ImageJSONElementModel(BaseModel):
    img_edition: str
    img_name: str
    img_show: str
    img_summary_ru: str
    img_summary_en: str
    img_start_date: str
    img_end_date: str
    img_mailing_list: str
    img_name_bugzilla: str
    img_json: Dict[str, Any]


class ImageJSONModel(BaseModel):
    img_branch: str
    img_description_ru: str
    img_description_en: str
    images: List[ImageJSONElementModel]


class ImageTagStatusGetElementModel(BaseModel):
    tag: str
    show: str


class ImageTagStatusGetModel(BaseModel):
    tags: List[ImageTagStatusGetElementModel]


class ImageTagJSONElementModel(BaseModel):
    img_tag: str
    img_show: str


class ImageTagJSONModel(BaseModel):
    tags: List[ImageTagJSONElementModel]


class ImageTagUUIDModel(BaseModel):
    request_args: Dict[str, Any]
    uuid: str
    file: str
    type: str
    components: Dict[str, Any]


class ImagePackagesElement1Model(BaseModel):
    hash: str
    arch: str
    name: str
    epoch: int
    version: str
    release: str
    disttag: str
    buildtime: int


class ImagePackagesElement2Model(ImagePackagesElement1Model):
    task_id: int
    subtask_id: int


class ImagePackagesJSONElementModel(BaseModel):
    pkg_hash: str
    pkg_name: str
    pkg_epoch: int
    pkg_version: str
    pkg_release: str
    pkg_arch: str
    pkg_disttag: str
    pkg_buildtime: int


class ImagePackagesJSONModel(BaseModel):
    branch: str
    packages: List[ImagePackagesJSONElementModel]


class ImagePackagesInspectSPPackageModel(BaseModel):
    found_in: str
    version_check: str
    image: ImagePackagesElement1Model | None
    database: ImagePackagesElement1Model | None
    last_branch: ImagePackagesElement1Model | None


class ImagePackagesInspectRegularModel(BaseModel):
    request_args: Dict[str, Any]
    input_pakages: int
    not_in_branch: int
    found_in_tasks: int
    not_found_in_db: int
    packages_in_tasks: List[ImagePackagesElement2Model]
    packages_not_in_db: List[ImagePackagesElement1Model]


class ImagePackagesInspectSPModel(BaseModel):
    request_args: Dict[str, Any]
    input_pakages: int
    in_branch: int
    not_in_branch: int
    found_in_tasks: int
    not_found_in_db: int
    packages: List[ImagePackagesInspectSPPackageModel]


class ImageAllISOElementModel(BaseModel):
    branch: str
    name: str
    tag: str
    file: str
    date: str
    uuid: str


class ImageAllISOModel(BaseModel):
    length: int
    images: List[ImageAllISOElementModel]


class LastImagePackagesElementModel(BaseModel):
    task_id: str
    task_changed: str
    tplan_action: str
    branch: str
    hash: str
    name: str
    version: str
    release: str
    arch: str
    img_hash: str
    img_version: str
    img_release: str
    summary: str
    chlog_name: str
    chlog_nick: str
    chlog_date: str
    chlog_text: str


class LastImagePackagesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[LastImagePackagesElementModel]


class FindImagesByTaskImageElementModel(BaseModel):
    filename: str
    edition: str
    tag: str
    buildtime: str
    binpkg_name: str
    binpkg_version: str
    binpkg_release: str
    binpkg_arch: str
    binpkg_hash: str


class FindImagesByTaskIterationElementModel(BaseModel):
    task_try: int
    task_iter: int


class FindImagesByTaskSubtaskElementModel(BaseModel):
    id: int
    type: str
    srpm_name: str
    srpm_hash: str
    pkg_version: str
    pkg_release: str
    images: List[FindImagesByTaskImageElementModel]


class FindImagesByTaskModel(BaseModel):
    task_id: int
    task_state: str
    task_testonly: int
    task_repo: str
    task_owner: str
    task_try: int
    task_iter: int
    task_message: str
    task_changed: str
    dependencies: List[int]
    subtasks: List[FindImagesByTaskSubtaskElementModel]
    iterations: List[FindImagesByTaskIterationElementModel]


class CheckImagesInputFilterModel(BaseModel):
    editions: List[str]
    releases: List[str]
    versions: List[str]
    archs: List[str]
    variants: List[str]
    types: List[str]


class CheckImagesInputModel(BaseModel):
    task_id: int
    packages_names: List[str]
    filters: List[CheckImagesInputFilterModel]


class CheckImagesOutputPackageModel(BaseModel):
    status: str
    from_subtask: int
    srcpkg_name: str
    binpkg_name: str
    binpkg_arch: str


class CheckImagesOutputImageModel(BaseModel):
    file: str
    branch: str
    edition: str
    flavor: str
    platform: str
    release: str
    major_version: int
    minor_version: int
    sub_version: int
    arch: str
    variant: str
    type: str
    buildtime: str
    packages: List[CheckImagesOutputPackageModel]


class CheckImagesOutputModel(BaseModel):
    request_args: Dict[str, Any]
    in_images: List[CheckImagesOutputImageModel]
    not_in_images: List[CheckImagesOutputPackageModel]


class LicenseInfoModel(BaseModel):
    request_args: Dict[str, Any]
    id: str
    name: str
    text: str
    type: str
    header: str
    comment: str
    urls: List[str]


class LicenseTokensElementModel(BaseModel):
    token: str
    license: str


class LicenseTokensModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    tokens: List[LicenseTokensElementModel]


class BuildDependencySetAmbiguousProvidesPackageModel(BaseModel):
    name: str
    used: bool


class BuildDependencySetAmbiguousProvidesElementModel(BaseModel):
    requires: str
    provides_count: int
    provides: List[BuildDependencySetAmbiguousProvidesPackageModel]


class BuildDependencySetAmbiguousProvidesModel(BaseModel):
    package: str
    ambiguous_provides: List[BuildDependencySetAmbiguousProvidesElementModel]


class BuildDependencySetPackageModel(BaseModel):
    name: str
    version: str
    release: str
    epoch: int
    archs: List[str]
    requires: List[str]


class BuildDependencySetPackagesModel(BaseModel):
    package: str
    length: int
    depends: List[BuildDependencySetPackageModel]


class BuildDependencySetModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[BuildDependencySetPackagesModel]
    ambiguous_dependencies: List[BuildDependencySetAmbiguousProvidesModel]


class PackageFindPackagesetElementModel(BaseModel):
    branch: str
    pkgset_datetime: str
    sourcepkgname: str
    packages: List[str]
    version: str
    release: str
    disttag: str
    packager_email: str
    buildtime: str
    archs: List[str]


class PackageFindPackagesetModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[PackageFindPackagesetElementModel]


class MaintainerScoreElementModel(BaseModel):
    nick: str
    score: float
    base_score: float
    updates: int
    patches: int
    nmu: int
    bugfixes: int
    bugfixes_with_update: int
    in_acl: bool
    last_activity: str
    recent_commits: int
    bonus_applied: bool


class MaintainerScoreModel(BaseModel):
    request_args: Dict[str, Any]
    package: str
    branch: str
    primary_maintainer: str
    status: str
    maintainers: List[MaintainerScoreElementModel]


class PackageMisconflictPackageModel(BaseModel):
    input_package: str
    conflict_package: str
    version: str
    release: str
    epoch: int
    archs: List[str]
    files_with_conflict: List[str]


class PackageMisconflictPackagesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    conflicts: List[PackageMisconflictPackageModel]


class PackageFilesElementModel(BaseModel):
    file_name: str
    file_size: str
    file_class: str
    symlink: str
    file_mtime: str
    file_mode: str


class PackageFilesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    files: List[PackageFilesElementModel]


class RepocopJsonGetModel(BaseModel):
    pkg_name: str
    pkg_version: str
    pkg_release: str
    pkg_arch: str
    branch: str
    test_name: str
    test_status: str
    test_message: str
    test_date: str


class RepocopJsonGetListModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[RepocopJsonGetModel]


class RepocopJsonPostModel(BaseModel):
    pkg_name: str
    pkg_version: str
    pkg_release: str
    pkg_arch: str
    pkgset_name: str
    rc_srcpkg_name: str
    rc_srcpkg_version: str
    rc_srcpkg_release: str
    rc_test_name: str
    rc_test_status: str
    rc_test_message: str
    rc_test_date: str


class RepocopJsonPostListModel(BaseModel):
    packages: List[RepocopJsonPostModel]


class PackageSpecfileModel(BaseModel):
    request_args: Dict[str, Any]
    pkg_hash: str
    pkg_name: str
    pkg_version: str
    pkg_release: str
    specfile_name: str
    specfile_date: str
    specfile_content: str


class UnpackagedDirsElementModel(BaseModel):
    package: str
    directory: str
    version: str
    release: str
    epoch: int
    packager: str
    email: str
    archs: List[str]


class UnpackagedDirsModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[UnpackagedDirsElementModel]


class PackagesetComparePackageModel(BaseModel):
    name: str
    version: str
    release: str


class PackagesetCompareElementModel(BaseModel):
    pkgset1: str
    pkgset2: str
    package1: PackagesetComparePackageModel | None
    package2: PackagesetComparePackageModel | None


class PackagesetCompareModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[PackagesetCompareElementModel]


class MaintainerScoresBatchMaintainerModel(BaseModel):
    nick: str
    score: float
    base_score: float
    updates: int
    patches: int
    nmu: int
    bugfixes: int
    in_acl: bool
    last_activity: str
    recent_commits: int
    bonus_applied: bool


class MaintainerScoresBatchElementModel(BaseModel):
    package: str
    primary_maintainer: str
    status: str
    maintainers: List[MaintainerScoresBatchMaintainerModel]


class MaintainerScoresBatchModel(BaseModel):
    request_args: Dict[str, Any]
    branch: str
    length: int
    packages: List[MaintainerScoresBatchElementModel]


class PackagesByUuidElementModel(BaseModel):
    hash: str
    name: str
    version: str
    release: str
    arch: str
    sourcerpm: str
    summary: str
    buildtime: int
    changelog_text: str


class PackagesByUuidModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[PackagesByUuidElementModel]


class PackageSetStatusGetElementModel(BaseModel):
    branch: str
    pkgset_name_bugzilla: str
    start_date: str
    end_date: str
    show: int
    description_ru: str
    description_en: str
    url_mailing_list: str
    mirrors_json: Dict[str, Any]
    has_images: int


class PackageSetStatusGetModel(BaseModel):
    branches: List[PackageSetStatusGetElementModel]


class PackageSetStatusPostElementModel(BaseModel):
    pkgset_name: str
    rs_pkgset_name_bugzilla: str
    rs_start_date: str
    rs_end_date: str
    rs_show: int
    rs_description_ru: str
    rs_description_en: str
    rs_mailing_list: str
    rs_mirrors_json: List[Dict[str, Any]]


class PackageSetStatusPostModel(BaseModel):
    branches: List[PackageSetStatusPostElementModel]


class PackagesetPackagesElementModel(BaseModel):
    hash: str
    name: str
    version: str
    release: str
    summary: str
    url: str
    license: str
    category: str
    maintainers: List[str]
    acl_list: List[str]
    archs: List[str]


class PackagesetPackagesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[PackagesetPackagesElementModel]
    done_tasks: List[int]


class SiteAllArchsElementModel(BaseModel):
    arch: str
    count: int


class SiteAllArchsModel(BaseModel):
    length: int
    archs: List[SiteAllArchsElementModel]


class SiteAllPackagasetsElementModel(BaseModel):
    branch: str
    count: int


class SiteAllPackagasetsModel(BaseModel):
    length: int
    branches: List[SiteAllPackagasetsElementModel]


class SiteAllPackagesetsSummaryCountsModel(BaseModel):
    arch: str
    count: int


class SiteAllPackagesetsSummaryBranchesModel(BaseModel):
    branch: str
    packages_count: List[SiteAllPackagesetsSummaryCountsModel]


class SiteAllPackagesetsSummaryModel(BaseModel):
    length: int
    branches: List[SiteAllPackagesetsSummaryBranchesModel]


class SiteBeehiveByMaintainerElementModel(BaseModel):
    branch: str
    name: str
    version: str
    release: str
    arch: str
    updated: str
    ftbfs_since: str
    build_time: float
    url: str


class SiteBeehiveByMaintainerModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    beehive: List[SiteBeehiveByMaintainerElementModel]


class SitePackageVersionsElementModel(BaseModel):
    branch: str
    version: str
    release: str
    pkghash: str
    deleted: bool


class SitePackagesBinaryListElementModel(BaseModel):
    hash: str
    name: str
    version: str
    release: str
    arch: str


class SitePackagesBinaryListModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[SitePackagesBinaryListElementModel]
    versions: List[SitePackageVersionsElementModel]


class SiteBinPackageScriptsElementModel(BaseModel):
    prein: str
    postin: str
    preun: str
    postun: str
    pretrans: str
    posttrans: str


class SiteBinPackageScriptsModel(BaseModel):
    request_args: Dict[str, Any]
    pkg_name: str
    pkg_arch: str
    length: int
    scripts: List[SiteBinPackageScriptsElementModel]


class SiteDeletedPackageModel(BaseModel):
    branch: str
    package: str
    version: str
    release: str
    hash: str
    task_id: int
    subtask_id: int
    task_owner: str
    subtask_owner: str
    task_changed: str
    task_message: str


class SiteFastPackagesSearchElementModel(BaseModel):
    name: str
    sourcepackage: str
    branches: List[str]


class SiteFastPackagesSearchModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[SiteFastPackagesSearchElementModel]


class SiteFingPackagesPackageModel(BaseModel):
    name: str
    buildtime: int
    url: str
    summary: str
    category: str
    versions: List[SitePackageVersionsElementModel]
    by_binary: bool


class SiteFingPackagesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[SiteFingPackagesPackageModel]


class SiteLastPackagesElementModel(BaseModel):
    subtask_id: int
    subtask_userid: str
    subtask_type: str
    hash: str
    name: str
    version: str
    release: str
    summary: str
    buildtime: int
    changelog_name: str
    changelog_nickname: str
    changelog_date: str
    changelog_text: str


class SiteLastPackagesPackageModel(BaseModel):
    task_id: int
    task_owner: str
    task_changed: str
    task_message: str
    packages: List[SiteLastPackagesElementModel]


class SiteLastPackagesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    tasks: List[SiteLastPackagesPackageModel]
    last_branch_task: int
    last_branch_date: str


class SiteLastBranchPackagesPackageModel(BaseModel):
    hash: str
    name: str
    version: str
    release: str
    summary: str
    buildtime: int
    changelog_name: str
    changelog_nickname: str
    changelog_date: str
    changelog_text: str


class SiteLastBranchPackagesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[SiteLastBranchPackagesPackageModel]
    last_branch_date: str


class SiteLastPackagesWithCVEFixesElementModel(BaseModel):
    hash: str
    name: str
    version: str
    release: str
    summary: str
    buildtime: int
    changelog_date: str
    changelog_text: str


class SiteLastPackagesWithCVEFixesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[SiteLastPackagesWithCVEFixesElementModel]


class MaintainerBranchesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    branches: List[SiteAllPackagasetsElementModel]


class MaintainerPackagesElementModel(BaseModel):
    name: str
    buildtime: int
    url: str
    summary: str
    version: str
    release: str


class MaintainerPackagesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[MaintainerPackagesElementModel]


class SiteChangelogElementModel(BaseModel):
    date: str
    name: str
    nick: str
    evr: str
    message: str


class SiteChangelogModel(BaseModel):
    pkghash: str
    request_args: Dict[str, Any]
    length: int
    changelog: List[SiteChangelogElementModel]


class SitePackagesDownloadsPackageModel(BaseModel):
    name: str
    url: str
    md5: str
    size: str


class SitePackagesDownloadsElementModel(BaseModel):
    arch: str
    packages: List[SitePackagesDownloadsPackageModel]


class SitePackagesDownloadsModel(BaseModel):
    pkghash: str
    request_args: Dict[str, Any]
    downloads: List[SitePackagesDownloadsElementModel]


class SiteBriefPackageInfoModel(BaseModel):
    name: str
    version: str
    release: str
    arch: str
    summary: str
    type: str


class BinPackageLogElementModel(BaseModel):
    pkg_hash: str
    task_id: int
    subtask_id: int
    subtask_arch: str
    buildlog_hash: str
    link: str


class PackageMisconflictBySrcElementModel(BaseModel):
    input_package: str
    input_archs: List[str]
    conflict_package: str
    version: str
    release: str
    epoch: int
    archs: List[str]
    files_with_conflict: List[str]
    explicit: bool


class PackageMisconflictBySrcModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    conflicts: List[PackageMisconflictBySrcElementModel]


class PackageNameFromRepologyModel(BaseModel):
    request_args: Dict[str, Any]
    name: str
    repo: str


class PackageNVRByHashModel(BaseModel):
    request_args: Dict[str, Any]
    hash: str
    name: str
    version: str
    release: str
    is_source: bool


class SiteSourcePackagesVersionsModel(BaseModel):
    request_args: Dict[str, Any]
    versions: List[SitePackageVersionsElementModel]


class SiteImagePackageVersionsElementModel(BaseModel):
    tag: str
    uuid: str
    version_major: int
    version_minor: int
    version_sub: int
    img_arch: str
    platform: str
    variant: str
    flavor: str
    type: str
    hash: str
    name: str
    version: str
    release: str
    arch: str


class SiteImagePackageVersionsModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    versions: List[SiteImagePackageVersionsElementModel]


class SItePackagesVersionsFromTasksElementModel(BaseModel):
    branch: str
    task: int
    hash: str
    owner: str
    changed: str
    name: str
    version: str
    release: str


class SItePackagesVersionsFromTasksModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    versions: List[SItePackagesVersionsFromTasksElementModel]


class SitePackagesetsByHashModel(BaseModel):
    pkghash: str
    length: int
    branches: List[str]


class SitePackagesetPackageHashByNameVersionRelease(BaseModel):
    request_args: Dict[str, Any]
    pkghash: str


class SitePackagesetCategoryElementModel(BaseModel):
    category: str
    count: int


class SitePackagesetCategoriesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    categories: List[SitePackagesetCategoryElementModel]


class SitePackagesetStatusElementModel(BaseModel):
    branch: str
    start_date: str
    end_date: str
    show: int
    description_ru: str
    description_en: str
    has_images: int


class SitePackagesetsSummaryStatusModel(BaseModel):
    length: int
    branches: List[SiteAllPackagesetsSummaryBranchesModel]
    status: List[SitePackagesetStatusElementModel]


class RepocopByMaintainerElementModel(BaseModel):
    pkg_name: str
    pkg_version: str
    pkg_release: str
    pkg_arch: str
    srcpkg_name: str
    branch: str
    test_name: str
    test_status: str
    test_message: str
    test_date: str


class RepocopByMaintainerModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[RepocopByMaintainerElementModel]


class SitePackagesElementModel(BaseModel):
    hash: str
    name: str
    version: str
    release: str
    summary: str
    buildtime: int
    category: str
    maintainer: str
    changelog: str
    task_id: int
    subtask_id: int
    task_owner: str


class SitePackagesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    subcategories: List[str]
    packages: List[SitePackagesElementModel]


class SiteTaskByNamePackageModel(BaseModel):
    type: str
    name: str
    version: str
    release: str
    link: str


class SiteTaskByNameTaskModel(BaseModel):
    id: int
    state: str
    branch: str
    owner: str
    changed: str
    packages: List[SiteTaskByNamePackageModel]


class SiteTaskByNameModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    tasks: List[SiteTaskByNameTaskModel]


class TasksHistoryBranchCommitModel(BaseModel):
    name: str
    date: str
    task: int


class TasksHistoryTaskModel(BaseModel):
    id: int
    prev: int
    branch: str
    date: str


class SiteTasksHistoryModel(BaseModel):
    branches: List[str]
    tasks: List[TasksHistoryTaskModel]
    branch_commits: List[TasksHistoryBranchCommitModel]


class AllTasksBranchesModel(BaseModel):
    length: int
    branches: List[str]


class FindTasksElementModel(BaseModel):
    task_id: int
    task_owner: str
    task_state: str
    task_repo: str
    components: List[str]


class FindTasksModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    tasks: List[FindTasksElementModel]


class TaskInfoPackageModel(BaseModel):
    name: str
    version: str
    release: str
    filename: str


class TaskInfoApprovalsModel(BaseModel):
    date: str
    type: str
    name: str
    message: str


class TaskInfoArchsModel(BaseModel):
    last_changed: str
    arch: str
    status: str


class TaskInfoSubtaskModel(BaseModel):
    subtask_id: int
    last_changed: str
    userid: str
    type: str
    sid: str
    dir: str
    package: str
    tag_author: str
    tag_name: str
    tag_id: str
    srpm: str
    srpm_name: str
    srpm_evr: str
    pkg_from: str
    source_package: TaskInfoPackageModel | None
    approvals: List[TaskInfoApprovalsModel]
    archs: List[TaskInfoArchsModel]


class TaskInfoPlanModel(BaseModel):
    src: List[TaskInfoPackageModel]
    bin: List[TaskInfoPackageModel]


class TaskInfoPlan2Model(BaseModel):
    model_config = {"populate_by_name": True}

    add: TaskInfoPlanModel | None
    del_: TaskInfoPlanModel | None = Field(None, alias="del")


class TaskInfoModel(BaseModel):
    model_config = {"populate_by_name": True}

    id: int
    prev: int
    try_: int | None = Field(None, alias="try")
    iter: int
    rebuilds: List[str]
    state: str
    branch: str
    user: str
    runby: str
    testonly: int
    failearly: int
    shared: int
    depends: List[int]
    message: str
    version: str
    last_changed: str
    subtasks: List[TaskInfoSubtaskModel]
    plan: TaskInfoPlan2Model | None


class TaskPackagesPackageElementModel(BaseModel):
    name: str
    epoch: int
    version: str
    release: str
    disttag: str
    buildtime: str
    arch: str


class TaskPackagesSubtaskElementModel(BaseModel):
    subtask: int
    source: TaskPackagesPackageElementModel | None
    binaries: List[TaskPackagesPackageElementModel]


class TaskPackagesModel(BaseModel):
    model_config = {"populate_by_name": True}

    id: int
    repo: str
    owner: str
    state: str
    testonly: int
    try_: int | None = Field(None, alias="try")
    iter: int
    message: str
    dependencies: List[int]
    length: int
    subtasks: List[TaskPackagesSubtaskElementModel]
    arepo: List[TaskPackagesPackageElementModel]


class TaskDiffDependenciesModel(BaseModel):
    model_config = {"populate_by_name": True}

    type: str
    del_: List[str] = Field(default_factory=list, alias="del")
    add: List[str]


class TaskDiffPackagesModel(BaseModel):
    model_config = {"populate_by_name": True}

    package: str
    del_: List[str] = Field(default_factory=list, alias="del")
    add: List[str]
    dependencies: List[TaskDiffDependenciesModel]


class TaskDiffArchsModel(BaseModel):
    arch: str
    packages: List[TaskDiffPackagesModel]


class TaskDiffModel(BaseModel):
    task_id: int
    task_have_plan: bool
    task_diff: List[TaskDiffArchsModel]


class TaskFindPackagesetElementModel(BaseModel):
    branch: str
    pkgset_datetime: str
    sourcepkgname: str
    packages: List[str]
    version: str
    release: str
    disttag: str
    packager_email: str
    buildtime: str
    archs: List[str]


class TaskFindPackagesetModel(BaseModel):
    id: int
    request_args: Dict[str, Any]
    task_packages: List[str]
    length: int
    packages: List[TaskFindPackagesetElementModel]


class TaskMisconflictPackageModel(BaseModel):
    input_package: str
    conflict_package: str
    version: str
    release: str
    epoch: int
    archs: List[str]
    files_with_conflict: List[str]


class TaskMisconflictPackagesModel(BaseModel):
    id: int
    request_args: Dict[str, Any]
    length: int
    conflicts: List[TaskMisconflictPackageModel]


class NeedsApprovalSubtaskElementModel(BaseModel):
    id: int
    type: str
    package: str
    userid: str
    dir: str
    sid: str
    pkg_from: str
    tag_author: str
    tag_id: str
    tag_name: str
    srpm: str
    srpm_name: str
    srpm_evr: str
    last_changed: str
    source_package: TaskInfoPackageModel | None


class NeedsApprovalTaskElementModel(BaseModel):
    model_config = {"populate_by_name": True}

    id: int
    state: str
    runby: str
    try_: int | None = Field(None, alias="try")
    iter: int
    failearly: bool
    shared: bool
    depends: List[int]
    testonly: bool
    message: str
    version: str
    prev: int
    last_changed: str
    branch: str
    user: str
    subtasks: List[NeedsApprovalSubtaskElementModel]


class NeedsApprovalModel(BaseModel):
    length: int
    tasks: List[NeedsApprovalTaskElementModel]


class TaskHistoryElementModel(BaseModel):
    task_id: int
    task_commited: str
    branch_commited: str


class TaskHistoryModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    tasks: List[TaskHistoryElementModel]


class TaskRepoPackageModel(BaseModel):
    name: str
    version: str
    release: str
    filename: str


class TaskRepoInfoModel(BaseModel):
    name: str
    date: str
    tag: str


class TaskRepoArchsModel(BaseModel):
    arch: str
    packages: List[TaskRepoPackageModel]


class TaskRepoModel(BaseModel):
    task_id: int
    base_repository: TaskRepoInfoModel | None
    task_diff_list: List[int]
    archs: List[TaskRepoArchsModel]


class TaskBuildDependencyElementModel(BaseModel):
    depth: int
    name: str
    version: str
    release: str
    epoch: int
    serial: int
    sourcerpm: str
    branch: str
    buildtime: str
    archs: List[str]
    cycle: List[str]
    requires: List[str]
    acl: List[str]


class TaskBuildDependencyModel(BaseModel):
    id: int
    request_args: Dict[str, Any]
    length: int
    dependencies: List[TaskBuildDependencyElementModel]


class VulnerabilityReferenceElementModel(BaseModel):
    name: str
    url: str
    tags: List[str]


class VulnerabilityCVSSVectorElementModel(BaseModel):
    version: str
    score: float
    vector: str


class VulnerabilityConfigurationElementModel(BaseModel):
    cpe: str
    version_start_excluding: str
    version_start_including: str
    version_end_excluding: str
    version_end_including: str


class VulnerabilityParsedDetailsModel(BaseModel):
    references: List[VulnerabilityReferenceElementModel]
    cvss_vectors: List[VulnerabilityCVSSVectorElementModel]
    configurations: List[VulnerabilityConfigurationElementModel]
    cwes: List[str]


class VulnerabilityModel(BaseModel):
    model_config = {"populate_by_name": True}
    id: str
    summary: str
    url: str
    severity: str
    score: float
    published: str
    modified: str
    refs: List[str]
    json_: Dict[str, Any] = Field(default_factory=dict, alias="json")
    rejected: bool


class VulnerabilityInfoModel(BaseModel):
    request_args: Dict[str, Any]
    vuln_info: VulnerabilityModel | None
    parsed: VulnerabilityParsedDetailsModel | None


class VulnPackageLastVersionModel(BaseModel):
    pkghash: str
    name: str
    branch: str
    version: str
    release: str


class VulnFixesPackagesElementModel(BaseModel):
    pkghash: str
    name: str
    branch: str
    version: str
    release: str
    errata_id: str
    task_id: int
    task_state: str
    last_version: VulnPackageLastVersionModel | None


class VulnFixesPackagesModel(BaseModel):
    request_args: Dict[str, Any]
    length: int
    packages: List[VulnFixesPackagesElementModel]


class CveTaskPackageVulnerableElementModel(BaseModel):
    id: str
    type: str
    link: str


class CveTaskPackagesElementModel(BaseModel):
    subtask: int
    pkghash: str
    pkg_name: str
    pkg_version: str
    pkg_release: str
    branch: str
    errata_id: str
    errata_link: str
    vulnerabilities: List[CveTaskPackageVulnerableElementModel]


class CveVulnerableTaskModel(BaseModel):
    packages: List[CveTaskPackagesElementModel]
