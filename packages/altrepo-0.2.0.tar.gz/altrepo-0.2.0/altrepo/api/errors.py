class RequestValidationError(Exception):
    """Ошибка валидации параметров запроса (400)"""
    pass


class DataNotFoundError(Exception):
    """Данные не найдены в базе (404)"""
    pass


class TooManyRequests(Exception):
    """Cлишком много запросо (429)"""
    pass


class UnexpectedResponseError(Exception):
    """Непредвиденный ответ от сервера"""
    def __init__(self, status_code: int, message: str = ""):
        self.status_code = status_code
        self.message = message or f"Unexpected response status: {status_code}"
        super().__init__(self.message)
