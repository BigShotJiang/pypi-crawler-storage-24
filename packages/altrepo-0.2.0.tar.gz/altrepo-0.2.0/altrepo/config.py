from dataclasses import dataclass, field


@dataclass
class ALTRepoConfig:
    api_base_url: str = "https://rdb.altlinux.org/api"
    cybertalk_url: str = "https://lists.altlinux.org/pipermail/sisyphus-cybertalk/{}/"
    ftbfs_url: str = "https://git.altlinux.org/beehive/stats/Sisyphus-x86_64/ftbfs-joined"
    watch_url: str = "https://watch.altlinux.org/pub/watch/{by_acl}/{nickname}.txt"
    watch_total_url: str = "https://watch.altlinux.org/pub/watch/watch-total.txt"
    appstream_url: str = (
        "https://git.altlinux.org/gears/a/appstream-data-desktop.git?"
        "a=blob_plain;f=xmls/altlinux.xml;hb=refs/heads/{branch}"
    )
    appstream_branches: list[str] = field(default_factory=lambda: ["sisyphus", "p11"])
    appstream_dir: str = "appstream"
