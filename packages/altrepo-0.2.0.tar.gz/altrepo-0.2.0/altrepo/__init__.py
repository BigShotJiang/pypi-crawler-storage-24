import aiohttp

from .api import ALTRepoAPI
from .appstream import ALTRepoAppStream
from .config import ALTRepoConfig
from .parser import ALTRepoParser


class ALTRepo:

    def __init__(self, config: ALTRepoConfig | None = None):
        self.config = config or ALTRepoConfig()
        self._session: aiohttp.ClientSession | None = None
        self.api: ALTRepoAPI | None = None
        self.appstream: ALTRepoAppStream | None = None
        self.parser: ALTRepoParser | None = None

    async def init(self, session: aiohttp.ClientSession | None = None):
        if self._session is None:
            self._session = session or aiohttp.ClientSession()
            self.api = ALTRepoAPI(self._session, self.config)
            self.appstream = ALTRepoAppStream(self._session, self.config)
            self.parser = ALTRepoParser(self._session, self.config)

    async def close(self):
        await self._session.close()


__all__ = ("ALTRepo", "ALTRepoConfig")
