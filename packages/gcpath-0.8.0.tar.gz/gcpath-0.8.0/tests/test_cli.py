import json

import pytest
import yaml
from typer.testing import CliRunner
from unittest.mock import patch, MagicMock
from gcpath.cli import app
from gcpath.core import OrganizationNode, Hierarchy, Project, GCPathError
from gcpath.cache import CacheInfo
from google.cloud import resourcemanager_v3

runner = CliRunner()


@pytest.fixture(autouse=True)
def mock_read_cache():
    """Prevent tests from hitting the real cache file."""
    with patch("gcpath.cli.read_cache", return_value=None) as m:
        yield m


@patch("gcpath.core.Hierarchy.load")
def test_ls_command(mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["ls"])
    assert result.exit_code == 0
    # Top level orgs and orgless projects by default
    assert "//example.com" in result.stdout
    assert "//_/Standalone" in result.stdout


@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_ls_positional_resource(mock_resolve, mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"

    # List folder/1 children
    result = runner.invoke(app, ["ls", "folders/1"])
    assert result.exit_code == 0
    # Child of folders/1 is Project 1 and folders/11 (depth 2)
    assert "//example.com/f1/f11" in result.stdout
    assert "//example.com/f1/Project%201" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_ls_recursive(mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["ls", "-R"])
    assert result.exit_code == 0
    assert "//example.com" in result.stdout
    assert "//example.com/f1" in result.stdout
    assert "//example.com/f1/f11" in result.stdout
    assert "//example.com/f1/Project%201" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_ls_long_format(mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["ls", "-l"])
    assert result.exit_code == 0
    assert "Path" in result.stdout
    assert "Resource Name" in result.stdout
    assert "example.com" in result.stdout
    assert "organizations/123" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_ls_long_format_shows_org_resource_names(mock_load, mock_hierarchy):
    """Verify organization resource names appear in long format"""
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["ls", "-l"])
    assert result.exit_code == 0
    assert "organizations/123" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_ls_long_format_shows_folder_resource_names(mock_load, mock_hierarchy):
    """Verify folder resource names appear in long format"""
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["ls", "-l", "organizations/123"])
    assert result.exit_code == 0
    assert "folders/1" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_ls_long_format_shows_project_resource_names(mock_load, mock_hierarchy):
    """Verify project resource names appear in long format"""
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["ls", "-l", "folders/1"])
    assert result.exit_code == 0
    assert "projects/p1" in result.stdout


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_tree_command_full(mock_confirm, mock_load, mock_hierarchy):
    mock_confirm.return_value = True  # User confirms the prompt
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["tree"])
    assert result.exit_code == 0
    assert "example.com" in result.stdout
    assert "f1" in result.stdout
    assert "f11" in result.stdout
    assert "(organizationless)" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_tree_depth_limit(mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["tree", "-L", "1"])
    assert result.exit_code == 0
    assert "f1" in result.stdout
    assert "f11" not in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_tree_accepts_level_greater_than_3(mock_load, mock_hierarchy):
    """Test that tree command accepts level > 3 (no more artificial limit)"""
    mock_load.return_value = mock_hierarchy
    # Use -y to skip the prompt that would trigger for level >= 4
    result = runner.invoke(app, ["tree", "-L", "5", "-y"])
    assert result.exit_code == 0


@patch("gcpath.cli.get_cache_info")
@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_tree_prompts_on_unlimited_load(
    mock_confirm, mock_load, mock_cache_info, mock_hierarchy
):
    """Test that tree prompts when loading full org tree without limit"""
    mock_cache_info.return_value = CacheInfo(
        exists=False, fresh=False, age_seconds=None, size_bytes=None,
        version=None, org_count=0, folder_count=0, project_count=0
    )
    mock_confirm.return_value = True
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["tree"])
    assert mock_confirm.called
    assert result.exit_code == 0


@patch("gcpath.cli.get_cache_info")
@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_tree_prompts_on_large_level(
    mock_confirm, mock_load, mock_cache_info, mock_hierarchy
):
    """Test that tree prompts when level >= 4"""
    mock_cache_info.return_value = CacheInfo(
        exists=False, fresh=False, age_seconds=None, size_bytes=None,
        version=None, org_count=0, folder_count=0, project_count=0
    )
    mock_confirm.return_value = True
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["tree", "-L", "4"])
    assert mock_confirm.called
    assert result.exit_code == 0


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_tree_yes_flag_skips_prompt(mock_confirm, mock_load, mock_hierarchy):
    """Test that --yes skips prompt"""
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["tree", "-y"])
    assert not mock_confirm.called
    assert result.exit_code == 0


@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
@patch("typer.confirm")
def test_tree_scoped_load_no_prompt(
    mock_confirm, mock_resolve, mock_load, mock_hierarchy
):
    """Test that scoped loads don't prompt"""
    mock_load.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"
    result = runner.invoke(app, ["tree", "folders/1"])
    assert not mock_confirm.called
    assert result.exit_code == 0


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_tree_user_declines_prompt(mock_confirm, mock_load, mock_hierarchy):
    """Test that declining prompt exits cleanly"""
    mock_confirm.return_value = False
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["tree"])
    assert result.exit_code == 0  # Clean exit


@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_tree_positional_resource(mock_resolve, mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"
    result = runner.invoke(app, ["tree", "folders/1"])
    assert result.exit_code == 0
    assert "//example.com/f1" in result.stdout
    assert "f11" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_name_command(mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["name", "//example.com/f1"])
    assert result.exit_code == 0
    assert "folders/1" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_name_command_id_only(mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["name", "--id", "//example.com/f1"])
    assert result.exit_code == 0
    assert "1" in result.stdout
    assert "folders" not in result.stdout


@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_path_command(mock_resolve):
    mock_resolve.return_value = "//example.com/f1"
    result = runner.invoke(app, ["path", "folders/1"])
    assert result.exit_code == 0
    assert "//example.com/f1" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_ls_no_resources_message(mock_load):
    h = Hierarchy([], [])
    mock_load.return_value = h
    result = runner.invoke(app, ["ls"])
    assert result.exit_code == 0
    # No organizations or projects message check
    # Depending on implementation it might print something or just empty list now with organizations/projects structure
    # My current implementation of ls doesn't have the specific "No resources found" msg anymore, it just prints what it finds.
    # But let's verify it doesn't crash.
    assert result.exception is None


# --- Stats command tests ---


@patch("gcpath.core.Hierarchy.load")
def test_stats_command(mock_load, mock_hierarchy):
    """Test stats command shows folder and project counts."""
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["stats"])
    assert result.exit_code == 0
    assert "Folders" in result.stdout
    assert "Projects" in result.stdout
    assert "Organizations" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_stats_command_scoped_org(mock_load, mock_hierarchy):
    """Test stats command scoped to an organization."""
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["stats", "organizations/123"])
    assert result.exit_code == 0
    assert "organizations/123" in result.stdout
    assert "Folders" in result.stdout
    assert "Projects" in result.stdout
    assert "Organizations" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_stats_command_scoped_folder(mock_load, mock_hierarchy):
    """Test stats command scoped to a folder omits organization row."""
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["stats", "folders/1"])
    assert result.exit_code == 0
    assert "folders/1" in result.stdout
    assert "Folders" in result.stdout
    assert "Projects" in result.stdout
    assert "Organizations" not in result.stdout


def test_stats_project_scope_error():
    """Test stats command rejects project scope."""
    result = runner.invoke(app, ["stats", "projects/123"])
    assert result.exit_code == 1


def test_stats_invalid_scope_error():
    """Test stats command rejects invalid scope."""
    result = runner.invoke(app, ["stats", "invalid/scope"])
    assert result.exit_code == 1
    assert "Invalid resource format" in result.output


def test_handle_error_gcpath_error():
    from gcpath.cli import handle_error
    import typer

    with pytest.raises(typer.Exit):
        handle_error(GCPathError("test error"))


@patch("gcpath.cli.Hierarchy.load")
def test_debug_flag(mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["--debug", "ls"])
    assert result.exit_code == 0


@patch("gcpath.core.Hierarchy.load")
def test_ls_gmail_account(mock_load):
    # Mock google.auth.default to return a gmail account
    mock_creds = MagicMock()
    mock_creds.account = "user@gmail.com"

    with patch("google.auth.default", return_value=(mock_creds, "project")):
        mock_load.return_value = Hierarchy([], [])
        result = runner.invoke(app, ["ls"])
        assert (
            "No organizations or projects found accessible to your account"
            in result.stdout
        )
        assert "user@gmail.com" in result.stdout


@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_ls_recursive_folder(mock_resolve, mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"

    result = runner.invoke(app, ["ls", "-R", "folders/1"])
    assert result.exit_code == 0
    assert "//example.com/f1" in result.stdout
    assert "//example.com/f1/f11" in result.stdout


def test_handle_error_permission_denied():
    from google.api_core import exceptions as gcp_exceptions
    from gcpath.cli import handle_error
    import typer

    with pytest.raises(typer.Exit):
        handle_error(gcp_exceptions.PermissionDenied("denied"))


def test_handle_error_service_unavailable():
    from google.api_core import exceptions as gcp_exceptions
    from gcpath.cli import handle_error
    import typer

    with pytest.raises(typer.Exit):
        handle_error(gcp_exceptions.ServiceUnavailable("unavailable"))


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_tree_with_ids(mock_confirm, mock_load, mock_hierarchy):
    mock_confirm.return_value = True  # User confirms the prompt
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["tree", "--ids"])
    assert result.exit_code == 0
    assert "(organizations/123)" in result.stdout
    assert "(folders/1)" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_name_organizationless_project(mock_load):
    # Setup hierarchy with an orgless project
    p1 = Project(
        name="projects/965192208715",
        project_id="main-dev-levente-001",
        display_name="main-dev-levente-001",
        parent="organizations/0",
        organization=None,
        folder=None,
    )
    mock_load.return_value = Hierarchy([], [p1])

    result = runner.invoke(app, ["name", "//_/main-dev-levente-001"])
    assert result.exit_code == 0
    assert "projects/965192208715" in result.stdout


@patch("gcpath.core.Hierarchy.load")
def test_name_multiple_paths(mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["name", "//example.com", "//example.com/f1"])
    assert result.exit_code == 0
    assert "organizations/123" in result.stdout
    assert "folders/1" in result.stdout


@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_path_multiple_resources(mock_resolve):
    mock_resolve.side_effect = ["//path1", "//path2"]
    result = runner.invoke(app, ["path", "folders/1", "folders/2"])
    assert result.exit_code == 0
    assert "//path1" in result.stdout
    assert "//path2" in result.stdout


@patch("gcpath.cli.clear_cache")
def test_cache_clear(mock_clear_cache):
    """Test cache clear subcommand"""
    mock_clear_cache.return_value = True
    result = runner.invoke(app, ["cache", "clear"])
    assert result.exit_code == 0
    mock_clear_cache.assert_called_once()


@patch("gcpath.cli.get_cache_info")
def test_cache_status(mock_get_cache_info):
    """Test cache status subcommand with fresh cache"""
    mock_get_cache_info.return_value = CacheInfo(
        exists=True,
        fresh=True,
        age_seconds=300.0,  # 5 minutes ago
        size_bytes=2048,
        version=1,
        org_count=2,
        folder_count=10,
        project_count=25,
    )
    result = runner.invoke(app, ["cache", "status"])
    assert result.exit_code == 0
    assert "Fresh" in result.stdout or "5m" in result.stdout
    assert "2.0 KB" in result.stdout  # 2048 bytes = 2.0 KB
    assert "2" in result.stdout  # org count
    assert "10" in result.stdout  # folder count
    assert "25" in result.stdout  # project count


@patch("gcpath.cli.get_cache_info")
def test_cache_status_no_cache(mock_get_cache_info):
    """Test cache status subcommand when no cache exists"""
    mock_get_cache_info.return_value = CacheInfo(
        exists=False,
        fresh=False,
        age_seconds=None,
        size_bytes=None,
        version=None,
        org_count=0,
        folder_count=0,
        project_count=0,
    )
    result = runner.invoke(app, ["cache", "status"])
    assert result.exit_code == 0
    assert "No cache" in result.stdout or "Does not exist" in result.stdout


# --- Diagram command tests ---


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_diagram_mermaid_default(mock_confirm, mock_load, mock_hierarchy):
    """Test diagram command produces Mermaid output by default."""
    mock_confirm.return_value = True
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["diagram"])
    assert result.exit_code == 0
    assert "graph TD" in result.stdout
    assert "organizations_123" in result.stdout
    assert "example.com" in result.stdout


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_diagram_d2(mock_confirm, mock_load, mock_hierarchy):
    """Test diagram command with D2 format."""
    mock_confirm.return_value = True
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["diagram", "--format", "d2"])
    assert result.exit_code == 0
    assert "graph TD" not in result.stdout
    assert "organizations_123" in result.stdout
    assert "->" in result.stdout


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_diagram_with_ids(mock_confirm, mock_load, mock_hierarchy):
    """Test diagram command with resource IDs."""
    mock_confirm.return_value = True
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["diagram", "--ids"])
    assert result.exit_code == 0
    assert "(organizations/123)" in result.stdout


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_diagram_with_level(mock_confirm, mock_load, mock_hierarchy):
    """Test diagram with depth limit."""
    mock_confirm.return_value = True
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["diagram", "-L", "1"])
    assert result.exit_code == 0
    assert "f1" in result.stdout
    # f11 is at depth 2, should not appear
    assert "f11" not in result.stdout


@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_diagram_scoped(mock_resolve, mock_load, mock_hierarchy):
    """Test diagram with scoped resource."""
    mock_load.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"
    result = runner.invoke(app, ["diagram", "folders/1"])
    assert result.exit_code == 0
    assert "folders_1" in result.stdout


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_diagram_output_file(mock_confirm, mock_load, mock_hierarchy, tmp_path):
    """Test diagram output to file."""
    mock_confirm.return_value = True
    mock_load.return_value = mock_hierarchy
    out_file = tmp_path / "test.mmd"
    result = runner.invoke(app, ["diagram", "-o", str(out_file)])
    assert result.exit_code == 0
    assert out_file.exists()
    content = out_file.read_text()
    assert "graph TD" in content


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_diagram_includes_orgless(mock_confirm, mock_load, mock_hierarchy):
    """Test that diagram includes organizationless projects."""
    mock_confirm.return_value = True
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["diagram"])
    assert result.exit_code == 0
    assert "organizationless" in result.stdout
    assert "Standalone" in result.stdout


def test_diagram_invalid_format():
    """Test diagram command rejects invalid format."""
    result = runner.invoke(app, ["diagram", "--format", "svg", "-y"])
    assert result.exit_code == 1


@patch("gcpath.core.Hierarchy.load")
def test_diagram_yes_flag_skips_prompt(mock_load, mock_hierarchy):
    """Test that --yes skips prompt."""
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["diagram", "-y"])
    assert result.exit_code == 0


# --- Config subcommand tests ---


@patch("gcpath.cli.set_entrypoint")
def test_config_set_entrypoint(mock_set):
    """Test config set-entrypoint command."""
    result = runner.invoke(app, ["config", "set-entrypoint", "folders/123"])
    assert result.exit_code == 0
    mock_set.assert_called_once_with("folders/123")
    assert "Entrypoint set" in result.stdout


@patch("gcpath.cli.set_entrypoint", side_effect=ValueError("must start with"))
def test_config_set_entrypoint_invalid(mock_set):
    """Test config set-entrypoint rejects invalid resource."""
    result = runner.invoke(app, ["config", "set-entrypoint", "projects/bad"])
    assert result.exit_code == 1


@patch("gcpath.cli.read_config", return_value={"entrypoint": "folders/123"})
def test_config_show(mock_read):
    """Test config show command."""
    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0
    assert "folders/123" in result.stdout


@patch("gcpath.cli.read_config", return_value={})
def test_config_show_empty(mock_read):
    """Test config show when no config set."""
    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0
    assert "No configuration" in result.stdout


@patch("gcpath.cli.clear_entrypoint")
def test_config_clear_entrypoint(mock_clear):
    """Test config clear-entrypoint command."""
    result = runner.invoke(app, ["config", "clear-entrypoint"])
    assert result.exit_code == 0
    assert "cleared" in result.stdout
    mock_clear.assert_called_once()


# --- Entrypoint behavior tests ---


@patch("gcpath.cli.get_entrypoint", return_value="folders/100")
@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_ls_with_entrypoint(mock_resolve, mock_load, mock_get_ep, mock_hierarchy):
    """ls with no resource arg uses entrypoint as scope."""
    mock_load.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"

    result = runner.invoke(app, ["ls"])
    assert result.exit_code == 0
    # Hierarchy.load should have been called with scope_resource="folders/100"
    mock_load.assert_called_once()
    call_kwargs = mock_load.call_args
    assert call_kwargs[1]["scope_resource"] == "folders/100"


@patch("gcpath.cli.get_entrypoint", return_value="folders/100")
@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_ls_explicit_resource_overrides_entrypoint(
    mock_resolve, mock_load, mock_get_ep, mock_hierarchy
):
    """Explicit resource arg overrides entrypoint."""
    mock_load.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"

    result = runner.invoke(app, ["ls", "folders/1"])
    assert result.exit_code == 0
    mock_load.assert_called_once()
    call_kwargs = mock_load.call_args
    # Should use folders/1, not folders/100
    assert call_kwargs[1]["scope_resource"] == "folders/1"


@patch("gcpath.cli.get_entrypoint", return_value="folders/100")
@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_entrypoint_flag_overrides_config(
    mock_resolve, mock_load, mock_get_ep, mock_hierarchy
):
    """--entrypoint flag overrides config file entrypoint."""
    mock_load.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"

    result = runner.invoke(app, ["--entrypoint", "folders/200", "ls"])
    assert result.exit_code == 0
    mock_load.assert_called_once()
    call_kwargs = mock_load.call_args
    assert call_kwargs[1]["scope_resource"] == "folders/200"


@patch("gcpath.cli.get_entrypoint", return_value="folders/100")
@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_tree_with_entrypoint(mock_resolve, mock_load, mock_get_ep, mock_hierarchy):
    """tree with no resource arg uses entrypoint."""
    mock_load.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"

    result = runner.invoke(app, ["tree"])
    assert result.exit_code == 0
    mock_load.assert_called_once()
    call_kwargs = mock_load.call_args
    assert call_kwargs[1]["scope_resource"] == "folders/100"


@patch("gcpath.cli.get_entrypoint", return_value="folders/100")
@patch("gcpath.core.Hierarchy.load")
def test_name_with_entrypoint(mock_load, mock_get_ep, mock_hierarchy):
    """name command uses entrypoint as scope_resource for loading."""
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["name", "//example.com/f1"])
    assert result.exit_code == 0
    mock_load.assert_called_once()
    call_kwargs = mock_load.call_args
    assert call_kwargs[1]["scope_resource"] == "folders/100"


# --- Entrypoint + cache interaction tests ---


@patch("gcpath.cli.get_entrypoint", return_value="folders/100")
@patch("gcpath.cli.write_cache")
@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_ls_entrypoint_uses_cache(
    mock_resolve, mock_load, mock_write, mock_get_ep, mock_hierarchy, mock_read_cache
):
    """Cache hit path: read_cache(scope='folders/100') returns data, Hierarchy.load not called."""
    mock_read_cache.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"

    result = runner.invoke(app, ["ls"])
    assert result.exit_code == 0
    # read_cache should have been called with scope
    mock_read_cache.assert_called_with(scope="folders/100")
    # Hierarchy.load should NOT be called (cache hit)
    mock_load.assert_not_called()


@patch("gcpath.cli.get_entrypoint", return_value="folders/100")
@patch("gcpath.cli.write_cache")
@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_ls_entrypoint_writes_cache(
    mock_resolve, mock_load, mock_write, mock_get_ep, mock_hierarchy, mock_read_cache
):
    """Cache miss path: write_cache(hierarchy, scope='folders/100') called."""
    mock_read_cache.return_value = None
    mock_load.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"

    result = runner.invoke(app, ["ls"])
    assert result.exit_code == 0
    mock_write.assert_called_once_with(mock_hierarchy, scope="folders/100")


@patch("gcpath.cli.get_entrypoint", return_value="folders/100")
@patch("gcpath.cli.write_cache")
@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_ls_entrypoint_loads_recursively(
    mock_resolve, mock_load, mock_write, mock_get_ep, mock_hierarchy, mock_read_cache
):
    """Hierarchy.load called with recursive=True even for non-recursive ls."""
    mock_read_cache.return_value = None
    mock_load.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"

    result = runner.invoke(app, ["ls"])  # default recursive=False
    assert result.exit_code == 0
    mock_load.assert_called_once()
    call_kwargs = mock_load.call_args[1]
    assert call_kwargs["recursive"] is True


@patch("gcpath.cli.get_entrypoint", return_value="folders/100")
@patch("gcpath.cli.write_cache")
@patch("gcpath.core.Hierarchy.load")
@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_ls_explicit_resource_not_cached(
    mock_resolve, mock_load, mock_write, mock_get_ep, mock_hierarchy, mock_read_cache
):
    """Explicit resource != entrypoint: write_cache NOT called."""
    mock_read_cache.return_value = None
    mock_load.return_value = mock_hierarchy
    mock_resolve.return_value = "//example.com/f1"

    result = runner.invoke(app, ["ls", "folders/999"])
    assert result.exit_code == 0
    mock_write.assert_not_called()


@patch("gcpath.cli.get_cache_info")
def test_cache_status_shows_scope(mock_get_cache_info):
    """Scope is displayed in cache status output."""
    mock_get_cache_info.return_value = CacheInfo(
        exists=True,
        fresh=True,
        age_seconds=300.0,
        size_bytes=2048,
        version=1,
        org_count=1,
        folder_count=5,
        project_count=10,
        scope="folders/100",
    )
    result = runner.invoke(app, ["cache", "status"])
    assert result.exit_code == 0
    assert "Scope" in result.stdout
    assert "folders/100" in result.stdout


# --- _try_read_cache helper tests ---


@patch("gcpath.cli.read_cache")
@patch("gcpath.cli.get_cache_info")
def test_try_read_cache_returns_none_on_miss(mock_get_info, mock_read_cache):
    """Test _try_read_cache returns None when cache miss."""
    from gcpath.cli import _try_read_cache

    mock_read_cache.return_value = None

    result = _try_read_cache(None, None)
    assert result is None


@patch("gcpath.cli.read_cache")
@patch("gcpath.cli.get_cache_info")
@patch("gcpath.cli.rprint")
def test_try_read_cache_applies_org_filter(mock_rprint, mock_get_info, mock_read_cache):
    """Test _try_read_cache applies org filter to cached data."""
    from gcpath.cli import _try_read_cache

    # Create mock hierarchy with two orgs
    org1 = resourcemanager_v3.Organization(
        name="organizations/1", display_name="org1.com"
    )
    org2 = resourcemanager_v3.Organization(
        name="organizations/2", display_name="org2.com"
    )
    node1 = OrganizationNode(organization=org1)
    node2 = OrganizationNode(organization=org2)
    mock_hierarchy = Hierarchy([node1, node2], [])

    mock_read_cache.return_value = mock_hierarchy
    mock_get_info.return_value = CacheInfo(
        exists=True, fresh=True, age_seconds=60.0,
        size_bytes=100, version=1, org_count=2, folder_count=0, project_count=0
    )

    # Filter to only org1
    result = _try_read_cache(None, ["org1.com"])

    assert len(result.organizations) == 1
    assert result.organizations[0].organization.display_name == "org1.com"


# --- Structured output (--json / --yaml) tests ---


def test_json_yaml_mutually_exclusive():
    """--json and --yaml together should fail."""
    result = runner.invoke(app, ["--json", "--yaml", "ls"])
    assert result.exit_code == 1


@patch("gcpath.core.Hierarchy.load")
def test_ls_json_output(mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["--json", "ls"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert isinstance(data, list)
    assert len(data) > 0
    assert all("path" in item for item in data)
    assert all("type" in item for item in data)
    types = {item["type"] for item in data}
    assert "organization" in types


@patch("gcpath.core.Hierarchy.load")
def test_ls_yaml_output(mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["--yaml", "ls"])
    assert result.exit_code == 0
    data = yaml.safe_load(result.stdout)
    assert isinstance(data, list)
    assert len(data) > 0
    assert all("path" in item for item in data)


@patch("gcpath.core.Hierarchy.load")
def test_ls_json_no_data(mock_load):
    """Empty hierarchy produces empty JSON array."""
    mock_load.return_value = Hierarchy([], [])
    result = runner.invoke(app, ["--json", "ls"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data == []


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_tree_json_output(mock_confirm, mock_load, mock_hierarchy):
    mock_confirm.return_value = True
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["--json", "tree"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert isinstance(data, list)
    assert len(data) >= 1
    # First node should be the organization
    org_node = data[0]
    assert org_node["type"] == "organization"
    assert "children" in org_node


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_tree_yaml_output(mock_confirm, mock_load, mock_hierarchy):
    mock_confirm.return_value = True
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["--yaml", "tree"])
    assert result.exit_code == 0
    data = yaml.safe_load(result.stdout)
    assert isinstance(data, list)
    assert data[0]["type"] == "organization"
    assert "children" in data[0]


@patch("gcpath.core.Hierarchy.load")
@patch("typer.confirm")
def test_tree_json_includes_orgless(mock_confirm, mock_load, mock_hierarchy):
    mock_confirm.return_value = True
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["--json", "tree"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    orgless_nodes = [n for n in data if n.get("type") == "organizationless"]
    assert len(orgless_nodes) == 1
    assert len(orgless_nodes[0]["children"]) == 1


@patch("gcpath.core.Hierarchy.load")
def test_name_json_output(mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["--json", "name", "//example.com/f1"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert isinstance(data, list)
    assert data[0]["path"] == "//example.com/f1"
    assert data[0]["resource_name"] == "folders/1"


@patch("gcpath.core.Hierarchy.load")
def test_name_json_id_only(mock_load, mock_hierarchy):
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["--json", "name", "--id", "//example.com/f1"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert "resource_id" in data[0]
    assert data[0]["resource_id"] == "1"


@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_path_json_output(mock_resolve):
    mock_resolve.return_value = "//example.com/f1"
    result = runner.invoke(app, ["--json", "path", "folders/1"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert isinstance(data, list)
    assert data[0]["resource_name"] == "folders/1"
    assert data[0]["path"] == "//example.com/f1"


@patch("gcpath.cli.Hierarchy.resolve_ancestry")
def test_path_yaml_output(mock_resolve):
    mock_resolve.return_value = "//example.com/f1"
    result = runner.invoke(app, ["--yaml", "path", "folders/1"])
    assert result.exit_code == 0
    data = yaml.safe_load(result.stdout)
    assert data[0]["resource_name"] == "folders/1"
    assert data[0]["path"] == "//example.com/f1"


@patch("gcpath.core.Hierarchy.load")
def test_json_output_no_rich_markup(mock_load, mock_hierarchy):
    """Structured output must not contain Rich markup."""
    mock_load.return_value = mock_hierarchy
    result = runner.invoke(app, ["--json", "ls"])
    assert result.exit_code == 0
    assert "[dim]" not in result.stdout
    assert "[bold" not in result.stdout
    assert "[green]" not in result.stdout
