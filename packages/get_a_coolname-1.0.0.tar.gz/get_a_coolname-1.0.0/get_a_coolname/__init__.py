from get_a_coolname.core import get_a_coolname

__all__ = ["get_a_coolname"]
