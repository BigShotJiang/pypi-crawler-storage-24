# get-a-coolname

Get a predictable coolname from any Python object.

## Installation

```bash
pip install get-a-coolname
```

## Usage

```python
from get_a_coolname import get_a_coolname

# Deterministic: same seed always gives the same name
get_a_coolname((42, "pythons", float))
# => 'solemn_pants_resize_lightly'

# Random: no seed, different name each time
get_a_coolname()
# => 'jovial_tigers_hug_silently'

# camelCase output
get_a_coolname(seed="hello", camel=True)
# => 'pinkWhalesSkateBeautifully'

# Pick which components to include
get_a_coolname(seed="x", noun=False, adverb=False)
# => 'stunning_spell'
```
