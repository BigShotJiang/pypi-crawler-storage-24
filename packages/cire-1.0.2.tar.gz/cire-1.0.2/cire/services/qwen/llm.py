import os
import asyncio
import logging
import json
from dotenv import load_dotenv
from pipecat.services.llm_service import LLMService
from pipecat.processors.aggregators.llm_context import LLMContext, NOT_GIVEN
from pipecat.processors.frame_processor import FrameDirection
from pipecat.frames.frames import (
    Frame,
    LLMContextFrame,
    LLMFullResponseStartFrame,
    LLMFullResponseEndFrame,
    LLMTextFrame,
    FunctionCallFromLLM,
)
from http import HTTPStatus
from enum import Enum
import dashscope
from dashscope import Generation

load_dotenv()

CIRE_LOG_LEVEL = os.getenv("CIRE_LOG_LEVEL", "INFO")
logging.basicConfig(level="ERROR", format="%(asctime)s %(name)s %(levelname)s %(message)s")
logger = logging.getLogger("QwenLLMService")
logger.setLevel(CIRE_LOG_LEVEL)

class QwenLLMService(LLMService):

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "https://dashscope-intl.aliyuncs.com/api/v1",
        model: str = "qwen3.5-flash",
        **kwargs,
    ):
        super().__init__(**kwargs)

        self._api_key = api_key
        self._base_url = base_url
        self._model = model

        dashscope.api_key = self._api_key
        dashscope.base_http_api_url = self._base_url


    async def run_inference(self, context: LLMContext, max_tokens: int =None):

        logger.info("******************************************")
        logger.info("run_inference")
        logger.info("******************************************")

        adapter = self.get_llm_adapter()
        params = adapter.get_llm_invocation_params(context)
        messages = params["messages"]
        logger.info("messages")
        logger.info(messages)

        tools = params["tools"]
        logger.info("tools")
        logger.info(tools)

        response = Generation.call(
            model=self._model,
            messages=messages,
            tools=tools,
            result_format='message',
            stream=False,
            incremental_output=False,
            enable_thinking=False,
        )

        content = None
        if response.status_code == HTTPStatus.OK:
            output = response.get("output")
            if output:
                choices = output.get("choices")
                if choices:
                    choice = choices[0]
                    message = choice.get("message")
                    if message:
                        tool_calls = message.get("tool_calls")
                        if tool_calls:

                            function_calls = []

                            for tool_call in tool_calls:

                                try:

                                    tool_call_id = tool_call.get("id")
                                    function = tool_call.get("function")
                                    if function:
                                        name = function.get("name")
                                        arguments_json = function.get("arguments")
                                        arguments = json.loads(arguments_json)
                                        function_calls.append(
                                            FunctionCallFromLLM(
                                                context=context,
                                                tool_call_id=tool_call_id,
                                                function_name=name,
                                                arguments=arguments,
                                            )
                                        )

                                except Exception as e:
                                    logger.error(str(e))

                            await self.run_function_calls(function_calls)

                        else:
                            content = message.get("content")


        else:
            logger.error("run_inference error")
            logger.error(response.request_id)
            logger.error(response.status_code)
            logger.error(response.code)
            logger.error(response.message)

        return content


    async def _process_context(self, context: LLMContext):

        await self.push_frame(LLMFullResponseStartFrame())

        adapter = self.get_llm_adapter()
        params = adapter.get_llm_invocation_params(context)
        messages = params["messages"]
        tools = params["tools"]
        if tools == NOT_GIVEN:
            tools = []

        responses = Generation.call(
            model=self._model,
            base_url=self._base_url,
            messages=messages,
            tools=tools,
            result_format='message',
            stream=True,
            incremental_output=True,
            enable_thinking=False,
        )

        thinking = False
        contents = []
        functions = []

        for response in responses:
            output = response.get("output")
            if output:
                choices = output.get("choices")
                if choices:
                    for choice in choices:
                        finish_reason = choice.get("finish_reason")
                        message = choice.get("message")
                        if message:
                            reasoning_content = message.get("reasoning_content")
                            tool_calls = message.get("tool_calls")
                            content = message.get("content")
                            if reasoning_content:
                                if not thinking:
                                    logger.debug("<thinking>")
                                    thinking = True
                                logger.debug(reasoning_content)
                            elif tool_calls:
                                for tool_call in tool_calls:
                                    tool_call_id = tool_call.get("id")
                                    function = tool_call.get("function")
                                    if function:
                                        name = function.get("name")
                                        arguments = function.get("arguments")
                                        if name:
                                            functions.append({"tool_call_id":tool_call_id, "name":name, "arguments":arguments})
                                        elif arguments:
                                            functions[-1]["arguments"] += arguments
                            elif content:
                                if thinking:
                                    logger.debug("</thinking>\n")
                                    thinking = False
                                await self.push_frame(LLMTextFrame(content))
                            elif finish_reason:
                                pass
                            else:
                                logger.error("unexpected message")
                                logger.error(message)


        if functions:
            function_calls = []
            for function in functions:
                try:
                    tool_call_id = function.get("tool_call_id")
                    name = function.get("name")
                    arguments_json = function.get("arguments")
                    arguments = json.loads(arguments_json)
                    function_calls.append(
                        FunctionCallFromLLM(
                            context=context,
                            tool_call_id=tool_call_id,
                            function_name=name,
                            arguments=arguments,
                        )
                    )
                except Exception as e:
                    logger.error(str(e))

            await self.run_function_calls(function_calls)

        await self.push_frame(LLMFullResponseEndFrame())


    async def process_frame(self, frame: Frame, direction: FrameDirection):
        await super().process_frame(frame, direction)

        context = None
        if isinstance(frame, LLMContextFrame):
            context = frame.context
            await self._process_context(context)

        await self.push_frame(frame, direction)

