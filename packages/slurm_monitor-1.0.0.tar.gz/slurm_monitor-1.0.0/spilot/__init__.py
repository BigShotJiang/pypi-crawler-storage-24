"""
spilot - A simple Python CLI package
"""

__version__ = '1.0.0'