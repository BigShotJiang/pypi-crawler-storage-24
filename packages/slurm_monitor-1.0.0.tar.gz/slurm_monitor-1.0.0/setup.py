from setuptools import setup, find_packages

setup(
    name="slurm-monitor",
    version="1.0.0",
    packages=find_packages(),
    package_data={
        "slurm_monitor": ["style.css"],
    },
    entry_points={
        'console_scripts': [
            'slurm-monitor=slurm_monitor.cli:main',
        ],
    },
    install_requires=[
        "textual>=2.0.0",
    ],
    author="Saurabh Atreya",
    author_email="saurabh@atrey-a.com",
    description="A terminal-based SLURM job monitoring utility that provides a clean, interactive TUI for viewing and managing jobs on HPC clusters.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/atrey-a/spilot",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8.1",
)