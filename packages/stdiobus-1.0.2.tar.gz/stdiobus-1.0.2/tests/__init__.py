"""Tests for stdiobus."""
