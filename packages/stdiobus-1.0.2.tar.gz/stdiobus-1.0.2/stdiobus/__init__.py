"""
stdiobus - Python SDK for stdio_bus AI agent transport layer.

Example:
    >>> from stdiobus import StdioBus
    >>> 
    >>> bus = StdioBus(config_path='./config.json')
    >>> bus.start()
    >>> result = bus.request('tools/list', {})
    >>> bus.stop()

Async Example:
    >>> from stdiobus import AsyncStdioBus
    >>> 
    >>> async with AsyncStdioBus(config_path='./config.json') as bus:
    ...     result = await bus.request('tools/list', {})
"""

from stdiobus.client import StdioBus, AsyncStdioBus
from stdiobus.types import BusState, BackendMode, BusStats
from stdiobus.errors import (
    StdioBusError,
    InvalidArgumentError,
    InvalidStateError,
    TimeoutError,
    CancelledError,
    TransportError,
    NegotiationFailedError,
    PolicyDeniedError,
    UnavailableError,
    ResourceExhaustedError,
    NotSupportedError,
    InternalError,
)

__version__ = "0.1.0"
__all__ = [
    # Main classes
    "StdioBus",
    "AsyncStdioBus",
    # Types
    "BusState",
    "BackendMode",
    "BusStats",
    # Errors
    "StdioBusError",
    "InvalidArgumentError",
    "InvalidStateError",
    "TimeoutError",
    "CancelledError",
    "TransportError",
    "NegotiationFailedError",
    "PolicyDeniedError",
    "UnavailableError",
    "ResourceExhaustedError",
    "NotSupportedError",
    "InternalError",
]
