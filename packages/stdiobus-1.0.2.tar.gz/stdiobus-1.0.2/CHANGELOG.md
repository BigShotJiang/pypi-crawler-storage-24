# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.0] - 2026-03-23

### Added
- Initial stable release
- `AsyncStdioBus` - async client with context manager support
- `StdioBus` - synchronous wrapper
- Docker backend for cross-platform support
- Native backend (optional) for Linux/macOS via cffi
- `generate_client_session_id()` for routing
- Full type hints and py.typed marker
- Comprehensive error types

### Features
- Automatic backend selection (native → docker)
- Request/response correlation
- Message handlers for notifications
- Runtime statistics
- Graceful shutdown with timeout

### Backends
- Docker: runs stdio_bus in container, communicates via TCP
- Native: direct FFI to libstdio_bus.a (requires build)
