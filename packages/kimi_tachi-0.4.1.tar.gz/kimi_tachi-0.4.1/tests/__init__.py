"""kimi-tachi test suite"""
