from floyd.domain.exceptions.domain_exception import DomainException


class UnexpectedException(DomainException):
    def __init__(self, message: str) -> None:
        super().__init__(message)
