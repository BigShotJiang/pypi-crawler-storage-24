"""Adapters layer - Infrastructure implementations."""
