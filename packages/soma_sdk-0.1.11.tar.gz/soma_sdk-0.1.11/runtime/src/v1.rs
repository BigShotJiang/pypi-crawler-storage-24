// Copyright (c) Soma Contributors
// SPDX-License-Identifier: Apache-2.0

use std::sync::Arc;

use aes::Aes256;
use async_trait::async_trait;
use blobs::BlobPath;
use blobs::downloader::BlobDownloader;
use blobs::loader::BlobLoader;
use blobs::progress::ProgressFactory;
use burn::Tensor;
use burn::prelude::Backend;
use ctr::Ctr128BE;
use ctr::cipher::{KeyIvInit, StreamCipher};
use models::cosine_distance::cosine_distance;
use models::select_best::select_best_model;
use models::{ModelAPI, ModelOutput};
use object_store::{ObjectStore, PutPayload};
use tokio::task::JoinSet;
use types::committee::EpochId;
use types::error::{BlobError, RuntimeError, RuntimeResult};
use types::metadata::{Manifest, ManifestAPI, MetadataAPI};

use crate::{CompetitionInput, CompetitionOutput, ManifestCompetitionInput, RuntimeAPI};

/// Decrypt data in-place with AES-256-CTR (zero IV).
fn decrypt_aes256_ctr(data: &mut [u8], key: &[u8; 32]) {
    let iv = [0u8; 16];
    let mut cipher = Ctr128BE::<Aes256>::new(key.into(), &iv.into());
    cipher.apply_keystream(data);
}

pub struct RuntimeV1<B, S, D, M>
where
    B: Backend,
    S: ObjectStore + BlobLoader,
    D: BlobDownloader<Store = S>,
    M: ModelAPI<Backend = B>,
{
    store: Arc<S>,
    downloader: Arc<D>,
    epoch: EpochId,
    device: B::Device,
    model: Arc<M>,
    progress: Option<Arc<dyn ProgressFactory>>,
}

impl<B, S, D, M> RuntimeV1<B, S, D, M>
where
    B: Backend,
    S: ObjectStore + BlobLoader,
    D: BlobDownloader<Store = S>,
    M: ModelAPI<Backend = B>,
{
    pub fn new(
        store: Arc<S>,
        downloader: Arc<D>,
        epoch: EpochId,
        device: B::Device,
        model: Arc<M>,
        progress: Option<Arc<dyn ProgressFactory>>,
    ) -> Self {
        Self { store, downloader, epoch, device, model, progress }
    }
}

#[async_trait]
impl<B, S, D, M> RuntimeAPI for RuntimeV1<B, S, D, M>
where
    B: Backend,
    S: ObjectStore + BlobLoader,
    D: BlobDownloader<Store = S>,
    M: ModelAPI<Backend = B>,
{
    async fn competition(&self, input: CompetitionInput) -> RuntimeResult<CompetitionOutput> {
        let data_buffer =
            self.store.get_buffer(input.data()).await.map_err(RuntimeError::BlobError)?;
        let buffer = Arc::from(data_buffer.as_ref());

        let dataloader = self.model.dataloader(buffer).await;

        let mut outputs = Vec::with_capacity(input.models.len());
        for model_path in &input.models {
            let safetensor_store =
                self.store.safetensor_store(model_path).await.map_err(RuntimeError::BlobError)?;
            let output: ModelOutput<B> = self
                .model
                .eval(dataloader.clone(), safetensor_store, input.seed())
                .await
                .map_err(|e| RuntimeError::ModelError(e.to_string()))?;
            outputs.push(output);
        }

        let best_idx = select_best_model(&outputs)
            .ok_or(RuntimeError::ValidationError("select best model returned None".to_string()))?;
        let best = &outputs[best_idx];

        let target: Tensor<B, 1> = Tensor::from_data(input.target, &self.device);
        let distance = cosine_distance(best.embedding.clone(), target);
        let loss_score = best.loss.clone();

        Ok(CompetitionOutput {
            winner: best_idx,
            loss_score: loss_score.into_data_async().await,
            embedding: best.embedding.clone().into_data_async().await,
            distance: distance.into_data_async().await,
        })
    }

    async fn download_manifest(&self, manifest: &Manifest, path: &BlobPath) -> RuntimeResult<()> {
        self.downloader
            .download(manifest, path.clone(), None)
            .await
            .map_err(RuntimeError::BlobError)?;
        Ok(())
    }

    async fn manifest_competition(
        &self,
        input: ManifestCompetitionInput,
    ) -> RuntimeResult<CompetitionOutput> {
        let data_path = BlobPath::Data(self.epoch, input.data().metadata().checksum());

        let mut model_paths = Vec::with_capacity(input.models().len());
        for manifest in input.models() {
            model_paths.push(BlobPath::Weights(self.epoch, manifest.metadata().checksum()));
        }

        let mut join_set = JoinSet::new();

        let data_progress =
            self.progress.as_ref().map(|f| f.create("data", input.data().metadata().size() as u64));
        let downloader = self.downloader.clone();
        let data_manifest = input.data().clone();
        let data_path_clone = data_path.clone();
        join_set.spawn(async move {
            downloader.download(&data_manifest, data_path_clone, data_progress).await
        });

        for (i, manifest) in input.models().iter().enumerate() {
            let model_progress = self
                .progress
                .as_ref()
                .map(|f| f.create(&format!("model {}", i), manifest.metadata().size() as u64));
            let downloader = self.downloader.clone();
            let manifest = manifest.clone();
            let path = model_paths[i].clone();
            join_set
                .spawn(async move { downloader.download(&manifest, path, model_progress).await });
        }

        while let Some(result) = join_set.join_next().await {
            result
                .map_err(|e| RuntimeError::ModelError(e.to_string()))?
                .map_err(RuntimeError::BlobError)?;
        }

        // Decrypt model weights if decryption keys are provided.
        // Write decrypted data to a separate path so the encrypted cache stays intact.
        let mut competition_paths = model_paths.clone();
        for (i, key) in input.model_keys().iter().enumerate() {
            if let Some(key) = key {
                let encrypted_path = &model_paths[i];
                let checksum = input.models()[i].metadata().checksum();
                let decrypted_path = BlobPath::DecryptedWeights(self.epoch, checksum);

                // Skip if already decrypted and cached.
                if self.store.head(&decrypted_path.path()).await.is_ok() {
                    competition_paths[i] = decrypted_path;
                    continue;
                }

                let get_result = self
                    .store
                    .get(&encrypted_path.path())
                    .await
                    .map_err(|e| RuntimeError::BlobError(BlobError::ObjectStoreError(e)))?;
                let encrypted = get_result
                    .bytes()
                    .await
                    .map_err(|e| RuntimeError::BlobError(BlobError::ObjectStoreError(e)))?;
                let mut decrypted = encrypted.to_vec();
                decrypt_aes256_ctr(&mut decrypted, key);
                self.store
                    .put(&decrypted_path.path(), PutPayload::from(decrypted))
                    .await
                    .map_err(|e| RuntimeError::BlobError(BlobError::ObjectStoreError(e)))?;
                competition_paths[i] = decrypted_path;
            }
        }

        let competition_input = CompetitionInput::new(
            data_path,
            competition_paths,
            input.target().clone(),
            input.seed(),
        );
        self.competition(competition_input).await
    }
}
