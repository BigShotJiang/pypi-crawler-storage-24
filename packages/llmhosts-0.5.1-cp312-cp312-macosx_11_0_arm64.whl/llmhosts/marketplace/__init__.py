"""Marketplace router — node selection engine for Phase 5.

Fetches nodes from a configurable catalog URL (e.g. GET /api/marketplace/nodes),
filters by model availability, ranks by price then latency, and registers
remote backends with the dispatcher using rank as priority.
Catalog response may include reputation_score (0-100) per node for future ranking.

ReputationEngine (Phase 5B, issue #290) provides weighted scoring from ProbeStore
history (uptime, latency, success rate, streak).
"""

from llmhosts.marketplace.refresh import MarketplaceRefresher
from llmhosts.marketplace.reputation import (
    TIER_MIN_SCORES,
    DeviceScore,
    ReputationEngine,
    compute_reputation_score,
    min_score_for_tier,
    reputation_score_from_node,
    reputation_score_with_uptime,
    reputation_tier,
)
from llmhosts.marketplace.router import (
    fetch_nodes,
    filter_by_model,
    load_and_register,
    rank_nodes,
)

__all__ = [
    "TIER_MIN_SCORES",
    "DeviceScore",
    "MarketplaceRefresher",
    "ReputationEngine",
    "compute_reputation_score",
    "fetch_nodes",
    "filter_by_model",
    "load_and_register",
    "min_score_for_tier",
    "rank_nodes",
    "reputation_score_from_node",
    "reputation_score_with_uptime",
    "reputation_tier",
]
