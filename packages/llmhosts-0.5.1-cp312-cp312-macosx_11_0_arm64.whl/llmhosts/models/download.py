"""Model download from HuggingFace Hub with progress and verification."""

from __future__ import annotations

import logging
import os

from llmhosts.models.registry import MODELS
from llmhosts.models.registry import models_dir as _default_models_dir

logger = logging.getLogger(__name__)


def ensure_models_dir(path: str | None = None) -> str:
    """Create the models directory if it doesn't exist."""
    d = path or _default_models_dir()
    os.makedirs(d, exist_ok=True)
    return d


def is_downloaded(name: str, models_dir: str | None = None) -> bool:
    """Check if a model's GGUF file exists locally."""
    info = MODELS.get(name)
    if info is None:
        return False
    d = models_dir or _default_models_dir()
    return os.path.exists(os.path.join(d, info["file"]))


def list_local_models(models_dir: str | None = None) -> list[str]:
    """List model names whose GGUF files are present locally."""
    d = models_dir or _default_models_dir()
    if not os.path.exists(d):
        return []
    local_files = set(os.listdir(d))
    return [name for name, info in MODELS.items() if info["file"] in local_files]


def download_model(name: str, models_dir: str | None = None) -> str:
    """Download a GGUF model from HuggingFace Hub.

    Returns the local path to the downloaded file. Raises ValueError for
    unknown models, RuntimeError if huggingface_hub is not installed.
    """
    info = MODELS.get(name)
    if info is None:
        raise ValueError(f"Unknown model: {name}")

    d = ensure_models_dir(models_dir)
    dest = os.path.join(d, info["file"])

    if os.path.exists(dest):
        logger.info("Model already downloaded: %s", dest)
        return dest

    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        raise RuntimeError(
            "huggingface_hub is required for model downloads. Install with: pip install llmhosts[smart]"
        ) from None

    logger.info("Downloading %s from %s...", info["file"], info["repo"])
    path = hf_hub_download(  # nosec B615 -- revision explicitly pinned to "main"
        repo_id=info["repo"],
        filename=info["file"],
        local_dir=d,
        revision="main",
    )

    # Also download tokenizer for the model
    try:
        hf_hub_download(  # nosec B615 -- revision explicitly pinned to "main"
            repo_id=info["tokenizer_repo"],
            filename="tokenizer.json",
            local_dir=d,
            revision="main",
        )
        logger.info("Tokenizer downloaded for %s", name)
    except Exception as exc:
        logger.warning("Could not download tokenizer for %s: %s", name, exc)

    return path
