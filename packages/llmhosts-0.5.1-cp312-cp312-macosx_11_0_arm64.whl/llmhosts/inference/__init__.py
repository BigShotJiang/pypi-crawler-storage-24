"""LLMHosts Core inference engine — Python wrappers."""
