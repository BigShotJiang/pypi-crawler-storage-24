"""LLMHosts Relay tunnel provider.

Primary tunnel provider: connects to the LLMHosts relay server via WebSocket
using the Rust ``_llmhosts.relay`` extension (pyo3 + maturin). Falls back gracefully
if the Rust extension is not built — the provider simply won't appear in the
detector cascade.

Protocol stack (M1 = WSS only, future milestones add layers):
  WSS → Noise NK encryption (M2) → yamux multiplexing (M3) → HTTP forwarding
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from llmhosts.tunnel.models import TunnelProvider, TunnelStatus

logger = logging.getLogger(__name__)

# --- Rust extension import (graceful degradation) --------------------------

RELAY_AVAILABLE: bool = False
_RelayClient: type | None = None
RELAY_VERSION: str = "0.0.0"

try:
    from _llmhosts import relay as _relay_core_mod  # type: ignore[import]

    _RelayClient = _relay_core_mod.RelayClient
    RELAY_VERSION = _relay_core_mod.RELAY_VERSION
    RELAY_AVAILABLE = True
    logger.debug("Rust relay core loaded (_llmhosts.relay %s)", RELAY_VERSION)
except ImportError:
    # Fallback: try standalone module (development mode with individual maturin develop)
    try:
        import _relay_core  # type: ignore[import]

        _RelayClient = _relay_core.RelayClient
        RELAY_VERSION = _relay_core.RELAY_VERSION
        RELAY_AVAILABLE = True
        logger.debug("Rust relay core loaded (standalone _relay_core %s)", RELAY_VERSION)
    except ImportError:
        logger.debug("Rust relay core not available — relay provider disabled")

# Default relay server URL
DEFAULT_RELAY_URL = "wss://llmhosts.com/api/relay/connect"


class RelayTunnel:
    """Manage a connection to the LLMHosts relay server.

    Interface: ``start()``, ``stop()``, ``status()``, ``get_url()``.
    """

    def __init__(self) -> None:
        self._client: object | None = None  # _relay_core.RelayClient instance
        self._active: bool = False
        self._url: str | None = None
        self._started_at: datetime | None = None
        self._port: int = 4000
        self._relay_url: str = DEFAULT_RELAY_URL
        self._device_token: str | None = None

    async def start(
        self,
        port: int = 4000,
        relay_url: str | None = None,
        device_token: str | None = None,
    ) -> TunnelStatus:
        """Connect to the relay server.

        Args:
            port: Local port that the FastAPI proxy listens on.
            relay_url: WebSocket URL of the relay server.
            device_token: Authentication token for this device.
        """
        self._port = port
        self._relay_url = relay_url or DEFAULT_RELAY_URL
        self._device_token = device_token

        if not RELAY_AVAILABLE or _RelayClient is None:
            return TunnelStatus(
                provider=TunnelProvider.RELAY,
                active=False,
                local_port=port,
                error="Rust relay core not available (install with maturin develop)",
            )

        if not device_token:
            return TunnelStatus(
                provider=TunnelProvider.RELAY,
                active=False,
                local_port=port,
                error="No relay device token configured",
            )

        try:
            self._client = _RelayClient(self._relay_url, device_token, port)
            await self._client.connect()  # type: ignore[union-attr]

            if self._client.is_connected:  # type: ignore[union-attr]
                self._active = True
                self._started_at = datetime.now(tz=timezone.utc)
                # The relay URL is the public endpoint for this device
                self._url = self._relay_url

                logger.info(
                    "Relay tunnel connected: %s (port %d, version %s)",
                    self._relay_url,
                    port,
                    RELAY_VERSION,
                )

                return TunnelStatus(
                    provider=TunnelProvider.RELAY,
                    active=True,
                    url=self._url,
                    local_port=port,
                    started_at=self._started_at,
                )

            return TunnelStatus(
                provider=TunnelProvider.RELAY,
                active=False,
                local_port=port,
                error="Relay connection established but client reports disconnected",
            )

        except Exception as exc:
            logger.error("Relay connection failed: %s", exc)
            self._active = False
            self._client = None
            return TunnelStatus(
                provider=TunnelProvider.RELAY,
                active=False,
                local_port=port,
                error=f"Relay connection failed: {exc}",
            )

    async def stop(self) -> None:
        """Disconnect from the relay server."""
        if self._client is not None:
            try:
                await self._client.disconnect()  # type: ignore[attr-defined]
            except Exception as exc:
                logger.warning("Error disconnecting relay: %s", exc)

        self._active = False
        self._client = None
        self._url = None
        self._started_at = None
        logger.info("Relay tunnel stopped")

    async def status(self) -> TunnelStatus:
        """Check relay connection status."""
        if self._client is not None and self._active:
            try:
                connected = self._client.is_connected  # type: ignore[attr-defined]
            except Exception:
                connected = False

            if connected:
                return TunnelStatus(
                    provider=TunnelProvider.RELAY,
                    active=True,
                    url=self._url,
                    local_port=self._port,
                    started_at=self._started_at,
                )

            # Client reports disconnected — connection was lost
            self._active = False
            return TunnelStatus(
                provider=TunnelProvider.RELAY,
                active=False,
                local_port=self._port,
                error="Relay connection lost",
            )

        return TunnelStatus(
            provider=TunnelProvider.RELAY,
            active=False,
            local_port=self._port,
        )

    async def get_url(self) -> str | None:
        """Get the relay URL."""
        return self._url

    @property
    def bytes_relayed(self) -> int:
        """Total bytes relayed through the connection."""
        if self._client is not None:
            try:
                return int(self._client.bytes_relayed)  # type: ignore[attr-defined]
            except Exception:
                return 0
        return 0

    @property
    def uptime_seconds(self) -> float:
        """Connection uptime in seconds."""
        if self._client is not None:
            try:
                return float(self._client.uptime_seconds)  # type: ignore[attr-defined]
            except Exception:
                return 0.0
        return 0.0
