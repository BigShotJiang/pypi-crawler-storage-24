"""Detect available tunnel providers on the system."""

from __future__ import annotations

import logging

from llmhosts.tunnel.models import TunnelProvider

logger = logging.getLogger(__name__)


class TunnelDetector:
    """Detect which tunnel providers are available."""

    @staticmethod
    async def detect() -> list[TunnelProvider]:
        """Return available providers in priority order.

        Currently only checks for the built-in LLMHosts Relay.
        """
        providers: list[TunnelProvider] = []

        if TunnelDetector.check_relay():
            providers.append(TunnelProvider.RELAY)

        return providers

    @staticmethod
    def check_relay() -> bool:
        """Check if the Rust relay extension is available."""
        from llmhosts.tunnel.relay import RELAY_AVAILABLE

        return RELAY_AVAILABLE
