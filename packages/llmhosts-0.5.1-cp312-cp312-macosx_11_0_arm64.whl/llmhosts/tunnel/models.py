"""Pydantic v2 models for tunnel configuration and status."""

from __future__ import annotations

from datetime import datetime  # noqa: TC003 — Pydantic needs this at runtime
from enum import Enum

from pydantic import BaseModel, Field


class TunnelProvider(str, Enum):
    """Supported tunnel providers."""

    RELAY = "relay"
    NONE = "none"


class TunnelStatus(BaseModel):
    """Current status of a tunnel connection."""

    provider: TunnelProvider = TunnelProvider.NONE
    active: bool = False
    url: str | None = None
    local_port: int = 4000
    started_at: datetime | None = None
    error: str | None = None
    pid: int | None = None

    @property
    def display_url(self) -> str:
        """URL suitable for display, or a placeholder."""
        return self.url or "(not connected)"


class TunnelConfig(BaseModel):
    """User-facing tunnel configuration."""

    port: int = Field(default=4000, ge=1, le=65535)
    auth_required: bool = True
    relay_url: str | None = None  # WebSocket URL for LLMHosts Relay
    relay_token: str | None = None  # Device token for relay authentication
