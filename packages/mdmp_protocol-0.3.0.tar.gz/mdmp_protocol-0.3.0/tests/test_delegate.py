from __future__ import annotations

from pathlib import Path
import json

import pandas as pd
from typer.testing import CliRunner

from mdmp_core.cli import app
from mdmp_core.crypto import MDMPSigner, generate_keypair
from mdmp_core.delegate import DelegateConstraints, DelegateIssuer, DelegateSigner, DelegateVerifier
from mdmp_core.fingerprint import file_sha256


def _write_dataset(path: Path, values: list[float]) -> None:
    pd.DataFrame(
        {
            "timestamp": [f"2026-03-08T00:{idx:02d}:00Z" for idx in range(len(values))],
            "glucose": values,
        }
    ).to_csv(path, index=False)


def test_delegate_issue_sign_verify_chain(tmp_path: Path) -> None:
    root_keys = generate_keypair(output_dir=tmp_path / "root")
    delegate_keys = generate_keypair(output_dir=tmp_path / "delegate")
    data = tmp_path / "data.csv"
    _write_dataset(data, [110.0, 111.0, 112.0])

    issuer = DelegateIssuer(MDMPSigner(root_keys["private_key"]))
    cert = issuer.issue(
        delegate_id="uzleuven-001",
        delegate_name="UZ Leuven Research Division",
        delegate_pubkey_path=delegate_keys["public_key"],
        allowed_grades=["draft", "research_grade"],
        constraints=DelegateConstraints(
            require_consent_field=True,
            allowed_flavors=["health"],
            allowed_grades=["draft", "research_grade"],
        ),
    )

    card = {
        "grade": "research_grade",
        "flavor": "health",
        "consent": {"ai_training_allowed": True},
        "dataset_fingerprint": f"sha256:{file_sha256(data)}",
    }
    signed = DelegateSigner(delegate_keys["private_key"], cert).sign_card(card, default_expires_days=180)
    result = DelegateVerifier(root_keys["public_key"]).verify(signed, cert, dataset_path=data)

    assert result["valid"] is True
    assert result["delegate_id"] == "uzleuven-001"
    assert all(step["valid"] for step in result["chain"])


def test_delegate_issuer_rejects_non_delegable_grades(tmp_path: Path) -> None:
    root_keys = generate_keypair(output_dir=tmp_path / "root")
    delegate_keys = generate_keypair(output_dir=tmp_path / "delegate")
    issuer = DelegateIssuer(MDMPSigner(root_keys["private_key"]))

    try:
        issuer.issue(
            delegate_id="org-1",
            delegate_name="Org 1",
            delegate_pubkey_path=delegate_keys["public_key"],
            allowed_grades=["research_grade", "clinical_grade"],
        )
        assert False, "Expected ValueError"
    except ValueError as exc:
        assert "non-delegable grade" in str(exc)


def test_delegate_signer_blocks_disallowed_grade(tmp_path: Path) -> None:
    root_keys = generate_keypair(output_dir=tmp_path / "root")
    delegate_keys = generate_keypair(output_dir=tmp_path / "delegate")
    issuer = DelegateIssuer(MDMPSigner(root_keys["private_key"]))
    cert = issuer.issue(
        delegate_id="org-2",
        delegate_name="Org 2",
        delegate_pubkey_path=delegate_keys["public_key"],
        allowed_grades=["draft"],
    )
    signer = DelegateSigner(delegate_keys["private_key"], cert)
    try:
        signer.sign_card({"grade": "research_grade"})
        assert False, "Expected PermissionError"
    except PermissionError as exc:
        assert "constraints violation" in str(exc)


def test_cli_delegate_flow(tmp_path: Path) -> None:
    runner = CliRunner()
    root_keys = generate_keypair(output_dir=tmp_path / "root")
    delegate_keys = generate_keypair(output_dir=tmp_path / "delegate")
    cert_path = tmp_path / "cert.json"
    report = tmp_path / "report.json"
    signed_path = tmp_path / "signed.mdmp"
    verify_json = tmp_path / "verify.json"
    dataset = tmp_path / "data.csv"

    _write_dataset(dataset, [109.0, 112.0])
    report.write_text(
        json.dumps(
            {
                "grade": "research_grade",
                "flavor": "health",
                "consent": {"ai_training_allowed": True},
                "dataset_fingerprint": f"sha256:{file_sha256(dataset)}",
            }
        ),
        encoding="utf-8",
    )

    delegate = runner.invoke(
        app,
        [
            "authority",
            "delegate",
            "--delegate-id",
            "uz-001",
            "--delegate-name",
            "UZ Research",
            "--delegate-pubkey",
            str(delegate_keys["public_key"]),
            "--grades",
            "draft",
            "--grades",
            "research_grade",
            "--require-consent",
            "--flavors",
            "health",
            "--privkey",
            str(root_keys["private_key"]),
            "--output",
            str(cert_path),
        ],
    )
    assert delegate.exit_code == 0

    sign = runner.invoke(
        app,
        [
            "delegate-sign",
            str(report),
            "--privkey",
            str(delegate_keys["private_key"]),
            "--cert",
            str(cert_path),
            "--output",
            str(signed_path),
        ],
    )
    assert sign.exit_code == 0

    verify = runner.invoke(
        app,
        [
            "verify",
            str(signed_path),
            "--cert",
            str(cert_path),
            "--public-key",
            str(root_keys["public_key"]),
            "--dataset",
            str(dataset),
            "--output-json",
            str(verify_json),
        ],
    )
    assert verify.exit_code == 0
    payload = json.loads(verify_json.read_text(encoding="utf-8"))
    assert payload["valid"] is True
