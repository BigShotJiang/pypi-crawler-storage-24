from __future__ import annotations

from copy import deepcopy
from pathlib import Path

from typer.testing import CliRunner

from mdmp_core.bundle import build_audit_bundle, verify_bundle_integrity
from mdmp_core.cli import app
from mdmp_core.crypto import MDMPSigner, MDMPVerifier, generate_keypair, normalize_unsigned_payload
from mdmp_core.delegate import DelegateIssuer, DelegateSigner, DelegateVerifier
from mdmp_core.policy import PolicySpec, apply_policy_effects, evaluate_policy
from mdmp_core.trust import trust_add_key, trust_init, trust_revoke_delegate, trust_revoke_key


def test_trust_store_key_rotation_and_revocation(tmp_path: Path) -> None:
    trust_store = tmp_path / "trust.json"
    key_v1 = generate_keypair(output_dir=tmp_path / "keys_v1")
    key_v2 = generate_keypair(output_dir=tmp_path / "keys_v2")

    trust_init(trust_store, key_id="root-v1", public_key_path=key_v1["public_key"], set_active=True)
    trust_add_key(trust_store, key_id="root-v2", public_key_path=key_v2["public_key"], set_active=True)

    payload = {"grade": "research_grade", "dataset_fingerprint": "sha256:abc123"}
    signed_v1 = MDMPSigner(key_v1["private_key"], key_id="root-v1").sign_card(payload)
    signed_v2 = MDMPSigner(key_v2["private_key"], key_id="root-v2").sign_card(payload)

    verifier = MDMPVerifier(trust_store_path=trust_store)
    assert verifier.verify(signed_v1)["valid"] is True
    assert verifier.verify(signed_v2)["valid"] is True

    trust_revoke_key(trust_store, key_id="root-v1", reason="compromised")
    revoked_result = verifier.verify(signed_v1)
    assert revoked_result["valid"] is False
    assert revoked_result["error"] == "key_revoked"


def test_delegate_revocation_is_enforced_with_trust_store(tmp_path: Path) -> None:
    trust_store = tmp_path / "trust.json"
    root_keys = generate_keypair(output_dir=tmp_path / "root")
    delegate_keys = generate_keypair(output_dir=tmp_path / "delegate")
    trust_init(trust_store, key_id="root-v1", public_key_path=root_keys["public_key"], set_active=True)

    issuer = DelegateIssuer(MDMPSigner(root_keys["private_key"], key_id="root-v1"))
    cert = issuer.issue(
        delegate_id="hospital-a",
        delegate_name="Hospital A",
        delegate_pubkey_path=delegate_keys["public_key"],
        allowed_grades=["draft", "research_grade"],
    )
    signed_card = DelegateSigner(delegate_keys["private_key"], cert).sign_card({"grade": "research_grade"})

    verifier = DelegateVerifier(trust_store_path=trust_store)
    assert verifier.verify(signed_card, cert)["valid"] is True

    trust_revoke_delegate(trust_store, delegate_id="hospital-a", reason="offboarded")
    revoked_result = verifier.verify(signed_card, cert)
    assert revoked_result["valid"] is False
    assert revoked_result["error"] == "delegate_revoked"


def test_policy_engine_downgrades_on_failure() -> None:
    payload = {
        "effective_grade": "clinical_grade",
        "consent_verified": True,
        "staleness": {"status": "stale"},
        "expired": False,
        "consent_context": {"jurisdiction": "GDPR"},
    }
    policy = PolicySpec(
        min_grade="research_grade",
        require_consent_verified=True,
        require_not_stale=True,
        require_not_expired=True,
        allowed_jurisdictions=("GDPR",),
        downgrade_grade_on_fail="draft",
    )
    evaluation = evaluate_policy(payload, policy)
    assert evaluation["passed"] is False
    grade, reason = apply_policy_effects(payload, evaluation, policy)
    assert grade == "draft"
    assert reason.startswith("policy_failed:")


def test_signed_audit_bundle_verification_and_tamper_detection(tmp_path: Path) -> None:
    keys = generate_keypair(output_dir=tmp_path / "keys")
    report = {
        "protocol_version": "1.0",
        "grade": "research_grade",
        "grade_reason": "medium_validation_score",
        "dataset_fingerprint_sha256": "deadbeef",
        "contract_fingerprint_sha256": "cafebabe",
        "compliance_score": 85.0,
        "consent_verified": True,
    }
    bundle = build_audit_bundle(report=report, validated_by="unit-test")
    signed_bundle = MDMPSigner(keys["private_key"]).sign_card(bundle)

    verify = MDMPVerifier(keys["public_key"]).verify(signed_bundle)
    assert verify["valid"] is True
    integrity = verify_bundle_integrity(normalize_unsigned_payload(signed_bundle))
    assert integrity["passed"] is True

    tampered = deepcopy(signed_bundle)
    tampered["sources"]["report"]["grade"] = "draft"
    tampered_verify = MDMPVerifier(keys["public_key"]).verify(tampered)
    assert tampered_verify["valid"] is False
    tampered_integrity = verify_bundle_integrity(normalize_unsigned_payload(tampered))
    assert tampered_integrity["passed"] is False


def test_cli_conformance_and_policy_eval(tmp_path: Path) -> None:
    runner = CliRunner()
    conformance_out = tmp_path / "conformance.json"
    policy_file = tmp_path / "policy.yaml"
    report_file = tmp_path / "report.json"
    policy_eval_out = tmp_path / "policy_eval.json"

    run_conf = runner.invoke(
        app,
        [
            "conformance",
            "--workdir",
            str(tmp_path / "work"),
            "--output-json",
            str(conformance_out),
            "--strict",
        ],
    )
    assert run_conf.exit_code == 0
    assert conformance_out.is_file()

    gen_policy = runner.invoke(app, ["policy-template", "--output", str(policy_file)])
    assert gen_policy.exit_code == 0

    report_file.write_text(
        '{"effective_grade":"research_grade","consent_verified":true,"staleness":{"status":"valid"},"expired":false,"consent_context":{"jurisdiction":"GDPR"}}',
        encoding="utf-8",
    )
    eval_policy = runner.invoke(
        app,
        ["policy-eval", str(policy_file), str(report_file), "--output-json", str(policy_eval_out)],
    )
    assert eval_policy.exit_code == 0
    assert policy_eval_out.is_file()
