from __future__ import annotations

from pathlib import Path
import json

import pandas as pd
from typer.testing import CliRunner

from mdmp_core.cli import app
from mdmp_core.crypto import MDMPSigner, MDMPVerifier, generate_keypair
from mdmp_core.fingerprint import file_sha256


def _write_dataset(path: Path, values: list[float]) -> None:
    pd.DataFrame(
        {
            "timestamp": [f"2026-03-08T00:{idx:02d}:00Z" for idx in range(len(values))],
            "glucose": values,
        }
    ).to_csv(path, index=False)


def test_sign_and_verify_roundtrip(tmp_path: Path) -> None:
    keys = generate_keypair(output_dir=tmp_path)
    data = tmp_path / "data.csv"
    _write_dataset(data, [110.0, 112.0, 113.0])
    payload = {
        "grade": "clinical_grade",
        "dataset_fingerprint": f"sha256:{file_sha256(data)}",
    }

    signed = MDMPSigner(keys["private_key"]).sign_card(payload, expires_days=365)
    result = MDMPVerifier(keys["public_key"]).verify(signed, dataset_path=data)

    assert result["valid"] is True
    assert result["tampered"] is False
    assert result["fingerprint_matches"] is True


def test_tamper_detection_fails_signature(tmp_path: Path) -> None:
    keys = generate_keypair(output_dir=tmp_path)
    signed = MDMPSigner(keys["private_key"]).sign_card({"grade": "draft"})
    signed["grade"] = "clinical_grade"

    result = MDMPVerifier(keys["public_key"]).verify(signed)
    assert result["valid"] is False
    assert result["tampered"] is True


def test_cli_authority_sign_and_verify(tmp_path: Path) -> None:
    runner = CliRunner()
    keys_dir = tmp_path / "keys"
    report = tmp_path / "report.json"
    signed_path = tmp_path / "report.signed.mdmp"
    verify_json = tmp_path / "verify.json"
    dataset = tmp_path / "data.csv"

    _write_dataset(dataset, [110.0, 111.0])
    report.write_text(
        json.dumps(
            {
                "grade": "clinical_grade",
                "dataset_fingerprint": f"sha256:{file_sha256(dataset)}",
            }
        ),
        encoding="utf-8",
    )

    keygen = runner.invoke(app, ["authority", "keygen", "--output-dir", str(keys_dir)])
    assert keygen.exit_code == 0
    priv = keys_dir / "mdmp_private_v1.pem"
    pub = keys_dir / "mdmp_pub_v1.pem"
    assert priv.is_file()
    assert pub.is_file()

    sign = runner.invoke(
        app,
        [
            "authority",
            "sign",
            str(report),
            "--privkey",
            str(priv),
            "--output",
            str(signed_path),
        ],
    )
    assert sign.exit_code == 0

    verify = runner.invoke(
        app,
        [
            "verify",
            str(signed_path),
            "--public-key",
            str(pub),
            "--dataset",
            str(dataset),
            "--output-json",
            str(verify_json),
        ],
    )
    assert verify.exit_code == 0
    payload = json.loads(verify_json.read_text(encoding="utf-8"))
    assert payload["valid"] is True
