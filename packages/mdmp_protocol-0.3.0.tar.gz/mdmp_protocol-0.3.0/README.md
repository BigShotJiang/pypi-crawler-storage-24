# MDMP

MDMP is an open protocol and CLI for dataset quality, provenance, and offline trust verification.

Tagline: **Know what your AI learned from.**

## What You Get

- Contract-based validation (`schema`, ranges, consent metadata)
- Deterministic grading (`draft`, `research_grade`, `clinical_grade`)
- Dataset fingerprints (`sha256:...`) with expiry/staleness checks
- Lineage cards for model-to-dataset traceability
- Offline signed artifacts (Ed25519), with optional delegated signing
- Key rotation + revocation trust store for offline verification
- Policy engine to enforce grade/consent/staleness rules
- Conformance suite to self-test MDMP core behavior
- Audit-ready JSON + HTML outputs

## Start In 2 Minutes

Always use a virtual environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
pip install -e .
```

Run the shortest working flow:

```bash
mdmp init --flavor health --output contracts/mdmp_contract.yaml
mdmp validate contracts/mdmp_contract.yaml data/demo_cgm.csv --output-json results/mdmp_report.json
mdmp report results/mdmp_report.json --output-html results/mdmp_dashboard.html
```

## Core Command Groups

Validation and reports:

```bash
mdmp validate contracts/mdmp_contract.yaml data/demo_cgm.csv --output-json results/mdmp_report.json
mdmp report results/mdmp_report.json --output-html results/mdmp_dashboard.html
mdmp audit results/mdmp_report.json --output-json results/mdmp_audit.json --output-html results/mdmp_audit.html
```

Fingerprint and lineage:

```bash
mdmp fingerprint-record data/demo_cgm.csv --output-json results/fingerprint.json --expires-days 365
mdmp fingerprint-check results/fingerprint.json data/demo_cgm.csv
mdmp lineage-card --model glucose_forecaster_v2 --dataset data/demo_cgm.csv --contract contracts/mdmp_contract.yaml --output results/mdmp_model_card.yaml
mdmp lineage-card-refresh results/mdmp_model_card.yaml
```

Registry and federation scaffold:

```bash
mdmp registry init --registry registry/mdmp_registry.json
mdmp registry push --registry registry/mdmp_registry.json --report results/mdmp_report.json --visibility public
mdmp registry export-public --registry registry/mdmp_registry.json --output-json registry/public_bundle.json
```

## Offline Trust Chain

Root signing:

```bash
mdmp authority keygen --output-dir keys
mdmp authority sign results/mdmp_report.json --privkey keys/mdmp_private_v1.pem --output results/mdmp_report.signed.mdmp
mdmp verify results/mdmp_report.signed.mdmp --public-key keys/mdmp_pub_v1.pem
```

Delegated organization signing:

```bash
mdmp authority delegate \
  --delegate-id uzleuven-001 \
  --delegate-name "UZ Leuven Research Division" \
  --delegate-pubkey keys/uzleuven_pub.pem \
  --grades draft --grades research_grade \
  --require-consent \
  --flavors health \
  --privkey keys/mdmp_private_v1.pem \
  --output certs/uzleuven_delegate.cert

mdmp delegate-sign results/mdmp_report.json \
  --privkey keys/uzleuven_private.pem \
  --cert certs/uzleuven_delegate.cert \
  --output results/mdmp_report.delegate.mdmp

mdmp verify results/mdmp_report.delegate.mdmp \
  --cert certs/uzleuven_delegate.cert \
  --public-key keys/mdmp_pub_v1.pem
```

Hard policy:

- `clinical_grade` and `ai_ready` are non-delegable.

Trust store (rotation + revocation):

```bash
mdmp trust init --trust-store trust/mdmp_trust_store.json --key-id mdmp_pub_v1 --public-key keys/mdmp_pub_v1.pem --set-active
mdmp trust add-key --trust-store trust/mdmp_trust_store.json --key-id mdmp_pub_v2 --public-key keys/mdmp_pub_v2.pem --set-active
mdmp trust revoke-key mdmp_pub_v1 --trust-store trust/mdmp_trust_store.json --reason compromised
mdmp verify results/mdmp_report.signed.mdmp --trust-store trust/mdmp_trust_store.json
```

Policy engine:

```bash
mdmp policy-template --output mdmp_policy.yaml
mdmp validate contracts/mdmp_contract.yaml data/demo_cgm.csv --policy mdmp_policy.yaml --output-json results/mdmp_report.json
mdmp policy-eval mdmp_policy.yaml results/mdmp_report.json --output-json results/mdmp_policy_eval.json
```

Signed audit bundle:

```bash
mdmp audit-bundle results/mdmp_report.json --privkey keys/mdmp_private_v1.pem --output-json results/mdmp_audit_bundle.signed.json
mdmp audit-bundle-verify results/mdmp_audit_bundle.signed.json --public-key keys/mdmp_pub_v1.pem
```

Conformance suite:

```bash
mdmp conformance --workdir results/conformance --output-json results/mdmp_conformance.json --strict
```

## Key Safety Rules

- Never commit private keys.
- Private keys are ignored by default:
  - `keys/mdmp_private*.pem`
  - `*_private.pem`
  - `*.key`
- Public key locations:
  - `src/mdmp_core/keys/mdmp_pub_v1.pem` (bundled with package)
  - `keys/mdmp_pub_v1.pem` (repository mirror)

## Integrations

- `mdmp integrations dvc-stage`
- `mdmp integrations mlflow-log`
- `mdmp integrations wandb-log`
- Reusable GitHub Action: `action.yml`

## Documentation

- Full manual: `docs/manual/complete-manual.md`
- CLI reference: `docs/reference/cli.md`
- Spec: `MDMP_SPEC.md` (`v1.0`)
- Conformance vectors: `conformance/vectors/*.json`
- Conformance guide: `conformance/README.md`
- Security policy: `SECURITY.md`
- Public docs site: [python35.github.io/MDMP](https://python35.github.io/MDMP/)

## Project Metadata

- Current version: `0.3.0`
- Changelog: `CHANGELOG.md`
- Contributing: `CONTRIBUTING.md`
- License: `Apache-2.0`

## Scope

MDMP provides provenance and data-quality metadata only. It is not a medical device and does not provide clinical dosing advice.
