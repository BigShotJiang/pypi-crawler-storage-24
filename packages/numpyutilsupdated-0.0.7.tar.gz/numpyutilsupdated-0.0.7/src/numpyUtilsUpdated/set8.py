code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 8 — Logistic Regression + Youden's Index
# ============================================================

# ---------- Step 1 (i): Build Model (reuse from Q7) ----------
credit_df8 = pd.read_csv('GermanCredit.csv')
x_feat8    = list(credit_df8.columns)
x_feat8.remove('credit_risk')

enc8  = pd.get_dummies(credit_df8[x_feat8], drop_first=True, dtype=int)
y8    = credit_df8['credit_risk'].map({'good': 1, 'bad': 0})
X8    = sm.add_constant(enc8)

X8_tr, X8_te, y8_tr, y8_te = train_test_split(
    X8, y8, test_size=0.3, random_state=42)

logit8 = sm.Logit(y8_tr, X8_tr).fit(maxiter=200)
print('===== (i) Model Summary =====')
print(logit8.summary2())

# ---------- Step 2 (ii): Youden's Index ----------
pred_probs8 = logit8.predict(X8_te)

fpr8, tpr8, thresholds8 = metrics.roc_curve(
    y8_te, pred_probs8, drop_intermediate=False)

youden_df = pd.DataFrame({
    'threshold': thresholds8,
    'tpr'      : tpr8,
    'fpr'      : fpr8
})
# Youden's J = TPR - FPR (= Sensitivity + Specificity - 1)
youden_df['youden_J'] = youden_df['tpr'] - youden_df['fpr']

# Filter to range 0.1 to 0.5
youden_range = youden_df[
    (youden_df['threshold'] >= 0.1) &
    (youden_df['threshold'] <= 0.5)
].sort_values('youden_J', ascending=False)

print('\n===== (ii) Youden Index Table (cut-off 0.1 to 0.5) =====')
print(youden_range.round(4).to_string())

optimal_cutoff8 = youden_range.iloc[0]['threshold']
max_youden8     = youden_range.iloc[0]['youden_J']
print(f'\nOptimal Cut-off = {round(optimal_cutoff8, 4)}')
print(f'Max Youden Index = {round(max_youden8, 4)}')

# ---------- Step 3 (iii): Confusion Matrix at Optimal Cut-off ----------
pred_new8 = (pred_probs8 > optimal_cutoff8).astype(int)

cm8 = metrics.confusion_matrix(y8_te, pred_new8, labels=[1, 0])
plt.figure(figsize=(6, 5))
sns.heatmap(cm8, annot=True, fmt='.0f',
            xticklabels=['Good credit', 'Bad credit'],
            yticklabels=['Good credit', 'Bad credit'],
            cmap='Blues')
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.title(f'(iii) Confusion Matrix at Optimal Cut-off ({round(optimal_cutoff8,3)})')
plt.show()

print('\n(iii) Classification Report at Optimal Cut-off:')
print(metrics.classification_report(y8_te, pred_new8,
      target_names=['Bad Credit', 'Good Credit']))

# ---------- Step 4 (iv): ROC & AUC ----------
auc8 = metrics.roc_auc_score(y8_te, pred_probs8)
plt.figure(figsize=(8, 6))
plt.plot(fpr8, tpr8, label=f'ROC Curve (AUC = {auc8:.2f})')
plt.plot([0, 1], [0, 1], 'k--')
plt.axvline(x=youden_range.iloc[0]['fpr'], color='green',
            linestyle=':', label=f'Optimal threshold = {round(optimal_cutoff8,3)}')
plt.xlim([0, 1]); plt.ylim([0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('(iv) ROC Curve with Optimal Youden Cut-off')
plt.legend(loc='lower right')
plt.show()

print('''
EXPLANATION:
(ii) Youden's Index (J) = TPR − FPR = Sensitivity + Specificity − 1
     • J = 1 → perfect classifier
     • J = 0 → no better than random
     We compute J for every threshold in [0.1, 0.5]
     The threshold with MAXIMUM J is the optimal cut-off.
     This balances sensitivity (catching true positives) and
     specificity (avoiding false positives).

(iii) Using the optimal cut-off instead of default 0.5 usually
      improves recall for the minority class (bad credit in this case).
      This is important when falsely approving bad credit is costly.
''')

END

"""