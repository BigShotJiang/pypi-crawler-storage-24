code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 7 — Logistic Regression on GermanCredit.csv
# ============================================================

# ---------- Step 1: Load & Prepare Data ----------
credit_df = pd.read_csv('GermanCredit.csv')
print('Shape:', credit_df.shape)
print('Columns:', credit_df.columns.tolist())
print(credit_df.head())

# ---------- Step 2 (i): Build Logistic Regression Model ----------
x_feat_cr = list(credit_df.columns)
x_feat_cr.remove('credit_risk')   # remove target (adjust name if needed)

# Encode categorical variables
encoded_cr = pd.get_dummies(
    credit_df[x_feat_cr], drop_first=True, dtype=int)

y_cr = credit_df['credit_risk'].map({'good': 1, 'bad': 0})
X_cr = sm.add_constant(encoded_cr)

X_cr_tr, X_cr_te, y_cr_tr, y_cr_te = train_test_split(
    X_cr, y_cr, test_size=0.3, random_state=42)

logit_cr = sm.Logit(y_cr_tr, X_cr_tr).fit(maxiter=200)
print('\n===== (i) LOGISTIC MODEL SUMMARY =====')
print(logit_cr.summary2())

# ---------- Step 3 (ii): Significant Features ----------
def get_sign_vars(lm):
    p_df          = pd.DataFrame({'pvals': lm.pvalues, 'vars': lm.pvalues.index})
    return list(p_df[p_df['pvals'] <= 0.05]['vars'])

sig_vars = get_sign_vars(logit_cr)
print(f'\n(ii) Significant features (p ≤ 0.05): {sig_vars}')

final_logit_cr = sm.Logit(
    y_cr_tr,
    sm.add_constant(X_cr_tr[sig_vars])
).fit(maxiter=200)
print('\n===== (ii) New Model with Significant Features =====')
print(final_logit_cr.summary2())

# ---------- Step 4 (iii): Positive/Negative Effects ----------
print('\n===== (iii) Effect of Each Parameter on credit_risk =====')
coeff_cr = pd.DataFrame({
    'coefficient': final_logit_cr.params,
    'effect'     : final_logit_cr.params.apply(
        lambda x: 'POSITIVE (increases good credit prob)'
                  if x > 0 else 'NEGATIVE (decreases good credit prob)'
    )
})
print(coeff_cr.to_string())

# ---------- Step 5 (iv): Confusion Matrix ----------
pred_probs_cr = final_logit_cr.predict(
    sm.add_constant(X_cr_te[sig_vars]))
pred_class_cr = (pred_probs_cr > 0.5).astype(int)

cm_cr = metrics.confusion_matrix(y_cr_te, pred_class_cr, labels=[1, 0])
plt.figure(figsize=(6, 5))
sns.heatmap(cm_cr, annot=True, fmt='.0f',
            xticklabels=['Good credit', 'Bad credit'],
            yticklabels=['Good credit', 'Bad credit'],
            cmap='Blues')
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.title('(iv) Confusion Matrix — GermanCredit')
plt.show()

print('\n(iv) Classification Report:')
print(metrics.classification_report(y_cr_te, pred_class_cr,
      target_names=['Bad Credit', 'Good Credit']))

# ---------- Step 6 (v): ROC Curve & AUC ----------
fpr_cr, tpr_cr, _ = metrics.roc_curve(y_cr_te, pred_probs_cr)
auc_cr            = metrics.roc_auc_score(y_cr_te, pred_probs_cr)

plt.figure(figsize=(8, 6))
plt.plot(fpr_cr, tpr_cr, label=f'ROC Curve (AUC = {auc_cr:.2f})')
plt.plot([0, 1], [0, 1], 'k--', label='Random (AUC = 0.5)')
plt.xlim([0, 1]); plt.ylim([0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('(v) ROC Curve — GermanCredit Logistic Model')
plt.legend(loc='lower right')
plt.show()
print(f'\n(v) AUC Score: {round(auc_cr, 4)}')

print('''
EXPLANATION:
(i)  sm.Logit() uses Maximum Likelihood Estimation to find optimal coefficients.
     Pseudo R² between 0.2–0.4 indicates a good logistic model fit.

(ii) p-value ≤ 0.05 → feature is statistically significant at 95% confidence.
     Using only significant features reduces noise and improves reliability.

(iii) Positive coefficient → feature INCREASES probability of good credit.
      Negative coefficient → feature DECREASES probability (pushes toward bad credit).

(iv) Precision = TP / (TP + FP) → Of all predicted good, how many were actually good.
     Recall    = TP / (TP + FN) → Of all actual good, how many did we correctly predict.

(v)  AUC > 0.7 = acceptable; > 0.8 = good; > 0.9 = excellent.
     AUC = 0.5 → random guessing (worst); AUC = 1.0 → perfect model.
''')

END

"""