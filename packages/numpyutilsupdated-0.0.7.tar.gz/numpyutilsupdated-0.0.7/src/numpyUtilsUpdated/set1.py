code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 1 — SLR on MBA Salary Dataset
# ============================================================

# ---------- Step 1: Load Dataset ----------
mba_df = pd.read_csv('MBA_salary.csv')
print('First 5 rows:')
print(mba_df.head())
print('\nDataset Info:')
print(mba_df.info())

# ---------- Step 2 (i): Build SLR Model ----------
# X = Grade 10 percentage (independent variable)
# y = Salary (dependent variable)
X = sm.add_constant(mba_df['percentage in Grade 10'])   # adds intercept column
y = mba_df['salary']

# Split: 80% train, 20% test
X_train, X_test, y_train, y_test = train_test_split(
    X, y, train_size=0.8, random_state=42)

# Fit OLS (Ordinary Least Squares) model
mba_lm = sm.OLS(y_train, X_train).fit()
print('\n===== MODEL SUMMARY (i) =====')
print(mba_lm.summary2())

# ---------- Step 3 (ii): Diagnose the Model — Homoscedasticity ----------
mba_resid = mba_lm.resid   # residuals = actual − predicted

def get_std_values(vals):
    return (vals - vals.mean()) / vals.std()

plt.figure(figsize=(8, 5))
plt.scatter(
    get_std_values(mba_lm.fittedvalues),
    get_std_values(mba_resid)
)
plt.axhline(y=0, color='red', linestyle='--')
plt.title('(ii) Residual Plot — Homoscedasticity Check')
plt.xlabel('Standardized Predicted Values')
plt.ylabel('Standardized Residuals')
plt.show()

# ---------- Step 4 (iii): P-P Plot — Residual Normality ----------
probplot = sm.ProbPlot(mba_resid)
plt.figure(figsize=(8, 5))
probplot.ppplot(line='45')
plt.title('(iii) Normal P-P Plot of Regression Standardized Residuals')
plt.show()

print('''
EXPLANATION:
(i)  sm.add_constant() adds an intercept (β₀) column.
     sm.OLS().fit()    trains the linear model on training data.
     summary2()        shows R², coefficients, p-values, AIC, BIC.
     • R²: % of salary variation explained by Grade 10 %.
     • p-value < 0.05 → feature is statistically significant.

(ii) Residual Plot checks Homoscedasticity:
     → Residuals randomly scattered around 0 = model is valid.
     → Pattern or funnel shape = Heteroscedasticity (problem).

(iii) P-P Plot checks if residuals are Normally distributed:
     → Points close to 45° line = residuals are normal = model is valid.
     → Points far from line = residuals are NOT normal.
''')

END
"""
def getCode():
    print(code)