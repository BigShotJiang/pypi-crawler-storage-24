code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 5 — MLR + Remove Multicollinearity + P-P Plot
# ============================================================

# ---------- Step 1 (i): Build MLR Model (same as Q4) ----------
IPL_df5 = pd.read_csv('IPL.csv')
categorical_features5 = ['AGE', 'COUNTRY', 'PLAYING ROLE', 'CAPTAINCY EXP']
IPL_enc5 = pd.get_dummies(
    IPL_df5, columns=categorical_features5, drop_first=True)

x_feat5 = IPL_enc5.columns.tolist()
x_feat5.remove('SOLD PRICE')
x_feat5 = [c for c in x_feat5 if IPL_enc5[c].dtype in ['int64','float64','uint8']]

X5      = sm.add_constant(IPL_enc5[x_feat5])
Y5      = IPL_df5['SOLD PRICE']
X5_tr, X5_te, y5_tr, y5_te = train_test_split(
    X5, Y5, train_size=0.8, random_state=42)

IPL_mod1 = sm.OLS(y5_tr, X5_tr).fit()
print('===== (i) Initial Model Summary =====')
print(IPL_mod1.summary2())

# ---------- Step 2 (ii): Compute VIF & Remove High-VIF Features ----------
def get_VIF_factors(X_df):
    X_arr     = X_df.values
    vif_table = pd.DataFrame()
    vif_table['column'] = X_df.columns
    vif_table['VIF']    = [
        variance_inflation_factor(X_arr, i)
        for i in range(X_arr.shape[1])
    ]
    return vif_table

vif5 = get_VIF_factors(X5_tr[x_feat5])
print('\n===== VIF Table (Before Removal) =====')
print(vif5.sort_values('VIF', ascending=False).head(15).to_string())

# Remove features with VIF > 10
cols_to_remove = list(vif5[vif5['VIF'] > 10]['column'])
print(f'\nColumns to remove (VIF > 10): {cols_to_remove}')

x_new_feat5 = [c for c in x_feat5 if c not in cols_to_remove]

X_new5    = sm.add_constant(IPL_enc5[x_new_feat5])
X_new5_tr = X_new5.loc[X5_tr.index]
X_new5_te = X_new5.loc[X5_te.index]

IPL_mod2  = sm.OLS(y5_tr, X_new5_tr).fit()
print('\n===== (ii) New Model Summary (After Removing Multicollinearity) =====')
print(IPL_mod2.summary2())

# Verify VIF improved
vif5_new = get_VIF_factors(X_new5_tr[x_new_feat5])
print('\nVIF Table After Removal:')
print(vif5_new.sort_values('VIF', ascending=False).to_string())

# ---------- Step 3 (iii): P-P Plot Residual Analysis ----------
ipl_resid5 = IPL_mod2.resid

# Residual Scatter Plot
plt.figure(figsize=(8, 5))
plt.scatter(
    get_std_values(IPL_mod2.fittedvalues),
    get_std_values(ipl_resid5)
)
plt.axhline(y=0, color='red', linestyle='--')
plt.title('(iii) Residual Plot — IPL Model (Post Multicollinearity Removal)')
plt.xlabel('Standardized Predicted Values')
plt.ylabel('Standardized Residuals')
plt.show()

# P-P Plot
probplot_ipl = sm.ProbPlot(ipl_resid5)
plt.figure(figsize=(8, 5))
probplot_ipl.ppplot(line='45')
plt.title('(iii) Normal P-P Plot — IPL Model After Removing Multicollinearity')
plt.show()

print('''
EXPLANATION:
(ii) After removing high-VIF features:
     • Model becomes more stable and interpretable
     • Coefficients are no longer inflated by correlated predictors
     • Compare Adj. R² before and after — it should stay similar or improve
     • Lower AIC/BIC in new model = better model

(iii) P-P Plot: if residuals of the cleaned model lie close to the 45° line,
      the model satisfies the normality assumption → model is VALID.
''')

END

"""