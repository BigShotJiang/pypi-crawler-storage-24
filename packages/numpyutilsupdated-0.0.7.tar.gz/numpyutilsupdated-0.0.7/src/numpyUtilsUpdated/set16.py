code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 16 & 18 — K-Means on CustomerSpends.csv
# ============================================================

# ---------- Step 1: Load Dataset ----------
cs_df = pd.read_csv('customerspends.csv')
print('Dataset shape:', cs_df.shape)
print('Columns:', cs_df.columns.tolist())
print(cs_df.head())

# Identify spend columns (adjust names based on your CSV)
# Assuming columns like: CustomerID, Apparel, BeautyHealthcare (or similar)
spend_cols = [c for c in cs_df.columns if c.lower() not in ['customerid', 'id', 'customer']]
print(f'\nSpend columns selected: {spend_cols}')

# Use first two spend columns for 2D plots
col1, col2 = spend_cols[0], spend_cols[1]

# ---------- Step 2 (i): Scatter Plot ----------
plt.figure(figsize=(8, 5))
plt.scatter(cs_df[col1], cs_df[col2], color='steelblue', edgecolors='k')
plt.xlabel(col1)
plt.ylabel(col2)
plt.title(f'(i) Customer Spends: {col1} vs {col2}')
plt.grid(True, alpha=0.3)
plt.show()
print('(i) Visually count the approximate number of natural clusters from the plot.')

# ---------- Step 3 (ii): StandardScaler Normalization ----------
scaler_cs  = StandardScaler()
scaled_cs  = scaler_cs.fit_transform(cs_df[spend_cols])

plt.figure(figsize=(8, 5))
plt.scatter(scaled_cs[:, 0], scaled_cs[:, 1], color='darkorange', edgecolors='k')
plt.xlabel(f'Scaled {col1}')
plt.ylabel(f'Scaled {col2}')
plt.title('(ii) Standardized Customer Spends')
plt.grid(True, alpha=0.3)
plt.show()

# ---------- Step 4 (iii): Dendrogram ----------
plt.figure(figsize=(14, 6))
linked_cs = linkage(scaled_cs[:, :2], method='ward')   # use first 2 features for clarity
dendrogram(
    linked_cs,
    truncate_mode='lastp',
    p=30,
    leaf_rotation=90,
    leaf_font_size=10
)
plt.title('(iii) Dendrogram (Ward Linkage) — Customer Spends')
plt.xlabel('Sample Index (or cluster size)')
plt.ylabel('Distance')
plt.show()
print('(iii) Count the number of vertical lines cut by a horizontal line at a chosen height.')
print('That count = suggested number of clusters.')

# Elbow Method
SSE_cs = []
for k in range(1, 10):
    km_cs = KMeans(n_clusters=k, random_state=42, n_init=10)
    km_cs.fit(scaled_cs)
    SSE_cs.append(km_cs.inertia_)

plt.figure(figsize=(8, 5))
plt.plot(range(1, 10), SSE_cs, marker='o', color='tomato')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('SSE (Inertia)')
plt.title('(iii) Elbow Method — Customer Spends')
plt.xticks(range(1, 10))
plt.grid(True, alpha=0.3)
plt.show()

# ---------- Step 5 (iv): K-Means with Optimal k ----------
OPTIMAL_K_CS = 3   # Change based on dendrogram + elbow

km_cs_final  = KMeans(n_clusters=OPTIMAL_K_CS, random_state=42, n_init=10)
cs_df['cluster'] = km_cs_final.fit_predict(scaled_cs)

colors_cs = ['green', 'black', 'red', 'blue', 'orange']
plt.figure(figsize=(9, 6))
for i in range(OPTIMAL_K_CS):
    c_data = cs_df[cs_df.cluster == i]
    plt.scatter(c_data[col1], c_data[col2],
                color=colors_cs[i], label=f'Cluster {i+1}', edgecolors='k')

# Plot centroids (inverse transform to original scale)
centers_orig = scaler_cs.inverse_transform(km_cs_final.cluster_centers_)
plt.scatter(
    centers_orig[:, 0], centers_orig[:, 1],
    color='purple', marker='*', s=300, label='Centroids', zorder=5)
plt.xlabel(col1)
plt.ylabel(col2)
plt.title(f'(iv) K-Means Clusters (k={OPTIMAL_K_CS})')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

# ---------- Step 6 (v): Records per Cluster & Cluster Centers ----------
print('\n===== (v) Records per Cluster =====')
for c in range(OPTIMAL_K_CS):
    cluster_data = cs_df[cs_df.cluster == c].drop('cluster', axis=1)
    print(f'\n--- Cluster {c+1} ({len(cluster_data)} customers) ---')
    print(cluster_data.to_string())

print('\n===== Cluster Centers (Scaled) =====')
print(pd.DataFrame(
    km_cs_final.cluster_centers_,
    columns=spend_cols,
    index=[f'Cluster {i+1}' for i in range(OPTIMAL_K_CS)]
).round(3))

print('\n===== Cluster Centers (Original Scale) =====')
print(pd.DataFrame(
    centers_orig,
    columns=spend_cols,
    index=[f'Cluster {i+1}' for i in range(OPTIMAL_K_CS)]
).round(2))

print('\n===== Cluster Summary Statistics =====')
print(cs_df.groupby('cluster')[spend_cols].agg(['mean','std']).round(2))

print('''
EXPLANATION:
(i)  Scatter plot: dots clumped in groups = natural clusters visible.
     Count roughly how many groups you see.

(ii) StandardScaler: makes all features comparable.
     Without it: a feature with values in thousands dominates distance.

(iii) Dendrogram (Hierarchical Clustering tree):
     Each leaf = one data point.
     Height of merger = dissimilarity when two clusters joined.
     Draw a horizontal line across the dendrogram:
       Number of vertical lines it crosses = suggested k.
     Ward linkage: merges clusters that minimize within-cluster variance.

     Elbow Method confirms the dendrogram suggestion.
     Both methods should agree on the same k for high confidence.

(iv) KMeans assigns each customer to the nearest centroid.
     After convergence, centroids represent average spending of each segment.

(v)  Interpretation example:
     Cluster 1: High Apparel, Low Beauty → fashion-focused customers
     Cluster 2: Low Apparel, High Beauty → healthcare/beauty-focused
     Cluster 3: Medium both → general shoppers
     Use these insights for targeted marketing.
''')

END

"""