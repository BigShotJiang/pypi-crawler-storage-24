code = """
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 2 — SLR on Country Dataset (Corruption vs Gini)
# ============================================================

# ---------- Step 1: Load Dataset ----------
country_df = pd.read_csv('country.csv')
print('First 5 rows:')
print(country_df.head())
print('\nColumns:', country_df.columns.tolist())

# ---------- Step 2 (i): Build SLR ----------
# NOTE: Adjust column names if different in your CSV file
X_c = sm.add_constant(country_df['Gini'])                    # Gini Index as predictor
y_c = country_df['Corruption_Perception_Index']              # CPI as target

X_c_train, X_c_test, y_c_train, y_c_test = train_test_split(
    X_c, y_c, train_size=0.8, random_state=42)

country_lm = sm.OLS(y_c_train, X_c_train).fit()
print('\n===== MODEL SUMMARY (i) =====')
print(country_lm.summary2())

gini_coeff = round(country_lm.params['Gini'], 4)
direction  = 'INCREASES' if gini_coeff > 0 else 'DECREASES'
print(f'\n(i) For every 1 unit INCREASE in Gini Index,')
print(f'    Corruption Perception Index {direction} by: {abs(gini_coeff)}')

# ---------- Step 3 (ii): Diagnose the Model ----------
country_resid = country_lm.resid

plt.figure(figsize=(8, 5))
plt.scatter(
    get_std_values(country_lm.fittedvalues),
    get_std_values(country_resid)
)
plt.axhline(y=0, color='red', linestyle='--')
plt.title('(ii) Residual Plot — Country Model')
plt.xlabel('Standardized Predicted Values')
plt.ylabel('Standardized Residuals')
plt.show()

# ---------- Step 4 (iii): P-P Plot ----------
probplot_c = sm.ProbPlot(country_resid)
plt.figure(figsize=(8, 5))
probplot_c.ppplot(line='45')
plt.title('(iii) Normal P-P Plot — Country SLR Residuals')
plt.show()

print('''
EXPLANATION:
(i)  The Gini coefficient (slope) directly answers:
     "How much does CPI change per 1 unit increase in Gini?"
     • Positive slope → Higher Gini = Higher CPI (less corruption)
     • Negative slope → Higher Gini = Lower CPI (more corruption)

(ii) Residual plot: random scatter around 0 = homoscedasticity OK.

(iii) P-P Plot: points close to 45° diagonal = residuals normally distributed
      = regression model assumptions are satisfied.
''')
END
"""

def getCode():
    print(code)