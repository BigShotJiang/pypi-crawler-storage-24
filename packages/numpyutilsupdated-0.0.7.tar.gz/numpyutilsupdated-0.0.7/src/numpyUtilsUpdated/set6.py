code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 6 — SLR (Country) + Outliers + Accuracy
# ============================================================

from sklearn.metrics import r2_score, mean_squared_error

# ---------- Step 1 (i): Build SLR ----------
country_df6 = pd.read_csv('country.csv')
print('Columns:', country_df6.columns.tolist())
print(country_df6.head())

X_c6 = sm.add_constant(country_df6['Gini'])
y_c6 = country_df6['Corruption_Perception_Index']   # adjust column name if needed

X_c6_tr, X_c6_te, y_c6_tr, y_c6_te = train_test_split(
    X_c6, y_c6, train_size=0.8, random_state=42)

country_lm6 = sm.OLS(y_c6_tr, X_c6_tr).fit()
print('\n===== (i) SLR Summary =====')
print(country_lm6.summary2())

gini_coef = round(country_lm6.params['Gini'], 4)
print(f'\n(i) Change in CPI per 1 unit increase in Gini Index = {gini_coef}')

# ---------- Step 2 (ii): Z-score Outliers ----------
country_df6['z_score_cpi'] = zscore(y_c6)
outliers_country = country_df6[abs(country_df6['z_score_cpi']) > 2.0]
print('\n===== (ii) Outliers by Z-score (|z| > 2) =====')
print(outliers_country[['Gini', 'Corruption_Perception_Index', 'z_score_cpi']])

# Cook's Distance
c_inf6       = country_lm6.get_influence()
(cook_d6, _) = c_inf6.cooks_distance
cutoff6      = 4 / len(X_c6_tr)

plt.figure(figsize=(8, 5))
plt.stem(np.arange(len(X_c6_tr)), np.round(cook_d6, 3), markerfmt=',')
plt.axhline(y=cutoff6, color='red', linestyle='--',
            label=f'Cutoff = 4/n = {cutoff6:.3f}')
plt.title("(ii) Cook's Distance — Country Dataset")
plt.xlabel('Row Index')
plt.ylabel("Cook's Distance")
plt.legend()
plt.show()

# ---------- Step 3 (iii): Predictions & Accuracy ----------
pred_c6  = country_lm6.predict(X_c6_te)
r2_c6    = np.abs(r2_score(y_c6_te, pred_c6))
rmse_c6  = np.sqrt(mean_squared_error(y_c6_te, pred_c6))

print('\n===== (iii) Prediction Accuracy =====')
print(f'R² Score : {round(r2_c6, 4)}')
print(f'RMSE     : {round(rmse_c6, 4)}')

print('''
EXPLANATION:
(i)  Slope = change in Y (CPI) for every 1-unit change in X (Gini).
     Small dataset (n=20) so use 80/20 split.

(ii) Z-score threshold 2 used (not 3) because dataset is very small.
     Cook's D > 4/n marks influential points that distort the model.

(iii) R² tells how well Gini explains CPI variation.
      RMSE = average prediction error in CPI units.
''')

END

"""