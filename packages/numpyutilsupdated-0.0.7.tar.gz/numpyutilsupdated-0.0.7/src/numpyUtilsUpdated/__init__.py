print("[numpyUtilsUpdated] : Welcome to LM Codes")
print("!pip install numpy pandas scikit-learn statsmodels matplotlib seaborn scipy --user")

print("""
Use the function:
      
import numpyUtilsUpdated as nup
nup.getSetDetails(set_no)

Example:
getSetDetails(1)

This will print the question for that set.

Then to get the code use:
Replace set1 with your set no, [set1 - set18] 
import numpyUtilsUpdated.set1 as set
print(set.code)
""")

SET_DETAILS = {
    "set1": {
        "question": "Develop an SLR model to predict MBA salary using Grade 10 percentage from MBA salary.csv. Diagnose the regression model and perform residual analysis using P-P plot."
    },

    "set2": {
        "question": "Develop a simple linear regression model between Corruption Perception Index (Y) and Gini Index (X) using country.csv. Diagnose the regression model and perform residual analysis using P-P plot."
    },

    "set3": {
        "question": "Develop an SLR model using MBA salary.csv and detect outliers using Z-score and Cook’s distance. Make prediction and measure accuracy."
    },

    "set4": {
        "question": "Using IPL dataset, build an MLR model, show the summary, and identify features with multicollinearity."
    },

    "set5": {
        "question": "Using IPL dataset, build an MLR model, detect multicollinearity, rebuild the model after removing it, and perform residual analysis using P-P plot."
    },

    "set6": {
        "question": "Using country.csv dataset, build an SLR model between Corruption Index and Gini Index, detect outliers using Z-score and Cook’s distance, and evaluate prediction accuracy."
    },

    "set7": {
        "question": "Using GermanCredit.csv dataset, build a logistic regression model to predict credit risk, identify significant features, rebuild the model, compute confusion matrix, precision, recall, ROC and AUC."
    },

    "set8": {
        "question": "Using GermanCredit.csv dataset, build logistic regression, compute Youden’s index for cut-offs from 0.1 to 0.5, find optimal cut-off, build confusion matrix, and compute ROC and AUC."
    },

    "set9": {
        "question": "Demonstrate Gain and Lift charts using bank.csv dataset."
    },

    "set10": {
        "question": "Using the tennis dataset, build a logistic regression model to predict PLAY, identify significant features, analyze coefficients, and compute confusion matrix with precision and recall."
    },

    "set11": {
        "question": "Construct the decision tree using Gini impurity for the given training dataset."
    },

    "set12": {
        "question": "Demonstrate Gradient Descent Algorithm for Linear Regression using Advertising.csv dataset."
    },

    "set13": {
        "question": "Build logistic regression models on bank.csv dataset for both imbalanced and balanced data, evaluate using 5-fold cross-validation and ROC AUC score."
    },

    "set14": {
        "question": "Demonstrate the KNN algorithm using a suitable dataset."
    },

    "set15": {
        "question": "Using Income Data.csv dataset, perform K-Means clustering, draw scatter plot of age vs income, normalize features, plot clusters, and interpret cluster centers."
    },

    "set16": {
        "question": "Using customerspends.csv dataset, perform K-Means clustering, visualize clusters, normalize features, use dendrogram and elbow method, and print cluster centers."
    },

    "set17": {
        "question": "Using Income Data.csv dataset, identify clusters, normalize features, apply elbow method, and print records and cluster centers."
    },

    "set18": {
        "question": "Perform product segmentation using K-Means clustering on customerspends.csv dataset, visualize clusters, verify with dendrogram and elbow method, and print cluster centers."
    }
}

def getSetDetails(set_no):
    key = f"set{set_no}"

    if key in SET_DETAILS:
        print(f"Set {set_no} Question:\n")
        print(SET_DETAILS[key]["question"])
    else:
        print("Invalid set number")