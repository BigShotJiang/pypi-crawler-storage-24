code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 10 — Logistic Regression on Tennis Dataset
# ============================================================

# ---------- Step 1: Create Dataset from Question ----------
tennis_data = {
    'DAY'     : [f'Day{i}' for i in range(1, 15)],
    'OUTLOOK' : ['Sunny','Sunny','Overcast','Rain','Rain','Rain',
                 'Overcast','Sunny','Sunny','Rain','Sunny','Overcast','Overcast','Rain'],
    'TEMP'    : ['Hot','Hot','Hot','Mild','Cool','Cool','Cool',
                 'Mild','Cool','Mild','Mild','Mild','Hot','Mild'],
    'HUMIDITY': ['High','High','High','High','Normal','Normal','Normal',
                 'High','Normal','Normal','Normal','High','Normal','High'],
    'WIND'    : ['Weak','Strong','Weak','Weak','Weak','Strong','Strong',
                 'Weak','Weak','Weak','Strong','Strong','Weak','Strong'],
    'PLAY'    : ['NO','NO','YES','YES','YES','NO','YES',
                 'NO','YES','YES','YES','YES','YES','NO']
}
tennis_df = pd.DataFrame(tennis_data)
print('Tennis Dataset:')
print(tennis_df.to_string(index=False))

# ---------- Step 2 (i): Build Logistic Model ----------
tennis_enc = pd.get_dummies(
    tennis_df[['OUTLOOK','TEMP','HUMIDITY','WIND']],
    drop_first=True, dtype=int)
y_tennis = (tennis_df['PLAY'] == 'YES').astype(int)

# Use sklearn since n=14 is very small (statsmodels may not converge)
tennis_clf = LogisticRegression(max_iter=10000, solver='lbfgs')
tennis_clf.fit(tennis_enc, y_tennis)

# Show all features and coefficients
coeff_tennis = pd.DataFrame({
    'feature'    : tennis_enc.columns,
    'coefficient': tennis_clf.coef_[0]
}).sort_values('coefficient', ascending=False)

print('\n===== (i) All Features and Coefficients =====')
print(coeff_tennis.to_string(index=False))

# ---------- Step 3 (ii): Significant Features ----------
# For small datasets use statsmodels for p-values
X_tennis_sm = sm.add_constant(tennis_enc)
try:
    logit_sm = sm.Logit(y_tennis, X_tennis_sm).fit(maxiter=500, disp=False)
    sig_tennis = [v for v, p in logit_sm.pvalues.items() if p <= 0.05]
    print(f'\n(ii) Significant features (p ≤ 0.05): {sig_tennis}')
except:
    # Fallback: use features with largest absolute coefficients
    sig_tennis = list(coeff_tennis.nlargest(3, 'coefficient')['feature']) + \
                 list(coeff_tennis.nsmallest(2, 'coefficient')['feature'])
    print(f'\n(ii) Top features by coefficient magnitude: {sig_tennis}')

# Build new model with significant features
tennis_clf2 = LogisticRegression(max_iter=10000)
sig_tennis_cols = [c for c in sig_tennis if c in tennis_enc.columns and c != 'const']
if sig_tennis_cols:
    tennis_clf2.fit(tennis_enc[sig_tennis_cols], y_tennis)
    print(f'New model features: {sig_tennis_cols}')
else:
    tennis_clf2 = tennis_clf
    sig_tennis_cols = list(tennis_enc.columns)

# ---------- Step 4 (iii): Positive/Negative Effects ----------
print('\n===== (iii) Effect on Probability of PLAY =====')
for _, row in coeff_tennis.iterrows():
    effect = 'POSITIVE (+) — increases PLAY probability' if row['coefficient'] > 0 \
             else 'NEGATIVE (−) — decreases PLAY probability'
    print(f"  {row['feature']:30s}: coeff={row['coefficient']:+.4f}  →  {effect}")

# ---------- Step 5 (iv): Confusion Matrix at 0.5 Cut-off ----------
pred_tennis = tennis_clf.predict(tennis_enc)   # uses default 0.5 threshold

cm_tennis = metrics.confusion_matrix(y_tennis, pred_tennis)
plt.figure(figsize=(6, 5))
sns.heatmap(cm_tennis, annot=True, fmt='.0f',
            xticklabels=['NO', 'YES'],
            yticklabels=['NO', 'YES'],
            cmap='Blues')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('(iv) Confusion Matrix — Tennis (cut-off = 0.5)')
plt.show()

print('\n(iv) Classification Report (PLAY = YES):')
print(metrics.classification_report(y_tennis, pred_tennis,
      target_names=['NO', 'YES']))

print('''
EXPLANATION:
(i)  get_dummies() converts OUTLOOK (Sunny/Overcast/Rain) → binary columns.
     OUTLOOK_Overcast=1, OUTLOOK_Sunny=1, TEMP_Hot=1, WIND_Weak=1 etc.
     drop_first=True: removes one level per feature to avoid multicollinearity.

(ii) Only 14 training samples → statsmodels may struggle to converge.
     Significant features are those with the strongest influence.

(iii) Positive coefficient:
      e.g., HUMIDITY_Normal = positive → Normal humidity increases chance of PLAY.
      Negative coefficient:
      e.g., WIND_Strong = negative → Strong wind decreases chance of PLAY.

(iv) Precision for PLAY=YES:
     Of all days we predicted play, how many actually played.
     Recall for PLAY=YES:
     Of all actual play days, how many did we correctly predict.
''')

END

"""