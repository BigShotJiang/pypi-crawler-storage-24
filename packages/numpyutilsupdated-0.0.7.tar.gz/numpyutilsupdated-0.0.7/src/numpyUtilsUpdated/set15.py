code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 15 & 17 — K-Means on Income_Data.csv
# ============================================================

# ---------- Step 1: Load Dataset ----------
income_df = pd.read_csv('Income_Data.csv')
print('Dataset:')
print(income_df.head())
print('Columns:', income_df.columns.tolist())
print('Shape  :', income_df.shape)

# ---------- Step 2 (i): Scatter Plot Age vs Income ----------
plt.figure(figsize=(8, 5))
plt.scatter(income_df['Age'], income_df['Income'], color='steelblue', edgecolors='k')
plt.xlabel('Age')
plt.ylabel('Income')
plt.title('(i) Scatter Plot: Age vs Income')
plt.grid(True, alpha=0.3)
plt.show()

# ---------- Step 3 (ii): Elbow Method to Find Optimal k ----------
SSE = []
k_range = range(1, 10)
for k in k_range:
    km_elbow = KMeans(n_clusters=k, random_state=42, n_init=10)
    km_elbow.fit(income_df[['Age', 'Income']])
    SSE.append(km_elbow.inertia_)

plt.figure(figsize=(8, 5))
plt.plot(k_range, SSE, marker='o', color='tomato')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('SSE (Within-cluster Sum of Squares)')
plt.title('(ii) Elbow Method — Optimal k for Income Data')
plt.xticks(k_range)
plt.grid(True, alpha=0.3)
plt.show()
print('Look at the plot — the "elbow" (where SSE starts decreasing slowly) gives optimal k.')

# ---------- Step 4 (iii): Normalize with StandardScaler ----------
scaler_inc = StandardScaler()
scaled_inc = scaler_inc.fit_transform(income_df[['Age', 'Income']])

plt.figure(figsize=(8, 5))
plt.scatter(scaled_inc[:, 0], scaled_inc[:, 1], color='purple', edgecolors='k')
plt.xlabel('Scaled Age')
plt.ylabel('Scaled Income')
plt.title('(iii) Standardized Scatter Plot (StandardScaler)')
plt.grid(True, alpha=0.3)
plt.show()

# Elbow on scaled data too
SSE_scaled = []
for k in k_range:
    km_s = KMeans(n_clusters=k, random_state=42, n_init=10)
    km_s.fit(scaled_inc)
    SSE_scaled.append(km_s.inertia_)

plt.figure(figsize=(8, 5))
plt.plot(k_range, SSE_scaled, marker='o', color='green')
plt.xlabel('k')
plt.ylabel('SSE (Scaled Data)')
plt.title('Elbow Method on Standardized Data')
plt.xticks(k_range)
plt.grid(True, alpha=0.3)
plt.show()

# ---------- Step 5 (iv): K-Means with 3 Clusters ----------
OPTIMAL_K = 3   # Change based on your elbow plot
km_inc    = KMeans(n_clusters=OPTIMAL_K, random_state=42, n_init=10)
income_df['cluster'] = km_inc.fit_predict(income_df[['Age', 'Income']])

colors = ['green', 'black', 'red', 'blue', 'orange']
plt.figure(figsize=(9, 6))
for i in range(OPTIMAL_K):
    c_data = income_df[income_df.cluster == i]
    plt.scatter(c_data['Age'], c_data['Income'],
                color=colors[i], label=f'Cluster {i+1}', edgecolors='k')

plt.scatter(
    km_inc.cluster_centers_[:, 0],
    km_inc.cluster_centers_[:, 1],
    color='purple', marker='*', s=300, label='Centroids', zorder=5)
plt.xlabel('Age')
plt.ylabel('Income')
plt.title(f'(iv) K-Means Clusters (k={OPTIMAL_K})')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

# ---------- Step 6 (v): Records per Cluster & Cluster Centers ----------
print('\n===== (v) Records per Cluster =====')
for c in range(OPTIMAL_K):
    cluster_records = income_df[income_df.cluster == c]
    print(f'\n--- Cluster {c+1} ({len(cluster_records)} records) ---')
    print(cluster_records.drop('cluster', axis=1).to_string(index=False))

print('\n===== Cluster Centers (Original Scale) =====')
centers_df = pd.DataFrame(
    km_inc.cluster_centers_,
    columns=['Age', 'Income'])
centers_df.index = [f'Cluster {i+1}' for i in range(OPTIMAL_K)]
print(centers_df.round(2))

print('\n===== Cluster Statistics =====')
cluster_stats_inc = income_df.groupby('cluster').agg(
    Count       = ('Age',    'count'),
    Age_Mean    = ('Age',    'mean'),
    Age_Std     = ('Age',    'std'),
    Income_Mean = ('Income', 'mean'),
    Income_Std  = ('Income', 'std')
).round(2)
print(cluster_stats_inc)

print('''
EXPLANATION:
(i)  Scatter plot visually shows natural groupings.
     Look for obvious clusters of dots before applying any algorithm.

(ii) Elbow Method:
     SSE (inertia) = total within-cluster squared distances.
     As k increases, SSE decreases (more clusters = less spread within each).
     The "elbow" = point where SSE reduction slows down significantly.
     That k value is the optimal number of clusters.

(iii) StandardScaler: normalizes to mean=0, std=1.
      CRITICAL when Age (20-50) and Income (60k-160k) are on different scales.
      Without normalization, Income dominates the distance calculation.

(iv)  KMeans.fit_predict():
      Assigns each data point to the nearest centroid.
      Algorithm iterates until centroids stop moving (convergence).

(v)   Cluster Centers = average of all points in that cluster.
      Interpretation example:
      Cluster 1: Age ≈ 26, Income ≈ 133,500 → Young high earners
      Cluster 2: Age ≈ 33, Income ≈ 62,633  → Mid-age moderate earners
      Cluster 3: Age ≈ 39, Income ≈ 156,660 → Older high earners
''')

END

"""