code='''
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 12 — Gradient Descent Algorithm for Linear Regression
# ============================================================

# ---------- Step 1: Load Dataset ----------
sales_df = pd.read_csv('Advertising.csv')
print('Dataset:')
print(sales_df.head())
print('Shape:', sales_df.shape)

X_sales = sales_df[['TV', 'Radio', 'Newspaper']]
y_sales = sales_df['sales']

# ---------- Step 2: Standardize Features ----------
y_std = np.array((y_sales - y_sales.mean()) / y_sales.std())
X_std = X_sales.apply(
    lambda col: (col - col.mean()) / col.std(), axis=0)

# ---------- Step 3: Define Gradient Descent Functions ----------

def initialize(dim):
    """Random initialization of weights (w) and bias (b)"""
    np.random.seed(42)
    b = np.random.random()
    w = np.random.rand(dim)
    return b, w

def predict_y(b, w, X):
    """Forward pass: y_hat = b + X·w"""
    return b + np.matmul(X, w)

def get_cost(y, y_hat):
    """Cost function: Mean Squared Error (MSE)"""
    residuals = y - y_hat
    return np.sum(np.matmul(residuals.T, residuals)) / len(residuals)

def update_beta(X, y, y_hat, b0, w0, learning_rate):
    """Gradient update step for bias and weights"""
    db = (np.sum(y_hat - y) * 2) / len(y)           # gradient for bias
    dw = (np.dot((y_hat - y), X) * 2) / len(y)      # gradient for weights
    b1 = b0 - learning_rate * db                     # update bias
    w1 = w0 - learning_rate * dw                     # update weights
    return b1, w1

def run_grad(X, y, alpha=0.01, num_iterations=100):
    """Run full Gradient Descent for given iterations and learning rate"""
    b, w        = initialize(X.shape[1])
    iter_num    = 0
    gd_iter_df  = pd.DataFrame(columns=['iterations', 'cost'])
    result_idx  = 0

    for iter_num in range(num_iterations):
        y_hat     = predict_y(b, w, X)
        this_cost = get_cost(y, y_hat)
        prev_b, prev_w = b, w
        b, w      = update_beta(X, y, y_hat, prev_b, prev_w, alpha)

        if iter_num % 10 == 0:   # record every 10th iteration
            gd_iter_df.loc[result_idx] = [iter_num, this_cost]
            result_idx += 1

    print(f'Final estimate of b & w: {round(b,5)}  {np.round(w,5)}')
    return gd_iter_df, b, w

# ---------- Step 4: Show Initial Parameters ----------
b_init, w_init = initialize(3)
print(f'\nInitial Bias    : {b_init:.4f}')
print(f'Initial Weights : {w_init}')

y_hat_init = predict_y(b_init, w_init, X_std.values)
cost_init  = get_cost(y_std, y_hat_init)
print(f'Initial Cost (MSE): {cost_init:.4f}')

b_init, w_init = update_beta(
    X_std.values, y_std, y_hat_init, b_init, w_init, 0.01)
print(f'\nAfter first update → Bias: {b_init:.4f}, Weights: {np.round(w_init,4)}')

# ---------- Step 5: Run Gradient Descent ----------
print('\n===== Running Gradient Descent (alpha=0.01, 2000 iterations) =====')
gd_df1, b1, w1 = run_grad(X_std.values, y_std, alpha=0.01, num_iterations=2000)
print('\nCost per 10 iterations (first 40 rows):')
print(gd_df1.head(40).to_string(index=False))

# ---------- Step 6: Plot Cost vs Iterations ----------
print('\n===== Running with alpha=0.001 for comparison =====')
gd_df2, b2, w2 = run_grad(X_std.values, y_std, alpha=0.001, num_iterations=2000)

plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.plot(gd_df1['iterations'].astype(float),
         gd_df1['cost'].astype(float), color='blue', label='alpha=0.01')
plt.xlabel('No. of Iterations')
plt.ylabel('Cost (MSE)')
plt.title('Cost vs Iterations (alpha=0.01)')
plt.legend()
plt.grid(True, alpha=0.3)

plt.subplot(1, 2, 2)
plt.plot(gd_df2['iterations'].astype(float),
         gd_df2['cost'].astype(float), color='orange', label='alpha=0.001')
plt.xlabel('No. of Iterations')
plt.ylabel('Cost (MSE)')
plt.title('Cost vs Iterations (alpha=0.001)')
plt.legend()
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

END

'''