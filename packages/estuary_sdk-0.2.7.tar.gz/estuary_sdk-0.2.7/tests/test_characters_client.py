"""Tests for CharactersClient."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock

import pytest
from estuary_sdk.rest.characters_client import CharactersClient
from estuary_sdk.types import Character, CharacterListResponse


def _character_dict(**overrides: Any) -> dict[str, Any]:
    """Return a minimal Character wire-format dict with optional overrides."""
    base: dict[str, Any] = {
        "id": "char-1",
        "name": "Test Character",
        "tagline": "A test character",
        "personality": "Friendly",
        "background": "Created for tests",
        "system_prompt": "You are a test character.",
        "tts_provider": "elevenlabs",
        "tts_model": "eleven_flash_v2_5",
        "llm_provider": "openai",
        "llm_model": "gpt-5-mini",
        "llm_temperature": 0.7,
        "llm_max_tokens": 2048,
        "stt_provider": "deepgram",
        "stt_language": "en",
        "text_only": False,
        "is_public": True,
        "is_active": True,
        "launch_status": "running",
        "created_at": "2025-01-01T00:00:00Z",
        "updated_at": "2025-01-02T00:00:00Z",
        "actions": [],
    }
    base.update(overrides)
    return base


@pytest.fixture
def mock_rest() -> AsyncMock:
    """Create a mock RestClient with all HTTP methods as AsyncMocks."""
    rest = AsyncMock()
    rest.get = AsyncMock()
    rest.post = AsyncMock()
    rest.put = AsyncMock()
    rest.patch = AsyncMock()
    rest.delete = AsyncMock()
    return rest


@pytest.fixture
def client(mock_rest: AsyncMock) -> CharactersClient:
    return CharactersClient(mock_rest, player_id="player-1")


class TestCharactersCreate:
    @pytest.mark.asyncio
    async def test_create_minimal(self, client: CharactersClient, mock_rest: AsyncMock) -> None:
        mock_rest.post.return_value = _character_dict(name="Minimal Bot")

        result = await client.create("Minimal Bot")

        assert isinstance(result, Character)
        assert result.name == "Minimal Bot"
        mock_rest.post.assert_awaited_once()
        call_args = mock_rest.post.call_args
        assert call_args[0][0] == "/api/v1/characters"
        body = call_args[1]["body"]
        assert body["persona"]["name"] == "Minimal Bot"
        assert body["verbose"] is False
        assert body["is_public"] is False

    @pytest.mark.asyncio
    async def test_create_with_all_options(
        self, client: CharactersClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.post.return_value = _character_dict()

        await client.create(
            "Full Bot",
            tagline="I do everything",
            personality="Bold",
            background="Background text",
            system_prompt="Be bold.",
            llm_provider="openai",
            llm_model="gpt-5-mini",
            llm_temperature=0.9,
            llm_max_tokens=4096,
            llm_verbosity="high",
            tts_provider="elevenlabs",
            tts_model="eleven_flash_v2_5",
            tts_voice="voice-id",
            tts_voice_preset="preset-1",
            tts_speed=1.2,
            stt_provider="deepgram",
            stt_language="en",
            vad_sensitivity=0.8,
            vad_min_speech_duration_ms=300,
            vlm_model="gpt-4.1-mini",
            avatar="https://example.com/avatar.png",
            text_only=False,
            verbose=True,
            actions=[{"name": "wave", "description": "Wave hand"}],
            is_public=True,
        )

        body = mock_rest.post.call_args[1]["body"]
        assert body["persona"]["name"] == "Full Bot"
        assert body["persona"]["tagline"] == "I do everything"
        assert body["persona"]["system_prompt"] == "Be bold."
        assert body["llm"]["provider"] == "openai"
        assert body["llm"]["temperature"] == 0.9
        assert body["llm"]["max_tokens"] == 4096
        assert body["tts"]["voice"] == "voice-id"
        assert body["tts"]["voice_preset"] == "preset-1"
        assert body["tts"]["speed"] == 1.2
        assert body["stt"]["provider"] == "deepgram"
        assert body["vad"]["sensitivity"] == 0.8
        assert body["vad"]["min_speech_duration_ms"] == 300
        assert body["vlm"]["model"] == "gpt-4.1-mini"
        assert body["avatar"] == "https://example.com/avatar.png"
        assert body["text_only"] is False
        assert body["verbose"] is True
        assert body["actions"] == [{"name": "wave", "description": "Wave hand"}]
        assert body["is_public"] is True

    @pytest.mark.asyncio
    async def test_create_omits_none_sections(
        self, client: CharactersClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.post.return_value = _character_dict()

        await client.create("Simple Bot")

        body = mock_rest.post.call_args[1]["body"]
        assert "llm" not in body
        assert "tts" not in body
        assert "stt" not in body
        assert "vad" not in body
        assert "vlm" not in body
        assert "avatar" not in body
        assert "text_only" not in body


class TestCharactersList:
    @pytest.mark.asyncio
    async def test_list_default(self, client: CharactersClient, mock_rest: AsyncMock) -> None:
        mock_rest.get.return_value = {
            "characters": [_character_dict(), _character_dict(id="char-2", name="Bot 2")],
            "total": 2,
            "limit": 20,
            "offset": 0,
        }

        result = await client.list()

        assert isinstance(result, CharacterListResponse)
        assert len(result.characters) == 2
        assert result.total == 2
        assert result.limit == 20
        assert result.offset == 0
        mock_rest.get.assert_awaited_once_with(
            "/api/v1/characters", params={"limit": 20, "offset": 0}
        )

    @pytest.mark.asyncio
    async def test_list_with_pagination(
        self, client: CharactersClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.get.return_value = {
            "characters": [_character_dict()],
            "total": 50,
            "limit": 10,
            "offset": 20,
        }

        result = await client.list(limit=10, offset=20)

        assert result.total == 50
        assert result.limit == 10
        assert result.offset == 20
        mock_rest.get.assert_awaited_once_with(
            "/api/v1/characters", params={"limit": 10, "offset": 20}
        )


class TestCharactersGet:
    @pytest.mark.asyncio
    async def test_get_character(self, client: CharactersClient, mock_rest: AsyncMock) -> None:
        mock_rest.get.return_value = _character_dict(
            id="char-42",
            name="Retrieved Bot",
            actions=[
                {
                    "name": "greet",
                    "description": "Say hello",
                    "parameters": [
                        {"name": "target", "type": "string", "required": True},
                    ],
                }
            ],
        )

        result = await client.get("char-42")

        assert isinstance(result, Character)
        assert result.id == "char-42"
        assert result.name == "Retrieved Bot"
        assert len(result.actions) == 1
        assert result.actions[0].name == "greet"
        assert len(result.actions[0].parameters) == 1
        assert result.actions[0].parameters[0].name == "target"
        assert result.actions[0].parameters[0].required is True
        mock_rest.get.assert_awaited_once_with("/api/v1/characters/char-42")


class TestCharactersUpdate:
    @pytest.mark.asyncio
    async def test_update_persona_fields(
        self, client: CharactersClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.put.return_value = _character_dict(name="Updated Bot")

        result = await client.update(
            "char-1",
            name="Updated Bot",
            tagline="New tagline",
        )

        assert isinstance(result, Character)
        assert result.name == "Updated Bot"
        body = mock_rest.put.call_args[1]["body"]
        assert body["persona"]["name"] == "Updated Bot"
        assert body["persona"]["tagline"] == "New tagline"

    @pytest.mark.asyncio
    async def test_update_llm_fields(
        self, client: CharactersClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.put.return_value = _character_dict()

        await client.update("char-1", llm_model="gpt-5", llm_temperature=0.5)

        body = mock_rest.put.call_args[1]["body"]
        assert body["llm"]["model"] == "gpt-5"
        assert body["llm"]["temperature"] == 0.5
        assert "persona" not in body

    @pytest.mark.asyncio
    async def test_update_tts_fields(
        self, client: CharactersClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.put.return_value = _character_dict()

        await client.update("char-1", tts_voice="new-voice", tts_speed=1.5)

        body = mock_rest.put.call_args[1]["body"]
        assert body["tts"]["voice"] == "new-voice"
        assert body["tts"]["speed"] == 1.5

    @pytest.mark.asyncio
    async def test_update_vlm(self, client: CharactersClient, mock_rest: AsyncMock) -> None:
        mock_rest.put.return_value = _character_dict()

        await client.update("char-1", vlm_model="gpt-4.1")

        body = mock_rest.put.call_args[1]["body"]
        assert body["vlm"]["model"] == "gpt-4.1"

    @pytest.mark.asyncio
    async def test_update_top_level_fields(
        self, client: CharactersClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.put.return_value = _character_dict()

        await client.update("char-1", text_only=True, is_public=True, avatar="new.png")

        body = mock_rest.put.call_args[1]["body"]
        assert body["text_only"] is True
        assert body["is_public"] is True
        assert body["avatar"] == "new.png"

    @pytest.mark.asyncio
    async def test_update_calls_put(
        self, client: CharactersClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.put.return_value = _character_dict()

        await client.update("char-1", name="X")

        mock_rest.put.assert_awaited_once()
        assert mock_rest.put.call_args[0][0] == "/api/v1/characters/char-1"


class TestCharactersDelete:
    @pytest.mark.asyncio
    async def test_delete_character(
        self, client: CharactersClient, mock_rest: AsyncMock
    ) -> None:
        mock_rest.delete.return_value = {"deleted": True}

        result = await client.delete("char-1")

        assert result == {"deleted": True}
        mock_rest.delete.assert_awaited_once_with("/api/v1/characters/char-1")
