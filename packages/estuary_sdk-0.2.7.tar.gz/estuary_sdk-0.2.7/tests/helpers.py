"""Shared test helpers."""

import asyncio
from collections import defaultdict
from typing import Any


class FakeSocketManager:
    """Minimal mock of SocketManager for voice tests."""

    def __init__(self) -> None:
        self.emitted: list[tuple[str, object]] = []
        self._listeners: dict[str, list[Any]] = defaultdict(list)
        self._once_set: set[Any] = set()
        self.is_connected: bool = True
        self.session: object = None

    def emit_event(self, event: str, data: object = None) -> None:
        self.emitted.append((event, data))

    def on(self, event: str, callback: Any) -> None:
        self._listeners[event].append(callback)

    def once(self, event: str, callback: Any) -> None:
        self._listeners[event].append(callback)
        self._once_set.add(callback)

    def off(self, event: str, callback: Any) -> None:
        listeners = self._listeners.get(event)
        if listeners:
            try:
                listeners.remove(callback)
            except ValueError:
                pass
            self._once_set.discard(callback)

    async def simulate_event(self, event: str, *args: Any) -> None:
        """Simulate the server emitting an event."""
        for cb in list(self._listeners.get(event, [])):
            if cb in self._once_set:
                self._once_set.discard(cb)
                try:
                    self._listeners[event].remove(cb)
                except ValueError:
                    pass
            result = cb(*args)
            if asyncio.iscoroutine(result):
                await result
