"""Tests for PlayersClient REST methods."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from estuary_sdk.rest.players_client import PlayersClient
from estuary_sdk.types import (
    Pagination,
    PlayerConversation,
    PlayerConversationList,
    PlayerMessage,
    PlayerMessageList,
    PlayerStats,
)


@pytest.fixture
def rest() -> AsyncMock:
    return AsyncMock()


@pytest.fixture
def client(rest: AsyncMock) -> PlayersClient:
    return PlayersClient(rest, agent_id="agent-123")


class TestGetStats:
    async def test_returns_player_stats(self, client: PlayersClient, rest: AsyncMock) -> None:
        rest.get.return_value = {
            "totalConversations": 10,
            "totalMessages": 500,
            "firstActivity": "2025-01-01T00:00:00Z",
            "lastActivity": "2025-06-01T00:00:00Z",
        }

        result = await client.get_stats()

        assert isinstance(result, PlayerStats)
        assert result.total_conversations == 10
        assert result.total_messages == 500
        assert result.first_activity == "2025-01-01T00:00:00Z"
        assert result.last_activity == "2025-06-01T00:00:00Z"
        rest.get.assert_called_once_with("/api/agents/agent-123/players/stats")

    async def test_returns_defaults_for_empty_response(
        self, client: PlayersClient, rest: AsyncMock
    ) -> None:
        rest.get.return_value = {}

        result = await client.get_stats()

        assert result.total_conversations == 0
        assert result.total_messages == 0
        assert result.first_activity is None
        assert result.last_activity is None


class TestList:
    async def test_returns_conversation_list(
        self, client: PlayersClient, rest: AsyncMock
    ) -> None:
        rest.get.return_value = {
            "conversations": [
                {
                    "id": "conv-1",
                    "characterId": "char-1",
                    "playerId": "p1",
                    "apiKeyId": "key-1",
                    "createdAt": "2025-01-01T00:00:00Z",
                    "lastActivity": "2025-06-01T00:00:00Z",
                    "messageCount": 42,
                    "lastMemoryExtractionAt": "2025-05-01T00:00:00Z",
                }
            ],
            "total": 100,
            "limit": 50,
            "offset": 0,
            "sortBy": "last_activity",
            "sortOrder": "desc",
        }

        result = await client.list()

        assert isinstance(result, PlayerConversationList)
        assert result.total == 100
        assert result.limit == 50
        assert result.offset == 0
        assert result.sort_by == "last_activity"
        assert result.sort_order == "desc"
        assert len(result.conversations) == 1

        conv = result.conversations[0]
        assert isinstance(conv, PlayerConversation)
        assert conv.id == "conv-1"
        assert conv.character_id == "char-1"
        assert conv.player_id == "p1"
        assert conv.api_key_id == "key-1"
        assert conv.message_count == 42
        assert conv.last_memory_extraction_at == "2025-05-01T00:00:00Z"

        rest.get.assert_called_once_with(
            "/api/agents/agent-123/players",
            params={
                "limit": 50,
                "offset": 0,
                "sort_by": "last_activity",
                "sort_order": "desc",
            },
        )

    async def test_passes_custom_params(
        self, client: PlayersClient, rest: AsyncMock
    ) -> None:
        rest.get.return_value = {"conversations": [], "total": 0}

        await client.list(
            limit=10,
            offset=20,
            sort_by="created_at",
            sort_order="asc",
            player_search="alice",
            min_messages=5,
        )

        rest.get.assert_called_once_with(
            "/api/agents/agent-123/players",
            params={
                "limit": 10,
                "offset": 20,
                "sort_by": "created_at",
                "sort_order": "asc",
                "player_search": "alice",
                "min_messages": 5,
            },
        )

    async def test_omits_none_filters(
        self, client: PlayersClient, rest: AsyncMock
    ) -> None:
        rest.get.return_value = {"conversations": [], "total": 0}

        await client.list(player_search=None, min_messages=None)

        call_params = rest.get.call_args[1]["params"]
        assert "player_search" not in call_params
        assert "min_messages" not in call_params


class TestGet:
    async def test_returns_single_conversation(
        self, client: PlayersClient, rest: AsyncMock
    ) -> None:
        rest.get.return_value = {
            "id": "conv-1",
            "characterId": "char-1",
            "playerId": "p1",
            "messageCount": 10,
        }

        result = await client.get("p1")

        assert isinstance(result, PlayerConversation)
        assert result.id == "conv-1"
        assert result.player_id == "p1"
        assert result.character_id == "char-1"
        rest.get.assert_called_once_with("/api/agents/agent-123/players/p1")


class TestGetMessages:
    async def test_returns_message_list(
        self, client: PlayersClient, rest: AsyncMock
    ) -> None:
        rest.get.return_value = {
            "messages": [
                {
                    "id": 1,
                    "conversationId": "conv-1",
                    "role": "user",
                    "content": "Hello",
                    "timestamp": "2025-01-01T00:00:00Z",
                    "imageUrl": None,
                },
                {
                    "id": 2,
                    "conversationId": "conv-1",
                    "role": "assistant",
                    "content": "Hi there!",
                    "timestamp": "2025-01-01T00:00:01Z",
                },
            ],
            "pagination": {
                "page": 1,
                "limit": 100,
                "total": 500,
                "hasMore": True,
            },
        }

        result = await client.get_messages("p1")

        assert isinstance(result, PlayerMessageList)
        assert len(result.messages) == 2

        msg = result.messages[0]
        assert isinstance(msg, PlayerMessage)
        assert msg.id == 1
        assert msg.conversation_id == "conv-1"
        assert msg.role == "user"
        assert msg.content == "Hello"
        assert msg.image_url is None

        assert isinstance(result.pagination, Pagination)
        assert result.pagination.page == 1
        assert result.pagination.limit == 100
        assert result.pagination.total == 500
        assert result.pagination.has_more is True

        rest.get.assert_called_once_with(
            "/api/agents/agent-123/players/p1/messages",
            params={"limit": 100, "page": 1},
        )

    async def test_passes_custom_pagination(
        self, client: PlayersClient, rest: AsyncMock
    ) -> None:
        rest.get.return_value = {"messages": [], "pagination": {}}

        await client.get_messages("p1", limit=25, page=3)

        rest.get.assert_called_once_with(
            "/api/agents/agent-123/players/p1/messages",
            params={"limit": 25, "page": 3},
        )


class TestDelete:
    async def test_returns_raw_dict(
        self, client: PlayersClient, rest: AsyncMock
    ) -> None:
        rest.delete.return_value = {"message": "Player deleted", "deleted": True}

        result = await client.delete("p1")

        assert result == {"message": "Player deleted", "deleted": True}
        rest.delete.assert_called_once_with("/api/agents/agent-123/players/p1")
