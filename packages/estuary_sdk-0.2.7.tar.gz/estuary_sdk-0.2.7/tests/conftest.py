"""Shared test fixtures."""

import pytest
from helpers import FakeSocketManager


@pytest.fixture
def socket() -> FakeSocketManager:
    return FakeSocketManager()
