"""Tests for data model types and their from_dict parsing."""

from estuary_sdk.types import (
    BotResponse,
    BotVoice,
    CameraCaptureRequest,
    CoreFact,
    CoreFactsResponse,
    GraphEdge,
    GraphNode,
    GraphStats,
    InterruptData,
    LiveKitTokenResponse,
    MemoryData,
    MemoryGraph,
    MemoryListResponse,
    MemoryStats,
    MemoryUpdatedEvent,
    QuotaExceededData,
    SessionInfo,
    SttResponse,
)


class TestSessionInfo:
    def test_from_dict(self) -> None:
        data = {
            "session_id": "sess-1",
            "conversation_id": "conv-1",
            "character_id": "char-1",
            "player_id": "player-1",
        }
        info = SessionInfo.from_dict(data)
        assert info.session_id == "sess-1"
        assert info.conversation_id == "conv-1"
        assert info.character_id == "char-1"
        assert info.player_id == "player-1"

    def test_from_dict_missing_fields(self) -> None:
        info = SessionInfo.from_dict({})
        assert info.session_id == ""
        assert info.player_id == ""

    def test_frozen(self) -> None:
        info = SessionInfo.from_dict(
            {"session_id": "s", "conversation_id": "c", "character_id": "ch", "player_id": "p"}
        )
        try:
            info.session_id = "new"  # type: ignore[misc]
            assert False, "Should be frozen"
        except AttributeError:
            pass


class TestBotResponse:
    def test_from_dict_full(self) -> None:
        data = {
            "text": "Hello!",
            "is_final": True,
            "partial": "Hel",
            "message_id": "msg-1",
            "chunk_index": 2,
            "is_interjection": False,
        }
        r = BotResponse.from_dict(data)
        assert r.text == "Hello!"
        assert r.is_final is True
        assert r.partial == "Hel"
        assert r.message_id == "msg-1"
        assert r.chunk_index == 2
        assert r.is_interjection is False

    def test_from_dict_defaults(self) -> None:
        r = BotResponse.from_dict({})
        assert r.text == ""
        assert r.is_final is False
        assert r.chunk_index == 0


class TestBotVoice:
    def test_from_dict(self) -> None:
        data = {"audio": "AQID", "message_id": "m1", "chunk_index": 1, "is_final": True}
        v = BotVoice.from_dict(data)
        assert v.audio == "AQID"
        assert v.is_final is True


class TestSttResponse:
    def test_from_dict(self) -> None:
        s = SttResponse.from_dict({"text": "hello", "is_final": True})
        assert s.text == "hello"
        assert s.is_final is True


class TestInterruptData:
    def test_from_dict_with_nulls(self) -> None:
        d = InterruptData.from_dict({})
        assert d.message_id is None
        assert d.reason is None

    def test_from_dict_with_values(self) -> None:
        d = InterruptData.from_dict({"message_id": "m1", "reason": "user"})
        assert d.message_id == "m1"
        assert d.reason == "user"


class TestQuotaExceededData:
    def test_from_dict(self) -> None:
        q = QuotaExceededData.from_dict(
            {
                "message": "Quota exceeded",
                "current": 100,
                "limit": 100,
                "remaining": 0,
                "tier": "free",
            }
        )
        assert q.message == "Quota exceeded"
        assert q.remaining == 0
        assert q.tier == "free"


class TestLiveKitTokenResponse:
    def test_from_dict(self) -> None:
        t = LiveKitTokenResponse.from_dict({"token": "tok", "url": "wss://lk", "room": "room-1"})
        assert t.token == "tok"
        assert t.url == "wss://lk"


class TestCameraCaptureRequest:
    def test_from_dict(self) -> None:
        c = CameraCaptureRequest.from_dict({"request_id": "r1", "text": "look"})
        assert c.request_id == "r1"
        assert c.text == "look"

    def test_from_dict_no_text(self) -> None:
        c = CameraCaptureRequest.from_dict({"request_id": "r1"})
        assert c.text is None


class TestMemoryData:
    def test_from_dict_camel_case(self) -> None:
        data = {
            "id": "mem-1",
            "userId": "u1",
            "agentId": "a1",
            "playerId": "p1",
            "content": "Likes pizza",
            "memoryType": "preference",
            "confidence": 0.95,
            "status": "active",
            "sourceConversationId": "conv-1",
            "sourceQuote": "I love pizza",
            "source": "text_chat",
            "topic": "food",
            "secondaryTopics": ["preferences"],
            "lastAccessedAt": None,
            "accessCount": 3,
            "extractedAt": "2024-01-01T00:00:00Z",
            "createdAt": "2024-01-01T00:00:00Z",
            "updatedAt": None,
        }
        m = MemoryData.from_dict(data)
        assert m.id == "mem-1"
        assert m.user_id == "u1"
        assert m.agent_id == "a1"
        assert m.memory_type == "preference"
        assert m.confidence == 0.95
        assert m.source_quote == "I love pizza"
        assert m.secondary_topics == ["preferences"]
        assert m.access_count == 3


class TestMemoryUpdatedEvent:
    def test_from_dict_with_memories(self) -> None:
        data = {
            "agent_id": "a1",
            "player_id": "p1",
            "memories_extracted": 2,
            "facts_extracted": 1,
            "conversation_id": "conv-1",
            "new_memories": [
                {"id": "m1", "content": "Fact 1", "memoryType": "fact"},
                {"id": "m2", "content": "Pref 1", "memoryType": "preference"},
            ],
            "timestamp": "2024-01-01T00:00:00Z",
        }
        e = MemoryUpdatedEvent.from_dict(data)
        assert e.agent_id == "a1"
        assert e.memories_extracted == 2
        assert len(e.new_memories) == 2
        assert e.new_memories[0].content == "Fact 1"
        assert e.new_memories[1].memory_type == "preference"


class TestMemoryListResponse:
    def test_from_dict(self) -> None:
        data = {
            "memories": [
                {"id": "m1", "content": "Likes pizza", "memoryType": "preference"},
                {"id": "m2", "content": "Lives in NYC", "memoryType": "fact"},
            ],
            "total": 100,
            "limit": 50,
            "offset": 10,
        }
        r = MemoryListResponse.from_dict(data)
        assert r.total == 100
        assert r.limit == 50
        assert r.offset == 10
        assert len(r.memories) == 2
        assert r.memories[0].content == "Likes pizza"
        assert r.memories[1].memory_type == "fact"

    def test_from_dict_defaults(self) -> None:
        r = MemoryListResponse.from_dict({})
        assert r.memories == []
        assert r.total == 0
        assert r.limit == 50
        assert r.offset == 0


class TestMemoryStats:
    def test_from_dict(self) -> None:
        data = {
            "totalActive": 50,
            "totalSuperseded": 10,
            "totalDecayed": 5,
            "byType": {"fact": 30, "preference": 15, "experience": 5},
            "coreFacts": 8,
        }
        s = MemoryStats.from_dict(data)
        assert s.total_active == 50
        assert s.total_superseded == 10
        assert s.total_decayed == 5
        assert s.by_type == {"fact": 30, "preference": 15, "experience": 5}
        assert s.core_facts == 8

    def test_from_dict_defaults(self) -> None:
        s = MemoryStats.from_dict({})
        assert s.total_active == 0
        assert s.by_type == {}
        assert s.core_facts == 0


class TestCoreFactsResponse:
    def test_from_dict(self) -> None:
        data = {
            "coreFacts": [
                {
                    "id": "cf-1",
                    "userId": "u1",
                    "agentId": "a1",
                    "playerId": "p1",
                    "factKey": "name",
                    "factValue": "John",
                    "sourceMemoryId": "mem-1",
                    "createdAt": "2024-01-01T00:00:00",
                    "updatedAt": None,
                }
            ]
        }
        r = CoreFactsResponse.from_dict(data)
        assert len(r.core_facts) == 1
        f = r.core_facts[0]
        assert f.id == "cf-1"
        assert f.user_id == "u1"
        assert f.agent_id == "a1"
        assert f.player_id == "p1"
        assert f.fact_key == "name"
        assert f.fact_value == "John"
        assert f.source_memory_id == "mem-1"
        assert f.updated_at is None

    def test_from_dict_empty(self) -> None:
        r = CoreFactsResponse.from_dict({})
        assert r.core_facts == []

    def test_core_fact_frozen(self) -> None:
        f = CoreFact.from_dict({"factKey": "k", "factValue": "v"})
        try:
            f.fact_key = "other"  # type: ignore[misc]
            assert False, "Should be frozen"
        except AttributeError:
            pass


class TestMemoryGraph:
    def test_from_dict_user_node(self) -> None:
        node = GraphNode.from_dict({"id": "user_p1", "type": "user", "label": "p1"})
        assert node.id == "user_p1"
        assert node.type == "user"
        assert node.label == "p1"
        assert node.content is None
        assert node.entity_type is None

    def test_from_dict_cluster_node(self) -> None:
        node = GraphNode.from_dict(
            {
                "id": "cluster_0",
                "type": "cluster",
                "label": "Food",
                "memoryCount": 5,
                "level": 1,
                "parentClusterId": None,
                "childClusterIds": ["cluster_1", "cluster_2"],
                "pendingLabel": False,
            }
        )
        assert node.type == "cluster"
        assert node.memory_count == 5
        assert node.level == 1
        assert node.parent_cluster_id is None
        assert node.child_cluster_ids == ["cluster_1", "cluster_2"]
        assert node.pending_label is False

    def test_from_dict_memory_node(self) -> None:
        node = GraphNode.from_dict(
            {
                "id": "mem_1",
                "type": "memory",
                "content": "Likes pizza",
                "memoryType": "preference",
                "confidence": 0.95,
                "createdAt": "2024-01-01T00:00:00",
                "topic": "food",
            }
        )
        assert node.type == "memory"
        assert node.content == "Likes pizza"
        assert node.memory_type == "preference"
        assert node.confidence == 0.95
        assert node.topic == "food"

    def test_from_dict_entity_node(self) -> None:
        node = GraphNode.from_dict(
            {
                "id": "ent_1",
                "type": "entity",
                "entityType": "person",
                "name": "John",
                "mentionCount": 3,
                "extraData": {"role": "friend"},
            }
        )
        assert node.type == "entity"
        assert node.entity_type == "person"
        assert node.name == "John"
        assert node.mention_count == 3
        assert node.extra_data == {"role": "friend"}

    def test_from_dict_edge(self) -> None:
        edge = GraphEdge.from_dict(
            {"source": "a", "target": "b", "type": "contains"}
        )
        assert edge.source == "a"
        assert edge.target == "b"
        assert edge.type == "contains"
        assert edge.relationship_type is None

    def test_from_dict_relationship_edge(self) -> None:
        edge = GraphEdge.from_dict(
            {
                "source": "ent_a",
                "target": "ent_b",
                "type": "relationship",
                "relationshipType": "knows",
                "label": "knows",
                "confidence": 0.8,
            }
        )
        assert edge.relationship_type == "knows"
        assert edge.label == "knows"
        assert edge.confidence == 0.8

    def test_from_dict_stats(self) -> None:
        stats = GraphStats.from_dict(
            {
                "totalMemories": 50,
                "totalEntities": 10,
                "clusterCount": 5,
                "clusters": {"Food": 5, "Work": 10},
            }
        )
        assert stats.total_memories == 50
        assert stats.total_entities == 10
        assert stats.cluster_count == 5
        assert stats.clusters == {"Food": 5, "Work": 10}

    def test_from_dict_full_graph(self) -> None:
        data = {
            "nodes": [
                {"id": "user_p1", "type": "user", "label": "p1"},
                {"id": "mem_1", "type": "memory", "content": "test"},
            ],
            "edges": [
                {"source": "user_p1", "target": "mem_1", "type": "has_memory"},
            ],
            "stats": {
                "totalMemories": 1,
                "totalEntities": 0,
                "clusterCount": 0,
                "clusters": {},
            },
            "stale": True,
        }
        graph = MemoryGraph.from_dict(data)
        assert len(graph.nodes) == 2
        assert len(graph.edges) == 1
        assert graph.stats.total_memories == 1
        assert graph.stale is True

    def test_from_dict_defaults(self) -> None:
        graph = MemoryGraph.from_dict({})
        assert graph.nodes == []
        assert graph.edges == []
        assert graph.stats.total_memories == 0
        assert graph.stale is False
