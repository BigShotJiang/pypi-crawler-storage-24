"""Tests for MemoryClient with typed return models."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from estuary_sdk.rest.memory_client import MemoryClient
from estuary_sdk.types import (
    CoreFactsResponse,
    MemoryDeleteResponse,
    MemoryGraph,
    MemoryListResponse,
    MemorySearchResponse,
    MemoryStats,
    MemoryTimeline,
)


class TestMemoryClient:
    @pytest.fixture
    def rest(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, rest: AsyncMock) -> MemoryClient:
        return MemoryClient(rest, agent_id="agent-1", player_id="player-1")

    @pytest.mark.asyncio
    async def test_get_memories(self, client: MemoryClient, rest: AsyncMock) -> None:
        rest.get.return_value = {
            "memories": [
                {"id": "m1", "content": "Likes pizza", "memoryType": "preference"},
                {"id": "m2", "content": "Lives in NYC", "memoryType": "fact"},
            ],
            "total": 2,
            "limit": 50,
            "offset": 0,
        }
        result = await client.get_memories()
        assert isinstance(result, MemoryListResponse)
        assert result.total == 2
        assert result.limit == 50
        assert result.offset == 0
        assert len(result.memories) == 2
        assert result.memories[0].id == "m1"
        assert result.memories[0].content == "Likes pizza"
        assert result.memories[0].memory_type == "preference"
        assert result.memories[1].id == "m2"

    @pytest.mark.asyncio
    async def test_get_memories_with_params(
        self, client: MemoryClient, rest: AsyncMock
    ) -> None:
        rest.get.return_value = {"memories": [], "total": 0, "limit": 10, "offset": 5}
        result = await client.get_memories(
            memory_type="fact", status="active", limit=10, offset=5
        )
        assert isinstance(result, MemoryListResponse)
        assert result.total == 0
        rest.get.assert_called_once()
        call_args = rest.get.call_args
        params = call_args[1]["params"] if "params" in call_args[1] else call_args[0][1]
        assert params["memory_type"] == "fact"
        assert params["status"] == "active"

    @pytest.mark.asyncio
    async def test_get_timeline(self, client: MemoryClient, rest: AsyncMock) -> None:
        rest.get.return_value = {
            "timeline": [
                {
                    "date": "2024-01-01",
                    "memories": [
                        {"id": "m1", "content": "Fact 1", "memoryType": "fact"},
                    ],
                },
                {
                    "date": "2024-01-02",
                    "memories": [
                        {"id": "m2", "content": "Pref 1", "memoryType": "preference"},
                        {"id": "m3", "content": "Pref 2", "memoryType": "preference"},
                    ],
                },
            ],
            "totalMemories": 3,
            "groupBy": "day",
        }
        result = await client.get_timeline()
        assert isinstance(result, MemoryTimeline)
        assert result.total_memories == 3
        assert result.group_by == "day"
        assert len(result.timeline) == 2
        assert result.timeline[0].date == "2024-01-01"
        assert len(result.timeline[0].memories) == 1
        assert result.timeline[1].date == "2024-01-02"
        assert len(result.timeline[1].memories) == 2

    @pytest.mark.asyncio
    async def test_get_stats(self, client: MemoryClient, rest: AsyncMock) -> None:
        rest.get.return_value = {
            "totalActive": 50,
            "totalSuperseded": 10,
            "totalDecayed": 5,
            "byType": {"fact": 30, "preference": 15, "experience": 5},
            "coreFacts": 8,
        }
        result = await client.get_stats()
        assert isinstance(result, MemoryStats)
        assert result.total_active == 50
        assert result.total_superseded == 10
        assert result.total_decayed == 5
        assert result.by_type == {"fact": 30, "preference": 15, "experience": 5}
        assert result.core_facts == 8

    @pytest.mark.asyncio
    async def test_get_core_facts(self, client: MemoryClient, rest: AsyncMock) -> None:
        rest.get.return_value = {
            "coreFacts": [
                {
                    "id": "cf-1",
                    "userId": "u1",
                    "agentId": "a1",
                    "playerId": "p1",
                    "factKey": "name",
                    "factValue": "John",
                    "sourceMemoryId": "mem-1",
                    "createdAt": "2024-01-01T00:00:00",
                    "updatedAt": None,
                },
                {
                    "id": "cf-2",
                    "userId": "u1",
                    "agentId": "a1",
                    "playerId": "p1",
                    "factKey": "favorite_food",
                    "factValue": "pizza",
                    "sourceMemoryId": "mem-2",
                    "createdAt": "2024-01-02T00:00:00",
                    "updatedAt": "2024-01-03T00:00:00",
                },
            ]
        }
        result = await client.get_core_facts()
        assert isinstance(result, CoreFactsResponse)
        assert len(result.core_facts) == 2
        assert result.core_facts[0].fact_key == "name"
        assert result.core_facts[0].fact_value == "John"
        assert result.core_facts[0].source_memory_id == "mem-1"
        assert result.core_facts[0].updated_at is None
        assert result.core_facts[1].fact_key == "favorite_food"
        assert result.core_facts[1].updated_at == "2024-01-03T00:00:00"

    @pytest.mark.asyncio
    async def test_get_graph(self, client: MemoryClient, rest: AsyncMock) -> None:
        rest.get.return_value = {
            "nodes": [
                {"id": "user_p1", "type": "user", "label": "p1"},
                {
                    "id": "cluster_0",
                    "type": "cluster",
                    "label": "Food",
                    "memoryCount": 5,
                    "level": 1,
                    "parentClusterId": None,
                    "childClusterIds": ["cluster_1"],
                    "pendingLabel": False,
                },
                {
                    "id": "mem_1",
                    "type": "memory",
                    "content": "Likes pizza",
                    "memoryType": "preference",
                    "confidence": 0.95,
                    "createdAt": "2024-01-01T00:00:00",
                    "topic": "food",
                },
                {
                    "id": "ent_1",
                    "type": "entity",
                    "entityType": "person",
                    "name": "John",
                    "mentionCount": 3,
                    "extraData": {"role": "friend"},
                },
            ],
            "edges": [
                {"source": "user_p1", "target": "cluster_0", "type": "has_cluster"},
                {"source": "cluster_0", "target": "mem_1", "type": "contains"},
                {"source": "mem_1", "target": "ent_1", "type": "mentions"},
                {
                    "source": "ent_1",
                    "target": "ent_2",
                    "type": "relationship",
                    "relationshipType": "knows",
                    "label": "knows",
                    "confidence": 0.8,
                },
            ],
            "stats": {
                "totalMemories": 5,
                "totalEntities": 2,
                "clusterCount": 1,
                "clusters": {"Food": 5},
            },
            "stale": False,
        }
        result = await client.get_graph()
        assert isinstance(result, MemoryGraph)
        assert len(result.nodes) == 4
        assert result.nodes[0].type == "user"
        assert result.nodes[0].label == "p1"
        assert result.nodes[1].type == "cluster"
        assert result.nodes[1].memory_count == 5
        assert result.nodes[1].level == 1
        assert result.nodes[1].child_cluster_ids == ["cluster_1"]
        assert result.nodes[2].type == "memory"
        assert result.nodes[2].content == "Likes pizza"
        assert result.nodes[2].confidence == 0.95
        assert result.nodes[3].type == "entity"
        assert result.nodes[3].entity_type == "person"
        assert result.nodes[3].name == "John"
        assert result.nodes[3].mention_count == 3
        assert result.nodes[3].extra_data == {"role": "friend"}
        assert len(result.edges) == 4
        assert result.edges[0].type == "has_cluster"
        assert result.edges[3].relationship_type == "knows"
        assert result.edges[3].confidence == 0.8
        assert result.stats.total_memories == 5
        assert result.stats.total_entities == 2
        assert result.stats.cluster_count == 1
        assert result.stats.clusters == {"Food": 5}
        assert result.stale is False

    @pytest.mark.asyncio
    async def test_search(self, client: MemoryClient, rest: AsyncMock) -> None:
        rest.get.return_value = {
            "results": [
                {
                    "memory": {
                        "id": "m1",
                        "content": "Likes pizza",
                        "memoryType": "preference",
                    },
                    "score": 0.85,
                    "similarityScore": 0.92,
                },
                {
                    "memory": {
                        "id": "m2",
                        "content": "Ordered pasta last week",
                        "memoryType": "experience",
                    },
                    "score": 0.60,
                    "similarityScore": 0.70,
                },
            ],
            "query": "food preferences",
            "total": 2,
        }
        result = await client.search("food preferences")
        assert isinstance(result, MemorySearchResponse)
        assert result.query == "food preferences"
        assert result.total == 2
        assert len(result.results) == 2
        assert result.results[0].score == 0.85
        assert result.results[0].similarity_score == 0.92
        assert result.results[0].memory.content == "Likes pizza"
        assert result.results[1].memory.id == "m2"

    @pytest.mark.asyncio
    async def test_delete_all(self, client: MemoryClient, rest: AsyncMock) -> None:
        rest.delete.return_value = {
            "message": "Deleted 50 records",
            "deletedCount": 50,
        }
        result = await client.delete_all()
        assert isinstance(result, MemoryDeleteResponse)
        assert result.message == "Deleted 50 records"
        assert result.deleted_count == 50

    @pytest.mark.asyncio
    async def test_base_path(self, rest: AsyncMock) -> None:
        client = MemoryClient(rest, agent_id="a1", player_id="p1")
        rest.get.return_value = {"memories": [], "total": 0, "limit": 50, "offset": 0}
        await client.get_memories()
        rest.get.assert_called_once()
        call_path = rest.get.call_args[0][0]
        assert call_path == "/api/agents/a1/players/p1/memories"

    # ------------------------------------------------------------------
    # Edge cases: empty responses
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_get_memories_empty(self, client: MemoryClient, rest: AsyncMock) -> None:
        """Empty response returns MemoryListResponse with memories=[], total=0."""
        rest.get.return_value = {"memories": [], "total": 0, "limit": 50, "offset": 0}
        result = await client.get_memories()
        assert isinstance(result, MemoryListResponse)
        assert result.memories == []
        assert result.total == 0

    @pytest.mark.asyncio
    async def test_get_graph_empty(self, client: MemoryClient, rest: AsyncMock) -> None:
        """Empty graph returns MemoryGraph with nodes=[], edges=[], stale=False."""
        rest.get.return_value = {"nodes": [], "edges": [], "stats": {}, "stale": False}
        result = await client.get_graph()
        assert isinstance(result, MemoryGraph)
        assert result.nodes == []
        assert result.edges == []
        assert result.stale is False
        assert result.stats.total_memories == 0
        assert result.stats.total_entities == 0
        assert result.stats.cluster_count == 0

    @pytest.mark.asyncio
    async def test_get_graph_stale(self, client: MemoryClient, rest: AsyncMock) -> None:
        """Graph with stale=True correctly sets the stale flag."""
        rest.get.return_value = {
            "nodes": [{"id": "user_p1", "type": "user", "label": "p1"}],
            "edges": [],
            "stats": {"totalMemories": 5, "totalEntities": 0, "clusterCount": 0},
            "stale": True,
        }
        result = await client.get_graph()
        assert isinstance(result, MemoryGraph)
        assert result.stale is True
        assert len(result.nodes) == 1

    @pytest.mark.asyncio
    async def test_search_empty(self, client: MemoryClient, rest: AsyncMock) -> None:
        """Search with no results returns MemorySearchResponse with results=[], total=0."""
        rest.get.return_value = {"results": [], "query": "nonexistent", "total": 0}
        result = await client.search("nonexistent")
        assert isinstance(result, MemorySearchResponse)
        assert result.results == []
        assert result.total == 0
        assert result.query == "nonexistent"

    @pytest.mark.asyncio
    async def test_get_timeline_empty(self, client: MemoryClient, rest: AsyncMock) -> None:
        """Empty timeline returns MemoryTimeline with timeline=[], total_memories=0."""
        rest.get.return_value = {"timeline": [], "totalMemories": 0, "groupBy": "day"}
        result = await client.get_timeline()
        assert isinstance(result, MemoryTimeline)
        assert result.timeline == []
        assert result.total_memories == 0
        assert result.group_by == "day"

    @pytest.mark.asyncio
    async def test_get_core_facts_empty(self, client: MemoryClient, rest: AsyncMock) -> None:
        """Empty core facts returns CoreFactsResponse with core_facts=[]."""
        rest.get.return_value = {"coreFacts": []}
        result = await client.get_core_facts()
        assert isinstance(result, CoreFactsResponse)
        assert result.core_facts == []

    # ------------------------------------------------------------------
    # Parameter forwarding verification
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_get_graph_params(self, client: MemoryClient, rest: AsyncMock) -> None:
        """get_graph forwards include_entities and include_character_memories."""
        rest.get.return_value = {"nodes": [], "edges": [], "stats": {}, "stale": False}
        await client.get_graph(include_entities=True, include_character_memories=True)
        rest.get.assert_called_once()
        call_args = rest.get.call_args
        params = call_args[1]["params"] if "params" in call_args[1] else call_args[0][1]
        assert params["include_entities"] is True
        assert params["include_character_memories"] is True

    @pytest.mark.asyncio
    async def test_get_timeline_params(self, client: MemoryClient, rest: AsyncMock) -> None:
        """get_timeline forwards start_date, end_date, and group_by."""
        rest.get.return_value = {"timeline": [], "totalMemories": 0, "groupBy": "month"}
        await client.get_timeline(
            start_date="2024-01-01", end_date="2024-12-31", group_by="month"
        )
        rest.get.assert_called_once()
        call_args = rest.get.call_args
        params = call_args[1]["params"] if "params" in call_args[1] else call_args[0][1]
        assert params["start_date"] == "2024-01-01"
        assert params["end_date"] == "2024-12-31"
        assert params["group_by"] == "month"

    @pytest.mark.asyncio
    async def test_get_memories_sort_params(
        self, client: MemoryClient, rest: AsyncMock
    ) -> None:
        """get_memories forwards sort_by and sort_order."""
        rest.get.return_value = {"memories": [], "total": 0, "limit": 50, "offset": 0}
        await client.get_memories(sort_by="confidence", sort_order="asc")
        rest.get.assert_called_once()
        call_args = rest.get.call_args
        params = call_args[1]["params"] if "params" in call_args[1] else call_args[0][1]
        assert params["sort_by"] == "confidence"
        assert params["sort_order"] == "asc"

    @pytest.mark.asyncio
    async def test_search_with_limit(self, client: MemoryClient, rest: AsyncMock) -> None:
        """search forwards limit parameter."""
        rest.get.return_value = {"results": [], "query": "test", "total": 0}
        await client.search("test", limit=5)
        rest.get.assert_called_once()
        call_args = rest.get.call_args
        params = call_args[1]["params"] if "params" in call_args[1] else call_args[0][1]
        assert params["q"] == "test"
        assert params["limit"] == 5
