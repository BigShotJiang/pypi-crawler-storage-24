"""Tests for VLM/vision flow in the Python SDK.

Covers:
- send_camera_image() payload correctness (all param combinations, None omission)
- camera_capture_request event reception and forwarding
- CameraCaptureRequest.from_dict() parsing
- Full VLM round-trip flow simulation
"""

import pytest
from helpers import FakeSocketManager

from estuary_sdk import ErrorCode, EstuaryClient, EstuaryConfig, EstuaryError
from estuary_sdk.types import BotResponse, CameraCaptureRequest


@pytest.fixture
def config() -> EstuaryConfig:
    return EstuaryConfig(
        server_url="http://localhost:4001",
        api_key="est_test_key",
        character_id="test-char-id",
        player_id="test-player",
    )


def _make_connected_client(config: EstuaryConfig) -> tuple[EstuaryClient, FakeSocketManager]:
    """Create an EstuaryClient with a FakeSocketManager wired in (connected state)."""
    client = EstuaryClient(config)
    fake = FakeSocketManager()
    fake.is_connected = True
    client._socket = fake  # type: ignore[assignment]
    client._bind_socket_events()
    return client, fake


class TestSendCameraImage:
    """Tests for EstuaryClient.send_camera_image() payload correctness."""

    def test_send_camera_image_basic(self, config: EstuaryConfig) -> None:
        client, fake = _make_connected_client(config)
        client.send_camera_image("aGVsbG8=", "image/jpeg")
        assert len(fake.emitted) == 1
        event, payload = fake.emitted[0]
        assert event == "camera_image"
        assert payload == {"image": "aGVsbG8=", "mime_type": "image/jpeg"}

    def test_send_camera_image_with_request_id(self, config: EstuaryConfig) -> None:
        client, fake = _make_connected_client(config)
        client.send_camera_image("aGVsbG8=", "image/jpeg", request_id="req-123")
        event, payload = fake.emitted[0]
        assert event == "camera_image"
        assert payload["request_id"] == "req-123"

    def test_send_camera_image_with_text(self, config: EstuaryConfig) -> None:
        client, fake = _make_connected_client(config)
        client.send_camera_image("aGVsbG8=", "image/jpeg", text="what is this?")
        event, payload = fake.emitted[0]
        assert event == "camera_image"
        assert payload["text"] == "what is this?"

    def test_send_camera_image_with_all_params(self, config: EstuaryConfig) -> None:
        client, fake = _make_connected_client(config)
        client.send_camera_image(
            "aGVsbG8=", "image/jpeg", request_id="req-456", text="describe this"
        )
        event, payload = fake.emitted[0]
        assert event == "camera_image"
        assert payload == {
            "image": "aGVsbG8=",
            "mime_type": "image/jpeg",
            "request_id": "req-456",
            "text": "describe this",
        }

    def test_send_camera_image_not_connected_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        # Client not connected (default state) -- should raise
        with pytest.raises(EstuaryError) as exc_info:
            client.send_camera_image("aGVsbG8=", "image/jpeg")
        assert exc_info.value.code == ErrorCode.NOT_CONNECTED

    def test_send_camera_image_omits_none_request_id(self, config: EstuaryConfig) -> None:
        client, fake = _make_connected_client(config)
        client.send_camera_image("aGVsbG8=", "image/jpeg", request_id=None)
        _, payload = fake.emitted[0]
        assert "request_id" not in payload

    def test_send_camera_image_omits_none_text(self, config: EstuaryConfig) -> None:
        client, fake = _make_connected_client(config)
        client.send_camera_image("aGVsbG8=", "image/jpeg", text=None)
        _, payload = fake.emitted[0]
        assert "text" not in payload


class TestCameraCaptureRequestEvent:
    """Tests that camera_capture_request events flow from SocketManager to EstuaryClient."""

    async def test_camera_capture_request_received(self, config: EstuaryConfig) -> None:
        client, fake = _make_connected_client(config)
        received: list[CameraCaptureRequest] = []

        async def handler(request: CameraCaptureRequest) -> None:
            received.append(request)

        client.on("camera_capture_request", handler)

        capture_request = CameraCaptureRequest(request_id="uuid-abc")
        await fake.simulate_event("camera_capture_request", capture_request)

        assert len(received) == 1
        assert isinstance(received[0], CameraCaptureRequest)
        assert received[0].request_id == "uuid-abc"

    async def test_camera_capture_request_has_request_id_and_text(
        self, config: EstuaryConfig
    ) -> None:
        client, fake = _make_connected_client(config)
        received: list[CameraCaptureRequest] = []

        async def handler(request: CameraCaptureRequest) -> None:
            received.append(request)

        client.on("camera_capture_request", handler)

        capture_request = CameraCaptureRequest(
            request_id="uuid-abc", text="what is this?"
        )
        await fake.simulate_event("camera_capture_request", capture_request)

        assert len(received) == 1
        assert received[0].request_id == "uuid-abc"
        assert received[0].text == "what is this?"


class TestCameraCaptureRequestParsing:
    """Unit tests for CameraCaptureRequest.from_dict() parsing."""

    def test_from_dict_full(self) -> None:
        result = CameraCaptureRequest.from_dict(
            {"request_id": "r1", "text": "look at this"}
        )
        assert result.request_id == "r1"
        assert result.text == "look at this"

    def test_from_dict_minimal(self) -> None:
        result = CameraCaptureRequest.from_dict({})
        assert result.request_id == ""
        assert result.text is None

    def test_from_dict_no_text(self) -> None:
        result = CameraCaptureRequest.from_dict({"request_id": "r2"})
        assert result.request_id == "r2"
        assert result.text is None


class TestVlmRoundTrip:
    """Integration-style test simulating the full VLM round-trip through the SDK."""

    async def test_full_vlm_flow(self, config: EstuaryConfig) -> None:
        """Simulate the complete VLM vision flow:

        1. User sends text "what am I looking at"
        2. Server emits camera_capture_request
        3. Client responds with send_camera_image
        4. Server emits bot_response with vision description
        """
        client, fake = _make_connected_client(config)

        # Track received events
        camera_requests: list[CameraCaptureRequest] = []
        bot_responses: list[BotResponse] = []

        async def on_camera_capture(request: CameraCaptureRequest) -> None:
            camera_requests.append(request)
            # In response to camera capture, client sends an image
            client.send_camera_image(
                "base64img",
                "image/jpeg",
                request_id=request.request_id,
                text="what am I looking at",
            )

        async def on_bot_response(response: BotResponse) -> None:
            bot_responses.append(response)

        client.on("camera_capture_request", on_camera_capture)
        client.on("bot_response", on_bot_response)

        # Step 1: User sends text
        client.send_text("what am I looking at")
        assert fake.emitted[0] == ("text", {"text": "what am I looking at"})

        # Step 2: Server emits camera_capture_request
        capture_request = CameraCaptureRequest(
            request_id="req-1", text="what am I looking at"
        )
        await fake.simulate_event("camera_capture_request", capture_request)

        # Step 3: Verify camera_capture_request was received and image was sent
        assert len(camera_requests) == 1
        assert camera_requests[0].request_id == "req-1"

        # Find the camera_image emission in the fake socket
        camera_emissions = [
            (evt, data) for evt, data in fake.emitted if evt == "camera_image"
        ]
        assert len(camera_emissions) == 1
        _, camera_payload = camera_emissions[0]
        assert camera_payload == {
            "image": "base64img",
            "mime_type": "image/jpeg",
            "request_id": "req-1",
            "text": "what am I looking at",
        }

        # Step 4: Server emits bot_response with vision description
        vision_response = BotResponse(
            text="I can see a coffee mug",
            is_final=True,
            message_id="msg-1",
        )
        await fake.simulate_event("bot_response", vision_response)

        # Verify bot_response was received
        assert len(bot_responses) == 1
        assert bot_responses[0].text == "I can see a coffee mug"
        assert bot_responses[0].is_final is True
        assert bot_responses[0].message_id == "msg-1"
