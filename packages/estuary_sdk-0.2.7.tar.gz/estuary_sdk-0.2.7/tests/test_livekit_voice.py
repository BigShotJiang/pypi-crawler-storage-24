"""Tests for LiveKitVoiceManager."""

import asyncio
import sys
from types import ModuleType, SimpleNamespace
from typing import Any
import pytest
from helpers import FakeSocketManager
from estuary_sdk.errors import ErrorCode, EstuaryError
from estuary_sdk.types import LiveKitTokenResponse, VoiceMode

# ---------------------------------------------------------------------------
# Mock the livekit.rtc module before importing LiveKitVoiceManager
# ---------------------------------------------------------------------------


class FakeAudioSource:
    def __init__(self, sample_rate: int, channels: int) -> None:
        self.sample_rate = sample_rate
        self.channels = channels
        self.captured_frames: list[Any] = []

    async def capture_frame(self, frame: Any) -> None:
        self.captured_frames.append(frame)

    async def aclose(self) -> None:
        pass


class FakeAudioFrame:
    def __init__(self, **kwargs: Any) -> None:
        for k, v in kwargs.items():
            setattr(self, k, v)


class FakeFrameEvent:
    def __init__(self, frame: Any) -> None:
        self.frame = frame


class FakeAudioStream:
    """Async iterable that yields frame events, then stops."""

    def __init__(self, track: Any, sample_rate: int = 16000, num_channels: int = 1) -> None:
        self.track = track
        self.sample_rate = sample_rate
        self.num_channels = num_channels
        self._frames: list[Any] = list(getattr(track, "_pending_frames", []))
        self._closed = False

    def __aiter__(self) -> "FakeAudioStream":
        return self

    async def __anext__(self) -> FakeFrameEvent:
        if self._closed or not self._frames:
            raise StopAsyncIteration
        frame = self._frames.pop(0)
        return FakeFrameEvent(frame)

    async def aclose(self) -> None:
        self._closed = True


class FakeLocalAudioTrack:
    def __init__(self, name: str, source: Any) -> None:
        self.name = name
        self.source = source
        self.sid = "track_sid_123"

    @staticmethod
    def create_audio_track(name: str, source: Any) -> "FakeLocalAudioTrack":
        return FakeLocalAudioTrack(name, source)


class FakeLocalParticipant:
    def __init__(self) -> None:
        self.published_tracks: list[Any] = []
        self.track_publications: dict[str, Any] = {}
        self._mic_enabled = True

    async def publish_track(self, track: Any, options: Any = None) -> None:
        self.published_tracks.append((track, options))

    async def set_microphone_enabled(self, enabled: bool) -> None:
        self._mic_enabled = enabled


class FakeTrackPublication:
    """Simulates a remote track publication."""

    def __init__(self, track: Any = None, subscribed: bool = False) -> None:
        self.track = track
        self.subscribed = subscribed


class FakeRemoteParticipant:
    """Simulates a remote participant with track publications."""

    def __init__(
        self, track_publications: dict[str, "FakeTrackPublication"] | None = None
    ) -> None:
        self.track_publications: dict[str, FakeTrackPublication] = track_publications or {}


class FakeRoom:
    def __init__(self) -> None:
        self.connected = False
        self.local_participant = FakeLocalParticipant()
        self.remote_participants: dict[str, FakeRemoteParticipant] = {}
        self._handlers: dict[str, list[Any]] = {}
        self._disconnected = False

    async def connect(self, url: str, token: str) -> None:
        self.connected = True
        self._url = url
        self._token = token

    async def disconnect(self) -> None:
        self.connected = False
        self._disconnected = True

    def on(self, event: str, handler: Any) -> None:
        self._handlers.setdefault(event, []).append(handler)

    def simulate_track_subscribed(
        self, track: Any, publication: Any = None, participant: Any = None
    ) -> None:
        for h in self._handlers.get("track_subscribed", []):
            h(track, publication, participant)


class FakeTrackPublishOptions:
    source: Any = None


class FakeTrackSource:
    SOURCE_MICROPHONE = "microphone"


class FakeTrackKind:
    KIND_AUDIO = "audio"
    KIND_VIDEO = "video"


class FakeRemoteAudioTrack:
    """Simulates a remote audio track from the bot."""

    def __init__(self, frames: list[Any] | None = None) -> None:
        self.kind = FakeTrackKind.KIND_AUDIO
        self._pending_frames = frames or []


class FakeAudioProcessingModule:
    """Fake APM that records processed frames for assertion."""

    def __init__(
        self,
        *,
        echo_cancellation: bool = False,
        noise_suppression: bool = False,
        high_pass_filter: bool = False,
        auto_gain_control: bool = False,
    ) -> None:
        self.echo_cancellation = echo_cancellation
        self.noise_suppression = noise_suppression
        self.high_pass_filter = high_pass_filter
        self.auto_gain_control = auto_gain_control
        self.processed_frames: list[Any] = []
        self.reverse_frames: list[Any] = []

    def process_stream(self, frame: Any) -> None:
        self.processed_frames.append(frame)

    def process_reverse_stream(self, frame: Any) -> None:
        self.reverse_frames.append(frame)


# Build the mock module
_mock_rtc = ModuleType("livekit.rtc")
_mock_rtc.Room = FakeRoom  # type: ignore[attr-defined]
_mock_rtc.AudioSource = FakeAudioSource  # type: ignore[attr-defined]
_mock_rtc.AudioFrame = FakeAudioFrame  # type: ignore[attr-defined]
_mock_rtc.AudioStream = FakeAudioStream  # type: ignore[attr-defined]
_mock_rtc.LocalAudioTrack = FakeLocalAudioTrack  # type: ignore[attr-defined]
_mock_rtc.TrackPublishOptions = FakeTrackPublishOptions  # type: ignore[attr-defined]
_mock_rtc.TrackSource = FakeTrackSource  # type: ignore[attr-defined]
_mock_rtc.TrackKind = FakeTrackKind  # type: ignore[attr-defined]
_mock_rtc.AudioProcessingModule = FakeAudioProcessingModule  # type: ignore[attr-defined]

_mock_livekit = ModuleType("livekit")
_mock_livekit.rtc = _mock_rtc  # type: ignore[attr-defined]

sys.modules["livekit"] = _mock_livekit
sys.modules["livekit.rtc"] = _mock_rtc

# Now import — it will use our mocks
from estuary_sdk.voice.livekit_voice import LiveKitVoiceManager  # noqa: E402

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

TOKEN = LiveKitTokenResponse(token="test-token", url="wss://lk.test", room="test-room")


def _make_vm(
    sock: FakeSocketManager,
    mode: VoiceMode = VoiceMode.CONTINUOUS,
    start_timeout: float = 1.0,
    on_audio_received: Any = None,
    livekit_token: LiveKitTokenResponse | None = None,
) -> LiveKitVoiceManager:
    return LiveKitVoiceManager(
        sock,  # type: ignore[arg-type]
        voice_mode=mode,
        start_timeout=start_timeout,
        on_audio_received=on_audio_received,
        livekit_token=livekit_token,
    )


async def _start_vm_with_ready(vm: LiveKitVoiceManager, sock: FakeSocketManager) -> None:
    """Start the VM with a background task that simulates livekit_ready."""

    async def confirm() -> None:
        await asyncio.sleep(0)
        await sock.simulate_event("livekit_ready", "test-room")

    task = asyncio.create_task(confirm())
    await vm.start()
    await task


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestLiveKitVoiceStart:
    @pytest.mark.asyncio
    async def test_start_requests_token_and_waits_for_ready(
        self, socket: FakeSocketManager
    ) -> None:
        vm = _make_vm(socket)

        async def confirm() -> None:
            await asyncio.sleep(0)
            # Simulate token response
            await socket.simulate_event("livekit_token", TOKEN)
            await asyncio.sleep(0)
            # Simulate ready
            await socket.simulate_event("livekit_ready", "test-room")

        task = asyncio.create_task(confirm())
        await vm.start()
        await task

        assert vm.is_active
        # Should have emitted livekit_token request and livekit_join
        events = [e for e, _ in socket.emitted]
        assert "livekit_token" in events
        assert "livekit_join" in events

    @pytest.mark.asyncio
    async def test_start_uses_embedded_token(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket, livekit_token=TOKEN)

        async def confirm() -> None:
            await asyncio.sleep(0)
            await socket.simulate_event("livekit_ready", "test-room")

        task = asyncio.create_task(confirm())
        await vm.start()
        await task

        assert vm.is_active
        # Should NOT have emitted livekit_token request
        events = [e for e, _ in socket.emitted]
        assert "livekit_token" not in events
        # Should still emit livekit_join
        assert "livekit_join" in events

    @pytest.mark.asyncio
    async def test_start_raises_on_livekit_error(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket, livekit_token=TOKEN)

        async def send_error() -> None:
            await asyncio.sleep(0)
            await socket.simulate_event("livekit_error", "Room not found")

        task = asyncio.create_task(send_error())
        with pytest.raises(EstuaryError) as exc_info:
            await vm.start()
        await task
        assert exc_info.value.code == ErrorCode.LIVEKIT_UNAVAILABLE
        assert "Room not found" in str(exc_info.value)
        assert not vm.is_active

    @pytest.mark.asyncio
    async def test_start_raises_on_timeout(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket, livekit_token=TOKEN, start_timeout=0.1)
        with pytest.raises(EstuaryError) as exc_info:
            await vm.start()
        assert exc_info.value.code == ErrorCode.LIVEKIT_UNAVAILABLE
        assert "timed out" in str(exc_info.value).lower()
        assert not vm.is_active


class TestLiveKitVoiceAudio:
    @pytest.mark.asyncio
    async def test_send_audio_captures_frame(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)

        audio_data = b"\x01\x00" * 160
        await vm.send_audio(audio_data)

        # The audio source should have captured a frame
        assert vm._audio_source is not None
        assert len(vm._audio_source.captured_frames) == 1
        frame = vm._audio_source.captured_frames[0]
        assert frame.sample_rate == 16000

    @pytest.mark.asyncio
    async def test_send_audio_blocked_when_muted(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)
        vm.toggle_mute()
        await vm.send_audio(b"\x01\x00")
        assert len(vm._audio_source.captured_frames) == 0

    @pytest.mark.asyncio
    async def test_receive_audio_callback(self, socket: FakeSocketManager) -> None:
        received: list[bytes] = []

        async def on_audio(data: bytes) -> None:
            received.append(data)

        vm = _make_vm(socket, livekit_token=TOKEN, on_audio_received=on_audio)
        await _start_vm_with_ready(vm, socket)

        # Simulate a remote audio track with frames.
        # VM uses 16kHz (default) so AudioStream is created at 48kHz and frames
        # are decimated 3:1.  Provide 6 int16 samples that decimate to [3, 4].
        raw_48k = b"\x03\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00"
        fake_frame = SimpleNamespace(data=SimpleNamespace(tobytes=lambda: raw_48k))
        remote_track = FakeRemoteAudioTrack(frames=[fake_frame])

        # Get the room and simulate track subscription
        room: FakeRoom = vm._room
        room.simulate_track_subscribed(remote_track)

        # Let the async receive task run
        await asyncio.sleep(0.05)

        assert len(received) == 1
        assert received[0] == b"\x03\x00\x04\x00"


    @pytest.mark.asyncio
    async def test_track_handler_registered_before_connect(
        self, socket: FakeSocketManager
    ) -> None:
        """Handler must be registered before connect so we don't miss early tracks."""
        vm = _make_vm(socket, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)

        room: FakeRoom = vm._room
        assert "track_subscribed" in room._handlers
        assert len(room._handlers["track_subscribed"]) == 1

    @pytest.mark.asyncio
    async def test_preexisting_remote_track_picked_up(self, socket: FakeSocketManager) -> None:
        """Tracks already subscribed during connect are caught by the post-connect scan."""
        received: list[bytes] = []

        async def on_audio(data: bytes) -> None:
            received.append(data)

        vm = _make_vm(socket, livekit_token=TOKEN, on_audio_received=on_audio)

        # Pre-populate the room with a remote participant that has a subscribed track.
        # 6 int16 samples at 48kHz → decimated to [5, 6] at 16kHz.
        raw_48k = b"\x05\x00\x00\x00\x00\x00\x06\x00\x00\x00\x00\x00"
        fake_frame = SimpleNamespace(data=SimpleNamespace(tobytes=lambda: raw_48k))
        remote_track = FakeRemoteAudioTrack(frames=[fake_frame])
        pub = FakeTrackPublication(track=remote_track, subscribed=True)
        participant = FakeRemoteParticipant(track_publications={"track_0": pub})

        # Monkey-patch FakeRoom so connect() populates remote_participants
        orig_connect = FakeRoom.connect

        async def connect_with_participant(self_room: Any, url: str, token: str) -> None:
            await orig_connect(self_room, url, token)
            self_room.remote_participants["bot"] = participant

        FakeRoom.connect = connect_with_participant  # type: ignore[assignment]
        try:
            await _start_vm_with_ready(vm, socket)
        finally:
            FakeRoom.connect = orig_connect  # type: ignore[assignment]

        # Let the async receive task run
        await asyncio.sleep(0.05)

        assert len(received) == 1
        assert received[0] == b"\x05\x00\x06\x00"


class TestLiveKitVoiceCleanup:
    @pytest.mark.asyncio
    async def test_stop_cleanup(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)
        assert vm.is_active

        room: FakeRoom = vm._room
        await vm.stop()

        assert not vm.is_active
        assert vm._room is None
        assert vm._audio_source is None
        assert vm._track is None
        assert room._disconnected
        # Should have emitted livekit_leave
        events = [e for e, _ in socket.emitted]
        assert "livekit_leave" in events

    @pytest.mark.asyncio
    async def test_dispose_calls_stop(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)
        await vm.dispose()
        assert not vm.is_active

    @pytest.mark.asyncio
    async def test_mute_toggle(self, socket: FakeSocketManager) -> None:
        vm = _make_vm(socket, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)
        assert not vm.is_muted
        vm.toggle_mute()
        assert vm.is_muted
        vm.toggle_mute()
        assert not vm.is_muted


class TestLiveKitVoiceTrackSubscription:
    @pytest.mark.asyncio
    async def test_duplicate_track_subscribed_ignored(self, socket: FakeSocketManager) -> None:
        """Second track_subscribed call is ignored when already receiving audio."""
        received: list[bytes] = []

        async def on_audio(data: bytes) -> None:
            received.append(data)

        vm = _make_vm(socket, livekit_token=TOKEN, on_audio_received=on_audio)
        await _start_vm_with_ready(vm, socket)

        # First track subscription (3 samples at 48kHz → decimated to 1 sample)
        fake_frame1 = SimpleNamespace(
            data=SimpleNamespace(tobytes=lambda: b"\x01\x00\x00\x00\x00\x00")
        )
        remote_track1 = FakeRemoteAudioTrack(frames=[fake_frame1])

        room: FakeRoom = vm._room
        room.simulate_track_subscribed(remote_track1)
        first_task = vm._audio_stream_task
        await asyncio.sleep(0.05)

        # Second track subscription while first is still "active" — simulate by
        # setting up a non-done task
        fake_frame2 = SimpleNamespace(
            data=SimpleNamespace(tobytes=lambda: b"\x02\x00\x00\x00\x00\x00")
        )
        remote_track2 = FakeRemoteAudioTrack(frames=[fake_frame2])

        # Create a long-running task to simulate an active stream
        async def long_running() -> None:
            await asyncio.sleep(10)

        vm._audio_stream_task = asyncio.ensure_future(long_running())
        room.simulate_track_subscribed(remote_track2)

        # Task should NOT have been replaced
        assert vm._audio_stream_task is not None
        # Clean up
        vm._audio_stream_task.cancel()
        try:
            await vm._audio_stream_task
        except asyncio.CancelledError:
            pass


class TestDecimateInt16:
    def test_decimate_by_3(self) -> None:
        """48kHz → 16kHz: keep every 3rd sample."""
        # 6 int16 samples: [1, 2, 3, 4, 5, 6]
        import struct

        data = struct.pack("<6h", 1, 2, 3, 4, 5, 6)
        result = LiveKitVoiceManager._decimate_int16(data, 3)
        assert struct.unpack(f"<{len(result)//2}h", result) == (1, 4)

    def test_decimate_by_2(self) -> None:
        """48kHz → 24kHz: keep every 2nd sample."""
        import struct

        data = struct.pack("<4h", 10, 20, 30, 40)
        result = LiveKitVoiceManager._decimate_int16(data, 2)
        assert struct.unpack(f"<{len(result)//2}h", result) == (10, 30)

    def test_decimate_by_1_is_noop(self) -> None:
        """No decimation needed (same rate)."""
        data = b"\x01\x00\x02\x00"
        result = LiveKitVoiceManager._decimate_int16(data, 1)
        assert result == data


class TestLiveKitVoicePTT:
    """Tests for push-to-talk (PTT) mode in LiveKit voice manager."""

    @pytest.mark.asyncio
    async def test_ptt_start_recording_does_not_emit_start_voice(
        self, socket: FakeSocketManager
    ) -> None:
        """start_recording() in LiveKit PTT should NOT emit start_voice.

        Deepgram is already connected via livekit_join; emitting start_voice
        would be redundant and stop_voice would tear it down prematurely.
        """
        vm = _make_vm(socket, mode=VoiceMode.PUSH_TO_TALK, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)
        socket.emitted.clear()

        await vm.start_recording()
        assert ("start_voice", None) not in socket.emitted

    @pytest.mark.asyncio
    async def test_ptt_start_recording_does_not_republish_track(
        self, socket: FakeSocketManager
    ) -> None:
        """start_recording() should NOT re-publish the track (already published in start())."""
        vm = _make_vm(socket, mode=VoiceMode.PUSH_TO_TALK, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)

        room: FakeRoom = vm._room
        # start() publishes once
        assert len(room.local_participant.published_tracks) == 1

        await vm.start_recording()
        # Should still be exactly 1 (no re-publish)
        assert len(room.local_participant.published_tracks) == 1

    @pytest.mark.asyncio
    async def test_ptt_stop_recording_does_not_emit_stop_voice(
        self, socket: FakeSocketManager
    ) -> None:
        """stop_recording() in LiveKit PTT should NOT emit stop_voice.

        Deepgram connection is owned by livekit_join; tearing it down on each
        PTT release causes 'No Deepgram connection' errors when LiveKit audio
        frames continue arriving.
        """
        vm = _make_vm(socket, mode=VoiceMode.PUSH_TO_TALK, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)
        await vm.start_recording()
        socket.emitted.clear()

        await vm.stop_recording()
        assert ("stop_voice", None) not in socket.emitted

    @pytest.mark.asyncio
    async def test_ptt_audio_blocked_before_start_recording(
        self, socket: FakeSocketManager
    ) -> None:
        """send_audio() in PTT mode before start_recording() should capture zero frames."""
        vm = _make_vm(socket, mode=VoiceMode.PUSH_TO_TALK, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)

        # Send audio without start_recording — should be blocked
        audio_data = b"\x01\x00" * 160  # 10ms at 16kHz
        await vm.send_audio(audio_data)
        assert len(vm._audio_source.captured_frames) == 0

    @pytest.mark.asyncio
    async def test_ptt_audio_flows_between_start_stop_recording(
        self, socket: FakeSocketManager
    ) -> None:
        """send_audio() should capture frames after start_recording, not after stop_recording."""
        vm = _make_vm(socket, mode=VoiceMode.PUSH_TO_TALK, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)

        # After start_recording, audio should flow
        await vm.start_recording()
        audio_data = b"\x01\x00" * 160
        await vm.send_audio(audio_data)
        assert len(vm._audio_source.captured_frames) == 1

        # After stop_recording, audio should be blocked again
        await vm.stop_recording()
        await vm.send_audio(audio_data)
        assert len(vm._audio_source.captured_frames) == 1  # Still 1, no new capture

    @pytest.mark.asyncio
    async def test_start_recording_noop_in_continuous_mode(
        self, socket: FakeSocketManager
    ) -> None:
        """start_recording() in CONTINUOUS mode should be a no-op (no start_voice emitted)."""
        vm = _make_vm(socket, mode=VoiceMode.CONTINUOUS, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)
        socket.emitted.clear()

        await vm.start_recording()
        # No start_voice should have been emitted
        events = [e for e, _ in socket.emitted]
        assert "start_voice" not in events

    @pytest.mark.asyncio
    async def test_start_recording_when_not_active_warns(
        self, socket: FakeSocketManager
    ) -> None:
        """start_recording() when voice is not active should log warning and return safely."""
        vm = _make_vm(socket, mode=VoiceMode.PUSH_TO_TALK, livekit_token=TOKEN)
        # Don't start the VM — voice is not active
        socket.emitted.clear()

        await vm.start_recording()
        # No emit, no crash
        events = [e for e, _ in socket.emitted]
        assert "start_voice" not in events


class TestLiveKitVoiceAEC:
    """Tests for AudioProcessingModule (APM) integration."""

    @pytest.mark.asyncio
    async def test_apm_created_on_start(self, socket: FakeSocketManager) -> None:
        """APM should be created during start() with all processing enabled."""
        vm = _make_vm(socket, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)

        assert vm._apm is not None
        assert isinstance(vm._apm, FakeAudioProcessingModule)
        assert vm._apm.echo_cancellation is True
        assert vm._apm.noise_suppression is True
        assert vm._apm.auto_gain_control is True
        assert vm._apm.high_pass_filter is True

    @pytest.mark.asyncio
    async def test_apm_cleaned_up_on_stop(self, socket: FakeSocketManager) -> None:
        """APM should be set to None after stop()."""
        vm = _make_vm(socket, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)
        assert vm._apm is not None

        await vm.stop()
        assert vm._apm is None

    @pytest.mark.asyncio
    async def test_send_audio_processes_through_apm(self, socket: FakeSocketManager) -> None:
        """Sending exactly 320 bytes (10ms at 16kHz) should process one frame through APM."""
        vm = _make_vm(socket, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)

        # 320 bytes = 160 int16 samples = 10ms at 16kHz
        audio_data = b"\x01\x00" * 160
        await vm.send_audio(audio_data)

        apm: FakeAudioProcessingModule = vm._apm
        assert len(apm.processed_frames) == 1
        # Frame should also have been captured
        assert len(vm._audio_source.captured_frames) == 1

    @pytest.mark.asyncio
    async def test_send_audio_chunks_larger_frames(self, socket: FakeSocketManager) -> None:
        """Sending 640 bytes (20ms) should process two 10ms frames through APM."""
        vm = _make_vm(socket, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)

        # 640 bytes = 320 int16 samples = 20ms at 16kHz
        audio_data = b"\x02\x00" * 320
        await vm.send_audio(audio_data)

        apm: FakeAudioProcessingModule = vm._apm
        assert len(apm.processed_frames) == 2
        # Should have captured a frame (combined processed output)
        assert len(vm._audio_source.captured_frames) == 1

    @pytest.mark.asyncio
    async def test_send_audio_buffers_partial_frames(self, socket: FakeSocketManager) -> None:
        """Sending 200 bytes (< 10ms) should buffer without processing or capturing."""
        vm = _make_vm(socket, livekit_token=TOKEN)
        await _start_vm_with_ready(vm, socket)

        # 200 bytes = 100 int16 samples < 160 samples (10ms at 16kHz)
        audio_data = b"\x03\x00" * 100
        await vm.send_audio(audio_data)

        apm: FakeAudioProcessingModule = vm._apm
        assert len(apm.processed_frames) == 0
        assert len(vm._audio_source.captured_frames) == 0

    @pytest.mark.asyncio
    async def test_receive_audio_processes_reverse_stream(
        self, socket: FakeSocketManager
    ) -> None:
        """Received far-end audio should be processed through APM reverse stream."""
        received: list[bytes] = []

        async def on_audio(data: bytes) -> None:
            received.append(data)

        vm = _make_vm(socket, livekit_token=TOKEN, on_audio_received=on_audio)
        await _start_vm_with_ready(vm, socket)

        # Provide 480 int16 samples at 48kHz (960 bytes).
        # Decimated 3:1 = 160 int16 samples = 320 bytes = exactly one 10ms chunk at 16kHz.
        import struct

        raw_48k = struct.pack("<480h", *range(480))
        fake_frame = SimpleNamespace(data=SimpleNamespace(tobytes=lambda: raw_48k))
        remote_track = FakeRemoteAudioTrack(frames=[fake_frame])

        room: FakeRoom = vm._room
        room.simulate_track_subscribed(remote_track)
        await asyncio.sleep(0.05)

        apm: FakeAudioProcessingModule = vm._apm
        # Decimated to 160 samples (320 bytes) = 1 reverse APM chunk
        assert len(apm.reverse_frames) == 1
        # Callback should still have been called
        assert len(received) == 1
