"""Tests for EstuaryClient public API surface."""

import pytest
from estuary_sdk import ErrorCode, EstuaryClient, EstuaryConfig, EstuaryError


@pytest.fixture
def config() -> EstuaryConfig:
    return EstuaryConfig(
        server_url="http://localhost:4001",
        api_key="est_test_key",
        character_id="test-char-id",
        player_id="test-player",
    )


class TestEstuaryClientInit:
    def test_creates_client(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        assert not client.is_connected
        assert client.session is None
        assert not client.is_voice_active
        assert not client.is_muted

    def test_config_defaults(self) -> None:
        config = EstuaryConfig(
            server_url="http://localhost:4001",
            api_key="key",
            character_id="char",
            player_id="player",
        )
        assert config.audio_sample_rate == 16000
        assert config.auto_reconnect is True
        assert config.max_reconnect_attempts == 5
        assert config.reconnect_delay == 1.0
        assert config.debug is False
        assert config.voice_transport == "websocket"
        assert config.realtime_memory is False


class TestEstuaryClientNotConnected:
    def test_send_text_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            client.send_text("hello")
        assert exc_info.value.code == ErrorCode.NOT_CONNECTED

    def test_interrupt_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            client.interrupt()
        assert exc_info.value.code == ErrorCode.NOT_CONNECTED

    def test_send_camera_image_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            client.send_camera_image("base64data", "image/jpeg")
        assert exc_info.value.code == ErrorCode.NOT_CONNECTED

    def test_memory_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            _ = client.memory
        assert exc_info.value.code == ErrorCode.NOT_CONNECTED

    @pytest.mark.asyncio
    async def test_start_voice_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            await client.start_voice()
        assert exc_info.value.code == ErrorCode.NOT_CONNECTED

    @pytest.mark.asyncio
    async def test_start_recording_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            await client.start_recording()
        assert exc_info.value.code == ErrorCode.VOICE_NOT_ACTIVE

    @pytest.mark.asyncio
    async def test_send_audio_raises(self, config: EstuaryConfig) -> None:
        client = EstuaryClient(config)
        with pytest.raises(EstuaryError) as exc_info:
            await client.send_audio(b"\x00")
        assert exc_info.value.code == ErrorCode.VOICE_NOT_ACTIVE


class TestEstuaryClientContextManager:
    @pytest.mark.asyncio
    async def test_context_manager(self, config: EstuaryConfig) -> None:
        async with EstuaryClient(config) as client:
            assert not client.is_connected
        # After exit, client should be cleaned up (no error)
