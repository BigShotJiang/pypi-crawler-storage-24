from __future__ import annotations

import struct
from unittest.mock import patch

import numpy as np
import pytest

from estuary_sdk.audio.recorder import AudioRecorder


class TestResolveDeviceRate:
    """Tests for _resolve_device_rate() sample rate negotiation."""

    def _make_recorder(self) -> AudioRecorder:
        return AudioRecorder(sample_rate=16000, on_audio=None)

    def test_target_rate_supported(self) -> None:
        recorder = self._make_recorder()
        with patch("estuary_sdk.audio.recorder.sd") as mock_sd:
            mock_sd.check_input_settings = lambda **kw: None
            assert recorder._resolve_device_rate() == 16000

    def test_fallback_to_48k(self) -> None:
        recorder = self._make_recorder()

        def check_input_settings(**kwargs: object) -> None:
            rate = kwargs["samplerate"]
            if rate == 16000:
                raise Exception("unsupported")

        with patch("estuary_sdk.audio.recorder.sd") as mock_sd:
            mock_sd.check_input_settings = check_input_settings
            assert recorder._resolve_device_rate() == 48000

    def test_fallback_to_44100(self) -> None:
        recorder = self._make_recorder()
        supported = {44100}

        def check_input_settings(**kwargs: object) -> None:
            if kwargs["samplerate"] not in supported:
                raise Exception("unsupported")

        with patch("estuary_sdk.audio.recorder.sd") as mock_sd:
            mock_sd.check_input_settings = check_input_settings
            assert recorder._resolve_device_rate() == 44100

    def test_no_supported_rate_raises(self) -> None:
        recorder = self._make_recorder()

        def check_input_settings(**kwargs: object) -> None:
            raise Exception("unsupported")

        with patch("estuary_sdk.audio.recorder.sd") as mock_sd:
            mock_sd.check_input_settings = check_input_settings
            with pytest.raises(RuntimeError, match="No supported input sample rate"):
                recorder._resolve_device_rate()


class TestResampleInt16:
    """Tests for _resample_int16() static method."""

    def test_integer_ratio_decimation(self) -> None:
        # 48kHz -> 16kHz = factor 3
        samples_48k = np.array([100, 200, 300, 400, 500, 600], dtype=np.int16)
        data = samples_48k.tobytes()

        result = AudioRecorder._resample_int16(data, 48000, 16000)

        out = np.frombuffer(result, dtype=np.int16)
        assert len(out) == 2  # 6 / 3
        np.testing.assert_array_equal(out, [100, 400])

    def test_integer_ratio_2x(self) -> None:
        # 32kHz -> 16kHz = factor 2
        samples = np.array([10, 20, 30, 40], dtype=np.int16)
        result = AudioRecorder._resample_int16(samples.tobytes(), 32000, 16000)
        out = np.frombuffer(result, dtype=np.int16)
        assert len(out) == 2
        np.testing.assert_array_equal(out, [10, 30])

    def test_non_integer_ratio_output_length(self) -> None:
        # 44100 -> 16000: non-integer ratio
        n_samples = 882  # 20ms at 44.1kHz
        samples = np.arange(n_samples, dtype=np.int16)
        result = AudioRecorder._resample_int16(samples.tobytes(), 44100, 16000)
        out = np.frombuffer(result, dtype=np.int16)
        expected_len = int(n_samples * 16000 / 44100)
        assert len(out) == expected_len

    def test_no_resample_needed(self) -> None:
        # Same rate — integer ratio factor 1
        samples = np.array([1, 2, 3, 4], dtype=np.int16)
        result = AudioRecorder._resample_int16(samples.tobytes(), 16000, 16000)
        out = np.frombuffer(result, dtype=np.int16)
        np.testing.assert_array_equal(out, samples)

    def test_96k_decimation(self) -> None:
        # 96kHz -> 16kHz = factor 6
        samples = np.arange(12, dtype=np.int16)
        result = AudioRecorder._resample_int16(samples.tobytes(), 96000, 16000)
        out = np.frombuffer(result, dtype=np.int16)
        assert len(out) == 2
        np.testing.assert_array_equal(out, [0, 6])


class TestDeviceSampleRateProperty:
    def test_default_matches_target(self) -> None:
        recorder = AudioRecorder(sample_rate=16000, on_audio=None)
        assert recorder.device_sample_rate == 16000
