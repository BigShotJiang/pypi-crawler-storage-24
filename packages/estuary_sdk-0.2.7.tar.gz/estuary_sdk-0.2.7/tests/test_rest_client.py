"""Tests for RestClient HTTP methods."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
from estuary_sdk.errors import ErrorCode, EstuaryError
from estuary_sdk.rest.rest_client import RestClient


def _make_response(status: int = 200, json_data: dict[str, Any] | None = None) -> MagicMock:
    """Create a mock aiohttp response with async context manager support."""
    resp = MagicMock()
    resp.status = status
    resp.json = AsyncMock(return_value=json_data or {})
    resp.text = AsyncMock(return_value="error body")
    return resp


def _make_session(response: MagicMock) -> MagicMock:
    """Create a mock aiohttp.ClientSession that returns the given response."""
    ctx = MagicMock()
    ctx.__aenter__ = AsyncMock(return_value=response)
    ctx.__aexit__ = AsyncMock(return_value=False)

    session = MagicMock()
    session.closed = False
    session.request = MagicMock(return_value=ctx)
    return session


class TestRestClientGet:
    @pytest.mark.asyncio
    async def test_get_success(self) -> None:
        resp = _make_response(200, {"key": "value"})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        result = await client.get("/api/test", params={"q": "hello"})

        assert result == {"key": "value"}
        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params={"q": "hello"},
            json=None,
        )

    @pytest.mark.asyncio
    async def test_get_error_raises(self) -> None:
        resp = _make_response(404)
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        with pytest.raises(EstuaryError) as exc_info:
            await client.get("/api/missing")
        assert exc_info.value.code == ErrorCode.REST_ERROR


class TestRestClientPost:
    @pytest.mark.asyncio
    async def test_post_success(self) -> None:
        resp = _make_response(201, {"id": "new-1"})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        result = await client.post("/api/items", body={"name": "test"})

        assert result == {"id": "new-1"}
        session.request.assert_called_once_with(
            "POST",
            "http://localhost:4001/api/items",
            params=None,
            json={"name": "test"},
        )

    @pytest.mark.asyncio
    async def test_post_error_raises(self) -> None:
        resp = _make_response(500)
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        with pytest.raises(EstuaryError) as exc_info:
            await client.post("/api/items", body={})
        assert exc_info.value.code == ErrorCode.REST_ERROR


class TestRestClientPut:
    @pytest.mark.asyncio
    async def test_put_success(self) -> None:
        resp = _make_response(200, {"id": "1", "updated": True})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        result = await client.put("/api/items/1", body={"name": "updated"})

        assert result == {"id": "1", "updated": True}
        session.request.assert_called_once_with(
            "PUT",
            "http://localhost:4001/api/items/1",
            params=None,
            json={"name": "updated"},
        )

    @pytest.mark.asyncio
    async def test_put_error_raises(self) -> None:
        resp = _make_response(400)
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        with pytest.raises(EstuaryError) as exc_info:
            await client.put("/api/items/1", body={})
        assert exc_info.value.code == ErrorCode.REST_ERROR


class TestRestClientPatch:
    @pytest.mark.asyncio
    async def test_patch_success(self) -> None:
        resp = _make_response(200, {"id": "1", "name": "patched"})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        result = await client.patch("/api/items/1", body={"name": "patched"})

        assert result == {"id": "1", "name": "patched"}
        session.request.assert_called_once_with(
            "PATCH",
            "http://localhost:4001/api/items/1",
            params=None,
            json={"name": "patched"},
        )

    @pytest.mark.asyncio
    async def test_patch_error_raises(self) -> None:
        resp = _make_response(422)
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        with pytest.raises(EstuaryError) as exc_info:
            await client.patch("/api/items/1", body={})
        assert exc_info.value.code == ErrorCode.REST_ERROR


class TestRestClientDelete:
    @pytest.mark.asyncio
    async def test_delete_success(self) -> None:
        resp = _make_response(200, {"deleted": True})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        result = await client.delete("/api/items/1")

        assert result == {"deleted": True}
        session.request.assert_called_once_with(
            "DELETE",
            "http://localhost:4001/api/items/1",
            params=None,
            json=None,
        )


class TestRestClientParamSanitization:
    @pytest.mark.asyncio
    async def test_sanitizes_bool_true_to_string(self) -> None:
        resp = _make_response(200, {"ok": True})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        await client.get("/api/test", params={"flag": True})

        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params={"flag": "true"},
            json=None,
        )

    @pytest.mark.asyncio
    async def test_sanitizes_bool_false_to_string(self) -> None:
        resp = _make_response(200, {"ok": True})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        await client.get("/api/test", params={"flag": False})

        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params={"flag": "false"},
            json=None,
        )

    @pytest.mark.asyncio
    async def test_non_bool_params_unchanged(self) -> None:
        resp = _make_response(200, {})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        await client.get("/api/test", params={"q": "hello", "limit": 10})

        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params={"q": "hello", "limit": 10},
            json=None,
        )

    @pytest.mark.asyncio
    async def test_mixed_params_converts_only_bools(self) -> None:
        resp = _make_response(200, {})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        await client.get("/api/test", params={"flag": True, "q": "test", "n": 5})

        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params={"flag": "true", "q": "test", "n": 5},
            json=None,
        )

    @pytest.mark.asyncio
    async def test_none_params_pass_through(self) -> None:
        resp = _make_response(200, {})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001", "test-key")
        client._session = session

        await client.get("/api/test", params=None)

        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params=None,
            json=None,
        )


class TestRestClientBaseUrl:
    @pytest.mark.asyncio
    async def test_strips_trailing_slash(self) -> None:
        resp = _make_response(200, {})
        session = _make_session(resp)
        client = RestClient("http://localhost:4001/", "test-key")
        client._session = session

        await client.get("/api/test")

        session.request.assert_called_once_with(
            "GET",
            "http://localhost:4001/api/test",
            params=None,
            json=None,
        )
