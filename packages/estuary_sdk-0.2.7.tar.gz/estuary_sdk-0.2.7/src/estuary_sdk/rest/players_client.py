from __future__ import annotations

from typing import Any

from estuary_sdk.rest.rest_client import RestClient
from estuary_sdk.types import (
    PlayerConversation,
    PlayerConversationList,
    PlayerMessageList,
    PlayerStats,
)


class PlayersClient:
    """Client for the Estuary Players REST API.

    Base path: /api/agents/{agent_id}/players
    """

    def __init__(self, rest: RestClient, agent_id: str) -> None:
        self._rest = rest
        self._base = f"/api/agents/{agent_id}/players"

    async def get_stats(self) -> PlayerStats:
        """Get aggregate player statistics for this agent."""
        data = await self._rest.get(f"{self._base}/stats")
        return PlayerStats.from_dict(data)

    async def list(
        self,
        limit: int = 50,
        offset: int = 0,
        sort_by: str = "last_activity",
        sort_order: str = "desc",
        player_search: str | None = None,
        min_messages: int | None = None,
    ) -> PlayerConversationList:
        """List player conversations with optional filtering and pagination."""
        params: dict[str, Any] = {
            "limit": limit,
            "offset": offset,
            "sort_by": sort_by,
            "sort_order": sort_order,
        }
        if player_search is not None:
            params["player_search"] = player_search
        if min_messages is not None:
            params["min_messages"] = min_messages
        data = await self._rest.get(self._base, params=params)
        return PlayerConversationList.from_dict(data)

    async def get(self, player_id: str) -> PlayerConversation:
        """Get a single player conversation by player ID."""
        data = await self._rest.get(f"{self._base}/{player_id}")
        return PlayerConversation.from_dict(data)

    async def get_messages(
        self,
        player_id: str,
        limit: int = 100,
        page: int = 1,
    ) -> PlayerMessageList:
        """Get messages for a player conversation."""
        params: dict[str, Any] = {"limit": limit, "page": page}
        data = await self._rest.get(f"{self._base}/{player_id}/messages", params=params)
        return PlayerMessageList.from_dict(data)

    async def delete(self, player_id: str) -> dict[str, Any]:
        """Delete a player and all associated data."""
        data = await self._rest.delete(f"{self._base}/{player_id}")
        return data
