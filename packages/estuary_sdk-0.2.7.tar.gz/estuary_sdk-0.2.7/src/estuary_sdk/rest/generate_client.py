from __future__ import annotations

import aiohttp

from estuary_sdk.rest.rest_client import RestClient
from estuary_sdk.types import GeneratedCharacter, ModelStatus


class GenerateClient:
    """Client for the Estuary character generation REST API."""

    def __init__(self, rest: RestClient, player_id: str) -> None:
        self._rest = rest
        self._player_id = player_id

    async def image_to_character(
        self,
        image: bytes,
        mime_type: str = "image/jpeg",
    ) -> GeneratedCharacter:
        """Upload an image to generate an AI character.

        Returns the created character immediately. Poll get_model_status()
        for 3D model progress.

        Args:
            image: Raw image bytes (JPEG, PNG, or WebP).
            mime_type: Image MIME type.
        """
        form = aiohttp.FormData()
        form.add_field(
            "image",
            image,
            filename="image.jpg",
            content_type=mime_type,
        )
        data = await self._rest.post_form(
            "/api/generate/image-to-character",
            data=form,
            headers={"X-Player-Id": self._player_id},
        )
        return GeneratedCharacter.from_dict(data)

    async def get_model_status(self, agent_id: str) -> ModelStatus:
        """Poll 3D model generation progress for a character.

        Args:
            agent_id: The character/agent ID returned by image_to_character().
        """
        data = await self._rest.get(f"/api/generate/{agent_id}/model-status")
        return ModelStatus.from_dict(data)
