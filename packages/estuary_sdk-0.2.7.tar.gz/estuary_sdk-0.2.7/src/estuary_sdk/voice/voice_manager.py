from __future__ import annotations

import logging
from typing import Awaitable, Callable, Protocol, runtime_checkable

from estuary_sdk.connection.socket_manager import SocketManager
from estuary_sdk.types import LiveKitTokenResponse, VoiceMode

logger = logging.getLogger("estuary_sdk")


@runtime_checkable
class VoiceManager(Protocol):
    """Protocol for voice manager implementations."""

    async def start(self) -> None: ...
    async def stop(self) -> None: ...
    def toggle_mute(self) -> None: ...

    @property
    def is_muted(self) -> bool: ...

    @property
    def is_active(self) -> bool: ...

    async def start_recording(self) -> None: ...
    async def stop_recording(self) -> None: ...
    async def send_audio(self, audio: bytes) -> None: ...
    async def dispose(self) -> None: ...


def create_voice_manager(
    transport: str,
    socket_manager: SocketManager,
    sample_rate: int,
    voice_mode: VoiceMode,
    on_audio_received: Callable[[bytes], Awaitable[None]] | None = None,
    livekit_token: LiveKitTokenResponse | None = None,
    start_timeout: float = 10.0,
) -> VoiceManager:
    """Factory to create the appropriate voice manager based on transport."""
    if transport == "livekit":
        try:
            from estuary_sdk.voice.livekit_voice import LiveKitVoiceManager

            return LiveKitVoiceManager(
                socket_manager=socket_manager,
                sample_rate=sample_rate,
                voice_mode=voice_mode,
                start_timeout=start_timeout,
                on_audio_received=on_audio_received,
                livekit_token=livekit_token,
            )
        except ImportError:
            logger.warning(
                "livekit package not installed, falling back to websocket voice. "
                "Install with: pip install estuary-sdk[livekit]"
            )

    from estuary_sdk.voice.websocket_voice import WebSocketVoiceManager

    return WebSocketVoiceManager(
        socket_manager=socket_manager,
        sample_rate=sample_rate,
        voice_mode=voice_mode,
    )
