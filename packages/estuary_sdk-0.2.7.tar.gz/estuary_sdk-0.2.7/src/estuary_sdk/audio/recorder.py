from __future__ import annotations

import asyncio
import concurrent.futures
import logging
from typing import Awaitable, Callable

logger = logging.getLogger("estuary_sdk")

try:
    import numpy as np
    import sounddevice as sd

    HAS_AUDIO = True
except ImportError:
    HAS_AUDIO = False


class AudioRecorder:
    """Captures audio from the microphone as PCM16 bytes.

    Requires the `audio` optional dependency:
        pip install estuary-sdk[audio]
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        on_audio: Callable[[bytes], Awaitable[None]] | None = None,
    ) -> None:
        if not HAS_AUDIO:
            raise ImportError(
                "sounddevice and numpy are required for audio recording. "
                "Install with: pip install estuary-sdk[audio]"
            )
        self._target_rate = sample_rate
        self._device_rate: int = sample_rate
        self._on_audio = on_audio
        self._stream: sd.InputStream | None = None  # type: ignore[name-defined]
        self._recording = False
        self._loop: asyncio.AbstractEventLoop | None = None

    @property
    def is_recording(self) -> bool:
        return self._recording

    @property
    def device_sample_rate(self) -> int:
        """The actual sample rate negotiated with the audio device."""
        return self._device_rate

    def _resolve_device_rate(self) -> int:
        """Determine a supported input sample rate for the default device.

        Tries the target rate first, then probes common rates (preferring
        integer multiples of the target for cheap decimation).
        """
        probe_rates = [48000, 32000, 96000, 44100, 22050]

        # Try target rate first
        try:
            sd.check_input_settings(  # type: ignore[attr-defined]
                samplerate=self._target_rate, channels=1, dtype="int16"
            )
            return self._target_rate
        except Exception:
            pass

        for rate in probe_rates:
            if rate == self._target_rate:
                continue
            try:
                sd.check_input_settings(  # type: ignore[attr-defined]
                    samplerate=rate, channels=1, dtype="int16"
                )
                logger.info(
                    "Device does not support %d Hz, using %d Hz (will resample)",
                    self._target_rate,
                    rate,
                )
                return rate
            except Exception:
                continue

        raise RuntimeError(
            f"No supported input sample rate found (tried {self._target_rate} and {probe_rates})"
        )

    @staticmethod
    def _resample_int16(data: bytes, device_rate: int, target_rate: int) -> bytes:
        """Resample PCM16 audio from device_rate to target_rate."""
        if device_rate % target_rate == 0:
            # Integer ratio — simple decimation
            factor = device_rate // target_rate
            return memoryview(data).cast("h")[::factor].tobytes()
        # Non-integer ratio — numpy linear interpolation
        samples = np.frombuffer(data, dtype=np.int16)
        out_len = int(len(samples) * target_rate / device_rate)
        indices = np.linspace(0, len(samples) - 1, out_len)
        resampled = np.interp(indices, np.arange(len(samples)), samples.astype(np.float64))
        return resampled.astype(np.int16).tobytes()

    async def start(self) -> None:
        """Start capturing audio from the default input device."""
        if self._recording:
            return

        self._loop = asyncio.get_event_loop()
        self._recording = True

        self._device_rate = self._resolve_device_rate()

        # 20ms frames for low latency
        blocksize = self._device_rate // 50

        self._stream = sd.InputStream(  # type: ignore[attr-defined]
            samplerate=self._device_rate,
            channels=1,
            dtype="int16",
            blocksize=blocksize,
            callback=self._audio_callback,
        )
        self._stream.start()
        logger.debug("Audio recorder started (rate=%d)", self._device_rate)

    async def stop(self) -> None:
        """Stop capturing audio."""
        if not self._recording:
            return

        self._recording = False
        if self._stream:
            self._stream.stop()
            self._stream.close()
            self._stream = None
        logger.debug("Audio recorder stopped")

    def _audio_callback(
        self,
        indata: np.ndarray,  # type: ignore[name-defined]
        frames: int,
        time_info: object,
        status: object,
    ) -> None:
        """Called by sounddevice from the audio thread."""
        if not self._recording or self._on_audio is None or self._loop is None:
            return
        audio_bytes = indata.tobytes()
        if self._device_rate != self._target_rate:
            audio_bytes = self._resample_int16(
                audio_bytes, self._device_rate, self._target_rate
            )
        fut: concurrent.futures.Future[None] = asyncio.run_coroutine_threadsafe(
            self._on_audio(audio_bytes), self._loop  # type: ignore[arg-type]
        )
        fut.add_done_callback(AudioRecorder._handle_audio_error)

    @staticmethod
    def _handle_audio_error(fut: concurrent.futures.Future[None]) -> None:
        try:
            fut.result()
        except Exception:
            logger.exception("Error in audio callback")
