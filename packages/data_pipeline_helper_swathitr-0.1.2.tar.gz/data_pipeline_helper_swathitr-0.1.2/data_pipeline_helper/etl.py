# PyPI and PIP 

import pandas as pd

def load_csv_to_dataframe(file_path):
    return pd.read_csv(file_path)

def save_dataframe_to_csv(df, file_path, index=False):
    df.to_csv(file_path, index=index)