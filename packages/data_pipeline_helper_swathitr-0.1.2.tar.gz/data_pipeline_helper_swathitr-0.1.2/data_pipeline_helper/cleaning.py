# PyPI and PIP 

import pandas as pd

def remove_null_values(df, column):
    return df.dropna(subset=column)

def remove_duplicates(df, subset = None):
    return df.drop_duplicates(subset=subset)