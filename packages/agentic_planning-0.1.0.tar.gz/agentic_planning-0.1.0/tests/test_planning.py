"""Comprehensive tests for AgenticPlanning Python SDK.

This file tests PlanningGraph and PlanningError.
Does NOT replace test_planning_graph.py -- this is an additional test file.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path, PurePosixPath
from unittest.mock import patch, MagicMock

import pytest

from agentic_planning import PlanningGraph, PlanningError, __version__


# ---------------------------------------------------------------------------
# 1. Package Metadata
# ---------------------------------------------------------------------------


class TestPackageMetadata:
    def test_version_exists(self) -> None:
        assert __version__ is not None
        assert isinstance(__version__, str)
        assert len(__version__) > 0

    def test_version_semver(self) -> None:
        parts = __version__.split(".")
        assert len(parts) == 3
        assert all(p.isdigit() for p in parts)

    def test_version_is_010(self) -> None:
        assert __version__ == "0.1.0"

    def test_import_main_class(self) -> None:
        assert PlanningGraph is not None

    def test_import_error_class(self) -> None:
        assert PlanningError is not None
        assert issubclass(PlanningError, Exception)

    def test_main_class_has_docstring(self) -> None:
        # PlanningGraph is a dataclass; it may not have a long docstring
        # but it should at least be importable and functional
        assert PlanningGraph is not None


# ---------------------------------------------------------------------------
# 2. Initialization
# ---------------------------------------------------------------------------


class TestInit:
    def test_create_with_string_path(self, tmp_path: Path) -> None:
        path = str(tmp_path / "test.aplan")
        obj = PlanningGraph(path)
        assert str(obj.path) == path

    def test_create_with_path_object(self, tmp_path: Path) -> None:
        path = tmp_path / "test.aplan"
        obj = PlanningGraph(path)
        assert obj.path == path

    def test_create_with_pure_posix_path(self) -> None:
        obj = PlanningGraph(PurePosixPath("/tmp/test.aplan"))
        assert "test.aplan" in str(obj.path)

    def test_path_converted_to_path_object(self, tmp_path: Path) -> None:
        path = str(tmp_path / "test.aplan")
        obj = PlanningGraph(path)
        assert isinstance(obj.path, Path)

    def test_custom_binary_name(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "test.aplan"), binary="custom-bin")
        assert obj.binary == "custom-bin"

    def test_default_binary_name(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "test.aplan"))
        assert obj.binary == "aplan"

    def test_exists_false_for_new(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "nonexistent.aplan"))
        assert not obj.exists

    def test_exists_true_when_file_present(self, tmp_path: Path) -> None:
        path = tmp_path / "exists.aplan"
        path.touch()
        obj = PlanningGraph(str(path))
        assert obj.exists

    def test_repr_does_not_crash(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "test.aplan"))
        r = repr(obj)
        assert isinstance(r, str)

    def test_path_name_preserved(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "test.aplan"))
        assert obj.path.name == "test.aplan"


# ---------------------------------------------------------------------------
# 3. Binary Resolution
# ---------------------------------------------------------------------------


class TestBinaryResolution:
    def test_missing_binary_raises(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"), binary="nonexistent-xyz-999")
        with pytest.raises(PlanningError):
            obj._binary()

    def test_error_contains_binary_name(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"), binary="nonexistent-xyz-999")
        with pytest.raises(PlanningError, match="nonexistent-xyz-999"):
            obj._binary()

    def test_error_contains_install_hint(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"), binary="nonexistent-xyz-999")
        with pytest.raises(PlanningError, match="install"):
            obj._binary()

    def test_binary_returns_string(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch("shutil.which", return_value="/usr/bin/aplan"):
            result = obj._binary()
            assert isinstance(result, str)
            assert result == "/usr/bin/aplan"

    def test_binary_uses_shutil_which(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch("shutil.which", return_value="/opt/bin/aplan") as mock_which:
            result = obj._binary()
            mock_which.assert_called_with("aplan")
            assert result == "/opt/bin/aplan"


# ---------------------------------------------------------------------------
# 4. Subprocess Execution
# ---------------------------------------------------------------------------


class TestSubprocessExecution:
    def test_run_json_calls_subprocess(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch("shutil.which", return_value="/usr/bin/echo"), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout='{"key": "value"}\n', stderr=""
            )
            result = obj._run_json("test")
            assert mock_run.called
            cmd = mock_run.call_args[0][0]
            assert cmd[0] == "/usr/bin/echo"

    def test_run_json_includes_file_flag(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch("shutil.which", return_value="/usr/bin/echo"), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout='{"k": 1}\n', stderr=""
            )
            obj._run_json("test")
            cmd = mock_run.call_args[0][0]
            assert "--file" in cmd
            assert str(tmp_path / "t.aplan") in cmd

    def test_run_json_raises_on_nonzero_exit(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch("shutil.which", return_value="/bin/false"), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=1, stdout="", stderr="error happened"
            )
            with pytest.raises(PlanningError, match="error happened"):
                obj._run_json("fail")

    def test_run_json_parses_output(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch("shutil.which", return_value="/usr/bin/echo"), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout='{"key": "value"}\n', stderr=""
            )
            result = obj._run_json("test")
            assert result == {"key": "value"}

    def test_run_json_returns_empty_dict_on_empty_output(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch("shutil.which", return_value="/usr/bin/echo"), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout="", stderr=""
            )
            result = obj._run_json("test")
            assert result == {}

    def test_run_json_raises_on_invalid_json(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch("shutil.which", return_value="/usr/bin/echo"), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout="not json at all", stderr=""
            )
            with pytest.raises((json.JSONDecodeError, PlanningError)):
                obj._run_json("test")

    def test_run_json_error_with_empty_stderr_uses_fallback(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch("shutil.which", return_value="/bin/false"), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=1, stdout="", stderr=""
            )
            with pytest.raises(PlanningError, match="aplan command failed"):
                obj._run_json("fail")


# ---------------------------------------------------------------------------
# 5. Edge Cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_empty_path(self) -> None:
        obj = PlanningGraph("")
        assert isinstance(obj.path, Path)

    def test_path_with_spaces(self, tmp_path: Path) -> None:
        path = tmp_path / "path with spaces" / "test.aplan"
        obj = PlanningGraph(str(path))
        assert "spaces" in str(obj.path)

    def test_path_with_unicode(self, tmp_path: Path) -> None:
        path = tmp_path / "donnees" / "test.aplan"
        obj = PlanningGraph(str(path))
        assert "donnees" in str(obj.path)

    def test_very_long_path(self, tmp_path: Path) -> None:
        long_name = "a" * 200
        path = tmp_path / long_name / "test.aplan"
        obj = PlanningGraph(str(path))
        assert len(str(obj.path)) > 200

    def test_multiple_instances_independent(self, tmp_path: Path) -> None:
        a = PlanningGraph(str(tmp_path / "a.aplan"))
        b = PlanningGraph(str(tmp_path / "b.aplan"))
        assert a.path != b.path

    def test_dot_in_directory_name(self, tmp_path: Path) -> None:
        path = tmp_path / "v1.0.0" / "test.aplan"
        obj = PlanningGraph(str(path))
        assert "v1.0.0" in str(obj.path)

    def test_binary_not_cached_across_calls(self, tmp_path: Path) -> None:
        """PlanningGraph._binary() re-calls shutil.which every time (no caching)."""
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch("shutil.which", return_value="/usr/bin/aplan") as mock_which:
            obj._binary()
            obj._binary()
            assert mock_which.call_count == 2


# ---------------------------------------------------------------------------
# 6. Error Handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_error_is_exception(self) -> None:
        assert issubclass(PlanningError, Exception)

    def test_error_stores_message(self) -> None:
        err = PlanningError("test message")
        assert "test message" in str(err)

    def test_error_caught_as_exception(self) -> None:
        with pytest.raises(Exception):
            raise PlanningError("boom")

    def test_error_caught_specifically(self) -> None:
        try:
            raise PlanningError("specific")
        except PlanningError as e:
            assert "specific" in str(e)

    def test_error_repr(self) -> None:
        err = PlanningError("repr test")
        assert repr(err) is not None


# ---------------------------------------------------------------------------
# 7. High-Level API Methods
# ---------------------------------------------------------------------------


class TestAPIMethods:
    def test_create_goal_calls_run_json(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch.object(obj, "_run_json", return_value={"id": "g1"}) as mock:
            result = obj.create_goal("Build MVP", "ship by Friday")
            mock.assert_called_once_with("goal", "create", "Build MVP", "--intention", "ship by Friday")
            assert result == {"id": "g1"}

    def test_list_goals_calls_run_json(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch.object(obj, "_run_json", return_value=[{"id": "g1"}]) as mock:
            result = obj.list_goals()
            mock.assert_called_once_with("goal", "list")
            assert result == [{"id": "g1"}]


# ---------------------------------------------------------------------------
# 8. Stress Tests
# ---------------------------------------------------------------------------


class TestStress:
    def test_create_1000_instances(self, tmp_path: Path) -> None:
        instances = [
            PlanningGraph(str(tmp_path / f"test_{i}.aplan"))
            for i in range(1000)
        ]
        assert len(instances) == 1000
        assert instances[0].path != instances[999].path

    def test_binary_lookup_1000_times(self, tmp_path: Path) -> None:
        obj = PlanningGraph(str(tmp_path / "t.aplan"))
        with patch("shutil.which", return_value="/usr/bin/aplan"):
            for _ in range(1000):
                assert obj._binary() == "/usr/bin/aplan"

    def test_create_1000_errors(self) -> None:
        errors = [PlanningError(f"err_{i}") for i in range(1000)]
        assert len(errors) == 1000
        assert "err_999" in str(errors[999])
