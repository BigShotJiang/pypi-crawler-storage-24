import os

def get_template():
    templates = {}
    base_dir = os.path.dirname(os.path.abspath(__file__))
    target_dir = os.path.join(base_dir, "ex_layout")
    
    for ex in os.listdir(target_dir):
        with open(os.path.join(os.path.abspath(target_dir), ex), "r", encoding="utf-8") as file:
            templates[ex] = file.read()

    return templates


PROMPT_FOR_IMAGE_MODEL = """
Gemini said
Analyze the attached image focusing exclusively on its informational structure and content hierarchy, while completely ignoring the visual styling (colors, fonts, specific layout positioning, or decorative elements).
Your goal is to reverse-engineer the semantic skeleton of the content to understand what data is presented, not how it looks.
Output a structured breakdown covering:
Logical Sections: Identify all distinct content blocks (e.g., Headers, Footers, Main Content Areas, Sidebars) and their specific titles (e.g., "Project Goal," "Technical Stack," "Author").
But dont write any values, only topics.
Data Points & Text: Extract the key text, lists, bullet points, and descriptions contained within each section.
Information Hierarchy: Define the nesting of elements (e.g., "The 'Roadmap' section contains an unordered list of 3 items").

CRITICAL CONSTRAINTS:
DO NOT describe colors, hex codes, backgrounds, or gradients.
DO NOT mention font families, weights, or typographic styles.
DO NOT describe CSS properties (padding, margin, border-radius, shadow).
Final Output Format: Provide a clean, hierarchical outline (Markdown or JSON structure) representing the raw data model of the poster."""

PROMPT_FOR_TEXT_MODEL = f"""Role: You are a World-Class Graphic Designer and Creative Technologist. Your task is to output a FINAL, production-ready HTML/CSS poster.

BASE TEMPLATE:
{get_template()}

STRICT DESIGN RULES:
1. USE THE TEMPLATE: You must inject your content into the HTML structure provided above. Do not change the dimensions or core setup, but enhance the internal CSS for beauty.
2. 90% DENSITY: Information and design elements must occupy more than 90% of the poster area. 
3. AUTO-FILL LOGIC: If the user's information is sparse, you MUST automatically generate professional decorative content to fill space:
   - Technical 'System Data' blocks, geometric shapes, or grid lines.
   - Massive typography (e.g., font-size: 20vw) for key words.
   - Professional sub-headers, timestamps (2026), and "Design Spec" labels.
4. SWISS BRUTALISM: Use high-contrast colors (e.g., #000 and #FFF with one neon accent), bold grids, and premium typography (Google Fonts).

CONTENT TO RENDER:
[Здесь будет твой текст или переменная с контентом]

OUTPUT PROTOCOL:
- Start immediately with <!DOCTYPE html> (from the template).
- NO markdown blocks (no ```html).
- NO introduction, NO explanations, NO "Here is your poster".
- Every field must be filled. Never leave anything empty.
- Total silence except for the final HTML code."""