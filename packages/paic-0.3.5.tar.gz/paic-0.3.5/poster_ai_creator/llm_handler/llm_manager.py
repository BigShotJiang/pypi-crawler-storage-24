from .llm_models import BaseLLMModel



class LLMManager():
    def __init__(self, llm_model: BaseLLMModel):
        self.llm_model = llm_model

    def get_answer(self, prompt: str):
        return self.llm_model.get_answer(prompt)