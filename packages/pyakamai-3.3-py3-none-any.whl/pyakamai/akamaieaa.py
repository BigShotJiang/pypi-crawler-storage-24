# Python edgegrid module
""" Copyright 2015 Akamai Technologies, Inc. All Rights Reserved.

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.

 You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
"""
import sys
import os
import requests
import logging
import json
from akamai.edgegrid import EdgeGridAuth, EdgeRc
from .http_calls import EdgeGridHttpCaller
if sys.version_info[0] >= 3:
    # python3
    from urllib import parse
else:
    # python2.7
    import urlparse as parse


class AkamaiEAA():
    def __init__(self,prdHttpCaller,accountSwitchKey=None):
        self._prdHttpCaller = prdHttpCaller
        self.accountSwitchKey = accountSwitchKey
        return None

    def listApplications(self,contractId):
        ep = '/crux/v1/mgmt-pop/apps'
        params = {}
        params['contractId']= contractId
        params['expand'] = True
        params['expand_sdk' ] = True
        params['limit'] = 250

        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
           
        status,applicationsResult = self._prdHttpCaller.getResult(ep,params=params)

        return status,applicationsResult
    
    def getApplication(self,contractId,appId):  
        ep = '/crux/v1/mgmt-pop/apps/{}'.format(appId)
        params = {}
        params['contractId']= contractId
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,applicationResult = self._prdHttpCaller.getResult(ep,params=params)

        return status,applicationResult
    

    def listConnectors(self,contractId):
        ep = '/crux/v1/mgmt-pop/agents'
        params = {}
        params['contractId']= contractId
        params['limit'] = 250
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,connectorsResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,connectorsResult
    
    def listConnectorPools(self,contractId):
        ep = '/crux/v1/mgmt-pop/connector-pools'
        params = {}
        params['contractId']= contractId
        params['limit'] = 250
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,connectorPoolsResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,connectorPoolsResult
    
    def getConnector(self,contractId,uuid_url):
        ep = '/crux/v1/mgmt-pop/agents/{}'.format(uuid_url)
        params = {}
        params['contractId']= contractId
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,connectorResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,connectorResult
    
    def listIDPs(self,contractId):
        ep = '/crux/v1/mgmt-pop/appidp'
        params = {}
        params['contractId']= contractId
        params['limit'] = 250
        params['expand'] = True
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,idpsResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,idpsResult
    
    def listAccessGroups(self,contractId):
        ep = '/crux/v1/mgmt-pop/app-access-groups'
        params = {}
        params['contractId']= contractId
        params['limit'] = 250
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,accessGroupsResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,accessGroupsResult
    
    
    def getIDP(self,contractId,appIdpId):
        ep = '/crux/v1/mgmt-pop/appidp/{}'.format(appIdpId)
        params = {}
        params['contractId']= contractId
        params['expand'] = True
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,idpResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,idpResult


    def listDirectoriesAndGroups(self,contractId):
        ep = '/crux/v1/mgmt-pop/directories'
        params = {}
        params['contractId']= contractId
        params['limit'] = 250
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,directoriesAndGroupsResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,directoriesAndGroupsResult


    def getDirectory(self,contractId,directory_id):
        ep = '/crux/v1/mgmt-pop/directories/{}'.format(directory_id)
        params = {}
        params['contractId']= contractId
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,directoryResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,directoryResult
    
    def getGroup(self,contractId,directory_uuid,group_uuid):
        ep = '/crux/v1/mgmt-pop/directories/{}/groups/{}'.format(directory_uuid,group_uuid)
        params = {}
        params['contractId']= contractId
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,groupResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,groupResult


    def listCertificates(self,contractId):
        ep = '/crux/v1/mgmt-pop/certificates'
        params = {}
        params['contractId']= contractId
        params['limit'] = 250
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,certificatesResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,certificatesResult


    def getCertificate(self,contractId,certificate_id):
        ep = '/crux/v1/mgmt-pop/certificates/{}'.format(certificate_id)
        params = {}
        params['contractId']= contractId
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,certificateResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,certificateResult
    
    def listAppBundles(self,contractId):
        ep = '/crux/v1/mgmt-pop/appbundle'
        params = {}
        params['contractId']= contractId
        params['limit'] = 250
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,appBundlesResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,appBundlesResult
    
    def getAppBundle(self,contractId,app_bundle_id):
        ep = '/crux/v1/mgmt-pop/appbundle/{}'.format(app_bundle_id)
        params = {}
        params['contractId']= contractId
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,appBundleResult = self._prdHttpCaller.getResult(ep,params=params)
        return status,appBundleResult

    def createApplication(self,contractId,app_name,app_description,app_profile,app_type,popId,client_app_mode):
        #application profile. Either 1 for HTTP, 2 for SharePoint, 3 for Jira, 4 for RDP, 5 for VNC, 6 for ssh, 7 for Jenkins, 8 for Confluence, or 9 for TCP.
        #app_type - The type of application configuration. Either 1 for Enterprise Hosted, 2 for SAAS, 3 for Bookmark, 4 for Tunnel, or 5 for Enterprise Threat Protector.
   
        payload = {
            "name": app_name,
            "description": app_description,
            "app_profile": app_profile,
            "app_type": app_type,
            "pop": popId,
            "client_app_mode": client_app_mode
        }   

        datajson = json.dumps(payload,indent=2)
   
        ep = '/crux/v1/mgmt-pop/apps'
        params = {}
        params['contractId']= contractId
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey
        status,appcreationResult = self._prdHttpCaller.postResult(ep,datajson,params=params)
        return status,appcreationResult
    

    def addHostnameandDestinationtoApplication(self,applId,contractId,hostname,tunnel_internal_hosts):
        status, appresponse1 = self.getApplication(contractId,applId)

        appresponse = appresponse1.copy()
        appresponse['domain'] = 2       
        appresponse['host'] = hostname        
        appresponse['tunnel_internal_hosts'] = tunnel_internal_hosts


        ep = '/crux/v1/mgmt-pop/apps/{}'.format(applId)
        datajson = json.dumps(appresponse,indent=2)
        params = {}
        params['contractId']= contractId
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey

        headers = {}
        headers['content-type']=  'application/json'


        status,addHostnameResult = self._prdHttpCaller.putResult(ep,datajson,headers,params=params)
        print(json.dumps(addHostnameResult,indent=2))
        return status,addHostnameResult


    def addConnectorstoApplication(self,app_uuid_url,contractId,connectorsArray):
        dataconnectorArray = []
 
        status,connectorList = self.listConnectors(contractId)
        print(connectorsArray)
        for connector in connectorsArray:
            for item in connectorList['objects']:
                if item['name'] == connector:
                    print(item)
                    dataconnectorItem = {}
                    dataconnectorItem['compatible'] = "true"
                    dataconnectorItem['name'] = connector
                    dataconnectorItem['uuid_url'] = item['uuid_url']
                    dataconnectorArray.append(dataconnectorItem)
            
        print("Data Connecrotors to be added to the application:")
        print(dataconnectorArray)
                
        data = json.dumps({"agents": dataconnectorArray})

        ep = '/crux/v1/mgmt-pop/apps/{}/agents'.format(app_uuid_url)
        params = {}
        params['contractId']= contractId
        if self.accountSwitchKey:
            params['accountSwitchKey']= self.accountSwitchKey

        headers = {}
        headers['content-type']=  'application/json'

        status,response = self._prdHttpCaller.postResult(ep,data,headers=headers,params=params)
        return status,response
    

    def addIDPtoApplication(self,app_uuid_url,contractId,idp_name):
        status,idpResult = self.listIDPs(contractId)
        idp_uuid = None
        for item in idpResult['objects']:
            if item['idp']['name'] == idp_name:

                idp_uuid = item['idp']['idp_uuid_url']
               
                data = {}
                data['idp'] = idp_uuid
                data['app'] = app_uuid_url
                datajson = json.dumps(data,indent=2)    

                ep = '/crux/v1/mgmt-pop/appidp'
                params = {}
                params['contractId']= contractId
                if self.accountSwitchKey:
                    params['accountSwitchKey']= self.accountSwitchKey

                headers = {}
                headers['content-type']=  'application/json'

                status,response = self._prdHttpCaller.postResult(ep,datajson,headers=headers,params=params)
                return status,response

    
    def addAccessGrouptoApplication1(self,app_uuid_url,contractId,access_group_name):
        print('*'*80)
        print("Adding access group {} to application {}".format(access_group_name,app_uuid_url))

        status,accessGroupsResult = self.listAccessGroups(contractId)
        for item in accessGroupsResult['objects']:
            if item['name'] == access_group_name:
                accessgroupItem = {}
                #accessgroupItem['compatible'] = "true"
                #accessgroupItem['uuid_url'] = item['uuid_url']
                #accessgroupItem['name'] = item['name']
                #accessgroupItem['authn_ruleset'] = item['authn_ruleset']
                #accessgroupItem['authz_ruleset'] = item['authz_ruleset']

                #appresponse['application_access_group'] = accessgroupItem 

                testitem  = {}
                testitem['apps'] = [app_uuid_url]
                testitem['groups'] = []
                tempitem = {}
                tempitem['uuid_url'] = item['uuid_url']
                testitem['groups'].append(tempitem)

                accessgroupItem['data'] = []
                accessgroupItem['data'].append(testitem)

                print(json.dumps(accessgroupItem, indent=2))
                ep = '/crux/v1/mgmt-pop/apps/app-access-groups'.format()
                datajson = json.dumps(accessgroupItem,indent=2)
                params = {}
                params['contractId']= contractId
                if self.accountSwitchKey:
                    params['accountSwitchKey']= self.accountSwitchKey


                headers = {}
                headers['content-type']=  'application/json'


                status,addaccessgroupResult = self._prdHttpCaller.postResult(ep,datajson,headers=headers,params=params)
                print(json.dumps(addaccessgroupResult,indent=2))
                return status,addaccessgroupResult
            

    def addAccessGrouptoApplication(self,app_uuid_url,contractId,access_group_name):
        print('*'*80)
        print("Adding access group {} to application {}".format(access_group_name,app_uuid_url))

        status,accessGroupsResult = self.listAccessGroups(contractId)
        for item in accessGroupsResult['objects']:
            if item['name'] == access_group_name:
                groupID = item['uuid_url']
                
                data = {}
                data['add'] = [app_uuid_url]
                data['authn_overridden_apps'] = []
                data['authz_overridden_apps'] = []
                data['delete'] = []
                datajson = json.dumps(data,indent=2)    



                print(json.dumps(data, indent=2))
                
                ep = '/crux/v1/mgmt-pop/app-access-groups/{}/apps/associate'.format(groupID)
                datajson = json.dumps(data,indent=2)
                params = {}
                params['contractId']= contractId
                params['gid'] = 194092
                if self.accountSwitchKey:
                    params['accountSwitchKey']= self.accountSwitchKey

                headers = {}
                headers['content-type']=  'application/json'


                status,addaccessgroupResult = self._prdHttpCaller.putResult(ep,datajson,headers,params=params)
                print(json.dumps(addaccessgroupResult,indent=2))
                return status,addaccessgroupResult


'''

List Connectors : 
https://{hostname}/crux/v1/mgmt-pop/apps/{applicationId}/agents

Attach Connectors: 
https://{hostname}/crux/v1/mgmt-pop/apps/{applicationId}/agents

List Access groups:
https://control.akamai.com/crux/v1/mgmt-pop/apps/{applicationId}/aag/associate


https://control.akamai.com/crux/v1/mgmt-pop/app-access-groups/Wi5XBCJDQUibhKQecJbuag?contractId=P-3VUR6PV&gid=194092' \


'''
