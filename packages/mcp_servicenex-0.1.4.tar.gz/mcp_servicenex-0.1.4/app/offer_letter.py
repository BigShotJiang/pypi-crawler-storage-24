"""
Generate professional job offer letter documents as .docx files.
"""

import base64
from io import BytesIO
from typing import Any

from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH


def build_offer_letter_docx(
    company_name: str,
    company_address: str,
    candidate_name: str,
    job_title: str,
    department: str,
    start_date: str,
    salary: str,
    **kwargs: Any,
) -> bytes:
    """
    Build a professionally formatted offer letter as a .docx file.

    Returns the raw bytes of the document.
    """
    doc = Document()
    style = doc.styles["Normal"]
    font = style.font
    font.name = "Times New Roman"
    font.size = Pt(12)

    # Header - Company name and address
    header = doc.add_paragraph()
    header_run = header.add_run(company_name)
    header_run.bold = True
    header_run.font.size = Pt(14)
    header.alignment = WD_ALIGN_PARAGRAPH.LEFT

    addr_para = doc.add_paragraph(company_address)
    addr_para.paragraph_format.space_after = Pt(24)

    # Date
    from datetime import datetime
    date_para = doc.add_paragraph(f"Date: {datetime.now().strftime('%B %d, %Y')}")
    date_para.paragraph_format.space_after = Pt(12)

    # Recipient
    recipient_para = doc.add_paragraph()
    recipient_para.add_run("To:\n").bold = True
    recipient_para.add_run(f"{candidate_name}\n")
    recipient_para.paragraph_format.space_after = Pt(12)

    # Subject
    subject_para = doc.add_paragraph()
    subject_para.add_run("Subject: ").bold = True
    subject_para.add_run(f"Job Offer - {job_title}")
    subject_para.paragraph_format.space_after = Pt(24)

    # Body - Opening
    body_intro = doc.add_paragraph()
    body_intro.add_run("Dear ").bold = False
    first_name = candidate_name.split()[0] if candidate_name else "Candidate"
    body_intro.add_run(f"{first_name},\n\n")
    body_intro.add_run(
        f"We are pleased to extend this formal offer of employment for the position of "
    )
    body_intro.add_run(f"{job_title}").bold = True
    body_intro.add_run(f" in the {department} department at {company_name}.")
    body_intro.paragraph_format.space_after = Pt(12)

    # Terms section
    terms_para = doc.add_paragraph()
    terms_para.add_run("Terms of Offer:\n").bold = True
    terms_para.paragraph_format.space_after = Pt(6)

    terms_list = [
        ("Position:", job_title),
        ("Department:", department),
        ("Start Date:", start_date),
        ("Salary:", salary),
    ]
    for label, value in terms_list:
        line = doc.add_paragraph()
        line.add_run(f"  • {label} ").bold = True
        line.add_run(value)
        line.paragraph_format.space_after = Pt(3)

    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    # Closing
    closing_para = doc.add_paragraph()
    closing_para.add_run(
        "We are excited about the possibility of you joining our team. "
        "Please sign and return a copy of this letter to indicate your acceptance. "
        "If you have any questions, please do not hesitate to contact us."
    )
    closing_para.paragraph_format.space_after = Pt(24)

    # Signature block
    sig_para = doc.add_paragraph("Sincerely,\n\n\n_____________________________")
    sig_para.paragraph_format.space_after = Pt(6)
    sig_para = doc.add_paragraph(f"{company_name}")
    sig_para.paragraph_format.space_after = Pt(24)

    # Write to buffer
    buffer = BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer.read()
