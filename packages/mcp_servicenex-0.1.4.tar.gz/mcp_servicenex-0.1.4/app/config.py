import os

# Configuration - reads from environment variables (set by MCP/Claude config env)
# No hardcoded credentials for security when published to PyPI

MY_API_BASE_URL = os.getenv("MY_API_BASE_URL", "https://qa.servicenex.io/api")
MY_API_KEY = os.getenv("MY_API_KEY")