"""HTTP client for the CrowdTime API.

Wraps httpx with auth header injection, org-scoped URL prefixing,
and friendly error handling.
"""

from __future__ import annotations

from typing import Any

import httpx
from rich.console import Console

from .auth import get_token
from .config import get_config

console = Console(stderr=True)


class APIError(Exception):
    """Raised when an API call fails."""

    def __init__(self, message: str, status_code: int | None = None, detail: Any = None) -> None:
        self.message = message
        self.status_code = status_code
        self.detail = detail
        super().__init__(message)


class CrowdTimeClient:
    """Synchronous HTTP client for the CrowdTime API."""

    def __init__(self, require_auth: bool = True, require_org: bool = False) -> None:
        self.config = get_config()
        self.base_url = self.config.server_url
        self.token = get_token()
        self.org_slug = self.config.organization

        if require_auth and not self.token:
            console.print(
                "[red]Not authenticated.[/red] Please run [bold]ct login[/bold] first."
            )
            raise SystemExit(1)

        if require_org and not self.org_slug:
            console.print(
                "[red]No organization set.[/red] Please run [bold]ct org switch <slug>[/bold] first."
            )
            raise SystemExit(1)

        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        self._client = httpx.Client(
            base_url=self.base_url,
            headers=headers,
            timeout=30.0,
        )

    def _org_prefix(self) -> str:
        """Return the org-scoped URL prefix."""
        return f"/api/v1/organizations/{self.org_slug}"

    def _url(self, path: str, org_scoped: bool = True) -> str:
        """Build the full URL path."""
        if path.startswith("/api/"):
            return path
        if org_scoped and self.org_slug:
            return f"{self._org_prefix()}/{path.lstrip('/')}"
        return f"/api/v1/{path.lstrip('/')}"

    def get(self, path: str, params: dict[str, Any] | None = None,
            org_scoped: bool = True) -> Any:
        """Make a GET request."""
        url = self._url(path, org_scoped=org_scoped)
        response = self._request("GET", url, params=params)
        return response

    def post(self, path: str, data: dict[str, Any] | None = None,
             org_scoped: bool = True) -> Any:
        """Make a POST request."""
        url = self._url(path, org_scoped=org_scoped)
        response = self._request("POST", url, json=data)
        return response

    def patch(self, path: str, data: dict[str, Any] | None = None,
              org_scoped: bool = True) -> Any:
        """Make a PATCH request."""
        url = self._url(path, org_scoped=org_scoped)
        response = self._request("PATCH", url, json=data)
        return response

    def delete(self, path: str, org_scoped: bool = True) -> Any:
        """Make a DELETE request."""
        url = self._url(path, org_scoped=org_scoped)
        response = self._request("DELETE", url)
        return response

    def _request(self, method: str, url: str, **kwargs: Any) -> Any:
        """Execute an HTTP request with error handling."""
        try:
            response = self._client.request(method, url, **kwargs)
            return self._handle_response(response)
        except httpx.ConnectError:
            console.print(
                f"[red]Cannot connect to server at {self.base_url}[/red]\n"
                "Is the CrowdTime server running?"
            )
            raise SystemExit(1)
        except httpx.TimeoutException:
            console.print("[red]Request timed out.[/red] Please try again.")
            raise SystemExit(1)
        except APIError:
            raise
        except httpx.HTTPError as e:
            console.print(f"[red]HTTP error:[/red] {e}")
            raise SystemExit(1)

    def _handle_response(self, response: httpx.Response) -> Any:
        """Check response status and parse JSON."""
        if response.status_code == 204:
            return None

        if response.status_code == 401:
            console.print(
                "[red]Authentication failed.[/red] Please run [bold]ct login[/bold] to re-authenticate."
            )
            raise SystemExit(1)

        if response.status_code == 403:
            console.print("[red]Permission denied.[/red] You don't have access to this resource.")
            raise SystemExit(1)

        if response.status_code == 402:
            try:
                detail = response.json()
            except Exception:
                detail = {}
            msg = (
                detail.get("detail", "")
                if isinstance(detail, dict)
                else str(detail)
            ) or "Your organization's subscription is inactive."
            console.print(
                f"[yellow]{msg}[/yellow]\n"
                "Run [bold]ct billing portal[/bold] to update your billing."
            )
            raise APIError(msg, status_code=402, detail=detail)

        if response.status_code == 404:
            raise APIError("Not found", status_code=404)

        if response.status_code >= 500:
            # Server errors — show a friendly message, not raw HTML
            try:
                detail = response.json()
                msg = detail.get("detail", "Internal server error")
            except Exception:
                msg = "Internal server error"
            raise APIError(
                f"Server error ({response.status_code}): {msg}",
                status_code=response.status_code,
            )

        if response.status_code >= 400:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            msg = detail.get("detail", str(detail)) if isinstance(detail, dict) else str(detail)
            raise APIError(msg, status_code=response.status_code, detail=detail)

        if not response.content:
            return None

        try:
            return response.json()
        except Exception:
            return response.text

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> CrowdTimeClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
