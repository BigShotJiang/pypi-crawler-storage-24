"""Shared name-to-UUID resolution helpers for CLI commands."""

from __future__ import annotations

import re

from rich.console import Console

from .client import APIError, CrowdTimeClient

console = Console(stderr=True)


def resolve_task(client: CrowdTimeClient, task_ref: str, project_id: str | None = None) -> str:
    """Resolve a task name or UUID to a UUID. Auto-assigns to project if needed.

    Args:
        client: Authenticated API client.
        task_ref: Task name or UUID.
        project_id: If provided, ensures the task is assigned to this project.

    Returns:
        The task UUID string.
    """
    # If it looks like a UUID already, use it directly
    if _looks_like_uuid(task_ref):
        task_id = task_ref
    else:
        # Search org tasks by name
        data = client.get("/tasks/", params={"search": task_ref})
        tasks_list = data if isinstance(data, list) else data.get("results", [])

        # Exact match (case-insensitive)
        task_id = None
        for t in tasks_list:
            if t.get("name", "").lower() == task_ref.lower():
                task_id = t["id"]
                break

        if task_id is None:
            # No match — create the task
            console.print(f"[dim]Task '{task_ref}' not found — creating it...[/dim]")
            new_task = client.post("/tasks/", data={"name": task_ref})
            task_id = new_task["id"]

    # If a project is specified, ensure the task is assigned to it
    if project_id:
        _ensure_task_assigned_to_project(client, task_id, project_id)

    return task_id


def _ensure_task_assigned_to_project(
    client: CrowdTimeClient, task_id: str, project_id: str
) -> None:
    """Check if a task is assigned to a project; assign it if not."""
    # List tasks currently assigned to the project
    try:
        data = client.get(f"/projects/{project_id}/tasks/")
        assigned = data if isinstance(data, list) else data.get("results", [])

        for pt in assigned:
            # The response has 'task' (UUID) field
            if pt.get("task") == task_id:
                return  # Already assigned

        # Not assigned — assign it
        console.print(f"[dim]Assigning task to project...[/dim]")
        client.post(f"/projects/{project_id}/tasks/", data={"task": task_id})
    except APIError:
        # If we can't check/assign, let the API validate later
        pass


def _looks_like_uuid(value: str) -> bool:
    """Quick check if a string looks like a UUID."""
    return bool(re.match(
        r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
        value.lower(),
    ))
