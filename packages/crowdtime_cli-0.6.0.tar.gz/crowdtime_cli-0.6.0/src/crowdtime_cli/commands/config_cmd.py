"""Config commands: set, get, list, edit."""

from __future__ import annotations

import os
import subprocess

import typer
from rich.console import Console

from ..config import get_config
from ..formatters import format_error, format_success, print_json

app = typer.Typer(name="config", help="Manage CLI configuration.")
console = Console()


@app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Config key (e.g. server.url, defaults.project)."),
    value: str = typer.Argument(..., help="Value to set."),
) -> None:
    """Set a configuration value.

    Examples:
        ct config set server.url https://api.crowdtime.io
        ct config set defaults.project myproject
        ct config set defaults.daily_target 7h
    """
    config = get_config()
    # Convert boolean strings
    if value.lower() in ("true", "yes", "1"):
        config.set(key, True)
    elif value.lower() in ("false", "no", "0"):
        config.set(key, False)
    else:
        config.set(key, value)
    format_success(f"{key} = {value}")


@app.command("get")
def config_get(
    key: str = typer.Argument(..., help="Config key to read."),
) -> None:
    """Get a configuration value."""
    config = get_config()
    value = config.get(key)
    if value is None:
        format_error(f"Key '{key}' not found.")
        raise typer.Exit(1)
    console.print(f"{key} = {value}")


@app.command("list")
def config_list(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show all configuration values."""
    config = get_config()
    all_config = config.all()

    if output_json:
        print_json(dict(all_config))
        return

    console.print(f"\n[dim]Config file: {config.config_path}[/dim]\n")
    for section, values in all_config.items():
        console.print(f"[bold][{section}][/bold]")
        if isinstance(values, dict):
            for key, value in values.items():
                console.print(f"  {key} = {value}")
        else:
            console.print(f"  {values}")
    console.print()


@app.command("edit")
def config_edit() -> None:
    """Open the config file in your default editor."""
    config = get_config()
    editor = os.environ.get("EDITOR", os.environ.get("VISUAL", "nano"))

    try:
        subprocess.run([editor, str(config.config_path)], check=True)
        format_success(f"Config saved at {config.config_path}")
    except FileNotFoundError:
        format_error(f"Editor '{editor}' not found. Set $EDITOR to your preferred editor.")
        raise typer.Exit(1)
    except subprocess.CalledProcessError:
        format_error("Editor exited with an error.")
        raise typer.Exit(1)
