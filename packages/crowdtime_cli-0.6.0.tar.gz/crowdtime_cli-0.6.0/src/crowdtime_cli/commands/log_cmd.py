"""Log commands: create, edit, delete, list."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from ..client import APIError, CrowdTimeClient
from ..formatters import (
    format_entries_table,
    format_entry_summary,
    format_error,
    format_success,
    print_json,
)
from ..models import TimeEntry
from ..resolvers import resolve_task
from ..utils import format_date, parse_date, parse_duration

app = typer.Typer(name="log", help="Log and manage time entries.")
console = Console()


@app.callback(invoke_without_command=True)
def log_default(
    ctx: typer.Context,
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Log and manage time entries. Run without arguments to list today's entries."""
    if ctx.invoked_subcommand is None:
        _list_entries(date_str="today", output_json=output_json)


@app.command()
def create(
    duration: str = typer.Argument(..., help="Duration (e.g. 2h, 2h30m, 2:30, 150m)."),
    description: Optional[str] = typer.Argument(None, help="What did you work on?"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project slug or ID."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="Task name or ID."),
    date: Optional[str] = typer.Option(None, "--date", "-d", help="Date (default: today)."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable/non-billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Log a completed time entry.

    Examples:
        ct log create 2h "Code review"
        ct log create -p myproject 2h30m "Feature work"
        ct l -p myproject -d yesterday 1:30 "Standup"
    """
    try:
        hours = parse_duration(duration)
    except ValueError as e:
        format_error(str(e))
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "hours": str(hours),
    }
    if description:
        payload["notes"] = description

    project_id = project or client.config.default_project
    if project_id:
        payload["project"] = project_id
    if task:
        try:
            payload["task"] = resolve_task(client, task, project_id=project_id)
        except APIError as e:
            format_error(f"Failed to resolve task '{task}': {e.message}")
            raise typer.Exit(1)
    if date:
        try:
            parsed = parse_date(date)
            payload["date"] = format_date(parsed)
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if billable is not None:
        payload["is_billable"] = billable

    try:
        data = client.post("/time/", data=payload)
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_success("Time entry logged")
            format_entry_summary(entry)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def edit(
    entry_id: str = typer.Argument(..., help="Time entry ID to edit."),
    duration: Optional[str] = typer.Option(None, "--duration", help="New duration."),
    description: Optional[str] = typer.Option(None, "--description", help="New description."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="New project."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="New task."),
    date: Optional[str] = typer.Option(None, "--date", "-d", help="New date."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable/non-billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Edit an existing time entry."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if duration:
        try:
            payload["hours"] = str(parse_duration(duration))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if description is not None:
        payload["notes"] = description
    if project:
        payload["project"] = project
    if task:
        try:
            payload["task"] = resolve_task(client, task, project_id=project)
        except APIError as e:
            format_error(f"Failed to resolve task '{task}': {e.message}")
            raise typer.Exit(1)
    if date:
        try:
            payload["date"] = format_date(parse_date(date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if billable is not None:
        payload["is_billable"] = billable

    if not payload:
        format_error("No changes specified. Use --duration, --description, --project, etc.")
        raise typer.Exit(1)

    try:
        data = client.patch(f"/time/{entry_id}/", data=payload)
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_success(f"Entry {entry_id} updated")
            format_entry_summary(entry)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Entry {entry_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def delete(
    entry_id: str = typer.Argument(..., help="Time entry ID to delete."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Delete a time entry."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if not force:
        # Fetch entry details for confirmation
        try:
            data = client.get(f"/time/{entry_id}/")
            entry = TimeEntry(**data)
            desc = entry.description or "(no description)"
            if not typer.confirm(f"Delete entry '{desc}'?"):
                console.print("[dim]Cancelled.[/dim]")
                return
        except APIError as e:
            if e.status_code == 404:
                format_error(f"Entry {entry_id} not found.")
            else:
                format_error(e.message)
            raise typer.Exit(1)

    try:
        client.delete(f"/time/{entry_id}/")
        format_success(f"Entry {entry_id} deleted.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Entry {entry_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("list")
def list_entries(
    date: Optional[str] = typer.Option(None, "--date", "-d", help="Filter by date."),
    week: bool = typer.Option(False, "--week", "-w", help="Show this week's entries."),
    month: bool = typer.Option(False, "--month", "-m", help="Show this month's entries."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date for range filter."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date for range filter."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Filter by project."),
    format_output: str = typer.Option("table", "--format", help="Output format: table, json, csv."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List time entries with optional filters."""
    _list_entries(
        date_str=date,
        week=week,
        month=month,
        from_date=from_date,
        to_date=to_date,
        project=project,
        format_output=format_output,
        output_json=output_json,
    )


def _list_entries(
    date_str: str | None = None,
    week: bool = False,
    month: bool = False,
    from_date: str | None = None,
    to_date: str | None = None,
    project: str | None = None,
    format_output: str = "table",
    output_json: bool = False,
) -> None:
    """Internal function to list entries."""
    from datetime import date as date_type, timedelta

    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}

    if date_str:
        try:
            parsed = parse_date(date_str)
            params["date"] = format_date(parsed)
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    elif week:
        today = date_type.today()
        start = today - timedelta(days=today.weekday())
        params["from"] = format_date(start)
        params["to"] = format_date(today)
    elif month:
        today = date_type.today()
        start = today.replace(day=1)
        params["from"] = format_date(start)
        params["to"] = format_date(today)

    if from_date:
        try:
            params["from"] = format_date(parse_date(from_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if to_date:
        try:
            params["to"] = format_date(parse_date(to_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    if project:
        params["project"] = project

    try:
        data = client.get("/time/", params=params)
        entries = [TimeEntry(**item) for item in (data if isinstance(data, list) else data.get("results", []))]

        if format_output == "json" or output_json:
            print_json(entries)
        elif format_output == "csv":
            _print_csv(entries)
        else:
            format_entries_table(entries, show_date=True)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


def _print_csv(entries: list[TimeEntry]) -> None:
    """Print entries as CSV."""
    console.print("id,date,project,task,description,duration,billable")
    for e in entries:
        desc = (e.description or "").replace('"', '""')
        console.print(
            f'{e.id},{e.date or ""},'
            f'{e.project_name or ""},{e.task_name or ""},'
            f'"{desc}",{e.duration or 0},'
            f'{"yes" if e.is_billable else "no"}'
        )
