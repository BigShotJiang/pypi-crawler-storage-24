"""Client commands: list, show, create, archive, contacts."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..formatters import format_error, format_success, print_json

app = typer.Typer(name="clients", help="Manage clients.")
console = Console()


def _resolve_client(api_client: CrowdTimeClient, client_ref: str) -> str:
    """Resolve a client name or ID to a client UUID.

    If client_ref looks like a UUID, return it directly.
    Otherwise search by name and return the first exact match.
    """
    # If it looks like a UUID, use it directly
    if len(client_ref) == 36 and client_ref.count("-") == 4:
        return client_ref

    # Search by name
    data = api_client.get("/clients/", params={"search": client_ref})
    clients_list = data if isinstance(data, list) else data.get("results", [])

    # Exact match (case-insensitive)
    for c in clients_list:
        if c.get("name", "").lower() == client_ref.lower():
            return c["id"]

    # Partial match — take first result if only one
    if len(clients_list) == 1:
        return clients_list[0]["id"]

    if not clients_list:
        raise APIError(f"Client '{client_ref}' not found.", status_code=404)

    # Multiple matches — ambiguous
    names = ", ".join(c.get("name", "") for c in clients_list[:5])
    raise APIError(
        f"Multiple clients match '{client_ref}': {names}. Please use the client ID instead.",
        status_code=400,
    )


@app.command("list")
def list_clients(
    archived: bool = typer.Option(False, "--archived", "-a", help="Include archived clients."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List all clients in the current organization."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if archived:
        params["is_archived"] = "true"

    try:
        data = client.get("/clients/", params=params)
        clients_list = data if isinstance(data, list) else data.get("results", [])

        if output_json:
            print_json(clients_list)
        else:
            if not clients_list:
                console.print("[dim]No clients found.[/dim]")
                return

            table = Table(show_header=True, header_style="bold")
            table.add_column("ID", style="dim")
            table.add_column("Name")
            table.add_column("Contact")
            table.add_column("Projects", justify="right")
            table.add_column("Status")

            for c in clients_list:
                client_id = str(c.get("id", ""))
                name = c.get("name", "")
                contact = c.get("contact_name", "") or "-"
                project_count = str(c.get("project_count", 0))
                is_archived = c.get("is_archived", False)
                status = "[red]Archived[/red]" if is_archived else "[green]Active[/green]"
                table.add_row(client_id, name, contact, project_count, status)

            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def show(
    client_id: str = typer.Argument(..., help="Client ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show details for a specific client."""
    api_client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = api_client.get(f"/clients/{client_id}/")

        if output_json:
            print_json(data)
        else:
            console.print(f"\n[bold]{data.get('name')}[/bold]")
            console.print(f"  ID:       {data.get('id')}")
            console.print(f"  Currency: {data.get('currency', '-')}")
            console.print(f"  Contact:  {data.get('contact_name', '-')}")
            if data.get("contact_email"):
                console.print(f"  Email:    {data['contact_email']}")
            if data.get("contact_phone"):
                console.print(f"  Phone:    {data['contact_phone']}")
            if data.get("address"):
                console.print(f"  Address:  {data['address']}")
            status = "Archived" if data.get("is_archived") else "Active"
            console.print(f"  Status:   {status}")
            console.print()
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Client '{client_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def create(
    name: str = typer.Argument(..., help="Client name."),
    currency: Optional[str] = typer.Option(None, "--currency", help="Currency code (e.g. USD)."),
    contact_name: Optional[str] = typer.Option(None, "--contact", help="Contact person name."),
    contact_email: Optional[str] = typer.Option(None, "--email", help="Contact email."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a new client."""
    api_client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {"name": name}
    if currency:
        payload["currency"] = currency
    if contact_name:
        payload["contact_name"] = contact_name
    if contact_email:
        payload["contact_email"] = contact_email

    try:
        data = api_client.post("/clients/", data=payload)

        if output_json:
            print_json(data)
        else:
            format_success(f"Client '{data.get('name')}' created (ID: {data.get('id')})")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def archive(
    client_id: str = typer.Argument(..., help="Client ID to archive."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Archive a client."""
    if not force:
        if not typer.confirm(f"Archive client '{client_id}'?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    api_client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        api_client.delete(f"/clients/{client_id}/")
        format_success(f"Client '{client_id}' archived.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Client '{client_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


# ─── Contact subcommands ─────────────────────────────────────────


@app.command("contacts")
def list_contacts(
    client_ref: str = typer.Argument(..., help="Client name or ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List all contacts for a client.

    Examples:
        ct clients contacts "Acme Corp"
        ct clients contacts <client-id>
    """
    api_client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        client_id = _resolve_client(api_client, client_ref)
        data = api_client.get(f"/clients/{client_id}/contacts/")
        contacts = data if isinstance(data, list) else data.get("results", [])

        if output_json:
            print_json(contacts)
        else:
            if not contacts:
                console.print("[dim]No contacts found for this client.[/dim]")
                return

            table = Table(show_header=True, header_style="bold")
            table.add_column("ID", style="dim")
            table.add_column("Name", width=20)
            table.add_column("Email", width=25)
            table.add_column("Phone", width=15)
            table.add_column("Role", width=15)
            table.add_column("Primary", justify="center", width=8)

            for contact in contacts:
                is_primary = contact.get("is_primary", False)
                primary_label = "[green]Yes[/green]" if is_primary else "[dim]No[/dim]"

                table.add_row(
                    str(contact.get("id", "")),
                    contact.get("name", ""),
                    contact.get("email", "") or "-",
                    contact.get("phone", "") or "-",
                    contact.get("role", "") or "-",
                    primary_label,
                )

            console.print(table)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Client '{client_ref}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("add-contact")
def add_contact(
    client_ref: str = typer.Argument(..., help="Client name or ID."),
    name: str = typer.Option(..., "--name", help="Contact person name."),
    email: Optional[str] = typer.Option(None, "--email", help="Contact email."),
    phone: Optional[str] = typer.Option(None, "--phone", help="Contact phone."),
    role: Optional[str] = typer.Option(None, "--role", help="Contact role/title."),
    primary: bool = typer.Option(False, "--primary", help="Set as primary contact."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Add a contact to a client.

    Examples:
        ct clients add-contact "Acme Corp" --name "Jane Doe" --email jane@acme.com
        ct clients add-contact <client-id> --name "John Smith" --role "CTO" --primary
    """
    api_client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        client_id = _resolve_client(api_client, client_ref)

        payload: dict = {"name": name}
        if email:
            payload["email"] = email
        if phone:
            payload["phone"] = phone
        if role:
            payload["role"] = role
        if primary:
            payload["is_primary"] = True

        data = api_client.post(f"/clients/{client_id}/contacts/", data=payload)

        if output_json:
            print_json(data)
        else:
            format_success(
                f"Contact '{data.get('name', name)}' added to client "
                f"(ID: {data.get('id', '')})"
            )
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Client '{client_ref}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("remove-contact")
def remove_contact(
    client_ref: str = typer.Argument(..., help="Client name or ID."),
    contact_id: str = typer.Argument(..., help="Contact ID to remove."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Remove a contact from a client.

    Examples:
        ct clients remove-contact "Acme Corp" <contact-id>
        ct clients remove-contact <client-id> <contact-id> --force
    """
    if not force:
        if not typer.confirm(f"Remove contact '{contact_id}'?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    api_client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        client_id = _resolve_client(api_client, client_ref)
        api_client.delete(f"/clients/{client_id}/contacts/{contact_id}/")
        format_success(f"Contact '{contact_id}' removed.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Client or contact not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)
