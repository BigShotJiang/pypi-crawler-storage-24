"""Report commands: report, projects, team."""

from __future__ import annotations

from datetime import date as date_type, timedelta
from typing import Optional

import typer
from rich.console import Console

from ..client import APIError, CrowdTimeClient
from ..formatters import format_error, format_report, print_json
from ..utils import format_date, parse_date

app = typer.Typer(name="report", help="Generate time reports.")
console = Console()


def _resolve_period(
    today_flag: bool = False,
    yesterday_flag: bool = False,
    week: bool = False,
    last_week: bool = False,
    month: bool = False,
    from_date: str | None = None,
    to_date: str | None = None,
) -> tuple[str, str]:
    """Resolve date range from flags."""
    today = date_type.today()

    if today_flag:
        d = format_date(today)
        return d, d
    if yesterday_flag:
        d = format_date(today - timedelta(days=1))
        return d, d
    if week:
        start = today - timedelta(days=today.weekday())
        return format_date(start), format_date(today)
    if last_week:
        start = today - timedelta(days=today.weekday() + 7)
        end = start + timedelta(days=6)
        return format_date(start), format_date(end)
    if month:
        start = today.replace(day=1)
        return format_date(start), format_date(today)
    if from_date and to_date:
        try:
            return format_date(parse_date(from_date)), format_date(parse_date(to_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if from_date:
        try:
            return format_date(parse_date(from_date)), format_date(today)
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    # Default: this week
    start = today - timedelta(days=today.weekday())
    return format_date(start), format_date(today)


@app.callback(invoke_without_command=True)
def report(
    ctx: typer.Context,
    today_flag: bool = typer.Option(False, "--today", help="Report for today."),
    yesterday_flag: bool = typer.Option(False, "--yesterday", help="Report for yesterday."),
    week: bool = typer.Option(False, "--week", "-w", help="Report for this week."),
    last_week: bool = typer.Option(False, "--last-week", help="Report for last week."),
    month: bool = typer.Option(False, "--month", "-m", help="Report for this month."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Filter by project."),
    group_by: str = typer.Option("project", "--group-by", "-g",
                                 help="Group by: project, task, day, client."),
    format_output: str = typer.Option("table", "--format", "-f",
                                      help="Output format: table, json, csv, markdown."),
) -> None:
    """Generate a time report.

    Examples:
        ct report --week
        ct report --month --group-by task
        ct report --from 2026-03-01 --to 2026-03-10 -p myproject
    """
    if ctx.invoked_subcommand is not None:
        return

    period_from, period_to = _resolve_period(
        today_flag, yesterday_flag, week, last_week, month, from_date, to_date
    )

    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {
        "from": period_from,
        "to": period_to,
        "group_by": group_by,
    }
    if project:
        params["project"] = project

    endpoint = "/reports/project-summary/" if group_by == "project" else "/reports/time-detail/"

    try:
        data = client.get(endpoint, params=params)
        results = data if isinstance(data, list) else data.get("results", [])

        if format_output == "json":
            print_json(results)
        elif format_output == "csv":
            _print_report_csv(results, group_by)
        elif format_output == "markdown":
            _print_report_markdown(results, group_by, period_from, period_to)
        else:
            console.print(f"\n[dim]Period: {period_from} to {period_to}[/dim]")
            format_report(results, group_by=group_by)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("projects")
def project_report(
    week: bool = typer.Option(False, "--week", "-w", help="This week."),
    month: bool = typer.Option(True, "--month", "-m", help="This month (default)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Project breakdown report."""
    period_from, period_to = _resolve_period(week=week, month=month)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/reports/project-summary/", params={
            "from": period_from,
            "to": period_to,
        })
        results = data if isinstance(data, list) else data.get("results", [])

        if output_json:
            print_json(results)
        else:
            console.print(f"\n[dim]Period: {period_from} to {period_to}[/dim]")
            format_report(results, group_by="project")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("team")
def team_report(
    week: bool = typer.Option(False, "--week", "-w", help="This week."),
    month: bool = typer.Option(True, "--month", "-m", help="This month (default)."),
    member: Optional[str] = typer.Option(None, "--member", help="Filter by team member."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Team utilization report."""
    period_from, period_to = _resolve_period(week=week, month=month)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {
        "from": period_from,
        "to": period_to,
    }
    if member:
        params["member"] = member

    try:
        data = client.get("/reports/team-utilization/", params=params)
        results = data if isinstance(data, list) else data.get("results", [])

        if output_json:
            print_json(results)
        else:
            console.print(f"\n[dim]Team Report: {period_from} to {period_to}[/dim]")
            _print_team_table(results)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


def _print_team_table(data: list[dict]) -> None:
    """Print team utilization table."""
    from rich.table import Table
    from ..utils import format_duration
    from decimal import Decimal

    if not data:
        console.print("[dim]No data.[/dim]")
        return

    table = Table(show_header=True, header_style="bold", title="Team Utilization")
    table.add_column("Member", width=20)
    table.add_column("Hours", justify="right", width=10)
    table.add_column("Billable", justify="right", width=10)
    table.add_column("Utilization", justify="right", width=12)

    for row in data:
        hours = Decimal(str(row.get("hours", 0)))
        billable = Decimal(str(row.get("billable_hours", 0)))
        utilization = row.get("utilization", 0)
        table.add_row(
            row.get("member", ""),
            format_duration(hours),
            format_duration(billable),
            f"{utilization}%",
        )

    console.print(table)


def _print_report_csv(data: list[dict], group_by: str) -> None:
    """Print report as CSV."""
    console.print(f"{group_by},hours,billable_hours,entries_count")
    for row in data:
        console.print(
            f'{row.get(group_by, row.get("project", ""))},'
            f'{row.get("hours", 0)},'
            f'{row.get("billable_hours", 0)},'
            f'{row.get("entries_count", 0)}'
        )


def _print_report_markdown(data: list[dict], group_by: str, from_d: str, to_d: str) -> None:
    """Print report as Markdown."""
    from ..utils import format_duration
    from decimal import Decimal

    console.print(f"## Time Report ({from_d} to {to_d})\n")
    console.print(f"| {group_by.capitalize()} | Hours | Billable | Entries |")
    console.print("|---|---|---|---|")
    for row in data:
        hours = format_duration(Decimal(str(row.get("hours", 0))))
        billable = format_duration(Decimal(str(row.get("billable_hours", 0))))
        console.print(
            f"| {row.get(group_by, row.get('project', ''))} "
            f"| {hours} | {billable} | {row.get('entries_count', 0)} |"
        )
