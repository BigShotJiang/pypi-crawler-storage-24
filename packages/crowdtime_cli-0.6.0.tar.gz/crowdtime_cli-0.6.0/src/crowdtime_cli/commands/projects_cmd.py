"""Project commands: list, show, create, archive, switch, budget."""

from __future__ import annotations

from decimal import Decimal
from typing import Optional

import typer
from rich.console import Console

from ..client import APIError, CrowdTimeClient
from ..config import get_config
from ..formatters import format_error, format_projects_table, format_success, print_json
from ..models import Project
from ..utils import format_duration

app = typer.Typer(name="projects", help="Manage projects.")
console = Console()


def _resolve_or_create_client(api_client: CrowdTimeClient, client_name: str) -> str:
    """Look up a client by name; create one if it doesn't exist. Returns the client UUID."""
    # Search for existing clients matching the name
    data = api_client.get("/clients/", params={"search": client_name})
    clients_list = data if isinstance(data, list) else data.get("results", [])

    # Exact match (case-insensitive)
    for c in clients_list:
        if c.get("name", "").lower() == client_name.lower():
            return c["id"]

    # No match — auto-create the client
    console.print(f"[dim]Client '{client_name}' not found — creating it...[/dim]")
    new_client = api_client.post("/clients/", data={"name": client_name})
    return new_client["id"]


@app.command("list")
def list_projects(
    archived: bool = typer.Option(False, "--archived", "-a", help="Include archived projects."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List all projects in the current organization."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if archived:
        params["status"] = "archived"

    try:
        data = client.get("/projects/", params=params)
        projects_list = data if isinstance(data, list) else data.get("results", [])
        projects = [Project(**item) for item in projects_list]

        if output_json:
            print_json(projects)
        else:
            # Show which is default
            default_proj = client.config.default_project
            format_projects_table(projects)
            if default_proj:
                console.print(f"\n[dim]Default project: {default_proj}[/dim]")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def show(
    project_id: str = typer.Argument(..., help="Project ID or slug."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show details for a specific project."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/projects/{project_id}/")
        project = Project(**data)

        if output_json:
            print_json(project)
        else:
            console.print(f"\n[bold]{project.name}[/bold]")
            console.print(f"  ID:       {project.id}")
            console.print(f"  Code:     {project.code}")
            console.print(f"  Client:   {project.client or '-'}")
            console.print(f"  Status:   {project.status}")
            console.print(f"  Billable: {'Yes' if project.is_billable else 'No'}")
            if project.budget_hours:
                console.print(f"  Budget:   {project.budget_hours}h")
            if project.description:
                console.print(f"  Notes:    {project.description}")
            console.print()
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Project '{project_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def create(
    name: str = typer.Argument(..., help="Project name."),
    client_name: Optional[str] = typer.Option(None, "--client", "-c", help="Client name."),
    billable: bool = typer.Option(True, "--billable/--no-billable", "-b/-B",
                                  help="Mark as billable."),
    color: Optional[str] = typer.Option(None, "--color", help="Project color (hex)."),
    budget: Optional[float] = typer.Option(None, "--budget", help="Budget in hours."),
    code: Optional[str] = typer.Option(None, "--code", help="Short project code."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a new project."""
    api_client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {"name": name, "is_billable": billable}
    if color:
        payload["color"] = color
    if budget:
        payload["budget_hours"] = budget
    if code:
        payload["code"] = code

    # Resolve client name to UUID (or auto-create)
    if client_name:
        try:
            client_id = _resolve_or_create_client(api_client, client_name)
            payload["client"] = str(client_id)
        except APIError as e:
            format_error(f"Failed to resolve client '{client_name}': {e.message}")
            raise typer.Exit(1)

    try:
        data = api_client.post("/projects/", data=payload)
        project = Project(**data)

        if output_json:
            print_json(project)
        else:
            format_success(f"Project '{project.name}' created (ID: {project.id})")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def archive(
    project_id: str = typer.Argument(..., help="Project ID or slug to archive."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Archive a project."""
    if not force:
        if not typer.confirm(f"Archive project '{project_id}'?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.patch(f"/projects/{project_id}/", data={"status": "archived"})
        format_success(f"Project '{project_id}' archived.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Project '{project_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("switch")
def switch_project(
    slug: str = typer.Argument(..., help="Project slug or name to set as default."),
) -> None:
    """Set a project as the default for new entries."""
    config = get_config()
    config.set("defaults.project", slug)
    format_success(f"Default project set to '{slug}'")


@app.command("budget")
def budget(
    project_id: str = typer.Argument(..., help="Project ID or slug."),
    refresh: bool = typer.Option(False, "--refresh", help="Trigger a fresh budget snapshot computation."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show project budget status.

    Displays budget type, amount, spent, remaining, and percentage used.
    Use --refresh to trigger a fresh snapshot computation.

    Examples:
        ct projects budget my-project
        ct projects budget my-project --refresh
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        # Fetch project details for budget type and amount
        project_data = client.get(f"/projects/{project_id}/")
        project = Project(**project_data)

        # Trigger refresh if requested
        if refresh:
            console.print("[dim]Computing fresh budget snapshot...[/dim]")
            client.post("/reports/budget-burn/compute/", data={"project": str(project.id)})

        # Fetch budget burn data
        burn_data = client.get(f"/reports/budget-burn/{project.id}/")

        if output_json:
            print_json({
                "project": project_data,
                "budget_burn": burn_data,
            })
        else:
            budget_type = project_data.get("budget_type", "none")
            budget_amount = project_data.get("budget_amount") or project_data.get("budget_hours")

            console.print(f"\n[bold]{project.name}[/bold] — Budget Status")
            console.print(f"  Budget Type:  {budget_type.replace('_', ' ').capitalize() if budget_type else 'None'}")

            if not budget_amount and budget_type in ("none", None):
                console.print("  [dim]No budget configured for this project.[/dim]")
                console.print()
                return

            # Parse budget values
            spent = Decimal(str(burn_data.get("spent", burn_data.get("total_spent", 0))))
            budget_val = Decimal(str(budget_amount)) if budget_amount else Decimal("0")
            remaining = budget_val - spent if budget_val else Decimal("0")
            pct_used = (spent / budget_val * 100) if budget_val else Decimal("0")

            # Determine if budget is hours or currency
            is_hours_budget = budget_type in ("hours", "total_hours", None) or project.budget_hours

            if is_hours_budget:
                console.print(f"  Budget:       {format_duration(budget_val)}")
                console.print(f"  Spent:        {format_duration(spent)}")
                remaining_style = "red" if remaining < 0 else "green"
                console.print(f"  Remaining:    [{remaining_style}]{format_duration(abs(remaining))}{'  (over budget)' if remaining < 0 else ''}[/{remaining_style}]")
            else:
                console.print(f"  Budget:       ${budget_val:,.2f}")
                console.print(f"  Spent:        ${spent:,.2f}")
                remaining_style = "red" if remaining < 0 else "green"
                console.print(f"  Remaining:    [{remaining_style}]${abs(remaining):,.2f}{'  (over budget)' if remaining < 0 else ''}[/{remaining_style}]")

            # Progress bar
            pct_float = min(float(pct_used), 100)
            bar_width = 30
            filled = int(bar_width * pct_float / 100)
            bar_style = "green" if pct_float < 75 else "yellow" if pct_float < 90 else "red"
            bar = f"[{bar_style}]" + "\u2588" * filled + f"[/{bar_style}]" + "[dim]" + "\u2591" * (bar_width - filled) + "[/dim]"
            console.print(f"  Used:         {bar} {pct_used:.1f}%")

            if refresh:
                console.print("\n  [dim]Snapshot refreshed.[/dim]")

            console.print()
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Project '{project_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)
