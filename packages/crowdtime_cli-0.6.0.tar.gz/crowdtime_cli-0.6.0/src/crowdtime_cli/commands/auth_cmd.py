"""Authentication commands: login, logout, whoami."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from ..auth import clear_token, get_token, save_token
from ..client import CrowdTimeClient
from ..config import get_config
from ..formatters import format_error, format_success, print_json
from ..models import User

app = typer.Typer(name="auth", help="Authentication commands.")
console = Console()


@app.command()
def login(
    token: Optional[str] = typer.Option(
        None, "--token", "-t",
        help="API token for manual authentication (skips browser login).",
    ),
    no_browser: bool = typer.Option(
        False, "--no-browser",
        help="Don't open a browser. Prompt for token instead.",
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Authenticate with the CrowdTime server.

    By default, opens your browser for Google OAuth login.
    Use --token to provide an API token directly, or --no-browser to be prompted.
    """
    if token:
        _login_with_token(token, output_json)
    elif no_browser:
        manual_token = typer.prompt("API Token", hide_input=True)
        if not manual_token or not manual_token.strip():
            format_error("Token cannot be empty.")
            raise typer.Exit(1)
        _login_with_token(manual_token.strip(), output_json)
    else:
        _login_with_browser(output_json)


def _login_with_token(token: str, output_json: bool) -> None:
    """Authenticate using a provided API token."""
    token = token.strip()
    if not token:
        format_error("Token cannot be empty.")
        raise typer.Exit(1)

    save_token(token)
    try:
        client = CrowdTimeClient(require_auth=True, require_org=False)
        data = client.get("/api/v1/auth/me/", org_scoped=False)
        user = User(**data)

        if output_json:
            print_json(user)
        else:
            format_success(f"Logged in as {user.display_name} ({user.email})")
    except SystemExit:
        clear_token()
        format_error("Invalid token. Could not authenticate.")
        raise typer.Exit(1)


def _login_with_browser(output_json: bool) -> None:
    """Authenticate via browser-based Google OAuth."""
    from ..oauth import run_oauth_flow

    config = get_config()
    server_url = config.server_url

    console.print(f"\n[bold]Opening browser for Google login...[/bold]")
    console.print(f"[dim]Server: {server_url}[/dim]")
    console.print(f"[dim]Waiting for authentication (up to 2 minutes)...[/dim]\n")

    result = run_oauth_flow(server_url)

    if result is None:
        console.print()
        format_error(
            "Browser login failed or timed out.\n"
            "  Possible causes:\n"
            "  - Browser didn't open (try copying the URL manually)\n"
            "  - Google OAuth is not configured on the server\n"
            "  - Login was cancelled or took too long\n\n"
            "  You can also login with a token:\n"
            "    ct auth login --token <your-api-token>\n"
            "    ct auth login --no-browser"
        )
        raise typer.Exit(1)

    api_token, org_slug = result

    # Store the token
    save_token(api_token)

    # Auto-set the organization if returned
    if org_slug:
        config.set("defaults.organization", org_slug)

    # Verify the token works
    try:
        client = CrowdTimeClient(require_auth=True, require_org=False)
        data = client.get("/api/v1/auth/me/", org_scoped=False)
        user = User(**data)

        if output_json:
            print_json(user)
        else:
            format_success(f"Logged in as {user.display_name} ({user.email})")
            if org_slug:
                console.print(f"  Organization set to [cyan]{org_slug}[/cyan]")
            console.print()
    except SystemExit:
        clear_token()
        format_error("Token verification failed after OAuth login.")
        raise typer.Exit(1)


@app.command()
def logout() -> None:
    """Log out and remove stored credentials."""
    if not get_token():
        console.print("[dim]Already logged out.[/dim]")
        return

    clear_token()
    format_success("Logged out. Token removed.")


@app.command()
def whoami(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show the currently authenticated user and organization."""
    client = CrowdTimeClient(require_auth=True, require_org=False)
    data = client.get("/api/v1/auth/me/", org_scoped=False)
    user = User(**data)

    if output_json:
        print_json(user)
        return

    console.print(f"\n[bold]{user.display_name}[/bold]")
    console.print(f"  Email:    {user.email}")
    console.print(f"  Timezone: {user.timezone}")

    org_slug = client.config.organization
    if org_slug:
        console.print(f"  Org:      [cyan]{org_slug}[/cyan]")
    else:
        console.print("  Org:      [dim]Not set (run ct org switch <slug>)[/dim]")
    console.print()
