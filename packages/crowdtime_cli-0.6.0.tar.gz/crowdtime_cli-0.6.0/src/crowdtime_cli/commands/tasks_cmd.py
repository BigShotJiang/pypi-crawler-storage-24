"""Task commands: list, create."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..formatters import format_error, format_success, print_json
from ..models import Task

app = typer.Typer(name="tasks", help="Manage tasks.")
console = Console()


@app.command("list")
def list_tasks(
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Filter by project."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List available tasks."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if project:
        params["project"] = project

    try:
        data = client.get("/tasks/", params=params)
        tasks_list = data if isinstance(data, list) else data.get("results", [])
        tasks = [Task(**item) for item in tasks_list]

        if output_json:
            print_json(tasks)
            return

        if not tasks:
            console.print("[dim]No tasks found.[/dim]")
            return

        table = Table(show_header=True, header_style="bold")
        table.add_column("ID", style="dim")
        table.add_column("Name", width=25)
        table.add_column("Project", style="cyan", width=15)
        table.add_column("Billable", justify="center", width=8)

        for t in tasks:
            table.add_row(
                str(t.id),
                t.name,
                t.project_name or "",
                "[green]$[/green]" if t.is_billable else "",
            )

        console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def create(
    name: str = typer.Argument(..., help="Task name."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project to assign to."),
    billable: bool = typer.Option(True, "--billable/--no-billable", "-b/-B",
                                  help="Mark as billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a new task. If --project is specified, also assigns it to that project."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {"name": name, "is_billable": billable}

    try:
        data = client.post("/tasks/", data=payload)
        task = Task(**data)

        # If a project is specified, assign the task to it
        if project:
            try:
                client.post(f"/projects/{project}/tasks/", data={"task": task.id})
            except APIError as e:
                # Task was created but assignment failed — warn, don't fail
                console.print(
                    f"[yellow]Warning:[/yellow] Task created but could not assign "
                    f"to project '{project}': {e.message}"
                )

        if output_json:
            print_json(task)
        else:
            msg = f"Task '{task.name}' created (ID: {task.id})"
            if project:
                msg += f" and assigned to project"
            format_success(msg)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
