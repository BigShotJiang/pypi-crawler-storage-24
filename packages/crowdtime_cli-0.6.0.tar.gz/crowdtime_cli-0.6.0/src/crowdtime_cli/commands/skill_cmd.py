"""Skill commands: install agent skills for LLM coding tools."""

from __future__ import annotations

import shutil
from enum import Enum
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..formatters import format_error, format_success

app = typer.Typer(name="skill", help="Manage CrowdTime agent skills for LLM coding tools.")
console = Console()

# Bundled skill files live next to this package
SKILLS_SOURCE = Path(__file__).resolve().parent.parent / "skills" / "crowdtime"


class Tool(str, Enum):
    claude = "claude"
    codex = "codex"
    gemini = "gemini"
    cursor = "cursor"


# Maps tool name -> (global skills dir, project skills dir pattern)
TOOL_PATHS: dict[str, tuple[Path, str]] = {
    "claude": (
        Path.home() / ".claude" / "skills",
        ".claude/skills",
    ),
    "codex": (
        Path.home() / ".codex" / "skills",
        ".agents/skills",
    ),
    "gemini": (
        Path.home() / ".gemini" / "skills",
        ".gemini/skills",
    ),
    "cursor": (
        # Cursor doesn't have a global skills dir; uses project-level only
        Path.home() / ".cursor" / "skills",
        ".cursor-plugin/skills",
    ),
}

SKILL_NAME = "crowdtime"


def _detect_installed_tools() -> list[str]:
    """Detect which LLM coding tools are installed by checking config dirs."""
    found = []
    indicators = {
        "claude": [Path.home() / ".claude"],
        "codex": [Path.home() / ".codex"],
        "gemini": [Path.home() / ".gemini"],
        "cursor": [Path.home() / ".cursor"],
    }
    for tool, paths in indicators.items():
        if any(p.exists() for p in paths):
            found.append(tool)
    return found


def _get_project_dir() -> Path:
    """Return the current working directory for project-level installs."""
    return Path.cwd()


def _install_skill(target_dir: Path) -> tuple[bool, str]:
    """Copy bundled skill files to the target directory.

    Returns (success, message).
    """
    if not SKILLS_SOURCE.exists():
        return False, "Bundled skill files not found. Reinstall crowdtime-cli."

    dest = target_dir / SKILL_NAME
    already_exists = dest.exists()

    # Copy skill tree
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(SKILLS_SOURCE, dest)

    verb = "Updated" if already_exists else "Installed"
    return True, f"{verb} skill at {dest}"


@app.command("install")
def install(
    tool: Optional[Tool] = typer.Option(
        None, "--tool", "-t",
        help="Target tool (claude, codex, gemini, cursor). Auto-detects if omitted.",
    ),
    global_install: bool = typer.Option(
        False, "--global", "-g",
        help="Install to user-wide skills directory (~/.claude/skills/, etc.).",
    ),
    all_tools: bool = typer.Option(
        False, "--all", "-a",
        help="Install for all detected tools.",
    ),
) -> None:
    """Install the CrowdTime skill for your LLM coding tool.

    By default installs to the current project. Use --global for user-wide install.

    Examples:
        ct skill install                    # auto-detect tool, project-level
        ct skill install --global           # auto-detect tool, user-wide
        ct skill install --tool claude      # explicit tool
        ct skill install --all --global     # all detected tools, user-wide
    """
    if not SKILLS_SOURCE.exists():
        format_error("Bundled skill files not found. Reinstall crowdtime-cli.")
        raise typer.Exit(1)

    # Determine which tools to install for
    if tool:
        tools = [tool.value]
    elif all_tools:
        tools = _detect_installed_tools()
        if not tools:
            format_error(
                "No LLM coding tools detected. "
                "Use --tool to specify one (claude, codex, gemini, cursor)."
            )
            raise typer.Exit(1)
    else:
        # Auto-detect: pick the first one found
        tools = _detect_installed_tools()
        if not tools:
            format_error(
                "No LLM coding tools detected.\n"
                "  Looked for: ~/.claude, ~/.codex, ~/.gemini, ~/.cursor\n"
                "  Use --tool to specify one explicitly."
            )
            raise typer.Exit(1)
        # Default to first detected
        tools = [tools[0]]

    installed_count = 0

    for t in tools:
        global_dir, project_pattern = TOOL_PATHS[t]

        if global_install:
            target = global_dir
        else:
            target = _get_project_dir() / project_pattern

        success, message = _install_skill(target)
        if success:
            console.print(f"[bold green]{t}:[/bold green] {message}")
            installed_count += 1
        else:
            console.print(f"[bold red]{t}:[/bold red] {message}")

    if installed_count == 0:
        raise typer.Exit(1)

    # Show usage hint
    console.print()
    if "claude" in tools:
        console.print("[dim]Claude Code: skill auto-activates or use /crowdtime[/dim]")
    if "codex" in tools:
        console.print("[dim]Codex: skill auto-activates or use $crowdtime[/dim]")
    if "gemini" in tools:
        console.print("[dim]Gemini: skill auto-activates when time tracking is mentioned[/dim]")
    if "cursor" in tools:
        console.print("[dim]Cursor: skill auto-activates in agent mode[/dim]")


@app.command("uninstall")
def uninstall(
    tool: Optional[Tool] = typer.Option(
        None, "--tool", "-t",
        help="Target tool. Auto-detects if omitted.",
    ),
    global_install: bool = typer.Option(
        False, "--global", "-g",
        help="Remove from user-wide skills directory.",
    ),
    all_tools: bool = typer.Option(
        False, "--all", "-a",
        help="Remove from all detected tools.",
    ),
) -> None:
    """Remove the CrowdTime skill from your LLM coding tool."""
    if tool:
        tools = [tool.value]
    elif all_tools:
        tools = list(TOOL_PATHS.keys())
    else:
        tools = _detect_installed_tools() or list(TOOL_PATHS.keys())

    removed = 0
    for t in tools:
        global_dir, project_pattern = TOOL_PATHS[t]

        if global_install:
            target = global_dir / SKILL_NAME
        else:
            target = _get_project_dir() / project_pattern / SKILL_NAME

        if target.exists():
            shutil.rmtree(target)
            console.print(f"[bold green]{t}:[/bold green] Removed skill from {target}")
            removed += 1

    if removed == 0:
        console.print("[dim]No installed skills found to remove.[/dim]")


@app.command("status")
def status() -> None:
    """Show where the CrowdTime skill is installed."""
    table = Table(title="CrowdTime Skill Status")
    table.add_column("Tool", style="bold")
    table.add_column("Scope")
    table.add_column("Path")
    table.add_column("Status")

    project_dir = _get_project_dir()

    for tool_name, (global_dir, project_pattern) in TOOL_PATHS.items():
        # Check global
        global_skill = global_dir / SKILL_NAME
        if global_skill.exists():
            table.add_row(
                tool_name, "global", str(global_skill),
                "[green]installed[/green]",
            )
        else:
            table.add_row(
                tool_name, "global", str(global_skill),
                "[dim]not installed[/dim]",
            )

        # Check project
        project_skill = project_dir / project_pattern / SKILL_NAME
        if project_skill.exists():
            table.add_row(
                "", "project", str(project_skill),
                "[green]installed[/green]",
            )
        else:
            table.add_row(
                "", "project", str(project_skill),
                "[dim]not installed[/dim]",
            )

    console.print()
    console.print(table)
    console.print()

    detected = _detect_installed_tools()
    if detected:
        console.print(f"[dim]Detected tools: {', '.join(detected)}[/dim]")
    else:
        console.print("[dim]No LLM coding tools detected on this machine.[/dim]")
