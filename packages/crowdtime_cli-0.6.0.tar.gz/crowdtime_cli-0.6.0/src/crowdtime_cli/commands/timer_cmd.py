"""Timer commands: start, stop, status, switch, discard."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from ..client import APIError, CrowdTimeClient
from ..formatters import format_entry_summary, format_error, format_success, format_timer, print_json
from ..models import TimeEntry
from ..resolvers import resolve_task

app = typer.Typer(name="timer", help="Timer commands for tracking time.")
console = Console()


@app.command()
def start(
    description: str = typer.Argument("", help="What are you working on?"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name or ID."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="Task name or ID."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable/non-billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Start a new timer.

    If a timer is already running, you'll be asked to stop it first.
    Use 'ct timer switch' to stop and start in one step.
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    project_id = project or client.config.default_project
    if not project_id:
        format_error("Project is required. Use -p <project-id> or set a default with: ct projects switch <slug>")
        raise typer.Exit(1)

    payload: dict = {
        "project_id": project_id,
    }
    if description:
        payload["notes"] = description
    if task:
        try:
            payload["task_id"] = resolve_task(client, task, project_id=project_id)
        except APIError as e:
            format_error(f"Failed to resolve task '{task}': {e.message}")
            raise typer.Exit(1)
    if billable is not None:
        payload["is_billable"] = billable

    try:
        data = client.post("/time/start/", data=payload)
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_success("Timer started")
            format_timer(entry)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def stop(
    note: Optional[str] = typer.Option(None, "--note", "-n", help="Add a note to the entry."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Stop the currently running timer."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if note:
        payload["note"] = note

    try:
        data = client.post("/time/stop/", data=payload if payload else None)
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_success("Timer stopped")
            format_entry_summary(entry)
    except APIError as e:
        if e.status_code == 404:
            format_error("No timer is currently running.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def status(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show the currently running timer."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/time/running/")
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_timer(entry)
    except APIError as e:
        if e.status_code == 404:
            console.print("[dim]No timer is currently running.[/dim]")
        else:
            format_error(e.message)
            raise typer.Exit(1)


@app.command()
def switch(
    description: str = typer.Argument("", help="What are you switching to?"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name or ID."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="Task name or ID."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable/non-billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Stop the current timer and start a new one."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    # Stop current timer
    try:
        stop_data = client.post("/time/stop/")
        stopped = TimeEntry(**stop_data)
        if not output_json:
            console.print(f"[dim]Stopped: {stopped.description or '(no description)'} "
                          f"({stopped.project_name or ''})[/dim]")
    except APIError as e:
        if e.status_code != 404:
            format_error(f"Could not stop current timer: {e.message}")
            raise typer.Exit(1)

    # Start new timer
    project_id = project or client.config.default_project
    if not project_id:
        format_error("Project is required. Use -p <project-id> or set a default with: ct projects switch <slug>")
        raise typer.Exit(1)

    payload: dict = {
        "project_id": project_id,
    }
    if description:
        payload["notes"] = description
    if task:
        try:
            payload["task_id"] = resolve_task(client, task, project_id=project_id)
        except APIError as e:
            format_error(f"Failed to resolve task '{task}': {e.message}")
            raise typer.Exit(1)
    if billable is not None:
        payload["is_billable"] = billable

    try:
        data = client.post("/time/start/", data=payload)
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_success("Switched timer")
            format_timer(entry)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def discard(
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Discard the running timer without saving."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    # Get the running entry
    try:
        data = client.get("/time/running/")
        entry = TimeEntry(**data)
    except APIError as e:
        if e.status_code == 404:
            console.print("[dim]No timer is currently running.[/dim]")
            return
        format_error(e.message)
        raise typer.Exit(1)

    if not force:
        desc = entry.description or "(no description)"
        if not typer.confirm(f"Discard timer '{desc}'?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    try:
        client.delete(f"/time/{entry.id}/")
        format_success("Timer discarded.")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
