"""Billing commands: status, portal, plan, reactivate, events."""

from __future__ import annotations

import webbrowser
from decimal import Decimal
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..formatters import format_error, format_success, print_json

app = typer.Typer(name="billing", help="Manage subscription and billing.")
console = Console()


# ─── Helpers ──────────────────────────────────────────────────────


STATUS_COLORS = {
    "active": "green",
    "trialing": "blue",
    "past_due": "red",
    "unpaid": "red",
    "canceled": "yellow",
    "paused": "yellow",
    "incomplete": "yellow",
    "incomplete_expired": "red",
}

STATUS_LABELS = {
    "active": "ACTIVE",
    "trialing": "TRIALING",
    "past_due": "PAST DUE",
    "unpaid": "UNPAID",
    "canceled": "CANCELED",
    "paused": "PAUSED",
    "incomplete": "INCOMPLETE",
    "incomplete_expired": "EXPIRED",
}

PLAN_LABELS = {
    "monthly": "Monthly",
    "annual": "Annual",
}


def _cents_to_dollars(cents: int | str | None) -> Decimal:
    """Convert an amount in cents to dollars."""
    if cents is None:
        return Decimal("0")
    try:
        return Decimal(str(cents)) / Decimal("100")
    except Exception:
        return Decimal("0")


def _format_currency(amount: Decimal) -> str:
    """Format a Decimal dollar amount for display."""
    return f"${amount:,.2f}"


def _format_date(date_str: str | None) -> str:
    """Format an ISO date string for display (YYYY-MM-DD)."""
    if not date_str:
        return ""
    # Handle datetime strings by taking just the date part
    return date_str[:10]


# ─── Commands ─────────────────────────────────────────────────────


@app.callback(invoke_without_command=True)
def billing_default(
    ctx: typer.Context,
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show subscription status or manage billing."""
    if ctx.invoked_subcommand is None:
        status(output_json=output_json)


@app.command("status")
def status(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show current subscription status.

    Displays plan, seats, pricing, and next billing date.

    Examples:
        ct billing
        ct billing status
        ct billing status --json
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/billing/")
    except APIError as e:
        if e.status_code == 402:
            console.print(
                "[yellow]No active subscription.[/yellow] "
                "Run [bold]ct billing portal[/bold] to manage your billing."
            )
            raise typer.Exit(1)
        if e.status_code == 404:
            console.print(
                "[dim]No subscription found for this organization.[/dim]\n"
                "Run [bold]ct billing checkout[/bold] to start a free trial (owner only)."
            )
            raise typer.Exit(1)
        format_error(e.message)
        raise typer.Exit(1)

    if output_json:
        print_json(data)
        return

    sub_status = data.get("status", "unknown")
    plan = data.get("plan", "")
    seat_count = data.get("seat_count", 0)

    # Amounts come from the serializer in cents
    base_dollars = _cents_to_dollars(data.get("base_amount"))
    per_seat_dollars = _cents_to_dollars(data.get("per_seat_amount"))
    total_dollars = _cents_to_dollars(data.get("total_amount"))

    period_end = _format_date(data.get("current_period_end"))
    cancel_at_end = data.get("cancel_at_period_end", False)
    trial_ends = _format_date(data.get("trial_ends_at"))

    # Calculate next billing amount (total * months in period)
    # For monthly it's the same; for annual it's total * 12
    if plan == "annual":
        next_amount = total_dollars * 12
    else:
        next_amount = total_dollars

    # Status styling
    color = STATUS_COLORS.get(sub_status, "yellow")
    label = STATUS_LABELS.get(sub_status, sub_status.upper())

    # Build the info table (no header, simple key-value)
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="dim", width=12)
    table.add_column("Value")

    table.add_row("Status", f"[{color}]{label}[/{color}]")
    table.add_row("Plan", PLAN_LABELS.get(plan, plan.capitalize()))
    table.add_row("Seats", str(seat_count))
    table.add_row("Base", f"{_format_currency(base_dollars)}/mo")
    table.add_row("Per seat", f"{_format_currency(per_seat_dollars)}/mo")
    table.add_row("Total", f"{_format_currency(total_dollars)}/mo")

    if sub_status == "trialing" and trial_ends:
        table.add_row("Trial ends", trial_ends)
    elif period_end:
        table.add_row("Next bill", period_end)
        table.add_row("Next amount", _format_currency(next_amount))

    if cancel_at_end:
        table.add_row("", "[yellow]Cancels at period end[/yellow]")

    panel = Panel(
        table,
        title="[bold]Billing[/bold]",
        border_style=color,
        padding=(1, 1),
    )
    console.print(panel)


@app.command("portal")
def portal(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Open the Stripe billing portal in your browser.

    Allows you to update payment methods, view invoices,
    and manage your subscription. Requires owner or admin role.

    Examples:
        ct billing portal
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    # Build the return URL pointing to the frontend billing page
    org_slug = client.org_slug
    frontend_url = client.config.frontend_url
    return_url = f"{frontend_url}/{org_slug}/settings/billing"

    try:
        data = client.post("/billing/portal/", data={"return_url": return_url})
    except APIError as e:
        if e.status_code == 403:
            format_error(
                "Permission denied. Only organization owners and admins "
                "can access the billing portal."
            )
            raise typer.Exit(1)
        if e.status_code == 404:
            format_error(
                "No subscription found. An organization owner must set up "
                "billing from the web dashboard first."
            )
            raise typer.Exit(1)
        format_error(e.message)
        raise typer.Exit(1)

    portal_url = data.get("portal_url", data.get("url", ""))

    if not portal_url:
        format_error("No portal URL returned from the server.")
        raise typer.Exit(1)

    if output_json:
        print_json({"portal_url": portal_url})
        return

    # Open in default browser
    webbrowser.open(portal_url)

    format_success("Billing portal opened in your browser.")
    console.print(f"\n  [dim]URL:[/dim] {portal_url}")
    console.print("  [dim]If the browser didn't open, copy the URL above.[/dim]")


@app.command("checkout")
def checkout(
    plan_choice: str = typer.Argument(
        "monthly", help="Plan to subscribe to: 'monthly' or 'annual'."
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Start a new subscription via Stripe Checkout.

    Opens the Stripe Checkout page in your browser to start a free
    trial or subscribe. Requires owner role.

    Examples:
        ct billing checkout
        ct billing checkout annual
    """
    plan_choice = plan_choice.lower()
    if plan_choice not in ("monthly", "annual"):
        format_error("Plan must be 'monthly' or 'annual'.")
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    org_slug = client.org_slug
    frontend_url = client.config.frontend_url
    billing_url = f"{frontend_url}/{org_slug}/settings/billing"

    try:
        data = client.post("/billing/checkout/", data={
            "plan": plan_choice,
            "success_url": f"{billing_url}?checkout=success",
            "cancel_url": f"{billing_url}?checkout=canceled",
        })
    except APIError as e:
        if e.status_code == 400:
            format_error(e.message or "Cannot create checkout session.")
            raise typer.Exit(1)
        if e.status_code == 403:
            format_error("Permission denied. Only the organization owner can start a subscription.")
            raise typer.Exit(1)
        format_error(e.message)
        raise typer.Exit(1)

    checkout_url = data.get("checkout_url", "")

    if not checkout_url:
        format_error("No checkout URL returned from the server.")
        raise typer.Exit(1)

    if output_json:
        print_json({"checkout_url": checkout_url})
        return

    webbrowser.open(checkout_url)

    format_success("Stripe Checkout opened in your browser.")
    console.print(f"\n  [dim]URL:[/dim] {checkout_url}")
    console.print("  [dim]If the browser didn't open, copy the URL above.[/dim]")


@app.command("plan")
def plan(
    new_plan: str = typer.Argument(
        ..., help="Plan to switch to: 'monthly' or 'annual'."
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Switch billing plan between monthly and annual.

    Requires owner role. The change takes effect immediately with
    prorated credit for the remainder of the current period.

    Examples:
        ct billing plan annual
        ct billing plan monthly
    """
    new_plan = new_plan.lower()
    if new_plan not in ("monthly", "annual"):
        format_error("Plan must be 'monthly' or 'annual'.")
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.patch("/billing/plan/", data={"plan": new_plan})
    except APIError as e:
        if e.status_code == 400:
            format_error(e.message or "Invalid plan change request.")
            raise typer.Exit(1)
        if e.status_code == 403:
            format_error("Permission denied. Only the organization owner can switch plans.")
            raise typer.Exit(1)
        if e.status_code == 404:
            format_error("No subscription found.")
            raise typer.Exit(1)
        format_error(e.message)
        raise typer.Exit(1)

    if output_json:
        print_json(data)
        return

    plan_label = PLAN_LABELS.get(new_plan, new_plan.capitalize())
    format_success(f"Switched to {plan_label} billing.")

    total = _cents_to_dollars(data.get("total_amount"))
    if new_plan == "annual":
        console.print(f"  [dim]Billed annually at {_format_currency(total * 12)}/yr[/dim]")
    else:
        console.print(f"  [dim]Billed at {_format_currency(total)}/mo[/dim]")


@app.command("reactivate")
def reactivate(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Reactivate a canceled subscription.

    Undoes a pending cancellation so the subscription continues
    at the end of the current billing period. Requires owner role.

    Examples:
        ct billing reactivate
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post("/billing/reactivate/", data={})
    except APIError as e:
        if e.status_code == 400:
            format_error(e.message or "Subscription is not scheduled for cancellation.")
            raise typer.Exit(1)
        if e.status_code == 403:
            format_error("Permission denied. Only the organization owner can reactivate.")
            raise typer.Exit(1)
        if e.status_code == 404:
            format_error("No subscription found.")
            raise typer.Exit(1)
        format_error(e.message)
        raise typer.Exit(1)

    if output_json:
        print_json(data)
        return

    format_success("Subscription reactivated.")
    period_end = _format_date(data.get("current_period_end"))
    if period_end:
        console.print(f"  [dim]Next renewal: {period_end}[/dim]")


@app.command("events")
def events(
    limit: int = typer.Option(20, "--limit", "-n", help="Number of events to show."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show billing event audit log.

    Displays recent Stripe webhook events processed for this
    organization. Requires owner role.

    Examples:
        ct billing events
        ct billing events -n 50
        ct billing events --json
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/billing/events/")
    except APIError as e:
        if e.status_code == 403:
            format_error("Permission denied. Only the organization owner can view billing events.")
            raise typer.Exit(1)
        if e.status_code == 404:
            format_error("No subscription found.")
            raise typer.Exit(1)
        format_error(e.message)
        raise typer.Exit(1)

    # Handle both paginated and flat list responses
    event_list = data if isinstance(data, list) else data.get("results", data.get("data", []))
    event_list = event_list[:limit]

    if output_json:
        print_json(event_list)
        return

    if not event_list:
        console.print("[dim]No billing events found.[/dim]")
        return

    table = Table(title="Billing Events", show_lines=False)
    table.add_column("Date", style="dim", width=10)
    table.add_column("Event", width=40)
    table.add_column("Status", width=10)

    for event in event_list:
        date = _format_date(event.get("created_at"))
        event_type = event.get("event_type", "unknown")
        processed = event.get("processed", False)
        error = event.get("error", "")

        if error:
            status_str = "[red]FAILED[/red]"
        elif processed:
            status_str = "[green]OK[/green]"
        else:
            status_str = "[yellow]PENDING[/yellow]"

        table.add_row(date, event_type, status_str)

    console.print(table)
