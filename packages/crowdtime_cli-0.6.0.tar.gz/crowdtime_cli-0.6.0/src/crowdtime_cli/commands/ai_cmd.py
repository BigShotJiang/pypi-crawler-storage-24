"""AI commands: parse, suggest, summarize."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from ..client import APIError, CrowdTimeClient
from ..formatters import (
    format_error,
    format_parse_result,
    format_success,
    format_suggestions,
    print_json,
)
from ..models import ParseResult, Suggestion, TimeEntry, WeeklySummary
from ..utils import format_date, parse_date

app = typer.Typer(name="ai", help="AI-powered time tracking features.")
console = Console()


@app.command()
def parse(
    text: str = typer.Argument(..., help="Natural language time entry description."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be created without saving."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Parse natural language into a time entry.

    Examples:
        ct ai parse "2 hours on project alpha doing code review"
        ct ai parse "spent yesterday afternoon on bug fixes for client X"
        ct ai parse "30min standup" --yes
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post("/ai/parse/", data={"text": text})
        result = ParseResult(**data)

        if output_json:
            print_json(result)
            return

        format_parse_result(result)

        if dry_run:
            console.print("[dim]Dry run - not saving.[/dim]")
            return

        if not yes:
            if not typer.confirm("Create this entry?"):
                console.print("[dim]Cancelled.[/dim]")
                return

        # Confirm and create the entry
        confirm_data = client.post("/ai/parse/confirm/", data={
            "parse_log_id": result.parse_log_id,
            "parsed_result": result.parsed_result,
        })
        entry = TimeEntry(**confirm_data)
        format_success("Entry created from AI parse")
        from ..formatters import format_entry_summary
        format_entry_summary(entry)

    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def suggest(
    date: Optional[str] = typer.Option(None, "--date", "-d", help="Date for suggestions."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Get AI-powered entry suggestions based on your patterns.

    Suggests what you might be working on based on your history.
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if date:
        try:
            params["date"] = format_date(parse_date(date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    try:
        data = client.get("/ai/suggestions/", params=params)
        suggestions_list = data if isinstance(data, list) else data.get("results", [])
        suggestions = [Suggestion(**item) for item in suggestions_list]

        if output_json:
            print_json(suggestions)
            return

        format_suggestions(suggestions)

        if suggestions:
            choice = typer.prompt(
                "Start a timer with suggestion # (or Enter to skip)",
                default="",
                show_default=False,
            )
            if choice.strip().isdigit():
                idx = int(choice.strip()) - 1
                if 0 <= idx < len(suggestions):
                    s = suggestions[idx]
                    payload: dict = {"description": s.description}
                    if s.project_name:
                        payload["project"] = s.project_name
                    if s.task_name:
                        payload["task"] = s.task_name

                    start_data = client.post("/time/start/", data=payload)
                    entry = TimeEntry(**start_data)
                    format_success("Timer started from suggestion")
                    from ..formatters import format_timer
                    format_timer(entry)
                else:
                    format_error("Invalid selection.")

    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def summarize(
    today_flag: bool = typer.Option(False, "--today", help="Summarize today."),
    week: bool = typer.Option(True, "--week", "-w", help="Summarize this week (default)."),
    month: bool = typer.Option(False, "--month", "-m", help="Summarize this month."),
    for_format: str = typer.Option("report", "--for", help="Format for: standup, report, slack."),
    copy: bool = typer.Option(False, "--copy", "-c", help="Copy to clipboard."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Generate an AI summary of your tracked time.

    Examples:
        ct ai summarize --week --for standup
        ct ai summarize --today --for slack --copy
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {"format": for_format}
    if today_flag:
        params["period"] = "today"
    elif month:
        params["period"] = "month"
    else:
        params["period"] = "week"

    try:
        data = client.get("/ai/summary/weekly/", params=params)
        summary = WeeklySummary(**data)

        if output_json:
            print_json(summary)
            return

        from ..utils import format_duration

        console.print(f"\n[bold]{summary.headline}[/bold]")
        console.print(f"Total: [yellow]{format_duration(summary.total_hours)}[/yellow]\n")

        if summary.project_breakdown:
            console.print("[bold]By Project:[/bold]")
            for pb in summary.project_breakdown:
                hours = format_duration(pb.get("hours", 0))
                console.print(f"  [cyan]{pb.get('project', 'Unknown')}[/cyan]: {hours}")

        if summary.insights:
            console.print("\n[bold]Insights:[/bold]")
            for insight in summary.insights:
                console.print(f"  - {insight}")

        console.print()

        if copy:
            try:
                import subprocess
                text_to_copy = f"{summary.headline}\n"
                text_to_copy += f"Total: {format_duration(summary.total_hours)}\n"
                for pb in summary.project_breakdown:
                    text_to_copy += f"  {pb.get('project', '')}: {format_duration(pb.get('hours', 0))}\n"

                process = subprocess.Popen(
                    ["pbcopy"], stdin=subprocess.PIPE, text=True
                )
                process.communicate(text_to_copy)
                format_success("Copied to clipboard")
            except Exception:
                try:
                    process = subprocess.Popen(
                        ["xclip", "-selection", "clipboard"],
                        stdin=subprocess.PIPE, text=True
                    )
                    process.communicate(text_to_copy)
                    format_success("Copied to clipboard")
                except Exception:
                    console.print("[dim]Could not copy to clipboard.[/dim]")

    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
