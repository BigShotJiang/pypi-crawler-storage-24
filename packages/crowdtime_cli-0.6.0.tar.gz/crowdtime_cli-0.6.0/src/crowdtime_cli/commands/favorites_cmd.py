"""Favorites commands: list, create, delete, start."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from ..client import APIError, CrowdTimeClient
from ..formatters import (
    format_error,
    format_favorites_table,
    format_success,
    format_timer,
    print_json,
)
from ..models import FavoriteEntry, TimeEntry

app = typer.Typer(name="favorites", help="Manage favorite time entry templates.")
console = Console()


@app.command("list")
def list_favorites(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List all saved favorites."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/favorites/")
        favs_list = data if isinstance(data, list) else data.get("results", [])
        favorites = [FavoriteEntry(**item) for item in favs_list]

        if output_json:
            print_json(favorites)
        else:
            format_favorites_table(favorites)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def create(
    description: str = typer.Argument("", help="Description for the favorite."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name or ID."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="Task name or ID."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Additional notes."),
    billable: bool = typer.Option(True, "--billable/--no-billable", "-b/-B",
                                  help="Mark as billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a new favorite entry template."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "description": description,
        "is_billable": billable,
    }
    if project:
        payload["project"] = project
    if task:
        payload["task"] = task
    if notes:
        payload["notes"] = notes

    try:
        data = client.post("/favorites/", data=payload)
        fav = FavoriteEntry(**data)

        if output_json:
            print_json(fav)
        else:
            format_success(f"Favorite created (ID: {fav.id})")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def delete(
    favorite_id: str = typer.Argument(..., help="Favorite ID to delete."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Delete a favorite."""
    if not force:
        if not typer.confirm(f"Delete favorite {favorite_id}?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        client.delete(f"/favorites/{favorite_id}/")
        format_success(f"Favorite {favorite_id} deleted.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Favorite {favorite_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def start(
    favorite_id: str = typer.Argument(..., help="Favorite ID to start timer from."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Start a timer from a favorite template."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(f"/favorites/{favorite_id}/start/")
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_success("Timer started from favorite")
            format_timer(entry)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Favorite {favorite_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)
