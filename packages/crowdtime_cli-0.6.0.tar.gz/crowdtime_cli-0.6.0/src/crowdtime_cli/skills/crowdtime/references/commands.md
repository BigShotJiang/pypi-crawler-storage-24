# CrowdTime CLI — Complete Command Reference

Every command, subcommand, argument, flag, and option in the CrowdTime CLI.

## Table of Contents

- [Global Behavior](#global-behavior)
- [ct (bare / status)](#ct-bare--status)
- [ct auth](#ct-auth)
- [ct timer](#ct-timer)
- [ct log](#ct-log)
- [ct clients](#ct-clients)
- [ct expense](#ct-expense)
- [ct billing](#ct-billing)
- [ct payroll](#ct-payroll)
- [ct projects](#ct-projects)
- [ct tasks](#ct-tasks)
- [ct report](#ct-report)
- [ct ai](#ct-ai)
- [ct favorites](#ct-favorites)
- [ct org](#ct-org)
- [ct config](#ct-config)
- [ct timesheet](#ct-timesheet)
- [ct invoice](#ct-invoice)
- [Short Aliases](#short-aliases)

---

## Global Behavior

- Entry points: `crowdtime` and `ct` (identical)
- Config file: `~/.crowdtime/config.toml`
- Token storage: OS keychain (via `keyring`), fallback to `~/.crowdtime/credentials`
- All org-scoped commands require: authenticated user + active organization
- `--json` flag on most commands outputs machine-readable JSON

### Magic Routing

Any unrecognized first argument routes to AI parsing:
```bash
ct "2h on project alpha code review"   # → ct ai parse "..."
```

---

## ct (bare / status)

Shows full status dashboard.

```
ct
ct status [--json]
ct s [--json]           # alias
```

**Output includes:**
- Authenticated user and current organization
- Running timer (if any) with elapsed HH:MM:SS
- Today's entries with progress bar toward daily target
- This week's breakdown with daily hour bars

**Endpoints called:**
- `GET /api/v1/auth/me/`
- `GET /time/running/`
- `GET /time/daily/{today}/`
- `GET /time/weekly/{monday}/`

---

## ct auth

### ct auth login

```
ct auth login [--token/-t TOKEN] [--no-browser] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--token`, `-t` | string | API token (skips browser login) |
| `--no-browser` | flag | Prompt for token instead of opening browser |
| `--json` | flag | JSON output |

- Default (no flags): opens browser for Google OAuth login
- `--token`: provide an API token directly
- `--no-browser`: prompts for token interactively (useful for headless environments)
- Stores token in OS keychain with file fallback
- Validates by calling `GET /api/v1/auth/me/`

### ct auth logout

```
ct auth logout
```

Removes stored credentials from keychain and file.

### ct auth whoami

```
ct auth whoami [--json]
```

Shows: name, email, timezone, current organization.

---

## ct timer

### ct timer start

```
ct timer start [DESCRIPTION] [options]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `DESCRIPTION` | string (optional) | What you're working on |
| `--project`, `-p` | string | Project slug or UUID |
| `--task`, `-t` | string | Task name or UUID (auto-creates and assigns if needed) |
| `--billable`, `-b` | flag | Mark as billable |
| `--no-billable`, `-B` | flag | Mark as non-billable |
| `--json` | flag | JSON output |

- Fails if a timer is already running (use `switch` instead)
- Uses default project from config if `--project` not specified
- Endpoint: `POST /time/start/`

### ct timer stop

```
ct timer stop [--note/-n NOTE] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--note`, `-n` | string | Add a note to the completed entry |
| `--json` | flag | JSON output |

- Returns 404 if no timer running
- Endpoint: `POST /time/stop/`

### ct timer status

```
ct timer status [--json]
```

Shows running timer with elapsed HH:MM:SS, description, project, task, billable status.
Endpoint: `GET /time/running/`

### ct timer switch

```
ct timer switch [DESCRIPTION] [options]
```

Same arguments and options as `timer start`. Atomically stops the current timer and starts a new one.

### ct timer discard

```
ct timer discard [--force/-f]
```

| Option | Type | Description |
|--------|------|-------------|
| `--force`, `-f` | flag | Skip confirmation prompt |

Discards the running timer without saving any time entry.

---

## ct log

**Bare `ct log` (no arguments)** lists today's entries (same as `ct log list`).

`ct log` with options/args auto-routes to `ct log create` — all three forms below are equivalent:
- `ct log -p proj 2h "work"`
- `ct log create -p proj 2h "work"`
- `ct l -p proj 2h "work"`

### ct log create

```
ct log [create] [OPTIONS] DURATION [DESCRIPTION]
```

**IMPORTANT: Options MUST come BEFORE positional arguments (duration, description).** This is a Typer/Click constraint.

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `DURATION` | string (required) | Time spent: `2h`, `2h30m`, `2:30`, `150m`, `0.25d`, or number |
| `DESCRIPTION` | string (optional) | What you worked on |
| `--project`, `-p` | string | Project slug or UUID |
| `--task`, `-t` | string | Task name or UUID (auto-creates and assigns if needed) |
| `--date`, `-d` | string | Date (default: today) |
| `--billable`, `-b` | flag | Billable |
| `--no-billable`, `-B` | flag | Non-billable |
| `--json` | flag | JSON output |

**Usage examples:**
```bash
ct log -p crowdtime-dev 2h "code review"
ct log -p crowdtime-dev -t "Research" -d yesterday 2h30m "meeting"

# Short alias (ct l):
ct l -p crowdtime-dev 2h "code review"
ct l -p crowdtime-dev -t "Design" 1:30 "wireframes"
```

**Duration formats:**
| Format | Example | Result |
|--------|---------|--------|
| Hours | `2h` | 2.0 hours |
| Hours + minutes | `2h30m` | 2.5 hours |
| HH:MM | `2:30` | 2.5 hours |
| Minutes | `150m` | 2.5 hours |
| Days | `0.25d` | 2.0 hours (1d = 8h) |
| Decimal | `2.5` | 2.5 hours |

**Date formats:**
| Format | Example |
|--------|---------|
| Keywords | `today`, `yesterday` |
| Day names | `monday`, `tue`, `fri` |
| Last + day | `last friday` |
| ISO | `2026-03-10` |
| US short | `3/10`, `03/10/2026` |

Endpoint: `POST /time/`

### ct log edit

```
ct log edit ENTRY_ID [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--duration` | string | New duration |
| `--description` | string | New description |
| `--project`, `-p` | string | New project |
| `--task`, `-t` | string | New task (name or UUID) |
| `--date`, `-d` | string | New date |
| `--billable`, `-b` | flag | Set billable |
| `--no-billable`, `-B` | flag | Set non-billable |
| `--json` | flag | JSON output |

Only provided fields are updated. Endpoint: `PATCH /time/{id}/`

### ct log delete

```
ct log delete ENTRY_ID [--force/-f]
```

Requires confirmation unless `--force`. Endpoint: `DELETE /time/{id}/`

### ct log list

```
ct log list [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--date`, `-d` | string | Specific date |
| `--week`, `-w` | flag | This week |
| `--month`, `-m` | flag | This month |
| `--from` | string | Start date for range |
| `--to` | string | End date for range |
| `--project`, `-p` | string | Filter by project |
| `--format` | string | Output: `table`, `json`, `csv` |
| `--json` | flag | JSON output |

Endpoint: `GET /time/`

---

## ct clients

### ct clients list

```
ct clients list [--archived/-a] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--archived`, `-a` | flag | Include archived clients |
| `--json` | flag | JSON output |

Shows: ID, Name, Contact, Projects count, Status.
Endpoint: `GET /clients/`

### ct clients show

```
ct clients show CLIENT_ID [--json]
```

Shows: ID, name, currency, contact info, status.
Endpoint: `GET /clients/{id}/`

### ct clients create

```
ct clients create NAME [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--currency` | string | Currency code (e.g. USD) |
| `--contact` | string | Contact person name |
| `--email` | string | Contact email |
| `--json` | flag | JSON output |

Endpoint: `POST /clients/`

### ct clients archive

```
ct clients archive CLIENT_ID [--force/-f]
```

Soft-archives the client. Requires confirmation unless `--force`.
Endpoint: `DELETE /clients/{id}/`

### ct clients contacts

```
ct clients contacts CLIENT [--json]
```

Lists all contacts for a client. Shows: Name, Email, Phone, Role, Primary status.
Endpoint: `GET /clients/{id}/contacts/`

### ct clients add-contact

```
ct clients add-contact CLIENT --name NAME [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--name` | string (required) | Contact person name |
| `--email` | string | Contact email address |
| `--phone` | string | Contact phone number |
| `--role` | string | Contact's role (e.g. "CTO", "Billing Manager") |
| `--primary` | flag | Set as primary contact |
| `--json` | flag | JSON output |

Endpoint: `POST /clients/{id}/contacts/`

### ct clients remove-contact

```
ct clients remove-contact CLIENT CONTACT_ID [--yes/-y]
```

| Option | Type | Description |
|--------|------|-------------|
| `--yes`, `-y` | flag | Skip confirmation prompt |

Removes a contact from the client. Requires confirmation unless `--yes`.
Endpoint: `DELETE /clients/{id}/contacts/{contact_id}/`

---

## ct expense

Short alias: `ct ex`

### ct expense list

```
ct expense list [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--from` | string | Start date for range |
| `--to` | string | End date for range |
| `--project`, `-p` | string | Filter by project |
| `--category` | string | Filter by category |
| `--billable` | flag | Only billable expenses |
| `--invoiced` | flag | Only invoiced expenses |
| `--json` | flag | JSON output |

Shows: ID, Date, Description, Amount, Category, Project, Billable, Invoiced.
Endpoint: `GET /expenses/`

### ct expense create

```
ct expense create --amount AMOUNT DESCRIPTION [options]
```

**IMPORTANT: `--amount` and other options MUST come BEFORE the positional description argument.**

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `DESCRIPTION` | string (required) | What the expense is for |
| `--amount` | float (required) | Expense amount |
| `--project`, `-p` | string | Project slug or UUID |
| `--category` | string | Expense category name |
| `--vendor` | string | Vendor or merchant name |
| `--date`, `-d` | string | Date (default: today) |
| `--billable`, `-b` | flag | Mark as billable |
| `--notes` | string | Additional notes |
| `--receipt-url` | string | URL to receipt image |
| `--json` | flag | JSON output |

**Usage examples:**
```bash
ct expense create --amount 49.99 "Domain renewal" --project acme-website --category "Software" --billable
ct ex create --amount 125 "Client lunch" --category "Meals" --vendor "La Trattoria" --billable --notes "Q1 planning lunch"
ct ex create --amount 29.99 "Adobe subscription" -p design-project --category "Software" -d yesterday -b
```

Endpoint: `POST /expenses/`

### ct expense edit

```
ct expense edit EXPENSE_ID [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--amount` | float | New amount |
| `--description` | string | New description |
| `--project`, `-p` | string | New project |
| `--category` | string | New category |
| `--vendor` | string | New vendor |
| `--date`, `-d` | string | New date |
| `--billable`, `-b` | flag | Set billable |
| `--notes` | string | New notes |
| `--json` | flag | JSON output |

Only provided fields are updated. Endpoint: `PATCH /expenses/{id}/`

### ct expense delete

```
ct expense delete EXPENSE_ID [--yes/-y]
```

| Option | Type | Description |
|--------|------|-------------|
| `--yes`, `-y` | flag | Skip confirmation prompt |

Requires confirmation unless `--yes`. Endpoint: `DELETE /expenses/{id}/`

### ct expense categories

```
ct expense categories [--json]
```

Lists all expense categories for the organization.
Endpoint: `GET /expenses/categories/`

### ct expense add-category

```
ct expense add-category NAME [--json]
```

Creates a new expense category at the organization level.
Endpoint: `POST /expenses/categories/`

---

## ct billing

Short alias: `ct b`

### ct billing (bare / status)

```
ct billing [--json]
ct billing status [--json]
ct b [--json]           # alias
```

Shows subscription status in a Rich panel: status, plan (monthly/annual), seat count, base price, per-seat price, total monthly cost, next billing date, and next billing amount.

**Status colors:**
| Status | Color |
|--------|-------|
| ACTIVE | green |
| TRIALING | blue |
| PAST_DUE, UNPAID | red |
| CANCELED, PAUSED | yellow |

Handles 402 (subscription inactive) and 404 (no subscription) gracefully.

Endpoint: `GET /billing/`

### ct billing portal

```
ct billing portal [--json]
```

Opens the Stripe Customer Portal in the default browser. Allows updating payment methods, viewing Stripe invoices, and managing the subscription.

### ct billing checkout

```
ct billing checkout [monthly|annual] [--json]
```

Opens Stripe Checkout in the browser to start a new subscription (with free trial). Defaults to monthly plan.

- Requires **owner** role
- Opens the Stripe-hosted checkout page in the default browser
- After checkout, redirects to the billing settings page
- `--json` outputs `{"checkout_url": "..."}` instead of opening the browser
- Errors if the organization already has an active subscription

Endpoint: `POST /billing/checkout/`

### ct billing portal

- Requires **admin+** role (API enforces this; shows friendly error on 403)
- Prints the portal URL for manual access if the browser doesn't open
- `--json` outputs `{"portal_url": "..."}` instead of opening the browser

Endpoint: `POST /billing/portal/`

### ct billing plan

```
ct billing plan <monthly|annual> [--json]
```

Switches the billing plan between monthly and annual. The change takes effect immediately with prorated credit for the remainder of the current period.

- Requires **owner** role
- Shows the new billing amount after switching
- Errors if already on the target plan

Endpoint: `PATCH /billing/plan/`

### ct billing reactivate

```
ct billing reactivate [--json]
```

Undoes a pending cancellation so the subscription continues at the end of the current billing period.

- Requires **owner** role
- Only works when `cancel_at_period_end` is true
- Shows the next renewal date after reactivation

Endpoint: `POST /billing/reactivate/`

### ct billing events

```
ct billing events [--limit/-n N] [--json]
```

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--limit`, `-n` | int | 20 | Number of events to show |
| `--json` | flag | | JSON output |

Shows recent Stripe webhook events processed for this organization. Each event shows date, event type, and processing status (OK, FAILED, PENDING).

- Requires **owner** role

Endpoint: `GET /billing/events/`

---

## ct payroll

Access restricted to HR managers (`is_hr_manager=True`), admins, and owners.

### ct payroll (bare / summary)

```
ct payroll [--json]
ct payroll summary [--period YYYY-MM] [--json]
```

Shows payroll periods overview. Defaults to listing all periods.

Endpoint: `GET /payroll/periods/`

### ct payroll members

```
ct payroll members [--json]
```

Lists all active members with their current compensation configuration (type, rate, effective date).

Endpoints: `GET /payroll/compensation/` + `GET /members/`

### ct payroll show

```
ct payroll show MEMBER [--json]
```

| Argument | Type | Description |
|----------|------|-------------|
| `MEMBER` | string (required) | Member email or name |

Shows all compensation configs for a member (rate history).

Endpoint: `GET /payroll/compensation/?membership=<id>`

### ct payroll set-rate

```
ct payroll set-rate MEMBER RATE [--effective/-e DATE] [--json]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `MEMBER` | string (required) | Member email or name |
| `RATE` | string (required) | Hourly rate (e.g. 75.00) |
| `--effective`, `-e` | string | Effective from date (YYYY-MM-DD, must be 1st of month). Default: 1st of current month |

Sets an hourly compensation config. Creates a new config record (previous configs preserved).

Endpoint: `POST /payroll/compensation/`

### ct payroll set-salary

```
ct payroll set-salary MEMBER AMOUNT [--effective/-e DATE] [--json]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `MEMBER` | string (required) | Member email or name |
| `AMOUNT` | string (required) | Monthly salary (e.g. 5000.00) |
| `--effective`, `-e` | string | Effective from date (YYYY-MM-DD, must be 1st of month). Default: 1st of current month |

Sets a fixed monthly salary compensation config.

Endpoint: `POST /payroll/compensation/`

### ct payroll run

```
ct payroll run [--period YYYY-MM] [--dry-run] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--period` | string | Period as YYYY-MM (default: current month) |
| `--dry-run` | flag | Preview calculations without saving |

Creates a payroll period (if needed) and runs liquidation calculation:
- **Hourly** members: `gross = total_hours × hourly_rate`
- **Salary** members: `gross = monthly_salary` (flat, no proration)

Members without a compensation config are skipped.

Endpoints: `POST /payroll/periods/` + `POST /payroll/periods/<id>/calculate/`

### ct payroll periods

```
ct payroll periods [--json]
```

Lists all payroll periods. Same as `ct payroll summary`.

### ct payroll period

```
ct payroll period PERIOD_ID [--json]
```

Shows period detail with member-by-member breakdown including hours, rates, gross amounts, and payment status.

Endpoint: `GET /payroll/periods/<id>/`

### ct payroll approve

```
ct payroll approve PERIOD_ID [--json]
```

Approves a calculated period. Only calculated periods can be approved.

**Status transitions**: draft → calculated → approved → paid

Endpoint: `POST /payroll/periods/<id>/approve/`

### ct payroll mark-paid

```
ct payroll mark-paid PERIOD_ID [MEMBER] [--all] [--method/-m METHOD] [--reference/--ref/-r REF] [--json]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `PERIOD_ID` | string (required) | Payroll period ID |
| `MEMBER` | string (optional) | Member email (for individual payment) |
| `--all` | flag | Mark all entries as paid |
| `--method`, `-m` | string | Payment method: `bank_transfer` (default), `check`, `cash`, `other` |
| `--reference`, `--ref`, `-r` | string | External reference (transaction ID, check number) |

Marks payroll entries as paid. Either specify a member email OR use `--all`.

Endpoints: `POST /payroll/payments/` + `POST /payroll/payments/<id>/mark-paid/` or `POST /payroll/periods/<id>/mark-all-paid/`

### ct payroll payments

```
ct payroll payments [--period YYYY-MM] [--member MEMBER] [--status STATUS] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--period` | string | Filter by period (YYYY-MM) |
| `--member` | string | Filter by member email |
| `--status` | string | Filter: `pending`, `paid`, `failed` |

Lists payroll payments with amount, status, method, and reference.

Endpoint: `GET /payroll/payments/`

---

## ct projects

### ct projects list

```
ct projects list [--archived/-a] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--archived`, `-a` | flag | Include archived projects |
| `--json` | flag | JSON output |

Shows: ID, Name, Code, Client, Status, Billable. Marks default project.
Endpoint: `GET /projects/`

### ct projects show

```
ct projects show PROJECT_ID [--json]
```

Shows: ID, code, client, status, billable, budget, description.
Endpoint: `GET /projects/{id}/`

### ct projects create

```
ct projects create NAME [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--client`, `-c` | string | Client name (auto-creates if not found) |
| `--billable`, `-b` | flag | Billable (default: true) |
| `--no-billable`, `-B` | flag | Non-billable |
| `--color` | string | Hex color code |
| `--budget` | float | Budget in hours |
| `--code` | string | Short project code |
| `--json` | flag | JSON output |

Endpoint: `POST /projects/`

### ct projects archive

```
ct projects archive PROJECT_ID [--force/-f]
```

Requires confirmation unless `--force`. Endpoint: `PATCH /projects/{id}/`

### ct projects switch

```
ct projects switch SLUG
```

Sets project as default for new entries. Saves to config `defaults.project`.

### ct projects budget

```
ct projects budget PROJECT [--refresh] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `PROJECT` | string (required) | Project slug or UUID |
| `--refresh` | flag | Refresh the budget snapshot before displaying |
| `--json` | flag | JSON output |

Shows budget status: total budget (hours), hours used, hours remaining, percentage spent, and budget health indicator.
If `--refresh` is specified, triggers a fresh budget snapshot calculation before displaying.

**Usage examples:**
```bash
ct projects budget acme-website              # View current budget status
ct projects budget acme-website --refresh    # Refresh snapshot and view
```

---

## ct tasks

### ct tasks list

```
ct tasks list [--project/-p PROJECT] [--json]
```

Shows: ID, Name, Project, Billable. Endpoint: `GET /tasks/`

### ct tasks create

```
ct tasks create NAME [--project/-p PROJECT] [--billable/-b] [--no-billable/-B] [--json]
```

Creates an organization-level task. If `--project` is specified, also assigns the task to that project (via ProjectTask).
Endpoint: `POST /tasks/` + `POST /projects/{id}/tasks/`

---

## ct report

### ct report (main)

```
ct report [period options] [filter options] [output options]
```

**Period options** (default: this week):

| Option | Description |
|--------|-------------|
| `--today` | Today only |
| `--yesterday` | Yesterday |
| `--week`, `-w` | This week |
| `--last-week` | Last week |
| `--month`, `-m` | This month |
| `--from` | Start date (with optional `--to`) |
| `--to` | End date |

**Filter options:**

| Option | Type | Description |
|--------|------|-------------|
| `--project`, `-p` | string | Filter by project |

**Output options:**

| Option | Type | Description |
|--------|------|-------------|
| `--group-by`, `-g` | string | `project` (default), `task`, `day`, `client` |
| `--format`, `-f` | string | `table` (default), `json`, `csv`, `markdown` |

Endpoint: `GET /reports/time-detail/` or `GET /reports/project-summary/`

### ct report projects

```
ct report projects [--week/-w] [--month/-m] [--json]
```

Project breakdown with hours, billable, budget info. Default: this month.

### ct report team

```
ct report team [--week/-w] [--month/-m] [--member MEMBER] [--json]
```

Team utilization: Member, Hours, Billable, Utilization %. Endpoint: `GET /reports/team-utilization/`

---

## ct ai

### ct ai parse

```
ct ai parse TEXT [--dry-run] [--yes/-y] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `TEXT` | string (required) | Natural language time entry |
| `--dry-run` | flag | Preview without creating |
| `--yes`, `-y` | flag | Skip confirmation |
| `--json` | flag | JSON output |

Shows parsed: description, project, task, duration, date, billable, confidence, ambiguities.
Endpoints: `POST /ai/parse/` then `POST /ai/parse/confirm/`

### ct ai suggest

```
ct ai suggest [--date/-d DATE] [--json]
```

AI-powered suggestions based on work patterns. Interactive: select a suggestion to start a timer.
Endpoint: `GET /ai/suggestions/`

### ct ai summarize

```
ct ai summarize [period] [--for FORMAT] [--copy/-c] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--today` | flag | Today |
| `--week`, `-w` | flag | This week (default) |
| `--month`, `-m` | flag | This month |
| `--for` | string | `report` (default), `standup`, `slack` |
| `--copy`, `-c` | flag | Copy to clipboard |
| `--json` | flag | JSON output |

Generates headline, total hours, project breakdown, insights.
Endpoint: `GET /ai/summary/weekly/`

---

## ct favorites

### ct favorites list

```
ct favorites list [--json]
```

Shows: ID, Project, Task, Description, Use count. Endpoint: `GET /favorites/`

### ct favorites create

```
ct favorites create [DESCRIPTION] [--project/-p] [--task/-t] [--notes/-n] [--billable/-b] [--no-billable/-B] [--json]
```

Creates a reusable entry template. Endpoint: `POST /favorites/`

### ct favorites delete

```
ct favorites delete FAVORITE_ID [--force/-f]
```

Endpoint: `DELETE /favorites/{id}/`

### ct favorites start

```
ct favorites start FAVORITE_ID [--json]
```

Starts a timer from a saved template. Endpoint: `POST /favorites/{id}/start/`

---

## ct org

### ct org list

```
ct org list [--json]
```

Lists organizations you belong to. Marks current with `*`. Non-org-scoped.
Endpoint: `GET /api/v1/organizations/`

### ct org switch

```
ct org switch SLUG
```

Switches active organization. Saves to config `defaults.organization`.

### ct org members

```
ct org members [--json]
```

Shows: Name, Email, Role, Status. Endpoint: `GET /members/`

### ct org invite

```
ct org invite EMAIL [--role/-r ROLE] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--role`, `-r` | string | `admin`, `manager`, `project_manager`, `member` (default), `viewer` |

**Roles:**
- `viewer` — external client stakeholder, read-only access scoped to assigned projects
- `member` — can log time, manage own entries
- `project_manager` — manage projects, tasks, timesheets, team time; no financial data (rates, invoices)
- `manager` — Account Manager: project management + invoices, rates, clients, billing
- `admin` — manage org settings, members, integrations

Endpoint: `POST /members/invite/`

### ct org invitations

```
ct org invitations [--json]
```

Lists pending invitations for the current organization. Endpoint: `GET /invitations/`

### ct org resend-invite

```
ct org resend-invite INVITATION_ID [--json]
```

Resends the invitation email for a pending invitation. Endpoint: `POST /invitations/{id}/resend/`

---

## ct config

### ct config set

```
ct config set KEY VALUE
```

Uses dot notation. Examples:
- `ct config set server.url https://api.crowdtime.io`
- `ct config set defaults.project myproject`
- `ct config set defaults.daily_target 7h`
- `ct config set display.compact true`

Auto-converts boolean strings.

### ct config get

```
ct config get KEY
```

### ct config list

```
ct config list [--json]
```

Shows all config with file path.

### ct config edit

```
ct config edit
```

Opens in `$EDITOR`, `$VISUAL`, or `nano`.

### Config Structure

```toml
[server]
url = "https://api.crowdtime.lat"

[defaults]
organization = ""
project = ""
daily_target = "8h"
weekly_target = "40h"
date_format = "%Y-%m-%d"
time_format = "24h"

[display]
theme = "auto"
color = true
compact = false
```

---

## ct timesheet

### ct timesheet list

```
ct timesheet list [--status STATUS] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--status` | string | Filter: `draft`, `submitted`, `approved`, `rejected` |
| `--json` | flag | JSON output |

Lists your timesheets (or all viewable timesheets for managers). Endpoint: `GET /timesheets/`

### ct timesheet submit

```
ct timesheet submit --from DATE --to DATE [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--from` | string (required) | Period start date |
| `--to` | string (required) | Period end date |
| `--json` | flag | JSON output |

Submits a timesheet for the given period. Endpoint: `POST /timesheets/submit/`

### ct timesheet approve

```
ct timesheet approve TIMESHEET_ID [--notes NOTES] [--json]
```

Approves a submitted timesheet (requires manager+ role). Endpoint: `POST /timesheets/{id}/approve/`

### ct timesheet reject

```
ct timesheet reject TIMESHEET_ID --notes NOTES [--json]
```

Rejects a submitted timesheet with notes (requires manager+ role). Endpoint: `POST /timesheets/{id}/reject/`

### ct timesheet team

```
ct timesheet team [--week/-w] [--last-week] [--from DATE] [--to DATE] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--week`, `-w` | flag | This week (default) |
| `--last-week` | flag | Last week |
| `--from` | string | Start date for custom period |
| `--to` | string | End date for custom period |
| `--json` | flag | JSON output |

Shows team overview with hours, entries, and timesheet status for each member. Requires manager+ role.
Endpoint: `GET /timesheets/team-overview/`

---

## ct invoice

### ct invoice list

```
ct invoice list [--status STATUS] [--client CLIENT] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--status` | string | Filter: `draft`, `sent`, `viewed`, `partial`, `paid`, `overdue`, `void` |
| `--client` | string | Filter by client name or ID |
| `--json` | flag | JSON output |

Endpoint: `GET /invoices/`

### ct invoice show

```
ct invoice show INVOICE_ID [--json]
```

Shows invoice details including line items, payments, and totals. Endpoint: `GET /invoices/{id}/`

### ct invoice create

```
ct invoice create --client CLIENT [--due DATE] [--period PERIOD] [--payment-terms TERMS] [--type TYPE] [--currency CUR] [--notes NOTES] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--client` | string (required) | Client name or ID |
| `--due` | string | Due date (default: 30 days from now) |
| `--period` | string | Period preset: `last-week`, `last-2-weeks`, `last-month`, `this-month` |
| `--payment-terms` | string | Payment terms: `receipt`, `net15`, `net30`, or a number of days |
| `--type` | string | `standard` (default), `retainer`, `credit_note` |
| `--currency` | string | Currency code |
| `--notes` | string | Invoice notes |
| `--json` | flag | JSON output |

Creates a draft invoice. When `--period` is specified, billable time entries and billable expenses from that period are automatically imported as line items. The output shows how many time entries and expenses were included.

When `--payment-terms` is specified, the due date is calculated automatically from the issue date (e.g. `net30` sets the due date to 30 days from now). This overrides `--due` if both are provided.

**Usage examples:**
```bash
ct invoice create --client "Acme Corp" --due 2026-04-15
ct invoice create --client "Acme Corp" --period last-month --payment-terms net30
ct invoice create --client "Beta Inc" --period this-month --payment-terms net15
ct invoice create --client "Gamma LLC" --period last-2-weeks --payment-terms receipt
```

Endpoint: `POST /invoices/`

### ct invoice add-line

```
ct invoice add-line INVOICE_ID --description DESC [--quantity QTY] [--rate RATE] [--hours HOURS] [--tax TAX_RATE_NAME] [--json]
```

Adds a line item. `--hours` is shorthand for `--quantity` in hours context. Endpoint: `POST /invoices/{id}/line-items/`

### ct invoice import-time

```
ct invoice import-time INVOICE_ID --from DATE --to DATE [--project/-p PROJECT] [--json]
```

Imports billable time entries as line items. Endpoint: `POST /invoices/{id}/import-time/`

### ct invoice send

```
ct invoice send INVOICE_ID [--json]
```

Marks invoice as sent. Endpoint: `POST /invoices/{id}/send/`

### ct invoice mark-paid

```
ct invoice mark-paid INVOICE_ID [--date DATE] [--method METHOD] [--reference REF] [--json]
```

Records full payment. Endpoint: `POST /invoices/{id}/mark-paid/`

### ct invoice void

```
ct invoice void INVOICE_ID [--force/-f] [--json]
```

Voids an invoice. Requires confirmation unless `--force`. Endpoint: `POST /invoices/{id}/void/`

### ct invoice duplicate

```
ct invoice duplicate INVOICE_ID [--json]
```

Creates a copy of an existing invoice as a new draft. Endpoint: `POST /invoices/{id}/duplicate/`

---

### ct invoice retainer show

```
ct invoice retainer show RETAINER_ID [--json]
```

Shows retainer details including balance info (total deposited, total withdrawn, available balance).

### ct invoice retainer withdraw

```
ct invoice retainer withdraw RETAINER_ID --invoice INVOICE_ID --amount AMOUNT [--notes NOTES] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--invoice`, `-i` | string (required) | Target invoice ID to apply credit to |
| `--amount`, `-a` | string (required) | Amount to withdraw |
| `--notes`, `-n` | string | Notes for the withdrawal |
| `--json` | flag | JSON output |

Withdraws from retainer balance and applies as payment on the target invoice. The target invoice must be:
- Same client as the retainer
- Same currency
- Not a draft, void, paid, or retainer-type invoice

Endpoint: `POST /invoices/retainers/{id}/withdraw/`

### ct invoice retainer withdrawals

```
ct invoice retainer withdrawals RETAINER_ID [--json]
```

Lists all withdrawals for a retainer with amount, target invoice, date, and status (active/reversed).

Endpoint: `GET /invoices/retainers/{id}/withdrawals/`

### ct invoice retainer reverse-withdrawal

```
ct invoice retainer reverse-withdrawal RETAINER_ID --withdrawal WITHDRAWAL_ID --reason REASON [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--withdrawal`, `-w` | string (required) | Withdrawal ID to reverse |
| `--reason`, `-r` | string (required) | Reason for reversal |
| `--json` | flag | JSON output |

Reverses a withdrawal: returns the amount to the retainer balance and adjusts the target invoice's payment.

Endpoint: `POST /invoices/retainers/{id}/withdrawals/{wid}/reverse/`

---

## Short Aliases

| Alias | Expands To |
|-------|-----------|
| `ct` | `ct status` |
| `ct s` | `ct status` |
| `ct t` | `ct timer status` |
| `ct ts` | `ct timer start` |
| `ct tx` | `ct timer stop` |
| `ct l` | `ct log` (create) |
| `ct ll` | `ct log list` |
| `ct p` | `ct projects list` |
| `ct r` | `ct report` |
| `ct b` | `ct billing status` |
| `ct ex` | `ct expense` |
| `ct "text"` | `ct ai parse "text"` |
