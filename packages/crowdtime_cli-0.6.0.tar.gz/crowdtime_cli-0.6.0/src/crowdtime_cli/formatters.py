"""Rich-based output formatting for CrowdTime CLI."""

from __future__ import annotations

import json
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, TextColumn
from rich.table import Table
from rich.text import Text

from .models import FavoriteEntry, ParseResult, Project, Suggestion, TimeEntry
from .utils import format_duration, truncate

console = Console()


def format_error(message: str) -> None:
    """Print an error message."""
    console.print(f"[bold red]Error:[/bold red] {message}")


def format_success(message: str) -> None:
    """Print a success message."""
    console.print(f"[bold green]Done:[/bold green] {message}")


def format_warning(message: str) -> None:
    """Print a warning message."""
    console.print(f"[bold yellow]Warning:[/bold yellow] {message}")


def format_timer(entry: TimeEntry) -> None:
    """Display the currently running timer as a Rich panel."""
    if not entry.is_running:
        console.print("[dim]No timer is currently running.[/dim]")
        return

    elapsed = ""
    if entry.start_time:
        now = datetime.now(timezone.utc)
        start = entry.start_time
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        delta = now - start
        total_seconds = int(delta.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        elapsed = f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    parts: list[str] = []
    if entry.description:
        parts.append(f"[bold]{entry.description}[/bold]")
    if entry.project_name:
        parts.append(f"[cyan]{entry.project_name}[/cyan]")
    if entry.task_name:
        parts.append(f"[dim]{entry.task_name}[/dim]")
    if entry.is_billable:
        parts.append("[green]$[/green]")

    title = " | ".join(parts) if parts else "[dim]No description[/dim]"

    panel = Panel(
        f"[bold green]{elapsed}[/bold green]" if elapsed else "[dim]Running...[/dim]",
        title=title,
        subtitle="[dim]Timer running[/dim]",
        border_style="green",
        padding=(0, 2),
    )
    console.print(panel)


def format_entry_summary(entry: TimeEntry) -> None:
    """Display a single time entry summary."""
    parts: list[str] = []
    if entry.description:
        parts.append(f"[bold]{entry.description}[/bold]")
    if entry.project_name:
        parts.append(f"[cyan]{entry.project_name}[/cyan]")
    if entry.task_name:
        parts.append(f"[dim]{entry.task_name}[/dim]")
    if entry.duration is not None:
        parts.append(f"[yellow]{format_duration(entry.duration)}[/yellow]")
    if entry.date:
        parts.append(f"[dim]{entry.date}[/dim]")

    console.print(" | ".join(parts))


def format_entries_table(entries: list[TimeEntry], show_date: bool = True) -> None:
    """Display time entries in a Rich table."""
    if not entries:
        console.print("[dim]No entries found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("ID", style="dim")
    if show_date:
        table.add_column("Date", width=12)
    table.add_column("Project", style="cyan", width=15)
    table.add_column("Task", style="dim", width=15)
    table.add_column("Description", width=35)
    table.add_column("Duration", justify="right", width=8)
    table.add_column("$", justify="center", width=3)

    for entry in entries:
        row: list[str] = [str(entry.id)]
        if show_date:
            row.append(str(entry.date or ""))
        row.extend([
            entry.project_name or "",
            entry.task_name or "",
            truncate(entry.description, 35),
            format_duration(entry.duration) if not entry.is_running else "[green]running[/green]",
            "[green]$[/green]" if entry.is_billable else "",
        ])
        table.add_row(*row)

    # Total
    total_hours = sum(
        (e.duration or Decimal("0")) for e in entries if not e.is_running
    )
    console.print(table)
    console.print(f"\n[bold]Total:[/bold] {format_duration(total_hours)} ({len(entries)} entries)")


def format_status(
    user_name: str,
    org_name: str,
    running_entry: TimeEntry | None,
    today_entries: list[TimeEntry],
    daily_target: str,
    week_entries: list[TimeEntry] | None = None,
) -> None:
    """Display the full status dashboard."""
    # Header
    console.print(f"\n[bold]CrowdTime[/bold] | {user_name} @ {org_name}\n")

    # Running timer
    if running_entry:
        format_timer(running_entry)
        console.print()
    else:
        console.print("[dim]No timer running[/dim]\n")

    # Today's summary
    from .utils import parse_duration
    try:
        target_hours = parse_duration(daily_target)
    except ValueError:
        target_hours = Decimal("8")

    today_total = sum(
        (e.duration or Decimal("0")) for e in today_entries if not e.is_running
    )

    console.print("[bold]Today[/bold]")
    progress_pct = min(float(today_total / target_hours * 100), 100) if target_hours else 0

    bar_width = 30
    filled = int(bar_width * progress_pct / 100)
    bar = "[green]" + "\u2588" * filled + "[/green]" + "[dim]" + "\u2591" * (bar_width - filled) + "[/dim]"
    console.print(
        f"  {bar} {format_duration(today_total)} / {format_duration(target_hours)} "
        f"({progress_pct:.0f}%)"
    )

    if today_entries:
        for entry in today_entries[-5:]:
            prefix = "[green]\u25cf[/green]" if entry.is_running else "[dim]\u25cb[/dim]"
            dur = "running" if entry.is_running else format_duration(entry.duration)
            desc = truncate(entry.description or "(no description)", 40)
            proj = f" [cyan]{entry.project_name}[/cyan]" if entry.project_name else ""
            console.print(f"  {prefix} {desc}{proj} [{dur}]")

    # Week summary
    if week_entries is not None:
        console.print("\n[bold]This Week[/bold]")
        days: dict[str, Decimal] = {}
        day_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        for entry in week_entries:
            if entry.date:
                day_key = day_names[entry.date.weekday()]
                days[day_key] = days.get(day_key, Decimal("0")) + (entry.duration or Decimal("0"))

        week_total = sum(days.values(), Decimal("0"))
        for day_name in day_names:
            hrs = days.get(day_name, Decimal("0"))
            day_bar_width = 20
            day_pct = min(float(hrs / target_hours * 100), 100) if target_hours else 0
            day_filled = int(day_bar_width * day_pct / 100)
            day_bar = "\u2588" * day_filled + "\u2591" * (day_bar_width - day_filled)
            style = "green" if day_pct >= 100 else "yellow" if day_pct >= 50 else "dim"
            console.print(f"  {day_name} [{style}]{day_bar}[/{style}] {format_duration(hrs)}")

        console.print(f"\n  [bold]Week total:[/bold] {format_duration(week_total)}")

    console.print()


def format_weekly_table(entries_by_day: dict[str, list[TimeEntry]]) -> None:
    """Display entries grouped by day in a weekly view."""
    for day_label, entries in entries_by_day.items():
        day_total = sum((e.duration or Decimal("0")) for e in entries)
        console.print(f"\n[bold]{day_label}[/bold] - {format_duration(day_total)}")
        if entries:
            for entry in entries:
                dur = format_duration(entry.duration)
                desc = truncate(entry.description or "(no description)", 40)
                proj = f" [cyan]{entry.project_name}[/cyan]" if entry.project_name else ""
                console.print(f"  \u25cb {desc}{proj} [{dur}]")
        else:
            console.print("  [dim]No entries[/dim]")


def format_projects_table(projects: list[Project]) -> None:
    """Display projects in a table."""
    if not projects:
        console.print("[dim]No projects found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("ID", style="dim")
    table.add_column("Name", style="bold", width=20)
    table.add_column("Code", width=8)
    table.add_column("Client", width=15)
    table.add_column("Status", width=10)
    table.add_column("Billable", justify="center", width=8)

    for project in projects:
        status_style = "green" if project.status == "active" else "dim"
        table.add_row(
            str(project.id),
            project.name,
            project.code,
            project.client or "",
            f"[{status_style}]{project.status}[/{status_style}]",
            "[green]$[/green]" if project.is_billable else "",
        )

    console.print(table)


def format_parse_result(result: ParseResult) -> None:
    """Display AI parse result for confirmation."""
    parsed = result.parsed_result

    console.print("\n[bold]Parsed Time Entry[/bold]")
    console.print(f"  Confidence: [{'green' if result.confidence > 0.8 else 'yellow'}]"
                  f"{result.confidence:.0%}[/{'green' if result.confidence > 0.8 else 'yellow'}]")

    if parsed.get("description"):
        console.print(f"  Description: [bold]{parsed['description']}[/bold]")
    if parsed.get("project"):
        console.print(f"  Project:     [cyan]{parsed['project']}[/cyan]")
    if parsed.get("task"):
        console.print(f"  Task:        {parsed['task']}")
    if parsed.get("duration"):
        console.print(f"  Duration:    [yellow]{parsed['duration']}[/yellow]")
    if parsed.get("date"):
        console.print(f"  Date:        {parsed['date']}")
    if parsed.get("is_billable") is not None:
        console.print(f"  Billable:    {'Yes' if parsed['is_billable'] else 'No'}")

    if result.ambiguities:
        console.print("\n  [yellow]Ambiguities:[/yellow]")
        for amb in result.ambiguities:
            console.print(f"    - {amb}")

    console.print()


def format_suggestions(suggestions: list[Suggestion]) -> None:
    """Display AI suggestions as a numbered list."""
    if not suggestions:
        console.print("[dim]No suggestions available.[/dim]")
        return

    console.print("\n[bold]Suggested entries[/bold]\n")
    for i, s in enumerate(suggestions, 1):
        console.print(f"  [bold]{i}.[/bold] {s.description}")
        parts: list[str] = []
        if s.project_name:
            parts.append(f"[cyan]{s.project_name}[/cyan]")
        if s.task_name:
            parts.append(s.task_name)
        if s.estimated_hours:
            parts.append(f"[yellow]{format_duration(s.estimated_hours)}[/yellow]")
        if parts:
            console.print(f"     {' | '.join(parts)}")
        if s.reason:
            console.print(f"     [dim]{s.reason}[/dim]")
    console.print()


def format_favorites_table(favorites: list[FavoriteEntry]) -> None:
    """Display favorites in a table."""
    if not favorites:
        console.print("[dim]No favorites found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("ID", style="dim")
    table.add_column("Project", style="cyan", width=15)
    table.add_column("Task", width=15)
    table.add_column("Description", width=30)
    table.add_column("Uses", justify="right", width=6)

    for fav in favorites:
        table.add_row(
            str(fav.id),
            fav.project_name or "",
            fav.task_name or "",
            truncate(fav.description, 30),
            str(fav.use_count),
        )

    console.print(table)


def format_report(data: list[dict[str, Any]], group_by: str = "project") -> None:
    """Display report data in a table."""
    if not data:
        console.print("[dim]No data for this period.[/dim]")
        return

    table = Table(show_header=True, header_style="bold", title="Time Report")
    table.add_column(group_by.capitalize(), style="bold", width=20)
    table.add_column("Hours", justify="right", width=10)
    table.add_column("Billable", justify="right", width=10)
    table.add_column("Entries", justify="right", width=8)

    total_hours = Decimal("0")
    total_billable = Decimal("0")

    for row in data:
        hours = Decimal(str(row.get("hours", 0)))
        billable = Decimal(str(row.get("billable_hours", 0)))
        total_hours += hours
        total_billable += billable

        table.add_row(
            str(row.get(group_by, row.get("project", ""))),
            format_duration(hours),
            format_duration(billable),
            str(row.get("entries_count", "")),
        )

    table.add_section()
    table.add_row(
        "[bold]Total[/bold]",
        f"[bold]{format_duration(total_hours)}[/bold]",
        f"[bold]{format_duration(total_billable)}[/bold]",
        "",
    )

    console.print(table)


ROLE_LABELS = {
    "owner": "Owner",
    "admin": "Admin",
    "manager": "Account Manager",
    "project_manager": "Project Manager",
    "member": "Member",
    "viewer": "Viewer",
}


def format_members_table(members: list[dict[str, Any]]) -> None:
    """Display organization members in a table."""
    if not members:
        console.print("[dim]No members found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("Name", width=20)
    table.add_column("Email", width=25)
    table.add_column("Role", width=18)
    table.add_column("Status", width=10)

    for m in members:
        status = "[green]Active[/green]" if m.get("is_active", True) else "[dim]Inactive[/dim]"
        role = m.get("role", "member")
        role_label = ROLE_LABELS.get(role, role)
        table.add_row(
            m.get("user_name", ""),
            m.get("user_email", ""),
            role_label,
            status,
        )

    console.print(table)


def print_json(data: Any) -> None:
    """Print data as formatted JSON."""
    if hasattr(data, "model_dump"):
        data = data.model_dump(mode="json")
    elif isinstance(data, list) and data and hasattr(data[0], "model_dump"):
        data = [item.model_dump(mode="json") for item in data]
    console.print_json(json.dumps(data, default=str))
