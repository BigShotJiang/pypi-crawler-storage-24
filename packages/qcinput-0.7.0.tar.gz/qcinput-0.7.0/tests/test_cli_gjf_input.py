import sys

from qcinput import __generator_banner__
from qcinput.cli import main
from tests.helpers import write_example_files


def _write_example_gjf(tmp_path, *, title: str = "Title Card Required"):
    gjf = tmp_path / "example.gjf"
    gjf.write_text(
        "\n".join(
            [
                r"%chk=C:\Users\arc7\Desktop\sss.chk",
                "# hf/3-21g geom=connectivity",
                "",
                title,
                "",
                "0 1",
                " C                 -1.03321036    0.35055350    0.00000000",
                " H                 -0.67655594   -0.65825650    0.00000000",
                " H                 -0.67653752    0.85495169   -0.87365150",
                " H                 -2.10321036    0.35056668    0.00000000",
                "",
                " 1 2 1.0 3 1.0 4 1.0",
                " 2",
                " 3",
                " 4",
                "",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    return gjf


def test_gaussian_generation_accepts_gjf_input(monkeypatch, tmp_path, capsys) -> None:
    gjf = _write_example_gjf(tmp_path)
    _, config = write_example_files(tmp_path, kind="sp", engine="gaussian")
    output = tmp_path / "from_gjf.gjf"

    monkeypatch.setattr(
        sys,
        "argv",
        ["qcinput", str(gjf), "--config", str(config), "-o", str(output)],
    )

    exit_code = main()
    captured = capsys.readouterr()
    text = output.read_text(encoding="utf-8")

    assert exit_code == 0
    assert str(output) in captured.out
    assert "%chk=example.chk" in text
    assert __generator_banner__ in text
    assert "C -1.03321036 0.35055350 0.00000000" in text
    assert "H -0.67655594 -0.65825650 0.00000000" in text
    assert "1 2 1.0 3 1.0 4 1.0" not in text


def test_orca_generation_accepts_gjf_input(monkeypatch, tmp_path, capsys) -> None:
    gjf = _write_example_gjf(tmp_path)
    _, config = write_example_files(tmp_path, kind="int", engine="orca")
    output = tmp_path / "from_gjf.inp"

    monkeypatch.setattr(
        sys,
        "argv",
        ["qcinput", str(gjf), "--config", str(config), "-o", str(output)],
    )

    exit_code = main()
    captured = capsys.readouterr()
    text = output.read_text(encoding="utf-8")

    assert exit_code == 0
    assert str(output) in captured.out
    assert "* xyz 0 1" in text
    assert "C -1.03321036 0.35055350 0.00000000" in text


def test_gjf_charge_multiplicity_mismatch_errors(monkeypatch, tmp_path) -> None:
    gjf = _write_example_gjf(tmp_path)
    _, config = write_example_files(tmp_path, kind="sp", engine="gaussian")
    config_text = config.read_text(encoding="utf-8").replace(
        "charge = 0", "charge = 1", 1
    )
    config.write_text(config_text, encoding="utf-8")

    monkeypatch.setattr(
        sys,
        "argv",
        ["qcinput", str(gjf), "--config", str(config)],
    )

    try:
        main()
    except SystemExit as exc:
        message = str(exc)
    else:
        raise AssertionError("Expected SystemExit for GJF/config mismatch.")

    assert "mismatch" in message
    assert "gjf=0/1" in message
    assert "config=1/1" in message


def test_gjf_title_like_integers_is_not_charge_line(
    monkeypatch, tmp_path, capsys
) -> None:
    gjf = _write_example_gjf(tmp_path, title="1 2")
    _, config = write_example_files(tmp_path, kind="int", engine="orca")
    output = tmp_path / "title_int_like.inp"

    monkeypatch.setattr(
        sys,
        "argv",
        ["qcinput", str(gjf), "--config", str(config), "-o", str(output)],
    )

    exit_code = main()
    captured = capsys.readouterr()
    text = output.read_text(encoding="utf-8")

    assert exit_code == 0
    assert str(output) in captured.out
    assert "* xyz 0 1" in text


def test_orca_ts_with_gjf_input_generates_companion_xyz(
    monkeypatch, tmp_path, capsys
) -> None:
    gjf = _write_example_gjf(tmp_path)
    _, config = write_example_files(tmp_path, kind="ts", engine="orca")
    output = tmp_path / "from_gjf_ts.inp"

    monkeypatch.setattr(
        sys,
        "argv",
        ["qcinput", str(gjf), "--config", str(config), "-o", str(output)],
    )

    exit_code = main()
    captured = capsys.readouterr()
    text = output.read_text(encoding="utf-8")

    assert exit_code == 0
    assert str(output) in captured.out
    assert "* xyzfile 0 1 from_gjf_ts_Compound_1.xyz *" in text
