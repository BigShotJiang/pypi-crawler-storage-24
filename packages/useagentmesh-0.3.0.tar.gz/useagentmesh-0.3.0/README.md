# AgentMesh SDK

**The Trust Layer for AI Agents** — Scan for governance gaps offline. Enforce policies in production via the AgentMesh platform.

[![PyPI](https://img.shields.io/pypi/v/agentmesh.svg)](https://pypi.org/project/agentmesh/)
[![Python](https://img.shields.io/pypi/pyversions/agentmesh.svg)](https://pypi.org/project/agentmesh/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

---

## Quick Start

### 1. Install

```bash
pip install useagentmesh
```

With framework-specific extras:

```bash
pip install useagentmesh[crewai]      # CrewAI support
pip install useagentmesh[langgraph]   # LangGraph support
pip install useagentmesh[autogen]     # AutoGen support
pip install useagentmesh[all]         # All frameworks
```

### 2. Scan Your Project (free, offline, no account needed)

```bash
agentmesh scan .
# → Governance Score: 35/100 | 8 findings | Agent BOM: 3 agents, 12 tools
# → Run `agentmesh auth login` to enable runtime governance
```

### 3. Connect to Platform (optional, enables runtime governance)

```bash
agentmesh init
```

This will:
- Validate your API key
- Generate `.agentmesh.yaml` config
- Create a framework-specific middleware file
- Enable runtime policy enforcement

### 4. Integrate Runtime Middleware

#### CrewAI

```python
from agentmesh import with_compliance
from my_crew import MyCrew

crew = with_compliance(MyCrew())
result = crew.kickoff()
```

#### LangGraph

```python
from agentmesh import with_langgraph_compliance

graph = with_langgraph_compliance(my_graph.compile())
result = graph.invoke(input)
```

#### AutoGen

```python
from agentmesh import with_autogen_compliance

chat = with_autogen_compliance(my_group_chat)
```

#### Direct Client

```python
from agentmesh import AgentMeshClient

client = AgentMeshClient.from_env()
result = client.verify_agent_identity_sync("my-agent", "researcher")
```

---

## CLI Commands

| Command | Description | Requires Account |
|---|---|:---:|
| `agentmesh scan .` | Scan project for governance gaps | No |
| `agentmesh init` | Initialize runtime SDK in your project | Yes |
| `agentmesh status` | Check connection and quota status | Yes |
| `agentmesh verify` | Verify audit hash chain integrity | Yes |
| `agentmesh serve` | Start a local MCP compliance server | Yes |

---

## Configuration

`.agentmesh.yaml`:

```yaml
version: "1.0"
tenant_id: your_tenant_id
api_key_env: AGENTMESH_API_KEY
endpoint: https://api.useagentmesh.com
framework: crewai

tools:
  audit_log_action: true
  verify_agent_identity: true
  evaluate_policy: true

guardrails:
  prompt_injection_detection: true
  dlp_scanning: false

trust:
  enabled: true
  decay_half_life_hours: 168
  circuit_breaker_threshold: 3
```

---

## Capabilities

### Scan CLI (free, offline)

| Capability | Status | Details |
|---|---|---|
| Governance Score | ✅ Built-in | 25 rules, 4 categories, deterministic evaluation |
| Agent BOM | ✅ Built-in | AST-based discovery, 6 frameworks |
| EU AI Act Gap Detection | ✅ Built-in | Art. 9, 11, 12, 14 mapping with fix snippets |
| SARIF 2.1.0 | ✅ Built-in | GitHub Code Scanning compatible |
| SVG Badge | ✅ Built-in | Embeddable governance badge |

### Runtime Platform (requires account)

| Capability | Status | Details |
|---|---|---|
| Policy Enforcement | ✅ Production | Real-time evaluation on tool calls |
| DLP/PII Detection | ✅ Production | Presidio-based, 8+ entity types, anonymization |
| Circuit Breaker | ✅ Production | State machine + EigenTrust scoring |
| Audit Trail | ✅ Production | SHA-256/BLAKE3 hash chain + digital signatures |
| Trust Score | ✅ Production | 0-100 dynamic score per agent |
| OTEL Export | 🔜 Next Sprint | OpenTelemetry semantic conventions |

---

## Environment Variables

| Variable | Description | Required |
|---|---|---:|
| `AGENTMESH_API_KEY` | Your API key (for runtime features) | For platform |
| `AGENTMESH_ENDPOINT` | Custom backend URL | No |
| `AGENTMESH_TENANT_ID` | Override tenant ID | No |

---

## Development

```bash
git clone https://github.com/agentmesh/agentmesh-python.git
cd agentmesh-python
pip install -e ".[dev]"
pytest
```

---

## License

MIT
