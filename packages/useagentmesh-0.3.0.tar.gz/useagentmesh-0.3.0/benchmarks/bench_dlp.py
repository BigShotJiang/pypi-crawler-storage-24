import json
import time
import sys
from pathlib import Path
import os

repo_root = Path(__file__).parent.parent.parent.resolve()
sys.path.append(str(repo_root))

try:
    from rich.console import Console
    from rich.table import Table
except ImportError:
    Console = None

from app.services.presidio_service import get_presidio_wrapper

ITERATIONS = 1000
WARMUP = 10

def generate_payloads():
    clean = "This is a clean payload with no personal identifiable information. It's safe to process."
    one_pii = "Contact John Doe at his email address."
    ten_pii = "John Smith (jsmith@email.com) called from 555-0123. His colleague Jane Doe (jane.doe@company.com, 555-0199) also attended. Credit cards used: 4111-1111-1111-1111 and 5555-4444-3333-2222. Address: 123 Main St, New York, NY."
    
    # 10KB payload (clean text repeated)
    large_payload = (clean + " ") * (10000 // len(clean))
    # inject 5 PII into the large payload
    large_payload = large_payload[:5000] + " " + ten_pii + " " + large_payload[5000:]
    
    return {
        "Clean Text (baseline)": clean,
        "1 PII": one_pii,
        "10 PIIs": ten_pii,
        "Large Payload (~10KB)": large_payload
    }

def run_dlp_benchmark():
    print("Running DLP Benchmarks (Presidio Wrapper) ...")
    
    wrapper = get_presidio_wrapper()
    if not wrapper.is_available:
        print("Error: Presidio is not available (install presidio-analyzer, presidio-anonymizer, spacy-models).")
        return None
        
    payloads = generate_payloads()
    results = {}
    
    for name, text in payloads.items():
        # Warmup
        for _ in range(WARMUP):
            wrapper.analyze(text)
            
        times_ms = []
        for _ in range(ITERATIONS):
            t0 = time.perf_counter_ns()
            wrapper.analyze(text)
            t1 = time.perf_counter_ns()
            times_ms.append((t1 - t0) / 1e6)
            
        mean = sum(times_ms) / len(times_ms)
        results[name] = {
            "mean_ms": mean,
            "min_ms": min(times_ms),
            "max_ms": max(times_ms)
        }
        
    out_dir = Path(__file__).parent / "results"
    out_dir.mkdir(exist_ok=True, parents=True)
    with open(out_dir / "dlp.json", "w") as f:
        json.dump(results, f, indent=2)
        
    if Console:
        console = Console()
        table = Table(title="DLP Extraction Latency (Presidio Wrapper)")
        table.add_column("Payload Type", style="cyan")
        table.add_column("Mean Latency (ms)", justify="right")
        table.add_column("Min (ms)", justify="right")
        table.add_column("Max (ms)", justify="right")
        
        for name, stat in results.items():
            table.add_row(
                name,
                f"{stat['mean_ms']:.2f}",
                f"{stat['min_ms']:.2f}",
                f"{stat['max_ms']:.2f}"
            )
        console.print(table)
        
    return results

if __name__ == "__main__":
    run_dlp_benchmark()
