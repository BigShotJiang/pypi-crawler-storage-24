"""Load and validate .agentmesh.yaml configuration using Pydantic."""

from __future__ import annotations

import os
from pathlib import Path

import yaml
from pydantic import BaseModel, Field

from agentmesh.exceptions import ConfigError


# ------------------------------------------------------------------
# Legacy config models (kept for backward compatibility)
# ------------------------------------------------------------------

class ToolsConfig(BaseModel):
    audit_log_action: bool = True
    verify_agent_identity: bool = True
    evaluate_policy: bool = True


class GuardrailsConfig(BaseModel):
    prompt_injection_detection: bool = True
    dlp_scanning: bool = False


class TrustConfig(BaseModel):
    enabled: bool = True
    decay_half_life_hours: int = 168
    circuit_breaker_threshold: int = 3


class BFTConfig(BaseModel):
    enabled: bool = False
    quorum_size: int = 4


# ------------------------------------------------------------------
# New config models for rich YAML (v1.0 rewrite)
# ------------------------------------------------------------------

class AgentEntry(BaseModel):
    source: str = ""
    description: str = ""


class ToolEntry(BaseModel):
    source: str = ""
    type: str = "read"  # read | write | execute | network | payment


class DLPConfig(BaseModel):
    mode: str = "audit"  # audit | enforce | off


class CircuitBreakerAgentConfig(BaseModel):
    failure_threshold: int = 10
    time_window_seconds: int = 300
    recovery_timeout_seconds: int = 60


class CircuitBreakerConfig(BaseModel):
    agent_level: CircuitBreakerAgentConfig = Field(default_factory=CircuitBreakerAgentConfig)


class GovernanceConfig(BaseModel):
    on_backend_unreachable: str = "allow"  # "allow" | "block"


class AuditNewConfig(BaseModel):
    enabled: bool = True


# ------------------------------------------------------------------
# HITL (Human-in-the-Loop) Checkpoint config  [requires Pro]
# ------------------------------------------------------------------

class HITLTriggersConfig(BaseModel):
    tool_types: list[str] = Field(default_factory=list)
    tools: list[str] = Field(default_factory=list)
    trust_score_below: float | None = None
    spend_above_usd: float | None = None
    records_above: int | None = None
    first_time_tool: bool = False
    first_time_action: bool = False


class HITLNotificationConfig(BaseModel):
    webhook_url: str | None = None
    email: str | None = None


class HITLConfig(BaseModel):
    mode: str = "off"  # "audit" | "enforce" | "off"
    triggers: HITLTriggersConfig = Field(default_factory=HITLTriggersConfig)
    notification: HITLNotificationConfig = Field(default_factory=HITLNotificationConfig)
    approval_timeout_minutes: int = 30
    timeout_action: str = "reject"  # "reject" | "allow"


# ------------------------------------------------------------------
# Intent Fingerprinting config  [requires Pro]
# ------------------------------------------------------------------

class IntentRequiredForConfig(BaseModel):
    tool_types: list[str] = Field(default_factory=lambda: ["payment", "write", "execute"])
    tools: list[str] = Field(default_factory=list)


class IntentVerificationConfig(BaseModel):
    mode: str = "off"  # "audit" | "enforce" | "off"
    required_for: IntentRequiredForConfig = Field(default_factory=IntentRequiredForConfig)
    anti_replay: bool = True
    intent_ttl_seconds: int = 300


# ------------------------------------------------------------------
# Programmable Hooks config  [requires Pro]
# ------------------------------------------------------------------

class HookEntryConfig(BaseModel):
    name: str
    condition: str | None = None
    script: str | None = None
    timeout_ms: int = 5000
    action_on_fail: str = "allow"  # "allow" | "block"
    priority: int = 0


class HooksConfig(BaseModel):
    pre_action: list[HookEntryConfig] = Field(default_factory=list)
    post_action: list[HookEntryConfig] = Field(default_factory=list)
    on_error: list[HookEntryConfig] = Field(default_factory=list)
    on_session_end: list[HookEntryConfig] = Field(default_factory=list)


# ------------------------------------------------------------------
# Main config
# ------------------------------------------------------------------

class AgentMeshConfig(BaseModel):
    version: str = "1.0"
    tenant_id: str
    api_key_env: str = "AGENTMESH_API_KEY"
    api_key: str | None = None
    endpoint: str = "https://api.useagentmesh.com"
    framework: str = "generic"
    # Legacy feature flags
    tools: ToolsConfig = Field(default_factory=ToolsConfig)
    guardrails: GuardrailsConfig = Field(default_factory=GuardrailsConfig)
    trust: TrustConfig = Field(default_factory=TrustConfig)
    bft: BFTConfig = Field(default_factory=BFTConfig)
    # New rich config fields (all optional with defaults for backward compat)
    agents: dict[str, AgentEntry] = Field(default_factory=dict)
    detected_tools: dict[str, ToolEntry] = Field(default_factory=dict)
    dlp: DLPConfig = Field(default_factory=DLPConfig)
    circuit_breaker: CircuitBreakerConfig = Field(default_factory=CircuitBreakerConfig)
    audit: AuditNewConfig = Field(default_factory=AuditNewConfig)
    governance: GovernanceConfig = Field(default_factory=GovernanceConfig)
    # Sprint 2 features (Pro+)
    hitl: HITLConfig = Field(default_factory=HITLConfig)
    intent_verification: IntentVerificationConfig = Field(default_factory=IntentVerificationConfig)
    # Sprint 3 features (Pro+)
    hooks: HooksConfig = Field(default_factory=HooksConfig)

    @classmethod
    def load(cls, path: str = ".agentmesh.yaml") -> AgentMeshConfig:
        """Load config from a YAML file."""
        config_path = Path(path)
        if not config_path.exists():
            raise ConfigError(
                f"Config file not found: {config_path.resolve()}\n"
                "Run 'agentmesh init' to create one."
            )
        try:
            with open(config_path) as f:
                data = yaml.safe_load(f)
        except yaml.YAMLError as exc:
            raise ConfigError(f"Invalid YAML in {path}: {exc}") from exc

        if not isinstance(data, dict):
            raise ConfigError(f"Expected a YAML mapping in {path}, got {type(data).__name__}")

        return cls.model_validate(data)

    def resolve_api_key(self) -> str:
        """Resolve the API key: env var first, then YAML-stored key."""
        # Priority 1: environment variable (for CI/CD overrides)
        key = os.environ.get(self.api_key_env)
        if key:
            return key
        # Priority 2: key stored in .agentmesh.yaml
        if self.api_key:
            return self.api_key
        raise ConfigError(
            f"API key not found. Set the environment variable {self.api_key_env} "
            f"or re-run 'agentmesh init' to store it in your config.\n"
            f"Set env var: export {self.api_key_env}=am_live_your_key_here"
        )

    def to_yaml(self, path: str = ".agentmesh.yaml") -> None:
        """Serialize config to a YAML file."""
        data = self.model_dump()
        with open(path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)
