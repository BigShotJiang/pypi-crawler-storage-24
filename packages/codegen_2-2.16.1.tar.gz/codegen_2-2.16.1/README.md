# codegen

`codegen` is a small code generation library for building Python and partial TypeScript output from a lightweight AST.

- PyPI/package name: `codegen-2`
- Import path: `codegen`
- Main public module: `codegen.models`
- Python requirement: `>=3.11`

Use this import pattern:

```python
from codegen.models import Program, DeferredVar, ImportHelper, expr, stmt
```

The top-level `codegen/__init__.py` is empty, so `from codegen import Program` does not work.

Full reference: [docs/codegen-reference.md](docs/codegen-reference.md)
