# Changelog

All notable changes to ICDEV will be documented in this file.

## [1.0.4] - 2026-03-12

### Added
- **CodeLens/Pro Container Validation** — 7-lens container analysis engine (Dockerfile lint, K8s manifest, Helm chart, security/STIG compliance, database compatibility, air-gap readiness, file hygiene) with configurable profiles
- **Review Pro Engine** — Advanced code review lenses: anti-sycophancy detection, ghost coverage analysis, compliance QE validation, test decay detection, test pattern analysis
- **CLI Generator** — Auto-generate CLI and MCP server wrappers from existing Python tools via AST introspection
- **Enterprise MCP Servers** — DOORS NG, eMASS, SysML v2, and Xacta MCP server integrations
- **DocHub Dashboard** — Living documentation hub with document generation, health scoring, diff tracking, and multi-tenant module management
- **Resilience Dashboard** — System resilience monitoring with health metrics and recovery tracking
- **CI/CD SDLC Pipeline** — Full software development lifecycle workflow orchestration (`icdev_sdlc.py`)
- **Testing Enhancements** — Migration validator, performance regression detector, traceability bridge for test-to-requirement mapping
- **Environment Configs** — Air-gap, dev, staging, and production environment YAML profiles
- **DB Migrations** — Schema migrations for memory enhancements, dev profiles, innovation engine, AI security, agent evolution, cloud phases

### Changed
- Dashboard expanded with 10+ new route handlers and templates
- Storage layer improved with better PostgreSQL fallback handling
- GraphRAG source registry expanded with Review Pro tables
- MCP tool registry updated with new wrapper registrations

### Fixed
- Storage config PostgreSQL connection handling edge cases
- Dashboard template inheritance and navigation consistency

## [0.0.3] - 2026-03-10

### Added
- **Marketplace SaaS** — Standalone marketplace backend on AWS Lambda with DynamoDB, contribution pipeline (8-check scanning, admin review, 7-day quarantine, RSA-signed artifacts)
- **Forge Studio** — Visual app builder with drag-and-drop component palette, tier classification (local eject vs parent ICDEV handoff), blueprint export engine
- **Audit Engine** — Multi-regime compliance report card (NIST 800-53, 800-171, CMMC, FedRAMP, CISA SbD), AI advisor recommendations, regime comparison, BYOS target support
- **ICDEV Pulse** — Technical content dashboard with research pipeline, author analytics, and post management
- **CI Pipeline** — 9-gate GitHub Actions workflow (py_compile, ruff, bandit, secret-scan, dep-audit, tests, CUI marking, GOTCHA architecture, import-check)
- **Marketplace Contribution Pipeline** — GitHub Actions for module scanning and publishing with SLSA provenance
- **Blueprint System** — Deterministic 12-signal tier classifier, ForgeBlueprint manifests, parent ICDEV HTTP client for Tier 2 handoff
- **Module Encryption** — AES-256-GCM at-rest encryption for marketplace modules with transparent import hook
- **Knowledge Graph RAG** — Per-query scoring profiles, self-directed context compression, parallel multi-strategy retrieval
- **Harness Engineering** — AI agent maturity assessment, loop detection, exit criteria, trace analysis
- **Secure by Design** — CISA SbD pledge assessment, Cloudyrion 8-pillar alignment, exception registry
- **Developer Scorecard** — 6-dimension project health scoring (code quality, security, compliance, test coverage, velocity, SbD posture)
- **ATO Simulator** — Monte Carlo timeline prediction with PERT sampling
- **Firmware SBOM** — CycloneDX 1.5 + CSAF 2.0 VEX generation for embedded targets
- **Storage Abstraction** — PostgreSQL primary backend with SQLite fallback, transparent placeholder translation
- **E2E Test Framework** — 27 Playwright E2E specs with standardized screenshot output to `playwright/screenshots/`

### Changed
- Rebranded from "Intelligent Coding Development" to **Intelligent Certified Development**
- Dashboard port standardized to 5050 across all E2E specs
- URLs updated to `icdev-ai` GitHub organization
- Storage layer migrated from direct sqlite3 to `tools.db.storage.get_connection()`
- License changed from AGPL-3.0 to Apache-2.0

### Fixed
- Lambda deployment reliability (version-pinned deps, unique S3 keys, Windows-safe ZIP building)
- E2E screenshots now save to `playwright/screenshots/` instead of project root
- Port 5000 references corrected to 5050 in 9 E2E specs

## [0.0.2] - 2026-03-04

### Added
- CloudForge — Landing zones, migration assessments, hybrid topology, FinOps, SIEM, runbooks, metastore
- DataBridge — Universal data connector with 10+ connector types, sync engine, scale engine
- Connector Forge — Dynamic connector generation, validation, sandbox, marketplace
- GovProposal (GovCon) — SAM.gov scanning, proposal lifecycle, CPMP, compliance matrix
- WriteGuard — AI writing assistant with 5-layer style guides, grammar, tone, readability
- Innovation features (F1-F12): cATO live evidence, template exchange, VSM dashboard, AI narratives, thread heatmap, PR intelligence, threat modeler, developer scorecard, golden path, forge hub, ATO simulator, firmware SBOM
- DevSecOps & Zero Trust Architecture — Pipeline security, policy-as-code, 7-pillar ZTA maturity
- OWASP Agentic Security — Behavioral drift detection, tool chain validation, trust scoring
- Observability & XAI — Distributed tracing, W3C PROV provenance, AgentSHAP attribution
- SparkPilot embedded — NL-to-firmware, browser simulator, gamified missions, fleet management, edge AI

### Changed
- Multi-agent architecture expanded to 12 agents
- MCP servers expanded to 12 stdio servers
- Compliance frameworks expanded to 8 (added CISA SbD, IEEE 1012, DoDI 5000.87)

## [0.0.1] - 2026-02-28

### Added
- Initial public release
- GOTCHA 6-layer framework
- ATLAS/M-ATLAS build workflow
- 5 compliance frameworks (NIST 800-53, FedRAMP, 800-171, CMMC, DoD CSSP)
- Multi-agent orchestration (7 agents)
- Memory system with hybrid search
- RICOAS requirements intake
- MBSE integration (SysML, DOORS NG)
- Code intelligence (AST metrics, smell detection)
