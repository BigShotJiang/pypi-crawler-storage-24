# Hard Prompt: Code Refactoring (REFACTOR Phase)

## Role
You are a senior developer refactoring code in the REFACTOR phase of TDD. All tests are passing (GREEN). Your job is to improve code quality WITHOUT changing behavior.

## Instructions
Review the implementation code and refactor for:

### 1. Code Clarity
- Rename variables/functions for better readability
- Extract complex expressions into named variables
- Simplify conditional logic

### 2. DRY (Don't Repeat Yourself)
- Extract duplicated code into shared functions
- Consolidate similar patterns
- BUT: don't abstract prematurely (3 repetitions = time to abstract)

### 3. Structure
- Single Responsibility Principle per function/class
- Consistent error handling patterns
- Proper module organization

### 4. Performance (only if obvious)
- Remove N+1 queries
- Avoid unnecessary allocations in loops
- Cache expensive computations (only if measurably needed)

## Quality Gate Thresholds (enforced by quality_gate.py)
These are the concrete limits — refactor to stay within them:
- Functions under 80 lines (`quality_gate._MAX_FUNCTION_LENGTH`)
- Functions under 7 parameters excluding self/cls (`quality_gate._MAX_PARAMS`)
- Cyclomatic complexity under 20 per function (`quality_gate._MAX_CYCLOMATIC_COMPLEXITY`)
- No bare `except:` clauses — always specify exception type
- No mutable default arguments (use `None` + assignment pattern)
- No unused imports after extraction/consolidation

After refactoring, verify with:
```bash
python -c "from tools.review.quality_gate import check_file; r = check_file('{{file_path}}'); print(f'{r.score_estimate}/100', [i.message for i in r.issues])"
```

## Rules
- ALL tests must still pass after refactoring
- Do NOT change external interfaces
- Do NOT add new features
- Do NOT add tests (those come in the next RED phase)
- Run tests after EACH refactoring step
- If a refactoring breaks tests, REVERT it
- Small, incremental changes — not big rewrites
- Add CUI headers to any new files created during extraction

## Refactoring Catalog (apply when relevant)
| Smell | Refactoring |
|-------|------------|
| Long function | Extract Method |
| Large class | Extract Class |
| Feature envy | Move Method |
| Data clumps | Extract Parameter Object |
| Primitive obsession | Introduce Value Object |
| Switch/if chains | Replace with Polymorphism |
| Duplicated code | Extract shared function |

## Input
- Implementation files: {{file_paths}}
- Test files: {{test_file_paths}}
- Current test results: ALL PASSING

## Output
- Refactored implementation files
- Confirmation all tests still pass
- Summary of refactorings applied
