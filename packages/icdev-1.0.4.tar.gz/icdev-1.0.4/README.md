<p align="center">
  <img src="https://img.shields.io/badge/license-Apache--2.0_+_Commercial-blue" alt="License">
  <img src="https://img.shields.io/badge/python-3.9%2B-brightgreen" alt="Python 3.9+">
  <img src="https://img.shields.io/badge/boards-5-orange" alt="Boards">
  <img src="https://img.shields.io/badge/missions-7-blueviolet" alt="Missions">
  <img src="https://img.shields.io/badge/SDK-~8KB-red" alt="SDK Size">
  <img src="https://img.shields.io/badge/FreeRTOS-v10.5-green" alt="FreeRTOS">
</p>

# SparkPilot — AI Co-Pilot for Embedded Systems

**Talk to your hardware.**

SparkPilot makes embedded RTOS development accessible to anyone — from a beginner building their first blinking LED to a DoD engineer deploying AI-enabled firmware with full compliance traceability. Type a command in plain English, get production FreeRTOS C code, simulate it in the browser, and deploy to real hardware when you're ready.

No toolchain setup. No datasheet diving. No 200-page FreeRTOS manual. Just describe what you want.

---

## What SparkPilot Does

```
"Blink an LED every 2 seconds"
        │
        ▼
┌─ PARSE ────────────────────────────────────────────────┐
│  Natural language → template matching + param extraction │
│  → Detects: "blink", "LED", "2 seconds" → blink_led     │
│  → Params: pin=2, delay_ms=2000                          │
└───────────────────────────┬────────────────────────────┘
                            ▼
┌─ GENERATE ─────────────────────────────────────────────┐
│  FreeRTOS C code with:                                   │
│  → #include "FreeRTOS.h", "task.h", "hal_gpio.h"        │
│  → vBlinkTask with hal_gpio_init + vTaskDelay            │
│  → app_main with xTaskCreate + vTaskStartScheduler       │
└───────────────────────────┬────────────────────────────┘
                            ▼
┌─ SIMULATE ─────────────────────────────────────────────┐
│  Browser-based FreeRTOS POSIX port                       │
│  → Virtual LEDs, sensors, buttons, OLED display          │
│  → No hardware required — runs in WASM                   │
└───────────────────────────┬────────────────────────────┘
                            ▼
┌─ DEPLOY ───────────────────────────────────────────────┐
│  Cross-compile for target board                          │
│  → CMakeLists.txt + FreeRTOSConfig.h auto-generated      │
│  → Flash via USB or OTA via MQTT                         │
│  → 72-hour stability window with auto-rollback           │
└────────────────────────────────────────────────────────┘
```

---

## Screenshots

**Home Dashboard** — 10-card overview (devices, firmware builds, missions, ML models, sim sessions, crash dumps, OTA pending, NL commands) with inline natural language command input:

![SparkPilot Dashboard](playwright/screenshots/sparkpilot-home-desktop.png)

**Natural Language to Firmware** — Type "Blink an LED every 2 seconds" and get production FreeRTOS C code with `hal_gpio`, `vTaskDelay`, and `xTaskCreate`:

![NL-to-Firmware](playwright/screenshots/sparkpilot-nl-command.png)

**Gamified Missions** — 7 progressive missions from beginner to expert with XP rewards, difficulty badges, and step-by-step objectives:

![Learning Missions](playwright/screenshots/sparkpilot-missions.png)

**FreeRTOS Simulator** — Browser-based simulator with 7 virtual peripherals and session management — no hardware required:

![FreeRTOS Simulator](playwright/screenshots/sparkpilot-simulator.png)

**Device Fleet** — Register devices by name and board type, track online/offline status, firmware version, and heartbeat timestamps:

![Device Fleet](playwright/screenshots/sparkpilot-fleet.png)

**Self-Healing Firmware** — 4-step autonomous pipeline: device crashes → AI analyzes dump → patch generated → auto-deployed via OTA:

![Self-Healing Firmware](playwright/screenshots/sparkpilot-selfheal.png)

---

## Four-Tier Architecture

| Tier | Environment | Purpose |
|------|-------------|---------|
| **Tier 0** | Browser Simulator (WASM/JS) | FreeRTOS POSIX port, virtual peripherals, no install needed |
| **Tier 1** | FreeRTOS MCU (Cortex-M, ESP32, RISC-V) | TinyML inference, MQTT telemetry, OTA updates, SparkPilot Device SDK (~8KB) |
| **Tier 2** | Edge Gateway (RPi, Jetson) | Local LLM (llama.cpp), multi-agent coordination, edge inference |
| **Tier 3** | Cloud (Bedrock, SageMaker) | Full LLM orchestration, compliance monitoring, self-healing |

---

## Supported Boards

| Board | Arch | Flash | RAM | Toolchain |
|-------|------|-------|-----|-----------|
| ESP32-S3 | Xtensa LX7 | 8MB | 512KB | xtensa-esp32s3-elf |
| STM32F407 | Cortex-M4F | 1MB | 192KB | arm-none-eabi |
| nRF52840 | Cortex-M4F | 1MB | 256KB | arm-none-eabi |
| RPi Pico | Cortex-M0+ | 2MB | 264KB | arm-none-eabi |
| Simulator | POSIX/Host | — | — | gcc |

---

## Natural Language Commands

SparkPilot parses English descriptions and generates FreeRTOS C code from 4 templates:

| Template | Trigger Words | What It Generates |
|----------|---------------|-------------------|
| **blink_led** | blink, LED, flash, toggle | GPIO init + vTaskDelay loop with configurable pin and delay |
| **read_sensor** | read, sensor, temperature, humidity, accel | I2C initialization + periodic sensor polling task |
| **mqtt_publish** | MQTT, publish, send, message, telemetry | MQTT client connect + periodic telemetry publish |
| **wifi_connect** | WiFi, connect, network, internet | WiFi station mode + connection with retry |

Numeric extraction: "every 2 seconds" → `delay_ms=2000`, "at 10 Hz" → `interval_ms=100`

---

## Gamified Missions

7 progressive missions teach embedded development from zero to fleet management:

| # | Mission | Difficulty | XP | Time | Hardware Required |
|---|---------|------------|-----|------|-------------------|
| 1 | **Hello, LED!** — Blink an LED on and off | Beginner | 100 | ~10 min | No |
| 2 | **Sensor Explorer** — Read a temperature sensor via I2C | Beginner | 150 | ~15 min | No |
| 3 | **WiFi Wrangler** — Connect your device to WiFi | Intermediate | 200 | ~15 min | No |
| 4 | **MQTT Messenger** — Send your first message to the cloud | Intermediate | 250 | ~20 min | No |
| 5 | **AI Detective** — Add anomaly detection AI to your sensor | Advanced | 400 | ~30 min | No |
| 6 | **Silicon Upgrade** — Deploy from simulator to real hardware | Advanced | 500 | ~45 min | Yes |
| 7 | **Fleet Commander** — Manage multiple devices at once | Expert | 600 | ~60 min | No |

Each mission includes starter code with TODO comments, progressive hints, solution code, and automatic validation. Total: **2,200 XP** across all missions.

---

## Browser Simulator

Start a FreeRTOS simulator session with 7 virtual peripherals — no hardware, no toolchain, no install:

| Peripheral | Type | Interface | WASM Module |
|------------|------|-----------|-------------|
| Red LED | LED | GPIO pin 2 | VirtualLED |
| Green LED | LED | GPIO pin 4 | VirtualLED |
| Push Button | Button | GPIO pin 0 (active low, pull-up) | VirtualButton |
| Temperature Sensor | I2C | Address 0x48, range -40°C to 125°C | VirtualTempSensor |
| Accelerometer | I2C | Address 0x1D, ±4g range | VirtualAccelerometer |
| OLED Display 128x64 | SPI | CS=5, DC=16 | VirtualOLED |
| Potentiometer | ADC | Channel 0, 0–4095 | VirtualPotentiometer |

Session states: running → paused → stopped. Event logging captures task switches, LED toggles, sensor reads, MQTT publishes, and crashes.

---

## Device SDK

Thin C library (~8KB flash, ~2KB RAM) with 3 FreeRTOS tasks:

| Task | Purpose |
|------|---------|
| **MQTT Client** | Broker connection, subscribe, publish, reconnect |
| **Command Handler** | Dequeue and execute agent commands (OTA, config, reboot, diagnostics, model update, task control) |
| **Telemetry Reporter** | Periodic health + sensor data reports |

### API

```c
// Lifecycle
sp_error_t sparkpilot_init(void);
sp_error_t sparkpilot_init_with_config(const sp_config_t *config);
sp_error_t sparkpilot_start(void);
void       sparkpilot_stop(void);
const char* sparkpilot_version(void);

// MQTT
sp_error_t sparkpilot_mqtt_connect(const char *broker, uint16_t port);
sp_error_t sparkpilot_mqtt_publish(const char *topic, const void *payload,
                                    uint16_t payload_len, uint8_t qos);
uint8_t    sparkpilot_mqtt_is_connected(void);

// Commands
sp_error_t sparkpilot_queue_command(const sp_command_t *cmd);

// Telemetry
void sparkpilot_get_telemetry(sp_telemetry_t *report);
void sparkpilot_send_telemetry_now(void);
```

**6 command types:** `SP_CMD_OTA_UPDATE`, `SP_CMD_CONFIG_SET`, `SP_CMD_REBOOT`, `SP_CMD_DIAG_DUMP`, `SP_CMD_MODEL_UPDATE`, `SP_CMD_TASK_CONTROL`

**Telemetry fields:** heap_free, stack_watermark, cpu_usage, uptime, temperature, RSSI, inference_count, inference_latency

---

## Fleet Management

### Device Registry

- Register devices by name and board type (ESP32-S3, STM32F407, nRF52840, RPi Pico, Simulator)
- Track online/offline status via heartbeat with firmware version, heap, CPU, and stack watermark
- Fleet health dashboard: total, online, offline, error counts

### OTA Updates

- **Single device deploy** — push firmware to one device over MQTT
- **Canary deployment** — roll out to a configurable percentage (default 10%) of a device group first
- **Stability window** — 72 hours via MCUboot secondary slot before committing
- **Auto-rollback** — failed OTA or crash within stability window triggers automatic rollback
- **Update types** — firmware, ML model, or config

Deployment phases: `canary → staged_rollout → full_rollout` (or `rollback` on failure)

---

## Edge AI / TinyML

- Register TFLite Micro models with metadata (task type, quantization, input/output shapes)
- Deploy models to devices via OTA
- Track inference telemetry: latency, accuracy, throughput per device
- Model templates: anomaly detection, keyword spotting, image classification, predictive maintenance

---

## Self-Healing Firmware

When a device crashes (HardFault, stack overflow, watchdog timeout):

1. **Crash dump captured** — registers, stack trace, fault type logged
2. **AI analyzes dump** — pattern matching against known crash signatures
3. **Patch generated** — fix produced based on root cause analysis
4. **Auto-deployed via OTA** — confidence-based gating:
   - ≥ 0.7 → auto-fix deployed
   - 0.3–0.7 → fix suggested, human reviews
   - < 0.3 → escalated to engineer

---

## Quick Start

### Option 1: Install from PyPI (recommended)

```bash
# Install ICDEV
pip install icdev

# Add LLM providers (pick what you need)
pip install icdev[llm]          # OpenAI, Anthropic, Bedrock, Gemini, Ollama
pip install icdev[full]         # Everything: all LLM providers + search + testing + security

# Initialize databases (234 tables)
icdev-init-db

# Start the dashboard
icdev-dashboard
# → http://localhost:5000

# Start the unified MCP server (241 tools for Claude Code / AI IDEs)
icdev-mcp
```

**Available extras:**

| Extra | What it adds |
|-------|-------------|
| `icdev[llm]` | OpenAI, Anthropic, Bedrock, Google GenAI, Ollama |
| `icdev[llm-azure]` | Azure OpenAI |
| `icdev[llm-vertex]` | Google Vertex AI |
| `icdev[llm-oci]` | Oracle Cloud GenAI |
| `icdev[llm-ibm]` | IBM watsonx.ai |
| `icdev[llm-all]` | All LLM providers |
| `icdev[search]` | Semantic + keyword search (numpy, rank_bm25) |
| `icdev[testing]` | pytest, behave, ruff, pydantic |
| `icdev[security]` | bandit, pip-audit, detect-secrets, cyclonedx-bom |
| `icdev[full]` | Everything above |

### Option 2: Install from source

```bash
# Clone and install
git clone https://github.com/icdev-ai/icdev.git
cd icdev
pip install -r requirements.txt

# Initialize databases (234 tables)
python tools/db/init_icdev_db.py

# Start the dashboard
python tools/dashboard/app.py
# → http://localhost:5000
```

### Option 3: Modular installation

```bash
# Interactive wizard
python tools/installer/installer.py --interactive

# Profile-based (pick your mission)
python tools/installer/installer.py --profile dod_team --compliance fedramp_high,cmmc
python tools/installer/installer.py --profile healthcare --compliance hipaa,hitrust
python tools/installer/installer.py --profile isv_startup --platform docker
```

### Generate your first application:

```bash
# Assess fitness for agentic architecture
python tools/builder/agentic_fitness.py --spec "Mission planning tool for IL5 with CUI markings" --json

# Generate blueprint from scorecard
python tools/builder/app_blueprint.py --fitness-scorecard scorecard.json \
  --user-decisions '{}' --app-name "mission-planner" --json

# Generate the full application (12 steps, 300+ files)
python tools/builder/child_app_generator.py --blueprint blueprint.json \
  --project-path ./output --name "mission-planner" --json
```

### Or use Claude Code:

```bash
/icdev-intake        # Start conversational requirements intake
/icdev-simulate      # Run Digital Program Twin simulation
/icdev-agentic       # Generate the full application
/icdev-build         # TDD build (RED → GREEN → REFACTOR)
/icdev-comply        # Generate ATO artifacts
/icdev-transparency  # AI transparency & accountability audit
/icdev-accountability # AI accountability — oversight, CAIO, appeals, incidents
/audit               # 33-check production readiness audit
```

---

## 42 Compliance Frameworks

| Category | Frameworks |
|----------|------------|
| **Federal** | NIST 800-53 Rev 5, NIST 800-171, FedRAMP (Moderate/High/20x), CMMC Level 2/3, FIPS 199/200, CNSSI 1253 |
| **DoD** | DoDI 5000.87 DES, MOSA (10 U.S.C. §4401), CSSP (DI 8530.01), cATO Monitoring |
| **Healthcare** | HIPAA Security Rule, HITRUST CSF v11 |
| **Financial** | PCI DSS v4.0, SOC 2 Type II |
| **Law Enforcement** | CJIS Security Policy |
| **International** | ISO/IEC 27001:2022, ISO/IEC 42001:2023, EU AI Act (Annex III) |
| **AI/ML Security** | NIST AI RMF 1.0, MITRE ATLAS, OWASP LLM Top 10, OWASP Agentic AI, OWASP ASI, SAFE-AI |
| **AI Transparency** | OMB M-25-21 (High-Impact AI), OMB M-26-04 (Unbiased AI), NIST AI 600-1 (GenAI), GAO-21-519SP (AI Accountability) |
| **Architecture** | NIST 800-207 Zero Trust, CISA Secure by Design, IEEE 1012 IV&V |
| **Explainability** | XAI Compliance, Model Cards, System Cards, Confabulation Detection, Fairness Assessment |

---

## CodeLens — Universal Code Review Engine

CodeLens is ICDEV's built-in code review and quality gate engine. Every review runs 7 parallel analysis lenses — deterministic-first, LLM-agnostic, air-gap safe.

| Lens | Name | What It Checks |
|------|------|----------------|
| L1 | **Style & Format** | Naming conventions, formatting, import order |
| L2 | **Complexity** | Cyclomatic/cognitive complexity, deep nesting, long functions |
| L3 | **Security** | OWASP Top 10, injection, hardcoded secrets, unsafe deserialization |
| L4 | **Documentation** | Missing docstrings, stale comments, API doc coverage |
| L5 | **Error Handling** | Bare excepts, swallowed errors, missing error paths |
| L6 | **Performance** | N+1 queries, unnecessary allocations, blocking I/O in async |
| L7 | **Testing** | Test coverage gaps, assertion quality, missing edge case tests |

```bash
# Run CodeLens review
python -m tools.review.cli --project-dir . --json

# Single lens
python -m tools.review.cli --project-dir . --lenses security --json
```

### CodeLens Pro — 9 Advanced Lenses (L8-L16)

CodeLens Pro extends the base engine with 9 additional lenses for teams that need deeper analysis. Available at STANDARD+ maturity levels.

| Lens | Name | Maturity | What It Checks |
|------|------|----------|----------------|
| L8 | **Accessibility** | STANDARD | WCAG 2.1 AA compliance, ARIA roles, color contrast |
| L9 | **Mutation Testing** | STANDARD | Test suite strength via code mutation survival analysis |
| L10 | **Property Testing** | STANDARD | Hypothesis-style invariant verification |
| L11 | **Contract Testing** | ADVANCED | API contract conformance, schema drift |
| L12 | **IV&V** | ADVANCED | IEEE 1012 independent verification & validation |
| L13 | **Usability** | ADVANCED | UX heuristic evaluation, cognitive load |
| L14 | **Chaos Engineering** | ADVANCED | Failure injection readiness, resilience patterns |
| L15 | **Intent Analysis** | ADVANCED | Code-to-requirements alignment, dead code, scope creep |
| L16 | **Runtime Feedback** | ADVANCED | Production error correlation, deploy spike detection, test gap analysis |

**L16 Runtime Feedback** closes the loop between code review and production behavior. It correlates runtime errors back to source files under review — error hotspots, recurring patterns, deployment-correlated spikes, and test coverage gaps. Air-gap native: reads from existing ICDEV SQLite tables with zero external dependencies. Connected mode (Sentry webhook) is optional.

```bash
# Run CodeLens Pro
python -m tools.review_pro.cli_pro --project-dir . --maturity advanced --json

# Run specific Pro lens
python -m tools.review_pro.cli_pro --project-dir . --pro-lenses runtime_feedback --no-base --json
```

Both CodeLens and CodeLens Pro are **core ICDEV components** — included in every deployment under the same Apache 2.0 + Commercial dual license. No marketplace activation required. Works fully air-gapped.

---

## Multi-Agent Architecture (15 Agents)

| Tier | Agents | Role |
|------|--------|------|
| **Core** | Orchestrator, Architect | Task routing, system design |
| **Domain** | Builder, Compliance, Security, Infrastructure, MBSE, Modernization, Requirements Analyst, Supply Chain, Simulation, DevSecOps/ZTA, Gateway | Specialized domain work |
| **Support** | Knowledge, Monitor | Self-healing, observability |

Agents communicate via A2A protocol (JSON-RPC 2.0 over mutual TLS). Each publishes an Agent Card at `/.well-known/agent.json`. Workflows use DAG-based parallel execution with domain authority vetoes.

**Orchestration Controls:**
- **Dispatcher mode** — Orchestrator delegates only, never executes tools directly (GOTCHA enforcement)
- **Declarative prompt chains** — YAML-driven sequential LLM-to-LLM reasoning (plan → critique → refine)
- **Session purpose tracking** — NIST AU-3 audit traceability for every agent session
- **Async result injection** — high-priority mailbox delivery for completed background tasks
- **Tiered file access** — zero_access / read_only / no_delete defense-in-depth for sensitive files

---

## 6 First-Class Languages — Build New or Modernize Legacy

Government agencies and defense contractors sit on millions of lines of legacy code — COBOL, Fortran, Struts, .NET Framework, Python 2 — with the original developers long gone and zero institutional knowledge left. Hiring is impossible: nobody wants to maintain a 20-year-old Java 6 monolith on WebLogic. The code works, but it's a ticking time bomb of tech debt, unpatched CVEs, and expired ATOs.

ICDEV solves this from both directions:

**Build new** — scaffold, TDD, lint, scan, and generate code in any of 6 languages with compliance baked in from line one:

| Language | Scaffold | TDD | Lint | SAST | BDD | Code Gen |
|----------|:--------:|:---:|:----:|:----:|:---:|:--------:|
| Python | Flask/FastAPI | pytest | ruff | bandit | behave | yes |
| Java | Spring Boot | JUnit | checkstyle | SpotBugs | Cucumber | yes |
| Go | net/http, Gin | go test | golangci-lint | gosec | godog | yes |
| Rust | Actix-web | cargo test | clippy | cargo-audit | cucumber-rs | yes |
| C# | ASP.NET Core | xUnit | analyzers | SecurityCodeScan | SpecFlow | yes |
| TypeScript | Express | Jest | eslint | eslint-security | cucumber-js | yes |

**Modernize legacy** — when the original team is gone, ICDEV becomes the team:

- **7R Assessment** — automated analysis scores each application across Rehost, Replatform, Refactor, Rearchitect, Rebuild, Replace, and Retire using a weighted multi-criteria decision matrix. No tribal knowledge required — ICDEV reads the code.
- **Architecture Extraction** — static analysis maps the dependency graph, identifies coupling hotspots, measures complexity, and generates documentation that never existed. Works on codebases with zero comments and zero docs.
- **Cross-Language Translation** — 5-phase hybrid pipeline translates between any of the 30 language pairs (Extract → Type-Check → Translate → Assemble → Validate+Repair). Migrating a Python 2 Flask app to Go? A legacy Java 8 monolith to modern Spring Boot? A .NET Framework service to ASP.NET Core? ICDEV generates pass@k candidate translations, validates with compiler feedback, and auto-repairs failures — up to 3 repair cycles per unit.
- **Strangler Fig Tracking** — for large monoliths that can't be rewritten overnight, ICDEV manages the gradual migration: dual-system traceability, feature-by-feature cutover tracking, and a compliance bridge that maintains ≥95% ATO control coverage throughout the entire transition.
- **Framework Migration** — declarative JSON mapping rules handle Struts → Spring Boot, Django 2 → Django 4, Rails 5 → Rails 7, Express → Fastify, and more. Add new migration paths without writing code.
- **ATO Compliance Bridge** — this is the killer feature for modernization. Legacy apps often have existing ATOs. ICDEV ensures the modernized application inherits the original control mappings through the crosswalk engine, so you don't lose years of compliance work. The bridge validates coverage every PI and blocks deployment if it drops below 95%.

The bottom line: **you don't need the original developers**. You don't need a team that knows the legacy stack. ICDEV analyzes the codebase, scores the migration strategy, translates the code, and maintains ATO coverage — with an append-only audit trail documenting every decision for your ISSO.

---

## 6 Cloud Providers

| Provider | Environment | LLM Integration |
|----------|-------------|-----------------|
| **AWS GovCloud** | us-gov-west-1 | Amazon Bedrock (Claude, Titan) |
| **Azure Government** | USGov Virginia | Azure OpenAI |
| **GCP** | Assured Workloads | Vertex AI (Gemini, Claude) |
| **OCI** | Government Cloud | OCI GenAI (Cohere, Llama) |
| **IBM** | Cloud for Government | watsonx.ai (Granite, Llama) |
| **Local** | Air-Gapped | Ollama (Llama, Mistral, CodeGemma) |

Generated applications connect to 100+ cloud-provider MCP servers automatically based on target CSP.

---

## GOTCHA Framework

ICDEV's core architecture separates deterministic tools from probabilistic AI:

```
┌──────────────────────────────────────────────────────┐
│  Goals         →  What to achieve (48 workflows)      │
│  Orchestration →  AI decides tool order (LLM layer)   │
│  Tools         →  Deterministic scripts (500+ tools)  │
│  Context       →  Static reference (42 catalogs)      │
│  Hard Prompts  →  Reusable LLM templates              │
│  Args          →  YAML/JSON config (40+ files)        │
└──────────────────────────────────────────────────────┘
```

**Why?** LLMs are probabilistic. Business logic must be deterministic. 90% accuracy per step = ~59% over 5 steps. GOTCHA fixes this by keeping AI in the orchestration layer and critical logic in deterministic Python scripts.

Generated child applications inherit the full GOTCHA framework — they aren't wrappers or templates, they're autonomous systems that can build their own features using the same methodology.

---

## Architecture

```
┌──────────────────────────────────────────────────────────┐
│                  Claude Code / AI IDE                      │
│            (39 slash commands, 250+ MCP tools)             │
├──────────────────────────────────────────────────────────┤
│                 Unified MCP Gateway                        │
│          (single server, all 250+ tools, lazy-loaded)       │
├──────────┬──────────┬───────────┬───────────┬────────────┤
│   Core   │  Domain  │  Domain   │  Domain   │  Support   │
│          │          │           │           │            │
│ Orchestr │ Builder  │ MBSE      │ DevSecOps │ Knowledge  │
│ Architect│ Complnce │ Modernize │ Gateway   │ Monitor    │
│          │ Security │ Req.Anlst │           │            │
│          │ Infra    │ SupplyChn │           │            │
│          │          │ Simulatn  │           │            │
├──────────┴──────────┴───────────┴───────────┴────────────┤
│                   GOTCHA Framework                         │
│       Goals │ Tools │ Args │ Context │ Hard Prompts        │
├──────────────────────────────────────────────────────────┤
│  SQLite (dev) / PostgreSQL (prod)  │   Multi-Cloud CSP    │
│  210 tables, append-only audit     │  AWS │Azure│GCP│OCI  │
│  Per-tenant DB isolation           │  IBM │Local/Air-Gap   │
└──────────────────────────────────────────────────────────┘
```

---

## Dashboard

```bash
python tools/dashboard/app.py
# → http://localhost:5000
```

| Page | Purpose |
|------|---------|
| `/` | Home with auto-notifications and pipeline status |
| `/projects` | Project listing with compliance posture |
| `/agents` | Agent registry with heartbeat monitoring |
| `/monitoring` | System health with status icons |
| `/wizard` | Getting Started wizard (3 questions → workflow) |
| `/query` | Natural language compliance queries |
| `/chat` | Multi-agent chat interface |
| `/children` | Generated child application registry with health monitoring |
| `/traces` | Distributed trace explorer with span waterfall |
| `/provenance` | W3C PROV lineage viewer |
| `/xai` | Explainable AI dashboard with SHAP analysis |
| `/ai-transparency` | AI Transparency: model cards, system cards, AI inventory, fairness, GAO readiness |
| `/ai-accountability` | AI Accountability: oversight plans, CAIO registry, appeals, incidents, ethics reviews, reassessment |
| `/code-quality` | Code Quality Intelligence: AST metrics, smell detection, maintainability trend, runtime feedback |
| `/orchestration` | Real-time orchestration: agent grid, workflow DAG, SSE mailbox feed, prompt chains, ATLAS critiques |
| `/cpmp` | Contract Performance Management: EVM, CPARS prediction, deliverables, subcontractors, portfolio health |
| `/cpmp/cor` | COR portal: government read-only contract oversight (deliverables, EVM, CPARS) |
| `/proposals` | GovProposal lifecycle: opportunities, sections, compliance matrix, timeline, reviews |
| `/govcon` | GovCon Intelligence: SAM.gov scanning, pipeline status, domain distribution |
| `/govcon/requirements` | Requirement pattern analysis: frequency, domain heatmap, trend detection |
| `/govcon/capabilities` | ICDEV capability coverage: L/M/N grading, gaps, enhancement recommendations |

Auth: per-user API keys (SHA-256 hashed), 6 RBAC roles (admin, pm, developer, isso, co, cor). Optional BYOK (bring-your-own LLM keys) with AES-256 encryption.

### Dashboard Screenshots

**Home Dashboard** — Real-time system overview with pipeline status, agent health, and auto-notifications:

![Home Dashboard](playwright/screenshots/e2e-home-desktop.png)

**Knowledge Search (RAG)** — Natural language search across all ingested knowledge with source filtering and relevance scoring:

![Knowledge Search](playwright/screenshots/e2e-knowledge-search.png)

### GovProposal E2E Lifecycle

The following screenshots capture a complete end-to-end proposal lifecycle — from RFP intake through contract award — simulated against a realistic Air Force cloud migration solicitation (FA8075-26-R-0128).

**1. Proposals Overview** — Portfolio view of all tracked opportunities with status, agency, and deadline:

![Proposals Overview](playwright/screenshots/e2e-01-proposals-overview.png)

**2. Opportunity Intake** — New opportunity created from SAM.gov solicitation, entering the capture pipeline:

![Opportunity Intake](playwright/screenshots/e2e-02-opportunity-intake.png)

**3. Compliance Matrix** — Auto-populated L/M/N compliance grading from ICDEV capability mapping against extracted RFP "shall" statements:

![Compliance Matrix](playwright/screenshots/e2e-05-compliance-matrix.png)

**4. Sections at Multiple Review Stages** — 7 proposal sections across 3 volumes, each at a different stage of the 14-step color team review pipeline (Submitted, Gold Team, Red Team, Pink Team, Final, Internal Review):

![Sections Multi-Stage](playwright/screenshots/e2e-07-sections-multi-stage.png)

**5. Section Detail — 14-Step Status Pipeline** — Full color team review pipeline for a single section, showing all 15 stages from Not Started through Submitted:

![Section Detail Pipeline](playwright/screenshots/e2e-08-section-detail-pipeline.png)

**6. Section Status History** — Complete audit trail of status transitions with timestamps, reviewers, and reasons:

![Section Status History](playwright/screenshots/e2e-09-section-status-history.png)

**7. Opportunity Won** — Proposal awarded with "Contract Transition Available" banner for seamless handoff to post-award management:

![Opportunity Won](playwright/screenshots/e2e-10-opportunity-won.png)

**8. CPMP Contract** — Post-award Contract Performance Management Portal with EVM, CPARS, deliverables, and subcontractor tracking:

![CPMP Contract](playwright/screenshots/e2e-12-cpmp-contract.png)

### GovCon Intelligence — Competitive Landscape

The GovCon Intelligence dashboard pulls live data from two federal procurement sources — **SAM.gov Opportunities API v2** and **FPDS via USASpending.gov** — scanning across 3 NAICS codes (541512, 541519, 541715). Award notices auto-discover competitors, track contract values, and map NAICS distribution.

**GovCon Dashboard** — 179 opportunities, 2,999 FPDS wins, 1,277 competitors, $128B+ in tracked FPDS value:

![GovCon Intelligence](playwright/screenshots/govcon-desktop.png)

**Active Competitors** — Combined SAM + FPDS data with top agency, NAICS domains, and status. Major primes (Booz Allen, Accenture Federal, GDIT, CACI, Peraton, Deloitte) auto-discovered from award data:

![Active Competitors](playwright/screenshots/govcon-fpds-wins.png)

**Recent Competitor Wins (FPDS)** — Real-time contract award data from USASpending.gov with award IDs, amounts, agencies, and descriptions:

![FPDS Wins](playwright/screenshots/govcon-fpds-table.png)

**Tablet View** — Responsive layout with 6-card stat grid, scan controls, and competitor tables:

![GovCon Tablet](playwright/screenshots/govcon-tablet.png)

### SparkPilot — AI Co-Pilot for Embedded Systems

SparkPilot makes embedded RTOS development accessible to anyone — from a beginner building their first blinking LED to a DoD engineer deploying AI-enabled firmware with full NIST compliance. Four-tier architecture spans browser simulator (WASM) through MCU, edge gateway, and cloud orchestration. 5 supported boards (ESP32-S3, STM32F407, nRF52840, RPi Pico, Simulator), 8 embedded compliance frameworks (NIST, IEC 62443, DO-178C, ISO 26262, IEC 62304, MISRA C, FIPS 140-3, EU AI Act), and a ~8KB device SDK with MQTT, OTA, and telemetry.

**Home Dashboard** — 10-card overview (devices, firmware builds, missions, ML models, sim sessions, crash dumps, OTA pending, NL commands) with inline natural language command input:

![SparkPilot Dashboard](playwright/screenshots/sparkpilot-home-desktop.png)

**Natural Language to Firmware** — Type "Blink an LED every 2 seconds" and get production FreeRTOS C code with `hal_gpio`, `vTaskDelay`, and `xTaskCreate` — ready to cross-compile for any supported board:

![NL-to-Firmware](playwright/screenshots/sparkpilot-nl-command.png)

**Gamified Missions** — 7 progressive missions from beginner to expert (Hello LED → Sensor Explorer → WiFi Wrangler → MQTT Messenger → AI Detective → Silicon Upgrade → Fleet Commander) with XP, difficulty badges, and step-by-step objectives:

![Learning Missions](playwright/screenshots/sparkpilot-missions.png)

**FreeRTOS Simulator** — Browser-based simulator with 7 virtual peripherals (accelerometer, button, LEDs, OLED display, potentiometer, temperature sensor) and session management — no hardware required:

![FreeRTOS Simulator](playwright/screenshots/sparkpilot-simulator.png)

**Device Fleet** — Register devices by name and board type, track online/offline status, firmware version, and heartbeat timestamps. Supports ESP32-S3, STM32F407, nRF52840, RPi Pico, and simulator:

![Device Fleet](playwright/screenshots/sparkpilot-fleet.png)

**Self-Healing Firmware** — 4-step autonomous pipeline: device crashes → AI analyzes dump → patch generated → auto-deployed via OTA. Confidence-based gating (≥0.7 auto-fix, 0.3–0.7 suggest, <0.3 escalate):

![Self-Healing Firmware](playwright/screenshots/sparkpilot-selfheal.png)

---

## MCP Server Integration

All 250+ tools exposed through a single MCP gateway. Works with any AI coding assistant:

```json
{
  "mcpServers": {
    "icdev-unified": {
      "command": "python",
      "args": ["tools/mcp/unified_server.py"]
    }
  }
}
```

Compatible with: **Claude Code**, **OpenAI Codex**, **Google Gemini**, **GitHub Copilot**, **Cursor**, **Windsurf**, **Amazon Q**, **JetBrains/Junie**, **Cline**, **Aider**.

---

## Security

Defense-in-depth by default:

- **STIG-hardened containers** — non-root, read-only rootfs, all capabilities dropped
- **Append-only audit trail** — no UPDATE/DELETE on audit tables, NIST AU compliant
- **CUI markings** — applied at generation time per impact level (IL4/IL5/IL6)
- **Mutual TLS** — all inter-agent communication within K8s
- **Prompt injection detection** — 5-category scanner for AI-specific threats
- **MITRE ATLAS red teaming** — adversarial testing against 6 techniques
- **Behavioral drift detection** — z-score baseline monitoring for all agents
- **Tool chain validation** — blocks dangerous execution sequences
- **MCP RBAC** — per-tool, per-role deny-first authorization
- **AI transparency** — model cards, system cards, AI use case inventory, confabulation detection, fairness assessment per OMB M-25-21/M-26-04, NIST AI 600-1, and GAO-21-519SP
- **AI accountability** — human oversight plans, CAIO designation, appeal tracking, AI incident response, ethics reviews, reassessment scheduling, cross-framework accountability audit
- **Dispatcher mode** — Orchestrator agent enforced as delegate-only, cannot execute tools directly
- **Tiered file access control** — zero_access (`.env`, `*.pem`, `*.tfstate`), read_only (lock files, catalogs), no_delete (`CLAUDE.md`, goals, IaC)
- **Session purpose tracking** — NIST AU-3 compliant session intent declaration with SHA-256 integrity hashing
- **ATLAS adversarial critique** — multi-agent plan review with GO/NOGO/CONDITIONAL consensus before stress-testing
- **Self-healing** — confidence-based remediation (≥0.7 auto-fix, 0.3–0.7 suggest, <0.3 escalate)

---

## Deployment

### Desktop (Development)

```bash
pip install -r requirements.txt
python tools/dashboard/app.py --port 5050
# → http://localhost:5050
```

### Natural Language to Firmware

```bash
# Simulator (no hardware needed)
python tools/embedded/nl_to_firmware.py --command "Blink LED every 2 seconds" --board simulator --json

# ESP32-S3
python tools/embedded/nl_to_firmware.py --command "Read temperature sensor" --board esp32-s3 --json

# STM32F407 with deploy
python tools/embedded/nl_to_firmware.py --command "Send MQTT message" --board stm32f407 --deploy --json
```

### Simulator

```bash
python tools/simulator/sim_runner.py --seed --json          # Seed virtual peripherals
python tools/simulator/sim_runner.py --create --user-id player1 --json  # Start session
python tools/simulator/sim_runner.py --peripherals --json   # List peripherals
```

### Missions

```bash
python tools/missions/mission_engine.py --seed --json                    # Seed 7 missions
python tools/missions/mission_engine.py --start --mission 1 --user-id player1 --json  # Start Mission 1
python tools/missions/mission_engine.py --complete --mission 1 --user-id player1 --json
python tools/missions/mission_engine.py --progress --user-id player1 --json
```

### Fleet Management

```bash
python tools/fleet/device_registry.py --register --name "my-esp32" --board esp32-s3 --json
python tools/fleet/device_registry.py --list --json
python tools/fleet/device_registry.py --health --json
```

### OTA Updates

```bash
python tools/fleet/ota_manager.py --deploy --firmware-id fw-001 --device-id dev-001 --json
python tools/fleet/ota_manager.py --canary --firmware-id fw-001 --group-id grp-001 --canary-pct 10 --json
python tools/fleet/ota_manager.py --status --json
```

### Edge AI

```bash
python tools/edge_ai/model_manager.py --templates --json
python tools/edge_ai/model_manager.py --register --name "anomaly" --task anomaly_detection --json
python tools/edge_ai/model_manager.py --deploy --model-id mdl-001 --device-id dev-001 --json
```

### CMake Generation

```bash
python tools/embedded/cmake_generator.py --board esp32-s3 --json
python tools/embedded/cmake_generator.py --board simulator --with-tinyml --json
```

### Crash Analysis

```bash
python tools/embedded/crash_analyzer.py --crash-type hardfault --device-id dev-001 --json
python tools/embedded/crash_analyzer.py --patterns --json
```

---

## Database

**32 tables** in `data/sparkpilot.db` (SQLite):

| Category | Tables |
|----------|--------|
| Core | projects, audit_trail, agents, agent_tasks, memory_entries |
| Compliance | compliance_controls, compliance_evidence, sbom_entries |
| Devices | devices, rtos_tasks, device_telemetry, device_commands |
| Firmware | firmware_builds, firmware_deploy_log, ota_update_log |
| Fleet | device_groups, fleet_canary_log, mqtt_messages |
| Edge AI | ml_models, inference_telemetry |
| Missions | missions, mission_completion_log, user_progress |
| Simulator | simulator_sessions, simulator_session_log, virtual_peripherals |
| Build | cmake_configs, board_support_packages |
| NL Commands | nl_commands, embedded_patterns |

**10 append-only tables** — no UPDATE/DELETE for audit compliance.

---

## Dashboard Pages

| Page | Route | Purpose |
|------|-------|---------|
| Home | `/` | Stats grid, NL command input, recent activity |
| Missions | `/missions` | 7 mission cards with progress tracking |
| Simulator | `/simulator` | Virtual peripherals, session management |
| Fleet | `/devices` | Device registry, registration form |
| Firmware | `/firmware` | Firmware builds, OTA update log |
| Edge AI | `/edge-ai` | ML model registry, inference telemetry |
| Self-Heal | `/crashes` | Crash dump log, system health status |
| AI Agents | `/agents` | Agent registry, LLM orchestration status |

**API Endpoints:** `/api/nl-command`, `/api/mission/{n}`, `/api/mission/start`, `/api/mission/complete`, `/api/sim/create`, `/api/device/register`, `/health`

---

## Compliance Frameworks (Pro Mode)

SparkPilot supports progressive compliance — Beginner Mode shows a clean UI, Pro Mode enables full compliance traceability:

| Framework | Scope |
|-----------|-------|
| NIST 800-53 | Core federal baseline |
| IEC 62443 | Industrial cybersecurity |
| DO-178C | Avionics traceability |
| ISO 26262 | Automotive safety |
| IEC 62304 | Medical devices |
| MISRA C:2023 | Coding standard |
| FIPS 140-3 | Crypto modules |
| EU AI Act | Embedded AI |

---

## Project Structure

```
sparkpilot/
├── sdk/                     # Device SDK (~8KB C library)
│   ├── include/             # sparkpilot_sdk.h
│   ├── src/                 # sparkpilot_sdk.c
│   └── CMakeLists.txt       # Build config
├── tools/
│   ├── dashboard/           # Flask web UI (port 5050)
│   ├── embedded/            # NL-to-firmware, CMake gen, crash analysis
│   ├── fleet/               # Device registry, OTA manager
│   ├── edge_ai/             # TinyML model manager
│   ├── missions/            # Gamified mission engine
│   ├── simulator/           # Browser-based FreeRTOS simulator
│   └── db/                  # Database initialization (32 tables)
├── data/
│   └── sparkpilot.db        # SQLite operational database
├── playwright/screenshots/  # E2E test screenshots
└── README.md                # This file
```

---

## Testing

```bash
# Health check
python tools/testing/health_check.py

# E2E browser tests (Playwright)
python tools/testing/e2e_runner.py --run-all

# SparkPilot dashboard E2E
# Tests: home, NL command, missions, simulator, fleet, firmware, edge AI, self-heal
# Viewports: desktop (1920x1080), tablet (768x1024), mobile (375x812)
```

---

## License

ICDEV is dual-licensed:

- **Open Source** — [Apache License 2.0](LICENSE) — free for use, modification, and distribution with patent protection
- **Commercial** — [Commercial License](COMMERCIAL.md) — for SLA-backed support, IP indemnification, FedRAMP managed service, and white-label rights

---

<p align="center">
  <i>Talk to your hardware. Ship firmware in minutes.</i>
</p>
