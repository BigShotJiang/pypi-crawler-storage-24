# CUI // SP-CTI
"""Tests for the ICDEV error hierarchy.

Classification: CUI // SP-CTI
"""

import pytest

from tools.core.errors import (
    ICDEVError,
    AgentError,
    AgentUnavailableError,
    AgentTimeoutError,
    AgentContractError,
    ComplianceError,
    ComplianceGateError,
    ClassificationError,
    LLMError,
    LLMFallbackExhaustedError,
    LLMProviderError,
    StorageError,
    StorageConnectionError,
    StorageMigrationError,
    SecurityError,
    PromptInjectionError,
    TrustScoreError,
)


# ---------------------------------------------------------------------------
# Base error
# ---------------------------------------------------------------------------

class TestICDEVError:

    def test_basic_creation(self):
        err = ICDEVError("something went wrong")
        assert str(err) == "something went wrong"
        assert err.code is None
        assert err.retryable is False
        assert err.context == {}

    def test_with_all_params(self):
        err = ICDEVError(
            "bad", code="BAD_THING", retryable=True, context={"key": "val"}
        )
        assert err.code == "BAD_THING"
        assert err.retryable is True
        assert err.context["key"] == "val"

    def test_to_dict(self):
        err = ICDEVError("msg", code="C1", retryable=True)
        d = err.to_dict()
        assert d["error"] == "ICDEVError"
        assert d["message"] == "msg"
        assert d["code"] == "C1"
        assert d["retryable"] is True

    def test_is_exception(self):
        with pytest.raises(ICDEVError):
            raise ICDEVError("test")


# ---------------------------------------------------------------------------
# Agent errors
# ---------------------------------------------------------------------------

class TestAgentErrors:

    def test_unavailable_sets_context(self):
        err = AgentUnavailableError("compliance")
        assert "compliance" in str(err)
        assert err.context["agent_name"] == "compliance"
        assert err.retryable is True
        assert err.code == "AGENT_UNAVAILABLE"

    def test_timeout_captures_duration(self):
        err = AgentTimeoutError("builder", 30.0)
        assert err.context["timeout_seconds"] == 30.0
        assert err.retryable is True

    def test_contract_error_not_retryable(self):
        err = AgentContractError("security", "missing 'scan_id' in response")
        assert err.retryable is False
        assert "contract" in err.code.lower()

    def test_hierarchy(self):
        err = AgentUnavailableError("x")
        assert isinstance(err, AgentError)
        assert isinstance(err, ICDEVError)
        assert isinstance(err, Exception)


# ---------------------------------------------------------------------------
# Compliance errors
# ---------------------------------------------------------------------------

class TestComplianceErrors:

    def test_gate_error_captures_findings(self):
        findings = [{"id": "V-1234", "severity": "CAT1"}]
        err = ComplianceGateError("stig_check", findings=findings)
        assert err.findings == findings
        assert err.retryable is False

    def test_classification_error(self):
        err = ClassificationError("Missing CUI marking")
        assert "classification" in err.code.lower()


# ---------------------------------------------------------------------------
# LLM errors
# ---------------------------------------------------------------------------

class TestLLMErrors:

    def test_fallback_exhausted(self):
        err = LLMFallbackExhaustedError(
            "code_generation", ["ollama", "bedrock"]
        )
        assert err.context["providers_tried"] == ["ollama", "bedrock"]
        assert err.retryable is False

    def test_provider_error_retryable(self):
        err = LLMProviderError("bedrock", "throttled")
        assert err.retryable is True
        assert err.context["provider"] == "bedrock"


# ---------------------------------------------------------------------------
# Storage errors
# ---------------------------------------------------------------------------

class TestStorageErrors:

    def test_connection_error(self):
        err = StorageConnectionError("postgresql", "connection refused")
        assert err.retryable is True
        assert err.context["backend"] == "postgresql"

    def test_migration_error(self):
        err = StorageMigrationError("v42", "column already exists")
        assert err.retryable is False


# ---------------------------------------------------------------------------
# Security errors
# ---------------------------------------------------------------------------

class TestSecurityErrors:

    def test_prompt_injection(self):
        err = PromptInjectionError("instruction_override", 0.95)
        assert err.context["confidence"] == 0.95
        assert err.retryable is False

    def test_trust_score(self):
        err = TrustScoreError("rogue_agent", 0.15, 0.30)
        assert err.context["score"] == 0.15
        assert err.context["threshold"] == 0.30
