# CUI // SP-CTI
"""Tests for unified Ops MCP server — handler dispatch and JSON-RPC protocol."""

import json
import sqlite3
from pathlib import Path
from unittest.mock import patch

import pytest

from tools.mcp.ops_server import HANDLERS, handle_request


# ─── JSON-RPC PROTOCOL TESTS ────────────────────────────────────────────────


class TestProtocol:
    def test_method_not_found(self):
        resp = handle_request({"jsonrpc": "2.0", "id": 1, "method": "nonexistent"})
        assert resp["error"]["code"] == -32601
        assert "not found" in resp["error"]["message"].lower()

    def test_all_18_handlers_registered(self):
        expected = {
            "runbook_list", "runbook_get", "runbook_create", "runbook_execute",
            "runbook_execution_status", "runbook_generate",
            "metastore_list_apps", "metastore_get_app", "metastore_register",
            "metastore_dependencies", "metastore_discover", "metastore_rto_check",
            "ops_query_zones", "ops_query_budgets", "ops_query_siem",
            "ops_query_migrations", "ops_query_deployments", "ops_query_topologies",
        }
        assert set(HANDLERS.keys()) == expected
        assert len(HANDLERS) == 18


# ─── RUNBOOK HANDLER TESTS (with temp DB) ────────────────────────────────────


@pytest.fixture
def temp_db(tmp_path):
    """Create temp DB with all tables needed."""
    db_path = tmp_path / "test_icdev.db"
    conn = sqlite3.connect(str(db_path))
    conn.executescript("""
        CREATE TABLE cf_runbooks (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT,
            version INTEGER DEFAULT 1, status TEXT DEFAULT 'draft',
            template_source TEXT, tasks_json TEXT NOT NULL, edges_json TEXT NOT NULL,
            snippets_used TEXT, estimated_duration_minutes INTEGER,
            owner TEXT, tags TEXT, classification TEXT DEFAULT 'CUI // SP-CTI',
            tenant_id TEXT DEFAULT 'default', project_id TEXT, created_by TEXT,
            created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT (datetime('now')),
            UNIQUE(tenant_id, name, version)
        );
        CREATE TABLE cf_runbook_executions (
            id TEXT PRIMARY KEY, runbook_id TEXT NOT NULL, runbook_version INTEGER NOT NULL,
            status TEXT DEFAULT 'pending', trigger_type TEXT DEFAULT 'manual',
            triggered_by TEXT, started_at TEXT, completed_at TEXT,
            duration_ms INTEGER, task_results_json TEXT,
            parallel_paths_count INTEGER DEFAULT 0,
            tasks_completed INTEGER DEFAULT 0, tasks_failed INTEGER DEFAULT 0,
            tasks_skipped INTEGER DEFAULT 0, tasks_total INTEGER DEFAULT 0,
            error_summary TEXT, classification TEXT DEFAULT 'CUI // SP-CTI',
            tenant_id TEXT DEFAULT 'default', created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE cf_runbook_task_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT, execution_id TEXT NOT NULL,
            task_id TEXT NOT NULL, task_name TEXT NOT NULL, action TEXT NOT NULL,
            output_json TEXT, error_details TEXT, duration_ms INTEGER,
            actor TEXT DEFAULT 'cloudforge', classification TEXT DEFAULT 'CUI // SP-CTI',
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE cf_applications (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT,
            app_type TEXT NOT NULL, status TEXT DEFAULT 'active',
            environment TEXT DEFAULT 'production', rto_hours REAL, rpo_hours REAL,
            criticality TEXT DEFAULT 'medium', owner_team TEXT, owner_email TEXT,
            zone_ids TEXT, device_ids TEXT, connection_ids TEXT, runbook_ids TEXT,
            metadata_json TEXT, discovery_source TEXT, tags TEXT,
            classification TEXT DEFAULT 'CUI // SP-CTI',
            tenant_id TEXT DEFAULT 'default', project_id TEXT, created_by TEXT,
            created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT (datetime('now')),
            UNIQUE(tenant_id, name, environment)
        );
        CREATE TABLE cf_app_dependencies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_app_id TEXT NOT NULL, target_app_id TEXT NOT NULL,
            dependency_type TEXT NOT NULL, protocol TEXT, port INTEGER,
            description TEXT, classification TEXT DEFAULT 'CUI // SP-CTI',
            tenant_id TEXT DEFAULT 'default', created_at TEXT DEFAULT (datetime('now')),
            UNIQUE(source_app_id, target_app_id, dependency_type)
        );
        CREATE TABLE cf_runbook_snippets (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT,
            category TEXT NOT NULL, tasks_json TEXT NOT NULL, edges_json TEXT NOT NULL,
            usage_count INTEGER DEFAULT 0, classification TEXT DEFAULT 'CUI // SP-CTI',
            tenant_id TEXT DEFAULT 'default', created_by TEXT,
            created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT (datetime('now')),
            UNIQUE(tenant_id, name)
        );
    """)
    conn.commit()
    conn.close()
    return db_path


class TestRunbookHandlers:
    def test_runbook_list_empty(self, temp_db):
        with patch("tools.cloudforge.runbooks.engine.DB_PATH", temp_db):
            resp = handle_request({"jsonrpc": "2.0", "id": 1, "method": "runbook_list", "params": {}})
            assert resp["result"] == []

    def test_runbook_create_and_list(self, temp_db):
        with patch("tools.cloudforge.runbooks.engine.DB_PATH", temp_db):
            resp = handle_request({
                "jsonrpc": "2.0", "id": 1, "method": "runbook_create",
                "params": {
                    "name": "MCP Test",
                    "tasks": [{"id": "t1", "name": "A", "action": "noop"}],
                    "edges": [],
                }
            })
            assert resp["result"]["status"] == "ok"

            resp2 = handle_request({"jsonrpc": "2.0", "id": 2, "method": "runbook_list", "params": {}})
            assert len(resp2["result"]) == 1

    def test_runbook_execute(self, temp_db):
        with patch("tools.cloudforge.runbooks.engine.DB_PATH", temp_db):
            create = handle_request({
                "jsonrpc": "2.0", "id": 1, "method": "runbook_create",
                "params": {
                    "name": "Exec Test",
                    "tasks": [{"id": "t1", "name": "A", "action": "noop"}],
                    "edges": [],
                }
            })
            rb_id = create["result"]["id"]

            exec_resp = handle_request({
                "jsonrpc": "2.0", "id": 2, "method": "runbook_execute",
                "params": {"runbook_id": rb_id}
            })
            assert exec_resp["result"]["status"] == "completed"

    def test_runbook_generate(self, temp_db):
        resp = handle_request({
            "jsonrpc": "2.0", "id": 1, "method": "runbook_generate",
            "params": {"description": "DR failover for production zone"}
        })
        assert resp["result"]["status"] == "ok"
        assert resp["result"]["generated"] is True
        assert len(resp["result"]["tasks"]) > 0


class TestMetastoreHandlers:
    def test_metastore_list_empty(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            resp = handle_request({"jsonrpc": "2.0", "id": 1, "method": "metastore_list_apps", "params": {}})
            assert resp["result"] == []

    def test_metastore_register_and_get(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            resp = handle_request({
                "jsonrpc": "2.0", "id": 1, "method": "metastore_register",
                "params": {"name": "MCP App", "app_type": "api"}
            })
            assert resp["result"]["status"] == "ok"
            app_id = resp["result"]["id"]

            get_resp = handle_request({
                "jsonrpc": "2.0", "id": 2, "method": "metastore_get_app",
                "params": {"app_id": app_id}
            })
            assert get_resp["result"]["name"] == "MCP App"

    def test_metastore_rto_check(self, temp_db):
        with patch("tools.cloudforge.metastore.rto_tracker.DB_PATH", temp_db):
            resp = handle_request({"jsonrpc": "2.0", "id": 1, "method": "metastore_rto_check", "params": {}})
            assert resp["result"]["status"] == "ok"

    def test_metastore_dependencies_full_graph(self, temp_db):
        with patch("tools.cloudforge.metastore.dependency_graph.DB_PATH", temp_db):
            resp = handle_request({"jsonrpc": "2.0", "id": 1, "method": "metastore_dependencies", "params": {}})
            assert resp["result"]["node_count"] == 0
