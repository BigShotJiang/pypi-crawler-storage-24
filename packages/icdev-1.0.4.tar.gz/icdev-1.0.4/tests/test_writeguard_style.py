"""WriteGuard Style Guide + Style Enforcer tests (~35 tests)."""
from __future__ import annotations

import json
import os
import sqlite3
import tempfile
import uuid

import pytest
import yaml

from tools.writing.style_guide_manager import (
    CASCADE_ORDER,
    create_guide,
    diff_versions,
    get_guide,
    history,
    list_guides,
    load_default_guides,
    lock_dimension,
    resolve_cascade,
    unlock_dimension,
    update_guide,
)
from tools.writing.style_enforcer import enforce_style


# ── Fixtures ───────────────────────────────────────────────────────


@pytest.fixture
def db_path(tmp_path):
    """Create a temporary database with wg tables."""
    path = tmp_path / "test_style.db"
    conn = sqlite3.connect(str(path))
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS wg_style_guides (
            id TEXT NOT NULL,
            scope TEXT NOT NULL,
            scope_id TEXT NOT NULL,
            version INTEGER NOT NULL DEFAULT 1,
            guide_name TEXT NOT NULL,
            guide_yaml TEXT NOT NULL,
            inherits_from TEXT,
            created_by TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            is_active INTEGER DEFAULT 1,
            change_summary TEXT,
            classification TEXT DEFAULT 'CUI',
            PRIMARY KEY (id, version)
        );
        CREATE TABLE IF NOT EXISTS wg_style_guide_locks (
            id TEXT PRIMARY KEY,
            guide_id TEXT NOT NULL,
            dimension_path TEXT NOT NULL,
            lock_owner_role TEXT NOT NULL,
            locked_by TEXT NOT NULL,
            locked_at TEXT NOT NULL DEFAULT (datetime('now')),
            reason TEXT,
            is_active INTEGER DEFAULT 1
        );
    """)
    conn.close()
    return str(path)


@pytest.fixture
def sample_guide_yaml():
    return yaml.dump({
        "readability": {"max_grade_level": 14, "target_grade_level": 11},
        "sentences": {"max_words": 35, "max_passive_voice_pct": 20},
        "tone": {"target": "technical"},
    })


# ── create_guide ───────────────────────────────────────────────────


class TestCreateGuide:

    def test_create_returns_id(self, db_path, sample_guide_yaml):
        r = create_guide("tenant", "t1", "Test Guide", sample_guide_yaml,
                         "admin", db_path=db_path)
        assert "id" in r
        assert r["scope"] == "tenant"
        assert r["version"] == 1

    def test_create_invalid_scope(self, db_path, sample_guide_yaml):
        r = create_guide("invalid_scope", "t1", "Bad", sample_guide_yaml,
                         "admin", db_path=db_path)
        assert "error" in r

    def test_create_empty_yaml(self, db_path):
        r = create_guide("tenant", "t1", "Empty", "", "admin", db_path=db_path)
        # Should either succeed with empty or error
        assert isinstance(r, dict)

    def test_create_duplicate_name_same_scope(self, db_path, sample_guide_yaml):
        create_guide("tenant", "t1", "Dup", sample_guide_yaml, "admin", db_path=db_path)
        r2 = create_guide("tenant", "t1", "Dup", sample_guide_yaml, "admin", db_path=db_path)
        # Should succeed as a separate guide (different id)
        assert "id" in r2


# ── get_guide ──────────────────────────────────────────────────────


class TestGetGuide:

    def test_get_existing(self, db_path, sample_guide_yaml):
        created = create_guide("project", "p1", "My Guide", sample_guide_yaml,
                               "user1", db_path=db_path)
        result = get_guide(created["id"], db_path=db_path)
        assert result["guide_name"] == "My Guide"

    def test_get_nonexistent(self, db_path):
        result = get_guide("nonexistent-id", db_path=db_path)
        assert "error" in result or result == {}

    def test_get_specific_version(self, db_path, sample_guide_yaml):
        created = create_guide("tenant", "t1", "Versioned", sample_guide_yaml,
                               "admin", db_path=db_path)
        update_guide(created["id"], yaml.dump({"readability": {"max_grade_level": 12}}),
                     "admin", "Updated", db_path=db_path)
        v1 = get_guide(created["id"], version=1, db_path=db_path)
        assert isinstance(v1, dict)


# ── list_guides ────────────────────────────────────────────────────


class TestListGuides:

    def test_list_empty(self, db_path):
        result = list_guides(db_path=db_path)
        assert isinstance(result, list)
        assert len(result) == 0

    def test_list_after_create(self, db_path, sample_guide_yaml):
        create_guide("tenant", "t1", "Listed", sample_guide_yaml,
                     "admin", db_path=db_path)
        result = list_guides(db_path=db_path)
        assert len(result) >= 1

    def test_list_filter_by_scope(self, db_path, sample_guide_yaml):
        create_guide("tenant", "t1", "Tenant Guide", sample_guide_yaml,
                     "admin", db_path=db_path)
        create_guide("project", "p1", "Project Guide", sample_guide_yaml,
                     "admin", db_path=db_path)
        result = list_guides(scope="tenant", db_path=db_path)
        assert all(g["scope"] == "tenant" for g in result)


# ── update_guide ───────────────────────────────────────────────────


class TestUpdateGuide:

    def test_update_increments_version(self, db_path, sample_guide_yaml):
        created = create_guide("tenant", "t1", "Updatable", sample_guide_yaml,
                               "admin", db_path=db_path)
        updated = update_guide(created["id"],
                               yaml.dump({"readability": {"max_grade_level": 10}}),
                               "admin", "Lower grade", db_path=db_path)
        assert updated["version"] == 2

    def test_update_nonexistent(self, db_path):
        result = update_guide("no-such-id", "yaml: content", "admin",
                              db_path=db_path)
        assert "error" in result


# ── resolve_cascade ────────────────────────────────────────────────


class TestResolveCascade:

    def test_resolve_empty_db(self, db_path):
        result = resolve_cascade("p1", scope="project", db_path=db_path)
        assert "resolved_guide" in result or "applied_layers" in result

    def test_resolve_with_guides(self, db_path):
        platform_yaml = yaml.dump({"readability": {"max_grade_level": 14}})
        tenant_yaml = yaml.dump({"readability": {"max_grade_level": 12}})
        create_guide("platform", "global", "Platform", platform_yaml,
                     "admin", db_path=db_path)
        create_guide("tenant", "t1", "Tenant", tenant_yaml,
                     "admin", db_path=db_path)
        result = resolve_cascade("t1", scope="tenant", db_path=db_path)
        assert isinstance(result, dict)

    def test_cascade_order_constant(self):
        assert CASCADE_ORDER == ("platform", "tenant", "program", "project", "user")


# ── lock_dimension / unlock_dimension ──────────────────────────────


class TestLockDimension:

    def test_lock_returns_lock_id(self, db_path, sample_guide_yaml):
        created = create_guide("tenant", "t1", "Lockable", sample_guide_yaml,
                               "admin", db_path=db_path)
        result = lock_dimension(created["id"], "readability", "isso",
                                "isso@mil", "CUI compliance", db_path=db_path)
        assert "lock_id" in result or "error" not in result

    def test_unlock(self, db_path, sample_guide_yaml):
        created = create_guide("tenant", "t1", "Unlockable", sample_guide_yaml,
                               "admin", db_path=db_path)
        lock_dimension(created["id"], "readability", "isso",
                       "isso@mil", db_path=db_path)
        result = unlock_dimension(created["id"], "readability",
                                  "isso@mil", "isso", db_path=db_path)
        assert "error" not in result or result.get("status") == "unlocked"


# ── history / diff_versions ────────────────────────────────────────


class TestHistoryAndDiff:

    def test_history_shows_versions(self, db_path, sample_guide_yaml):
        created = create_guide("tenant", "t1", "Hist", sample_guide_yaml,
                               "admin", db_path=db_path)
        update_guide(created["id"], yaml.dump({"readability": {"max_grade_level": 10}}),
                     "admin", "v2", db_path=db_path)
        result = history(created["id"], db_path=db_path)
        assert isinstance(result, list)
        assert len(result) >= 2

    def test_diff_two_versions(self, db_path, sample_guide_yaml):
        created = create_guide("tenant", "t1", "Diff", sample_guide_yaml,
                               "admin", db_path=db_path)
        update_guide(created["id"], yaml.dump({"readability": {"max_grade_level": 10}}),
                     "admin", "changed", db_path=db_path)
        result = diff_versions(created["id"], 1, 2, db_path=db_path)
        assert "v1" in result and "v2" in result

    def test_diff_nonexistent_version(self, db_path, sample_guide_yaml):
        created = create_guide("tenant", "t1", "DiffBad", sample_guide_yaml,
                               "admin", db_path=db_path)
        result = diff_versions(created["id"], 1, 99, db_path=db_path)
        assert "error" in result


# ── load_default_guides ────────────────────────────────────────────


class TestLoadDefaultGuides:

    def test_returns_dict(self):
        result = load_default_guides()
        assert isinstance(result, dict)

    def test_has_expected_guides(self):
        result = load_default_guides()
        expected = {"government", "technical", "proposal", "business", "academic"}
        # At least some of the expected guides should be present
        found = set(result.keys())
        assert len(found & expected) >= 3


# ── enforce_style ──────────────────────────────────────────────────


class TestEnforceStyle:

    def test_returns_expected_keys(self):
        guide = {"readability": {"max_grade_level": 14},
                 "sentences": {"max_words": 35, "max_passive_voice_pct": 20}}
        result = enforce_style("The cat sat on the mat.", guide)
        assert "findings" in result
        assert "compliance_score" in result
        assert "checks_passed" in result
        assert "checks_total" in result

    def test_empty_guide(self):
        result = enforce_style("Some text.", {})
        assert isinstance(result, dict)
        assert result["findings"] == [] or isinstance(result["findings"], list)

    def test_high_grade_text_flagged(self):
        guide = {"readability": {"max_grade_level": 8}}
        text = (
            "The implementation of sophisticated algorithmic methodologies "
            "necessitates comprehensive evaluation procedures."
        )
        result = enforce_style(text, guide)
        # Should have readability findings
        assert isinstance(result["findings"], list)

    def test_passive_voice_enforcement(self):
        guide = {"sentences": {"max_passive_voice_pct": 10}}
        text = "The report was written. The code was tested. The system was deployed."
        result = enforce_style(text, guide)
        assert isinstance(result["findings"], list)

    def test_compliance_score_range(self):
        guide = {"readability": {"max_grade_level": 14},
                 "sentences": {"max_words": 35}}
        result = enforce_style("Short text.", guide)
        assert 0 <= result["compliance_score"] <= 100
