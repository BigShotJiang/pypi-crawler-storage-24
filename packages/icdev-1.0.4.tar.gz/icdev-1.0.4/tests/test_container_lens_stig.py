#!/usr/bin/env python3
# CUI // SP-CTI
"""Tests for Phase 4 STIG checks (E-14..E-19, E-24..E-27)."""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tools.container_lens.utils.stig_checks import (
    check_audit_logging,
    check_log_forwarding_sidecar,
    check_mtls_configured,
    check_etcd_encryption,
    check_api_server_stig,
    check_kubelet_stig,
    check_pv_encryption,
    check_rbac_least_privilege,
    check_pss_enforced,
    check_runtime_monitoring,
)
from tools.container_lens.lenses.security_compliance import run_lens


# ===========================================================================
# Helper: write YAML manifests to temp dir
# ===========================================================================

def _write_manifest(tmp_path, filename, content):
    """Write a manifest file and return the directory."""
    m_dir = tmp_path / "k8s"
    m_dir.mkdir(exist_ok=True)
    (m_dir / filename).write_text(content, encoding="utf-8")
    return m_dir


# ===========================================================================
# E-14: Audit logging
# ===========================================================================

class TestAuditLogging:
    def test_no_log_forwarder(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "deploy.yaml", (
            "apiVersion: apps/v1\n"
            "kind: Deployment\n"
            "metadata:\n"
            "  name: app\n"
            "spec:\n"
            "  template:\n"
            "    spec:\n"
            "      containers:\n"
            "        - name: app\n"
            "          image: myapp:1.0\n"
        ))
        issues = check_audit_logging(m_dir)
        assert len(issues) >= 1

    def test_fluentbit_present(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "logging.yaml", (
            "apiVersion: apps/v1\n"
            "kind: DaemonSet\n"
            "metadata:\n"
            "  name: fluent-bit\n"
            "spec:\n"
            "  template:\n"
            "    spec:\n"
            "      containers:\n"
            "        - name: fluent-bit\n"
            "          image: fluent/fluent-bit:2.1\n"
        ))
        issues = check_audit_logging(m_dir)
        assert len(issues) == 0


# ===========================================================================
# E-15: Log forwarding sidecar
# ===========================================================================

class TestLogForwarding:
    def test_no_sidecar(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "deploy.yaml", (
            "apiVersion: apps/v1\n"
            "kind: Deployment\n"
            "metadata:\n"
            "  name: app\n"
            "spec:\n"
            "  template:\n"
            "    spec:\n"
            "      containers:\n"
            "        - name: app\n"
            "          image: myapp:1.0\n"
        ))
        issues = check_log_forwarding_sidecar(m_dir)
        assert len(issues) >= 1

    def test_no_dir(self):
        issues = check_log_forwarding_sidecar(None)
        assert len(issues) == 0


# ===========================================================================
# E-16: mTLS
# ===========================================================================

class TestMtls:
    def test_no_peer_auth(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "deploy.yaml", (
            "apiVersion: apps/v1\n"
            "kind: Deployment\n"
            "metadata:\n"
            "  name: app\n"
            "spec:\n"
            "  template:\n"
            "    spec:\n"
            "      containers:\n"
            "        - name: app\n"
            "          image: myapp:1.0\n"
        ))
        issues = check_mtls_configured(m_dir)
        assert len(issues) >= 1

    def test_strict_mtls(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "peer-auth.yaml", (
            "apiVersion: security.istio.io/v1beta1\n"
            "kind: PeerAuthentication\n"
            "metadata:\n"
            "  name: default\n"
            "  namespace: istio-system\n"
            "spec:\n"
            "  mtls:\n"
            "    mode: STRICT\n"
        ))
        issues = check_mtls_configured(m_dir)
        assert len(issues) == 0

    def test_permissive_mtls(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "peer-auth.yaml", (
            "apiVersion: security.istio.io/v1beta1\n"
            "kind: PeerAuthentication\n"
            "metadata:\n"
            "  name: default\n"
            "spec:\n"
            "  mtls:\n"
            "    mode: PERMISSIVE\n"
        ))
        issues = check_mtls_configured(m_dir)
        assert len(issues) >= 1


# ===========================================================================
# E-17: etcd encryption
# ===========================================================================

class TestEtcdEncryption:
    def test_no_encryption_config(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "deploy.yaml", (
            "apiVersion: apps/v1\n"
            "kind: Deployment\n"
            "metadata:\n"
            "  name: app\n"
            "spec:\n"
            "  template:\n"
            "    spec:\n"
            "      containers:\n"
            "        - name: app\n"
            "          image: myapp:1.0\n"
        ))
        issues = check_etcd_encryption(m_dir)
        assert len(issues) >= 1

    def test_encryption_config_present(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "enc.yaml", (
            "apiVersion: apiserver.config.k8s.io/v1\n"
            "kind: EncryptionConfiguration\n"
            "resources:\n"
            "  - resources:\n"
            "      - secrets\n"
            "    providers:\n"
            "      - aescbc:\n"
            "          keys:\n"
            "            - name: key1\n"
            "              secret: base64-encoded-key\n"
        ))
        issues = check_etcd_encryption(m_dir)
        assert len(issues) == 0


# ===========================================================================
# E-18: API server STIG
# ===========================================================================

class TestApiServerStig:
    def test_insecure_apiserver(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "apiserver.yaml", (
            "apiVersion: v1\n"
            "kind: Pod\n"
            "metadata:\n"
            "  name: kube-apiserver\n"
            "spec:\n"
            "  containers:\n"
            "    - name: kube-apiserver\n"
            "      image: k8s.gcr.io/kube-apiserver:v1.28\n"
            "      command:\n"
            "        - kube-apiserver\n"
            "        - --anonymous-auth=true\n"
            "        - --authorization-mode=AlwaysAllow\n"
        ))
        issues = check_api_server_stig(m_dir)
        assert len(issues) >= 2  # anon-auth + AlwaysAllow

    def test_secure_apiserver(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "apiserver.yaml", (
            "apiVersion: v1\n"
            "kind: Pod\n"
            "metadata:\n"
            "  name: kube-apiserver\n"
            "spec:\n"
            "  containers:\n"
            "    - name: kube-apiserver\n"
            "      image: k8s.gcr.io/kube-apiserver:v1.28\n"
            "      command:\n"
            "        - kube-apiserver\n"
            "        - --anonymous-auth=false\n"
            "        - --authorization-mode=RBAC,Node\n"
            "        - --audit-log-path=/var/log/audit.log\n"
            "        - --audit-log-maxage=30\n"
        ))
        issues = check_api_server_stig(m_dir)
        assert len(issues) == 0


# ===========================================================================
# E-19: Kubelet STIG
# ===========================================================================

class TestKubeletStig:
    def test_insecure_kubelet(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "kubelet.yaml", (
            "apiVersion: kubelet.config.k8s.io/v1beta1\n"
            "kind: KubeletConfiguration\n"
            "authentication:\n"
            "  anonymous:\n"
            "    enabled: true\n"
            "authorization:\n"
            "  mode: AlwaysAllow\n"
            "readOnlyPort: 10255\n"
        ))
        issues = check_kubelet_stig(m_dir)
        assert len(issues) >= 2

    def test_no_kubelet_config(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "deploy.yaml", (
            "apiVersion: apps/v1\n"
            "kind: Deployment\n"
            "metadata:\n"
            "  name: app\n"
        ))
        issues = check_kubelet_stig(m_dir)
        assert len(issues) == 0


# ===========================================================================
# E-24: PV encryption
# ===========================================================================

class TestPvEncryption:
    def test_unencrypted(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "sc.yaml", (
            "apiVersion: storage.k8s.io/v1\n"
            "kind: StorageClass\n"
            "metadata:\n"
            "  name: gp2\n"
            "provisioner: kubernetes.io/aws-ebs\n"
            "parameters:\n"
            "  type: gp2\n"
        ))
        issues = check_pv_encryption(m_dir)
        assert len(issues) >= 1

    def test_encrypted(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "sc.yaml", (
            "apiVersion: storage.k8s.io/v1\n"
            "kind: StorageClass\n"
            "metadata:\n"
            "  name: gp3-enc\n"
            "provisioner: ebs.csi.aws.com\n"
            "parameters:\n"
            "  type: gp3\n"
            "  encrypted: 'true'\n"
        ))
        issues = check_pv_encryption(m_dir)
        assert len(issues) == 0


# ===========================================================================
# E-25: RBAC
# ===========================================================================

class TestRbac:
    def test_cluster_admin_binding(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "rbac.yaml", (
            "apiVersion: rbac.authorization.k8s.io/v1\n"
            "kind: ClusterRoleBinding\n"
            "metadata:\n"
            "  name: admin-binding\n"
            "roleRef:\n"
            "  kind: ClusterRole\n"
            "  name: cluster-admin\n"
            "subjects:\n"
            "  - kind: User\n"
            "    name: dev-user\n"
        ))
        issues = check_rbac_least_privilege(m_dir)
        assert len(issues) >= 1

    def test_system_binding_allowed(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "rbac.yaml", (
            "apiVersion: rbac.authorization.k8s.io/v1\n"
            "kind: ClusterRoleBinding\n"
            "metadata:\n"
            "  name: system-binding\n"
            "roleRef:\n"
            "  kind: ClusterRole\n"
            "  name: cluster-admin\n"
            "subjects:\n"
            "  - kind: User\n"
            "    name: system:admin\n"
        ))
        issues = check_rbac_least_privilege(m_dir)
        assert len(issues) == 0


# ===========================================================================
# E-26: PSS
# ===========================================================================

class TestPss:
    def test_no_pss_label(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "ns.yaml", (
            "apiVersion: v1\n"
            "kind: Namespace\n"
            "metadata:\n"
            "  name: my-app\n"
        ))
        issues = check_pss_enforced(m_dir)
        assert len(issues) >= 1

    def test_pss_restricted(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "ns.yaml", (
            "apiVersion: v1\n"
            "kind: Namespace\n"
            "metadata:\n"
            "  name: my-app\n"
            "  labels:\n"
            "    pod-security.kubernetes.io/enforce: restricted\n"
        ))
        issues = check_pss_enforced(m_dir)
        assert len(issues) == 0


# ===========================================================================
# E-27: Runtime monitoring
# ===========================================================================

class TestRuntimeMonitoring:
    def test_no_falco(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "deploy.yaml", (
            "apiVersion: apps/v1\n"
            "kind: Deployment\n"
            "metadata:\n"
            "  name: app\n"
            "spec:\n"
            "  template:\n"
            "    spec:\n"
            "      containers:\n"
            "        - name: app\n"
            "          image: myapp:1.0\n"
        ))
        issues = check_runtime_monitoring(m_dir)
        assert len(issues) >= 1

    def test_falco_present(self, tmp_path):
        m_dir = _write_manifest(tmp_path, "falco.yaml", (
            "apiVersion: apps/v1\n"
            "kind: DaemonSet\n"
            "metadata:\n"
            "  name: falco\n"
            "spec:\n"
            "  template:\n"
            "    spec:\n"
            "      containers:\n"
            "        - name: falco\n"
            "          image: falcosecurity/falco:0.36\n"
        ))
        issues = check_runtime_monitoring(m_dir)
        assert len(issues) == 0


# ===========================================================================
# Integration: run_lens with Phase 4 checks
# ===========================================================================

class TestRunLensPhase4:
    def test_checks_count_27(self):
        config = {
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        assert result["lens_name"] == "security_compliance"
        assert result["checks_run"] == 27

    def test_dod_fips_checks_run(self):
        config = {
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "dod-il4",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        assert result["checks_run"] == 27

    def test_skip_phase4_checks(self):
        skip = {"E-11", "E-12", "E-13", "E-14", "E-15", "E-16", "E-17",
                "E-18", "E-19", "E-20", "E-21", "E-22", "E-23", "E-24",
                "E-25", "E-26", "E-27"}
        config = {
            "skip_checks": skip,
            "severity_overrides": {},
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        assert result["checks_run"] == 10  # Only Phase 3 checks
