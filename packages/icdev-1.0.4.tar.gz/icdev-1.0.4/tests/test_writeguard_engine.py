"""WriteGuard Analysis Engine tests (~30 tests)."""
from __future__ import annotations

import sqlite3

import pytest

from tools.writing.analysis_engine import analyze, get_result, get_stats, list_results


@pytest.fixture
def db_path(tmp_path):
    """Create a temporary database with all required wg tables."""
    path = tmp_path / "test_engine.db"
    conn = sqlite3.connect(str(path))
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS wg_analysis_results (
            id TEXT PRIMARY KEY,
            input_text_hash TEXT NOT NULL,
            input_length INTEGER NOT NULL DEFAULT 0,
            mode TEXT NOT NULL DEFAULT 'inline',
            readability_flesch REAL DEFAULT 0.0,
            readability_gunning_fog REAL DEFAULT 0.0,
            readability_grade_level REAL DEFAULT 0.0,
            grammar_error_count INTEGER DEFAULT 0,
            passive_voice_pct REAL DEFAULT 0.0,
            avg_sentence_length REAL DEFAULT 0.0,
            tone_profile TEXT DEFAULT '{}',
            coherence_score REAL DEFAULT 0.0,
            plagiarism_max_similarity REAL DEFAULT 0.0,
            ai_content_score REAL DEFAULT 0.0,
            overall_quality_score REAL DEFAULT 0.0,
            style_guide_id TEXT,
            section_id TEXT,
            opportunity_id TEXT,
            document_name TEXT DEFAULT '',
            findings_count INTEGER DEFAULT 0,
            analysis_duration_ms INTEGER DEFAULT 0,
            tenant_id TEXT DEFAULT '',
            project_id TEXT DEFAULT '',
            user_id TEXT DEFAULT '',
            classification TEXT NOT NULL DEFAULT 'CUI',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS wg_analysis_findings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            result_id TEXT NOT NULL,
            category TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'info',
            message TEXT NOT NULL,
            suggestion TEXT DEFAULT '',
            context TEXT DEFAULT '',
            line_number INTEGER DEFAULT 0,
            char_offset INTEGER DEFAULT 0,
            char_length INTEGER DEFAULT 0,
            rule_id TEXT DEFAULT '',
            confidence REAL DEFAULT 1.0,
            auto_fixable INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS wg_style_guides (
            id TEXT PRIMARY KEY,
            scope TEXT NOT NULL,
            scope_id TEXT NOT NULL,
            version INTEGER NOT NULL DEFAULT 1,
            guide_name TEXT NOT NULL,
            guide_yaml TEXT NOT NULL,
            inherits_from TEXT,
            created_by TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            is_active INTEGER DEFAULT 1,
            change_summary TEXT,
            classification TEXT DEFAULT 'CUI'
        );
        CREATE TABLE IF NOT EXISTS wg_style_guide_locks (
            id TEXT PRIMARY KEY,
            guide_id TEXT NOT NULL,
            dimension_path TEXT NOT NULL,
            lock_owner_role TEXT NOT NULL,
            locked_by TEXT NOT NULL,
            locked_at TEXT NOT NULL DEFAULT (datetime('now')),
            reason TEXT,
            is_active INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS wg_snippets (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            category TEXT NOT NULL,
            domain TEXT DEFAULT 'general',
            tags TEXT DEFAULT '[]',
            usage_count INTEGER DEFAULT 0,
            status TEXT DEFAULT 'active',
            tenant_id TEXT DEFAULT '',
            project_id TEXT DEFAULT '',
            created_by TEXT DEFAULT '',
            classification TEXT NOT NULL DEFAULT 'CUI',
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
    """)
    conn.close()
    return str(path)


# ── analyze ────────────────────────────────────────────────────────


class TestAnalyze:

    def test_returns_dict(self, db_path):
        result = analyze("The cat sat on the mat.", db_path=db_path)
        assert isinstance(result, dict)

    def test_has_result_id(self, db_path):
        result = analyze("Testing result ID.", db_path=db_path)
        assert "result_id" in result
        assert result["result_id"].startswith("wg-")

    def test_has_quality_score(self, db_path):
        result = analyze("Quality score test.", db_path=db_path)
        assert "quality_score" in result
        assert isinstance(result["quality_score"], (int, float))

    def test_has_readability(self, db_path):
        result = analyze("Readability metrics test.", db_path=db_path)
        assert "readability" in result
        assert isinstance(result["readability"], dict)

    def test_has_grammar(self, db_path):
        result = analyze("Grammar check test.", db_path=db_path)
        assert "grammar" in result

    def test_has_findings(self, db_path):
        result = analyze("Findings list check.", db_path=db_path)
        assert "findings" in result
        assert isinstance(result["findings"], list)

    def test_has_duration(self, db_path):
        result = analyze("Duration measurement.", db_path=db_path)
        assert "duration_ms" in result
        assert result["duration_ms"] >= 0

    def test_inline_mode(self, db_path):
        result = analyze("Inline mode test.", mode="inline", db_path=db_path)
        assert result["mode"] == "inline"

    def test_batch_mode(self, db_path):
        result = analyze("Batch mode test.", mode="batch", db_path=db_path)
        assert result["mode"] == "batch"

    def test_skip_llm(self, db_path):
        result = analyze("Skip LLM test.", skip_llm=True, db_path=db_path)
        assert isinstance(result, dict)

    def test_with_document_name(self, db_path):
        result = analyze("Named document.", document_name="test.txt",
                         db_path=db_path)
        assert isinstance(result, dict)

    def test_empty_text(self, db_path):
        result = analyze("", db_path=db_path)
        assert isinstance(result, dict)

    def test_long_text(self, db_path):
        text = "This is a test sentence. " * 100
        result = analyze(text, db_path=db_path)
        assert result["findings_count"] >= 0

    def test_findings_stored_in_db(self, db_path):
        result = analyze("Store findings test.", db_path=db_path)
        conn = sqlite3.connect(db_path)
        row = conn.execute(
            "SELECT id FROM wg_analysis_results WHERE id = ?",
            (result["result_id"],)
        ).fetchone()
        conn.close()
        assert row is not None

    def test_with_section_id(self, db_path):
        result = analyze("Section test.", section_id="sec-123", db_path=db_path)
        assert isinstance(result, dict)

    def test_with_opportunity_id(self, db_path):
        result = analyze("Opp test.", opportunity_id="opp-456", db_path=db_path)
        assert isinstance(result, dict)

    def test_quality_score_range(self, db_path):
        result = analyze("Good quality text that should score reasonably.",
                         db_path=db_path)
        assert 0 <= result["quality_score"] <= 100

    def test_has_passive_voice(self, db_path):
        result = analyze("The report was written by the team.", db_path=db_path)
        assert "passive_voice" in result

    def test_has_sentence_length(self, db_path):
        result = analyze("Short. Medium sentence here.", db_path=db_path)
        assert "sentence_length" in result

    def test_has_ai_detection(self, db_path):
        result = analyze("AI detection should run.", db_path=db_path)
        assert "ai_detection" in result


# ── get_result ─────────────────────────────────────────────────────


class TestGetResult:

    def test_get_existing(self, db_path):
        created = analyze("Retrievable result.", db_path=db_path)
        result = get_result(created["result_id"], db_path=db_path)
        assert isinstance(result, dict)
        assert "id" in result or "result_id" in result or "overall_quality_score" in result

    def test_get_nonexistent(self, db_path):
        result = get_result("nonexistent-id", db_path=db_path)
        assert result is None or "error" in result


# ── list_results ───────────────────────────────────────────────────


class TestListResults:

    def test_list_empty(self, db_path):
        result = list_results(db_path=db_path)
        assert isinstance(result, list)

    def test_list_after_analyze(self, db_path):
        analyze("First analysis.", db_path=db_path)
        analyze("Second analysis.", db_path=db_path)
        result = list_results(db_path=db_path)
        assert len(result) >= 2

    def test_list_with_limit(self, db_path):
        for i in range(5):
            analyze(f"Analysis number {i}.", db_path=db_path)
        result = list_results(limit=3, db_path=db_path)
        assert len(result) <= 3


# ── get_stats ──────────────────────────────────────────────────────


class TestGetStats:

    def test_returns_dict(self, db_path):
        result = get_stats(db_path=db_path)
        assert isinstance(result, dict)

    def test_has_expected_keys(self, db_path):
        analyze("Stats test.", db_path=db_path)
        result = get_stats(db_path=db_path)
        assert "total_analyses" in result
        assert "avg_quality_score" in result

    def test_stats_after_analyses(self, db_path):
        analyze("First.", db_path=db_path)
        analyze("Second.", db_path=db_path)
        result = get_stats(db_path=db_path)
        assert result["total_analyses"] >= 2
