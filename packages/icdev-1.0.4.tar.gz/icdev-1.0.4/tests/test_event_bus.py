# CUI // SP-CTI
"""Tests for tools.events.event_bus."""

import threading
import time

import pytest

from tools.events.event_bus import (
    DomainEvent,
    EventBus,
    bus,
    AGENT_STARTED,
    COMPLIANCE_GATE_PASSED,
    LLM_FALLBACK_TRIGGERED,
)


@pytest.fixture
def fresh_bus():
    """Return a fresh EventBus instance (not the module singleton)."""
    return EventBus()


class TestDomainEvent:
    def test_immutable(self):
        evt = DomainEvent(topic="test.topic", payload={"key": "val"})
        with pytest.raises(AttributeError):
            evt.topic = "other"  # type: ignore[misc]

    def test_auto_fields(self):
        evt = DomainEvent(topic="test.topic")
        assert evt.event_id.startswith("evt-")
        assert evt.timestamp > 0
        assert evt.payload == {}

    def test_to_dict(self):
        evt = DomainEvent(topic="a.b", payload={"x": 1}, source="test")
        d = evt.to_dict()
        assert d["topic"] == "a.b"
        assert d["payload"] == {"x": 1}
        assert d["source"] == "test"
        assert "event_id" in d
        assert "timestamp" in d


class TestEventBus:
    def test_subscribe_and_publish(self, fresh_bus):
        received = []
        fresh_bus.subscribe("my.topic", lambda e: received.append(e))
        evt = DomainEvent(topic="my.topic", payload={"n": 42})
        fresh_bus.publish(evt)
        assert len(received) == 1
        assert received[0].payload["n"] == 42

    def test_wildcard_handler(self, fresh_bus):
        received = []
        fresh_bus.subscribe("*", lambda e: received.append(e.topic))
        fresh_bus.publish(DomainEvent(topic="a"))
        fresh_bus.publish(DomainEvent(topic="b"))
        assert received == ["a", "b"]

    def test_topic_isolation(self, fresh_bus):
        received = []
        fresh_bus.subscribe("yes", lambda e: received.append(True))
        fresh_bus.publish(DomainEvent(topic="no"))
        assert received == []

    def test_handler_exception_does_not_propagate(self, fresh_bus):
        def bad_handler(e):
            raise ValueError("boom")

        ok_received = []
        fresh_bus.subscribe("t", bad_handler)
        fresh_bus.subscribe("t", lambda e: ok_received.append(True))
        fresh_bus.publish(DomainEvent(topic="t"))
        # Second handler still runs
        assert ok_received == [True]

    def test_unsubscribe(self, fresh_bus):
        received = []
        handler = lambda e: received.append(True)
        fresh_bus.subscribe("t", handler)
        fresh_bus.unsubscribe("t", handler)
        fresh_bus.publish(DomainEvent(topic="t"))
        assert received == []

    def test_recent_events(self, fresh_bus):
        for i in range(5):
            fresh_bus.publish(DomainEvent(topic=f"t{i}"))
        recent = fresh_bus.recent_events(limit=3)
        assert len(recent) == 3
        # Newest first
        assert recent[0]["topic"] == "t4"

    def test_recent_events_filtered(self, fresh_bus):
        fresh_bus.publish(DomainEvent(topic="a"))
        fresh_bus.publish(DomainEvent(topic="b"))
        fresh_bus.publish(DomainEvent(topic="a"))
        filtered = fresh_bus.recent_events(topic="a")
        assert len(filtered) == 2

    def test_registered_topics(self, fresh_bus):
        fresh_bus.subscribe("x", lambda e: None)
        fresh_bus.subscribe("y", lambda e: None)
        topics = fresh_bus.registered_topics()
        assert "x" in topics
        assert "y" in topics

    def test_handler_count(self, fresh_bus):
        fresh_bus.subscribe("t", lambda e: None)
        fresh_bus.subscribe("t", lambda e: None)
        assert fresh_bus.handler_count("t") == 2
        assert fresh_bus.handler_count("z") == 0

    def test_reset(self, fresh_bus):
        fresh_bus.subscribe("t", lambda e: None)
        fresh_bus.publish(DomainEvent(topic="t"))
        fresh_bus.reset()
        assert fresh_bus.registered_topics() == []
        assert fresh_bus.recent_events() == []

    def test_thread_safety(self, fresh_bus):
        received = []
        fresh_bus.subscribe("t", lambda e: received.append(1))

        def publisher():
            for _ in range(100):
                fresh_bus.publish(DomainEvent(topic="t"))

        threads = [threading.Thread(target=publisher) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert len(received) == 400

    def test_rolling_log_limit(self, fresh_bus):
        fresh_bus._log_limit = 10
        for i in range(20):
            fresh_bus.publish(DomainEvent(topic="t"))
        assert len(fresh_bus._event_log) == 10


class TestModuleSingleton:
    def test_bus_is_singleton(self):
        assert isinstance(bus, EventBus)

    def test_well_known_topics_are_strings(self):
        assert AGENT_STARTED == "agent.started"
        assert COMPLIANCE_GATE_PASSED == "compliance.gate_passed"
        assert LLM_FALLBACK_TRIGGERED == "llm.fallback_triggered"
