# CUI // SP-CTI
"""Tests for runbook engine — CRUD, execution, template loading."""

import json
import os
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from tools.cloudforge.runbooks.models import (
    ExecutionResult,
    RunbookEdge,
    RunbookTask,
    TaskResult,
    edges_from_json,
    edges_to_json,
    tasks_from_json,
    tasks_to_json,
)


# ─── MODEL TESTS ─────────────────────────────────────────────────────────────


class TestModels:
    def test_task_roundtrip(self):
        task = RunbookTask(id="t1", name="Check health", action="http_check",
                           parameters={"url": "http://localhost"})
        d = task.to_dict()
        assert d["id"] == "t1"
        assert d["action"] == "http_check"
        task2 = RunbookTask.from_dict(d)
        assert task2.id == task.id
        assert task2.parameters == task.parameters

    def test_edge_roundtrip(self):
        edge = RunbookEdge(source="t1", target="t2", label="then")
        d = edge.to_dict()
        edge2 = RunbookEdge.from_dict(d)
        assert edge2.source == "t1"
        assert edge2.target == "t2"

    def test_tasks_json_roundtrip(self):
        tasks = [
            RunbookTask(id="t1", name="A", action="noop"),
            RunbookTask(id="t2", name="B", action="http_check"),
        ]
        j = tasks_to_json(tasks)
        parsed = tasks_from_json(j)
        assert len(parsed) == 2
        assert parsed[0].id == "t1"
        assert parsed[1].action == "http_check"

    def test_edges_json_roundtrip(self):
        edges = [RunbookEdge(source="t1", target="t2")]
        j = edges_to_json(edges)
        parsed = edges_from_json(j)
        assert len(parsed) == 1
        assert parsed[0].source == "t1"

    def test_task_result_to_dict(self):
        tr = TaskResult(task_id="t1", task_name="A", action="completed",
                        output={"key": "val"}, duration_ms=100)
        d = tr.to_dict()
        assert d["duration_ms"] == 100

    def test_execution_result_to_dict(self):
        er = ExecutionResult(
            execution_id="rex-001", runbook_id="rb-001",
            status="completed", tasks_completed=2, tasks_total=2,
            task_results=[
                TaskResult(task_id="t1", task_name="A", action="completed"),
            ],
        )
        d = er.to_dict()
        assert d["status"] == "completed"
        assert len(d["task_results"]) == 1

    def test_from_dict_ignores_extra_fields(self):
        d = {"id": "t1", "name": "A", "action": "noop", "extra_field": "ignored"}
        task = RunbookTask.from_dict(d)
        assert task.id == "t1"
        assert not hasattr(task, "extra_field") or "extra_field" not in task.__dataclass_fields__


# ─── ENGINE TESTS (with temp DB) ─────────────────────────────────────────────


@pytest.fixture
def temp_db(tmp_path):
    """Create a temporary DB with runbook tables."""
    db_path = tmp_path / "test_icdev.db"
    conn = sqlite3.connect(str(db_path))
    # Create all 6 tables
    conn.executescript("""
        CREATE TABLE cf_runbooks (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            version INTEGER NOT NULL DEFAULT 1,
            status TEXT DEFAULT 'draft',
            template_source TEXT,
            tasks_json TEXT NOT NULL,
            edges_json TEXT NOT NULL,
            snippets_used TEXT,
            estimated_duration_minutes INTEGER,
            owner TEXT,
            tags TEXT,
            classification TEXT DEFAULT 'CUI // SP-CTI',
            tenant_id TEXT NOT NULL DEFAULT 'default',
            project_id TEXT,
            created_by TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            UNIQUE(tenant_id, name, version)
        );
        CREATE TABLE cf_runbook_executions (
            id TEXT PRIMARY KEY,
            runbook_id TEXT NOT NULL,
            runbook_version INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',
            trigger_type TEXT DEFAULT 'manual',
            triggered_by TEXT,
            started_at TEXT,
            completed_at TEXT,
            duration_ms INTEGER,
            task_results_json TEXT,
            parallel_paths_count INTEGER DEFAULT 0,
            tasks_completed INTEGER DEFAULT 0,
            tasks_failed INTEGER DEFAULT 0,
            tasks_skipped INTEGER DEFAULT 0,
            tasks_total INTEGER DEFAULT 0,
            error_summary TEXT,
            classification TEXT DEFAULT 'CUI // SP-CTI',
            tenant_id TEXT NOT NULL DEFAULT 'default',
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE cf_runbook_task_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            execution_id TEXT NOT NULL,
            task_id TEXT NOT NULL,
            task_name TEXT NOT NULL,
            action TEXT NOT NULL,
            output_json TEXT,
            error_details TEXT,
            duration_ms INTEGER,
            actor TEXT DEFAULT 'cloudforge',
            classification TEXT DEFAULT 'CUI // SP-CTI',
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE cf_runbook_snippets (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            category TEXT NOT NULL,
            tasks_json TEXT NOT NULL,
            edges_json TEXT NOT NULL,
            usage_count INTEGER DEFAULT 0,
            classification TEXT DEFAULT 'CUI // SP-CTI',
            tenant_id TEXT NOT NULL DEFAULT 'default',
            created_by TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            UNIQUE(tenant_id, name)
        );
    """)
    conn.commit()
    conn.close()
    return db_path


@pytest.fixture
def patched_engine(temp_db):
    """Patch engine.DB_PATH to use temp DB."""
    with patch("tools.cloudforge.runbooks.engine.DB_PATH", temp_db):
        from tools.cloudforge.runbooks import engine
        yield engine


class TestEngineCreateAndList:
    def test_create_runbook(self, patched_engine):
        result = patched_engine.create_runbook(
            name="Test Runbook",
            tasks=[{"id": "t1", "name": "Step 1", "action": "noop"}],
            edges=[],
        )
        assert result["status"] == "ok"
        assert result["id"].startswith("rb-")
        assert result["tasks_count"] == 1

    def test_create_invalid_dag(self, patched_engine):
        result = patched_engine.create_runbook(
            name="Bad Runbook",
            tasks=[{"id": "t1", "name": "A", "action": "noop"},
                   {"id": "t2", "name": "B", "action": "noop"}],
            edges=[{"source": "t1", "target": "t2"},
                   {"source": "t2", "target": "t1"}],
        )
        assert result["status"] == "error"
        assert any("cycle" in e.lower() for e in result["errors"])

    def test_list_runbooks_empty(self, patched_engine):
        results = patched_engine.list_runbooks()
        assert results == []

    def test_list_after_create(self, patched_engine):
        patched_engine.create_runbook(
            name="RB1",
            tasks=[{"id": "t1", "name": "A", "action": "noop"}],
            edges=[],
        )
        results = patched_engine.list_runbooks()
        assert len(results) == 1
        assert results[0]["name"] == "RB1"

    def test_get_runbook(self, patched_engine):
        res = patched_engine.create_runbook(
            name="RB Get",
            tasks=[{"id": "t1", "name": "A", "action": "noop"}],
            edges=[],
        )
        rb = patched_engine.get_runbook(res["id"])
        assert rb is not None
        assert rb["name"] == "RB Get"
        assert len(rb["tasks"]) == 1

    def test_get_nonexistent(self, patched_engine):
        assert patched_engine.get_runbook("rb-nonexistent") is None


class TestEngineExecution:
    def test_execute_simple_runbook(self, patched_engine):
        res = patched_engine.create_runbook(
            name="Simple",
            tasks=[
                {"id": "t1", "name": "Step1", "action": "noop"},
                {"id": "t2", "name": "Step2", "action": "noop"},
            ],
            edges=[{"source": "t1", "target": "t2"}],
        )
        exec_result = patched_engine.execute_runbook(res["id"])
        assert exec_result.status == "completed"
        assert exec_result.tasks_completed == 2
        assert exec_result.tasks_failed == 0
        assert exec_result.execution_id.startswith("rex-")

    def test_execute_nonexistent_runbook(self, patched_engine):
        exec_result = patched_engine.execute_runbook("rb-missing")
        assert exec_result.status == "failed"
        assert "not found" in exec_result.error_summary.lower()

    def test_execute_with_condition_skip(self, patched_engine):
        res = patched_engine.create_runbook(
            name="Conditional",
            tasks=[
                {"id": "t1", "name": "Always", "action": "noop"},
                {"id": "t2", "name": "Conditional", "action": "noop",
                 "condition": {"key": "env", "operator": "eq", "value": "prod"}},
            ],
            edges=[{"source": "t1", "target": "t2"}],
        )
        # env=dev means t2 should be skipped
        exec_result = patched_engine.execute_runbook(res["id"], context={"env": "dev"})
        assert exec_result.status == "completed"
        assert exec_result.tasks_completed == 1
        assert exec_result.tasks_skipped == 1

    def test_execution_history(self, patched_engine):
        res = patched_engine.create_runbook(
            name="History",
            tasks=[{"id": "t1", "name": "A", "action": "noop"}],
            edges=[],
        )
        patched_engine.execute_runbook(res["id"])
        patched_engine.execute_runbook(res["id"])
        execs = patched_engine.list_executions(res["id"])
        assert len(execs) == 2

    def test_get_execution_detail(self, patched_engine):
        res = patched_engine.create_runbook(
            name="Detail",
            tasks=[{"id": "t1", "name": "A", "action": "noop"}],
            edges=[],
        )
        exec_result = patched_engine.execute_runbook(res["id"])
        detail = patched_engine.get_execution(exec_result.execution_id)
        assert detail is not None
        assert detail["status"] == "completed"
        assert len(detail["task_log"]) >= 2  # started + completed

    def test_publish_runbook(self, patched_engine):
        res = patched_engine.create_runbook(
            name="Pub",
            tasks=[{"id": "t1", "name": "A", "action": "noop"}],
            edges=[],
        )
        pub = patched_engine.publish_runbook(res["id"])
        assert pub["new_status"] == "published"
        rb = patched_engine.get_runbook(res["id"])
        assert rb["status"] == "published"


# ─── TEMPLATE LOADER TESTS ──────────────────────────────────────────────────


class TestTemplateLoader:
    def test_list_templates(self):
        from tools.cloudforge.runbooks.template_loader import list_templates
        templates = list_templates()
        assert len(templates) >= 3
        names = [t["name"] for t in templates]
        assert "dr_failover" in names
        assert "health_check" in names
        assert "backup_verify" in names

    def test_load_template(self):
        from tools.cloudforge.runbooks.template_loader import load_template
        tmpl = load_template("dr_failover")
        assert tmpl is not None
        assert "tasks" in tmpl
        assert len(tmpl["tasks"]) >= 5
        assert "edges" in tmpl
        assert len(tmpl["edges"]) >= 5

    def test_load_nonexistent(self):
        from tools.cloudforge.runbooks.template_loader import load_template
        assert load_template("nonexistent_template") is None

    def test_instantiate_template(self):
        from tools.cloudforge.runbooks.template_loader import instantiate_template
        result = instantiate_template("dr_failover", overrides={"primary_zone_id": "lz-001"})
        assert result is not None
        assert result["template_source"] == "dr_failover"
        assert len(result["tasks"]) >= 5
