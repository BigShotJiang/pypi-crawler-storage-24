#!/usr/bin/env python3
# CUI // SP-CTI
"""Tests for CodeLens/Pro Lens G: Database Compatibility.

Covers migration_parser utilities and all 10 G-checks.
"""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from tools.container_lens.utils.migration_parser import (
    SQLITE_SYNTAX_PATTERNS,
    check_advisory_lock,
    check_pgbouncer_bypass,
    check_rollback_quality,
    check_ssl_config,
    discover_migrations,
    extract_pg_versions,
    scan_sqlite_syntax,
)
from tools.container_lens.lenses.database_compat import run_lens


# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------

def _create_migration_dir(root, name, up_content="", down_content="",
                          up_ext=".py", down_ext=".py", meta=None):
    """Create a migration directory with up/down files."""
    mig_dir = root / "tools" / "db" / "migrations" / name
    mig_dir.mkdir(parents=True, exist_ok=True)
    (mig_dir / "__init__.py").touch()

    if up_content:
        (mig_dir / f"up{up_ext}").write_text(up_content, encoding="utf-8")
    if down_content:
        (mig_dir / f"down{down_ext}").write_text(down_content, encoding="utf-8")
    if meta:
        (mig_dir / "meta.json").write_text(
            json.dumps(meta), encoding="utf-8"
        )
    return mig_dir


# ---------------------------------------------------------------------------
# Migration parser tests
# ---------------------------------------------------------------------------

class TestSqliteSyntaxScan(unittest.TestCase):
    """Test scan_sqlite_syntax detection."""

    def test_insert_or_replace(self):
        with tempfile.NamedTemporaryFile(suffix=".py", mode="w",
                                         delete=False, encoding="utf-8") as f:
            f.write('conn.execute("INSERT OR REPLACE INTO t VALUES (1)")\n')
            f.flush()
            findings = scan_sqlite_syntax(f.name)
        os.unlink(f.name)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["pattern"], "INSERT OR REPLACE")

    def test_insert_or_ignore(self):
        with tempfile.NamedTemporaryFile(suffix=".sql", mode="w",
                                         delete=False, encoding="utf-8") as f:
            f.write("INSERT OR IGNORE INTO config (k, v) VALUES ('a', 'b');\n")
            f.flush()
            findings = scan_sqlite_syntax(f.name)
        os.unlink(f.name)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["pattern"], "INSERT OR IGNORE")

    def test_datetime_now(self):
        with tempfile.NamedTemporaryFile(suffix=".sql", mode="w",
                                         delete=False, encoding="utf-8") as f:
            f.write("created_at TEXT DEFAULT (datetime('now')),\n")
            f.flush()
            findings = scan_sqlite_syntax(f.name)
        os.unlink(f.name)
        self.assertEqual(len(findings), 1)
        self.assertIn("datetime", findings[0]["pattern"])

    def test_bare_placeholder(self):
        with tempfile.NamedTemporaryFile(suffix=".py", mode="w",
                                         delete=False, encoding="utf-8") as f:
            f.write('conn.execute("SELECT * FROM t WHERE id = ?", (pid,))\n')
            f.flush()
            findings = scan_sqlite_syntax(f.name)
        os.unlink(f.name)
        placeholders = [f for f in findings if f["pattern"] == "? placeholder"]
        self.assertEqual(len(placeholders), 1)

    def test_clean_file(self):
        with tempfile.NamedTemporaryFile(suffix=".py", mode="w",
                                         delete=False, encoding="utf-8") as f:
            f.write('conn.execute("INSERT INTO t (a) VALUES (%s)", (1,))\n')
            f.flush()
            findings = scan_sqlite_syntax(f.name)
        os.unlink(f.name)
        self.assertEqual(len(findings), 0)

    def test_comment_skipped(self):
        with tempfile.NamedTemporaryFile(suffix=".sql", mode="w",
                                         delete=False, encoding="utf-8") as f:
            f.write("-- INSERT OR REPLACE is not supported\n")
            f.flush()
            findings = scan_sqlite_syntax(f.name)
        os.unlink(f.name)
        self.assertEqual(len(findings), 0)

    def test_group_concat(self):
        with tempfile.NamedTemporaryFile(suffix=".sql", mode="w",
                                         delete=False, encoding="utf-8") as f:
            f.write("SELECT GROUP_CONCAT(name, ',') FROM tags;\n")
            f.flush()
            findings = scan_sqlite_syntax(f.name)
        os.unlink(f.name)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["pattern"], "GROUP_CONCAT()")


class TestDiscoverMigrations(unittest.TestCase):
    """Test migration discovery."""

    def test_icdev_pattern(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            _create_migration_dir(
                root, "001_baseline",
                up_content="def up(conn): pass\n",
                down_content="def down(conn): pass\n",
            )
            migrations = discover_migrations(td)
            self.assertEqual(len(migrations), 1)
            self.assertEqual(migrations[0]["name"], "001_baseline")
            self.assertTrue(migrations[0]["has_up"])

    def test_no_migrations(self):
        with tempfile.TemporaryDirectory() as td:
            migrations = discover_migrations(td)
            self.assertEqual(len(migrations), 0)


class TestRollbackQuality(unittest.TestCase):
    """Test rollback validation."""

    def test_no_down_file(self):
        mig = {"name": "001", "path": "/tmp/001", "has_down": False,
               "down_files": []}
        result = check_rollback_quality(mig)
        self.assertIsNotNone(result)
        self.assertIn("No rollback", result)

    def test_pass_only_down(self):
        with tempfile.NamedTemporaryFile(suffix=".py", mode="w",
                                         delete=False, encoding="utf-8") as f:
            f.write("def down(conn):\n    pass\n")
            f.flush()
            mig = {"name": "001", "path": "/tmp/001", "has_down": True,
                   "down_files": [f.name]}
            result = check_rollback_quality(mig)
        os.unlink(f.name)
        self.assertIsNotNone(result)
        self.assertIn("pass", result)

    def test_real_rollback(self):
        with tempfile.NamedTemporaryFile(suffix=".py", mode="w",
                                         delete=False, encoding="utf-8") as f:
            f.write('def down(conn):\n    conn.execute("DROP TABLE t")\n')
            f.flush()
            mig = {"name": "001", "path": "/tmp/001", "has_down": True,
                   "down_files": [f.name]}
            result = check_rollback_quality(mig)
        os.unlink(f.name)
        self.assertIsNone(result)


class TestPgVersionExtraction(unittest.TestCase):
    """Test PG version extraction."""

    def test_k8s_manifest(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            k8s = root / "k8s"
            k8s.mkdir()
            (k8s / "db.yaml").write_text(
                "image: postgres:15-alpine\n", encoding="utf-8"
            )
            versions = extract_pg_versions(td)
            self.assertEqual(versions["k8s"], "15")

    def test_docker_compose(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "docker-compose.yml").write_text(
                "services:\n  db:\n    image: postgres:16.2\n",
                encoding="utf-8",
            )
            versions = extract_pg_versions(td)
            self.assertEqual(versions["docker_compose"], "16.2")


class TestAdvisoryLock(unittest.TestCase):
    """Test advisory lock detection."""

    def test_has_lock(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            db_dir = root / "tools" / "db"
            db_dir.mkdir(parents=True)
            (db_dir / "migrate.py").write_text(
                "conn.execute('SELECT pg_try_advisory_lock(12345)')\n",
                encoding="utf-8",
            )
            self.assertTrue(check_advisory_lock(td))

    def test_no_lock(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            db_dir = root / "tools" / "db"
            db_dir.mkdir(parents=True)
            (db_dir / "migrate.py").write_text(
                "def run(): pass\n", encoding="utf-8",
            )
            self.assertFalse(check_advisory_lock(td))


class TestSslConfig(unittest.TestCase):
    """Test SSL configuration check."""

    def test_has_ssl(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            args = root / "args"
            args.mkdir()
            (args / "storage_config.yaml").write_text(
                'connection_string: "host=db sslmode=verify-full"\n',
                encoding="utf-8",
            )
            result = check_ssl_config(td)
            self.assertTrue(result["has_ssl"])

    def test_no_ssl(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            args = root / "args"
            args.mkdir()
            (args / "storage_config.yaml").write_text(
                'connection_string: "host=db port=5432"\n',
                encoding="utf-8",
            )
            result = check_ssl_config(td)
            self.assertFalse(result["has_ssl"])
            self.assertTrue(len(result["issues"]) > 0)


# ---------------------------------------------------------------------------
# Lens G integration tests
# ---------------------------------------------------------------------------

class TestRunLens(unittest.TestCase):
    """Test run_lens integration."""

    def test_clean_project(self):
        """A project with no migrations should pass cleanly."""
        with tempfile.TemporaryDirectory() as td:
            config = {
                "project_dir": td,
                "profile_name": "commercial",
                "skip_checks": set(),
                "severity_overrides": {},
            }
            result = run_lens(config)
            self.assertEqual(result["lens_name"], "database_compat")
            self.assertGreater(result["checks_run"], 0)
            self.assertGreaterEqual(result["score"], 0)

    def test_sqlite_leak_detected(self):
        """Migrations with SQLite syntax should produce findings."""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            _create_migration_dir(
                root, "001_test",
                up_content=(
                    'def up(conn):\n'
                    '    conn.execute("INSERT OR REPLACE INTO t VALUES (1)")\n'
                ),
            )
            config = {
                "project_dir": td,
                "profile_name": "commercial",
                "skip_checks": set(),
                "severity_overrides": {},
            }
            result = run_lens(config)
            g02 = [f for f in result["findings"] if f["check_id"] == "G-02"]
            self.assertTrue(len(g02) > 0)

    def test_severity_override(self):
        """Severity overrides should be applied."""
        with tempfile.TemporaryDirectory() as td:
            config = {
                "project_dir": td,
                "profile_name": "commercial",
                "skip_checks": set(),
                "severity_overrides": {"G-03": "BLOCK"},
            }
            result = run_lens(config)
            g03 = [f for f in result["findings"] if f["check_id"] == "G-03"]
            for f in g03:
                self.assertEqual(f["severity"], "BLOCK")

    def test_skip_checks(self):
        """Skipped checks should not run."""
        with tempfile.TemporaryDirectory() as td:
            config = {
                "project_dir": td,
                "profile_name": "commercial",
                "skip_checks": {"G-01", "G-02", "G-03", "G-04", "G-05",
                                "G-06", "G-07", "G-08", "G-09", "G-10"},
                "severity_overrides": {},
            }
            result = run_lens(config)
            self.assertEqual(result["checks_run"], 0)
            self.assertEqual(result["score"], 100.0)

    def test_dod_profile_blocks(self):
        """DoD profile should escalate G-02 to BLOCK."""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            _create_migration_dir(
                root, "001_test",
                up_content=(
                    'def up(conn):\n'
                    '    conn.execute("INSERT OR REPLACE INTO t VALUES (1)")\n'
                ),
            )
            config = {
                "project_dir": td,
                "profile_name": "dod-il4",
                "skip_checks": set(),
                "severity_overrides": {},
            }
            result = run_lens(config)
            g02 = [f for f in result["findings"] if f["check_id"] == "G-02"]
            self.assertTrue(any(f["severity"] == "BLOCK" for f in g02))


class TestRunLensRealProject(unittest.TestCase):
    """Test run_lens against the real ICDEV project."""

    def test_real_project(self):
        """Run against actual ICDEV project dir."""
        config = {
            "project_dir": str(BASE_DIR),
            "profile_name": "commercial",
            "skip_checks": set(),
            "severity_overrides": {},
        }
        result = run_lens(config)
        self.assertEqual(result["lens_name"], "database_compat")
        self.assertGreater(result["checks_run"], 0)
        # Should produce some findings (init scripts + migrations coexist)
        self.assertIsInstance(result["findings"], list)
        # Score should be reasonable
        self.assertGreaterEqual(result["score"], 0)


if __name__ == "__main__":
    unittest.main()
