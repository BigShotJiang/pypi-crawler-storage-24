#!/usr/bin/env python3
# CUI // SP-CTI
"""Unit tests for CodeLens/Pro Lens B: Dockerfile Lint."""

import sys
import pytest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tools.container_lens.lenses.dockerfile_lint import run_lens


def _make_config(tmp_path, dockerfile_content, skip=None, overrides=None):
    """Helper to create a lens config dict."""
    df = tmp_path / "Dockerfile"
    df.write_text(dockerfile_content, encoding="utf-8")
    return {
        "project_dir": tmp_path,
        "dockerfile": df,
        "skip_checks": set(skip or []),
        "severity_overrides": overrides or {},
    }


def _find(findings, check_id):
    return [f for f in findings if f["check_id"] == check_id]


# ---- B-02: pip --no-cache-dir ----

class TestB02PipCache:
    def test_detects_missing_no_cache_dir(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nRUN pip install flask\n"))
        matches = _find(result["findings"], "B-02")
        assert len(matches) >= 1

    def test_passes_with_no_cache_dir(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nRUN pip install --no-cache-dir flask\n"))
        assert not _find(result["findings"], "B-02")


# ---- B-04: Cache-busting COPY ----

class TestB04CacheBust:
    def test_detects_copy_before_pip(self, tmp_path):
        result = run_lens(_make_config(tmp_path, (
            "FROM python:3.12-slim\n"
            "COPY . /app/\n"
            "RUN pip install -r /app/requirements.txt\n"
        )))
        matches = _find(result["findings"], "B-04")
        assert len(matches) >= 1

    def test_passes_correct_order(self, tmp_path):
        result = run_lens(_make_config(tmp_path, (
            "FROM python:3.12-slim\n"
            "COPY requirements.txt /app/\n"
            "RUN pip install -r /app/requirements.txt\n"
            "COPY . /app/\n"
        )))
        assert not _find(result["findings"], "B-04")


# ---- B-05: Non-root USER ----

class TestB05User:
    def test_detects_no_user(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nRUN echo hi\n"))
        matches = _find(result["findings"], "B-05")
        assert len(matches) == 1
        assert matches[0]["severity"] == "BLOCK"

    def test_detects_root_user(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nUSER root\nRUN echo hi\n"))
        matches = _find(result["findings"], "B-05")
        assert len(matches) == 1

    def test_passes_nonroot_user(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nUSER 1000\nRUN echo hi\n"))
        assert not _find(result["findings"], "B-05")

    def test_passes_named_user(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nUSER appuser\nRUN echo hi\n"))
        assert not _find(result["findings"], "B-05")


# ---- B-09: HEALTHCHECK ----

class TestB09Healthcheck:
    def test_detects_missing_healthcheck(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nUSER 1000\nCMD python app.py\n"))
        matches = _find(result["findings"], "B-09")
        assert len(matches) == 1

    def test_passes_with_healthcheck(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nUSER 1000\n"
            "HEALTHCHECK --interval=30s CMD curl -f http://localhost:8080/health\n"))
        assert not _find(result["findings"], "B-09")


# ---- B-10: ARG in CMD/ENTRYPOINT ----

class TestB10ArgRuntime:
    def test_detects_arg_in_cmd(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nARG APP_PORT\nUSER 1000\n"
            "CMD python app.py --port $APP_PORT\n"))
        matches = _find(result["findings"], "B-10")
        assert len(matches) >= 1

    def test_passes_env_in_cmd(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nENV APP_PORT=8080\nUSER 1000\n"
            "CMD python app.py --port $APP_PORT\n"))
        assert not _find(result["findings"], "B-10")


# ---- B-14: Missing locale ----

class TestB14Locale:
    def test_detects_missing_lang(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nUSER 1000\n"))
        matches = _find(result["findings"], "B-14")
        assert len(matches) == 1

    def test_passes_with_lang(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nENV LANG=C.UTF-8\nUSER 1000\n"))
        assert not _find(result["findings"], "B-14")


# ---- B-18: Floating pip versions ----

class TestB18FloatingPip:
    def test_detects_floating(self, tmp_path):
        req = tmp_path / "requirements.txt"
        req.write_text("flask>=2.0\nrequests\n", encoding="utf-8")
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nRUN pip install -r requirements.txt\nUSER 1000\n"))
        matches = _find(result["findings"], "B-18")
        assert len(matches) >= 1

    def test_passes_pinned(self, tmp_path):
        req = tmp_path / "requirements.txt"
        req.write_text("flask==3.0.2\nrequests==2.31.0\n", encoding="utf-8")
        result = run_lens(_make_config(tmp_path,
            "FROM python:3.12-slim\nRUN pip install -r requirements.txt\nUSER 1000\n"))
        assert not _find(result["findings"], "B-18")


# ---- B-19: npm install vs npm ci ----

class TestB19NpmCi:
    def test_detects_npm_install(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM node:20-slim\nRUN npm install\nUSER 1000\n"))
        matches = _find(result["findings"], "B-19")
        assert len(matches) >= 1

    def test_passes_npm_ci(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM node:20-slim\nRUN npm ci\nUSER 1000\n"))
        assert not _find(result["findings"], "B-19")


# ---- B-20: Non-FIPS base image ----

class TestB20Fips:
    def test_detects_alpine(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM alpine:3.19\nUSER 1000\n"))
        matches = _find(result["findings"], "B-20")
        assert len(matches) >= 1

    def test_passes_ubi(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM registry.access.redhat.com/ubi9/python-312:latest\nUSER 1000\n"))
        assert not _find(result["findings"], "B-20")

    def test_dod_il4_upgrades_to_block(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM alpine:3.19\nUSER 1000\n",
            overrides={"B-20": "BLOCK"}))
        matches = _find(result["findings"], "B-20")
        assert len(matches) >= 1
        assert matches[0]["severity"] == "BLOCK"


# ---- Result structure ----

class TestResultStructure:
    def test_lens_name(self, tmp_path):
        result = run_lens(_make_config(tmp_path, "FROM python:3.12-slim\nUSER 1000\n"))
        assert result["lens_name"] == "dockerfile_lint"

    def test_no_dockerfile_returns_empty(self, tmp_path):
        result = run_lens({
            "project_dir": tmp_path,
            "dockerfile": None,
            "skip_checks": set(),
            "severity_overrides": {},
        })
        assert result["checks_run"] == 0
        assert result["score"] == 100.0

    def test_all_findings_have_required_fields(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            "FROM python\nRUN pip install flask\nCOPY . /app/\n"))
        for f in result["findings"]:
            assert "check_id" in f
            assert "severity" in f
            assert f["severity"] in ("BLOCK", "WARN", "INFO")
            assert "category" in f
            assert f["category"] == "dockerfile_lint"
            assert "title" in f
            assert "nist_controls" in f
