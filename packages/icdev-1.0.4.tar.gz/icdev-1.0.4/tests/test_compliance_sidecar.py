# CUI // SP-CTI
"""Tests for tools.core.compliance_sidecar."""

import pytest

from tools.core.compliance_sidecar import compliance_sidecar, DEFAULT_MARKING


class TestComplianceSidecar:
    def test_injects_classification_into_dict(self):
        @compliance_sidecar
        def my_tool():
            return {"data": "value"}

        result = my_tool()
        assert result["classification"] == DEFAULT_MARKING
        assert result["data"] == "value"

    def test_does_not_overwrite_existing_classification(self):
        @compliance_sidecar
        def my_tool():
            return {"data": "x", "classification": "UNCLASSIFIED"}

        result = my_tool()
        assert result["classification"] == "UNCLASSIFIED"

    def test_custom_marking(self):
        @compliance_sidecar(marking="CUI // SP-CTI // NOFORN")
        def my_tool():
            return {"data": "x"}

        result = my_tool()
        assert result["classification"] == "CUI // SP-CTI // NOFORN"

    def test_nested_dict_injection(self):
        @compliance_sidecar
        def my_tool():
            return {
                "report": {"findings": []},
                "summary": {"score": 95},
            }

        result = my_tool()
        assert result["classification"] == DEFAULT_MARKING
        assert result["report"]["classification"] == DEFAULT_MARKING
        assert result["summary"]["classification"] == DEFAULT_MARKING

    def test_list_of_dicts_injection(self):
        @compliance_sidecar
        def my_tool():
            return [{"name": "a"}, {"name": "b"}]

        result = my_tool()
        assert all(item["classification"] == DEFAULT_MARKING for item in result)

    def test_string_output_untouched_by_default(self):
        @compliance_sidecar
        def my_tool():
            return "plain text"

        result = my_tool()
        assert result == "plain text"

    def test_string_enforce_prepends_marking(self):
        @compliance_sidecar(enforce_string=True)
        def my_tool():
            return "Some report content"

        result = my_tool()
        assert result.startswith(f"// {DEFAULT_MARKING}")

    def test_string_enforce_skips_if_present(self):
        @compliance_sidecar(enforce_string=True)
        def my_tool():
            return f"// {DEFAULT_MARKING}\nReport content"

        result = my_tool()
        # Should not double-prepend
        assert result.count(DEFAULT_MARKING) == 1

    def test_preserves_function_name(self):
        @compliance_sidecar
        def my_special_tool():
            """My docstring."""
            return {}

        assert my_special_tool.__name__ == "my_special_tool"
        assert my_special_tool.__doc__ == "My docstring."

    def test_none_output_passes_through(self):
        @compliance_sidecar
        def my_tool():
            return None

        assert my_tool() is None

    def test_payload_key_not_recursed(self):
        """The 'payload' key is excluded from recursive injection."""

        @compliance_sidecar
        def my_tool():
            return {"payload": {"inner": "data"}}

        result = my_tool()
        assert result["classification"] == DEFAULT_MARKING
        assert "classification" not in result["payload"]

    def test_with_args_and_kwargs(self):
        @compliance_sidecar
        def my_tool(project_id, format="json"):
            return {"project": project_id, "format": format}

        result = my_tool("proj-1", format="xml")
        assert result["project"] == "proj-1"
        assert result["format"] == "xml"
        assert result["classification"] == DEFAULT_MARKING
