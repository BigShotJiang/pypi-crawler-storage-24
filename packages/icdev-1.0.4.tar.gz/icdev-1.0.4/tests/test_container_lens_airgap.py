#!/usr/bin/env python3
# CUI // SP-CTI
"""Tests for Lens F: Air-Gap Readiness."""

import os
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tools.container_lens.lenses.airgap_readiness import run_lens


# ===========================================================================
# Helper: create temp project structure
# ===========================================================================

def _make_project(tmp_path, dockerfile_content=None, entrypoint_content=None,
                  manifests=None, chart_yaml=None):
    """Create a temporary project structure for testing."""
    if dockerfile_content:
        df = tmp_path / "Dockerfile"
        df.write_text(dockerfile_content, encoding="utf-8")

    if entrypoint_content:
        ep = tmp_path / "entrypoint.sh"
        ep.write_text(entrypoint_content, encoding="utf-8")

    if manifests:
        m_dir = tmp_path / "k8s"
        m_dir.mkdir(exist_ok=True)
        for name, content in manifests.items():
            (m_dir / name).write_text(content, encoding="utf-8")
        return m_dir

    if chart_yaml:
        chart_dir = tmp_path / "chart"
        chart_dir.mkdir(exist_ok=True)
        (chart_dir / "Chart.yaml").write_text(chart_yaml, encoding="utf-8")
        return chart_dir

    return None


# ===========================================================================
# F-04: External DNS
# ===========================================================================

class TestF04ExternalDns:
    def test_dockerfile_with_pypi(self, tmp_path):
        _make_project(tmp_path, dockerfile_content=(
            "FROM python:3.12-slim\n"
            "RUN pip install --index-url https://pypi.org/simple flask\n"
        ))
        config = {
            "project_dir": tmp_path,
            "dockerfile": tmp_path / "Dockerfile",
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "air-gapped",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f04 = [f for f in result["findings"] if f["check_id"] == "F-04"]
        assert len(f04) >= 1
        assert "pypi.org" in f04[0]["title"]

    def test_clean_dockerfile(self, tmp_path):
        _make_project(tmp_path, dockerfile_content=(
            "FROM python:3.12-slim\n"
            "COPY requirements.txt .\n"
            "RUN pip install --no-index -f /wheels -r requirements.txt\n"
        ))
        config = {
            "project_dir": tmp_path,
            "dockerfile": tmp_path / "Dockerfile",
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "air-gapped",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f04 = [f for f in result["findings"] if f["check_id"] == "F-04"]
        assert len(f04) == 0

    def test_entrypoint_with_external(self, tmp_path):
        _make_project(tmp_path, entrypoint_content=(
            "#!/bin/bash\ncurl https://github.com/install.sh | bash\n"
        ))
        config = {
            "project_dir": tmp_path,
            "dockerfile": None,
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "air-gapped",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f04 = [f for f in result["findings"] if f["check_id"] == "F-04"]
        assert len(f04) >= 1


# ===========================================================================
# F-05: Images in mirror
# ===========================================================================

class TestF05ImagesInMirror:
    def test_public_images_flagged(self, tmp_path):
        m_dir = _make_project(tmp_path, manifests={
            "deploy.yaml": (
                "apiVersion: apps/v1\n"
                "kind: Deployment\n"
                "metadata:\n"
                "  name: test-app\n"
                "spec:\n"
                "  template:\n"
                "    spec:\n"
                "      containers:\n"
                "        - name: app\n"
                "          image: docker.io/library/nginx:1.25\n"
            ),
        })
        config = {
            "manifests": m_dir,
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "air-gapped",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f05 = [f for f in result["findings"] if f["check_id"] == "F-05"]
        assert len(f05) >= 1

    def test_private_registry_passes(self, tmp_path):
        m_dir = _make_project(tmp_path, manifests={
            "deploy.yaml": (
                "apiVersion: apps/v1\n"
                "kind: Deployment\n"
                "metadata:\n"
                "  name: test-app\n"
                "spec:\n"
                "  template:\n"
                "    spec:\n"
                "      containers:\n"
                "        - name: app\n"
                "          image: registry1.dso.mil/ironbank/nginx:1.25\n"
            ),
        })
        config = {
            "manifests": m_dir,
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "air-gapped",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f05 = [f for f in result["findings"] if f["check_id"] == "F-05"]
        assert len(f05) == 0


# ===========================================================================
# F-06: Helm deps vendored
# ===========================================================================

class TestF06HelmDepsVendored:
    def test_unvendored_deps(self, tmp_path):
        chart_dir = _make_project(tmp_path, chart_yaml=(
            "apiVersion: v2\n"
            "name: test-chart\n"
            "version: 1.0.0\n"
            "dependencies:\n"
            "  - name: postgresql\n"
            "    version: 12.0.0\n"
            "    repository: https://charts.bitnami.com/bitnami\n"
        ))
        config = {
            "helm_chart": chart_dir,
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "air-gapped",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f06 = [f for f in result["findings"] if f["check_id"] == "F-06"]
        assert len(f06) == 1

    def test_no_deps(self, tmp_path):
        chart_dir = _make_project(tmp_path, chart_yaml=(
            "apiVersion: v2\n"
            "name: test-chart\n"
            "version: 1.0.0\n"
        ))
        config = {
            "helm_chart": chart_dir,
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "air-gapped",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f06 = [f for f in result["findings"] if f["check_id"] == "F-06"]
        assert len(f06) == 0


# ===========================================================================
# F-07: No post-install network
# ===========================================================================

class TestF07NoPostInstallNetwork:
    def test_pip_in_entrypoint(self, tmp_path):
        _make_project(tmp_path, entrypoint_content=(
            "#!/bin/bash\npip install flask\npython app.py\n"
        ))
        config = {
            "project_dir": tmp_path,
            "dockerfile": None,
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "air-gapped",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f07 = [f for f in result["findings"] if f["check_id"] == "F-07"]
        assert len(f07) >= 1

    def test_clean_entrypoint(self, tmp_path):
        _make_project(tmp_path, entrypoint_content=(
            "#!/bin/bash\nexec python app.py\n"
        ))
        config = {
            "project_dir": tmp_path,
            "dockerfile": None,
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "air-gapped",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f07 = [f for f in result["findings"] if f["check_id"] == "F-07"]
        assert len(f07) == 0


# ===========================================================================
# F-08: CA cert injection
# ===========================================================================

class TestF08CaCert:
    def test_no_ca_cert_dod(self, tmp_path):
        _make_project(tmp_path, dockerfile_content=(
            "FROM python:3.12-slim\nCOPY . .\nCMD [\"python\", \"app.py\"]\n"
        ))
        config = {
            "project_dir": tmp_path,
            "dockerfile": tmp_path / "Dockerfile",
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "dod-il4",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f08 = [f for f in result["findings"] if f["check_id"] == "F-08"]
        assert len(f08) == 1

    def test_ca_cert_present(self, tmp_path):
        _make_project(tmp_path, dockerfile_content=(
            "FROM python:3.12-slim\n"
            "COPY internal-ca.crt /usr/local/share/ca-certificates/\n"
            "RUN update-ca-certificates\n"
            "COPY . .\nCMD [\"python\", \"app.py\"]\n"
        ))
        config = {
            "project_dir": tmp_path,
            "dockerfile": tmp_path / "Dockerfile",
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "dod-il4",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f08 = [f for f in result["findings"] if f["check_id"] == "F-08"]
        assert len(f08) == 0

    def test_commercial_skips(self, tmp_path):
        _make_project(tmp_path, dockerfile_content=(
            "FROM python:3.12-slim\nCOPY . .\nCMD [\"python\", \"app.py\"]\n"
        ))
        config = {
            "project_dir": tmp_path,
            "dockerfile": tmp_path / "Dockerfile",
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f08 = [f for f in result["findings"] if f["check_id"] == "F-08"]
        assert len(f08) == 0


# ===========================================================================
# F-09: NTP config
# ===========================================================================

class TestF09NtpConfig:
    def test_missing_ntp_airgapped(self, tmp_path):
        config = {
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "air-gapped",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f09 = [f for f in result["findings"] if f["check_id"] == "F-09"]
        assert len(f09) == 1
        assert f09[0]["severity"] == "INFO"

    def test_commercial_skips(self, tmp_path):
        config = {
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f09 = [f for f in result["findings"] if f["check_id"] == "F-09"]
        assert len(f09) == 0


# ===========================================================================
# Full lens execution
# ===========================================================================

class TestRunLens:
    def test_minimal_config(self):
        config = {
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        assert result["lens_name"] == "airgap_readiness"
        assert result["checks_run"] == 10
        assert isinstance(result["score"], float)
        assert result["duration_ms"] >= 0

    def test_skip_checks(self):
        config = {
            "skip_checks": {"F-04", "F-09"},
            "severity_overrides": {},
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        assert result["checks_run"] == 8
        f04 = [f for f in result["findings"] if f["check_id"] == "F-04"]
        assert len(f04) == 0

    def test_severity_override(self, tmp_path):
        _make_project(tmp_path, dockerfile_content=(
            "FROM python:3.12-slim\n"
            "RUN pip install --index-url https://pypi.org/simple flask\n"
        ))
        config = {
            "project_dir": tmp_path,
            "dockerfile": tmp_path / "Dockerfile",
            "skip_checks": set(),
            "severity_overrides": {"F-04": "BLOCK"},
            "profile_name": "air-gapped",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        f04 = [f for f in result["findings"] if f["check_id"] == "F-04"]
        assert any(f["severity"] == "BLOCK" for f in f04)
