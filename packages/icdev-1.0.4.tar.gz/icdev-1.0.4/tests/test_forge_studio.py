# CUI // SP-CTI
"""Tests for Forge Studio Phase 1 — component catalog, renderer, generator, schema, eject."""

import json
import os
import shutil
import tempfile
import pytest

# ---------------------------------------------------------------------------
# Component Catalog
# ---------------------------------------------------------------------------

class TestComponentRegistry:
    def test_list_components(self):
        from tools.forge_studio.catalog.component_registry import list_components
        components = list_components()
        assert len(components) >= 30
        types = {c["type"] for c in components}
        assert "Button" in types
        assert "Card" in types
        assert "Table" in types
        assert "KanbanBoard" in types

    def test_get_component(self):
        from tools.forge_studio.catalog.component_registry import get_component
        btn = get_component("Button")
        assert btn is not None
        assert btn["category"] == "input"
        assert "variant" in btn["props_schema"]

    def test_get_nonexistent(self):
        from tools.forge_studio.catalog.component_registry import get_component
        assert get_component("FakeComponent") is None

    def test_validate_props_valid(self):
        from tools.forge_studio.catalog.component_registry import validate_props
        result = validate_props("Button", {"label": "Click me", "variant": "default"})
        assert result["valid"] is True
        assert len(result["errors"]) == 0

    def test_validate_props_missing_required(self):
        from tools.forge_studio.catalog.component_registry import validate_props
        result = validate_props("Button", {"variant": "default"})
        assert result["valid"] is False
        assert any("required" in e for e in result["errors"])

    def test_validate_props_invalid_enum(self):
        from tools.forge_studio.catalog.component_registry import validate_props
        result = validate_props("Button", {"label": "OK", "variant": "nope"})
        assert result["valid"] is False
        assert any("not in" in e for e in result["errors"])

    def test_get_categories(self):
        from tools.forge_studio.catalog.component_registry import get_categories
        cats = get_categories()
        assert "layout" in cats
        assert "input" in cats
        assert "display" in cats

    def test_catalog_summary(self):
        from tools.forge_studio.catalog.component_registry import get_catalog_summary
        summary = get_catalog_summary()
        assert summary["total_components"] >= 30
        assert "version" in summary


# ---------------------------------------------------------------------------
# Schema Validator
# ---------------------------------------------------------------------------

class TestSchemaValidator:
    def test_validate_simple_tree(self):
        from tools.forge_studio.catalog.schema_validator import validate_component_tree
        tree = [
            {"id": "btn1", "type": "Button", "props": {"label": "Click"}, "children": []},
        ]
        result = validate_component_tree(tree)
        assert result["valid"] is True
        assert result["component_count"] == 1

    def test_validate_unknown_type(self):
        from tools.forge_studio.catalog.schema_validator import validate_component_tree
        tree = [
            {"id": "x1", "type": "FakeWidget", "props": {}, "children": []},
        ]
        result = validate_component_tree(tree)
        assert result["valid"] is False
        assert any("unknown" in e.lower() for e in result["errors"])

    def test_validate_duplicate_ids(self):
        from tools.forge_studio.catalog.schema_validator import validate_component_tree
        tree = [
            {"id": "same", "type": "Button", "props": {"label": "A"}, "children": []},
            {"id": "same", "type": "Button", "props": {"label": "B"}, "children": []},
        ]
        result = validate_component_tree(tree)
        assert result["valid"] is False
        assert any("duplicate" in e for e in result["errors"])

    def test_validate_nested_tree(self):
        from tools.forge_studio.catalog.schema_validator import validate_component_tree
        tree = [{
            "id": "card1", "type": "Card", "props": {},
            "children": [
                {"id": "txt1", "type": "Text", "props": {"content": "Hello"}, "children": [], "slot": "content"},
            ],
        }]
        result = validate_component_tree(tree)
        assert result["valid"] is True
        assert result["component_count"] == 2

    def test_validate_app(self):
        from tools.forge_studio.catalog.schema_validator import validate_app
        app = {
            "name": "Test",
            "pages": [{
                "id": "p1", "name": "Home", "route": "/",
                "component_tree": [
                    {"id": "t1", "type": "Text", "props": {"content": "Hi"}, "children": []},
                ],
            }],
        }
        result = validate_app(app)
        assert result["valid"] is True
        assert result["page_count"] == 1


# ---------------------------------------------------------------------------
# Renderer
# ---------------------------------------------------------------------------

class TestRenderer:
    def test_render_button(self):
        from tools.forge_studio.renderer.json_render_engine import render_component
        node = {"id": "b1", "type": "Button", "props": {"label": "Click", "variant": "default"}, "children": []}
        jsx = render_component(node)
        assert "Click" in jsx
        assert "Button" in jsx

    def test_render_card_with_children(self):
        from tools.forge_studio.renderer.json_render_engine import render_component
        node = {
            "id": "c1", "type": "Card", "props": {},
            "children": [
                {"id": "t1", "type": "Text", "props": {"content": "Title"}, "children": [], "slot": "header"},
            ],
        }
        jsx = render_component(node)
        assert "Card" in jsx
        assert "Title" in jsx

    def test_render_page_file(self):
        from tools.forge_studio.renderer.json_render_engine import render_page_file
        page = {
            "name": "Dashboard",
            "route": "/",
            "is_protected": True,
            "component_tree": [
                {"id": "t1", "type": "Text", "props": {"content": "Welcome"}, "children": []},
            ],
        }
        code = render_page_file(page)
        assert '"use client"' in code
        assert "useAuth" in code
        assert "DashboardPage" in code

    def test_render_app(self):
        from tools.forge_studio.renderer.json_render_engine import render_app
        app = {
            "name": "Test",
            "pages": [{
                "id": "p1", "name": "Home", "route": "/",
                "component_tree": [
                    {"id": "t1", "type": "Text", "props": {"content": "Hi"}, "children": []},
                ],
            }],
        }
        files = render_app(app)
        assert "app/page.tsx" in files


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class TestModels:
    def test_forge_component_roundtrip(self):
        from tools.forge_studio.models import ForgeComponent
        comp = ForgeComponent(id="btn1", type="Button", props={"label": "Go"})
        d = comp.to_dict()
        comp2 = ForgeComponent.from_dict(d)
        assert comp2.id == "btn1"
        assert comp2.props["label"] == "Go"

    def test_forge_app_roundtrip(self):
        from tools.forge_studio.models import ForgeApp, ForgePage, ForgeComponent
        app = ForgeApp(
            id="test-1", name="Test App",
            pages=[ForgePage(
                id="p1", name="Home", route="/",
                component_tree=[ForgeComponent(id="t1", type="Text", props={"content": "Hi"})],
            )],
            created_at="2026-01-01T00:00:00Z",
        )
        j = app.to_json()
        app2 = ForgeApp.from_json(j)
        assert app2.name == "Test App"
        assert len(app2.pages) == 1
        assert app2.pages[0].component_tree[0].type == "Text"


# ---------------------------------------------------------------------------
# Schema Generator
# ---------------------------------------------------------------------------

class TestSchemaGenerator:
    def test_generate_ddl(self):
        from tools.forge_studio.supabase.schema_generator import schema_from_tables_spec, generate_ddl
        spec = [
            {"name": "tasks", "columns": [{"name": "title", "type": "text"}]},
        ]
        schema = schema_from_tables_spec(spec)
        ddl = generate_ddl(schema)
        assert "CREATE TABLE IF NOT EXISTS tasks" in ddl
        assert "auth.uid() = user_id" in ddl
        assert "ROW LEVEL SECURITY" in ddl

    def test_auto_columns(self):
        from tools.forge_studio.supabase.schema_generator import schema_from_tables_spec
        spec = [{"name": "items", "columns": [{"name": "name", "type": "text"}]}]
        schema = schema_from_tables_spec(spec)
        col_names = [c.name for c in schema.tables[0].columns]
        assert "id" in col_names
        assert "user_id" in col_names
        assert "created_at" in col_names

    def test_rls_policies_generated(self):
        from tools.forge_studio.supabase.schema_generator import schema_from_tables_spec
        spec = [{"name": "docs", "columns": [{"name": "body", "type": "text"}]}]
        schema = schema_from_tables_spec(spec)
        assert len(schema.tables[0].rls_policies) == 4  # SELECT, INSERT, UPDATE, DELETE


# ---------------------------------------------------------------------------
# App Generator (template mode — no LLM)
# ---------------------------------------------------------------------------

class TestAppGenerator:
    def test_generate_crm(self):
        from tools.forge_studio.generator.app_generator import generate_app
        result = generate_app("CRM with contacts", use_llm=False, store=False)
        assert result["status"] == "success"
        assert result["app"]["name"] == "CRM App"
        assert len(result["app"]["pages"]) >= 2

    def test_generate_dashboard(self):
        from tools.forge_studio.generator.app_generator import generate_app
        result = generate_app("Analytics dashboard", use_llm=False, store=False)
        assert result["status"] == "success"
        assert "Dashboard" in result["app"]["name"]

    def test_generate_project_mgmt(self):
        from tools.forge_studio.generator.app_generator import generate_app
        result = generate_app("Task management kanban", use_llm=False, store=False)
        assert result["status"] == "success"

    def test_validation_included(self):
        from tools.forge_studio.generator.app_generator import generate_app
        result = generate_app("CRM", use_llm=False, store=False)
        assert "validation" in result
        assert "valid" in result["validation"]


# ---------------------------------------------------------------------------
# Spec Builder
# ---------------------------------------------------------------------------

class TestSpecBuilder:
    def test_extract_json_direct(self):
        from tools.forge_studio.generator.spec_builder import extract_json_from_response
        result = extract_json_from_response('{"name": "test"}')
        assert result == {"name": "test"}

    def test_extract_json_from_code_block(self):
        from tools.forge_studio.generator.spec_builder import extract_json_from_response
        response = 'Here is the spec:\n```json\n{"name": "test"}\n```'
        result = extract_json_from_response(response)
        assert result == {"name": "test"}

    def test_normalize_component_tree(self):
        from tools.forge_studio.generator.spec_builder import normalize_component_tree
        tree = [
            {"id": "h1", "type": "Heading", "props": {"content": "Title"}, "children": []},
            {"id": "f1", "type": "TextField", "props": {"name": "email"}, "children": []},
        ]
        normalized = normalize_component_tree(tree)
        types = [n["type"] for n in normalized]
        assert "Text" in types
        assert "Input" in types
        assert "Heading" not in types


# ---------------------------------------------------------------------------
# Eject Engine
# ---------------------------------------------------------------------------

class TestEjectEngine:
    def test_eject_from_description(self):
        from tools.forge_studio.eject.eject_engine import eject_from_description
        with tempfile.TemporaryDirectory() as tmpdir:
            result = eject_from_description(
                description="Dashboard app",
                output_dir=tmpdir,
                use_llm=False,
            )
            assert result["status"] == "success"
            assert result["file_count"] >= 20

            # Check key files exist
            assert os.path.exists(os.path.join(tmpdir, "package.json"))
            assert os.path.exists(os.path.join(tmpdir, "docker-compose.yml"))
            assert os.path.exists(os.path.join(tmpdir, "SECURITY.md"))
            assert os.path.exists(os.path.join(tmpdir, "app", "layout.tsx"))

    def test_eject_has_supabase_migration(self):
        from tools.forge_studio.eject.eject_engine import eject_from_description
        with tempfile.TemporaryDirectory() as tmpdir:
            result = eject_from_description("CRM", output_dir=tmpdir, use_llm=False)
            migration_dir = os.path.join(tmpdir, "supabase", "migrations")
            assert os.path.exists(migration_dir)
            sql_files = [f for f in os.listdir(migration_dir) if f.endswith(".sql")]
            assert len(sql_files) >= 1

    def test_eject_has_dockerfile(self):
        from tools.forge_studio.eject.eject_engine import eject_from_description
        with tempfile.TemporaryDirectory() as tmpdir:
            result = eject_from_description("Dashboard", output_dir=tmpdir, use_llm=False)
            df = os.path.join(tmpdir, "Dockerfile")
            assert os.path.exists(df)
            content = open(df).read()
            assert "FROM node:20-alpine" in content


# ---------------------------------------------------------------------------
# Layout Engine
# ---------------------------------------------------------------------------

class TestLayoutEngine:
    def test_compose_app_layout(self):
        from tools.forge_studio.renderer.layout_engine import compose_app_layout
        layout = compose_app_layout({"name": "Test", "pages": []})
        assert "RootLayout" in layout
        assert "AuthProvider" in layout

    def test_globals_css(self):
        from tools.forge_studio.renderer.layout_engine import compose_globals_css
        css = compose_globals_css()
        assert "@tailwind base" in css
        assert "--primary" in css

    def test_generate_route_structure(self):
        from tools.forge_studio.renderer.layout_engine import generate_route_structure
        pages = [
            {"name": "Home", "route": "/"},
            {"name": "Settings", "route": "/settings"},
        ]
        routes = generate_route_structure(pages)
        assert routes["/"] == "app/page.tsx"
        assert routes["/settings"] == "app/settings/page.tsx"
