#!/usr/bin/env python3
# CUI // SP-CTI
"""Tests for Lens E: Security & Compliance."""

import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tools.container_lens.lenses.security_compliance import run_lens
from tools.container_lens.utils.image_inspector import (
    parse_image_ref, is_approved_registry, uses_latest_tag,
    detect_runtime_network_calls, detect_external_dns,
    check_coredns_forward,
)


# ===========================================================================
# Image Inspector utility tests
# ===========================================================================

class TestParseImageRef:
    def test_simple_image(self):
        r = parse_image_ref("nginx:1.25")
        assert r["repo"] == "nginx"
        assert r["tag"] == "1.25"
        assert r["registry"] is None
        assert r["digest"] is None

    def test_registry_image(self):
        r = parse_image_ref("registry1.dso.mil/ironbank/nginx:1.25-alpine")
        assert r["registry"] == "registry1.dso.mil"
        assert r["repo"] == "ironbank/nginx"
        assert r["tag"] == "1.25-alpine"

    def test_digest_image(self):
        digest = "sha256:" + "a" * 64
        r = parse_image_ref(f"myimage@{digest}")
        assert r["digest"] == digest
        assert r["repo"] == "myimage"

    def test_latest_implicit(self):
        r = parse_image_ref("python")
        assert r["tag"] is None

    def test_full_ref(self):
        r = parse_image_ref("ghcr.io/org/app:v2.0.0")
        assert r["registry"] == "ghcr.io"
        assert r["repo"] == "org/app"
        assert r["tag"] == "v2.0.0"


class TestIsApprovedRegistry:
    def test_ironbank_approved(self):
        assert is_approved_registry("registry1.dso.mil/ironbank/python:3.12")

    def test_docker_hub_not_approved(self):
        assert not is_approved_registry("docker.io/library/python:3.12")

    def test_extra_approved(self):
        assert is_approved_registry(
            "myregistry.internal/app:1.0",
            extra_approved=["myregistry.internal"],
        )


class TestUsesLatestTag:
    def test_latest_explicit(self):
        assert uses_latest_tag("nginx:latest")

    def test_no_tag(self):
        assert uses_latest_tag("nginx")

    def test_specific_tag(self):
        assert not uses_latest_tag("nginx:1.25.3")

    def test_digest(self):
        assert not uses_latest_tag("nginx@sha256:" + "a" * 64)


class TestDetectRuntimeNetworkCalls:
    def test_pip_install(self):
        script = "#!/bin/bash\npip install flask\n"
        matches = detect_runtime_network_calls(script)
        assert len(matches) == 1
        assert "pip install" in matches[0]

    def test_comment_skipped(self):
        script = "#!/bin/bash\n# pip install flask\necho ok\n"
        matches = detect_runtime_network_calls(script)
        assert len(matches) == 0

    def test_multiple(self):
        script = "npm install\nyarn add react\n"
        matches = detect_runtime_network_calls(script)
        assert len(matches) == 2


class TestDetectExternalDns:
    def test_finds_pypi(self):
        content = "RUN pip install --index-url https://pypi.org/simple flask"
        matches = detect_external_dns(content)
        assert len(matches) == 1

    def test_clean(self):
        content = "RUN pip install --no-index flask"
        matches = detect_external_dns(content)
        assert len(matches) == 0


class TestCheckCorednsForward:
    def test_external_forward(self):
        corefile = """.:53 {
    forward . 8.8.8.8 8.8.4.4
    log
}"""
        issues = check_coredns_forward(corefile)
        assert len(issues) == 1
        assert "8.8.8.8" in issues[0]

    def test_internal_forward(self):
        corefile = """.:53 {
    forward . /etc/resolv.conf
    log
}"""
        issues = check_coredns_forward(corefile)
        assert len(issues) == 0


# ===========================================================================
# Lens E check tests
# ===========================================================================

class TestE01ApprovedRegistry:
    def test_no_image(self):
        config = {"skip_checks": set(), "severity_overrides": {}}
        result = run_lens(config)
        # No image provided — most checks skipped, should pass gracefully
        assert result["lens_name"] == "security_compliance"

    def test_ironbank_passes(self):
        config = {
            "image": "registry1.dso.mil/ironbank/python:3.12",
            "profile_name": "dod-il4",
            "profile": {"thresholds": {}},
            "skip_checks": set(),
            "severity_overrides": {},
        }
        result = run_lens(config)
        e01 = [f for f in result["findings"] if f["check_id"] == "E-01"]
        assert len(e01) == 0

    def test_docker_hub_fails_dod(self):
        config = {
            "image": "docker.io/library/python:3.12",
            "profile_name": "dod-il4",
            "profile": {"thresholds": {}},
            "skip_checks": set(),
            "severity_overrides": {},
        }
        result = run_lens(config)
        e01 = [f for f in result["findings"] if f["check_id"] == "E-01"]
        assert len(e01) >= 1


class TestE09LatestTag:
    def test_latest_blocked(self):
        config = {
            "image": "myapp:latest",
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
            "skip_checks": set(),
            "severity_overrides": {},
        }
        result = run_lens(config)
        e09 = [f for f in result["findings"] if f["check_id"] == "E-09"]
        assert len(e09) == 1
        assert e09[0]["severity"] == "BLOCK"

    def test_specific_tag_passes(self):
        config = {
            "image": "myapp:v1.2.3",
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
            "skip_checks": set(),
            "severity_overrides": {},
        }
        result = run_lens(config)
        e09 = [f for f in result["findings"] if f["check_id"] == "E-09"]
        assert len(e09) == 0

    def test_digest_passes(self):
        config = {
            "image": "myapp@sha256:" + "a" * 64,
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
            "skip_checks": set(),
            "severity_overrides": {},
        }
        result = run_lens(config)
        e09 = [f for f in result["findings"] if f["check_id"] == "E-09"]
        assert len(e09) == 0


class TestSeverityOverrides:
    def test_override_applied(self):
        config = {
            "image": "myapp:latest",
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
            "skip_checks": set(),
            "severity_overrides": {"E-09": "INFO"},
        }
        result = run_lens(config)
        e09 = [f for f in result["findings"] if f["check_id"] == "E-09"]
        assert len(e09) == 1
        assert e09[0]["severity"] == "INFO"


class TestRunLens:
    def test_no_image_graceful(self):
        config = {
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        assert result["lens_name"] == "security_compliance"
        assert result["checks_run"] == 27
        # Most checks return [] when no image, so most pass
        assert result["checks_passed"] >= 5

    def test_metadata_includes_tool_status(self):
        config = {
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        meta = result["metadata"]
        assert "docker_available" in meta
        assert "trivy_available" in meta
        assert "cosign_available" in meta

    def test_skip_checks(self):
        config = {
            "image": "myapp:latest",
            "skip_checks": {"E-09"},
            "severity_overrides": {},
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        e09 = [f for f in result["findings"] if f["check_id"] == "E-09"]
        assert len(e09) == 0
