#!/usr/bin/env python3
# CUI // SP-CTI
"""Unit tests for harness engineering tools.

Tests loop detection, progress tracking, exit criteria evaluation,
trace analysis, maturity assessment, and scaffolding.
"""

import json
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

# Ensure project root is on path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ---------------------------------------------------------------------------
# Exit Criteria Evaluator Tests
# ---------------------------------------------------------------------------

class TestExitCriteriaEvaluator:
    """Tests for tools/harness/exit_criteria_evaluator.py."""

    def test_list_workflows(self):
        from tools.harness.exit_criteria_evaluator import list_workflows
        result = list_workflows()
        assert "workflows" in result
        assert result["count"] >= 6
        names = [w["name"] for w in result["workflows"]]
        assert "build" in names
        assert "test" in names
        assert "deploy" in names

    def test_evaluate_build_workflow_no_state(self):
        from tools.harness.exit_criteria_evaluator import evaluate_workflow
        result = evaluate_workflow("build")
        assert result["workflow"] == "build"
        assert "criteria" in result
        assert len(result["criteria"]) >= 4
        # Without state, all should be unknown
        for c in result["criteria"]:
            assert c["status"] in ("met", "not_met", "unknown")

    def test_evaluate_build_with_passing_state(self, tmp_path):
        from tools.harness.exit_criteria_evaluator import evaluate_workflow
        state = {
            "unit_passed": 42,
            "unit_failed": 0,
            "security_gate_passed": True,
        }
        state_file = tmp_path / "state.json"
        state_file.write_text(json.dumps(state))
        result = evaluate_workflow("build", str(state_file))
        pytest_criterion = next((c for c in result["criteria"] if c["gate"] == "pytest_pass"), None)
        assert pytest_criterion is not None
        assert pytest_criterion["status"] == "met"

    def test_evaluate_build_with_failing_state(self, tmp_path):
        from tools.harness.exit_criteria_evaluator import evaluate_workflow
        state = {"unit_passed": 10, "unit_failed": 3}
        state_file = tmp_path / "state.json"
        state_file.write_text(json.dumps(state))
        result = evaluate_workflow("build", str(state_file))
        assert result["any_failed"] is True
        assert result["all_met"] is False

    def test_evaluate_unknown_workflow(self):
        from tools.harness.exit_criteria_evaluator import evaluate_workflow
        result = evaluate_workflow("nonexistent")
        assert "error" in result

    def test_classification_marking(self):
        from tools.harness.exit_criteria_evaluator import evaluate_workflow
        result = evaluate_workflow("build")
        assert result["classification"] == "CUI // SP-CTI"


# ---------------------------------------------------------------------------
# Maturity Assessor Tests
# ---------------------------------------------------------------------------

class TestMaturityAssessor:
    """Tests for tools/harness/maturity_assessor.py."""

    def test_assess_icdev_project(self):
        from tools.harness.maturity_assessor import assess_maturity
        project_dir = str(Path(__file__).resolve().parent.parent)
        result = assess_maturity(project_dir, detailed=True)
        assert result["level"] == 4
        assert result["level_name"] == "Optimized"
        assert result["composite_score"] == 1.0
        assert len(result["dimensions"]) == 6

    def test_assess_empty_dir(self, tmp_path):
        from tools.harness.maturity_assessor import assess_maturity
        result = assess_maturity(str(tmp_path), detailed=True)
        assert result["level"] == 0
        assert result["level_name"] == "None"
        assert result["composite_score"] == 0.0

    def test_assess_partial_dir(self, tmp_path):
        from tools.harness.maturity_assessor import assess_maturity
        # Create only hooks
        hooks_dir = tmp_path / ".claude" / "hooks"
        hooks_dir.mkdir(parents=True)
        (hooks_dir / "pre_tool_use.py").write_text("# hook")
        (hooks_dir / "post_tool_use.py").write_text("# hook")
        (hooks_dir / "stop.py").write_text("# hook")
        result = assess_maturity(str(tmp_path), detailed=True)
        assert result["level"] >= 1
        assert result["composite_score"] > 0.0

    def test_dimension_weights_sum(self):
        from tools.harness.maturity_assessor import DEFAULT_WEIGHTS
        total = sum(DEFAULT_WEIGHTS.values())
        assert abs(total - 1.0) < 0.01

    def test_classification_marking(self):
        from tools.harness.maturity_assessor import assess_maturity
        result = assess_maturity(str(Path(__file__).resolve().parent.parent))
        assert result["classification"] == "CUI // SP-CTI"


# ---------------------------------------------------------------------------
# Trace Analyzer Tests
# ---------------------------------------------------------------------------

class TestTraceAnalyzer:
    """Tests for tools/harness/trace_analyzer.py."""

    def test_analyze_nonexistent_session(self):
        from tools.harness.trace_analyzer import analyze_session
        result = analyze_session("nonexistent-session-id")
        assert result["session_id"] == "nonexistent-session-id"
        assert result["event_count"] == 0
        assert result["recommendation_count"] == 0

    def test_analyze_recent_zero(self):
        from tools.harness.trace_analyzer import analyze_recent
        result = analyze_recent(0)
        assert result["sessions_analyzed"] == 0

    def test_get_stored_recommendations(self):
        from tools.harness.trace_analyzer import get_stored_recommendations
        result = get_stored_recommendations(limit=10)
        assert "recommendations" in result
        assert "count" in result

    def test_loop_state_analysis(self, tmp_path):
        from tools.harness.trace_analyzer import _analyze_loop_state
        # Create mock loop state
        session_id = "test-session-123"
        session_dir = tmp_path / ".tmp" / "sessions" / session_id
        session_dir.mkdir(parents=True)
        loop_state = {
            "edits": {
                "tools/dashboard/app.py": {"count": 12, "first_ts": "", "last_ts": ""},
                "tools/harness/__init__.py": {"count": 2, "first_ts": "", "last_ts": ""},
            },
            "warnings_issued": {},
        }
        (session_dir / "loop_state.json").write_text(json.dumps(loop_state))

        # Patch BASE_DIR to tmp_path
        with patch("tools.harness.trace_analyzer.BASE_DIR", tmp_path):
            recs = _analyze_loop_state(session_id)
        assert len(recs) >= 1
        assert any(r["category"] == "loop_detection" for r in recs)

    def test_classification_marking(self):
        from tools.harness.trace_analyzer import analyze_session
        result = analyze_session("test")
        assert result["classification"] == "CUI // SP-CTI"


# ---------------------------------------------------------------------------
# Scaffold Harness Tests
# ---------------------------------------------------------------------------

class TestScaffoldHarness:
    """Tests for tools/harness/scaffold_harness.py."""

    def test_scaffold_creates_all_files(self, tmp_path):
        from tools.harness.scaffold_harness import scaffold
        result = scaffold(str(tmp_path))
        assert result["file_count"] == 6
        assert (tmp_path / ".claude" / "hooks" / "pre_tool_use.py").exists()
        assert (tmp_path / ".claude" / "hooks" / "post_tool_use.py").exists()
        assert (tmp_path / ".claude" / "hooks" / "stop.py").exists()
        assert (tmp_path / "args" / "harness_config.yaml").exists()
        assert (tmp_path / "args" / "exit_criteria.yaml").exists()
        assert (tmp_path / "args" / "security_gates.yaml").exists()

    def test_scaffold_il4_has_stricter_gates(self, tmp_path):
        from tools.harness.scaffold_harness import scaffold
        scaffold(str(tmp_path), impact_level="IL4")
        gates_content = (tmp_path / "args" / "security_gates.yaml").read_text()
        assert "missing_cui_markings" in gates_content
        assert "cat1_stig_finding" in gates_content

    def test_scaffold_il2_has_basic_gates(self, tmp_path):
        from tools.harness.scaffold_harness import scaffold
        scaffold(str(tmp_path), impact_level="IL2")
        gates_content = (tmp_path / "args" / "security_gates.yaml").read_text()
        assert "critical_vulnerability" in gates_content
        # IL2 should NOT have CUI markings gate
        assert "missing_cui_markings" not in gates_content

    def test_scaffold_cui_markings_present(self, tmp_path):
        from tools.harness.scaffold_harness import scaffold
        scaffold(str(tmp_path))
        for fp in [
            tmp_path / ".claude" / "hooks" / "pre_tool_use.py",
            tmp_path / "args" / "harness_config.yaml",
            tmp_path / "args" / "exit_criteria.yaml",
        ]:
            content = fp.read_text()
            assert "CUI // SP-CTI" in content

    def test_scaffold_classification_in_result(self, tmp_path):
        from tools.harness.scaffold_harness import scaffold
        result = scaffold(str(tmp_path))
        assert result["classification"] == "CUI // SP-CTI"

    def test_scaffolded_project_scores_nonzero(self, tmp_path):
        """A scaffolded project should score > 0 on maturity assessment."""
        from tools.harness.scaffold_harness import scaffold
        from tools.harness.maturity_assessor import assess_maturity
        scaffold(str(tmp_path))
        result = assess_maturity(str(tmp_path), detailed=True)
        assert result["level"] >= 2  # Managed or better
        assert result["composite_score"] > 0.0


# ---------------------------------------------------------------------------
# Loop Detection Tests (via post_tool_use hook logic)
# ---------------------------------------------------------------------------

class TestLoopDetection:
    """Tests for loop detection in .claude/hooks/post_tool_use.py."""

    def _get_hook_module(self):
        """Import the post_tool_use module."""
        hooks_dir = Path(__file__).resolve().parent.parent / ".claude" / "hooks"
        if str(hooks_dir) not in sys.path:
            sys.path.insert(0, str(hooks_dir))
        import importlib
        # Ensure fresh import
        if "post_tool_use" in sys.modules:
            del sys.modules["post_tool_use"]
        import post_tool_use
        return post_tool_use

    def test_loop_detection_warns_at_threshold(self, tmp_path):
        mod = self._get_hook_module()
        session_id = "test-loop-1"

        # Mock config with threshold=3 for easier testing
        mock_config = {
            "loop_detection": {"enabled": True, "threshold": 3, "escalation_multiplier": 2, "exclude_files": []},
        }
        with patch.object(mod, "_load_harness_config", return_value=mock_config):
            with patch.object(mod, "PROJECT_ROOT", tmp_path):
                # Edit same file 3 times
                for _ in range(3):
                    mod.check_loop_detection("Edit", {"file_path": "/test/file.py"}, session_id)

        state_file = tmp_path / ".tmp" / "sessions" / session_id / "loop_state.json"
        assert state_file.exists()
        state = json.loads(state_file.read_text())
        assert state["edits"]["/test/file.py"]["count"] == 3
        assert "warn" in state["warnings_issued"].get("/test/file.py", [])

    def test_loop_detection_skips_non_edit_tools(self, tmp_path):
        mod = self._get_hook_module()
        mock_config = {"loop_detection": {"enabled": True, "threshold": 3, "exclude_files": []}}
        with patch.object(mod, "_load_harness_config", return_value=mock_config):
            with patch.object(mod, "PROJECT_ROOT", tmp_path):
                mod.check_loop_detection("Read", {"file_path": "/test/file.py"}, "test-2")
        state_dir = tmp_path / ".tmp" / "sessions" / "test-2"
        assert not (state_dir / "loop_state.json").exists()

    def test_loop_detection_respects_excludes(self, tmp_path):
        mod = self._get_hook_module()
        mock_config = {
            "loop_detection": {"enabled": True, "threshold": 2, "escalation_multiplier": 2, "exclude_files": ["*.lock"]},
        }
        with patch.object(mod, "_load_harness_config", return_value=mock_config):
            with patch.object(mod, "PROJECT_ROOT", tmp_path):
                for _ in range(5):
                    mod.check_loop_detection("Edit", {"file_path": "/test/yarn.lock"}, "test-3")
        state_file = tmp_path / ".tmp" / "sessions" / "test-3" / "loop_state.json"
        assert not state_file.exists()

    def test_loop_detection_disabled(self, tmp_path):
        mod = self._get_hook_module()
        mock_config = {"loop_detection": {"enabled": False}}
        with patch.object(mod, "_load_harness_config", return_value=mock_config):
            with patch.object(mod, "PROJECT_ROOT", tmp_path):
                mod.check_loop_detection("Edit", {"file_path": "/test/file.py"}, "test-4")
        state_file = tmp_path / ".tmp" / "sessions" / "test-4" / "loop_state.json"
        assert not state_file.exists()


# ---------------------------------------------------------------------------
# Progress Tracking Tests
# ---------------------------------------------------------------------------

class TestProgressTracking:
    """Tests for progress tracking in .claude/hooks/post_tool_use.py."""

    def _get_hook_module(self):
        hooks_dir = Path(__file__).resolve().parent.parent / ".claude" / "hooks"
        if str(hooks_dir) not in sys.path:
            sys.path.insert(0, str(hooks_dir))
        if "post_tool_use" in sys.modules:
            del sys.modules["post_tool_use"]
        import post_tool_use
        return post_tool_use

    def test_progress_tracks_write(self, tmp_path):
        mod = self._get_hook_module()
        session_id = "test-prog-1"
        mock_config = {"progress_tracking": {"enabled": True, "significant_tools": ["Write", "Edit", "Bash"], "max_events": 500}}
        with patch.object(mod, "_load_harness_config", return_value=mock_config):
            with patch.object(mod, "PROJECT_ROOT", tmp_path):
                mod.track_progress("Write", {"file_path": "/new/file.py"}, "", session_id)
        pf = tmp_path / ".tmp" / "sessions" / session_id / "progress.json"
        assert pf.exists()
        progress = json.loads(pf.read_text())
        assert "/new/file.py" in progress["files_created"]
        assert len(progress["events"]) == 1

    def test_progress_tracks_pytest(self, tmp_path):
        mod = self._get_hook_module()
        session_id = "test-prog-2"
        mock_config = {"progress_tracking": {"enabled": True, "significant_tools": ["Bash"], "capture_test_results": True, "max_events": 500}}
        output = "===== 10 passed, 2 failed in 5.3s ====="
        with patch.object(mod, "_load_harness_config", return_value=mock_config):
            with patch.object(mod, "PROJECT_ROOT", tmp_path):
                mod.track_progress("Bash", {"command": "python -m pytest tests/"}, output, session_id)
        pf = tmp_path / ".tmp" / "sessions" / session_id / "progress.json"
        progress = json.loads(pf.read_text())
        assert progress["tests_run"] == 1
        assert progress["tests_passed"] == 10
        assert progress["tests_failed"] == 2

    def test_progress_caps_events(self, tmp_path):
        mod = self._get_hook_module()
        session_id = "test-prog-3"
        mock_config = {"progress_tracking": {"enabled": True, "significant_tools": ["Edit"], "max_events": 5}}
        with patch.object(mod, "_load_harness_config", return_value=mock_config):
            with patch.object(mod, "PROJECT_ROOT", tmp_path):
                for i in range(10):
                    mod.track_progress("Edit", {"file_path": f"/file{i}.py"}, "", session_id)
        pf = tmp_path / ".tmp" / "sessions" / session_id / "progress.json"
        progress = json.loads(pf.read_text())
        assert len(progress["events"]) == 5  # capped at max_events

    def test_progress_disabled(self, tmp_path):
        mod = self._get_hook_module()
        mock_config = {"progress_tracking": {"enabled": False}}
        with patch.object(mod, "_load_harness_config", return_value=mock_config):
            with patch.object(mod, "PROJECT_ROOT", tmp_path):
                mod.track_progress("Write", {"file_path": "/x.py"}, "", "test-prog-4")
        pf = tmp_path / ".tmp" / "sessions" / "test-prog-4" / "progress.json"
        assert not pf.exists()
