# CUI // SP-CTI
"""Tests for CircuitBreaker implementation.

Classification: CUI // SP-CTI
"""

import time
from unittest.mock import patch

import pytest

from tools.core.circuit_breaker import (
    CircuitBreaker,
    CircuitOpenError,
    CircuitState,
    get_breaker,
    all_breakers,
    _REGISTRY,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_registry():
    """Clear the global breaker registry between tests."""
    _REGISTRY.clear()
    yield
    _REGISTRY.clear()


@pytest.fixture
def breaker():
    """Create a test breaker with low thresholds for fast tests."""
    return CircuitBreaker(
        name="test",
        failure_threshold=3,
        reset_timeout_seconds=0.5,
        half_open_success_threshold=2,
        window_size=10,
        min_calls_before_trip=3,
    )


# ---------------------------------------------------------------------------
# State transitions
# ---------------------------------------------------------------------------

class TestCircuitBreakerStates:

    def test_initial_state_is_closed(self, breaker):
        assert breaker.state == CircuitState.CLOSED

    def test_stays_closed_on_successes(self, breaker):
        for _ in range(10):
            breaker.record_success()
        assert breaker.state == CircuitState.CLOSED

    def test_opens_after_threshold_failures(self, breaker):
        for _ in range(3):
            breaker.record_failure()
        assert breaker.state == CircuitState.OPEN

    def test_does_not_open_below_min_calls(self):
        b = CircuitBreaker(
            "test2",
            failure_threshold=2,
            min_calls_before_trip=5,
            window_size=10,
            reset_timeout_seconds=1,
        )
        # 2 failures but only 2 calls (below min_calls_before_trip=5)
        b.record_failure()
        b.record_failure()
        assert b.state == CircuitState.CLOSED

    def test_transitions_to_half_open_after_timeout(self, breaker):
        for _ in range(3):
            breaker.record_failure()
        assert breaker.state == CircuitState.OPEN

        # Wait for reset timeout
        time.sleep(0.6)
        assert breaker.state == CircuitState.HALF_OPEN

    def test_closes_after_half_open_successes(self, breaker):
        for _ in range(3):
            breaker.record_failure()
        time.sleep(0.6)
        assert breaker.state == CircuitState.HALF_OPEN

        breaker.record_success()
        breaker.record_success()
        assert breaker.state == CircuitState.CLOSED

    def test_reopens_on_half_open_failure(self, breaker):
        for _ in range(3):
            breaker.record_failure()
        time.sleep(0.6)
        assert breaker.state == CircuitState.HALF_OPEN

        breaker.record_failure()
        assert breaker.state == CircuitState.OPEN


# ---------------------------------------------------------------------------
# Request gating
# ---------------------------------------------------------------------------

class TestAllowRequest:

    def test_allows_when_closed(self, breaker):
        assert breaker.allow_request() is True

    def test_rejects_when_open(self, breaker):
        for _ in range(3):
            breaker.record_failure()
        assert breaker.allow_request() is False

    def test_allows_limited_calls_in_half_open(self, breaker):
        for _ in range(3):
            breaker.record_failure()
        time.sleep(0.6)

        # half_open_success_threshold = 2
        assert breaker.allow_request() is True
        assert breaker.allow_request() is True
        assert breaker.allow_request() is False  # Third call rejected


# ---------------------------------------------------------------------------
# Context manager / decorator
# ---------------------------------------------------------------------------

class TestContextManager:

    def test_context_manager_records_success(self, breaker):
        with breaker:
            pass  # no exception
        assert breaker.state == CircuitState.CLOSED

    def test_context_manager_records_failure(self, breaker):
        for _ in range(3):
            with pytest.raises(ValueError):
                with breaker:
                    raise ValueError("boom")
        assert breaker.state == CircuitState.OPEN

    def test_context_manager_raises_circuit_open(self, breaker):
        for _ in range(3):
            breaker.record_failure()
        with pytest.raises(CircuitOpenError) as exc_info:
            with breaker:
                pass
        assert exc_info.value.breaker_name == "test"

    def test_decorator_wraps_function(self, breaker):
        @breaker
        def my_func(x):
            return x * 2

        assert my_func(5) == 10

    def test_decorator_records_failure(self, breaker):
        @breaker
        def failing_func():
            raise RuntimeError("fail")

        for _ in range(3):
            with pytest.raises(RuntimeError):
                failing_func()
        assert breaker.state == CircuitState.OPEN


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

class TestRegistry:

    def test_get_breaker_creates_new(self):
        b = get_breaker("registry_test")
        assert isinstance(b, CircuitBreaker)
        assert b.name == "registry_test"

    def test_get_breaker_returns_same_instance(self):
        b1 = get_breaker("same")
        b2 = get_breaker("same")
        assert b1 is b2

    def test_all_breakers_snapshot(self):
        get_breaker("a")
        get_breaker("b")
        snapshot = all_breakers()
        assert "a" in snapshot
        assert "b" in snapshot
        assert snapshot["a"]["state"] == "closed"


# ---------------------------------------------------------------------------
# Serialisation
# ---------------------------------------------------------------------------

class TestToDict:

    def test_to_dict_structure(self, breaker):
        d = breaker.to_dict()
        assert d["name"] == "test"
        assert d["state"] == "closed"
        assert d["failure_count"] == 0
        assert "failure_threshold" in d
        assert "reset_timeout_seconds" in d

    def test_to_dict_reflects_failures(self, breaker):
        breaker.record_failure()
        breaker.record_failure()
        d = breaker.to_dict()
        assert d["failure_count"] == 2


# ---------------------------------------------------------------------------
# Reset
# ---------------------------------------------------------------------------

class TestReset:

    def test_reset_clears_state(self, breaker):
        for _ in range(3):
            breaker.record_failure()
        assert breaker.state == CircuitState.OPEN

        breaker.reset()
        assert breaker.state == CircuitState.CLOSED
        assert breaker.allow_request() is True
