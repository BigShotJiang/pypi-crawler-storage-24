#!/usr/bin/env python3
# CUI // SP-CTI
"""Tests for CodeLens/Pro Lens C: K8s Manifest Validation."""

import os
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

# Ensure project root is on path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tools.container_lens.utils.manifest_parser import (
    parse_yaml,
    parse_multi_doc_yaml,
    load_manifests,
    get_kind,
    get_containers,
    get_security_context,
    is_workload,
)


class TestManifestParser(unittest.TestCase):
    """Test the YAML manifest parser."""

    def test_parse_simple_deployment(self):
        yaml_text = textwrap.dedent("""\
            apiVersion: apps/v1
            kind: Deployment
            metadata:
              name: web
              namespace: production
            spec:
              replicas: 3
        """)
        doc = parse_yaml(yaml_text)
        self.assertEqual(doc["apiVersion"], "apps/v1")
        self.assertEqual(doc["kind"], "Deployment")
        self.assertEqual(doc["metadata"]["name"], "web")
        self.assertEqual(doc["spec"]["replicas"], 3)

    def test_parse_multi_doc(self):
        yaml_text = textwrap.dedent("""\
            apiVersion: v1
            kind: Service
            metadata:
              name: svc
            ---
            apiVersion: apps/v1
            kind: Deployment
            metadata:
              name: deploy
        """)
        docs = parse_multi_doc_yaml(yaml_text)
        self.assertEqual(len(docs), 2)
        self.assertEqual(docs[0]["kind"], "Service")
        self.assertEqual(docs[1]["kind"], "Deployment")

    def test_parse_list_values(self):
        yaml_text = textwrap.dedent("""\
            apiVersion: v1
            kind: Pod
            spec:
              containers:
                - name: web
                  image: nginx:1.25
                - name: sidecar
                  image: envoy:1.28
        """)
        doc = parse_yaml(yaml_text)
        self.assertEqual(doc["kind"], "Pod")
        containers = doc["spec"]["containers"]
        self.assertEqual(len(containers), 2)
        self.assertEqual(containers[0]["name"], "web")

    def test_parse_nested_security_context(self):
        yaml_text = textwrap.dedent("""\
            apiVersion: v1
            kind: Pod
            spec:
              securityContext:
                runAsNonRoot: true
                fsGroup: 1000
              containers:
                - name: app
                  securityContext:
                    readOnlyRootFilesystem: true
                    allowPrivilegeEscalation: false
        """)
        doc = parse_yaml(yaml_text)
        sc = doc["spec"]["securityContext"]
        self.assertTrue(sc["runAsNonRoot"])
        self.assertEqual(sc["fsGroup"], 1000)

    def test_parse_flow_sequence(self):
        yaml_text = textwrap.dedent("""\
            apiVersion: v1
            kind: Pod
            spec:
              containers:
                - name: app
                  securityContext:
                    capabilities:
                      drop: ["ALL"]
        """)
        doc = parse_yaml(yaml_text)
        caps = doc["spec"]["containers"][0]["securityContext"]["capabilities"]
        self.assertEqual(caps["drop"], ["ALL"])

    def test_load_manifests_from_dir(self):
        with tempfile.TemporaryDirectory() as td:
            # Write a manifest file
            (Path(td) / "deploy.yaml").write_text(textwrap.dedent("""\
                apiVersion: apps/v1
                kind: Deployment
                metadata:
                  name: web
            """), encoding="utf-8")
            docs = load_manifests(Path(td))
            self.assertEqual(len(docs), 1)
            self.assertEqual(docs[0]["kind"], "Deployment")
            self.assertIn("_source_file", docs[0])

    def test_is_workload(self):
        self.assertTrue(is_workload({"kind": "Deployment"}))
        self.assertTrue(is_workload({"kind": "StatefulSet"}))
        self.assertFalse(is_workload({"kind": "Service"}))
        self.assertFalse(is_workload({"kind": "ConfigMap"}))


class TestC03RunAsNonRoot(unittest.TestCase):
    """Test C-03: runAsNonRoot check."""

    def _make_deployment(self, container_sc=None, pod_sc=None):
        doc = {
            "kind": "Deployment",
            "spec": {
                "template": {
                    "spec": {
                        "containers": [
                            {"name": "app", "image": "myapp:1.0"}
                        ],
                    }
                }
            }
        }
        if container_sc:
            doc["spec"]["template"]["spec"]["containers"][0]["securityContext"] = container_sc
        if pod_sc:
            doc["spec"]["template"]["spec"]["securityContext"] = pod_sc
        return doc

    def test_detects_missing_run_as_non_root(self):
        from tools.container_lens.lenses.k8s_manifest import _check_run_as_non_root
        docs = [self._make_deployment()]
        findings = _check_run_as_non_root(docs, set())
        self.assertTrue(len(findings) > 0)
        self.assertEqual(findings[0]["check_id"], "C-03")

    def test_passes_container_level(self):
        from tools.container_lens.lenses.k8s_manifest import _check_run_as_non_root
        docs = [self._make_deployment(container_sc={"runAsNonRoot": True})]
        findings = _check_run_as_non_root(docs, set())
        self.assertEqual(len(findings), 0)

    def test_passes_pod_level(self):
        from tools.container_lens.lenses.k8s_manifest import _check_run_as_non_root
        docs = [self._make_deployment(pod_sc={"runAsNonRoot": True})]
        findings = _check_run_as_non_root(docs, set())
        self.assertEqual(len(findings), 0)


class TestC05PrivilegeEscalation(unittest.TestCase):
    """Test C-05: allowPrivilegeEscalation check."""

    def test_detects_missing(self):
        from tools.container_lens.lenses.k8s_manifest import _check_privilege_escalation
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app", "image": "x:1"}]
        }}}}]
        findings = _check_privilege_escalation(docs, set())
        self.assertTrue(len(findings) > 0)

    def test_passes_when_false(self):
        from tools.container_lens.lenses.k8s_manifest import _check_privilege_escalation
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app", "image": "x:1",
                            "securityContext": {"allowPrivilegeEscalation": False}}]
        }}}}]
        findings = _check_privilege_escalation(docs, set())
        self.assertEqual(len(findings), 0)


class TestC06Capabilities(unittest.TestCase):
    """Test C-06: capabilities drop ALL check."""

    def test_detects_missing_drop(self):
        from tools.container_lens.lenses.k8s_manifest import _check_capabilities
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app", "image": "x:1"}]
        }}}}]
        findings = _check_capabilities(docs, set())
        self.assertTrue(len(findings) > 0)

    def test_passes_with_drop_all(self):
        from tools.container_lens.lenses.k8s_manifest import _check_capabilities
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app", "image": "x:1",
                            "securityContext": {"capabilities": {"drop": ["ALL"]}}}]
        }}}}]
        findings = _check_capabilities(docs, set())
        self.assertEqual(len(findings), 0)


class TestC08ResourceLimits(unittest.TestCase):
    """Test C-08: resource limits check."""

    def test_detects_missing_limits(self):
        from tools.container_lens.lenses.k8s_manifest import _check_resource_limits
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app", "image": "x:1"}]
        }}}}]
        findings = _check_resource_limits(docs, set())
        self.assertTrue(len(findings) > 0)
        self.assertIn("cpu", findings[0]["title"])

    def test_passes_with_limits(self):
        from tools.container_lens.lenses.k8s_manifest import _check_resource_limits
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app", "image": "x:1",
                            "resources": {"limits": {"cpu": "500m", "memory": "256Mi"}}}]
        }}}}]
        findings = _check_resource_limits(docs, set())
        self.assertEqual(len(findings), 0)


class TestC11HostNamespace(unittest.TestCase):
    """Test C-11: host namespace check."""

    def test_detects_host_network(self):
        from tools.container_lens.lenses.k8s_manifest import _check_host_namespace
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "hostNetwork": True,
            "containers": [{"name": "app"}]
        }}}}]
        findings = _check_host_namespace(docs, set())
        self.assertTrue(len(findings) > 0)

    def test_passes_no_host(self):
        from tools.container_lens.lenses.k8s_manifest import _check_host_namespace
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app"}]
        }}}}]
        findings = _check_host_namespace(docs, set())
        self.assertEqual(len(findings), 0)


class TestC12Privileged(unittest.TestCase):
    """Test C-12: privileged container check."""

    def test_detects_privileged(self):
        from tools.container_lens.lenses.k8s_manifest import _check_privileged
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app", "securityContext": {"privileged": True}}]
        }}}}]
        findings = _check_privileged(docs, set())
        self.assertTrue(len(findings) > 0)

    def test_passes_not_privileged(self):
        from tools.container_lens.lenses.k8s_manifest import _check_privileged
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app", "securityContext": {"privileged": False}}]
        }}}}]
        findings = _check_privileged(docs, set())
        self.assertEqual(len(findings), 0)


class TestC14LatestTag(unittest.TestCase):
    """Test C-14: latest tag check."""

    def test_detects_latest(self):
        from tools.container_lens.lenses.k8s_manifest import _check_latest_tag
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app", "image": "nginx:latest"}]
        }}}}]
        findings = _check_latest_tag(docs, set())
        self.assertTrue(len(findings) > 0)

    def test_detects_no_tag(self):
        from tools.container_lens.lenses.k8s_manifest import _check_latest_tag
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app", "image": "nginx"}]
        }}}}]
        findings = _check_latest_tag(docs, set())
        self.assertTrue(len(findings) > 0)

    def test_passes_specific_tag(self):
        from tools.container_lens.lenses.k8s_manifest import _check_latest_tag
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app", "image": "nginx:1.25.3"}]
        }}}}]
        findings = _check_latest_tag(docs, set())
        self.assertEqual(len(findings), 0)


class TestC17HostPath(unittest.TestCase):
    """Test C-17: hostPath volume check."""

    def test_detects_host_path(self):
        from tools.container_lens.lenses.k8s_manifest import _check_host_path
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app"}],
            "volumes": [{"name": "data", "hostPath": {"path": "/data"}}],
        }}}}]
        findings = _check_host_path(docs, set())
        self.assertTrue(len(findings) > 0)

    def test_passes_emptydir(self):
        from tools.container_lens.lenses.k8s_manifest import _check_host_path
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{"name": "app"}],
            "volumes": [{"name": "tmp", "emptyDir": {}}],
        }}}}]
        findings = _check_host_path(docs, set())
        self.assertEqual(len(findings), 0)


class TestC18NetworkPolicy(unittest.TestCase):
    """Test C-18: NetworkPolicy check."""

    def test_detects_missing_netpol(self):
        from tools.container_lens.lenses.k8s_manifest import _check_network_policy
        docs = [{"kind": "Deployment"}]
        findings = _check_network_policy(docs, set())
        self.assertTrue(len(findings) > 0)

    def test_passes_with_netpol(self):
        from tools.container_lens.lenses.k8s_manifest import _check_network_policy
        docs = [{"kind": "Deployment"}, {"kind": "NetworkPolicy"}]
        findings = _check_network_policy(docs, set())
        self.assertEqual(len(findings), 0)


class TestC02DeprecatedAPIs(unittest.TestCase):
    """Test C-02: deprecated API check."""

    def test_detects_removed_api(self):
        from tools.container_lens.lenses.k8s_manifest import _check_deprecated_apis
        docs = [{"apiVersion": "extensions/v1beta1", "kind": "Ingress"}]
        findings = _check_deprecated_apis(docs, "1.29", set())
        self.assertTrue(len(findings) > 0)
        self.assertEqual(findings[0]["severity"], "BLOCK")

    def test_passes_current_api(self):
        from tools.container_lens.lenses.k8s_manifest import _check_deprecated_apis
        docs = [{"apiVersion": "networking.k8s.io/v1", "kind": "Ingress"}]
        findings = _check_deprecated_apis(docs, "1.29", set())
        self.assertEqual(len(findings), 0)


class TestC20EnvVarOrdering(unittest.TestCase):
    """Test C-20: env var ordering check."""

    def test_detects_forward_reference(self):
        from tools.container_lens.lenses.k8s_manifest import _check_env_var_ordering
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{
                "name": "app",
                "env": [
                    {"name": "URL", "value": "http://$(HOST):8080"},
                    {"name": "HOST", "value": "example.com"},
                ]
            }]
        }}}}]
        findings = _check_env_var_ordering(docs, set())
        self.assertTrue(len(findings) > 0)

    def test_passes_correct_order(self):
        from tools.container_lens.lenses.k8s_manifest import _check_env_var_ordering
        docs = [{"kind": "Deployment", "spec": {"template": {"spec": {
            "containers": [{
                "name": "app",
                "env": [
                    {"name": "HOST", "value": "example.com"},
                    {"name": "URL", "value": "http://$(HOST):8080"},
                ]
            }]
        }}}}]
        findings = _check_env_var_ordering(docs, set())
        self.assertEqual(len(findings), 0)


class TestRunLens(unittest.TestCase):
    """Test full lens execution."""

    def test_no_manifests_returns_empty(self):
        from tools.container_lens.lenses.k8s_manifest import run_lens
        result = run_lens({"manifests": None, "skip_checks": set()})
        self.assertEqual(result["lens_name"], "k8s_manifest")
        self.assertEqual(result["checks_run"], 0)

    def test_full_scan_with_findings(self):
        from tools.container_lens.lenses.k8s_manifest import run_lens
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "deploy.yaml").write_text(textwrap.dedent("""\
                apiVersion: apps/v1
                kind: Deployment
                metadata:
                  name: web
                spec:
                  template:
                    spec:
                      containers:
                        - name: app
                          image: nginx:latest
            """), encoding="utf-8")
            result = run_lens({
                "manifests": td,
                "skip_checks": set(),
                "severity_overrides": {},
                "target_k8s_version": "1.29",
            })
            self.assertEqual(result["lens_name"], "k8s_manifest")
            self.assertGreater(result["checks_run"], 0)
            self.assertGreater(len(result["findings"]), 0)
            # Should find: C-03 (no runAsNonRoot), C-05 (priv esc), C-06 (caps),
            # C-08 (limits), C-14 (latest tag), etc.
            check_ids = {f["check_id"] for f in result["findings"]}
            self.assertIn("C-14", check_ids)  # latest tag

    def test_severity_override_applied(self):
        from tools.container_lens.lenses.k8s_manifest import run_lens
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "deploy.yaml").write_text(textwrap.dedent("""\
                apiVersion: apps/v1
                kind: Deployment
                metadata:
                  name: web
                spec:
                  template:
                    spec:
                      containers:
                        - name: app
                          image: nginx:latest
            """), encoding="utf-8")
            result = run_lens({
                "manifests": td,
                "skip_checks": set(),
                "severity_overrides": {"C-14": "WARN"},
                "target_k8s_version": "1.29",
            })
            c14_findings = [f for f in result["findings"] if f["check_id"] == "C-14"]
            self.assertTrue(all(f["severity"] == "WARN" for f in c14_findings))


if __name__ == "__main__":
    unittest.main()
