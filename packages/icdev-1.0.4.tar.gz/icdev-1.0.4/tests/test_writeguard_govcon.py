"""WriteGuard GovCon Bridge + Batch + Signal tests (~25 tests)."""
from __future__ import annotations

import sqlite3

import pytest

from tools.writing.govcon_bridge import (
    check_cross_volume_consistency,
    check_shall_compliance,
    get_opportunity_quality_summary,
    get_section_quality,
    validate_win_themes,
)
from tools.writing.batch_analyzer import get_batch, list_batches, run_batch
from tools.writing.signal_registrar import (
    get_writing_signals,
    register_high_frequency_findings,
)


@pytest.fixture
def db_path(tmp_path):
    """Create a temporary database with govcon + writeguard tables."""
    path = tmp_path / "test_govcon.db"
    conn = sqlite3.connect(str(path))
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS rfp_shall_statements (
            id TEXT PRIMARY KEY,
            sam_opportunity_id TEXT,
            proposal_opportunity_id TEXT,
            statement_text TEXT NOT NULL,
            statement_type TEXT NOT NULL DEFAULT 'shall',
            domain_category TEXT,
            keywords TEXT DEFAULT '[]',
            keyword_fingerprint TEXT,
            source_section TEXT,
            content_hash TEXT NOT NULL DEFAULT '',
            extracted_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS proposal_knowledge_base (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            category TEXT DEFAULT 'general',
            domain TEXT DEFAULT '',
            volume_type TEXT DEFAULT '',
            keywords TEXT DEFAULT '[]',
            usage_count INTEGER DEFAULT 0,
            status TEXT DEFAULT 'active',
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS proposal_sections (
            id TEXT PRIMARY KEY,
            volume_id TEXT,
            opportunity_id TEXT,
            title TEXT NOT NULL DEFAULT '',
            section_number TEXT NOT NULL DEFAULT '',
            sort_order INTEGER DEFAULT 0,
            status TEXT DEFAULT 'not_started',
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS proposal_section_drafts (
            id TEXT PRIMARY KEY,
            section_id TEXT,
            opportunity_id TEXT,
            draft_content TEXT,
            draft_method TEXT DEFAULT 'manual',
            domain_category TEXT,
            status TEXT DEFAULT 'draft',
            reviewed_by TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS proposal_opportunities (
            id TEXT PRIMARY KEY,
            title TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS proposal_compliance_matrix (
            id TEXT PRIMARY KEY,
            opportunity_id TEXT,
            requirement_text TEXT,
            response_summary TEXT,
            coverage_level TEXT DEFAULT 'partial',
            nist_control TEXT DEFAULT '',
            section_id TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS wg_analysis_results (
            id TEXT PRIMARY KEY,
            input_text_hash TEXT NOT NULL,
            input_length INTEGER NOT NULL DEFAULT 0,
            mode TEXT NOT NULL DEFAULT 'inline',
            readability_flesch REAL DEFAULT 0.0,
            readability_gunning_fog REAL DEFAULT 0.0,
            readability_grade_level REAL DEFAULT 0.0,
            grammar_error_count INTEGER DEFAULT 0,
            passive_voice_pct REAL DEFAULT 0.0,
            avg_sentence_length REAL DEFAULT 0.0,
            tone_profile TEXT DEFAULT '{}',
            coherence_score REAL DEFAULT 0.0,
            plagiarism_max_similarity REAL DEFAULT 0.0,
            ai_content_score REAL DEFAULT 0.0,
            overall_quality_score REAL DEFAULT 0.0,
            style_guide_id TEXT,
            section_id TEXT,
            opportunity_id TEXT,
            document_name TEXT DEFAULT '',
            findings_count INTEGER DEFAULT 0,
            analysis_duration_ms INTEGER DEFAULT 0,
            tenant_id TEXT DEFAULT '',
            project_id TEXT DEFAULT '',
            user_id TEXT DEFAULT '',
            classification TEXT NOT NULL DEFAULT 'CUI',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS wg_analysis_findings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            result_id TEXT NOT NULL,
            category TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'info',
            message TEXT NOT NULL,
            suggestion TEXT DEFAULT '',
            context TEXT DEFAULT '',
            line_number INTEGER DEFAULT 0,
            char_offset INTEGER DEFAULT 0,
            char_length INTEGER DEFAULT 0,
            rule_id TEXT DEFAULT '',
            confidence REAL DEFAULT 1.0,
            auto_fixable INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS wg_batch_runs (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            document_count INTEGER DEFAULT 0,
            completed_count INTEGER DEFAULT 0,
            avg_quality_score REAL DEFAULT 0.0,
            cross_doc_consistency_score REAL DEFAULT 0.0,
            status TEXT DEFAULT 'pending',
            summary TEXT DEFAULT '{}',
            tenant_id TEXT DEFAULT '',
            project_id TEXT DEFAULT '',
            created_by TEXT DEFAULT '',
            classification TEXT NOT NULL DEFAULT 'CUI',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS wg_style_guides (
            id TEXT NOT NULL,
            scope TEXT NOT NULL,
            scope_id TEXT NOT NULL,
            version INTEGER NOT NULL DEFAULT 1,
            guide_name TEXT NOT NULL,
            guide_yaml TEXT NOT NULL,
            inherits_from TEXT,
            created_by TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            is_active INTEGER DEFAULT 1,
            change_summary TEXT,
            classification TEXT DEFAULT 'CUI',
            PRIMARY KEY (id, version)
        );
        CREATE TABLE IF NOT EXISTS wg_style_guide_locks (
            id TEXT PRIMARY KEY,
            guide_id TEXT NOT NULL,
            dimension_path TEXT NOT NULL,
            lock_owner_role TEXT NOT NULL,
            locked_by TEXT NOT NULL,
            locked_at TEXT NOT NULL DEFAULT (datetime('now')),
            reason TEXT,
            is_active INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS wg_snippets (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            category TEXT NOT NULL,
            domain TEXT DEFAULT 'general',
            tags TEXT DEFAULT '[]',
            usage_count INTEGER DEFAULT 0,
            status TEXT DEFAULT 'active',
            tenant_id TEXT DEFAULT '',
            project_id TEXT DEFAULT '',
            created_by TEXT DEFAULT '',
            classification TEXT NOT NULL DEFAULT 'CUI',
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS innovation_signals (
            id TEXT PRIMARY KEY,
            source TEXT,
            source_type TEXT,
            title TEXT,
            description TEXT,
            url TEXT DEFAULT '',
            raw_content TEXT DEFAULT '',
            content_hash TEXT DEFAULT '',
            relevance_score REAL DEFAULT 0.0,
            status TEXT DEFAULT 'new',
            created_at TEXT DEFAULT (datetime('now'))
        );
    """)
    conn.close()
    return str(path)


def _seed_shalls(db_path, opportunity_id="opp-1"):
    """Seed shall statements for testing."""
    conn = sqlite3.connect(db_path)
    for i in range(3):
        conn.execute(
            """INSERT INTO rfp_shall_statements
               (id, proposal_opportunity_id, statement_text, statement_type, domain_category, keywords, content_hash)
               VALUES (?, ?, ?, 'shall', ?, '[]', ?)""",
            (f"shall-{i}", opportunity_id,
             f"The contractor shall provide item {i} with full compliance.",
             "devsecops", f"hash-{i}"),
        )
    conn.commit()
    conn.close()


def _seed_knowledge(db_path):
    """Seed knowledge base for win theme testing."""
    conn = sqlite3.connect(db_path)
    conn.execute(
        "INSERT INTO proposal_knowledge_base (id, title, content, category) VALUES (?, ?, ?, ?)",
        ("kb-1", "Differentiator: AI Security", "Our AI security platform is unique.", "differentiator"),
    )
    conn.commit()
    conn.close()


# ── GovCon Bridge ──────────────────────────────────────────────────


class TestCheckShallCompliance:

    def test_returns_dict(self, db_path):
        result = check_shall_compliance("Some text.", "opp-1", db_path=db_path)
        assert isinstance(result, dict)

    def test_no_shalls_returns_note(self, db_path):
        result = check_shall_compliance("Some text.", "opp-empty", db_path=db_path)
        assert "note" in result or result.get("total_shalls") == 0

    def test_with_shalls(self, db_path):
        _seed_shalls(db_path)
        result = check_shall_compliance(
            "We will provide item 0 with full compliance and item 1 support.",
            "opp-1", db_path=db_path,
        )
        assert "coverage_pct" in result
        assert result["total_shalls"] == 3

    def test_has_covered_and_missed(self, db_path):
        _seed_shalls(db_path)
        result = check_shall_compliance("Unrelated text.", "opp-1", db_path=db_path)
        assert "covered" in result
        assert "missed" in result


class TestValidateWinThemes:

    def test_returns_dict(self, db_path):
        result = validate_win_themes("Some text.", "opp-1", db_path=db_path)
        assert isinstance(result, dict)

    def test_with_knowledge_base(self, db_path):
        _seed_knowledge(db_path)
        result = validate_win_themes(
            "Our AI security platform is unique.", "opp-1", db_path=db_path,
        )
        assert "themes_found" in result or "note" in result


class TestCrossVolumeConsistency:

    def test_returns_dict(self, db_path):
        result = check_cross_volume_consistency("opp-1", db_path=db_path)
        assert isinstance(result, dict)

    def test_no_sections_returns_note(self, db_path):
        result = check_cross_volume_consistency("opp-empty", db_path=db_path)
        assert "note" in result or result.get("sections_checked") == 0


class TestGetSectionQuality:

    def test_no_results_returns_none(self, db_path):
        result = get_section_quality("sec-nonexistent", db_path=db_path)
        assert result is None


class TestGetOpportunityQualitySummary:

    def test_no_results_returns_note(self, db_path):
        result = get_opportunity_quality_summary("opp-empty", db_path=db_path)
        assert "note" in result or result.get("section_count") == 0


# ── Batch Analyzer ─────────────────────────────────────────────────


class TestRunBatch:

    def test_returns_dict(self, db_path):
        docs = [
            {"name": "doc1.txt", "text": "First document."},
            {"name": "doc2.txt", "text": "Second document."},
        ]
        result = run_batch(docs, db_path=db_path)
        assert isinstance(result, dict)

    def test_has_batch_id(self, db_path):
        docs = [{"name": "test.txt", "text": "Test document content."}]
        result = run_batch(docs, db_path=db_path)
        assert "batch_id" in result

    def test_document_count(self, db_path):
        docs = [
            {"name": "a.txt", "text": "Alpha."},
            {"name": "b.txt", "text": "Bravo."},
            {"name": "c.txt", "text": "Charlie."},
        ]
        result = run_batch(docs, db_path=db_path)
        assert result["document_count"] == 3

    def test_empty_documents(self, db_path):
        result = run_batch([], db_path=db_path)
        assert result.get("document_count") == 0 or "error" in result

    def test_has_cross_doc_findings(self, db_path):
        docs = [
            {"name": "d1.txt", "text": "High quality text."},
            {"name": "d2.txt", "text": "Another document."},
        ]
        result = run_batch(docs, db_path=db_path)
        assert "cross_doc_findings" in result


class TestGetBatch:

    def test_nonexistent(self, db_path):
        result = get_batch("no-such-batch", db_path=db_path)
        assert "error" in result or result == {}


class TestListBatches:

    def test_empty_list(self, db_path):
        result = list_batches(db_path=db_path)
        assert isinstance(result, list)


# ── Signal Registrar ───────────────────────────────────────────────


class TestRegisterHighFrequencyFindings:

    def test_returns_dict(self, db_path):
        result = register_high_frequency_findings(db_path=db_path)
        assert isinstance(result, dict)
        assert "signals_registered" in result

    def test_no_findings_zero_signals(self, db_path):
        result = register_high_frequency_findings(db_path=db_path)
        assert result["signals_registered"] == 0


class TestGetWritingSignals:

    def test_returns_list(self, db_path):
        result = get_writing_signals(db_path=db_path)
        assert isinstance(result, list)
