#!/usr/bin/env python3
# CUI // SP-CTI
"""Tests for FIPS 140-3 compliance checks."""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tools.container_lens.utils.fips_checker import (
    check_fips_base_image,
    check_fips_openssl,
    check_python_hashlib_fips,
)
from tools.container_lens.lenses.security_compliance import run_lens


# ===========================================================================
# FIPS base image
# ===========================================================================

class TestFipsBaseImage:
    def test_alpine_fails(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_text("FROM python:3.12-alpine\nCOPY . .\n", encoding="utf-8")
        ok, detail = check_fips_base_image(df)
        assert not ok
        assert "alpine" in detail.lower() or "FIPS" in detail

    def test_ironbank_passes(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_text(
            "FROM registry1.dso.mil/ironbank/python:3.12\nCOPY . .\n",
            encoding="utf-8",
        )
        ok, _ = check_fips_base_image(df)
        assert ok

    def test_ubi_passes(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_text(
            "FROM registry.access.redhat.com/ubi9/python-312\nCOPY . .\n",
            encoding="utf-8",
        )
        ok, _ = check_fips_base_image(df)
        assert ok

    def test_distroless_fails(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_text(
            "FROM gcr.io/distroless/python3\nCOPY . .\n",
            encoding="utf-8",
        )
        ok, detail = check_fips_base_image(df)
        assert not ok

    def test_multistage_checks_final(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_text(
            "FROM python:3.12-alpine AS builder\n"
            "RUN pip install flask\n"
            "FROM registry1.dso.mil/ironbank/python:3.12\n"
            "COPY --from=builder /app /app\n",
            encoding="utf-8",
        )
        ok, _ = check_fips_base_image(df)
        assert ok  # Final stage is Iron Bank

    def test_no_dockerfile(self):
        ok, _ = check_fips_base_image(None)
        assert ok

    def test_template_variable(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_text("FROM ${BASE_IMAGE}\nCOPY . .\n", encoding="utf-8")
        ok, detail = check_fips_base_image(df)
        assert ok
        assert "Template" in detail or "skipped" in detail.lower()


# ===========================================================================
# FIPS OpenSSL
# ===========================================================================

class TestFipsOpenssl:
    def test_no_fips_with_ssl(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_text(
            "FROM python:3.12\n"
            "RUN apt-get install -y openssl\n"
            "COPY . .\n",
            encoding="utf-8",
        )
        ok, detail = check_fips_openssl(df)
        assert not ok
        assert "FIPS" in detail

    def test_fips_env_set(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_text(
            "FROM python:3.12\n"
            "ENV OPENSSL_FIPS=1\n"
            "COPY . .\n",
            encoding="utf-8",
        )
        ok, _ = check_fips_openssl(df)
        assert ok

    def test_no_crypto_ok(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_text(
            "FROM python:3.12\n"
            "COPY . .\n"
            "CMD python app.py\n",
            encoding="utf-8",
        )
        ok, _ = check_fips_openssl(df)
        assert ok

    def test_no_dockerfile(self):
        ok, _ = check_fips_openssl(None)
        assert ok


# ===========================================================================
# FIPS Python hashlib
# ===========================================================================

class TestFipsHashlib:
    def test_unsafe_md5(self, tmp_path):
        src = tmp_path / "app.py"
        src.write_text("import hashlib\nh = hashlib.md5(data)\n", encoding="utf-8")
        findings = check_python_hashlib_fips(tmp_path)
        assert len(findings) == 1
        assert "md5" in findings[0]["code"]

    def test_safe_md5(self, tmp_path):
        src = tmp_path / "app.py"
        src.write_text(
            "import hashlib\n"
            "h = hashlib.md5(data, usedforsecurity=False)\n",
            encoding="utf-8",
        )
        findings = check_python_hashlib_fips(tmp_path)
        assert len(findings) == 0

    def test_sha256_ok(self, tmp_path):
        src = tmp_path / "app.py"
        src.write_text("import hashlib\nh = hashlib.sha256(data)\n", encoding="utf-8")
        findings = check_python_hashlib_fips(tmp_path)
        assert len(findings) == 0

    def test_skips_test_files(self, tmp_path):
        test_dir = tmp_path / "tests"
        test_dir.mkdir()
        src = test_dir / "test_app.py"
        src.write_text("import hashlib\nh = hashlib.md5(data)\n", encoding="utf-8")
        findings = check_python_hashlib_fips(tmp_path)
        assert len(findings) == 0

    def test_no_project_dir(self):
        findings = check_python_hashlib_fips(None)
        assert len(findings) == 0


# ===========================================================================
# Integration: E-11/E-12 in run_lens
# ===========================================================================

class TestFipsInLens:
    def test_fips_checks_skip_commercial(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_text("FROM python:3.12-alpine\nCOPY . .\n", encoding="utf-8")
        config = {
            "dockerfile": df,
            "project_dir": tmp_path,
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "commercial",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        e11 = [f for f in result["findings"] if f["check_id"] == "E-11"]
        assert len(e11) == 0  # FIPS only for DoD

    def test_fips_checks_dod_alpine_blocks(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_text("FROM python:3.12-alpine\nCOPY . .\n", encoding="utf-8")
        config = {
            "dockerfile": df,
            "project_dir": tmp_path,
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "dod-il4",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        e11 = [f for f in result["findings"] if f["check_id"] == "E-11"]
        assert len(e11) == 1
        assert e11[0]["severity"] == "BLOCK"

    def test_fips_ironbank_passes_dod(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_text(
            "FROM registry1.dso.mil/ironbank/python:3.12\nCOPY . .\n",
            encoding="utf-8",
        )
        config = {
            "dockerfile": df,
            "project_dir": tmp_path,
            "skip_checks": set(),
            "severity_overrides": {},
            "profile_name": "dod-il4",
            "profile": {"thresholds": {}},
        }
        result = run_lens(config)
        e11 = [f for f in result["findings"] if f["check_id"] == "E-11"]
        assert len(e11) == 0
