# CUI // SP-CTI
"""Tests for runbook DAG validator — Kahn's algorithm, cycle detection, conditions."""

import pytest

from tools.cloudforge.runbooks.models import RunbookEdge, RunbookTask
from tools.cloudforge.runbooks.dag_validator import (
    evaluate_condition,
    validate_dag,
)


# ─── FIXTURES ────────────────────────────────────────────────────────────────


def _task(tid: str, name: str = "", action: str = "noop", **kwargs) -> RunbookTask:
    return RunbookTask(id=tid, name=name or tid, action=action, **kwargs)


def _edge(src: str, tgt: str, **kwargs) -> RunbookEdge:
    return RunbookEdge(source=src, target=tgt, **kwargs)


# ─── VALID DAGs ──────────────────────────────────────────────────────────────


class TestValidDags:
    def test_single_task(self):
        result = validate_dag([_task("t1")], [])
        assert result["valid"] is True
        assert result["topological_order"] == ["t1"]
        assert result["parallel_paths"] == 1

    def test_linear_chain(self):
        tasks = [_task("t1"), _task("t2"), _task("t3")]
        edges = [_edge("t1", "t2"), _edge("t2", "t3")]
        result = validate_dag(tasks, edges)
        assert result["valid"] is True
        assert result["topological_order"] == ["t1", "t2", "t3"]
        assert result["parallel_paths"] == 1

    def test_diamond_dag(self):
        tasks = [_task("t1"), _task("t2"), _task("t3"), _task("t4")]
        edges = [
            _edge("t1", "t2"),
            _edge("t1", "t3"),
            _edge("t2", "t4"),
            _edge("t3", "t4"),
        ]
        result = validate_dag(tasks, edges)
        assert result["valid"] is True
        assert result["parallel_paths"] == 2
        # t1 must come first, t4 must come last
        order = result["topological_order"]
        assert order[0] == "t1"
        assert order[-1] == "t4"

    def test_wide_fan_out(self):
        tasks = [_task("root")] + [_task(f"t{i}") for i in range(5)]
        edges = [_edge("root", f"t{i}") for i in range(5)]
        result = validate_dag(tasks, edges)
        assert result["valid"] is True
        assert result["parallel_paths"] == 5

    def test_empty_dag(self):
        result = validate_dag([], [])
        assert result["valid"] is True
        assert result["topological_order"] == []


# ─── INVALID DAGs ────────────────────────────────────────────────────────────


class TestInvalidDags:
    def test_simple_cycle(self):
        tasks = [_task("t1"), _task("t2")]
        edges = [_edge("t1", "t2"), _edge("t2", "t1")]
        result = validate_dag(tasks, edges)
        assert result["valid"] is False
        assert any("cycle" in e.lower() for e in result["errors"])

    def test_self_loop(self):
        tasks = [_task("t1")]
        edges = [_edge("t1", "t1")]
        result = validate_dag(tasks, edges)
        assert result["valid"] is False
        assert any("self-loop" in e.lower() for e in result["errors"])

    def test_edge_references_missing_task(self):
        tasks = [_task("t1")]
        edges = [_edge("t1", "t_missing")]
        result = validate_dag(tasks, edges)
        assert result["valid"] is False
        assert any("t_missing" in e for e in result["errors"])

    def test_duplicate_task_ids(self):
        tasks = [_task("t1"), _task("t1")]
        edges = []
        result = validate_dag(tasks, edges)
        assert result["valid"] is False
        assert any("duplicate" in e.lower() for e in result["errors"])

    def test_three_node_cycle(self):
        tasks = [_task("t1"), _task("t2"), _task("t3")]
        edges = [_edge("t1", "t2"), _edge("t2", "t3"), _edge("t3", "t1")]
        result = validate_dag(tasks, edges)
        assert result["valid"] is False


# ─── WARNINGS ────────────────────────────────────────────────────────────────


class TestWarnings:
    def test_orphan_task_warning(self):
        tasks = [_task("t1"), _task("t2"), _task("orphan")]
        edges = [_edge("t1", "t2")]
        result = validate_dag(tasks, edges)
        assert result["valid"] is True
        assert any("orphan" in w.lower() for w in result["warnings"])


# ─── CONDITION EVALUATION (D-CF-25) ─────────────────────────────────────────


class TestConditionEvaluation:
    def test_eq_match(self):
        assert evaluate_condition({"key": "env", "operator": "eq", "value": "prod"}, {"env": "prod"}) is True

    def test_eq_no_match(self):
        assert evaluate_condition({"key": "env", "operator": "eq", "value": "prod"}, {"env": "dev"}) is False

    def test_ne(self):
        assert evaluate_condition({"key": "x", "operator": "ne", "value": "a"}, {"x": "b"}) is True

    def test_gt_numeric(self):
        assert evaluate_condition({"key": "count", "operator": "gt", "value": "5"}, {"count": 10}) is True
        assert evaluate_condition({"key": "count", "operator": "gt", "value": "5"}, {"count": 3}) is False

    def test_lt_numeric(self):
        assert evaluate_condition({"key": "count", "operator": "lt", "value": "5"}, {"count": 3}) is True

    def test_gte_lte(self):
        assert evaluate_condition({"key": "n", "operator": "gte", "value": "5"}, {"n": 5}) is True
        assert evaluate_condition({"key": "n", "operator": "lte", "value": "5"}, {"n": 5}) is True

    def test_contains(self):
        assert evaluate_condition({"key": "msg", "operator": "contains", "value": "error"}, {"msg": "found error here"}) is True

    def test_in_operator(self):
        assert evaluate_condition({"key": "status", "operator": "in", "value": "active,pending"}, {"status": "active"}) is True

    def test_missing_key_returns_false(self):
        assert evaluate_condition({"key": "missing", "operator": "eq", "value": "x"}, {}) is False

    def test_none_condition_returns_true(self):
        assert evaluate_condition(None, {}) is True

    def test_empty_condition_returns_true(self):
        assert evaluate_condition({}, {}) is True


# ─── CONDITION VALIDATION ────────────────────────────────────────────────────


class TestConditionValidation:
    def test_invalid_operator_in_task(self):
        task = _task("t1", condition={"key": "x", "operator": "INVALID", "value": "y"})
        result = validate_dag([task], [])
        assert result["valid"] is False
        assert any("invalid operator" in e.lower() for e in result["errors"])

    def test_missing_key_in_condition(self):
        task = _task("t1", condition={"operator": "eq", "value": "y"})
        result = validate_dag([task], [])
        assert result["valid"] is False
        assert any("missing" in e.lower() for e in result["errors"])
