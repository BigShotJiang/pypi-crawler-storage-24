# CUI // SP-CTI
"""Tests for DMN-Lite Decision Engine.

Classification: CUI // SP-CTI
"""

import json
import pytest
from unittest.mock import patch, MagicMock

from tools.decisions.dmn_engine import (
    _feel_match,
    _coerce_numeric,
    evaluate_table,
    list_tables,
    load_table,
    validate_table,
    evaluate_all,
    HitPolicy,
    _match_rule,
    _extract_outputs,
    _default_outputs,
)


# ---------------------------------------------------------------------------
# FEEL expression matching
# ---------------------------------------------------------------------------

class TestFeelMatch:
    """Test FEEL-subset expression matching."""

    def test_wildcard_dash(self):
        assert _feel_match("-", "anything") is True

    def test_wildcard_star(self):
        assert _feel_match("*", "anything") is True

    def test_wildcard_empty(self):
        assert _feel_match("", "anything") is True

    def test_literal_string_match(self):
        assert _feel_match("CUI", "CUI") is True
        assert _feel_match("CUI", "FOUO") is False

    def test_literal_case_insensitive(self):
        assert _feel_match("cui", "CUI") is True
        assert _feel_match("CUI", "cui") is True

    def test_literal_numeric(self):
        assert _feel_match("42", 42) is True
        assert _feel_match("42", 43) is False

    def test_boolean_true(self):
        assert _feel_match("true", True) is True
        assert _feel_match("true", 1) is True
        assert _feel_match("true", False) is False

    def test_boolean_false(self):
        assert _feel_match("false", False) is True
        assert _feel_match("false", 0) is True
        assert _feel_match("false", True) is False

    # Comparison operators
    def test_greater_than(self):
        assert _feel_match("> 5", 10) is True
        assert _feel_match("> 5", 5) is False
        assert _feel_match("> 5", 3) is False

    def test_less_than(self):
        assert _feel_match("< 10", 5) is True
        assert _feel_match("< 10", 10) is False

    def test_greater_equal(self):
        assert _feel_match(">= 5", 5) is True
        assert _feel_match(">= 5", 6) is True
        assert _feel_match(">= 5", 4) is False

    def test_less_equal(self):
        assert _feel_match("<= 10", 10) is True
        assert _feel_match("<= 10", 9) is True
        assert _feel_match("<= 10", 11) is False

    def test_not_equal(self):
        assert _feel_match("!= blocked", "active") is True
        assert _feel_match("!= blocked", "blocked") is False

    def test_equal_operator(self):
        assert _feel_match("= active", "active") is True
        assert _feel_match("= active", "blocked") is False

    # Range expressions
    def test_range_inclusive(self):
        assert _feel_match("[1..10]", 1) is True
        assert _feel_match("[1..10]", 10) is True
        assert _feel_match("[1..10]", 5) is True
        assert _feel_match("[1..10]", 0) is False
        assert _feel_match("[1..10]", 11) is False

    def test_range_exclusive(self):
        assert _feel_match("(0..1.0)", 0.5) is True
        assert _feel_match("(0..1.0)", 0) is False
        assert _feel_match("(0..1.0)", 1.0) is False

    def test_range_mixed(self):
        assert _feel_match("[0..100)", 0) is True
        assert _feel_match("[0..100)", 99) is True
        assert _feel_match("[0..100)", 100) is False

    def test_range_float(self):
        assert _feel_match("[0.2..0.8]", 0.5) is True
        assert _feel_match("[0.2..0.8]", 0.1) is False

    # List expressions
    def test_comma_list(self):
        assert _feel_match("low, medium, high", "medium") is True
        assert _feel_match("low, medium, high", "critical") is False

    def test_comma_list_case_insensitive(self):
        assert _feel_match("CAC, PIV, MFA", "cac") is True
        assert _feel_match("CAC, PIV, MFA", "password") is False

    # Negation
    def test_not_literal(self):
        assert _feel_match("not(blocked)", "active") is True
        assert _feel_match("not(blocked)", "blocked") is False

    def test_not_comparison(self):
        assert _feel_match("not(> 10)", 5) is True
        assert _feel_match("not(> 10)", 15) is False

    # Non-numeric with comparison
    def test_string_comparison(self):
        assert _feel_match("!= none", "MFA") is True
        assert _feel_match("!= none", "none") is False


class TestCoerceNumeric:
    """Test numeric coercion."""

    def test_int(self):
        assert _coerce_numeric("42") == 42

    def test_float(self):
        assert _coerce_numeric("3.14") == 3.14

    def test_passthrough_int(self):
        assert _coerce_numeric(42) == 42

    def test_passthrough_string(self):
        assert _coerce_numeric("hello") == "hello"


# ---------------------------------------------------------------------------
# Rule matching
# ---------------------------------------------------------------------------

class TestMatchRule:
    """Test rule matching logic."""

    def test_empty_when_matches_all(self):
        rule = {"when": {}, "then": {"result": "default"}}
        inputs = [{"name": "x"}]
        assert _match_rule(rule, inputs, {"x": "anything"}) is True

    def test_simple_match(self):
        rule = {"when": {"color": "red"}, "then": {"action": "stop"}}
        inputs = [{"name": "color"}]
        assert _match_rule(rule, inputs, {"color": "red"}) is True
        assert _match_rule(rule, inputs, {"color": "green"}) is False

    def test_multiple_conditions_and(self):
        rule = {"when": {"a": "> 5", "b": "yes"}, "then": {"out": 1}}
        inputs = [{"name": "a"}, {"name": "b"}]
        assert _match_rule(rule, inputs, {"a": 10, "b": "yes"}) is True
        assert _match_rule(rule, inputs, {"a": 3, "b": "yes"}) is False
        assert _match_rule(rule, inputs, {"a": 10, "b": "no"}) is False

    def test_missing_input_no_match(self):
        rule = {"when": {"x": "required"}, "then": {"out": 1}}
        inputs = [{"name": "x"}]
        assert _match_rule(rule, inputs, {}) is False

    def test_wildcard_condition(self):
        rule = {"when": {"x": "-"}, "then": {"out": 1}}
        inputs = [{"name": "x"}]
        assert _match_rule(rule, inputs, {"x": "anything"}) is True


class TestExtractOutputs:
    """Test output extraction."""

    def test_basic_output(self):
        rule = {"then": {"action": "stop", "color": "red"}}
        outputs = [{"name": "action"}, {"name": "color"}]
        result = _extract_outputs(rule, outputs)
        assert result == {"action": "stop", "color": "red"}

    def test_default_output(self):
        rule = {"then": {}}
        outputs = [{"name": "action", "default": "continue"}]
        result = _extract_outputs(rule, outputs)
        assert result == {"action": "continue"}

    def test_missing_no_default(self):
        rule = {"then": {}}
        outputs = [{"name": "action"}]
        result = _extract_outputs(rule, outputs)
        assert result == {}


class TestDefaultOutputs:
    """Test default output generation."""

    def test_with_defaults(self):
        outputs = [
            {"name": "a", "default": "x"},
            {"name": "b", "default": 0},
        ]
        result = _default_outputs(outputs)
        assert result == {"a": "x", "b": 0}

    def test_without_defaults(self):
        outputs = [{"name": "a"}]
        result = _default_outputs(outputs)
        assert result == {"a": None}


# ---------------------------------------------------------------------------
# Table loading and evaluation (integration with YAML files)
# ---------------------------------------------------------------------------

class TestListTables:
    """Test listing available tables."""

    def test_list_returns_tables(self):
        tables = list_tables()
        assert isinstance(tables, list)
        # We created 3 example tables
        names = [t["name"] for t in tables]
        assert "ato_boundary_impact" in names
        assert "deployment_approval" in names
        assert "agent_trust_decision" in names

    def test_table_metadata(self):
        tables = list_tables()
        ato_table = next(t for t in tables if t["name"] == "ato_boundary_impact")
        assert ato_table["hit_policy"] == "FIRST"
        assert ato_table["rule_count"] > 0
        assert "CA-3" in ato_table["controls"]
        assert len(ato_table["inputs"]) > 0
        assert len(ato_table["outputs"]) > 0


class TestLoadTable:
    """Test table loading."""

    def test_load_existing(self):
        table = load_table("ato_boundary_impact")
        assert table["name"] == "ato_boundary_impact"
        assert table["hit_policy"] == "FIRST"
        assert len(table["inputs"]) == 3
        assert len(table["outputs"]) == 3

    def test_load_nonexistent(self):
        with pytest.raises(FileNotFoundError):
            load_table("nonexistent_table")


class TestValidateTable:
    """Test table validation."""

    def test_validate_valid_table(self):
        result = validate_table("ato_boundary_impact")
        assert result["valid"] is True
        assert len(result["errors"]) == 0

    def test_validate_nonexistent(self):
        result = validate_table("nonexistent")
        assert result["valid"] is False


class TestEvaluateTable:
    """Test decision table evaluation."""

    @patch("tools.decisions.dmn_engine._log_decision")
    def test_ato_red_secret(self, mock_log):
        """SECRET data should trigger RED impact tier."""
        result = evaluate_table("ato_boundary_impact", {
            "data_sensitivity": "SECRET",
            "external_connections": 0,
            "authentication_method": "CAC",
        })
        assert result["outputs"]["impact_tier"] == "RED"
        assert result["outputs"]["ato_reauthorization"] is True
        assert result["matched_count"] >= 1

    @patch("tools.decisions.dmn_engine._log_decision")
    def test_ato_red_no_auth(self, mock_log):
        """No auth on external connections should be RED."""
        result = evaluate_table("ato_boundary_impact", {
            "data_sensitivity": "CUI",
            "external_connections": 1,
            "authentication_method": "none",
        })
        assert result["outputs"]["impact_tier"] == "RED"

    @patch("tools.decisions.dmn_engine._log_decision")
    def test_ato_green_public(self, mock_log):
        """Public data with no external connections should be GREEN."""
        result = evaluate_table("ato_boundary_impact", {
            "data_sensitivity": "public",
            "external_connections": 0,
            "authentication_method": "CAC",
        })
        assert result["outputs"]["impact_tier"] == "GREEN"

    @patch("tools.decisions.dmn_engine._log_decision")
    def test_deployment_blocked_critical_vulns(self, mock_log):
        """Critical vulnerabilities block all deployments."""
        result = evaluate_table("deployment_approval", {
            "environment": "production",
            "test_coverage_pct": 95,
            "critical_vulns": 1,
            "compliance_score": 0.95,
            "stig_cat1_findings": 0,
        })
        assert result["outputs"]["approval_level"] == "blocked"
        assert result["outputs"]["auto_deploy"] is False

    @patch("tools.decisions.dmn_engine._log_decision")
    def test_deployment_dev_auto(self, mock_log):
        """Development auto-deploys with no critical vulns."""
        result = evaluate_table("deployment_approval", {
            "environment": "development",
            "test_coverage_pct": 50,
            "critical_vulns": 0,
            "compliance_score": 0.6,
            "stig_cat1_findings": 0,
        })
        assert result["outputs"]["approval_level"] == "auto"
        assert result["outputs"]["auto_deploy"] is True

    @patch("tools.decisions.dmn_engine._log_decision")
    def test_agent_trust_quarantine(self, mock_log):
        """Very low trust score should quarantine."""
        result = evaluate_table("agent_trust_decision", {
            "trust_score": 0.1,
            "behavioral_drift": 0.5,
            "consecutive_failures": 3,
            "tool_chain_valid": True,
        })
        assert result["outputs"]["action"] == "quarantine"
        assert result["outputs"]["escalate"] is True

    @patch("tools.decisions.dmn_engine._log_decision")
    def test_agent_trust_autonomous(self, mock_log):
        """High trust, low drift should grant full autonomy."""
        result = evaluate_table("agent_trust_decision", {
            "trust_score": 0.9,
            "behavioral_drift": 0.1,
            "consecutive_failures": 0,
            "tool_chain_valid": True,
        })
        assert result["outputs"]["action"] == "allow"
        assert result["outputs"]["autonomy_level"] == "autonomous"

    @patch("tools.decisions.dmn_engine._log_decision")
    def test_trace_mode(self, mock_log):
        """Trace mode should include rule-by-rule trace."""
        result = evaluate_table("ato_boundary_impact", {
            "data_sensitivity": "SECRET",
        }, trace=True)
        assert "trace" in result
        assert len(result["trace"]) > 0
        assert result["trace"][0]["matched"] is True

    @patch("tools.decisions.dmn_engine._log_decision")
    def test_result_metadata(self, mock_log):
        """Results should include metadata."""
        result = evaluate_table("ato_boundary_impact", {
            "data_sensitivity": "public",
            "external_connections": 0,
            "authentication_method": "CAC",
        })
        assert "decision_id" in result
        assert "evaluated_at" in result
        assert result["classification"] == "CUI // SP-CTI"
        assert result["table"] == "ato_boundary_impact"
        assert result["hit_policy"] == "FIRST"
        assert "controls" in result

    @patch("tools.decisions.dmn_engine._log_decision")
    def test_no_match_returns_defaults(self, mock_log):
        """No matching rules should return default outputs."""
        result = evaluate_table("ato_boundary_impact", {
            "data_sensitivity": "UNKNOWN_LEVEL",
            "external_connections": 999,
            "authentication_method": "UNKNOWN",
        })
        assert result["matched_count"] == 0
        # Should return defaults from output definitions
        assert "impact_tier" in result["outputs"]


class TestEvaluateAll:
    """Test batch evaluation."""

    @patch("tools.decisions.dmn_engine._log_decision")
    def test_evaluate_all_tables(self, mock_log):
        """Evaluate all tables with same context."""
        result = evaluate_all({
            "data_sensitivity": "CUI",
            "external_connections": 1,
            "authentication_method": "CAC",
            "environment": "production",
            "test_coverage_pct": 90,
            "critical_vulns": 0,
            "compliance_score": 0.9,
            "stig_cat1_findings": 0,
            "trust_score": 0.8,
            "behavioral_drift": 0.1,
            "consecutive_failures": 0,
            "tool_chain_valid": True,
        })
        assert result["tables_evaluated"] >= 3
        assert "results" in result
        assert "ato_boundary_impact" in result["results"]
        assert "deployment_approval" in result["results"]

    @patch("tools.decisions.dmn_engine._log_decision")
    def test_evaluate_specific_tables(self, mock_log):
        """Evaluate only specified tables."""
        result = evaluate_all(
            {"data_sensitivity": "CUI"},
            tables=["ato_boundary_impact"],
        )
        assert result["tables_evaluated"] == 1
        assert "ato_boundary_impact" in result["results"]


class TestHitPolicy:
    """Test hit policy constants."""

    def test_all_policies(self):
        assert HitPolicy.FIRST == "FIRST"
        assert HitPolicy.UNIQUE == "UNIQUE"
        assert HitPolicy.COLLECT == "COLLECT"
        assert HitPolicy.RULE_ORDER == "RULE_ORDER"
        assert len(HitPolicy.ALL) == 4
