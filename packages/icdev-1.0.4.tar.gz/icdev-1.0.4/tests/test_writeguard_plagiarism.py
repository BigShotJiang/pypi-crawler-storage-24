"""WriteGuard Plagiarism + Tone + Coherence + Rewriter tests (~20 tests)."""
from __future__ import annotations

import pytest

from tools.writing.tone_profiler import profile_tone
from tools.writing.coherence_analyzer import analyze_coherence
from tools.writing.rewriter import rewrite


# ── Tone Profiler ──────────────────────────────────────────────────


class TestProfileTone:

    def test_returns_dict(self):
        result = profile_tone("The team delivered excellent results.")
        assert isinstance(result, dict)

    def test_has_profile(self):
        result = profile_tone("Professional writing sample.")
        assert "profile" in result
        assert isinstance(result["profile"], dict)

    def test_has_dominant_tone(self):
        result = profile_tone("We are confident in our approach.")
        assert "dominant_tone" in result
        assert isinstance(result["dominant_tone"], str)

    def test_has_sentiment(self):
        result = profile_tone("This is a great achievement.")
        assert "sentiment" in result

    def test_has_findings(self):
        result = profile_tone("Test text for findings.")
        assert "findings" in result
        assert isinstance(result["findings"], list)

    def test_has_stats(self):
        result = profile_tone("Test text for statistics.")
        assert "stats" in result
        assert "word_count" in result["stats"]

    def test_empty_text(self):
        result = profile_tone("")
        assert isinstance(result, dict)

    def test_persuasive_text(self):
        text = ("Our innovative solution delivers exceptional value. "
                "We guarantee outstanding results with proven methodology.")
        result = profile_tone(text)
        assert result["dominant_tone"] != ""

    def test_use_llm_false(self):
        result = profile_tone("Simple text.", use_llm=False)
        assert isinstance(result, dict)


# ── Coherence Analyzer ────────────────────────────────────────────


class TestAnalyzeCoherence:

    def test_returns_dict(self):
        result = analyze_coherence("First paragraph. Second paragraph.")
        assert isinstance(result, dict)

    def test_has_coherence_score(self):
        result = analyze_coherence("This text has flow. Furthermore, it continues.")
        assert "coherence_score" in result
        assert 0 <= result["coherence_score"] <= 1

    def test_has_findings(self):
        result = analyze_coherence("Text for findings check.")
        assert "findings" in result
        assert isinstance(result["findings"], list)

    def test_has_transition_analysis(self):
        result = analyze_coherence("First, we plan. Then, we execute.")
        assert "transition_analysis" in result

    def test_has_paragraph_count(self):
        text = "Para one.\n\nPara two.\n\nPara three."
        result = analyze_coherence(text)
        assert "paragraph_count" in result

    def test_has_connectivity_score(self):
        text = "The system provides monitoring.\n\nThe monitoring system tracks metrics."
        result = analyze_coherence(text)
        assert "connectivity_score" in result

    def test_has_topic_drift(self):
        text = "Topic one discusses security.\n\nSecurity controls enforce compliance.\n\nCompliance audits verify controls."
        result = analyze_coherence(text)
        assert "topic_drift" in result

    def test_empty_text(self):
        result = analyze_coherence("")
        assert isinstance(result, dict)

    def test_well_connected_text(self):
        text = (
            "First, we analyze the requirements. "
            "Then, we design the solution. "
            "Furthermore, we implement the code. "
            "Finally, we test and deploy."
        )
        result = analyze_coherence(text)
        assert result["coherence_score"] > 0


# ── Rewriter ──────────────────────────────────────────────────────


class TestRewrite:

    def test_returns_dict(self):
        result = rewrite("Fix this text please.")
        assert isinstance(result, dict)

    def test_has_rewritten_text(self):
        result = rewrite("The report was writed badly.")
        assert "rewritten_text" in result or "status" in result

    def test_has_status(self):
        result = rewrite("Some text to rewrite.")
        assert "status" in result

    def test_empty_text(self):
        result = rewrite("")
        assert result["status"] == "no_input" or isinstance(result, dict)

    def test_with_findings(self):
        findings = [{"category": "grammar", "message": "its/it's confusion",
                     "suggestion": "Use it's"}]
        result = rewrite("Its a good day.", findings=findings)
        assert isinstance(result, dict)

    def test_with_style(self):
        result = rewrite("Fix this text.", style="technical")
        assert isinstance(result, dict)

    def test_max_length(self):
        long_text = "Word " * 6000
        result = rewrite(long_text, max_length=5000)
        assert isinstance(result, dict)

    def test_changes_made_field(self):
        result = rewrite("Some text to check.")
        assert "changes_made" in result or "suggestions" in result or "status" in result
