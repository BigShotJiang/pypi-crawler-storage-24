# CUI // SP-CTI
"""Snapshot tests for compliance artifact outputs (D-ARCH-14 Phase 6).

Validates structural stability of SSP, POAM, SBOM, and OSCAL generators.
Uses a lightweight JSON normalization + file comparison approach (no syrupy).

On first run (or with --update-snapshots pytest flag), snapshot files are
written to tests/snapshots/.  Subsequent runs compare against saved snapshots.

All tests use ICDEV_STORAGE_BACKEND=sqlite and a temporary in-memory or
file-based database seeded with minimal test data.
"""

import json
import os
import re
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import pytest

# ---------------------------------------------------------------------------
# Path setup
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent
SNAPSHOT_DIR = Path(__file__).resolve().parent / "snapshots"
SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)

# Ensure project root is on sys.path for imports
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

# ---------------------------------------------------------------------------
# Lazy imports — skip gracefully if modules unavailable
# ---------------------------------------------------------------------------

try:
    from tools.compliance.ssp_generator import (
        _build_system_info,
        _build_control_section,
        _build_family_summary,
        _load_nist_controls,
        _substitute_variables,
        CONTROL_FAMILIES,
    )
    HAS_SSP = True
except ImportError:
    HAS_SSP = False

try:
    from tools.compliance.poam_generator import (
        _build_poam_detail,
        _build_poam_table_row,
        _stig_severity_to_poam,
        REMEDIATION_TIMELINES,
    )
    HAS_POAM = True
except ImportError:
    HAS_POAM = False

try:
    from tools.compliance.sbom_generator import (
        _build_cyclonedx_sbom,
        _generate_bom_ref,
        _detect_project_type,
        _parse_requirements_txt,
        CYCLONEDX_SPEC_VERSION,
    )
    HAS_SBOM = True
except ImportError:
    HAS_SBOM = False

try:
    from tools.compliance.oscal_generator import (
        _control_id_to_oscal,
        OSCAL_VERSION,
    )
    HAS_OSCAL = True
except ImportError:
    HAS_OSCAL = False


# ---------------------------------------------------------------------------
# pytest flag: --update-snapshots
# ---------------------------------------------------------------------------

def pytest_addoption(parser):
    """Register --update-snapshots CLI flag."""
    try:
        parser.addoption(
            "--update-snapshots",
            action="store_true",
            default=False,
            help="Overwrite existing snapshot files with current output",
        )
    except ValueError:
        pass  # already registered


@pytest.fixture
def update_snapshots(request):
    """Return True when --update-snapshots was passed on the CLI."""
    return request.config.getoption("--update-snapshots", default=False)


# ---------------------------------------------------------------------------
# Snapshot helper
# ---------------------------------------------------------------------------

# Patterns for normalization
_ISO_DATE_RE = re.compile(
    r"\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:\d{2})?\s*(?:UTC)?)?",
)
_UUID_RE = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",
)
_URN_UUID_RE = re.compile(
    r"urn:uuid:[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",
)
_TIMESTAMP_EPOCH_RE = re.compile(r"\d{8}_\d{6}")  # 20260311_235800-style


def normalize(text: str) -> str:
    """Replace volatile values (dates, UUIDs) with stable placeholders."""
    text = _URN_UUID_RE.sub("urn:uuid:NORMALIZED_UUID", text)
    text = _UUID_RE.sub("NORMALIZED_UUID", text)
    text = _TIMESTAMP_EPOCH_RE.sub("NORMALIZED_TIMESTAMP", text)
    text = _ISO_DATE_RE.sub("NORMALIZED_DATE", text)
    return text


def normalize_json(obj):
    """Recursively normalize a Python object (dict/list/str) in place.

    Returns a new object with all date and UUID strings replaced.
    """
    if isinstance(obj, str):
        return normalize(obj)
    if isinstance(obj, dict):
        return {k: normalize_json(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [normalize_json(v) for v in obj]
    return obj


def assert_snapshot(name: str, content: str, update: bool = False):
    """Compare *content* against the snapshot file ``tests/snapshots/<name>``.

    If the snapshot does not exist or *update* is ``True``, write a new one.
    """
    snap_path = SNAPSHOT_DIR / name
    normalized = normalize(content)

    if update or not snap_path.exists():
        snap_path.write_text(normalized, encoding="utf-8")
        return  # first run — nothing to compare against

    expected = snap_path.read_text(encoding="utf-8")
    assert normalized == expected, (
        f"Snapshot mismatch for {name}.\n"
        f"Run with --update-snapshots to accept the new output.\n"
        f"--- expected (first 500 chars) ---\n{expected[:500]}\n"
        f"--- actual (first 500 chars) ---\n{normalized[:500]}"
    )


def assert_json_snapshot(name: str, obj, update: bool = False):
    """JSON-specific snapshot: normalizes then pretty-prints for diffing."""
    normalized_obj = normalize_json(obj)
    content = json.dumps(normalized_obj, indent=2, sort_keys=True)
    assert_snapshot(name, content, update=update)


# ---------------------------------------------------------------------------
# Test fixtures — minimal in-memory database
# ---------------------------------------------------------------------------

@pytest.fixture
def test_project():
    """Return a minimal project dict for testing generators."""
    return {
        "id": "test-snapshot-proj",
        "name": "Snapshot Test System",
        "description": "A test project for compliance snapshot verification",
        "type": "webapp",
        "impact_level": "IL4",
        "directory_path": "",
        "status": "active",
    }


@pytest.fixture
def test_controls():
    """Return a small set of control implementations."""
    return [
        {
            "control_id": "AC-2",
            "implementation_status": "implemented",
            "implementation_description": "Account management via IAM service.",
            "responsible_role": "System Administrator",
            "evidence_path": "/evidence/ac-2.pdf",
        },
        {
            "control_id": "AU-3",
            "implementation_status": "planned",
            "implementation_description": "Audit event content logging planned.",
            "responsible_role": "Security Engineer",
            "evidence_path": "",
        },
        {
            "control_id": "SC-7",
            "implementation_status": "implemented",
            "implementation_description": "Boundary protection via WAF and NSGs.",
            "responsible_role": "Network Engineer",
            "evidence_path": "/evidence/sc-7.pdf",
        },
    ]


@pytest.fixture
def test_components():
    """Return a small set of SBOM components."""
    return [
        {
            "type": "library",
            "name": "flask",
            "version": "3.0.0",
            "purl": "pkg:pypi/flask@3.0.0",
            "scope": "required",
            "group": "",
            "source": "requirements.txt",
        },
        {
            "type": "library",
            "name": "requests",
            "version": "2.31.0",
            "purl": "pkg:pypi/requests@2.31.0",
            "scope": "required",
            "group": "",
            "source": "requirements.txt",
        },
        {
            "type": "library",
            "name": "cryptography",
            "version": "41.0.0",
            "purl": "pkg:pypi/cryptography@41.0.0",
            "scope": "required",
            "group": "",
            "source": "requirements.txt",
        },
    ]


# ---------------------------------------------------------------------------
# SSP snapshot tests
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not HAS_SSP, reason="ssp_generator not importable")
class TestSSPSnapshots:
    """Snapshot tests for SSP generator output structure."""

    def test_ssp_system_info_structure(self, test_project, update_snapshots):
        """SSP system info dict has stable keys and value patterns."""
        info = _build_system_info(test_project, "Snapshot Test System")
        assert_json_snapshot("ssp_system_info.json", info, update=update_snapshots)

    def test_ssp_control_section_structure(self, test_controls, update_snapshots):
        """SSP control section markdown has stable format."""
        nist_controls = {
            "AC-2": {"id": "AC-2", "title": "Account Management"},
            "AU-3": {"id": "AU-3", "title": "Content of Audit Records"},
            "SC-7": {"id": "SC-7", "title": "Boundary Protection"},
        }
        section = _build_control_section(test_controls, nist_controls)
        assert_snapshot("ssp_control_section.md", section, update=update_snapshots)

    def test_ssp_family_summary_counts(self, test_controls, update_snapshots):
        """SSP family summary produces correct count keys for all 17 families."""
        nist_controls = _load_nist_controls()
        if not nist_controls:
            # Provide minimal controls so test still validates structure
            nist_controls = {
                "AC-2": {"id": "AC-2", "title": "Account Management"},
                "AU-3": {"id": "AU-3", "title": "Content of Audit Records"},
                "SC-7": {"id": "SC-7", "title": "Boundary Protection"},
            }
        summary = _build_family_summary(test_controls, nist_controls)

        # Verify all 17 families have keys
        for fam_code in CONTROL_FAMILIES:
            prefix = fam_code.lower()
            assert f"{prefix}_total" in summary, f"Missing {prefix}_total"
            assert f"{prefix}_implemented" in summary, f"Missing {prefix}_implemented"
            assert f"{prefix}_planned" in summary, f"Missing {prefix}_planned"
            assert f"{prefix}_na" in summary, f"Missing {prefix}_na"

        assert "total_controls_required" in summary
        assert "controls_implemented" in summary
        assert_json_snapshot("ssp_family_summary.json", summary, update=update_snapshots)


# ---------------------------------------------------------------------------
# POAM snapshot tests
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not HAS_POAM, reason="poam_generator not importable")
class TestPOAMSnapshots:
    """Snapshot tests for POAM generator output structure."""

    def test_poam_table_row_format(self, update_snapshots):
        """POAM table row has stable column layout."""
        item = {
            "weakness": "Weak password policy",
            "severity": "moderate",
            "control_id": "IA-5",
            "description": "System does not enforce minimum password complexity requirements for local accounts",
            "corrective_action": "Implement password complexity rules via PAM or Group Policy to enforce minimum length and character requirements",
            "resources": "Staff time",
            "milestone_date": "2026-06-15",
            "status": "open",
            "completion_date": "",
            "responsible": "Security Team",
        }
        row = _build_poam_table_row(1, item)
        assert_snapshot("poam_table_row.txt", row, update=update_snapshots)

    def test_poam_detail_section_format(self, update_snapshots):
        """POAM detail section has stable markdown structure."""
        item = {
            "weakness": "Missing MFA",
            "severity": "critical",
            "control_id": "IA-2(1)",
            "description": "Multi-factor authentication is not enabled for privileged accounts.",
            "corrective_action": "Enable MFA via TOTP or hardware tokens for all privileged accounts.",
            "resources": "Staff time, hardware tokens",
            "milestone_date": "2026-04-15",
            "status": "open",
            "completion_date": "",
            "responsible": "IAM Team",
            "source": "STIG Assessment (RHEL8-STIG)",
            "date_identified": "2026-03-01",
        }
        detail = _build_poam_detail(1, item)
        assert_snapshot("poam_detail_section.md", detail, update=update_snapshots)

    def test_poam_severity_mapping(self):
        """STIG-to-POAM severity mapping is deterministic."""
        assert _stig_severity_to_poam("CAT1") == "critical"
        assert _stig_severity_to_poam("CAT2") == "moderate"
        assert _stig_severity_to_poam("CAT3") == "low"
        assert _stig_severity_to_poam("UNKNOWN") == "moderate"


# ---------------------------------------------------------------------------
# SBOM snapshot tests
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not HAS_SBOM, reason="sbom_generator not importable")
class TestSBOMSnapshots:
    """Snapshot tests for SBOM generator output structure."""

    def test_sbom_cyclonedx_structure(self, test_project, test_components, update_snapshots):
        """CycloneDX SBOM JSON has stable top-level structure."""
        sbom, count = _build_cyclonedx_sbom(
            test_project,
            test_components,
            serial_number="urn:uuid:00000000-0000-0000-0000-000000000000",
        )

        assert count == 3
        assert sbom["bomFormat"] == "CycloneDX"
        assert sbom["specVersion"] == CYCLONEDX_SPEC_VERSION
        assert "metadata" in sbom
        assert "components" in sbom
        assert len(sbom["components"]) == 3

        # Verify CUI classification properties are present
        props = sbom["metadata"]["properties"]
        prop_names = [p["name"] for p in props]
        assert "icdev:classification" in prop_names
        assert "icdev:project-id" in prop_names
        assert "icdev:cui-category" in prop_names

        assert_json_snapshot("sbom_cyclonedx.json", sbom, update=update_snapshots)

    def test_sbom_bom_ref_determinism(self, test_components):
        """BOM references are deterministic for the same component."""
        ref1 = _generate_bom_ref(test_components[0])
        ref2 = _generate_bom_ref(test_components[0])
        assert ref1 == ref2
        assert len(ref1) == 16  # SHA-256 truncated to 16 hex chars

        # Different components produce different refs
        ref3 = _generate_bom_ref(test_components[1])
        assert ref1 != ref3

    def test_sbom_deduplication(self, test_project):
        """SBOM deduplicates components by purl."""
        duped = [
            {
                "type": "library",
                "name": "flask",
                "version": "3.0.0",
                "purl": "pkg:pypi/flask@3.0.0",
                "scope": "required",
                "group": "",
                "source": "requirements.txt",
            },
            {
                "type": "library",
                "name": "flask",
                "version": "3.0.0",
                "purl": "pkg:pypi/flask@3.0.0",
                "scope": "required",
                "group": "",
                "source": "pyproject.toml",
            },
        ]
        sbom, count = _build_cyclonedx_sbom(
            test_project,
            duped,
            serial_number="urn:uuid:00000000-0000-0000-0000-000000000000",
        )
        assert count == 1, "Duplicate purl components should be deduplicated"
        assert len(sbom["components"]) == 1


# ---------------------------------------------------------------------------
# OSCAL snapshot tests
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not HAS_OSCAL, reason="oscal_generator not importable")
class TestOSCALSnapshots:
    """Snapshot tests for OSCAL generator output structure."""

    def test_oscal_control_id_normalization(self):
        """Control IDs normalize consistently to OSCAL format."""
        assert _control_id_to_oscal("AC-2") == "ac-2"
        assert _control_id_to_oscal("AC-2(1)") == "ac-2.1"
        assert _control_id_to_oscal("SI-4(4)") == "si-4.4"
        assert _control_id_to_oscal("ac-2") == "ac-2"
        assert _control_id_to_oscal("") == ""
        assert _control_id_to_oscal(None) == ""

    def test_oscal_version_constant(self):
        """OSCAL version is pinned to 1.1.2."""
        assert OSCAL_VERSION == "1.1.2"
