#!/usr/bin/env python3
# CUI // SP-CTI
"""Unit tests for CodeLens/Pro Lens A: File Hygiene."""

import os
import sys
import pytest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tools.container_lens.lenses.file_hygiene import run_lens


def _make_config(tmp_path, dockerfile_content=None, skip=None):
    """Helper to create a lens config dict with optional Dockerfile."""
    df_path = None
    if dockerfile_content is not None:
        df = tmp_path / "Dockerfile"
        df.write_text(dockerfile_content, encoding="utf-8")
        df_path = df
    return {
        "project_dir": tmp_path,
        "dockerfile": df_path,
        "skip_checks": set(skip or []),
        "severity_overrides": {},
    }


def _find(findings, check_id):
    """Find findings matching a check_id."""
    return [f for f in findings if f["check_id"] == check_id]


# ---- A-01: CRLF detection ----

class TestA01Crlf:
    def test_detects_crlf_in_shell_script(self, tmp_path):
        sh = tmp_path / "entrypoint.sh"
        sh.write_bytes(b"#!/bin/bash\r\necho hello\r\n")
        result = run_lens(_make_config(tmp_path))
        matches = _find(result["findings"], "A-01")
        assert len(matches) >= 1
        assert matches[0]["severity"] == "BLOCK"

    def test_passes_lf_only(self, tmp_path):
        sh = tmp_path / "entrypoint.sh"
        sh.write_bytes(b"#!/bin/bash\necho hello\n")
        result = run_lens(_make_config(tmp_path))
        assert not _find(result["findings"], "A-01")

    def test_detects_crlf_in_dockerfile(self, tmp_path):
        df = tmp_path / "Dockerfile"
        df.write_bytes(b"FROM python:3.12\r\nRUN echo hi\r\n")
        result = run_lens(_make_config(tmp_path))
        matches = _find(result["findings"], "A-01")
        assert len(matches) >= 1

    def test_skip_check(self, tmp_path):
        sh = tmp_path / "entrypoint.sh"
        sh.write_bytes(b"#!/bin/bash\r\n")
        result = run_lens(_make_config(tmp_path, skip=["A-01"]))
        assert not _find(result["findings"], "A-01")


# ---- A-03: Case collision ----

class TestA03CaseCollision:
    def test_detects_case_collision(self, tmp_path):
        (tmp_path / "Config.py").write_text("a = 1", encoding="utf-8")
        (tmp_path / "config.py").write_text("b = 2", encoding="utf-8")
        result = run_lens(_make_config(tmp_path))
        matches = _find(result["findings"], "A-03")
        # On Windows (case-insensitive FS), only one file exists, so no collision
        # On Linux, both exist and we detect collision
        # Test is valid on both — just check the mechanism works
        if os.name != "nt":
            assert len(matches) >= 1
            assert matches[0]["severity"] == "BLOCK"

    def test_no_collision(self, tmp_path):
        (tmp_path / "config.py").write_text("a = 1", encoding="utf-8")
        (tmp_path / "utils.py").write_text("b = 2", encoding="utf-8")
        result = run_lens(_make_config(tmp_path))
        assert not _find(result["findings"], "A-03")


# ---- A-04: BOM detection ----

class TestA04Bom:
    def test_detects_bom(self, tmp_path):
        di = tmp_path / ".dockerignore"
        di.write_bytes(b"\xef\xbb\xbfnode_modules\n.git\n")
        result = run_lens(_make_config(tmp_path))
        matches = _find(result["findings"], "A-04")
        assert len(matches) == 1
        assert matches[0]["severity"] == "WARN"

    def test_no_bom(self, tmp_path):
        di = tmp_path / ".dockerignore"
        di.write_text("node_modules\n.git\n", encoding="utf-8")
        result = run_lens(_make_config(tmp_path))
        assert not _find(result["findings"], "A-04")


# ---- A-06: .dockerignore ----

class TestA06Dockerignore:
    def test_missing_dockerignore(self, tmp_path):
        result = run_lens(_make_config(tmp_path))
        matches = _find(result["findings"], "A-06")
        assert len(matches) >= 1

    def test_incomplete_dockerignore(self, tmp_path):
        di = tmp_path / ".dockerignore"
        di.write_text("*.pyc\n", encoding="utf-8")
        result = run_lens(_make_config(tmp_path))
        matches = _find(result["findings"], "A-06")
        assert len(matches) >= 1  # Missing .git, node_modules, .env

    def test_good_dockerignore(self, tmp_path):
        di = tmp_path / ".dockerignore"
        di.write_text(".git\nnode_modules\n.env\n", encoding="utf-8")
        result = run_lens(_make_config(tmp_path))
        assert not _find(result["findings"], "A-06")


# ---- A-07: Secrets in build context ----

class TestA07Secrets:
    def test_detects_env_file(self, tmp_path):
        (tmp_path / ".env").write_text("SECRET=abc", encoding="utf-8")
        result = run_lens(_make_config(tmp_path))
        matches = _find(result["findings"], "A-07")
        assert len(matches) >= 1
        assert matches[0]["severity"] == "BLOCK"

    def test_detects_pem_file(self, tmp_path):
        (tmp_path / "server.pem").write_text("-----BEGIN CERT-----", encoding="utf-8")
        result = run_lens(_make_config(tmp_path))
        matches = _find(result["findings"], "A-07")
        assert len(matches) >= 1


# ---- A-14: Unpinned base image ----

class TestA14UnpinnedBase:
    def test_detects_latest_tag(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            dockerfile_content="FROM python:latest\nRUN echo hi\n"))
        matches = _find(result["findings"], "A-14")
        assert len(matches) >= 1
        assert matches[0]["severity"] == "BLOCK"

    def test_detects_no_tag(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            dockerfile_content="FROM python\nRUN echo hi\n"))
        matches = _find(result["findings"], "A-14")
        assert len(matches) >= 1

    def test_passes_digest(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            dockerfile_content="FROM python@sha256:abc123\nRUN echo hi\n"))
        assert not _find(result["findings"], "A-14")

    def test_passes_specific_tag(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            dockerfile_content="FROM python:3.12.3-slim\nRUN echo hi\n"))
        assert not _find(result["findings"], "A-14")

    def test_scratch_is_ok(self, tmp_path):
        result = run_lens(_make_config(tmp_path,
            dockerfile_content="FROM scratch\nCOPY app /app\n"))
        assert not _find(result["findings"], "A-14")


# ---- Score calculation ----

class TestScoring:
    def test_perfect_score(self, tmp_path):
        """A clean project with good Dockerfile should score well."""
        (tmp_path / ".dockerignore").write_text(".git\nnode_modules\n.env\n", encoding="utf-8")
        (tmp_path / ".gitattributes").write_text("*.sh text eol=lf\nDockerfile text eol=lf\n", encoding="utf-8")
        result = run_lens(_make_config(tmp_path,
            dockerfile_content="FROM python:3.12-slim@sha256:abc123 AS builder\nRUN echo hi\n"))
        assert result["score"] > 50.0

    def test_lens_result_structure(self, tmp_path):
        result = run_lens(_make_config(tmp_path))
        assert "lens_name" in result
        assert result["lens_name"] == "file_hygiene"
        assert "findings" in result
        assert "score" in result
        assert "duration_ms" in result
        assert "checks_run" in result
        assert "checks_passed" in result

    def test_finding_structure(self, tmp_path):
        sh = tmp_path / "entrypoint.sh"
        sh.write_bytes(b"#!/bin/bash\r\necho hello\r\n")
        result = run_lens(_make_config(tmp_path))
        findings = result["findings"]
        assert len(findings) > 0
        f = findings[0]
        assert "check_id" in f
        assert "severity" in f
        assert "category" in f
        assert "title" in f
        assert "remediation" in f
        assert "nist_controls" in f


# ---- Severity overrides ----

class TestSeverityOverrides:
    def test_override_applied(self, tmp_path):
        sh = tmp_path / "entrypoint.sh"
        sh.write_bytes(b"#!/bin/bash\r\n")
        config = _make_config(tmp_path)
        config["severity_overrides"] = {"A-01": "INFO"}
        result = run_lens(config)
        matches = _find(result["findings"], "A-01")
        assert len(matches) >= 1
        assert matches[0]["severity"] == "INFO"  # Downgraded from BLOCK
