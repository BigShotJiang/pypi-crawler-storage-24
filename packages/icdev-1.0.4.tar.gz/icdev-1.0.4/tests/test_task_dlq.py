# CUI // SP-CTI
"""Tests for the Dead Letter Queue (DLQ) module.

Classification: CUI // SP-CTI
"""

import sqlite3
import json

import pytest

from tools.core.task_dlq import (
    dispatch_with_retry,
    get_dlq_entries,
    resolve_dlq_entry,
    DLQ_TABLE_DDL,
    _ensure_table,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def db():
    """In-memory SQLite database with DLQ table."""
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.execute(DLQ_TABLE_DDL)
    conn.commit()
    yield conn
    conn.close()


def _make_call_fn(succeed_on_attempt=None, exception_cls=RuntimeError):
    """Create a call_fn that fails until succeed_on_attempt."""
    state = {"attempt": 0}

    def call_fn(agent, method, params):
        state["attempt"] += 1
        if succeed_on_attempt and state["attempt"] >= succeed_on_attempt:
            return {"status": "ok", "attempt": state["attempt"]}
        raise exception_cls(f"fail on attempt {state['attempt']}")

    return call_fn, state


# ---------------------------------------------------------------------------
# dispatch_with_retry
# ---------------------------------------------------------------------------

class TestDispatchWithRetry:

    def test_succeeds_on_first_try(self, db):
        call_fn, _ = _make_call_fn(succeed_on_attempt=1)
        result = dispatch_with_retry(
            agent_name="compliance",
            method="ssp_generate",
            params={"project_id": "test"},
            task_id="task-001",
            call_fn=call_fn,
            db_conn=db,
        )
        assert result["status"] == "ok"
        # No DLQ entry
        entries = get_dlq_entries(db_conn=db)
        assert len(entries) == 0

    def test_succeeds_on_retry(self, db):
        call_fn, state = _make_call_fn(succeed_on_attempt=2)
        result = dispatch_with_retry(
            agent_name="compliance",
            method="ssp_generate",
            params={"project_id": "test"},
            task_id="task-002",
            call_fn=call_fn,
            db_conn=db,
        )
        assert result["status"] == "ok"
        assert state["attempt"] == 2
        entries = get_dlq_entries(db_conn=db)
        assert len(entries) == 0

    def test_exhausts_retries_and_writes_dlq(self, db):
        call_fn, state = _make_call_fn(succeed_on_attempt=None)  # always fails
        with pytest.raises(RuntimeError):
            dispatch_with_retry(
                agent_name="security",
                method="sast_scan",
                params={"project_dir": "/tmp"},
                task_id="task-003",
                call_fn=call_fn,
                db_conn=db,
            )
        entries = get_dlq_entries(db_conn=db)
        assert len(entries) == 1
        assert entries[0]["agent_name"] == "security"
        assert entries[0]["method"] == "sast_scan"
        assert entries[0]["reason"] == "max_retries_exceeded"
        assert entries[0]["resolved_at"] is None


# ---------------------------------------------------------------------------
# DLQ queries
# ---------------------------------------------------------------------------

class TestDLQQueries:

    def _insert_entry(self, db, agent="test_agent", resolved=False):
        db.execute(
            """INSERT INTO agent_task_dlq
               (id, task_id, agent_name, method, params_json, reason,
                retry_count, classification, resolved_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                f"dlq-{agent}",
                f"task-{agent}",
                agent,
                "test_method",
                "{}",
                "max_retries_exceeded",
                3,
                "CUI // SP-CTI",
                "2026-03-08 00:00:00" if resolved else None,
            ),
        )
        db.commit()

    def test_get_unresolved_only(self, db):
        self._insert_entry(db, agent="a", resolved=False)
        self._insert_entry(db, agent="b", resolved=True)
        entries = get_dlq_entries(db_conn=db, unresolved_only=True)
        assert len(entries) == 1
        assert entries[0]["agent_name"] == "a"

    def test_get_all_entries(self, db):
        self._insert_entry(db, agent="a", resolved=False)
        self._insert_entry(db, agent="b", resolved=True)
        entries = get_dlq_entries(db_conn=db, unresolved_only=False)
        assert len(entries) == 2

    def test_filter_by_agent(self, db):
        self._insert_entry(db, agent="compliance", resolved=False)
        self._insert_entry(db, agent="security", resolved=False)
        entries = get_dlq_entries(db_conn=db, agent_name="compliance")
        assert len(entries) == 1
        assert entries[0]["agent_name"] == "compliance"

    def test_limit(self, db):
        for i in range(5):
            self._insert_entry(db, agent=f"agent-{i}")
        entries = get_dlq_entries(db_conn=db, limit=3)
        assert len(entries) == 3


# ---------------------------------------------------------------------------
# Resolve
# ---------------------------------------------------------------------------

class TestResolveDLQ:

    def test_resolve_marks_entry(self, db):
        db.execute(
            """INSERT INTO agent_task_dlq
               (id, task_id, agent_name, method, params_json, reason,
                retry_count, classification)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            ("dlq-1", "task-1", "agent", "method", "{}", "reason", 3, "CUI // SP-CTI"),
        )
        db.commit()

        ok = resolve_dlq_entry("dlq-1", resolved_by="admin", db_conn=db)
        assert ok is True

        row = db.execute(
            "SELECT resolved_at, resolved_by FROM agent_task_dlq WHERE id = ?",
            ("dlq-1",),
        ).fetchone()
        assert row["resolved_at"] is not None
        assert row["resolved_by"] == "admin"
