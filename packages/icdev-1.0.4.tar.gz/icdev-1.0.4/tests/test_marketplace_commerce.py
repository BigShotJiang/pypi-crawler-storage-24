#!/usr/bin/env python3
"""Tests for Marketplace Community Model (D-MKT-S1 through D-MKT-S4).
CUI // SP-CTI

Tests community activation (90-day tokens, unlimited renewals),
thin-client token verification, module runtime cache, feedback submission,
sponsor tier metadata, and renewal reminders.
"""
import json
import os
import sqlite3
import sys
import tempfile
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# D-MKT-S1: Marketplace extracted to standalone SaaS (marketplace.icdev.ai).
# ICDEV retains only the thin client (module_runtime, license_client, token_store).
# Full commerce modules (license_manager, subscription_manager, gov_po_processor,
# renewal_scheduler, stripe_billing) live in the standalone SaaS repo.
_SAAS_SKIP = "Module extracted to standalone SaaS per D-MKT-S1"

def _has_module(name: str) -> bool:
    """Check if a marketplace module exists locally."""
    return (ROOT / "tools" / "marketplace" / f"{name}.py").exists()

_has_license_manager = _has_module("license_manager")
_has_subscription_manager = _has_module("subscription_manager")
_has_gov_po_processor = _has_module("gov_po_processor")
_has_renewal_scheduler = _has_module("renewal_scheduler")
_has_stripe_billing = _has_module("stripe_billing")


# ---------------------------------------------------------------------------
# Token Store Tests (thin client — always available)
# ---------------------------------------------------------------------------

class TestTokenStore:
    """Tests for token_store.py — local JSON token cache."""

    def setup_method(self):
        self._tmp = tempfile.NamedTemporaryFile(suffix=".json", delete=False)
        self._tmp.close()

    def teardown_method(self):
        try:
            os.unlink(self._tmp.name)
        except OSError:
            pass

    def _make_token(self, slug, days_until_expiry=90, renewal_count=0, sponsor_tier=None):
        """Create a test token entry."""
        exp = (datetime.now(timezone.utc) + timedelta(days=days_until_expiry)).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
        token = {
            "license_id": f"lic-{uuid.uuid4().hex[:8]}",
            "asset_slug": slug,
            "tenant_id": "tenant-test",
            "billing_cycle": "community",
            "expires_at": exp,
            "grace_period_days": 30,
            "renewal_count": renewal_count,
        }
        if sponsor_tier:
            token["sponsor_tier"] = sponsor_tier
        return {"token": token, "license_id": token["license_id"]}

    def _write_tokens(self, tokens):
        with open(self._tmp.name, "w") as f:
            json.dump(tokens, f)

    def test_get_active_slugs(self):
        from tools.marketplace.token_store import get_active_slugs, TOKEN_FILE
        tokens = [self._make_token("writeguard", 45), self._make_token("proposalai", 10)]
        self._write_tokens(tokens)
        with patch.object(
            sys.modules["tools.marketplace.token_store"], "TOKEN_FILE", Path(self._tmp.name)
        ):
            slugs = get_active_slugs()
            assert "writeguard" in slugs
            assert "proposalai" in slugs

    def test_expired_token_outside_grace_not_active(self):
        from tools.marketplace.token_store import get_active_slugs
        tokens = [self._make_token("writeguard", -40)]  # 40 days past expiry, 30 day grace
        self._write_tokens(tokens)
        with patch.object(
            sys.modules["tools.marketplace.token_store"], "TOKEN_FILE", Path(self._tmp.name)
        ):
            slugs = get_active_slugs()
            assert "writeguard" not in slugs

    def test_expired_token_within_grace_still_active(self):
        from tools.marketplace.token_store import get_active_slugs
        tokens = [self._make_token("writeguard", -15)]  # 15 days past expiry, 30 day grace
        self._write_tokens(tokens)
        with patch.object(
            sys.modules["tools.marketplace.token_store"], "TOKEN_FILE", Path(self._tmp.name)
        ):
            slugs = get_active_slugs()
            assert "writeguard" in slugs

    def test_get_expiring_soon(self):
        from tools.marketplace.token_store import get_expiring_soon
        tokens = [
            self._make_token("writeguard", 5),     # Expiring in 5 days
            self._make_token("proposalai", 60),     # Not expiring soon
        ]
        self._write_tokens(tokens)
        with patch.object(
            sys.modules["tools.marketplace.token_store"], "TOKEN_FILE", Path(self._tmp.name)
        ):
            expiring = get_expiring_soon(days=14)
            assert len(expiring) == 1
            assert expiring[0]["slug"] == "writeguard"
            assert expiring[0]["days_remaining"] <= 5

    def test_get_expiring_soon_empty_when_all_fresh(self):
        from tools.marketplace.token_store import get_expiring_soon
        tokens = [self._make_token("writeguard", 80)]
        self._write_tokens(tokens)
        with patch.object(
            sys.modules["tools.marketplace.token_store"], "TOKEN_FILE", Path(self._tmp.name)
        ):
            expiring = get_expiring_soon(days=14)
            assert len(expiring) == 0

    def test_get_token_for_slug(self):
        from tools.marketplace.token_store import get_token_for_slug
        tokens = [self._make_token("writeguard", 90)]
        self._write_tokens(tokens)
        with patch.object(
            sys.modules["tools.marketplace.token_store"], "TOKEN_FILE", Path(self._tmp.name)
        ):
            entry = get_token_for_slug("writeguard")
            assert entry is not None
            assert entry["token"]["asset_slug"] == "writeguard"

    def test_get_token_for_slug_not_found(self):
        from tools.marketplace.token_store import get_token_for_slug
        self._write_tokens([])
        with patch.object(
            sys.modules["tools.marketplace.token_store"], "TOKEN_FILE", Path(self._tmp.name)
        ):
            entry = get_token_for_slug("nonexistent")
            assert entry is None

    def test_get_renewal_count(self):
        from tools.marketplace.token_store import get_renewal_count
        tokens = [self._make_token("writeguard", 90, renewal_count=7)]
        self._write_tokens(tokens)
        with patch.object(
            sys.modules["tools.marketplace.token_store"], "TOKEN_FILE", Path(self._tmp.name)
        ):
            count = get_renewal_count("writeguard")
            assert count == 7

    def test_get_renewal_count_missing_slug(self):
        from tools.marketplace.token_store import get_renewal_count
        self._write_tokens([])
        with patch.object(
            sys.modules["tools.marketplace.token_store"], "TOKEN_FILE", Path(self._tmp.name)
        ):
            count = get_renewal_count("nonexistent")
            assert count == 0

    def test_get_days_until_expiry(self):
        from tools.marketplace.token_store import get_days_until_expiry
        tokens = [self._make_token("writeguard", 45)]
        self._write_tokens(tokens)
        with patch.object(
            sys.modules["tools.marketplace.token_store"], "TOKEN_FILE", Path(self._tmp.name)
        ):
            days = get_days_until_expiry("writeguard")
            assert days is not None
            assert 44 <= days <= 45

    def test_remove_revoked(self):
        from tools.marketplace.token_store import remove_revoked, get_active_slugs
        t1 = self._make_token("writeguard", 90)
        t2 = self._make_token("proposalai", 90)
        self._write_tokens([t1, t2])
        with patch.object(
            sys.modules["tools.marketplace.token_store"], "TOKEN_FILE", Path(self._tmp.name)
        ):
            remove_revoked([t1["license_id"]])
            slugs = get_active_slugs()
            assert "writeguard" not in slugs
            assert "proposalai" in slugs

    def test_store_tokens_replaces_all(self):
        from tools.marketplace.token_store import store_tokens, get_active_slugs
        t1 = self._make_token("writeguard", 90)
        with patch.object(
            sys.modules["tools.marketplace.token_store"], "TOKEN_FILE", Path(self._tmp.name)
        ):
            store_tokens([t1])
            slugs = get_active_slugs()
            assert "writeguard" in slugs


# ---------------------------------------------------------------------------
# License Client Tests (thin client — always available)
# ---------------------------------------------------------------------------

class TestLicenseClient:
    """Tests for license_client.py — token verification + SaaS API."""

    def test_canonical_payload_excludes_signature(self):
        from tools.marketplace.license_client import _canonical_payload
        data = {"a": 1, "b": 2, "signature": "xyz"}
        payload = _canonical_payload(data)
        parsed = json.loads(payload)
        assert "signature" not in parsed
        assert parsed == {"a": 1, "b": 2}

    def test_canonical_payload_sorted_keys(self):
        from tools.marketplace.license_client import _canonical_payload
        data = {"z": 3, "a": 1, "m": 2}
        payload = _canonical_payload(data)
        assert payload == b'{"a":1,"m":2,"z":3}'

    def test_verify_token_locally_no_crypto(self):
        from tools.marketplace.license_client import verify_token_locally
        with patch("tools.marketplace.license_client.HAS_CRYPTO", False):
            result = verify_token_locally({"asset_slug": "test", "signature": "abc"})
            assert result["valid"] is True  # Skips verification gracefully

    def test_verify_token_missing_signature(self):
        from tools.marketplace.license_client import verify_token_locally, HAS_CRYPTO
        if not HAS_CRYPTO:
            pytest.skip("cryptography not installed")
        result = verify_token_locally({"asset_slug": "test"})
        assert result["valid"] is False
        assert any("signature" in e.lower() for e in result["errors"])

    def test_sync_tokens_no_config(self):
        from tools.marketplace.license_client import sync_tokens
        result = sync_tokens(marketplace_url="", api_key="")
        assert result == []

    def test_phone_home_no_config(self):
        from tools.marketplace.license_client import phone_home
        with patch("tools.marketplace.license_client.PHONE_HOME_ENABLED", True):
            result = phone_home(marketplace_url="", api_key="")
            assert "error" in result

    def test_phone_home_disabled(self):
        from tools.marketplace.license_client import phone_home
        with patch("tools.marketplace.license_client.PHONE_HOME_ENABLED", False):
            result = phone_home(
                marketplace_url="https://marketplace.icdev.ai",
                api_key="test-key",
            )
            assert result["skipped"] is True
            assert result["reason"] == "phone_home_disabled"

    def test_phone_home_enabled_makes_request(self):
        from tools.marketplace.license_client import phone_home

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(
            {"updated": 1, "revoked": []}
        ).encode()
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("tools.marketplace.license_client.PHONE_HOME_ENABLED", True):
            with patch("urllib.request.urlopen", return_value=mock_response):
                result = phone_home(
                    marketplace_url="https://marketplace.icdev.ai",
                    api_key="test-key",
                )
                assert result["updated"] == 1

    def test_renew_token_no_config(self):
        from tools.marketplace.license_client import renew_token
        result = renew_token("writeguard", marketplace_url="", api_key="")
        assert "error" in result

    def test_renew_token_with_feedback(self):
        """Verify renew_token includes feedback in the payload."""
        from tools.marketplace.license_client import renew_token

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(
            {"renewed": True, "token": {"asset_slug": "writeguard"}}
        ).encode()
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_response) as mock_open:
            result = renew_token(
                "writeguard",
                marketplace_url="https://marketplace.icdev.ai",
                api_key="test-key",
                feedback={"modules_used": "writeguard", "whats_working": "Great!"},
            )
            assert result["renewed"] is True
            # Verify the request included feedback
            call_args = mock_open.call_args
            req = call_args[0][0]
            body = json.loads(req.data)
            assert "feedback" in body
            assert body["feedback"]["whats_working"] == "Great!"

    def test_submit_feedback_no_config(self):
        from tools.marketplace.license_client import submit_feedback
        result = submit_feedback("writeguard", {"test": "data"}, marketplace_url="", api_key="")
        assert "error" in result

    def test_submit_feedback_success(self):
        from tools.marketplace.license_client import submit_feedback

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({"submitted": True}).encode()
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_response):
            result = submit_feedback(
                "writeguard",
                {"modules_used": "writeguard", "feature_requests": "PDF export"},
                marketplace_url="https://marketplace.icdev.ai",
                api_key="test-key",
            )
            assert result["submitted"] is True


# ---------------------------------------------------------------------------
# Module Runtime Tests (thin client — always available)
# ---------------------------------------------------------------------------

class TestModuleRuntimeOSS:
    """Tests for module_runtime.py in OSS mode (default)."""

    def test_oss_mode_always_enabled(self):
        from tools.marketplace.module_runtime import is_module_enabled
        with patch("tools.marketplace.module_runtime.MODE", "oss"):
            assert is_module_enabled("writeguard") is True
            assert is_module_enabled("nonexistent") is True

    def test_oss_mode_require_module_noop(self):
        from tools.marketplace.module_runtime import require_module
        with patch("tools.marketplace.module_runtime.MODE", "oss"):
            @require_module("writeguard")
            def my_route():
                return "ok"
            assert my_route() == "ok"

    def test_token_expires_in_days_oss_returns_none(self):
        from tools.marketplace.module_runtime import token_expires_in_days
        with patch("tools.marketplace.module_runtime.MODE", "oss"):
            assert token_expires_in_days("writeguard") is None

    def test_get_sponsor_tier_oss_returns_none(self):
        from tools.marketplace.module_runtime import get_sponsor_tier
        with patch("tools.marketplace.module_runtime.MODE", "oss"):
            assert get_sponsor_tier() is None


class TestModuleRuntimeSaaS:
    """Tests for module_runtime.py in SaaS mode."""

    def test_saas_mode_checks_token_store(self):
        from tools.marketplace.module_runtime import is_module_enabled, invalidate_cache
        invalidate_cache()
        with patch("tools.marketplace.module_runtime.MODE", "saas"):
            with patch(
                "tools.marketplace.module_runtime._load_active_slugs_saas",
                return_value=["writeguard"],
            ):
                assert is_module_enabled("writeguard") is True
                assert is_module_enabled("nonexistent") is False

    def test_cache_invalidation(self):
        from tools.marketplace.module_runtime import (
            is_module_enabled, invalidate_cache, _module_cache,
        )
        invalidate_cache()
        with patch("tools.marketplace.module_runtime.MODE", "saas"):
            with patch(
                "tools.marketplace.module_runtime._load_active_slugs_saas",
                return_value=["writeguard"],
            ):
                is_module_enabled("writeguard", "tenant-cache")
                assert ("tenant-cache", "") in _module_cache

                invalidate_cache("tenant-cache")
                assert ("tenant-cache", "") not in _module_cache

    def test_cache_ttl_expiry(self):
        from tools.marketplace.module_runtime import (
            is_module_enabled, invalidate_cache, _module_cache, _cache_key, CACHE_TTL,
        )
        invalidate_cache()
        with patch("tools.marketplace.module_runtime.MODE", "saas"):
            with patch(
                "tools.marketplace.module_runtime._load_active_slugs_saas",
                return_value=["writeguard"],
            ):
                is_module_enabled("writeguard", "tenant-ttl")

                key = _cache_key("tenant-ttl", "")
                with patch.dict(_module_cache, {key: (time.time() - CACHE_TTL - 1, set())}):
                    from tools.marketplace.module_runtime import _get_cached
                    assert _get_cached("tenant-ttl") is None

    def test_token_expires_in_days_saas(self):
        from tools.marketplace.module_runtime import token_expires_in_days
        with patch("tools.marketplace.module_runtime.MODE", "saas"):
            with patch(
                "tools.marketplace.token_store.get_days_until_expiry", return_value=42
            ):
                assert token_expires_in_days("writeguard") == 42

    def test_get_sponsor_tier_saas(self):
        from tools.marketplace.module_runtime import get_sponsor_tier
        tokens = [{"token": {"asset_slug": "writeguard", "sponsor_tier": "gold"}}]
        with patch("tools.marketplace.module_runtime.MODE", "saas"):
            with patch("tools.marketplace.token_store._load_tokens", return_value=tokens):
                assert get_sponsor_tier() == "gold"

    def test_get_sponsor_tier_no_sponsor(self):
        from tools.marketplace.module_runtime import get_sponsor_tier
        tokens = [{"token": {"asset_slug": "writeguard"}}]
        with patch("tools.marketplace.module_runtime.MODE", "saas"):
            with patch("tools.marketplace.token_store._load_tokens", return_value=tokens):
                assert get_sponsor_tier() is None


# ---------------------------------------------------------------------------
# Community Activation Flow Tests
# ---------------------------------------------------------------------------

class TestCommunityActivation:
    """End-to-end community activation: register -> 90-day token -> verify -> renew."""

    def test_community_token_90_day_active(self):
        """A fresh 90-day community token should be active."""
        from tools.marketplace.token_store import get_active_slugs

        exp = (datetime.now(timezone.utc) + timedelta(days=90)).strftime("%Y-%m-%dT%H:%M:%SZ")
        tokens = [{
            "token": {
                "license_id": "lic-community-1",
                "asset_slug": "writeguard",
                "tenant_id": "tenant-community",
                "billing_cycle": "community",
                "expires_at": exp,
                "grace_period_days": 30,
                "renewal_count": 0,
            },
            "license_id": "lic-community-1",
        }]

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            json.dump(tokens, f)
            tmp_path = f.name

        try:
            with patch.object(
                sys.modules["tools.marketplace.token_store"],
                "TOKEN_FILE",
                Path(tmp_path),
            ):
                slugs = get_active_slugs()
                assert "writeguard" in slugs
        finally:
            os.unlink(tmp_path)

    def test_community_token_day_89_still_active(self):
        """Token at day 89 of 90 should still be active."""
        from tools.marketplace.token_store import get_active_slugs

        exp = (datetime.now(timezone.utc) + timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
        tokens = [{
            "token": {
                "license_id": "lic-89",
                "asset_slug": "writeguard",
                "expires_at": exp,
                "grace_period_days": 30,
                "renewal_count": 3,
            },
            "license_id": "lic-89",
        }]

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            json.dump(tokens, f)
            tmp_path = f.name

        try:
            with patch.object(
                sys.modules["tools.marketplace.token_store"],
                "TOKEN_FILE",
                Path(tmp_path),
            ):
                slugs = get_active_slugs()
                assert "writeguard" in slugs
        finally:
            os.unlink(tmp_path)


class TestUnlimitedRenewal:
    """Verify unlimited renewal support — renewal_count has no cap."""

    def test_high_renewal_count_still_active(self):
        """A token renewed 50+ times should still be valid."""
        from tools.marketplace.token_store import get_active_slugs, get_renewal_count

        exp = (datetime.now(timezone.utc) + timedelta(days=90)).strftime("%Y-%m-%dT%H:%M:%SZ")
        tokens = [{
            "token": {
                "license_id": "lic-renew-50",
                "asset_slug": "writeguard",
                "expires_at": exp,
                "grace_period_days": 30,
                "renewal_count": 50,
            },
            "license_id": "lic-renew-50",
        }]

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            json.dump(tokens, f)
            tmp_path = f.name

        try:
            with patch.object(
                sys.modules["tools.marketplace.token_store"],
                "TOKEN_FILE",
                Path(tmp_path),
            ):
                slugs = get_active_slugs()
                assert "writeguard" in slugs
                assert get_renewal_count("writeguard") == 50
        finally:
            os.unlink(tmp_path)

    def test_renew_token_api_called_with_correct_payload(self):
        """Verify renew_token sends correct payload to SaaS."""
        from tools.marketplace.license_client import renew_token

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "renewed": True,
            "token": {
                "asset_slug": "writeguard",
                "renewal_count": 51,
                "expires_at": "2026-06-05T00:00:00Z",
            },
        }).encode()
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_response) as mock_open:
            result = renew_token(
                "writeguard",
                marketplace_url="https://marketplace.icdev.ai",
                api_key="test-key",
                tenant_id="tenant-renew",
            )
            assert result["renewed"] is True
            assert result["token"]["renewal_count"] == 51

            req = mock_open.call_args[0][0]
            body = json.loads(req.data)
            assert body["asset_slug"] == "writeguard"
            assert body["tenant_id"] == "tenant-renew"


class TestRenewalFeedback:
    """Verify feedback can be submitted with renewal or standalone."""

    def test_renewal_with_feedback_payload(self):
        from tools.marketplace.license_client import renew_token

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({"renewed": True}).encode()
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        feedback = {
            "modules_used": "writeguard, proposalai",
            "whats_working": "Compliance output is excellent",
            "feature_requests": "Add PDF export for SSP",
        }

        with patch("urllib.request.urlopen", return_value=mock_response) as mock_open:
            result = renew_token(
                "writeguard",
                marketplace_url="https://marketplace.icdev.ai",
                api_key="test-key",
                feedback=feedback,
            )
            assert result["renewed"] is True
            req = mock_open.call_args[0][0]
            body = json.loads(req.data)
            assert body["feedback"]["modules_used"] == "writeguard, proposalai"
            assert body["feedback"]["feature_requests"] == "Add PDF export for SSP"

    def test_standalone_feedback_submission(self):
        from tools.marketplace.license_client import submit_feedback

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({"submitted": True}).encode()
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_response) as mock_open:
            result = submit_feedback(
                "writeguard",
                {"whats_working": "Everything", "feature_requests": "Dark mode"},
                marketplace_url="https://marketplace.icdev.ai",
                api_key="test-key",
            )
            assert result["submitted"] is True
            req = mock_open.call_args[0][0]
            assert "/api/v1/feedback" in req.full_url


class TestSponsorBadge:
    """Verify sponsor tier is read from token metadata."""

    def test_sponsor_tier_in_token(self):
        from tools.marketplace.token_store import get_token_for_slug

        exp = (datetime.now(timezone.utc) + timedelta(days=90)).strftime("%Y-%m-%dT%H:%M:%SZ")
        tokens = [{
            "token": {
                "license_id": "lic-sponsor",
                "asset_slug": "writeguard",
                "expires_at": exp,
                "grace_period_days": 30,
                "sponsor_tier": "platinum",
            },
            "license_id": "lic-sponsor",
        }]

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            json.dump(tokens, f)
            tmp_path = f.name

        try:
            with patch.object(
                sys.modules["tools.marketplace.token_store"],
                "TOKEN_FILE",
                Path(tmp_path),
            ):
                entry = get_token_for_slug("writeguard")
                assert entry["token"]["sponsor_tier"] == "platinum"
        finally:
            os.unlink(tmp_path)

    def test_no_sponsor_tier_returns_none(self):
        from tools.marketplace.module_runtime import get_sponsor_tier
        tokens = [{"token": {"asset_slug": "writeguard"}}]
        with patch("tools.marketplace.module_runtime.MODE", "saas"):
            with patch("tools.marketplace.token_store._load_tokens", return_value=tokens):
                assert get_sponsor_tier() is None

    def test_sponsor_tiers_are_valid(self):
        """Ensure only recognized sponsor tiers are used."""
        valid_tiers = {"platinum", "gold", "silver", "bronze"}
        # This is a contract test — sponsor_tier in tokens must be one of these
        for tier in valid_tiers:
            assert tier in valid_tiers


# ---------------------------------------------------------------------------
# Legacy SaaS Module Tests (skipped — modules live in standalone SaaS)
# ---------------------------------------------------------------------------

@pytest.mark.skipif(not _has_license_manager, reason=_SAAS_SKIP)
class TestLicenseManager:
    """Tests for license_manager.py — extracted to standalone SaaS."""
    pass


@pytest.mark.skipif(not _has_subscription_manager, reason=_SAAS_SKIP)
class TestSubscriptionManager:
    """Tests for subscription_manager.py — extracted to standalone SaaS."""
    pass


@pytest.mark.skipif(not _has_gov_po_processor, reason=_SAAS_SKIP)
class TestGovPoProcessor:
    """Tests for gov_po_processor.py — extracted to standalone SaaS."""
    pass


@pytest.mark.skipif(not _has_renewal_scheduler, reason=_SAAS_SKIP)
class TestRenewalScheduler:
    """Tests for renewal_scheduler.py — extracted to standalone SaaS."""
    pass


@pytest.mark.skipif(not _has_stripe_billing, reason=_SAAS_SKIP)
class TestStripeBilling:
    """Tests for stripe_billing.py — extracted to standalone SaaS."""
    pass
