# CUI // SP-CTI
"""Property-based tests for ICDEV compliance rule engines (D-ARCH-14).

Uses the Hypothesis framework to verify invariants across compliance modules:
- crosswalk_engine: NIST-to-framework mapping
- nist_lookup: control reference lookup
- zta_maturity_scorer: Zero Trust scoring
- sbd_assessor: Secure by Design requirements
- agent_trust_scorer: trust score decay and levels
- control_mapper: activity-to-control mapping

Each test asserts a property that must hold for ALL valid inputs,
not just a handful of hand-picked examples.
"""

import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Hypothesis imports
# ---------------------------------------------------------------------------
hypothesis = pytest.importorskip("hypothesis", reason="hypothesis not installed")
from hypothesis import given, settings, assume, HealthCheck
from hypothesis import strategies as st

# ---------------------------------------------------------------------------
# Project root on sys.path so tool imports resolve
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

# ---------------------------------------------------------------------------
# Conditional imports — skip gracefully when dependencies are missing
# ---------------------------------------------------------------------------
_SKIP_CROSSWALK = False
_SKIP_NIST = False
_SKIP_ZTA = False
_SKIP_SBD = False
_SKIP_TRUST = False
_SKIP_MAPPER = False

try:
    from tools.compliance.crosswalk_engine import (
        get_frameworks_for_control,
        load_crosswalk,
        FRAMEWORK_KEYS,
    )
except Exception as exc:
    _SKIP_CROSSWALK = True
    _crosswalk_skip_reason = str(exc)

try:
    from tools.compliance.nist_lookup import lookup, load_controls, list_family
except Exception as exc:
    _SKIP_NIST = True
    _nist_skip_reason = str(exc)

try:
    from tools.devsecops.zta_maturity_scorer import (
        _score_to_maturity,
        _load_config as _zta_load_config,
        PILLARS,
    )
except Exception as exc:
    _SKIP_ZTA = True
    _zta_skip_reason = str(exc)

try:
    from tools.compliance.sbd_assessor import _load_sbd_requirements
except Exception as exc:
    _SKIP_SBD = True
    _sbd_skip_reason = str(exc)

try:
    from tools.security.agent_trust_scorer import (
        AgentTrustScorer,
        CSA_ATF_TIERS,
        _WEEKLY_DECAY_RATE,
    )
except Exception as exc:
    _SKIP_TRUST = True
    _trust_skip_reason = str(exc)

try:
    from tools.compliance.control_mapper import VALID_STATUSES, REQUIRED_FAMILIES
except Exception as exc:
    _SKIP_MAPPER = True
    _mapper_skip_reason = str(exc)

# ---------------------------------------------------------------------------
# Shared fixtures / helpers
# ---------------------------------------------------------------------------

# Known NIST control IDs from the crosswalk file (loaded once for strategies)
_KNOWN_NIST_IDS: list = []
if not _SKIP_CROSSWALK:
    try:
        _cw = load_crosswalk()
        _KNOWN_NIST_IDS = [
            entry.get("nist_id", entry.get("nist_800_53", ""))
            for entry in _cw
            if entry.get("nist_id") or entry.get("nist_800_53")
        ]
    except Exception:
        pass

_KNOWN_FAMILIES = ["AC", "AU", "CM", "IA", "SA", "SC", "RA", "CA"]


# =========================================================================
# 1. Crosswalk: valid NIST control maps to >= 1 framework
# =========================================================================

@pytest.mark.skipif(_SKIP_CROSSWALK or not _KNOWN_NIST_IDS,
                     reason="crosswalk_engine not available or no crosswalk data")
class TestCrosswalkProperties:

    @given(nist_id=st.sampled_from(_KNOWN_NIST_IDS))
    @settings(max_examples=50, suppress_health_check=[HealthCheck.function_scoped_fixture])
    def test_valid_nist_maps_to_at_least_one_framework(self, nist_id):
        """Property: every NIST control present in the crosswalk maps to >= 1 framework."""
        result = get_frameworks_for_control(nist_id)
        assert isinstance(result, dict), f"Expected dict, got {type(result)}"
        assert len(result) >= 1, (
            f"Control {nist_id} should map to at least one framework, got 0"
        )

    @given(nist_id=st.sampled_from(_KNOWN_NIST_IDS))
    @settings(max_examples=50, suppress_health_check=[HealthCheck.function_scoped_fixture])
    def test_crosswalk_is_idempotent(self, nist_id):
        """Property: calling get_frameworks_for_control twice yields identical results."""
        first = get_frameworks_for_control(nist_id)
        second = get_frameworks_for_control(nist_id)
        assert first == second, (
            f"Crosswalk not idempotent for {nist_id}: {first} != {second}"
        )

    @given(nist_id=st.sampled_from(_KNOWN_NIST_IDS))
    @settings(max_examples=50, suppress_health_check=[HealthCheck.function_scoped_fixture])
    def test_crosswalk_framework_keys_are_known(self, nist_id):
        """Property: every framework key in a crosswalk result is a recognized key."""
        result = get_frameworks_for_control(nist_id)
        for key in result:
            assert key in FRAMEWORK_KEYS, (
                f"Unknown framework key '{key}' in crosswalk for {nist_id}"
            )

    @given(nist_id=st.text(min_size=1, max_size=10))
    @settings(max_examples=50, suppress_health_check=[HealthCheck.function_scoped_fixture])
    def test_crosswalk_never_raises_on_arbitrary_input(self, nist_id):
        """Property: get_frameworks_for_control returns {} for unknown controls, never raises."""
        result = get_frameworks_for_control(nist_id)
        assert isinstance(result, dict)


# =========================================================================
# 2. NIST Lookup: always returns dict with required keys
# =========================================================================

@pytest.mark.skipif(_SKIP_NIST, reason="nist_lookup not available")
class TestNistLookupProperties:

    @classmethod
    def setup_class(cls):
        try:
            cls._controls = load_controls()
            cls._control_ids = [c["id"] for c in cls._controls]
        except Exception:
            cls._controls = []
            cls._control_ids = []

    @given(data=st.data())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.function_scoped_fixture])
    def test_lookup_returns_dict_with_required_keys(self, data):
        """Property: lookup of a known control always returns a dict with id, title, family."""
        if not self._control_ids:
            pytest.skip("No NIST controls loaded")
        cid = data.draw(st.sampled_from(self._control_ids))
        result = lookup(cid, controls=self._controls)
        assert result is not None, f"Expected control dict for {cid}, got None"
        assert isinstance(result, dict)
        for key in ("id", "title", "family"):
            assert key in result, f"Missing key '{key}' in control {cid}"

    @given(data=st.data())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.function_scoped_fixture])
    def test_lookup_is_case_insensitive(self, data):
        """Property: lookup('ac-2') and lookup('AC-2') return same result."""
        if not self._control_ids:
            pytest.skip("No NIST controls loaded")
        cid = data.draw(st.sampled_from(self._control_ids))
        upper = lookup(cid.upper(), controls=self._controls)
        lower = lookup(cid.lower(), controls=self._controls)
        assert upper == lower, f"Case sensitivity mismatch for {cid}"

    @given(cid=st.text(min_size=1, max_size=20))
    @settings(max_examples=50, suppress_health_check=[HealthCheck.function_scoped_fixture])
    def test_lookup_returns_none_for_unknown(self, cid):
        """Property: lookup of a non-existent control returns None, never raises."""
        assume(cid.upper() not in [c.upper() for c in (self._control_ids or [])])
        result = lookup(cid, controls=self._controls)
        assert result is None

    @given(family=st.sampled_from(_KNOWN_FAMILIES))
    @settings(max_examples=50, suppress_health_check=[HealthCheck.function_scoped_fixture])
    def test_list_family_returns_list(self, family):
        """Property: list_family always returns a list (possibly empty)."""
        result = list_family(family, controls=self._controls)
        assert isinstance(result, list)
        for ctrl in result:
            assert ctrl["family"].upper() == family.upper()


# =========================================================================
# 3. ZTA Maturity: score always in [0.0, 1.0]
# =========================================================================

@pytest.mark.skipif(_SKIP_ZTA, reason="zta_maturity_scorer not available")
class TestZtaMaturityProperties:

    @given(score=st.floats(min_value=0.0, max_value=1.0, allow_nan=False))
    @settings(max_examples=50)
    def test_score_to_maturity_returns_valid_level(self, score):
        """Property: _score_to_maturity maps any [0,1] float to a known maturity level."""
        result = _score_to_maturity(score)
        valid_levels = {"traditional", "advanced", "optimal"}
        assert result in valid_levels, (
            f"Score {score} mapped to unknown level '{result}'"
        )

    @given(score=st.floats(min_value=0.0, max_value=1.0, allow_nan=False))
    @settings(max_examples=50)
    def test_maturity_is_deterministic(self, score):
        """Property: same score always produces same maturity level."""
        first = _score_to_maturity(score)
        second = _score_to_maturity(score)
        assert first == second

    @given(
        lo=st.sampled_from([0.0, 0.10, 0.20, 0.33]),
        hi=st.sampled_from([0.67, 0.80, 0.90, 1.0]),
    )
    @settings(max_examples=50, deadline=None)
    def test_higher_score_not_lower_maturity(self, lo, hi):
        """Property: a score clearly in 'optimal' range is never below one clearly in
        'traditional' range.  Uses range-interior values to avoid the
        0.33-0.34 and 0.66-0.67 boundary gaps in the ZTA config."""
        assume(hi > lo)
        level_order = {"traditional": 0, "advanced": 1, "optimal": 2}
        lo_level = _score_to_maturity(lo)
        hi_level = _score_to_maturity(hi)
        assert level_order[hi_level] >= level_order[lo_level], (
            f"Higher score {hi} ({hi_level}) ranked below {lo} ({lo_level})"
        )


# =========================================================================
# 4. SbD Assessment: never produces empty requirements list
# =========================================================================

@pytest.mark.skipif(_SKIP_SBD, reason="sbd_assessor not available")
class TestSbdProperties:

    @classmethod
    def setup_class(cls):
        try:
            cls._sbd_data = _load_sbd_requirements()
            cls._requirements = cls._sbd_data.get("requirements", [])
        except Exception:
            cls._sbd_data = {}
            cls._requirements = []

    def test_sbd_requirements_not_empty(self):
        """Property: the SbD requirements catalog always has at least one requirement."""
        assert len(self._requirements) > 0, (
            "SbD requirements list must not be empty"
        )

    def test_every_requirement_has_required_fields(self):
        """Property: every SbD requirement has id, domain, title, description."""
        for req in self._requirements:
            for key in ("id", "domain", "title", "description"):
                assert key in req, (
                    f"Requirement {req.get('id', '?')} missing key '{key}'"
                )

    def test_every_requirement_has_nist_controls(self):
        """Property: every SbD requirement maps to at least one NIST control."""
        for req in self._requirements:
            nist = req.get("nist_controls", [])
            assert isinstance(nist, list) and len(nist) >= 1, (
                f"Requirement {req['id']} must map to >= 1 NIST control"
            )

    def test_all_requirement_ids_unique(self):
        """Property: all SbD requirement IDs are unique."""
        ids = [r["id"] for r in self._requirements]
        assert len(ids) == len(set(ids)), "Duplicate requirement IDs found"

    @given(domain=st.sampled_from([
        "Authentication", "Memory Safety", "Vulnerability Management",
        "Intrusion Evidence", "Cryptography", "Access Control",
        "Input Handling", "Error Handling", "Supply Chain",
        "Threat Modeling", "Defense in Depth", "Secure Defaults",
        "CUI Compliance", "DoD Software Assurance",
    ]))
    @settings(max_examples=50)
    def test_filtering_by_valid_domain_returns_nonempty(self, domain):
        """Property: filtering by any recognized domain yields >= 1 requirement."""
        filtered = [r for r in self._requirements if r.get("domain") == domain]
        assert len(filtered) >= 1, (
            f"Domain '{domain}' should have at least one requirement"
        )


# =========================================================================
# 5. Trust score: decay is monotonically decreasing
# =========================================================================

@pytest.mark.skipif(_SKIP_TRUST, reason="agent_trust_scorer not available")
class TestTrustScoreProperties:

    def _make_scorer(self, initial=0.85):
        """Create an AgentTrustScorer with test config (no DB access)."""
        config = {
            "initial_score": initial,
            "min_score": 0.0,
            "max_score": 1.0,
            "decay_factors": {
                "veto_hard": -0.15,
                "veto_soft": -0.05,
                "tool_chain_violation": -0.12,
                "output_violation_critical": -0.10,
                "output_violation_high": -0.07,
                "output_violation_medium": -0.03,
            },
            "recovery": {
                "clean_check_bonus": 0.02,
                "max_recovery_per_day": 0.10,
            },
            "thresholds": {
                "normal": 0.70,
                "degraded": 0.50,
                "untrusted": 0.30,
            },
        }
        return AgentTrustScorer(config=config)

    @given(score=st.floats(min_value=0.0, max_value=1.0, allow_nan=False))
    @settings(max_examples=50)
    def test_trust_level_always_valid(self, score):
        """Property: get_trust_level maps any [0,1] score to a known level."""
        scorer = self._make_scorer()
        level = scorer.get_trust_level(score)
        assert level in {"normal", "degraded", "untrusted", "blocked"}, (
            f"Unknown trust level '{level}' for score {score}"
        )

    @given(
        score=st.floats(min_value=0.01, max_value=1.0, allow_nan=False),
        weeks=st.integers(min_value=1, max_value=52),
    )
    @settings(max_examples=50)
    def test_weekly_decay_is_monotonically_decreasing(self, score, weeks):
        """Property: applying weekly decay always produces a lower or equal score."""
        decay_amount = score * _WEEKLY_DECAY_RATE * weeks
        new_score = max(0.0, score - decay_amount)
        assert new_score <= score, (
            f"Decay should not increase score: {score} -> {new_score}"
        )

    @given(
        score=st.floats(min_value=0.0, max_value=1.0, allow_nan=False),
        weeks=st.integers(min_value=0, max_value=200),
    )
    @settings(max_examples=50)
    def test_decayed_score_never_negative(self, score, weeks):
        """Property: trust score after decay is always >= 0."""
        decay_amount = score * _WEEKLY_DECAY_RATE * weeks
        new_score = max(0.0, score - decay_amount)
        assert new_score >= 0.0

    @given(score=st.floats(min_value=0.0, max_value=1.0, allow_nan=False))
    @settings(max_examples=50)
    def test_csa_tier_always_valid(self, score):
        """Property: _score_to_csa_tier maps any [0,1] score to a known CSA ATF tier."""
        scorer = self._make_scorer()
        tier = scorer._score_to_csa_tier(score)
        assert tier in CSA_ATF_TIERS, f"Unknown CSA tier '{tier}' for score {score}"

    @given(
        lo=st.floats(min_value=0.0, max_value=0.5, allow_nan=False),
        hi=st.floats(min_value=0.5, max_value=1.0, allow_nan=False),
    )
    @settings(max_examples=50)
    def test_higher_score_not_lower_csa_tier(self, lo, hi):
        """Property: a higher trust score never maps to a strictly lower CSA tier."""
        assume(hi > lo)
        scorer = self._make_scorer()
        tier_order = {"intern": 0, "junior": 1, "senior": 2, "principal": 3}
        lo_tier = scorer._score_to_csa_tier(lo)
        hi_tier = scorer._score_to_csa_tier(hi)
        assert tier_order[hi_tier] >= tier_order[lo_tier], (
            f"Higher score {hi} ({hi_tier}) ranked below {lo} ({lo_tier})"
        )


# =========================================================================
# 6. Control mapper: valid statuses and families
# =========================================================================

@pytest.mark.skipif(_SKIP_MAPPER, reason="control_mapper not available")
class TestControlMapperProperties:

    def test_valid_statuses_not_empty(self):
        """Property: VALID_STATUSES is a non-empty tuple."""
        assert len(VALID_STATUSES) >= 1

    @given(status=st.sampled_from(list(VALID_STATUSES)))
    @settings(max_examples=50)
    def test_valid_statuses_are_lowercase_strings(self, status):
        """Property: every valid status is a lowercase string without spaces."""
        assert isinstance(status, str)
        assert status == status.lower()
        assert " " not in status

    def test_required_families_cover_fips_200(self):
        """Property: REQUIRED_FAMILIES includes all 17 FIPS 200 families."""
        assert len(REQUIRED_FAMILIES) == 17
        expected = {
            "AC", "AT", "AU", "CA", "CM", "CP", "IA", "IR",
            "MA", "MP", "PE", "PL", "PS", "RA", "SA", "SC", "SI",
        }
        assert set(REQUIRED_FAMILIES) == expected

    @given(family=st.sampled_from(REQUIRED_FAMILIES if not _SKIP_MAPPER else ["AC"]))
    @settings(max_examples=50)
    def test_family_codes_are_two_uppercase_letters(self, family):
        """Property: every required family code is exactly 2 uppercase ASCII letters."""
        assert len(family) == 2
        assert family.isalpha()
        assert family.isupper()
