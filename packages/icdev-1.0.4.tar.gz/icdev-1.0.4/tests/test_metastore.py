# CUI // SP-CTI
"""Tests for Application Metastore — registry, dependency graph, RTO tracker, snippets."""

import json
import sqlite3
from pathlib import Path
from unittest.mock import patch

import pytest


# ─── FIXTURES ────────────────────────────────────────────────────────────────


@pytest.fixture
def temp_db(tmp_path):
    """Create a temp DB with all required tables."""
    db_path = tmp_path / "test_icdev.db"
    conn = sqlite3.connect(str(db_path))
    conn.executescript("""
        CREATE TABLE cf_applications (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            app_type TEXT NOT NULL,
            status TEXT DEFAULT 'active',
            environment TEXT DEFAULT 'production',
            rto_hours REAL,
            rpo_hours REAL,
            criticality TEXT DEFAULT 'medium',
            owner_team TEXT,
            owner_email TEXT,
            zone_ids TEXT,
            device_ids TEXT,
            connection_ids TEXT,
            runbook_ids TEXT,
            metadata_json TEXT,
            discovery_source TEXT,
            tags TEXT,
            classification TEXT DEFAULT 'CUI // SP-CTI',
            tenant_id TEXT NOT NULL DEFAULT 'default',
            project_id TEXT,
            created_by TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            UNIQUE(tenant_id, name, environment)
        );
        CREATE TABLE cf_app_dependencies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_app_id TEXT NOT NULL,
            target_app_id TEXT NOT NULL,
            dependency_type TEXT NOT NULL,
            protocol TEXT,
            port INTEGER,
            description TEXT,
            classification TEXT DEFAULT 'CUI // SP-CTI',
            tenant_id TEXT NOT NULL DEFAULT 'default',
            created_at TEXT DEFAULT (datetime('now')),
            UNIQUE(source_app_id, target_app_id, dependency_type)
        );
        CREATE TABLE cf_runbooks (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            version INTEGER NOT NULL DEFAULT 1,
            status TEXT DEFAULT 'draft',
            template_source TEXT,
            tasks_json TEXT NOT NULL,
            edges_json TEXT NOT NULL,
            snippets_used TEXT,
            estimated_duration_minutes INTEGER,
            owner TEXT,
            tags TEXT,
            classification TEXT DEFAULT 'CUI // SP-CTI',
            tenant_id TEXT NOT NULL DEFAULT 'default',
            project_id TEXT,
            created_by TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            UNIQUE(tenant_id, name, version)
        );
        CREATE TABLE cf_runbook_snippets (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            category TEXT NOT NULL,
            tasks_json TEXT NOT NULL,
            edges_json TEXT NOT NULL,
            usage_count INTEGER DEFAULT 0,
            classification TEXT DEFAULT 'CUI // SP-CTI',
            tenant_id TEXT NOT NULL DEFAULT 'default',
            created_by TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            UNIQUE(tenant_id, name)
        );
        CREATE TABLE cf_landing_zones (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            cloud_type TEXT NOT NULL,
            impact_level TEXT DEFAULT 'IL4',
            environment TEXT DEFAULT 'production',
            status TEXT DEFAULT 'active'
        );
        CREATE TABLE db_connections (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            connector_type TEXT NOT NULL,
            status TEXT DEFAULT 'active'
        );
    """)
    conn.commit()
    conn.close()
    return db_path


# ─── REGISTRY TESTS ─────────────────────────────────────────────────────────


class TestRegistry:
    def test_register_app(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            from tools.cloudforge.metastore.registry import register_app
            result = register_app(name="My API", app_type="api", criticality="high")
            assert result["status"] == "ok"
            assert result["id"].startswith("app-")

    def test_list_apps_empty(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            from tools.cloudforge.metastore.registry import list_apps
            assert list_apps() == []

    def test_list_after_register(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            from tools.cloudforge.metastore.registry import register_app, list_apps
            register_app(name="App1", app_type="web")
            register_app(name="App2", app_type="database")
            apps = list_apps()
            assert len(apps) == 2

    def test_get_app(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            from tools.cloudforge.metastore.registry import register_app, get_app
            res = register_app(name="GetMe", app_type="api")
            app = get_app(res["id"])
            assert app is not None
            assert app["name"] == "GetMe"

    def test_update_app(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            from tools.cloudforge.metastore.registry import register_app, update_app, get_app
            res = register_app(name="UpdateMe", app_type="api")
            update_app(res["id"], criticality="critical", rto_hours=1.0)
            app = get_app(res["id"])
            assert app["criticality"] == "critical"
            assert app["rto_hours"] == 1.0

    def test_deregister_app(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            from tools.cloudforge.metastore.registry import register_app, deregister_app, get_app
            res = register_app(name="RemoveMe", app_type="web")
            deregister_app(res["id"])
            app = get_app(res["id"])
            assert app["status"] == "decommissioned"

    def test_filter_by_criticality(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            from tools.cloudforge.metastore.registry import register_app, list_apps
            register_app(name="Critical", app_type="api", criticality="critical")
            register_app(name="Low", app_type="web", criticality="low")
            apps = list_apps(criticality="critical")
            assert len(apps) == 1
            assert apps[0]["name"] == "Critical"


# ─── DEPENDENCY GRAPH TESTS ─────────────────────────────────────────────────


class TestDependencyGraph:
    def _register_two(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            from tools.cloudforge.metastore.registry import register_app
            a1 = register_app(name="Frontend", app_type="web")
            a2 = register_app(name="Backend", app_type="api")
            return a1["id"], a2["id"]

    def test_add_dependency(self, temp_db):
        a1, a2 = self._register_two(temp_db)
        with patch("tools.cloudforge.metastore.dependency_graph.DB_PATH", temp_db):
            from tools.cloudforge.metastore.dependency_graph import add_dependency
            result = add_dependency(a1, a2, "hard", protocol="https", port=443)
            assert result["status"] == "ok"

    def test_self_dependency_rejected(self, temp_db):
        a1, _ = self._register_two(temp_db)
        with patch("tools.cloudforge.metastore.dependency_graph.DB_PATH", temp_db):
            from tools.cloudforge.metastore.dependency_graph import add_dependency
            result = add_dependency(a1, a1, "hard")
            assert result["status"] == "error"

    def test_cycle_detection(self, temp_db):
        a1, a2 = self._register_two(temp_db)
        with patch("tools.cloudforge.metastore.dependency_graph.DB_PATH", temp_db):
            from tools.cloudforge.metastore.dependency_graph import add_dependency
            add_dependency(a1, a2, "hard")
            result = add_dependency(a2, a1, "hard")
            assert result["status"] == "error"
            assert any("circular" in e.lower() for e in result["errors"])

    def test_get_dependencies(self, temp_db):
        a1, a2 = self._register_two(temp_db)
        with patch("tools.cloudforge.metastore.dependency_graph.DB_PATH", temp_db):
            from tools.cloudforge.metastore.dependency_graph import add_dependency, get_dependencies
            add_dependency(a1, a2, "hard")
            deps = get_dependencies(a1)
            assert deps["downstream_count"] == 1
            assert deps["upstream_count"] == 0

    def test_full_graph(self, temp_db):
        a1, a2 = self._register_two(temp_db)
        with patch("tools.cloudforge.metastore.dependency_graph.DB_PATH", temp_db):
            from tools.cloudforge.metastore.dependency_graph import add_dependency, get_full_graph
            add_dependency(a1, a2, "data")
            graph = get_full_graph()
            assert graph["node_count"] == 2
            assert graph["edge_count"] == 1

    def test_missing_app_rejected(self, temp_db):
        a1, _ = self._register_two(temp_db)
        with patch("tools.cloudforge.metastore.dependency_graph.DB_PATH", temp_db):
            from tools.cloudforge.metastore.dependency_graph import add_dependency
            result = add_dependency(a1, "app-nonexistent", "hard")
            assert result["status"] == "error"


# ─── RTO TRACKER TESTS ──────────────────────────────────────────────────────


class TestRtoTracker:
    def test_compliant_app(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            from tools.cloudforge.metastore.registry import register_app, update_app
            res = register_app(name="FastApp", app_type="api", criticality="critical")
            update_app(res["id"], rto_hours=0.5, rpo_hours=0.1)

        with patch("tools.cloudforge.metastore.rto_tracker.DB_PATH", temp_db):
            from tools.cloudforge.metastore.rto_tracker import check_rto_compliance
            result = check_rto_compliance()
            assert result["compliant_count"] == 1

    def test_non_compliant_app(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            from tools.cloudforge.metastore.registry import register_app, update_app
            res = register_app(name="SlowApp", app_type="batch", criticality="critical")
            update_app(res["id"], rto_hours=48.0, rpo_hours=24.0)

        with patch("tools.cloudforge.metastore.rto_tracker.DB_PATH", temp_db):
            from tools.cloudforge.metastore.rto_tracker import check_rto_compliance
            result = check_rto_compliance()
            assert result["non_compliant_count"] == 1

    def test_undefined_rto(self, temp_db):
        with patch("tools.cloudforge.metastore.registry.DB_PATH", temp_db):
            from tools.cloudforge.metastore.registry import register_app
            register_app(name="NoRTO", app_type="web")

        with patch("tools.cloudforge.metastore.rto_tracker.DB_PATH", temp_db):
            from tools.cloudforge.metastore.rto_tracker import check_rto_compliance
            result = check_rto_compliance()
            assert result["undefined_count"] == 1


# ─── SNIPPET TESTS ───────────────────────────────────────────────────────────


class TestSnippets:
    def test_create_snippet(self, temp_db):
        with patch("tools.cloudforge.runbooks.snippet_library.DB_PATH", temp_db):
            from tools.cloudforge.runbooks.snippet_library import create_snippet
            result = create_snippet(
                name="Health Check",
                category="health_check",
                tasks=[{"id": "s1", "name": "Check", "action": "zone_health"}],
                edges=[],
            )
            assert result["status"] == "ok"
            assert result["id"].startswith("snp-")

    def test_list_snippets(self, temp_db):
        with patch("tools.cloudforge.runbooks.snippet_library.DB_PATH", temp_db):
            from tools.cloudforge.runbooks.snippet_library import create_snippet, list_snippets
            create_snippet(name="S1", category="backup",
                           tasks=[{"id": "t1", "name": "A", "action": "noop"}], edges=[])
            create_snippet(name="S2", category="health_check",
                           tasks=[{"id": "t1", "name": "A", "action": "noop"}], edges=[])
            assert len(list_snippets()) == 2
            assert len(list_snippets(category="backup")) == 1

    def test_embed_snippet(self, temp_db):
        with patch("tools.cloudforge.runbooks.snippet_library.DB_PATH", temp_db):
            from tools.cloudforge.runbooks.snippet_library import create_snippet, embed_snippet
            res = create_snippet(
                name="Reusable",
                category="custom",
                tasks=[
                    {"id": "s1", "name": "A", "action": "noop"},
                    {"id": "s2", "name": "B", "action": "noop"},
                ],
                edges=[{"source": "s1", "target": "s2"}],
            )
            embed = embed_snippet(
                snippet_id=res["id"],
                runbook_tasks=[{"id": "t1", "name": "Main", "action": "noop"}],
                runbook_edges=[],
            )
            assert embed["status"] == "ok"
            assert embed["snippet_tasks_added"] == 2
            assert len(embed["tasks"]) == 3  # 1 original + 2 from snippet

    def test_invalid_snippet_dag(self, temp_db):
        with patch("tools.cloudforge.runbooks.snippet_library.DB_PATH", temp_db):
            from tools.cloudforge.runbooks.snippet_library import create_snippet
            result = create_snippet(
                name="Bad",
                category="custom",
                tasks=[{"id": "t1", "name": "A", "action": "noop"},
                       {"id": "t2", "name": "B", "action": "noop"}],
                edges=[{"source": "t1", "target": "t2"}, {"source": "t2", "target": "t1"}],
            )
            assert result["status"] == "error"


# ─── DISCOVERY TESTS ─────────────────────────────────────────────────────────


class TestDiscovery:
    def _make_sqlite_conn(self, temp_db):
        """Return a sqlite3 connection to the temp DB with Row factory."""
        conn = sqlite3.connect(str(temp_db))
        conn.row_factory = sqlite3.Row
        return conn

    def test_discover_from_zones(self, temp_db):
        # Seed a landing zone
        conn = sqlite3.connect(str(temp_db))
        conn.execute(
            "INSERT INTO cf_landing_zones (id, name, cloud_type, impact_level, status) VALUES ('lz-001', 'prod-gov', 'aws_govcloud', 'IL4', 'active')"
        )
        conn.commit()
        conn.close()

        with patch("tools.cloudforge.metastore.discovery.get_connection", lambda **kw: self._make_sqlite_conn(temp_db)):
            from tools.cloudforge.metastore.discovery import discover_from_zones
            results = discover_from_zones()
            assert len(results) == 1
            assert results[0]["action"] == "created"

    def test_discover_from_connections(self, temp_db):
        conn = sqlite3.connect(str(temp_db))
        conn.execute(
            "INSERT INTO db_connections (id, name, connector_type, status) VALUES ('conn-001', 'pg-main', 'postgresql', 'active')"
        )
        conn.commit()
        conn.close()

        with patch("tools.cloudforge.metastore.discovery.get_connection", lambda **kw: self._make_sqlite_conn(temp_db)):
            from tools.cloudforge.metastore.discovery import discover_from_connections
            results = discover_from_connections()
            assert len(results) == 1

    def test_idempotent_upsert(self, temp_db):
        conn = sqlite3.connect(str(temp_db))
        conn.execute(
            "INSERT INTO cf_landing_zones (id, name, cloud_type, status) VALUES ('lz-002', 'test', 'gcp', 'active')"
        )
        conn.commit()
        conn.close()

        with patch("tools.cloudforge.metastore.discovery.get_connection", lambda **kw: self._make_sqlite_conn(temp_db)):
            from tools.cloudforge.metastore.discovery import discover_from_zones
            r1 = discover_from_zones()
            assert r1[0]["action"] == "created"
            r2 = discover_from_zones()
            assert r2[0]["action"] == "updated"


# ─── VISUALIZATION TESTS ────────────────────────────────────────────────────


class TestVisualization:
    def test_runbook_to_vis_json(self):
        from tools.cloudforge.runbooks.visualization import runbook_to_vis_json
        runbook = {
            "tasks_json": json.dumps([
                {"id": "t1", "name": "A", "action": "noop", "description": "", "parameters": {},
                 "timeout_seconds": 60, "retries": 0, "on_failure": "stop", "condition": None, "assigned_to": "cf"},
                {"id": "t2", "name": "B", "action": "noop", "description": "", "parameters": {},
                 "timeout_seconds": 60, "retries": 0, "on_failure": "stop", "condition": None, "assigned_to": "cf"},
                {"id": "t3", "name": "C", "action": "noop", "description": "", "parameters": {},
                 "timeout_seconds": 60, "retries": 0, "on_failure": "stop", "condition": None, "assigned_to": "cf"},
            ]),
            "edges_json": json.dumps([
                {"source": "t1", "target": "t2", "label": "", "condition": None},
                {"source": "t1", "target": "t3", "label": "", "condition": None},
            ]),
        }
        vis = runbook_to_vis_json(runbook)
        assert vis["total_tasks"] == 3
        assert vis["total_edges"] == 2
        assert vis["max_depth"] == 2
        assert len(vis["levels"]) == 2
        # t1 at level 0, t2/t3 at level 1
        assert vis["levels"][0] == ["t1"]
        assert set(vis["levels"][1]) == {"t2", "t3"}

    def test_execution_to_vis_json(self):
        from tools.cloudforge.runbooks.visualization import execution_to_vis_json
        execution = {
            "id": "rex-001",
            "status": "completed",
            "duration_ms": 500,
            "task_log": [
                {"task_id": "t1", "action": "started", "duration_ms": 0},
                {"task_id": "t1", "action": "completed", "duration_ms": 100},
                {"task_id": "t2", "action": "started", "duration_ms": 0},
                {"task_id": "t2", "action": "failed", "duration_ms": 200},
            ],
        }
        vis = execution_to_vis_json(execution)
        assert vis["task_statuses"]["t1"] == "completed"
        assert vis["task_statuses"]["t2"] == "failed"
