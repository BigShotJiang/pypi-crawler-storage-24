#!/usr/bin/env python3
# CUI // SP-CTI
"""Tests for CodeLens/Pro Lens D: Helm Chart Validation."""

import os
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

# Ensure project root is on path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


class TestHelmChartMetadata(unittest.TestCase):
    """Test D-08: Chart.yaml metadata check."""

    def _make_chart(self, td, chart_yaml="", values_yaml="", templates=None):
        """Create a minimal Helm chart structure."""
        chart_dir = Path(td) / "mychart"
        chart_dir.mkdir()
        templates_dir = chart_dir / "templates"
        templates_dir.mkdir()
        if chart_yaml:
            (chart_dir / "Chart.yaml").write_text(chart_yaml, encoding="utf-8")
        if values_yaml:
            (chart_dir / "values.yaml").write_text(values_yaml, encoding="utf-8")
        if templates:
            for name, content in templates.items():
                (templates_dir / name).write_text(content, encoding="utf-8")
        return chart_dir

    def test_missing_chart_yaml(self):
        from tools.container_lens.lenses.helm_chart import _check_chart_metadata
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "nochart"
            chart_dir.mkdir()
            findings = _check_chart_metadata(chart_dir, set())
            self.assertTrue(len(findings) > 0)
            self.assertEqual(findings[0]["check_id"], "D-08")
            self.assertEqual(findings[0]["severity"], "BLOCK")

    def test_missing_required_fields(self):
        from tools.container_lens.lenses.helm_chart import _check_chart_metadata
        with tempfile.TemporaryDirectory() as td:
            chart_dir = self._make_chart(td, chart_yaml="name: mychart\n")
            findings = _check_chart_metadata(chart_dir, set())
            missing_fields = {f["title"] for f in findings if f["severity"] == "BLOCK"}
            self.assertTrue(any("apiVersion" in t for t in missing_fields))
            self.assertTrue(any("version" in t for t in missing_fields))

    def test_passes_complete_chart(self):
        from tools.container_lens.lenses.helm_chart import _check_chart_metadata
        with tempfile.TemporaryDirectory() as td:
            chart_dir = self._make_chart(td, chart_yaml=textwrap.dedent("""\
                apiVersion: v2
                name: mychart
                version: 1.0.0
                description: My chart
                type: application
                appVersion: 1.0.0
            """))
            findings = _check_chart_metadata(chart_dir, set())
            block_findings = [f for f in findings if f["severity"] == "BLOCK"]
            self.assertEqual(len(block_findings), 0)


class TestHelmDeadValues(unittest.TestCase):
    """Test D-04: Dead values check."""

    def test_detects_dead_values(self):
        from tools.container_lens.lenses.helm_chart import _check_dead_values
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "mychart"
            chart_dir.mkdir()
            templates_dir = chart_dir / "templates"
            templates_dir.mkdir()
            (chart_dir / "values.yaml").write_text(textwrap.dedent("""\
                image:
                  repository: nginx
                  tag: 1.25
                unused_key: somevalue
            """), encoding="utf-8")
            (templates_dir / "deploy.yaml").write_text(
                "image: {{ .Values.image.repository }}:{{ .Values.image.tag }}",
                encoding="utf-8"
            )
            findings = _check_dead_values(chart_dir, set())
            dead_keys = {f["title"] for f in findings}
            self.assertTrue(any("unused_key" in t for t in dead_keys))

    def test_no_dead_values(self):
        from tools.container_lens.lenses.helm_chart import _check_dead_values
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "mychart"
            chart_dir.mkdir()
            templates_dir = chart_dir / "templates"
            templates_dir.mkdir()
            (chart_dir / "values.yaml").write_text(textwrap.dedent("""\
                replicaCount: 3
            """), encoding="utf-8")
            (templates_dir / "deploy.yaml").write_text(
                "replicas: {{ .Values.replicaCount }}",
                encoding="utf-8"
            )
            findings = _check_dead_values(chart_dir, set())
            self.assertEqual(len(findings), 0)


class TestHelmNotesAndSchema(unittest.TestCase):
    """Test D-12 and D-13: NOTES.txt and values.schema.json."""

    def test_missing_notes(self):
        from tools.container_lens.lenses.helm_chart import _check_notes_txt
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "mychart"
            chart_dir.mkdir()
            (chart_dir / "templates").mkdir()
            findings = _check_notes_txt(chart_dir, set())
            self.assertEqual(len(findings), 1)
            self.assertEqual(findings[0]["check_id"], "D-12")

    def test_has_notes(self):
        from tools.container_lens.lenses.helm_chart import _check_notes_txt
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "mychart"
            chart_dir.mkdir()
            (chart_dir / "templates").mkdir()
            (chart_dir / "templates" / "NOTES.txt").write_text("Hello!", encoding="utf-8")
            findings = _check_notes_txt(chart_dir, set())
            self.assertEqual(len(findings), 0)

    def test_missing_schema(self):
        from tools.container_lens.lenses.helm_chart import _check_values_schema
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "mychart"
            chart_dir.mkdir()
            findings = _check_values_schema(chart_dir, set())
            self.assertEqual(len(findings), 1)
            self.assertEqual(findings[0]["check_id"], "D-13")

    def test_has_schema(self):
        from tools.container_lens.lenses.helm_chart import _check_values_schema
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "mychart"
            chart_dir.mkdir()
            (chart_dir / "values.schema.json").write_text("{}", encoding="utf-8")
            findings = _check_values_schema(chart_dir, set())
            self.assertEqual(len(findings), 0)


class TestHelmVendoredDeps(unittest.TestCase):
    """Test D-09: Vendored dependencies check."""

    def test_detects_unvendored(self):
        from tools.container_lens.lenses.helm_chart import _check_vendored_deps
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "mychart"
            chart_dir.mkdir()
            (chart_dir / "Chart.yaml").write_text(textwrap.dedent("""\
                apiVersion: v2
                name: mychart
                version: 1.0.0
                dependencies:
                  - name: postgresql
                    version: 12.1.0
                    repository: https://charts.bitnami.com/bitnami
            """), encoding="utf-8")
            findings = _check_vendored_deps(chart_dir, set())
            self.assertTrue(len(findings) > 0)
            self.assertEqual(findings[0]["check_id"], "D-09")

    def test_passes_vendored(self):
        from tools.container_lens.lenses.helm_chart import _check_vendored_deps
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "mychart"
            chart_dir.mkdir()
            charts_dir = chart_dir / "charts"
            charts_dir.mkdir()
            (charts_dir / "postgresql-12.1.0.tgz").write_text("", encoding="utf-8")
            (chart_dir / "Chart.yaml").write_text(textwrap.dedent("""\
                apiVersion: v2
                name: mychart
                version: 1.0.0
                dependencies:
                  - name: postgresql
                    version: 12.1.0
                    repository: https://charts.bitnami.com/bitnami
            """), encoding="utf-8")
            findings = _check_vendored_deps(chart_dir, set())
            self.assertEqual(len(findings), 0)


class TestHelmFloatingDeps(unittest.TestCase):
    """Test D-10: Floating dependency versions."""

    def test_detects_wildcard(self):
        from tools.container_lens.lenses.helm_chart import _check_floating_dep_versions
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "mychart"
            chart_dir.mkdir()
            (chart_dir / "Chart.yaml").write_text(textwrap.dedent("""\
                apiVersion: v2
                name: mychart
                version: 1.0.0
                dependencies:
                  - name: redis
                    version: "*"
                    repository: https://charts.bitnami.com/bitnami
            """), encoding="utf-8")
            findings = _check_floating_dep_versions(chart_dir, set())
            self.assertTrue(len(findings) > 0)
            self.assertIn("*", findings[0]["title"])


class TestHelmStorageClass(unittest.TestCase):
    """Test D-15: Hardcoded StorageClass check."""

    def test_detects_hardcoded_gp2(self):
        from tools.container_lens.lenses.helm_chart import _check_storage_class_hardcoded
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "mychart"
            chart_dir.mkdir()
            templates_dir = chart_dir / "templates"
            templates_dir.mkdir()
            (templates_dir / "pvc.yaml").write_text(textwrap.dedent("""\
                apiVersion: v1
                kind: PersistentVolumeClaim
                spec:
                  storageClassName: gp2
                  resources:
                    requests:
                      storage: 10Gi
            """), encoding="utf-8")
            findings = _check_storage_class_hardcoded(chart_dir, set())
            self.assertTrue(len(findings) > 0)

    def test_passes_parameterized(self):
        from tools.container_lens.lenses.helm_chart import _check_storage_class_hardcoded
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "mychart"
            chart_dir.mkdir()
            templates_dir = chart_dir / "templates"
            templates_dir.mkdir()
            (templates_dir / "pvc.yaml").write_text(textwrap.dedent("""\
                apiVersion: v1
                kind: PersistentVolumeClaim
                spec:
                  storageClassName: {{ .Values.persistence.storageClass }}
            """), encoding="utf-8")
            findings = _check_storage_class_hardcoded(chart_dir, set())
            self.assertEqual(len(findings), 0)


class TestRunLens(unittest.TestCase):
    """Test full helm_chart lens execution."""

    def test_no_chart_returns_empty(self):
        from tools.container_lens.lenses.helm_chart import run_lens
        result = run_lens({"helm_chart": None, "skip_checks": set()})
        self.assertEqual(result["lens_name"], "helm_chart")
        self.assertEqual(result["checks_run"], 0)

    def test_nonexistent_chart(self):
        from tools.container_lens.lenses.helm_chart import run_lens
        result = run_lens({
            "helm_chart": "/nonexistent/chart",
            "skip_checks": set(),
            "severity_overrides": {},
        })
        self.assertEqual(result["lens_name"], "helm_chart")
        self.assertGreater(len(result["findings"]), 0)

    def test_minimal_chart(self):
        from tools.container_lens.lenses.helm_chart import run_lens
        with tempfile.TemporaryDirectory() as td:
            chart_dir = Path(td) / "mychart"
            chart_dir.mkdir()
            (chart_dir / "templates").mkdir()
            (chart_dir / "Chart.yaml").write_text(textwrap.dedent("""\
                apiVersion: v2
                name: mychart
                version: 1.0.0
            """), encoding="utf-8")
            (chart_dir / "values.yaml").write_text("replicaCount: 1\n", encoding="utf-8")
            result = run_lens({
                "helm_chart": str(chart_dir),
                "skip_checks": set(),
                "severity_overrides": {},
            })
            self.assertEqual(result["lens_name"], "helm_chart")
            self.assertGreater(result["checks_run"], 0)


if __name__ == "__main__":
    unittest.main()
