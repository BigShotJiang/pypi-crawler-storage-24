# CUI // SP-CTI
"""Tests for tools.ci.gate_enforcer."""

import json

import pytest

from tools.ci.gate_enforcer import (
    _evaluate_block_condition,
    enforce_gate,
    list_stages,
    get_stage_gates,
)


class TestBlockConditionEvaluation:
    def test_any_finding_blocks(self):
        assert _evaluate_block_condition("any_finding", {"findings": [{"id": 1}]}) is True

    def test_any_finding_passes(self):
        assert _evaluate_block_condition("any_finding", {"findings": []}) is False

    def test_any_failure_blocks(self):
        assert _evaluate_block_condition("any_failure", {"failures": ["f1"]}) is True

    def test_missing_markings_blocks(self):
        assert _evaluate_block_condition("missing_markings", {"missing_markings": ["file.py"]}) is True

    def test_missing_markings_passes(self):
        assert _evaluate_block_condition("missing_markings", {"missing_markings": []}) is False

    def test_syntax_error_blocks(self):
        assert _evaluate_block_condition("syntax_error", {"syntax_errors": ["err"]}) is True

    def test_gate_failed_blocks(self):
        assert _evaluate_block_condition("gate_failed", {"gate_result": "FAIL"}) is True

    def test_gate_failed_passes(self):
        assert _evaluate_block_condition("gate_failed", {"gate_result": "PASS"}) is False

    def test_high_confidence_injection(self):
        assert _evaluate_block_condition("high_confidence_injection", {"high_confidence_count": 2}) is True
        assert _evaluate_block_condition("high_confidence_injection", {"high_confidence_count": 0}) is False

    def test_critical_failure(self):
        assert _evaluate_block_condition("critical_failure", {"status": "critical"}) is True
        assert _evaluate_block_condition("critical_failure", {"status": "healthy"}) is False

    def test_severity_list(self):
        output = {"findings": [{"severity": "critical"}, {"severity": "low"}]}
        assert _evaluate_block_condition({"severity": ["critical", "high"]}, output) is True

    def test_severity_list_passes(self):
        output = {"findings": [{"severity": "low"}]}
        assert _evaluate_block_condition({"severity": ["critical", "high"]}, output) is False

    def test_numeric_threshold_blocks(self):
        assert _evaluate_block_condition({"cat1_findings": 0}, {"cat1_findings": 3}) is True

    def test_numeric_threshold_passes(self):
        assert _evaluate_block_condition({"cat1_findings": 0}, {"cat1_findings": 0}) is False

    def test_maturity_below(self):
        assert _evaluate_block_condition(
            {"maturity_below": "advanced"}, {"maturity_below": "traditional"}
        ) is True

    def test_error_severity(self):
        output = {"errors": [{"severity": "error"}]}
        assert _evaluate_block_condition("error_severity", output) is True
        output2 = {"errors": [{"severity": "warning"}]}
        assert _evaluate_block_condition("error_severity", output2) is False


class TestListStages:
    def test_returns_list(self):
        stages = list_stages()
        assert isinstance(stages, list)
        # pipeline_gates.yaml defines these stages
        for expected in ["pre_commit", "build", "integration", "pre_deploy", "post_deploy"]:
            assert expected in stages


class TestGetStageGates:
    def test_build_stage_has_gates(self):
        gates = get_stage_gates("build")
        assert isinstance(gates, list)
        assert len(gates) > 0
        names = [g["name"] for g in gates]
        assert "unit_tests" in names

    def test_nonexistent_stage(self):
        gates = get_stage_gates("nonexistent_stage")
        assert gates == []


class TestEnforceGate:
    def test_missing_tool_fails(self):
        gate = {
            "name": "test_gate",
            "tool": "tools/nonexistent_tool_xyz.py",
            "blocking": True,
            "block_on": "any_failure",
            "timeout_seconds": 5,
        }
        result = enforce_gate(gate, ".")
        assert result["name"] == "test_gate"
        assert result["passed"] is False
        assert result["classification"] == "CUI // SP-CTI"

    def test_non_blocking_gate_does_not_block(self):
        gate = {
            "name": "advisory_gate",
            "tool": "tools/nonexistent_tool_xyz.py",
            "blocking": False,
            "timeout_seconds": 5,
        }
        result = enforce_gate(gate, ".")
        # Non-blocking gates don't set blocked=True even on failure
        assert result["blocked"] is False
