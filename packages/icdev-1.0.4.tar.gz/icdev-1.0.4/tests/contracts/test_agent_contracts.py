# CUI // SP-CTI
"""Contract tests for ICDEV agent-to-agent (A2A) communication.

These tests validate that agent request/response schemas conform to the
JSON-RPC 2.0 contracts defined in each agent's Agent Card.  They catch
schema drift between consumer expectations and provider implementations
without requiring all 12 agents to be running.

Run: pytest tests/contracts/ -v

Classification: CUI // SP-CTI
"""

import json
from typing import Any, Dict, List

import pytest


# ---------------------------------------------------------------------------
# Contract definitions
# ---------------------------------------------------------------------------
# Each contract defines the expected request params schema and response schema
# for a specific agent method.  These are the "consumer expectations" that
# providers must satisfy.

CONTRACTS: Dict[str, Dict[str, Any]] = {
    "compliance.ssp_generate": {
        "agent": "compliance",
        "method": "ssp_generate",
        "params_required": ["project_id"],
        "params_optional": ["baseline", "format"],
        "params_types": {
            "project_id": str,
            "baseline": str,
            "format": str,
        },
        "result_required": ["ssp_id", "classification"],
        "result_types": {
            "ssp_id": str,
            "classification": str,
        },
        "classification_pattern": "CUI",
    },
    "compliance.poam_generate": {
        "agent": "compliance",
        "method": "poam_generate",
        "params_required": ["project_id"],
        "params_optional": [],
        "params_types": {"project_id": str},
        "result_required": ["poam_id", "findings", "classification"],
        "result_types": {
            "poam_id": str,
            "findings": list,
            "classification": str,
        },
        "classification_pattern": "CUI",
    },
    "security.sast_scan": {
        "agent": "security",
        "method": "sast_scan",
        "params_required": ["project_dir"],
        "params_optional": ["severity_threshold"],
        "params_types": {"project_dir": str},
        "result_required": ["scan_id", "findings", "summary"],
        "result_types": {
            "scan_id": str,
            "findings": list,
            "summary": dict,
        },
    },
    "security.dep_audit": {
        "agent": "security",
        "method": "dep_audit",
        "params_required": ["project_dir"],
        "params_optional": [],
        "params_types": {"project_dir": str},
        "result_required": ["audit_id", "vulnerabilities"],
        "result_types": {
            "audit_id": str,
            "vulnerabilities": list,
        },
    },
    "builder.generate_code": {
        "agent": "builder",
        "method": "generate_code",
        "params_required": ["spec", "language"],
        "params_optional": ["style", "tests"],
        "params_types": {
            "spec": str,
            "language": str,
        },
        "result_required": ["code", "language"],
        "result_types": {
            "code": str,
            "language": str,
        },
    },
    "requirements.create_intake_session": {
        "agent": "requirements_analyst",
        "method": "create_intake_session",
        "params_required": ["project_id", "customer_name", "customer_org"],
        "params_optional": ["impact_level"],
        "params_types": {
            "project_id": str,
            "customer_name": str,
            "customer_org": str,
        },
        "result_required": ["session_id", "status"],
        "result_types": {
            "session_id": str,
            "status": str,
        },
    },
    "simulation.run_monte_carlo": {
        "agent": "simulation",
        "method": "run_monte_carlo",
        "params_required": ["scenario_id", "dimension", "iterations"],
        "params_optional": [],
        "params_types": {
            "scenario_id": str,
            "dimension": str,
            "iterations": int,
        },
        "result_required": ["simulation_id", "results"],
        "result_types": {
            "simulation_id": str,
            "results": dict,
        },
    },
    "devsecops.zta_maturity_score": {
        "agent": "devsecops_zta",
        "method": "zta_maturity_score",
        "params_required": ["project_id"],
        "params_optional": [],
        "params_types": {"project_id": str},
        "result_required": ["overall_score", "pillars"],
        "result_types": {
            "overall_score": (int, float),
            "pillars": (list, dict),
        },
    },
    "orchestrator.task_dispatch": {
        "agent": "orchestrator",
        "method": "task_dispatch",
        "params_required": ["target_agent", "method", "params"],
        "params_optional": ["priority", "timeout"],
        "params_types": {
            "target_agent": str,
            "method": str,
            "params": dict,
        },
        "result_required": ["task_id", "status"],
        "result_types": {
            "task_id": str,
            "status": str,
        },
    },
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def validate_schema_params(contract: Dict[str, Any], params: Dict[str, Any]) -> List[str]:
    """Validate that params conform to the contract."""
    errors = []
    for field in contract["params_required"]:
        if field not in params:
            errors.append(f"Missing required param: {field}")
    for field, value in params.items():
        expected_type = contract.get("params_types", {}).get(field)
        if expected_type and not isinstance(value, expected_type):
            errors.append(
                f"Param '{field}' expected {expected_type.__name__}, "
                f"got {type(value).__name__}"
            )
    return errors


def validate_schema_result(contract: Dict[str, Any], result: Dict[str, Any]) -> List[str]:
    """Validate that a result dict conforms to the contract."""
    errors = []
    for field in contract.get("result_required", []):
        if field not in result:
            errors.append(f"Missing required result field: {field}")
    for field, value in result.items():
        expected_type = contract.get("result_types", {}).get(field)
        if expected_type and not isinstance(value, expected_type):
            errors.append(
                f"Result '{field}' expected {expected_type}, "
                f"got {type(value).__name__}"
            )
    # Classification check
    pattern = contract.get("classification_pattern")
    if pattern:
        classification = result.get("classification", "")
        if pattern not in classification:
            errors.append(
                f"Classification must contain '{pattern}', got '{classification}'"
            )
    return errors


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestContractDefinitions:
    """Validate that contract definitions themselves are well-formed."""

    @pytest.mark.parametrize("contract_key", list(CONTRACTS.keys()))
    def test_contract_has_required_fields(self, contract_key):
        """Every contract must define agent, method, params_required, result_required."""
        contract = CONTRACTS[contract_key]
        assert "agent" in contract, f"{contract_key}: missing 'agent'"
        assert "method" in contract, f"{contract_key}: missing 'method'"
        assert "params_required" in contract, f"{contract_key}: missing 'params_required'"
        assert "result_required" in contract, f"{contract_key}: missing 'result_required'"

    @pytest.mark.parametrize("contract_key", list(CONTRACTS.keys()))
    def test_contract_key_matches_agent_method(self, contract_key):
        """Contract key must be 'agent.method'."""
        contract = CONTRACTS[contract_key]
        expected_key = f"{contract['agent']}.{contract['method']}"
        # Allow key prefix to differ from agent name (e.g. compliance vs compliance_agent)
        assert contract["method"] in contract_key


class TestParamValidation:
    """Validate that contract param schemas catch violations."""

    def test_missing_required_param_detected(self):
        contract = CONTRACTS["compliance.ssp_generate"]
        errors = validate_schema_params(contract, {})
        assert any("project_id" in e for e in errors)

    def test_valid_params_pass(self):
        contract = CONTRACTS["compliance.ssp_generate"]
        errors = validate_schema_params(contract, {"project_id": "sparkpilot"})
        assert errors == []

    def test_wrong_type_detected(self):
        contract = CONTRACTS["simulation.run_monte_carlo"]
        errors = validate_schema_params(
            contract,
            {"scenario_id": "sc-1", "dimension": "schedule", "iterations": "not_int"},
        )
        assert any("iterations" in e for e in errors)


class TestResultValidation:
    """Validate that contract result schemas catch violations."""

    def test_missing_required_result_field(self):
        contract = CONTRACTS["compliance.ssp_generate"]
        errors = validate_schema_result(contract, {"ssp_id": "ssp-1"})
        assert any("classification" in e for e in errors)

    def test_classification_enforcement(self):
        contract = CONTRACTS["compliance.ssp_generate"]
        errors = validate_schema_result(
            contract,
            {"ssp_id": "ssp-1", "classification": "UNCLASSIFIED"},
        )
        assert any("CUI" in e for e in errors)

    def test_valid_result_passes(self):
        contract = CONTRACTS["compliance.ssp_generate"]
        errors = validate_schema_result(
            contract,
            {"ssp_id": "ssp-1", "classification": "CUI // SP-CTI"},
        )
        assert errors == []


class TestJsonRpcEnvelope:
    """Validate JSON-RPC 2.0 envelope structure."""

    def test_valid_request_envelope(self):
        """A JSON-RPC 2.0 request must have jsonrpc, method, id."""
        request = {
            "jsonrpc": "2.0",
            "method": "ssp_generate",
            "params": {"project_id": "sparkpilot"},
            "id": 1,
        }
        assert request["jsonrpc"] == "2.0"
        assert "method" in request
        assert "id" in request

    def test_valid_response_envelope(self):
        """A JSON-RPC 2.0 response must have jsonrpc, result or error, id."""
        response = {
            "jsonrpc": "2.0",
            "result": {"ssp_id": "ssp-1", "classification": "CUI // SP-CTI"},
            "id": 1,
        }
        assert response["jsonrpc"] == "2.0"
        assert "result" in response or "error" in response
        assert "id" in response

    def test_error_response_envelope(self):
        """Error responses must have code and message."""
        response = {
            "jsonrpc": "2.0",
            "error": {"code": -32600, "message": "Invalid Request"},
            "id": 1,
        }
        assert "code" in response["error"]
        assert "message" in response["error"]
