# CUI // SP-CTI
"""Contract tests for A2A agent communication schemas."""
