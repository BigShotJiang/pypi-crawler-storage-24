"""WriteGuard Snippet Manager tests (~20 tests)."""
from __future__ import annotations

import sqlite3

import pytest

from tools.writing.snippet_manager import (
    CATEGORIES,
    add_snippet,
    archive_snippet,
    get_snippet,
    increment_usage,
    list_snippets,
    search_snippets,
    update_snippet,
)


@pytest.fixture
def db_path(tmp_path):
    """Create a temporary database with wg_snippets table."""
    path = tmp_path / "test_snippets.db"
    conn = sqlite3.connect(str(path))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS wg_snippets (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            category TEXT NOT NULL,
            domain TEXT DEFAULT 'general',
            tags TEXT DEFAULT '[]',
            usage_count INTEGER DEFAULT 0,
            status TEXT DEFAULT 'active',
            tenant_id TEXT DEFAULT '',
            project_id TEXT DEFAULT '',
            created_by TEXT DEFAULT '',
            classification TEXT NOT NULL DEFAULT 'CUI',
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
    """)
    conn.close()
    return str(path)


# ── Constants ──────────────────────────────────────────────────────


class TestConstants:

    def test_categories_is_tuple(self):
        assert isinstance(CATEGORIES, tuple)

    def test_categories_has_expected_values(self):
        expected = {"boilerplate", "transition", "introduction", "conclusion",
                    "methodology", "compliance", "evidence", "custom"}
        assert set(CATEGORIES) == expected


# ── add_snippet ────────────────────────────────────────────────────


class TestAddSnippet:

    def test_returns_dict_with_id(self, db_path):
        result = add_snippet("Test Title", "Test content", "boilerplate",
                             db_path=db_path)
        assert "id" in result
        assert result["id"].startswith("wg-sn-")

    def test_returns_title(self, db_path):
        result = add_snippet("My Snippet", "Some content", "custom", db_path=db_path)
        assert result["title"] == "My Snippet"

    def test_invalid_category(self, db_path):
        result = add_snippet("Bad", "Content", "invalid_category", db_path=db_path)
        assert "error" in result

    def test_with_tags(self, db_path):
        result = add_snippet("Tagged", "Content", "boilerplate",
                             tags=["gov", "proposal"], db_path=db_path)
        assert "id" in result

    def test_with_domain(self, db_path):
        result = add_snippet("Domain", "Content", "methodology",
                             domain="cybersecurity", db_path=db_path)
        assert "id" in result

    def test_empty_title_error(self, db_path):
        result = add_snippet("", "Content", "boilerplate", db_path=db_path)
        assert "error" in result or "id" in result  # impl may allow empty


# ── get_snippet ────────────────────────────────────────────────────


class TestGetSnippet:

    def test_get_existing(self, db_path):
        created = add_snippet("Get Test", "Get content", "evidence", db_path=db_path)
        result = get_snippet(created["id"], db_path=db_path)
        assert result["title"] == "Get Test"
        assert result["content"] == "Get content"

    def test_get_nonexistent(self, db_path):
        result = get_snippet("no-such-id", db_path=db_path)
        assert "error" in result or result is None or result == {}

    def test_tags_parsed_as_list(self, db_path):
        created = add_snippet("Tags", "Content", "boilerplate",
                              tags=["a", "b"], db_path=db_path)
        result = get_snippet(created["id"], db_path=db_path)
        assert isinstance(result.get("tags"), list)


# ── list_snippets ──────────────────────────────────────────────────


class TestListSnippets:

    def test_list_empty(self, db_path):
        result = list_snippets(db_path=db_path)
        assert isinstance(result, list)
        assert len(result) == 0

    def test_list_after_add(self, db_path):
        add_snippet("L1", "Content", "boilerplate", db_path=db_path)
        add_snippet("L2", "Content", "custom", db_path=db_path)
        result = list_snippets(db_path=db_path)
        assert len(result) == 2

    def test_list_filter_category(self, db_path):
        add_snippet("C1", "Content", "boilerplate", db_path=db_path)
        add_snippet("C2", "Content", "evidence", db_path=db_path)
        result = list_snippets(category="boilerplate", db_path=db_path)
        assert all(s["category"] == "boilerplate" for s in result)

    def test_list_filter_domain(self, db_path):
        add_snippet("D1", "Content", "boilerplate", domain="gov", db_path=db_path)
        add_snippet("D2", "Content", "boilerplate", domain="tech", db_path=db_path)
        result = list_snippets(domain="gov", db_path=db_path)
        assert len(result) >= 1


# ── search_snippets ────────────────────────────────────────────────


class TestSearchSnippets:

    def test_search_returns_list(self, db_path):
        add_snippet("FedRAMP Boilerplate", "FedRAMP compliance template",
                     "compliance", db_path=db_path)
        result = search_snippets("FedRAMP", db_path=db_path)
        assert isinstance(result, list)

    def test_search_empty_query(self, db_path):
        result = search_snippets("", db_path=db_path)
        assert isinstance(result, list)


# ── update_snippet ─────────────────────────────────────────────────


class TestUpdateSnippet:

    def test_update_title(self, db_path):
        created = add_snippet("Old Title", "Content", "boilerplate", db_path=db_path)
        result = update_snippet(created["id"], title="New Title", db_path=db_path)
        assert result.get("status") == "updated" or "id" in result

    def test_update_nonexistent(self, db_path):
        result = update_snippet("no-such-id", title="New", db_path=db_path)
        assert "error" in result


# ── increment_usage ────────────────────────────────────────────────


class TestIncrementUsage:

    def test_increment(self, db_path):
        created = add_snippet("Usage", "Content", "boilerplate", db_path=db_path)
        result = increment_usage(created["id"], db_path=db_path)
        assert result["usage_count"] == 1

    def test_double_increment(self, db_path):
        created = add_snippet("Usage2", "Content", "boilerplate", db_path=db_path)
        increment_usage(created["id"], db_path=db_path)
        result = increment_usage(created["id"], db_path=db_path)
        assert result["usage_count"] == 2


# ── archive_snippet ────────────────────────────────────────────────


class TestArchiveSnippet:

    def test_archive(self, db_path):
        created = add_snippet("Archivable", "Content", "boilerplate", db_path=db_path)
        result = archive_snippet(created["id"], db_path=db_path)
        assert result["status"] == "archived"

    def test_archived_not_in_active_list(self, db_path):
        created = add_snippet("To Archive", "Content", "boilerplate", db_path=db_path)
        archive_snippet(created["id"], db_path=db_path)
        result = list_snippets(status="active", db_path=db_path)
        assert all(s["id"] != created["id"] for s in result)
