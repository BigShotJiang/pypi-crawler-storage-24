# CUI // SP-CTI
"""Tests for DataBridge Scale Engine (D-SC-1 through D-SC-7).

Tests worker pool, connection pool, write batcher, backpressure,
chunked pipeline, and scale engine orchestrator.
"""
import os
import sqlite3
import tempfile
import threading
import time
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# TestWorkerPool
# ---------------------------------------------------------------------------

class TestWorkerPool:
    """Tests for ScaleWorkerPool."""

    def test_submit_and_complete(self):
        from tools.databridge.scale.worker_pool import ScaleWorkerPool

        pool = ScaleWorkerPool(max_workers=2, max_concurrent_syncs=2)
        future = pool.submit_sync(lambda: 42)
        assert future.result(timeout=5) == 42
        pool.shutdown()

    def test_semaphore_enforcement(self):
        """Submit more tasks than max_concurrent_syncs, verify queueing."""
        from tools.databridge.scale.worker_pool import ScaleWorkerPool

        barrier = threading.Event()
        results = []

        def slow_fn(idx):
            barrier.wait(timeout=5)
            results.append(idx)
            return idx

        pool = ScaleWorkerPool(max_workers=4, max_concurrent_syncs=2)
        futures = [pool.submit_sync(slow_fn, i) for i in range(4)]

        # Only 2 should be running (semaphore=2)
        time.sleep(0.1)
        active = pool.get_active_count()
        assert active <= 4  # all submitted, but semaphore limits execution

        barrier.set()
        for f in futures:
            f.result(timeout=5)

        assert len(results) == 4
        pool.shutdown()

    def test_timeout_enforcement(self):
        """Submit slow function, verify timeout raises."""
        from tools.databridge.scale.worker_pool import ScaleWorkerPool

        pool = ScaleWorkerPool(max_workers=1, max_concurrent_syncs=1, sync_timeout_seconds=1)

        def slow():
            time.sleep(10)

        future = pool.submit_sync(slow)
        with pytest.raises(Exception):
            pool.get_result(future, timeout=0.5)
        pool.shutdown(wait=False)

    def test_status_counts(self):
        from tools.databridge.scale.worker_pool import ScaleWorkerPool

        pool = ScaleWorkerPool(max_workers=2, max_concurrent_syncs=2)
        future = pool.submit_sync(lambda: "ok")
        future.result(timeout=5)
        time.sleep(0.1)  # callback propagation

        status = pool.status()
        assert status["submitted"] >= 1
        assert status["completed"] >= 1
        pool.shutdown()

    def test_shutdown_after_shutdown_raises(self):
        from tools.databridge.scale.worker_pool import ScaleWorkerPool

        pool = ScaleWorkerPool(max_workers=1, max_concurrent_syncs=1)
        pool.shutdown()
        with pytest.raises(RuntimeError):
            pool.submit_sync(lambda: 1)


# ---------------------------------------------------------------------------
# TestConnectionPool
# ---------------------------------------------------------------------------

class TestConnectionPool:
    """Tests for ConnectionPool."""

    def _make_mock_connector(self, name="test"):
        connector = MagicMock()
        connector.connector_name = name
        connector.connect.return_value = True
        connector.health_check.return_value = {"status": "healthy"}
        connector.capabilities.supports_write = True
        return connector

    def test_acquire_creates_new(self):
        from tools.databridge.scale.connection_pool import ConnectionPool

        pool = ConnectionPool(max_per_type=2)
        factory = lambda: self._make_mock_connector()

        conn = pool.acquire("test", {"host": "localhost"}, connector_factory=factory)
        assert conn is not None
        assert pool.stats()["creates"] == 1
        pool.release(conn)
        pool.drain()

    def test_acquire_reuses_idle(self):
        from tools.databridge.scale.connection_pool import ConnectionPool

        pool = ConnectionPool(max_per_type=2)
        mock = self._make_mock_connector()
        factory = lambda: mock

        conn1 = pool.acquire("test", {"host": "localhost"}, connector_factory=factory)
        pool.release(conn1)

        conn2 = pool.acquire("test", {"host": "localhost"}, connector_factory=factory)
        assert conn2 is conn1  # same instance reused
        assert pool.stats()["creates"] == 1  # only 1 create
        pool.release(conn2)
        pool.drain()

    def test_config_change_invalidates(self):
        from tools.databridge.scale.connection_pool import ConnectionPool

        pool = ConnectionPool(max_per_type=3)
        mock1 = self._make_mock_connector()
        mock2 = self._make_mock_connector()
        call_count = [0]

        def factory():
            call_count[0] += 1
            return mock1 if call_count[0] == 1 else mock2

        conn1 = pool.acquire("test", {"host": "a"}, connector_factory=factory)
        pool.release(conn1)

        # Different config hash — should create new
        conn2 = pool.acquire("test", {"host": "b"}, connector_factory=factory)
        assert conn2 is not conn1
        assert pool.stats()["creates"] == 2
        pool.release(conn2)
        pool.drain()

    def test_max_per_type_blocks(self):
        from tools.databridge.scale.connection_pool import ConnectionPool

        pool = ConnectionPool(max_per_type=1)
        mocks = [self._make_mock_connector() for _ in range(2)]
        idx = [0]

        def factory():
            m = mocks[idx[0]]
            idx[0] += 1
            return m

        conn1 = pool.acquire("test", {"host": "a"}, connector_factory=factory, timeout=1)

        # Pool is full (1/1 in use), should timeout
        with pytest.raises(TimeoutError):
            pool.acquire("test", {"host": "a"}, connector_factory=factory, timeout=0.5)

        pool.release(conn1)
        pool.drain()

    def test_health_check_on_acquire(self):
        from tools.databridge.scale.connection_pool import ConnectionPool

        pool = ConnectionPool(max_per_type=2, health_check_on_acquire=True)
        mock = self._make_mock_connector()
        mock.health_check.return_value = {"status": "healthy"}
        factory = lambda: mock

        conn = pool.acquire("test", {"host": "a"}, connector_factory=factory)
        pool.release(conn)

        # Re-acquire should trigger health check
        conn2 = pool.acquire("test", {"host": "a"}, connector_factory=factory)
        assert mock.health_check.called
        pool.release(conn2)
        pool.drain()

    def test_drain_disconnects_all(self):
        from tools.databridge.scale.connection_pool import ConnectionPool

        pool = ConnectionPool(max_per_type=3)
        mocks = []
        for _ in range(3):
            m = self._make_mock_connector()
            mocks.append(m)

        idx = [0]
        def factory():
            m = mocks[idx[0]]
            idx[0] += 1
            return m

        conns = [pool.acquire("test", {"host": "a"}, connector_factory=factory) for _ in range(3)]
        for c in conns:
            pool.release(c)

        count = pool.drain()
        assert count == 3
        for m in mocks:
            m.disconnect.assert_called()


# ---------------------------------------------------------------------------
# TestWriteBatcher
# ---------------------------------------------------------------------------

class TestWriteBatcher:
    """Tests for WriteBatcher."""

    def _make_db(self):
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        conn = sqlite3.connect(path)
        conn.execute("""CREATE TABLE db_sync_log (
            connection_id TEXT, sync_direction TEXT, table_name TEXT,
            rows_read INTEGER, rows_written INTEGER, rows_failed INTEGER,
            bytes_transferred INTEGER, sync_duration_ms INTEGER,
            incremental_key TEXT, incremental_value TEXT,
            error_details TEXT, classification TEXT, synced_at TEXT
        )""")
        conn.execute("""CREATE TABLE audit_trail (
            id TEXT, event_type TEXT, actor TEXT, action TEXT,
            details TEXT, classification TEXT, created_at TEXT
        )""")
        conn.commit()
        conn.close()
        return path

    def test_enqueue_and_flush(self):
        from tools.databridge.scale.write_batcher import WriteBatcher

        db_path = self._make_db()
        batcher = WriteBatcher(db_path=db_path, flush_interval_ms=100, max_buffer_size=10)
        batcher.start()

        batcher.enqueue_sync_log(
            connection_id="conn-1",
            sync_direction="read",
            table_name="users",
            rows_read=100,
        )
        batcher.enqueue_audit(action="test_action", details="test details")

        time.sleep(0.5)  # wait for flush
        batcher.stop()

        conn = sqlite3.connect(db_path)
        sync_rows = conn.execute("SELECT COUNT(*) FROM db_sync_log").fetchone()[0]
        audit_rows = conn.execute("SELECT COUNT(*) FROM audit_trail").fetchone()[0]
        conn.close()

        assert sync_rows >= 1
        assert audit_rows >= 1
        os.unlink(db_path)

    def test_graceful_shutdown_flushes(self):
        from tools.databridge.scale.write_batcher import WriteBatcher

        db_path = self._make_db()
        batcher = WriteBatcher(db_path=db_path, flush_interval_ms=60000, max_buffer_size=1000)
        batcher.start()

        for i in range(5):
            batcher.enqueue_sync_log(
                connection_id=f"conn-{i}",
                sync_direction="read",
                table_name="t",
            )

        batcher.stop()  # should flush remaining

        conn = sqlite3.connect(db_path)
        count = conn.execute("SELECT COUNT(*) FROM db_sync_log").fetchone()[0]
        conn.close()
        assert count == 5
        os.unlink(db_path)

    def test_stats(self):
        from tools.databridge.scale.write_batcher import WriteBatcher

        db_path = self._make_db()
        batcher = WriteBatcher(db_path=db_path)
        batcher.start()
        batcher.enqueue_sync_log(connection_id="c1", sync_direction="read")
        time.sleep(0.2)

        stats = batcher.stats()
        assert stats["enqueued"] >= 1
        assert stats["started"] is True
        batcher.stop()
        os.unlink(db_path)


# ---------------------------------------------------------------------------
# TestBackpressureController
# ---------------------------------------------------------------------------

class TestBackpressureController:
    """Tests for BackpressureController."""

    def test_no_psutil_fallback(self):
        from tools.databridge.scale.backpressure import BackpressureController

        with patch("tools.databridge.scale.backpressure._detect_memory_backend", return_value="none"):
            bp = BackpressureController(memory_threshold_mb=100)
            assert bp.get_memory_bytes() == -1
            assert bp.should_pause() is False

    def test_pause_resume_stream(self):
        from tools.databridge.scale.backpressure import BackpressureController

        bp = BackpressureController()
        assert not bp.is_paused("stream-1")

        bp.pause_stream("stream-1")
        assert bp.is_paused("stream-1")

        bp.resume_stream("stream-1")
        assert not bp.is_paused("stream-1")

    def test_resume_all(self):
        from tools.databridge.scale.backpressure import BackpressureController

        bp = BackpressureController()
        bp.pause_stream("s1")
        bp.pause_stream("s2")
        count = bp.resume_all()
        assert count == 2
        assert not bp.is_paused("s1")

    def test_status(self):
        from tools.databridge.scale.backpressure import BackpressureController

        bp = BackpressureController(memory_threshold_mb=512)
        status = bp.status()
        assert "backend" in status
        assert status["threshold_mb"] == 512


# ---------------------------------------------------------------------------
# TestChunkedPipeline
# ---------------------------------------------------------------------------

class TestChunkedPipeline:
    """Tests for ChunkedPipeline."""

    @pytest.fixture
    def arrow_available(self):
        try:
            import pyarrow
            return True
        except ImportError:
            return False

    def test_passthrough_no_pipeline(self, arrow_available):
        if not arrow_available:
            pytest.skip("pyarrow not installed")

        import pyarrow as pa
        from tools.databridge.scale.chunked_pipeline import ChunkedPipeline

        table = pa.table({"a": [1, 2, 3, 4, 5], "b": ["x", "y", "z", "w", "v"]})
        cp = ChunkedPipeline(pipeline=None, chunk_size=2)
        result = cp.execute(table)
        assert result["status"] == "ok"
        assert result["row_count"] == 5

    def test_streaming_yields_chunks(self, arrow_available):
        if not arrow_available:
            pytest.skip("pyarrow not installed")

        import pyarrow as pa
        from tools.databridge.scale.chunked_pipeline import ChunkedPipeline

        table = pa.table({"x": list(range(10))})
        cp = ChunkedPipeline(pipeline=None, chunk_size=3)
        chunks = list(cp.execute_streaming(table))
        assert len(chunks) == 4  # 3+3+3+1
        assert chunks[0]["chunk_index"] == 0
        assert chunks[-1]["chunk_index"] == 3

    def test_no_arrow_error(self):
        from tools.databridge.scale.chunked_pipeline import ChunkedPipeline

        with patch("tools.databridge.scale.chunked_pipeline.HAS_ARROW", False):
            cp = ChunkedPipeline(chunk_size=10)
            result = cp.execute("fake_data")
            assert result["status"] == "error"


# ---------------------------------------------------------------------------
# TestScaleEngine
# ---------------------------------------------------------------------------

class TestScaleEngine:
    """Tests for ScaleEngine."""

    def test_start_stop_lifecycle(self):
        from tools.databridge.scale.engine import ScaleEngine

        engine = ScaleEngine(config={})
        engine.start()
        assert engine._started is True

        status = engine.status()
        assert status["started"] is True
        assert "worker_pool" in status
        assert "connection_pool" in status
        assert "write_batcher" in status
        assert "backpressure" in status

        engine.stop()
        assert engine._started is False

    def test_status_aggregation(self):
        from tools.databridge.scale.engine import ScaleEngine

        engine = ScaleEngine(config={
            "worker_pool": {"max_workers": 4, "max_concurrent_syncs": 2},
            "backpressure": {"memory_threshold_mb": 256},
        })
        engine.start()
        status = engine.status()

        assert status["worker_pool"]["max_workers"] == 4
        assert status["worker_pool"]["max_concurrent_syncs"] == 2
        assert status["backpressure"]["threshold_mb"] == 256
        engine.stop()

    def test_singleton_lifecycle(self):
        import tools.databridge.scale.engine as eng

        # Reset singleton
        eng._ENGINE = None

        engine = eng.get_scale_engine()
        assert engine is not None

        engine2 = eng.get_scale_engine()
        assert engine2 is engine  # same instance

        eng.shutdown_scale_engine()
        assert eng._ENGINE is None

    def test_backward_compat_sync_read_import(self):
        """Verify sync_read still imports and has use_scale_engine param."""
        from tools.databridge.sync_engine import sync_read
        import inspect
        sig = inspect.signature(sync_read)
        assert "use_scale_engine" in sig.parameters
