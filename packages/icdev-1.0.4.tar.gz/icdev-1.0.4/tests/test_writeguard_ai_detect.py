"""WriteGuard AI Content Detection tests (~25 tests)."""
from __future__ import annotations

import pytest

from tools.writing.ai_content_detector import detect_ai_content


class TestDetectAiContent:
    """Tests for AI-generated content detection."""

    def test_returns_dict(self):
        result = detect_ai_content("This is a simple test sentence.")
        assert isinstance(result, dict)

    def test_has_ai_score(self):
        result = detect_ai_content("Hello world.")
        assert "ai_score" in result
        assert isinstance(result["ai_score"], (int, float))

    def test_ai_score_range(self):
        result = detect_ai_content("The project was completed on time.")
        assert 0 <= result["ai_score"] <= 1

    def test_has_interpretation(self):
        result = detect_ai_content("Testing the interpretation field.")
        assert "interpretation" in result
        assert isinstance(result["interpretation"], str)

    def test_has_confidence(self):
        result = detect_ai_content("Another test sentence here.")
        assert "confidence" in result

    def test_has_signals(self):
        result = detect_ai_content("The signals dict should be present.")
        assert "signals" in result
        assert isinstance(result["signals"], dict)

    def test_has_stats(self):
        result = detect_ai_content("Stats should include word counts.")
        assert "stats" in result
        assert isinstance(result["stats"], dict)

    def test_advisory_flag(self):
        result = detect_ai_content("Advisory mode is always true.")
        assert "advisory" in result
        assert result["advisory"] is True

    def test_empty_text(self):
        result = detect_ai_content("")
        assert result["ai_score"] == 0 or isinstance(result["ai_score"], (int, float))

    def test_single_word(self):
        result = detect_ai_content("Hello.")
        assert isinstance(result["ai_score"], (int, float))

    def test_human_like_text(self):
        """Natural human text with varied sentence structure."""
        text = (
            "I went to the store yesterday. Man, the prices are crazy! "
            "Got some milk, bread, and oh yeah - those cookies my kid likes. "
            "Traffic was terrible coming home. Why is it always like that on Tuesdays?"
        )
        result = detect_ai_content(text)
        # Human text should have lower AI score
        assert result["ai_score"] >= 0  # Just verify it works

    def test_ai_like_text(self):
        """Stereotypically AI-generated text with uniform structure."""
        text = (
            "The implementation of advanced machine learning algorithms requires "
            "careful consideration of multiple factors. These factors include data "
            "preprocessing, feature engineering, model selection, and hyperparameter "
            "tuning. Additionally, it is important to consider the computational "
            "resources available and the specific requirements of the application. "
            "Furthermore, the deployment of such models necessitates robust "
            "monitoring and maintenance procedures to ensure optimal performance."
        )
        result = detect_ai_content(text)
        # AI text might score higher
        assert result["ai_score"] >= 0  # Just verify it works

    def test_signals_have_subscores(self):
        text = "This is a test with enough words to generate meaningful signals."
        result = detect_ai_content(text)
        signals = result["signals"]
        # Should have sub-score categories
        assert isinstance(signals, dict)

    def test_very_short_text(self):
        result = detect_ai_content("Yes.")
        assert isinstance(result, dict)

    def test_repetitive_text(self):
        """Repetitive text should affect burstiness/repetition scores."""
        text = "The system works. The system is good. The system delivers results. "
        text += "The system provides value. The system meets requirements."
        result = detect_ai_content(text)
        assert isinstance(result["signals"], dict)

    def test_varied_text(self):
        """Varied text should have different patterns."""
        text = (
            "Quick fox jumps! Really, who does that? "
            "I've never seen anything like it in my 20 years. "
            "But hey, stranger things have happened."
        )
        result = detect_ai_content(text)
        assert isinstance(result, dict)

    def test_long_text_performance(self):
        """Should handle long text without error."""
        text = "This is a sentence. " * 500
        result = detect_ai_content(text)
        assert isinstance(result["ai_score"], (int, float))

    def test_special_characters(self):
        result = detect_ai_content("Test with special chars: @#$% & *!")
        assert isinstance(result, dict)

    def test_numeric_text(self):
        result = detect_ai_content("The values are 42, 17, and 99.5 percent.")
        assert isinstance(result, dict)

    def test_multiline_text(self):
        text = "First paragraph.\n\nSecond paragraph.\n\nThird paragraph."
        result = detect_ai_content(text)
        assert isinstance(result, dict)

    def test_code_snippet_text(self):
        text = "Use the function: def calculate(x): return x * 2"
        result = detect_ai_content(text)
        assert isinstance(result, dict)

    def test_bullet_point_text(self):
        text = "Key points:\n- First item\n- Second item\n- Third item"
        result = detect_ai_content(text)
        assert isinstance(result, dict)

    def test_mixed_case_text(self):
        text = "ALL CAPS TEXT mixed with Normal Case and lowercase text."
        result = detect_ai_content(text)
        assert isinstance(result, dict)

    def test_unicode_text(self):
        text = "Testing with unicode characters like and special marks."
        result = detect_ai_content(text)
        assert isinstance(result, dict)
