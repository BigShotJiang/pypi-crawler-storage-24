# CUI // SP-CTI
"""Tests for the lightweight DI container.

Classification: CUI // SP-CTI
"""

import pytest

from tools.core.container import ServiceContainer, container


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def svc():
    """Fresh container per test."""
    c = ServiceContainer()
    yield c
    c.reset()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestServiceContainer:

    def test_register_and_resolve(self, svc):
        svc.register("greeting", lambda: "hello")
        assert svc.resolve("greeting") == "hello"

    def test_resolve_unknown_raises(self, svc):
        with pytest.raises(KeyError, match="not_registered"):
            svc.resolve("not_registered")

    def test_transient_creates_new_each_time(self, svc):
        svc.register("counter", lambda: object())
        a = svc.resolve("counter")
        b = svc.resolve("counter")
        assert a is not b

    def test_singleton_returns_same_instance(self, svc):
        svc.register("single", lambda: object(), singleton=True)
        a = svc.resolve("single")
        b = svc.resolve("single")
        assert a is b

    def test_re_register_clears_singleton(self, svc):
        svc.register("db", lambda: "prod_conn", singleton=True)
        prod = svc.resolve("db")
        assert prod == "prod_conn"

        svc.register("db", lambda: "test_conn", singleton=True)
        test = svc.resolve("db")
        assert test == "test_conn"

    def test_has(self, svc):
        assert svc.has("x") is False
        svc.register("x", lambda: 1)
        assert svc.has("x") is True

    def test_reset_clears_all(self, svc):
        svc.register("a", lambda: 1)
        svc.register("b", lambda: 2, singleton=True)
        svc.resolve("b")
        svc.reset()
        assert svc.has("a") is False
        assert svc.has("b") is False

    def test_registered_services(self, svc):
        svc.register("alpha", lambda: 1)
        svc.register("beta", lambda: 2)
        names = svc.registered_services()
        assert "alpha" in names
        assert "beta" in names


class TestModuleLevelContainer:
    """The module-level singleton should be importable and functional."""

    def test_module_container_exists(self):
        assert isinstance(container, ServiceContainer)
