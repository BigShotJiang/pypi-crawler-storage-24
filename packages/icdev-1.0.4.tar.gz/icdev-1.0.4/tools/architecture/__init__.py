# CUI // SP-CTI
# tools/architecture — Architecture decision record extraction utilities
