#!/usr/bin/env python3
# CUI // SP-CTI
"""VSM (Value Stream Mapping) Dashboard Engine.

Instruments the ATLAS pipeline (architect -> trace -> link -> assemble ->
stress_test) and computes DORA metrics (deployment frequency, lead time,
change failure rate, MTTR).  Detects stage-level bottlenecks via p90
analysis.

Tables used:
  - vsm_stage_events     (read/write stage events)
  - vsm_dora_snapshots   (write DORA metric snapshots)
  - audit_trail           (read deploy/test events, write audit entries)

CLI:
  python tools/analytics/vsm_engine.py --project-id <id> --record-event --stage architect --event-type started --pipeline-run-id run-001 --json
  python tools/analytics/vsm_engine.py --project-id <id> --dora --days 30 --json
  python tools/analytics/vsm_engine.py --project-id <id> --bottlenecks --json
  python tools/analytics/vsm_engine.py --project-id <id> --pipelines --json
"""

import argparse
import json
import sqlite3
import sys
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"

try:
    from tools.compat.db_utils import get_db_connection
except ImportError:
    get_db_connection = None

# ---------------------------------------------------------------------------
# Valid stage / event-type enums
# ---------------------------------------------------------------------------

VALID_STAGES = ("architect", "trace", "link", "assemble", "stress_test")
VALID_EVENT_TYPES = ("started", "completed", "failed", "blocked")


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def _get_connection(db_path=None):
    """Return a sqlite3 connection with Row factory.

    Tries tools.compat.db_utils first, falls back to direct connect.
    """
    if db_path is None and get_db_connection is not None:
        try:
            conn = get_db_connection()
            conn.row_factory = sqlite3.Row
            return conn
        except Exception:
            pass
    path = Path(db_path) if db_path else DB_PATH
    if not path.exists():
        raise FileNotFoundError(
            f"Database not found: {path}\n"
            "Run: python tools/db/init_icdev_db.py"
        )
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _ensure_tables(conn):
    """Create VSM tables if they do not exist."""
    conn.execute(
        "CREATE TABLE IF NOT EXISTS vsm_stage_events ("
        "id TEXT PRIMARY KEY, "
        "project_id TEXT NOT NULL, "
        "pipeline_run_id TEXT NOT NULL, "
        "stage TEXT NOT NULL, "
        "event_type TEXT NOT NULL, "
        "actor TEXT, "
        "duration_seconds REAL, "
        "metadata TEXT, "
        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"
    )
    conn.execute(
        "CREATE TABLE IF NOT EXISTS vsm_dora_snapshots ("
        "id TEXT PRIMARY KEY, "
        "project_id TEXT NOT NULL, "
        "period_days INTEGER NOT NULL, "
        "deployment_frequency REAL, "
        "lead_time_hours REAL, "
        "change_failure_rate REAL, "
        "mttr_hours REAL, "
        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"
    )
    conn.commit()


def _log_audit(conn, project_id, event_type, action, details):
    """Append-only audit trail entry (INSERT only — NIST AU)."""
    try:
        conn.execute(
            "INSERT INTO audit_trail "
            "(project_id, event_type, actor, action, details, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                project_id,
                event_type,
                "sparkpilot-vsm-engine",
                action,
                json.dumps(details) if isinstance(details, dict) else str(details),
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        conn.commit()
    except Exception as exc:
        print(f"Warning: audit log failed: {exc}", file=sys.stderr)


def _uid() -> str:
    return uuid.uuid4().hex[:12]


# ---------------------------------------------------------------------------
# Percentile helper (stdlib only — linear interpolation)
# ---------------------------------------------------------------------------

def _percentile(sorted_values: List[float], pct: float) -> float:
    """Compute percentile via linear interpolation on a pre-sorted list."""
    if not sorted_values:
        return 0.0
    n = len(sorted_values)
    if n == 1:
        return sorted_values[0]
    k = (pct / 100.0) * (n - 1)
    lo = int(k)
    hi = min(lo + 1, n - 1)
    frac = k - lo
    return sorted_values[lo] + frac * (sorted_values[hi] - sorted_values[lo])


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def record_stage_event(
    project_id: str,
    pipeline_run_id: str,
    stage: str,
    event_type: str,
    actor: Optional[str] = None,
    duration_seconds: Optional[float] = None,
    metadata: Optional[Dict[str, Any]] = None,
    db_path=None,
) -> dict:
    """Record an ATLAS pipeline stage event.

    Args:
        project_id: Project identifier.
        pipeline_run_id: Unique pipeline run identifier.
        stage: One of architect, trace, link, assemble, stress_test.
        event_type: One of started, completed, failed, blocked.
        actor: Optional actor/agent name.
        duration_seconds: Optional stage duration in seconds.
        metadata: Optional JSON-serialisable metadata dict.
        db_path: Optional database path override.

    Returns:
        dict with id, stage, event_type, recorded.
    """
    if stage not in VALID_STAGES:
        raise ValueError(f"Invalid stage '{stage}'. Must be one of {VALID_STAGES}")
    if event_type not in VALID_EVENT_TYPES:
        raise ValueError(f"Invalid event_type '{event_type}'. Must be one of {VALID_EVENT_TYPES}")

    conn = _get_connection(db_path)
    try:
        _ensure_tables(conn)
        event_id = _uid()
        conn.execute(
            "INSERT INTO vsm_stage_events "
            "(id, project_id, pipeline_run_id, stage, event_type, actor, "
            "duration_seconds, metadata, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                event_id,
                project_id,
                pipeline_run_id,
                stage,
                event_type,
                actor,
                duration_seconds,
                json.dumps(metadata) if metadata else None,
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        conn.commit()

        _log_audit(conn, project_id, "vsm_stage_recorded",
                   f"Stage {stage} {event_type} for pipeline {pipeline_run_id}",
                   {"event_id": event_id, "stage": stage,
                    "event_type": event_type, "pipeline_run_id": pipeline_run_id})

        return {
            "id": event_id,
            "stage": stage,
            "event_type": event_type,
            "recorded": True,
        }
    finally:
        conn.close()


def compute_dora_metrics(project_id: str, days: int = 30, db_path=None) -> dict:
    """Compute DORA metrics from vsm_stage_events and audit_trail.

    Metrics:
        - deployment_frequency: deploys per day in the period.
        - lead_time_hours: avg time from first stage start to last stage
          complete per pipeline run.
        - change_failure_rate: pct of pipeline runs with at least one
          'failed' event.
        - mttr_hours: avg time from a 'failed' event to the next
          'completed' event within the same pipeline run.

    Args:
        project_id: Project identifier.
        days: Look-back period in days (default 30).
        db_path: Optional database path override.

    Returns:
        dict with DORA metrics and snapshot_id.
    """
    conn = _get_connection(db_path)
    try:
        _ensure_tables(conn)

        cutoff_dt = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

        # -- All events in period ------------------------------------------------
        rows = conn.execute(
            "SELECT pipeline_run_id, stage, event_type, duration_seconds, created_at "
            "FROM vsm_stage_events "
            "WHERE project_id = ? AND created_at >= ? "
            "ORDER BY created_at ASC",
            (project_id, cutoff_dt),
        ).fetchall()

        # Group by pipeline run
        pipelines: Dict[str, List[dict]] = {}
        for r in rows:
            pid = r["pipeline_run_id"]
            pipelines.setdefault(pid, []).append({
                "stage": r["stage"],
                "event_type": r["event_type"],
                "duration_seconds": r["duration_seconds"],
                "created_at": r["created_at"],
            })

        total_pipelines = len(pipelines)

        # -- Deployment frequency ------------------------------------------------
        # Count pipelines where stress_test completed (= successful deploy)
        deploy_count = 0
        for events in pipelines.values():
            for e in events:
                if e["stage"] == "stress_test" and e["event_type"] == "completed":
                    deploy_count += 1
                    break
        deployment_frequency = deploy_count / max(days, 1)

        # -- Lead time -----------------------------------------------------------
        lead_times: List[float] = []
        for events in pipelines.values():
            timestamps = [e["created_at"] for e in events if e["created_at"]]
            if len(timestamps) >= 2:
                try:
                    first = datetime.fromisoformat(timestamps[0])
                    last = datetime.fromisoformat(timestamps[-1])
                    diff_hours = (last - first).total_seconds() / 3600.0
                    if diff_hours >= 0:
                        lead_times.append(diff_hours)
                except (ValueError, TypeError):
                    pass
        lead_time_hours = (sum(lead_times) / len(lead_times)) if lead_times else 0.0

        # -- Change failure rate -------------------------------------------------
        failed_pipelines = 0
        for events in pipelines.values():
            for e in events:
                if e["event_type"] == "failed":
                    failed_pipelines += 1
                    break
        change_failure_rate = (
            (failed_pipelines / total_pipelines * 100.0) if total_pipelines else 0.0
        )

        # -- MTTR ----------------------------------------------------------------
        recovery_times: List[float] = []
        for events in pipelines.values():
            last_failure_time = None
            for e in events:
                if e["event_type"] == "failed" and e["created_at"]:
                    try:
                        last_failure_time = datetime.fromisoformat(e["created_at"])
                    except (ValueError, TypeError):
                        pass
                elif e["event_type"] == "completed" and last_failure_time and e["created_at"]:
                    try:
                        completed_time = datetime.fromisoformat(e["created_at"])
                        diff = (completed_time - last_failure_time).total_seconds() / 3600.0
                        if diff >= 0:
                            recovery_times.append(diff)
                        last_failure_time = None
                    except (ValueError, TypeError):
                        pass
        mttr_hours = (sum(recovery_times) / len(recovery_times)) if recovery_times else 0.0

        # -- Store snapshot ------------------------------------------------------
        snapshot_id = _uid()
        conn.execute(
            "INSERT INTO vsm_dora_snapshots "
            "(id, project_id, period_days, deployment_frequency, lead_time_hours, "
            "change_failure_rate, mttr_hours, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                snapshot_id,
                project_id,
                days,
                round(deployment_frequency, 4),
                round(lead_time_hours, 2),
                round(change_failure_rate, 2),
                round(mttr_hours, 2),
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        conn.commit()

        _log_audit(conn, project_id, "vsm_dora_computed",
                   f"DORA metrics computed for {days}-day window",
                   {"snapshot_id": snapshot_id,
                    "deployment_frequency": round(deployment_frequency, 4),
                    "lead_time_hours": round(lead_time_hours, 2),
                    "change_failure_rate": round(change_failure_rate, 2),
                    "mttr_hours": round(mttr_hours, 2)})

        return {
            "project_id": project_id,
            "period_days": days,
            "deployment_frequency": round(deployment_frequency, 4),
            "lead_time_hours": round(lead_time_hours, 2),
            "change_failure_rate": round(change_failure_rate, 2),
            "mttr_hours": round(mttr_hours, 2),
            "snapshot_id": snapshot_id,
        }
    finally:
        conn.close()


def detect_bottlenecks(project_id: str, days: int = 30, db_path=None) -> dict:
    """Detect ATLAS pipeline bottlenecks via p90 duration analysis.

    A stage is a bottleneck when its p90 duration exceeds 2x the median
    of all stages' p90 durations.

    Args:
        project_id: Project identifier.
        days: Look-back period in days (default 30).
        db_path: Optional database path override.

    Returns:
        dict with per-stage p50/p90 and bottleneck flags.
    """
    conn = _get_connection(db_path)
    try:
        _ensure_tables(conn)

        cutoff_dt = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

        rows = conn.execute(
            "SELECT stage, duration_seconds "
            "FROM vsm_stage_events "
            "WHERE project_id = ? AND created_at >= ? "
            "AND duration_seconds IS NOT NULL AND event_type = 'completed' "
            "ORDER BY stage, duration_seconds",
            (project_id, cutoff_dt),
        ).fetchall()

        # Group durations by stage
        stage_durations: Dict[str, List[float]] = {s: [] for s in VALID_STAGES}
        for r in rows:
            stage = r["stage"]
            if stage in stage_durations:
                stage_durations[stage].append(float(r["duration_seconds"]))

        # Compute p50 and p90 per stage
        stages_result: List[dict] = []
        p90_values: List[float] = []
        for stage in VALID_STAGES:
            durations = sorted(stage_durations[stage])
            p50 = round(_percentile(durations, 50), 2) if durations else 0.0
            p90 = round(_percentile(durations, 90), 2) if durations else 0.0
            stages_result.append({
                "stage": stage,
                "p50_seconds": p50,
                "p90_seconds": p90,
                "is_bottleneck": False,  # will be updated below
            })
            if p90 > 0:
                p90_values.append(p90)

        # Determine bottleneck threshold: 2 * median of all p90s
        if p90_values:
            sorted_p90 = sorted(p90_values)
            median_p90 = _percentile(sorted_p90, 50)
            threshold = 2.0 * median_p90
            bottleneck_stages = []
            for entry in stages_result:
                if entry["p90_seconds"] > threshold:
                    entry["is_bottleneck"] = True
                    bottleneck_stages.append(entry["stage"])
        else:
            bottleneck_stages = []

        if bottleneck_stages:
            _log_audit(conn, project_id, "vsm_bottleneck_detected",
                       f"Bottleneck stages detected: {', '.join(bottleneck_stages)}",
                       {"bottleneck_stages": bottleneck_stages, "days": days})

        return {
            "project_id": project_id,
            "stages": stages_result,
            "bottleneck_stages": bottleneck_stages,
        }
    finally:
        conn.close()


def get_pipeline_flow(project_id: str, limit: int = 20, db_path=None) -> dict:
    """List recent pipeline runs with stage timing.

    Args:
        project_id: Project identifier.
        limit: Maximum number of pipeline runs to return (default 20).
        db_path: Optional database path override.

    Returns:
        dict with pipeline run details and stage timings.
    """
    conn = _get_connection(db_path)
    try:
        _ensure_tables(conn)

        # Get distinct recent pipeline runs
        run_rows = conn.execute(
            "SELECT DISTINCT pipeline_run_id, MIN(created_at) AS first_event "
            "FROM vsm_stage_events "
            "WHERE project_id = ? "
            "GROUP BY pipeline_run_id "
            "ORDER BY first_event DESC "
            "LIMIT ?",
            (project_id, limit),
        ).fetchall()

        pipelines: List[dict] = []
        for run_row in run_rows:
            run_id = run_row["pipeline_run_id"]
            events = conn.execute(
                "SELECT stage, event_type, duration_seconds, created_at "
                "FROM vsm_stage_events "
                "WHERE project_id = ? AND pipeline_run_id = ? "
                "ORDER BY created_at ASC",
                (project_id, run_id),
            ).fetchall()

            stages = []
            total_duration = 0.0
            has_failure = False
            has_completion = False
            for e in events:
                dur = float(e["duration_seconds"]) if e["duration_seconds"] is not None else 0.0
                stages.append({
                    "stage": e["stage"],
                    "event_type": e["event_type"],
                    "duration_seconds": dur,
                    "created_at": e["created_at"],
                })
                total_duration += dur
                if e["event_type"] == "failed":
                    has_failure = True
                if e["event_type"] == "completed" and e["stage"] == "stress_test":
                    has_completion = True

            if has_failure:
                status = "failed"
            elif has_completion:
                status = "completed"
            else:
                status = "in_progress"

            pipelines.append({
                "pipeline_run_id": run_id,
                "stages": stages,
                "total_duration_seconds": round(total_duration, 2),
                "status": status,
            })

        return {
            "project_id": project_id,
            "pipelines": pipelines,
            "count": len(pipelines),
        }
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="VSM (Value Stream Mapping) Dashboard Engine"
    )
    parser.add_argument("--project-id", required=True, help="Project identifier")
    parser.add_argument("--json", action="store_true", help="Output as JSON")

    # Record event
    parser.add_argument("--record-event", action="store_true",
                        help="Record a pipeline stage event")
    parser.add_argument("--stage", choices=VALID_STAGES, help="Pipeline stage")
    parser.add_argument("--event-type", choices=VALID_EVENT_TYPES,
                        help="Event type")
    parser.add_argument("--pipeline-run-id", help="Pipeline run identifier")
    parser.add_argument("--actor", help="Actor/agent name")
    parser.add_argument("--duration", type=float,
                        help="Stage duration in seconds")

    # DORA metrics
    parser.add_argument("--dora", action="store_true",
                        help="Compute DORA metrics")
    parser.add_argument("--days", type=int, default=30,
                        help="Look-back period in days (default 30)")

    # Bottlenecks
    parser.add_argument("--bottlenecks", action="store_true",
                        help="Detect pipeline bottlenecks")

    # Pipeline flow
    parser.add_argument("--pipelines", action="store_true",
                        help="List recent pipeline runs")
    parser.add_argument("--limit", type=int, default=20,
                        help="Max pipeline runs to return (default 20)")

    args = parser.parse_args()

    try:
        if args.record_event:
            if not args.stage:
                parser.error("--stage is required with --record-event")
            if not args.event_type:
                parser.error("--event-type is required with --record-event")
            if not args.pipeline_run_id:
                parser.error("--pipeline-run-id is required with --record-event")
            result = record_stage_event(
                project_id=args.project_id,
                pipeline_run_id=args.pipeline_run_id,
                stage=args.stage,
                event_type=args.event_type,
                actor=args.actor,
                duration_seconds=args.duration,
            )
        elif args.dora:
            result = compute_dora_metrics(
                project_id=args.project_id,
                days=args.days,
            )
        elif args.bottlenecks:
            result = detect_bottlenecks(
                project_id=args.project_id,
                days=args.days,
            )
        elif args.pipelines:
            result = get_pipeline_flow(
                project_id=args.project_id,
                limit=args.limit,
            )
        else:
            parser.print_help()
            sys.exit(1)

        if args.json:
            print(json.dumps(result, indent=2, default=str))
        else:
            for key, value in result.items():
                print(f"{key}: {value}")

    except Exception as exc:
        err = {"error": str(exc)}
        if args.json:
            print(json.dumps(err, indent=2))
        else:
            print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
