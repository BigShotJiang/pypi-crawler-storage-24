# CUI // SP-CTI
"""Runtime policy generator — PSA and Kyverno policies for container security."""

import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


def generate_psa_labels(namespace: str = "default",
                        level: str = "restricted") -> Dict[str, str]:
    """Generate Pod Security Admission labels for a namespace."""
    return {
        f"pod-security.kubernetes.io/enforce": level,
        f"pod-security.kubernetes.io/audit": level,
        f"pod-security.kubernetes.io/warn": level,
    }


def generate_network_policy(namespace: str = "default",
                            app_label: str = "cloudforge") -> Dict[str, Any]:
    """Generate a default-deny NetworkPolicy."""
    return {
        "apiVersion": "networking.k8s.io/v1",
        "kind": "NetworkPolicy",
        "metadata": {
            "name": f"{app_label}-default-deny",
            "namespace": namespace,
        },
        "spec": {
            "podSelector": {},
            "policyTypes": ["Ingress", "Egress"],
        },
    }


def generate_kyverno_require_nonroot() -> Dict[str, Any]:
    """Generate a Kyverno policy requiring non-root containers."""
    return {
        "apiVersion": "kyverno.io/v1",
        "kind": "ClusterPolicy",
        "metadata": {
            "name": "require-run-as-non-root",
            "annotations": {
                "policies.kyverno.io/title": "Require Non-Root",
                "policies.kyverno.io/category": "Pod Security Standards",
                "managed-by": "cloudforge",
            },
        },
        "spec": {
            "validationFailureAction": "Enforce",
            "background": True,
            "rules": [{
                "name": "run-as-non-root",
                "match": {"any": [{"resources": {"kinds": ["Pod"]}}]},
                "validate": {
                    "message": "Containers must run as non-root.",
                    "pattern": {
                        "spec": {
                            "securityContext": {"runAsNonRoot": True},
                        },
                    },
                },
            }],
        },
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Runtime Policy Generator")
    parser.add_argument("--psa", action="store_true")
    parser.add_argument("--netpol", action="store_true")
    parser.add_argument("--kyverno", action="store_true")
    parser.add_argument("--namespace", default="default")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.psa:
        print(json.dumps(generate_psa_labels(args.namespace), indent=2))
    elif args.netpol:
        print(json.dumps(generate_network_policy(args.namespace), indent=2))
    elif args.kyverno:
        print(json.dumps(generate_kyverno_require_nonroot(), indent=2))
    else:
        parser.print_help()
