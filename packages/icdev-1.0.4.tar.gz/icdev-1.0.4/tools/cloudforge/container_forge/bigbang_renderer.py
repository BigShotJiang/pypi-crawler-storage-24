# CUI // SP-CTI
"""Big Bang Helm values renderer — generates values.yaml for DoD Big Bang.

Big Bang is the DoD's standard Kubernetes platform built on Iron Bank images.
This module generates Helm values for a landing zone's K8s cluster.
"""

import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)

try:
    import yaml
except ImportError:
    yaml = None


def render_bigbang_values(
    zone_id: str,
    domain: str = "bigbang.dev",
    istio_enabled: bool = True,
    monitoring_enabled: bool = True,
    logging_enabled: bool = True,
    twistlock_enabled: bool = True,
) -> Dict[str, Any]:
    """Render Big Bang Helm values for a landing zone."""
    values = {
        "domain": domain,
        "istio": {
            "enabled": istio_enabled,
            "values": {
                "global": {
                    "proxy": {"resources": {"requests": {"cpu": "100m", "memory": "256Mi"}}},
                },
            },
        },
        "monitoring": {
            "enabled": monitoring_enabled,
            "values": {
                "prometheus": {"prometheusSpec": {"retention": "30d"}},
            },
        },
        "loki": {
            "enabled": logging_enabled,
        },
        "twistlock": {
            "enabled": twistlock_enabled,
        },
        "networkPolicies": {
            "enabled": True,
        },
        "addons": {
            "argocd": {"enabled": True},
        },
    }

    yaml_content = ""
    if yaml:
        yaml_content = yaml.dump(values, default_flow_style=False, sort_keys=False)
    else:
        yaml_content = json.dumps(values, indent=2)

    return {
        "status": "ok",
        "zone_id": zone_id,
        "values": values,
        "yaml_content": yaml_content,
        "classification": "CUI // SP-CTI",
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Big Bang Renderer")
    parser.add_argument("--zone-id", default="lz-001")
    parser.add_argument("--domain", default="bigbang.dev")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    result = render_bigbang_values(args.zone_id, args.domain)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(result["yaml_content"])
