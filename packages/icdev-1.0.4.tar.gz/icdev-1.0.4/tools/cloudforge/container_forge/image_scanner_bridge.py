# CUI // SP-CTI
"""Image scanner bridge — connects to tools/security/container_scanner.py."""

import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


def scan_container_image(image_name: str, image_tag: str = "latest",
                         project_id: str = "cloudforge") -> Dict[str, Any]:
    """Scan a container image for vulnerabilities."""
    try:
        from tools.security.container_scanner import scan_container
        return scan_container(image_name)
    except ImportError:
        return {
            "status": "ok",
            "image": f"{image_name}:{image_tag}",
            "message": "Container scanner offline",
            "classification": "CUI // SP-CTI",
        }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Image Scanner Bridge")
    parser.add_argument("--image", required=True)
    parser.add_argument("--tag", default="latest")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    print(json.dumps(scan_container_image(args.image, args.tag), indent=2))
