# CUI // SP-CTI
"""CloudForge Provider Registry (D-CF-2).

Uses the same @register_provider decorator + lazy loading pattern
as DataBridge connector registry (tools/databridge/registry.py).
"""

import argparse
import importlib
import json
import logging
from typing import Any, Dict, List, Optional, Type

from tools.cloudforge.provider import CloudProvider

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# In-memory registry
# ---------------------------------------------------------------------------

_PROVIDER_CLASSES: Dict[str, Type[CloudProvider]] = {}


def register_provider(cls: Type[CloudProvider]) -> Type[CloudProvider]:
    """Decorator to register a cloud provider class."""
    try:
        name = cls.__dict__.get("_provider_name") or cls.__name__.lower()
    except Exception:
        name = cls.__name__.lower()
    _PROVIDER_CLASSES[name] = cls
    logger.debug("Registered provider: %s", name)
    return cls


# ---------------------------------------------------------------------------
# Lazy loading (D-CF-2: same pattern as DataBridge D-DB-18)
# ---------------------------------------------------------------------------

_BUILTIN_MODULES = [
    "tools.cloudforge.providers.aws_commercial",
    "tools.cloudforge.providers.aws_govcloud",
    "tools.cloudforge.providers.aws_secret",
    "tools.cloudforge.providers.azure_commercial",
    "tools.cloudforge.providers.azure_gov",
    "tools.cloudforge.providers.azure_secret",
    "tools.cloudforge.providers.gcp",
    "tools.cloudforge.providers.oci",
]

_loaded = False


def _load_builtin_providers() -> None:
    """Import each built-in provider module.

    Missing dependencies are silently skipped (air-gap safe).
    """
    global _loaded
    if _loaded:
        return
    for mod_path in _BUILTIN_MODULES:
        try:
            importlib.import_module(mod_path)
        except (ImportError, ModuleNotFoundError):
            logger.debug("Skipped %s (missing dependency)", mod_path)
        except Exception as exc:
            logger.warning("Failed to load %s: %s", mod_path, exc)
    _loaded = True


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_provider_class(name: str) -> Optional[Type[CloudProvider]]:
    """Get a provider class by name."""
    if not _PROVIDER_CLASSES:
        _load_builtin_providers()
    return _PROVIDER_CLASSES.get(name)


def get_provider_instance(name: str, **kwargs: Any) -> Optional[CloudProvider]:
    """Get an instantiated provider by name."""
    cls = get_provider_class(name)
    if cls:
        return cls(**kwargs)
    return None


def list_registered_providers() -> List[Dict[str, Any]]:
    """List all registered providers with metadata."""
    if not _PROVIDER_CLASSES:
        _load_builtin_providers()
    result = []
    for name, cls in sorted(_PROVIDER_CLASSES.items()):
        try:
            inst = cls()
            caps = inst.capabilities
            result.append({
                "name": name,
                "cloud_name": inst.cloud_name,
                "cloud_type": inst.cloud_type.value,
                "supported_il_levels": caps.supported_il_levels,
                "supports_govcloud": caps.supports_govcloud,
                "supports_k8s": caps.supports_k8s,
                "iac_engines": caps.iac_engines,
                "supported_regions": caps.supported_regions,
            })
        except Exception as exc:
            result.append({"name": name, "error": str(exc)})
    return result


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="CloudForge Provider Registry")
    parser.add_argument("--list", action="store_true", help="List registered providers")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    if args.list:
        providers = list_registered_providers()
        if args.json:
            print(json.dumps(providers, indent=2))
        else:
            for p in providers:
                if "error" in p:
                    print(f"  {p['name']}: ERROR — {p['error']}")
                else:
                    il = ", ".join(p["supported_il_levels"])
                    print(f"  {p['cloud_name']} ({p['name']}): IL=[{il}] "
                          f"GovCloud={p['supports_govcloud']} K8s={p['supports_k8s']}")


if __name__ == "__main__":
    main()
