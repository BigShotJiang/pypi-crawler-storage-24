# CUI // SP-CTI
"""Control inheritor — map CSP shared responsibility controls to landing zones.

Each CSP inherits a set of NIST 800-53 controls at the infrastructure layer.
This module resolves which controls are inherited vs. customer-responsible
based on the cloud_type and impact_level.
"""

import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Shared responsibility controls inherited from CSP (infrastructure layer)
_CSP_INHERITED: Dict[str, Dict[str, List[str]]] = {
    "aws_commercial": {
        "IL2": ["PE-1", "PE-2", "PE-3", "PE-6", "PE-8", "SC-7"],
    },
    "aws_govcloud": {
        "IL2": ["PE-1", "PE-2", "PE-3", "PE-6", "PE-8", "SC-7", "SC-8"],
        "IL4": ["PE-1", "PE-2", "PE-3", "PE-6", "PE-8", "SC-7", "SC-8", "SC-12",
                "SC-13", "SC-28", "AU-2", "AU-3", "IA-2", "IA-5"],
        "IL5": ["PE-1", "PE-2", "PE-3", "PE-6", "PE-8", "SC-7", "SC-8", "SC-12",
                "SC-13", "SC-28", "AU-2", "AU-3", "IA-2", "IA-5", "CP-6", "CP-7"],
    },
    "aws_secret": {
        "IL6": ["PE-1", "PE-2", "PE-3", "PE-6", "PE-8", "SC-7", "SC-8", "SC-12",
                "SC-13", "SC-28", "AU-2", "AU-3", "IA-2", "IA-5", "CP-6", "CP-7",
                "AC-17", "MA-4"],
    },
    "azure_commercial": {
        "IL2": ["PE-1", "PE-2", "PE-3", "PE-6", "SC-7"],
    },
    "azure_gov": {
        "IL2": ["PE-1", "PE-2", "PE-3", "PE-6", "SC-7", "SC-8"],
        "IL4": ["PE-1", "PE-2", "PE-3", "PE-6", "SC-7", "SC-8", "SC-12",
                "SC-13", "SC-28", "AU-2", "AU-3", "IA-2", "IA-5"],
        "IL5": ["PE-1", "PE-2", "PE-3", "PE-6", "SC-7", "SC-8", "SC-12",
                "SC-13", "SC-28", "AU-2", "AU-3", "IA-2", "IA-5", "CP-6", "CP-7",
                "AC-17"],
    },
    "azure_secret": {
        "IL5": ["PE-1", "PE-2", "PE-3", "PE-6", "SC-7", "SC-8", "SC-12",
                "SC-13", "SC-28", "AU-2", "AU-3", "CP-6", "CP-7"],
        "IL6": ["PE-1", "PE-2", "PE-3", "PE-6", "SC-7", "SC-8", "SC-12",
                "SC-13", "SC-28", "AU-2", "AU-3", "CP-6", "CP-7", "AC-17", "MA-4"],
    },
    "gcp": {
        "IL2": ["PE-1", "PE-2", "PE-3", "SC-7", "SC-8", "SC-12", "AU-2", "AU-3"],
        "IL4": ["PE-1", "PE-2", "PE-3", "SC-7", "SC-8", "SC-12", "AU-2", "AU-3",
                "SC-13", "SC-28", "IA-2"],
        "IL5": ["PE-1", "PE-2", "PE-3", "SC-7", "SC-8", "SC-12", "AU-2", "AU-3",
                "SC-13", "SC-28", "IA-2", "IA-5", "CP-6"],
    },
    "oci": {
        "IL2": ["PE-1", "PE-2", "PE-3", "SC-7", "SC-8", "SC-12", "AU-2", "AU-3"],
        "IL4": ["PE-1", "PE-2", "PE-3", "SC-7", "SC-8", "SC-12", "AU-2", "AU-3",
                "SC-13", "SC-28"],
        "IL5": ["PE-1", "PE-2", "PE-3", "SC-7", "SC-8", "SC-12", "AU-2", "AU-3",
                "SC-13", "SC-28", "IA-2", "CP-6"],
    },
}


def get_inherited_controls(cloud_type: str, impact_level: str) -> List[str]:
    """Return the list of NIST 800-53 controls inherited from the CSP."""
    csp_controls = _CSP_INHERITED.get(cloud_type, {})
    return csp_controls.get(impact_level, [])


def get_customer_responsible_controls(cloud_type: str, impact_level: str,
                                      total_controls: int = 325) -> Dict[str, Any]:
    """Calculate how many controls are inherited vs customer-responsible."""
    inherited = get_inherited_controls(cloud_type, impact_level)
    return {
        "cloud_type": cloud_type,
        "impact_level": impact_level,
        "inherited_count": len(inherited),
        "inherited_controls": inherited,
        "customer_responsible_count": total_controls - len(inherited),
        "total_controls": total_controls,
        "inheritance_pct": round(len(inherited) / total_controls * 100, 1) if total_controls else 0,
    }


def compare_csp_inheritance(impact_level: str) -> List[Dict[str, Any]]:
    """Compare control inheritance across all CSPs for a given IL."""
    results = []
    for cloud_type in _CSP_INHERITED:
        controls = get_inherited_controls(cloud_type, impact_level)
        if controls:
            results.append({
                "cloud_type": cloud_type,
                "impact_level": impact_level,
                "inherited_count": len(controls),
                "controls": controls,
            })
    results.sort(key=lambda x: x["inherited_count"], reverse=True)
    return results


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CloudForge Control Inheritor")
    parser.add_argument("--cloud-type", help="CSP cloud type")
    parser.add_argument("--impact-level", default="IL4")
    parser.add_argument("--compare", action="store_true", help="Compare all CSPs")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.compare:
        results = compare_csp_inheritance(args.impact_level)
        if args.json:
            print(json.dumps(results, indent=2))
        else:
            for r in results:
                print(f"  {r['cloud_type']:20s} {r['inherited_count']} controls")
    elif args.cloud_type:
        result = get_customer_responsible_controls(args.cloud_type, args.impact_level)
        print(json.dumps(result, indent=2))
    else:
        parser.print_help()
