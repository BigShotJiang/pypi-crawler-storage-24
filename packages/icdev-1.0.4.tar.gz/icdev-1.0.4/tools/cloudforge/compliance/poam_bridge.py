# CUI // SP-CTI
"""POAM Bridge — connects CloudForge to tools/compliance/poam_generator.py."""

import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


def generate_poam_for_zone(zone_id: str, project_id: str = "cloudforge") -> Dict[str, Any]:
    """Generate a POAM enriched with CloudForge landing zone data."""
    from tools.cloudforge.landing_zone.zone_provisioner import get_zone

    zone = get_zone(zone_id)
    if not zone:
        return {"status": "error", "message": f"Zone {zone_id} not found"}

    try:
        from tools.compliance.poam_generator import generate_poam
        poam_result = generate_poam(project_id)
    except ImportError:
        poam_result = {"status": "ok", "message": "POAM generator not available (offline mode)"}

    return {
        "status": "ok",
        "zone_id": zone_id,
        "cloud_type": zone["cloud_type"],
        "impact_level": zone["impact_level"],
        "poam_result": poam_result,
        "classification": "CUI // SP-CTI",
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge POAM Bridge")
    parser.add_argument("--zone-id", required=True)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    print(json.dumps(generate_poam_for_zone(args.zone_id), indent=2))
