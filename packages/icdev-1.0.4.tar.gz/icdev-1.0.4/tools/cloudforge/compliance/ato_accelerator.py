# CUI // SP-CTI
"""18-day ATO accelerator — 5-phase gate orchestrator (D-CF-14).

Manages the ATO pipeline: Boundary Definition → Control Implementation →
Security Scanning → Evidence Collection → Assessment & Authorization.
Each phase has automated gates that must pass before advancing.
"""

import json
import logging
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"

ATO_PHASES = [
    {
        "number": 1,
        "name": "Boundary Definition",
        "target_days": 2,
        "gates": ["system_boundary_defined", "data_flow_mapped", "ports_protocols_documented"],
    },
    {
        "number": 2,
        "name": "Control Implementation",
        "target_days": 5,
        "gates": ["inherited_controls_mapped", "implemented_controls_documented", "crosswalk_complete"],
    },
    {
        "number": 3,
        "name": "Security Scanning",
        "target_days": 4,
        "gates": ["sast_passed", "container_scan_passed", "stig_checked", "secret_scan_clean"],
    },
    {
        "number": 4,
        "name": "Evidence Collection",
        "target_days": 3,
        "gates": ["ssp_generated", "poam_generated", "sbom_generated", "test_results_attached"],
    },
    {
        "number": 5,
        "name": "Assessment & Authorization",
        "target_days": 4,
        "gates": ["assessor_review_complete", "risk_accepted", "ato_letter_signed"],
    },
]


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def initialize_ato(zone_id: str) -> Dict[str, Any]:
    """Initialize all 5 ATO phases for a landing zone."""
    conn = _get_db()
    phases_created = []
    try:
        for phase in ATO_PHASES:
            phase_id = f"ato-{zone_id}-p{phase['number']}"
            conn.execute(
                """INSERT OR IGNORE INTO cf_ato_phases
                   (id, zone_id, phase_number, phase_name, status, classification)
                   VALUES (?, ?, ?, ?, 'pending', 'CUI // SP-CTI')""",
                (phase_id, zone_id, phase["number"], phase["name"]),
            )
            phases_created.append({
                "id": phase_id,
                "phase_number": phase["number"],
                "name": phase["name"],
                "target_days": phase["target_days"],
                "gates": phase["gates"],
                "status": "pending",
            })
        conn.commit()
    finally:
        conn.close()

    return {
        "status": "ok",
        "zone_id": zone_id,
        "phases": phases_created,
        "total_target_days": sum(p["target_days"] for p in ATO_PHASES),
    }


def start_phase(zone_id: str, phase_number: int) -> Dict[str, Any]:
    """Start an ATO phase."""
    phase_id = f"ato-{zone_id}-p{phase_number}"
    conn = _get_db()
    try:
        conn.execute(
            """UPDATE cf_ato_phases
               SET status = 'in_progress', started_at = datetime('now')
               WHERE id = ? AND status = 'pending'""",
            (phase_id,),
        )
        conn.commit()
        return {"status": "ok", "phase_id": phase_id, "phase_number": phase_number}
    finally:
        conn.close()


def evaluate_gates(zone_id: str, phase_number: int,
                   gate_results: Optional[Dict[str, bool]] = None) -> Dict[str, Any]:
    """Evaluate gate conditions for a phase.

    In a real deployment, this would call the actual security/compliance tools.
    Here it accepts explicit gate results or simulates passing.
    """
    phase_def = next((p for p in ATO_PHASES if p["number"] == phase_number), None)
    if not phase_def:
        return {"status": "error", "message": f"Invalid phase number: {phase_number}"}

    # Default: all gates pass (caller can override)
    results = {gate: True for gate in phase_def["gates"]}
    if gate_results:
        results.update(gate_results)

    all_passed = all(results.values())
    phase_id = f"ato-{zone_id}-p{phase_number}"

    conn = _get_db()
    try:
        new_status = "passed" if all_passed else "failed"
        conn.execute(
            """UPDATE cf_ato_phases
               SET status = ?, gate_results_json = ?,
                   completed_at = CASE WHEN ? = 'passed' THEN datetime('now') ELSE completed_at END
               WHERE id = ?""",
            (new_status, json.dumps(results), new_status, phase_id),
        )
        conn.commit()
    finally:
        conn.close()

    return {
        "status": "ok",
        "phase_id": phase_id,
        "phase_number": phase_number,
        "phase_name": phase_def["name"],
        "all_gates_passed": all_passed,
        "gate_results": results,
        "phase_status": "passed" if all_passed else "failed",
    }


def get_ato_status(zone_id: str) -> Dict[str, Any]:
    """Get the full ATO pipeline status for a zone."""
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT phase_number, phase_name, status, started_at, completed_at,
                      gate_results_json
               FROM cf_ato_phases WHERE zone_id = ?
               ORDER BY phase_number""",
            (zone_id,),
        ).fetchall()

        if not rows:
            return {"status": "not_initialized", "zone_id": zone_id}

        phases = []
        for r in rows:
            phases.append({
                "phase_number": r["phase_number"],
                "name": r["phase_name"],
                "status": r["status"],
                "started_at": r["started_at"],
                "completed_at": r["completed_at"],
                "gate_results": json.loads(r["gate_results_json"]) if r["gate_results_json"] else {},
            })

        completed = sum(1 for p in phases if p["status"] == "passed")
        current = next((p for p in phases if p["status"] == "in_progress"), None)

        return {
            "status": "ok",
            "zone_id": zone_id,
            "phases": phases,
            "completed_phases": completed,
            "total_phases": len(phases),
            "current_phase": current["phase_number"] if current else None,
            "ato_complete": completed == len(phases),
        }
    finally:
        conn.close()


def advance_ato(zone_id: str, gate_results: Optional[Dict[str, bool]] = None) -> Dict[str, Any]:
    """Auto-advance the ATO pipeline: evaluate current phase, start next if passed."""
    status = get_ato_status(zone_id)
    if status.get("status") == "not_initialized":
        initialize_ato(zone_id)
        status = get_ato_status(zone_id)

    if status.get("ato_complete"):
        return {"status": "ok", "message": "ATO already complete", "zone_id": zone_id}

    # Find current or next pending phase
    current_phase = status.get("current_phase")
    if current_phase:
        result = evaluate_gates(zone_id, current_phase, gate_results)
        if result.get("all_gates_passed"):
            # Start next phase if available
            next_phase = current_phase + 1
            if next_phase <= 5:
                start_phase(zone_id, next_phase)
                return {
                    "status": "ok",
                    "message": f"Phase {current_phase} passed, started phase {next_phase}",
                    "zone_id": zone_id,
                    "completed_phase": current_phase,
                    "started_phase": next_phase,
                }
            else:
                return {
                    "status": "ok",
                    "message": "All 5 phases passed — ATO complete!",
                    "zone_id": zone_id,
                    "ato_complete": True,
                }
        else:
            return {
                "status": "blocked",
                "message": f"Phase {current_phase} has failing gates",
                "zone_id": zone_id,
                "gate_results": result.get("gate_results"),
            }
    else:
        # Start phase 1
        start_phase(zone_id, 1)
        return {
            "status": "ok",
            "message": "Started ATO phase 1: Boundary Definition",
            "zone_id": zone_id,
            "started_phase": 1,
        }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CloudForge ATO Accelerator")
    parser.add_argument("--init", help="Initialize ATO for zone ID")
    parser.add_argument("--status", help="Get ATO status for zone ID")
    parser.add_argument("--advance", help="Advance ATO for zone ID")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.init:
        result = initialize_ato(args.init)
    elif args.status:
        result = get_ato_status(args.status)
    elif args.advance:
        result = advance_ato(args.advance)
    else:
        parser.print_help()
        exit(0)

    print(json.dumps(result, indent=2))
