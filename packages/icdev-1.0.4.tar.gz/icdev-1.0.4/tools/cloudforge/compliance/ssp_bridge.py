# CUI // SP-CTI
"""SSP Bridge — connects CloudForge to tools/compliance/ssp_generator.py.

Enriches SSP generation with landing zone context (CSP, region, controls).
"""

import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


def generate_ssp_for_zone(zone_id: str, project_id: str = "cloudforge") -> Dict[str, Any]:
    """Generate an SSP enriched with CloudForge landing zone data."""
    from tools.cloudforge.landing_zone.zone_provisioner import get_zone
    from tools.cloudforge.compliance.control_inheritor import get_inherited_controls

    zone = get_zone(zone_id)
    if not zone:
        return {"status": "error", "message": f"Zone {zone_id} not found"}

    inherited = get_inherited_controls(zone["cloud_type"], zone["impact_level"])

    # Call existing SSP generator
    try:
        from tools.compliance.ssp_generator import generate_ssp
        ssp_result = generate_ssp(project_id)
    except ImportError:
        ssp_result = {"status": "ok", "message": "SSP generator not available (offline mode)"}

    return {
        "status": "ok",
        "zone_id": zone_id,
        "cloud_type": zone["cloud_type"],
        "impact_level": zone["impact_level"],
        "region": zone["region"],
        "inherited_controls": inherited,
        "inherited_count": len(inherited),
        "ssp_result": ssp_result,
        "classification": "CUI // SP-CTI",
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge SSP Bridge")
    parser.add_argument("--zone-id", required=True)
    parser.add_argument("--project-id", default="cloudforge")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    print(json.dumps(generate_ssp_for_zone(args.zone_id, args.project_id), indent=2))
