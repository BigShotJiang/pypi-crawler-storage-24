# CUI // SP-CTI
"""STIG Bridge — connects CloudForge to tools/compliance/stig_checker.py."""

import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


def check_stigs_for_zone(zone_id: str, project_id: str = "cloudforge") -> Dict[str, Any]:
    """Run STIG checks enriched with CloudForge landing zone context."""
    from tools.cloudforge.landing_zone.zone_provisioner import get_zone

    zone = get_zone(zone_id)
    if not zone:
        return {"status": "error", "message": f"Zone {zone_id} not found"}

    try:
        from tools.compliance.stig_checker import check_stigs
        stig_result = check_stigs(project_id)
    except ImportError:
        stig_result = {"status": "ok", "message": "STIG checker not available (offline mode)"}

    return {
        "status": "ok",
        "zone_id": zone_id,
        "cloud_type": zone["cloud_type"],
        "impact_level": zone["impact_level"],
        "stig_result": stig_result,
        "classification": "CUI // SP-CTI",
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge STIG Bridge")
    parser.add_argument("--zone-id", required=True)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    print(json.dumps(check_stigs_for_zone(args.zone_id), indent=2))
