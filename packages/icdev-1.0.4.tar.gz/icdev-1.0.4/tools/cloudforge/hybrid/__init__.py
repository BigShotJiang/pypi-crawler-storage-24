# CUI // SP-CTI
"""CloudForge Hybrid Cloud Manager — topology, connections, workload abstraction."""
