# CUI // SP-CTI
"""Workload abstractor — cloud-agnostic definitions compiled to CSP-specific (D-CF-17)."""

import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)

# Cloud-agnostic → CSP-specific resource mapping
_RESOURCE_MAP: Dict[str, Dict[str, str]] = {
    "compute": {
        "aws_commercial": "aws_instance",
        "aws_govcloud": "aws_instance",
        "azure_commercial": "azurerm_virtual_machine",
        "azure_gov": "azurerm_virtual_machine",
        "gcp": "google_compute_instance",
        "oci": "oci_core_instance",
    },
    "container_cluster": {
        "aws_commercial": "aws_eks_cluster",
        "aws_govcloud": "aws_eks_cluster",
        "azure_commercial": "azurerm_kubernetes_cluster",
        "azure_gov": "azurerm_kubernetes_cluster",
        "gcp": "google_container_cluster",
        "oci": "oci_containerengine_cluster",
    },
    "object_storage": {
        "aws_commercial": "aws_s3_bucket",
        "aws_govcloud": "aws_s3_bucket",
        "azure_commercial": "azurerm_storage_account",
        "azure_gov": "azurerm_storage_account",
        "gcp": "google_storage_bucket",
        "oci": "oci_objectstorage_bucket",
    },
    "database": {
        "aws_commercial": "aws_db_instance",
        "aws_govcloud": "aws_db_instance",
        "azure_commercial": "azurerm_postgresql_server",
        "azure_gov": "azurerm_postgresql_server",
        "gcp": "google_sql_database_instance",
        "oci": "oci_database_db_system",
    },
    "load_balancer": {
        "aws_commercial": "aws_lb",
        "aws_govcloud": "aws_lb",
        "azure_commercial": "azurerm_lb",
        "azure_gov": "azurerm_lb",
        "gcp": "google_compute_forwarding_rule",
        "oci": "oci_load_balancer_load_balancer",
    },
}


def abstract_to_specific(
    resource_type: str,
    target_cloud: str,
    params: Dict[str, Any] = None,
) -> Dict[str, Any]:
    """Compile a cloud-agnostic resource to CSP-specific."""
    mapping = _RESOURCE_MAP.get(resource_type, {})
    specific = mapping.get(target_cloud, f"unknown_{resource_type}")

    return {
        "status": "ok",
        "abstract_type": resource_type,
        "target_cloud": target_cloud,
        "specific_resource": specific,
        "parameters": params or {},
        "classification": "CUI // SP-CTI",
    }


def get_supported_abstractions() -> Dict[str, list]:
    """List all supported abstract resource types and their CSP mappings."""
    return {k: list(v.keys()) for k, v in _RESOURCE_MAP.items()}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Workload Abstractor")
    parser.add_argument("--resolve", nargs=2, metavar=("TYPE", "CLOUD"))
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.resolve:
        print(json.dumps(abstract_to_specific(args.resolve[0], args.resolve[1]), indent=2))
    elif args.list:
        print(json.dumps(get_supported_abstractions(), indent=2))
    else:
        parser.print_help()
