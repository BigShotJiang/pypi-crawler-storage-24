# CUI // SP-CTI
"""Connection manager — persistent cross-cloud links (VPN, peering, interconnect)."""

import json
import logging
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"

CONNECTION_TYPES = [
    "vpn", "peering", "direct_connect", "expressroute",
    "interconnect", "transit_gateway", "relay",
]


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def create_connection(
    topology_id: str,
    source_zone_id: str,
    target_zone_id: str,
    connection_type: str = "vpn",
    bandwidth_mbps: int = 100,
    encrypted: bool = True,
    config: Dict[str, Any] = None,
) -> Dict[str, Any]:
    """Create a cross-cloud connection between two landing zones."""
    conn_id = f"conn-{uuid.uuid4().hex[:8]}"
    conn = _get_db()
    try:
        conn.execute(
            """INSERT INTO cf_hybrid_connections
               (id, topology_id, source_zone_id, target_zone_id,
                connection_type, status, bandwidth_mbps, encrypted,
                config_json, classification, created_at)
               VALUES (?, ?, ?, ?, ?, 'planned', ?, ?, ?, 'CUI // SP-CTI',
                       datetime('now'))""",
            (conn_id, topology_id, source_zone_id, target_zone_id,
             connection_type, bandwidth_mbps, 1 if encrypted else 0,
             json.dumps(config or {})),
        )
        conn.commit()
        return {
            "status": "ok",
            "connection_id": conn_id,
            "topology_id": topology_id,
            "source": source_zone_id,
            "target": target_zone_id,
            "type": connection_type,
        }
    finally:
        conn.close()


def establish_connection(connection_id: str) -> Dict[str, Any]:
    """Establish a planned connection (transitions planned → active)."""
    conn = _get_db()
    try:
        # Get connection details to delegate to provider
        row = conn.execute(
            """SELECT c.*, s.cloud_type as source_cloud, t.cloud_type as target_cloud
               FROM cf_hybrid_connections c
               LEFT JOIN cf_landing_zones s ON c.source_zone_id = s.id
               LEFT JOIN cf_landing_zones t ON c.target_zone_id = t.id
               WHERE c.id = ?""",
            (connection_id,),
        ).fetchone()

        if not row:
            return {"status": "error", "message": "Connection not found"}

        # In production: call provider.create_vpn / create_peering / create_direct_connect
        conn.execute(
            """UPDATE cf_hybrid_connections
               SET status = 'active', health_status = 'healthy'
               WHERE id = ?""",
            (connection_id,),
        )
        conn.commit()

        return {
            "status": "ok",
            "connection_id": connection_id,
            "state": "active",
            "type": row["connection_type"],
        }
    finally:
        conn.close()


def list_connections(topology_id: str = "") -> List[Dict[str, Any]]:
    """List connections, optionally filtered by topology."""
    conn = _get_db()
    try:
        if topology_id:
            rows = conn.execute(
                "SELECT * FROM cf_hybrid_connections WHERE topology_id = ?",
                (topology_id,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM cf_hybrid_connections").fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Connection Manager")
    parser.add_argument("--create", action="store_true")
    parser.add_argument("--establish", help="Connection ID")
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--topology-id", default="")
    parser.add_argument("--source", default="")
    parser.add_argument("--target", default="")
    parser.add_argument("--type", default="vpn", choices=CONNECTION_TYPES)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.create:
        result = create_connection(args.topology_id, args.source, args.target, args.type)
    elif args.establish:
        result = establish_connection(args.establish)
    elif args.list:
        result = list_connections(args.topology_id)
    else:
        parser.print_help()
        exit(0)
    print(json.dumps(result, indent=2, default=str))
