# CUI // SP-CTI
"""Network bridge — VPN/peering/interconnect config generation."""

import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


def generate_vpn_config(
    source_cloud: str,
    target_cloud: str,
    source_cidr: str = "10.0.0.0/16",
    target_cidr: str = "10.1.0.0/16",
) -> Dict[str, Any]:
    """Generate VPN configuration between two clouds."""
    return {
        "status": "ok",
        "connection_type": "vpn",
        "source_cloud": source_cloud,
        "target_cloud": target_cloud,
        "config": {
            "source_cidr": source_cidr,
            "target_cidr": target_cidr,
            "ike_version": "IKEv2",
            "encryption": "AES-256-GCM",
            "dh_group": 20,
            "lifetime_hours": 8,
            "dpd_interval": 10,
            "dpd_timeout": 30,
        },
        "classification": "CUI // SP-CTI",
    }


def generate_peering_config(
    source_cloud: str,
    target_cloud: str,
) -> Dict[str, Any]:
    """Generate peering configuration (same-CSP VPC/VNet peering)."""
    return {
        "status": "ok",
        "connection_type": "peering",
        "source_cloud": source_cloud,
        "target_cloud": target_cloud,
        "requires_same_csp": True,
        "same_csp": source_cloud.split("_")[0] == target_cloud.split("_")[0],
        "classification": "CUI // SP-CTI",
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Network Bridge")
    parser.add_argument("--vpn", action="store_true")
    parser.add_argument("--peering", action="store_true")
    parser.add_argument("--source", default="aws_govcloud")
    parser.add_argument("--target", default="azure_gov")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.vpn:
        print(json.dumps(generate_vpn_config(args.source, args.target), indent=2))
    elif args.peering:
        print(json.dumps(generate_peering_config(args.source, args.target), indent=2))
    else:
        parser.print_help()
