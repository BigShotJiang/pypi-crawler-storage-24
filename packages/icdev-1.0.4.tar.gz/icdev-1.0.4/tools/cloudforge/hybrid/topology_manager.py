# CUI // SP-CTI
"""Topology manager — hub-spoke, mesh, gateway topologies (D-CF-13).

Manages hybrid cloud topology as a graph (adjacency list in SQLite).
"""

import json
import logging
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def create_topology(
    name: str,
    topology_type: str = "hub_spoke",
    nodes: List[Dict[str, str]] = None,
    tenant_id: str = "default",
    project_id: str = "",
) -> Dict[str, Any]:
    """Create a new hybrid topology."""
    topo_id = f"topo-{uuid.uuid4().hex[:8]}"
    conn = _get_db()
    try:
        conn.execute(
            """INSERT INTO cf_hybrid_topology
               (id, name, topology_type, status, nodes_json, edges_json,
                classification, tenant_id, project_id,
                created_at, updated_at)
               VALUES (?, ?, ?, 'planned', ?, '[]', 'CUI // SP-CTI', ?, ?,
                       datetime('now'), datetime('now'))""",
            (topo_id, name, topology_type, json.dumps(nodes or []),
             tenant_id, project_id),
        )
        conn.commit()
        return {
            "status": "ok",
            "topology_id": topo_id,
            "name": name,
            "type": topology_type,
            "node_count": len(nodes or []),
        }
    finally:
        conn.close()


def add_node(topology_id: str, zone_id: str, role: str = "spoke") -> Dict[str, Any]:
    """Add a landing zone node to a topology."""
    conn = _get_db()
    try:
        row = conn.execute(
            "SELECT nodes_json FROM cf_hybrid_topology WHERE id = ?",
            (topology_id,),
        ).fetchone()
        if not row:
            return {"status": "error", "message": "Topology not found"}

        nodes = json.loads(row["nodes_json"] or "[]")
        nodes.append({"zone_id": zone_id, "role": role})
        conn.execute(
            "UPDATE cf_hybrid_topology SET nodes_json = ?, updated_at = datetime('now') WHERE id = ?",
            (json.dumps(nodes), topology_id),
        )
        conn.commit()
        return {"status": "ok", "topology_id": topology_id, "added_zone": zone_id, "role": role}
    finally:
        conn.close()


def get_topology(topology_id: str) -> Dict[str, Any]:
    """Get a topology with its nodes and connections."""
    conn = _get_db()
    try:
        topo = conn.execute(
            "SELECT * FROM cf_hybrid_topology WHERE id = ?", (topology_id,)
        ).fetchone()
        if not topo:
            return {"status": "error", "message": "Not found"}

        connections = conn.execute(
            """SELECT * FROM cf_hybrid_connections WHERE topology_id = ?
               ORDER BY created_at""",
            (topology_id,),
        ).fetchall()

        result = dict(topo)
        result["nodes"] = json.loads(result.get("nodes_json", "[]"))
        result["connections"] = [dict(c) for c in connections]
        return result
    finally:
        conn.close()


def list_topologies(tenant_id: str = "default") -> List[Dict[str, Any]]:
    """List all topologies for a tenant."""
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT id, name, topology_type, status, health_status, created_at
               FROM cf_hybrid_topology WHERE tenant_id = ?
               ORDER BY created_at DESC""",
            (tenant_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Topology Manager")
    parser.add_argument("--create", action="store_true")
    parser.add_argument("--get", help="Topology ID")
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--add-node", nargs=2, metavar=("TOPO_ID", "ZONE_ID"))
    parser.add_argument("--name", default="My Topology")
    parser.add_argument("--type", default="hub_spoke",
                        choices=["hub_spoke", "mesh", "gateway", "point_to_point"])
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.create:
        result = create_topology(args.name, args.type)
    elif args.get:
        result = get_topology(args.get)
    elif args.list:
        result = list_topologies()
    elif args.add_node:
        result = add_node(args.add_node[0], args.add_node[1])
    else:
        parser.print_help()
        exit(0)
    print(json.dumps(result, indent=2, default=str))
