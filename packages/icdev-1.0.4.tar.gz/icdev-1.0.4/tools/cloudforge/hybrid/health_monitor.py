# CUI // SP-CTI
"""Health monitor — cross-cloud health monitoring for hybrid topologies."""

import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def check_topology_health(topology_id: str) -> Dict[str, Any]:
    """Check health of all connections in a topology."""
    conn = _get_db()
    try:
        connections = conn.execute(
            "SELECT * FROM cf_hybrid_connections WHERE topology_id = ?",
            (topology_id,),
        ).fetchall()

        results = []
        healthy = 0
        for c in connections:
            health = "healthy" if c["status"] == "active" else "unhealthy"
            if health == "healthy":
                healthy += 1
            results.append({
                "connection_id": c["id"],
                "type": c["connection_type"],
                "source": c["source_zone_id"],
                "target": c["target_zone_id"],
                "status": c["status"],
                "health": health,
            })

        total = len(connections)
        overall = (
            "healthy" if healthy == total and total > 0
            else "degraded" if healthy > 0
            else "unhealthy"
        )

        # Update topology health
        conn.execute(
            """UPDATE cf_hybrid_topology
               SET health_status = ?, last_health_check = datetime('now'),
                   status = CASE WHEN ? = 'unhealthy' THEN 'error'
                                 WHEN ? = 'degraded' THEN 'degraded'
                                 ELSE status END
               WHERE id = ?""",
            (overall, overall, overall, topology_id),
        )
        conn.commit()

        return {
            "status": "ok",
            "topology_id": topology_id,
            "overall_health": overall,
            "healthy_connections": healthy,
            "total_connections": total,
            "connections": results,
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "classification": "CUI // SP-CTI",
        }
    finally:
        conn.close()


def check_all_topologies(tenant_id: str = "default") -> List[Dict[str, Any]]:
    """Check health across all topologies."""
    conn = _get_db()
    try:
        rows = conn.execute(
            "SELECT id FROM cf_hybrid_topology WHERE tenant_id = ?",
            (tenant_id,),
        ).fetchall()
        return [check_topology_health(r["id"]) for r in rows]
    except Exception:
        return []
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Health Monitor")
    parser.add_argument("--topology", help="Topology ID")
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.topology:
        print(json.dumps(check_topology_health(args.topology), indent=2))
    elif args.all:
        print(json.dumps(check_all_topologies(), indent=2))
    else:
        parser.print_help()
