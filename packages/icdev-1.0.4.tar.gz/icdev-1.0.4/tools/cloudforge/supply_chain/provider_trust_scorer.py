# CUI // SP-CTI
"""Provider trust scorer — score CSP and IaC module trustworthiness."""

import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Trust factors for CSPs
_CSP_TRUST_SCORES: Dict[str, Dict[str, Any]] = {
    "aws_govcloud": {"trust_score": 0.95, "fedramp": "High", "dod_srg": True, "stigs_available": True},
    "aws_commercial": {"trust_score": 0.85, "fedramp": "High", "dod_srg": False, "stigs_available": True},
    "aws_secret": {"trust_score": 0.98, "fedramp": "High", "dod_srg": True, "stigs_available": True},
    "azure_gov": {"trust_score": 0.93, "fedramp": "High", "dod_srg": True, "stigs_available": True},
    "azure_commercial": {"trust_score": 0.83, "fedramp": "High", "dod_srg": False, "stigs_available": True},
    "azure_secret": {"trust_score": 0.97, "fedramp": "High", "dod_srg": True, "stigs_available": True},
    "gcp": {"trust_score": 0.80, "fedramp": "High", "dod_srg": False, "stigs_available": False},
    "oci": {"trust_score": 0.78, "fedramp": "High", "dod_srg": False, "stigs_available": False},
}


def score_provider(cloud_type: str) -> Dict[str, Any]:
    """Score a cloud provider's trust level."""
    scores = _CSP_TRUST_SCORES.get(cloud_type, {"trust_score": 0.5})
    return {
        "cloud_type": cloud_type,
        **scores,
        "classification": "CUI // SP-CTI",
    }


def compare_providers(cloud_types: List[str] = None) -> List[Dict[str, Any]]:
    """Compare trust scores across providers."""
    types = cloud_types or list(_CSP_TRUST_SCORES.keys())
    results = [score_provider(ct) for ct in types]
    results.sort(key=lambda x: x["trust_score"], reverse=True)
    return results


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Provider Trust Scorer")
    parser.add_argument("--score", help="Cloud type to score")
    parser.add_argument("--compare", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.score:
        print(json.dumps(score_provider(args.score), indent=2))
    elif args.compare:
        print(json.dumps(compare_providers(), indent=2))
    else:
        parser.print_help()
