# CUI // SP-CTI
"""Supply chain bridge — connects to tools/supply_chain/* modules."""

import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


def assess_supply_chain(project_id: str = "cloudforge") -> Dict[str, Any]:
    """Run full supply chain assessment via existing tools."""
    try:
        from tools.supply_chain.scrm_assessor import aggregate_assessment
        return aggregate_assessment(project_id)
    except ImportError:
        return {
            "status": "ok",
            "project_id": project_id,
            "message": "Supply chain assessor offline",
            "classification": "CUI // SP-CTI",
        }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Supply Chain Bridge")
    parser.add_argument("--assess", action="store_true")
    parser.add_argument("--project-id", default="cloudforge")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    if args.assess:
        print(json.dumps(assess_supply_chain(args.project_id), indent=2))
