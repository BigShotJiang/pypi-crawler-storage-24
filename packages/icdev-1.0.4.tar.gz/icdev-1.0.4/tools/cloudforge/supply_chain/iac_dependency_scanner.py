# CUI // SP-CTI
"""IaC dependency scanner — scan Terraform modules for vulnerabilities."""

import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


def scan_iac_dependencies(iac_path: str = "") -> Dict[str, Any]:
    """Scan IaC modules for known vulnerabilities.

    Bridges to tools/supply_chain/dependency_graph.py.
    """
    try:
        from tools.supply_chain.dependency_graph import build_graph
        return build_graph("cloudforge")
    except ImportError:
        return {
            "status": "ok",
            "iac_path": iac_path,
            "vulnerabilities": [],
            "total_modules": 0,
            "message": "Supply chain scanner offline",
            "classification": "CUI // SP-CTI",
        }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge IaC Dependency Scanner")
    parser.add_argument("--path", default="")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    print(json.dumps(scan_iac_dependencies(args.path), indent=2))
