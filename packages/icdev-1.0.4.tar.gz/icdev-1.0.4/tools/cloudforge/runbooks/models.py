# CUI // SP-CTI
"""Runbook data models — dataclasses for tasks, edges, and execution results."""

import json
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class RunbookTask:
    """Single task node in a runbook DAG."""
    id: str
    name: str
    action: str  # e.g. "http_check", "sql_query", "shell_cmd", "manual_approval"
    description: str = ""
    parameters: Dict[str, Any] = field(default_factory=dict)
    timeout_seconds: int = 600
    retries: int = 0
    on_failure: str = "stop"  # stop | continue | skip_downstream
    condition: Optional[Dict[str, str]] = None  # {"key": "...", "operator": "...", "value": "..."}
    assigned_to: str = "cloudforge"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RunbookTask":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class RunbookEdge:
    """Directed edge between two tasks in the DAG."""
    source: str  # task_id
    target: str  # task_id
    label: str = ""
    condition: Optional[Dict[str, str]] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RunbookEdge":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class TaskResult:
    """Result of executing a single task."""
    task_id: str
    task_name: str
    action: str  # started | completed | failed | skipped | retried
    output: Dict[str, Any] = field(default_factory=dict)
    error: str = ""
    duration_ms: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ExecutionResult:
    """Result of executing an entire runbook."""
    execution_id: str
    runbook_id: str
    status: str  # completed | failed | cancelled
    tasks_completed: int = 0
    tasks_failed: int = 0
    tasks_skipped: int = 0
    tasks_total: int = 0
    parallel_paths_count: int = 0
    duration_ms: int = 0
    task_results: List[TaskResult] = field(default_factory=list)
    error_summary: str = ""

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["task_results"] = [tr.to_dict() for tr in self.task_results]
        return d


def tasks_from_json(tasks_json: str) -> List[RunbookTask]:
    """Parse tasks_json column into RunbookTask list."""
    raw = json.loads(tasks_json) if isinstance(tasks_json, str) else tasks_json
    return [RunbookTask.from_dict(t) for t in raw]


def edges_from_json(edges_json: str) -> List[RunbookEdge]:
    """Parse edges_json column into RunbookEdge list."""
    raw = json.loads(edges_json) if isinstance(edges_json, str) else edges_json
    return [RunbookEdge.from_dict(e) for e in raw]


def tasks_to_json(tasks: List[RunbookTask]) -> str:
    return json.dumps([t.to_dict() for t in tasks])


def edges_to_json(edges: List[RunbookEdge]) -> str:
    return json.dumps([e.to_dict() for e in edges])
