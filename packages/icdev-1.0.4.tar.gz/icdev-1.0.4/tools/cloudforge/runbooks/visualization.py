# CUI // SP-CTI
"""DAG visualization — convert runbook DAG to JSON node-map for dashboard rendering."""

import json
import logging
from typing import Any, Dict, List

from tools.cloudforge.runbooks.models import edges_from_json, tasks_from_json

logger = logging.getLogger(__name__)


def runbook_to_vis_json(runbook: Dict[str, Any]) -> Dict[str, Any]:
    """Convert a runbook dict to a visualization-ready JSON structure.

    Output format suitable for D3.js force-directed graph or dagre layout:
    {
        "nodes": [{"id": "t1", "name": "...", "action": "...", "level": 0}, ...],
        "links": [{"source": "t1", "target": "t2", "label": "..."}, ...],
        "levels": [[task_ids at level 0], [task_ids at level 1], ...]
    }
    """
    tasks = tasks_from_json(runbook.get("tasks_json", "[]"))
    edges = edges_from_json(runbook.get("edges_json", "[]"))

    # Build adjacency and compute levels via BFS
    in_degree: Dict[str, int] = {t.id: 0 for t in tasks}
    adjacency: Dict[str, List[str]] = {t.id: [] for t in tasks}

    for e in edges:
        if e.source in adjacency and e.target in in_degree:
            adjacency[e.source].append(e.target)
            in_degree[e.target] += 1

    # BFS level assignment
    levels: Dict[str, int] = {}
    queue = [t.id for t in tasks if in_degree[t.id] == 0]
    current_level = 0
    level_groups: List[List[str]] = []

    while queue:
        level_groups.append(list(queue))
        next_queue = []
        for node in queue:
            levels[node] = current_level
            for neighbor in adjacency.get(node, []):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    next_queue.append(neighbor)
        queue = next_queue
        current_level += 1

    # Build nodes
    task_map = {t.id: t for t in tasks}
    nodes = []
    for t in tasks:
        nodes.append({
            "id": t.id,
            "name": t.name,
            "action": t.action,
            "description": t.description,
            "level": levels.get(t.id, 0),
            "on_failure": t.on_failure,
            "has_condition": t.condition is not None,
        })

    # Build links
    links = []
    for e in edges:
        links.append({
            "source": e.source,
            "target": e.target,
            "label": e.label,
            "has_condition": e.condition is not None,
        })

    return {
        "nodes": nodes,
        "links": links,
        "levels": level_groups,
        "total_tasks": len(nodes),
        "total_edges": len(links),
        "max_depth": len(level_groups),
    }


def execution_to_vis_json(execution: Dict[str, Any]) -> Dict[str, Any]:
    """Convert execution detail to visualization-ready JSON with task statuses."""
    task_log = execution.get("task_log", [])
    task_status: Dict[str, str] = {}
    task_duration: Dict[str, int] = {}

    for log in task_log:
        tid = log["task_id"]
        action = log["action"]
        if action in ("completed", "failed", "skipped"):
            task_status[tid] = action
            task_duration[tid] = log.get("duration_ms", 0)
        elif action == "started" and tid not in task_status:
            task_status[tid] = "running"

    return {
        "execution_id": execution.get("id", ""),
        "status": execution.get("status", ""),
        "task_statuses": task_status,
        "task_durations": task_duration,
        "duration_ms": execution.get("duration_ms", 0),
    }
