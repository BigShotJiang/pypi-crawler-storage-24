# CUI // SP-CTI
"""Runbook engine — create, list, get, execute runbooks with DAG execution.

Design decisions:
- D-CF-19: Runbooks stored as JSON DAG (tasks_json + edges_json) in SQLite
- D-CF-20: Executions are append-only with per-task log
- D-CF-21: DAG execution uses Kahn's algorithm (topological sort)
- D-CF-30: Community: 3 runbooks; Pro: unlimited
"""

import json
import logging
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from tools.cloudforge.runbooks.dag_validator import evaluate_condition, validate_dag
from tools.cloudforge.runbooks.models import (
    ExecutionResult,
    RunbookEdge,
    RunbookTask,
    TaskResult,
    edges_from_json,
    edges_to_json,
    tasks_from_json,
    tasks_to_json,
)

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


# ─── CRUD ────────────────────────────────────────────────────────────────────


def create_runbook(
    name: str,
    tasks: List[Dict[str, Any]],
    edges: List[Dict[str, Any]],
    description: str = "",
    template_source: str = "",
    owner: str = "cloudforge",
    tags: str = "",
    tenant_id: str = "default",
    project_id: str = "",
    created_by: str = "cloudforge",
) -> Dict[str, Any]:
    """Create a new runbook with DAG validation."""
    # Parse and validate
    task_objs = [RunbookTask.from_dict(t) for t in tasks]
    edge_objs = [RunbookEdge.from_dict(e) for e in edges]

    validation = validate_dag(task_objs, edge_objs)
    if not validation["valid"]:
        return {
            "status": "error",
            "errors": validation["errors"],
            "classification": "CUI // SP-CTI",
        }

    runbook_id = f"rb-{uuid.uuid4().hex[:8]}"
    conn = _get_db()
    try:
        conn.execute(
            """INSERT INTO cf_runbooks
               (id, name, description, version, status, template_source,
                tasks_json, edges_json, estimated_duration_minutes, owner, tags,
                classification, tenant_id, project_id, created_by,
                created_at, updated_at)
               VALUES (?, ?, ?, 1, 'draft', ?, ?, ?, ?, ?, ?, 'CUI // SP-CTI',
                       ?, ?, ?, datetime('now'), datetime('now'))""",
            (
                runbook_id, name, description, template_source,
                tasks_to_json(task_objs), edges_to_json(edge_objs),
                _estimate_duration(task_objs), owner, tags,
                tenant_id, project_id, created_by,
            ),
        )
        conn.commit()
        return {
            "status": "ok",
            "id": runbook_id,
            "name": name,
            "tasks_count": len(task_objs),
            "edges_count": len(edge_objs),
            "parallel_paths": validation["parallel_paths"],
            "classification": "CUI // SP-CTI",
        }
    except sqlite3.IntegrityError as exc:
        return {"status": "error", "errors": [str(exc)], "classification": "CUI // SP-CTI"}
    finally:
        conn.close()


def list_runbooks(
    tenant_id: str = "default",
    status: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """List all runbooks, optionally filtered by status."""
    conn = _get_db()
    try:
        query = "SELECT * FROM cf_runbooks WHERE tenant_id = ?"
        params: list = [tenant_id]
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY updated_at DESC"
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_runbook(runbook_id: str) -> Optional[Dict[str, Any]]:
    """Get a single runbook with parsed DAG."""
    conn = _get_db()
    try:
        row = conn.execute(
            "SELECT * FROM cf_runbooks WHERE id = ?", (runbook_id,)
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["tasks"] = json.loads(d["tasks_json"])
        d["edges"] = json.loads(d["edges_json"])
        return d
    finally:
        conn.close()


def publish_runbook(runbook_id: str) -> Dict[str, Any]:
    """Transition runbook from draft to published."""
    conn = _get_db()
    try:
        conn.execute(
            "UPDATE cf_runbooks SET status = 'published', updated_at = datetime('now') WHERE id = ? AND status = 'draft'",
            (runbook_id,),
        )
        conn.commit()
        return {"status": "ok", "id": runbook_id, "new_status": "published"}
    finally:
        conn.close()


# ─── EXECUTION ───────────────────────────────────────────────────────────────


def execute_runbook(
    runbook_id: str,
    trigger_type: str = "manual",
    triggered_by: str = "cloudforge",
    context: Optional[Dict[str, Any]] = None,
    tenant_id: str = "default",
) -> ExecutionResult:
    """Execute a runbook using Kahn's topological sort (D-CF-21).

    Tasks at the same topological level run sequentially here but are
    marked as parallelizable for future async execution.
    """
    exec_context = context or {}
    runbook = get_runbook(runbook_id)
    if not runbook:
        return ExecutionResult(
            execution_id="", runbook_id=runbook_id,
            status="failed", error_summary="Runbook not found",
        )

    task_objs = tasks_from_json(runbook["tasks_json"])
    edge_objs = edges_from_json(runbook["edges_json"])

    validation = validate_dag(task_objs, edge_objs)
    if not validation["valid"]:
        return ExecutionResult(
            execution_id="", runbook_id=runbook_id,
            status="failed", error_summary="; ".join(validation["errors"]),
        )

    execution_id = f"rex-{uuid.uuid4().hex[:8]}"
    start_time = time.time()

    # Create execution record
    conn = _get_db()
    try:
        conn.execute(
            """INSERT INTO cf_runbook_executions
               (id, runbook_id, runbook_version, status, trigger_type,
                triggered_by, started_at, tasks_total, classification,
                tenant_id, created_at)
               VALUES (?, ?, ?, 'running', ?, ?, datetime('now'), ?,
                       'CUI // SP-CTI', ?, datetime('now'))""",
            (
                execution_id, runbook_id, runbook.get("version", 1),
                trigger_type, triggered_by, len(task_objs), tenant_id,
            ),
        )
        conn.commit()
    finally:
        conn.close()

    # Execute in topological order
    task_map = {t.id: t for t in task_objs}
    task_results: List[TaskResult] = []
    completed = 0
    failed = 0
    skipped = 0
    failed_tasks: set = set()

    for task_id in validation["topological_order"]:
        task = task_map.get(task_id)
        if not task:
            continue

        # Check if upstream failed and on_failure = stop
        upstream_failed = any(
            e.source in failed_tasks
            for e in edge_objs
            if e.target == task_id
        )

        if upstream_failed:
            _log_task(execution_id, task_id, task.name, "skipped")
            task_results.append(TaskResult(
                task_id=task_id, task_name=task.name,
                action="skipped", error="Upstream task failed",
            ))
            skipped += 1
            continue

        # Check condition (D-CF-25)
        if not evaluate_condition(task.condition, exec_context):
            _log_task(execution_id, task_id, task.name, "skipped")
            task_results.append(TaskResult(
                task_id=task_id, task_name=task.name,
                action="skipped", error="Condition not met",
            ))
            skipped += 1
            continue

        # Execute task
        task_start = time.time()
        _log_task(execution_id, task_id, task.name, "started")

        try:
            output = _execute_task(task, exec_context)
            task_duration = int((time.time() - task_start) * 1000)
            _log_task(execution_id, task_id, task.name, "completed",
                      output=output, duration_ms=task_duration)
            task_results.append(TaskResult(
                task_id=task_id, task_name=task.name,
                action="completed", output=output, duration_ms=task_duration,
            ))
            exec_context[f"task.{task_id}.output"] = output
            exec_context[f"task.{task_id}.status"] = "completed"
            completed += 1
        except Exception as exc:
            task_duration = int((time.time() - task_start) * 1000)
            error_msg = str(exc)
            _log_task(execution_id, task_id, task.name, "failed",
                      error=error_msg, duration_ms=task_duration)
            task_results.append(TaskResult(
                task_id=task_id, task_name=task.name,
                action="failed", error=error_msg, duration_ms=task_duration,
            ))
            failed += 1
            failed_tasks.add(task_id)
            exec_context[f"task.{task_id}.status"] = "failed"

            if task.on_failure == "stop":
                break

    # Finalize execution
    total_duration = int((time.time() - start_time) * 1000)
    final_status = "completed" if failed == 0 else "failed"

    result = ExecutionResult(
        execution_id=execution_id,
        runbook_id=runbook_id,
        status=final_status,
        tasks_completed=completed,
        tasks_failed=failed,
        tasks_skipped=skipped,
        tasks_total=len(task_objs),
        parallel_paths_count=validation["parallel_paths"],
        duration_ms=total_duration,
        task_results=task_results,
        error_summary="" if failed == 0 else f"{failed} task(s) failed",
    )

    # Update execution record
    conn = _get_db()
    try:
        conn.execute(
            """UPDATE cf_runbook_executions
               SET status = ?, completed_at = datetime('now'), duration_ms = ?,
                   task_results_json = ?, parallel_paths_count = ?,
                   tasks_completed = ?, tasks_failed = ?, tasks_skipped = ?,
                   error_summary = ?
               WHERE id = ?""",
            (
                final_status, total_duration,
                json.dumps([tr.to_dict() for tr in task_results]),
                validation["parallel_paths"],
                completed, failed, skipped,
                result.error_summary, execution_id,
            ),
        )
        conn.commit()
    finally:
        conn.close()

    return result


def _execute_task(task: RunbookTask, context: Dict[str, Any]) -> Dict[str, Any]:
    """Execute a single task action. Deterministic dispatch — no eval().

    In production, each action type would delegate to real infrastructure.
    For now, returns simulated success output.
    """
    action = task.action
    params = task.parameters

    if action == "http_check":
        return {"url": params.get("url", ""), "status_code": 200, "latency_ms": 42}
    elif action == "sql_query":
        return {"query": params.get("query", ""), "rows_affected": 0}
    elif action == "shell_cmd":
        return {"command": params.get("command", ""), "exit_code": 0, "stdout": ""}
    elif action == "manual_approval":
        return {"approved": True, "approver": context.get("approver", "auto")}
    elif action == "wait":
        seconds = int(params.get("seconds", 1))
        time.sleep(min(seconds, 5))  # Cap at 5s for safety
        return {"waited_seconds": seconds}
    elif action == "notify":
        return {"channel": params.get("channel", ""), "message": params.get("message", ""), "sent": True}
    elif action == "databridge_sync":
        return {"connection_id": params.get("connection_id", ""), "records_synced": 0}
    elif action == "zone_health":
        return {"zone_id": params.get("zone_id", ""), "healthy": True}
    elif action == "siem_check":
        return {"alerts_count": 0, "critical": 0}
    elif action == "noop":
        return {"action": "noop"}
    else:
        return {"action": action, "simulated": True}


def _log_task(
    execution_id: str, task_id: str, task_name: str, action: str,
    output: Optional[Dict] = None, error: str = "", duration_ms: int = 0,
) -> None:
    """Append to cf_runbook_task_log (D-CF-20, append-only)."""
    try:
        conn = _get_db()
        conn.execute(
            """INSERT INTO cf_runbook_task_log
               (execution_id, task_id, task_name, action,
                output_json, error_details, duration_ms,
                classification, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, 'CUI // SP-CTI', datetime('now'))""",
            (
                execution_id, task_id, task_name, action,
                json.dumps(output) if output else None,
                error, duration_ms,
            ),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        logger.warning("Failed to log task action: %s", exc)


# ─── EXECUTION HISTORY ───────────────────────────────────────────────────────


def list_executions(
    runbook_id: Optional[str] = None,
    tenant_id: str = "default",
    limit: int = 50,
) -> List[Dict[str, Any]]:
    """List runbook executions."""
    conn = _get_db()
    try:
        if runbook_id:
            rows = conn.execute(
                """SELECT * FROM cf_runbook_executions
                   WHERE runbook_id = ? AND tenant_id = ?
                   ORDER BY created_at DESC LIMIT ?""",
                (runbook_id, tenant_id, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                """SELECT * FROM cf_runbook_executions
                   WHERE tenant_id = ?
                   ORDER BY created_at DESC LIMIT ?""",
                (tenant_id, limit),
            ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_execution(execution_id: str) -> Optional[Dict[str, Any]]:
    """Get execution detail with task log."""
    conn = _get_db()
    try:
        row = conn.execute(
            "SELECT * FROM cf_runbook_executions WHERE id = ?", (execution_id,)
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        # Attach task log
        logs = conn.execute(
            "SELECT * FROM cf_runbook_task_log WHERE execution_id = ? ORDER BY id",
            (execution_id,),
        ).fetchall()
        d["task_log"] = [dict(l) for l in logs]
        return d
    finally:
        conn.close()


# ─── HELPERS ─────────────────────────────────────────────────────────────────


def _estimate_duration(tasks: List[RunbookTask]) -> int:
    """Estimate total duration in minutes based on task timeouts."""
    total_seconds = sum(t.timeout_seconds for t in tasks)
    return max(1, total_seconds // 60)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CloudForge Runbook Engine")
    parser.add_argument("--list", action="store_true", help="List runbooks")
    parser.add_argument("--get", help="Get runbook by ID")
    parser.add_argument("--executions", help="List executions for runbook ID")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    if args.list:
        results = list_runbooks()
        if args.json:
            print(json.dumps(results, indent=2))
        else:
            print(f"Runbooks: {len(results)}")
            for r in results:
                print(f"  {r['id']}: {r['name']} ({r['status']})")
    elif args.get:
        rb = get_runbook(args.get)
        print(json.dumps(rb, indent=2) if rb else "Not found")
    elif args.executions:
        execs = list_executions(args.executions)
        print(json.dumps(execs, indent=2) if args.json else f"Executions: {len(execs)}")
    else:
        results = list_runbooks()
        print(json.dumps(results, indent=2) if args.json else f"Runbooks: {len(results)}")
