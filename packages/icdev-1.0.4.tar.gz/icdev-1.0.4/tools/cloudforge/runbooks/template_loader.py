# CUI // SP-CTI
"""Template loader — load YAML runbook templates from args/cloudforge_runbook_templates/.

Design decision D-CF-29: YAML templates in args/ directory (GOTCHA args layer).
Follows blueprint_loader.py pattern.
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

try:
    import yaml
except ImportError:
    yaml = None

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
TEMPLATE_DIR = BASE_DIR / "args" / "cloudforge_runbook_templates"


def _load_yaml(path: Path) -> Dict[str, Any]:
    """Load a YAML file, with fallback for missing PyYAML."""
    if yaml:
        with open(path, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    logger.warning("PyYAML not available — returning empty config for %s", path.name)
    return {}


def list_templates() -> List[Dict[str, str]]:
    """List all available runbook templates."""
    if not TEMPLATE_DIR.exists():
        return []
    templates = []
    for f in sorted(TEMPLATE_DIR.glob("*.yaml")):
        data = _load_yaml(f)
        templates.append({
            "name": f.stem,
            "file": str(f),
            "description": data.get("description", ""),
            "category": data.get("category", "custom"),
            "tasks_count": len(data.get("tasks", [])),
            "estimated_duration_minutes": data.get("estimated_duration_minutes", 0),
        })
    return templates


def load_template(name: str) -> Optional[Dict[str, Any]]:
    """Load a specific runbook template by name (without .yaml extension)."""
    path = TEMPLATE_DIR / f"{name}.yaml"
    if not path.exists():
        logger.error("Template not found: %s", path)
        return None
    data = _load_yaml(path)
    data["_template_name"] = name
    data["_template_path"] = str(path)
    return data


def instantiate_template(
    name: str,
    overrides: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """Load a template and apply parameter overrides.

    Returns dict ready for create_runbook() with tasks and edges.
    """
    template = load_template(name)
    if not template:
        return None

    params = template.get("parameters", {})
    if overrides:
        params.update(overrides)

    # Apply parameter substitution to task fields
    tasks = template.get("tasks", [])
    edges = template.get("edges", [])

    for task in tasks:
        for key, value in task.get("parameters", {}).items():
            if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
                param_name = value[2:-1]
                if param_name in params:
                    task["parameters"][key] = params[param_name]

    return {
        "name": template.get("name", name),
        "description": template.get("description", ""),
        "template_source": name,
        "tasks": tasks,
        "edges": edges,
        "tags": template.get("tags", ""),
    }


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CloudForge Runbook Template Loader")
    parser.add_argument("--list", action="store_true", help="List templates")
    parser.add_argument("--load", help="Load template by name")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    if args.list:
        results = list_templates()
        if args.json:
            print(json.dumps(results, indent=2))
        else:
            print(f"Templates: {len(results)}")
            for t in results:
                print(f"  {t['name']}: {t['description']} ({t['tasks_count']} tasks)")
    elif args.load:
        tmpl = load_template(args.load)
        print(json.dumps(tmpl, indent=2) if tmpl else "Not found")
    else:
        results = list_templates()
        print(json.dumps(results, indent=2) if args.json else f"Templates: {len(results)}")
