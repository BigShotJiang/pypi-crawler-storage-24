# CUI // SP-CTI
"""AI runbook generator — RAG-powered runbook generation (non-critical-path).

Design decision D-CF-26: Always outputs status='draft', deterministic-first.
Uses RAG to find relevant patterns from existing runbooks and templates.
"""

import json
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# Default task actions by category keyword
_CATEGORY_TASKS = {
    "failover": [
        {"id": "t1", "name": "Pre-Check Health", "action": "zone_health"},
        {"id": "t2", "name": "Freeze Writes", "action": "shell_cmd", "parameters": {"command": "writeguard --enable"}},
        {"id": "t3", "name": "Data Sync", "action": "databridge_sync"},
        {"id": "t4", "name": "Switch Traffic", "action": "shell_cmd", "parameters": {"command": "traffic-switch"}},
        {"id": "t5", "name": "Verify Health", "action": "zone_health"},
        {"id": "t6", "name": "Notify", "action": "notify", "parameters": {"channel": "ops", "message": "Failover complete"}},
    ],
    "backup": [
        {"id": "t1", "name": "Check Schedules", "action": "sql_query"},
        {"id": "t2", "name": "Validate Checksums", "action": "shell_cmd", "parameters": {"command": "backup-verify --checksums"}},
        {"id": "t3", "name": "Test Restore", "action": "shell_cmd", "parameters": {"command": "backup-restore --verify"}},
        {"id": "t4", "name": "Log Compliance", "action": "noop"},
        {"id": "t5", "name": "Report", "action": "notify", "parameters": {"channel": "ops", "message": "Backup verified"}},
    ],
    "health": [
        {"id": "t1", "name": "Enumerate Zones", "action": "sql_query"},
        {"id": "t2", "name": "Network Check", "action": "http_check"},
        {"id": "t3", "name": "Service Check", "action": "zone_health"},
        {"id": "t4", "name": "SIEM Check", "action": "siem_check"},
        {"id": "t5", "name": "Report", "action": "notify", "parameters": {"channel": "ops", "message": "Health check done"}},
    ],
    "patch": [
        {"id": "t1", "name": "Pre-Check", "action": "zone_health"},
        {"id": "t2", "name": "Snapshot", "action": "shell_cmd", "parameters": {"command": "snapshot --create"}},
        {"id": "t3", "name": "Canary Deploy", "action": "shell_cmd", "parameters": {"command": "patch-apply --canary"}},
        {"id": "t4", "name": "Verify Canary", "action": "zone_health"},
        {"id": "t5", "name": "Full Rollout", "action": "shell_cmd", "parameters": {"command": "patch-apply --full"}},
        {"id": "t6", "name": "Notify", "action": "notify", "parameters": {"channel": "ops", "message": "Patch deployed"}},
    ],
    "incident": [
        {"id": "t1", "name": "Triage", "action": "siem_check"},
        {"id": "t2", "name": "Contain", "action": "shell_cmd", "parameters": {"command": "network-isolate"}},
        {"id": "t3", "name": "Investigate", "action": "noop"},
        {"id": "t4", "name": "Remediate", "action": "shell_cmd", "parameters": {"command": "remediate"}},
        {"id": "t5", "name": "Restore", "action": "zone_health"},
        {"id": "t6", "name": "Report", "action": "notify", "parameters": {"channel": "security", "message": "Incident resolved"}},
    ],
}


def generate_runbook(
    description: str,
    app_context: str = "",
    category_hint: str = "",
) -> Dict[str, Any]:
    """Generate a runbook draft from a natural language description.

    This is a deterministic-first generator (D-CF-26):
    1. Match keywords to known categories
    2. Generate a linear DAG from the matching template tasks
    3. Always returns status='draft' for human review

    In production with LLM access, step 1 would use RAG to find
    relevant existing runbooks and snippets, and step 2 would use
    an LLM to customize the task parameters.
    """
    desc_lower = description.lower()

    # Step 1: Category detection (deterministic keyword matching)
    detected_category = category_hint
    if not detected_category:
        for cat in _CATEGORY_TASKS:
            if cat in desc_lower:
                detected_category = cat
                break

    if not detected_category:
        # Default: generic health check
        detected_category = "health"

    # Step 2: Build tasks from category template
    template_tasks = _CATEGORY_TASKS.get(detected_category, _CATEGORY_TASKS["health"])
    tasks = []
    for t in template_tasks:
        task = dict(t)
        task.setdefault("description", f"Auto-generated: {task['name']}")
        task.setdefault("timeout_seconds", 300)
        task.setdefault("retries", 0)
        task.setdefault("on_failure", "continue")
        task.setdefault("parameters", {})
        tasks.append(task)

    # Step 3: Build linear edge chain
    edges = []
    for i in range(len(tasks) - 1):
        edges.append({"source": tasks[i]["id"], "target": tasks[i + 1]["id"]})

    # Step 4: Build name
    name = f"AI-Generated: {description[:60]}"

    return {
        "status": "ok",
        "generated": True,
        "category": detected_category,
        "name": name,
        "description": f"AI-generated runbook from: {description}",
        "tasks": tasks,
        "edges": edges,
        "tasks_count": len(tasks),
        "note": "Status will be 'draft' — review before publishing",
        "classification": "CUI // SP-CTI",
    }
