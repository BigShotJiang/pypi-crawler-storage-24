# CUI // SP-CTI
"""Snippet library — reusable sub-DAG task sequences.

Design decision D-CF-22: Snippets are self-contained sub-DAGs embedded by reference.
Usage count tracked for popularity metrics.
"""

import json
import logging
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from tools.cloudforge.runbooks.dag_validator import validate_dag
from tools.cloudforge.runbooks.models import (
    RunbookEdge,
    RunbookTask,
    edges_to_json,
    tasks_to_json,
)

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def create_snippet(
    name: str,
    category: str,
    tasks: List[Dict[str, Any]],
    edges: List[Dict[str, Any]],
    description: str = "",
    tenant_id: str = "default",
    created_by: str = "cloudforge",
) -> Dict[str, Any]:
    """Create a reusable snippet (sub-DAG)."""
    task_objs = [RunbookTask.from_dict(t) for t in tasks]
    edge_objs = [RunbookEdge.from_dict(e) for e in edges]

    validation = validate_dag(task_objs, edge_objs)
    if not validation["valid"]:
        return {"status": "error", "errors": validation["errors"]}

    snippet_id = f"snp-{uuid.uuid4().hex[:8]}"
    conn = _get_db()
    try:
        conn.execute(
            """INSERT INTO cf_runbook_snippets
               (id, name, description, category, tasks_json, edges_json,
                classification, tenant_id, created_by,
                created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, 'CUI // SP-CTI', ?, ?,
                       datetime('now'), datetime('now'))""",
            (
                snippet_id, name, description, category,
                tasks_to_json(task_objs), edges_to_json(edge_objs),
                tenant_id, created_by,
            ),
        )
        conn.commit()
        return {"status": "ok", "id": snippet_id, "name": name, "category": category}
    except sqlite3.IntegrityError as exc:
        return {"status": "error", "errors": [str(exc)]}
    finally:
        conn.close()


def list_snippets(
    tenant_id: str = "default",
    category: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """List all snippets, optionally filtered by category."""
    conn = _get_db()
    try:
        query = "SELECT * FROM cf_runbook_snippets WHERE tenant_id = ?"
        params: list = [tenant_id]
        if category:
            query += " AND category = ?"
            params.append(category)
        query += " ORDER BY usage_count DESC, name ASC"
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_snippet(snippet_id: str) -> Optional[Dict[str, Any]]:
    """Get a snippet by ID with parsed tasks/edges."""
    conn = _get_db()
    try:
        row = conn.execute(
            "SELECT * FROM cf_runbook_snippets WHERE id = ?", (snippet_id,)
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["tasks"] = json.loads(d["tasks_json"])
        d["edges"] = json.loads(d["edges_json"])
        return d
    finally:
        conn.close()


def embed_snippet(
    snippet_id: str,
    runbook_tasks: List[Dict[str, Any]],
    runbook_edges: List[Dict[str, Any]],
    prefix: str = "",
) -> Dict[str, Any]:
    """Embed a snippet's tasks/edges into a runbook, with ID prefixing to avoid collisions.

    Returns updated tasks and edges lists ready for runbook creation.
    """
    snippet = get_snippet(snippet_id)
    if not snippet:
        return {"status": "error", "errors": ["Snippet not found"]}

    pfx = prefix or f"snp-{snippet_id[-8:]}-"

    # Prefix snippet task IDs
    new_tasks = []
    for t in snippet["tasks"]:
        t_copy = dict(t)
        t_copy["id"] = pfx + t_copy["id"]
        new_tasks.append(t_copy)

    new_edges = []
    for e in snippet["edges"]:
        e_copy = dict(e)
        e_copy["source"] = pfx + e_copy["source"]
        e_copy["target"] = pfx + e_copy["target"]
        new_edges.append(e_copy)

    # Increment usage count
    conn = _get_db()
    try:
        conn.execute(
            "UPDATE cf_runbook_snippets SET usage_count = usage_count + 1, updated_at = datetime('now') WHERE id = ?",
            (snippet_id,),
        )
        conn.commit()
    finally:
        conn.close()

    return {
        "status": "ok",
        "tasks": runbook_tasks + new_tasks,
        "edges": runbook_edges + new_edges,
        "snippet_tasks_added": len(new_tasks),
    }
