# CUI // SP-CTI
"""DAG validator — Kahn's algorithm for topological sort, cycle detection, orphan check.

Design decisions:
- D-CF-21: Kahn's algorithm — deterministic O(V+E), no LLM in critical path
- D-CF-25: Conditional branching uses key-operator-value triples (no eval())
"""

import logging
from collections import deque
from typing import Any, Dict, List, Optional, Set, Tuple

from tools.cloudforge.runbooks.models import RunbookEdge, RunbookTask

logger = logging.getLogger(__name__)

VALID_OPERATORS = {"eq", "ne", "gt", "lt", "gte", "lte", "in", "not_in", "contains"}


def validate_dag(
    tasks: List[RunbookTask],
    edges: List[RunbookEdge],
) -> Dict[str, Any]:
    """Validate a runbook DAG structure.

    Returns dict with:
        valid (bool), errors (list), warnings (list),
        topological_order (list of task_id), parallel_paths (int)
    """
    errors: List[str] = []
    warnings: List[str] = []
    task_ids = {t.id for t in tasks}

    # --- Check: no duplicate task IDs ---
    seen_ids: Set[str] = set()
    for t in tasks:
        if t.id in seen_ids:
            errors.append(f"Duplicate task ID: {t.id}")
        seen_ids.add(t.id)

    # --- Check: edges reference valid tasks ---
    for e in edges:
        if e.source not in task_ids:
            errors.append(f"Edge source '{e.source}' not in tasks")
        if e.target not in task_ids:
            errors.append(f"Edge target '{e.target}' not in tasks")
        if e.source == e.target:
            errors.append(f"Self-loop on task '{e.source}'")

    # --- Check: orphan tasks (no edges in or out, if >1 task) ---
    if len(tasks) > 1:
        connected = set()
        for e in edges:
            connected.add(e.source)
            connected.add(e.target)
        orphans = task_ids - connected
        for o in orphans:
            warnings.append(f"Orphan task (no edges): {o}")

    # --- Validate conditions (D-CF-25) ---
    for t in tasks:
        if t.condition:
            _validate_condition(t.condition, f"task '{t.id}'", errors)
    for e in edges:
        if e.condition:
            _validate_condition(e.condition, f"edge '{e.source}->'{e.target}'", errors)

    # --- Kahn's algorithm: topological sort + cycle detection ---
    topo_order, cycle_detected, parallel_paths = _kahns_sort(tasks, edges)

    if cycle_detected:
        errors.append("DAG contains a cycle — cannot execute")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
        "topological_order": topo_order,
        "parallel_paths": parallel_paths,
    }


def _validate_condition(
    condition: Dict[str, str], context: str, errors: List[str]
) -> None:
    """Validate a condition triple: key, operator, value."""
    if not isinstance(condition, dict):
        errors.append(f"Condition on {context} must be a dict")
        return
    for required in ("key", "operator", "value"):
        if required not in condition:
            errors.append(f"Condition on {context} missing '{required}'")
    op = condition.get("operator", "")
    if op and op not in VALID_OPERATORS:
        errors.append(
            f"Invalid operator '{op}' on {context}. Valid: {VALID_OPERATORS}"
        )


def _kahns_sort(
    tasks: List[RunbookTask],
    edges: List[RunbookEdge],
) -> Tuple[List[str], bool, int]:
    """Kahn's algorithm — returns (topological_order, cycle_detected, parallel_paths).

    parallel_paths = max number of tasks that could run concurrently at any level.
    """
    task_ids = [t.id for t in tasks]
    in_degree: Dict[str, int] = {tid: 0 for tid in task_ids}
    adjacency: Dict[str, List[str]] = {tid: [] for tid in task_ids}

    for e in edges:
        if e.source in adjacency and e.target in in_degree:
            adjacency[e.source].append(e.target)
            in_degree[e.target] += 1

    # Start with zero in-degree nodes
    queue: deque = deque()
    for tid in task_ids:
        if in_degree[tid] == 0:
            queue.append(tid)

    topo_order: List[str] = []
    max_parallel = 0

    while queue:
        # All items in queue at this point can run in parallel
        level_size = len(queue)
        max_parallel = max(max_parallel, level_size)

        for _ in range(level_size):
            node = queue.popleft()
            topo_order.append(node)
            for neighbor in adjacency.get(node, []):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

    cycle_detected = len(topo_order) != len(task_ids)
    return topo_order, cycle_detected, max_parallel


def evaluate_condition(
    condition: Optional[Dict[str, str]],
    context: Dict[str, Any],
) -> bool:
    """Evaluate a condition triple against a context dict (D-CF-25).

    No eval() — deterministic key-operator-value comparison only.
    """
    if not condition:
        return True

    key = condition.get("key", "")
    operator = condition.get("operator", "eq")
    expected = condition.get("value", "")

    actual = context.get(key)
    if actual is None:
        return False

    # Coerce types for comparison
    try:
        if isinstance(actual, (int, float)):
            expected = type(actual)(expected)
    except (ValueError, TypeError):
        pass

    if operator == "eq":
        return actual == expected
    elif operator == "ne":
        return actual != expected
    elif operator == "gt":
        return actual > expected
    elif operator == "lt":
        return actual < expected
    elif operator == "gte":
        return actual >= expected
    elif operator == "lte":
        return actual <= expected
    elif operator == "in":
        return actual in (expected if isinstance(expected, (list, tuple, set)) else str(expected).split(","))
    elif operator == "not_in":
        return actual not in (expected if isinstance(expected, (list, tuple, set)) else str(expected).split(","))
    elif operator == "contains":
        return str(expected) in str(actual)
    else:
        logger.warning("Unknown operator: %s", operator)
        return False


if __name__ == "__main__":
    import argparse
    import json as json_mod

    parser = argparse.ArgumentParser(description="Validate a runbook DAG")
    parser.add_argument("--tasks-json", help="JSON string of tasks")
    parser.add_argument("--edges-json", help="JSON string of edges")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    if args.tasks_json and args.edges_json:
        from tools.cloudforge.runbooks.models import tasks_from_json, edges_from_json

        tasks = tasks_from_json(args.tasks_json)
        edges_list = edges_from_json(args.edges_json)
        result = validate_dag(tasks, edges_list)

        if args.json:
            print(json_mod.dumps(result, indent=2))
        else:
            status = "VALID" if result["valid"] else "INVALID"
            print(f"DAG: {status}")
            for e in result["errors"]:
                print(f"  ERROR: {e}")
            for w in result["warnings"]:
                print(f"  WARN: {w}")
            print(f"  Topological order: {result['topological_order']}")
            print(f"  Max parallel paths: {result['parallel_paths']}")
