# CUI // SP-CTI
"""Log aggregator — aggregate logs from all CSPs via DataBridge connectors (D-CF-10)."""

import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def ingest_event(
    zone_id: str,
    cloud_type: str,
    event_source: str,
    event_type: str,
    severity: str = "info",
    raw_event: Dict[str, Any] = None,
) -> Dict[str, Any]:
    """Ingest a SIEM event (append-only)."""
    now = datetime.now(timezone.utc).isoformat()
    conn = _get_db()
    try:
        conn.execute(
            """INSERT INTO cf_siem_events
               (zone_id, cloud_type, event_source, event_type, severity,
                raw_event_json, event_time, classification, ingested_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, 'CUI // SP-CTI', datetime('now'))""",
            (zone_id, cloud_type, event_source, event_type, severity,
             json.dumps(raw_event or {}), now),
        )
        conn.commit()
        return {"status": "ok", "event_time": now, "severity": severity}
    finally:
        conn.close()


def query_events(
    zone_id: str = "",
    severity: str = "",
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """Query SIEM events with optional filters."""
    conn = _get_db()
    try:
        query = "SELECT * FROM cf_siem_events WHERE 1=1"
        params: list = []
        if zone_id:
            query += " AND zone_id = ?"
            params.append(zone_id)
        if severity:
            query += " AND severity = ?"
            params.append(severity)
        query += " ORDER BY event_time DESC LIMIT ?"
        params.append(limit)

        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []
    finally:
        conn.close()


def get_event_summary() -> Dict[str, Any]:
    """Get SIEM event summary by severity."""
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT severity, COUNT(*) as count
               FROM cf_siem_events GROUP BY severity"""
        ).fetchall()
        summary = {r["severity"]: r["count"] for r in rows}
        return {
            "status": "ok",
            "total_events": sum(summary.values()),
            "by_severity": summary,
            "classification": "CUI // SP-CTI",
        }
    except Exception:
        return {"status": "ok", "total_events": 0, "by_severity": {}}
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Log Aggregator")
    parser.add_argument("--query", action="store_true")
    parser.add_argument("--summary", action="store_true")
    parser.add_argument("--zone-id", default="")
    parser.add_argument("--severity", default="")
    parser.add_argument("--limit", type=int, default=100)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.query:
        print(json.dumps(query_events(args.zone_id, args.severity, args.limit), indent=2, default=str))
    elif args.summary:
        print(json.dumps(get_event_summary(), indent=2))
    else:
        parser.print_help()
