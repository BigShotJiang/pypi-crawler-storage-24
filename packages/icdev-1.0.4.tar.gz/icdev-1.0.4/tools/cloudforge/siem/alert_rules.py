# CUI // SP-CTI
"""Alert rules — rule-based alerting for SIEM events."""

import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

DEFAULT_RULES: List[Dict[str, Any]] = [
    {
        "id": "ALERT-001",
        "name": "Critical Security Event",
        "condition": "severity == 'critical'",
        "action": "immediate_notify",
        "enabled": True,
    },
    {
        "id": "ALERT-002",
        "name": "Unauthorized Access Attempt",
        "condition": "event_type == 'unauthorized_access'",
        "action": "notify_and_block",
        "enabled": True,
    },
    {
        "id": "ALERT-003",
        "name": "Configuration Change",
        "condition": "event_type == 'config_change' AND severity >= 'medium'",
        "action": "notify",
        "enabled": True,
    },
    {
        "id": "ALERT-004",
        "name": "Cross-Cloud Correlation",
        "condition": "correlated_event_id IS NOT NULL AND severity >= 'high'",
        "action": "escalate",
        "enabled": True,
    },
]


def evaluate_rules(event: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Evaluate alert rules against an event."""
    fired = []
    severity = event.get("severity", "info")
    event_type = event.get("event_type", "")

    for rule in DEFAULT_RULES:
        if not rule["enabled"]:
            continue

        matched = False
        if rule["id"] == "ALERT-001" and severity == "critical":
            matched = True
        elif rule["id"] == "ALERT-002" and event_type == "unauthorized_access":
            matched = True
        elif rule["id"] == "ALERT-003" and event_type == "config_change" and severity in ("medium", "high", "critical"):
            matched = True
        elif rule["id"] == "ALERT-004" and event.get("correlated_event_id") and severity in ("high", "critical"):
            matched = True

        if matched:
            fired.append({
                "rule_id": rule["id"],
                "rule_name": rule["name"],
                "action": rule["action"],
            })

    return fired


def list_rules() -> List[Dict[str, Any]]:
    """List all alert rules."""
    return DEFAULT_RULES


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Alert Rules")
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    if args.list:
        print(json.dumps(list_rules(), indent=2))
    else:
        parser.print_help()
