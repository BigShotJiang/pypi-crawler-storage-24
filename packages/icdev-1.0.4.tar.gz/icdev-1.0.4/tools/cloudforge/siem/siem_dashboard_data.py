# CUI // SP-CTI
"""SIEM dashboard data — aggregate data for dashboard charts."""

import json
import logging
from typing import Any, Dict

from tools.cloudforge.siem.log_aggregator import get_event_summary
from tools.cloudforge.siem.alert_rules import list_rules

logger = logging.getLogger(__name__)


def get_dashboard_data() -> Dict[str, Any]:
    """Get all SIEM data needed for the dashboard."""
    summary = get_event_summary()
    rules = list_rules()
    return {
        "status": "ok",
        "event_summary": summary,
        "alert_rules": rules,
        "active_rule_count": sum(1 for r in rules if r["enabled"]),
        "classification": "CUI // SP-CTI",
    }


if __name__ == "__main__":
    print(json.dumps(get_dashboard_data(), indent=2))
