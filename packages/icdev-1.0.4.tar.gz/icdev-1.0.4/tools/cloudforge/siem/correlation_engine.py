# CUI // SP-CTI
"""Correlation engine — cross-cloud event correlation."""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def correlate_events(window_minutes: int = 15) -> List[Dict[str, Any]]:
    """Find correlated events within a time window across clouds."""
    conn = _get_db()
    try:
        # Find events from different clouds within the time window
        rows = conn.execute(
            """SELECT a.id as event_a, b.id as event_b,
                      a.cloud_type as cloud_a, b.cloud_type as cloud_b,
                      a.event_type as type_a, b.event_type as type_b,
                      a.severity as sev_a, b.severity as sev_b,
                      a.event_time as time_a, b.event_time as time_b
               FROM cf_siem_events a
               JOIN cf_siem_events b ON a.id < b.id
               WHERE a.cloud_type != b.cloud_type
               AND abs(julianday(a.event_time) - julianday(b.event_time)) * 1440 <= ?
               AND (a.severity IN ('high', 'critical') OR b.severity IN ('high', 'critical'))
               ORDER BY a.event_time DESC
               LIMIT 50""",
            (window_minutes,),
        ).fetchall()

        correlations = [dict(r) for r in rows]
        return correlations
    except Exception:
        return []
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Correlation Engine")
    parser.add_argument("--correlate", action="store_true")
    parser.add_argument("--window", type=int, default=15)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    if args.correlate:
        print(json.dumps(correlate_events(args.window), indent=2, default=str))
    else:
        parser.print_help()
