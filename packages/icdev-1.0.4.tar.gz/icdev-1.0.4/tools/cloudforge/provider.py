# CUI // SP-CTI
"""CloudForge Provider ABC — cloud-agnostic landing zone provisioning (D-CF-1).

Follows the DataConnector ABC pattern from tools/databridge/connector.py.
All providers implement the same interface for provisioning, validation,
cost estimation, and health checking across all CSPs.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class CloudType(Enum):
    """Supported cloud service providers (commercial + government)."""

    AWS_COMMERCIAL = "aws_commercial"
    AWS_GOVCLOUD = "aws_govcloud"
    AWS_SECRET = "aws_secret"
    AZURE_COMMERCIAL = "azure_commercial"
    AZURE_GOV = "azure_gov"
    AZURE_SECRET = "azure_secret"
    GCP = "gcp"
    OCI = "oci"


class ImpactLevel(Enum):
    """DoD Impact Levels for classification."""

    IL2 = "IL2"
    IL4 = "IL4"
    IL5 = "IL5"
    IL6 = "IL6"


class ProvisionStatus(Enum):
    """Landing zone lifecycle states."""

    PLANNED = "planned"
    PROVISIONING = "provisioning"
    ACTIVE = "active"
    UPDATING = "updating"
    DESTROYING = "destroying"
    DESTROYED = "destroyed"
    ERROR = "error"
    DRIFTED = "drifted"


class IaCEngine(Enum):
    """Supported Infrastructure-as-Code engines."""

    TERRAFORM = "terraform"
    OPENTOFU = "opentofu"
    PULUMI = "pulumi"


class MigrationStrategy(Enum):
    """Cloud migration strategies."""

    PHASED = "phased"
    BIG_BANG = "big_bang"
    TRICKLE = "trickle"
    REPLATFORM = "replatform"
    HYBRID = "hybrid"


class TopologyType(Enum):
    """Hybrid cloud topology patterns."""

    HUB_SPOKE = "hub_spoke"
    MESH = "mesh"
    GATEWAY = "gateway"
    POINT_TO_POINT = "point_to_point"


class ConnectionType(Enum):
    """Cross-cloud connection types."""

    VPN = "vpn"
    PEERING = "peering"
    DIRECT_CONNECT = "direct_connect"
    EXPRESSROUTE = "expressroute"
    INTERCONNECT = "interconnect"
    TRANSIT_GATEWAY = "transit_gateway"
    RELAY = "relay"


class DeployStrategy(Enum):
    """Continuous delivery deployment strategies."""

    ROLLING = "rolling"
    CANARY = "canary"
    BLUE_GREEN = "blue_green"
    RECREATE = "recreate"


# ---------------------------------------------------------------------------
# Data Classes
# ---------------------------------------------------------------------------

@dataclass
class ProviderCapabilities:
    """Capabilities advertised by a cloud provider."""

    supported_il_levels: List[str] = field(default_factory=lambda: ["IL2"])
    supports_govcloud: bool = False
    supports_secret_region: bool = False
    supports_k8s: bool = True
    supports_serverless: bool = True
    supports_vpn: bool = True
    supports_peering: bool = False
    supports_direct_connect: bool = False
    max_vpcs: int = 5
    supported_regions: List[str] = field(default_factory=list)
    iac_engines: List[str] = field(default_factory=lambda: ["terraform"])


@dataclass
class ProvisionRequest:
    """Request to provision a landing zone."""

    zone_id: str = ""
    blueprint_name: str = ""
    cloud_type: str = "aws_govcloud"
    region: str = "us-gov-west-1"
    impact_level: str = "IL4"
    environment: str = "staging"
    project_id: str = ""
    tenant_id: str = "default"
    parameters: Dict[str, Any] = field(default_factory=dict)
    iac_engine: str = "terraform"
    classification: str = "CUI // SP-CTI"
    dry_run: bool = False


@dataclass
class ProvisionResponse:
    """Response from a provisioning operation."""

    status: str = "ok"
    zone_id: str = ""
    resources_created: List[Dict[str, Any]] = field(default_factory=list)
    iac_output_path: str = ""
    estimated_monthly_cost_usd: float = 0.0
    compliance_controls_inherited: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    duration_ms: int = 0
    classification: str = "CUI // SP-CTI"

    @property
    def ok(self) -> bool:
        return self.status == "ok" and not self.errors


@dataclass
class CostEstimate:
    """Multi-cloud cost estimate."""

    monthly_usd: float = 0.0
    annual_usd: float = 0.0
    breakdown: Dict[str, float] = field(default_factory=dict)
    currency: str = "USD"
    confidence: str = "estimate"


@dataclass
class DriftResult:
    """Infrastructure drift detection result."""

    has_drift: bool = False
    drifted_resources: List[Dict[str, Any]] = field(default_factory=list)
    total_resources: int = 0
    drift_percentage: float = 0.0
    checked_at: str = ""


@dataclass
class MigrationAssessment:
    """Per-workload migration assessment."""

    workload_id: str = ""
    source_cloud: str = ""
    target_cloud: str = ""
    complexity_score: float = 0.0
    risk_score: float = 0.0
    estimated_downtime_hours: float = 0.0
    recommended_strategy: str = ""
    blockers: List[str] = field(default_factory=list)
    data_volume_gb: float = 0.0
    dependencies: List[str] = field(default_factory=list)


@dataclass
class WorkloadManifest:
    """Cloud-agnostic workload definition (D-CF-17).

    Compiled to CSP-specific IaC by workload_abstractor.
    """

    name: str = ""
    compute: Dict[str, Any] = field(default_factory=dict)
    storage: Dict[str, Any] = field(default_factory=dict)
    network: Dict[str, Any] = field(default_factory=dict)
    database: Dict[str, Any] = field(default_factory=dict)
    classification: str = "CUI // SP-CTI"


@dataclass
class HealthStatus:
    """Health check result for a connection or topology."""

    status: str = "unknown"
    latency_ms: int = 0
    bandwidth_mbps: int = 0
    last_checked: str = ""
    details: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Abstract Base Class
# ---------------------------------------------------------------------------

class CloudProvider(ABC):
    """Abstract base class for all CloudForge providers (D-CF-1).

    Every CSP implementation (AWS, Azure, GCP, OCI) must implement this
    interface. Mirrors the DataConnector ABC from DataBridge.
    """

    @property
    @abstractmethod
    def cloud_type(self) -> CloudType:
        """Return the CloudType enum for this provider."""
        ...

    @property
    @abstractmethod
    def cloud_name(self) -> str:
        """Human-readable name, e.g. 'AWS GovCloud'."""
        ...

    @property
    @abstractmethod
    def capabilities(self) -> ProviderCapabilities:
        """Return capabilities for this provider."""
        ...

    # -- Authentication --

    @abstractmethod
    def authenticate(self, config: Dict[str, Any]) -> bool:
        """Verify credentials. Returns True on success."""
        ...

    # -- Landing Zone Lifecycle --

    @abstractmethod
    def provision(self, request: ProvisionRequest) -> ProvisionResponse:
        """Provision a landing zone from a blueprint."""
        ...

    @abstractmethod
    def validate(self, zone_id: str) -> Dict[str, Any]:
        """Validate a provisioned landing zone (drift, compliance)."""
        ...

    @abstractmethod
    def destroy(self, zone_id: str, dry_run: bool = False) -> ProvisionResponse:
        """Destroy a landing zone."""
        ...

    # -- Health & Cost --

    @abstractmethod
    def health_check(self) -> Dict[str, Any]:
        """Return health status: {status, latency_ms, details}."""
        ...

    @abstractmethod
    def estimate_cost(self, request: ProvisionRequest) -> CostEstimate:
        """Estimate monthly cost for a landing zone blueprint."""
        ...

    # -- Discovery --

    @abstractmethod
    def list_regions(self) -> List[Dict[str, str]]:
        """List available regions for this provider."""
        ...

    def list_services(self) -> List[Dict[str, Any]]:
        """List available services. Override per provider."""
        return []

    def get_inherited_controls(self, impact_level: str) -> List[str]:
        """Return NIST controls inherited from CSP at given IL.

        Override per provider with CSP-specific shared responsibility model.
        """
        return []

    # -- Network --

    def create_vpn(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Create a VPN connection. Override if supported."""
        return {"status": "error", "message": "VPN not supported by this provider"}

    def create_peering(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Create a VPC/VNet peering. Override if supported."""
        return {"status": "error", "message": "Peering not supported by this provider"}

    def create_direct_connect(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Create a direct connect / express route. Override if supported."""
        return {"status": "error", "message": "Direct connect not supported by this provider"}
