# CUI // SP-CTI
"""Zone state manager — track landing zone lifecycle in the database.

Provides state transitions and history queries for landing zones.
All mutations are logged to cf_provision_log (append-only, D-CF-15).
"""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"

VALID_TRANSITIONS = {
    "planned": ["provisioning", "destroyed"],
    "provisioning": ["active", "error"],
    "active": ["updating", "destroying", "drifted"],
    "updating": ["active", "error"],
    "drifted": ["active", "updating", "destroying"],
    "destroying": ["destroyed", "error"],
    "error": ["provisioning", "destroying", "destroyed"],
    "destroyed": [],
}


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def transition_state(zone_id: str, new_status: str, actor: str = "cloudforge") -> Dict[str, Any]:
    """Transition a landing zone to a new status with validation."""
    conn = _get_db()
    try:
        row = conn.execute(
            "SELECT status FROM cf_landing_zones WHERE id = ?", (zone_id,)
        ).fetchone()

        if not row:
            return {"status": "error", "message": f"Zone {zone_id} not found"}

        current = row["status"]
        allowed = VALID_TRANSITIONS.get(current, [])

        if new_status not in allowed:
            return {
                "status": "error",
                "message": f"Invalid transition: {current} -> {new_status}. Allowed: {allowed}",
            }

        conn.execute(
            "UPDATE cf_landing_zones SET status = ?, updated_at = datetime('now') WHERE id = ?",
            (new_status, zone_id),
        )

        # Append-only log (D-CF-15)
        action = "validate" if new_status == "active" else new_status
        conn.execute(
            """INSERT INTO cf_provision_log
               (zone_id, action, status, actor, classification, created_at)
               VALUES (?, ?, 'completed', ?, 'CUI // SP-CTI', datetime('now'))""",
            (zone_id, action, actor),
        )
        conn.commit()

        return {
            "status": "ok",
            "zone_id": zone_id,
            "previous_state": current,
            "new_state": new_status,
        }
    except Exception as exc:
        return {"status": "error", "message": str(exc)}
    finally:
        conn.close()


def get_zone_history(zone_id: str) -> List[Dict[str, Any]]:
    """Return the provision log history for a zone."""
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT action, status, resources_affected, duration_ms,
                      error_details, actor, created_at
               FROM cf_provision_log WHERE zone_id = ?
               ORDER BY created_at DESC""",
            (zone_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []
    finally:
        conn.close()


def get_zone_counts(tenant_id: str = "default") -> Dict[str, int]:
    """Return zone counts by status for a tenant."""
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT status, COUNT(*) as cnt
               FROM cf_landing_zones WHERE tenant_id = ?
               GROUP BY status""",
            (tenant_id,),
        ).fetchall()
        return {r["status"]: r["cnt"] for r in rows}
    except Exception:
        return {}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CloudForge Zone State Manager")
    parser.add_argument("--transition", nargs=2, metavar=("ZONE_ID", "NEW_STATUS"))
    parser.add_argument("--history", help="Zone ID to get history")
    parser.add_argument("--counts", action="store_true")
    parser.add_argument("--tenant", default="default")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.transition:
        result = transition_state(args.transition[0], args.transition[1])
        print(json.dumps(result, indent=2))
    elif args.history:
        history = get_zone_history(args.history)
        print(json.dumps(history, indent=2))
    elif args.counts:
        counts = get_zone_counts(args.tenant)
        print(json.dumps(counts, indent=2))
    else:
        parser.print_help()
