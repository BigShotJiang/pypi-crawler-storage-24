# CUI // SP-CTI
"""Zone provisioner — orchestrates landing zone creation end-to-end.

Loads blueprint → validates → selects provider → renders IaC → logs to DB.
This is the main entry point for creating a landing zone.
"""

import json
import logging
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

from tools.cloudforge.provider import ProvisionRequest, ProvisionResponse

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def _log_provision(zone_id: str, action: str, status: str,
                   duration_ms: int = 0, error: str = "") -> None:
    """Append to cf_provision_log (D-CF-15, append-only)."""
    try:
        conn = _get_db()
        conn.execute(
            """INSERT INTO cf_provision_log
               (zone_id, action, status, duration_ms, error_details,
                classification, created_at)
               VALUES (?, ?, ?, ?, ?, 'CUI // SP-CTI', datetime('now'))""",
            (zone_id, action, status, duration_ms, error),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        logger.warning("Failed to log provision action: %s", exc)


def provision_zone(
    name: str,
    cloud_type: str,
    region: str,
    impact_level: str = "IL4",
    environment: str = "staging",
    blueprint_name: str = "default",
    iac_engine: str = "terraform",
    parameters: Optional[Dict[str, Any]] = None,
    tenant_id: str = "default",
    project_id: str = "",
    created_by: str = "cloudforge",
    dry_run: bool = False,
) -> Dict[str, Any]:
    """Provision a new landing zone end-to-end.

    Steps:
    1. Load and validate blueprint
    2. Create zone record in DB
    3. Select IaC renderer
    4. Render IaC
    5. Log result
    """
    start = time.time()
    zone_id = f"lz-{uuid.uuid4().hex[:8]}"
    params = parameters or {}

    # Step 1: Load blueprint
    from tools.cloudforge.landing_zone.blueprint_loader import load_blueprint
    from tools.cloudforge.landing_zone.blueprint_validator import validate_blueprint

    blueprint = load_blueprint(blueprint_name)
    if blueprint:
        validation = validate_blueprint(blueprint)
        if not validation["valid"]:
            return {
                "status": "error",
                "zone_id": zone_id,
                "errors": validation["errors"],
            }

    # Step 2: Create zone record
    conn = _get_db()
    try:
        conn.execute(
            """INSERT INTO cf_landing_zones
               (id, name, cloud_type, region, impact_level, environment,
                blueprint_name, iac_engine, status, parameters_json,
                classification, tenant_id, project_id, created_by,
                created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'CUI // SP-CTI',
                       ?, ?, ?, datetime('now'), datetime('now'))""",
            (zone_id, name, cloud_type, region, impact_level, environment,
             blueprint_name, iac_engine,
             "planned" if dry_run else "provisioning",
             json.dumps(params), tenant_id, project_id, created_by),
        )
        conn.commit()
    except Exception as exc:
        conn.close()
        return {"status": "error", "zone_id": zone_id, "errors": [str(exc)]}
    finally:
        conn.close()

    _log_provision(zone_id, "plan", "started")

    if dry_run:
        duration_ms = int((time.time() - start) * 1000)
        _log_provision(zone_id, "plan", "completed", duration_ms)
        return {
            "status": "dry_run",
            "zone_id": zone_id,
            "name": name,
            "cloud_type": cloud_type,
            "region": region,
            "impact_level": impact_level,
            "iac_engine": iac_engine,
            "duration_ms": duration_ms,
        }

    # Step 3: Select renderer
    iac_path = ""
    try:
        if iac_engine == "pulumi":
            from tools.cloudforge.iac.pulumi_renderer import render_pulumi
            iac_path = render_pulumi(
                cloud_type=cloud_type, region=region,
                impact_level=impact_level, parameters=params,
                zone_id=zone_id,
            )
        elif iac_engine == "opentofu":
            from tools.cloudforge.iac.opentofu_adapter import render_opentofu
            iac_path = render_opentofu(
                cloud_type=cloud_type, region=region,
                impact_level=impact_level, parameters=params,
                zone_id=zone_id,
            )
        else:
            from tools.cloudforge.iac.terraform_renderer import render_terraform
            iac_path = render_terraform(
                cloud_type=cloud_type, region=region,
                impact_level=impact_level, parameters=params,
                zone_id=zone_id,
            )
    except Exception as exc:
        duration_ms = int((time.time() - start) * 1000)
        _log_provision(zone_id, "plan", "failed", duration_ms, str(exc))
        # Update zone status to error
        conn = _get_db()
        conn.execute(
            "UPDATE cf_landing_zones SET status = 'error', updated_at = datetime('now') WHERE id = ?",
            (zone_id,),
        )
        conn.commit()
        conn.close()
        return {"status": "error", "zone_id": zone_id, "errors": [str(exc)]}

    # Step 4: Get cost estimate
    from tools.cloudforge.registry import get_provider_instance
    provider = get_provider_instance(cloud_type)
    estimated_cost = 0.0
    inherited_controls: list = []
    if provider:
        request = ProvisionRequest(
            zone_id=zone_id, blueprint_name=blueprint_name,
            cloud_type=cloud_type, region=region,
            impact_level=impact_level, parameters=params,
            iac_engine=iac_engine,
        )
        cost_est = provider.estimate_cost(request)
        estimated_cost = cost_est.monthly_usd
        inherited_controls = provider.get_inherited_controls(impact_level)

    # Step 5: Update zone record
    conn = _get_db()
    conn.execute(
        """UPDATE cf_landing_zones
           SET status = 'active', iac_output_path = ?,
               estimated_monthly_cost_usd = ?,
               inherited_controls_json = ?,
               updated_at = datetime('now')
           WHERE id = ?""",
        (iac_path, estimated_cost, json.dumps(inherited_controls), zone_id),
    )
    conn.commit()
    conn.close()

    duration_ms = int((time.time() - start) * 1000)
    _log_provision(zone_id, "apply", "completed", duration_ms)

    return {
        "status": "ok",
        "zone_id": zone_id,
        "name": name,
        "cloud_type": cloud_type,
        "region": region,
        "impact_level": impact_level,
        "iac_engine": iac_engine,
        "iac_output_path": iac_path,
        "estimated_monthly_cost_usd": estimated_cost,
        "inherited_controls": inherited_controls,
        "duration_ms": duration_ms,
    }


def list_zones(tenant_id: str = "default") -> list:
    """List all landing zones for a tenant."""
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT id, name, cloud_type, region, impact_level, environment,
                      status, estimated_monthly_cost_usd, iac_engine, created_at
               FROM cf_landing_zones WHERE tenant_id = ?
               ORDER BY created_at DESC""",
            (tenant_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []
    finally:
        conn.close()


def get_zone(zone_id: str) -> Optional[Dict[str, Any]]:
    """Get a single landing zone by ID."""
    conn = _get_db()
    try:
        row = conn.execute(
            "SELECT * FROM cf_landing_zones WHERE id = ?", (zone_id,)
        ).fetchone()
        return dict(row) if row else None
    except Exception:
        return None
    finally:
        conn.close()


def destroy_zone(zone_id: str, dry_run: bool = False) -> Dict[str, Any]:
    """Destroy a landing zone."""
    start = time.time()
    _log_provision(zone_id, "destroy", "started")

    if dry_run:
        return {"status": "dry_run", "zone_id": zone_id}

    conn = _get_db()
    conn.execute(
        "UPDATE cf_landing_zones SET status = 'destroyed', updated_at = datetime('now') WHERE id = ?",
        (zone_id,),
    )
    conn.commit()
    conn.close()

    duration_ms = int((time.time() - start) * 1000)
    _log_provision(zone_id, "destroy", "completed", duration_ms)

    return {"status": "ok", "zone_id": zone_id, "duration_ms": duration_ms}


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CloudForge Zone Provisioner")
    parser.add_argument("--provision", action="store_true")
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--destroy", help="Zone ID to destroy")
    parser.add_argument("--name", default="my-landing-zone")
    parser.add_argument("--cloud-type", default="aws_govcloud")
    parser.add_argument("--region", default="us-gov-west-1")
    parser.add_argument("--impact-level", default="IL4")
    parser.add_argument("--iac-engine", default="terraform")
    parser.add_argument("--blueprint", default="default")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.provision:
        result = provision_zone(
            name=args.name, cloud_type=args.cloud_type,
            region=args.region, impact_level=args.impact_level,
            iac_engine=args.iac_engine, blueprint_name=args.blueprint,
            dry_run=args.dry_run,
        )
        print(json.dumps(result, indent=2))
    elif args.list:
        zones = list_zones()
        if args.json:
            print(json.dumps(zones, indent=2))
        else:
            for z in zones:
                print(f"  {z['id']} {z['name']:30s} {z['cloud_type']:20s} {z['status']}")
    elif args.destroy:
        result = destroy_zone(args.destroy, dry_run=args.dry_run)
        print(json.dumps(result, indent=2))
    else:
        parser.print_help()
