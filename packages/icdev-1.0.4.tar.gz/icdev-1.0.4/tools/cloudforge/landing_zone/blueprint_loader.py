# CUI // SP-CTI
"""Blueprint loader — load and parse YAML landing zone blueprints from args/.

Blueprints define the modules, parameters, and compliance requirements
for a landing zone. Stored in args/cloudforge_blueprints/.
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

try:
    import yaml
except ImportError:
    yaml = None

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
BLUEPRINT_DIR = BASE_DIR / "args" / "cloudforge_blueprints"


def _load_yaml(path: Path) -> Dict[str, Any]:
    """Load a YAML file, with fallback for missing PyYAML."""
    if yaml:
        with open(path, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    # Minimal fallback for air-gap without PyYAML
    logger.warning("PyYAML not available — returning empty config for %s", path.name)
    return {}


def list_blueprints() -> List[Dict[str, str]]:
    """List all available blueprint files."""
    if not BLUEPRINT_DIR.exists():
        return []
    blueprints = []
    for f in sorted(BLUEPRINT_DIR.glob("*.yaml")):
        data = _load_yaml(f)
        blueprints.append({
            "name": f.stem,
            "file": str(f),
            "cloud_type": data.get("cloud_type", "unknown"),
            "impact_level": data.get("impact_level", "IL4"),
            "description": data.get("description", ""),
        })
    return blueprints


def load_blueprint(name: str) -> Dict[str, Any]:
    """Load a specific blueprint by name (without .yaml extension)."""
    path = BLUEPRINT_DIR / f"{name}.yaml"
    if not path.exists():
        logger.error("Blueprint not found: %s", path)
        return {}
    data = _load_yaml(path)
    data["_blueprint_name"] = name
    data["_blueprint_path"] = str(path)
    return data


def get_blueprint_modules(name: str) -> List[str]:
    """Return the list of IaC modules a blueprint requires."""
    bp = load_blueprint(name)
    return bp.get("modules", [])


def get_blueprint_parameters(name: str) -> Dict[str, Any]:
    """Return the default parameters for a blueprint."""
    bp = load_blueprint(name)
    return bp.get("parameters", {})


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CloudForge Blueprint Loader")
    parser.add_argument("--list", action="store_true", help="List all blueprints")
    parser.add_argument("--load", help="Load a specific blueprint by name")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.list:
        bps = list_blueprints()
        if args.json:
            print(json.dumps(bps, indent=2))
        else:
            for b in bps:
                print(f"  {b['name']:30s} {b['cloud_type']:20s} {b['impact_level']}")
    elif args.load:
        bp = load_blueprint(args.load)
        print(json.dumps(bp, indent=2, default=str))
    else:
        parser.print_help()
