# CUI // SP-CTI
"""Blueprint validator — validate blueprint completeness and compatibility.

Checks that a blueprint specifies all required fields, references valid
modules, and targets a supported CSP + IL combination.
"""

import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

REQUIRED_FIELDS = ["cloud_type", "impact_level", "region", "modules"]
VALID_CLOUD_TYPES = [
    "aws_commercial", "aws_govcloud", "aws_secret",
    "azure_commercial", "azure_gov", "azure_secret",
    "gcp", "oci",
]
VALID_IL_LEVELS = ["IL2", "IL4", "IL5", "IL6"]
VALID_MODULES = [
    "vpc", "k8s", "iam_baseline", "logging", "kms",
    "database", "waf", "guardduty",
]

# IL support matrix per cloud_type
_IL_SUPPORT: Dict[str, List[str]] = {
    "aws_commercial": ["IL2"],
    "aws_govcloud": ["IL2", "IL4", "IL5"],
    "aws_secret": ["IL6"],
    "azure_commercial": ["IL2"],
    "azure_gov": ["IL2", "IL4", "IL5"],
    "azure_secret": ["IL5", "IL6"],
    "gcp": ["IL2", "IL4", "IL5"],
    "oci": ["IL2", "IL4", "IL5"],
}


def validate_blueprint(blueprint: Dict[str, Any]) -> Dict[str, Any]:
    """Validate a blueprint dict. Returns {valid, errors, warnings}."""
    errors: List[str] = []
    warnings: List[str] = []

    # Check required fields
    for field in REQUIRED_FIELDS:
        if field not in blueprint or not blueprint[field]:
            errors.append(f"Missing required field: {field}")

    # Validate cloud_type
    cloud_type = blueprint.get("cloud_type", "")
    if cloud_type and cloud_type not in VALID_CLOUD_TYPES:
        errors.append(f"Invalid cloud_type: {cloud_type}. Must be one of {VALID_CLOUD_TYPES}")

    # Validate impact_level
    il = blueprint.get("impact_level", "")
    if il and il not in VALID_IL_LEVELS:
        errors.append(f"Invalid impact_level: {il}. Must be one of {VALID_IL_LEVELS}")

    # Check IL/CSP compatibility
    if cloud_type and il:
        supported = _IL_SUPPORT.get(cloud_type, [])
        if il not in supported:
            errors.append(
                f"Impact level {il} not supported on {cloud_type}. "
                f"Supported: {supported}"
            )

    # Validate modules
    modules = blueprint.get("modules", [])
    if isinstance(modules, list):
        for mod in modules:
            if mod not in VALID_MODULES:
                warnings.append(f"Unknown module: {mod} (may be custom)")

    # Check IL4+ requires logging and kms
    if il in ("IL4", "IL5", "IL6") and isinstance(modules, list):
        if "logging" not in modules:
            warnings.append(f"IL {il} typically requires 'logging' module")
        if "kms" not in modules:
            warnings.append(f"IL {il} typically requires 'kms' module")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
        "blueprint_name": blueprint.get("_blueprint_name", "unknown"),
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CloudForge Blueprint Validator")
    parser.add_argument("--blueprint", required=True, help="Blueprint name to validate")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    from tools.cloudforge.landing_zone.blueprint_loader import load_blueprint
    bp = load_blueprint(args.blueprint)
    result = validate_blueprint(bp)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        status = "VALID" if result["valid"] else "INVALID"
        print(f"Blueprint '{args.blueprint}': {status}")
        for e in result["errors"]:
            print(f"  ERROR: {e}")
        for w in result["warnings"]:
            print(f"  WARN:  {w}")
