# CUI // SP-CTI
"""Rollback engine — automated rollback on health check failure."""

import json
import logging
from typing import Any, Dict

from tools.cloudforge.cd_hub.hub_controller import rollback

logger = logging.getLogger(__name__)


def auto_rollback(deployment_id: str, reason: str = "health_check_failure") -> Dict[str, Any]:
    """Automatically rollback a deployment and log the reason."""
    result = rollback(deployment_id)
    result["rollback_reason"] = reason
    result["classification"] = "CUI // SP-CTI"
    logger.warning("Auto-rollback triggered for %s: %s", deployment_id, reason)
    return result


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Rollback Engine")
    parser.add_argument("--deployment-id", required=True)
    parser.add_argument("--reason", default="manual_rollback")
    parser.add_argument("--json", action="store_true", help="JSON output (default)")
    args = parser.parse_args()
    print(json.dumps(auto_rollback(args.deployment_id, args.reason), indent=2))
