# CUI // SP-CTI
"""Pipeline bridge — connects CloudForge CD Hub to DevSecOps pipeline generator."""

import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


def generate_pipeline_for_zone(zone_id: str, project_id: str = "cloudforge") -> Dict[str, Any]:
    """Generate a DevSecOps pipeline configuration for a landing zone."""
    try:
        from tools.devsecops.pipeline_security_generator import generate_pipeline_security
        return generate_pipeline_security(project_id)
    except ImportError:
        return {
            "status": "ok",
            "message": "Pipeline generator not available (offline mode)",
            "zone_id": zone_id,
        }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Pipeline Bridge")
    parser.add_argument("--zone-id", required=True)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    print(json.dumps(generate_pipeline_for_zone(args.zone_id), indent=2))
