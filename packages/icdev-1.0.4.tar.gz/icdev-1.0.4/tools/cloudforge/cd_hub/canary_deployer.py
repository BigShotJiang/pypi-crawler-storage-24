# CUI // SP-CTI
"""Canary deployer — progressive rollout with automated promotion/rollback."""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any, Dict

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def start_canary(deployment_id: str, initial_pct: int = 10) -> Dict[str, Any]:
    """Start a canary deployment with initial traffic percentage."""
    conn = _get_db()
    try:
        conn.execute(
            """UPDATE cf_deployments
               SET strategy = 'canary', canary_pct = ?, status = 'deploying'
               WHERE id = ?""",
            (initial_pct, deployment_id),
        )
        conn.commit()
        return {
            "status": "ok",
            "deployment_id": deployment_id,
            "canary_pct": initial_pct,
            "state": "canary_active",
        }
    finally:
        conn.close()


def promote_canary(deployment_id: str, new_pct: int = 100) -> Dict[str, Any]:
    """Promote canary to higher traffic percentage (100 = full rollout)."""
    conn = _get_db()
    try:
        if new_pct >= 100:
            conn.execute(
                """UPDATE cf_deployments
                   SET canary_pct = 100, status = 'healthy', completed_at = datetime('now')
                   WHERE id = ?""",
                (deployment_id,),
            )
            state = "promoted"
        else:
            conn.execute(
                "UPDATE cf_deployments SET canary_pct = ? WHERE id = ?",
                (new_pct, deployment_id),
            )
            state = "canary_active"
        conn.commit()
        return {
            "status": "ok",
            "deployment_id": deployment_id,
            "canary_pct": new_pct,
            "state": state,
        }
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Canary Deployer")
    parser.add_argument("--start", help="Deployment ID")
    parser.add_argument("--promote", help="Deployment ID")
    parser.add_argument("--pct", type=int, default=10)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.start:
        result = start_canary(args.start, args.pct)
    elif args.promote:
        result = promote_canary(args.promote, args.pct)
    else:
        parser.print_help()
        exit(0)
    print(json.dumps(result, indent=2))
