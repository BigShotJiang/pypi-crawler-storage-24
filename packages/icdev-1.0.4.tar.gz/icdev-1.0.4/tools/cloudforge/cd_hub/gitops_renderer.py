# CUI // SP-CTI
"""GitOps renderer — generate ArgoCD/FluxCD manifests for deployments."""

import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)

try:
    import yaml
except ImportError:
    yaml = None


def _to_yaml(data: dict) -> str:
    if yaml:
        return yaml.dump(data, default_flow_style=False, sort_keys=False)
    return json.dumps(data, indent=2)


def render_argocd_app(
    name: str,
    zone_id: str,
    repo_url: str,
    path: str = "manifests",
    target_revision: str = "HEAD",
    namespace: str = "default",
    destination_server: str = "https://kubernetes.default.svc",
) -> Dict[str, Any]:
    """Render an ArgoCD Application manifest."""
    manifest = {
        "apiVersion": "argoproj.io/v1alpha1",
        "kind": "Application",
        "metadata": {
            "name": name,
            "namespace": "argocd",
            "labels": {
                "cloudforge.io/zone-id": zone_id,
                "app.kubernetes.io/managed-by": "cloudforge",
            },
        },
        "spec": {
            "project": "default",
            "source": {
                "repoURL": repo_url,
                "targetRevision": target_revision,
                "path": path,
            },
            "destination": {
                "server": destination_server,
                "namespace": namespace,
            },
            "syncPolicy": {
                "automated": {
                    "prune": True,
                    "selfHeal": True,
                },
                "syncOptions": ["CreateNamespace=true"],
            },
        },
    }
    return {
        "status": "ok",
        "tool": "argocd",
        "manifest": manifest,
        "yaml": _to_yaml(manifest),
    }


def render_fluxcd_kustomization(
    name: str,
    zone_id: str,
    source_name: str = "cloudforge-repo",
    path: str = "./manifests",
    namespace: str = "flux-system",
    interval: str = "5m",
) -> Dict[str, Any]:
    """Render a FluxCD Kustomization manifest."""
    manifest = {
        "apiVersion": "kustomize.toolkit.fluxcd.io/v1",
        "kind": "Kustomization",
        "metadata": {
            "name": name,
            "namespace": namespace,
            "labels": {
                "cloudforge.io/zone-id": zone_id,
            },
        },
        "spec": {
            "interval": interval,
            "sourceRef": {
                "kind": "GitRepository",
                "name": source_name,
            },
            "path": path,
            "prune": True,
            "targetNamespace": "default",
        },
    }
    return {
        "status": "ok",
        "tool": "fluxcd",
        "manifest": manifest,
        "yaml": _to_yaml(manifest),
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge GitOps Renderer")
    parser.add_argument("--tool", choices=["argocd", "fluxcd"], default="argocd")
    parser.add_argument("--name", default="my-app")
    parser.add_argument("--zone-id", default="lz-001")
    parser.add_argument("--repo", default="https://github.com/org/repo.git")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.tool == "argocd":
        result = render_argocd_app(args.name, args.zone_id, args.repo)
    else:
        result = render_fluxcd_kustomization(args.name, args.zone_id)
    print(json.dumps(result, indent=2))
