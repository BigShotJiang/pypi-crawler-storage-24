# CUI // SP-CTI
"""Control tracer — map MBSE model elements to NIST 800-53 controls.

Creates traceability links: SysML Block → NIST Control → IaC Resource.
This forms the digital thread from design to implementation to compliance.
"""

import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Standard mapping: model element types → NIST control families
_ELEMENT_CONTROL_MAP: Dict[str, List[str]] = {
    "network": ["SC-7", "SC-8", "AC-17", "AC-4"],
    "compute": ["CM-6", "CM-7", "SI-2", "SI-3"],
    "identity": ["AC-2", "AC-3", "IA-2", "IA-5"],
    "crypto": ["SC-12", "SC-13", "SC-28"],
    "logging": ["AU-2", "AU-3", "AU-6", "AU-12"],
    "storage": ["SC-28", "MP-2", "MP-4"],
    "database": ["SC-28", "AC-3", "AU-3"],
    "container": ["CM-6", "CM-7", "SI-2", "SC-7"],
    "dmz": ["SC-7", "AC-17", "SI-4"],
}


def trace_controls(zone_id: str, project_id: str = "cloudforge") -> Dict[str, Any]:
    """Build control traceability from boundary components to NIST controls."""
    from tools.cloudforge.mbse_thread.system_boundary import derive_boundary

    boundary = derive_boundary(zone_id, project_id)
    if boundary.get("status") != "ok":
        return boundary

    traces: List[Dict[str, Any]] = []
    all_controls: set = set()

    for component in boundary.get("boundary_components", []):
        comp_type = component.get("type", "")
        mapped_controls = _ELEMENT_CONTROL_MAP.get(comp_type, [])
        all_controls.update(mapped_controls)

        traces.append({
            "component": component["name"],
            "component_type": comp_type,
            "boundary": component.get("boundary", "internal"),
            "mapped_controls": mapped_controls,
        })

    return {
        "status": "ok",
        "zone_id": zone_id,
        "trace_count": len(traces),
        "traces": traces,
        "unique_controls": sorted(all_controls),
        "unique_control_count": len(all_controls),
        "classification": "CUI // SP-CTI",
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Control Tracer")
    parser.add_argument("--zone-id", required=True)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    print(json.dumps(trace_controls(args.zone_id), indent=2))
