# CUI // SP-CTI
"""ATO thread weaver — end-to-end digital thread from SysML to ATO.

Weaves together: SysML Model → System Boundary → Control Mapping →
IaC Resources → Security Scans → Evidence → ATO Package.
"""

import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


def weave_thread(zone_id: str, project_id: str = "cloudforge") -> Dict[str, Any]:
    """Build the complete digital thread for ATO.

    Returns the full traceability chain from model to authorization.
    """
    from tools.cloudforge.mbse_thread.system_boundary import derive_boundary
    from tools.cloudforge.mbse_thread.control_tracer import trace_controls
    from tools.cloudforge.compliance.control_inheritor import get_inherited_controls
    from tools.cloudforge.compliance.ato_accelerator import get_ato_status
    from tools.cloudforge.landing_zone.zone_provisioner import get_zone

    zone = get_zone(zone_id)
    if not zone:
        return {"status": "error", "message": f"Zone {zone_id} not found"}

    # Layer 1: System boundary
    boundary = derive_boundary(zone_id, project_id)

    # Layer 2: Control traceability
    traces = trace_controls(zone_id, project_id)

    # Layer 3: Inherited controls
    inherited = get_inherited_controls(zone["cloud_type"], zone["impact_level"])

    # Layer 4: ATO pipeline status
    ato_status = get_ato_status(zone_id)

    # Thread summary
    thread_links: List[Dict[str, str]] = []
    for trace in traces.get("traces", []):
        for control in trace.get("mapped_controls", []):
            thread_links.append({
                "model_element": trace["component"],
                "element_type": trace["component_type"],
                "nist_control": control,
                "inherited": control in inherited,
                "iac_resource": f"{zone['cloud_type']}_{trace['component_type']}",
            })

    coverage = {
        "boundary_components": boundary.get("component_count", 0),
        "traced_controls": traces.get("unique_control_count", 0),
        "inherited_controls": len(inherited),
        "total_thread_links": len(thread_links),
        "ato_phases_complete": ato_status.get("completed_phases", 0),
        "ato_total_phases": ato_status.get("total_phases", 5),
    }

    return {
        "status": "ok",
        "zone_id": zone_id,
        "cloud_type": zone["cloud_type"],
        "impact_level": zone["impact_level"],
        "thread_links": thread_links,
        "coverage": coverage,
        "ato_complete": ato_status.get("ato_complete", False),
        "classification": "CUI // SP-CTI",
    }


def thread_coverage_report(zone_id: str, project_id: str = "cloudforge") -> Dict[str, Any]:
    """Generate a coverage report for the digital thread."""
    thread = weave_thread(zone_id, project_id)
    if thread.get("status") != "ok":
        return thread

    coverage = thread["coverage"]
    total = coverage["traced_controls"] + coverage["inherited_controls"]
    score = min(100.0, round(total / 325 * 100, 1)) if total else 0.0

    return {
        "status": "ok",
        "zone_id": zone_id,
        "coverage_score_pct": score,
        "coverage": coverage,
        "recommendation": (
            "Full coverage" if score >= 80
            else "Additional control mapping needed" if score >= 50
            else "Significant gaps — review boundary and control mapping"
        ),
        "classification": "CUI // SP-CTI",
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge ATO Thread Weaver")
    parser.add_argument("--zone-id", required=True)
    parser.add_argument("--coverage", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.coverage:
        result = thread_coverage_report(args.zone_id)
    else:
        result = weave_thread(args.zone_id)
    print(json.dumps(result, indent=2))
