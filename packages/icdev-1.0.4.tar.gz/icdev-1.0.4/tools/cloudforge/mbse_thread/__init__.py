# CUI // SP-CTI
"""CloudForge MBSE-to-ATO Thread — SysML boundary to NIST controls to IaC."""
