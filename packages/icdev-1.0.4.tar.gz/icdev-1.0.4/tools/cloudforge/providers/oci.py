# CUI // SP-CTI
"""OCI Provider — Oracle Cloud Infrastructure landing zones.

Supports commercial regions. OCI Government Cloud provides IL2-IL5
with FedRAMP High authorization.
"""

import logging
from typing import Any, Dict, List

from tools.cloudforge.provider import (
    CloudProvider, CloudType, CostEstimate,
    ProviderCapabilities, ProvisionRequest, ProvisionResponse,
)
from tools.cloudforge.registry import register_provider

logger = logging.getLogger(__name__)


@register_provider
class OCIProvider(CloudProvider):
    """Oracle Cloud Infrastructure provider."""

    _provider_name = "oci"

    @property
    def cloud_type(self) -> CloudType:
        return CloudType.OCI

    @property
    def cloud_name(self) -> str:
        return "Oracle Cloud Infrastructure"

    @property
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            supported_il_levels=["IL2", "IL4", "IL5"],
            supports_govcloud=False,
            supports_k8s=True,
            supports_serverless=True,
            supports_vpn=True,
            supports_peering=True,
            supports_direct_connect=True,
            max_vpcs=5,
            supported_regions=[
                "us-ashburn-1", "us-phoenix-1", "us-sanjose-1",
                "us-gov-ashburn-1", "us-gov-chicago-1", "us-gov-phoenix-1",
            ],
            iac_engines=["terraform", "opentofu", "pulumi"],
        )

    def authenticate(self, config: Dict[str, Any]) -> bool:
        try:
            import oci
            oci_config = oci.config.from_file()
            identity = oci.identity.IdentityClient(oci_config)
            identity.get_user(oci_config["user"])
            return True
        except ImportError:
            return True
        except Exception as exc:
            logger.error("OCI auth failed: %s", exc)
            return False

    def provision(self, request: ProvisionRequest) -> ProvisionResponse:
        return ProvisionResponse(
            status="ok", zone_id=request.zone_id,
            estimated_monthly_cost_usd=350.0,
        )

    def validate(self, zone_id: str) -> Dict[str, Any]:
        return {"status": "ok", "zone_id": zone_id}

    def destroy(self, zone_id: str, dry_run: bool = False) -> ProvisionResponse:
        return ProvisionResponse(status="ok" if not dry_run else "dry_run", zone_id=zone_id)

    def health_check(self) -> Dict[str, Any]:
        return {"status": "healthy", "latency_ms": 0}

    def estimate_cost(self, request: ProvisionRequest) -> CostEstimate:
        base = {"IL2": 350.0, "IL4": 1600.0, "IL5": 3200.0}
        monthly = base.get(request.impact_level, 350.0)
        return CostEstimate(monthly_usd=monthly, annual_usd=monthly * 12)

    def list_regions(self) -> List[Dict[str, str]]:
        return [
            {"id": "us-ashburn-1", "name": "US East (Ashburn)"},
            {"id": "us-phoenix-1", "name": "US West (Phoenix)"},
            {"id": "us-gov-ashburn-1", "name": "US Gov (Ashburn)"},
        ]

    def get_inherited_controls(self, impact_level: str) -> List[str]:
        return ["PE-1", "PE-2", "PE-3", "SC-7", "SC-8", "SC-12", "AU-2", "AU-3"]

    def create_vpn(self, config: Dict[str, Any]) -> Dict[str, Any]:
        return {"status": "ok", "type": "oci_core_ipsec", "config": config}

    def create_peering(self, config: Dict[str, Any]) -> Dict[str, Any]:
        return {"status": "ok", "type": "oci_core_remote_peering", "config": config}

    def create_direct_connect(self, config: Dict[str, Any]) -> Dict[str, Any]:
        return {"status": "ok", "type": "oci_core_fast_connect", "config": config}
