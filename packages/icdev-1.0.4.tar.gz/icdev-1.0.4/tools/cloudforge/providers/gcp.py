# CUI // SP-CTI
"""GCP Provider — Google Cloud Platform landing zones.

Supports commercial regions. GCP Assured Workloads provides IL2-IL5 via
FedRAMP High / ITAR configurations within standard GCP.
"""

import logging
from typing import Any, Dict, List

from tools.cloudforge.provider import (
    CloudProvider, CloudType, CostEstimate,
    ProviderCapabilities, ProvisionRequest, ProvisionResponse,
)
from tools.cloudforge.registry import register_provider

logger = logging.getLogger(__name__)


@register_provider
class GCPProvider(CloudProvider):
    """Google Cloud Platform provider."""

    _provider_name = "gcp"

    @property
    def cloud_type(self) -> CloudType:
        return CloudType.GCP

    @property
    def cloud_name(self) -> str:
        return "Google Cloud Platform"

    @property
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            supported_il_levels=["IL2", "IL4", "IL5"],
            supports_govcloud=False,
            supports_k8s=True,
            supports_serverless=True,
            supports_vpn=True,
            supports_peering=True,
            supports_direct_connect=True,
            max_vpcs=5,
            supported_regions=[
                "us-central1", "us-east1", "us-east4", "us-west1",
                "europe-west1", "asia-southeast1",
            ],
            iac_engines=["terraform", "opentofu", "pulumi"],
        )

    def authenticate(self, config: Dict[str, Any]) -> bool:
        try:
            from google.auth import default
            credentials, project = default()
            logger.info("Authenticated to GCP project: %s", project)
            return True
        except ImportError:
            return True
        except Exception as exc:
            logger.error("GCP auth failed: %s", exc)
            return False

    def provision(self, request: ProvisionRequest) -> ProvisionResponse:
        return ProvisionResponse(
            status="ok", zone_id=request.zone_id,
            estimated_monthly_cost_usd=400.0,
        )

    def validate(self, zone_id: str) -> Dict[str, Any]:
        return {"status": "ok", "zone_id": zone_id}

    def destroy(self, zone_id: str, dry_run: bool = False) -> ProvisionResponse:
        return ProvisionResponse(status="ok" if not dry_run else "dry_run", zone_id=zone_id)

    def health_check(self) -> Dict[str, Any]:
        return {"status": "healthy", "latency_ms": 0}

    def estimate_cost(self, request: ProvisionRequest) -> CostEstimate:
        base = {"IL2": 400.0, "IL4": 1800.0, "IL5": 3500.0}
        monthly = base.get(request.impact_level, 400.0)
        return CostEstimate(monthly_usd=monthly, annual_usd=monthly * 12)

    def list_regions(self) -> List[Dict[str, str]]:
        return [
            {"id": "us-central1", "name": "Iowa"},
            {"id": "us-east1", "name": "South Carolina"},
            {"id": "us-east4", "name": "Northern Virginia"},
            {"id": "us-west1", "name": "Oregon"},
        ]

    def get_inherited_controls(self, impact_level: str) -> List[str]:
        return ["PE-1", "PE-2", "PE-3", "SC-7", "SC-8", "SC-12", "AU-2", "AU-3"]

    def create_vpn(self, config: Dict[str, Any]) -> Dict[str, Any]:
        return {"status": "ok", "type": "google_compute_vpn_tunnel", "config": config}

    def create_peering(self, config: Dict[str, Any]) -> Dict[str, Any]:
        return {"status": "ok", "type": "google_compute_network_peering", "config": config}

    def create_direct_connect(self, config: Dict[str, Any]) -> Dict[str, Any]:
        return {"status": "ok", "type": "google_compute_interconnect", "config": config}
