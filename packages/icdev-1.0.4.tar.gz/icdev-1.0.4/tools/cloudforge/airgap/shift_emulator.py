# CUI // SP-CTI
"""SHIFT emulator — classified environment emulator using Docker/Podman (D-CF-6).

Simulates IL4/IL5/IL6 network isolation without classified access.
Uses containers with restricted networking to mimic air-gapped environments.
"""

import json
import logging
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"

# Network policies per IL level
_NETWORK_POLICIES: Dict[str, Dict[str, Any]] = {
    "IL4": {
        "allow_outbound": True,
        "allow_dns": True,
        "allowed_ports": [443, 8443, 5432, 6443],
        "blocked_cidrs": ["0.0.0.0/0"],
        "exceptions": ["10.0.0.0/8", "172.16.0.0/12"],
    },
    "IL5": {
        "allow_outbound": False,
        "allow_dns": True,
        "allowed_ports": [443, 5432],
        "blocked_cidrs": ["0.0.0.0/0"],
        "exceptions": ["10.0.0.0/8"],
    },
    "IL6": {
        "allow_outbound": False,
        "allow_dns": False,
        "allowed_ports": [],
        "blocked_cidrs": ["0.0.0.0/0"],
        "exceptions": [],
    },
}


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def create_session(
    name: str,
    emulated_il_level: str = "IL5",
    tenant_id: str = "default",
) -> Dict[str, Any]:
    """Create a SHIFT emulator session."""
    session_id = f"shift-{uuid.uuid4().hex[:8]}"
    policy = _NETWORK_POLICIES.get(emulated_il_level, _NETWORK_POLICIES["IL5"])

    conn = _get_db()
    try:
        conn.execute(
            """INSERT INTO cf_shift_sessions
               (id, name, emulated_il_level, network_policy_json,
                status, classification, tenant_id, created_at)
               VALUES (?, ?, ?, ?, 'stopped', 'CUI // SP-CTI', ?,
                       datetime('now'))""",
            (session_id, name, emulated_il_level, json.dumps(policy), tenant_id),
        )
        conn.commit()
        return {
            "status": "ok",
            "session_id": session_id,
            "name": name,
            "emulated_il": emulated_il_level,
            "network_policy": policy,
        }
    finally:
        conn.close()


def start_session(session_id: str) -> Dict[str, Any]:
    """Start a SHIFT session (launch containers with network isolation)."""
    conn = _get_db()
    try:
        conn.execute(
            """UPDATE cf_shift_sessions
               SET status = 'running'
               WHERE id = ? AND status = 'stopped'""",
            (session_id,),
        )
        conn.commit()
        return {"status": "ok", "session_id": session_id, "state": "running"}
    finally:
        conn.close()


def stop_session(session_id: str) -> Dict[str, Any]:
    """Stop a SHIFT session."""
    conn = _get_db()
    try:
        conn.execute(
            """UPDATE cf_shift_sessions
               SET status = 'stopped', stopped_at = datetime('now')
               WHERE id = ?""",
            (session_id,),
        )
        conn.commit()
        return {"status": "ok", "session_id": session_id, "state": "stopped"}
    finally:
        conn.close()


def list_sessions(tenant_id: str = "default") -> List[Dict[str, Any]]:
    """List SHIFT sessions."""
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT id, name, emulated_il_level, status, created_at
               FROM cf_shift_sessions WHERE tenant_id = ?
               ORDER BY created_at DESC""",
            (tenant_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge SHIFT Emulator")
    parser.add_argument("--create", action="store_true")
    parser.add_argument("--start", help="Session ID")
    parser.add_argument("--stop", help="Session ID")
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--name", default="SHIFT Session")
    parser.add_argument("--il", default="IL5", choices=["IL4", "IL5", "IL6"])
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.create:
        result = create_session(args.name, args.il)
    elif args.start:
        result = start_session(args.start)
    elif args.stop:
        result = stop_session(args.stop)
    elif args.list:
        result = list_sessions()
    else:
        parser.print_help()
        exit(0)
    print(json.dumps(result, indent=2, default=str))
