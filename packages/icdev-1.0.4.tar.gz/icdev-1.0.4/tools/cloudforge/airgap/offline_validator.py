# CUI // SP-CTI
"""Offline validator — validate bundles without network access."""

import json
import logging
from pathlib import Path
from typing import Any, Dict

logger = logging.getLogger(__name__)


def validate_bundle(bundle_path: str) -> Dict[str, Any]:
    """Validate a sneakernet bundle for completeness."""
    path = Path(bundle_path)
    checks = []

    # Check manifest
    manifest_ok = (path / "manifest.json").exists()
    checks.append({"check": "manifest", "passed": manifest_ok})

    # Check config
    config_ok = (path / "cloudforge_config.yaml").exists()
    checks.append({"check": "config", "passed": config_ok})

    all_passed = all(c["passed"] for c in checks)

    return {
        "status": "ok",
        "bundle_path": str(path),
        "valid": all_passed,
        "checks": checks,
        "classification": "CUI // SP-CTI",
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Offline Validator")
    parser.add_argument("--validate", required=True, help="Bundle path")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    print(json.dumps(validate_bundle(args.validate), indent=2))
