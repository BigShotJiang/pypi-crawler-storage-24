# CUI // SP-CTI
"""Sneakernet — bundle export/import for disconnected environments.

Creates portable bundles containing IaC, configs, and container images
that can be transferred via physical media to air-gapped networks.
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
OUTPUT_DIR = BASE_DIR / ".tmp" / "cloudforge" / "bundles"


def create_bundle(
    zone_id: str,
    include_iac: bool = True,
    include_images: bool = False,
    include_config: bool = True,
) -> Dict[str, Any]:
    """Create a sneakernet bundle for offline transfer."""
    bundle_dir = OUTPUT_DIR / zone_id
    bundle_dir.mkdir(parents=True, exist_ok=True)

    contents: List[str] = []

    # Manifest
    manifest = {
        "zone_id": zone_id,
        "bundle_version": "1.0",
        "includes_iac": include_iac,
        "includes_images": include_images,
        "includes_config": include_config,
        "classification": "CUI // SP-CTI",
    }
    manifest_path = bundle_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    contents.append("manifest.json")

    if include_config:
        # Copy cloudforge config
        config_src = BASE_DIR / "args" / "cloudforge_config.yaml"
        if config_src.exists():
            (bundle_dir / "cloudforge_config.yaml").write_text(
                config_src.read_text(encoding="utf-8"), encoding="utf-8"
            )
            contents.append("cloudforge_config.yaml")

    return {
        "status": "ok",
        "zone_id": zone_id,
        "bundle_path": str(bundle_dir),
        "contents": contents,
        "classification": "CUI // SP-CTI",
    }


def import_bundle(bundle_path: str) -> Dict[str, Any]:
    """Import a sneakernet bundle on the air-gapped side."""
    path = Path(bundle_path)
    manifest_path = path / "manifest.json"
    if not manifest_path.exists():
        return {"status": "error", "message": "No manifest.json found in bundle"}

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    return {
        "status": "ok",
        "zone_id": manifest.get("zone_id", "unknown"),
        "bundle_version": manifest.get("bundle_version", "unknown"),
        "imported_from": str(path),
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Sneakernet")
    parser.add_argument("--export", help="Zone ID to export")
    parser.add_argument("--import-bundle", help="Path to import")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.export:
        print(json.dumps(create_bundle(args.export), indent=2))
    elif args.import_bundle:
        print(json.dumps(import_bundle(args.import_bundle), indent=2))
    else:
        parser.print_help()
