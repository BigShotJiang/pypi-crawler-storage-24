# CUI // SP-CTI
"""IL classifier — auto-classify resources by Impact Level."""

import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Classification rules based on data sensitivity
_CLASSIFICATION_RULES = {
    "IL2": {
        "description": "Non-CUI, publicly releasable",
        "data_types": ["public", "non_sensitive"],
        "markings": [],
    },
    "IL4": {
        "description": "CUI — Controlled Unclassified Information",
        "data_types": ["cui", "fouo", "pii", "phi"],
        "markings": ["CUI", "CUI // SP-CTI"],
    },
    "IL5": {
        "description": "CUI + National Security Systems",
        "data_types": ["cui", "nss", "export_controlled"],
        "markings": ["CUI // SP-CTI", "CUI // ITAR"],
    },
    "IL6": {
        "description": "Classified — SECRET",
        "data_types": ["secret", "noforn"],
        "markings": ["SECRET", "SECRET // NOFORN"],
    },
}


def classify_resource(
    data_types: List[str],
    current_il: str = "IL2",
) -> Dict[str, Any]:
    """Determine the minimum IL level required for given data types."""
    required_il = "IL2"
    for il_level in ["IL6", "IL5", "IL4", "IL2"]:
        rule = _CLASSIFICATION_RULES[il_level]
        if any(dt in rule["data_types"] for dt in data_types):
            required_il = il_level
            break

    upgrade_needed = (
        list(_CLASSIFICATION_RULES.keys()).index(required_il)
        > list(_CLASSIFICATION_RULES.keys()).index(current_il)
    )

    return {
        "status": "ok",
        "required_il": required_il,
        "current_il": current_il,
        "upgrade_needed": upgrade_needed,
        "description": _CLASSIFICATION_RULES[required_il]["description"],
        "markings": _CLASSIFICATION_RULES[required_il]["markings"],
        "classification": "CUI // SP-CTI",
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge IL Classifier")
    parser.add_argument("--data-types", nargs="+", default=["cui"])
    parser.add_argument("--current-il", default="IL2")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    print(json.dumps(classify_resource(args.data_types, args.current_il), indent=2))
