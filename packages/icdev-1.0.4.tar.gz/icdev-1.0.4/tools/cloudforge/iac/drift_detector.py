# CUI // SP-CTI
"""Infrastructure drift detection for CloudForge landing zones.

Compares expected state (DB + IaC) against actual infrastructure.
Uses deterministic comparison (D-CF-7) — no LLM required.
"""

import json
import logging
import sqlite3
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from tools.cloudforge.provider import DriftResult

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def _log_drift_check(zone_id: str, status: str, drift_count: int = 0,
                     details: str = "", duration_ms: int = 0) -> None:
    """Append drift check to provision log (D-CF-15)."""
    try:
        conn = _get_db()
        conn.execute(
            """INSERT INTO cf_provision_log
               (zone_id, action, status, resources_affected, duration_ms,
                error_details, classification, created_at)
               VALUES (?, 'drift_check', ?, ?, ?, ?, 'CUI // SP-CTI', datetime('now'))""",
            (zone_id, status, drift_count, duration_ms, details),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        logger.warning("Failed to log drift check: %s", exc)


def detect_drift(zone_id: str, provider_name: str = "") -> DriftResult:
    """Run drift detection for a landing zone.

    In a real deployment this would run `terraform plan -detailed-exitcode`.
    Here we check the zone status in the DB and simulate a drift scan.
    """
    start = time.time()
    conn = _get_db()

    try:
        row = conn.execute(
            "SELECT * FROM cf_landing_zones WHERE id = ?", (zone_id,)
        ).fetchone()
    except Exception:
        row = None
    finally:
        conn.close()

    if not row:
        result = DriftResult(
            zone_id=zone_id, has_drift=False,
            drift_items=[], scan_duration_ms=0,
            error="Zone not found",
        )
        return result

    zone_status = row["status"] if row else "unknown"
    duration_ms = int((time.time() - start) * 1000)

    # Simulated drift detection (real impl would shell out to terraform plan)
    has_drift = zone_status == "drifted"
    drift_items: List[Dict[str, str]] = []
    if has_drift:
        drift_items.append({
            "resource": "simulated_resource",
            "attribute": "configuration",
            "expected": "as-defined",
            "actual": "modified",
        })

    result = DriftResult(
        zone_id=zone_id,
        has_drift=has_drift,
        drift_items=drift_items,
        scan_duration_ms=duration_ms,
    )

    _log_drift_check(
        zone_id=zone_id,
        status="completed",
        drift_count=len(drift_items),
        duration_ms=duration_ms,
    )

    return result


def detect_drift_all(tenant_id: str = "default") -> List[DriftResult]:
    """Run drift detection across all active landing zones for a tenant."""
    conn = _get_db()
    try:
        rows = conn.execute(
            "SELECT id FROM cf_landing_zones WHERE tenant_id = ? AND status = 'active'",
            (tenant_id,),
        ).fetchall()
    except Exception:
        rows = []
    finally:
        conn.close()

    results = []
    for row in rows:
        results.append(detect_drift(row["id"]))
    return results


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CloudForge Drift Detector")
    parser.add_argument("--zone-id", help="Check specific zone")
    parser.add_argument("--all", action="store_true", help="Check all active zones")
    parser.add_argument("--tenant", default="default")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.all:
        results = detect_drift_all(args.tenant)
        if args.json:
            print(json.dumps([asdict(r) for r in results], indent=2))
        else:
            for r in results:
                status = "DRIFT" if r.has_drift else "OK"
                print(f"  {r.zone_id}: {status} ({len(r.drift_items)} items)")
    elif args.zone_id:
        result = detect_drift(args.zone_id)
        if args.json:
            print(json.dumps(asdict(result), indent=2))
        else:
            status = "DRIFT DETECTED" if result.has_drift else "NO DRIFT"
            print(f"{result.zone_id}: {status}")
    else:
        parser.print_help()
