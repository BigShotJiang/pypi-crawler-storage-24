# CUI // SP-CTI
"""Reusable IaC module library — VPC, K8s, IAM, DB, logging modules.

Provides parameterized module snippets that landing zone blueprints can
compose. Each module returns HCL strings for Terraform/OpenTofu.
"""

import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module catalog
# ---------------------------------------------------------------------------
MODULE_CATALOG: Dict[str, Dict[str, Any]] = {
    "vpc": {
        "name": "Virtual Private Cloud / VNet / VCN",
        "csp_support": ["aws", "azure", "gcp", "oci"],
        "params": ["cidr", "az_count", "enable_flow_logs"],
    },
    "k8s": {
        "name": "Managed Kubernetes (EKS / AKS / GKE / OKE)",
        "csp_support": ["aws", "azure", "gcp", "oci"],
        "params": ["cluster_name", "node_count", "node_size", "k8s_version"],
    },
    "iam_baseline": {
        "name": "IAM Baseline (roles, policies, MFA)",
        "csp_support": ["aws", "azure", "gcp", "oci"],
        "params": ["admin_role_name", "enforce_mfa"],
    },
    "logging": {
        "name": "Centralized Logging (CloudTrail / Activity Log / Audit)",
        "csp_support": ["aws", "azure", "gcp", "oci"],
        "params": ["retention_days", "enable_encryption"],
    },
    "kms": {
        "name": "Key Management (KMS / Key Vault / Cloud KMS)",
        "csp_support": ["aws", "azure", "gcp", "oci"],
        "params": ["key_alias", "rotation_days"],
    },
    "database": {
        "name": "Managed Database (RDS / SQL / Cloud SQL / DB System)",
        "csp_support": ["aws", "azure", "gcp", "oci"],
        "params": ["engine", "instance_class", "storage_gb", "multi_az"],
    },
    "waf": {
        "name": "Web Application Firewall",
        "csp_support": ["aws", "azure", "gcp"],
        "params": ["managed_rules", "rate_limit"],
    },
    "guardduty": {
        "name": "Threat Detection (GuardDuty / Defender / SCC)",
        "csp_support": ["aws", "azure", "gcp"],
        "params": ["enable_s3_protection", "enable_k8s_protection"],
    },
}

# ---------------------------------------------------------------------------
# K8s module HCL per CSP
# ---------------------------------------------------------------------------
_K8S_MODULES: Dict[str, str] = {
    "aws": '''
# --- EKS Cluster ---
resource "aws_eks_cluster" "{cluster_name}" {{
  name     = "{cluster_name}"
  role_arn = aws_iam_role.eks_cluster.arn
  version  = "{k8s_version}"

  vpc_config {{
    subnet_ids              = aws_subnet.private[*].id
    endpoint_private_access = true
    endpoint_public_access  = false
  }}

  encryption_config {{
    provider {{
      key_arn = aws_kms_key.eks.arn
    }}
    resources = ["secrets"]
  }}

  tags = {{
    ManagedBy = "cloudforge"
  }}
}}

resource "aws_eks_node_group" "workers" {{
  cluster_name    = aws_eks_cluster.{cluster_name}.name
  node_group_name = "{cluster_name}-workers"
  node_role_arn   = aws_iam_role.eks_node.arn
  subnet_ids      = aws_subnet.private[*].id

  scaling_config {{
    desired_size = {node_count}
    max_size     = {node_count} * 2
    min_size     = 1
  }}

  instance_types = ["{node_size}"]
}}
''',
    "azure": '''
# --- AKS Cluster ---
resource "azurerm_kubernetes_cluster" "{cluster_name}" {{
  name                = "{cluster_name}"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  dns_prefix          = "{cluster_name}"
  kubernetes_version  = "{k8s_version}"

  default_node_pool {{
    name       = "default"
    node_count = {node_count}
    vm_size    = "{node_size}"
    vnet_subnet_id = azurerm_subnet.private.id
  }}

  identity {{
    type = "SystemAssigned"
  }}

  network_profile {{
    network_plugin = "azure"
    network_policy = "calico"
  }}

  tags = {{
    ManagedBy = "cloudforge"
  }}
}}
''',
    "gcp": '''
# --- GKE Cluster ---
resource "google_container_cluster" "{cluster_name}" {{
  name     = "{cluster_name}"
  location = var.region

  initial_node_count       = 1
  remove_default_node_pool = true
  min_master_version       = "{k8s_version}"

  network    = google_compute_network.main.name
  subnetwork = google_compute_subnetwork.private.name

  private_cluster_config {{
    enable_private_nodes    = true
    enable_private_endpoint = false
    master_ipv4_cidr_block  = "172.16.0.0/28"
  }}
}}

resource "google_container_node_pool" "workers" {{
  name       = "{cluster_name}-workers"
  location   = var.region
  cluster    = google_container_cluster.{cluster_name}.name
  node_count = {node_count}

  node_config {{
    machine_type = "{node_size}"
    oauth_scopes = ["https://www.googleapis.com/auth/cloud-platform"]
  }}
}}
''',
    "oci": '''
# --- OKE Cluster ---
resource "oci_containerengine_cluster" "{cluster_name}" {{
  compartment_id     = var.compartment_id
  kubernetes_version = "{k8s_version}"
  name               = "{cluster_name}"
  vcn_id             = oci_core_vcn.main.id

  endpoint_config {{
    is_public_ip_enabled = false
    subnet_id            = oci_core_subnet.private.id
  }}
}}

resource "oci_containerengine_node_pool" "workers" {{
  cluster_id         = oci_containerengine_cluster.{cluster_name}.id
  compartment_id     = var.compartment_id
  kubernetes_version = "{k8s_version}"
  name               = "{cluster_name}-workers"

  node_config_details {{
    size = {node_count}
    placement_configs {{
      availability_domain = data.oci_identity_availability_domains.ads.availability_domains[0].name
      subnet_id           = oci_core_subnet.private.id
    }}
  }}

  node_shape = "{node_size}"
}}
''',
}

# ---------------------------------------------------------------------------
# Default node sizes per CSP
# ---------------------------------------------------------------------------
_DEFAULT_NODE_SIZES: Dict[str, str] = {
    "aws": "m5.xlarge",
    "azure": "Standard_D4s_v3",
    "gcp": "e2-standard-4",
    "oci": "VM.Standard.E4.Flex",
}


def get_module_catalog() -> List[Dict[str, Any]]:
    """Return the full module catalog."""
    return [{"id": k, **v} for k, v in MODULE_CATALOG.items()]


def render_k8s_module(
    csp_family: str,
    cluster_name: str = "cloudforge-k8s",
    node_count: int = 3,
    node_size: str = "",
    k8s_version: str = "1.29",
) -> str:
    """Render a managed Kubernetes module for the given CSP family."""
    node_size = node_size or _DEFAULT_NODE_SIZES.get(csp_family, "m5.xlarge")
    template = _K8S_MODULES.get(csp_family, f"# No K8s template for {csp_family}\n")
    return template.format(
        cluster_name=cluster_name,
        node_count=node_count,
        node_size=node_size,
        k8s_version=k8s_version,
    )


def list_modules(csp_family: str = "") -> List[Dict[str, Any]]:
    """List available modules, optionally filtered by CSP family."""
    catalog = get_module_catalog()
    if csp_family:
        catalog = [m for m in catalog if csp_family in m["csp_support"]]
    return catalog


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CloudForge Module Library")
    parser.add_argument("--list", action="store_true", help="List all modules")
    parser.add_argument("--csp", default="", help="Filter by CSP family")
    parser.add_argument("--render-k8s", action="store_true")
    parser.add_argument("--cluster-name", default="cloudforge-k8s")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.list:
        modules = list_modules(args.csp)
        if args.json:
            print(json.dumps(modules, indent=2))
        else:
            for m in modules:
                print(f"  {m['id']:20s} {m['name']}")
    elif args.render_k8s:
        csp = args.csp or "aws"
        hcl = render_k8s_module(csp, cluster_name=args.cluster_name)
        print(hcl)
