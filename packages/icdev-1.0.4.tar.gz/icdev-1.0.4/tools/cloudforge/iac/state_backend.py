# CUI // SP-CTI
"""Remote state backend configuration per CSP.

Manages Terraform/OpenTofu state backend selection and initialization
commands for each cloud provider.
"""

import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Backend configurations
# ---------------------------------------------------------------------------
_BACKENDS: Dict[str, Dict[str, Any]] = {
    "aws_commercial": {
        "type": "s3",
        "init_cmd": "terraform init -backend-config=backend.hcl",
        "config": {
            "bucket": "cloudforge-state-{region}",
            "key": "cloudforge/{zone_id}/terraform.tfstate",
            "region": "{region}",
            "encrypt": True,
            "dynamodb_table": "cloudforge-locks",
        },
    },
    "aws_govcloud": {
        "type": "s3",
        "init_cmd": "terraform init -backend-config=backend.hcl",
        "config": {
            "bucket": "cloudforge-state-{region}",
            "key": "cloudforge/{zone_id}/terraform.tfstate",
            "region": "{region}",
            "encrypt": True,
            "dynamodb_table": "cloudforge-locks",
        },
    },
    "aws_secret": {
        "type": "s3",
        "init_cmd": "terraform init -backend-config=backend.hcl",
        "config": {
            "bucket": "cloudforge-state-{region}",
            "key": "cloudforge/{zone_id}/terraform.tfstate",
            "region": "{region}",
            "encrypt": True,
        },
    },
    "azure_commercial": {
        "type": "azurerm",
        "init_cmd": "terraform init -backend-config=backend.hcl",
        "config": {
            "resource_group_name": "cloudforge-state-rg",
            "storage_account_name": "cloudforgestate",
            "container_name": "cloudforge",
            "key": "{zone_id}.tfstate",
        },
    },
    "azure_gov": {
        "type": "azurerm",
        "init_cmd": "terraform init -backend-config=backend.hcl",
        "config": {
            "resource_group_name": "cloudforge-state-rg",
            "storage_account_name": "cloudforgestate",
            "container_name": "cloudforge",
            "key": "{zone_id}.tfstate",
            "environment": "usgovernment",
        },
    },
    "azure_secret": {
        "type": "azurerm",
        "init_cmd": "terraform init -backend-config=backend.hcl",
        "config": {
            "resource_group_name": "cloudforge-state-rg",
            "storage_account_name": "cloudforgestate",
            "container_name": "cloudforge",
            "key": "{zone_id}.tfstate",
            "environment": "usgovernment",
        },
    },
    "gcp": {
        "type": "gcs",
        "init_cmd": "terraform init -backend-config=backend.hcl",
        "config": {
            "bucket": "cloudforge-state",
            "prefix": "cloudforge/{zone_id}",
        },
    },
    "oci": {
        "type": "http",
        "init_cmd": "terraform init -backend-config=backend.hcl",
        "config": {
            "address": "https://objectstorage.{region}.oraclecloud.com/cloudforge/{zone_id}",
        },
    },
}


def get_backend_config(cloud_type: str, zone_id: str = "", region: str = "") -> Dict[str, Any]:
    """Return the resolved backend configuration for a CSP."""
    backend = _BACKENDS.get(cloud_type, _BACKENDS.get("aws_commercial", {}))
    result = {
        "type": backend.get("type", "local"),
        "init_cmd": backend.get("init_cmd", "terraform init"),
        "config": {},
    }
    for k, v in backend.get("config", {}).items():
        if isinstance(v, str):
            result["config"][k] = v.format(zone_id=zone_id, region=region)
        else:
            result["config"][k] = v
    return result


def render_backend_hcl(cloud_type: str, zone_id: str = "", region: str = "") -> str:
    """Render a backend.hcl file for terraform init -backend-config."""
    cfg = get_backend_config(cloud_type, zone_id, region)
    lines = [f"# CUI // SP-CTI\n# Backend: {cfg['type']}\n"]
    for k, v in cfg["config"].items():
        if isinstance(v, bool):
            lines.append(f'{k} = {str(v).lower()}')
        elif isinstance(v, str):
            lines.append(f'{k} = "{v}"')
        else:
            lines.append(f'{k} = {v}')
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CloudForge State Backend")
    parser.add_argument("--cloud-type", required=True)
    parser.add_argument("--zone-id", default="lz-default")
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.json:
        print(json.dumps(get_backend_config(args.cloud_type, args.zone_id, args.region), indent=2))
    else:
        print(render_backend_hcl(args.cloud_type, args.zone_id, args.region))
