# CUI // SP-CTI
"""Migration planner — generate migration plans (phased/big-bang/trickle)."""

import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

STRATEGIES = {
    "phased": {
        "description": "Multi-phase migration with validation between phases",
        "phases": ["Discover", "Assess", "Pilot", "Migrate", "Optimize"],
        "risk": "low",
        "downtime": "minimal per phase",
    },
    "big_bang": {
        "description": "Full cutover in a single maintenance window",
        "phases": ["Prepare", "Cutover", "Validate"],
        "risk": "high",
        "downtime": "significant (hours to days)",
    },
    "trickle": {
        "description": "Gradual workload migration over extended period",
        "phases": ["Setup", "Trickle", "Monitor", "Complete"],
        "risk": "low",
        "downtime": "none (dual-running)",
    },
    "replatform": {
        "description": "Migrate and modernize (containers, serverless)",
        "phases": ["Assess", "Refactor", "Migrate", "Validate", "Optimize"],
        "risk": "medium",
        "downtime": "varies",
    },
    "hybrid": {
        "description": "Maintain workloads across clouds with data sync",
        "phases": ["Connect", "Sync", "Balance", "Monitor"],
        "risk": "medium",
        "downtime": "none",
    },
}


def generate_plan(
    assessment_id: str,
    strategy: str = "phased",
    workloads: List[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Generate a migration plan based on strategy and workload inventory."""
    strategy_info = STRATEGIES.get(strategy, STRATEGIES["phased"])
    wl = workloads or []

    phases = []
    for i, phase_name in enumerate(strategy_info["phases"], 1):
        phase_workloads = [
            w for w in wl if w.get("migration_phase", 1) == i
        ]
        phases.append({
            "phase_number": i,
            "name": phase_name,
            "workload_count": len(phase_workloads),
            "workloads": [w.get("name", "") for w in phase_workloads],
        })

    return {
        "status": "ok",
        "assessment_id": assessment_id,
        "strategy": strategy,
        "strategy_description": strategy_info["description"],
        "risk_level": strategy_info["risk"],
        "expected_downtime": strategy_info["downtime"],
        "phase_count": len(phases),
        "phases": phases,
        "total_workloads": len(wl),
        "classification": "CUI // SP-CTI",
    }


def list_strategies() -> List[Dict[str, Any]]:
    """List available migration strategies."""
    return [{"id": k, **v} for k, v in STRATEGIES.items()]


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Migration Planner")
    parser.add_argument("--plan", help="Assessment ID")
    parser.add_argument("--strategy", default="phased")
    parser.add_argument("--strategies", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.strategies:
        print(json.dumps(list_strategies(), indent=2))
    elif args.plan:
        print(json.dumps(generate_plan(args.plan, args.strategy), indent=2))
    else:
        parser.print_help()
