# CUI // SP-CTI
"""Per-workload risk scorer — deterministic risk calculation (D-CF-7)."""

import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Risk factors and their weights
RISK_FACTORS = {
    "data_volume": {"weight": 0.20, "threshold_gb": 100},
    "dependency_count": {"weight": 0.20, "threshold": 5},
    "cross_il_migration": {"weight": 0.25, "description": "Crossing IL boundaries"},
    "stateful": {"weight": 0.15, "description": "Stateful vs stateless"},
    "custom_integrations": {"weight": 0.10, "description": "Custom API/SDK integrations"},
    "regulatory_sensitivity": {"weight": 0.10, "description": "PHI/PII/CUI data present"},
}


def score_workload_risk(
    workload_type: str,
    data_volume_gb: float = 0.0,
    dependency_count: int = 0,
    cross_il: bool = False,
    stateful: bool = True,
    custom_integrations: int = 0,
    regulatory_data: bool = False,
) -> Dict[str, Any]:
    """Calculate a deterministic risk score for a workload."""
    scores = {}

    # Data volume risk (normalized 0-1)
    threshold = RISK_FACTORS["data_volume"]["threshold_gb"]
    scores["data_volume"] = min(1.0, data_volume_gb / threshold)

    # Dependency risk
    dep_threshold = RISK_FACTORS["dependency_count"]["threshold"]
    scores["dependency_count"] = min(1.0, dependency_count / dep_threshold)

    # Cross-IL risk (binary)
    scores["cross_il_migration"] = 1.0 if cross_il else 0.0

    # Stateful risk
    scores["stateful"] = 0.8 if stateful else 0.1

    # Custom integrations
    scores["custom_integrations"] = min(1.0, custom_integrations / 5)

    # Regulatory sensitivity
    scores["regulatory_sensitivity"] = 0.9 if regulatory_data else 0.1

    # Weighted total
    total = sum(
        scores[k] * RISK_FACTORS[k]["weight"]
        for k in scores
    )
    total = round(total, 4)

    risk_level = (
        "critical" if total >= 0.8
        else "high" if total >= 0.6
        else "medium" if total >= 0.3
        else "low"
    )

    return {
        "risk_score": total,
        "risk_level": risk_level,
        "workload_type": workload_type,
        "factor_scores": {k: round(v, 4) for k, v in scores.items()},
        "recommendation": (
            "Block migration — risk too high" if total >= 0.9
            else "Proceed with extra validation" if total >= 0.6
            else "Proceed with standard validation" if total >= 0.3
            else "Low risk — proceed"
        ),
        "classification": "CUI // SP-CTI",
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Workload Risk Scorer")
    parser.add_argument("--type", default="application")
    parser.add_argument("--data-gb", type=float, default=10.0)
    parser.add_argument("--deps", type=int, default=2)
    parser.add_argument("--cross-il", action="store_true")
    parser.add_argument("--stateful", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    result = score_workload_risk(
        args.type, args.data_gb, args.deps,
        args.cross_il, args.stateful,
    )
    print(json.dumps(result, indent=2))
