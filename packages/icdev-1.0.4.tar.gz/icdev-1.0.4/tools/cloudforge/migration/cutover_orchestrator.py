# CUI // SP-CTI
"""Cutover orchestrator — execute migration phases with DataBridge."""

import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def execute_phase(assessment_id: str, phase_number: int) -> Dict[str, Any]:
    """Execute a migration phase — move workloads assigned to this phase."""
    start = time.time()
    conn = _get_db()

    try:
        workloads = conn.execute(
            """SELECT id, name, workload_type, data_volume_gb, databridge_sync_id
               FROM cf_migration_workloads
               WHERE assessment_id = ? AND migration_phase = ? AND status = 'pending'""",
            (assessment_id, phase_number),
        ).fetchall()

        migrated = []
        for wl in workloads:
            # Update status to migrating
            conn.execute(
                "UPDATE cf_migration_workloads SET status = 'migrating', updated_at = datetime('now') WHERE id = ?",
                (wl["id"],),
            )

            # In production: delegate data movement to DataBridge sync engine
            # from tools.databridge.sync_engine import sync_read, sync_write

            # Mark as validating
            conn.execute(
                "UPDATE cf_migration_workloads SET status = 'validating', updated_at = datetime('now') WHERE id = ?",
                (wl["id"],),
            )

            # Mark as completed
            conn.execute(
                "UPDATE cf_migration_workloads SET status = 'completed', updated_at = datetime('now') WHERE id = ?",
                (wl["id"],),
            )

            migrated.append({"id": wl["id"], "name": wl["name"], "status": "completed"})

        conn.commit()
        duration_ms = int((time.time() - start) * 1000)

        return {
            "status": "ok",
            "assessment_id": assessment_id,
            "phase_number": phase_number,
            "workloads_migrated": len(migrated),
            "workloads": migrated,
            "duration_ms": duration_ms,
            "classification": "CUI // SP-CTI",
        }
    finally:
        conn.close()


def rollback_phase(assessment_id: str, phase_number: int) -> Dict[str, Any]:
    """Rollback all workloads in a phase."""
    conn = _get_db()
    try:
        conn.execute(
            """UPDATE cf_migration_workloads
               SET status = 'rolled_back', updated_at = datetime('now')
               WHERE assessment_id = ? AND migration_phase = ?
               AND status IN ('migrating', 'validating', 'completed')""",
            (assessment_id, phase_number),
        )
        affected = conn.total_changes
        conn.commit()
        return {
            "status": "ok",
            "assessment_id": assessment_id,
            "phase_number": phase_number,
            "workloads_rolled_back": affected,
        }
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Cutover Orchestrator")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--rollback", action="store_true")
    parser.add_argument("--assessment-id", required=True)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.execute:
        result = execute_phase(args.assessment_id, args.phase)
    elif args.rollback:
        result = rollback_phase(args.assessment_id, args.phase)
    else:
        parser.print_help()
        exit(0)
    print(json.dumps(result, indent=2))
