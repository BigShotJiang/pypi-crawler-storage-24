# CUI // SP-CTI
"""Migration assessor — 7-dimension readiness scoring (D-CF-7, D-CF-12).

Scores migration readiness across: complexity, risk, data volume,
dependencies, compliance, cost, and timeline. Deterministic (no LLM).
"""

import json
import logging
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"

# 7 assessment dimensions with weights
DIMENSIONS = {
    "complexity": {"weight": 0.20, "description": "Architecture complexity"},
    "risk": {"weight": 0.20, "description": "Migration risk factors"},
    "data_volume": {"weight": 0.15, "description": "Data volume and transfer time"},
    "dependencies": {"weight": 0.15, "description": "Cross-system dependencies"},
    "compliance": {"weight": 0.15, "description": "Compliance requirements delta"},
    "cost": {"weight": 0.10, "description": "Cost impact and TCO change"},
    "timeline": {"weight": 0.05, "description": "Timeline constraints"},
}


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def create_assessment(
    name: str,
    source_cloud: str,
    target_cloud: str,
    strategy: str = "phased",
    tenant_id: str = "default",
    project_id: str = "",
    created_by: str = "cloudforge",
) -> Dict[str, Any]:
    """Create a new migration assessment."""
    assessment_id = f"mig-{uuid.uuid4().hex[:8]}"
    conn = _get_db()
    try:
        conn.execute(
            """INSERT INTO cf_migration_assessments
               (id, name, source_cloud, target_cloud, status, strategy,
                classification, tenant_id, project_id, created_by,
                created_at, updated_at)
               VALUES (?, ?, ?, ?, 'draft', ?, 'CUI // SP-CTI', ?, ?, ?,
                       datetime('now'), datetime('now'))""",
            (assessment_id, name, source_cloud, target_cloud, strategy,
             tenant_id, project_id, created_by),
        )
        conn.commit()
        return {
            "status": "ok",
            "assessment_id": assessment_id,
            "name": name,
            "source_cloud": source_cloud,
            "target_cloud": target_cloud,
            "strategy": strategy,
        }
    finally:
        conn.close()


def score_readiness(
    assessment_id: str,
    dimension_scores: Dict[str, float] = None,
) -> Dict[str, Any]:
    """Calculate weighted readiness score across 7 dimensions.

    Each dimension is scored 0.0-1.0. Overall score is weighted average.
    """
    scores = dimension_scores or {d: 0.5 for d in DIMENSIONS}

    weighted_scores = {}
    total = 0.0
    for dim, config in DIMENSIONS.items():
        raw = scores.get(dim, 0.5)
        weighted = raw * config["weight"]
        weighted_scores[dim] = {
            "raw_score": raw,
            "weight": config["weight"],
            "weighted_score": round(weighted, 4),
            "description": config["description"],
        }
        total += weighted

    overall = round(total, 4)
    risk_level = (
        "low" if overall >= 0.7
        else "medium" if overall >= 0.4
        else "high"
    )

    # Update DB
    conn = _get_db()
    try:
        conn.execute(
            """UPDATE cf_migration_assessments
               SET overall_risk_score = ?, overall_complexity_score = ?,
                   status = 'assessing', updated_at = datetime('now')
               WHERE id = ?""",
            (1.0 - overall, scores.get("complexity", 0.5), assessment_id),
        )
        conn.commit()
    except Exception:
        pass
    finally:
        conn.close()

    return {
        "status": "ok",
        "assessment_id": assessment_id,
        "overall_readiness": overall,
        "risk_level": risk_level,
        "dimensions": weighted_scores,
        "recommendation": (
            "Ready for migration" if overall >= 0.7
            else "Proceed with caution — mitigate risks first" if overall >= 0.4
            else "Not recommended — significant risks identified"
        ),
        "classification": "CUI // SP-CTI",
    }


def get_assessment(assessment_id: str) -> Dict[str, Any]:
    """Get a migration assessment by ID."""
    conn = _get_db()
    try:
        row = conn.execute(
            "SELECT * FROM cf_migration_assessments WHERE id = ?",
            (assessment_id,),
        ).fetchone()
        return dict(row) if row else {"status": "error", "message": "Not found"}
    finally:
        conn.close()


def list_assessments(tenant_id: str = "default") -> List[Dict[str, Any]]:
    """List all migration assessments for a tenant."""
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT id, name, source_cloud, target_cloud, status,
                      strategy, overall_risk_score, workload_count, created_at
               FROM cf_migration_assessments WHERE tenant_id = ?
               ORDER BY created_at DESC""",
            (tenant_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Migration Assessor")
    parser.add_argument("--create", action="store_true")
    parser.add_argument("--score", help="Assessment ID to score")
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--name", default="Migration Assessment")
    parser.add_argument("--source", default="aws_commercial")
    parser.add_argument("--target", default="aws_govcloud")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.create:
        result = create_assessment(args.name, args.source, args.target)
    elif args.score:
        result = score_readiness(args.score)
    elif args.list:
        result = list_assessments()
    else:
        parser.print_help()
        exit(0)
    print(json.dumps(result, indent=2, default=str))
