# CUI // SP-CTI
"""Workload inventory — discover and inventory workloads for migration."""

import json
import logging
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"

WORKLOAD_TYPES = [
    "vm", "container", "database", "storage", "serverless",
    "network", "identity", "application", "data_pipeline",
]


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def add_workload(
    assessment_id: str,
    name: str,
    workload_type: str,
    data_volume_gb: float = 0.0,
    dependencies: List[str] = None,
    migration_phase: int = 1,
) -> Dict[str, Any]:
    """Add a workload to a migration assessment."""
    wl_id = f"wl-{uuid.uuid4().hex[:8]}"
    conn = _get_db()
    try:
        conn.execute(
            """INSERT INTO cf_migration_workloads
               (id, assessment_id, name, workload_type, data_volume_gb,
                dependencies_json, migration_phase, status,
                classification, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', 'CUI // SP-CTI',
                       datetime('now'), datetime('now'))""",
            (wl_id, assessment_id, name, workload_type, data_volume_gb,
             json.dumps(dependencies or []), migration_phase),
        )
        # Update assessment workload count
        conn.execute(
            """UPDATE cf_migration_assessments
               SET workload_count = workload_count + 1,
                   total_data_volume_gb = total_data_volume_gb + ?,
                   updated_at = datetime('now')
               WHERE id = ?""",
            (data_volume_gb, assessment_id),
        )
        conn.commit()
        return {
            "status": "ok",
            "workload_id": wl_id,
            "assessment_id": assessment_id,
            "name": name,
            "type": workload_type,
        }
    finally:
        conn.close()


def list_workloads(assessment_id: str) -> List[Dict[str, Any]]:
    """List all workloads for an assessment."""
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT id, name, workload_type, data_volume_gb, risk_score,
                      complexity_score, migration_phase, status
               FROM cf_migration_workloads WHERE assessment_id = ?
               ORDER BY migration_phase, name""",
            (assessment_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Workload Inventory")
    parser.add_argument("--add", action="store_true")
    parser.add_argument("--list", help="Assessment ID")
    parser.add_argument("--assessment-id", default="")
    parser.add_argument("--name", default="workload")
    parser.add_argument("--type", default="application", choices=WORKLOAD_TYPES)
    parser.add_argument("--data-gb", type=float, default=0.0)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.add:
        result = add_workload(args.assessment_id, args.name, args.type, args.data_gb)
        print(json.dumps(result, indent=2))
    elif args.list:
        print(json.dumps(list_workloads(args.list), indent=2, default=str))
    else:
        parser.print_help()
