# CUI // SP-CTI
"""Runbook linker — associate applications with runbooks."""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def link_runbook(app_id: str, runbook_id: str) -> Dict[str, Any]:
    """Link a runbook to an application."""
    conn = _get_db()
    try:
        row = conn.execute("SELECT runbook_ids FROM cf_applications WHERE id = ?", (app_id,)).fetchone()
        if not row:
            return {"status": "error", "errors": ["App not found"]}

        current = row["runbook_ids"] or ""
        ids = [x.strip() for x in current.split(",") if x.strip()]
        if runbook_id not in ids:
            ids.append(runbook_id)

        conn.execute(
            "UPDATE cf_applications SET runbook_ids = ?, updated_at = datetime('now') WHERE id = ?",
            (",".join(ids), app_id),
        )
        conn.commit()
        return {"status": "ok", "app_id": app_id, "runbook_ids": ids}
    finally:
        conn.close()


def unlink_runbook(app_id: str, runbook_id: str) -> Dict[str, Any]:
    """Unlink a runbook from an application."""
    conn = _get_db()
    try:
        row = conn.execute("SELECT runbook_ids FROM cf_applications WHERE id = ?", (app_id,)).fetchone()
        if not row:
            return {"status": "error", "errors": ["App not found"]}

        current = row["runbook_ids"] or ""
        ids = [x.strip() for x in current.split(",") if x.strip() and x.strip() != runbook_id]

        conn.execute(
            "UPDATE cf_applications SET runbook_ids = ?, updated_at = datetime('now') WHERE id = ?",
            (",".join(ids), app_id),
        )
        conn.commit()
        return {"status": "ok", "app_id": app_id, "runbook_ids": ids}
    finally:
        conn.close()


def get_app_runbooks(app_id: str) -> List[Dict[str, Any]]:
    """Get all runbooks linked to an application."""
    conn = _get_db()
    try:
        row = conn.execute("SELECT runbook_ids FROM cf_applications WHERE id = ?", (app_id,)).fetchone()
        if not row or not row["runbook_ids"]:
            return []

        ids = [x.strip() for x in row["runbook_ids"].split(",") if x.strip()]
        runbooks = []
        for rid in ids:
            rb = conn.execute("SELECT id, name, status, description FROM cf_runbooks WHERE id = ?", (rid,)).fetchone()
            if rb:
                runbooks.append(dict(rb))
        return runbooks
    finally:
        conn.close()
