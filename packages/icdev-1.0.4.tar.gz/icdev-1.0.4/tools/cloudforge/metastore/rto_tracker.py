# CUI // SP-CTI
"""RTO/RPO compliance tracker — check applications against recovery objectives.

Design decision D-CF-27: RTO/RPO stored as hours (REAL) on cf_applications.
"""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


# Default thresholds by criticality
DEFAULT_THRESHOLDS = {
    "critical": {"rto_hours": 1.0, "rpo_hours": 0.25},
    "high": {"rto_hours": 4.0, "rpo_hours": 1.0},
    "medium": {"rto_hours": 24.0, "rpo_hours": 4.0},
    "low": {"rto_hours": 72.0, "rpo_hours": 24.0},
}


def check_rto_compliance(
    tenant_id: str = "default",
    thresholds: Optional[Dict[str, Dict[str, float]]] = None,
) -> Dict[str, Any]:
    """Check all active applications against RTO/RPO thresholds."""
    limits = thresholds or DEFAULT_THRESHOLDS
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT id, name, app_type, criticality, rto_hours, rpo_hours, environment
               FROM cf_applications
               WHERE tenant_id = ? AND status = 'active'
               ORDER BY criticality DESC""",
            (tenant_id,),
        ).fetchall()

        compliant = []
        non_compliant = []
        undefined = []

        for row in rows:
            app = dict(row)
            crit = app["criticality"]
            limit = limits.get(crit, limits.get("medium", {}))

            rto = app.get("rto_hours")
            rpo = app.get("rpo_hours")

            if rto is None and rpo is None:
                app["rto_status"] = "undefined"
                app["rpo_status"] = "undefined"
                undefined.append(app)
                continue

            rto_ok = rto is not None and rto <= limit.get("rto_hours", 999)
            rpo_ok = rpo is not None and rpo <= limit.get("rpo_hours", 999)
            app["rto_status"] = "compliant" if rto_ok else "non_compliant"
            app["rpo_status"] = "compliant" if rpo_ok else "non_compliant"
            app["rto_limit"] = limit.get("rto_hours")
            app["rpo_limit"] = limit.get("rpo_hours")

            if rto_ok and rpo_ok:
                compliant.append(app)
            else:
                non_compliant.append(app)

        return {
            "status": "ok",
            "compliant_count": len(compliant),
            "non_compliant_count": len(non_compliant),
            "undefined_count": len(undefined),
            "total": len(rows),
            "compliant": compliant,
            "non_compliant": non_compliant,
            "undefined": undefined,
            "classification": "CUI // SP-CTI",
        }
    finally:
        conn.close()
