# CUI // SP-CTI
"""Auto-discovery — discover applications from existing CloudForge and DataBridge data.

Design decision D-CF-24: Idempotent upsert on unique constraint.
Pulls from: db_connections, cf_landing_zones, devices.
"""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any, Dict, List
from tools.db.storage import get_connection

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def discover_from_zones(tenant_id: str = "default") -> List[Dict[str, Any]]:
    """Discover applications from cf_landing_zones."""
    conn = get_connection()
    discovered = []
    try:
        rows = conn.execute(
            "SELECT id, name, cloud_type, impact_level, environment, status FROM cf_landing_zones WHERE status = 'active'"
        ).fetchall()
        for row in rows:
            env = row["environment"] if row["environment"] else "production"
            result = _upsert_discovered_app(
                conn=conn,
                name=f"zone-{row['name']}",
                app_type="monolith",
                description=f"Landing zone: {row['name']} ({row['cloud_type']}, {row['impact_level']})",
                environment=env,
                zone_ids=row["id"],
                discovery_source="cf_landing_zones",
                tenant_id=tenant_id,
            )
            discovered.append(result)
        conn.commit()
    except Exception as exc:
        logger.warning("Zone discovery failed: %s", exc)
    finally:
        conn.close()
    return discovered


def discover_from_connections(tenant_id: str = "default") -> List[Dict[str, Any]]:
    """Discover applications from db_connections (DataBridge)."""
    conn = get_connection()
    discovered = []
    try:
        rows = conn.execute(
            "SELECT id, name, connector_type, status FROM db_connections WHERE status = 'active'"
        ).fetchall()
        for row in rows:
            app_type = _infer_app_type(row["connector_type"])
            result = _upsert_discovered_app(
                conn=conn,
                name=f"db-{row['name']}",
                app_type=app_type,
                description=f"DataBridge connection: {row['name']} ({row['connector_type']})",
                connection_ids=row["id"],
                discovery_source="db_connections",
                tenant_id=tenant_id,
            )
            discovered.append(result)
        conn.commit()
    except Exception as exc:
        logger.warning("Connection discovery failed: %s", exc)
    finally:
        conn.close()
    return discovered


def discover_from_devices(tenant_id: str = "default") -> List[Dict[str, Any]]:
    """Discover applications from devices table (SparkPilot fleet)."""
    conn = get_connection()
    discovered = []
    try:
        # devices table is in sparkpilot.db — check if accessible
        sp_db = BASE_DIR / "data" / "sparkpilot.db"
        if not sp_db.exists():
            return []
        sp_conn = sqlite3.connect(str(sp_db))
        sp_conn.row_factory = sqlite3.Row
        rows = sp_conn.execute(
            "SELECT device_id, name, board, status FROM devices WHERE status = 'online'"
        ).fetchall()
        sp_conn.close()

        for row in rows:
            result = _upsert_discovered_app(
                conn=conn,
                name=f"device-{row['name']}",
                app_type="firmware",
                description=f"Fleet device: {row['name']} ({row['board']})",
                device_ids=row["device_id"],
                discovery_source="devices",
                tenant_id=tenant_id,
            )
            discovered.append(result)
        conn.commit()
    except Exception as exc:
        logger.warning("Device discovery failed: %s", exc)
    finally:
        conn.close()
    return discovered


def run_full_discovery(tenant_id: str = "default") -> Dict[str, Any]:
    """Run all three discovery sources."""
    zones = discover_from_zones(tenant_id)
    connections = discover_from_connections(tenant_id)
    devices = discover_from_devices(tenant_id)

    return {
        "status": "ok",
        "zones_discovered": len(zones),
        "connections_discovered": len(connections),
        "devices_discovered": len(devices),
        "total": len(zones) + len(connections) + len(devices),
        "classification": "CUI // SP-CTI",
    }


def _upsert_discovered_app(
    conn: sqlite3.Connection,
    name: str,
    app_type: str,
    description: str = "",
    environment: str = "production",
    zone_ids: str = "",
    device_ids: str = "",
    connection_ids: str = "",
    discovery_source: str = "",
    tenant_id: str = "default",
) -> Dict[str, Any]:
    """Insert or update a discovered application (idempotent on name+environment)."""
    import uuid

    existing = conn.execute(
        "SELECT id FROM cf_applications WHERE tenant_id = ? AND name = ? AND environment = ?",
        (tenant_id, name, environment),
    ).fetchone()

    if existing:
        conn.execute(
            """UPDATE cf_applications SET description = ?, zone_ids = ?,
               device_ids = ?, connection_ids = ?, discovery_source = ?,
               updated_at = datetime('now') WHERE id = ?""",
            (description, zone_ids, device_ids, connection_ids, discovery_source, existing["id"]),
        )
        return {"id": existing["id"], "name": name, "action": "updated"}

    app_id = f"app-{uuid.uuid4().hex[:8]}"
    conn.execute(
        """INSERT INTO cf_applications
           (id, name, description, app_type, status, environment,
            zone_ids, device_ids, connection_ids, discovery_source,
            classification, tenant_id, created_by,
            created_at, updated_at)
           VALUES (?, ?, ?, ?, 'discovered', ?, ?, ?, ?, ?,
                   'CUI // SP-CTI', ?, 'auto-discovery',
                   datetime('now'), datetime('now'))""",
        (
            app_id, name, description, app_type, environment,
            zone_ids, device_ids, connection_ids, discovery_source, tenant_id,
        ),
    )
    return {"id": app_id, "name": name, "action": "created"}


def _infer_app_type(connector_type: str) -> str:
    """Infer app_type from DataBridge connector type."""
    db_types = {"postgresql", "mysql", "sqlite", "oracle", "mssql", "dynamodb", "mongodb"}
    queue_types = {"kafka", "rabbitmq", "sqs", "kinesis"}
    cache_types = {"redis", "memcached", "elasticache"}
    api_types = {"rest_api", "graphql", "grpc"}

    ct = connector_type.lower()
    if ct in db_types:
        return "database"
    elif ct in queue_types:
        return "queue"
    elif ct in cache_types:
        return "cache"
    elif ct in api_types:
        return "api"
    return "other"
