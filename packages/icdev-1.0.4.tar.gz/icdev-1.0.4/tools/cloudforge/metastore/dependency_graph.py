# CUI // SP-CTI
"""Dependency graph — adjacency list for application dependencies.

Design decision D-CF-23: Adjacency list pattern (same as D27, D-CF-13).
Cycle detection via DFS to prevent circular dependencies.
"""

import json
import logging
import sqlite3
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def add_dependency(
    source_app_id: str,
    target_app_id: str,
    dependency_type: str,
    protocol: str = "",
    port: Optional[int] = None,
    description: str = "",
    tenant_id: str = "default",
) -> Dict[str, Any]:
    """Add a dependency edge between two applications."""
    if source_app_id == target_app_id:
        return {"status": "error", "errors": ["Self-dependency not allowed"]}

    conn = _get_db()
    try:
        # Verify both apps exist
        for app_id in (source_app_id, target_app_id):
            row = conn.execute("SELECT id FROM cf_applications WHERE id = ?", (app_id,)).fetchone()
            if not row:
                return {"status": "error", "errors": [f"App not found: {app_id}"]}

        # Check for cycles before inserting
        if _would_create_cycle(conn, source_app_id, target_app_id, tenant_id):
            return {"status": "error", "errors": ["Would create circular dependency"]}

        conn.execute(
            """INSERT INTO cf_app_dependencies
               (source_app_id, target_app_id, dependency_type,
                protocol, port, description, classification,
                tenant_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, 'CUI // SP-CTI', ?, datetime('now'))""",
            (source_app_id, target_app_id, dependency_type,
             protocol, port, description, tenant_id),
        )
        conn.commit()
        return {
            "status": "ok",
            "source": source_app_id,
            "target": target_app_id,
            "type": dependency_type,
        }
    except sqlite3.IntegrityError:
        return {"status": "error", "errors": ["Dependency already exists"]}
    finally:
        conn.close()


def get_dependencies(
    app_id: str,
    direction: str = "both",
    tenant_id: str = "default",
) -> Dict[str, Any]:
    """Get dependencies for an app. direction: upstream, downstream, both."""
    conn = _get_db()
    try:
        upstream = []
        downstream = []

        if direction in ("upstream", "both"):
            rows = conn.execute(
                """SELECT d.*, a.name as source_name
                   FROM cf_app_dependencies d
                   JOIN cf_applications a ON a.id = d.source_app_id
                   WHERE d.target_app_id = ? AND d.tenant_id = ?""",
                (app_id, tenant_id),
            ).fetchall()
            upstream = [dict(r) for r in rows]

        if direction in ("downstream", "both"):
            rows = conn.execute(
                """SELECT d.*, a.name as target_name
                   FROM cf_app_dependencies d
                   JOIN cf_applications a ON a.id = d.target_app_id
                   WHERE d.source_app_id = ? AND d.tenant_id = ?""",
                (app_id, tenant_id),
            ).fetchall()
            downstream = [dict(r) for r in rows]

        return {
            "app_id": app_id,
            "upstream": upstream,
            "downstream": downstream,
            "upstream_count": len(upstream),
            "downstream_count": len(downstream),
        }
    finally:
        conn.close()


def get_full_graph(tenant_id: str = "default") -> Dict[str, Any]:
    """Export the full dependency graph as nodes + edges for visualization."""
    conn = _get_db()
    try:
        apps = conn.execute(
            "SELECT id, name, app_type, status, criticality FROM cf_applications WHERE tenant_id = ?",
            (tenant_id,),
        ).fetchall()

        deps = conn.execute(
            "SELECT source_app_id, target_app_id, dependency_type, protocol FROM cf_app_dependencies WHERE tenant_id = ?",
            (tenant_id,),
        ).fetchall()

        nodes = [
            {
                "id": a["id"],
                "name": a["name"],
                "type": a["app_type"],
                "status": a["status"],
                "criticality": a["criticality"],
            }
            for a in apps
        ]
        edges = [
            {
                "source": d["source_app_id"],
                "target": d["target_app_id"],
                "type": d["dependency_type"],
                "protocol": d["protocol"],
            }
            for d in deps
        ]

        return {
            "nodes": nodes,
            "edges": edges,
            "node_count": len(nodes),
            "edge_count": len(edges),
            "classification": "CUI // SP-CTI",
        }
    finally:
        conn.close()


def remove_dependency(
    source_app_id: str,
    target_app_id: str,
    dependency_type: str,
) -> Dict[str, Any]:
    """Remove a specific dependency edge."""
    conn = _get_db()
    try:
        conn.execute(
            """DELETE FROM cf_app_dependencies
               WHERE source_app_id = ? AND target_app_id = ? AND dependency_type = ?""",
            (source_app_id, target_app_id, dependency_type),
        )
        conn.commit()
        return {"status": "ok", "action": "removed"}
    finally:
        conn.close()


def _would_create_cycle(
    conn: sqlite3.Connection,
    source: str,
    target: str,
    tenant_id: str,
) -> bool:
    """Check if adding source->target would create a cycle via DFS."""
    # If there's a path from target back to source, adding source->target creates a cycle
    visited: Set[str] = set()

    def dfs(node: str) -> bool:
        if node == source:
            return True
        if node in visited:
            return False
        visited.add(node)
        rows = conn.execute(
            "SELECT target_app_id FROM cf_app_dependencies WHERE source_app_id = ? AND tenant_id = ?",
            (node, tenant_id),
        ).fetchall()
        return any(dfs(r["target_app_id"]) for r in rows)

    return dfs(target)
