# CUI // SP-CTI
"""Application registry — CRUD for the Application Metastore.

Design decisions:
- D-CF-23: Applications stored in cf_applications
- D-CF-27: RTO/RPO stored as hours (REAL)
"""

import json
import logging
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def register_app(
    name: str,
    app_type: str,
    description: str = "",
    environment: str = "production",
    rto_hours: Optional[float] = None,
    rpo_hours: Optional[float] = None,
    criticality: str = "medium",
    owner_team: str = "",
    owner_email: str = "",
    zone_ids: str = "",
    device_ids: str = "",
    connection_ids: str = "",
    metadata_json: str = "",
    discovery_source: str = "",
    tags: str = "",
    tenant_id: str = "default",
    project_id: str = "",
    created_by: str = "cloudforge",
) -> Dict[str, Any]:
    """Register a new application in the metastore."""
    app_id = f"app-{uuid.uuid4().hex[:8]}"
    conn = _get_db()
    try:
        conn.execute(
            """INSERT INTO cf_applications
               (id, name, description, app_type, status, environment,
                rto_hours, rpo_hours, criticality, owner_team, owner_email,
                zone_ids, device_ids, connection_ids, metadata_json,
                discovery_source, tags, classification,
                tenant_id, project_id, created_by,
                created_at, updated_at)
               VALUES (?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                       'CUI // SP-CTI', ?, ?, ?, datetime('now'), datetime('now'))""",
            (
                app_id, name, description, app_type, environment,
                rto_hours, rpo_hours, criticality, owner_team, owner_email,
                zone_ids, device_ids, connection_ids, metadata_json,
                discovery_source, tags, tenant_id, project_id, created_by,
            ),
        )
        conn.commit()
        return {
            "status": "ok",
            "id": app_id,
            "name": name,
            "app_type": app_type,
            "classification": "CUI // SP-CTI",
        }
    except sqlite3.IntegrityError as exc:
        return {"status": "error", "errors": [str(exc)], "classification": "CUI // SP-CTI"}
    finally:
        conn.close()


def list_apps(
    tenant_id: str = "default",
    status: Optional[str] = None,
    environment: Optional[str] = None,
    criticality: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """List applications with optional filters."""
    conn = _get_db()
    try:
        query = "SELECT * FROM cf_applications WHERE tenant_id = ?"
        params: list = [tenant_id]
        if status:
            query += " AND status = ?"
            params.append(status)
        if environment:
            query += " AND environment = ?"
            params.append(environment)
        if criticality:
            query += " AND criticality = ?"
            params.append(criticality)
        query += " ORDER BY criticality DESC, name ASC"
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_app(app_id: str) -> Optional[Dict[str, Any]]:
    """Get a single application by ID."""
    conn = _get_db()
    try:
        row = conn.execute(
            "SELECT * FROM cf_applications WHERE id = ?", (app_id,)
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def update_app(app_id: str, **kwargs) -> Dict[str, Any]:
    """Update application fields."""
    allowed = {
        "name", "description", "app_type", "status", "environment",
        "rto_hours", "rpo_hours", "criticality", "owner_team", "owner_email",
        "zone_ids", "device_ids", "connection_ids", "runbook_ids",
        "metadata_json", "tags",
    }
    updates = {k: v for k, v in kwargs.items() if k in allowed and v is not None}
    if not updates:
        return {"status": "error", "errors": ["No valid fields to update"]}

    set_clause = ", ".join(f"{k} = ?" for k in updates)
    values = list(updates.values()) + [app_id]

    conn = _get_db()
    try:
        conn.execute(
            f"UPDATE cf_applications SET {set_clause}, updated_at = datetime('now') WHERE id = ?",
            values,
        )
        conn.commit()
        return {"status": "ok", "id": app_id, "updated_fields": list(updates.keys())}
    finally:
        conn.close()


def deregister_app(app_id: str) -> Dict[str, Any]:
    """Soft-deregister an application (set status to 'decommissioned')."""
    conn = _get_db()
    try:
        conn.execute(
            "UPDATE cf_applications SET status = 'decommissioned', updated_at = datetime('now') WHERE id = ?",
            (app_id,),
        )
        conn.commit()
        return {"status": "ok", "id": app_id, "new_status": "decommissioned"}
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CloudForge Application Metastore")
    parser.add_argument("--list", action="store_true", help="List applications")
    parser.add_argument("--get", help="Get app by ID")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    if args.list:
        results = list_apps()
        if args.json:
            print(json.dumps(results, indent=2))
        else:
            print(f"Applications: {len(results)}")
            for a in results:
                print(f"  {a['id']}: {a['name']} ({a['app_type']}, {a['criticality']})")
    elif args.get:
        app = get_app(args.get)
        print(json.dumps(app, indent=2) if app else "Not found")
    else:
        results = list_apps()
        print(json.dumps(results, indent=2) if args.json else f"Applications: {len(results)}")
