# CUI // SP-CTI
"""CloudForge Application Metastore — CMDB-like registry with dependency mapping."""
