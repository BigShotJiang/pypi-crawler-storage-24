# CUI // SP-CTI
"""Cost anomaly detector — z-score based spike detection."""

import json
import logging
import math
import sqlite3
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"

DEFAULT_Z_THRESHOLD = 2.5


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def detect_anomalies(zone_id: str = "", z_threshold: float = DEFAULT_Z_THRESHOLD) -> List[Dict[str, Any]]:
    """Detect cost anomalies using z-score analysis."""
    conn = _get_db()
    try:
        if zone_id:
            rows = conn.execute(
                """SELECT service_name, cost_usd, period_start
                   FROM cf_cost_records WHERE zone_id = ?
                   ORDER BY period_start""",
                (zone_id,),
            ).fetchall()
        else:
            rows = conn.execute(
                """SELECT service_name, cost_usd, period_start
                   FROM cf_cost_records ORDER BY period_start""",
            ).fetchall()

        if len(rows) < 3:
            return []

        costs = [r["cost_usd"] for r in rows]
        mean = sum(costs) / len(costs)
        variance = sum((c - mean) ** 2 for c in costs) / len(costs)
        std = math.sqrt(variance) if variance > 0 else 1.0

        anomalies = []
        for r in rows:
            z = (r["cost_usd"] - mean) / std if std > 0 else 0
            if abs(z) >= z_threshold:
                anomalies.append({
                    "service": r["service_name"],
                    "cost_usd": r["cost_usd"],
                    "period": r["period_start"],
                    "z_score": round(z, 2),
                    "mean_cost": round(mean, 2),
                    "std_dev": round(std, 2),
                    "anomaly_type": "spike" if z > 0 else "drop",
                })

        return anomalies
    except Exception:
        return []
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Cost Anomaly Detector")
    parser.add_argument("--zone-id", default="")
    parser.add_argument("--threshold", type=float, default=DEFAULT_Z_THRESHOLD)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    print(json.dumps(detect_anomalies(args.zone_id, args.threshold), indent=2))
