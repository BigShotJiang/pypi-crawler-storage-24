# CUI // SP-CTI
"""Cost collector — fetch billing data via DataBridge SaaS connectors (D-CF-11)."""

import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def collect_costs(
    zone_id: str,
    cloud_type: str,
    period_start: str = "",
    period_end: str = "",
) -> Dict[str, Any]:
    """Collect cost data for a landing zone.

    In production: uses DataBridge SaaS connectors for AWS Cost Explorer,
    Azure Cost Management, GCP Billing, OCI Cost Management.
    """
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    period_start = period_start or now
    period_end = period_end or now

    # Simulated cost data (real impl: DataBridge SaaS connector)
    services = _simulate_costs(cloud_type)

    conn = _get_db()
    try:
        for svc in services:
            conn.execute(
                """INSERT INTO cf_cost_records
                   (zone_id, cloud_type, service_name, cost_usd,
                    usage_quantity, usage_unit, period_start, period_end,
                    classification, collected_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'CUI // SP-CTI', datetime('now'))""",
                (zone_id, cloud_type, svc["service"], svc["cost"],
                 svc["usage"], svc["unit"], period_start, period_end),
            )
        conn.commit()
    finally:
        conn.close()

    total = sum(s["cost"] for s in services)
    return {
        "status": "ok",
        "zone_id": zone_id,
        "cloud_type": cloud_type,
        "period": f"{period_start} to {period_end}",
        "total_cost_usd": round(total, 2),
        "service_count": len(services),
        "services": services,
        "classification": "CUI // SP-CTI",
    }


def _simulate_costs(cloud_type: str) -> List[Dict[str, Any]]:
    """Generate simulated cost data for demo."""
    base_costs = {
        "aws": [
            {"service": "EC2", "cost": 450.0, "usage": 720, "unit": "hours"},
            {"service": "S3", "cost": 25.0, "usage": 500, "unit": "GB"},
            {"service": "RDS", "cost": 200.0, "usage": 720, "unit": "hours"},
            {"service": "EKS", "cost": 146.0, "usage": 2, "unit": "clusters"},
        ],
        "azure": [
            {"service": "Virtual Machines", "cost": 480.0, "usage": 720, "unit": "hours"},
            {"service": "Blob Storage", "cost": 20.0, "usage": 400, "unit": "GB"},
            {"service": "SQL Database", "cost": 220.0, "usage": 720, "unit": "hours"},
            {"service": "AKS", "cost": 160.0, "usage": 2, "unit": "clusters"},
        ],
        "gcp": [
            {"service": "Compute Engine", "cost": 420.0, "usage": 720, "unit": "hours"},
            {"service": "Cloud Storage", "cost": 18.0, "usage": 350, "unit": "GB"},
            {"service": "Cloud SQL", "cost": 190.0, "usage": 720, "unit": "hours"},
            {"service": "GKE", "cost": 140.0, "usage": 2, "unit": "clusters"},
        ],
        "oci": [
            {"service": "Compute", "cost": 380.0, "usage": 720, "unit": "hours"},
            {"service": "Object Storage", "cost": 15.0, "usage": 300, "unit": "GB"},
            {"service": "DB System", "cost": 180.0, "usage": 720, "unit": "hours"},
            {"service": "OKE", "cost": 120.0, "usage": 2, "unit": "clusters"},
        ],
    }
    family = cloud_type.split("_")[0] if "_" in cloud_type else cloud_type
    return base_costs.get(family, base_costs["aws"])


def get_cost_summary(tenant_id: str = "default") -> Dict[str, Any]:
    """Get aggregated cost summary across all zones."""
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT cloud_type, SUM(cost_usd) as total,
                      COUNT(DISTINCT zone_id) as zone_count
               FROM cf_cost_records
               GROUP BY cloud_type""",
        ).fetchall()
        breakdown = [dict(r) for r in rows]
        grand_total = sum(r["total"] for r in breakdown)
        return {
            "status": "ok",
            "grand_total_usd": round(grand_total, 2),
            "by_cloud": breakdown,
            "classification": "CUI // SP-CTI",
        }
    except Exception:
        return {"status": "ok", "grand_total_usd": 0, "by_cloud": []}
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Cost Collector")
    parser.add_argument("--collect", action="store_true")
    parser.add_argument("--summary", action="store_true")
    parser.add_argument("--zone-id", default="lz-001")
    parser.add_argument("--cloud-type", default="aws_govcloud")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.collect:
        print(json.dumps(collect_costs(args.zone_id, args.cloud_type), indent=2))
    elif args.summary:
        print(json.dumps(get_cost_summary(), indent=2))
    else:
        parser.print_help()
