# CUI // SP-CTI
"""Budget tracker — multi-cloud budget monitoring and alerting."""

import json
import logging
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def create_budget(
    name: str,
    monthly_limit_usd: float,
    zone_id: str = "",
    alert_threshold_pct: float = 80.0,
    tenant_id: str = "default",
) -> Dict[str, Any]:
    """Create a budget."""
    budget_id = f"bgt-{uuid.uuid4().hex[:8]}"
    period = __import__("datetime").datetime.now().strftime("%Y-%m")
    conn = _get_db()
    try:
        conn.execute(
            """INSERT INTO cf_budgets
               (id, name, zone_id, monthly_limit_usd, alert_threshold_pct,
                period, status, classification, tenant_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, 'active', 'CUI // SP-CTI', ?,
                       datetime('now'))""",
            (budget_id, name, zone_id, monthly_limit_usd,
             alert_threshold_pct, period, tenant_id),
        )
        conn.commit()
        return {"status": "ok", "budget_id": budget_id, "name": name,
                "limit_usd": monthly_limit_usd}
    finally:
        conn.close()


def check_budgets(tenant_id: str = "default") -> List[Dict[str, Any]]:
    """Check all budgets for threshold breaches."""
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT * FROM cf_budgets WHERE tenant_id = ? AND status = 'active'""",
            (tenant_id,),
        ).fetchall()
        results = []
        for r in rows:
            pct = (r["current_spend_usd"] / r["monthly_limit_usd"] * 100
                   if r["monthly_limit_usd"] > 0 else 0)
            alert = pct >= r["alert_threshold_pct"]
            exceeded = pct >= 100
            results.append({
                "budget_id": r["id"],
                "name": r["name"],
                "limit_usd": r["monthly_limit_usd"],
                "current_spend_usd": r["current_spend_usd"],
                "utilization_pct": round(pct, 1),
                "alert": alert,
                "exceeded": exceeded,
            })
        return results
    except Exception:
        return []
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Budget Tracker")
    parser.add_argument("--create", action="store_true")
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--name", default="Monthly Budget")
    parser.add_argument("--limit", type=float, default=5000.0)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.create:
        print(json.dumps(create_budget(args.name, args.limit), indent=2))
    elif args.check:
        print(json.dumps(check_budgets(), indent=2))
    else:
        parser.print_help()
