# CUI // SP-CTI
"""Chargeback — cost allocation across teams/projects."""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def generate_chargeback_report(tenant_id: str = "default") -> Dict[str, Any]:
    """Generate chargeback report grouped by zone."""
    conn = _get_db()
    try:
        rows = conn.execute(
            """SELECT z.id as zone_id, z.name as zone_name, z.cloud_type,
                      COALESCE(SUM(c.cost_usd), 0) as total_cost
               FROM cf_landing_zones z
               LEFT JOIN cf_cost_records c ON z.id = c.zone_id
               WHERE z.tenant_id = ?
               GROUP BY z.id
               ORDER BY total_cost DESC""",
            (tenant_id,),
        ).fetchall()

        allocations = [dict(r) for r in rows]
        grand_total = sum(a["total_cost"] for a in allocations)

        for a in allocations:
            a["pct_of_total"] = round(
                a["total_cost"] / grand_total * 100, 1
            ) if grand_total > 0 else 0

        return {
            "status": "ok",
            "tenant_id": tenant_id,
            "grand_total_usd": round(grand_total, 2),
            "allocations": allocations,
            "zone_count": len(allocations),
            "classification": "CUI // SP-CTI",
        }
    except Exception:
        return {"status": "ok", "grand_total_usd": 0, "allocations": []}
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CloudForge Chargeback")
    parser.add_argument("--report", action="store_true")
    parser.add_argument("--tenant", default="default")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    if args.report:
        print(json.dumps(generate_chargeback_report(args.tenant), indent=2))
    else:
        parser.print_help()
