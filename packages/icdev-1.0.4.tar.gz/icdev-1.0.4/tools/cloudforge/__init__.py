# CUI // SP-CTI
"""CloudForge — Cloud-Agnostic Landing Zone & Hybrid Cloud Platform (D-CF-1).

ICDEV marketplace module for multi-CSP landing zone provisioning,
18-day ATO acceleration, cross-classification continuous delivery,
hybrid cloud migration/connection, and workload mobility.

Powered by DataBridge for data movement across CSPs.
"""

__version__ = "1.0.0"
__module_slug__ = "cloudforge"
