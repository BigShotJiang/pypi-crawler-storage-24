#!/usr/bin/env python3
# CUI // SP-CTI
"""SPARKPILOT Agent Server — Lightweight HTTP server for containerized agents.

Serves the A2A agent card, health endpoint, and task execution endpoint.
Each agent container runs one instance with a role-specific card and port.

Usage:
    python tools/agent/agent_server.py --port 8443 --role orchestrator
    python tools/agent/agent_server.py --port 8447 --role security
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

# Ensure project root is importable
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from flask import Flask, jsonify, request

logger = logging.getLogger("agent_server")

app = Flask(__name__)
app.secret_key = os.environ.get("AGENT_SECRET_KEY", os.urandom(32))

# Agent metadata — set at startup
_AGENT_ROLE: str = "unknown"
_AGENT_CARD: dict = {}
_START_TIME: str = datetime.now(timezone.utc).isoformat()


def _load_agent_card(role: str) -> dict:
    """Load the agent card JSON for the given role."""
    cards_dir = Path(__file__).resolve().parent / "cards"
    card_file = cards_dir / f"{role}_card.json"
    if card_file.exists():
        with open(card_file, "r") as fh:
            return json.load(fh)
    # Fallback: minimal card
    return {
        "name": f"sparkpilot-{role}",
        "description": f"SPARKPILOT {role} agent",
        "version": "1.0.0",
        "capabilities": {"streaming": False, "pushNotifications": False},
        "skills": [],
        "authentication": {"schemes": [{"scheme": "mutual-tls"}]},
    }


@app.route("/health")
def health():
    """Health check endpoint (used by Docker HEALTHCHECK and K8s probes)."""
    return jsonify({
        "status": "healthy",
        "agent": _AGENT_ROLE,
        "started_at": _START_TIME,
        "classification": "CUI // SP-CTI",
    })


@app.route("/ready")
def ready():
    """Readiness probe — returns 200 when the agent can accept tasks."""
    return jsonify({"ready": True, "agent": _AGENT_ROLE})


@app.route("/.well-known/agent.json")
def agent_card():
    """A2A Agent Card (JSON-RPC 2.0 discovery)."""
    return jsonify(_AGENT_CARD)


@app.route("/api/task", methods=["POST"])
def execute_task():
    """Execute a task dispatched by the orchestrator.

    Request body: {"task_id": "...", "action": "...", "params": {...}}
    """
    data = request.get_json(force=True, silent=True) or {}
    task_id = data.get("task_id", "unknown")
    action = data.get("action", "")
    params = data.get("params", {})

    logger.info("Task %s: action=%s agent=%s", task_id, action, _AGENT_ROLE)

    # Route to the appropriate handler based on agent role
    try:
        result = _handle_task(action, params)
        return jsonify({
            "task_id": task_id,
            "status": "completed",
            "result": result,
            "agent": _AGENT_ROLE,
        })
    except Exception as exc:
        logger.exception("Task %s failed", task_id)
        return jsonify({
            "task_id": task_id,
            "status": "failed",
            "error": str(exc),
            "agent": _AGENT_ROLE,
        }), 500


def _handle_task(action: str, params: dict) -> dict:
    """Dispatch task to role-specific handler."""
    if _AGENT_ROLE == "orchestrator":
        return _handle_orchestrator(action, params)
    elif _AGENT_ROLE == "security":
        return _handle_security(action, params)
    elif _AGENT_ROLE == "compliance":
        return _handle_compliance(action, params)
    elif _AGENT_ROLE == "builder":
        return _handle_builder(action, params)
    elif _AGENT_ROLE == "architect":
        return _handle_architect(action, params)
    else:
        return {"message": f"Agent '{_AGENT_ROLE}' received action '{action}'", "params": params}


def _handle_orchestrator(action: str, params: dict) -> dict:
    """Orchestrator agent: task routing, workflow management."""
    if action == "status":
        return {"agents_available": True, "workflow_engine": "ready"}
    return {"routed": True, "action": action}


def _handle_security(action: str, params: dict) -> dict:
    """Security agent: SAST, dep audit, secret detection, container scan."""
    if action == "sast_scan":
        from tools.security.sast_runner import run_sast
        project_dir = params.get("project_dir", str(PROJECT_ROOT))
        return run_sast(project_dir)
    if action == "dep_audit":
        from tools.security.dependency_auditor import run_audit
        project_dir = params.get("project_dir", str(PROJECT_ROOT))
        return run_audit(project_dir)
    return {"action": action, "status": "acknowledged"}


def _handle_compliance(action: str, params: dict) -> dict:
    """Compliance agent: ATO artifacts, control mapping."""
    return {"action": action, "status": "acknowledged"}


def _handle_builder(action: str, params: dict) -> dict:
    """Builder agent: TDD code gen."""
    return {"action": action, "status": "acknowledged"}


def _handle_architect(action: str, params: dict) -> dict:
    """Architect agent: system design, decomposition."""
    return {"action": action, "status": "acknowledged"}


def main():
    global _AGENT_ROLE, _AGENT_CARD

    parser = argparse.ArgumentParser(description="SPARKPILOT Agent Server")
    parser.add_argument("--port", type=int, default=8443, help="Listen port")
    parser.add_argument("--role", default=os.environ.get("AGENT_ROLE", "orchestrator"),
                        help="Agent role (orchestrator, security, compliance, builder, architect)")
    parser.add_argument("--host", default="0.0.0.0", help="Bind address")
    args = parser.parse_args()

    _AGENT_ROLE = args.role
    _AGENT_CARD = _load_agent_card(args.role)
    # Update card URL to match runtime port
    _AGENT_CARD["url"] = f"http://localhost:{args.port}"

    logging.basicConfig(
        level=logging.INFO,
        format=f"%(asctime)s [{args.role}] %(levelname)s %(message)s",
    )

    logger.info("Starting %s agent on port %d", args.role, args.port)
    app.run(host=args.host, port=args.port, debug=False)


if __name__ == "__main__":
    main()
