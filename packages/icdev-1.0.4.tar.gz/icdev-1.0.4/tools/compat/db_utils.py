#!/usr/bin/env python3
# CUI // SP-CTI
"""Centralized database path resolution and connection helpers for ICDEV.

Provides functions to resolve database paths and create connections with a
consistent fallback chain: env var > explicit argument > default.

As of D-DB-20, this module delegates to ``tools.db.storage`` for actual
connection creation, which supports both SQLite and PostgreSQL backends.
The path-resolution functions remain here for backward compatibility and
are used by the storage layer itself.

Usage:
    from tools.compat.db_utils import get_icdev_db_path, get_db_connection

    db_path = get_icdev_db_path()                    # env var or default
    db_path = get_icdev_db_path("/custom/path.db")   # explicit override

    conn = get_db_connection()                       # default icdev.db
    conn = get_db_connection(validate=True)           # raise if DB missing
    conn = get_db_connection(db_path="/other.db")    # explicit DB

    # New: context manager support (recommended)
    with get_db_connection() as conn:
        rows = conn.execute("SELECT 1").fetchall()

Fallback chain:
    1. Explicit path argument (if provided)
    2. ICDEV_DB_PATH environment variable
    3. Default: <project_root>/data/icdev.db

This module uses only Python stdlib (air-gap safe) for path resolution.
Connection creation delegates to tools.db.storage which may use psycopg2
when PostgreSQL is configured.
"""

import os
import sqlite3
from pathlib import Path
from typing import Optional, Union

# Project root: 3 levels up from tools/compat/db_utils.py
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_DEFAULT_DB = _PROJECT_ROOT / "data" / "icdev.db"


def get_project_root() -> Path:
    """Return the ICDEV project root directory."""
    return _PROJECT_ROOT


def get_icdev_db_path(explicit: Optional[Union[str, Path]] = None) -> Path:
    """Resolve the ICDEV database path.

    Args:
        explicit: Optional explicit path override (highest priority).

    Returns:
        Resolved Path to the ICDEV database.

    Fallback chain:
        1. explicit argument
        2. ICDEV_DB_PATH env var
        3. <project_root>/data/icdev.db
    """
    if explicit:
        return Path(explicit)

    env_path = os.environ.get("ICDEV_DB_PATH")
    if env_path:
        return Path(env_path)

    return _DEFAULT_DB


def get_memory_db_path(explicit: Optional[Union[str, Path]] = None) -> Path:
    """Resolve the memory database path.

    Fallback: ICDEV_MEMORY_DB_PATH env var > <project_root>/data/memory.db
    """
    if explicit:
        return Path(explicit)

    env_path = os.environ.get("ICDEV_MEMORY_DB_PATH")
    if env_path:
        return Path(env_path)

    return _PROJECT_ROOT / "data" / "memory.db"


def get_platform_db_path(explicit: Optional[Union[str, Path]] = None) -> Path:
    """Resolve the platform (SaaS) database path.

    Fallback: ICDEV_PLATFORM_DB_PATH env var > <project_root>/data/platform.db
    """
    if explicit:
        return Path(explicit)

    env_path = os.environ.get("ICDEV_PLATFORM_DB_PATH")
    if env_path:
        return Path(env_path)

    return _PROJECT_ROOT / "data" / "platform.db"


# ---------------------------------------------------------------------------
# Connection helpers — delegate to storage layer (D-DB-20)
# ---------------------------------------------------------------------------

def _get_storage_connection(db_path, validate, row_factory):
    """Delegate to tools.db.storage for backend-agnostic connections."""
    try:
        from tools.db.storage import get_connection
        return get_connection(db_path=db_path, row_factory=row_factory, validate=validate)
    except ImportError:
        # Fallback: direct SQLite if storage module not available
        pass

    # Direct SQLite fallback (air-gap, minimal install)
    path = get_icdev_db_path(db_path)
    if validate and not path.exists():
        raise FileNotFoundError(
            f"Database not found: {path}\n"
            "Run: python tools/db/init_icdev_db.py"
        )
    conn = sqlite3.connect(str(path))
    if row_factory:
        conn.row_factory = sqlite3.Row
    return conn


def get_db_connection(
    db_path: Optional[Union[str, Path]] = None,
    validate: bool = False,
    row_factory: bool = True,
):
    """Get a connection to the ICDEV database.

    Delegates to ``tools.db.storage`` which supports both SQLite and
    PostgreSQL backends (D-DB-20). Falls back to direct SQLite if the
    storage module is unavailable.

    The returned connection supports context manager (``with`` statement)
    and the standard sqlite3-compatible API: execute, commit, close.

    Args:
        db_path: Explicit path override (SQLite only).
        validate: When *True*, raise ``FileNotFoundError`` if SQLite DB missing.
        row_factory: When *True* (default), enable dict-like row access.

    Returns:
        A StorageConnection (or sqlite3.Connection fallback).
    """
    return _get_storage_connection(db_path, validate, row_factory)


def get_memory_connection(
    db_path: Optional[Union[str, Path]] = None,
    validate: bool = False,
    row_factory: bool = True,
):
    """Get a connection to the memory database."""
    path = get_memory_db_path(db_path)
    try:
        from tools.db.storage import get_memory_connection as _get_mem
        return _get_mem(db_path=path, validate=validate, row_factory=row_factory)
    except ImportError:
        pass

    if validate and not path.exists():
        raise FileNotFoundError(f"Memory database not found: {path}")
    conn = sqlite3.connect(str(path))
    if row_factory:
        conn.row_factory = sqlite3.Row
    return conn


def get_platform_connection(
    db_path: Optional[Union[str, Path]] = None,
    validate: bool = False,
    row_factory: bool = True,
):
    """Get a connection to the platform (SaaS) database."""
    path = get_platform_db_path(db_path)
    if validate and not path.exists():
        raise FileNotFoundError(f"Platform database not found: {path}")
    conn = sqlite3.connect(str(path))
    if row_factory:
        conn.row_factory = sqlite3.Row
    return conn
