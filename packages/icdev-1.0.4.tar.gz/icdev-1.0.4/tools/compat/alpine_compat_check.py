#!/usr/bin/env python3
# CUI // SP-CTI
"""Alpine Linux / musl libc compatibility checker for ICDEV.

Validates that the current environment and dependency chain are compatible
with Alpine Linux 3.12+ (musl libc). Detects glibc-only packages, missing
system libraries, and platform-specific code patterns.

Usage:
    python tools/compat/alpine_compat_check.py          # Human output
    python tools/compat/alpine_compat_check.py --json   # JSON output
    python tools/compat/alpine_compat_check.py --gate   # Exit 1 on failures

Architecture Decision:
  D-COMPAT-1: Alpine 3.12+ as default container base (musl libc).
              Users can override with --base-image in Dockerfile generation.
"""

from __future__ import annotations

import importlib
import json
import os
import platform
import struct
import subprocess
import sys
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


# ---------------------------------------------------------------------------
# Known C-extension packages and their Alpine compatibility status
# ---------------------------------------------------------------------------
KNOWN_C_EXTENSIONS: dict[str, dict[str, Any]] = {
    "pydantic": {
        "musllinux_wheels": True,
        "since_version": "2.0.1",
        "alpine_deps": [],
        "status": "core",
    },
    "cryptography": {
        "musllinux_wheels": True,
        "since_version": "3.4",
        "alpine_deps": ["libffi-dev"],
        "status": "optional",
    },
    "psycopg": {
        "musllinux_wheels": True,
        "since_version": "3.1",
        "alpine_deps": ["libpq-dev"],
        "note": "Replaces psycopg2-binary which lacks musl wheels",
        "status": "optional",
    },
    "numpy": {
        "musllinux_wheels": True,
        "since_version": "1.25",
        "alpine_deps": [],
        "status": "optional",
    },
    "Pillow": {
        "musllinux_wheels": True,
        "since_version": "8.3",
        "alpine_deps": ["jpeg-dev", "zlib-dev", "libpng-dev"],
        "status": "optional",
    },
    "lxml": {
        "musllinux_wheels": True,
        "since_version": "4.6.3",
        "alpine_deps": ["libxml2-dev", "libxslt-dev"],
        "status": "optional",
    },
    "PyYAML": {
        "musllinux_wheels": True,
        "since_version": "6.0",
        "alpine_deps": [],
        "note": "Has pure-Python fallback if C extension unavailable",
        "status": "core",
    },
    "psycopg2-binary": {
        "musllinux_wheels": False,
        "alpine_deps": ["postgresql-dev", "gcc", "musl-dev"],
        "note": "DEPRECATED for Alpine. Use psycopg[binary]>=3.1 instead.",
        "status": "deprecated",
    },
}


def check_libc() -> dict:
    """Detect C library (glibc vs musl)."""
    libc = "unknown"
    version = ""

    try:
        # On Linux, check if we're running musl
        result = subprocess.run(
            ["ldd", "--version"],
            capture_output=True, text=True, timeout=5,
        )
        output = result.stdout + result.stderr
        if "musl" in output.lower():
            libc = "musl"
            for line in output.splitlines():
                if "version" in line.lower():
                    version = line.strip()
                    break
        elif "glibc" in output.lower() or "gnu" in output.lower():
            libc = "glibc"
            for line in output.splitlines():
                if "glibc" in line.lower() or line.strip().startswith("ldd"):
                    version = line.strip()
                    break
    except (FileNotFoundError, subprocess.TimeoutExpired):
        if platform.system() == "Windows":
            libc = "msvcrt"
        elif platform.system() == "Darwin":
            libc = "libSystem"

    return {
        "check": "libc",
        "ok": True,
        "value": libc,
        "version": version,
        "is_musl": libc == "musl",
    }


def check_python_version() -> dict:
    """Python 3.12+ required for reliable musllinux wheel support."""
    v = sys.version_info
    ok = v >= (3, 12)
    return {
        "check": "python_version",
        "ok": ok,
        "value": f"{v.major}.{v.minor}.{v.micro}",
        "required": ">=3.12",
        "note": "" if ok else "Python 3.12+ required for musllinux wheel compatibility",
    }


def check_wheel_tags() -> dict:
    """Check if pip supports musllinux wheel tags."""
    try:
        from pip._internal.utils.compatibility_tags import get_supported
        tags = get_supported()
        tag_strs = [str(t) for t in tags]
        musl_tags = [t for t in tag_strs if "musl" in t]
        manylinux_tags = [t for t in tag_strs if "manylinux" in t]
        return {
            "check": "wheel_tags",
            "ok": True,
            "musl_supported": len(musl_tags) > 0,
            "musl_tag_count": len(musl_tags),
            "manylinux_tag_count": len(manylinux_tags),
            "sample_musl": musl_tags[:3] if musl_tags else [],
        }
    except ImportError:
        return {
            "check": "wheel_tags",
            "ok": True,
            "musl_supported": "unknown",
            "note": "pip internals not available — install pip to check",
        }


def check_c_extensions() -> dict:
    """Check installed C-extension packages for Alpine compatibility."""
    findings = []

    for pkg_name, info in KNOWN_C_EXTENSIONS.items():
        installed = False
        version = ""
        try:
            mod = importlib.import_module(pkg_name.lower().replace("-", "_"))
            installed = True
            version = getattr(mod, "__version__", "unknown")
        except ImportError:
            pass

        if not installed:
            continue

        has_musl = info.get("musllinux_wheels", False)
        is_deprecated = info.get("status") == "deprecated"

        finding = {
            "package": pkg_name,
            "version": version,
            "installed": True,
            "musllinux_wheels": has_musl,
            "alpine_compatible": has_musl and not is_deprecated,
            "alpine_deps": info.get("alpine_deps", []),
            "status": info.get("status", "unknown"),
        }
        if info.get("note"):
            finding["note"] = info["note"]
        if is_deprecated:
            finding["warning"] = f"DEPRECATED: {info.get('note', 'Use alternative package')}"

        findings.append(finding)

    all_compat = all(f["alpine_compatible"] for f in findings)
    deprecated = [f for f in findings if f["status"] == "deprecated"]

    return {
        "check": "c_extensions",
        "ok": all_compat and len(deprecated) == 0,
        "total_installed": len(findings),
        "alpine_compatible": sum(1 for f in findings if f["alpine_compatible"]),
        "deprecated_found": len(deprecated),
        "findings": findings,
    }


def check_os_specific_patterns() -> dict:
    """Scan for common OS-specific code patterns in tools/."""
    issues = []
    tools_dir = PROJECT_ROOT / "tools"

    patterns = [
        ("os.name == \"nt\"", "Use tools.compat.platform_utils.IS_WINDOWS"),
        ("os.name == 'nt'", "Use tools.compat.platform_utils.IS_WINDOWS"),
        ("sys.platform == \"win32\"", "Use tools.compat.platform_utils.IS_WINDOWS"),
        ("sys.platform == 'win32'", "Use tools.compat.platform_utils.IS_WINDOWS"),
    ]

    py_files = list(tools_dir.rglob("*.py"))
    for py_file in py_files:
        if "__pycache__" in str(py_file):
            continue
        try:
            content = py_file.read_text(encoding="utf-8", errors="replace")
            for pattern, suggestion in patterns:
                if pattern in content:
                    # Skip if in a comment or the compat module itself
                    rel = py_file.relative_to(PROJECT_ROOT)
                    if "compat" in str(rel):
                        continue
                    issues.append({
                        "file": str(rel).replace("\\", "/"),
                        "pattern": pattern,
                        "suggestion": suggestion,
                    })
        except Exception:
            continue

    return {
        "check": "os_specific_patterns",
        "ok": len(issues) == 0,
        "issues_found": len(issues),
        "files_scanned": len(py_files),
        "issues": issues[:20],  # Cap at 20 to avoid noise
    }


def check_path_handling() -> dict:
    """Verify pathlib.Path usage (not hardcoded separators)."""
    tools_dir = PROJECT_ROOT / "tools"
    issues = []

    # Look for hardcoded Windows paths in Python strings
    import re
    win_path_pattern = re.compile(r'["\'][A-Z]:\\\\')  # "C:\\" pattern

    py_files = list(tools_dir.rglob("*.py"))
    for py_file in py_files:
        if "__pycache__" in str(py_file):
            continue
        try:
            rel = py_file.relative_to(PROJECT_ROOT)
            if "compat" in str(rel):
                continue
            content = py_file.read_text(encoding="utf-8", errors="replace")
            for match in win_path_pattern.finditer(content):
                issues.append({
                    "file": str(rel).replace("\\", "/"),
                    "line_snippet": content[max(0, match.start() - 20):match.end() + 20].strip(),
                })
        except Exception:
            continue

    return {
        "check": "path_handling",
        "ok": len(issues) == 0,
        "hardcoded_windows_paths": len(issues),
        "issues": issues[:10],
    }


def check_alpine_base_image() -> dict:
    """Check if Dockerfiles use Alpine base images."""
    docker_dir = PROJECT_ROOT / "docker"
    if not docker_dir.exists():
        return {"check": "alpine_dockerfiles", "ok": True, "note": "No docker/ directory"}

    results = []
    for df in sorted(docker_dir.glob("Dockerfile.*")):
        try:
            content = df.read_text(encoding="utf-8")
            uses_alpine = "alpine" in content.lower()
            uses_slim = "slim" in content.lower() and not uses_alpine
            results.append({
                "file": df.name,
                "alpine": uses_alpine,
                "slim_debian": uses_slim,
            })
        except Exception:
            continue

    alpine_count = sum(1 for r in results if r["alpine"])
    total = len(results)

    return {
        "check": "alpine_dockerfiles",
        "ok": alpine_count == total,
        "alpine_count": alpine_count,
        "total_dockerfiles": total,
        "non_alpine": [r["file"] for r in results if not r["alpine"]],
    }


def run_all_checks() -> list[dict]:
    """Run all Alpine compatibility checks."""
    return [
        check_libc(),
        check_python_version(),
        check_wheel_tags(),
        check_c_extensions(),
        check_os_specific_patterns(),
        check_path_handling(),
        check_alpine_base_image(),
    ]


def main():
    import argparse

    parser = argparse.ArgumentParser(description="ICDEV Alpine Linux compatibility checker")
    parser.add_argument("--json", action="store_true", help="JSON output")
    parser.add_argument("--gate", action="store_true", help="Exit 1 on any failure")
    args = parser.parse_args()

    results = run_all_checks()
    all_ok = all(r["ok"] for r in results)

    if args.json:
        print(json.dumps({
            "alpine_compatible": all_ok,
            "checks": results,
            "platform": platform.system(),
            "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "arch": platform.machine(),
            "pointer_size": struct.calcsize("P") * 8,
        }, indent=2))
    else:
        from tools.compat.platform_utils import PLATFORM_NAME
        print(f"ICDEV Alpine Compatibility Check — {PLATFORM_NAME}")
        print("=" * 55)
        for r in results:
            status = "PASS" if r["ok"] else "FAIL"
            check = r["check"]
            if check == "libc":
                print(f"  [{status}] {check}: {r['value']} (musl={r['is_musl']})")
            elif check == "c_extensions":
                print(f"  [{status}] {check}: {r['alpine_compatible']}/{r['total_installed']} compatible")
                if r.get("deprecated_found"):
                    print(f"         WARNING: {r['deprecated_found']} deprecated package(s) found")
                for f in r.get("findings", []):
                    flag = "OK" if f["alpine_compatible"] else "FAIL"
                    print(f"           [{flag}] {f['package']}=={f['version']}")
                    if f.get("warning"):
                        print(f"                  {f['warning']}")
            elif check == "os_specific_patterns":
                print(f"  [{status}] {check}: {r['issues_found']} issues in {r['files_scanned']} files")
                for issue in r.get("issues", [])[:5]:
                    print(f"           {issue['file']}: {issue['pattern']}")
            elif check == "alpine_dockerfiles":
                print(f"  [{status}] {check}: {r.get('alpine_count', 0)}/{r.get('total_dockerfiles', 0)} Alpine")
                for name in r.get("non_alpine", [])[:5]:
                    print(f"           non-Alpine: {name}")
            elif check == "path_handling":
                print(f"  [{status}] {check}: {r['hardcoded_windows_paths']} hardcoded paths")
            else:
                val = r.get("value", "")
                print(f"  [{status}] {check}: {val}")
                if r.get("note"):
                    print(f"         Note: {r['note']}")

        print(f"\nOverall: {'PASS' if all_ok else 'FAIL'}")

    if args.gate and not all_ok:
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
