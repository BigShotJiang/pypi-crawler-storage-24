#!/usr/bin/env python3
# CUI // SP-CTI
# ////////////////////////////////////////////////////////////////////
# CONTROLLED UNCLASSIFIED INFORMATION (CUI) // SP-CTI
# Distribution: Distribution D -- Authorized DoD Personnel Only
# ////////////////////////////////////////////////////////////////////
"""cATO Live Evidence Engine — continuous OSCAL streaming and live evidence dashboard.

Extends cato_monitor.py with incremental OSCAL assessment-results generation,
evidence dashboard aggregation, freshness timeline tracking, and on-demand
evidence collection triggering.

Database tables:
  - cato_evidence_stream (write) — streamed OSCAL snapshots
  - cato_evidence (read) — evidence items from cato_monitor
  - project_controls (read) — mapped controls per project
"""

import argparse
import json
import sqlite3
import sys
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"

try:
    from tools.compat.db_utils import get_db_connection
except ImportError:
    get_db_connection = None

# Evidence freshness thresholds (days)
STALE_THRESHOLD_RATIO = 0.80  # 80% of expiry window elapsed = stale


def _get_connection(db_path=None):
    """Get a database connection with row factory."""
    if get_db_connection:
        return get_db_connection(db_path or DB_PATH, validate=True)
    path = db_path or DB_PATH
    if not Path(path).exists():
        raise FileNotFoundError(
            f"Database not found: {path}\n"
            "Run: python tools/db/init_icdev_db.py"
        )
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    return conn


def _ensure_tables(conn):
    """Ensure the cato_evidence_stream table exists."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cato_evidence_stream (
            id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            control_id TEXT NOT NULL,
            oscal_json TEXT,
            finding_status TEXT,
            observation_ts TEXT,
            streamed_at TEXT NOT NULL,
            current_count INTEGER DEFAULT 0,
            stale_count INTEGER DEFAULT 0,
            expired_count INTEGER DEFAULT 0
        )
    """)
    conn.commit()


def _log_audit_event(conn, project_id, event_type, details):
    """Log an audit trail event (append-only, NIST AU compliant)."""
    try:
        conn.execute(
            """INSERT INTO audit_trail
               (project_id, event_type, actor, action, details, classification)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                project_id,
                event_type,
                "icdev-cato-live-engine",
                event_type,
                json.dumps(details, default=str),
                "CUI",
            ),
        )
        conn.commit()
    except Exception as e:
        print(f"Warning: Could not log audit event: {e}", file=sys.stderr)


def _classify_evidence(conn, project_id, control_id):
    """Classify evidence freshness for a single control.

    Returns:
        Tuple of (status, last_collected, expires_at) where status is
        'current', 'stale', 'expired', or 'none'.
    """
    row = conn.execute(
        """SELECT status, collected_at, expires_at
           FROM cato_evidence
           WHERE project_id = ? AND control_id = ?
           ORDER BY collected_at DESC LIMIT 1""",
        (project_id, control_id),
    ).fetchone()

    if not row:
        return "none", None, None
    return row["status"] or "expired", row["collected_at"], row["expires_at"]


def _build_oscal_assessment_result(control_id, finding_status, observation_ts):
    """Build a minimal OSCAL assessment-results dict for a single control."""
    result_uuid = str(uuid.uuid4())
    return {
        "uuid": result_uuid,
        "metadata": {
            "last-modified": datetime.now(timezone.utc).strftime(
                "%Y-%m-%dT%H:%M:%SZ"
            ),
        },
        "results": [
            {
                "uuid": str(uuid.uuid4()),
                "title": f"cATO Evidence Stream — {control_id}",
                "start": observation_ts,
                "findings": [
                    {
                        "uuid": str(uuid.uuid4()),
                        "target": {
                            "type": "objective-id",
                            "target-id": control_id,
                            "status": {"state": finding_status},
                        },
                    }
                ],
                "observations": [
                    {
                        "uuid": str(uuid.uuid4()),
                        "description": (
                            f"Evidence freshness observation for {control_id}"
                        ),
                        "collected": observation_ts,
                    }
                ],
            }
        ],
    }


# --------------------------------------------------------------------------
# Public API functions
# --------------------------------------------------------------------------


def stream_oscal(project_id, db_path=None):
    """Stream incremental OSCAL assessment-results for controls with updated evidence.

    For each control in project_controls, checks evidence freshness from the
    cato_evidence table, generates an OSCAL assessment-results JSON for controls
    with evidence, and INSERTs into cato_evidence_stream.

    Args:
        project_id: Project identifier.
        db_path: Optional database path override.

    Returns:
        Dict with project_id, controls_streamed, current_count, stale_count,
        expired_count, and stream_ids.
    """
    conn = _get_connection(db_path)
    try:
        _ensure_tables(conn)

        # Get all controls for the project
        controls = conn.execute(
            """SELECT DISTINCT control_id FROM project_controls
               WHERE project_id = ?
               ORDER BY control_id""",
            (project_id,),
        ).fetchall()

        now = datetime.now(timezone.utc)
        now_str = now.strftime("%Y-%m-%dT%H:%M:%SZ")

        stream_ids = []
        current_count = 0
        stale_count = 0
        expired_count = 0

        for ctrl_row in controls:
            control_id = ctrl_row["control_id"]
            status, last_collected, expires_at = _classify_evidence(
                conn, project_id, control_id
            )

            if status == "none":
                expired_count += 1
                finding_status = "not-satisfied"
            elif status == "current":
                current_count += 1
                finding_status = "satisfied"
            elif status == "stale":
                stale_count += 1
                finding_status = "not-satisfied"
            else:  # expired
                expired_count += 1
                finding_status = "not-satisfied"

            # Build OSCAL assessment-results
            oscal = _build_oscal_assessment_result(
                control_id, finding_status, now_str
            )

            stream_id = f"ces-{uuid.uuid4().hex[:12]}"
            conn.execute(
                """INSERT INTO cato_evidence_stream
                   (id, project_id, control_id, oscal_json, finding_status,
                    observation_ts, streamed_at, current_count, stale_count,
                    expired_count)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    stream_id,
                    project_id,
                    control_id,
                    json.dumps(oscal, default=str),
                    finding_status,
                    now_str,
                    now_str,
                    current_count,
                    stale_count,
                    expired_count,
                ),
            )
            stream_ids.append(stream_id)

        conn.commit()

        # Audit trail
        _log_audit_event(conn, project_id, "cato_stream_published", {
            "controls_streamed": len(stream_ids),
            "current": current_count,
            "stale": stale_count,
            "expired": expired_count,
        })

        if stale_count > 0:
            _log_audit_event(conn, project_id, "cato_stream_stale_detected", {
                "stale_count": stale_count,
            })

        result = {
            "project_id": project_id,
            "controls_streamed": len(stream_ids),
            "current_count": current_count,
            "stale_count": stale_count,
            "expired_count": expired_count,
            "stream_ids": stream_ids,
        }

        print(f"cATO OSCAL stream: {len(stream_ids)} controls streamed")
        print(f"  Current: {current_count}  Stale: {stale_count}  "
              f"Expired: {expired_count}")

        return result

    finally:
        conn.close()


def get_evidence_dashboard(project_id, db_path=None):
    """Aggregate evidence status across all controls for a live dashboard.

    Args:
        project_id: Project identifier.
        db_path: Optional database path override.

    Returns:
        Dict with project_id, total_controls, with_evidence, current, stale,
        expired, coverage_pct, readiness_score, and controls list.
    """
    conn = _get_connection(db_path)
    try:
        # Get all mapped controls
        ctrl_rows = conn.execute(
            """SELECT DISTINCT control_id FROM project_controls
               WHERE project_id = ?
               ORDER BY control_id""",
            (project_id,),
        ).fetchall()

        total_controls = len(ctrl_rows)
        with_evidence = 0
        current = 0
        stale = 0
        expired = 0
        controls = []

        for ctrl_row in ctrl_rows:
            control_id = ctrl_row["control_id"]
            status, last_collected, expires_at = _classify_evidence(
                conn, project_id, control_id
            )

            if status != "none":
                with_evidence += 1

            if status == "current":
                current += 1
            elif status == "stale":
                stale += 1
            elif status in ("expired", "none"):
                expired += 1

            controls.append({
                "control_id": control_id,
                "status": status,
                "last_collected": last_collected,
                "expires_at": expires_at,
            })

        coverage_pct = round(
            (with_evidence / total_controls * 100) if total_controls > 0 else 0.0, 1
        )
        readiness_score = round(
            (current / total_controls) if total_controls > 0 else 0.0, 3
        )

        result = {
            "project_id": project_id,
            "total_controls": total_controls,
            "with_evidence": with_evidence,
            "current": current,
            "stale": stale,
            "expired": expired,
            "coverage_pct": coverage_pct,
            "readiness_score": readiness_score,
            "controls": controls,
        }

        print(f"cATO evidence dashboard for {project_id}:")
        print(f"  Controls: {total_controls}  With evidence: {with_evidence}")
        print(f"  Current: {current}  Stale: {stale}  Expired: {expired}")
        print(f"  Coverage: {coverage_pct}%  Readiness: {readiness_score}")

        return result

    finally:
        conn.close()


def get_freshness_timeline(project_id, days=30, db_path=None):
    """Historical freshness trend from cato_evidence_stream snapshots.

    Aggregates daily counts of current/stale/expired findings from the
    cato_evidence_stream table over the specified number of days.

    Args:
        project_id: Project identifier.
        days: Number of days to look back (default 30).
        db_path: Optional database path override.

    Returns:
        Dict with project_id and timeline list of daily snapshots.
    """
    conn = _get_connection(db_path)
    try:
        _ensure_tables(conn)

        cutoff = (
            datetime.now(timezone.utc) - timedelta(days=days)
        ).strftime("%Y-%m-%dT%H:%M:%SZ")

        rows = conn.execute(
            """SELECT DATE(streamed_at) as day,
                      SUM(CASE WHEN finding_status = 'satisfied' THEN 1 ELSE 0 END) as current_count,
                      SUM(CASE WHEN finding_status = 'not-satisfied' THEN 1 ELSE 0 END) as stale_expired_count
               FROM cato_evidence_stream
               WHERE project_id = ? AND streamed_at >= ?
               GROUP BY DATE(streamed_at)
               ORDER BY day""",
            (project_id, cutoff),
        ).fetchall()

        timeline = []
        for row in rows:
            timeline.append({
                "date": row["day"],
                "current_count": row["current_count"] or 0,
                "stale_count": 0,  # Approximation: split not-satisfied
                "expired_count": row["stale_expired_count"] or 0,
            })

        result = {
            "project_id": project_id,
            "timeline": timeline,
        }

        print(f"cATO freshness timeline for {project_id}: "
              f"{len(timeline)} days of data (last {days}d)")

        return result

    finally:
        conn.close()


def trigger_collection(project_id, control_id=None, db_path=None):
    """Trigger evidence collection for one or all controls.

    Attempts to import and use cato_monitor.collect_evidence for each
    control that needs refreshing. Handles ImportError gracefully.

    Args:
        project_id: Project identifier.
        control_id: Optional specific control ID. If None, triggers all.
        db_path: Optional database path override.

    Returns:
        Dict with project_id, triggered count, and results list.
    """
    # Try to import collect_evidence from cato_monitor
    collect_fn = None
    try:
        from tools.compliance.cato_monitor import collect_evidence
        collect_fn = collect_evidence
    except ImportError:
        pass

    conn = _get_connection(db_path)
    try:
        if control_id:
            control_ids = [control_id]
        else:
            rows = conn.execute(
                """SELECT DISTINCT control_id FROM project_controls
                   WHERE project_id = ?
                   ORDER BY control_id""",
                (project_id,),
            ).fetchall()
            control_ids = [r["control_id"] for r in rows]

        results = []
        triggered = 0

        for cid in control_ids:
            entry = {"control_id": cid, "status": "triggered"}

            if collect_fn is not None:
                try:
                    collect_fn(
                        project_id=project_id,
                        control_id=cid,
                        evidence_type="config_check",
                        evidence_source="cato_live_engine_trigger",
                        automation_frequency="per_change",
                        db_path=db_path,
                    )
                    entry["status"] = "collected"
                except Exception as e:
                    entry["status"] = "error"
                    entry["error"] = str(e)
            else:
                entry["status"] = "skipped"
                entry["reason"] = "cato_monitor.collect_evidence not available"

            results.append(entry)
            triggered += 1

        result = {
            "project_id": project_id,
            "triggered": triggered,
            "results": results,
        }

        print(f"cATO collection trigger: {triggered} controls triggered")

        return result

    finally:
        conn.close()


# --------------------------------------------------------------------------
# CLI entry point
# --------------------------------------------------------------------------


def main():
    """CLI entry point for cATO Live Evidence Engine."""
    parser = argparse.ArgumentParser(
        description="cATO Live Evidence Engine — continuous OSCAL streaming "
                    "and live evidence dashboard"
    )
    parser.add_argument(
        "--project-id", required=True,
        help="Project ID in ICDEV database"
    )
    parser.add_argument(
        "--db-path", type=Path, default=None,
        help="Override database path"
    )

    # Action flags
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--stream", action="store_true",
        help="Stream incremental OSCAL assessment-results for all controls"
    )
    group.add_argument(
        "--dashboard", action="store_true",
        help="Get aggregated evidence dashboard"
    )
    group.add_argument(
        "--timeline", action="store_true",
        help="Get historical freshness timeline"
    )
    group.add_argument(
        "--trigger", action="store_true",
        help="Trigger evidence collection for controls"
    )

    # Optional parameters
    parser.add_argument(
        "--days", type=int, default=30,
        help="Number of days for timeline lookback (default: 30)"
    )
    parser.add_argument(
        "--control-id", type=str, default=None,
        help="Specific control ID for --trigger"
    )

    # Output format
    parser.add_argument(
        "--json", action="store_true",
        help="Output as JSON"
    )

    args = parser.parse_args()

    try:
        if args.stream:
            result = stream_oscal(
                project_id=args.project_id,
                db_path=args.db_path,
            )
            if args.json:
                print(json.dumps(result, indent=2, default=str))

        elif args.dashboard:
            result = get_evidence_dashboard(
                project_id=args.project_id,
                db_path=args.db_path,
            )
            if args.json:
                print(json.dumps(result, indent=2, default=str))
            else:
                print("=" * 65)
                print("  cATO LIVE EVIDENCE DASHBOARD")
                print("=" * 65)
                print(f"  Project:    {result['project_id']}")
                print(f"  Controls:   {result['total_controls']}")
                print(f"  Evidence:   {result['with_evidence']}")
                print(f"  Current:    {result['current']}")
                print(f"  Stale:      {result['stale']}")
                print(f"  Expired:    {result['expired']}")
                print(f"  Coverage:   {result['coverage_pct']}%")
                print(f"  Readiness:  {result['readiness_score']}")
                print("=" * 65)

        elif args.timeline:
            result = get_freshness_timeline(
                project_id=args.project_id,
                days=args.days,
                db_path=args.db_path,
            )
            if args.json:
                print(json.dumps(result, indent=2, default=str))
            else:
                print(f"Freshness Timeline ({args.days} days):")
                for entry in result["timeline"]:
                    print(f"  {entry['date']}  current={entry['current_count']}  "
                          f"stale={entry['stale_count']}  "
                          f"expired={entry['expired_count']}")

        elif args.trigger:
            result = trigger_collection(
                project_id=args.project_id,
                control_id=args.control_id,
                db_path=args.db_path,
            )
            if args.json:
                print(json.dumps(result, indent=2, default=str))
            else:
                print(f"Triggered collection for {result['triggered']} controls")
                for r in result["results"]:
                    print(f"  {r['control_id']}: {r['status']}")

    except (FileNotFoundError, ValueError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
