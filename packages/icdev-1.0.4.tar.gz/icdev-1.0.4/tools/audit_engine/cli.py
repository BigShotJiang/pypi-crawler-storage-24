#!/usr/bin/env python3
# CUI // SP-CTI
# Controlled by: Department of Defense
# CUI Category: CTI
# Distribution: D
# POC: ICDEV System Administrator
"""Audit Engine CLI — Unified compliance audit command-line interface.

Provides a single entry point for all audit engine operations:
scan, compare, advise, manage regimes, and BYOS.

Usage:
    # Run audit on current directory
    python tools/audit_engine/cli.py scan --json

    # Run audit on BYOS (directory)
    python tools/audit_engine/cli.py scan --target /path/to/code --type byos --json

    # Run audit on BYOS (git URL, private)
    python tools/audit_engine/cli.py scan --target https://github.com/org/repo.git \\
        --type byos --auth token --token ghp_xxx --json

    # Compare two regimes
    python tools/audit_engine/cli.py compare --baseline nist_800_171 --target nist_800_53 --json

    # Get AI recommendations
    python tools/audit_engine/cli.py advise --regime nist_800_53 --json

    # List available regimes
    python tools/audit_engine/cli.py regimes --json

    # Import a custom regime
    python tools/audit_engine/cli.py regime-import --file /path/to/regime.json --json

    # Export regimes
    python tools/audit_engine/cli.py regime-export --output /path/to/export --json

    # Score trend
    python tools/audit_engine/cli.py trend --regime nist_800_53 --json
"""

import argparse
import json
import os
import sys
from pathlib import Path

# Ensure ICDEV root is on sys.path for tools.* imports
_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


def main():
    parser = argparse.ArgumentParser(
        description="ICDEV Audit Engine — Unified Compliance Report Card",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # ── scan ──
    scan_p = subparsers.add_parser("scan", help="Run audit scan")
    scan_p.add_argument("--target", default=".", help="Target path or git URL")
    scan_p.add_argument("--type", default="auto",
                        choices=["icdev", "module", "child_app", "byos", "auto"])
    scan_p.add_argument("--project-id", help="ICDEV project ID")
    scan_p.add_argument("--regimes", nargs="*", help="Specific regime IDs")
    scan_p.add_argument("--skip", nargs="*", help="Scanners to skip")
    scan_p.add_argument("--no-store", action="store_true")
    scan_p.add_argument("--auth", default="auto",
                        choices=["auto", "ssh", "token", "public"],
                        help="Git auth method (for BYOS git URLs)")
    scan_p.add_argument("--token", help="HTTPS personal access token")
    scan_p.add_argument("--ssh-key", help="SSH private key path")
    scan_p.add_argument("--branch", help="Git branch to clone")
    scan_p.add_argument("--format", default="terminal",
                        choices=["json", "terminal", "markdown"])
    scan_p.add_argument("--json", action="store_true")

    # ── compare ──
    cmp_p = subparsers.add_parser("compare", help="Compare two regimes")
    cmp_p.add_argument("--baseline", required=True)
    cmp_p.add_argument("--target", required=True)
    cmp_p.add_argument("--scan-target", default=".", help="Path to scan")
    cmp_p.add_argument("--project-id", help="ICDEV project ID")
    cmp_p.add_argument("--json", action="store_true")

    # ── advise ──
    adv_p = subparsers.add_parser("advise", help="Get AI recommendations")
    adv_p.add_argument("--regime", help="Filter to single regime")
    adv_p.add_argument("--scan-target", default=".", help="Path to scan")
    adv_p.add_argument("--project-id", help="ICDEV project ID")
    adv_p.add_argument("--use-llm", action="store_true")
    adv_p.add_argument("--max", type=int, default=20)
    adv_p.add_argument("--json", action="store_true")

    # ── regimes ──
    reg_p = subparsers.add_parser("regimes", help="List available regimes")
    reg_p.add_argument("--json", action="store_true")

    # ── regime-import ──
    imp_p = subparsers.add_parser("regime-import", help="Import a regime file")
    imp_p.add_argument("--file", required=True, help="Path to regime JSON")
    imp_p.add_argument("--json", action="store_true")

    # ── regime-export ──
    exp_p = subparsers.add_parser("regime-export", help="Export all regimes")
    exp_p.add_argument("--output", required=True, help="Output directory")
    exp_p.add_argument("--json", action="store_true")

    # ── trend ──
    trn_p = subparsers.add_parser("trend", help="Show score trend")
    trn_p.add_argument("--regime", help="Filter by regime ID")
    trn_p.add_argument("--limit", type=int, default=10)
    trn_p.add_argument("--json", action="store_true")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    if args.command == "scan":
        _cmd_scan(args)
    elif args.command == "compare":
        _cmd_compare(args)
    elif args.command == "advise":
        _cmd_advise(args)
    elif args.command == "regimes":
        _cmd_regimes(args)
    elif args.command == "regime-import":
        _cmd_regime_import(args)
    elif args.command == "regime-export":
        _cmd_regime_export(args)
    elif args.command == "trend":
        _cmd_trend(args)


def _cmd_scan(args):
    from tools.audit_engine.engine import run_audit
    from tools.audit_engine.report_card import generate_report_card

    target = args.target
    clone_path = None

    # Handle git URLs for BYOS
    if args.type == "byos" and (target.startswith("http") or target.startswith("git@")):
        from tools.audit_engine.git_fetcher import fetch_repo, cleanup_clone
        print(f"Cloning {target}...", file=sys.stderr)
        fetch = fetch_repo(
            url=target,
            auth_method=args.auth,
            token=args.token,
            ssh_key=args.ssh_key,
            branch=args.branch,
        )
        if not fetch.get("success"):
            print(f"Error: {fetch.get('error')}", file=sys.stderr)
            sys.exit(1)
        clone_path = fetch["clone_path"]
        target = clone_path
        print(f"Cloned to {clone_path}", file=sys.stderr)

    result = run_audit(
        target_path=target,
        target_type=args.type,
        project_id=args.project_id,
        regime_ids=args.regimes,
        skip_tools=args.skip,
        store_results=not args.no_store,
    )

    # Clean up clone
    if clone_path:
        from tools.audit_engine.git_fetcher import cleanup_clone
        cleanup_clone(clone_path)

    fmt = "json" if args.json else args.format
    report = generate_report_card(result, output_format=fmt)
    print(report["formatted_output"])


def _cmd_compare(args):
    from tools.audit_engine.engine import run_audit
    from tools.audit_engine.comparator import compare_regimes

    audit_result = run_audit(
        target_path=args.scan_target,
        project_id=args.project_id,
        regime_ids=[args.baseline, args.target],
        store_results=False,
    )
    result = compare_regimes(audit_result, args.baseline, args.target)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        if "error" in result:
            print(f"Error: {result['error']}", file=sys.stderr)
            sys.exit(1)
        b = result["baseline"]
        t = result["target"]
        print(f"\n{'='*70}")
        print(f"  REGIME COMPARISON: {b['regime_name']} vs {t['regime_name']}")
        print(f"{'='*70}")
        print(f"  Baseline: {b['score']:.1f}% ({b['grade']}) | Target: {t['score']:.1f}% ({t['grade']})")
        print(f"  Delta: {result['score_delta']:+.1f}% | Gaps: {result['gap_count']}")
        print(f"\n  {result['recommendation']}")
        print(f"\n{'='*70}")


def _cmd_advise(args):
    from tools.audit_engine.engine import run_audit
    from tools.audit_engine.ai_advisor import generate_recommendations

    audit_result = run_audit(
        target_path=args.scan_target,
        project_id=args.project_id,
        store_results=False,
    )
    result = generate_recommendations(
        audit_result,
        regime_id=args.regime,
        max_recommendations=args.max,
        use_llm=args.use_llm,
    )

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"\n  TOP RECOMMENDATIONS (by ROI):")
        for rec in result.get("by_roi", [])[:10]:
            print(f"  {rec['rank']:2d}. [{rec['severity'].upper():8s}] {rec['title']}")
            print(f"      Control: {rec['control_id']} | Effort: {rec['effort_label']} | Impact: {rec['impact_score']}")
        if result.get("estimated_improvement_top5"):
            print(f"\n  Est. improvement (top 5): +{result['estimated_improvement_top5']}%")


def _cmd_regimes(args):
    from tools.audit_engine.regime_loader import list_regimes
    result = list_regimes()
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"\n  Available Regimes ({len(result)}):")
        for r in result:
            print(f"    {r['id']:25s} {r['name']:40s} v{r['version']} ({r['category_count']} cats)")


def _cmd_regime_import(args):
    from tools.audit_engine.regime_updater import import_regime
    result = import_regime(args.file)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        if result.get("success"):
            print(f"  Imported: {result['name']} ({result['action']})")
        else:
            print(f"  Error: {result.get('error')}", file=sys.stderr)


def _cmd_regime_export(args):
    from tools.audit_engine.regime_updater import export_regimes
    result = export_regimes(args.output)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"  Exported {result['exported_count']} regimes to {result['output_dir']}")


def _cmd_trend(args):
    from tools.audit_engine.report_card import get_score_trend
    result = get_score_trend(regime_id=args.regime, limit=args.limit)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        if not result:
            print("  No historical data yet. Run an audit first.")
        else:
            for t in result:
                print(f"  {t.get('timestamp', '')[:19]}  {t.get('regime_id', ''):25s}  "
                      f"{t.get('overall_score', 0):5.1f}%  {t.get('grade', '?')}")


if __name__ == "__main__":
    main()
