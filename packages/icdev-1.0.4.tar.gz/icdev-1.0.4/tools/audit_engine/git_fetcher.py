#!/usr/bin/env python3
# CUI // SP-CTI
# Controlled by: Department of Defense
# CUI Category: CTI
# Distribution: D
# POC: ICDEV System Administrator
"""Git Fetcher — Clone repositories for BYOS audit scanning.

Supports both SSH and HTTPS authentication for private repositories.
Clones into a temporary directory, runs the audit, and optionally
cleans up after completion.

Auth methods:
  - Public repos: No auth needed
  - SSH: git@github.com:org/repo.git (uses SSH agent or key file)
  - HTTPS token: https://github.com/org/repo.git with personal access token

Usage:
    # Public repo
    python tools/audit_engine/git_fetcher.py --url https://github.com/org/repo.git --json

    # Private via HTTPS token
    python tools/audit_engine/git_fetcher.py --url https://github.com/org/repo.git \\
        --auth-method token --token ghp_xxxxx --json

    # Private via SSH
    python tools/audit_engine/git_fetcher.py --url git@github.com:org/repo.git \\
        --auth-method ssh --json

    # SSH with specific key
    python tools/audit_engine/git_fetcher.py --url git@github.com:org/repo.git \\
        --auth-method ssh --ssh-key ~/.ssh/id_ed25519 --json
"""

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional

BASE_DIR = Path(__file__).resolve().parent.parent.parent
CLONE_BASE = BASE_DIR / ".tmp" / "audit_clones"


def fetch_repo(
    url: str,
    auth_method: str = "auto",
    token: Optional[str] = None,
    ssh_key: Optional[str] = None,
    branch: Optional[str] = None,
    depth: int = 1,
    keep: bool = False,
) -> Dict:
    """Clone a git repository for BYOS scanning.

    Args:
        url: Git repository URL (HTTPS or SSH).
        auth_method: 'auto', 'ssh', 'token', or 'public'.
        token: Personal access token for HTTPS auth.
        ssh_key: Path to SSH private key file.
        branch: Optional branch to clone.
        depth: Clone depth (1 for shallow, 0 for full).
        keep: Keep cloned directory after return (default: cleaned by caller).

    Returns:
        Dict with clone_path, repo_name, and metadata.
    """
    # Validate URL
    if not _is_valid_git_url(url):
        return {"success": False, "error": f"Invalid git URL: {url}"}

    # Determine auth method
    if auth_method == "auto":
        auth_method = _detect_auth_method(url, token, ssh_key)

    # Extract repo name for directory naming
    repo_name = _extract_repo_name(url)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    clone_dir = CLONE_BASE / f"{repo_name}_{timestamp}"

    CLONE_BASE.mkdir(parents=True, exist_ok=True)

    # Build git clone command
    clone_url = url
    env = dict(os.environ)

    if auth_method == "token" and token:
        # Inject token into HTTPS URL
        clone_url = _inject_token(url, token)
    elif auth_method == "ssh":
        if ssh_key:
            # Use specific SSH key
            env["GIT_SSH_COMMAND"] = f'ssh -i "{ssh_key}" -o StrictHostKeyChecking=accept-new'
        else:
            # Use default SSH agent
            env["GIT_SSH_COMMAND"] = "ssh -o StrictHostKeyChecking=accept-new"

    cmd = ["git", "clone"]
    if depth > 0:
        cmd.extend(["--depth", str(depth)])
    if branch:
        cmd.extend(["--branch", branch])
    cmd.extend([clone_url, str(clone_dir)])

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,
            env=env,
        )

        if result.returncode != 0:
            # Sanitize error message (remove tokens)
            error = _sanitize_output(result.stderr, token)
            return {
                "success": False,
                "error": f"Git clone failed: {error}",
                "auth_method": auth_method,
            }

        # Get repo metadata
        metadata = _get_repo_metadata(clone_dir)

        return {
            "success": True,
            "clone_path": str(clone_dir),
            "repo_name": repo_name,
            "url": _sanitize_url(url),  # Never expose tokens in output
            "auth_method": auth_method,
            "branch": branch or metadata.get("branch", "main"),
            "metadata": metadata,
        }

    except subprocess.TimeoutExpired:
        _cleanup(clone_dir)
        return {"success": False, "error": "Clone timed out (120s limit)"}
    except FileNotFoundError:
        return {"success": False, "error": "git not found — install git and add to PATH"}
    except Exception as e:
        _cleanup(clone_dir)
        return {"success": False, "error": str(e)}


def cleanup_clone(clone_path: str) -> Dict:
    """Remove a cloned repository directory.

    Args:
        clone_path: Path to the cloned repository.

    Returns:
        Cleanup result dict.
    """
    try:
        path = Path(clone_path)
        if path.exists() and str(CLONE_BASE) in str(path):
            shutil.rmtree(path, ignore_errors=True)
            return {"success": True, "removed": str(path)}
        return {"success": False, "error": "Path not in audit_clones directory"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def cleanup_all() -> Dict:
    """Remove all cloned repositories."""
    try:
        if CLONE_BASE.exists():
            count = sum(1 for _ in CLONE_BASE.iterdir())
            shutil.rmtree(CLONE_BASE, ignore_errors=True)
            return {"success": True, "removed_count": count}
        return {"success": True, "removed_count": 0}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _is_valid_git_url(url: str) -> bool:
    """Validate git URL format."""
    patterns = [
        r"^https?://[\w./-]+\.git$",           # HTTPS
        r"^https?://[\w./-]+$",                  # HTTPS without .git
        r"^git@[\w.]+:[\w./-]+\.git$",          # SSH
        r"^git@[\w.]+:[\w./-]+$",               # SSH without .git
        r"^ssh://[\w.@/-]+$",                    # SSH protocol
    ]
    return any(re.match(p, url) for p in patterns)


def _detect_auth_method(url: str, token: Optional[str],
                        ssh_key: Optional[str]) -> str:
    """Auto-detect authentication method."""
    if token:
        return "token"
    if ssh_key:
        return "ssh"
    if url.startswith("git@") or url.startswith("ssh://"):
        return "ssh"
    return "public"


def _extract_repo_name(url: str) -> str:
    """Extract repository name from URL."""
    # Remove trailing .git
    name = url.rstrip("/").split("/")[-1]
    if name.endswith(".git"):
        name = name[:-4]
    # Handle SSH format git@host:org/repo
    if ":" in name and "@" in url:
        name = url.split(":")[-1].split("/")[-1]
        if name.endswith(".git"):
            name = name[:-4]
    # Sanitize
    name = re.sub(r"[^\w.-]", "_", name)
    return name or "repo"


def _inject_token(url: str, token: str) -> str:
    """Inject auth token into HTTPS URL."""
    if "://" in url:
        parts = url.split("://", 1)
        return f"{parts[0]}://x-token:{token}@{parts[1]}"
    return url


def _sanitize_url(url: str) -> str:
    """Remove credentials from URL for safe display."""
    # Remove embedded tokens/passwords
    return re.sub(r"://[^@]+@", "://***@", url)


def _sanitize_output(text: str, token: Optional[str]) -> str:
    """Remove sensitive data from error output."""
    sanitized = text
    if token:
        sanitized = sanitized.replace(token, "***")
    # Remove any embedded credentials in URLs
    sanitized = re.sub(r"://[^@\s]+@", "://***@", sanitized)
    return sanitized[:500]  # Cap error length


def _get_repo_metadata(clone_dir: Path) -> Dict:
    """Extract metadata from cloned repository."""
    metadata = {}
    try:
        # Current branch
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, cwd=str(clone_dir), timeout=10,
        )
        if result.returncode == 0:
            metadata["branch"] = result.stdout.strip()

        # Last commit
        result = subprocess.run(
            ["git", "log", "-1", "--format=%H|%s|%ai"],
            capture_output=True, text=True, cwd=str(clone_dir), timeout=10,
        )
        if result.returncode == 0:
            parts = result.stdout.strip().split("|", 2)
            if len(parts) == 3:
                metadata["last_commit"] = parts[0][:12]
                metadata["last_message"] = parts[1][:100]
                metadata["last_date"] = parts[2]

        # Languages detected
        extensions = set()
        for root, _, files in os.walk(clone_dir):
            if ".git" in root:
                continue
            for f in files:
                ext = Path(f).suffix.lower()
                if ext in {".py", ".js", ".ts", ".java", ".go", ".rs", ".c", ".cs", ".rb"}:
                    extensions.add(ext)
        metadata["languages"] = sorted(extensions)

        # File count
        file_count = sum(1 for _ in clone_dir.rglob("*") if _.is_file() and ".git" not in str(_))
        metadata["file_count"] = file_count

    except Exception:
        pass

    return metadata


def _cleanup(path: Path) -> None:
    """Clean up directory silently."""
    try:
        if path.exists():
            shutil.rmtree(path, ignore_errors=True)
    except Exception:
        pass


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Git Fetcher for BYOS Audit")
    parser.add_argument("--url", type=str, help="Git repository URL")
    parser.add_argument("--auth-method", type=str, default="auto",
                        choices=["auto", "ssh", "token", "public"])
    parser.add_argument("--token", type=str, help="HTTPS personal access token")
    parser.add_argument("--ssh-key", type=str, help="Path to SSH private key")
    parser.add_argument("--branch", type=str, help="Branch to clone")
    parser.add_argument("--depth", type=int, default=1, help="Clone depth (0=full)")
    parser.add_argument("--cleanup", action="store_true", help="Clean up all clones")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    if args.cleanup:
        result = cleanup_all()
    elif args.url:
        result = fetch_repo(
            url=args.url,
            auth_method=args.auth_method,
            token=args.token,
            ssh_key=args.ssh_key,
            branch=args.branch,
            depth=args.depth,
        )
    else:
        parser.print_help()
        sys.exit(0)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        if result.get("success"):
            print(f"Cloned to: {result.get('clone_path', '')}")
            meta = result.get("metadata", {})
            if meta:
                print(f"Branch: {meta.get('branch', '?')}")
                print(f"Languages: {', '.join(meta.get('languages', []))}")
                print(f"Files: {meta.get('file_count', '?')}")
        else:
            print(f"Error: {result.get('error', 'Unknown')}", file=sys.stderr)
