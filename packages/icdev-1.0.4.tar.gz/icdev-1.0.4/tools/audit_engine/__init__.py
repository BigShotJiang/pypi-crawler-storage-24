#!/usr/bin/env python3
# CUI // SP-CTI
# Controlled by: Department of Defense
# CUI Category: CTI
# Distribution: D
# POC: ICDEV System Administrator
"""Audit Engine — Unified compliance report card with regime crosswalk.

Scans ICDEV projects, modules, child apps, and bring-your-own-software
for compliance posture across all supported frameworks. Produces per-regime
scores with side-by-side gap analysis and AI-powered recommendations.
"""
