#!/usr/bin/env python3
# CUI // SP-CTI
# Controlled by: Department of Defense
# CUI Category: CTI
# Distribution: D
# POC: ICDEV System Administrator
"""Regime Comparator — Side-by-side gap analysis between compliance frameworks.

Enables users to see their compliance posture across two regimes simultaneously,
highlighting gaps, overlaps, and controls unique to each framework. Key use case:
"I'm 800-171 compliant — what do I need for 800-53?"

Usage:
    python tools/audit_engine/comparator.py --baseline nist_800_171 --target nist_800_53 \\
        --audit-result audit_result.json --json
"""

import json
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from tools.audit_engine.regime_loader import load_regime, get_regime_controls


def compare_regimes(
    audit_result: Dict,
    baseline_regime_id: str,
    target_regime_id: str,
) -> Dict:
    """Compare two regime scores side-by-side from an audit result.

    Args:
        audit_result: Full audit result from engine.run_audit().
        baseline_regime_id: Current/baseline regime ID.
        target_regime_id: Target regime to compare against.

    Returns:
        Comparison dict with gap analysis, shared controls, and delta scores.
    """
    regime_scores = audit_result.get("regime_scores", {})
    baseline_scores = regime_scores.get(baseline_regime_id, {})
    target_scores = regime_scores.get(target_regime_id, {})

    if not baseline_scores or "error" in baseline_scores:
        return {"error": f"No scores for baseline regime '{baseline_regime_id}'"}
    if not target_scores or "error" in target_scores:
        return {"error": f"No scores for target regime '{target_regime_id}'"}

    # Build control-level maps
    baseline_controls = _extract_control_map(baseline_scores)
    target_controls = _extract_control_map(target_scores)

    # Identify crosswalk overlaps
    crosswalk_map = _build_crosswalk_map(baseline_regime_id, target_regime_id)

    # Classify controls
    shared = []       # Controls in both regimes (via crosswalk)
    baseline_only = []  # Controls only in baseline
    target_only = []    # Controls only in target (the "gap")

    matched_target_ids = set()

    for ctrl_id, ctrl_data in baseline_controls.items():
        # Check if this control maps to target via crosswalk
        mapped_target_id = crosswalk_map.get(ctrl_id)
        if mapped_target_id and mapped_target_id in target_controls:
            target_ctrl = target_controls[mapped_target_id]
            matched_target_ids.add(mapped_target_id)
            shared.append({
                "baseline_control": ctrl_id,
                "target_control": mapped_target_id,
                "baseline_status": ctrl_data["status"],
                "target_status": target_ctrl["status"],
                "baseline_title": ctrl_data["title"],
                "target_title": target_ctrl["title"],
                "status_match": ctrl_data["status"] == target_ctrl["status"],
                "gap": ctrl_data["status"] == "pass" and target_ctrl["status"] != "pass",
            })
        else:
            baseline_only.append({
                "control_id": ctrl_id,
                "title": ctrl_data["title"],
                "status": ctrl_data["status"],
                "severity": ctrl_data["severity"],
            })

    for ctrl_id, ctrl_data in target_controls.items():
        if ctrl_id not in matched_target_ids:
            target_only.append({
                "control_id": ctrl_id,
                "title": ctrl_data["title"],
                "status": ctrl_data["status"],
                "severity": ctrl_data["severity"],
            })

    # Score delta
    baseline_score = baseline_scores.get("overall_score", 0)
    target_score = target_scores.get("overall_score", 0)

    # Gap analysis: target_only controls that are failing
    gaps = [c for c in target_only if c["status"] in ("fail", "not_assessed")]
    gaps_by_severity = {
        "critical": [g for g in gaps if g["severity"] == "critical"],
        "high": [g for g in gaps if g["severity"] == "high"],
        "medium": [g for g in gaps if g["severity"] == "medium"],
        "low": [g for g in gaps if g["severity"] == "low"],
    }

    return {
        "baseline": {
            "regime_id": baseline_regime_id,
            "regime_name": baseline_scores.get("regime_name", baseline_regime_id),
            "score": baseline_score,
            "grade": baseline_scores.get("grade", "?"),
            "total_controls": baseline_scores.get("summary", {}).get("total_controls", 0),
        },
        "target": {
            "regime_id": target_regime_id,
            "regime_name": target_scores.get("regime_name", target_regime_id),
            "score": target_score,
            "grade": target_scores.get("grade", "?"),
            "total_controls": target_scores.get("summary", {}).get("total_controls", 0),
        },
        "score_delta": round(target_score - baseline_score, 1),
        "shared_controls": len(shared),
        "baseline_only_controls": len(baseline_only),
        "target_only_controls": len(target_only),
        "gap_count": len(gaps),
        "gaps_by_severity": {k: len(v) for k, v in gaps_by_severity.items()},
        "category_comparison": _compare_categories(baseline_scores, target_scores),
        "shared": shared,
        "baseline_only": baseline_only,
        "target_only": target_only,
        "gaps": gaps,
        "recommendation": _generate_gap_recommendation(
            baseline_regime_id, target_regime_id, gaps, baseline_score, target_score
        ),
    }


def _extract_control_map(regime_score: Dict) -> Dict:
    """Extract flat control map from regime score data."""
    controls = {}
    for category in regime_score.get("categories", []):
        for ctrl in category.get("controls", []):
            controls[ctrl["control_id"]] = {
                "title": ctrl.get("title", ""),
                "status": ctrl.get("status", "not_assessed"),
                "severity": ctrl.get("severity", "medium"),
                "category_id": category.get("category_id", ""),
                "category_name": category.get("category_name", ""),
                "evidence_count": ctrl.get("evidence_count", 0),
            }
    return controls


def _build_crosswalk_map(baseline_id: str, target_id: str) -> Dict:
    """Build a mapping from baseline control IDs to target control IDs.

    Uses crosswalk data embedded in regime definitions.
    """
    mapping = {}

    # Get baseline regime controls with crosswalk data
    baseline_controls = get_regime_controls(baseline_id)
    for ctrl in baseline_controls:
        for xwalk in ctrl.get("crosswalk", []):
            if xwalk.get("framework") == target_id or \
               _normalize_framework_id(xwalk.get("framework", "")) == target_id:
                mapping[ctrl["control_id"]] = xwalk["control"]

    # Also build reverse mapping from target
    target_controls = get_regime_controls(target_id)
    for ctrl in target_controls:
        for xwalk in ctrl.get("crosswalk", []):
            if xwalk.get("framework") == baseline_id or \
               _normalize_framework_id(xwalk.get("framework", "")) == baseline_id:
                # Reverse: target control -> baseline control
                if xwalk["control"] not in mapping:
                    mapping[xwalk["control"]] = ctrl["control_id"]

    return mapping


def _normalize_framework_id(fw: str) -> str:
    """Normalize framework IDs for comparison."""
    aliases = {
        "nist_800_53": "nist_800_53",
        "nist_800_171": "nist_800_171",
        "fedramp_moderate": "fedramp_moderate",
        "fedramp": "fedramp_moderate",
        "cmmc_l2": "cmmc_l2",
        "cmmc_level_2": "cmmc_l2",
    }
    return aliases.get(fw, fw)


def _compare_categories(baseline: Dict, target: Dict) -> List[Dict]:
    """Compare category-level scores between two regimes."""
    baseline_cats = {c["category_id"]: c for c in baseline.get("categories", [])}
    target_cats = {c["category_id"]: c for c in target.get("categories", [])}

    all_cat_ids = sorted(set(list(baseline_cats.keys()) + list(target_cats.keys())))

    comparisons = []
    for cat_id in all_cat_ids:
        b = baseline_cats.get(cat_id, {})
        t = target_cats.get(cat_id, {})
        comparisons.append({
            "category_id": cat_id,
            "category_name": b.get("category_name") or t.get("category_name", cat_id),
            "baseline_score": b.get("score", None),
            "target_score": t.get("score", None),
            "delta": round((t.get("score", 0) or 0) - (b.get("score", 0) or 0), 1)
                if b.get("score") is not None and t.get("score") is not None else None,
            "in_baseline": cat_id in baseline_cats,
            "in_target": cat_id in target_cats,
        })

    return comparisons


def _generate_gap_recommendation(
    baseline_id: str, target_id: str,
    gaps: List[Dict], baseline_score: float, target_score: float
) -> str:
    """Generate a human-readable gap recommendation summary."""
    if not gaps:
        return (f"Your {baseline_id} posture covers all {target_id} requirements. "
                f"No additional controls needed.")

    critical = sum(1 for g in gaps if g["severity"] == "critical")
    high = sum(1 for g in gaps if g["severity"] == "high")
    medium = sum(1 for g in gaps if g["severity"] == "medium")

    parts = []
    parts.append(f"To move from {baseline_id} to {target_id}, "
                 f"you need to address {len(gaps)} additional controls.")

    if critical:
        parts.append(f"PRIORITY: {critical} critical controls require immediate attention.")
    if high:
        parts.append(f"{high} high-severity controls should be addressed next.")
    if medium:
        parts.append(f"{medium} medium-severity controls for full compliance.")

    return " ".join(parts)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Audit Regime Comparator")
    parser.add_argument("--baseline", required=True, help="Baseline regime ID")
    parser.add_argument("--target", required=True, help="Target regime ID")
    parser.add_argument("--audit-file", type=str, help="Path to audit result JSON")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    if args.audit_file:
        with open(args.audit_file, "r") as f:
            audit_result = json.load(f)
    else:
        # Run a fresh audit with both regimes
        from tools.audit_engine.engine import run_audit
        audit_result = run_audit(
            target_path=".",
            regime_ids=[args.baseline, args.target],
            store_results=False,
        )

    result = compare_regimes(audit_result, args.baseline, args.target)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        if "error" in result:
            print(f"Error: {result['error']}")
            sys.exit(1)

        b = result["baseline"]
        t = result["target"]
        print(f"\n{'='*70}")
        print(f"  REGIME COMPARISON: {b['regime_name']} vs {t['regime_name']}")
        print(f"{'='*70}\n")
        print(f"  {'':30s}  {'Baseline':>10s}  {'Target':>10s}  {'Delta':>8s}")
        print(f"  {'Score':30s}  {b['score']:>9.1f}%  {t['score']:>9.1f}%  {result['score_delta']:>+7.1f}%")
        print(f"  {'Grade':30s}  {b['grade']:>10s}  {t['grade']:>10s}")
        print(f"  {'Total Controls':30s}  {b['total_controls']:>10d}  {t['total_controls']:>10d}")
        print(f"\n  Shared Controls:        {result['shared_controls']}")
        print(f"  Baseline Only:          {result['baseline_only_controls']}")
        print(f"  Target Only (gaps):     {result['target_only_controls']}")
        print(f"  Failing Gaps:           {result['gap_count']}")

        if result["gaps_by_severity"]:
            print(f"\n  Gap Severity Breakdown:")
            for sev, count in result["gaps_by_severity"].items():
                if count > 0:
                    print(f"    {sev:10s}: {count}")

        print(f"\n  Recommendation: {result['recommendation']}")
        print(f"\n{'='*70}")
        print(f"  CUI // SP-CTI")
        print(f"{'='*70}")
