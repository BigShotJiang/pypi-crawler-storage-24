#!/usr/bin/env python3
# CUI // SP-CTI
# Controlled by: Department of Defense
# CUI Category: CTI
# Distribution: D
# POC: ICDEV System Administrator
"""Regime Updater — Auto-fetch and apply regime definition updates.

Checks for regime definition updates from a configurable source
(local directory, git repository, or URL). Validates incoming
regime files before applying, preserving user customizations.

Usage:
    # Check for updates (dry run)
    python tools/audit_engine/regime_updater.py --check --json

    # Apply updates
    python tools/audit_engine/regime_updater.py --update --json

    # Import a regime from file
    python tools/audit_engine/regime_updater.py --import-file /path/to/regime.json --json

    # Export all regimes (for sharing)
    python tools/audit_engine/regime_updater.py --export --output /path/to/export/ --json
"""

import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

BASE_DIR = Path(__file__).resolve().parent.parent.parent
REGIMES_DIR = BASE_DIR / "args" / "audit_regimes"
UPDATE_SOURCE_DIR = BASE_DIR / "args" / "audit_regimes" / ".updates"


def check_for_updates(source_dir: Optional[str] = None) -> Dict:
    """Check for regime definition updates.

    Args:
        source_dir: Optional override for update source directory.

    Returns:
        Dict with available updates and version comparisons.
    """
    src = Path(source_dir) if source_dir else UPDATE_SOURCE_DIR

    current_regimes = _get_installed_regimes()
    updates_available = []
    new_regimes = []

    if not src.exists():
        return {
            "success": True,
            "source": str(src),
            "updates_available": [],
            "new_regimes": [],
            "message": "No update source directory found. Place updated regime files in .updates/",
        }

    for path in sorted(src.glob("*.json")):
        try:
            incoming = json.loads(path.read_text(encoding="utf-8"))
            incoming_meta = incoming.get("regime", {})
            regime_id = incoming_meta.get("id", path.stem)

            if regime_id in current_regimes:
                current = current_regimes[regime_id]
                current_version = current.get("version", "0")
                incoming_version = incoming_meta.get("version", "0")

                if incoming_version != current_version:
                    updates_available.append({
                        "regime_id": regime_id,
                        "current_version": current_version,
                        "incoming_version": incoming_version,
                        "source_file": str(path),
                        "current_hash": current.get("hash", ""),
                        "incoming_hash": _hash_file(path),
                    })
            else:
                new_regimes.append({
                    "regime_id": regime_id,
                    "name": incoming_meta.get("name", regime_id),
                    "version": incoming_meta.get("version", ""),
                    "source_file": str(path),
                })
        except (json.JSONDecodeError, Exception) as e:
            print(f"Warning: Invalid regime file {path.name}: {e}", file=sys.stderr)

    return {
        "success": True,
        "source": str(src),
        "updates_available": updates_available,
        "new_regimes": new_regimes,
        "total_installed": len(current_regimes),
    }


def apply_updates(source_dir: Optional[str] = None,
                  backup: bool = True) -> Dict:
    """Apply regime definition updates.

    Args:
        source_dir: Optional override for update source directory.
        backup: Whether to backup current regimes before updating.

    Returns:
        Dict with applied updates summary.
    """
    check = check_for_updates(source_dir)
    src = Path(source_dir) if source_dir else UPDATE_SOURCE_DIR

    applied = []
    errors = []

    # Create backup if requested
    if backup and (check["updates_available"] or check["new_regimes"]):
        backup_dir = REGIMES_DIR / ".backup" / datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        backup_dir.mkdir(parents=True, exist_ok=True)
        for path in REGIMES_DIR.glob("*.json"):
            shutil.copy2(path, backup_dir / path.name)

    # Apply updates
    for update in check["updates_available"]:
        try:
            src_file = Path(update["source_file"])
            # Validate before applying
            incoming = json.loads(src_file.read_text(encoding="utf-8"))
            if not _validate_regime(incoming):
                errors.append({"regime_id": update["regime_id"], "error": "Validation failed"})
                continue

            dest = REGIMES_DIR / f"{update['regime_id']}.json"
            shutil.copy2(src_file, dest)
            applied.append({
                "regime_id": update["regime_id"],
                "action": "updated",
                "from_version": update["current_version"],
                "to_version": update["incoming_version"],
            })
        except Exception as e:
            errors.append({"regime_id": update["regime_id"], "error": str(e)})

    # Install new regimes
    for new in check["new_regimes"]:
        try:
            src_file = Path(new["source_file"])
            incoming = json.loads(src_file.read_text(encoding="utf-8"))
            if not _validate_regime(incoming):
                errors.append({"regime_id": new["regime_id"], "error": "Validation failed"})
                continue

            dest = REGIMES_DIR / f"{new['regime_id']}.json"
            shutil.copy2(src_file, dest)
            applied.append({
                "regime_id": new["regime_id"],
                "action": "installed",
                "version": new["version"],
            })
        except Exception as e:
            errors.append({"regime_id": new["regime_id"], "error": str(e)})

    return {
        "success": len(errors) == 0,
        "applied": applied,
        "errors": errors,
        "backup_created": backup and bool(applied),
    }


def import_regime(file_path: str) -> Dict:
    """Import a single regime definition file.

    Args:
        file_path: Path to regime JSON file to import.

    Returns:
        Import result dict.
    """
    path = Path(file_path)
    if not path.exists():
        return {"success": False, "error": f"File not found: {file_path}"}

    try:
        content = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        return {"success": False, "error": f"Invalid JSON: {e}"}

    if not _validate_regime(content):
        return {"success": False, "error": "Regime validation failed — missing required fields"}

    regime_id = content.get("regime", {}).get("id", path.stem)
    dest = REGIMES_DIR / f"{regime_id}.json"

    # Check for existing
    is_update = dest.exists()
    if is_update:
        # Backup existing
        backup_path = REGIMES_DIR / ".backup"
        backup_path.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dest, backup_path / f"{regime_id}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json")

    shutil.copy2(path, dest)

    return {
        "success": True,
        "regime_id": regime_id,
        "action": "updated" if is_update else "installed",
        "name": content.get("regime", {}).get("name", regime_id),
        "version": content.get("regime", {}).get("version", ""),
        "destination": str(dest),
    }


def export_regimes(output_dir: str) -> Dict:
    """Export all installed regime definitions.

    Args:
        output_dir: Directory to export regime files to.

    Returns:
        Export summary dict.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    exported = []
    for path in sorted(REGIMES_DIR.glob("*.json")):
        dest = out / path.name
        shutil.copy2(path, dest)
        exported.append({
            "file": path.name,
            "size": path.stat().st_size,
            "hash": _hash_file(path),
        })

    return {
        "success": True,
        "output_dir": str(out),
        "exported_count": len(exported),
        "files": exported,
    }


def _get_installed_regimes() -> Dict:
    """Get map of installed regimes with metadata."""
    regimes = {}
    for path in REGIMES_DIR.glob("*.json"):
        try:
            content = json.loads(path.read_text(encoding="utf-8"))
            meta = content.get("regime", {})
            rid = meta.get("id", path.stem)
            regimes[rid] = {
                "version": meta.get("version", "unknown"),
                "name": meta.get("name", rid),
                "file_path": str(path),
                "hash": _hash_file(path),
            }
        except Exception:
            continue
    return regimes


def _validate_regime(content: Dict) -> bool:
    """Validate regime definition structure."""
    if not isinstance(content, dict):
        return False
    if "regime" not in content:
        return False
    meta = content["regime"]
    if not meta.get("id") or not meta.get("name"):
        return False
    if "categories" not in content:
        return False
    if not isinstance(content["categories"], list):
        return False
    for cat in content["categories"]:
        if not cat.get("id") or not cat.get("name"):
            return False
        if "controls" not in cat or not isinstance(cat["controls"], list):
            return False
    return True


def _hash_file(path: Path) -> str:
    """SHA-256 hash of file content (for tamper detection, per D-INV-5)."""
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16]


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Audit Regime Updater")
    parser.add_argument("--check", action="store_true", help="Check for updates")
    parser.add_argument("--update", action="store_true", help="Apply updates")
    parser.add_argument("--import-file", type=str, help="Import a regime file")
    parser.add_argument("--export", action="store_true", help="Export all regimes")
    parser.add_argument("--output", type=str, help="Export output directory")
    parser.add_argument("--source", type=str, help="Update source directory")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    if args.check:
        result = check_for_updates(args.source)
    elif args.update:
        result = apply_updates(args.source)
    elif args.import_file:
        result = import_regime(args.import_file)
    elif args.export:
        if not args.output:
            print("Error: --output required for export", file=sys.stderr)
            sys.exit(1)
        result = export_regimes(args.output)
    else:
        parser.print_help()
        sys.exit(0)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(json.dumps(result, indent=2))
