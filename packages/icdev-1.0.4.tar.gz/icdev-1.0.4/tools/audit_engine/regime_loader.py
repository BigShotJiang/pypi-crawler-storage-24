#!/usr/bin/env python3
# CUI // SP-CTI
# Controlled by: Department of Defense
# CUI Category: CTI
# Distribution: D
# POC: ICDEV System Administrator
"""Regime Loader — Load compliance regime definitions from YAML.

Reads drop-in YAML files from args/audit_regimes/ and normalizes them
into a unified regime model that the audit engine can evaluate against.

Users can add custom regimes (HIPAA, PCI-DSS, SOX, etc.) by dropping
a YAML file into args/audit_regimes/ without modifying core code.
"""

import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional

BASE_DIR = Path(__file__).resolve().parent.parent.parent
REGIMES_DIR = BASE_DIR / "args" / "audit_regimes"


def _try_load_yaml(text: str) -> Optional[dict]:
    """Attempt to load YAML using PyYAML if available, else return None.

    For complex nested structures (regime definitions), JSON format
    is preferred. YAML support is a convenience for simple configs.
    """
    try:
        import yaml
        return yaml.safe_load(text)
    except ImportError:
        return None
    except Exception:
        return None


def load_regime(regime_id: str) -> Optional[Dict]:
    """Load a single regime definition by ID.

    Args:
        regime_id: The regime identifier (e.g., 'nist_800_53', 'fedramp_moderate')

    Returns:
        Parsed regime dict or None if not found.
    """
    # Try exact filename match first (JSON preferred, then YAML)
    candidates = [
        REGIMES_DIR / f"{regime_id}.json",
        REGIMES_DIR / f"{regime_id}.yaml",
        REGIMES_DIR / f"{regime_id}.yml",
    ]
    for path in candidates:
        if path.exists():
            return _load_regime_file(path)

    # Search all files for matching regime.id
    for ext in ("*.json", "*.yaml", "*.yml"):
        for path in REGIMES_DIR.glob(ext):
            regime = _load_regime_file(path)
            if regime and regime.get("regime", {}).get("id") == regime_id:
                return regime

    return None


def _load_regime_file(path: Path) -> Optional[Dict]:
    """Load and parse a regime YAML file."""
    try:
        text = path.read_text(encoding="utf-8")
        # JSON files (preferred for complex nested structures)
        if path.suffix == ".json" or text.strip().startswith("{"):
            return json.loads(text)
        # YAML files (convenience, requires PyYAML)
        return _try_load_yaml(text)
    except Exception as e:
        print(f"Warning: Failed to load regime {path.name}: {e}", file=sys.stderr)
        return None


def list_regimes() -> List[Dict]:
    """List all available regime definitions.

    Returns:
        List of dicts with id, name, version, file_path for each regime.
    """
    regimes = []
    seen_ids = set()

    for ext in ("*.json", "*.yaml", "*.yml"):
        for path in sorted(REGIMES_DIR.glob(ext)):
            regime = _load_regime_file(path)
            if not regime:
                continue
            meta = regime.get("regime", {})
            rid = meta.get("id", path.stem)
            if rid in seen_ids:
                continue
            seen_ids.add(rid)
            regimes.append({
                "id": rid,
                "name": meta.get("name", rid),
                "version": meta.get("version", "unknown"),
                "last_updated": meta.get("last_updated", "unknown"),
                "category_count": len(regime.get("categories", [])),
                "file_path": str(path),
            })

    return regimes


def get_regime_controls(regime_id: str) -> List[Dict]:
    """Get flattened list of all controls in a regime.

    Returns:
        List of dicts with category_id, category_name, control_id, title, severity, etc.
    """
    regime = load_regime(regime_id)
    if not regime:
        return []

    controls = []
    for category in regime.get("categories", []):
        cat_id = category.get("id", "")
        cat_name = category.get("name", "")
        for ctrl in category.get("controls", []):
            controls.append({
                "category_id": cat_id,
                "category_name": cat_name,
                "control_id": ctrl.get("id", ""),
                "title": ctrl.get("title", ""),
                "severity": ctrl.get("severity", "medium"),
                "evidence_sources": ctrl.get("evidence_sources", []),
                "scoring": ctrl.get("scoring", {}),
                "crosswalk": ctrl.get("crosswalk", []),
            })

    return controls


def get_regime_metadata(regime_id: str) -> Optional[Dict]:
    """Get metadata for a regime without loading full control catalog."""
    regime = load_regime(regime_id)
    if not regime:
        return None
    meta = regime.get("regime", {})
    total_controls = sum(
        len(cat.get("controls", []))
        for cat in regime.get("categories", [])
    )
    return {
        "id": meta.get("id", regime_id),
        "name": meta.get("name", regime_id),
        "version": meta.get("version", "unknown"),
        "last_updated": meta.get("last_updated", "unknown"),
        "total_controls": total_controls,
        "categories": [
            {"id": c.get("id"), "name": c.get("name"),
             "control_count": len(c.get("controls", []))}
            for c in regime.get("categories", [])
        ],
    }


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Audit Regime Loader")
    parser.add_argument("--list", action="store_true", help="List all regimes")
    parser.add_argument("--get", type=str, help="Get regime by ID")
    parser.add_argument("--controls", type=str, help="List controls for regime")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    if args.list:
        result = list_regimes()
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            for r in result:
                print(f"  {r['id']:30s} {r['name']:40s} v{r['version']}  ({r['category_count']} categories)")
    elif args.get:
        result = get_regime_metadata(args.get)
        if result:
            print(json.dumps(result, indent=2) if args.json else f"{result['name']} — {result['total_controls']} controls")
        else:
            print(f"Regime '{args.get}' not found.", file=sys.stderr)
            sys.exit(1)
    elif args.controls:
        result = get_regime_controls(args.controls)
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            for c in result:
                print(f"  [{c['category_id']}] {c['control_id']:15s} {c['title']}")
    else:
        parser.print_help()
