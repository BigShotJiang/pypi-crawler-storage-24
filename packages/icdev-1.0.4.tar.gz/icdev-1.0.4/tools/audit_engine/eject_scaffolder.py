#!/usr/bin/env python3
# CUI // SP-CTI
# Controlled by: Department of Defense
# CUI Category: CTI
# Distribution: D
# POC: ICDEV System Administrator
"""Audit Engine Eject Scaffolder — Package as standalone application.

Generates a fully self-contained audit engine application with:
- All audit engine source files
- All regime definitions
- Standalone Flask dashboard
- Built-in scanners (no ICDEV tool dependencies)
- CLI for headless/CI usage
- Own SQLite database for audit history

The ejected app has ZERO runtime dependency on ICDEV.

Usage:
    python tools/audit_engine/eject_scaffolder.py --output /path/to/output --json
"""

import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional

BASE_DIR = Path(__file__).resolve().parent.parent.parent
AUDIT_ENGINE_DIR = BASE_DIR / "tools" / "audit_engine"
REGIMES_DIR = BASE_DIR / "args" / "audit_regimes"


def eject_audit_engine(
    output_dir: str,
    project_name: str = "audit-engine",
    include_dashboard: bool = True,
) -> Dict:
    """Eject the audit engine as a standalone application.

    Args:
        output_dir: Directory to write the ejected project.
        project_name: Name for the ejected project.
        include_dashboard: Include Flask dashboard (default: True).

    Returns:
        Eject result dict with file list and instructions.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    files_created = []

    # 1. Core audit engine files
    src_dir = out / "audit_engine"
    src_dir.mkdir(exist_ok=True)

    core_files = [
        "__init__.py", "engine.py", "scanner.py", "regime_loader.py",
        "report_card.py", "comparator.py", "ai_advisor.py",
        "git_fetcher.py", "regime_updater.py", "cli.py",
    ]
    for fname in core_files:
        src = AUDIT_ENGINE_DIR / fname
        if src.exists():
            content = src.read_text(encoding="utf-8")
            # Rewrite imports to be local (remove tools. prefix)
            content = _rewrite_imports(content)
            (src_dir / fname).write_text(content, encoding="utf-8")
            files_created.append(f"audit_engine/{fname}")

    # 2. Regime definitions
    regimes_out = out / "regimes"
    regimes_out.mkdir(exist_ok=True)
    for path in REGIMES_DIR.glob("*.json"):
        shutil.copy2(path, regimes_out / path.name)
        files_created.append(f"regimes/{path.name}")

    # 3. Storage layer (minimal standalone)
    _write_standalone_storage(out / "audit_engine" / "storage.py")
    files_created.append("audit_engine/storage.py")

    # 4. Dashboard (if included)
    if include_dashboard:
        _write_standalone_dashboard(out)
        files_created.extend([
            "app.py",
            "templates/base.html",
            "templates/audit_engine.html",
        ])

    # 5. CLI wrapper
    _write_cli_wrapper(out, project_name)
    files_created.append("run_audit.py")

    # 6. Configuration
    _write_config(out, project_name)
    files_created.extend([
        "config.json",
        "requirements.txt",
        "README.md",
        ".gitignore",
    ])

    # 7. Dockerfile
    _write_dockerfile(out, project_name)
    files_created.extend(["Dockerfile", "docker-compose.yml"])

    # Log audit event
    try:
        from tools.db.storage import get_connection
        with get_connection() as conn:
            conn.execute(
                """INSERT INTO audit_trail
                   (project_id, event_type, actor, action, details,
                    affected_files, classification)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    "audit-engine",
                    "audit_engine_ejected",
                    "icdev-audit-engine",
                    f"Ejected audit engine to {output_dir}",
                    json.dumps({"files": len(files_created), "dashboard": include_dashboard}),
                    json.dumps([output_dir]),
                    "CUI",
                ),
            )
            conn.commit()
    except Exception:
        pass

    return {
        "success": True,
        "output_dir": str(out),
        "project_name": project_name,
        "files_created": files_created,
        "file_count": len(files_created),
        "includes_dashboard": include_dashboard,
        "instructions": [
            f"cd {output_dir}",
            "pip install -r requirements.txt",
            "python run_audit.py scan --target /path/to/code --json",
            "python app.py  # Start dashboard on http://localhost:5055",
        ],
    }


def _rewrite_imports(content: str) -> str:
    """Rewrite ICDEV-specific imports for standalone usage."""
    replacements = [
        ("from tools.audit_engine.", "from audit_engine."),
        ("from tools.db.storage import get_connection", "from audit_engine.storage import get_connection"),
        ("from tools.security.sast_runner import", "# from tools.security.sast_runner import"),
        ("from tools.security.secret_detector import", "# from tools.security.secret_detector import"),
        ("from tools.security.dependency_auditor import", "# from tools.security.dependency_auditor import"),
        ("from tools.compliance.stig_checker import", "# from tools.compliance.stig_checker import"),
        ("from tools.compliance.sbom_generator import", "# from tools.compliance.sbom_generator import"),
        ("from tools.compliance.sbd_assessor import", "# from tools.compliance.sbd_assessor import"),
        ("from tools.llm.router import", "# from tools.llm.router import"),
    ]
    for old, new in replacements:
        content = content.replace(old, new)
    return content


def _write_standalone_storage(path: Path):
    """Write a minimal standalone storage layer."""
    path.write_text('''#!/usr/bin/env python3
"""Standalone SQLite storage for ejected audit engine."""
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "audit.db"


def get_connection(db_path=None):
    """Get SQLite connection."""
    p = Path(db_path) if db_path else DB_PATH
    p.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(p))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn
''', encoding="utf-8")


def _write_standalone_dashboard(out: Path):
    """Write a minimal Flask dashboard for standalone usage."""
    # Copy template from ICDEV
    templates_dir = out / "templates"
    templates_dir.mkdir(exist_ok=True)

    # Minimal base template
    (templates_dir / "base.html").write_text('''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Audit Engine{% endblock %}</title>
    <style>
        :root { --bg: #0f172a; --surface: #1e293b; --surface2: #334155; --border: #475569;
                --text: #e2e8f0; --text-dim: #94a3b8; --accent: #6366f1; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
               background: var(--bg); color: var(--text); }
        a { color: var(--accent); text-decoration: none; }
    </style>
</head>
<body>{% block content %}{% endblock %}</body>
</html>
''', encoding="utf-8")

    # Copy audit engine template
    ae_template = BASE_DIR / "tools" / "dashboard" / "templates" / "audit_engine.html"
    if ae_template.exists():
        shutil.copy2(ae_template, templates_dir / "audit_engine.html")

    # App file
    (out / "app.py").write_text('''#!/usr/bin/env python3
"""Standalone Audit Engine Dashboard."""
import json
from flask import Flask, render_template, jsonify, request

app = Flask(__name__)
app.secret_key = "audit-engine-standalone"

@app.route("/")
def index():
    return render_template("audit_engine.html")

@app.route("/api/audit-engine/run", methods=["POST"])
def api_run():
    from audit_engine.engine import run_audit
    data = request.get_json(force=True)
    target = data.get("target", ".")
    clone_path = None
    if data.get("type") == "byos" and (target.startswith("http") or target.startswith("git@")):
        from audit_engine.git_fetcher import fetch_repo, cleanup_clone
        fetch = fetch_repo(url=target, auth_method=data.get("auth_method", "auto"),
                           token=data.get("token"), ssh_key=data.get("ssh_key"))
        if not fetch.get("success"):
            return jsonify(fetch), 400
        clone_path = fetch["clone_path"]
        target = clone_path
    result = run_audit(target_path=target, target_type=data.get("type", "auto"),
                       project_id=data.get("project_id"), store_results=True)
    if clone_path:
        from audit_engine.git_fetcher import cleanup_clone
        cleanup_clone(clone_path)
    return jsonify(result)

@app.route("/api/audit-engine/compare", methods=["POST"])
def api_compare():
    from audit_engine.comparator import compare_regimes
    data = request.get_json(force=True)
    return jsonify(compare_regimes(data.get("audit_result", {}), data.get("baseline"), data.get("target")))

@app.route("/api/audit-engine/advise", methods=["POST"])
def api_advise():
    from audit_engine.ai_advisor import generate_recommendations
    data = request.get_json(force=True)
    return jsonify(generate_recommendations(data.get("audit_result", {}), regime_id=data.get("regime_id")))

@app.route("/api/audit-engine/regimes", methods=["GET"])
def api_regimes():
    from audit_engine.regime_loader import list_regimes
    return jsonify(list_regimes())

if __name__ == "__main__":
    print("Audit Engine Dashboard: http://localhost:5055")
    app.run(host="127.0.0.1", port=5055, debug=True)
''', encoding="utf-8")


def _write_cli_wrapper(out: Path, project_name: str):
    """Write CLI wrapper script."""
    (out / "run_audit.py").write_text(f'''#!/usr/bin/env python3
"""{project_name} — Standalone Compliance Audit Engine."""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from audit_engine.cli import main
main()
''', encoding="utf-8")


def _write_config(out: Path, project_name: str):
    """Write configuration files."""
    (out / "config.json").write_text(json.dumps({
        "project_name": project_name,
        "version": "1.0.0",
        "regimes_dir": "regimes",
        "database": "data/audit.db",
        "dashboard_port": 5055,
    }, indent=2), encoding="utf-8")

    (out / "requirements.txt").write_text(
        "flask>=3.0\n", encoding="utf-8"
    )

    (out / "README.md").write_text(f'''# {project_name}

Standalone Compliance Audit Engine — ejected from ICDEV.

## Quick Start

```bash
pip install -r requirements.txt

# Run audit via CLI
python run_audit.py scan --target /path/to/code --json

# Start dashboard
python app.py
# Open http://localhost:5055
```

## Supported Regimes

- NIST SP 800-53 Rev 5
- NIST SP 800-171 Rev 2
- FedRAMP Moderate
- CMMC Level 2
- CISA Secure by Design
- DoD CSSP (DI 8530.01)
- IEEE 1012 IV&V
- DoDI 5000.87 DES

## Add Custom Regimes

Drop a JSON file into `regimes/` following the regime schema.

---
CUI // SP-CTI
''', encoding="utf-8")

    (out / ".gitignore").write_text(
        "data/\n.tmp/\n__pycache__/\n*.pyc\n.env\n", encoding="utf-8"
    )


def _write_dockerfile(out: Path, project_name: str):
    """Write Docker files for containerized deployment."""
    (out / "Dockerfile").write_text(f'''FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
RUN useradd -r -s /bin/false appuser
USER appuser
EXPOSE 5055
CMD ["python", "app.py"]
''', encoding="utf-8")

    (out / "docker-compose.yml").write_text(f'''version: "3.8"
services:
  {project_name}:
    build: .
    ports:
      - "5055:5055"
    volumes:
      - audit-data:/app/data
    read_only: true
    tmpfs:
      - /tmp
    security_opt:
      - no-new-privileges:true

volumes:
  audit-data:
''', encoding="utf-8")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Eject Audit Engine")
    parser.add_argument("--output", required=True, help="Output directory")
    parser.add_argument("--name", default="audit-engine", help="Project name")
    parser.add_argument("--no-dashboard", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    result = eject_audit_engine(
        output_dir=args.output,
        project_name=args.name,
        include_dashboard=not args.no_dashboard,
    )

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"\nEjected to: {result['output_dir']}")
        print(f"Files: {result['file_count']}")
        print(f"\nNext steps:")
        for step in result.get("instructions", []):
            print(f"  {step}")
