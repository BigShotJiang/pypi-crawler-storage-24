#!/usr/bin/env python3
# CUI // SP-CTI
# Controlled by: Department of Defense
# CUI Category: CTI
# Distribution: D
# POC: ICDEV System Administrator
"""Audit Scanner — Collect evidence from multiple sources.

Runs ICDEV security/compliance tools and collects findings into a
normalized evidence format that the audit engine can score against
regime controls.

Supports four target types:
  - icdev: Full ICDEV installation (direct tool access)
  - module: ICDEV module directory
  - child_app: Generated child application
  - byos: Bring-your-own-software (directory or git clone)
"""

import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

BASE_DIR = Path(__file__).resolve().parent.parent.parent

# Directories to skip during file scanning (vendored, third-party, build artifacts)
SCAN_SKIP_DIRS = {
    ".git", "node_modules", "venv", "__pycache__", ".tmp", "vendor", "dist",
    "build", "data", ".venv", "env", ".env", "site-packages", ".mypy_cache",
    ".pytest_cache", ".tox", "coverage", "htmlcov", ".aws-sam", "deps",
    "clean-build", ".serverless", "cdk.out", ".terraform", "egg-info",
    ".eggs", "bower_components", "jspm_packages", ".next", ".nuxt",
    "marketplace-saas",  # SaaS portal has its own lifecycle
}

# Evidence severity normalization
SEVERITY_MAP = {
    "critical": "critical",
    "high": "high",
    "medium": "medium",
    "moderate": "medium",
    "low": "low",
    "info": "info",
    "informational": "info",
}


class AuditEvidence:
    """Normalized evidence container from a single scan source."""

    def __init__(self, source: str, tool: str):
        self.source = source
        self.tool = tool
        self.findings: List[Dict] = []
        self.summary: Dict = {}
        self.success: bool = False
        self.error: Optional[str] = None
        self.timestamp = datetime.now(timezone.utc).isoformat()

    def add_finding(self, control_hint: str, severity: str, title: str,
                    description: str, file_path: Optional[str] = None,
                    line: Optional[int] = None, status: str = "fail"):
        """Add a normalized finding."""
        self.findings.append({
            "control_hint": control_hint,
            "severity": SEVERITY_MAP.get(severity.lower(), "medium"),
            "title": title,
            "description": description,
            "file_path": file_path,
            "line": line,
            "status": status,  # pass, fail, partial, not_applicable
        })

    def to_dict(self) -> Dict:
        return {
            "source": self.source,
            "tool": self.tool,
            "success": self.success,
            "findings_count": len(self.findings),
            "findings": self.findings,
            "summary": self.summary,
            "error": self.error,
            "timestamp": self.timestamp,
        }


def scan_target(target_path: str, target_type: str = "auto",
                project_id: Optional[str] = None,
                skip_tools: Optional[List[str]] = None) -> Dict:
    """Run all applicable scanners on a target.

    Args:
        target_path: Directory path to scan.
        target_type: One of 'icdev', 'module', 'child_app', 'byos', 'auto'.
        project_id: Optional project ID for ICDEV tool integration.
        skip_tools: Optional list of tool names to skip.

    Returns:
        Dict with evidence from all scanners, keyed by source name.
    """
    target_path = os.path.abspath(target_path)
    skip = set(skip_tools or [])

    if target_type == "auto":
        target_type = _detect_target_type(target_path)

    results = {
        "target_path": target_path,
        "target_type": target_type,
        "project_id": project_id,
        "scan_timestamp": datetime.now(timezone.utc).isoformat(),
        "evidence": {},
    }

    # Determine which scanners to run based on target type
    scanners = _get_scanners_for_type(target_type)

    for scanner_name, scanner_fn in scanners:
        if scanner_name in skip:
            continue
        try:
            evidence = scanner_fn(target_path, project_id)
            results["evidence"][scanner_name] = evidence.to_dict()
        except Exception as e:
            err_evidence = AuditEvidence(scanner_name, scanner_name)
            err_evidence.error = str(e)
            results["evidence"][scanner_name] = err_evidence.to_dict()

    # Compute aggregate summary
    total_findings = 0
    severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for ev in results["evidence"].values():
        total_findings += ev.get("findings_count", 0)
        for f in ev.get("findings", []):
            sev = f.get("severity", "medium")
            severity_counts[sev] = severity_counts.get(sev, 0) + 1

    results["summary"] = {
        "total_findings": total_findings,
        "severity_counts": severity_counts,
        "scanners_run": len(results["evidence"]),
        "scanners_succeeded": sum(
            1 for e in results["evidence"].values() if e.get("success")
        ),
    }

    return results


def _detect_target_type(target_path: str) -> str:
    """Auto-detect target type from directory contents."""
    p = Path(target_path)

    # ICDEV itself
    if (p / "tools" / "audit_engine").exists() and (p / "CLAUDE.md").exists():
        return "icdev"

    # Child app (has CLAUDE.md but no audit_engine)
    if (p / "CLAUDE.md").exists() and (p / "tools").exists():
        return "child_app"

    # Module (has __init__.py and manifest or pyproject.toml inside tools/)
    if (p / "__init__.py").exists() and (p.parent.name == "tools" or (p / "manifest.md").exists()):
        return "module"

    return "byos"


def _get_scanners_for_type(target_type: str) -> List[tuple]:
    """Return list of (name, function) scanners for target type."""
    # Core scanners available for all types
    scanners = [
        ("sast", _scan_sast),
        ("secrets", _scan_secrets),
        ("dependencies", _scan_dependencies),
        ("code_patterns", _scan_code_patterns),
        ("file_permissions", _scan_file_permissions),
    ]

    # ICDEV-specific scanners
    if target_type in ("icdev", "child_app"):
        scanners.extend([
            ("stig", _scan_stig),
            ("sbom", _scan_sbom),
            ("cui_markings", _scan_cui_markings),
            ("sbd", _scan_sbd),
        ])

    # Module-specific
    if target_type == "module":
        scanners.extend([
            ("module_manifest", _scan_module_manifest),
            ("cui_markings", _scan_cui_markings),
        ])

    return scanners


# -----------------------------------------------------------------
# Individual Scanners
# -----------------------------------------------------------------

def _scan_sast(target_path: str, project_id: Optional[str]) -> AuditEvidence:
    """Run SAST analysis using fast builtin patterns (skip_dirs + file caps)."""
    # Always use the fast fallback scanner — ICDEV sast_runner walks the full
    # tree without caps and is too slow for interactive dashboard use.
    return _scan_sast_fallback(target_path)


def _scan_sast_fallback(target_path: str) -> AuditEvidence:
    """Fallback SAST using basic pattern matching (for BYOS/air-gap)."""
    ev = AuditEvidence("sast", "builtin_patterns")

    dangerous_patterns = [
        (r"\beval\s*\(", "eval() usage", "SI-10", "high"),
        (r"\bexec\s*\(", "exec() usage", "SI-10", "high"),
        (r"subprocess\.call\s*\(.*shell\s*=\s*True", "Shell injection risk", "SI-10", "critical"),
        (r"os\.system\s*\(", "os.system() usage", "SI-10", "high"),
        (r"__import__\s*\(", "Dynamic import", "SI-10", "medium"),
        (r"pickle\.loads?\s*\(", "Unsafe deserialization", "SI-10", "high"),
        (r"yaml\.load\s*\((?!.*Loader)", "Unsafe YAML load", "SI-10", "high"),
        (r"SELECT\s+.*\+.*(?:request|input|param)", "Possible SQL injection", "SI-10", "critical"),
        (r"innerHTML\s*=", "Possible XSS via innerHTML", "SI-10", "high"),
        (r"document\.write\s*\(", "Possible XSS via document.write", "SI-10", "high"),
    ]

    scan_extensions = {".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rs", ".c", ".cpp", ".cs"}
    skip_dirs = SCAN_SKIP_DIRS

    finding_count = 0
    for root, dirs, files in os.walk(target_path):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for fname in files:
            ext = Path(fname).suffix.lower()
            if ext not in scan_extensions:
                continue
            fpath = os.path.join(root, fname)
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    for line_num, line in enumerate(f, 1):
                        for pattern, msg, ctrl, sev in dangerous_patterns:
                            if re.search(pattern, line):
                                rel_path = os.path.relpath(fpath, target_path)
                                ev.add_finding(ctrl, sev, msg, f"{msg} at {rel_path}:{line_num}",
                                               file_path=rel_path, line=line_num)
                                finding_count += 1
            except (OSError, UnicodeDecodeError):
                continue

    ev.success = True
    ev.summary = {"total_findings": finding_count}
    if finding_count == 0:
        ev.add_finding("SI-10", "info", "SAST Clean", "No dangerous patterns found", status="pass")
    return ev


def _scan_secrets(target_path: str, project_id: Optional[str]) -> AuditEvidence:
    """Run secret detection using fast builtin patterns (skip_dirs + file caps)."""
    # Always use the fast fallback scanner — ICDEV secret_detector walks the
    # full tree without caps and is too slow for interactive dashboard use.
    return _scan_secrets_fallback(target_path)


def _scan_secrets_fallback(target_path: str) -> AuditEvidence:
    """Fallback secret detection using regex patterns."""
    ev = AuditEvidence("secrets", "builtin_patterns")

    secret_patterns = [
        (r"(?:AKIA|ASIA)[A-Z0-9]{16}", "AWS Access Key", "critical"),
        (r"(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{36,}", "GitHub Token", "critical"),
        (r"sk-[A-Za-z0-9]{48}", "OpenAI API Key", "critical"),
        (r"(?:password|passwd|pwd)\s*=\s*['\"][^'\"]{8,}", "Hardcoded Password", "high"),
        (r"(?:api_key|apikey|api-key)\s*=\s*['\"][^'\"]{8,}", "Hardcoded API Key", "high"),
        (r"(?:secret|token)\s*=\s*['\"][^'\"]{8,}", "Hardcoded Secret/Token", "high"),
        (r"-----BEGIN (?:RSA |EC |DSA )?PRIVATE KEY-----", "Private Key File", "critical"),
    ]

    skip_dirs = SCAN_SKIP_DIRS
    skip_files = {".env.example", ".env.template", "*.md"}

    file_count = 0
    max_files = 500
    for root, dirs, files in os.walk(target_path):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for fname in files:
            if file_count >= max_files:
                break
            if fname.endswith(".md") or fname in skip_files:
                continue
            fpath = os.path.join(root, fname)
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read(50000)  # Cap per-file read
                    for pattern, msg, sev in secret_patterns:
                        for match in re.finditer(pattern, content):
                            rel_path = os.path.relpath(fpath, target_path)
                            line_num = content[:match.start()].count("\n") + 1
                            ev.add_finding("IA-5", sev, msg, f"{msg} in {rel_path}",
                                           file_path=rel_path, line=line_num)
                    file_count += 1
            except (OSError, UnicodeDecodeError):
                continue
        if file_count >= max_files:
            break

    ev.success = True
    ev.summary = {"total_findings": len(ev.findings)}
    if not ev.findings:
        ev.add_finding("IA-5", "info", "No Secrets", "No hardcoded secrets detected", status="pass")
    return ev


def _scan_dependencies(target_path: str, project_id: Optional[str]) -> AuditEvidence:
    """Run dependency vulnerability audit."""
    ev = AuditEvidence("dependencies", "dependency_auditor")
    try:
        from tools.security.dependency_auditor import audit_python
        result = audit_python(target_path)
        ev.success = result.get("success", False)
        ev.summary = result.get("summary", {})
        for finding in result.get("findings", []):
            ev.add_finding(
                control_hint="SA-11",  # Developer testing
                severity=finding.get("severity", "medium"),
                title=f"Vulnerable: {finding.get('package', 'unknown')} {finding.get('version', '')}",
                description=finding.get("description", finding.get("vulnerability_id", "")),
                status="fail",
            )
        if not ev.findings:
            ev.add_finding("SA-11", "info", "Dependencies Clean", "No known vulnerabilities", status="pass")
    except ImportError:
        ev.success = True
        ev.summary = {"note": "Dependency auditor not available — skipped"}
        ev.add_finding("SA-11", "info", "Skipped", "Dependency auditor not available", status="not_applicable")
    return ev


def _scan_code_patterns(target_path: str, project_id: Optional[str]) -> AuditEvidence:
    """Scan for security-relevant code patterns."""
    ev = AuditEvidence("code_patterns", "builtin_analysis")

    checks = {
        "logging_present": {
            "patterns": [r"import logging", r"from logging import", r"console\.log", r"log\."],
            "control_hint": "AU-2",
            "pass_msg": "Logging framework detected",
            "fail_msg": "No logging framework detected",
        },
        "error_handling": {
            "patterns": [r"try\s*:", r"except\s+", r"catch\s*\(", r"\.catch\("],
            "control_hint": "SI-11",
            "pass_msg": "Error handling present",
            "fail_msg": "No error handling patterns detected",
        },
        "input_validation": {
            "patterns": [r"validate", r"sanitize", r"escape", r"parameterized"],
            "control_hint": "SI-10",
            "pass_msg": "Input validation patterns found",
            "fail_msg": "No input validation patterns detected",
        },
        "auth_present": {
            "patterns": [r"authenticate", r"authorize", r"@login_required", r"require_auth",
                         r"jwt", r"oauth", r"session.*check"],
            "control_hint": "AC-3",
            "pass_msg": "Authentication/authorization patterns found",
            "fail_msg": "No authentication patterns detected",
        },
        "encryption": {
            "patterns": [r"encrypt", r"AES", r"RSA", r"hashlib", r"bcrypt", r"crypto",
                         r"TLS", r"SSL", r"https"],
            "control_hint": "SC-13",
            "pass_msg": "Encryption usage detected",
            "fail_msg": "No encryption patterns detected",
        },
    }

    scan_extensions = {".py", ".js", ".ts", ".java", ".go", ".rs", ".c", ".cs"}
    skip_dirs = SCAN_SKIP_DIRS

    # Collect source content (cap at 500 files for performance)
    all_content = ""
    file_count = 0
    max_files = 500
    for root, dirs, files in os.walk(target_path):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for fname in files:
            if file_count >= max_files:
                break
            if Path(fname).suffix.lower() in scan_extensions:
                try:
                    with open(os.path.join(root, fname), "r", encoding="utf-8", errors="ignore") as f:
                        all_content += f.read(50000) + "\n"  # Cap per-file read
                        file_count += 1
                except (OSError, UnicodeDecodeError):
                    continue
        if file_count >= max_files:
            break

    for check_name, check_def in checks.items():
        found = any(re.search(p, all_content, re.IGNORECASE) for p in check_def["patterns"])
        ev.add_finding(
            control_hint=check_def["control_hint"],
            severity="medium" if not found else "info",
            title=check_def["pass_msg"] if found else check_def["fail_msg"],
            description=check_name,
            status="pass" if found else "fail",
        )

    ev.success = True
    ev.summary = {"checks_run": len(checks)}
    return ev


def _scan_file_permissions(target_path: str, project_id: Optional[str]) -> AuditEvidence:
    """Check for overly permissive files and sensitive file exposure."""
    ev = AuditEvidence("file_permissions", "builtin_analysis")

    sensitive_files = [
        ".env", ".env.local", ".env.production",
        "credentials.json", "service-account.json",
        "id_rsa", "id_ed25519", "*.pem", "*.key",
        ".htpasswd", "shadow", "passwd",
    ]

    skip_dirs = SCAN_SKIP_DIRS
    found_sensitive = []

    for root, dirs, files in os.walk(target_path):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for fname in files:
            for pattern in sensitive_files:
                if pattern.startswith("*"):
                    if fname.endswith(pattern[1:]):
                        found_sensitive.append(os.path.relpath(os.path.join(root, fname), target_path))
                elif fname == pattern:
                    found_sensitive.append(os.path.relpath(os.path.join(root, fname), target_path))

    # Check for .gitignore
    gitignore_path = Path(target_path) / ".gitignore"
    has_gitignore = gitignore_path.exists()

    if not has_gitignore:
        ev.add_finding("CM-6", "medium", "No .gitignore", "Missing .gitignore file", status="fail")

    for sf in found_sensitive:
        ev.add_finding("AC-3", "high", f"Sensitive file exposed: {sf}",
                       f"Sensitive file {sf} found in project tree",
                       file_path=sf, status="fail")

    if not found_sensitive:
        ev.add_finding("AC-3", "info", "No sensitive files exposed",
                       "No sensitive files found in project tree", status="pass")

    ev.success = True
    ev.summary = {"sensitive_files_found": len(found_sensitive), "has_gitignore": has_gitignore}
    return ev


def _scan_stig(target_path: str, project_id: Optional[str]) -> AuditEvidence:
    """Run STIG compliance check (ICDEV/child apps only).

    Uses a subprocess with timeout to avoid blocking on DB connection issues.
    """
    ev = AuditEvidence("stig", "stig_checker")
    if not project_id:
        ev.success = True
        ev.add_finding("CM-6", "info", "Skipped", "No project_id for STIG check", status="not_applicable")
        return ev

    try:
        result = subprocess.run(
            [sys.executable, "-c",
             f"import sys; sys.path.insert(0,'.'); "
             f"from tools.compliance.stig_checker import run_stig_check; "
             f"import json; print(json.dumps(run_stig_check(project_id='{project_id}')))"],
            capture_output=True, text=True, timeout=5,
            cwd=str(BASE_DIR),
            env={**os.environ, "ICDEV_STORAGE_BACKEND": "sqlite"},
        )
        if result.returncode == 0 and result.stdout.strip():
            data = json.loads(result.stdout.strip())
            ev.success = True
            ev.summary = data.get("summary", {})
            for finding in data.get("results", []):
                status = "pass" if finding.get("status") in ("NotAFinding", "Not_Applicable") else "fail"
                sev = {"CAT1": "critical", "CAT2": "high", "CAT3": "medium"}.get(
                    finding.get("severity", ""), "medium")
                ev.add_finding(
                    control_hint=finding.get("control", "CM-6"),
                    severity=sev,
                    title=finding.get("title", finding.get("vuln_id", "")),
                    description=finding.get("comments", ""),
                    status=status,
                )
        else:
            ev.add_finding("CM-6", "info", "STIG check unavailable", "Tool returned no data", status="not_applicable")
            ev.success = True
    except (subprocess.TimeoutExpired, Exception) as e:
        ev.add_finding("CM-6", "info", "STIG check skipped", f"Timeout or error: {e}", status="not_applicable")
        ev.success = True
    return ev


def _scan_sbom(target_path: str, project_id: Optional[str]) -> AuditEvidence:
    """Check SBOM generation capability.

    Uses a subprocess with timeout to avoid blocking on DB connection issues.
    """
    ev = AuditEvidence("sbom", "sbom_generator")
    pid = project_id or "audit-scan"
    try:
        result = subprocess.run(
            [sys.executable, "-c",
             f"import sys; sys.path.insert(0,'.'); "
             f"from tools.compliance.sbom_generator import generate_sbom; "
             f"import json; r = generate_sbom(project_id='{pid}'); "
             f"print(json.dumps({{'components': len(r.get('components', []))}}))"
             ],
            capture_output=True, text=True, timeout=5,
            cwd=str(BASE_DIR),
            env={**os.environ, "ICDEV_STORAGE_BACKEND": "sqlite"},
        )
        if result.returncode == 0 and result.stdout.strip():
            data = json.loads(result.stdout.strip())
            count = data.get("components", 0)
            ev.success = True
            ev.summary = {"component_count": count}
            ev.add_finding("SA-11", "info", f"SBOM generated: {count} components",
                           "SBOM successfully generated", status="pass")
        else:
            ev.add_finding("SA-11", "info", "SBOM unavailable", "Tool returned no data", status="not_applicable")
            ev.success = True
    except (subprocess.TimeoutExpired, Exception) as e:
        ev.add_finding("SA-11", "info", "SBOM check skipped", f"Timeout or error: {e}", status="not_applicable")
        ev.success = True
    return ev


def _scan_cui_markings(target_path: str, project_id: Optional[str]) -> AuditEvidence:
    """Check for CUI markings on source files."""
    ev = AuditEvidence("cui_markings", "builtin_analysis")

    skip_dirs = SCAN_SKIP_DIRS

    marked = 0
    unmarked = 0
    unmarked_files = []
    file_count = 0
    max_files = 500

    py_files = []
    for root, dirs, files in os.walk(target_path):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for fname in files:
            if fname.endswith(".py"):
                py_files.append(os.path.join(root, fname))
                file_count += 1
                if file_count >= max_files:
                    break
        if file_count >= max_files:
            break

    for fpath in py_files:
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                header = f.read(500)
                if "CUI" in header or "UNCLASSIFIED" in header:
                    marked += 1
                else:
                    unmarked += 1
                    if len(unmarked_files) < 10:
                        unmarked_files.append(os.path.relpath(str(fpath), target_path))
        except (OSError, UnicodeDecodeError):
            continue

    total = marked + unmarked
    if total > 0:
        pct = (marked / total) * 100
        status = "pass" if pct >= 90 else ("partial" if pct >= 50 else "fail")
        sev = "info" if pct >= 90 else ("medium" if pct >= 50 else "high")
        ev.add_finding("AC-16", sev, f"CUI markings: {pct:.0f}% ({marked}/{total})",
                       f"Unmarked: {', '.join(unmarked_files[:5])}" if unmarked_files else "All files marked",
                       status=status)
    else:
        ev.add_finding("AC-16", "info", "No Python files to check", "", status="not_applicable")

    ev.success = True
    ev.summary = {"marked": marked, "unmarked": unmarked, "total": total}
    return ev


def _scan_sbd(target_path: str, project_id: Optional[str]) -> AuditEvidence:
    """Run Secure by Design assessment.

    Uses a subprocess with timeout to avoid blocking on DB connection issues.
    """
    ev = AuditEvidence("sbd", "sbd_assessor")
    if not project_id:
        ev.add_finding("SA-15", "info", "Skipped", "No project_id for SbD check", status="not_applicable")
        ev.success = True
        return ev

    try:
        result = subprocess.run(
            [sys.executable, "-c",
             f"import sys; sys.path.insert(0,'.'); "
             f"from tools.compliance.sbd_assessor import run_sbd_assessment; "
             f"import json; print(json.dumps(run_sbd_assessment("
             f"project_id='{project_id}', project_dir='{target_path}', gate=False)))"],
            capture_output=True, text=True, timeout=5,
            cwd=str(BASE_DIR),
            env={**os.environ, "ICDEV_STORAGE_BACKEND": "sqlite"},
        )
        if result.returncode == 0 and result.stdout.strip():
            data = json.loads(result.stdout.strip())
            ev.success = True
            ev.summary = data.get("summary", {})
            score = data.get("summary", {}).get("score", 0)
            status = "pass" if score >= 80 else ("partial" if score >= 50 else "fail")
            ev.add_finding("SA-15", "info" if status == "pass" else "medium",
                           f"SbD Score: {score}%", json.dumps(data.get("summary", {})), status=status)
        else:
            ev.add_finding("SA-15", "info", "SbD check unavailable", "Tool returned no data", status="not_applicable")
            ev.success = True
    except (subprocess.TimeoutExpired, Exception) as e:
        ev.add_finding("SA-15", "info", "SbD check skipped", f"Timeout or error: {e}", status="not_applicable")
        ev.success = True
    return ev


def _scan_module_manifest(target_path: str, project_id: Optional[str]) -> AuditEvidence:
    """Check module manifest compliance."""
    ev = AuditEvidence("module_manifest", "builtin_analysis")

    required_files = ["__init__.py", "README.md"]
    recommended_files = ["SECURITY.md", "LICENSE", "pyproject.toml", "tests/"]

    for rf in required_files:
        path = Path(target_path) / rf
        exists = path.exists()
        ev.add_finding("CM-2", "high" if not exists else "info",
                       f"{'Found' if exists else 'Missing'}: {rf}",
                       f"Required file {rf}", status="pass" if exists else "fail")

    for rf in recommended_files:
        path = Path(target_path) / rf
        exists = path.exists()
        ev.add_finding("CM-2", "low" if not exists else "info",
                       f"{'Found' if exists else 'Missing'}: {rf}",
                       f"Recommended: {rf}", status="pass" if exists else "partial")

    ev.success = True
    return ev


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Audit Scanner")
    parser.add_argument("--target", type=str, required=True, help="Directory or git URL to scan")
    parser.add_argument("--type", type=str, default="auto",
                        choices=["icdev", "module", "child_app", "byos", "auto"])
    parser.add_argument("--project-id", type=str, help="ICDEV project ID")
    parser.add_argument("--skip", type=str, nargs="*", help="Scanners to skip")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    result = scan_target(args.target, args.type, args.project_id, args.skip)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"\nAudit Scan: {result['target_path']}")
        print(f"Type: {result['target_type']}")
        print(f"Scanners: {result['summary']['scanners_run']} run, "
              f"{result['summary']['scanners_succeeded']} succeeded")
        print(f"Findings: {result['summary']['total_findings']}")
        for sev, count in result['summary']['severity_counts'].items():
            if count > 0:
                print(f"  {sev}: {count}")
