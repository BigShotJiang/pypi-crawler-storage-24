#!/usr/bin/env python3
# CUI // SP-CTI
# Controlled by: Department of Defense
# CUI Category: CTI
# Distribution: D
# POC: ICDEV System Administrator
"""Report Card Generator — Visual compliance report card output.

Generates formatted report cards from audit results in multiple formats:
JSON, Markdown, and terminal display. Unified format for ICDEV, modules,
child apps, and BYOS targets.
"""

import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional


def generate_report_card(
    audit_result: Dict,
    output_format: str = "json",
    output_path: Optional[str] = None,
    include_details: bool = False,
) -> Dict:
    """Generate a formatted report card from audit results.

    Args:
        audit_result: Full result from engine.run_audit().
        output_format: 'json', 'markdown', or 'terminal'.
        output_path: Optional file path to write output.
        include_details: Include per-control findings detail.

    Returns:
        Report card dict with formatted output.
    """
    regime_scores = audit_result.get("regime_scores", {})
    scan_summary = audit_result.get("scan_summary", {})

    # Build cards
    cards = []
    for regime_id, score_data in regime_scores.items():
        if "error" in score_data:
            cards.append({"regime_id": regime_id, "error": score_data["error"]})
            continue

        card = {
            "regime_id": score_data.get("regime_id", regime_id),
            "regime_name": score_data.get("regime_name", regime_id),
            "version": score_data.get("version", ""),
            "overall_score": score_data.get("overall_score", 0),
            "grade": score_data.get("grade", "F"),
            "summary": score_data.get("summary", {}),
            "categories": [],
        }

        for cat in score_data.get("categories", []):
            cat_card = {
                "category_id": cat.get("category_id", ""),
                "category_name": cat.get("category_name", ""),
                "score": cat.get("score", 0),
                "passed": cat.get("passed", 0),
                "partial": cat.get("partial", 0),
                "failed": cat.get("failed", 0),
                "not_applicable": cat.get("not_applicable", 0),
                "total": cat.get("total", 0),
            }

            if include_details:
                cat_card["controls"] = cat.get("controls", [])

            card["categories"].append(cat_card)

        cards.append(card)

    report = {
        "title": "ICDEV Audit Engine — Compliance Report Card",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "target_path": audit_result.get("target_path", ""),
        "target_type": audit_result.get("target_type", ""),
        "scan_summary": scan_summary,
        "regime_count": len(cards),
        "cards": cards,
        "classification": "CUI // SP-CTI",
    }

    # Format output
    if output_format == "markdown":
        content = _format_markdown(report)
    elif output_format == "terminal":
        content = _format_terminal(report)
    else:
        content = json.dumps(report, indent=2)

    # Write to file if requested
    if output_path:
        Path(output_path).write_text(content, encoding="utf-8")
        report["output_file"] = output_path

    report["formatted_output"] = content
    return report


def _format_markdown(report: Dict) -> str:
    """Format report card as Markdown."""
    lines = []
    lines.append(f"# {report['title']}")
    lines.append(f"")
    lines.append(f"**CUI // SP-CTI**")
    lines.append(f"")
    lines.append(f"| Field | Value |")
    lines.append(f"|-------|-------|")
    lines.append(f"| Generated | {report['generated_at'][:19]} UTC |")
    lines.append(f"| Target | `{report['target_path']}` |")
    lines.append(f"| Type | {report['target_type']} |")
    lines.append(f"| Regimes | {report['regime_count']} |")
    lines.append(f"")

    # Summary table
    lines.append(f"## Scores Overview")
    lines.append(f"")
    lines.append(f"| Regime | Score | Grade | Passed | Failed | Total |")
    lines.append(f"|--------|------:|:-----:|-------:|-------:|------:|")

    for card in report["cards"]:
        if "error" in card:
            lines.append(f"| {card['regime_id']} | — | — | — | — | ERROR |")
            continue
        s = card.get("summary", {})
        lines.append(
            f"| {card['regime_name']} | {card['overall_score']:.1f}% | {card['grade']} | "
            f"{s.get('passed', 0)} | {s.get('failed', 0)} | {s.get('total_controls', 0)} |"
        )

    lines.append(f"")

    # Per-regime detail
    for card in report["cards"]:
        if "error" in card:
            continue

        lines.append(f"## {card['regime_name']} ({card['overall_score']:.1f}% — {card['grade']})")
        lines.append(f"")
        lines.append(f"| Category | Score | Passed | Partial | Failed | N/A |")
        lines.append(f"|----------|------:|-------:|--------:|-------:|----:|")

        for cat in card.get("categories", []):
            lines.append(
                f"| {cat['category_name']} | {cat['score']:.1f}% | "
                f"{cat['passed']} | {cat['partial']} | {cat['failed']} | {cat['not_applicable']} |"
            )

        lines.append(f"")

        # Control details if included
        for cat in card.get("categories", []):
            if "controls" in cat:
                lines.append(f"### {cat['category_name']}")
                lines.append(f"")
                for ctrl in cat["controls"]:
                    status_icon = {
                        "pass": "✅", "partial": "⚠️", "fail": "❌",
                        "not_applicable": "➖", "not_assessed": "❓",
                    }.get(ctrl.get("status", ""), "❓")
                    lines.append(f"- {status_icon} **{ctrl['control_id']}** — {ctrl.get('title', '')}")
                lines.append(f"")

    lines.append(f"---")
    lines.append(f"*CUI // SP-CTI*")
    return "\n".join(lines)


def _format_terminal(report: Dict) -> str:
    """Format report card for terminal display."""
    lines = []
    lines.append(f"")
    lines.append(f"{'='*70}")
    lines.append(f"  ICDEV AUDIT ENGINE — COMPLIANCE REPORT CARD")
    lines.append(f"{'='*70}")
    lines.append(f"  Target: {report['target_path']}")
    lines.append(f"  Type:   {report['target_type']}")
    lines.append(f"  Date:   {report['generated_at'][:10]}")
    lines.append(f"{'='*70}")
    lines.append(f"")

    for card in report["cards"]:
        if "error" in card:
            lines.append(f"  {card['regime_id']:35s}  ERROR: {card['error']}")
            continue

        score = card.get("overall_score", 0)
        grade = card.get("grade", "?")
        bar_len = int(score / 2)
        bar = "\u2588" * bar_len + "\u2591" * (50 - bar_len)

        lines.append(f"  {card.get('regime_name', ''):35s}")
        lines.append(f"  [{bar}] {score:5.1f}%  {grade}")

        s = card.get("summary", {})
        lines.append(f"  Passed: {s.get('passed', 0)} | Partial: {s.get('partial', 0)} | "
                      f"Failed: {s.get('failed', 0)} | Total: {s.get('total_controls', 0)}")
        lines.append(f"")

        # Category breakdown
        for cat in card.get("categories", []):
            cat_score = cat.get("score", 0)
            cat_bar_len = int(cat_score / 5)
            cat_bar = "\u2588" * cat_bar_len + "\u2591" * (20 - cat_bar_len)
            lines.append(f"    {cat.get('category_name', ''):25s} [{cat_bar}] {cat_score:5.1f}%")

        lines.append(f"  {'─'*66}")
        lines.append(f"")

    lines.append(f"{'='*70}")
    lines.append(f"  CUI // SP-CTI")
    lines.append(f"{'='*70}")
    return "\n".join(lines)


def get_score_trend(project_id: Optional[str] = None,
                    regime_id: Optional[str] = None,
                    limit: int = 10) -> List[Dict]:
    """Get historical score trend from DB.

    Returns list of {timestamp, regime_id, score, grade} sorted by time.
    """
    try:
        from tools.db.storage import get_connection
    except ImportError:
        return []

    with get_connection() as conn:
        try:
            query = "SELECT * FROM audit_engine_scores ORDER BY timestamp DESC"
            params = []

            conditions = []
            if regime_id:
                conditions.append("regime_id = ?")
                params.append(regime_id)

            if conditions:
                query = f"SELECT * FROM audit_engine_scores WHERE {' AND '.join(conditions)} ORDER BY timestamp DESC"

            query += f" LIMIT {limit}"
            rows = conn.execute(query, tuple(params)).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Audit Report Card Generator")
    parser.add_argument("--audit-file", type=str, help="Audit result JSON file")
    parser.add_argument("--format", type=str, default="terminal",
                        choices=["json", "markdown", "terminal"])
    parser.add_argument("--output", type=str, help="Output file path")
    parser.add_argument("--details", action="store_true", help="Include per-control details")
    parser.add_argument("--trend", action="store_true", help="Show score trend")
    parser.add_argument("--regime", type=str, help="Filter by regime ID")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    if args.trend:
        trend = get_score_trend(regime_id=args.regime)
        if args.json:
            print(json.dumps(trend, indent=2))
        else:
            for t in trend:
                print(f"  {t.get('timestamp', '')[:19]}  {t.get('regime_id', ''):25s}  "
                      f"{t.get('overall_score', 0):5.1f}%  {t.get('grade', '?')}")
    elif args.audit_file:
        with open(args.audit_file, "r") as f:
            audit_result = json.load(f)
        report = generate_report_card(
            audit_result,
            output_format=args.format,
            output_path=args.output,
            include_details=args.details,
        )
        if args.format != "json":
            print(report["formatted_output"])
        else:
            print(json.dumps(report, indent=2))
    else:
        parser.print_help()
