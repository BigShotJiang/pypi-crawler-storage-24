# [TEMPLATE: CUI // SP-CTI]
# SPARKPILOT SDLC — Complete Software Development Life Cycle orchestrator
# Adapted from ADW adw_sdlc.py with dual platform support

"""
SPARKPILOT SDLC — Chains together all workflow phases.

Usage:
    python tools/ci/workflows/icdev_sdlc.py <issue-number> [run-id] [--orchestrated]

Pipeline:
    1.  icdev_plan   — Planning phase
    2.  icdev_build  — Implementation phase
    2b. quality_gate — Shift-left AST checks
    2c. codelens_pro — CodeLens Pro quality review (deterministic + IV&V)
    3.  icdev_test   — Testing phase (unit + BDD + security)
    3b. icdev_e2e    — E2E browser verification (Playwright)
    4.  icdev_review — Code review phase
    5.  icdev_comply — Compliance artifacts (if applicable)

Flags:
    --orchestrated  Use multi-agent DAG orchestration (parallel execution)
"""

import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from tools.ci.modules.workflow_ops import ensure_run_id


# Phases eligible for self-recovery (D134)
RECOVERABLE_PHASES = {"Test", "Build"}


def run_phase(phase_name: str, script_name: str, issue_number: str,
              run_id: str, extra_args: list = None) -> bool:
    """Run a workflow phase as a subprocess.

    For recoverable phases (Test, Build), failure triggers the recovery engine
    which attempts to auto-fix and retest before aborting.
    """
    script_path = Path(__file__).parent / f"{script_name}.py"

    cmd = [sys.executable, str(script_path), issue_number, run_id]
    if extra_args:
        cmd.extend(extra_args)

    print(f"\n{'='*60}")
    print(f"  {phase_name.upper()} PHASE")
    print(f"{'='*60}")
    print(f"Command: {' '.join(cmd)}")

    result = subprocess.run(
        cmd, cwd=str(PROJECT_ROOT), capture_output=True, text=True,
    )

    # Print output to stdout for visibility
    if result.stdout:
        print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)

    if result.returncode != 0:
        print(f"\n{phase_name} phase FAILED (exit code: {result.returncode})")

        # Attempt self-recovery for eligible phases (D134)
        if phase_name in RECOVERABLE_PHASES:
            recovered = _attempt_phase_recovery(
                phase_name, result.stdout + result.stderr,
                run_id, issue_number,
            )
            if recovered:
                print(f"\n{phase_name} phase RECOVERED — continuing pipeline")
                return True

        return False

    print(f"\n{phase_name} phase completed")
    return True


def _attempt_phase_recovery(
    phase_name: str, failure_output: str,
    run_id: str, issue_number: str,
) -> bool:
    """Invoke recovery engine for a failed phase."""
    try:
        from tools.ci.core.recovery_engine import RecoveryEngine
        from tools.ci.modules.state import ICDevState

        engine = RecoveryEngine()
        state = ICDevState.load(run_id)

        # Map phase names to parser phase names
        phase_map = {"Test": "test", "Build": "compile"}
        parser_phase = phase_map.get(phase_name, phase_name.lower())

        print(f"\n[Recovery] Attempting self-recovery for {phase_name}...")
        result = engine.attempt_recovery(
            parser_phase, failure_output, run_id, issue_number, state,
        )

        if result.recovered:
            print(f"[Recovery] {phase_name} recovered after {result.attempts} attempt(s)")
            print(f"[Recovery] Fixed files: {result.fixed_files}")
            return True
        else:
            print(f"[Recovery] {phase_name} recovery failed: {result.error}")
            # Post escalation message to issue
            try:
                from tools.ci.modules.vcs import VCS
                from tools.ci.modules.workflow_ops import format_issue_message
                vcs = VCS()
                escalation = engine.format_escalation_message(result)
                vcs.comment_on_issue(
                    int(issue_number),
                    format_issue_message(run_id, "recovery", escalation),
                )
            except Exception:
                pass
            return False

    except ImportError:
        print("[Recovery] Recovery engine not available")
        return False
    except Exception as e:
        print(f"[Recovery] Recovery attempt failed: {e}")
        return False


def _run_quality_gate() -> bool:
    """Run shift-left quality gate on changed Python files.

    Returns True if no errors found, False if blocking errors detected.
    """
    print(f"\n{'='*60}")
    print("  QUALITY GATE PHASE (shift-left AST checks)")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD~1", "--", "*.py"],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
        )
        changed_files = [
            f.strip() for f in result.stdout.strip().split("\n")
            if f.strip() and (PROJECT_ROOT / f.strip()).is_file()
        ]
    except Exception as exc:
        print(f"Could not determine changed files: {exc}")
        return True  # Don't block on git errors

    if not changed_files:
        print("No changed Python files — skipping quality gate")
        return True

    try:
        from tools.review.quality_gate import check_files
    except ImportError:
        print("quality_gate module not available — skipping")
        return True

    results = check_files(changed_files)
    errors_found = 0
    for r in results:
        file_errors = [i for i in r.issues if i.severity == "error"]
        if file_errors:
            errors_found += len(file_errors)
            for issue in file_errors:
                print(f"  ERROR: {r.file}:{issue.line} — {issue.message}")
        else:
            print(f"  PASS: {r.file} — {r.score_estimate}/100")

    print(f"\nQuality gate checked {len(results)} file(s), {errors_found} error(s)")
    if errors_found > 0:
        print("Quality gate FAILED — fix errors before proceeding")
        return False

    print("Quality gate PASSED")
    return True


def _run_coverage_gate() -> bool:
    """Run test coverage gate — blocks pipeline if coverage is below threshold.

    Threshold loaded from args/exit_criteria.yaml (coverage_threshold key)
    or defaults to 80%.  Returns True if coverage meets threshold.
    """
    print(f"\n{'='*60}")
    print("  COVERAGE GATE PHASE (test coverage threshold)")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.coverage_gate",
                "--project-dir", str(PROJECT_ROOT),
                "--gate", "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=300,
        )

        if result.returncode == 0:
            # Parse and display result
            try:
                import json as _json
                data = _json.loads(result.stdout)
                pct = data.get("coverage_pct", 0)
                threshold = data.get("threshold", 80)
                print(f"Coverage: {pct:.1f}% (threshold: {threshold}%)")
            except Exception:
                pass
            print("Coverage gate PASSED")
            return True
        else:
            try:
                import json as _json
                data = _json.loads(result.stdout)
                pct = data.get("coverage_pct", 0)
                threshold = data.get("threshold", 80)
                tip = data.get("coaching_tip", "")
                print(f"Coverage: {pct:.1f}% (threshold: {threshold}%)")
                if tip:
                    print(f"Tip: {tip}")
            except Exception:
                pass
            print("Coverage gate FAILED")
            return False

    except subprocess.TimeoutExpired:
        print("Coverage gate timed out (300s) — skipping")
        return True
    except Exception as e:
        print(f"Coverage gate error: {e} — skipping")
        return True


def _run_codelens_pro_gate() -> bool:
    """Run CodeLens Pro as a shift-left quality gate in the SDLC pipeline.

    Executes deterministic lenses (accessibility, mutation, property) on
    changed files.  Returns True if score >= 70, False otherwise.
    Non-blocking on import errors (CodeLens Pro is optional).
    """
    print(f"\n{'='*60}")
    print("  CODELENS PRO PHASE (shift-left quality review)")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.review_pro.cli_pro",
                "--project-dir", str(PROJECT_ROOT),
                "--no-base", "--offline", "--maturity", "standard",
                "--gate", "--min-score", "70",
                "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=300,
        )

        if result.returncode == 0:
            print("CodeLens Pro gate PASSED")
            return True
        else:
            # Parse score from output if available
            import json as _json
            try:
                data = _json.loads(result.stdout)
                score = data.get("quality_score", {}).get("overall", 0)
                grade = data.get("quality_score", {}).get("grade", "?")
                findings = data.get("metrics", {}).get("total_pro_findings", 0)
                print(f"CodeLens Pro: {score:.1f}/100 ({grade}) — {findings} findings")
            except Exception:
                pass
            print("CodeLens Pro gate FAILED (non-blocking)")
            return False

    except subprocess.TimeoutExpired:
        print("CodeLens Pro timed out (300s) — skipping")
        return True
    except Exception as e:
        print(f"CodeLens Pro error: {e} — skipping")
        return True


def _run_evidence_freshness_gate() -> bool:
    """Run evidence freshness gate — blocks if compliance evidence is expired (D-INV-2).

    Returns True if evidence is current or stale (warning), False if expired.
    """
    print(f"\n{'='*60}")
    print("  EVIDENCE FRESHNESS GATE (D-INV-2 compliance evidence)")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.evidence_freshness_gate",
                "--project-id", "sparkpilot",
                "--gate", "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=60,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            s = data.get("summary", {})
            print(f"Evidence: {s.get('current', 0)} current, {s.get('stale', 0)} stale, "
                  f"{s.get('expired', 0)} expired")
        except Exception:
            pass

        if result.returncode == 0:
            print("Evidence freshness gate PASSED")
            return True
        else:
            print("Evidence freshness gate FAILED")
            return False

    except subprocess.TimeoutExpired:
        print("Evidence freshness gate timed out — skipping")
        return True
    except Exception as e:
        print(f"Evidence freshness gate error: {e} — skipping")
        return True


def _run_confabulation_gate() -> bool:
    """Run confabulation gate — warns if AI-generated content has high risk.

    Returns True always (non-blocking), prints warning if risk is high.
    """
    print(f"\n{'='*60}")
    print("  CONFABULATION GATE (NIST AI 600-1)")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.confabulation_gate",
                "--project-id", "sparkpilot", "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=120,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            risk = data.get("aggregate_risk", 0)
            files = data.get("files_checked", 0)
            status = data.get("gate_status", "?")
            print(f"Confabulation: risk={risk:.3f}, files={files}, status={status}")
        except Exception:
            pass

        print("Confabulation gate completed")
        return True  # Non-blocking — warn only

    except subprocess.TimeoutExpired:
        print("Confabulation gate timed out — skipping")
        return True
    except Exception as e:
        print(f"Confabulation gate error: {e} — skipping")
        return True


def _run_a2a_integration_tests() -> bool:
    """Run A2A integration tests — validates agent cards and registrations.

    Returns True always (non-blocking), prints warning if issues found.
    """
    print(f"\n{'='*60}")
    print("  A2A INTEGRATION TESTS (agent card validation)")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.a2a_integration_tests",
                "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=60,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            agents = data.get("agents_total", 0)
            passed = data.get("agents_passed", 0)
            skills = data.get("total_skills", 0)
            blocks = data.get("block_count", 0)
            print(f"A2A: {passed}/{agents} agents valid, {skills} skills, {blocks} blockers")
        except Exception:
            pass

        print("A2A integration tests completed")
        return True  # Non-blocking — warn only

    except subprocess.TimeoutExpired:
        print("A2A integration tests timed out — skipping")
        return True
    except Exception as e:
        print(f"A2A integration tests error: {e} — skipping")
        return True


def _run_data_quality_gate() -> bool:
    """Run data quality validation — schema, referential integrity, audit immutability.

    Returns True always (non-blocking), prints warning if issues found.
    """
    print(f"\n{'='*60}")
    print("  DATA QUALITY GATE (schema + integrity)")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.data_quality_validator",
                "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=60,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            checks = data.get("checks_total", 0)
            passed = data.get("checks_passed", 0)
            blocks = data.get("block_count", 0)
            print(f"Data quality: {passed}/{checks} checks passed, {blocks} blockers")
        except Exception:
            pass

        print("Data quality gate completed")
        return True  # Non-blocking — warn only

    except subprocess.TimeoutExpired:
        print("Data quality gate timed out — skipping")
        return True
    except Exception as e:
        print(f"Data quality gate error: {e} — skipping")
        return True


def _run_ivv_replay() -> bool:
    """Run IV&V replay — re-execute deterministic gates for reproducibility.

    Returns True always (non-blocking), prints warning if drift detected.
    """
    print(f"\n{'='*60}")
    print("  IV&V REPLAY (IEEE 1012 reproducibility)")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.ivv_replay",
                "--project-id", "sparkpilot", "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=120,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            total = data.get("gates_total", 0)
            passed = data.get("gates_passed", 0)
            drift = data.get("drift_regressions", 0)
            print(f"IV&V: {passed}/{total} gates passed, {drift} drift regression(s)")
        except Exception:
            pass

        print("IV&V replay completed")
        return True  # Non-blocking — warn only

    except subprocess.TimeoutExpired:
        print("IV&V replay timed out — skipping")
        return True
    except Exception as e:
        print(f"IV&V replay error: {e} — skipping")
        return True


def _run_contract_tests() -> bool:
    """Run contract tests — validate A2A/MCP/REST contracts.

    Returns True always (non-blocking), prints warning if issues found.
    """
    print(f"\n{'='*60}")
    print("  CONTRACT TESTS (A2A + MCP + REST)")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.contract_test_runner",
                "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=60,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            checks = data.get("checks_total", 0)
            passed = data.get("checks_passed", 0)
            blocks = data.get("block_count", 0)
            print(f"Contracts: {passed}/{checks} checks passed, {blocks} blockers")
        except Exception:
            pass

        print("Contract tests completed")
        return True  # Non-blocking

    except subprocess.TimeoutExpired:
        print("Contract tests timed out — skipping")
        return True
    except Exception as e:
        print(f"Contract tests error: {e} — skipping")
        return True


def _run_api_contract_validation() -> bool:
    """Run API contract validation — REST endpoint schema validation.

    Returns True always (non-blocking), prints warning if issues found.
    """
    print(f"\n{'='*60}")
    print("  API CONTRACT VALIDATION (REST endpoint schemas)")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.api_contract_validator",
                "--base-url", "http://localhost:5050", "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=60,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            routes = data.get("routes_tested", 0)
            blocks = data.get("block_count", 0)
            warns = data.get("warn_count", 0)
            print(f"API contracts: {routes} routes tested, {blocks} blockers, {warns} warnings")
        except Exception:
            pass

        print("API contract validation completed")
        return True  # Non-blocking

    except subprocess.TimeoutExpired:
        print("API contract validation timed out — skipping")
        return True
    except Exception as e:
        print(f"API contract validation error: {e} — skipping")
        return True


def _run_accessibility_tests() -> bool:
    """Run accessibility tests — WCAG 2.1 AA compliance.

    Returns True always (non-blocking), prints warning if issues found.
    """
    print(f"\n{'='*60}")
    print("  ACCESSIBILITY TESTS (WCAG 2.1 AA)")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.accessibility_test_runner",
                "--base-url", "http://localhost:5050", "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=60,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            pages = data.get("pages_tested", 0)
            issues = data.get("pages_with_issues", 0)
            blocks = data.get("block_count", 0)
            print(f"Accessibility: {pages} pages tested, {issues} with issues, {blocks} blockers")
        except Exception:
            pass

        print("Accessibility tests completed")
        return True  # Non-blocking

    except subprocess.TimeoutExpired:
        print("Accessibility tests timed out — skipping")
        return True
    except Exception as e:
        print(f"Accessibility tests error: {e} — skipping")
        return True


def _run_flakiness_analysis() -> bool:
    """Run flakiness analysis — detect flaky tests from historical data.

    Returns True always (non-blocking), prints warning if issues found.
    """
    print(f"\n{'='*60}")
    print("  FLAKINESS ANALYSIS (test stability)")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.flakiness_analyzer",
                "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=30,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            total = data.get("total_tests_tracked", 0)
            flaky = data.get("flaky_count", 0)
            quarantine = data.get("quarantine_count", 0)
            print(f"Flakiness: {flaky}/{total} flaky tests, {quarantine} quarantined")
        except Exception:
            pass

        print("Flakiness analysis completed")
        return True  # Non-blocking

    except subprocess.TimeoutExpired:
        print("Flakiness analysis timed out — skipping")
        return True
    except Exception as e:
        print(f"Flakiness analysis error: {e} — skipping")
        return True


def _run_license_check() -> bool:
    """Run dependency license compliance check.

    Returns True always (non-blocking), prints warning if issues found.
    """
    print(f"\n{'='*60}")
    print("  LICENSE COMPLIANCE CHECK")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.license_checker",
                "--offline", "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=30,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            status = data.get("gate_status", "?")
            print(f"License: {status} — {data.get('message', '')}")
        except Exception:
            pass

        print("License check completed")
        return True

    except subprocess.TimeoutExpired:
        print("License check timed out — skipping")
        return True
    except Exception as e:
        print(f"License check error: {e} — skipping")
        return True


def _run_migration_validation() -> bool:
    """Run database migration integrity validation.

    Returns True always (non-blocking), prints warning if issues found.
    """
    print(f"\n{'='*60}")
    print("  MIGRATION INTEGRITY VALIDATION")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.migration_validator",
                "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=30,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            status = data.get("gate_status", "?")
            print(f"Migrations: {status} — {data.get('message', '')}")
        except Exception:
            pass

        print("Migration validation completed")
        return True

    except subprocess.TimeoutExpired:
        print("Migration validation timed out — skipping")
        return True
    except Exception as e:
        print(f"Migration validation error: {e} — skipping")
        return True


def _run_config_drift_detection() -> bool:
    """Run configuration drift detection.

    Returns True always (non-blocking), prints warning if issues found.
    """
    print(f"\n{'='*60}")
    print("  CONFIGURATION DRIFT DETECTION")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.config_drift_detector",
                "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=30,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            status = data.get("gate_status", "?")
            print(f"Config drift: {status} — {data.get('message', '')}")
        except Exception:
            pass

        print("Config drift detection completed")
        return True

    except subprocess.TimeoutExpired:
        print("Config drift detection timed out — skipping")
        return True
    except Exception as e:
        print(f"Config drift detection error: {e} — skipping")
        return True


def _run_dead_code_detection() -> bool:
    """Run dead code detection.

    Returns True always (non-blocking), prints warning if issues found.
    """
    print(f"\n{'='*60}")
    print("  DEAD CODE DETECTION")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.dead_code_detector",
                "--max-files", "200", "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=60,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            status = data.get("gate_status", "?")
            print(f"Dead code: {status} — {data.get('message', '')}")
        except Exception:
            pass

        print("Dead code detection completed")
        return True

    except subprocess.TimeoutExpired:
        print("Dead code detection timed out — skipping")
        return True
    except Exception as e:
        print(f"Dead code detection error: {e} — skipping")
        return True


def _run_deprecation_detection() -> bool:
    """Run deprecation detection.

    Returns True always (non-blocking), prints warning if issues found.
    """
    print(f"\n{'='*60}")
    print("  DEPRECATION DETECTION")
    print(f"{'='*60}")

    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "tools.testing.deprecation_detector",
                "--max-files", "200", "--json",
            ],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
            timeout=60,
        )

        try:
            import json as _json
            data = _json.loads(result.stdout)
            status = data.get("gate_status", "?")
            print(f"Deprecation: {status} — {data.get('message', '')}")
        except Exception:
            pass

        print("Deprecation detection completed")
        return True

    except subprocess.TimeoutExpired:
        print("Deprecation detection timed out — skipping")
        return True
    except Exception as e:
        print(f"Deprecation detection error: {e} — skipping")
        return True


def run_orchestrated(issue_number: str, run_id: str) -> bool:
    """Run SDLC pipeline using multi-agent orchestration (DAG-based parallelism).

    Uses TeamOrchestrator to decompose the SDLC into a subtask DAG
    and execute independent phases in parallel where possible.
    Falls back to sequential execution if orchestrator is unavailable.
    """
    try:
        from tools.agent.team_orchestrator import TeamOrchestrator

        print(f"\n{'='*60}")
        print("  ORCHESTRATED SDLC (Multi-Agent DAG)")
        print(f"{'='*60}")

        orchestrator = TeamOrchestrator(max_workers=4)

        # Decompose the SDLC task
        task_desc = (
            f"Execute full SDLC pipeline for issue #{issue_number} (run_id: {run_id}). "
            f"Phases: Plan (classify issue, create branch, generate plan), "
            f"Build (implement from plan with TDD), "
            f"Test (unit + BDD + security scan), "
            f"Review (code review with compliance check). "
            f"Plan must complete before Build. Build must complete before Test. "
            f"Test and Review can run in parallel after Build."
        )

        workflow = orchestrator.decompose_task(task_desc, project_id=f"issue-{issue_number}")
        print(f"Workflow: {workflow.name} ({len(workflow.subtasks)} subtasks)")

        # Execute the workflow
        workflow = orchestrator.execute_workflow(workflow, timeout=1200)

        if workflow.status == "completed":
            print("\nOrchestrated SDLC completed successfully")
            return True
        elif workflow.status == "partially_completed":
            print("\nOrchestrated SDLC partially completed — check failed subtasks")
            return False
        else:
            print(f"\nOrchestrated SDLC failed: {workflow.status}")
            return False

    except ImportError:
        print("TeamOrchestrator not available — falling back to sequential execution")
        return False
    except Exception as e:
        print(f"Orchestrated execution failed ({e}) — falling back to sequential")
        return False


def main():
    """Main entry point."""
    if len(sys.argv) < 2:
        print("CUI // SP-CTI")
        print("Usage: python tools/ci/workflows/icdev_sdlc.py <issue-number> [run-id] [--orchestrated]")
        print("\nRuns the complete SDLC pipeline:")
        print("  1. Plan   — Issue classification, branch, plan generation")
        print("  2. Build  — Implementation from plan")
        print("  3. Test   — pytest, behave, ruff, bandit, security gates")
        print("  4. Review — Code review against spec")
        print("  5. Comply — Compliance artifacts (SSP, POAM, STIG, SBOM)")
        print("\nFlags:")
        print("  --orchestrated  Use multi-agent DAG orchestration (parallel execution)")
        sys.exit(1)

    issue_number = sys.argv[1]
    run_id = sys.argv[2] if len(sys.argv) > 2 and not sys.argv[2].startswith("--") else None
    orchestrated = "--orchestrated" in sys.argv

    # Ensure run_id
    run_id = ensure_run_id(issue_number, run_id)
    print("CUI // SP-CTI")
    print(f"SPARKPILOT SDLC — run_id: {run_id}, issue: #{issue_number}")

    # Orchestrated mode: use TeamOrchestrator for DAG-based parallel execution
    if orchestrated:
        if run_orchestrated(issue_number, run_id):
            print(f"\n{'='*60}")
            print("  SPARKPILOT SDLC COMPLETE (Orchestrated)")
            print(f"{'='*60}")
            print(f"Run ID: {run_id}")
            print(f"Issue:  #{issue_number}")
            return
        # Fall through to sequential if orchestrated failed
        print("Falling back to sequential SDLC pipeline...")

    # Phase 1: Plan
    if not run_phase("Plan", "icdev_plan", issue_number, run_id):
        print("Pipeline aborted at Plan phase")
        sys.exit(1)

    # Phase 2: Build
    if not run_phase("Build", "icdev_build", issue_number, run_id):
        print("Pipeline aborted at Build phase")
        sys.exit(1)

    # Phase 2b: Quality Gate — shift-left AST checks on changed files
    if not _run_quality_gate():
        print("Pipeline aborted at Quality Gate phase")
        sys.exit(1)

    # Phase 2b-cov: Coverage Gate — hard gate on test coverage threshold
    if not _run_coverage_gate():
        print("Pipeline aborted at Coverage Gate — increase test coverage")
        sys.exit(1)

    # Phase 2c: CodeLens Pro — shift-left code quality review (deterministic + IV&V)
    if not _run_codelens_pro_gate():
        print("WARNING: CodeLens Pro gate failed — review findings before merge")

    # Phase 3: Test (unit + BDD + security gates)
    if not run_phase("Test", "icdev_test", issue_number, run_id):
        print("Pipeline aborted at Test phase")
        sys.exit(1)

    # Phase 3b: E2E — Playwright browser verification (dashboard + UI pages)
    # E2E runs AFTER unit/BDD pass to catch visual regressions, missing pages,
    # broken navigation, and CUI banner issues that API tests cannot detect.
    # E2E is a BLOCKING gate — failures prevent merge (hardened 2026-03-11).
    if not run_phase("E2E", "icdev_e2e", issue_number, run_id):
        print("Pipeline aborted at E2E phase — review screenshots and fix failures")
        sys.exit(1)

    # Phase 4: Review
    if not run_phase("Review", "icdev_review", issue_number, run_id):
        print("Pipeline aborted at Review phase")
        sys.exit(1)

    # Phase 5: Comply — Generate ATO compliance artifacts (SSP, POAM, STIG, SBOM)
    if not run_phase("Comply", "icdev_comply", issue_number, run_id):
        print("Pipeline aborted at Comply phase")
        sys.exit(1)

    # Phase 5b: Evidence Freshness Gate — block if compliance evidence is expired
    if not _run_evidence_freshness_gate():
        print("Pipeline aborted at Evidence Freshness Gate — collect fresh evidence")
        sys.exit(1)

    # Phase 5c: Confabulation Gate — block if AI-generated artifacts have high risk
    if not _run_confabulation_gate():
        print("WARNING: Confabulation gate flagged high-risk content — review before merge")

    # Phase 5d: A2A Integration Tests — validate agent card schema and registrations
    if not _run_a2a_integration_tests():
        print("WARNING: A2A integration test issues detected — review agent cards")

    # Phase 6a: Data Quality Validation — schema + referential integrity
    if not _run_data_quality_gate():
        print("WARNING: Data quality issues detected — review DB integrity")

    # Phase 6b: IV&V Replay — re-execute deterministic gates for reproducibility
    if not _run_ivv_replay():
        print("WARNING: IV&V replay detected drift — review gate results")

    # Phase 7a: Contract Tests — validate A2A/MCP/REST contracts
    if not _run_contract_tests():
        print("WARNING: Contract test issues detected — review agent/API contracts")

    # Phase 7b: API Contract Validation — REST endpoint schema validation
    if not _run_api_contract_validation():
        print("WARNING: API contract issues detected — review endpoint schemas")

    # Phase 7c: Accessibility Tests — WCAG 2.1 AA compliance
    if not _run_accessibility_tests():
        print("WARNING: Accessibility issues detected — review WCAG findings")

    # Phase 7d: Flakiness Analysis — detect flaky tests
    if not _run_flakiness_analysis():
        print("WARNING: Flaky tests detected — review quarantine list")

    # Phase 7e: License Compliance — dependency license audit
    if not _run_license_check():
        print("WARNING: License issues detected — review dependency licenses")

    # Phase 7f: Migration Integrity — database migration validation
    if not _run_migration_validation():
        print("WARNING: Migration issues detected — review migration files")

    # Phase 7g: Configuration Drift — config file validation
    if not _run_config_drift_detection():
        print("WARNING: Config drift detected — review args/*.yaml files")

    # Phase 7h: Dead Code Detection — unused code analysis
    if not _run_dead_code_detection():
        print("WARNING: Dead code detected — review unused imports/functions")

    # Phase 7i: Deprecation Detection — deprecated API/package usage
    if not _run_deprecation_detection():
        print("WARNING: Deprecated usage detected — review deprecated imports")

    print(f"\n{'='*60}")
    print("  SPARKPILOT SDLC COMPLETE")
    print(f"{'='*60}")
    print(f"Run ID: {run_id}")
    print(f"Issue:  #{issue_number}")
    print("All phases completed successfully.")


if __name__ == "__main__":
    main()
