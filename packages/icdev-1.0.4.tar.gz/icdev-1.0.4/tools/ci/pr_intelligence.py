#!/usr/bin/env python3
# CUI // SP-CTI
"""PR Intelligence with Compliance Pre-Check.

Orchestrates security and compliance checks on commit diffs, generates
consolidated reports, and stores results for audit traceability.

Tables used:
  - pr_intelligence_reports  (write analysis reports)
  - audit_trail              (append-only audit events)

CLI:
  python tools/ci/pr_intelligence.py --project-id <id> --analyze --json
  python tools/ci/pr_intelligence.py --project-id <id> --analyze --pr-reference "PR-42" --json
  python tools/ci/pr_intelligence.py --project-id <id> --report --report-id <id> --json
"""

import argparse
import json
import sqlite3
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DB_PATH = BASE_DIR / "data" / "icdev.db"

# Try tools.compat.db_utils first
try:
    from tools.compat.db_utils import get_db_connection as _compat_get_conn
except ImportError:
    _compat_get_conn = None

# Control family keyword mapping for compliance pre-check
CONTROL_FAMILY_KEYWORDS = {
    "AC": ["auth", "access", "login", "permission", "rbac", "role", "session", "token"],
    "AU": ["audit", "log", "trail", "event", "monitor", "telemetry"],
    "SC": ["encrypt", "tls", "ssl", "crypto", "hash", "certificate", "key_exchange"],
    "IA": ["identity", "credential", "password", "mfa", "authenticate", "iam"],
    "SI": ["integrity", "validation", "sanitize", "input_check", "patch"],
    "CM": ["config", "baseline", "settings", "deploy", "pipeline"],
    "CP": ["backup", "recovery", "failover", "replicate", "disaster"],
    "RA": ["risk", "vulnerability", "scan", "assessment", "threat"],
    "SA": ["supply_chain", "vendor", "dependency", "sbom", "acquisition"],
    "MP": ["media", "storage", "wipe", "sanitization"],
}


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def _get_connection(db_path=None):
    """Return a sqlite3 connection with Row factory."""
    if _compat_get_conn and db_path is None:
        try:
            conn = _compat_get_conn()
            conn.row_factory = sqlite3.Row
            return conn
        except Exception:
            pass
    path = Path(db_path) if db_path else DB_PATH
    if not path.exists():
        raise FileNotFoundError(
            f"Database not found: {path}\n"
            "Run: python tools/db/init_icdev_db.py"
        )
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _ensure_tables(conn):
    """Create tables if they do not exist."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS pr_intelligence_reports (
            id              TEXT PRIMARY KEY,
            project_id      TEXT NOT NULL,
            pr_reference    TEXT,
            files_changed   INTEGER DEFAULT 0,
            security_json   TEXT,
            compliance_json TEXT,
            code_quality_json TEXT,
            overall_status  TEXT DEFAULT 'pass',
            classification  TEXT DEFAULT 'CUI // SP-CTI',
            created_at      TEXT DEFAULT (datetime('now'))
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_trail (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id      TEXT,
            event_type      TEXT,
            actor           TEXT,
            action          TEXT,
            details         TEXT,
            classification  TEXT DEFAULT 'CUI',
            created_at      TEXT DEFAULT (datetime('now'))
        )
    """)
    conn.commit()


def _log_audit(conn, project_id, event_type, action, details):
    """Append-only audit trail entry (NIST AU)."""
    try:
        conn.execute(
            """INSERT INTO audit_trail
               (project_id, event_type, actor, action, details, classification)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (project_id, event_type, "sparkpilot-pr-intelligence-agent", action,
             json.dumps(details) if isinstance(details, dict) else str(details),
             "CUI"),
        )
        conn.commit()
    except Exception as exc:
        print(f"Warning: audit log failed: {exc}", file=sys.stderr)


# ---------------------------------------------------------------------------
# Git diff helpers
# ---------------------------------------------------------------------------

def _get_git_diff(project_dir=None) -> Dict:
    """Run git diff HEAD~1 and return file change info."""
    cwd = str(Path(project_dir)) if project_dir else str(BASE_DIR)
    changed_files: List[str] = []
    diff_text = ""
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD~1"],
            capture_output=True, text=True, cwd=cwd, timeout=30,
        )
        if result.returncode == 0:
            changed_files = [f.strip() for f in result.stdout.strip().splitlines() if f.strip()]
        # Also get stat summary
        stat_result = subprocess.run(
            ["git", "diff", "--stat", "HEAD~1"],
            capture_output=True, text=True, cwd=cwd, timeout=30,
        )
        diff_text = stat_result.stdout if stat_result.returncode == 0 else ""
    except (subprocess.TimeoutExpired, FileNotFoundError):
        # git not available or timeout — fall back to empty
        pass
    return {
        "changed_files": changed_files,
        "files_changed": len(changed_files),
        "diff_summary": diff_text[:2000],
    }


# ---------------------------------------------------------------------------
# Security pre-check
# ---------------------------------------------------------------------------

def run_security_precheck(project_dir=None, db_path=None) -> Dict:
    """Run SAST and secret detection, merge findings.

    Gracefully handles missing tools by marking them unavailable.
    """
    findings: List[Dict] = []
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    sast_available = False
    secret_available = False
    scan_dir = str(Path(project_dir)) if project_dir else str(BASE_DIR)

    # Try SAST runner
    try:
        from tools.security.sast_runner import run_bandit
        sast_result = run_bandit(scan_dir)
        sast_available = True
        if isinstance(sast_result, dict):
            for f in sast_result.get("findings", []):
                sev = f.get("severity", "low").lower()
                findings.append({
                    "source": "sast",
                    "severity": sev,
                    "message": f.get("message", f.get("test_name", "unknown")),
                    "file": f.get("filename", ""),
                    "line": f.get("line_number", 0),
                })
                if sev in counts:
                    counts[sev] += 1
    except (ImportError, Exception) as exc:
        findings.append({
            "source": "sast",
            "severity": "info",
            "message": f"SAST runner unavailable: {exc}",
            "file": "",
            "line": 0,
        })

    # Try secret detector
    try:
        from tools.security.secret_detector import scan
        secret_result = scan(scan_dir)
        secret_available = True
        if isinstance(secret_result, dict):
            for f in secret_result.get("findings", []):
                sev = f.get("severity", "high").lower()
                findings.append({
                    "source": "secret_detector",
                    "severity": sev,
                    "message": f.get("pattern_name", f.get("type", "secret")),
                    "file": f.get("file", ""),
                    "line": f.get("line", 0),
                })
                if sev in counts:
                    counts[sev] += 1
    except (ImportError, Exception) as exc:
        findings.append({
            "source": "secret_detector",
            "severity": "info",
            "message": f"Secret detector unavailable: {exc}",
            "file": "",
            "line": 0,
        })

    # Determine status
    if counts["critical"] > 0 or counts["high"] > 0:
        status = "fail"
    elif counts["medium"] > 0:
        status = "warn"
    else:
        status = "pass"

    return {
        "findings_count": len([f for f in findings if f["severity"] != "info"]),
        "critical": counts["critical"],
        "high": counts["high"],
        "medium": counts["medium"],
        "low": counts["low"],
        "sast_available": sast_available,
        "secret_detector_available": secret_available,
        "findings": findings,
        "status": status,
    }


# ---------------------------------------------------------------------------
# Compliance pre-check
# ---------------------------------------------------------------------------

def run_compliance_precheck(project_id, changed_files=None, db_path=None) -> Dict:
    """Check if changed files affect NIST control implementations.

    Uses keyword matching from file paths to control families.
    """
    if not changed_files:
        return {
            "affected_controls": [],
            "impact_level": "none",
            "status": "pass",
        }

    affected: Dict[str, List[str]] = {}  # control_family -> [files]
    for fpath in changed_files:
        fpath_lower = fpath.lower().replace("\\", "/")
        for family, keywords in CONTROL_FAMILY_KEYWORDS.items():
            for kw in keywords:
                if kw in fpath_lower:
                    affected.setdefault(family, []).append(fpath)
                    break  # one match per family per file

    affected_controls = sorted(affected.keys())

    # Determine impact
    high_impact_families = {"AC", "IA", "SC", "AU"}
    medium_impact_families = {"SI", "CM", "RA", "SA"}

    has_high = any(f in high_impact_families for f in affected_controls)
    has_medium = any(f in medium_impact_families for f in affected_controls)

    if has_high:
        impact_level = "high"
        status = "warn"
    elif has_medium:
        impact_level = "medium"
        status = "warn"
    elif affected_controls:
        impact_level = "low"
        status = "warn"
    else:
        impact_level = "none"
        status = "pass"

    return {
        "affected_controls": [
            {"family": fam, "files": files}
            for fam, files in sorted(affected.items())
        ],
        "impact_level": impact_level,
        "status": status,
    }


# ---------------------------------------------------------------------------
# E2E coverage check
# ---------------------------------------------------------------------------

# File patterns that indicate dashboard/UI changes requiring E2E coverage
_UI_PATTERNS = [
    "tools/dashboard/",
    "templates/",
    ".html", ".jinja", ".jinja2", ".j2",
    ".css", ".scss", ".less",
    "static/js/", ".jsx", ".tsx", ".vue",
]

# E2E spec directories to check for coverage
_E2E_SPEC_DIRS = [
    "args/e2e_specs/",           # standalone YAML specs
    ".claude/commands/e2e/",     # MCP markdown specs
    "tests/e2e/",                # native Playwright specs
]


def run_e2e_coverage_check(changed_files=None, project_dir=None) -> Dict:
    """Check if dashboard/UI file changes have corresponding E2E test coverage.

    Flags PRs that modify templates, routes, CSS, or JS without a matching
    E2E spec — a common source of undetected visual regressions.
    """
    if not changed_files:
        return {
            "ui_files_changed": 0,
            "e2e_specs_exist": 0,
            "coverage_gap": False,
            "status": "pass",
            "missing_specs": [],
        }

    # Find UI-related changed files
    ui_files = []
    for fpath in changed_files:
        fpath_norm = fpath.replace("\\", "/").lower()
        if any(pat in fpath_norm for pat in _UI_PATTERNS):
            ui_files.append(fpath)

    if not ui_files:
        return {
            "ui_files_changed": 0,
            "e2e_specs_exist": 0,
            "coverage_gap": False,
            "status": "pass",
            "missing_specs": [],
        }

    # Count existing E2E specs
    e2e_spec_count = 0
    base = Path(project_dir) if project_dir else BASE_DIR
    for spec_dir in _E2E_SPEC_DIRS:
        spec_path = base / spec_dir
        if spec_path.exists():
            e2e_spec_count += len(list(spec_path.glob("*.yaml")))
            e2e_spec_count += len(list(spec_path.glob("*.yml")))
            e2e_spec_count += len(list(spec_path.glob("*.md")))
            e2e_spec_count += len(list(spec_path.glob("*.spec.ts")))

    # Check if E2E specs were also updated in this PR
    e2e_files_in_diff = [
        f for f in changed_files
        if any(d in f.replace("\\", "/") for d in _E2E_SPEC_DIRS)
    ]

    # Coverage gap: UI changed but no E2E spec updated in same PR
    coverage_gap = len(ui_files) > 0 and len(e2e_files_in_diff) == 0

    status = "warn" if coverage_gap else "pass"

    return {
        "ui_files_changed": len(ui_files),
        "ui_files": ui_files[:20],  # cap for report size
        "e2e_specs_exist": e2e_spec_count,
        "e2e_specs_updated_in_pr": len(e2e_files_in_diff),
        "coverage_gap": coverage_gap,
        "status": status,
        "missing_specs": [
            f"Dashboard file '{f}' changed but no E2E spec updated"
            for f in ui_files[:5]
        ] if coverage_gap else [],
    }


# ---------------------------------------------------------------------------
# Code quality delta (lightweight)
# ---------------------------------------------------------------------------

def _compute_code_quality_delta(changed_files) -> Dict:
    """Compute a lightweight code quality delta for changed files."""
    py_files = [f for f in changed_files if f.endswith(".py")]
    yaml_files = [f for f in changed_files if f.endswith((".yaml", ".yml"))]
    test_files = [f for f in changed_files if "test" in f.lower()]
    return {
        "total_files_changed": len(changed_files),
        "python_files_changed": len(py_files),
        "config_files_changed": len(yaml_files),
        "test_files_changed": len(test_files),
        "test_coverage_impact": "positive" if test_files else "neutral",
    }


# ---------------------------------------------------------------------------
# Main analysis function
# ---------------------------------------------------------------------------

def analyze_pr(project_id, pr_reference=None, project_dir=None, db_path=None) -> Dict:
    """Run all checks and generate a consolidated PR intelligence report.

    Steps:
      (a) Get git diff (subprocess git diff HEAD~1)
      (b) Count files changed
      (c) Run security precheck
      (d) Run compliance precheck
      (e) Compute code quality delta
      (f) INSERT into pr_intelligence_reports
    """
    conn = _get_connection(db_path)
    _ensure_tables(conn)

    report_id = uuid.uuid4().hex[:12]
    now = datetime.now(timezone.utc).isoformat()

    # (a) + (b) Git diff
    diff_info = _get_git_diff(project_dir)
    changed_files = diff_info["changed_files"]
    files_changed = diff_info["files_changed"]

    # (c) Security precheck
    security = run_security_precheck(project_dir, db_path)

    _log_audit(conn, project_id, "pr_security_checked", "security_precheck",
               {"report_id": report_id, "findings": security["findings_count"],
                "status": security["status"]})

    # (d) Compliance precheck
    compliance = run_compliance_precheck(project_id, changed_files, db_path)

    _log_audit(conn, project_id, "pr_compliance_checked", "compliance_precheck",
               {"report_id": report_id, "affected_controls": len(compliance["affected_controls"]),
                "impact_level": compliance["impact_level"]})

    # (e) Code quality delta
    code_quality_delta = _compute_code_quality_delta(changed_files)

    # (e2) E2E coverage check — flag UI changes without E2E spec updates
    e2e_coverage = run_e2e_coverage_check(changed_files, project_dir)

    if e2e_coverage["coverage_gap"]:
        _log_audit(conn, project_id, "pr_e2e_coverage_gap", "e2e_coverage_check",
                   {"report_id": report_id,
                    "ui_files_changed": e2e_coverage["ui_files_changed"],
                    "e2e_specs_updated": e2e_coverage["e2e_specs_updated_in_pr"]})

    # Determine overall status
    if security["status"] == "fail":
        overall_status = "fail"
    elif security["status"] == "warn" or compliance["status"] == "warn":
        overall_status = "warn"
    elif e2e_coverage["status"] == "warn":
        overall_status = "warn"
    else:
        overall_status = "pass"

    # (f) Store report
    conn.execute(
        """INSERT INTO pr_intelligence_reports
           (id, project_id, pr_reference, files_changed,
            security_json, compliance_json, code_quality_json,
            overall_status, classification, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (report_id, project_id, pr_reference or "", files_changed,
         json.dumps(security), json.dumps(compliance),
         json.dumps(code_quality_delta), overall_status,
         "CUI // SP-CTI", now),
    )
    conn.commit()

    _log_audit(conn, project_id, "pr_analyzed", "analyze_pr",
               {"report_id": report_id, "overall_status": overall_status,
                "files_changed": files_changed})

    conn.close()

    return {
        "id": report_id,
        "project_id": project_id,
        "pr_reference": pr_reference or "",
        "files_changed": files_changed,
        "security": security,
        "compliance": compliance,
        "e2e_coverage": e2e_coverage,
        "code_quality_delta": code_quality_delta,
        "overall_status": overall_status,
    }


def generate_pr_report(report_id, db_path=None) -> Dict:
    """Load a PR intelligence report from the database."""
    conn = _get_connection(db_path)
    _ensure_tables(conn)

    row = conn.execute(
        "SELECT * FROM pr_intelligence_reports WHERE id = ?", (report_id,)
    ).fetchone()
    conn.close()

    if not row:
        return {"error": f"Report not found: {report_id}"}

    return {
        "id": row["id"],
        "project_id": row["project_id"],
        "pr_reference": row["pr_reference"],
        "files_changed": row["files_changed"],
        "security": json.loads(row["security_json"]) if row["security_json"] else {},
        "compliance": json.loads(row["compliance_json"]) if row["compliance_json"] else {},
        "code_quality_delta": json.loads(row["code_quality_json"]) if row["code_quality_json"] else {},
        "overall_status": row["overall_status"],
        "classification": row["classification"],
        "created_at": row["created_at"],
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="PR Intelligence with Compliance Pre-Check"
    )
    parser.add_argument("--project-id", required=True, help="Project identifier")
    parser.add_argument("--analyze", action="store_true", help="Run full PR analysis")
    parser.add_argument("--pr-reference", default=None, help="PR reference (e.g., PR-42)")
    parser.add_argument("--project-dir", default=None, help="Project directory for git/scanning")
    parser.add_argument("--report", action="store_true", help="Retrieve a stored report")
    parser.add_argument("--report-id", default=None, help="Report ID to retrieve")
    parser.add_argument("--json", action="store_true", help="JSON output")

    args = parser.parse_args()

    result = {}

    if args.analyze:
        result = analyze_pr(
            project_id=args.project_id,
            pr_reference=args.pr_reference,
            project_dir=args.project_dir,
        )
    elif args.report:
        if not args.report_id:
            print("Error: --report-id is required with --report", file=sys.stderr)
            sys.exit(1)
        result = generate_pr_report(report_id=args.report_id)
    else:
        parser.print_help()
        sys.exit(1)

    if args.json:
        print(json.dumps(result, indent=2, default=str))
    else:
        # Human-readable output
        print(f"PR Intelligence Report: {result.get('id', 'N/A')}")
        print(f"  Project:        {result.get('project_id', 'N/A')}")
        print(f"  PR Reference:   {result.get('pr_reference', 'N/A')}")
        print(f"  Files Changed:  {result.get('files_changed', 0)}")
        print(f"  Overall Status: {result.get('overall_status', 'N/A')}")
        sec = result.get("security", {})
        if sec:
            print(f"  Security:       {sec.get('status', 'N/A')} "
                  f"(C:{sec.get('critical', 0)} H:{sec.get('high', 0)} "
                  f"M:{sec.get('medium', 0)} L:{sec.get('low', 0)})")
        comp = result.get("compliance", {})
        if comp:
            print(f"  Compliance:     {comp.get('status', 'N/A')} "
                  f"(impact: {comp.get('impact_level', 'N/A')})")


if __name__ == "__main__":
    main()
