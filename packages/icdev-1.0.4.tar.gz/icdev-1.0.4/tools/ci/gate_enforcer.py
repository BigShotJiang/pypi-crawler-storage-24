# CUI // SP-CTI
"""Pipeline gate enforcement engine.

Reads ``args/pipeline_gates.yaml`` and executes the configured gates for a
given stage.  Each gate invokes the referenced tool (as a subprocess) and
evaluates the blocking conditions against the tool's JSON output.

Usage::

    from tools.ci.gate_enforcer import enforce_stage, list_stages

    # Run all gates for the 'build' stage
    results = enforce_stage("build", project_dir="/path/to/project")

    # CLI
    python tools/ci/gate_enforcer.py --stage build --project-dir . --json

Classification: CUI // SP-CTI
"""

from __future__ import annotations

import json
import logging
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("icdev.ci.gate_enforcer")

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_GATES_CONFIG_PATH = _PROJECT_ROOT / "args" / "pipeline_gates.yaml"


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def _load_gates_config() -> Dict[str, Any]:
    """Load pipeline_gates.yaml."""
    try:
        import yaml
    except ImportError:
        logger.warning("PyYAML not available — cannot load gate config")
        return {}
    if not _GATES_CONFIG_PATH.exists():
        logger.warning("Gate config not found at %s", _GATES_CONFIG_PATH)
        return {}
    try:
        with open(_GATES_CONFIG_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception as exc:
        logger.error("Failed to load gate config: %s", exc)
        return {}


def list_stages() -> List[str]:
    """Return available pipeline stage names."""
    cfg = _load_gates_config()
    return list(cfg.get("stages", {}).keys())


def get_stage_gates(stage: str) -> List[Dict[str, Any]]:
    """Return gate definitions for a given stage."""
    cfg = _load_gates_config()
    stage_cfg = cfg.get("stages", {}).get(stage, {})
    return stage_cfg.get("gates", [])


# ---------------------------------------------------------------------------
# Gate execution
# ---------------------------------------------------------------------------

def _run_tool(tool_path: str, project_dir: str, timeout: int) -> Dict[str, Any]:
    """Execute a gate tool and capture its JSON output.

    Returns a dict with keys: success, output, error, exit_code, elapsed_ms.
    """
    resolved = _PROJECT_ROOT / tool_path if not Path(tool_path).is_absolute() else Path(tool_path)

    # Only run Python tools that exist on disk
    if not resolved.exists():
        return {
            "success": False,
            "output": {},
            "error": f"Tool not found: {tool_path}",
            "exit_code": -1,
            "elapsed_ms": 0,
        }

    cmd = [sys.executable, str(resolved), "--project-dir", project_dir, "--json"]

    start = time.time()
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(_PROJECT_ROOT),
        )
        elapsed = int((time.time() - start) * 1000)

        # Try to parse JSON from stdout
        output = {}
        if proc.stdout.strip():
            try:
                output = json.loads(proc.stdout.strip())
            except json.JSONDecodeError:
                output = {"raw_output": proc.stdout.strip()}

        return {
            "success": proc.returncode == 0,
            "output": output,
            "error": proc.stderr.strip() if proc.returncode != 0 else "",
            "exit_code": proc.returncode,
            "elapsed_ms": elapsed,
        }
    except subprocess.TimeoutExpired:
        elapsed = int((time.time() - start) * 1000)
        return {
            "success": False,
            "output": {},
            "error": f"Gate timed out after {timeout}s",
            "exit_code": -2,
            "elapsed_ms": elapsed,
        }
    except Exception as exc:
        elapsed = int((time.time() - start) * 1000)
        return {
            "success": False,
            "output": {},
            "error": str(exc),
            "exit_code": -3,
            "elapsed_ms": elapsed,
        }


def _evaluate_block_condition(block_on: Any, output: Dict[str, Any]) -> bool:
    """Evaluate whether a gate should block based on its block_on rule.

    Returns True if the gate BLOCKS (i.e. failure condition met).
    """
    if block_on == "any_finding" or block_on == "any_failure":
        # Block if exit code was non-zero or output has findings
        findings = output.get("findings", output.get("failures", []))
        return bool(findings)

    if block_on == "missing_markings":
        return bool(output.get("missing_markings", []))

    if block_on == "syntax_error":
        return bool(output.get("syntax_errors", []))

    if block_on == "error_severity":
        errors = output.get("errors", [])
        return any(e.get("severity") == "error" for e in errors) if errors else False

    if block_on == "gate_failed":
        return output.get("gate_result") == "FAIL"

    if block_on == "high_confidence_injection":
        return output.get("high_confidence_count", 0) > 0

    if block_on == "critical_failure":
        return output.get("status") == "critical"

    if isinstance(block_on, dict):
        # Structured conditions like {severity: [critical, high]} or {cat1_findings: 0}
        for key, threshold in block_on.items():
            actual = output.get(key, 0)
            if isinstance(threshold, list):
                # severity: [critical, high] — check findings by severity
                findings = output.get("findings", [])
                matching = [f for f in findings if f.get("severity") in threshold]
                if matching:
                    return True
            elif isinstance(threshold, (int, float)):
                # cat1_findings: 0 — block if actual exceeds threshold
                if isinstance(actual, (int, float)) and actual > threshold:
                    return True
            elif isinstance(threshold, str):
                # maturity_below: advanced
                maturity_order = ["initial", "traditional", "advanced", "optimal"]
                actual_level = str(actual).lower()
                if actual_level in maturity_order and threshold.lower() in maturity_order:
                    if maturity_order.index(actual_level) < maturity_order.index(threshold.lower()):
                        return True
        return False

    return False


def enforce_gate(gate: Dict[str, Any], project_dir: str) -> Dict[str, Any]:
    """Execute a single gate and return its result.

    Returns dict with: name, tool, blocking, passed, blocked, output, error, elapsed_ms.
    """
    name = gate.get("name", "unknown")
    tool = gate.get("tool", "")
    blocking = gate.get("blocking", False)
    timeout = gate.get("timeout_seconds", 120)
    block_on = gate.get("block_on")

    logger.info("Running gate: %s (tool=%s, blocking=%s)", name, tool, blocking)

    # Run the tool
    result = _run_tool(tool, project_dir, timeout)

    # Evaluate blocking condition
    blocked = False
    if blocking and block_on:
        if not result["success"]:
            blocked = True
        else:
            blocked = _evaluate_block_condition(block_on, result["output"])

    passed = result["success"] and not blocked

    return {
        "name": name,
        "tool": tool,
        "blocking": blocking,
        "passed": passed,
        "blocked": blocked,
        "output": result["output"],
        "error": result["error"],
        "exit_code": result["exit_code"],
        "elapsed_ms": result["elapsed_ms"],
        "classification": "CUI // SP-CTI",
    }


def enforce_stage(
    stage: str,
    project_dir: str = ".",
    fail_fast: bool = False,
) -> Dict[str, Any]:
    """Execute all gates for a pipeline stage.

    Parameters
    ----------
    stage : str
        Pipeline stage name (e.g. ``"build"``, ``"pre_deploy"``).
    project_dir : str
        Project directory to scan.
    fail_fast : bool
        If True, stop on the first blocking failure.

    Returns
    -------
    dict
        Stage result with keys: stage, passed, gate_results, blocked_by, elapsed_ms.
    """
    gates = get_stage_gates(stage)
    if not gates:
        return {
            "stage": stage,
            "passed": True,
            "gate_results": [],
            "blocked_by": [],
            "elapsed_ms": 0,
            "classification": "CUI // SP-CTI",
        }

    start = time.time()
    gate_results = []
    blocked_by = []

    for gate_def in gates:
        result = enforce_gate(gate_def, project_dir)
        gate_results.append(result)

        if result["blocked"]:
            blocked_by.append(result["name"])
            if fail_fast:
                break

    elapsed = int((time.time() - start) * 1000)

    return {
        "stage": stage,
        "passed": len(blocked_by) == 0,
        "gate_results": gate_results,
        "blocked_by": blocked_by,
        "elapsed_ms": elapsed,
        "classification": "CUI // SP-CTI",
    }


# ---------------------------------------------------------------------------
# Audit trail
# ---------------------------------------------------------------------------

def _log_gate_result(result: Dict[str, Any]) -> None:
    """Append gate execution result to audit trail (append-only)."""
    try:
        from tools.db.storage import get_connection
        conn = get_connection()
        conn.execute(
            """INSERT INTO audit_trail (event_type, event_data, classification)
               VALUES (?, ?, ?)""",
            (
                "pipeline_gate",
                json.dumps(result),
                "CUI // SP-CTI",
            ),
        )
        conn.commit()
    except Exception as exc:
        logger.debug("Could not log gate result to audit trail: %s", exc)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    import argparse

    parser = argparse.ArgumentParser(description="Pipeline gate enforcer")
    parser.add_argument("--stage", required=False, help="Pipeline stage to enforce")
    parser.add_argument("--list", action="store_true", help="List available stages")
    parser.add_argument("--project-dir", default=".", help="Project directory")
    parser.add_argument("--fail-fast", action="store_true", help="Stop on first blocking failure")
    parser.add_argument("--json", action="store_true", help="JSON output")
    args = parser.parse_args()

    if args.list:
        stages = list_stages()
        if args.json:
            print(json.dumps({"stages": stages}, indent=2))
        else:
            for s in stages:
                gates = get_stage_gates(s)
                print(f"  {s}: {len(gates)} gates")
        return

    if not args.stage:
        parser.error("--stage is required unless --list is used")

    result = enforce_stage(args.stage, args.project_dir, args.fail_fast)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        status = "PASSED" if result["passed"] else "BLOCKED"
        print(f"Stage '{args.stage}': {status} ({result['elapsed_ms']}ms)")
        for gr in result["gate_results"]:
            mark = "PASS" if gr["passed"] else "BLOCK" if gr["blocked"] else "WARN"
            print(f"  [{mark}] {gr['name']} ({gr['elapsed_ms']}ms)")
        if result["blocked_by"]:
            print(f"\n  Blocked by: {', '.join(result['blocked_by'])}")

    sys.exit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()
