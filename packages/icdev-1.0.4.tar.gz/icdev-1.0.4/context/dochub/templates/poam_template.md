# {{classification_marking}}

---

# Plan of Action and Milestones (POA&M)

**System Name:** {{system_name}}
**Generated:** {{generated_date}}

---

## Table of Contents

1. [POA&M Summary](#1-poam-summary)
2. [Risk Summary](#2-risk-summary)
3. [POA&M Items](#3-poam-items)
4. [Milestone Summary](#4-milestone-summary)
5. [Overdue Items](#5-overdue-items)
6. [Appendices](#6-appendices)

---

## 1. POA&M Summary

### 1.1 Overview

| Metric | Count |
|--------|-------|
| Total POA&M Items | {{total_items}} |
| Open | {{open_count}} |
| In Progress | {{in_progress_count}} |
| Completed | {{completed_count}} |
| Overdue | {{overdue_count}} |
| Accepted Risk | {{accepted_risk_count}} |

### 1.2 Severity Distribution

| Severity | Count | Percentage |
|----------|-------|------------|
| Critical (CAT I) | {{cat1_count}} | {{cat1_pct}} |
| High (CAT II) | {{cat2_count}} | {{cat2_pct}} |
| Medium (CAT III) | {{cat3_count}} | {{cat3_pct}} |
| Low | {{low_count}} | {{low_pct}} |

---

## 2. Risk Summary

### 2.1 Risk Overview

{{risk_summary}}

### 2.2 Risk Acceptance Decisions

| POA&M ID | Control | Risk Level | Accepted By | Rationale | Expiration |
|----------|---------|------------|-------------|-----------|------------|
{{risk_acceptance_table}}

---

## 3. POA&M Items

### 3.1 Items Table

| POA&M ID | Control | Weakness | Severity | Status | Scheduled Completion | Responsible | Resources |
|----------|---------|----------|----------|--------|---------------------|-------------|-----------|
{{poam_items_table}}

### 3.2 Item Details

{{poam_item_details}}

---

## 4. Milestone Summary

### 4.1 Milestone Tracker

{{milestone_summary}}

### 4.2 Milestone Timeline

| Milestone | Target Date | Status | Dependencies |
|-----------|-------------|--------|--------------|
{{milestone_timeline_table}}

---

## 5. Overdue Items

### 5.1 Overdue Summary

**Total Overdue:** {{overdue_count}}

### 5.2 Overdue Items Detail

| POA&M ID | Control | Days Overdue | Original Due Date | Responsible | Escalation Status |
|----------|---------|-------------|-------------------|-------------|-------------------|
{{overdue_items_table}}

---

## 6. Appendices

### 6.1 References

{{references}}

### 6.2 Revision History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
{{revision_history_table}}

---

# {{classification_marking}}
