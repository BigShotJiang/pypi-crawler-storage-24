# {{classification_marking}}

---

# System Design Document (SDD)

**System Name:** {{system_name}}
**Generated:** {{generated_date}}

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Technology Stack](#2-technology-stack)
3. [Component Design](#3-component-design)
4. [Interface Contracts](#4-interface-contracts)
5. [Data Model](#5-data-model)
6. [Deployment Topology](#6-deployment-topology)
7. [Architecture Decision Records](#7-architecture-decision-records)
8. [Code Quality Metrics](#8-code-quality-metrics)
9. [Appendices](#9-appendices)

---

## 1. Architecture Overview

### 1.1 System Context (C4 Level 1)

{{architecture_overview}}

### 1.2 Container Diagram (C4 Level 2)

{{container_diagram}}

### 1.3 Design Principles

{{design_principles}}

### 1.4 Key Constraints

{{constraints}}

---

## 2. Technology Stack

| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
{{technology_stack}}

---

## 3. Component Design

### 3.1 Component Summary

{{component_table}}

### 3.2 Component Diagram (C4 Level 3)

{{component_diagram}}

### 3.3 Component Details

{{component_details}}

### 3.4 Component Dependencies

{{component_dependencies}}

---

## 4. Interface Contracts

### 4.1 External Interfaces

{{external_interfaces}}

### 4.2 Internal Interfaces

{{internal_interfaces}}

### 4.3 Interface Contract Details

{{interface_contracts}}

### 4.4 API Specifications

{{api_specifications}}

---

## 5. Data Model

### 5.1 Entity Relationship Diagram

{{er_diagram}}

### 5.2 Data Dictionary

{{data_model}}

### 5.3 Data Flow

{{data_flow}}

### 5.4 Data Retention and Lifecycle

{{data_retention}}

---

## 6. Deployment Topology

### 6.1 Deployment Diagram

{{deployment_diagram}}

### 6.2 Environment Details

{{deployment_topology}}

### 6.3 Infrastructure Requirements

{{infrastructure_requirements}}

### 6.4 Scaling Strategy

{{scaling_strategy}}

---

## 7. Architecture Decision Records

### 7.1 ADR Summary

| ADR ID | Title | Status | Date | Decision |
|--------|-------|--------|------|----------|
{{adr_summary}}

### 7.2 ADR Details

{{adr_details}}

---

## 8. Code Quality Metrics

### 8.1 Quality Summary

| Metric | Value | Threshold | Status |
|--------|-------|-----------|--------|
{{code_quality_metrics}}

### 8.2 Complexity Analysis

{{complexity_analysis}}

### 8.3 Test Coverage

{{test_coverage}}

---

## 9. Appendices

### 9.1 Glossary

{{glossary}}

### 9.2 References

{{references}}

### 9.3 Revision History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
{{revision_history_table}}

---

# {{classification_marking}}
