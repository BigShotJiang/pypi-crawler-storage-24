# {{classification_marking}}

---

# Software Bill of Materials (SBOM) Summary

**System Name:** {{system_name}}
**Generated:** {{generated_date}}

---

## Table of Contents

1. [Component Summary](#1-component-summary)
2. [Dependency Tree](#2-dependency-tree)
3. [Vulnerability Summary](#3-vulnerability-summary)
4. [License Breakdown](#4-license-breakdown)
5. [Supply Chain Risk](#5-supply-chain-risk)
6. [Appendices](#6-appendices)

---

## 1. Component Summary

### 1.1 Overview

| Metric | Count |
|--------|-------|
| Total Components | {{total_components}} |
| Direct Dependencies | {{direct_dependencies}} |
| Transitive Dependencies | {{transitive_dependencies}} |
| Unique Licenses | {{unique_licenses}} |
| Known Vulnerabilities | {{known_vulnerabilities}} |

### 1.2 Component Distribution by Type

| Type | Count | Percentage |
|------|-------|------------|
{{component_type_table}}

### 1.3 Component Distribution by Language

| Language | Count | Percentage |
|----------|-------|------------|
{{component_language_table}}

---

## 2. Dependency Tree

### 2.1 Direct Dependencies

| Package | Version | License | Vulnerabilities | Risk |
|---------|---------|---------|-----------------|------|
{{direct_deps_table}}

### 2.2 Transitive Dependencies

{{transitive_deps_table}}

### 2.3 Dependency Graph

{{dependency_graph}}

---

## 3. Vulnerability Summary

### 3.1 Vulnerability Overview

{{vulnerability_summary}}

### 3.2 Vulnerability Distribution

| Severity | Count | Patched Available | Exploitable |
|----------|-------|-------------------|-------------|
| Critical | {{vuln_critical}} | {{vuln_critical_patched}} | {{vuln_critical_exploitable}} |
| High | {{vuln_high}} | {{vuln_high_patched}} | {{vuln_high_exploitable}} |
| Medium | {{vuln_medium}} | {{vuln_medium_patched}} | {{vuln_medium_exploitable}} |
| Low | {{vuln_low}} | {{vuln_low_patched}} | {{vuln_low_exploitable}} |

### 3.3 Vulnerability Details

| CVE | Component | Severity | CVSS | Status | Remediation |
|-----|-----------|----------|------|--------|-------------|
{{vulnerability_details_table}}

---

## 4. License Breakdown

### 4.1 License Summary

{{license_breakdown}}

### 4.2 License Distribution

| License | Count | Category | Copyleft Risk |
|---------|-------|----------|---------------|
{{license_distribution_table}}

### 4.3 License Compliance Issues

{{license_compliance_issues}}

---

## 5. Supply Chain Risk

### 5.1 Risk Score

**Overall Supply Chain Risk Score:** {{supply_chain_risk_score}}

### 5.2 Risk Factors

| Factor | Score | Weight | Contribution |
|--------|-------|--------|--------------|
{{risk_factors_table}}

### 5.3 Vendor Risk Assessment

{{vendor_risk_assessment}}

---

## 6. Appendices

### 6.1 SBOM Format Details

{{sbom_format_details}}

### 6.2 References

{{references}}

### 6.3 Revision History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
{{revision_history_table}}

---

# {{classification_marking}}
