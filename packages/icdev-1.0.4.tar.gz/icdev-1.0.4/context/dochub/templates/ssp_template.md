# {{classification_marking}}

---

# System Security Plan (SSP)

**System Name:** {{system_name}}
**Version:** {{version}}
**Generated:** {{generated_date}}
**System Owner:** {{system_owner}}
**Impact Level:** {{impact_level}}

---

## Table of Contents

1. [System Overview](#1-system-overview)
2. [Authorization Boundary](#2-authorization-boundary)
3. [Data Flow Description](#3-data-flow-description)
4. [Interconnections](#4-interconnections)
5. [Control Implementations](#5-control-implementations)
6. [Risk Assessment Summary](#6-risk-assessment-summary)
7. [Continuous Monitoring Strategy](#7-continuous-monitoring-strategy)
8. [Appendices](#8-appendices)

---

## 1. System Overview

### 1.1 System Description

{{system_description}}

### 1.2 System Purpose and Scope

This SSP documents the security controls implemented for **{{system_name}}** operating at **{{impact_level}}**. The system processes, stores, and transmits data classified as **{{classification_marking}}**.

### 1.3 System Environment

| Attribute | Value |
|-----------|-------|
| System Name | {{system_name}} |
| System Owner | {{system_owner}} |
| Impact Level | {{impact_level}} |
| Deployment Model | {{deployment_model}} |
| Operating Environment | {{operating_environment}} |

### 1.4 System Users and Roles

{{user_roles_table}}

---

## 2. Authorization Boundary

### 2.1 Boundary Description

{{authorization_boundary}}

### 2.2 Boundary Diagram

{{boundary_diagram}}

### 2.3 Components Within Boundary

{{boundary_components_table}}

---

## 3. Data Flow Description

### 3.1 Data Flow Overview

{{data_flow_description}}

### 3.2 Data Flow Diagram

{{data_flow_diagram}}

### 3.3 Data Types and Sensitivity

| Data Type | Sensitivity Level | Storage Location | Encryption |
|-----------|------------------|------------------|------------|
{{data_types_table}}

---

## 4. Interconnections

### 4.1 External Interconnections

{{interconnections_table}}

### 4.2 Interconnection Security Agreements (ISA)

{{isa_summary}}

---

## 5. Control Implementations

### 5.1 Control Summary

| Metric | Count |
|--------|-------|
| Total Controls | {{total_controls}} |
| Implemented | {{implemented_count}} |
| Partially Implemented | {{partial_count}} |
| Planned | {{planned_count}} |
| Not Applicable | {{na_count}} |

### 5.2 Control Implementation Details

{{control_implementations_table}}

---

## 6. Risk Assessment Summary

### 6.1 Risk Overview

{{risk_assessment_summary}}

### 6.2 Risk Register

| Risk ID | Description | Likelihood | Impact | Risk Level | Mitigation |
|---------|-------------|------------|--------|------------|------------|
{{risk_register_table}}

---

## 7. Continuous Monitoring Strategy

### 7.1 Monitoring Approach

{{continuous_monitoring_strategy}}

### 7.2 Monitoring Schedule

| Control Family | Frequency | Method | Responsible Party |
|---------------|-----------|--------|-------------------|
{{monitoring_schedule_table}}

### 7.3 Automated Monitoring Tools

{{automated_monitoring_tools}}

---

## 8. Appendices

### 8.1 Acronyms and Definitions

{{acronyms_table}}

### 8.2 References

{{references}}

### 8.3 Revision History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
{{revision_history_table}}

---

# {{classification_marking}}
