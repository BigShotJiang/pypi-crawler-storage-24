# {{classification_marking}}

---

# Security Assessment Report (SAR)

**System Name:** {{system_name}}
**Generated:** {{generated_date}}

---

## Table of Contents

1. [Assessment Methodology](#1-assessment-methodology)
2. [Assessor Information](#2-assessor-information)
3. [Findings](#3-findings)
4. [Risk Summary](#4-risk-summary)
5. [Recommendations](#5-recommendations)
6. [Appendices](#6-appendices)

---

## 1. Assessment Methodology

### 1.1 Assessment Scope

{{assessment_scope}}

### 1.2 Methodology

{{assessment_methodology}}

### 1.3 Assessment Timeline

| Phase | Start Date | End Date | Activities |
|-------|-----------|----------|------------|
{{assessment_timeline_table}}

### 1.4 Tools and Techniques

| Tool | Purpose | Version |
|------|---------|---------|
{{tools_table}}

### 1.5 Standards and Baselines

{{standards_baselines}}

---

## 2. Assessor Information

### 2.1 Assessment Organization

{{assessor_info}}

### 2.2 Assessment Team

| Name | Role | Certifications | Responsibilities |
|------|------|---------------|-----------------|
{{assessment_team_table}}

---

## 3. Findings

### 3.1 Findings Summary

| Severity | Count | Remediated | Open |
|----------|-------|------------|------|
| Critical (CAT I) | {{cat1_count}} | {{cat1_remediated}} | {{cat1_open}} |
| High (CAT II) | {{cat2_count}} | {{cat2_remediated}} | {{cat2_open}} |
| Medium (CAT III) | {{cat3_count}} | {{cat3_remediated}} | {{cat3_open}} |
| Low | {{low_count}} | {{low_remediated}} | {{low_open}} |

### 3.2 Findings Detail

{{findings_table}}

### 3.3 Control Assessment Results

| Control Family | Total | Satisfied | Partially | Not Satisfied | N/A |
|---------------|-------|-----------|-----------|--------------|-----|
{{control_assessment_table}}

---

## 4. Risk Summary

### 4.1 Overall Risk Posture

{{risk_summary}}

### 4.2 Risk by Category

| Category | Inherent Risk | Control Effectiveness | Residual Risk |
|----------|--------------|----------------------|---------------|
{{risk_category_table}}

### 4.3 Risk Trends

{{risk_trends}}

---

## 5. Recommendations

### 5.1 Recommendations Summary

{{recommendations_table}}

### 5.2 Prioritized Remediation Roadmap

| Priority | Finding | Recommendation | Estimated Effort | Target Date |
|----------|---------|----------------|-----------------|-------------|
{{remediation_roadmap_table}}

### 5.3 Authorization Recommendation

{{authorization_recommendation}}

---

## 6. Appendices

### 6.1 Evidence Inventory

{{evidence_inventory}}

### 6.2 References

{{references}}

### 6.3 Revision History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
{{revision_history_table}}

---

# {{classification_marking}}
