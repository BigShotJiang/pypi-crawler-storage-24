# {{classification_marking}}

---

# Program Management Plan (PMP)

**System Name:** {{system_name}}
**Generated:** {{generated_date}}

---

## Table of Contents

1. [Schedule Summary](#1-schedule-summary)
2. [Milestone Tracker](#2-milestone-tracker)
3. [Risk Register](#3-risk-register)
4. [Resource Plan](#4-resource-plan)
5. [DORA Metrics](#5-dora-metrics)
6. [Velocity Trends](#6-velocity-trends)
7. [Appendices](#7-appendices)

---

## 1. Schedule Summary

### 1.1 Program Timeline

{{schedule_summary}}

### 1.2 Phase Status

| Phase | Start | End | Status | % Complete | On Track |
|-------|-------|-----|--------|------------|----------|
{{phase_status_table}}

### 1.3 Critical Path

{{critical_path}}

---

## 2. Milestone Tracker

### 2.1 Milestone Summary

{{milestone_table}}

### 2.2 Milestone Timeline

| Milestone | Planned Date | Actual Date | Status | Owner | Dependencies |
|-----------|-------------|-------------|--------|-------|-------------|
{{milestone_detail_table}}

### 2.3 Upcoming Milestones (Next 30 Days)

{{upcoming_milestones}}

### 2.4 Overdue Milestones

{{overdue_milestones}}

---

## 3. Risk Register

### 3.1 Risk Summary

| Risk Level | Count | Mitigated | Accepted | Open |
|-----------|-------|-----------|----------|------|
| Critical | {{risk_critical}} | {{risk_critical_mitigated}} | {{risk_critical_accepted}} | {{risk_critical_open}} |
| High | {{risk_high}} | {{risk_high_mitigated}} | {{risk_high_accepted}} | {{risk_high_open}} |
| Medium | {{risk_medium}} | {{risk_medium_mitigated}} | {{risk_medium_accepted}} | {{risk_medium_open}} |
| Low | {{risk_low}} | {{risk_low_mitigated}} | {{risk_low_accepted}} | {{risk_low_open}} |

### 3.2 Risk Details

{{risk_register}}

### 3.3 Risk Burn-Down Trend

{{risk_burndown}}

---

## 4. Resource Plan

### 4.1 Resource Allocation

{{resource_plan}}

### 4.2 Resource Utilization

| Resource | Allocated | Utilized | Available | Utilization % |
|----------|-----------|----------|-----------|--------------|
{{resource_utilization_table}}

### 4.3 Resource Conflicts

{{resource_conflicts}}

---

## 5. DORA Metrics

### 5.1 DORA Dashboard

{{dora_metrics_table}}

### 5.2 Metric Details

| Metric | Current | Previous | Target | Trend |
|--------|---------|----------|--------|-------|
| Deployment Frequency | {{deploy_freq_current}} | {{deploy_freq_prev}} | {{deploy_freq_target}} | {{deploy_freq_trend}} |
| Lead Time for Changes | {{lead_time_current}} | {{lead_time_prev}} | {{lead_time_target}} | {{lead_time_trend}} |
| Change Failure Rate | {{cfr_current}} | {{cfr_prev}} | {{cfr_target}} | {{cfr_trend}} |
| Mean Time to Recovery | {{mttr_current}} | {{mttr_prev}} | {{mttr_target}} | {{mttr_trend}} |

### 5.3 DORA Performance Classification

{{dora_classification}}

---

## 6. Velocity Trends

### 6.1 Velocity Summary

{{velocity_trends}}

### 6.2 Sprint/Iteration Metrics

| Iteration | Planned | Completed | Velocity | Carry-Over |
|-----------|---------|-----------|----------|------------|
{{iteration_metrics_table}}

### 6.3 Throughput Analysis

{{throughput_analysis}}

---

## 7. Appendices

### 7.1 Acronyms

{{acronyms_table}}

### 7.2 References

{{references}}

### 7.3 Revision History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
{{revision_history_table}}

---

# {{classification_marking}}
