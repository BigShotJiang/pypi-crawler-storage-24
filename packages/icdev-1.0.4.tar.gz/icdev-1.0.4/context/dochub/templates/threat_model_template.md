# {{classification_marking}}

---

# Threat Model

**System Name:** {{system_name}}
**Generated:** {{generated_date}}

---

## Table of Contents

1. [Attack Surface](#1-attack-surface)
2. [Data Flow Diagram](#2-data-flow-diagram)
3. [STRIDE Analysis](#3-stride-analysis)
4. [Mitigations](#4-mitigations)
5. [Risk Ratings](#5-risk-ratings)
6. [NIST Control Mapping](#6-nist-control-mapping)
7. [Appendices](#7-appendices)

---

## 1. Attack Surface

### 1.1 Attack Surface Summary

{{attack_surface}}

### 1.2 Entry Points

| Entry Point | Protocol | Authentication | Trust Level | Exposure |
|-------------|----------|----------------|-------------|----------|
{{entry_points_table}}

### 1.3 Assets

| Asset | Type | Sensitivity | Location | Protection |
|-------|------|-------------|----------|------------|
{{assets_table}}

---

## 2. Data Flow Diagram

### 2.1 DFD Overview

{{data_flow_diagram}}

### 2.2 Trust Boundaries

{{trust_boundaries}}

### 2.3 Data Stores

| Store | Data Type | Sensitivity | Access Controls |
|-------|-----------|-------------|-----------------|
{{data_stores_table}}

---

## 3. STRIDE Analysis

### 3.1 STRIDE Summary

| Category | Threat Count | Critical | High | Medium | Low |
|----------|-------------|----------|------|--------|-----|
| Spoofing | {{spoofing_count}} | {{spoofing_critical}} | {{spoofing_high}} | {{spoofing_medium}} | {{spoofing_low}} |
| Tampering | {{tampering_count}} | {{tampering_critical}} | {{tampering_high}} | {{tampering_medium}} | {{tampering_low}} |
| Repudiation | {{repudiation_count}} | {{repudiation_critical}} | {{repudiation_high}} | {{repudiation_medium}} | {{repudiation_low}} |
| Information Disclosure | {{info_disc_count}} | {{info_disc_critical}} | {{info_disc_high}} | {{info_disc_medium}} | {{info_disc_low}} |
| Denial of Service | {{dos_count}} | {{dos_critical}} | {{dos_high}} | {{dos_medium}} | {{dos_low}} |
| Elevation of Privilege | {{eop_count}} | {{eop_critical}} | {{eop_high}} | {{eop_medium}} | {{eop_low}} |

### 3.2 STRIDE Detail

{{stride_analysis_table}}

---

## 4. Mitigations

### 4.1 Mitigation Summary

| Status | Count |
|--------|-------|
| Implemented | {{mitigations_implemented}} |
| Planned | {{mitigations_planned}} |
| Accepted Risk | {{mitigations_accepted}} |

### 4.2 Mitigation Details

| Threat ID | Threat | Mitigation | Status | Control ID | Responsible |
|-----------|--------|------------|--------|------------|-------------|
{{mitigations_table}}

---

## 5. Risk Ratings

### 5.1 Risk Matrix

{{risk_ratings}}

### 5.2 Residual Risk Summary

| Component | Inherent Risk | Controls | Residual Risk |
|-----------|--------------|----------|---------------|
{{residual_risk_table}}

---

## 6. NIST Control Mapping

### 6.1 STRIDE-to-NIST Mapping

| STRIDE Category | NIST Control Families | Primary Controls |
|----------------|----------------------|-----------------|
| Spoofing | AC, IA | AC-2, AC-3, IA-2, IA-5 |
| Tampering | SC, SI | SC-8, SC-13, SI-7 |
| Repudiation | AU | AU-2, AU-3, AU-6, AU-12 |
| Information Disclosure | SC | SC-8, SC-12, SC-13, SC-28 |
| Denial of Service | SC, CP | SC-5, CP-7, CP-8 |
| Elevation of Privilege | AC | AC-2, AC-3, AC-5, AC-6 |

### 6.2 Control Coverage

{{nist_mapping_table}}

---

## 7. Appendices

### 7.1 Methodology

{{methodology}}

### 7.2 References

{{references}}

### 7.3 Revision History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
{{revision_history_table}}

---

# {{classification_marking}}
