# {{classification_marking}}

---

# Audit Report

**System Name:** {{system_name}}
**Generated:** {{generated_date}}

---

## Table of Contents

1. [Findings Summary](#1-findings-summary)
2. [Evidence Chain](#2-evidence-chain)
3. [Remediation Status](#3-remediation-status)
4. [Change Log](#4-change-log)
5. [Appendices](#5-appendices)

---

## 1. Findings Summary

### 1.1 Audit Overview

{{audit_overview}}

### 1.2 Findings by Severity

| Severity | Count | Resolved | Open | Accepted Risk |
|----------|-------|----------|------|--------------|
| Critical | {{finding_critical}} | {{finding_critical_resolved}} | {{finding_critical_open}} | {{finding_critical_accepted}} |
| High | {{finding_high}} | {{finding_high_resolved}} | {{finding_high_open}} | {{finding_high_accepted}} |
| Medium | {{finding_medium}} | {{finding_medium_resolved}} | {{finding_medium_open}} | {{finding_medium_accepted}} |
| Low | {{finding_low}} | {{finding_low_resolved}} | {{finding_low_open}} | {{finding_low_accepted}} |
| Informational | {{finding_info}} | {{finding_info_resolved}} | {{finding_info_open}} | {{finding_info_accepted}} |

### 1.3 Findings Detail

{{findings_table}}

### 1.4 Findings by Control Family

| Control Family | Findings | Critical | High | Medium | Low |
|---------------|----------|----------|------|--------|-----|
{{findings_by_family_table}}

---

## 2. Evidence Chain

### 2.1 Evidence Overview

{{evidence_chain}}

### 2.2 Evidence Inventory

| Evidence ID | Type | Source | Collection Date | Integrity Hash | Linked Finding |
|-------------|------|--------|----------------|----------------|---------------|
{{evidence_inventory_table}}

### 2.3 Evidence Provenance

{{evidence_provenance}}

### 2.4 Evidence Gaps

| Control | Expected Evidence | Status | Gap Description |
|---------|-------------------|--------|-----------------|
{{evidence_gaps_table}}

---

## 3. Remediation Status

### 3.1 Remediation Overview

{{remediation_status}}

### 3.2 Remediation Tracker

| Finding ID | Severity | Status | Owner | Due Date | Completion Date | Verification |
|-----------|----------|--------|-------|----------|-----------------|-------------|
{{remediation_tracker_table}}

### 3.3 Overdue Remediations

{{overdue_remediations}}

### 3.4 Remediation Trend

{{remediation_trend}}

---

## 4. Change Log

### 4.1 Change Summary

{{change_log_summary}}

### 4.2 Change Log Detail

| Date | Change ID | Type | Description | Author | Impact | Approval |
|------|-----------|------|-------------|--------|--------|----------|
{{change_log_table}}

### 4.3 Configuration Changes

{{configuration_changes}}

### 4.4 Access Changes

{{access_changes}}

---

## 5. Appendices

### 5.1 Audit Methodology

{{audit_methodology}}

### 5.2 Audit Scope

{{audit_scope}}

### 5.3 References

{{references}}

### 5.4 Revision History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
{{revision_history_table}}

---

# {{classification_marking}}
