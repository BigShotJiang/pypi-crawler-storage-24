# {{classification_marking}}

---

# Security Posture Report

**System Name:** {{system_name}}
**Generated:** {{generated_date}}

---

## Table of Contents

1. [SAST Summary](#1-sast-summary)
2. [Dependency Audit](#2-dependency-audit)
3. [Secret Detection](#3-secret-detection)
4. [Secure by Design Score](#4-secure-by-design-score)
5. [AI Security Posture](#5-ai-security-posture)
6. [Zero Trust Maturity](#6-zero-trust-maturity)
7. [Supply Chain Risk](#7-supply-chain-risk)
8. [Vendor Assessments](#8-vendor-assessments)
9. [ISA Status](#9-isa-status)
10. [Appendices](#10-appendices)

---

## 1. SAST Summary

### 1.1 Static Analysis Overview

{{sast_summary}}

### 1.2 Findings by Severity

| Severity | Count | Fixed | Open | False Positive |
|----------|-------|-------|------|---------------|
| Critical | {{sast_critical}} | {{sast_critical_fixed}} | {{sast_critical_open}} | {{sast_critical_fp}} |
| High | {{sast_high}} | {{sast_high_fixed}} | {{sast_high_open}} | {{sast_high_fp}} |
| Medium | {{sast_medium}} | {{sast_medium_fixed}} | {{sast_medium_open}} | {{sast_medium_fp}} |
| Low | {{sast_low}} | {{sast_low_fixed}} | {{sast_low_open}} | {{sast_low_fp}} |

### 1.3 Top Finding Categories

{{sast_categories_table}}

---

## 2. Dependency Audit

### 2.1 Audit Overview

{{dependency_audit_summary}}

### 2.2 Vulnerable Dependencies

| Package | Version | CVE | Severity | Fixed In | Status |
|---------|---------|-----|----------|----------|--------|
{{vulnerable_deps_table}}

### 2.3 Outdated Dependencies

{{outdated_deps_table}}

---

## 3. Secret Detection

### 3.1 Detection Summary

{{secret_detection_summary}}

### 3.2 Findings

| Type | File | Status | Remediation |
|------|------|--------|-------------|
{{secret_findings_table}}

### 3.3 Secret Management Compliance

{{secret_management_compliance}}

---

## 4. Secure by Design Score

### 4.1 SbD Assessment

{{sbd_score}}

### 4.2 CISA SbD Pledge Alignment

| Requirement | Status | Evidence | Pillar |
|-------------|--------|----------|--------|
{{sbd_requirements_table}}

### 4.3 Exception Registry

{{sbd_exceptions_table}}

---

## 5. AI Security Posture

### 5.1 AI Security Overview

{{ai_security_posture}}

### 5.2 MITRE ATLAS Coverage

{{atlas_coverage}}

### 5.3 OWASP LLM Top 10

{{owasp_llm_status}}

### 5.4 Prompt Injection Defense

{{prompt_injection_status}}

### 5.5 AI Telemetry

{{ai_telemetry_status}}

---

## 6. Zero Trust Maturity

### 6.1 ZTA Overview

{{zta_maturity}}

### 6.2 7-Pillar Assessment

| Pillar | Maturity Level | Score | Target |
|--------|---------------|-------|--------|
{{zta_pillars_table}}

### 6.3 NIST 800-207 Compliance

{{nist_207_compliance}}

---

## 7. Supply Chain Risk

### 7.1 Risk Overview

{{supply_chain_risk}}

### 7.2 SCRM Assessment

{{scrm_assessment}}

### 7.3 CVE Triage Status

{{cve_triage_status}}

---

## 8. Vendor Assessments

### 8.1 Vendor Risk Summary

{{vendor_assessments}}

### 8.2 Vendor Details

| Vendor | Product | Risk Score | Last Assessed | Findings | Status |
|--------|---------|-----------|--------------|----------|--------|
{{vendor_details_table}}

---

## 9. ISA Status

### 9.1 ISA Overview

{{isa_status}}

### 9.2 Active ISAs

| ISA ID | Partner | Status | Expiration | Data Types | Risk Level |
|--------|---------|--------|------------|------------|------------|
{{isa_details_table}}

---

## 10. Appendices

### 10.1 Tool Versions

{{tool_versions_table}}

### 10.2 References

{{references}}

### 10.3 Revision History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
{{revision_history_table}}

---

# {{classification_marking}}
