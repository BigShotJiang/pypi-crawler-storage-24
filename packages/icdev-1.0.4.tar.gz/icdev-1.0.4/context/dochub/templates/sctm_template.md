# {{classification_marking}}

---

# Security Controls Traceability Matrix (SCTM)

**System Name:** {{system_name}}
**Generated:** {{generated_date}}

---

## Table of Contents

1. [Control Family Summary](#1-control-family-summary)
2. [Controls Matrix](#2-controls-matrix)
3. [Coverage Analysis](#3-coverage-analysis)
4. [Framework Crosswalk](#4-framework-crosswalk)
5. [Appendices](#5-appendices)

---

## 1. Control Family Summary

### 1.1 Overview

| Metric | Value |
|--------|-------|
| Total Control Families | {{total_families}} |
| Total Controls | {{total_controls}} |
| Implemented | {{implemented_count}} |
| Partially Implemented | {{partial_count}} |
| Planned | {{planned_count}} |
| Not Applicable | {{na_count}} |
| Coverage Percentage | {{coverage_percentage}} |

### 1.2 Family Distribution

| Family | Family Name | Total | Implemented | Partial | Planned | N/A |
|--------|------------|-------|-------------|---------|---------|-----|
{{control_family_summary}}

---

## 2. Controls Matrix

### 2.1 Full Controls Table

| Control ID | Control Name | Status | Implementation Description | Evidence | Responsible Party | Test Result |
|-----------|-------------|--------|---------------------------|----------|-------------------|-------------|
{{controls_table}}

### 2.2 Controls by Status

#### Implemented Controls

{{implemented_controls_detail}}

#### Partially Implemented Controls

{{partial_controls_detail}}

#### Planned Controls

{{planned_controls_detail}}

---

## 3. Coverage Analysis

### 3.1 Coverage Summary

**Overall Coverage:** {{coverage_percentage}}

### 3.2 Coverage by Family

| Family | Coverage | Gap Count | Critical Gaps |
|--------|----------|-----------|---------------|
{{coverage_by_family_table}}

### 3.3 Gap Analysis

{{gap_analysis}}

---

## 4. Framework Crosswalk

### 4.1 Crosswalk Summary

{{framework_crosswalk}}

### 4.2 Multi-Framework Alignment

| NIST 800-53 | FedRAMP | CMMC | NIST 800-171 | Status |
|-------------|---------|------|-------------|--------|
{{crosswalk_detail_table}}

### 4.3 Framework Coverage

| Framework | Total Required | Satisfied | Coverage |
|-----------|---------------|-----------|----------|
{{framework_coverage_table}}

---

## 5. Appendices

### 5.1 Evidence Repository

{{evidence_repository}}

### 5.2 References

{{references}}

### 5.3 Revision History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
{{revision_history_table}}

---

# {{classification_marking}}
