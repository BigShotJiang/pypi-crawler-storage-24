# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with sparkpilot.

---

## Quick Reference

### Commands
```bash
# Memory system
python tools/memory/memory_read.py --format markdown          # Load all memory
python tools/memory/memory_write.py --content "text" --type event  # Write to daily log + DB
python tools/memory/memory_write.py --content "text" --type fact --importance 7  # Store a fact
python tools/memory/memory_write.py --update-memory --content "text" --section user_preferences  # Update MEMORY.md
python tools/memory/memory_db.py --action search --query "keyword"   # Keyword search
python tools/memory/semantic_search.py --query "concept"             # Semantic search (requires OpenAI key)
python tools/memory/hybrid_search.py --query "query"                 # Best: combined keyword + semantic
python tools/memory/embed_memory.py --all                            # Generate embeddings for all entries
```

### CloudForge Runbooks & Metastore Commands
```bash
# Runbook Engine
python tools/cloudforge/runbooks/engine.py --list --json                    # List runbooks
python tools/cloudforge/runbooks/engine.py --get <id> --json                # Get runbook detail
python tools/cloudforge/runbooks/template_loader.py --list --json           # List YAML templates
python tools/cloudforge/runbooks/template_loader.py --load dr_failover --json  # Load template

# Application Metastore
python tools/cloudforge/metastore/registry.py --list --json                 # List applications
python tools/cloudforge/metastore/registry.py --get <id> --json             # Get app detail

# Ops MCP Server (18 tools: runbooks, metastore, cross-domain)
python tools/mcp/ops_server.py                                              # Start stdio MCP server
```

### Testing Commands
```bash
python tools/testing/health_check.py                 # Full system health check
python tools/testing/health_check.py --json           # JSON output
python tools/testing/test_orchestrator.py --project-dir /path/to/project
python tools/testing/e2e_runner.py --discover         # List available E2E test specs
python tools/testing/e2e_runner.py --run-all           # Execute all E2E tests
```

### Compliance Commands
```bash
python tools/compliance/ssp_generator.py --project-id "sparkpilot"
python tools/compliance/poam_generator.py --project-id "sparkpilot"
python tools/compliance/stig_checker.py --project-id "sparkpilot"
python tools/compliance/sbom_generator.py --project-dir "/path/to/project"
python tools/compliance/cui_marker.py --file "/path/to/file" --marking "CUI // SP-CTI"
python tools/compliance/nist_lookup.py --control "AC-2"
python tools/compliance/control_mapper.py --activity "code.commit" --project-id "sparkpilot"
python tools/compliance/crosswalk_engine.py --control AC-2
python tools/compliance/crosswalk_engine.py --project-id "sparkpilot" --coverage
python tools/compliance/fedramp_assessor.py --project-id "sparkpilot" --baseline moderate
python tools/compliance/cmmc_assessor.py --project-id "sparkpilot" --level 2
python tools/compliance/oscal_generator.py --project-id "sparkpilot" --artifact ssp
python tools/compliance/classification_manager.py --impact-level IL4

# Secure by Design (CISA SbD + Cloudyrion 8-Pillar)
python tools/compliance/sbd_assessor.py --project-id "sparkpilot" --project-dir . --gate --json
python tools/compliance/sbd_assessor.py --project-id "sparkpilot" --list-exceptions --json
python tools/compliance/sbd_assessor.py --project-id "sparkpilot" --register-exception --requirement-id "SBD-04" --title "Title" --owner "owner@org" --duration-days 90 --json
python tools/compliance/sbd_assessor.py --project-id "sparkpilot" --renew-exception --requirement-id "SBD-04" --json
python tools/compliance/sbd_report_generator.py --project-id "sparkpilot" --json
python tools/compliance/crosswalk_engine.py --framework cisa_sbd --project-id "sparkpilot" --coverage
```

### Module Encryption Commands
```bash
# Encrypt a module directory (used by marketplace SaaS at publish time)
python tools/marketplace/module_crypto.py encrypt --module-dir tools/writing --seed "<hex>" --slug writeguard
python tools/marketplace/module_crypto.py encrypt --module-dir tools/writing --seed "<hex>" --slug writeguard --keep-originals

# Verify a .py.enc file can be decrypted
python tools/marketplace/module_crypto.py verify --file tools/writing/analysis_engine.py.enc --seed "<hex>" --slug writeguard
```

### Storage Layer Commands
```bash
python tools/db/storage.py --health --json        # Check backend connectivity
python tools/db/storage.py --info --json           # Show backend configuration
# Connection API (in Python):
# from tools.db.storage import get_connection
# with get_connection() as conn:
#     rows = conn.execute("SELECT * FROM projects WHERE id = ?", (pid,)).fetchall()
```

### Security Commands
```bash
python tools/security/sast_runner.py --project-dir "/path"
python tools/security/dependency_auditor.py --project-dir "/path"
python tools/security/secret_detector.py --project-dir "/path"
python tools/security/container_scanner.py --image "sparkpilot:latest"
```

### AI Security Commands
```bash
python tools/security/prompt_injection_detector.py --text "input" --json
python tools/security/prompt_injection_detector.py --project-dir /path --gate --json
python tools/security/ai_telemetry_logger.py --summary --json
python tools/security/ai_telemetry_logger.py --anomalies --window-hours 24 --json
python tools/security/ai_bom_generator.py --project-id "sparkpilot" --project-dir . --json
python tools/compliance/atlas_assessor.py --project-id "sparkpilot" --json
python tools/compliance/owasp_llm_assessor.py --project-id "sparkpilot" --json
python tools/compliance/owasp_agentic_assessor.py --project-id "sparkpilot" --json
python tools/security/agent_trust_scorer.py --all --json
```

### Requirements Intake (RICOAS) Commands
```bash
python tools/requirements/intake_engine.py --project-id "sparkpilot" --customer-name "Name" --customer-org "Org" --impact-level IL4 --json
python tools/requirements/gap_detector.py --session-id "<id>" --check-security --check-compliance --json
python tools/requirements/readiness_scorer.py --session-id "<id>" --json
python tools/requirements/decomposition_engine.py --session-id "<id>" --level story --generate-bdd --json
python tools/requirements/boundary_analyzer.py --project-id "sparkpilot" --list-assessments --json
python tools/supply_chain/dependency_graph.py --project-id "sparkpilot" --build-graph --json
python tools/supply_chain/scrm_assessor.py --project-id "sparkpilot" --aggregate --json
python tools/supply_chain/cve_triager.py --project-id "sparkpilot" --sla-check --json
python tools/simulation/simulation_engine.py --project-id "sparkpilot" --create-scenario --scenario-name "Scenario" --scenario-type what_if --json
python tools/simulation/monte_carlo.py --scenario-id "<id>" --dimension schedule --iterations 10000 --json
python tools/simulation/coa_generator.py --session-id "<id>" --generate-3-coas --simulate --json
```

### DevSecOps & ZTA Commands
```bash
python tools/devsecops/profile_manager.py --project-id "sparkpilot" --assess --json
python tools/devsecops/pipeline_security_generator.py --project-id "sparkpilot" --json
python tools/devsecops/policy_generator.py --project-id "sparkpilot" --engine kyverno --json
python tools/devsecops/zta_maturity_scorer.py --project-id "sparkpilot" --all --json
python tools/compliance/nist_800_207_assessor.py --project-id "sparkpilot" --json
python tools/devsecops/service_mesh_generator.py --project-id "sparkpilot" --mesh istio --json
```

### Observability & XAI Commands
```bash
python tools/observability/shap/agent_shap.py --project-id "sparkpilot" --last-n 10 --json
python tools/observability/provenance/prov_query.py --entity-id "<id>" --direction backward --json
python tools/observability/provenance/prov_export.py --project-id "sparkpilot" --json
python tools/compliance/xai_assessor.py --project-id "sparkpilot" --json
```

### Code Intelligence Commands
```bash
python tools/analysis/code_analyzer.py --project-dir tools/ --json
python tools/analysis/code_analyzer.py --project-dir tools/ --store --json
python tools/analysis/code_analyzer.py --project-dir tools/ --trend --json
python tools/analysis/runtime_feedback.py --health --function analyze_code --json
```

### Knowledge Graph & GraphRAG Commands
```bash
# Knowledge graph analysis
python tools/knowledge_graph/text_network.py --text "input text" --project-id "sparkpilot" --json
python tools/knowledge_graph/ingester.py --file /path/to/doc --project-id "sparkpilot" --json

# GraphRAG retrieval (D-KARL-1 scoring profiles, D-KARL-2 compression)
python tools/knowledge_graph/graph_rag.py --query "zero trust" --project-id sparkpilot --json
python tools/knowledge_graph/graph_rag.py --query "AC-2 compliance" --profile compliance --json
python tools/knowledge_graph/graph_rag.py --query "explore gaps" --profile exploratory --no-compress --json

# AI insight generation (scanner-tier, zero Claude tokens)
python tools/knowledge_graph/insight_generator.py --graph-id <id> --questions --json
python tools/knowledge_graph/insight_generator.py --graph-id <id> --bridge-gaps --json

# Parallel multi-strategy retrieval (D-KARL-3)
python tools/rag/corrective_rag.py --parallel --query "NIST compliance gaps" --json
python tools/rag/corrective_rag.py --parallel --query "zero trust" --profile compliance --json

# KARL pass-rate filtered pair generation (D-KARL-4)
python tools/finetune/pair_generator.py --generate-filtered --dataset-id "ds-xxx" --source-table "research_signals" --json
python tools/finetune/pair_generator.py --generate-filtered --dataset-id "ds-xxx" --source-table "research_signals" --num-attempts 5 --min-pass-rate 0.2 --max-pass-rate 0.8 --json
```

### MBSE Commands
```bash
python tools/mbse/xmi_parser.py --project-id "sparkpilot" --file /path/model.xmi --json
python tools/mbse/reqif_parser.py --project-id "sparkpilot" --file /path/reqs.reqif --json
python tools/mbse/digital_thread.py --project-id "sparkpilot" auto-link --json
python tools/mbse/digital_thread.py --project-id "sparkpilot" coverage --json
python tools/mbse/model_code_generator.py --project-id "sparkpilot" --language python --output ./src
python tools/mbse/sync_engine.py --project-id "sparkpilot" detect-drift --json
python tools/mbse/des_assessor.py --project-id "sparkpilot" --project-dir /path --json
```

### DocHub Commands
```bash
# Document generation
python tools/dochub/doc_generator.py --project-id "sparkpilot" --doc-type ssp --profile 3pao --impact-level IL4 --json
python tools/dochub/doc_generator.py --project-id "sparkpilot" --generate-all --profile compliance --json
python tools/dochub/doc_generator.py --regenerate --doc-id "dh-doc-xxx" --json

# Data collection
python tools/dochub/data_collector.py --project-id "sparkpilot" --collect --json
python tools/dochub/data_collector.py --project-id "sparkpilot" --doc-type ssp --json

# Profiles
python tools/dochub/profile_engine.py --list --json
python tools/dochub/profile_engine.py --profile 3pao --json

# Export (8 formats: markdown, html, pdf_ready, oscal_json, xacta_csv, fedramp_zip, dod_pkg, emass)
python tools/dochub/export_engine.py --doc-id "dh-doc-xxx" --format html --json
python tools/dochub/export_engine.py --project-id "sparkpilot" --format fedramp_zip --output ./exports --json
python tools/dochub/export_engine.py --project-id "sparkpilot" --format dod_pkg --impact-level IL4 --output ./exports --json

# Health scoring
python tools/dochub/health_scorer.py --project-id "sparkpilot" --compute --json
python tools/dochub/health_scorer.py --project-id "sparkpilot" --trend --json
python tools/dochub/health_scorer.py --project-id "sparkpilot" --module-scores --json
python tools/dochub/health_scorer.py --portfolio --json

# Diff/changelog
python tools/dochub/diff_engine.py --doc-id "dh-doc-xxx" --latest --json
python tools/dochub/diff_engine.py --project-id "sparkpilot" --summary --json

# BYOS scanning
python tools/dochub/byos_scanner.py --project-dir /path/to/app --scan --json
python tools/dochub/byos_scanner.py --project-dir /path --scan --store --generate --json
python tools/dochub/byos_scanner.py --import-artifact --file /path/to/sbom.json --artifact-type sbom --project-id X --json

# Research enrichment
python tools/dochub/enrichment_engine.py --project-id "sparkpilot" --enrich --json
python tools/dochub/enrichment_engine.py --project-id "sparkpilot" --check-cves --json
python tools/dochub/enrichment_engine.py --cache-status --json

# Multi-tenant / module management
python tools/dochub/tenant_manager.py --register --project-id "sparkpilot" --name "SparkPilot" --app-type icdev --json
python tools/dochub/tenant_manager.py --list --json
python tools/dochub/tenant_manager.py --register-module --project-id "sparkpilot" --module-name "WriteGuard" --module-slug writeguard --json
python tools/dochub/tenant_manager.py --list-modules --project-id "sparkpilot" --json
python tools/dochub/tenant_manager.py --impact-analysis --target-id "requests" --target-type dependency --json
```

### Embedded Development Commands
```bash
# Natural Language to Firmware
python tools/embedded/nl_to_firmware.py --command "Blink LED every 2 seconds" --board simulator --json
python tools/embedded/nl_to_firmware.py --command "Read temperature sensor" --board esp32-s3 --json
python tools/embedded/nl_to_firmware.py --command "Send MQTT message" --board stm32f407 --deploy --json

# CMake and FreeRTOSConfig.h Generation
python tools/embedded/cmake_generator.py --board esp32-s3 --json
python tools/embedded/cmake_generator.py --board simulator --with-tinyml --json
python tools/embedded/cmake_generator.py --board stm32f407 --project-dir ./my-project --json

# Crash Analysis / Self-Healing
python tools/embedded/crash_analyzer.py --crash-type hardfault --device-id dev-001 --json
python tools/embedded/crash_analyzer.py --patterns --json
```

### Fleet Management Commands
```bash
# Device Registry
python tools/fleet/device_registry.py --register --name "my-esp32" --board esp32-s3 --json
python tools/fleet/device_registry.py --list --json
python tools/fleet/device_registry.py --heartbeat --device-id dev-001 --json
python tools/fleet/device_registry.py --health --json

# OTA Updates
python tools/fleet/ota_manager.py --deploy --firmware-id fw-001 --device-id dev-001 --json
python tools/fleet/ota_manager.py --canary --firmware-id fw-001 --group-id grp-001 --canary-pct 10 --json
python tools/fleet/ota_manager.py --status --json
```

### Edge AI / TinyML Commands
```bash
python tools/edge_ai/model_manager.py --templates --json                           # List model templates
python tools/edge_ai/model_manager.py --register --name "anomaly" --task anomaly_detection --json
python tools/edge_ai/model_manager.py --list --json
python tools/edge_ai/model_manager.py --deploy --model-id mdl-001 --device-id dev-001 --json
python tools/edge_ai/model_manager.py --inference-stats --device-id dev-001 --json
```

### Gamified Missions Commands
```bash
python tools/missions/mission_engine.py --seed --json            # Seed 7 default missions
python tools/missions/mission_engine.py --list --json            # List all missions
python tools/missions/mission_engine.py --start --mission 1 --user-id player1 --json
python tools/missions/mission_engine.py --complete --mission 1 --user-id player1 --json
python tools/missions/mission_engine.py --progress --user-id player1 --json
```

### Simulator Commands
```bash
python tools/simulator/sim_runner.py --seed --json               # Seed virtual peripherals
python tools/simulator/sim_runner.py --peripherals --json        # List available peripherals
python tools/simulator/sim_runner.py --create --user-id player1 --json  # Create session
python tools/simulator/sim_runner.py --list --json               # List sessions
python tools/simulator/sim_runner.py --status --session-id sim-001 --json
python tools/simulator/sim_runner.py --stop --session-id sim-001 --json
```

### Connector Forge Commands
```bash
# Generate connector from OpenAPI spec (template-only, no LLM)
python -c "from tools.databridge.forge.forge_agent import forge_from_spec; import json; print(json.dumps(forge_from_spec(content='{...}', connector_name='my_api', use_llm=False, run_sandbox_flag=False), indent=2))"

# List forge connectors
python -c "from tools.databridge.forge.forge_agent import list_forge_connectors; import json; print(json.dumps(list_forge_connectors(), indent=2))"

# Promote sandboxed connector
python -c "from tools.databridge.forge.promoter import promote_connector; import json; print(json.dumps(promote_connector('forge-xxx', 'admin'), indent=2))"

# MCP server
echo '{"jsonrpc":"2.0","id":1,"method":"forge_list","params":{}}' | python tools/mcp/connector_forge_server.py
```

### CI/CD Commands
```bash
python tools/ci/triggers/webhook_server.py           # Start webhook server
python tools/ci/triggers/poll_trigger.py             # Start issue polling
python tools/ci/workflows/icdev_sdlc.py 123          # Run full SDLC pipeline
```

### Forge Studio Blueprint Commands
```bash
# Tier classification (deterministic 12-signal heuristic)
python tools/forge_studio/generator/complexity_detector.py --classify-tier --description "Build me a CRM" --json

# Create blueprint (classify + store)
python tools/forge_studio/blueprint/export_engine.py --description "Build me a CRM" --json
python tools/forge_studio/blueprint/export_engine.py --app-id "app-xxx" --force-tier local --json

# Full automated pipeline: classify → route → build/submit
python tools/forge_studio/blueprint/build_tracker.py --build --description "Build me a CRM" --json
python tools/forge_studio/blueprint/build_tracker.py --build --app-id "app-xxx" --json

# Build status (auto-polls parent for Tier 2)
python tools/forge_studio/blueprint/build_tracker.py --status --blueprint-id "bp-xxx" --json

# Retry queued parent submissions
python tools/forge_studio/blueprint/build_tracker.py --retry-queued --json

# Parent ICDEV handoff
python tools/forge_studio/blueprint/parent_client.py --submit --blueprint-id "bp-xxx" --json
python tools/forge_studio/blueprint/parent_client.py --poll --blueprint-id "bp-xxx" --json
python tools/forge_studio/blueprint/parent_client.py --health --json
```

### Harness Engineering Commands
```bash
# Maturity assessment (6 dimensions, Level 0-4)
python tools/harness/maturity_assessor.py --project-dir . --detailed --json

# Exit criteria — list workflows or evaluate a specific one
python tools/harness/exit_criteria_evaluator.py --list --json
python tools/harness/exit_criteria_evaluator.py --workflow build --json
python tools/harness/exit_criteria_evaluator.py --workflow build --check-state .tmp/test_runs/state.json --json

# Trace analysis — analyze recent sessions for patterns
python tools/harness/trace_analyzer.py --last-n 5 --json
python tools/harness/trace_analyzer.py --session-id <id> --json
python tools/harness/trace_analyzer.py --recommendations --limit 20 --json

# Scaffold baseline harness for child apps
python tools/harness/scaffold_harness.py --output-dir /path/to/project --json
python tools/harness/scaffold_harness.py --output-dir /path --impact-level IL4 --json
```

### Innovation Feature Commands
```bash
# VSM Dashboard (F3) — DORA metrics, pipeline flow, bottleneck detection
python tools/analytics/vsm_engine.py --project-id "sparkpilot" --dora --json
python tools/analytics/vsm_engine.py --project-id "sparkpilot" --bottlenecks --json
python tools/analytics/vsm_engine.py --project-id "sparkpilot" --pipelines --json

# Developer Scorecard (F8) — 5-dimension health scoring
python tools/analytics/scorecard.py --project-id "sparkpilot" --compute --json
python tools/analytics/scorecard.py --project-id "sparkpilot" --trend --json
python tools/analytics/scorecard.py --project-id "sparkpilot" --latest --json

# cATO Live Evidence (F1) — continuous OSCAL streaming
python tools/compliance/cato_live_engine.py --project-id "sparkpilot" --stream --json
python tools/compliance/cato_live_engine.py --project-id "sparkpilot" --dashboard --json
python tools/compliance/cato_live_engine.py --project-id "sparkpilot" --timeline --json

# AI Narratives (F4) — compliance narrative workflow
python tools/compliance/narrative_workflow.py --project-id "sparkpilot" --batch --json
python tools/compliance/narrative_workflow.py --project-id "sparkpilot" --pending --json

# Template Exchange (F2) — community compliance templates
python tools/compliance/template_exchange.py --list --json
python tools/compliance/template_exchange.py --create --name "AC-2 SSP" --template-type ssp --framework "NIST 800-53" --content "..." --json

# Firmware SBOM + VEX (F12)
python tools/compliance/firmware_sbom.py --project-id "sparkpilot" --generate --project-dir . --board simulator --json

# Thread Heatmap (F5) — digital thread coverage gaps
python tools/mbse/thread_heatmap.py --project-id "sparkpilot" --generate --json
python tools/mbse/thread_heatmap.py --project-id "sparkpilot" --orphans --json

# PR Intelligence (F6) — compliance/security pre-check
python tools/ci/pr_intelligence.py --project-id "sparkpilot" --analyze --pr-reference HEAD --project-dir . --json

# Threat Modeler (F7) — STRIDE analysis with NIST mapping
python tools/security/threat_modeler.py --project-id "sparkpilot" --list --json
python tools/security/threat_modeler.py --project-id "sparkpilot" --create --name "Model" --components '[{"id":"web","type":"web_application"}]' --json

# Golden Path Scaffolder (F9)
python tools/scaffold/golden_path.py --list --json
python tools/scaffold/golden_path.py --scaffold --template flask_api --project-name "my-project" --json

# Forge Hub (F10) — connector community marketplace
python tools/databridge/forge/community_hub.py --browse --json
python tools/databridge/forge/community_hub.py --featured --json

# ATO Simulator (F11) — Monte Carlo timeline prediction
python tools/simulation/ato_simulator.py --project-id "sparkpilot" --simulate --iterations 1000 --json

# All tools use icdev.db (NOT sparkpilot.db)
```


---

## Architecture: GOTCHA Framework

This is a 6-layer agentic system.  The AI (you) is the orchestration layer -- you read goals, call tools, apply args, reference context, and use hard prompts.  You never execute work directly; you delegate to deterministic Python scripts.

**Why:** LLMs are probabilistic.  Business logic must be deterministic.  90% accuracy/step = ~59% over 5 steps.  Separation of concerns fixes this.

### The 6 Layers

| Layer | Directory | Role |
|-------|-----------|------|
| **Goals** | `goals/` | Process definitions -- what to achieve, which tools to use, expected outputs, edge cases |
| **Orchestration** | *(you)* | Read goal -> decide tool order -> apply args -> reference context -> handle errors |
| **Tools** | `tools/` | Python scripts, one job each.  Deterministic.  Don't think, just execute. |
| **Args** | `args/` | YAML/JSON behavior settings (themes, modes, schedules).  Change behavior without editing goals/tools |
| **Context** | `context/` | Static reference material (tone rules, writing samples, ICP descriptions, case studies) |
| **Hard Prompts** | `hardprompts/` | Reusable LLM instruction templates (outline->post, rewrite-in-voice, summarize) |

### Key Files

- `goals/manifest.md` -- Index of all goal workflows.  Check before starting any task.
- `tools/manifest.md` -- Master list of all tools.  Check before writing a new script.
- `memory/MEMORY.md` -- Curated long-term facts/preferences, read at session start.
- `memory/logs/YYYY-MM-DD.md` -- Daily session logs.
- `.env` -- API keys and environment variables.
- `.tmp/` -- Disposable scratch work.  Never store important data here.

### Memory System Architecture

Dual storage: markdown files (human-readable) + SQLite databases (searchable).

**Databases:**
- `data/memory.db` -- `memory_entries` (with embeddings), `daily_logs`, `memory_access_log`
- `data/activity.db` -- `tasks` table for tracking

**Memory types:** fact, preference, event, insight, task, relationship

**Search ranking:** Hybrid search uses 0.7 * BM25 (keyword) + 0.3 * semantic (vector).  Configurable via `--bm25-weight` and `--semantic-weight` flags.

**Embeddings:** OpenAI text-embedding-3-small (1536 dims), stored as BLOBs in SQLite.

---

## How to Operate

1. **Check goals first** -- Read `goals/manifest.md` before starting a task.  If a goal exists, follow it.
2. **Check tools first** -- Read `tools/manifest.md` before writing new code.  If you create a new tool, add it to the manifest.
3. **When tools fail** -- Read the error, fix the tool, update the goal with what you learned (rate limits, batching, timing).
4. **Goals are living docs** -- Update when better approaches emerge.  Never modify/create goals without explicit permission.
5. **When stuck** -- Explain what is missing and what you need.  Do not guess or invent capabilities.

### Session Start Protocol

1. Read `memory/MEMORY.md` for long-term context
2. Read today's daily log (`memory/logs/YYYY-MM-DD.md`)
3. Read yesterday's log for continuity
4. Or run: `python tools/memory/memory_read.py --format markdown`

---

## sparkpilot System

### Classification

**Impact Level:** IL4
**Classification:** CUI // SP-CTI
All generated artifacts MUST include classification markings appropriate to impact level.

### Multi-Agent Architecture (12 Agents)

| Tier | Agent | Port | Role |
|------|-------|------|------|
| Core | Orchestrator | 9443 | Task routing, workflow management |
| Core | Architect | 9444 | ATLAS A/T phases, system design |
| Domain | Builder | 9445 | TDD code gen (RED->GREEN->REFACTOR) |
| Support | Knowledge | 9449 | Self-healing patterns, recommendations |
| Support | Monitor | 9450 | Log analysis, metrics, alerts, health checks |
| Domain | Compliance | 9446 | ATO artifacts, 9-framework compliance |
| Domain | Security | 9447 | SAST, dep audit, secret detection |
| Domain | Requirements_analyst | 9453 | Conversational intake, gap detection, SAFe decomposition |
| Domain | Supply_chain | 9454 | Dependency graph, SBOM aggregation, ISA lifecycle, CVE triage |
| Domain | Simulation | 9455 | Digital Program Twin, Monte Carlo, COA generation |
| Domain | Devsecops_zta | 9457 | DevSecOps pipeline security, Zero Trust, policy-as-code |
| Domain | Connector_forge | 9458 | Dynamic connector generation, validation, sandbox, marketplace |

Agents communicate via **A2A protocol** (JSON-RPC 2.0 over mutual TLS within K8s).  Each publishes an Agent Card at `/.well-known/agent.json`.

### MCP Servers (12 stdio servers for Claude Code)

| Server | Tools |
|--------|-------|
| architect | design_system, decompose, interface_contract |
| builder | scaffold, generate_code, write_tests, run_tests, lint, format |
| compliance | ssp_generate, poam_generate, stig_check, sbom_generate, cui_mark, control_map, nist_lookup |
| connector-forge | forge_from_spec, forge_from_yaml, forge_status, forge_validate, forge_promote, forge_publish, forge_import, forge_list |
| devsecops | devsecops_profile_create, zta_maturity_score, pipeline_security_generate, policy_generate, service_mesh_generate |
| knowledge | search_knowledge, add_pattern, get_recommendations, self_heal |
| monitor | log_analyze, health_check, metrics_query, alert_manage |
| core | project_create, project_list, project_status, task_dispatch, agent_status |
| requirements | create_intake_session, process_intake_turn, detect_gaps, score_readiness, decompose_requirements |
| security | sast_scan, dep_audit, secret_detect, container_scan |
| simulation | create_scenario, run_simulation, run_monte_carlo, generate_coas, compare_coas |
| supply-chain | add_vendor, build_dependency_graph, assess_scrm, triage_cve, manage_isa |
| ops | runbook_list, runbook_get, runbook_create, runbook_execute, runbook_execution_status, runbook_generate, metastore_list_apps, metastore_get_app, metastore_register, metastore_dependencies, metastore_discover, metastore_rto_check, ops_query_zones, ops_query_budgets, ops_query_siem, ops_query_migrations, ops_query_deployments, ops_query_topologies |

### Compliance Frameworks Supported

| Framework | Description |
|-----------|-------------|
| NIST 800-53 Rev 5 | Federal information systems baseline |
| FedRAMP Moderate/High | Cloud services authorization |
| NIST 800-171 | CUI protection requirements |
| CMMC Level 2/3 | Cybersecurity maturity certification |
| DoD CSSP (DI 8530.01) | Cybersecurity service provider |
| CISA Secure by Design | Secure development principles |
| IEEE 1012 IV&V | Independent verification and validation |
| DoDI 5000.87 DES | Digital engineering strategy |

**Control Crosswalk:** Implementing one NIST 800-53 control auto-populates FedRAMP, CMMC, and 800-171 status via the crosswalk engine.

### MBSE Integration

Model-Based Systems Engineering: SysML XMI import, DOORS NG ReqIF import, digital thread traceability, model-to-code generation, drift detection, and DES compliance assessment.

- Import models: `xmi_parser.py`, `reqif_parser.py`
- Digital thread: `digital_thread.py` (auto-link, coverage, report)
- Code generation: `model_code_generator.py`
- Drift detection: `sync_engine.py`
- DES compliance: `des_assessor.py`, `des_report_generator.py`

### RICOAS — Requirements Intake, COA & Approval System

AI-driven conversational requirements intake with gap detection, SAFe decomposition, boundary impact assessment, supply chain intelligence, and Digital Program Twin simulation.

- Requirements intake: `intake_engine.py` (5-stage pipeline)
- Gap detection: `gap_detector.py`, `readiness_scorer.py` (7-dimension scoring)
- Decomposition: `decomposition_engine.py` (SAFe hierarchy with BDD)
- Boundary analysis: `boundary_analyzer.py` (4-tier ATO impact: GREEN/YELLOW/ORANGE/RED)
- Supply chain: `dependency_graph.py`, `scrm_assessor.py`, `cve_triager.py`
- Simulation: `simulation_engine.py`, `monte_carlo.py`, `coa_generator.py`

### DevSecOps & Zero Trust Architecture

DevSecOps pipeline security with policy-as-code (Kyverno/OPA), service mesh generation, and NIST SP 800-207 Zero Trust maturity scoring across 7 pillars.

- Profile management: `profile_manager.py` (5 maturity levels)
- Pipeline security: `pipeline_security_generator.py`
- Policy-as-code: `policy_generator.py` (Kyverno/OPA)
- ZTA maturity: `zta_maturity_scorer.py` (7-pillar DoD ZTA Strategy)
- NIST 800-207: `nist_800_207_assessor.py`
- Service mesh: `service_mesh_generator.py` (Istio/Linkerd)

### AI Security

MITRE ATLAS threat defense, OWASP LLM Top 10, prompt injection detection, AI telemetry with privacy-preserving hashing, and agentic security (behavioral drift, tool chain validation, trust scoring).

- Prompt injection: `prompt_injection_detector.py` (5 detection categories)
- AI telemetry: `ai_telemetry_logger.py` (SHA-256 hashed prompts/responses)
- ATLAS: `atlas_assessor.py`, `atlas_red_team.py`
- OWASP: `owasp_llm_assessor.py`, `owasp_agentic_assessor.py`
- Trust scoring: `agent_trust_scorer.py`, `tool_chain_validator.py`

### Observability & Explainable AI

Distributed tracing (OTel+SQLite), W3C PROV provenance, AgentSHAP tool attribution, and XAI compliance assessment.

- Tracing: Dual-mode tracer (OTel production, SQLite air-gapped)
- Provenance: `prov_query.py`, `prov_export.py` (W3C PROV-AGENT)
- Attribution: `agent_shap.py` (Monte Carlo Shapley values)
- XAI assessment: `xai_assessor.py` (10 compliance checks)

---

## SparkPilot — AI Co-Pilot for Embedded Systems

SparkPilot makes embedded RTOS development accessible to anyone — from a beginner building their first blinking LED to a DoD engineer deploying AI-enabled firmware with full NIST compliance.

### Four-Tier Architecture

| Tier | Environment | Purpose |
|------|-------------|---------|
| **Tier 0** | Browser Simulator (WASM/JS) | FreeRTOS POSIX port in browser, virtual peripherals, no install needed |
| **Tier 1** | FreeRTOS MCU (Cortex-M, ESP32, RISC-V) | TinyML inference, MQTT telemetry, OTA updates, SparkPilot Device SDK (~8KB) |
| **Tier 2** | Edge Gateway (RPi, Jetson) | Local LLM (llama.cpp), multi-agent coordination, edge inference |
| **Tier 3** | Cloud/ICDEV (Bedrock, SageMaker) | Full LLM orchestration, compliance monitoring, self-healing |

### Key Capabilities

1. **Natural Language to Firmware** — "Blink LED every 2 seconds" → C code → cross-compile → deploy
2. **Browser Simulator** — FreeRTOS POSIX port in WASM with virtual LEDs, sensors, display
3. **Gamified Missions** — 7 progressive missions: Blink LED → Sensor → WiFi → MQTT → AI → Hardware → Fleet
4. **Edge AI Pipeline** — TFLite Micro integration, model OTA, inference scheduler as FreeRTOS task
5. **Self-Healing Firmware** — Crash dump analysis, auto-rollback via MCUboot, 72-hour stability window
6. **Fleet Management** — Device registry, canary deployments, health heartbeat, OTA pipeline
7. **Progressive Compliance** — Beginner Mode (clean, simple) vs Pro Mode (NIST, IEC 62443, DO-178C)
8. **Sim-to-Silicon Path** — Auto-adapt simulator code to real HAL drivers, board recommendations

### SparkPilot Device SDK

Thin C library (~8KB flash) with 3 FreeRTOS tasks:
- **MQTT Client Task** — bridge to cloud agents
- **Command Handler Task** — executes agent instructions (OTA_UPDATE, CONFIG_SET, REBOOT, DIAG_DUMP, MODEL_UPDATE, TASK_CONTROL)
- **Telemetry Reporter Task** — sends health/sensor data

Header: `sdk/include/sparkpilot_sdk.h`
Source: `sdk/src/sparkpilot_sdk.c`
Build: `sdk/CMakeLists.txt`

### SparkPilot-Specific Tools

| Tool | Path | Purpose |
|------|------|---------|
| NL-to-Firmware | `tools/embedded/nl_to_firmware.py` | Natural language command → FreeRTOS C code |
| CMake Generator | `tools/embedded/cmake_generator.py` | CMakeLists.txt + FreeRTOSConfig.h per board |
| Crash Analyzer | `tools/embedded/crash_analyzer.py` | Crash dump pattern matching, self-healing |
| Device Registry | `tools/fleet/device_registry.py` | Device registration, heartbeats, health |
| OTA Manager | `tools/fleet/ota_manager.py` | Firmware/model OTA with canary deployment |
| Model Manager | `tools/edge_ai/model_manager.py` | TinyML model lifecycle, inference tracking |
| Mission Engine | `tools/missions/mission_engine.py` | Gamified learning, XP, badges, progress |
| Simulator Runner | `tools/simulator/sim_runner.py` | POSIX/WASM simulator sessions, virtual peripherals |

### Supported Boards

| Board | Arch | Flash | RAM | Toolchain |
|-------|------|-------|-----|-----------|
| ESP32-S3 | Xtensa LX7 | 8MB | 512KB | xtensa-esp32s3-elf |
| STM32F407 | Cortex-M4F | 1MB | 192KB | arm-none-eabi |
| nRF52840 | Cortex-M4F | 1MB | 256KB | arm-none-eabi |
| RPi Pico | Cortex-M0+ | 2MB | 264KB | arm-none-eabi |
| Simulator | POSIX/Host | - | - | gcc |

### Embedded Compliance Frameworks (Pro Mode)

| Framework | Scope |
|-----------|-------|
| NIST 800-53 | Core federal baseline |
| IEC 62443 | Industrial cybersecurity |
| DO-178C | Avionics traceability |
| ISO 26262 | Automotive safety |
| IEC 62304 | Medical devices |
| MISRA C:2023 | Coding standard |
| FIPS 140-3 | Crypto modules |
| EU AI Act | Embedded AI |

### Database

`data/sparkpilot.db` — 348 tables covering:
- Core: projects, audit_trail, agents, agent_tasks, memory_entries
- Compliance: compliance_controls, compliance_evidence, sbom_entries
- Devices: devices, rtos_tasks, device_telemetry, device_commands
- Firmware: firmware_builds, firmware_deploy_log, ota_update_log
- Fleet: device_groups, fleet_canary_log, mqtt_messages
- Edge AI: ml_models, inference_telemetry
- Missions: missions, mission_completion_log, user_progress
- CloudForge: cf_landing_zones, cf_provision_log, cf_ato_phases, cf_migration_assessments, cf_migration_workloads, cf_hybrid_topology, cf_hybrid_connections, cf_cost_records, cf_budgets, cf_siem_events, cf_shift_sessions, cf_deployments, cf_container_scans
- Simulator: simulator_sessions, simulator_session_log, virtual_peripherals
- Build: cmake_configs, board_support_packages
- Other: nl_commands, crash_dump_log, embedded_patterns

### Code Intelligence

AST-based code quality metrics, smell detection, deterministic maintainability scoring, and runtime feedback from test results.

- Code analyzer: `code_analyzer.py` (cyclomatic/cognitive complexity, nesting, params)
- Smell detection: 5 smell types (long function, deep nesting, high complexity, too many params, god class)
- Runtime feedback: `runtime_feedback.py` (test-to-source mapping)

### ATLAS Workflow

Build process follows the ATLAS methodology:
1. **Model** -- Import/validate SysML and DOORS models (M-ATLAS pre-phase)
1. **Model** -- model
2. **Architect** -- System design, component decomposition, interface contracts
3. **Trace** -- Requirements traceability matrix, compliance mapping
4. **Link** -- Wire components together, dependency injection, A2A registration
5. **Assemble** -- Build, test (TDD RED->GREEN->REFACTOR), integrate
6. **Stress_test** -- Load testing, security scanning, compliance gate checks

### Orchestration

- Prompt chains: Declarative YAML multi-step LLM reasoning (plan_critique_refine, scout_analyze_recommend)
- Dispatcher mode: Orchestrator restricted to delegation tools only (GOTCHA separation of concerns)
- Session purpose: Declared intent per session for NIST AU-3 audit traceability
```bash
python tools/agent/prompt_chain_executor.py --list --json
python tools/agent/prompt_chain_executor.py --chain plan_critique_refine --input "text" --project-id "proj-123" --json
python tools/agent/dispatcher_mode.py --status --project-id "proj-123" --json
python tools/agent/session_purpose.py --declare "task description" --project-id "proj-123" --json
```

### Testing Framework

**Testing Architecture (7-step pipeline):**
1. **py_compile** -- Python syntax validation
2. **Ruff** -- Ultra-fast Python linter
3. **pytest** (tests/) -- Unit/integration tests with coverage
4. **behave/Gherkin** (features/) -- BDD scenario tests
5. **Bandit** -- SAST security scan
6. **Playwright MCP** (.claude/commands/e2e/*.md) -- Browser automation E2E tests
7. **Security + Compliance gates** -- CUI markings, STIG, secret detection

### Database

| Database | Purpose |
|----------|---------|
| `data/sparkpilot.db` | Main operational DB: projects, agents, audit trail, compliance, MBSE, RICOAS, AI security, observability, DevSecOps/ZTA, code intelligence, WriteGuard (wg_style_guides, wg_style_guide_locks, wg_analysis_results, wg_analysis_findings, wg_snippets, wg_batch_runs) |
| `data/memory.db` | Memory system: entries, daily logs, access log |
| `data/activity.db` | Task tracking |

**Audit trail is append-only/immutable** -- no UPDATE/DELETE operations.  Satisfies NIST 800-53 AU controls.

---

## Existing Goals

| Goal | File | Purpose |
|------|------|---------|
| ATLAS Workflow | `goals/build_app.md` | 5-step build: Architect -> Trace -> Link -> Assemble -> Stress-test |
| TDD Workflow | `goals/tdd_workflow.md` | RED->GREEN->REFACTOR cycle with Cucumber/Gherkin |
| Compliance Workflow | `goals/compliance_workflow.md` | Generate SSP, POAM, STIG, SBOM, CUI markings |
| Security Scan | `goals/security_scan.md` | SAST, dependency audit, secret detection, container scan |
| Deploy Workflow | `goals/deploy_workflow.md` | IaC generation, pipeline, staging, production deploy |
| Monitoring | `goals/monitoring.md` | Log analysis, metrics, alerts, health checks |
| Self-Healing | `goals/self_healing.md` | Pattern detection, root cause analysis, auto-remediation |
| Agent Management | `goals/agent_management.md` | A2A agent lifecycle, registration, health |
| Integration Testing | `goals/integration_testing.md` | Multi-layer testing: unit, BDD, E2E (Playwright), gates |
| Maintenance Audit | `goals/maintenance_audit.md` | Dependency scanning, vulnerability checking, SLA enforcement |
| Requirements Intake (RICOAS) | `goals/requirements_intake.md` | AI-driven conversational intake, gap detection, SAFe decomposition |
| Boundary & Supply Chain | `goals/boundary_supply_chain.md` | ATO boundary impact, supply chain dependency graph, CVE triage |
| Digital Program Twin Simulation | `goals/simulation_engine.md` | 6-dimension what-if simulation, Monte Carlo, COA generation |
| DevSecOps Workflow | `goals/devsecops_workflow.md` | DevSecOps profile, pipeline security, policy-as-code |
| Zero Trust Architecture | `goals/zero_trust_architecture.md` | ZTA 7-pillar maturity, NIST 800-207, service mesh |
| MOSA Workflow | `goals/mosa_workflow.md` | DoD MOSA modularity analysis, ICD/TSP generation |
| Observability & XAI | `goals/observability_traceability_xai.md` | Distributed tracing, provenance, AgentSHAP, XAI assessment |
| AI Transparency | `goals/ai_transparency.md` | Model/system cards, AI inventory, fairness, confabulation detection |
| AI Accountability | `goals/ai_accountability.md` | Oversight plans, CAIO, appeals, incident response, ethics reviews |
| OWASP Agentic Security | `goals/owasp_agentic_security.md` | Behavioral drift, tool chain validation, trust scoring, RBAC |
| Code Intelligence | `goals/code_intelligence.md` | AST metrics, smell detection, maintainability scoring |
| Multi-Agent Orchestration | `goals/multi_agent_orchestration.md` | Prompt chains, dispatcher mode, session purpose, ATLAS critique |
| WriteGuard | `goals/writeguard.md` | AI writing assistant: grammar, readability, tone, style guides, GovProposal bridge |
| Connector Forge | `goals/connector_forge.md` | Dynamic DataBridge connector generation, validation, sandbox, marketplace |
| cATO Live Evidence | `goals/cato_live_evidence.md` | Continuous OSCAL streaming, evidence freshness monitoring |
| Template Exchange | `goals/template_exchange.md` | Community compliance template sharing, rating, import |
| VSM Dashboard | `goals/vsm_dashboard.md` | DORA metrics, pipeline flow, bottleneck detection |
| AI Narratives | `goals/ai_narratives.md` | AI-generated compliance narrative approval workflow |
| Thread Heatmap | `goals/thread_heatmap.md` | Digital thread traceability coverage gap detection |
| PR Intelligence | `goals/pr_intelligence.md` | PR compliance and security pre-checks |
| Threat Modeler | `goals/threat_modeler.md` | STRIDE threat modeling with NIST mapping and auto-POAM |
| Developer Scorecard | `goals/developer_scorecard.md` | 5-dimension project health scoring with trends |
| Golden Path | `goals/golden_path.md` | Self-service project scaffolding with compliance bootstrap |
| Forge Hub | `goals/forge_hub.md` | Connector community browsing, rating, trust scoring |
| ATO Simulator | `goals/ato_simulator.md` | Monte Carlo ATO timeline prediction with PERT sampling |
| Firmware SBOM | `goals/firmware_sbom.md` | Firmware CycloneDX SBOM and VEX generation |
| Harness Engineering | `goals/harness_engineering.md` | AI agent maturity assessment, loop detection, exit criteria, trace analysis, scaffolding |
| Secure by Design | `goals/secure_by_design.md` | CISA SbD pledge assessment, Cloudyrion 8-pillar alignment, exception registry, child app SbD inheritance |
| Systematic Debugging | `goals/systematic_debugging.md` | 4-phase root cause methodology: investigate → pattern → hypothesis → fix |
| Brainstorming Gate | `goals/brainstorming_gate.md` | Mandatory design exploration with 2-3 approaches before implementation |
| Bite-Sized Plans | `goals/bite_sized_plans.md` | 2-5 min task granularity with exact paths, code, commands |
| Subagent Review | `goals/subagent_review.md` | Two-stage review per subagent task: spec compliance then code quality |
| Verification Iron Law | `goals/verification_iron_law.md` | No completion claims without fresh verification evidence |
| DocHub | `goals/dochub.md` | Living documentation engine — 8 audience profiles, 8 export formats, multi-tenant, BYOS, health scoring, enrichment |

---

## Guardrails

### Superpowers Discipline (adapted from obra/superpowers)

- **Verification Iron Law:** NO completion claims without fresh verification evidence. Run the command, read the output, THEN claim the result. "Should work" is not evidence. (`goals/verification_iron_law.md`)
- **Systematic Debugging:** NO fixes without root cause investigation first. 4-phase process: investigate → pattern → hypothesis → fix. 3+ failed fixes = question the architecture. (`goals/systematic_debugging.md`)
- **Brainstorming Gate:** For new features/phases, present 2-3 approaches with tradeoffs and get user approval before implementation. Save design doc to `docs/plans/`. Exception: user says "just do it." (`goals/brainstorming_gate.md`)
- **Bite-Sized Plans:** Break multi-step work into 2-5 minute tasks with exact file paths, exact code, exact test commands. Plans readable by someone with zero codebase context. (`goals/bite_sized_plans.md`)
- **Two-Stage Subagent Review:** After each subagent task: spec compliance review (matches requirements?), then code quality review (well-built?). Never skip either stage. (`goals/subagent_review.md`)

### Core Guardrails

- Always check `tools/manifest.md` before writing a new script
- Verify tool output format before chaining into another tool
- Do not assume APIs support batch operations -- check first
- When a workflow fails mid-execution, preserve intermediate outputs before retrying
- Read the full goal before starting a task -- do not skim
- Audit trail is append-only -- NEVER add UPDATE/DELETE operations to audit tables
- Never store secrets in code or config -- use secrets manager or K8s secrets
- All containers must run as non-root with read-only root filesystem
- All generated artifacts MUST include classification markings appropriate to impact level
- SBOM must be regenerated on every build
- When implementing a NIST 800-53 control, always call crosswalk engine to auto-populate FedRAMP/CMMC/800-171 status
- Security gates block on: CAT1 STIG findings, critical/high vulnerabilities, failed tests, missing markings
- AI Security gates block on: prompt injection defense inactive, AI telemetry disabled, AI BOM missing, ATLAS coverage < 80%
- ZTA gates block on: maturity < Advanced for IL4+, mTLS not enforced with service mesh, no default-deny NetworkPolicy
- RICOAS gates block on: readiness score < 0.7, unresolved critical gaps, RED requirements without alternative COAs
- Observability gates block on: tracing not active, provenance graph empty, XAI assessment not completed
- Code Quality gates block on: average cyclomatic complexity > 25
- **This application CANNOT generate child applications** -- it is a generated child app of ICDEV.  The agentic fitness assessor, app blueprint engine, and child app generator are intentionally excluded.

### Cloud Service Provider Integration

**Target:** AWS (us-gov-west-1)
**MCP Servers:**
- @aws/core-mcp-server
- @aws/aws-api-mcp-server
- @aws/cdk-mcp-server
- @aws/terraform-mcp-server
- @aws/cloudformation-mcp-server
- @aws/iam-mcp-server
- @aws/well-architected-security-mcp-server
- @aws/cloudwatch-mcp-server
- @aws/cloudtrail-mcp-server
- @aws/cost-explorer-mcp-server
- @aws/aws-documentation-mcp-server
- @aws/aws-knowledge-mcp-server

---

## Key Architecture Decisions

- **D1:** ~~SQLite for internal operational data (zero-config portability)~~ Superseded by D-DB-20
- **D-DB-20:** PostgreSQL is the primary backend; SQLite retained as lightweight fallback for portable/browser scenarios
- **D-DB-21:** Storage abstraction layer in ``tools/db/storage.py`` -- all tools use ``get_connection()`` (backend-agnostic)
- **D-DB-22:** ``args/storage_config.yaml`` controls backend selection; env vars override YAML (ICDEV_STORAGE_BACKEND, ICDEV_PG_*)
- **D-DB-23:** Placeholder translation (? -> %s) handled transparently by StorageConnection wrapper
- **D-DB-24:** Supabase for marketplace-saas (PostgreSQL + Auth + RLS + Realtime)
- **D-DB-25:** Alembic for PostgreSQL schema versioning (replaces table-recreation pattern)
- **D2:** Stdio for MCP (Claude Code); HTTPS+mTLS for A2A (K8s inter-agent)
- **D5:** CUI markings applied at generation time (inline, not post-processing)
- **D6:** Audit trail is append-only/immutable (no UPDATE/DELETE -- NIST AU compliance)
- **D4:** Statistical methods for pattern detection; Bedrock LLM for root cause analysis
- **D7:** Python stdlib xml.etree.ElementTree for XMI/ReqIF parsing (zero deps, air-gap safe)
- **D8:** Normalized DB tables for model elements (enables SQL joins across digital thread)
- **D9:** M-ATLAS adds Model pre-phase to ATLAS (backward compatible -- skips if no model)
- **D12:** N:M digital thread links (one block -> many code modules; one control -> many requirements)
- **D21:** Readiness scoring uses deterministic weighted average (reproducible, not probabilistic)
- **D22:** Monte Carlo uses Python stdlib random (zero deps, air-gap safe)
- **D27:** Supply chain graph stored as SQL adjacency list (no graph DB needed)
- **D117:** DevSecOps/ZTA Agent with hard veto on pipeline_configuration and zero_trust_policy
- **D120:** ZTA maturity model uses DoD 7-pillar scoring (Traditional -> Advanced -> Optimal)
- **D215:** Prompt injection detector uses 5 detection categories
- **D216:** AI telemetry hashes prompts/responses with SHA-256 (privacy-preserving audit)
- **D280:** Pluggable Tracer ABC: OTelTracer (production), SQLiteTracer (air-gapped), NullTracer (fallback)
- **D287:** PROV-AGENT provenance in 3 append-only SQLite tables (W3C PROV standard)
- **D331:** Code quality metrics are read-only, advisory-only -- never modifies source files
- **D-WG-1:** Independent `tools/writing/` directory for marketplace portability
- **D-WG-2:** Deterministic-first pipeline (regex before LLM) -- air-gap safe, reproducible
- **D-WG-3:** 5-layer style guide cascade with ISSO locks (Platform->Tenant->Program->Project->User)
- **D-WG-5:** Plagiarism via RAG similarity (0.85 threshold)
- **D-WG-6:** AI detection is deterministic (advisory-only) -- perplexity, burstiness, n-gram stats
- **D-WG-7:** Snippets follow knowledge_base.py CRUD + hybrid search pattern
- **D-WG-8:** GovProposal via read-only bridge -- never writes to proposal tables
- **D-WG-9:** Append-only analysis results (NIST AU compliant)
- **D-WG-12:** Two-tier routing per function -- grammar/readability deterministic, tone scanner, rewrite/coherence worker
- **D-MKT-S1:** Marketplace extracted to standalone SaaS (marketplace.icdev.ai) -- ICDEV uses thin client (4 files, ~400 LOC)
- **D-MKT-S2:** Two modes: oss (all unlocked, default), saas (token verification)
- **D-MKT-S3:** Token verification is 100% offline via RSA-SHA256 public key -- 30-day grace period for air-gap
- **D-MKT-S4:** Thin client: module_runtime.py (gating), license_client.py (sync/verify/renew/feedback), token_store.py (local JSON cache)
- **D-MKT-C1:** Community-first model: 90-day free activation, unlimited renewals, no SLA
- **D-MKT-C2:** Sponsor tiers (platinum/gold/silver/bronze) are recognition badges only -- no feature gating, donations handled externally
- **D-MKT-C3:** Renewal = feedback touchpoint: optional survey on each renewal for continuous improvement
- **D-MKT-E1:** At-rest encryption for marketplace modules using AES-256-GCM with HKDF-SHA256 key derivation
- **D-MKT-E2:** Encryption key derived from token `encryption_seed` field (hex string, stable across renewals) + module slug as HKDF salt
- **D-MKT-E3:** File format: `[4B "IENC"][2B version][12B nonce][NB ciphertext+GCM tag]` -- GCM provides both confidentiality and integrity (no separate HMAC)
- **D-MKT-E4:** Custom `sys.meta_path` import hook (`EncryptedModuleFinder`) transparently decrypts `.py.enc` files to memory on import -- never writes plaintext to disk
- **D-MKT-E5:** Anti-tamper: if `.py` exists where `.py.enc` is expected for a protected module, import is refused with `ImportError`
- **D-MKT-E6:** Per-module encryption keys (different slug = different HKDF salt = different key) -- per-child-app isolation via per-license `encryption_seed`
- **D-MKT-E7:** OSS mode skips encryption entirely (files in the clear); SaaS mode encrypts on install, decrypts on import
- **D-MKT-E8:** Key and code object caches are per-process lifetime -- each module decrypted only once per process, ~0.5ms per 100KB
- **D-MKT-D1:** Marketplace disabled by default (air-gapped/OSS). Enable with `ICDEV_MARKETPLACE_ENABLED=true` env var or `args/marketplace_config.yaml enabled: true`. When disabled: `is_module_enabled()` returns True (all features are core), marketplace commerce routes return 501, no token checks, no network calls, no encrypted import hooks.
- **D-CF-1:** Connector Forge `forge/` is a subpackage of `tools/databridge/` -- imports from existing ABCs
- **D-CF-2:** Two-tier LLM for code gen (qwen3 drafts connector skeleton, Claude reviews against ABC contract)
- **D-CF-3:** Inline Jinja2 template strings with string-replacement fallback (air-gap safe)
- **D-CF-4:** Docker sandbox primary (--network none, --memory 256m), subprocess fallback
- **D-CF-5:** Two new ConnectorType enum values: SOAP, HEALTH
- **D-CF-6:** Promotion state machine: sandboxed → promoted → published → deprecated
- **D-CF-7:** 8 new audit event types for forge lifecycle
- **D-CF-8:** Marketplace install via ASSET_TYPE_DIRS["databridge_connector"]
- **D-CF-9:** MCP server exposes 8 tools for forge operations
- **D-CF-10:** Config in databridge_config.yaml under forge: block
- **D-SC-1:** Scale Engine uses ThreadPoolExecutor wrapping existing sync connectors (no ABC changes)
- **D-SC-2:** Per-connector-type connection pools (key = connector_name)
- **D-SC-3:** WAL + batch flush for sync log and audit writes (single writer thread)
- **D-SC-4:** Fixed limits (configurable max_workers, max_concurrent_syncs via YAML)
- **D-SC-5:** Semaphore enforces max_concurrent_syncs (makes existing config value real)
- **D-SC-6:** stdlib only (concurrent.futures, threading, queue); psutil optional for backpressure
- **D-SC-7:** Append-only audit trail preserved (INSERT only in WriteBatcher, NIST AU)
- **D-CF-19:** Runbooks stored as JSON DAG (tasks_json + edges_json) in SQLite -- air-gap safe
- **D-CF-20:** Runbook executions are append-only with per-task log (NIST AU compliance)
- **D-CF-21:** DAG execution uses Kahn's algorithm (topological sort) -- deterministic O(V+E), no LLM in critical path
- **D-CF-22:** Snippets are self-contained sub-DAGs embedded by reference with usage count tracking
- **D-CF-23:** Metastore uses adjacency list for dependency graph (matches D27 pattern, SQL joins)
- **D-CF-24:** Auto-discovery pulls from db_connections, cf_landing_zones, devices -- idempotent upsert
- **D-CF-25:** Conditional branching uses deterministic expression eval (key-operator-value triples, no eval())
- **D-CF-26:** AI runbook generation is non-critical-path, always outputs status='draft'
- **D-CF-27:** RTO/RPO stored as hours (REAL) on cf_applications -- simple numeric comparison
- **D-CF-28:** Single unified Ops MCP server with 18 tools (reduces MCP server proliferation)
- **D-CF-29:** YAML runbook templates in args/cloudforge_runbook_templates/ (GOTCHA args layer)
- **D-CF-30:** Community: 3 runbooks, no snippets/AI/discovery; Pro: unlimited
- **D52:** This is a generated child app -- grandchild app generation is disabled by design
- **D-INV-1:** cATO OSCAL streaming uses incremental assessment-results (per-control, not bulk)
- **D-INV-2:** Evidence freshness thresholds: current <= 30d, stale <= 90d, expired > 90d
- **D-INV-5:** Template provenance via SHA-256 content hash (tamper detection)
- **D-INV-9:** DORA metrics computed from audit_trail stage timestamps (no external CI integration needed)
- **D-INV-10:** Bottleneck detection via p90 statistical analysis (no ML)
- **D-INV-13:** Two-tier LLM for narrative generation: qwen3 drafts, Claude reviews
- **D-INV-14:** Narrative approval workflow: draft -> pending_review -> approved/rejected
- **D-INV-17:** Heatmap matrix uses N x M artifact-type cross-reference (not individual artifacts)
- **D-INV-21:** PR diff analysis via subprocess git (no GitHub API dependency)
- **D-INV-25:** STRIDE threat analysis is deterministic rule-based per component type (no LLM)
- **D-INV-26:** STRIDE-to-NIST mapping: Spoofing->AC/IA, Tampering->SC/SI, Repudiation->AU, InfoDisc->SC, DoS->SC/CP, EoP->AC
- **D-INV-29:** Scorecard weighted composite (6 dimensions): code_quality=0.20, security=0.20, compliance=0.15, test_coverage=0.15, velocity=0.10, sbd_posture=0.20
- **D-INV-33:** Golden Path uses declarative YAML template definitions (5 built-in templates)
- **D-INV-37:** Forge Hub trust score: validation=0.30, rating=0.25, downloads=0.20, age=0.15, author=0.10
- **D-INV-41:** ATO simulator uses PERT sampling via stdlib random.betavariate (zero deps)
- **D-INV-45:** Firmware SBOM output format: CycloneDX 1.5 JSON
- **D-INV-46:** VEX output format: CSAF 2.0 with per-component exploitability status
- **D-INV-48:** All innovation features use icdev.db (NOT sparkpilot.db -- that's for IoT/embedded only)
- **D-HARNESS-1:** Loop state in `.tmp/sessions/` JSON (ephemeral, not DB)
- **D-HARNESS-2:** Loop detection is soft-signal only (stderr, exit 0) -- never blocks
- **D-HARNESS-3:** Progress file is JSON (models handle structured data better)
- **D-HARNESS-4:** Exit criteria in args/ YAML (GOTCHA separation)
- **D-HARNESS-5:** Trace analyzer scanner-tier only (zero Claude tokens)
- **D-HARNESS-6:** Maturity assessor read-only, advisory-only
- **D-HARNESS-7:** Scaffolder generates 3 hooks (minimal), not all 7
- **D-HARNESS-8:** One new append-only DB table: `harness_trace_recommendations`
- **D-SBD-1:** Cloudyrion 8-Pillar SbD Framework mapped to all 35 SBD requirements via `sbd_pillars` field
- **D-SBD-2:** Security exception registry in `sbd_exceptions` table (active/expired/renewed lifecycle, max 365 days)
- **D-SBD-3:** Exception aging gate: expired exceptions block deployment (Cloudyrion anti-pattern: lingering exceptions)
- **D-SBD-4:** CISA SbD added to crosswalk engine as `cisa_sbd` framework key (implement once, satisfy many)
- **D-SBD-5:** Golden Path child apps auto-inherit SECURITY.md, .well-known/security.txt, and args/sbd_gates.yaml
- **D-SBD-6:** Developer Scorecard expanded to 6 dimensions (sbd_posture=0.20 weight, penalizes expired exceptions)
- **D-SBD-7:** SbD goal workflow: 7-step assess-review-remediate-report cycle with Cloudyrion pillar alignment
- **D-KARL-1:** Per-query-type GraphRAG scoring profiles (compliance, exploratory, entity_search, synthesis) with auto-detection from query text
- **D-KARL-2:** Self-directed context compression via scanner-tier LLM (qwen3.5, zero Claude tokens) — compresses verbose GraphRAG neighborhood context before downstream consumption
- **D-KARL-3:** Parallel multi-strategy retrieval (GraphRAG + corrective RAG + source registry) via ThreadPoolExecutor with generative aggregation — scanner-tier LLM synthesizes unified context from N independent retrieval paths
- **D-KARL-4:** Pass-rate filtered training pair generation — Goldilocks difficulty calibration (pairs that are neither too easy nor too hard for the model)
- **D-FS-TIER-1:** Deterministic 12-signal tier classifier (regex, no LLM) — threshold >= 3 routes to parent ICDEV handoff
- **D-FS-TIER-2:** ForgeBlueprint manifest with 31-column DB table — portable JSON spec for app design, requirements, and handoff tracking
- **D-FS-TIER-3:** Parent ICDEV HTTP client uses stdlib urllib (air-gap safe) with queued retry when parent unreachable
- **D-FS-TIER-4:** Build tracker orchestrates full pipeline: classify → route → build (local eject) or submit (parent handoff) → track
- **D-DH-1:** Scanner-tier deterministic generation (zero Claude tokens). Templates + data aggregation only. Optional LLM enhancement via two-tier router.
- **D-DH-2:** Document versions use monotonic integer (1, 2, 3...) with SHA-256 content hash for integrity
- **D-DH-3:** Section-level diffing (not line-level) — aligns with structured document templates
- **D-DH-4:** Health score uses weighted composite: freshness=0.35, completeness=0.40, gaps=0.25 (same pattern as D-INV-29 scorecard)
- **D-DH-5:** BYOS scanner reuses existing detection patterns from sbom_generator.py and code_analyzer.py
- **D-DH-6:** Enrichment cache with configurable TTL — graceful degradation in air-gapped mode
- **D-DH-7:** Multi-tenant via tenant_id column — future-proofed for multi-org without schema change
- **D-DH-8:** Export delegates to existing tools (oscal_generator, xacta_export, emass_export) where possible
- **D-DH-9:** All dh_ tables are append-only (new version = new row, status change on old row) — NIST AU compliant
- **D-DH-10:** Profile definitions are JSON in context/ (GOTCHA context layer), not hardcoded in tools
- **D-DH-11:** Module-level docs with independent health scores, rolling up to parent app
- **D-DH-12:** Portfolio aggregate uses weighted average by app criticality
- **D-DH-13:** Imported artifacts stored as-is with format detection (SPDX, CycloneDX, PDF, OSCAL)
- **D-DH-14:** Provenance tracks origin_project, origin_version, current_version, drift_status
- **D-DH-15:** Dependency graph uses adjacency list (matches D27 pattern)

---

## Continuous Improvement

Every failure strengthens the system: identify what broke -> fix the tool -> test it -> update the goal -> next run succeeds automatically.

Be direct.  Be reliable.  Get it done.
