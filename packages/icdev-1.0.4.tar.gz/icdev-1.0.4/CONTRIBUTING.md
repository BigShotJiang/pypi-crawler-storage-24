# Contributing to ICDEV

Thank you for your interest in contributing to ICDEV (Intelligent Certified Development).

## Two Contribution Paths

### 1. Marketplace Modules (new tools, compliance packs, child apps)

If you're building a **new module** for the ICDEV marketplace, submit to the dedicated contributions repo:

- **Repo:** [icdev-ai/marketplace-contributions](https://github.com/icdev-ai/marketplace-contributions)
- **Guide:** [docs/marketplace/CONTRIBUTING.md](docs/marketplace/CONTRIBUTING.md)
- **Process:** PR -> 8 automated scans -> admin review -> 7-day quarantine -> published

### 2. Core Platform (this repo)

Bug fixes, improvements, and features to the ICDEV platform itself.

## Getting Started

1. **Fork** this repository
2. **Create a branch** from `main` (`git checkout -b fix/describe-the-change`)
3. **Make your changes** following the guidelines below
4. **Open a Pull Request** to `main`

## Architecture: GOTCHA Framework

ICDEV uses a strict 6-layer architecture. Understanding it is essential:

| Layer | Directory | Rule |
|-------|-----------|------|
| **Goals** | `goals/` | Process definitions — what to achieve |
| **Orchestration** | AI agent | Reads goals, calls tools, applies args |
| **Tools** | `tools/` | Deterministic Python scripts. One job each. |
| **Args** | `args/` | YAML/JSON config. Change behavior without code changes. |
| **Context** | `context/` | Static reference material |
| **Hard Prompts** | `hardprompts/` | Reusable LLM instruction templates |

**Key rules:**
- Tools must NOT import from `goals/` or `hardprompts/`
- Tools must be deterministic — no direct LLM calls
- Database access must use `tools.db.storage.get_connection()` (not direct sqlite3)
- Audit trail tables are append-only (no UPDATE/DELETE — NIST AU compliance)

## CI Gates (automated)

Every PR is automatically checked against **9 gates**:

| Gate | What It Checks | Severity |
|------|---------------|----------|
| `py_compile` | Python syntax | Blocking |
| `ruff_lint` | Code style and linting | Blocking |
| `bandit_sast` | Security vulnerabilities (zero medium+ on changed files) | Blocking |
| `secret_scan` | Hardcoded secrets (TruffleHog) | Blocking |
| `dependency_audit` | Known CVEs in dependencies | Warning |
| `test_pass` | pytest test suite | Blocking |
| `cui_marking` | CUI // SP-CTI marking on new files | Warning |
| `architecture` | GOTCHA 6-layer compliance | Blocking |
| `import_check` | Circular import detection | Blocking |

## Code Standards

### Every new Python file must:
```python
#!/usr/bin/env python3
"""CUI // SP-CTI
Brief description of what this module does.
"""
```

### No hardcoded secrets
```python
# BAD
API_KEY = "sk-abc123..."

# GOOD
API_KEY = os.environ.get("MY_API_KEY", "")
```

### No direct database access
```python
# BAD
import sqlite3
conn = sqlite3.connect("data/icdev.db")

# GOOD
from tools.db.storage import get_connection
with get_connection() as conn:
    rows = conn.execute("SELECT ...").fetchall()
```

### New tools must be registered
If you add a new tool in `tools/`, add it to `tools/manifest.md`.

## PR Review Process

1. **Automated CI** runs all 9 gates (~3 minutes)
2. **Auto-labeling** tags your PR based on changed files
3. **Maintainer review** — an ICDEV maintainer reviews your code
4. **Merge** — squash-merge to `main`

## What We Accept

- Bug fixes with reproduction steps
- Performance improvements with benchmarks
- New tools that follow GOTCHA architecture
- Documentation improvements
- Test coverage additions
- Security hardening

## What We Don't Accept

- Breaking changes to GOTCHA layer boundaries
- Direct LLM calls in tools (tools must be deterministic)
- UPDATE/DELETE operations on audit trail tables
- Code without CUI markings (for classified modules)
- Dependencies with known critical CVEs

## Questions?

Open an issue at [icdev-ai/ICDev/issues](https://github.com/icdev-ai/ICDev/issues).
