# Contributing to the ICDEV Marketplace

Thank you for your interest in contributing to the ICDEV Marketplace! This guide explains the process for submitting new modules, tools, compliance packs, child apps, and other artifacts.

## Overview

Contributions are submitted via GitHub Pull Requests to the [icdev-ai/marketplace-contributions](https://github.com/icdev-ai/marketplace-contributions) repository. Every submission goes through an **automated 8-check vetting pipeline** followed by **manual admin review** before being published.

### Contribution Lifecycle

```
PR Opened → Automated Scanning (8 checks) → Admin Review → Approve/Reject
                                                              ↓
                                                    RSA Sign + S3 Upload
                                                              ↓
                                                    7-Day Quarantine
                                                              ↓
                                                        Published
```

## What You Can Contribute

| Type | Description | Example |
|------|-------------|---------|
| `tool` | Python-based tool module | Writing assistant, data connector |
| `compliance` | Compliance pack or template | NIST control mappings, SSP templates |
| `template` | Project scaffolding template | Flask API, React SPA |
| `child_app` | Full child application template | Microservice, ML service |
| `compliance_template` | Reusable compliance document templates | SSP sections, POAM templates |

## Submission Requirements

### 1. Repository Structure

Your PR must contain these files at minimum:

```
your-module/
├── module_manifest.yaml    # REQUIRED — module metadata
├── __init__.py             # REQUIRED — Python package
├── requirements.txt        # If you have dependencies
├── tests/                  # REQUIRED — at least one test
│   ├── __init__.py
│   └── test_*.py
└── ... your code ...
```

### 2. Module Manifest (`module_manifest.yaml`)

Every submission **must** include a `module_manifest.yaml` in the root:

```yaml
# Required fields
slug: my-awesome-tool           # URL-safe identifier (lowercase, hyphens)
display_name: My Awesome Tool   # Human-readable name
description: >
  Brief description of what your module does
  and why someone would want to install it.
asset_type: tool                # tool | compliance | template | child_app
install_slug: my_tool           # Directory name under tools/ or apps/
version: 1.0.0                  # SemVer
author: your-github-username    # GitHub username

# Optional fields
tags: [category1, category2]
license: MIT
min_icdev_version: "1.0.0"
dependencies: []                # Other marketplace slugs this depends on
```

### 3. Automated Checks (8 gates)

Your submission is automatically scanned for:

| # | Check | What It Does | How to Pass |
|---|-------|-------------|-------------|
| 1 | `py_compile` | Python syntax validation | All `.py` files must compile without errors |
| 2 | `ruff_lint` | Linting (ruff) | No lint errors (warnings OK) |
| 3 | `bandit_sast` | Security analysis (SAST) | Zero high/critical findings |
| 4 | `secret_scan` | Secret detection (TruffleHog) | No hardcoded secrets, API keys, or passwords |
| 5 | `dependency_audit` | CVE scanning (pip-audit) | No critical/high CVEs in dependencies |
| 6 | `test_pass` | Test suite (pytest) | All tests must pass; `tests/` dir required |
| 7 | `manifest_valid` | Manifest schema validation | All required fields present and valid |
| 8 | `architecture_check` | GOTCHA layer compliance | No hardcoded DB paths, no direct sqlite3, has `__init__.py` |

### 4. Code Guidelines

- **No hardcoded database paths** — use `tools.db.storage.get_connection()` if you need DB access
- **No secrets in code** — use environment variables or config
- **Include `__init__.py`** in your module root and test directories
- **Write tests** — minimum one test file in `tests/`
- **Follow GOTCHA architecture** — tools are deterministic, don't call LLMs directly

### 5. What NOT to Include

- `.env` files or any credentials
- Large binary files (>10MB)
- Node modules, `__pycache__`, or build artifacts
- Code that modifies ICDEV core files

## How to Submit

1. **Fork** the [marketplace-contributions](https://github.com/icdev-ai/marketplace-contributions) repo
2. **Create a branch** for your module (e.g., `add-my-awesome-tool`)
3. **Add your code** following the structure above
4. **Open a Pull Request** to `main`
5. **Wait for automated scans** — results posted as a PR comment within ~5 minutes
6. **Fix any failures** — push fixes, scans re-run automatically
7. **Admin review** — once all 8 checks pass, an ICDEV maintainer reviews your submission
8. **Quarantine** — approved submissions enter a 7-day quarantine period
9. **Published** — after quarantine, your module appears in the marketplace catalog

## After Acceptance

Once published, your module will be:
- Available in the ICDEV marketplace catalog
- Downloadable via `icdev marketplace install <your-slug>`
- RSA-signed with the ICDEV marketplace key for integrity verification
- Listed with SLSA provenance attestation

## Questions?

- Open an issue in [marketplace-contributions](https://github.com/icdev-ai/marketplace-contributions/issues)
- Check the [ICDEV documentation](https://icdev.ai/docs)
