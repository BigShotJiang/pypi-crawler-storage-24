# Dashboard Completion — Phased Implementation Plan

**Classification:** CUI // SP-CTI
**Created:** 2026-03-12
**Status:** Active

---

## Overview

15 incomplete dashboard pages remain after Phases 73-74 (Agent Evolution, Resilience). This plan organizes them into 8 phases, ordered by dependency chain and effort. Each phase targets 1-3 pages with related backing modules.

---

## Phase 75: Intelligence Dashboard
**Effort:** Medium | **Pages:** 1 | **Route:** `/intelligence`

Wire 5 tabs to real backing modules:

| Tab | API Endpoint | Backing Tool | Work |
|-----|-------------|-------------|------|
| Semantic Cache | `/api/intelligence/cache` | `tools/llm/semantic_cache.py` | Return cache stats, hit/miss ratio, recent lookups |
| Budget Routing | `/api/intelligence/budget` | `tools/llm/router.py` | Return tier usage, token counts, cost breakdown |
| Corrective RAG | `/api/intelligence/rag` | `tools/rag/corrective_rag.py` | Return retrieval stats, correction counts, source health |
| Prompt Registry | `/api/intelligence/prompts` | `hardprompts/` directory scan | Return registered prompts, usage frequency |
| Output Verifier | `/api/intelligence/verify` | `tools/llm/output_verifier.py` | Return verification stats, confabulation flags |

**Template work:** Auto-load on tab switch, stat cards, usage charts.

---

## Phase 76: Decisions Engine + Container Lens
**Effort:** Medium | **Pages:** 2 | **Routes:** `/decisions`, `/container-lens`

### Decisions Engine
| Tab | API Endpoint | Backing Tool | Work |
|-----|-------------|-------------|------|
| Decision Tables | `/api/decisions/tables` | `tools/decisions/dmn_engine.py` | Return table definitions, rule counts |
| Evaluate | `/api/decisions/evaluate` | `tools/decisions/dmn_engine.py` | Execute rules against sample input |
| Validate | `/api/decisions/validate/<table>` | `tools/decisions/dmn_engine.py` | Check table completeness, conflict detection |

### Container Lens
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| Validate | `/api/container-lens/validate` | `tools/security/container_scanner.py` | Return scan results, vulnerability counts |
| History | `/api/container-lens/history` | DB query | Return past scan results with trends |

**Template work:** Auto-load, result cards, vulnerability severity badges, rule evaluation form.

---

## Phase 77: Compliance Acceleration
**Effort:** Large | **Pages:** 1 | **Route:** `/compliance-accel`

Wire 5 tabs to compliance toolchain:

| Tab | API Endpoint | Backing Tool | Work |
|-----|-------------|-------------|------|
| KSI (Key Security Indicators) | `/api/compliance-accel/ksi` | `tools/compliance/fedramp_assessor.py`, `tools/compliance/cmmc_assessor.py` | Aggregate scores across frameworks |
| OSCAL Validation | `/api/compliance-accel/oscal` | `tools/compliance/oscal_generator.py` | Return OSCAL artifacts, validation status |
| Control Inheritance | `/api/compliance-accel/inheritance` | `tools/compliance/crosswalk_engine.py` | Return cross-framework control mapping |
| AI Narrative | `/api/compliance-accel/narrative` | `tools/compliance/narrative_workflow.py` | Return narrative drafts, approval status |
| AI RMF | `/api/compliance-accel/airmf` | `tools/compliance/atlas_assessor.py`, `tools/compliance/owasp_llm_assessor.py` | Return AI risk assessment |

**Template work:** Framework comparison charts, inheritance flow diagram, narrative approval workflow UI.

---

## Phase 78: Harness Engineering + Developer Scorecard
**Effort:** Medium | **Pages:** 2 | **Routes:** `/harness`, `/scorecard`

### Harness Engineering
| Tab | API Endpoint | Backing Tool | Work |
|-----|-------------|-------------|------|
| Maturity Assessment | `/api/harness/maturity` | `tools/harness/maturity_assessor.py` | Return 6-dimension maturity scores |
| Exit Criteria | `/api/harness/exit-criteria` | `tools/harness/exit_criteria_evaluator.py` | Return workflow exit criteria status |
| Trace Analysis | `/api/harness/traces` | `tools/harness/trace_analyzer.py` | Return session traces, recommendations |

### Developer Scorecard
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| Compute | `/api/scorecard/compute` | `tools/analytics/scorecard.py` | Return 6-dimension composite score |
| Trend | `/api/scorecard/trend` | `tools/analytics/scorecard.py` | Return historical score progression |
| Latest | `/api/scorecard/latest` | `tools/analytics/scorecard.py` | Return most recent snapshot |

**Template work:** Radar/spider charts for maturity, progress bars for exit criteria, sparkline trends for scorecard.

---

## Phase 79: Security Trio — Threat Modeler + PR Intelligence + ATO Simulator
**Effort:** Medium | **Pages:** 3 | **Routes:** `/threat-modeler`, `/pr-intelligence`, `/ato-simulator`

### Threat Modeler
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| Models | `/api/threat-modeler/list` | `tools/security/threat_modeler.py` | Return STRIDE models |
| Create | `/api/threat-modeler/create` | `tools/security/threat_modeler.py` | Create new threat model |
| Analyze | `/api/threat-modeler/analyze/<id>` | `tools/security/threat_modeler.py` | Return threats with NIST mapping |

### PR Intelligence
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| Analyze | `/api/pr-intelligence/analyze` | `tools/ci/pr_intelligence.py` | Return compliance/security pre-check |
| History | `/api/pr-intelligence/history` | DB query | Return past PR analyses |

### ATO Simulator
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| Simulate | `/api/ato-simulator/simulate` | `tools/simulation/ato_simulator.py` | Monte Carlo timeline prediction |
| History | `/api/ato-simulator/history` | DB query | Past simulation runs |

**Template work:** STRIDE threat matrix, PR diff viewer with annotations, Monte Carlo distribution chart.

---

## Phase 80: Knowledge & Evidence — Knowledge Graph + cATO Live + Template Exchange
**Effort:** Large | **Pages:** 3 | **Routes:** `/knowledge-graph`, `/cato-live`, `/template-exchange`

### Knowledge Graph
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| Analyze | `/api/knowledge-graph/analyze` | `tools/knowledge_graph/text_network.py` | Build graph from text |
| List | `/api/knowledge-graph/list` | `tools/knowledge_graph/ingester.py` | Return stored graphs |
| Insights | `/api/knowledge-graph/insights` | `tools/knowledge_graph/insight_generator.py` | Return AI-generated insights |
| Chat | `/api/knowledge-graph/chat` | `tools/knowledge_graph/graph_rag.py` | GraphRAG Q&A |

### cATO Live Evidence
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| Dashboard | `/api/cato-live/dashboard` | `tools/compliance/cato_live_engine.py` | Evidence freshness, control status |
| Collect | `/api/cato-live/collect` | `tools/compliance/cato_live_engine.py` | Trigger evidence collection |
| Timeline | `/api/cato-live/timeline` | `tools/compliance/cato_live_engine.py` | Evidence collection timeline |

### Template Exchange
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| Browse | `GET /api/template-exchange/templates` | `tools/compliance/template_exchange.py` | List community templates |
| Publish | `POST /api/template-exchange/templates` | `tools/compliance/template_exchange.py` | Submit new template |

**Template work:** Canvas graph visualization, evidence freshness heatmap, template cards with ratings.

---

## Phase 81: VSM + Golden Path + Firmware SBOM + Forge Hub
**Effort:** Medium | **Pages:** 4 | **Routes:** `/vsm`, `/golden-path`, `/firmware-sbom`, `/forge-hub`

### VSM Dashboard
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| DORA Metrics | `/api/vsm/dora` | `tools/analytics/vsm_engine.py` | Lead time, deploy freq, MTTR, change fail rate |
| Bottlenecks | `/api/vsm/bottlenecks` | `tools/analytics/vsm_engine.py` | P90 stage duration analysis |
| Pipelines | `/api/vsm/pipelines` | `tools/analytics/vsm_engine.py` | Pipeline flow visualization |

### Golden Path
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| Templates | `/api/golden-path/list` | `tools/scaffold/golden_path.py` | List available scaffolds |
| Scaffold | `/api/golden-path/scaffold` | `tools/scaffold/golden_path.py` | Generate new project |

### Firmware SBOM
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| Generate | `/api/firmware-sbom/generate` | `tools/compliance/firmware_sbom.py` | CycloneDX + VEX output |
| History | `/api/firmware-sbom/history` | DB query | Past SBOM generations |

### Forge Hub
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| Browse | `/api/forge-hub/browse` | `tools/databridge/forge/community_hub.py` | Community connectors |
| Featured | `/api/forge-hub/featured` | `tools/databridge/forge/community_hub.py` | Top-rated connectors |

**Template work:** DORA metric gauges, pipeline flow diagram, template cards, SBOM tree view.

---

## Phase 82: Audit Engine + DocHub + Research
**Effort:** Large | **Pages:** 3 | **Routes:** `/audit-engine`, `/dochub`, `/research`

### Audit Engine
| Section | API Endpoint | Backing Tool | Work |
|---------|-------------|-------------|------|
| Run | `/api/audit-engine/run` | Compliance toolchain aggregate | Full compliance report card |
| Compare | `/api/audit-engine/compare` | DB query | Compare two audit snapshots |
| Trend | `/api/audit-engine/trend` | DB query | Score progression over time |
| Self-Heal | `/api/audit-engine/self-heal` | `tools/knowledge_graph/` + compliance | Auto-remediation suggestions |

### DocHub
| Tab | API Endpoint | Backing Tool | Work |
|-----|-------------|-------------|------|
| Documents | `/api/dochub/documents` | `tools/compliance/` generators | List generated docs |
| Health | `/api/dochub/health` | Cross-module health check | Document freshness scoring |
| Export | `/api/dochub/export` | Multi-format generator | PDF/OSCAL/markdown export |

### Research
| Tab | API Endpoint | Backing Tool | Work |
|-----|-------------|-------------|------|
| Sessions | `/api/research/sessions` | `tools/research/` | Research session management |
| Signals | `/api/research/signals` | `tools/research/` | Competitive intelligence signals |
| Dossiers | `/api/research/dossiers` | `tools/research/` | Competitor dossier aggregation |

**Template work:** Report card visualization, document health matrix, research signal timeline.

---

## Phase Summary

| Phase | Pages | Effort | Cumulative |
|-------|-------|--------|------------|
| **75** | Intelligence Dashboard | Medium | 1 page |
| **76** | Decisions + Container Lens | Medium | 3 pages |
| **77** | Compliance Acceleration | Large | 4 pages |
| **78** | Harness + Scorecard | Medium | 6 pages |
| **79** | Threat Modeler + PR Intel + ATO Sim | Medium | 9 pages |
| **80** | Knowledge Graph + cATO + Templates | Large | 12 pages |
| **81** | VSM + Golden Path + SBOM + Forge Hub | Medium | 16 pages |
| **82** | Audit Engine + DocHub + Research | Large | 19 pages |

**Total: 19 pages across 8 phases**

---

## Per-Phase Protocol

Every phase follows this mandatory sequence:

1. **Read backing tools** — Verify module exists, check function signatures
2. **Read current template** — Understand existing structure
3. **Enhance API endpoints** — Wire to real backing modules, add CUI markings
4. **Enhance template** — Auto-load on tab switch, visual cards, charts
5. **Restart dashboard** — Kill stale process, start fresh on port 5050
6. **Playwright E2E** — 3 viewports (1920x1080, 768x1024, 375x812), console/network error check
7. **Feature docs** — `docs/features/phase-{N}-{slug}.md`

---

## Dependencies

```
Phase 75 (Intelligence) ── standalone
Phase 76 (Decisions + Container) ── standalone
Phase 77 (Compliance Accel) ── benefits from Phase 75 (RAG tab overlap)
Phase 78 (Harness + Scorecard) ── standalone
Phase 79 (Security Trio) ── standalone
Phase 80 (Knowledge + cATO + Templates) ── benefits from Phase 77 (compliance overlap)
Phase 81 (VSM + Golden Path + SBOM + Hub) ── standalone
Phase 82 (Audit + DocHub + Research) ── benefits from Phases 77, 80 (compliance data)
```

Phases 75, 76, 78, 79, 81 can run in any order. Phases 77, 80, 82 benefit from sequential execution.
