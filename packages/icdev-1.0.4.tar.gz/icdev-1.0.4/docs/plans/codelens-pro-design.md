# CUI // SP-CTI
# CodeLens Pro -- Design Document

## Overview

CodeLens Pro is a marketplace module extending the base CodeLens (7 lenses) with 8 additional lenses (L8-L15) focused on UAT, IV&V, accessibility, mutation testing, UX, contract testing, chaos engineering, and AI intent validation.

## Architecture Decisions

| ADR | Decision |
|-----|----------|
| D-CLP-1 | CodeLens Pro is independent marketplace module in `tools/review_pro/` |
| D-CLP-2 | IV&V lens runs as separate subprocess (IEEE 1012 independence) |
| D-CLP-3 | Accessibility supports both WCAG 2.1 AA and 2.2 AA (configurable) |
| D-CLP-4 | Mutation testing runs on PR (quick mode) and nightly (full mode) |
| D-CLP-5 | Intent lens uses Qwen3.5 by default (configurable via args/review_pro_config.yaml) |
| D-CLP-6 | Chaos testing targets both A2A agents (12) and MCP servers (12) |
| D-CLP-7 | Contract testing is provider-driven (servers publish schemas) |
| D-CLP-8 | SUS survey collection is opt-in (dashboard toggle) |
| D-CLP-9 | All Pro results feed into ATO evidence via OSCAL |

## 8 New Lenses

| # | Lens | Type | Phase | Status |
|---|------|------|-------|--------|
| L8 | Accessibility | Deterministic | P1 | DONE |
| L9 | Mutation | Deterministic | P1 | DONE |
| L10 | Property | Deterministic | P2 | DONE |
| L11 | Contract | Deterministic | P4 | DONE |
| L12 | IV&V | Independent Process | P3 | DONE |
| L13 | Usability | Deterministic | P5 | DONE |
| L14 | Chaos | Deterministic | P4 | DONE |
| L15 | Intent | LLM-as-judge | P2 | DONE |

## Maturity Integration

| Level | Base CodeLens | + CodeLens Pro |
|-------|---------------|----------------|
| STANDARD | L1-L5 | + L8 (Accessibility) + L9 (Mutation) + L10 (Property) |
| ADVANCED | L1-L6 | + L11 (Contract) + L12 (IV&V) + L14 (Chaos) + L15 (Intent) |
| EXPERT | L1-L7 | + L13 (Usability) |

## Phase 1 Deliverables (DONE)

- Module scaffold: `tools/review_pro/` (15 Python files)
- L8 Accessibility: 10 deterministic WCAG checks + contrast + keyboard + axe-core
- L9 Mutation: 6 AST operators + runner + kill rate scoring
- Config: `args/review_pro_config.yaml`
- DB: 3 append-only tables (reviews, a11y_findings, mutation_results)
- Tests: 62 passing (25 accessibility, 22 mutation, 15 engine/config)
- CLI: `python -m tools.review_pro.cli_pro --project-dir . --json`

## Phase 2 Deliverables (DONE)

- L10 Property: AST-based invariant detection, Hypothesis test template generation
- L15 Intent: LLM-as-judge G-Eval (5 dimensions, Qwen3.5 default, configurable)
- Property added to standard maturity, Intent to advanced
- Tests: 54 new (16 property, 38 intent) — total 116 passing
- CLI E2E: standard maturity runs 3 lenses (a11y + mutation + property), score 94.4/A

## Phase 3 Deliverables (DONE)

- L12 IV&V: IEEE 1012 independent subprocess verification (D-CLP-2)
- Subprocess runner: `tools/review_pro/ivv/subprocess_runner.py` (isolated process)
- Wraps existing `tools/compliance/ivv_assessor.py` (1550+ lines, 9 process areas)
- JSON extraction from mixed-format subprocess output
- Severity mapping: critical/high -> blocker, medium -> tech_debt, low -> skippable
- DB: 1 new append-only table (codelens_pro_ivv_results)
- Tests: 19 new — total 135 passing
- CLI E2E: 15 findings, V:3.6%, Val:18.8%, subprocess isolation confirmed

## Phase 4 Deliverables (DONE)

- L11 Contract: Provider-driven MCP + A2A agent card schema validation (D-CLP-3, D-CLP-4)
  - A2A card validation: required fields, semver, auth schemes, skills
  - MCP registry validation: server file existence, duplicate tool names
  - Contract drift detection: code changes without contract updates
  - Tests: 18 new
- L14 Chaos: Static resilience posture verification (D-CLP-5, D-CLP-6)
  - 7 resilience checks: circuit breaker, retry, timeout, bulkhead, fallback, shutdown, health
  - Reads from args/resilience_config.yaml (GOTCHA args layer)
  - Resilience score: 0-100 composite from configuration completeness
  - Tests: 23 new
- Both lenses added to ADVANCED maturity tier
- Config: contract + chaos enabled in review_pro_config.yaml
- CLI E2E: 97.6/100 quality gate PASSED, 7 lenses at advanced, 0 blockers
- Tests: 176 total passing across all review_pro tests

## Phase 5 Deliverables (DONE)

- L13 Usability: Developer experience static analysis (D-CLP-8, D-CLP-10)
  - 6 checks: documentation coverage, API param count, bool param naming, error message quality, nesting depth, CLI help text
  - SUS infrastructure detection (opt-in per D-CLP-8)
  - Usability score: 0-100 composite from doc coverage + finding penalties
  - Tests: 30 new — total 206 passing
- All 8 Pro lenses now implemented and enabled
- CLI E2E: 98.5/100 quality gate PASSED, 8 lenses at expert maturity, 0 blockers
- Usability score: 94.0/100 on review_pro code

## Research Insights (Informing Future Phases)

### AI-Generated Code Testing
- AI PRs average 10.83 issues vs 6.45 human (CodeRabbit study)
- 100% coverage can have only 4% mutation score (Meta research)
- Property-based testing (Hypothesis) bridges LLM code gen and validation
- Meta's ACH: LLM-generated mutations + LLM-generated tests at scale

### IV&V for AI Systems (Phase 3)
- NIST AI TEVV: Test, Evaluation, Verification, Validation
- AI generation model treated as "supplier" (SA-15 alignment)
- Independent assessor requirement (IEEE 1012)

### UX Testing (Phase 5)
- System Usability Scale (SUS): 10-item survey, globally adopted
- Developer Experience Index (DXI): feedback loops, cognitive load, flow state
- Task completion rate, time-on-task for top 10 workflows

### Accessibility (Phase 1 - DONE)
- axe-core catches 30-40% of WCAG issues; manual testing needed for rest
- WCAG 2.2 AA adds: Focus Not Obscured, Target Size Minimum, Accessible Auth
- ADA Title II deadline: April 24, 2026

### Chaos Engineering (Phase 4 - DONE)
- ChaosEater (NTT): automated chaos cycles for K8s using LLMs
- Test: agent crash, message loss, timeout cascading, hallucination propagation
- Implementation: Static resilience posture analysis (7 checks: CB, retry, timeout, bulkhead, fallback, shutdown, health)

### LLM-as-Judge (Phase 2)
- 80% agreement with human preferences
- Thinking models (QwQ) outperform standard models as judges
- G-Eval pattern: LLM generates evaluation criteria before scoring
