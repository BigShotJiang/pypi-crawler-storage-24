# CodeLens/Pro Container & K8s Deployment Validator — Implementation Plan

**CUI // SP-CTI**
**Date:** 2026-03-11
**Research:** [container-deployment-research.md](../research/container-deployment-research.md)
**Status:** Draft — Pending Approval

---

## Table of Contents

1. [Overview](#1-overview)
2. [Architecture](#2-architecture)
3. [Implementation Phases](#3-implementation-phases)
4. [Phase 1: File Hygiene & Dockerfile Linting](#phase-1-file-hygiene--dockerfile-linting)
5. [Phase 2: K8s Manifest & Helm Validation](#phase-2-k8s-manifest--helm-validation)
6. [Phase 3: Image Scanning & Air-Gap Simulation](#phase-3-image-scanning--air-gap-simulation)
7. [Phase 4: Compliance, STIG & FIPS](#phase-4-compliance-stig--fips)
8. [Phase 5: Database Migration Validation](#phase-5-database-migration-validation)
9. [Phase 6: Dashboard, Integration & MCP](#phase-6-dashboard-integration--mcp)
10. [Database Schema](#database-schema)
11. [Configuration](#configuration)
12. [File Manifest](#file-manifest)
13. [Test Plan](#test-plan)

---

## 1. Overview

**Problem:** Developers build on Windows/macOS, deploy to hardened Linux containers in air-gapped government clouds. ~70% of deployment failures are catchable with static analysis but no single tool covers the full spectrum (platform mismatch + air-gap readiness + K8s config + compliance + database compatibility).

**Solution:** CodeLens/Pro — a deterministic, multi-lens validation engine that runs in < 60 seconds and catches container/K8s deployment issues before code leaves the developer's machine.

**Design Principles:**
1. **Deterministic first** — all checks are rule-based, no LLM in critical path (GOTCHA D-WG-2)
2. **Scanner-tier only** — zero Claude tokens (air-gap safe, cost-effective)
3. **Progressive pipeline** — Phase 1-3 always run; Phase 4-5 opt-in per profile
4. **Multi-cloud aware** — checks adapt to target CSP (EKS/AKS/RKE2/OpenShift)
5. **Profile-driven** — commercial, fedramp-moderate, dod-il4, dod-il5, air-gapped
6. **Offline capable** — no internet required at scan time

---

## 2. Architecture

### 2.1 Component Layout

```
tools/container_lens/
├── __init__.py                     # Package init
├── validator.py                    # Main orchestrator (CLI entry point)
├── lenses/
│   ├── __init__.py
│   ├── file_hygiene.py             # Lens A: CRLF, case, perms, BOM, symlinks
│   ├── dockerfile_lint.py          # Lens B: Dockerfile best practices
│   ├── k8s_manifest.py            # Lens C: K8s SecurityContext, resources, NetworkPolicy
│   ├── helm_chart.py              # Lens D: Helm lint, template, values completeness
│   ├── security_compliance.py     # Lens E: CVE, SBOM, STIG, FIPS, supply chain
│   ├── airgap_readiness.py        # Lens F: Network isolation, registry, DNS, certs
│   └── database_compat.py         # Lens G: PG version, migration, PgBouncer, syntax
├── profiles/
│   ├── __init__.py
│   └── profile_loader.py          # Load profile from args/container_lens_profiles.yaml
├── reporters/
│   ├── __init__.py
│   ├── json_reporter.py           # JSON output (machine-readable)
│   ├── table_reporter.py          # CLI table output (human-readable)
│   └── sarif_reporter.py          # SARIF output (IDE integration)
└── utils/
    ├── __init__.py
    ├── dockerfile_parser.py        # Parse Dockerfile AST
    ├── manifest_parser.py          # Parse K8s YAML manifests
    ├── helm_renderer.py            # helm template wrapper
    └── image_inspector.py          # Docker image layer inspection
```

### 2.2 Data Flow

```
Developer runs:
  python tools/container_lens/validator.py \
    --project-id sparkpilot \
    --project-dir . \
    --profile dod-il4 \
    --gate \
    --json

Pipeline:
  1. Profile loader → selects active lenses + thresholds
  2. Lenses run in parallel (ThreadPoolExecutor)
     A: file_hygiene   ─┐
     B: dockerfile_lint ─┤
     C: k8s_manifest   ─┤── parallel (< 5s)
     D: helm_chart     ─┤
     G: database_compat ─┘
  3. If image specified:
     E: security_compliance ─┐── parallel (< 15s)
     F: airgap_readiness    ─┘
  4. Aggregate findings
  5. Gate evaluation (pass/fail/warn per threshold)
  6. Crosswalk mapping (findings → NIST controls)
  7. Audit trail (append-only INSERT)
  8. Output (JSON/table/SARIF)
```

### 2.3 Lens Interface

Every lens implements:

```python
class LensResult:
    """Standard return from every lens."""
    lens_name: str                    # e.g., "file_hygiene"
    findings: List[Finding]           # Individual issues found
    score: float                      # 0-100 lens score
    duration_ms: int                  # Execution time
    checks_run: int                   # Total checks attempted
    checks_passed: int                # Checks that passed
    metadata: Dict                    # Lens-specific extra data

class Finding:
    """Single issue found by a lens."""
    check_id: str                     # e.g., "A-01"
    severity: str                     # BLOCK, WARN, INFO
    category: str                     # e.g., "file_hygiene"
    title: str                        # Short description
    description: str                  # Detail + evidence
    file_path: Optional[str]         # Affected file
    line: Optional[int]              # Line number
    remediation: str                  # How to fix
    nist_controls: List[str]         # e.g., ["CM-6", "SC-28"]
    cis_benchmark: Optional[str]     # CIS reference
    stig_id: Optional[str]           # STIG finding ID

def run_lens(project_dir: Path, config: Dict) -> LensResult:
    """Every lens module exposes this function."""
```

---

## 3. Implementation Phases

| Phase | Scope | Checks | Est. LOC | Dependencies |
|-------|-------|--------|----------|--------------|
| **1** | File hygiene + Dockerfile lint | A-01..A-15, B-01..B-20 | ~800 | None (pure Python) |
| **2** | K8s manifests + Helm charts | C-01..C-25, D-01..D-15 | ~900 | helm CLI (optional) |
| **3** | Image scanning + air-gap sim | E-01..E-10, F-01..F-10 | ~700 | Docker CLI, Trivy (optional) |
| **4** | STIG, FIPS, supply chain | E-11..E-25 | ~600 | OpenSCAP (optional) |
| **5** | Database migration validation | G-01..G-10 | ~500 | Alembic, testcontainers (optional) |
| **6** | Dashboard, MCP, CI integration | UI + API + MCP | ~800 | Flask (dashboard) |

**Total: ~4,300 LOC across 6 phases**

---

## Phase 1: File Hygiene & Dockerfile Linting

**Goal:** Catch the #1 class of deployment failures — platform mismatches that are invisible on the developer's machine but fatal in Linux containers.

### Lens A: File Hygiene (15 checks)

| Check | ID | Severity | What it detects | How |
|-------|----|----------|-----------------|-----|
| CRLF in scripts | A-01 | BLOCK | `\r\n` in .sh, Dockerfile, .dockerignore, .env | Read first 8KB, check for `\r\n` |
| Missing chmod | A-02 | WARN | .sh files without execute bit in Dockerfile COPY | Parse Dockerfile, track COPY of .sh without --chmod or subsequent chmod |
| Case collision | A-03 | BLOCK | Files differing only by case (e.g., `Config.py` vs `config.py`) | `os.listdir()` + case-fold comparison per directory |
| UTF-8 BOM | A-04 | WARN | BOM bytes in .dockerignore, Dockerfile, .env | Check first 3 bytes for `\xEF\xBB\xBF` |
| External symlinks | A-05 | WARN | Symlinks pointing outside build context | `os.path.realpath()` vs build context root |
| Missing .dockerignore | A-06 | WARN | No .dockerignore or ineffective patterns | Check existence; if exists, verify .git, node_modules, .env excluded |
| Secrets in context | A-07 | BLOCK | .env, *.pem, *.key, credentials.json in build context | Glob for sensitive file patterns not in .dockerignore |
| Large build context | A-08 | WARN | Files > 100MB in build context | Walk tree, sum sizes, flag > threshold |
| Windows paths | A-09 | WARN | Backslash paths in Dockerfile | Regex `\\` in COPY/ADD/WORKDIR/RUN lines |
| Missing .gitattributes | A-11 | INFO | No eol=lf rules for critical file types | Check .gitattributes for `*.sh text eol=lf` etc. |
| Hardcoded localhost | A-12 | WARN | `127.0.0.1`, `localhost` in source/config | Grep source files (excluding tests) |
| External URLs | A-13 | WARN | Telemetry endpoints, public registries | Pattern match against known phone-home URLs |
| Unpinned base image | A-14 | BLOCK | `FROM python:3.12` without digest | Parse FROM lines, check for `@sha256:` or specific patch tag |
| Invalid COPY --from | A-15 | BLOCK | Multi-stage COPY referencing non-existent stage | Parse all FROM aliases, verify --from references |

### Lens B: Dockerfile Lint (20 checks)

| Check | ID | Severity | What it detects |
|-------|----|----------|-----------------|
| Unpinned apt packages | B-01 | WARN | `apt-get install curl` without `=version` |
| Missing --no-cache-dir | B-02 | INFO | `pip install` without `--no-cache-dir` |
| Missing --no-install-recommends | B-03 | INFO | `apt-get install` without flag |
| Cache-busting COPY | B-04 | WARN | `COPY . /app/` before dependency install |
| No non-root USER | B-05 | BLOCK | Missing USER directive or USER 0/root |
| SUID/SGID not stripped | B-06 | WARN | No `find / -perm /6000` cleanup |
| Package managers present | B-07 | WARN (BLOCK for IL4+) | No removal of apt/apk/yum after install |
| Shell present | B-08 | INFO (WARN for IL5+) | /bin/sh, /bin/bash not removed |
| Missing HEALTHCHECK | B-09 | WARN | No HEALTHCHECK instruction |
| ARG vs ENV confusion | B-10 | WARN | ARG used for runtime config (not available after build) |
| ADD for remote URL | B-11 | WARN | `ADD http://...` instead of COPY + curl |
| Build deps leaking | B-12 | WARN | gcc, make, *-dev packages in final stage |
| Missing shared libs | B-13 | WARN | COPY --from builder without checking ldd dependencies |
| Missing locale data | B-14 | INFO | No LANG/LC_ALL env var set |
| Missing CA certs | B-15 | WARN (BLOCK for air-gap) | No ca-certificates installed, no COPY of internal CA |
| Missing telemetry opt-out | B-16 | INFO | Known telemetry env vars not set |
| Repo configs not cleaned | B-17 | WARN (BLOCK for air-gap) | /etc/apt/sources.list not emptied after install |
| Floating pip versions | B-18 | WARN | requirements.txt using `>=` instead of `==` |
| npm install vs npm ci | B-19 | WARN | `npm install` instead of `npm ci` |
| Non-FIPS base image | B-20 | BLOCK (IL4+ DoD) | Alpine or distroless base (no FIPS validation) |

### Phase 1 Files

```
tools/container_lens/__init__.py              # 10 LOC
tools/container_lens/validator.py             # 200 LOC — CLI + orchestrator
tools/container_lens/lenses/__init__.py       # 5 LOC
tools/container_lens/lenses/file_hygiene.py   # 250 LOC — 15 checks
tools/container_lens/lenses/dockerfile_lint.py # 300 LOC — 20 checks
tools/container_lens/utils/__init__.py        # 5 LOC
tools/container_lens/utils/dockerfile_parser.py # 100 LOC — FROM/COPY/RUN/USER/ARG/ENV parser
tools/container_lens/profiles/__init__.py     # 5 LOC
tools/container_lens/profiles/profile_loader.py # 60 LOC
tools/container_lens/reporters/__init__.py    # 5 LOC
tools/container_lens/reporters/json_reporter.py # 40 LOC
tools/container_lens/reporters/table_reporter.py # 60 LOC

args/container_lens_profiles.yaml             # 120 LOC — 5 profiles + thresholds
args/container_lens_checks.yaml               # 200 LOC — per-check severity overrides

tests/test_container_lens_file_hygiene.py     # 150 LOC
tests/test_container_lens_dockerfile_lint.py  # 150 LOC

goals/container_lens_validation.md            # Goal workflow document
```

### Phase 1 CLI

```bash
# Scan project directory for file hygiene + Dockerfile issues
python tools/container_lens/validator.py \
  --project-id sparkpilot \
  --project-dir . \
  --lenses file_hygiene,dockerfile_lint \
  --json

# Gate check (exit 1 on BLOCK findings)
python tools/container_lens/validator.py \
  --project-id sparkpilot \
  --project-dir . \
  --profile dod-il4 \
  --gate \
  --json

# Scan specific Dockerfile
python tools/container_lens/validator.py \
  --project-id sparkpilot \
  --dockerfile ./Dockerfile \
  --json
```

---

## Phase 2: K8s Manifest & Helm Validation

**Goal:** Catch K8s misconfigurations that cause silent failures in production — missing NetworkPolicy, wrong SecurityContext, env var ordering bugs, storage class mismatches.

### Lens C: K8s Manifest Validation (25 checks)

| Check | ID | Severity | What it detects |
|-------|----|----------|-----------------|
| Schema valid | C-01 | BLOCK | Invalid field names, wrong types (delegates to kubeconform if available, fallback to built-in checks) |
| Deprecated APIs | C-02 | BLOCK | Removed APIs for target K8s version |
| runAsNonRoot missing | C-03 | BLOCK | No `runAsNonRoot: true` in SecurityContext |
| readOnlyRootFilesystem | C-04 | BLOCK (IL4+) | Missing `readOnlyRootFilesystem: true` |
| allowPrivilegeEscalation | C-05 | BLOCK | Not set to `false` |
| Capabilities not dropped | C-06 | BLOCK | Missing `capabilities.drop: ["ALL"]` |
| No seccompProfile | C-07 | WARN (BLOCK IL4+) | Missing RuntimeDefault seccomp |
| Missing resource limits | C-08 | BLOCK | No `limits.cpu` or `limits.memory` |
| No liveness probe | C-09 | WARN | Missing livenessProbe |
| No readiness probe | C-10 | WARN | Missing readinessProbe |
| Host namespace | C-11 | BLOCK | `hostNetwork`, `hostPID`, or `hostIPC` |
| Privileged container | C-12 | BLOCK | `privileged: true` |
| Default namespace | C-13 | BLOCK (IL4+) | `namespace: default` or missing namespace |
| Latest tag | C-14 | BLOCK | Image uses `:latest` tag |
| No imagePullSecrets | C-15 | WARN | Missing imagePullSecrets |
| Default ServiceAccount | C-16 | WARN | Using `default` SA |
| hostPath volumes | C-17 | BLOCK | Any `hostPath` volume |
| No NetworkPolicy | C-18 | BLOCK (IL4+) | No NetworkPolicy in same namespace YAML |
| DNS egress missing | C-19 | WARN | NetworkPolicy egress blocks port 53 |
| Env var ordering | C-20 | WARN | `$(VAR)` references undefined/later vars |
| ConfigMap/Secret size | C-21 | WARN | Inline data > 512KB |
| CSP-specific annotations | C-22 | INFO | Hardcoded AWS/Azure/GCP annotations (not parameterized) |
| Topology constraints | C-23 | INFO | DoNotSchedule with insufficient zones |
| Init container deps | C-24 | INFO | Init container order doesn't match service deps |
| Sidecar limits missing | C-25 | WARN | Sidecar containers without resource limits |

### Lens D: Helm Chart Validation (15 checks)

| Check | ID | Severity | What it detects |
|-------|----|----------|-----------------|
| helm lint | D-01 | BLOCK | Chart structural issues |
| Rendered schema | D-02 | BLOCK | `helm template` output fails kubeconform |
| Rendered security | D-03 | BLOCK | Rendered output fails C-01..C-25 |
| Dead values | D-04 | INFO | keys in values.yaml not referenced in templates |
| Missing defaults | D-05 | WARN | Template references without `default` function |
| Hook weight sorting | D-06 | WARN | Non-zero-padded hook weights |
| CRD dependencies | D-07 | WARN | References to CRDs from other charts |
| Chart metadata | D-08 | INFO | Missing required Chart.yaml fields |
| Vendored deps | D-09 | WARN (BLOCK air-gap) | Subchart deps not in charts/ directory |
| Floating dep versions | D-10 | WARN | `version: "*"` or `>=` in Chart.yaml dependencies |
| Test hooks | D-11 | INFO | No Helm test hooks defined |
| NOTES.txt | D-12 | INFO | Missing NOTES.txt |
| Values schema | D-13 | INFO | No values.schema.json |
| Multi-cloud annotations | D-14 | WARN | CSP-specific annotations not parameterized |
| Storage class hardcoded | D-15 | WARN | StorageClass name not parameterized |

### Phase 2 Files

```
tools/container_lens/lenses/k8s_manifest.py   # 350 LOC — 25 checks
tools/container_lens/lenses/helm_chart.py      # 250 LOC — 15 checks
tools/container_lens/utils/manifest_parser.py  # 150 LOC — YAML multi-doc parser
tools/container_lens/utils/helm_renderer.py    # 100 LOC — helm template wrapper

tests/test_container_lens_k8s_manifest.py      # 200 LOC
tests/test_container_lens_helm_chart.py        # 150 LOC
```

### Phase 2 CLI

```bash
# Validate K8s manifests
python tools/container_lens/validator.py \
  --project-id sparkpilot \
  --manifests k8s/ \
  --target-k8s-version 1.29 \
  --target-csp eks-govcloud \
  --json

# Validate Helm chart
python tools/container_lens/validator.py \
  --project-id sparkpilot \
  --helm-chart charts/myapp/ \
  --helm-values charts/myapp/values-production.yaml \
  --json
```

---

## Phase 3: Image Scanning & Air-Gap Simulation

**Goal:** Validate built images for vulnerabilities, supply chain integrity, and air-gap readiness. The "does it actually work with no network?" test.

### Lens E: Security & Compliance — Subset (10 checks)

| Check | ID | Severity | What it detects | Tool |
|-------|----|----------|-----------------|------|
| Approved registry | E-01 | BLOCK (IL4+) | Image not from Iron Bank / approved mirror | Image ref parsing |
| Image signed | E-02 | WARN (BLOCK IL4+) | No Cosign signature | cosign verify (if available) |
| Critical CVEs | E-03 | BLOCK | CVSS 9.0+ vulnerabilities | Trivy / Grype (if available), fallback to Syft + NVD lookup |
| High CVEs | E-04 | WARN | CVSS 7.0-8.9 | Same as E-03 |
| SBOM current | E-05 | WARN | No SBOM or SBOM older than 30 days | Check sbom_entries table |
| SBOM matches image | E-06 | WARN | SBOM digest doesn't match image digest | Compare digests |
| Secrets in layers | E-07 | BLOCK | .env, credentials, keys in image layers | Trivy secret scan or pattern match on layer content |
| SLSA provenance | E-08 | INFO (WARN IL4+) | No provenance attestation | Check for in-toto attestation |
| No latest tag | E-09 | BLOCK | Image ref uses :latest | Already in C-14 but also validates built image tag |
| Image size | E-10 | INFO | Image > threshold (500MB default) | Docker inspect |

### Lens F: Air-Gap Readiness (10 checks)

| Check | ID | Severity | What it detects | How |
|-------|----|----------|-----------------|-----|
| Build offline | F-01 | BLOCK (air-gap profile) | Dockerfile needs network during build | `docker build --network none` |
| Runtime offline | F-02 | BLOCK (air-gap profile) | Container needs network to start | `docker run --network none` + check exit code |
| Health check offline | F-03 | WARN | Health check fails without connectivity | `docker run --network none` + curl health endpoint |
| External DNS | F-04 | WARN | DNS lookups to external domains | Parse container logs for DNS errors |
| Images in mirror | F-05 | BLOCK (air-gap profile) | Referenced images not in mirror registry | Aggregate all image refs, check against registry |
| Helm deps vendored | F-06 | WARN | Chart deps require network to fetch | Check charts/ directory |
| No post-install network | F-07 | WARN | pip/npm/cargo called at runtime | Scan entrypoint and CMD for package manager invocations |
| CA cert injected | F-08 | WARN | No internal CA certificate in image | Check /etc/ssl/certs/ for non-default CAs |
| NTP config | F-09 | INFO | No NTP/chrony configuration | Check for chrony.conf or ntpd.conf |
| CoreDNS no forward | F-10 | WARN | CoreDNS Corefile has upstream `forward` | Parse CoreDNS ConfigMap YAML |

### Phase 3 Files

```
tools/container_lens/lenses/security_compliance.py  # 300 LOC — 10 checks
tools/container_lens/lenses/airgap_readiness.py     # 250 LOC — 10 checks
tools/container_lens/utils/image_inspector.py       # 150 LOC — Docker/Trivy wrappers

tests/test_container_lens_security.py               # 150 LOC
tests/test_container_lens_airgap.py                 # 150 LOC
```

### Phase 3 CLI

```bash
# Scan built image
python tools/container_lens/validator.py \
  --project-id sparkpilot \
  --image myapp:v1.2.3 \
  --profile air-gapped \
  --gate \
  --json

# Air-gap simulation (builds and tests with --network none)
python tools/container_lens/validator.py \
  --project-id sparkpilot \
  --project-dir . \
  --dockerfile Dockerfile \
  --simulate-airgap \
  --json

# Full validation (all lenses)
python tools/container_lens/validator.py \
  --project-id sparkpilot \
  --project-dir . \
  --dockerfile Dockerfile \
  --image myapp:v1.2.3 \
  --manifests k8s/ \
  --helm-chart charts/myapp/ \
  --profile dod-il4 \
  --gate \
  --json
```

---

## Phase 4: Compliance, STIG & FIPS

**Goal:** Automated STIG/FIPS compliance checking for DoD customers. Commercial customers skip these checks via profile selection.

### Lens E (continued): Compliance Checks (15 more checks)

| Check | ID | Severity | What it detects |
|-------|----|----------|-----------------|
| FIPS base image | E-09 | BLOCK (IL4+ DoD) | Base image not FIPS-validated (Alpine, distroless) |
| FIPS OpenSSL | E-10 | BLOCK (IL4+ DoD) | OpenSSL not built with FIPS module |
| FIPS Python hashlib | E-11 | WARN | `hashlib.md5()` without `usedforsecurity=False` |
| Audit logging config | E-12 | WARN | No audit log forwarding in manifests |
| Log forwarding | E-13 | WARN | No Fluentd/Fluent Bit sidecar |
| mTLS configured | E-14 | WARN (BLOCK IL5+) | No Istio PeerAuthentication: STRICT |
| etcd encryption | E-15 | BLOCK (DoD) | No encryption-provider-config |
| API server STIG | E-16 | BLOCK/WARN | anonymous-auth, authorization-mode, audit-log |
| Kubelet STIG | E-17 | BLOCK/WARN | anonymous-auth, authorization-mode, read-only-port |
| VEX document | E-18 | INFO (WARN IL4+) | No VEX for known CVEs |
| No world-writable | E-19 | WARN | World-writable files in image |
| Secret rotation | E-20 | INFO | No rotation policy for mounted secrets |
| TLS cert expiry | E-21 | WARN | TLS certs expiring within 30 days |
| PV encryption | E-22 | WARN (BLOCK IL4+) | StorageClass missing `encrypted: "true"` |
| RBAC least-privilege | E-23 | WARN | ClusterRoleBinding to cluster-admin |
| PSS enforced | E-24 | BLOCK (IL4+) | Namespace missing `pod-security.kubernetes.io/enforce=restricted` |
| Runtime monitoring | E-25 | INFO | No Falco/Sysdig DaemonSet |

### NIST Control Mapping

Each check maps to NIST 800-53 controls for crosswalk integration:

| Check Category | Primary NIST Controls |
|---------------|----------------------|
| File hygiene (A) | CM-6 (Configuration Settings), CM-7 (Least Functionality) |
| Dockerfile (B) | CM-6, CM-7, SC-28 (Protection of Info at Rest), SI-7 (Software Integrity) |
| K8s security (C) | AC-3 (Access Enforcement), AC-6 (Least Privilege), SC-7 (Boundary Protection) |
| Helm (D) | CM-2 (Baseline Configuration), CM-6 |
| CVE/SBOM (E-01..E-10) | RA-5 (Vulnerability Monitoring), SI-2 (Flaw Remediation) |
| STIG/FIPS (E-11..E-25) | SC-13 (Cryptographic Protection), AU-3 (Audit Content), IA-7 (Crypto Authentication) |
| Air-gap (F) | SC-7, CM-7, SC-8 (Transmission Confidentiality) |
| Database (G) | CM-6, SC-28, SI-7 |

### Phase 4 Files

```
tools/container_lens/lenses/security_compliance.py  # Extend from Phase 3 (+300 LOC)
tools/container_lens/utils/stig_checks.py           # 200 LOC — K8s STIG check functions
tools/container_lens/utils/fips_checker.py          # 100 LOC — FIPS validation helpers

tests/test_container_lens_stig.py                   # 150 LOC
tests/test_container_lens_fips.py                   # 100 LOC
```

---

## Phase 5: Database Migration Validation

**Goal:** Catch database compatibility issues that only surface in production (PG version mismatch, SQLite syntax leakage, PgBouncer conflicts, migration ordering).

### Lens G: Database Compatibility (10 checks)

| Check | ID | Severity | How |
|-------|----|----------|-----|
| PG version match | G-01 | WARN | Compare docker-compose PG version vs K8s PG version vs prod target |
| SQLite syntax leak | G-02 | BLOCK | Grep migrations for `INSERT OR REPLACE`, `?` placeholders, `date('now')` |
| Migration test | G-03 | WARN | Run `alembic check` against target PG version (if testcontainers available) |
| Rollback test | G-04 | INFO | Check each migration has a `downgrade()` that's not `pass` |
| Advisory lock | G-05 | WARN | Migration entrypoint doesn't use `pg_try_advisory_lock` |
| PgBouncer bypass | G-06 | WARN | Migration connects via PgBouncer service (not direct PG) |
| SSL configured | G-07 | WARN (BLOCK prod) | Connection string missing `sslmode=verify-full` |
| Connection format | G-08 | INFO | URL-encoded special chars in password |
| ILIKE vs LIKE | G-09 | INFO | `LIKE` used in queries where case-insensitivity intended |
| Schema drift | G-10 | WARN | Alembic head doesn't match DB state |

### Phase 5 Files

```
tools/container_lens/lenses/database_compat.py  # 300 LOC
tools/container_lens/utils/migration_parser.py  # 150 LOC — Alembic migration analyzer

tests/test_container_lens_database.py           # 150 LOC
```

---

## Phase 6: Dashboard, Integration & MCP

**Goal:** Visual dashboard for validation results, MCP server integration for Claude Code, and CI pipeline injection.

### 6.1 Dashboard Route

**Route:** `/container-lens`

**Features:**
- Recent validation results (table with pass/fail/score)
- Per-lens breakdown (expandable accordion)
- Findings drill-down (severity, file, remediation)
- Profile selector (commercial/fedramp/dod-il4/dod-il5/air-gapped)
- Trend chart (score over time)
- Gate status indicator (PASS/FAIL with violation details)

### 6.2 MCP Server Integration

Add to existing MCP server (`tools/mcp/security_server.py` or new `tools/mcp/container_lens_server.py`):

```
Tools:
  container_lens_validate    — Run full validation
  container_lens_scan_file   — Scan single file for hygiene issues
  container_lens_check_image — Scan built image
  container_lens_gate        — Evaluate gate pass/fail
  container_lens_airgap_sim  — Run air-gap simulation
```

### 6.3 CI Pipeline Integration

Generate CI stage for GitLab CI, GitHub Actions, or generic:

```yaml
# Generated by pipeline_security_generator.py
container_lens:
  stage: validate
  script:
    - python tools/container_lens/validator.py
        --project-id $PROJECT_ID
        --project-dir .
        --dockerfile Dockerfile
        --manifests k8s/
        --profile $COMPLIANCE_PROFILE
        --gate
        --json
        --output reports/container-lens.json
  artifacts:
    reports:
      container_scanning: reports/container-lens.json
```

### 6.4 Scorecard Integration

Add `container_readiness` as a 7th dimension to the Developer Scorecard:

```python
DIMENSION_WEIGHTS = {
    "code_quality": 0.18,         # Was 0.20
    "security": 0.18,             # Was 0.20
    "compliance": 0.13,           # Was 0.15
    "test_coverage": 0.13,        # Was 0.15
    "velocity": 0.08,             # Was 0.10
    "sbd_posture": 0.18,          # Was 0.20
    "container_readiness": 0.12,  # NEW
}
```

### Phase 6 Files

```
tools/dashboard/templates/container_lens.html   # 300 LOC — Dashboard template
tools/dashboard/app.py                          # +50 LOC — Route registration
tools/mcp/container_lens_server.py              # 200 LOC — MCP server
tools/analytics/scorecard.py                    # +30 LOC — 7th dimension

tests/test_container_lens_dashboard.py          # 100 LOC
.claude/commands/e2e/container_lens.md          # E2E test spec
```

---

## Database Schema

```sql
-- CUI // SP-CTI
-- New tables for CodeLens/Pro (in icdev.db per D-INV-48)

CREATE TABLE IF NOT EXISTS container_lens_validations (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    profile TEXT NOT NULL DEFAULT 'commercial',
    target_csp TEXT,                           -- eks, aks, rke2, openshift, etc.
    target_k8s_version TEXT,
    dockerfile_path TEXT,
    image_ref TEXT,
    manifest_paths TEXT,                       -- JSON array
    helm_chart_path TEXT,
    overall_score REAL NOT NULL DEFAULT 0.0,
    letter_grade TEXT NOT NULL DEFAULT 'F',
    gate_passed INTEGER NOT NULL DEFAULT 0,
    gate_violations TEXT,                      -- JSON array
    lens_results TEXT NOT NULL,                -- JSON: {lens_name: LensResult}
    total_findings INTEGER NOT NULL DEFAULT 0,
    block_count INTEGER NOT NULL DEFAULT 0,
    warn_count INTEGER NOT NULL DEFAULT 0,
    info_count INTEGER NOT NULL DEFAULT 0,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    classification TEXT NOT NULL DEFAULT 'CUI',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS container_lens_findings (
    id TEXT PRIMARY KEY,
    validation_id TEXT NOT NULL,
    project_id TEXT NOT NULL,
    check_id TEXT NOT NULL,                    -- e.g., "A-01", "C-18"
    severity TEXT NOT NULL,                    -- BLOCK, WARN, INFO
    category TEXT NOT NULL,                    -- lens name
    title TEXT NOT NULL,
    description TEXT,
    file_path TEXT,
    line_number INTEGER,
    remediation TEXT,
    nist_controls TEXT,                        -- JSON array e.g., ["CM-6", "SC-28"]
    stig_id TEXT,
    cis_ref TEXT,
    classification TEXT NOT NULL DEFAULT 'CUI',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    FOREIGN KEY (validation_id) REFERENCES container_lens_validations(id)
);

CREATE INDEX IF NOT EXISTS idx_cl_validations_project
    ON container_lens_validations(project_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_cl_findings_validation
    ON container_lens_findings(validation_id);
CREATE INDEX IF NOT EXISTS idx_cl_findings_severity
    ON container_lens_findings(project_id, severity);
```

---

## Configuration

### args/container_lens_profiles.yaml

```yaml
# CUI // SP-CTI
# CodeLens/Pro Validation Profiles — GOTCHA args layer

profiles:
  commercial:
    description: "Non-DoD commercial cloud deployment"
    active_lenses: [file_hygiene, dockerfile_lint, k8s_manifest, helm_chart, security_compliance, database_compat]
    skip_checks: [B-07, B-08, B-20, C-18, E-01, E-02, E-08, E-09, E-10, E-11, E-12, E-13, E-14, E-15, E-16, E-17, E-24, E-25]
    thresholds:
      min_score: 60
      max_block: 0
      max_critical_cve: 0
      max_high_cve: 5

  fedramp-moderate:
    description: "FedRAMP Moderate baseline"
    active_lenses: [file_hygiene, dockerfile_lint, k8s_manifest, helm_chart, security_compliance, airgap_readiness, database_compat]
    skip_checks: [B-08, E-14, E-25]
    thresholds:
      min_score: 70
      max_block: 0
      max_critical_cve: 0
      max_high_cve: 0

  dod-il4:
    description: "DoD Impact Level 4 with STIG + FIPS"
    active_lenses: [file_hygiene, dockerfile_lint, k8s_manifest, helm_chart, security_compliance, airgap_readiness, database_compat]
    skip_checks: []
    severity_overrides:
      B-07: BLOCK        # Package managers MUST be removed
      B-20: BLOCK        # FIPS base image REQUIRED
      C-18: BLOCK        # NetworkPolicy REQUIRED
      E-01: BLOCK        # Approved registry REQUIRED
      E-02: BLOCK        # Image signing REQUIRED
      E-24: BLOCK        # PSS restricted REQUIRED
    thresholds:
      min_score: 80
      max_block: 0
      max_critical_cve: 0
      max_high_cve: 0
      fips_required: true
      stig_cat1_max: 0

  dod-il5:
    description: "DoD Impact Level 5 with SLSA 3"
    inherits: dod-il4
    severity_overrides:
      B-08: BLOCK        # No shells
      E-08: BLOCK        # SLSA provenance REQUIRED
      E-14: BLOCK        # mTLS REQUIRED
    thresholds:
      min_score: 85
      slsa_level_min: 3

  air-gapped:
    description: "Fully air-gapped environment (no egress)"
    active_lenses: [file_hygiene, dockerfile_lint, k8s_manifest, helm_chart, airgap_readiness, database_compat]
    severity_overrides:
      B-15: BLOCK        # CA cert injection REQUIRED
      B-17: BLOCK        # Repo configs cleanup REQUIRED
      D-09: BLOCK        # Helm deps vendored REQUIRED
      F-01: BLOCK        # Build offline REQUIRED
      F-02: BLOCK        # Runtime offline REQUIRED
      F-05: BLOCK        # All images in mirror REQUIRED
    thresholds:
      min_score: 75
      max_block: 0

  # Multi-cloud target configurations
  target_csp:
    eks-govcloud:
      k8s_api_version_min: "1.27"
      arn_prefix: "arn:aws-us-gov:"
      storage_classes: [gp2, gp3, io1, io2]
      ingress_class: alb
      network_policy_cni: calico
      notes: "Requires Calico addon for NetworkPolicy. GovCloud ARN prefix."

    aks-gov:
      k8s_api_version_min: "1.27"
      storage_classes: [managed-premium, managed-standard, azurefile]
      ingress_class: azure/application-gateway
      network_policy_cni: azure
      notes: "NetworkPolicy requires --network-policy flag at cluster creation."

    rke2:
      k8s_api_version_min: "1.27"
      storage_classes: [local-path]
      ingress_class: nginx
      network_policy_cni: calico
      default_pss: restricted
      stig_flags_accessible: true
      notes: "Most STIG-compliant. Default PSS is restricted."

    openshift:
      k8s_api_version_min: "4.14"
      security_model: scc
      ingress_model: routes
      notes: "Uses SCC not PSS. Uses Routes not Ingress."
```

---

## File Manifest

### New Files (by phase)

| Phase | Path | Purpose | LOC |
|-------|------|---------|-----|
| 1 | `tools/container_lens/__init__.py` | Package init | 10 |
| 1 | `tools/container_lens/validator.py` | CLI + orchestrator | 200 |
| 1 | `tools/container_lens/lenses/__init__.py` | Lens package | 5 |
| 1 | `tools/container_lens/lenses/file_hygiene.py` | 15 file checks | 250 |
| 1 | `tools/container_lens/lenses/dockerfile_lint.py` | 20 Dockerfile checks | 300 |
| 1 | `tools/container_lens/utils/__init__.py` | Utils package | 5 |
| 1 | `tools/container_lens/utils/dockerfile_parser.py` | Dockerfile AST | 100 |
| 1 | `tools/container_lens/profiles/__init__.py` | Profiles package | 5 |
| 1 | `tools/container_lens/profiles/profile_loader.py` | YAML profile loader | 60 |
| 1 | `tools/container_lens/reporters/__init__.py` | Reporters package | 5 |
| 1 | `tools/container_lens/reporters/json_reporter.py` | JSON output | 40 |
| 1 | `tools/container_lens/reporters/table_reporter.py` | CLI table output | 60 |
| 1 | `args/container_lens_profiles.yaml` | Profiles + thresholds | 120 |
| 1 | `args/container_lens_checks.yaml` | Per-check config | 200 |
| 1 | `goals/container_lens_validation.md` | Goal workflow | 80 |
| 1 | `tests/test_container_lens_file_hygiene.py` | Unit tests | 150 |
| 1 | `tests/test_container_lens_dockerfile_lint.py` | Unit tests | 150 |
| 2 | `tools/container_lens/lenses/k8s_manifest.py` | 25 K8s checks | 350 |
| 2 | `tools/container_lens/lenses/helm_chart.py` | 15 Helm checks | 250 |
| 2 | `tools/container_lens/utils/manifest_parser.py` | K8s YAML parser | 150 |
| 2 | `tools/container_lens/utils/helm_renderer.py` | helm template wrapper | 100 |
| 2 | `tests/test_container_lens_k8s_manifest.py` | Unit tests | 200 |
| 2 | `tests/test_container_lens_helm_chart.py` | Unit tests | 150 |
| 3 | `tools/container_lens/lenses/security_compliance.py` | 25 security checks | 600 |
| 3 | `tools/container_lens/lenses/airgap_readiness.py` | 10 air-gap checks | 250 |
| 3 | `tools/container_lens/utils/image_inspector.py` | Docker/Trivy wrapper | 150 |
| 3 | `tests/test_container_lens_security.py` | Unit tests | 150 |
| 3 | `tests/test_container_lens_airgap.py` | Unit tests | 150 |
| 4 | `tools/container_lens/utils/stig_checks.py` | K8s STIG functions | 200 |
| 4 | `tools/container_lens/utils/fips_checker.py` | FIPS validation | 100 |
| 4 | `tests/test_container_lens_stig.py` | Unit tests | 150 |
| 5 | `tools/container_lens/lenses/database_compat.py` | 10 DB checks | 300 |
| 5 | `tools/container_lens/utils/migration_parser.py` | Alembic analyzer | 150 |
| 5 | `tests/test_container_lens_database.py` | Unit tests | 150 |
| 6 | `tools/dashboard/templates/container_lens.html` | Dashboard UI | 300 |
| 6 | `tools/mcp/container_lens_server.py` | MCP server | 200 |
| 6 | `.claude/commands/e2e/container_lens.md` | E2E test spec | 80 |

### Modified Files

| Phase | Path | Change |
|-------|------|--------|
| 1 | `tools/manifest.md` | Add container_lens entries |
| 1 | `goals/manifest.md` | Add container_lens_validation goal |
| 6 | `tools/dashboard/app.py` | Add `/container-lens` route + API endpoints |
| 6 | `tools/analytics/scorecard.py` | Add 7th dimension `container_readiness` |
| 6 | `args/security_gates.yaml` | Add `container_lens` gate section |
| 6 | `tools/ci/triggers/pipeline_security_generator.py` | Add container_lens stage |

---

## Test Plan

### Unit Tests (per phase)

Each lens has dedicated pytest tests with fixture-based test data:

```python
# tests/test_container_lens_file_hygiene.py
def test_a01_detects_crlf_in_shell_script(tmp_path):
    """A-01: CRLF in .sh files → BLOCK."""
    sh = tmp_path / "entrypoint.sh"
    sh.write_bytes(b"#!/bin/bash\r\necho hello\r\n")
    result = run_lens(tmp_path, {})
    assert any(f.check_id == "A-01" and f.severity == "BLOCK" for f in result.findings)

def test_a01_passes_lf_only(tmp_path):
    """A-01: LF-only .sh files → no finding."""
    sh = tmp_path / "entrypoint.sh"
    sh.write_bytes(b"#!/bin/bash\necho hello\n")
    result = run_lens(tmp_path, {})
    assert not any(f.check_id == "A-01" for f in result.findings)
```

### Integration Tests

```bash
# Run against the ICDEV codebase itself
python tools/container_lens/validator.py \
  --project-id sparkpilot \
  --project-dir . \
  --profile commercial \
  --json

# Verify: no BLOCK findings for our own codebase (dogfood)
```

### BDD Tests

```gherkin
Feature: Container Lens Validation
  As a developer deploying to air-gapped DoD environments
  I want pre-push validation to catch deployment issues
  So that deployments don't fail in production

  Scenario: Detect CRLF line endings in shell scripts
    Given a project with entrypoint.sh containing CRLF line endings
    When I run container lens with profile "commercial"
    Then I should see finding A-01 with severity BLOCK
    And the remediation should mention .gitattributes

  Scenario: DoD IL4 blocks non-FIPS base image
    Given a Dockerfile with "FROM alpine:3.19"
    When I run container lens with profile "dod-il4"
    Then I should see finding B-20 with severity BLOCK
    And the remediation should recommend RHEL UBI or Iron Bank base

  Scenario: Air-gap profile validates offline build
    Given a Dockerfile that runs "pip install flask"
    When I run container lens with profile "air-gapped"
    Then I should see finding F-01 with severity BLOCK
    And the remediation should mention vendored wheels
```

### E2E Tests (Phase 6)

Playwright E2E testing for dashboard at `/container-lens` — covered by `.claude/commands/e2e/container_lens.md`.

---

## Approach Considerations

### Why NOT wrap existing tools?

We could simply wrap Hadolint + kubeconform + Trivy + kube-linter. However:

1. **Air-gap safe:** These tools require installation. Our checks must work with zero external binaries (pure Python fallback).
2. **Custom checks:** 40+ checks in our catalog don't exist in any tool (env var ordering, phone-home detection, multi-cloud portability, PgBouncer compat, FIPS chain, etc.).
3. **Unified scoring:** No tool provides a single weighted score across all dimensions.
4. **Profile system:** No tool supports DoD-specific severity overrides per IL level.
5. **Crosswalk integration:** Findings must map to NIST controls for the crosswalk engine.

**Approach:** Pure Python implementation for all checks. When external tools ARE available (Trivy, helm, kubeconform), delegate to them for deeper analysis. When they're not, our built-in checks still provide 80%+ coverage.

### Why `tools/container_lens/` not `tools/security/`?

Container validation spans security, compliance, operations, and database. It doesn't fit cleanly in any existing directory. A dedicated `container_lens/` directory follows the GOTCHA principle of clear tool boundaries and makes it easy to exclude from child apps if needed (like `tools/govcon/` via `PARENT_ONLY_DIRS`).
