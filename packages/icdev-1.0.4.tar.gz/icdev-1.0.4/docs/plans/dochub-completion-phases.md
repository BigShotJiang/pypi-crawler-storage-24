# DocHub — Living Documentation Engine: Phased Completion Plan

**Classification:** CUI // SP-CTI
**Created:** 2026-03-12
**Status:** Active

---

## Current State

DocHub is **95% complete** with 9 Python modules (6,753 LOC), 10 interactive tabs, 12 DB tables, and 21 API endpoints. Remaining work is focused on 4 missing API endpoints, template UI polish, and full E2E validation.

### Completion Matrix

| Tab | API | Tool | Template | DB | Status |
|-----|-----|------|----------|----|--------|
| Overview | ✅ | ✅ | ✅ | ✅ | COMPLETE |
| Documents | ✅ | ✅ | ✅ | ✅ | COMPLETE |
| Modules | ✅ | ✅ | ✅ | ✅ | COMPLETE |
| BYOS Scanner | ✅ | ✅ | ✅ | ✅ | COMPLETE |
| Profiles | ✅ | ✅ | ✅ | — | COMPLETE |
| Export | ⚠️ 3 missing | ✅ | ✅ | ✅ | NEEDS 3 ENDPOINTS |
| Health | ✅ | ✅ | ✅ | ✅ | COMPLETE |
| Changelog | ✅ | ✅ | ✅ | ✅ | COMPLETE |
| Apps | ✅ | ✅ | ✅ | ✅ | COMPLETE |
| Impact Analysis | ⚠️ 1 missing | ✅ | ✅ | ✅ | NEEDS 1 ENDPOINT |

---

## Phase 75A: Export Tab — Missing Endpoints

**Effort:** Small | **Files:** `tools/dashboard/app.py`

The Export tab template calls 3 endpoints that don't exist in `app.py`:

| Endpoint | Purpose | Backing Data |
|----------|---------|-------------|
| `GET /api/dochub/export/history/<project_id>` | Past export log | Query `dh_documents` for exported docs |
| `GET /api/dochub/export/fedramp-status/<project_id>` | FedRAMP package readiness | Check required doc types present vs FedRAMP Rev 5 checklist |
| `GET /api/dochub/export/dod-status/<project_id>` | DoD IL package readiness | Check required doc types present vs IL2/IL4/IL5 checklist |

**Work:**
1. Add 3 route handlers in `app.py` near existing DocHub routes (lines ~7018-7373)
2. `export/history` — query `dh_documents` WHERE `project_id = ?` ORDER BY `created_at DESC`
3. `export/fedramp-status` — compare generated doc types against `context/dochub/export_formats/fedramp_package.json` required list
4. `export/dod-status` — compare against `context/dochub/export_formats/dod_il_package.json` required list
5. All responses include `classification: "CUI // SP-CTI"`

---

## Phase 75B: Impact Analysis — Graph Endpoint

**Effort:** Small | **Files:** `tools/dashboard/app.py`

| Endpoint | Purpose | Backing Data |
|----------|---------|-------------|
| `GET /api/dochub/impact/graph/<target_id>` | Dependency graph visualization | Query `dh_dependency_graph` adjacency list |

**Work:**
1. Add route handler returning nodes + edges from `dh_dependency_graph` table
2. Format as `{ nodes: [...], edges: [...] }` for frontend canvas rendering
3. Include `classification: "CUI // SP-CTI"`

---

## Phase 75C: Template UI Enhancement

**Effort:** Medium | **File:** `tools/dashboard/templates/dochub.html`

### Auto-load & State Tracking
- Add `tabLoaded` state tracking (same pattern as Phases 73-74)
- Auto-load data on first tab visit instead of requiring manual clicks
- Prevent redundant API calls on tab re-visit

### Export Tab Polish
- Wire FedRAMP/DoD status cards to new endpoints from Phase 75A
- Show readiness checklist with green/red indicators per required doc type
- Export history table with format, date, file size columns

### Impact Analysis Polish
- Wire graph visualization to new endpoint from Phase 75B
- Render dependency DAG using canvas or SVG
- Show affected apps/modules on node click

### Dynamic App Selector
- Currently hardcoded to "sparkpilot (default)" in template
- Populate dropdown dynamically from `GET /api/dochub/tenants`
- Persist selection across tab switches

---

## Phase 75D: Playwright E2E Validation

**Effort:** Medium | **E2E Spec:** `.claude/commands/e2e/dochub.md`

Full 10-tab E2E test across 3 viewports:

| Viewport | Resolution |
|----------|-----------|
| Desktop | 1920×1080 |
| Tablet | 768×1024 |
| Mobile | 375×812 |

**Per-tab validation:**
1. **Overview** — Stat cards render, recent docs table populated
2. **Documents** — Filter dropdowns work, generate form submits, doc view modal opens
3. **Modules** — Module table renders, register form submits, detail modal opens
4. **BYOS Scanner** — Scan form submits, results render, artifact import works
5. **Profiles** — All 8 profile cards render with terminology sets
6. **Export** — Format list loads, export triggers, FedRAMP/DoD status cards render
7. **Health** — Score computes, grade indicator shows, dimension breakdown renders
8. **Changelog** — Diff table renders, version range picker works
9. **Apps** — Tenant table renders, register form submits
10. **Impact** — Analysis form submits, results render, graph visualizes

**Checks:**
- Console errors = 0
- Network 500-level errors = 0
- All API endpoints return 200

**Screenshots:** 30 total (10 tabs × 3 viewports)
- `playwright/screenshots/phase75-dochub-{tab}-{WxH}.png`

---

## Phase 75E: Feature Documentation

**Effort:** Small | **File:** `docs/features/phase-75-dochub-completion.md`

Document:
- 4 new API endpoints added
- Template UI enhancements (auto-load, app selector, graph viz)
- E2E test results table
- Screenshot references

---

## Execution Order

```
Phase 75A (Export endpoints)     ─┐
Phase 75B (Impact graph endpoint) ─┤── can run in parallel
                                   │
Phase 75C (Template UI)          ──┘── depends on 75A + 75B
                                   │
Phase 75D (Playwright E2E)       ──── depends on 75C
                                   │
Phase 75E (Feature docs)         ──── depends on 75D
```

**Total estimated effort:** 1 phase, 5 sub-phases, ~2-3 hours

---

## Key Files

| File | Role |
|------|------|
| `tools/dashboard/app.py` (lines 7018-7373) | DocHub API routes |
| `tools/dashboard/templates/dochub.html` | 10-tab template (~1,800 lines) |
| `tools/dochub/doc_generator.py` | Core generation engine (722 LOC) |
| `tools/dochub/export_engine.py` | Multi-format export (962 LOC) |
| `tools/dochub/health_scorer.py` | Health scoring (909 LOC) |
| `tools/dochub/byos_scanner.py` | Third-party scanner (1,126 LOC) |
| `tools/dochub/tenant_manager.py` | App/module registry (837 LOC) |
| `tools/dochub/diff_engine.py` | Section-level diffing (533 LOC) |
| `tools/dochub/profile_engine.py` | Audience profiles (400 LOC) |
| `tools/dochub/data_collector.py` | Data aggregation (481 LOC) |
| `tools/dochub/enrichment_engine.py` | CVE/regulatory enrichment (783 LOC) |
| `context/dochub/templates/` | 12 document templates |
| `context/dochub/profiles/` | 8 audience profile JSONs |
| `context/dochub/export_formats/` | 3 export format configs |
| `args/dochub_config.yaml` | Feature flags and settings |
| `.claude/commands/e2e/dochub.md` | E2E test specification |
