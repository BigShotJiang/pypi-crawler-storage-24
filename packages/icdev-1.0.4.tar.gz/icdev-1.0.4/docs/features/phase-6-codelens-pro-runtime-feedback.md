# CUI // SP-CTI
# Phase 6: CodeLens Pro L16 Runtime Feedback Lens

## Summary

L16 Runtime Feedback closes the loop between code review (left of deploy) and
production behavior (right of deploy). It correlates runtime error telemetry
back to source files under review, identifying error hotspots, recurring
patterns, deployment-correlated spikes, and test coverage gaps.

**Air-gap native by default.** The LocalCollector reads from existing ICDEV
SQLite tables with zero external dependencies. Connected mode (Sentry webhook)
is optional.

## Architecture

```
                     ┌─────────────────────────┐
                     │    Code Review (L1-L15)  │
                     │    Left of Deploy        │
                     └───────────┬──────────────┘
                                 │ deploys
                     ┌───────────▼──────────────┐
                     │  Production Runtime       │
                     │  audit_trail, crash_dumps, │
                     │  otel_spans, test_results  │
                     └───────────┬──────────────┘
                                 │ telemetry
         ┌───────────────────────▼────────────────────────┐
         │              L16 Runtime Feedback               │
         │  ┌──────────┐  ┌───────────┐  ┌─────────────┐ │
         │  │ Collector │→│ Correlator │→│ Deploy Track │ │
         │  │ (pluggable)│ │ (4 strat) │  │ (spike det) │ │
         │  └──────────┘  └───────────┘  └─────────────┘ │
         │          │           │              │           │
         │     ┌────▼───────────▼──────────────▼────┐     │
         │     │         5 Analysis Checks          │     │
         │     │ 1. Error hotspots                   │     │
         │     │ 2. Recurring patterns               │     │
         │     │ 3. Deploy impact                    │     │
         │     │ 4. Test gap analysis                │     │
         │     │ 5. Error type distribution          │     │
         │     └────────────────────────────────────┘     │
         └────────────────────────────────────────────────┘
```

## Two Operating Modes

| Mode | Collector | Dependencies | Use Case |
|------|-----------|-------------|----------|
| **Local** (default) | `LocalCollector` | Zero external | Air-gapped, IL4+, SCIF |
| **Sentry** (optional) | `SentryCollector` | Sentry webhook cache table | Connected environments |

Both modes produce identical analysis output. The collector is pluggable —
analysis logic is universal.

## Data Sources (Local Mode)

| Source | Table | What It Provides |
|--------|-------|-----------------|
| Audit Trail | `audit_trail` | Error events, failure actions |
| Crash Dumps | `crash_dump_log` | Embedded device crashes with backtrace |
| Test Results | `runtime_feedback` | Failed pytest results with source mapping |
| OTel Traces | `otel_spans` | Error spans from SQLiteTracer (D280) |

## Correlation Strategies

| Strategy | Confidence | Method |
|----------|-----------|--------|
| `stack_trace` | 95% | Parse Python tracebacks for `File "path", line N` |
| `module_path` | 80-85% | Match error file paths to project file paths |
| `function_name` | 75% | Match error function to function defs in diff |
| `git_blame` | 70% | Correlate error timestamps with git commits |

## Analysis Checks

### 1. Error Hotspots
Files with high error counts in the lookback window.
- >= 20 errors → **BLOCKER**
- >= 5 errors → **TECH_DEBT**

### 2. Recurring Patterns
Same error type in same file 3+ times indicates systematic issue.
- Severity: **TECH_DEBT**

### 3. Deploy Impact
Compares pre-deploy baseline error rate to post-deploy rate.
- Spike multiplier >= 3.0x → **BLOCKER**
- Includes affected files and error types

### 4. Test Gap Analysis
Files with runtime errors but no passing test results recorded.
- Requires 3+ errors to flag
- Severity: **TECH_DEBT**

### 5. Error Type Distribution
Metrics-only — counts error types and sources for dashboard visibility.

## Health Score (0-100)

| Factor | Max Penalty |
|--------|------------|
| Hotspot blockers | -30 (15 per blocker, capped) |
| Hotspot files | -15 (3 per file, capped) |
| Recurring patterns | -15 (3 per pattern, capped) |
| Deploy impacts | -20 (10 per impact, capped) |
| Test gaps | -10 (2 per file, capped) |

## Configuration

### review_pro_config.yaml
```yaml
lenses:
  runtime_feedback:
    enabled: false               # Enable at ADVANCED+ maturity
    weight: 1.0
    collector: local             # "local" or "sentry"
    error_spike_threshold: 5
    lookback_hours: 168          # 7-day window
    correlation_min_confidence: 50
```

### args/runtime_feedback_config.yaml
Full collector configuration — see file for all options.

### Environment Variables
- `CODELENS_PRO_RUNTIME_COLLECTOR` — override collector mode
- `CODELENS_PRO_RUNTIME_LOOKBACK_HOURS` — override lookback window

## Maturity Levels

| Maturity | L16 Available |
|----------|--------------|
| STANDARD | No |
| ADVANCED | Yes |
| EXPERT | Yes |

## Files Created/Modified

### New Files (7)
- `tools/review_pro/runtime/__init__.py`
- `tools/review_pro/runtime/collectors.py` — LocalCollector + SentryCollector
- `tools/review_pro/runtime/correlator.py` — Error-to-source correlation engine
- `tools/review_pro/runtime/deploy_tracker.py` — Deploy impact detection
- `tools/review_pro/lenses/runtime_feedback.py` — L16 lens orchestration
- `tools/review_pro/tests/test_runtime_feedback.py` — 28 unit tests
- `args/runtime_feedback_config.yaml` — GOTCHA args layer config

### Modified Files (6)
- `tools/review_pro/models_pro.py` — `RUNTIME_FEEDBACK` enum + finding fields
- `tools/review_pro/config_pro.py` — defaults + env var overrides
- `tools/review_pro/engine_pro.py` — L16 import + dispatch + storage
- `tools/review_pro/scoring_pro.py` — runtime feedback coaching tips
- `tools/review_pro/db.py` — `codelens_pro_runtime_findings` table
- `tools/review_pro/lenses/base_pro.py` — runtime finding fields in `_make_finding`
- `args/review_pro_config.yaml` — L16 config section

## Architecture Decisions

| ADR | Decision |
|-----|----------|
| **D-CLP-10** | Air-gap native — LocalCollector has zero external dependencies |
| **D-CLP-11** | Pluggable ingestion, universal analysis — same lens logic regardless of data source |
| **D-CLP-12** | Deterministic spike detection — statistical comparison, no ML |
| **D-CLP-13** | Correlation strategies ordered by confidence — stack_trace > module_path > function_name |

## Test Results

```
28 passed in 0.20s
234 total CodeLens Pro tests passed (existing + new)
```

## CLI Usage

```bash
# Enable L16 via maturity level
python -m tools.review_pro.cli_pro --project-dir . --maturity advanced --json

# Enable L16 explicitly
python -m tools.review_pro.cli_pro --project-dir . --pro-lenses runtime_feedback --no-base --json

# Override collector to Sentry mode
CODELENS_PRO_RUNTIME_COLLECTOR=sentry python -m tools.review_pro.cli_pro --project-dir . --pro-lenses runtime_feedback --json
```

## Research Basis

Based on competitive analysis of Sentry.io, Datadog, New Relic, SigNoz, Raygun,
Rollbar, PostHog, Bugsnag, and GlitchTip (research session `rsess-64cc1b666bb1`).
Key insight: don't compete with Sentry — integrate the feedback loop that no one
else offers. CodeLens is the only system that correlates production errors back
to code review findings, and works fully air-gapped.
