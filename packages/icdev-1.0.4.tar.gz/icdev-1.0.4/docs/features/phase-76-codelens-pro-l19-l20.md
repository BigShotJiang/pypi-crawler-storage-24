# Phase 76: CodeLens/Pro L19 Compliance QE + L20 Test Decay + L21 Test Pattern Bank

**Classification:** CUI // SP-CTI
**Date:** 2026-03-12
**Status:** Implemented

---

## Summary

Three new CodeLens Pro lenses that extend the Code Quality Intelligence suite:

- **L19: Compliance-Integrated QE** — Maps test coverage to NIST 800-53 control families. No competitor addresses this; it bridges dev-centric test metrics with assessor-centric compliance evidence.
- **L20: Test Decay Detector** — Finds stale, rotting, and abandoned tests: skipped tests, empty bodies, commented-out assertions, TODO/FIXME markers, and high skip ratios.
- **L21: Test Pattern Recommender** — Cross-module test pattern bank. Indexes test patterns per module, identifies common patterns across peers, and reports gaps where a module is missing patterns that majority of peers implement.

All three are deterministic, scanner-tier (zero LLM tokens), air-gap safe.

---

## L19: Compliance-Integrated QE (pro_compliance_qe)

**File:** `tools/review_pro/lenses/compliance_qe.py`
**Maturity tier:** Advanced

Maps 12 NIST 800-53 control families to test evidence via keyword/AST heuristics:

| Family | Name | Severity | Confidence | Keywords |
|--------|------|----------|------------|----------|
| AC | Access Control | blocker | 85 | auth, login, permission, role, rbac, 403, 401 |
| AU | Audit & Accountability | tech_debt | 75 | audit, log, trail, event_log, provenance |
| CM | Configuration Management | skippable | 60 | config, settings, baseline, yaml, env_var |
| IA | Identification & Authentication | blocker | 80 | password, credential, mfa, certificate, ldap |
| SC | System & Comms Protection | blocker | 80 | encrypt, tls, ssl, crypto, aes, fips, mtls |
| SI | System & Info Integrity | tech_debt | 75 | validate, sanitize, injection, xss, csrf |
| RA | Risk Assessment | tech_debt | 65 | vulnerability, cve, scan, risk, threat |
| CP | Contingency Planning | tech_debt | 70 | backup, restore, failover, recovery, rollback |
| SA | System & Services Acquisition | skippable | 60 | sbom, supply_chain, dependency, vendor |
| MP | Media Protection | skippable | 55 | encrypt_at_rest, storage_encrypt, wipe |
| IR | Incident Response | skippable | 55 | incident, alert, notification, escalation |
| PE | Physical & Environmental | skippable | 40 | physical, badge, access_card, facility |

**Metrics:** `compliance_qe_score` (0-100), `families_tested`, `families_untested`, per-family coverage details.

### Smoke Test Results

```
L19 Compliance QE: 36 test files scanned
  Score: 83.3% (10/12 families covered)
  Covered: AC, AU, CM, IA, SC, SI, RA, CP, SA, IR
  Gaps: MP (Media Protection), PE (Physical/Environmental)
```

---

## L20: Test Decay Detector (pro_test_decay)

**File:** `tools/review_pro/lenses/test_decay.py`
**Maturity tier:** Standard (always active)

Detects 5 categories of test rot:

| Category | Severity | Confidence | Detection Method |
|----------|----------|------------|------------------|
| Skipped/xfail tests | tech_debt | 85 | Regex: @pytest.mark.skip, @unittest.skip, pytest.skip() |
| Empty test bodies | blocker | 90 | Regex: def test_...(): pass/... |
| Commented assertions | tech_debt | 75 | Regex: # assert, # self.assert, # expect( |
| TODO/FIXME markers | skippable | 60 | Regex: # TODO, FIXME, HACK, XXX, BROKEN |
| High skip ratio | tech_debt | 80 | >50% of tests in file are skipped |

**Metrics:** `decay_score` (0-100), `total_tests`, `skipped_tests`, `empty_tests`, `commented_asserts`, `todo_markers`.

### Smoke Test Results

```
L20 Test Decay: 36 test files, 827 tests
  Decay score: 97.6% (Good)
  Skipped tests: 20
  Empty tests: 0
  Commented asserts: 0
  TODO markers: 0
```

---

## L21: Test Pattern Recommender (pro_test_patterns)

**File:** `tools/review_pro/lenses/test_patterns.py`
**Maturity tier:** Standard (always active)

Indexes test files per module, builds a cross-module pattern matrix, and identifies gaps:

| Pattern Category | Description | Detection Method |
|-----------------|-------------|------------------|
| unit_assertion | Direct value assertions | assert ==, !=, in, isinstance |
| exception_testing | Exception/error path testing | pytest.raises, assertRaises |
| fixture_usage | Test fixture and setup patterns | @pytest.fixture, tmp_path, monkeypatch |
| mocking | Mocking and patching patterns | patch(), MagicMock, Mock, monkeypatch.setattr |
| parametrize | Parameterized test patterns | @pytest.mark.parametrize |
| bdd_gherkin | BDD/Gherkin scenario patterns | Given/When/Then, Scenario:, Feature: |
| snapshot_golden | Snapshot/golden file testing | snapshot, golden, expected_output, baseline |
| integration_db | Database integration testing | get_connection, sqlite3.connect, CREATE TABLE |
| api_http | API/HTTP endpoint testing | client.get/post, requests.get/post, response.status_code |
| async_concurrent | Async/concurrent test patterns | @pytest.mark.asyncio, asyncio.run, ThreadPoolExecutor |

**Module detection:** Filename patterns, import analysis, and keyword mapping against 25 known module directories.

**Common pattern threshold:** Patterns used by >= 50% of detected modules are considered "common". Modules missing common patterns get advisory findings.

**Metrics:** `pattern_consistency_score` (0-100), `modules_analyzed`, `modules_with_gaps`, `total_test_files`, per-module summary with pattern counts and gaps.

### RAG Infrastructure Enhancement

- **GraphRAG scoring profile (D-KARL-1):** New `test_patterns` profile with weights `{relevance: 0.5, centrality: 0.3, proximity: 0.2}` and auto-detection via regex
- **Source registry:** 3 new sources registered — `test_execution_events`, `codelens_pro_reviews`, `harness_recommendations`

### Smoke Test Results

```
L21 Test Patterns: 36 test files, 10 modules
  Pattern consistency: 20.0% (8/10 modules have gaps)
  Common patterns: fixture_usage, integration_db, mocking, unit_assertion
  Modules: ci, cloudforge, compliance, container_lens, databridge,
           forge_studio, harness, marketplace, security, writing
```

---

## Integration

### Files Created

| File | Purpose |
|------|---------|
| `tools/review_pro/lenses/compliance_qe.py` | L19 implementation |
| `tools/review_pro/lenses/test_decay.py` | L20 implementation |
| `tools/review_pro/lenses/test_patterns.py` | L21 implementation |
| `docs/features/phase-76-codelens-pro-l19-l20.md` | This document |

### Files Modified

| File | Change |
|------|--------|
| `tools/review_pro/models_pro.py` | +3 enum values: COMPLIANCE_QE, TEST_DECAY, TEST_PATTERNS |
| `tools/review_pro/models_pro.py` | Updated PRO_MATURITY_LENSES (L20+L21→standard, L19→advanced) |
| `tools/review_pro/engine_pro.py` | +3 lens registrations in _create_pro_lenses() |
| `args/review_pro_config.yaml` | +3 lens config blocks (compliance_qe, test_decay, test_patterns) |
| `tools/dashboard/app.py` | Updated code-quality API to include L19+L20+L21 |
| `tools/dashboard/templates/container_lens.html` | Added L19+L20+L21 stat cards, metric panels, JS rendering |
| `tools/knowledge_graph/graph_rag.py` | Added test_patterns scoring profile + auto-detection regex |
| `tools/rag/source_registry.py` | +3 source entries (test_execution_events, codelens_pro_reviews, harness_recommendations) |

### Architecture Decisions

- **D-CLP-21:** Compliance QE uses keyword/AST heuristics to classify test functions into NIST control families (no LLM)
- **D-CLP-22:** Test Decay uses regex pattern matching to identify test rot without running the test suite
- **D-CLP-23:** L20 is standard-tier (always active) because decayed tests are always dangerous
- **D-CLP-24:** All three lenses are zero-LLM, pure deterministic (GOTCHA scanner tier)
- **D-CLP-25:** Cross-module pattern matching uses GraphRAG test_patterns profile
- **D-CLP-26:** Module detection via directory heuristic (tools/<module>/)
- **D-CLP-27:** Pattern bank is read-only advisory (never modifies test files)
