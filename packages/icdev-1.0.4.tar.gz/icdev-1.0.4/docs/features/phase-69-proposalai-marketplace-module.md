# CUI // SP-CTI
# Phase 69: ProposalAI Module + Free Trials + Marketplace Admin

## Overview

Phase 69 adds three capabilities:
- **Free Trial System** — 30-day trial for any marketplace module, renewable once (60 days max)
- **ProposalAI Module** — Gates Phase 67/68 AI drafting features behind a marketplace subscription
- **Marketplace Admin** — CRUD interface for managing modules and pricing tiers, plus redesigned marketplace page (1 card per module with pricing tiers inside)

## Architecture Decisions

| ID | Decision | Rationale |
|----|----------|-----------|
| D-P69-1 | New `trial` billing_cycle | Reuses existing subscription/license infrastructure |
| D-P69-2 | Trial auto-activates, 30-day expiry | Same UX as free tier but time-limited |
| D-P69-3 | `trial_renewal_count` column, max 1 renewal | 60 days max before requiring paid subscription |
| D-P69-4 | Single `proposalai` module slug | One paywall for all AI drafting features |
| D-P69-5 | `@require_module('proposalai')` on 8 API routes | Server-side 403 enforcement |
| D-P69-6 | `{% if module_enabled('proposalai') %}` on templates | Client-side gating with upgrade prompts |
| D-P69-7 | New `/marketplace/admin` page with CRUD | Admin configuration for modules + pricing |
| D-P69-8 | Redesigned marketplace page — 1 card per module | Group pricing tiers inside card, not separate cards |

## Schema Changes

### ALTER: `marketplace_subscriptions`
```sql
ALTER TABLE marketplace_subscriptions ADD COLUMN trial_renewal_count INTEGER DEFAULT 0;
```

### CHECK Constraint Updates
Both `marketplace_pricing` and `marketplace_subscriptions` tables updated to include `'trial'` in `billing_cycle` CHECK constraint.

### New Seed Data
- WriteGuard trial pricing tier ($0, 30 days)
- ProposalAI asset (slug: `proposalai`, type: `skill`)
- ProposalAI pricing: trial ($0), monthly ($149), annual ($1,490)

## Modified Files

| File | Changes |
|------|---------|
| `tools/db/init_icdev_db.py` | Trial ALTER SQL, CHECK constraint updates, ProposalAI + trial seed data |
| `tools/marketplace/subscription_manager.py` | Trial in `create_subscription()`, new `renew_trial()` |
| `tools/marketplace/license_manager.py` | Trial 30-day expiry in `issue_license()` |
| `tools/dashboard/app.py` | 8 route gates, 2 trial routes, 5 admin CRUD routes, marketplace page redesign |
| `tools/dashboard/templates/marketplace.html` | Redesign: 1 card per module with pricing tiers |
| `tools/dashboard/templates/marketplace_admin.html` | New: Module + pricing CRUD admin |
| `tools/dashboard/templates/marketplace_subscriptions.html` | Trial status, renewal button |
| `tools/dashboard/templates/proposals/detail.html` | Gate Generate All/Generate buttons |
| `tools/dashboard/templates/proposals/section_detail.html` | Gate Generate Draft, pipeline, KB panels |
| `tools/dashboard/templates/govcon.html` | Gate KB nav link |

## API Routes

### Trial Routes
| Route | Method | Purpose |
|-------|--------|---------|
| `/api/marketplace/trial/start` | POST | Start 30-day trial for a module |
| `/api/marketplace/trial/renew` | POST | Renew trial once (another 30 days) |

### Admin Routes
| Route | Method | Purpose |
|-------|--------|---------|
| `/marketplace/admin` | GET | Admin page listing all modules + pricing |
| `/api/marketplace/admin/assets` | POST | Create new module asset |
| `/api/marketplace/admin/assets/<id>` | PUT | Update module |
| `/api/marketplace/admin/pricing` | POST | Add pricing tier |
| `/api/marketplace/admin/pricing/<id>` | PUT | Update pricing tier |
| `/api/marketplace/admin/pricing/<id>` | DELETE | Soft deactivate pricing tier |

### Gated Routes (ProposalAI)
| Route | Purpose |
|-------|---------|
| `GET /govcon/knowledge-base` | KB browse page |
| `POST /api/govcon/knowledge-base/upload` | KB document upload |
| `GET /api/govcon/knowledge-base/search` | KB search |
| `GET /api/govcon/knowledge-base/stats` | KB statistics |
| `POST /api/govcon/sections/<id>/generate-draft` | Single section v2 pipeline |
| `POST /api/govcon/sections/<id>/draft-status` | Draft status check |
| `POST /api/govcon/proposals/<id>/generate-all` | Batch generation |
| `GET /api/govcon/jobs/<id>/progress` | Batch job progress |

## Trial Lifecycle

```
No subscription → "Start 30-Day Trial" button
    ↓ POST /api/marketplace/trial/start
Trial Active (30 days) → "Renew 30 Days" button
    ↓ POST /api/marketplace/trial/renew
Trial Active (extended 30 days) → "(renewal used)"
    ↓ Expires or Cancel
No subscription → "Start 30-Day Trial" / "Subscribe" buttons
```

## Marketplace Redesign

**Before (Phase 66):** 1 card per pricing tier → 3 cards for WriteGuard (confusing)
**After (Phase 69):** 1 card per module with pricing tiers listed inside

Card layout:
```
┌────────────────────────────────────────┐
│ ProposalAI — AI Proposal Drafting      │  From $149/mo
│ proposalai · v1.0.0                    │
│ Description text...                    │
│ [govcon] [proposal] [drafting] [ai]    │
│ ┌──────┐ ┌─────────┐ ┌──────────────┐ │
│ │Trial │ │ Monthly │ │   Annual     │ │
│ │ $0   │ │  $149   │ │  $1,490      │ │
│ └──────┘ └─────────┘ └──────────────┘ │
│ [Start Trial] [Subscribe] [Gov PO]     │
│  — or — ✓ Trial Active (2026-04-03)   │
└────────────────────────────────────────┘
```

## Verification Results

| # | Check | Result |
|---|-------|--------|
| V1 | ProposalAI + trial tiers in DB | 2 assets, 7 pricing tiers |
| V2 | Trial start | Trial activates, 30-day expiry, routes unlock (200) |
| V3 | Trial renewal | Renew extends 30d, count=1, second attempt shows "(renewal used)" |
| V4 | Route gating (no license) | 403 on KB/draft APIs |
| V5 | Template gating | KB link hidden, Generate buttons hidden |
| V6 | Cancel trial | Routes re-gated (403), buttons reappear on marketplace |
| V7 | Marketplace redesign | 1 card per module, tiers inside, 3 viewports |
| V8 | Admin CRUD | Modules + pricing displayed with Edit/Deactivate/Publish |
| V9 | Subscriptions page | Trial status, renewal info, Cancel button |
| V10 | Console errors | 0 errors across all pages |
| V11 | Network 500s | 0 server errors |
