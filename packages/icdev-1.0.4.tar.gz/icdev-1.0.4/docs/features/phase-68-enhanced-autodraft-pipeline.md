# CUI // SP-CTI
# Phase 68: Enhanced Auto-Draft Pipeline

## Overview

Phase 68 upgrades the Phase 67 single-step RAG draft generation into a 4-step
enhanced pipeline: KB Retrieval → Engine Enrichment → SMART Solutioning → Content
Generation with WriteGuard quality gate. Adds batch "Generate All" with
dependency-aware ordering and step-by-step progress UI.

## Architecture Decisions

| ID | Decision | Rationale |
|----|----------|-----------|
| D-P68-1 | New `engine_enrichment.py` for DB keyword queries | GOTCHA separation; standalone for Phase 69 extraction |
| D-P68-2 | Static `context/icdev_methodology.md` + KB search | Air-gap safe; deterministic context injection |
| D-P68-3 | New `draft_generation_jobs` table for batch tracking | Polling-based progress needs persistent state |
| D-P68-4 | WriteGuard post-check via direct `analyze()` call | Same-process, faster than HTTP roundtrip |
| D-P68-5 | Auto-rewrite once, then flag human | Balance automation with HITL quality control |
| D-P68-6 | Kahn's topological sort for batch ordering | Deterministic, handles deps + sort_order fallback |
| D-P68-7 | Background thread for batch generation | Long-running, UI polls for progress |
| D-P68-8 | Prior sections context injected into each subsequent section | Sequential dependency builds coherent proposal |

## New Files

| File | Purpose |
|------|---------|
| `tools/govcon/engine_enrichment.py` | DB queries against Innovation/Creative/Research tables |
| `context/icdev_methodology.md` | Static ICDEV framework reference (GOTCHA, ATLAS, RICOAS, ZTA) |

## Modified Files

| File | Changes |
|------|---------|
| `tools/govcon/draft_orchestrator.py` | Added v2 pipeline, batch generation, job tracking, SMART plan |
| `hardprompts/proposal_draft.md` | Added engine_enrichments, smart_plan, prior_sections, style_hints |
| `tools/dashboard/app.py` | Updated generate-draft to v2, added generate-all + job progress routes |
| `tools/dashboard/templates/proposals/detail.html` | Generate All button, progress bar, polling JS |
| `tools/dashboard/templates/proposals/section_detail.html` | Pipeline steps panel, quality score display |
| `tools/db/init_icdev_db.py` | `draft_generation_jobs` table, ALTER columns on `proposal_section_drafts` |

## Pipeline Data Flow

```
Step 1: KB Retrieval
  → knowledge_base.search_blocks(query, domain, top_k=5) → kb_blocks[]
  → search_blocks("GOTCHA ATLAS methodology", top_k=3) → methodology_blocks[]

Step 2: Engine Enrichment
  → engine_enrichment.extract_rfp_keywords(section, opp, shalls) → keywords[]
  → query_innovation_tables(keywords) → innovation_results[]
  → query_creative_tables(keywords) → creative_results[]
  → query_research_tables(keywords) → research_results[]

Step 3: SMART Solutioning
  → Read context/icdev_methodology.md (static, ~3000 chars max)
  → Build SMART prompt combining KB + engines + methodology
  → router.invoke("proposal_drafting") → structured SMART plan
  → Fallback: deterministic bullet-point plan from KB blocks

Step 4: Content Generation + Quality Gate
  → Fill enhanced hardprompts/proposal_draft.md with ALL context
  → router.invoke("proposal_drafting") → draft_content
  → WriteGuard analyze(draft_content) → quality_score
  → IF score < 60: rewriter.rewrite() → rewritten draft
  → IF still < 60: flagged for human review
  → Save to proposal_section_drafts with provenance
```

## Dashboard Routes

| Route | Method | Purpose |
|-------|--------|---------|
| `/api/govcon/sections/<id>/generate-draft` | POST | Single section v2 pipeline (updated) |
| `/api/govcon/proposals/<opp_id>/generate-all` | POST | Start batch job, returns job_id |
| `/api/govcon/jobs/<job_id>/progress` | GET | Poll batch progress |

## Schema Changes

### New Table: `draft_generation_jobs`
Tracks batch generation jobs with step-by-step progress.

### New Columns on `proposal_section_drafts`
- `engine_enrichment_ids` — JSON array of engine result IDs used
- `smart_plan` — Generated SMART plan text
- `writeguard_score` — Quality score from WriteGuard post-check
- `writeguard_result_id` — Reference to WriteGuard analysis result
- `was_auto_rewritten` — Whether auto-rewrite was applied
- `pipeline_version` — "v1" or "v2"

## CLI Usage

```bash
# Single section v2 pipeline
python tools/govcon/draft_orchestrator.py --generate-v2 --section-id <id> --opportunity-id <id> --json

# Batch generate all sections
python tools/govcon/draft_orchestrator.py --batch --opportunity-id <id> --json

# Engine enrichment test
python tools/govcon/engine_enrichment.py --test --json

# v1 pipeline (legacy fallback)
python tools/govcon/draft_orchestrator.py --generate --section-id <id> --opportunity-id <id> --json
```

## Bug Fixes

- Applied Phase 68 schema to both `sparkpilot.db` and `icdev.db` (dashboard uses `icdev.db`)
