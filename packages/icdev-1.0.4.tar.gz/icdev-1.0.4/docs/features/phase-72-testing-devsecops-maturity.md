# CUI // SP-CTI
# Phase 72: Testing & DevSecOps Maturity — Phase 6 Completion

## Overview

Completes the Architecture Evolution Phase 6 by implementing property-based
testing, compliance artifact snapshot tests, a SLSA Level 2 GitHub Actions
workflow, environment profiles, and enhancing the DevSecOps Maturity Dashboard
with Output Verifier and Environment Comparison tabs.

This phase closes the gap between deterministic compliance tooling and
continuous delivery assurance — every compliance artifact is now
property-tested for structural invariants, snapshot-tested for regression,
and the build pipeline produces verifiable SLSA Level 2 provenance.

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                   Phase 72 — Testing & DevSecOps             │
│                                                              │
│  ┌─────────────────┐  ┌──────────────────┐  ┌────────────┐  │
│  │ Property-Based   │  │ Snapshot Tests    │  │ SLSA L2    │  │
│  │ Tests (Hypothesis)│  │ (Compliance       │  │ Build      │  │
│  │ 25 tests, 6 class │  │  Artifacts)       │  │ Provenance │  │
│  └────────┬─────────┘  └────────┬──────────┘  └─────┬──────┘  │
│           │                     │                    │         │
│  ┌────────▼─────────────────────▼────────────────────▼──────┐ │
│  │              DevSecOps Maturity Dashboard                 │ │
│  │  ┌──────────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌────┐ ┌─────┐│ │
│  │  │Compliance│ │Feature│ │ SLSA │ │Test  │ │Out-│ │Env  ││ │
│  │  │Sidecar   │ │Flags  │ │Prov. │ │Strat.│ │put │ │Comp.││ │
│  │  │          │ │       │ │      │ │      │ │Ver.│ │     ││ │
│  │  └──────────┘ └──────┘ └──────┘ └──────┘ └────┘ └─────┘│ │
│  │                    6 Tabs Total                          │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │          Environment Profiles (args/environments/)        │ │
│  │   dev.yaml │ staging.yaml │ production.yaml │ air-gap.yaml│ │
│  └──────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```

## Property-Based Testing

25 Hypothesis-driven property tests across 6 test classes verify structural
invariants of compliance tooling outputs:

| Test Class | Tool Under Test | Properties Verified |
|------------|----------------|---------------------|
| `TestCrosswalkProperties` | `crosswalk_engine.py` | Framework key validity, bidirectional mapping consistency |
| `TestNistLookupProperties` | `nist_lookup.py` | Control ID format, family grouping, baseline membership |
| `TestZtaMaturityProperties` | `zta_maturity_scorer.py` | Score bounds (0-100), pillar count, level ordering |
| `TestSbdProperties` | `sbd_assessor.py` | Requirement ID format, pillar assignment, gate result shape |
| `TestTrustScoringProperties` | `agent_trust_scorer.py` | Score normalization (0.0-1.0), dimension completeness |
| `TestControlMapperProperties` | `control_mapper.py` | Activity-to-control mapping, output schema compliance |

**Why property-based:** Traditional unit tests check specific examples.
Property tests generate thousands of random inputs per run, catching edge
cases that hand-written tests miss. Critical for compliance tools where an
unexpected input shape could produce an invalid artifact.

## Compliance Artifact Snapshot Tests

10+ snapshot tests verify that compliance artifact generators produce
structurally stable output across code changes:

| Artifact | Generator | Snapshot Checks |
|----------|-----------|----------------|
| SSP | `ssp_generator.py` | Section count, required headers, CUI marking presence |
| POAM | `poam_generator.py` | Column schema, date format, risk level values |
| SBOM | `sbom_generator.py` | CycloneDX schema version, component structure |
| OSCAL | `oscal_generator.py` | JSON schema compliance, metadata fields |

**Lightweight approach:** Normalize-and-compare rather than byte-exact
snapshots. Timestamps, UUIDs, and volatile fields are stripped before
comparison, making tests deterministic across runs.

## SLSA Level 2 Build Provenance

`.github/workflows/slsa-build.yml` implements a GitHub Actions workflow
producing SLSA Level 2 provenance:

| SLSA Requirement | Implementation |
|-----------------|----------------|
| Source — Version controlled | GitHub repository |
| Build — Scripted build | GitHub Actions workflow |
| Provenance — Available | Sigstore cosign attestation |
| Provenance — Authenticated | Cosign keyless signing via Fulcio |
| SBOM | CycloneDX generated at build time |
| Artifact attestation | GitHub artifact attestation action |

**Air-gap note:** Sigstore signing requires network access. Air-gapped
deployments skip attestation but still produce the SBOM artifact.

## Environment Profiles

Four environment profiles in `args/environments/` configure gate thresholds,
provider availability, and security posture per deployment context:

| Profile | File | LLM Providers | Gate Strictness | Use Case |
|---------|------|---------------|----------------|----------|
| **dev** | `dev.yaml` | ollama, anthropic | Relaxed (warnings only) | Local development |
| **staging** | `staging.yaml` | ollama, anthropic | Strict (all gates enforced) | Pre-production validation |
| **production** | `production.yaml` | ollama, anthropic | Maximum thresholds | Production deployment |
| **air-gap** | `air-gap.yaml` | ollama only | Strict (no network calls) | SCIF / IL4+ environments |

Profiles follow the GOTCHA args layer pattern — behavior changes without
editing goals or tools.

## Dashboard — DevSecOps Maturity

### 6 Tabs

| Tab | Purpose | Data Source |
|-----|---------|-------------|
| Compliance Sidecar | Framework coverage heatmap | Crosswalk engine |
| Feature Flags | Module enablement status | `args/marketplace_config.yaml` |
| SLSA Provenance | Build attestation timeline | `.github/workflows/slsa-build.yml` |
| Testing Strategy | Property + snapshot test results | pytest output |
| **Output Verifier** (new) | Credential leak detection, output sanitization gate | `/api/maturity/output-verifier` |
| **Environments** (new) | Side-by-side environment profile comparison | `/api/maturity/environments` |

### Output Verifier

Scans tool outputs for credential leaks (API keys, tokens, connection strings)
before they reach logs or dashboards. Blocks on detection — defense in depth
for NIST SC-28 (Protection of Information at Rest).

### Environment Comparison

Displays all four environment profiles side-by-side, highlighting differences
in gate thresholds, provider availability, and security settings. Useful for
promotion decisions (dev -> staging -> production).

## API Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/maturity/output-verifier` | Run output verification scan |
| GET | `/api/maturity/output-verifier/stats` | Verification statistics and block history |
| GET | `/api/maturity/environments` | List environment profiles with diff |

## Files Created

### New Files (7)
- `tests/test_compliance_properties.py` — 25 property-based tests using Hypothesis across 6 test classes
- `tests/test_compliance_snapshots.py` — 10+ snapshot tests for compliance artifact output regression
- `.github/workflows/slsa-build.yml` — GitHub Actions SLSA Level 2 build provenance workflow
- `args/environments/dev.yaml` — Development environment profile
- `args/environments/staging.yaml` — Staging environment profile
- `args/environments/production.yaml` — Production environment profile
- `args/environments/air-gap.yaml` — Air-gapped environment profile

### Modified Files (2)
- `tools/dashboard/templates/devsecops_maturity.html` — Added Output Verifier and Environments tabs (6 tabs total)
- `tools/dashboard/app.py` — Added 3 API endpoints for output verifier and environment comparison

## Architecture Decisions

| ADR | Decision |
|-----|----------|
| **D-ARCH-12** | Output verification gate — scans all tool outputs for credential leaks before logging |
| **D-ARCH-13** | SLSA Level 2 provenance — Sigstore cosign + CycloneDX SBOM at build time |
| **D-ARCH-14** | Property-based testing — Hypothesis for compliance tool structural invariants |

## E2E Test Results

```
Viewports tested: 3
  - Desktop:  1920x1080 ✓
  - Tablet:    768x1024 ✓
  - Mobile:    375x812  ✓

Console errors: 0
Network 5xx errors: 0
API responses: all 200 OK

Output Verifier: credential leak detection verified (blocked test payload)
Environment Comparison: all 4 profiles rendered with diff highlighting
All 6 dashboard tabs render correctly across viewports
```

## CLI Usage

```bash
# Run property-based tests
python -m pytest tests/test_compliance_properties.py -v

# Run snapshot tests
python -m pytest tests/test_compliance_snapshots.py -v

# Run both
python -m pytest tests/test_compliance_properties.py tests/test_compliance_snapshots.py -v

# Check output verifier stats
curl http://localhost:5000/api/maturity/output-verifier/stats

# Compare environment profiles
curl http://localhost:5000/api/maturity/environments
```
