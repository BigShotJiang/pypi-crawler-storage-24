# CodeLens/Pro Innovation: L17 Ghost Intent Coverage + L18 Anti-Sycophancy Gate

**Classification:** CUI // SP-CTI
**Date:** 2026-03-12
**Status:** Implemented
**Origin:** Competitive analysis of [agentic-qe](https://github.com/proffesor-for-testing/agentic-qe) + market research

---

## Research Summary

Analyzed the Agentic QE v3 platform (1,369 TypeScript files, 13 domain bounded contexts, 18 test framework generators) and 15+ commercial competitors (Qodo, Diffblue, Mabl, Testsigma Atto 2.0, BrowserStack, Applitools, Katalon, Functionize, Meticulous, Trunk.io, Launchable, Momentic, Spur, Virtuoso QA, LambdaTest/KaneAI).

### Key Market Gaps Identified

| Capability | Market Status | ICDEV Opportunity |
|---|---|---|
| Anti-sycophancy in AI tests | **Nobody** — completely unaddressed | Very High |
| Semantic/ghost coverage gaps | Qodo partial | High |
| Compliance-integrated QE | **Nobody** | Very High (unique ICDEV advantage) |
| Cross-project pattern learning | Research only | High |
| Unified unit + E2E generation | No single platform | High |

### Decision: Build L17 + L18

Selected **L17 Ghost Intent Coverage** and **L18 Anti-Sycophancy Gate** as P0 because:
1. L18 occupies a **completely unoccupied market position** — no tool addresses hollow AI-generated tests
2. L17 goes beyond traditional coverage metrics — inspired by AQE's "Ghost Intent Coverage" but implemented deterministically
3. Both fit GOTCHA (deterministic, zero LLM tokens, air-gap safe)
4. Both plug directly into existing CodeLens Pro framework (same base class, config, scoring)

---

## L17: Ghost Intent Coverage (pro_ghost_coverage)

**File:** `tools/review_pro/lenses/ghost_coverage.py`
**Maturity tier:** Advanced+

Detects 7 categories of semantically missing test coverage that line metrics miss:

| Category | Severity | Confidence | Detection Method |
|---|---|---|---|
| Untested error handlers | tech_debt | 80 | AST: find except blocks, check test file for pytest.raises |
| Missing boundary tests | tech_debt | 70 | AST: numeric params, check test for 0/-1/empty/max values |
| Missing auth tests | **blocker** | 90 | AST: auth decorators without unauthorized access test |
| Untested branches | skippable | 60 | AST: if/elif chains with fewer tests than branches |
| Untested fallbacks | skippable | 55 | AST: else clauses without matching test |
| Missing concurrency tests | **blocker** | 85 | AST: shared mutable state without thread tests |
| Missing negative tests | tech_debt | 70 | Regex: no pytest.raises/assertRaises in test file |

**Metrics:** `ghost_coverage_score` (0-100), `total_intents`, `tested_intents`, per-category counts.

---

## L18: Anti-Sycophancy Gate (pro_anti_sycophancy)

**File:** `tools/review_pro/lenses/anti_sycophancy.py`
**Maturity tier:** Standard (always active — this is critical)

Detects 6 categories of hollow AI-generated test patterns:

| Category | Severity | Confidence | Detection Method |
|---|---|---|---|
| Assertion-free tests | **blocker** | 95 | AST: no assert statements + regex for framework assertions |
| Tautological assertions | **blocker** | 90 | Regex: 10 patterns (assert True, 1==1, is not None only, len>=0) |
| Happy-path-only bias | tech_debt | 75 | Regex: file has no negative test indicators |
| Mirror tests | tech_debt | 70 | AST: test replicates source operators (70%+ overlap) |
| Shallow mocking | tech_debt | 65 | Regex: mock count > 3, mock asserts dominate real asserts |
| Hardcoded oracles | skippable | 55 | Regex: magic numbers/long strings in assertions |

**Metrics:** `sycophancy_score` (0-100), `hollow_tests`, per-category counts.

### Smoke Test Results (against ICDEV codebase)

```
L18 Anti-Sycophancy: 35 test files, 816 tests, 111 findings
  Sycophancy score: 88.8 (Good)
  Tautological assertions found: real instances in production tests

L17 Ghost Coverage: 8 source files, 52 ghost intents detected
  Ghost coverage score: varies by match quality
```

---

## Integration

### Files Modified

| File | Change |
|---|---|
| `tools/review_pro/models_pro.py` | +2 enum values: GHOST_COVERAGE, ANTI_SYCOPHANCY |
| `tools/review_pro/models_pro.py` | Updated PRO_MATURITY_LENSES (L18→standard, L17→advanced) |
| `tools/review_pro/engine_pro.py` | +2 lens registrations in _create_pro_lenses() |
| `args/review_pro_config.yaml` | +2 lens config blocks (ghost_coverage, anti_sycophancy) |

### Files Created

| File | Purpose |
|---|---|
| `tools/review_pro/lenses/ghost_coverage.py` | L17 implementation |
| `tools/review_pro/lenses/anti_sycophancy.py` | L18 implementation |
| `docs/features/codelens-pro-innovation-l17-l18.md` | This document |

### Architecture Decisions

- **D-CLP-17:** Ghost Intent Coverage uses AST source+test cross-analysis (not line-level coverage tools)
- **D-CLP-18:** Anti-Sycophancy is standard-tier (always active) because hollow tests are always dangerous
- **D-CLP-19:** Both lenses are zero-LLM, pure deterministic (GOTCHA scanner tier)
- **D-CLP-20:** Mirror test detection uses operator-set overlap heuristic (70% threshold)

---

## Future Innovation Tracks (P1/P2)

| Track | Description | Priority |
|---|---|---|
| Compliance-Integrated QE | Map test coverage to NIST 800-53 controls | P1 |
| L19: Mutation Score | AST mutation injection + kill rate scoring | P1 |
| Cross-Project Pattern Bank | HNSW-indexed test patterns via knowledge graph | P2 |
