# CUI // SP-CTI
# Phase 70: DataBridge — Universal Data & Storage Connector

## Overview

DataBridge is a marketplace module that enables any ICDEV instance (or child app) to connect to any database, data store, cloud storage, streaming platform, SaaS API, or file source. All data flows through Apache Arrow as the universal in-memory format.

**Slug:** `databridge`
**Marketplace model:** All-in-one subscription (free tier with limits, paid tier unlocks everything)

## Architecture

### Core Stack
- **Apache Arrow** — Universal in-memory columnar format (zero-copy IPC)
- **fsspec** — Universal filesystem abstraction (S3/Azure/GCS/HDFS/local)
- **SQLAlchemy** — Database connectivity (connection pooling, type mapping)
- **DuckDB** — Embedded analytics engine (cross-source SQL JOINs)
- **Microsoft Presidio** — PII detection and anonymization (regex fallback for air-gap)

### Connector Types (22 total)

| Category | Connectors | Tier |
|----------|-----------|------|
| Database | SQLite, PostgreSQL, MySQL, MSSQL, Oracle | SQLite=Free, rest=Paid |
| Cloud Storage | Local FS, S3, Azure Blob, GCS, HDFS | Local=Free, rest=Paid |
| File Format | CSV, JSON, Parquet, Avro, Excel | CSV/JSON=Free, rest=Paid |
| Streaming | Kafka, Kinesis, CDC (PostgreSQL) | All Paid |
| SaaS API | Salesforce, ServiceNow, Jira, SAP | All Paid |

### ABC Hierarchy

```
DataConnector (ABC)
├── SQLBaseConnector → sqlite, postgresql, mysql, mssql, oracle
├── FsspecBaseConnector → local_fs, s3, azure_blob, gcs, hdfs
├── FileBaseConnector → csv, parquet, json, avro, excel
├── StreamingBaseConnector → kafka, kinesis, cdc
└── SaaSBaseConnector → salesforce, servicenow, jira, sap
```

## Key Features

### Data Mapping Engine
- Visual drag-and-drop schema mapping editor (vanilla JS + SVG)
- 16 transform functions: rename, cast, concat, split, lookup, conditional, aggregate, calculated, default, trim, upper, lower, date_format, hash, mask_pii, cui_mark
- Auto-map by column name similarity (Levenshtein distance)
- Versioned mappings with SHA-256 hashing (append-only)
- Format conversion: CSV, Parquet, JSON, Arrow IPC, Avro, Excel

### DuckDB Analytics
- SQL query editor over connected sources
- Cross-source JOINs by registering Arrow tables
- Column profiling (type, nulls, distinct, min/max/avg/stddev)
- Table profiling across all columns

### PII Detection & Anonymization
- Microsoft Presidio integration (NLP-based)
- Regex fallback for air-gap environments
- Entity types: PERSON, EMAIL, PHONE, CREDIT_CARD, SSN, IP_ADDRESS, PASSPORT
- Actions: mask, redact, encrypt (SHA-256), flag_only
- Batch scanning over data rows with column-level findings

### On-Prem Agent
- Lightweight Python daemon on customer network
- Outbound WebSocket only (firewall-friendly, no inbound ports)
- Receives sync requests, executes locally, returns Arrow IPC
- Signal handling for graceful shutdown
- SSH tunnel support for direct database access

### Data Quality Profiling
- Per-column statistics: type inference, nulls, distinct, min/max/avg/stddev
- Top-N value frequency analysis
- Quality score per column (0-100)

## Database Tables (11)

| Table | Purpose |
|-------|---------|
| `db_connections` | Connection registry with encrypted config |
| `db_schemas` | Versioned schema snapshots |
| `db_sync_log` | Append-only sync audit trail |
| `db_connector_configs` | Connector type registry |
| `db_storage_paths` | Logical storage path mappings |
| `db_mappings` | Versioned schema crosswalks |
| `db_mapping_log` | Append-only mapping execution log |
| `db_lookup_tables` | Transform lookup tables |
| `db_streams` | Active streaming subscriptions |
| `db_oauth_tokens` | OAuth token cache (references only) |
| `db_agents` | On-prem agent registry |

## Dashboard Pages

| Route | Page |
|-------|------|
| `/databridge` | Main dashboard — stats, connections, connector catalog |
| `/databridge/mapping` | Visual schema mapping editor |
| `/databridge/analytics` | DuckDB SQL editor, PII scanner, data profiler |

## API Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/databridge/connections` | List connections |
| POST | `/api/databridge/connections` | Create connection |
| POST | `/api/databridge/connections/<id>/test` | Test connection health |
| GET | `/api/databridge/connections/<id>/schema` | Get connection schemas |
| GET | `/api/databridge/connectors` | List available connectors |
| GET | `/api/databridge/mappings` | List mappings |
| POST | `/api/databridge/mappings` | Create mapping |
| POST | `/api/databridge/mappings/<id>/execute` | Execute mapping |
| POST | `/api/databridge/mappings/suggest` | Auto-suggest mappings |
| GET | `/api/databridge/transforms` | List available transforms |
| POST | `/api/databridge/convert` | Format conversion |
| POST | `/api/databridge/query` | Execute DuckDB SQL |
| POST | `/api/databridge/pii/scan` | Scan text for PII |
| POST | `/api/databridge/profile` | Profile data quality |

## Marketplace Pricing

| Tier | Price | Limits |
|------|-------|--------|
| Free | $0 | 3 connectors (SQLite, CSV, JSON), 5 mappings max, no streaming/on-prem |
| Trial | 30 days | All features |
| Monthly | $199/mo | All 22 connectors, unlimited mappings, streaming, on-prem agent |
| Annual | $1,990/yr | Same as monthly (save 17%) |
| Gov PO | Custom | Enterprise support, FIPS 140-3, dedicated relay |

## Files Created (45 Python files)

```
tools/databridge/
├── __init__.py
├── connector.py              # ABC + types + enums
├── connection_manager.py     # CRUD + secret resolution
├── schema_engine.py          # Inference + versioning
├── arrow_pipeline.py         # Arrow transform pipeline
├── sync_engine.py            # Sync orchestrator
├── registry.py               # Connector discovery (@register_connector)
├── mapping_engine.py         # Schema crosswalks
├── transforms.py             # 16 transform functions
├── format_converter.py       # Format conversion via Arrow
├── stream_manager.py         # Background stream manager
├── analytics.py              # DuckDB engine
├── pii_detector.py           # Presidio PII detection
├── data_profiler.py          # Data quality profiling
├── relay_server.py           # Cloud WebSocket relay
├── connectors/
│   ├── __init__.py
│   ├── sql_base.py           # SQLAlchemy base
│   ├── postgresql.py
│   ├── mysql.py
│   ├── sqlite_connector.py
│   ├── mssql.py
│   ├── oracle.py
│   ├── fsspec_base.py        # fsspec base
│   ├── s3.py
│   ├── azure_blob.py
│   ├── gcs.py
│   ├── hdfs.py
│   ├── local_fs.py
│   ├── csv_connector.py
│   ├── parquet_connector.py
│   ├── json_connector.py
│   ├── avro_connector.py
│   ├── excel_connector.py
│   ├── kafka_connector.py
│   ├── kinesis_connector.py
│   ├── cdc_connector.py
│   ├── saas_base.py
│   ├── salesforce.py
│   ├── servicenow.py
│   ├── jira_connector.py
│   └── sap.py
├── agent/
│   ├── __init__.py
│   ├── daemon.py             # On-prem agent daemon
│   ├── ws_relay.py           # WebSocket client
│   └── tunnel.py             # SSH tunnel manager

args/databridge_config.yaml
goals/databridge.md

tools/dashboard/templates/
├── databridge.html           # Main dashboard
├── databridge_mapping.html   # Visual mapping editor
└── databridge_analytics.html # DuckDB + PII scanner
```

## Design Decisions

| ID | Decision |
|----|----------|
| D-DB-1 | Independent `tools/databridge/` directory (marketplace portability) |
| D-DB-2 | ABC `DataConnector` base + concrete implementations |
| D-DB-3 | Apache Arrow as universal in-memory format |
| D-DB-4 | fsspec as universal filesystem abstraction |
| D-DB-5 | DuckDB as local analytics engine |
| D-DB-6 | All sync ops append-only in `db_sync_log` |
| D-DB-7 | Schema mappings versioned with SHA-256 hash |
| D-DB-8 | CUI field-level marking conditional on impact_level |
| D-DB-9 | Microsoft Presidio for PII detection |
| D-DB-10 | On-prem agent uses outbound WebSocket only |
| D-DB-11 | Free: 3 connectors, no streaming/on-prem. Paid: all |
| D-DB-13 | Secrets stored as references (`env:VAR`, `secret:name`), never plaintext |
| D-DB-18 | Graceful optional imports for heavy deps (air-gap safe) |
| D-DB-19 | Visual drag-and-drop mapping in vanilla JS + SVG |

## Compliance

- All tables include `classification` column
- Sync logs and mapping logs are append-only (NIST AU)
- CUI markings auto-applied at IL4+ via `transform_cui_mark()`
- PII detection satisfies SP 800-122 PII handling requirements
- FIPS 140-3 TLS optional at IL4+ via config flag
