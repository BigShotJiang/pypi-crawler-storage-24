# Phase 66: Marketplace Commerce Extension
CUI // SP-CTI

## Overview

Extends Phase 37 marketplace with billing, licensing, and module runtime integration.
Enables free and paid module subscriptions (Stripe + Gov PO), RSA-signed license tokens
with 30-day offline grace, and a Jinja2 context processor for conditional template blocks.

First integration: WriteGuard "Analyze Writing" button on GovProposal section editor,
visible only when the writeguard module is enabled.

## Architecture Decisions

- **D-MKT-C1:** Separate RSA-4096 key pair for module licenses
- **D-MKT-C2:** Reuses license_validator.py canonical JSON + RSA-SHA256 pattern
- **D-MKT-C3:** UNIQUE(asset_id, tenant_id, user_id) at application layer
- **D-MKT-C4:** Process-local cache, 60s TTL for `is_module_enabled()`
- **D-MKT-C5:** marketplace_invoices is append-only (NIST AU)
- **D-MKT-C6:** marketplace_licenses status transitions only (effectively append-only)
- **D-MKT-C7:** Stripe is optional dependency (air-gap safe)
- **D-MKT-C8:** Pre-coded `{% if module_enabled('slug') %}` conditionals (no XSS)
- **D-MKT-C9:** Gov PO approval requires CO or admin role
- **D-MKT-C10:** Free modules: no expiry, no payment, instant activation

## New DB Tables (5)

| Table | Purpose |
|-------|---------|
| marketplace_pricing | Per-asset pricing tiers (free, monthly, annual, po_only) |
| marketplace_subscriptions | Active subscriptions with status lifecycle |
| marketplace_invoices | Payment history (append-only) |
| marketplace_payment_methods | Stripe customer IDs + gov PO refs |
| marketplace_licenses | RSA-signed license tokens per subscription |

## New Python Tools (6)

| File | LOC | Purpose |
|------|-----|---------|
| tools/marketplace/license_manager.py | ~340 | RSA sign/verify, is_module_active, issue/revoke |
| tools/marketplace/subscription_manager.py | ~300 | Create/activate/cancel subscriptions, invoicing |
| tools/marketplace/stripe_billing.py | ~220 | Stripe Checkout, Billing Portal, webhooks |
| tools/marketplace/gov_po_processor.py | ~230 | PO submission, CO approval workflow |
| tools/marketplace/module_runtime.py | ~160 | Flask context processor, cache, @require_module |
| tools/marketplace/renewal_scheduler.py | ~170 | Background phone-home, license expiry |

## Dashboard Routes

| Route | Method | Purpose |
|-------|--------|---------|
| /marketplace | GET | Browse modules, enable/subscribe |
| /marketplace/subscriptions | GET | Manage subscriptions, view invoices |
| /marketplace/po-queue | GET | PO approval queue (CO/admin) |
| /api/marketplace/enable | POST | Enable free module |
| /api/marketplace/subscribe | POST | Start paid subscription |
| /api/marketplace/cancel | POST | Cancel subscription |
| /api/marketplace/po/submit | POST | Submit gov purchase order |
| /api/marketplace/po/approve | POST | CO approves PO |
| /webhooks/stripe | POST | Stripe webhook handler |
| /proposals/<opp>/sections/<sec> | GET | Section editor with WriteGuard |

## Test Coverage

- 42 unit tests in tests/test_marketplace_commerce.py
- License signing, verification, tampering detection
- Free and paid subscription lifecycle
- Module runtime cache + invalidation
- Gov PO submit/approve/reject flow
- Grace period and expiry logic
- Stripe unavailable handling
- End-to-end free enable + paid PO flows

## Verification

1. Free enable: Click Enable -> subscription active -> license issued -> module_enabled returns True
2. Section editor: "Analyze Writing" button visible when writeguard enabled
3. Grace period: Token expired but within 30-day grace -> still active
4. Air-gap: HAS_STRIPE=False -> PO flow still works
5. All 234 tests pass (192 existing + 42 new)
