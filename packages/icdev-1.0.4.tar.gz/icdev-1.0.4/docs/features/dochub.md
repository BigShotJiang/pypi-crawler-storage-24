# CUI // SP-CTI
# DocHub — Living Documentation Engine

## Overview

DocHub is a living documentation engine that auto-generates role-specific, multi-format documentation for ICDEV, its marketplace modules, child apps, and third-party (BYOS) applications. Documents regenerate from live database and code state with a single click. The engine supports 8 audience profiles, 12 document templates, 8 export formats, module-level provenance tracking, cross-app dependency impact analysis, portfolio health scoring, and research enrichment from CVE/regulatory feeds.

**Classification:** CUI // SP-CTI
**Impact Level:** IL4
**Database:** `data/icdev.db` (12 `dh_` prefixed tables)

## Architecture

### Python Modules (9 files in `tools/dochub/`)

| Module | Purpose |
|--------|---------|
| `data_collector.py` | Aggregates project data from compliance, security, scorecard, DORA, SbD, and AI security tables into a unified snapshot |
| `profile_engine.py` | Loads and applies role-specific audience profiles with terminology mapping and section filtering |
| `doc_generator.py` | Core generation engine: pulls data, loads templates, applies profiles, renders documents, stores versions |
| `export_engine.py` | Multi-format export: Markdown, HTML, PDF-ready, OSCAL JSON, Xacta CSV, FedRAMP ZIP, DoD IL package, eMASS CSV |
| `tenant_manager.py` | Multi-tenant application and module registry, dependency graph, cross-app impact analysis |
| `health_scorer.py` | Weighted composite health scoring (freshness, completeness, gaps) with portfolio aggregation |
| `byos_scanner.py` | Bring-Your-Own-Software scanner: analyzes external codebases for languages, frameworks, dependencies, security findings |
| `diff_engine.py` | Section-level document diffing with changelog generation across versions |
| `enrichment_engine.py` | Research enrichment: CVE feed correlation, regulatory updates, cached with configurable TTL |

### Template and Profile Locations

- **Templates:** `context/dochub/templates/` (GOTCHA context layer)
- **Profiles:** `context/dochub/profiles/` (GOTCHA context layer, JSON format)
- **Export format configs:** `context/dochub/export_formats/`

## Document Templates (12)

| Template | File | Purpose |
|----------|------|---------|
| System Security Plan | `ssp_template.md` | NIST 800-53 / FedRAMP SSP with control implementations |
| System Design Document | `sdd_template.md` | Technical architecture and design |
| POA&M | `poam_template.md` | Plan of Action and Milestones for open findings |
| Threat Model | `threat_model_template.md` | STRIDE threat analysis with NIST mapping |
| SBOM Summary | `sbom_summary_template.md` | Software Bill of Materials overview |
| ConOps | `conops_template.md` | Concept of Operations |
| Security Assessment Report | `sar_template.md` | 3PAO assessment findings |
| Security Controls Traceability Matrix | `sctm_template.md` | Control-to-requirement mapping |
| Project Management Plan | `pmp_template.md` | Project planning and governance |
| Security Posture | `security_posture_template.md` | Current security posture summary |
| Developer Guide | `dev_guide_template.md` | Developer onboarding and implementation guide |
| Audit Report | `audit_report_template.md` | Audit trail and compliance audit findings |

Templates use `{{variable}}` substitution syntax. Data is injected from the data collector snapshot at generation time.

## Audience Profiles (8)

| Profile ID | Name | Terminology Set | Document Types |
|------------|------|-----------------|----------------|
| `3pao` | 3PAO Assessor | FedRAMP | SSP, POA&M, STIG, SBOM, ATO Package |
| `ciso` | CISO / Security Executive | Security | Scorecard, Threat Model, SSP |
| `developer` | Developer / Engineer | Technical | Scorecard, SBOM, STIG |
| `executive` | Executive / Program Manager | Management | Scorecard, SSP |
| `acquisition` | Contracting / Acquisition Officer | Acquisition | SSP, POA&M, SBOM, ATO Package |
| `full` | Full Detail (No Filtering) | NIST | All document types |
| `isso` | ISSO | NIST | Compliance-focused document set |
| `auditor` | Auditor | FedRAMP | Audit-focused document set |

Each profile controls:
- **Section inclusion/exclusion** -- which document sections appear
- **Detail level** -- full, standard, or summary
- **Terminology mapping** -- swaps terms for audience context (e.g., "control" vs "safeguard" vs "security requirement")

### Terminology Sets

| Set | Example Term Mappings |
|-----|----------------------|
| FedRAMP | control implementation statement, authorization to operate, authorization boundary |
| NIST | control implementation, authorization, system boundary |
| Technical | implementation, approval, system boundary |
| Security | safeguard implementation, risk acceptance, trust boundary |
| Management | governance control, executive approval, system scope |
| Acquisition | contract requirement, procurement approval, system scope |

## Export Formats (8)

| Format | Extension | Description |
|--------|-----------|-------------|
| Markdown | `.md` | Native DocHub format, raw Markdown |
| HTML | `.html` | Styled HTML with CUI classification banners |
| PDF-ready | `.html` | Print-optimized HTML for PDF generation |
| OSCAL JSON | `.json` | NIST OSCAL 1.1.2 assessment-results JSON |
| Xacta CSV | `.csv` | Xacta 360 CSV import format |
| FedRAMP ZIP | `.zip` | FedRAMP Rev 5 authorization package ZIP |
| DoD IL Package | `.zip` | DoD Impact Level package ZIP (IL2/IL4/IL5) |
| eMASS CSV | `.csv` | eMASS bulk import CSV |

Export delegates to existing ICDEV tools where possible (e.g., `oscal_generator.py`, `xacta_export`, `emass_export`).

## Multi-Tenant Support

DocHub supports multiple applications via the tenant manager:

- **Register applications:** ICDEV itself, child apps, BYOS third-party apps
- **Register modules:** Marketplace modules tracked per application (e.g., WriteGuard, DataBridge)
- **Dependency graph:** Adjacency list tracking inter-app and inter-module dependencies
- **Impact analysis:** Query which apps/modules are affected by a dependency change (e.g., a library CVE)
- **Portfolio health:** Aggregate health scores across all registered applications, weighted by criticality

### Database Tables (12)

| Table | Purpose |
|-------|---------|
| `dh_documents` | Generated documents with versioning and content hash |
| `dh_generation_runs` | Document generation run log |
| `dh_document_diffs` | Section-level diff records between versions |
| `dh_health_scores` | Per-app health score history |
| `dh_byos_scans` | BYOS scanner results |
| `dh_enrichment_cache` | CVE/regulatory enrichment cache with TTL |
| `dh_tenant_apps` | Registered applications |
| `dh_modules` | Registered modules per app |
| `dh_module_provenance` | Module origin tracking (origin project, version, drift status) |
| `dh_imported_artifacts` | Imported vendor artifacts (SPDX, CycloneDX, PDF, OSCAL) |
| `dh_dependency_graph` | Adjacency list for inter-app/module dependencies |
| `dh_portfolio_scores` | Portfolio-level aggregate scores |

All `dh_` tables are **append-only** (new version = new row, status change on old row) per NIST AU compliance.

## Module Provenance

Each marketplace module registered in DocHub tracks provenance metadata:

- **origin_project:** Which app/org the module originated from
- **origin_version:** Version at time of installation
- **current_version:** Currently deployed version
- **drift_status:** Whether the module has drifted from its origin (clean, drifted, unknown)

Modules without provenance are treated as locally-created (no drift check).

## Health Scoring

Health scores use a weighted composite formula:

| Dimension | Weight | Description |
|-----------|--------|-------------|
| Freshness | 0.35 | How recently documents were generated (current <= 30d, stale <= 90d, expired > 90d) |
| Completeness | 0.40 | Coverage of expected document types for the app's profile |
| Gaps | 0.25 | Inverse of missing/incomplete sections across documents |

**Grade scale:** A (90-100), B (80-89), C (70-79), D (60-69), F (< 60)

**Portfolio aggregate:** Weighted average across all registered apps, weighted by app criticality level.

## BYOS Scanner

The Bring-Your-Own-Software scanner analyzes third-party codebases without requiring them to be ICDEV projects:

- **Language detection:** Identifies programming languages from file extensions and content
- **Framework detection:** Recognizes common frameworks (Flask, Django, React, Spring, etc.)
- **Dependency extraction:** Parses package manifests (requirements.txt, package.json, Cargo.toml, etc.)
- **Security findings:** Reuses detection patterns from `sbom_generator.py` and `code_analyzer.py`
- **Code metrics:** Lines of code, file counts, complexity indicators

Modes:
- **Scan-only:** Returns JSON to stdout, no database writes (works without DB)
- **Scan + Store:** Persists results to `dh_byos_scans` table
- **Scan + Store + Generate:** Automatically generates documentation for the scanned app
- **Import artifact:** Import vendor-provided SBOMs, security reports, or compliance artifacts

Directory walk skips: `.git`, `node_modules`, `__pycache__`, `venv`, `dist`

## Enrichment Engine

Research enrichment correlates project data with external intelligence:

- **CVE correlation:** Checks project dependencies against known CVE feeds
- **Regulatory updates:** Monitors for framework changes (NIST, FedRAMP, CMMC revisions)
- **Enrichment cache:** Results cached with configurable TTL to reduce external calls
- **Air-gap mode:** Graceful degradation -- enrichment disabled, all generation remains scanner-tier only

## Dashboard Integration

**Route:** `/dochub`
**Template:** `tools/dashboard/templates/dochub.html`

### Dashboard Tabs (10)

| Tab | Content |
|-----|---------|
| Overview | Stat cards, recent documents table, portfolio summary, Regenerate All button |
| Documents | Filtered document list, Generate Document form |
| Modules | Registered modules table, Register Module form |
| BYOS Scanner | Scan external projects, import vendor artifacts |
| Profiles | Available audience profiles with terminology details |
| Export | Multi-format export with format selector |
| Health | Health score breakdown with grade indicator |
| Changelog | Section-level diff history across document versions |
| Apps | Registered applications table, Register App form |
| Impact Analysis | Dependency impact analysis across all tenants |

### API Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/dochub/overview` | Overview stats and recent documents |
| GET | `/api/dochub/documents` | List documents with filters |
| POST | `/api/dochub/generate` | Generate a document |
| POST | `/api/dochub/regenerate-all` | Regenerate all documents for an app |
| GET | `/api/dochub/modules` | List registered modules |
| POST | `/api/dochub/modules` | Register a module |
| GET | `/api/dochub/profiles` | List audience profiles |
| POST | `/api/dochub/export` | Export a document in specified format |
| GET | `/api/dochub/health` | Compute and return health score |
| GET | `/api/dochub/changelog` | Get document changelog/diffs |
| GET | `/api/dochub/apps` | List registered applications |
| POST | `/api/dochub/apps` | Register an application |
| POST | `/api/dochub/impact` | Run cross-app impact analysis |
| POST | `/api/dochub/byos/scan` | Scan an external project |
| POST | `/api/dochub/byos/import` | Import a vendor artifact |
| POST | `/api/dochub/enrich` | Run research enrichment |
| GET | `/api/dochub/portfolio` | Portfolio-level health summary |

## CLI Commands

```bash
# Register application and modules
python tools/dochub/tenant_manager.py --register --project-id "sparkpilot" --name "SparkPilot" --app-type icdev --json
python tools/dochub/tenant_manager.py --register-module --project-id "sparkpilot" --module-name "WriteGuard" --module-slug writeguard --json

# Collect data snapshot
python tools/dochub/data_collector.py --project-id "sparkpilot" --collect --json

# Generate documents
python tools/dochub/doc_generator.py --project-id "sparkpilot" --doc-type ssp --profile 3pao --impact-level IL4 --json
python tools/dochub/doc_generator.py --project-id "sparkpilot" --generate-all --profile compliance --json
python tools/dochub/doc_generator.py --regenerate --doc-id "dh-doc-xxx" --json

# Health scoring
python tools/dochub/health_scorer.py --project-id "sparkpilot" --compute --json
python tools/dochub/health_scorer.py --portfolio --json

# Export
python tools/dochub/export_engine.py --doc-id "dh-doc-xxx" --format html --json
python tools/dochub/export_engine.py --project-id "sparkpilot" --format fedramp_zip --output ./exports --json
python tools/dochub/export_engine.py --project-id "sparkpilot" --format dod_pkg --impact-level IL4 --output ./exports --json
python tools/dochub/export_engine.py --list-formats --json

# Changelog
python tools/dochub/diff_engine.py --doc-id "dh-doc-xxx" --latest --json
python tools/dochub/diff_engine.py --project-id "sparkpilot" --summary --json

# BYOS scanner
python tools/dochub/byos_scanner.py --project-dir /path/to/external/app --scan --json
python tools/dochub/byos_scanner.py --project-dir /path --scan --store --generate --json
python tools/dochub/byos_scanner.py --import-artifact --file /path/to/vendor-sbom.json --artifact-type sbom --project-id byos-001 --json

# Research enrichment
python tools/dochub/enrichment_engine.py --project-id "sparkpilot" --enrich --json
python tools/dochub/enrichment_engine.py --project-id "sparkpilot" --check-cves --json

# Impact analysis
python tools/dochub/tenant_manager.py --impact-analysis --target-id "requests" --target-type dependency --json

# Profiles
python tools/dochub/profile_engine.py --list --json
python tools/dochub/profile_engine.py --profile 3pao --json
```

## Design Decisions

| ID | Decision |
|----|----------|
| D-DH-1 | Scanner-tier deterministic generation (zero Claude tokens). Templates + data aggregation only. Optional LLM enhancement via two-tier router |
| D-DH-2 | Document versions use monotonic integer (1, 2, 3...) with SHA-256 content hash for integrity |
| D-DH-3 | Section-level diffing (not line-level) -- aligns with structured document templates |
| D-DH-4 | Health score uses weighted composite: freshness=0.35, completeness=0.40, gaps=0.25 (same pattern as D-INV-29 scorecard) |
| D-DH-5 | BYOS scanner reuses existing detection patterns from sbom_generator.py and code_analyzer.py |
| D-DH-6 | Enrichment cache with configurable TTL -- graceful degradation in air-gapped mode |
| D-DH-7 | Multi-tenant via tenant_id column -- future-proofed for multi-org without schema change |
| D-DH-8 | Export delegates to existing tools (oscal_generator, xacta_export, emass_export) where possible |
| D-DH-9 | All dh_ tables are append-only (new version = new row, status change on old row) -- NIST AU compliant |
| D-DH-10 | Profile definitions are JSON in context/ (GOTCHA context layer), not hardcoded in tools |
| D-DH-11 | Module-level docs with independent health scores, rolling up to parent app |
| D-DH-12 | Portfolio aggregate uses weighted average by app criticality |
| D-DH-13 | Imported artifacts stored as-is with format detection (SPDX, CycloneDX, PDF, OSCAL) |
| D-DH-14 | Provenance tracks origin_project, origin_version, current_version, drift_status |
| D-DH-15 | Dependency graph uses adjacency list (matches D27 pattern) |

## Compliance

- All generated documents include `CUI // SP-CTI` classification marking
- All `dh_` tables include `classification` column
- Document storage and diffs are append-only (NIST 800-53 AU controls)
- Export formats support FedRAMP, DoD IL, and eMASS regulatory requirements
- BYOS scanner enables compliance documentation for third-party software
- Health scoring enforces documentation freshness thresholds aligned with cATO evidence requirements

## Edge Cases

- Missing source data returns graceful defaults (empty sections, not errors)
- Air-gapped mode: enrichment disabled, all generation scanner-tier only
- BYOS without DB: scan-only mode returns JSON to stdout, no DB writes
- Module without provenance: treated as locally-created (no drift check)
- Empty project (no controls/findings): generates template with placeholder sections
- Large BYOS projects: directory walk skips .git, node_modules, __pycache__, venv, dist
