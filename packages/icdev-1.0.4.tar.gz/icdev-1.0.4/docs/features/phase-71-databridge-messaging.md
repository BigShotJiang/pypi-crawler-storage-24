# CUI // SP-CTI
# Phase 71-77: DataBridge Messaging Hub — Universal Connectivity

## Overview

Expands DataBridge from 22 connectors into a **45-connector universal connectivity hub** with bi-directional messaging, email, CRM/ERP, DevOps, and observability integrations. All connectors are paid tier (bundled in DataBridge subscription).

## Architecture

### New Connector Categories

| Category | Count | Connectors |
|----------|-------|------------|
| Messaging | 8 | Telegram, Slack, Discord, Teams, Mattermost, WhatsApp, Signal, Matrix |
| Email | 4 | IMAP, SMTP, Gmail, Microsoft 365 Mail |
| CRM/ERP | 3 | HubSpot, Dynamics 365, NetSuite |
| DevOps | 4 | GitHub, GitLab, Jenkins, ArgoCD |
| Observability | 4 | Splunk, Datadog, Elasticsearch, PagerDuty |
| **Total New** | **23** | |
| **Grand Total** | **45** | 22 original + 23 new |

### Infrastructure Components

| Component | File | Purpose |
|-----------|------|---------|
| MessageEnvelope | `tools/databridge/messaging/message_envelope.py` | Normalized message dataclass across all platforms |
| MessagingBaseConnector | `tools/databridge/connectors/messaging_base.py` | Abstract base for messaging connectors |
| EmailBaseConnector | `tools/databridge/connectors/email_base.py` | Abstract base for email connectors |
| Messaging Daemon | `tools/databridge/messaging/messaging_daemon.py` | Persistent connection manager (separate process) |
| Agent Bridge | `tools/databridge/messaging/agent_bridge.py` | Routes messages to ICDEV agents via A2A JSON-RPC |
| OAuth2 Manager | `tools/databridge/messaging/oauth2_manager.py` | OAuth2 PKCE flow for 8 platforms |
| Message Logger | `tools/databridge/messaging/message_logger.py` | Append-only logging with PII auto-scan |

### Database Tables (3 new)

| Table | Purpose |
|-------|---------|
| `db_messages` | Append-only message log with PII status (NIST AU compliant) |
| `db_message_routing` | Per-channel agent routing overrides |
| `db_messaging_daemon_state` | Daemon worker thread tracking |

### Connection Modes

| Mode | Connectors | Implementation |
|------|------------|----------------|
| WebSocket | Slack (Socket Mode), Discord (Gateway), Mattermost | Persistent WS connection |
| Long Poll | Telegram (getUpdates), Signal (signal-cli), Matrix (/sync) | Periodic HTTP polling |
| Webhook Only | WhatsApp (Meta callback), Teams (Bot Framework) | Flask webhook routes |

### Webhook Endpoints

| Endpoint | Platform |
|----------|----------|
| `POST /api/databridge/webhooks/telegram` | Telegram Bot API |
| `POST /api/databridge/webhooks/slack` | Slack Events API |
| `POST /api/databridge/webhooks/discord` | Discord Interactions |
| `POST /api/databridge/webhooks/whatsapp` | WhatsApp Cloud API |
| `POST /api/databridge/webhooks/teams` | MS Teams Bot Framework |
| `POST /api/databridge/webhooks/mattermost` | Mattermost Outgoing |
| `POST /api/databridge/webhooks/generic` | Generic JSON payload |

### OAuth2 Platforms

Slack, Discord, Teams, Gmail, O365, GitHub, GitLab, HubSpot — all with PKCE.

## Message Lifecycle

```
Platform → Webhook/Daemon → MessageEnvelope → MessageLogger (PII scan) → db_messages
  → AgentBridge → Orchestrator (or per-channel override) → Agent response
  → connector.send_message() → Platform
```

## Design Decisions

- D-DB-21: 5 new ConnectorType enums (MESSAGING, EMAIL, CRM_ERP, DEVOPS, OBSERVABILITY)
- D-DB-22: MessagingBaseConnector with bi-directional messaging contract
- D-DB-23: Messaging daemon as separate process with worker threads
- D-DB-24: Webhook receiver integrated into Flask dashboard
- D-DB-25: Agent bridge defaults to Orchestrator with per-channel overrides
- D-DB-26: db_messages append-only with PII auto-scan (NIST AU compliant)
- D-DB-27: OAuth2 PKCE for platforms requiring browser flow
- D-DB-28: MessageEnvelope normalizes all platforms
- D-DB-29: All 23 connectors are paid tier
- D-DB-30: Daemon ↔ Dashboard communicate via shared SQLite

## Dashboard

Messaging Hub page at `/databridge/messaging` with 4 tabs:
1. **Connected Channels** — active messaging/integration connections
2. **Message Feed** — recent messages with platform/direction filters
3. **Agent Routing** — per-channel routing rule management
4. **Connect Platform** — OAuth2 connect buttons + connector category overview

## Verification

- 45 connectors registered and seeded in db_connector_configs
- All files compile clean (`py_compile`)
- Dashboard returns 200 on `/databridge/messaging`
- All 4 messaging API endpoints return 200
- Playwright E2E: 12 screenshots (4 pages × 3 viewports), 0 console errors
- db_messages is append-only (no UPDATE/DELETE)
