# Phase 65: WriteGuard — AI Writing Assistant

| Field | Value |
|-------|-------|
| Phase | 65 |
| Status | Complete |
| Date | 2026-03-04 |
| ADRs | D-WG-1 through D-WG-14 |

## Problem

No FedRAMP-authorized writing assistant exists. Grammarly is cloud-only, not CUI-aware, banned by NASA, and cannot operate in air-gapped IL5/IL6 environments. Government proposal writers lack tools that address CUI marking compliance, RFP shall-statement coverage, win theme threading, cross-volume consistency, and Plain Writing Act scoring.

## Solution

WriteGuard is a Grammarly-like writing assistant that runs fully air-gapped via local Ollama models, integrates with ICDEV's existing RAG/LLM/marketplace infrastructure, and adds GovProposal-specific features.

## Goals

- General-purpose + gov-specific tone profiles
- Fully air-gapped (Ollama only, deterministic-first)
- Real-time inline + batch document review
- Per-tenant style guides with ISSO-lockable rules (5-layer cascade)
- CUI/classification-aware rules
- Plagiarism detection (internal corpus via RAG)
- AI-generated content detection (statistical)
- Snippet/template management
- GovProposal integration (shall-compliance, win themes, cross-volume consistency)
- Marketplace asset packaging

## Architecture

### Two-Tier Routing

| Function | Tier | Method |
|---|---|---|
| Grammar check | Deterministic | Regex rules |
| Readability score | Deterministic | Flesch-Kincaid, Gunning Fog, SMOG |
| AI content detection | Deterministic | Perplexity, burstiness, n-gram stats |
| Tone profiler | Scanner (qwen3) | Keyword + LLM classification |
| Coherence analyzer | Worker (qwen3 → Claude) | Cross-paragraph flow analysis |
| Rewriter | Worker (qwen3 → Claude) | Text improvement |
| Plagiarism check | Deterministic (RAG) | Vector similarity search |
| Style enforcer | Deterministic | Rule evaluation against cascade |

### Style Guide 5-Layer Cascade

Platform → Tenant → Program → Project → User. ISSO-lockable dimensions prevent downstream overrides on compliance-critical rules.

### GovProposal Bridge (D-WG-8)

Read-only bridge to proposal tables. Never writes to govcon tables. Provides:
- `check_shall_compliance()` — RFP shall-statement coverage checking
- `validate_win_themes()` — Win theme presence in drafts
- `check_cross_volume_consistency()` — Cross-volume numerical contradiction detection

## Database Tables (6 new)

| Table | Purpose |
|-------|---------|
| `wg_style_guides` | 5-layer cascade, version-immutable (composite PK: id, version) |
| `wg_style_guide_locks` | ISSO-lockable dimensions |
| `wg_analysis_results` | Append-only analysis runs (D6) |
| `wg_analysis_findings` | Individual findings (D6) |
| `wg_snippets` | Reusable writing templates |
| `wg_batch_runs` | Batch analysis sessions |

## Files (14 tools)

| File | Purpose | LOC |
|------|---------|-----|
| `tools/writing/analysis_engine.py` | Core orchestrator | ~400 |
| `tools/writing/grammar_checker.py` | Regex grammar rules | ~300 |
| `tools/writing/readability_scorer.py` | 5 readability formulas | ~200 |
| `tools/writing/tone_profiler.py` | Keyword + scanner | ~250 |
| `tools/writing/style_enforcer.py` | Style guide rule evaluation | ~350 |
| `tools/writing/coherence_analyzer.py` | Paragraph flow analysis | ~250 |
| `tools/writing/plagiarism_detector.py` | RAG similarity wrapper | ~200 |
| `tools/writing/ai_content_detector.py` | Statistical AI detection | ~300 |
| `tools/writing/rewriter.py` | LLM-assisted rewrite | ~200 |
| `tools/writing/snippet_manager.py` | CRUD + search | ~300 |
| `tools/writing/style_guide_manager.py` | 5-layer cascade | ~450 |
| `tools/writing/batch_analyzer.py` | Multi-doc batch mode | ~300 |
| `tools/writing/govcon_bridge.py` | GovProposal integration | ~350 |
| `tools/writing/signal_registrar.py` | Innovation Engine bridge | ~150 |

## Configuration

- `args/writeguard_config.yaml` — WriteGuard configuration
- `context/writing/style_guides/*.yaml` — 5 default style guides (government, technical, business, academic, proposal)
- `context/writing/grammar_rules/common_errors.json` — 30+ regex grammar patterns
- `context/writing/grammar_rules/govcon_vocabulary.json` — FAR/DFARS/NIST terms

## Dashboard

- `/writeguard` — Main writing assistant page with stat grid, analyze/rewrite panel, findings display, recent analyses

## Testing

```bash
pytest tests/test_writeguard_*.py -v    # 192 tests across 8 files
```

| Test File | Tests | Coverage |
|-----------|-------|----------|
| `test_writeguard_grammar.py` | ~30 | Grammar pattern detection |
| `test_writeguard_readability.py` | ~20 | Readability scoring accuracy |
| `test_writeguard_style.py` | ~35 | Style guide cascade, locks, versioning |
| `test_writeguard_ai_detect.py` | ~25 | AI content detection |
| `test_writeguard_plagiarism.py` | ~20 | Tone, coherence, rewriter |
| `test_writeguard_engine.py` | ~30 | Full analysis pipeline |
| `test_writeguard_govcon.py` | ~25 | GovProposal bridge, batch, signals |
| `test_writeguard_snippets.py` | ~20 | Snippet CRUD |

## Security

- `writeguard` security gate in `args/security_gates.yaml`
- Blocking: `cui_marking_violations_in_production`, `classification_vocabulary_leak`
- Warning: `readability_grade_above_14`, `passive_voice_above_40_pct`, `quality_score_below_threshold`
- Append-only tables: `wg_analysis_results`, `wg_analysis_findings`

## ADRs

| ADR | Decision |
|-----|----------|
| D-WG-1 | Independent `tools/writing/` for marketplace portability |
| D-WG-2 | Deterministic-first pipeline (regex before LLM) |
| D-WG-3 | 5-layer cascade with ISSO locks |
| D-WG-4 | Inline + batch modes (same engine) |
| D-WG-5 | Plagiarism via RAG similarity (0.85 threshold) |
| D-WG-6 | AI detection is deterministic (advisory-only) |
| D-WG-7 | Snippets follow knowledge_base.py pattern |
| D-WG-8 | GovProposal via bridge, not coupling |
| D-WG-9 | Append-only results (NIST AU compliant) |
| D-WG-10 | 3 marketplace assets |
| D-WG-11 | RAG source registration |
| D-WG-12 | Two-tier routing per function |
| D-WG-13 | CUI-aware rules engine |
| D-WG-14 | Innovation signal registration |
