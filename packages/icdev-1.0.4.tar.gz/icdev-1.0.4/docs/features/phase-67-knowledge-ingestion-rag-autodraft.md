# CUI // SP-CTI
# Phase 67: Knowledge Ingestion & RAG-Assisted Auto-Draft

## Overview

Phase 67 bridges the gap between document extraction and knowledge base storage,
and adds RAG-assisted auto-draft generation for proposal sections. Old RFP
responses (PDF, DOCX, TXT) can now be uploaded, chunked, classified, and stored
as reusable knowledge blocks. When drafting a new proposal section, the system
searches the knowledge base, retrieves relevant blocks, and generates a draft
using the LLM router (with fine-tuned model support via D-FT-6).

## Architecture Decisions

| ID | Decision | Rationale |
|----|----------|-----------|
| D-KB-1 | Chunk by section headers first, then paragraphs if >2000 chars | Mirrors RFP structure |
| D-KB-2 | Auto-categorize via keyword patterns (no LLM) | Air-gap safe, GOTCHA-compliant |
| D-KB-3 | Four-section prompt template | Separation of concerns |
| D-KB-4 | Route via `router.invoke("proposal_drafting")` | Reuses existing FT override + two-tier |
| D-KB-5 | Flask multipart upload, 50MB max, UUID prefix | Standard pattern, prevents collisions |
| D-KB-6 | Content hash dedup on ingestion | Prevents duplicate blocks |
| D-KB-7 | `_read_file_content()` used as pure function | Avoids cross-DB dependency |

## New Files

| File | Purpose |
|------|---------|
| `tools/govcon/knowledge_ingestion.py` | Document → chunk → classify → knowledge_base.add_block() |
| `tools/govcon/draft_orchestrator.py` | RAG search → prompt → LLM → save draft |
| `hardprompts/proposal_draft.md` | System prompt template for draft generation |
| `tools/dashboard/templates/knowledge/index.html` | Knowledge base browse, search, upload UI |

## Modified Files

| File | Changes |
|------|---------|
| `tools/finetune/pair_generator.py` | Bug fix: `draft_text` → `draft_content` |
| `tools/rag/source_registry.py` | Bug fix: `draft_text` → `draft_content` |
| `tools/db/init_icdev_db.py` | ALTER TABLE: add provenance columns |
| `tools/dashboard/app.py` | 6 new routes (knowledge browse/upload/search/stats, generate-draft, draft-status) |
| `tools/dashboard/templates/govcon.html` | Knowledge Base button |
| `tools/dashboard/templates/proposals/section_detail.html` | Generate Draft, Save, approval workflow |
| `tools/dashboard/templates/proposals/detail.html` | Generate action in section rows |

## Data Flow

```
INGESTION:
  Upload PDF/DOCX → Flask API → knowledge_ingestion.ingest_document()
    → document_extractor._read_file_content() → _chunk_document()
    → _auto_categorize() → knowledge_base.add_block() per chunk

AUTO-DRAFT:
  Click "Generate Draft" → draft_orchestrator.generate_draft()
    → Load section + opportunity + shall-statements
    → knowledge_base.search_blocks() (hybrid keyword + RAG semantic)
    → Fill hardprompts/proposal_draft.md template
    → router.invoke("proposal_drafting") → save to proposal_section_drafts

FEEDBACK LOOP:
  Approve draft → pair_generator --generate-from-govcon → fine-tuning pairs
    → Fine-tuned model → better future drafts
```

## Dashboard Routes

| Route | Method | Purpose |
|-------|--------|---------|
| `/govcon/knowledge-base` | GET | Browse/search knowledge blocks |
| `/api/govcon/knowledge-base/upload` | POST | File upload → ingest_document() |
| `/api/govcon/knowledge-base/search` | GET | Search blocks |
| `/api/govcon/knowledge-base/stats` | GET | Stats (total, by category/domain) |
| `/api/govcon/sections/<id>/generate-draft` | POST | Auto-draft generation |
| `/api/govcon/sections/<id>/draft-status` | POST | Approval workflow |

## CLI Usage

```bash
# Ingest a single document
python tools/govcon/knowledge_ingestion.py --ingest --file old_rfp.pdf --json

# Bulk ingest a directory
python tools/govcon/knowledge_ingestion.py --bulk-ingest --directory ./old_rfps --json

# Generate draft for a section
python tools/govcon/draft_orchestrator.py --generate --section-id <id> --opportunity-id <id> --json

# Preview context without LLM
python tools/govcon/draft_orchestrator.py --preview --section-id <id> --opportunity-id <id> --json
```

## Bug Fixes

- `pair_generator.py`: `draft_text` → `draft_content`, `quality_score` → `confidence_score`, `updated_at` → `created_at`
- `source_registry.py`: `draft_text` → `draft_content` in content_cols and metadata_cols
- `draft_orchestrator.py`: `shall_text` → `statement_text`, `confidence_score` → `confidence`, `draft_method` column removed (doesn't exist)
