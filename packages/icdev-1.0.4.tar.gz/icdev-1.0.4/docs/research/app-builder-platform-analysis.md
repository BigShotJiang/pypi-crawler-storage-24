# Innovation & Competitive Analysis: Open App Builder Platform

**CUI // SP-CTI**
**Date:** 2026-03-08
**Classification:** Internal Research — ICDEV Child App Strategy

---

## Executive Summary

The app builder market is bifurcated: **locked platforms** (Appian at $500M Army deals, Base44 acquired by Wix for $80M) offer speed but create vendor lock-in, while **open building blocks** (Shadcn/ui, Supabase, Vercel json-render) offer ownership but require assembly. No product combines both: an **open-source, compliance-native, AI-assisted app builder** with visual drag-and-drop, full code ownership, and government-grade compliance baked in.

This is ICDEV's whitespace. The child app — codename **"Forge Studio"** — would be a separate product that lets any user (technical or non-technical) build professional full-stack applications with:
- Visual drag-and-drop builder (no-code)
- AI-assisted generation (describe → get app)
- JSON-render server-driven UI (dynamic without redeployment)
- Shadcn/ui component catalog (beautiful, accessible, owned)
- Supabase + PostgreSQL dual backend (managed or self-hosted)
- ICDEV compliance stack inherited by every generated app
- Multi-tenant, air-gap deployable, open-source

---

## 1. Product Research: Five Building Blocks

### 1.1 Shadcn/ui — The Component Foundation

| Attribute | Detail |
|-----------|--------|
| **What** | Copy-paste React component system built on Radix UI + Tailwind CSS |
| **GitHub Stars** | 105,000+ (fastest-growing UI library in history) |
| **License** | MIT (free, no restrictions) |
| **Key Innovation** | You own every line of code — no npm dependency, no vendor lock-in |
| **AI-Native** | MCP server + registry protocol + Skills system for AI agents |
| **Components** | 50+ accessible components: forms, tables, charts, navigation, overlays |
| **Ecosystem** | Blocks (pre-built page sections), community registries, visual builders |

**Why it matters for Forge Studio:**
- The **registry protocol** makes components machine-readable — AI and visual builders can discover, install, and compose them programmatically
- Components are **accessibility-first** (Radix primitives handle ARIA, keyboard, focus)
- **No runtime dependency** — generated apps don't depend on a "shadcn" package
- **AI coding agents** (Claude Code, Cursor, v0.dev) already understand shadcn/ui natively
- Community visual builders like `ui-builder` and shadcn Studio prove drag-and-drop works with these components

**Weakness to mitigate:** Hard Tailwind CSS dependency. Maintenance burden of copied components. React-only (no Vue/Angular).

### 1.2 Supabase — The Backend Engine

| Attribute | Detail |
|-----------|--------|
| **What** | Open-source Firebase alternative built on PostgreSQL |
| **GitHub Stars** | 78,000+ |
| **License** | Apache 2.0 (core), MIT (client libraries) |
| **Architecture** | PostgreSQL + PostgREST (auto API) + GoTrue (auth) + Realtime (WebSocket) + Storage (S3-compat) + Edge Functions (Deno) |
| **Self-Hosting** | Docker Compose or Kubernetes, fully air-gap capable |
| **Pricing** | Free tier (500MB, 50K auth users) → Pro ($25/mo) → Team ($599/mo) → Enterprise |
| **Compliance** | SOC 2 Type II, HIPAA BAA (Team+). No FedRAMP — but self-hostable in GovCloud |
| **AI/Vector** | pgvector for embeddings, LangChain/LlamaIndex integrations |

**Why it matters for Forge Studio:**
- **Aligns with ICDEV's PostgreSQL strategy** (D-DB-20) — Supabase IS PostgreSQL
- **Auto-generated REST/GraphQL APIs** from schema — no-code users get instant backend
- **Row-Level Security (RLS)** — authorization logic in the database, not middleware
- **Realtime subscriptions** — live data without custom WebSocket code
- **Self-hostable in AWS GovCloud** for FedRAMP boundary inheritance
- **Air-gap capable** — all components containerized, no phone-home requirement
- **Storage + Auth + Functions** bundled — complete backend from one product

**Weakness to mitigate:** No FedRAMP on managed platform. Edge Functions limited to Deno/TypeScript. Single-region architecture. Connection limits on lower tiers.

**Dual-mode architecture for Forge Studio:**
| Mode | Backend | Use Case |
|------|---------|----------|
| **Managed** | Supabase Cloud (Pro/Team) | Commercial customers, startups, rapid prototyping |
| **Self-Hosted** | Supabase on AWS GovCloud / K8s | Government, defense, air-gapped, IL4+ environments |
| **Lite** | Direct PostgreSQL via ICDEV storage abstraction | Minimal footprint, existing PostgreSQL deployments |

### 1.3 Vercel json-render — The Generative UI Bridge

| Attribute | Detail |
|-----------|--------|
| **What** | AI-constrained UI generation framework — AI produces JSON, renderer produces React |
| **Released** | January 2026 |
| **License** | Apache 2.0 |
| **Architecture** | Developer defines Catalog (allowed components + Zod schemas) → AI generates JSON → Renderer produces native UI |
| **Cross-Platform** | React, React Native, Vue, Svelte, PDF, HTML email, video |
| **Key Feature** | Progressive streaming (JSONL patches), reverse source-code generation |

**Why it matters for Forge Studio:**
- **The bridge between no-code and pro-code** — AI generates constrained JSON within developer-defined guardrails
- **Server-Driven UI** — update the backend JSON, all clients reflect changes instantly (no redeployment)
- **Catalog = component whitelist** — maps directly to a shadcn/ui component registry
- **Type-safe, no arbitrary code execution** — critical for compliance (no eval(), no injection)
- **Cross-platform rendering** — one schema renders to web, mobile, PDF, email
- **Reverse code generation** — users can "eject" from JSON-render to raw React code at any time (no lock-in)

**Weakness to mitigate:** Relatively new (Jan 2026). Complex interactions still need custom components. Performance overhead of JSON parsing at runtime.

**Competitive landscape in generative UI:**
| Framework | Approach | Status |
|-----------|----------|--------|
| **json-render** (Vercel) | Catalog + JSON constraints | GA, Apache 2.0 |
| **A2UI** (Google) | Open protocol for agent-to-client UI | v0.8 preview, Apache 2.0 |
| **Thesys C1** | LLM-to-UI API endpoint | Active, 300+ teams |

**Strategic choice:** json-render wins because it's catalog-constrained (matches shadcn/ui registry), framework-agnostic, and supports reverse code generation (no lock-in). A2UI is worth monitoring for agent-to-agent UI communication.

### 1.4 Base44 — The UX Model (Not Architecture)

| Attribute | Detail |
|-----------|--------|
| **What** | AI no-code app builder — describe in natural language → get working app |
| **Users** | 250,000+ in months |
| **Acquired** | Wix, $80M (June 2025) |
| **Tech Stack** | React frontend, proprietary locked backend, PostgreSQL |
| **Code Export** | Frontend only — backend is proprietary and cannot be exported |
| **Weakness** | Severe vendor lock-in, production stability concerns, security incidents |

**What to learn from Base44 (UX patterns, NOT architecture):**
- **Conversational app creation** works — users describe, AI builds
- **Instant deployment** to a live URL creates "magic moment" engagement
- **Built-in integrations** (email, SMS, LLM calls) reduce time-to-value
- **Dual credit system** (build credits + runtime credits) is a clever monetization model

**What NOT to copy from Base44:**
- Proprietary locked backend (critical failure — users cannot leave)
- No self-hosting capability
- Opaque backend logic (no inspect, no modify)
- Production instability and security vulnerabilities
- No compliance story whatsoever

**Forge Studio advantage over Base44:** Full code ownership, self-hostable, compliance-native, air-gap capable, open-source. Same magic UX, none of the lock-in.

### 1.5 Appian — The Enterprise Validation

| Attribute | Detail |
|-----------|--------|
| **What** | Enterprise low-code platform (BPM + RPA + AI + data fabric) |
| **Government** | FedRAMP High, DoD IL5, $500M US Army contract |
| **Market Position** | Gartner Leader in BOAT and Enterprise Low-Code |
| **Pricing** | ~$70-100/user/month (enterprise), opaque, six-to-seven figures annually |
| **Lock-in** | Proprietary SAIL UI framework, no code export |

**What Appian validates for Forge Studio:**
1. **Market demand is real** — $500M Army deal proves government will pay for compliance-embedded app builders
2. **Data fabric pattern** — virtual data layer across systems (ICDEV's DataBridge + storage abstraction is the open-source version)
3. **Process-as-governance** — compliance embedded in process execution, not bolted on
4. **Agent Studio** — AI agents within governed processes (ICDEV already has 12-agent architecture)
5. **Portals** — external-facing apps without per-user licensing (smart model for gov)

**Forge Studio advantage over Appian:**
| Dimension | Appian | Forge Studio |
|-----------|--------|-------------|
| **Price** | $70-100/user/month | Open-source (free) + optional managed tier |
| **Lock-in** | High (SAIL, no export) | Zero (React + PostgreSQL, full code export) |
| **Compliance** | FedRAMP High, IL5 | 9-framework crosswalk + cATO live evidence |
| **Frontend** | SAIL (limited) | Shadcn/ui (full React, unlimited customization) |
| **AI** | Agent Studio | 12-agent A2A + json-render generative UI |
| **Self-host** | On-prem (expensive) | Docker/K8s (free, air-gap capable) |
| **Data layer** | Data Fabric (proprietary) | Supabase + DataBridge (open-source) |

---

## 2. Market Analysis

### 2.1 Market Size & Growth

| Market | Size | CAGR | Source |
|--------|------|------|--------|
| Low-Code Platform | $44.5B by 2026 | 20% YoY | Gartner |
| BOAT (Process Automation) | $25B by 2027 | — | Gartner |
| Hyperautomation | $1.04T | 11.9% | Industry |
| AI App Builders (vibe coding) | Emerging | Explosive | Base44: 250K users in months |

### 2.2 Competitive Positioning

```
┌─────────────────────────────────────────────────────────────────────┐
│                    COMPETITIVE LANDSCAPE                             │
│                                                                     │
│  HIGH CONTROL ←──────────────────────────────→ HIGH EASE            │
│  (Pro-Code)                                    (No-Code)            │
│                                                                     │
│  ┌─────────┐                                                        │
│  │ Raw React│  Full control, no assistance                          │
│  │ + Supa   │                                                       │
│  └─────────┘                                                        │
│       ┌──────────┐                                                  │
│       │ Shadcn + │  Component ownership + AI assist                 │
│       │ json-rend│                                                  │
│       └──────────┘                                                  │
│            ┌─────────────────┐                                      │
│            │  FORGE STUDIO   │  ← THE GAP                           │
│            │  Open + Easy +  │  Drag-and-drop + AI + compliance     │
│            │  Compliance     │  + full code ownership                │
│            └─────────────────┘                                      │
│                 ┌───────────┐                                       │
│                 │ Lovable / │  AI gen + code export, no compliance  │
│                 │ Bolt.new  │                                       │
│                 └───────────┘                                       │
│                      ┌─────────┐                                    │
│                      │ Base44  │  AI gen, locked backend             │
│                      └─────────┘                                    │
│                           ┌──────────┐                              │
│                           │ Appian / │  Enterprise locked,          │
│                           │ Pega     │  compliance, $$$              │
│                           └──────────┘                              │
│                                ┌──────────────┐                     │
│                                │ Power Platform│  Cheapest, shallowest│
│                                └──────────────┘                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 2.3 The Whitespace

**No existing product offers ALL of:**
1. Visual drag-and-drop builder (no-code entry point)
2. AI-assisted generation (describe → get app)
3. Full code ownership and export (no lock-in)
4. Self-hostable and air-gap capable
5. Government compliance baked in (NIST, FedRAMP, CMMC)
6. Open-source
7. Multi-tenant SaaS option
8. Professional-grade UI (shadcn/ui quality)
9. Real-time backend (Supabase capabilities)
10. Server-driven UI for dynamic updates (json-render)

Forge Studio would be the **first open-source, compliance-native, AI-assisted app builder** targeting all customers — from a startup founder prototyping an MVP to a DoD program manager building a mission app.

---

## 3. Strategic Architecture: Forge Studio

### 3.1 Four-Mode User Experience

| Mode | User | Interface | Output |
|------|------|-----------|--------|
| **Chat Mode** | Anyone | "Build me a CRM with Kanban board" → AI generates full app | json-render JSON → React app |
| **Visual Mode** | Designers, PMs | Drag-and-drop shadcn/ui components onto canvas | json-render JSON → React app |
| **Low-Code Mode** | Citizen developers | Visual builder + formula bar + data bindings | json-render JSON + custom logic |
| **Pro-Code Mode** | Developers | Full React + TypeScript + Supabase SDK | Standard React codebase |

**Key principle:** All four modes produce the same artifact — a json-render catalog definition + Supabase schema. Users can move between modes freely. A PM starts in Chat Mode, a designer refines in Visual Mode, a developer extends in Pro-Code Mode — all working on the same app.

### 3.2 Technology Stack

```
┌──────────────────────────────────────────────────────┐
│                    FORGE STUDIO                       │
│                                                      │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐     │
│  │  Chat Mode │  │Visual Mode │  │Pro-Code Mode│     │
│  │  (AI Gen)  │  │(Drag-Drop) │  │  (React)   │     │
│  └─────┬──────┘  └─────┬──────┘  └─────┬──────┘     │
│        │               │               │             │
│        ▼               ▼               ▼             │
│  ┌─────────────────────────────────────────────┐     │
│  │         json-render Catalog Layer            │     │
│  │   (Component whitelist + Zod schemas)        │     │
│  │   Built on shadcn/ui registry protocol       │     │
│  └─────────────────────┬───────────────────────┘     │
│                        │                             │
│                        ▼                             │
│  ┌─────────────────────────────────────────────┐     │
│  │         Rendering Engine                     │     │
│  │   json-render → React (web)                  │     │
│  │   json-render → React Native (mobile)        │     │
│  │   json-render → PDF (compliance artifacts)   │     │
│  └─────────────────────┬───────────────────────┘     │
│                        │                             │
│                        ▼                             │
│  ┌─────────────────────────────────────────────┐     │
│  │         Backend Layer                        │     │
│  │   Supabase (managed) OR Self-hosted PG       │     │
│  │   Auth + RLS + Realtime + Storage + Edge Fn  │     │
│  └─────────────────────┬───────────────────────┘     │
│                        │                             │
│                        ▼                             │
│  ┌─────────────────────────────────────────────┐     │
│  │         ICDEV Compliance Layer               │     │
│  │   9-framework crosswalk, cATO, audit trail   │     │
│  │   CUI markings, SBOM, ZTA, digital thread    │     │
│  └─────────────────────────────────────────────┘     │
│                                                      │
│  ┌─────────────────────────────────────────────┐     │
│  │         Multi-Tenancy Layer                  │     │
│  │   Tenant isolation via Supabase RLS          │     │
│  │   Per-tenant schemas OR shared + RLS         │     │
│  └─────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────┘
```

### 3.3 Component Architecture

| Layer | Technology | Purpose |
|-------|-----------|---------|
| **UI Catalog** | Shadcn/ui + custom components | 50+ accessible components owned by each app |
| **Generative UI** | Vercel json-render | AI-safe JSON → React rendering with catalog constraints |
| **Visual Builder** | Custom canvas (React DnD / Lexical) | Drag-and-drop composition of catalog components |
| **AI Engine** | ICDEV LLM Router (qwen3.5 draft → Claude review) | Natural language → json-render JSON generation |
| **Backend** | Supabase (PostgreSQL + Auth + Realtime + Storage) | Managed or self-hosted, auto-generated APIs |
| **Compliance** | ICDEV compliance stack | 9-framework crosswalk, cATO, audit trail, CUI |
| **Deployment** | Docker/K8s + Vercel/Netlify options | Self-host or managed, air-gap capable |
| **Multi-Tenancy** | Supabase RLS + tenant context | Row-level isolation, per-tenant or shared schema |

### 3.4 The "Eject" Guarantee (Anti-Lock-In)

Every Forge Studio app can be **ejected** at any point to a standard React + Supabase codebase:

| What You Get | Format |
|-------------|--------|
| Frontend code | React + TypeScript + shadcn/ui + Tailwind CSS |
| Backend schema | PostgreSQL migrations (standard SQL) |
| Auth config | Supabase GoTrue config OR standalone auth |
| API endpoints | PostgREST (auto) OR custom Edge Functions |
| Compliance artifacts | OSCAL JSON, SSP markdown, SBOM CycloneDX |
| Deployment config | Dockerfile + docker-compose.yml + K8s manifests |

**No proprietary runtime. No SDK dependency. No phone-home.** The ejected app runs on vanilla React + PostgreSQL forever.

### 3.5 Deployment Modes

| Mode | Target | Infrastructure | Compliance |
|------|--------|---------------|------------|
| **SaaS** | Startups, commercial | Supabase Cloud + Vercel | SOC 2 inherited |
| **Self-Hosted** | Enterprise, on-prem | Docker Compose / K8s | Customer-managed ATO |
| **GovCloud** | Federal, DoD | AWS GovCloud + self-hosted Supabase | FedRAMP boundary inheritance |
| **Air-Gap** | IC, classified | K8s on isolated network, no internet | Full NIST 800-53, IL4+ |

### 3.6 Multi-Tenancy Architecture

```
Option A: Shared Database + RLS (default)
┌─────────────────────────────────────────┐
│  PostgreSQL (single instance)           │
│  ┌──────────────────────────────────┐   │
│  │ tenant_id column on every table  │   │
│  │ RLS policy: tenant_id = jwt.tid  │   │
│  │ Tenant A sees only Tenant A rows │   │
│  │ Tenant B sees only Tenant B rows │   │
│  └──────────────────────────────────┘   │
└─────────────────────────────────────────┘

Option B: Schema-per-Tenant (enterprise)
┌─────────────────────────────────────────┐
│  PostgreSQL (single instance)           │
│  ├── tenant_a (schema)                  │
│  ├── tenant_b (schema)                  │
│  └── shared   (schema) — common config  │
└─────────────────────────────────────────┘

Option C: Database-per-Tenant (gov/classified)
┌───────────┐  ┌───────────┐  ┌───────────┐
│  PG (A)   │  │  PG (B)   │  │  PG (C)   │
│  Tenant A │  │  Tenant B │  │  Tenant C │
└───────────┘  └───────────┘  └───────────┘
```

---

## 4. Competitive Advantages

### 4.1 vs. Appian ($500M Army Deals)

| Dimension | Appian | Forge Studio |
|-----------|--------|-------------|
| Price | $70-100/user/month | Free (open-source) + managed tier |
| Lock-in | SAIL proprietary, no export | Zero — eject to React + PostgreSQL anytime |
| Compliance | FedRAMP High, IL5 | 9-framework crosswalk + cATO + more |
| AI | Agent Studio (new) | 12-agent A2A + generative UI (json-render) |
| Frontend | SAIL (limited) | Shadcn/ui (unlimited customization) |
| Self-host | Expensive on-prem | Free Docker/K8s |
| Data | Data Fabric (proprietary) | Supabase + DataBridge (open) |

### 4.2 vs. Base44 (250K Users)

| Dimension | Base44 | Forge Studio |
|-----------|--------|-------------|
| Speed | Minutes to working app | Minutes to working app (same AI gen) |
| Backend | Locked, proprietary | Open (Supabase/PostgreSQL), fully exportable |
| Self-host | Impossible | Docker Compose one-liner |
| Compliance | None | 9-framework crosswalk |
| Code ownership | Frontend only | Full stack |
| Production-ready | Stability concerns | PostgreSQL + Supabase (battle-tested) |
| Air-gap | Impossible | Fully supported |

### 4.3 vs. Lovable/Bolt.new

| Dimension | Lovable/Bolt | Forge Studio |
|-----------|-------------|-------------|
| AI generation | Yes | Yes (same quality, ICDEV LLM router) |
| Code export | Yes | Yes |
| Visual builder | No | Yes (drag-and-drop) |
| Compliance | None | 9-framework crosswalk |
| Self-host | Limited | Full Docker/K8s |
| Multi-tenant | No | Yes |
| Air-gap | No | Yes |

### 4.4 vs. Power Platform

| Dimension | Power Platform | Forge Studio |
|-----------|---------------|-------------|
| Price | $5-40/user/month | Free (open-source) |
| Ecosystem | Microsoft only | Any cloud, any infra |
| BPM depth | Basic | ICDEV workflow engine |
| Compliance | FedRAMP via Azure Gov | 9-framework crosswalk |
| Open-source | No | Yes |
| Lock-in | Microsoft ecosystem | Zero |
| AI quality | Copilot (good) | Claude + qwen3.5 (flexible) |

---

## 5. Revenue Model (Open-Source + Managed)

| Tier | Price | Includes |
|------|-------|---------|
| **Community** | Free forever | Full platform, self-hosted, unlimited apps, all components |
| **Cloud** | $29/month | Managed hosting, Supabase backend, custom domains, auto-deploy |
| **Team** | $99/month | Multi-tenant, collaboration, RBAC, priority support |
| **Enterprise** | Custom | SLA, dedicated infrastructure, compliance packages, SSO/SAML |
| **GovCloud** | Custom | AWS GovCloud deployment, FedRAMP boundary, IL4+ support, US-person support |

**Marketplace add-ons:**
- Premium component packs (industry-specific: healthcare forms, defense dashboards)
- Compliance template bundles (FedRAMP, CMMC, STIG)
- Connector packs (SAP, ServiceNow, DOORS NG)
- AI credit packs (for managed AI generation)

---

## 6. Implementation Roadmap

### Phase 1: Foundation (4-6 sprints)
- [ ] Shadcn/ui catalog registration as json-render catalog
- [ ] json-render integration with ICDEV LLM router
- [ ] Supabase schema generator from natural language
- [ ] Basic Chat Mode: "Build me a [X]" → working app
- [ ] Eject command: export to React + Supabase project
- [ ] Docker Compose one-liner for self-hosting

### Phase 2: Visual Builder (4-6 sprints)
- [ ] Drag-and-drop canvas (React DnD Kit)
- [ ] Component palette from shadcn/ui catalog
- [ ] Property panel for component configuration
- [ ] Data binding to Supabase tables
- [ ] Live preview with hot reload
- [ ] Responsive layout system (desktop/tablet/mobile)

### Phase 3: Compliance Integration (2-3 sprints)
- [ ] ICDEV compliance stack wiring
- [ ] Auto-generated SBOM for every app
- [ ] CUI marking injection
- [ ] Audit trail for builder actions
- [ ] Compliance dashboard per app

### Phase 4: Multi-Tenancy & Deployment (3-4 sprints)
- [ ] Tenant isolation via Supabase RLS
- [ ] Per-tenant configuration and branding
- [ ] One-click deploy to managed cloud
- [ ] GovCloud deployment pipeline
- [ ] Air-gap deployment package generator

### Phase 5: Advanced Features (4-6 sprints)
- [ ] Low-code formula bar (computed fields, expressions)
- [ ] Workflow builder (BPMN-lite from ICDEV runbook engine)
- [ ] Marketplace for components, templates, connectors
- [ ] Mobile app generation (React Native via json-render)
- [ ] Process mining integration from audit trail

### Phase 6: Enterprise & Government (3-4 sprints)
- [ ] SSO/SAML integration
- [ ] Custom compliance framework support
- [ ] White-label capability
- [ ] FedRAMP package documentation
- [ ] IL4+ deployment hardening guide

---

## 7. Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| json-render is too new (Jan 2026) | Medium | High | Build abstraction layer; can swap to A2UI or custom renderer |
| Shadcn/ui React-only limits market | Low | Medium | React dominates; Vue/Angular can come later via json-render cross-platform |
| Supabase self-hosted complexity | Medium | Medium | Provide hardened Docker images + K8s Helm charts |
| Visual builder is hard to build well | High | High | Start with Chat Mode (AI gen); visual builder is Phase 2 |
| Appian/ServiceNow compete on gov contracts | Medium | Medium | Open-source + compliance depth is the moat |
| AI generation quality inconsistent | Medium | Medium | Catalog constraints (json-render) + two-tier LLM review |
| Multi-tenancy RLS complexity | Medium | Medium | Start with Option A (shared + RLS), add B/C for enterprise |
| Air-gap Supabase requires custom images | Low | Low | Pre-built air-gap image with all extensions |

---

## 7a. BPMN-Lite Workflow Integration (Implemented in Phase 1)

Forge Studio reuses ICDEV's existing workflow engines via a thin adapter pattern (`tools/forge_studio/workflow/bpmn_adapter.py`), following D-FS-5 — no modifications to existing code.

### Engines Reused

| Engine | Source | Purpose in Forge Studio |
|--------|--------|------------------------|
| **Runbook DAG** | `tools/cloudforge/runbooks/engine.py` | Multi-step workflow orchestration (approval flows, onboarding, CRUD audit) |
| **DMN Engine** | `tools/decisions/dmn_engine.py` | Decision routing (e.g., approval threshold → auto-approve vs. manager review) |
| **Saga Coordinator** | `tools/orchestration/saga_coordinator.py` | Compensation logic for multi-step workflows (rollback on failure) |

### Workflow Templates (args/forge_studio/workflow_templates.yaml)

| Template | Steps | DMN | Saga |
|----------|-------|-----|------|
| `approval_flow` | Submit → Route → Approve/Reject → Notify | Routing by amount/category | Notification rollback |
| `onboarding_flow` | Create Account → Assign Role → Welcome → Training → Verify | — | Full compensation chain |
| `crud_with_audit` | Validate → Execute → Audit Log | — | — |

### Architecture Pattern

```
User creates workflow in Forge Studio
  → bpmn_adapter.py creates Runbook DAG (tasks + edges)
  → Registers DMN decision tables (if conditional routing needed)
  → Creates Saga with compensation steps (if multi-step)
  → Runbook Engine executes via Kahn's topological sort (D-CF-21)
  → DMN evaluates conditions deterministically
  → Saga handles failures with compensation
```

This keeps workflow execution **100% deterministic** (no LLM in critical path) while giving users a visual workflow builder in future phases.

---

## 8. Key Technology Decisions

| ID | Decision | Rationale |
|----|----------|-----------|
| **D-FS-1** | Shadcn/ui as component catalog | 105K stars, AI-native, MIT, registry protocol, full ownership |
| **D-FS-2** | Vercel json-render as rendering layer | Catalog-constrained AI gen, cross-platform, reverse code gen, Apache 2.0 |
| **D-FS-3** | Supabase as backend | PostgreSQL (D-DB-20 aligned), self-hostable, air-gap capable, auto API, RLS |
| **D-FS-4** | Four-mode UX (Chat/Visual/Low-Code/Pro-Code) | All customer segments: non-technical to developer |
| **D-FS-5** | Eject guarantee — full code export at any time | Anti-lock-in differentiator vs. Appian, Base44, Power Platform |
| **D-FS-6** | ICDEV compliance stack inherited by default | 9-framework crosswalk, cATO, audit trail, CUI markings |
| **D-FS-7** | Multi-tenancy via Supabase RLS (default), schema-per-tenant (enterprise) | Proven PostgreSQL pattern, scales from startup to government |
| **D-FS-8** | ICDEV LLM router for AI generation (qwen3.5 draft → Claude review) | Token-optimized, air-gap capable (Ollama local), consistent quality |
| **D-FS-9** | Open-source core with managed tiers | Community adoption + enterprise revenue, like Supabase's own model |
| **D-FS-10** | Separate product from ICDEV dashboard | Clean separation, own deployment, own user base |

---

## 9. Validation Signals

| Signal | Evidence |
|--------|---------|
| **Market demand for AI app builders** | Base44: 250K users in months, $80M acquisition |
| **Government willingness to pay** | Appian: $500M Army deal, FedRAMP High + IL5 |
| **Open-source beats proprietary** | Supabase: 78K stars, growing faster than Firebase |
| **Component ownership matters** | Shadcn/ui: 105K stars, replaced MUI/Chakra in new projects |
| **Server-driven UI is the future** | Airbnb Ghost Platform, Shopify, Netflix all use SDUI in production |
| **Compliance is a moat** | Appian charges $70-100/user/month largely because of FedRAMP/IL5 |
| **AI + visual builder convergence** | v0.dev + shadcn/ui, Base44 UX, Lovable + Supabase |

---

## Sources

- [Shadcn/ui Documentation](https://ui.shadcn.com/docs)
- [Shadcn/ui CLI v4 Changelog (March 2026)](https://ui.shadcn.com/docs/changelog/2026-03-cli-v4)
- [Supabase Official Documentation](https://supabase.com/docs)
- [Vercel json-render GitHub](https://github.com/vercel-labs/json-render)
- [json-render Official Site](https://json-render.dev/)
- [Google A2UI GitHub](https://github.com/google/A2UI)
- [Base44 Official Site](https://base44.com)
- [Wix Acquires Base44 for $80M (Yahoo Finance)](https://finance.yahoo.com/news/wix-com-acquires-base44-80-191121958.html)
- [Appian Government Cloud](https://appian.com/industries/public-sector/appian-government-cloud)
- [US Army Awards Appian $500M (Appian Press)](https://appian.com/about/explore/press-releases/2026/us-army-awards-appian-enterprise-agreement)
- [Appian FedRAMP High Authorization (2025)](https://appian.com/about/explore/press-releases/2025/appian-secures-government-most-sensitive-civilian-data-fedramp)
- [Airbnb Server-Driven UI Deep Dive](https://medium.com/airbnb-engineering/a-deep-dive-into-airbnbs-server-driven-ui-system-842244c5f5)
- [Generative UI Frameworks Comparison 2026](https://quickleap.io/blog/generative-ui-platforms-comparison-2026)
- [Gartner: Low-Code Market $44.5B by 2026](https://www.gartner.com)
- [AI Coding Agents Benchmark 2026](https://ai-agents-benchmark.com/)
- [ICDEV Flowable BOAT Competitive Analysis (Internal)](docs/research/flowable-boat-competitive-analysis.md)

---

*Generated by ICDEV Innovation Engine — 2026-03-08*
