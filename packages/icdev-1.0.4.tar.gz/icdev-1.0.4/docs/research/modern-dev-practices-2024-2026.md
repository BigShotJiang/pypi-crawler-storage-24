# CUI // SP-CTI
# Modern Software Development Best Practices (2024-2026)
# Applied to ICDEV: DoD/Federal Compliance Automation Platform

Classification: CUI // SP-CTI | Impact Level: IL4
Research Date: 2026-03-08
Scope: TDD/BDD for AI-Agentic Systems, DevSecOps Pipelines, Code Quality,
Configuration Management, Documentation-as-Code, Resilience Engineering

---

## Table of Contents

1. [TDD/BDD Best Practices for AI-Agentic Systems](#1-tddbdd-best-practices-for-ai-agentic-systems)
2. [DevSecOps Pipeline Best Practices](#2-devsecops-pipeline-best-practices)
3. [Code Quality and Maintainability](#3-code-quality-and-maintainability)
4. [Configuration Management](#4-configuration-management)
5. [Documentation-as-Code](#5-documentation-as-code)
6. [Resilience Engineering](#6-resilience-engineering)
7. [Priority Actions Summary](#7-priority-actions-summary)
8. [Sources](#8-sources)

---

## 1. TDD/BDD Best Practices for AI-Agentic Systems

### 1.1 Testing Non-Deterministic AI Outputs

**The Core Problem.** Traditional TDD expects deterministic outputs: given input X,
assert output Y. With LLMs, the same input produces different outputs on every run.
ICDEV's 12-agent architecture with a 4-tier LLM routing system (planner, worker,
scanner, default) through `tools/llm/router.py` makes this challenge pervasive.

**Industry Consensus (2025-2026).** The field has converged on a layered evaluation
strategy that replaces exact-match assertions with behavioral, structural, and
semantic validation:

| Evaluation Layer | What It Checks | When to Use | Example |
|-----------------|----------------|-------------|---------|
| Structural | Output schema, required fields, types | Always | SSP has `ssp_id`, `classification` |
| Semantic | Meaning similarity (cosine similarity) | LLM-generated text | Narrative covers AC-2 concepts |
| Behavioral | Tool selection, reasoning steps, decisions | Agent orchestration | Compliance agent chose correct framework |
| Property-based | Invariants that must always hold | Rule engines | Every NIST control maps to >= 1 framework |
| Rubric-based | LLM-as-judge with scoring criteria | Complex narratives | Narrative scores >= 7/10 for accuracy |

**Semantic Similarity Approach.**  Embed both the expected reference output and
the actual output using a sentence transformer, then assert cosine similarity
exceeds a threshold (typically 0.75-0.85).  This tolerates phrasing variation
while catching semantic drift.  Research from Agent CI (2025) shows that cosine
similarity alone can miss cases where "wording is similar but meaning is
different," so it should be combined with structural checks:

```python
# tests/test_narrative_quality.py
from sentence_transformers import SentenceTransformer
import numpy as np

model = SentenceTransformer("all-MiniLM-L6-v2")

def cosine_sim(a: str, b: str) -> float:
    emb = model.encode([a, b])
    return float(np.dot(emb[0], emb[1]) / (np.linalg.norm(emb[0]) * np.linalg.norm(emb[1])))

def test_ac2_narrative_semantic_similarity():
    reference = "AC-2 is implemented via centralized identity management..."
    actual = generate_narrative(control="AC-2", project_id="test")

    # Structural: must contain classification marking
    assert "CUI //" in actual

    # Semantic: must be conceptually similar to reference
    sim = cosine_sim(reference, actual)
    assert sim > 0.75, f"Semantic similarity {sim:.3f} below threshold"
```

**LLM-as-Judge Evaluation.**  For complex narrative outputs (compliance SSP
narratives, AI-generated documentation), use an LLM evaluator with a scoring
rubric.  The G-Eval framework (DeepEval, 2025) uses chain-of-thought prompting
with binary or 1-5 scale rubrics.  Binary evaluations are more reliable:

```python
# tests/evals/test_ssp_narrative_eval.py
RUBRIC = """
Evaluate the SSP narrative for control {control_id}.
Score each criterion as PASS or FAIL:
1. ACCURACY: Narrative correctly describes the control implementation
2. COMPLETENESS: All required sub-controls are addressed
3. CLASSIFICATION: Contains appropriate CUI marking
4. SPECIFICITY: References project-specific implementation details
5. COMPLIANCE: Uses NIST 800-53 Rev 5 language and terminology
"""

def test_ssp_narrative_with_llm_judge():
    narrative = generate_ssp_narrative(control="AC-2", project_id="test")
    judge_result = llm_evaluate(
        rubric=RUBRIC.format(control_id="AC-2"),
        output=narrative,
        judge_model="claude-sonnet",
    )
    assert judge_result["ACCURACY"] == "PASS"
    assert judge_result["CLASSIFICATION"] == "PASS"
```

**Outlier Detection for Consistency.**  When running the same prompt N times, compute
the centroid (mean embedding vector) and use Median Absolute Deviation (MAD) to
detect outliers.  This catches cases where the model occasionally produces wildly
different outputs:

```python
def test_output_consistency(n_runs=5):
    outputs = [generate_ssp_narrative("AC-2", "test") for _ in range(n_runs)]
    embeddings = model.encode(outputs)
    centroid = np.mean(embeddings, axis=0)
    distances = [np.linalg.norm(e - centroid) for e in embeddings]
    median_dist = np.median(distances)
    mad = np.median([abs(d - median_dist) for d in distances])
    # No output should be > 3 MADs from centroid
    for i, d in enumerate(distances):
        assert (d - median_dist) / (mad + 1e-8) < 3.0, f"Run {i} is an outlier"
```

**ICDEV-Specific Recommendation.** Test at each LLM routing tier differently:

| Tier | Test Strategy | Rationale |
|------|--------------|-----------|
| Planner (Claude direct) | LLM-as-judge + semantic similarity | Complex reasoning; needs qualitative evaluation |
| Worker (qwen3.5 draft + Claude review) | Structural + semantic | Verify draft and review improve quality |
| Scanner (qwen3.5/llava only) | Structural + property-based | Deterministic schemas; verify format compliance |
| Default (fallback chain) | Structural only | Verify graceful degradation across providers |


### 1.2 Contract Testing for Agent-to-Agent Communication

**Why Contract Testing Matters for ICDEV.**  ICDEV's 12 agents communicate via
JSON-RPC 2.0 over mTLS.  Each publishes an Agent Card at `/.well-known/agent.json`.
When one agent's response schema changes, consumer agents break silently.  Contract
testing catches this at build time, not in production.

**Consumer-Driven Contract Testing.**  The industry standard (Pact, 2025) defines
contracts from the consumer's perspective.  The consumer specifies what it expects,
and the provider verifies it can satisfy those expectations.  For ICDEV:

- The **orchestrator** is the primary consumer of all 11 domain/support agents
- Each **domain agent** consumes the orchestrator's dispatch and status APIs
- **Compliance agent** consumes security agent scan results for evidence collection

**Implementation Pattern:**

```python
# tests/contracts/schemas/compliance_ssp_generate.json
{
  "consumer": "orchestrator",
  "provider": "compliance",
  "method": "ssp_generate",
  "request": {
    "required": ["project_id"],
    "properties": {
      "project_id": {"type": "string"},
      "baseline": {"type": "string", "enum": ["low", "moderate", "high"]}
    }
  },
  "response": {
    "required": ["ssp_id", "controls", "classification"],
    "properties": {
      "ssp_id": {"type": "string"},
      "controls": {"type": "array"},
      "classification": {"type": "string", "pattern": "^CUI //"}
    }
  }
}
```

Store contracts as JSON Schema files in `tests/contracts/schemas/`.  Each agent's
CI pipeline validates both directions: "Do I produce what consumers expect?" and
"Do I receive what I need from providers?"

**Contract Versioning.**  When a breaking change is necessary:

1. Add a new contract version (e.g., `v2/compliance_ssp_generate.json`)
2. Provider must satisfy both v1 and v2 during migration period
3. Consumers migrate to v2 on their own schedule
4. v1 contract deprecated after all consumers migrate

**ICDEV Already Has: `tests/contracts/test_agent_contracts.py`** (created during
this research).  It defines contracts for 9 agent methods with structural validation,
type checking, and CUI classification enforcement.


### 1.3 Property-Based Testing for Compliance Rule Engines

**Research Evidence.**  An empirical study presented at OOPSLA 2025 evaluated
property-based testing (PBT) across 7,125 Hypothesis tests in 426 Python projects.
Key finding: **each PBT test finds approximately 50x more mutants than the average
unit test**.  This makes PBT exceptionally valuable for ICDEV's deterministic rule
engines.

**What to Test with Hypothesis.**  ICDEV's compliance tools have rich invariants:

| Component | Properties to Test |
|-----------|-------------------|
| `crosswalk_engine.py` | Every valid NIST control maps to >= 1 framework; coverage percentages are 0.0-1.0; implementing a control never decreases coverage |
| `nist_lookup.py` | Control IDs follow pattern `[A-Z]{2}-[0-9]+`; every control has a family; enhancement IDs include parent |
| `zta_maturity_scorer.py` | Scores are 0.0-1.0; adding security measures never decreases score; all 7 pillars are always present |
| `sbd_assessor.py` | 35 SBD requirements are always evaluated; pillar mapping covers all 8 Cloudyrion pillars |
| `control_mapper.py` | Activity-to-control mappings are deterministic; same activity always maps to same controls |
| `agent_trust_scorer.py` | Trust scores are 0.0-1.0; violations always decrease score; trust levels correspond to score ranges |

**Example Hypothesis Tests:**

```python
# tests/test_compliance_properties.py
from hypothesis import given, strategies as st, assume

# Strategy for valid NIST 800-53 control IDs
nist_control_ids = st.from_regex(
    r"(AC|AT|AU|CA|CM|CP|IA|IR|MA|MP|PE|PL|PM|PS|PT|RA|SA|SC|SI|SR)-[0-9]{1,2}",
    fullmatch=True,
)

@given(control_id=nist_control_ids)
def test_crosswalk_coverage_is_bounded(control_id):
    """Coverage percentage must always be between 0.0 and 1.0."""
    result = crosswalk_engine.get_coverage(control_id)
    if result["found"]:
        assert 0.0 <= result["coverage"] <= 1.0

@given(score=st.floats(min_value=0.0, max_value=1.0))
def test_trust_level_always_assigned(score):
    """Every valid score must map to exactly one trust level."""
    level = AgentTrustScorer.score_to_level(score)
    assert level in ("normal", "degraded", "untrusted", "blocked")

@given(
    scores=st.lists(
        st.floats(min_value=0.0, max_value=1.0),
        min_size=7, max_size=7,
    )
)
def test_zta_overall_is_weighted_average(scores):
    """Overall ZTA score must be a valid weighted average of pillar scores."""
    pillars = dict(zip(
        ["identity", "device", "network", "application", "data",
         "visibility", "automation"],
        scores,
    ))
    overall = zta_scorer.compute_overall(pillars)
    assert min(scores) <= overall <= max(scores)
```

**Agentic Property-Based Testing.**  A 2025 arXiv paper describes using Claude Code
as an agent that generates Hypothesis PBTs targeting Python functions, modules, or
entire codebases.  This approach found novel bugs across the Python ecosystem.  For
ICDEV, this means PBT generation can be partially automated:

```bash
# Use Claude Code to generate Hypothesis tests for a module
claude "Generate Hypothesis property-based tests for tools/compliance/crosswalk_engine.py
focusing on invariants: coverage bounds, monotonic mapping, idempotent lookups"
```


### 1.4 Snapshot Testing for Generated Artifacts

**When to Use Snapshots.**  ICDEV generates structured compliance artifacts (SSP,
POAM, SBOM, OSCAL documents, CycloneDX JSON).  These artifacts have stable structure
but dynamic content (timestamps, UUIDs, version numbers).  Snapshot testing catches
unintended structural regressions while allowing expected dynamic fields to change.

**Syrupy Framework.**  Syrupy is the standard pytest snapshot plugin (used by
Home Assistant, AWS CDK, and many large Python projects).  It stores human-readable
snapshot files alongside tests, which are committed to version control:

```python
# tests/test_compliance_snapshots.py
import re
import json

def normalize(output: dict) -> dict:
    """Strip dynamic fields before snapshot comparison."""
    s = json.dumps(output, indent=2, sort_keys=True)
    # Normalize timestamps
    s = re.sub(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}", "TIMESTAMP", s)
    # Normalize UUIDs
    s = re.sub(r"[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}",
               "UUID", s)
    return json.loads(s)

def test_ssp_structure(snapshot):
    result = ssp_generator.generate(project_id="test-project", baseline="moderate")
    assert normalize(result) == snapshot

def test_sbom_cyclonedx_structure(snapshot):
    result = sbom_generator.generate(project_dir="/test", format="cyclonedx")
    assert normalize(result) == snapshot

def test_oscal_assessment_results(snapshot):
    result = cato_live_engine.generate_assessment(project_id="test")
    assert normalize(result) == snapshot
```

Update snapshots intentionally: `pytest --snapshot-update`

**When NOT to Use Snapshots.**  Avoid for LLM-generated narrative text (too
variable).  Use semantic similarity + rubric evaluation instead.


### 1.5 Mutation Testing Applicability

**What Mutation Testing Reveals.**  Mutation testing modifies source code (e.g.,
changing `>=` to `>`, removing a conditional branch) and checks whether tests
detect the mutation.  Surviving mutants indicate weak test coverage.

**Tool Selection for Python.**  `mutmut` (pure Python) and `cosmic-ray` (more
features, slower) are the primary options.  For ICDEV's 410+ tool files, use
targeted mutation testing on high-value deterministic components:

| Component Category | Mutation Value | Rationale | Tool Files |
|-------------------|---------------|-----------|------------|
| Compliance rule engines | **High** | Pure deterministic logic; boundary conditions critical | `crosswalk_engine.py`, `nist_lookup.py`, `control_mapper.py` |
| Scoring algorithms | **High** | Threshold comparisons; weighted averages | `zta_maturity_scorer.py`, `agent_trust_scorer.py`, `readiness_scorer.py` |
| Security detectors | **High** | False negatives are security risks | `prompt_injection_detector.py`, `secret_detector.py` |
| LLM router logic | **Medium** | Routing decisions are deterministic; provider probing is not | `router.py` (routing logic only) |
| Data parsers | **Medium** | Schema validation, field extraction | `xmi_parser.py`, `reqif_parser.py` |
| LLM-dependent generators | **Low** | Output depends on model; mutations in prompt assembly hard to detect | `narrative_workflow.py`, `ssp_generator.py` |
| Dashboard/UI code | **Low** | Visual rendering; better tested with E2E | `app.py`, templates |

**Targeted Execution:**

```bash
# Mutate only the crosswalk engine
mutmut run --paths-to-mutate tools/compliance/crosswalk_engine.py \
           --tests-dir tests/ --runner "pytest tests/test_crosswalk.py"

# View surviving mutants
mutmut results
mutmut show <mutant_id>
```


### 1.6 Testing Prompt Chains and LLM Routing

**ICDEV's Prompt Chains.**  The `tools/agent/prompt_chain_executor.py` runs
multi-step LLM reasoning chains defined in `args/prompt_chains.yaml` (e.g.,
`plan_critique_refine`, `scout_analyze_recommend`).  Testing at three levels:

**Level 1: Unit (Mock LLM, Test Orchestration).**  Mock the LLM provider and
verify chain mechanics: step ordering, input/output threading, error handling,
early termination conditions:

```python
def test_chain_executes_all_steps():
    with mock_llm(responses=["plan text", "critique text", "refined text"]):
        result = execute_chain("plan_critique_refine", input="design auth flow")
    assert result["steps_completed"] == 3
    assert result["step_names"] == ["plan", "critique", "refine"]
    # Verify output of step N is input to step N+1
    assert "plan text" in result["steps"][1]["input"]
```

**Level 2: Integration (Deterministic Model Stub).**  Use a local small model
(or canned responses) to verify end-to-end flow without cloud API calls:

```python
@pytest.mark.integration
def test_chain_with_local_model():
    """Run chain against Ollama qwen3.5 (requires Ollama running)."""
    result = execute_chain(
        "plan_critique_refine",
        input="design a FedRAMP-compliant auth flow",
        provider_override="ollama",
    )
    assert result["status"] == "completed"
    assert len(result["final_output"]) > 100
```

**Level 3: Evaluation (Periodic, Real Models).**  Run nightly in CI with real
models and score with rubrics.  These are not pass/fail gates but quality
dashboards:

```python
@pytest.mark.nightly
def test_chain_quality_evaluation():
    result = execute_chain("plan_critique_refine", input=STANDARD_PROMPT)
    quality = evaluate_with_rubric(result["final_output"], QUALITY_RUBRIC)
    # Log to metrics, don't hard-fail
    assert quality["overall"] >= 6, f"Quality regression: {quality}"
```

**LLM Router Testing.**  The router (`tools/llm/router.py`) has deterministic
routing logic (config-driven) and non-deterministic execution (LLM calls).
Test them separately:

```python
# Test routing logic (deterministic)
def test_scanner_tier_routes_to_ollama():
    router = LLMRouter()
    provider, model = router.resolve_provider("compliance_export")
    assert provider == "ollama"  # Scanner tier never uses Claude

def test_worker_tier_uses_two_tier():
    router = LLMRouter()
    provider, model = router.resolve_provider("code_generation")
    # Worker tier should attempt qwen3.5 first
    assert "qwen" in model.lower() or provider == "ollama"

# Test fallback behavior (mock providers)
def test_fallback_chain_on_provider_failure():
    with mock_provider_unavailable("ollama"):
        router = LLMRouter()
        provider, model = router.resolve_provider("code_generation")
        assert provider == "bedrock"  # Falls back to Claude
```

**Evaluation Frameworks for 2025-2026.**  Key tools:

| Framework | Best For | ICDEV Relevance |
|-----------|---------|-----------------|
| DeepEval | Pytest-integrated LLM evals; G-Eval rubrics | Testing narrative quality |
| RAGAS | RAG pipeline evaluation | Testing RAG subsystem (Phase 64) |
| Inspect AI | Multi-step agent behavior | Testing prompt chains |
| Promptfoo | Prompt regression testing | Detecting prompt template regressions |
| LangSmith | Tracing + evaluation combined | Development-time debugging |

---

## 2. DevSecOps Pipeline Best Practices

### 2.1 Shift-Left Security for Federal Systems

**Executive Order 14028 Compliance.**  EO 14028 (May 2021) mandates SBOMs, secure
development practices, and attestation for all federal software suppliers.  NIST
responded with SSDF v1.2 (draft 2025).  In 2026, SBOM mandates are transitioning
from aspiration to enforcement.

**ICDEV's Current Position.**  ICDEV already implements shift-left security:
- SAST: `tools/security/sast_runner.py`
- Dependency audit: `tools/security/dependency_auditor.py`
- Secret detection: `tools/security/secret_detector.py`
- Container scanning: `tools/security/container_scanner.py`
- SBOM generation: `tools/compliance/sbom_generator.py`
- Prompt injection detection: `tools/security/prompt_injection_detector.py`

**Gap: Pipeline Gate Orchestration.**  The individual tools exist but need
declarative orchestration that enforces gate ordering and prevents skipping.
The `args/pipeline_gates.yaml` file (created during this research) addresses
this with 5 stages: pre_commit, build, integration, pre_deploy, post_deploy.

**Key Principle:**  Every security gate must be:
1. **Automated** -- no manual approval steps for routine checks
2. **Immovable** -- blocking gates cannot be bypassed without documented exception
3. **Audited** -- every gate result (pass/fail/skip) logged to audit_trail
4. **Deterministic** -- same code + same config = same gate result


### 2.2 Continuous ATO (cATO) Pipeline Patterns

**DoD cATO Evaluation Criteria (2024).**  The DoD CIO published formal cATO
evaluation criteria requiring:

1. **Active Cyber Defense** -- Continuous monitoring, automated response
2. **Secure Software Supply Chain** -- SBOM, provenance, attestation
3. **DevSecOps Pipelines** -- Automated security at every stage
4. **Continuous Monitoring** -- Real-time evidence collection
5. **Rapid Patch Management** -- Automated vulnerability remediation

**ICDEV Alignment:**

| cATO Requirement | ICDEV Implementation | Status |
|-----------------|---------------------|--------|
| Continuous monitoring | `cato_live_engine.py` OSCAL streaming | Implemented (F1) |
| SBOM on every build | `sbom_generator.py` + pipeline gate | Implemented |
| Automated scanning | SAST/DAST/SCA/container | Implemented |
| Immutable audit trail | Append-only audit_trail table | Implemented (D6) |
| Evidence freshness | 30-day threshold in cATO engine | Implemented (D-INV-2) |
| Provenance tracking | W3C PROV-AGENT (D287) | Implemented |
| Rapid patching | CVE triage with SLA (D-SC-*) | Implemented |

**cATO Pipeline Pattern (recommended for ICDEV):**

```
Code Commit
    |
    v
[Pre-commit Gates] -> Secret detection, lint, CUI marking
    |
    v
[Build] -> Compile, SAST, dep audit, SBOM generation
    |
    v
[Integration] -> Contract tests, prompt injection scan, AI BOM
    |
    v
[Pre-deploy] -> Container scan, STIG, SbD, ZTA maturity, SLSA provenance
    |
    v
[Deploy to Staging] -> Smoke tests, E2E, acceptance criteria
    |
    v
[cATO Evidence] -> OSCAL assessment-results streamed per-control
    |
    v
[Deploy to Production] -> Canary -> Full rollout
    |
    v
[Continuous Monitoring] -> Evidence freshness, trust scoring, telemetry
```

**The Software Factory Model.**  DoD software factories (Platform One, Black Pearl,
Kessel Run) establish reusable DevSecOps platforms.  ICDEV's architecture aligns
with this model: the GOTCHA framework provides the reusable platform, and child
applications inherit the pipeline, gates, and compliance posture.


### 2.3 SBOM-Driven Vulnerability Management

**Current State (2026).**  SBOMs are no longer optional for federal suppliers.
Organizations that build with automated SBOM generation from day one have a
structural advantage in defense procurement.

**ICDEV's SBOM Capabilities:**
- Software SBOM: `sbom_generator.py` (CycloneDX)
- Firmware SBOM: `firmware_sbom.py` (CycloneDX 1.5 + VEX CSAF 2.0, D-INV-45/46)
- AI BOM: `ai_bom_generator.py` (AI component inventory)
- Dependency graph: `dependency_graph.py` (SQL adjacency list, D27)

**Recommended Enhancement: VEX-Driven Triage.**  Vulnerability Exploitability
eXchange (VEX) documents contextualize SBOM vulnerabilities.  Not every CVE in
a dependency is exploitable in your specific deployment.  ICDEV's `cve_triager.py`
should consume VEX data to automatically downgrade non-exploitable findings:

```
SBOM (what we ship) + CVE feeds (what's vulnerable) + VEX (what's exploitable)
    -> Actionable vulnerability list (what we must fix)
```


### 2.4 Policy-as-Code Maturity Model

ICDEV already generates Kyverno and OPA policies via `policy_generator.py`.
The maturity model for policy-as-code:

| Level | Description | ICDEV Status | Action |
|-------|-------------|-------------|--------|
| 1 - Manual | Policies in PDFs/wikis | Surpassed | -- |
| 2 - Coded | Policies in Rego/YAML | **Current** | `policy_generator.py` generates policies |
| 3 - Tested | Policy unit tests with conftest | **Gap** | Add `tests/test_policies.py` with conftest |
| 4 - Enforced | Admission controllers block violations | **Partial** | Kyverno generation exists; deployment needed |
| 5 - Continuous | Policy dashboards, drift detection | **Gap** | Add policy compliance to `vsm_engine.py` |

**Kyverno vs OPA for ICDEV:**

| Aspect | Kyverno | OPA/Gatekeeper |
|--------|---------|----------------|
| Language | YAML (developer-friendly) | Rego (learning curve) |
| K8s native | Yes (CRDs) | Via Gatekeeper |
| Mutation | Built-in | Separate webhook |
| Audit | Built-in reporting | External |
| ICDEV support | `policy_generator.py --engine kyverno` | `policy_generator.py --engine opa` |
| Recommendation | **Primary** for ICDEV | Secondary for complex rules |


### 2.5 GitOps for Infrastructure

**ArgoCD for Federal Deployments.**  ArgoCD is the dominant GitOps tool for DoD
Kubernetes environments in 2025-2026, with widespread adoption in AWS GovCloud.
Key benefits for ICDEV:

- **Drift detection**: ArgoCD continuously compares Git state to cluster state,
  aligning with ICDEV's `sync_engine.py` drift detection philosophy
- **Multi-cluster**: Manage IL4/IL5/IL6 clusters from a single control plane
  with RBAC per clearance level
- **Audit**: Every sync logged with Git commit SHA, user, timestamp (NIST AU)
- **Self-heal**: Automatically reverts unauthorized manual changes

**ArgoCD + ICDEV Integration Pattern:**

```yaml
# argocd/applications/icdev-compliance-agent.yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: icdev-compliance-agent
  namespace: argocd
spec:
  project: icdev-agents
  source:
    repoURL: https://github.com/icdev-ai/icdev.git
    targetRevision: main
    path: k8s/agents/compliance
  destination:
    server: https://kubernetes.default.svc
    namespace: icdev
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
```

**Dual-Tool Strategy.**  Many organizations use both: ArgoCD for application
delivery, Flux for cluster bootstrapping.  For ICDEV, ArgoCD is sufficient
as the primary tool.

**Best Practices:**
- Separate app code and K8s manifests into different repos (or directories)
- Use Kustomize overlays for environments (dev/staging/production/air-gap)
- Pin image versions explicitly (never use `:latest` in production)
- Enable self-heal and prune features
- Never commit plain Secrets to Git (use sealed-secrets or external-secrets)


### 2.6 Supply Chain Security (SLSA Framework)

**SLSA Levels (v1.1/v1.2).**  SLSA provides progressive security levels for
software supply chain integrity:

| Level | Requirements | ICDEV Status | Action |
|-------|-------------|-------------|--------|
| 0 | No provenance | Surpassed | -- |
| 1 | Build provenance generated | **Partial** | audit_trail captures builds; need SLSA-format provenance |
| 2 | Hosted build + authenticated contributors | **Available** | GitHub Actions with OIDC; sign with cosign/Sigstore |
| 3 | Isolated builds, tamper-evident logs, non-falsifiable provenance | **Not yet** | Ephemeral build containers needed |

**SLSA v1.2 Source Track (2025).**  The new Source Track covers threats from
source code authoring, reviewing, and management.  This aligns with ICDEV's
existing code review gates in `args/security_gates.yaml`.

**Achieving SLSA Level 2 (Weeks, Not Months):**

1. Use GitHub Actions with OIDC for build provenance
2. Sign artifacts with Sigstore/cosign
3. Generate SLSA provenance attestation via `slsa-github-generator`
4. Verify provenance in the pre-deploy pipeline gate

```yaml
# .github/workflows/slsa-build.yml
jobs:
  build:
    runs-on: ubuntu-latest
    outputs:
      digests: ${{ steps.hash.outputs.digests }}
    steps:
      - uses: actions/checkout@v4
      - run: python -m build
      - id: hash
        run: sha256sum dist/* | base64 -w0 > digests.txt

  provenance:
    needs: build
    uses: slsa-framework/slsa-github-generator/.github/workflows/generator_generic_slsa3.yml@v2.1.0
    with:
      base64-subjects: ${{ needs.build.outputs.digests }}
```

**ICDEV Already Has:**  `args/security_gates.yaml` includes `swft` gates that
check for SLSA provenance (`slsa_provenance_missing` blocks, `min_slsa_level: 2`).

---

## 3. Code Quality and Maintainability

### 3.1 Clean Architecture Applied to AI Agent Systems

**Principles (2025-2026).**  Clean Architecture organizes software into concentric
layers where dependencies point inward toward core business logic.  Python's
dynamic nature makes this straightforward without heavy frameworks.  Sam Keen's
"Clean Architecture with Python" (Packt, 2025) is the definitive reference.

**How GOTCHA Aligns with Clean Architecture.**  ICDEV's 6-layer GOTCHA framework
already embodies clean architecture principles:

| Clean Architecture Layer | GOTCHA Equivalent | Direction |
|-------------------------|-------------------|-----------|
| Entities (business rules) | Tools (`tools/`) | Inner (no outward deps) |
| Use Cases (orchestration) | Goals (`goals/`) + You (AI) | Middle |
| Interface Adapters | Args (`args/`), Context (`context/`) | Outer ring |
| Frameworks & Drivers | MCP servers, Dashboard, A2A | Outermost |

**Key Gap: Tool-to-Tool Dependencies.**  Some tools import directly from other
tools (e.g., `crosswalk_engine.py` imports `get_connection` from `storage.py`).
This is acceptable for the storage layer (it's infrastructure) but problematic
when domain tools import from each other.

**Recommendation: Dependency Rule Enforcement.**

```python
# tools/linting/dep_check.py
# Verify that compliance tools don't import from security tools directly
# (they should communicate via the orchestrator or shared interfaces)

FORBIDDEN_IMPORTS = {
    "tools/compliance/": ["tools/security/", "tools/devsecops/"],
    "tools/security/": ["tools/compliance/", "tools/mbse/"],
    "tools/mbse/": ["tools/security/", "tools/govcon/"],
}
```

### 3.2 SOLID Principles in Python Agent Code

**Single Responsibility.**  Each of ICDEV's 410+ tool files follows SRP well --
one job per script.  The `code_analyzer.py` enforces this with cyclomatic
complexity checks (gate: max avg complexity 25).

**Interface Segregation.**  Python uses abstract base classes (ABCs) for
interfaces.  ICDEV's `tools/llm/provider.py` defines `LLMProvider` and
`EmbeddingProvider` ABCs that all providers implement.  Extend this pattern:

```python
# tools/core/interfaces.py
from abc import ABC, abstractmethod

class ComplianceScanner(ABC):
    """Interface for any compliance scanning tool."""

    @abstractmethod
    def scan(self, project_id: str) -> dict:
        """Run the scan and return findings."""
        ...

    @abstractmethod
    def gate_check(self, findings: dict) -> bool:
        """Return True if findings pass the gate."""
        ...

# Implemented by: stig_checker.py, sbd_assessor.py, fedramp_assessor.py, etc.
```

**Dependency Inversion.**  High-level modules should not depend on low-level
modules; both should depend on abstractions.  The DI container created in
`tools/core/container.py` enables this:

```python
# At startup:
container.register("storage", lambda: get_connection(), singleton=False)
container.register("llm_router", lambda: LLMRouter(), singleton=True)
container.register("audit", lambda: AuditTrail(container.resolve("storage")))

# In tests:
container.register("storage", lambda: sqlite3.connect(":memory:"))
container.register("llm_router", lambda: MockLLMRouter())
```


### 3.3 Error Handling Patterns for Distributed Agent Systems

**Problem.**  When 12 agents communicate via JSON-RPC 2.0, error propagation
becomes complex.  Without standardized errors, debugging requires string-matching
on exception messages across agent boundaries.

**Solution: Structured Error Hierarchy.**  The `tools/core/errors.py` module
(created during this research) provides 14 exception classes across 5 domains:

```
ICDEVError (base)
  ├── AgentError
  │     ├── AgentUnavailableError (retryable=True)
  │     ├── AgentTimeoutError (retryable=True)
  │     └── AgentContractError (retryable=False)
  ├── ComplianceError
  │     ├── ComplianceGateError (retryable=False, carries findings)
  │     └── ClassificationError (retryable=False)
  ├── LLMError
  │     ├── LLMFallbackExhaustedError (retryable=False)
  │     └── LLMProviderError (retryable=True)
  ├── StorageError
  │     ├── StorageConnectionError (retryable=True)
  │     └── StorageMigrationError (retryable=False)
  └── SecurityError
        ├── PromptInjectionError (retryable=False)
        └── TrustScoreError (retryable=False)
```

Every error carries:
- `retryable` flag: Enables programmatic retry/DLQ decisions
- `code`: Machine-readable identifier for JSON-RPC error responses
- `context`: Structured metadata dict for audit trail and OTel spans
- `to_dict()`: Serialization for JSON-RPC error responses


### 3.4 OpenTelemetry Observability Best Practices

**OpenTelemetry Maturity (2025-2026).**  OTel is now CNCF-graduated with stable
APIs for traces, metrics, logs, and profiling (4th signal, stable March 2024).
Python has comprehensive auto-instrumentation and 100+ supported libraries.

**ICDEV Already Has:**  Dual-mode tracer (D280: OTel production, SQLite air-gapped,
NullTracer fallback).  The recommendations below mature this foundation.

**GenAI Semantic Conventions.**  OpenTelemetry published experimental semantic
conventions specifically for AI agent systems (2025):

```python
# tools/observability/otel_conventions.py
# Following OTel GenAI semantic conventions (experimental, 2025)

# Agent span attributes
AGENT_NAME = "gen_ai.agent.name"           # e.g., "compliance"
AGENT_DESCRIPTION = "gen_ai.agent.description"

# LLM invocation attributes
GEN_AI_SYSTEM = "gen_ai.system"             # e.g., "anthropic", "ollama"
GEN_AI_REQUEST_MODEL = "gen_ai.request.model"
GEN_AI_RESPONSE_MODEL = "gen_ai.response.model"
GEN_AI_REQUEST_MAX_TOKENS = "gen_ai.request.max_tokens"
GEN_AI_USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
GEN_AI_USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"

# ICDEV custom attributes (namespaced)
ICDEV_PROJECT_ID = "icdev.project_id"
ICDEV_CLASSIFICATION = "icdev.classification"
ICDEV_LLM_TIER = "icdev.llm.tier"           # planner/worker/scanner
ICDEV_LLM_FUNCTION = "icdev.llm.function"   # e.g., "code_generation"
ICDEV_GATE_NAME = "icdev.gate.name"
ICDEV_GATE_RESULT = "icdev.gate.result"      # pass/fail/skip
```

**Baggage Propagation.**  Pass `project_id`, `session_id`, `classification_level`
as OTel baggage across agent boundaries so that every span in a distributed trace
carries this context:

```python
from opentelemetry import baggage, context

ctx = baggage.set_baggage("icdev.project_id", project_id)
ctx = baggage.set_baggage("icdev.classification", "CUI // SP-CTI", context=ctx)
# All downstream spans inherit this context
```

**Metrics Export.**  Export DORA metrics from `vsm_engine.py` as OTel metrics:

```python
from opentelemetry import metrics

meter = metrics.get_meter("icdev.vsm")
deployment_frequency = meter.create_counter("icdev.dora.deployment_frequency")
lead_time = meter.create_histogram("icdev.dora.lead_time_seconds")
mttr = meter.create_histogram("icdev.dora.mttr_seconds")
change_failure_rate = meter.create_gauge("icdev.dora.change_failure_rate")
```

**Best Practices from CNCF (2025):**
1. Start with auto-instrumentation, add manual spans for business logic
2. Use the OTel Collector (never send telemetry directly to vendors)
3. Follow semantic conventions consistently across all 12 agents
4. Sample intelligently: 100% in staging, head-based sampling in production
5. Correlate traces, metrics, and logs via trace_id


### 3.5 Technical Debt Management

**ICDEV-Specific Debt Items Identified:**

| Debt Item | Impact | Effort | Recommendation |
|-----------|--------|--------|---------------|
| Direct `sqlite3` import in `router.py` line 13 | Bypasses storage abstraction (D-DB-21) | Low | Replace with `get_connection()` |
| Logger names use `sparkpilot.*` (e.g., `sparkpilot.llm.router`) | Branding inconsistency after rename to ICDEV | Low | Global rename to `icdev.*` |
| Test fixtures create schemas inline (e.g., `test_metastore.py`) | Schema drift risk; inline DDL diverges from actual schema | Medium | Share DDL from canonical source or Alembic |
| 348 tables in a single database | Cognitive load; schema bloat | Medium | Group into PostgreSQL schemas: `core`, `compliance`, `fleet`, `govcon` |
| No type hints on many older tool files | IDE support degraded; mypy unusable | Medium | Incremental typing starting with `tools/core/` |
| Some tools still reference `sparkpilot.db` in error messages | Confusing after D-DB-20 migration | Low | Search-and-replace pass |

**Tracking Approach.**  Use ICDEV's existing code quality infrastructure:
- `code_analyzer.py` tracks cyclomatic complexity, cognitive complexity, nesting
- Code quality gate: avg complexity > 25 blocks (D331)
- Track Technical Debt Ratio (TDR): estimated fix cost / total codebase cost
- Log debt items to a `technical_debt` table (append-only, NIST AU) with
  priority, estimated effort, and linked ADR

**GitHub Debt Insights (2026).**  GitHub's new AI-powered Debt Insights feature
can predict long-term costs of unresolved debt.  Consider integrating with
ICDEV's `analytics/scorecard.py` for a unified health view.

---

## 4. Configuration Management

### 4.1 Feature Flags for Federal Compliance Features

**Why Feature Flags for ICDEV.**  ICDEV has 12 innovation features (F1-F12),
optional modules (GovCon, marketplace), and operational modes (air-gap, debug).
Feature flags enable safe rollout, environment-specific configuration, and
graceful degradation.

**Tool Selection for Air-Gapped Environments.**

| Tool | Self-Hosted | Air-Gap | Python SDK | License | Recommendation |
|------|-----------|---------|-----------|---------|---------------|
| Unleash | Yes | Yes (FedRAMP/air-gap) | Yes | Open source | **Best for ICDEV** |
| Flagsmith | Yes | Yes (private cloud) | Yes | Open source | Strong alternative |
| LaunchDarkly | No | No | Yes | Proprietary | **Not suitable** (SaaS only) |
| GrowthBook | Yes | Partial | Yes | Open source | Viable |
| ConfigCat | Yes | Yes | Yes | Freemium | Viable |
| YAML-based (custom) | Yes | Yes | N/A | N/A | **Current ICDEV approach** |

**ICDEV Recommendation: YAML-Based + Unleash.**

For the MVP, the `args/feature_flags.yaml` file (created during this research)
provides zero-dependency feature flags with env var overrides.  For production
multi-tenant deployment, adopt Unleash for dynamic toggling, gradual rollout,
and per-tenant configuration:

```python
# tools/core/feature_flags.py
import os
from pathlib import Path

def is_enabled(flag_name: str, environment: str = None) -> bool:
    """Check if a feature flag is enabled.

    Resolution order:
    1. Environment variable: ICDEV_FF_{FLAG_NAME_UPPER}
    2. YAML config: args/feature_flags.yaml
    3. Default: False
    """
    env_var = f"ICDEV_FF_{flag_name.upper()}"
    env_value = os.environ.get(env_var)
    if env_value is not None:
        return env_value.lower() in ("true", "1", "yes")

    config = _load_flags_yaml()
    flag = config.get("flags", {}).get(flag_name, {})

    if not flag.get("enabled", False):
        return False

    # Check air-gap overrides
    air_gap = config.get("flags", {}).get("air_gap_mode", {})
    if air_gap.get("enabled", False):
        overrides = air_gap.get("overrides", {})
        if flag_name in overrides:
            return overrides[flag_name]

    # Check environment restriction
    allowed_envs = flag.get("environments", [])
    if environment and allowed_envs and environment not in allowed_envs:
        return False

    return True
```


### 4.2 Environment-Based Configuration

**Four Environments for ICDEV:**

| Environment | Storage | LLM | Network | Gates | Classification |
|------------|---------|-----|---------|-------|---------------|
| Production | PostgreSQL | Ollama + Bedrock | Full | Strict (all blocking) | CUI // SP-CTI |
| Staging | PostgreSQL | Ollama + Bedrock | Full | Strict (all blocking) | CUI // SP-CTI |
| Dev | SQLite | Ollama + Bedrock | Full | Relaxed (warnings only) | CUI // SP-CTI |
| Air-gap | SQLite | Ollama only | None | Strict + relaxed freshness | CUI // SP-CTI |

**Configuration Cascade:**

```
Environment variable (highest priority)
    |
    v
args/feature_flags.yaml (environment-specific)
    |
    v
args/<tool>_config.yaml (tool-specific)
    |
    v
Hardcoded defaults (lowest priority)
```


### 4.3 Secret Management Patterns

**ICDEV Target: AWS GovCloud (us-gov-west-1).**

| Environment | Secret Backend | Pattern |
|------------|---------------|---------|
| Production | AWS Secrets Manager | `ICDEV_PG_SECRET_REF=aws:secretsmanager:icdev/pg-creds` |
| Staging | AWS Secrets Manager | Same, different secret path |
| Dev/Local | `.env` file (gitignored) | `ICDEV_PG_PASSWORD=localdev` |
| Air-gap | HashiCorp Vault (on-prem) | `ICDEV_PG_SECRET_REF=vault:secret/icdev/pg` |

**Secret Resolver Enhancement.**  ICDEV's `storage.py` already supports
`ICDEV_PG_SECRET_REF=env:PG_PASS`.  Extend the resolver:

```python
# tools/db/secret_resolver.py
def resolve_secret(ref: str) -> str:
    """Resolve a secret reference to its value.

    Supported schemes:
      env:VAR_NAME          -- Read from environment variable
      aws:secretsmanager:ID -- Fetch from AWS Secrets Manager
      vault:PATH            -- Fetch from HashiCorp Vault
      file:/path/to/secret  -- Read from file (K8s mounted secrets)
    """
    scheme, _, path = ref.partition(":")

    if scheme == "env":
        return os.environ[path]
    elif scheme == "aws":
        _, service, secret_id = path.split(":", 2)
        return _fetch_aws_secret(secret_id)
    elif scheme == "vault":
        return _fetch_vault_secret(path)
    elif scheme == "file":
        return Path(path).read_text().strip()
    else:
        raise ValueError(f"Unknown secret scheme: {scheme}")
```

**HashiCorp Vault vs AWS Secrets Manager:**

| Feature | Vault | AWS Secrets Manager |
|---------|-------|-------------------|
| Dynamic secrets | Yes (per-use credentials) | No (rotation only) |
| Multi-cloud | Yes | AWS only |
| Air-gap | Yes (self-hosted) | No |
| Complexity | High (self-managed) | Low (managed service) |
| Cost | Free (OSS) + infra | $0.40/secret/month |
| **ICDEV recommendation** | Air-gap/on-prem | AWS GovCloud production |


### 4.4 Schema Versioning with Alembic

**ICDEV's Current State.**  D-DB-25 designates Alembic for PostgreSQL schema
versioning.  With 348 tables, migration management is critical.

**SQLite + PostgreSQL Dual-Backend Migrations.**  Alembic's batch operations
mode handles SQLite's ALTER TABLE limitations.  The recommended pattern:

```python
# alembic/env.py
def run_migrations_online():
    connectable = engine_from_config(config.get_section("alembic"))

    with connectable.connect() as connection:
        # Detect backend for appropriate migration strategy
        dialect = connection.dialect.name

        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            render_as_batch=(dialect == "sqlite"),  # Batch mode for SQLite
        )

        with context.begin_transaction():
            context.run_migrations()
```

**Migration Best Practices for ICDEV:**

1. **One migration per change** -- never combine unrelated DDL
2. **Always review autogenerated migrations** -- autogenerate is a starting point
3. **Offline SQL generation for air-gap** -- `alembic upgrade head --sql > migration.sql`
4. **Migration tests** -- run every migration up and down in CI
5. **Never modify released migrations** -- create new migrations to fix issues
6. **Tag milestones** -- `alembic stamp <revision>` for release versions

```bash
# Generate offline SQL for DBA review (air-gap)
alembic upgrade head --sql > migrations/offline/v1.2.0.sql

# Run migration tests
pytest tests/test_migrations.py -v
```

---

## 5. Documentation-as-Code

### 5.1 Architecture Decision Records (ADRs)

**ICDEV's Current State.**  ICDEV already uses extensive D-* numbering (D1 through
D-SBD-7+) embedded in `CLAUDE.md`.  This is functional but has scaling issues:
the CLAUDE.md file is very large, and individual decisions are hard to discover.

**AWS ADR Best Practices (2025).**  AWS published formal ADR guidance recommending:

1. **One file per decision** in a dedicated directory
2. **Immutable once accepted** (create new ADR to supersede)
3. **Status lifecycle**: Proposed -> Accepted -> Deprecated/Superseded
4. **Cross-referencing** via explicit `supersedes` and `depends_on` fields

**Recommended ADR Structure for ICDEV:**

```
docs/adr/
  ├── README.md           # Index of all ADRs
  ├── template.md         # ADR template
  ├── core/
  │     ├── D-DB-20.md    # PostgreSQL primary backend
  │     ├── D-DB-21.md    # Storage abstraction layer
  │     └── ...
  ├── compliance/
  │     ├── D-INV-1.md    # cATO OSCAL streaming
  │     ├── D-SBD-1.md    # Cloudyrion 8-Pillar mapping
  │     └── ...
  ├── security/
  │     ├── D215.md       # Prompt injection categories
  │     └── ...
  └── resilience/
        ├── D280.md       # Pluggable tracer ABC
        └── ...
```

**ADR Template:**

```markdown
# D-{DOMAIN}-{NUMBER}: {Title}

**Status:** Accepted | Proposed | Deprecated | Superseded by D-XX
**Date:** YYYY-MM-DD
**Supersedes:** D-XX (if applicable)
**Depends on:** D-XX, D-YY

## Context
What is the issue? What forces are at play?

## Decision
What we decided and why.

## Consequences
Positive, negative, and risks.

## Compliance Impact
Which frameworks are affected (NIST, FedRAMP, CMMC, etc.)

## Classification
CUI // SP-CTI
```


### 5.2 API Documentation Automation

**ICDEV's 12 MCP Servers Expose 70+ Tools.**  Each MCP server defines tools with
name, description, and JSON Schema parameters.  This is already machine-readable
documentation.

**Recommendation: Auto-Generate OpenAPI Docs from MCP Tool Definitions.**

```python
# tools/docs/mcp_doc_generator.py
"""Generate API reference documentation from MCP server tool definitions.

Reads each MCP server module, extracts tool definitions, and produces:
  1. OpenAPI 3.0 spec (for Swagger UI)
  2. Markdown reference (for docs/api/)
  3. JSON Schema catalog (for contract testing)
"""

def extract_tools_from_mcp(server_module) -> list:
    """Import MCP server and extract tool definitions."""
    ...

def generate_openapi_spec(all_tools: list) -> dict:
    """Convert MCP tools to OpenAPI paths."""
    ...

def generate_markdown(all_tools: list) -> str:
    """Generate markdown API reference."""
    ...
```

**FastAPI Already Supports This.**  If ICDEV's dashboard (`tools/dashboard/app.py`)
uses Flask, the OpenAPI spec must be generated manually.  If migrated to FastAPI,
docs are auto-generated from type hints and Pydantic models.


### 5.3 Living Documentation from Tests

**BDD Features as Compliance Evidence.**  ICDEV's Gherkin/BDD tests in `features/`
already serve as living documentation.  Enhance with compliance tagging:

```gherkin
@NIST-AC-2 @FedRAMP-Moderate @CUI @IL4
Feature: User Account Provisioning
  As a system administrator
  I want user accounts to require approval
  So that NIST AC-2 account management controls are satisfied

  Scenario: New account requires manager approval
    Given a pending account request for "analyst@dod.mil"
    When the account is submitted for provisioning
    Then the account status should be "pending_approval"
    And an audit trail entry should be created with action "account_requested"
    And the entry classification should contain "CUI // SP-CTI"
```

**Auto-Generate Compliance Traceability from Feature Tags:**

```python
# tools/docs/compliance_trace_from_bdd.py
"""Parse @NIST-* tags from .feature files and generate a traceability matrix.

Maps BDD scenarios to NIST 800-53 controls, then feeds into the crosswalk
engine to auto-populate FedRAMP/CMMC/800-171 coverage.
"""
```

**Test Results as cATO Evidence.**  Feed BDD test results into
`cato_live_engine.py` as evidence for the controls tagged in each scenario.
A passing `@NIST-AC-2` scenario becomes evidence for AC-2 implementation.


### 5.4 Compliance Documentation Generation

**ICDEV Already Excels Here.**  The compliance toolchain is comprehensive:
- SSP: `ssp_generator.py`
- POAM: `poam_generator.py`
- OSCAL: `oscal_generator.py`
- SBOM: `sbom_generator.py`
- CUI markings: `cui_marker.py`
- Crosswalk: `crosswalk_engine.py`

**Enhancement: Docs-from-Gates.**  Every pipeline gate execution generates
structured data.  Aggregate gate results into compliance documentation:

```
Gate Results (pipeline_gates.yaml)
    |
    v
Evidence Aggregator
    |
    +---> cATO OSCAL assessment-results
    +---> SSP appendix (automated test evidence)
    +---> POAM update (failed gates -> new findings)
    +---> CMMC evidence package
```

---

## 6. Resilience Engineering

### 6.1 Chaos Engineering for Agent Systems

**Chaos Engineering Platforms (2025-2026).**  Two CNCF-incubating projects
dominate Kubernetes chaos engineering:

| Platform | Maturity | Key Feature | ICDEV Relevance |
|----------|---------|-------------|----------------|
| LitmusChaos | 106 releases | MCP Server for AI-driven chaos | Direct integration with Claude Code |
| Chaos Mesh | 74 releases | Fine-grained fault injection | Comprehensive K8s fault simulation |

**LitmusChaos MCP Server (2025).**  Litmus launched an MCP Server that exposes
chaos engineering capabilities via the Model Context Protocol.  This enables
natural-language chaos experiments from Claude Code:

```
"Run a network latency experiment on the compliance agent pod
 with 500ms delay for 60 seconds and observe the circuit breaker behavior"
```

**Chaos Experiments for ICDEV's 12-Agent Architecture:**

| Experiment | Target | Expected Behavior | Validates |
|-----------|--------|-------------------|-----------|
| Agent pod kill | Any agent pod | K8s restarts pod; DLQ captures in-flight tasks | Auto-recovery, DLQ |
| Network partition | Between orchestrator and domain agents | Circuit breaker trips; cached results served | Circuit breaker, fallback |
| LLM provider timeout | Bedrock endpoint | Router falls back to Ollama | LLM fallback chain |
| Database connection drop | PostgreSQL | Storage layer falls back to SQLite | Storage fallback (D-DB-20) |
| Memory pressure | Any agent pod | K8s OOM kills; pod restarts with clean state | Resource limits, bulkhead |
| Clock skew | Evidence collector | cATO freshness checks detect stale evidence | Evidence freshness (D-INV-2) |

**Implementation Approach:**

1. **Phase 1 (No New Tools):** Use ICDEV's existing circuit breaker + DLQ
   to inject failures in unit/integration tests
2. **Phase 2 (Staging):** Deploy Chaos Mesh in staging K8s cluster; run
   experiments on non-production agents
3. **Phase 3 (Production):** Graduate to production chaos with LitmusChaos;
   integrate with monitoring for automated experiment evaluation


### 6.2 Graceful Degradation Patterns

**The Degradation Matrix.**  The `args/degradation_matrix.yaml` (created during
this research) defines fallback behavior for 9 components.  The orchestrator
consults this matrix when a circuit breaker trips or health check fails.

**Degradation Strategies:**

| Strategy | When Used | Example |
|----------|----------|---------|
| Provider chain | Primary provider down | Cloud LLM -> Ollama fallback |
| Cloud escalation | Local provider down | Ollama down -> Claude-only |
| SQLite fallback | PostgreSQL down | Switch to local SQLite |
| Queue and cache | Agent down | Queue tasks to DLQ; serve cached results |
| Cache only | Non-critical agent down | Return cached knowledge |
| Air-gap mode | Network down | Disable all external calls |
| Deterministic only | All LLMs down | Only run deterministic tools |
| Graceful shutdown | No storage available | Flush state and exit |

**Cascading Failure Protection:**

```yaml
# From args/degradation_matrix.yaml
cascading_rules:
  - trigger: "postgresql AND sqlite both down"
    action: graceful_shutdown
  - trigger: "cloud_llm AND ollama both down"
    action: degrade_to_deterministic_only
  - trigger: "3+ agents down simultaneously"
    action: emergency_mode
```


### 6.3 Bulkhead Pattern for Agent Isolation

**ICDEV Already Has Bulkhead Config.**  The `args/resilience_config.yaml` includes:

```yaml
bulkhead:
  enabled: true
  default_max_concurrent: 10
  default_queue_size: 50
  overrides:
    bedrock_llm:
      max_concurrent: 5
      queue_size: 20
    sqlite_writes:
      max_concurrent: 3
      queue_size: 100
```

**Kubernetes-Level Bulkheads.**  Complement application-level bulkheads with
K8s resource isolation:

```yaml
# Per-agent resource quotas (prevent one agent from starving others)
apiVersion: v1
kind: ResourceQuota
metadata:
  name: compliance-agent-quota
  namespace: icdev-compliance
spec:
  hard:
    requests.cpu: "2"
    requests.memory: 2Gi
    limits.cpu: "4"
    limits.memory: 4Gi
    pods: "5"
```

```yaml
# NetworkPolicy: compliance agent can only reach orchestrator and DB
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: compliance-agent-bulkhead
spec:
  podSelector:
    matchLabels:
      app: icdev-compliance-agent
  policyTypes: [Ingress, Egress]
  ingress:
    - from:
        - podSelector:
            matchLabels:
              app: icdev-orchestrator
  egress:
    - to:
        - podSelector:
            matchLabels:
              app: icdev-db
    - to:   # Allow DNS
        - namespaceSelector: {}
      ports:
        - port: 53
          protocol: UDP
```


### 6.4 Retry with Exponential Backoff

**ICDEV Already Has Retry Config.**  The `args/resilience_config.yaml` defines:
- Default: 3 retries, exponential backoff (base 1s, multiplier 2.0, max 30s)
- Jitter: 0-25% of computed delay
- Per-subsystem overrides (Bedrock: 5 retries, Ollama: 2 retries)

**Tenacity Library Integration.**  While ICDEV's `task_dlq.py` implements custom
retry logic, the `tenacity` library is the Python standard for production retries:

```python
from tenacity import (
    retry, stop_after_attempt, wait_random_exponential,
    retry_if_exception_type, before_sleep_log,
)

@retry(
    stop=stop_after_attempt(5),
    wait=wait_random_exponential(multiplier=1, max=60),
    retry=retry_if_exception_type((ConnectionError, TimeoutError)),
    before_sleep=before_sleep_log(logger, logging.WARNING),
)
def call_bedrock_llm(prompt: str) -> str:
    """Call Bedrock with automatic retry and jitter."""
    return bedrock_client.invoke(prompt)
```

**Key Insight: `wait_random_exponential` vs `wait_exponential`.**
- `wait_exponential`: Fixed intervals (1, 2, 4, 8...) -- good for single-client retry
- `wait_random_exponential`: Randomized within exponentially widening window --
  **required for multi-process/multi-agent systems** to avoid thundering herd
- ICDEV should always use `wait_random_exponential` since 12 agents may retry
  simultaneously against the same backend


### 6.5 Dead Letter Queue for Failed Agent Tasks

**Implementation.**  The `tools/core/task_dlq.py` (created during this research)
provides:

- **Dispatch with retry**: Exponential backoff + jitter, config-driven from
  `args/resilience_config.yaml`
- **DLQ table**: `agent_task_dlq` (append-only, NIST AU compliant)
- **Query API**: Filter by agent, resolved/unresolved, with limits
- **Resolution tracking**: Mark entries resolved without deleting (audit trail)

**DLQ Lifecycle:**

```
Task dispatched
    |
    v
[Attempt 1] -- fail --> [Wait 1s + jitter]
    |
    v
[Attempt 2] -- fail --> [Wait 2s + jitter]
    |
    v
[Attempt 3] -- fail --> [Move to DLQ]
    |
    v
DLQ entry created (append-only)
    |
    +---> Alert operator (if configured)
    +---> Dashboard DLQ widget
    +---> Manual review and resolution
    |
    v
[Resolution] -- set resolved_at, resolved_by (no DELETE)
```

**DLQ Monitoring Integration:**

```python
# Add to health check endpoint
def dlq_health() -> dict:
    entries = get_dlq_entries(unresolved_only=True)
    return {
        "dlq_unresolved_count": len(entries),
        "dlq_oldest_entry": entries[-1]["created_at"] if entries else None,
        "dlq_by_agent": _group_by_agent(entries),
        "status": "healthy" if len(entries) < 10 else "degraded",
    }
```

---

## 7. Priority Actions Summary

### Tier 1: High Impact, Low Effort (Do First)

| # | Action | Files | Impact |
|---|--------|-------|--------|
| 1 | Property-based tests with Hypothesis for rule engines | `tests/test_compliance_properties.py` | Catches 50x more bugs per test |
| 2 | Circuit breaker in LLM router | `tools/core/circuit_breaker.py` (done) | Prevents cascade failures |
| 3 | Structured error hierarchy | `tools/core/errors.py` (done) | Consistent debugging across agents |
| 4 | Pipeline gates YAML | `args/pipeline_gates.yaml` (done) | Enforces gate ordering |
| 5 | Fix `sparkpilot` logger references | Global rename | Branding consistency |

### Tier 2: High Impact, Medium Effort

| # | Action | Files | Impact |
|---|--------|-------|--------|
| 6 | Contract tests for A2A schemas | `tests/contracts/` (done) | Prevents integration failures |
| 7 | Dead letter queue for agent tasks | `tools/core/task_dlq.py` (done) | Prevents lost work |
| 8 | Feature flags with env profiles | `args/feature_flags.yaml` (done) | Safer deployments |
| 9 | SLSA Level 2 with Sigstore | `.github/workflows/slsa-build.yml` | Supply chain security |
| 10 | Snapshot tests for compliance artifacts | `tests/test_compliance_snapshots.py` | Catches regressions |

### Tier 3: Medium Impact, Medium-High Effort

| # | Action | Files | Impact |
|---|--------|-------|--------|
| 11 | Extract ADRs from CLAUDE.md | `docs/adr/` directory | Improves discoverability |
| 12 | DI container adoption | `tools/core/container.py` (done) | Test isolation |
| 13 | Degradation matrix | `args/degradation_matrix.yaml` (done) | Documents failure modes |
| 14 | OTel GenAI semantic conventions | `tools/observability/otel_conventions.py` | Standardized tracing |
| 15 | LLM evaluation framework (DeepEval) | `tests/evals/` | Narrative quality assurance |

### Tier 4: Strategic (Plan and Execute Over Time)

| # | Action | Files | Impact |
|---|--------|-------|--------|
| 16 | Chaos engineering with LitmusChaos | K8s manifests | Production resilience validation |
| 17 | ArgoCD GitOps deployment | `argocd/` directory | Drift detection, audit trail |
| 18 | Secret resolver (AWS + Vault) | `tools/db/secret_resolver.py` | Multi-environment secrets |
| 19 | Auto-generate API docs from MCP | `tools/docs/mcp_doc_generator.py` | Self-documenting system |
| 20 | Mutation testing on rule engines | CI pipeline config | Test suite quality assurance |

### Already Delivered During This Research

| File | Purpose |
|------|---------|
| `tools/core/__init__.py` | Package init |
| `tools/core/errors.py` | 14-class structured error hierarchy |
| `tools/core/circuit_breaker.py` | Thread-safe circuit breaker with config |
| `tools/core/container.py` | Lightweight DI container |
| `tools/core/task_dlq.py` | Dead letter queue with retry |
| `args/pipeline_gates.yaml` | Declarative pipeline gate definitions |
| `args/feature_flags.yaml` | Feature flags with env profiles |
| `args/degradation_matrix.yaml` | Graceful degradation rules |
| `tests/test_core_errors.py` | 16 tests for error hierarchy |
| `tests/test_circuit_breaker.py` | 17 tests for circuit breaker |
| `tests/test_container.py` | 9 tests for DI container |
| `tests/test_task_dlq.py` | 8 tests for DLQ |
| `tests/contracts/__init__.py` | Contract tests package |
| `tests/contracts/test_agent_contracts.py` | 27 tests for 9 agent contracts |

**Total: 14 files, 81 passing tests**

---

## 8. Sources

### Testing AI-Agentic Systems
- [AI Agents, meet Test Driven Development (Latent Space)](https://www.latent.space/p/anita-tdd)
- [Red/green TDD - Agentic Engineering Patterns (Simon Willison)](https://simonwillison.net/guides/agentic-engineering-patterns/red-green-tdd/)
- [From Scenario to Finished: Domain-Driven TDD for AI Agents (LangWatch)](https://langwatch.ai/blog/from-scenario-to-finished-how-to-test-ai-agents-with-domain-driven-tdd)
- [An Empirical Evaluation of Property-Based Testing in Python (OOPSLA 2025)](https://cseweb.ucsd.edu/~mcoblenz/assets/pdf/OOPSLA_2025_PBT.pdf)
- [Agentic Property-Based Testing (arXiv 2025)](https://arxiv.org/html/2510.09907v1)
- [Semantic Similarity is Nuanced but Not Difficult (Agent CI)](https://agent-ci.com/blog/2025/10/08/semantic-similarity-nuanced-not-difficult/)
- [AI Agent Evaluation: 5 Lessons Learned (Monte Carlo Data)](https://www.montecarlodata.com/blog-ai-agent-evaluation/)
- [Beyond Task Completion: Assessing Agentic AI Systems (arXiv 2025)](https://arxiv.org/html/2512.12791v1)

### LLM Evaluation Frameworks
- [LLM Evaluation Landscape 2026 (AIM Research)](https://research.aimultiple.com/llm-eval-tools/)
- [DeepEval: LLM Evaluation Framework (GitHub)](https://github.com/confident-ai/deepeval)
- [G-Eval: LLM-as-a-Judge Guide (Confident AI)](https://www.confident-ai.com/blog/g-eval-the-definitive-guide)
- [LLM-as-a-Judge Complete Guide (Langfuse)](https://langfuse.com/docs/evaluation/evaluation-methods/llm-as-a-judge)
- [LLM Rubric Evaluation (Promptfoo)](https://www.promptfoo.dev/docs/configuration/expected-outputs/model-graded/llm-rubric/)
- [OpenEvals by LangChain (GitHub)](https://github.com/langchain-ai/openevals)

### Contract Testing
- [Contract Testing: Shifting Left with Confidence (Tweag)](https://www.tweag.io/blog/2025-01-23-contract-testing/)
- [Contract Testing for Microservices Guide (HyperTest)](https://www.hypertest.co/contract-testing/contract-testing-for-microservices)
- [Pact Testing Explained (BaseRock AI)](https://www.baserock.ai/blog/pact-testing)

### Snapshot Testing
- [Snapshot Testing with Syrupy (Simon Willison TIL)](https://til.simonwillison.net/pytest/syrupy)
- [Syrupy: Sweeter Pytest Snapshot Plugin (GitHub)](https://github.com/syrupy-project/syrupy)

### DevSecOps and cATO
- [DoD cATO Evaluation Criteria (PDF)](https://dodcio.defense.gov/Portals/0/Documents/Library/cATO-EvaluationCriteria.pdf)
- [DoD Continuous Authorization Implementation Guide (PDF)](https://dodcio.defense.gov/Portals/0/Documents/Library/DoDCIO-ContinuousAuthorizationImplementationGuide.pdf)
- [cATO Needs a DevSecOps Platform (VMware Tanzu)](https://blogs.vmware.com/tanzu/continuous-authorization-to-operate-cato-needs-a-devsecops-platform/)
- [Unpacking DoD cATO Part IV: SSSC and DevSecOps (BreakPoint Labs)](https://breakpoint-labs.com/unpacking-the-dod-continuous-authorization-to-operate-cato-evaluation-criteria-part-iv-secure-software-supply-chain-sssc-and-devsecops/)
- [DevSecOps Trends 2026 (DebugLies)](https://debuglies.com/2026/01/07/devsecops-trends-2026-ai-agents-revolutionizing-secure-software-development/)
- [DevSecOps for Defense (Lasting Dynamics)](https://www.lastingdynamics.com/blog/devsecops-agile-defense-military-software-development/)
- [How MOSA Principles Will Reshape DoD RMF (Sonatype)](https://www.sonatype.com/blog/how-mosa-principles-will-reshape-the-dod-rmf)

### SLSA and Supply Chain Security
- [SLSA Framework Guide (Practical DevSecOps)](https://www.practical-devsecops.com/slsa-framework-guide-software-supply-chain-security/)
- [SLSA Security Levels (slsa.dev)](https://slsa.dev/spec/v0.1/levels)
- [Supply Chain Security 2025: SBOMs, SLSA, Sigstore (Faith Forge Labs)](https://faithforgelabs.com/blog_supplychain_security_2025.php)
- [Supply Chain Security Trifecta: SBOM, SLSA, SSDF (Petronella)](https://petronellatech.com/blog/the-supply-chain-security-trifecta-sbom-slsa-ssdf/)

### Clean Architecture and Code Quality
- [Python Design Patterns for Clean Architecture 2025 (Glukhov)](https://www.glukhov.org/post/2025/11/python-design-patterns-for-clean-architecture/)
- [Clean Architecture with Python (Packt/O'Reilly 2025)](https://www.oreilly.com/library/view/clean-architecture-with/9781836642893/)
- [Pragmatic Clean Architecture in Python (Deep Engineering)](https://deepengineering.substack.com/p/pragmatic-clean-architecture-in-python)
- [Technical Debt Management (DasRoot 2026)](https://dasroot.net/posts/2026/02/technical-debt-management-sonarqube-cicd/)
- [How to Manage Tech Debt in the AI Era (MIT Sloan)](https://sloanreview.mit.edu/article/how-to-manage-tech-debt-in-the-ai-era/)

### OpenTelemetry
- [OTel Semantic Conventions for GenAI Agent Spans](https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-agent-spans/)
- [AI Agent Observability Standards (OTel Blog 2025)](https://opentelemetry.io/blog/2025/ai-agent-observability/)
- [OTel Observability 2026 Complete Guide (CalmOps)](https://calmops.com/devops/opentelemetry-observability-2026-complete-guide/)
- [OTel Best Practices (Better Stack)](https://betterstack.com/community/guides/observability/opentelemetry-best-practices/)
- [OTel Python Instrumentation Guide](https://opentelemetry.io/docs/languages/python/instrumentation/)

### GitOps
- [ArgoCD in the Federal Trenches (AlphaBravo)](https://blog.alphabravo.io/argocd-in-the-federal-trenches-when-uncle-sam-meets-gitops/)
- [GitOps 2026 Complete Guide (CalmOps)](https://calmops.com/devops/gitops-2026-complete-guide/)
- [ArgoCD vs FluxCD 2025 (AWS Plain English)](https://aws.plainenglish.io/argocd-vs-flux-in-2025-the-gitops-war-is-over-and-you-won-d22e084929a5)

### Resilience Engineering
- [Building Resilient Systems: Circuit Breakers and Retry (DasRoot 2026)](https://dasroot.net/posts/2026/01/building-resilient-systems-circuit-breakers-retry-patterns/)
- [Resilient Microservices: Recovery Patterns Survey (arXiv 2025)](https://arxiv.org/html/2512.16959v1)
- [Circuit Breaker with Bulkhead Isolation (GeeksforGeeks)](https://www.geeksforgeeks.org/system-design/circuit-breaker-with-bulkhead-isolation-in-microservices/)
- [Dead Letter Queues and Retry Queues (Medium)](https://medium.com/@vinay.georgiatech/dead-letter-queues-and-retry-queues-the-safety-net-for-distributed-systems-b961c718e6a0)
- [Retry Logic with Exponential Backoff in Python (OneUptime)](https://oneuptime.com/blog/post/2025-01-06-python-retry-exponential-backoff/view)
- [Tenacity: Jitter, Backoff, and Idempotency (Medium 2025)](https://medium.com/@hadiyolworld007/python-retry-policies-with-tenacity-jitter-backoff-and-idempotency-that-survives-chaos-12bba4fc8d32)
- [Exponential Backoff with Jitter (Presidio)](https://www.presidio.com/technical-blog/exponential-backoff-with-jitter-a-powerful-tool-for-resilient-systems/)

### Chaos Engineering
- [LitmusChaos (GitHub/CNCF)](https://github.com/litmuschaos/litmus)
- [Chaos Mesh (GitHub/CNCF)](https://github.com/chaos-mesh/chaos-mesh)
- [Chaos Engineering in the Wild (arXiv 2025)](https://arxiv.org/html/2505.13654v1)
- [Chaos Mesh + Testkube Integration (Testkube)](https://testkube.io/blog/orchestrating-chaos-engineering-with-testkube-and-chaos-mesh)

### Configuration Management
- [ADR Best Practices (AWS Architecture Blog 2025)](https://aws.amazon.com/blogs/architecture/master-architecture-decision-records-adrs-best-practices-for-effective-decision-making/)
- [ADR Process (AWS Prescriptive Guidance)](https://docs.aws.amazon.com/prescriptive-guidance/latest/architectural-decision-records/adr-process.html)
- [Maintain ADRs (Azure Well-Architected Framework)](https://learn.microsoft.com/en-us/azure/well-architected/architect-role/architecture-decision-record)
- [Feature Flag Tools for Enterprises 2025 (Flagsmith)](https://www.flagsmith.com/blog/top-7-feature-flag-tools)
- [Open-Source Feature Flag Tools (Unleash)](https://www.getunleash.io/blog/11-open-source-feature-flag-tools)
- [HashiCorp Vault vs AWS Secrets Manager 2026 (Infisical)](https://infisical.com/blog/aws-secrets-manager-vs-hashicorp-vault)
- [Alembic Schema Migration Best Practices (PingCAP)](https://www.pingcap.com/article/best-practices-alembic-schema-migration/)
- [Alembic Batch Migrations for SQLite (Alembic Docs)](https://alembic.sqlalchemy.org/en/latest/batch.html)

### API Documentation
- [OpenAPI Generator (GitHub)](https://github.com/OpenAPITools/openapi-generator)
- [API Documentation Tools 2025 (Mintlify)](https://www.mintlify.com/blog/best-api-documentation-tools-of-2025)
- [API Docs and SDK Generation (Fern 2025)](https://buildwithfern.com/post/api-documentation-sdk-generation-tools)
