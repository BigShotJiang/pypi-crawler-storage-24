# CodeLens/Pro: Container & K8s Deployment Validation Research

**CUI // SP-CTI**
**Date:** 2026-03-11
**Purpose:** Research findings for building a shift-left container/K8s validation tool that catches deployment issues before they reach air-gapped production environments.

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Air-Gapped Container Gotchas](#2-air-gapped-container-gotchas)
3. [Kubernetes Deployment Failures](#3-kubernetes-deployment-failures)
4. [Cross-Platform Build Issues](#4-cross-platform-build-issues)
5. [Compliance, STIG & Governance](#5-compliance-stig--governance)
6. [Shift-Left Tooling Landscape](#6-shift-left-tooling-landscape)
7. [Recommended Architecture for CodeLens/Pro](#7-recommended-architecture-for-codelens-pro)
8. [Gap Analysis](#8-gap-analysis)

---

## 1. Executive Summary

Developers build on Windows/macOS, deploy to hardened Linux containers in air-gapped government clouds. This transition introduces **5 categories of failure**:

| Category | Examples | Detection Difficulty |
|----------|----------|---------------------|
| **Platform mismatch** | CRLF line endings, case-sensitive imports, musl vs glibc | Easy (static analysis) |
| **Air-gap breakage** | Package managers reaching internet, telemetry phone-home, DNS timeouts | Medium (network simulation) |
| **K8s misconfiguration** | Missing NetworkPolicy, env var ordering, storage class mismatch | Medium (policy validation) |
| **Compliance violations** | Root user, no FIPS crypto, missing SBOM, STIG findings | Medium (automated checking) |
| **Runtime failures** | OOMKilled, init container races, PgBouncer + migrations | Hard (requires integration test) |

**Key insight:** ~70% of deployment failures can be caught with static analysis (< 15 seconds). Another ~20% require building the image and validating it (< 60 seconds). Only ~10% require a running cluster to detect.

---

## 2. Air-Gapped Container Gotchas

### 2.1 Alpine vs Debian — musl vs glibc

Alpine uses musl libc. This causes silent, hard-to-diagnose failures:

**Python wheel incompatibility:**
```
ERROR: Could not find a version that satisfies the requirement numpy==1.24.3
```
PyPI wheels compiled against glibc (`manylinux2014_x86_64`) don't work on Alpine (`musllinux_1_1_x86_64`). Many packages don't publish musl wheels, forcing source compilation that requires build tools and adds 10+ minutes to builds.

**musl DNS resolver:**
- Does NOT use `/etc/nsswitch.conf`
- Sends ALL A/AAAA queries simultaneously (may return IPv6 when IPv4 expected)
- Hardcoded 5-second DNS timeout with no retry (glibc does exponential backoff)
- In air-gapped K8s where CoreDNS may be slow, produces `socket.gaierror: Name or service not known`

**Recommendation for DoD:** Use `python:3.12-slim-bookworm` (Debian, glibc) as default. Alpine only for Go static binaries. For IL4+, use Iron Bank hardened base images.

### 2.2 Registry Mirroring

**Digest mismatches:** When mirroring with tools that re-sign or re-compress layers, the manifest digest changes. Images pinned by digest (`image@sha256:abc...`) fail to pull from the mirror.

**Multi-arch manifest list breakage:** Some mirror tools only copy single-arch manifests, breaking the fat manifest. Fix: always use `skopeo copy --all` or `crane copy --all-tags`.

**Harbor replication gotcha:** Harbor's built-in replication sometimes silently fails on large images. A "success" status doesn't guarantee all layers transferred. Always verify with a pull test.

### 2.3 Package Manager Phone-Home

Even after building, `apt`/`apk` leave repo configs in place. Any init script running `apt-get update` hangs for 30+ seconds trying to reach `deb.debian.org`:

```dockerfile
# Fix: Remove repo configs after install
RUN apt-get update && apt-get install -y --no-install-recommends \
    curl ca-certificates \
    && rm -rf /var/lib/apt/lists/* \
    && rm -f /etc/apt/sources.list.d/* \
    && echo "" > /etc/apt/sources.list
```

### 2.4 Telemetry & Phone-Home Endpoints

| Software | Phone-home behavior | Disable with |
|----------|---------------------|--------------|
| .NET | CLI telemetry | `DOTNET_CLI_TELEMETRY_OPTOUT=1` |
| pip | Version check | `PIP_DISABLE_PIP_VERSION_CHECK=1` |
| npm | Audit + update notifier | `NPM_CONFIG_AUDIT=false` |
| Terraform | Checkpoint | `CHECKPOINT_DISABLE=1` |
| Next.js | Telemetry | `NEXT_TELEMETRY_DISABLED=1` |
| Node.js | Various postinstall scripts | `npm_config_build_from_source=true` |
| Cargo/Rust | crates.io index | Pre-vendor with `cargo vendor` |

**CodeLens/Pro check:** Run container with `--network none` and scan for connection errors.

### 2.5 Time/NTP & Certificate Failures

Air-gapped environments have no NTP server. Clock drift causes TLS handshake failures:
```
ssl.SSLCertVerificationError: certificate is not yet valid
```

Also breaks JWT validation (expired tokens, future `iat` claims). Never work around with `verify=False` -- that's a STIG CAT I finding.

### 2.6 DNS in Air-Gapped K8s

**CoreDNS:** Default Corefile includes `forward . /etc/resolv.conf` which tries upstream DNS. In air-gapped, this causes 5-second timeouts per lookup. Fix: remove the forward stanza.

**ndots:5 default:** A lookup for `internal-api` generates 4 failed search domain expansions before resolving. Each upstream timeout is 5 seconds. Fix: set `ndots: 2` and use FQDNs with trailing dots.

### 2.7 Certificate Chains

**Custom CA not trusted:** Air-gapped environments use internal CA (DoD PKI). Containers don't have this CA in trust store. Must inject per-language:

| Language | Env var / Fix |
|----------|--------------|
| Python | `REQUESTS_CA_BUNDLE=/etc/ssl/certs/ca-certificates.crt` |
| Java | `keytool -importcert -trustcacerts -cacerts` |
| Node.js | `NODE_EXTRA_CA_CERTS=/etc/ssl/certs/internal-ca.pem` |
| Go | `SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt` |

### 2.8 Locale/Timezone

Slim images strip locale data. Python crashes with `locale.Error: unsupported locale setting`. Fix:
```dockerfile
ENV LANG=C.UTF-8
ENV PYTHONIOENCODING=utf-8
```

### 2.9 The Air-Gap Simulation Test

```bash
docker run \
  --network none \
  --dns 127.0.0.1 \
  --read-only \
  --tmpfs /tmp:size=100M \
  --user 1001:1001 \
  --cap-drop ALL \
  myapp:test
```
If the container starts and passes health checks under these conditions, it's air-gap ready.

---

## 3. Kubernetes Deployment Failures

### 3.1 Helm Chart Gotchas

**Values.yaml path mismatch:** Override file has wrong key path -- silently creates new top-level key instead of overriding nested value. Fix: always `helm template` to verify rendered output.

**CRD race conditions:** Chart depends on another chart's CRDs that don't exist yet. Fix: two-phase install (CRD-providing charts first).

**Hook weight sorting:** Lexicographic, not numeric. `"10"` sorts before `"2"`. Fix: zero-padded weights (`"001"`, `"002"`).

### 3.2 Resource Limits

**OOMKilled silent killers:**
- Java: JVM heap defaults to 25% of *node* RAM, not container limit (64GB node + 512Mi limit = 16GB heap attempt)
- Go: `GOMAXPROCS` defaults to node CPU count, not container limit
- Fix: always set `JAVA_OPTS=-XX:MaxRAMPercentage=75.0`, `GOMAXPROCS`, `GOMEMLIMIT`

**CPU throttling:** No restarts, no events -- pods just become slow. Detect via `nr_throttled` in cgroup stats.

### 3.3 NetworkPolicy

**Default-deny missing:** Without explicit deny-all NetworkPolicy, ALL traffic is allowed -- ZTA violation for IL4+.

**DNS egress blocked:** The #1 NetworkPolicy mistake. Apply egress deny-all and nothing resolves because CoreDNS port 53 is blocked. Always include DNS egress rule.

**CNI enforcement differences:**
| CNI | NetworkPolicy Support |
|-----|----------------------|
| Calico | Full (including egress, CIDR) |
| Cilium | Full (plus L7 HTTP) |
| AWS VPC CNI (EKS) | Requires Calico addon |
| Azure CNI (AKS) | Requires flag at cluster creation |
| Flannel | **None** (silently ignored) |

### 3.4 SecurityContext

**Restricted PSS minimum (required for IL4+):**
```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: true
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**readOnlyRootFilesystem breakers:**

| Application | Writable paths needed |
|-------------|----------------------|
| Nginx | `/var/cache/nginx`, `/var/run`, `/tmp` |
| Python/pip | `/tmp`, `/.cache` |
| Java/Spring | `/tmp` (Tomcat work dir) |
| PostgreSQL | `/var/run/postgresql` |
| Node.js | `/tmp`, `/home/node/.npm` |

### 3.5 Image Pull in Air-Gap

- `imagePullPolicy: Always` fails (no registry connectivity)
- `imagePullPolicy: IfNotPresent` caches stale images if tags are mutable
- Fix: use immutable digest references + `IfNotPresent`

### 3.6 Env Var Ordering

`$(DB_USER)` substitution uses already-defined env vars *in order*. If `DB_USER` is defined AFTER `DATABASE_URL`, the substitution silently produces empty string. **No error, no restart -- just wrong connection string.**

### 3.7 Multi-Cloud K8s Differences

| Feature | EKS | AKS | GKE | RKE2 | OpenShift |
|---------|-----|-----|-----|------|-----------|
| Default CNI | VPC CNI | Azure CNI | GKE CNI | Canal | OVN-K8s |
| NetworkPolicy | Needs addon | Needs flag | Native | Native | Native |
| Pod Security | PSS | PSS | PSS | PSS (restricted default) | SCC (not PSS) |
| Ingress | ALB Controller | AGIC | GCE Ingress | Nginx | Routes |
| Storage | EBS/EFS CSI | Azure Disk/Files | PD CSI | Longhorn | OCS |
| Gov region | GovCloud | Azure Gov | FedRAMP regions | Self-hosted | Self-hosted |
| STIG flags | Limited (managed) | Limited | Limited | Full access | Full access |

**GovCloud ARN gotcha:** AWS GovCloud uses `arn:aws-us-gov:` prefix, not `arn:aws:`.

**OpenShift uses SCC (Security Context Constraints), not PSS.** Cannot use `restricted` PSS labels.

**RKE2 default is `restricted` PSS** -- many public Helm charts fail without modification.

### 3.8 Database Migration in K8s

**PgBouncer transaction pooling breaks:** Advisory locks, prepared statements, SET commands, LISTEN/NOTIFY, temporary tables. Migrations must bypass PgBouncer and connect directly to PostgreSQL.

**PostgreSQL major version upgrade:** Cannot change image tag from `postgres:14` to `postgres:16` with same PV. Requires `pg_dump`/restore to new PV.

**Concurrent migration protection:** Use PostgreSQL advisory locks (`pg_try_advisory_lock(1)`) to prevent multiple migration pods running simultaneously.

---

## 4. Cross-Platform Build Issues

### 4.1 Windows to Linux

**CRLF line endings:** The #1 cross-platform Docker failure.
```
/bin/bash^M: bad interpreter: No such file or directory
```
Fix: `.gitattributes` with `*.sh text eol=lf`, `Dockerfile text eol=lf`.

**File permissions lost:** Windows NTFS doesn't store Unix permission bits. `COPY` arrives as 0644. Fix: `COPY --chmod=755` (requires BuildKit) or explicit `RUN chmod +x`.

**Case-insensitive filenames:** `from Utils import helper` works on Windows, fails on Linux where directory is `utils/`. Fix: enforce consistent casing in CI.

**UTF-8 BOM in .dockerignore:** Windows editors may save with BOM (`\xEF\xBB\xBF`), making first ignore pattern not match.

### 4.2 Multi-Arch Builds

**QEMU emulation failures:** Segfaults during C extension compilation, Go `mlock` failures, 5-10x slower builds. No single tool catches all QEMU issues.

**Cross-compilation pattern (Go):**
```dockerfile
FROM --platform=$BUILDPLATFORM golang:1.22 AS builder
ARG TARGETARCH TARGETOS
RUN GOOS=$TARGETOS GOARCH=$TARGETARCH go build -o /app .
```
10x faster than QEMU emulation.

**Python has no easy cross-compilation path.** Must use pre-built wheels (`--only-binary :all:`) or build natively on target arch.

**Manifest list gotcha:** `docker tag` + `docker push` replaces multi-arch manifest list with single-platform image.

### 4.3 Build Reproducibility

**Non-deterministic `apt-get`:** Different versions installed on different days. Fix: pin by digest + pin package versions.

**Cache-busting `COPY . /app/`:** Any source code change invalidates pip/npm install cache. Fix: copy dependency files first, install, then copy source.

### 4.4 SQLite Dev vs PostgreSQL Prod

Directly relevant to ICDEV (D-DB-20). Key syntax differences:

| Feature | SQLite | PostgreSQL |
|---------|--------|-----------|
| Placeholder | `?` | `%s` |
| UPSERT | `INSERT OR REPLACE` | `INSERT ... ON CONFLICT DO UPDATE` |
| LIKE | Case-insensitive | Case-sensitive (use `ILIKE`) |
| Type enforcement | Dynamic | Strict |
| JSON | `json_extract(col, '$.key')` | `col->>'key'` |

ICDEV's `StorageConnection` wrapper (D-DB-23) handles placeholder translation, but other syntax differences may still leak through.

---

## 5. Compliance, STIG & Governance

### 5.1 DISA Container Platform SRG -- Key CAT I Findings

| Finding | Requirement | Severity |
|---------|------------|----------|
| No default/shared service accounts with elevated privileges | Dedicated SA per workload | CAT I |
| No privileged containers without approval | `privileged: false` | CAT I |
| TLS 1.2+ for management plane | API server TLS config | CAT I |
| etcd encryption at rest with FIPS crypto | `--encryption-provider-config` | CAT I |
| API server anonymous auth disabled | `--anonymous-auth=false` | CAT I |

### 5.2 DISA Kubernetes STIG (V2R3, Feb 2025) -- Critical Checks

**API Server:**
- `--anonymous-auth=false` (CAT I)
- `--authorization-mode` includes `RBAC`, NOT `AlwaysAllow` (CAT I)
- `--audit-log-path`, `--audit-log-maxage=30`, `--audit-log-maxbackup=10` (CAT II)

**etcd:**
- Encryption provider must use `aescbc`, `aesgcm`, or `kms` (not `identity`) (CAT I)
- Peer TLS and client TLS with cert auth (CAT II)

**Kubelet:**
- `--anonymous-auth=false` (CAT I)
- `--authorization-mode=Webhook` (CAT I)
- `--read-only-port=0` (CAT II)

**Managed K8s gotcha:** EKS/AKS/GKE don't expose all API server flags. Must document compensating controls. RKE2 is the most STIG-compliant managed distribution.

### 5.3 FIPS 140-2/3

| Base Image | FIPS Status |
|-----------|-------------|
| RHEL/UBI 8/9 | Validated |
| Ubuntu Pro | Validated |
| Chainguard | In process |
| Alpine | **Not validated** (musl + LibreSSL) |
| Distroless | **Not validated** |

**What breaks under FIPS:**
- MD5 disabled (breaks legacy protocols, package checksums, etag generation)
- Python `hashlib.md5()` throws `ValueError` (unless `usedforsecurity=False`)
- Some TLS cipher suites unavailable
- SSH key exchange restricted
- Many test frameworks fail (use MD5 for test identification)

**Language-specific:**
- **Go:** Standard `crypto/tls` is NOT FIPS-compliant. Use `golang-fips/go` or `GOEXPERIMENT=boringcrypto`
- **Python:** Inherits from host OpenSSL if FIPS mode enabled at OS level
- **Node.js:** `--enable-fips` flag; many npm packages bypass OpenSSL

### 5.4 Container Image Hardening (DoD Guide v1.2)

1. No package managers in production (remove `apt`, `yum`, `apk`)
2. No shells (`/bin/sh`, `/bin/bash`) -- use distroless
3. Non-root execution (`USER` != 0)
4. Read-only root filesystem
5. No SUID/SGID binaries
6. Drop ALL capabilities
7. No `latest` tag -- immutable digest or specific version
8. Multi-stage builds (build deps don't leak to runtime)

### 5.5 Supply Chain Security

| SLSA Level | Requirements | DoD Relevance |
|------------|-------------|---------------|
| SLSA 0 | No guarantees | Non-compliant |
| SLSA 1 | Documented build process | Minimum for IL2 |
| SLSA 2 | Signed provenance | Required for IL4 |
| SLSA 3 | Verified source, isolated builds | Required for IL5+ |

**Air-gapped Sigstore gotcha:** Fulcio and Rekor require internet. Must run private Sigstore instance or use long-lived signing keys.

### 5.6 Vulnerability Scanning Thresholds

| Severity | Iron Bank Policy | Typical AO Policy |
|----------|-----------------|-------------------|
| Critical (CVSS 9.0+) | Block | Block |
| High (CVSS 7.0-8.9) | Block (30-day window) | Block or POA&M |
| Medium (CVSS 4.0-6.9) | Warn (90-day window) | POA&M |
| Low | Track | Accepted risk |

### 5.7 cATO vs Traditional ATO

**Traditional:** Point-in-time every 3 years, paper-heavy (500+ pages).

**cATO (DoD CIO Feb 2022):** Requires continuous monitoring, active cyber defense, secure supply chain. OSCAL format for machine-readable evidence. AO still required but relies on dashboards instead of paper.

### 5.8 Government Container Registries

| Component | Purpose |
|-----------|---------|
| Repo One (`repo1.dso.mil`) | GitLab with container source/Dockerfiles |
| Iron Bank (`registry1.dso.mil`) | Hardened container image registry |
| Platform One (`p1.dso.mil`) | DevSecOps platform |
| Big Bang | Flux-based K8s deployment with pre-hardened configs |

**Big Bang** is the easiest path to STIG-compliant K8s -- deploys Istio, Prometheus, Grafana, Fluentd, OPA, Twistlock, Keycloak pre-configured.

### 5.9 Multi-Cloud Compliance

| Certification | AWS GovCloud | Azure Gov | Google Cloud | Oracle Gov |
|--------------|-------------|-----------|-------------|------------|
| FedRAMP High | Yes | Yes | Yes | Yes |
| DoD IL4 | Yes | Yes | Yes | Yes |
| DoD IL5 | Yes | Yes | Yes | Yes |
| DoD IL6 (Secret) | Yes | Yes | Limited | Yes |
| Top Secret | Yes | Yes | No | Unknown |
| FIPS 140-2/3 KMS | Validated | Validated | Validated | Validated |

**FedRAMP High != DoD IL5.** IL5 adds NIPRNet connectivity requirement via BCAP/DREN.

---

## 6. Shift-Left Tooling Landscape

### 6.1 Tool Coverage Matrix

| Layer | Tool | What it covers | Speed | ICDEV Integration |
|-------|------|---------------|-------|-------------------|
| Dockerfile | **Hadolint** | Best practices, ShellCheck | <1s | New |
| K8s schema | **kubeconform** | API correctness | <1s | New |
| K8s security | **kube-linter** | Security + prod-readiness | <2s | New |
| K8s policy | **Kyverno CLI** | Custom org policies | <3s | Extends existing `policy_generator.py` |
| API deprecation | **Pluto** | Removed/deprecated APIs | <1s | New |
| Helm | **helm lint + template** | Structure + rendering | <2s | New |
| Config policy | **Conftest** | Dockerfile/Terraform/misc OPA | <2s | Extends existing OPA |
| Secrets | **Trivy fs** | Leaked secrets in source | <5s | Extends existing `secret_detector.py` |
| Image vulns | **Trivy/Grype** | CVEs in built image | ~15s | Extends existing `container_scanner.py` |
| Image structure | **container-structure-test** | Files, user, ports | <5s | New |
| SBOM | **Syft** | Dependency inventory | <10s | Extends existing `sbom_generator.py` |
| STIG | **OpenSCAP** | Automated STIG checks | ~30s | New |

### 6.2 Ideal Pipeline (< 60 seconds)

```
PHASE 1: Static Analysis (parallel, ~5s)
  hadolint Dockerfile
  kubeconform k8s/**/*.yaml
  kube-linter k8s/**/*.yaml
  kyverno apply --policy policies/ --resource k8s/
  pluto detect-files -d k8s/
  helm lint + helm template | kubeconform
  conftest test Dockerfile --policy policy/docker/
  trivy fs --scanners secret .
  CRLF / case-sensitivity / permission checks (custom)
  Air-gap dependency manifest check (custom)

PHASE 2: Build (sequential, ~20s)
  docker build -t app:local .
  helm template → kubeconform rendered output

PHASE 3: Image Validation (parallel, ~15s)
  trivy image --severity HIGH,CRITICAL app:local
  container-structure-test --image app:local
  dockle app:local
  syft app:local → sbom.json
  FIPS crypto check (custom)

PHASE 4: Air-Gap Simulation (~15s)
  docker run --network none --read-only --user 1001 --cap-drop ALL app:local
  Verify health checks pass
  Check for connection/timeout errors in logs

PHASE 5: Integration (optional, ~60s, CI only)
  kind create cluster (with Calico for NetworkPolicy)
  kubectl apply manifests
  Wait for rollout
  Smoke test health endpoints
  NetworkPolicy enforcement verification
  kind delete cluster
```

### 6.3 Gaps No Existing Tool Covers

1. **Air-gap completeness:** No tool verifies ALL image references in all manifests are available in mirror registry
2. **Cross-resource consistency:** Service selectors matching Deployment labels
3. **FIPS crypto chain:** No tool validates complete FIPS 140-3 chain
4. **Init container ordering:** Schema-valid but logically wrong
5. **PgBouncer + migration compatibility:** Requires runtime testing
6. **Multi-cloud manifest portability:** Annotations, storage classes, ARN prefixes
7. **Env var ordering correctness:** Silent substitution failures
8. **Helm values completeness:** Dead values, missing defaults

---

## 7. Recommended Architecture for CodeLens/Pro

### 7.1 Design Principles

1. **Deterministic first** -- all checks are rule-based, no LLM in critical path (GOTCHA D-WG-2 pattern)
2. **Scanner-tier only** -- zero Claude tokens for validation (cost-effective, air-gap safe)
3. **Progressive disclosure** -- Phase 1-3 always run; Phase 4-5 opt-in
4. **Multi-cloud aware** -- checks adapt to target CSP (EKS vs AKS vs RKE2 vs OpenShift)
5. **STIG-profile driven** -- DoD customers get STIG checks; commercial customers get CIS checks
6. **Offline capable** -- vulnerability DBs cached locally, no internet required at scan time

### 7.2 Check Categories (~120 total checks)

**Category A: File Hygiene (15 checks)**
- A-01: CRLF line endings in .sh, Dockerfile, .dockerignore, .env
- A-02: Shell scripts without execute permission
- A-03: Case-insensitive filename collisions
- A-04: UTF-8 BOM in config files
- A-05: Symlinks in build context pointing outside
- A-06: .dockerignore missing or ineffective
- A-07: Secrets in build context (.env, credentials, keys)
- A-08: Large files in build context (>100MB)
- A-09: Windows path separators in Dockerfile
- A-10: Backslash line continuations vs Unix conventions
- A-11: .gitattributes eol=lf for critical files
- A-12: Hardcoded localhost/127.0.0.1 URLs
- A-13: Hardcoded external URLs (telemetry, registries)
- A-14: Pinned base image (digest or specific tag, not `latest`)
- A-15: Multi-stage COPY --from references valid

**Category B: Dockerfile Quality (20 checks)**
- B-01: Package versions pinned (apt, pip, npm)
- B-02: `--no-cache-dir` on pip install
- B-03: `--no-install-recommends` on apt-get
- B-04: Layer ordering (deps before source)
- B-05: Non-root USER directive
- B-06: No SUID/SGID binaries
- B-07: Package managers removed after install
- B-08: Shells removed (distroless or explicit removal)
- B-09: HEALTHCHECK defined
- B-10: Build args vs env vars correct usage
- B-11: No `ADD` for remote URLs (use `COPY` + `RUN curl`)
- B-12: Multi-stage build deps not leaking to runtime
- B-13: Shared library dependencies satisfied in runtime stage
- B-14: Locale/timezone data present
- B-15: CA certificates injected for internal PKI
- B-16: Telemetry opt-out env vars set
- B-17: Repo configs removed after package install
- B-18: pip `requirements.txt` uses `==` not `>=`
- B-19: npm uses `npm ci` not `npm install`
- B-20: FIPS-compatible base image (if IL4+)

**Category C: K8s Manifest Validation (25 checks)**
- C-01: Schema valid (kubeconform)
- C-02: No deprecated APIs (Pluto)
- C-03: runAsNonRoot: true
- C-04: readOnlyRootFilesystem: true
- C-05: allowPrivilegeEscalation: false
- C-06: capabilities.drop: ["ALL"]
- C-07: seccompProfile: RuntimeDefault
- C-08: Resource requests AND limits set
- C-09: Liveness probe defined
- C-10: Readiness probe defined
- C-11: No hostNetwork/hostPID/hostIPC
- C-12: No privileged: true
- C-13: No default namespace
- C-14: No latest tag in image reference
- C-15: imagePullSecrets configured
- C-16: ServiceAccount specified (not default)
- C-17: No hostPath volumes
- C-18: NetworkPolicy exists in namespace
- C-19: NetworkPolicy includes DNS egress (port 53)
- C-20: Env var ordering correct (deps before dependents)
- C-21: ConfigMap/Secret size < 1MB
- C-22: PVC storage class exists in target cluster
- C-23: Pod topology spread constraints reasonable
- C-24: Init container ordering logical
- C-25: Sidecar container resource limits set

**Category D: Helm Chart Validation (15 checks)**
- D-01: helm lint passes
- D-02: Rendered output passes kubeconform
- D-03: Rendered output passes C-01 through C-25
- D-04: Values.yaml keys all referenced in templates
- D-05: Templates have defaults for all values
- D-06: Hook weights zero-padded
- D-07: CRD dependencies documented
- D-08: Chart.yaml has required metadata
- D-09: Subchart dependencies in charts/ directory
- D-10: No floating chart dependency versions
- D-11: Test hooks defined
- D-12: NOTES.txt present
- D-13: Values schema (values.schema.json) present
- D-14: Multi-cloud annotations parameterized
- D-15: Storage class names parameterized

**Category E: Security & Compliance (25 checks)**
- E-01: Image from approved registry
- E-02: Image signed (Cosign verification)
- E-03: No Critical CVEs (Trivy/Grype)
- E-04: No High CVEs without POA&M
- E-05: SBOM generated (CycloneDX/SPDX)
- E-06: SBOM matches runtime image
- E-07: No secrets in image layers
- E-08: SLSA provenance present (IL4+)
- E-09: FIPS crypto validated (IL4+ DoD)
- E-10: Classification markings present (CUI)
- E-11: Audit logging configuration present
- E-12: Log forwarding configured
- E-13: mTLS configured (if service mesh)
- E-14: etcd encryption configured (cluster check)
- E-15: API server STIG flags (cluster check)
- E-16: Kubelet STIG flags (cluster check)
- E-17: VEX document for known CVEs
- E-18: No world-writable files
- E-19: Secret rotation policy configured
- E-20: TLS certificates valid and not near expiry
- E-21: PV encryption at rest enabled
- E-22: RBAC least-privilege (no cluster-admin for apps)
- E-23: Pod Security Standards enforced on namespace
- E-24: Backup/recovery configuration present
- E-25: Runtime security monitoring active (Falco/Sysdig)

**Category F: Air-Gap Readiness (10 checks)**
- F-01: Build succeeds with `--network none`
- F-02: Container starts with `--network none`
- F-03: Health checks pass with no external connectivity
- F-04: No DNS lookups to external domains
- F-05: All container images available in mirror registry
- F-06: Helm chart dependencies vendored locally
- F-07: No post-install network calls (npm/pip/cargo)
- F-08: Internal CA certificate injected
- F-09: NTP configuration present
- F-10: CoreDNS Corefile has no upstream forward

**Category G: Database Compatibility (10 checks)**
- G-01: PostgreSQL version matches prod
- G-02: No SQLite-specific syntax in migrations
- G-03: Alembic migrations tested against target PG version
- G-04: Migration rollback tested
- G-05: Advisory lock used for concurrent migration protection
- G-06: PgBouncer bypass for migrations
- G-07: SSL/TLS configured for prod database connection
- G-08: Connection string format correct for target
- G-09: No `LIKE` where `ILIKE` needed
- G-10: Schema diff clean (no drift)

### 7.3 Severity Classification

| Level | Gate Behavior | Examples |
|-------|--------------|---------|
| **BLOCK** | Cannot deploy. Must fix. | CAT I STIG, Critical CVE, root user, no NetworkPolicy, FIPS violation |
| **WARN** | Deploy with POA&M. Must plan fix. | CAT II STIG, High CVE, missing probes, unpinned versions |
| **INFO** | Advisory only. Track. | CAT III STIG, Medium CVE, optimization suggestions |

### 7.4 Profile System

| Profile | Target | Active Categories |
|---------|--------|-------------------|
| `commercial` | Non-DoD cloud | A, B, C, D, F (no STIG/FIPS) |
| `fedramp-moderate` | FedRAMP Moderate | A, B, C, D, E (subset), F, G |
| `dod-il4` | DoD IL4 | All categories, STIG + FIPS enabled |
| `dod-il5` | DoD IL5 | All categories, SLSA 3 required |
| `air-gapped` | Any air-gapped | A, B, C, D, F (heavy focus on F) |

---

## 8. Gap Analysis

### What CodeLens/Pro Must Build (Not Available in Existing Tools)

| Gap | Description | Priority |
|-----|-------------|----------|
| Air-gap completeness checker | Aggregate all image refs from Helm + manifests, verify against mirror registry | P0 |
| CRLF/case/permission scanner | Cross-platform file hygiene (no existing tool combines all three) | P0 |
| Env var ordering validator | Parse K8s manifests for `$(VAR)` references and verify ordering | P1 |
| FIPS crypto chain validator | Check OpenSSL version, FIPS mode, language-specific crypto compliance | P1 |
| Multi-cloud manifest portability | Check for hardcoded CSP-specific values (ARNs, storage classes, annotations) | P1 |
| Telemetry/phone-home detector | Scan Dockerfile + source for known phone-home patterns | P2 |
| PgBouncer migration compatibility | Warn if migration scripts use features incompatible with connection pooling | P2 |
| Init container dependency analyzer | Verify init container ordering matches service dependencies | P2 |
| DNS configuration validator | Check CoreDNS config, ndots settings, FQDN usage | P2 |
| Internal CA injection validator | Verify CA certs injected per language runtime | P2 |

### Integration Points with Existing ICDEV Tools

| ICDEV Tool | CodeLens/Pro Integration |
|-----------|-------------------------|
| `container_scanner.py` | Extend with Trivy/Grype integration, FIPS checks |
| `dependency_auditor.py` | Feed into air-gap dependency manifest |
| `sbom_generator.py` | Verify SBOM matches built image |
| `secret_detector.py` | Extend to scan Docker layers |
| `policy_generator.py` (Kyverno) | Generate + validate K8s policies locally |
| `stig_checker.py` | Extend with Container SRG + K8s STIG checks |
| `sbd_assessor.py` | Container hardening maps to SbD requirements |
| `pipeline_security_generator.py` | Inject CodeLens/Pro into generated CI pipelines |
| `crosswalk_engine.py` | Map container checks to NIST/FedRAMP/CMMC controls |

---

## References

### Standards & Guides
- DISA Container Platform SRG (v2, Dec 2020)
- DISA Kubernetes STIG (V2R3, Feb 2025)
- DoD Container Hardening Guide v1.2
- DoD DevSecOps Reference Design v2.0
- NIST SP 800-53 Rev 5 (AU, SC, AC controls)
- NIST SP 800-207 Zero Trust Architecture
- NIST SP 800-204 Series (Microservices Security)
- cATO Implementation Guide (DoD CIO, Feb 2022)
- EO 14028 (Software Supply Chain Security)
- SLSA v1.1 Specification

### Tools
- Hadolint, Dockle, kubeconform, Polaris, kube-linter
- Kyverno, OPA/Gatekeeper, Conftest
- Trivy, Grype, Syft, Snyk
- container-structure-test, Pluto, Nova
- OpenSCAP, Cosign/Sigstore
- Kind, k3d, Skopeo, crane, Harbor
