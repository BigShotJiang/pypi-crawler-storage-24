# CUI // SP-CTI
# Marketplace — Architecture Decision Records

**Total decisions:** 7
**Last updated:** 2026-03-08

| ID | Status | Decision |
|----|--------|----------|
| D-MKT-S1 | Accepted | Marketplace extracted to standalone SaaS (marketplace.icdev.ai) -- ICDEV uses thin client (4 files, ~400 LOC) |
| D-MKT-S2 | Accepted | Two modes: oss (all unlocked, default), saas (token verification) |
| D-MKT-S3 | Accepted | Token verification is 100% offline via RSA-SHA256 public key -- 30-day grace period for air-gap |
| D-MKT-S4 | Accepted | Thin client: module_runtime.py (gating), license_client.py (sync/verify/renew/feedback), token_store.py (local JSON cache) |
| D-MKT-C1 | Accepted | Community-first model: 90-day free activation, unlimited renewals, no SLA |
| D-MKT-C2 | Accepted | Sponsor tiers (platinum/gold/silver/bronze) are recognition badges only -- no feature gating, donations handled externally |
| D-MKT-C3 | Accepted | Renewal = feedback touchpoint: optional survey on each renewal for continuous improvement |

---

## D-MKT-S1: Marketplace extracted to standalone SaaS

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The marketplace needed to operate independently from ICDEV core to scale and serve multiple tenants.
**Decision:** Marketplace extracted to standalone SaaS (marketplace.icdev.ai) -- ICDEV uses thin client (4 files, ~400 LOC)
**Consequences:**
- Marketplace operates as independent service.
- ICDEV uses thin client (4 files, ~400 LOC) for integration.
- Independent scaling and deployment.

---

## D-MKT-S2: Two modes: oss and saas

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The marketplace and community features require clear operational boundaries between open-source and commercial modes.
**Decision:** Two modes: oss (all unlocked, default), saas (token verification)
**Consequences:**
- OSS mode has all features unlocked (default).
- SaaS mode requires token verification for premium features.
- Mode selection via configuration.

---

## D-MKT-S3: Token verification is 100% offline via RSA-SHA256 public key

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The system must operate in air-gapped environments. License verification cannot depend on network connectivity.
**Decision:** Token verification is 100% offline via RSA-SHA256 public key -- 30-day grace period for air-gap
**Consequences:**
- No external network dependencies required for license verification.
- RSA-SHA256 public key embedded in client.
- 30-day grace period allows operation during network outages.

---

## D-MKT-S4: Thin client architecture

**Status:** Accepted
**Date:** 2026-03-08
**Context:** ICDEV's marketplace integration must be minimal to avoid tight coupling with the SaaS platform.
**Decision:** Thin client: module_runtime.py (gating), license_client.py (sync/verify/renew/feedback), token_store.py (local JSON cache)
**Consequences:**
- Four files total for marketplace integration (~400 LOC).
- module_runtime.py handles feature gating.
- license_client.py manages token lifecycle.
- token_store.py provides local caching.

---

## D-MKT-C1: Community-first model

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The marketplace and community features must lower barriers to adoption and encourage community growth.
**Decision:** Community-first model: 90-day free activation, unlimited renewals, no SLA
**Consequences:**
- 90-day free activation period for all users.
- Unlimited renewals maintain free access.
- No SLA commitment for community tier.

---

## D-MKT-C2: Sponsor tiers are recognition badges only

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Sponsorship must not create feature inequality. Recognition-only model preserves community equity.
**Decision:** Sponsor tiers (platinum/gold/silver/bronze) are recognition badges only -- no feature gating, donations handled externally
**Consequences:**
- All features available regardless of sponsor status.
- Sponsor badges provide visibility and recognition.
- Donations handled through external platforms.

---

## D-MKT-C3: Renewal = feedback touchpoint

**Status:** Accepted
**Date:** 2026-03-08
**Context:** License renewal provides a natural touchpoint for gathering user feedback without being intrusive.
**Decision:** Renewal = feedback touchpoint: optional survey on each renewal for continuous improvement
**Consequences:**
- Optional survey presented during renewal.
- Feedback data drives product improvement.
- Non-blocking: survey is skippable.

---
