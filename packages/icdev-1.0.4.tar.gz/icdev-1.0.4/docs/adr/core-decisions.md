# CUI // SP-CTI
# Core Architecture — Architecture Decision Records

**Total decisions:** 20
**Last updated:** 2026-03-08

| ID | Status | Decision |
|----|--------|----------|
| D1 | Superseded | SQLite for internal operational data (zero-config portability) [SUPERSEDED] Superseded by D-DB-20 |
| D2 | Accepted | Stdio for MCP (Claude Code); HTTPS+mTLS for A2A (K8s inter-agent) |
| D4 | Accepted | Statistical methods for pattern detection; Bedrock LLM for root cause analysis |
| D5 | Accepted | CUI markings applied at generation time (inline, not post-processing) |
| D6 | Accepted | Audit trail is append-only/immutable (no UPDATE/DELETE -- NIST AU compliance) |
| D7 | Accepted | Python stdlib xml.etree.ElementTree for XMI/ReqIF parsing (zero deps, air-gap safe) |
| D8 | Accepted | Normalized DB tables for model elements (enables SQL joins across digital thread) |
| D9 | Accepted | M-ATLAS adds Model pre-phase to ATLAS (backward compatible -- skips if no model) |
| D12 | Accepted | N:M digital thread links (one block -> many code modules; one control -> many requirements) |
| D21 | Accepted | Readiness scoring uses deterministic weighted average (reproducible, not probabilistic) |
| D22 | Accepted | Monte Carlo uses Python stdlib random (zero deps, air-gap safe) |
| D27 | Accepted | Supply chain graph stored as SQL adjacency list (no graph DB needed) |
| D52 | Accepted | This is a generated child app -- grandchild app generation is disabled by design |
| D117 | Accepted | DevSecOps/ZTA Agent with hard veto on pipeline_configuration and zero_trust_policy |
| D120 | Accepted | ZTA maturity model uses DoD 7-pillar scoring (Traditional -> Advanced -> Optimal) |
| D215 | Accepted | Prompt injection detector uses 5 detection categories |
| D216 | Accepted | AI telemetry hashes prompts/responses with SHA-256 (privacy-preserving audit) |
| D280 | Accepted | Pluggable Tracer ABC: OTelTracer (production), SQLiteTracer (air-gapped), NullTracer (fallback) |
| D287 | Accepted | PROV-AGENT provenance in 3 append-only SQLite tables (W3C PROV standard) |
| D331 | Accepted | Code quality metrics are read-only, advisory-only -- never modifies source files |

---

## D1: SQLite for internal operational data

**Status:** Superseded
**Date:** 2026-03-08
**Context:** The system needed a lightweight, zero-configuration database for internal operational data storage that works in portable and air-gapped environments.
**Decision:** ~~SQLite for internal operational data (zero-config portability)~~ Superseded by D-DB-20
**Consequences:**
- This decision has been replaced by D-DB-20 (PostgreSQL as primary backend).
- SQLite is retained as a lightweight fallback for portable/browser scenarios.

---

## D2: Stdio for MCP; HTTPS+mTLS for A2A

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Multi-agent communication requires well-defined protocols and boundaries between Claude Code MCP servers and inter-agent Kubernetes communication.
**Decision:** Stdio for MCP (Claude Code); HTTPS+mTLS for A2A (K8s inter-agent)
**Consequences:**
- MCP servers use stdio transport for Claude Code integration.
- Agent-to-agent communication uses HTTPS with mutual TLS within Kubernetes.
- Clear separation between local tool invocation and network-based agent communication.

---

## D4: Statistical methods for pattern detection

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Pattern detection in monitoring and self-healing must balance accuracy with cost and latency.
**Decision:** Statistical methods for pattern detection; Bedrock LLM for root cause analysis
**Consequences:**
- Pattern detection runs locally without LLM token costs.
- Root cause analysis leverages LLM reasoning capabilities when needed.
- Two-tier approach optimizes cost vs. intelligence tradeoff.

---

## D5: CUI markings applied at generation time

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Federal compliance requirements (NIST 800-53) mandate CUI markings on all generated artifacts at the appropriate impact level.
**Decision:** CUI markings applied at generation time (inline, not post-processing)
**Consequences:**
- All generated artifacts include classification markings from creation.
- No post-processing step required to add markings.
- Reduces risk of unmarked artifacts escaping the system.

---

## D6: Audit trail is append-only/immutable

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Federal compliance requirements (NIST 800-53 AU controls) mandate immutable audit records that cannot be tampered with.
**Decision:** Audit trail is append-only/immutable (no UPDATE/DELETE -- NIST AU compliance)
**Consequences:**
- Historical records cannot be modified or deleted.
- All audit tables use INSERT only.
- Satisfies NIST 800-53 AU control family requirements.

---

## D7: Python stdlib xml.etree.ElementTree for XMI/ReqIF parsing

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The system must operate in air-gapped environments without external dependencies for MBSE model parsing.
**Decision:** Python stdlib xml.etree.ElementTree for XMI/ReqIF parsing (zero deps, air-gap safe)
**Consequences:**
- No external network dependencies required at runtime.
- Works in air-gapped environments.
- Limited to stdlib XML capabilities (no lxml advanced features).

---

## D8: Normalized DB tables for model elements

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Data persistence strategy must support cross-domain queries across the digital thread (models, requirements, code, compliance).
**Decision:** Normalized DB tables for model elements (enables SQL joins across digital thread)
**Consequences:**
- SQL joins enable cross-domain traceability queries.
- Standard relational patterns for model element storage.
- All components must conform to this architectural constraint.

---

## D9: M-ATLAS adds Model pre-phase to ATLAS

**Status:** Accepted
**Date:** 2026-03-08
**Context:** MBSE model import needed integration with the existing ATLAS build workflow without breaking backward compatibility.
**Decision:** M-ATLAS adds Model pre-phase to ATLAS (backward compatible -- skips if no model)
**Consequences:**
- Existing ATLAS workflows continue to work unchanged.
- Model import is optional and triggered only when SysML/ReqIF files are present.
- Backward compatible with all existing projects.

---

## D12: N:M digital thread links

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Traceability between system artifacts requires many-to-many relationships (one block maps to multiple code modules, one control maps to multiple requirements).
**Decision:** N:M digital thread links (one block -> many code modules; one control -> many requirements)
**Consequences:**
- Full many-to-many traceability across artifact types.
- More complex queries but more accurate coverage reporting.
- All components must conform to this architectural constraint.

---

## D21: Readiness scoring uses deterministic weighted average

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Probabilistic behavior in business logic leads to unreliable results across runs. Readiness scores must be reproducible.
**Decision:** Readiness scoring uses deterministic weighted average (reproducible, not probabilistic)
**Consequences:**
- Results are reproducible across runs.
- Same inputs always produce same readiness score.
- No LLM involvement in scoring calculation.

---

## D22: Monte Carlo uses Python stdlib random

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The system must operate in air-gapped environments without external dependencies for simulation capabilities.
**Decision:** Monte Carlo uses Python stdlib random (zero deps, air-gap safe)
**Consequences:**
- No external network dependencies required at runtime.
- Works in air-gapped environments without numpy/scipy.
- Seeded runs are reproducible.

---

## D27: Supply chain graph stored as SQL adjacency list

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Data persistence strategy must support dependency graph traversal without requiring a dedicated graph database.
**Decision:** Supply chain graph stored as SQL adjacency list (no graph DB needed)
**Consequences:**
- No additional database technology required.
- Standard SQL queries for graph traversal.
- Pattern reused by metastore (D-CF-23).

---

## D52: Generated child app — grandchild generation disabled

**Status:** Accepted
**Date:** 2026-03-08
**Context:** This application is a generated child app of ICDEV. Allowing it to generate further child apps would create uncontrolled proliferation.
**Decision:** This is a generated child app -- grandchild app generation is disabled by design
**Consequences:**
- Agentic fitness assessor, app blueprint engine, and child app generator are excluded.
- Prevents recursive app generation chains.
- All components must conform to this architectural constraint.

---

## D117: DevSecOps/ZTA Agent with hard veto

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Security posture must be maintained across all system boundaries. Pipeline configuration and zero trust policy changes are high-risk operations.
**Decision:** DevSecOps/ZTA Agent with hard veto on pipeline_configuration and zero_trust_policy
**Consequences:**
- DevSecOps/ZTA agent can block pipeline and policy changes.
- Hard veto cannot be overridden by other agents.
- Ensures security review for all infrastructure changes.

---

## D120: ZTA maturity model uses DoD 7-pillar scoring

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Zero Trust Architecture maturity must be assessed using the DoD ZTA Strategy framework across all seven pillars.
**Decision:** ZTA maturity model uses DoD 7-pillar scoring (Traditional -> Advanced -> Optimal)
**Consequences:**
- Three maturity levels per pillar: Traditional, Advanced, Optimal.
- IL4+ systems must achieve Advanced or higher.
- Aligned with DoD Zero Trust Strategy.

---

## D215: Prompt injection detector uses 5 detection categories

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Security posture must be maintained across all system boundaries. AI prompt injection is a critical attack vector.
**Decision:** Prompt injection detector uses 5 detection categories
**Consequences:**
- Five distinct detection categories for comprehensive coverage.
- Gate-mode blocks deployment when injection defense is inactive.
- All components must conform to this architectural constraint.

---

## D216: AI telemetry hashes prompts/responses with SHA-256

**Status:** Accepted
**Date:** 2026-03-08
**Context:** AI telemetry must be auditable while preserving privacy of prompt and response content.
**Decision:** AI telemetry hashes prompts/responses with SHA-256 (privacy-preserving audit)
**Consequences:**
- Prompt and response content is never stored in plain text in telemetry.
- SHA-256 hashes enable tamper detection and deduplication.
- Satisfies privacy requirements while maintaining audit capability.

---

## D280: Pluggable Tracer ABC

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Observability must work in both connected (production) and air-gapped environments with a consistent interface.
**Decision:** Pluggable Tracer ABC: OTelTracer (production), SQLiteTracer (air-gapped), NullTracer (fallback)
**Consequences:**
- Three tracer implementations behind a common abstract base class.
- Environment-appropriate tracing without code changes.
- NullTracer ensures graceful degradation when no tracing backend is available.

---

## D287: PROV-AGENT provenance in 3 append-only SQLite tables

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Federal compliance requirements (NIST 800-53) mandate provenance tracking. W3C PROV standard provides interoperability.
**Decision:** PROV-AGENT provenance in 3 append-only SQLite tables (W3C PROV standard)
**Consequences:**
- Historical records cannot be modified or deleted.
- W3C PROV standard enables interoperability with external provenance systems.
- Three tables: entities, activities, derivations.

---

## D331: Code quality metrics are read-only, advisory-only

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Code intelligence tools must never modify source files to prevent unintended side effects during analysis.
**Decision:** Code quality metrics are read-only, advisory-only -- never modifies source files
**Consequences:**
- Analysis tools only read source files, never write to them.
- Metrics are advisory and do not enforce changes.
- Safe to run in any environment without risk of code modification.

---
