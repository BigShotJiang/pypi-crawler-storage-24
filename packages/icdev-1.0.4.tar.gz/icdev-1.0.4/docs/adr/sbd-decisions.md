# CUI // SP-CTI
# Secure by Design — Architecture Decision Records

**Total decisions:** 7
**Last updated:** 2026-03-08

| ID | Status | Decision |
|----|--------|----------|
| D-SBD-1 | Accepted | Cloudyrion 8-Pillar SbD Framework mapped to all 35 SBD requirements via `sbd_pillars` field |
| D-SBD-2 | Accepted | Security exception registry in `sbd_exceptions` table (active/expired/renewed lifecycle, max 365 days) |
| D-SBD-3 | Accepted | Exception aging gate: expired exceptions block deployment (Cloudyrion anti-pattern: lingering exceptions) |
| D-SBD-4 | Accepted | CISA SbD added to crosswalk engine as `cisa_sbd` framework key (implement once, satisfy many) |
| D-SBD-5 | Accepted | Golden Path child apps auto-inherit SECURITY.md, .well-known/security.txt, and args/sbd_gates.yaml |
| D-SBD-6 | Accepted | Developer Scorecard expanded to 6 dimensions (sbd_posture=0.20 weight, penalizes expired exceptions) |
| D-SBD-7 | Accepted | SbD goal workflow: 7-step assess-review-remediate-report cycle with Cloudyrion pillar alignment |

---

## D-SBD-1: Cloudyrion 8-Pillar SbD Framework mapped to all 35 SBD requirements

**Status:** Accepted
**Date:** 2026-03-08
**Context:** CISA Secure by Design requirements need organizational alignment through a structured framework. Cloudyrion's 8-Pillar model provides this structure.
**Decision:** Cloudyrion 8-Pillar SbD Framework mapped to all 35 SBD requirements via `sbd_pillars` field
**Consequences:**
- All 35 SBD requirements tagged with their Cloudyrion pillar.
- Pillar-level rollup reporting enabled.
- Framework alignment visible in assessment output.

---

## D-SBD-2: Security exception registry in `sbd_exceptions` table

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Security exceptions must be tracked with clear lifecycle management to prevent indefinite waivers.
**Decision:** Security exception registry in `sbd_exceptions` table (active/expired/renewed lifecycle, max 365 days)
**Consequences:**
- Three lifecycle states: active, expired, renewed.
- Maximum 365-day exception duration prevents permanent waivers.
- Exception history preserved for audit.

---

## D-SBD-3: Exception aging gate blocks deployment

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Security posture must be maintained. Lingering expired exceptions represent unmitigated security risks (Cloudyrion anti-pattern).
**Decision:** Exception aging gate: expired exceptions block deployment (Cloudyrion anti-pattern: lingering exceptions)
**Consequences:**
- Expired exceptions are hard blockers for deployment.
- Forces timely exception renewal or remediation.
- Prevents the "lingering exception" anti-pattern.

---

## D-SBD-4: CISA SbD added to crosswalk engine

**Status:** Accepted
**Date:** 2026-03-08
**Context:** CISA Secure by Design must integrate with existing compliance crosswalk for unified control mapping.
**Decision:** CISA SbD added to crosswalk engine as `cisa_sbd` framework key (implement once, satisfy many)
**Consequences:**
- Implementing NIST controls auto-populates SbD status via crosswalk.
- Single implementation satisfies multiple framework requirements.
- Consistent with existing crosswalk patterns (FedRAMP, CMMC, 800-171).

---

## D-SBD-5: Golden Path child apps auto-inherit security artifacts

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Scaffolded child applications must inherit security posture from the parent to maintain SbD compliance from day one.
**Decision:** Golden Path child apps auto-inherit SECURITY.md, .well-known/security.txt, and args/sbd_gates.yaml
**Consequences:**
- Child apps start with security artifacts pre-configured.
- SECURITY.md provides vulnerability disclosure policy.
- security.txt follows RFC 9116 standard.
- SbD gates enforced from first deployment.

---

## D-SBD-6: Developer Scorecard expanded to 6 dimensions

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Security posture must be visible in project health scoring. SbD compliance is a first-class quality dimension.
**Decision:** Developer Scorecard expanded to 6 dimensions (sbd_posture=0.20 weight, penalizes expired exceptions)
**Consequences:**
- SbD posture is 20% of overall health score.
- Expired exceptions reduce the score.
- Incentivizes proactive security exception management.

---

## D-SBD-7: SbD goal workflow: 7-step cycle

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Secure by Design assessment needs a structured workflow that aligns with Cloudyrion's pillar model.
**Decision:** SbD goal workflow: 7-step assess-review-remediate-report cycle with Cloudyrion pillar alignment
**Consequences:**
- Seven-step cycle provides structured remediation path.
- Cloudyrion pillar alignment in each step.
- Report generation at cycle end for stakeholder review.

---
