# CUI // SP-CTI
# Scale Engine — Architecture Decision Records

**Total decisions:** 7
**Last updated:** 2026-03-08

| ID | Status | Decision |
|----|--------|----------|
| D-SC-1 | Accepted | Scale Engine uses ThreadPoolExecutor wrapping existing sync connectors (no ABC changes) |
| D-SC-2 | Accepted | Per-connector-type connection pools (key = connector_name) |
| D-SC-3 | Accepted | WAL + batch flush for sync log and audit writes (single writer thread) |
| D-SC-4 | Accepted | Fixed limits (configurable max_workers, max_concurrent_syncs via YAML) |
| D-SC-5 | Accepted | Semaphore enforces max_concurrent_syncs (makes existing config value real) |
| D-SC-6 | Accepted | stdlib only (concurrent.futures, threading, queue); psutil optional for backpressure |
| D-SC-7 | Accepted | Append-only audit trail preserved (INSERT only in WriteBatcher, NIST AU) |

---

## D-SC-1: Scale Engine uses ThreadPoolExecutor wrapping existing sync connectors

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Sync connectors need parallel execution without modifying existing connector abstract base classes.
**Decision:** Scale Engine uses ThreadPoolExecutor wrapping existing sync connectors (no ABC changes)
**Consequences:**
- Existing connectors work without modification.
- ThreadPoolExecutor provides parallel execution.
- No changes to connector ABC or existing implementations.

---

## D-SC-2: Per-connector-type connection pools

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Different connector types have different connection characteristics and limits.
**Decision:** Per-connector-type connection pools (key = connector_name)
**Consequences:**
- Each connector type maintains its own connection pool.
- Pool sizes can be tuned per connector type.
- Prevents one connector type from exhausting shared resources.

---

## D-SC-3: WAL + batch flush for sync log and audit writes

**Status:** Accepted
**Date:** 2026-03-08
**Context:** High-throughput sync operations generate many log entries. Individual writes create I/O bottlenecks.
**Decision:** WAL + batch flush for sync log and audit writes (single writer thread)
**Consequences:**
- Write-Ahead Logging reduces I/O contention.
- Batch flush aggregates writes for efficiency.
- Single writer thread prevents lock contention.

---

## D-SC-4: Fixed limits (configurable max_workers, max_concurrent_syncs via YAML)

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Configuration and templates must follow GOTCHA separation of concerns. Resource limits must be configurable per deployment.
**Decision:** Fixed limits (configurable max_workers, max_concurrent_syncs via YAML)
**Consequences:**
- Resource limits defined in YAML configuration.
- max_workers controls thread pool size.
- max_concurrent_syncs controls parallel sync operations.

---

## D-SC-5: Semaphore enforces max_concurrent_syncs

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The max_concurrent_syncs config value existed but was not enforced at runtime. Actual enforcement was needed.
**Decision:** Semaphore enforces max_concurrent_syncs (makes existing config value real)
**Consequences:**
- Threading semaphore provides hard limit on concurrent syncs.
- Existing config value now has runtime enforcement.
- Prevents resource exhaustion under load.

---

## D-SC-6: stdlib only; psutil optional for backpressure

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The system must operate in air-gapped environments without external dependencies for core scale engine functionality.
**Decision:** stdlib only (concurrent.futures, threading, queue); psutil optional for backpressure
**Consequences:**
- No external network dependencies required at runtime.
- Core functionality uses Python stdlib only.
- psutil provides optional CPU/memory backpressure when available.

---

## D-SC-7: Append-only audit trail preserved

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Federal compliance requirements (NIST 800-53 AU controls) mandate immutable audit records even in high-throughput batch scenarios.
**Decision:** Append-only audit trail preserved (INSERT only in WriteBatcher, NIST AU)
**Consequences:**
- Historical records cannot be modified or deleted.
- WriteBatcher uses INSERT only operations.
- Satisfies NIST AU compliance requirements.

---
