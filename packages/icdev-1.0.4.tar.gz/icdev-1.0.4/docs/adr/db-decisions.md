# CUI // SP-CTI
# Database & Storage — Architecture Decision Records

**Total decisions:** 6
**Last updated:** 2026-03-08

| ID | Status | Decision |
|----|--------|----------|
| D-DB-20 | Accepted | PostgreSQL is the primary backend; SQLite retained as lightweight fallback for portable/browser scenarios |
| D-DB-21 | Accepted | Storage abstraction layer in `tools/db/storage.py` -- all tools use `get_connection()` (backend-agnostic) |
| D-DB-22 | Accepted | `args/storage_config.yaml` controls backend selection; env vars override YAML (ICDEV_STORAGE_BACKEND, ICDEV_PG_*) |
| D-DB-23 | Accepted | Placeholder translation (? -> %s) handled transparently by StorageConnection wrapper |
| D-DB-24 | Accepted | Supabase for marketplace-saas (PostgreSQL + Auth + RLS + Realtime) |
| D-DB-25 | Accepted | Alembic for PostgreSQL schema versioning (replaces table-recreation pattern) |

---

## D-DB-20: PostgreSQL is the primary backend

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Data persistence strategy must balance portability, performance, and compliance. SQLite (D1) was insufficient for production multi-user scenarios.
**Decision:** PostgreSQL is the primary backend; SQLite retained as lightweight fallback for portable/browser scenarios
**Consequences:**
- PostgreSQL provides ACID compliance, concurrent access, and production-grade performance.
- SQLite remains available for development, testing, and air-gapped portable deployments.
- Supersedes D1 (SQLite-only approach).

---

## D-DB-21: Storage abstraction layer in `tools/db/storage.py`

**Status:** Accepted
**Date:** 2026-03-08
**Context:** All tools must work with both PostgreSQL and SQLite backends without code changes.
**Decision:** Storage abstraction layer in `tools/db/storage.py` -- all tools use `get_connection()` (backend-agnostic)
**Consequences:**
- All tools use a single `get_connection()` entry point.
- Backend switching requires only configuration changes, not code changes.
- All components must conform to this architectural constraint.

---

## D-DB-22: `args/storage_config.yaml` controls backend selection

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Configuration and templates must follow GOTCHA separation of concerns. Backend selection must be overridable per environment.
**Decision:** `args/storage_config.yaml` controls backend selection; env vars override YAML (ICDEV_STORAGE_BACKEND, ICDEV_PG_*)
**Consequences:**
- YAML config provides default backend selection.
- Environment variables override YAML for deployment flexibility.
- Follows GOTCHA args layer pattern.

---

## D-DB-23: Placeholder translation (? -> %s) handled transparently

**Status:** Accepted
**Date:** 2026-03-08
**Context:** SQLite uses `?` placeholders while PostgreSQL uses `%s`. Tools should not need to know which backend is active.
**Decision:** Placeholder translation (? -> %s) handled transparently by StorageConnection wrapper
**Consequences:**
- All tools write SQL with `?` placeholders (SQLite syntax).
- StorageConnection automatically translates to `%s` when PostgreSQL is active.
- No backend-specific SQL in tool code.

---

## D-DB-24: Supabase for marketplace-saas

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The marketplace SaaS requires PostgreSQL with authentication, row-level security, and realtime capabilities.
**Decision:** Supabase for marketplace-saas (PostgreSQL + Auth + RLS + Realtime)
**Consequences:**
- Marketplace uses Supabase-hosted PostgreSQL.
- Row-level security enforces tenant isolation.
- Realtime subscriptions enable live marketplace updates.

---

## D-DB-25: Alembic for PostgreSQL schema versioning

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The table-recreation pattern used with SQLite does not work for PostgreSQL with existing data. A proper migration framework is needed.
**Decision:** Alembic for PostgreSQL schema versioning (replaces table-recreation pattern)
**Consequences:**
- Schema changes are versioned and reversible.
- Migration history provides audit trail of schema evolution.
- Replaces the SQLite-era table-recreation pattern.

---
