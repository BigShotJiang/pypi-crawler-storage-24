# CUI // SP-CTI
# Harness Engineering — Architecture Decision Records

**Total decisions:** 8
**Last updated:** 2026-03-08

| ID | Status | Decision |
|----|--------|----------|
| D-HARNESS-1 | Accepted | Loop state in `.tmp/sessions/` JSON (ephemeral, not DB) |
| D-HARNESS-2 | Accepted | Loop detection is soft-signal only (stderr, exit 0) -- never blocks |
| D-HARNESS-3 | Accepted | Progress file is JSON (models handle structured data better) |
| D-HARNESS-4 | Accepted | Exit criteria in args/ YAML (GOTCHA separation) |
| D-HARNESS-5 | Accepted | Trace analyzer scanner-tier only (zero Claude tokens) |
| D-HARNESS-6 | Accepted | Maturity assessor read-only, advisory-only |
| D-HARNESS-7 | Accepted | Scaffolder generates 3 hooks (minimal), not all 7 |
| D-HARNESS-8 | Accepted | One new append-only DB table: `harness_trace_recommendations` |

---

## D-HARNESS-1: Loop state in `.tmp/sessions/` JSON

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Loop detection state is ephemeral and session-scoped. Persisting it in the database adds unnecessary complexity.
**Decision:** Loop state in `.tmp/sessions/` JSON (ephemeral, not DB)
**Consequences:**
- Session state is disposable and does not pollute the database.
- JSON format is human-readable for debugging.
- State is lost on session end (by design).

---

## D-HARNESS-2: Loop detection is soft-signal only

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Loop detection should inform but never block agent operations to prevent false positives from halting work.
**Decision:** Loop detection is soft-signal only (stderr, exit 0) -- never blocks
**Consequences:**
- Warnings emitted to stderr for visibility.
- Exit code 0 ensures downstream processes are not blocked.
- Human judgment required for loop resolution.

---

## D-HARNESS-3: Progress file is JSON

**Status:** Accepted
**Date:** 2026-03-08
**Context:** AI models handle structured data better than free-form text. Progress tracking must be machine-readable.
**Decision:** Progress file is JSON (models handle structured data better)
**Consequences:**
- JSON format enables programmatic progress tracking.
- AI models can parse and reason about progress state.
- Human-readable with standard JSON formatting.

---

## D-HARNESS-4: Exit criteria in args/ YAML

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Configuration and templates must follow GOTCHA separation of concerns. Exit criteria must be adjustable without code changes.
**Decision:** Exit criteria in args/ YAML (GOTCHA separation)
**Consequences:**
- Exit criteria defined in YAML configuration.
- Behavior changes without editing goals or tools.
- Follows GOTCHA args layer pattern.

---

## D-HARNESS-5: Trace analyzer scanner-tier only

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Trace analysis must be cost-effective and available in air-gapped environments without Claude tokens.
**Decision:** Trace analyzer scanner-tier only (zero Claude tokens)
**Consequences:**
- No Claude token consumption for trace analysis.
- Uses local models or deterministic analysis only.
- Available in air-gapped environments.

---

## D-HARNESS-6: Maturity assessor read-only, advisory-only

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Maturity assessment must never modify the system it is assessing to prevent measurement from affecting results.
**Decision:** Maturity assessor read-only, advisory-only
**Consequences:**
- Assessment tools only read system state, never modify it.
- Results are advisory and do not enforce changes.
- Safe to run in production without risk.

---

## D-HARNESS-7: Scaffolder generates 3 hooks (minimal)

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Scaffolded harness should be minimal and not overwhelm new projects with unnecessary complexity.
**Decision:** Scaffolder generates 3 hooks (minimal), not all 7
**Consequences:**
- Three essential hooks provided out of the box.
- Additional hooks can be added as needed.
- Lower barrier to adoption for new projects.

---

## D-HARNESS-8: One new append-only DB table

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Federal compliance requirements (NIST 800-53 AU controls) mandate immutable storage for trace recommendations.
**Decision:** One new append-only DB table: `harness_trace_recommendations`
**Consequences:**
- Historical records cannot be modified or deleted.
- Single table for all trace-derived recommendations.
- Satisfies NIST AU compliance requirements.

---
