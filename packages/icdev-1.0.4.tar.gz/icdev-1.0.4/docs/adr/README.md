# CUI // SP-CTI
# Architecture Decision Records — Index

**Total decisions:** 104
**Last updated:** 2026-03-08

## Decision Groups

| Group | File | Count | Description |
|-------|------|-------|-------------|
| Core Architecture | [core-decisions.md](core-decisions.md) | 20 | Foundational system decisions: protocols, data models, compliance, observability |
| Database & Storage | [db-decisions.md](db-decisions.md) | 6 | PostgreSQL migration, storage abstraction, schema versioning |
| Connector Forge & CloudForge | [connector-forge-decisions.md](connector-forge-decisions.md) | 22 | Dynamic connector generation, runbooks, metastore, ops server |
| Innovation Features | [innovation-decisions.md](innovation-decisions.md) | 18 | cATO, DORA, narratives, threat modeling, scorecard, golden path, SBOM |
| WriteGuard | [writeguard-decisions.md](writeguard-decisions.md) | 9 | AI writing assistant: deterministic pipeline, style guides, analysis |
| Marketplace | [marketplace-decisions.md](marketplace-decisions.md) | 7 | SaaS extraction, licensing, community model, sponsor tiers |
| Scale Engine | [scale-engine-decisions.md](scale-engine-decisions.md) | 7 | Parallel sync execution, connection pools, batch writes |
| Harness Engineering | [harness-decisions.md](harness-decisions.md) | 8 | Loop detection, maturity assessment, exit criteria, trace analysis |
| Secure by Design | [sbd-decisions.md](sbd-decisions.md) | 7 | CISA SbD, Cloudyrion 8-Pillar, exception registry, scorecard integration |

## Summary by Status

| Status | Count |
|--------|-------|
| Accepted | 103 |
| Superseded | 1 |

## Superseded Decisions

| ID | Superseded By | Original Decision |
|----|---------------|-------------------|
| D1 | D-DB-20 | SQLite for internal operational data (zero-config portability) |

## How to Use

These ADRs are extracted from `CLAUDE.md` Key Architecture Decisions section.

To regenerate all ADR files:
```bash
python tools/architecture/adr_extractor.py --extract --json
```

To list all decisions:
```bash
python tools/architecture/adr_extractor.py --list --json
```

## ADR Format

Each group file contains:
- **Summary table** — ID, status, and brief description for quick scanning
- **Individual sections** — Status, Date, Context, Decision, and Consequences for each ADR

## Naming Convention

Decision IDs follow the pattern `D-{PREFIX}-{NUMBER}`:
- `D{N}` — Core architecture decisions (no prefix)
- `D-DB-{N}` — Database and storage layer
- `D-CF-{N}` — Connector Forge and CloudForge
- `D-INV-{N}` — Innovation features
- `D-WG-{N}` — WriteGuard writing assistant
- `D-MKT-{S|C}{N}` — Marketplace (S=SaaS, C=Community)
- `D-SC-{N}` — Scale Engine
- `D-HARNESS-{N}` — Harness Engineering
- `D-SBD-{N}` — Secure by Design
- `D-ARCH-{N}` — Architecture Patterns (reserved)
