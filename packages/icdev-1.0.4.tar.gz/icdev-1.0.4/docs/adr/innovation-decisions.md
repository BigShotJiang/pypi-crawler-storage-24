# CUI // SP-CTI
# Innovation Features — Architecture Decision Records

**Total decisions:** 18
**Last updated:** 2026-03-08

| ID | Status | Decision |
|----|--------|----------|
| D-INV-1 | Accepted | cATO OSCAL streaming uses incremental assessment-results (per-control, not bulk) |
| D-INV-2 | Accepted | Evidence freshness thresholds: current <= 30d, stale <= 90d, expired > 90d |
| D-INV-5 | Accepted | Template provenance via SHA-256 content hash (tamper detection) |
| D-INV-9 | Accepted | DORA metrics computed from audit_trail stage timestamps (no external CI integration needed) |
| D-INV-10 | Accepted | Bottleneck detection via p90 statistical analysis (no ML) |
| D-INV-13 | Accepted | Two-tier LLM for narrative generation: qwen3 drafts, Claude reviews |
| D-INV-14 | Accepted | Narrative approval workflow: draft -> pending_review -> approved/rejected |
| D-INV-17 | Accepted | Heatmap matrix uses N x M artifact-type cross-reference (not individual artifacts) |
| D-INV-21 | Accepted | PR diff analysis via subprocess git (no GitHub API dependency) |
| D-INV-25 | Accepted | STRIDE threat analysis is deterministic rule-based per component type (no LLM) |
| D-INV-26 | Accepted | STRIDE-to-NIST mapping: Spoofing->AC/IA, Tampering->SC/SI, Repudiation->AU, InfoDisc->SC, DoS->SC/CP, EoP->AC |
| D-INV-29 | Accepted | Scorecard weighted composite (6 dimensions): code_quality=0.20, security=0.20, compliance=0.15, ... |
| D-INV-33 | Accepted | Golden Path uses declarative YAML template definitions (5 built-in templates) |
| D-INV-37 | Accepted | Forge Hub trust score: validation=0.30, rating=0.25, downloads=0.20, age=0.15, author=0.10 |
| D-INV-41 | Accepted | ATO simulator uses PERT sampling via stdlib random.betavariate (zero deps) |
| D-INV-45 | Accepted | Firmware SBOM output format: CycloneDX 1.5 JSON |
| D-INV-46 | Accepted | VEX output format: CSAF 2.0 with per-component exploitability status |
| D-INV-48 | Accepted | All innovation features use icdev.db (NOT sparkpilot.db -- that's for IoT/embedded only) |

---

## D-INV-1: cATO OSCAL streaming uses incremental assessment-results

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Continuous ATO requires real-time evidence streaming without overwhelming the system with bulk assessments.
**Decision:** cATO OSCAL streaming uses incremental assessment-results (per-control, not bulk)
**Consequences:**
- Individual control assessments streamed as they complete.
- Reduces latency for evidence freshness monitoring.
- OSCAL format ensures interoperability with GRC tools.

---

## D-INV-2: Evidence freshness thresholds

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Federal compliance requirements mandate evidence currency. Stale evidence must be flagged and expired evidence must block authorization.
**Decision:** Evidence freshness thresholds: current <= 30d, stale <= 90d, expired > 90d
**Consequences:**
- Three-tier freshness classification: current, stale, expired.
- Automated alerts when evidence transitions to stale.
- Expired evidence blocks cATO continuation.

---

## D-INV-5: Template provenance via SHA-256 content hash

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Security posture must be maintained. Compliance templates must be tamper-evident.
**Decision:** Template provenance via SHA-256 content hash (tamper detection)
**Consequences:**
- Content hash computed on template creation and verified on use.
- Tampered templates are detected and rejected.
- Hash stored alongside template metadata.

---

## D-INV-9: DORA metrics computed from audit_trail stage timestamps

**Status:** Accepted
**Date:** 2026-03-08
**Context:** DORA metrics (deployment frequency, lead time, MTTR, change failure rate) must be computed without external CI/CD integration.
**Decision:** DORA metrics computed from audit_trail stage timestamps (no external CI integration needed)
**Consequences:**
- Metrics derived from existing audit trail data.
- No external CI/CD system integration required.
- Works in air-gapped environments.

---

## D-INV-10: Bottleneck detection via p90 statistical analysis

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Pipeline bottleneck detection must be deterministic and reproducible without ML model dependencies.
**Decision:** Bottleneck detection via p90 statistical analysis (no ML)
**Consequences:**
- Results are reproducible across runs.
- P90 percentile analysis identifies outlier stages.
- No ML model training or inference required.

---

## D-INV-13: Two-tier LLM for narrative generation

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Compliance narrative generation needs both speed (drafting) and quality (review) at reasonable token cost.
**Decision:** Two-tier LLM for narrative generation: qwen3 drafts, Claude reviews
**Consequences:**
- qwen3 handles initial narrative drafting (fast, low cost).
- Claude reviews for accuracy and compliance language.
- Consistent with two-tier LLM pattern (D-CF-2).

---

## D-INV-14: Narrative approval workflow

**Status:** Accepted
**Date:** 2026-03-08
**Context:** AI-generated compliance narratives require human review and approval before inclusion in ATO packages.
**Decision:** Narrative approval workflow: draft -> pending_review -> approved/rejected
**Consequences:**
- Three-state workflow with clear transitions.
- Human review required before approval.
- Rejected narratives can be revised and resubmitted.

---

## D-INV-17: Heatmap matrix uses N x M artifact-type cross-reference

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Digital thread coverage visualization must show gaps at the artifact-type level, not individual artifact level, to remain useful at scale.
**Decision:** Heatmap matrix uses N x M artifact-type cross-reference (not individual artifacts)
**Consequences:**
- Coverage gaps visible at category level.
- Scalable visualization regardless of artifact count.
- N artifact types x M artifact types matrix.

---

## D-INV-21: PR diff analysis via subprocess git

**Status:** Accepted
**Date:** 2026-03-08
**Context:** PR intelligence must work without GitHub API access for air-gapped and self-hosted environments.
**Decision:** PR diff analysis via subprocess git (no GitHub API dependency)
**Consequences:**
- No external network dependencies required at runtime.
- Works with any git hosting platform.
- Subprocess git available in all environments.

---

## D-INV-25: STRIDE threat analysis is deterministic rule-based

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Probabilistic behavior in threat modeling leads to inconsistent results. STRIDE analysis must be reproducible.
**Decision:** STRIDE threat analysis is deterministic rule-based per component type (no LLM)
**Consequences:**
- Results are reproducible across runs.
- Component type determines applicable threats.
- No LLM token cost for threat analysis.

---

## D-INV-26: STRIDE-to-NIST mapping

**Status:** Accepted
**Date:** 2026-03-08
**Context:** STRIDE threats must map to NIST 800-53 controls for compliance integration.
**Decision:** STRIDE-to-NIST mapping: Spoofing->AC/IA, Tampering->SC/SI, Repudiation->AU, InfoDisc->SC, DoS->SC/CP, EoP->AC
**Consequences:**
- Automatic control mapping from threat identification.
- Six STRIDE categories map to specific NIST control families.
- Enables auto-generation of POAM items from threats.

---

## D-INV-29: Scorecard weighted composite (6 dimensions)

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Developer scorecard must provide a single health score from multiple quality dimensions with configurable weights.
**Decision:** Scorecard weighted composite (6 dimensions): code_quality=0.20, security=0.20, compliance=0.15, test_coverage=0.15, velocity=0.10, sbd_posture=0.20
**Consequences:**
- Single composite score from six dimensions.
- Weights are configurable but must sum to 1.0.
- SbD posture weight (0.20) reflects security-first priorities.

---

## D-INV-33: Golden Path uses declarative YAML template definitions

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Configuration and templates must follow GOTCHA separation of concerns. Project scaffolding must be extensible.
**Decision:** Golden Path uses declarative YAML template definitions (5 built-in templates)
**Consequences:**
- Templates defined in YAML, not code.
- 5 built-in templates cover common project types.
- New templates added without code changes.

---

## D-INV-37: Forge Hub trust score

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The marketplace and community features require trust scoring for community-contributed connectors.
**Decision:** Forge Hub trust score: validation=0.30, rating=0.25, downloads=0.20, age=0.15, author=0.10
**Consequences:**
- Five-factor weighted trust score.
- Validation weight (0.30) prioritizes technical correctness.
- Trust score visible to users during connector selection.

---

## D-INV-41: ATO simulator uses PERT sampling

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The system must operate in air-gapped environments without external dependencies for Monte Carlo simulation.
**Decision:** ATO simulator uses PERT sampling via stdlib random.betavariate (zero deps)
**Consequences:**
- No external network dependencies required at runtime.
- PERT distribution via betavariate provides realistic timeline estimates.
- Works in air-gapped environments without numpy/scipy.

---

## D-INV-45: Firmware SBOM output format: CycloneDX 1.5 JSON

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Firmware SBOM must use a widely adopted standard format for interoperability with vulnerability management tools.
**Decision:** Firmware SBOM output format: CycloneDX 1.5 JSON
**Consequences:**
- CycloneDX 1.5 provides firmware-specific component types.
- JSON format enables programmatic consumption.
- Compatible with OWASP Dependency-Track and similar tools.

---

## D-INV-46: VEX output format: CSAF 2.0

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Vulnerability exploitability exchange documents must use a standard format for automated triage.
**Decision:** VEX output format: CSAF 2.0 with per-component exploitability status
**Consequences:**
- CSAF 2.0 provides structured vulnerability advisories.
- Per-component exploitability status enables targeted remediation.
- Compatible with CISA VEX requirements.

---

## D-INV-48: All innovation features use icdev.db

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Data persistence strategy must separate operational data (icdev.db) from IoT/embedded data (sparkpilot.db).
**Decision:** All innovation features use icdev.db (NOT sparkpilot.db -- that's for IoT/embedded only)
**Consequences:**
- Clear database boundary between ICDEV platform and SparkPilot embedded.
- Innovation features never touch sparkpilot.db.
- All components must conform to this architectural constraint.

---
