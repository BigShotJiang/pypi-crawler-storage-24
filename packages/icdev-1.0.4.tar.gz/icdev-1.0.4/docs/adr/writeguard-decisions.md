# CUI // SP-CTI
# WriteGuard — Architecture Decision Records

**Total decisions:** 9
**Last updated:** 2026-03-08

| ID | Status | Decision |
|----|--------|----------|
| D-WG-1 | Accepted | Independent `tools/writing/` directory for marketplace portability |
| D-WG-2 | Accepted | Deterministic-first pipeline (regex before LLM) -- air-gap safe, reproducible |
| D-WG-3 | Accepted | 5-layer style guide cascade with ISSO locks (Platform->Tenant->Program->Project->User) |
| D-WG-5 | Accepted | Plagiarism via RAG similarity (0.85 threshold) |
| D-WG-6 | Accepted | AI detection is deterministic (advisory-only) -- perplexity, burstiness, n-gram stats |
| D-WG-7 | Accepted | Snippets follow knowledge_base.py CRUD + hybrid search pattern |
| D-WG-8 | Accepted | GovProposal via read-only bridge -- never writes to proposal tables |
| D-WG-9 | Accepted | Append-only analysis results (NIST AU compliant) |
| D-WG-12 | Accepted | Two-tier routing per function -- grammar/readability deterministic, tone scanner, rewrite/coherence worker |

---

## D-WG-1: Independent `tools/writing/` directory for marketplace portability

**Status:** Accepted
**Date:** 2026-03-08
**Context:** WriteGuard must be extractable as a standalone marketplace module without pulling in unrelated ICDEV dependencies.
**Decision:** Independent `tools/writing/` directory for marketplace portability
**Consequences:**
- WriteGuard code is self-contained in `tools/writing/`.
- Can be packaged independently for marketplace distribution.
- Minimal coupling to other ICDEV modules.

---

## D-WG-2: Deterministic-first pipeline (regex before LLM)

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The system must operate in air-gapped environments. Writing analysis must be reproducible without LLM availability.
**Decision:** Deterministic-first pipeline (regex before LLM) -- air-gap safe, reproducible
**Consequences:**
- No external network dependencies required for basic analysis.
- Results are reproducible across runs.
- LLM enhances but is not required for core functionality.

---

## D-WG-3: 5-layer style guide cascade with ISSO locks

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Style guide management must support organizational hierarchy with security officer override capability.
**Decision:** 5-layer style guide cascade with ISSO locks (Platform->Tenant->Program->Project->User)
**Consequences:**
- Five priority levels for style guide resolution.
- ISSO can lock style guides to prevent unauthorized changes.
- Cascade resolution: higher layers override lower layers.

---

## D-WG-5: Plagiarism via RAG similarity (0.85 threshold)

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Plagiarism detection must use existing RAG infrastructure for similarity comparison.
**Decision:** Plagiarism via RAG similarity (0.85 threshold)
**Consequences:**
- 0.85 cosine similarity threshold for plagiarism flagging.
- Reuses existing RAG embedding infrastructure.
- Threshold is configurable per project.

---

## D-WG-6: AI detection is deterministic (advisory-only)

**Status:** Accepted
**Date:** 2026-03-08
**Context:** AI content detection must be reproducible and clearly advisory, not authoritative.
**Decision:** AI detection is deterministic (advisory-only) -- perplexity, burstiness, n-gram stats
**Consequences:**
- Results are reproducible across runs.
- Three statistical measures: perplexity, burstiness, n-gram analysis.
- Advisory-only: does not block or modify content.

---

## D-WG-7: Snippets follow knowledge_base.py CRUD + hybrid search pattern

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Writing snippets must use the same storage and search patterns as the knowledge base for consistency.
**Decision:** Snippets follow knowledge_base.py CRUD + hybrid search pattern
**Consequences:**
- Consistent CRUD interface across knowledge base and snippets.
- Hybrid search (keyword + semantic) for snippet retrieval.
- Reuses existing infrastructure.

---

## D-WG-8: GovProposal via read-only bridge

**Status:** Accepted
**Date:** 2026-03-08
**Context:** WriteGuard integration with GovProposal must not risk corrupting proposal data.
**Decision:** GovProposal via read-only bridge -- never writes to proposal tables
**Consequences:**
- WriteGuard can read proposal content for analysis.
- No write operations to proposal tables.
- Bridge pattern ensures data integrity.

---

## D-WG-9: Append-only analysis results

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Federal compliance requirements (NIST 800-53 AU controls) mandate immutable analysis records.
**Decision:** Append-only analysis results (NIST AU compliant)
**Consequences:**
- Historical records cannot be modified or deleted.
- Complete history of analysis results preserved.
- Satisfies NIST AU compliance requirements.

---

## D-WG-12: Two-tier routing per function

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Different WriteGuard functions have different accuracy requirements. Grammar checking is deterministic; rewriting needs LLM.
**Decision:** Two-tier routing per function -- grammar/readability deterministic, tone scanner, rewrite/coherence worker
**Consequences:**
- Grammar and readability analysis run deterministically (no LLM cost).
- Tone scanning uses scanner-tier LLM.
- Rewrite and coherence checking use worker-tier LLM.

---
