# CUI // SP-CTI
# Connector Forge & CloudForge — Architecture Decision Records

**Total decisions:** 22
**Last updated:** 2026-03-08

| ID | Status | Decision |
|----|--------|----------|
| D-CF-1 | Accepted | Connector Forge `forge/` is a subpackage of `tools/databridge/` -- imports from existing ABCs |
| D-CF-2 | Accepted | Two-tier LLM for code gen (qwen3 drafts connector skeleton, Claude reviews against ABC contract) |
| D-CF-3 | Accepted | Inline Jinja2 template strings with string-replacement fallback (air-gap safe) |
| D-CF-4 | Accepted | Docker sandbox primary (--network none, --memory 256m), subprocess fallback |
| D-CF-5 | Accepted | Two new ConnectorType enum values: SOAP, HEALTH |
| D-CF-6 | Accepted | Promotion state machine: sandboxed -> promoted -> published -> deprecated |
| D-CF-7 | Accepted | 8 new audit event types for forge lifecycle |
| D-CF-8 | Accepted | Marketplace install via ASSET_TYPE_DIRS["databridge_connector"] |
| D-CF-9 | Accepted | MCP server exposes 8 tools for forge operations |
| D-CF-10 | Accepted | Config in databridge_config.yaml under forge: block |
| D-CF-19 | Accepted | Runbooks stored as JSON DAG (tasks_json + edges_json) in SQLite -- air-gap safe |
| D-CF-20 | Accepted | Runbook executions are append-only with per-task log (NIST AU compliance) |
| D-CF-21 | Accepted | DAG execution uses Kahn's algorithm (topological sort) -- deterministic O(V+E), no LLM in critical path |
| D-CF-22 | Accepted | Snippets are self-contained sub-DAGs embedded by reference with usage count tracking |
| D-CF-23 | Accepted | Metastore uses adjacency list for dependency graph (matches D27 pattern, SQL joins) |
| D-CF-24 | Accepted | Auto-discovery pulls from db_connections, cf_landing_zones, devices -- idempotent upsert |
| D-CF-25 | Accepted | Conditional branching uses deterministic expression eval (key-operator-value triples, no eval()) |
| D-CF-26 | Accepted | AI runbook generation is non-critical-path, always outputs status='draft' |
| D-CF-27 | Accepted | RTO/RPO stored as hours (REAL) on cf_applications -- simple numeric comparison |
| D-CF-28 | Accepted | Single unified Ops MCP server with 18 tools (reduces MCP server proliferation) |
| D-CF-29 | Accepted | YAML runbook templates in args/cloudforge_runbook_templates/ (GOTCHA args layer) |
| D-CF-30 | Accepted | Community: 3 runbooks, no snippets/AI/discovery; Pro: unlimited |

---

## D-CF-1: Connector Forge as subpackage of tools/databridge/

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Connector Forge needs to reuse existing DataBridge abstract base classes and connector patterns without duplication.
**Decision:** Connector Forge `forge/` is a subpackage of `tools/databridge/` -- imports from existing ABCs
**Consequences:**
- Forge connectors inherit from the same ABCs as built-in connectors.
- No code duplication of connector interfaces.
- Forge directory is self-contained within the DataBridge module.

---

## D-CF-2: Two-tier LLM for code gen

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Connector code generation needs both speed (drafting) and accuracy (contract validation) at reasonable token cost.
**Decision:** Two-tier LLM for code gen (qwen3 drafts connector skeleton, Claude reviews against ABC contract)
**Consequences:**
- qwen3 handles initial code generation (fast, low cost).
- Claude reviews for ABC contract compliance (high accuracy).
- Reduced Claude token consumption (~40% savings).

---

## D-CF-3: Inline Jinja2 template strings with string-replacement fallback

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The system must operate in air-gapped environments without external dependencies for template rendering.
**Decision:** Inline Jinja2 template strings with string-replacement fallback (air-gap safe)
**Consequences:**
- No external network dependencies required at runtime.
- Jinja2 used when available, string replacement as fallback.
- Templates are embedded in source code, not external files.

---

## D-CF-4: Docker sandbox primary, subprocess fallback

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Generated connector code must be executed in isolation to prevent security risks from untrusted code.
**Decision:** Docker sandbox primary (--network none, --memory 256m), subprocess fallback
**Consequences:**
- Network-isolated Docker container for maximum security.
- Memory-limited to prevent resource exhaustion.
- Subprocess fallback when Docker is unavailable.

---

## D-CF-5: Two new ConnectorType enum values

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The connector type system needed to support SOAP web services and health check endpoints.
**Decision:** Two new ConnectorType enum values: SOAP, HEALTH
**Consequences:**
- SOAP connectors can be properly categorized.
- Health check connectors have a distinct type.
- Enum extended without breaking existing connector types.

---

## D-CF-6: Promotion state machine

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Generated connectors need a clear lifecycle from initial sandbox testing through production deployment and eventual retirement.
**Decision:** Promotion state machine: sandboxed -> promoted -> published -> deprecated
**Consequences:**
- Clear progression path for connector maturity.
- Each state has distinct permissions and visibility.
- Deprecated connectors are retained but not recommended.

---

## D-CF-7: 8 new audit event types for forge lifecycle

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Federal compliance requirements (NIST 800-53 AU controls) mandate audit logging of forge lifecycle events.
**Decision:** 8 new audit event types for forge lifecycle
**Consequences:**
- Historical records cannot be modified or deleted.
- Complete audit trail of connector generation, validation, promotion, and deprecation.
- All forge operations are traceable.

---

## D-CF-8: Marketplace install via ASSET_TYPE_DIRS

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The marketplace and community features require clear operational boundaries for installing forge connectors.
**Decision:** Marketplace install via ASSET_TYPE_DIRS["databridge_connector"]
**Consequences:**
- Connectors installed to a known directory path.
- Asset type directory mapping is consistent across marketplace.
- All components must conform to this architectural constraint.

---

## D-CF-9: MCP server exposes 8 tools for forge operations

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Multi-agent communication requires well-defined protocols for Claude Code to interact with forge capabilities.
**Decision:** MCP server exposes 8 tools for forge operations
**Consequences:**
- Claude Code can invoke forge operations via MCP.
- Eight distinct tool functions for full forge lifecycle.
- Consistent with existing MCP server patterns.

---

## D-CF-10: Config in databridge_config.yaml under forge: block

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Configuration and templates must follow GOTCHA separation of concerns.
**Decision:** Config in databridge_config.yaml under forge: block
**Consequences:**
- Forge configuration colocated with DataBridge config.
- Follows GOTCHA args layer pattern.
- Single config file for all DataBridge-related settings.

---

## D-CF-19: Runbooks stored as JSON DAG

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The system must operate in air-gapped environments. Runbook task graphs need a portable representation.
**Decision:** Runbooks stored as JSON DAG (tasks_json + edges_json) in SQLite -- air-gap safe
**Consequences:**
- No external network dependencies required at runtime.
- DAG structure enables parallel task execution.
- SQLite storage provides portability.

---

## D-CF-20: Runbook executions are append-only with per-task log

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Federal compliance requirements (NIST 800-53 AU controls) mandate immutable execution records.
**Decision:** Runbook executions are append-only with per-task log (NIST AU compliance)
**Consequences:**
- Historical records cannot be modified or deleted.
- Per-task log enables granular execution audit.
- Satisfies NIST AU compliance requirements.

---

## D-CF-21: DAG execution uses Kahn's algorithm

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Probabilistic behavior in business logic leads to unreliable results. Runbook task ordering must be deterministic.
**Decision:** DAG execution uses Kahn's algorithm (topological sort) -- deterministic O(V+E), no LLM in critical path
**Consequences:**
- Results are reproducible across runs.
- O(V+E) time complexity for task ordering.
- No LLM involvement in execution critical path.

---

## D-CF-22: Snippets are self-contained sub-DAGs

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Runbook composition requires reusable building blocks that can be embedded by reference.
**Decision:** Snippets are self-contained sub-DAGs embedded by reference with usage count tracking
**Consequences:**
- Reusable runbook fragments across multiple runbooks.
- Usage count tracking for impact analysis.
- Self-contained design prevents cross-snippet dependencies.

---

## D-CF-23: Metastore uses adjacency list for dependency graph

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Data persistence strategy must support dependency graph traversal. Consistency with existing patterns (D27) is preferred.
**Decision:** Metastore uses adjacency list for dependency graph (matches D27 pattern, SQL joins)
**Consequences:**
- Consistent with supply chain graph pattern (D27).
- Standard SQL queries for dependency traversal.
- No additional database technology required.

---

## D-CF-24: Auto-discovery pulls from existing tables

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Application metastore needs to discover existing infrastructure without manual registration.
**Decision:** Auto-discovery pulls from db_connections, cf_landing_zones, devices -- idempotent upsert
**Consequences:**
- Existing infrastructure is automatically registered.
- Idempotent upsert prevents duplicate entries.
- Discovery sources span DataBridge, CloudForge, and Fleet.

---

## D-CF-25: Conditional branching uses deterministic expression eval

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Probabilistic behavior in business logic leads to unreliable results. Runbook branching must be deterministic and secure.
**Decision:** Conditional branching uses deterministic expression eval (key-operator-value triples, no eval())
**Consequences:**
- Results are reproducible across runs.
- No `eval()` prevents code injection attacks.
- Key-operator-value triples provide sufficient expressiveness.

---

## D-CF-26: AI runbook generation is non-critical-path

**Status:** Accepted
**Date:** 2026-03-08
**Context:** AI-generated runbooks need human review before execution. LLM output must not be directly executable.
**Decision:** AI runbook generation is non-critical-path, always outputs status='draft'
**Consequences:**
- Generated runbooks require human promotion to active status.
- LLM failures do not block runbook operations.
- Draft status clearly signals review needed.

---

## D-CF-27: RTO/RPO stored as hours (REAL) on cf_applications

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Recovery time/point objectives need simple comparison for compliance checking.
**Decision:** RTO/RPO stored as hours (REAL) on cf_applications -- simple numeric comparison
**Consequences:**
- Simple SQL comparison for RTO/RPO threshold checks.
- Hours provide sufficient granularity for enterprise applications.
- Stored directly on application record for fast access.

---

## D-CF-28: Single unified Ops MCP server with 18 tools

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Multi-agent communication requires well-defined protocols. Proliferation of MCP servers increases complexity.
**Decision:** Single unified Ops MCP server with 18 tools (reduces MCP server proliferation)
**Consequences:**
- One MCP server instead of multiple for ops domain.
- 18 tools cover runbooks, metastore, and cross-domain queries.
- Reduced configuration and maintenance overhead.

---

## D-CF-29: YAML runbook templates in args/cloudforge_runbook_templates/

**Status:** Accepted
**Date:** 2026-03-08
**Context:** Configuration and templates must follow GOTCHA separation of concerns.
**Decision:** YAML runbook templates in args/cloudforge_runbook_templates/ (GOTCHA args layer)
**Consequences:**
- Templates live in the GOTCHA args layer.
- Behavior changes without editing goals or tools.
- YAML format for human readability.

---

## D-CF-30: Community vs Pro feature split

**Status:** Accepted
**Date:** 2026-03-08
**Context:** The marketplace and community features require clear operational boundaries between free and paid tiers.
**Decision:** Community: 3 runbooks, no snippets/AI/discovery; Pro: unlimited
**Consequences:**
- Community tier has clear, documented limits.
- Pro tier removes all limits.
- Feature gating enforced at runtime.

---
