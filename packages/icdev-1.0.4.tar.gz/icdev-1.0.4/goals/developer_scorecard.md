# CUI // SP-CTI

# F8: Developer Scorecard

## Purpose

Compute per-developer and per-team quality scorecards across multiple dimensions: code quality, test coverage, compliance adherence, security posture, and documentation completeness. Provides trend tracking and gamified improvement signals.

## Prerequisites

- `data/icdev.db` initialized with project tables
- Code analysis results from `tools/analysis/code_analyzer.py`
- Test results from pytest/behave runs
- Compliance and security scan results

## Workflow Steps

### 1. Compute Scorecard
```bash
python tools/analytics/scorecard.py --compute --project-id "sparkpilot" --developer "dev-001" --json
```
**Expected output:** JSON with overall score (0-100), per-dimension scores (code_quality, test_coverage, compliance, security, documentation), letter grade (A-F), and dimension breakdown.

### 2. Get Trend
```bash
python tools/analytics/scorecard.py --trend --project-id "sparkpilot" --developer "dev-001" --window-days 30 --json
```
**Expected output:** JSON array of daily score snapshots with per-dimension values and trend direction (improving/stable/declining).

### 3. Get Latest Scorecard
```bash
python tools/analytics/scorecard.py --latest --project-id "sparkpilot" --developer "dev-001" --json
```
**Expected output:** JSON with most recent scorecard, comparison to previous period, and top 3 improvement recommendations.

### 4. Team Aggregation
```bash
python tools/analytics/scorecard.py --team --project-id "sparkpilot" --json
```
**Expected output:** JSON with team average scores, per-developer ranking, dimension-level team strengths and weaknesses.

### 5. Set Dimension Weights
```bash
python tools/analytics/scorecard.py --set-weights --project-id "sparkpilot" --weights '{"code_quality":0.25,"test_coverage":0.25,"compliance":0.20,"security":0.20,"documentation":0.10}' --json
```
**Expected output:** JSON confirming updated weights and recalculated sample score.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-INV-29 | Scorecard uses weighted average of 5 dimensions -- deterministic, reproducible |
| D-INV-30 | Letter grade thresholds: A >= 90, B >= 80, C >= 70, D >= 60, F < 60 |
| D-INV-31 | Trend computed from stored daily snapshots -- not recalculated retroactively |
| D-INV-32 | Default weights: code_quality 0.25, test_coverage 0.25, compliance 0.20, security 0.20, documentation 0.10 |

## Edge Cases

- Developer with no activity returns scorecard with all zeros and "no data" note
- Missing dimension data (e.g., no security scans) excluded from weighted average with note
- Single data point returns score without trend
- Team aggregation with one developer returns individual scorecard as team score

## Tier Gating

| Capability | Community | Pro |
|------------|-----------|-----|
| Individual scorecard | Yes | Yes |
| Trend tracking | Last 7 days | Unlimited |
| Latest with recommendations | Yes | Yes |
| Team aggregation | No | Yes |
| Custom dimension weights | No | Yes |

## Security

- Scorecard snapshots are append-only (NIST AU compliant)
- Developer identity stored as opaque ID -- no PII in scorecard tables
- CUI markings applied to exported reports
