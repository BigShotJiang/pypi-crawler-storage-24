# CUI // SP-CTI

# F4: AI-Generated Compliance Narratives

## Purpose

Generate human-quality compliance control narratives from structured evidence. Supports deterministic template-based generation (air-gap safe) with optional LLM enhancement for natural language polish. Includes review/approval workflow for compliance officer sign-off.

## Prerequisites

- `data/icdev.db` initialized with compliance controls and evidence
- Control mappings populated via `tools/compliance/control_mapper.py`
- For LLM-enhanced mode: LLM router configured in `args/llm_config.yaml`

## Workflow Steps

### 1. Generate Narrative
```bash
python tools/compliance/narrative_workflow.py --generate --project-id "sparkpilot" --control-id "AC-2" --mode deterministic --json
```
**Expected output:** JSON with narrative ID, control ID, generated text, mode (deterministic/llm), word count, and status (draft).

### 2. Submit for Review
```bash
python tools/compliance/narrative_workflow.py --submit-review --narrative-id "nar-001" --reviewer "isso@example.com" --json
```
**Expected output:** JSON with review ID, narrative ID, reviewer, submission timestamp, and status (pending_review).

### 3. Approve or Reject
```bash
python tools/compliance/narrative_workflow.py --approve --narrative-id "nar-001" --reviewer "isso@example.com" --json
python tools/compliance/narrative_workflow.py --reject --narrative-id "nar-001" --reviewer "isso@example.com" --comment "Needs more detail on monitoring" --json
```
**Expected output:** JSON with updated status (approved/rejected), reviewer, timestamp, and comment if rejected.

### 4. Batch Generate
```bash
python tools/compliance/narrative_workflow.py --batch --project-id "sparkpilot" --control-family AC --mode deterministic --json
```
**Expected output:** JSON with batch ID, count of narratives generated, success/failure counts, and per-control status.

### 5. Export Narratives
```bash
python tools/compliance/narrative_workflow.py --export --project-id "sparkpilot" --status approved --format markdown --json
```
**Expected output:** JSON with export path, narrative count, and CUI markings applied.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-INV-13 | Deterministic mode uses Jinja2 templates populated from evidence tables -- air-gap safe |
| D-INV-14 | LLM mode sends template output + evidence to worker tier for natural language polish |
| D-INV-15 | Review workflow is 3-state: draft -> pending_review -> approved/rejected |
| D-INV-16 | Narratives are versioned -- rejection creates new draft version, preserves history |

## Edge Cases

- Control with no evidence generates narrative stub with "[EVIDENCE NEEDED]" placeholders
- LLM unavailable falls back to deterministic mode silently
- Batch generation skips controls with approved narratives (use `--force` to regenerate)
- Rejected narrative preserves reviewer comment for next iteration

## Tier Gating

| Capability | Community | Pro |
|------------|-----------|-----|
| Deterministic generation | Yes | Yes |
| LLM-enhanced generation | No | Yes |
| Review/approval workflow | Yes | Yes |
| Batch generation | 10 controls max | Unlimited |
| Export with CUI markings | Yes | Yes |

## Security

- All narratives and reviews are append-only (NIST AU compliant)
- Reviewer identity logged for accountability
- CUI markings applied at generation time
- LLM inputs/outputs hashed in AI telemetry (D-216)
