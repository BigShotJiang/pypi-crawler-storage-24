# Goal: Systematic Debugging

## Description

Debug any issue using a 4-phase root cause methodology. Random fixes waste time and create new bugs. Quick patches mask underlying issues.

**Adapted from:** [obra/superpowers](https://github.com/obra/superpowers) systematic-debugging skill.

**The iron rule:** NO FIXES WITHOUT ROOT CAUSE INVESTIGATION FIRST. If you haven't completed Phase 1, you cannot propose fixes.

---

## When to Use

Use for ANY technical issue:
- Test failures
- Bugs in production or development
- Unexpected behavior
- Performance problems
- Build failures
- Integration issues
- Dashboard errors (500s, console errors)
- Database migration failures

**Use ESPECIALLY when:**
- Under time pressure (emergencies make guessing tempting)
- "Just one quick fix" seems obvious
- You've already tried multiple fixes
- Previous fix didn't work
- You don't fully understand the issue

---

## Prerequisites

- [ ] Issue clearly described (error message, stack trace, or observed behavior)
- [ ] `memory/MEMORY.md` loaded (session context)
- [ ] Access to relevant source files and logs

---

## Process

### Phase 1: Root Cause Investigation

**BEFORE attempting ANY fix:**

#### Step 1.1: Read Error Messages Carefully

- Don't skip past errors or warnings
- Read stack traces COMPLETELY
- Note line numbers, file paths, error codes
- Check for the exact error message — it often contains the solution

#### Step 1.2: Reproduce Consistently

- Can you trigger it reliably?
- What are the exact steps?
- Does it happen every time?
- If not reproducible → gather more data, don't guess

#### Step 1.3: Check Recent Changes

- `git diff` — what changed?
- Recent commits that could cause this
- New dependencies, config changes
- Environmental differences (Python version, DB backend, OS)

#### Step 1.4: Gather Evidence in Multi-Component Systems

When the system has multiple layers (dashboard → API → tool → database):

```
For EACH component boundary:
  - Log what data enters the component
  - Log what data exits the component
  - Verify environment/config propagation
  - Check state at each layer

Run once to gather evidence showing WHERE it breaks
THEN analyze evidence to identify the failing component
THEN investigate that specific component
```

**Example (ICDEV stack):**
```bash
# Layer 1: Dashboard template — does the JS call the right endpoint?
# Layer 2: Flask route in app.py — does it receive correct params?
# Layer 3: Tool function — does it return expected structure?
# Layer 4: Database — does the query return data?
```

#### Step 1.5: Trace Data Flow

- Where does the bad value originate?
- What called this with the bad value?
- Keep tracing up until you find the source
- Fix at source, not at symptom

**Tools available:**
```bash
python tools/testing/health_check.py --json          # System health
python tools/db/storage.py --health --json            # DB connectivity
python tools/monitor/log_analyzer.py --tail 50        # Recent logs
```

---

### Phase 2: Pattern Analysis

#### Step 2.1: Find Working Examples

- Locate similar working code in same codebase
- What works that's similar to what's broken?
- Compare function signatures, DB schemas, API patterns

#### Step 2.2: Compare Against References

- If implementing a pattern, read the reference implementation COMPLETELY
- Don't skim — read every line
- Understand the pattern fully before applying

#### Step 2.3: Identify Differences

- What's different between working and broken?
- List every difference, however small
- Don't assume "that can't matter"

**Common ICDEV-specific patterns to check:**
- PostgreSQL vs SQLite placeholder mismatch (`?` vs `%s` — handled by StorageConnection)
- BOOLEAN DEFAULT 0 vs DEFAULT FALSE (PostgreSQL incompatibility)
- Missing `ensure_*_tables()` call before first DB access
- API endpoint signature mismatch between `app.py` route and tool function
- Template API path not matching Flask route

---

### Phase 3: Hypothesis and Testing

#### Step 3.1: Form Single Hypothesis

- State clearly: "I think X is the root cause because Y"
- Be specific, not vague

#### Step 3.2: Test Minimally

- Make the SMALLEST possible change to test hypothesis
- One variable at a time
- Don't fix multiple things at once

#### Step 3.3: Verify Before Continuing

- Did it work? Yes → Phase 4
- Didn't work? Form NEW hypothesis
- DON'T add more fixes on top

#### Step 3.4: When You Don't Know

- Say "I don't understand X"
- Don't pretend to know
- Ask the user for help
- Research more

---

### Phase 4: Implementation

#### Step 4.1: Create Failing Test Case

- Simplest possible reproduction
- Automated test if possible (pytest)
- One-off script if no framework applies
- MUST have before fixing

**Tool:** `python tools/builder/test_writer.py --project <name> --requirement "<bug description>"`

#### Step 4.2: Implement Single Fix

- Address the ROOT CAUSE identified
- ONE change at a time
- No "while I'm here" improvements
- No bundled refactoring

#### Step 4.3: Verify Fix

- Test passes now?
- No other tests broken?
- Issue actually resolved?
- Run: `python tools/testing/health_check.py --json`

#### Step 4.4: If Fix Doesn't Work — STOP

Count: How many fixes have you tried?

- **If < 3:** Return to Phase 1, re-analyze with new information
- **If ≥ 3:** STOP and question the architecture

**3+ failed fixes = architectural problem:**
- Each fix reveals new shared state/coupling/problem in different place
- Fixes require "massive refactoring" to implement
- Each fix creates new symptoms elsewhere

**Discuss with user before attempting more fixes.**

#### Step 4.5: Log the Fix

```bash
python tools/memory/memory_write.py --content "Bug: <description>. Root cause: <cause>. Fix: <what changed>." --type insight --importance 6
```

---

## Red Flags — STOP and Return to Phase 1

If you catch yourself thinking:
- "Quick fix for now, investigate later"
- "Just try changing X and see if it works"
- "Add multiple changes, run tests"
- "Skip the test, I'll manually verify"
- "It's probably X, let me fix that"
- "I don't fully understand but this might work"
- "One more fix attempt" (when already tried 2+)
- Proposing solutions before tracing data flow

**ALL of these mean: STOP. Return to Phase 1.**

---

## Common Rationalizations

| Excuse | Reality |
|--------|---------|
| "Issue is simple, don't need process" | Simple issues have root causes too. Process is fast for simple bugs. |
| "Emergency, no time for process" | Systematic debugging is FASTER than guess-and-check. |
| "Just try this first, then investigate" | First fix sets the pattern. Do it right from the start. |
| "I'll write test after confirming fix" | Untested fixes don't stick. Test first proves it. |
| "Multiple fixes at once saves time" | Can't isolate what worked. Causes new bugs. |
| "I see the problem, let me fix it" | Seeing symptoms ≠ understanding root cause. |

---

## Quick Reference

| Phase | Key Activities | Success Criteria |
|-------|---------------|------------------|
| **1. Root Cause** | Read errors, reproduce, check changes, trace data | Understand WHAT and WHY |
| **2. Pattern** | Find working examples, compare differences | Identify what's different |
| **3. Hypothesis** | Form theory, test minimally, one variable | Confirmed or new hypothesis |
| **4. Implementation** | Create test, fix root cause, verify | Bug resolved, tests pass |

---

## Compliance Integration

- All bug fixes MUST be logged to audit trail (NIST AU-3)
- Security bugs require `python tools/security/sast_runner.py` re-scan after fix
- If fix changes compliance posture, re-run crosswalk: `python tools/compliance/crosswalk_engine.py --control <affected-control>`
