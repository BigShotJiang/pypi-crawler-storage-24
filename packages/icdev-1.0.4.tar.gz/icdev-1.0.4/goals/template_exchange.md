# CUI // SP-CTI

# F2: Community Compliance Template Exchange

## Purpose

Enable sharing, discovery, and reuse of compliance templates (SSP sections, POAM entries, control narratives) across projects and tenants. Community-driven with ratings and quality scoring.

## Prerequisites

- `data/icdev.db` initialized with compliance tables
- At least one project created via `tools/agent/core_mcp_server.py`

## Workflow Steps

### 1. Create Template
```bash
python tools/compliance/template_exchange.py --create --project-id "sparkpilot" --name "AC-2 Narrative" --framework "NIST 800-53" --control-id "AC-2" --content-file /path/to/template.md --json
```
**Expected output:** JSON with template ID, metadata, version, and publication status (draft).

### 2. List and Search Templates
```bash
python tools/compliance/template_exchange.py --list --framework "NIST 800-53" --json
python tools/compliance/template_exchange.py --search --query "access control" --json
```
**Expected output:** JSON array of templates with ID, name, framework, rating, download count.

### 3. Rate Template
```bash
python tools/compliance/template_exchange.py --rate --template-id "tpl-001" --rating 4 --comment "Clear and thorough" --json
```
**Expected output:** JSON with updated average rating and total review count.

### 4. Publish Template
```bash
python tools/compliance/template_exchange.py --publish --template-id "tpl-001" --json
```
**Expected output:** JSON with publication status, visibility scope, and shareable reference ID.

### 5. Import Template
```bash
python tools/compliance/template_exchange.py --import --template-id "tpl-001" --target-project "sparkpilot" --json
```
**Expected output:** JSON with imported template ID, adaptation notes, and control mapping status.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-INV-5 | Templates stored as versioned rows in SQLite -- full history preserved |
| D-INV-6 | Rating uses 1-5 integer scale with weighted average (recent reviews weighted higher) |
| D-INV-7 | Search uses BM25 keyword matching on template name, description, and content |
| D-INV-8 | Cross-project import creates a copy -- no shared mutable state between projects |

## Edge Cases

- Importing a template for a different framework maps controls via crosswalk engine
- Empty search query returns top-rated templates
- Duplicate template name within same project appends version suffix
- Deleted source template does not affect already-imported copies

## Tier Gating

| Capability | Community | Pro |
|------------|-----------|-----|
| Create templates | 5 max | Unlimited |
| Search and browse | Yes | Yes |
| Rate templates | Yes | Yes |
| Publish to exchange | Yes | Yes |
| Cross-project import | No | Yes |

## Security

- Template content scanned for secrets before publication
- CUI markings enforced on all templates at publication time
- Audit trail logged for all create/publish/import operations
