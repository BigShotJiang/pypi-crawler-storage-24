# CUI // SP-CTI

# F1: cATO Live Evidence Engine

## Purpose

Continuously collect, stream, and refresh compliance evidence for continuous Authority to Operate (cATO). Replaces periodic manual evidence gathering with automated, schedule-driven collection tied to OSCAL-formatted control catalogs.

## Prerequisites

- `data/icdev.db` initialized with compliance tables
- OSCAL catalog loaded via `tools/compliance/oscal_generator.py`
- Control mappings populated via `tools/compliance/control_mapper.py`

## Workflow Steps

### 1. Stream OSCAL Evidence
```bash
python tools/compliance/cato_live_engine.py --stream-oscal --project-id "sparkpilot" --json
```
**Expected output:** JSON with `oscal_stream` array of control-evidence pairs, timestamps, and freshness scores.

### 2. Get Evidence Dashboard
```bash
python tools/compliance/cato_live_engine.py --dashboard --project-id "sparkpilot" --json
```
**Expected output:** JSON summary with total controls, evidence coverage percentage, stale count, and freshness histogram.

### 3. Get Evidence Timeline
```bash
python tools/compliance/cato_live_engine.py --timeline --project-id "sparkpilot" --window-days 30 --json
```
**Expected output:** JSON array of evidence collection events with timestamps, control IDs, source, and staleness flags.

### 4. Trigger Evidence Collection
```bash
python tools/compliance/cato_live_engine.py --collect --project-id "sparkpilot" --control-family AC --json
```
**Expected output:** JSON with collection results per control, new evidence count, errors, and next scheduled run.

### 5. Check Freshness SLA
```bash
python tools/compliance/cato_live_engine.py --freshness-check --project-id "sparkpilot" --sla-hours 24 --json
```
**Expected output:** JSON with SLA compliance status, stale controls list, and recommended actions.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-INV-1 | Evidence stored in append-only SQLite tables (NIST AU compliant) |
| D-INV-2 | OSCAL streaming uses incremental diff -- only changed controls re-collected |
| D-INV-3 | Freshness scored 0.0-1.0 based on hours since last collection vs SLA threshold |
| D-INV-4 | Scheduler uses stdlib `sched` module -- no external dependencies |

## Edge Cases

- Missing OSCAL catalog returns error with setup instructions
- Stale evidence older than 2x SLA flagged as CRITICAL, not just WARNING
- Air-gapped mode: all collection is local scan only, no external API calls
- Empty control family returns note listing available families

## Tier Gating

| Capability | Community | Pro |
|------------|-----------|-----|
| Manual evidence collection | Yes | Yes |
| Evidence dashboard | Yes | Yes |
| Automated scheduling | No | Yes |
| 24h freshness SLA enforcement | No | Yes |
| OSCAL streaming with incremental diff | No | Yes |

## Security

- All evidence records are append-only (NIST AU compliant)
- Collection audit trail logged to `audit_trail` table
- CUI markings applied to all generated evidence artifacts
