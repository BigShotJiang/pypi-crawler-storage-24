# CUI // SP-CTI
# Harness Engineering — AI Agent Orchestration Scaffolding

## Purpose
Ensure AI agents operate reliably through structured constraints, feedback loops,
progress tracking, and self-correcting middleware. Harness engineering is the
discipline of building the system around the model — not the model itself.

## References
- Anthropic: "Effective Harnesses for Long-Running Agents"
- OpenAI: "Harness Engineering"
- LangChain: "Improving Deep Agents with Harness Engineering"
- Mitchell Hashimoto: Harness Engineering adoption path

## Architecture Decisions
- D-HARNESS-1: Loop state in .tmp/sessions/ JSON (ephemeral, not DB)
- D-HARNESS-2: Loop detection is soft-signal only (stderr, exit 0)
- D-HARNESS-3: Progress file is JSON (models handle structured data better)
- D-HARNESS-4: Exit criteria in args/ YAML (GOTCHA separation)
- D-HARNESS-5: Trace analyzer scanner-tier only (zero Claude tokens)
- D-HARNESS-6: Maturity assessor read-only, advisory-only
- D-HARNESS-7: Scaffolder generates 3 hooks (minimal), not all 7
- D-HARNESS-8: One new append-only DB table (harness_trace_recommendations)

## Maturity Levels
| Level | Name | Description |
|-------|------|-------------|
| 0 | None | Raw model calls, no structure |
| 1 | Initial | Fixed pipeline with stable prompts |
| 2 | Managed | Token budgets, input/output validation |
| 3 | Defined | Exit criteria the agent evaluates itself |
| 4 | Optimized | Harness as infrastructure — versioned, monitored, rollback-able |

## Components

### 1. Loop Detection Middleware
- **Where:** .claude/hooks/post_tool_use.py
- **What:** Tracks (tool_name, file_path) edits per session
- **Config:** args/harness_config.yaml → loop_detection block
- **Behavior:** Warn at threshold (default 5), escalate at 2x (default 10)
- **Output:** stderr warnings (soft signal, never blocks)

### 2. Progress Tracking
- **Where:** .claude/hooks/post_tool_use.py + stop.py
- **What:** Appends significant events to .tmp/sessions/{session_id}/progress.json
- **Tracks:** files_modified, files_created, tests_run/passed/failed, events
- **Config:** args/harness_config.yaml → progress_tracking block

### 3. Exit Criteria Registry
- **Where:** args/exit_criteria.yaml
- **What:** Machine-readable exit conditions per workflow type
- **Workflows:** build, test, deploy, comply, secure, review
- **Evaluator:** tools/harness/exit_criteria_evaluator.py

### 4. Trace-Driven Improvement
- **Where:** tools/harness/trace_analyzer.py
- **What:** Analyzes hook_events for patterns, suggests improvements
- **Detects:** Repetitive edits, long sessions, loop state triggers
- **Stores:** harness_trace_recommendations table (append-only)

### 5. Maturity Assessor
- **Where:** tools/harness/maturity_assessor.py
- **What:** Scores project 0-4 across 6 dimensions
- **Dimensions:** hooks, gates, exit criteria, tracing, loop detection, progress
- **Read-only:** Never modifies files

### 6. Harness Scaffolder
- **Where:** tools/harness/scaffold_harness.py
- **What:** Generates baseline harness for child apps
- **Output:** 3 hooks, harness_config.yaml, exit_criteria.yaml, security_gates.yaml
- **Impact-level:** IL4+ gets stricter gates

## Workflow

1. **Assess** — Run maturity assessor on project: `python tools/harness/maturity_assessor.py --project-dir . --json`
2. **Scaffold** — If missing, generate baseline: `python tools/harness/scaffold_harness.py --output-dir . --json`
3. **Configure** — Tune args/harness_config.yaml thresholds for project needs
4. **Monitor** — Loop detection + progress tracking run automatically via hooks
5. **Analyze** — Periodically run trace analyzer: `python tools/harness/trace_analyzer.py --last-n 5 --json`
6. **Evaluate** — Before declaring done, check exit criteria: `python tools/harness/exit_criteria_evaluator.py --workflow build --json`

## Security Gate
```yaml
harness:
  blocking:
    - loop_detection_threshold_exceeded_critical
  warning:
    - loop_detection_escalation_triggered
    - exit_criteria_not_defined
    - harness_maturity_below_managed
```
