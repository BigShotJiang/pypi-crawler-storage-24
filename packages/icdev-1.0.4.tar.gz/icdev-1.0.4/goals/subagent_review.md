# Goal: Two-Stage Subagent Review

## Description

When dispatching work to subagents, enforce a two-stage review after each task: first spec compliance (did it match requirements?), then code quality (is it well-built?). This catches both under-building and over-building.

**Adapted from:** [obra/superpowers](https://github.com/obra/superpowers) subagent-driven-development skill.

**The principle:** Fresh subagent per task + two-stage review (spec then quality) = high quality, fast iteration.

---

## When to Use

- Executing implementation plans via subagents
- Any task dispatched with the Agent tool
- Multi-step implementations where quality matters
- Phase implementations (Forge Studio phases, feature rollouts)

**When NOT to use:**
- Simple research/exploration agents (Explore subagent type)
- One-off file searches
- Read-only operations

---

## Prerequisites

- [ ] Implementation plan exists (from `goals/bite_sized_plans.md` or clear user directive)
- [ ] Tasks are mostly independent (tightly coupled tasks should be sequential)

---

## Process

### Step 1: Extract All Tasks Upfront

Read the plan once. Extract all tasks with full text and context. Create a TodoWrite with all tasks. Do NOT make the subagent read the plan file — provide the full text directly.

### Step 2: Per-Task Cycle

For each task:

```
1. Dispatch IMPLEMENTER subagent
   - Provide: full task text, context, relevant file paths
   - Subagent: implements, tests, commits, self-reviews

2. If implementer asks questions → answer, re-dispatch

3. Dispatch SPEC REVIEWER subagent
   - Provide: original task spec, list of changed files
   - Reviewer checks:
     ✓ All requirements from spec are implemented
     ✓ Nothing extra was added (YAGNI)
     ✓ Edge cases from spec are covered
   - If issues found → implementer fixes → re-review

4. Dispatch CODE QUALITY REVIEWER subagent
   - Provide: changed files, project conventions
   - Reviewer checks:
     ✓ Code follows codebase patterns
     ✓ No security vulnerabilities (OWASP top 10)
     ✓ Tests are meaningful (not just coverage)
     ✓ No magic numbers, clear naming
     ✓ CUI markings present (if applicable)
   - If issues found → implementer fixes → re-review

5. Mark task complete in TodoWrite
```

**CRITICAL ORDER:** Spec compliance FIRST, then code quality. Never start quality review before spec is approved.

### Step 3: Implementer Prompt Template

When dispatching the implementer subagent:

```markdown
## Task: [Task name from plan]

### Context
[Where this fits in the larger feature. What was built before. What comes after.]

### Requirements
[Full task text from plan — copy-paste, don't summarize]

### Files to Reference
[List of existing files the implementer needs to read]

### Constraints
- Follow TDD: write failing test first, then implement
- Use existing patterns from codebase (get_connection(), log_forge_event(), etc.)
- Include CUI // SP-CTI marking on new files
- Commit after completing the task

### Expected Output
- Summary of what was implemented
- List of files created/modified
- Test results (paste output)
```

### Step 4: Spec Reviewer Prompt Template

```markdown
## Spec Compliance Review

### Original Specification
[Full task text from plan]

### Files Changed
[List of files the implementer created/modified]

### Review Checklist
1. Are ALL requirements from the spec implemented?
2. Is anything EXTRA added that wasn't requested? (YAGNI violation)
3. Are edge cases from the spec covered?
4. Do function signatures match what the spec described?
5. Does the implementation match the architecture described?

### Output Format
- ✅ Spec compliant — all requirements met, nothing extra
- ❌ Issues found:
  - Missing: [what's not implemented]
  - Extra: [what was added but not requested]
  - Wrong: [what doesn't match spec]
```

### Step 5: Code Quality Reviewer Prompt Template

```markdown
## Code Quality Review

### Files to Review
[List of changed files with line ranges]

### Project Conventions
- Python with `from __future__ import annotations`
- DB via `from tools.db.storage import get_connection`
- Audit via `log_forge_event()` or audit_trail INSERT
- UUIDs: `uuid.uuid4().hex`
- Timestamps: `datetime.now(timezone.utc).isoformat()`
- CUI marking: `# CUI // SP-CTI` on line 1 of new files
- PostgreSQL compatible (BOOLEAN DEFAULT FALSE, not DEFAULT 0)

### Review Checklist
1. Follows codebase patterns and conventions?
2. No security vulnerabilities (injection, XSS, eval)?
3. Tests are meaningful (test behavior, not implementation)?
4. Error handling appropriate?
5. No magic numbers or unclear naming?
6. Audit trail entries for state changes?

### Output Format
- ✅ Approved — code quality good
- ❌ Issues:
  - [Category]: [Description] (file:line)
```

### Step 6: After All Tasks Complete

1. Dispatch a FINAL reviewer subagent across the entire implementation
2. Run full verification (`goals/verification_iron_law.md`)
3. Update TodoWrite — all tasks completed

---

## Red Flags — STOP

- Skipping spec review ("code looks good, skip to quality")
- Skipping quality review ("spec passed, we're done")
- Not re-reviewing after fixes ("they said they fixed it")
- Dispatching multiple implementer subagents in parallel on dependent tasks
- Letting implementer self-review replace actual review
- Proceeding with unfixed issues
- Starting code quality review before spec compliance is approved

---

## When Subagent Fails

- **Asks questions:** Answer clearly and completely, re-dispatch
- **Can't complete task:** Dispatch a FIX subagent with specific instructions. Don't fix manually (context pollution)
- **Review finds issues:** Implementer fixes, reviewer re-reviews. Repeat until approved.
- **3+ review loops:** Stop. The task spec may be unclear. Revisit the plan.

---

## Efficiency Notes

**Cost:** More subagent invocations (implementer + 2 reviewers per task).
**Benefit:** Catches issues early. Cheaper than debugging later. Prevents scope creep (YAGNI). Ensures codebase consistency.

**Optimization:** For trivial tasks (single-line changes, config updates), the orchestrator can combine spec + quality review into a single pass.

---

## Integration

| Related Goal | Relationship |
|-------------|-------------|
| `bite_sized_plans.md` | Creates the plans this goal executes |
| `verification_iron_law.md` | Final verification after all tasks |
| `systematic_debugging.md` | Used when implementation hits bugs |
| `brainstorming_gate.md` | Design must be approved before plans are written |
| `tdd_workflow.md` | Each implementer subagent follows TDD |
