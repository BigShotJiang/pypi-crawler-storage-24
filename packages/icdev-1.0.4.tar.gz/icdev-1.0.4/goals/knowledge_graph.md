# CUI // SP-CTI
# Knowledge Graph Engine — GOTCHA Goal

## Purpose
InfraNodus-style text network analysis integrated with ICDEV's RAG pipeline.
Converts text from any source into interactive co-occurrence knowledge graphs,
detects topic clusters, identifies structural gaps (blind spots), and generates
AI-powered research questions to bridge disconnected concepts.

## Architecture Decisions
- D-KG-1: Pure Python stdlib + minimal deps (air-gap safe)
- D-KG-2: SQL adjacency list storage (matches D27 pattern)
- D-KG-3: Louvain community detection (deterministic, no LLM in critical path)
- D-KG-4: 4-gram sliding window for co-occurrence (InfraNodus standard)
- D-KG-5: Structural gap = high-distance cross-cluster node pairs
- D-KG-6: stdlib urllib + html.parser for web scraping (air-gap safe)
- D-KG-7: Pluggable source adapters (add new types without modifying core)
- D-KG-8: GraphRAG enhances (not replaces) existing corrective_rag.py
- D-KG-9: Query expansion via graph neighborhood traversal (BFS depth=2)
- D-KG-10: Scoring = 0.4 * relevance + 0.3 * centrality + 0.3 * proximity
- D-KG-11: Scanner-tier LLM routing (qwen3.5 local, zero Claude tokens)
- D-KG-12: Deterministic gap detection first, LLM enrichment second
- D-KG-13: All AI outputs are advisory-only (never modifies graph)
- D-KG-14: Portable for child apps — no ICDEV-specific dependencies in core engine

## Workflow

### 1. Ingest Source
- **Tool**: `tools/knowledge_graph/ingester.py`
- **Sources**: text, file (TXT/MD/CSV/JSON/code), URL, YouTube, database, code directory
- **Output**: Extracted text string

### 2. Build Text Network
- **Tool**: `tools/knowledge_graph/text_network.py`
- **Steps**:
  1. Tokenize (lowercase, stop removal, rule-based lemmatization)
  2. Build co-occurrence graph (4-gram sliding window)
  3. Compute betweenness centrality (Brandes algorithm, O(VE))
  4. Detect communities (Louvain modularity optimization)
  5. Find structural gaps (cross-cluster edge density analysis)
- **Output**: Nodes + edges + communities + gaps + stats

### 3. Persist to Database
- **Tables**: `kg_graphs`, `kg_nodes`, `kg_edges`, `kg_gaps`, `kg_ingestions`
- **Pattern**: SQL adjacency list (matches D27)
- **Incremental**: `append_to_graph()` merges new text into existing graphs

### 4. GraphRAG Retrieval
- **Tool**: `tools/knowledge_graph/graph_rag.py`
- **Steps**:
  1. Tokenize query → seed nodes
  2. Match to graph nodes (exact + partial)
  3. BFS neighborhood expansion (depth=2)
  4. Score: 0.4 * relevance + 0.3 * centrality + 0.3 * proximity
  5. Include community context + structural gap context
- **Integration**: Enriches existing corrective_rag.py, doesn't replace it

### 5. AI Insight Generation
- **Tool**: `tools/knowledge_graph/insight_generator.py`
- **Capabilities**:
  - Research question generation (template-based + LLM)
  - Community summarization (label + description)
  - Deep gap analysis (bridge candidates + narrative)
  - Layer peeling (remove top nodes → reveal hidden concepts)
- **LLM Tier**: Scanner (qwen3.5 local, zero Claude tokens)

### 6. Visualization
- **Dashboard**: `/knowledge-graph` route
- **Features**:
  - Force Atlas / Circular / Grid layouts
  - Node sizing by centrality / degree / occurrences
  - Community color coding (12-color palette)
  - Interactive: drag, pan, zoom, hover tooltips
  - Structural gap display panel
  - GraphRAG chat panel (queries codebase/infrastructure/frameworks)

## Edge Cases
- Empty or very short text → return error with token count
- Single-word text → insufficient for co-occurrence → error
- Very large text (>100K tokens) → cap at max_nodes/max_edges config
- No captions on YouTube video → graceful error message
- Database source with empty table → error with row count
- LLM unavailable → deterministic-only mode (all features work without LLM)

## Portability (Child Apps)
- Core engine (`text_network.py`) has zero ICDEV-specific imports
- Ingester sources are pluggable — child apps register their own
- Dashboard template extends `base.html` (works with any Flask app)
- Database tables are self-contained (no FK to other ICDEV tables)
- Config in `args/knowledge_graph_config.yaml` (GOTCHA args layer)
- RAG source registry entries are additive (child apps can add more)

## Testing
- Unit tests: tokenization, co-occurrence, centrality, Louvain, gap detection
- Integration: full pipeline from text → graph → query → insights
- E2E: dashboard loads, analyze text, view graph, use chat
- Edge cases: empty text, unicode, very large input, missing LLM

## CLI Commands
```bash
# Analyze text
python tools/knowledge_graph/text_network.py --text "your text" --save --json

# Ingest from URL
python tools/knowledge_graph/ingester.py --url "https://example.com" --name "Article" --json

# Ingest from YouTube
python tools/knowledge_graph/ingester.py --youtube "https://youtube.com/watch?v=xxx" --json

# Ingest from ICDEV database
python tools/knowledge_graph/ingester.py --db-source compliance_controls --json

# Ingest codebase
python tools/knowledge_graph/ingester.py --code-dir tools/ --name "ICDEV Codebase" --json

# Append to existing graph
python tools/knowledge_graph/ingester.py --text "more text" --graph-id <id> --json

# GraphRAG query
python tools/knowledge_graph/graph_rag.py --query "zero trust architecture" --json

# AI insights
python tools/knowledge_graph/insight_generator.py --graph-id <id> --questions --json
python tools/knowledge_graph/insight_generator.py --graph-id <id> --layer-peel --json

# List saved graphs
python tools/knowledge_graph/text_network.py --list --json
```
