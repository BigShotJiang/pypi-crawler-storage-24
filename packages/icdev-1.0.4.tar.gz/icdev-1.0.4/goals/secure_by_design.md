# CUI // SP-CTI
# Goal: Secure by Design Assessment & Remediation

## Purpose
Assess, remediate, and maintain CISA Secure by Design compliance aligned with
Cloudyrion's 8-Pillar SbD Framework. Applies to ICDEV, all modules, and child apps.

## When to Use
- New project initialization (post-Golden Path scaffold)
- Pre-ATO compliance workflow (Step 15 of compliance_workflow.md)
- After significant architectural changes
- Quarterly SbD posture review
- When onboarding a new child application

## Prerequisites
- Project registered in icdev.db
- Project directory accessible for auto-checks
- SECURITY.md and .well-known/security.txt present (CISA Commitment 5)

---

## Workflow Steps

### Step 1: Run SbD Assessment
```bash
python tools/compliance/sbd_assessor.py \
  --project-id "<project_id>" \
  --project-dir "<path>" \
  --gate \
  --json
```
**Expected:** JSON with 35 requirement results, domain summary, gate result.
**Gate criteria:** 0 critical-priority requirements with status `not_satisfied`.

### Step 2: Review CISA 7 Commitments Status
Check these specifically (all must be satisfied for CISA pledge compliance):
1. **MFA** (SBD-01) — Multi-factor authentication enforced
2. **Default Passwords** (SBD-02) — Zero hardcoded credentials
3. **Vuln Class Reduction** (SBD-03, SBD-04) — Memory-safe language + tooling
4. **Security Patching** (SBD-05) — Dependabot/Renovate configured
5. **Vuln Disclosure** (SBD-06) — SECURITY.md present
6. **CVE Transparency** (SBD-07) — CVE tracking process documented
7. **Intrusion Evidence** (SBD-08, SBD-09, SBD-10) — Audit logging complete

### Step 3: Review Exception Registry
```bash
python tools/compliance/sbd_assessor.py \
  --project-id "<project_id>" \
  --list-exceptions \
  --json
```
**Check for:**
- Expired exceptions (must be renewed or remediated)
- Exceptions aging > 90 days (Cloudyrion anti-pattern: lingering exceptions)
- High/critical blast-radius exceptions without compensating controls

### Step 4: Remediate Findings
For each `not_satisfied` requirement:
1. Identify the root cause from evidence/details
2. Implement the fix
3. Re-run the specific domain assessment to verify
4. If remediation is not feasible, register an exception:
```bash
python tools/compliance/sbd_assessor.py \
  --project-id "<project_id>" \
  --register-exception \
  --requirement-id "SBD-XX" \
  --title "Description" \
  --justification "Why this cannot be remediated now" \
  --owner "person@org" \
  --duration-days 90 \
  --blast-radius medium
```

### Step 5: Generate SbD Report
```bash
python tools/compliance/sbd_report_generator.py \
  --project-id "<project_id>" \
  --json
```

### Step 6: Update Developer Scorecard
```bash
python tools/analytics/scorecard.py \
  --project-id "<project_id>" \
  --compute \
  --json
```
**Check:** `sbd_posture` dimension score >= 80 for Level 3 compliance.

### Step 7: Cross-Framework Mapping (Optional)
```bash
python tools/compliance/crosswalk_engine.py \
  --framework cisa_sbd \
  --project-id "<project_id>" \
  --coverage
```

---

## Cloudyrion 8-Pillar Alignment

| Pillar | ICDEV Implementation | Key Tools |
|--------|---------------------|-----------|
| P1: Proactive Design | Threat modeling at project kickoff | `threat_modeler.py` |
| P2: Holistic Stack | SBOM + supply chain + firmware SBOM | `sbom_generator.py`, `scrm_assessor.py` |
| P3: Shared Ownership | Security champion per project | Developer Scorecard `sbd_posture` |
| P4: Adaptive Architecture | Plugin MCP architecture, GOTCHA layers | `golden_path.py` |
| P5: Assume Breach | ZTA 7-pillar, mTLS, NetworkPolicy | `zta_maturity_scorer.py` |
| P6: Risk-Driven | Readiness scoring, Monte Carlo | `readiness_scorer.py`, `monte_carlo.py` |
| P7: Customer-First | Secure defaults, progressive compliance | `golden_path.py`, SECURITY.md |
| P8: Continuous Improvement | Harness trace analyzer, knowledge self-heal | `trace_analyzer.py` |

## Gates
- **SbD gate blocks on:** critical SBD requirements not satisfied, default credentials, no MFA, no VDP, stack traces in production
- **Exception gate blocks on:** any expired exceptions (must renew or remediate)
- **Scorecard gate:** `sbd_posture` score < 60 = FAIL

## Child App Inheritance
Every child app scaffolded via Golden Path automatically receives:
- `SECURITY.md` (vulnerability disclosure policy)
- `.well-known/security.txt` (RFC 9116)
- `args/sbd_gates.yaml` (SbD gate configuration)
- CUI markings on all generated files
- `.gitignore` excluding secrets

## Related Goals
- `compliance_workflow.md` — SbD is Step 15 of the ATO pipeline
- `security_scan.md` — SAST, dependency audit, secret detection
- `zero_trust_architecture.md` — ZTA 7-pillar maturity
- `harness_engineering.md` — Maturity assessment, trace analysis

////////////////////////////////////////////////////////////////////
CUI // SP-CTI | Department of Defense
////////////////////////////////////////////////////////////////////
