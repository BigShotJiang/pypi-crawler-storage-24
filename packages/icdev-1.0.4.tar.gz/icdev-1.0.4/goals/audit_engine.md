# Goal: Audit Engine — Unified Compliance Report Card

## Description

The Audit Engine provides a unified compliance report card for ICDEV, modules, child apps, and bring-your-own-software (BYOS). It scans targets against all supported compliance frameworks, generates per-regime scores with side-by-side gap analysis, and provides AI-powered recommendations for score improvement.

### Key Capabilities

1. **Multi-regime scoring** — Scan once, score against all 8 frameworks (NIST 800-53, 800-171, FedRAMP, CMMC, CISA SbD, DoD CSSP, IEEE 1012, DoDI 5000.87)
2. **Side-by-side comparison** — "I'm 800-171 compliant — what do I need for 800-53?"
3. **AI-powered recommendations** — Dual-ranked by impact (biggest score boost) and effort (easiest to implement)
4. **BYOS scanning** — Audit any codebase via directory path or git URL (SSH + HTTPS)
5. **Pluggable regimes** — Drop JSON files into `args/audit_regimes/` for custom frameworks
6. **Eject-ready** — Package as standalone application via eject scaffold

---

## Pipeline: SCAN → EVALUATE → SCORE → ADVISE → REPORT

### Phase 1: SCAN — Collect Evidence

#### Tools Used
- `tools/audit_engine/scanner.py` — Orchestrates all scanners
- `tools/security/sast_runner.py` — SAST analysis (fallback: builtin patterns)
- `tools/security/secret_detector.py` — Secret detection (fallback: regex patterns)
- `tools/security/dependency_auditor.py` — Dependency vulnerability audit
- `tools/compliance/stig_checker.py` — STIG compliance (ICDEV/child apps only)
- `tools/compliance/sbom_generator.py` — SBOM generation
- `tools/compliance/sbd_assessor.py` — Secure by Design assessment

#### Pre-conditions
- Target path exists (directory or valid git URL)
- For git URLs: auth credentials available (SSH key or HTTPS token)

#### Implementation Steps
1. Determine target type (auto-detect or explicit)
2. If git URL: clone via `git_fetcher.py`
3. Run applicable scanners based on target type
4. Normalize findings into `AuditEvidence` format
5. Aggregate into scan result

#### Post-conditions
- Scan result dict with evidence from all sources
- No modification to target files

---

### Phase 2: EVALUATE — Map Evidence to Controls

#### Tools Used
- `tools/audit_engine/engine.py` — Core evaluation logic
- `tools/audit_engine/regime_loader.py` — Load regime definitions

#### Implementation Steps
1. Load regime definition(s) from `args/audit_regimes/`
2. For each control in regime:
   a. Check explicit evidence sources from regime YAML/JSON
   b. Fall back to NIST control-family heuristic mapping
   c. Determine status: pass / partial / fail / not_applicable / not_assessed
3. Compute per-category scores

#### Scoring Formula
```
category_score = (passed + 0.5 * partial) / (total - not_applicable) * 100
overall_score = weighted average across categories
```

---

### Phase 3: SCORE — Generate Report Card

#### Tools Used
- `tools/audit_engine/report_card.py` — Format output
- `tools/audit_engine/engine.py` — Store results

#### Implementation Steps
1. Compute letter grade from score (A+ ≥ 95, A ≥ 90, ... F < 50)
2. Generate report card with per-regime cards
3. Store results in `audit_engine_results` and `audit_engine_scores` tables
4. Log audit event to `audit_trail` (append-only, D6)

---

### Phase 4: ADVISE — AI Recommendations

#### Tools Used
- `tools/audit_engine/ai_advisor.py` — Recommendation engine

#### Implementation Steps
1. Identify failing/partial controls across all regimes
2. Deduplicate (same NIST control across multiple regimes = one recommendation)
3. Map to recommendation catalog (deterministic, scanner tier)
4. Calculate impact score (severity × status weight)
5. Calculate effort score (config change = 1, architecture = 7)
6. Compute ROI = impact / effort
7. Optionally enhance with LLM (worker tier) for top 5 by impact
8. Return three ranked lists: by_impact, by_effort, by_roi + quick_wins

---

### Phase 5: REPORT — Output and Compare

#### Tools Used
- `tools/audit_engine/comparator.py` — Side-by-side comparison
- `tools/audit_engine/report_card.py` — Format output

#### Implementation Steps
1. If comparison requested: build crosswalk map between regimes
2. Identify shared, baseline-only, and target-only controls
3. Compute gap analysis (failing controls unique to target)
4. Generate human-readable recommendation summary
5. Output in selected format (JSON, Markdown, terminal)

---

## CLI Commands

```bash
# Full audit scan
python tools/audit_engine/cli.py scan --json
python tools/audit_engine/cli.py scan --target /path --type byos --json
python tools/audit_engine/cli.py scan --target https://github.com/org/repo.git --type byos --auth token --token ghp_xxx --json
python tools/audit_engine/cli.py scan --target git@github.com:org/repo.git --type byos --auth ssh --json

# Compare regimes
python tools/audit_engine/cli.py compare --baseline nist_800_171 --target nist_800_53 --json

# AI recommendations
python tools/audit_engine/cli.py advise --regime nist_800_53 --json

# Regime management
python tools/audit_engine/cli.py regimes --json
python tools/audit_engine/cli.py regime-import --file /path/to/regime.json --json
python tools/audit_engine/cli.py regime-export --output /path/to/export --json

# Score trend
python tools/audit_engine/cli.py trend --regime nist_800_53 --json
```

## Dashboard

- Route: `/audit-engine`
- API: `/api/audit-engine/run`, `/api/audit-engine/compare`, `/api/audit-engine/advise`, `/api/audit-engine/regimes`, `/api/audit-engine/trend`

## Database Tables

| Table | Purpose |
|-------|---------|
| `audit_engine_results` | Full audit results (append-only) |
| `audit_engine_scores` | Per-regime scores per audit run |

## Architecture Decisions

- **D-AE-1:** Audit engine is core module (`tools/audit_engine/`) with eject capability
- **D-AE-2:** Regime definitions are JSON files in `args/audit_regimes/` (pluggable)
- **D-AE-3:** Scoring formula: `(passed + 0.5 * partial) / (total - not_applicable) * 100`
- **D-AE-4:** AI advisor uses scanner tier (deterministic) + optional worker tier (LLM)
- **D-AE-5:** BYOS supports both SSH and HTTPS token auth for private repos
- **D-AE-6:** Cloned repos go to `.tmp/audit_clones/` and are cleaned up after scan
- **D-AE-7:** All 8 existing compliance frameworks shipped as built-in regime definitions
- **D-AE-8:** Regime updater uses SHA-256 content hash for tamper detection (D-INV-5 pattern)
- **D-AE-9:** Results are append-only in DB (NIST AU compliance, D6)

## Error Handling

- Scanner failures: isolated per-scanner, don't block other scanners
- Git clone failures: return error with sanitized message (no token leakage)
- Regime not found: skip with error in report card
- LLM unavailable: fall back to deterministic recommendations
- DB unavailable: scan still runs, results not persisted

## Guardrails

- Never modify target files during scan (read-only)
- Never expose auth tokens in output or logs
- Audit trail is append-only (no UPDATE/DELETE)
- CUI markings on all generated artifacts
