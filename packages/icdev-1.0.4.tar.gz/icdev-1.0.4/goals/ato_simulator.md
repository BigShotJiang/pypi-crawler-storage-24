# CUI // SP-CTI

# F11: Monte Carlo ATO Simulator

## Purpose

Simulate ATO (Authority to Operate) timelines using Monte Carlo methods. Build task dependency graphs with probabilistic duration estimates, run thousands of iterations to produce confidence intervals, and identify schedule risk drivers.

## Prerequisites

- `data/icdev.db` initialized with project and compliance tables
- ATO task definitions (or use built-in FedRAMP Moderate template)
- Python stdlib `random` module (no external dependencies)

## Workflow Steps

### 1. Build Task Graph
```bash
python tools/simulation/ato_simulator.py --build-tasks --project-id "sparkpilot" --template fedramp-moderate --json
```
**Expected output:** JSON with task list including task ID, name, dependencies, optimistic/likely/pessimistic duration estimates (days), and critical path flag.

### 2. Simulate Timeline
```bash
python tools/simulation/ato_simulator.py --simulate --project-id "sparkpilot" --iterations 1000 --json
```
**Expected output:** JSON with simulation results: P10/P25/P50/P75/P90 completion dates, mean duration, standard deviation, and iteration count.

### 3. Review Percentiles
```bash
python tools/simulation/ato_simulator.py --percentiles --project-id "sparkpilot" --json
```
**Expected output:** JSON with percentile table (P5 through P95 in 5-point increments), each with calendar date and total business days.

### 4. Identify Risk Drivers
```bash
python tools/simulation/ato_simulator.py --risk-drivers --project-id "sparkpilot" --json
```
**Expected output:** JSON array of tasks ranked by schedule sensitivity (correlation of task duration to total timeline), with risk category (HIGH/MEDIUM/LOW).

### 5. Compare Scenarios
```bash
python tools/simulation/ato_simulator.py --compare --project-id "sparkpilot" --scenario-a "baseline" --scenario-b "parallel-stig" --json
```
**Expected output:** JSON comparing P50 and P90 dates between scenarios, delta in business days, and recommendation.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-INV-41 | PERT distribution for task durations: (optimistic + 4*likely + pessimistic) / 6 |
| D-INV-42 | Critical path computed via topological sort with longest path algorithm |
| D-INV-43 | Sensitivity analysis uses Spearman rank correlation per task vs total duration |
| D-INV-44 | Python stdlib random only -- no numpy required, air-gap safe |

## Edge Cases

- Circular dependency in task graph returns error with cycle path
- Single task returns deterministic result (no simulation needed)
- Zero iterations defaults to 1000
- Task with optimistic > pessimistic returns validation error

## Tier Gating

| Capability | Community | Pro |
|------------|-----------|-----|
| Build task graph | Yes | Yes |
| Simulate timeline | 1000 max iterations | 10000+ iterations |
| Percentile review | P25/P50/P75 only | Full P5-P95 |
| Risk driver analysis | Yes | Yes |
| Custom task parameters | No | Yes |

## Security

- Simulation results are append-only (NIST AU compliant)
- Task graphs scoped to project -- no cross-project access
- CUI markings applied to exported simulation reports
- Random seed logged for reproducibility
