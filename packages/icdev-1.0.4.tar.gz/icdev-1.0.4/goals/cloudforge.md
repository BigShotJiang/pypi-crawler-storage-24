# CUI // SP-CTI
# Goal: CloudForge — Cloud-Agnostic Landing Zone Platform

## Purpose
Provision compliant cloud environments across 8 CSPs in 18 days (vs 12–18 months industry average). Includes landing zone engine, IaC generators, compliance accelerator, migration engine, hybrid cloud manager, CD hub, container forge, FinOps, SIEM, air-gap bridge, and supply chain intel.

## When to Use
- Standing up a new cloud environment (any CSP, any IL)
- Migrating workloads between clouds
- Managing hybrid/multi-cloud topologies
- Tracking cross-cloud costs and security events
- Accelerating ATO with automated evidence generation
- Hardening containers to Iron Bank/Big Bang standards
- Simulating classified environments (SHIFT emulator)

## Modules (12)

| # | Module | Directory | Key Functions |
|---|--------|-----------|---------------|
| 1 | Foundation | `tools/cloudforge/` | `provider.py`, `registry.py` — CloudProvider ABC, 8 CSP providers |
| 2 | IaC Generators | `tools/cloudforge/iac/` | Terraform, Pulumi, OpenTofu rendering per CSP |
| 3 | Landing Zone Engine | `tools/cloudforge/landing_zone/` | Blueprint loading, validation, provisioning, state management |
| 4 | Compliance Accelerator | `tools/cloudforge/compliance/` | 18-day ATO, 5-phase gates, SSP/POAM/STIG bridges |
| 5 | MBSE Thread | `tools/cloudforge/mbse_thread/` | SysML → boundary → controls → IaC → ATO |
| 6 | CD Hub | `tools/cloudforge/cd_hub/` | Hub-spoke GitOps, canary deployment, rollback |
| 7 | Container Forge | `tools/cloudforge/container_forge/` | Iron Bank hardening, Big Bang, runtime policies |
| 8 | Migration Engine | `tools/cloudforge/migration/` | 7-dimension assessment, DataBridge bridge, cutover |
| 9 | Hybrid Cloud | `tools/cloudforge/hybrid/` | Topology CRUD, connections, DNS/identity federation |
| 10 | FinOps | `tools/cloudforge/finops/` | Cost collection, budgets, anomaly detection, chargeback |
| 11 | SIEM | `tools/cloudforge/siem/` | Log aggregation, correlation, alert rules |
| 12 | Air-Gap | `tools/cloudforge/airgap/` | SHIFT emulator, sneakernet, IL classifier |

## Workflow: Provision a Landing Zone

```
1. Load blueprint         → blueprint_loader.load_blueprint(name)
2. Validate blueprint     → blueprint_validator.validate_blueprint(bp, cloud_type, impact_level)
3. Create zone record     → zone_provisioner.provision_zone(name, cloud_type, region, ...)
4. Render IaC             → terraform_renderer.render_terraform(...) or pulumi_renderer.render_pulumi(...)
5. Estimate cost          → provider.estimate_cost(region, modules)
6. Start ATO pipeline     → ato_accelerator.initialize_ato(zone_id)
7. Run 5-phase gates      → ato_accelerator.advance_ato(zone_id)
8. Generate evidence      → evidence_generator.generate_evidence(zone_id, phase)
```

## Workflow: Migrate Workloads

```
1. Create assessment      → assessor.create_assessment(name, source, target)
2. Inventory workloads    → workload_inventory.add_workload(assessment_id, ...)
3. Score risk             → risk_scorer.score_workload(workload_id)
4. Generate plan          → planner.generate_plan(assessment_id, strategy)
5. Map DataBridge connectors → databridge_bridge.get_connector_for_workload(...)
6. Execute cutover        → cutover_orchestrator.execute_phase(assessment_id, phase)
7. Validate post-migration → validation_runner.run_validation(assessment_id)
```

## Workflow: Hybrid Cloud Setup

```
1. Create topology        → topology_manager.create_topology(name, type)
2. Add connections        → connection_manager.create_connection(topology_id, source, target, type)
3. Generate VPN config    → network_bridge.generate_vpn_config(source, target)
4. Federate DNS           → dns_federator.create_federation(topology_id, zones)
5. Federate identity      → identity_federator.create_federation(topology_id, providers)
6. Monitor health         → health_monitor.check_topology_health(topology_id)
```

## Config
- `args/cloudforge_config.yaml` — Tiers, providers, thresholds
- `args/cloudforge_blueprints/*.yaml` — 8 landing zone blueprints

## Database Tables (14 `cf_` prefixed)
cf_landing_zones, cf_provision_log, cf_ato_phases, cf_migration_assessments, cf_migration_workloads, cf_hybrid_topology, cf_hybrid_connections, cf_cost_records, cf_budgets, cf_siem_events, cf_shift_sessions, cf_deployments, cf_container_scans

## Dashboard Pages
- `/cloudforge` — Main dashboard (zones, providers, blueprints)
- `/cloudforge/migration` — Migration planner
- `/cloudforge/hybrid` — Hybrid topology manager
- `/cloudforge/finops` — FinOps cost governance
- `/cloudforge/siem` — Cross-cloud SIEM

## Tiers
| Feature | Community | Pro |
|---------|-----------|-----|
| Landing Zones | 3 | Unlimited |
| CSPs | 1 | All 8 |
| Migration | No | Yes |
| Hybrid | No | Yes |
| FinOps | No | Yes |
| SIEM | No | Yes |
| SHIFT | No | Yes |
| ATO Target | 30 days | 18 days |

## DataBridge Integration
Migration delegates all data movement to DataBridge sync engine. FinOps uses SaaS billing connectors. SIEM uses observability connectors (Splunk, Datadog, Elasticsearch).

## Edge Cases
- Air-gapped environments: Use sneakernet bundle export/import, offline validator
- Cross-classification: IL4→IL5 upgrade requires re-assessment via il_classifier
- Drift detection: drift_detector polls state files and logs divergence to cf_provision_log
- Budget exceeded: budget_tracker returns alert with status='exceeded'
- Migration rollback: cutover_orchestrator.rollback_phase() reverses last phase

## Classification
All artifacts include `CUI // SP-CTI` markings. IaC output includes CUI header comments.
