# Goal: Brainstorming Gate

## Description

Before implementing any feature, phase, or significant change, conduct a structured design exploration. Present 2-3 approaches with tradeoffs, get user approval, then save the design doc before writing code.

**Adapted from:** [obra/superpowers](https://github.com/obra/superpowers) brainstorming skill.

**The iron rule:** NO IMPLEMENTATION WITHOUT A VALIDATED DESIGN. Do NOT write code, scaffold projects, or take any implementation action until the design is presented and the user has approved it.

---

## When to Use

**Always before:**
- New features or phases
- Significant refactoring (>3 files)
- New tools or modules
- Architecture changes
- New dashboard pages
- New database tables
- Integration with external systems

**Exceptions (ask user first):**
- Hotfixes for production bugs (use `goals/systematic_debugging.md` instead)
- Trivial config changes
- Documentation-only updates
- User explicitly says "just do it"

**Anti-Pattern: "This Is Too Simple To Need A Design"**

Every project goes through this process. A single-function utility, a config change, a new API endpoint — all of them. "Simple" projects are where unexamined assumptions cause the most wasted work. The design can be short (a few sentences for truly simple features), but you MUST present it and get approval.

---

## Prerequisites

- [ ] User has described what they want (even roughly)
- [ ] `memory/MEMORY.md` loaded (session context)
- [ ] Relevant goal files checked (`goals/manifest.md`)
- [ ] Tool manifest checked (`tools/manifest.md`)

---

## Process

### Step 1: Explore Project Context

Before asking questions:
1. Check relevant files, docs, recent commits
2. Read related goal files
3. Check `tools/manifest.md` for existing tools that overlap
4. Understand what already exists

### Step 2: Ask Clarifying Questions

- **One question at a time** — don't overwhelm
- **Multiple choice preferred** — easier to answer than open-ended
- Focus on: purpose, constraints, success criteria, edge cases
- Understand the "why" not just the "what"

**Key questions to cover:**
- What problem does this solve?
- Who uses it? (end user, admin, developer, agent)
- What are the constraints? (air-gap, compliance, performance)
- How does this interact with existing features?
- What does success look like?

### Step 3: Propose 2-3 Approaches

Present options with clear tradeoffs:

```markdown
## Approach A: [Name]
- **How:** [2-3 sentences]
- **Pro:** [key advantage]
- **Con:** [key disadvantage]
- **Effort:** [Low/Medium/High]

## Approach B: [Name]
- **How:** [2-3 sentences]
- **Pro:** [key advantage]
- **Con:** [key disadvantage]
- **Effort:** [Low/Medium/High]

**Recommendation:** Approach [X] because [reason].
```

Lead with your recommended option and explain why.

### Step 4: Present Design

Once user selects an approach, present the full design:

- **Architecture** — components, data flow, dependencies
- **Database** — new tables/columns (if any)
- **API** — new endpoints (if any)
- **UI** — new pages/tabs (if any)
- **Compliance** — framework impact (if any)
- **Testing** — what needs testing
- **Architecture decisions** — D-* identifiers for key choices

Scale each section to its complexity: a few sentences if straightforward, detailed if nuanced.

**Ask after each major section:** "Does this look right so far?"

### Step 5: Save Design Doc

After user approves:

```bash
# Save to docs/plans/
docs/plans/YYYY-MM-DD-<feature-name>-design.md
```

**Design doc format:**
```markdown
# [Feature Name] Design

> **Goal:** [One sentence]
> **Approach:** [Selected approach name]
> **Status:** Approved
> **Date:** YYYY-MM-DD

## Architecture
[2-3 sentences]

## Components
[List of new/modified files]

## Database Changes
[New tables, columns]

## API Changes
[New endpoints]

## Architecture Decisions
[D-* identifiers with rationale]

## Implementation Notes
[Key technical details for the implementer]
```

### Step 6: Transition to Implementation

After design doc is saved:
- Create bite-sized implementation plan (`goals/bite_sized_plans.md`)
- Or proceed directly if user prefers

---

## GOTCHA Alignment

This goal maps to the GOTCHA framework:

| Layer | Role in Brainstorming |
|-------|----------------------|
| **Goals** | This goal defines the brainstorming process |
| **Orchestration** | You (Claude) facilitate the design dialogue |
| **Tools** | Not invoked until after design approval |
| **Args** | Architecture decisions become args configs |
| **Context** | Existing code/docs inform the design |
| **Hard Prompts** | Design doc becomes a hard prompt for implementation |

---

## Red Flags — STOP

- Starting to write code before design approval
- Skipping the approaches step ("there's only one way")
- Not asking the user any questions
- Presenting a design without checking existing code first
- Design doc not saved before implementation begins

---

## Quick Reference

| Step | Action | Output |
|------|--------|--------|
| 1. Context | Read existing code/docs | Understanding of landscape |
| 2. Questions | One at a time, multiple choice | Refined requirements |
| 3. Approaches | 2-3 options with tradeoffs | User-selected approach |
| 4. Design | Section-by-section presentation | User-approved design |
| 5. Save | `docs/plans/YYYY-MM-DD-*-design.md` | Committed design doc |
| 6. Handoff | Transition to implementation | Bite-sized plan or direct build |
