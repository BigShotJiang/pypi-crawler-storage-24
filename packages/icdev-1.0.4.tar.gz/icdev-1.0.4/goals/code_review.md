# CUI // SP-CTI
# Goal: CodeLens — Universal Code Review & Quality Gate

## Purpose
Run LLM-agnostic, deterministic-first code reviews with 7 parallel analysis lenses.
Works standalone (BYOS) or integrated with ICDEV ecosystem.

## When to Use
- After implementing code changes (pre-commit, pre-merge)
- During CI/CD pipeline quality gates
- For compliance audits (CUI, NIST, STIG)
- For team quality coaching and process improvement

## Prerequisites
- Project directory with code to review
- Git (optional — falls back to full-project scan)
- Flask (optional — for web dashboard)
- LLM (optional — offline mode is fully functional)

## Workflow

### Step 1: Configure Review
```bash
# Quick review with defaults
python tools/review/cli.py --project-dir .

# Specific profile for weak QA/QC teams
python tools/review/cli.py --project-dir . --profile beginner --educational

# Security-focused pre-release review
python tools/review/cli.py --project-dir . --profile pre_release --diff origin/main

# Offline mode (no LLM, deterministic only)
python tools/review/cli.py --project-dir . --offline --json

# Specific lenses only
python tools/review/cli.py --project-dir . --lenses security,compliance
```

### Step 2: Review Findings
- **Blockers** must be fixed before merge
- **Tech Debt** should be addressed in current or next sprint
- **Advisory** (skippable) are process improvement suggestions

### Step 3: Check Quality Gate
- Exit code 0 = passed (no blockers)
- Exit code 1 = failed (blockers present)
- Adversarial minimum ensures meaningful review even on clean code

### Step 4: Track History
```bash
python tools/review/cli.py --history --project-dir .
python tools/review/cli.py --patterns
```

### Step 5: Web Dashboard (optional)
```bash
python tools/review/cli.py --dashboard --port 8080
```

## 7 Lenses

| Lens | What It Checks | Maturity Level |
|------|---------------|----------------|
| L1: Correctness | AST bugs, complexity, dead code | Starter+ |
| L2: Security | SAST, secrets, injection, CVEs | Starter+ |
| L3: Compliance | CUI markings, NIST, audit integrity | Standard+ |
| L4: Architecture | Layer violations, circular deps, god classes | Advanced+ |
| L5: Coverage | Test gaps, untested functions, assertion quality | Standard+ |
| L6: Historical | Git hotspots, bug-fix correlation, anti-patterns | Advanced+ |
| L7: Visual | Screenshot diff, OCR comparison | Expert |

## Maturity Levels (for teams building QA/QC culture)

| Level | Active Lenses | Use When |
|-------|--------------|----------|
| Starter | L1 + L2 | New to code review, just starting |
| Standard | L1-L3 + L5 | Have basic review process |
| Advanced | L1-L6 | Mature review culture |
| Expert | All 7 | Full quality gate with visual regression |

## Review Profiles

| Profile | Description |
|---------|-------------|
| beginner | Gentle, educational, starter maturity |
| security_first | Security + compliance heavy |
| pre_release | All lenses, strict thresholds |
| compliance_audit | Compliance + architecture focus |
| quick_check | Correctness only, fast |

## Configuration
- YAML: `args/review_config.yaml`
- Env vars: `CODELENS_OFFLINE`, `CODELENS_THRESHOLD`, `CODELENS_MATURITY`, `CODELENS_PROFILE`
- Runtime: `--config ./custom-rules.yaml`

## ICDEV Integration
When running within ICDEV:
- Compliance findings delegate to ICDEV compliance engine (no duplication)
- Reviews logged to ICDEV audit trail (append-only, NIST AU compliant)
- LLM routes through ICDEV router (any backend)
- Quality metrics feed into Developer Scorecard

## BYOS (Bring Your Own Software)
When running standalone:
- Zero ICDEV dependencies required
- Local SQLite for history and patterns
- Direct LLM provider support (Anthropic, OpenAI, Ollama)
- Pip installable: `pip install icdev-review`

## Key Design Decisions
- D-CL-1: Deterministic-first, LLM-optional
- D-CL-2: 7 parallel lenses with ThreadPoolExecutor
- D-CL-3: Standalone `tools/review/` for marketplace portability
- D-CL-4: LLM via router when available, skip when not
- D-CL-5: YAML rulesets in `args/` (GOTCHA args layer)
- D-CL-6: Three visual backends with graceful fallback
- D-CL-7: Confidence scoring is 100% deterministic
- D-CL-8: Compliance delegates to ICDEV engine, not duplicates
- D-CL-9: Same JSON schema online/offline
- D-CL-10: pip-installable with zero ICDEV deps in core

## Edge Cases
- No git available → full project scan (capped at 200 files)
- No LLM available → offline mode (same schema, `llm_enriched: false`)
- No Playwright available → visual lens skipped gracefully
- No review history → coaching says "Run reviews to get suggestions"
- Clean code (no findings) → adversarial minimum generates meta-observations
