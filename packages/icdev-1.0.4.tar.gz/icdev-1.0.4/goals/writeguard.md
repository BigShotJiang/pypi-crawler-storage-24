# WriteGuard — AI Writing Assistant Workflow

## Purpose

Analyze and improve writing quality for government proposals and technical documents. Runs fully air-gapped with deterministic-first analysis pipeline.

## When to Use

- Analyzing draft proposal sections for readability, grammar, and tone
- Checking RFP shall-statement coverage in proposal drafts
- Validating win theme threading across volumes
- Detecting cross-volume numerical inconsistencies
- Managing reusable writing snippets and templates
- Enforcing tenant-specific style guides with ISSO locks
- Running batch analysis across multiple documents

## Tools

| Tool | Purpose |
|------|---------|
| `tools/writing/analysis_engine.py` | Core orchestrator — `analyze(text, mode, style_guide_id)` |
| `tools/writing/grammar_checker.py` | Regex-based grammar error detection |
| `tools/writing/readability_scorer.py` | Flesch-Kincaid, Gunning Fog, SMOG scoring |
| `tools/writing/tone_profiler.py` | Keyword + qwen3 scanner tone classification |
| `tools/writing/style_enforcer.py` | Style guide rule evaluation |
| `tools/writing/coherence_analyzer.py` | Paragraph flow and topic drift analysis |
| `tools/writing/plagiarism_detector.py` | RAG similarity search |
| `tools/writing/ai_content_detector.py` | Statistical AI content detection |
| `tools/writing/rewriter.py` | LLM-assisted text improvement |
| `tools/writing/snippet_manager.py` | CRUD for reusable writing templates |
| `tools/writing/style_guide_manager.py` | 5-layer cascade with ISSO locks |
| `tools/writing/batch_analyzer.py` | Multi-document batch analysis |
| `tools/writing/govcon_bridge.py` | GovProposal integration (read-only) |
| `tools/writing/signal_registrar.py` | Innovation Engine bridge |

## Workflow

### Inline Analysis
1. User pastes text into WriteGuard
2. `analysis_engine.analyze()` orchestrates all checks:
   - Grammar (deterministic regex)
   - Readability (deterministic formulas)
   - AI detection (deterministic statistics)
   - Tone profiling (scanner tier)
   - Style enforcement (cascade resolution)
   - CUI marking check
3. Results stored in `wg_analysis_results` + `wg_analysis_findings`
4. Findings displayed with severity, category, suggestions

### Batch Analysis
1. Submit multiple documents via `batch_analyzer.run_batch()`
2. Each document analyzed individually
3. Cross-document consistency checks run
4. Results aggregated in `wg_batch_runs`

### GovProposal Integration
1. `check_shall_compliance(text, opportunity_id)` — reads `rfp_shall_statements`, checks keyword coverage
2. `validate_win_themes(text, opportunity_id)` — reads `proposal_knowledge_base` differentiators
3. `check_cross_volume_consistency(opportunity_id)` — reads all drafts, detects numerical contradictions

### Style Guide Management
1. Create guides at platform/tenant/program/project/user scope
2. ISSO can lock dimensions (e.g., readability rules)
3. Cascade resolves bottom-up, locked dimensions skip-propagate
4. Version history with diff and rollback

## Args

- `args/writeguard_config.yaml` — analysis defaults, thresholds, LLM settings

## Context

- `context/writing/style_guides/*.yaml` — 5 default guides
- `context/writing/grammar_rules/*.json` — grammar patterns and govcon vocabulary

## Edge Cases

- Empty text returns early with status message
- Missing style guide uses platform defaults
- Nonexistent opportunity_id returns note (not error)
- Single-paragraph text skips connectivity/topic-drift analysis
- Air-gapped mode: all deterministic checks work; LLM-assisted checks (tone, coherence, rewrite) degrade to deterministic-only

## Security

- All analysis results are append-only (NIST AU compliant)
- GovProposal bridge is read-only — never writes to proposal tables
- CUI marking enforcement is configurable
- Style guide locks prevent unauthorized changes to compliance dimensions
