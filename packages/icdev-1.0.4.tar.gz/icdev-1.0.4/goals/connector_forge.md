# CUI // SP-CTI
# Goal: Connector Forge — Dynamic DataBridge Connector Generation

## Purpose

Generate, validate, sandbox, and publish new DataBridge connectors on demand from API specs, WSDL definitions, or structured YAML input. Extends DataBridge's 47 hand-coded connectors with an infinite long tail via AI-assisted code generation.

## When to Use

- User needs a DataBridge connector for a product/service that doesn't have one yet
- User has an OpenAPI spec, WSDL definition, or API documentation URL
- User wants to import a community-shared connector from the marketplace
- User wants to promote a sandboxed connector to production

## 6-Stage Pipeline

```
INPUT PARSING → BASE CLASS SELECTION → CODE GENERATION → STATIC VALIDATION → SANDBOX → INTEGRATION TEST
  (spec_parser)    (base_selector)      (code_generator)  (static_validator)  (sandbox_mgr)  (int_tester)
```

### Stage 1: Spec Parser
Parse OpenAPI JSON/YAML, WSDL XML, HTML docs, or structured YAML into `ForgeApiManifest`.

### Stage 2: Base Selector
Deterministic protocol→base class mapping. Maps to one of 8 base classes: SaaSBase, SoapBase, SQLBase, FsspecBase, MessagingBase, HealthBase, EmailBase, DataConnector.

### Stage 3: Code Generator
Render skeleton from Jinja2 template, optionally enhance with two-tier LLM (qwen3 draft → Claude review).

### Stage 4: Static Validator
6-gate validation: py_compile, ruff, AST ABC check, bandit SAST, secret scan, import whitelist.

### Stage 5: Sandbox
Docker container (--network none, --memory 256m) with subprocess fallback. Probes import/instantiate/connect/health/list_tables.

### Stage 6: Integration Test
Evaluate sandbox results. Pass requires successful import + instantiation.

## Workflow

### Generate a connector from spec
```bash
# Via MCP
echo '{"jsonrpc":"2.0","id":1,"method":"forge_from_spec","params":{"content":"<openapi-json>","connector_name":"my_api"}}' | python tools/mcp/connector_forge_server.py

# Via Python
from tools.databridge.forge.forge_agent import forge_from_spec
result = forge_from_spec(content="...", connector_name="my_api", use_llm=False, run_sandbox_flag=False)
```

### Promote to production
```bash
from tools.databridge.forge.promoter import promote_connector
result = promote_connector(connector_id="forge-abc123", promoted_by="admin")
```

### Publish to marketplace
```bash
from tools.databridge.forge.marketplace_publisher import publish_connector
result = publish_connector(connector_id="forge-abc123", marketplace_url="https://marketplace.icdev.ai")
```

### Import from marketplace
```bash
from tools.databridge.forge.import_handler import import_community_connector
result = import_community_connector(slug="databridge-connector-acme-crm")
```

## Promotion State Machine

```
sandboxed → promoted → published → deprecated
```

- **sandboxed**: Just generated, passed validation. Cannot be used in production sync jobs.
- **promoted**: Human-approved. Loaded into in-memory connector registry via `load_forge_connectors()`.
- **published**: Shared on marketplace.icdev.ai for community use.
- **deprecated**: Retired. No longer loaded into registry.

## Expected Outputs

| Operation | Success Output |
|-----------|---------------|
| forge_from_spec | `{status: "sandboxed", connector_id, validation, sandbox, integration}` |
| forge_promote | `{status: "ok", new_status: "promoted"}` |
| forge_publish | `{status: "ok", slug, artifact_id}` |
| forge_import | `{status: "ok", connector_id, new_status: "sandboxed"}` |
| forge_list | `{connectors: [...], count: N}` |

## Edge Cases

- **No LLM available**: Falls back to template-only generation (still produces valid connector skeleton)
- **No Docker**: Falls back to subprocess sandbox with restricted PYTHONPATH
- **Air-gapped**: All parsing uses stdlib (xml.etree, json, html.parser). Jinja2 has string-replacement fallback
- **Validation failure**: Pipeline stops after Stage 4, returns detailed gate results
- **Sandbox timeout**: 30-second default, configurable in `args/databridge_config.yaml` under `forge.sandbox`
- **Import validation fail**: Community connector rejected, not stored in DB

## Configuration

`args/databridge_config.yaml` under `forge:` block — sandbox settings, validation flags, import whitelist, promotion config.

## Architecture Decisions

- D-CF-1: `forge/` is a subpackage of `tools/databridge/`
- D-CF-2: Two-tier LLM (qwen3 drafts, Claude reviews)
- D-CF-3: Inline Jinja2 templates with string-replacement fallback
- D-CF-4: Docker primary, subprocess fallback for sandbox
- D-CF-5: Two new ConnectorType enum values: SOAP, HEALTH
- D-CF-6: Promotion state machine: sandboxed → promoted → published → deprecated
- D-CF-7: 8 new audit event types
- D-CF-8: Marketplace install via ASSET_TYPE_DIRS["databridge_connector"]
- D-CF-9: MCP server with 8 tools
- D-CF-10: Config in databridge_config.yaml under forge: block

## Tools

| Tool | Path |
|------|------|
| Forge Agent | `tools/databridge/forge/forge_agent.py` |
| Spec Parser | `tools/databridge/forge/spec_parser.py` |
| Base Selector | `tools/databridge/forge/base_selector.py` |
| Code Generator | `tools/databridge/forge/code_generator.py` |
| Static Validator | `tools/databridge/forge/static_validator.py` |
| Sandbox Manager | `tools/databridge/forge/sandbox_manager.py` |
| Integration Tester | `tools/databridge/forge/integration_tester.py` |
| Promoter | `tools/databridge/forge/promoter.py` |
| Publisher | `tools/databridge/forge/marketplace_publisher.py` |
| Import Handler | `tools/databridge/forge/import_handler.py` |
| Templates | `tools/databridge/forge/templates/__init__.py` |
| MCP Server | `tools/mcp/connector_forge_server.py` |
| A2A Card | `tools/agent/cards/connector_forge_card.json` |
