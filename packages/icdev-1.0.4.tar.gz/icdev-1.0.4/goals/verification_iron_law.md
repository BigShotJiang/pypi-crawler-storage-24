# Goal: Verification Iron Law

## Description

No completion claims without fresh verification evidence. Claiming work is complete without running verification is dishonesty, not efficiency.

**Adapted from:** [obra/superpowers](https://github.com/obra/superpowers) verification-before-completion skill.

**The iron rule:** NO COMPLETION CLAIMS WITHOUT FRESH VERIFICATION EVIDENCE. If you haven't run the verification command in this response, you cannot claim it passes.

---

## When to Use

**ALWAYS before:**
- Any claim that work is "complete" or "done"
- Any expression of satisfaction ("Great!", "All working!")
- Committing code
- Creating pull requests
- Moving to the next task
- Reporting status to the user
- Marking a TodoWrite task as completed

**This rule applies to:**
- Exact phrases ("Done!", "Complete!")
- Paraphrases ("All set", "Ready to go")
- Implications ("That should work now")
- ANY communication suggesting completion or correctness

---

## The Gate Function

```
BEFORE claiming any status or expressing satisfaction:

1. IDENTIFY: What command proves this claim?
2. RUN: Execute the FULL command (fresh, complete)
3. READ: Full output, check exit code, count failures
4. VERIFY: Does output confirm the claim?
   - If NO → State actual status with evidence
   - If YES → State claim WITH evidence
5. ONLY THEN: Make the claim

Skip any step = unverified claim
```

---

## Verification Commands by Context

### Code Changes
```bash
# Syntax check
python -m py_compile path/to/file.py

# Unit tests
python -m pytest tests/ -v

# Specific test
python -m pytest tests/test_specific.py::test_name -v

# Linting
python -m ruff check path/to/file.py
```

### Dashboard Changes
```bash
# Start dashboard
python tools/dashboard/app.py --host 0.0.0.0 --port 8080 &

# Check it starts
curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/login

# Playwright E2E (mandatory per CLAUDE.md guardrails)
# Navigate to every new/changed page
# Screenshot 3 viewports (desktop 1920x1080, tablet 768x1024, mobile 375x812)
# Check console for errors (browser_console_messages)
# Check network for 500s (browser_network_requests)
```

### Database Changes
```bash
python tools/db/storage.py --health --json
```

### System Health
```bash
python tools/testing/health_check.py --json
```

### Security
```bash
python tools/security/sast_runner.py --project-dir path/
python tools/security/secret_detector.py --project-dir path/
```

### Compliance
```bash
python tools/compliance/crosswalk_engine.py --project-id "sparkpilot" --coverage
```

---

## Evidence Format

**Good (with evidence):**
```
All 12 tests pass:
$ python -m pytest tests/test_widget.py -v
  test_create_widget PASSED
  test_get_widget PASSED
  ...
  12 passed in 0.34s
```

**Bad (without evidence):**
```
All tests should pass now.
```

---

## Common Failures

| Claim | Requires | NOT Sufficient |
|-------|----------|----------------|
| "Tests pass" | Test output: 0 failures | Previous run, "should pass" |
| "No console errors" | `browser_console_messages` output | "I didn't see any" |
| "Dashboard works" | Playwright navigation + screenshot | "It should render" |
| "Bug fixed" | Failing test → fix → passing test | "Code changed" |
| "Build succeeds" | `py_compile` exit 0 | "Linter passed" |
| "Subagent completed" | VCS diff shows changes | Agent reports "success" |
| "Requirements met" | Line-by-line checklist verified | "Tests passing" |

---

## Red Flags — STOP

If you catch yourself:
- Using "should", "probably", "seems to"
- Expressing satisfaction before verification
- About to commit/push without verification
- Trusting subagent success reports without checking
- Relying on partial verification
- Thinking "just this once"
- Tired and wanting work over
- Using different words to imply success without evidence

**ALL of these mean: RUN THE VERIFICATION COMMAND.**

---

## Rationalization Prevention

| Excuse | Reality |
|--------|---------|
| "Should work now" | RUN the verification |
| "I'm confident" | Confidence ≠ evidence |
| "Just this once" | No exceptions |
| "Linter passed" | Linter ≠ compiler ≠ runtime |
| "Subagent said success" | Verify independently |
| "Partial check is enough" | Partial proves nothing |
| "Different words so rule doesn't apply" | Spirit over letter |

---

## ICDEV-Specific Verification Checklist

Before marking any phase or feature complete:

- [ ] `py_compile` passes on all new/modified .py files
- [ ] `pytest` passes for related tests
- [ ] New dashboard pages verified via Playwright (3 viewports)
- [ ] Console errors: 0
- [ ] Network 500s: 0
- [ ] `tools/manifest.md` updated if new tools created
- [ ] CUI markings present on new files
- [ ] Memory file updated with implementation details
- [ ] Audit trail events logged for state changes

---

## Integration

| Related Goal | Relationship |
|-------------|-------------|
| `tdd_workflow.md` | TDD's "verify RED/GREEN" is a subset of this |
| `systematic_debugging.md` | Phase 4 verify-fix step uses this |
| `subagent_review.md` | Each review stage must produce evidence |
| `integration_testing.md` | Full test suite is the ultimate verification |
| `build_app.md` | Post-Implementation Checklist enforces this |
