# Goal: CodeLens/Pro Container & K8s Deployment Validation

## Description

Validate container images, Dockerfiles, K8s manifests, and Helm charts for
deployment readiness using 7 deterministic lenses.  Catches platform mismatches,
air-gap breakage, compliance violations, and database compatibility issues
before code leaves the developer's machine.

## Prerequisites

- [ ] Project directory with Dockerfile or K8s manifests
- [ ] Profile selected (commercial, fedramp-moderate, dod-il4, dod-il5, air-gapped)

## Quality Gates

| Gate | Threshold | Blocks? |
|------|-----------|---------|
| BLOCK findings | 0 | YES (all profiles) |
| Score below profile minimum | Profile-dependent (60-85) | YES |
| Critical CVE | 0 | YES (fedramp+) |
| High CVE | 0 (fedramp+) or 5 (commercial) | Profile-dependent |
| STIG CAT I | 0 | YES (dod-il4+) |
| FIPS base image | Required | YES (dod-il4+) |

## Process

### Step 1: File Hygiene Scan (Lens A)
Tool: `python tools/container_lens/validator.py --project-id <id> --project-dir . --lenses file_hygiene --json`

Checks: CRLF line endings, case collisions, BOM, secrets in build context,
unpinned base images, missing .dockerignore, Windows paths.

### Step 2: Dockerfile Lint (Lens B)
Tool: `python tools/container_lens/validator.py --project-id <id> --dockerfile Dockerfile --lenses dockerfile_lint --json`

Checks: Non-root USER, package pinning, cache ordering, HEALTHCHECK, FIPS
base images, build dep leakage, telemetry opt-out, shared lib verification.

### Step 3: Full Validation with Gate
Tool: `python tools/container_lens/validator.py --project-id <id> --project-dir . --profile <profile> --gate --json`

Runs all active lenses for the profile, evaluates gate, returns pass/fail
with score and letter grade.

### Step 4: Fix and Re-validate
For each BLOCK finding:
1. Read the remediation guidance
2. Apply the fix
3. Re-run validation for just that lens

## Severity Levels

| Level | Meaning | Action |
|-------|---------|--------|
| BLOCK | Deployment will fail or violate compliance | Must fix before deploy |
| WARN | Potential issue, risk accepted with POA&M | Should fix, can defer |
| INFO | Best practice suggestion | Track, optional fix |

## Profiles

| Profile | Min Score | FIPS | STIG | Air-Gap |
|---------|-----------|------|------|---------|
| commercial | 60 | No | No | No |
| fedramp-moderate | 70 | No | No | Partial |
| dod-il4 | 80 | Yes | Yes | Yes |
| dod-il5 | 85 | Yes | Yes | Yes |
| air-gapped | 75 | No | No | Full |

## Error Handling

- If a lens fails to run, it returns score=0 with error in metadata
- Gate evaluation still proceeds with available lens results
- All results logged to audit_trail (append-only)
- If Dockerfile not found, file_hygiene still runs, dockerfile_lint skips

## NIST Control Mapping

| Lens | Primary Controls |
|------|-----------------|
| File Hygiene (A) | CM-6, CM-7 |
| Dockerfile (B) | CM-6, CM-7, AC-6, SC-13, SI-7 |
| K8s Manifest (C) | AC-3, AC-6, SC-7 |
| Helm Chart (D) | CM-2, CM-6 |
| Security (E) | RA-5, SI-2, SC-13, AU-3 |
| Air-Gap (F) | SC-7, CM-7, SC-8 |
| Database (G) | CM-6, SC-28, SI-7 |

## Configuration

- Profiles: `args/container_lens_profiles.yaml`
- Gate thresholds: embedded in profiles
- Severity overrides: per-profile in YAML

## Post-Implementation

- Run Playwright E2E tests on dashboard (when dashboard route added)
- Update tools/manifest.md
- Update goals/manifest.md
