# CUI // SP-CTI

# F10: Connector Forge Community Hub

## Purpose

Community-driven marketplace for sharing, discovering, and rating DataBridge connectors created via Connector Forge. Enables trust scoring based on test coverage, security scans, and community feedback to surface reliable connectors.

## Prerequisites

- `data/icdev.db` initialized with connector forge tables
- Connector Forge operational (`tools/databridge/forge/`)
- At least one published connector (state = `published`)

## Workflow Steps

### 1. Browse Connectors
```bash
python tools/databridge/forge/community_hub.py --browse --category all --sort-by trust_score --json
```
**Expected output:** JSON array of published connectors with name, author, connector type, trust score (0-100), download count, average rating, and last updated timestamp.

### 2. Search Connectors
```bash
python tools/databridge/forge/community_hub.py --search --query "salesforce REST" --json
```
**Expected output:** JSON array of matching connectors ranked by relevance, with highlights showing matched terms.

### 3. Rate Connector
```bash
python tools/databridge/forge/community_hub.py --rate --connector-id "forge-001" --rating 4 --review "Reliable, good error handling" --json
```
**Expected output:** JSON with updated average rating, review count, and trust score impact.

### 4. Compute Trust Score
```bash
python tools/databridge/forge/community_hub.py --trust-score --connector-id "forge-001" --json
```
**Expected output:** JSON with trust score breakdown: test_coverage (0-30), security_scan (0-30), community_rating (0-20), download_count (0-10), author_reputation (0-10).

### 5. Get Connector Details
```bash
python tools/databridge/forge/community_hub.py --details --connector-id "forge-001" --json
```
**Expected output:** JSON with full connector metadata, supported operations, configuration schema, reviews, and installation instructions.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-INV-37 | Trust score is deterministic weighted sum of 5 dimensions (max 100) |
| D-INV-38 | Search uses BM25 on connector name, description, and tags |
| D-INV-39 | Ratings are 1-5 integers; trust score recalculated on each new rating |
| D-INV-40 | Published connectors are immutable -- updates create new versions |

## Edge Cases

- Connector with zero ratings gets trust score from test coverage and security scan only
- Search with no results returns top-rated connectors as suggestions
- Deprecated connectors appear in search results with deprecation warning
- Rating by connector author is accepted but flagged in trust score calculation

## Tier Gating

| Capability | Community | Pro |
|------------|-----------|-----|
| Browse and search | Yes | Yes |
| Rate connectors | Yes | Yes |
| Trust score viewing | Yes | Yes |
| Private hub (tenant-scoped) | No | Yes |
| Verified publisher badges | No | Yes |

## Security

- All ratings and reviews are append-only (NIST AU compliant)
- Connector binaries scanned for secrets and malware signatures before publication
- CUI markings applied to connector metadata exports
- Author identity verified against project membership
