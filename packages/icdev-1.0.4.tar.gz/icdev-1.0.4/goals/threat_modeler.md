# CUI // SP-CTI

# F7: STRIDE Threat Modeler

## Purpose

Systematic threat modeling using the STRIDE methodology (Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege). Maps identified threats to NIST 800-53 controls and auto-generates POAM entries for unmitigated risks.

## Prerequisites

- `data/icdev.db` initialized with project and compliance tables
- System architecture documented (components, data flows, trust boundaries)
- Control mappings populated via `tools/compliance/control_mapper.py`

## Workflow Steps

### 1. Create Threat Model
```bash
python tools/security/threat_modeler.py --create --project-id "sparkpilot" --name "API Gateway Model" --json
```
**Expected output:** JSON with model ID, name, creation timestamp, and status (draft).

### 2. Analyze Components
```bash
python tools/security/threat_modeler.py --analyze --model-id "tm-001" --components /path/to/components.json --json
```
**Expected output:** JSON with STRIDE analysis per component: threat ID, category (S/T/R/I/D/E), description, likelihood (1-5), impact (1-5), risk score, and mitigation status.

### 3. Map Threats to NIST Controls
```bash
python tools/security/threat_modeler.py --map-controls --model-id "tm-001" --json
```
**Expected output:** JSON mapping each threat to recommended NIST 800-53 controls, with implementation status from existing compliance data.

### 4. Auto-Generate POAM Entries
```bash
python tools/security/threat_modeler.py --auto-poam --model-id "tm-001" --json
```
**Expected output:** JSON with generated POAM entries for unmitigated threats, including milestone dates and responsible parties.

### 5. Get Model Summary
```bash
python tools/security/threat_modeler.py --summary --model-id "tm-001" --json
```
**Expected output:** JSON with threat counts by STRIDE category, risk distribution, mitigation coverage, and residual risk score.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-INV-25 | STRIDE analysis uses deterministic rule engine per component type -- air-gap safe |
| D-INV-26 | Risk score = likelihood x impact (1-25 scale), thresholds: LOW < 6, MEDIUM < 12, HIGH < 20, CRITICAL >= 20 |
| D-INV-27 | NIST mapping uses crosswalk engine for multi-framework propagation |
| D-INV-28 | POAM entries auto-generated with 90-day default milestones for HIGH/CRITICAL |

## Edge Cases

- Component with no applicable STRIDE threats returns clean report
- Missing control mapping triggers crosswalk engine lookup before failing
- Duplicate threat model name within project appends version suffix
- Empty component list returns model shell with instructions

## Tier Gating

| Capability | Community | Pro |
|------------|-----------|-----|
| STRIDE analysis | Yes | Yes |
| NIST control mapping | Yes | Yes |
| POAM auto-generation | Yes | Yes |
| ATT&CK mapping | No | Yes |
| Auto-remediation suggestions | No | Yes |

## Security

- Threat models and POAM entries are append-only (NIST AU compliant)
- Model data scoped to project -- no cross-project access
- CUI markings applied to all exported threat model artifacts
