# CUI // SP-CTI

# DocHub — Living Documentation Engine

## Purpose

Auto-generate role-specific, multi-format documentation for ICDEV, its modules,
child apps, and third-party (BYOS) applications.  Documents regenerate from live
DB/code state with a single click.  Supports 8 audience profiles, 8 export
formats (including Xacta, FedRAMP ZIP, DoD IL2/4/5 packages), module-level
tracking with provenance, cross-app dependency impact analysis, portfolio health
scoring, and research enrichment from CVE/regulatory feeds.

## Prerequisites

- `data/icdev.db` initialized with projects table
- Compliance tables populated (project_controls, poam_items, sbom_entries)
- Source tools available (scorecard, ssp_generator, threat_modeler, etc.)

## Workflow Steps

### 1. Register Application
```bash
python tools/dochub/tenant_manager.py --register --project-id "sparkpilot" --name "SparkPilot" --app-type icdev --json
```
**Expected output:** JSON with tenant app record (id, project_id, display_name).

### 2. Register Modules
```bash
python tools/dochub/tenant_manager.py --register-module --project-id "sparkpilot" --module-name "WriteGuard" --module-slug writeguard --json
```
**Expected output:** JSON with module record (id, module_name, module_slug).

### 3. Collect Data
```bash
python tools/dochub/data_collector.py --project-id "sparkpilot" --collect --json
```
**Expected output:** JSON snapshot with project_info, controls, poam_items, threats, sbom, code_metrics, scorecard, dora_metrics, sbd_score, ai_security.

### 4. Generate Documents
```bash
python tools/dochub/doc_generator.py --project-id "sparkpilot" --doc-type ssp --profile 3pao --impact-level IL4 --json
python tools/dochub/doc_generator.py --project-id "sparkpilot" --generate-all --profile compliance --json
```
**Expected output:** JSON with doc_id, title, version, content_hash, status.

### 5. Compute Health Score
```bash
python tools/dochub/health_scorer.py --project-id "sparkpilot" --compute --json
```
**Expected output:** JSON with overall_score, freshness_score, completeness_score, gap_score, grade.

### 6. Export Documents
```bash
python tools/dochub/export_engine.py --doc-id "dh-doc-xxx" --format html --json
python tools/dochub/export_engine.py --project-id "sparkpilot" --format fedramp_zip --output ./exports --json
python tools/dochub/export_engine.py --project-id "sparkpilot" --format dod_pkg --impact-level IL4 --output ./exports --json
```
**Expected output:** JSON with export path, format, file size.

### 7. View Changelog
```bash
python tools/dochub/diff_engine.py --doc-id "dh-doc-xxx" --latest --json
python tools/dochub/diff_engine.py --project-id "sparkpilot" --summary --json
```
**Expected output:** JSON with sections_added, sections_removed, sections_changed, summary.

### 8. BYOS Scan
```bash
python tools/dochub/byos_scanner.py --project-dir /path/to/external/app --scan --json
python tools/dochub/byos_scanner.py --project-dir /path --scan --store --generate --json
python tools/dochub/byos_scanner.py --import-artifact --file /path/to/vendor-sbom.json --artifact-type sbom --project-id byos-001 --json
```
**Expected output:** JSON with languages, frameworks, dependencies, security_findings, code_metrics.

### 9. Research Enrichment
```bash
python tools/dochub/enrichment_engine.py --project-id "sparkpilot" --enrich --json
python tools/dochub/enrichment_engine.py --project-id "sparkpilot" --check-cves --json
```
**Expected output:** JSON with cve_findings, regulatory_updates, enrichment_summary.

### 10. Impact Analysis
```bash
python tools/dochub/tenant_manager.py --impact-analysis --target-id "requests" --target-type dependency --json
```
**Expected output:** JSON with affected apps and modules across all registered tenants.

### 11. Portfolio Health
```bash
python tools/dochub/health_scorer.py --portfolio --json
```
**Expected output:** JSON with aggregate score, per-app breakdown, portfolio grade.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-DH-1 | Scanner-tier deterministic generation (zero Claude tokens). Optional LLM via two-tier router |
| D-DH-2 | Document versions use monotonic integer with SHA-256 content hash |
| D-DH-3 | Section-level diffing (not line-level) — structured document templates |
| D-DH-4 | Health score uses weighted composite: freshness 0.35, completeness 0.40, gaps 0.25 |
| D-DH-5 | BYOS scanner reuses detection patterns from sbom_generator and code_analyzer |
| D-DH-6 | Enrichment cache with configurable TTL — graceful degradation in air-gap |
| D-DH-7 | Multi-tenant via tenant_id column — future-proofed for multi-org |
| D-DH-8 | Export delegates to existing tools (oscal_generator, etc.) where possible |
| D-DH-9 | All dh_ tables are append-only (NIST AU compliant) |
| D-DH-10 | Profile definitions are JSON in context/ (GOTCHA context layer) |
| D-DH-11 | Module-level docs with independent health scores, rolling up to parent app |
| D-DH-12 | Portfolio aggregate uses weighted average by app criticality |
| D-DH-13 | Imported artifacts stored as-is with format detection |
| D-DH-14 | Provenance tracks origin_project, origin_version, current_version, drift_status |
| D-DH-15 | Dependency graph uses adjacency list (matches D27 pattern) |

## Edge Cases

- Missing source data returns graceful defaults (empty sections, not errors)
- Air-gapped mode: enrichment disabled, all generation scanner-tier only
- BYOS without DB: scan-only mode returns JSON to stdout, no DB writes
- Module without provenance: treated as locally-created (no drift check)
- Empty project (no controls/findings): generates template with placeholder sections
- Large BYOS projects: directory walk skips .git, node_modules, __pycache__, venv, dist
