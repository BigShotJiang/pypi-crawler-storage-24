# CUI // SP-CTI

# F9: Golden Path Scaffolder

## Purpose

Generate new project scaffolds from opinionated, compliance-ready templates ("golden paths"). Each template embeds security controls, CI/CD pipelines, NIST mappings, and coding standards so every new project starts compliant by default.

## Prerequisites

- `data/icdev.db` initialized with project tables
- Template catalog populated (built-in templates available at first run)

## Workflow Steps

### 1. List Templates
```bash
python tools/scaffold/golden_path.py --list --json
```
**Expected output:** JSON array of available templates with name, description, language, framework, compliance level, and included controls.

### 2. Scaffold Project
```bash
python tools/scaffold/golden_path.py --scaffold --template "python-fastapi-il4" --project-name "my-service" --output-dir /path/to/output --json
```
**Expected output:** JSON with generated file manifest, directory structure, applied controls, CI/CD pipeline path, and post-scaffold instructions.

### 3. Validate Output
```bash
python tools/scaffold/golden_path.py --validate --project-dir /path/to/output --json
```
**Expected output:** JSON with validation results: file completeness check, control presence verification, CI/CD pipeline syntax check, and pass/fail status.

### 4. Show Template Details
```bash
python tools/scaffold/golden_path.py --details --template "python-fastapi-il4" --json
```
**Expected output:** JSON with full template specification including file list, variable placeholders, embedded controls, and customization options.

### 5. Register Custom Template
```bash
python tools/scaffold/golden_path.py --register --template-dir /path/to/custom-template --name "custom-flask-il2" --json
```
**Expected output:** JSON with registration status, template ID, and validation results.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-INV-33 | Templates use Jinja2 with string-replacement fallback -- air-gap safe |
| D-INV-34 | Built-in templates: python-fastapi-il4, python-flask-il2, node-express-il2, rust-axum-il4 |
| D-INV-35 | Compliance bootstrap embeds control stubs, CUI headers, and .gitignore for secrets |
| D-INV-36 | Validation checks structural completeness -- does not compile or execute generated code |

## Edge Cases

- Unknown template name returns available templates list with suggestions
- Output directory already exists returns error unless `--force` flag provided
- Template with missing variables uses defaults and logs warnings
- Validation of non-scaffolded project checks against closest matching template

## Tier Gating

| Capability | Community | Pro |
|------------|-----------|-----|
| List built-in templates | Yes | Yes |
| Scaffold from built-in | Yes | Yes |
| Validate output | Yes | Yes |
| Register custom templates | No | Yes |
| Compliance bootstrap (NIST controls) | No | Yes |

## Security

- Scaffold operations logged to audit trail
- Generated projects include .gitignore excluding secrets and .env files
- CUI markings applied to all generated source files at IL4+
- No secrets or credentials embedded in templates -- placeholder references only
