# CUI // SP-CTI

# F5: Digital Thread Gap Heatmap

## Purpose

Visualize traceability coverage across the digital thread (requirements -> design -> code -> test -> compliance). Identify orphaned artifacts, missing links, and coverage gaps as a heatmap matrix to prioritize remediation efforts.

## Prerequisites

- `data/icdev.db` initialized with MBSE tables
- Digital thread links populated via `tools/mbse/digital_thread.py`
- At least one model imported via `xmi_parser.py` or `reqif_parser.py`

## Workflow Steps

### 1. Generate Heatmap
```bash
python tools/mbse/thread_heatmap.py --heatmap --project-id "sparkpilot" --json
```
**Expected output:** JSON with heatmap matrix (rows = source artifacts, columns = target artifact types), cell values as coverage percentages (0.0-1.0), and overall thread health score.

### 2. Get Gap Matrix
```bash
python tools/mbse/thread_heatmap.py --gap-matrix --project-id "sparkpilot" --json
```
**Expected output:** JSON array of gap entries with source artifact ID, missing link types, severity (critical/high/medium/low), and suggested remediation.

### 3. Get Orphaned Artifacts
```bash
python tools/mbse/thread_heatmap.py --orphans --project-id "sparkpilot" --json
```
**Expected output:** JSON array of artifacts with zero inbound or outbound links, grouped by artifact type.

### 4. Check Coverage Threshold
```bash
python tools/mbse/thread_heatmap.py --coverage-check --project-id "sparkpilot" --threshold 0.8 --json
```
**Expected output:** JSON with pass/fail status, current coverage percentage, threshold, and list of below-threshold artifact pairs.

### 5. Get Historical Trend
```bash
python tools/mbse/thread_heatmap.py --trend --project-id "sparkpilot" --window-days 30 --json
```
**Expected output:** JSON array of daily coverage snapshots showing improvement or regression.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-INV-17 | Heatmap computed from digital_thread_links table via SQL aggregation -- no external deps |
| D-INV-18 | Gap severity based on artifact type: requirement->test gaps are CRITICAL, design->code gaps are HIGH |
| D-INV-19 | Orphan detection uses bidirectional link check -- both unlinked sources and unlinked targets |
| D-INV-20 | Coverage threshold configurable per project, defaults to 0.8 |

## Edge Cases

- Empty digital thread returns heatmap with all zeros and setup instructions
- Single artifact type returns 1x1 matrix with self-link coverage
- Deleted artifacts excluded from heatmap but logged in gap report
- Coverage check with threshold 0.0 always passes (used for baseline)

## Tier Gating

| Capability | Community | Pro |
|------------|-----------|-----|
| Heatmap generation | Yes | Yes |
| Gap matrix | Yes | Yes |
| Orphan detection | Yes | Yes |
| CI/CD gate integration | No | Yes |
| Historical trending | No | Yes |

## Security

- Heatmap data is read-only aggregation -- no mutations
- Coverage check results logged to audit trail
- CUI markings applied to exported heatmap reports
