# Goal: Bite-Sized Implementation Plans

## Description

Break implementation work into bite-sized tasks (2-5 minutes each) with exact file paths, exact code, exact test commands, and exact expected output. Plans are written assuming the implementer has zero codebase context.

**Adapted from:** [obra/superpowers](https://github.com/obra/superpowers) writing-plans skill.

**The principle:** Write plans clear enough for "an enthusiastic junior engineer with no project context" to follow. Every step is one action. DRY. YAGNI. TDD. Frequent commits.

---

## When to Use

- After a design is approved (`goals/brainstorming_gate.md`)
- Before any multi-step implementation (3+ files to create/modify)
- When dispatching work to subagents
- When breaking a phase into tasks

**Exceptions:**
- Single-file bug fixes (use `goals/systematic_debugging.md`)
- Trivial changes the user wants done immediately

---

## Prerequisites

- [ ] Design approved (or user directive clear)
- [ ] Relevant source files read and understood
- [ ] Test framework available (pytest, behave)

---

## Process

### Step 1: Write the Plan Header

Every plan MUST start with:

```markdown
# [Feature Name] Implementation Plan

**Goal:** [One sentence describing what this builds]
**Architecture:** [2-3 sentences about approach]
**Key Files:** [List critical existing files to reference]

---
```

### Step 2: Break Into Bite-Sized Tasks

**Each task is one action (2-5 minutes):**

| Good (one action) | Bad (multiple actions) |
|---|---|
| "Write the failing test" | "Write tests and implement the feature" |
| "Run it to make sure it fails" | "Make it all work" |
| "Implement the minimal code to pass" | "Add the module with tests" |
| "Run tests and verify they pass" | "Finish the feature" |
| "Commit" | "Clean up and commit everything" |

### Step 3: Task Structure

Each task follows this template:

````markdown
### Task N: [Component Name]

**Files:**
- Create: `exact/path/to/file.py`
- Modify: `exact/path/to/existing.py` (lines ~120-145)
- Test: `tests/exact/path/to/test_file.py`

**Step 1: Write the failing test**

```python
def test_specific_behavior():
    """Exact test code — copy-paste ready."""
    result = function_under_test(input_value)
    assert result == expected_value
```

**Step 2: Run test to verify it fails**

```bash
python -m pytest tests/path/test_file.py::test_specific_behavior -v
```
Expected: FAIL with "function_under_test not defined" or similar

**Step 3: Write minimal implementation**

```python
def function_under_test(input_value):
    """Exact implementation code — copy-paste ready."""
    return expected_value
```

**Step 4: Run test to verify it passes**

```bash
python -m pytest tests/path/test_file.py::test_specific_behavior -v
```
Expected: PASS

**Step 5: Commit**

```bash
git add tests/path/test_file.py src/path/file.py
git commit -m "feat: add specific feature"
```
````

### Step 4: Plan Completeness Checklist

Before finalizing the plan, verify:

- [ ] Every task has exact file paths (no "the config file")
- [ ] Every task has complete code (no "add validation logic here")
- [ ] Every task has exact commands with expected output
- [ ] Every task follows TDD: test first → fail → implement → pass → commit
- [ ] Tasks are ordered by dependency (no forward references)
- [ ] Each task is independently verifiable (can confirm it worked)

### Step 5: Save the Plan

```
docs/plans/YYYY-MM-DD-<feature-name>-plan.md
```

### Step 6: Execution Handoff

After saving, offer execution choice:

**Option 1: Direct execution** — Execute tasks sequentially in this session, checkpointing every 3 tasks.

**Option 2: Subagent-driven** — Dispatch fresh subagent per task with two-stage review (`goals/subagent_review.md`).

**Option 3: Parallel agents** — If tasks are independent, dispatch multiple agents concurrently (`dispatching-parallel-agents` pattern).

---

## Example: Adding a New API Endpoint

````markdown
# Widget Counter Implementation Plan

**Goal:** Add a GET /api/widgets/count endpoint that returns widget count per tenant.
**Architecture:** New route in app.py, new function in widget_manager.py, DB query.
**Key Files:** `tools/dashboard/app.py`, `tools/widgets/widget_manager.py`

---

### Task 1: Write failing test for count function

**Files:**
- Create: `tests/test_widget_manager.py`

**Step 1: Write test**
```python
from tools.widgets.widget_manager import get_widget_count

def test_get_widget_count_empty():
    result = get_widget_count(tenant_id="test-tenant")
    assert result == {"count": 0, "tenant_id": "test-tenant"}
```

**Step 2: Run — expect FAIL**
```bash
python -m pytest tests/test_widget_manager.py::test_get_widget_count_empty -v
```

### Task 2: Implement minimal count function

**Files:**
- Modify: `tools/widgets/widget_manager.py`

**Step 1: Add function**
```python
def get_widget_count(tenant_id: str) -> dict:
    from tools.db.storage import get_connection
    with get_connection() as conn:
        row = conn.execute(
            "SELECT COUNT(*) as cnt FROM widgets WHERE tenant_id = ?",
            (tenant_id,)
        ).fetchone()
        count = row[0] if row else 0
    return {"count": count, "tenant_id": tenant_id}
```

**Step 2: Run — expect PASS**
```bash
python -m pytest tests/test_widget_manager.py::test_get_widget_count_empty -v
```

**Step 3: Commit**
```bash
git add tools/widgets/widget_manager.py tests/test_widget_manager.py
git commit -m "feat: add get_widget_count function"
```
````

---

## Integration with GOTCHA

| Layer | Role |
|-------|------|
| **Goals** | This goal defines plan format |
| **Orchestration** | You write the plan, then execute or delegate |
| **Tools** | Plans reference exact tool paths and commands |
| **Args** | Plans may reference config in `args/` |
| **Context** | Plans are informed by existing codebase |
| **Hard Prompts** | The plan itself becomes a hard prompt for subagents |

---

## Key Principles

- **Exact file paths always** — never "the config file" or "the test file"
- **Complete code in plan** — never "add validation" or "implement logic"
- **Exact commands with expected output** — never "run the tests"
- **DRY** — don't repeat yourself across tasks
- **YAGNI** — don't plan features not requested
- **TDD** — every task starts with a failing test
- **Frequent commits** — commit after each task or logical group
