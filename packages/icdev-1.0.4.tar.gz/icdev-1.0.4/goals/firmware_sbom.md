# CUI // SP-CTI

# F12: Firmware SBOM + VEX

## Purpose

Generate Software Bill of Materials (SBOM) and Vulnerability Exploitability eXchange (VEX) documents for embedded firmware projects. Parses CMake build files, detects RTOS components, enumerates third-party libraries, and maps known CVEs to deployed firmware.

## Prerequisites

- `data/icdev.db` initialized with project and SBOM tables
- Firmware project with CMakeLists.txt (or build manifest)
- Board support package registered via `tools/embedded/cmake_generator.py`

## Workflow Steps

### 1. Generate SBOM
```bash
python tools/compliance/firmware_sbom.py --generate --project-id "sparkpilot" --firmware-dir /path/to/firmware --format cyclonedx --json
```
**Expected output:** JSON SBOM with component inventory: name, version, supplier, license, CPE identifier, and dependency relationships.

### 2. Parse CMake Dependencies
```bash
python tools/compliance/firmware_sbom.py --parse-cmake --project-id "sparkpilot" --cmake-file /path/to/CMakeLists.txt --json
```
**Expected output:** JSON array of dependencies extracted from CMake: library name, version constraints, fetch method (FetchContent/find_package/submodule), and source URL.

### 3. Detect RTOS Components
```bash
python tools/compliance/firmware_sbom.py --detect-rtos --project-id "sparkpilot" --firmware-dir /path/to/firmware --json
```
**Expected output:** JSON with detected RTOS (FreeRTOS/Zephyr/NuttX), version, kernel config, enabled modules (TCP/IP, TLS, OTA), and component hashes.

### 4. Generate VEX
```bash
python tools/compliance/firmware_sbom.py --generate-vex --project-id "sparkpilot" --json
```
**Expected output:** JSON VEX document with per-component vulnerability status: affected, not_affected (with justification), fixed, or under_investigation.

### 5. Check CVEs
```bash
python tools/compliance/firmware_sbom.py --check-cves --project-id "sparkpilot" --json
```
**Expected output:** JSON array of known CVEs matching SBOM components, with severity (CVSS), exploitability, and VEX status.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-INV-45 | SBOM format supports CycloneDX 1.5 and SPDX 2.3 -- CycloneDX default |
| D-INV-46 | CMake parsing uses regex extraction -- no CMake execution required (air-gap safe) |
| D-INV-47 | RTOS detection uses file signature matching (FreeRTOSConfig.h, Kconfig, defconfig) |
| D-INV-48 | VEX justifications follow CISA VEX guidelines: component_not_present, vulnerable_code_not_reachable, vulnerable_code_cannot_be_controlled_by_adversary, inline_mitigations_already_exist |

## Edge Cases

- Missing CMakeLists.txt falls back to directory scan for known library signatures
- Unknown RTOS returns component list without RTOS classification
- Component with no CPE identifier flagged for manual review
- CVE database unavailable (air-gap) returns SBOM without CVE overlay and note

## Tier Gating

| Capability | Community | Pro |
|------------|-----------|-----|
| SBOM generation | Yes | Yes |
| CMake parsing | Yes | Yes |
| RTOS detection | Yes | Yes |
| VEX generation | Yes | Yes |
| CVE triaging with severity | No | Yes |
| Automated VEX updates | No | Yes |

## Security

- SBOM and VEX documents are append-only versioned (NIST AU compliant)
- Component hashes (SHA-256) stored for integrity verification
- CUI markings applied to all generated SBOM/VEX artifacts
- No network calls for CVE lookup in air-gapped mode -- uses local CVE cache
