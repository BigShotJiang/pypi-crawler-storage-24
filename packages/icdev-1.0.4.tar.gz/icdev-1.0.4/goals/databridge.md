# CUI // SP-CTI
# Goal: DataBridge — Universal Data & Storage Connector

## Purpose
Enable ICDEV and child applications to connect to any database, data store,
cloud storage, streaming platform, SaaS API, or file source through a
unified Apache Arrow-based pipeline.

## When to Use
- User needs to read/write data from external sources
- User wants to set up data integrations (ETL/ELT)
- User needs to map schemas between sources
- User needs to query across multiple data sources (DuckDB analytics)
- User needs PII detection or CUI field-level marking on data flows

## Workflow

### 1. Create Connection
```bash
# Via dashboard: /databridge → "Add Connection"
# Via API: POST /api/databridge/connections
python tools/databridge/connection_manager.py --list --json
```

### 2. Test Connection
```bash
python tools/databridge/connection_manager.py --test <connection_id> --json
```

### 3. Infer Schema
```bash
python tools/databridge/schema_engine.py --get <connection_id> <table_name> --json
```

### 4. Sync Data (Read)
```bash
python tools/databridge/sync_engine.py --read <connection_id> <table_name> --json
```

### 5. Create Mapping (Optional)
```bash
# Via dashboard: /databridge/mappings → visual drag-and-drop editor
# Via API: POST /api/databridge/mappings
python tools/databridge/mapping_engine.py --list --json
```

### 6. Execute Mapping
```bash
python tools/databridge/mapping_engine.py --execute <mapping_id> --json
```

### 7. Query with DuckDB (Optional)
```bash
python tools/databridge/analytics.py --query "SELECT * FROM source LIMIT 10" --json
```

### 8. PII Scan (Optional)
```bash
python tools/databridge/pii_detector.py --scan <connection_id> <table_name> --json
```

## Tools

| Tool | Purpose |
|------|---------|
| `tools/databridge/connector.py` | ABC base class + universal types |
| `tools/databridge/connection_manager.py` | CRUD connections, health checks |
| `tools/databridge/schema_engine.py` | Schema inference, versioning |
| `tools/databridge/arrow_pipeline.py` | Arrow transform pipeline |
| `tools/databridge/sync_engine.py` | Sync orchestrator |
| `tools/databridge/registry.py` | Connector discovery |
| `tools/databridge/mapping_engine.py` | Schema crosswalks + transforms |
| `tools/databridge/transforms.py` | Transform function library |
| `tools/databridge/format_converter.py` | Format conversion |
| `tools/databridge/analytics.py` | DuckDB analytics |
| `tools/databridge/pii_detector.py` | PII detection (Presidio) |
| `tools/databridge/data_profiler.py` | Data quality profiling |
| `tools/databridge/stream_manager.py` | Streaming connector manager |
| `tools/databridge/relay_server.py` | On-prem WebSocket relay |

## Configuration
- `args/databridge_config.yaml` — module settings, tier limits, PII, CUI, FIPS

## Connectors (22 built-in)

| Category | Connectors | Tier |
|----------|-----------|------|
| Database | SQLite, PostgreSQL, MySQL, MSSQL, Oracle | SQLite=free |
| Cloud Storage | Local FS, S3, Azure Blob, GCS, HDFS | Local=free |
| File | CSV, JSON, Parquet, Avro, Excel | CSV/JSON=free |
| Streaming | Kafka, Kinesis, CDC | All paid |
| SaaS API | Salesforce, ServiceNow, Jira, SAP | All paid |

## Design Decisions
- D-DB-1: Independent `tools/databridge/` directory
- D-DB-2: ABC `DataConnector` + concrete implementations
- D-DB-3: Apache Arrow universal in-memory format
- D-DB-4: fsspec universal filesystem abstraction
- D-DB-5: DuckDB local analytics
- D-DB-6: Append-only sync logs (NIST AU)
- D-DB-7: Versioned schema mappings (SHA-256)
- D-DB-8: CUI field-level marking (IL4+ only)
- D-DB-9: Presidio PII detection
- D-DB-10: On-prem agent (outbound WebSocket)
- D-DB-11: Free tier: 3 connectors, no streaming
- D-DB-12: YAML config in DB column
- D-DB-13: Secret references, never plaintext
- D-DB-14: Deterministic schema inference
- D-DB-15: Transform pipeline = Arrow compute DAG
- D-DB-17: RAG integration with on/off toggle
- D-DB-18: Graceful optional imports
- D-DB-19: Visual mapping in vanilla JS + SVG
- D-DB-20: FIPS 140-3 TLS optional

## Edge Cases
- Connection fails mid-sync → log partial results, mark connection as error
- Schema drift detected → create new version, alert user
- PII detected in non-CUI data → flag_only mode (no masking unless configured)
- Free tier limit hit → return error with upgrade prompt
- Heavy dependency not installed → graceful skip, connector unavailable
- On-prem agent disconnects → auto-reconnect with exponential backoff

## Compliance
- All sync logs are append-only (NIST AU-2, AU-3)
- CUI field marking at IL4+ (NIST SI-12)
- PII detection satisfies NIST SI-18
- Schema versioning satisfies NIST CM-3
- Secret references satisfy NIST SC-28
