# CUI // SP-CTI

# F6: PR Intelligence

## Purpose

Analyze pull requests for security risks, compliance impact, and code quality before merge. Provides pre-merge risk scoring, automatic security prechecks, compliance policy validation, and consolidated reports for reviewers.

## Prerequisites

- `data/icdev.db` initialized with project and compliance tables
- Git repository accessible from working directory
- For auto-analysis: CI webhook configured via `tools/ci/triggers/webhook_server.py`

## Workflow Steps

### 1. Analyze PR
```bash
python tools/ci/pr_intelligence.py --analyze --project-id "sparkpilot" --pr-diff /path/to/diff --json
```
**Expected output:** JSON with risk score (0-100), changed file analysis, new dependency flags, API surface changes, and reviewer recommendations.

### 2. Run Security Precheck
```bash
python tools/ci/pr_intelligence.py --security-precheck --project-id "sparkpilot" --pr-diff /path/to/diff --json
```
**Expected output:** JSON with secret detection results, dependency vulnerability scan, SAST findings, and pass/fail gate status.

### 3. Run Compliance Precheck
```bash
python tools/ci/pr_intelligence.py --compliance-precheck --project-id "sparkpilot" --pr-diff /path/to/diff --json
```
**Expected output:** JSON with CUI marking check, control impact assessment, boundary change detection, and compliance gate status.

### 4. Generate Report
```bash
python tools/ci/pr_intelligence.py --report --project-id "sparkpilot" --pr-id "PR-42" --json
```
**Expected output:** JSON with consolidated report including risk score, security findings, compliance impact, code quality metrics, and recommended actions.

### 5. Get History
```bash
python tools/ci/pr_intelligence.py --history --project-id "sparkpilot" --last-n 20 --json
```
**Expected output:** JSON array of past PR analyses with risk trends and recurring issue patterns.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-INV-21 | Risk scoring uses weighted sum: security (0.4) + compliance (0.3) + complexity (0.2) + size (0.1) |
| D-INV-22 | Security precheck reuses existing SAST, dep audit, and secret detection tools |
| D-INV-23 | Compliance precheck checks boundary impact via boundary_analyzer.py |
| D-INV-24 | PR analysis results stored in append-only table for trend analysis |

## Edge Cases

- Empty diff returns zero-risk score with note
- Binary files in diff flagged but not analyzed for content
- PR touching compliance tools triggers elevated review requirement
- Missing project configuration returns setup instructions

## Tier Gating

| Capability | Community | Pro |
|------------|-----------|-----|
| Manual PR analysis | Yes | Yes |
| Security precheck | Yes | Yes |
| Compliance precheck | Yes | Yes |
| Auto-analysis on PR open | No | Yes |
| Compliance policy enforcement | No | Yes |

## Security

- PR analysis results are append-only (NIST AU compliant)
- Secret detection runs before any content is logged
- CUI markings applied to exported reports
- Diff content never persisted -- only analysis results stored
