# CUI // SP-CTI

# F3: VSM Dashboard

## Purpose

Track value stream metrics across the development pipeline. Compute DORA metrics (deployment frequency, lead time, change failure rate, MTTR), detect bottlenecks, and visualize end-to-end pipeline flow.

## Prerequisites

- `data/icdev.db` initialized with project tables
- Pipeline events recorded (commit, build, test, deploy stages)

## Workflow Steps

### 1. Record Stage Event
```bash
python tools/analytics/vsm_engine.py --record-event --project-id "sparkpilot" --stage "build" --status "success" --duration-seconds 120 --json
```
**Expected output:** JSON with event ID, timestamp, stage, status, and running stage metrics.

### 2. Compute DORA Metrics
```bash
python tools/analytics/vsm_engine.py --dora --project-id "sparkpilot" --window-days 30 --json
```
**Expected output:** JSON with deployment_frequency, lead_time_hours, change_failure_rate, mttr_hours, and DORA level (Elite/High/Medium/Low).

### 3. Detect Bottlenecks
```bash
python tools/analytics/vsm_engine.py --bottlenecks --project-id "sparkpilot" --json
```
**Expected output:** JSON array of stages ranked by average duration, wait time, and failure rate with bottleneck flags.

### 4. Get Pipeline Flow
```bash
python tools/analytics/vsm_engine.py --pipeline-flow --project-id "sparkpilot" --json
```
**Expected output:** JSON with ordered stage list, throughput per stage, WIP counts, and flow efficiency percentage.

### 5. Get Trend Report
```bash
python tools/analytics/vsm_engine.py --trend --project-id "sparkpilot" --window-days 90 --interval weekly --json
```
**Expected output:** JSON array of weekly DORA snapshots showing improvement or regression per metric.

## Decision Reference

| Decision | Description |
|----------|-------------|
| D-INV-9 | DORA classification uses 2024 DORA report thresholds |
| D-INV-10 | Stage events stored in append-only table -- immutable audit trail |
| D-INV-11 | Bottleneck detection uses statistical outlier analysis (> 1.5x IQR) |
| D-INV-12 | Flow efficiency = value-add time / total elapsed time per pipeline run |

## Edge Cases

- Fewer than 5 events returns insufficient data warning instead of DORA metrics
- Missing stage in pipeline flow marked as "no data" rather than zero
- Overlapping events for same stage deduplicated by latest timestamp
- Single-stage pipeline returns flow efficiency of 100%

## Tier Gating

| Capability | Community | Pro |
|------------|-----------|-----|
| Record events | 90-day retention | Unlimited history |
| DORA metrics | Yes | Yes |
| Bottleneck detection | Yes | Yes |
| Custom stage definitions | No | Yes |
| Trend reporting | Last 30 days | Unlimited window |

## Security

- All stage events are append-only (NIST AU compliant)
- Pipeline data scoped to project -- no cross-project leakage
- CUI markings applied to exported reports
