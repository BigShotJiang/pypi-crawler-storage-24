import logging
from logging.handlers import RotatingFileHandler
import os

LOG_FILE = "abhicalls.log"

os.makedirs("logs", exist_ok=True)

LOG_PATH = os.path.join("logs", LOG_FILE)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)

LOGGER = logging.getLogger("AbhiCalls")
LOGGER.setLevel(logging.INFO)

file_handler = RotatingFileHandler(
    LOG_PATH,
    maxBytes=5 * 1024 * 1024,
    backupCount=3
)

formatter = logging.Formatter(
    "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)

file_handler.setFormatter(formatter)

LOGGER.addHandler(file_handler)
