from traceback import format_exc
from AbhiCalls.logger import LOGGER
from AbhiCalls._engine.native import _NativeEngine
from AbhiCalls.controller import VoiceController


class VoiceEngine:
    def __init__(self, app, cookies: str | None = None):
        try:
            LOGGER.info("VoiceEngine init")

            self._engine = _NativeEngine(app)
            self.vc = VoiceController(self._engine, cookies=cookies)

            LOGGER.info("VoiceEngine controller attached")

        except Exception:
            LOGGER.error("VoiceEngine initialization failed\n%s", format_exc())
            raise

    async def start(self):
        try:
            await self._engine.start()
            LOGGER.info("VoiceEngine started")

        except Exception:
            LOGGER.error("VoiceEngine start failed\n%s", format_exc())
            raise
