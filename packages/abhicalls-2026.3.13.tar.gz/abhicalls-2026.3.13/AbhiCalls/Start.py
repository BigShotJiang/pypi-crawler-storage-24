import requests
from traceback import format_exc
from AbhiCalls import __version__, __author__
from AbhiCalls.logger import LOGGER


def check_latest_version(pkg_name="AbhiCalls"):
    try:
        r = requests.get(f"https://pypi.org/pypi/{pkg_name}/json", timeout=3)
        if r.status_code != 200:
            LOGGER.error("PyPI bad status → %s", r.status_code)
            return None
        data = r.json()
        return data.get("info", {}).get("version")
    except Exception:
        LOGGER.error("Version check failed\n%s", format_exc())
        return None


def print_startup_message():
    try:
        LOGGER.info("AbhiCalls started")
        LOGGER.info("Version  : %s", __version__)
        LOGGER.info("Author   : %s", __author__)
        LOGGER.info("License  : Abhishek Special")
        LOGGER.info("GitHub   : https://github.com/YouTubeMusicAPI/AbhiCalls")
        LOGGER.info("Telegram : https://t.me/WtfShia")

        latest = check_latest_version("AbhiCalls")

        if not latest:
            LOGGER.warning("Could not check latest version (offline or PyPI issue)")
            return

        if latest != __version__:
            LOGGER.warning("Update Available → v%s", latest)
        else:
            LOGGER.info("You are using the latest version!")

    except Exception:
        LOGGER.error("Startup error\n%s", format_exc())
