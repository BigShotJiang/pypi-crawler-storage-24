from traceback import format_exc
from AbhiCalls.logger import LOGGER


class Settings:
    def __init__(self):
        try:
            self.cookies: str | None = None
            self.require_cookies: bool = True
            self.debug: bool = False
            self.auto_delete_queue: bool = True
            self.auto_delete_nowplaying: bool = True
            self.default_volume: int = 200
            self.experimental: bool = False
        except Exception:
            LOGGER.error("Settings initialization failed\n%s", format_exc())

    def __repr__(self):
        try:
            return (
                f"<Settings debug={self.debug} "
                f"cookies={'Yes' if self.cookies else 'No'} "
                f"require_cookies={self.require_cookies}>"
            )
        except Exception:
            LOGGER.error("Settings repr failed\n%s", format_exc())
            return "<Settings error>"


settings = Settings()
