from traceback import format_exc

from AbhiCalls.vc import VoiceEngine
from AbhiCalls.runtime import idle
from AbhiCalls.logger import LOGGER
from .player import Player
from .plugins import Plugin

__all__ = ["VoiceEngine", "idle"]

__version__ = "2026.3.13"
__author__ = "ABHISHEK THAKUR"

try:
    from .Start import print_startup_message
    print_startup_message()
except ImportError:
    LOGGER.error("Startup module not found\n%s", format_exc())
except Exception:
    LOGGER.error("Startup execution failed\n%s", format_exc())
