from collections import deque
import random
from traceback import format_exc

from AbhiCalls.logger import LOGGER


class SongQueue:
    def __init__(self):
        self.items = []
        self.history = deque(maxlen=20)
        self.infinite_loop = False

    def add(self, song):
        try:
            self.items.append(song)
            LOGGER.info(
                "Queue add → %s (size=%s)",
                getattr(song, "title", "Unknown"),
                len(self.items),
            )
            return len(self.items)
        except Exception:
            LOGGER.error("Queue add failed\n%s", format_exc())

    def pop_last(self):
        try:
            if not self.items:
                return None

            removed = self.items.pop()

            LOGGER.info(
                "Queue pop_last → %s",
                getattr(removed, "title", "Unknown"),
            )

            return removed

        except Exception:
            LOGGER.error("Queue pop_last failed\n%s", format_exc())

    def current(self):
        try:
            if not self.items:
                return None
            return self.items[0]

        except Exception:
            LOGGER.error("Queue current failed\n%s", format_exc())

    def next(self):
        try:
            if not self.items:
                LOGGER.warning("Queue next → empty")
                return None

            current = self.items[0]
            self.history.appendleft(current)

            if getattr(current, "loop_left", 0) > 0:
                current.loop_left -= 1
                LOGGER.info("Queue loop → %s left=%s", current.title, current.loop_left)
                return current

            if self.infinite_loop:
                LOGGER.info("Queue infinite loop → %s", current.title)
                return current

            self.items.pop(0)

            nxt = self.current()

            if nxt:
                LOGGER.info("Queue next → %s", nxt.title)
            else:
                LOGGER.info("Queue finished")

            return nxt

        except Exception:
            LOGGER.error("Queue next failed\n%s", format_exc())

    def previous(self):
        try:
            if not self.history:
                LOGGER.warning("Queue previous → empty")
                return None

            prev = self.history.popleft()
            self.items.insert(0, prev)

            LOGGER.info("Queue previous → %s", prev.title)

            return prev

        except Exception:
            LOGGER.error("Queue previous failed\n%s", format_exc())

    def shuffle(self):
        try:
            if len(self.items) <= 1:
                LOGGER.info("Queue shuffle skipped")
                return False

            current = self.items.pop(0)
            random.shuffle(self.items)
            self.items.insert(0, current)

            LOGGER.info("Queue shuffled")

            return True

        except Exception:
            LOGGER.error("Queue shuffle failed\n%s", format_exc())

    def clear(self):
        try:
            LOGGER.info("Queue cleared")

            self.items.clear()
            self.history.clear()
            self.infinite_loop = False

        except Exception:
            LOGGER.error("Queue clear failed\n%s", format_exc())
