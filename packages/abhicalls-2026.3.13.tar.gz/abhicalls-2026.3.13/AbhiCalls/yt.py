import re
import os
import asyncio
import inspect
from traceback import format_exc

from YouTubeMusic.Search import Search
from YouTubeMusic.Stream import get_stream, get_video_stream
from YouTubeMusic.Playlist import get_playlist_songs

from AbhiCalls.settings import settings
from AbhiCalls.logger import LOGGER


PLAYLIST_REGEX = re.compile(r"(list=)")
YOUTUBE_REGEX = re.compile(r"(youtube\.com|youtu\.be|music\.youtube\.com)")


def sec_to_mmss(sec):
    try:
        sec = int(sec)
        return f"{sec // 60}:{sec % 60:02d}"
    except Exception:
        return "0:00"


def yt_thumbnail(url: str):
    try:
        if "watch?v=" in url:
            vid = url.split("watch?v=")[1].split("&")[0]
        elif "youtu.be/" in url:
            vid = url.split("youtu.be/")[1].split("?")[0]
        else:
            return None
        return f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
    except Exception:
        return None


async def safe_extract(extractor, url, cookies):
    try:
        if inspect.iscoroutinefunction(extractor):
            return await extractor(url, cookies)
        return await asyncio.to_thread(extractor, url, cookies)
    except Exception:
        LOGGER.error("Stream extraction failed → %s\n%s", url, format_exc())
        return None


def extract_channel(item):
    try:
        channel = item.get("channel")

        if isinstance(channel, dict):
            return channel.get("name", "Unknown")

        if isinstance(channel, str):
            return channel

        return "Unknown"

    except Exception:
        LOGGER.error("Channel extraction failed\n%s", format_exc())
        return "Unknown"


async def resolve_query(
    query: str,
    cookies: str | None = None,
    video: bool = False
):
    try:
        LOGGER.info("Resolver query=%s | video=%s", query, video)

        cookies = cookies or settings.cookies

        if settings.require_cookies and not cookies:
            raise RuntimeError("Cookies required but missing")

        extractor = get_video_stream if video else get_stream


        if PLAYLIST_REGEX.search(query):

            LOGGER.info("Resolver mode=playlist")

            playlist = await get_playlist_songs(query)
            songs = []

            for item in playlist:
                url = item.get("url")

                if not url:
                    continue

                try:
                    stream = await safe_extract(extractor, url, cookies)
                except Exception:
                    LOGGER.error("Playlist stream error → %s\n%s", url, format_exc())
                    continue

                if not stream:
                    continue

                songs.append({
                    "title": item.get("title", "Unknown"),
                    "url": url,
                    "duration": sec_to_mmss(item.get("duration", 0)),
                    "views": item.get("views", "Unknown"),
                    "channel": extract_channel(item),
                    "thumb": yt_thumbnail(url),
                    "stream": stream,
                    "is_video": video,
                })

            return songs or None


        LOGGER.info("Resolver mode=search/url")

        res = await Search(query, limit=1)

        if not res or not res.get("main_results"):
            return None

        item = res["main_results"][0]
        url = item.get("url")

        if not url:
            return None

        stream = await safe_extract(extractor, url, cookies)

        if not stream:
            raise RuntimeError(f"Stream extraction failed → {url}")

        return [{
            "title": item.get("title", "Unknown"),
            "url": url,
            "duration": item.get("duration", "0:00"),
            "views": item.get("views", "Unknown"),
            "channel": extract_channel(item),
            "thumb": item.get("thumbnail") or yt_thumbnail(url),
            "stream": stream,
            "is_video": video,
        }]

    except Exception:
        LOGGER.error("Resolver failed\n%s", format_exc())
        return None
        

async def _test():
    try:
        LOGGER.info("YT Resolver test started")

        query = input("Enter search or YouTube link: ").strip()
        cookie_path = input("Enter cookies.txt path (leave blank if none): ").strip()

        cookies = None

        if cookie_path:
            if os.path.exists(cookie_path):
                cookies = cookie_path
                LOGGER.info("Cookies file loaded")
            else:
                LOGGER.error("Cookies file not found")
                return

        try:
            audio_results = await resolve_query(query, cookies=cookies, video=False)

            if audio_results:
                song = audio_results[0]

                LOGGER.info("TITLE   : %s", song["title"])
                LOGGER.info("CHANNEL : %s", song["channel"])
                LOGGER.info("VIEWS   : %s", song["views"])
                LOGGER.info("STREAM  : %s", str(song["stream"])[:120])

        except Exception:
            LOGGER.error("Audio test failed\n%s", format_exc())

        try:
            video_results = await resolve_query(query, cookies=cookies, video=True)

            if video_results:
                song = video_results[0]

                LOGGER.info("TITLE   : %s", song["title"])
                LOGGER.info("CHANNEL : %s", song["channel"])
                LOGGER.info("VIEWS   : %s", song["views"])
                LOGGER.info("STREAM  : %s", str(song["stream"])[:120])

        except Exception:
            LOGGER.error("Video test failed\n%s", format_exc())

        LOGGER.info("Resolver test complete")

    except Exception:
        LOGGER.error("Resolver test crashed\n%s", format_exc())


if __name__ == "__main__":
    asyncio.run(_test())
    
