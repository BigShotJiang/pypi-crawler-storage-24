import sys
import os
import logging
from contextlib import contextmanager
from traceback import format_exc
from pytgcalls import idle as _idle

from AbhiCalls.logger import LOGGER

try:
    from AbhiCalls.settings import settings
    DEBUG = getattr(settings, "debug", False)
except Exception:
    LOGGER.error("Settings load failed\n%s", format_exc())
    DEBUG = False

logging.getLogger("pytgcalls").setLevel(logging.CRITICAL)
logging.getLogger("ntgcalls").setLevel(logging.CRITICAL)


@contextmanager
def _suppress_stdout():
    if DEBUG:
        yield
        return

    try:
        with open(os.devnull, "w") as devnull:
            old_out = sys.stdout
            old_err = sys.stderr
            sys.stdout = devnull
            sys.stderr = devnull
            try:
                yield
            finally:
                sys.stdout = old_out
                sys.stderr = old_err
    except Exception:
        LOGGER.error("stdout suppression failed\n%s", format_exc())
        yield


async def idle():
    try:
        LOGGER.info("Idle loop started (debug=%s)", DEBUG)
        with _suppress_stdout():
            await _idle()
    except Exception:
        LOGGER.error("Idle loop crashed\n%s", format_exc())
