"""Device info, root-check, props, partitions."""
import os, re
from .utils import *

MAGISK_PATHS=['/data/adb/magisk','/sbin/.magisk','/data/adb/magisk.db']
KSU_PATHS=['/data/adb/ksu','/data/adb/ksud']
SUPERSU_PATHS=['/system/xbin/daemonsu','/system/etc/.installed_su_daemon']
ROOT_BINS=['/sbin/su','/system/bin/su','/system/xbin/su','/su/bin/su']

def cmd_info(args):
    section('Device Info'); print()
    props={'Model':'ro.product.model','Brand':'ro.product.brand',
           'Device':'ro.product.device','Android':'ro.build.version.release',
           'SDK':'ro.build.version.sdk','Build':'ro.build.display.id',
           'Arch':'ro.product.cpu.abi','Board':'ro.product.board',
           'Bootloader':'ro.bootloader','Hardware':'ro.hardware',
           'Fingerprint':'ro.build.fingerprint'}
    for label,key in props.items():
        val=get_prop(key)
        print(f"  {c(B,label+':'):<22} {c(GRN if val else DIM,val or '?')}")
    print()
    # RAM
    ram_out,_,_=run(['cat','/proc/meminfo'])
    if not ram_out and is_termux(): ram_out,_,_=run_root('cat /proc/meminfo')
    if ram_out:
        tot=re.search(r'MemTotal:\s+(\d+)',ram_out)
        avl=re.search(r'MemAvailable:\s+(\d+)',ram_out)
        if tot:
            tm=int(tot.group(1))//1024
            am=int(avl.group(1))//1024 if avl else 0
            um=tm-am
            bl=int((um/tm)*30) if tm else 0
            col=RED if um/tm>0.85 else YLW if um/tm>0.6 else GRN
            bar=c(col,'█'*bl)+c(DIM,'░'*(30-bl))
            print(f"  {c(B,'RAM:  ')}  {bar} {c(YLW,str(um)+'MB')} / {c(WHT,str(tm)+'MB')}")
    # CPU
    cpu_out,_,_=run(['cat','/proc/cpuinfo'])
    if not cpu_out and is_termux(): cpu_out,_,_=run_root('cat /proc/cpuinfo')
    if cpu_out:
        hw=re.search(r'Hardware\s*:\s*(.+)',cpu_out)
        cores=cpu_out.count('processor\t:')
        model=re.search(r'model name\s*:\s*(.+)',cpu_out)
        cs=(hw.group(1) if hw else model.group(1) if model else '?').strip()
        print(f"  {c(B,'CPU:  ')}  {c(WHT,cs)} {c(DIM,f'({cores} cores)')}")
    # Storage
    df,_,_=run(['df','-h','/data'])
    if df:
        parts=df.strip().split('\n')
        if len(parts)>1:
            p=parts[1].split()
            if len(p)>=4:
                print(f"  {c(B,'Storage:')} {c(YLW,p[2])} used / {c(WHT,p[1])} total")
    print()

def cmd_root_check(args):
    section('Root Status Check'); print()
    rooted=False; root_method=None
    sp=Spinner('Testing su access...')
    sp.start()
    su_out,su_err,su_code=run(['su','-c','id'],timeout=6)
    sp.stop()
    if su_code==0 and 'uid=0' in su_out:
        ok(f"su works → {c(GRN,su_out.strip())}"); rooted=True
    else:
        err(f"su not available ({su_err[:60] if su_err else 'no response'})")
    print()
    # Detect root manager
    sp2=Spinner('Detecting root manager...')
    sp2.start()
    for path in MAGISK_PATHS:
        e,_,ec=run_root(f'test -e {path} && echo yes')
        if ec==0 and 'yes' in e:
            sp2.stop()
            ok(f"Magisk detected: {c(CYN,path)}")
            root_method='magisk'; rooted=True
            mv,_,_=run_root('magisk -v 2>/dev/null')
            if mv: info(f"Version: {mv[:40]}")
            break
    if not root_method:
        for path in KSU_PATHS:
            e,_,ec=run_root(f'test -e {path} && echo yes')
            if ec==0 and 'yes' in e:
                sp2.stop()
                ok(f"KernelSU detected: {c(CYN,path)}")
                root_method='kernelsu'; rooted=True; break
    if not root_method:
        for path in SUPERSU_PATHS:
            e,_,ec=run_root(f'test -e {path} && echo yes')
            if ec==0 and 'yes' in e:
                sp2.stop()
                ok(f"SuperSU detected: {c(CYN,path)}")
                root_method='supersu'; rooted=True; break
    if not root_method:
        try: sp2.stop()
        except: pass
        found=[p for p in ROOT_BINS if os.path.exists(p)]
        if found: warn(f"Root binary found: {found[0]}"); root_method='unknown'
        else: err("No root manager detected")
    print()
    sel,_,_=run(['getenforce'])
    if not sel: sel,_,_=run_root('getenforce')
    if sel: print(f"  {c(B,'SELinux:')}    {c(YLW if 'Enforcing' in sel else GRN,sel.strip())}")
    bl=get_prop('ro.boot.flash.locked') or get_prop('ro.secureboot.lockstate')
    if bl:
        locked=bl in ('1','locked','true')
        print(f"  {c(B,'Bootloader:')} {c(RED,'LOCKED') if locked else c(GRN,'UNLOCKED')}")
    print()
    if rooted: ok(c(GRN+B,f"Device IS rooted ({root_method or 'detected'})"))
    else:
        err(c(RED+B,"Device is NOT rooted"))
        print(f"\n  Run {c(CYN+B,'luckyboot root')} to root it, or {c(CYN,'luckyboot root-guide')} for a guide.\n")

def cmd_props(args):
    section('Build Properties'); print()
    filt=getattr(args,'filter',None)
    out,_,_=run(['getprop'])
    if not out: out,_,_=run_root('getprop')
    if not out: err("Cannot read props"); print(); return
    for line in out.split('\n'):
        if not line.strip(): continue
        if filt and filt.lower() not in line.lower(): continue
        m=re.match(r'\[([^\]]+)\]:\s*\[([^\]]*)\]',line)
        if m:
            k,v=m.group(1),m.group(2)
            col=CYN if any(x in k for x in ['version','model','brand','build']) else BLU
            print(f"  {c(col,k):<45} {c(WHT,v)}")
    print()

def cmd_partitions(args):
    section('Partitions'); print()
    out,_,_=run(['cat','/proc/partitions'])
    if not out: out,_,_=run_root('cat /proc/partitions')
    if out:
        print(f"  {c(B+WHT,'Major  Minor  Blocks    Name')}\n  {c(DIM,chr(8212)*45)}")
        for line in out.strip().split('\n')[2:]:
            p=line.split()
            if len(p)>=4:
                nm=p[3]; bl=int(p[2]); sz=bl//1024
                col=GRN if 'mmcblk' in nm and 'p' in nm else YLW if 'mmcblk' in nm else DIM
                print(f"  {c(DIM,p[0]):<8}{c(DIM,p[1]):<8}{c(col,nm):<20}{c(YLW,str(sz)+'MB') if sz>0 else c(DIM,str(bl)+'K')}")
    mnt,_,_=run(['cat','/proc/mounts'])
    if not mnt: mnt,_,_=run_root('cat /proc/mounts')
    if mnt:
        print(f"\n  {c(B,'Mounted:')}")
        imp=['system','vendor','data','cache','boot','recovery','odm']
        for line in mnt.split('\n'):
            p=line.split()
            if len(p)>=3 and any(k in p[1] for k in imp):
                rw=c(GRN,'rw') if 'rw' in p[3] else c(RED,'ro')
                print(f"  {c(BLU,p[0]):<35}{c(WHT,p[1]):<20}{rw}")
    print()
