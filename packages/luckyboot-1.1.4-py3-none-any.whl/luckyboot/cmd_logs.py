"""Logcat analyzer, bugreport, crash detector with AI."""
import os, re, json, subprocess
import urllib.request
from .utils import *

UA = 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36'

def cmd_crash(args):
    """Find crashes and ANRs in logcat."""
    serial = getattr(args,'serial',None)
    lines  = getattr(args,'lines',None) or 5000
    section('Crash & ANR Detector'); print()
    sp = Spinner('Reading logcat...')
    sp.start()
    out, _, _ = adb_cmd(['logcat','-d','-t',str(lines),'-v','time'], serial=serial)
    sp.stop()
    if not out: err("No logcat output"); print(); return

    crashes = []; anrs = []; exceptions = []
    current_block = []; in_block = False

    for line in out.split('\n'):
        if any(x in line for x in ['FATAL EXCEPTION','AndroidRuntime','CRASH']):
            in_block = True; current_block = [line]
        elif in_block:
            if line.strip().startswith('at ') or 'Caused by:' in line or 'Exception' in line:
                current_block.append(line)
            else:
                if current_block: crashes.append('\n'.join(current_block[:15]))
                in_block = False; current_block = []
        if 'ANR in' in line:
            anrs.append(line)
        if re.search(r'\b(NullPointerException|OutOfMemoryError|IllegalStateException|NetworkOnMainThreadException)', line):
            exceptions.append(line)

    print(f"  {c(B,'Crashes found:  ')} {c(RED+B if crashes else GRN, str(len(crashes)))}")
    print(f"  {c(B,'ANRs found:     ')} {c(RED+B if anrs else GRN, str(len(anrs)))}")
    print(f"  {c(B,'Exceptions:     ')} {c(YLW if exceptions else GRN, str(len(exceptions)))}")
    print()

    if crashes:
        print(f"  {c(RED+B,'═ CRASHES ══════════════════════════════')}")
        for i, crash in enumerate(crashes[:3]):
            print(f"\n  {c(RED+B,'Crash '+str(i+1)+':')}")
            for line in crash.split('\n')[:10]:
                m = re.search(r'\s([VDIWEFS])/', line)
                col = RED if m and m.group(1) in 'EF' else DIM
                print(f"  {c(col, line)}")
        if len(crashes)>3: print(f"\n  {c(DIM,f'... and {len(crashes)-3} more')}")
        print()

    if anrs:
        print(f"  {c(YLW+B,'═ ANRs ══════════════════════════════════')}")
        for anr in anrs[:5]:
            print(f"  {c(YLW, anr)}")
        print()

    # AI analysis
    if getattr(args,'ai',False) and crashes:
        _ai_analyze_crash(crashes[0], serial=serial)

def _ai_analyze_crash(crash_text, serial=None):
    api_key = os.environ.get('GROQ_API_KEY') or os.environ.get('ANTHROPIC_API_KEY')
    if not api_key: warn("Set GROQ_API_KEY for AI analysis"); return
    provider = 'groq' if os.environ.get('GROQ_API_KEY') else 'claude'
    sp = Spinner('AI analyzing crash...')
    sp.start()
    try:
        payload = json.dumps({
            'model':'llama-3.3-70b-versatile',
            'max_tokens':800,
            'messages':[{'role':'user','content':f'Analyze this Android crash and explain what caused it and how to fix it:\n\n{crash_text[:2000]}'}]
        }).encode()
        req = urllib.request.Request(
            'https://api.groq.com/openai/v1/chat/completions',
            data=payload,
            headers={"Content-Type":"application/json","Authorization":f"Bearer {api_key}","User-Agent":UA},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=30) as r:
            d = json.loads(r.read())
            analysis = d['choices'][0]['message']['content']
        sp.stop()
        print(f"\n  {c(CYN+B,'═ AI Analysis ══════════════════════════════')}")
        for line in analysis.split('\n'): print(f"  {line}")
        print(f"  {c(CYN+B,'══════════════════════════════════════════════')}\n")
    except Exception as e:
        sp.stop(); err(f"AI failed: {e}")

def cmd_battery(args):
    """Battery stats and health."""
    serial = getattr(args,'serial',None)
    section('Battery Stats'); print()
    out, _, _ = adb_cmd(['shell','dumpsys','battery'], serial=serial)
    if not out: err("Cannot get battery info"); print(); return
    fields = {
        'AC powered':   GRN, 'USB powered': YLW, 'Wireless powered': CYN,
        'Max charging voltage': WHT, 'Max charging current': WHT,
        'status': YLW, 'health': GRN, 'present': DIM,
        'level': YLW, 'scale': DIM, 'voltage': CYN,
        'temperature': RED, 'technology': DIM,
    }
    for line in out.split('\n'):
        for field, col in fields.items():
            if field in line.lower():
                parts = line.split(':',1)
                if len(parts)==2:
                    key, val = parts
                    val = val.strip()
                    # Color battery level
                    if 'level' in key.lower():
                        try:
                            pct = int(val)
                            col = GRN if pct>50 else YLW if pct>20 else RED
                        except: pass
                    # Color temperature
                    if 'temperature' in key.lower():
                        try:
                            temp = int(val)/10
                            val = f"{temp}°C"
                            col = RED if temp>45 else YLW if temp>35 else GRN
                        except: pass
                    print(f"  {c(B,key.strip()+':'):<28} {c(col, val)}")
    print()

def cmd_memory(args):
    """Memory stats."""
    serial = getattr(args,'serial',None)
    section('Memory Stats'); print()
    out, _, _ = adb_cmd(['shell','cat','/proc/meminfo'], serial=serial)
    if not out: err("Cannot read meminfo"); print(); return
    important = ['MemTotal','MemFree','MemAvailable','Buffers','Cached','SwapTotal','SwapFree']
    for line in out.split('\n'):
        for field in important:
            if line.startswith(field+':'):
                parts = line.split()
                kb = int(parts[1]) if len(parts)>1 else 0
                mb = kb // 1024
                col = GRN if 'Free' in field or 'Available' in field else YLW if 'Swap' in field else WHT
                print(f"  {c(B,field+':'):<20} {c(col, str(mb)+'MB')} {c(DIM,f'({kb:,}KB)')}")
    print()
    # Top processes by memory
    out2, _, _ = adb_cmd(['shell','ps','-A','--sort','rss','-o','pid,rss,name'], serial=serial)
    if out2:
        lines = [l for l in out2.split('\n') if l.strip()]
        print(f"  {c(B,'Top processes by RSS:')}")
        for line in reversed(lines[-15:]):
            parts = line.split()
            if len(parts)>=3:
                try: rss_mb=int(parts[1])//1024; col=RED if rss_mb>200 else YLW if rss_mb>100 else DIM
                except: rss_mb=0; col=DIM
                if rss_mb > 10:
                    print(f"  {c(DIM,parts[0]):<8} {c(col,str(rss_mb)+'MB'):<10} {c(WHT,' '.join(parts[2:])[:40])}")
    print()
