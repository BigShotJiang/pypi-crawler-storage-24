"""Frida/Objection helper for app analysis."""
import os, re, json
import urllib.request
from .utils import *

def _check_frida():
    _, _, code = run(['frida','--version'])
    return code == 0

def _frida_server_running(serial=None):
    out, _, _ = adb_cmd(['shell','ps','|','grep','frida'], serial=serial)
    return 'frida-server' in out

def cmd_frida_setup(args):
    """Download and push frida-server to device."""
    section('Frida Server Setup'); print()
    serial = getattr(args,'serial',None)
    # Get device arch
    arch_out, _, _ = adb_cmd(['shell','getprop','ro.product.cpu.abi'], serial=serial)
    arch = arch_out.strip()
    arch_map = {
        'arm64-v8a': 'arm64',
        'armeabi-v7a': 'arm',
        'x86': 'x86',
        'x86_64': 'x86_64',
    }
    frida_arch = arch_map.get(arch, 'arm64')
    info(f"Device arch: {c(CYN, arch)} → frida arch: {c(YLW, frida_arch)}")

    # Check if frida-tools installed
    if not _check_frida():
        warn("frida-tools not installed on host")
        info("Install: pip install frida-tools objection")
        print()

    # Get latest version
    sp = Spinner('Getting latest Frida version...')
    sp.start()
    try:
        req = urllib.request.Request(
            'https://api.github.com/repos/frida/frida/releases/latest',
            headers={'User-Agent':'luckyboot'}
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
            version = data['tag_name']
        sp.stop()
        ok(f"Latest version: {c(GRN, version)}")
    except Exception as e:
        sp.stop()
        version = getattr(args,'version',None) or '16.2.1'
        warn(f"Could not check version, using {version}")

    server_name = f"frida-server-{version}-android-{frida_arch}"
    dl_url = f"https://github.com/frida/frida/releases/download/{version}/{server_name}.xz"
    print()
    info(f"Download URL: {c(DIM, dl_url)}")
    info(f"Commands to run:\n")
    print(f"  {c(CYN, f'# Download frida-server')}")
    print(f"  {c(CYN, f'curl -L {dl_url} -o frida-server.xz')}")
    print(f"  {c(CYN, f'xz -d frida-server.xz')}")
    print(f"  {c(CYN, f'mv frida-server {server_name}')}")
    print(f"  {c(CYN, f'adb push {server_name} /data/local/tmp/frida-server')}")
    print(f"  {c(CYN, f'adb shell chmod 755 /data/local/tmp/frida-server')}")
    print()
    print(f"  {c(B,'Then start server:')}")
    print(f"  {c(CYN, 'adb shell su -c \"/data/local/tmp/frida-server &\"')}")
    print()
    print(f"  {c(B,'Verify:')}")
    print(f"  {c(CYN, 'frida-ps -U')}")
    print()

    if getattr(args,'auto',False):
        # Actually do it
        _auto_frida_push(serial, server_name, version, frida_arch, dl_url)

def _auto_frida_push(serial, server_name, version, arch, url):
    info("Auto-downloading and pushing...")
    sp = Spinner('Downloading frida-server...')
    sp.start()
    import subprocess
    result = subprocess.run(['curl','-L',url,'-o','frida-server.xz'], capture_output=True)
    sp.stop()
    if result.returncode != 0:
        err("Download failed"); return
    os.system('xz -d frida-server.xz 2>/dev/null || unxz frida-server.xz')
    if not os.path.exists('frida-server'):
        err("Decompress failed"); return
    sp2 = Spinner('Pushing to device...')
    sp2.start()
    _, _, code = adb_cmd(['push','frida-server','/data/local/tmp/frida-server'], serial=serial)
    sp2.stop()
    if code == 0:
        adb_cmd(['shell','chmod','755','/data/local/tmp/frida-server'], serial=serial)
        ok("frida-server pushed!")
        info(f"Start it: {c(CYN,'adb shell su -c \"/data/local/tmp/frida-server &\"')}")
    else:
        err("Push failed")
    os.remove('frida-server.xz') if os.path.exists('frida-server.xz') else None

def cmd_frida_start(args):
    """Start frida-server on device."""
    serial = getattr(args,'serial',None)
    section('Start Frida Server'); print()
    if _frida_server_running(serial):
        ok("frida-server already running"); print(); return
    _, _, code = adb_cmd(['shell','su','-c','"/data/local/tmp/frida-server &"'], serial=serial)
    import time; time.sleep(1)
    if _frida_server_running(serial):
        ok(c(GRN+B,"frida-server started!"))
        info(f"List processes: {c(CYN,'frida-ps -U')}")
        info(f"Attach to app:  {c(CYN,'frida -U -n com.package.name')}")
    else:
        err("Could not start frida-server")
        warn("Is device rooted? Is frida-server at /data/local/tmp/frida-server?")
        info(f"Setup first: {c(CYN,'luckyboot frida-setup')}")
    print()

def cmd_frida_ps(args):
    """List running processes via frida."""
    serial = getattr(args,'serial',None)
    section('Running Processes (Frida)'); print()
    if not _check_frida():
        err("frida not installed — pip install frida-tools"); print(); return
    flag = ['-D', serial] if serial else ['-U']
    out, err_s, code = run(['frida-ps'] + flag)
    if code != 0: err(f"frida-ps failed: {err_s[:100]}"); print(); return
    for line in out.split('\n'):
        parts = line.split(None,1)
        if len(parts)==2:
            pid, name = parts
            col = CYN if any(x in name.lower() for x in ['com.','org.','net.']) else DIM
            print(f"  {c(DIM,pid):<8} {c(col,name)}")
    print()

def cmd_objection(args):
    """Objection quick reference and launcher."""
    section('Objection — App Runtime Exploration'); print()
    package = getattr(args,'package',None)
    serial  = getattr(args,'serial',None)
    if not __import__('shutil').which('objection'):
        err("objection not installed")
        info("Install: pip install objection")
        print(); return
    if package:
        info(f"Launching objection on: {c(CYN, package)}")
        cmd = ['objection', '-g', package, 'explore']
        if serial: cmd = ['objection', '--device', serial, '-g', package, 'explore']
        import os as _os
        _os.execvp('objection', cmd)
    else:
        print(f"  {c(B,'Common objection commands:')}\n")
        cmds = [
            ('android sslpinning disable',         'Bypass SSL pinning'),
            ('android root disable',               'Bypass root detection'),
            ('android hooking list classes',       'List all classes'),
            ('android hooking list activities',    'List activities'),
            ('android hooking watch class com.x.Y','Hook all methods in class'),
            ('android clipboard monitor',          'Monitor clipboard'),
            ('android intent launch_activity',     'Launch activity'),
            ('android ui screenshot',              'Screenshot'),
            ('env',                                'Show app directories'),
            ('file download /data/data/com.x/...',  'Download file'),
            ('memory dump all dump.bin',           'Dump memory'),
        ]
        for cmd_s, desc in cmds:
            print(f"  {c(CYN, cmd_s):<45} {c(DIM, desc)}")
        print(f"\n  {c(B,'Launch:')}")
        print(f"  {c(CYN,'luckyboot objection --package com.target.app')}\n")
