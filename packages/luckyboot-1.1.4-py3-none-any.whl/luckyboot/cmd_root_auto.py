"""
luckyboot root - THE one command to root your phone.
Fully automatic: finds firmware, extracts boot.img, patches with Magisk, flashes.
"""
import os, re, json, time, zipfile, glob, shutil, platform
import urllib.request
from .utils import *
from .cmd_flash import (cmd_flash_boot, _wait_for_adb,
                         _require_adb, _download_file, _confirm)

MAGISK_RELEASES = "https://api.github.com/repos/topjohnwu/Magisk/releases/latest"

# ── Device snapshot ───────────────────────────────────────────────────────────

def _device_snapshot(serial=None):
    def gp(key):
        if is_termux():
            return get_prop(key)
        out, _, _ = adb_shell("getprop " + key, serial=serial)
        return out.strip() if out else ""
    d = {}
    d["model"]       = gp("ro.product.model")
    d["brand"]       = gp("ro.product.brand")
    d["device"]      = gp("ro.product.device")
    d["android"]     = gp("ro.build.version.release")
    d["sdk"]         = gp("ro.build.version.sdk")
    d["build"]       = gp("ro.build.display.id")
    d["arch"]        = gp("ro.product.cpu.abi")
    d["board"]       = gp("ro.product.board")
    d["bl_locked"]   = gp("ro.boot.flash.locked") or gp("ro.secureboot.lockstate")
    d["ab_device"]   = bool(gp("ro.boot.slot_suffix"))
    d["slot"]        = gp("ro.boot.slot_suffix")
    kinfo, _, _ = adb_shell("cat /proc/version", serial=serial)
    if kinfo:
        m = re.search(r"Linux version ([\d.]+)", kinfo)
        d["kernel"] = m.group(1) if m else ""
    else:
        d["kernel"] = ""
    return d

def _is_rooted(serial=None):
    o, _, c = adb_shell("su -c id", serial=serial)
    return c == 0 and "uid=0" in o

def _bl_is_unlocked(d):
    bl = d.get("bl_locked", "")
    if bl in ("0", "unlocked", "false"): return True
    if bl in ("1", "locked", "true"):    return False
    return None

def _print_device(d):
    brand = d.get("brand", "?"); model = d.get("model", "?")
    android = d.get("android", "?"); sdk = d.get("sdk", "?")
    kernel = d.get("kernel", "?"); arch = d.get("arch", "?")
    bl = d.get("bl_locked", "?")
    bl_map = {"0":"UNLOCKED","unlocked":"UNLOCKED","false":"UNLOCKED",
              "1":"LOCKED","locked":"LOCKED","true":"LOCKED"}
    bl_str = bl_map.get(bl, bl or "unknown")
    bl_col = GRN if _bl_is_unlocked(d) else RED if _bl_is_unlocked(d) == False else YLW
    slot_str = "yes (slot " + d.get("slot","?") + ")" if d.get("ab_device") else "no"
    print(f"  {c(B,'Device:    '):<18} {c(GRN+B, brand+' '+model)}")
    print(f"  {c(B,'Android:   '):<18} {c(WHT, android)} (SDK {sdk})")
    print(f"  {c(B,'Kernel:    '):<18} {c(CYN, kernel)}")
    print(f"  {c(B,'Arch:      '):<18} {c(YLW, arch)}")
    print(f"  {c(B,'A/B slots: '):<18} {c(GRN,slot_str) if d.get('ab_device') else c(DIM,slot_str)}")
    print(f"  {c(B,'Bootloader:'):<18} {c(bl_col, bl_str)}")

# ── Firmware search ───────────────────────────────────────────────────────────

def _search_firmware_zips():
    """Search common locations for firmware zip files."""
    candidates = []
    home = os.path.expanduser("~")
    search_dirs = [
        os.path.join(home, "Downloads"),
        os.path.join(home, "Desktop"),
        home,
        os.getcwd(),
    ]
    # Also check Windows-style paths
    if platform.system() == "Windows":
        for drive in ["C:", "D:"]:
            for user_dir in glob.glob(f"{drive}\\Users\\*"):
                search_dirs.append(os.path.join(user_dir, "Downloads"))
                search_dirs.append(os.path.join(user_dir, "Desktop"))

    keywords = ["firmware","rom","stock","flash","spd","ulefone","samsung",
                "pixel","xiaomi","oneplus","motorola","update","ota"]

    for d in search_dirs:
        if not os.path.isdir(d):
            continue
        for f in os.listdir(d):
            fl = f.lower()
            if f.endswith(".zip") and any(k in fl for k in keywords):
                full = os.path.join(d, f)
                sz = os.path.getsize(full)
                if sz > 50 * 1024 * 1024:  # >50MB = likely firmware
                    candidates.append((full, sz))

    candidates.sort(key=lambda x: x[1], reverse=True)  # biggest first
    return [c[0] for c in candidates]

def _extract_boot_from_zip(zip_path, out_dir):
    """Try to extract boot.img from a zip. Handles standard and SPD formats."""
    info(f"Scanning: {os.path.basename(zip_path)}")
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            names = zf.namelist()
            # Direct boot.img
            for n in names:
                if n.lower().endswith("boot.img") and "magisk" not in n.lower():
                    out = os.path.join(out_dir, "boot.img")
                    info(f"Found boot.img: {n}")
                    with zf.open(n) as src, open(out, 'wb') as dst:
                        shutil.copyfileobj(src, dst)
                    return out
            # SPD PAC file inside zip
            for n in names:
                if n.lower().endswith(".pac"):
                    pac_out = os.path.join(out_dir, os.path.basename(n))
                    info(f"Found PAC file: {n} — extracting...")
                    with zf.open(n) as src, open(pac_out, 'wb') as dst:
                        shutil.copyfileobj(src, dst)
                    result = _extract_boot_from_pac(pac_out, out_dir)
                    if result:
                        return result
            # Nested zip
            for n in names:
                if n.lower().endswith(".zip"):
                    nested = os.path.join(out_dir, os.path.basename(n))
                    with zf.open(n) as src, open(nested, 'wb') as dst:
                        shutil.copyfileobj(src, dst)
                    result = _extract_boot_from_zip(nested, out_dir)
                    if result:
                        return result
    except Exception as e:
        warn(f"Zip error: {e}")
    return None

def _extract_boot_from_pac(pac_path, out_dir):
    """Extract boot.img from Spreadtrum/Unisoc PAC firmware file."""
    info("Parsing PAC file structure...")
    try:
        with open(pac_path, 'rb') as f:
            # PAC header: magic at offset 0, file list follows
            data = f.read(4096)
            # Check PAC magic
            if data[:4] not in (b'\x88\x88\x88\x88', b'PACS'):
                # Try reading partition table embedded in PAC
                pass

            f.seek(0)
            raw = f.read()

        # PAC format: each partition entry has name + offset + size
        # Search for "boot" partition by scanning for the string
        boot_offsets = []
        search_terms = [b'b\x00o\x00o\x00t\x00', b'boot\x00', b'BOOT']
        for term in search_terms:
            pos = 0
            while True:
                idx = raw.find(term, pos)
                if idx == -1:
                    break
                boot_offsets.append(idx)
                pos = idx + 1

        if boot_offsets:
            # Try to find the actual partition data near each offset
            for offset in boot_offsets[:5]:
                # Read surrounding area to find size/offset fields
                # PAC stores: name(256 bytes) + file_id(4) + offset(4) + size(4)
                # Try various struct layouts
                for struct_offset in range(max(0, offset-512), offset+512, 4):
                    try:
                        import struct
                        chunk = raw[struct_offset:struct_offset+16]
                        if len(chunk) < 16:
                            continue
                        # Try little-endian uint32 for offset and size
                        _, data_offset, data_size = struct.unpack_from('<III', chunk, 4)
                        if (50*1024*1024 < data_size < 200*1024*1024 and
                                data_offset > 0 and data_offset + data_size < len(raw)):
                            candidate = raw[data_offset:data_offset+data_size]
                            # Check for Android boot magic
                            if candidate[:8] == b'ANDROID!':
                                out = os.path.join(out_dir, "boot.img")
                                open(out, 'wb').write(candidate)
                                ok("Extracted boot.img from PAC!")
                                return out
                    except:
                        continue

        # Fallback: scan raw bytes for Android boot magic
        info("Scanning PAC for Android boot magic...")
        MAGIC = b'ANDROID!'
        pos = 0
        while True:
            idx = raw.find(MAGIC, pos)
            if idx == -1:
                break
            # Read boot image header to get size
            try:
                import struct
                # Android boot header: magic(8) + kernel_size(4) + ... + page_size(4)
                page_size = struct.unpack_from('<I', raw, idx+36)[0]
                kernel_size = struct.unpack_from('<I', raw, idx+8)[0]
                ramdisk_size = struct.unpack_from('<I', raw, idx+16)[0]
                second_size = struct.unpack_from('<I', raw, idx+24)[0]
                if 2048 <= page_size <= 65536 and kernel_size > 0:
                    def pages(n): return (n + page_size - 1) // page_size
                    total = page_size * (1 + pages(kernel_size) + pages(ramdisk_size) + pages(second_size))
                    if 1*1024*1024 < total < 150*1024*1024:
                        out = os.path.join(out_dir, "boot.img")
                        open(out, 'wb').write(raw[idx:idx+total])
                        ok(f"Extracted boot.img from PAC (offset {idx}, size {total//1024}KB)")
                        return out
            except:
                pass
            pos = idx + 1

    except Exception as e:
        warn(f"PAC parse error: {e}")
    return None

# ── Magisk patching via ADB (no root needed) ──────────────────────────────────

def _get_magisk_apk(serial=None):
    """Find or download Magisk APK."""
    # Check if already on device
    check, _, _ = adb_shell("ls /data/local/tmp/Magisk*.apk 2>/dev/null || ls /sdcard/Download/Magisk*.apk 2>/dev/null", serial=serial)
    if check.strip():
        return check.strip().split()[0], True  # path on device, already_there

    # Check local Downloads
    home = os.path.expanduser("~")
    for d in [os.path.join(home, "Downloads"), home, os.getcwd()]:
        for f in glob.glob(os.path.join(d, "Magisk*.apk")) + glob.glob(os.path.join(d, "app-debug.apk")):
            return f, False

    return None, False

def _patch_boot_with_magisk(boot_img_path, serial=None, arch="armeabi-v7a"):
    """Patch boot.img using magiskboot extracted from Magisk APK. No root needed."""
    info("Patching boot.img with Magisk...")

    # Determine magiskboot lib name based on arch
    arch_map = {
        "arm64-v8a":   "lib/arm64-v8a/libmagiskboot.so",
        "armeabi-v7a": "lib/armeabi-v7a/libmagiskboot.so",
        "x86":         "lib/x86/libmagiskboot.so",
        "x86_64":      "lib/x86_64/libmagiskboot.so",
    }
    lib_path = arch_map.get(arch, "lib/armeabi-v7a/libmagiskboot.so")

    # Find Magisk APK locally
    magisk_apk = None
    home = os.path.expanduser("~")
    for d in [os.path.join(home, "Downloads"), home, os.getcwd()]:
        for f in (glob.glob(os.path.join(d, "Magisk*.apk")) +
                  glob.glob(os.path.join(d, "app-debug.apk"))):
            magisk_apk = f
            break
        if magisk_apk:
            break

    if not magisk_apk:
        # Download it
        info("Downloading Magisk APK...")
        try:
            req = urllib.request.Request(MAGISK_RELEASES, headers={"User-Agent":"luckyboot"})
            with urllib.request.urlopen(req, timeout=15) as r:
                data = json.loads(r.read())
            for asset in data.get("assets", []):
                if asset["name"].endswith(".apk"):
                    magisk_apk = asset["name"]
                    _download_file(asset["browser_download_url"], magisk_apk)
                    break
        except:
            magisk_apk = "Magisk.apk"
            _download_file("https://github.com/topjohnwu/Magisk/releases/latest/download/Magisk.apk", magisk_apk)

    if not magisk_apk or not os.path.exists(magisk_apk):
        err("Cannot find Magisk APK")
        return None

    ok(f"Using Magisk APK: {os.path.basename(magisk_apk)}")

    # Push files to device
    tmp = "/data/local/tmp"
    boot_remote = tmp + "/boot.img"
    magisk_remote = tmp + "/Magisk.apk"

    step(1, 4, "Pushing boot.img to device...")
    _, _, rc = adb_cmd(["push", boot_img_path, boot_remote], serial=serial)
    if rc != 0:
        err("Failed to push boot.img"); return None

    step(2, 4, "Pushing Magisk APK to device...")
    _, _, rc = adb_cmd(["push", magisk_apk, magisk_remote], serial=serial)
    if rc != 0:
        err("Failed to push Magisk APK"); return None

    step(3, 4, "Extracting magiskboot and patching...")
    patch_cmd = (
        f"cd {tmp} && "
        f"unzip -o Magisk.apk '{lib_path}' -d . 2>/dev/null && "
        f"mv '{lib_path}' magiskboot && "
        f"chmod 755 magiskboot && "
        f"KEEPVERITY=true KEEPFORCEENCRYPT=true ./magiskboot patch boot.img && "
        f"echo PATCH_OK"
    )
    out, _, rc = adb_shell(patch_cmd, serial=serial)
    if "PATCH_OK" not in out:
        err(f"magiskboot patch failed: {out[:200]}")
        return None

    step(4, 4, "Pulling patched boot.img...")
    patched_remote = tmp + "/new-boot.img"
    patched_local = "magisk_patched_luckyboot.img"
    _, _, rc = adb_cmd(["pull", patched_remote, patched_local], serial=serial)
    if rc != 0:
        err("Failed to pull patched image"); return None

    ok(f"Patched image ready: {patched_local}")
    return patched_local

# ── Main cmd_root ─────────────────────────────────────────────────────────────

def cmd_root(args):
    """THE one-shot root command. Does everything automatically."""
    section("luckyboot root - Auto Root"); print()

    serial   = getattr(args, "serial", None)
    boot_img = getattr(args, "boot", None)
    force    = getattr(args, "force", False)

    # ── Analyze device ────────────────────────────────────────────────────────
    sp = Spinner("Analyzing device..."); sp.start()
    d = _device_snapshot(serial=serial)
    already_rooted = _is_rooted(serial=serial)
    sp.stop()

    _print_device(d); print()

    if already_rooted and not force:
        ok(c(GRN+B, "Device is already rooted!"))
        info("To re-root: luckyboot root --force")
        return

    if not _require_adb(serial):
        err("No ADB device connected. Connect your phone and enable USB debugging.")
        return

    bl_unlocked = _bl_is_unlocked(d)
    arch = d.get("arch", "armeabi-v7a")

    sdklbl = "ADB connected:"; bllbl = "Bootloader:"; btlbl = "boot.img:"
    print(f"  {c(B,sdklbl):<24} {c(GRN,'yes')}")
    print(f"  {c(B,bllbl):<24} {c(GRN,'UNLOCKED') if bl_unlocked else c(RED,'LOCKED') if bl_unlocked==False else c(YLW,'unknown')}")
    print(f"  {c(B,btlbl):<24} {c(GRN,boot_img) if boot_img else c(YLW,'auto-detect')}")
    print()

    if bl_unlocked == False:
        err("Bootloader is LOCKED")
        info("Unlock with: luckyboot bl-unlock")
        info("Warning: this will wipe your data!")
        print()
        if _confirm("Unlock bootloader now?"):
            _do_bl_unlock(d, serial, d.get("brand","").lower())
        return

    # ── Find or use boot.img ─────────────────────────────────────────────────
    work_dir = os.path.join(os.path.expanduser("~"), ".luckyboot_work")
    os.makedirs(work_dir, exist_ok=True)

    if boot_img and os.path.exists(os.path.expanduser(boot_img)):
        boot_path = os.path.expanduser(boot_img)
        info(f"Using provided boot.img: {boot_path}")
    else:
        # Auto-find firmware
        info("Searching for firmware on your PC..."); print()
        zips = _search_firmware_zips()
        if not zips:
            warn("No firmware zip found locally")
            print()
            info("Trying to download the correct firmware automatically...")
            print()
            fw_zip = _auto_download_firmware(d, work_dir)
            if fw_zip:
                zips = [fw_zip]
            else:
                err("Could not find or download firmware automatically")
                print()
                _guide_get_boot_img(d)
                info("Or provide directly: luckyboot root --boot boot.img")
                return

        boot_path = None
        for z in zips:
            sz_mb = os.path.getsize(z) // (1024*1024)
            info(f"Trying: {os.path.basename(z)} ({sz_mb}MB)")
            boot_path = _extract_boot_from_zip(z, work_dir)
            if boot_path:
                ok(f"boot.img extracted from {os.path.basename(z)}")
                break

        if not boot_path:
            warn("Could not extract boot.img from local firmware zips")
            print()
            info("Trying to download the correct firmware automatically...")
            print()
            fw_zip = _auto_download_firmware(d, work_dir)
            if fw_zip:
                boot_path = _extract_boot_from_zip(fw_zip, work_dir)
            if not boot_path:
                err("Could not get boot.img automatically")
                print()
                _guide_get_boot_img(d)
                info("Or extract boot.img manually and run: luckyboot root --boot boot.img")
                return

    # ── Patch with Magisk ────────────────────────────────────────────────────
    print()
    section("Patching with Magisk"); print()

    patched = _patch_boot_with_magisk(boot_path, serial=serial, arch=arch)
    if not patched:
        err("Magisk patching failed")
        print()
        info("Manual fallback:")
        info("1. Open Magisk app on phone")
        info("2. Install -> Select and Patch a File -> choose boot.img")
        plbl = "adb pull /sdcard/Download/magisk_patched*.img ."
        rlbl = "luckyboot root --boot magisk_patched_XXXX.img"
        info(f"3. {c(CYN,plbl)}")
        info(f"4. {c(CYN,rlbl)}")
        return

    # ── Flash ────────────────────────────────────────────────────────────────
    print()
    section("Flashing patched boot"); print()

    from argparse import Namespace
    flash_args = Namespace(
        image=patched, serial=serial, slot=None,
        yes=True, no_reboot=False, no_verify=False
    )
    cmd_flash_boot(flash_args)

    info("Waiting for device to reboot...")
    time.sleep(5)
    if _wait_for_adb(serial, 120):
        time.sleep(5)
        if _is_rooted(serial=serial):
            print()
            ok(c(GRN+B, "ROOT SUCCESSFUL!"))
            ok("Magisk is installed and working")
            info("Open Magisk app to manage root permissions")
        else:
            print()
            warn("Device rebooted but root not detected yet")
            info("Open Magisk app - it may need to finish setup")
            info("If bootloop: hold Volume Down + Power to enter recovery")
    print()

def _do_bl_unlock(d, serial, brand):
    from .cmd_flash import (
        _unlock_pixel, _unlock_xiaomi, _unlock_samsung,
        _unlock_oneplus, _unlock_motorola, _unlock_huawei, _unlock_generic
    )
    if "pixel" in brand or "google" in brand: _unlock_pixel(serial)
    elif any(x in brand for x in ("xiaomi","redmi","poco")): _unlock_xiaomi(serial, brand)
    elif "samsung" in brand: _unlock_samsung(serial)
    elif "oneplus" in brand: _unlock_oneplus(serial)
    elif "motorola" in brand or "moto" in brand: _unlock_motorola(serial)
    elif "huawei" in brand or "honor" in brand: _unlock_huawei(serial)
    else: _unlock_generic(serial)

def _guide_get_boot_img(d):
    build = d.get("build","?"); device = d.get("device","?"); brand = d.get("brand","?")
    print(f"  {c(B,'Where to get firmware/boot.img for:')} {c(CYN,build)}"); print()
    info(f"1. {c(GRN,'firmware.mobi')} - search {c(CYN,build)}")
    info(f"2. {c(GRN,'xdaforums.com')} - search {c(CYN,device+' stock firmware')}")
    info(f"3. {c(GRN,'Official brand site')} - firmware/support section")
    if "samsung" in brand.lower():
        info(f"4. {c(GRN,'SamFirm / Frija')} - for Samsung firmware")
    if "google" in brand.lower() or "pixel" in brand.lower():
        info(f"4. {c(GRN,'developers.google.com/android/images')}")
    print()
    info("Download full firmware zip (100MB+), then re-run: luckyboot root")


# ── Auto firmware download ────────────────────────────────────────────────────

FIRMWARE_SOURCES = [
    # (name, url_template, search_type)
    ("Ulefone official", "https://www.ulefone.com/pages/support", "scrape"),
    ("firmware.mobi", "https://firmware.mobi/search?q={query}", "scrape"),
]

def _auto_download_firmware(d, work_dir):
    """Try to automatically find and download the correct firmware."""
    build = d.get("build", "")
    brand = d.get("brand", "").lower()
    model = d.get("model", "")
    device = d.get("device", "")

    info(f"Searching firmware for: {c(CYN, build)}")

    # Build search queries
    queries = [build, f"{model} firmware", f"{device} stock firmware"]

    # Try brand-specific sources first
    if "ulefone" in brand:
        url = _find_ulefone_firmware(build, model)
        if url:
            fname = os.path.join(work_dir, "firmware.zip")
            info(f"Downloading from Ulefone: {os.path.basename(url)}")
            if _download_file_progress(url, fname):
                return fname

    # Try firmware.mobi
    for query in queries:
        url = _search_firmware_mobi(query)
        if url:
            fname = os.path.join(work_dir, "firmware.zip")
            info(f"Downloading: {url[:80]}")
            if _download_file_progress(url, fname):
                return fname

    return None

def _find_ulefone_firmware(build, model):
    """Search Ulefone support page for firmware download link."""
    try:
        import re as _re
        # Try direct firmware page
        model_slug = model.lower().replace(" ", "-")
        urls_to_try = [
            f"https://www.ulefone.com/pages/{model_slug}",
            f"https://www.ulefone.com/pages/support",
        ]
        for url in urls_to_try:
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=15) as r:
                    html = r.read().decode("utf-8", errors="ignore")
                # Look for firmware download links
                # Pattern: links to zip files containing build identifier
                build_parts = build.replace(" ", "_").split("_")
                for part in build_parts:
                    if len(part) < 3:
                        continue
                    pattern = r'https?://[^"\'>\s]+' + re.escape(part) + r'[^"\'>\s]*\.zip'
                    matches = re.findall(pattern, html, re.IGNORECASE)
                    if matches:
                        return matches[0]
                # Generic zip links
                zips = re.findall(r'https?://[^"\'>\s]+\.zip', html)
                firmware_zips = [z for z in zips if any(k in z.lower() for k in
                    ["firmware", "rom", "flash", model.lower().replace(" ",""), model.lower().replace(" ","_")])]
                if firmware_zips:
                    return firmware_zips[0]
            except:
                continue
    except:
        pass
    return None

def _search_firmware_mobi(query):
    """Search firmware.mobi for firmware download."""
    try:
        import urllib.parse
        q = urllib.parse.quote(query)
        url = f"https://firmware.mobi/en/android/search?q={q}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as r:
            html = r.read().decode("utf-8", errors="ignore")
        # Find download links
        links = re.findall(r'href="(/en/android/[^"]+)"', html)
        if links:
            # Get first result page
            detail_url = "https://firmware.mobi" + links[0]
            req2 = urllib.request.Request(detail_url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req2, timeout=15) as r2:
                html2 = r2.read().decode("utf-8", errors="ignore")
            # Find actual download link
            dl = re.findall(r'https?://[^"\'>\s]+\.zip', html2)
            if dl:
                return dl[0]
    except:
        pass
    return None

def _download_file_progress(url, dest):
    """Download with progress bar."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as r:
            total = int(r.headers.get("Content-Length", 0))
            downloaded = 0
            with open(dest, "wb") as f:
                while True:
                    chunk = r.read(65536)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        pct = downloaded / total * 100
                        mb = downloaded / 1024 / 1024
                        tmb = total / 1024 / 1024
                        print(f"\r  {c(CYN,'↓')} {mb:.1f}/{tmb:.1f}MB ({pct:.0f}%)", end="", flush=True)
            print()
        ok(f"Downloaded: {os.path.basename(dest)} ({downloaded//1024//1024}MB)")
        return True
    except Exception as e:
        warn(f"Download failed: {e}")
        return False
