"""
Flash commands: boot.img, recovery, zip, full ROM.
Works from Termux (local) or over ADB (remote device).
"""
import os, re, json, time, subprocess, glob
import urllib.request
from .utils import *

MAGISK_RELEASES = "https://api.github.com/repos/topjohnwu/Magisk/releases/latest"
TWRP_BASE       = "https://dl.twrp.me"

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _fb(args_list, serial=None):
    """Run fastboot command."""
    base = ['fastboot'] + (['-s', serial] if serial else [])
    if isinstance(args_list, str): args_list = args_list.split()
    return run(base + args_list, timeout=120)

def _require_fastboot(serial=None):
    if not has_fastboot():
        err("fastboot not installed")
        if is_termux(): info("Install: pkg install android-tools")
        print(); return False
    out, _, _ = run(['fastboot', 'devices'])
    devs = [l for l in out.strip().split('\n') if l.strip() and 'fastboot' in l]
    if not devs:
        err("No device in fastboot mode")
        info(f"Boot to bootloader: {c(CYN,'adb reboot bootloader')}")
        info("Or: hold Volume Down + Power until bootloader screen")
        print(); return False
    return True

def _require_adb(serial=None):
    if not has_adb():
        err("adb not installed")
        if is_termux(): info("Install: pkg install android-tools")
        print(); return False
    out, _, _ = run(['adb', 'devices'])
    devs = [l for l in out.strip().split('\n')[1:] if 'device' in l and not l.startswith('*')]
    if not devs:
        err("No ADB device connected")
        info("Enable Developer Options → USB Debugging")
        print(); return False
    return True

def _get_current_slot(serial=None):
    """Return 'a', 'b', or None for non-A/B devices."""
    out, _, _ = run(['fastboot'] + (['-s',serial] if serial else []) + ['getvar','current-slot'])
    # fastboot outputs to stderr
    _, err_s, _ = run(['fastboot'] + (['-s',serial] if serial else []) + ['getvar','current-slot'])
    m = re.search(r'current-slot:\s*([ab])', (out+err_s), re.I)
    return m.group(1) if m else None

def _confirm(prompt="Are you sure?"):
    try:
        ans = input(f"  {c(YLW+B, prompt)} [y/N]: ").strip().lower()
        return ans in ('y','yes')
    except (EOFError, KeyboardInterrupt):
        print(); return False

def _wait_for_fastboot(serial=None, timeout=60):
    """Wait until device appears in fastboot."""
    sp = Spinner('Waiting for fastboot mode...')
    sp.start()
    t0 = time.time()
    while time.time()-t0 < timeout:
        out, _, _ = run(['fastboot','devices'])
        if out.strip() and 'fastboot' in out:
            sp.stop(); return True
        time.sleep(1)
    sp.stop(); return False

def _wait_for_adb(serial=None, timeout=90):
    """Wait until device is back in ADB."""
    sp = Spinner('Waiting for device to boot...')
    sp.start()
    t0 = time.time()
    while time.time()-t0 < timeout:
        out, _, _ = run(['adb', 'devices'])
        devs = [l for l in out.strip().split('\n')[1:] if 'device' in l and not l.startswith('*')]
        if devs:
            sp.stop(); return True
        time.sleep(2)
    sp.stop(); return False

# ─────────────────────────────────────────────────────────────────────────────
# Flash boot.img
# ─────────────────────────────────────────────────────────────────────────────

def cmd_flash_boot(args):
    """Flash boot.img (or patched boot) via fastboot."""
    section('Flash Boot Image'); print()
    img     = args.image
    serial  = getattr(args,'serial',None)
    slot    = getattr(args,'slot',None)
    no_verify = getattr(args,'no_verify',False)

    if not os.path.exists(os.path.expanduser(img)):
        err(f"File not found: {img}"); print(); return

    size_mb = os.path.getsize(os.path.expanduser(img)) / (1024*1024)
    info(f"Image: {c(CYN, img)} ({c(YLW, f'{size_mb:.1f}MB')})")
    print()

    # Try to reboot to bootloader if in ADB mode
    out, _, _ = run(['adb','devices'])
    if 'device' in out:
        info("Device in ADB mode — rebooting to bootloader...")
        adb_cmd(['reboot','bootloader'], serial=serial)
        if not _wait_for_fastboot(serial, timeout=45):
            err("Device did not enter fastboot mode"); print(); return

    if not _require_fastboot(serial): return

    # Detect slot
    if not slot:
        slot = _get_current_slot(serial)
    if slot:
        info(f"Current slot: {c(GRN, slot.upper())} → flashing to {c(YLW, 'boot_'+slot)}")
        partition = f'boot_{slot}'
    else:
        info("Non-A/B device → flashing to 'boot'")
        partition = 'boot'

    print()
    warn("This will replace your boot partition!")
    if not getattr(args,'yes',False) and not _confirm("Flash boot image?"):
        print(f"  {c(DIM,'Cancelled')}\n"); return

    sp = Spinner(f'Flashing {partition}...')
    sp.start()
    fb = ['fastboot'] + (['-s',serial] if serial else [])
    if no_verify: fb += ['--disable-verity','--disable-verification']
    out, err_s, code = run(fb + ['flash', partition, os.path.expanduser(img)], timeout=120)
    sp.stop()

    if code == 0 or 'OKAY' in (out+err_s) or 'Finished' in (out+err_s):
        ok(c(GRN+B, f'{partition} flashed!'))
        print()
        if not getattr(args,'no_reboot',False):
            info("Rebooting...")
            run(['fastboot'] + (['-s',serial] if serial else []) + ['reboot'])
            if _wait_for_adb(serial, 90):
                ok("Device booted!")
            else:
                warn("Reboot taking long — check device screen")
    else:
        err(f"Flash failed: {err_s or out}")
    print()

# ─────────────────────────────────────────────────────────────────────────────
# Flash any partition
# ─────────────────────────────────────────────────────────────────────────────

def cmd_flash_img(args):
    """Flash any .img to any partition."""
    section('Flash Image'); print()
    partition = args.partition
    img       = args.image
    serial    = getattr(args,'serial',None)
    slot      = getattr(args,'slot',None)

    if not os.path.exists(os.path.expanduser(img)):
        err(f"Not found: {img}"); print(); return

    size_mb = os.path.getsize(os.path.expanduser(img)) / (1024*1024)
    info(f"Partition: {c(YLW, partition)}")
    info(f"Image:     {c(CYN, img)} ({size_mb:.1f}MB)")
    print()

    out, _, _ = run(['adb','devices'])
    if 'device' in out and partition not in ('data','userdata'):
        info("In ADB mode — rebooting to bootloader...")
        adb_cmd(['reboot','bootloader'], serial=serial)
        if not _wait_for_fastboot(serial): err("fastboot timeout"); print(); return

    if not _require_fastboot(serial): return

    warn(f"Flashing {c(RED+B,partition)} — wrong partition = brick!")
    if not getattr(args,'yes',False) and not _confirm(f"Flash {partition}?"):
        print(f"  {c(DIM,'Cancelled')}\n"); return

    fb = ['fastboot'] + (['-s',serial] if serial else [])
    if slot: fb += ['--slot', slot]
    sp = Spinner(f'Flashing {partition}...')
    sp.start()
    out, err_s, code = run(fb + ['flash', partition, os.path.expanduser(img)], timeout=120)
    sp.stop()

    if code==0 or 'OKAY' in (out+err_s) or 'Finished' in (out+err_s):
        ok(c(GRN+B,f'{partition} flashed!'))
        if not getattr(args,'no_reboot',False) and partition not in ('recovery',):
            run(fb+['reboot'])
    else:
        err(f"Failed: {err_s or out}")
    print()

# ─────────────────────────────────────────────────────────────────────────────
# Flash ZIP via recovery (TWRP)
# ─────────────────────────────────────────────────────────────────────────────

def cmd_flash_zip(args):
    """Push zip to device and flash via TWRP, or sideload."""
    section('Flash ZIP'); print()
    zipfile = args.zipfile
    serial  = getattr(args,'serial',None)
    method  = getattr(args,'method',None) or 'auto'  # auto, twrp, sideload

    if not os.path.exists(os.path.expanduser(zipfile)):
        err(f"Not found: {zipfile}"); print(); return

    size_mb = os.path.getsize(os.path.expanduser(zipfile)) / (1024*1024)
    info(f"ZIP: {c(CYN, os.path.basename(zipfile))} ({size_mb:.1f}MB)")
    print()

    # Check mode
    out, _, _ = run(['adb','devices'])
    in_adb = any('device' in l and not l.startswith('*') for l in out.split('\n')[1:])
    in_recovery = any('recovery' in l for l in out.split('\n')[1:])
    in_sideload = any('sideload' in l for l in out.split('\n')[1:])

    if in_sideload or method == 'sideload':
        _flash_sideload(zipfile, serial)
        return

    if in_recovery or method == 'twrp':
        _flash_twrp(zipfile, serial)
        return

    if in_adb:
        info("Device in ADB mode")
        print(f"\n  {c(B,'How to flash?')}")
        print(f"  {c(CYN+B,'1')} → Reboot to TWRP recovery and flash there")
        print(f"  {c(CYN+B,'2')} → Reboot to sideload mode and use ADB sideload")
        print(f"  {c(CYN+B,'3')} → Push zip to /sdcard and flash manually in TWRP")
        print()
        try:
            choice = input("  Choose [1/2/3]: ").strip()
        except: print(); return

        if choice == '1':
            info("Rebooting to recovery...")
            adb_cmd(['reboot','recovery'], serial=serial)
            info(f"Waiting for TWRP... (then run: {c(CYN,'luckyboot flash-zip '+zipfile+' --method twrp')})")
        elif choice == '2':
            info("Rebooting to sideload...")
            adb_cmd(['reboot','sideload'], serial=serial)
            time.sleep(5)
            _flash_sideload(zipfile, serial)
        elif choice == '3':
            _push_to_sdcard(zipfile, serial)
    else:
        warn("No device found")
        info("Connect device with USB debugging enabled")
    print()

def _flash_sideload(zipfile, serial=None):
    info("Sideloading...")
    if not _wait_for_adb(serial, 30):
        # Check sideload mode specifically
        pass
    sp = Spinner('Sideloading ZIP...')
    sp.start()
    cmd = ['adb'] + (['-s',serial] if serial else []) + ['sideload', os.path.expanduser(zipfile)]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    output = []
    for line in proc.stdout: output.append(line)
    proc.wait()
    sp.stop()
    if proc.returncode == 0 or any('Total xfer' in l for l in output):
        ok("Sideload complete!")
    else:
        err("Sideload failed: " + ''.join(output)[:200])

def _flash_twrp(zipfile, serial=None):
    """Push zip and flash via TWRP."""
    sp = Spinner('Pushing ZIP to /sdcard...')
    sp.start()
    remote = f'/sdcard/{os.path.basename(zipfile)}'
    _, _, code = adb_cmd(['push', os.path.expanduser(zipfile), remote], serial=serial)
    sp.stop()
    if code != 0: err("Push failed"); return
    ok(f"Pushed to {remote}")

    sp2 = Spinner('Flashing via TWRP...')
    sp2.start()
    out, err_s, code = adb_cmd(['shell', f'twrp install {remote}'], serial=serial)
    sp2.stop()
    if code == 0 or 'succeeded' in out.lower():
        ok("TWRP flash complete!")
        if not _confirm("Reboot now?"): return
        adb_cmd(['reboot'], serial=serial)
    else:
        warn("TWRP CLI install failed — try manually in TWRP GUI")
        info(f"ZIP is at: {c(CYN, remote)}")

def _push_to_sdcard(zipfile, serial=None):
    remote = f'/sdcard/{os.path.basename(zipfile)}'
    sp = Spinner('Pushing to /sdcard...')
    sp.start()
    _, _, code = adb_cmd(['push', os.path.expanduser(zipfile), remote], serial=serial)
    sp.stop()
    if code == 0:
        ok(f"ZIP at: {c(CYN, remote)}")
        info("Open TWRP → Install → select the ZIP")
    else:
        err("Push failed")

# ─────────────────────────────────────────────────────────────────────────────
# Magisk patch + flash (all-in-one)
# ─────────────────────────────────────────────────────────────────────────────

def cmd_magisk_patch(args):
    """Download latest Magisk, patch boot.img, flash — all in one."""
    section('Magisk Patch & Flash'); print()
    boot_img = getattr(args,'boot',None)
    serial   = getattr(args,'serial',None)
    apk_only = getattr(args,'apk_only',False)

    # Step 1: Get latest Magisk
    step(1,4,"Getting latest Magisk release")
    sp = Spinner('Checking GitHub releases...')
    sp.start()
    try:
        req = urllib.request.Request(MAGISK_RELEASES, headers={'User-Agent':'luckyboot'})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        version = data['tag_name']
        # Find APK asset
        apk_url = None; apk_name = None
        for asset in data.get('assets',[]):
            if asset['name'].endswith('.apk') and 'canary' not in asset['name'].lower():
                apk_url  = asset['browser_download_url']
                apk_name = asset['name']
                break
        sp.stop()
        ok(f"Magisk {c(GRN+B, version)}: {apk_name}")
    except Exception as e:
        sp.stop()
        warn(f"GitHub check failed: {e}")
        version = 'latest'
        apk_url  = 'https://github.com/topjohnwu/Magisk/releases/latest/download/Magisk.apk'
        apk_name = 'Magisk.apk'

    if apk_only:
        info(f"Download: {c(CYN, apk_url)}")
        _download_file(apk_url, apk_name)
        ok(f"Saved: {apk_name}")
        print(); return

    # Step 2: Download Magisk APK
    print()
    step(2,4,"Downloading Magisk APK")
    if not _download_file(apk_url, apk_name):
        err("Download failed"); print(); return
    ok(f"Downloaded: {apk_name}")

    # Step 3: Patch boot.img
    print()
    step(3,4,"Patching boot.img")
    if not boot_img:
        err("Need --boot boot.img")
        info(f"Get stock boot.img for build: {c(CYN, get_prop('ro.build.display.id'))}")
        info("Sources: firmware.mobi, xdaforums.com, or extract from OTA")
        print()
        # Offer to install APK and patch on device
        if _require_adb(serial):
            info(f"Alternative: install Magisk on device and patch there")
            if _confirm("Install Magisk APK on device?"):
                _, _, code = adb_cmd(['install','-r', apk_name], serial=serial)
                if code==0:
                    ok("Magisk installed on device!")
                    info("Open Magisk → Install → Select and Patch a File → choose boot.img")
                    info(f"Pull back: {c(CYN,'adb pull /sdcard/Download/magisk_patched*.img .')}")
                    info(f"Then run:  {c(CYN,'luckyboot flash-boot magisk_patched*.img')}")
        print(); return

    boot_img = os.path.expanduser(boot_img)
    if not os.path.exists(boot_img):
        err(f"boot.img not found: {boot_img}"); print(); return

    # Try patching locally if Magisk binary available
    magisk_bin, _, _ = run_root('which magisk 2>/dev/null')
    if magisk_bin:
        sp2 = Spinner('Patching locally...')
        sp2.start()
        out, err_s, code = run_root(f'magisk --patch-boot {os.path.abspath(boot_img)}')
        sp2.stop()
        patched_glob = glob.glob('/data/local/tmp/magisk_patched*.img')
        if patched_glob:
            patched = patched_glob[0]
            run(['cp', patched, './magisk_patched.img'], shell=False)
            ok(f"Patched: {c(GRN+B,'./magisk_patched.img')}")
        else:
            warn("Local patch uncertain — try device method")
    else:
        # Push boot.img to device, let Magisk patch there
        info("Patching on device via Magisk app...")
        if not _require_adb(serial): print(); return
        sp2 = Spinner('Installing Magisk APK...')
        sp2.start()
        adb_cmd(['install','-r', apk_name], serial=serial)
        sp2.stop()
        # Push boot img
        adb_cmd(['push', boot_img, '/sdcard/luckyboot_boot.img'], serial=serial)
        ok("Magisk installed, boot.img pushed to /sdcard/")
        warn("You must manually patch in Magisk app:")
        info("Open Magisk → Install → Select file → /sdcard/luckyboot_boot.img")
        info(f"Then: {c(CYN,'adb pull /sdcard/Download/magisk_patched*.img magisk_patched.img')}")
        info(f"Then: {c(CYN,'luckyboot flash-boot magisk_patched.img')}")
        print(); return

    # Step 4: Flash
    print()
    step(4,4,"Flashing patched boot")
    patched_files = glob.glob('./magisk_patched*.img') or ['./magisk_patched.img']
    patched = patched_files[0] if patched_files else None
    if not patched or not os.path.exists(patched):
        err("Patched image not found — flash manually:")
        info(f"  {c(CYN,'luckyboot flash-boot <magisk_patched.img>')}")
        print(); return

    args.image   = patched
    args.yes     = True
    args.no_reboot = False
    cmd_flash_boot(args)

def _download_file(url, dest, timeout=60):
    try:
        req = urllib.request.Request(url, headers={'User-Agent':'luckyboot'})
        sp = Spinner(f'Downloading {os.path.basename(dest)}...')
        sp.start()
        with urllib.request.urlopen(req, timeout=timeout) as r, open(dest,'wb') as f:
            while True:
                chunk = r.read(65536)
                if not chunk: break
                f.write(chunk)
        sp.stop()
        return True
    except Exception as e:
        try: sp.stop()
        except: pass
        err(f"Download error: {e}")
        return False

# ─────────────────────────────────────────────────────────────────────────────
# TWRP installer
# ─────────────────────────────────────────────────────────────────────────────

def cmd_twrp(args):
    """Download and flash TWRP for your device."""
    section('TWRP Installer'); print()
    serial  = getattr(args,'serial',None)
    img     = getattr(args,'image',None)
    codename= getattr(args,'device',None)

    if not codename:
        codename = get_prop('ro.product.device')
        if not codename and _require_adb(serial):
            out,_,_ = adb_cmd(['shell','getprop','ro.product.device'], serial=serial)
            codename = out.strip()

    if img:
        # Direct flash
        info(f"Flashing custom recovery: {img}")
        args.partition = 'recovery'
        args.image     = img
        cmd_flash_img(args)
        return

    info(f"Device codename: {c(GRN+B, codename or '?')}")
    print()
    # Try to get TWRP download
    if codename:
        twrp_url = f"https://dl.twrp.me/{codename}/"
        info(f"TWRP page: {c(CYN, twrp_url)}")
        try:
            req = urllib.request.Request(twrp_url, headers={'User-Agent':'luckyboot'})
            with urllib.request.urlopen(req, timeout=8) as r:
                html = r.read().decode('utf-8','replace')
            # Parse latest .img link
            imgs = re.findall(r'href="(/'+codename+r'/[^"]+\.img[^"]*)"', html)
            if imgs:
                latest = 'https://dl.twrp.me' + imgs[0]
                ok(f"Found TWRP for {codename}")
                info(f"Latest: {c(CYN, latest)}")
                print()
                if _confirm("Download and flash TWRP?"):
                    fname = f"twrp-{codename}.img"
                    if _download_file(latest, fname):
                        ok(f"Downloaded: {fname}")
                        args.partition = 'recovery'
                        args.image = fname
                        cmd_flash_img(args)
                    else:
                        err("Download failed")
            else:
                warn(f"No .img found on TWRP page for {codename}")
                info(f"Check manually: {c(CYN, twrp_url)}")
        except Exception as e:
            warn(f"Could not check TWRP: {e}")
            info(f"Download manually: {c(CYN, f'https://twrp.me/Devices/')}")
    else:
        err("Could not detect device codename")
        info("Use: luckyboot twrp --device <codename> --image twrp.img")
    print()

# ─────────────────────────────────────────────────────────────────────────────
# Bootloader unlock (enhanced, step-by-step)
# ─────────────────────────────────────────────────────────────────────────────

def cmd_bl_unlock(args):
    """Full bootloader unlock flow."""
    section('Bootloader Unlock'); print()
    serial = getattr(args,'serial',None)
    brand  = (getattr(args,'brand',None) or get_prop('ro.product.brand') or '').lower()
    model  = get_prop('ro.product.model')

    info(f"Device: {c(GRN+B, model or '?')} ({c(CYN, brand or '?')})")
    print()
    warn("BOOTLOADER UNLOCK WILL WIPE ALL DATA ON THE DEVICE!")
    warn("Backup contacts, photos, apps before proceeding!")
    print()
    if not _confirm("I have a backup and want to unlock bootloader"):
        print(f"  {c(DIM,'Cancelled')}\n"); return

    print()
    # Brand-specific pre-steps
    if 'xiaomi' in brand or 'redmi' in brand or 'poco' in brand:
        _unlock_xiaomi(serial, brand)
    elif 'samsung' in brand:
        _unlock_samsung(serial)
    elif 'oneplus' in brand:
        _unlock_oneplus(serial)
    elif 'pixel' in brand or 'google' in brand:
        _unlock_pixel(serial)
    elif 'motorola' in brand or 'moto' in brand:
        _unlock_motorola(serial)
    elif 'huawei' in brand or 'honor' in brand:
        _unlock_huawei(serial)
    else:
        _unlock_generic(serial)

def _run_unlock_fastboot(serial=None):
    fb = ['fastboot'] + (['-s',serial] if serial else [])
    print()
    step(99,99,"Sending fastboot unlock commands")
    for cmd in [['flashing','unlock'], ['oem','unlock']]:
        sp = Spinner(f"fastboot {' '.join(cmd)}...")
        sp.start()
        out, err_s, code = run(fb + cmd, timeout=30)
        sp.stop()
        if code==0 or 'OKAY' in (out+err_s):
            ok(c(GRN+B,"Bootloader UNLOCKED!"))
            info("Device will wipe and reboot")
            return True
        else:
            err_msg = (err_s or out)[:100]
            if 'not supported' not in err_msg.lower():
                warn(f"{' '.join(cmd)}: {err_msg}")
    return False

def _unlock_pixel(serial):
    print(f"  {c(B+YLW,'Google Pixel unlock:')}\n")
    step(1,4,"Enable Developer Options")
    info("Settings → About Phone → Build Number (tap 7 times)")
    step(2,4,"Enable OEM Unlocking")
    info("Settings → System → Developer Options → OEM Unlocking → ON")
    step(3,4,"Reboot to bootloader")
    if _require_adb(serial):
        if _confirm("Reboot to bootloader now?"):
            adb_cmd(['reboot','bootloader'], serial=serial)
            _wait_for_fastboot(serial)
    step(4,4,"Unlock")
    _run_unlock_fastboot(serial)

def _unlock_xiaomi(serial, brand):
    print(f"  {c(B+YLW,'Xiaomi / Redmi / POCO unlock:')}\n")
    warn("Xiaomi requires Mi Account verification + waiting period (up to 168h)")
    print()
    step(1,5,"Get MIUI Developer options")
    info("Settings → About Phone → MIUI Version (tap 7 times)")
    step(2,5,"Enable OEM + USB Debugging")
    info("Settings → Additional Settings → Developer Options")
    info("→ Enable USB Debugging + Enable OEM Unlocking (if visible)")
    step(3,5,"Link Mi Account")
    info("Settings → Additional Settings → Developer Options → Mi Unlock Status")
    info("→ Add account and device")
    step(4,5,"Download Mi Unlock Tool")
    info(f"From PC: {c(CYN,'https://en.miui.com/unlock/download_en.html')}")
    info("Login with same Mi Account → click Unlock")
    warn("May show countdown (72h-168h) if account not trusted")
    step(5,5,"After unlock — back to bootloader for root")
    info(f"{c(CYN,'luckyboot root')}")

def _unlock_samsung(serial):
    print(f"  {c(B+YLW,'Samsung unlock:')}\n")
    warn("Samsung: unlocking TRIPS Knox counter PERMANENTLY (0x1)")
    warn("This voids warranty and disables Samsung Pay, Secure Folder, Knox apps")
    print()
    step(1,4,"Enable Developer Options")
    info("Settings → About Phone → Software Information → Build Number (tap 7x)")
    step(2,4,"Enable OEM Unlocking")
    info("Settings → Developer Options → OEM Unlocking")
    warn("If OEM Unlocking is greyed out: insert SIM, wait 7 days after activation")
    step(3,4,"Reboot to Download Mode")
    info("Power off → Hold Volume Down + Up + USB cable (varies by model)")
    info("Press Volume Up to enter Download Mode")
    step(4,4,"Unlock via Odin / TWRP")
    info(f"Use Odin on Windows or: {c(CYN,'heimdall flash --recovery recovery.img')}")
    info(f"Heimdall: {c(CYN,'pkg install heimdall')}")

def _unlock_oneplus(serial):
    print(f"  {c(B+YLW,'OnePlus unlock:')}\n")
    step(1,3,"Enable Developer Options")
    info("Settings → About Device → Build Number (tap 7x)")
    step(2,3,"Enable OEM Unlocking + USB Debugging")
    info("Settings → Developer Options → both toggles ON")
    step(3,3,"fastboot unlock")
    if _require_adb(serial):
        if _confirm("Reboot to bootloader?"):
            adb_cmd(['reboot','bootloader'], serial=serial)
            _wait_for_fastboot(serial)
    _run_unlock_fastboot(serial)

def _unlock_motorola(serial):
    print(f"  {c(B+YLW,'Motorola unlock:')}\n")
    step(1,4,"Enable Developer Options")
    info("Settings → About Phone → Build Number (tap 7x)")
    step(2,4,"Get unlock code from Motorola")
    # Get device identifier
    if _require_fastboot(serial):
        fb = ['fastboot'] + (['-s',serial] if serial else [])
        _, err_s, _ = run(fb+['oem','get_unlock_data'])
        if err_s:
            info(f"Unlock data: {c(YLW, err_s[:200])}")
        info(f"Paste at: {c(CYN,'https://motorola-global-portal.custhelp.com/app/standalone/bootloader/unlock-your-device-b')}")
    step(3,4,"Flash unlock key")
    info("fastboot oem unlock <KEY_FROM_MOTOROLA>")
    step(4,4,"Root now:")
    info(f"{c(CYN,'luckyboot root')}")

def _unlock_huawei(serial):
    print(f"  {c(B+YLW,'Huawei / Honor unlock:')}\n")
    warn("Huawei stopped providing unlock codes in 2018!")
    warn("Modern Huawei devices (after May 2018) cannot be officially unlocked")
    print()
    info("Options for locked Huawei:")
    info(f"1. {c(YLW,'DC-Unlocker')} (paid tool): dc-unlocker.com")
    info(f"2. {c(YLW,'PotatoNV')} (some Kirin): github.com/mashed-potatoes/PotatoNV")
    info(f"3. {c(YLW,'testpoint method')} (advanced, hardware): xdaforums.com")
    info("Search XDA for your specific model")

def _unlock_generic(serial):
    print(f"  {c(B+YLW,'Generic Android unlock:')}\n")
    step(1,4,"Enable Developer Options")
    info("Settings → About Phone → Build Number (tap 7 times)")
    step(2,4,"Enable OEM Unlocking")
    info("Settings → Developer Options → OEM Unlocking → ON")
    step(3,4,"Reboot to bootloader")
    if _require_adb(serial):
        if _confirm("Reboot to bootloader?"):
            adb_cmd(['reboot','bootloader'], serial=serial)
            _wait_for_fastboot(serial)
    step(4,4,"Unlock")
    _run_unlock_fastboot(serial)

# ─────────────────────────────────────────────────────────────────────────────
# Wipe
# ─────────────────────────────────────────────────────────────────────────────

def cmd_wipe(args):
    """Wipe data/cache/dalvik."""
    section('Wipe'); print()
    target = getattr(args,'target',None) or 'cache'
    serial = getattr(args,'serial',None)

    SAFE   = {'cache','dalvik','system-cache'}
    DANGER = {'data','userdata','all'}

    if target in DANGER:
        warn(f"Wiping {c(RED+B,target)} DELETES ALL USER DATA!")
        if not _confirm(f"Really wipe {target}? THIS CANNOT BE UNDONE"):
            print(f"  {c(DIM,'Cancelled')}\n"); return

    fb = ['fastboot'] + (['-s',serial] if serial else [])

    # Try to get to fastboot/recovery
    out, _, _ = run(['adb','devices'])
    if 'device' in out:
        adb_cmd(['reboot','bootloader'], serial=serial)
        _wait_for_fastboot(serial)

    if not _require_fastboot(serial): return

    wipe_map = {
        'cache':       [['erase','cache']],
        'dalvik':      [['erase','dalvik-cache']],
        'data':        [['erase','userdata'],['erase','metadata']],
        'userdata':    [['erase','userdata']],
        'system-cache':[['erase','cache'],['erase','dalvik-cache']],
        'all':         [['erase','userdata'],['erase','cache'],['erase','metadata']],
    }
    cmds = wipe_map.get(target, [[f'erase', target]])
    for cmd_args in cmds:
        sp = Spinner(f"fastboot {' '.join(cmd_args)}...")
        sp.start()
        out, err_s, code = run(fb + cmd_args, timeout=60)
        sp.stop()
        if code==0 or 'OKAY' in (out+err_s):
            ok(f"{cmd_args[1]} wiped")
        else:
            err(f"{' '.join(cmd_args)}: {err_s or out}")

    print()
    if not getattr(args,'no_reboot',False):
        if _confirm("Reboot?"):
            run(fb+['reboot'])
    print()
