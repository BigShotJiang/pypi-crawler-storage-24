"""Shared utilities for luckyboot — single consistent API."""
import subprocess, os, time, threading

R="\033[0m"; B="\033[1m"; DIM="\033[2m"
RED="\033[91m"; GRN="\033[92m"; YLW="\033[93m"
BLU="\033[94m"; MAG="\033[95m"; CYN="\033[96m"; WHT="\033[97m"

def c(col,txt): return f"{col}{txt}{R}"
def section(t): print(f"\n{c(B+CYN,'  '+t)}\n  {c(DIM,chr(8212)*50)}")
def ok(m):   print(f"  {c(GRN+B,'✓')} {m}")
def err(m):  print(f"  {c(RED+B,'✗')} {m}")
def warn(m): print(f"  {c(YLW+B,'!')}{R} {m}")
def info(m): print(f"  {c(BLU,'→')} {m}")
def step(n,t,m): print(f"  {c(CYN+B,f'[{n}/{t}]')} {m}")

def run(cmd, timeout=30, shell=False):
    try:
        if isinstance(cmd,str) and not shell: cmd=cmd.split()
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout,shell=shell)
        return r.stdout.strip(), r.stderr.strip(), r.returncode
    except FileNotFoundError: return '','not found',127
    except subprocess.TimeoutExpired: return '','timeout',-1
    except Exception as e: return '',str(e),-1

def run_root(cmd):
    if isinstance(cmd,list): cmd=' '.join(cmd)
    return run(['su','-c',cmd],timeout=20)

def adb_cmd(args, serial=None):
    base=['adb']+(['-s',serial] if serial else [])
    if isinstance(args,str): args=args.split()
    return run(base+args,timeout=60)

def adb_shell(cmd, serial=None):
    if isinstance(cmd,list): cmd=' '.join(cmd)
    return adb_cmd(['shell',cmd],serial=serial)

def is_termux(): return os.path.exists('/data/data/com.termux')

def has_root():
    o,_,c2=run(['su','-c','id'],timeout=5)
    return c2==0 and 'uid=0' in o

def has_adb():
    _,_,c2=run(['adb','version'])
    return c2==0

def has_fastboot():
    _,_,c2=run(['fastboot','--version'])
    return c2==0

def get_prop(key):
    o,_,_=run(['getprop',key])
    if not o and is_termux():
        o,_,_=run_root(f'getprop {key}')
    return o.strip()

class Spinner:
    def __init__(self,msg=""):
        self.msg=msg;self._stop=False;self._t=None
    def _spin(self):
        f="⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏";i=0
        while not self._stop:
            print(f"\r  {c(CYN,f[i%len(f)])} {c(DIM,self.msg)}",end='',flush=True)
            time.sleep(0.09);i+=1
        print('\r'+' '*(len(self.msg)+6)+'\r',end='',flush=True)
    def start(self): self._t=threading.Thread(target=self._spin,daemon=True);self._t.start()
    def stop(self):
        self._stop=True
        if self._t: self._t.join()
