"""Bootloader & fastboot tools."""
import re
from .utils import *

def cmd_bootloader(args):
    section('Bootloader Info'); print()
    props = {
        'Status':     ('ro.boot.flash.locked','ro.secureboot.lockstate'),
        'Bootloader': ('ro.bootloader',),
        'Verifiedboot':('ro.boot.verifiedbootstate',),
        'DM-Verity': ('ro.boot.veritymode',),
        'Hardware':  ('ro.hardware',),
        'Board':     ('ro.product.board',),
    }
    for label, keys in props.items():
        val = ''
        for k in keys:
            val = get_prop(k)
            if val: break
        if not val: continue
        locked = val in ('1','locked','true','enforcing')
        unlocked = val in ('0','unlocked','false','disabled')
        col = RED if locked else GRN if unlocked else YLW
        print(f"  {c(B, label+':'):<22} {c(col, val)}")
    print()
    # ADB check
    if has_adb():
        serial = getattr(args,'serial',None)
        out, _, _ = adb_cmd(['shell','getprop','ro.boot.flash.locked'], serial=serial)
        if out:
            locked = out.strip() == '1'
            print(f"  {c(B,'Via ADB flash.locked:')} {c(RED,'LOCKED') if locked else c(GRN,'UNLOCKED')}")
        # OEM unlock
        oem, _, _ = adb_cmd(['shell','settings','get','global','development_settings_enabled'], serial=serial)
        print(f"  {c(B,'Dev Settings:  ')} {c(GRN,'enabled') if oem=='1' else c(RED,'disabled')}")
    print()

def cmd_fastboot(args):
    section('Fastboot Mode'); print()
    if not has_fastboot():
        err("fastboot not installed")
        if is_termux(): info("Install: pkg install android-tools")
        print(); return
    out, err_s, code = run(['fastboot','devices'])
    if not out.strip():
        warn("No fastboot devices")
        info("Boot device to bootloader:")
        info(f"  {c(CYN,'adb reboot bootloader')}")
        info("  Or: Volume Down + Power")
        print(); return
    devices = [l for l in out.strip().split('\n') if l.strip() and not l.startswith('*')]
    for line in devices:
        parts = line.split()
        serial = parts[0] if parts else '?'
        mode   = parts[1] if len(parts)>1 else '?'
        print(f"  {c(GRN+B,'[fastboot]')} {c(CYN, serial)} {c(DIM, mode)}")
    print()
    # Get vars
    serial = getattr(args,'serial',None)
    fb_base = ['fastboot'] + (['-s',serial] if serial else [])
    for var in ['product','version-baseband','version-bootloader','current-slot','slot-count','unlocked']:
        out_v, _, _ = run(fb_base+['getvar',var], timeout=5)
        m = re.search(rf'{var}:\s*(.+)', out_v+_)  # fastboot prints to stderr
        if m: print(f"  {c(B,var+':'):<30} {c(YLW, m.group(1).strip())}")
    # Try stderr (fastboot outputs vars to stderr)
    _, err_v, _ = run(fb_base+['getvar','all'], timeout=5)
    if err_v:
        for line in err_v.split('\n')[:20]:
            m = re.match(r'(.+):\s*(.+)', line)
            if m: print(f"  {c(BLU, m.group(1).strip()):<30} {c(WHT, m.group(2).strip())}")
    print()

def cmd_unlock(args):
    section('Unlock Bootloader'); print()
    method = getattr(args,'method',None)
    serial = getattr(args,'serial',None)
    device = get_prop('ro.product.brand').lower()

    warn("UNLOCKING BOOTLOADER WILL WIPE YOUR DEVICE!")
    warn("BACKUP EVERYTHING BEFORE PROCEEDING!")
    print()

    if not getattr(args,'yes',False):
        try:
            confirm = input(f"  {c(RED+B,'Type UNLOCK to confirm')}: ").strip()
        except (EOFError,KeyboardInterrupt):
            print(); return
        if confirm != 'UNLOCK':
            err("Cancelled"); print(); return

    if not has_fastboot():
        err("fastboot not found"); print(); return

    fb = ['fastboot'] + (['-s',serial] if serial else [])
    info("Attempting bootloader unlock...")
    sp = Spinner('Sending unlock command...')
    sp.start()
    # Try modern method first
    out, err_s, code = run(fb+['flashing','unlock'])
    sp.stop()
    if code == 0 or 'OKAY' in out:
        ok(c(GRN+B,"Bootloader unlocked!"))
        info("Device will reboot and wipe data")
    else:
        # Try legacy
        sp2 = Spinner('Trying legacy method...')
        sp2.start()
        out2, err_s2, code2 = run(fb+['oem','unlock'])
        sp2.stop()
        if code2 == 0 or 'OKAY' in out2:
            ok(c(GRN+B,"Bootloader unlocked (OEM method)!"))
        else:
            err(f"Failed: {err_s2 or out2}")
            print()
            if 'samsung' in device:
                warn("Samsung: check OEM Unlocking in Developer Options first")
            elif 'xiaomi' in device:
                warn("Xiaomi: requires Mi Account verification (72h wait)")
                info("Use: Mi Unlock Tool on Windows or Xiaomi HyperOS unlock")
            else:
                warn("Some devices need special codes or OEM tools")
                info(f"Run: {c(CYN,'luckyboot root-guide')} for device-specific steps")
    print()

def cmd_flash(args):
    section('Flash Partition'); print()
    partition = args.partition
    img_file  = args.image
    serial    = getattr(args,'serial',None)
    slot      = getattr(args,'slot',None)

    if not has_fastboot():
        err("fastboot not installed"); print(); return
    if not __import__('os').path.exists(img_file):
        err(f"File not found: {img_file}"); print(); return

    fb = ['fastboot'] + (['-s',serial] if serial else [])
    if slot: fb += ['--slot', slot]
    size = __import__('os').path.getsize(img_file) / (1024*1024)
    info(f"Partition: {c(YLW,partition)}")
    info(f"Image:     {img_file} ({size:.1f}MB)")
    warn("Flashing wrong partition can brick your device!")

    if not getattr(args,'yes',False):
        try:
            confirm = input(f"\n  {c(RED+B,'Type YES to flash')}: ").strip()
        except: print(); return
        if confirm != 'YES': err("Cancelled"); print(); return

    sp = Spinner(f'Flashing {partition}...')
    sp.start()
    out, err_s, code = run(fb+['flash', partition, img_file], timeout=120)
    sp.stop()
    if code == 0 or 'OKAY' in out or 'Finished' in out:
        ok(f"{partition} flashed successfully!")
        info(f"Reboot: {c(CYN,'fastboot reboot')}")
    else:
        err(f"Flash failed: {err_s or out}")
    print()

def cmd_recovery(args):
    """Flash recovery (TWRP etc)."""
    section('Flash Recovery'); print()
    img = getattr(args,'image',None)
    serial = getattr(args,'serial',None)
    if not img:
        device = get_prop('ro.product.device')
        info(f"Device codename: {c(CYN, device or '?')}")
        info("Download TWRP from: https://twrp.me/Devices/")
        info("Or Orangefox: https://orangefox.download")
        print()
        info(f"Then run: {c(CYN,f'luckyboot recovery --image twrp.img')}")
        print(); return
    args.partition = 'recovery'
    args.image = img
    cmd_flash(args)
