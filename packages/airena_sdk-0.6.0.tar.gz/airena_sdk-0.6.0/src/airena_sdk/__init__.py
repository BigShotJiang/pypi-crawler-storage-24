"""AiRENA SDK — thin protocol layer for openra.v1 bots.

Handles JSONL I/O, message dispatch, action serialization, and lifecycle.
Uses only the Python standard library.
"""

from importlib.metadata import version as _pkg_version

__version__ = _pkg_version("airena-sdk")

from airena_sdk.protocol import PROTOCOL, log, send, send_error
from airena_sdk.runner import BotRunner
from airena_sdk.actions import (
    move,
    attack_unit,
    deploy,
    stop,
    harvest,
    capture,
    queue_production,
    place_building,
    noop,
)
from airena_sdk.observation import (
    Observation,
    Unit,
    EnemyUnit,
    SelfInfo,
    Resources,
    ProductionQueue,
    ProductionItem,
    ActionResult,
    ResourceCell,
    MapInfo,
)
from airena_sdk.ruleset import Ruleset, UnitType, Weapon, Terrain
from airena_sdk.helpers import (
    can_afford,
    can_produce,
    power_for,
    projected_power,
    dps,
    effective_dps,
    unit_dps_against,
    decode_rle,
    can_build_at,
)

__all__ = [
    "__version__",
    "PROTOCOL",
    "log",
    "send",
    "send_error",
    "BotRunner",
    "move",
    "attack_unit",
    "deploy",
    "stop",
    "harvest",
    "capture",
    "queue_production",
    "place_building",
    "noop",
    # Observation dataclasses
    "Observation",
    "Unit",
    "EnemyUnit",
    "SelfInfo",
    "Resources",
    "ProductionQueue",
    "ProductionItem",
    "ActionResult",
    "ResourceCell",
    "MapInfo",
    # Ruleset dataclasses
    "Ruleset",
    "UnitType",
    "Weapon",
    "Terrain",
    # Helpers
    "can_afford",
    "can_produce",
    "power_for",
    "projected_power",
    "dps",
    "effective_dps",
    "unit_dps_against",
    "decode_rle",
    "can_build_at",
]
