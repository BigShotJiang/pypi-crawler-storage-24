"""Typed observation parser for openra.v1 tick messages.

Parses raw tick message dicts into frozen dataclasses with named fields.
Field names and structure match tick.schema.json (source of truth).
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class Resources:
    cash: int
    power: int


@dataclass(frozen=True, slots=True)
class ProductionItem:
    item_type_id: str
    progress: float
    done: bool
    paused: bool
    ticks_remaining: int | None = None
    status: str | None = None


@dataclass(frozen=True, slots=True)
class ProductionQueue:
    queue_type: str
    enabled: bool
    queue_length: int
    items: tuple[ProductionItem, ...]
    buildable_items: tuple[str, ...]

    def first_done(self) -> str | None:
        """Return type_id of first completed item, or None."""
        for item in self.items:
            if item.done:
                return item.item_type_id
        return None


@dataclass(frozen=True, slots=True)
class ActionResult:
    action: str
    status: str
    unit_id: int | None = None
    detail: str | None = None
    placement_detail: str | None = None


@dataclass(frozen=True, slots=True)
class Unit:
    id: int
    type_id: str
    x: int
    y: int
    hp: int
    max_hp: int
    facing: int
    cooldowns: dict[str, int]
    can_deploy: bool = False
    current_order: str = ""
    cargo_ratio: float | None = None
    harvester_state: str | None = None
    refinery_queue: int | None = None


@dataclass(frozen=True, slots=True)
class EnemyUnit:
    id: int
    type_id: str
    x: int
    y: int
    hp: int
    max_hp: int


@dataclass(frozen=True, slots=True)
class ResourceCell:
    x: int
    y: int
    kind: str
    density: float | None = None


@dataclass(frozen=True, slots=True)
class MapInfo:
    width: int
    height: int
    buildable: str | None = None


@dataclass(frozen=True, slots=True)
class SelfInfo:
    player_id: int
    faction: str
    resources: Resources
    production_queues: tuple[ProductionQueue, ...]
    placement_pending: bool = False
    placement_type_id: str | None = None
    build_queue: tuple[ProductionItem, ...] = ()
    action_results: tuple[ActionResult, ...] = ()

    def queue_for(self, queue_type: str) -> ProductionQueue | None:
        """Find a production queue by type (case-insensitive)."""
        key = queue_type.lower()
        for q in self.production_queues:
            if q.queue_type.lower() == key:
                return q
        return None

    def buildable_in(self, queue_type: str) -> tuple[str, ...]:
        """Return buildable item type_ids for a queue type."""
        q = self.queue_for(queue_type)
        return q.buildable_items if q is not None else ()

    def find_action_result(self, action_type: str) -> ActionResult | None:
        """Return first action result matching the action type."""
        for ar in self.action_results:
            if ar.action == action_type:
                return ar
        return None


@dataclass(frozen=True, slots=True)
class Observation:
    """Parsed tick observation. Created via ``Observation.from_tick(msg)``."""

    tick: int
    self_info: SelfInfo
    units: tuple[Unit, ...]
    enemies: tuple[EnemyUnit, ...]
    nearby_resources: tuple[ResourceCell, ...]
    map: MapInfo
    fow_enforced: bool = True

    @classmethod
    def from_tick(cls, msg: dict) -> Observation:
        """Parse a raw tick message dict into a typed Observation."""
        obs = msg["observation"]
        s = obs["self"]
        res = s["resources"]

        production_queues = tuple(
            ProductionQueue(
                queue_type=q["queue_type"],
                enabled=q["enabled"],
                queue_length=q["queue_length"],
                items=tuple(
                    ProductionItem(
                        item_type_id=it["item_type_id"],
                        progress=it["progress"],
                        done=it["done"],
                        paused=it["paused"],
                        ticks_remaining=it.get("ticks_remaining"),
                        status=it.get("status"),
                    )
                    for it in q["items"]
                ),
                buildable_items=tuple(q["buildable_items"]),
            )
            for q in s["production_queues"]
        )

        action_results = tuple(
            ActionResult(
                action=ar["action"],
                status=ar["status"],
                unit_id=ar.get("unit_id"),
                detail=ar.get("detail"),
                placement_detail=ar.get("placement_detail"),
            )
            for ar in s.get("action_results", [])
        )

        build_queue = tuple(
            ProductionItem(
                item_type_id=it["item_type_id"],
                progress=it["progress"],
                done=it["done"],
                paused=it["paused"],
                ticks_remaining=it.get("ticks_remaining"),
                status=it.get("status"),
            )
            for it in s.get("build_queue", [])
        )

        self_info = SelfInfo(
            player_id=s["player_id"],
            faction=s["faction"],
            resources=Resources(cash=res["cash"], power=res["power"]),
            production_queues=production_queues,
            placement_pending=s.get("placement_pending", False),
            placement_type_id=s.get("placement_type_id"),
            build_queue=build_queue,
            action_results=action_results,
        )

        units = tuple(
            Unit(
                id=u["id"],
                type_id=u["type_id"],
                x=u["x"],
                y=u["y"],
                hp=u["hp"],
                max_hp=u["max_hp"],
                facing=u["facing"],
                cooldowns=u["cooldowns"],
                can_deploy=u.get("can_deploy", False),
                current_order=u.get("current_order", ""),
                cargo_ratio=u.get("cargo_ratio"),
                harvester_state=u.get("harvester_state"),
                refinery_queue=u.get("refinery_queue"),
            )
            for u in obs["units"]
        )

        enemies = tuple(
            EnemyUnit(
                id=e["id"],
                type_id=e["type_id"],
                x=e["x"],
                y=e["y"],
                hp=e["hp"],
                max_hp=e["max_hp"],
            )
            for e in obs["visible_enemies"]
        )

        nearby_resources = tuple(
            ResourceCell(x=r["x"], y=r["y"], kind=r["kind"], density=r.get("density"))
            for r in obs.get("nearby_resources", [])
        )

        m = obs["map"]

        return cls(
            tick=msg["tick"],
            self_info=self_info,
            units=units,
            enemies=enemies,
            nearby_resources=nearby_resources,
            map=MapInfo(width=m["width"], height=m["height"], buildable=m.get("buildable")),
            fow_enforced=obs.get("fow_enforced", True),
        )
