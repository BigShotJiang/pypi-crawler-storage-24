from __future__ import annotations

import fnmatch
import json
import typing as t
from collections import defaultdict
from pathlib import Path

import click

from dbt_run_cache.config import RunCacheConfig
from dbt_run_cache.cli.auth import auth
from dbt_run_cache.cli.humanizer import _get_detailed_info
from dbt_run_cache.decision_logger import (
    DecisionLogger,
    DecisionEnvelope,
)


@click.group()
@click.pass_context
def cli(ctx: click.Context) -> None:
    ctx.ensure_object(dict)
    # TODO: Ideally use dbt to get the project root and log path
    # alternative is to parse the dbt project yml file to get log path
    decision_logger = DecisionLogger(
        project_root=Path.cwd(), log_path="logs", config=RunCacheConfig()
    )
    ctx.obj["decision_logger"] = decision_logger


@cli.command()
# TODO: Use dbt model selector to allow full model selection syntax that is supported by dbt
@click.option(
    "-s",
    "--select",
    type=str,
    help="Model selector to filter results by model name (Unix-style wildcards supported)",
    required=False,
)
@click.pass_context
def explain(ctx: click.Context, select: t.Optional[str] = None) -> None:
    decision_logger: DecisionLogger = ctx.obj["decision_logger"]
    log_files = decision_logger.logs_filepaths()
    labels = []
    mapping = {}
    for i, log_file in enumerate(log_files, start=1):
        label = f"({i}) {log_file.name}"
        labels.append(label)
        mapping[i] = log_file

    if not mapping:
        click.echo("No log files found.")
        return

    click.echo("Select a log file (most recent to least recent):")
    for label in labels:
        click.echo(f"  {label}")
    selected_label = click.prompt(
        "Enter choice",
        type=click.IntRange(1, len(mapping)),
        default=1,
    )

    selected_log_file = mapping[selected_label]
    responses = []
    with selected_log_file.open("r", encoding="utf-8") as f:
        responses = [_get_detailed_info(DecisionEnvelope.from_json(line)) for line in f]
    if select:
        responses = [
            response for response in responses if fnmatch.fnmatch(response["model_name"], select)
        ]
    click.echo(json.dumps(responses, indent=4))


@cli.command()
@click.option(
    "-i",
    "--index",
    type=int,
    help="0-based index for the file number to start processing",
    default=0,
    required=False,
)
@click.option(
    "-n",
    "--num",
    type=int,
    help="Number of files to process starting from `--index`",
    default=1,
    required=False,
)
@click.pass_context
def summary(ctx: click.Context, index: int, num: int) -> None:
    start = max(index, 0)
    decision_logger: DecisionLogger = ctx.obj["decision_logger"]
    log_files = decision_logger.logs_filepaths()
    num = max(1, min(num, len(log_files)))
    end = start + num
    selected_files = log_files[start:end]
    if not selected_files:
        click.echo("No log files found for the given range.")
        return
    stats: t.Dict[str, int] = defaultdict(int)
    for log_file in selected_files:
        with log_file.open("r", encoding="utf-8") as f:
            for line in f:
                envelope = DecisionEnvelope.from_json(line)
                stats[envelope.decision_type_short] += 1
    # pretty print json summary
    click.echo("Summary of response types:")
    click.echo(json.dumps(stats, indent=4, sort_keys=True))


cli.add_command(auth)


if __name__ == "__main__":
    cli()
