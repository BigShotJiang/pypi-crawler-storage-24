from __future__ import annotations

import typing as t

import click
import pyperclip
from rich.console import Console
from rich.table import Table

from dbt_run_cache.auth import sso_auth
from dbt_run_cache.auth.oauth_clients import OAuthClientManager
from dbt_run_cache.cli import error_handler


@click.group()
@click.option(
    "-o",
    "--org-id",
    type=str,
    help="Specify the organization ID to authenticate for.",
)
@click.pass_context
def auth(ctx: click.Context, org_id: t.Optional[str] = None) -> None:
    """
    Run Cache Authentication
    """
    ctx.ensure_object(dict)
    ctx.obj["sso"] = sso_auth(org_id=org_id)


@auth.command()
@click.pass_context
@error_handler
def status(ctx: click.Context) -> None:
    """Display current session status"""
    ctx.obj["sso"].status()


@auth.command()
@click.pass_context
@error_handler
def refresh(ctx: click.Context) -> None:
    """Refresh your current token"""
    console = Console()
    console.print("Refreshing your authentication token :arrows_counterclockwise:")
    ctx.obj["sso"].refresh_token()


@auth.command()
@click.pass_context
@error_handler
def logout(ctx: click.Context) -> None:
    """Logout of any current session"""
    ctx.obj["sso"].logout()


@auth.command()
@click.option(
    "-f",
    "--force",
    is_flag=True,
    default=False,
    help="Create a new session even when one already exists.",
)
@click.pass_context
@error_handler
def login(ctx: click.Context, force: bool) -> None:
    """Login"""
    sso = ctx.obj["sso"]
    if force:
        sso.login()
    else:
        sso.id_token(login=True)

    sso.status()


@auth.command("client-create")
@click.option(
    "-n",
    "--name",
    type=str,
    required=True,
    help="Name of the OAuth client.",
)
@click.option(
    "-d",
    "--description",
    type=str,
    required=True,
    help="Description of the OAuth client.",
)
@click.pass_context
@error_handler
def client_create(ctx: click.Context, name: str, description: str) -> None:
    """Create a new OAuth client"""
    sso = ctx.obj["sso"]
    manager = OAuthClientManager(sso)
    manager.create_client(name, description)
    click.echo(f"OAuth client '{name}' created successfully")


@auth.command("client-list")
@click.pass_context
@error_handler
def client_list(ctx: click.Context) -> None:
    """List existing OAuth clients"""
    sso = ctx.obj["sso"]
    manager = OAuthClientManager(sso)
    clients = manager.list_clients()

    if not clients:
        click.echo("No OAuth clients found")
        return

    console = Console()
    table = Table(title="OAuth Clients", show_header=True, header_style="bold magenta")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="green")
    table.add_column("Description", style="yellow")
    table.add_column("Organization", style="blue")
    table.add_column("Scope", style="white")

    for client in clients:
        table.add_row(
            client.id,
            client.name,
            client.description or "",
            client.org,
            client.scope,
        )

    console.print(table)


@auth.command("client-delete")
@click.argument(
    "client_id",
    type=str,
    required=True,
)
@click.option(
    "-y",
    "--yes",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt.",
)
@click.pass_context
@error_handler
def client_delete(ctx: click.Context, client_id: str, yes: bool) -> None:
    """Delete an OAuth client"""
    if not yes:
        if not click.confirm(f"Are you sure you want to delete OAuth client '{client_id}'?"):
            click.echo("Deletion cancelled")
            return

    sso = ctx.obj["sso"]
    manager = OAuthClientManager(sso)
    manager.delete_client(client_id)
    click.echo(f"OAuth client '{client_id}' deleted successfully")


@auth.command("client-secret")
@click.argument(
    "client_id",
    type=str,
    required=True,
)
@click.option(
    "-p",
    "--print",
    "print_secret",
    is_flag=True,
    default=False,
    help="Print the secret to stdout instead of copying to clipboard.",
)
@click.pass_context
@error_handler
def client_secret(ctx: click.Context, client_id: str, print_secret: bool) -> None:
    """Retrieve an OAuth client secret, printing it or copying it to clipboard"""
    sso = ctx.obj["sso"]
    manager = OAuthClientManager(sso)
    clients = manager.list_clients()

    client = next((c for c in clients if c.id == client_id), None)

    if not client:
        click.echo(f"OAuth client '{client_id}' not found")
        return

    if print_secret:
        click.echo(client.secret, nl=False)
    else:
        try:
            pyperclip.copy(client.secret)
            click.echo(f"Secret for OAuth client '{client.name}' copied to clipboard")
        except Exception as e:
            click.echo(f"Failed to copy to clipboard: {e}")
