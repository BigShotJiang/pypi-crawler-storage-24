import typing as t

from query_cache_common.models.services import (
    client_telemetry_service_models,
    sql_service_models,
    clone_service_models,
)
from dbt.contracts.graph.nodes import (
    GenericTestNode,
    ModelNode,
    SnapshotNode,
    SingularTestNode,
)


SQLSubmitResponse = t.Union[
    sql_service_models.ReadyToExecuteResponse,
    sql_service_models.SkipExecutionResponse,
    clone_service_models.ReadyToCloneResponse,
]


ModelOrSnapshotNode = t.Union[ModelNode, SnapshotNode]
ModelOrSnapshotOrTestNode = t.Union[ModelNode, SnapshotNode, GenericTestNode, SingularTestNode]

ClientEvent = t.Union[
    client_telemetry_service_models.SessionStartRequest,
    client_telemetry_service_models.ClientPrepareEnrichedSQLRequest,
    client_telemetry_service_models.SessionEndRequest,
]
