from __future__ import annotations

import logging
import typing as t
from dataclasses import dataclass
from urllib.parse import urljoin

import httpx

from dbt_run_cache.auth.sso import SsoAuth
from dbt_run_cache.config import get_env
from dbt_run_cache.errors import OAuthClientError


logger = logging.getLogger(__name__)

OAUTH_CLIENTS_URL = get_env(
    "OAUTH_CLIENTS_URL",
    "https://auth.runcache.com/api/clients",
)


@dataclass
class OAuthClient:
    """Represents an OAuth client entry returned by the auth service."""

    id: str
    secret: str
    scope: str
    org: str
    name: str
    description: t.Optional[str] = None

    @classmethod
    def from_dict(cls, data: t.Dict[str, t.Any]) -> OAuthClient:
        required_fields = ["id", "secret", "scope", "org", "config"]
        missing_fields = [f for f in required_fields if f not in data]

        if missing_fields:
            raise ValueError(f"Missing required fields: {', '.join(missing_fields)}")

        return cls(
            id=data["id"],
            secret=data["secret"],
            scope=data["scope"],
            org=data["org"],
            name=data["config"].get("name", "<missing>"),
            description=data["config"].get("description"),
        )


class OAuthClientManager:
    """Manages OAuth client operations (create, read, delete) via the Auth service."""

    def __init__(
        self,
        sso: SsoAuth,
        base_url: str = OAUTH_CLIENTS_URL,
        timeout: float = 30.0,
    ) -> None:
        self._sso = sso
        self._base_url = base_url.rstrip("/") + "/"
        self._timeout = timeout

    def create_client(self, name: str, description: str) -> None:
        """Create a new OAuth client for the organization.

        Args:
            name: Client name
            description: Client description

        Raises:
            OAuthClientError: If client creation fails.
        """
        org_id = self._sso.org_id(login=True)
        url = urljoin(self._base_url, org_id)

        payload = {"name": name, "description": description}

        try:
            response = httpx.post(
                url, json=payload, headers=self._get_headers(), timeout=self._timeout
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise OAuthClientError(
                f"Failed to create OAuth client: {e.response.status_code} - {e.response.text}"
            ) from e
        except Exception as e:
            raise OAuthClientError(f"Unexpected error creating OAuth client: {e}") from e

    def list_clients(self) -> t.List[OAuthClient]:
        """List all OAuth clients for the organization.

        Returns:
            List of OAuthClient objects

        Raises:
            OAuthClientError: If listing clients fails
        """
        org_id = self._sso.org_id(login=True)
        url = urljoin(self._base_url, org_id)

        try:
            response = httpx.get(url, headers=self._get_headers(), timeout=self._timeout)
            response.raise_for_status()
            data = response.json()
            clients = [OAuthClient.from_dict(client) for client in data["clients"]]
            return clients
        except httpx.HTTPStatusError as e:
            raise OAuthClientError(
                f"Failed to list OAuth clients: {e.response.status_code} - {e.response.text}"
            ) from e
        except Exception as e:
            raise OAuthClientError(f"Unexpected error listing OAuth clients: {e}") from e

    def delete_client(self, client_id: str) -> None:
        """Delete an OAuth client.

        Args:
            client_id: ID of the client to delete

        Raises:
            OAuthClientError: If client deletion fails
        """
        org_id = self._sso.org_id(login=True)
        url = urljoin(self._base_url, f"{org_id}/{client_id}")

        try:
            response = httpx.delete(url, headers=self._get_headers(), timeout=self._timeout)
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise OAuthClientError(
                f"Failed to delete OAuth client: {e.response.status_code} - {e.response.text}"
            ) from e
        except Exception as e:
            raise OAuthClientError(f"Unexpected error deleting OAuth client: {e}") from e

    def _get_headers(self) -> t.Dict[str, str]:
        token = self._sso.id_token(login=True)
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
