#!/usr/bin/python3
# -*- coding: utf-8 -*-

from importlib.metadata import PackageNotFoundError, version

try:
    INSTALLED_VERSION: str = version("sun")
except PackageNotFoundError:
    INSTALLED_VERSION = "unknown"

__prgnam__: str = 'sun'
__author__: str = 'dslackw'
__copyright__: str = '2015-2026'
__version__: str = INSTALLED_VERSION
__license__: str = 'GNU General Public License v3 (GPLv3)'
__license_link__: str = 'https://www.gnu.org/licenses/gpl-3.0.html'
__email__: str = 'dslackw@gmail.com'
__website__: str = 'https://dslackw.gitlab.io/sun/'

__about_text__: str = f"""
            <h3>SUN (Slackware Update Notifier) {__version__}</h3>
            SUN is a tray notification applet and daemon for informing about package updates in Slackware.
            It also serves as a CLI tool for monitoring upgraded packages.<br><br>
            Copyright: {__copyright__} © Dimitris Zlatanidis<br><br>
            <a href='http://www.slackware.com/'>Slackware®</a> is a Registered Trademark of Patrick Volkerding.<br>
            <a href='https://www.kernel.org/'>Linux®</a> is a Registered Trademark of Linus Torvalds.<br><br>
            License: <a href='{__license_link__}'>GNU General Public License v3 or later (GPLv3+)</a><br><br>
            Home: <a href='{__website__}'>{__website__}</a><br>
        """
