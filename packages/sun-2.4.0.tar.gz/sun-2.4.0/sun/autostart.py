#!/usr/bin/python3
# -*- coding: utf-8 -*-

import argparse
from pathlib import Path

from sun.configs import configs_load


class Autostart:
    """Manages the sun-daemon XDG autostart .desktop file."""

    PREFIX: str = 'The sun-daemon autostart is'

    def __init__(self) -> None:
        """Resolves the XDG autostart directory and sets the enable/disable file paths."""
        data_configs = configs_load.data_configs
        xdg: Path = Path(data_configs['xdg_autostart'])
        self.enable_file: Path = xdg / 'sun-daemon.desktop'
        self.disable_file: Path = xdg / 'sun-daemon.desktop.sample'

    def enable(self) -> None:
        """Enables autostart by renaming the .sample file to the active .desktop file."""
        if self.disable_file.is_file():
            self.disable_file.rename(self.enable_file)
            print(f'{self.PREFIX} enabled.')
        elif self.enable_file.is_file():
            print(f'{self.PREFIX} already enabled.')
        else:
            print(f'{self.PREFIX} not installed.')

    def disable(self) -> None:
        """Disables autostart by renaming the active .desktop file to a .sample file."""
        if self.enable_file.is_file():
            self.enable_file.rename(self.disable_file)
            print(f'{self.PREFIX} disabled.')
        elif self.disable_file.is_file():
            print(f'{self.PREFIX} already disabled.')
        else:
            print(f'{self.PREFIX} not installed.')

    def status(self) -> None:
        """Prints whether autostart is enabled, disabled, or not installed."""
        if self.enable_file.is_file():
            print(f'{self.PREFIX} enabled.')
        elif self.disable_file.is_file():
            print(f'{self.PREFIX} disabled.')
        else:
            print(f'{self.PREFIX} not installed.')

    def run(self) -> None:
        """Parses CLI arguments and dispatches to the appropriate action method."""
        parser = argparse.ArgumentParser(
            prog='sun-autostart',
            description='Script to enable-disable sun daemon autostart.'
        )
        parser.add_argument(
            'action',
            choices=['enable', 'disable', 'status'],
            help='Enable, disable, or view status of autostart SUN daemon.'
        )
        args = parser.parse_args()
        getattr(self, args.action)()


def main() -> None:
    """Entry point for the sun-autostart command."""
    Autostart().run()
