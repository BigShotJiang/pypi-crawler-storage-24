[![Latest Release](https://gitlab.com/dslackw/sun/-/badges/release.svg)](https://gitlab.com/dslackw/sun/-/releases)
[![pipeline status](https://img.shields.io/badge/pipeline-master-blue)](https://gitlab.com/dslackw/sun/-/commits/master)
[![coverage report](https://gitlab.com/dslackw/sun/badges/master/coverage.svg)](https://gitlab.com/dslackw/sun/-/commits/master)
[![Python](https://img.shields.io/badge/python-3.9_–_3.12-blue)](https://www.python.org/)
[![Code style: flake8](https://img.shields.io/badge/code%20style-flake8-orange)](https://flake8.pycqa.org/)
[![Type checked: mypy](https://img.shields.io/badge/type%20checked-mypy-blue)](https://mypy-lang.org/)
[![Linting: pylint](https://img.shields.io/badge/linting-pylint-yellowgreen)](https://pylint.org/)
[![License: GPL v3](https://img.shields.io/badge/license-GPLv3-blue)](LICENSE)

## About

SUN (Slackware Update Notifier) is a tray notification applet and background
daemon that monitors the Slackware `ChangeLog.txt` for package updates and
notifies the desktop user when new updates are available. It also serves as a
CLI tool for checking updates and viewing OS and machine information.

SUN works by default with slackpkg, as well as with other tools like slpkg.
You can probably use SUN with other Slackware-based Linux distributions as well.

## Features

- Background daemon that fetches the remote `ChangeLog.txt` at a configurable interval
- Desktop notification when new updates are detected
- System tray icon with numeric badge showing the update count
- Badge syncs immediately with daemon notification via SIGUSR1
- Greyscale tray icon when the daemon is not running
- Colored ChangeLog dialog with date headers and comment highlighting
- Config dialog in tray menu to view the active `sun.conf` settings
- `sun check` CLI command to check for updates without the daemon
- `sun config` CLI command to view the active `sun.conf` settings
- `sun info` CLI command to view hardware and OS information
- `sun changelog` CLI command to view the remote `ChangeLog.txt`
- `sun log` CLI command to view the daemon log
- `sun start / stop / restart / status` CLI commands to manage the daemon
- `NOTIFICATIONS` option to enable/disable desktop notifications independently of the tray badge
- `HTTP_TIMEOUT` option to configure the remote fetch timeout
- Mirror version warning when `HTTP_MIRROR` does not match installed Slackware version

## Screenshots

### Tray Menu
<img src="https://gitlab.com/dslackw/sun/-/raw/site/docs/images/sun_tray_menu.png" title="Tray Menu" width="300">

### Check Updates
<img src="https://gitlab.com/dslackw/sun/-/raw/site/docs/images/sun_check_updates.png" title="Check Updates">

### ChangeLog
<img src="https://gitlab.com/dslackw/sun/-/raw/site/docs/images/sun_changelog.png" title="ChangeLog">

### OS Info
<img src="https://gitlab.com/dslackw/sun/-/raw/site/docs/images/sun_os_info.png" title="OS Info">

## Documentation

https://dslackw.gitlab.io/sun/

## Manual

After installation, the manual page is available via:

```
man sun
```
