"""TUI widget modules."""
