from .tracker import EcoTracker
from .ui import CellHook
from .recommender import RecommendationEngine
from .gemini_helper import GeminiAdvisor

__all__ = [
    "EcoTracker",
    "CellHook",
    "RecommendationEngine",
    "GeminiAdvisor",
    "start",
]


def start(
    log_path: str = None,
    notebook_name: str = "Notebook",
    gemini: bool = True,
    api_key: str = None,
    emission_factor: float = 0.475,
):
    """
    One-call EcoML setup — works locally, on Google Colab, and anywhere.

    Simplest usage:
        from ecoml import start
        start()

    With Gemini on Colab (recommended):
        from ecoml import start
        start(api_key="your-gemini-key")

        # or store key in Colab Secrets as GEMINI_API_KEY → it's auto-read

    Parameters
    ----------
    log_path       : CSV file to log metrics. Auto-detected if not given.
    notebook_name  : Label shown in the log.
    gemini         : Enable Gemini AI advisor (needs an API key).
    api_key        : Gemini API key. If None, read from GEMINI_API_KEY
                     env var, .env file, or Colab Secrets automatically.
    emission_factor: kg CO₂ per kWh (default = India grid 0.475).
    """
    import pathlib

    # ── auto-detect log path ──────────────────────────────────────────
    if log_path is None:
        cwd = pathlib.Path().resolve()
        for folder in [cwd, cwd.parent, cwd.parent.parent]:
            candidate = folder / "data" / "emissions_log.csv"
            if candidate.parent.exists():
                log_path = str(candidate)
                break
        if log_path is None:
            log_path = str(cwd / "emissions_log.csv")

    # ── build components ─────────────────────────────────────────────
    _gemini      = GeminiAdvisor(api_key=api_key) if gemini else None
    _tracker     = EcoTracker(
        log_path=log_path,
        notebook_name=notebook_name,
        emission_factor=emission_factor,
    )
    _recommender = RecommendationEngine(gemini=_gemini)
    _hook        = CellHook(_tracker, _recommender)
    _hook.register()

    # ── status print ─────────────────────────────────────────────────
    gemini_status = "ON ✅" if (_gemini and _gemini.enabled) else "OFF ❌"
    print(f"🌿 EcoML v0.2.2 Ready")
    print(f"   📁 Log   : {log_path}")
    print(f"   🤖 Gemini: {gemini_status}")
    if not (_gemini and _gemini.enabled):
        print("   💡 Tip   : pass api_key= or set GEMINI_API_KEY env / Colab Secret")

    return _tracker, _recommender, _hook
