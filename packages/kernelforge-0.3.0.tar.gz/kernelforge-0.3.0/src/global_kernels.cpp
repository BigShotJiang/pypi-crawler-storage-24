// C++ standard library
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <stdexcept>
#include <vector>

// Third-party libraries
#include <omp.h>

// Project headers
#include "aligned_alloc64.hpp"
#include "blas_config.h"
#include "constants.hpp"
#include "rfp_utils.hpp"

namespace kf {

void kernel_gaussian_symm(
    const double *Xptr, blas_int n, blas_int rep_size, double alpha, double *Kptr
) {
    // 1) DSYRK (RowMajor, lower triangle): K = (-2*alpha) * X * X^T + 0*K
    cblas_dsyrk(
        CblasRowMajor,
        CblasLower,
        CblasNoTrans,
        n,
        rep_size,
        -2.0 * alpha,
        Xptr,
        rep_size,
        0.0,
        Kptr,
        n
    );

    // 2) diag = -0.5 * diag(K)
    const std::size_t n_size = static_cast<std::size_t>(n);
    std::vector<double> diag(n_size);
    for (blas_int i = 0; i < n; ++i) {
        diag[i] = -0.5 * Kptr[i * n + i];
    }

    // 3) K += 1 * (1*diag^T + diag*1^T) on LOWER via dsyr2
    std::vector<double> onevec(n_size, 1.0);
    cblas_dsyr2(CblasRowMajor, CblasLower, n, 1.0, onevec.data(), 1, diag.data(), 1, Kptr, n);

    // 4) Elementwise exp on the lower triangle (row j >= col i)
#pragma omp parallel for schedule(guided)
    for (blas_int j = 0; j < n; ++j) {
        for (blas_int i = 0; i <= j; ++i) {
            Kptr[j * n + i] = std::exp(Kptr[j * n + i]);
        }
    }

    // 5) Mirror lower triangle to upper triangle
#pragma omp parallel for schedule(static)
    for (blas_int j = 0; j < n; ++j) {
        for (blas_int i = 0; i < j; ++i) {
            Kptr[i * n + j] = Kptr[j * n + i];
        }
    }
}

// =============================================================================
// LEGACY: DSFRK-based implementation of kernel_gaussian_symm_rfp.
//
// This version uses LAPACKE_dsfrk to write the Gram matrix directly into RFP
// without any temporary buffer (pure O(N²/2) memory). It is a faithful C++
// port of the Fortran reference in examples/dsfrk_kernel.f90.
//
// WHY IT IS NOT THE PRIMARY IMPLEMENTATION:
//   LAPACKE_dsfrk for double precision is ~2.5× slower than cblas_dsyrk on MKL
//   (N=10000: ~0.35 s vs ~0.14 s). MKL's DSFRK is not as well optimised as
//   DSYRK for double; the Fortran reference uses single-precision ssfrk where
//   the gap is smaller. The tiled DSYRK approach below achieves 1.28× overhead
//   while still avoiding the full N×N allocation, so it dominates on all counts.
//
// The code is kept here for reference and in case a future MKL release improves
// DSFRK performance, or for use on platforms where DSYRK tile memory is tight.
// =============================================================================
#if 0

// Inverse RFP map: linear RFP index (0-based) -> (i, j) 0-based, i <= j
// Valid for TRANSR='N', UPLO='U', any n. Ported from Fortran rfp_ij_n_u.
static inline void rfp_ij_n_u(blas_int n, std::size_t idx, blas_int *i_out, blas_int *j_out) {
    const blas_int k      = n / 2;
    const bool     even   = (n % 2 == 0);
    const blas_int stride = even ? (n + 1) : n;
    const blas_int p  = static_cast<blas_int>(idx);
    const blas_int c0 = p / stride;
    const blas_int r0 = p - c0 * stride;
    const blas_int iA = r0, jA = k + c0;
    const bool     useA = (iA <= jA);
    const blas_int q  = p - (k + 1);
    const blas_int iB = (q >= 0) ? (q / stride) : 0;
    const blas_int jB = (q >= 0) ? (q - iB * stride) : 0;
    *i_out = useA ? iA : iB;
    *j_out = useA ? jA : jB;
}

void kernel_gaussian_symm_rfp_dsfrk(const double *Xptr, blas_int n, blas_int rep_size,
                                     double alpha, double *arf) {
    if (n <= 0 || rep_size <= 0) throw std::invalid_argument("n and rep_size must be > 0");
    if (!Xptr || !arf)           throw std::invalid_argument("Xptr and arf must be non-null");

    const std::size_t n_size = static_cast<std::size_t>(n);
    const std::size_t nt     = n_size * (n_size + 1) / 2;

    std::memset(arf, 0, nt * sizeof(double));  // beta=0 may skip writes on uninit buffer

    kf_dsfrk('N', 'U', 'T', n, rep_size, -2.0 * alpha, Xptr, rep_size, 0.0, arf);

    std::vector<double> sq(n_size);
    #pragma omp parallel for schedule(static)
    for (blas_int i = 0; i < n; ++i) {
        const double *row = Xptr + static_cast<std::size_t>(i) * static_cast<std::size_t>(rep_size);
        double acc = 0.0;
        for (blas_int kk = 0; kk < rep_size; ++kk) acc += row[kk] * row[kk];
        sq[i] = alpha * acc;
    }

    const blas_int k_rfp      = n / 2;
    const blas_int stride_rfp = (n % 2 == 0) ? (n + 1) : n;
    #pragma omp parallel for schedule(guided)
    for (std::ptrdiff_t idx = 0; idx < static_cast<std::ptrdiff_t>(nt); ++idx) {
        blas_int ii, jj;
        rfp_ij_n_u(n, static_cast<std::size_t>(idx), &ii, &jj);
        arf[idx] = std::exp(arf[idx] + sq[ii] + sq[jj]);
    }
}

#endif  // LEGACY DSFRK implementation

// =============================================================================
// Tile size for kernel_gaussian_symm_rfp (number of rows/cols per tile).
// Temporary buffer is TILE_RFP × TILE_RFP doubles = 512 MB for 8192.
// For N <= TILE_RFP the whole matrix fits in one tile (single DSYRK + scatter).
static constexpr blas_int TILE_RFP = 8192;

void kernel_gaussian_symm_rfp(
    const double *Xptr, blas_int n, blas_int rep_size, double alpha, double *arf
) {
    // Compute symmetric Gaussian kernel directly into RFP format using tiled DGEMM/DSYRK.
    // Output: arf[n*(n+1)/2] in Rectangular Full Packed (RFP) format
    //   (Fortran TRANSR='N', UPLO='U').
    //
    // Memory: one TILE_RFP×TILE_RFP temporary buffer (~512 MB for T=8192).
    // For N >> TILE_RFP this is far less than N×N.
    // For N <= TILE_RFP the whole matrix fits in one tile (single DSYRK + scatter).

    if (n <= 0 || rep_size <= 0) throw std::invalid_argument("n and rep_size must be > 0");
    if (!Xptr || !arf) throw std::invalid_argument("Xptr and arf must be non-null");

    const std::size_t n_sz = static_cast<std::size_t>(n);
    const std::size_t d_sz = static_cast<std::size_t>(rep_size);

    // 1) Squared norms: sq[i] = alpha * ||X[i]||^2
    std::vector<double> sq(n_sz);
#pragma omp parallel for schedule(static)
    for (blas_int i = 0; i < n; ++i) {
        const double *row = Xptr + static_cast<std::size_t>(i) * d_sz;
        double acc = 0.0;
        for (blas_int kk = 0; kk < rep_size; ++kk)
            acc += row[kk] * row[kk];
        sq[i] = alpha * acc;
    }

    // 2) Allocate one reusable tile buffer (TILE_RFP × TILE_RFP or smaller if n < TILE_RFP)
    const blas_int T = std::min<blas_int>(TILE_RFP, n);
    const std::size_t tile_buf_sz = static_cast<std::size_t>(T) * static_cast<std::size_t>(T);
    double *tile = aligned_alloc_64(tile_buf_sz);
    if (!tile) throw std::bad_alloc();

    // 3) Tile over the upper triangle.
    //    Outer loop: tile-columns tc (j range [j0, j1))
    //    Inner loop: tile-rows tr <= tc (i range [i0, i1))
    //    Diagonal tiles (tr==tc): DSYRK + scatter upper-triangle entries to RFP
    //    Off-diagonal tiles (tr<tc): DGEMM + scatter all entries to RFP
    for (blas_int j0 = 0; j0 < n; j0 += T) {
        const blas_int j1 = std::min<blas_int>(j0 + T, n);
        const blas_int Tj = j1 - j0;  // width of this column tile
        const double *Xj = Xptr + static_cast<std::size_t>(j0) * d_sz;

        for (blas_int i0 = 0; i0 <= j0; i0 += T) {
            const blas_int i1 = std::min<blas_int>(i0 + T, j1);  // i1 <= j1 (upper tri only)
            const blas_int Ti = i1 - i0;
            const double *Xi = Xptr + static_cast<std::size_t>(i0) * d_sz;

            if (i0 == j0) {
                // ---- Diagonal tile: only upper triangle needed ----
                // DSYRK (lower, row-major) into tile[Ti×Ti]
                // tile[p*Ti + q] = -2*alpha * X[i0+p] · X[i0+q]  for q <= p (lower)
                cblas_dsyrk(
                    CblasRowMajor,
                    CblasLower,
                    CblasNoTrans,
                    Ti,
                    rep_size,
                    -2.0 * alpha,
                    Xi,
                    rep_size,
                    0.0,
                    tile,
                    Ti
                );

                // Scatter lower triangle of tile → RFP (with exp).
                // DSYRK row-major lower: tile[p*Ti + q] valid for q <= p.
                // In global indexing: row = i0+p, col = i0+q, with row >= col (lower tri),
                // which maps to rfp_index_upper_N(n, col, row) = rfp_index_upper_N(n, i0+q, i0+p).
#pragma omp parallel for schedule(guided)
                for (blas_int p = 0; p < Ti; ++p) {
                    for (blas_int q = 0; q <= p; ++q) {
                        const blas_int gi = i0 + q;  // global i (upper-tri: i <= j)
                        const blas_int gj = i0 + p;  // global j
                        const double val = std::exp(
                            sq[gi] + sq[gj] +
                            tile
                                [static_cast<std::size_t>(p) * static_cast<std::size_t>(Ti) +
                                 static_cast<std::size_t>(q)]
                        );
                        arf[rfp_index_upper_N(n, gi, gj)] = val;
                    }
                }
            } else {
                // ---- Off-diagonal tile: i range is strictly left of j range ----
                // tile[Ti × Tj] = (-2*alpha) * X[i0:i1] @ X[j0:j1]^T
                cblas_dgemm(
                    CblasRowMajor,
                    CblasNoTrans,
                    CblasTrans,
                    Ti,
                    Tj,
                    rep_size,
                    -2.0 * alpha,
                    Xi,
                    rep_size,
                    Xj,
                    rep_size,
                    0.0,
                    tile,
                    Tj
                );

                // Scatter all Ti×Tj entries → RFP (with exp).
                // tile[p*Tj + q] corresponds to global (i=i0+p, j=j0+q), i < j always.
#pragma omp parallel for schedule(guided)
                for (blas_int p = 0; p < Ti; ++p) {
                    for (blas_int q = 0; q < Tj; ++q) {
                        const blas_int gi = i0 + p;
                        const blas_int gj = j0 + q;
                        const double val = std::exp(
                            sq[gi] + sq[gj] +
                            tile
                                [static_cast<std::size_t>(p) * static_cast<std::size_t>(Tj) +
                                 static_cast<std::size_t>(q)]
                        );
                        arf[rfp_index_upper_N(n, gi, gj)] = val;
                    }
                }
            }
        }
    }

    aligned_free_64(tile);
}

static inline void rowwise_self_norms(const double *X, std::size_t n, std::size_t d, double *out) {
    // out[i] = sum_k X[i, k]^2  (row-major: row i is contiguous)
    for (std::size_t i = 0; i < n; ++i) {
        const double *row = X + i * d;
        double acc = 0.0;
        for (std::size_t k = 0; k < d; ++k)
            acc += row[k] * row[k];
        out[i] = acc;
    }
}

void kernel_gaussian(
    const double *X1, const double *X2, std::size_t n1, std::size_t n2, std::size_t d, double alpha,
    double *K
) {
    // 1) K = (-2*alpha) * X1 * X2^T
    // RowMajor: A=X1 (n1 x d), B=X2 (n2 x d) but we pass Trans(B) => (d x n2)
    // lda = d, ldb = d, ldc = n1
    const double gemm_alpha = -2.0 * alpha;
    const double gemm_beta = 0.0;
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(n1),  // M
        static_cast<blas_int>(n2),  // N
        static_cast<blas_int>(d),   // K
        gemm_alpha,
        X1,
        static_cast<blas_int>(d),  // A, lda
        X2,
        static_cast<blas_int>(d),  // B, ldb  (Trans)
        gemm_beta,
        K,
        static_cast<blas_int>(n2)
    );  // C

    // 2) Rowwise self norms
    std::vector<double> nrm1(n1), nrm2(n2);
    rowwise_self_norms(X1, n1, d, nrm1.data());
    rowwise_self_norms(X2, n2, d, nrm2.data());

    // Ones
    std::vector<double> one_n1(n1, 1.0), one_n2(n2, 1.0);

    // 3) K += alpha * (ones_n2 * nrm1^T)   => GER(m=n1, n=n2)
    cblas_dger(
        CblasRowMajor,
        static_cast<blas_int>(n1),
        static_cast<blas_int>(n2),
        alpha,
        one_n1.data(),
        1,
        nrm2.data(),
        1,
        K,
        static_cast<blas_int>(n2)
    );

    // 4) K += alpha * (nrm2 * ones_n1^T)
    cblas_dger(
        CblasRowMajor,
        static_cast<blas_int>(n1),
        static_cast<blas_int>(n2),
        alpha,
        nrm1.data(),
        1,
        one_n2.data(),
        1,
        K,
        static_cast<blas_int>(n2)
    );

    // 5) Elementwise exp
    const std::size_t total = n2 * n1;
#pragma omp parallel for schedule(static)
    for (std::ptrdiff_t idx = 0; idx < static_cast<std::ptrdiff_t>(total); ++idx) {
        K[static_cast<std::size_t>(idx)] = std::exp(K[static_cast<std::size_t>(idx)]);
    }
}

void kernel_gaussian_jacobian(
    const double *X1, const double *dX1, const double *X2, std::size_t N1, std::size_t N2,
    std::size_t M, std::size_t D, double sigma, double *K_out
) {
    if (!X1 || !dX1 || !X2 || !K_out) throw std::invalid_argument("null pointer");
    if (N1 == 0 || N2 == 0 || M == 0 || D == 0) throw std::invalid_argument("empty dimension");
    if (!(sigma > 0.0)) throw std::invalid_argument("sigma must be > 0");

    const double inv_s2 = 1.0 / (sigma * sigma);

    // Phase 1: Precompute distance-based coefficients C[a,b] = exp(-||x1[a]-x2[b]||²/(2σ²)) / σ²

    // Squared norms
    std::vector<double> n1(N1), n2(N2);
    rowwise_self_norms(X1, N1, M, n1.data());
    rowwise_self_norms(X2, N2, M, n2.data());

    // S = X1 @ X2^T, then transform in-place to C
    double *C = aligned_alloc_64(N1 * N2);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(N1),
        static_cast<blas_int>(N2),
        static_cast<blas_int>(M),
        -2.0,  // coefficient for -2*S[a,b] term
        X1,
        static_cast<blas_int>(M),
        X2,
        static_cast<blas_int>(M),
        0.0,
        C,
        static_cast<blas_int>(N2)
    );

    // C[a,b] = exp(-0.5/σ² * (n1[a] + n2[b] - 2*S[a,b])) / σ²
#pragma omp parallel for collapse(2) schedule(static)
    for (std::size_t a = 0; a < N1; ++a) {
        for (std::size_t b = 0; b < N2; ++b) {
            const double sq = n1[a] + n2[b] + C[a * N2 + b];  // C currently holds -2*S
            const double k = std::exp(-0.5 * inv_s2 * sq);
            C[a * N2 + b] = k * inv_s2;
        }
    }

    // Phase 2: Projection table V = dX1 @ X2^T, write directly into K_out
    // K_out(N1*D × N2) = dX1(N1*D × M) @ X2^T(M × N2)
    // dX1 is contiguous as (N1*D, M) thanks to (N, D, M) layout
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(N1 * D),
        static_cast<blas_int>(N2),
        static_cast<blas_int>(M),
        1.0,
        dX1,
        static_cast<blas_int>(M),
        X2,
        static_cast<blas_int>(M),
        0.0,
        K_out,
        static_cast<blas_int>(N2)
    );

    // Phase 3: Self-projections u[a*D:(a+1)*D] = J1a @ x1a
    std::vector<double> u(N1 * D);

    int saved_blas_threads = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N1; ++a) {
        const double *x1a = X1 + a * M;
        const double *J1a = dX1 + (a * D) * M;  // (D × M) block
        cblas_dgemv(
            CblasRowMajor,
            CblasNoTrans,
            static_cast<blas_int>(D),
            static_cast<blas_int>(M),
            1.0,
            J1a,
            static_cast<blas_int>(M),
            x1a,
            1,
            0.0,
            u.data() + a * D,
            1
        );
    }

    kf_blas_set_num_threads(saved_blas_threads);

    // Phase 4: Fused scale + subtract: K_out[a*D+d, b] = C[a,b] * (K_out[a*D+d, b] - u[a*D+d])
#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N1; ++a) {
        const double *u_a = u.data() + a * D;
        const double *C_a = C + a * N2;
        double *K_a = K_out + (a * D) * N2;  // Rows [a*D : (a+1)*D)

        for (std::size_t d = 0; d < D; ++d) {
            const double u_ad = u_a[d];
            double *K_row = K_a + d * N2;  // Row (a*D + d)

            // Vectorize over b
#pragma omp simd
            for (std::size_t b = 0; b < N2; ++b) {
                K_row[b] = C_a[b] * (K_row[b] - u_ad);
            }
        }
    }

    // Cleanup
    aligned_free_64(C);
}

// Transposed Jacobian kernel: Jacobians on reference side (X2, dX2) instead of query side
// Output: K_t(N1, N2*D) where K_t[a, b*D+d] = sum_i (k_ab/σ²) * (x1[a,i] - x2[b,i]) * J2[b,d,i]
// Relationship: kernel_gaussian_jacobian_t(X2, X1, dX1, σ) == kernel_gaussian_jacobian(X1, dX1, X2,
// σ).T
void kernel_gaussian_jacobian_t(
    const double *X1, const double *X2, const double *dX2, std::size_t N1, std::size_t N2,
    std::size_t M, std::size_t D, double sigma, double *K_out
) {
    if (!X1 || !X2 || !dX2 || !K_out) throw std::invalid_argument("null pointer");
    if (N1 == 0 || N2 == 0 || M == 0 || D == 0) throw std::invalid_argument("empty dimension");
    if (!(sigma > 0.0)) throw std::invalid_argument("sigma must be > 0");

    const double inv_s2 = 1.0 / (sigma * sigma);
    const std::size_t N2D = N2 * D;

    // Phase 1: Precompute distance-based coefficients C[a,b] = exp(-||x1[a]-x2[b]||²/(2σ²)) / σ²

    // Squared norms
    std::vector<double> n1(N1), n2(N2);
    rowwise_self_norms(X1, N1, M, n1.data());
    rowwise_self_norms(X2, N2, M, n2.data());

    // S = X1 @ X2^T, then transform in-place to C
    double *C = aligned_alloc_64(N1 * N2);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(N1),
        static_cast<blas_int>(N2),
        static_cast<blas_int>(M),
        -2.0,  // coefficient for -2*S[a,b] term
        X1,
        static_cast<blas_int>(M),
        X2,
        static_cast<blas_int>(M),
        0.0,
        C,
        static_cast<blas_int>(N2)
    );

    // C[a,b] = exp(-0.5/σ² * (n1[a] + n2[b] - 2*S[a,b])) / σ²
#pragma omp parallel for collapse(2) schedule(static)
    for (std::size_t a = 0; a < N1; ++a) {
        for (std::size_t b = 0; b < N2; ++b) {
            const double sq = n1[a] + n2[b] + C[a * N2 + b];  // C currently holds -2*S
            const double k = std::exp(-0.5 * inv_s2 * sq);
            C[a * N2 + b] = k * inv_s2;
        }
    }

    // Phase 2: Projection table V = X1 @ dX2^T, write directly into K_out
    // K_out(N1, N2*D) = X1(N1, M) @ dX2^T(M, N2*D)
    // dX2 is contiguous as (N2*D, M) thanks to (N, D, M) layout
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(N1),
        static_cast<blas_int>(N2D),
        static_cast<blas_int>(M),
        1.0,
        X1,
        static_cast<blas_int>(M),
        dX2,
        static_cast<blas_int>(M),
        0.0,
        K_out,
        static_cast<blas_int>(N2D)
    );

    // Phase 3: Self-projections u[b*D:(b+1)*D] = J2b @ x2b
    std::vector<double> u(N2 * D);

    int saved_blas_threads = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel for schedule(static)
    for (std::size_t b = 0; b < N2; ++b) {
        const double *x2b = X2 + b * M;
        const double *J2b = dX2 + (b * D) * M;  // (D × M) block
        cblas_dgemv(
            CblasRowMajor,
            CblasNoTrans,
            static_cast<blas_int>(D),
            static_cast<blas_int>(M),
            1.0,
            J2b,
            static_cast<blas_int>(M),
            x2b,
            1,
            0.0,
            u.data() + b * D,
            1
        );
    }

    kf_blas_set_num_threads(saved_blas_threads);

    // Phase 4: Fused scale + subtract
    // K_out[a, b*D+d] = C[a,b] * (K_out[a, b*D+d] - u[b*D+d])
#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N1; ++a) {
        const double *C_a = C + a * N2;
        double *K_row = K_out + a * N2D;  // Row a of K_out, length N2*D

        for (std::size_t b = 0; b < N2; ++b) {
            const double c_ab = C_a[b];
            const double *u_b = u.data() + b * D;
            double *K_bd = K_row + b * D;  // D contiguous elements

            // SIMD-friendly: D contiguous elements, scalar broadcast of c_ab
#pragma omp simd
            for (std::size_t d = 0; d < D; ++d) {
                K_bd[d] = c_ab * (K_bd[d] - u_b[d]);
            }
        }
    }

    // Cleanup
    aligned_free_64(C);
}

static inline void row_axpy(std::size_t n, double alpha, const double *x, double *y) {
    for (std::size_t i = 0; i < n; ++i)
        y[i] += alpha * x[i];
}

void kernel_gaussian_hessian(
    const double *__restrict X1, const double *__restrict dX1, const double *__restrict X2,
    const double *__restrict dX2, std::size_t N1, std::size_t N2, std::size_t M, std::size_t D1,
    std::size_t D2, double sigma,
    std::size_t tile_B,  // now used
    double *__restrict H_out
) {
    if (!X1 || !dX1 || !X2 || !dX2 || !H_out) throw std::invalid_argument("null pointer");
    if (N1 == 0 || N2 == 0 || M == 0 || D1 == 0 || D2 == 0)
        throw std::invalid_argument("empty dimension");
    if (!(sigma > 0.0)) throw std::invalid_argument("sigma must be > 0");

    const std::size_t big_rows = N1 * D1;
    const std::size_t big_cols = N2 * D2;

    const double inv_s2 = 1.0 / (sigma * sigma);
    const double inv_s4 = inv_s2 * inv_s2;

    // 1) Distances → C = K/s^2 and C4 = K/s^4
    std::vector<double> n1(N1), n2(N2);

#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N1; ++a) {
        const double *__restrict x = X1 + a * M;
        double s = 0.0;
#pragma omp simd reduction(+ : s)
        for (std::size_t i = 0; i < M; ++i)
            s += x[i] * x[i];
        n1[a] = s;
    }

#pragma omp parallel for schedule(static)
    for (std::size_t b = 0; b < N2; ++b) {
        const double *__restrict x = X2 + b * M;
        double s = 0.0;
#pragma omp simd reduction(+ : s)
        for (std::size_t i = 0; i < M; ++i)
            s += x[i] * x[i];
        n2[b] = s;
    }

    // C = -2 * X1 @ X2^T  (write directly into C, will be transformed in-place)
    double *C = aligned_alloc_64(N1 * N2);
    double *C4 = aligned_alloc_64(N1 * N2);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(N1),
        static_cast<blas_int>(N2),
        static_cast<blas_int>(M),
        -2.0,  // coefficient for -2*S[a,b] term
        X1,
        static_cast<blas_int>(M),
        X2,
        static_cast<blas_int>(M),
        0.0,
        C,
        static_cast<blas_int>(N2)
    );

    // Transform C in-place: C[a,b] = exp(-0.5/σ² * (n1[a] + n2[b] - 2*S)) / σ²
    //                                = exp(-0.5/σ² * (n1[a] + n2[b] + C[a,b])) / σ²
    // C4[a,b] = same kernel but scaled by 1/σ⁴
#pragma omp parallel for collapse(2) schedule(static)
    for (std::size_t a = 0; a < N1; ++a) {
        for (std::size_t b = 0; b < N2; ++b) {
            const double sq = n1[a] + n2[b] + C[a * N2 + b];  // C holds -2*S
            const double k = std::exp(-0.5 * inv_s2 * sq);
            C[a * N2 + b] = k * inv_s2;
            C4[a * N2 + b] = k * inv_s4;
        }
    }

    // 2) dX1 and dX2 are already in (N*D × M) layout - no packing needed!

    // 3) No global Gram matrix. D1×D2 Gram blocks computed on-the-fly in phase 6.
    //    Avoids writing/reading the big_rows × big_cols = (N1*D1)×(N2*D2) H_out,
    //    which at N=1000, D=27 is 5.8 GB and bottlenecked by cold-page memory bandwidth.

    // 4) Projection tables:
    //    V1X2 = dX1 @ X2^T  (big_rows × N2) -- unchanged for now
    //    V2X1_T = X1 @ dX2^T  (N1 × big_cols) -- transposed for contiguous v2 reads
    //    dX1 and dX2 are already in (N*D × M) row-major layout
    double *V1X2_all = aligned_alloc_64(big_rows * N2);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(big_rows),
        static_cast<blas_int>(N2),
        static_cast<blas_int>(M),
        1.0,
        dX1,
        static_cast<blas_int>(M),
        X2,
        static_cast<blas_int>(M),
        0.0,
        V1X2_all,
        static_cast<blas_int>(N2)
    );

    // V2X1_T(N1 × N2*D2) = X1(N1 × M) @ dX2^T(M × N2*D2)
    // This makes v2 extraction contiguous in Phase 6
    double *V2X1_T = aligned_alloc_64(N1 * big_cols);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(N1),
        static_cast<blas_int>(big_cols),
        static_cast<blas_int>(M),
        1.0,
        X1,
        static_cast<blas_int>(M),
        dX2,
        static_cast<blas_int>(M),
        0.0,
        V2X1_T,
        static_cast<blas_int>(big_cols)
    );

    // 5) Self projections: U1[a]=J1_a^T x1_a, U2[b]=J2_b^T x2_b
    std::vector<double> U1(N1 * D1), U2(N2 * D2);

    int saved_blas_threads_phase5 = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N1; ++a) {
        const double *__restrict x1 = X1 + a * M;
        const double *__restrict J1 = dX1 + (a * D1) * M;
        cblas_dgemv(
            CblasRowMajor,
            CblasNoTrans,
            static_cast<blas_int>(D1),
            static_cast<blas_int>(M),
            1.0,
            J1,
            static_cast<blas_int>(M),
            x1,
            1,
            0.0,
            U1.data() + a * D1,
            1
        );
    }

#pragma omp parallel for schedule(static)
    for (std::size_t b = 0; b < N2; ++b) {
        const double *__restrict x2 = X2 + b * M;
        const double *__restrict J2 = dX2 + (b * D2) * M;
        cblas_dgemv(
            CblasRowMajor,
            CblasNoTrans,
            static_cast<blas_int>(D2),
            static_cast<blas_int>(M),
            1.0,
            J2,
            static_cast<blas_int>(M),
            x2,
            1,
            0.0,
            U2.data() + b * D2,
            1
        );
    }

    kf_blas_set_num_threads(saved_blas_threads_phase5);

    // 6) Tiled Gram computation: for each (a, b-tile), compute ONE large DGEMM
    //    instead of tile_B small ones. This reduces BLAS dispatch overhead from
    //    ~1.0s to ~0.016s (62.5× reduction in calls).
    //
    //    Key insight: dX2 is (N2*D2, M) row-major, so J2[b0:bend] is CONTIGUOUS.
    //    G_tile(D1 × tile_len*D2) = J1a(D1 × M) @ dX2[b0*D2*M:]^T(M × tile_len*D2)
    //    Then apply scale + rank-1 correction per (a,b) from the tiled result.
    if (tile_B == 0) tile_B = std::min<std::size_t>(DEFAULT_TILE_SIZE, N2);

    int saved_blas_threads = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel
    {
        // Allocate per-thread G_tile buffer for tiled Gram results
        // Max size: D1 × tile_B*D2 (e.g., 27 × 64*27 = 46656 doubles = 364.5 KB)
        double *G_tile = aligned_alloc_64(D1 * tile_B * D2);
        std::vector<double> v1(D1), v2(D2);

#pragma omp for schedule(static)
        for (std::size_t a = 0; a < N1; ++a) {
            const double *__restrict U1a = U1.data() + a * D1;
            const double *__restrict V1X2a = V1X2_all + (a * D1) * N2;  // (D1×N2)
            const double *__restrict J1a_hat = dX1 + a * D1 * M;        // (D1×M)

            for (std::size_t b0 = 0; b0 < N2; b0 += tile_B) {
                const std::size_t bend = std::min(N2, b0 + tile_B);
                const std::size_t tile_len = bend - b0;

                // ---- Tiled Gram DGEMM: G_tile(D1 × tile_len*D2) = J1a @ J2_stacked^T ----
                // J2_stacked is dX2[b0*D2*M : bend*D2*M] -- already contiguous in dX2!
                // This ONE DGEMM replaces tile_len tiny DGEMMs
                const double *__restrict J2_stacked = dX2 + b0 * D2 * M;
                cblas_dgemm(
                    CblasRowMajor,
                    CblasNoTrans,
                    CblasTrans,
                    static_cast<blas_int>(D1),
                    static_cast<blas_int>(tile_len * D2),
                    static_cast<blas_int>(M),
                    1.0,
                    J1a_hat,
                    static_cast<blas_int>(M),
                    J2_stacked,
                    static_cast<blas_int>(M),
                    0.0,
                    G_tile,
                    static_cast<blas_int>(tile_len * D2)
                );

                // ---- Per-molecule correction loop ----
                for (std::size_t b = b0; b < bend; ++b) {
                    const double cab = C[a * N2 + b];
                    const double c4ab = C4[a * N2 + b];

                    // v1 = U1[a] - V1X2_all[aD1:(a+1)D1, b]
#pragma omp simd
                    for (std::size_t i = 0; i < D1; ++i)
                        v1[i] = U1a[i] - V1X2a[i * N2 + b];

                    // v2 = V2X1_T[a, b*D2:(b+1)*D2] - U2[b] (CONTIGUOUS reads!)
                    const double *__restrict U2b = U2.data() + b * D2;
                    const double *__restrict V2X1_row = V2X1_T + a * big_cols + b * D2;
#pragma omp simd
                    for (std::size_t j = 0; j < D2; ++j)
                        v2[j] = V2X1_row[j] - U2b[j];

                    // Extract D1×D2 Gram sub-block from G_tile for this b
                    // G_tile layout: row d1, cols (b-b0)*D2 + d2
                    const std::size_t b_offset = (b - b0) * D2;

                    // Fused scale + rank-1 + write to H_out
                    double *__restrict Hblk = H_out + (a * D1) * big_cols + b * D2;
                    for (std::size_t i = 0; i < D1; ++i) {
                        const double *__restrict G_row = G_tile + i * (tile_len * D2) + b_offset;
                        double *__restrict Hrow = Hblk + i * big_cols;
#pragma omp simd
                        for (std::size_t j = 0; j < D2; ++j)
                            Hrow[j] = G_row[j] * cab - c4ab * v1[i] * v2[j];
                    }
                }
            }
        }
        aligned_free_64(G_tile);
    }

    kf_blas_set_num_threads(saved_blas_threads);

    // Free aligned allocations
    aligned_free_64(V2X1_T);
    aligned_free_64(V1X2_all);
    aligned_free_64(C4);
    aligned_free_64(C);
}

// Symmetric (training) RBF Hessian kernel, Gaussian.
// X: (N, M) row-major          – descriptor vectors
// dX: (N, D, M) row-major      – Jacobians wrt descriptor coords (D x M) per sample
// Output H_out: (N*D, N*D) row-major, symmetric
void kernel_gaussian_hessian_symm(
    // Symmetric (training) RBF Hessian, Gaussian kernel.
    // Assumes: X2==X1 (same set), dX2==dX1, N1==N2, D1==D2.
    // Builds only the lower triangle and mirrors to upper.
    // void rbf_hessian_full_tiled_gemm_symmetric(
    const double *__restrict X1, const double *__restrict dX1, std::size_t N1, std::size_t M,
    std::size_t D1, double sigma, std::size_t tile_B, double *__restrict H_out
) {
    if (!X1 || !dX1 || !H_out) throw std::invalid_argument("null pointer");
    if (N1 == 0 || M == 0 || D1 == 0) throw std::invalid_argument("empty dimension");
    if (!(sigma > 0.0)) throw std::invalid_argument("sigma must be > 0");

    const std::size_t N = N1;
    const std::size_t D = D1;
    const std::size_t BIG = N * D;

    const double inv_s2 = 1.0 / (sigma * sigma);
    const double inv_s4 = inv_s2 * inv_s2;

    // Zero output once (we'll fill lower and mirror to upper at the end)
    // std::fill(H_out, H_out + BIG*BIG, 0.0);

    // 1) Distances → C = K/s^2 and C4 = K/s^4
    std::vector<double> n(N);
#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        const double *__restrict x = X1 + a * M;
        double s = 0.0;
#pragma omp simd reduction(+ : s)
        for (std::size_t i = 0; i < M; ++i)
            s += x[i] * x[i];
        n[a] = s;
    }

    // C = -2 * X1 @ X1^T (write directly into C, will be transformed in-place)
    double *C = aligned_alloc_64(N * N);
    double *C4 = aligned_alloc_64(N * N);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(N),
        static_cast<blas_int>(N),
        static_cast<blas_int>(M),
        -2.0,  // coefficient for -2*S[a,b] term
        X1,
        static_cast<blas_int>(M),
        X1,
        static_cast<blas_int>(M),
        0.0,
        C,
        static_cast<blas_int>(N)
    );

    // Transform C in-place: C[a,b] = exp(-0.5/σ² * (n[a] + n[b] + C[a,b])) / σ²
    // where C currently holds -2*S
#pragma omp parallel for collapse(2) schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        for (std::size_t b = 0; b < N; ++b) {
            const double sq = n[a] + n[b] + C[a * N + b];  // C holds -2*S
            const double k = std::exp(-0.5 * inv_s2 * sq);
            C[a * N + b] = k * inv_s2;
            C4[a * N + b] = k * inv_s4;
        }
    }

    // 2) dX1 is already in (N*D × M) layout - no packing needed!

    // 3) No global Gram matrix. D×D Gram blocks computed on-the-fly in phase 6.
    //    Avoids allocating/writing/reading the BIG×BIG = (N*D)² H_out in phase 3/6,
    //    which at N=1000, D=27 is 5.8 GB and bottlenecked by cold-page memory bandwidth.

    // 4) Projection table V = dX1 @ X1^T  (BIG x N)
    //    dX1 is already in (N*D × M) row-major layout
    double *V = aligned_alloc_64(BIG * N);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(BIG),
        static_cast<blas_int>(N),
        static_cast<blas_int>(M),
        1.0,
        dX1,
        static_cast<blas_int>(M),
        X1,
        static_cast<blas_int>(M),
        0.0,
        V,
        static_cast<blas_int>(N)
    );

    // 5) Self projections: U[a] = J_a^T x_a  (N x D)
    std::vector<double> U(N * D);

    int saved_blas_threads_phase5 = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        const double *__restrict x = X1 + a * M;
        const double *__restrict Ja = dX1 + (a * D) * M;
        double *__restrict Ua = U.data() + a * D;
        cblas_dgemv(
            CblasRowMajor,
            CblasNoTrans,
            static_cast<blas_int>(D),
            static_cast<blas_int>(M),
            1.0,
            Ja,
            static_cast<blas_int>(M),
            x,
            1,
            0.0,
            Ua,
            1
        );
    }

    kf_blas_set_num_threads(saved_blas_threads_phase5);

    // 6) Lower-triangle blocks: compute D×D Gram on-the-fly per (a,b), fuse scale + rank-1.
    //    Avoids ever writing the cold BIG×BIG global Gram matrix; each D×D Gblk
    //    (D=27: 5832 bytes) stays hot in L1 cache.
    if (tile_B == 0) tile_B = std::min<std::size_t>(DEFAULT_TILE_SIZE, N);

    int saved_blas_threads_symm = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel
    {
        // Allocate tiled Gram buffer: G_tile(D × tile_B*D) for one medium DGEMM per tile
        double *G_tile = aligned_alloc_64(D * tile_B * D);
        std::vector<double> v1(D), v2(D);

#pragma omp for schedule(static)
        for (std::size_t a = 0; a < N; ++a) {
            const double *__restrict Ua = U.data() + a * D;
            const double *__restrict Va = V + (a * D) * N;
            const double *__restrict Ja_hat = dX1 + a * D * M;  // (D×M)

            for (std::size_t b0 = 0; b0 < a + 1; b0 += tile_B) {
                const std::size_t bend = std::min<std::size_t>(a + 1, b0 + tile_B);
                const std::size_t tile_len = bend - b0;

                // Tiled DGEMM: G_tile(D × tile_len*D) = Ja_hat(D×M) @ dX1[b0*D*M:]^T(M ×
                // tile_len*D) dX1 layout is (N*D, M), so consecutive Jacobian blocks are contiguous
                const double *__restrict Jb_tile = dX1 + b0 * D * M;
                cblas_dgemm(
                    CblasRowMajor,
                    CblasNoTrans,
                    CblasTrans,
                    static_cast<blas_int>(D),
                    static_cast<blas_int>(tile_len * D),
                    static_cast<blas_int>(M),
                    1.0,
                    Ja_hat,
                    static_cast<blas_int>(M),
                    Jb_tile,
                    static_cast<blas_int>(M),
                    0.0,
                    G_tile,
                    static_cast<blas_int>(tile_len * D)
                );

                for (std::size_t b = b0; b < bend; ++b) {
                    const double cab = C[a * N + b];
                    const double c4ab = C4[a * N + b];

                    // Extract D×D slice from G_tile for this b
                    const double *__restrict Gblk = G_tile + (b - b0) * D;

                    // v1 = U[a] - V[aD:(a+1)D, b]
#pragma omp simd
                    for (std::size_t i = 0; i < D; ++i)
                        v1[i] = Ua[i] - Va[i * N + b];

                    // v2 = V[bD:(b+1)D, a] - U[b]
                    const double *__restrict Ub = U.data() + b * D;
                    const double *__restrict Vb = V + (b * D) * N;
#pragma omp simd
                    for (std::size_t j = 0; j < D; ++j)
                        v2[j] = Vb[j * N + a] - Ub[j];

                    // Fused scale + rank-1 correction, write lower-triangle block of H_out.
                    // H_out[aD+i, bD+j] = Gblk[i,j]*cab - c4ab*v1[i]*v2[j]
                    // Only the lower triangle is filled (consistent with original behaviour;
                    // the caller/test only reads H_out[i,j] for j<=i).
                    double *__restrict Hblk = H_out + (a * D) * BIG + b * D;
                    for (std::size_t i = 0; i < D; ++i) {
                        const double *__restrict Grow = Gblk + i * tile_len * D;
                        double *__restrict Hrow = Hblk + i * BIG;
#pragma omp simd
                        for (std::size_t j = 0; j < D; ++j)
                            Hrow[j] = Grow[j] * cab - c4ab * v1[i] * v2[j];
                    }
                }
            }
        }
        aligned_free_64(G_tile);
    }

    kf_blas_set_num_threads(saved_blas_threads_symm);

    // 7) Mirror lower-triangle D×D blocks to upper triangle.
    //    For each (a, b) with a > b, copy the D×D block at [a*D:, b*D:] → [b*D:, a*D:].
#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        for (std::size_t b = 0; b < a; ++b) {
            for (std::size_t d1 = 0; d1 < D; ++d1) {
                for (std::size_t d2 = 0; d2 < D; ++d2) {
                    H_out[(b * D + d2) * BIG + (a * D + d1)] =
                        H_out[(a * D + d1) * BIG + (b * D + d2)];
                }
            }
        }
        // Mirror diagonal block lower→upper within the D×D block at [a*D:, a*D:]
        for (std::size_t d1 = 0; d1 < D; ++d1) {
            for (std::size_t d2 = 0; d2 < d1; ++d2) {
                H_out[(a * D + d2) * BIG + (a * D + d1)] = H_out[(a * D + d1) * BIG + (a * D + d2)];
            }
        }
    }

    aligned_free_64(V);
    aligned_free_64(C4);
    aligned_free_64(C);
}

// ============================================================================
// RFP (Row-First Packed) version - saves ~50% memory for symmetric matrices
// ============================================================================

// Symmetric Hessian kernel with RFP output (memory-efficient)
// Output H_rfp: packed lower triangle, length BIG*(BIG+1)/2 where BIG=N*D
// Memory savings: ~50% compared to full matrix
void kernel_gaussian_hessian_symm_rfp(
    const double *__restrict X1, const double *__restrict dX1, std::size_t N1, std::size_t M,
    std::size_t D1, double sigma, std::size_t tile_B, double *__restrict H_rfp
) {
    if (!X1 || !dX1 || !H_rfp) throw std::invalid_argument("null pointer");
    if (N1 == 0 || M == 0 || D1 == 0) throw std::invalid_argument("empty dimension");
    if (!(sigma > 0.0)) throw std::invalid_argument("sigma must be > 0");

    const std::size_t N = N1;
    const std::size_t D = D1;
    const std::size_t BIG = N * D;
    const std::size_t rfp_size = BIG * (BIG + 1) / 2;

    const double inv_s2 = 1.0 / (sigma * sigma);
    const double inv_s4 = inv_s2 * inv_s2;

    // NOTE: H_rfp is NOT zeroed here. Every element is written exactly once in
    // phase 6, so a prior memset would only waste time on a cold 2.9 GB buffer.

    // 1) Distances → C = K/s^2 and C4 = K/s^4
    // Optimized: DGEMM with alpha=-2.0 writes -2*X@X^T directly to C, avoiding S allocation
    std::vector<double> n(N);
#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        const double *__restrict x = X1 + a * M;
        double s = 0.0;
#pragma omp simd reduction(+ : s)
        for (std::size_t i = 0; i < M; ++i)
            s += x[i] * x[i];
        n[a] = s;
    }

    // C = -2.0 * X1 @ X1^T (DGEMM with alpha=-2.0, no S allocation needed)
    double *C = aligned_alloc_64(N * N);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(N),
        static_cast<blas_int>(N),
        static_cast<blas_int>(M),
        -2.0,
        X1,
        static_cast<blas_int>(M),
        X1,
        static_cast<blas_int>(M),
        0.0,
        C,
        static_cast<blas_int>(N)
    );

    double *C4 = aligned_alloc_64(N * N);
#pragma omp parallel for collapse(2) schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        for (std::size_t b = 0; b < N; ++b) {
            // C[a,b] now holds -2*S[a,b], so: sq = n[a] + n[b] + C[a,b]
            const double sq = n[a] + n[b] + C[a * N + b];
            const double k = std::exp(-0.5 * inv_s2 * sq);
            C[a * N + b] = k * inv_s2;
            C4[a * N + b] = k * inv_s4;
        }
    }

    // 2) dX1 is already in (N*D × M) layout - no packing needed!

    // 3) No global Gram matrix allocated here.
    //    The D×D Gram block for each (a,b) pair is computed on-the-fly in phase 6
    //    via a small DGEMM (D×M) @ (M×D) → (D×D), using a thread-local scratch buffer.
    //    This avoids allocating the BIG×BIG = (N*D)² temp matrix (~5.8 GB for N=1000,D=27)
    //    that the previous implementation used, and eliminates its ~2.4 GB/s-limited memset.

    // 4) Projection table V = dX1 @ X1^T  (BIG x N)  (identical to hessian_symm)
    //    dX1 is already in (N*D × M) row-major layout
    double *V = aligned_alloc_64(BIG * N);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(BIG),
        static_cast<blas_int>(N),
        static_cast<blas_int>(M),
        1.0,
        dX1,
        static_cast<blas_int>(M),
        X1,
        static_cast<blas_int>(M),
        0.0,
        V,
        static_cast<blas_int>(N)
    );

    // 5) Self projections: U[a] = J_a^T x_a  (N x D)  (identical to hessian_symm)
    std::vector<double> U(N * D);

    int saved_blas_threads_phase5 = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        const double *__restrict x = X1 + a * M;
        const double *__restrict Ja = dX1 + (a * D) * M;
        double *__restrict Ua = U.data() + a * D;
        cblas_dgemv(
            CblasRowMajor,
            CblasNoTrans,
            static_cast<blas_int>(D),
            static_cast<blas_int>(M),
            1.0,
            Ja,
            static_cast<blas_int>(M),
            x,
            1,
            0.0,
            Ua,
            1
        );
    }

    kf_blas_set_num_threads(saved_blas_threads_phase5);

    // 6) Per-block lower-triangle: tiled DGEMM approach for efficiency
    //    Compute D×tile_len*D Gram blocks per tile, then apply scaling +
    //    rank-1 correction, write directly to RFP. No H_temp needed.
    if (tile_B == 0) tile_B = std::min<std::size_t>(DEFAULT_TILE_SIZE, N);

    int saved_blas_threads_symm = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel
    {
        // Thread-local scratch: G_tile(D × tile_B*D) for tiled DGEMM + v1/v2 correction vectors
        double *G_tile = aligned_alloc_64(D * tile_B * D);
        std::vector<double> v1(D), v2(D);

#pragma omp for schedule(static)
        for (std::size_t a = 0; a < N; ++a) {
            const double *__restrict Ua = U.data() + a * D;
            const double *__restrict Va = V + (a * D) * N;
            // dX1 rows for block a: dX1 + a*D*M, shape (D × M)
            const double *__restrict Ja_hat = dX1 + a * D * M;

            for (std::size_t b0 = 0; b0 < a + 1; b0 += tile_B) {
                const std::size_t bend = std::min<std::size_t>(a + 1, b0 + tile_B);
                const std::size_t tile_len = bend - b0;

                // Tiled DGEMM: G_tile(D × tile_len*D) = Ja_hat(D×M) @ dX1[b0*D*M:]^T(M ×
                // tile_len*D)
                const double *__restrict Jb_tile = dX1 + b0 * D * M;
                cblas_dgemm(
                    CblasRowMajor,
                    CblasNoTrans,
                    CblasTrans,
                    static_cast<blas_int>(D),
                    static_cast<blas_int>(tile_len * D),
                    static_cast<blas_int>(M),
                    1.0,
                    Ja_hat,
                    static_cast<blas_int>(M),
                    Jb_tile,
                    static_cast<blas_int>(M),
                    0.0,
                    G_tile,
                    static_cast<blas_int>(tile_len * D)
                );

                for (std::size_t b = b0; b < bend; ++b) {
                    const double cab = C[a * N + b];
                    const double c4ab = C4[a * N + b];

                    // Extract D×D slice from G_tile for this b
                    const double *__restrict Gblk = G_tile + (b - b0) * D;

                    // v1 = U[a] - V[aD:(a+1)D, b]
#pragma omp simd
                    for (std::size_t i = 0; i < D; ++i)
                        v1[i] = Ua[i] - Va[i * N + b];

                    // v2 = V[bD:(b+1)D, a] - U[b]
                    const double *__restrict Ub = U.data() + b * D;
                    const double *__restrict Vb = V + (b * D) * N;
#pragma omp simd
                    for (std::size_t j = 0; j < D; ++j)
                        v2[j] = Vb[j * N + a] - Ub[j];

                    // Apply scaling + rank-1 correction and write to RFP.
                    // Global indices: row = a*D+i, col = b*D+j, row >= col for lower tri.
                    // For a > b all entries are lower-tri (row >= col always).
                    // For a == b only lower triangle (i >= j) is written.
                    for (std::size_t i = 0; i < D; ++i) {
                        const std::size_t row = a * D + i;
                        const std::size_t j_max = (a == b) ? (i + 1) : D;
                        const double *__restrict Grow = Gblk + i * tile_len * D;
                        for (std::size_t j = 0; j < j_max; ++j) {
                            const std::size_t col = b * D + j;
                            const double val = Grow[j] * cab - c4ab * v1[i] * v2[j];
                            // RFP upper: rfp_index_upper_N(BIG, col, row) with col <= row
                            H_rfp[rfp_index_upper_N(BIG, col, row)] = val;
                        }
                    }
                }
            }
        }
        aligned_free_64(G_tile);
    }

    kf_blas_set_num_threads(saved_blas_threads_symm);

    aligned_free_64(V);
    aligned_free_64(C4);
    aligned_free_64(C);
}

// ============================================================================
// Full combined energy+force kernel (asymmetric).
// Output K_full is (N1*(1+D1)) x (N2*(1+D2)), row-major (stride = full_cols).
//
// Block layout (full_cols = N2 + N2*D2 = N2*(1+D2)):
//   [0:N1,        0:N2]          scalar  K[a,b] = exp(-||x1a-x2b||^2/(2σ²))
//   [0:N1,        N2:full_cols]  jac_t   K_jt[a, b*D2+d] = C[a,b]*(U2[b,d] - V2X1[b,d,a])
//   [N1:,         0:N2]          jac     K_j[a*D1+d, b]  = C[a,b]*(V1X2[a,d,b] - U1[a,d])
//   [N1:,         N2:full_cols]  hessian H[a*D1+d1, b*D2+d2] (on-the-fly Gram)
//
// where:
//   C[a,b]  = exp(-0.5*inv_s2*sq) * inv_s2  (= K[a,b] / σ²)
//   C4[a,b] = exp(-0.5*inv_s2*sq) * inv_s4  (= K[a,b] / σ⁴)
//   V1X2[a,d,b] = (J1_hat row a*D1+d) · X2[b]   [rows of J1_hat dotted with X2 cols]
//   V2X1[b,d,a] = (J2_hat row b*D2+d) · X1[a]   [rows of J2_hat dotted with X1 cols]
//   U1[a,d]     = (J1_hat row a*D1+d) · X1[a]
//   U2[b,d]     = (J2_hat row b*D2+d) · X2[b]
// ============================================================================
void kernel_gaussian_full(
    const double *__restrict X1, const double *__restrict dX1, const double *__restrict X2,
    const double *__restrict dX2, std::size_t N1, std::size_t N2, std::size_t M, std::size_t D1,
    std::size_t D2, double sigma, std::size_t tile_B, double *__restrict K_full
) {
    if (!X1 || !dX1 || !X2 || !dX2 || !K_full) throw std::invalid_argument("null pointer");
    if (N1 == 0 || N2 == 0 || M == 0 || D1 == 0 || D2 == 0)
        throw std::invalid_argument("empty dimension");
    if (!(sigma > 0.0)) throw std::invalid_argument("sigma must be > 0");

    const double inv_s2 = 1.0 / (sigma * sigma);
    const double inv_s4 = inv_s2 * inv_s2;

    const std::size_t big_rows = N1 * D1;         // rows of hessian block
    const std::size_t big_cols = N2 * D2;         // cols of hessian block
    const std::size_t full_rows = N1 + big_rows;  // total rows of K_full
    const std::size_t full_cols = N2 + big_cols;  // total cols of K_full (= stride)

    // -------------------------------------------------------------------------
    // Phase 1: Distance coefficients C[a,b] = K/s^2, C4[a,b] = K/s^4
    // -------------------------------------------------------------------------
    std::vector<double> n1v(N1), n2v(N2);
#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N1; ++a) {
        const double *x = X1 + a * M;
        double s = 0.0;
#pragma omp simd reduction(+ : s)
        for (std::size_t i = 0; i < M; ++i)
            s += x[i] * x[i];
        n1v[a] = s;
    }
#pragma omp parallel for schedule(static)
    for (std::size_t b = 0; b < N2; ++b) {
        const double *x = X2 + b * M;
        double s = 0.0;
#pragma omp simd reduction(+ : s)
        for (std::size_t i = 0; i < M; ++i)
            s += x[i] * x[i];
        n2v[b] = s;
    }

    // Optimized: DGEMM with alpha=-2.0 writes -2*X1@X2^T directly to C, avoiding S allocation
    double *C = aligned_alloc_64(N1 * N2);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(N1),
        static_cast<blas_int>(N2),
        static_cast<blas_int>(M),
        -2.0,
        X1,
        static_cast<blas_int>(M),
        X2,
        static_cast<blas_int>(M),
        0.0,
        C,
        static_cast<blas_int>(N2)
    );

    double *C4 = aligned_alloc_64(N1 * N2);
#pragma omp parallel for collapse(2) schedule(static)
    for (std::size_t a = 0; a < N1; ++a) {
        for (std::size_t b = 0; b < N2; ++b) {
            // C[a,b] now holds -2*S[a,b], so: sq = n1v[a] + n2v[b] + C[a,b]
            const double sq = n1v[a] + n2v[b] + C[a * N2 + b];
            const double k = std::exp(-0.5 * inv_s2 * sq);
            C[a * N2 + b] = k * inv_s2;
            C4[a * N2 + b] = k * inv_s4;
        }
    }

    // -------------------------------------------------------------------------
    // Phase 2: dX1 and dX2 are already in (N*D × M) layout - no packing needed!
    // -------------------------------------------------------------------------

    // -------------------------------------------------------------------------
    // Phase 3: Projection tables
    //   V1X2 (big_rows x N2) = dX1 @ X2^T
    //   V2X1 (big_cols x N1) = dX2 @ X1^T
    //   dX1 and dX2 are already in (N*D × M) row-major layout
    // -------------------------------------------------------------------------
    double *V1X2 = aligned_alloc_64(big_rows * N2);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(big_rows),
        static_cast<blas_int>(N2),
        static_cast<blas_int>(M),
        1.0,
        dX1,
        static_cast<blas_int>(M),
        X2,
        static_cast<blas_int>(M),
        0.0,
        V1X2,
        static_cast<blas_int>(N2)
    );

    // Compute V2X1 in original layout, then transpose it for cache efficiency
    // Original: V2X1(big_cols × N1) = dX2 @ X1^T
    // Then transpose to: V2X1_T(N1 × big_cols) for contiguous v2 reads
    double *V2X1 = aligned_alloc_64(big_cols * N1);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(big_cols),
        static_cast<blas_int>(N1),
        static_cast<blas_int>(M),
        1.0,
        dX2,
        static_cast<blas_int>(M),
        X1,
        static_cast<blas_int>(M),
        0.0,
        V2X1,
        static_cast<blas_int>(N1)
    );

    // Transpose V2X1 to V2X1_T for better cache locality
    double *V2X1_T = aligned_alloc_64(N1 * big_cols);
#pragma omp parallel for schedule(static)
    for (std::size_t i = 0; i < big_cols; ++i) {
        for (std::size_t j = 0; j < N1; ++j) {
            V2X1_T[j * big_cols + i] = V2X1[i * N1 + j];
        }
    }
    aligned_free_64(V2X1);

    // -------------------------------------------------------------------------
    // Phase 4: Self projections U1[a*D1+d] = dX1[a,d,:] · X1[a,:]
    //                           U2[b*D2+d] = dX2[b,d,:] · X2[b,:]
    // -------------------------------------------------------------------------
    std::vector<double> U1(big_rows), U2(big_cols);

    int saved_blas_threads = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N1; ++a) {
        cblas_dgemv(
            CblasRowMajor,
            CblasNoTrans,
            static_cast<blas_int>(D1),
            static_cast<blas_int>(M),
            1.0,
            dX1 + a * D1 * M,
            static_cast<blas_int>(M),
            X1 + a * M,
            1,
            0.0,
            U1.data() + a * D1,
            1
        );
    }
#pragma omp parallel for schedule(static)
    for (std::size_t b = 0; b < N2; ++b) {
        cblas_dgemv(
            CblasRowMajor,
            CblasNoTrans,
            static_cast<blas_int>(D2),
            static_cast<blas_int>(M),
            1.0,
            dX2 + b * D2 * M,
            static_cast<blas_int>(M),
            X2 + b * M,
            1,
            0.0,
            U2.data() + b * D2,
            1
        );
    }

    kf_blas_set_num_threads(saved_blas_threads);

    // -------------------------------------------------------------------------
    // Phase 5: Fill K_full — all four blocks in a single pass over (a, b).
    //
    // Memory layout of K_full (stride = full_cols = N2 + N2*D2):
    //
    //   Scalar [a, b]:              K_full[a * full_cols + b]
    //   Jac_t  [a, N2 + b*D2 + d]: K_full[a * full_cols + N2 + b*D2 + d]
    //   Jac    [N1+a*D1+d, b]:      K_full[(N1 + a*D1 + d) * full_cols + b]
    //   Hess   [N1+a*D1+d1, N2+b*D2+d2]:
    //                               K_full[(N1+a*D1+d1)*full_cols + N2+b*D2+d2]
    // -------------------------------------------------------------------------
    if (tile_B == 0) tile_B = std::min<std::size_t>(DEFAULT_TILE_SIZE, N2);

    saved_blas_threads = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel
    {
        // Allocate tiled Gram buffer: G_tile(D1 × tile_B*D2) for one medium DGEMM per tile
        double *G_tile = aligned_alloc_64(D1 * tile_B * D2);
        std::vector<double> v1(D1), v2(D2);

#pragma omp for schedule(static)
        for (std::size_t a = 0; a < N1; ++a) {
            const double *U1a = U1.data() + a * D1;
            const double *V1X2a = V1X2 + (a * D1) * N2;  // (D1 x N2) block
            const double *J1a_hat = dX1 + a * D1 * M;    // (D1 x M) block

            // Row pointers in K_full for this 'a'
            double *Kscalar_row = K_full + a * full_cols;            // scalar and jac_t row
            double *Kjac_base = K_full + (N1 + a * D1) * full_cols;  // base for jac+hess rows

            for (std::size_t b0 = 0; b0 < N2; b0 += tile_B) {
                const std::size_t bend = std::min(N2, b0 + tile_B);
                const std::size_t tile_len = bend - b0;

                // Tiled DGEMM: G_tile(D1 × tile_len*D2) = J1a_hat(D1×M) @ dX2[b0*D2*M:]^T(M ×
                // tile_len*D2)
                const double *J2b_tile = dX2 + b0 * D2 * M;
                cblas_dgemm(
                    CblasRowMajor,
                    CblasNoTrans,
                    CblasTrans,
                    static_cast<blas_int>(D1),
                    static_cast<blas_int>(tile_len * D2),
                    static_cast<blas_int>(M),
                    1.0,
                    J1a_hat,
                    static_cast<blas_int>(M),
                    J2b_tile,
                    static_cast<blas_int>(M),
                    0.0,
                    G_tile,
                    static_cast<blas_int>(tile_len * D2)
                );

                for (std::size_t b = b0; b < bend; ++b) {
                    const double cab = C[a * N2 + b];
                    const double c4ab = C4[a * N2 + b];
                    // Recover raw kernel K = cab * sigma^2
                    const double kab = cab * sigma * sigma;

                    // ----- Scalar block [a, b] -----
                    Kscalar_row[b] = kab;

                    // ----- Jacobian_t block [a, N2 + b*D2 : N2 + (b+1)*D2] -----
                    // K_jt[a, b*D2+d] = C[a,b] * (V2X1_T[a, b*D2+d] - U2[b*D2+d])
                    // Matches standalone: diff = X1a - X2b, K_jt = coeff * J2b^T * diff
                    {
                        const double *U2b = U2.data() + b * D2;
                        const double *V2X1_T_row =
                            V2X1_T + a * big_cols + b * D2;  // contiguous access
                        double *Kjt_dest = Kscalar_row + N2 + b * D2;
#pragma omp simd
                        for (std::size_t d = 0; d < D2; ++d)
                            Kjt_dest[d] = cab * (V2X1_T_row[d] - U2b[d]);
                    }

                    // ----- Jacobian block [N1+a*D1 : N1+(a+1)*D1, b] -----
                    // K_j[a*D1+d, b] = C[a,b] * (V1X2[a*D1+d, b] - U1[a*D1+d])
                    {
                        for (std::size_t d = 0; d < D1; ++d) {
                            Kjac_base[d * full_cols + b] = cab * (V1X2a[d * N2 + b] - U1a[d]);
                        }
                    }

                    // ----- Hessian block [N1+a*D1+d1, N2+b*D2+d2] -----
                    // Extract D1×D2 slice from G_tile for this b
                    const double *Gblk = G_tile + (b - b0) * D2;

                    // v1[d] = U1[a*D1+d] - V1X2[a*D1+d, b]
#pragma omp simd
                    for (std::size_t d = 0; d < D1; ++d)
                        v1[d] = U1a[d] - V1X2a[d * N2 + b];

                    // v2[d] = V2X1_T[a, b*D2+d] - U2[b*D2+d]
                    const double *U2b = U2.data() + b * D2;
                    const double *V2X1_T_row = V2X1_T + a * big_cols + b * D2;
#pragma omp simd
                    for (std::size_t d = 0; d < D2; ++d)
                        v2[d] = V2X1_T_row[d] - U2b[d];

                    // Write hessian block
                    for (std::size_t d1 = 0; d1 < D1; ++d1) {
                        const double *Grow = Gblk + d1 * tile_len * D2;
                        double *Hrow = Kjac_base + d1 * full_cols + N2 + b * D2;
#pragma omp simd
                        for (std::size_t d2 = 0; d2 < D2; ++d2)
                            Hrow[d2] = Grow[d2] * cab - c4ab * v1[d1] * v2[d2];
                    }
                }
            }
        }
        aligned_free_64(G_tile);
    }

    kf_blas_set_num_threads(saved_blas_threads);

    aligned_free_64(V2X1_T);
    aligned_free_64(V1X2);
    aligned_free_64(C4);
    aligned_free_64(C);
}

// ============================================================================
// Full combined energy+force kernel (symmetric: X1==X2, D1==D2).
// Output K_full is (N*(1+D)) x (N*(1+D)), row-major, lower triangle only.
//
// Block layout (BIG = N*(1+D), full_cols = BIG):
//   [0:N,    0:N]     scalar block   (lower triangle)
//   [N:,     0:N]     jacobian block (all entries)
//   [0:N,    N:]      jacobian_t block (upper-left transpose of jacobian block — NOT stored,
//                      caller fills from lower triangle)
//   [N:,     N:]      hessian block  (lower triangle only)
//
// Note: This fills the lower triangle of K_full (row >= col).
// The scalar diagonal is K[a,a] = 1.0 (exp(0)).
// The jacobian_t upper block is the transpose of the jacobian lower-left block.
// The hessian block is symmetric; only lower triangle is filled.
// ============================================================================
void kernel_gaussian_full_symm(
    const double *__restrict X, const double *__restrict dX, std::size_t N, std::size_t M,
    std::size_t D, double sigma, std::size_t tile_B, double *__restrict K_full
) {
    if (!X || !dX || !K_full) throw std::invalid_argument("null pointer");
    if (N == 0 || M == 0 || D == 0) throw std::invalid_argument("empty dimension");
    if (!(sigma > 0.0)) throw std::invalid_argument("sigma must be > 0");

    const double inv_s2 = 1.0 / (sigma * sigma);
    const double inv_s4 = inv_s2 * inv_s2;

    const std::size_t big = N * D;      // rows/cols of hessian block
    const std::size_t BIG = N + big;    // total rows/cols of K_full
    const std::size_t full_cols = BIG;  // stride

    // ---- Phase 1: Distance coefficients (symmetric, lower triangle only) ----
    std::vector<double> nv(N);
#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        const double *x = X + a * M;
        double s = 0.0;
#pragma omp simd reduction(+ : s)
        for (std::size_t i = 0; i < M; ++i)
            s += x[i] * x[i];
        nv[a] = s;
    }

    // Optimized: DGEMM with alpha=-2.0 writes -2*X@X^T directly to C, avoiding S allocation
    double *C = aligned_alloc_64(N * N);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(N),
        static_cast<blas_int>(N),
        static_cast<blas_int>(M),
        -2.0,
        X,
        static_cast<blas_int>(M),
        X,
        static_cast<blas_int>(M),
        0.0,
        C,
        static_cast<blas_int>(N)
    );

    double *C4 = aligned_alloc_64(N * N);
#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        for (std::size_t b = 0; b <= a; ++b) {
            // C[a,b] now holds -2*S[a,b], so: sq = nv[a] + nv[b] + C[a,b]
            const double sq = nv[a] + nv[b] + C[a * N + b];
            const double k = std::exp(-0.5 * inv_s2 * sq);
            C[a * N + b] = k * inv_s2;
            C4[a * N + b] = k * inv_s4;
            // Mirror for projection table phases
            C[b * N + a] = C[a * N + b];
            C4[b * N + a] = C4[a * N + b];
        }
    }

    // ---- Phase 2: dX is already in (N*D × M) layout - no packing needed! ----

    // ---- Phase 3: Projection table V (big x N) = dX @ X^T ----
    double *V = aligned_alloc_64(big * N);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(big),
        static_cast<blas_int>(N),
        static_cast<blas_int>(M),
        1.0,
        dX,
        static_cast<blas_int>(M),
        X,
        static_cast<blas_int>(M),
        0.0,
        V,
        static_cast<blas_int>(N)
    );

    // ---- Phase 4: Self projections U[a*D+d] = dX[a,d,:] · X[a,:] ----
    std::vector<double> U(big);

    int saved_blas_threads = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        cblas_dgemv(
            CblasRowMajor,
            CblasNoTrans,
            static_cast<blas_int>(D),
            static_cast<blas_int>(M),
            1.0,
            dX + a * D * M,
            static_cast<blas_int>(M),
            X + a * M,
            1,
            0.0,
            U.data() + a * D,
            1
        );
    }

    kf_blas_set_num_threads(saved_blas_threads);

    // ---- Phase 5: Fill K_full lower triangle ----
    // For (a, b) pairs with a >= b:
    //   Scalar:   [a, b]               C[a,b]*s^2  (and [b,a] by symmetry)
    //   Jac:      [N+a*D+d, b]         C[a,b]*(V[a,d,b] - U[a,d])
    //   Jac_t:    [b, N+a*D+d]         = Jac^T (upper triangle — don't fill)
    //             [a, N+b*D+d] lower   C[a,b]*(U[b,d] - V[b,d,a])
    //   Hessian:  [N+a*D+d1, N+b*D+d2] (lower: a>=b only full rows, within a==b lower tri)

    if (tile_B == 0) tile_B = std::min<std::size_t>(DEFAULT_TILE_SIZE, N);

    saved_blas_threads = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel
    {
        // Allocate tiled Gram buffer: G_tile(D × tile_B*D) for one medium DGEMM per tile
        double *G_tile = aligned_alloc_64(D * tile_B * D);
        std::vector<double> v1(D), v2(D);

#pragma omp for schedule(static)
        for (std::size_t a = 0; a < N; ++a) {
            const double *Ua = U.data() + a * D;
            const double *Va = V + (a * D) * N;  // row group for a: (D x N)
            const double *Ja_hat = dX + a * D * M;

            double *row_scalar_a = K_full + a * full_cols;           // row a (scalar+jact)
            double *rows_hess_a = K_full + (N + a * D) * full_cols;  // rows N+a*D.. of K_full

            for (std::size_t b0 = 0; b0 <= a; b0 += tile_B) {
                const std::size_t bend = std::min<std::size_t>(a + 1, b0 + tile_B);
                const std::size_t tile_len = bend - b0;

                // Tiled DGEMM: G_tile(D × tile_len*D) = Ja_hat(D×M) @ dX[b0*D*M:]^T(M × tile_len*D)
                const double *Jb_tile = dX + b0 * D * M;
                cblas_dgemm(
                    CblasRowMajor,
                    CblasNoTrans,
                    CblasTrans,
                    static_cast<blas_int>(D),
                    static_cast<blas_int>(tile_len * D),
                    static_cast<blas_int>(M),
                    1.0,
                    Ja_hat,
                    static_cast<blas_int>(M),
                    Jb_tile,
                    static_cast<blas_int>(M),
                    0.0,
                    G_tile,
                    static_cast<blas_int>(tile_len * D)
                );

                for (std::size_t b = b0; b < bend; ++b) {
                    const double cab = C[a * N + b];
                    const double c4ab = C4[a * N + b];
                    const double kab = cab * sigma * sigma;

                    const double *Ub = U.data() + b * D;
                    const double *Vb = V + (b * D) * N;  // (D x N)

                    // ---- Scalar block (lower triangle) ----
                    // [a, b] and diagonal
                    row_scalar_a[b] = kab;
                    if (a == b) {
                        // Self kernel = exp(0) = 1.0; also fill diagonal of scalar block
                        row_scalar_a[b] = 1.0;
                    }
                    if (b < a) {
                        // [b, a] = [a, b] (mirror into upper scalar block)
                        K_full[b * full_cols + a] = kab;
                    }

                    // ---- Jacobian block: rows N+a*D..N+(a+1)*D, col b ----
                    // K_j[a*D+d, b] = C[a,b] * (V[a,d,b] - U[a,d])
                    // Also fill jacobian_t: [b, N+a*D+d] = same value (transpose)
                    for (std::size_t d = 0; d < D; ++d) {
                        const double val_j = cab * (Va[d * N + b] - Ua[d]);
                        rows_hess_a[(long)(d * full_cols) + (long)b] = val_j;
                        // Jacobian_t (upper triangle): [b, N+a*D+d]
                        K_full[b * full_cols + N + a * D + d] = val_j;
                    }

                    // ---- If a > b: also fill jacobian for b at col a ----
                    // K_j[b*D+d, a] = C[b,a] * (V[b,d,a] - U[b,d])
                    if (b < a) {
                        double *rows_hess_b = K_full + (N + b * D) * full_cols;
                        for (std::size_t d = 0; d < D; ++d) {
                            const double val_j = cab * (Vb[d * N + a] - Ub[d]);
                            rows_hess_b[d * full_cols + a] = val_j;
                            // Jacobian_t [a, N+b*D+d]
                            K_full[a * full_cols + N + b * D + d] = val_j;
                        }
                    }

                    // ---- Hessian block [N+a*D+d1, N+b*D+d2] (lower triangle: b <= a) ----
                    // Extract D×D slice from G_tile for this b
                    const double *Gblk = G_tile + (b - b0) * D;

                    // v1[d] = U[a,d] - V[a,d,b]
#pragma omp simd
                    for (std::size_t d = 0; d < D; ++d)
                        v1[d] = Ua[d] - Va[d * N + b];
                    // v2[d] = V[b,d,a] - U[b,d]
#pragma omp simd
                    for (std::size_t d = 0; d < D; ++d)
                        v2[d] = Vb[d * N + a] - Ub[d];

                    if (a == b) {
                        // Diagonal hessian block: fill lower triangle then mirror to upper
                        for (std::size_t d1 = 0; d1 < D; ++d1) {
                            const double *Grow = Gblk + d1 * tile_len * D;
                            double *Hrow = rows_hess_a + d1 * full_cols + N + b * D;
                            for (std::size_t d2 = 0; d2 <= d1; ++d2)
                                Hrow[d2] = Grow[d2] * cab - c4ab * v1[d1] * v2[d2];
                        }
                        // Mirror lower→upper within diagonal D×D block
                        for (std::size_t d1 = 0; d1 < D; ++d1) {
                            for (std::size_t d2 = d1 + 1; d2 < D; ++d2) {
                                rows_hess_a[d1 * full_cols + N + b * D + d2] =
                                    rows_hess_a[d2 * full_cols + N + b * D + d1];
                            }
                        }
                    } else {
                        // Off-diagonal: fill all D×D entries for [N+a*D:, N+b*D:]
                        for (std::size_t d1 = 0; d1 < D; ++d1) {
                            const double *Grow = Gblk + d1 * tile_len * D;
                            double *Hrow = rows_hess_a + d1 * full_cols + N + b * D;
#pragma omp simd
                            for (std::size_t d2 = 0; d2 < D; ++d2)
                                Hrow[d2] = Grow[d2] * cab - c4ab * v1[d1] * v2[d2];
                        }
                    }
                }
            }
        }
        aligned_free_64(G_tile);
    }

    kf_blas_set_num_threads(saved_blas_threads);

    // ---- Mirror off-diagonal hessian blocks to upper triangle ----
    // For each pair (a > b), the block at [N+a*D:, N+b*D:] (D×D) has been filled.
    // We now copy it transposed to [N+b*D:, N+a*D:].
#pragma omp parallel for schedule(static)
    for (std::size_t a = 1; a < N; ++a) {
        for (std::size_t b = 0; b < a; ++b) {
            for (std::size_t d1 = 0; d1 < D; ++d1) {
                for (std::size_t d2 = 0; d2 < D; ++d2) {
                    // Source: K_full[N+a*D+d1, N+b*D+d2]
                    // Dest:   K_full[N+b*D+d2, N+a*D+d1]
                    K_full[(N + b * D + d2) * full_cols + (N + a * D + d1)] =
                        K_full[(N + a * D + d1) * full_cols + (N + b * D + d2)];
                }
            }
        }
    }

    aligned_free_64(V);
    aligned_free_64(C4);
    aligned_free_64(C);
}

// ============================================================================
// Full combined energy+force kernel (symmetric RFP format).
// Output: 1D RFP array of length BIG*(BIG+1)/2, where BIG = N*(1+D).
// Uses the same RFP indexing as kernel_gaussian_hessian_symm_rfp (TRANSR='N', UPLO='U').
// ============================================================================
void kernel_gaussian_full_symm_rfp(
    const double *__restrict X, const double *__restrict dX, std::size_t N, std::size_t M,
    std::size_t D, double sigma, std::size_t tile_B, double *__restrict K_rfp
) {
    if (!X || !dX || !K_rfp) throw std::invalid_argument("null pointer");
    if (N == 0 || M == 0 || D == 0) throw std::invalid_argument("empty dimension");
    if (!(sigma > 0.0)) throw std::invalid_argument("sigma must be > 0");

    const double inv_s2 = 1.0 / (sigma * sigma);
    const double inv_s4 = inv_s2 * inv_s2;

    const std::size_t big = N * D;
    const std::size_t BIG = N + big;  // = N*(1+D)
    const std::size_t rfp_size = BIG * (BIG + 1) / 2;

    // ---- Phase 1: Distance coefficients ----
    std::vector<double> nv(N);
#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        const double *x = X + a * M;
        double s = 0.0;
#pragma omp simd reduction(+ : s)
        for (std::size_t i = 0; i < M; ++i)
            s += x[i] * x[i];
        nv[a] = s;
    }

    // Optimized: DGEMM with alpha=-2.0 writes -2*X@X^T directly to C, avoiding S allocation
    double *C = aligned_alloc_64(N * N);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(N),
        static_cast<blas_int>(N),
        static_cast<blas_int>(M),
        -2.0,
        X,
        static_cast<blas_int>(M),
        X,
        static_cast<blas_int>(M),
        0.0,
        C,
        static_cast<blas_int>(N)
    );

    double *C4 = aligned_alloc_64(N * N);
#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        for (std::size_t b = 0; b <= a; ++b) {
            // C[a,b] now holds -2*S[a,b], so: sq = nv[a] + nv[b] + C[a,b]
            const double sq = nv[a] + nv[b] + C[a * N + b];
            const double k = std::exp(-0.5 * inv_s2 * sq);
            C[a * N + b] = C[b * N + a] = k * inv_s2;
            C4[a * N + b] = C4[b * N + a] = k * inv_s4;
        }
    }

    // ---- Phase 2: dX is already in (N*D × M) layout - no packing needed! ----

    // ---- Phase 3: Projection table V (big x N) ----
    double *V = aligned_alloc_64(big * N);
    cblas_dgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasTrans,
        static_cast<blas_int>(big),
        static_cast<blas_int>(N),
        static_cast<blas_int>(M),
        1.0,
        dX,
        static_cast<blas_int>(M),
        X,
        static_cast<blas_int>(M),
        0.0,
        V,
        static_cast<blas_int>(N)
    );

    // ---- Phase 4: Self projections ----
    std::vector<double> U(big);

    int saved_blas_threads = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel for schedule(static)
    for (std::size_t a = 0; a < N; ++a) {
        cblas_dgemv(
            CblasRowMajor,
            CblasNoTrans,
            static_cast<blas_int>(D),
            static_cast<blas_int>(M),
            1.0,
            dX + a * D * M,
            static_cast<blas_int>(M),
            X + a * M,
            1,
            0.0,
            U.data() + a * D,
            1
        );
    }

    kf_blas_set_num_threads(saved_blas_threads);

    // ---- Phase 5: Fill RFP ----
    // RFP index for (row, col) in the upper triangle of a BIG×BIG symmetric matrix.
    // We use the same rfp_index_upper_N helper (for std::size_t).
    // The matrix is indexed as: K_full[row, col] with row <= col (upper convention).
    //
    // Our block structure in K_full (global row/col 0-based):
    //   Scalar block:    rows [0,N),  cols [0,N)
    //   Jac_t block:     rows [0,N),  cols [N, BIG)  = [0,N) x [N+a*D, N+(a+1)*D)
    //   Hessian block:   rows [N,BIG), cols [N,BIG)
    //
    // The Jacobian block (lower-left) has row>=col in upper-triangle sense only when
    // row >= N (hessian rows) and col < N (scalar cols) — that's the lower-left,
    // which is NOT in upper triangle. We store the UPPER triangle (row<=col), so:
    //   Scalar:   row=a, col=b, a<=b  => rfp(a, b)
    //   Jac_t:    row=a, col=N+b*D+d, a < N+b*D+d  => rfp(a, N+b*D+d)
    //   Hessian:  row=N+a*D+d1, col=N+b*D+d2, d1<=d2 when a==b, any when a<b
    //             => rfp(N+a*D+d1, N+b*D+d2) for a<=b

    if (tile_B == 0) tile_B = std::min<std::size_t>(DEFAULT_TILE_SIZE, N);

    saved_blas_threads = kf_blas_get_num_threads();
    kf_blas_set_num_threads(1);

#pragma omp parallel
    {
        // Allocate tiled Gram buffer: G_tile(D × tile_B*D) for one medium DGEMM per tile
        double *G_tile = aligned_alloc_64(D * tile_B * D);
        std::vector<double> v1(D), v2(D);

#pragma omp for schedule(static)
        for (std::size_t a = 0; a < N; ++a) {
            const double *Ua = U.data() + a * D;
            const double *Va = V + (a * D) * N;
            const double *Ja_hat = dX + a * D * M;

            // Upper triangle tiling: b0 from a to N
            for (std::size_t b0 = a; b0 < N; b0 += tile_B) {
                const std::size_t bend = std::min<std::size_t>(N, b0 + tile_B);
                const std::size_t tile_len = bend - b0;

                // Tiled DGEMM: G_tile(D × tile_len*D) = Ja_hat(D×M) @ dX[b0*D*M:]^T(M × tile_len*D)
                const double *Jb_tile = dX + b0 * D * M;
                cblas_dgemm(
                    CblasRowMajor,
                    CblasNoTrans,
                    CblasTrans,
                    static_cast<blas_int>(D),
                    static_cast<blas_int>(tile_len * D),
                    static_cast<blas_int>(M),
                    1.0,
                    Ja_hat,
                    static_cast<blas_int>(M),
                    Jb_tile,
                    static_cast<blas_int>(M),
                    0.0,
                    G_tile,
                    static_cast<blas_int>(tile_len * D)
                );

                for (std::size_t b = b0; b < bend; ++b) {  // upper triangle: b >= a
                    const double cab = C[a * N + b];
                    const double c4ab = C4[a * N + b];
                    const double kab = cab * sigma * sigma;

                    const double *Ub = U.data() + b * D;
                    const double *Vb = V + (b * D) * N;

                    // ---- Scalar block [a, b] (upper: a <= b) ----
                    K_rfp[rfp_index_upper_N(BIG, a, b)] = (a == b) ? 1.0 : kab;

                    // ---- Jac_t block: [a, N+b*D+d] (always upper since N+b*D+d > a for any a<N)
                    // ---- K_full[a, N+b*D+d] = K_j[N+b*D+d, a] = C[a,b] * (V[b,d,a] - U[b,d])
                    for (std::size_t d = 0; d < D; ++d) {
                        const std::size_t col = N + b * D + d;
                        K_rfp[rfp_index_upper_N(BIG, a, col)] = cab * (Vb[d * N + a] - Ub[d]);
                    }

                    if (a < b) {
                        // ---- Jac_t block: [b, N+a*D+d] (b < N+a*D+d always) ----
                        // K_full[b, N+a*D+d] = K_j[N+a*D+d, b] = C[a,b] * (V[a,d,b] - U[a,d])
                        for (std::size_t d = 0; d < D; ++d) {
                            const std::size_t col = N + a * D + d;
                            K_rfp[rfp_index_upper_N(BIG, b, col)] = cab * (Va[d * N + b] - Ua[d]);
                        }
                    }

                    // ---- Hessian block [N+a*D+d1, N+b*D+d2] ----
                    // Extract D×D slice from G_tile for this b
                    const double *Gblk = G_tile + (b - b0) * D;

#pragma omp simd
                    for (std::size_t d = 0; d < D; ++d)
                        v1[d] = Ua[d] - Va[d * N + b];
#pragma omp simd
                    for (std::size_t d = 0; d < D; ++d)
                        v2[d] = Vb[d * N + a] - Ub[d];

                    if (a == b) {
                        // Diagonal: upper triangle d1 <= d2
                        for (std::size_t d1 = 0; d1 < D; ++d1) {
                            const double *Grow = Gblk + d1 * tile_len * D;
                            for (std::size_t d2 = d1; d2 < D; ++d2) {
                                const std::size_t row = N + a * D + d1;
                                const std::size_t col = N + b * D + d2;
                                K_rfp[rfp_index_upper_N(BIG, row, col)] =
                                    Grow[d2] * cab - c4ab * v1[d1] * v2[d2];
                            }
                        }
                    } else {
                        // Off-diagonal: all D*D entries
                        for (std::size_t d1 = 0; d1 < D; ++d1) {
                            const double *Grow = Gblk + d1 * tile_len * D;
                            for (std::size_t d2 = 0; d2 < D; ++d2) {
                                const std::size_t row = N + a * D + d1;
                                const std::size_t col = N + b * D + d2;
                                K_rfp[rfp_index_upper_N(BIG, row, col)] =
                                    Grow[d2] * cab - c4ab * v1[d1] * v2[d2];
                            }
                        }
                    }
                }
            }
        }
        aligned_free_64(G_tile);
    }

    kf_blas_set_num_threads(saved_blas_threads);

    aligned_free_64(V);
    aligned_free_64(C4);
    aligned_free_64(C);
}

}  // namespace kf
