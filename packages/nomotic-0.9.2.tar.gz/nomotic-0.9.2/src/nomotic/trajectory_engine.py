"""Behavioral trajectory engine — predicting drift before it happens.

Every governance system in the market is reactive. The Behavioral Trajectory
Engine makes Nomotic proactive: it projects behavioral drift forward,
computes violation probabilities against the active contract, and triggers
graduated interventions before violations actually occur.

Closed-loop behavioral control: detect trajectory -> project forward ->
intervene proportionally -> verify correction.
"""

from __future__ import annotations

import threading
import time as _time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from nomotic.drift import DriftScore

if TYPE_CHECKING:
    from nomotic.contract import ContractStore
    from nomotic.observer import FingerprintObserver
    from nomotic.policy_optimizer import InterventionPolicy, PolicyOptimizer

__all__ = [
    "BehavioralTrajectoryEngine",
    "InterventionAction",
    "TrajectoryConfig",
    "TrajectoryProjection",
]

_DISTRIBUTIONS = ("action", "target", "temporal", "outcome", "semantic")


@dataclass(frozen=True)
class TrajectoryProjection:
    """Forward projection of an agent's behavioral trajectory.

    Contains per-invariant and per-distribution violation probabilities,
    a risk level, and a recommended intervention.
    """

    agent_id: str
    projection_horizon: int
    timestamp: float

    invariant_projections: tuple[dict[str, Any], ...] = ()
    projected_drift: dict[str, float] = field(default_factory=dict)

    risk_level: str = "low"
    highest_risk_invariant: str = ""
    highest_risk_distribution: str = ""

    recommended_intervention: str = "none"
    intervention_reason: str = ""
    intervention_policy: InterventionPolicy | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-friendly dict."""
        result = {
            "agent_id": self.agent_id,
            "projection_horizon": self.projection_horizon,
            "timestamp": self.timestamp,
            "invariant_projections": list(self.invariant_projections),
            "projected_drift": {k: round(v, 6) for k, v in self.projected_drift.items()},
            "risk_level": self.risk_level,
            "highest_risk_invariant": self.highest_risk_invariant,
            "highest_risk_distribution": self.highest_risk_distribution,
            "recommended_intervention": self.recommended_intervention,
            "intervention_reason": self.intervention_reason,
        }
        if self.intervention_policy is not None:
            result["intervention_policy"] = self.intervention_policy.to_dict()
        return result


@dataclass
class InterventionAction:
    """A proactive intervention triggered by trajectory projection."""

    action_type: str  # "advisory", "throttle", "escalate", "tighten"
    agent_id: str
    reason: str
    timestamp: float
    projection: TrajectoryProjection | None = None
    applied: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-friendly dict."""
        return {
            "action_type": self.action_type,
            "agent_id": self.agent_id,
            "reason": self.reason,
            "timestamp": self.timestamp,
            "projection": self.projection.to_dict() if self.projection else None,
            "applied": self.applied,
        }


@dataclass
class TrajectoryConfig:
    """Configuration for the behavioral trajectory engine."""

    projection_horizon: int = 100
    check_interval: int = 25
    advisory_threshold: float = 0.3
    throttle_threshold: float = 0.5
    escalate_threshold: float = 0.7
    tighten_threshold: float = 0.9
    enable_auto_intervention: bool = False
    tighten_requires_approval: bool = True


class BehavioralTrajectoryEngine:
    """Projects agent behavioral trajectories and triggers proactive interventions.

    The engine continuously tracks drift velocity across all five distributions,
    projects forward against the active contract, and applies graduated
    interventions before violations occur.
    """

    def __init__(
        self,
        config: TrajectoryConfig | None = None,
        fingerprint_observer: FingerprintObserver | None = None,
        contract_store: ContractStore | None = None,
        policy_optimizer: PolicyOptimizer | None = None,
    ) -> None:
        self._config = config or TrajectoryConfig()
        self._fp_observer = fingerprint_observer
        self._contract_store = contract_store
        self._optimizer = policy_optimizer
        self._projections: dict[str, TrajectoryProjection] = {}
        self._interventions: list[InterventionAction] = []
        self._observation_counts: dict[str, int] = {}
        self._drift_history: dict[str, list[tuple[float, DriftScore]]] = {}
        self._lock = threading.Lock()

    # ── Drift recording ────────────────────────────────────────────

    def record_drift(self, agent_id: str, drift_score: DriftScore) -> None:
        """Record a drift observation for velocity computation.

        Maintains the last 10 drift observations per agent.
        """
        with self._lock:
            history = self._drift_history.setdefault(agent_id, [])
            history.append((_time.time(), drift_score))
            if len(history) > 10:
                self._drift_history[agent_id] = history[-10:]

    # ── Velocity computation ───────────────────────────────────────

    def _compute_drift_velocity(self, agent_id: str) -> dict[str, float]:
        """Compute rate of change per distribution from drift history.

        Returns per-observation velocity for each of the five distributions.
        """
        history = self._drift_history.get(agent_id, [])
        if len(history) < 2:
            return {d: 0.0 for d in _DISTRIBUTIONS}

        earliest_t, earliest_drift = history[0]
        latest_t, latest_drift = history[-1]
        dt = latest_t - earliest_t
        if dt <= 0:
            return {d: 0.0 for d in _DISTRIBUTIONS}

        velocity: dict[str, float] = {}
        for dist in _DISTRIBUTIONS:
            latest_val = getattr(latest_drift, f"{dist}_drift", 0.0)
            earliest_val = getattr(earliest_drift, f"{dist}_drift", 0.0)
            velocity[dist] = (latest_val - earliest_val) / dt
        return velocity

    # ── Violation probability projection ───────────────────────────

    @staticmethod
    def _project_violation_probability(
        current_value: float,
        threshold: float,
        velocity: float,
        horizon: int,
    ) -> tuple[float, int]:
        """Project when a threshold will be crossed.

        Returns (violation_probability, projected_step_of_violation).
        A projected_step of -1 means no crossing within the horizon.
        """
        if velocity <= 0:
            return (0.0, -1)

        projected_value = current_value + velocity * horizon
        if projected_value < threshold:
            prob = projected_value / threshold if threshold > 0 else 0.0
            return (max(0.0, min(1.0, prob)), -1)

        steps_to_violation = (threshold - current_value) / velocity
        prob = min(1.0, 1.0 - (steps_to_violation / horizon))
        return (max(0.0, prob), int(steps_to_violation))

    # ── Core projection ────────────────────────────────────────────

    def project(self, agent_id: str) -> TrajectoryProjection | None:
        """Project an agent's behavioral trajectory forward.

        Uses current drift, drift velocity, and the active contract to
        compute violation probabilities for each distribution and invariant.
        """
        if self._contract_store is None or self._fp_observer is None:
            return None

        contract = self._contract_store.get_active(agent_id)
        if contract is None:
            return None

        drift = self._fp_observer.get_drift(agent_id)
        if drift is None:
            return None

        velocity = self._compute_drift_velocity(agent_id)
        horizon = self._config.projection_horizon

        # Project per-distribution violations
        projected_drift: dict[str, float] = {}
        max_prob = 0.0
        max_dist = ""
        invariant_projections: list[dict[str, Any]] = []

        for dist in _DISTRIBUTIONS:
            current = getattr(drift, f"{dist}_drift", 0.0)
            vel = velocity.get(dist, 0.0)
            projected_drift[dist] = current + vel * horizon

            if dist in contract.drift_thresholds:
                threshold = contract.drift_thresholds[dist]
                prob, step = self._project_violation_probability(
                    current, threshold, vel, horizon,
                )
                inv_proj = {
                    "invariant_id": f"drift_threshold_{dist}",
                    "violation_probability": round(prob, 6),
                    "projected_violation_at": step,
                    "current_margin": round(
                        max(0.0, (threshold - current) / threshold) if threshold > 0 else 1.0,
                        4,
                    ),
                }
                invariant_projections.append(inv_proj)
                if prob > max_prob:
                    max_prob = prob
                    max_dist = dist

        # Project invariant violations from contract invariants
        max_inv_id = ""
        if contract.invariants:
            compiled = contract.compile_invariants()
            fingerprint = self._fp_observer.get_fingerprint(agent_id)
            semantic_drift = self._fp_observer.get_semantic_drift(agent_id)
            results = compiled.evaluate(
                fingerprint=fingerprint,
                drift_score=drift,
                semantic_drift=semantic_drift,
            )
            for result in results:
                margin = result.margin
                # Use overall drift velocity as proxy for invariant margin erosion
                overall_vel = sum(abs(v) for v in velocity.values()) / max(len(velocity), 1)
                if overall_vel > 0 and margin > 0:
                    steps_to_zero_margin = margin / overall_vel
                    if steps_to_zero_margin < horizon:
                        prob = min(1.0, 1.0 - (steps_to_zero_margin / horizon))
                    else:
                        prob = (overall_vel * horizon) / margin if margin > 0 else 0.0
                        prob = min(1.0, max(0.0, prob))
                else:
                    prob = 0.0

                inv_proj = {
                    "invariant_id": result.invariant_id,
                    "violation_probability": round(prob, 6),
                    "projected_violation_at": int(steps_to_zero_margin)
                    if overall_vel > 0 and margin > 0 and steps_to_zero_margin < horizon else -1,
                    "current_margin": round(margin, 4),
                }
                invariant_projections.append(inv_proj)
                if prob > max_prob:
                    max_prob = prob
                    max_inv_id = result.invariant_id

        # Determine risk level and intervention
        risk_level, intervention = self._classify_risk(max_prob)

        reason = ""
        if intervention != "none":
            if max_inv_id:
                reason = f"Invariant '{max_inv_id}' projected violation probability {max_prob:.2f}"
            elif max_dist:
                reason = f"Distribution '{max_dist}' projected violation probability {max_prob:.2f}"

        projection = TrajectoryProjection(
            agent_id=agent_id,
            projection_horizon=horizon,
            timestamp=_time.time(),
            invariant_projections=tuple(invariant_projections),
            projected_drift=projected_drift,
            risk_level=risk_level,
            highest_risk_invariant=max_inv_id,
            highest_risk_distribution=max_dist,
            recommended_intervention=intervention,
            intervention_reason=reason,
        )

        with self._lock:
            self._projections[agent_id] = projection
        return projection

    def _classify_risk(self, max_prob: float) -> tuple[str, str]:
        """Map violation probability to risk level and intervention type."""
        cfg = self._config
        if max_prob >= cfg.tighten_threshold:
            risk = "critical"
            intervention = "escalate" if cfg.tighten_requires_approval else "tighten"
        elif max_prob >= cfg.escalate_threshold:
            risk = "high"
            intervention = "escalate"
        elif max_prob >= cfg.throttle_threshold:
            risk = "high"
            intervention = "throttle"
        elif max_prob >= cfg.advisory_threshold:
            risk = "moderate"
            intervention = "advisory"
        else:
            risk = "low"
            intervention = "none"
        return risk, intervention

    # ── Observation hook ───────────────────────────────────────────

    def on_observation(
        self, agent_id: str, drift_score: DriftScore,
    ) -> InterventionAction | None:
        """Called after each drift computation.

        Records the drift, and every ``check_interval`` observations,
        projects the trajectory and optionally triggers an intervention.
        """
        self.record_drift(agent_id, drift_score)

        with self._lock:
            count = self._observation_counts.get(agent_id, 0) + 1
            self._observation_counts[agent_id] = count

        if count % self._config.check_interval != 0:
            return None

        projection = self.project(agent_id)
        if projection is None:
            return None

        # Run policy optimizer if available — overrides simple threshold recommendation
        if self._optimizer is not None and self._contract_store is not None:
            self._run_optimizer(agent_id, projection)

        if (
            projection.recommended_intervention != "none"
            and self._config.enable_auto_intervention
        ):
            action = InterventionAction(
                action_type=projection.recommended_intervention,
                agent_id=agent_id,
                reason=projection.intervention_reason,
                timestamp=_time.time(),
                projection=projection,
            )
            with self._lock:
                self._interventions.append(action)
            return action

        return None

    def _run_optimizer(
        self, agent_id: str, projection: TrajectoryProjection,
    ) -> None:
        """Run the policy optimizer and attach results to the projection."""
        assert self._optimizer is not None  # noqa: S101
        assert self._contract_store is not None  # noqa: S101

        contract = self._contract_store.get_active(agent_id)
        if contract is None:
            return

        # Get archetype from contract
        archetype = getattr(contract, "archetype", "default") or "default"

        # Build cost profile from contract
        from nomotic.cost_profile import CostProfile

        cost_profile_data = getattr(contract, "cost_profile", None)
        if cost_profile_data and isinstance(cost_profile_data, dict):
            cost_profile = CostProfile.from_dict(cost_profile_data)
        else:
            cost_profile = CostProfile()

        # Compute overall drift and velocity
        drift = self._fp_observer.get_drift(agent_id) if self._fp_observer else None
        if drift is None:
            return

        current_drift = drift.overall
        velocity = self._compute_drift_velocity(agent_id)
        overall_vel = sum(velocity.values()) / max(len(velocity), 1)

        policy = self._optimizer.optimize(
            agent_id=agent_id,
            current_drift=current_drift,
            velocity=overall_vel,
            archetype=archetype,
            cost_profile=cost_profile,
            drift_thresholds=contract.drift_thresholds,
        )

        # Attach policy to projection (frozen dataclass — use object.__setattr__)
        object.__setattr__(projection, "intervention_policy", policy)

        # Override recommended intervention from policy schedule
        if policy.intervention_schedule:
            first_type = policy.intervention_schedule[0][0]
            object.__setattr__(projection, "recommended_intervention", first_type)
            reason = (
                f"Policy optimizer: {policy.strategy_name} "
                f"(cost={policy.expected_total_cost:.4f}, "
                f"confidence={policy.confidence:.2f})"
            )
            object.__setattr__(projection, "intervention_reason", reason)

    # ── Accessors ──────────────────────────────────────────────────

    def get_projection(self, agent_id: str) -> TrajectoryProjection | None:
        """Return the latest projection for an agent."""
        with self._lock:
            return self._projections.get(agent_id)

    def get_interventions(
        self, agent_id: str | None = None,
    ) -> list[InterventionAction]:
        """Return intervention history, optionally filtered by agent."""
        with self._lock:
            if agent_id is None:
                return list(self._interventions)
            return [i for i in self._interventions if i.agent_id == agent_id]
