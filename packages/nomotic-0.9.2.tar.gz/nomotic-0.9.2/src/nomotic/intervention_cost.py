"""Intervention cost model — quantifying the cost of governance actions.

Each intervention type has a base cost, contextual multipliers, and
fatigue effects. Costs are distributions (mean + variance) for Monte
Carlo uncertainty propagation.
"""

from __future__ import annotations

import random
import threading
import time as _time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nomotic.cost_profile import CostProfile

__all__ = [
    "CostModelConfig",
    "InterventionCost",
    "InterventionCostModel",
]


@dataclass(frozen=True)
class InterventionCost:
    """Cost of one intervention, as a distribution."""

    mean: float
    variance: float = 0.0
    fatigue_multiplier: float = 1.0
    detail: str = ""

    @property
    def effective(self) -> float:
        """Mean cost adjusted by fatigue."""
        return self.mean * self.fatigue_multiplier

    def sample(self) -> float:
        """Sample from the cost distribution (for Monte Carlo).

        Uses normal distribution clamped to >= 0.
        """
        if self.variance <= 0:
            return self.effective
        return max(0.0, random.gauss(self.effective, self.variance ** 0.5))


@dataclass
class CostModelConfig:
    """Configuration for the intervention cost model."""

    base_costs: dict[str, float] = field(default_factory=lambda: {
        "advisory": 0.01,
        "throttle": 0.08,
        "escalate": 0.15,
        "tighten": 0.12,
        "quarantine": 0.25,
    })
    base_variances: dict[str, float] = field(default_factory=lambda: {
        "advisory": 0.005,
        "throttle": 0.03,
        "escalate": 0.05,
        "tighten": 0.04,
        "quarantine": 0.08,
    })
    fatigue_base: float = 1.5
    fatigue_window: int = 10
    strategy_failure_threshold: int = 3


class InterventionCostModel:
    """Computes intervention costs with fatigue and failure detection."""

    def __init__(self, config: CostModelConfig | None = None) -> None:
        self._config = config or CostModelConfig()
        # agent_id -> [(timestamp, intervention_type)]
        self._intervention_history: dict[str, list[tuple[float, str]]] = {}
        self._lock = threading.Lock()

    def compute_cost(
        self,
        intervention_type: str,
        agent_id: str,
        cost_profile: CostProfile | None = None,
    ) -> InterventionCost:
        """Compute the cost of an intervention for a specific agent.

        1. Base cost from config.
        2. If cost_profile available and intervention is "escalate",
           use escalation costs from profile.
        3. Count recent same-type interventions in fatigue window.
        4. Fatigue multiplier = fatigue_base ^ recent_count.
        5. Return InterventionCost with mean, variance, and fatigue_multiplier.
        """
        cfg = self._config
        mean = cfg.base_costs.get(intervention_type, 0.1)
        variance = cfg.base_variances.get(intervention_type, 0.01)

        # Override for escalation when a cost profile is provided.
        if cost_profile is not None and intervention_type == "escalate":
            mean = (
                cost_profile.escalation_latency_cost
                + cost_profile.escalation_interruption_cost
            )

        fatigue = self.get_fatigue_factor(agent_id, intervention_type)

        detail = (
            f"{intervention_type}: base={mean:.4f}, "
            f"fatigue={fatigue:.2f}"
        )

        return InterventionCost(
            mean=mean,
            variance=variance,
            fatigue_multiplier=fatigue,
            detail=detail,
        )

    def record_intervention(
        self,
        agent_id: str,
        intervention_type: str,
        timestamp: float | None = None,
    ) -> None:
        """Record an intervention for fatigue tracking."""
        ts = timestamp if timestamp is not None else _time.time()
        with self._lock:
            history = self._intervention_history.setdefault(agent_id, [])
            history.append((ts, intervention_type))
            # Keep only the most recent entries within the fatigue window.
            if len(history) > self._config.fatigue_window * 5:
                self._intervention_history[agent_id] = history[-(self._config.fatigue_window * 5):]

    def detect_strategy_failure(
        self, agent_id: str, intervention_type: str,
    ) -> bool:
        """Check if same-type interventions have failed to reduce drift.

        Returns True if >= strategy_failure_threshold recent interventions
        of this type without drift improvement.
        """
        with self._lock:
            history = self._intervention_history.get(agent_id, [])

        recent = [t for t in history if t[1] == intervention_type]
        window = self._config.fatigue_window
        recent = recent[-window:]

        return len(recent) >= self._config.strategy_failure_threshold

    def get_fatigue_factor(
        self, agent_id: str, intervention_type: str,
    ) -> float:
        """Get current fatigue multiplier for an intervention type on an agent."""
        with self._lock:
            history = self._intervention_history.get(agent_id, [])

        window = self._config.fatigue_window
        recent = [t for t in history[-window:] if t[1] == intervention_type]
        count = len(recent)

        if count == 0:
            return 1.0

        return self._config.fatigue_base ** count
