"""The governance dimensions evaluated for every action.

Dimensions are organized into three categories. D1–D14 are included in the
open source nomotic package. D15–D20 are available via the nomotic-pro plugin
(Pro or Enterprise license required).

Deterministic Dimensions (6) — fast-gate, veto-capable, always active:
 1. Scope Compliance              - Is the action within authorized scope?
 2. Authority Verification        - Does the agent have authority for this action?
 3. Resource Boundaries           - Are resource limits respected?
 4. Isolation Integrity           - Are containment boundaries maintained?
 5. Temporal Compliance           - Is the timing appropriate?
 6. Human Override                - Is human intervention required?

Probabilistic Dimensions (8) — weighted scoring, contextual, always active:
 7. Behavioral Consistency        - Does this match expected behavior patterns?
 8. Cascading Impact              - What are the downstream consequences?
 9. Stakeholder Impact            - Who is affected and how?
10. Ethical Alignment             - Does the action meet ethical constraints?
11. Transparency                  - Can governance explain this decision coherently?
12. Precedent Alignment           - Is this consistent with past governance decisions?
13. Incident Detection            - Does this match known failure patterns?
14. Jurisdictional Compliance     - Are regulatory requirements satisfied?

Inferential Dimensions (6) — schema-driven, context-aware, nomotic-pro required:
15. Reversibility                 - Can this action be undone if needed?
16. Minimum Necessary Privilege   - Is the agent exercising only what the goal requires?
17. Data Sensitivity Classification - What is the sensitivity class of the data involved?
18. Delegation Chain Integrity    - Is authority extension in this chain legitimate?
19. Goal-Action Alignment         - Is this action coherent with the declared goal?
20. Adversarial Signal Detection  - Does this action match known attack patterns?

Each dimension produces a DimensionScore and a structured DimensionResult.
Veto-capable dimensions stop evaluation immediately when they fire.
The DimensionOrchestrator runs dimensions in priority order with relevance
filtering and early exit when sufficient confidence is reached.

Plugin dimensions (D15–D20) are discovered via Python entry points in the
'nomotic.dimensions' group. They are only registered when ActivatedTier is
PRO or ENTERPRISE. See docs/nomotic-pro.md for installation instructions.
"""

from __future__ import annotations

import importlib.metadata
import logging
import math
import threading
import time as _time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from fnmatch import fnmatch
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from nomotic.tiering import ProductTier

from nomotic.dimension_types import AuthorityGroup, AuthorityRule, ScopeDefinition
from nomotic.license import ActivatedTier
from nomotic.types import (
    Action,
    AgentContext,
    BlastRadius,
    DataSensitivity,
    DimensionResult,
    DimensionScore,
    Environment,
    EvaluatedRule,
    ReversibilityDeclaration,
)

_log = logging.getLogger(__name__)

# The 14 core dimension names (D1–D14) — always available regardless of license tier.
# Used to distinguish core from plugin dimensions in logging and available_count().
CORE_DIMENSION_NAMES: frozenset[str] = frozenset({
    "scope_compliance",
    "authority_verification",
    "resource_boundaries",
    "behavioral_consistency",
    "cascading_impact",
    "stakeholder_impact",
    "incident_detection",
    "isolation_integrity",
    "temporal_compliance",
    "precedent_alignment",
    "transparency",
    "human_override",
    "ethical_alignment",
    "jurisdictional_compliance",
})

__all__ = [
    "AuthorityGroup",
    "AuthorityRule",
    "AuthorityVerification",
    "BehavioralConsistency",
    "BlackoutDate",
    "CascadingImpact",
    "CascadingImpactConfig",
    "CONFLICTING_REGULATION_PAIRS",
    "ConsistencyConfig",
    "CORE_DIMENSION_NAMES",
    "DimensionRegistry",
    "EthicalAlignment",
    "EthicalRule",
    "GovernanceDimension",
    "HoldRecord",
    "HumanOverride",
    "IncidentConfig",
    "IncidentDetection",
    "IncidentPattern",
    "IsolationIntegrity",
    "JURISDICTION_RULES",
    "JurisdictionalCompliance",
    "LegalBasisMapping",
    "OverrideThresholdConfig",
    "PrecedentAlignment",
    "PrecedentConfig",
    "ResourceBoundaries",
    "ResourceLimit",
    "ResourceLimits",
    "ScopeCompliance",
    "ScopeDefinition",
    "SharedResourcePool",
    "StakeholderImpact",
    "StakeholderImpactConfig",
    "TemporalCompliance",
    "TemporalConfig",
    "Transparency",
]


class GovernanceDimension(ABC):
    """Base class for all governance dimensions.

    Each dimension evaluates actions independently and returns a score.
    A score of 0.0 means maximum governance concern (likely deny).
    A score of 1.0 means no governance concern (allow).
    A veto from any dimension overrides all other scores.
    """

    name: str
    weight: float = 1.0
    can_veto: bool = False
    relevant_schema_fields: list[str] = []   # empty = always relevant
    is_foundation: bool = False              # runs in pre-pass, populates shared context
    priority: int = 50                       # lower = runs earlier (0=highest priority)

    @abstractmethod
    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        """Evaluate an action and return a governance score."""
        ...


# --- Dimension 1: Scope Compliance ---


class ScopeCompliance(GovernanceDimension):
    """Is the action within the agent's authorized scope?

    Evaluates action type, target pattern, and environment against structured
    ``ScopeDefinition`` triplets.  Wildcard scopes (``action_type="*"``) are
    accepted but reduce confidence to 0.7 and flag ``wildcard_scope_active``
    in metadata.

    Legacy string-set interface (``configure_agent_scope``) is still supported
    for backwards compatibility — string entries are auto-promoted to
    ``ScopeDefinition(action_type=entry)``.

    When an archetype contract is loaded via ``load_archetype_contract()``,
    the contract's ``scope_deny_categories`` and ``authorized_action_categories``
    are checked before the configured scope definitions.
    """

    name = "scope_compliance"
    weight = 1.5
    can_veto = True

    def __init__(self, allowed_scopes: dict[str, set[str]] | None = None):
        self._scope_definitions: dict[str, list[ScopeDefinition]] = {}
        self._archetype_contracts: dict[str, Any] = {}  # agent_id -> ArchetypeContract
        # Promote legacy string scopes if supplied at init.
        if allowed_scopes:
            for agent_id, actions in allowed_scopes.items():
                self._scope_definitions[agent_id] = [
                    ScopeDefinition(action_type=a) for a in actions
                ]

    # --- configuration ---------------------------------------------------

    def configure_agent_scope(self, agent_id: str, allowed_actions: set[str]) -> None:
        """Legacy string-set API — auto-promotes to ScopeDefinition list."""
        self._scope_definitions[agent_id] = [
            ScopeDefinition(action_type=a) for a in allowed_actions
        ]

    def configure_scope_definitions(
        self, agent_id: str, scopes: list[ScopeDefinition]
    ) -> None:
        """Primary structured API."""
        self._scope_definitions[agent_id] = list(scopes)

    @property
    def _allowed_scopes(self) -> dict[str, set[str]]:
        """Backward-compatible view: flatten ScopeDefinitions to action-type sets."""
        return {
            agent_id: {s.action_type for s in defs}
            for agent_id, defs in self._scope_definitions.items()
        }

    def load_archetype_contract(self, contract: Any, agent_id: str | None = None) -> None:
        """Apply an archetype contract to this dimension.

        When *agent_id* is provided (legacy API), stores the contract in
        ``_archetype_contracts[agent_id]`` for agent-specific lookup.

        When called without *agent_id* (new API), extracts deny/escalate/
        authorized category sets for fast ``action.action_type in ...``
        checks that run before any scope definition evaluation.
        """
        if agent_id is not None:
            self._archetype_contracts[agent_id] = contract

        # Always extract category sets for fast path checks
        from nomotic.archetype_contracts import ArchetypeContract  # type check
        self._deny_categories: set[str] = set(contract.scope_deny_categories)
        self._escalate_categories: set[str] = {
            k for k, v in contract.authorized_action_categories.items()
            if v == "escalate"
        }
        self._authorized_categories: set[str] = {
            k for k, v in contract.authorized_action_categories.items()
            if v == "allow"
        }
        self._archetype_name: str = contract.archetype_name

    # --- evaluation -------------------------------------------------------

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        # ── Contract-level category checks (fast path, run first) ─────
        deny_cats = getattr(self, "_deny_categories", set())
        escalate_cats = getattr(self, "_escalate_categories", set())
        authorized_cats = getattr(self, "_authorized_categories", set())
        archetype = getattr(self, "_archetype_name", None)

        if deny_cats and action.action_type in deny_cats:
            result = DimensionResult(
                dimension_name=self.name,
                score=0.0,
                confidence=1.0,
                veto=True,
                primary_signal="archetype_category_deny",
                schema_fields_used=["action_type"],
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.0,
                weight=self.weight,
                veto=True,
                reasoning=(
                    f"Action '{action.action_type}' is outside authorized scope"
                    + (f" for archetype '{archetype}'" if archetype else "")
                ),
                result=result,
            )

        if escalate_cats and action.action_type in escalate_cats:
            result = DimensionResult(
                dimension_name=self.name,
                score=0.3,
                confidence=0.9,
                primary_signal="archetype_category_escalate",
                schema_fields_used=["action_type"],
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.3,
                weight=self.weight,
                veto=False,
                reasoning=(
                    f"Action '{action.action_type}' requires escalation"
                    + (f" per archetype '{archetype}'" if archetype else "")
                ),
                metadata={"escalation_required": True},
                result=result,
            )

        if authorized_cats and action.action_type in authorized_cats:
            result = DimensionResult(
                dimension_name=self.name,
                score=1.0,
                confidence=1.0,
                primary_signal="archetype_category_allow",
                schema_fields_used=["action_type"],
            )
            return DimensionScore(
                dimension_name=self.name,
                score=1.0,
                weight=self.weight,
                reasoning=f"Action '{action.action_type}' explicitly authorized by archetype contract",
                result=result,
            )

        # ── Check archetype contract via is_authorized (legacy path) ──
        contract = self._archetype_contracts.get(context.agent_id)
        if contract is not None:
            from nomotic.archetype_contracts import classify_action_category
            # Check the action_type directly against the contract first,
            # then fall back to classifying it as freeform text.
            action_cat = action.action_type
            authorization = contract.is_authorized(action_cat)
            if authorization == "allow":
                # Try classifying the action_type text for broader matching
                classified = classify_action_category(action.action_type)
                if classified != "general_request":
                    action_cat = classified
                    authorization = contract.is_authorized(action_cat)
            if authorization == "deny":
                result = DimensionResult(
                    dimension_name=self.name,
                    score=0.0,
                    confidence=1.0,
                    veto=True,
                    primary_signal="archetype_contract_deny",
                    schema_fields_used=["action_type"],
                )
                return DimensionScore(
                    dimension_name=self.name,
                    score=0.0,
                    weight=self.weight,
                    veto=True,
                    reasoning=(
                        f"Archetype contract '{contract.archetype_name}' denies "
                        f"category '{action_cat}' for action '{action.action_type}'"
                    ),
                    metadata={"archetype_contract_deny": action_cat},
                    result=result,
                )
            if authorization == "escalate":
                result = DimensionResult(
                    dimension_name=self.name,
                    score=0.4,
                    confidence=0.9,
                    primary_signal="archetype_contract_escalate",
                    schema_fields_used=["action_type"],
                )
                return DimensionScore(
                    dimension_name=self.name,
                    score=0.4,
                    weight=self.weight,
                    reasoning=(
                        f"Archetype contract '{contract.archetype_name}' escalates "
                        f"category '{action_cat}' for action '{action.action_type}'"
                    ),
                    metadata={
                        "archetype_contract_escalate": action_cat,
                        "escalation_required": True,
                    },
                    result=result,
                )

        scopes = self._scope_definitions.get(context.agent_id, [])
        rules_evaluated: list[EvaluatedRule] = []

        if not scopes:
            result = DimensionResult(
                dimension_name=self.name,
                score=0.5,
                confidence=0.5,
                primary_signal="no_scope_defined",
                context_missing=["agent_scope"],
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.5,
                weight=self.weight,
                reasoning="No scope defined for agent; default caution",
                result=result,
            )

        matched_scope: ScopeDefinition | None = None
        wildcard_active = False

        for idx, scope in enumerate(scopes):
            hit = scope.matches(action.action_type, action.target, action.environment)
            rules_evaluated.append(EvaluatedRule(
                rule_id=f"scope_{idx}",
                rule_description=(
                    f"{scope.action_type}:{scope.target_pattern}"
                    + (f"@{scope.environment.value}" if scope.environment else "")
                ),
                triggered=hit,
                value_evaluated=f"{action.action_type}:{action.target}",
                threshold_used=None,
                outcome="pass" if hit else "skip",
            ))
            if hit and matched_scope is None:
                matched_scope = scope
                if scope.is_wildcard:
                    wildcard_active = True

        if matched_scope is not None:
            confidence = 0.7 if wildcard_active else 1.0
            metadata: dict[str, Any] = {}
            if wildcard_active:
                metadata["wildcard_scope_active"] = True

            result = DimensionResult(
                dimension_name=self.name,
                score=1.0,
                confidence=confidence,
                rules_evaluated=rules_evaluated,
                primary_signal="scope_match",
                schema_fields_used=["action_type", "target", "environment"],
            )
            return DimensionScore(
                dimension_name=self.name,
                score=1.0,
                weight=self.weight,
                confidence=confidence,
                reasoning=f"Action '{action.action_type}' within scope",
                metadata=metadata,
                result=result,
            )

        result = DimensionResult(
            dimension_name=self.name,
            score=0.0,
            confidence=1.0,
            veto=True,
            rules_evaluated=rules_evaluated,
            primary_signal="scope_violation",
            schema_fields_used=["action_type", "target", "environment"],
        )
        return DimensionScore(
            dimension_name=self.name,
            score=0.0,
            weight=self.weight,
            veto=True,
            reasoning=f"Action '{action.action_type}' outside agent scope",
            result=result,
        )


# --- Dimension 2: Authority Verification ---


class AuthorityVerification(GovernanceDimension):
    """Does the agent have authority for this specific action?

    Scope says what types of actions are allowed. Authority says whether
    this specific action on this specific target is permitted.

    Primary interface: ``AuthorityRule`` / ``AuthorityGroup`` declarative
    format.  Legacy lambdas are still accepted via ``add_authority_check``
    as a ``custom_checks`` escape hatch.
    """

    name = "authority_verification"
    weight = 1.5
    can_veto = True

    def __init__(self) -> None:
        self._authority_groups: list[AuthorityGroup] = []
        self._custom_checks: list[Callable[[Action, AgentContext], bool]] = []

    # --- primary declarative API -----------------------------------------

    def add_rule(self, rule: AuthorityRule) -> None:
        """Add a single rule in its own AND group."""
        self._authority_groups.append(AuthorityGroup(rules=[rule], logic="AND"))

    def add_group(self, group: AuthorityGroup) -> None:
        self._authority_groups.append(group)

    # --- legacy escape hatch ---------------------------------------------

    def add_authority_check(
        self, check: Callable[[Action, AgentContext], bool]
    ) -> None:
        """Legacy lambda API — kept as escape hatch."""
        self._custom_checks.append(check)

    @property
    def _authority_checks(self) -> list[Callable[[Action, AgentContext], bool]]:
        """Backward-compatible alias for custom_checks."""
        return self._custom_checks

    # --- evaluation -------------------------------------------------------

    def _build_variables(self, action: Action, context: AgentContext) -> dict[str, Any]:
        """Build the variable dict available to rule condition expressions."""
        return {
            "action": action,
            "context": context,
            "action_type": action.action_type,
            "target": action.target,
            "agent_id": context.agent_id,
            "trust": context.trust_profile.overall_trust,
            "agent_tier": context.metadata.get("agent_tier", 0),
            "environment": action.environment,
        }

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        has_rules = bool(self._authority_groups)
        has_checks = bool(self._custom_checks)

        if not has_rules and not has_checks:
            result = DimensionResult(
                dimension_name=self.name,
                score=0.5,
                confidence=0.5,
                primary_signal="no_authority_configured",
                context_missing=["authority_rules"],
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.5,
                weight=self.weight,
                reasoning="No authority checks configured; default uncertainty",
                result=result,
            )

        rules_evaluated: list[EvaluatedRule] = []
        variables = self._build_variables(action, context)
        now = _time.time()
        all_passed = True

        # Evaluate declarative authority groups
        for group in self._authority_groups:
            group_passed, group_results = group.evaluate(variables, now=now)
            for rule, outcome in group_results:
                if outcome == "expired":
                    _log.warning(
                        "Authority rule %s expired at %s",
                        rule.rule_id,
                        rule.expires_at,
                    )
                rules_evaluated.append(EvaluatedRule(
                    rule_id=rule.rule_id,
                    rule_description=rule.description,
                    triggered=outcome != "pass",
                    value_evaluated=rule.condition,
                    threshold_used=rule.expires_at,
                    outcome=outcome,
                ))
            if not group_passed:
                all_passed = False

        # Evaluate legacy custom checks
        for idx, check in enumerate(self._custom_checks):
            try:
                passed = check(action, context)
            except Exception:
                passed = False
            rules_evaluated.append(EvaluatedRule(
                rule_id=f"custom_check_{idx}",
                rule_description="legacy lambda check",
                triggered=not passed,
                value_evaluated="<callable>",
                threshold_used=None,
                outcome="pass" if passed else "fail",
            ))
            if not passed:
                all_passed = False

        if all_passed:
            result = DimensionResult(
                dimension_name=self.name,
                score=1.0,
                confidence=1.0,
                rules_evaluated=rules_evaluated,
                primary_signal="authority_confirmed",
            )
            return DimensionScore(
                dimension_name=self.name,
                score=1.0,
                weight=self.weight,
                reasoning="All authority checks passed",
                result=result,
            )

        # At least one failed
        failed_rules = [r for r in rules_evaluated if r.outcome in ("fail", "expired")]
        first_failure = failed_rules[0] if failed_rules else None
        reasoning = (
            f"Authority check failed: {first_failure.rule_id}"
            if first_failure
            else "Authority check failed"
        )
        result = DimensionResult(
            dimension_name=self.name,
            score=0.0,
            confidence=1.0,
            veto=True,
            rules_evaluated=rules_evaluated,
            primary_signal="authority_denied",
        )
        return DimensionScore(
            dimension_name=self.name,
            score=0.0,
            weight=self.weight,
            veto=True,
            reasoning=reasoning,
            result=result,
        )


# --- Dimension 3: Resource Boundaries ---


@dataclass
class ResourceLimits:
    max_actions_per_minute: int = 60
    max_concurrent_actions: int = 10
    max_cost_per_action: float = float("inf")
    max_total_cost: float = float("inf")


@dataclass
class ResourceLimit:
    """Per-resource-type rate limit with burst allowance."""

    resource_type: str
    max_per_minute: int
    max_burst: int = 0
    burst_window_seconds: int = 10


@dataclass
class SharedResourcePool:
    """Cross-agent resource pool — multiple agents draw from one quota."""

    pool_id: str
    max_per_minute: int
    member_agents: list[str] = field(default_factory=list)
    current_usage: dict[str, int] = field(default_factory=dict)
    _timestamps: list[float] = field(default_factory=list, repr=False)

    def record(self, agent_id: str, now: float) -> None:
        self._timestamps.append(now)
        self.current_usage[agent_id] = self.current_usage.get(agent_id, 0) + 1

    def rate(self, now: float) -> int:
        cutoff = now - 60
        self._timestamps = [t for t in self._timestamps if t > cutoff]
        return len(self._timestamps)


class ResourceBoundaries(GovernanceDimension):
    """Are resource limits respected?

    Tracks rate, concurrency, and cost against configured limits.
    Supports per-resource-type limits with burst allowance and
    cross-agent shared resource pools.
    Degrades gracefully — approaching limits lowers the score before
    hitting them triggers a veto.
    """

    name = "resource_boundaries"
    weight = 1.2
    can_veto = True

    def __init__(
        self,
        limits: ResourceLimits | None = None,
        resource_limits: list[ResourceLimit] | None = None,
        pools: list[SharedResourcePool] | None = None,
    ):
        self._limits = limits or ResourceLimits()
        self._resource_limits: dict[str, ResourceLimit] = {}
        for rl in (resource_limits or []):
            self._resource_limits[rl.resource_type] = rl
        self._pools: dict[str, SharedResourcePool] = {}
        for p in (pools or []):
            self._pools[p.pool_id] = p
        # Per-resource-type tracking: resource_type -> list of timestamps
        self._resource_timestamps: dict[str, list[float]] = {}
        self._action_timestamps: list[float] = []
        self._active_count: int = 0
        self._total_cost: float = 0.0
        self._lock = threading.Lock()

    def record_action_start(self, cost: float = 0.0) -> None:
        import time

        with self._lock:
            self._action_timestamps.append(time.time())
            self._active_count += 1
            self._total_cost += cost

    def record_action_end(self) -> None:
        with self._lock:
            self._active_count = max(0, self._active_count - 1)

    def _check_resource_limit(
        self, resource_type: str, now: float
    ) -> tuple[bool, str]:
        """Check per-resource-type limit. Returns (ok, reason)."""
        rl = self._resource_limits.get(resource_type)
        if rl is None:
            return True, ""

        timestamps = self._resource_timestamps.get(resource_type, [])
        # Clean old timestamps (beyond 60s)
        cutoff_minute = now - 60
        timestamps = [t for t in timestamps if t > cutoff_minute]
        self._resource_timestamps[resource_type] = timestamps

        # Minute-level check
        if len(timestamps) >= rl.max_per_minute:
            return False, (
                f"Resource '{resource_type}' rate limit exceeded: "
                f"{len(timestamps)}/{rl.max_per_minute} per minute"
            )

        # Burst check — only if burst is configured
        if rl.max_burst > 0:
            burst_cutoff = now - rl.burst_window_seconds
            burst_count = sum(1 for t in timestamps if t > burst_cutoff)
            if burst_count >= rl.max_burst:
                return False, (
                    f"Resource '{resource_type}' burst limit exceeded: "
                    f"{burst_count}/{rl.max_burst} in {rl.burst_window_seconds}s"
                )

        return True, ""

    def _record_resource(self, resource_type: str, now: float) -> None:
        if resource_type not in self._resource_timestamps:
            self._resource_timestamps[resource_type] = []
        self._resource_timestamps[resource_type].append(now)

    def _check_pool(
        self, agent_id: str, now: float
    ) -> tuple[bool, str]:
        """Check all pools this agent belongs to. Returns (ok, reason)."""
        for pool in self._pools.values():
            if agent_id in pool.member_agents:
                rate = pool.rate(now)
                if rate >= pool.max_per_minute:
                    return False, (
                        f"Shared pool '{pool.pool_id}' rate limit exceeded: "
                        f"{rate}/{pool.max_per_minute} per minute"
                    )
        return True, ""

    def _record_pool(self, agent_id: str, now: float) -> None:
        for pool in self._pools.values():
            if agent_id in pool.member_agents:
                pool.record(agent_id, now)

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        import time

        now = time.time()
        rules_evaluated: list[EvaluatedRule] = []

        with self._lock:
            # Clean old timestamps
            cutoff = now - 60
            self._action_timestamps = [
                t for t in self._action_timestamps if t > cutoff
            ]
            rate = len(self._action_timestamps)
            active_count = self._active_count
            total_cost = self._total_cost

        resource_type = action.parameters.get("resource_type", "")

        # Per-resource-type check
        if resource_type and resource_type in self._resource_limits:
            ok, reason = self._check_resource_limit(resource_type, now)
            rules_evaluated.append(EvaluatedRule(
                rule_id=f"resource_limit_{resource_type}",
                rule_description=f"Per-resource limit for '{resource_type}'",
                triggered=not ok,
                value_evaluated=resource_type,
                threshold_used=None,
                outcome="fail" if not ok else "pass",
            ))
            if not ok:
                result = DimensionResult(
                    dimension_name=self.name,
                    score=0.0,
                    confidence=1.0,
                    veto=True,
                    rules_evaluated=rules_evaluated,
                    primary_signal="resource_limit_exceeded",
                )
                return DimensionScore(
                    dimension_name=self.name,
                    score=0.0,
                    weight=self.weight,
                    veto=True,
                    reasoning=reason,
                    result=result,
                )

        # Shared pool check
        pool_ok, pool_reason = self._check_pool(context.agent_id, now)
        if not pool_ok:
            rules_evaluated.append(EvaluatedRule(
                rule_id="shared_pool",
                rule_description="Shared resource pool limit",
                triggered=True,
                value_evaluated=context.agent_id,
                threshold_used=None,
                outcome="fail",
            ))
            result = DimensionResult(
                dimension_name=self.name,
                score=0.0,
                confidence=1.0,
                veto=True,
                rules_evaluated=rules_evaluated,
                primary_signal="pool_limit_exceeded",
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.0,
                weight=self.weight,
                veto=True,
                reasoning=pool_reason,
                result=result,
            )

        # Global rate check
        rate_ratio = rate / self._limits.max_actions_per_minute
        rules_evaluated.append(EvaluatedRule(
            rule_id="global_rate",
            rule_description="Global actions-per-minute",
            triggered=rate_ratio >= 1.0,
            value_evaluated=str(rate),
            threshold_used=None,
            outcome="fail" if rate_ratio >= 1.0 else "pass",
        ))
        if rate_ratio >= 1.0:
            result = DimensionResult(
                dimension_name=self.name,
                score=0.0,
                confidence=1.0,
                veto=True,
                rules_evaluated=rules_evaluated,
                primary_signal="rate_limit_exceeded",
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.0,
                weight=self.weight,
                veto=True,
                reasoning=f"Rate limit exceeded: {rate}/{self._limits.max_actions_per_minute} per minute",
                result=result,
            )

        # Concurrency check
        conc_ratio = active_count / self._limits.max_concurrent_actions
        if conc_ratio >= 1.0:
            result = DimensionResult(
                dimension_name=self.name,
                score=0.0,
                confidence=1.0,
                veto=True,
                rules_evaluated=rules_evaluated,
                primary_signal="concurrency_limit_exceeded",
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.0,
                weight=self.weight,
                veto=True,
                reasoning=f"Concurrency limit: {active_count}/{self._limits.max_concurrent_actions}",
                result=result,
            )

        # Cost check
        action_cost = action.parameters.get("cost", 0.0)
        if action_cost > self._limits.max_cost_per_action:
            result = DimensionResult(
                dimension_name=self.name,
                score=0.0,
                confidence=1.0,
                veto=True,
                rules_evaluated=rules_evaluated,
                primary_signal="cost_limit_exceeded",
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.0,
                weight=self.weight,
                veto=True,
                reasoning=f"Action cost {action_cost} exceeds limit {self._limits.max_cost_per_action}",
                result=result,
            )
        if total_cost + action_cost > self._limits.max_total_cost:
            result = DimensionResult(
                dimension_name=self.name,
                score=0.0,
                confidence=1.0,
                veto=True,
                rules_evaluated=rules_evaluated,
                primary_signal="total_cost_exceeded",
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.0,
                weight=self.weight,
                veto=True,
                reasoning="Total cost would exceed limit",
                result=result,
            )

        # Record resource usage on success
        if resource_type and resource_type in self._resource_limits:
            self._record_resource(resource_type, now)
        self._record_pool(context.agent_id, now)

        # Graduated score — closer to limits = lower score
        score = 1.0 - max(rate_ratio, conc_ratio) * 0.5
        result = DimensionResult(
            dimension_name=self.name,
            score=score,
            confidence=1.0,
            rules_evaluated=rules_evaluated,
            primary_signal="within_limits",
        )
        return DimensionScore(
            dimension_name=self.name,
            score=score,
            weight=self.weight,
            reasoning=f"Within limits (rate={rate}, concurrent={active_count})",
            result=result,
        )


# --- Dimension 4: Behavioral Consistency ---


@dataclass
class ConsistencyConfig:
    """Configuration for BehavioralConsistency dimension."""

    drift_coefficient: float = 0.6
    min_score_floor: float = 0.2
    environment_weight: float = 0.3
    schema_mode: bool = False
    veto_on_critical_production_novelty: bool = False


class BehavioralConsistency(GovernanceDimension):
    """Does this action match expected behavioral patterns?

    The anchoring dimension of the Behavioral Control Plane.  Behavioral
    Consistency connects behavioral fingerprints, drift detection, and
    trust calibration into a unified behavioral evaluation.  It is the
    primary dimension through which an agent's behavioral DNA influences
    real-time governance decisions.

    Compares the action against the agent's established behavioral
    fingerprint.  Sudden deviations — new action types, unusual targets,
    parameter anomalies — lower the score.

    When a behavioral fingerprint is available (from the fingerprint
    observer), the evaluation checks against the fingerprint's action
    distribution for richer scoring.  Without a fingerprint, falls back
    to the legacy "have I seen this action type before?" check.

    When drift data is available, high behavioral drift modulates the
    score downward proportionally to the drift magnitude.

    Environment-aware: when ``action.environment`` is present, consistency
    is scored against environment-specific history.  An action normal in
    DEVELOPMENT that is novel in PRODUCTION scores differently per environment.

    Schema mode: when ``config.schema_mode`` is True, uses structured
    ActionSchema fields for fingerprint matching instead of action_type strings.
    """

    name = "behavioral_consistency"
    weight = 1.0
    can_veto = False

    def __init__(self, config: ConsistencyConfig | None = None) -> None:
        self._config = config or ConsistencyConfig()
        self._known_patterns: dict[str, set[str]] = {}  # agent_id -> action_types seen
        # Environment-specific patterns: (agent_id, environment) -> action_types
        self._env_patterns: dict[tuple[str, str], set[str]] = {}
        self._fingerprint_accessor: Callable[[str], Any] | None = None
        self._drift_accessor: Callable[[str], Any] | None = None
        self._lock = threading.Lock()
        # Update can_veto based on config
        if self._config.veto_on_critical_production_novelty:
            self.can_veto = True

    def set_fingerprint_accessor(
        self, accessor: Callable[[str], Any],
    ) -> None:
        """Set a function that retrieves fingerprints for agents."""
        self._fingerprint_accessor = accessor

    def set_drift_accessor(
        self, accessor: Callable[[str], Any],
    ) -> None:
        """Set a function that retrieves drift scores for agents."""
        self._drift_accessor = accessor

    def _fingerprint_key(self, action: Action) -> str:
        """Return the key used for fingerprint matching.

        When schema_mode is True, builds a composite key from structured
        ActionSchema fields.  Otherwise returns the action_type string.
        """
        if self._config.schema_mode:
            parts = [action.action_type]
            if action.blast_radius is not None:
                parts.append(f"br:{action.blast_radius.value}")
            if action.reversibility is not None:
                parts.append(f"rev:{action.reversibility.value}")
            if action.data_sensitivity is not None:
                parts.append(f"ds:{action.data_sensitivity.value}")
            return "|".join(parts)
        return action.action_type

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        cfg = self._config
        with self._lock:
            seen = self._known_patterns.setdefault(context.agent_id, set())
            fprint_key = self._fingerprint_key(action)

            # Track environment-specific history
            env_key: tuple[str, str] | None = None
            env_seen: set[str] | None = None
            if action.environment is not None:
                env_key = (context.agent_id, action.environment.value)
                env_seen = self._env_patterns.setdefault(env_key, set())

            # First-ever action for this agent
            if not seen:
                seen.add(fprint_key)
                if env_seen is not None:
                    env_seen.add(fprint_key)
                result = DimensionResult(
                    dimension_name=self.name,
                    score=0.7,
                    confidence=0.5,
                    primary_signal="first_action_baseline",
                    schema_fields_used=["action_type"],
                )
                return DimensionScore(
                    dimension_name=self.name,
                    score=0.7,
                    weight=self.weight,
                    reasoning="First action; establishing baseline",
                    result=result,
                )

            is_novel_global = fprint_key not in seen
            is_novel_env = (env_seen is not None and fprint_key not in env_seen)
            seen.add(fprint_key)
            if env_seen is not None:
                env_seen.add(fprint_key)

            # Compute base score from fingerprint or legacy
            base_score: float
            base_reasoning: str
            fp_confidence: float | None = None
            schema_fields = ["action_type"]
            if self._config.schema_mode:
                schema_fields.extend(["blast_radius", "reversibility", "data_sensitivity"])

            if self._fingerprint_accessor is None:
                if is_novel_global:
                    base_score = 0.5
                    base_reasoning = f"Novel action type '{action.action_type}' for this agent"
                else:
                    base_score = 1.0
                    base_reasoning = "Action type consistent with history"
            else:
                fp = self._fingerprint_accessor(context.agent_id)
                if fp is None or fp.total_observations < 10:
                    if is_novel_global:
                        base_score = 0.5
                        base_reasoning = f"Novel action type '{action.action_type}' (insufficient fingerprint data)"
                    else:
                        base_score = 1.0
                        base_reasoning = "Action type consistent with history"
                else:
                    fp_confidence = fp.confidence
                    expected_freq = fp.action_distribution.get(action.action_type, 0.0)

                    if expected_freq >= 0.05:
                        base_score = 1.0
                        base_reasoning = f"Action type '{action.action_type}' is {expected_freq:.0%} of typical activity"
                    elif expected_freq > 0:
                        base_score = 0.7
                        base_reasoning = f"Action type '{action.action_type}' is rare ({expected_freq:.1%} of typical activity)"
                    else:
                        base_score = 0.4
                        base_reasoning = f"Action type '{action.action_type}' has no precedent in behavioral fingerprint"

            # Environment-aware scoring adjustment
            if action.environment is not None and not is_novel_global and is_novel_env:
                env_penalty = cfg.environment_weight
                base_score = base_score * (1.0 - env_penalty)
                env_name = action.environment.value.upper()
                base_reasoning += f"; novel in {env_name} environment (globally known)"
                schema_fields.append("environment")

            # Drift modulation
            drift_overall: float = 0.0
            veto = False
            if self._drift_accessor is not None:
                drift = self._drift_accessor(context.agent_id)
                if drift is not None and drift.confidence > 0.3:
                    drift_overall = drift.overall
                    if drift.overall >= 0.15:
                        drift_factor = 1.0 - (drift.overall * cfg.drift_coefficient)
                        drift_factor = max(drift_factor, cfg.min_score_floor)
                        base_score = base_score * drift_factor

                        if drift.overall >= 0.35:
                            base_reasoning = f"{base_reasoning}; HIGH DRIFT detected ({drift.overall:.2f}): {drift.detail}"
                        else:
                            base_reasoning = f"{base_reasoning}; moderate drift detected ({drift.overall:.2f})"

                        conf = min(fp_confidence, drift.confidence) if fp_confidence is not None else drift.confidence
                        fp_confidence = conf

            # Veto check: critical drift + novel + PRODUCTION
            if (
                cfg.veto_on_critical_production_novelty
                and drift_overall >= 0.35
                and (is_novel_global or is_novel_env)
                and action.environment == Environment.PRODUCTION
            ):
                veto = True
                base_reasoning += "; VETO: critical drift + novel action in PRODUCTION"

            confidence = fp_confidence if fp_confidence is not None else 1.0
            result = DimensionResult(
                dimension_name=self.name,
                score=base_score,
                confidence=confidence,
                veto=veto,
                primary_signal="behavioral_consistency",
                schema_fields_used=schema_fields,
            )
            return DimensionScore(
                dimension_name=self.name,
                score=base_score,
                weight=self.weight,
                confidence=confidence,
                veto=veto,
                reasoning=base_reasoning,
                result=result,
            )


# --- Dimension 5: Cascading Impact ---


@dataclass
class CascadingImpactConfig:
    """Configuration for CascadingImpact dimension.

    ``matrix_overrides`` maps ``(reversibility, blast_radius)`` tuples to
    custom base scores, overriding the built-in matrix.

    ``dependency_penalty_per`` is the score reduction per declared downstream
    dependency (capped at ``dependency_penalty_cap``).

    Veto conditions (all opt-in, disabled by default):
    - ``veto_irreversible_system_wide``: veto when IRREVERSIBLE × SYSTEM_WIDE
      and data_sensitivity is in ``veto_sensitivity_classes`` and
      environment == PRODUCTION.
    """

    matrix_overrides: dict[tuple[str, str], float] = field(default_factory=dict)
    dependency_penalty_per: float = 0.05
    dependency_penalty_cap: float = 0.25
    veto_irreversible_system_wide: bool = False
    veto_sensitivity_classes: set[str] = field(
        default_factory=lambda: {"phi", "pii", "financial"},
    )
    veto_environment: Environment = field(default=Environment.PRODUCTION)


# Reversibility × BlastRadius → base score
_CASCADING_MATRIX: dict[tuple[ReversibilityDeclaration, BlastRadius], float] = {
    (ReversibilityDeclaration.IRREVERSIBLE, BlastRadius.SYSTEM_WIDE): 0.05,
    (ReversibilityDeclaration.IRREVERSIBLE, BlastRadius.SUBSET): 0.15,
    (ReversibilityDeclaration.IRREVERSIBLE, BlastRadius.SINGLE_RECORD): 0.4,
    (ReversibilityDeclaration.APPEND_ONLY, BlastRadius.SYSTEM_WIDE): 0.25,
    (ReversibilityDeclaration.APPEND_ONLY, BlastRadius.SUBSET): 0.5,
    (ReversibilityDeclaration.APPEND_ONLY, BlastRadius.SINGLE_RECORD): 0.7,
    (ReversibilityDeclaration.REVERSIBLE, BlastRadius.SYSTEM_WIDE): 0.6,
    (ReversibilityDeclaration.REVERSIBLE, BlastRadius.SUBSET): 0.8,
    (ReversibilityDeclaration.REVERSIBLE, BlastRadius.SINGLE_RECORD): 0.95,
}


class CascadingImpact(GovernanceDimension):
    """What are the downstream consequences of this action?

    Uses a schema-based reversibility × blast_radius matrix to score
    cascading impact.  Downstream dependencies reduce the score
    proportionally.  Conditional veto for IRREVERSIBLE × SYSTEM_WIDE
    actions on sensitive production data (opt-in).

    When schema fields are absent, returns a neutral 0.5 with a warning.
    """

    name = "cascading_impact"
    weight = 1.3
    can_veto = False

    def __init__(self, config: CascadingImpactConfig | None = None) -> None:
        self._config = config or CascadingImpactConfig()
        if self._config.veto_irreversible_system_wide:
            self.can_veto = True

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        cfg = self._config
        rules_evaluated: list[EvaluatedRule] = []
        schema_fields_used: list[str] = []

        # Check if schema fields are present
        if action.reversibility is None or action.blast_radius is None:
            _log.warning(
                "CascadingImpact: schema fields absent for action %s; returning neutral score",
                action.id,
            )
            result = DimensionResult(
                dimension_name=self.name,
                score=0.5,
                confidence=0.5,
                primary_signal="schema_fields_absent",
                context_missing=["reversibility", "blast_radius"],
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.5,
                weight=self.weight,
                confidence=0.5,
                reasoning="Schema fields absent; neutral score",
                result=result,
            )

        schema_fields_used.extend(["reversibility", "blast_radius"])

        # Look up base score from matrix
        matrix_key = (action.reversibility, action.blast_radius)
        override_key = (action.reversibility.value, action.blast_radius.value)

        if override_key in cfg.matrix_overrides:
            base_score = cfg.matrix_overrides[override_key]
        else:
            base_score = _CASCADING_MATRIX.get(matrix_key, 0.5)

        rules_evaluated.append(EvaluatedRule(
            rule_id="matrix_lookup",
            rule_description=f"{action.reversibility.value} × {action.blast_radius.value}",
            triggered=True,
            value_evaluated=f"{action.reversibility.value}:{action.blast_radius.value}",
            threshold_used=base_score,
            outcome="pass",
        ))

        reasoning_parts = [
            f"{action.reversibility.value} × {action.blast_radius.value} → {base_score:.2f}",
        ]

        # Downstream dependency weighting
        dep_penalty = 0.0
        if action.downstream_dependencies > 0:
            schema_fields_used.append("downstream_dependencies")
            dep_penalty = min(
                action.downstream_dependencies * cfg.dependency_penalty_per,
                cfg.dependency_penalty_cap,
            )
            base_score = max(0.0, base_score - dep_penalty)
            reasoning_parts.append(
                f"{action.downstream_dependencies} downstream deps → -{dep_penalty:.2f}",
            )
            rules_evaluated.append(EvaluatedRule(
                rule_id="downstream_deps",
                rule_description=f"{action.downstream_dependencies} downstream dependencies",
                triggered=True,
                value_evaluated=action.downstream_dependencies,
                threshold_used=cfg.dependency_penalty_per,
                outcome="warn",
            ))

        # Conditional veto
        veto = False
        if (
            cfg.veto_irreversible_system_wide
            and action.reversibility == ReversibilityDeclaration.IRREVERSIBLE
            and action.blast_radius == BlastRadius.SYSTEM_WIDE
            and action.data_sensitivity is not None
            and action.data_sensitivity.value in cfg.veto_sensitivity_classes
            and action.environment == cfg.veto_environment
        ):
            veto = True
            schema_fields_used.extend(["data_sensitivity", "environment"])
            reasoning_parts.append(
                f"VETO: irreversible system-wide on {action.data_sensitivity.value} "
                f"in {action.environment.value}",
            )
            rules_evaluated.append(EvaluatedRule(
                rule_id="conditional_veto",
                rule_description="IRREVERSIBLE × SYSTEM_WIDE × sensitive × PRODUCTION",
                triggered=True,
                value_evaluated=f"{action.data_sensitivity.value}@{action.environment.value}",
                threshold_used=None,
                outcome="fail",
            ))

        reasoning = "; ".join(reasoning_parts)
        result = DimensionResult(
            dimension_name=self.name,
            score=base_score,
            confidence=1.0,
            veto=veto,
            rules_evaluated=rules_evaluated,
            primary_signal="cascading_matrix",
            schema_fields_used=schema_fields_used,
        )
        return DimensionScore(
            dimension_name=self.name,
            score=base_score,
            weight=self.weight,
            veto=veto,
            reasoning=reasoning,
            result=result,
        )


# --- Dimension 6: Stakeholder Impact ---


@dataclass
class StakeholderImpactConfig:
    """Configuration for StakeholderImpact dimension.

    ``population_weight_curve``: "linear" (default) or "log".  Controls how
    ``indirect_stakeholder_reach`` maps to a penalty.  Linear penalizes
    proportionally; log compresses large populations so that 10x more users
    doesn't produce 10x more penalty.

    ``weight``: dimension weight, default 1.4 (raised from 1.2 to reflect
    the significance of stakeholder impact in governance decisions).
    Configurable so operators can override.

    ``external_system_prefixes``: downstream system name prefixes that are
    treated as external-facing (default: ``("ext-", "public-", "customer-")``).
    """

    population_weight_curve: str = "linear"  # "linear" | "log"
    weight: float = 1.4
    external_system_prefixes: tuple[str, ...] = ("ext-", "public-", "customer-")


# Sensitivity ordering for comparisons
_SENSITIVITY_ORDER: dict[DataSensitivity, int] = {
    DataSensitivity.PUBLIC: 0,
    DataSensitivity.INTERNAL: 1,
    DataSensitivity.CONFIDENTIAL: 2,
    DataSensitivity.PII: 3,
    DataSensitivity.PHI: 4,
    DataSensitivity.FINANCIAL: 5,
    DataSensitivity.CLASSIFIED: 6,
}


class StakeholderImpact(GovernanceDimension):
    """Who is affected by this action and how?

    Scores based on structured schema fields: ``data_sensitivity``,
    ``blast_radius``, ``indirect_stakeholder_reach``, and
    ``downstream_systems``.  String matching on target names has been
    removed in favour of these declared fields.
    """

    name = "stakeholder_impact"
    can_veto = False

    def __init__(self, config: StakeholderImpactConfig | None = None) -> None:
        self._config = config or StakeholderImpactConfig()
        self.weight = self._config.weight

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        t0 = _time.monotonic()
        rules: list[EvaluatedRule] = []
        schema_fields_used: list[str] = []
        context_missing: list[str] = []
        score = 1.0

        # --- data_sensitivity ---
        if action.data_sensitivity is not None:
            schema_fields_used.append("data_sensitivity")
            sens_order = _SENSITIVITY_ORDER.get(action.data_sensitivity, 0)
            # Higher sensitivity → lower score contribution
            sensitivity_penalty = sens_order * 0.1  # 0.0 – 0.6
            score -= sensitivity_penalty
            rules.append(EvaluatedRule(
                rule_id="data_sensitivity",
                rule_description=f"Data sensitivity: {action.data_sensitivity.value}",
                triggered=sensitivity_penalty > 0,
                value_evaluated=action.data_sensitivity.value,
                threshold_used=None,
                outcome="warn" if sensitivity_penalty > 0 else "pass",
            ))
        else:
            context_missing.append("data_sensitivity")

        # --- blast_radius ---
        if action.blast_radius is not None:
            schema_fields_used.append("blast_radius")
            blast_penalties = {
                BlastRadius.SINGLE_RECORD: 0.0,
                BlastRadius.SUBSET: 0.1,
                BlastRadius.SYSTEM_WIDE: 0.25,
            }
            bp = blast_penalties.get(action.blast_radius, 0.0)
            score -= bp
            rules.append(EvaluatedRule(
                rule_id="blast_radius",
                rule_description=f"Blast radius: {action.blast_radius.value}",
                triggered=bp > 0,
                value_evaluated=action.blast_radius.value,
                threshold_used=None,
                outcome="warn" if bp > 0 else "pass",
            ))
        else:
            context_missing.append("blast_radius")

        # --- indirect_stakeholder_reach (population) ---
        population = action.indirect_stakeholder_reach
        if population > 0:
            schema_fields_used.append("indirect_stakeholder_reach")
            if self._config.population_weight_curve == "log":
                # log10(pop) / 8 — caps around 100M users → penalty ~1.0
                pop_penalty = min(math.log10(max(population, 1)) / 8.0, 1.0)
            else:
                # Linear: 1 penalty point per 100_000_000 stakeholders, capped at 1.0
                pop_penalty = min(population / 100_000_000, 1.0)
            score -= pop_penalty * 0.3  # population contributes up to 0.3
            rules.append(EvaluatedRule(
                rule_id="indirect_stakeholder_reach",
                rule_description=f"Affected population: {population:,}",
                triggered=True,
                value_evaluated=population,
                threshold_used=None,
                outcome="warn",
            ))

        # --- downstream_systems (indirect impact) ---
        if action.downstream_systems:
            schema_fields_used.append("downstream_systems")
            external_count = sum(
                1 for s in action.downstream_systems
                if any(s.startswith(p) for p in self._config.external_system_prefixes)
            )
            internal_count = len(action.downstream_systems) - external_count
            # Each external downstream system: 0.08 penalty, internal: 0.03
            ds_penalty = min(external_count * 0.08 + internal_count * 0.03, 0.3)
            score -= ds_penalty
            rules.append(EvaluatedRule(
                rule_id="downstream_systems",
                rule_description=(
                    f"{len(action.downstream_systems)} downstream system(s), "
                    f"{external_count} external-facing"
                ),
                triggered=True,
                value_evaluated=list(action.downstream_systems),
                threshold_used=None,
                outcome="warn" if external_count > 0 else "pass",
            ))

        # Clamp
        score = max(score, 0.0)

        primary = "No schema fields declared" if not schema_fields_used else rules[0].rule_description if rules else ""
        elapsed = (_time.monotonic() - t0) * 1000.0

        result = DimensionResult(
            dimension_name=self.name,
            score=score,
            rules_evaluated=rules,
            primary_signal=primary,
            schema_fields_used=schema_fields_used,
            context_missing=context_missing,
            evaluation_time_ms=elapsed,
        )

        return DimensionScore(
            dimension_name=self.name,
            score=score,
            weight=self.weight,
            reasoning=result.to_reasoning_string(),
            result=result,
        )


# --- Dimension 7: Incident Detection ---


@dataclass
class IncidentPattern:
    """A declarative incident pattern for runtime detection.

    Wraps a detector callable with auditable metadata (ID, description,
    category).  The detector returns a concern score 0–1 (0 = no concern,
    1 = maximum concern) or ``None`` if the pattern does not apply to the
    current action.
    """

    pattern_id: str
    description: str
    category: str  # "privilege_escalation", "exfiltration", "confused_deputy", etc.
    detector: Callable[[Action, AgentContext], float | None]
    min_history_depth: int = 3


@dataclass
class IncidentConfig:
    """Configurable thresholds for incident detection.

    * Scores **at or below** ``veto_threshold`` trigger a hard veto.
    * Scores above ``veto_threshold`` but **at or below**
      ``escalation_threshold`` set ``escalation_required = True``.
    """

    veto_threshold: float = 0.1
    escalation_threshold: float = 0.25


class IncidentDetection(GovernanceDimension):
    """Does this action match known failure or attack patterns?

    Cross-action pattern monitoring.  Detects sequences that look like
    known incidents — rapid repeated failures, privilege escalation
    attempts, data exfiltration patterns.

    Supports declarative ``IncidentPattern`` objects (preferred) as well
    as legacy bare-lambda detectors via ``add_pattern()``.

    **Lookahead detection**: ``lookahead_patterns`` fire advisory signals
    at the first 2 actions of a known sequence rather than waiting for
    completion.

    **Multi-category co-occurrence**: when signals from 2+ independent
    pattern categories fire simultaneously the concern is amplified.

    When drift data is available, critical drift is treated as an
    incident signal.
    """

    name = "incident_detection"
    weight = 1.5
    can_veto = True

    def __init__(self, config: IncidentConfig | None = None) -> None:
        self._incident_patterns: list[IncidentPattern] = []
        # Legacy bare-lambda patterns (wrapped internally)
        self._legacy_patterns: list[Callable[[Action, AgentContext], float | None]] = []
        self._drift_accessor: Callable[[str], Any] | None = None
        self._lookahead_patterns: list[IncidentPattern] = []
        self.config = config or IncidentConfig()

    # -- configuration helpers ------------------------------------------------

    def set_drift_accessor(
        self, accessor: Callable[[str], Any],
    ) -> None:
        """Set a function that retrieves drift scores for agents."""
        self._drift_accessor = accessor

    def add_incident_pattern(self, pattern: IncidentPattern) -> None:
        """Add a declarative incident pattern."""
        self._incident_patterns.append(pattern)

    def add_pattern(
        self, detector: Callable[[Action, AgentContext], float | None],
    ) -> None:
        """Legacy interface: add a bare-lambda pattern detector.

        Legacy detectors return a **score** (0 = max concern, 1 = no concern).
        This wraps them as ``IncidentPattern`` by inverting the value so
        the internal ``detector`` returns **concern** (0 = no concern,
        1 = max concern).

        For new code, prefer ``add_incident_pattern()``.
        """
        _legacy = detector  # capture

        def _inverted(action: Action, context: AgentContext) -> float | None:
            result = _legacy(action, context)
            if result is None:
                return None
            return round(1.0 - result, 10)  # score → concern

        self._incident_patterns.append(IncidentPattern(
            pattern_id=f"legacy_{len(self._incident_patterns)}",
            description="Legacy lambda pattern",
            category="unknown",
            detector=_inverted,
            min_history_depth=0,
        ))

    def add_lookahead_pattern(self, pattern: IncidentPattern) -> None:
        """Add a lookahead pattern that fires advisory signals early."""
        self._lookahead_patterns.append(pattern)

    # -- evaluation -----------------------------------------------------------

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        t0 = _time.monotonic()
        history_depth = len(context.action_history) if context.action_history else 0
        evaluated_rules: list[EvaluatedRule] = []
        fired_categories: dict[str, float] = {}  # category -> worst concern
        worst_score = 1.0
        worst_pattern_id = ""
        worst_category = ""
        worst_reason = "No incident patterns matched"

        # 1. Built-in rapid-repetition check
        recent = context.action_history[-20:] if context.action_history else []
        if len(recent) >= 5:
            recent_types = [r.action.action_type for r in recent[-5:]]
            if len(set(recent_types)) == 1 and recent_types[0] == action.action_type:
                score = 0.2
                if score < worst_score:
                    worst_score = score
                    worst_pattern_id = "builtin_rapid_repetition"
                    worst_category = "repetition"
                    worst_reason = "Repetitive pattern detected: 5+ identical actions"
                fired_categories.setdefault("repetition", 0.0)
                fired_categories["repetition"] = max(fired_categories["repetition"], 1.0 - score)
                evaluated_rules.append(EvaluatedRule(
                    rule_id="builtin_rapid_repetition",
                    rule_description="5+ identical action types in a row",
                    triggered=True,
                    value_evaluated=str(len(recent_types)),
                    threshold_used="5",
                    outcome="fail",
                ))

        # 2. Declarative incident patterns
        for pat in self._incident_patterns:
            if history_depth < pat.min_history_depth:
                evaluated_rules.append(EvaluatedRule(
                    rule_id=pat.pattern_id,
                    rule_description=pat.description,
                    triggered=False,
                    value_evaluated=str(history_depth),
                    threshold_used=str(pat.min_history_depth),
                    outcome="skip",
                ))
                continue
            concern = pat.detector(action, context)
            if concern is not None and concern > 0.0:
                score = round(1.0 - concern, 10)  # concern 0-1 → score 1-0
                if score < worst_score:
                    worst_score = score
                    worst_pattern_id = pat.pattern_id
                    worst_category = pat.category
                    worst_reason = f"Pattern '{pat.pattern_id}' ({pat.category}): {pat.description}"
                fired_categories.setdefault(pat.category, 0.0)
                fired_categories[pat.category] = max(fired_categories[pat.category], concern)
                evaluated_rules.append(EvaluatedRule(
                    rule_id=pat.pattern_id,
                    rule_description=pat.description,
                    triggered=True,
                    value_evaluated=f"concern={concern:.2f}",
                    threshold_used="0.0",
                    outcome="fail",
                ))
            else:
                evaluated_rules.append(EvaluatedRule(
                    rule_id=pat.pattern_id,
                    rule_description=pat.description,
                    triggered=False,
                    value_evaluated=str(concern),
                    threshold_used="0.0",
                    outcome="pass",
                ))

        # 3. Lookahead patterns — advisory-only, min_history_depth override to 0
        lookahead_fired = False
        for pat in self._lookahead_patterns:
            # Lookahead fires even with minimal history (first 2 actions)
            concern = pat.detector(action, context)
            if concern is not None and concern > 0.0:
                lookahead_fired = True
                # Advisory: nudge score down but softer than full pattern
                advisory_score = 1.0 - (concern * 0.5)  # halved concern
                if advisory_score < worst_score:
                    worst_score = advisory_score
                    worst_pattern_id = pat.pattern_id
                    worst_category = pat.category
                    worst_reason = f"Lookahead advisory '{pat.pattern_id}' ({pat.category}): {pat.description}"
                fired_categories.setdefault(pat.category, 0.0)
                fired_categories[pat.category] = max(fired_categories[pat.category], concern * 0.5)
                evaluated_rules.append(EvaluatedRule(
                    rule_id=f"lookahead:{pat.pattern_id}",
                    rule_description=f"[lookahead] {pat.description}",
                    triggered=True,
                    value_evaluated=f"concern={concern:.2f}",
                    threshold_used="advisory",
                    outcome="fail",
                ))

        # 4. Multi-category co-occurrence amplification
        # If 2+ independent categories fire, multiply concern
        active_categories = {c: v for c, v in fired_categories.items() if v > 0.0}
        if len(active_categories) >= 2:
            # Product of (1 - concern) for each category gives combined pass-through
            combined_pass = 1.0
            for concern_val in active_categories.values():
                combined_pass *= (1.0 - concern_val)
            co_occurrence_score = combined_pass  # e.g. two 0.4 concerns → 0.6 * 0.6 = 0.36
            if co_occurrence_score < worst_score:
                worst_score = co_occurrence_score
                cats = ", ".join(sorted(active_categories.keys()))
                worst_reason = f"Multi-category co-occurrence ({cats}): amplified concern"
                worst_pattern_id = "multi_category_co_occurrence"
                worst_category = "co_occurrence"
            evaluated_rules.append(EvaluatedRule(
                rule_id="multi_category_co_occurrence",
                rule_description=f"Co-occurrence of {len(active_categories)} categories: {', '.join(sorted(active_categories.keys()))}",
                triggered=True,
                value_evaluated=f"combined_score={co_occurrence_score:.3f}",
                threshold_used="2+ categories",
                outcome="fail",
            ))

        # 5. Drift-based incident detection
        if self._drift_accessor is not None:
            drift = self._drift_accessor(context.agent_id)
            if drift is not None and drift.confidence > 0.5:
                if drift.overall >= 0.60:
                    score = min(worst_score, 0.1)
                    if score <= worst_score:
                        worst_reason = f"Critical behavioral drift detected ({drift.overall:.2f}): {drift.detail}"
                        worst_pattern_id = "builtin_critical_drift"
                        worst_category = "drift"
                    worst_score = score
                elif drift.overall >= 0.40:
                    score = min(worst_score, 0.3)
                    if score <= worst_score:
                        worst_reason = f"High behavioral drift ({drift.overall:.2f}): {drift.detail}"
                        worst_pattern_id = "builtin_high_drift"
                        worst_category = "drift"
                    worst_score = score

        # 6. Threshold-based decisions
        veto = worst_score <= self.config.veto_threshold
        escalation = (
            not veto
            and worst_score <= self.config.escalation_threshold
        )

        elapsed = (_time.monotonic() - t0) * 1000.0

        schema_fields: list[str] = []
        if action.declared_jurisdiction:
            schema_fields.append("declared_jurisdiction")

        result = DimensionResult(
            dimension_name=self.name,
            score=worst_score,
            veto=veto,
            rules_evaluated=evaluated_rules,
            primary_signal=worst_reason,
            counterfactual=(
                f"Without pattern '{worst_pattern_id}' score would be higher"
                if worst_pattern_id else ""
            ),
            escalation_required=escalation,
            schema_fields_used=schema_fields,
            signals_used=[worst_category] if worst_category else [],
            evaluation_time_ms=elapsed,
        )
        result_metadata = {
            "fired_pattern_id": worst_pattern_id,
            "fired_category": worst_category,
            "active_categories": list(active_categories.keys()) if active_categories else [],
            "lookahead_fired": lookahead_fired,
        }
        return DimensionScore(
            dimension_name=self.name,
            score=worst_score,
            weight=self.weight,
            veto=veto,
            reasoning=worst_reason,
            result=result,
            metadata=result_metadata,
        )


# --- Dimension 8: Isolation Integrity ---


class IsolationIntegrity(GovernanceDimension):
    """Are containment boundaries maintained?

    Agents should operate within defined boundaries. Actions that cross
    isolation boundaries — accessing other agents' resources, modifying
    shared state without coordination — score lower or get vetoed.

    Supports:
    - Separate read and write boundaries (``set_rw_boundaries``).
    - Glob patterns in boundary expressions (e.g. ``customer_*``, ``prod.*``).
    - Parameter-value inspection: any parameter value matching an
      out-of-bounds target pattern is flagged as an isolation violation.
    - Legacy ``set_boundaries`` API is still supported (sets both
      read and write boundaries to the same set).
    """

    name = "isolation_integrity"
    weight = 1.4
    can_veto = True

    # Action types considered "write" operations
    _WRITE_ACTIONS: set[str] = {"write", "update", "delete", "create", "insert", "modify", "put", "patch", "remove"}

    def __init__(self) -> None:
        self._read_boundaries: dict[str, set[str]] = {}
        self._write_boundaries: dict[str, set[str]] = {}

    @property
    def _boundaries(self) -> dict[str, set[str]]:
        """Backward-compatible view: union of read and write boundaries."""
        all_agents = set(self._read_boundaries) | set(self._write_boundaries)
        return {
            agent_id: self._read_boundaries.get(agent_id, set())
            | self._write_boundaries.get(agent_id, set())
            for agent_id in all_agents
        }

    # --- configuration ---

    def set_boundaries(self, agent_id: str, allowed_targets: set[str]) -> None:
        """Legacy API — sets both read and write boundaries identically."""
        self._read_boundaries[agent_id] = set(allowed_targets)
        self._write_boundaries[agent_id] = set(allowed_targets)

    def set_rw_boundaries(
        self,
        agent_id: str,
        read_boundaries: set[str],
        write_boundaries: set[str],
    ) -> None:
        """Set separate read and write boundary sets (glob patterns accepted)."""
        self._read_boundaries[agent_id] = set(read_boundaries)
        self._write_boundaries[agent_id] = set(write_boundaries)

    # --- helpers ---

    @staticmethod
    def _matches_any(value: str, patterns: set[str]) -> bool:
        """Check if *value* matches any pattern (exact or glob)."""
        for pat in patterns:
            if pat == "*" or pat == value or fnmatch(value, pat):
                return True
        return False

    def _is_write(self, action: Action) -> bool:
        return action.action_type.lower() in self._WRITE_ACTIONS

    # --- evaluation ---

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        read_b = self._read_boundaries.get(context.agent_id)
        write_b = self._write_boundaries.get(context.agent_id)

        if read_b is None and write_b is None:
            result = DimensionResult(
                dimension_name=self.name,
                score=0.6,
                confidence=0.5,
                primary_signal="no_boundaries_defined",
                context_missing=["isolation_boundaries"],
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.6,
                weight=self.weight,
                reasoning="No isolation boundaries defined",
                result=result,
            )

        is_write = self._is_write(action)
        boundaries = write_b if is_write else read_b
        if boundaries is None:
            boundaries = set()

        rules_evaluated: list[EvaluatedRule] = []

        # Check primary target
        target_ok = not action.target or self._matches_any(action.target, boundaries)
        rules_evaluated.append(EvaluatedRule(
            rule_id="target_check",
            rule_description=f"Target '{action.target}' vs {'write' if is_write else 'read'} boundaries",
            triggered=not target_ok,
            value_evaluated=action.target,
            threshold_used=None,
            outcome="pass" if target_ok else "fail",
        ))

        # Check parameter values for isolation bypass.
        # A parameter value is flagged only if it matches a known target
        # pattern belonging to *another* agent (i.e., a target the current
        # agent is NOT allowed to access).  This prevents false positives
        # on arbitrary data values like table names or SQL fragments.
        param_violation: str | None = None
        all_own = (read_b or set()) | (write_b or set())
        # Build set of other agents' boundary patterns
        other_patterns: set[str] = set()
        for aid, pats in self._read_boundaries.items():
            if aid != context.agent_id:
                other_patterns |= pats
        for aid, pats in self._write_boundaries.items():
            if aid != context.agent_id:
                other_patterns |= pats

        for key, val in action.parameters.items():
            if not isinstance(val, str) or not val:
                continue
            # Flag if value matches another agent's boundary AND is
            # not within our own boundaries
            if not self._matches_any(val, all_own) and self._matches_any(val, other_patterns):
                param_violation = f"parameter '{key}' value '{val}'"
                rules_evaluated.append(EvaluatedRule(
                    rule_id=f"param_check_{key}",
                    rule_description=f"Parameter value '{val}' outside boundaries",
                    triggered=True,
                    value_evaluated=val,
                    threshold_used=None,
                    outcome="fail",
                ))
                break

        if not target_ok or param_violation is not None:
            violation_detail = (
                param_violation
                if param_violation
                else f"target '{action.target}'"
            )
            result = DimensionResult(
                dimension_name=self.name,
                score=0.0,
                confidence=1.0,
                veto=True,
                rules_evaluated=rules_evaluated,
                primary_signal="isolation_violation",
                schema_fields_used=["target", "parameters"],
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.0,
                weight=self.weight,
                veto=True,
                reasoning=f"Isolation violation: {violation_detail} outside {'write' if is_write else 'read'} boundaries",
                result=result,
            )

        result = DimensionResult(
            dimension_name=self.name,
            score=1.0,
            confidence=1.0,
            rules_evaluated=rules_evaluated,
            primary_signal="within_boundaries",
            schema_fields_used=["target", "parameters"],
        )
        return DimensionScore(
            dimension_name=self.name,
            score=1.0,
            weight=self.weight,
            reasoning="Within isolation boundaries",
            result=result,
        )


# --- Dimension 9: Temporal Compliance ---


@dataclass
class BlackoutDate:
    """A date on which certain action types are prohibited."""

    date: str  # ISO format YYYY-MM-DD
    reason: str
    applies_to: list[str] | None = None  # action type patterns; None = all


@dataclass
class TemporalConfig:
    """Configuration for TemporalCompliance dimension."""

    blackout_dates: list[BlackoutDate] = field(default_factory=list)


@dataclass
class HoldRecord:
    """Incident-triggered hold preventing an agent/action-type from proceeding."""

    agent_id: str
    action_type_pattern: str
    hold_until: float
    reason: str


class TemporalCompliance(GovernanceDimension):
    """Is the timing of this action appropriate?

    Timezone-aware time windows, blackout dates, incident-triggered holds,
    and minimum execution intervals.
    """

    name = "temporal_compliance"
    weight = 0.8
    can_veto = True

    def __init__(self, config: TemporalConfig | None = None) -> None:
        self._time_windows: dict[str, tuple[int, int, str]] = {}  # action_type -> (start, end, tz)
        self._min_intervals: dict[str, float] = {}
        self._last_execution: dict[str, float] = {}
        self._config = config or TemporalConfig()
        self._holds: list[HoldRecord] = []
        self._holds_lock = threading.Lock()
        self._archetype_contracts: dict[str, Any] = {}  # agent_id -> ArchetypeContract

    def load_archetype_contract(self, contract: Any, agent_id: str | None = None) -> None:
        """Apply archetype contract temporal constraints.

        When *agent_id* is provided (legacy API), stores the contract and
        installs time windows keyed by agent.

        When called without *agent_id* (new API), extracts authorized_hours,
        authorized_days, and constraint values for parameter-based checks
        in evaluate(). These check ``action.parameters["day_of_week"]`` and
        ``action.parameters["hour"]`` — NOT the server's wall clock — so
        workflow agents can simulate any scenario.
        """
        if agent_id is not None:
            self._archetype_contracts[agent_id] = contract
            hours = contract.get_constraint("authorized_hours")
            if hours and isinstance(hours, (tuple, list)) and len(hours) == 2:
                start_str, end_str = hours
                try:
                    start_h = int(start_str.split(":")[0])
                    end_h = int(end_str.split(":")[0])
                    self._time_windows[f"_archetype_{agent_id}_*"] = (start_h, end_h, "UTC")
                except (ValueError, AttributeError):
                    pass

        # Extract constraints for parameter-based checks (new API)
        constraints = contract.constraints

        # Authorized hours
        auth_hours = constraints.get("authorized_hours")
        if auth_hours and isinstance(auth_hours, (list, tuple)) and len(auth_hours) == 2:
            try:
                start_str, end_str = auth_hours
                self._contract_hour_start: int = int(str(start_str).split(":")[0])
                self._contract_hour_end: int = int(str(end_str).split(":")[0])
                self._contract_check_hours: bool = True
            except (ValueError, IndexError):
                self._contract_check_hours = False
        else:
            self._contract_check_hours = False

        # Authorized days
        auth_days = constraints.get("authorized_days")
        if auth_days and isinstance(auth_days, (list, tuple)):
            self._contract_authorized_days: set[str] = {
                d.lower().strip() for d in auth_days
            }
            self._contract_check_days: bool = True
        else:
            self._contract_check_days = False

        # no_weekend_* shorthand (overrides authorized_days if present)
        no_weekend = any(
            v is True
            for k, v in constraints.items()
            if k.startswith("no_weekend")
        )
        if no_weekend:
            self._contract_authorized_days = {
                "monday", "tuesday", "wednesday", "thursday", "friday"
            }
            self._contract_check_days = True

        self._archetype_name: str = contract.archetype_name

        # Numeric constraint: max meeting duration
        max_dur = constraints.get("max_meeting_duration_hrs")
        if max_dur:
            self._max_duration_hrs = float(max_dur)

    def set_time_window(
        self, action_type: str, start_hour: int, end_hour: int, timezone: str = "",
    ) -> None:
        if not (0 <= start_hour <= 23):
            raise ValueError(f"start_hour must be 0-23, got {start_hour}")
        if not (0 <= end_hour <= 23):
            raise ValueError(f"end_hour must be 0-23, got {end_hour}")
        if not timezone:
            _log.warning(
                "No timezone specified for time window on '%s'; defaulting to UTC",
                action_type,
            )
            timezone = "UTC"
        self._time_windows[action_type] = (start_hour, end_hour, timezone)

    def set_min_interval(self, action_type: str, seconds: float) -> None:
        self._min_intervals[action_type] = seconds

    def register_hold(self, hold: HoldRecord) -> None:
        """Register an incident-triggered hold."""
        with self._holds_lock:
            self._holds.append(hold)

    def clear_expired_holds(self, now: float | None = None) -> None:
        if now is None:
            now = _time.time()
        with self._holds_lock:
            self._holds = [h for h in self._holds if h.hold_until > now]

    def _check_holds(
        self, agent_id: str, action_type: str, now: float,
    ) -> HoldRecord | None:
        """Return the first active hold matching agent_id and action_type, or None."""
        with self._holds_lock:
            # Clean expired holds opportunistically
            self._holds = [h for h in self._holds if h.hold_until > now]
            for hold in self._holds:
                if hold.agent_id == agent_id and fnmatch(action_type, hold.action_type_pattern):
                    return hold
        return None

    def _check_blackout(self, action_type: str, date_str: str) -> BlackoutDate | None:
        """Return the first matching blackout date, or None."""
        for bd in self._config.blackout_dates:
            if bd.date != date_str:
                continue
            if bd.applies_to is None:
                return bd
            for pattern in bd.applies_to:
                if fnmatch(action_type, pattern):
                    return bd
        return None

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        import time
        from datetime import datetime, timezone as _tz

        now_ts = time.time()
        rules_evaluated: list[EvaluatedRule] = []

        # ── Contract constraint checks (parameter-based, not wall-clock) ──
        # These check action.parameters["day_of_week"] and ["hour"]
        # so workflow simulations get the right verdict regardless of real time.

        check_days = getattr(self, "_contract_check_days", False)
        check_hours = getattr(self, "_contract_check_hours", False)
        archetype = getattr(self, "_archetype_name", None)
        authorized_days_set = getattr(self, "_contract_authorized_days", set())

        if check_days:
            day = action.parameters.get("day_of_week", "").lower().strip()
            if day and day not in authorized_days_set:
                day_list = ", ".join(sorted(authorized_days_set))
                rules_evaluated.append(EvaluatedRule(
                    rule_id="contract_day_of_week",
                    rule_description=f"Authorized days: {day_list}",
                    triggered=True,
                    value_evaluated=day,
                    threshold_used=None,
                    outcome="fail",
                ))
                result = DimensionResult(
                    dimension_name=self.name,
                    score=0.0,
                    confidence=1.0,
                    veto=True,
                    rules_evaluated=rules_evaluated,
                    primary_signal="contract_day_blocked",
                )
                return DimensionScore(
                    dimension_name=self.name,
                    score=0.0,
                    weight=self.weight,
                    veto=True,
                    reasoning=(
                        f"'{day.capitalize()}' is not an authorized day"
                        + (f" for archetype '{archetype}'" if archetype else "")
                        + f". Authorized: {day_list}"
                    ),
                    result=result,
                )

        if check_hours:
            hour = action.parameters.get("hour")
            if hour is not None:
                hour = int(hour)
                start = self._contract_hour_start
                end = self._contract_hour_end
                if not (start <= hour < end):
                    rules_evaluated.append(EvaluatedRule(
                        rule_id="contract_hour",
                        rule_description=f"Authorized hours: {start:02d}:00–{end:02d}:00",
                        triggered=True,
                        value_evaluated=f"{hour:02d}:00",
                        threshold_used=None,
                        outcome="fail",
                    ))
                    result = DimensionResult(
                        dimension_name=self.name,
                        score=0.0,
                        confidence=1.0,
                        veto=True,
                        rules_evaluated=rules_evaluated,
                        primary_signal="contract_hour_blocked",
                    )
                    return DimensionScore(
                        dimension_name=self.name,
                        score=0.0,
                        weight=self.weight,
                        veto=True,
                        reasoning=(
                            f"Hour {hour:02d}:00 is outside authorized hours"
                            + (f" for archetype '{archetype}'" if archetype else "")
                            + f" ({start:02d}:00–{end:02d}:00)"
                        ),
                        result=result,
                    )

        # ── Duration check ──
        max_dur_key = getattr(self, "_max_duration_hrs", None)
        duration = action.parameters.get("duration_hrs")
        if max_dur_key and duration and float(duration) > max_dur_key:
            rules_evaluated.append(EvaluatedRule(
                rule_id="contract_duration",
                rule_description=f"Max duration: {max_dur_key}hrs",
                triggered=True,
                value_evaluated=f"{duration}hrs",
                threshold_used=max_dur_key,
                outcome="fail",
            ))
            result = DimensionResult(
                dimension_name=self.name,
                score=0.0,
                confidence=1.0,
                veto=True,
                rules_evaluated=rules_evaluated,
                primary_signal="contract_duration_exceeded",
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.0,
                weight=self.weight,
                veto=True,
                reasoning=f"Duration {duration}hrs exceeds maximum {max_dur_key}hrs",
                result=result,
            )

        # ── Check archetype contract day-of-week via wall clock (legacy) ──
        contract = self._archetype_contracts.get(context.agent_id)
        if contract is not None:
            legacy_authorized_days = contract.get_constraint("authorized_days")
            if legacy_authorized_days:
                utc_now = datetime.now(_tz.utc)
                day_abbr = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"][utc_now.weekday()]
                if day_abbr not in legacy_authorized_days:
                    rules_evaluated.append(EvaluatedRule(
                        rule_id="archetype_day_of_week",
                        rule_description=f"Authorized days: {legacy_authorized_days}",
                        triggered=True,
                        value_evaluated=day_abbr,
                        threshold_used=None,
                        outcome="fail",
                    ))
                    result = DimensionResult(
                        dimension_name=self.name,
                        score=0.0,
                        confidence=1.0,
                        veto=True,
                        rules_evaluated=rules_evaluated,
                        primary_signal="archetype_day_blocked",
                    )
                    return DimensionScore(
                        dimension_name=self.name,
                        score=0.0,
                        weight=self.weight,
                        veto=True,
                        reasoning=(
                            f"Archetype contract '{contract.archetype_name}' blocks "
                            f"actions on {day_abbr} (authorized: {legacy_authorized_days})"
                        ),
                        result=result,
                    )

        # Check incident holds
        hold = self._check_holds(context.agent_id, action.action_type, now_ts)
        if hold is not None:
            rules_evaluated.append(EvaluatedRule(
                rule_id="incident_hold",
                rule_description=f"Hold: {hold.reason}",
                triggered=True,
                value_evaluated=f"{context.agent_id}:{action.action_type}",
                threshold_used=hold.hold_until,
                outcome="fail",
            ))
            result = DimensionResult(
                dimension_name=self.name,
                score=0.0,
                confidence=1.0,
                veto=True,
                rules_evaluated=rules_evaluated,
                primary_signal="incident_hold_active",
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.0,
                weight=self.weight,
                veto=True,
                reasoning=f"Incident hold active: {hold.reason}",
                result=result,
            )

        # Check time window (timezone-aware)
        window = self._time_windows.get(action.action_type)
        if window:
            start, end, tz_name = window
            try:
                import zoneinfo
                tz = zoneinfo.ZoneInfo(tz_name)
            except Exception:
                _log.warning("Unknown timezone '%s', falling back to UTC", tz_name)
                tz = _tz.utc
            now_dt = datetime.now(tz)
            if start <= end:
                in_window = start <= now_dt.hour < end
            else:
                in_window = now_dt.hour >= start or now_dt.hour < end

            rules_evaluated.append(EvaluatedRule(
                rule_id="time_window",
                rule_description=f"Window {start}:00-{end}:00 {tz_name}",
                triggered=not in_window,
                value_evaluated=f"{now_dt.hour}:00 {tz_name}",
                threshold_used=None,
                outcome="pass" if in_window else "fail",
            ))
            if not in_window:
                result = DimensionResult(
                    dimension_name=self.name,
                    score=0.0,
                    confidence=1.0,
                    veto=True,
                    rules_evaluated=rules_evaluated,
                    primary_signal="outside_time_window",
                )
                return DimensionScore(
                    dimension_name=self.name,
                    score=0.0,
                    weight=self.weight,
                    veto=True,
                    reasoning=f"Outside time window ({start}:00-{end}:00 {tz_name})",
                    result=result,
                )

        # Check blackout dates (in UTC by default)
        utc_now = datetime.now(_tz.utc)
        date_str = utc_now.strftime("%Y-%m-%d")
        blackout = self._check_blackout(action.action_type, date_str)
        if blackout is not None:
            rules_evaluated.append(EvaluatedRule(
                rule_id="blackout_date",
                rule_description=f"Blackout: {blackout.reason}",
                triggered=True,
                value_evaluated=date_str,
                threshold_used=None,
                outcome="fail",
            ))
            result = DimensionResult(
                dimension_name=self.name,
                score=0.0,
                confidence=1.0,
                veto=True,
                rules_evaluated=rules_evaluated,
                primary_signal="blackout_date",
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.0,
                weight=self.weight,
                veto=True,
                reasoning=f"Blackout date: {blackout.reason}",
                result=result,
            )

        # Check minimum interval
        interval = self._min_intervals.get(action.action_type)
        if interval:
            key = f"{context.agent_id}:{action.action_type}"
            last = self._last_execution.get(key)
            if last and (time.time() - last) < interval:
                elapsed = time.time() - last
                rules_evaluated.append(EvaluatedRule(
                    rule_id="min_interval",
                    rule_description=f"Min interval {interval}s",
                    triggered=True,
                    value_evaluated=f"{elapsed:.1f}s",
                    threshold_used=interval,
                    outcome="fail",
                ))
                result = DimensionResult(
                    dimension_name=self.name,
                    score=0.1,
                    confidence=1.0,
                    veto=True,
                    rules_evaluated=rules_evaluated,
                    primary_signal="min_interval_violated",
                )
                return DimensionScore(
                    dimension_name=self.name,
                    score=0.1,
                    weight=self.weight,
                    veto=True,
                    reasoning=f"Min interval not met ({elapsed:.1f}s < {interval}s)",
                    result=result,
                )
            self._last_execution[key] = time.time()

        result = DimensionResult(
            dimension_name=self.name,
            score=1.0,
            confidence=1.0,
            rules_evaluated=rules_evaluated,
            primary_signal="temporal_ok",
        )
        return DimensionScore(
            dimension_name=self.name,
            score=1.0,
            weight=self.weight,
            reasoning="Temporal constraints satisfied",
            result=result,
        )


# --- Dimension 10: Precedent Alignment ---


@dataclass
class PrecedentConfig:
    """Configuration for precedent alignment scoring."""

    half_life_days: float = 90.0
    use_embeddings: bool = False  # requires embedding model; falls back to string matching


class PrecedentAlignment(GovernanceDimension):
    """Is this consistent with past governance decisions?

    Similar actions should get similar governance outcomes.  Uses a continuous
    graduated scale based on historical denial rate (replacing the old binary
    50% threshold), recency-weighted precedents (exponential decay with
    configurable half-life), and authority weighting (Tier 3 deliberated
    precedents count 2x).

    When ``use_embeddings=True`` and action schema fields are available,
    similarity is computed via cosine similarity on schema vectors rather than
    action_type string matching.  Falls back to string matching when schema
    is absent or embeddings are disabled.
    """

    name = "precedent_alignment"
    weight = 0.7
    can_veto = False

    def __init__(self, config: PrecedentConfig | None = None) -> None:
        self._config = config or PrecedentConfig()

    # -- graduated scale: denial_rate → score --------------------------------

    _GRADUATED_SCALE: list[tuple[float, float, float]] = [
        # (lower_bound, upper_bound, score)
        (0.0, 0.10, 0.90),
        (0.10, 0.25, 0.75),
        (0.25, 0.50, 0.55),
        (0.50, 0.75, 0.35),
        (0.75, 0.90, 0.15),
        (0.90, 1.01, 0.05),  # 1.01 so 1.0 is included
    ]

    @staticmethod
    def _graduated_score(denial_rate: float) -> float:
        for lo, hi, score in PrecedentAlignment._GRADUATED_SCALE:
            if lo <= denial_rate < hi:
                return score
        return 0.05  # fallback for edge-case rounding

    # -- recency weighting ---------------------------------------------------

    def _recency_weight(self, record_timestamp: float, now: float) -> float:
        """Exponential decay weight based on half-life."""
        half_life_seconds = self._config.half_life_days * 86400.0
        if half_life_seconds <= 0:
            return 1.0
        age = max(0.0, now - record_timestamp)
        return math.exp(-0.693147 * age / half_life_seconds)  # ln(2) ≈ 0.693147

    # -- authority weighting -------------------------------------------------

    @staticmethod
    def _authority_weight(record: Any) -> float:
        """Tier 3 deliberated precedents count 2x."""
        tier = getattr(record, "deliberation_tier", 1)
        return 2.0 if tier == 3 else 1.0

    # -- similarity ----------------------------------------------------------

    def _find_similar(self, action: Action, history: list[Any]) -> list[Any]:
        """Find similar precedents.  String-match on action_type by default."""
        # Embedding path (future): if use_embeddings and schema vectors exist
        # use cosine similarity.  Stubbed — requires embedding model integration.
        return [r for r in history if r.action.action_type == action.action_type]

    # -- evaluate ------------------------------------------------------------

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        from nomotic.types import Verdict

        rules: list[EvaluatedRule] = []

        if not context.action_history:
            rules.append(EvaluatedRule(
                rule_id="precedent_history_check",
                rule_description="Action history available",
                triggered=True, value_evaluated=0, threshold_used=1,
                outcome="skip",
            ))
            return DimensionScore(
                dimension_name=self.name, score=0.8, weight=self.weight,
                reasoning="No precedent history available",
                result=DimensionResult(
                    dimension_name=self.name, score=0.8,
                    rules_evaluated=rules,
                    primary_signal="no_history",
                    counterfactual="Would score based on denial rate if history existed",
                ),
            )

        similar = self._find_similar(action, context.action_history)
        if not similar:
            rules.append(EvaluatedRule(
                rule_id="precedent_type_match",
                rule_description="Similar action type found in history",
                triggered=False, value_evaluated=action.action_type,
                threshold_used=None, outcome="skip",
            ))
            return DimensionScore(
                dimension_name=self.name, score=0.7, weight=self.weight,
                reasoning="No precedent for this action type",
                result=DimensionResult(
                    dimension_name=self.name, score=0.7,
                    rules_evaluated=rules,
                    primary_signal="no_type_match",
                    counterfactual="Would score based on denial rate if similar actions existed",
                ),
            )

        # Compute weighted denial rate
        now = _time.time()
        total_weight = 0.0
        denied_weight = 0.0
        for r in similar:
            rw = self._recency_weight(r.timestamp, now)
            aw = self._authority_weight(r)
            w = rw * aw
            total_weight += w
            if r.verdict.verdict == Verdict.DENY:
                denied_weight += w

        denial_rate = denied_weight / total_weight if total_weight > 0 else 0.0
        score = self._graduated_score(denial_rate)

        rules.append(EvaluatedRule(
            rule_id="graduated_denial_rate",
            rule_description="Weighted denial rate mapped to graduated scale",
            triggered=denial_rate > 0,
            value_evaluated=round(denial_rate, 4),
            threshold_used="graduated_scale",
            outcome="pass" if score >= 0.55 else "warn" if score >= 0.35 else "fail",
        ))

        reasoning = (
            f"Denial rate {denial_rate:.1%} across {len(similar)} similar actions "
            f"(recency half-life={self._config.half_life_days}d)"
        )
        return DimensionScore(
            dimension_name=self.name, score=score, weight=self.weight,
            reasoning=reasoning,
            result=DimensionResult(
                dimension_name=self.name, score=score,
                rules_evaluated=rules,
                primary_signal="weighted_denial_rate",
                counterfactual=(
                    f"Would have scored {self._graduated_score(0.0)} "
                    f"if denial rate were 0%"
                ),
            ),
        )


# --- Dimension 11: Transparency ---


class Transparency(GovernanceDimension):
    """Can governance construct a coherent justification for its verdict?

    This dimension runs **after** all other probabilistic dimensions and
    receives their ``DimensionScore`` results via ``peer_scores``.  It
    evaluates three qualities of the governance evaluation itself:

    1. **Internal coherence** — if a veto-capable dimension scored < 0.2 but
       the UCS is still above the allow threshold (due to other high scores),
       the justification is incoherent.  Penalty: −0.3.
    2. **Counterfactual completeness** — what fraction of active dimensions
       produced a non-empty ``DimensionResult.counterfactual``?  Low fraction
       reduces score.
    3. **Explanation depth** — what fraction of dimensions produced
       ``rules_evaluated`` with at least one entry?  Low fraction reduces score.

    Base score: 1.0, reduced by penalties.  Weight: 1.2.
    """

    name = "transparency"
    weight = 1.2
    can_veto = False

    def evaluate(
        self,
        action: Action,
        context: AgentContext,
        peer_scores: list[DimensionScore] | None = None,
    ) -> DimensionScore:
        base_score = 1.0
        rules: list[EvaluatedRule] = []
        penalties: list[str] = []

        if peer_scores is None:
            # No peer data — cannot assess coherence; return moderate score
            rules.append(EvaluatedRule(
                rule_id="peer_scores_available",
                rule_description="Peer dimension scores provided",
                triggered=True, value_evaluated=False, threshold_used=True,
                outcome="skip",
            ))
            return DimensionScore(
                dimension_name=self.name, score=0.5, weight=self.weight,
                reasoning="No peer scores available; limited transparency assessment",
                result=DimensionResult(
                    dimension_name=self.name, score=0.5,
                    rules_evaluated=rules,
                    primary_signal="no_peer_scores",
                    context_missing=["peer_scores"],
                ),
            )

        # Filter out our own score if accidentally included
        peers = [s for s in peer_scores if s.dimension_name != self.name]

        if not peers:
            return DimensionScore(
                dimension_name=self.name, score=0.5, weight=self.weight,
                reasoning="No peer dimension scores to evaluate",
                result=DimensionResult(
                    dimension_name=self.name, score=0.5,
                    rules_evaluated=rules,
                    primary_signal="no_peers",
                ),
            )

        # --- 1. Internal coherence check ------------------------------------
        # A veto-capable dim scoring < 0.2 while overall signal is high = incoherent
        veto_capable_low = [
            s for s in peers if s.veto is False and getattr(s, "metadata", {}).get("can_veto", s.veto) is False
        ]
        # More accurate: check if any peer that *can* veto scored very low
        # We detect veto-capable dims by checking can_veto attribute or if the
        # score has veto=True potential (weight >= 1.5 is a proxy, but we use
        # an explicit check via score metadata or the dimension's own flag).
        incoherent = False
        low_veto_dims: list[str] = []
        for s in peers:
            # A dimension is veto-capable if it has veto=True on any of its scores
            # or if it's known to be veto-capable.  We check metadata for can_veto.
            is_veto_capable = s.metadata.get("can_veto", False) if s.metadata else False
            if is_veto_capable and s.score < 0.2:
                low_veto_dims.append(s.dimension_name)
                incoherent = True

        if incoherent:
            base_score -= 0.3
            penalties.append(
                f"Incoherence: veto-capable dimensions scored < 0.2 "
                f"({', '.join(low_veto_dims)}) but no veto fired"
            )

        rules.append(EvaluatedRule(
            rule_id="internal_coherence",
            rule_description="No veto-capable dimension scores < 0.2 without veto",
            triggered=incoherent,
            value_evaluated=low_veto_dims if low_veto_dims else None,
            threshold_used=0.2,
            outcome="fail" if incoherent else "pass",
        ))

        # --- 2. Counterfactual completeness ---------------------------------
        peers_with_result = [s for s in peers if s.result is not None]
        total_with_result = len(peers_with_result)
        counterfactual_count = sum(
            1 for s in peers_with_result
            if s.result is not None and s.result.counterfactual
        )
        cf_fraction = counterfactual_count / total_with_result if total_with_result > 0 else 0.0
        cf_penalty = max(0.0, (1.0 - cf_fraction) * 0.2)  # up to 0.2 penalty
        base_score -= cf_penalty
        if cf_penalty > 0.01:
            penalties.append(
                f"Low counterfactual completeness: {counterfactual_count}/{total_with_result} "
                f"dimensions ({cf_fraction:.0%})"
            )

        rules.append(EvaluatedRule(
            rule_id="counterfactual_completeness",
            rule_description="Fraction of dimensions with counterfactual explanations",
            triggered=cf_fraction < 1.0,
            value_evaluated=round(cf_fraction, 3),
            threshold_used=1.0,
            outcome="pass" if cf_fraction >= 0.8 else "warn" if cf_fraction >= 0.5 else "fail",
        ))

        # --- 3. Explanation depth -------------------------------------------
        rules_count = sum(
            1 for s in peers_with_result
            if s.result is not None and len(s.result.rules_evaluated) >= 1
        )
        rules_fraction = rules_count / total_with_result if total_with_result > 0 else 0.0
        depth_penalty = max(0.0, (1.0 - rules_fraction) * 0.2)  # up to 0.2 penalty
        base_score -= depth_penalty
        if depth_penalty > 0.01:
            penalties.append(
                f"Low explanation depth: {rules_count}/{total_with_result} "
                f"dimensions with rules ({rules_fraction:.0%})"
            )

        rules.append(EvaluatedRule(
            rule_id="explanation_depth",
            rule_description="Fraction of dimensions with rules_evaluated entries",
            triggered=rules_fraction < 1.0,
            value_evaluated=round(rules_fraction, 3),
            threshold_used=1.0,
            outcome="pass" if rules_fraction >= 0.8 else "warn" if rules_fraction >= 0.5 else "fail",
        ))

        final_score = max(0.0, min(1.0, base_score))
        reasoning = "; ".join(penalties) if penalties else "Governance justification fully coherent"

        return DimensionScore(
            dimension_name=self.name, score=final_score, weight=self.weight,
            reasoning=reasoning,
            result=DimensionResult(
                dimension_name=self.name, score=final_score,
                rules_evaluated=rules,
                primary_signal="justification_quality",
                counterfactual=(
                    "Would have scored 1.0 if all dimensions provided "
                    "counterfactuals and rules_evaluated"
                ),
            ),
        )


# --- Dimension 12: Human Override ---


@dataclass
class OverrideThresholdConfig:
    """Risk-based trust thresholds for human override."""

    default: float = 0.3
    by_action_type: dict[str, float] = field(default_factory=dict)
    by_environment: dict[str, float] = field(default_factory=dict)


class HumanOverride(GovernanceDimension):
    """Is human intervention required or requested?

    Some actions always require human approval. Others require it based on
    context (high value, sensitive target, low trust). This dimension
    enforces human-in-the-loop requirements.

    Supports persistent approval state via ``HumanOverrideStore``, approval
    expiry, and risk-based trust thresholds per action type and environment.
    """

    name = "human_override"
    weight = 2.0  # Highest weight — human override is authoritative
    can_veto = True

    def __init__(
        self,
        threshold_config: OverrideThresholdConfig | None = None,
        approval_ttl: float = 0.0,
        pending_ttl: float = 0.0,
    ) -> None:
        self._require_human: set[str] = set()
        self._threshold_config = threshold_config or OverrideThresholdConfig()
        self._approval_ttl = approval_ttl  # default TTL for granted approvals (0 = no expiry)
        self._pending_ttl = pending_ttl  # default TTL for pending approvals (0 = no expiry)
        # In-memory fallback (replaced by set_store)
        self._pending_approvals: set[str] = set()
        self._approved: set[str] = set()
        self._store: Any = None  # HumanOverrideStore | None
        self._escalation_callback: Any = None  # Callable[[PendingApproval], None] | None

    def set_store(self, store: Any) -> None:
        """Attach a persistent HumanOverrideStore."""
        self._store = store

    def set_escalation_callback(self, callback: Any) -> None:
        """Set callback invoked when a pending approval expires."""
        self._escalation_callback = callback

    def require_human_for(self, *action_types: str) -> None:
        self._require_human.update(action_types)

    def load_archetype_contract(self, contract: Any) -> None:
        """Load human override policy from an archetype contract.

        Registers all ``contract.human_override_actions`` as requiring human
        approval.  Also registers action types with
        ``authorized_action_categories == "escalate"``.
        """
        if contract.human_override_actions:
            self.require_human_for(*contract.human_override_actions)

        # Also require human for anything the scope marks as "escalate"
        escalate_actions = [
            k for k, v in contract.authorized_action_categories.items()
            if v == "escalate"
        ]
        if escalate_actions:
            self.require_human_for(*escalate_actions)

    def approve(self, action_id: str, valid_until: float = 0.0) -> None:
        if self._store is not None:
            from nomotic.store import GrantedApproval
            vu = valid_until if valid_until else (
                (_time.time() + self._approval_ttl) if self._approval_ttl > 0 else 0.0
            )
            self._store.save_granted(GrantedApproval(
                action_id=action_id,
                agent_id="",
                action_type="",
                valid_until=vu,
            ))
        else:
            self._approved.add(action_id)
            self._pending_approvals.discard(action_id)

    def _resolve_threshold(self, action: Action) -> float:
        """Determine the trust threshold for this action based on config."""
        cfg = self._threshold_config
        # Check action type specific threshold
        if action.action_type in cfg.by_action_type:
            return cfg.by_action_type[action.action_type]
        # Check environment specific threshold
        if action.environment is not None:
            env_name = action.environment.value if hasattr(action.environment, "value") else str(action.environment)
            if env_name in cfg.by_environment:
                return cfg.by_environment[env_name]
        return cfg.default

    def _is_approved(self, action_id: str, now: float) -> bool:
        if self._store is not None:
            # Expire stale grants first
            self._store.remove_expired_grants(now)
            grant = self._store.get_granted(action_id)
            if grant is not None:
                if grant.valid_until > 0 and grant.valid_until <= now:
                    return False
                return True
            return False
        return action_id in self._approved

    def _record_pending(self, action: Action, context: AgentContext, now: float) -> None:
        if self._store is not None:
            from nomotic.store import PendingApproval
            expires = (now + self._pending_ttl) if self._pending_ttl > 0 else 0.0
            self._store.save_pending(PendingApproval(
                action_id=action.id,
                agent_id=context.agent_id,
                action_type=action.action_type,
                created_at=now,
                expires_at=expires,
            ))
            # Expire old pendings and escalate
            expired = self._store.expire_pending(now)
            if expired and self._escalation_callback is not None:
                for pa in expired:
                    self._escalation_callback(pa)
        else:
            self._pending_approvals.add(action.id)

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        now = _time.time()
        rules_evaluated: list[EvaluatedRule] = []

        # Already approved by human
        if self._is_approved(action.id, now):
            result = DimensionResult(
                dimension_name=self.name,
                score=1.0,
                confidence=1.0,
                rules_evaluated=rules_evaluated,
                primary_signal="human_approved",
            )
            return DimensionScore(
                dimension_name=self.name,
                score=1.0,
                weight=self.weight,
                reasoning="Human-approved",
                result=result,
            )

        # Action type requires human approval
        if action.action_type in self._require_human:
            self._record_pending(action, context, now)
            rules_evaluated.append(EvaluatedRule(
                rule_id="require_human",
                rule_description=f"Action type '{action.action_type}' requires human approval",
                triggered=True,
                value_evaluated=action.action_type,
                threshold_used=None,
                outcome="fail",
            ))
            result = DimensionResult(
                dimension_name=self.name,
                score=0.0,
                confidence=1.0,
                veto=True,
                rules_evaluated=rules_evaluated,
                primary_signal="human_required",
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.0,
                weight=self.weight,
                veto=True,
                reasoning=f"Human approval required for '{action.action_type}'",
                result=result,
            )

        # Low trust triggers human requirement (risk-based threshold)
        threshold = self._resolve_threshold(action)
        trust = context.trust_profile.overall_trust
        if trust < threshold:
            self._record_pending(action, context, now)
            rules_evaluated.append(EvaluatedRule(
                rule_id="trust_threshold",
                rule_description=f"Trust {trust:.2f} < threshold {threshold:.2f}",
                triggered=True,
                value_evaluated=f"{trust:.2f}",
                threshold_used=threshold,
                outcome="fail",
            ))
            result = DimensionResult(
                dimension_name=self.name,
                score=0.0,
                confidence=1.0,
                veto=True,
                rules_evaluated=rules_evaluated,
                primary_signal="low_trust_override",
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.0,
                weight=self.weight,
                veto=True,
                reasoning=f"Low trust ({trust:.2f}) requires human approval (threshold={threshold:.2f})",
                result=result,
            )

        result = DimensionResult(
            dimension_name=self.name,
            score=1.0,
            confidence=1.0,
            rules_evaluated=rules_evaluated,
            primary_signal="no_override_needed",
        )
        return DimensionScore(
            dimension_name=self.name,
            score=1.0,
            weight=self.weight,
            reasoning="No human override required",
            result=result,
        )


# --- Dimension 13: Ethical Alignment ---


@dataclass
class EthicalRule:
    """Declarative ethical rule for the EthicalAlignment dimension.

    ``applies_to``: action types this rule applies to; empty list means all.
    ``data_sensitivity_threshold``: only apply when action's data_sensitivity
    is at or above this level.
    ``severity``: "violation" (score 0.0, veto), "concern" (score 0.4,
    escalation_required), or "advisory" (score 0.65, score reduction only).
    ``custom_check``: optional lambda ``(Action, AgentContext) -> (bool, str)``
    for logic that can't be expressed declaratively.
    """

    rule_id: str
    description: str
    applies_to: list[str] = field(default_factory=list)
    data_sensitivity_threshold: DataSensitivity | None = None
    severity: str = "violation"  # "violation" | "concern" | "advisory"
    custom_check: Callable[[Action, AgentContext], tuple[bool, str]] | None = None


# Severity → (score, veto, escalation_required)
_SEVERITY_MAP: dict[str, tuple[float, bool, bool]] = {
    "violation": (0.0, True, False),
    "concern": (0.4, False, True),
    "advisory": (0.65, False, False),
}


class EthicalAlignment(GovernanceDimension):
    """Does the action meet ethical constraints?

    Evaluates against configured ethical rules. Rules are evaluated
    non-short-circuit: ALL applicable rules run, and all failures are
    collected. The worst severity determines the verdict score.

    Unconfigured deployments score 0.5 (uncertainty), not 0.8.
    This is a breaking change from the previous default of 0.8.

    Supports both the new ``EthicalRule`` dataclass and legacy lambdas
    (via ``add_rule``), which are wrapped as ``EthicalRule`` instances
    with ``custom_check``.
    """

    name = "ethical_alignment"
    weight = 2.0
    can_veto = True

    def __init__(self) -> None:
        self._ethical_rules: list[EthicalRule] = []

    def add_ethical_rule(self, rule: EthicalRule) -> None:
        """Add a declarative ethical rule."""
        self._ethical_rules.append(rule)

    def add_rule(
        self, rule: Callable[[Action, AgentContext], tuple[bool, str]]
    ) -> None:
        """Legacy interface: add a lambda rule.

        Wraps the lambda in an ``EthicalRule`` with severity="violation"
        for backwards compatibility.
        """
        self._ethical_rules.append(EthicalRule(
            rule_id=f"lambda_{len(self._ethical_rules)}",
            description="Legacy lambda rule",
            custom_check=rule,
        ))

    def _rule_applies(self, rule: EthicalRule, action: Action) -> bool:
        """Check whether a rule is relevant to this action."""
        if rule.applies_to and action.action_type not in rule.applies_to:
            return False
        if rule.data_sensitivity_threshold is not None:
            if action.data_sensitivity is None:
                return False
            threshold_order = _SENSITIVITY_ORDER.get(rule.data_sensitivity_threshold, 0)
            action_order = _SENSITIVITY_ORDER.get(action.data_sensitivity, 0)
            if action_order < threshold_order:
                return False
        return True

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        t0 = _time.monotonic()

        if not self._ethical_rules:
            result = DimensionResult(
                dimension_name=self.name,
                score=0.5,
                confidence=0.5,
                primary_signal="No ethical rules configured — scoring as uncertain",
                evaluation_time_ms=(_time.monotonic() - t0) * 1000.0,
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.5,
                weight=self.weight,
                confidence=0.5,
                reasoning="No ethical rules configured",
                result=result,
            )

        evaluated_rules: list[EvaluatedRule] = []
        worst_score = 1.0
        worst_veto = False
        escalation = False
        failures: list[str] = []

        for rule in self._ethical_rules:
            # Rule relevance filtering
            if not self._rule_applies(rule, action):
                evaluated_rules.append(EvaluatedRule(
                    rule_id=rule.rule_id,
                    rule_description=rule.description,
                    triggered=False,
                    value_evaluated=None,
                    threshold_used=None,
                    outcome="skip",
                ))
                continue

            # Evaluate the rule
            if rule.custom_check is not None:
                passes, reason = rule.custom_check(action, context)
            else:
                # Declarative-only rules with no custom_check always pass
                passes, reason = True, "declarative rule — no custom_check"

            if passes:
                evaluated_rules.append(EvaluatedRule(
                    rule_id=rule.rule_id,
                    rule_description=rule.description,
                    triggered=False,
                    value_evaluated=None,
                    threshold_used=None,
                    outcome="pass",
                ))
            else:
                sev_score, sev_veto, sev_escalation = _SEVERITY_MAP.get(
                    rule.severity, (0.0, True, False),
                )
                if sev_score < worst_score:
                    worst_score = sev_score
                if sev_veto:
                    worst_veto = True
                if sev_escalation:
                    escalation = True
                failures.append(f"[{rule.severity}] {rule.rule_id}: {reason}")
                evaluated_rules.append(EvaluatedRule(
                    rule_id=rule.rule_id,
                    rule_description=rule.description,
                    triggered=True,
                    value_evaluated=reason,
                    threshold_used=rule.severity,
                    outcome="fail",
                ))

        if not failures:
            score = 1.0
            reasoning = "All ethical rules satisfied"
        else:
            score = worst_score
            reasoning = "Ethical failure(s): " + "; ".join(failures)

        elapsed = (_time.monotonic() - t0) * 1000.0

        result = DimensionResult(
            dimension_name=self.name,
            score=score,
            veto=worst_veto,
            rules_evaluated=evaluated_rules,
            primary_signal=failures[0] if failures else "All rules passed",
            escalation_required=escalation,
            evaluation_time_ms=elapsed,
        )

        return DimensionScore(
            dimension_name=self.name,
            score=score,
            weight=self.weight,
            veto=worst_veto,
            reasoning=reasoning,
            result=result,
        )


# --- Dimension 14: Jurisdictional Compliance ---

# Built-in jurisdiction rules. Keys are zone glob patterns.
# These cover major jurisdictions with strict data governance requirements.
JURISDICTION_RULES: dict[str, dict[str, Any]] = {
    "eu/*": {
        "regulations": ["gdpr"],
        "residency_strict": True,
        "adequacy_destinations": [
            "eu/*", "ch/*", "gb/*", "ca/*", "jp/*", "kr/*",
            "nz/*", "uy/*", "ar/*", "il/*",
        ],
        "pii_requires_legal_basis": True,
        "health_classification": "sensitive_pii",
    },
    "cn/*": {
        "regulations": ["pipl", "dsl"],
        "residency_strict": True,
        "adequacy_destinations": [],
        "critical_data_transfer_prohibited": True,
    },
    "us/*": {
        "regulations": ["ccpa"],
        "residency_strict": False,
        "hipaa_zones": ["us/healthcare/*"],
        "ccpa_applies_if_subject_in": ["us/ca/*"],
    },
    "in/*": {
        "regulations": ["dpdpa"],
        "residency_strict": True,
        "adequacy_destinations": ["in/*"],
    },
    "gb/*": {
        "regulations": ["uk_gdpr"],
        "residency_strict": True,
        "adequacy_destinations": [
            "eu/*", "gb/*", "ch/*", "ca/*", "jp/*", "nz/*", "uy/*", "ar/*",
        ],
        "pii_requires_legal_basis": True,
    },
    "sg/*": {
        "regulations": ["pdpa"],
        "residency_strict": False,
        "adequacy_destinations": ["sg/*", "au/*", "nz/*"],
    },
    # ── Hybrid zones (multiple regulations co-apply) ─────────────────
    "us/hipaa": {
        "regulations": ["hipaa", "ccpa"],
        "residency_strict": False,
        "adequacy_destinations": [],
        "hipaa_zone": True,
        "notes": "HIPAA + CCPA co-apply for California healthcare data",
    },
    # ── US state zones ────────────────────────────────────────────────
    "us/ny": {
        "regulations": ["ny_shield"],
        "residency_strict": False,
        "adequacy_destinations": [],
        "notes": "New York SHIELD Act",
    },
    "us/tx": {
        "regulations": ["tdpsa"],
        "residency_strict": False,
        "adequacy_destinations": [],
        "notes": "Texas Data Privacy and Security Act",
    },
    "us/va": {
        "regulations": ["vcdpa"],
        "residency_strict": False,
        "adequacy_destinations": [],
        "notes": "Virginia Consumer Data Protection Act",
    },
    # ── International zones ───────────────────────────────────────────
    "br": {
        "regulations": ["lgpd"],
        "residency_strict": False,
        "adequacy_destinations": ["eu/*", "gb", "us/*"],
        "notes": "Brazil LGPD — Lei Geral de Proteção de Dados",
    },
    "au": {
        "regulations": ["privacy_act", "apps"],
        "residency_strict": False,
        "adequacy_destinations": ["eu/*", "gb", "nz", "us/*"],
        "notes": "Australia Privacy Act 1988 + Australian Privacy Principles",
    },
    "ca": {
        "regulations": ["pipeda"],
        "residency_strict": False,
        "adequacy_destinations": ["eu/*", "gb", "us/*"],
        "notes": "Canada PIPEDA",
    },
}

CONFLICTING_REGULATION_PAIRS: list[tuple[str, str]] = [
    ("gdpr", "pipl"),      # Different adequacy rules; cross-border complex
    ("hipaa", "gdpr"),     # Different consent standards for health data
    ("ccpa", "pipl"),      # Different data subject rights
    ("gdpr", "lgpd"),      # Generally compatible but cross-border complex
]

# ── GDPR Legal Basis Appropriateness ──────────────────────────────────

# Maps (legal_basis, action_type) → whether it is appropriate.
# ``None`` means no opinion (pass).  ``False`` means flag as advisory.
_LEGAL_BASIS_APPROPRIATENESS: dict[tuple[str, str], bool | None] = {
    ("legitimate_interest", "marketing_communication"): False,
    ("legitimate_interest", "profiling"): False,
    ("legitimate_interest", "automated_decision"): False,
}


@dataclass
class LegalBasisMapping:
    """Declares the legal basis for a specific processing purpose.

    Used by ``JurisdictionalCompliance`` to verify that the declared
    legal basis is appropriate for the action's ``action_type``.
    """

    legal_basis: str
    action_type: str
    appropriate: bool | None = None  # None = no opinion

    def check(self) -> bool | None:
        """Return appropriateness.  Falls back to the built-in map."""
        if self.appropriate is not None:
            return self.appropriate
        return _LEGAL_BASIS_APPROPRIATENESS.get(
            (self.legal_basis, self.action_type),
        )


class JurisdictionalCompliance(GovernanceDimension):
    """Dimension 14: Jurisdictional Compliance.

    Evaluates whether the proposed action is permitted under applicable
    legal and regulatory jurisdictions. Evaluated per-action at runtime —
    not static configuration.

    Evaluation categories:
    1. Per-action zone determination (``action.declared_jurisdiction``)
    2. Cross-border transfer legality
    3. Data classification against jurisdiction rules
    4. Legal basis verification (GDPR/UK_GDPR zones)
    5. GDPR legal basis appropriateness
    6. Regulation conflict escalation
    7. Inference zone compliance

    A missing JurisdictionalContext (no context profile, or profile
    has no jurisdictional section) returns 0.7 — caution without veto.
    This preserves backward compatibility for deployments that have not
    yet configured jurisdictional context.
    """

    name = "jurisdictional_compliance"
    weight = 1.4
    can_veto = True

    def __init__(self) -> None:
        self._custom_rules: dict[str, dict[str, Any]] = {}
        # agent_id -> operating_zone override (for configure_agent_zone)
        self._agent_zones: dict[str, str] = {}
        self._jurisdictional_accessor: Callable[[str], Any] | None = None

    def add_jurisdiction_rule(self, zone_pattern: str, rules: dict[str, Any]) -> None:
        """Add a custom jurisdiction rule. Custom rules take precedence over built-in."""
        self._custom_rules[zone_pattern] = rules

    def configure_agent_zone(self, agent_id: str, operating_zone: str) -> None:
        """Store agent zone override. Used when the agent's zone is known statically."""
        self._agent_zones[agent_id] = operating_zone

    def set_jurisdictional_accessor(
        self, accessor: Callable[[str], Any],
    ) -> None:
        """Set a function that returns JurisdictionalContext | None for a given agent_id."""
        self._jurisdictional_accessor = accessor

    def _get_rules_for_zone(self, zone: str) -> dict[str, Any]:
        """Return merged rules for a given zone.

        Check custom rules first (fnmatch), then JURISDICTION_RULES.
        Returns empty dict if no match.
        """
        import fnmatch as _fnmatch

        # Custom rules first
        for pattern, rules in self._custom_rules.items():
            if _fnmatch.fnmatch(zone, pattern):
                return rules

        # Built-in rules
        for pattern, rules in JURISDICTION_RULES.items():
            if _fnmatch.fnmatch(zone, pattern):
                return rules

        return {}

    def _zone_is_adequate_destination(self, source_zone: str, destination_zone: str) -> bool:
        """Check if destination_zone appears in the adequacy_destinations list of source zone's rules."""
        import fnmatch as _fnmatch

        rules = self._get_rules_for_zone(source_zone)
        adequacy_list = rules.get("adequacy_destinations", [])
        for pattern in adequacy_list:
            if _fnmatch.fnmatch(destination_zone, pattern):
                return True
        return False

    def _determine_zone(self, action: Action, context: AgentContext) -> str | None:
        """Determine the effective jurisdiction zone for this action.

        Priority:
        1. ``action.declared_jurisdiction`` (per-action override)
        2. Agent's registered zone via ``configure_agent_zone``
        3. ``None`` — unknown
        """
        if action.declared_jurisdiction:
            return action.declared_jurisdiction
        return self._agent_zones.get(context.agent_id)

    def _check_regulation_conflicts(
        self, regulations: set[str],
    ) -> list[tuple[str, str]]:
        """Return list of conflicting regulation pairs that co-apply."""
        conflicts: list[tuple[str, str]] = []
        for a, b in CONFLICTING_REGULATION_PAIRS:
            if a in regulations and b in regulations:
                conflicts.append((a, b))
        return conflicts

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        t0 = _time.monotonic()
        evaluated_rules: list[EvaluatedRule] = []
        schema_fields_used: list[str] = []
        escalation = False

        # 0. Determine effective zone for this action
        effective_zone = self._determine_zone(action, context)
        if action.declared_jurisdiction:
            schema_fields_used.append("declared_jurisdiction")
        if action.data_sensitivity is not None:
            schema_fields_used.append("data_sensitivity")

        # 1. Retrieve jurisdictional context
        jctx = None
        if self._jurisdictional_accessor is not None:
            jctx = self._jurisdictional_accessor(context.agent_id)

        if jctx is None:
            elapsed = (_time.monotonic() - t0) * 1000.0
            result = DimensionResult(
                dimension_name=self.name,
                score=0.7,
                confidence=0.5,
                primary_signal="No jurisdictional context available",
                schema_fields_used=schema_fields_used,
                context_missing=["jurisdictional_context"],
                evaluation_time_ms=elapsed,
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.7,
                weight=self.weight,
                reasoning="No jurisdictional context available; proceeding with caution",
                result=result,
            )

        # If effective_zone is set, evaluate under that zone's regulations
        # regardless of the agent's registered zone
        if effective_zone:
            zone_rules = self._get_rules_for_zone(effective_zone)
            if zone_rules:
                zone_regulations = set(zone_rules.get("regulations", []))
            else:
                zone_regulations = set()
        else:
            zone_regulations = set()

        # Merge with jctx applicable_regulations
        all_regulations = set(jctx.applicable_regulations) | zone_regulations

        # 2. Check cross-border transfer legality
        if jctx.cross_border_transfer and jctx.data_residency_zones:
            for source_zone in jctx.data_residency_zones:
                source_rules = self._get_rules_for_zone(source_zone)
                if source_rules.get("residency_strict"):
                    # Check each destination zone
                    for dest in jctx.transfer_destination_zones:
                        if not self._zone_is_adequate_destination(source_zone, dest):
                            # Check if transfer mechanism saves it
                            safe_mechanisms = {
                                "standard_contractual_clauses",
                                "binding_corporate_rules",
                                "explicit_consent",
                            }
                            if jctx.transfer_mechanism not in safe_mechanisms:
                                elapsed = (_time.monotonic() - t0) * 1000.0
                                reason = (
                                    f"Cross-border transfer from {source_zone} to {dest} "
                                    f"violates data residency requirements: no adequacy decision "
                                    f"or valid transfer mechanism. "
                                    f"Applicable regulations: {source_rules.get('regulations', [])}"
                                )
                                evaluated_rules.append(EvaluatedRule(
                                    rule_id="cross_border_transfer",
                                    rule_description="Cross-border data transfer legality",
                                    triggered=True,
                                    value_evaluated=f"{source_zone}->{dest}",
                                    threshold_used="adequacy_decision or transfer_mechanism",
                                    outcome="fail",
                                ))
                                result = DimensionResult(
                                    dimension_name=self.name,
                                    score=0.0,
                                    veto=True,
                                    rules_evaluated=evaluated_rules,
                                    primary_signal=reason,
                                    schema_fields_used=schema_fields_used,
                                    evaluation_time_ms=elapsed,
                                )
                                return DimensionScore(
                                    dimension_name=self.name,
                                    score=0.0,
                                    weight=self.weight,
                                    veto=True,
                                    reasoning=reason,
                                    result=result,
                                )
                            else:
                                elapsed = (_time.monotonic() - t0) * 1000.0
                                reason = (
                                    f"Cross-border transfer from {source_zone} to {dest} "
                                    f"via {jctx.transfer_mechanism}"
                                )
                                evaluated_rules.append(EvaluatedRule(
                                    rule_id="cross_border_transfer",
                                    rule_description="Cross-border data transfer legality",
                                    triggered=False,
                                    value_evaluated=f"{source_zone}->{dest} via {jctx.transfer_mechanism}",
                                    threshold_used="safe_mechanism",
                                    outcome="pass",
                                ))
                                result = DimensionResult(
                                    dimension_name=self.name,
                                    score=0.9,
                                    rules_evaluated=evaluated_rules,
                                    primary_signal=reason,
                                    schema_fields_used=schema_fields_used,
                                    evaluation_time_ms=elapsed,
                                )
                                return DimensionScore(
                                    dimension_name=self.name,
                                    score=0.9,
                                    weight=self.weight,
                                    reasoning=reason,
                                    result=result,
                                )

        # 3. Legal basis check (GDPR/UK_GDPR zones)
        gdpr_regulations = {"gdpr", "uk_gdpr"}
        if all_regulations & gdpr_regulations:
            pii_classifications = {"pii", "sensitive_pii", "health", "financial"}
            if jctx.data_classification in pii_classifications:
                if jctx.legal_basis is None:
                    elapsed = (_time.monotonic() - t0) * 1000.0
                    reason = (
                        f"GDPR applies ({jctx.data_classification} data) but no legal basis "
                        f"specified. Provide legal_basis in JurisdictionalContext."
                    )
                    evaluated_rules.append(EvaluatedRule(
                        rule_id="gdpr_legal_basis_required",
                        rule_description="GDPR requires legal basis for PII processing",
                        triggered=True,
                        value_evaluated=jctx.data_classification,
                        threshold_used="pii_classifications",
                        outcome="fail",
                    ))
                    result = DimensionResult(
                        dimension_name=self.name,
                        score=0.3,
                        rules_evaluated=evaluated_rules,
                        primary_signal=reason,
                        schema_fields_used=schema_fields_used,
                        context_missing=["legal_basis"],
                        evaluation_time_ms=elapsed,
                    )
                    return DimensionScore(
                        dimension_name=self.name,
                        score=0.3,
                        weight=self.weight,
                        reasoning=reason,
                        result=result,
                    )

        # 4. GDPR legal basis appropriateness check
        if all_regulations & gdpr_regulations and jctx.legal_basis:
            mapping = LegalBasisMapping(
                legal_basis=jctx.legal_basis,
                action_type=action.action_type,
            )
            appropriate = mapping.check()
            if appropriate is False:
                evaluated_rules.append(EvaluatedRule(
                    rule_id="gdpr_legal_basis_appropriateness",
                    rule_description=(
                        f"Legal basis '{jctx.legal_basis}' may be inappropriate "
                        f"for action type '{action.action_type}'"
                    ),
                    triggered=True,
                    value_evaluated=f"{jctx.legal_basis}/{action.action_type}",
                    threshold_used="legal_basis_mapping",
                    outcome="fail",
                ))
                # Advisory warning — does not veto, does not reduce score below 0.85
                # but we note it in the result

        # 5. Regulation conflict escalation
        conflicts = self._check_regulation_conflicts(all_regulations)
        if conflicts:
            escalation = True  # Hard escalation — Tier 3
            conflict_strs = [f"{a}+{b}" for a, b in conflicts]
            evaluated_rules.append(EvaluatedRule(
                rule_id="regulation_conflict",
                rule_description=f"Conflicting regulations co-apply: {', '.join(conflict_strs)}",
                triggered=True,
                value_evaluated=str(conflict_strs),
                threshold_used="CONFLICTING_REGULATION_PAIRS",
                outcome="fail",
            ))

        # 6. Inference zone compliance check
        inference_zone = jctx.model_inference_zone or jctx.agent_operating_zone
        if inference_zone and jctx.data_residency_zones:
            for source_zone in jctx.data_residency_zones:
                source_rules = self._get_rules_for_zone(source_zone)
                if source_rules.get("critical_data_transfer_prohibited"):
                    # e.g. China PIPL critical data
                    if not inference_zone.startswith(source_zone.split("/")[0]):
                        elapsed = (_time.monotonic() - t0) * 1000.0
                        reason = (
                            f"Model inference in {inference_zone} is prohibited for "
                            f"data from {source_zone}: critical data processing "
                            f"restrictions apply ({source_rules.get('regulations', [])})"
                        )
                        evaluated_rules.append(EvaluatedRule(
                            rule_id="inference_zone_compliance",
                            rule_description="Inference zone vs data residency",
                            triggered=True,
                            value_evaluated=f"inference={inference_zone}, data={source_zone}",
                            threshold_used="critical_data_transfer_prohibited",
                            outcome="fail",
                        ))
                        result = DimensionResult(
                            dimension_name=self.name,
                            score=0.0,
                            veto=True,
                            rules_evaluated=evaluated_rules,
                            primary_signal=reason,
                            schema_fields_used=schema_fields_used,
                            evaluation_time_ms=elapsed,
                        )
                        return DimensionScore(
                            dimension_name=self.name,
                            score=0.0,
                            weight=self.weight,
                            veto=True,
                            reasoning=reason,
                            result=result,
                        )

        # 7. Passing all checks
        elapsed = (_time.monotonic() - t0) * 1000.0
        if not jctx.data_residency_zones and not all_regulations:
            result = DimensionResult(
                dimension_name=self.name,
                score=0.8,
                rules_evaluated=evaluated_rules,
                primary_signal="Minimal jurisdictional context; no violations detected",
                schema_fields_used=schema_fields_used,
                escalation_required=escalation,
                evaluation_time_ms=elapsed,
            )
            return DimensionScore(
                dimension_name=self.name,
                score=0.8,
                weight=self.weight,
                reasoning="Minimal jurisdictional context; no violations detected",
                result=result,
            )

        # Check if legal basis appropriateness advisory was triggered
        appropriateness_advisory = any(
            r.rule_id == "gdpr_legal_basis_appropriateness" and r.triggered
            for r in evaluated_rules
        )
        advisory_note = ""
        if appropriateness_advisory:
            advisory_note = (
                f" Advisory: legal basis '{jctx.legal_basis}' may be "
                f"inappropriate for '{action.action_type}'."
            )

        reason = (
            f"Jurisdictional compliance verified. "
            f"Regulations: {sorted(all_regulations) or 'none specified'}. "
            f"Cross-border: {jctx.cross_border_transfer}."
            f"{advisory_note}"
        )

        primary = reason
        if escalation:
            conflict_strs = [f"{a}+{b}" for a, b in conflicts]
            primary = f"Regulation conflicts detected ({', '.join(conflict_strs)}); escalation required"

        result = DimensionResult(
            dimension_name=self.name,
            score=1.0,
            rules_evaluated=evaluated_rules,
            primary_signal=primary,
            escalation_required=escalation,
            schema_fields_used=schema_fields_used,
            evaluation_time_ms=elapsed,
        )
        return DimensionScore(
            dimension_name=self.name,
            score=1.0,
            weight=self.weight,
            reasoning=reason,
            result=result,
        )


# --- Registry ---


class DimensionRegistry:
    """Registry of all active governance dimensions.

    Core dimensions (D1-D14) are registered at construction.
    Plugin dimensions (D15-D20 from nomotic-pro) are discovered
    via Python entry points in the 'nomotic.dimensions' group.
    Plugin dimensions are only registered when the activated tier
    permits them (Pro or Enterprise).
    """

    def __init__(self, activated_tier: ActivatedTier = ActivatedTier.OPEN) -> None:
        self._dimensions: dict[str, GovernanceDimension] = {}
        self._activated_tier = activated_tier
        self._register_core_dimensions()
        if activated_tier in (ActivatedTier.PRO, ActivatedTier.ENTERPRISE):
            self._discover_plugin_dimensions()

    def _register_core_dimensions(self) -> None:
        """Register D1-D14 — always available."""
        self.register(ScopeCompliance())
        self.register(AuthorityVerification())
        self.register(ResourceBoundaries())
        self.register(BehavioralConsistency())
        self.register(CascadingImpact())
        self.register(StakeholderImpact())
        self.register(IncidentDetection())
        self.register(IsolationIntegrity())
        self.register(TemporalCompliance())
        self.register(PrecedentAlignment())
        self.register(Transparency())
        self.register(HumanOverride())
        self.register(EthicalAlignment())
        self.register(JurisdictionalCompliance())

    def _discover_plugin_dimensions(self) -> None:
        """Discover and register plugin dimensions from installed packages.

        Plugin packages register via the 'nomotic.dimensions' entry point group.
        Each entry point value is a GovernanceDimension subclass.

        Example (in nomotic-pro's pyproject.toml):
            [project.entry_points."nomotic.dimensions"]
            reversibility = "nomotic_pro.dimensions.reversibility:ReversibilityDimension"
            minimum_necessary_privilege = "nomotic_pro.dimensions.privilege:MinimumNecessaryPrivilege"
            ...
        """
        try:
            eps = importlib.metadata.entry_points(group="nomotic.dimensions")
        except Exception:
            return

        for ep in eps:
            try:
                dimension_class = ep.load()
                instance = dimension_class()
                self._dimensions[instance.name] = instance
                _log.debug("Registered plugin dimension: %s (from %s)", instance.name, ep.value)
            except Exception as e:
                _log.warning("Failed to load plugin dimension '%s': %s", ep.name, e)
                # Never fail hard on plugin load failure — governance continues with available dimensions

    def register(self, dimension: GovernanceDimension) -> None:
        self._dimensions[dimension.name] = dimension

    def get(self, name: str) -> GovernanceDimension | None:
        return self._dimensions.get(name)

    @property
    def dimensions(self) -> list[GovernanceDimension]:
        return list(self._dimensions.values())

    def available_count(self) -> dict[str, int]:
        """Return counts of core vs plugin dimensions active."""
        return {
            "core": sum(1 for d in self._dimensions.values() if d.name in CORE_DIMENSION_NAMES),
            "plugin": sum(1 for d in self._dimensions.values() if d.name not in CORE_DIMENSION_NAMES),
            "total": len(self._dimensions),
        }

    def evaluate_all(
        self, action: Action, context: AgentContext
    ) -> list[DimensionScore]:
        """Evaluate all dimensions and return their scores.

        Transparency runs last and receives peer scores from all other dimensions.
        """
        scores: list[DimensionScore] = []
        transparency_dim: GovernanceDimension | None = None

        for dim in self._dimensions.values():
            if dim.name == "transparency":
                transparency_dim = dim
            else:
                scores.append(dim.evaluate(action, context))

        # Transparency runs last with peer scores
        if transparency_dim is not None:
            scores.append(transparency_dim.evaluate(action, context, peer_scores=scores))

        return scores

    @classmethod
    def create_default(cls, activated_tier: ActivatedTier = ActivatedTier.OPEN) -> DimensionRegistry:
        """Create a registry with core dimensions and optional plugin discovery."""
        return cls(activated_tier=activated_tier)

    def active_dimensions(
        self,
        tier: "ProductTier",
        custom_enabled: list[str] | None = None,
        custom_disabled: list[str] | None = None,
    ) -> list[GovernanceDimension]:
        """Return the active dimension set for the current tier and license.

        Dimensions declared in the tier mapping but not present in the registry
        (because the plugin package is not installed) are silently skipped —
        not an error. The UCS normalizes across whatever is actually active.

        A startup warning is logged when Pro/Enterprise tier is licensed but
        no plugin dimensions are registered:
        "Pro tier licensed but nomotic-pro is not installed. D15-D20 inactive."
        """
        from nomotic.tiering import TieringConfig

        cfg = TieringConfig(
            tier=tier,
            custom_enabled=list(custom_enabled or []),
            custom_disabled=list(custom_disabled or []),
        )
        active_names = set(cfg.active_dimension_names())
        return [d for d in self._dimensions.values() if d.name in active_names]
