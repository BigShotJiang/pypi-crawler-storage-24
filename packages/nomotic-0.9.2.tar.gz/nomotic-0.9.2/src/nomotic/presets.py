"""Compliance-aligned presets and severity tiers.

Presets package expert-curated governance configurations aligned to the
concerns of specific compliance frameworks (SOC2, HIPAA, PCI-DSS,
ISO 27001) and risk tolerances (standard, strict, ultra_strict).  Users
select a preset instead of manually defining weights, vetoes, and
thresholds.

**Important:** These presets are Nomotic's interpretation of dimensional
weights aligned to framework concerns.  They are not certified, endorsed,
or approved by any standards body and do not constitute compliance.

Usage::

    from nomotic.presets import get_preset, merge_presets
    from nomotic.runtime import RuntimeConfig

    config = RuntimeConfig.from_preset("hipaa_aligned")
    config = RuntimeConfig.from_preset("soc2_aligned", allow_threshold=0.85)

    # Combine a severity tier with a compliance framework
    merged = merge_presets(get_preset("strict"), get_preset("hipaa_aligned"))
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GovernancePreset",
    "INDUSTRY_PRESET_RECOMMENDATIONS",
    "PRESET_DISCLAIMER",
    "get_preset",
    "get_preset_names",
    "list_compliance_presets",
    "list_presets",
    "list_severity_presets",
    "merge_presets",
]

# The 14 governance dimensions (D1–D14)
DIMENSION_NAMES: list[str] = [
    "scope_compliance",
    "authority_verification",
    "resource_boundaries",
    "behavioral_consistency",
    "cascading_impact",
    "stakeholder_impact",
    "incident_detection",
    "isolation_integrity",
    "temporal_compliance",
    "precedent_alignment",
    "transparency",
    "human_override",
    "ethical_alignment",
    "jurisdictional_compliance",
]

TRUST_SETTING_KEYS: set[str] = {
    "success_increment",
    "violation_decrement",
    "interrupt_cost",
    "decay_rate",
    "floor",
    "ceiling",
}

PRESET_DISCLAIMER: str = (
    "Governance presets are Nomotic's interpretation of dimensional weights "
    "aligned to the concerns of the referenced framework. They are not "
    "certified, endorsed, or approved by any standards body. These presets "
    "do not constitute compliance with any regulatory framework. Consult "
    "your compliance team before deploying in regulated environments."
)


@dataclass(frozen=True)
class GovernancePreset:
    """A reusable governance configuration template."""

    name: str
    display_name: str
    description: str
    category: str  # "compliance" or "severity"
    framework_reference: str  # e.g. "SOC2" for compliance presets, "" for severity
    certified: bool  # Always False for built-in presets
    disclaimer: str  # PRESET_DISCLAIMER for compliance, "" for severity
    dimension_weights: dict[str, float]
    veto_dimensions: list[str]
    allow_threshold: float
    deny_threshold: float
    trust_settings: dict[str, float]
    metadata: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        # Validate all 14 dimensions (D1–D14) are present in weights
        missing = set(DIMENSION_NAMES) - set(self.dimension_weights)
        if missing:
            raise ValueError(
                f"Preset '{self.name}' missing dimension weights: {sorted(missing)}"
            )
        # Validate vetoes are a subset of the 14 dimensions (D1–D14)
        invalid_vetoes = set(self.veto_dimensions) - set(DIMENSION_NAMES)
        if invalid_vetoes:
            raise ValueError(
                f"Preset '{self.name}' has invalid veto dimensions: {sorted(invalid_vetoes)}"
            )
        # Validate thresholds
        if self.allow_threshold <= self.deny_threshold:
            raise ValueError(
                f"Preset '{self.name}': allow_threshold ({self.allow_threshold}) "
                f"must be greater than deny_threshold ({self.deny_threshold})"
            )
        # Validate trust settings keys
        missing_keys = TRUST_SETTING_KEYS - set(self.trust_settings)
        if missing_keys:
            raise ValueError(
                f"Preset '{self.name}' missing trust settings: {sorted(missing_keys)}"
            )


# ---------------------------------------------------------------------------
# Compliance presets
# ---------------------------------------------------------------------------

SOC2_ALIGNED = GovernancePreset(
    name="soc2_aligned",
    display_name="SOC2-Aligned",
    description=(
        "Service Organization Control 2. Emphasizes incident detection, "
        "scope compliance, isolation integrity, and transparency. "
        "Security-focused controls."
    ),
    category="compliance",
    framework_reference="SOC2",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 1.8,
        "resource_boundaries": 1.5,
        "behavioral_consistency": 1.2,
        "cascading_impact": 1.3,
        "stakeholder_impact": 1.2,
        "incident_detection": 2.0,
        "isolation_integrity": 1.8,
        "temporal_compliance": 1.0,
        "precedent_alignment": 0.8,
        "transparency": 1.5,
        "human_override": 2.0,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 1.4,
    },
    veto_dimensions=[
        "scope_compliance",
        "incident_detection",
        "isolation_integrity",
        "authority_verification",
        "human_override",
    ],
    allow_threshold=0.75,
    deny_threshold=0.35,
    trust_settings={
        "violation_decrement": 0.06,
        "success_increment": 0.008,
        "interrupt_cost": 0.04,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.93,
    },
    metadata={
        "framework": "SOC2",
        "regulatory_body": "AICPA",
        "focus": "security",
    },
)

HIPAA_ALIGNED = GovernancePreset(
    name="hipaa_aligned",
    display_name="HIPAA-Aligned",
    description=(
        "Health Insurance Portability and Accountability Act. Emphasizes "
        "data isolation, stakeholder impact (patient safety), ethical "
        "alignment, and transparency. Privacy-focused."
    ),
    category="compliance",
    framework_reference="HIPAA",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 1.5,
        "resource_boundaries": 1.2,
        "behavioral_consistency": 1.0,
        "cascading_impact": 1.5,
        "stakeholder_impact": 2.0,
        "incident_detection": 1.5,
        "isolation_integrity": 2.0,
        "temporal_compliance": 1.0,
        "precedent_alignment": 0.8,
        "transparency": 1.5,
        "human_override": 2.0,
        "ethical_alignment": 2.0,
        "jurisdictional_compliance": 1.8,
    },
    veto_dimensions=[
        "isolation_integrity",
        "stakeholder_impact",
        "ethical_alignment",
        "scope_compliance",
        "human_override",
        "authority_verification",
    ],
    allow_threshold=0.80,
    deny_threshold=0.30,
    trust_settings={
        "violation_decrement": 0.08,
        "success_increment": 0.005,
        "interrupt_cost": 0.04,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.92,
    },
    metadata={
        "framework": "HIPAA",
        "regulatory_body": "HHS",
        "focus": "privacy",
    },
)

PCI_DSS_ALIGNED = GovernancePreset(
    name="pci_dss_aligned",
    display_name="PCI-DSS-Aligned",
    description=(
        "Payment Card Industry Data Security Standard. Emphasizes scope "
        "compliance, authority verification, resource boundaries, and "
        "cascading impact. Transaction-integrity-focused."
    ),
    category="compliance",
    framework_reference="PCI_DSS",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 2.0,
        "resource_boundaries": 1.8,
        "behavioral_consistency": 1.2,
        "cascading_impact": 1.8,
        "stakeholder_impact": 1.5,
        "incident_detection": 1.8,
        "isolation_integrity": 1.5,
        "temporal_compliance": 1.2,
        "precedent_alignment": 1.0,
        "transparency": 1.0,
        "human_override": 2.0,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 1.5,
    },
    veto_dimensions=[
        "scope_compliance",
        "authority_verification",
        "resource_boundaries",
        "incident_detection",
        "human_override",
    ],
    allow_threshold=0.80,
    deny_threshold=0.35,
    trust_settings={
        "violation_decrement": 0.08,
        "success_increment": 0.005,
        "interrupt_cost": 0.05,
        "decay_rate": 0.002,
        "floor": 0.05,
        "ceiling": 0.90,
    },
    metadata={
        "framework": "PCI_DSS",
        "regulatory_body": "PCI SSC",
        "focus": "transaction_integrity",
    },
)

ISO27001_ALIGNED = GovernancePreset(
    name="iso27001_aligned",
    display_name="ISO 27001-Aligned",
    description=(
        "Information Security Management System. Balanced across all "
        "dimensions with emphasis on behavioral consistency and precedent "
        "alignment. Process-focused."
    ),
    category="compliance",
    framework_reference="ISO27001",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 1.8,
        "authority_verification": 1.8,
        "resource_boundaries": 1.3,
        "behavioral_consistency": 1.5,
        "cascading_impact": 1.3,
        "stakeholder_impact": 1.3,
        "incident_detection": 1.5,
        "isolation_integrity": 1.5,
        "temporal_compliance": 1.3,
        "precedent_alignment": 1.5,
        "transparency": 1.3,
        "human_override": 1.8,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 1.4,
    },
    veto_dimensions=[
        "scope_compliance",
        "authority_verification",
        "isolation_integrity",
        "human_override",
    ],
    allow_threshold=0.70,
    deny_threshold=0.30,
    trust_settings={
        "violation_decrement": 0.05,
        "success_increment": 0.01,
        "interrupt_cost": 0.03,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.95,
    },
    metadata={
        "framework": "ISO27001",
        "regulatory_body": "ISO/IEC",
        "focus": "process",
    },
)

SOX_ALIGNED = GovernancePreset(
    name="sox_aligned",
    display_name="SOX-Aligned",
    description=(
        "Sarbanes-Oxley Act. Strict audit trail requirements, financial data "
        "modification vetoes, high allow threshold for financial reporting "
        "integrity."
    ),
    category="compliance",
    framework_reference="SOX",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 2.0,
        "resource_boundaries": 1.8,
        "behavioral_consistency": 1.5,
        "cascading_impact": 1.8,
        "stakeholder_impact": 1.5,
        "incident_detection": 1.8,
        "isolation_integrity": 1.5,
        "temporal_compliance": 2.0,
        "precedent_alignment": 1.5,
        "transparency": 2.0,
        "human_override": 2.0,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 1.5,
    },
    veto_dimensions=[
        "scope_compliance",
        "authority_verification",
        "transparency",
        "temporal_compliance",
        "human_override",
    ],
    allow_threshold=0.80,
    deny_threshold=0.35,
    trust_settings={
        "violation_decrement": 0.08,
        "success_increment": 0.005,
        "interrupt_cost": 0.04,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.92,
    },
    metadata={
        "framework": "SOX",
        "regulatory_body": "SEC",
        "focus": "audit_trail",
    },
)

GLBA_ALIGNED = GovernancePreset(
    name="glba_aligned",
    display_name="GLBA-Aligned",
    description=(
        "Gramm-Leach-Bliley Act. Protects customer financial data with "
        "emphasis on data sharing boundaries, isolation integrity, and "
        "stakeholder impact."
    ),
    category="compliance",
    framework_reference="GLBA",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 1.8,
        "authority_verification": 1.8,
        "resource_boundaries": 2.0,
        "behavioral_consistency": 1.2,
        "cascading_impact": 1.5,
        "stakeholder_impact": 2.0,
        "incident_detection": 1.5,
        "isolation_integrity": 2.0,
        "temporal_compliance": 1.0,
        "precedent_alignment": 1.0,
        "transparency": 1.5,
        "human_override": 1.8,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 1.5,
    },
    veto_dimensions=[
        "resource_boundaries",
        "isolation_integrity",
        "stakeholder_impact",
        "human_override",
    ],
    allow_threshold=0.75,
    deny_threshold=0.35,
    trust_settings={
        "violation_decrement": 0.07,
        "success_increment": 0.006,
        "interrupt_cost": 0.04,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.93,
    },
    metadata={
        "framework": "GLBA",
        "regulatory_body": "FTC",
        "focus": "financial_privacy",
    },
)

FEDRAMP_ALIGNED = GovernancePreset(
    name="fedramp_aligned",
    display_name="FedRAMP-Aligned",
    description=(
        "Federal Risk and Authorization Management Program. Highest allow "
        "thresholds for federal cloud security with continuous monitoring "
        "weights and strict isolation."
    ),
    category="compliance",
    framework_reference="FedRAMP",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 2.0,
        "resource_boundaries": 2.0,
        "behavioral_consistency": 1.5,
        "cascading_impact": 1.8,
        "stakeholder_impact": 1.5,
        "incident_detection": 2.0,
        "isolation_integrity": 2.0,
        "temporal_compliance": 1.5,
        "precedent_alignment": 1.2,
        "transparency": 1.8,
        "human_override": 2.0,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 2.0,
    },
    veto_dimensions=[
        "scope_compliance",
        "authority_verification",
        "incident_detection",
        "isolation_integrity",
        "human_override",
        "jurisdictional_compliance",
    ],
    allow_threshold=0.85,
    deny_threshold=0.40,
    trust_settings={
        "violation_decrement": 0.09,
        "success_increment": 0.004,
        "interrupt_cost": 0.05,
        "decay_rate": 0.002,
        "floor": 0.05,
        "ceiling": 0.90,
    },
    metadata={
        "framework": "FedRAMP",
        "regulatory_body": "GSA/FedRAMP_PMO",
        "focus": "federal_cloud_security",
    },
)

NIST_800_171_ALIGNED = GovernancePreset(
    name="nist_800_171_aligned",
    display_name="NIST 800-171-Aligned",
    description=(
        "NIST Special Publication 800-171. Controlled Unclassified "
        "Information (CUI) protection with 14 control families mapped to "
        "dimension weights."
    ),
    category="compliance",
    framework_reference="NIST_800_171",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 2.0,
        "resource_boundaries": 1.8,
        "behavioral_consistency": 1.5,
        "cascading_impact": 1.5,
        "stakeholder_impact": 1.5,
        "incident_detection": 2.0,
        "isolation_integrity": 2.0,
        "temporal_compliance": 1.5,
        "precedent_alignment": 1.5,
        "transparency": 1.8,
        "human_override": 2.0,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 1.8,
    },
    veto_dimensions=[
        "scope_compliance",
        "authority_verification",
        "incident_detection",
        "isolation_integrity",
        "human_override",
    ],
    allow_threshold=0.80,
    deny_threshold=0.35,
    trust_settings={
        "violation_decrement": 0.08,
        "success_increment": 0.005,
        "interrupt_cost": 0.04,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.91,
    },
    metadata={
        "framework": "NIST_800_171",
        "regulatory_body": "NIST",
        "focus": "cui_protection",
    },
)

CMMC_L1_ALIGNED = GovernancePreset(
    name="cmmc_l1_aligned",
    display_name="CMMC Level 1-Aligned",
    description=(
        "Cybersecurity Maturity Model Certification Level 1 (Foundational). "
        "DoD supply chain basic cyber hygiene."
    ),
    category="compliance",
    framework_reference="CMMC_L1",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 1.5,
        "authority_verification": 1.5,
        "resource_boundaries": 1.3,
        "behavioral_consistency": 1.2,
        "cascading_impact": 1.2,
        "stakeholder_impact": 1.0,
        "incident_detection": 1.5,
        "isolation_integrity": 1.5,
        "temporal_compliance": 1.0,
        "precedent_alignment": 1.0,
        "transparency": 1.2,
        "human_override": 1.5,
        "ethical_alignment": 1.0,
        "jurisdictional_compliance": 1.2,
    },
    veto_dimensions=[
        "scope_compliance",
        "authority_verification",
        "human_override",
    ],
    allow_threshold=0.70,
    deny_threshold=0.30,
    trust_settings={
        "violation_decrement": 0.06,
        "success_increment": 0.008,
        "interrupt_cost": 0.03,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.95,
    },
    metadata={
        "framework": "CMMC_L1",
        "regulatory_body": "DoD",
        "focus": "basic_cyber_hygiene",
        "tier": "cmmc_level_1",
    },
)

CMMC_L2_ALIGNED = GovernancePreset(
    name="cmmc_l2_aligned",
    display_name="CMMC Level 2-Aligned",
    description=(
        "Cybersecurity Maturity Model Certification Level 2 (Advanced). "
        "DoD supply chain CUI protection aligned with NIST 800-171."
    ),
    category="compliance",
    framework_reference="CMMC_L2",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 1.8,
        "authority_verification": 1.8,
        "resource_boundaries": 1.5,
        "behavioral_consistency": 1.5,
        "cascading_impact": 1.5,
        "stakeholder_impact": 1.2,
        "incident_detection": 1.8,
        "isolation_integrity": 1.8,
        "temporal_compliance": 1.2,
        "precedent_alignment": 1.2,
        "transparency": 1.5,
        "human_override": 1.8,
        "ethical_alignment": 1.2,
        "jurisdictional_compliance": 1.5,
    },
    veto_dimensions=[
        "scope_compliance",
        "authority_verification",
        "incident_detection",
        "isolation_integrity",
        "human_override",
    ],
    allow_threshold=0.78,
    deny_threshold=0.35,
    trust_settings={
        "violation_decrement": 0.07,
        "success_increment": 0.006,
        "interrupt_cost": 0.04,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.92,
    },
    metadata={
        "framework": "CMMC_L2",
        "regulatory_body": "DoD",
        "focus": "cui_protection",
        "tier": "cmmc_level_2",
    },
)

CMMC_L3_ALIGNED = GovernancePreset(
    name="cmmc_l3_aligned",
    display_name="CMMC Level 3-Aligned",
    description=(
        "Cybersecurity Maturity Model Certification Level 3 (Expert). "
        "DoD supply chain advanced persistent threat protection."
    ),
    category="compliance",
    framework_reference="CMMC_L3",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 2.0,
        "resource_boundaries": 2.0,
        "behavioral_consistency": 1.8,
        "cascading_impact": 1.8,
        "stakeholder_impact": 1.5,
        "incident_detection": 2.0,
        "isolation_integrity": 2.0,
        "temporal_compliance": 1.5,
        "precedent_alignment": 1.5,
        "transparency": 1.8,
        "human_override": 2.0,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 1.8,
    },
    veto_dimensions=[
        "scope_compliance",
        "authority_verification",
        "incident_detection",
        "isolation_integrity",
        "human_override",
        "ethical_alignment",
    ],
    allow_threshold=0.85,
    deny_threshold=0.38,
    trust_settings={
        "violation_decrement": 0.09,
        "success_increment": 0.004,
        "interrupt_cost": 0.05,
        "decay_rate": 0.002,
        "floor": 0.05,
        "ceiling": 0.89,
    },
    metadata={
        "framework": "CMMC_L3",
        "regulatory_body": "DoD",
        "focus": "apt_protection",
        "tier": "cmmc_level_3",
    },
)

NERC_CIP_ALIGNED = GovernancePreset(
    name="nerc_cip_aligned",
    display_name="NERC CIP-Aligned",
    description=(
        "North American Electric Reliability Corporation Critical "
        "Infrastructure Protection. Physical/logical access controls for "
        "bulk electric system reliability."
    ),
    category="compliance",
    framework_reference="NERC_CIP",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 2.0,
        "resource_boundaries": 2.0,
        "behavioral_consistency": 1.5,
        "cascading_impact": 2.0,
        "stakeholder_impact": 1.8,
        "incident_detection": 2.0,
        "isolation_integrity": 2.0,
        "temporal_compliance": 1.5,
        "precedent_alignment": 1.2,
        "transparency": 1.5,
        "human_override": 2.0,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 1.8,
    },
    veto_dimensions=[
        "scope_compliance",
        "authority_verification",
        "cascading_impact",
        "isolation_integrity",
        "incident_detection",
        "human_override",
    ],
    allow_threshold=0.82,
    deny_threshold=0.38,
    trust_settings={
        "violation_decrement": 0.09,
        "success_increment": 0.004,
        "interrupt_cost": 0.05,
        "decay_rate": 0.002,
        "floor": 0.05,
        "ceiling": 0.90,
    },
    metadata={
        "framework": "NERC_CIP",
        "regulatory_body": "NERC",
        "focus": "critical_infrastructure",
    },
)

NIS2_ALIGNED = GovernancePreset(
    name="nis2_aligned",
    display_name="NIS2-Aligned",
    description=(
        "EU Network and Information Security Directive 2. Operational "
        "resilience with incident reporting weights and supply chain "
        "risk management."
    ),
    category="compliance",
    framework_reference="NIS2",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 1.8,
        "authority_verification": 1.8,
        "resource_boundaries": 1.8,
        "behavioral_consistency": 1.5,
        "cascading_impact": 2.0,
        "stakeholder_impact": 1.8,
        "incident_detection": 2.0,
        "isolation_integrity": 1.8,
        "temporal_compliance": 1.5,
        "precedent_alignment": 1.2,
        "transparency": 1.8,
        "human_override": 1.8,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 2.0,
    },
    veto_dimensions=[
        "incident_detection",
        "cascading_impact",
        "isolation_integrity",
        "human_override",
        "jurisdictional_compliance",
    ],
    allow_threshold=0.78,
    deny_threshold=0.35,
    trust_settings={
        "violation_decrement": 0.07,
        "success_increment": 0.006,
        "interrupt_cost": 0.04,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.92,
    },
    metadata={
        "framework": "NIS2",
        "regulatory_body": "EU",
        "focus": "operational_resilience",
    },
)

GDPR_ALIGNED = GovernancePreset(
    name="gdpr_aligned",
    display_name="GDPR-Aligned",
    description=(
        "EU General Data Protection Regulation. Strong PII veto, data "
        "minimization weights, data subject rights, and jurisdictional "
        "compliance emphasis."
    ),
    category="compliance",
    framework_reference="GDPR",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 1.8,
        "resource_boundaries": 2.0,
        "behavioral_consistency": 1.2,
        "cascading_impact": 1.5,
        "stakeholder_impact": 2.0,
        "incident_detection": 1.5,
        "isolation_integrity": 2.0,
        "temporal_compliance": 1.2,
        "precedent_alignment": 1.0,
        "transparency": 2.0,
        "human_override": 2.0,
        "ethical_alignment": 2.0,
        "jurisdictional_compliance": 2.0,
    },
    veto_dimensions=[
        "scope_compliance",
        "isolation_integrity",
        "stakeholder_impact",
        "ethical_alignment",
        "human_override",
        "jurisdictional_compliance",
    ],
    allow_threshold=0.80,
    deny_threshold=0.35,
    trust_settings={
        "violation_decrement": 0.08,
        "success_increment": 0.005,
        "interrupt_cost": 0.04,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.91,
    },
    metadata={
        "framework": "GDPR",
        "regulatory_body": "EU_DPAs",
        "focus": "data_privacy",
    },
)

CCPA_ALIGNED = GovernancePreset(
    name="ccpa_aligned",
    display_name="CCPA-Aligned",
    description=(
        "California Consumer Privacy Act. Consumer opt-out weights, "
        "disclosure dimension tuning, and data sharing boundaries."
    ),
    category="compliance",
    framework_reference="CCPA",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 1.8,
        "authority_verification": 1.5,
        "resource_boundaries": 1.8,
        "behavioral_consistency": 1.2,
        "cascading_impact": 1.3,
        "stakeholder_impact": 2.0,
        "incident_detection": 1.5,
        "isolation_integrity": 1.8,
        "temporal_compliance": 1.0,
        "precedent_alignment": 1.0,
        "transparency": 2.0,
        "human_override": 2.0,
        "ethical_alignment": 1.8,
        "jurisdictional_compliance": 1.8,
    },
    veto_dimensions=[
        "scope_compliance",
        "stakeholder_impact",
        "transparency",
        "human_override",
        "jurisdictional_compliance",
    ],
    allow_threshold=0.75,
    deny_threshold=0.33,
    trust_settings={
        "violation_decrement": 0.07,
        "success_increment": 0.006,
        "interrupt_cost": 0.04,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.93,
    },
    metadata={
        "framework": "CCPA",
        "regulatory_body": "California_AG",
        "focus": "consumer_privacy",
    },
)

FERPA_ALIGNED = GovernancePreset(
    name="ferpa_aligned",
    display_name="FERPA-Aligned",
    description=(
        "Family Educational Rights and Privacy Act. Strict educational "
        "purpose scope, student record isolation, and parental consent "
        "requirements."
    ),
    category="compliance",
    framework_reference="FERPA",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 1.8,
        "resource_boundaries": 1.5,
        "behavioral_consistency": 1.2,
        "cascading_impact": 1.3,
        "stakeholder_impact": 2.0,
        "incident_detection": 1.5,
        "isolation_integrity": 2.0,
        "temporal_compliance": 1.0,
        "precedent_alignment": 1.0,
        "transparency": 1.5,
        "human_override": 2.0,
        "ethical_alignment": 1.8,
        "jurisdictional_compliance": 1.5,
    },
    veto_dimensions=[
        "scope_compliance",
        "isolation_integrity",
        "stakeholder_impact",
        "human_override",
        "ethical_alignment",
    ],
    allow_threshold=0.78,
    deny_threshold=0.33,
    trust_settings={
        "violation_decrement": 0.07,
        "success_increment": 0.006,
        "interrupt_cost": 0.04,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.93,
    },
    metadata={
        "framework": "FERPA",
        "regulatory_body": "ED",
        "focus": "student_privacy",
    },
)

GXP_ALIGNED = GovernancePreset(
    name="gxp_aligned",
    display_name="GxP-Aligned",
    description=(
        "Good Practice regulations (GMP, GLP, GCP). Pharmaceutical and "
        "life sciences with immutable audit trail, validation requirements, "
        "and data integrity emphasis."
    ),
    category="compliance",
    framework_reference="GxP",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 2.0,
        "resource_boundaries": 1.8,
        "behavioral_consistency": 2.0,
        "cascading_impact": 1.8,
        "stakeholder_impact": 2.0,
        "incident_detection": 1.8,
        "isolation_integrity": 1.8,
        "temporal_compliance": 2.0,
        "precedent_alignment": 1.8,
        "transparency": 2.0,
        "human_override": 2.0,
        "ethical_alignment": 2.0,
        "jurisdictional_compliance": 1.5,
    },
    veto_dimensions=[
        "scope_compliance",
        "authority_verification",
        "behavioral_consistency",
        "transparency",
        "temporal_compliance",
        "human_override",
    ],
    allow_threshold=0.82,
    deny_threshold=0.38,
    trust_settings={
        "violation_decrement": 0.09,
        "success_increment": 0.004,
        "interrupt_cost": 0.05,
        "decay_rate": 0.002,
        "floor": 0.05,
        "ceiling": 0.90,
    },
    metadata={
        "framework": "GxP",
        "regulatory_body": "FDA/EMA",
        "focus": "data_integrity",
    },
)

ITAR_ALIGNED = GovernancePreset(
    name="itar_aligned",
    display_name="ITAR-Aligned",
    description=(
        "International Traffic in Arms Regulations. Strictest isolation "
        "for export-controlled data, cross-border veto, and jurisdictional "
        "compliance emphasis."
    ),
    category="compliance",
    framework_reference="ITAR",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 2.0,
        "resource_boundaries": 2.0,
        "behavioral_consistency": 1.8,
        "cascading_impact": 2.0,
        "stakeholder_impact": 1.5,
        "incident_detection": 2.0,
        "isolation_integrity": 2.0,
        "temporal_compliance": 1.5,
        "precedent_alignment": 1.5,
        "transparency": 1.5,
        "human_override": 2.0,
        "ethical_alignment": 1.8,
        "jurisdictional_compliance": 2.0,
    },
    veto_dimensions=[
        "scope_compliance",
        "authority_verification",
        "isolation_integrity",
        "cascading_impact",
        "human_override",
        "jurisdictional_compliance",
    ],
    allow_threshold=0.88,
    deny_threshold=0.40,
    trust_settings={
        "violation_decrement": 0.10,
        "success_increment": 0.003,
        "interrupt_cost": 0.05,
        "decay_rate": 0.002,
        "floor": 0.05,
        "ceiling": 0.88,
    },
    metadata={
        "framework": "ITAR",
        "regulatory_body": "DDTC",
        "focus": "export_control",
    },
)

DORA_ALIGNED = GovernancePreset(
    name="dora_aligned",
    display_name="DORA-Aligned",
    description=(
        "EU Digital Operational Resilience Act. ICT risk management, "
        "third-party service provider weights, incident reporting, and "
        "operational resilience testing."
    ),
    category="compliance",
    framework_reference="DORA",
    certified=False,
    disclaimer=PRESET_DISCLAIMER,
    dimension_weights={
        "scope_compliance": 1.8,
        "authority_verification": 1.8,
        "resource_boundaries": 2.0,
        "behavioral_consistency": 1.5,
        "cascading_impact": 2.0,
        "stakeholder_impact": 1.8,
        "incident_detection": 2.0,
        "isolation_integrity": 1.8,
        "temporal_compliance": 1.5,
        "precedent_alignment": 1.2,
        "transparency": 1.8,
        "human_override": 1.8,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 2.0,
    },
    veto_dimensions=[
        "incident_detection",
        "cascading_impact",
        "resource_boundaries",
        "isolation_integrity",
        "human_override",
        "jurisdictional_compliance",
    ],
    allow_threshold=0.80,
    deny_threshold=0.35,
    trust_settings={
        "violation_decrement": 0.08,
        "success_increment": 0.005,
        "interrupt_cost": 0.04,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.91,
    },
    metadata={
        "framework": "DORA",
        "regulatory_body": "EU",
        "focus": "digital_resilience",
    },
)


# ---------------------------------------------------------------------------
# Severity tier presets
# ---------------------------------------------------------------------------

STANDARD = GovernancePreset(
    name="standard",
    display_name="Standard",
    description="Reasonable defaults for general use.",
    category="severity",
    framework_reference="",
    certified=False,
    disclaimer="",
    dimension_weights={
        "scope_compliance": 1.0,
        "authority_verification": 1.0,
        "resource_boundaries": 1.0,
        "behavioral_consistency": 1.0,
        "cascading_impact": 1.0,
        "stakeholder_impact": 1.0,
        "incident_detection": 1.0,
        "isolation_integrity": 1.0,
        "temporal_compliance": 1.0,
        "precedent_alignment": 1.0,
        "transparency": 1.0,
        "human_override": 1.5,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 1.0,
    },
    veto_dimensions=[
        "scope_compliance",
        "human_override",
    ],
    allow_threshold=0.70,
    deny_threshold=0.30,
    trust_settings={
        "violation_decrement": 0.05,
        "success_increment": 0.01,
        "interrupt_cost": 0.03,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.95,
    },
    metadata={
        "tier": "standard",
        "focus": "general",
    },
)

STRICT = GovernancePreset(
    name="strict",
    display_name="Strict",
    description="Elevated security posture.",
    category="severity",
    framework_reference="",
    certified=False,
    disclaimer="",
    dimension_weights={
        "scope_compliance": 1.8,
        "authority_verification": 1.8,
        "resource_boundaries": 1.5,
        "behavioral_consistency": 1.2,
        "cascading_impact": 1.5,
        "stakeholder_impact": 1.2,
        "incident_detection": 1.8,
        "isolation_integrity": 1.8,
        "temporal_compliance": 1.2,
        "precedent_alignment": 1.2,
        "transparency": 1.2,
        "human_override": 1.8,
        "ethical_alignment": 1.5,
        "jurisdictional_compliance": 1.5,
    },
    veto_dimensions=[
        "scope_compliance",
        "authority_verification",
        "incident_detection",
        "isolation_integrity",
        "human_override",
        "ethical_alignment",
    ],
    allow_threshold=0.80,
    deny_threshold=0.35,
    trust_settings={
        "violation_decrement": 0.07,
        "success_increment": 0.006,
        "interrupt_cost": 0.04,
        "decay_rate": 0.001,
        "floor": 0.05,
        "ceiling": 0.92,
    },
    metadata={
        "tier": "strict",
        "focus": "security",
    },
)

ULTRA_STRICT = GovernancePreset(
    name="ultra_strict",
    display_name="Ultra-Strict",
    description="Maximum governance.",
    category="severity",
    framework_reference="",
    certified=False,
    disclaimer="",
    dimension_weights={
        "scope_compliance": 2.0,
        "authority_verification": 2.0,
        "resource_boundaries": 2.0,
        "behavioral_consistency": 1.5,
        "cascading_impact": 2.0,
        "stakeholder_impact": 2.0,
        "incident_detection": 2.0,
        "isolation_integrity": 2.0,
        "temporal_compliance": 1.5,
        "precedent_alignment": 1.5,
        "transparency": 1.5,
        "human_override": 2.0,
        "ethical_alignment": 2.0,
        "jurisdictional_compliance": 2.0,
    },
    veto_dimensions=list(DIMENSION_NAMES),  # ALL 14 dimensions (D1–D14)
    allow_threshold=0.90,
    deny_threshold=0.40,
    trust_settings={
        "violation_decrement": 0.10,
        "success_increment": 0.003,
        "interrupt_cost": 0.05,
        "decay_rate": 0.002,
        "floor": 0.05,
        "ceiling": 0.88,
    },
    metadata={
        "tier": "ultra_strict",
        "focus": "maximum_governance",
    },
)


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_PRESETS: dict[str, GovernancePreset] = {
    p.name.lower(): p
    for p in [
        SOC2_ALIGNED, HIPAA_ALIGNED, PCI_DSS_ALIGNED, ISO27001_ALIGNED,
        SOX_ALIGNED, GLBA_ALIGNED, FEDRAMP_ALIGNED, NIST_800_171_ALIGNED,
        CMMC_L1_ALIGNED, CMMC_L2_ALIGNED, CMMC_L3_ALIGNED,
        NERC_CIP_ALIGNED, NIS2_ALIGNED, GDPR_ALIGNED, CCPA_ALIGNED,
        FERPA_ALIGNED, GXP_ALIGNED, ITAR_ALIGNED, DORA_ALIGNED,
        STANDARD, STRICT, ULTRA_STRICT,
    ]
}

def get_preset(name: str) -> GovernancePreset:
    """Get a preset by name (case-insensitive).

    Only canonical preset names are accepted (e.g. ``"hipaa_aligned"``,
    ``"soc2_aligned"``).  Raises ``KeyError`` if the preset is not found.
    """
    key = name.lower()
    try:
        return _PRESETS[key]
    except KeyError:
        available = ", ".join(sorted(_PRESETS))
        raise KeyError(
            f"Unknown preset '{name}'. Available presets: {available}"
        ) from None


def list_presets() -> list[GovernancePreset]:
    """Return all available presets."""
    return list(_PRESETS.values())


def list_compliance_presets() -> list[GovernancePreset]:
    """Return only compliance framework presets."""
    return [p for p in _PRESETS.values() if p.category == "compliance"]


def list_severity_presets() -> list[GovernancePreset]:
    """Return only severity tier presets."""
    return [p for p in _PRESETS.values() if p.category == "severity"]


def get_preset_names() -> list[str]:
    """Return all preset names."""
    return [p.name for p in _PRESETS.values()]


# ---------------------------------------------------------------------------
# Industry-to-preset recommendations
# ---------------------------------------------------------------------------

INDUSTRY_PRESET_RECOMMENDATIONS: dict[str, list[str]] = {
    "banking_finance": ["pci_dss_aligned", "sox_aligned", "glba_aligned", "soc2_aligned"],
    "healthcare": ["hipaa_aligned", "soc2_aligned", "gxp_aligned"],
    "government_us": ["fedramp_aligned", "nist_800_171_aligned", "cmmc_l2_aligned"],
    "defense_aerospace": ["cmmc_l3_aligned", "itar_aligned", "nist_800_171_aligned"],
    "energy_utilities": ["nerc_cip_aligned", "soc2_aligned"],
    "retail": ["pci_dss_aligned", "ccpa_aligned", "gdpr_aligned"],
    "education": ["ferpa_aligned", "soc2_aligned"],
    "pharmaceutical": ["gxp_aligned", "hipaa_aligned", "soc2_aligned"],
    "insurance": ["sox_aligned", "glba_aligned", "soc2_aligned"],
    "telecommunications": ["nis2_aligned", "soc2_aligned", "iso27001_aligned"],
    "eu_financial_services": ["dora_aligned", "gdpr_aligned", "nis2_aligned"],
    "eu_general": ["gdpr_aligned", "nis2_aligned"],
    "technology": ["soc2_aligned", "iso27001_aligned", "ccpa_aligned"],
    "manufacturing": ["iso27001_aligned", "cmmc_l1_aligned", "soc2_aligned"],
}


def merge_presets(*presets: GovernancePreset) -> GovernancePreset:
    """Merge multiple presets into one.

    Merge semantics:

    - **Weights**: maximum value from any preset for each dimension.
    - **Vetoes**: union (combined) across all presets.
    - **Thresholds**: strictest values — highest ``allow_threshold``,
      highest ``deny_threshold``.
    - **Trust settings**: most conservative — highest
      ``violation_decrement``, lowest ``success_increment``, highest
      ``interrupt_cost``, highest ``decay_rate``, highest ``floor``,
      lowest ``ceiling``.
    - **Name**: joined with ``+``.
    - **Category**: ``"merged"``.
    - **Metadata**: later presets override earlier ones.

    Example::

        merged = merge_presets(get_preset("strict"), get_preset("hipaa_aligned"))
    """
    if not presets:
        raise ValueError("merge_presets requires at least one preset")

    if len(presets) == 1:
        return presets[0]

    # Weights: max across all presets
    merged_weights: dict[str, float] = {}
    for dim in DIMENSION_NAMES:
        merged_weights[dim] = max(p.dimension_weights[dim] for p in presets)

    # Vetoes: union
    merged_vetoes: list[str] = sorted(
        set().union(*(p.veto_dimensions for p in presets))
    )

    # Thresholds: strictest
    merged_allow = max(p.allow_threshold for p in presets)
    merged_deny = max(p.deny_threshold for p in presets)

    # Trust settings: most conservative
    merged_trust: dict[str, float] = {
        "violation_decrement": max(p.trust_settings["violation_decrement"] for p in presets),
        "success_increment": min(p.trust_settings["success_increment"] for p in presets),
        "interrupt_cost": max(p.trust_settings["interrupt_cost"] for p in presets),
        "decay_rate": max(p.trust_settings["decay_rate"] for p in presets),
        "floor": max(p.trust_settings["floor"] for p in presets),
        "ceiling": min(p.trust_settings["ceiling"] for p in presets),
    }

    # Name: joined
    merged_name = "+".join(p.name for p in presets)

    # Display name: joined
    merged_display = " + ".join(p.display_name for p in presets)

    # Description: combined
    merged_desc = " | ".join(p.description for p in presets)

    # Framework reference: combined non-empty references
    refs = [p.framework_reference for p in presets if p.framework_reference]
    merged_ref = "+".join(refs) if refs else ""

    # Disclaimer: use PRESET_DISCLAIMER if any compliance preset is included
    merged_disclaimer = PRESET_DISCLAIMER if any(p.disclaimer for p in presets) else ""

    # Metadata: later overrides earlier
    merged_metadata: dict[str, str] = {}
    for p in presets:
        merged_metadata.update(p.metadata)

    return GovernancePreset(
        name=merged_name,
        display_name=merged_display,
        description=merged_desc,
        category="merged",
        framework_reference=merged_ref,
        certified=False,
        disclaimer=merged_disclaimer,
        dimension_weights=merged_weights,
        veto_dimensions=merged_vetoes,
        allow_threshold=merged_allow,
        deny_threshold=merged_deny,
        trust_settings=merged_trust,
        metadata=merged_metadata,
    )
