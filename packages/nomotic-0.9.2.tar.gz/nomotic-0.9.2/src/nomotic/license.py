"""License configuration for the Nomotic governance runtime.

The open source SDK does not validate license keys. It reads a key from
config or the filesystem and makes it available to installed plugins.
License validation and tier resolution are the responsibility of the
nomotic-pro plugin (or any compatible plugin registered via entry points).

If no plugin performs validation, the runtime defaults to ActivatedTier.OPEN.
This is not an error — the free tier (D1-D14) is fully functional without
any license key.

License keys are purchased and managed at nomotic.ai.
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nomotic.llm import LLMConfig

__all__ = [
    "ActivatedTier",
    "LicenseConfig",
    "LicenseGate",
    "LicenseInfo",
]

logger = logging.getLogger("nomotic.license")

DEFAULT_LICENSE_FILE = Path.home() / ".nomotic" / "license.key"


class ActivatedTier(Enum):
    """The governance tier activated by the current license configuration."""

    OPEN = "open"  # D1-D14, free, no license required
    PRO = "pro"  # D1-D20 (requires nomotic-pro plugin)
    ENTERPRISE = "enterprise"  # D1-D20 + behavioral engine


@dataclass
class LicenseConfig:
    """License configuration for the governance runtime.

    Pass to RuntimeConfig.license_config to activate Pro or Enterprise
    features. The SDK reads the key and makes it available to installed
    plugins; it does not validate the key itself.

    If key is None and no license file exists, the runtime operates in
    free tier (OPEN) with D1-D14 dimensions.
    """

    key: str | None = None  # JWT license key string
    key_file: Path | None = None  # path to license key file; defaults to ~/.nomotic/license.key
    server_url: str | None = None  # Nomotic Cloud URL for revocation checks (optional)
    llm_config: LLMConfig | None = None  # LLM endpoint for D16, D19, D20 when using nomotic-pro


@dataclass
class LicenseInfo:
    """Resolved license information after validation by a plugin."""

    tier: ActivatedTier = ActivatedTier.OPEN
    org_id: str | None = None
    expires_at: float | None = None
    features: list[str] = field(default_factory=list)
    deployment: str = "local"
    validation_error: str | None = None  # set if key present but invalid


class LicenseGate:
    """Reads a license key and delegates validation to installed plugins.

    The SDK itself performs no cryptographic validation. It:
    1. Reads the key from config, key file, or environment variable
    2. Discovers any installed license validators via entry points
    3. Passes the key to the first available validator
    4. Returns OPEN tier if no validator is installed or key is absent

    Plugin validators register via the 'nomotic.license' entry point group::

        [project.entry_points."nomotic.license"]
        validator = "nomotic_pro.license:ProLicenseValidator"
    """

    ENTRY_POINT_GROUP = "nomotic.license"
    ENV_VAR = "NOMOTIC_LICENSE_KEY"

    def __init__(self, config: LicenseConfig | None = None):
        self._config = config or LicenseConfig()
        self._resolved: LicenseInfo | None = None

    def resolve(self) -> LicenseInfo:
        """Resolve the activated tier. Cached after first call."""
        if self._resolved is not None:
            return self._resolved

        key = self._read_key()

        if key is None:
            logger.debug("No license key found. Running in free tier (D1-D14).")
            self._resolved = LicenseInfo(tier=ActivatedTier.OPEN)
            return self._resolved

        # Delegate validation to installed plugin
        validator = self._discover_validator()
        if validator is None:
            logger.info(
                "License key present but no license validator is installed. "
                "Running in free tier. Install nomotic-pro to activate Pro features."
            )
            self._resolved = LicenseInfo(
                tier=ActivatedTier.OPEN,
                validation_error="No license validator installed. Install nomotic-pro.",
            )
            return self._resolved

        try:
            self._resolved = validator.validate(key, self._config)
        except Exception as e:
            logger.warning("License validation failed: %s. Running in free tier.", e)
            self._resolved = LicenseInfo(
                tier=ActivatedTier.OPEN,
                validation_error=str(e),
            )

        return self._resolved  # type: ignore[return-value]

    def _read_key(self) -> str | None:
        """Read key from config, env var, or key file. In that priority order."""
        # 1. Explicit key in config
        if self._config.key:
            return self._config.key.strip()

        # 2. Environment variable
        env_key = os.environ.get(self.ENV_VAR)
        if env_key:
            return env_key.strip()

        # 3. Key file (explicit path, then default)
        key_file = self._config.key_file or DEFAULT_LICENSE_FILE
        if key_file.exists():
            try:
                return key_file.read_text().strip()
            except OSError:
                pass

        return None

    def _discover_validator(self) -> Any | None:
        """Discover an installed license validator via entry points."""
        try:
            import importlib.metadata

            eps = importlib.metadata.entry_points(group=self.ENTRY_POINT_GROUP)
            for ep in eps:
                try:
                    validator_class = ep.load()
                    return validator_class()
                except Exception as e:
                    logger.debug("Failed to load license validator '%s': %s", ep.name, e)
        except Exception:
            pass
        return None

    @property
    def tier(self) -> ActivatedTier:
        """The activated tier. Resolves on first access."""
        return self.resolve().tier

    def is_pro_or_above(self) -> bool:
        """Return ``True`` if the activated tier is PRO or ENTERPRISE."""
        return self.tier in (ActivatedTier.PRO, ActivatedTier.ENTERPRISE)

    def is_enterprise(self) -> bool:
        """Return ``True`` if the activated tier is ENTERPRISE."""
        return self.tier == ActivatedTier.ENTERPRISE

    def warn_if_expired_soon(self, warning_days: int = 14) -> str | None:
        """Return a warning string if the license expires within *warning_days*.

        Returns ``None`` otherwise.
        """
        info = self.resolve()
        if info.expires_at and (info.expires_at - time.time()) < (warning_days * 86400):
            days_left = int((info.expires_at - time.time()) / 86400)
            return (
                f"Nomotic license expires in {days_left} days. "
                "Renew at nomotic.ai/license."
            )
        return None
