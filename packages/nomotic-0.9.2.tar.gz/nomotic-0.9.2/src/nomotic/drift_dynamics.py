"""Drift dynamics model — predicting how drift evolves over time.

Simple parametric models that capture drift behavior under different
conditions: natural continuation, post-intervention decay, and
self-correction. Parameters are pre-seeded per archetype and refined
as observed episodes accumulate.

Model maturity levels:
- <50 episodes: parametric defaults only
- 50-200 episodes: blend observed transitions with defaults
- 200+ episodes: observed data dominates
"""

from __future__ import annotations

import math
import threading
from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "ArchetypeDynamics",
    "DriftDynamicsModel",
    "DriftTransitionParams",
    "InterventionEffect",
]


@dataclass
class DriftTransitionParams:
    """Parameters for one drift transition scenario."""

    continuation_rate: float = 1.0
    """Linear drift multiplier without intervention (1.0 = constant velocity)."""

    acceleration_factor: float = 0.0
    """>0 means drift accelerates, <0 decelerates naturally."""

    self_correction_probability: float = 0.0
    """Probability drift reverses on its own at each step."""

    self_correction_magnitude: float = 0.3
    """How much drift drops on self-correction (fractional)."""

    def to_dict(self) -> dict[str, Any]:
        return {
            "continuation_rate": self.continuation_rate,
            "acceleration_factor": self.acceleration_factor,
            "self_correction_probability": self.self_correction_probability,
            "self_correction_magnitude": self.self_correction_magnitude,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DriftTransitionParams:
        return cls(
            continuation_rate=data.get("continuation_rate", 1.0),
            acceleration_factor=data.get("acceleration_factor", 0.0),
            self_correction_probability=data.get("self_correction_probability", 0.0),
            self_correction_magnitude=data.get("self_correction_magnitude", 0.3),
        )


@dataclass
class InterventionEffect:
    """How an intervention type affects drift."""

    intervention_type: str
    """One of: 'advisory', 'throttle', 'escalate', 'tighten'."""

    decay_half_life: float = 10.0
    """Actions until drift halves after intervention."""

    effectiveness: float = 0.7
    """Probability intervention reduces drift at all."""

    rebound_rate: float = 0.3
    """How fast drift returns after intervention wears off."""

    def to_dict(self) -> dict[str, Any]:
        return {
            "intervention_type": self.intervention_type,
            "decay_half_life": self.decay_half_life,
            "effectiveness": self.effectiveness,
            "rebound_rate": self.rebound_rate,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> InterventionEffect:
        return cls(
            intervention_type=data["intervention_type"],
            decay_half_life=data.get("decay_half_life", 10.0),
            effectiveness=data.get("effectiveness", 0.7),
            rebound_rate=data.get("rebound_rate", 0.3),
        )


@dataclass
class ArchetypeDynamics:
    """Complete dynamics model for one archetype."""

    archetype_name: str
    natural_transition: DriftTransitionParams = field(
        default_factory=DriftTransitionParams,
    )
    intervention_effects: dict[str, InterventionEffect] = field(default_factory=dict)
    causal_modifiers: dict[str, DriftTransitionParams] = field(default_factory=dict)
    """Keys: 'config_change', 'model_update', 'workload_shift',
    'semantic_reframing', 'organic'."""

    episodes_observed: int = 0
    """Model maturity counter."""

    def to_dict(self) -> dict[str, Any]:
        return {
            "archetype_name": self.archetype_name,
            "natural_transition": self.natural_transition.to_dict(),
            "intervention_effects": {
                k: v.to_dict() for k, v in self.intervention_effects.items()
            },
            "causal_modifiers": {
                k: v.to_dict() for k, v in self.causal_modifiers.items()
            },
            "episodes_observed": self.episodes_observed,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ArchetypeDynamics:
        return cls(
            archetype_name=data["archetype_name"],
            natural_transition=DriftTransitionParams.from_dict(
                data.get("natural_transition", {}),
            ),
            intervention_effects={
                k: InterventionEffect.from_dict(v)
                for k, v in data.get("intervention_effects", {}).items()
            },
            causal_modifiers={
                k: DriftTransitionParams.from_dict(v)
                for k, v in data.get("causal_modifiers", {}).items()
            },
            episodes_observed=data.get("episodes_observed", 0),
        )


# ── Default archetype dynamics ──────────────────────────────────────────

def _default_interventions(
    advisory_eff: float = 0.5,
    throttle_eff: float = 0.7,
    escalate_eff: float = 0.85,
    tighten_eff: float = 0.9,
    advisory_hl: float = 12.0,
    throttle_hl: float = 8.0,
    escalate_hl: float = 6.0,
    tighten_hl: float = 4.0,
    advisory_rb: float = 0.4,
    throttle_rb: float = 0.3,
    escalate_rb: float = 0.2,
    tighten_rb: float = 0.15,
) -> dict[str, InterventionEffect]:
    return {
        "advisory": InterventionEffect(
            "advisory", decay_half_life=advisory_hl,
            effectiveness=advisory_eff, rebound_rate=advisory_rb,
        ),
        "throttle": InterventionEffect(
            "throttle", decay_half_life=throttle_hl,
            effectiveness=throttle_eff, rebound_rate=throttle_rb,
        ),
        "escalate": InterventionEffect(
            "escalate", decay_half_life=escalate_hl,
            effectiveness=escalate_eff, rebound_rate=escalate_rb,
        ),
        "tighten": InterventionEffect(
            "tighten", decay_half_life=tighten_hl,
            effectiveness=tighten_eff, rebound_rate=tighten_rb,
        ),
    }


def _default_causal_modifiers() -> dict[str, DriftTransitionParams]:
    """Default causal modifiers shared across archetypes."""
    return {
        "config_change": DriftTransitionParams(
            continuation_rate=0.6, acceleration_factor=-0.01,
            self_correction_probability=0.4, self_correction_magnitude=0.5,
        ),
        "model_update": DriftTransitionParams(
            continuation_rate=1.2, acceleration_factor=0.02,
            self_correction_probability=0.1, self_correction_magnitude=0.2,
        ),
        "workload_shift": DriftTransitionParams(
            continuation_rate=0.8, acceleration_factor=0.0,
            self_correction_probability=0.3, self_correction_magnitude=0.4,
        ),
        "semantic_reframing": DriftTransitionParams(
            continuation_rate=1.1, acceleration_factor=0.01,
            self_correction_probability=0.15, self_correction_magnitude=0.25,
        ),
        "organic": DriftTransitionParams(
            continuation_rate=1.0, acceleration_factor=0.0,
            self_correction_probability=0.2, self_correction_magnitude=0.3,
        ),
    }


_ARCHETYPE_DEFAULTS: dict[str, tuple[DriftTransitionParams, dict[str, float]]] = {
    # (natural_transition, {intervention_type: (effectiveness, half_life, rebound)})
    "financial-analyst": (
        DriftTransitionParams(
            continuation_rate=1.1, acceleration_factor=0.01,
            self_correction_probability=0.1, self_correction_magnitude=0.2,
        ),
        {"advisory_eff": 0.4, "throttle_eff": 0.7, "escalate_eff": 0.85,
         "tighten_eff": 0.9, "tighten_hl": 3.0},
    ),
    "customer-experience": (
        DriftTransitionParams(
            continuation_rate=0.9, acceleration_factor=0.0,
            self_correction_probability=0.3, self_correction_magnitude=0.35,
        ),
        {"advisory_eff": 0.7, "throttle_eff": 0.75, "escalate_eff": 0.85,
         "tighten_eff": 0.9},
    ),
    "security-monitor": (
        DriftTransitionParams(
            continuation_rate=1.15, acceleration_factor=0.02,
            self_correction_probability=0.05, self_correction_magnitude=0.15,
        ),
        {"advisory_eff": 0.8, "throttle_eff": 0.9, "escalate_eff": 0.95,
         "tighten_eff": 0.98, "tighten_hl": 2.0, "escalate_hl": 3.0},
    ),
    "sales-agent": (
        DriftTransitionParams(
            continuation_rate=1.0, acceleration_factor=0.005,
            self_correction_probability=0.25, self_correction_magnitude=0.3,
        ),
        {"advisory_eff": 0.55, "throttle_eff": 0.85, "escalate_eff": 0.9,
         "tighten_eff": 0.92},
    ),
    "operations-coordinator": (
        DriftTransitionParams(
            continuation_rate=0.95, acceleration_factor=0.0,
            self_correction_probability=0.2, self_correction_magnitude=0.3,
        ),
        {"advisory_eff": 0.6, "throttle_eff": 0.75, "escalate_eff": 0.85,
         "tighten_eff": 0.9},
    ),
    "data-processor": (
        DriftTransitionParams(
            continuation_rate=1.05, acceleration_factor=0.005,
            self_correction_probability=0.15, self_correction_magnitude=0.25,
        ),
        {"advisory_eff": 0.45, "throttle_eff": 0.7, "escalate_eff": 0.85,
         "tighten_eff": 0.92},
    ),
    "content-creator": (
        DriftTransitionParams(
            continuation_rate=0.85, acceleration_factor=-0.005,
            self_correction_probability=0.35, self_correction_magnitude=0.4,
        ),
        {"advisory_eff": 0.65, "throttle_eff": 0.7, "escalate_eff": 0.8,
         "tighten_eff": 0.88},
    ),
    "research-analyst": (
        DriftTransitionParams(
            continuation_rate=0.9, acceleration_factor=0.0,
            self_correction_probability=0.3, self_correction_magnitude=0.35,
        ),
        {"advisory_eff": 0.6, "throttle_eff": 0.72, "escalate_eff": 0.82,
         "tighten_eff": 0.9},
    ),
    "executive-assistant": (
        DriftTransitionParams(
            continuation_rate=0.95, acceleration_factor=0.0,
            self_correction_probability=0.2, self_correction_magnitude=0.3,
        ),
        {"advisory_eff": 0.6, "throttle_eff": 0.75, "escalate_eff": 0.88,
         "tighten_eff": 0.93},
    ),
    "healthcare-agent": (
        DriftTransitionParams(
            continuation_rate=1.1, acceleration_factor=0.01,
            self_correction_probability=0.08, self_correction_magnitude=0.2,
        ),
        {"advisory_eff": 0.7, "throttle_eff": 0.85, "escalate_eff": 0.95,
         "tighten_eff": 0.98, "tighten_hl": 2.5, "escalate_hl": 4.0},
    ),
}


class DriftDynamicsModel:
    """Predicts drift evolution using per-archetype parametric models.

    Each archetype has a pre-seeded dynamics model that captures how drift
    evolves naturally, how interventions affect it, and how causal context
    modifies the trajectory. As observed episodes accumulate, the model
    transitions from parametric defaults to empirically-tuned parameters.
    """

    def __init__(self) -> None:
        self._models: dict[str, ArchetypeDynamics] = {}
        self._lock = threading.Lock()
        self._init_defaults()

    def _init_defaults(self) -> None:
        """Pre-seed parametric defaults for all 10 built-in archetypes."""
        for name, (nat_trans, intv_kwargs) in _ARCHETYPE_DEFAULTS.items():
            self._models[name] = ArchetypeDynamics(
                archetype_name=name,
                natural_transition=nat_trans,
                intervention_effects=_default_interventions(**intv_kwargs),
                causal_modifiers=_default_causal_modifiers(),
            )

    def get_dynamics(self, archetype: str) -> ArchetypeDynamics:
        """Get the dynamics model for an archetype. Returns default if unknown."""
        with self._lock:
            if archetype in self._models:
                return self._models[archetype]
            # Return a generic default for unknown archetypes
            default = ArchetypeDynamics(
                archetype_name=archetype,
                natural_transition=DriftTransitionParams(),
                intervention_effects=_default_interventions(),
                causal_modifiers=_default_causal_modifiers(),
            )
            self._models[archetype] = default
            return default

    def project_drift(
        self,
        current_drift: float,
        velocity: float,
        horizon: int,
        archetype: str,
        intervention: str | None = None,
        cause_type: str = "organic",
        *,
        _rng: Any | None = None,
    ) -> list[float]:
        """Project drift forward by *horizon* steps.

        Returns a list of projected drift values, one per step.

        Parameters
        ----------
        current_drift:
            Current overall drift score (0.0-1.0).
        velocity:
            Current drift velocity (drift units per step).
        horizon:
            Number of steps to project.
        archetype:
            Archetype name to look up dynamics.
        intervention:
            Optional intervention type applied at step 0.
        cause_type:
            Causal context for the drift episode.
        _rng:
            Optional ``random.Random`` instance for reproducible projections.
        """
        import random as _random

        rng = _rng if _rng is not None else _random

        dynamics = self.get_dynamics(archetype)

        # Select transition params: causal modifier takes precedence
        if cause_type in dynamics.causal_modifiers:
            params = dynamics.causal_modifiers[cause_type]
        else:
            params = dynamics.natural_transition

        intv_effect: InterventionEffect | None = None
        if intervention is not None:
            intv_effect = dynamics.intervention_effects.get(intervention)

        projected: list[float] = []
        drift = current_drift

        # Pre-decide intervention effectiveness (single roll per projection)
        intervention_effective = False
        if intv_effect is not None:
            intervention_effective = rng.random() < intv_effect.effectiveness

        rebound_start = (
            int(intv_effect.decay_half_life * 3) if intv_effect else horizon + 1
        )
        # Track the drift value at the point intervention decay bottoms out
        drift_at_rebound = 0.0

        for step in range(1, horizon + 1):
            if intv_effect is not None and intervention_effective:
                # Intervention path: exponential decay then rebound
                if step <= rebound_start:
                    # Exponential decay: drift * 2^(-step / half_life)
                    decay = math.pow(2.0, -step / intv_effect.decay_half_life)
                    drift = current_drift * decay
                    drift_at_rebound = drift
                else:
                    # Rebound phase
                    rebound_steps = step - rebound_start
                    drift = drift_at_rebound + (
                        intv_effect.rebound_rate * velocity * rebound_steps
                    )
            else:
                # Natural trajectory (or failed intervention)
                drift += velocity * params.continuation_rate + (
                    params.acceleration_factor * step
                )
                # Self-correction check
                if (
                    params.self_correction_probability > 0
                    and rng.random() < params.self_correction_probability
                ):
                    drift *= 1.0 - params.self_correction_magnitude

            # Clamp to [0.0, 1.0]
            drift = max(0.0, min(1.0, drift))
            projected.append(drift)

        return projected

    def record_episode(
        self,
        archetype: str,
        drift_trajectory: list[float],
        intervention: str | None = None,
        intervention_at_step: int | None = None,
        cause_type: str = "organic",
    ) -> None:
        """Record an observed drift episode for model refinement.

        Increment ``episodes_observed``. When the model has 50+ episodes,
        observed data is blended into the parametric defaults.
        """
        with self._lock:
            dynamics = self._models.get(archetype)
            if dynamics is None:
                # Auto-create with defaults
                dynamics = self.get_dynamics(archetype)

            dynamics.episodes_observed += 1

            if dynamics.episodes_observed < 50:
                # Not enough data to refine — keep defaults
                return

            # Blend observed data into parameters
            self._refine_from_trajectory(
                dynamics, drift_trajectory, intervention,
                intervention_at_step, cause_type,
            )

    def _refine_from_trajectory(
        self,
        dynamics: ArchetypeDynamics,
        trajectory: list[float],
        intervention: str | None,
        intervention_at_step: int | None,
        cause_type: str,
    ) -> None:
        """Blend observed trajectory data into model parameters.

        Uses exponential moving average with a blend weight that increases
        as more episodes are observed (heavier weight on observations as
        maturity grows).
        """
        if len(trajectory) < 3:
            return

        episodes = dynamics.episodes_observed
        # Blend weight: 0.0 at 50 episodes, approaches 1.0 at 200+
        blend = min(1.0, (episodes - 50) / 150.0)

        # Estimate observed velocity from trajectory
        deltas = [
            trajectory[i + 1] - trajectory[i]
            for i in range(len(trajectory) - 1)
        ]
        if not deltas:
            return

        observed_velocity = sum(deltas) / len(deltas)

        # Check for self-corrections (negative deltas)
        negative_steps = sum(1 for d in deltas if d < -0.01)
        observed_sc_prob = negative_steps / len(deltas) if deltas else 0.0

        # Determine which params to update
        if cause_type in dynamics.causal_modifiers:
            params = dynamics.causal_modifiers[cause_type]
        else:
            params = dynamics.natural_transition

        # Blend continuation rate
        if observed_velocity != 0 and params.continuation_rate != 0:
            observed_cr = observed_velocity / max(
                abs(params.continuation_rate), 0.01,
            )
            params.continuation_rate = (
                (1 - blend) * params.continuation_rate + blend * observed_cr
            )

        # Blend self-correction probability
        params.self_correction_probability = (
            (1 - blend) * params.self_correction_probability
            + blend * observed_sc_prob
        )

        # Refine intervention effects if intervention was applied
        if intervention and intervention_at_step is not None:
            intv = dynamics.intervention_effects.get(intervention)
            if intv and intervention_at_step < len(trajectory):
                pre_drift = trajectory[intervention_at_step]
                post_drifts = trajectory[intervention_at_step + 1:]
                if post_drifts and pre_drift > 0:
                    min_post = min(post_drifts)
                    reduction = (pre_drift - min_post) / pre_drift
                    observed_eff = 1.0 if reduction > 0.1 else 0.0
                    intv.effectiveness = (
                        (1 - blend) * intv.effectiveness
                        + blend * observed_eff
                    )

    def maturity(self, archetype: str) -> str:
        """Return model maturity level.

        Returns ``'default'`` (<50 episodes), ``'blended'`` (50-200),
        or ``'observed'`` (200+).
        """
        with self._lock:
            dynamics = self._models.get(archetype)
            if dynamics is None:
                return "default"
            if dynamics.episodes_observed < 50:
                return "default"
            if dynamics.episodes_observed < 200:
                return "blended"
            return "observed"
