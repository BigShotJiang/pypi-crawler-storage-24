"""Tiered escalation paths — try cheap resolutions before expensive ones.

Instead of routing every ambiguous decision to a human reviewer, the
escalation path system tries lower-cost resolution steps first. Each
step has a cost and expected information gain. VOI governs whether to
proceed to the next tier or accept the current resolution.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from nomotic.cost_profile import CostProfile
from nomotic.types import Action, AgentContext, DimensionScore
from nomotic.voi import VOIResult

__all__ = [
    "EscalationManager",
    "EscalationPath",
    "EscalationResult",
    "EscalationStep",
]

# Threshold for "high" false-allow cost — above this, fallback is DENY.
_HIGH_FALSE_ALLOW_COST = 0.6

# Percentage by which secondary check adjusts thresholds.
_SECONDARY_THRESHOLD_ADJUSTMENT = 0.05

# Ambiguity zone boundaries for UCS resolution checks.
_AMBIGUITY_LOWER = 0.35
_AMBIGUITY_UPPER = 0.65


@dataclass(frozen=True)
class EscalationStep:
    """One step in an escalation path."""

    step_type: str  # "request_context", "secondary_check", "human_review"
    cost: float  # Relative cost of this step
    expected_resolution_rate: float  # Probability this step resolves the ambiguity
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "step_type": self.step_type,
            "cost": self.cost,
            "expected_resolution_rate": self.expected_resolution_rate,
            "description": self.description,
        }


@dataclass
class EscalationPath:
    """Ordered sequence of escalation steps, cheapest first."""

    steps: list[EscalationStep] = field(default_factory=lambda: [
        EscalationStep(
            "request_context",
            cost=0.02,
            expected_resolution_rate=0.3,
            description="Request additional context from agent",
        ),
        EscalationStep(
            "secondary_check",
            cost=0.08,
            expected_resolution_rate=0.4,
            description="Re-evaluate with relaxed/tightened parameters",
        ),
        EscalationStep(
            "human_review",
            cost=0.20,
            expected_resolution_rate=0.9,
            description="Route to human reviewer",
        ),
    ])
    fallback_verdict: str = "DENY"

    def to_dict(self) -> dict[str, Any]:
        return {
            "steps": [s.to_dict() for s in self.steps],
            "fallback_verdict": self.fallback_verdict,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EscalationPath:
        steps = [
            EscalationStep(
                step_type=s["step_type"],
                cost=s["cost"],
                expected_resolution_rate=s["expected_resolution_rate"],
                description=s.get("description", ""),
            )
            for s in data.get("steps", [])
        ]
        return cls(
            steps=steps if steps else EscalationPath().steps,
            fallback_verdict=data.get("fallback_verdict", "DENY"),
        )


@dataclass
class EscalationResult:
    """Result of running the escalation path."""

    resolved: bool
    resolved_at_step: str = ""
    steps_attempted: list[str] = field(default_factory=list)
    total_cost_incurred: float = 0.0
    final_verdict: str = ""
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "resolved": self.resolved,
            "resolved_at_step": self.resolved_at_step,
            "steps_attempted": list(self.steps_attempted),
            "total_cost_incurred": round(self.total_cost_incurred, 4),
            "final_verdict": self.final_verdict,
            "detail": self.detail,
        }


class EscalationManager:
    """Manages tiered escalation for ambiguous governance decisions."""

    def __init__(self, default_path: EscalationPath | None = None) -> None:
        self._default_path = default_path or EscalationPath()

    @property
    def default_path(self) -> EscalationPath:
        return self._default_path

    def resolve(
        self,
        action: Action,
        context: AgentContext,
        scores: list[DimensionScore],
        ucs: float,
        voi_result: VOIResult,
        cost_profile: CostProfile | None = None,
        escalation_path: EscalationPath | None = None,
    ) -> EscalationResult:
        """Attempt to resolve an ambiguous decision through the escalation path.

        Walks through escalation steps cheapest-first. For each step, checks
        whether VOI justifies its cost before attempting resolution. Returns
        as soon as a step resolves the ambiguity, or falls back to a default
        verdict if no step succeeds.
        """
        path = escalation_path or self._default_path

        # Determine fallback verdict from cost profile.
        fallback = path.fallback_verdict
        if cost_profile is not None:
            if cost_profile.false_allow_cost >= _HIGH_FALSE_ALLOW_COST:
                fallback = "DENY"
            else:
                fallback = "ALLOW"

        steps_attempted: list[str] = []
        total_cost = 0.0

        for step in path.steps:
            # VOI gate: skip step if VOI doesn't justify the cost.
            if voi_result.voi_score < step.cost:
                detail = (
                    f"VOI {voi_result.voi_score:.4f} < step cost {step.cost:.4f}; "
                    f"skipping remaining steps"
                )
                return EscalationResult(
                    resolved=False,
                    steps_attempted=steps_attempted,
                    total_cost_incurred=total_cost,
                    final_verdict=fallback,
                    detail=detail,
                )

            steps_attempted.append(step.step_type)
            total_cost += step.cost

            # -- Attempt resolution per step type --------------------------

            if step.step_type == "request_context":
                resolved, verdict = self._try_request_context(
                    action, scores, ucs,
                )
                if resolved:
                    return EscalationResult(
                        resolved=True,
                        resolved_at_step="request_context",
                        steps_attempted=steps_attempted,
                        total_cost_incurred=total_cost,
                        final_verdict=verdict,
                        detail="Additional context resolved ambiguity",
                    )

            elif step.step_type == "secondary_check":
                resolved, verdict = self._try_secondary_check(ucs)
                if resolved:
                    return EscalationResult(
                        resolved=True,
                        resolved_at_step="secondary_check",
                        steps_attempted=steps_attempted,
                        total_cost_incurred=total_cost,
                        final_verdict=verdict,
                        detail="Secondary check with adjusted thresholds resolved ambiguity",
                    )

            elif step.step_type == "human_review":
                # Human review always "succeeds" by deferring to the human.
                return EscalationResult(
                    resolved=True,
                    resolved_at_step="human_review",
                    steps_attempted=steps_attempted,
                    total_cost_incurred=total_cost,
                    final_verdict="ESCALATE",
                    detail="Escalated to human reviewer",
                )

        # All steps exhausted without resolution.
        return EscalationResult(
            resolved=False,
            steps_attempted=steps_attempted,
            total_cost_incurred=total_cost,
            final_verdict=fallback,
            detail="All escalation steps exhausted without resolution",
        )

    # -- Resolution helpers ------------------------------------------------

    @staticmethod
    def _try_request_context(
        action: Action,
        scores: list[DimensionScore],
        ucs: float,
    ) -> tuple[bool, str]:
        """Check if action parameters contain additional context that resolves ambiguity.

        If the action carries ``additional_context`` in its parameters, we
        treat that as new information that may push the UCS outside the
        ambiguity zone.
        """
        additional = action.parameters.get("additional_context")
        if not additional:
            return False, ""

        # Heuristic: additional context gives a confidence bump proportional
        # to the amount of context provided. A simple proxy is the number
        # of context keys (for dicts) or length (for strings).
        if isinstance(additional, dict):
            bump = min(0.15, len(additional) * 0.05)
        elif isinstance(additional, str):
            bump = min(0.15, len(additional) * 0.005)
        else:
            bump = 0.05

        adjusted_ucs = ucs + bump
        if adjusted_ucs >= _AMBIGUITY_UPPER:
            return True, "ALLOW"
        if adjusted_ucs <= _AMBIGUITY_LOWER:
            return True, "DENY"
        return False, ""

    @staticmethod
    def _try_secondary_check(ucs: float) -> tuple[bool, str]:
        """Re-evaluate with slightly adjusted thresholds (±5%).

        If the UCS is within the adjustment margin of a clear verdict,
        the secondary check resolves the ambiguity.
        """
        if ucs >= (_AMBIGUITY_UPPER - _SECONDARY_THRESHOLD_ADJUSTMENT):
            return True, "ALLOW"
        if ucs <= (_AMBIGUITY_LOWER + _SECONDARY_THRESHOLD_ADJUSTMENT):
            return True, "DENY"
        return False, ""
