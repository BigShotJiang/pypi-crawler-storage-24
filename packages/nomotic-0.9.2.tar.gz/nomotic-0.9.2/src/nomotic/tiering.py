"""Product Tiering — dimension activation by subscription tier.

Three tiers control which governance dimensions are active by default:

- **Base** (8 dimensions): Core safety dimensions for all deployments.
- **Professional** (17 dimensions): Base + behavioral, impact, and alignment dimensions.
- **Enterprise** (20 dimensions, 14 open source + 6 nomotic-pro): All dimensions
  including transparency, jurisdictional compliance, and minimum necessary privilege.

Custom overrides allow activating dimensions beyond the tier default
or disabling dimensions within the tier.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nomotic.dimensions import DimensionRegistry, GovernanceDimension

if TYPE_CHECKING:
    from nomotic.license import ActivatedTier

__all__ = [
    "ACTIVATED_TIER_TO_PRODUCT_TIER",
    "ProductTier",
    "TIER_DIMENSIONS",
    "TieringConfig",
]


class ProductTier(Enum):
    BASE = "base"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"


# Dimension assignment by tier.  Each tier includes all dimensions from
# lower tiers plus its own additions.
TIER_DIMENSIONS: dict[ProductTier, list[str]] = {
    ProductTier.BASE: [
        "scope_compliance",
        "authority_verification",
        "resource_boundaries",
        "isolation_integrity",
        "temporal_compliance",
        "human_override",
        "reversibility",                    # D15
        "data_sensitivity_classification",  # D17 — foundation
    ],
    ProductTier.PROFESSIONAL: [
        # All Base dimensions +
        "scope_compliance",
        "authority_verification",
        "resource_boundaries",
        "isolation_integrity",
        "temporal_compliance",
        "human_override",
        "reversibility",
        "data_sensitivity_classification",
        # Professional additions
        "behavioral_consistency",
        "cascading_impact",
        "stakeholder_impact",
        "incident_detection",
        "precedent_alignment",
        "ethical_alignment",
        "goal_action_alignment",            # D19
        "adversarial_signal_detection",     # D20
        "delegation_chain_integrity",       # D18
    ],
    ProductTier.ENTERPRISE: [
        # All Professional dimensions +
        "scope_compliance",
        "authority_verification",
        "resource_boundaries",
        "isolation_integrity",
        "temporal_compliance",
        "human_override",
        "reversibility",
        "data_sensitivity_classification",
        "behavioral_consistency",
        "cascading_impact",
        "stakeholder_impact",
        "incident_detection",
        "precedent_alignment",
        "ethical_alignment",
        "goal_action_alignment",
        "adversarial_signal_detection",
        "delegation_chain_integrity",
        # Enterprise additions
        "transparency",
        "jurisdictional_compliance",
        "minimum_necessary_privilege",      # D16
    ],
}


def activated_tier_to_product_tier(activated: "ActivatedTier") -> ProductTier:
    """Map a license :class:`ActivatedTier` to the corresponding :class:`ProductTier`.

    This bridges the license gate (which resolves *what the customer paid for*)
    with the product tiering system (which controls *which dimensions are active*).
    """
    from nomotic.license import ActivatedTier

    _mapping: dict["ActivatedTier", ProductTier] = {
        ActivatedTier.OPEN: ProductTier.BASE,
        ActivatedTier.PRO: ProductTier.PROFESSIONAL,
        ActivatedTier.ENTERPRISE: ProductTier.ENTERPRISE,
    }
    return _mapping.get(activated, ProductTier.BASE)


@dataclass
class TieringConfig:
    """Controls which dimensions are active based on product tier."""

    tier: ProductTier = ProductTier.PROFESSIONAL
    custom_enabled: list[str] = field(default_factory=list)
    """Activate dimensions beyond the tier default."""
    custom_disabled: list[str] = field(default_factory=list)
    """Disable dimensions within the tier default."""

    def active_dimension_names(self) -> list[str]:
        """Return the resolved set of active dimension names."""
        tier_dims = set(TIER_DIMENSIONS[self.tier])
        tier_dims.update(self.custom_enabled)
        tier_dims -= set(self.custom_disabled)
        return sorted(tier_dims)
