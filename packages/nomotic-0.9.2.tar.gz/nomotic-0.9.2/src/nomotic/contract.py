"""Behavioral Contracts — declarative behavioral expectations for governed agents.

A Behavioral Contract consolidates an agent's behavioral expectations into
a single, versioned, cryptographically sealed, machine-enforceable artifact.
It declares what the agent should do, how often, in what patterns, with
what outcomes, and the Behavioral Control Plane holds it accountable
to that declaration continuously.

Contracts bundle: identity (birth certificate binding), behavioral DNA
(archetype prior), authorized scope, trust parameters, behavioral
invariants, semantic anchors, and drift thresholds.
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
import uuid
from dataclasses import dataclass, field, fields, replace
from typing import TYPE_CHECKING, Any

# Guard this import so it only runs during static analysis, not at runtime.
# compile_invariants() uses a deferred `from nomotic.invariants import ...`
# inside the function body to avoid a circular import at module load time.
# The TYPE_CHECKING block makes the name available to type checkers and linters
# without introducing the circular dependency.
# See: https://docs.python.org/3/library/typing.html#typing.TYPE_CHECKING
if TYPE_CHECKING:
    from nomotic.invariants import CompiledInvariants

from nomotic.keys import SigningKey, VerifyKey

__all__ = ["BehavioralContract", "ContractStore", "generate_contract"]


@dataclass(frozen=True)
class BehavioralContract:
    """Versioned behavioral expectations for an agent.

    Frozen so contracts are immutable once created. New expectations
    require a new version. The version history is maintained by
    ContractStore.
    """

    contract_id: str
    version: int
    agent_id: str
    created_at: float

    # Identity binding
    certificate_id: str | None = None
    archetype: str = "general"

    # Behavioral expectations (from archetype prior)
    expected_action_distribution: dict[str, float] = field(default_factory=dict)
    expected_target_distribution: dict[str, float] = field(default_factory=dict)
    expected_outcome_distribution: dict[str, float] = field(default_factory=dict)

    # Scope — what the agent is authorized to do
    authorized_scope: dict[str, Any] = field(default_factory=dict)

    # Trust parameters
    initial_trust: float = 0.5
    trust_floor: float = 0.0
    trust_ceiling: float = 1.0

    # Behavioral invariants
    invariants: list[dict[str, Any]] = field(default_factory=list)

    # Semantic anchors
    semantic_anchors: list[dict[str, Any]] = field(default_factory=list)

    # Drift thresholds
    drift_thresholds: dict[str, float] = field(default_factory=dict)

    # Cost profile (serialized CostProfile dict — dict to keep frozen dataclass simple)
    cost_profile: dict[str, Any] = field(default_factory=dict)

    # Escalation path (serialized EscalationPath dict — custom tiered escalation)
    escalation_path: dict[str, Any] = field(default_factory=dict)

    # Cryptographic seal
    signature: str = ""
    signed_by: str = ""

    def content_hash(self) -> str:
        """SHA-256 hash of all contract fields EXCEPT signature and signed_by."""
        d: dict[str, Any] = {}
        for f in fields(self):
            if f.name in ("signature", "signed_by"):
                continue
            d[f.name] = getattr(self, f.name)
        raw = json.dumps(d, sort_keys=True, default=str).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def seal(self, signing_key: SigningKey, signer_id: str = "system") -> BehavioralContract:
        """Return a new frozen BehavioralContract with signature filled."""
        hash_hex = self.content_hash()
        sig = signing_key.sign(hash_hex.encode("utf-8"))
        return replace(self, signature=sig.hex(), signed_by=signer_id)

    def verify(self, verify_key: VerifyKey) -> bool:
        """Verify the cryptographic seal."""
        if not self.signature:
            return False
        try:
            hash_hex = self.content_hash()
            return verify_key.verify(
                bytes.fromhex(self.signature),
                hash_hex.encode("utf-8"),
            )
        except (ValueError, TypeError):
            return False

    def diff(self, other: BehavioralContract) -> dict[str, Any]:
        """Compare two contract versions, return what changed."""
        if self.agent_id != other.agent_id:
            raise ValueError(
                f"Cannot diff contracts for different agents: "
                f"{self.agent_id!r} vs {other.agent_id!r}"
            )
        skip = {"contract_id", "created_at", "signature", "signed_by"}
        changes: dict[str, Any] = {}
        for f in fields(self):
            if f.name in skip:
                continue
            old_val = getattr(self, f.name)
            new_val = getattr(other, f.name)
            if old_val != new_val:
                if isinstance(old_val, dict) and isinstance(new_val, dict):
                    all_keys = set(old_val) | set(new_val)
                    per_key: dict[str, Any] = {}
                    for k in sorted(all_keys):
                        ov = old_val.get(k)
                        nv = new_val.get(k)
                        if ov != nv:
                            per_key[k] = {"from": ov, "to": nv}
                    changes[f.name] = per_key
                else:
                    changes[f.name] = {"from": old_val, "to": new_val}
        return {
            "version_from": self.version,
            "version_to": other.version,
            "changes": changes,
        }

    def compile_invariants(self) -> 'CompiledInvariants':
        """Compile this contract's invariants into optimized evaluation artifacts."""
        from nomotic.invariants import CompiledInvariants, InvariantSpec

        specs = [InvariantSpec.from_dict(d) for d in self.invariants]
        return CompiledInvariants.compile(specs)

    def to_dict(self) -> dict[str, Any]:
        """Full JSON serialization."""
        d: dict[str, Any] = {}
        for f in fields(self):
            val = getattr(self, f.name)
            if isinstance(val, dict):
                d[f.name] = dict(val)
            elif isinstance(val, list):
                d[f.name] = list(val)
            else:
                d[f.name] = val
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BehavioralContract:
        """Deserialize from dict. Handle missing optional fields with defaults."""
        known = {f.name for f in fields(cls)}
        kwargs: dict[str, Any] = {}
        for k, v in data.items():
            if k in known:
                kwargs[k] = v
        return cls(**kwargs)


class ContractStore:
    """In-memory store for behavioral contracts. One active contract per agent.

    Thread-safe. Maintains version history for audit trail.
    """

    def __init__(self) -> None:
        self._active: dict[str, BehavioralContract] = {}
        self._history: dict[str, list[BehavioralContract]] = {}
        self._lock = threading.Lock()

    def store(self, contract: BehavioralContract) -> None:
        """Store a contract and set it as active."""
        with self._lock:
            current = self._active.get(contract.agent_id)
            if current is not None and contract.version <= current.version:
                raise ValueError(
                    f"New contract version ({contract.version}) must be greater "
                    f"than current version ({current.version}) for agent "
                    f"{contract.agent_id!r}"
                )
            self._active[contract.agent_id] = contract
            self._history.setdefault(contract.agent_id, []).append(contract)

    def get_active(self, agent_id: str) -> BehavioralContract | None:
        """Get the current active contract for an agent."""
        with self._lock:
            return self._active.get(agent_id)

    def get_version(self, agent_id: str, version: int) -> BehavioralContract | None:
        """Get a specific version from history."""
        with self._lock:
            for c in self._history.get(agent_id, []):
                if c.version == version:
                    return c
            return None

    def get_history(self, agent_id: str) -> list[BehavioralContract]:
        """Get all contract versions for an agent, ordered by version."""
        with self._lock:
            return list(self._history.get(agent_id, []))

    def revoke(self, agent_id: str, reason: str = "") -> bool:
        """Remove the active contract for an agent. History is preserved."""
        with self._lock:
            if agent_id in self._active:
                del self._active[agent_id]
                return True
            return False

    def all_active(self) -> dict[str, BehavioralContract]:
        """Return dict of all active contracts. Returns a copy for thread safety."""
        with self._lock:
            return dict(self._active)


def generate_contract(
    agent_id: str,
    archetype: str,
    prior_registry: Any,
    certificate: Any | None = None,
    scope: dict[str, Any] | None = None,
    invariants: list[dict[str, Any]] | None = None,
    semantic_anchors: list[dict[str, Any]] | None = None,
    drift_thresholds: dict[str, float] | None = None,
    version: int = 1,
    cost_profile: dict[str, Any] | None = None,
) -> BehavioralContract:
    """Generate a contract from an archetype prior and optional overrides."""
    prior = prior_registry.get_for_agent(archetype)

    expected_action: dict[str, float] = {}
    expected_target: dict[str, float] = {}
    expected_outcome: dict[str, float] = {}
    default_cost_profile: dict[str, Any] = {}

    if prior is not None:
        expected_action = dict(prior.action_distribution)
        expected_target = dict(prior.target_categories)
        expected_outcome = dict(prior.outcome_expectations)
        if hasattr(prior, "default_cost_profile") and prior.default_cost_profile:
            default_cost_profile = dict(prior.default_cost_profile)

    # Explicit cost_profile overrides archetype default
    final_cost_profile = cost_profile if cost_profile is not None else default_cost_profile

    cert_id: str | None = None
    default_scope: dict[str, Any] = {}
    if certificate is not None:
        cert_id = certificate.certificate_id
        if hasattr(certificate, "scope") and certificate.scope:
            default_scope = dict(certificate.scope)

    final_scope = default_scope
    if scope is not None:
        final_scope = scope

    return BehavioralContract(
        contract_id=str(uuid.uuid4()),
        version=version,
        agent_id=agent_id,
        created_at=time.time(),
        certificate_id=cert_id,
        archetype=archetype,
        expected_action_distribution=expected_action,
        expected_target_distribution=expected_target,
        expected_outcome_distribution=expected_outcome,
        authorized_scope=final_scope,
        invariants=invariants or [],
        semantic_anchors=semantic_anchors or [],
        drift_thresholds=drift_thresholds or {},
        cost_profile=final_cost_profile,
    )
