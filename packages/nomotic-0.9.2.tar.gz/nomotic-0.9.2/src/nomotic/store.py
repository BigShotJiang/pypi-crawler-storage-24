"""Certificate storage — pluggable persistence for agent certificates.

v1 is an in-memory store backed by a simple dict. The interface is defined
as a Protocol so it can be swapped for file-based JSON, SQLite, Postgres,
or any other backend without changing calling code.

The file-based store (FileCertificateStore) persists certificates and keys
to ``~/.nomotic/`` for the CLI and standalone usage.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Protocol, runtime_checkable

from nomotic.certificate import AgentCertificate, CertStatus

__all__ = [
    "CertificateStore",
    "MemoryCertificateStore",
    "FileCertificateStore",
    "HumanOverrideStore",
    "SQLiteHumanOverrideStore",
    "PendingApproval",
    "GrantedApproval",
]


# ── Human Override persistence types ─────────────────────────────────


@dataclass
class PendingApproval:
    """A pending human approval request with expiry."""

    action_id: str
    agent_id: str
    action_type: str
    created_at: float = field(default_factory=time.time)
    expires_at: float = 0.0  # 0 = no expiry
    state: str = "pending"  # "pending" | "expired"


@dataclass
class GrantedApproval:
    """A granted human approval with validity window."""

    action_id: str
    agent_id: str
    action_type: str
    granted_at: float = field(default_factory=time.time)
    valid_until: float = 0.0  # 0 = no expiry


@runtime_checkable
class HumanOverrideStore(Protocol):
    """Abstract persistence interface for human override state."""

    def save_pending(self, approval: PendingApproval) -> None: ...

    def get_pending(self, action_id: str) -> PendingApproval | None: ...

    def save_granted(self, approval: GrantedApproval) -> None: ...

    def get_granted(self, action_id: str) -> GrantedApproval | None: ...

    def expire_pending(self, now: float | None = None) -> list[PendingApproval]:
        """Move expired pending approvals to 'expired' state. Return those expired."""
        ...

    def remove_expired_grants(self, now: float | None = None) -> list[GrantedApproval]:
        """Remove grants past valid_until. Return those removed."""
        ...


class SQLiteHumanOverrideStore:
    """SQLite-backed persistence for human override state.

    Thread-safe — each thread gets its own connection via thread-local storage.
    """

    def __init__(self, db_path: str | Path = ":memory:") -> None:
        self._db_path = str(db_path)
        self._local = threading.local()
        self._init_db(self._get_conn())

    def _get_conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self._db_path)
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
            self._init_db(conn)
        return conn

    def _init_db(self, conn: sqlite3.Connection) -> None:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS pending_approvals (
                action_id TEXT PRIMARY KEY,
                agent_id TEXT NOT NULL,
                action_type TEXT NOT NULL,
                created_at REAL NOT NULL,
                expires_at REAL NOT NULL,
                state TEXT NOT NULL DEFAULT 'pending'
            );
            CREATE TABLE IF NOT EXISTS granted_approvals (
                action_id TEXT PRIMARY KEY,
                agent_id TEXT NOT NULL,
                action_type TEXT NOT NULL,
                granted_at REAL NOT NULL,
                valid_until REAL NOT NULL
            );
        """)
        conn.commit()

    def save_pending(self, approval: PendingApproval) -> None:
        conn = self._get_conn()
        conn.execute(
            "INSERT OR REPLACE INTO pending_approvals "
            "(action_id, agent_id, action_type, created_at, expires_at, state) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (approval.action_id, approval.agent_id, approval.action_type,
             approval.created_at, approval.expires_at, approval.state),
        )
        conn.commit()

    def get_pending(self, action_id: str) -> PendingApproval | None:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT * FROM pending_approvals WHERE action_id = ?", (action_id,)
        ).fetchone()
        if row is None:
            return None
        return PendingApproval(
            action_id=row["action_id"],
            agent_id=row["agent_id"],
            action_type=row["action_type"],
            created_at=row["created_at"],
            expires_at=row["expires_at"],
            state=row["state"],
        )

    def save_granted(self, approval: GrantedApproval) -> None:
        conn = self._get_conn()
        conn.execute(
            "INSERT OR REPLACE INTO granted_approvals "
            "(action_id, agent_id, action_type, granted_at, valid_until) "
            "VALUES (?, ?, ?, ?, ?)",
            (approval.action_id, approval.agent_id, approval.action_type,
             approval.granted_at, approval.valid_until),
        )
        conn.commit()

    def get_granted(self, action_id: str) -> GrantedApproval | None:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT * FROM granted_approvals WHERE action_id = ?", (action_id,)
        ).fetchone()
        if row is None:
            return None
        return GrantedApproval(
            action_id=row["action_id"],
            agent_id=row["agent_id"],
            action_type=row["action_type"],
            granted_at=row["granted_at"],
            valid_until=row["valid_until"],
        )

    def expire_pending(self, now: float | None = None) -> list[PendingApproval]:
        if now is None:
            now = time.time()
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT * FROM pending_approvals "
            "WHERE state = 'pending' AND expires_at > 0 AND expires_at <= ?",
            (now,),
        ).fetchall()
        expired: list[PendingApproval] = []
        for row in rows:
            pa = PendingApproval(
                action_id=row["action_id"],
                agent_id=row["agent_id"],
                action_type=row["action_type"],
                created_at=row["created_at"],
                expires_at=row["expires_at"],
                state="expired",
            )
            expired.append(pa)
        if expired:
            conn.execute(
                "UPDATE pending_approvals SET state = 'expired' "
                "WHERE state = 'pending' AND expires_at > 0 AND expires_at <= ?",
                (now,),
            )
            conn.commit()
        return expired

    def remove_expired_grants(self, now: float | None = None) -> list[GrantedApproval]:
        if now is None:
            now = time.time()
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT * FROM granted_approvals WHERE valid_until > 0 AND valid_until <= ?",
            (now,),
        ).fetchall()
        removed: list[GrantedApproval] = []
        for row in rows:
            removed.append(GrantedApproval(
                action_id=row["action_id"],
                agent_id=row["agent_id"],
                action_type=row["action_type"],
                granted_at=row["granted_at"],
                valid_until=row["valid_until"],
            ))
        if removed:
            conn.execute(
                "DELETE FROM granted_approvals WHERE valid_until > 0 AND valid_until <= ?",
                (now,),
            )
            conn.commit()
        return removed


@runtime_checkable
class CertificateStore(Protocol):
    """Abstract certificate storage interface."""

    def save(self, certificate: AgentCertificate) -> None: ...

    def get(self, certificate_id: str) -> AgentCertificate | None: ...

    def list(
        self,
        org: str | None = None,
        status: CertStatus | None = None,
        archetype: str | None = None,
    ) -> list[AgentCertificate]: ...

    def update(self, certificate: AgentCertificate) -> None: ...

    def move_to_revoked(self, certificate_id: str) -> None: ...

    def list_revoked(self) -> List[AgentCertificate]: ...


class MemoryCertificateStore:
    """In-memory certificate store.

    Good for testing and for embedding in the GovernanceRuntime where
    persistence isn't needed.
    """

    def __init__(self) -> None:
        self._certs: dict[str, AgentCertificate] = {}
        self._revoked: dict[str, AgentCertificate] = {}

    def save(self, certificate: AgentCertificate) -> None:
        self._certs[certificate.certificate_id] = certificate

    def get(self, certificate_id: str) -> AgentCertificate | None:
        cert = self._certs.get(certificate_id)
        if cert is None:
            cert = self._revoked.get(certificate_id)
        return cert

    def list(
        self,
        org: str | None = None,
        status: CertStatus | None = None,
        archetype: str | None = None,
    ) -> list[AgentCertificate]:
        results: list[AgentCertificate] = []
        for cert in self._certs.values():
            if org is not None and cert.organization != org:
                continue
            if status is not None and cert.status != status:
                continue
            if archetype is not None and cert.archetype != archetype:
                continue
            results.append(cert)
        return results

    def update(self, certificate: AgentCertificate) -> None:
        if certificate.certificate_id in self._revoked:
            self._revoked[certificate.certificate_id] = certificate
        else:
            self._certs[certificate.certificate_id] = certificate

    def move_to_revoked(self, certificate_id: str) -> None:
        cert = self._certs.pop(certificate_id, None)
        if cert is not None:
            self._revoked[certificate_id] = cert

    def list_revoked(self) -> List[AgentCertificate]:
        """Return all revoked certificates."""
        return list(self._revoked.values())


class FileCertificateStore:
    """File-based certificate store using JSON.

    Stores certificates in ``<base_dir>/certs/`` and revoked certificates
    in ``<base_dir>/revoked/``. Keys are stored alongside certificates.

    Directory layout::

        <base_dir>/
            certs/
                <cert-id>.json
                <cert-id>.key   (agent private key, only on issuing machine)
                <cert-id>.pub   (agent public key)
            revoked/
                <cert-id>.json
    """

    def __init__(self, base_dir: str | Path | None = None) -> None:
        if base_dir is None:
            base_dir = Path.home() / ".nomotic"
        self._base = Path(base_dir)
        self._certs_dir = self._base / "certs"
        self._revoked_dir = self._base / "revoked"
        self._certs_dir.mkdir(parents=True, exist_ok=True)
        self._revoked_dir.mkdir(parents=True, exist_ok=True)

    def save(self, certificate: AgentCertificate) -> None:
        path = self._certs_dir / f"{certificate.certificate_id}.json"
        path.write_text(
            json.dumps(certificate.to_dict(), sort_keys=True, indent=2),
            encoding="utf-8",
        )

    def get(self, certificate_id: str) -> AgentCertificate | None:
        path = self._certs_dir / f"{certificate_id}.json"
        if not path.exists():
            path = self._revoked_dir / f"{certificate_id}.json"
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        return AgentCertificate.from_dict(data)

    def list(
        self,
        org: str | None = None,
        status: CertStatus | None = None,
        archetype: str | None = None,
    ) -> list[AgentCertificate]:
        results: list[AgentCertificate] = []
        for path in sorted(self._certs_dir.glob("*.json")):
            data = json.loads(path.read_text(encoding="utf-8"))
            cert = AgentCertificate.from_dict(data)
            if org is not None and cert.organization != org:
                continue
            if status is not None and cert.status != status:
                continue
            if archetype is not None and cert.archetype != archetype:
                continue
            results.append(cert)
        return results

    def update(self, certificate: AgentCertificate) -> None:
        # Check revoked dir first
        revoked_path = self._revoked_dir / f"{certificate.certificate_id}.json"
        if revoked_path.exists():
            revoked_path.write_text(
                json.dumps(certificate.to_dict(), sort_keys=True, indent=2),
                encoding="utf-8",
            )
        else:
            self.save(certificate)

    def move_to_revoked(self, certificate_id: str) -> None:
        src = self._certs_dir / f"{certificate_id}.json"
        if src.exists():
            dst = self._revoked_dir / f"{certificate_id}.json"
            dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
            src.unlink()

    def list_revoked(self) -> List[AgentCertificate]:
        """Return all revoked certificates."""
        results: list[AgentCertificate] = []
        for path in sorted(self._revoked_dir.glob("*.json")):
            data = json.loads(path.read_text(encoding="utf-8"))
            results.append(AgentCertificate.from_dict(data))
        return results

    # ── Key file helpers ─────────────────────────────────────────────

    def save_agent_key(self, certificate_id: str, key_bytes: bytes) -> None:
        """Save the agent's private key alongside the certificate."""
        path = self._certs_dir / f"{certificate_id}.key"
        path.write_bytes(key_bytes)
        os.chmod(path, 0o600)

    def save_agent_pub(self, certificate_id: str, pub_bytes: bytes) -> None:
        """Save the agent's public key alongside the certificate."""
        path = self._certs_dir / f"{certificate_id}.pub"
        path.write_bytes(pub_bytes)

    def get_agent_key(self, certificate_id: str) -> bytes | None:
        """Load the agent's private key."""
        path = self._certs_dir / f"{certificate_id}.key"
        if not path.exists():
            return None
        return path.read_bytes()

    def get_agent_pub(self, certificate_id: str) -> bytes | None:
        """Load the agent's public key."""
        path = self._certs_dir / f"{certificate_id}.pub"
        if not path.exists():
            return None
        return path.read_bytes()
