"""Policy Evolution Dashboard — backend analytics engine.

Identifies exception clusters, outcome correlations, dimension drift,
and configuration staleness from audit trail data.  Generates specific
configuration recommendations and manages the approval workflow.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from nomotic.audit import (
    AccountabilityRecord,
    AuditRecord,
    AuditTrail,
    ChangeRecord,
    OutcomeRecord,
    UnwrittenPolicyAdjustmentRecord,
)


__all__ = [
    "GovernancePattern",
    "PatternAnalyzer",
    "PatternType",
    "PolicyEvolutionConfig",
    "PolicyEvolutionEngine",
    "PolicyRecommendation",
    "RecommendationEngine",
]


# ── Types ──────────────────────────────────────────────────────────────


class PatternType(Enum):
    EXCEPTION_CLUSTER = "exception_cluster"
    OUTCOME_CORRELATION = "outcome_correlation"
    DIMENSION_DRIFT = "dimension_drift"
    CONFIG_STALENESS = "config_staleness"


@dataclass
class GovernancePattern:
    """A recurring pattern surfaced by the dashboard analysis."""

    pattern_id: str
    pattern_type: PatternType
    description: str
    supporting_evidence: list[str]  # action_ids that contributed
    observation_count: int
    significance_score: float  # 0–1
    first_observed: float
    last_observed: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "pattern_id": self.pattern_id,
            "pattern_type": self.pattern_type.value,
            "description": self.description,
            "supporting_evidence": self.supporting_evidence,
            "observation_count": self.observation_count,
            "significance_score": round(self.significance_score, 4),
            "first_observed": self.first_observed,
            "last_observed": self.last_observed,
        }


@dataclass
class PolicyRecommendation:
    """A specific recommended configuration change."""

    recommendation_id: str
    pattern_id: str
    recommendation_text: str
    proposed_change: dict[str, Any]
    projected_impact: str
    status: str = "pending"  # "pending" | "approved" | "rejected" | "deferred"
    reviewed_by: str | None = None
    reviewed_at: float | None = None
    reviewer_note: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "recommendation_id": self.recommendation_id,
            "pattern_id": self.pattern_id,
            "recommendation_text": self.recommendation_text,
            "proposed_change": self.proposed_change,
            "projected_impact": self.projected_impact,
            "status": self.status,
        }
        if self.reviewed_by is not None:
            d["reviewed_by"] = self.reviewed_by
        if self.reviewed_at is not None:
            d["reviewed_at"] = self.reviewed_at
        if self.reviewer_note is not None:
            d["reviewer_note"] = self.reviewer_note
        return d


@dataclass
class PolicyEvolutionConfig:
    """Configuration for the policy evolution engine."""

    window_days: int = 90
    min_cluster_size: int = 5
    significance_threshold: float = 0.5
    drift_threshold: float = 0.3

    def to_dict(self) -> dict[str, Any]:
        return {
            "window_days": self.window_days,
            "min_cluster_size": self.min_cluster_size,
            "significance_threshold": self.significance_threshold,
            "drift_threshold": self.drift_threshold,
        }


# ── Pattern Analyzer ───────────────────────────────────────────────────


class PatternAnalyzer:
    """Analyzes Decision and Outcome records to identify governance patterns."""

    def analyze_exception_clusters(
        self,
        decisions: list[AuditRecord],
        accountability: list[AccountabilityRecord],
        window_days: int = 90,
        min_observations: int = 5,
    ) -> list[GovernancePattern]:
        """Find clusters where humans consistently overrode the system.

        Groups overrides by action_type and looks for repeated override
        patterns that exceed *min_observations* within *window_days*.
        """
        cutoff = time.time() - window_days * 86400

        # Build lookup of overridden action_ids and their rationales.
        override_map: dict[str, AccountabilityRecord] = {}
        for acc in accountability:
            if acc.timestamp < cutoff:
                continue
            if acc.human_action in ("override_approved", "override"):
                override_map[acc.action_id] = acc

        if not override_map:
            return []

        # Group overridden decisions by action_type.
        clusters: dict[str, list[AuditRecord]] = {}
        for dec in decisions:
            if dec.timestamp < cutoff:
                continue
            if dec.action_id in override_map:
                clusters.setdefault(dec.action_type, []).append(dec)

        patterns: list[GovernancePattern] = []
        for action_type, records in clusters.items():
            if len(records) < min_observations:
                continue
            timestamps = [r.timestamp for r in records]
            significance = min(1.0, len(records) / (min_observations * 3))
            patterns.append(
                GovernancePattern(
                    pattern_id=uuid.uuid4().hex[:12],
                    pattern_type=PatternType.EXCEPTION_CLUSTER,
                    description=(
                        f"Humans overrode system verdict on '{action_type}' "
                        f"{len(records)} times in the last {window_days} days"
                    ),
                    supporting_evidence=[r.action_id for r in records],
                    observation_count=len(records),
                    significance_score=significance,
                    first_observed=min(timestamps),
                    last_observed=max(timestamps),
                )
            )
        return patterns

    def analyze_outcome_correlations(
        self,
        decisions: list[AuditRecord],
        outcomes: list[OutcomeRecord],
        window_days: int = 90,
    ) -> list[GovernancePattern]:
        """Find cases where system verdicts are consistently contradicted by outcomes.

        Groups decisions by verdict and checks whether the outcome signals
        indicate the verdict was wrong (override_occurred or negative signals).
        """
        cutoff = time.time() - window_days * 86400

        outcome_by_action: dict[str, OutcomeRecord] = {}
        for o in outcomes:
            if o.timestamp >= cutoff:
                outcome_by_action[o.action_id] = o

        # Group decisions with outcomes by verdict.
        verdict_stats: dict[str, list[tuple[AuditRecord, OutcomeRecord]]] = {}
        for dec in decisions:
            if dec.timestamp < cutoff:
                continue
            outcome = outcome_by_action.get(dec.action_id)
            if outcome is None:
                continue
            verdict_stats.setdefault(dec.verdict, []).append((dec, outcome))

        patterns: list[GovernancePattern] = []
        for verdict, pairs in verdict_stats.items():
            contradicted = [
                (d, o) for d, o in pairs if o.override_occurred
            ]
            if len(contradicted) < 3:
                continue
            contradiction_rate = len(contradicted) / len(pairs)
            if contradiction_rate < 0.3:
                continue
            timestamps = [d.timestamp for d, _ in contradicted]
            patterns.append(
                GovernancePattern(
                    pattern_id=uuid.uuid4().hex[:12],
                    pattern_type=PatternType.OUTCOME_CORRELATION,
                    description=(
                        f"Verdict '{verdict}' contradicted by outcomes "
                        f"{len(contradicted)}/{len(pairs)} times "
                        f"({contradiction_rate:.0%} contradiction rate)"
                    ),
                    supporting_evidence=[d.action_id for d, _ in contradicted],
                    observation_count=len(contradicted),
                    significance_score=min(1.0, contradiction_rate),
                    first_observed=min(timestamps),
                    last_observed=max(timestamps),
                )
            )
        return patterns

    def analyze_dimension_drift(
        self,
        decisions: list[AuditRecord],
        outcomes: list[OutcomeRecord],
        window_days: int = 90,
    ) -> list[GovernancePattern]:
        """Find dimensions whose scores are inconsistent with actual outcomes.

        If a dimension consistently scores high but outcomes are negative
        (or vice-versa), flag it as drifting.
        """
        cutoff = time.time() - window_days * 86400

        outcome_by_action: dict[str, OutcomeRecord] = {}
        for o in outcomes:
            if o.timestamp >= cutoff:
                outcome_by_action[o.action_id] = o

        # Accumulate per-dimension stats: high score but bad outcome.
        dim_contradictions: dict[str, list[AuditRecord]] = {}
        dim_total: dict[str, int] = {}

        for dec in decisions:
            if dec.timestamp < cutoff:
                continue
            outcome = outcome_by_action.get(dec.action_id)
            if outcome is None:
                continue
            for ds in dec.dimension_scores:
                dim_name = ds.get("name", "")
                score = ds.get("score", 0.0)
                if not dim_name:
                    continue
                dim_total[dim_name] = dim_total.get(dim_name, 0) + 1
                # High score but outcome was overridden → dimension misjudged.
                if score >= 0.7 and outcome.override_occurred:
                    dim_contradictions.setdefault(dim_name, []).append(dec)

        patterns: list[GovernancePattern] = []
        for dim_name, records in dim_contradictions.items():
            total = dim_total.get(dim_name, 0)
            if len(records) < 3 or total == 0:
                continue
            drift_rate = len(records) / total
            if drift_rate < 0.2:
                continue
            timestamps = [r.timestamp for r in records]
            patterns.append(
                GovernancePattern(
                    pattern_id=uuid.uuid4().hex[:12],
                    pattern_type=PatternType.DIMENSION_DRIFT,
                    description=(
                        f"Dimension '{dim_name}' scored high but outcomes "
                        f"were negative {len(records)}/{total} times "
                        f"({drift_rate:.0%} mismatch rate)"
                    ),
                    supporting_evidence=[r.action_id for r in records],
                    observation_count=len(records),
                    significance_score=min(1.0, drift_rate * 2),
                    first_observed=min(timestamps),
                    last_observed=max(timestamps),
                )
            )
        return patterns


# ── Recommendation Engine ──────────────────────────────────────────────


class RecommendationEngine:
    """Generates specific configuration recommendations from patterns."""

    def generate(
        self, pattern: GovernancePattern, current_config: dict[str, Any]
    ) -> PolicyRecommendation | None:
        """Produce a recommendation for the given pattern, or None if not actionable."""
        if pattern.pattern_type == PatternType.EXCEPTION_CLUSTER:
            return self._recommend_for_exception_cluster(pattern, current_config)
        if pattern.pattern_type == PatternType.OUTCOME_CORRELATION:
            return self._recommend_for_outcome_correlation(pattern, current_config)
        if pattern.pattern_type == PatternType.DIMENSION_DRIFT:
            return self._recommend_for_dimension_drift(pattern, current_config)
        return None

    def _recommend_for_exception_cluster(
        self, pattern: GovernancePattern, current_config: dict[str, Any]
    ) -> PolicyRecommendation:
        return PolicyRecommendation(
            recommendation_id=uuid.uuid4().hex[:12],
            pattern_id=pattern.pattern_id,
            recommendation_text=(
                f"Consider updating policy to align with human override pattern: "
                f"{pattern.description}"
            ),
            proposed_change={"adjust_policy_for": pattern.description},
            projected_impact=(
                f"Reduce manual overrides by aligning system behavior with "
                f"{pattern.observation_count} observed human decisions"
            ),
        )

    def _recommend_for_outcome_correlation(
        self, pattern: GovernancePattern, current_config: dict[str, Any]
    ) -> PolicyRecommendation:
        return PolicyRecommendation(
            recommendation_id=uuid.uuid4().hex[:12],
            pattern_id=pattern.pattern_id,
            recommendation_text=(
                f"Recalibrate verdict thresholds: {pattern.description}"
            ),
            proposed_change={"recalibrate_verdict": pattern.description},
            projected_impact=(
                f"Improve verdict accuracy by addressing "
                f"{pattern.observation_count} contradicted outcomes"
            ),
        )

    def _recommend_for_dimension_drift(
        self, pattern: GovernancePattern, current_config: dict[str, Any]
    ) -> PolicyRecommendation:
        return PolicyRecommendation(
            recommendation_id=uuid.uuid4().hex[:12],
            pattern_id=pattern.pattern_id,
            recommendation_text=(
                f"Adjust dimension weight or scoring: {pattern.description}"
            ),
            proposed_change={"adjust_dimension": pattern.description},
            projected_impact=(
                f"Improve dimension accuracy by addressing "
                f"{pattern.observation_count} score-outcome mismatches"
            ),
        )


# ── Policy Evolution Engine ────────────────────────────────────────────


class PolicyEvolutionEngine:
    """Orchestrates pattern analysis and recommendation generation."""

    def __init__(
        self,
        audit_trail: AuditTrail,
        config: PolicyEvolutionConfig | None = None,
    ) -> None:
        self._audit_trail = audit_trail
        self._config = config or PolicyEvolutionConfig()
        self._analyzer = PatternAnalyzer()
        self._recommender = RecommendationEngine()
        self._patterns: list[GovernancePattern] = []
        self._recommendations: dict[str, PolicyRecommendation] = {}

    @property
    def patterns(self) -> list[GovernancePattern]:
        return list(self._patterns)

    def run_analysis(self) -> list[GovernancePattern]:
        """Run all pattern analyses and generate recommendations."""
        decisions = list(self._audit_trail.records)
        outcomes = list(self._audit_trail.outcome_records)
        accountability = list(self._audit_trail.accountability_records)
        window = self._config.window_days
        min_obs = self._config.min_cluster_size

        patterns: list[GovernancePattern] = []
        patterns.extend(
            self._analyzer.analyze_exception_clusters(
                decisions, accountability, window, min_obs
            )
        )
        patterns.extend(
            self._analyzer.analyze_outcome_correlations(
                decisions, outcomes, window
            )
        )
        patterns.extend(
            self._analyzer.analyze_dimension_drift(
                decisions, outcomes, window
            )
        )

        self._patterns = patterns

        # Generate recommendations for significant patterns.
        for p in patterns:
            if p.significance_score >= self._config.significance_threshold:
                rec = self._recommender.generate(p, {})
                if rec is not None:
                    self._recommendations[rec.recommendation_id] = rec

        return patterns

    def pending_recommendations(self) -> list[PolicyRecommendation]:
        """Return all recommendations with status 'pending'."""
        return [
            r for r in self._recommendations.values() if r.status == "pending"
        ]

    def get_recommendation(self, recommendation_id: str) -> PolicyRecommendation | None:
        """Look up a recommendation by ID."""
        return self._recommendations.get(recommendation_id)

    def approve_recommendation(
        self, recommendation_id: str, approved_by: str, note: str = ""
    ) -> None:
        """Mark a recommendation as approved."""
        rec = self._recommendations.get(recommendation_id)
        if rec is None:
            raise KeyError(f"Recommendation not found: {recommendation_id}")
        rec.status = "approved"
        rec.reviewed_by = approved_by
        rec.reviewed_at = time.time()
        rec.reviewer_note = note

    def reject_recommendation(
        self, recommendation_id: str, rejected_by: str, note: str = ""
    ) -> None:
        """Mark a recommendation as rejected and emit an accountability record."""
        rec = self._recommendations.get(recommendation_id)
        if rec is None:
            raise KeyError(f"Recommendation not found: {recommendation_id}")
        rec.status = "rejected"
        rec.reviewed_by = rejected_by
        rec.reviewed_at = time.time()
        rec.reviewer_note = note

        # Emit an accountability record for the rejection.
        acc = AccountabilityRecord(
            record_id=uuid.uuid4().hex[:12],
            action_id=rec.recommendation_id,
            human_id=rejected_by,
            human_action="recommendation_rejected",
            original_verdict="pending",
            resulting_verdict="rejected",
            stated_rationale=note or "No rationale provided",
            timestamp=time.time(),
        )
        self._audit_trail.append_accountability(acc)

    def apply_approved_recommendation(
        self, recommendation_id: str
    ) -> ChangeRecord:
        """Apply an approved recommendation, emitting audit records."""
        rec = self._recommendations.get(recommendation_id)
        if rec is None:
            raise KeyError(f"Recommendation not found: {recommendation_id}")
        if rec.status != "approved":
            raise ValueError(
                f"Recommendation {recommendation_id} is not approved "
                f"(status: {rec.status})"
            )

        now = time.time()

        # Find the originating pattern.
        pattern = None
        for p in self._patterns:
            if p.pattern_id == rec.pattern_id:
                pattern = p
                break

        # Emit UnwrittenPolicyAdjustmentRecord.
        adj = UnwrittenPolicyAdjustmentRecord(
            record_id=uuid.uuid4().hex[:12],
            pattern_description=pattern.description if pattern else rec.recommendation_text,
            evidence_action_ids=pattern.supporting_evidence if pattern else [],
            observation_count=pattern.observation_count if pattern else 0,
            positive_outcome_rate=pattern.significance_score if pattern else 0.0,
            proposed_policy_change=rec.recommendation_text,
            approved_by=rec.reviewed_by or "",
            approved_at=rec.reviewed_at or now,
            policy_change_applied=str(rec.proposed_change),
            timestamp=now,
        )
        self._audit_trail.append_policy_adjustment(adj)

        # Emit ChangeRecord.
        change = ChangeRecord(
            record_id=uuid.uuid4().hex[:12],
            changed_by=rec.reviewed_by or "system",
            change_type="policy_evolution",
            component="governance_config",
            before_state={},
            after_state=rec.proposed_change,
            source=f"policy_evolution:{rec.recommendation_id}",
            timestamp=now,
        )
        self._audit_trail.append_change(change)

        rec.status = "applied"
        return change
