"""Dimension Orchestration Engine — controls evaluation order, relevance filtering, and fast-exit.

Instead of evaluating all dimensions simultaneously, the orchestrator sequences
evaluation through four phases:

1. **Foundation dimensions** (pre-pass) — dimensions marked ``is_foundation=True``
   run first and populate ``foundation_context`` consumed by later dimensions.
2. **Veto-capable dimensions** — dimensions with ``can_veto=True`` run next.
   If any fires a veto the evaluation stops immediately (fast-gate).
3. **Remaining dimensions** in priority order — lower ``priority`` values run first.
4. **Early exit** — after each scored dimension the orchestrator checks whether
   enough signal has accumulated to make a confident decision, and stops early
   when the running weighted score is decisively above the allow threshold or
   below the deny threshold.

Dimensions that declare ``relevant_schema_fields`` are skipped (returning a
neutral score) when the action does not populate any of those fields.

Action-type routing re-orders dimensions so the most informative ones for a
given action type (delete, read, write, delegate) run first.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from nomotic.dimensions import GovernanceDimension
from nomotic.types import Action, AgentContext, DimensionScore

__all__ = [
    "ACTION_TYPE_ROUTING",
    "DimensionOrchestrator",
    "OrchestratorResult",
]

# Routing table: for each action type, the dimensions that should be evaluated
# first (in the listed order).  Dimensions not in the list run afterward in
# their default priority order.
ACTION_TYPE_ROUTING: dict[str, list[str]] = {
    "delete": [
        "scope_compliance",
        "authority_verification",
        "reversibility",
        "cascading_impact",
    ],
    "read": [
        "isolation_integrity",
        "data_sensitivity_classification",
        "scope_compliance",
    ],
    "write": [
        "scope_compliance",
        "authority_verification",
        "resource_boundaries",
    ],
    "delegate": [
        "delegation_chain_integrity",
        "authority_verification",
        "scope_compliance",
    ],
}

_NEUTRAL_SCORE = 0.5
_MIN_DIMENSIONS_BEFORE_EARLY_EXIT = 3
_CONFIDENCE_MARGIN = 0.15


@dataclass
class OrchestratorResult:
    """Result of an orchestrated dimension evaluation."""

    scores: list[DimensionScore] = field(default_factory=list)
    vetoed: bool = False
    veto_dimensions: list[str] = field(default_factory=list)
    escalation_required: bool = False
    escalation_required_by: list[str] = field(default_factory=list)
    dimensions_skipped: list[str] = field(default_factory=list)
    early_exit: bool = False
    foundation_context: dict[str, Any] = field(default_factory=dict)


class DimensionOrchestrator:
    """Controls dimension evaluation order, relevance filtering, and fast-exit."""

    def evaluate(
        self,
        action: Action,
        context: AgentContext,
        dimensions: list[GovernanceDimension],
        allow_threshold: float,
        deny_threshold: float,
    ) -> OrchestratorResult:
        """Evaluate dimensions in orchestrated order.

        Evaluation sequence:
        1. Run foundation dimensions (pre-pass) — populate shared context
        2. Run veto-capable dimensions — stop immediately if any veto fires
        3. Run remaining dimensions in priority order
        4. Early exit when enough dimensions have run for confident decision

        Returns all scores collected, veto status, and escalation_required flags.
        """
        result = OrchestratorResult()

        # Classify dimensions into buckets
        foundation: list[GovernanceDimension] = []
        veto_capable: list[GovernanceDimension] = []
        remaining: list[GovernanceDimension] = []

        for dim in dimensions:
            if getattr(dim, "is_foundation", False):
                foundation.append(dim)
            elif dim.can_veto:
                veto_capable.append(dim)
            else:
                remaining.append(dim)

        # Apply action-type routing to reorder veto_capable and remaining
        route_order = self._route_priority(action)
        if route_order:
            veto_capable = self._apply_route_order(veto_capable, route_order)
            remaining = self._apply_route_order(remaining, route_order)

        # Sort remaining by priority (lower = earlier)
        remaining.sort(key=lambda d: getattr(d, "priority", 50))

        # Separate Transparency dimension — it runs last and receives peer scores
        transparency_dim: GovernanceDimension | None = None
        non_transparency: list[GovernanceDimension] = []
        for dim in remaining:
            if dim.name == "transparency":
                transparency_dim = dim
            else:
                non_transparency.append(dim)

        # Phase 1: Foundation dimensions
        for dim in foundation:
            if not self._is_relevant(dim, action):
                result.dimensions_skipped.append(dim.name)
                result.scores.append(self._neutral_score(dim))
                continue
            score = dim.evaluate(action, context)
            result.scores.append(score)
            self._track_escalation(score, result)
            # Store foundation outputs in context
            if score.metadata:
                result.foundation_context[dim.name] = score.metadata

        # Phase 2: Veto-capable dimensions (fast-gate)
        for dim in veto_capable:
            if not self._is_relevant(dim, action):
                result.dimensions_skipped.append(dim.name)
                result.scores.append(self._neutral_score(dim))
                continue
            score = dim.evaluate(action, context)
            result.scores.append(score)
            self._track_escalation(score, result)
            if score.veto:
                result.vetoed = True
                result.veto_dimensions.append(dim.name)
                return result

        # Phase 3: Remaining dimensions (excluding Transparency) with early exit
        for i, dim in enumerate(non_transparency):
            if not self._is_relevant(dim, action):
                result.dimensions_skipped.append(dim.name)
                result.scores.append(self._neutral_score(dim))
                continue
            score = dim.evaluate(action, context)
            result.scores.append(score)
            self._track_escalation(score, result)

            # Check for early exit — account for unevaluated dimensions
            unevaluated = non_transparency[i + 1:]
            # Include transparency in unevaluated count if present
            unevaluated_all = list(unevaluated)
            if transparency_dim is not None:
                unevaluated_all.append(transparency_dim)
            if self._can_early_exit(
                result, allow_threshold, deny_threshold, unevaluated_all
            ):
                result.early_exit = True
                # Pad remaining dimensions with neutral scores
                for remaining_dim in unevaluated_all:
                    if remaining_dim.name not in {s.dimension_name for s in result.scores}:
                        result.scores.append(self._neutral_score(remaining_dim))
                        result.dimensions_skipped.append(remaining_dim.name)
                return result

        # Phase 4: Transparency dimension — runs last with peer scores
        if transparency_dim is not None:
            if not self._is_relevant(transparency_dim, action):
                result.dimensions_skipped.append(transparency_dim.name)
                result.scores.append(self._neutral_score(transparency_dim))
            else:
                peer_scores = list(result.scores)  # all scores collected so far
                score = transparency_dim.evaluate(action, context, peer_scores=peer_scores)
                result.scores.append(score)
                self._track_escalation(score, result)

        return result

    def _is_relevant(self, dimension: GovernanceDimension, action: Action) -> bool:
        """Check dimension's relevance declarations against action schema fields."""
        relevant_fields = getattr(dimension, "relevant_schema_fields", [])
        if not relevant_fields:
            return True  # empty = always relevant
        for field_name in relevant_fields:
            value = getattr(action, field_name, None)
            if value is not None:
                return True
        return False

    def _route_priority(self, action: Action) -> list[str]:
        """Return ordered list of dimension names for this action's type."""
        return ACTION_TYPE_ROUTING.get(action.action_type, [])

    def _apply_route_order(
        self,
        dims: list[GovernanceDimension],
        route_order: list[str],
    ) -> list[GovernanceDimension]:
        """Reorder dimensions so those in route_order come first (in that order)."""
        by_name = {d.name: d for d in dims}
        ordered: list[GovernanceDimension] = []
        seen: set[str] = set()

        for name in route_order:
            if name in by_name:
                ordered.append(by_name[name])
                seen.add(name)

        for dim in dims:
            if dim.name not in seen:
                ordered.append(dim)

        return ordered

    def _neutral_score(self, dimension: GovernanceDimension) -> DimensionScore:
        """Return a neutral score for a skipped dimension."""
        return DimensionScore(
            dimension_name=dimension.name,
            score=_NEUTRAL_SCORE,
            weight=dimension.weight,
            reasoning="Dimension not relevant to this action; neutral score",
        )

    def _track_escalation(
        self, score: DimensionScore, result: OrchestratorResult
    ) -> None:
        """Track escalation flags from dimension scores.

        Escalation may be signalled via the ``DimensionResult`` attached to the
        score (``score.result.escalation_required``) or via score metadata
        (``score.metadata.get("escalation_required")``).
        """
        escalation = False
        if score.result is not None and getattr(score.result, "escalation_required", False):
            escalation = True
        if score.metadata.get("escalation_required"):
            escalation = True
        if escalation:
            result.escalation_required = True
            result.escalation_required_by.append(score.dimension_name)

    def _can_early_exit(
        self,
        result: OrchestratorResult,
        allow_threshold: float,
        deny_threshold: float,
        unevaluated: list[GovernanceDimension] | None = None,
    ) -> bool:
        """Check if we have enough signal for a confident decision.

        Requires at least ``_MIN_DIMENSIONS_BEFORE_EARLY_EXIT`` non-skipped
        scores.  Then checks whether the running weighted average — including
        unevaluated dimensions assumed to score neutrally (0.5) with their
        actual weights — is decisively above the allow threshold or below the
        deny threshold (by ``_CONFIDENCE_MARGIN``).

        Including unevaluated dimensions as neutral prevents premature exit
        when heavy-weight dimensions have already scored low/high and the
        remaining dimensions would shift the average.
        """
        evaluated_scores = [
            s for s in result.scores
            if s.dimension_name not in result.dimensions_skipped
        ]
        if len(evaluated_scores) < _MIN_DIMENSIONS_BEFORE_EARLY_EXIT:
            return False

        total_weight = sum(s.weight for s in evaluated_scores)
        weighted_sum = sum(s.score * s.weight for s in evaluated_scores)

        # Assume unevaluated dimensions score neutrally with their actual weights
        if unevaluated:
            for dim in unevaluated:
                dim_weight = dim.weight
                total_weight += dim_weight
                weighted_sum += _NEUTRAL_SCORE * dim_weight

        if total_weight == 0:
            return False

        weighted_avg = weighted_sum / total_weight

        if weighted_avg >= allow_threshold + _CONFIDENCE_MARGIN:
            return True
        if weighted_avg <= deny_threshold - _CONFIDENCE_MARGIN:
            return True

        return False
