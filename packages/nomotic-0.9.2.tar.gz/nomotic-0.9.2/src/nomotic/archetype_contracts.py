"""Opinionated behavioral contracts shipped with every built-in archetype.

When a developer runs ``nomotic certify --archetype=travel-booking``, this
contract activates automatically. No manual configuration required.

Contracts define:
- authorized_action_categories: what semantic action types this agent may perform
- constraints: quantitative policy limits (budget, hours, quantities, etc.)
- human_override_actions: action types that always require human approval
- scope_deny_categories: action categories that are hard-blocked for this archetype
- compliance_preset: which compliance preset applies by default
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "ACTION_CATEGORY_PATTERNS",
    "ARCHETYPE_CONTRACTS",
    "ArchetypeContract",
    "classify_action_category",
    "get_contract",
]


@dataclass
class ArchetypeContract:
    """Policy contract for a built-in archetype.

    Loaded automatically at runtime init when an agent's birth certificate
    carries an archetype name. Applied by ScopeCompliance and
    TemporalCompliance dimensions before any custom configuration.
    """

    archetype_name: str

    # Semantic action categories this agent is authorized to perform.
    # Maps category -> "allow" | "escalate" | "deny"
    authorized_action_categories: dict[str, str] = field(default_factory=dict)

    # Hard-blocked categories. Any request mapping here is DENY regardless
    # of trust or other dimensions.
    scope_deny_categories: list[str] = field(default_factory=list)

    # Action types requiring human approval regardless of trust score.
    human_override_actions: list[str] = field(default_factory=list)

    # Quantitative constraints checked by dimension evaluators.
    constraints: dict[str, Any] = field(default_factory=dict)

    # Default compliance preset name for this archetype.
    compliance_preset: str = "standard"

    # Whether this agent is expected to handle freeform natural language.
    # True = chatbot/conversational. False = structured input only.
    conversational: bool = False

    def is_authorized(self, action_category: str) -> str:
        """Return 'allow', 'escalate', or 'deny' for an action category."""
        if action_category in self.scope_deny_categories:
            return "deny"
        return self.authorized_action_categories.get(action_category, "allow")

    def get_constraint(self, key: str, default: Any = None) -> Any:
        return self.constraints.get(key, default)


# ---------------------------------------------------------------------------
# Contracts for all 30 built-in archetypes
# ---------------------------------------------------------------------------

ARCHETYPE_CONTRACTS: dict[str, ArchetypeContract] = {
    # ── Customer-facing ───────────────────────────────────────────────
    "customer-experience": ArchetypeContract(
        archetype_name="customer-experience",
        conversational=True,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "account_query": "allow",
            "information_request": "allow",
            "appointment_booking": "allow",
            "complaint_filing": "allow",
            "refund_request": "escalate",
            "financial_transaction": "escalate",
            "data_export": "escalate",
            "document_writing": "allow",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "system_administration",
            "data_bulk_export",
        ],
        human_override_actions=["bulk_export", "financial_transaction_above_threshold"],
        constraints={
            "transaction_escalate_above": 5000,
            "max_discount_pct": 20,
            "authorized_hours": ("00:00", "23:59"),
        },
    ),
    "sales-assistant": ArchetypeContract(
        archetype_name="sales-assistant",
        conversational=True,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "lead_qualification": "allow",
            "information_request": "allow",
            "send_email": "allow",
            "schedule_demo": "allow",
            "generate_quote": "allow",
            "discount_offer": "escalate",
            "contract_signing": "escalate",
            "data_export": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "system_administration",
            "data_bulk_export",
            "financial_transaction",
        ],
        human_override_actions=["discount_above_threshold", "contract_signing"],
        constraints={
            "max_discount_pct": 15,
            "quote_valid_days": 30,
            "authorized_hours": ("08:00", "20:00"),
        },
    ),
    "customer-onboarding": ArchetypeContract(
        archetype_name="customer-onboarding",
        conversational=True,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "account_setup": "allow",
            "product_activation": "allow",
            "send_welcome": "allow",
            "schedule_training": "allow",
            "information_request": "allow",
            "configuration_change": "escalate",
            "billing_setup": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "system_administration",
            "data_bulk_export",
        ],
        human_override_actions=["billing_setup", "enterprise_activation"],
        constraints={
            "authorized_hours": ("08:00", "20:00"),
            "max_onboarding_days": 30,
        },
    ),

    # ── Travel and bookings ───────────────────────────────────────────
    "travel-booking": ArchetypeContract(
        archetype_name="travel-booking",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "book_flight": "allow",
            "book_hotel": "allow",
            "book_car_rental": "allow",
            "book_ride_share": "allow",
            "book_train": "allow",
            "cancel_booking": "escalate",
            "modify_booking": "allow",
            "expense_report": "allow",
        },
        scope_deny_categories=[
            "first_class_upgrade",
            "personal_account_charge",
            "creative_content",
            "financial_transaction",
        ],
        human_override_actions=["cancel_booking", "book_above_budget"],
        constraints={
            "hotel_rate_cap_usd": 250,
            "flight_class": "economy",
            "flight_class_escalate": "business",
            "flight_class_deny": "first",
            "authorized_days": ["mon", "tue", "wed", "thu", "fri"],
            "no_weekend_bookings": True,
            "car_preferred_over_rideshare_days": 2,
            "budget_ceiling_per_trip": 3000,
            "requires_approval_above": 1500,
        },
    ),

    # ── Order processing ──────────────────────────────────────────────
    "order-processing": ArchetypeContract(
        archetype_name="order-processing",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "place_order": "allow",
            "cancel_order": "escalate",
            "modify_order": "escalate",
            "check_inventory": "allow",
            "request_quote": "allow",
            "approve_purchase": "escalate",
        },
        scope_deny_categories=["creative_content", "financial_transaction", "data_export"],
        human_override_actions=["cancel_order", "order_above_threshold", "bulk_order"],
        constraints={
            "order_escalate_above_usd": 10000,
            "quantity_anomaly_multiplier": 10,
            "requires_po_above": 5000,
            "max_single_order_usd": 50000,
            "authorized_vendors_only": True,
        },
    ),

    # ── Scheduling ────────────────────────────────────────────────────
    "scheduling": ArchetypeContract(
        archetype_name="scheduling",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "book_meeting": "allow",
            "cancel_meeting": "allow",
            "reschedule_meeting": "allow",
            "book_resource": "allow",
            "send_invite": "allow",
            "book_on_behalf": "escalate",
        },
        scope_deny_categories=["creative_content", "financial_transaction", "data_export"],
        human_override_actions=["book_on_behalf_executive", "block_calendar_extended"],
        constraints={
            "authorized_hours": ("08:00", "18:00"),
            "authorized_days": ["mon", "tue", "wed", "thu", "fri"],
            "no_weekend_scheduling": True,
            "max_meeting_duration_hrs": 4,
            "advance_booking_days": 90,
            "no_double_booking": True,
        },
    ),

    # ── HR ────────────────────────────────────────────────────────────
    "hr-operations": ArchetypeContract(
        archetype_name="hr-operations",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "post_job_listing": "allow",
            "screen_resume": "allow",
            "schedule_interview": "allow",
            "send_offer": "escalate",
            "onboard_employee": "allow",
            "process_leave": "allow",
            "terminate_employee": "escalate",
            "access_personnel_record": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "financial_transaction",
            "off_domain_personal",
            "data_bulk_export",
        ],
        human_override_actions=["terminate_employee", "send_offer", "salary_change"],
        constraints={
            "authorized_hours": ("08:00", "18:00"),
            "authorized_days": ["mon", "tue", "wed", "thu", "fri"],
            "pii_access_requires_purpose": True,
            "audit_every_access": True,
        },
    ),

    # ── IT ────────────────────────────────────────────────────────────
    "it-helpdesk": ArchetypeContract(
        archetype_name="it-helpdesk",
        conversational=True,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "create_ticket": "allow",
            "update_ticket": "allow",
            "resolve_ticket": "allow",
            "route_ticket": "allow",
            "reset_password": "escalate",
            "grant_access": "escalate",
            "revoke_access": "escalate",
            "install_software": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "financial_transaction",
            "data_bulk_export",
        ],
        human_override_actions=["grant_admin_access", "revoke_access", "deploy_change"],
        constraints={
            "authorized_hours": ("07:00", "22:00"),
            "max_access_level": "standard",
            "admin_access_requires_approval": True,
        },
    ),

    # ── Legal ─────────────────────────────────────────────────────────
    "legal-research": ArchetypeContract(
        archetype_name="legal-research",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "search_case_law": "allow",
            "document_review": "allow",
            "generate_summary": "allow",
            "legal_analysis": "allow",
            "draft_brief": "allow",
            "file_document": "escalate",
            "client_communication": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "financial_transaction",
            "system_administration",
        ],
        human_override_actions=["file_document", "client_communication", "legal_advice"],
        constraints={
            "authorized_hours": ("08:00", "20:00"),
            "privilege_check_required": True,
            "no_cross_matter_queries": True,
        },
    ),
    "contract-management": ArchetypeContract(
        archetype_name="contract-management",
        conversational=False,
        compliance_preset="sox_aligned",
        authorized_action_categories={
            "draft_contract": "allow",
            "review_contract": "allow",
            "redline_contract": "allow",
            "track_milestone": "allow",
            "send_for_signature": "escalate",
            "execute_contract": "escalate",
            "terminate_contract": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "financial_transaction",
            "system_administration",
        ],
        human_override_actions=["execute_contract", "terminate_contract", "amend_terms"],
        constraints={
            "authorized_hours": ("08:00", "18:00"),
            "authorized_days": ["mon", "tue", "wed", "thu", "fri"],
            "value_escalate_above_usd": 50000,
            "requires_legal_review_above_usd": 25000,
        },
    ),

    # ── Finance ───────────────────────────────────────────────────────
    "financial-transactions": ArchetypeContract(
        archetype_name="financial-transactions",
        conversational=False,
        compliance_preset="pci_dss_aligned",
        authorized_action_categories={
            "account_query": "allow",
            "domestic_transfer": "allow",
            "international_transfer": "escalate",
            "payment_processing": "allow",
            "credit_adjustment": "escalate",
            "bulk_payment": "escalate",
            "data_export": "escalate",
            "document_writing": "allow",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "data_bulk_export",
            "system_administration",
        ],
        human_override_actions=[
            "international_transfer",
            "bulk_payment",
            "credit_limit_change",
            "export_customer_data",
        ],
        constraints={
            "domestic_transfer_limit_usd": 10000,
            "transfer_escalate_above_usd": 5000,
            "international_always_escalate": True,
            "authorized_hours": ("09:00", "17:00"),
            "authorized_days": ["mon", "tue", "wed", "thu", "fri"],
            "max_daily_transaction_volume_usd": 100000,
        },
    ),
    "expense-management": ArchetypeContract(
        archetype_name="expense-management",
        conversational=False,
        compliance_preset="sox_aligned",
        authorized_action_categories={
            "submit_expense": "allow",
            "approve_expense": "escalate",
            "reject_expense": "allow",
            "request_reimbursement": "allow",
            "generate_report": "allow",
            "flag_policy_violation": "allow",
        },
        scope_deny_categories=[
            "bulk_payment",
            "creative_content",
            "data_bulk_export",
        ],
        human_override_actions=["approve_above_threshold", "approve_for_executive"],
        constraints={
            "auto_approve_below_usd": 75,
            "manager_approve_below_usd": 500,
            "vp_approve_below_usd": 2000,
            "requires_receipt_above_usd": 25,
            "per_diem_max_usd": 150,
            "hotel_rate_max_usd": 250,
            "no_personal_expenses": True,
            "no_alcohol_without_approval": True,
        },
    ),
    "accounts-payable": ArchetypeContract(
        archetype_name="accounts-payable",
        conversational=False,
        compliance_preset="sox_aligned",
        authorized_action_categories={
            "process_invoice": "allow",
            "match_po": "allow",
            "schedule_payment": "allow",
            "approve_payment": "escalate",
            "vendor_query": "allow",
            "generate_report": "allow",
            "void_payment": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "data_bulk_export",
            "system_administration",
        ],
        human_override_actions=["approve_above_threshold", "void_payment", "new_vendor_setup"],
        constraints={
            "auto_approve_below_usd": 500,
            "requires_dual_approval_above_usd": 10000,
            "payment_frequency_max_per_vendor_per_day": 3,
            "authorized_hours": ("08:00", "18:00"),
            "authorized_days": ["mon", "tue", "wed", "thu", "fri"],
        },
    ),
    "underwriting": ArchetypeContract(
        archetype_name="underwriting",
        conversational=False,
        compliance_preset="sox_aligned",
        authorized_action_categories={
            "risk_assessment": "allow",
            "policy_evaluation": "allow",
            "premium_calculation": "allow",
            "approve_standard": "allow",
            "approve_exception": "escalate",
            "decline_application": "escalate",
            "generate_report": "allow",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "financial_transaction",
            "system_administration",
        ],
        human_override_actions=["approve_exception", "override_risk_score", "bulk_approval"],
        constraints={
            "auto_approve_score_above": 750,
            "escalate_score_below": 600,
            "max_single_policy_value_usd": 1000000,
            "authorized_hours": ("08:00", "18:00"),
            "authorized_days": ["mon", "tue", "wed", "thu", "fri"],
        },
    ),

    # ── Healthcare ────────────────────────────────────────────────────
    "clinical-support": ArchetypeContract(
        archetype_name="clinical-support",
        conversational=True,
        compliance_preset="hipaa_aligned",
        authorized_action_categories={
            "patient_query": "allow",
            "schedule_appointment": "allow",
            "access_patient_record": "allow",
            "update_medication": "escalate",
            "generate_summary": "allow",
            "order_test": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "financial_transaction",
            "bulk_export",
            "off_domain_personal",
        ],
        human_override_actions=["update_medication", "order_procedure", "bulk_export"],
        constraints={
            "phi_access_requires_purpose": True,
            "audit_every_access": True,
            "no_cross_patient_queries": True,
            "authorized_hours": ("07:00", "19:00"),
        },
    ),
    "patient-intake": ArchetypeContract(
        archetype_name="patient-intake",
        conversational=True,
        compliance_preset="hipaa_aligned",
        authorized_action_categories={
            "register_patient": "allow",
            "schedule_appointment": "allow",
            "collect_insurance": "allow",
            "verify_identity": "allow",
            "update_demographics": "allow",
            "access_medical_history": "escalate",
            "assign_provider": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "financial_transaction",
            "off_domain_personal",
            "data_bulk_export",
        ],
        human_override_actions=["override_insurance", "assign_provider", "bulk_registration"],
        constraints={
            "phi_access_requires_purpose": True,
            "audit_every_access": True,
            "authorized_hours": ("06:00", "22:00"),
        },
    ),
    "clinical-documentation": ArchetypeContract(
        archetype_name="clinical-documentation",
        conversational=False,
        compliance_preset="hipaa_aligned",
        authorized_action_categories={
            "generate_note": "allow",
            "code_diagnosis": "allow",
            "update_ehr": "escalate",
            "generate_summary": "allow",
            "transcribe_encounter": "allow",
            "amend_record": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "financial_transaction",
            "off_domain_personal",
            "data_bulk_export",
        ],
        human_override_actions=["amend_record", "override_coding", "bulk_update"],
        constraints={
            "phi_access_requires_purpose": True,
            "audit_every_access": True,
            "no_cross_patient_queries": True,
            "authorized_hours": ("06:00", "22:00"),
            "requires_provider_cosign": True,
        },
    ),

    # ── Data and analytics ────────────────────────────────────────────
    "data-processing": ArchetypeContract(
        archetype_name="data-processing",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "read_data": "allow",
            "transform_data": "allow",
            "write_data": "allow",
            "schedule_pipeline": "allow",
            "delete_data": "escalate",
            "export_data": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "financial_transaction",
            "system_administration",
        ],
        human_override_actions=["delete_data", "export_pii", "schema_migration"],
        constraints={
            "max_row_write_per_batch": 1000000,
            "pii_requires_masking": True,
            "authorized_hours": ("00:00", "23:59"),
        },
    ),
    "analytics": ArchetypeContract(
        archetype_name="analytics",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "run_query": "allow",
            "generate_report": "allow",
            "create_dashboard": "allow",
            "export_report": "allow",
            "access_raw_data": "escalate",
            "share_externally": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "financial_transaction",
            "system_administration",
            "data_bulk_export",
        ],
        human_override_actions=["share_externally", "access_pii_data", "cross_org_query"],
        constraints={
            "query_timeout_seconds": 300,
            "max_export_rows": 100000,
            "pii_requires_aggregation": True,
            "authorized_hours": ("06:00", "22:00"),
        },
    ),

    # ── Operations ────────────────────────────────────────────────────
    "system-administration": ArchetypeContract(
        archetype_name="system-administration",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "monitor_system": "allow",
            "restart_service": "escalate",
            "deploy_change": "escalate",
            "update_config": "escalate",
            "grant_access": "escalate",
            "backup_data": "allow",
            "view_logs": "allow",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "financial_transaction",
        ],
        human_override_actions=[
            "production_deploy",
            "grant_admin_access",
            "delete_resource",
            "modify_firewall",
        ],
        constraints={
            "change_window_hours": ("02:00", "06:00"),
            "authorized_days": ["mon", "tue", "wed", "thu", "fri"],
            "requires_change_ticket": True,
            "max_concurrent_deploys": 1,
        },
    ),
    "workflow-orchestration": ArchetypeContract(
        archetype_name="workflow-orchestration",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "trigger_workflow": "allow",
            "pause_workflow": "allow",
            "resume_workflow": "allow",
            "cancel_workflow": "escalate",
            "modify_workflow": "escalate",
            "route_task": "allow",
            "escalate_task": "allow",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "financial_transaction",
            "data_bulk_export",
        ],
        human_override_actions=["cancel_workflow", "modify_production_workflow", "bulk_trigger"],
        constraints={
            "max_concurrent_workflows": 50,
            "max_workflow_duration_hours": 72,
            "authorized_hours": ("00:00", "23:59"),
        },
    ),
    "supply-chain": ArchetypeContract(
        archetype_name="supply-chain",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "track_shipment": "allow",
            "update_inventory": "allow",
            "create_po": "escalate",
            "approve_po": "escalate",
            "route_shipment": "allow",
            "request_quote": "allow",
            "flag_disruption": "allow",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "data_bulk_export",
        ],
        human_override_actions=["approve_po_above_threshold", "change_supplier", "bulk_order"],
        constraints={
            "po_escalate_above_usd": 25000,
            "max_single_po_usd": 100000,
            "authorized_vendors_only": True,
            "authorized_hours": ("06:00", "22:00"),
        },
    ),
    "facilities-management": ArchetypeContract(
        archetype_name="facilities-management",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "book_space": "allow",
            "submit_maintenance": "allow",
            "track_request": "allow",
            "approve_request": "escalate",
            "manage_access_card": "escalate",
            "schedule_cleaning": "allow",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "financial_transaction",
            "data_bulk_export",
        ],
        human_override_actions=["manage_access_card", "emergency_maintenance", "budget_override"],
        constraints={
            "authorized_hours": ("06:00", "22:00"),
            "maintenance_escalate_above_usd": 5000,
            "advance_booking_days": 60,
        },
    ),

    # ── Content ───────────────────────────────────────────────────────
    "content-generation": ArchetypeContract(
        archetype_name="content-generation",
        conversational=True,
        compliance_preset="standard",
        authorized_action_categories={
            "create_content": "allow",
            "edit_content": "allow",
            "publish_draft": "allow",
            "publish_final": "escalate",
            "translate_content": "allow",
            "generate_media": "allow",
        },
        scope_deny_categories=[
            "financial_transaction",
            "system_administration",
            "data_bulk_export",
        ],
        human_override_actions=["publish_final", "external_distribution", "brand_content"],
        constraints={
            "max_content_length_words": 10000,
            "requires_review_before_publish": True,
            "authorized_hours": ("00:00", "23:59"),
        },
    ),
    "content-moderation": ArchetypeContract(
        archetype_name="content-moderation",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "review_content": "allow",
            "flag_content": "allow",
            "remove_content": "escalate",
            "approve_content": "allow",
            "escalate_content": "allow",
            "ban_user": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "financial_transaction",
            "system_administration",
        ],
        human_override_actions=["ban_user", "remove_legal_content", "bulk_moderation"],
        constraints={
            "authorized_hours": ("00:00", "23:59"),
            "auto_remove_confidence_threshold": 0.95,
            "escalation_sla_minutes": 30,
        },
    ),

    # ── Security and compliance ───────────────────────────────────────
    "security-monitoring": ArchetypeContract(
        archetype_name="security-monitoring",
        conversational=False,
        compliance_preset="soc2_aligned",
        authorized_action_categories={
            "monitor_events": "allow",
            "detect_threat": "allow",
            "create_alert": "allow",
            "isolate_system": "escalate",
            "block_ip": "escalate",
            "investigate_incident": "allow",
            "generate_report": "allow",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "financial_transaction",
        ],
        human_override_actions=["isolate_production", "block_ip_range", "revoke_credentials"],
        constraints={
            "authorized_hours": ("00:00", "23:59"),
            "alert_sla_minutes": 15,
            "requires_incident_ticket": True,
        },
    ),
    "compliance-audit": ArchetypeContract(
        archetype_name="compliance-audit",
        conversational=False,
        compliance_preset="sox_aligned",
        authorized_action_categories={
            "run_audit": "allow",
            "generate_report": "allow",
            "check_compliance": "allow",
            "flag_violation": "allow",
            "request_remediation": "allow",
            "enforce_policy": "escalate",
            "grant_exception": "escalate",
        },
        scope_deny_categories=[
            "creative_content",
            "off_domain_personal",
            "financial_transaction",
            "system_administration",
        ],
        human_override_actions=["grant_exception", "modify_policy", "waive_requirement"],
        constraints={
            "authorized_hours": ("08:00", "18:00"),
            "authorized_days": ["mon", "tue", "wed", "thu", "fri"],
            "audit_trail_required": True,
        },
    ),

    # ── Research ──────────────────────────────────────────────────────
    "research-assistant": ArchetypeContract(
        archetype_name="research-assistant",
        conversational=True,
        compliance_preset="standard",
        authorized_action_categories={
            "search_literature": "allow",
            "summarize_paper": "allow",
            "generate_report": "allow",
            "data_analysis": "allow",
            "information_request": "allow",
            "access_database": "allow",
            "share_externally": "escalate",
        },
        scope_deny_categories=[
            "financial_transaction",
            "system_administration",
            "data_bulk_export",
        ],
        human_override_actions=["share_externally", "access_restricted_data", "publish_findings"],
        constraints={
            "authorized_hours": ("00:00", "23:59"),
            "max_query_cost_usd": 50,
        },
    ),
    "tutoring": ArchetypeContract(
        archetype_name="tutoring",
        conversational=True,
        compliance_preset="ferpa_aligned",
        authorized_action_categories={
            "answer_question": "allow",
            "generate_exercise": "allow",
            "assess_response": "allow",
            "track_progress": "allow",
            "recommend_resource": "allow",
            "access_student_record": "escalate",
            "modify_curriculum": "escalate",
        },
        scope_deny_categories=[
            "financial_transaction",
            "system_administration",
            "data_bulk_export",
            "off_domain_personal",
        ],
        human_override_actions=["access_student_record", "modify_grade", "contact_parent"],
        constraints={
            "authorized_hours": ("06:00", "22:00"),
            "student_data_requires_consent": True,
            "no_cross_student_data": True,
        },
    ),

    # ── General ───────────────────────────────────────────────────────
    "general-purpose": ArchetypeContract(
        archetype_name="general-purpose",
        conversational=True,
        compliance_preset="standard",
        authorized_action_categories={
            "information_request": "allow",
            "document_writing": "allow",
            "data_query": "allow",
        },
        scope_deny_categories=[
            "system_administration",
            "data_bulk_export",
        ],
        human_override_actions=["financial_transaction", "data_export", "access_pii"],
        constraints={
            "authorized_hours": ("00:00", "23:59"),
        },
    ),
}


# ---------------------------------------------------------------------------
# Action category classification
# ---------------------------------------------------------------------------

ACTION_CATEGORY_PATTERNS: dict[str, list[str]] = {
    "creative_content": [
        "poem", "haiku", "story", "joke", "song", "essay",
        "write a poem", "write me a",
    ],
    "off_domain_personal": [
        "pizza", "recipe", "weather", "sports", "news",
        "cook", "how do i make",
    ],
    "financial_transaction": [
        "transfer", "send money", "wire", "payment", "pay",
    ],
    "data_bulk_export": [
        "export all", "download all", "bulk export",
        "all records", "everything",
    ],
    "data_export": ["export", "download", "send records"],
    "account_query": [
        "balance", "statement", "account info", "my account",
    ],
    "document_writing": [
        "write a contract", "write a check", "write a letter", "draft",
    ],
    "booking": ["book", "reserve", "schedule", "appointment"],
    "order": ["order", "purchase", "buy", "request"],
    "system_administration": [
        "deploy", "restart", "shutdown", "delete all", "drop table",
    ],
}


def classify_action_category(text: str) -> str:
    """Map freeform text to a semantic action category.

    Used by ScopeCompliance to evaluate freeform requests against
    archetype contracts without relying on keyword tool detection.

    Returns the most specific matching category, or 'general_request'
    if no pattern matches.
    """
    text_lower = text.lower()
    for category, patterns in ACTION_CATEGORY_PATTERNS.items():
        if any(p in text_lower for p in patterns):
            return category
    return "general_request"


def get_contract(archetype_name: str) -> ArchetypeContract | None:
    """Look up the built-in contract for an archetype name."""
    return ARCHETYPE_CONTRACTS.get(archetype_name)
