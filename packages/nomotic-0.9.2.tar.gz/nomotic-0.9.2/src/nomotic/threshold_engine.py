"""Dynamic threshold derivation — computing optimal decision boundaries from cost profiles.

The threshold engine sits between the CostProfile and the governance pipeline.
It derives per-evaluation allow/deny thresholds, applies smoothing to prevent
threshold oscillation, and provides threshold history for auditability.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any

from nomotic.cost_profile import CostProfile

__all__ = ["DerivedThresholds", "ThresholdEngine"]


@dataclass
class DerivedThresholds:
    """Result of threshold derivation for one evaluation."""

    allow_threshold: float
    deny_threshold: float
    ambiguity_zone_width: float
    source: str  # "cost_profile", "static_default", "smoothed"
    cost_profile_summary: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict for provenance / audit."""
        return {
            "allow_threshold": self.allow_threshold,
            "deny_threshold": self.deny_threshold,
            "ambiguity_zone_width": self.ambiguity_zone_width,
            "source": self.source,
            "cost_profile_summary": dict(self.cost_profile_summary),
        }


class ThresholdEngine:
    """Derives dynamic thresholds from CostProfiles with smoothing.

    Smoothing prevents threshold oscillation: thresholds cannot shift
    more than max_shift_per_cycle from their previous values.
    """

    def __init__(
        self,
        default_allow: float = 0.7,
        default_deny: float = 0.3,
        max_shift_per_cycle: float = 0.10,
        min_allow: float = 0.15,
        max_allow: float = 0.95,
        min_deny: float = 0.05,
        max_deny: float = 0.85,
    ) -> None:
        self._default_allow = default_allow
        self._default_deny = default_deny
        self._max_shift = max_shift_per_cycle
        self._min_allow = min_allow
        self._max_allow = max_allow
        self._min_deny = min_deny
        self._max_deny = max_deny
        self._previous: dict[str, DerivedThresholds] = {}
        self._lock = threading.Lock()

    def derive(
        self, agent_id: str, cost_profile: CostProfile | None = None
    ) -> DerivedThresholds:
        """Derive thresholds for an evaluation.

        1. If no cost_profile, return static defaults with source="static_default".
        2. Compute raw thresholds from the cost profile.
        3. Clamp to configured bounds.
        4. Apply smoothing against previous thresholds for this agent.
        5. Store as previous for next cycle and return.
        """
        if cost_profile is None:
            result = DerivedThresholds(
                allow_threshold=self._default_allow,
                deny_threshold=self._default_deny,
                ambiguity_zone_width=self._default_allow - self._default_deny,
                source="static_default",
                cost_profile_summary={},
            )
            with self._lock:
                self._previous[agent_id] = result
            return result

        # Compute raw thresholds from cost profile
        raw_allow = cost_profile.optimal_allow_threshold()
        raw_deny = cost_profile.optimal_deny_threshold()

        # Clamp to configured bounds
        raw_allow = max(self._min_allow, min(self._max_allow, raw_allow))
        raw_deny = max(self._min_deny, min(self._max_deny, raw_deny))

        # Ensure allow > deny
        if raw_allow <= raw_deny:
            raw_allow = raw_deny + 0.05

        summary: dict[str, float] = {
            "false_allow": cost_profile.effective_false_allow(),
            "false_deny": cost_profile.effective_false_deny(),
            "zone_multiplier": cost_profile.zone_multiplier,
        }

        # Apply smoothing
        with self._lock:
            prev = self._previous.get(agent_id)

        if prev is not None and prev.source != "static_default":
            smoothed_allow = self._smooth(prev.allow_threshold, raw_allow)
            smoothed_deny = self._smooth(prev.deny_threshold, raw_deny)
            # Re-clamp after smoothing
            smoothed_allow = max(self._min_allow, min(self._max_allow, smoothed_allow))
            smoothed_deny = max(self._min_deny, min(self._max_deny, smoothed_deny))
            if smoothed_allow <= smoothed_deny:
                smoothed_allow = smoothed_deny + 0.05
            source = "smoothed" if (smoothed_allow != raw_allow or smoothed_deny != raw_deny) else "cost_profile"
            result = DerivedThresholds(
                allow_threshold=smoothed_allow,
                deny_threshold=smoothed_deny,
                ambiguity_zone_width=smoothed_allow - smoothed_deny,
                source=source,
                cost_profile_summary=summary,
            )
        else:
            result = DerivedThresholds(
                allow_threshold=raw_allow,
                deny_threshold=raw_deny,
                ambiguity_zone_width=raw_allow - raw_deny,
                source="cost_profile",
                cost_profile_summary=summary,
            )

        with self._lock:
            self._previous[agent_id] = result
        return result

    def _smooth(self, previous: float, target: float) -> float:
        """Clamp the change from previous to target within ±max_shift."""
        delta = target - previous
        if abs(delta) <= self._max_shift:
            return target
        return previous + self._max_shift * (1.0 if delta > 0 else -1.0)

    def get_previous(self, agent_id: str) -> DerivedThresholds | None:
        """Get the last derived thresholds for an agent."""
        with self._lock:
            return self._previous.get(agent_id)

    def reset(self, agent_id: str) -> None:
        """Clear stored thresholds for an agent."""
        with self._lock:
            self._previous.pop(agent_id, None)
