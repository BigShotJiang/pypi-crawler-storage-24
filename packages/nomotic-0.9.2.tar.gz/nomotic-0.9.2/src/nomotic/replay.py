"""Counterfactual behavioral replay — what would have happened if?

Transforms audit trails from static records into an interactive behavioral
forensics tool.  Replay any agent's history against alternative contracts,
invariants, thresholds, or governance configurations to understand what
different rules would have done.

Usage::

    from nomotic.replay import BehavioralReplayEngine, ReplayConfig
    from nomotic.audit_store import AuditStore

    engine = BehavioralReplayEngine(audit_store=AuditStore(base_dir))
    report = engine.replay(
        agent_id="agent-1",
        replay_config=ReplayConfig(allow_threshold=0.9, description="Stricter Q2 policy"),
    )
    print(report.generate_summary())
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any

from nomotic.audit_store import LogStore, PersistentLogRecord
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import Action, AgentContext, TrustProfile

__all__ = [
    "BehavioralReplayEngine",
    "ReplayConfig",
    "ReplayReport",
    "VerdictComparison",
]

# Strictness ordering for verdict direction classification.
_VERDICT_ORDER = {"ALLOW": 0, "MODIFY": 1, "ESCALATE": 2, "DENY": 3}


def _classify_direction(actual: str, counterfactual: str) -> str:
    """Classify the direction of verdict change.

    Strictness order: ALLOW < MODIFY < ESCALATE < DENY.
    If counterfactual is stricter: ``"stricter"``.
    If counterfactual is looser: ``"looser"``.
    If same: ``"same"``.
    Otherwise: ``"lateral"``.
    """
    a = _VERDICT_ORDER.get(actual)
    c = _VERDICT_ORDER.get(counterfactual)
    if a is None or c is None:
        return "lateral"
    if a == c:
        return "same"
    if c > a:
        return "stricter"
    return "looser"


# ── Data classes ───────────────────────────────────────────────────────


@dataclass
class ReplayConfig:
    """Alternative governance configuration to replay against.

    ``None`` values mean "use the same as original."
    """

    contract: Any = None  # BehavioralContract override
    invariants: list[dict[str, Any]] | None = None  # InvariantSpec dicts override
    dimension_weights: dict[str, float] | None = None
    allow_threshold: float | None = None
    deny_threshold: float | None = None
    trust_influence: float | None = None
    drift_thresholds: dict[str, float] | None = None
    semantic_anchor_overrides: list[dict[str, Any]] | None = None
    cost_profile: dict[str, Any] | None = None  # Alternative CostProfile for counterfactual replay

    description: str = ""  # Human description: "Stricter drift thresholds proposed for Q2"

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {}
        if self.contract is not None:
            d["contract"] = (
                self.contract.to_dict()
                if hasattr(self.contract, "to_dict")
                else self.contract
            )
        if self.invariants is not None:
            d["invariants"] = self.invariants
        if self.dimension_weights is not None:
            d["dimension_weights"] = self.dimension_weights
        if self.allow_threshold is not None:
            d["allow_threshold"] = self.allow_threshold
        if self.deny_threshold is not None:
            d["deny_threshold"] = self.deny_threshold
        if self.trust_influence is not None:
            d["trust_influence"] = self.trust_influence
        if self.drift_thresholds is not None:
            d["drift_thresholds"] = self.drift_thresholds
        if self.semantic_anchor_overrides is not None:
            d["semantic_anchor_overrides"] = self.semantic_anchor_overrides
        if self.cost_profile is not None:
            d["cost_profile"] = self.cost_profile
        if self.description:
            d["description"] = self.description
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ReplayConfig:
        return cls(
            contract=data.get("contract"),
            invariants=data.get("invariants"),
            dimension_weights=data.get("dimension_weights"),
            allow_threshold=data.get("allow_threshold"),
            deny_threshold=data.get("deny_threshold"),
            trust_influence=data.get("trust_influence"),
            drift_thresholds=data.get("drift_thresholds"),
            semantic_anchor_overrides=data.get("semantic_anchor_overrides"),
            cost_profile=data.get("cost_profile"),
            description=data.get("description", ""),
        )


@dataclass(frozen=True)
class VerdictComparison:
    """Side-by-side comparison of actual vs. counterfactual verdict."""

    action_index: int
    timestamp: float
    action_type: str
    target: str

    actual_verdict: str  # "ALLOW", "DENY", "ESCALATE", "MODIFY"
    actual_ucs: float

    counterfactual_verdict: str
    counterfactual_ucs: float

    diverged: bool
    direction: str = ""  # "stricter", "looser", "lateral", "same"

    def to_dict(self) -> dict[str, Any]:
        return {
            "action_index": self.action_index,
            "timestamp": self.timestamp,
            "action_type": self.action_type,
            "target": self.target,
            "actual_verdict": self.actual_verdict,
            "actual_ucs": self.actual_ucs,
            "counterfactual_verdict": self.counterfactual_verdict,
            "counterfactual_ucs": self.counterfactual_ucs,
            "diverged": self.diverged,
            "direction": self.direction,
        }


@dataclass
class ReplayReport:
    """Results of replaying agent history against an alternative configuration."""

    report_id: str
    agent_id: str
    replay_config_description: str

    actions_replayed: int
    time_range_start: float
    time_range_end: float

    total_divergences: int
    stricter_count: int
    looser_count: int

    divergence_points: list[VerdictComparison] = field(default_factory=list)

    invariant_violations_counterfactual: int = 0

    drift_at_end_actual: dict[str, float] = field(default_factory=dict)
    drift_at_end_counterfactual: dict[str, float] = field(default_factory=dict)

    cost_profile_used: dict[str, Any] = field(default_factory=dict)

    summary: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "report_id": self.report_id,
            "agent_id": self.agent_id,
            "replay_config_description": self.replay_config_description,
            "actions_replayed": self.actions_replayed,
            "time_range_start": self.time_range_start,
            "time_range_end": self.time_range_end,
            "total_divergences": self.total_divergences,
            "stricter_count": self.stricter_count,
            "looser_count": self.looser_count,
            "divergence_points": [dp.to_dict() for dp in self.divergence_points],
            "invariant_violations_counterfactual": self.invariant_violations_counterfactual,
            "drift_at_end_actual": self.drift_at_end_actual,
            "drift_at_end_counterfactual": self.drift_at_end_counterfactual,
            "cost_profile_used": self.cost_profile_used,
            "summary": self.summary,
        }

    def generate_summary(self) -> str:
        """Generate a human-readable summary of the replay results."""
        if self.actions_replayed == 0:
            self.summary = (
                f"No actions found to replay for agent {self.agent_id}."
            )
            return self.summary

        lines: list[str] = []
        lines.append(
            f"Replayed {self.actions_replayed} actions for {self.agent_id}."
        )

        if self.total_divergences == 0:
            lines.append(
                "The alternative config would have produced identical verdicts."
            )
        else:
            parts: list[str] = []
            if self.stricter_count:
                parts.append(f"{self.stricter_count} stricter (more denials)")
            if self.looser_count:
                parts.append(f"{self.looser_count} looser")
            lateral = self.total_divergences - self.stricter_count - self.looser_count
            if lateral > 0:
                parts.append(f"{lateral} lateral")
            lines.append(
                f"The alternative config would have produced "
                f"{self.total_divergences} different verdicts: {', '.join(parts)}."
            )
            if self.actions_replayed > 0 and self.stricter_count > 0:
                pct = (self.stricter_count / self.actions_replayed) * 100
                lines.append(
                    f"Net effect: {pct:.1f}% of actions would have been "
                    f"blocked that were previously allowed."
                )

        self.summary = " ".join(lines)
        return self.summary


# ── Engine ─────────────────────────────────────────────────────────────


class BehavioralReplayEngine:
    """Replay agent behavioral history against alternative governance configs.

    Loads historical action sequences from the audit trail, applies
    alternative governance configurations (contracts, invariants, thresholds,
    dimension weights, trust parameters), and produces a :class:`ReplayReport`
    comparing actual verdicts with counterfactual verdicts.
    """

    def __init__(self, audit_store: LogStore | None = None) -> None:
        self._audit_store = audit_store

    def _reconstruct_action(self, record: PersistentLogRecord) -> Action:
        """Reconstruct an :class:`Action` from an audit record."""
        return Action(
            id=record.record_id,
            action_type=record.action_type,
            target=record.action_target,
            parameters=record.parameters or {},
            agent_id=record.agent_id,
            timestamp=record.timestamp,
        )

    def _build_counterfactual_runtime(
        self,
        replay_config: ReplayConfig,
        archetype: str = "general",
        agent_id: str = "replay-agent",
    ) -> GovernanceRuntime:
        """Create a fresh runtime with counterfactual configuration.

        This runtime is ephemeral — used only for replay, then discarded.
        Fingerprints are enabled for behavioral tracking during replay,
        but auditing is disabled (no need to audit a replay).
        """
        config_kwargs: dict[str, Any] = {
            "enable_fingerprints": True,
            "enable_audit": False,
            "enable_contextual_modifier": False,
            "enable_workflow_governor": False,
            "enable_equity_analysis": False,
            "enable_bias_detection": False,
            "enable_cross_dimensional": False,
            "enable_contracts": False,
        }

        if replay_config.allow_threshold is not None:
            config_kwargs["allow_threshold"] = replay_config.allow_threshold
        if replay_config.deny_threshold is not None:
            config_kwargs["deny_threshold"] = replay_config.deny_threshold
        if replay_config.trust_influence is not None:
            config_kwargs["trust_influence"] = replay_config.trust_influence
        if replay_config.dimension_weights is not None:
            config_kwargs["dimension_weights"] = replay_config.dimension_weights

        # Enable cost-sensitive governance when a cost_profile is provided
        if replay_config.cost_profile is not None:
            config_kwargs["enable_cost_sensitive"] = True
            config_kwargs["enable_contracts"] = True

        config = RuntimeConfig(**config_kwargs)
        runtime = GovernanceRuntime(config)

        # Apply contract if provided.
        if replay_config.contract is not None and runtime._contract_store is not None:
            runtime._contract_store.store(replay_config.contract)

        # Apply cost_profile to the agent's contract for counterfactual replay
        if replay_config.cost_profile is not None and runtime._contract_store is not None:
            from nomotic.contract import BehavioralContract

            import time as _time

            # Create a minimal contract with the cost profile if no contract was provided
            if replay_config.contract is None:
                cp_contract = BehavioralContract(
                    contract_id=f"replay-cost-{archetype}",
                    version=1,
                    agent_id=agent_id,
                    created_at=_time.time(),
                    archetype=archetype,
                    expected_action_distribution={},
                    expected_target_distribution={},
                    expected_outcome_distribution={},
                    drift_thresholds={},
                    cost_profile=replay_config.cost_profile,
                )
                runtime._contract_store.store(cp_contract)
            else:
                # Merge cost_profile onto the provided contract
                existing = runtime._contract_store.get_active(agent_id)
                if existing is not None:
                    from dataclasses import replace as _dc_replace
                    updated = _dc_replace(existing, cost_profile=replay_config.cost_profile)
                    runtime._contract_store.store(updated)

        return runtime

    def replay(
        self,
        agent_id: str,
        replay_config: ReplayConfig,
        start_time: float | None = None,
        end_time: float | None = None,
        max_actions: int = 10000,
    ) -> ReplayReport:
        """Replay agent history against alternative config.

        Args:
            agent_id: The agent whose history to replay.
            replay_config: Alternative governance configuration.
            start_time: Only replay actions after this timestamp.
            end_time: Only replay actions before this timestamp.
            max_actions: Maximum number of actions to replay.

        Returns:
            A :class:`ReplayReport` comparing actual vs. counterfactual verdicts.
        """
        if self._audit_store is None:
            return self._empty_report(agent_id, replay_config)

        # Query all records in chronological order.
        all_records = self._audit_store.query_all(agent_id)
        if not all_records:
            return self._empty_report(agent_id, replay_config)

        # Filter by time range.
        records: list[PersistentLogRecord] = []
        for r in all_records:
            if start_time is not None and r.timestamp < start_time:
                continue
            if end_time is not None and r.timestamp > end_time:
                continue
            records.append(r)
            if len(records) >= max_actions:
                break

        if not records:
            return self._empty_report(agent_id, replay_config)

        # Build counterfactual runtime.
        cf_runtime = self._build_counterfactual_runtime(replay_config, agent_id=agent_id)

        # Create context for replay.
        context = AgentContext(
            agent_id=agent_id,
            trust_profile=TrustProfile(agent_id=agent_id),
        )

        divergence_points: list[VerdictComparison] = []
        stricter_count = 0
        looser_count = 0

        for idx, record in enumerate(records):
            action = self._reconstruct_action(record)
            cf_verdict = cf_runtime.evaluate(action, context)

            actual_verdict_str = record.verdict
            cf_verdict_str = cf_verdict.verdict.name

            diverged = actual_verdict_str != cf_verdict_str
            direction = _classify_direction(actual_verdict_str, cf_verdict_str)

            if diverged:
                comparison = VerdictComparison(
                    action_index=idx,
                    timestamp=record.timestamp,
                    action_type=record.action_type,
                    target=record.action_target,
                    actual_verdict=actual_verdict_str,
                    actual_ucs=record.ucs,
                    counterfactual_verdict=cf_verdict_str,
                    counterfactual_ucs=cf_verdict.ucs,
                    diverged=True,
                    direction=direction,
                )
                divergence_points.append(comparison)

                if direction == "stricter":
                    stricter_count += 1
                elif direction == "looser":
                    looser_count += 1

        report = ReplayReport(
            report_id=f"replay-{uuid.uuid4().hex[:12]}",
            agent_id=agent_id,
            replay_config_description=replay_config.description,
            actions_replayed=len(records),
            time_range_start=records[0].timestamp,
            time_range_end=records[-1].timestamp,
            total_divergences=len(divergence_points),
            stricter_count=stricter_count,
            looser_count=looser_count,
            divergence_points=divergence_points,
            cost_profile_used=replay_config.cost_profile or {},
        )
        report.generate_summary()
        return report

    def replay_fleet(
        self,
        agent_ids: list[str],
        replay_config: ReplayConfig,
        start_time: float | None = None,
        end_time: float | None = None,
    ) -> dict[str, ReplayReport]:
        """Replay multiple agents. Returns ``{agent_id: ReplayReport}``."""
        return {
            aid: self.replay(
                agent_id=aid,
                replay_config=replay_config,
                start_time=start_time,
                end_time=end_time,
            )
            for aid in agent_ids
        }

    def compare_configs(
        self,
        agent_id: str,
        config_a: ReplayConfig,
        config_b: ReplayConfig,
        start_time: float | None = None,
        end_time: float | None = None,
    ) -> dict[str, ReplayReport]:
        """Compare two configs against the same agent history.

        Returns ``{"config_a": ReplayReport, "config_b": ReplayReport}``.
        """
        return {
            "config_a": self.replay(
                agent_id=agent_id,
                replay_config=config_a,
                start_time=start_time,
                end_time=end_time,
            ),
            "config_b": self.replay(
                agent_id=agent_id,
                replay_config=config_b,
                start_time=start_time,
                end_time=end_time,
            ),
        }

    def _empty_report(
        self, agent_id: str, replay_config: ReplayConfig
    ) -> ReplayReport:
        report = ReplayReport(
            report_id=f"replay-{uuid.uuid4().hex[:12]}",
            agent_id=agent_id,
            replay_config_description=replay_config.description,
            actions_replayed=0,
            time_range_start=0.0,
            time_range_end=0.0,
            total_divergences=0,
            stricter_count=0,
            looser_count=0,
        )
        report.generate_summary()
        return report
