"""Signal Model & Prior System — normalized signal ingestion for governance.

Provides a formal signal catalogue, normalized signal representation, and a
prior system that supplies default values when signals are absent.  Dimensions
access signals through ``context.signal_bundle.get(name, prior_system)``
instead of ad-hoc ``AgentContext.metadata`` lookups.
"""

from __future__ import annotations

import csv
import json
import os
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

__all__ = [
    "FileSignalFeed",
    "PriorSystem",
    "Signal",
    "SignalBundle",
    "SignalCatalogue",
    "SignalFormat",
    "SignalSpec",
    "BUILTIN_SIGNALS",
]


# ── Signal format ───────────────────────────────────────────────────────


class SignalFormat(Enum):
    """Normalized formats a signal value can take."""

    FLOAT_01 = "float_0_1"       # 0.0–1.0 normalized
    CATEGORICAL = "categorical"
    INTEGER = "integer"
    BOOLEAN = "boolean"


# ── Signal specification ────────────────────────────────────────────────


@dataclass(frozen=True)
class SignalSpec:
    """Definition of a named governance signal."""

    name: str
    description: str
    format: SignalFormat
    agent_types: list[str]       # which agent types this signal is relevant for; empty = all
    prior: Any                   # default value when signal is absent
    valid_range: tuple[float, float] | None = None  # for FLOAT_01: (0.0, 1.0)
    valid_values: list[Any] | None = None           # for CATEGORICAL


# ── Runtime signal value ────────────────────────────────────────────────


@dataclass
class Signal:
    """A signal value at evaluation time."""

    name: str
    value: Any
    source: str             # where this value came from
    computed_at: float      # unix timestamp
    confidence: float = 1.0


# ── Signal catalogue ───────────────────────────────────────────────────


class SignalCatalogue:
    """Registry of all named signals Nomotic understands."""

    def __init__(self) -> None:
        self._specs: dict[str, SignalSpec] = {}
        self._lock = threading.Lock()

    def register(self, spec: SignalSpec) -> None:
        """Register a signal specification."""
        with self._lock:
            self._specs[spec.name] = spec

    def get_spec(self, name: str) -> SignalSpec | None:
        """Return the spec for *name*, or ``None`` if unknown."""
        return self._specs.get(name)

    def get_for_agent_type(self, agent_type: str) -> list[SignalSpec]:
        """Return all specs relevant to *agent_type*.

        A spec with an empty ``agent_types`` list is relevant to every type.
        """
        return [
            s for s in self._specs.values()
            if not s.agent_types or agent_type in s.agent_types
        ]

    def all_specs(self) -> list[SignalSpec]:
        """Return every registered spec."""
        return list(self._specs.values())

    def __len__(self) -> int:
        return len(self._specs)

    def __contains__(self, name: str) -> bool:
        return name in self._specs


# ── Prior system ────────────────────────────────────────────────────────


class PriorSystem:
    """Manages prior values for absent signals."""

    def __init__(self, catalogue: SignalCatalogue) -> None:
        self._catalogue = catalogue

    def get_prior(self, signal_name: str, agent_type: str | None = None) -> Any:
        """Return the prior (default) value for *signal_name*.

        Raises ``KeyError`` if the signal is not in the catalogue.
        """
        spec = self._catalogue.get_spec(signal_name)
        if spec is None:
            raise KeyError(f"Unknown signal: {signal_name!r}")
        return spec.prior

    def resolve(
        self,
        signals: dict[str, Signal],
        signal_name: str,
        agent_type: str | None = None,
    ) -> Any:
        """Return signal value if present, prior if absent."""
        sig = signals.get(signal_name)
        if sig is not None:
            return sig.value
        return self.get_prior(signal_name, agent_type)


# ── Signal bundle ───────────────────────────────────────────────────────


@dataclass
class SignalBundle:
    """The set of signals available for a single evaluation."""

    signals: dict[str, Signal] = field(default_factory=dict)
    agent_type: str | None = None

    def get(self, name: str, prior_system: PriorSystem) -> Any:
        """Get signal value or prior."""
        return prior_system.resolve(self.signals, name, self.agent_type)

    def missing(self, catalogue: SignalCatalogue) -> list[str]:
        """List signals in catalogue for this agent type that are absent."""
        if self.agent_type is not None:
            relevant = catalogue.get_for_agent_type(self.agent_type)
        else:
            relevant = catalogue.all_specs()
        return [s.name for s in relevant if s.name not in self.signals]


# ── Built-in signal catalogue ──────────────────────────────────────────

BUILTIN_SIGNALS: list[SignalSpec] = [
    SignalSpec(
        name="loyalty",
        description="Customer loyalty score, normalized 0–1.",
        format=SignalFormat.FLOAT_01,
        agent_types=["customer_experience", "sales_agent"],
        prior=0.5,
        valid_range=(0.0, 1.0),
    ),
    SignalSpec(
        name="fraud_risk",
        description="Probability of fraudulent activity, normalized 0–1.",
        format=SignalFormat.FLOAT_01,
        agent_types=["customer_experience", "financial_analyst"],
        prior=0.3,
        valid_range=(0.0, 1.0),
    ),
    SignalSpec(
        name="consent_status",
        description="User consent status for data processing.",
        format=SignalFormat.CATEGORICAL,
        agent_types=[],
        prior="unknown",
        valid_values=["granted", "denied", "unknown"],
    ),
    SignalSpec(
        name="relationship_tenure",
        description="Length of customer relationship in days.",
        format=SignalFormat.INTEGER,
        agent_types=[],
        prior=0,
    ),
    SignalSpec(
        name="fraud_risk_elevated",
        description="Whether fraud risk is currently elevated.",
        format=SignalFormat.BOOLEAN,
        agent_types=["financial_analyst"],
        prior=False,
    ),
]


def build_default_catalogue() -> SignalCatalogue:
    """Return a :class:`SignalCatalogue` pre-loaded with built-in signals."""
    catalogue = SignalCatalogue()
    for spec in BUILTIN_SIGNALS:
        catalogue.register(spec)
    return catalogue


# ── File-based signal feed ──────────────────────────────────────────────


class FileSignalFeed:
    """Reads a CSV or JSON file and populates a SignalBundle cache.

    The file is re-read on a configurable interval.  Each row/object must
    contain an ``entity_id`` field that keys the cache, plus one or more
    signal columns whose names match the catalogue.

    Supported formats (detected from extension):
    - ``.csv`` — header row required; values are coerced per signal spec.
    - ``.json`` — top-level list of objects.
    """

    def __init__(
        self,
        path: str,
        catalogue: SignalCatalogue,
        refresh_seconds: float = 60.0,
        source: str | None = None,
    ) -> None:
        self.path = path
        self._catalogue = catalogue
        self.refresh_seconds = refresh_seconds
        self.source = source or f"file:{path}"
        self._cache: dict[str, SignalBundle] = {}
        self._lock = threading.Lock()
        self._last_load: float = 0.0

    # ── Public API ──────────────────────────────────────────────────

    def get_bundle(self, entity_id: str, agent_type: str | None = None) -> SignalBundle:
        """Return the cached :class:`SignalBundle` for *entity_id*.

        Triggers a reload if the refresh interval has elapsed.
        """
        self._maybe_reload()
        with self._lock:
            bundle = self._cache.get(entity_id)
        if bundle is not None:
            return bundle
        return SignalBundle(agent_type=agent_type)

    @property
    def cache(self) -> dict[str, SignalBundle]:
        """Snapshot of the current cache (mainly for testing)."""
        with self._lock:
            return dict(self._cache)

    def reload(self) -> None:
        """Force an immediate reload of the backing file."""
        self._load()

    # ── Internal ────────────────────────────────────────────────────

    def _maybe_reload(self) -> None:
        if time.monotonic() - self._last_load >= self.refresh_seconds:
            self._load()

    def _load(self) -> None:
        ext = os.path.splitext(self.path)[1].lower()
        if ext == ".csv":
            rows = self._read_csv()
        elif ext == ".json":
            rows = self._read_json()
        else:
            raise ValueError(f"Unsupported signal feed file type: {ext!r}")

        now = time.time()
        new_cache: dict[str, SignalBundle] = {}
        for row in rows:
            entity_id = row.get("entity_id")
            if entity_id is None:
                continue
            signals: dict[str, Signal] = {}
            for key, raw_value in row.items():
                if key == "entity_id":
                    continue
                spec = self._catalogue.get_spec(key)
                if spec is None:
                    continue
                value = self._coerce(raw_value, spec)
                signals[key] = Signal(
                    name=key,
                    value=value,
                    source=self.source,
                    computed_at=now,
                )
            new_cache[entity_id] = SignalBundle(signals=signals)

        with self._lock:
            self._cache = new_cache
        self._last_load = time.monotonic()

    def _read_csv(self) -> list[dict[str, str]]:
        with open(self.path, newline="") as f:
            return list(csv.DictReader(f))

    def _read_json(self) -> list[dict[str, Any]]:
        with open(self.path) as f:
            data = json.load(f)
        if isinstance(data, list):
            return data
        raise ValueError("JSON signal feed must be a top-level list of objects")

    @staticmethod
    def _coerce(raw: Any, spec: SignalSpec) -> Any:
        """Coerce a raw value to the type expected by *spec*."""
        if spec.format == SignalFormat.FLOAT_01:
            return float(raw)
        if spec.format == SignalFormat.INTEGER:
            return int(raw)
        if spec.format == SignalFormat.BOOLEAN:
            if isinstance(raw, str):
                return raw.lower() in ("true", "1", "yes")
            return bool(raw)
        # CATEGORICAL — keep as string
        return str(raw)
