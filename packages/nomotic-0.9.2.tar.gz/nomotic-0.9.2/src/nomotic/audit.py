"""Audit trail — structured, append-only log of governance events.

The audit trail records every governance decision with enough detail to
reconstruct decisions after the fact.  It is the evidence base for
transparency and accountability.

In-memory implementation with a pluggable backend interface.  The trail
accumulates records and can be queried by agent, by time, by context
code, or by severity.
"""

from __future__ import annotations

import hashlib
import json
import threading
from dataclasses import dataclass, field
from typing import Any, cast


__all__ = [
    "AccountabilityRecord",
    "AuditRecord",
    "AuditTrail",
    "ChangeRecord",
    "JustificationRecord",
    "OutcomeRecord",
    "UnwrittenPolicyAdjustmentRecord",
    "build_justification",
    "verify_chain",
    "verify_typed_chain",
]


# ── AuditRecord ───────────────────────────────────────────────────────────


@dataclass
class AuditRecord:
    """A single audit record — one governance event fully documented.

    This is the atomic unit of the audit trail.  It captures everything
    needed to reconstruct a governance decision after the fact.
    """

    # Identity
    record_id: str
    timestamp: float

    # Context code
    context_code: str  # e.g., "GOVERNANCE.ALLOW"
    severity: str      # Copied from the ContextCode for fast filtering

    # The three actors
    agent_id: str
    owner_id: str        # From the certificate's owner field
    user_id: str         # Who triggered this action (if known)

    # The action
    action_id: str
    action_type: str
    action_target: str

    # The governance decision
    verdict: str         # Verdict name: "ALLOW", "DENY", etc.
    ucs: float           # Unified Confidence Score
    tier: int            # Which tier decided (1, 2, 3)

    # Dimension scores snapshot
    dimension_scores: list[dict[str, Any]] = field(default_factory=list)

    # Trust state at time of decision
    trust_score: float = 0.5
    trust_trend: str = "stable"

    # Drift state at time of decision (if available)
    drift_overall: float | None = None
    drift_severity: str | None = None

    # Contextual justification — the narrative explanation
    justification: str = ""

    # Additional metadata
    metadata: dict[str, Any] = field(default_factory=dict)

    # Hash chain fields
    previous_hash: str = ""      # SHA-256 hash of the previous record
    record_hash: str = ""        # SHA-256 hash of this record (computed on creation)

    def compute_hash(self) -> str:
        """Compute the SHA-256 hash of this record.

        Serializes the record (without record_hash) to canonical JSON,
        prepends the previous_hash, and computes SHA-256.
        """
        d = self._hashable_dict()
        canonical = json.dumps(d, sort_keys=True, separators=(",", ":"))
        payload = self.previous_hash + canonical
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _hashable_dict(self) -> dict[str, Any]:
        """Dict of all fields except record_hash, for hashing."""
        d: dict[str, Any] = {
            "record_id": self.record_id,
            "timestamp": self.timestamp,
            "context_code": self.context_code,
            "severity": self.severity,
            "agent_id": self.agent_id,
            "owner_id": self.owner_id,
            "user_id": self.user_id,
            "action_id": self.action_id,
            "action_type": self.action_type,
            "action_target": self.action_target,
            "verdict": self.verdict,
            "ucs": round(self.ucs, 4),
            "tier": self.tier,
            "dimension_scores": self.dimension_scores,
            "trust_score": round(self.trust_score, 4),
            "trust_trend": self.trust_trend,
            "drift_overall": round(self.drift_overall, 4) if self.drift_overall is not None else None,
            "drift_severity": self.drift_severity,
            "justification": self.justification,
            "previous_hash": self.previous_hash,
        }
        if self.metadata:
            d["metadata"] = self.metadata
        return d

    def to_dict(self) -> dict[str, Any]:
        """Serialize to JSON-friendly dict."""
        d: dict[str, Any] = {
            "record_id": self.record_id,
            "timestamp": self.timestamp,
            "context_code": self.context_code,
            "severity": self.severity,
            "agent_id": self.agent_id,
            "owner_id": self.owner_id,
            "user_id": self.user_id,
            "action_id": self.action_id,
            "action_type": self.action_type,
            "action_target": self.action_target,
            "verdict": self.verdict,
            "ucs": round(self.ucs, 4),
            "tier": self.tier,
            "dimension_scores": self.dimension_scores,
            "trust_score": round(self.trust_score, 4),
            "trust_trend": self.trust_trend,
            "drift_overall": round(self.drift_overall, 4) if self.drift_overall is not None else None,
            "drift_severity": self.drift_severity,
            "justification": self.justification,
            "previous_hash": self.previous_hash,
            "record_hash": self.record_hash,
        }
        if self.metadata:
            d["metadata"] = self.metadata
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> AuditRecord:
        """Deserialize from dict."""
        return cls(
            record_id=d["record_id"],
            timestamp=d["timestamp"],
            context_code=d["context_code"],
            severity=d["severity"],
            agent_id=d["agent_id"],
            owner_id=d["owner_id"],
            user_id=d["user_id"],
            action_id=d["action_id"],
            action_type=d["action_type"],
            action_target=d["action_target"],
            verdict=d["verdict"],
            ucs=d["ucs"],
            tier=d["tier"],
            dimension_scores=d.get("dimension_scores", []),
            trust_score=d.get("trust_score", 0.5),
            trust_trend=d.get("trust_trend", "stable"),
            drift_overall=d.get("drift_overall"),
            drift_severity=d.get("drift_severity"),
            justification=d.get("justification", ""),
            metadata=d.get("metadata", {}),
            previous_hash=d.get("previous_hash", ""),
            record_hash=d.get("record_hash", ""),
        )


# ── Typed record base ─────────────────────────────────────────────────────


def _compute_typed_hash(fields: dict[str, Any], prev_hash: str) -> str:
    """Compute SHA-256 hash for a typed record given its hashable fields."""
    canonical = json.dumps(fields, sort_keys=True, separators=(",", ":"))
    payload = prev_hash + canonical
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


# ── JustificationRecord ──────────────────────────────────────────────────


@dataclass
class JustificationRecord:
    """Why the governance system made the decision it made."""

    record_id: str
    action_id: str
    agent_id: str
    verdict: str
    determinative_factors: list[str]
    counterfactual: str
    dimension_results: dict[str, Any]
    coherence_score: float
    timestamp: float
    prev_hash: str = ""
    record_hash: str = ""

    def _hashable_dict(self) -> dict[str, Any]:
        return {
            "record_id": self.record_id,
            "action_id": self.action_id,
            "agent_id": self.agent_id,
            "verdict": self.verdict,
            "determinative_factors": self.determinative_factors,
            "counterfactual": self.counterfactual,
            "dimension_results": self.dimension_results,
            "coherence_score": round(self.coherence_score, 4),
            "timestamp": self.timestamp,
            "prev_hash": self.prev_hash,
        }

    def compute_hash(self) -> str:
        return _compute_typed_hash(self._hashable_dict(), self.prev_hash)

    def to_dict(self) -> dict[str, Any]:
        d = self._hashable_dict()
        d["record_hash"] = self.record_hash
        return d


# ── OutcomeRecord ─────────────────────────────────────────────────────────


@dataclass
class OutcomeRecord:
    """What happened as a result of a governance decision."""

    record_id: str
    action_id: str
    agent_id: str
    decision_verdict: str
    outcome_signals: dict[str, Any]
    outcome_at: float
    outcome_validated: bool
    override_occurred: bool
    override_reason: str | None
    timestamp: float
    prev_hash: str = ""
    record_hash: str = ""

    def _hashable_dict(self) -> dict[str, Any]:
        return {
            "record_id": self.record_id,
            "action_id": self.action_id,
            "agent_id": self.agent_id,
            "decision_verdict": self.decision_verdict,
            "outcome_signals": self.outcome_signals,
            "outcome_at": self.outcome_at,
            "outcome_validated": self.outcome_validated,
            "override_occurred": self.override_occurred,
            "override_reason": self.override_reason,
            "timestamp": self.timestamp,
            "prev_hash": self.prev_hash,
        }

    def compute_hash(self) -> str:
        return _compute_typed_hash(self._hashable_dict(), self.prev_hash)

    def to_dict(self) -> dict[str, Any]:
        d = self._hashable_dict()
        d["record_hash"] = self.record_hash
        return d


# ── UnwrittenPolicyAdjustmentRecord ───────────────────────────────────────


@dataclass
class UnwrittenPolicyAdjustmentRecord:
    """A pattern promoted from exception to explicit policy."""

    record_id: str
    pattern_description: str
    evidence_action_ids: list[str]
    observation_count: int
    positive_outcome_rate: float
    proposed_policy_change: str
    approved_by: str
    approved_at: float
    policy_change_applied: str
    timestamp: float
    prev_hash: str = ""
    record_hash: str = ""

    def _hashable_dict(self) -> dict[str, Any]:
        return {
            "record_id": self.record_id,
            "pattern_description": self.pattern_description,
            "evidence_action_ids": self.evidence_action_ids,
            "observation_count": self.observation_count,
            "positive_outcome_rate": round(self.positive_outcome_rate, 4),
            "proposed_policy_change": self.proposed_policy_change,
            "approved_by": self.approved_by,
            "approved_at": self.approved_at,
            "policy_change_applied": self.policy_change_applied,
            "timestamp": self.timestamp,
            "prev_hash": self.prev_hash,
        }

    def compute_hash(self) -> str:
        return _compute_typed_hash(self._hashable_dict(), self.prev_hash)

    def to_dict(self) -> dict[str, Any]:
        d = self._hashable_dict()
        d["record_hash"] = self.record_hash
        return d


# ── AccountabilityRecord ──────────────────────────────────────────────────


@dataclass
class AccountabilityRecord:
    """Every human action taken in relation to a governance decision."""

    record_id: str
    action_id: str
    human_id: str
    human_action: str
    original_verdict: str
    resulting_verdict: str | None
    stated_rationale: str
    timestamp: float
    prev_hash: str = ""
    record_hash: str = ""

    def _hashable_dict(self) -> dict[str, Any]:
        return {
            "record_id": self.record_id,
            "action_id": self.action_id,
            "human_id": self.human_id,
            "human_action": self.human_action,
            "original_verdict": self.original_verdict,
            "resulting_verdict": self.resulting_verdict,
            "stated_rationale": self.stated_rationale,
            "timestamp": self.timestamp,
            "prev_hash": self.prev_hash,
        }

    def compute_hash(self) -> str:
        return _compute_typed_hash(self._hashable_dict(), self.prev_hash)

    def to_dict(self) -> dict[str, Any]:
        d = self._hashable_dict()
        d["record_hash"] = self.record_hash
        return d


# ── ChangeRecord ──────────────────────────────────────────────────────────


@dataclass
class ChangeRecord:
    """Every configuration change to the governance system."""

    record_id: str
    changed_by: str
    change_type: str
    component: str
    before_state: dict[str, Any]
    after_state: dict[str, Any]
    source: str
    timestamp: float
    prev_hash: str = ""
    record_hash: str = ""

    def _hashable_dict(self) -> dict[str, Any]:
        return {
            "record_id": self.record_id,
            "changed_by": self.changed_by,
            "change_type": self.change_type,
            "component": self.component,
            "before_state": self.before_state,
            "after_state": self.after_state,
            "source": self.source,
            "timestamp": self.timestamp,
            "prev_hash": self.prev_hash,
        }

    def compute_hash(self) -> str:
        return _compute_typed_hash(self._hashable_dict(), self.prev_hash)

    def to_dict(self) -> dict[str, Any]:
        d = self._hashable_dict()
        d["record_hash"] = self.record_hash
        return d


# ── Justification builder ─────────────────────────────────────────────────


def build_justification(
    verdict: Any,
    action: Any,
    context: Any,
    drift_score: Any = None,
) -> str:
    """Build a contextual justification for a governance decision.

    Synthesizes dimension scores, trust state, and drift into a
    narrative that a regulator, auditor, or board member can understand.
    """
    from nomotic.types import Verdict

    parts: list[str] = []

    # Verdict summary
    verdict_name = verdict.verdict.name if hasattr(verdict.verdict, "name") else str(verdict.verdict)
    tier_str = f"Tier {verdict.tier}"

    if verdict.vetoed_by:
        parts.append(
            f"Action {verdict_name} (UCS: {verdict.ucs:.2f}, {tier_str}, veto)."
        )
    else:
        parts.append(
            f"Action {verdict_name} (UCS: {verdict.ucs:.2f}, {tier_str})."
        )

    # Agent and trust context
    trust = context.trust_profile.overall_trust if hasattr(context, "trust_profile") else 0.5
    parts.append(
        f"Agent (trust: {trust:.2f}) requested '{action.action_type}' on '{action.target}'."
    )

    # Dimension scores detail
    if verdict.vetoed_by:
        # Lead with the veto reasons
        for score in verdict.dimension_scores:
            if score.veto:
                parts.append(
                    f"VETOED by {score.dimension_name} ({score.score:.2f}) — {score.reasoning}."
                )

    # Brief mention of other dimensions
    for score in verdict.dimension_scores:
        if score.veto:
            continue  # Already covered above
        if score.score >= 0.8:
            # Brief mention
            name = score.dimension_name.replace("_", " ").title()
            parts.append(f"{name} ok ({score.score:.2f}).")
        elif score.score >= 0.4:
            name = score.dimension_name.replace("_", " ").title()
            parts.append(f"{name} elevated ({score.score:.2f}) — {score.reasoning}.")
        else:
            name = score.dimension_name.replace("_", " ").title()
            parts.append(f"{name} concern ({score.score:.2f}) — {score.reasoning}.")

    # Drift info
    if drift_score is not None:
        severity = drift_score.severity if hasattr(drift_score, "severity") else "unknown"
        overall = drift_score.overall if hasattr(drift_score, "overall") else 0.0
        if severity in ("high", "critical"):
            parts.append(f"Drift {severity.upper()} ({overall:.2f}).")
        elif severity == "moderate":
            parts.append(f"Drift moderate ({overall:.2f}).")
        elif severity == "none":
            parts.append("No drift detected.")

    # Cap length for normal cases
    result = " ".join(parts)
    if verdict.verdict == Verdict.ALLOW and len(result) > 500:
        result = result[:497] + "..."

    return result


# ── AuditTrail ─────────────────────────────────────────────────────────────


def verify_chain(records: list[AuditRecord]) -> tuple[bool, str]:
    """Verify the hash chain integrity.

    Records should be in chronological order (oldest first).
    Returns (valid, error_message).
    """
    if not records:
        return True, ""

    for i, record in enumerate(records):
        # Skip records without hash chain data (pre-upgrade)
        if not record.record_hash:
            continue

        # Verify the previous_hash links
        if i > 0 and records[i - 1].record_hash:
            if record.previous_hash != records[i - 1].record_hash:
                return False, (
                    f"Chain broken at record {i} ({record.record_id}): "
                    f"previous_hash mismatch"
                )

        # Verify the record's own hash
        expected = record.compute_hash()
        if record.record_hash != expected:
            return False, (
                f"Hash mismatch at record {i} ({record.record_id}): "
                f"expected {expected[:16]}..., got {record.record_hash[:16]}..."
            )

    return True, ""


_TypedRecord = (
    JustificationRecord
    | OutcomeRecord
    | UnwrittenPolicyAdjustmentRecord
    | AccountabilityRecord
    | ChangeRecord
)


def verify_typed_chain(records: list[_TypedRecord]) -> tuple[bool, str]:
    """Verify hash chain integrity for any typed record list.

    Works for JustificationRecord, OutcomeRecord, etc.
    Records should be in chronological order (oldest first).
    """
    if not records:
        return True, ""

    for i, record in enumerate(records):
        if not record.record_hash:
            continue

        if i > 0 and records[i - 1].record_hash:
            if record.prev_hash != records[i - 1].record_hash:
                return False, (
                    f"Chain broken at record {i} ({record.record_id}): "
                    f"prev_hash mismatch"
                )

        expected = record.compute_hash()
        if record.record_hash != expected:
            return False, (
                f"Hash mismatch at record {i} ({record.record_id}): "
                f"expected {expected[:16]}..., got {record.record_hash[:16]}..."
            )

    return True, ""


class AuditTrail:
    """Append-only structured log of governance events.

    The audit trail records every governance decision with enough detail
    to reconstruct decisions after the fact.  It is the evidence base for
    transparency and accountability.

    In-memory implementation with a pluggable backend interface.
    The trail accumulates records and can be queried by agent, by time,
    by context code, or by severity.

    The trail is capped at *max_records* to prevent unbounded memory
    growth.  When the cap is hit, oldest records are dropped.

    Records are hash-chained: each record includes the SHA-256 hash of
    the previous record, creating an immutable audit trail.
    """

    def __init__(
        self,
        max_records: int = 10000,
        sanitization_policy: Any = None,
    ) -> None:
        self._records: list[AuditRecord] = []
        self._max_records = max_records
        self._lock = threading.Lock()
        self._last_hash: str = ""
        self._sanitization_policy = sanitization_policy

        # Independent hash chains for each typed record
        self._justification_records: list[JustificationRecord] = []
        self._justification_last_hash: str = ""
        self._outcome_records: list[OutcomeRecord] = []
        self._outcome_last_hash: str = ""
        self._policy_adjustment_records: list[UnwrittenPolicyAdjustmentRecord] = []
        self._policy_adjustment_last_hash: str = ""
        self._accountability_records: list[AccountabilityRecord] = []
        self._accountability_last_hash: str = ""
        self._change_records: list[ChangeRecord] = []
        self._change_last_hash: str = ""

    def append(self, record: AuditRecord) -> None:
        """Add a record to the trail.  Thread-safe.

        Computes hash chain: sets previous_hash from the last record
        and computes record_hash for the new record.

        If a sanitization policy is configured and enabled, the record
        is sanitized before hashing and appending.
        """
        with self._lock:
            # Sanitize before hashing so the hash covers the redacted form
            if (
                self._sanitization_policy is not None
                and self._sanitization_policy.enabled
            ):
                from nomotic.sanitize import sanitize_audit_record
                sanitize_audit_record(record, self._sanitization_policy)

            # Set hash chain fields
            record.previous_hash = self._last_hash
            record.record_hash = record.compute_hash()
            self._last_hash = record.record_hash

            self._records.append(record)
            if len(self._records) > self._max_records:
                self._records = self._records[-self._max_records:]

    def query(
        self,
        *,
        agent_id: str | None = None,
        owner_id: str | None = None,
        user_id: str | None = None,
        context_code: str | None = None,
        category: str | None = None,
        severity: str | None = None,
        verdict: str | None = None,
        since: float | None = None,
        until: float | None = None,
        limit: int = 100,
    ) -> list[AuditRecord]:
        """Query audit records with filters.  All filters are AND-combined.

        Returns records in reverse chronological order (newest first).
        """
        with self._lock:
            records = list(self._records)

        # Apply filters
        if agent_id is not None:
            records = [r for r in records if r.agent_id == agent_id]
        if owner_id is not None:
            records = [r for r in records if r.owner_id == owner_id]
        if user_id is not None:
            records = [r for r in records if r.user_id == user_id]
        if context_code is not None:
            code_str = str(context_code)
            records = [r for r in records if r.context_code == code_str]
        if category is not None:
            records = [r for r in records if r.context_code.split(".")[0] == category]
        if severity is not None:
            records = [r for r in records if r.severity == severity]
        if verdict is not None:
            records = [r for r in records if r.verdict == verdict]
        if since is not None:
            records = [r for r in records if r.timestamp >= since]
        if until is not None:
            records = [r for r in records if r.timestamp <= until]

        # Reverse chronological, limited
        records.reverse()
        return records[:limit]

    def count(self, **filters: Any) -> int:
        """Count records matching filters (same args as query)."""
        return len(self.query(**filters, limit=self._max_records))

    def summary(
        self,
        agent_id: str | None = None,
        since: float | None = None,
    ) -> dict[str, Any]:
        """Summary statistics for the audit trail.

        Returns:
            {
                "total_records": 1247,
                "by_verdict": {"ALLOW": 1180, "DENY": 45, ...},
                "by_category": {"GOVERNANCE": 1225, "SECURITY": 12, ...},
                "by_severity": {"info": 1100, "warning": 120, ...},
                "recent_alerts": [last 5 records with severity >= "alert"],
            }
        """
        with self._lock:
            records = list(self._records)

        if agent_id is not None:
            records = [r for r in records if r.agent_id == agent_id]
        if since is not None:
            records = [r for r in records if r.timestamp >= since]

        by_verdict: dict[str, int] = {}
        by_category: dict[str, int] = {}
        by_severity: dict[str, int] = {}
        alerts: list[AuditRecord] = []

        for r in records:
            by_verdict[r.verdict] = by_verdict.get(r.verdict, 0) + 1
            cat = r.context_code.split(".")[0]
            by_category[cat] = by_category.get(cat, 0) + 1
            by_severity[r.severity] = by_severity.get(r.severity, 0) + 1
            if r.severity in ("alert", "critical"):
                alerts.append(r)

        return {
            "total_records": len(records),
            "by_verdict": by_verdict,
            "by_category": by_category,
            "by_severity": by_severity,
            "recent_alerts": [a.to_dict() for a in alerts[-5:]],
        }

    @property
    def records(self) -> list[AuditRecord]:
        """All records, newest first.  Returns a copy."""
        with self._lock:
            return list(reversed(self._records))

    def export(self, format: str = "json") -> str | list[dict[str, Any]]:
        """Export the audit trail.

        Args:
            format: ``"json"`` returns a JSON string.
                    ``"dicts"`` returns a list of dicts.

        If a sanitization policy is configured, the exported data is
        sanitized (records stored in the trail may already be sanitized
        on append; this provides a second pass for exports specifically).
        """
        with self._lock:
            dicts = [r.to_dict() for r in self._records]

        if (
            self._sanitization_policy is not None
            and self._sanitization_policy.enabled
        ):
            from nomotic.sanitize import sanitize_for_export
            dicts = cast(
                list[dict[str, Any]],
                sanitize_for_export(dicts, self._sanitization_policy),
            )

        if format == "dicts":
            return dicts
        return json.dumps(dicts, indent=2)

    def clear(self) -> None:
        """Clear the audit trail.  Use with caution."""
        with self._lock:
            self._records.clear()
            self._justification_records.clear()
            self._justification_last_hash = ""
            self._outcome_records.clear()
            self._outcome_last_hash = ""
            self._policy_adjustment_records.clear()
            self._policy_adjustment_last_hash = ""
            self._accountability_records.clear()
            self._accountability_last_hash = ""
            self._change_records.clear()
            self._change_last_hash = ""

    # ── Typed record chains ───────────────────────────────────────────

    def _append_typed(
        self,
        record: _TypedRecord,
        store: list,  # type: ignore[type-arg]
        last_hash_attr: str,
    ) -> None:
        """Hash-chain and append a typed record.  Caller holds _lock."""
        last_hash = getattr(self, last_hash_attr)
        record.prev_hash = last_hash
        record.record_hash = record.compute_hash()
        setattr(self, last_hash_attr, record.record_hash)
        store.append(record)
        if len(store) > self._max_records:
            del store[: len(store) - self._max_records]

    # ── Justification ─────────────────────────────────────────────────

    def append_justification(self, record: JustificationRecord) -> None:
        """Append a JustificationRecord to its independent chain."""
        with self._lock:
            self._append_typed(
                record, self._justification_records, "_justification_last_hash",
            )

    def query_justifications(
        self,
        *,
        agent_id: str | None = None,
        action_id: str | None = None,
        since: float | None = None,
        until: float | None = None,
        limit: int = 100,
    ) -> list[JustificationRecord]:
        """Query justification records with filters."""
        with self._lock:
            records = list(self._justification_records)
        if agent_id is not None:
            records = [r for r in records if r.agent_id == agent_id]
        if action_id is not None:
            records = [r for r in records if r.action_id == action_id]
        if since is not None:
            records = [r for r in records if r.timestamp >= since]
        if until is not None:
            records = [r for r in records if r.timestamp <= until]
        records.reverse()
        return records[:limit]

    @property
    def justification_records(self) -> list[JustificationRecord]:
        """All justification records (chronological copy)."""
        with self._lock:
            return list(self._justification_records)

    # ── Outcome ───────────────────────────────────────────────────────

    def append_outcome(self, record: OutcomeRecord) -> None:
        """Append an OutcomeRecord to its independent chain."""
        with self._lock:
            self._append_typed(
                record, self._outcome_records, "_outcome_last_hash",
            )

    def query_outcomes(
        self,
        *,
        agent_id: str | None = None,
        action_id: str | None = None,
        since: float | None = None,
        until: float | None = None,
        limit: int = 100,
    ) -> list[OutcomeRecord]:
        """Query outcome records with filters."""
        with self._lock:
            records = list(self._outcome_records)
        if agent_id is not None:
            records = [r for r in records if r.agent_id == agent_id]
        if action_id is not None:
            records = [r for r in records if r.action_id == action_id]
        if since is not None:
            records = [r for r in records if r.timestamp >= since]
        if until is not None:
            records = [r for r in records if r.timestamp <= until]
        records.reverse()
        return records[:limit]

    @property
    def outcome_records(self) -> list[OutcomeRecord]:
        """All outcome records (chronological copy)."""
        with self._lock:
            return list(self._outcome_records)

    # ── Unwritten Policy Adjustment ───────────────────────────────────

    def append_policy_adjustment(
        self, record: UnwrittenPolicyAdjustmentRecord,
    ) -> None:
        """Append an UnwrittenPolicyAdjustmentRecord to its independent chain."""
        with self._lock:
            self._append_typed(
                record,
                self._policy_adjustment_records,
                "_policy_adjustment_last_hash",
            )

    def query_policy_adjustments(
        self,
        *,
        since: float | None = None,
        until: float | None = None,
        limit: int = 100,
    ) -> list[UnwrittenPolicyAdjustmentRecord]:
        """Query policy adjustment records with filters."""
        with self._lock:
            records = list(self._policy_adjustment_records)
        if since is not None:
            records = [r for r in records if r.timestamp >= since]
        if until is not None:
            records = [r for r in records if r.timestamp <= until]
        records.reverse()
        return records[:limit]

    @property
    def policy_adjustment_records(self) -> list[UnwrittenPolicyAdjustmentRecord]:
        """All policy adjustment records (chronological copy)."""
        with self._lock:
            return list(self._policy_adjustment_records)

    # ── Accountability ────────────────────────────────────────────────

    def append_accountability(self, record: AccountabilityRecord) -> None:
        """Append an AccountabilityRecord to its independent chain."""
        with self._lock:
            self._append_typed(
                record,
                self._accountability_records,
                "_accountability_last_hash",
            )

    def query_accountability(
        self,
        *,
        action_id: str | None = None,
        human_id: str | None = None,
        since: float | None = None,
        until: float | None = None,
        limit: int = 100,
    ) -> list[AccountabilityRecord]:
        """Query accountability records with filters."""
        with self._lock:
            records = list(self._accountability_records)
        if action_id is not None:
            records = [r for r in records if r.action_id == action_id]
        if human_id is not None:
            records = [r for r in records if r.human_id == human_id]
        if since is not None:
            records = [r for r in records if r.timestamp >= since]
        if until is not None:
            records = [r for r in records if r.timestamp <= until]
        records.reverse()
        return records[:limit]

    @property
    def accountability_records(self) -> list[AccountabilityRecord]:
        """All accountability records (chronological copy)."""
        with self._lock:
            return list(self._accountability_records)

    # ── Change ────────────────────────────────────────────────────────

    def append_change(self, record: ChangeRecord) -> None:
        """Append a ChangeRecord to its independent chain."""
        with self._lock:
            self._append_typed(
                record, self._change_records, "_change_last_hash",
            )

    def query_changes(
        self,
        *,
        changed_by: str | None = None,
        change_type: str | None = None,
        component: str | None = None,
        since: float | None = None,
        until: float | None = None,
        limit: int = 100,
    ) -> list[ChangeRecord]:
        """Query change records with filters."""
        with self._lock:
            records = list(self._change_records)
        if changed_by is not None:
            records = [r for r in records if r.changed_by == changed_by]
        if change_type is not None:
            records = [r for r in records if r.change_type == change_type]
        if component is not None:
            records = [r for r in records if r.component == component]
        if since is not None:
            records = [r for r in records if r.timestamp >= since]
        if until is not None:
            records = [r for r in records if r.timestamp <= until]
        records.reverse()
        return records[:limit]

    @property
    def change_records(self) -> list[ChangeRecord]:
        """All change records (chronological copy)."""
        with self._lock:
            return list(self._change_records)
