"""LLM endpoint configuration for Nomotic governance dimensions.

LLM-dependent dimensions (D16 Minimum Necessary Privilege, D19 Goal-Action
Alignment, D20 Adversarial Signal Detection) require an LLM endpoint to
score meaningfully. Without one, they fall back to heuristic scoring.

This module defines the configuration interface. The actual LLM calls are
made by nomotic-pro, not by the open source SDK.

Supported endpoint types:

- Nomotic Cloud LLM: endpoint="https://api.nomotic.ai/v1/llm"
  Requires a valid Pro/Enterprise license. No additional setup.

- Self-hosted / BYOL: endpoint="http://localhost:11434" (Ollama)
  or endpoint="https://your-azure.openai.com/..."
  Requires your own LLM deployment.

- AWS Bedrock: endpoint="https://bedrock-runtime.us-east-1.amazonaws.com"
  Requires AWS credentials in the environment.
"""

from __future__ import annotations

from dataclasses import dataclass

__all__ = [
    "LLMConfig",
    "NOMOTIC_CLOUD_LLM",
]


@dataclass
class LLMConfig:
    """Configuration for the LLM endpoint used by inferential dimensions.

    Used by nomotic-pro for D16 (Minimum Necessary Privilege),
    D19 (Goal-Action Alignment), and D20 (Adversarial Signal Detection).

    When fallback_to_heuristic=True (default), missing or failing LLM calls
    produce conservative heuristic scores rather than errors.

    Examples:
        # Nomotic Cloud LLM (requires Pro license)
        LLMConfig(endpoint="https://api.nomotic.ai/v1/llm")

        # Self-hosted Ollama
        LLMConfig(
            endpoint="http://localhost:11434",
            model="llama3.1:70b",
        )

        # Azure OpenAI
        LLMConfig(
            endpoint="https://my-resource.openai.azure.com",
            model="gpt-4o",
            api_key="my-azure-key",
        )
    """

    endpoint: str = "https://api.nomotic.ai/v1/llm"
    model: str = "nomotic-governance-v1"
    api_key: str | None = None          # None = use license key or environment auth
    timeout_ms: int = 2000
    fallback_to_heuristic: bool = True  # if True, failed LLM calls return heuristic score
    max_retries: int = 1


NOMOTIC_CLOUD_LLM = LLMConfig(
    endpoint="https://api.nomotic.ai/v1/llm",
    model="nomotic-governance-v1",
)
"""Default LLM config pointing at Nomotic Cloud. Requires Pro license."""
