"""Simple API key authentication for the Nomotic governance server.

The server supports two auth modes:

- ``"none"`` (default for local/dev): no authentication required.
- ``"api_key"``: requests must include the header ``X-Nomotic-API-Key``
  matching the configured key.

Configure via :attr:`RuntimeConfig.server_auth_mode` and
:attr:`RuntimeConfig.server_api_key`, or pass ``--api-key`` to
``nomotic serve``.
"""

from __future__ import annotations

__all__ = ["check_api_key"]


def check_api_key(
    runtime_api_key: str | None,
    request_key: str | None,
) -> bool:
    """Return ``True`` if the request is authorised.

    Parameters
    ----------
    runtime_api_key:
        The server's configured API key.  When ``None``, authentication is
        disabled and all requests pass.
    request_key:
        The value of the ``X-Nomotic-API-Key`` header sent by the client.

    Returns
    -------
    bool
        ``True`` if access is allowed, ``False`` if the key is missing or
        does not match.
    """
    if runtime_api_key is None:
        return True  # auth disabled
    return request_key == runtime_api_key
