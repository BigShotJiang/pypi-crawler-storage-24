"""Drift causal analysis — explaining why drift happened.

Detection without explanation is half the job. When the Behavioral Control
Plane flags drift, the first question is 'why?' This module provides
causal hypotheses with evidence, ranked by confidence, for every drift
scope and distribution combination in the Nomotic Drift Taxonomy.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any

from nomotic.drift import DriftScore

__all__ = [
    "CausalHypothesis",
    "DriftCausalAnalyzer",
    "DriftCausalReport",
]


# ── Data structures ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class CausalHypothesis:
    """A hypothesized cause for a drift event."""

    cause_type: str
    """One of ``"config_change"``, ``"model_update"``, ``"workload_shift"``,
    ``"upstream_propagation"``, ``"semantic_reframing"``, ``"contract_change"``,
    ``"unknown"``."""

    confidence: float
    """0.0–1.0 confidence in this hypothesis."""

    description: str
    """Human-readable explanation, e.g. ``"Model endpoint updated from v3.1
    to v3.2 at 14:22 UTC"``."""

    evidence: tuple[str, ...] = ()
    """Supporting evidence strings (tuple for frozen dataclass)."""

    timestamp: float | None = None
    """When the hypothesized cause occurred."""

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-friendly dict."""
        d: dict[str, Any] = {
            "cause_type": self.cause_type,
            "confidence": round(self.confidence, 4),
            "description": self.description,
            "evidence": list(self.evidence),
        }
        if self.timestamp is not None:
            d["timestamp"] = self.timestamp
        return d


@dataclass(frozen=True)
class DriftCausalReport:
    """Causal analysis of a drift event."""

    alert_id: str
    """The alert that triggered this analysis."""

    agent_id: str
    """Primary agent (or first in chain for coordinated drift)."""

    scope: str
    """One of ``"agent"``, ``"fleet"``, ``"correlated"``, ``"coordinated"``."""

    distributions_involved: tuple[str, ...] = ()
    """Which distributions drifted significantly (e.g. ``("action", "semantic")``)."""

    primary_hypothesis: CausalHypothesis | None = None
    alternative_hypotheses: tuple[CausalHypothesis, ...] = ()

    # Correlated drift specific
    shared_upstream_input: str = ""
    affected_agents: tuple[str, ...] = ()

    # Coordinated drift specific
    propagation_chain: tuple[str, ...] = ()
    amplification_profile: tuple[str, ...] = ()
    recommended_intervention: str = ""

    # Fleet drift specific
    contributing_groups: dict[str, int] = field(default_factory=dict)
    """Archetype → count of drifting agents."""
    fleet_movement_type: str = ""
    """``"concentrated"`` or ``"distributed"``."""

    remediation: tuple[str, ...] = ()
    """Recommended remediation actions."""

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-friendly dict."""
        d: dict[str, Any] = {
            "alert_id": self.alert_id,
            "agent_id": self.agent_id,
            "scope": self.scope,
            "distributions_involved": list(self.distributions_involved),
            "primary_hypothesis": (
                self.primary_hypothesis.to_dict()
                if self.primary_hypothesis is not None
                else None
            ),
            "alternative_hypotheses": [
                h.to_dict() for h in self.alternative_hypotheses
            ],
            "shared_upstream_input": self.shared_upstream_input,
            "affected_agents": list(self.affected_agents),
            "propagation_chain": list(self.propagation_chain),
            "amplification_profile": list(self.amplification_profile),
            "recommended_intervention": self.recommended_intervention,
            "contributing_groups": dict(self.contributing_groups),
            "fleet_movement_type": self.fleet_movement_type,
            "remediation": list(self.remediation),
        }
        return d

    def summary(self) -> str:
        """One-paragraph summary suitable for alert display.

        Example::

            Correlated semantic drift detected across 7 finance-agent instances.
            Hypothesis (confidence: 0.85): shared model endpoint updated from
            v3.1 to v3.2.  Recommendation: review model v3.2 semantic impact,
            consider staged rollout.
        """
        parts: list[str] = []

        # Scope + distributions
        dist_str = ", ".join(self.distributions_involved) if self.distributions_involved else "overall"
        if self.scope == "agent":
            parts.append(f"Agent drift detected ({dist_str}) for {self.agent_id}.")
        elif self.scope == "correlated":
            n = len(self.affected_agents)
            parts.append(
                f"Correlated {dist_str} drift detected across {n} agent"
                f"{'s' if n != 1 else ''}."
            )
        elif self.scope == "coordinated":
            chain_len = len(self.propagation_chain)
            parts.append(
                f"Coordinated drift propagated through {chain_len}-hop chain ({dist_str})."
            )
        elif self.scope == "fleet":
            parts.append(f"Fleet-level drift detected ({dist_str}).")
            if self.fleet_movement_type:
                parts.append(f"Movement type: {self.fleet_movement_type}.")

        # Hypothesis
        if self.primary_hypothesis is not None:
            h = self.primary_hypothesis
            parts.append(
                f"Hypothesis (confidence: {h.confidence:.2f}): {h.description}"
            )

        # Remediation
        if self.remediation:
            parts.append(f"Recommendation: {self.remediation[0]}")

        return " ".join(parts)


# ── Remediation templates ─────────────────────────────────────────────────

_DISTRIBUTION_REMEDIATION: dict[str, str] = {
    "action": "Review agent scope and action type permissions",
    "target": "Verify agent target access patterns",
    "temporal": "Check scheduling changes or infrastructure",
    "semantic": "Review instruction anchors in behavioral contract",
    "outcome": "Check if governance rules changed or agent behavior triggered new rules",
}

# Moderate drift threshold for identifying involved distributions
_MODERATE_THRESHOLD = 0.15

# Time window to look back in provenance log (seconds)
_PROVENANCE_LOOKBACK = 3600  # 1 hour
# Close temporal proximity for high-confidence config attribution
_CLOSE_PROXIMITY = 1800  # 30 minutes


# ── Analyzer ──────────────────────────────────────────────────────────────


class DriftCausalAnalyzer:
    """Post-detection enrichment layer that explains drift events.

    Strategies by scope:

    * **Agent**: correlate drift timing with provenance log entries (config
      changes, model updates).
    * **Fleet**: decompose aggregate shift into contributing agent groups.
    * **Correlated**: identify shared upstream input from provenance log.
    * **Coordinated**: reconstruct propagation chain with amplification
      analysis.
    """

    def __init__(
        self,
        provenance_log: Any | None = None,
        fingerprint_observer: Any | None = None,
        fleet_monitor: Any | None = None,
        contract_store: Any | None = None,
    ) -> None:
        self._provenance = provenance_log
        self._observer = fingerprint_observer
        self._fleet_monitor = fleet_monitor
        self._contract_store = contract_store

    # ── Public dispatch ───────────────────────────────────────────────

    def analyze(self, alert: Any) -> DriftCausalReport:
        """Auto-dispatch based on alert type.

        * :class:`DriftAlert` (from ``monitor.py``) → :meth:`analyze_agent_drift`
        * :class:`FleetDriftAlert` with ``scope="fleet"`` → :meth:`analyze_fleet_drift`
        * :class:`FleetDriftAlert` with ``scope="correlated"`` → :meth:`analyze_correlated_drift`
        * :class:`FleetDriftAlert` with ``scope="coordinated"`` → :meth:`analyze_coordinated_drift`
        """
        # FleetDriftAlert has alert_id and scope; DriftAlert has agent_id
        if hasattr(alert, "scope"):
            # FleetDriftAlert
            if alert.scope == "fleet":
                return self.analyze_fleet_drift(alert)
            elif alert.scope == "correlated":
                return self.analyze_correlated_drift(alert)
            elif alert.scope == "coordinated":
                return self.analyze_coordinated_drift(alert)
        # DriftAlert (individual agent)
        return self.analyze_agent_drift(
            agent_id=alert.agent_id,
            drift_score=alert.drift_score,
            alert_timestamp=alert.timestamp,
        )

    # ── Agent drift ───────────────────────────────────────────────────

    def analyze_agent_drift(
        self,
        agent_id: str,
        drift_score: DriftScore,
        alert_timestamp: float,
    ) -> DriftCausalReport:
        """Analyze individual agent drift.

        1. Identify distributions above moderate threshold.
        2. Query provenance log for events near the alert timestamp.
        3. Generate hypotheses ranked by confidence.
        4. Generate remediation based on involved distributions.
        """
        alert_id = f"agent-{agent_id}-{uuid.uuid4().hex[:8]}"

        # 1. Identify involved distributions
        distributions_involved = self._identify_distributions(drift_score)

        # 2. Query provenance
        provenance_events = self._query_provenance_for_agent(
            agent_id, alert_timestamp
        )

        # 3. Generate hypotheses
        hypotheses = self._build_agent_hypotheses(
            agent_id, drift_score, alert_timestamp, provenance_events,
            distributions_involved,
        )
        hypotheses.sort(key=lambda h: h.confidence, reverse=True)
        primary = hypotheses[0] if hypotheses else None
        alternatives = tuple(hypotheses[1:])

        # 4. Remediation
        remediation = self._build_remediation(distributions_involved)

        return DriftCausalReport(
            alert_id=alert_id,
            agent_id=agent_id,
            scope="agent",
            distributions_involved=tuple(distributions_involved),
            primary_hypothesis=primary,
            alternative_hypotheses=alternatives,
            remediation=tuple(remediation),
        )

    # ── Fleet drift ───────────────────────────────────────────────────

    def analyze_fleet_drift(self, alert: Any) -> DriftCausalReport:
        """Analyze fleet-level aggregate drift.

        1. Group agents by archetype.
        2. Determine fleet movement type (concentrated vs distributed).
        3. Query provenance for global policy changes.
        4. Build hypotheses and return report.
        """
        alert_id = getattr(alert, "alert_id", f"fleet-{uuid.uuid4().hex[:8]}")
        distributions_involved = tuple(
            getattr(alert, "fleet_distributions_shifted", [])
        )

        # Gather per-agent drift data
        agent_drifts: dict[str, float] = {}
        agent_archetypes: dict[str, str] = {}
        if self._observer is not None:
            fps = self._observer.all_fingerprints()
            for aid in fps:
                d = self._observer.get_drift(aid)
                if d is not None:
                    agent_drifts[aid] = d.overall

        # Determine fleet movement type
        fleet_movement_type, contributing_groups = self._classify_fleet_movement(
            agent_drifts, agent_archetypes,
        )

        # Query provenance for global changes
        provenance_events = self._query_provenance_global(alert.timestamp)

        hypotheses: list[CausalHypothesis] = []
        if provenance_events:
            ev = provenance_events[0]
            hypotheses.append(CausalHypothesis(
                cause_type="config_change",
                confidence=0.75,
                description=(
                    f"Global policy change: {ev.change_type} on "
                    f"{ev.target_type}/{ev.target_id}"
                ),
                evidence=(
                    f"Provenance record at {ev.timestamp}: {ev.change_type} "
                    f"by {ev.actor}",
                ),
                timestamp=ev.timestamp,
            ))

        if fleet_movement_type == "concentrated":
            hypotheses.append(CausalHypothesis(
                cause_type="workload_shift",
                confidence=0.5,
                description=(
                    "Fleet drift concentrated in a few high-magnitude drifters"
                ),
            ))
        else:
            hypotheses.append(CausalHypothesis(
                cause_type="model_update",
                confidence=0.5,
                description=(
                    "Broad low-magnitude shift across many agents suggests "
                    "shared upstream change"
                ),
            ))

        hypotheses.append(CausalHypothesis(
            cause_type="unknown",
            confidence=0.2,
            description="No specific cause identified",
        ))
        hypotheses.sort(key=lambda h: h.confidence, reverse=True)

        remediation = self._build_remediation(list(distributions_involved))
        if fleet_movement_type == "concentrated":
            remediation.insert(
                0,
                "Investigate the top drifting agents individually for root cause",
            )
        else:
            remediation.insert(
                0,
                "Review recent shared infrastructure or model changes affecting the fleet",
            )

        return DriftCausalReport(
            alert_id=alert_id,
            agent_id=getattr(alert, "affected_agents", ["fleet"])[0]
            if getattr(alert, "affected_agents", [])
            else "fleet",
            scope="fleet",
            distributions_involved=distributions_involved,
            primary_hypothesis=hypotheses[0],
            alternative_hypotheses=tuple(hypotheses[1:]),
            contributing_groups=contributing_groups,
            fleet_movement_type=fleet_movement_type,
            remediation=tuple(remediation),
        )

    # ── Correlated drift ──────────────────────────────────────────────

    def analyze_correlated_drift(self, alert: Any) -> DriftCausalReport:
        """Analyze correlated drift across multiple agents.

        1. Get affected agents from alert.
        2. Query provenance for shared upstream changes.
        3. Determine dominant distribution from shared_drift_direction.
        4. Build hypotheses and return report.
        """
        alert_id = getattr(alert, "alert_id", f"correlated-{uuid.uuid4().hex[:8]}")
        affected = list(getattr(alert, "affected_agents", []))

        # Determine dominant distribution
        shared_direction = getattr(alert, "shared_drift_direction", {})
        distributions_involved = [
            name for name, val in shared_direction.items()
            if val > _MODERATE_THRESHOLD
        ] or ["overall"]

        # Query provenance for shared upstream changes
        provenance_events = self._query_provenance_shared(alert.timestamp)
        shared_upstream = ""

        hypotheses: list[CausalHypothesis] = []
        if provenance_events:
            ev = provenance_events[0]
            shared_upstream = f"{ev.target_type}/{ev.target_id}"
            hypotheses.append(CausalHypothesis(
                cause_type="model_update"
                if ev.target_type in ("model", "endpoint")
                else "config_change",
                confidence=0.85,
                description=(
                    f"Shared upstream change: {ev.change_type} on "
                    f"{ev.target_type}/{ev.target_id} at {ev.timestamp}"
                ),
                evidence=(
                    f"Provenance: {ev.change_type} by {ev.actor}",
                    f"Affects {len(affected)} agents simultaneously",
                ),
                timestamp=ev.timestamp,
            ))

        if "semantic" in distributions_involved:
            hypotheses.append(CausalHypothesis(
                cause_type="semantic_reframing",
                confidence=0.7,
                description=(
                    "Semantic drift dominant across affected agents — shared "
                    "model or instruction source likely changed"
                ),
                evidence=(
                    f"Semantic distribution shifted in {len(affected)} agents",
                ),
            ))

        hypotheses.append(CausalHypothesis(
            cause_type="unknown",
            confidence=0.2,
            description="No specific cause identified",
        ))
        hypotheses.sort(key=lambda h: h.confidence, reverse=True)

        remediation = [
            "Review the shared upstream change. Consider staged rollout.",
        ] + self._build_remediation(distributions_involved)

        return DriftCausalReport(
            alert_id=alert_id,
            agent_id=affected[0] if affected else "unknown",
            scope="correlated",
            distributions_involved=tuple(distributions_involved),
            primary_hypothesis=hypotheses[0],
            alternative_hypotheses=tuple(hypotheses[1:]),
            shared_upstream_input=shared_upstream,
            affected_agents=tuple(affected),
            remediation=tuple(remediation),
        )

    # ── Coordinated drift ─────────────────────────────────────────────

    def analyze_coordinated_drift(self, alert: Any) -> DriftCausalReport:
        """Analyze coordinated drift through interaction chains.

        1. Use alert's propagation chain and amplification factors.
        2. Analyze root cause agent's drift for underlying cause.
        3. Compute amplification analysis.
        4. Determine recommended intervention point.
        """
        alert_id = getattr(alert, "alert_id", f"coordinated-{uuid.uuid4().hex[:8]}")
        chain = list(getattr(alert, "propagation_chain", []))
        amp_factors = list(getattr(alert, "amplification_factors", []))

        # Root cause = first agent in chain
        root_agent = chain[0] if chain else "unknown"

        # Analyze root cause agent
        root_drift = None
        if self._observer is not None and root_agent != "unknown":
            root_drift = self._observer.get_drift(root_agent)

        # Determine distributions from root drift
        distributions_involved: list[str] = []
        if root_drift is not None:
            distributions_involved = self._identify_distributions(root_drift)

        # Analyze amplification: growing, stable, or attenuating?
        amplification_profile: list[str] = []
        if len(amp_factors) >= 2:
            for i in range(1, len(amp_factors)):
                if amp_factors[i] > amp_factors[i - 1] * 1.1:
                    amplification_profile.append(
                        f"hop {i}: amplifying ({amp_factors[i]:.4f})"
                    )
                elif amp_factors[i] < amp_factors[i - 1] * 0.9:
                    amplification_profile.append(
                        f"hop {i}: attenuating ({amp_factors[i]:.4f})"
                    )
                else:
                    amplification_profile.append(
                        f"hop {i}: stable ({amp_factors[i]:.4f})"
                    )

        # Determine if drift is amplifying through chain
        is_amplifying = (
            len(amp_factors) >= 2 and amp_factors[-1] > amp_factors[0]
        )

        # Recommended intervention
        if is_amplifying:
            intervention = root_agent
            intervention_desc = (
                f"Break amplification chain at root agent {root_agent}"
            )
        elif chain:
            mid = len(chain) // 2
            intervention = chain[mid]
            intervention_desc = (
                f"Inject governance checkpoint at {chain[mid]}"
            )
        else:
            intervention = root_agent
            intervention_desc = f"Review root agent {root_agent}"

        # Build hypotheses from root cause analysis
        hypotheses: list[CausalHypothesis] = []
        provenance_events = self._query_provenance_for_agent(
            root_agent, alert.timestamp,
        )
        if provenance_events:
            ev = provenance_events[0]
            hypotheses.append(CausalHypothesis(
                cause_type="config_change",
                confidence=0.8,
                description=(
                    f"Root cause agent {root_agent} config change: "
                    f"{ev.change_type} on {ev.target_type} at {ev.timestamp}"
                ),
                evidence=(
                    f"Config change propagated through {len(chain)}-hop chain",
                ),
                timestamp=ev.timestamp,
            ))

        hypotheses.append(CausalHypothesis(
            cause_type="upstream_propagation",
            confidence=0.7,
            description=(
                f"Drift propagated from {root_agent} through "
                f"{len(chain)}-hop interaction chain"
            ),
            evidence=tuple(amplification_profile) if amplification_profile else (),
        ))

        hypotheses.append(CausalHypothesis(
            cause_type="unknown",
            confidence=0.2,
            description="No specific cause identified",
        ))
        hypotheses.sort(key=lambda h: h.confidence, reverse=True)

        remediation_parts: list[str] = [intervention_desc]
        if is_amplifying and len(chain) >= 2:
            remediation_parts.append(
                f"Inject governance checkpoint between "
                f"{chain[0]} and {chain[1]}"
            )
        remediation_parts.extend(self._build_remediation(distributions_involved))

        return DriftCausalReport(
            alert_id=alert_id,
            agent_id=root_agent,
            scope="coordinated",
            distributions_involved=tuple(distributions_involved),
            primary_hypothesis=hypotheses[0],
            alternative_hypotheses=tuple(hypotheses[1:]),
            propagation_chain=tuple(chain),
            amplification_profile=tuple(amplification_profile),
            recommended_intervention=intervention,
            remediation=tuple(remediation_parts),
        )

    # ── Internal helpers ──────────────────────────────────────────────

    def _identify_distributions(self, drift_score: DriftScore) -> list[str]:
        """Identify distributions above moderate threshold."""
        involved = []
        for name in ("action", "target", "temporal", "outcome", "semantic"):
            val = getattr(drift_score, f"{name}_drift", 0.0)
            if val > _MODERATE_THRESHOLD:
                involved.append(name)
        return involved

    def _query_provenance_for_agent(
        self, agent_id: str, alert_timestamp: float,
    ) -> list[Any]:
        """Query provenance log for events near the alert affecting this agent."""
        if self._provenance is None:
            return []
        since = alert_timestamp - _PROVENANCE_LOOKBACK
        records = self._provenance.query(since=since, until=alert_timestamp)
        # Filter for events related to this agent
        relevant_target_types = {
            "scope", "rule", "weight", "threshold", "trust",
            "model", "policy", "endpoint", "contract",
        }
        relevant: list[Any] = []
        for r in records:
            if r.target_id == agent_id or r.target_type in relevant_target_types:
                relevant.append(r)
        return relevant

    def _query_provenance_global(self, alert_timestamp: float) -> list[Any]:
        """Query provenance log for global changes."""
        if self._provenance is None:
            return []
        since = alert_timestamp - _PROVENANCE_LOOKBACK
        records = self._provenance.query(since=since, until=alert_timestamp)
        global_types = {"model", "policy", "scope", "endpoint", "fleet"}
        return [r for r in records if r.target_type in global_types]

    def _query_provenance_shared(self, alert_timestamp: float) -> list[Any]:
        """Query provenance log for shared upstream changes."""
        if self._provenance is None:
            return []
        since = alert_timestamp - _PROVENANCE_LOOKBACK
        records = self._provenance.query(since=since, until=alert_timestamp)
        shared_types = {"model", "policy", "scope", "endpoint"}
        return [r for r in records if r.target_type in shared_types]

    def _build_agent_hypotheses(
        self,
        agent_id: str,
        drift_score: DriftScore,
        alert_timestamp: float,
        provenance_events: list[Any],
        distributions_involved: list[str],
    ) -> list[CausalHypothesis]:
        """Build ranked hypotheses for agent drift."""
        hypotheses: list[CausalHypothesis] = []

        # Check provenance events within close proximity
        close_events = [
            ev for ev in provenance_events
            if (alert_timestamp - ev.timestamp) <= _CLOSE_PROXIMITY
        ]

        if close_events:
            ev = close_events[0]
            hypotheses.append(CausalHypothesis(
                cause_type="config_change",
                confidence=0.8,
                description=(
                    f"Config change at {ev.timestamp}: {ev.change_type} "
                    f"on {ev.target_type}"
                ),
                evidence=(
                    f"Provenance: {ev.actor} ({ev.actor_type}) changed "
                    f"{ev.target_type}/{ev.target_id}",
                    f"Change occurred {alert_timestamp - ev.timestamp:.0f}s before drift alert",
                ),
                timestamp=ev.timestamp,
            ))

        # Semantic reframing hypothesis
        if "semantic" in distributions_involved and not close_events:
            detail_text = drift_score.detail if drift_score.detail else "unknown term"
            hypotheses.append(CausalHypothesis(
                cause_type="semantic_reframing",
                confidence=0.6,
                description=(
                    f"Gradual semantic reframing of term '{detail_text}'"
                ),
                evidence=(
                    "Semantic drift dominant with no proximate config change",
                ),
            ))

        # Workload shift hypothesis (when no provenance)
        if not provenance_events:
            hypotheses.append(CausalHypothesis(
                cause_type="workload_shift",
                confidence=0.4,
                description="Possible workload or input pattern change",
                evidence=(
                    "No provenance events found in the lookback window",
                ),
            ))

        # Always include unknown alternative
        hypotheses.append(CausalHypothesis(
            cause_type="unknown",
            confidence=0.2,
            description="No specific cause identified",
        ))

        return hypotheses

    def _build_remediation(self, distributions: list[str]) -> list[str]:
        """Generate remediation recommendations from involved distributions."""
        if not distributions:
            return ["Review agent behavioral profile for unexpected changes"]
        return [
            _DISTRIBUTION_REMEDIATION[d]
            for d in distributions
            if d in _DISTRIBUTION_REMEDIATION
        ]

    def _classify_fleet_movement(
        self,
        agent_drifts: dict[str, float],
        agent_archetypes: dict[str, str],
    ) -> tuple[str, dict[str, int]]:
        """Classify fleet movement as concentrated or distributed.

        Returns (movement_type, contributing_groups).
        """
        if not agent_drifts:
            return "distributed", {}

        # Identify agents above moderate threshold
        drifting = {
            aid: val for aid, val in agent_drifts.items()
            if val > _MODERATE_THRESHOLD
        }
        if not drifting:
            return "distributed", {}

        total_drift = sum(drifting.values())
        if total_drift == 0:
            return "distributed", {}

        # Sort by drift magnitude
        sorted_agents = sorted(drifting.items(), key=lambda x: x[1], reverse=True)
        top_20_count = max(1, len(sorted_agents) // 5)
        top_20_drift = sum(v for _, v in sorted_agents[:top_20_count])

        movement_type = (
            "concentrated"
            if top_20_drift / total_drift > 0.8
            else "distributed"
        )

        # Group by archetype
        contributing_groups: dict[str, int] = {}
        for aid in drifting:
            archetype = agent_archetypes.get(aid, "unknown")
            contributing_groups[archetype] = contributing_groups.get(archetype, 0) + 1

        return movement_type, contributing_groups
