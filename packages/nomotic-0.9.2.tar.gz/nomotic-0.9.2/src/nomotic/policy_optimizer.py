"""Monte Carlo policy optimizer — computing optimal intervention strategies.

For each agent, simulates multiple intervention strategies forward using
the drift dynamics model, scores each by total cost (intervention +
violation), and selects the strategy with the lowest expected cost.

Output is an InterventionPolicy: a human-readable, inspectable,
auditable, state-conditional intervention plan.
"""

from __future__ import annotations

import math
import threading
import time as _time
from dataclasses import dataclass, field
from typing import Any

from nomotic.cost_profile import CostProfile
from nomotic.drift_dynamics import DriftDynamicsModel
from nomotic.intervention_cost import InterventionCostModel

__all__ = [
    "InterventionPolicy",
    "OptimizerConfig",
    "PolicyOptimizer",
    "STRATEGIES",
]

# ── Predefined intervention strategies ─────────────────────────────────
# Each strategy is a list of (intervention_type, trigger_at_step) tuples.

STRATEGIES: dict[str, list[tuple[str, int]]] = {
    "no_op": [],  # Do nothing, let drift evolve naturally
    "early_advisory": [("advisory", 0)],  # Advisory immediately
    "wait_and_throttle": [("throttle", 25)],  # Wait 25 steps, then throttle
    "immediate_escalate": [("escalate", 0)],  # Escalate now
    "graduated": [("advisory", 0), ("throttle", 25), ("escalate", 50)],  # Graduated response
}


@dataclass(frozen=True)
class InterventionPolicy:
    """State-conditional intervention plan."""

    strategy_name: str
    expected_total_cost: float
    intervention_schedule: tuple[tuple[str, int], ...] = ()
    conditions: dict[str, str] = field(default_factory=dict)
    # e.g., {"stand_down_if": "drift < 0.15 within 25 actions",
    #        "escalate_if": "drift > 0.25"}

    confidence: float = 0.0
    """How confident the optimizer is (based on N rollouts and variance)."""

    cost_vs_naive: float = 0.0
    """Cost savings compared to naive threshold intervention."""

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-friendly dict."""
        return {
            "strategy_name": self.strategy_name,
            "expected_total_cost": round(self.expected_total_cost, 6),
            "intervention_schedule": [
                {"type": t, "trigger_step": s} for t, s in self.intervention_schedule
            ],
            "conditions": dict(self.conditions),
            "confidence": round(self.confidence, 4),
            "cost_vs_naive": round(self.cost_vs_naive, 4),
        }

    def to_readable(self) -> str:
        """Human-readable decision-tree format.

        Example::

            Policy: graduated
            Step 0: Issue advisory
            If drift < 0.15 within 25 actions: Stand down
            Step 25: Throttle if drift persists
            If drift > 0.25: Escalate
            Expected cost: 0.12 (vs 0.19 naive = 37% savings)
        """
        lines: list[str] = [f"Policy: {self.strategy_name}"]

        for intervention_type, step in self.intervention_schedule:
            label = {
                "advisory": "Issue advisory",
                "throttle": "Throttle if drift persists",
                "escalate": "Escalate",
                "tighten": "Tighten contract",
            }.get(intervention_type, intervention_type.title())
            lines.append(f"Step {step}: {label}")

        for key, value in self.conditions.items():
            readable_key = key.replace("_", " ").capitalize()
            lines.append(f"{readable_key}: {value}")

        cost_line = f"Expected cost: {self.expected_total_cost:.2f}"
        if self.cost_vs_naive > 0:
            savings_pct = self.cost_vs_naive * 100
            cost_line += f" ({savings_pct:.0f}% savings vs naive)"
        lines.append(cost_line)

        return "\n".join(lines)


@dataclass
class OptimizerConfig:
    """Configuration for the Monte Carlo policy optimizer."""

    n_rollouts: int = 200
    """Simulations per strategy."""

    timeout_seconds: float = 5.0
    """Max time per agent optimization."""

    horizon: int = 100
    """Steps to simulate forward."""

    policy_switch_threshold: float = 0.10
    """Only switch policy if >10% cost improvement."""

    strategies: dict[str, list[tuple[str, int]]] | None = None
    """Override predefined strategies."""


class PolicyOptimizer:
    """Monte Carlo policy optimizer for governance interventions.

    For each agent, evaluates multiple predefined intervention strategies
    via Monte Carlo rollouts, selecting the one with lowest expected cost
    (intervention cost + violation cost).
    """

    def __init__(
        self,
        config: OptimizerConfig | None = None,
        dynamics_model: DriftDynamicsModel | None = None,
        cost_model: InterventionCostModel | None = None,
    ) -> None:
        self._config = config or OptimizerConfig()
        self._dynamics = dynamics_model or DriftDynamicsModel()
        self._cost_model = cost_model or InterventionCostModel()
        self._current_policies: dict[str, InterventionPolicy] = {}
        self._lock = threading.Lock()

    # ── Strategy pruning ───────────────────────────────────────────

    def _prune_strategies(
        self, current_drift: float,
    ) -> dict[str, list[tuple[str, int]]]:
        """Heuristic pruning: skip irrelevant strategies.

        If drift < 0.10: only consider no_op and early_advisory.
        If drift > 0.40: skip no_op and early_advisory (too passive).
        Otherwise: consider all.
        """
        all_strategies = self._config.strategies or STRATEGIES

        if current_drift < 0.10:
            return {
                k: v for k, v in all_strategies.items()
                if k in ("no_op", "early_advisory")
            }
        if current_drift > 0.40:
            return {
                k: v for k, v in all_strategies.items()
                if k not in ("no_op", "early_advisory")
            }
        return dict(all_strategies)

    # ── Strategy simulation ────────────────────────────────────────

    def _simulate_strategy(
        self,
        strategy_name: str,
        strategy_steps: list[tuple[str, int]],
        current_drift: float,
        velocity: float,
        archetype: str,
        cost_profile: CostProfile,
        agent_id: str,
        cause_type: str = "organic",
        *,
        _deadline: float | None = None,
    ) -> tuple[float, float]:
        """Simulate one strategy N times, return (mean_cost, variance).

        For each rollout:
        1. Project drift forward using dynamics_model.project_drift().
        2. At each strategy trigger step, apply intervention:
           - Sample intervention cost from cost_model.
           - Reduce projected drift per dynamics model intervention effect.
        3. At each step, check if drift exceeds thresholds (violation).
           If yes, add violation cost from cost_profile.false_allow_cost.
        4. Total cost = sum of intervention costs + violation costs.

        Return mean and variance across N rollouts.
        """
        import random as _random

        n_rollouts = self._config.n_rollouts
        horizon = self._config.horizon
        violation_threshold = 0.30  # Default contract violation threshold
        violation_cost = cost_profile.false_allow_cost

        costs: list[float] = []

        for _ in range(n_rollouts):
            # Check timeout
            if _deadline is not None and _time.time() > _deadline:
                break

            rng = _random.Random()
            total_cost = 0.0

            # Sort strategy steps by trigger time
            sorted_steps = sorted(strategy_steps, key=lambda s: s[1])

            # Simulate the trajectory with interventions applied sequentially
            drift = current_drift
            vel = velocity
            step_idx = 0  # Index into sorted_steps

            for step in range(horizon):
                # Check if an intervention triggers at this step
                if step_idx < len(sorted_steps):
                    intv_type, trigger_step = sorted_steps[step_idx]
                    if step == trigger_step:
                        # Sample intervention cost
                        intv_cost_obj = self._cost_model.compute_cost(
                            intv_type, agent_id, cost_profile,
                        )
                        total_cost += intv_cost_obj.sample()

                        # Project drift with intervention from this point
                        remaining = horizon - step
                        if remaining > 0:
                            projected = self._dynamics.project_drift(
                                drift, vel, remaining, archetype,
                                intervention=intv_type,
                                cause_type=cause_type,
                                _rng=rng,
                            )
                            # Update drift and velocity from intervention projection
                            if len(projected) > 1:
                                drift = projected[0]
                                # Rough velocity estimate from first two projected points
                                vel = projected[1] - projected[0]
                            elif projected:
                                drift = projected[0]
                                vel = 0.0

                        step_idx += 1
                        continue

                # Natural drift evolution for this step
                projected_one = self._dynamics.project_drift(
                    drift, vel, 1, archetype,
                    cause_type=cause_type,
                    _rng=rng,
                )
                if projected_one:
                    new_drift = projected_one[0]
                    vel = new_drift - drift
                    drift = new_drift

                # Check violation
                if drift > violation_threshold:
                    total_cost += violation_cost * 0.01  # Per-step violation penalty

            costs.append(total_cost)

        if not costs:
            return (float("inf"), float("inf"))

        mean_cost = sum(costs) / len(costs)
        if len(costs) > 1:
            variance = sum((c - mean_cost) ** 2 for c in costs) / (len(costs) - 1)
        else:
            variance = 0.0

        return (mean_cost, variance)

    # ── Core optimization ──────────────────────────────────────────

    def optimize(
        self,
        agent_id: str,
        current_drift: float,
        velocity: float,
        archetype: str,
        cost_profile: CostProfile,
        drift_thresholds: dict[str, float] | None = None,
        cause_type: str = "organic",
    ) -> InterventionPolicy:
        """Find the optimal intervention policy for an agent.

        1. Prune strategy space based on current drift.
        2. For each remaining strategy, run _simulate_strategy().
        3. Select strategy with lowest mean cost.
        4. Compute confidence from variance.
        5. Compute cost_vs_naive vs immediate_escalate baseline.
        6. Check policy stability: keep current if savings < threshold.
        7. Build InterventionPolicy with conditions.
        8. Store as current policy for agent.
        """
        deadline = _time.time() + self._config.timeout_seconds

        # 1. Prune strategies
        candidates = self._prune_strategies(current_drift)

        # 2. Simulate each strategy
        results: dict[str, tuple[float, float]] = {}
        for name, steps in candidates.items():
            if _time.time() > deadline:
                break
            mean, var = self._simulate_strategy(
                name, steps, current_drift, velocity,
                archetype, cost_profile, agent_id, cause_type,
                _deadline=deadline,
            )
            results[name] = (mean, var)

        if not results:
            # Timeout with no results — return no_op as safe default
            return self._build_policy("no_op", [], 0.0, 0.0, 0.0, current_drift)

        # 3. Select best strategy (lowest mean cost)
        best_name = min(results, key=lambda k: results[k][0])
        best_mean, best_var = results[best_name]
        best_steps = candidates[best_name]

        # 4. Confidence from variance
        # High confidence when variance is low relative to mean
        if best_mean > 0 and best_var > 0:
            cv = math.sqrt(best_var) / best_mean  # coefficient of variation
            confidence = max(0.0, min(1.0, 1.0 - cv))
        elif best_mean == 0:
            confidence = 1.0  # Zero cost with zero variance = perfect
        else:
            confidence = 0.95  # Zero variance, nonzero mean = very confident

        # 5. Cost vs naive (immediate_escalate as baseline)
        naive_cost = results.get("immediate_escalate", (best_mean, 0.0))[0]
        if naive_cost > 0 and best_mean < naive_cost:
            cost_vs_naive = (naive_cost - best_mean) / naive_cost
        else:
            cost_vs_naive = 0.0

        # 6. Policy stability check
        with self._lock:
            current = self._current_policies.get(agent_id)

        if current is not None and current.expected_total_cost > 0:
            improvement = (
                (current.expected_total_cost - best_mean)
                / current.expected_total_cost
            )
            if improvement < self._config.policy_switch_threshold:
                return current

        # 7-8. Build and store policy
        policy = self._build_policy(
            best_name, best_steps, best_mean, confidence,
            cost_vs_naive, current_drift,
        )
        with self._lock:
            self._current_policies[agent_id] = policy

        return policy

    def _build_policy(
        self,
        strategy_name: str,
        steps: list[tuple[str, int]],
        expected_cost: float,
        confidence: float,
        cost_vs_naive: float,
        current_drift: float,
    ) -> InterventionPolicy:
        """Build an InterventionPolicy with derived conditions."""
        conditions: dict[str, str] = {}

        # Derive conditions from strategy steps and drift level
        if steps:
            first_type, first_step = steps[0]
            if first_type == "advisory":
                conditions["stand_down_if"] = "drift < 0.15 within 25 actions"
            if len(steps) > 1:
                conditions["escalate_if"] = f"drift > {current_drift + 0.10:.2f}"

        return InterventionPolicy(
            strategy_name=strategy_name,
            expected_total_cost=expected_cost,
            intervention_schedule=tuple(
                (t, s) for t, s in steps
            ),
            conditions=conditions,
            confidence=confidence,
            cost_vs_naive=cost_vs_naive,
        )

    # ── Multi-agent coordination ─────────────────────────────────

    def optimize_chain(
        self,
        chain: list[str],
        current_drifts: dict[str, float],
        velocities: dict[str, float],
        archetypes: dict[str, str],
        cost_profiles: dict[str, CostProfile],
        drift_thresholds: dict[str, dict[str, float]] | None = None,
        cause_types: dict[str, str] | None = None,
        propagation_attenuation: float = 0.6,
    ) -> dict[str, InterventionPolicy]:
        """Optimize intervention across a coordinated drift chain.

        For a chain A → B → C, evaluates intervening at each point.
        Intervening at the root may reduce downstream drift via
        propagation attenuation, making it cheaper than independent
        intervention on all agents.

        Parameters
        ----------
        chain:
            Ordered agent IDs forming the propagation chain.
        current_drifts:
            Per-agent current drift scores.
        velocities:
            Per-agent drift velocities.
        archetypes:
            Per-agent archetype names.
        cost_profiles:
            Per-agent cost profiles.
        propagation_attenuation:
            Fraction of drift reduction that propagates to the next
            hop in the chain (0.0–1.0). Default 0.6.

        Returns
        -------
        dict mapping each agent_id in the chain to its InterventionPolicy.
        """
        if len(chain) <= 1:
            # Single agent — fall back to standard optimize.
            agent = chain[0]
            policy = self.optimize(
                agent_id=agent,
                current_drift=current_drifts.get(agent, 0.0),
                velocity=velocities.get(agent, 0.0),
                archetype=archetypes.get(agent, "operations-coordinator"),
                cost_profile=cost_profiles.get(agent, CostProfile()),
                cause_type=(cause_types or {}).get(agent, "organic"),
            )
            return {agent: policy}

        cause_map = cause_types or {}
        violation_threshold = 0.30

        # ── Option 1: Independent intervention on each agent ──────
        independent_policies: dict[str, InterventionPolicy] = {}
        independent_total = 0.0
        for agent in chain:
            policy = self.optimize(
                agent_id=agent,
                current_drift=current_drifts.get(agent, 0.0),
                velocity=velocities.get(agent, 0.0),
                archetype=archetypes.get(agent, "operations-coordinator"),
                cost_profile=cost_profiles.get(agent, CostProfile()),
                cause_type=cause_map.get(agent, "organic"),
            )
            independent_policies[agent] = policy
            independent_total += policy.expected_total_cost

        # ── Option 2: Coordinated root intervention ───────────────
        # Intervene at each possible point; pick the cheapest fleet-wide.
        best_coord_cost = float("inf")
        best_coord_point = 0

        for intv_idx in range(len(chain)):
            intv_agent = chain[intv_idx]
            intv_drift = current_drifts.get(intv_agent, 0.0)
            intv_profile = cost_profiles.get(intv_agent, CostProfile())
            intv_archetype = archetypes.get(intv_agent, "operations-coordinator")

            # Find the best single-agent policy for the intervention point
            intv_policy = self.optimize(
                agent_id=intv_agent,
                current_drift=intv_drift,
                velocity=velocities.get(intv_agent, 0.0),
                archetype=intv_archetype,
                cost_profile=intv_profile,
                cause_type=cause_map.get(intv_agent, "organic"),
            )
            fleet_cost = intv_policy.expected_total_cost

            # Model downstream effect: drift reduction propagates with attenuation
            drift_reduction = intv_drift - intv_policy.expected_total_cost
            if drift_reduction < 0:
                drift_reduction = intv_drift * 0.5  # Assume some reduction

            remaining_reduction = drift_reduction
            for downstream_idx in range(intv_idx + 1, len(chain)):
                remaining_reduction *= propagation_attenuation
                downstream_agent = chain[downstream_idx]
                ds_drift = current_drifts.get(downstream_agent, 0.0)
                ds_profile = cost_profiles.get(downstream_agent, CostProfile())

                # Downstream drift after propagated reduction
                effective_drift = max(0.0, ds_drift - remaining_reduction)

                # Remaining violation cost for this downstream agent
                if effective_drift > violation_threshold:
                    excess = effective_drift - violation_threshold
                    fleet_cost += excess * ds_profile.false_allow_cost
                # else: no residual cost for this agent

            # Upstream agents (before intervention point) get independent policies
            for upstream_idx in range(intv_idx):
                upstream_agent = chain[upstream_idx]
                fleet_cost += independent_policies[upstream_agent].expected_total_cost

            if fleet_cost < best_coord_cost:
                best_coord_cost = fleet_cost
                best_coord_point = intv_idx

        # ── Compare and select ────────────────────────────────────
        if best_coord_cost < independent_total:
            # Build coordinated result
            result: dict[str, InterventionPolicy] = {}
            root_agent = chain[best_coord_point]
            root_policy = self.optimize(
                agent_id=root_agent,
                current_drift=current_drifts.get(root_agent, 0.0),
                velocity=velocities.get(root_agent, 0.0),
                archetype=archetypes.get(root_agent, "operations-coordinator"),
                cost_profile=cost_profiles.get(root_agent, CostProfile()),
                cause_type=cause_map.get(root_agent, "organic"),
            )

            for i, agent in enumerate(chain):
                if i < best_coord_point:
                    result[agent] = independent_policies[agent]
                elif i == best_coord_point:
                    result[agent] = root_policy
                else:
                    # Downstream agents get no_op — root intervention covers them
                    result[agent] = self._build_policy(
                        "no_op", [], 0.0, 0.9, 0.0,
                        current_drifts.get(agent, 0.0),
                    )

            with self._lock:
                for agent_id, policy in result.items():
                    self._current_policies[agent_id] = policy
            return result
        else:
            with self._lock:
                for agent_id, policy in independent_policies.items():
                    self._current_policies[agent_id] = policy
            return independent_policies

    def optimize_correlated(
        self,
        agents: list[str],
        current_drifts: dict[str, float],
        velocities: dict[str, float],
        archetypes: dict[str, str],
        cost_profiles: dict[str, CostProfile],
        upstream_fix_cost: float | None = None,
        cause_types: dict[str, str] | None = None,
    ) -> dict[str, InterventionPolicy]:
        """Optimize intervention for correlated drift (shared upstream cause).

        When multiple agents drift in the same direction due to a shared
        upstream cause, a single upstream fix may be cheaper than
        intervening on each agent independently.

        Parameters
        ----------
        agents:
            Agent IDs exhibiting correlated drift.
        current_drifts:
            Per-agent current drift scores.
        velocities:
            Per-agent drift velocities.
        archetypes:
            Per-agent archetype names.
        cost_profiles:
            Per-agent cost profiles.
        upstream_fix_cost:
            Cost of fixing the shared upstream cause. If None, estimated
            as 2x the median individual intervention cost.
        cause_types:
            Per-agent cause type overrides.

        Returns
        -------
        dict mapping each agent_id to its InterventionPolicy.
        """
        cause_map = cause_types or {}

        # ── Option 1: Independent intervention on each agent ──────
        independent_policies: dict[str, InterventionPolicy] = {}
        independent_total = 0.0
        for agent in agents:
            policy = self.optimize(
                agent_id=agent,
                current_drift=current_drifts.get(agent, 0.0),
                velocity=velocities.get(agent, 0.0),
                archetype=archetypes.get(agent, "operations-coordinator"),
                cost_profile=cost_profiles.get(agent, CostProfile()),
                cause_type=cause_map.get(agent, "organic"),
            )
            independent_policies[agent] = policy
            independent_total += policy.expected_total_cost

        # ── Option 2: Upstream fix ────────────────────────────────
        if upstream_fix_cost is None:
            # Estimate: 2x median individual cost
            costs_sorted = sorted(
                p.expected_total_cost for p in independent_policies.values()
            )
            median_cost = costs_sorted[len(costs_sorted) // 2] if costs_sorted else 0.0
            upstream_fix_cost = median_cost * 2.0

        # ── Compare and select ────────────────────────────────────
        if upstream_fix_cost < independent_total:
            # Upstream fix is cheaper — all agents get no_op with annotation
            result: dict[str, InterventionPolicy] = {}
            per_agent_cost = upstream_fix_cost / len(agents) if agents else 0.0
            for agent in agents:
                policy = InterventionPolicy(
                    strategy_name="upstream_fix",
                    expected_total_cost=per_agent_cost,
                    intervention_schedule=(),
                    conditions={
                        "action": "Fix shared upstream cause",
                        "scope": f"Covers {len(agents)} correlated agents",
                    },
                    confidence=0.8,
                    cost_vs_naive=(
                        (independent_total - upstream_fix_cost) / independent_total
                        if independent_total > 0 else 0.0
                    ),
                )
                result[agent] = policy

            with self._lock:
                for agent_id, policy in result.items():
                    self._current_policies[agent_id] = policy
            return result
        else:
            with self._lock:
                for agent_id, policy in independent_policies.items():
                    self._current_policies[agent_id] = policy
            return independent_policies

    # ── Accessors ──────────────────────────────────────────────────

    def get_policy(self, agent_id: str) -> InterventionPolicy | None:
        """Return the current policy for an agent, if any."""
        with self._lock:
            return self._current_policies.get(agent_id)
