"""Nomotic: Behavioral Control Plane™ for AI agents."""

from __future__ import annotations

import importlib

__version__ = "0.9.2"

# ── Lazy import registry ────────────────────────────────────────────────
# Maps each public attribute to the submodule that provides it.
# Modules are imported only when the attribute is first accessed, so
# ``import nomotic`` is near-instant regardless of package size.

_LAZY_MODULE_ATTRS: dict[str, list[str]] = {
    # Core governance
    "nomotic.runtime": ["GovernanceRuntime", "RuntimeConfig"],
    "nomotic.types": [
        "Action", "AgentContext", "GovernanceVerdict", "TrustProfile",
        "Verdict", "DimensionScore", "DimensionResult", "EvaluatedRule",
        "BlastRadius", "ReversibilityDeclaration", "DataSensitivity",
        "Environment", "ActionRecord", "ActionState", "Severity",
        "UserContext",
    ],
    # License and tier
    "nomotic.license": ["LicenseConfig", "ActivatedTier", "LicenseInfo", "LicenseGate"],
    # LLM configuration
    "nomotic.llm": ["LLMConfig", "NOMOTIC_CLOUD_LLM"],
    # Agent SDK (primary integration surface)
    "nomotic.sdk": ["GovernedAgent", "GovernedResponse"],
    # Executor (tool-calling governance)
    "nomotic.executor": ["GovernedToolExecutor", "ExecutionResult"],
    "nomotic.async_executor": ["AsyncGovernedToolExecutor"],
    # Signals and session
    "nomotic.signals": [
        "Signal", "SignalBundle", "SignalCatalogue", "SignalSpec",
        "PriorSystem",
    ],
    "nomotic.session": ["SessionContext", "SessionRegistry"],
    # Dimensions (base class + registry)
    "nomotic.dimensions": ["GovernanceDimension", "DimensionRegistry"],
    # Tiering
    "nomotic.tiering": ["ProductTier", "TieringConfig"],
    # Trust
    "nomotic.trust": ["TrustCalibrator", "TrustConfig"],
    # Audit
    "nomotic.audit": ["AuditTrail", "AuditRecord"],
    # Certificates and identity
    "nomotic.certificate": ["AgentCertificate", "CertStatus"],
    "nomotic.keys": ["SigningKey"],
    # Interrupt authority
    "nomotic.interrupt": ["InterruptAuthority", "ExecutionHandle"],
    # Presets
    "nomotic.presets": ["INDUSTRY_PRESET_RECOMMENDATIONS"],
    # Archetype contracts
    "nomotic.archetype_contracts": [
        "ArchetypeContract",
        "ARCHETYPE_CONTRACTS",
        "classify_action_category",
        "get_contract",
    ],
}

# Special-case attrs that need renaming or construction
_SPECIAL_ATTRS: dict[str, tuple[str, str]] = {
    # public name -> (module, original name)
    "PRESETS": ("nomotic.presets", "_PRESETS"),
}

# Build reverse lookup: attr name -> module path
_ATTR_TO_MODULE: dict[str, str] = {}
for _mod, _attrs in _LAZY_MODULE_ATTRS.items():
    for _attr in _attrs:
        _ATTR_TO_MODULE[_attr] = _mod
del _mod, _attrs, _attr


def __getattr__(name: str) -> object:
    # Nomotic convenience alias
    if name == "Nomotic":
        from nomotic.runtime import GovernanceRuntime
        globals()["Nomotic"] = GovernanceRuntime
        return GovernanceRuntime

    if name in _ATTR_TO_MODULE:
        module = importlib.import_module(_ATTR_TO_MODULE[name])
        value = getattr(module, name)
        globals()[name] = value  # cache for subsequent access
        return value

    if name in _SPECIAL_ATTRS:
        mod_path, original_name = _SPECIAL_ATTRS[name]
        module = importlib.import_module(mod_path)
        value = getattr(module, original_name)
        globals()[name] = value
        return value

    raise AttributeError(f"module 'nomotic' has no attribute {name!r}")


__all__ = [
    # Version
    "__version__",
    # Core governance
    "GovernanceRuntime",
    "RuntimeConfig",
    "Nomotic",
    # Types
    "Action",
    "AgentContext",
    "GovernanceVerdict",
    "TrustProfile",
    "Verdict",
    "DimensionScore",
    "DimensionResult",
    "EvaluatedRule",
    "BlastRadius",
    "ReversibilityDeclaration",
    "DataSensitivity",
    "Environment",
    "ActionRecord",
    "ActionState",
    "Severity",
    "UserContext",
    # License and tier
    "LicenseConfig",
    "ActivatedTier",
    "LicenseInfo",
    "LicenseGate",
    # LLM configuration
    "LLMConfig",
    "NOMOTIC_CLOUD_LLM",
    # Agent SDK
    "GovernedAgent",
    "GovernedResponse",
    # Executor
    "GovernedToolExecutor",
    "ExecutionResult",
    "AsyncGovernedToolExecutor",
    # Signals and session
    "Signal",
    "SignalBundle",
    "SignalCatalogue",
    "SignalSpec",
    "PriorSystem",
    "SessionContext",
    "SessionRegistry",
    # Dimensions
    "GovernanceDimension",
    "DimensionRegistry",
    # Tiering
    "ProductTier",
    "TieringConfig",
    # Trust
    "TrustCalibrator",
    "TrustConfig",
    # Audit
    "AuditTrail",
    "AuditRecord",
    # Certificates and identity
    "AgentCertificate",
    "CertStatus",
    "SigningKey",
    # Interrupt authority
    "InterruptAuthority",
    "ExecutionHandle",
    # Presets
    "PRESETS",
    "INDUSTRY_PRESET_RECOMMENDATIONS",
    # Archetype contracts
    "ArchetypeContract",
    "ARCHETYPE_CONTRACTS",
    "classify_action_category",
    "get_contract",
]
