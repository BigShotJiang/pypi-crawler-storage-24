"""Value of Information — should governance escalate to human review?

ESCALATE is an investment decision: the system pays a cost (latency,
reviewer attention, process interruption) in exchange for expected
information gain. VOI quantifies this tradeoff.

Three signals drive VOI:
1. Dimension Score Entropy — do the dimensions agree or disagree?
2. Trust-Weighted Uncertainty — how reliable is the system's model?
3. Cost-Profile Sensitivity — how much is at stake?

Escalation cost factors in reviewer fatigue from the HumanDriftMonitor.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from nomotic.cost_profile import CostProfile
from nomotic.human_drift import HumanDriftResult
from nomotic.types import DimensionScore, TrustProfile

__all__ = ["VOIConfig", "VOIEngine", "VOIResult"]


@dataclass(frozen=True)
class VOIResult:
    """Result of a Value of Information computation."""

    voi_score: float  # 0.0-1.0, composite VOI
    escalation_cost: float  # Estimated cost of escalating
    should_escalate: bool  # voi_score > escalation_cost

    # Component scores
    dimension_entropy: float = 0.0  # 0.0 = perfect agreement, 1.0 = max disagreement
    trust_uncertainty: float = 0.0  # 0.0 = high-trust (reliable model), 1.0 = low-trust
    cost_sensitivity: float = 0.0  # 0.0 = low stakes, 1.0 = high stakes

    # Diagnostic info
    expected_verdict_shift_probability: float = 0.0  # How likely is human to change verdict
    dominant_disagreement: list[str] = field(default_factory=list)
    recommended_path: str = "none"  # "none", "request_context", "secondary_check", "human_review"

    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "voi_score": round(self.voi_score, 4),
            "escalation_cost": round(self.escalation_cost, 4),
            "should_escalate": self.should_escalate,
            "dimension_entropy": round(self.dimension_entropy, 4),
            "trust_uncertainty": round(self.trust_uncertainty, 4),
            "cost_sensitivity": round(self.cost_sensitivity, 4),
            "expected_verdict_shift_probability": round(
                self.expected_verdict_shift_probability, 4,
            ),
            "dominant_disagreement": list(self.dominant_disagreement),
            "recommended_path": self.recommended_path,
            "detail": self.detail,
        }


@dataclass
class VOIConfig:
    """Configuration for VOI computation."""

    # Signal weights (sum should be ~1.0)
    entropy_weight: float = 0.40
    trust_weight: float = 0.25
    cost_weight: float = 0.35

    # Dimension-specific disagreement weights.
    # Dimensions listed here contribute more to entropy when they disagree.
    dimension_disagreement_weights: dict[str, float] = field(default_factory=lambda: {
        "ethical_alignment": 1.5,
        "scope_compliance": 1.3,
        "behavioral_consistency": 1.2,
    })
    # All other dimensions default to 1.0.

    # Escalation cost parameters
    base_latency_cost: float = 0.05
    base_attention_cost: float = 0.10
    reviewer_fatigue_threshold: float = 0.85  # approval_rate above this → fatigued
    reviewer_fatigue_multiplier: float = 2.0

    # Trust floor: agents below this always escalate regardless of VOI
    trust_floor: float = 0.2

    # Minimum VOI threshold (conservative initial default)
    min_voi_to_escalate: float = 0.3


class VOIEngine:
    """Computes Value of Information for potential escalation decisions.

    Pure computation — no side effects. Takes dimension scores, trust,
    cost profile, and reviewer state, returns VOIResult.
    """

    def __init__(self, config: VOIConfig | None = None) -> None:
        self._config = config or VOIConfig()

    @property
    def config(self) -> VOIConfig:
        return self._config

    # ── public API ────────────────────────────────────────────────────

    def compute(
        self,
        scores: list[DimensionScore],
        trust_profile: TrustProfile,
        cost_profile: CostProfile | None = None,
        reviewer_drift: HumanDriftResult | None = None,
        ucs: float = 0.5,
    ) -> VOIResult:
        """Compute VOI for a potential escalation.

        See module docstring for the three signal descriptions.
        """
        cfg = self._config

        # 1. Dimension entropy
        dimension_entropy, dominant = self._dimension_entropy(scores)

        # 2. Trust uncertainty
        trust_uncertainty = self._trust_uncertainty(trust_profile)

        # 3. Cost sensitivity
        cost_sensitivity = self._cost_sensitivity(cost_profile)

        # 4. Composite VOI
        voi_score = (
            cfg.entropy_weight * dimension_entropy
            + cfg.trust_weight * trust_uncertainty
            + cfg.cost_weight * cost_sensitivity
        )
        voi_score = max(0.0, min(1.0, voi_score))

        # 5. Escalation cost
        escalation_cost = self._escalation_cost(cost_profile, reviewer_drift)

        # 6. Expected verdict shift probability
        shift_prob = self._verdict_shift_probability(dimension_entropy, ucs)

        # 7. Decision
        if trust_profile.overall_trust < cfg.trust_floor:
            should_escalate = True
            detail = (
                f"trust {trust_profile.overall_trust:.2f} below floor "
                f"{cfg.trust_floor:.2f} — forced escalation"
            )
        elif voi_score > max(escalation_cost, cfg.min_voi_to_escalate):
            should_escalate = True
            detail = (
                f"voi {voi_score:.3f} exceeds cost {escalation_cost:.3f} "
                f"and min threshold {cfg.min_voi_to_escalate:.2f}"
            )
        else:
            should_escalate = False
            detail = (
                f"voi {voi_score:.3f} does not exceed "
                f"max(cost={escalation_cost:.3f}, min={cfg.min_voi_to_escalate:.2f})"
            )

        # 8. Recommended path
        recommended_path = self._recommended_path(should_escalate, voi_score)

        return VOIResult(
            voi_score=voi_score,
            escalation_cost=escalation_cost,
            should_escalate=should_escalate,
            dimension_entropy=dimension_entropy,
            trust_uncertainty=trust_uncertainty,
            cost_sensitivity=cost_sensitivity,
            expected_verdict_shift_probability=shift_prob,
            dominant_disagreement=dominant,
            recommended_path=recommended_path,
            detail=detail,
        )

    # ── internal helpers ──────────────────────────────────────────────

    def _dimension_entropy(
        self, scores: list[DimensionScore],
    ) -> tuple[float, list[str]]:
        """Compute weighted dimension entropy and identify dominant disagreements.

        Uses mean weighted deviation normalized against the theoretical maximum.
        Every dimension's deviation from the mean contributes, scaled by its
        disagreement weight from the config.
        """
        if not scores:
            return 0.0, []

        values = [s.score for s in scores]
        mean = sum(values) / len(values)

        cfg = self._config

        # Compute weighted deviation for each dimension
        contributions: list[tuple[str, float]] = []
        for s in scores:
            deviation = abs(s.score - mean)
            weight = cfg.dimension_disagreement_weights.get(s.dimension_name, 1.0)
            contributions.append((s.dimension_name, deviation * weight))

        total_weighted = sum(c for _, c in contributions)
        if total_weighted == 0:
            return 0.0, []

        # Normalize: average weighted deviation / max theoretical weighted deviation.
        # Max theoretical deviation from the mean is 0.5 (when mean=0.5 and
        # scores are at 0 or 1). We use the max disagreement weight in the set.
        avg_weighted = total_weighted / len(contributions)
        max_weight = max(
            (cfg.dimension_disagreement_weights.get(s.dimension_name, 1.0) for s in scores),
            default=1.0,
        )
        entropy = min(1.0, avg_weighted / (0.5 * max(max_weight, 1.0)))

        # Sort by contribution, pick top 3
        contributions.sort(key=lambda x: x[1], reverse=True)
        dominant = [name for name, c in contributions[:3] if c > 0]

        return entropy, dominant

    def _trust_uncertainty(self, trust_profile: TrustProfile) -> float:
        """Compute uncertainty from trust profile."""
        base_uncertainty = 1.0 - trust_profile.overall_trust

        # Scale by observation count: few observations = higher uncertainty
        total_observations = trust_profile.successful_actions + trust_profile.violation_count
        if total_observations < 10:
            # Low observation count — inflate uncertainty
            observation_factor = 1.0 + (10 - total_observations) * 0.05
            base_uncertainty = min(1.0, base_uncertainty * observation_factor)

        return max(0.0, min(1.0, base_uncertainty))

    def _cost_sensitivity(self, cost_profile: CostProfile | None) -> float:
        """Compute cost sensitivity from cost profile."""
        if cost_profile is None:
            return 0.3  # moderate default

        return max(cost_profile.false_allow_cost, cost_profile.false_deny_cost)

    def _escalation_cost(
        self,
        cost_profile: CostProfile | None,
        reviewer_drift: HumanDriftResult | None,
    ) -> float:
        """Compute escalation cost including reviewer fatigue."""
        cfg = self._config
        base_cost = cfg.base_latency_cost + cfg.base_attention_cost

        if cost_profile is not None:
            base_cost += cost_profile.escalation_latency_cost
            base_cost += cost_profile.escalation_interruption_cost

        # Reviewer fatigue inflates cost
        if reviewer_drift is not None:
            approval_rate = reviewer_drift.recent_profile.approval_rate
            if approval_rate > cfg.reviewer_fatigue_threshold:
                base_cost *= cfg.reviewer_fatigue_multiplier

        return base_cost

    @staticmethod
    def _verdict_shift_probability(dimension_entropy: float, ucs: float) -> float:
        """Estimate probability that human review would change the verdict."""
        # Higher entropy + UCS near 0.5 = higher shift probability
        ambiguity_factor = 1.0 - abs(ucs - 0.5) * 2.0
        ambiguity_factor = max(0.0, ambiguity_factor)
        return dimension_entropy * ambiguity_factor

    @staticmethod
    def _recommended_path(should_escalate: bool, voi_score: float) -> str:
        """Determine the recommended escalation path."""
        if not should_escalate:
            return "none"
        if voi_score < 0.5:
            return "request_context"
        if voi_score < 0.7:
            return "secondary_check"
        return "human_review"
