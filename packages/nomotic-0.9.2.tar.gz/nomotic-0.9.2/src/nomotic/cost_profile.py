"""Cost profiles — asymmetric error cost specifications for decision-theoretic governance.

A CostProfile specifies the cost of each governance error type for an
agent or action context. The Behavioral Control Plane uses these costs
to derive optimal decision boundaries rather than relying on static
allow/deny thresholds.

Cost profiles support three modes:
- Categorical: LOW, MODERATE, HIGH, CRITICAL (mapped to numeric defaults)
- Numeric: precise float values for domains with actuarial data
- Hybrid: categorical defaults with numeric overrides per invariant

The optimal threshold is derived from signal detection theory:
theta = C_FP / (C_FP + C_FN) where C_FP is the cost of false denial
and C_FN is the cost of false allow.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "BALANCED",
    "CONSERVATIVE",
    "COST_LEVELS",
    "CostProfile",
    "PERMISSIVE",
]

# Cost scale constants — configurable at the organization level.
COST_LEVELS: dict[str, float] = {
    "LOW": 0.1,
    "MODERATE": 0.3,
    "HIGH": 0.6,
    "CRITICAL": 1.0,
}


@dataclass(frozen=True)
class CostProfile:
    """Asymmetric error cost specification.

    Specifies how costly each type of governance error is for this
    agent or context. Used to derive dynamic decision thresholds.
    """

    # Primary cost axes
    false_allow_cost: float = 0.3    # C_FN: cost of allowing a bad action
    false_deny_cost: float = 0.3     # C_FP: cost of denying a good action

    # Categorical labels (for display and operator convenience)
    false_allow_label: str = "MODERATE"  # "LOW", "MODERATE", "HIGH", "CRITICAL"
    false_deny_label: str = "MODERATE"

    # Per-invariant cost overrides (hybrid mode)
    # Maps invariant_id -> {"false_allow": float, "false_deny": float}
    invariant_overrides: dict[str, dict[str, float]] = field(default_factory=dict)

    # Escalation cost parameters (used by VOI)
    escalation_latency_cost: float = 0.1     # Cost of pausing for review
    escalation_interruption_cost: float = 0.1  # Cost of process interruption

    # Zone multiplier (production > staging > development)
    zone_multiplier: float = 1.0

    def effective_false_allow(self, invariant_id: str | None = None) -> float:
        """Get the effective false-allow cost, checking invariant overrides first."""
        if invariant_id and invariant_id in self.invariant_overrides:
            base = self.invariant_overrides[invariant_id].get(
                "false_allow", self.false_allow_cost,
            )
            return base * self.zone_multiplier
        return self.false_allow_cost * self.zone_multiplier

    def effective_false_deny(self, invariant_id: str | None = None) -> float:
        """Get the effective false-deny cost, checking invariant overrides first."""
        if invariant_id and invariant_id in self.invariant_overrides:
            base = self.invariant_overrides[invariant_id].get(
                "false_deny", self.false_deny_cost,
            )
            return base * self.zone_multiplier
        return self.false_deny_cost * self.zone_multiplier

    def optimal_allow_threshold(self, invariant_id: str | None = None) -> float:
        """Derive optimal allow threshold from cost profile.

        theta = C_FP / (C_FP + C_FN)

        When false allows are catastrophic (high C_FN), threshold drops -> deny more.
        When false denials are expensive (high C_FP), threshold rises -> allow more.

        Clamped to [0.15, 0.95] to prevent extreme thresholds.
        """
        cfp = self.effective_false_deny(invariant_id)
        cfn = self.effective_false_allow(invariant_id)
        if cfp + cfn == 0:
            return 0.5
        raw = cfp / (cfp + cfn)
        return max(0.15, min(0.95, raw))

    def optimal_deny_threshold(self, invariant_id: str | None = None) -> float:
        """Derive optimal deny threshold. Symmetric to allow threshold.

        deny_threshold = allow_threshold - ambiguity_zone_width
        Ambiguity zone width scales with stakes: high stakes = narrow zone.

        Clamped to [0.05, 0.85].
        """
        allow_t = self.optimal_allow_threshold(invariant_id)
        # Ambiguity zone width: inversely proportional to max cost
        max_cost = max(
            self.effective_false_allow(invariant_id),
            self.effective_false_deny(invariant_id),
        )
        zone_width = max(0.05, 0.4 * (1.0 - max_cost))  # High cost = narrow zone
        deny_t = allow_t - zone_width
        return max(0.05, min(0.85, deny_t))

    def to_dict(self) -> dict[str, Any]:
        """Full JSON serialization."""
        return {
            "false_allow_cost": self.false_allow_cost,
            "false_deny_cost": self.false_deny_cost,
            "false_allow_label": self.false_allow_label,
            "false_deny_label": self.false_deny_label,
            "invariant_overrides": dict(self.invariant_overrides),
            "escalation_latency_cost": self.escalation_latency_cost,
            "escalation_interruption_cost": self.escalation_interruption_cost,
            "zone_multiplier": self.zone_multiplier,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CostProfile:
        """Deserialize from dict."""
        if not data:
            return cls()
        return cls(
            false_allow_cost=data.get("false_allow_cost", 0.3),
            false_deny_cost=data.get("false_deny_cost", 0.3),
            false_allow_label=data.get("false_allow_label", "MODERATE"),
            false_deny_label=data.get("false_deny_label", "MODERATE"),
            invariant_overrides=data.get("invariant_overrides", {}),
            escalation_latency_cost=data.get("escalation_latency_cost", 0.1),
            escalation_interruption_cost=data.get("escalation_interruption_cost", 0.1),
            zone_multiplier=data.get("zone_multiplier", 1.0),
        )

    @classmethod
    def from_categorical(
        cls,
        false_allow: str = "MODERATE",
        false_deny: str = "MODERATE",
        **kwargs: Any,
    ) -> CostProfile:
        """Create from categorical labels. Maps labels to numeric values using COST_LEVELS."""
        return cls(
            false_allow_cost=COST_LEVELS[false_allow],
            false_deny_cost=COST_LEVELS[false_deny],
            false_allow_label=false_allow,
            false_deny_label=false_deny,
            **kwargs,
        )


# Predefined profiles for common domains
CONSERVATIVE = CostProfile.from_categorical("CRITICAL", "LOW")    # Financial, security
BALANCED = CostProfile.from_categorical("MODERATE", "MODERATE")    # General purpose
PERMISSIVE = CostProfile.from_categorical("LOW", "HIGH")           # Customer service, content
