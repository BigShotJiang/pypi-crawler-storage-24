"""Semantic anchoring — governing what agents mean, not just what they do.

Semantic drift is the fifth distribution in Nomotic's behavioral fingerprint.
While action, target, temporal, and outcome distributions track the structural
shape of behavior, semantic drift tracks the meaning-level mapping between
an agent's instructions and its actions.

An agent that is structurally stable — same action types, same targets,
same timing, same approval rate — can still drift semantically if the
operational meaning of its instructions shifts. 'Research' starts mapping
to booking actions. 'Analyze' starts mapping to execution. The structural
fingerprint sees nothing. The semantic fingerprint catches everything.

This module is part of the Behavioral Control Plane's Drift Taxonomy:
semantic drift is a distribution (what changed), not a scope (where/how).
It can appear in any drift scope: individual agent semantic drift, fleet
semantic drift, correlated semantic drift, coordinated semantic drift.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any

from nomotic.types import Action

__all__ = [
    "SemanticAnchor",
    "SemanticActionMap",
    "SemanticDriftScore",
    "SemanticObserver",
]


@dataclass(frozen=True)
class SemanticAnchor:
    """Maps an instruction term to its expected action pattern.

    Created at contract time (or from archetype defaults). Represents what
    a term SHOULD mean operationally. Drift is measured against these anchors.
    """

    term: str
    """The instruction term (e.g., "research", "analyze", "book")."""

    expected_action_distribution: dict[str, float]
    """What actions this term should map to (e.g., {"read": 0.9, "query": 0.1})."""

    expected_target_distribution: dict[str, float]
    """What targets (e.g., {"search_api": 0.7, "reviews": 0.3})."""

    tolerance: float = 0.15
    """Max allowed JSD drift from anchor before flagging (0.0-1.0)."""

    def to_dict(self) -> dict[str, Any]:
        return {
            "term": self.term,
            "expected_action_distribution": dict(self.expected_action_distribution),
            "expected_target_distribution": dict(self.expected_target_distribution),
            "tolerance": self.tolerance,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SemanticAnchor:
        return cls(
            term=data["term"],
            expected_action_distribution=data.get("expected_action_distribution", {}),
            expected_target_distribution=data.get("expected_target_distribution", {}),
            tolerance=data.get("tolerance", 0.15),
        )


@dataclass
class SemanticActionMap:
    """Tracks the observed mapping between instruction terms and action patterns.

    This is the semantic fingerprint. For each instruction term the agent
    has operated under, what action and target distributions has it actually
    produced?
    """

    agent_id: str

    # Per-term raw counts and computed distributions
    # Internal: _term_data[term] = {
    #   "action_counts": {"read": 42, "write": 3},
    #   "target_counts": {"search_api": 30, "booking_api": 15},
    #   "total": 45,
    #   "action_distribution": {"read": 0.93, "write": 0.07},
    #   "target_distribution": {"search_api": 0.67, "booking_api": 0.33},
    # }
    _term_data: dict[str, dict[str, Any]] = field(default_factory=dict)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False, compare=False)

    def observe(self, term: str, action_type: str, target: str) -> None:
        """Record that instruction term ``term`` produced this action against this target."""
        with self._lock:
            if term not in self._term_data:
                self._term_data[term] = {
                    "action_counts": {},
                    "target_counts": {},
                    "total": 0,
                    "action_distribution": {},
                    "target_distribution": {},
                }
            td = self._term_data[term]
            td["action_counts"][action_type] = td["action_counts"].get(action_type, 0) + 1
            td["target_counts"][target] = td["target_counts"].get(target, 0) + 1
            td["total"] += 1
            total = td["total"]
            td["action_distribution"] = {
                k: v / total for k, v in td["action_counts"].items()
            }
            td["target_distribution"] = {
                k: v / total for k, v in td["target_counts"].items()
            }

    def get_term_distribution(self, term: str) -> dict[str, Any] | None:
        """Get the observed action/target distributions for a specific term.

        Returns dict with keys: action_distribution, target_distribution, total.
        Or ``None`` if no observations for this term.
        """
        with self._lock:
            td = self._term_data.get(term)
            if td is None:
                return None
            return {
                "action_distribution": dict(td["action_distribution"]),
                "target_distribution": dict(td["target_distribution"]),
                "total": td["total"],
            }

    def compute_drift(self, anchors: list[SemanticAnchor]) -> SemanticDriftScore:
        """Compare observed term distributions against anchors.

        For each anchor, computes JSD between expected and observed distributions.
        Per-term drift = 0.6 * action_jsd + 0.4 * target_jsd.
        Overall is the observation-count-weighted average of per-term drifts.
        """
        from nomotic.drift import _jsd

        per_term: dict[str, float] = {}
        weights: dict[str, int] = {}

        with self._lock:
            for anchor in anchors:
                td = self._term_data.get(anchor.term)
                if td is None or td["total"] == 0:
                    continue
                action_jsd = _jsd(anchor.expected_action_distribution, td["action_distribution"])
                target_jsd = _jsd(anchor.expected_target_distribution, td["target_distribution"])
                term_drift = 0.6 * action_jsd + 0.4 * target_jsd
                per_term[anchor.term] = term_drift
                weights[anchor.term] = td["total"]

        if not per_term:
            return SemanticDriftScore(overall=0.0)

        # Weighted average by observation count
        total_weight = sum(weights.values())
        overall = sum(per_term[t] * weights[t] for t in per_term) / total_weight
        overall = max(0.0, min(1.0, overall))

        most_drifted_term = max(per_term, key=lambda t: per_term[t])
        detail = f"Term '{most_drifted_term}' shifted (drift={per_term[most_drifted_term]:.2f})"

        return SemanticDriftScore(
            overall=overall,
            per_term=per_term,
            most_drifted_term=most_drifted_term,
            detail=detail,
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize. Include per-term distributions and counts."""
        with self._lock:
            terms: dict[str, Any] = {}
            for term, td in self._term_data.items():
                terms[term] = {
                    "action_counts": dict(td["action_counts"]),
                    "target_counts": dict(td["target_counts"]),
                    "total": td["total"],
                    "action_distribution": dict(td["action_distribution"]),
                    "target_distribution": dict(td["target_distribution"]),
                }
            return {
                "agent_id": self.agent_id,
                "term_data": terms,
            }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SemanticActionMap:
        sam = cls(agent_id=data["agent_id"])
        for term, td in data.get("term_data", {}).items():
            sam._term_data[term] = {
                "action_counts": dict(td.get("action_counts", {})),
                "target_counts": dict(td.get("target_counts", {})),
                "total": td.get("total", 0),
                "action_distribution": dict(td.get("action_distribution", {})),
                "target_distribution": dict(td.get("target_distribution", {})),
            }
        return sam


@dataclass(frozen=True)
class SemanticDriftScore:
    """Drift score for the semantic distribution."""

    overall: float = 0.0
    """Aggregate semantic drift (0.0-1.0)."""

    per_term: dict[str, float] = field(default_factory=dict)
    """Per-term drift scores: term -> drift score."""

    most_drifted_term: str = ""
    """Which term drifted most."""

    detail: str = ""
    """Human-readable: "Term 'research' shifted from read-heavy to write-heavy"."""

    @property
    def severity(self) -> str:
        """Same thresholds as DriftScore: none/low/moderate/high/critical."""
        if self.overall < 0.05:
            return "none"
        if self.overall < 0.15:
            return "low"
        if self.overall < 0.35:
            return "moderate"
        if self.overall < 0.60:
            return "high"
        return "critical"

    def to_dict(self) -> dict[str, Any]:
        return {
            "overall": round(self.overall, 4),
            "per_term": {k: round(v, 4) for k, v in self.per_term.items()},
            "most_drifted_term": self.most_drifted_term,
            "detail": self.detail,
            "severity": self.severity,
        }


class SemanticObserver:
    """Observes governance evaluations and maintains semantic-action maps.

    Sits alongside FingerprintObserver in the behavioral observation layer.
    When instruction context is available, tracks which instruction terms
    map to which actions.
    """

    def __init__(self) -> None:
        self._maps: dict[str, SemanticActionMap] = {}  # agent_id -> map
        self._anchors: dict[str, list[SemanticAnchor]] = {}  # agent_id -> anchors
        self._lock = threading.Lock()

    def set_anchors(self, agent_id: str, anchors: list[SemanticAnchor]) -> None:
        """Set semantic anchors for an agent (typically from BehavioralContract)."""
        with self._lock:
            self._anchors[agent_id] = list(anchors)

    def get_anchors(self, agent_id: str) -> list[SemanticAnchor]:
        """Get current anchors for an agent. Empty list if none set."""
        with self._lock:
            return list(self._anchors.get(agent_id, []))

    def observe(
        self,
        agent_id: str,
        action: Action,
        instruction_context: str | None = None,
    ) -> None:
        """Record an observation.

        Extracts instruction terms from the context and records the
        action-to-term mapping in the agent's semantic action map.
        """
        # 1. Determine instruction context
        ctx = instruction_context
        if ctx is None and hasattr(action, "parameters") and action.parameters:
            ctx = (
                action.parameters.get("instruction_context")
                or action.parameters.get("task_description")
                or action.parameters.get("goal")
            )

        # 2. Extract matching terms
        with self._lock:
            anchors = self._anchors.get(agent_id, [])
            if agent_id not in self._maps:
                self._maps[agent_id] = SemanticActionMap(agent_id=agent_id)
            sem_map = self._maps[agent_id]

        if ctx is None:
            # No instruction context at all — record under __untagged__
            sem_map.observe("__untagged__", action.action_type, action.target)
            return

        ctx_lower = ctx.lower()

        # Match against anchor terms
        matched_terms: list[str] = []
        if anchors:
            for anchor in anchors:
                if anchor.term.lower() in ctx_lower:
                    matched_terms.append(anchor.term)

        if not matched_terms:
            # No anchor matches — use the context as a single term
            term = ctx_lower.strip()[:50]
            matched_terms = [term]

        for term in matched_terms:
            sem_map.observe(term, action.action_type, action.target)

    def get_semantic_drift(self, agent_id: str) -> SemanticDriftScore | None:
        """Compute current semantic drift against anchors.

        Returns ``None`` if no anchors set for this agent.
        Returns ``SemanticDriftScore(overall=0.0)`` if no observations.
        """
        with self._lock:
            anchors = self._anchors.get(agent_id)
            if anchors is None:
                return None
            sem_map = self._maps.get(agent_id)

        if not anchors:
            return None

        if sem_map is None:
            return SemanticDriftScore(overall=0.0)

        return sem_map.compute_drift(anchors)

    def get_map(self, agent_id: str) -> SemanticActionMap | None:
        """Get the current semantic-action map for an agent."""
        with self._lock:
            return self._maps.get(agent_id)

    def reset(self, agent_id: str) -> None:
        """Remove agent's semantic map and anchors."""
        with self._lock:
            self._maps.pop(agent_id, None)
            self._anchors.pop(agent_id, None)
