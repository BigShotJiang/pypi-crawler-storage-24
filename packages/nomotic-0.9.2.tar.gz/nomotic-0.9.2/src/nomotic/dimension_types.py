"""Structured types for deterministic dimension evaluation.

ScopeDefinition, AuthorityRule, and AuthorityGroup replace raw strings
and lambdas as the primary interfaces for ScopeCompliance and
AuthorityVerification dimensions.
"""

from __future__ import annotations

import fnmatch
import time
from dataclasses import dataclass, field
from typing import Any

from nomotic.types import Environment

__all__ = [
    "AuthorityGroup",
    "AuthorityRule",
    "ScopeDefinition",
]


@dataclass(frozen=True)
class ScopeDefinition:
    """A single scope permission: action_type + target_pattern + environment.

    action_type: The permitted action (e.g. "read", "write", "*").
    target_pattern: Glob pattern for permitted targets (e.g. "logs/*", "*").
    environment: If set, scope only applies in this environment; None = any.
    """

    action_type: str
    target_pattern: str = "*"
    environment: Environment | None = None

    def matches(self, action_type: str, target: str, environment: Environment | None) -> bool:
        """Return True if this scope covers the given action."""
        # Action type check
        if self.action_type != "*" and self.action_type != action_type:
            return False
        # Target pattern check
        if self.target_pattern != "*" and not fnmatch.fnmatch(target, self.target_pattern):
            return False
        # Environment check
        if self.environment is not None and self.environment != environment:
            return False
        return True

    @property
    def is_wildcard(self) -> bool:
        """True if this scope uses a wildcard action_type."""
        return self.action_type == "*"


@dataclass
class AuthorityRule:
    """A single declarative authority rule.

    rule_id: Stable identifier for this rule.
    description: Human-readable description.
    condition: Expression string (e.g. "agent_tier >= 2").
    logic: How this rule combines with others in a group ("AND" | "OR").
    expires_at: Unix timestamp — None = permanent.
    """

    rule_id: str
    description: str
    condition: str
    logic: str = "AND"
    expires_at: float | None = None

    def is_expired(self, now: float | None = None) -> bool:
        if self.expires_at is None:
            return False
        return (now or time.time()) >= self.expires_at

    def evaluate(self, variables: dict[str, Any]) -> bool:
        """Evaluate the condition against provided variables.

        Uses a restricted eval with only the supplied variables visible.
        Returns False if evaluation fails or the condition is not met.
        """
        try:
            return bool(eval(self.condition, {"__builtins__": {}}, variables))  # noqa: S307
        except Exception:
            return False


@dataclass
class AuthorityGroup:
    """Combines multiple AuthorityRule instances with declared logic.

    rules: The authority rules in this group.
    logic: "AND" (all must pass) or "OR" (at least one must pass).
    """

    rules: list[AuthorityRule] = field(default_factory=list)
    logic: str = "AND"

    def evaluate(self, variables: dict[str, Any], now: float | None = None) -> tuple[bool, list[tuple[AuthorityRule, str]]]:
        """Evaluate all rules, returning (passed, [(rule, outcome)]).

        Expired rules are scored as failed and logged with outcome "expired".
        """
        results: list[tuple[AuthorityRule, str]] = []
        passing = 0
        current_time = now or time.time()

        for rule in self.rules:
            if rule.is_expired(current_time):
                results.append((rule, "expired"))
                continue
            if rule.evaluate(variables):
                results.append((rule, "pass"))
                passing += 1
            else:
                results.append((rule, "fail"))

        if not self.rules:
            return True, results

        if self.logic == "OR":
            return passing > 0, results
        # AND: all non-expired must pass, and at least one must be non-expired
        non_expired = [(r, o) for r, o in results if o != "expired"]
        if not non_expired:
            return False, results
        return all(o == "pass" for _, o in non_expired), results
