"""Session Context Accumulation — real-time signal tracking across evaluations.

Each governance evaluation normally starts with a fresh context snapshot.
Session-generated signals (a customer stating a reason, contradicting
themselves, making escalating requests) are lost between evaluations.

This module introduces ``SessionContext`` which accumulates signals as a
session progresses, ``SessionContradiction`` which detects contradictions
between actions, and ``SessionRegistry`` which provides thread-safe
management of active sessions.

Session signals override file-feed signals, which override priors, giving
the governance runtime a richer view of in-session behavior.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any

from nomotic.types import Action, Verdict

__all__ = [
    "SessionContradiction",
    "SessionContext",
    "SessionRegistry",
    "SessionSignalUpdate",
]


# ── Data classes ───────────────────────────────────────────────────────


@dataclass
class SessionSignalUpdate:
    """A signal update generated during a session."""

    signal_name: str
    value: Any
    confidence: float
    source: str  # "agent_declared", "behavior_inferred", "contradiction_detected"
    timestamp: float = field(default_factory=time.time)


@dataclass
class SessionContradiction:
    """A detected contradiction within a session."""

    prior_action_id: str
    current_action_id: str
    contradiction_type: str  # "goal_change", "scope_expansion", "trust_reversal"
    confidence: float


# ── Contradiction detection helpers ────────────────────────────────────

_CONTRADICTION_DETECTORS: list[
    tuple[str, Any]
] = []  # populated at module level below


def _detect_goal_change(prior: Action, current: Action) -> float:
    """Return confidence (0.0–1.0) that a goal contradiction occurred."""
    if prior.declared_goal and current.declared_goal:
        if prior.declared_goal != current.declared_goal:
            # Different goal types are a stronger signal
            if prior.goal_type and current.goal_type and prior.goal_type != current.goal_type:
                return 0.85
            return 0.6
    return 0.0


def _detect_scope_expansion(prior: Action, current: Action) -> float:
    """Return confidence that the scope of requests is expanding."""
    confidence = 0.0

    # Blast radius escalation
    _radius_order = {"single_record": 0, "subset": 1, "system_wide": 2}
    if prior.blast_radius and current.blast_radius:
        prior_level = _radius_order.get(prior.blast_radius.value, 0)
        current_level = _radius_order.get(current.blast_radius.value, 0)
        if current_level > prior_level:
            confidence = max(confidence, 0.5 + 0.2 * (current_level - prior_level))

    # Data sensitivity escalation
    _sensitivity_order = {
        "public": 0, "internal": 1, "confidential": 2,
        "pii": 3, "phi": 4, "financial": 4, "classified": 5,
    }
    if prior.data_sensitivity and current.data_sensitivity:
        prior_level = _sensitivity_order.get(prior.data_sensitivity.value, 0)
        current_level = _sensitivity_order.get(current.data_sensitivity.value, 0)
        if current_level > prior_level:
            confidence = max(confidence, 0.5 + 0.15 * (current_level - prior_level))

    return min(confidence, 1.0)


def _detect_trust_reversal(prior: Action, current: Action) -> float:
    """Return confidence that a trust/reversibility reversal occurred."""
    _rev_order = {"reversible": 0, "append_only": 1, "partial": 2, "irreversible": 3}
    if prior.reversibility and current.reversibility:
        prior_level = _rev_order.get(prior.reversibility.value, 0)
        current_level = _rev_order.get(current.reversibility.value, 0)
        if current_level > prior_level:
            return 0.5 + 0.15 * (current_level - prior_level)
    return 0.0


_CONTRADICTION_DETECTORS = [
    ("goal_change", _detect_goal_change),
    ("scope_expansion", _detect_scope_expansion),
    ("trust_reversal", _detect_trust_reversal),
]


# ── SessionContext ─────────────────────────────────────────────────────


class SessionContext:
    """Accumulating session-level context for governance.

    Tracks signal updates, detected contradictions, and escalation patterns
    across multiple evaluations within a single session.
    """

    def __init__(self, session_id: str, agent_id: str) -> None:
        self.session_id = session_id
        self.agent_id = agent_id
        self.started_at: float = time.time()

        self.signal_updates: list[SessionSignalUpdate] = []
        self.contradictions: list[SessionContradiction] = []
        self.escalation_count: int = 0

        self._lock = threading.Lock()
        # Track actions for contradiction detection
        self._action_history: list[Action] = []

    # ── Public API ──────────────────────────────────────────────────

    def apply_update(self, update: SessionSignalUpdate) -> None:
        """Record a signal update in this session."""
        with self._lock:
            self.signal_updates.append(update)

    def record_action(self, action: Action) -> None:
        """Record an action for contradiction detection."""
        with self._lock:
            self._action_history.append(action)

    def detect_contradiction(
        self, prior: Action, current: Action
    ) -> SessionContradiction | None:
        """Check for contradictions between two actions.

        Returns the highest-confidence contradiction found, or ``None``.
        """
        best: SessionContradiction | None = None
        best_confidence = 0.0

        for ctype, detector in _CONTRADICTION_DETECTORS:
            confidence = detector(prior, current)
            if confidence > 0.0 and confidence > best_confidence:
                best_confidence = confidence
                best = SessionContradiction(
                    prior_action_id=prior.id,
                    current_action_id=current.id,
                    contradiction_type=ctype,
                    confidence=confidence,
                )

        if best is not None:
            with self._lock:
                self.contradictions.append(best)
                # Contradiction-sourced signal update
                self.signal_updates.append(
                    SessionSignalUpdate(
                        signal_name=f"contradiction_{best.contradiction_type}",
                        value=True,
                        confidence=best.confidence,
                        source="contradiction_detected",
                    )
                )

        return best

    def detect_contradictions_for_action(self, action: Action) -> list[SessionContradiction]:
        """Check the new action against all prior actions in this session.

        Returns all contradictions found. Also records the action.
        """
        found: list[SessionContradiction] = []
        with self._lock:
            prior_actions = list(self._action_history)

        for prior in prior_actions:
            c = self.detect_contradiction(prior, action)
            if c is not None:
                found.append(c)

        self.record_action(action)
        return found

    def current_signals(self) -> dict[str, Any]:
        """Merge session-generated signals into a signal dict for evaluation.

        When multiple updates exist for the same signal name, the most recent
        update wins.
        """
        with self._lock:
            updates = list(self.signal_updates)

        result: dict[str, Any] = {}
        # Process in order so later updates override earlier ones
        for update in updates:
            result[update.signal_name] = update.value

        # Always include escalation count as a signal
        result["session_escalation_count"] = self.escalation_count
        result["session_contradiction_count"] = len(self.contradictions)

        return result

    def risk_elevation(self) -> float:
        """Session-level risk modifier based on accumulated signals.

        Returns 0.0 (neutral) to 1.0 (maximum elevation).
        The risk modifier is computed from:
        - Number and severity of contradictions
        - Escalation count
        - High-confidence behavior-inferred signals
        """
        elevation = 0.0

        # Contradiction contribution: each contradiction adds risk
        with self._lock:
            contradictions = list(self.contradictions)
            updates = list(self.signal_updates)

        for c in contradictions:
            elevation += c.confidence * 0.15

        # Escalation contribution
        if self.escalation_count > 0:
            elevation += min(self.escalation_count * 0.1, 0.3)

        # High-confidence behavior-inferred signals contribute
        inferred_count = sum(
            1 for u in updates
            if u.source == "behavior_inferred" and u.confidence > 0.7
        )
        elevation += inferred_count * 0.05

        return min(elevation, 1.0)

    def promotable_signals(self, confidence_threshold: float = 0.7) -> list[SessionSignalUpdate]:
        """Return signals that exceed the confidence threshold for promotion."""
        with self._lock:
            return [
                u for u in self.signal_updates
                if u.confidence >= confidence_threshold
            ]


# ── SessionRegistry ────────────────────────────────────────────────────


class SessionRegistry:
    """Thread-safe registry of active sessions."""

    def __init__(self) -> None:
        self._sessions: dict[str, SessionContext] = {}
        self._lock = threading.Lock()
        self._promotion_callback: Any = None  # Callable[[str, list[SessionSignalUpdate]], None]

    def set_promotion_callback(
        self, callback: Any
    ) -> None:
        """Set a callback invoked when a session is promoted to history.

        The callback receives ``(agent_id, promotable_signals)``.
        """
        self._promotion_callback = callback

    def get_or_create(self, session_id: str, agent_id: str) -> SessionContext:
        """Retrieve an existing session or create a new one."""
        with self._lock:
            if session_id not in self._sessions:
                self._sessions[session_id] = SessionContext(
                    session_id=session_id, agent_id=agent_id,
                )
            return self._sessions[session_id]

    def get(self, session_id: str) -> SessionContext | None:
        """Retrieve a session by ID, or ``None`` if not found."""
        with self._lock:
            return self._sessions.get(session_id)

    def close(
        self,
        session_id: str,
        promote_to_history: bool = False,
        confidence_threshold: float = 0.7,
    ) -> None:
        """Close a session and optionally promote signals to behavioral history.

        When *promote_to_history* is ``True``, session signals that exceeded
        *confidence_threshold* are passed to the promotion callback (if set)
        for writing to the agent's behavioral history.
        """
        with self._lock:
            session = self._sessions.pop(session_id, None)

        if session is None:
            return

        if promote_to_history and self._promotion_callback is not None:
            promotable = session.promotable_signals(confidence_threshold)
            if promotable:
                self._promotion_callback(session.agent_id, promotable)

    def active_session_ids(self) -> list[str]:
        """Return IDs of all active sessions."""
        with self._lock:
            return list(self._sessions.keys())

    def active_count(self) -> int:
        """Return the number of active sessions."""
        with self._lock:
            return len(self._sessions)
