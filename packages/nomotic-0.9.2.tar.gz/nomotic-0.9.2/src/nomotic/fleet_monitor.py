"""Fleet behavioral monitoring — seeing the whole fleet, not just individual agents.

The FleetBehavioralMonitor detects three multi-agent drift scopes from
the Nomotic Drift Taxonomy:

Fleet Drift: The fleet's aggregate behavioral distribution shifts even
when no individual agent triggers an alert.

Correlated Drift: Multiple agents drift in the same direction at the
same time — shared upstream input is the likely cause.

Coordinated Drift: One agent's output changes another's behavior, and
the shift compounds through an interaction chain.

This module is part of the Behavioral Control Plane's fleet intelligence
layer. Individual agent monitoring is in src/nomotic/monitor.py.
"""

from __future__ import annotations

import math
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from nomotic.drift import DriftCalculator, DriftScore
from nomotic.fingerprint import BehavioralFingerprint
from nomotic.observer import FingerprintObserver

__all__ = [
    "FleetBehavioralMonitor",
    "FleetDriftAlert",
    "FleetDriftConfig",
]


@dataclass
class FleetDriftConfig:
    """Configuration for fleet-level drift detection."""

    fleet_check_interval: int = 50
    """Recompute fleet drift every N total fleet observations."""

    correlation_time_window: float = 300.0
    """Seconds — drift events within this window are correlation candidates."""

    correlation_min_agents: int = 3
    """Minimum agents with similar drift to trigger correlated alert."""

    correlation_similarity_threshold: float = 0.7
    """Cosine similarity threshold for drift vector comparison."""

    propagation_max_lag: float = 60.0
    """Max seconds between cause and effect in coordinated drift."""

    fleet_drift_threshold: float = 0.15
    """Fleet aggregate drift above this triggers alert."""

    max_recent_events: int = 500
    """Max drift events retained for analysis."""


@dataclass
class FleetDriftAlert:
    """Alert from fleet-level drift detection.

    Three scopes produce these alerts:

    * ``"fleet"`` — aggregate fleet behavioral distribution shifted.
    * ``"correlated"`` — multiple agents drifted in the same direction.
    * ``"coordinated"`` — drift propagated through an interaction chain.
    """

    alert_id: str
    """Unique identifier for this alert (UUID)."""

    scope: str
    """One of ``"fleet"``, ``"correlated"``, ``"coordinated"``."""

    severity: str
    """One of ``"moderate"``, ``"high"``, ``"critical"``."""

    timestamp: float

    # Fleet drift fields
    fleet_drift_score: float = 0.0
    fleet_distributions_shifted: list[str] = field(default_factory=list)

    # Correlated drift fields
    affected_agents: list[str] = field(default_factory=list)
    shared_drift_direction: dict[str, float] = field(default_factory=dict)
    correlation_strength: float = 0.0
    """Average pairwise cosine similarity within the correlated cluster."""

    # Coordinated drift fields
    propagation_chain: list[str] = field(default_factory=list)
    """Ordered agent chain: [source, hop1, hop2, ...]."""
    amplification_factors: list[float] = field(default_factory=list)
    """Drift magnitude at each hop in the chain."""
    recommended_intervention_point: str = ""

    detail: str = ""
    acknowledged: bool = False
    causal_report: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-friendly dict."""
        return {
            "alert_id": self.alert_id,
            "scope": self.scope,
            "severity": self.severity,
            "timestamp": self.timestamp,
            "fleet_drift_score": round(self.fleet_drift_score, 4),
            "fleet_distributions_shifted": self.fleet_distributions_shifted,
            "affected_agents": self.affected_agents,
            "shared_drift_direction": {
                k: round(v, 4) for k, v in self.shared_drift_direction.items()
            },
            "correlation_strength": round(self.correlation_strength, 4),
            "propagation_chain": self.propagation_chain,
            "amplification_factors": [round(f, 4) for f in self.amplification_factors],
            "recommended_intervention_point": self.recommended_intervention_point,
            "detail": self.detail,
            "acknowledged": self.acknowledged,
            "causal_report": self.causal_report,
        }


# ── Helper functions ─────────────────────────────────────────────────────


def _cosine_similarity(vec_a: list[float], vec_b: list[float]) -> float:
    """Cosine similarity between two vectors.

    Returns 0.0 if either vector has zero magnitude.
    """
    dot = sum(a * b for a, b in zip(vec_a, vec_b))
    mag_a = math.sqrt(sum(a * a for a in vec_a))
    mag_b = math.sqrt(sum(b * b for b in vec_b))
    if mag_a > 0 and mag_b > 0:
        return dot / (mag_a * mag_b)
    return 0.0


def _drift_vector(score: DriftScore) -> list[float]:
    """Convert DriftScore to a 5-element vector for similarity comparison.

    Returns ``[action_drift, target_drift, temporal_drift, outcome_drift, semantic_drift]``.
    """
    return [
        score.action_drift,
        score.target_drift,
        score.temporal_drift,
        score.outcome_drift,
        score.semantic_drift,
    ]


# ── Fleet Behavioral Monitor ────────────────────────────────────────────


class FleetBehavioralMonitor:
    """Fleet-level behavioral intelligence layer.

    Sits above individual agent drift monitoring and detects fleet-wide
    behavioral patterns that no single-agent monitor can see.

    Three drift scopes:

    * **Fleet drift** — the fleet's aggregate behavioral fingerprint
      diverges from its baseline.
    * **Correlated drift** — multiple agents drift in the same direction
      within the same time window, suggesting a shared upstream cause.
    * **Coordinated drift** — drift propagates through an agent interaction
      chain, with potential amplification at each hop.
    """

    def __init__(
        self,
        config: FleetDriftConfig | None = None,
        fingerprint_observer: FingerprintObserver | None = None,
    ) -> None:
        self._config = config or FleetDriftConfig()
        self._fp_observer = fingerprint_observer

        self._fleet_baseline: BehavioralFingerprint | None = None
        self._fleet_baseline_set: bool = False
        self._total_observations: int = 0

        # Recent drift events: (timestamp, agent_id, DriftScore)
        self._recent_drift_events: list[tuple[float, str, DriftScore]] = []

        # Interaction map: source_agent -> {downstream_agents}
        self._interaction_map: dict[str, set[str]] = {}

        self._alerts: list[FleetDriftAlert] = []
        self._lock = threading.Lock()

    def set_interaction_map(self, interaction_map: dict[str, set[str]]) -> None:
        """Set the full agent interaction graph.

        Keys are source agent IDs, values are sets of downstream agent IDs
        that consume the source's output.
        """
        with self._lock:
            self._interaction_map = {
                k: set(v) for k, v in interaction_map.items()
            }

    def register_interaction(self, source_agent: str, target_agent: str) -> None:
        """Register a single directed interaction edge."""
        with self._lock:
            self._interaction_map.setdefault(source_agent, set()).add(target_agent)

    def on_agent_drift(
        self,
        agent_id: str,
        drift_score: DriftScore,
        timestamp: float | None = None,
    ) -> list[FleetDriftAlert]:
        """Called when any agent's drift is computed. Runs fleet-level analysis.

        Returns a list of new fleet-level alerts (may be empty).
        """
        ts = timestamp if timestamp is not None else time.time()

        with self._lock:
            # 1. Record event
            self._recent_drift_events.append((ts, agent_id, drift_score))

            # 2. Prune events older than correlation_time_window
            cutoff = ts - self._config.correlation_time_window
            self._recent_drift_events = [
                e for e in self._recent_drift_events if e[0] >= cutoff
            ]

            # 3. Cap at max_recent_events
            if len(self._recent_drift_events) > self._config.max_recent_events:
                self._recent_drift_events = self._recent_drift_events[
                    -self._config.max_recent_events :
                ]

            # 4. Increment total observations
            self._total_observations += 1

            new_alerts: list[FleetDriftAlert] = []

            # 5. Fleet drift check (periodic)
            if self._total_observations % self._config.fleet_check_interval == 0:
                alert = self._check_fleet_drift()
                if alert is not None:
                    new_alerts.append(alert)

            # 6. Correlated drift check (every time)
            alert = self._check_correlated_drift()
            if alert is not None:
                new_alerts.append(alert)

            # 7. Coordinated drift check (every time)
            alert = self._check_coordinated_drift()
            if alert is not None:
                new_alerts.append(alert)

            # 8. Store alerts
            self._alerts.extend(new_alerts)

            return new_alerts

    def _check_fleet_drift(self) -> FleetDriftAlert | None:
        """Compute aggregate fleet fingerprint and compare to baseline."""
        if self._fp_observer is None:
            return None

        fps = self._fp_observer.all_fingerprints()
        if len(fps) < 2:
            return None

        # Build aggregate fingerprint by averaging all agent distributions
        fleet_fp = BehavioralFingerprint(agent_id="__fleet__")

        all_action_keys: set[str] = set()
        all_target_keys: set[str] = set()
        all_outcome_keys: set[str] = set()
        total_obs = 0

        for fp in fps.values():
            all_action_keys.update(fp.action_distribution.keys())
            all_target_keys.update(fp.target_distribution.keys())
            all_outcome_keys.update(fp.outcome_distribution.keys())
            total_obs += fp.total_observations

        n = len(fps)

        # Average action distributions
        action_dist: dict[str, float] = {}
        for k in all_action_keys:
            action_dist[k] = sum(
                fp.action_distribution.get(k, 0.0) for fp in fps.values()
            ) / n
        fleet_fp.action_distribution = action_dist

        # Average target distributions
        target_dist: dict[str, float] = {}
        for k in all_target_keys:
            target_dist[k] = sum(
                fp.target_distribution.get(k, 0.0) for fp in fps.values()
            ) / n
        fleet_fp.target_distribution = target_dist

        # Average outcome distributions
        outcome_dist: dict[str, float] = {}
        for k in all_outcome_keys:
            outcome_dist[k] = sum(
                fp.outcome_distribution.get(k, 0.0) for fp in fps.values()
            ) / n
        fleet_fp.outcome_distribution = outcome_dist

        fleet_fp.total_observations = total_obs

        # Set baseline on first computation
        if not self._fleet_baseline_set:
            self._fleet_baseline = fleet_fp
            self._fleet_baseline_set = True
            return None

        # Compare against baseline
        calculator = DriftCalculator()
        score = calculator.compare(
            baseline=self._fleet_baseline,  # type: ignore[arg-type]
            recent=fleet_fp,
        )

        if score.overall > self._config.fleet_drift_threshold:
            # Identify which distributions shifted most
            dist_names = [
                ("action", score.action_drift),
                ("target", score.target_drift),
                ("temporal", score.temporal_drift),
                ("outcome", score.outcome_drift),
                ("semantic", score.semantic_drift),
            ]
            shifted = [
                name for name, val in dist_names if val > self._config.fleet_drift_threshold * 0.5
            ]

            severity = _fleet_severity(score.overall)

            alert = FleetDriftAlert(
                alert_id=str(uuid.uuid4()),
                scope="fleet",
                severity=severity,
                timestamp=time.time(),
                fleet_drift_score=score.overall,
                fleet_distributions_shifted=shifted,
                detail=(
                    f"Fleet aggregate drift {score.overall:.3f} exceeds "
                    f"threshold {self._config.fleet_drift_threshold:.3f}. "
                    f"Shifted distributions: {', '.join(shifted) or 'none'}."
                ),
            )

            # Slowly update baseline: blend 90% old + 10% new
            self._blend_baseline(fleet_fp)

            return alert

        # Update baseline slowly even when no alert
        self._blend_baseline(fleet_fp)
        return None

    def _blend_baseline(self, new_fp: BehavioralFingerprint) -> None:
        """Blend new fleet fingerprint into baseline (90% old, 10% new)."""
        if self._fleet_baseline is None:
            self._fleet_baseline = new_fp
            return

        old = self._fleet_baseline
        alpha = 0.1  # New weight

        # Blend action distribution
        all_keys = set(old.action_distribution) | set(new_fp.action_distribution)
        old.action_distribution = {
            k: (1 - alpha) * old.action_distribution.get(k, 0.0)
            + alpha * new_fp.action_distribution.get(k, 0.0)
            for k in all_keys
        }

        # Blend target distribution
        all_keys = set(old.target_distribution) | set(new_fp.target_distribution)
        old.target_distribution = {
            k: (1 - alpha) * old.target_distribution.get(k, 0.0)
            + alpha * new_fp.target_distribution.get(k, 0.0)
            for k in all_keys
        }

        # Blend outcome distribution
        all_keys = set(old.outcome_distribution) | set(new_fp.outcome_distribution)
        old.outcome_distribution = {
            k: (1 - alpha) * old.outcome_distribution.get(k, 0.0)
            + alpha * new_fp.outcome_distribution.get(k, 0.0)
            for k in all_keys
        }

    def _check_correlated_drift(self) -> FleetDriftAlert | None:
        """Analyze recent drift events for parallel drift vectors."""
        # Get unique agents from recent events
        agent_scores: dict[str, DriftScore] = {}
        for _ts, agent_id, score in self._recent_drift_events:
            # Keep latest score per agent
            agent_scores[agent_id] = score

        if len(agent_scores) < self._config.correlation_min_agents:
            return None

        # Compute drift vectors for each agent
        agent_vectors: dict[str, list[float]] = {}
        for agent_id, score in agent_scores.items():
            vec = _drift_vector(score)
            # Only consider agents with meaningful drift
            if any(v > 0.01 for v in vec):
                agent_vectors[agent_id] = vec

        if len(agent_vectors) < self._config.correlation_min_agents:
            return None

        # Find largest cluster of similar drift vectors (greedy)
        agents = list(agent_vectors.keys())
        best_cluster: list[str] = []

        for start_idx in range(len(agents)):
            cluster = [agents[start_idx]]
            for j in range(len(agents)):
                if j == start_idx:
                    continue
                candidate = agents[j]
                # Check similarity against all current cluster members
                all_similar = True
                for member in cluster:
                    sim = _cosine_similarity(
                        agent_vectors[candidate], agent_vectors[member]
                    )
                    if sim < self._config.correlation_similarity_threshold:
                        all_similar = False
                        break
                if all_similar:
                    cluster.append(candidate)

            if len(cluster) > len(best_cluster):
                best_cluster = cluster

        if len(best_cluster) < self._config.correlation_min_agents:
            return None

        # Compute shared drift direction (mean vector)
        cluster_vectors = [agent_vectors[a] for a in best_cluster]
        mean_vector = [
            sum(v[i] for v in cluster_vectors) / len(cluster_vectors)
            for i in range(5)
        ]
        dist_names = ["action", "target", "temporal", "outcome", "semantic"]
        shared_direction = {
            dist_names[i]: mean_vector[i] for i in range(5)
        }

        # Compute correlation strength (mean pairwise cosine similarity)
        pair_sims: list[float] = []
        for i in range(len(best_cluster)):
            for j in range(i + 1, len(best_cluster)):
                sim = _cosine_similarity(
                    agent_vectors[best_cluster[i]],
                    agent_vectors[best_cluster[j]],
                )
                pair_sims.append(sim)
        correlation_strength = sum(pair_sims) / len(pair_sims) if pair_sims else 0.0

        # Determine severity from average drift magnitude
        avg_drift = sum(
            agent_scores[a].overall for a in best_cluster
        ) / len(best_cluster)
        severity = _fleet_severity(avg_drift)

        alert = FleetDriftAlert(
            alert_id=str(uuid.uuid4()),
            scope="correlated",
            severity=severity,
            timestamp=time.time(),
            affected_agents=sorted(best_cluster),
            shared_drift_direction=shared_direction,
            correlation_strength=correlation_strength,
            detail=(
                f"{len(best_cluster)} agents drifting in similar direction "
                f"(correlation {correlation_strength:.3f}). "
                f"Likely shared upstream cause — investigate model versions, "
                f"data sources, or prompt templates."
            ),
        )
        return alert

    def _check_coordinated_drift(self) -> FleetDriftAlert | None:
        """Trace causal propagation chains through the interaction map."""
        if not self._interaction_map:
            return None

        # Sort events by timestamp
        events = sorted(self._recent_drift_events, key=lambda e: e[0])
        if not events:
            return None

        # Build per-agent earliest event lookup
        agent_first_event: dict[str, tuple[float, DriftScore]] = {}
        for ts, agent_id, score in events:
            if agent_id not in agent_first_event:
                agent_first_event[agent_id] = (ts, score)

        best_chain: list[str] = []
        best_chain_scores: list[float] = []

        # For each agent that has downstream consumers
        for source in self._interaction_map:
            if source not in agent_first_event:
                continue

            chain = [source]
            chain_scores = [agent_first_event[source][1].overall]
            self._extend_chain(
                chain, chain_scores, agent_first_event,
            )

            if len(chain) > len(best_chain):
                best_chain = chain
                best_chain_scores = chain_scores

        if len(best_chain) < 2:
            return None

        # Determine severity based on chain length and amplification
        max_amp = max(best_chain_scores) if best_chain_scores else 0.0
        if len(best_chain) >= 4 or max_amp > 0.5:
            severity = "critical"
        elif len(best_chain) >= 3 or max_amp > 0.3:
            severity = "high"
        else:
            severity = "moderate"

        alert = FleetDriftAlert(
            alert_id=str(uuid.uuid4()),
            scope="coordinated",
            severity=severity,
            timestamp=time.time(),
            propagation_chain=best_chain,
            amplification_factors=best_chain_scores,
            recommended_intervention_point=best_chain[0],
            detail=(
                f"Drift propagation chain detected: {' -> '.join(best_chain)}. "
                f"Amplification profile: {[round(f, 3) for f in best_chain_scores]}. "
                f"Recommended intervention: {best_chain[0]}."
            ),
        )
        return alert

    def _extend_chain(
        self,
        chain: list[str],
        chain_scores: list[float],
        agent_first_event: dict[str, tuple[float, DriftScore]],
    ) -> None:
        """Recursively extend a propagation chain through downstream agents."""
        current = chain[-1]
        current_ts = agent_first_event[current][0]
        downstream = self._interaction_map.get(current, set())

        for target in downstream:
            if target in chain:
                continue  # Avoid cycles
            if target not in agent_first_event:
                continue

            target_ts, target_score = agent_first_event[target]

            # Check temporal ordering: downstream must drift AFTER source
            if target_ts <= current_ts:
                continue

            # Check temporal proximity
            if target_ts - current_ts > self._config.propagation_max_lag:
                continue

            chain.append(target)
            chain_scores.append(target_score.overall)
            # Try to extend further
            self._extend_chain(chain, chain_scores, agent_first_event)
            return  # Only follow the first valid downstream path

    def get_alerts(
        self,
        scope: str | None = None,
        unacknowledged_only: bool = False,
    ) -> list[FleetDriftAlert]:
        """Get fleet alerts, optionally filtered by scope."""
        with self._lock:
            alerts = list(self._alerts)
        if scope is not None:
            alerts = [a for a in alerts if a.scope == scope]
        if unacknowledged_only:
            alerts = [a for a in alerts if not a.acknowledged]
        return alerts

    def get_fleet_health(self) -> dict[str, Any]:
        """Return fleet health summary."""
        with self._lock:
            agents_tracked = 0
            agents_drifting = 0

            if self._fp_observer is not None:
                fps = self._fp_observer.all_fingerprints()
                agents_tracked = len(fps)

            # Count agents with recent drift above moderate threshold
            seen_agents: set[str] = set()
            for _ts, agent_id, score in self._recent_drift_events:
                if score.overall >= 0.2:  # moderate threshold
                    seen_agents.add(agent_id)
            agents_drifting = len(seen_agents)

            # Current fleet drift
            fleet_drift = 0.0
            if self._fleet_baseline_set and self._fp_observer is not None:
                fps = self._fp_observer.all_fingerprints()
                if len(fps) >= 2 and self._fleet_baseline is not None:
                    fleet_fp = BehavioralFingerprint(agent_id="__fleet__")
                    n = len(fps)
                    all_action_keys: set[str] = set()
                    all_target_keys: set[str] = set()
                    all_outcome_keys: set[str] = set()
                    for fp in fps.values():
                        all_action_keys.update(fp.action_distribution.keys())
                        all_target_keys.update(fp.target_distribution.keys())
                        all_outcome_keys.update(fp.outcome_distribution.keys())
                    fleet_fp.action_distribution = {
                        k: sum(fp.action_distribution.get(k, 0.0) for fp in fps.values()) / n
                        for k in all_action_keys
                    }
                    fleet_fp.target_distribution = {
                        k: sum(fp.target_distribution.get(k, 0.0) for fp in fps.values()) / n
                        for k in all_target_keys
                    }
                    fleet_fp.outcome_distribution = {
                        k: sum(fp.outcome_distribution.get(k, 0.0) for fp in fps.values()) / n
                        for k in all_outcome_keys
                    }
                    fleet_fp.total_observations = sum(
                        fp.total_observations for fp in fps.values()
                    )
                    calculator = DriftCalculator()
                    drift = calculator.compare(
                        baseline=self._fleet_baseline,
                        recent=fleet_fp,
                    )
                    fleet_drift = drift.overall

            # Count active alerts by scope
            alert_counts: dict[str, int] = {"fleet": 0, "correlated": 0, "coordinated": 0}
            for alert in self._alerts:
                if not alert.acknowledged:
                    alert_counts[alert.scope] = alert_counts.get(alert.scope, 0) + 1

            # Count interaction edges
            interaction_edges = sum(
                len(targets) for targets in self._interaction_map.values()
            )

            return {
                "agents_tracked": agents_tracked,
                "agents_drifting": agents_drifting,
                "fleet_drift": round(fleet_drift, 4),
                "active_alerts": alert_counts,
                "interaction_edges": interaction_edges,
            }

    # ── Policy coordination integration ─────────────────────────

    def on_alert_with_policy_coordination(
        self,
        alert: FleetDriftAlert,
        optimizer: Any,
        current_drifts: dict[str, float],
        velocities: dict[str, float],
        archetypes: dict[str, str],
        cost_profiles: dict[str, Any],
        cause_types: dict[str, str] | None = None,
    ) -> dict[str, Any] | None:
        """Run multi-agent policy coordination when a fleet alert fires.

        Called by the runtime when a coordinated or correlated drift alert
        is detected and the policy optimizer is enabled. Delegates to
        ``optimizer.optimize_chain`` or ``optimizer.optimize_correlated``
        depending on the alert scope.

        Parameters
        ----------
        alert:
            The fleet drift alert that triggered coordination.
        optimizer:
            A ``PolicyOptimizer`` instance with ``optimize_chain`` and
            ``optimize_correlated`` methods.
        current_drifts:
            Per-agent current drift scores.
        velocities:
            Per-agent drift velocities.
        archetypes:
            Per-agent archetype names.
        cost_profiles:
            Per-agent ``CostProfile`` instances.
        cause_types:
            Optional per-agent cause type overrides.

        Returns
        -------
        dict mapping agent_id → InterventionPolicy, or None if the alert
        scope is not coordinated/correlated.
        """
        if alert.scope == "coordinated" and alert.propagation_chain:
            return optimizer.optimize_chain(
                chain=alert.propagation_chain,
                current_drifts=current_drifts,
                velocities=velocities,
                archetypes=archetypes,
                cost_profiles=cost_profiles,
                cause_types=cause_types,
            )
        elif alert.scope == "correlated" and alert.affected_agents:
            return optimizer.optimize_correlated(
                agents=alert.affected_agents,
                current_drifts=current_drifts,
                velocities=velocities,
                archetypes=archetypes,
                cost_profiles=cost_profiles,
                cause_types=cause_types,
            )
        return None

    def reset_baseline(self) -> None:
        """Reset fleet baseline. Useful after intentional fleet-wide changes."""
        with self._lock:
            self._fleet_baseline = None
            self._fleet_baseline_set = False


def _fleet_severity(drift: float) -> str:
    """Map drift magnitude to severity level."""
    if drift >= 0.60:
        return "critical"
    if drift >= 0.35:
        return "high"
    return "moderate"
