"""Tests for the Dimension Orchestration Engine."""

from nomotic.dimensions import GovernanceDimension
from nomotic.orchestrator import (
    ACTION_TYPE_ROUTING,
    DimensionOrchestrator,
    OrchestratorResult,
)
from nomotic.types import Action, AgentContext, DimensionScore, TrustProfile


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ctx(agent_id: str = "agent-1", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


def _action(action_type: str = "read", target: str = "db", **kwargs) -> Action:
    return Action(agent_id="agent-1", action_type=action_type, target=target, **kwargs)


class StubDimension(GovernanceDimension):
    """A configurable stub dimension for testing."""

    def __init__(
        self,
        name: str,
        score: float = 0.8,
        *,
        veto: bool = False,
        can_veto: bool = False,
        weight: float = 1.0,
        escalation_required: bool = False,
        relevant_schema_fields: list[str] | None = None,
        is_foundation: bool = False,
        priority: int = 50,
        metadata: dict | None = None,
    ):
        self.name = name
        self.weight = weight
        self.can_veto = can_veto
        self._score = score
        self._veto = veto
        self._escalation_required = escalation_required
        self.relevant_schema_fields = relevant_schema_fields or []
        self.is_foundation = is_foundation
        self.priority = priority
        self._metadata = metadata or {}
        self.evaluated = False  # track if evaluate was called

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        self.evaluated = True
        meta = dict(self._metadata)
        if self._escalation_required:
            meta["escalation_required"] = True
        return DimensionScore(
            dimension_name=self.name,
            score=self._score,
            weight=self.weight,
            veto=self._veto,
            reasoning=f"Stub score for {self.name}",
            metadata=meta,
        )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestFastGateVeto:
    """Veto-capable dimensions stop evaluation immediately on veto."""

    def test_veto_stops_evaluation(self):
        orch = DimensionOrchestrator()
        dims = [
            StubDimension("d1", score=1.0, can_veto=True),
            StubDimension("d2", score=0.0, veto=True, can_veto=True),
            StubDimension("d3", score=1.0),  # should never run
        ]
        result = orch.evaluate(_action(), _ctx(), dims, 0.7, 0.3)

        assert result.vetoed is True
        assert "d2" in result.veto_dimensions
        assert not dims[2].evaluated  # d3 never evaluated

    def test_no_veto_proceeds(self):
        orch = DimensionOrchestrator()
        dims = [
            StubDimension("d1", score=0.9, can_veto=True),
            StubDimension("d2", score=0.8),
        ]
        result = orch.evaluate(_action(), _ctx(), dims, 0.7, 0.3)

        assert result.vetoed is False
        assert result.veto_dimensions == []
        assert len(result.scores) == 2

    def test_first_veto_dimension_stops(self):
        """When multiple veto-capable dims exist, the first to veto stops eval."""
        orch = DimensionOrchestrator()
        veto1 = StubDimension("v1", score=0.0, veto=True, can_veto=True)
        veto2 = StubDimension("v2", score=0.0, veto=True, can_veto=True)
        result = orch.evaluate(_action(), _ctx(), [veto1, veto2], 0.7, 0.3)

        assert result.vetoed is True
        assert result.veto_dimensions == ["v1"]
        assert not veto2.evaluated


class TestRelevanceFiltering:
    """Dimensions with relevant_schema_fields are skipped when action lacks those fields."""

    def test_irrelevant_dimension_skipped(self):
        orch = DimensionOrchestrator()
        dim = StubDimension(
            "d1", relevant_schema_fields=["data_sensitivity"]
        )
        # Action without data_sensitivity set
        result = orch.evaluate(_action(), _ctx(), [dim], 0.7, 0.3)

        assert "d1" in result.dimensions_skipped
        assert not dim.evaluated
        assert len(result.scores) == 1
        assert result.scores[0].score == 0.5  # neutral

    def test_relevant_dimension_evaluated(self):
        from nomotic.types import DataSensitivity

        orch = DimensionOrchestrator()
        dim = StubDimension(
            "d1", relevant_schema_fields=["data_sensitivity"]
        )
        action = _action(data_sensitivity=DataSensitivity.CONFIDENTIAL)
        result = orch.evaluate(action, _ctx(), [dim], 0.7, 0.3)

        assert "d1" not in result.dimensions_skipped
        assert dim.evaluated

    def test_empty_relevant_fields_always_relevant(self):
        orch = DimensionOrchestrator()
        dim = StubDimension("d1", relevant_schema_fields=[])
        result = orch.evaluate(_action(), _ctx(), [dim], 0.7, 0.3)

        assert dim.evaluated
        assert "d1" not in result.dimensions_skipped


class TestEarlyExit:
    """Early exit fires when confidence threshold is reached."""

    def test_early_exit_high_scores(self):
        """When all scores are very high, early exit should trigger."""
        orch = DimensionOrchestrator()
        # 4 dimensions scoring 1.0 — well above allow_threshold + margin
        dims = [
            StubDimension(f"d{i}", score=1.0) for i in range(6)
        ]
        result = orch.evaluate(_action(), _ctx(), dims, 0.7, 0.3)

        assert result.early_exit is True
        # Not all dimensions should have been evaluated
        unevaluated = [d for d in dims if not d.evaluated]
        assert len(unevaluated) > 0

    def test_early_exit_low_scores(self):
        """When all scores are very low, early exit should trigger for deny."""
        orch = DimensionOrchestrator()
        dims = [
            StubDimension(f"d{i}", score=0.05) for i in range(6)
        ]
        result = orch.evaluate(_action(), _ctx(), dims, 0.7, 0.3)

        assert result.early_exit is True

    def test_no_early_exit_ambiguous(self):
        """When scores are ambiguous, all dimensions should run."""
        orch = DimensionOrchestrator()
        dims = [
            StubDimension(f"d{i}", score=0.5) for i in range(6)
        ]
        result = orch.evaluate(_action(), _ctx(), dims, 0.7, 0.3)

        assert result.early_exit is False
        assert all(d.evaluated for d in dims)

    def test_no_early_exit_with_too_few_dimensions(self):
        """Early exit requires minimum number of evaluated dimensions."""
        orch = DimensionOrchestrator()
        dims = [
            StubDimension("d1", score=1.0),
            StubDimension("d2", score=1.0),
        ]
        result = orch.evaluate(_action(), _ctx(), dims, 0.7, 0.3)

        assert result.early_exit is False


class TestActionTypeRouting:
    """Routing applies correct dimension priority per action type."""

    def test_delete_routing_order(self):
        orch = DimensionOrchestrator()
        # Create dimensions matching delete routing table names
        dims = [
            StubDimension("cascading_impact", score=0.8),
            StubDimension("scope_compliance", score=0.8),
            StubDimension("authority_verification", score=0.8),
            StubDimension("other_dim", score=0.8),
        ]
        action = _action(action_type="delete")
        result = orch.evaluate(action, _ctx(), dims, 0.7, 0.3)

        # All should be evaluated
        assert all(d.evaluated for d in dims)
        # Check the scores are in the expected routing order
        score_names = [s.dimension_name for s in result.scores]
        # scope_compliance and authority_verification should come before other_dim
        scope_idx = score_names.index("scope_compliance")
        auth_idx = score_names.index("authority_verification")
        other_idx = score_names.index("other_dim")
        assert scope_idx < other_idx
        assert auth_idx < other_idx

    def test_read_routing_order(self):
        orch = DimensionOrchestrator()
        dims = [
            StubDimension("other_dim", score=0.8),
            StubDimension("isolation_integrity", score=0.8),
            StubDimension("scope_compliance", score=0.8),
        ]
        action = _action(action_type="read")
        result = orch.evaluate(action, _ctx(), dims, 0.7, 0.3)

        score_names = [s.dimension_name for s in result.scores]
        iso_idx = score_names.index("isolation_integrity")
        scope_idx = score_names.index("scope_compliance")
        other_idx = score_names.index("other_dim")
        assert iso_idx < other_idx
        assert scope_idx < other_idx

    def test_unknown_action_type_uses_default_order(self):
        orch = DimensionOrchestrator()
        dims = [
            StubDimension("d1", score=0.8, priority=100),
            StubDimension("d2", score=0.8, priority=10),
        ]
        action = _action(action_type="custom_op")
        result = orch.evaluate(action, _ctx(), dims, 0.7, 0.3)

        # d2 has lower priority so should run first
        score_names = [s.dimension_name for s in result.scores]
        assert score_names.index("d2") < score_names.index("d1")

    def test_delegate_routing(self):
        orch = DimensionOrchestrator()
        dims = [
            StubDimension("scope_compliance", score=0.8),
            StubDimension("authority_verification", score=0.8),
            StubDimension("unrelated", score=0.8),
        ]
        action = _action(action_type="delegate")
        result = orch.evaluate(action, _ctx(), dims, 0.7, 0.3)

        score_names = [s.dimension_name for s in result.scores]
        auth_idx = score_names.index("authority_verification")
        unrelated_idx = score_names.index("unrelated")
        assert auth_idx < unrelated_idx


class TestFoundationDimensions:
    """Foundation dimensions run in the pre-pass and populate shared context."""

    def test_foundation_runs_first(self):
        orch = DimensionOrchestrator()
        eval_order: list[str] = []

        class TrackingDim(GovernanceDimension):
            def __init__(self, name, **kwargs):
                self.name = name
                self.weight = 1.0
                self.can_veto = kwargs.get("can_veto", False)
                self.relevant_schema_fields = []
                self.is_foundation = kwargs.get("is_foundation", False)
                self.priority = kwargs.get("priority", 50)

            def evaluate(self, action, context):
                eval_order.append(self.name)
                return DimensionScore(
                    dimension_name=self.name, score=0.8, weight=1.0
                )

        dims = [
            TrackingDim("regular", priority=10),
            TrackingDim("foundation", is_foundation=True),
            TrackingDim("veto_dim", can_veto=True),
        ]
        orch.evaluate(_action(), _ctx(), dims, 0.7, 0.3)

        assert eval_order[0] == "foundation"
        assert eval_order.index("veto_dim") < eval_order.index("regular")

    def test_foundation_metadata_in_context(self):
        orch = DimensionOrchestrator()
        dim = StubDimension(
            "classifier",
            is_foundation=True,
            metadata={"sensitivity_level": "high"},
        )
        result = orch.evaluate(_action(), _ctx(), [dim], 0.7, 0.3)

        assert "classifier" in result.foundation_context
        assert result.foundation_context["classifier"]["sensitivity_level"] == "high"


class TestEscalation:
    """Escalation flags are tracked correctly."""

    def test_escalation_tracked(self):
        orch = DimensionOrchestrator()
        dims = [
            StubDimension("d1", score=0.5, escalation_required=True),
            StubDimension("d2", score=0.8),
        ]
        result = orch.evaluate(_action(), _ctx(), dims, 0.7, 0.3)

        assert result.escalation_required is True
        assert "d1" in result.escalation_required_by

    def test_no_escalation_by_default(self):
        orch = DimensionOrchestrator()
        dims = [StubDimension("d1", score=0.8)]
        result = orch.evaluate(_action(), _ctx(), dims, 0.7, 0.3)

        assert result.escalation_required is False
        assert result.escalation_required_by == []


class TestOrchestratorResult:
    """OrchestratorResult dataclass defaults."""

    def test_defaults(self):
        r = OrchestratorResult()
        assert r.scores == []
        assert r.vetoed is False
        assert r.veto_dimensions == []
        assert r.escalation_required is False
        assert r.escalation_required_by == []
        assert r.dimensions_skipped == []
        assert r.early_exit is False
        assert r.foundation_context == {}
