"""Tests for the tiered escalation path system."""

from __future__ import annotations

import unittest

from nomotic.cost_profile import CONSERVATIVE, PERMISSIVE, CostProfile
from nomotic.escalation import (
    EscalationManager,
    EscalationPath,
    EscalationResult,
    EscalationStep,
)
from nomotic.types import Action, AgentContext, DimensionScore, TrustProfile
from nomotic.voi import VOIResult


def _make_trust(overall: float = 0.5, actions: int = 50) -> TrustProfile:
    return TrustProfile(
        agent_id="agent-1",
        overall_trust=overall,
        successful_actions=actions,
        violation_count=0,
    )


def _make_context(trust: float = 0.5) -> AgentContext:
    return AgentContext(agent_id="agent-1", trust_profile=_make_trust(trust))


def _uniform_scores(value: float = 0.5, n: int = 4) -> list[DimensionScore]:
    names = ["ethical_alignment", "scope_compliance", "behavioral_consistency", "resource_governance"]
    return [DimensionScore(dimension_name=names[i % len(names)], score=value) for i in range(n)]


def _make_voi(voi_score: float = 0.5, should_escalate: bool = True) -> VOIResult:
    return VOIResult(
        voi_score=voi_score,
        escalation_cost=0.15,
        should_escalate=should_escalate,
        recommended_path="human_review" if should_escalate else "none",
    )


class TestDefaultPathSteps(unittest.TestCase):
    """test_default_path_steps: Default EscalationPath has 3 steps in cheapest-first order."""

    def test_default_path_has_three_steps(self) -> None:
        path = EscalationPath()
        self.assertEqual(len(path.steps), 3)

    def test_steps_ordered_cheapest_first(self) -> None:
        path = EscalationPath()
        costs = [s.cost for s in path.steps]
        self.assertEqual(costs, sorted(costs))

    def test_step_types(self) -> None:
        path = EscalationPath()
        types = [s.step_type for s in path.steps]
        self.assertEqual(types, ["request_context", "secondary_check", "human_review"])


class TestRequestContextResolves(unittest.TestCase):
    """test_request_context_resolves: Action with rich parameters resolves at request_context."""

    def test_additional_context_resolves(self) -> None:
        action = Action(
            agent_id="agent-1",
            action_type="query",
            parameters={"additional_context": {"reason": "authorized", "approval": "yes", "ref": "ticket-123"}},
        )
        manager = EscalationManager()
        result = manager.resolve(
            action=action,
            context=_make_context(),
            scores=_uniform_scores(0.5),
            ucs=0.55,  # In ambiguity zone, but context bump pushes it above 0.65
            voi_result=_make_voi(voi_score=0.5),
        )
        self.assertTrue(result.resolved)
        self.assertEqual(result.resolved_at_step, "request_context")
        self.assertEqual(result.final_verdict, "ALLOW")

    def test_no_context_does_not_resolve(self) -> None:
        action = Action(agent_id="agent-1", action_type="query")
        manager = EscalationManager()
        result = manager.resolve(
            action=action,
            context=_make_context(),
            scores=_uniform_scores(0.5),
            ucs=0.5,
            voi_result=_make_voi(voi_score=0.5),
        )
        # request_context won't resolve; check it was attempted but didn't resolve there
        self.assertIn("request_context", result.steps_attempted)
        self.assertNotEqual(result.resolved_at_step, "request_context")


class TestSecondaryCheckResolves(unittest.TestCase):
    """test_secondary_check_resolves: Slightly adjusted thresholds push UCS above allow."""

    def test_ucs_just_below_upper_resolves(self) -> None:
        # UCS at 0.61 — within secondary check's ±5% adjustment of 0.65
        action = Action(agent_id="agent-1", action_type="query")
        manager = EscalationManager()
        result = manager.resolve(
            action=action,
            context=_make_context(),
            scores=_uniform_scores(0.5),
            ucs=0.61,
            voi_result=_make_voi(voi_score=0.5),
        )
        self.assertTrue(result.resolved)
        self.assertEqual(result.resolved_at_step, "secondary_check")
        self.assertEqual(result.final_verdict, "ALLOW")

    def test_ucs_just_above_lower_resolves_deny(self) -> None:
        # UCS at 0.39 — within secondary check's ±5% of 0.35
        action = Action(agent_id="agent-1", action_type="query")
        manager = EscalationManager()
        result = manager.resolve(
            action=action,
            context=_make_context(),
            scores=_uniform_scores(0.5),
            ucs=0.39,
            voi_result=_make_voi(voi_score=0.5),
        )
        self.assertTrue(result.resolved)
        self.assertEqual(result.resolved_at_step, "secondary_check")
        self.assertEqual(result.final_verdict, "DENY")


class TestFallsThroughToHuman(unittest.TestCase):
    """test_falls_through_to_human: No cheaper path resolves → reaches human_review."""

    def test_reaches_human_review(self) -> None:
        # UCS at 0.5 (dead center) — no context, no secondary check resolves
        action = Action(agent_id="agent-1", action_type="query")
        manager = EscalationManager()
        result = manager.resolve(
            action=action,
            context=_make_context(),
            scores=_uniform_scores(0.5),
            ucs=0.5,
            voi_result=_make_voi(voi_score=0.5),
        )
        self.assertTrue(result.resolved)
        self.assertEqual(result.resolved_at_step, "human_review")
        self.assertEqual(result.final_verdict, "ESCALATE")
        self.assertEqual(len(result.steps_attempted), 3)


class TestFallbackDenyHighStakes(unittest.TestCase):
    """test_fallback_deny_high_stakes: CONSERVATIVE CostProfile → fallback_verdict='DENY'."""

    def test_conservative_fallback_deny(self) -> None:
        action = Action(agent_id="agent-1", action_type="query")
        # Custom path with only steps that won't resolve
        path = EscalationPath(
            steps=[
                EscalationStep("request_context", cost=0.02, expected_resolution_rate=0.3),
            ],
            fallback_verdict="DENY",
        )
        manager = EscalationManager(default_path=path)
        result = manager.resolve(
            action=action,
            context=_make_context(),
            scores=_uniform_scores(0.5),
            ucs=0.5,
            voi_result=_make_voi(voi_score=0.5),
            cost_profile=CONSERVATIVE,
        )
        # request_context won't resolve (no additional_context), path exhausted
        self.assertFalse(result.resolved)
        self.assertEqual(result.final_verdict, "DENY")


class TestFallbackAllowLowStakes(unittest.TestCase):
    """test_fallback_allow_low_stakes: PERMISSIVE CostProfile → fallback_verdict='ALLOW'."""

    def test_permissive_fallback_allow(self) -> None:
        action = Action(agent_id="agent-1", action_type="query")
        path = EscalationPath(
            steps=[
                EscalationStep("request_context", cost=0.02, expected_resolution_rate=0.3),
            ],
            fallback_verdict="DENY",  # Default, but cost_profile overrides to ALLOW
        )
        manager = EscalationManager(default_path=path)
        result = manager.resolve(
            action=action,
            context=_make_context(),
            scores=_uniform_scores(0.5),
            ucs=0.5,
            voi_result=_make_voi(voi_score=0.5),
            cost_profile=PERMISSIVE,
        )
        self.assertFalse(result.resolved)
        self.assertEqual(result.final_verdict, "ALLOW")


class TestVOITooLowSkipsStep(unittest.TestCase):
    """test_voi_too_low_skips_step: VOI score lower than step cost → step skipped."""

    def test_low_voi_skips_to_fallback(self) -> None:
        action = Action(agent_id="agent-1", action_type="query")
        # VOI score of 0.01 is below the cheapest step (0.02)
        manager = EscalationManager()
        result = manager.resolve(
            action=action,
            context=_make_context(),
            scores=_uniform_scores(0.5),
            ucs=0.5,
            voi_result=_make_voi(voi_score=0.01),
        )
        self.assertFalse(result.resolved)
        self.assertEqual(len(result.steps_attempted), 0)
        self.assertIn("skipping", result.detail)

    def test_voi_between_steps_skips_expensive(self) -> None:
        action = Action(agent_id="agent-1", action_type="query")
        # VOI of 0.05 — enough for request_context (0.02) but not secondary_check (0.08)
        path = EscalationPath(
            steps=[
                EscalationStep("request_context", cost=0.02, expected_resolution_rate=0.3),
                EscalationStep("secondary_check", cost=0.08, expected_resolution_rate=0.4),
            ],
        )
        manager = EscalationManager(default_path=path)
        result = manager.resolve(
            action=action,
            context=_make_context(),
            scores=_uniform_scores(0.5),
            ucs=0.5,
            voi_result=_make_voi(voi_score=0.05),
        )
        self.assertFalse(result.resolved)
        self.assertIn("request_context", result.steps_attempted)
        self.assertNotIn("secondary_check", result.steps_attempted)


class TestCustomEscalationPath(unittest.TestCase):
    """test_custom_escalation_path: Contract with custom 2-step path is used."""

    def test_custom_path_used(self) -> None:
        action = Action(agent_id="agent-1", action_type="query")
        custom_path = EscalationPath(
            steps=[
                EscalationStep("secondary_check", cost=0.05, expected_resolution_rate=0.5),
                EscalationStep("human_review", cost=0.15, expected_resolution_rate=0.9),
            ],
        )
        manager = EscalationManager()
        # UCS at 0.61 — secondary_check resolves with adjusted thresholds
        result = manager.resolve(
            action=action,
            context=_make_context(),
            scores=_uniform_scores(0.5),
            ucs=0.61,
            voi_result=_make_voi(voi_score=0.5),
            escalation_path=custom_path,
        )
        self.assertTrue(result.resolved)
        self.assertEqual(result.resolved_at_step, "secondary_check")
        # request_context was NOT attempted because custom path doesn't include it
        self.assertNotIn("request_context", result.steps_attempted)

    def test_custom_path_from_dict_roundtrip(self) -> None:
        custom_path = EscalationPath(
            steps=[
                EscalationStep("secondary_check", cost=0.05, expected_resolution_rate=0.5, description="Check"),
            ],
            fallback_verdict="ALLOW",
        )
        data = custom_path.to_dict()
        restored = EscalationPath.from_dict(data)
        self.assertEqual(len(restored.steps), 1)
        self.assertEqual(restored.steps[0].step_type, "secondary_check")
        self.assertEqual(restored.fallback_verdict, "ALLOW")


class TestEscalationResultSerialization(unittest.TestCase):
    """test_escalation_result_serialization: to_dict() round-trip."""

    def test_result_to_dict(self) -> None:
        result = EscalationResult(
            resolved=True,
            resolved_at_step="secondary_check",
            steps_attempted=["request_context", "secondary_check"],
            total_cost_incurred=0.10,
            final_verdict="ALLOW",
            detail="Secondary check resolved",
        )
        d = result.to_dict()
        self.assertTrue(d["resolved"])
        self.assertEqual(d["resolved_at_step"], "secondary_check")
        self.assertEqual(d["steps_attempted"], ["request_context", "secondary_check"])
        self.assertAlmostEqual(d["total_cost_incurred"], 0.10, places=4)
        self.assertEqual(d["final_verdict"], "ALLOW")
        self.assertEqual(d["detail"], "Secondary check resolved")

    def test_step_to_dict(self) -> None:
        step = EscalationStep("human_review", cost=0.20, expected_resolution_rate=0.9, description="Human")
        d = step.to_dict()
        self.assertEqual(d["step_type"], "human_review")
        self.assertEqual(d["cost"], 0.20)
        self.assertEqual(d["expected_resolution_rate"], 0.9)
        self.assertEqual(d["description"], "Human")

    def test_path_to_dict_and_from_dict(self) -> None:
        path = EscalationPath()
        d = path.to_dict()
        restored = EscalationPath.from_dict(d)
        self.assertEqual(len(restored.steps), len(path.steps))
        for orig, rest in zip(path.steps, restored.steps):
            self.assertEqual(orig.step_type, rest.step_type)
            self.assertAlmostEqual(orig.cost, rest.cost)
            self.assertAlmostEqual(orig.expected_resolution_rate, rest.expected_resolution_rate)


class TestEscalationManagerIntegration(unittest.TestCase):
    """Integration: EscalationManager works end-to-end with various scenarios."""

    def test_total_cost_accumulates(self) -> None:
        action = Action(agent_id="agent-1", action_type="query")
        manager = EscalationManager()
        result = manager.resolve(
            action=action,
            context=_make_context(),
            scores=_uniform_scores(0.5),
            ucs=0.5,
            voi_result=_make_voi(voi_score=0.5),
        )
        # Falls through to human_review after trying all 3 steps
        expected_cost = 0.02 + 0.08 + 0.20
        self.assertAlmostEqual(result.total_cost_incurred, expected_cost, places=4)

    def test_empty_path_returns_fallback(self) -> None:
        action = Action(agent_id="agent-1", action_type="query")
        path = EscalationPath(steps=[], fallback_verdict="DENY")
        manager = EscalationManager(default_path=path)
        result = manager.resolve(
            action=action,
            context=_make_context(),
            scores=_uniform_scores(0.5),
            ucs=0.5,
            voi_result=_make_voi(voi_score=0.5),
        )
        self.assertFalse(result.resolved)
        self.assertEqual(result.final_verdict, "DENY")


if __name__ == "__main__":
    unittest.main()
