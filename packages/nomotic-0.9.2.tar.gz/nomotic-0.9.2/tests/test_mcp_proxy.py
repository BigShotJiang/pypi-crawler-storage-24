"""Tests for MCP Governance Proxy — adapter layer for MCP tool calls."""

import json
import signal
import time
from unittest.mock import MagicMock, patch

import pytest

from nomotic.authority import CertificateAuthority
from nomotic.executor import ExecutionResult
from nomotic.keys import SigningKey
from nomotic.mcp_proxy import (
    MCPGovernanceProxy,
    MCPHTTPGovernanceProxy,
    _attach_governance_token,
    _build_denial_response,
    _extract_target,
)
from nomotic.internal.sandbox import AgentConfig, save_agent_config
from nomotic.store import FileCertificateStore


def _setup_agent(
    tmp_path,
    agent_id: str = "TestBot",
    actions: list[str] | None = None,
    boundaries: list[str] | None = None,
) -> str:
    """Create a certificate and config for an agent in tmp_path."""
    sk, _vk = SigningKey.generate()
    store = FileCertificateStore(tmp_path)
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    cert, _agent_sk = ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization="test-org",
        zone_path="global",
        owner="test-owner",
    )

    if actions is None:
        actions = ["read", "write", "query"]
    config = AgentConfig(
        agent_id=agent_id,
        actions=actions,
        boundaries=boundaries or [],
    )
    save_agent_config(tmp_path, config)
    return cert.certificate_id


# ── _extract_target tests ─────────────────────────────────────────────────


class TestExtractTarget:
    def test_target_key(self):
        assert _extract_target("run", {"target": "server-1"}) == "server-1"

    def test_path_key(self):
        assert _extract_target("read", {"path": "/data/file.csv"}) == "/data/file.csv"

    def test_file_key(self):
        assert _extract_target("open", {"file": "report.pdf"}) == "report.pdf"

    def test_table_key(self):
        assert _extract_target("query", {"table": "customers"}) == "customers"

    def test_url_key(self):
        assert _extract_target("fetch", {"url": "https://example.com"}) == "https://example.com"

    def test_resource_key(self):
        assert _extract_target("access", {"resource": "bucket-3"}) == "bucket-3"

    def test_database_key(self):
        assert _extract_target("connect", {"database": "prod_db"}) == "prod_db"

    def test_uri_key(self):
        assert _extract_target("open", {"uri": "s3://bucket/key"}) == "s3://bucket/key"

    def test_priority_order(self):
        """'target' takes priority over 'path'."""
        assert _extract_target("x", {"path": "/p", "target": "/t"}) == "/t"

    def test_fallback_first_string(self):
        assert _extract_target("search", {"query": "hello"}) == "hello"

    def test_fallback_tool_name_no_string_args(self):
        assert _extract_target("ping", {"count": 5}) == "ping"

    def test_empty_args(self):
        assert _extract_target("noop", {}) == "noop"


# ── _build_denial_response tests ──────────────────────────────────────────


class TestBuildDenialResponse:
    def test_structure(self):
        resp = _build_denial_response(42, "delete_file", "/etc/passwd", "scope violation")
        assert resp["jsonrpc"] == "2.0"
        assert resp["id"] == 42
        assert resp["result"]["isError"] is True
        content = resp["result"]["content"]
        assert len(content) == 1
        assert content[0]["type"] == "text"

    def test_includes_tool_name_and_target(self):
        resp = _build_denial_response(1, "drop_table", "users", "forbidden")
        text = resp["result"]["content"][0]["text"]
        assert "drop_table" in text
        assert "users" in text
        assert "forbidden" in text

    def test_none_request_id(self):
        resp = _build_denial_response(None, "x", "y", "z")
        assert resp["id"] is None

    def test_valid_json_roundtrip(self):
        resp = _build_denial_response(7, "a", "b", "reason")
        serialized = json.dumps(resp)
        deserialized = json.loads(serialized)
        assert deserialized == resp


# ── _attach_governance_token tests ────────────────────────────────────────


class TestAttachGovernanceToken:
    def _make_result(self, **overrides):
        defaults = {
            "allowed": True,
            "verdict": "ALLOW",
            "reason": "",
            "data": None,
            "ucs": 0.95,
            "tier": 2,
            "trust_before": 0.8,
            "trust_after": 0.82,
            "trust_delta": 0.02,
            "dimension_scores": {},
            "vetoed_by": [],
            "action_id": "abc123",
            "duration_ms": 1.5,
        }
        defaults.update(overrides)
        return ExecutionResult(**defaults)

    def test_adds_nomotic_key(self):
        msg = {"jsonrpc": "2.0", "method": "tools/call", "params": {"name": "x"}, "id": 1}
        result = self._make_result()
        forwarded = _attach_governance_token(msg, result)
        assert "_nomotic" in forwarded["params"]
        token = forwarded["params"]["_nomotic"]
        assert token["governance_token"] == "abc123"
        assert token["trust_score"] == 0.82
        assert token["verdict"] == "ALLOW"
        assert "timestamp" in token

    def test_does_not_mutate_original(self):
        msg = {"jsonrpc": "2.0", "method": "tools/call", "params": {"name": "x"}, "id": 1}
        result = self._make_result()
        _attach_governance_token(msg, result)
        assert "_nomotic" not in msg["params"]

    def test_preserves_existing_params(self):
        msg = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {"name": "read", "arguments": {"path": "/tmp"}},
            "id": 1,
        }
        result = self._make_result()
        forwarded = _attach_governance_token(msg, result)
        assert forwarded["params"]["name"] == "read"
        assert forwarded["params"]["arguments"] == {"path": "/tmp"}


# ── MCPGovernanceProxy._is_tool_call tests ────────────────────────────────


class TestIsToolCall:
    def test_valid_tool_call(self):
        assert MCPGovernanceProxy._is_tool_call(
            {"method": "tools/call", "params": {"name": "read"}}
        )

    def test_tools_list_is_not_tool_call(self):
        assert not MCPGovernanceProxy._is_tool_call(
            {"method": "tools/list", "params": {}}
        )

    def test_initialize_is_not_tool_call(self):
        assert not MCPGovernanceProxy._is_tool_call(
            {"method": "initialize", "params": {}}
        )

    def test_no_params_is_not_tool_call(self):
        assert not MCPGovernanceProxy._is_tool_call(
            {"method": "tools/call"}
        )

    def test_empty_dict(self):
        assert not MCPGovernanceProxy._is_tool_call({})

    def test_notification_without_id(self):
        """Notifications can have method but no id — still treated as tool call if params present."""
        assert MCPGovernanceProxy._is_tool_call(
            {"method": "tools/call", "params": {"name": "x"}}
        )


# ── Integration tests with real governance ────────────────────────────────


class TestProxyGovernance:
    """Test that the proxy correctly delegates governance decisions."""

    def test_allowed_tool_call_forwards(self, tmp_path):
        """An allowed tool call should produce a forwarded message with governance token."""
        _setup_agent(tmp_path, "ProxyBot", actions=["read"])
        proxy = MCPGovernanceProxy(
            agent_id="ProxyBot",
            upstream_command="echo test",
            base_dir=tmp_path,
            test_mode=True,
        )

        # Capture what gets sent to upstream vs client
        upstream_messages = []
        client_messages = []
        proxy._send_to_upstream = lambda msg: upstream_messages.append(msg)
        proxy._send_to_client = lambda msg: client_messages.append(msg)

        message = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "read", "arguments": {"path": "/data/file.csv"}},
        }

        proxy._handle_tool_call(message)

        assert len(upstream_messages) == 1
        assert len(client_messages) == 0
        forwarded = json.loads(upstream_messages[0])
        assert "_nomotic" in forwarded["params"]
        assert forwarded["params"]["_nomotic"]["verdict"] == "ALLOW"

    def test_denied_tool_call_returns_denial(self, tmp_path):
        """A denied tool call should return a denial response to the client."""
        # Agent scoped to "read" only — "delete_all" is out of scope
        _setup_agent(tmp_path, "RestrictedBot", actions=["read"])
        proxy = MCPGovernanceProxy(
            agent_id="RestrictedBot",
            upstream_command="echo test",
            base_dir=tmp_path,
            test_mode=True,
        )

        upstream_messages = []
        client_messages = []
        proxy._send_to_upstream = lambda msg: upstream_messages.append(msg)
        proxy._send_to_client = lambda msg: client_messages.append(msg)

        message = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {"name": "delete_all", "arguments": {"table": "users"}},
        }

        proxy._handle_tool_call(message)

        assert len(upstream_messages) == 0
        assert len(client_messages) == 1
        denial = json.loads(client_messages[0])
        assert denial["jsonrpc"] == "2.0"
        assert denial["id"] == 2
        assert denial["result"]["isError"] is True
        assert "GOVERNANCE DENIED" in denial["result"]["content"][0]["text"]

    def test_non_tool_messages_pass_through(self, tmp_path):
        """Messages that aren't tools/call should be forwarded unchanged."""
        _setup_agent(tmp_path, "PassBot")
        proxy = MCPGovernanceProxy(
            agent_id="PassBot",
            upstream_command="echo test",
            base_dir=tmp_path,
            test_mode=True,
        )

        upstream_messages = []
        proxy._send_to_upstream = lambda msg: upstream_messages.append(msg)

        # Simulate initialize message
        init_msg = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}}
        stdin_line = json.dumps(init_msg)

        # Manually call the logic that _read_client would use
        message = json.loads(stdin_line)
        if proxy._is_tool_call(message):
            proxy._handle_tool_call(message)
        else:
            proxy._send_to_upstream(json.dumps(message))

        assert len(upstream_messages) == 1
        assert json.loads(upstream_messages[0])["method"] == "initialize"


# ── CLI argument parsing tests ────────────────────────────────────────────


class TestMCPProxyCLI:
    def test_mcp_proxy_parser_exists(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "test-bot",
            "--upstream", "python server.py",
        ])
        assert args.command == "mcp-proxy"
        assert args.agent_id == "test-bot"
        assert args.upstream == "python server.py"
        assert args.upstream_url is None

    def test_mcp_proxy_http_mode(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "test-bot",
            "--upstream-url", "http://localhost:3000",
            "--port", "9000",
        ])
        assert args.upstream_url == "http://localhost:3000"
        assert args.port == 9000
        assert args.upstream is None

    def test_mcp_proxy_defaults(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "bot",
            "--upstream", "cmd",
        ])
        assert args.port == 8421
        assert args.host == "127.0.0.1"
        assert args.test_mode is False
        assert args.log_level == "info"

    def test_mcp_proxy_test_mode_flag(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "bot",
            "--upstream", "cmd",
            "--test-mode",
            "--log-level", "debug",
        ])
        assert args.test_mode is True
        assert args.log_level == "debug"


# ── HTTP proxy unit tests ────────────────────────────────────────────────


class TestHTTPProxy:
    def test_handle_tool_call_http_denied(self, tmp_path):
        """Denied tool call returns denial dict."""
        # Agent scoped to "read" only — "destroy" is out of scope
        _setup_agent(tmp_path, "HTTPBot", actions=["read"])
        proxy = MCPHTTPGovernanceProxy(
            agent_id="HTTPBot",
            upstream_url="http://localhost:9999",
            base_dir=tmp_path,
            test_mode=True,
        )

        message = {
            "jsonrpc": "2.0",
            "id": 5,
            "method": "tools/call",
            "params": {"name": "destroy", "arguments": {"target": "everything"}},
        }

        result = proxy._handle_tool_call_http(message)
        assert result is not None
        assert result["result"]["isError"] is True
        assert "GOVERNANCE DENIED" in result["result"]["content"][0]["text"]

    def test_handle_tool_call_http_allowed(self, tmp_path):
        """Allowed tool call returns None (meaning: forward to upstream)."""
        _setup_agent(tmp_path, "HTTPAllowBot", actions=["read"])
        proxy = MCPHTTPGovernanceProxy(
            agent_id="HTTPAllowBot",
            upstream_url="http://localhost:9999",
            base_dir=tmp_path,
            test_mode=True,
        )

        message = {
            "jsonrpc": "2.0",
            "id": 6,
            "method": "tools/call",
            "params": {"name": "read", "arguments": {"path": "/data"}},
        }

        result = proxy._handle_tool_call_http(message)
        assert result is None


# ── MCPHTTPGovernanceProxy._log / _health_check / _forward_to_upstream ────


def _make_http_proxy_mock(**kwargs):
    """Construct MCPHTTPGovernanceProxy with a mocked executor (no real cert/config needed)."""
    mock_executor = MagicMock()
    with patch("nomotic.mcp_proxy.GovernedToolExecutor.connect", return_value=mock_executor):
        proxy = MCPHTTPGovernanceProxy(
            agent_id="test-agent",
            upstream_url="http://localhost:9999",
            **kwargs,
        )
    return proxy


class TestMCPHTTPLog:
    def test_quiet_suppresses_info(self, capsys) -> None:
        proxy = _make_http_proxy_mock(log_level="quiet")
        proxy._log("info", "ignored message")
        assert capsys.readouterr().err == ""

    def test_quiet_passes_error(self, capsys) -> None:
        proxy = _make_http_proxy_mock(log_level="quiet")
        proxy._log("error", "critical failure")
        assert "critical failure" in capsys.readouterr().err

    def test_info_suppresses_debug(self, capsys) -> None:
        proxy = _make_http_proxy_mock(log_level="info")
        proxy._log("debug", "verbose detail")
        assert capsys.readouterr().err == ""

    def test_info_passes_info(self, capsys) -> None:
        proxy = _make_http_proxy_mock(log_level="info")
        proxy._log("info", "request received")
        assert "request received" in capsys.readouterr().err

    def test_debug_passes_debug(self, capsys) -> None:
        proxy = _make_http_proxy_mock(log_level="debug")
        proxy._log("debug", "verbose detail")
        assert "verbose detail" in capsys.readouterr().err

    def test_log_is_valid_json_with_standard_fields(self, capsys) -> None:
        proxy = _make_http_proxy_mock(log_level="info")
        proxy._log("info", "test event", tool="read_file", request_id="req-1")
        line = capsys.readouterr().err.strip()
        parsed = json.loads(line)
        assert parsed["level"] == "info"
        assert parsed["message"] == "test event"
        assert parsed["agent_id"] == "test-agent"
        assert parsed["tool"] == "read_file"
        assert "timestamp" in parsed


class TestMCPHTTPHealthCheck:
    def test_returns_required_fields(self) -> None:
        proxy = _make_http_proxy_mock()
        with patch("nomotic.mcp_proxy.urllib.request.urlopen", side_effect=Exception("timeout")):
            health = proxy._health_check()
        for key in ("status", "agent_id", "upstream_url", "uptime_seconds", "requests_total", "denials_total"):
            assert key in health, f"Missing field: {key}"

    def test_unreachable_upstream_sets_degraded(self) -> None:
        proxy = _make_http_proxy_mock()
        with patch("nomotic.mcp_proxy.urllib.request.urlopen", side_effect=Exception("refused")):
            health = proxy._health_check()
        assert health["status"] == "degraded"
        assert health["upstream_status"] == "unreachable"

    def test_reachable_upstream_sets_ok(self) -> None:
        proxy = _make_http_proxy_mock()
        mock_resp = MagicMock()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        with patch("nomotic.mcp_proxy.urllib.request.urlopen", return_value=mock_resp):
            health = proxy._health_check()
        assert health["status"] == "ok"
        assert health["upstream_status"] == "reachable"

    def test_counters_reflected_in_health(self) -> None:
        proxy = _make_http_proxy_mock()
        proxy._request_count = 7
        proxy._denial_count = 2
        with patch("nomotic.mcp_proxy.urllib.request.urlopen", side_effect=Exception("timeout")):
            health = proxy._health_check()
        assert health["requests_total"] == 7
        assert health["denials_total"] == 2


class TestMCPHTTPForwardToUpstream:
    def test_successful_forward_returns_parsed_json(self) -> None:
        proxy = _make_http_proxy_mock()
        payload = json.dumps({"jsonrpc": "2.0", "result": {"data": "ok"}}).encode()
        mock_resp = MagicMock()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = payload
        with patch("nomotic.mcp_proxy.urlopen", return_value=mock_resp):
            result = proxy._forward_to_upstream(b'{"jsonrpc":"2.0","method":"test"}')
        assert result == {"jsonrpc": "2.0", "result": {"data": "ok"}}

    def test_url_error_returns_jsonrpc_error_dict(self) -> None:
        from urllib.error import URLError
        proxy = _make_http_proxy_mock()
        with patch("nomotic.mcp_proxy.urlopen", side_effect=URLError("connection refused")):
            result = proxy._forward_to_upstream(b"{}")
        assert isinstance(result, dict)
        assert result.get("jsonrpc") == "2.0"
        assert result["error"]["code"] == -32603

    def test_per_tool_timeout_used(self) -> None:
        proxy = _make_http_proxy_mock(tool_timeouts={"slow_tool": 120.0}, default_timeout=5.0)
        mock_resp = MagicMock()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = b'{"result": "ok"}'
        with patch("nomotic.mcp_proxy.urlopen", return_value=mock_resp) as mock_urlopen:
            proxy._forward_to_upstream(b"{}", tool_name="slow_tool")
        assert mock_urlopen.call_args.kwargs.get("timeout") == 120.0

    def test_default_timeout_used_for_unknown_tool(self) -> None:
        proxy = _make_http_proxy_mock(default_timeout=15.0)
        mock_resp = MagicMock()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = b'{"result": "ok"}'
        with patch("nomotic.mcp_proxy.urlopen", return_value=mock_resp) as mock_urlopen:
            proxy._forward_to_upstream(b"{}", tool_name="unknown")
        assert mock_urlopen.call_args.kwargs.get("timeout") == 15.0


# ── MCPHTTPGovernanceProxy._verify_certificate ────────────────────────────


class TestMCPHTTPVerifyCertificate:
    def test_delegates_to_verify_certificate_status(self) -> None:
        proxy = _make_http_proxy_mock()
        mock_store = MagicMock()
        proxy._cert_store = mock_store
        mock_cert = MagicMock()
        mock_cert.status = __import__("nomotic.certificate", fromlist=["CertStatus"]).CertStatus.ACTIVE
        mock_store.get.return_value = mock_cert
        result = proxy._verify_certificate("agent-1")
        assert result is None  # ACTIVE cert → valid

    def test_returns_error_string_for_invalid_cert(self) -> None:
        proxy = _make_http_proxy_mock()
        mock_store = MagicMock()
        proxy._cert_store = mock_store
        mock_store.get.return_value = None
        mock_store.list.return_value = []
        result = proxy._verify_certificate("missing-agent")
        assert result is not None
        assert "NO_VALID_CERTIFICATE" in result


# ── MCPGovernanceProxy._send_to_upstream / _send_to_client ───────────────


class TestMCPStdioSendMethods:
    def test_send_to_upstream_writes_to_stdin(self, tmp_path) -> None:
        _setup_agent(tmp_path, "SendBot")
        proxy = MCPGovernanceProxy(
            agent_id="SendBot",
            upstream_command="echo test",
            base_dir=tmp_path,
            test_mode=True,
        )
        mock_proc = MagicMock()
        proxy._upstream_proc = mock_proc
        proxy._send_to_upstream('{"jsonrpc": "2.0"}')
        mock_proc.stdin.write.assert_called_once_with(b'{"jsonrpc": "2.0"}\n')
        mock_proc.stdin.flush.assert_called_once()

    def test_send_to_upstream_noop_when_no_proc(self, tmp_path) -> None:
        _setup_agent(tmp_path, "SendBot2")
        proxy = MCPGovernanceProxy(
            agent_id="SendBot2",
            upstream_command="echo",
            base_dir=tmp_path,
            test_mode=True,
        )
        proxy._upstream_proc = None
        # Should not raise
        proxy._send_to_upstream("ignored")

    def test_send_to_client_writes_to_stdout(self, tmp_path, capsys) -> None:
        _setup_agent(tmp_path, "ClientBot")
        proxy = MCPGovernanceProxy(
            agent_id="ClientBot",
            upstream_command="echo",
            base_dir=tmp_path,
            test_mode=True,
        )
        proxy._send_to_client('{"result": 1}')
        assert capsys.readouterr().out == '{"result": 1}\n'


# ── MCPGovernanceProxy require_certificate constructor path ───────────────


class TestMCPGovernanceProxyRequireCertificate:
    def test_raises_when_cert_missing(self, tmp_path) -> None:
        # No certificate issued — should raise ValueError
        _setup_agent(tmp_path, "CertBot")
        with patch("nomotic.mcp_proxy.verify_certificate_status", return_value="NO_VALID_CERTIFICATE"):
            with patch("nomotic.mcp_proxy.GovernedToolExecutor.connect"):
                import pytest
                with pytest.raises(ValueError, match="Certificate required"):
                    MCPGovernanceProxy(
                        agent_id="CertBot",
                        upstream_command="echo",
                        base_dir=tmp_path,
                        require_certificate=True,
                    )

    def test_succeeds_when_cert_valid(self, tmp_path) -> None:
        _setup_agent(tmp_path, "GoodCertBot")
        with patch("nomotic.mcp_proxy.verify_certificate_status", return_value=None), \
             patch("nomotic.mcp_proxy.GovernedToolExecutor.connect"):
            # Should not raise
            MCPGovernanceProxy(
                agent_id="GoodCertBot",
                upstream_command="echo",
                base_dir=tmp_path,
                require_certificate=True,
            )


# ── MCPHTTPGovernanceProxy require_certificate constructor path ───────────


class TestMCPHTTPRequireCertificate:
    def test_cert_store_created_when_required(self, tmp_path) -> None:
        mock_cert_store = MagicMock()
        with patch("nomotic.mcp_proxy.GovernedToolExecutor.connect"), \
             patch("nomotic.store.FileCertificateStore", return_value=mock_cert_store):
            proxy = MCPHTTPGovernanceProxy(
                agent_id="agent",
                upstream_url="http://localhost:9999",
                base_dir=tmp_path,
                require_certificate=True,
            )
        assert proxy._cert_store is mock_cert_store
        assert proxy._require_certificate is True


# ── MCPGovernanceProxy._read_client / _read_upstream ─────────────────────


class TestMCPStdioReadMethods:
    def test_read_client_forwards_non_tool_messages(self, tmp_path, monkeypatch) -> None:
        import io
        import sys
        _setup_agent(tmp_path, "ReadBot")
        proxy = MCPGovernanceProxy(
            agent_id="ReadBot",
            upstream_command="echo",
            base_dir=tmp_path,
            test_mode=True,
        )
        upstream_messages = []
        proxy._send_to_upstream = lambda msg: upstream_messages.append(msg)
        stdin_data = '{"jsonrpc":"2.0","method":"initialize","params":{}}\n'
        monkeypatch.setattr(sys, "stdin", io.StringIO(stdin_data))
        proxy._read_client()
        assert len(upstream_messages) == 1
        assert json.loads(upstream_messages[0])["method"] == "initialize"

    def test_read_client_handles_non_json_lines(self, tmp_path, monkeypatch) -> None:
        import io
        import sys
        _setup_agent(tmp_path, "ReadBot2")
        proxy = MCPGovernanceProxy(
            agent_id="ReadBot2",
            upstream_command="echo",
            base_dir=tmp_path,
            test_mode=True,
        )
        upstream_messages = []
        proxy._send_to_upstream = lambda msg: upstream_messages.append(msg)
        monkeypatch.setattr(sys, "stdin", io.StringIO("not valid json\n"))
        proxy._read_client()
        assert upstream_messages == ["not valid json"]

    def test_read_client_intercepts_tool_calls(self, tmp_path, monkeypatch) -> None:
        import io
        import sys
        _setup_agent(tmp_path, "ReadBot3")
        proxy = MCPGovernanceProxy(
            agent_id="ReadBot3",
            upstream_command="echo",
            base_dir=tmp_path,
            test_mode=True,
        )
        upstream_messages = []
        client_messages = []
        proxy._send_to_upstream = lambda msg: upstream_messages.append(msg)
        proxy._send_to_client = lambda msg: client_messages.append(msg)
        tool_call = json.dumps({
            "jsonrpc": "2.0", "id": 1,
            "method": "tools/call",
            "params": {"name": "read", "arguments": {}},
        })
        monkeypatch.setattr(sys, "stdin", io.StringIO(tool_call + "\n"))
        proxy._read_client()
        # Tool call should be handled (either forwarded or denied)
        assert len(upstream_messages) + len(client_messages) == 1

    def test_read_client_skips_blank_lines(self, tmp_path, monkeypatch) -> None:
        import io
        import sys
        _setup_agent(tmp_path, "ReadBot4")
        proxy = MCPGovernanceProxy(
            agent_id="ReadBot4",
            upstream_command="echo",
            base_dir=tmp_path,
            test_mode=True,
        )
        upstream_messages = []
        proxy._send_to_upstream = lambda msg: upstream_messages.append(msg)
        monkeypatch.setattr(sys, "stdin", io.StringIO("\n\n\n"))
        proxy._read_client()
        assert upstream_messages == []

    def test_read_upstream_forwards_lines_to_client(self, tmp_path) -> None:
        _setup_agent(tmp_path, "UpstreamBot")
        proxy = MCPGovernanceProxy(
            agent_id="UpstreamBot",
            upstream_command="echo",
            base_dir=tmp_path,
            test_mode=True,
        )
        client_messages = []
        proxy._send_to_client = lambda msg: client_messages.append(msg)
        mock_proc = MagicMock()
        mock_proc.stdout = iter([b'{"jsonrpc":"2.0","result":{}}\n', b""])
        proxy._upstream_proc = mock_proc
        proxy._read_upstream()
        assert len(client_messages) == 1
        assert json.loads(client_messages[0])["jsonrpc"] == "2.0"

    def test_read_upstream_noop_when_no_proc(self, tmp_path) -> None:
        _setup_agent(tmp_path, "UpstreamBot2")
        proxy = MCPGovernanceProxy(
            agent_id="UpstreamBot2",
            upstream_command="echo",
            base_dir=tmp_path,
            test_mode=True,
        )
        proxy._upstream_proc = None
        # Should not raise
        proxy._read_upstream()


# ── MCPGovernanceProxy.run() ──────────────────────────────────────────────


class TestMCPGovernanceProxyRun:
    def test_run_launches_subprocess_and_terminates_on_exit(self, tmp_path) -> None:
        _setup_agent(tmp_path, "RunBot")
        proxy = MCPGovernanceProxy(
            agent_id="RunBot",
            upstream_command="echo test",
            base_dir=tmp_path,
            test_mode=True,
        )
        mock_proc = MagicMock()
        mock_proc.stdin = MagicMock()
        mock_proc.stdout = iter([])
        mock_proc.stderr = MagicMock()
        with patch("nomotic.mcp_proxy.subprocess.Popen", return_value=mock_proc), \
             patch.object(proxy, "_read_client", side_effect=KeyboardInterrupt):
            proxy.run()
        mock_proc.terminate.assert_called_once()

    def test_run_passes_upstream_command_to_popen(self, tmp_path) -> None:
        _setup_agent(tmp_path, "RunBot2")
        proxy = MCPGovernanceProxy(
            agent_id="RunBot2",
            upstream_command="python my_server.py --port 3000",
            base_dir=tmp_path,
            test_mode=True,
        )
        mock_proc = MagicMock()
        mock_proc.stdin = MagicMock()
        mock_proc.stdout = iter([])
        with patch("nomotic.mcp_proxy.subprocess.Popen", return_value=mock_proc) as mock_popen, \
             patch.object(proxy, "_read_client", side_effect=KeyboardInterrupt):
            proxy.run()
        cmd_arg = mock_popen.call_args.args[0]
        assert cmd_arg == ["python", "my_server.py", "--port", "3000"]

    def test_run_terminates_proc_on_keyboard_interrupt(self, tmp_path) -> None:
        _setup_agent(tmp_path, "RunBot3")
        proxy = MCPGovernanceProxy(
            agent_id="RunBot3",
            upstream_command="echo",
            base_dir=tmp_path,
            test_mode=True,
        )
        mock_proc = MagicMock()
        mock_proc.stdin = MagicMock()
        mock_proc.stdout = iter([])
        # Even when _read_client succeeds normally, proc is terminated in finally
        with patch("nomotic.mcp_proxy.subprocess.Popen", return_value=mock_proc), \
             patch.object(proxy, "_read_client", return_value=None):
            proxy.run()
        mock_proc.terminate.assert_called_once()


# ── MCPHTTPGovernanceProxy.run() integration ─────────────────────────────


class TestMCPHTTPGovernanceProxyRunIntegration:
    """Spin up MCPHTTPGovernanceProxy.run() in a thread to test the inner Handler."""

    def setup_method(self) -> None:
        import threading
        from http.server import HTTPServer as _RealHTTPServer
        from unittest.mock import patch as _patch

        self._server_instance = None
        self._server_ready = threading.Event()
        real_self = self

        class PatchedHTTPServer(_RealHTTPServer):
            def __init__(self, addr, handler_cls):
                super().__init__(("127.0.0.1", 0), handler_cls)
                real_self._server_instance = self
                real_self._server_ready.set()

        self._proxy = _make_http_proxy_mock(log_level="quiet")
        mock_result = MagicMock()
        mock_result.allowed = True
        mock_result.reason = "allowed"
        mock_result.verdict = "ALLOW"
        mock_result.trust_after = 0.9
        mock_result.action_id = "act-123"
        mock_result.ucs = 0.85
        self._proxy._executor.check.return_value = mock_result

        self._httpserver_patcher = _patch("nomotic.mcp_proxy.HTTPServer", PatchedHTTPServer)
        self._signal_patcher = _patch("nomotic.mcp_proxy.signal.signal")
        self._httpserver_patcher.start()
        self._signal_patcher.start()

        self._thread = threading.Thread(target=self._proxy.run, daemon=True)
        self._thread.start()

        # Wait for server to be ready (up to 5 seconds)
        self._server_ready.wait(timeout=5)
        assert self._server_instance is not None, "Server did not start in time"
        self._port = self._server_instance.server_address[1]

    def teardown_method(self) -> None:
        if self._server_instance:
            self._server_instance.shutdown()
            self._server_instance.server_close()
        self._thread.join(timeout=5)
        self._httpserver_patcher.stop()
        self._signal_patcher.stop()

    def _request_with_retry(
        self,
        method: str,
        path: str,
        body: bytes | None = None,
        headers: dict[str, str] | None = None,
    ) -> tuple[int, bytes]:
        import http.client

        last_exc: Exception | None = None
        for _ in range(2):
            conn = http.client.HTTPConnection("127.0.0.1", self._port, timeout=5)
            try:
                conn.request(method, path, body=body, headers=headers or {})
                resp = conn.getresponse()
                resp_body = resp.read()
                status = resp.status
                conn.close()
                return status, resp_body
            except (ConnectionResetError, BrokenPipeError) as exc:
                # Rare CI flake on macOS when socket is reset mid-read.
                last_exc = exc
                conn.close()
                time.sleep(0.05)

        assert last_exc is not None
        raise last_exc

    def _request_status_with_retry(
        self,
        method: str,
        path: str,
        body: bytes | None = None,
        headers: dict[str, str] | None = None,
    ) -> int:
        import http.client

        last_exc: Exception | None = None
        for _ in range(2):
            conn = http.client.HTTPConnection("127.0.0.1", self._port, timeout=5)
            try:
                conn.request(method, path, body=body, headers=headers or {})
                resp = conn.getresponse()
                status = resp.status
                conn.close()
                return status
            except (ConnectionResetError, BrokenPipeError) as exc:
                # Rare CI flake on macOS when socket is reset around response body read.
                last_exc = exc
                conn.close()
                time.sleep(0.05)

        assert last_exc is not None
        raise last_exc

    def _get(self, path: str) -> tuple[int, bytes]:
        return self._request_with_retry("GET", path)

    def _post(self, path: str, body: bytes) -> tuple[int, bytes]:
        return self._request_with_retry(
            "POST",
            path,
            body=body,
            headers={"Content-Length": str(len(body))},
        )

    def _post_with_headers(
        self,
        path: str,
        body: bytes,
        headers: dict[str, str],
    ) -> tuple[int, bytes]:
        req_headers = {"Content-Length": str(len(body)), **headers}
        return self._request_with_retry("POST", path, body=body, headers=req_headers)

    def _post_status_only(self, path: str, body: bytes) -> int:
        return self._request_status_with_retry(
            "POST",
            path,
            body=body,
            headers={"Content-Length": str(len(body))},
        )

    def _post_with_headers_status_only(
        self,
        path: str,
        body: bytes,
        headers: dict[str, str],
    ) -> int:
        req_headers = {"Content-Length": str(len(body)), **headers}
        return self._request_status_with_retry(
            "POST",
            path,
            body=body,
            headers=req_headers,
        )

    def test_health_endpoint_responds(self) -> None:
        status, body_bytes = self._get("/health")
        body = json.loads(body_bytes)
        assert status in (200, 503)
        assert "status" in body
        assert body["agent_id"] == "test-agent"

    def test_metrics_endpoint_responds(self) -> None:
        status, _ = self._get("/metrics")
        assert status == 200

    def test_unknown_get_returns_404(self) -> None:
        status, body_bytes = self._get("/unknown-path")
        body = json.loads(body_bytes)
        assert status == 404
        assert "error" in body

    def test_post_with_non_tool_call_passes_through(self) -> None:
        msg = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}}).encode()
        upstream_resp = json.dumps({"jsonrpc": "2.0", "result": {}}).encode()
        mock_resp = MagicMock()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = upstream_resp
        with patch("nomotic.mcp_proxy.urlopen", return_value=mock_resp):
            status, body_bytes = self._post("/", msg)
        assert status == 200
        body = json.loads(body_bytes)
        assert body.get("jsonrpc") == "2.0"

    def test_post_with_tool_call_governance_denied_returns_200_with_error(self) -> None:
        # Configure executor to deny
        mock_result = MagicMock()
        mock_result.allowed = False
        mock_result.reason = "policy denied"
        mock_result.verdict = "DENY"
        mock_result.trust_after = 0.5
        mock_result.action_id = "act-deny"
        mock_result.ucs = 0.3
        self._proxy._executor.check.return_value = mock_result
        msg = json.dumps({
            "jsonrpc": "2.0", "id": 5,
            "method": "tools/call",
            "params": {"name": "delete_db", "arguments": {"target": "prod"}},
        }).encode()
        status, body_bytes = self._post("/", msg)
        assert status == 200
        body = json.loads(body_bytes)
        assert body["result"]["isError"] is True

    def test_post_with_invalid_json_returns_400(self) -> None:
        status, body_bytes = self._post("/", b"not json at all {{{")
        assert status == 400
        body = json.loads(body_bytes)
        assert "error" in body

    def test_post_with_tool_call_allowed_forwards(self) -> None:
        msg = json.dumps({
            "jsonrpc": "2.0", "id": 9,
            "method": "tools/call",
            "params": {"name": "read", "arguments": {"path": "/tmp/x"}},
        }).encode()
        upstream_resp = json.dumps({"jsonrpc": "2.0", "result": {"ok": 1}}).encode()
        mock_resp = MagicMock()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = upstream_resp
        with patch("nomotic.mcp_proxy.urlopen", return_value=mock_resp):
            status, body_bytes = self._post("/", msg)
        assert status == 200
        body = json.loads(body_bytes)
        assert body["result"]["ok"] == 1

    def test_post_requires_certificate_without_identity_returns_403(self) -> None:
        self._proxy._require_certificate = True
        self._proxy._agent_id_map = {}
        self._proxy._verify_certificate = MagicMock(return_value=None)
        msg = json.dumps({"jsonrpc": "2.0", "id": 10, "method": "initialize", "params": {}}).encode()
        status = self._post_status_only("/", msg)
        assert status == 403
        self._proxy._verify_certificate.assert_not_called()

    def test_post_requires_certificate_accepts_certificate_id_header(self) -> None:
        self._proxy._require_certificate = True
        self._proxy._verify_certificate = MagicMock(return_value=None)
        msg = json.dumps({"jsonrpc": "2.0", "id": 111, "method": "initialize", "params": {}}).encode()
        with patch.object(self._proxy, "_forward_to_upstream", return_value={"jsonrpc": "2.0", "result": {}}):
            status, body_bytes = self._post_with_headers(
                "/",
                msg,
                {"X-Nomotic-Certificate-Id": "cert-123"},
            )
        assert status == 200
        body = json.loads(body_bytes)
        assert body["jsonrpc"] == "2.0"
        self._proxy._verify_certificate.assert_called_once_with("cert-123")

    def test_response_handles_bytes_body(self) -> None:
        msg = json.dumps({"jsonrpc": "2.0", "id": 12, "method": "initialize", "params": {}}).encode()
        with patch.object(self._proxy, "_forward_to_upstream", return_value=b"raw-bytes"):
            status, body_bytes = self._post("/", msg)
        assert status == 200
        assert body_bytes == b"raw-bytes"

    def test_response_handles_str_body(self) -> None:
        msg = json.dumps({"jsonrpc": "2.0", "id": 13, "method": "initialize", "params": {}}).encode()
        with patch.object(self._proxy, "_forward_to_upstream", return_value="plain-text"):
            status, body_bytes = self._post("/", msg)
        assert status == 200
        assert body_bytes == b"plain-text"

    def test_debug_mode_emits_http_log_message(self) -> None:
        self._proxy._log_level = "debug"
        with patch("nomotic.mcp_proxy.sys.stderr.write") as mock_write:
            self._get("/health")
        assert mock_write.called


class TestMCPHTTPRunSignalHandler:
    def test_shutdown_signal_sets_flag_and_starts_timer(self) -> None:
        proxy = _make_http_proxy_mock(log_level="quiet")
        proxy._host = "127.0.0.1"
        proxy._port = 0

        mock_server = MagicMock()
        mock_server.serve_forever.side_effect = KeyboardInterrupt
        signal_handlers = {}
        mock_timer = MagicMock()

        def _capture_signal(sig, handler):
            signal_handlers[sig] = handler

        with patch("nomotic.mcp_proxy.HTTPServer", return_value=mock_server), \
             patch("nomotic.mcp_proxy.signal.signal", side_effect=_capture_signal), \
             patch("nomotic.mcp_proxy.threading.Timer", return_value=mock_timer) as timer_cls:
            with pytest.raises(KeyboardInterrupt):
                proxy.run()
            assert signal.SIGTERM in signal_handlers
            signal_handlers[signal.SIGTERM](signal.SIGTERM, None)

        assert proxy._shutting_down is True
        timer_cls.assert_called_once_with(5.0, mock_server.shutdown)
        mock_timer.start.assert_called_once()
