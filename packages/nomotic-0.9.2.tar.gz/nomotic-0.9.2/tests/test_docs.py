"""Documentation quality tests — cross-platform, no shell dependencies."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).parent.parent

SEARCH_DIRS = ["src", "docs", "tests", "examples"]

SKIP_PATTERNS = [
    "Nomotic_v07", "Nomotic_v08", "CHANGELOG", ".git",
    "pr13.txt", "__pycache__", "test_docs.py",
]

TEXT_EXTENSIONS = {".py", ".md", ".rst", ".html"}


def _search_files(pattern: str, dirs: list[str]) -> list[str]:
    regex = re.compile(pattern, re.IGNORECASE)
    hits: list[str] = []
    for dir_name in dirs:
        search_dir = ROOT / dir_name
        if not search_dir.exists():
            continue
        for path in search_dir.rglob("*"):
            if path.suffix not in TEXT_EXTENSIONS:
                continue
            if any(skip in str(path) for skip in SKIP_PATTERNS):
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for i, line in enumerate(text.splitlines(), 1):
                if regex.search(line):
                    hits.append(f"{path.relative_to(ROOT)}:{i}:{line.strip()}")
    return hits


def test_no_stale_dimension_counts():
    """No file contains the old 13-dimension count."""
    pattern = r"\b13[- ]dimension|\b13 governance dimension|thirteen dimension"
    hits = _search_files(pattern, SEARCH_DIRS)
    assert not hits, "Stale '13 dimension' references:\n" + "\n".join(hits)


def test_twenty_dimensions_always_explained():
    """Every '20 dimensions' mention must include the 14+6 split context."""
    context_terms = ["14", "nomotic-pro", "open source", "plugin"]
    violations: list[str] = []
    for dir_name in ["src", "docs"]:
        search_dir = ROOT / dir_name
        if not search_dir.exists():
            continue
        for path in search_dir.rglob("*"):
            if path.suffix not in {".py", ".md"}:
                continue
            if any(skip in str(path) for skip in SKIP_PATTERNS):
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for i, line in enumerate(text.splitlines(), 1):
                if re.search(r"\b20 dimensions\b", line, re.IGNORECASE):
                    if not any(t in line for t in context_terms):
                        violations.append(
                            f"{path.relative_to(ROOT)}:{i}:{line.strip()}"
                        )
    assert not violations, (
        "Found '20 dimensions' without split explanation:\n"
        + "\n".join(violations)
    )
