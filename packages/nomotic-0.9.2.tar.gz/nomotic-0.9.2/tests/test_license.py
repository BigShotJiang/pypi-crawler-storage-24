"""Tests for the license gate infrastructure and dimension plugin discovery.

Covers:
- Key reading priority (config > env var > file)
- No key → OPEN tier (free tier, not an error)
- No validator installed → OPEN with message
- Validator discovery (mock plugin)
- Validator raises → OPEN with warning
- Tier properties (is_pro_or_above, is_enterprise)
- Expiry warning fires at correct threshold
- resolve() caching — validator called only once
- GovernanceRuntime starts cleanly with no license config
- GovernanceRuntime logs tier on startup
- OPEN tier produces 14 dimensions (D1–D14), PRO tier with mock plugin produces 14 + plugin count
- Plugin load failure is logged as warning, not raised as exception
- DimensionRegistry.available_count() returns correct breakdown
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from nomotic.license import (
    ActivatedTier,
    LicenseConfig,
    LicenseGate,
    LicenseInfo,
)
from nomotic.runtime import GovernanceRuntime, RuntimeConfig


# ── Test helpers ─────────────────────────────────────────────────────


class MockProValidator:
    """A mock license validator that returns PRO tier for 'valid-pro-key'."""

    def validate(self, key: str, config: LicenseConfig) -> LicenseInfo:
        if key == "valid-pro-key":
            return LicenseInfo(tier=ActivatedTier.PRO, org_id="test-org")
        raise ValueError("Invalid key")


class MockEnterpriseValidator:
    """A mock license validator that returns ENTERPRISE tier."""

    def validate(self, key: str, config: LicenseConfig) -> LicenseInfo:
        if key == "valid-enterprise-key":
            return LicenseInfo(
                tier=ActivatedTier.ENTERPRISE,
                org_id="test-org",
                features=["dimensions_pro", "behavioral_engine"],
            )
        raise ValueError("Invalid key")


def _make_mock_entry_point(validator_class):
    """Create a mock entry point that loads the given validator class."""
    return type(
        "MockEP",
        (),
        {
            "name": "validator",
            "value": "mock:MockValidator",
            "load": staticmethod(lambda cls=validator_class: cls),
        },
    )()


# ── Key reading priority tests ───────────────────────────────────────


class TestKeyReadingPriority:
    """License key reads from config > env var > file."""

    def test_key_from_config(self):
        gate = LicenseGate(config=LicenseConfig(key="config-key"))
        assert gate._read_key() == "config-key"

    def test_key_from_env_var(self, monkeypatch):
        monkeypatch.setenv("NOMOTIC_LICENSE_KEY", "env-key")
        gate = LicenseGate(config=LicenseConfig())
        assert gate._read_key() == "env-key"

    def test_key_from_file(self, tmp_path):
        key_file = tmp_path / "license.key"
        key_file.write_text("  file-key  \n")
        gate = LicenseGate(config=LicenseConfig(key_file=key_file))
        assert gate._read_key() == "file-key"

    def test_config_takes_priority_over_env(self, monkeypatch):
        monkeypatch.setenv("NOMOTIC_LICENSE_KEY", "env-key")
        gate = LicenseGate(config=LicenseConfig(key="config-key"))
        assert gate._read_key() == "config-key"

    def test_env_takes_priority_over_file(self, monkeypatch, tmp_path):
        monkeypatch.setenv("NOMOTIC_LICENSE_KEY", "env-key")
        key_file = tmp_path / "license.key"
        key_file.write_text("file-key")
        gate = LicenseGate(config=LicenseConfig(key_file=key_file))
        assert gate._read_key() == "env-key"

    def test_key_file_path_override(self, tmp_path):
        key_file = tmp_path / "custom.key"
        key_file.write_text("custom-key")
        gate = LicenseGate(config=LicenseConfig(key_file=key_file))
        assert gate._read_key() == "custom-key"

    def test_no_key_returns_none(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NOMOTIC_LICENSE_KEY", raising=False)
        # Point key_file to a non-existent file to avoid reading the real default
        gate = LicenseGate(config=LicenseConfig(key_file=tmp_path / "nonexistent.key"))
        assert gate._read_key() is None

    def test_key_stripped(self):
        gate = LicenseGate(config=LicenseConfig(key="  spaced-key  "))
        assert gate._read_key() == "spaced-key"


# ── LicenseGate unit tests ───────────────────────────────────────────


class TestLicenseGateNoKey:
    """No license key → OPEN tier (free tier, not an error)."""

    def test_no_config(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NOMOTIC_LICENSE_KEY", raising=False)
        gate = LicenseGate(config=LicenseConfig(key_file=tmp_path / "nonexistent.key"))
        info = gate.resolve()
        assert info.tier == ActivatedTier.OPEN
        assert info.validation_error is None

    def test_none_config(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NOMOTIC_LICENSE_KEY", raising=False)
        # Patch DEFAULT_LICENSE_FILE to avoid reading real file
        with patch("nomotic.license.DEFAULT_LICENSE_FILE", tmp_path / "nonexistent.key"):
            gate = LicenseGate(config=None)
            assert gate.tier == ActivatedTier.OPEN

    def test_empty_config(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NOMOTIC_LICENSE_KEY", raising=False)
        gate = LicenseGate(config=LicenseConfig(key_file=tmp_path / "nonexistent.key"))
        info = gate.resolve()
        assert info.tier == ActivatedTier.OPEN
        assert info.org_id is None
        assert info.expires_at is None
        assert info.features == []
        assert info.deployment == "local"
        assert info.validation_error is None


class TestLicenseGateNoValidator:
    """Key present but no validator installed → OPEN with info message."""

    def test_no_validator_installed(self, caplog):
        with patch("importlib.metadata.entry_points", return_value=[]):
            gate = LicenseGate(config=LicenseConfig(key="some-key"))
            with caplog.at_level(logging.INFO, logger="nomotic.license"):
                info = gate.resolve()
        assert info.tier == ActivatedTier.OPEN
        assert info.validation_error is not None
        assert "no license validator installed" in info.validation_error.lower()

    def test_no_validator_logs_info(self, caplog):
        with patch("importlib.metadata.entry_points", return_value=[]):
            gate = LicenseGate(config=LicenseConfig(key="some-key"))
            with caplog.at_level(logging.INFO, logger="nomotic.license"):
                gate.resolve()
        assert any("no license validator" in r.message.lower() for r in caplog.records)


class TestLicenseGateWithValidator:
    """Key present + mock validator → validator's returned tier."""

    def test_pro_tier_via_validator(self):
        mock_ep = _make_mock_entry_point(MockProValidator)
        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            gate = LicenseGate(config=LicenseConfig(key="valid-pro-key"))
            info = gate.resolve()
        assert info.tier == ActivatedTier.PRO
        assert info.org_id == "test-org"
        assert info.validation_error is None

    def test_enterprise_tier_via_validator(self):
        mock_ep = _make_mock_entry_point(MockEnterpriseValidator)
        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            gate = LicenseGate(config=LicenseConfig(key="valid-enterprise-key"))
            info = gate.resolve()
        assert info.tier == ActivatedTier.ENTERPRISE
        assert "behavioral_engine" in info.features

    def test_validator_raises_falls_to_open(self, caplog):
        mock_ep = _make_mock_entry_point(MockProValidator)
        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            gate = LicenseGate(config=LicenseConfig(key="bad-key"))
            with caplog.at_level(logging.WARNING, logger="nomotic.license"):
                info = gate.resolve()
        assert info.tier == ActivatedTier.OPEN
        assert info.validation_error is not None
        assert "invalid key" in info.validation_error.lower()


class TestLicenseGateCaching:
    """resolve() caches the result — validator called only once."""

    def test_resolve_cached(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NOMOTIC_LICENSE_KEY", raising=False)
        gate = LicenseGate(config=LicenseConfig(key_file=tmp_path / "nonexistent.key"))
        info1 = gate.resolve()
        info2 = gate.resolve()
        assert info1 is info2  # same object, not re-computed

    def test_validator_called_once(self):
        mock_validator = MagicMock()
        mock_validator.validate.return_value = LicenseInfo(tier=ActivatedTier.PRO)
        mock_ep = type(
            "MockEP", (), {
                "name": "validator",
                "value": "mock:V",
                "load": staticmethod(lambda: lambda: mock_validator),
            }
        )()

        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            gate = LicenseGate(config=LicenseConfig(key="some-key"))
            gate.resolve()
            gate.resolve()
            gate.resolve()

        mock_validator.validate.assert_called_once()


class TestLicenseGateHelpers:
    """Test convenience methods."""

    def test_is_pro_or_above(self):
        mock_ep = _make_mock_entry_point(MockProValidator)
        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            gate = LicenseGate(config=LicenseConfig(key="valid-pro-key"))
            assert gate.is_pro_or_above() is True
            assert gate.is_enterprise() is False

    def test_is_enterprise(self):
        mock_ep = _make_mock_entry_point(MockEnterpriseValidator)
        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            gate = LicenseGate(config=LicenseConfig(key="valid-enterprise-key"))
            assert gate.is_enterprise() is True
            assert gate.is_pro_or_above() is True

    def test_open_not_pro(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NOMOTIC_LICENSE_KEY", raising=False)
        gate = LicenseGate(config=LicenseConfig(key_file=tmp_path / "nonexistent.key"))
        assert gate.is_pro_or_above() is False
        assert gate.is_enterprise() is False


class TestExpiryWarning:
    """warn_if_expired_soon fires at correct threshold."""

    def test_no_warning_when_far_from_expiry(self):
        mock_ep = _make_mock_entry_point(MockProValidator)

        class FarExpiryValidator:
            def validate(self, key, config):
                return LicenseInfo(
                    tier=ActivatedTier.PRO,
                    expires_at=time.time() + 86400 * 365,
                )

        mock_ep = _make_mock_entry_point(FarExpiryValidator)
        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            gate = LicenseGate(config=LicenseConfig(key="any-key"))
            gate.resolve()
            assert gate.warn_if_expired_soon() is None

    def test_warning_when_close_to_expiry(self):
        class NearExpiryValidator:
            def validate(self, key, config):
                return LicenseInfo(
                    tier=ActivatedTier.PRO,
                    expires_at=time.time() + 86400 * 7,
                )

        mock_ep = _make_mock_entry_point(NearExpiryValidator)
        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            gate = LicenseGate(config=LicenseConfig(key="any-key"))
            gate.resolve()
            warning = gate.warn_if_expired_soon(warning_days=14)
            assert warning is not None
            assert "7 days" in warning or "6 days" in warning

    def test_no_warning_for_open(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NOMOTIC_LICENSE_KEY", raising=False)
        gate = LicenseGate(config=LicenseConfig(key_file=tmp_path / "nonexistent.key"))
        gate.resolve()
        assert gate.warn_if_expired_soon() is None

    def test_custom_warning_threshold(self):
        class ThreeDayExpiryValidator:
            def validate(self, key, config):
                return LicenseInfo(
                    tier=ActivatedTier.PRO,
                    expires_at=time.time() + 86400 * 3,
                )

        mock_ep = _make_mock_entry_point(ThreeDayExpiryValidator)
        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            gate = LicenseGate(config=LicenseConfig(key="any-key"))
            gate.resolve()
            # With default 14 days — should warn (3 < 14)
            assert gate.warn_if_expired_soon() is not None
            # With 5-day threshold — should warn (3 < 5)
            assert gate.warn_if_expired_soon(warning_days=5) is not None
            # With 2-day threshold — should NOT warn (3 > 2)
            assert gate.warn_if_expired_soon(warning_days=2) is None


class TestActivatedTierEnum:
    """ActivatedTier enum values."""

    def test_values(self):
        assert ActivatedTier.OPEN.value == "open"
        assert ActivatedTier.PRO.value == "pro"
        assert ActivatedTier.ENTERPRISE.value == "enterprise"

    def test_from_value(self):
        assert ActivatedTier("open") == ActivatedTier.OPEN
        assert ActivatedTier("pro") == ActivatedTier.PRO
        assert ActivatedTier("enterprise") == ActivatedTier.ENTERPRISE


# ── Runtime integration tests ────────────────────────────────────────


class TestRuntimeWithLicense:
    """GovernanceRuntime starts cleanly with license configurations."""

    def test_no_license_config_starts_cleanly(self, monkeypatch, tmp_path):
        """Free tier is the default — not an error."""
        monkeypatch.delenv("NOMOTIC_LICENSE_KEY", raising=False)
        with patch("nomotic.license.DEFAULT_LICENSE_FILE", tmp_path / "nonexistent.key"):
            runtime = GovernanceRuntime()
            assert runtime._activated_tier == ActivatedTier.OPEN

    def test_none_license_config(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NOMOTIC_LICENSE_KEY", raising=False)
        with patch("nomotic.license.DEFAULT_LICENSE_FILE", tmp_path / "nonexistent.key"):
            config = RuntimeConfig(license_config=None)
            runtime = GovernanceRuntime(config=config)
            assert runtime._activated_tier == ActivatedTier.OPEN

    def test_pro_license(self, mock_pro_validator):
        config = RuntimeConfig(license_config=LicenseConfig(key="valid-pro-key"))
        runtime = GovernanceRuntime(config=config)
        assert runtime._activated_tier == ActivatedTier.PRO

    def test_invalid_license_falls_to_open(self):
        with patch("importlib.metadata.entry_points", return_value=[]):
            config = RuntimeConfig(license_config=LicenseConfig(key="bad.token"))
            runtime = GovernanceRuntime(config=config)
            assert runtime._activated_tier == ActivatedTier.OPEN


class TestRuntimeLogging:
    """GovernanceRuntime logs tier on startup."""

    def test_logs_free_tier(self, caplog, monkeypatch, tmp_path):
        monkeypatch.delenv("NOMOTIC_LICENSE_KEY", raising=False)
        with patch("nomotic.license.DEFAULT_LICENSE_FILE", tmp_path / "nonexistent.key"):
            with caplog.at_level(logging.INFO, logger="nomotic.license"):
                GovernanceRuntime()
        assert any("free tier" in r.message.lower() for r in caplog.records)

    def test_logs_pro_tier(self, caplog, mock_pro_validator):
        config = RuntimeConfig(license_config=LicenseConfig(key="valid-pro-key"))
        with caplog.at_level(logging.INFO, logger="nomotic.license"):
            GovernanceRuntime(config=config)
        assert any("pro" in r.message.lower() for r in caplog.records)

    def test_logs_validation_error(self, caplog):
        with patch("importlib.metadata.entry_points", return_value=[]):
            config = RuntimeConfig(license_config=LicenseConfig(key="garbage"))
            with caplog.at_level(logging.WARNING, logger="nomotic.license"):
                GovernanceRuntime(config=config)
        assert any("validation" in r.message.lower() for r in caplog.records)


# ── Dimension registry + plugin discovery tests ──────────────────────

from nomotic.dimensions import (
    CORE_DIMENSION_NAMES,
    DimensionRegistry,
    GovernanceDimension,
)
from nomotic.types import DimensionResult, DimensionScore


class _MockPluginDimension(GovernanceDimension):
    """A fake plugin dimension for testing entry point discovery."""

    name = "mock_plugin_dimension"
    weight = 1.0
    can_veto = False
    priority = 50
    relevant_schema_fields: list[str] = []
    is_foundation = False

    def evaluate(self, action, context, **kwargs):
        result = DimensionResult(
            dimension_name=self.name,
            score=1.0,
            rules_evaluated=[],
            primary_signal="mock plugin OK",
        )
        return DimensionScore(
            dimension_name=self.name,
            score=1.0,
            weight=self.weight,
            reasoning="mock plugin evaluation",
            result=result,
        )


class _FailingPluginDimension:
    """A plugin that raises on instantiation."""

    def __init__(self):
        raise RuntimeError("plugin init failed")


class TestDimensionRegistryTierIntegration:
    """OPEN tier produces 14 dimensions (D1–D14); PRO tier discovers plugins."""

    def test_open_tier_has_14_dimensions(self):
        reg = DimensionRegistry(activated_tier=ActivatedTier.OPEN)
        assert len(reg.dimensions) == 14
        counts = reg.available_count()
        assert counts == {"core": 14, "plugin": 0, "total": 14}

    def test_open_tier_has_all_core_names(self):
        reg = DimensionRegistry(activated_tier=ActivatedTier.OPEN)
        names = {d.name for d in reg.dimensions}
        assert names == CORE_DIMENSION_NAMES

    def test_pro_tier_with_mock_plugin(self):
        """PRO tier discovers plugin dimensions via entry points."""
        mock_ep = type("MockEP", (), {
            "name": "mock_plugin_dimension",
            "value": "tests.test_license:_MockPluginDimension",
            "load": staticmethod(lambda: _MockPluginDimension),
        })()

        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            reg = DimensionRegistry(activated_tier=ActivatedTier.PRO)

        assert len(reg.dimensions) == 15  # 14 core + 1 plugin
        assert reg.get("mock_plugin_dimension") is not None
        counts = reg.available_count()
        assert counts == {"core": 14, "plugin": 1, "total": 15}

    def test_enterprise_tier_with_mock_plugin(self):
        """Enterprise tier also discovers plugin dimensions."""
        mock_ep = type("MockEP", (), {
            "name": "mock_plugin_dimension",
            "value": "tests.test_license:_MockPluginDimension",
            "load": staticmethod(lambda: _MockPluginDimension),
        })()

        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            reg = DimensionRegistry(activated_tier=ActivatedTier.ENTERPRISE)

        assert len(reg.dimensions) == 15
        counts = reg.available_count()
        assert counts["plugin"] == 1

    def test_plugin_load_failure_logged_not_raised(self, caplog):
        """Failed plugin loads are logged as warnings, not exceptions."""
        mock_ep = type("MockEP", (), {
            "name": "bad_plugin",
            "value": "tests.test_license:_FailingPluginDimension",
            "load": staticmethod(lambda: _FailingPluginDimension),
        })()

        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            with caplog.at_level(logging.WARNING, logger="nomotic.dimensions"):
                reg = DimensionRegistry(activated_tier=ActivatedTier.PRO)

        # Should still have 14 core dimensions — plugin failure didn't break anything
        assert len(reg.dimensions) == 14
        assert any("failed to load plugin dimension" in r.message.lower() for r in caplog.records)

    def test_no_plugin_discovery_for_open_tier(self):
        """OPEN tier never calls entry_points — no plugin discovery."""
        with patch("importlib.metadata.entry_points") as mock_eps:
            reg = DimensionRegistry(activated_tier=ActivatedTier.OPEN)
            mock_eps.assert_not_called()
        assert len(reg.dimensions) == 14

    def test_entry_points_exception_handled(self):
        """If importlib.metadata.entry_points raises, it's swallowed."""
        with patch("importlib.metadata.entry_points", side_effect=Exception("broken")):
            reg = DimensionRegistry(activated_tier=ActivatedTier.PRO)
        # Falls back to core-only
        assert len(reg.dimensions) == 14

    def test_available_count_with_multiple_plugins(self):
        """available_count correctly distinguishes core vs plugin."""

        class _PluginA(GovernanceDimension):
            name = "plugin_a"
            weight = 1.0
            can_veto = False
            priority = 50
            relevant_schema_fields: list[str] = []
            is_foundation = False

            def evaluate(self, action, context, **kwargs):
                return DimensionScore(
                    dimension_name=self.name, score=1.0, weight=1.0, reasoning="ok",
                )

        class _PluginB(GovernanceDimension):
            name = "plugin_b"
            weight = 1.0
            can_veto = False
            priority = 50
            relevant_schema_fields: list[str] = []
            is_foundation = False

            def evaluate(self, action, context, **kwargs):
                return DimensionScore(
                    dimension_name=self.name, score=1.0, weight=1.0, reasoning="ok",
                )

        eps = [
            type("EP", (), {"name": "plugin_a", "value": "x:A", "load": staticmethod(lambda: _PluginA)})(),
            type("EP", (), {"name": "plugin_b", "value": "x:B", "load": staticmethod(lambda: _PluginB)})(),
        ]

        with patch("importlib.metadata.entry_points", return_value=eps):
            reg = DimensionRegistry(activated_tier=ActivatedTier.PRO)

        counts = reg.available_count()
        assert counts == {"core": 14, "plugin": 2, "total": 16}
