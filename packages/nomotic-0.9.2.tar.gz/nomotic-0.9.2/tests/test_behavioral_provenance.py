"""Tests for the Behavioral Provenance system."""

from __future__ import annotations

import time
from unittest import TestCase

from nomotic.behavioral_provenance import (
    BehavioralProvenance,
    _build_behavioral_influences,
    _count_contract_invariants,
    _top3,
    build_provenance,
)
from nomotic.contract import BehavioralContract, ContractStore
from nomotic.observer import FingerprintObserver
from nomotic.priors import PriorRegistry
from nomotic.runtime import GovernanceRuntime
from nomotic.types import Action, AgentContext, TrustProfile, Verdict


def _action(action_type: str = "read", target: str = "/data", agent_id: str = "agent-1") -> Action:
    return Action(agent_id=agent_id, action_type=action_type, target=target)


def _ctx(agent_id: str = "agent-1", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


# ── Unit tests for BehavioralProvenance dataclass ────────────────────


class TestBehavioralProvenance(TestCase):
    """Tests for the BehavioralProvenance frozen dataclass."""

    def test_creation_defaults(self) -> None:
        """BehavioralProvenance() has all default values."""
        p = BehavioralProvenance()
        self.assertEqual(p.fingerprint_confidence, 0.0)
        self.assertEqual(p.total_observations, 0)
        self.assertEqual(p.action_distribution_top3, ())
        self.assertEqual(p.target_distribution_top3, ())
        self.assertEqual(p.drift_overall, 0.0)
        self.assertEqual(p.drift_severity, "none")
        self.assertEqual(p.drift_by_distribution, {})
        self.assertEqual(p.primary_drift_distribution, "")
        self.assertEqual(p.semantic_drift_overall, 0.0)
        self.assertEqual(p.semantic_most_drifted_term, "")
        self.assertEqual(p.semantic_detail, "")
        self.assertEqual(p.contract_id, "")
        self.assertEqual(p.contract_version, 0)
        self.assertEqual(p.invariants_satisfied, 0)
        self.assertEqual(p.invariants_violated, 0)
        self.assertEqual(p.invariants_approaching, 0)
        self.assertEqual(p.trust_score, 0.5)
        self.assertEqual(p.trust_direction, "stable")
        self.assertEqual(p.trust_velocity, 0.0)
        self.assertEqual(p.behavioral_influences, ())

    def test_to_dict_all_fields(self) -> None:
        """Populate all fields, verify to_dict() includes everything."""
        p = BehavioralProvenance(
            fingerprint_confidence=0.94,
            total_observations=847,
            action_distribution_top3=(("read", 0.6), ("write", 0.3), ("delete", 0.1)),
            target_distribution_top3=(("/data", 0.5), ("/api", 0.3), ("/db", 0.2)),
            drift_overall=0.12,
            drift_severity="low",
            drift_by_distribution={"action": 0.08, "target": 0.12, "temporal": 0.02, "outcome": 0.01, "semantic": 0.05},
            primary_drift_distribution="target",
            semantic_drift_overall=0.05,
            semantic_most_drifted_term="research",
            semantic_detail="Minor semantic shift",
            contract_id="contract-1",
            contract_version=3,
            invariants_satisfied=4,
            invariants_violated=0,
            invariants_approaching=1,
            trust_score=0.72,
            trust_direction="rising",
            trust_velocity=0.005,
            behavioral_influences=("low target drift (0.12) affecting behavioral consistency",),
        )
        d = p.to_dict()

        # All keys present
        self.assertIn("fingerprint_confidence", d)
        self.assertIn("total_observations", d)
        self.assertIn("action_distribution_top3", d)
        self.assertIn("target_distribution_top3", d)
        self.assertIn("drift_overall", d)
        self.assertIn("drift_severity", d)
        self.assertIn("drift_by_distribution", d)
        self.assertIn("primary_drift_distribution", d)
        self.assertIn("semantic_drift_overall", d)
        self.assertIn("semantic_most_drifted_term", d)
        self.assertIn("semantic_detail", d)
        self.assertIn("contract_id", d)
        self.assertIn("contract_version", d)
        self.assertIn("invariants_satisfied", d)
        self.assertIn("invariants_violated", d)
        self.assertIn("invariants_approaching", d)
        self.assertIn("trust_score", d)
        self.assertIn("trust_direction", d)
        self.assertIn("trust_velocity", d)
        self.assertIn("behavioral_influences", d)

        # Values correct
        self.assertEqual(d["fingerprint_confidence"], 0.94)
        self.assertEqual(d["total_observations"], 847)
        self.assertEqual(d["trust_direction"], "rising")
        self.assertEqual(d["contract_id"], "contract-1")

        # Tuples converted to lists
        self.assertIsInstance(d["action_distribution_top3"], list)
        self.assertIsInstance(d["behavioral_influences"], list)
        self.assertEqual(d["action_distribution_top3"][0], ["read", 0.6])

    def test_summary_no_drift(self) -> None:
        """summary() with defaults shows 'Drift: none'."""
        p = BehavioralProvenance()
        s = p.summary()
        self.assertIn("Drift: none", s)
        self.assertIn("FP: 0%", s)
        self.assertIn("No contract", s)
        self.assertIn("Trust: 0.50 (stable)", s)

    def test_summary_with_drift(self) -> None:
        """Set drift fields, verify summary includes severity and distribution."""
        p = BehavioralProvenance(
            fingerprint_confidence=0.85,
            total_observations=500,
            drift_overall=0.25,
            drift_severity="moderate",
            drift_by_distribution={"action": 0.25, "target": 0.10},
            primary_drift_distribution="action",
        )
        s = p.summary()
        self.assertIn("Drift: moderate", s)
        self.assertIn("action", s)
        self.assertIn("FP: 85%", s)

    def test_summary_with_contract(self) -> None:
        """Set contract fields, verify summary shows contract status."""
        p = BehavioralProvenance(
            contract_id="c-1",
            contract_version=3,
            invariants_satisfied=5,
            invariants_violated=0,
        )
        s = p.summary()
        self.assertIn("Contract v3: compliant", s)

    def test_summary_with_violations(self) -> None:
        """invariants_violated > 0, verify summary shows violation count."""
        p = BehavioralProvenance(
            contract_id="c-1",
            contract_version=1,
            invariants_satisfied=3,
            invariants_violated=2,
        )
        s = p.summary()
        self.assertIn("Contract v1: 2 violations", s)

    def test_frozen(self) -> None:
        """BehavioralProvenance is immutable."""
        import dataclasses

        p = BehavioralProvenance()
        with self.assertRaises(dataclasses.FrozenInstanceError):
            p.fingerprint_confidence = 0.5  # type: ignore[misc]


# ── Unit tests for helper functions ──────────────────────────────────


class TestTop3(TestCase):
    def test_top3_basic(self) -> None:
        dist = {"read": 0.5, "write": 0.3, "delete": 0.15, "query": 0.05}
        result = _top3(dist)
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0][0], "read")
        self.assertEqual(result[1][0], "write")
        self.assertEqual(result[2][0], "delete")

    def test_top3_less_than_3(self) -> None:
        dist = {"read": 0.8, "write": 0.2}
        result = _top3(dist)
        self.assertEqual(len(result), 2)

    def test_top3_empty(self) -> None:
        result = _top3({})
        self.assertEqual(result, ())


class TestBuildBehavioralInfluences(TestCase):
    def test_empty_when_healthy(self) -> None:
        influences = _build_behavioral_influences(None, None, None, "stable")
        self.assertEqual(influences, ())

    def test_includes_drift(self) -> None:
        class FakeDrift:
            severity = "moderate"
            action_drift = 0.25
            target_drift = 0.10
            temporal_drift = 0.05
            outcome_drift = 0.02
            semantic_drift = 0.01

        influences = _build_behavioral_influences(FakeDrift(), None, None, "stable")
        self.assertEqual(len(influences), 1)
        self.assertIn("moderate", influences[0])
        self.assertIn("action drift", influences[0])

    def test_includes_contract_violations(self) -> None:
        violations = {"action": {"current": 0.30, "threshold": 0.15}}
        influences = _build_behavioral_influences(None, None, violations, "stable")
        self.assertEqual(len(influences), 1)
        self.assertIn("contract threshold exceeded", influences[0])

    def test_includes_declining_trust(self) -> None:
        influences = _build_behavioral_influences(None, None, None, "falling")
        self.assertEqual(len(influences), 1)
        self.assertIn("declining trust trajectory", influences[0])


# ── Tests for build_provenance with real FingerprintObserver ─────────


class TestBuildProvenance(TestCase):
    """Tests for the build_provenance() factory function."""

    def setUp(self) -> None:
        self.observer = FingerprintObserver(
            prior_registry=PriorRegistry.with_defaults()
        )
        # Observe 50 actions to build up fingerprint data
        for i in range(50):
            self.observer.observe(
                "agent-1", _action("read", "/data"), Verdict.ALLOW, "data-analyst"
            )

    def test_returns_populated_provenance(self) -> None:
        """build_provenance returns a provenance with fingerprint data."""
        p = build_provenance("agent-1", self.observer)
        self.assertIsInstance(p, BehavioralProvenance)
        self.assertGreater(p.fingerprint_confidence, 0)
        self.assertEqual(p.total_observations, 50)

    def test_drift_by_distribution_populated(self) -> None:
        """After observing actions that cause drift, drift_by_distribution has keys."""
        # Shift actions to create drift
        for _ in range(50):
            self.observer.observe(
                "agent-1", _action("delete", "/other"), Verdict.ALLOW, "data-analyst"
            )
        p = build_provenance("agent-1", self.observer)
        # Drift should have been computed
        if p.drift_by_distribution:
            expected_keys = {"action", "target", "temporal", "outcome", "semantic"}
            self.assertEqual(set(p.drift_by_distribution.keys()), expected_keys)

    def test_primary_drift_distribution(self) -> None:
        """After causing action drift, primary_drift_distribution is populated."""
        for _ in range(50):
            self.observer.observe(
                "agent-1", _action("delete", "/other"), Verdict.DENY, "data-analyst"
            )
        p = build_provenance("agent-1", self.observer)
        if p.drift_by_distribution:
            self.assertNotEqual(p.primary_drift_distribution, "")

    def test_no_fingerprint_returns_defaults(self) -> None:
        """build_provenance for unknown agent returns default provenance."""
        p = build_provenance("unknown-agent", self.observer)
        self.assertEqual(p.fingerprint_confidence, 0.0)
        self.assertEqual(p.total_observations, 0)
        self.assertEqual(p.drift_by_distribution, {})

    def test_with_contract(self) -> None:
        """With a ContractStore, contract_id and version are populated."""
        store = ContractStore()
        contract = BehavioralContract(
            contract_id="test-contract",
            version=2,
            agent_id="agent-1",
            created_at=time.time(),
            archetype="data-analyst",
            expected_action_distribution={"read": 0.8, "write": 0.2},
            expected_target_distribution={"/data": 0.7, "/api": 0.3},
            expected_outcome_distribution={"allow": 0.9, "deny": 0.1},
            drift_thresholds={"action": 0.15, "target": 0.20},
        )
        store.store(contract)
        p = build_provenance("agent-1", self.observer, contract_store=store)
        self.assertEqual(p.contract_id, "test-contract")
        self.assertEqual(p.contract_version, 2)

    def test_without_contract(self) -> None:
        """Pass contract_store=None, verify contract fields are empty/zero."""
        p = build_provenance("agent-1", self.observer, contract_store=None)
        self.assertEqual(p.contract_id, "")
        self.assertEqual(p.contract_version, 0)

    def test_behavioral_influences_includes_drift(self) -> None:
        """Cause high drift, verify influences list includes drift message."""
        for _ in range(100):
            self.observer.observe(
                "agent-1", _action("delete", "/danger"), Verdict.DENY, "data-analyst"
            )
        p = build_provenance("agent-1", self.observer)
        if p.drift_severity not in ("none", ""):
            self.assertGreater(len(p.behavioral_influences), 0)
            found_drift = any("drift" in inf for inf in p.behavioral_influences)
            self.assertTrue(found_drift, f"Expected drift influence, got: {p.behavioral_influences}")

    def test_behavioral_influences_empty_when_healthy(self) -> None:
        """No drift, no violations: influences is empty."""
        # With only 50 identical observations and no drift, influences should be empty
        p = build_provenance("agent-1", self.observer)
        # Low drift = no influences (unless trust is falling)
        if p.drift_severity == "none":
            self.assertEqual(p.behavioral_influences, ())


# ── Runtime integration tests ────────────────────────────────────────


class TestRuntimeIntegration(TestCase):
    """Verify provenance is attached by the GovernanceRuntime."""

    def test_verdict_has_provenance(self) -> None:
        """Runtime.evaluate() attaches behavioral_provenance to verdict."""
        runtime = GovernanceRuntime()
        action = _action("read", "/data")
        context = _ctx("agent-1")
        verdict = runtime.evaluate(action, context)
        self.assertIsNotNone(verdict.behavioral_provenance)
        self.assertIsInstance(verdict.behavioral_provenance, BehavioralProvenance)

    def test_provenance_populates_after_observations(self) -> None:
        """After multiple evaluations, provenance has meaningful data."""
        runtime = GovernanceRuntime()
        context = _ctx("agent-1")

        # Run 30 evaluations
        for _ in range(30):
            action = _action("read", "/data")
            verdict = runtime.evaluate(action, context)

        p = verdict.behavioral_provenance
        self.assertIsNotNone(p)
        self.assertGreater(p.fingerprint_confidence, 0)
        self.assertGreater(p.total_observations, 0)

    def test_provenance_to_dict_serializable(self) -> None:
        """Provenance can be serialized to a dict."""
        import json

        runtime = GovernanceRuntime()
        action = _action("read", "/data")
        context = _ctx("agent-1")
        verdict = runtime.evaluate(action, context)
        d = verdict.behavioral_provenance.to_dict()
        # Should be JSON-serializable
        serialized = json.dumps(d)
        self.assertIsInstance(serialized, str)

    def test_provenance_in_audit_record(self) -> None:
        """When audit is enabled, the audit record includes provenance."""
        from nomotic.audit import AuditTrail

        runtime = GovernanceRuntime()
        runtime._audit_trail = AuditTrail()
        action = _action("read", "/data")
        context = _ctx("agent-1")
        runtime.evaluate(action, context)

        records = runtime._audit_trail.records
        self.assertGreater(len(records), 0)
        last_record = records[-1]
        # Provenance should be in metadata
        metadata = last_record.metadata or {}
        self.assertIn("behavioral_provenance", metadata)


# ── Cost-aware provenance tests ──────────────────────────────────────


class TestProvenanceWithCostProfile(TestCase):
    """Tests for cost-theoretic context in BehavioralProvenance."""

    def setUp(self) -> None:
        self.observer = FingerprintObserver(
            prior_registry=PriorRegistry.with_defaults()
        )
        for i in range(50):
            self.observer.observe(
                "agent-1", _action("read", "/data"), Verdict.ALLOW, "data-analyst"
            )

    def test_provenance_with_cost_profile(self) -> None:
        """Build provenance with DerivedThresholds from a CONSERVATIVE CostProfile."""
        from nomotic.threshold_engine import DerivedThresholds

        dt = DerivedThresholds(
            allow_threshold=0.15,
            deny_threshold=0.10,
            ambiguity_zone_width=0.05,
            source="cost_profile",
            cost_profile_summary={
                "false_allow": 1.0,
                "false_deny": 0.1,
                "zone_multiplier": 1.0,
            },
        )
        p = build_provenance("agent-1", self.observer, derived_thresholds=dt)
        self.assertTrue(p.cost_profile_active)
        self.assertAlmostEqual(p.cost_false_allow, 1.0)
        self.assertAlmostEqual(p.cost_false_deny, 0.1)
        self.assertAlmostEqual(p.cost_zone_multiplier, 1.0)
        self.assertAlmostEqual(p.derived_allow_threshold, 0.15)
        self.assertAlmostEqual(p.derived_deny_threshold, 0.10)
        self.assertEqual(p.threshold_source, "cost_profile")
        self.assertAlmostEqual(p.threshold_shift_from_default, abs(0.15 - 0.7))

    def test_provenance_without_cost_profile(self) -> None:
        """Build provenance without DerivedThresholds — defaults preserved."""
        p = build_provenance("agent-1", self.observer)
        self.assertFalse(p.cost_profile_active)
        self.assertAlmostEqual(p.cost_false_allow, 0.0)
        self.assertAlmostEqual(p.cost_false_deny, 0.0)
        self.assertAlmostEqual(p.derived_allow_threshold, 0.7)
        self.assertAlmostEqual(p.derived_deny_threshold, 0.3)
        self.assertEqual(p.threshold_source, "static_default")
        self.assertAlmostEqual(p.threshold_shift_from_default, 0.0)

    def test_provenance_summary_includes_cost(self) -> None:
        """summary() output includes CostProfile info when active."""
        from nomotic.threshold_engine import DerivedThresholds

        dt = DerivedThresholds(
            allow_threshold=0.15,
            deny_threshold=0.10,
            ambiguity_zone_width=0.05,
            source="cost_profile",
            cost_profile_summary={
                "false_allow": 1.0,
                "false_deny": 0.1,
                "zone_multiplier": 1.0,
            },
        )
        p = build_provenance("agent-1", self.observer, derived_thresholds=dt)
        s = p.summary()
        self.assertIn("CostProfile:", s)
        self.assertIn("C_FN=1.00", s)
        self.assertIn("C_FP=0.10", s)
        self.assertIn("Thresholds:", s)
        self.assertIn("allow=0.150", s)
        self.assertIn("deny=0.100", s)
        self.assertIn("cost_profile", s)

    def test_provenance_summary_excludes_cost_when_inactive(self) -> None:
        """summary() omits CostProfile section when not active."""
        p = build_provenance("agent-1", self.observer)
        s = p.summary()
        self.assertNotIn("CostProfile:", s)

    def test_provenance_serialization(self) -> None:
        """to_dict() includes all cost fields, round-trip preservation."""
        import json

        from nomotic.threshold_engine import DerivedThresholds

        dt = DerivedThresholds(
            allow_threshold=0.85,
            deny_threshold=0.45,
            ambiguity_zone_width=0.40,
            source="smoothed",
            cost_profile_summary={
                "false_allow": 0.6,
                "false_deny": 0.3,
                "zone_multiplier": 2.0,
            },
        )
        p = build_provenance("agent-1", self.observer, derived_thresholds=dt)
        d = p.to_dict()

        # All cost fields present
        self.assertIn("cost_profile_active", d)
        self.assertIn("cost_false_allow", d)
        self.assertIn("cost_false_deny", d)
        self.assertIn("cost_zone_multiplier", d)
        self.assertIn("derived_allow_threshold", d)
        self.assertIn("derived_deny_threshold", d)
        self.assertIn("threshold_source", d)
        self.assertIn("threshold_shift_from_default", d)

        # Values correct
        self.assertTrue(d["cost_profile_active"])
        self.assertAlmostEqual(d["cost_false_allow"], 0.6, places=3)
        self.assertAlmostEqual(d["cost_false_deny"], 0.3, places=3)
        self.assertAlmostEqual(d["cost_zone_multiplier"], 2.0, places=3)
        self.assertAlmostEqual(d["derived_allow_threshold"], 0.85, places=3)
        self.assertAlmostEqual(d["derived_deny_threshold"], 0.45, places=3)
        self.assertEqual(d["threshold_source"], "smoothed")
        self.assertAlmostEqual(d["threshold_shift_from_default"], 0.15, places=3)

        # JSON serializable
        serialized = json.dumps(d)
        self.assertIsInstance(serialized, str)

        # Round-trip: deserialize and check values are preserved
        d2 = json.loads(serialized)
        self.assertEqual(d2["cost_profile_active"], d["cost_profile_active"])
        self.assertAlmostEqual(d2["derived_allow_threshold"], d["derived_allow_threshold"], places=3)
        self.assertEqual(d2["threshold_source"], d["threshold_source"])
