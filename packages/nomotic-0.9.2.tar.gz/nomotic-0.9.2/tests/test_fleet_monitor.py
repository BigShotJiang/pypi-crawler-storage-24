"""Tests for the FleetBehavioralMonitor — multi-agent drift scopes.

Tests cover:
- Fleet drift: aggregate fleet behavioral distribution shifts
- Correlated drift: multiple agents drifting in the same direction
- Coordinated drift: drift propagation through interaction chains
- Cosine similarity helper
- Runtime integration
"""

from __future__ import annotations

import time
from unittest import TestCase
from unittest.mock import MagicMock

from nomotic.drift import DriftScore
from nomotic.fingerprint import BehavioralFingerprint
from nomotic.fleet_monitor import (
    FleetBehavioralMonitor,
    FleetDriftAlert,
    FleetDriftConfig,
    _cosine_similarity,
    _drift_vector,
)
from nomotic.observer import FingerprintObserver


# ── Helpers ────────────────────────────────────────────────────────────


def _make_drift(
    overall: float = 0.0,
    action: float = 0.0,
    target: float = 0.0,
    temporal: float = 0.0,
    outcome: float = 0.0,
    semantic: float = 0.0,
) -> DriftScore:
    return DriftScore(
        overall=overall,
        action_drift=action,
        target_drift=target,
        temporal_drift=temporal,
        outcome_drift=outcome,
        semantic_drift=semantic,
        confidence=0.9,
        window_size=100,
        baseline_size=500,
    )


def _make_fingerprint(
    agent_id: str,
    action_dist: dict[str, float] | None = None,
) -> BehavioralFingerprint:
    fp = BehavioralFingerprint(agent_id=agent_id)
    fp.action_distribution = action_dist or {"read": 0.7, "write": 0.3}
    fp.target_distribution = {"api": 0.5, "db": 0.5}
    fp.outcome_distribution = {"ALLOW": 0.8, "DENY": 0.2}
    fp.total_observations = 100
    return fp


# ── Cosine Similarity Tests ──────────────────────────────────────────


class TestCosineSimilarity(TestCase):
    def test_identical_vectors(self) -> None:
        vec = [0.3, 0.2, 0.1, 0.0, 0.4]
        self.assertAlmostEqual(_cosine_similarity(vec, vec), 1.0, places=6)

    def test_orthogonal_vectors(self) -> None:
        a = [1.0, 0.0, 0.0, 0.0, 0.0]
        b = [0.0, 1.0, 0.0, 0.0, 0.0]
        self.assertAlmostEqual(_cosine_similarity(a, b), 0.0, places=6)

    def test_opposite_vectors(self) -> None:
        a = [1.0, 0.0, 0.0, 0.0, 0.0]
        b = [-1.0, 0.0, 0.0, 0.0, 0.0]
        self.assertAlmostEqual(_cosine_similarity(a, b), -1.0, places=6)

    def test_zero_vector(self) -> None:
        a = [0.0, 0.0, 0.0, 0.0, 0.0]
        b = [1.0, 2.0, 3.0, 4.0, 5.0]
        self.assertAlmostEqual(_cosine_similarity(a, b), 0.0, places=6)

    def test_zero_both_vectors(self) -> None:
        a = [0.0, 0.0, 0.0, 0.0, 0.0]
        b = [0.0, 0.0, 0.0, 0.0, 0.0]
        self.assertAlmostEqual(_cosine_similarity(a, b), 0.0, places=6)


class TestDriftVector(TestCase):
    def test_conversion(self) -> None:
        score = _make_drift(
            overall=0.5,
            action=0.1,
            target=0.2,
            temporal=0.3,
            outcome=0.4,
            semantic=0.05,
        )
        vec = _drift_vector(score)
        self.assertEqual(vec, [0.1, 0.2, 0.3, 0.4, 0.05])


# ── Fleet Drift Tests ────────────────────────────────────────────────


class TestFleetDrift(TestCase):
    def _make_observer_with_agents(
        self, agent_dists: dict[str, dict[str, float]],
    ) -> FingerprintObserver:
        """Create a mock FingerprintObserver with given agents."""
        observer = MagicMock(spec=FingerprintObserver)
        fps = {}
        for agent_id, action_dist in agent_dists.items():
            fps[agent_id] = _make_fingerprint(agent_id, action_dist)
        observer.all_fingerprints.return_value = fps
        return observer

    def test_fleet_drift_detection(self) -> None:
        """Fleet aggregate drift triggers alert when all agents shift."""
        # Start with read-heavy fleet
        read_heavy = {
            f"agent-{i}": {"read": 0.9, "write": 0.1}
            for i in range(5)
        }
        observer = self._make_observer_with_agents(read_heavy)

        config = FleetDriftConfig(
            fleet_check_interval=1,  # Check every observation
            fleet_drift_threshold=0.10,
        )
        monitor = FleetBehavioralMonitor(config=config, fingerprint_observer=observer)

        # First call: establishes baseline
        drift = _make_drift(overall=0.05)
        alerts = monitor.on_agent_drift("agent-0", drift)
        self.assertEqual(len(alerts), 0)

        # Now shift all agents to write-heavy
        write_heavy = {
            f"agent-{i}": {"read": 0.1, "write": 0.9}
            for i in range(5)
        }
        observer.all_fingerprints.return_value = {
            aid: _make_fingerprint(aid, dist)
            for aid, dist in write_heavy.items()
        }

        # Second call: should detect fleet drift
        alerts = monitor.on_agent_drift("agent-1", drift)
        fleet_alerts = [a for a in alerts if a.scope == "fleet"]
        self.assertTrue(len(fleet_alerts) > 0)
        self.assertGreater(fleet_alerts[0].fleet_drift_score, 0.10)

    def test_fleet_drift_below_threshold(self) -> None:
        """Slight shifts below threshold produce no alert."""
        dists = {
            f"agent-{i}": {"read": 0.7, "write": 0.3}
            for i in range(5)
        }
        observer = self._make_observer_with_agents(dists)

        config = FleetDriftConfig(
            fleet_check_interval=1,
            fleet_drift_threshold=0.50,  # Very high threshold
        )
        monitor = FleetBehavioralMonitor(config=config, fingerprint_observer=observer)

        drift = _make_drift(overall=0.05)
        # First: baseline
        monitor.on_agent_drift("agent-0", drift)

        # Slight change
        dists_shifted = {
            f"agent-{i}": {"read": 0.65, "write": 0.35}
            for i in range(5)
        }
        observer.all_fingerprints.return_value = {
            aid: _make_fingerprint(aid, dist)
            for aid, dist in dists_shifted.items()
        }

        alerts = monitor.on_agent_drift("agent-1", drift)
        fleet_alerts = [a for a in alerts if a.scope == "fleet"]
        self.assertEqual(len(fleet_alerts), 0)

    def test_fleet_health_summary(self) -> None:
        """Verify get_fleet_health() returns correct agent counts."""
        dists = {
            f"agent-{i}": {"read": 0.7, "write": 0.3}
            for i in range(5)
        }
        observer = self._make_observer_with_agents(dists)

        config = FleetDriftConfig()
        monitor = FleetBehavioralMonitor(config=config, fingerprint_observer=observer)

        health = monitor.get_fleet_health()
        self.assertEqual(health["agents_tracked"], 5)
        self.assertEqual(health["agents_drifting"], 0)
        self.assertEqual(health["interaction_edges"], 0)
        self.assertIn("active_alerts", health)

    def test_fleet_drift_requires_two_agents(self) -> None:
        """Fleet drift check requires at least 2 agents."""
        observer = self._make_observer_with_agents(
            {"agent-0": {"read": 0.9, "write": 0.1}}
        )
        config = FleetDriftConfig(fleet_check_interval=1)
        monitor = FleetBehavioralMonitor(config=config, fingerprint_observer=observer)

        drift = _make_drift(overall=0.5)
        alerts = monitor.on_agent_drift("agent-0", drift)
        fleet_alerts = [a for a in alerts if a.scope == "fleet"]
        self.assertEqual(len(fleet_alerts), 0)


# ── Correlated Drift Tests ──────────────────────────────────────────


class TestCorrelatedDrift(TestCase):
    def test_correlated_detected(self) -> None:
        """3 agents drifting in the same direction triggers correlated alert."""
        config = FleetDriftConfig(
            correlation_min_agents=3,
            correlation_similarity_threshold=0.7,
            correlation_time_window=300.0,
        )
        monitor = FleetBehavioralMonitor(config=config)

        now = time.time()
        # All three agents drift in the same direction
        drift_a = _make_drift(overall=0.35, action=0.3, target=0.2, temporal=0.05, outcome=0.05, semantic=0.0)
        drift_b = _make_drift(overall=0.35, action=0.3, target=0.2, temporal=0.05, outcome=0.05, semantic=0.0)
        drift_c = _make_drift(overall=0.35, action=0.3, target=0.2, temporal=0.05, outcome=0.05, semantic=0.0)

        monitor.on_agent_drift("agent-a", drift_a, timestamp=now)
        monitor.on_agent_drift("agent-b", drift_b, timestamp=now + 1)
        alerts = monitor.on_agent_drift("agent-c", drift_c, timestamp=now + 2)

        corr_alerts = [a for a in alerts if a.scope == "correlated"]
        self.assertTrue(len(corr_alerts) > 0)
        alert = corr_alerts[0]
        self.assertEqual(len(alert.affected_agents), 3)
        self.assertGreater(alert.correlation_strength, 0.7)

    def test_correlated_different_directions(self) -> None:
        """Agents drifting in different directions do not correlate."""
        config = FleetDriftConfig(
            correlation_min_agents=3,
            correlation_similarity_threshold=0.7,
        )
        monitor = FleetBehavioralMonitor(config=config)

        now = time.time()
        # Each agent drifts in a completely different distribution
        drift_a = _make_drift(overall=0.3, action=0.3)
        drift_b = _make_drift(overall=0.3, target=0.3)
        drift_c = _make_drift(overall=0.3, temporal=0.3)

        monitor.on_agent_drift("agent-a", drift_a, timestamp=now)
        monitor.on_agent_drift("agent-b", drift_b, timestamp=now + 1)
        alerts = monitor.on_agent_drift("agent-c", drift_c, timestamp=now + 2)

        corr_alerts = [a for a in alerts if a.scope == "correlated"]
        self.assertEqual(len(corr_alerts), 0)

    def test_correlated_below_min_agents(self) -> None:
        """Only 2 agents drifting similarly (min is 3) — no alert."""
        config = FleetDriftConfig(
            correlation_min_agents=3,
            correlation_similarity_threshold=0.7,
        )
        monitor = FleetBehavioralMonitor(config=config)

        now = time.time()
        drift = _make_drift(overall=0.3, action=0.3, target=0.2)

        monitor.on_agent_drift("agent-a", drift, timestamp=now)
        alerts = monitor.on_agent_drift("agent-b", drift, timestamp=now + 1)

        corr_alerts = [a for a in alerts if a.scope == "correlated"]
        self.assertEqual(len(corr_alerts), 0)

    def test_correlation_strength(self) -> None:
        """Verify correlation_strength is the average pairwise cosine similarity."""
        config = FleetDriftConfig(
            correlation_min_agents=3,
            correlation_similarity_threshold=0.5,
        )
        monitor = FleetBehavioralMonitor(config=config)

        now = time.time()
        # All identical drift vectors -> cosine similarity = 1.0
        drift = _make_drift(overall=0.3, action=0.3, target=0.2, temporal=0.1, outcome=0.05, semantic=0.02)

        monitor.on_agent_drift("agent-a", drift, timestamp=now)
        monitor.on_agent_drift("agent-b", drift, timestamp=now + 1)
        alerts = monitor.on_agent_drift("agent-c", drift, timestamp=now + 2)

        corr_alerts = [a for a in alerts if a.scope == "correlated"]
        self.assertTrue(len(corr_alerts) > 0)
        # Identical vectors -> correlation strength should be 1.0
        self.assertAlmostEqual(corr_alerts[0].correlation_strength, 1.0, places=4)

    def test_correlated_semantic_drift(self) -> None:
        """Correlated semantic drift across fleet is detected."""
        config = FleetDriftConfig(
            correlation_min_agents=3,
            correlation_similarity_threshold=0.7,
        )
        monitor = FleetBehavioralMonitor(config=config)

        now = time.time()
        # All agents drift semantically with clean structural distributions
        drift = _make_drift(overall=0.3, semantic=0.3)

        monitor.on_agent_drift("agent-1", drift, timestamp=now)
        monitor.on_agent_drift("agent-2", drift, timestamp=now + 1)
        alerts = monitor.on_agent_drift("agent-3", drift, timestamp=now + 2)

        corr_alerts = [a for a in alerts if a.scope == "correlated"]
        self.assertTrue(len(corr_alerts) > 0)
        # Shared direction should show semantic drift
        self.assertGreater(corr_alerts[0].shared_drift_direction.get("semantic", 0), 0.1)


# ── Coordinated Drift Tests ─────────────────────────────────────────


class TestCoordinatedDrift(TestCase):
    def test_propagation_chain(self) -> None:
        """Drift propagates A->B->C in temporal order."""
        config = FleetDriftConfig(propagation_max_lag=60.0)
        monitor = FleetBehavioralMonitor(config=config)
        monitor.register_interaction("agent-a", "agent-b")
        monitor.register_interaction("agent-b", "agent-c")

        now = time.time()
        drift_a = _make_drift(overall=0.15, action=0.15)
        drift_b = _make_drift(overall=0.25, action=0.25)
        drift_c = _make_drift(overall=0.35, action=0.35)

        monitor.on_agent_drift("agent-a", drift_a, timestamp=now)
        monitor.on_agent_drift("agent-b", drift_b, timestamp=now + 10)
        alerts = monitor.on_agent_drift("agent-c", drift_c, timestamp=now + 20)

        coord_alerts = [a for a in alerts if a.scope == "coordinated"]
        self.assertTrue(len(coord_alerts) > 0)
        alert = coord_alerts[0]
        self.assertEqual(alert.propagation_chain, ["agent-a", "agent-b", "agent-c"])

    def test_amplification(self) -> None:
        """Amplification factors track drift magnitude at each hop."""
        config = FleetDriftConfig(propagation_max_lag=60.0)
        monitor = FleetBehavioralMonitor(config=config)
        monitor.register_interaction("a", "b")
        monitor.register_interaction("b", "c")

        now = time.time()
        monitor.on_agent_drift("a", _make_drift(overall=0.1), timestamp=now)
        monitor.on_agent_drift("b", _make_drift(overall=0.2), timestamp=now + 10)
        alerts = monitor.on_agent_drift("c", _make_drift(overall=0.4), timestamp=now + 20)

        coord_alerts = [a for a in alerts if a.scope == "coordinated"]
        self.assertTrue(len(coord_alerts) > 0)
        amp = coord_alerts[0].amplification_factors
        self.assertAlmostEqual(amp[0], 0.1, places=4)
        self.assertAlmostEqual(amp[1], 0.2, places=4)
        self.assertAlmostEqual(amp[2], 0.4, places=4)

    def test_no_interaction_map(self) -> None:
        """No interactions registered — no coordinated drift."""
        config = FleetDriftConfig()
        monitor = FleetBehavioralMonitor(config=config)

        now = time.time()
        drift = _make_drift(overall=0.3, action=0.3)
        monitor.on_agent_drift("agent-a", drift, timestamp=now)
        monitor.on_agent_drift("agent-b", drift, timestamp=now + 10)
        alerts = monitor.on_agent_drift("agent-c", drift, timestamp=now + 20)

        coord_alerts = [a for a in alerts if a.scope == "coordinated"]
        self.assertEqual(len(coord_alerts), 0)

    def test_wrong_temporal_order(self) -> None:
        """B drifts before A — no chain detected (temporal order violated)."""
        config = FleetDriftConfig(propagation_max_lag=60.0)
        monitor = FleetBehavioralMonitor(config=config)
        monitor.register_interaction("agent-a", "agent-b")

        now = time.time()
        drift = _make_drift(overall=0.3, action=0.3)

        # B drifts first, then A (wrong order)
        monitor.on_agent_drift("agent-b", drift, timestamp=now)
        alerts = monitor.on_agent_drift("agent-a", drift, timestamp=now + 10)

        coord_alerts = [a for a in alerts if a.scope == "coordinated"]
        self.assertEqual(len(coord_alerts), 0)

    def test_recommended_intervention(self) -> None:
        """Intervention point is first agent in chain."""
        config = FleetDriftConfig(propagation_max_lag=60.0)
        monitor = FleetBehavioralMonitor(config=config)
        monitor.register_interaction("source", "downstream")

        now = time.time()
        monitor.on_agent_drift("source", _make_drift(overall=0.2), timestamp=now)
        alerts = monitor.on_agent_drift(
            "downstream", _make_drift(overall=0.3), timestamp=now + 10
        )

        coord_alerts = [a for a in alerts if a.scope == "coordinated"]
        self.assertTrue(len(coord_alerts) > 0)
        self.assertEqual(coord_alerts[0].recommended_intervention_point, "source")

    def test_exceeds_propagation_lag(self) -> None:
        """Events too far apart are not chained."""
        config = FleetDriftConfig(propagation_max_lag=5.0)
        monitor = FleetBehavioralMonitor(config=config)
        monitor.register_interaction("a", "b")

        now = time.time()
        monitor.on_agent_drift("a", _make_drift(overall=0.3), timestamp=now)
        # 100 seconds later — exceeds 5s lag
        alerts = monitor.on_agent_drift("b", _make_drift(overall=0.3), timestamp=now + 100)

        coord_alerts = [a for a in alerts if a.scope == "coordinated"]
        self.assertEqual(len(coord_alerts), 0)


# ── Alert Serialization ──────────────────────────────────────────────


class TestFleetDriftAlert(TestCase):
    def test_to_dict(self) -> None:
        alert = FleetDriftAlert(
            alert_id="test-id",
            scope="fleet",
            severity="high",
            timestamp=1000.0,
            fleet_drift_score=0.25,
            fleet_distributions_shifted=["action", "target"],
        )
        d = alert.to_dict()
        self.assertEqual(d["alert_id"], "test-id")
        self.assertEqual(d["scope"], "fleet")
        self.assertEqual(d["severity"], "high")
        self.assertEqual(d["fleet_drift_score"], 0.25)
        self.assertEqual(d["fleet_distributions_shifted"], ["action", "target"])

    def test_to_dict_coordinated(self) -> None:
        alert = FleetDriftAlert(
            alert_id="coord-id",
            scope="coordinated",
            severity="critical",
            timestamp=2000.0,
            propagation_chain=["a", "b", "c"],
            amplification_factors=[0.1, 0.2, 0.4],
            recommended_intervention_point="a",
        )
        d = alert.to_dict()
        self.assertEqual(d["propagation_chain"], ["a", "b", "c"])
        self.assertEqual(d["amplification_factors"], [0.1, 0.2, 0.4])
        self.assertEqual(d["recommended_intervention_point"], "a")


# ── Interaction Map ──────────────────────────────────────────────────


class TestInteractionMap(TestCase):
    def test_set_interaction_map(self) -> None:
        monitor = FleetBehavioralMonitor()
        monitor.set_interaction_map({"a": {"b", "c"}, "b": {"c"}})
        self.assertEqual(monitor._interaction_map["a"], {"b", "c"})
        self.assertEqual(monitor._interaction_map["b"], {"c"})

    def test_register_interaction(self) -> None:
        monitor = FleetBehavioralMonitor()
        monitor.register_interaction("a", "b")
        monitor.register_interaction("a", "c")
        self.assertEqual(monitor._interaction_map["a"], {"b", "c"})

    def test_register_interaction_idempotent(self) -> None:
        monitor = FleetBehavioralMonitor()
        monitor.register_interaction("a", "b")
        monitor.register_interaction("a", "b")
        self.assertEqual(len(monitor._interaction_map["a"]), 1)


# ── Get Alerts Filtering ─────────────────────────────────────────────


class TestGetAlerts(TestCase):
    def test_filter_by_scope(self) -> None:
        monitor = FleetBehavioralMonitor()
        monitor._alerts = [
            FleetDriftAlert(alert_id="1", scope="fleet", severity="moderate", timestamp=1.0),
            FleetDriftAlert(alert_id="2", scope="correlated", severity="high", timestamp=2.0),
            FleetDriftAlert(alert_id="3", scope="coordinated", severity="critical", timestamp=3.0),
        ]
        fleet_alerts = monitor.get_alerts(scope="fleet")
        self.assertEqual(len(fleet_alerts), 1)
        self.assertEqual(fleet_alerts[0].scope, "fleet")

    def test_filter_unacknowledged(self) -> None:
        monitor = FleetBehavioralMonitor()
        monitor._alerts = [
            FleetDriftAlert(alert_id="1", scope="fleet", severity="moderate", timestamp=1.0, acknowledged=True),
            FleetDriftAlert(alert_id="2", scope="fleet", severity="high", timestamp=2.0, acknowledged=False),
        ]
        unack = monitor.get_alerts(unacknowledged_only=True)
        self.assertEqual(len(unack), 1)
        self.assertEqual(unack[0].alert_id, "2")


# ── Reset Baseline ───────────────────────────────────────────────────


class TestResetBaseline(TestCase):
    def test_reset(self) -> None:
        dists = {
            f"agent-{i}": {"read": 0.7, "write": 0.3}
            for i in range(3)
        }
        observer = MagicMock(spec=FingerprintObserver)
        observer.all_fingerprints.return_value = {
            aid: _make_fingerprint(aid, d) for aid, d in dists.items()
        }

        config = FleetDriftConfig(fleet_check_interval=1)
        monitor = FleetBehavioralMonitor(config=config, fingerprint_observer=observer)

        # Establish baseline
        monitor.on_agent_drift("agent-0", _make_drift(overall=0.05))
        self.assertTrue(monitor._fleet_baseline_set)

        # Reset
        monitor.reset_baseline()
        self.assertFalse(monitor._fleet_baseline_set)
        self.assertIsNone(monitor._fleet_baseline)


# ── Runtime Integration Tests ────────────────────────────────────────


class TestRuntimeIntegration(TestCase):
    def test_fleet_monitor_created(self) -> None:
        """RuntimeConfig(enable_fleet_monitor=True) creates fleet monitor."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        config = RuntimeConfig(enable_fleet_monitor=True)
        runtime = GovernanceRuntime(config=config)
        self.assertIsNotNone(runtime._fleet_monitor)

    def test_fleet_monitor_not_created(self) -> None:
        """enable_fleet_monitor=False, no fleet monitor."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        config = RuntimeConfig(enable_fleet_monitor=False)
        runtime = GovernanceRuntime(config=config)
        self.assertIsNone(runtime._fleet_monitor)

    def test_interaction_registration(self) -> None:
        """runtime.register_interaction works."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        config = RuntimeConfig(enable_fleet_monitor=True)
        runtime = GovernanceRuntime(config=config)
        runtime.register_interaction("A", "B")
        self.assertIn("B", runtime._fleet_monitor._interaction_map["A"])

    def test_get_fleet_health_when_disabled(self) -> None:
        """get_fleet_health returns defaults when fleet monitor is disabled."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        config = RuntimeConfig(enable_fleet_monitor=False)
        runtime = GovernanceRuntime(config=config)
        health = runtime.get_fleet_health()
        self.assertEqual(health["agents_tracked"], 0)

    def test_get_fleet_alerts_when_disabled(self) -> None:
        """get_fleet_alerts returns empty list when disabled."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        config = RuntimeConfig(enable_fleet_monitor=False)
        runtime = GovernanceRuntime(config=config)
        self.assertEqual(runtime.get_fleet_alerts(), [])

    def test_fleet_config_passthrough(self) -> None:
        """Custom FleetDriftConfig is passed through."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        fleet_cfg = FleetDriftConfig(fleet_check_interval=25, fleet_drift_threshold=0.3)
        config = RuntimeConfig(enable_fleet_monitor=True, fleet_config=fleet_cfg)
        runtime = GovernanceRuntime(config=config)
        self.assertEqual(runtime._fleet_monitor._config.fleet_check_interval, 25)
        self.assertAlmostEqual(runtime._fleet_monitor._config.fleet_drift_threshold, 0.3)

    def test_interaction_map_from_config(self) -> None:
        """Initial interaction map from RuntimeConfig is applied."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        config = RuntimeConfig(
            enable_fleet_monitor=True,
            interaction_map={"x": {"y", "z"}},
        )
        runtime = GovernanceRuntime(config=config)
        self.assertEqual(runtime._fleet_monitor._interaction_map["x"], {"y", "z"})
