"""Tests for the Value of Information (VOI) computation engine."""

from __future__ import annotations

import unittest

from nomotic.cost_profile import CONSERVATIVE, PERMISSIVE, CostProfile
from nomotic.human_drift import HumanDriftResult, HumanInteractionProfile
from nomotic.types import DimensionScore, TrustProfile
from nomotic.voi import VOIConfig, VOIEngine, VOIResult


def _make_profile(reviewer_id: str = "rev-1", **kwargs) -> HumanInteractionProfile:
    """Helper to create a HumanInteractionProfile with overrides."""
    return HumanInteractionProfile(reviewer_id=reviewer_id, **kwargs)


def _make_drift(
    approval_rate: float = 0.5,
    overall_drift: float = 0.1,
    **kwargs,
) -> HumanDriftResult:
    """Helper to create a HumanDriftResult with sensible defaults."""
    baseline = _make_profile(approval_rate=0.5)
    recent = _make_profile(approval_rate=approval_rate)
    return HumanDriftResult(
        reviewer_id="rev-1",
        overall_drift=overall_drift,
        drift_category=kwargs.get("drift_category", "stable"),
        timing_drift=kwargs.get("timing_drift", 0.0),
        decision_drift=kwargs.get("decision_drift", 0.0),
        engagement_drift=kwargs.get("engagement_drift", 0.0),
        throughput_drift=kwargs.get("throughput_drift", 0.0),
        risk_timing_drift=kwargs.get("risk_timing_drift", 0.0),
        fatigue_score=kwargs.get("fatigue_score", 0.0),
        alerts=[],
        baseline_profile=baseline,
        recent_profile=recent,
    )


def _make_trust(overall: float = 0.5, actions: int = 50, violations: int = 0) -> TrustProfile:
    """Helper to build a TrustProfile."""
    return TrustProfile(
        agent_id="agent-1",
        overall_trust=overall,
        successful_actions=actions,
        violation_count=violations,
    )


def _uniform_scores(value: float, n: int = 6) -> list[DimensionScore]:
    """Create n dimension scores all at the same value."""
    names = [
        "ethical_alignment", "scope_compliance", "behavioral_consistency",
        "resource_governance", "authority_boundary", "data_handling",
    ]
    return [
        DimensionScore(dimension_name=names[i % len(names)], score=value)
        for i in range(n)
    ]


class TestAgreeingDimensionsLowEntropy(unittest.TestCase):
    """All dimensions score ~0.5. Low entropy → low VOI → no escalation."""

    def test_low_entropy_no_escalation(self):
        engine = VOIEngine()
        scores = _uniform_scores(0.5, n=6)
        trust = _make_trust(overall=0.7, actions=100)
        result = engine.compute(scores, trust)

        self.assertLess(result.dimension_entropy, 0.1)
        self.assertFalse(result.should_escalate)
        self.assertEqual(result.recommended_path, "none")


class TestDisagreeingDimensionsHighEntropy(unittest.TestCase):
    """Half score 0.9, half score 0.1. High entropy → high VOI."""

    def test_high_entropy(self):
        engine = VOIEngine()
        scores = [
            DimensionScore(dimension_name="ethical_alignment", score=0.9),
            DimensionScore(dimension_name="scope_compliance", score=0.9),
            DimensionScore(dimension_name="behavioral_consistency", score=0.9),
            DimensionScore(dimension_name="resource_governance", score=0.1),
            DimensionScore(dimension_name="authority_boundary", score=0.1),
            DimensionScore(dimension_name="data_handling", score=0.1),
        ]
        trust = _make_trust(overall=0.7, actions=100)
        result = engine.compute(scores, trust)

        self.assertGreater(result.dimension_entropy, 0.3)
        self.assertGreater(result.voi_score, 0.3)


class TestWeightedDisagreement(unittest.TestCase):
    """Ethical_alignment at 0.1, all others at 0.8.

    Weighted entropy should be higher than if a non-weighted dimension
    had the same divergence.
    """

    def test_weighted_higher(self):
        engine = VOIEngine()

        # Weighted dimension (ethical_alignment) diverges
        scores_weighted = [
            DimensionScore(dimension_name="ethical_alignment", score=0.1),
            DimensionScore(dimension_name="scope_compliance", score=0.8),
            DimensionScore(dimension_name="behavioral_consistency", score=0.8),
            DimensionScore(dimension_name="resource_governance", score=0.8),
            DimensionScore(dimension_name="authority_boundary", score=0.8),
            DimensionScore(dimension_name="data_handling", score=0.8),
        ]

        # Non-weighted dimension (data_handling, weight=1.0) diverges
        scores_unweighted = [
            DimensionScore(dimension_name="ethical_alignment", score=0.8),
            DimensionScore(dimension_name="scope_compliance", score=0.8),
            DimensionScore(dimension_name="behavioral_consistency", score=0.8),
            DimensionScore(dimension_name="resource_governance", score=0.8),
            DimensionScore(dimension_name="authority_boundary", score=0.8),
            DimensionScore(dimension_name="data_handling", score=0.1),
        ]

        trust = _make_trust(overall=0.7, actions=100)

        result_w = engine.compute(scores_weighted, trust)
        result_u = engine.compute(scores_unweighted, trust)

        self.assertGreater(
            result_w.dimension_entropy,
            result_u.dimension_entropy,
            "Weighted dimension should produce higher entropy",
        )


class TestLowTrustHighUncertainty(unittest.TestCase):
    """Trust 0.15 → always escalate regardless of VOI (trust floor)."""

    def test_trust_floor_forces_escalation(self):
        engine = VOIEngine()
        scores = _uniform_scores(0.5, n=6)
        trust = _make_trust(overall=0.15, actions=100)
        result = engine.compute(scores, trust)

        self.assertTrue(result.should_escalate)
        self.assertIn("floor", result.detail)


class TestHighTrustLowUncertainty(unittest.TestCase):
    """Trust 0.9 → low trust_uncertainty signal."""

    def test_high_trust(self):
        engine = VOIEngine()
        scores = _uniform_scores(0.5, n=6)
        trust = _make_trust(overall=0.9, actions=200)
        result = engine.compute(scores, trust)

        self.assertLess(result.trust_uncertainty, 0.15)


class TestHighStakesCostSensitivity(unittest.TestCase):
    """CONSERVATIVE CostProfile → high cost_sensitivity → higher VOI."""

    def test_conservative_profile(self):
        engine = VOIEngine()
        # Create disagreeing scores to push VOI up
        scores = [
            DimensionScore(dimension_name="ethical_alignment", score=0.9),
            DimensionScore(dimension_name="scope_compliance", score=0.1),
            DimensionScore(dimension_name="behavioral_consistency", score=0.9),
            DimensionScore(dimension_name="resource_governance", score=0.1),
        ]
        trust = _make_trust(overall=0.5, actions=50)

        result_high = engine.compute(scores, trust, cost_profile=CONSERVATIVE)
        result_low = engine.compute(scores, trust, cost_profile=PERMISSIVE)

        self.assertGreater(result_high.cost_sensitivity, result_low.cost_sensitivity)
        self.assertGreater(result_high.voi_score, result_low.voi_score)


class TestLowStakesNoEscalation(unittest.TestCase):
    """PERMISSIVE CostProfile + agreeing dimensions → VOI too low, no escalation."""

    def test_low_stakes_agreement(self):
        engine = VOIEngine()
        scores = _uniform_scores(0.7, n=6)
        trust = _make_trust(overall=0.8, actions=200)
        result = engine.compute(scores, trust, cost_profile=PERMISSIVE)

        self.assertFalse(result.should_escalate)
        self.assertEqual(result.recommended_path, "none")


class TestReviewerFatigueInflatesCost(unittest.TestCase):
    """HumanDriftResult with approval_rate > threshold inflates escalation cost."""

    def test_fatigue_inflates(self):
        engine = VOIEngine()
        scores = _uniform_scores(0.5, n=6)
        trust = _make_trust(overall=0.5, actions=50)

        drift_normal = _make_drift(approval_rate=0.5)
        drift_fatigued = _make_drift(approval_rate=0.95)

        result_normal = engine.compute(scores, trust, reviewer_drift=drift_normal)
        result_fatigued = engine.compute(scores, trust, reviewer_drift=drift_fatigued)

        self.assertGreater(
            result_fatigued.escalation_cost,
            result_normal.escalation_cost,
            "Fatigued reviewer should inflate escalation cost",
        )


class TestVerdictShiftProbability(unittest.TestCase):
    """High entropy + UCS near 0.5 → high shift prob. Low entropy + UCS 0.9 → low."""

    def test_high_entropy_ambiguous_ucs(self):
        engine = VOIEngine()
        scores_disagree = [
            DimensionScore(dimension_name="ethical_alignment", score=0.9),
            DimensionScore(dimension_name="scope_compliance", score=0.1),
            DimensionScore(dimension_name="behavioral_consistency", score=0.9),
            DimensionScore(dimension_name="resource_governance", score=0.1),
        ]
        trust = _make_trust(overall=0.6, actions=100)

        result_ambig = engine.compute(scores_disagree, trust, ucs=0.5)
        result_clear = engine.compute(scores_disagree, trust, ucs=0.9)

        self.assertGreater(
            result_ambig.expected_verdict_shift_probability,
            result_clear.expected_verdict_shift_probability,
        )

    def test_low_entropy_low_shift(self):
        engine = VOIEngine()
        scores = _uniform_scores(0.7, n=6)
        trust = _make_trust(overall=0.7, actions=100)
        result = engine.compute(scores, trust, ucs=0.9)

        self.assertLess(result.expected_verdict_shift_probability, 0.1)


class TestRecommendedPathTiers(unittest.TestCase):
    """Low VOI → 'none'. Medium VOI → 'request_context'. High VOI → 'human_review'."""

    def test_no_escalation_path(self):
        engine = VOIEngine()
        scores = _uniform_scores(0.7, n=6)
        trust = _make_trust(overall=0.8, actions=200)
        result = engine.compute(scores, trust)
        self.assertEqual(result.recommended_path, "none")

    def test_request_context_path(self):
        # Force escalation via trust floor with moderate VOI
        config = VOIConfig(trust_floor=0.5, min_voi_to_escalate=0.1)
        engine = VOIEngine(config)
        scores = _uniform_scores(0.5, n=6)
        trust = _make_trust(overall=0.4, actions=100)
        result = engine.compute(scores, trust)
        self.assertTrue(result.should_escalate)
        # With low entropy, VOI should be low → request_context
        self.assertIn(result.recommended_path, ("request_context", "none"))

    def test_human_review_path(self):
        # High disagreement + low trust + high cost → high VOI
        config = VOIConfig(min_voi_to_escalate=0.1)
        engine = VOIEngine(config)
        scores = [
            DimensionScore(dimension_name="ethical_alignment", score=0.95),
            DimensionScore(dimension_name="scope_compliance", score=0.05),
            DimensionScore(dimension_name="behavioral_consistency", score=0.95),
            DimensionScore(dimension_name="resource_governance", score=0.05),
        ]
        trust = _make_trust(overall=0.15, actions=2, violations=1)
        result = engine.compute(scores, trust, cost_profile=CONSERVATIVE)
        self.assertTrue(result.should_escalate)
        # With very high VOI, should recommend human_review
        self.assertIn(result.recommended_path, ("human_review", "secondary_check"))


class TestVOIResultSerialization(unittest.TestCase):
    """to_dict() round-trip."""

    def test_to_dict(self):
        result = VOIResult(
            voi_score=0.65,
            escalation_cost=0.30,
            should_escalate=True,
            dimension_entropy=0.45,
            trust_uncertainty=0.30,
            cost_sensitivity=0.80,
            expected_verdict_shift_probability=0.35,
            dominant_disagreement=["ethical_alignment", "scope_compliance"],
            recommended_path="secondary_check",
            detail="test detail",
        )
        d = result.to_dict()

        self.assertIsInstance(d, dict)
        self.assertAlmostEqual(d["voi_score"], 0.65, places=2)
        self.assertAlmostEqual(d["escalation_cost"], 0.30, places=2)
        self.assertTrue(d["should_escalate"])
        self.assertEqual(d["recommended_path"], "secondary_check")
        self.assertEqual(d["dominant_disagreement"], ["ethical_alignment", "scope_compliance"])
        self.assertEqual(d["detail"], "test detail")
        self.assertAlmostEqual(d["dimension_entropy"], 0.45, places=2)
        self.assertAlmostEqual(d["trust_uncertainty"], 0.30, places=2)
        self.assertAlmostEqual(d["cost_sensitivity"], 0.80, places=2)


class TestNoCostProfileDefaults(unittest.TestCase):
    """No CostProfile → uses moderate defaults, computation still works."""

    def test_no_cost_profile(self):
        engine = VOIEngine()
        scores = _uniform_scores(0.5, n=6)
        trust = _make_trust(overall=0.6, actions=50)

        result = engine.compute(scores, trust, cost_profile=None)

        self.assertAlmostEqual(result.cost_sensitivity, 0.3, places=2)
        self.assertIsInstance(result.voi_score, float)
        self.assertIsInstance(result.escalation_cost, float)
        self.assertGreater(result.escalation_cost, 0.0)

    def test_no_drift_no_crash(self):
        engine = VOIEngine()
        scores = _uniform_scores(0.5, n=4)
        trust = _make_trust(overall=0.6)
        result = engine.compute(scores, trust, reviewer_drift=None)
        self.assertIsInstance(result, VOIResult)


if __name__ == "__main__":
    unittest.main()
