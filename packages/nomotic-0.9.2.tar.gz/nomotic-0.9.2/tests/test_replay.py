"""Tests for counterfactual behavioral replay."""

import json
import time
from unittest import TestCase

import pytest

from nomotic.audit_store import AuditStore, PersistentLogRecord
from nomotic.replay import (
    BehavioralReplayEngine,
    ReplayConfig,
    ReplayReport,
    VerdictComparison,
    _classify_direction,
)


def _build_audit_records(n: int = 50) -> list[PersistentLogRecord]:
    """Create a list of PersistentLogRecord representing *n* actions.

    First 40 are ALLOW (normal reads), last 10 are a mix of ALLOW and DENY.
    """
    records = []
    for i in range(n):
        if i < 40:
            verdict = "ALLOW"
            ucs = 0.8
            action_type = "read"
        elif i < 45:
            verdict = "ALLOW"
            ucs = 0.75
            action_type = "write"
        else:
            verdict = "DENY"
            ucs = 0.2
            action_type = "write"
        records.append(
            PersistentLogRecord(
                record_id=f"rec-{i}",
                timestamp=1000.0 + i,
                agent_id="agent-1",
                action_type=action_type,
                action_target="/data/reports",
                verdict=verdict,
                ucs=ucs,
                tier=2,
                trust_score=0.6,
                trust_delta=0.0,
                trust_trend="stable",
                severity="info",
                justification="test",
            )
        )
    return records


def _store_records(store: AuditStore, records: list[PersistentLogRecord]) -> None:
    """Append records to the store with proper hash chaining."""
    for record in records:
        previous_hash = store.get_last_hash(record.agent_id)
        record_dict = record.to_dict()
        record_dict["previous_hash"] = previous_hash
        record.previous_hash = previous_hash
        record.record_hash = store.compute_hash(record_dict, previous_hash)
        store.append(record)


@pytest.fixture
def audit_store(tmp_path):
    """Create an AuditStore with 50 test records."""
    store = AuditStore(tmp_path)
    records = _build_audit_records(50)
    _store_records(store, records)
    return store


@pytest.fixture
def engine(audit_store):
    """Create a BehavioralReplayEngine with the test audit store."""
    return BehavioralReplayEngine(audit_store=audit_store)


class TestDirectionClassification:
    """Test _classify_direction helper."""

    def test_same(self):
        assert _classify_direction("ALLOW", "ALLOW") == "same"
        assert _classify_direction("DENY", "DENY") == "same"

    def test_stricter(self):
        assert _classify_direction("ALLOW", "DENY") == "stricter"
        assert _classify_direction("ALLOW", "ESCALATE") == "stricter"
        assert _classify_direction("MODIFY", "DENY") == "stricter"

    def test_looser(self):
        assert _classify_direction("DENY", "ALLOW") == "looser"
        assert _classify_direction("ESCALATE", "ALLOW") == "looser"
        assert _classify_direction("DENY", "MODIFY") == "looser"

    def test_lateral_unknown(self):
        assert _classify_direction("ALLOW", "UNKNOWN") == "lateral"
        assert _classify_direction("UNKNOWN", "DENY") == "lateral"


class TestVerdictComparison:
    """Test VerdictComparison dataclass."""

    def test_creation_and_to_dict(self):
        vc = VerdictComparison(
            action_index=0,
            timestamp=1000.0,
            action_type="read",
            target="/data",
            actual_verdict="ALLOW",
            actual_ucs=0.8,
            counterfactual_verdict="DENY",
            counterfactual_ucs=0.3,
            diverged=True,
            direction="stricter",
        )
        d = vc.to_dict()
        assert d["action_index"] == 0
        assert d["actual_verdict"] == "ALLOW"
        assert d["counterfactual_verdict"] == "DENY"
        assert d["diverged"] is True
        assert d["direction"] == "stricter"

    def test_frozen(self):
        vc = VerdictComparison(
            action_index=0,
            timestamp=1000.0,
            action_type="read",
            target="/data",
            actual_verdict="ALLOW",
            actual_ucs=0.8,
            counterfactual_verdict="DENY",
            counterfactual_ucs=0.3,
            diverged=True,
            direction="stricter",
        )
        with pytest.raises(AttributeError):
            vc.action_index = 1  # type: ignore[misc]


class TestReplayEngine:
    """Tests for BehavioralReplayEngine."""

    def test_replay_empty_audit(self, tmp_path):
        """No records for agent -> report with actions_replayed=0."""
        store = AuditStore(tmp_path)
        eng = BehavioralReplayEngine(audit_store=store)
        report = eng.replay(
            agent_id="nonexistent-agent",
            replay_config=ReplayConfig(description="empty test"),
        )
        assert report.actions_replayed == 0
        assert report.total_divergences == 0
        assert "No actions found" in report.summary

    def test_replay_no_audit_store(self):
        """No audit store at all -> empty report."""
        eng = BehavioralReplayEngine(audit_store=None)
        report = eng.replay(
            agent_id="agent-1",
            replay_config=ReplayConfig(),
        )
        assert report.actions_replayed == 0

    def test_replay_same_config(self, engine):
        """Replay with default config. Should produce zero or minimal divergences.

        The counterfactual runtime has the same default thresholds, so
        verdicts should largely match. Some small differences may occur
        because the replay runtime starts with a fresh trust profile.
        """
        report = engine.replay(
            agent_id="agent-1",
            replay_config=ReplayConfig(description="baseline defaults"),
        )
        assert report.actions_replayed == 50
        assert report.report_id.startswith("replay-")
        assert report.time_range_start == 1000.0
        assert report.time_range_end == 1049.0

    def test_replay_stricter_threshold(self, engine):
        """Set allow_threshold=0.95 and deny_threshold=0.9. Divergences expected.

        The counterfactual runtime evaluates actions freshly with its own
        UCS pipeline, so divergences depend on the runtime's scoring.
        With very high thresholds, the runtime should produce divergences.
        """
        report = engine.replay(
            agent_id="agent-1",
            replay_config=ReplayConfig(
                allow_threshold=0.95,
                deny_threshold=0.9,
                description="stricter threshold",
            ),
        )
        assert report.actions_replayed == 50
        # With very tight thresholds, the runtime should produce divergences
        # because the counterfactual UCS (~0.84) falls between the new
        # deny_threshold (0.9) and allow_threshold (0.95), producing
        # ESCALATE or DENY verdicts for actions that were originally ALLOW.
        assert report.total_divergences > 0
        # Verify direction classification works correctly for all divergences
        for dp in report.divergence_points:
            assert dp.diverged is True
            assert dp.direction in ("stricter", "looser", "lateral")

    def test_replay_looser_threshold(self, engine):
        """Set allow_threshold=0.1. Should produce fewer denials."""
        report = engine.replay(
            agent_id="agent-1",
            replay_config=ReplayConfig(
                allow_threshold=0.1,
                deny_threshold=0.05,
                description="very loose threshold",
            ),
        )
        assert report.actions_replayed == 50
        # With very loose thresholds, actions that were DENY should
        # now be ALLOW, making them "looser".
        assert report.looser_count >= 0  # At minimum no regression

    def test_report_summary(self, engine):
        """Verify generate_summary() produces readable text with correct counts."""
        report = engine.replay(
            agent_id="agent-1",
            replay_config=ReplayConfig(
                allow_threshold=0.9,
                description="summary test",
            ),
        )
        summary = report.summary
        assert "agent-1" in summary
        assert "Replayed" in summary
        assert "50" in summary

    def test_report_to_dict(self, engine):
        """Report serializes correctly."""
        report = engine.replay(
            agent_id="agent-1",
            replay_config=ReplayConfig(description="dict test"),
        )
        d = report.to_dict()
        assert "report_id" in d
        assert "agent_id" in d
        assert d["agent_id"] == "agent-1"
        assert "divergence_points" in d
        assert isinstance(d["divergence_points"], list)
        # Ensure JSON serializable
        json.dumps(d)

    def test_compare_configs(self, engine):
        """Compare two different configs, verify both reports returned."""
        config_a = ReplayConfig(allow_threshold=0.5, description="config A")
        config_b = ReplayConfig(allow_threshold=0.9, description="config B")
        results = engine.compare_configs(
            agent_id="agent-1",
            config_a=config_a,
            config_b=config_b,
        )
        assert "config_a" in results
        assert "config_b" in results
        assert results["config_a"].actions_replayed == 50
        assert results["config_b"].actions_replayed == 50
        assert results["config_a"].replay_config_description == "config A"
        assert results["config_b"].replay_config_description == "config B"

    def test_replay_fleet(self, audit_store):
        """Replay two agents, verify both get reports."""
        # Add records for a second agent.
        records2 = []
        for i in range(10):
            records2.append(
                PersistentLogRecord(
                    record_id=f"rec2-{i}",
                    timestamp=2000.0 + i,
                    agent_id="agent-2",
                    action_type="read",
                    action_target="/data/other",
                    verdict="ALLOW",
                    ucs=0.85,
                    tier=2,
                    trust_score=0.7,
                    trust_delta=0.0,
                    trust_trend="stable",
                    severity="info",
                    justification="test",
                )
            )
        _store_records(audit_store, records2)

        eng = BehavioralReplayEngine(audit_store=audit_store)
        results = eng.replay_fleet(
            agent_ids=["agent-1", "agent-2"],
            replay_config=ReplayConfig(allow_threshold=0.9, description="fleet test"),
        )
        assert "agent-1" in results
        assert "agent-2" in results
        assert results["agent-1"].actions_replayed == 50
        assert results["agent-2"].actions_replayed == 10

    def test_replay_time_filter(self, engine):
        """Replay with time range filter."""
        report = engine.replay(
            agent_id="agent-1",
            replay_config=ReplayConfig(description="time filter"),
            start_time=1010.0,
            end_time=1020.0,
        )
        assert report.actions_replayed <= 11  # timestamps 1010..1020
        assert report.actions_replayed >= 1

    def test_replay_max_actions(self, engine):
        """Replay with max_actions limit."""
        report = engine.replay(
            agent_id="agent-1",
            replay_config=ReplayConfig(description="max actions"),
            max_actions=5,
        )
        assert report.actions_replayed == 5


class TestReconstructAction:
    """Test action reconstruction from audit records."""

    def test_reconstruction(self):
        record = PersistentLogRecord(
            record_id="test-rec-1",
            timestamp=1234.5,
            agent_id="agent-x",
            action_type="write",
            action_target="/data/sensitive",
            verdict="ALLOW",
            ucs=0.9,
            tier=2,
            trust_score=0.7,
            trust_delta=0.01,
            trust_trend="rising",
            severity="info",
            justification="allowed",
            parameters={"key": "value"},
        )
        engine = BehavioralReplayEngine()
        action = engine._reconstruct_action(record)
        assert action.id == "test-rec-1"
        assert action.action_type == "write"
        assert action.target == "/data/sensitive"
        assert action.agent_id == "agent-x"
        assert action.timestamp == 1234.5
        assert action.parameters == {"key": "value"}


class TestReplayConfig:
    """Test ReplayConfig serialization."""

    def test_to_dict_empty(self):
        rc = ReplayConfig()
        d = rc.to_dict()
        assert d == {}

    def test_to_dict_with_values(self):
        rc = ReplayConfig(
            allow_threshold=0.9,
            deny_threshold=0.2,
            description="test config",
        )
        d = rc.to_dict()
        assert d["allow_threshold"] == 0.9
        assert d["deny_threshold"] == 0.2
        assert d["description"] == "test config"

    def test_from_dict(self):
        data = {
            "allow_threshold": 0.85,
            "description": "round trip",
        }
        rc = ReplayConfig.from_dict(data)
        assert rc.allow_threshold == 0.85
        assert rc.description == "round trip"
        assert rc.deny_threshold is None

    def test_to_dict_with_cost_profile(self):
        rc = ReplayConfig(
            cost_profile={
                "false_allow_cost": 1.0,
                "false_deny_cost": 0.1,
                "zone_multiplier": 1.0,
            },
            description="conservative replay",
        )
        d = rc.to_dict()
        assert "cost_profile" in d
        assert d["cost_profile"]["false_allow_cost"] == 1.0
        assert d["description"] == "conservative replay"

    def test_from_dict_with_cost_profile(self):
        data = {
            "cost_profile": {
                "false_allow_cost": 1.0,
                "false_deny_cost": 0.1,
            },
            "description": "cost round trip",
        }
        rc = ReplayConfig.from_dict(data)
        assert rc.cost_profile is not None
        assert rc.cost_profile["false_allow_cost"] == 1.0
        assert rc.description == "cost round trip"


class TestReplayCostProfile:
    """Tests for replaying with alternative CostProfiles."""

    def test_replay_with_alternative_cost_profile(self, audit_store):
        """Replay with CONSERVATIVE CostProfile (original was BALANCED).

        CONSERVATIVE means false_allow_cost is high (1.0) while false_deny_cost
        is low (0.1). This creates a very low allow threshold via signal
        detection theory, meaning actions need less confidence to be allowed.
        But the key effect is that the entire threshold dynamics change,
        and the counterfactual runtime should produce different verdicts.
        """
        from nomotic.cost_profile import CONSERVATIVE

        eng = BehavioralReplayEngine(audit_store=audit_store)
        report = eng.replay(
            agent_id="agent-1",
            replay_config=ReplayConfig(
                cost_profile=CONSERVATIVE.to_dict(),
                description="CONSERVATIVE counterfactual",
            ),
        )
        assert report.actions_replayed == 50
        assert report.cost_profile_used is not None
        assert report.cost_profile_used.get("false_allow_cost") == CONSERVATIVE.false_allow_cost
        # The report should have a description referencing the config
        assert report.replay_config_description == "CONSERVATIVE counterfactual"

    def test_replay_cost_profile_in_report(self, audit_store):
        """ReplayReport includes note about which CostProfile was used."""
        eng = BehavioralReplayEngine(audit_store=audit_store)
        cost_profile = {
            "false_allow_cost": 1.0,
            "false_deny_cost": 0.1,
            "false_allow_label": "CRITICAL",
            "false_deny_label": "LOW",
            "zone_multiplier": 1.0,
        }
        report = eng.replay(
            agent_id="agent-1",
            replay_config=ReplayConfig(
                cost_profile=cost_profile,
                description="CONSERVATIVE vs original BALANCED",
            ),
        )
        # Verify cost_profile_used is populated in the report
        assert report.cost_profile_used == cost_profile
        d = report.to_dict()
        assert "cost_profile_used" in d
        assert d["cost_profile_used"]["false_allow_cost"] == 1.0
        assert d["cost_profile_used"]["false_deny_label"] == "LOW"

    def test_replay_no_cost_profile_report_empty(self, engine):
        """When no cost_profile is used, cost_profile_used is empty."""
        report = engine.replay(
            agent_id="agent-1",
            replay_config=ReplayConfig(description="no cost profile"),
        )
        assert report.cost_profile_used == {}
