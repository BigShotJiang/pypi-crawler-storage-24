"""Tests for framework adapters (import error paths)."""

import builtins
import importlib
import sys

import pytest


class TestFastAPIAdapter:
    def test_import_without_fastapi_raises(self):
        """Importing the FastAPI adapter without fastapi should raise ImportError."""
        # This test only runs if fastapi is NOT installed
        try:
            import fastapi  # noqa: F401
            pytest.skip("fastapi is installed, cannot test import error")
        except ImportError:
            pass

        # Ensure a stale cached module (e.g. from test_web_adapters) is gone
        sys.modules.pop("nomotic.adapters.fastapi_adapter", None)

        with pytest.raises(ImportError, match="pip install"):
            importlib.import_module("nomotic.adapters.fastapi_adapter")

    def test_import_error_message_when_starlette_import_fails(self):
        """Import path raises the adapter guidance message when starlette import fails."""
        original_import = builtins.__import__

        def _failing_import(name, globals=None, locals=None, fromlist=(), level=0):
            if name.startswith("starlette"):
                raise ImportError("forced starlette import failure")
            return original_import(name, globals, locals, fromlist, level)

        with pytest.raises(ImportError, match=r"nomotic\[fastapi\]"):
            with pytest.MonkeyPatch.context() as mp:
                mp.setattr(builtins, "__import__", _failing_import)
                mp.delitem(sys.modules, "nomotic.adapters.fastapi_adapter", raising=False)
                importlib.import_module("nomotic.adapters.fastapi_adapter")


class TestFlaskAdapter:
    def test_import_without_flask_raises(self):
        """Importing the Flask adapter without flask should raise ImportError."""
        try:
            import flask  # noqa: F401
            pytest.skip("flask is installed, cannot test import error")
        except ImportError:
            pass

        # Ensure a stale cached module (e.g. from test_web_adapters) is gone
        sys.modules.pop("nomotic.adapters.flask_adapter", None)

        with pytest.raises(ImportError, match="pip install"):
            importlib.import_module("nomotic.adapters.flask_adapter")
