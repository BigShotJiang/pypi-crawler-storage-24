"""Tests for semantic drift — the fifth behavioral fingerprint distribution."""

from __future__ import annotations

import threading
import time
import uuid
from unittest import TestCase

from nomotic.drift import DriftCalculator, DriftScore
from nomotic.fingerprint import BehavioralFingerprint
from nomotic.priors import PriorRegistry
from nomotic.semantic import (
    SemanticAnchor,
    SemanticActionMap,
    SemanticDriftScore,
    SemanticObserver,
)
from nomotic.types import Action, Verdict


# ── Helpers ──────────────────────────────────────────────────────────────


def _action(
    action_type: str = "read",
    target: str = "/data",
    parameters: dict | None = None,
    agent_id: str = "agent-1",
) -> Action:
    return Action(
        id=str(uuid.uuid4())[:12],
        action_type=action_type,
        target=target,
        parameters=parameters or {},
        agent_id=agent_id,
        timestamp=time.time(),
    )


# ── SemanticAnchor Tests ────────────────────────────────────────────────


class TestSemanticAnchor(TestCase):
    def test_creation(self) -> None:
        anchor = SemanticAnchor(
            term="research",
            expected_action_distribution={"read": 0.9, "query": 0.1},
            expected_target_distribution={"search_api": 0.7, "reviews": 0.3},
            tolerance=0.20,
        )
        self.assertEqual(anchor.term, "research")
        self.assertAlmostEqual(anchor.expected_action_distribution["read"], 0.9)
        self.assertAlmostEqual(anchor.tolerance, 0.20)

    def test_to_dict_roundtrip(self) -> None:
        anchor = SemanticAnchor(
            term="analyze",
            expected_action_distribution={"read": 0.6, "query": 0.4},
            expected_target_distribution={"data": 0.8, "report": 0.2},
            tolerance=0.10,
        )
        d = anchor.to_dict()
        restored = SemanticAnchor.from_dict(d)
        self.assertEqual(restored.term, "analyze")
        self.assertAlmostEqual(restored.expected_action_distribution["read"], 0.6)
        self.assertAlmostEqual(restored.tolerance, 0.10)

    def test_from_dict_defaults(self) -> None:
        restored = SemanticAnchor.from_dict({"term": "book"})
        self.assertEqual(restored.term, "book")
        self.assertEqual(restored.expected_action_distribution, {})
        self.assertEqual(restored.expected_target_distribution, {})
        self.assertAlmostEqual(restored.tolerance, 0.15)


# ── SemanticActionMap Tests ─────────────────────────────────────────────


class TestSemanticActionMap(TestCase):
    def test_observe_single_term(self) -> None:
        sam = SemanticActionMap(agent_id="agent-1")
        for _ in range(10):
            sam.observe("research", "read", "/data")

        dist = sam.get_term_distribution("research")
        self.assertIsNotNone(dist)
        self.assertAlmostEqual(dist["action_distribution"]["read"], 1.0)
        self.assertEqual(dist["total"], 10)

    def test_observe_multiple_terms(self) -> None:
        sam = SemanticActionMap(agent_id="agent-1")
        for _ in range(5):
            sam.observe("research", "read", "/data")
        for _ in range(5):
            sam.observe("book", "write", "/booking")

        research = sam.get_term_distribution("research")
        book = sam.get_term_distribution("book")
        self.assertIsNotNone(research)
        self.assertIsNotNone(book)
        self.assertAlmostEqual(research["action_distribution"]["read"], 1.0)
        self.assertAlmostEqual(book["action_distribution"]["write"], 1.0)

    def test_observe_mixed_actions(self) -> None:
        sam = SemanticActionMap(agent_id="agent-1")
        for _ in range(7):
            sam.observe("research", "read", "/data")
        for _ in range(3):
            sam.observe("research", "write", "/data")

        dist = sam.get_term_distribution("research")
        self.assertIsNotNone(dist)
        self.assertAlmostEqual(dist["action_distribution"]["read"], 0.7)
        self.assertAlmostEqual(dist["action_distribution"]["write"], 0.3)

    def test_compute_drift_no_drift(self) -> None:
        sam = SemanticActionMap(agent_id="agent-1")
        # Observe actions matching the anchor
        for _ in range(90):
            sam.observe("research", "read", "/search_api")
        for _ in range(10):
            sam.observe("research", "query", "/search_api")

        anchor = SemanticAnchor(
            term="research",
            expected_action_distribution={"read": 0.9, "query": 0.1},
            expected_target_distribution={"search_api": 1.0},
        )
        # Target mismatch: observed="/search_api" vs expected="search_api", but
        # the action distribution matches well
        score = sam.compute_drift([anchor])
        # Action distribution matches well → action_jsd near 0
        self.assertLess(score.overall, 0.5)

    def test_compute_drift_high_drift(self) -> None:
        sam = SemanticActionMap(agent_id="agent-1")
        # Anchor expects 90% read, but observations are 50/50
        for _ in range(50):
            sam.observe("research", "read", "/data")
        for _ in range(50):
            sam.observe("research", "write", "/data")

        anchor = SemanticAnchor(
            term="research",
            expected_action_distribution={"read": 0.9, "query": 0.1},
            expected_target_distribution={"data": 1.0},
        )
        score = sam.compute_drift([anchor])
        self.assertGreater(score.overall, 0.3)

    def test_compute_drift_no_observations(self) -> None:
        sam = SemanticActionMap(agent_id="agent-1")
        anchor = SemanticAnchor(
            term="research",
            expected_action_distribution={"read": 0.9},
            expected_target_distribution={"data": 1.0},
        )
        score = sam.compute_drift([anchor])
        self.assertAlmostEqual(score.overall, 0.0)

    def test_compute_drift_multiple_terms(self) -> None:
        sam = SemanticActionMap(agent_id="agent-1")
        # Term 1: matches anchor well
        for _ in range(50):
            sam.observe("research", "read", "/data")
        # Term 2: drifted
        for _ in range(50):
            sam.observe("book", "write", "/booking")

        anchors = [
            SemanticAnchor(
                term="research",
                expected_action_distribution={"read": 1.0},
                expected_target_distribution={"data": 1.0},
            ),
            SemanticAnchor(
                term="book",
                expected_action_distribution={"read": 1.0},  # expected read, got write
                expected_target_distribution={"booking": 1.0},
            ),
        ]
        score = sam.compute_drift(anchors)
        # Overall should be weighted average; "book" is heavily drifted
        self.assertGreater(score.overall, 0.0)
        self.assertEqual(score.most_drifted_term, "book")

    def test_to_dict_roundtrip(self) -> None:
        sam = SemanticActionMap(agent_id="agent-1")
        for _ in range(10):
            sam.observe("research", "read", "/data")
        for _ in range(5):
            sam.observe("research", "write", "/api")

        d = sam.to_dict()
        restored = SemanticActionMap.from_dict(d)
        self.assertEqual(restored.agent_id, "agent-1")
        dist = restored.get_term_distribution("research")
        self.assertIsNotNone(dist)
        self.assertEqual(dist["total"], 15)

    def test_thread_safety(self) -> None:
        sam = SemanticActionMap(agent_id="agent-1")
        errors: list[Exception] = []

        def worker(term: str, action_type: str, count: int) -> None:
            try:
                for _ in range(count):
                    sam.observe(term, action_type, "/data")
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=worker, args=("research", "read", 100)),
            threading.Thread(target=worker, args=("research", "write", 100)),
            threading.Thread(target=worker, args=("book", "write", 100)),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(len(errors), 0)
        dist = sam.get_term_distribution("research")
        self.assertIsNotNone(dist)
        self.assertEqual(dist["total"], 200)


# ── SemanticDriftScore Tests ────────────────────────────────────────────


class TestSemanticDriftScore(TestCase):
    def test_severity_thresholds(self) -> None:
        self.assertEqual(SemanticDriftScore(overall=0.02).severity, "none")
        self.assertEqual(SemanticDriftScore(overall=0.10).severity, "low")
        self.assertEqual(SemanticDriftScore(overall=0.25).severity, "moderate")
        self.assertEqual(SemanticDriftScore(overall=0.50).severity, "high")
        self.assertEqual(SemanticDriftScore(overall=0.75).severity, "critical")

    def test_to_dict(self) -> None:
        score = SemanticDriftScore(
            overall=0.3,
            per_term={"research": 0.1, "book": 0.5},
            most_drifted_term="book",
            detail="Term 'book' shifted",
        )
        d = score.to_dict()
        self.assertIn("overall", d)
        self.assertIn("per_term", d)
        self.assertIn("most_drifted_term", d)
        self.assertIn("detail", d)
        self.assertIn("severity", d)
        self.assertEqual(d["most_drifted_term"], "book")


# ── SemanticObserver Tests ──────────────────────────────────────────────


class TestSemanticObserver(TestCase):
    def test_observe_with_instruction_context(self) -> None:
        obs = SemanticObserver()
        anchor = SemanticAnchor(
            term="research",
            expected_action_distribution={"read": 0.9, "query": 0.1},
            expected_target_distribution={"search_api": 1.0},
        )
        obs.set_anchors("agent-1", [anchor])

        for _ in range(10):
            action = _action("read", "/search_api", {"instruction_context": "research flights"})
            obs.observe("agent-1", action)

        score = obs.get_semantic_drift("agent-1")
        self.assertIsNotNone(score)
        self.assertIsInstance(score, SemanticDriftScore)

    def test_observe_extracts_from_parameters(self) -> None:
        obs = SemanticObserver()
        anchor = SemanticAnchor(
            term="analyze",
            expected_action_distribution={"read": 1.0},
            expected_target_distribution={"data": 1.0},
        )
        obs.set_anchors("agent-1", [anchor])

        action = _action("read", "/data", {"task_description": "analyze the data"})
        obs.observe("agent-1", action)

        sem_map = obs.get_map("agent-1")
        self.assertIsNotNone(sem_map)
        dist = sem_map.get_term_distribution("analyze")
        self.assertIsNotNone(dist)
        self.assertEqual(dist["total"], 1)

    def test_observe_untagged_fallback(self) -> None:
        obs = SemanticObserver()
        action = _action("read", "/data")
        obs.observe("agent-1", action)

        sem_map = obs.get_map("agent-1")
        self.assertIsNotNone(sem_map)
        dist = sem_map.get_term_distribution("__untagged__")
        self.assertIsNotNone(dist)
        self.assertEqual(dist["total"], 1)

    def test_anchor_term_matching(self) -> None:
        obs = SemanticObserver()
        anchor = SemanticAnchor(
            term="analyze",
            expected_action_distribution={"read": 1.0},
            expected_target_distribution={"data": 1.0},
        )
        obs.set_anchors("agent-1", [anchor])

        action = _action("read", "/data", {"instruction_context": "please analyze the data"})
        obs.observe("agent-1", action)

        sem_map = obs.get_map("agent-1")
        self.assertIsNotNone(sem_map)
        dist = sem_map.get_term_distribution("analyze")
        self.assertIsNotNone(dist)
        self.assertEqual(dist["total"], 1)

    def test_no_anchors_returns_none(self) -> None:
        obs = SemanticObserver()
        action = _action("read", "/data")
        obs.observe("agent-1", action)

        score = obs.get_semantic_drift("agent-1")
        self.assertIsNone(score)

    def test_set_anchors_replaces(self) -> None:
        obs = SemanticObserver()
        anchor1 = SemanticAnchor(
            term="research",
            expected_action_distribution={"read": 1.0},
            expected_target_distribution={"data": 1.0},
        )
        anchor2 = SemanticAnchor(
            term="book",
            expected_action_distribution={"write": 1.0},
            expected_target_distribution={"booking": 1.0},
        )
        obs.set_anchors("agent-1", [anchor1])
        self.assertEqual(len(obs.get_anchors("agent-1")), 1)

        obs.set_anchors("agent-1", [anchor2])
        anchors = obs.get_anchors("agent-1")
        self.assertEqual(len(anchors), 1)
        self.assertEqual(anchors[0].term, "book")

    def test_reset(self) -> None:
        obs = SemanticObserver()
        anchor = SemanticAnchor(
            term="research",
            expected_action_distribution={"read": 1.0},
            expected_target_distribution={"data": 1.0},
        )
        obs.set_anchors("agent-1", [anchor])
        obs.observe("agent-1", _action("read", "/data", {"instruction_context": "research stuff"}))

        obs.reset("agent-1")
        self.assertIsNone(obs.get_map("agent-1"))
        self.assertEqual(obs.get_anchors("agent-1"), [])

    def test_end_to_end_drift_detection(self) -> None:
        obs = SemanticObserver()
        anchor = SemanticAnchor(
            term="research",
            expected_action_distribution={"read": 0.9, "query": 0.1},
            expected_target_distribution={"search_api": 1.0},
        )
        obs.set_anchors("agent-1", [anchor])

        # First 50: match the anchor (reads)
        for _ in range(50):
            action = _action("read", "/search_api", {"instruction_context": "research flights"})
            obs.observe("agent-1", action)

        # Next 50: drift away (writes instead of reads)
        for _ in range(50):
            action = _action("write", "/booking_api", {"instruction_context": "research flights"})
            obs.observe("agent-1", action)

        score = obs.get_semantic_drift("agent-1")
        self.assertIsNotNone(score)
        self.assertGreater(score.overall, 0.2)


# ── DriftScore semantic field Tests ─────────────────────────────────────


class TestDriftScoreSemanticField(TestCase):
    def test_drift_score_has_semantic_field(self) -> None:
        ds = DriftScore(
            overall=0.1, action_drift=0.1, target_drift=0.1,
            temporal_drift=0.1, outcome_drift=0.1, semantic_drift=0.2,
            confidence=0.8, window_size=100, baseline_size=500,
        )
        self.assertAlmostEqual(ds.semantic_drift, 0.2)

    def test_drift_score_to_dict_includes_semantic(self) -> None:
        ds = DriftScore(
            overall=0.1, action_drift=0.1, target_drift=0.1,
            temporal_drift=0.1, outcome_drift=0.1, semantic_drift=0.3,
            confidence=0.8, window_size=100, baseline_size=500,
        )
        d = ds.to_dict()
        self.assertIn("semantic_drift", d)
        self.assertAlmostEqual(d["semantic_drift"], 0.3)

    def test_drift_score_default_semantic_zero(self) -> None:
        ds = DriftScore(
            overall=0.1, action_drift=0.1, target_drift=0.1,
            temporal_drift=0.1, outcome_drift=0.1,
            confidence=0.8, window_size=100, baseline_size=500,
        )
        self.assertAlmostEqual(ds.semantic_drift, 0.0)


# ── DriftCalculator semantic integration Tests ──────────────────────────


class TestDriftCalculatorSemantic(TestCase):
    def setUp(self) -> None:
        self.calc = DriftCalculator()

    def _make_fp(self, agent_id: str, actions: list[tuple[str, str]]) -> BehavioralFingerprint:
        fp = BehavioralFingerprint(agent_id=agent_id)
        for action_type, target in actions:
            action = Action(
                agent_id=agent_id, action_type=action_type,
                target=target, timestamp=time.time(),
            )
            fp.observe(action, Verdict.ALLOW)
        return fp

    def test_compare_without_semantic(self) -> None:
        actions = [("read", "/data")] * 50
        fp1 = self._make_fp("a", actions)
        fp2 = self._make_fp("a", actions)
        score = self.calc.compare(fp1, fp2)
        self.assertAlmostEqual(score.semantic_drift, 0.0)
        self.assertAlmostEqual(score.overall, 0.0, places=2)

    def test_compare_with_semantic(self) -> None:
        actions = [("read", "/data")] * 50
        fp1 = self._make_fp("a", actions)
        fp2 = self._make_fp("a", actions)
        score = self.calc.compare(fp1, fp2, semantic_drift_score=0.3)
        self.assertAlmostEqual(score.semantic_drift, 0.3)
        # Overall should now include the semantic drift component
        self.assertGreater(score.overall, 0.0)

    def test_compare_semantic_weight(self) -> None:
        actions = [("read", "/data")] * 50
        fp1 = self._make_fp("a", actions)
        fp2 = self._make_fp("a", actions)
        # With double-weighted semantic
        score = self.calc.compare(
            fp1, fp2,
            drift_weights={
                "action": 1.0, "target": 1.0, "temporal": 1.0,
                "outcome": 1.0, "semantic": 2.0,
            },
            semantic_drift_score=0.5,
        )
        # Semantic should be double-weighted
        # All structural drifts are ~0. Overall = (0+0+0+0+2*0.5)/(1+1+1+1+2) = 1.0/6 ≈ 0.167
        self.assertGreater(score.overall, 0.1)
        self.assertAlmostEqual(score.semantic_drift, 0.5)

    def test_backward_compat_no_semantic(self) -> None:
        """Existing tests must still pass — semantic defaults to 0."""
        baseline = self._make_fp("a", [("read", "/data")] * 50)
        recent = self._make_fp("a", [("delete", "/data")] * 50)
        score = self.calc.compare(baseline, recent)
        # semantic_drift should default to 0
        self.assertAlmostEqual(score.semantic_drift, 0.0)
        # action_drift should still be high
        self.assertGreater(score.action_drift, 0.5)
        self.assertGreater(score.overall, 0.0)


# ── ArchetypePrior semantic drift weight Tests ──────────────────────────


class TestArchetypePriorSemantic(TestCase):
    def test_default_drift_weights_include_semantic(self) -> None:
        registry = PriorRegistry.with_defaults()
        for name, prior in registry.priors.items():
            self.assertIn("semantic", prior.drift_weights,
                          f"Prior '{name}' missing 'semantic' in drift_weights")

    def test_financial_analyst_high_semantic_weight(self) -> None:
        registry = PriorRegistry.with_defaults()
        prior = registry.get("financial-analyst")
        self.assertIsNotNone(prior)
        self.assertAlmostEqual(prior.drift_weights["semantic"], 1.5)

    def test_security_monitor_elevated_semantic_weight(self) -> None:
        registry = PriorRegistry.with_defaults()
        prior = registry.get("security-monitor")
        self.assertIsNotNone(prior)
        self.assertAlmostEqual(prior.drift_weights["semantic"], 1.3)
