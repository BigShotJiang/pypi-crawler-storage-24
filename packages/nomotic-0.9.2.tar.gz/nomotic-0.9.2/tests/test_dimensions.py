"""Tests for the 20 governance dimensions."""

import time

from nomotic.types import (
    Action,
    ActionRecord,
    AgentContext,
    BlastRadius,
    DataSensitivity,
    Environment,
    GovernanceVerdict,
    ReversibilityDeclaration,
    TrustProfile,
    Verdict,
)
from nomotic.dimension_types import AuthorityGroup, AuthorityRule, ScopeDefinition
from nomotic.types import (
    DimensionResult,
    DimensionScore,
    EvaluatedRule,
)
from nomotic.dimensions import (
    AuthorityVerification,
    BehavioralConsistency,
    BlackoutDate,
    CORE_DIMENSION_NAMES,
    CascadingImpact,
    CascadingImpactConfig,
    ConsistencyConfig,
    DimensionRegistry,
    EthicalAlignment,
    EthicalRule,
    HoldRecord,
    HumanOverride,
    IncidentDetection,
    IsolationIntegrity,
    OverrideThresholdConfig,
    PrecedentAlignment,
    PrecedentConfig,
    ResourceBoundaries,
    ResourceLimit,
    ResourceLimits,
    ScopeCompliance,
    SharedResourcePool,
    StakeholderImpact,
    StakeholderImpactConfig,
    TemporalCompliance,
    TemporalConfig,
    Transparency,
)


def _ctx(agent_id: str = "agent-1", trust: float = 0.5, history=None) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
        action_history=history or [],
    )


def _action(action_type: str = "read", target: str = "db", **params) -> Action:
    return Action(agent_id="agent-1", action_type=action_type, target=target, parameters=params)


# --- Scope Compliance ---


class TestScopeCompliance:
    def test_in_scope_allows(self):
        dim = ScopeCompliance()
        dim.configure_agent_scope("agent-1", {"read", "write"})
        score = dim.evaluate(_action("read"), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_out_of_scope_vetoes(self):
        dim = ScopeCompliance()
        dim.configure_agent_scope("agent-1", {"read"})
        score = dim.evaluate(_action("delete"), _ctx())
        assert score.score == 0.0
        assert score.veto

    def test_wildcard_allows_all(self):
        dim = ScopeCompliance()
        dim.configure_agent_scope("agent-1", {"*"})
        score = dim.evaluate(_action("anything"), _ctx())
        assert score.score == 1.0

    def test_no_scope_defined_caution(self):
        dim = ScopeCompliance()
        score = dim.evaluate(_action("read"), _ctx())
        assert score.score == 0.5

    # --- Structured scope evaluation ---

    def test_wildcard_scope_flags_metadata_and_reduces_confidence(self):
        """Wildcard scope sets wildcard_scope_active and confidence=0.7."""
        dim = ScopeCompliance()
        dim.configure_scope_definitions("agent-1", [
            ScopeDefinition(action_type="*"),
        ])
        score = dim.evaluate(_action("anything"), _ctx())
        assert score.score == 1.0
        assert score.confidence == 0.7
        assert score.metadata.get("wildcard_scope_active") is True
        assert score.result is not None
        assert score.result.confidence == 0.7

    def test_specific_scope_full_confidence(self):
        dim = ScopeCompliance()
        dim.configure_scope_definitions("agent-1", [
            ScopeDefinition(action_type="read", target_pattern="logs/*"),
        ])
        score = dim.evaluate(
            Action(agent_id="agent-1", action_type="read", target="logs/app"),
            _ctx(),
        )
        assert score.score == 1.0
        assert score.confidence == 1.0
        assert not score.metadata.get("wildcard_scope_active", False)

    def test_target_pattern_mismatch_vetoes(self):
        """read on logs/* does NOT grant read on pii/*."""
        dim = ScopeCompliance()
        dim.configure_scope_definitions("agent-1", [
            ScopeDefinition(action_type="read", target_pattern="logs/*"),
        ])
        score = dim.evaluate(
            Action(agent_id="agent-1", action_type="read", target="pii/users"),
            _ctx(),
        )
        assert score.score == 0.0
        assert score.veto

    def test_combination_scope_evaluation(self):
        """Multiple scopes: read on logs/* and write on cache/* — read on cache/* denied."""
        dim = ScopeCompliance()
        dim.configure_scope_definitions("agent-1", [
            ScopeDefinition(action_type="read", target_pattern="logs/*"),
            ScopeDefinition(action_type="write", target_pattern="cache/*"),
        ])
        # read on cache/* should fail
        score = dim.evaluate(
            Action(agent_id="agent-1", action_type="read", target="cache/data"),
            _ctx(),
        )
        assert score.veto
        # write on cache/* should pass
        score2 = dim.evaluate(
            Action(agent_id="agent-1", action_type="write", target="cache/data"),
            _ctx(),
        )
        assert score2.score == 1.0
        assert not score2.veto

    def test_environment_scope_restriction(self):
        """Scope limited to PRODUCTION does not apply in DEVELOPMENT."""
        dim = ScopeCompliance()
        dim.configure_scope_definitions("agent-1", [
            ScopeDefinition(
                action_type="deploy",
                target_pattern="*",
                environment=Environment.PRODUCTION,
            ),
        ])
        # PRODUCTION matches
        score = dim.evaluate(
            Action(agent_id="agent-1", action_type="deploy", target="app",
                   environment=Environment.PRODUCTION),
            _ctx(),
        )
        assert score.score == 1.0
        # DEVELOPMENT does not
        score2 = dim.evaluate(
            Action(agent_id="agent-1", action_type="deploy", target="app",
                   environment=Environment.DEVELOPMENT),
            _ctx(),
        )
        assert score2.veto

    def test_structured_result_has_rules_evaluated(self):
        dim = ScopeCompliance()
        dim.configure_scope_definitions("agent-1", [
            ScopeDefinition(action_type="read", target_pattern="logs/*"),
            ScopeDefinition(action_type="write", target_pattern="cache/*"),
        ])
        score = dim.evaluate(
            Action(agent_id="agent-1", action_type="read", target="logs/app"),
            _ctx(),
        )
        assert score.result is not None
        assert len(score.result.rules_evaluated) == 2


# --- Authority Verification ---


class TestAuthorityVerification:
    def test_no_checks_default_uncertainty(self):
        """No authority configured → score 0.5 (unknown, not 0.7)."""
        dim = AuthorityVerification()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.5

    def test_passing_check(self):
        dim = AuthorityVerification()
        dim.add_authority_check(lambda a, c: True)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    def test_failing_check_vetoes(self):
        dim = AuthorityVerification()
        dim.add_authority_check(lambda a, c: False)
        score = dim.evaluate(_action(), _ctx())
        assert score.veto

    # --- Declarative AuthorityRule tests ---

    def test_authority_rule_passes(self):
        dim = AuthorityVerification()
        dim.add_rule(AuthorityRule(
            rule_id="tier-check",
            description="Agent tier must be >= 1",
            condition="agent_tier >= 1",
        ))
        ctx = _ctx()
        ctx.metadata["agent_tier"] = 2
        score = dim.evaluate(_action(), ctx)
        assert score.score == 1.0
        assert score.result is not None
        assert any(r.outcome == "pass" for r in score.result.rules_evaluated)

    def test_authority_rule_fails_vetoes(self):
        dim = AuthorityVerification()
        dim.add_rule(AuthorityRule(
            rule_id="tier-check",
            description="Agent tier must be >= 3",
            condition="agent_tier >= 3",
        ))
        ctx = _ctx()
        ctx.metadata["agent_tier"] = 1
        score = dim.evaluate(_action(), ctx)
        assert score.score == 0.0
        assert score.veto

    def test_time_bounded_authority_expired(self):
        """Expired rules are treated as failed."""
        dim = AuthorityVerification()
        dim.add_rule(AuthorityRule(
            rule_id="temp-access",
            description="Temporary access grant",
            condition="True",
            expires_at=time.time() - 100,  # already expired
        ))
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.0
        assert score.veto
        assert score.result is not None
        assert any(r.outcome == "expired" for r in score.result.rules_evaluated)

    def test_time_bounded_authority_active(self):
        """Non-expired rules evaluate normally."""
        dim = AuthorityVerification()
        dim.add_rule(AuthorityRule(
            rule_id="temp-access",
            description="Temporary access grant",
            condition="True",
            expires_at=time.time() + 3600,  # 1 hour in future
        ))
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    def test_or_logic_authority_group(self):
        """OR group passes if at least one rule passes."""
        dim = AuthorityVerification()
        group = AuthorityGroup(
            rules=[
                AuthorityRule(
                    rule_id="admin-check",
                    description="Is admin",
                    condition="agent_tier >= 10",
                ),
                AuthorityRule(
                    rule_id="owner-check",
                    description="Is owner",
                    condition="agent_id == 'agent-1'",
                ),
            ],
            logic="OR",
        )
        dim.add_group(group)
        ctx = _ctx()
        ctx.metadata["agent_tier"] = 0  # not admin, but agent-1 matches
        score = dim.evaluate(_action(), ctx)
        assert score.score == 1.0

    def test_or_logic_all_fail_vetoes(self):
        """OR group vetoes if all rules fail."""
        dim = AuthorityVerification()
        group = AuthorityGroup(
            rules=[
                AuthorityRule(
                    rule_id="admin-check",
                    description="Is admin",
                    condition="agent_tier >= 10",
                ),
                AuthorityRule(
                    rule_id="owner-check",
                    description="Is owner",
                    condition="agent_id == 'special-agent'",
                ),
            ],
            logic="OR",
        )
        dim.add_group(group)
        ctx = _ctx()
        ctx.metadata["agent_tier"] = 0
        score = dim.evaluate(_action(), ctx)
        assert score.score == 0.0
        assert score.veto

    def test_and_logic_authority_group(self):
        """AND group requires all rules to pass."""
        dim = AuthorityVerification()
        group = AuthorityGroup(
            rules=[
                AuthorityRule(
                    rule_id="tier-check",
                    description="Tier >= 1",
                    condition="agent_tier >= 1",
                ),
                AuthorityRule(
                    rule_id="trust-check",
                    description="Trust >= 0.3",
                    condition="trust >= 0.3",
                ),
            ],
            logic="AND",
        )
        dim.add_group(group)
        ctx = _ctx(trust=0.5)
        ctx.metadata["agent_tier"] = 2
        score = dim.evaluate(_action(), ctx)
        assert score.score == 1.0

    def test_structured_result_from_authority(self):
        """AuthorityVerification produces structured DimensionResult."""
        dim = AuthorityVerification()
        dim.add_rule(AuthorityRule(
            rule_id="basic",
            description="Always allow",
            condition="True",
        ))
        score = dim.evaluate(_action(), _ctx())
        assert score.result is not None
        assert score.result.dimension_name == "authority_verification"
        assert len(score.result.rules_evaluated) == 1


# --- Resource Boundaries ---


class TestResourceBoundaries:
    def test_within_limits(self):
        dim = ResourceBoundaries(limits=ResourceLimits(max_actions_per_minute=100))
        score = dim.evaluate(_action(), _ctx())
        assert score.score > 0.5
        assert not score.veto

    def test_cost_exceeded_vetoes(self):
        dim = ResourceBoundaries(limits=ResourceLimits(max_cost_per_action=10.0))
        score = dim.evaluate(_action(cost=50.0), _ctx())
        assert score.veto

    def test_produces_structured_result(self):
        dim = ResourceBoundaries(limits=ResourceLimits(max_actions_per_minute=100))
        score = dim.evaluate(_action(), _ctx())
        assert score.result is not None
        assert score.result.dimension_name == "resource_boundaries"

    # --- Per-resource-type limits ---

    def test_per_resource_limit_allows_within(self):
        rl = ResourceLimit(resource_type="api_call", max_per_minute=5)
        dim = ResourceBoundaries(resource_limits=[rl])
        score = dim.evaluate(_action(resource_type="api_call"), _ctx())
        assert score.score > 0.5
        assert not score.veto

    def test_per_resource_limit_vetoes_when_exceeded(self):
        rl = ResourceLimit(resource_type="api_call", max_per_minute=3)
        dim = ResourceBoundaries(resource_limits=[rl])
        # Record enough to exceed
        for _ in range(3):
            dim._record_resource("api_call", time.time())
        score = dim.evaluate(_action(resource_type="api_call"), _ctx())
        assert score.veto
        assert "api_call" in score.reasoning

    def test_different_resource_types_independent(self):
        rl_api = ResourceLimit(resource_type="api_call", max_per_minute=2)
        rl_db = ResourceLimit(resource_type="db_query", max_per_minute=10)
        dim = ResourceBoundaries(resource_limits=[rl_api, rl_db])
        # Exhaust api_call
        for _ in range(2):
            dim._record_resource("api_call", time.time())
        # db_query should still be fine
        score = dim.evaluate(_action(resource_type="db_query"), _ctx())
        assert not score.veto

    # --- Burst allowance ---

    def test_burst_allowed_within_window(self):
        rl = ResourceLimit(resource_type="api_call", max_per_minute=100, max_burst=50, burst_window_seconds=10)
        dim = ResourceBoundaries(resource_limits=[rl])
        now = time.time()
        # 40 requests in last 10s — under burst limit of 50
        for i in range(40):
            dim._record_resource("api_call", now - 5)
        score = dim.evaluate(_action(resource_type="api_call"), _ctx())
        assert not score.veto

    def test_burst_vetoes_when_exceeded(self):
        rl = ResourceLimit(resource_type="api_call", max_per_minute=100, max_burst=10, burst_window_seconds=10)
        dim = ResourceBoundaries(resource_limits=[rl])
        now = time.time()
        for _ in range(10):
            dim._record_resource("api_call", now - 1)
        score = dim.evaluate(_action(resource_type="api_call"), _ctx())
        assert score.veto
        assert "burst" in score.reasoning.lower()

    def test_burst_ok_when_outside_window(self):
        """Burst from >10s ago doesn't count against current burst window."""
        rl = ResourceLimit(resource_type="api_call", max_per_minute=100, max_burst=10, burst_window_seconds=10)
        dim = ResourceBoundaries(resource_limits=[rl])
        now = time.time()
        # All timestamps older than burst window
        for _ in range(10):
            dim._record_resource("api_call", now - 30)
        score = dim.evaluate(_action(resource_type="api_call"), _ctx())
        assert not score.veto

    # --- Shared resource pool ---

    def test_shared_pool_tracks_cross_agent(self):
        pool = SharedResourcePool(
            pool_id="shared_api",
            max_per_minute=5,
            member_agents=["agent-1", "agent-2"],
        )
        dim = ResourceBoundaries(pools=[pool])
        now = time.time()
        # agent-2 uses 5 requests
        for _ in range(5):
            pool.record("agent-2", now)
        # agent-1 should now be blocked by the pool
        score = dim.evaluate(_action(), _ctx("agent-1"))
        assert score.veto
        assert "shared_api" in score.reasoning

    def test_shared_pool_allows_within_limit(self):
        pool = SharedResourcePool(
            pool_id="shared_api",
            max_per_minute=10,
            member_agents=["agent-1", "agent-2"],
        )
        dim = ResourceBoundaries(pools=[pool])
        now = time.time()
        pool.record("agent-2", now)
        score = dim.evaluate(_action(), _ctx("agent-1"))
        assert not score.veto

    def test_non_member_agent_not_affected_by_pool(self):
        pool = SharedResourcePool(
            pool_id="shared_api",
            max_per_minute=2,
            member_agents=["agent-1"],
        )
        dim = ResourceBoundaries(pools=[pool])
        now = time.time()
        for _ in range(5):
            pool.record("agent-1", now)
        # agent-3 is not a member, should be unaffected
        score = dim.evaluate(_action(), _ctx("agent-3"))
        assert not score.veto


# --- Behavioral Consistency ---


class TestBehavioralConsistency:
    def test_first_action_establishes_baseline(self):
        dim = BehavioralConsistency()
        score = dim.evaluate(_action("read"), _ctx())
        assert score.score == 0.7
        assert score.result is not None
        assert score.result.primary_signal == "first_action_baseline"

    def test_consistent_action_high_score(self):
        dim = BehavioralConsistency()
        ctx = _ctx()
        dim.evaluate(_action("read"), ctx)
        score = dim.evaluate(_action("read"), ctx)
        assert score.score == 1.0

    def test_novel_action_lower_score(self):
        dim = BehavioralConsistency()
        ctx = _ctx()
        dim.evaluate(_action("read"), ctx)
        score = dim.evaluate(_action("delete"), ctx)
        assert score.score == 0.5

    def test_produces_dimension_result(self):
        dim = BehavioralConsistency()
        ctx = _ctx()
        dim.evaluate(_action("read"), ctx)
        score = dim.evaluate(_action("read"), ctx)
        assert score.result is not None
        assert score.result.dimension_name == "behavioral_consistency"
        assert "action_type" in score.result.schema_fields_used

    def test_environment_aware_novel_in_production(self):
        """Action known globally but novel in PRODUCTION scores lower."""
        dim = BehavioralConsistency()
        ctx = _ctx()
        # Establish in DEVELOPMENT
        dim.evaluate(
            Action(agent_id="agent-1", action_type="deploy", environment=Environment.DEVELOPMENT),
            ctx,
        )
        # Same action in PRODUCTION — novel in that environment
        score = dim.evaluate(
            Action(agent_id="agent-1", action_type="deploy", environment=Environment.PRODUCTION),
            ctx,
        )
        # Should be penalized by environment_weight (default 0.3)
        assert score.score < 1.0
        assert "novel in PRODUCTION" in score.reasoning

    def test_environment_aware_known_in_same_env(self):
        """Action known in the same environment scores normally."""
        dim = BehavioralConsistency()
        ctx = _ctx()
        dim.evaluate(
            Action(agent_id="agent-1", action_type="read", environment=Environment.PRODUCTION),
            ctx,
        )
        score = dim.evaluate(
            Action(agent_id="agent-1", action_type="read", environment=Environment.PRODUCTION),
            ctx,
        )
        assert score.score == 1.0

    def test_configurable_drift_coefficient(self):
        """Custom drift_coefficient changes drift modulation."""
        cfg = ConsistencyConfig(drift_coefficient=0.8, min_score_floor=0.1)
        dim = BehavioralConsistency(config=cfg)

        class _Drift:
            overall = 0.5
            confidence = 0.9
            detail = "test"

        dim.set_drift_accessor(lambda _: _Drift())
        ctx = _ctx()
        dim.evaluate(_action("read"), ctx)
        score = dim.evaluate(_action("read"), ctx)
        # drift_factor = 1.0 - (0.5 * 0.8) = 0.6; base_score 1.0 * 0.6 = 0.6
        assert abs(score.score - 0.6) < 0.01

    def test_configurable_min_score_floor(self):
        """min_score_floor prevents drift from pushing score too low."""
        cfg = ConsistencyConfig(drift_coefficient=0.6, min_score_floor=0.5)
        dim = BehavioralConsistency(config=cfg)

        class _Drift:
            overall = 0.9
            confidence = 0.9
            detail = "extreme"

        dim.set_drift_accessor(lambda _: _Drift())
        ctx = _ctx()
        dim.evaluate(_action("read"), ctx)
        score = dim.evaluate(_action("read"), ctx)
        # drift_factor = max(1.0 - 0.9*0.6, 0.5) = max(0.46, 0.5) = 0.5
        assert score.score >= 0.5

    def test_veto_critical_drift_novel_production(self):
        """Veto triggers when drift is critical, action is novel, and env is PRODUCTION."""
        cfg = ConsistencyConfig(veto_on_critical_production_novelty=True)
        dim = BehavioralConsistency(config=cfg)
        assert dim.can_veto is True

        class _Drift:
            overall = 0.5
            confidence = 0.9
            detail = "critical drift"

        dim.set_drift_accessor(lambda _: _Drift())
        ctx = _ctx()
        dim.evaluate(_action("read"), ctx)
        score = dim.evaluate(
            Action(agent_id="agent-1", action_type="dangerous_op", environment=Environment.PRODUCTION),
            ctx,
        )
        assert score.veto is True
        assert "VETO" in score.reasoning

    def test_veto_disabled_by_default(self):
        """Veto does not trigger with default config."""
        dim = BehavioralConsistency()

        class _Drift:
            overall = 0.5
            confidence = 0.9
            detail = "critical"

        dim.set_drift_accessor(lambda _: _Drift())
        ctx = _ctx()
        dim.evaluate(_action("read"), ctx)
        score = dim.evaluate(
            Action(agent_id="agent-1", action_type="new_op", environment=Environment.PRODUCTION),
            ctx,
        )
        assert score.veto is False

    def test_schema_mode_composite_key(self):
        """schema_mode uses structured fields for fingerprint matching."""
        cfg = ConsistencyConfig(schema_mode=True)
        dim = BehavioralConsistency(config=cfg)
        ctx = _ctx()

        # First action with specific schema fields
        dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="write",
                blast_radius=BlastRadius.SINGLE_RECORD,
                reversibility=ReversibilityDeclaration.REVERSIBLE,
            ),
            ctx,
        )
        # Same action_type but different schema fields → novel
        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="write",
                blast_radius=BlastRadius.SYSTEM_WIDE,
                reversibility=ReversibilityDeclaration.IRREVERSIBLE,
            ),
            ctx,
        )
        assert score.score == 0.5  # novel composite key

    def test_schema_mode_same_key_consistent(self):
        """schema_mode recognizes identical composite keys as consistent."""
        cfg = ConsistencyConfig(schema_mode=True)
        dim = BehavioralConsistency(config=cfg)
        ctx = _ctx()

        action = Action(
            agent_id="agent-1",
            action_type="write",
            blast_radius=BlastRadius.SINGLE_RECORD,
            reversibility=ReversibilityDeclaration.REVERSIBLE,
        )
        dim.evaluate(action, ctx)
        score = dim.evaluate(action, ctx)
        assert score.score == 1.0

    def test_schema_mode_false_uses_action_type_only(self):
        """When schema_mode is False, only action_type matters."""
        dim = BehavioralConsistency()
        ctx = _ctx()

        dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="write",
                blast_radius=BlastRadius.SINGLE_RECORD,
            ),
            ctx,
        )
        # Same action_type, different blast_radius → still consistent
        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="write",
                blast_radius=BlastRadius.SYSTEM_WIDE,
            ),
            ctx,
        )
        assert score.score == 1.0


# --- Cascading Impact ---


class TestCascadingImpact:
    def test_schema_absent_neutral(self):
        """Missing schema fields return neutral 0.5 with warning."""
        dim = CascadingImpact()
        score = dim.evaluate(_action("anything"), _ctx())
        assert score.score == 0.5
        assert score.confidence == 0.5
        assert score.result is not None
        assert score.result.primary_signal == "schema_fields_absent"

    def test_irreversible_system_wide(self):
        dim = CascadingImpact()
        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="delete",
                reversibility=ReversibilityDeclaration.IRREVERSIBLE,
                blast_radius=BlastRadius.SYSTEM_WIDE,
            ),
            _ctx(),
        )
        assert score.score == 0.05

    def test_irreversible_subset(self):
        dim = CascadingImpact()
        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="delete",
                reversibility=ReversibilityDeclaration.IRREVERSIBLE,
                blast_radius=BlastRadius.SUBSET,
            ),
            _ctx(),
        )
        assert score.score == 0.15

    def test_irreversible_single_record(self):
        dim = CascadingImpact()
        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="delete",
                reversibility=ReversibilityDeclaration.IRREVERSIBLE,
                blast_radius=BlastRadius.SINGLE_RECORD,
            ),
            _ctx(),
        )
        assert score.score == 0.4

    def test_reversible_single_record(self):
        dim = CascadingImpact()
        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="read",
                reversibility=ReversibilityDeclaration.REVERSIBLE,
                blast_radius=BlastRadius.SINGLE_RECORD,
            ),
            _ctx(),
        )
        assert score.score == 0.95

    def test_reversible_system_wide(self):
        dim = CascadingImpact()
        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="update",
                reversibility=ReversibilityDeclaration.REVERSIBLE,
                blast_radius=BlastRadius.SYSTEM_WIDE,
            ),
            _ctx(),
        )
        assert score.score == 0.6

    def test_append_only_subset(self):
        dim = CascadingImpact()
        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="log",
                reversibility=ReversibilityDeclaration.APPEND_ONLY,
                blast_radius=BlastRadius.SUBSET,
            ),
            _ctx(),
        )
        assert score.score == 0.5

    def test_downstream_dependency_reduces_score(self):
        """Each downstream dependency reduces score by 0.05, capped at 0.25."""
        dim = CascadingImpact()
        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="update",
                reversibility=ReversibilityDeclaration.REVERSIBLE,
                blast_radius=BlastRadius.SUBSET,
                downstream_dependencies=3,
            ),
            _ctx(),
        )
        # base 0.8 - 3*0.05 = 0.65
        assert abs(score.score - 0.65) < 0.001

    def test_downstream_dependency_capped(self):
        """Downstream penalty capped at 0.25 total."""
        dim = CascadingImpact()
        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="update",
                reversibility=ReversibilityDeclaration.REVERSIBLE,
                blast_radius=BlastRadius.SUBSET,
                downstream_dependencies=10,  # 10 * 0.05 = 0.5, capped at 0.25
            ),
            _ctx(),
        )
        # base 0.8 - 0.25 = 0.55
        assert abs(score.score - 0.55) < 0.001

    def test_conditional_veto_production_pii(self):
        """Veto on IRREVERSIBLE × SYSTEM_WIDE × PII × PRODUCTION."""
        cfg = CascadingImpactConfig(veto_irreversible_system_wide=True)
        dim = CascadingImpact(config=cfg)
        assert dim.can_veto is True

        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="purge",
                reversibility=ReversibilityDeclaration.IRREVERSIBLE,
                blast_radius=BlastRadius.SYSTEM_WIDE,
                data_sensitivity=DataSensitivity.PII,
                environment=Environment.PRODUCTION,
            ),
            _ctx(),
        )
        assert score.veto is True
        assert "VETO" in score.reasoning

    def test_conditional_veto_phi(self):
        """Veto also triggers for PHI data."""
        cfg = CascadingImpactConfig(veto_irreversible_system_wide=True)
        dim = CascadingImpact(config=cfg)

        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="purge",
                reversibility=ReversibilityDeclaration.IRREVERSIBLE,
                blast_radius=BlastRadius.SYSTEM_WIDE,
                data_sensitivity=DataSensitivity.PHI,
                environment=Environment.PRODUCTION,
            ),
            _ctx(),
        )
        assert score.veto is True

    def test_conditional_veto_financial(self):
        """Veto also triggers for FINANCIAL data."""
        cfg = CascadingImpactConfig(veto_irreversible_system_wide=True)
        dim = CascadingImpact(config=cfg)

        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="purge",
                reversibility=ReversibilityDeclaration.IRREVERSIBLE,
                blast_radius=BlastRadius.SYSTEM_WIDE,
                data_sensitivity=DataSensitivity.FINANCIAL,
                environment=Environment.PRODUCTION,
            ),
            _ctx(),
        )
        assert score.veto is True

    def test_no_veto_when_disabled(self):
        """Default config does not veto."""
        dim = CascadingImpact()
        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="purge",
                reversibility=ReversibilityDeclaration.IRREVERSIBLE,
                blast_radius=BlastRadius.SYSTEM_WIDE,
                data_sensitivity=DataSensitivity.PII,
                environment=Environment.PRODUCTION,
            ),
            _ctx(),
        )
        assert score.veto is False

    def test_no_veto_non_production(self):
        """Veto does not trigger outside PRODUCTION even when enabled."""
        cfg = CascadingImpactConfig(veto_irreversible_system_wide=True)
        dim = CascadingImpact(config=cfg)

        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="purge",
                reversibility=ReversibilityDeclaration.IRREVERSIBLE,
                blast_radius=BlastRadius.SYSTEM_WIDE,
                data_sensitivity=DataSensitivity.PII,
                environment=Environment.STAGING,
            ),
            _ctx(),
        )
        assert score.veto is False

    def test_no_veto_non_sensitive(self):
        """Veto does not trigger for non-sensitive data."""
        cfg = CascadingImpactConfig(veto_irreversible_system_wide=True)
        dim = CascadingImpact(config=cfg)

        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="purge",
                reversibility=ReversibilityDeclaration.IRREVERSIBLE,
                blast_radius=BlastRadius.SYSTEM_WIDE,
                data_sensitivity=DataSensitivity.PUBLIC,
                environment=Environment.PRODUCTION,
            ),
            _ctx(),
        )
        assert score.veto is False

    def test_matrix_override(self):
        """Config can override matrix scores."""
        cfg = CascadingImpactConfig(
            matrix_overrides={("reversible", "system_wide"): 0.9},
        )
        dim = CascadingImpact(config=cfg)

        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="update",
                reversibility=ReversibilityDeclaration.REVERSIBLE,
                blast_radius=BlastRadius.SYSTEM_WIDE,
            ),
            _ctx(),
        )
        assert score.score == 0.9

    def test_custom_dependency_penalty(self):
        """Config can override dependency penalty."""
        cfg = CascadingImpactConfig(
            dependency_penalty_per=0.1,
            dependency_penalty_cap=0.3,
        )
        dim = CascadingImpact(config=cfg)

        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="update",
                reversibility=ReversibilityDeclaration.REVERSIBLE,
                blast_radius=BlastRadius.SUBSET,
                downstream_dependencies=2,
            ),
            _ctx(),
        )
        # base 0.8 - 2*0.1 = 0.6
        assert abs(score.score - 0.6) < 0.001

    def test_produces_dimension_result(self):
        """Structured DimensionResult is always produced."""
        dim = CascadingImpact()
        score = dim.evaluate(
            Action(
                agent_id="agent-1",
                action_type="read",
                reversibility=ReversibilityDeclaration.REVERSIBLE,
                blast_radius=BlastRadius.SINGLE_RECORD,
            ),
            _ctx(),
        )
        assert score.result is not None
        assert score.result.dimension_name == "cascading_impact"
        assert score.result.primary_signal == "cascading_matrix"
        assert "reversibility" in score.result.schema_fields_used
        assert "blast_radius" in score.result.schema_fields_used
        assert len(score.result.rules_evaluated) >= 1


# --- Stakeholder Impact ---


class TestStakeholderImpact:
    def test_no_schema_fields_scores_1(self):
        """No schema fields declared → score 1.0, context_missing populated."""
        dim = StakeholderImpact()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert score.result is not None
        assert "data_sensitivity" in score.result.context_missing
        assert "blast_radius" in score.result.context_missing

    def test_data_sensitivity_penalty(self):
        """Higher data sensitivity → lower score."""
        dim = StakeholderImpact()
        action = Action(agent_id="agent-1", action_type="read", target="db",
                        data_sensitivity=DataSensitivity.PII)
        score = dim.evaluate(action, _ctx())
        # PII = order 3 → penalty 0.3
        assert score.score == 0.7
        assert score.result is not None
        assert "data_sensitivity" in score.result.schema_fields_used

    def test_classified_data_max_sensitivity_penalty(self):
        dim = StakeholderImpact()
        action = Action(agent_id="agent-1", action_type="read", target="db",
                        data_sensitivity=DataSensitivity.CLASSIFIED)
        score = dim.evaluate(action, _ctx())
        # CLASSIFIED = order 6 → penalty 0.6
        assert abs(score.score - 0.4) < 0.01

    def test_blast_radius_system_wide(self):
        dim = StakeholderImpact()
        action = Action(agent_id="agent-1", action_type="write", target="db",
                        blast_radius=BlastRadius.SYSTEM_WIDE)
        score = dim.evaluate(action, _ctx())
        assert score.score == 0.75  # 1.0 - 0.25

    def test_indirect_stakeholder_reach_linear(self):
        """Large population with linear curve reduces score."""
        dim = StakeholderImpact()
        action = Action(agent_id="agent-1", action_type="notify", target="users",
                        indirect_stakeholder_reach=50_000_000)
        score = dim.evaluate(action, _ctx())
        # penalty = min(50M/100M, 1.0) * 0.3 = 0.5 * 0.3 = 0.15
        assert abs(score.score - 0.85) < 0.01

    def test_indirect_stakeholder_reach_log_curve(self):
        """Log curve compresses large populations."""
        config = StakeholderImpactConfig(population_weight_curve="log")
        dim = StakeholderImpact(config=config)
        action = Action(agent_id="agent-1", action_type="notify", target="users",
                        indirect_stakeholder_reach=1_000_000)
        score = dim.evaluate(action, _ctx())
        # log10(1M) = 6, penalty = 6/8 * 0.3 = 0.225
        assert abs(score.score - 0.775) < 0.01

    def test_downstream_systems_external_facing(self):
        """External-facing downstream systems increase penalty."""
        dim = StakeholderImpact()
        action = Action(agent_id="agent-1", action_type="write", target="db",
                        downstream_systems=("ext-api", "ext-notifications", "cache"))
        score = dim.evaluate(action, _ctx())
        # 2 external × 0.08 + 1 internal × 0.03 = 0.19
        assert abs(score.score - 0.81) < 0.01
        assert score.result is not None
        assert "downstream_systems" in score.result.schema_fields_used

    def test_combined_fields_compound_penalty(self):
        """Multiple schema fields compound their penalties."""
        dim = StakeholderImpact()
        action = Action(agent_id="agent-1", action_type="delete", target="records",
                        data_sensitivity=DataSensitivity.PHI,
                        blast_radius=BlastRadius.SYSTEM_WIDE,
                        indirect_stakeholder_reach=100_000_000,
                        downstream_systems=("ext-portal",))
        score = dim.evaluate(action, _ctx())
        # PHI(4*0.1=0.4) + SYSTEM_WIDE(0.25) + pop(1.0*0.3=0.3) + ext(0.08) = 1.03 → clamped to 0.0
        assert score.score == 0.0

    def test_default_weight_is_1_4(self):
        """Weight defaults to 1.4."""
        dim = StakeholderImpact()
        assert dim.weight == 1.4

    def test_configurable_weight(self):
        config = StakeholderImpactConfig(weight=1.8)
        dim = StakeholderImpact(config=config)
        assert dim.weight == 1.8

    def test_produces_dimension_result(self):
        dim = StakeholderImpact()
        action = Action(agent_id="agent-1", action_type="read", target="db",
                        data_sensitivity=DataSensitivity.INTERNAL)
        score = dim.evaluate(action, _ctx())
        assert score.result is not None
        assert score.result.dimension_name == "stakeholder_impact"
        assert len(score.result.rules_evaluated) > 0


# --- Incident Detection ---


class TestIncidentDetection:
    def test_no_patterns_passes(self):
        dim = IncidentDetection()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    def test_repetitive_pattern_detected(self):
        dim = IncidentDetection()
        history = []
        for _ in range(5):
            history.append(
                ActionRecord(
                    action=_action("spam"),
                    verdict=GovernanceVerdict(action_id="x", verdict=Verdict.ALLOW, ucs=0.8),
                )
            )
        ctx = _ctx(history=history)
        score = dim.evaluate(_action("spam"), ctx)
        assert score.score < 0.5

    def test_custom_pattern(self):
        dim = IncidentDetection()
        dim.add_pattern(lambda a, c: 0.05 if "exploit" in a.action_type else None)
        score = dim.evaluate(_action("exploit_vuln"), _ctx())
        assert score.score <= 0.05
        assert score.veto


# --- Isolation Integrity ---


class TestIsolationIntegrity:
    def test_within_boundary(self):
        dim = IsolationIntegrity()
        dim.set_boundaries("agent-1", {"db_a", "db_b"})
        score = dim.evaluate(_action(target="db_a"), _ctx())
        assert score.score == 1.0

    def test_outside_boundary_vetoes(self):
        dim = IsolationIntegrity()
        dim.set_boundaries("agent-1", {"db_a"})
        score = dim.evaluate(_action(target="db_secret"), _ctx())
        assert score.veto

    def test_no_boundaries_caution(self):
        dim = IsolationIntegrity()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.6

    def test_produces_structured_result(self):
        dim = IsolationIntegrity()
        dim.set_boundaries("agent-1", {"db_a"})
        score = dim.evaluate(_action(target="db_a"), _ctx())
        assert score.result is not None
        assert score.result.dimension_name == "isolation_integrity"
        assert score.result.primary_signal == "within_boundaries"

    # --- Parameter inspection ---

    def test_parameter_value_bypass_detected(self):
        """Parameter value pointing to another agent's boundary triggers a veto."""
        dim = IsolationIntegrity()
        dim.set_boundaries("agent-1", {"db_a"})
        # agent-2 owns db_secret — agent-1 referencing it via a parameter is a bypass
        dim.set_boundaries("agent-2", {"db_secret"})
        score = dim.evaluate(
            _action("read", target="db_a", source="db_secret"),
            _ctx(),
        )
        assert score.veto
        assert "parameter" in score.reasoning

    def test_parameter_within_boundary_ok(self):
        dim = IsolationIntegrity()
        dim.set_boundaries("agent-1", {"db_a", "db_b"})
        dim.set_boundaries("agent-2", {"db_c"})
        score = dim.evaluate(
            _action("read", target="db_a", join_target="db_b"),
            _ctx(),
        )
        assert score.score == 1.0
        assert not score.veto

    # --- Read vs write boundaries ---

    def test_read_allowed_write_denied(self):
        dim = IsolationIntegrity()
        dim.set_rw_boundaries(
            "agent-1",
            read_boundaries={"db_a", "db_b"},
            write_boundaries={"db_a"},
        )
        # Read db_b — allowed
        read_score = dim.evaluate(_action("read", target="db_b"), _ctx())
        assert read_score.score == 1.0
        assert not read_score.veto

        # Write db_b — denied (only db_a is writable)
        write_score = dim.evaluate(_action("write", target="db_b"), _ctx())
        assert write_score.veto

    def test_write_within_write_boundary_ok(self):
        dim = IsolationIntegrity()
        dim.set_rw_boundaries(
            "agent-1",
            read_boundaries={"db_a"},
            write_boundaries={"db_a"},
        )
        score = dim.evaluate(_action("write", target="db_a"), _ctx())
        assert score.score == 1.0

    def test_delete_uses_write_boundary(self):
        dim = IsolationIntegrity()
        dim.set_rw_boundaries(
            "agent-1",
            read_boundaries={"db_a", "db_b"},
            write_boundaries={"db_a"},
        )
        score = dim.evaluate(_action("delete", target="db_b"), _ctx())
        assert score.veto

    # --- Glob pattern boundaries ---

    def test_glob_pattern_matches(self):
        dim = IsolationIntegrity()
        dim.set_boundaries("agent-1", {"customer_*"})
        score = dim.evaluate(_action(target="customer_orders"), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_glob_pattern_rejects_non_match(self):
        dim = IsolationIntegrity()
        dim.set_boundaries("agent-1", {"customer_*"})
        score = dim.evaluate(_action(target="admin_settings"), _ctx())
        assert score.veto

    def test_glob_dot_pattern(self):
        dim = IsolationIntegrity()
        dim.set_boundaries("agent-1", {"prod.*"})
        score = dim.evaluate(_action(target="prod.users"), _ctx())
        assert score.score == 1.0

    def test_glob_pattern_in_rw_boundaries(self):
        dim = IsolationIntegrity()
        dim.set_rw_boundaries(
            "agent-1",
            read_boundaries={"customer_*", "report_*"},
            write_boundaries={"customer_*"},
        )
        # Read report_sales — allowed
        assert not dim.evaluate(_action("read", target="report_sales"), _ctx()).veto
        # Write report_sales — denied
        assert dim.evaluate(_action("write", target="report_sales"), _ctx()).veto
        # Write customer_123 — allowed
        assert not dim.evaluate(_action("write", target="customer_123"), _ctx()).veto


# --- Temporal Compliance ---


class TestTemporalCompliance:
    def test_no_constraints_passes(self):
        dim = TemporalCompliance()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert score.result is not None

    def test_min_interval_violation(self):
        dim = TemporalCompliance()
        dim.set_min_interval("deploy", 3600)
        ctx = _ctx()
        # First call sets the timestamp
        dim.evaluate(_action("deploy"), ctx)
        # Second call within interval should veto
        score = dim.evaluate(_action("deploy"), ctx)
        assert score.veto

    def test_timezone_aware_window_utc(self):
        """Time window with explicit UTC timezone."""
        from datetime import datetime, timezone as _tz
        dim = TemporalCompliance()
        now_utc = datetime.now(_tz.utc)
        # Set a window that includes the current hour
        dim.set_time_window("read", now_utc.hour, (now_utc.hour + 2) % 24, timezone="UTC")
        score = dim.evaluate(_action("read"), _ctx())
        assert score.score == 1.0
        assert score.result is not None
        assert score.result.primary_signal == "temporal_ok"

    def test_timezone_missing_defaults_to_utc(self):
        """Missing timezone logs warning and defaults to UTC."""
        dim = TemporalCompliance()
        dim.set_time_window("read", 0, 23)  # no timezone
        # Should have stored "UTC"
        assert dim._time_windows["read"][2] == "UTC"

    def test_timezone_aware_window_rejects_outside(self):
        """Window in a timezone where current hour is outside rejects."""
        from datetime import datetime, timezone as _tz
        dim = TemporalCompliance()
        now_utc = datetime.now(_tz.utc)
        # Set window to an hour range that excludes current hour
        excluded_start = (now_utc.hour + 3) % 24
        excluded_end = (now_utc.hour + 5) % 24
        dim.set_time_window("deploy", excluded_start, excluded_end, timezone="UTC")
        score = dim.evaluate(_action("deploy"), _ctx())
        assert score.veto
        assert score.result is not None
        assert score.result.primary_signal == "outside_time_window"

    def test_blackout_date_vetoes_action(self):
        """Action attempted on a blackout date is vetoed."""
        from datetime import datetime, timezone as _tz
        today = datetime.now(_tz.utc).strftime("%Y-%m-%d")
        config = TemporalConfig(blackout_dates=[
            BlackoutDate(date=today, reason="Maintenance window", applies_to=["deploy*"]),
        ])
        dim = TemporalCompliance(config=config)
        score = dim.evaluate(_action("deploy"), _ctx())
        assert score.veto
        assert "Maintenance window" in score.reasoning
        assert score.result is not None
        assert score.result.primary_signal == "blackout_date"

    def test_blackout_date_does_not_affect_other_actions(self):
        """Blackout applies_to=deploy* should not block 'read'."""
        from datetime import datetime, timezone as _tz
        today = datetime.now(_tz.utc).strftime("%Y-%m-%d")
        config = TemporalConfig(blackout_dates=[
            BlackoutDate(date=today, reason="Maintenance", applies_to=["deploy*"]),
        ])
        dim = TemporalCompliance(config=config)
        score = dim.evaluate(_action("read"), _ctx())
        assert score.score == 1.0

    def test_blackout_applies_to_all_when_none(self):
        """Blackout with applies_to=None blocks everything."""
        from datetime import datetime, timezone as _tz
        today = datetime.now(_tz.utc).strftime("%Y-%m-%d")
        config = TemporalConfig(blackout_dates=[
            BlackoutDate(date=today, reason="Company holiday"),
        ])
        dim = TemporalCompliance(config=config)
        score = dim.evaluate(_action("read"), _ctx())
        assert score.veto

    def test_incident_hold_blocks_action(self):
        """Active hold prevents agent/action-type combination."""
        dim = TemporalCompliance()
        hold = HoldRecord(
            agent_id="agent-1",
            action_type_pattern="deploy",
            hold_until=time.time() + 3600,
            reason="Post-incident hold",
        )
        dim.register_hold(hold)
        score = dim.evaluate(_action("deploy"), _ctx())
        assert score.veto
        assert "Post-incident hold" in score.reasoning
        assert score.result is not None
        assert score.result.primary_signal == "incident_hold_active"

    def test_incident_hold_expires(self):
        """Expired hold does not block."""
        dim = TemporalCompliance()
        hold = HoldRecord(
            agent_id="agent-1",
            action_type_pattern="deploy",
            hold_until=time.time() - 1,  # already expired
            reason="Old hold",
        )
        dim.register_hold(hold)
        score = dim.evaluate(_action("deploy"), _ctx())
        assert score.score == 1.0

    def test_incident_hold_pattern_matching(self):
        """Hold with wildcard pattern matches multiple action types."""
        dim = TemporalCompliance()
        hold = HoldRecord(
            agent_id="agent-1",
            action_type_pattern="deploy*",
            hold_until=time.time() + 3600,
            reason="Deploy freeze",
        )
        dim.register_hold(hold)
        score = dim.evaluate(_action("deploy_staging"), _ctx())
        assert score.veto
        # Different action type should pass
        score2 = dim.evaluate(_action("read"), _ctx())
        assert score2.score == 1.0

    def test_hold_does_not_affect_different_agent(self):
        """Hold for agent-1 does not block agent-2."""
        dim = TemporalCompliance()
        hold = HoldRecord(
            agent_id="agent-1",
            action_type_pattern="deploy",
            hold_until=time.time() + 3600,
            reason="Agent-specific hold",
        )
        dim.register_hold(hold)
        score = dim.evaluate(_action("deploy"), _ctx(agent_id="agent-2"))
        assert score.score == 1.0


# --- Precedent Alignment ---


class TestPrecedentAlignment:
    def test_no_history(self):
        dim = PrecedentAlignment()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.8
        assert score.result is not None
        assert score.result.primary_signal == "no_history"

    def test_no_matching_type(self):
        dim = PrecedentAlignment()
        history = [
            ActionRecord(
                action=_action("write"),
                verdict=GovernanceVerdict(action_id="x", verdict=Verdict.ALLOW, ucs=0.8),
            )
        ]
        score = dim.evaluate(_action("read"), _ctx(history=history))
        assert score.score == 0.7

    def test_consistent_with_precedent_zero_denials(self):
        """0% denial rate → score 0.9."""
        dim = PrecedentAlignment()
        history = [
            ActionRecord(
                action=_action("read"),
                verdict=GovernanceVerdict(action_id="x", verdict=Verdict.ALLOW, ucs=0.8),
            )
            for _ in range(5)
        ]
        score = dim.evaluate(_action("read"), _ctx(history=history))
        assert score.score == 0.9

    def test_graduated_scale_low_denial(self):
        """15% denial rate → score 0.75 (10–25% band)."""
        dim = PrecedentAlignment()
        # 3 denied out of 20 = 15%
        history = []
        for i in range(20):
            v = Verdict.DENY if i < 3 else Verdict.ALLOW
            history.append(ActionRecord(
                action=_action("write"),
                verdict=GovernanceVerdict(action_id=f"x{i}", verdict=v, ucs=0.5),
            ))
        score = dim.evaluate(_action("write"), _ctx(history=history))
        assert score.score == 0.75

    def test_graduated_scale_high_denial(self):
        """100% denial rate → score 0.05."""
        dim = PrecedentAlignment()
        history = [
            ActionRecord(
                action=_action("hack"),
                verdict=GovernanceVerdict(action_id="x", verdict=Verdict.DENY, ucs=0.0),
            )
            for _ in range(5)
        ]
        score = dim.evaluate(_action("hack"), _ctx(history=history))
        assert score.score == 0.05

    def test_graduated_scale_majority_denial(self):
        """60% denial → score 0.35 (50–75% band)."""
        dim = PrecedentAlignment()
        now = time.time()
        history = []
        for i in range(10):
            v = Verdict.DENY if i < 6 else Verdict.ALLOW
            r = ActionRecord(
                action=_action("write"),
                verdict=GovernanceVerdict(action_id=f"x{i}", verdict=v, ucs=0.5),
            )
            r.timestamp = now
            history.append(r)
        score = dim.evaluate(_action("write"), _ctx(history=history))
        assert score.score == 0.35

    def test_recency_decay_old_precedents_matter_less(self):
        """Old denied precedents decay, reducing effective denial rate."""
        dim = PrecedentAlignment(config=PrecedentConfig(half_life_days=1.0))
        now = time.time()
        # 5 old denials (30 days ago) + 5 recent allows (now)
        history = []
        for i in range(5):
            r = ActionRecord(
                action=_action("write"),
                verdict=GovernanceVerdict(action_id=f"old{i}", verdict=Verdict.DENY, ucs=0.0),
            )
            r.timestamp = now - 30 * 86400  # 30 days ago
            history.append(r)
        for i in range(5):
            r = ActionRecord(
                action=_action("write"),
                verdict=GovernanceVerdict(action_id=f"new{i}", verdict=Verdict.ALLOW, ucs=0.8),
            )
            r.timestamp = now
            history.append(r)
        score = dim.evaluate(_action("write"), _ctx(history=history))
        # Old denials have ~0 weight after 30 half-lives, so denial rate ≈ 0%
        assert score.score >= 0.75  # Should be in low-denial range

    def test_authority_weighting_tier3_counts_double(self):
        """Tier 3 precedents count 2x."""
        dim = PrecedentAlignment()
        now = time.time()
        # 1 tier-3 allow + 1 tier-1 deny
        # Without authority weighting: 50% denial → 0.35
        # With authority weighting: tier-3 allow = 2x weight
        #   denied_weight=1, total_weight=3, denial_rate=1/3 ≈ 33% → 0.55
        history = []
        r1 = ActionRecord(
            action=_action("write"),
            verdict=GovernanceVerdict(action_id="a", verdict=Verdict.ALLOW, ucs=0.8),
            deliberation_tier=3,
        )
        r1.timestamp = now
        history.append(r1)
        r2 = ActionRecord(
            action=_action("write"),
            verdict=GovernanceVerdict(action_id="b", verdict=Verdict.DENY, ucs=0.0),
            deliberation_tier=1,
        )
        r2.timestamp = now
        history.append(r2)
        score = dim.evaluate(_action("write"), _ctx(history=history))
        # denial_rate = 1/3 ≈ 33%, falls in 25–50% band → 0.55
        assert score.score == 0.55

    def test_produces_structured_result(self):
        dim = PrecedentAlignment()
        history = [
            ActionRecord(
                action=_action("read"),
                verdict=GovernanceVerdict(action_id="x", verdict=Verdict.ALLOW, ucs=0.8),
            )
        ]
        score = dim.evaluate(_action("read"), _ctx(history=history))
        assert score.result is not None
        assert score.result.dimension_name == "precedent_alignment"
        assert len(score.result.rules_evaluated) >= 1
        assert score.result.counterfactual != ""


# --- Transparency ---


class TestTransparency:
    def _make_peer_scores(
        self,
        *,
        with_results: bool = True,
        with_counterfactuals: bool = True,
        with_rules: bool = True,
        veto_capable_low: bool = False,
    ) -> list[DimensionScore]:
        """Helper to create peer scores for transparency testing."""
        scores = []
        for i, name in enumerate(["scope_compliance", "authority_verification", "precedent_alignment"]):
            result = None
            if with_results:
                result = DimensionResult(
                    dimension_name=name,
                    score=0.8,
                    counterfactual=f"Would score X if Y" if with_counterfactuals else "",
                    rules_evaluated=[
                        EvaluatedRule(
                            rule_id=f"rule_{i}",
                            rule_description="test rule",
                            triggered=False,
                            value_evaluated=None,
                            threshold_used=None,
                            outcome="pass",
                        )
                    ] if with_rules else [],
                )
            meta = {}
            score_val = 0.8
            if name == "scope_compliance":
                meta["can_veto"] = True
                if veto_capable_low:
                    score_val = 0.1
                    if result:
                        result.score = 0.1
            scores.append(DimensionScore(
                dimension_name=name,
                score=score_val,
                weight=1.0,
                reasoning="test",
                result=result,
                metadata=meta,
            ))
        return scores

    def test_no_peer_scores_returns_moderate(self):
        dim = Transparency()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.5
        assert score.result is not None
        assert "no_peer_scores" in score.result.primary_signal

    def test_fully_coherent_full_explanations(self):
        dim = Transparency()
        peers = self._make_peer_scores()
        score = dim.evaluate(_action(), _ctx(), peer_scores=peers)
        assert score.score == 1.0
        assert "coherent" in score.reasoning.lower()

    def test_incoherence_detection_veto_capable_low(self):
        """Veto-capable dim < 0.2 without veto → incoherence penalty of 0.3."""
        dim = Transparency()
        peers = self._make_peer_scores(veto_capable_low=True)
        score = dim.evaluate(_action(), _ctx(), peer_scores=peers)
        # Base 1.0 - 0.3 incoherence = 0.7 (no other penalties since all have results)
        assert score.score <= 0.7
        assert "Incoherence" in score.reasoning or "incoherence" in score.reasoning.lower()

    def test_low_counterfactual_completeness_penalty(self):
        """Missing counterfactuals reduce score."""
        dim = Transparency()
        peers = self._make_peer_scores(with_counterfactuals=False)
        score = dim.evaluate(_action(), _ctx(), peer_scores=peers)
        assert score.score < 1.0
        assert score.result is not None
        # Find the counterfactual rule
        cf_rules = [r for r in score.result.rules_evaluated if r.rule_id == "counterfactual_completeness"]
        assert len(cf_rules) == 1
        assert cf_rules[0].value_evaluated == 0.0  # 0% have counterfactuals

    def test_low_explanation_depth_penalty(self):
        """Missing rules_evaluated entries reduce score."""
        dim = Transparency()
        peers = self._make_peer_scores(with_rules=False)
        score = dim.evaluate(_action(), _ctx(), peer_scores=peers)
        assert score.score < 1.0
        assert score.result is not None
        depth_rules = [r for r in score.result.rules_evaluated if r.rule_id == "explanation_depth"]
        assert len(depth_rules) == 1
        assert depth_rules[0].value_evaluated == 0.0

    def test_combined_penalties_stack(self):
        """Incoherence + missing counterfactuals + missing rules all stack."""
        dim = Transparency()
        peers = self._make_peer_scores(
            with_counterfactuals=False,
            with_rules=False,
            veto_capable_low=True,
        )
        score = dim.evaluate(_action(), _ctx(), peer_scores=peers)
        # 1.0 - 0.3 (incoherence) - 0.2 (counterfactual) - 0.2 (depth) = 0.3
        assert abs(score.score - 0.3) < 0.01

    def test_weight_is_1_2(self):
        dim = Transparency()
        assert dim.weight == 1.2

    def test_excludes_own_score_from_peers(self):
        """If transparency's own score is in peers, it should be filtered out."""
        dim = Transparency()
        peers = self._make_peer_scores()
        # Add a transparency score to peers (shouldn't affect evaluation)
        peers.append(DimensionScore(
            dimension_name="transparency", score=0.5, weight=1.2, reasoning="self",
        ))
        score = dim.evaluate(_action(), _ctx(), peer_scores=peers)
        assert score.score == 1.0  # Same as without the self-score

    def test_peer_score_integration_via_orchestrator(self):
        """Transparency receives peer scores when run through the orchestrator."""
        from nomotic.orchestrator import DimensionOrchestrator
        orch = DimensionOrchestrator()
        # Use just a few dimensions including transparency
        dims = [PrecedentAlignment(), Transparency()]
        result = orch.evaluate(
            action=_action(), context=_ctx(),
            dimensions=dims,
            allow_threshold=0.5, deny_threshold=0.3,
        )
        # Transparency should have been evaluated with peer scores
        t_scores = [s for s in result.scores if s.dimension_name == "transparency"]
        assert len(t_scores) == 1
        assert t_scores[0].result is not None
        # It should have received precedent_alignment as a peer
        assert t_scores[0].result.primary_signal == "justification_quality"


# --- Human Override ---


class TestHumanOverride:
    def test_no_override_needed(self):
        dim = HumanOverride()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert score.result is not None

    def test_required_action_vetoes(self):
        dim = HumanOverride()
        dim.require_human_for("deploy")
        score = dim.evaluate(_action("deploy"), _ctx())
        assert score.veto
        assert score.result is not None
        assert score.result.primary_signal == "human_required"

    def test_approved_action_passes(self):
        dim = HumanOverride()
        dim.require_human_for("deploy")
        action = _action("deploy")
        dim.approve(action.id)
        score = dim.evaluate(action, _ctx())
        assert score.score == 1.0

    def test_low_trust_requires_human(self):
        dim = HumanOverride()
        score = dim.evaluate(_action(), _ctx(trust=0.1))
        assert score.veto

    def test_risk_based_threshold_by_action_type(self):
        """delete actions have a higher trust threshold than default."""
        config = OverrideThresholdConfig(
            default=0.3,
            by_action_type={"delete": 0.5},
        )
        dim = HumanOverride(threshold_config=config)
        # trust=0.4 is above default 0.3 but below delete's 0.5
        score = dim.evaluate(_action("delete"), _ctx(trust=0.4))
        assert score.veto
        # trust=0.4 is above default 0.3 for a 'read' action
        score2 = dim.evaluate(_action("read"), _ctx(trust=0.4))
        assert score2.score == 1.0

    def test_risk_based_threshold_by_environment(self):
        """Production environment has a higher trust threshold."""
        config = OverrideThresholdConfig(
            default=0.3,
            by_environment={"production": 0.6},
        )
        dim = HumanOverride(threshold_config=config)
        action = Action(
            agent_id="agent-1",
            action_type="write",
            target="db",
            environment=Environment.PRODUCTION,
        )
        # trust=0.5 is above default but below production's 0.6
        score = dim.evaluate(action, _ctx(trust=0.5))
        assert score.veto
        # Same trust with DEVELOPMENT should pass (uses default 0.3)
        action_dev = Action(
            agent_id="agent-1",
            action_type="write",
            target="db",
            environment=Environment.DEVELOPMENT,
        )
        score2 = dim.evaluate(action_dev, _ctx(trust=0.5))
        assert score2.score == 1.0


class TestHumanOverrideSQLiteStore:
    """Tests for SQLite-backed HumanOverrideStore persistence."""

    def test_sqlite_store_persists_across_instantiation(self):
        """Approval saved in one store instance is visible in a new instance."""
        import tempfile
        import os
        from nomotic.store import SQLiteHumanOverrideStore, GrantedApproval
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmpdir:
            db_path = os.path.join(tmpdir, "overrides.db")
            store1 = SQLiteHumanOverrideStore(db_path)
            store1.save_granted(GrantedApproval(
                action_id="act-1",
                agent_id="agent-1",
                action_type="deploy",
            ))
            # Create a new store instance pointing to the same DB
            store2 = SQLiteHumanOverrideStore(db_path)
            grant = store2.get_granted("act-1")
            assert grant is not None
            assert grant.action_id == "act-1"

    def test_pending_approval_expiry(self):
        """Expired pending approvals are moved to 'expired' state."""
        from nomotic.store import SQLiteHumanOverrideStore, PendingApproval
        store = SQLiteHumanOverrideStore()
        now = time.time()
        store.save_pending(PendingApproval(
            action_id="act-1",
            agent_id="agent-1",
            action_type="deploy",
            created_at=now - 100,
            expires_at=now - 10,  # already expired
        ))
        expired = store.expire_pending(now)
        assert len(expired) == 1
        assert expired[0].action_id == "act-1"
        assert expired[0].state == "expired"
        # Verify it's marked as expired in the store
        pa = store.get_pending("act-1")
        assert pa is not None
        assert pa.state == "expired"

    def test_granted_approval_expiry(self):
        """Expired granted approvals are removed and require re-approval."""
        from nomotic.store import SQLiteHumanOverrideStore, GrantedApproval
        store = SQLiteHumanOverrideStore()
        now = time.time()
        store.save_granted(GrantedApproval(
            action_id="act-1",
            agent_id="agent-1",
            action_type="deploy",
            valid_until=now - 10,  # already expired
        ))
        removed = store.remove_expired_grants(now)
        assert len(removed) == 1
        assert removed[0].action_id == "act-1"
        # Grant should no longer be found
        assert store.get_granted("act-1") is None

    def test_human_override_with_sqlite_store(self):
        """HumanOverride works with SQLiteHumanOverrideStore."""
        from nomotic.store import SQLiteHumanOverrideStore
        store = SQLiteHumanOverrideStore()
        dim = HumanOverride()
        dim.set_store(store)
        dim.require_human_for("deploy")
        action = _action("deploy")
        # Should veto
        score = dim.evaluate(action, _ctx())
        assert score.veto
        # Approve via store
        dim.approve(action.id)
        score2 = dim.evaluate(action, _ctx())
        assert score2.score == 1.0

    def test_approval_expiry_through_dimension(self):
        """Expired grant detected during evaluation requires re-approval."""
        from nomotic.store import SQLiteHumanOverrideStore
        store = SQLiteHumanOverrideStore()
        dim = HumanOverride()
        dim.set_store(store)
        dim.require_human_for("deploy")
        action = _action("deploy")
        # Approve with a validity that's already expired
        dim.approve(action.id, valid_until=time.time() - 10)
        score = dim.evaluate(action, _ctx())
        assert score.veto  # Expired grant should not count

    def test_escalation_callback_on_pending_expiry(self):
        """Escalation callback fires when pending approval expires."""
        from nomotic.store import SQLiteHumanOverrideStore
        store = SQLiteHumanOverrideStore()
        escalated = []
        dim = HumanOverride(pending_ttl=0.001)  # very short TTL
        dim.set_store(store)
        dim.set_escalation_callback(lambda pa: escalated.append(pa))
        dim.require_human_for("deploy")
        action1 = _action("deploy")
        # Evaluate to create pending
        dim.evaluate(action1, _ctx())
        # Wait for expiry
        time.sleep(0.01)
        # Evaluate again — should trigger expiry of first pending
        action2 = _action("deploy")
        dim.evaluate(action2, _ctx())
        assert len(escalated) >= 1


# --- Ethical Alignment ---


class TestEthicalAlignment:
    def test_unconfigured_default_scores_05(self):
        """Breaking change: unconfigured → 0.5, not 0.8."""
        dim = EthicalAlignment()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.5
        assert score.confidence == 0.5
        assert not score.veto

    def test_passing_rule(self):
        dim = EthicalAlignment()
        dim.add_rule(lambda a, c: (True, "ok"))
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    def test_failing_rule_vetoes(self):
        """Legacy lambda failing rule still vetoes (severity=violation)."""
        dim = EthicalAlignment()
        dim.add_rule(lambda a, c: (False, "violates principle X"))
        score = dim.evaluate(_action(), _ctx())
        assert score.veto
        assert score.score == 0.0
        assert "principle X" in score.reasoning

    # --- Non-short-circuit: all failures collected ---

    def test_non_short_circuit_collects_all_failures(self):
        """All rules evaluated; all failures appear in result."""
        dim = EthicalAlignment()
        dim.add_rule(lambda a, c: (False, "rule A failed"))
        dim.add_rule(lambda a, c: (False, "rule B failed"))
        dim.add_rule(lambda a, c: (True, "ok"))
        score = dim.evaluate(_action(), _ctx())
        assert score.veto
        assert score.score == 0.0
        assert score.result is not None
        failed = [r for r in score.result.rules_evaluated if r.outcome == "fail"]
        assert len(failed) == 2
        passed = [r for r in score.result.rules_evaluated if r.outcome == "pass"]
        assert len(passed) == 1

    # --- Graduated scoring ---

    def test_concern_severity_score_04(self):
        """Concern severity → score 0.4, escalation_required=True."""
        dim = EthicalAlignment()
        dim.add_ethical_rule(EthicalRule(
            rule_id="bias_check",
            description="Check for bias",
            severity="concern",
            custom_check=lambda a, c: (False, "potential bias detected"),
        ))
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.4
        assert not score.veto
        assert score.result is not None
        assert score.result.escalation_required

    def test_advisory_severity_score_065(self):
        """Advisory severity → score 0.65, no veto, no escalation."""
        dim = EthicalAlignment()
        dim.add_ethical_rule(EthicalRule(
            rule_id="style_check",
            description="Style guideline",
            severity="advisory",
            custom_check=lambda a, c: (False, "minor style issue"),
        ))
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.65
        assert not score.veto
        assert score.result is not None
        assert not score.result.escalation_required

    def test_violation_worst_severity_wins(self):
        """Mixed severities: worst (violation) determines score."""
        dim = EthicalAlignment()
        dim.add_ethical_rule(EthicalRule(
            rule_id="advisory_1",
            description="Minor issue",
            severity="advisory",
            custom_check=lambda a, c: (False, "minor"),
        ))
        dim.add_ethical_rule(EthicalRule(
            rule_id="violation_1",
            description="Critical issue",
            severity="violation",
            custom_check=lambda a, c: (False, "critical"),
        ))
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.0
        assert score.veto
        # Both failures collected
        failed = [r for r in score.result.rules_evaluated if r.outcome == "fail"]
        assert len(failed) == 2

    # --- Rule relevance filtering ---

    def test_applies_to_filters_by_action_type(self):
        """Rules with applies_to only run against matching action types."""
        dim = EthicalAlignment()
        dim.add_ethical_rule(EthicalRule(
            rule_id="delete_only",
            description="Delete restriction",
            applies_to=["delete"],
            severity="violation",
            custom_check=lambda a, c: (False, "no deletes allowed"),
        ))
        # Read action → rule skipped
        score = dim.evaluate(_action("read"), _ctx())
        assert score.score == 1.0
        assert score.result is not None
        skipped = [r for r in score.result.rules_evaluated if r.outcome == "skip"]
        assert len(skipped) == 1

        # Delete action → rule fires
        score = dim.evaluate(_action("delete"), _ctx())
        assert score.score == 0.0
        assert score.veto

    def test_data_sensitivity_threshold_filtering(self):
        """Rules with data_sensitivity_threshold only run when action sensitivity is high enough."""
        dim = EthicalAlignment()
        dim.add_ethical_rule(EthicalRule(
            rule_id="pii_rule",
            description="PII handling restriction",
            data_sensitivity_threshold=DataSensitivity.PII,
            severity="violation",
            custom_check=lambda a, c: (False, "PII not allowed here"),
        ))
        # No sensitivity → rule skipped
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

        # Internal sensitivity (below PII) → rule skipped
        action_internal = Action(agent_id="agent-1", action_type="read", target="db",
                                 data_sensitivity=DataSensitivity.INTERNAL)
        score = dim.evaluate(action_internal, _ctx())
        assert score.score == 1.0

        # PII sensitivity → rule fires
        action_pii = Action(agent_id="agent-1", action_type="read", target="db",
                            data_sensitivity=DataSensitivity.PII)
        score = dim.evaluate(action_pii, _ctx())
        assert score.score == 0.0
        assert score.veto

    def test_produces_dimension_result(self):
        dim = EthicalAlignment()
        dim.add_ethical_rule(EthicalRule(
            rule_id="test_rule",
            description="Test rule",
            custom_check=lambda a, c: (True, "ok"),
        ))
        score = dim.evaluate(_action(), _ctx())
        assert score.result is not None
        assert score.result.dimension_name == "ethical_alignment"
        assert len(score.result.rules_evaluated) == 1


# --- Registry ---


class TestDimensionRegistry:
    def test_default_has_14_core_dimensions(self):
        reg = DimensionRegistry.create_default()
        assert len(reg.dimensions) == 14

    def test_evaluate_all_returns_14_scores(self):
        reg = DimensionRegistry.create_default()
        scores = reg.evaluate_all(_action(), _ctx())
        assert len(scores) == 14

    def test_all_dimension_names_unique(self):
        reg = DimensionRegistry.create_default()
        names = [d.name for d in reg.dimensions]
        assert len(names) == len(set(names))

    def test_all_core_dimension_names_present(self):
        reg = DimensionRegistry.create_default()
        names = {d.name for d in reg.dimensions}
        assert names == CORE_DIMENSION_NAMES

    def test_available_count_no_plugins(self):
        reg = DimensionRegistry.create_default()
        counts = reg.available_count()
        assert counts == {"core": 14, "plugin": 0, "total": 14}


# --- Jurisdictional Compliance ---


from nomotic.dimensions import JurisdictionalCompliance
from nomotic.context_profile import ContextProfile, JurisdictionalContext


def _dim_with_accessor(jctx):
    """Create a JurisdictionalCompliance dimension with a mock accessor returning jctx."""
    dim = JurisdictionalCompliance()
    dim.set_jurisdictional_accessor(lambda _: jctx)
    return dim


class TestJurisdictionalCompliance:
    """Tests for Dimension 14: Jurisdictional Compliance (accessor-based)."""

    # --- Core scoring tests ---

    def test_no_jurisdictional_context_scores_07(self):
        dim = JurisdictionalCompliance()
        # No accessor → returns 0.7
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.7
        assert not score.veto

    def test_compliant_action_scores_1_0(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="legitimate_interest",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_cross_border_eu_to_us_no_mechanism_vetoes(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["us/east"],
            transfer_mechanism=None,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.0
        assert score.veto

    def test_cross_border_eu_to_us_scc_mechanism_scores_0_9(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["us/east"],
            transfer_mechanism="standard_contractual_clauses",
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.9
        assert not score.veto

    def test_gdpr_pii_no_legal_basis_scores_0_3(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis=None,
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.3
        assert not score.veto
        assert "GDPR" in score.reasoning

    def test_china_data_inference_outside_china_vetoes(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["cn/shanghai"],
            data_classification="pii",
            applicable_regulations=["pipl"],
            agent_operating_zone="us/east",
            model_inference_zone="us/east",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.0
        assert score.veto
        assert "prohibited" in score.reasoning

    def test_china_data_inference_inside_china_passes(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["cn/shanghai"],
            data_classification="pii",
            applicable_regulations=["pipl"],
            agent_operating_zone="cn/beijing",
            model_inference_zone="cn/beijing",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_eu_to_adequate_destination_switzerland_passes(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["ch/zurich"],
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_public_data_gdpr_no_legal_basis_passes(self):
        """Public data doesn't trigger the GDPR legal basis check."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="public",
            applicable_regulations=["gdpr"],
            legal_basis=None,
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_minimal_context_scores_0_8(self):
        """Empty JurisdictionalContext → score 0.8 (minimal)."""
        jctx = JurisdictionalContext()
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.8
        assert not score.veto

    # --- Configuration tests ---

    def test_weight_default_1_4(self):
        dim = JurisdictionalCompliance()
        assert dim.weight == 1.4

    def test_can_veto_is_true(self):
        dim = JurisdictionalCompliance()
        assert dim.can_veto is True

    def test_name_is_jurisdictional_compliance(self):
        dim = JurisdictionalCompliance()
        assert dim.name == "jurisdictional_compliance"

    # --- Registry integration tests ---

    def test_dimension_14_in_default_registry(self):
        reg = DimensionRegistry.create_default()
        names = [d.name for d in reg.dimensions]
        assert "jurisdictional_compliance" in names

    def test_create_default_returns_14_dimensions(self):
        reg = DimensionRegistry.create_default()
        assert len(reg.dimensions) == 14

    def test_registry_get_jurisdictional_compliance(self):
        reg = DimensionRegistry.create_default()
        dim = reg.get("jurisdictional_compliance")
        assert dim is not None
        assert dim.can_veto is True
        assert dim.name == "jurisdictional_compliance"

    def test_dimension_14_is_last_in_registry(self):
        reg = DimensionRegistry.create_default()
        assert reg.dimensions[-1].name == "jurisdictional_compliance"

    def test_score_includes_weight(self):
        dim = JurisdictionalCompliance()
        score = dim.evaluate(_action(), _ctx())
        assert score.weight == 1.4

    # --- Per-action jurisdiction override ---

    def test_per_action_jurisdiction_overrides_agent_zone(self):
        """action.declared_jurisdiction is primary; agent zone is fallback."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=[],  # empty — zone-derived regs should apply
            legal_basis="consent",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        dim.configure_agent_zone("agent-1", "us/east")  # agent registered in US

        # Action declares EU jurisdiction — GDPR should apply via zone rules
        action = Action(agent_id="agent-1", action_type="read", target="db", declared_jurisdiction="eu/de")
        score = dim.evaluate(action, _ctx())
        # Should pass (legal_basis is set, GDPR satisfied)
        assert score.score == 1.0
        assert score.result is not None
        assert "declared_jurisdiction" in score.result.schema_fields_used

    def test_agent_zone_fallback_when_no_declared_jurisdiction(self):
        """When action has no declared_jurisdiction, use agent's registered zone."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=[],
            legal_basis="consent",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        dim.configure_agent_zone("agent-1", "eu/fr")

        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    # --- Regulation conflict escalation ---

    def test_conflicting_regulations_trigger_escalation(self):
        """CONFLICTING_REGULATION_PAIRS fires → escalation_required = True."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr", "pipl"],
            legal_basis="consent",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.result is not None
        assert score.result.escalation_required is True
        conflict_rules = [r for r in score.result.rules_evaluated if r.rule_id == "regulation_conflict"]
        assert len(conflict_rules) == 1
        assert conflict_rules[0].triggered

    def test_no_conflict_no_escalation(self):
        """Non-conflicting regulations → no escalation."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.result is not None
        assert score.result.escalation_required is False

    # --- GDPR legal basis appropriateness ---

    def test_legitimate_interest_for_marketing_advisory(self):
        """legitimate_interest + marketing_communication → advisory warning."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="legitimate_interest",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        action = _action(action_type="marketing_communication", target="users")
        score = dim.evaluate(action, _ctx())
        # Score should still be 1.0 (advisory, not veto)
        assert score.score == 1.0
        assert score.result is not None
        appropriateness_rules = [
            r for r in score.result.rules_evaluated
            if r.rule_id == "gdpr_legal_basis_appropriateness"
        ]
        assert len(appropriateness_rules) == 1
        assert appropriateness_rules[0].triggered
        assert "inappropriate" in score.reasoning.lower() or "advisory" in score.reasoning.lower()

    def test_consent_for_marketing_no_advisory(self):
        """consent + marketing_communication → no advisory."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        action = _action(action_type="marketing_communication", target="users")
        score = dim.evaluate(action, _ctx())
        assert score.score == 1.0
        assert score.result is not None
        appropriateness_rules = [
            r for r in score.result.rules_evaluated
            if r.rule_id == "gdpr_legal_basis_appropriateness"
        ]
        assert len(appropriateness_rules) == 0

    # --- Structured DimensionResult ---

    def test_jurisdictional_produces_dimension_result(self):
        """JurisdictionalCompliance always produces a DimensionResult."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.result is not None
        assert score.result.dimension_name == "jurisdictional_compliance"
        assert score.result.evaluation_time_ms >= 0


# --- Incident Detection (Enhanced) ---

from nomotic.dimensions import IncidentConfig, IncidentPattern


def _history_of(n: int, action_type: str = "read", target: str = "db") -> list:
    """Build a list of n ActionRecords with the given action_type."""
    records = []
    for _ in range(n):
        a = _action(action_type=action_type, target=target)
        v = GovernanceVerdict(
            action_id=a.id, verdict=Verdict.ALLOW, ucs=0.9,
            dimension_scores=[], tier=1, vetoed_by=[], modifications={},
            reasoning="ok", timestamp=time.time(), evaluation_time_ms=1.0,
        )
        records.append(ActionRecord(action=a, verdict=v))
    return records


class TestIncidentDetectionEnhanced:
    """Tests for the enhanced IncidentDetection dimension."""

    # --- Declarative IncidentPattern ---

    def test_incident_pattern_fires_and_produces_result(self):
        """IncidentPattern with high concern → low score + structured result."""
        pat = IncidentPattern(
            pattern_id="test_escalation",
            description="Detects test escalation",
            category="privilege_escalation",
            detector=lambda a, c: 0.8 if a.action_type == "escalate" else None,
        )
        dim = IncidentDetection()
        dim.add_incident_pattern(pat)
        action = _action(action_type="escalate", target="admin")
        score = dim.evaluate(action, _ctx(history=_history_of(5)))
        assert score.score == 0.2  # 1.0 - 0.8
        assert score.result is not None
        assert score.result.dimension_name == "incident_detection"
        assert score.result.primary_signal.startswith("Pattern 'test_escalation'")
        assert score.metadata.get("fired_pattern_id") == "test_escalation"
        assert score.metadata.get("fired_category") == "privilege_escalation"

    def test_pattern_skipped_when_history_too_shallow(self):
        """Pattern with min_history_depth=5 skipped when only 2 actions in history."""
        pat = IncidentPattern(
            pattern_id="deep_pattern",
            description="Needs 5 actions",
            category="exfiltration",
            detector=lambda a, c: 0.9,
            min_history_depth=5,
        )
        dim = IncidentDetection()
        dim.add_incident_pattern(pat)
        score = dim.evaluate(_action(), _ctx(history=_history_of(2)))
        # Pattern should be skipped, score = 1.0
        assert score.score == 1.0
        skip_rules = [r for r in score.result.rules_evaluated if r.outcome == "skip"]
        assert len(skip_rules) == 1
        assert skip_rules[0].rule_id == "deep_pattern"

    def test_legacy_add_pattern_still_works(self):
        """Legacy add_pattern() wraps lambda as IncidentPattern."""
        dim = IncidentDetection()
        dim.add_pattern(lambda a, c: 0.5 if a.action_type == "delete" else None)
        score = dim.evaluate(_action(action_type="delete"), _ctx(history=_history_of(3)))
        assert score.score == 0.5
        assert score.result is not None

    # --- Configurable veto and escalation thresholds ---

    def test_veto_threshold_configurable(self):
        """Score at or below veto_threshold → veto."""
        config = IncidentConfig(veto_threshold=0.15, escalation_threshold=0.3)
        pat = IncidentPattern(
            pattern_id="severe",
            description="Severe pattern",
            category="exfiltration",
            detector=lambda a, c: 0.9,  # score = 0.1
        )
        dim = IncidentDetection(config=config)
        dim.add_incident_pattern(pat)
        score = dim.evaluate(_action(), _ctx(history=_history_of(3)))
        assert score.score == 0.1
        assert score.veto is True  # 0.1 <= 0.15

    def test_escalation_threshold(self):
        """Score between veto and escalation thresholds → escalation_required."""
        config = IncidentConfig(veto_threshold=0.1, escalation_threshold=0.3)
        pat = IncidentPattern(
            pattern_id="moderate",
            description="Moderate pattern",
            category="privilege_escalation",
            detector=lambda a, c: 0.8,  # score = 0.2
        )
        dim = IncidentDetection(config=config)
        dim.add_incident_pattern(pat)
        score = dim.evaluate(_action(), _ctx(history=_history_of(3)))
        assert score.score == 0.2
        assert score.veto is False  # 0.2 > 0.1
        assert score.result is not None
        assert score.result.escalation_required is True  # 0.2 <= 0.3

    def test_default_veto_at_0_1(self):
        """Default config: veto at 0.1."""
        pat = IncidentPattern(
            pattern_id="critical",
            description="Critical",
            category="exfiltration",
            detector=lambda a, c: 0.9,  # score = 0.1
        )
        dim = IncidentDetection()
        dim.add_incident_pattern(pat)
        score = dim.evaluate(_action(), _ctx(history=_history_of(3)))
        assert score.veto is True  # default threshold 0.1

    def test_above_escalation_no_flags(self):
        """Score above escalation_threshold → no veto, no escalation."""
        config = IncidentConfig(veto_threshold=0.1, escalation_threshold=0.25)
        pat = IncidentPattern(
            pattern_id="mild",
            description="Mild concern",
            category="drift",
            detector=lambda a, c: 0.3,  # score = 0.7
        )
        dim = IncidentDetection(config=config)
        dim.add_incident_pattern(pat)
        score = dim.evaluate(_action(), _ctx(history=_history_of(3)))
        assert score.score == 0.7
        assert score.veto is False
        assert score.result.escalation_required is False

    # --- Lookahead detection ---

    def test_lookahead_fires_advisory(self):
        """Lookahead patterns fire with halved concern."""
        pat = IncidentPattern(
            pattern_id="early_escalation",
            description="Early stage of escalation sequence",
            category="privilege_escalation",
            detector=lambda a, c: 0.8,
        )
        dim = IncidentDetection()
        dim.add_lookahead_pattern(pat)
        score = dim.evaluate(_action(), _ctx(history=[]))
        # Concern is halved: 0.8 * 0.5 = 0.4, score = 1.0 - 0.4 = 0.6
        assert score.score == 0.6
        assert score.metadata.get("lookahead_fired") is True
        lookahead_rules = [r for r in score.result.rules_evaluated if r.rule_id.startswith("lookahead:")]
        assert len(lookahead_rules) == 1

    def test_lookahead_does_not_fire_when_no_match(self):
        """Lookahead pattern returns None → no advisory."""
        pat = IncidentPattern(
            pattern_id="no_match",
            description="No match",
            category="exfiltration",
            detector=lambda a, c: None,
        )
        dim = IncidentDetection()
        dim.add_lookahead_pattern(pat)
        score = dim.evaluate(_action(), _ctx(history=[]))
        assert score.score == 1.0
        assert score.metadata.get("lookahead_fired") is False

    # --- Multi-category co-occurrence amplification ---

    def test_two_categories_amplify_concern(self):
        """Two independent categories (each 0.4 concern) → combined score ≈ 0.36."""
        pat1 = IncidentPattern(
            pattern_id="pat_a",
            description="Category A",
            category="privilege_escalation",
            detector=lambda a, c: 0.4,
        )
        pat2 = IncidentPattern(
            pattern_id="pat_b",
            description="Category B",
            category="exfiltration",
            detector=lambda a, c: 0.4,
        )
        dim = IncidentDetection()
        dim.add_incident_pattern(pat1)
        dim.add_incident_pattern(pat2)
        score = dim.evaluate(_action(), _ctx(history=_history_of(3)))
        # Each category concern=0.4, single pattern score = 0.6
        # Co-occurrence: (1-0.4) * (1-0.4) = 0.36
        assert abs(score.score - 0.36) < 0.01
        co_rules = [r for r in score.result.rules_evaluated if r.rule_id == "multi_category_co_occurrence"]
        assert len(co_rules) == 1

    def test_single_category_no_amplification(self):
        """One category → no co-occurrence amplification."""
        pat1 = IncidentPattern(
            pattern_id="pat_a",
            description="Same category",
            category="exfiltration",
            detector=lambda a, c: 0.4,
        )
        pat2 = IncidentPattern(
            pattern_id="pat_b",
            description="Same category again",
            category="exfiltration",
            detector=lambda a, c: 0.3,
        )
        dim = IncidentDetection()
        dim.add_incident_pattern(pat1)
        dim.add_incident_pattern(pat2)
        score = dim.evaluate(_action(), _ctx(history=_history_of(3)))
        # Worst single pattern: concern 0.4 → score 0.6
        # Only 1 category, no co-occurrence
        assert score.score == 0.6

    def test_three_categories_stronger_amplification(self):
        """Three independent categories amplify more than two."""
        pats = [
            IncidentPattern(
                pattern_id=f"pat_{cat}",
                description=f"Category {cat}",
                category=cat,
                detector=lambda a, c: 0.3,
            )
            for cat in ["privilege_escalation", "exfiltration", "confused_deputy"]
        ]
        dim = IncidentDetection()
        for p in pats:
            dim.add_incident_pattern(p)
        score = dim.evaluate(_action(), _ctx(history=_history_of(3)))
        # Co-occurrence: (1-0.3)^3 = 0.343
        assert abs(score.score - 0.343) < 0.01

    # --- Structured DimensionResult ---

    def test_incident_detection_produces_result(self):
        """IncidentDetection always attaches a DimensionResult."""
        dim = IncidentDetection()
        score = dim.evaluate(_action(), _ctx())
        assert score.result is not None
        assert score.result.dimension_name == "incident_detection"
        assert score.result.evaluation_time_ms >= 0

    def test_no_patterns_clean_result(self):
        """No patterns → score 1.0, clean result."""
        dim = IncidentDetection()
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert not score.veto
        assert score.result.escalation_required is False


# --- AdversarialScenario.to_incident_pattern ---

from nomotic.internal.adversarial import (
    AdversarialAction,
    AdversarialPhase,
    AdversarialScenario,
    ExpectedOutcome,
)


class TestAdversarialToIncidentPattern:
    """Tests for AdversarialScenario.to_incident_pattern()."""

    def _simple_scenario(self) -> AdversarialScenario:
        return AdversarialScenario(
            name="test_escalation",
            category="privilege_escalation",
            description="Test privilege escalation",
            setup_description="Basic scope",
            required_scope={},
            phases=[
                AdversarialPhase(
                    name="escalate",
                    description="Attempt escalation",
                    actions=[
                        AdversarialAction(
                            action_type="modify_permissions",
                            target="admin_config",
                            parameters={},
                            description="Modify admin perms",
                            attack_technique="privilege_escalation",
                            expected=ExpectedOutcome(
                                verdict="DENY",
                                caught_by=["scope_compliance"],
                                min_trust_impact=-0.1,
                                description="Should be denied",
                            ),
                        ),
                    ],
                ),
            ],
        )

    def test_returns_incident_pattern(self):
        scenario = self._simple_scenario()
        pat = scenario.to_incident_pattern()
        assert isinstance(pat, IncidentPattern)
        assert pat.pattern_id == "adversarial:test_escalation"
        assert pat.category == "privilege_escalation"

    def test_detector_matches_scenario_actions(self):
        scenario = self._simple_scenario()
        pat = scenario.to_incident_pattern()
        action = _action(action_type="modify_permissions", target="admin_config")
        concern = pat.detector(action, _ctx())
        assert concern == 0.9  # DENY → 0.9

    def test_detector_returns_none_for_unrelated_action(self):
        scenario = self._simple_scenario()
        pat = scenario.to_incident_pattern()
        action = _action(action_type="read", target="logs")
        concern = pat.detector(action, _ctx())
        assert concern is None

    def test_pattern_usable_in_incident_detection(self):
        """IncidentPattern from scenario can be registered and fires."""
        scenario = self._simple_scenario()
        pat = scenario.to_incident_pattern()
        dim = IncidentDetection()
        dim.add_incident_pattern(pat)
        action = _action(action_type="modify_permissions", target="admin_config")
        score = dim.evaluate(action, _ctx(history=_history_of(3)))
        # concern 0.9 → score 0.1 → veto
        assert score.score == 0.1
        assert score.veto is True


