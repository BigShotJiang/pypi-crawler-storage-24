"""Tests for the CLI argument parsing and commands."""

import json
import re
import tempfile
from pathlib import Path

import pytest

from nomotic.cli import build_parser, main


def _extract_cert_id(output: str) -> str:
    """Extract certificate ID from birth command output."""
    # New format: "  Certificate: nmc-..."
    m = re.search(r"Certificate:\s+(nmc-\S+)", output)
    if m:
        return m.group(1)
    # Old format: "Certificate issued: nmc-..."
    m = re.search(r"Certificate issued:\s+(nmc-\S+)", output)
    if m:
        return m.group(1)
    raise ValueError(f"Could not find cert ID in output:\n{output}")


class TestCLIArgParsing:
    def test_birth_args(self):
        parser = build_parser()
        args = parser.parse_args([
            "birth",
            "--name", "agent-1",
            "--archetype", "customer-experience",
            "--org", "acme",
            "--zone", "global/us",
        ])
        assert args.command == "birth"
        assert args.name == "agent-1"
        assert args.archetype == "customer-experience"
        assert args.org == "acme"
        assert args.zone == "global/us"

    def test_birth_args_with_agent_id_compat(self):
        """--agent-id is a hidden alias for backward compatibility."""
        parser = build_parser()
        args = parser.parse_args([
            "birth",
            "--agent-id", "agent-1",
            "--archetype", "customer-experience",
            "--org", "acme",
        ])
        assert args.command == "birth"
        assert args.agent_id_compat == "agent-1"

    def test_birth_args_with_owner(self):
        parser = build_parser()
        args = parser.parse_args([
            "birth",
            "--name", "agent-1",
            "--owner", "ops@acme.com",
            "--archetype", "arch",
            "--org", "org",
        ])
        assert args.owner == "ops@acme.com"

    def test_birth_args_no_zone(self):
        parser = build_parser()
        args = parser.parse_args([
            "birth",
            "--name", "agent-1",
            "--archetype", "arch",
            "--org", "org",
        ])
        assert args.zone is None
        assert args.owner is None

    def test_birth_args_name_only(self):
        """--name is the only required flag; archetype/org/zone are optional."""
        parser = build_parser()
        args = parser.parse_args([
            "birth",
            "--name", "my-agent",
        ])
        assert args.command == "birth"
        assert args.name == "my-agent"
        assert args.archetype is None
        assert args.org is None
        assert args.zone is None

    def test_setup_args(self):
        parser = build_parser()
        args = parser.parse_args(["setup"])
        assert args.command == "setup"

    def test_verify_args(self):
        parser = build_parser()
        args = parser.parse_args(["verify", "nmc-1234"])
        assert args.command == "verify"
        assert args.cert_id == "nmc-1234"

    def test_inspect_args(self):
        parser = build_parser()
        args = parser.parse_args(["inspect", "nmc-1234"])
        assert args.command == "inspect"
        assert args.agent_id == "nmc-1234"

    def test_inspect_args_brief(self):
        parser = build_parser()
        args = parser.parse_args(["inspect", "nmc-1234", "--brief"])
        assert args.command == "inspect"
        assert args.agent_id == "nmc-1234"
        assert args.brief is True
        assert args.raw is False

    def test_inspect_args_raw(self):
        parser = build_parser()
        args = parser.parse_args(["inspect", "nmc-1234", "--raw"])
        assert args.command == "inspect"
        assert args.agent_id == "nmc-1234"
        assert args.raw is True
        assert args.brief is False

    def test_suspend_args(self):
        parser = build_parser()
        args = parser.parse_args(["suspend", "nmc-1234", "--reason", "policy"])
        assert args.command == "suspend"
        assert args.cert_id == "nmc-1234"
        assert args.reason == "policy"

    def test_reactivate_args(self):
        parser = build_parser()
        args = parser.parse_args(["reactivate", "nmc-1234"])
        assert args.command == "reactivate"
        assert args.cert_id == "nmc-1234"

    def test_revoke_args(self):
        parser = build_parser()
        args = parser.parse_args(["revoke", "nmc-1234", "--reason", "done"])
        assert args.command == "revoke"
        assert args.cert_id == "nmc-1234"
        assert args.reason == "done"

    def test_renew_args(self):
        parser = build_parser()
        args = parser.parse_args(["renew", "nmc-1234"])
        assert args.command == "renew"
        assert args.cert_id == "nmc-1234"

    def test_list_args(self):
        parser = build_parser()
        args = parser.parse_args(["list", "--status", "ACTIVE", "--org", "acme"])
        assert args.command == "list"
        assert args.status == "ACTIVE"
        assert args.org == "acme"

    def test_reputation_args(self):
        parser = build_parser()
        args = parser.parse_args(["reputation", "nmc-1234"])
        assert args.command == "reputation"
        assert args.cert_id == "nmc-1234"

    def test_export_args(self):
        parser = build_parser()
        args = parser.parse_args(["export", "nmc-1234"])
        assert args.command == "export"
        assert args.cert_id == "nmc-1234"

    def test_history_args(self):
        parser = build_parser()
        args = parser.parse_args(["history", "1000"])
        assert args.command == "history"
        assert args.identifier == "1000"

    def test_base_dir_arg(self):
        parser = build_parser()
        args = parser.parse_args(["--base-dir", "/tmp/test", "list"])
        assert args.base_dir == Path("/tmp/test")


class TestCLICommands:
    def test_birth_command(self, capsys):
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "agent-1",
                "--owner", "ops@acme.com",
                "--archetype", "customer-experience",
                "--org", "acme",
            ])
            captured = capsys.readouterr()
            assert "Agent created:" in captured.out
            assert "agent-1" in captured.out
            assert "ops@acme.com" in captured.out
            assert "customer-experience" in captured.out
            assert "ID:" in captured.out
            assert "1000" in captured.out  # First agent gets ID 1000

    def test_birth_with_agent_id_compat(self, capsys):
        """--agent-id backward compatibility works."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--agent-id", "old-style",
                "--archetype", "customer-experience",
                "--org", "acme",
            ])
            captured = capsys.readouterr()
            assert "Agent created:" in captured.out
            assert "old-style" in captured.out

    def test_birth_then_verify(self, capsys):
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "agent-1",
                "--archetype", "arch",
                "--org", "org",
            ])
            captured = capsys.readouterr()
            cert_id = _extract_cert_id(captured.out)

            main(["--base-dir", tmp, "verify", cert_id])
            captured = capsys.readouterr()
            assert "VALID" in captured.out

    def test_birth_then_inspect_raw(self, capsys):
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "agent-1",
                "--archetype", "arch",
                "--org", "org",
            ])
            captured = capsys.readouterr()
            cert_id = _extract_cert_id(captured.out)

            main(["--base-dir", tmp, "inspect", cert_id, "--raw"])
            captured = capsys.readouterr()
            data = json.loads(captured.out)
            assert data["agent_id"] == "agent-1"
            assert data["agent_numeric_id"] == 1000

    def test_birth_then_inspect_brief(self, capsys):
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "agent-1",
                "--archetype", "arch",
                "--org", "org",
            ])
            captured = capsys.readouterr()
            cert_id = _extract_cert_id(captured.out)

            main(["--base-dir", tmp, "inspect", cert_id, "--brief"])
            captured = capsys.readouterr()
            assert "agent-1" in captured.out
            assert "Status:" in captured.out
            assert "Trust:" in captured.out
            assert "ACTIVE" in captured.out

    def test_birth_then_inspect_default(self, capsys):
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "agent-1",
                "--archetype", "arch",
                "--org", "org",
            ])
            captured = capsys.readouterr()
            cert_id = _extract_cert_id(captured.out)

            main(["--base-dir", tmp, "inspect", cert_id])
            captured = capsys.readouterr()
            assert "Governance Configuration: agent-1" in captured.out
            assert "Identity:" in captured.out

    def test_inspect_unresolved_identifier(self, capsys):
        """inspect with an unknown identifier still shows what it can find."""
        with tempfile.TemporaryDirectory() as tmp:
            # No agents exist — _resolve_agent will sys.exit(1), caught by except
            main(["--base-dir", tmp, "inspect", "ghost-agent"])
            captured = capsys.readouterr()
            # Should show governance config section (even if empty)
            assert "Governance Configuration" in captured.out

    def test_birth_suspend_reactivate(self, capsys):
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "agent-1",
                "--archetype", "arch",
                "--org", "org",
            ])
            captured = capsys.readouterr()
            cert_id = _extract_cert_id(captured.out)

            main(["--base-dir", tmp, "suspend", cert_id, "--reason", "test"])
            captured = capsys.readouterr()
            assert "Suspended" in captured.out

            main(["--base-dir", tmp, "reactivate", cert_id])
            captured = capsys.readouterr()
            assert "Reactivated" in captured.out

    def test_birth_then_revoke(self, capsys):
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "agent-1",
                "--archetype", "arch",
                "--org", "org",
            ])
            captured = capsys.readouterr()
            cert_id = _extract_cert_id(captured.out)

            main(["--base-dir", tmp, "revoke", cert_id, "--reason", "done"])
            captured = capsys.readouterr()
            assert "Revoked" in captured.out

    def test_birth_then_renew(self, capsys):
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "agent-1",
                "--archetype", "arch",
                "--org", "org",
            ])
            captured = capsys.readouterr()
            cert_id = _extract_cert_id(captured.out)

            main(["--base-dir", tmp, "renew", cert_id])
            captured = capsys.readouterr()
            assert "Renewed" in captured.out
            assert "Lineage:" in captured.out

    def test_list_command(self, capsys):
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "agent-1",
                "--archetype", "arch",
                "--org", "org",
            ])
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "agent-2",
                "--archetype", "arch",
                "--org", "org",
            ])
            capsys.readouterr()  # Clear output

            main(["--base-dir", tmp, "list"])
            captured = capsys.readouterr()
            assert "agent-1" in captured.out
            assert "agent-2" in captured.out

    def test_reputation_command(self, capsys):
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "agent-1",
                "--archetype", "arch",
                "--org", "org",
            ])
            captured = capsys.readouterr()
            cert_id = _extract_cert_id(captured.out)

            main(["--base-dir", tmp, "reputation", cert_id])
            captured = capsys.readouterr()
            assert "Trust Score:" in captured.out
            assert "Behavioral Age:" in captured.out

    def test_sequential_ids(self, capsys):
        """Birth commands should assign sequential IDs starting at 1000."""
        with tempfile.TemporaryDirectory() as tmp:
            main(["--base-dir", tmp, "birth", "--name", "a", "--archetype", "arch", "--org", "org"])
            out1 = capsys.readouterr().out
            assert "ID:          1000" in out1

            main(["--base-dir", tmp, "birth", "--name", "b", "--archetype", "arch", "--org", "org"])
            out2 = capsys.readouterr().out
            assert "ID:          1001" in out2

    def test_no_command_shows_help(self, capsys):
        import pytest
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(SystemExit) as exc_info:
                main(["--base-dir", tmp])
            assert exc_info.value.code == 0
            captured = capsys.readouterr()
            assert "nomotic" in captured.out.lower() or "usage" in captured.out.lower()

    def test_birth_with_config_defaults(self, capsys):
        """Birth with --name and --archetype should use config defaults."""
        with tempfile.TemporaryDirectory() as tmp:
            # Write a config file manually (simulates 'nomotic setup')
            config = {
                "organization": "acme-insurance",
                "owner": "chris@acme.com",
                "default_zone": "us/production",
                "retention": "5y",
                "enforce_unique_names": False,
            }
            config_path = Path(tmp) / "config.json"
            config_path.write_text(json.dumps(config), encoding="utf-8")

            main(["--base-dir", tmp, "birth", "--name", "ChrisBot", "--archetype", "customer-experience"])
            captured = capsys.readouterr()
            assert "Agent created:" in captured.out
            assert "ChrisBot" in captured.out
            assert "acme-insurance" in captured.out
            assert "chris@acme.com" in captured.out
            assert "us/production" in captured.out
            assert "customer-experience" in captured.out

    def test_birth_without_config_or_org_fails(self, capsys):
        """Birth without config and without --org should fail."""
        import pytest
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(SystemExit):
                main(["--base-dir", tmp, "birth", "--name", "test-agent", "--archetype", "customer-experience"])
            captured = capsys.readouterr()
            assert "not configured" in captured.err.lower() or "Run 'nomotic setup'" in captured.err

    def test_birth_normalizes_inputs(self, capsys):
        """Archetype, org, and zone should be lowercased automatically."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "test-agent",
                "--archetype", "Customer-Experience",
                "--org", "ACME",
                "--zone", "Global",
            ])
            captured = capsys.readouterr()
            assert "customer-experience" in captured.out
            assert "acme" in captured.out
            assert "global" in captured.out

    def test_birth_next_steps_shown(self, capsys):
        """Birth should show next steps."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "my-agent",
                "--archetype", "customer-experience",
                "--org", "org",
            ])
            captured = capsys.readouterr()
            assert "Next steps:" in captured.out
            assert "nomotic scope" in captured.out


class TestScopeCommand:
    """Tests for 'nomotic scope set' and 'nomotic scope show'."""

    def test_scope_set_and_show(self, capsys):
        """scope set configures agent, scope show displays it."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth", "--name", "scope-agent",
                "--archetype", "general", "--org", "org",
            ])
            capsys.readouterr()  # discard birth output

            main([
                "--base-dir", tmp,
                "scope", "scope-agent", "set",
                "--actions", "read,write",
                "--boundaries", "db.users,db.orders",
            ])
            captured = capsys.readouterr()
            assert "Scope configured" in captured.out
            assert "read" in captured.out
            assert "write" in captured.out
            assert "Authority Envelope" in captured.out
            assert "db.users" in captured.out
            assert "db.orders" in captured.out

    def test_scope_show(self, capsys):
        """scope show displays configured scope."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth", "--name", "show-agent",
                "--archetype", "general", "--org", "org",
            ])
            capsys.readouterr()

            main([
                "--base-dir", tmp,
                "scope", "show-agent", "set",
                "--actions", "query",
                "--boundaries", "api.public",
            ])
            capsys.readouterr()

            main([
                "--base-dir", tmp,
                "scope", "show-agent", "show",
            ])
            captured = capsys.readouterr()
            assert "Authority Envelope" in captured.out
            assert "query" in captured.out
            assert "api.public" in captured.out

    def test_scope_show_no_config(self, capsys):
        """scope show exits 1 when no config exists."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth", "--name", "no-scope",
                "--archetype", "general", "--org", "org",
            ])
            capsys.readouterr()

            with pytest.raises(SystemExit) as exc_info:
                main([
                    "--base-dir", tmp,
                    "scope", "no-scope", "show",
                ])
            assert exc_info.value.code == 1
            captured = capsys.readouterr()
            assert "No configuration found" in captured.err


class TestAuthorityRegistryCommand:
    """Tests for 'nomotic authority-registry' subcommands."""

    def test_authority_registry_list_empty(self, capsys):
        """authority-registry list with no registry shows empty state."""
        with tempfile.TemporaryDirectory() as tmp:
            main(["--base-dir", tmp, "authority-registry", "list"])
            captured = capsys.readouterr()
            assert "No governance authorities registered" in captured.out

    def test_authority_registry_bootstrap_and_list(self, capsys):
        """Bootstrap creates authority, list shows it."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "authority-registry", "bootstrap",
                "--name", "Admin Authority",
            ])
            captured = capsys.readouterr()
            assert "Bootstrapped governance authority registry" in captured.out

            main(["--base-dir", tmp, "authority-registry", "list"])
            captured = capsys.readouterr()
            assert "Admin Authority" in captured.out

    def test_authority_registry_history_empty(self, capsys):
        """authority-registry history with no history shows message."""
        with tempfile.TemporaryDirectory() as tmp:
            main(["--base-dir", tmp, "authority-registry", "history"])
            captured = capsys.readouterr()
            assert "No governance change history" in captured.out

    def test_authority_registry_history_with_filter(self, capsys):
        """authority-registry history --authority filters correctly."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "authority-registry", "history",
                "--authority", "nma-nonexistent",
            ])
            captured = capsys.readouterr()
            assert "No governance change history" in captured.out


class TestPolicyValidateCommand:
    """Tests for 'nomotic policy-validate'."""

    def test_policy_validate_no_policies(self, capsys):
        """policy-validate with empty dir shows no-policies message."""
        with tempfile.TemporaryDirectory() as tmp:
            policy_dir = Path(tmp) / "policies"
            policy_dir.mkdir()

            with pytest.raises(SystemExit) as exc_info:
                main([
                    "--base-dir", tmp,
                    "policy-validate",
                    "--dir", str(policy_dir),
                ])
            assert exc_info.value.code == 0
            captured = capsys.readouterr()
            assert "No policies loaded" in captured.out

    def test_policy_validate_valid_policy(self, capsys):
        """policy-validate with a valid policy shows it."""
        with tempfile.TemporaryDirectory() as tmp:
            policy_dir = Path(tmp) / "policies"
            policy_dir.mkdir()
            policy_file = policy_dir / "test-policy.json"
            policy_file.write_text(json.dumps({
                "name": "deny-delete",
                "description": "Block all delete actions",
                "priority": 100,
                "enabled": True,
                "when": {"action_type": "delete"},
                "then": {"verdict": "DENY", "reason": "Deletes not allowed"},
            }), encoding="utf-8")

            main([
                "--base-dir", tmp,
                "policy-validate",
                "--dir", str(policy_dir),
            ])
            captured = capsys.readouterr()
            assert "deny-delete" in captured.out
            assert "All policies valid" in captured.out

    def test_policy_validate_json_output(self, capsys):
        """policy-validate --json outputs JSON."""
        with tempfile.TemporaryDirectory() as tmp:
            policy_dir = Path(tmp) / "policies"
            policy_dir.mkdir()
            policy_file = policy_dir / "test-policy.json"
            policy_file.write_text(json.dumps({
                "name": "test-rule",
                "priority": 50,
                "enabled": True,
                "when": {"action_type": "read"},
                "then": {"verdict": "DENY", "reason": "No reads"},
            }), encoding="utf-8")

            with pytest.raises(SystemExit) as exc_info:
                main([
                    "--base-dir", tmp,
                    "policy-validate",
                    "--dir", str(policy_dir),
                    "--json",
                ])
            assert exc_info.value.code == 0
            captured = capsys.readouterr()
            data = json.loads(captured.out)
            assert data["valid"] is True
            assert data["policies_loaded"] >= 1

    def test_policy_validate_dry_run(self, capsys):
        """policy-validate --dry-run runs against audit history."""
        with tempfile.TemporaryDirectory() as tmp:
            policy_dir = Path(tmp) / "policies"
            policy_dir.mkdir()
            policy_file = policy_dir / "deny-transfers.json"
            policy_file.write_text(json.dumps({
                "name": "deny-transfers",
                "priority": 100,
                "enabled": True,
                "when": {"action_type": "transfer"},
                "then": {"verdict": "DENY", "reason": "No transfers"},
            }), encoding="utf-8")

            main([
                "--base-dir", tmp,
                "policy-validate",
                "--dir", str(policy_dir),
                "--dry-run",
                "--days", "1",
            ])
            captured = capsys.readouterr()
            assert "Policy Dry-Run" in captured.out
            assert "deny-transfers" in captured.out

    def test_policy_validate_dry_run_with_override_sim(self, capsys):
        """policy-validate --dry-run --override-sim parses override params."""
        with tempfile.TemporaryDirectory() as tmp:
            policy_dir = Path(tmp) / "policies"
            policy_dir.mkdir()
            (policy_dir / "deny-deletes.json").write_text(json.dumps({
                "name": "deny-deletes",
                "priority": 100,
                "enabled": True,
                "when": {"action_type": "delete"},
                "then": {"verdict": "DENY", "reason": "No deletes"},
            }), encoding="utf-8")

            main([
                "--base-dir", tmp,
                "policy-validate",
                "--dir", str(policy_dir),
                "--dry-run",
                "--days", "1",
                "--override-sim", "authority=ops-team,override_type=ALLOW_ANYWAY",
            ])
            captured = capsys.readouterr()
            assert "Policy Dry-Run" in captured.out

    def test_policy_validate_dry_run_override_sim_missing_authority(self, capsys):
        """--override-sim without authority key exits 1."""
        with tempfile.TemporaryDirectory() as tmp:
            policy_dir = Path(tmp) / "policies"
            policy_dir.mkdir()
            (policy_dir / "deny-deletes.json").write_text(json.dumps({
                "name": "deny-deletes",
                "priority": 100,
                "enabled": True,
                "when": {"action_type": "delete"},
                "then": {"verdict": "DENY", "reason": "No deletes"},
            }), encoding="utf-8")

            with pytest.raises(SystemExit) as exc_info:
                main([
                    "--base-dir", tmp,
                    "policy-validate",
                    "--dir", str(policy_dir),
                    "--dry-run",
                    "--days", "1",
                    "--override-sim", "override_type=ALLOW_ANYWAY",
                ])
            assert exc_info.value.code == 1
            captured = capsys.readouterr()
            assert "authority" in captured.out


class TestRolesCommand:
    """Tests for 'nomotic roles' subcommands."""

    def test_roles_show(self, capsys, tmp_path):
        """roles show displays role details."""
        roles_file = tmp_path / "nomotic-roles.json"
        roles_file.write_text(json.dumps({
            "roles": [{
                "name": "Incident Commander",
                "role_id": "incident-commander",
                "authorities": ["ops-team"],
                "permitted_override_types": ["ALLOW_ANYWAY"],
                "permitted_zones": ["global"],
                "permitted_archetypes": ["*"],
                "permitted_action_types": ["read", "write"],
                "max_risk_tier": 3,
            }]
        }), encoding="utf-8")

        main([
            "--roles-file", str(roles_file),
            "roles", "show", "incident-commander",
        ])
        captured = capsys.readouterr()
        assert "Incident Commander" in captured.out
        assert "incident-commander" in captured.out
        assert "ops-team" in captured.out

    def test_roles_show_not_found(self, capsys, tmp_path):
        """roles show with unknown role exits 1."""
        roles_file = tmp_path / "nomotic-roles.json"
        roles_file.write_text(json.dumps({
            "roles": [{
                "name": "Admin",
                "role_id": "admin",
                "authorities": ["admin-team"],
                "permitted_override_types": ["ALLOW_ANYWAY"],
            }]
        }), encoding="utf-8")

        with pytest.raises(SystemExit) as exc_info:
            main([
                "--roles-file", str(roles_file),
                "roles", "show", "nonexistent",
            ])
        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        assert "not found" in captured.out

    def test_roles_list(self, capsys, tmp_path):
        """roles list shows all configured roles."""
        roles_file = tmp_path / "nomotic-roles.json"
        roles_file.write_text(json.dumps({
            "roles": [
                {
                    "name": "Admin",
                    "role_id": "admin",
                    "authorities": ["admin-team"],
                    "permitted_override_types": ["ALLOW_ANYWAY"],
                },
                {
                    "name": "Reviewer",
                    "role_id": "reviewer",
                    "authorities": ["review-team"],
                    "permitted_override_types": ["ESCALATE_INSTEAD"],
                },
            ]
        }), encoding="utf-8")

        main([
            "--roles-file", str(roles_file),
            "roles", "list",
        ])
        captured = capsys.readouterr()
        assert "Admin" in captured.out
        assert "Reviewer" in captured.out
