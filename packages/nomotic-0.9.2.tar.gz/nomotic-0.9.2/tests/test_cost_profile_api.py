"""Tests for Cost Profile API endpoints."""

from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request
from typing import Any

import pytest

from nomotic.api import NomoticAPIServer
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.store import MemoryCertificateStore


# ── Test fixtures ───────────────────────────────────────────────────────


def _find_free_port() -> int:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class APITestClient:
    """Minimal HTTP client for testing the API."""

    def __init__(self, base_url: str) -> None:
        self.base_url = base_url

    def get(self, path: str) -> tuple[int, dict[str, Any]]:
        url = f"{self.base_url}{path}"
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req) as resp:
                body = json.loads(resp.read())
                return resp.status, body
        except urllib.error.HTTPError as e:
            body = json.loads(e.read())
            return e.code, body

    def post(self, path: str, data: dict[str, Any] | None = None) -> tuple[int, dict[str, Any]]:
        url = f"{self.base_url}{path}"
        payload = json.dumps(data or {}).encode("utf-8")
        try:
            req = urllib.request.Request(
                url, data=payload, method="POST",
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req) as resp:
                body = json.loads(resp.read())
                return resp.status, body
        except urllib.error.HTTPError as e:
            body = json.loads(e.read())
            return e.code, body


@pytest.fixture(scope="module")
def api_server() -> tuple[APITestClient, CertificateAuthority]:
    """Start a test API server and return a client + the CA."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)
    arch_reg = ArchetypeRegistry.with_defaults()
    zone_val = ZoneValidator()
    org_reg = OrganizationRegistry()

    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        archetype_registry=arch_reg,
        zone_validator=zone_val,
        org_registry=org_reg,
        host="127.0.0.1",
        port=port,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.3)

    client = APITestClient(f"http://127.0.0.1:{port}")
    yield client, ca
    server.shutdown()


# ═══════════════════════════════════════════════════════════════════════
# GET /v1/cost-profiles/{agent_id}
# ═══════════════════════════════════════════════════════════════════════


class TestCostProfileAgent:
    def test_get_cost_profile_returns_correct_structure(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.get("/v1/cost-profiles/agent-test-001")
        assert status == 200
        assert body["agent_id"] == "agent-test-001"
        assert "cost_profile" in body
        assert "derived_thresholds" in body
        assert "static_defaults" in body
        assert "threshold_history" in body
        assert "timestamp" in body

    def test_cost_profile_has_expected_fields(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.get("/v1/cost-profiles/agent-test-002")
        assert status == 200
        cp = body["cost_profile"]
        assert "false_allow_cost" in cp
        assert "false_deny_cost" in cp
        assert "false_allow_label" in cp
        assert "false_deny_label" in cp
        assert "zone_multiplier" in cp

    def test_derived_thresholds_structure(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.get("/v1/cost-profiles/agent-test-003")
        assert status == 200
        dt = body["derived_thresholds"]
        assert "allow_threshold" in dt
        assert "deny_threshold" in dt
        assert "ambiguity_zone_width" in dt
        assert "source" in dt
        assert dt["allow_threshold"] > dt["deny_threshold"]

    def test_static_defaults_present(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.get("/v1/cost-profiles/agent-test-004")
        assert status == 200
        sd = body["static_defaults"]
        assert sd["allow_threshold"] == 0.7
        assert sd["deny_threshold"] == 0.3


# ═══════════════════════════════════════════════════════════════════════
# GET /v1/cost-profiles/summary
# ═══════════════════════════════════════════════════════════════════════


class TestCostProfileSummary:
    def test_summary_returns_correct_structure(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.get("/v1/cost-profiles/summary")
        assert status == 200
        assert "total_agents" in body
        assert "cost_level_distribution" in body
        assert "cost_levels" in body
        assert "timestamp" in body

    def test_summary_cost_levels_present(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.get("/v1/cost-profiles/summary")
        assert status == 200
        levels = body["cost_levels"]
        assert "LOW" in levels
        assert "MODERATE" in levels
        assert "HIGH" in levels
        assert "CRITICAL" in levels

    def test_summary_distribution_has_all_levels(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.get("/v1/cost-profiles/summary")
        assert status == 200
        dist = body["cost_level_distribution"]
        for level in ["LOW", "MODERATE", "HIGH", "CRITICAL"]:
            assert level in dist

    def test_summary_empty_fleet(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        """With no runtime, total_agents should be 0."""
        client, _ca = api_server
        status, body = client.get("/v1/cost-profiles/summary")
        assert status == 200
        assert body["total_agents"] == 0


# ═══════════════════════════════════════════════════════════════════════
# POST /v1/cost-profiles/simulate
# ═══════════════════════════════════════════════════════════════════════


class TestCostProfileSimulate:
    def test_simulate_returns_thresholds(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.post("/v1/cost-profiles/simulate", {
            "agent_id": "sim-agent",
            "cost_profile": {
                "false_allow_cost": 0.6,
                "false_deny_cost": 0.1,
            },
        })
        assert status == 200
        assert body["agent_id"] == "sim-agent"
        assert "simulated_thresholds" in body
        st = body["simulated_thresholds"]
        assert "allow_threshold" in st
        assert "deny_threshold" in st
        assert st["allow_threshold"] > st["deny_threshold"]

    def test_simulate_missing_cost_profile(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.post("/v1/cost-profiles/simulate", {
            "agent_id": "sim-agent",
        })
        assert status == 400
        assert body["error"] == "missing_field"

    def test_simulate_default_agent_id(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.post("/v1/cost-profiles/simulate", {
            "cost_profile": {
                "false_allow_cost": 0.3,
                "false_deny_cost": 0.3,
            },
        })
        assert status == 200
        assert body["agent_id"] == "simulated-agent"

    def test_simulate_conservative_profile(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        """CRITICAL false_allow + LOW false_deny = lower allow threshold."""
        client, _ca = api_server
        status, body = client.post("/v1/cost-profiles/simulate", {
            "cost_profile": {
                "false_allow_cost": 1.0,
                "false_deny_cost": 0.1,
            },
        })
        assert status == 200
        st = body["simulated_thresholds"]
        # With high false_allow cost, the system should be more conservative
        assert st["allow_threshold"] < 0.5

    def test_simulate_permissive_profile(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        """LOW false_allow + HIGH false_deny = higher allow threshold."""
        client, _ca = api_server
        status, body = client.post("/v1/cost-profiles/simulate", {
            "cost_profile": {
                "false_allow_cost": 0.1,
                "false_deny_cost": 0.6,
            },
        })
        assert status == 200
        st = body["simulated_thresholds"]
        # With high false_deny cost, the system should allow more
        assert st["allow_threshold"] > 0.5

    def test_simulate_static_defaults_present(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.post("/v1/cost-profiles/simulate", {
            "cost_profile": {"false_allow_cost": 0.5, "false_deny_cost": 0.5},
        })
        assert status == 200
        assert body["static_defaults"]["allow_threshold"] == 0.7
        assert body["static_defaults"]["deny_threshold"] == 0.3
