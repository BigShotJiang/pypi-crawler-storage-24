"""Tests for the BehaviorLedger — complete decision reconstruction system."""

from __future__ import annotations

import time
from dataclasses import replace
from unittest import TestCase

from nomotic.behavior_ledger import (
    ActionToPass,
    BehaviorLedgerEntry,
    BehaviorLedgerStore,
    CausalLink,
    ContractSnapshot,
    PipelineStep,
    PipelineTracer,
    SemanticContext,
    build_ledger_entry,
)
from nomotic.contract import BehavioralContract, ContractStore
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import Action, AgentContext, TrustProfile, Verdict


def _action(
    action_type: str = "read",
    target: str = "/data",
    agent_id: str = "agent-1",
) -> Action:
    return Action(agent_id=agent_id, action_type=action_type, target=target)


def _ctx(agent_id: str = "agent-1", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


# ── PipelineStep ────────────────────────────────────────────────────


class TestPipelineStep(TestCase):
    """Tests for PipelineStep dataclass."""

    def test_creation_and_serialization(self) -> None:
        step = PipelineStep(
            step_id="trust_decay",
            description="Applied time decay to trust profile",
            timestamp_offset_ms=1.234,
            input_state={"trust_before": 0.73},
            output_state={"trust_after": 0.72, "decay_applied": True},
        )
        d = step.to_dict()
        self.assertEqual(d["step_id"], "trust_decay")
        self.assertEqual(d["description"], "Applied time decay to trust profile")
        self.assertAlmostEqual(d["timestamp_offset_ms"], 1.234)
        self.assertEqual(d["input_state"]["trust_before"], 0.73)
        self.assertEqual(d["output_state"]["trust_after"], 0.72)
        self.assertTrue(d["output_state"]["decay_applied"])
        self.assertEqual(d["decision"], "")
        self.assertFalse(d["decided_verdict"])

        # Roundtrip
        step2 = PipelineStep.from_dict(d)
        self.assertEqual(step2.step_id, step.step_id)
        self.assertEqual(step2.description, step.description)

    def test_decided_flag(self) -> None:
        step = PipelineStep(
            step_id="tier1",
            description="Tier 1 — DECIDED",
            timestamp_offset_ms=5.0,
            decision="veto_deny",
            decided_verdict=True,
        )
        self.assertTrue(step.decided_verdict)
        self.assertEqual(step.decision, "veto_deny")


# ── PipelineTracer ──────────────────────────────────────────────────


class TestPipelineTracer(TestCase):
    """Tests for PipelineTracer collector."""

    def test_empty_tracer(self) -> None:
        tracer = PipelineTracer()
        result = tracer.finalize()
        self.assertEqual(result, ())
        self.assertIsInstance(result, tuple)

    def test_record_multiple_steps(self) -> None:
        tracer = PipelineTracer()
        for i in range(5):
            tracer.record(
                step_id=f"step_{i}",
                description=f"Step {i}",
                input_state={"i": i},
                output_state={"result": i * 2},
            )
        result = tracer.finalize()
        self.assertEqual(len(result), 5)
        self.assertIsInstance(result, tuple)
        self.assertEqual(result[0].step_id, "step_0")
        self.assertEqual(result[4].step_id, "step_4")

    def test_timestamp_offsets_increase(self) -> None:
        tracer = PipelineTracer()
        for i in range(3):
            tracer.record(
                step_id=f"step_{i}",
                description=f"Step {i}",
                input_state={},
                output_state={},
            )
        result = tracer.finalize()
        for i in range(1, len(result)):
            self.assertGreaterEqual(
                result[i].timestamp_offset_ms,
                result[i - 1].timestamp_offset_ms,
            )


# ── ContractSnapshot ────────────────────────────────────────────────


class TestContractSnapshot(TestCase):
    """Tests for ContractSnapshot frozen dataclass."""

    def test_from_contract(self) -> None:
        contract = BehavioralContract(
            contract_id="c-123",
            version=3,
            agent_id="agent-1",
            created_at=time.time(),
            archetype="executor",
            drift_thresholds={"action": 0.2, "target": 0.3},
            invariants=[
                {"id": "inv-1", "type": "metric_bound", "metric": "trust_score", "threshold": 0.3},
            ],
            semantic_anchors=[{"term": "read"}, {"term": "write"}],
        )
        snap = ContractSnapshot(
            contract_id=contract.contract_id,
            version=contract.version,
            archetype=contract.archetype,
            drift_thresholds=dict(contract.drift_thresholds),
            invariant_count=len(contract.invariants),
            invariant_specs_summary=(("inv-1", "metric_bound", "trust_score", "0.3"),),
            semantic_anchor_terms=("read", "write"),
        )
        self.assertEqual(snap.contract_id, "c-123")
        self.assertEqual(snap.version, 3)
        self.assertEqual(snap.archetype, "executor")
        self.assertEqual(snap.invariant_count, 1)
        self.assertEqual(snap.semantic_anchor_terms, ("read", "write"))

        # Roundtrip
        d = snap.to_dict()
        snap2 = ContractSnapshot.from_dict(d)
        self.assertEqual(snap2.contract_id, snap.contract_id)
        self.assertEqual(snap2.version, snap.version)

    def test_empty_snapshot(self) -> None:
        snap = ContractSnapshot()
        self.assertEqual(snap.contract_id, "")
        self.assertEqual(snap.version, 0)
        self.assertEqual(snap.invariant_count, 0)
        d = snap.to_dict()
        self.assertEqual(d["contract_id"], "")


# ── SemanticContext ─────────────────────────────────────────────────


class TestSemanticContext(TestCase):
    """Tests for SemanticContext frozen dataclass."""

    def test_with_instruction_context(self) -> None:
        sc = SemanticContext(
            instruction_context="Process customer records",
            matched_anchor_terms=("read", "query"),
            per_term_drift={"read": 0.05, "query": 0.12},
            aggregate_semantic_drift=0.085,
            most_drifted_term="query",
        )
        self.assertEqual(sc.instruction_context, "Process customer records")
        self.assertEqual(sc.matched_anchor_terms, ("read", "query"))
        self.assertAlmostEqual(sc.aggregate_semantic_drift, 0.085)
        d = sc.to_dict()
        sc2 = SemanticContext.from_dict(d)
        self.assertEqual(sc2.most_drifted_term, "query")

    def test_empty_context(self) -> None:
        sc = SemanticContext()
        self.assertEqual(sc.instruction_context, "")
        self.assertEqual(sc.aggregate_semantic_drift, 0.0)


# ── CausalLink ──────────────────────────────────────────────────────


class TestCausalLink(TestCase):
    """Tests for CausalLink frozen dataclass."""

    def test_trust_change_link(self) -> None:
        cl = CausalLink(
            previous_entry_id="abc123",
            influence_type="trust_change",
            influence_description="Decision #5 changed trust from 0.71 to 0.72 (+0.01)",
            trust_delta=0.01,
        )
        self.assertEqual(cl.previous_entry_id, "abc123")
        self.assertEqual(cl.influence_type, "trust_change")
        self.assertAlmostEqual(cl.trust_delta, 0.01)

    def test_serialization(self) -> None:
        cl = CausalLink(
            previous_entry_id="xyz789",
            influence_type="drift_contribution",
            influence_description="Previous action increased action drift",
            trust_delta=-0.02,
        )
        d = cl.to_dict()
        cl2 = CausalLink.from_dict(d)
        self.assertEqual(cl2.previous_entry_id, cl.previous_entry_id)
        self.assertEqual(cl2.influence_type, cl.influence_type)
        self.assertAlmostEqual(cl2.trust_delta, cl.trust_delta)


# ── ActionToPass ────────────────────────────────────────────────────


class TestActionToPass(TestCase):
    """Tests for ActionToPass frozen dataclass."""

    def test_deny_gaps(self) -> None:
        atp = ActionToPass(
            current_verdict="DENY",
            dimension_gaps={"scope_compliance": 0.45, "authority_level": 0.2},
            ucs_needed=0.7,
            ucs_gap=0.35,
            detail="UCS 0.35 below allow threshold 0.70",
        )
        self.assertEqual(atp.current_verdict, "DENY")
        self.assertEqual(len(atp.dimension_gaps), 2)
        self.assertAlmostEqual(atp.ucs_gap, 0.35)
        d = atp.to_dict()
        atp2 = ActionToPass.from_dict(d)
        self.assertEqual(atp2.dimension_gaps, atp.dimension_gaps)

    def test_allow_margin(self) -> None:
        atp = ActionToPass(
            current_verdict="ALLOW",
            margin_to_deny=0.547,
            closest_veto_dimension="scope_compliance",
            closest_veto_margin=0.85,
        )
        self.assertEqual(atp.current_verdict, "ALLOW")
        self.assertAlmostEqual(atp.margin_to_deny, 0.547)
        self.assertEqual(atp.closest_veto_dimension, "scope_compliance")


# ── BehaviorLedgerEntry ─────────────────────────────────────────────


class TestBehaviorLedgerEntry(TestCase):
    """Tests for BehaviorLedgerEntry frozen dataclass."""

    def _make_entry(self, **overrides: object) -> BehaviorLedgerEntry:
        defaults = dict(
            entry_id="abc12345",
            timestamp=1709827200.0,
            sequence_number=42,
            agent_id="agent-1",
            action_type="read",
            action_target="/data",
            verdict="ALLOW",
            ucs=0.847,
            tier=2,
            reasoning="UCS above threshold",
            dimension_scores=(
                {"name": "scope_compliance", "score": 0.9, "weight": 1.3, "veto": False, "reasoning": "In scope"},
                {"name": "authority_level", "score": 0.8, "weight": 1.0, "veto": False, "reasoning": "OK"},
            ),
            pipeline_trace=(
                PipelineStep(step_id="trust_decay", description="Decay", timestamp_offset_ms=0.1,
                             input_state={"trust_before": 0.5}, output_state={"trust_after": 0.5}),
                PipelineStep(step_id="dimension_eval", description="Eval", timestamp_offset_ms=0.5,
                             input_state={}, output_state={"dimension_count": 14}),
                PipelineStep(step_id="tier2", description="Tier 2", timestamp_offset_ms=1.0,
                             decision="allow", decided_verdict=True),
            ),
            fingerprint_confidence=0.94,
            fingerprint_observations=847,
            trust_score=0.72,
            trust_direction="rising",
            action_to_pass=ActionToPass(
                current_verdict="ALLOW",
                margin_to_deny=0.547,
                closest_veto_dimension="scope_compliance",
                closest_veto_margin=0.9,
            ),
        )
        defaults.update(overrides)
        return BehaviorLedgerEntry(**defaults)  # type: ignore[arg-type]

    def test_creation_with_all_fields(self) -> None:
        entry = self._make_entry()
        self.assertEqual(entry.entry_id, "abc12345")
        self.assertEqual(entry.agent_id, "agent-1")
        self.assertEqual(entry.verdict, "ALLOW")
        self.assertAlmostEqual(entry.ucs, 0.847)
        self.assertEqual(entry.tier, 2)
        self.assertEqual(len(entry.dimension_scores), 2)
        self.assertEqual(len(entry.pipeline_trace), 3)
        self.assertAlmostEqual(entry.fingerprint_confidence, 0.94)
        self.assertIsNotNone(entry.action_to_pass)

    def test_serialization_roundtrip(self) -> None:
        entry = self._make_entry(
            contract=ContractSnapshot(contract_id="c-1", version=2, archetype="executor"),
            semantic=SemanticContext(instruction_context="test"),
            causal_links=(
                CausalLink(previous_entry_id="prev1", influence_type="trust_change",
                           influence_description="test", trust_delta=0.01),
            ),
        )
        d = entry.to_dict()
        entry2 = BehaviorLedgerEntry.from_dict(d)
        self.assertEqual(entry2.entry_id, entry.entry_id)
        self.assertEqual(entry2.agent_id, entry.agent_id)
        self.assertEqual(entry2.verdict, entry.verdict)
        self.assertAlmostEqual(entry2.ucs, entry.ucs, places=3)
        self.assertEqual(entry2.tier, entry.tier)
        self.assertEqual(len(entry2.dimension_scores), 2)
        self.assertEqual(len(entry2.pipeline_trace), 3)
        self.assertEqual(entry2.pipeline_trace[0].step_id, "trust_decay")
        self.assertIsNotNone(entry2.contract)
        self.assertEqual(entry2.contract.contract_id, "c-1")  # type: ignore[union-attr]
        self.assertIsNotNone(entry2.semantic)
        self.assertEqual(len(entry2.causal_links), 1)
        self.assertIsNotNone(entry2.action_to_pass)

    def test_hash_computation(self) -> None:
        entry = self._make_entry()
        h1 = entry.compute_hash()
        h2 = entry.compute_hash()
        self.assertEqual(h1, h2)
        self.assertEqual(len(h1), 64)  # SHA-256 hex

    def test_hash_chain(self) -> None:
        entry1 = self._make_entry(entry_id="e1", sequence_number=0)
        h1 = entry1.compute_hash()
        entry1 = replace(entry1, entry_hash=h1)

        entry2 = self._make_entry(
            entry_id="e2", sequence_number=1, previous_entry_hash=h1,
        )
        h2 = entry2.compute_hash()
        self.assertNotEqual(h1, h2)

    def test_summary(self) -> None:
        entry = self._make_entry()
        s = entry.summary()
        self.assertIn("agent-1", s)
        self.assertIn("ALLOW", s)
        self.assertIn("Tier 2", s)
        self.assertIn("UCS 0.847", s)
        self.assertIsInstance(s, str)
        self.assertGreater(len(s), 50)

    def test_narrative(self) -> None:
        entry = self._make_entry()
        n = entry.narrative()
        self.assertIn("GOVERNANCE DECISION RECORD", n)
        self.assertIn("PIPELINE TRACE", n)
        self.assertIn("BEHAVIORAL STATE", n)
        self.assertIn("Decay", n)
        self.assertIn("SAFETY MARGIN", n)
        self.assertGreater(len(n), 200)


# ── BehaviorLedgerStore ─────────────────────────────────────────────


class TestBehaviorLedgerStore(TestCase):
    """Tests for BehaviorLedgerStore."""

    def _make_entry(
        self, agent_id: str = "agent-1", verdict: str = "ALLOW", **kw: object,
    ) -> BehaviorLedgerEntry:
        import uuid

        defaults = dict(
            entry_id=uuid.uuid4().hex[:12],
            timestamp=time.time(),
            agent_id=agent_id,
            verdict=verdict,
            ucs=0.8 if verdict == "ALLOW" else 0.2,
            tier=2,
        )
        defaults.update(kw)
        return BehaviorLedgerEntry(**defaults)  # type: ignore[arg-type]

    def test_append_and_get(self) -> None:
        store = BehaviorLedgerStore()
        entry = self._make_entry()
        result = store.append(entry)
        self.assertEqual(result.sequence_number, 0)
        self.assertNotEqual(result.entry_hash, "")

        retrieved = store.get("agent-1", 0)
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.entry_id, entry.entry_id)  # type: ignore[union-attr]

    def test_get_latest(self) -> None:
        store = BehaviorLedgerStore()
        e1 = store.append(self._make_entry())
        e2 = store.append(self._make_entry())
        e3 = store.append(self._make_entry())
        latest = store.get_latest("agent-1")
        self.assertIsNotNone(latest)
        self.assertEqual(latest.sequence_number, 2)  # type: ignore[union-attr]

    def test_query_by_verdict(self) -> None:
        store = BehaviorLedgerStore()
        store.append(self._make_entry(verdict="ALLOW"))
        store.append(self._make_entry(verdict="DENY"))
        store.append(self._make_entry(verdict="ALLOW"))
        store.append(self._make_entry(verdict="DENY"))
        store.append(self._make_entry(verdict="ALLOW"))

        denials = store.query(agent_id="agent-1", verdict="DENY")
        self.assertEqual(len(denials), 2)
        for e in denials:
            self.assertEqual(e.verdict, "DENY")

    def test_query_by_time_range(self) -> None:
        store = BehaviorLedgerStore()
        now = time.time()
        store.append(self._make_entry(timestamp=now - 100))
        store.append(self._make_entry(timestamp=now - 50))
        store.append(self._make_entry(timestamp=now))

        results = store.query(agent_id="agent-1", since=now - 60, until=now + 1)
        self.assertEqual(len(results), 2)

    def test_hash_chain_integrity(self) -> None:
        store = BehaviorLedgerStore()
        for _ in range(5):
            store.append(self._make_entry())

        valid, error = store.verify_chain("agent-1")
        self.assertTrue(valid)
        self.assertEqual(error, "")

    def test_hash_chain_tamper_detected(self) -> None:
        store = BehaviorLedgerStore()
        for _ in range(3):
            store.append(self._make_entry())

        # Tamper with the middle entry
        entries = store._entries["agent-1"]
        tampered = replace(entries[1], verdict="TAMPERED")
        entries[1] = tampered

        valid, error = store.verify_chain("agent-1")
        self.assertFalse(valid)
        self.assertIn("entry_hash mismatch", error)

    def test_causal_chain_walk(self) -> None:
        store = BehaviorLedgerStore()
        e1 = store.append(self._make_entry())
        e2 = store.append(
            self._make_entry(
                causal_links=(
                    CausalLink(
                        previous_entry_id=e1.entry_id,
                        influence_type="trust_change",
                        influence_description="test",
                        trust_delta=0.01,
                    ),
                ),
            )
        )
        e3 = store.append(
            self._make_entry(
                causal_links=(
                    CausalLink(
                        previous_entry_id=e2.entry_id,
                        influence_type="trust_change",
                        influence_description="test 2",
                        trust_delta=0.02,
                    ),
                ),
            )
        )
        chain = store.get_causal_chain(e3.entry_id, depth=10)
        self.assertEqual(len(chain), 3)
        self.assertEqual(chain[0].entry_id, e3.entry_id)
        self.assertEqual(chain[1].entry_id, e2.entry_id)
        self.assertEqual(chain[2].entry_id, e1.entry_id)

    def test_sequence_numbers_increment(self) -> None:
        store = BehaviorLedgerStore()
        for i in range(5):
            result = store.append(self._make_entry())
            self.assertEqual(result.sequence_number, i)


# ── build_ledger_entry (integration with GovernanceRuntime) ─────────


class TestBuildLedgerEntry(TestCase):
    """Integration tests: build_ledger_entry with real runtime."""

    def _runtime(self, **kw: object) -> GovernanceRuntime:
        defaults = dict(
            enable_behavior_ledger=True,
            enable_fingerprints=True,
            enable_audit=False,
            enable_contextual_modifier=False,
            enable_workflow_governor=False,
            enable_equity_analysis=False,
            enable_bias_detection=False,
            enable_cross_dimensional=True,
            enable_contracts=True,
        )
        defaults.update(kw)
        return GovernanceRuntime(RuntimeConfig(**defaults))  # type: ignore[arg-type]

    def test_full_assembly(self) -> None:
        runtime = self._runtime()
        scope_dim = runtime.registry.get("scope_compliance")
        if scope_dim:
            scope_dim.configure_agent_scope("agent-1", {"read"})

        action = _action(action_type="read", target="/data")
        context = _ctx(agent_id="agent-1", trust=0.7)
        verdict = runtime.evaluate(action, context)

        ledger = runtime._behavior_ledger
        self.assertIsNotNone(ledger)
        entry = ledger.get_latest("agent-1")
        self.assertIsNotNone(entry)

        # Verify pipeline trace has steps
        self.assertGreaterEqual(len(entry.pipeline_trace), 5)

        # Verify verdict matches
        self.assertEqual(entry.verdict, verdict.verdict.name)

        # Verify dimension scores populated
        self.assertGreater(len(entry.dimension_scores), 0)

        # Verify behavioral state populated
        self.assertGreaterEqual(entry.fingerprint_observations, 0)

        # Verify action_to_pass populated
        self.assertIsNotNone(entry.action_to_pass)

    def test_deny_entry_has_gaps(self) -> None:
        runtime = self._runtime()
        # Don't configure any scope — should deny for out-of-scope
        action = _action(action_type="admin_delete", target="/system/core")
        context = _ctx(agent_id="agent-1", trust=0.5)
        verdict = runtime.evaluate(action, context)

        entry = runtime._behavior_ledger.get_latest("agent-1")
        self.assertIsNotNone(entry)

        if entry.verdict == "DENY":
            self.assertIsNotNone(entry.action_to_pass)
            self.assertEqual(entry.action_to_pass.current_verdict, "DENY")

    def test_allow_entry_has_margin(self) -> None:
        runtime = self._runtime()
        scope_dim = runtime.registry.get("scope_compliance")
        if scope_dim:
            scope_dim.configure_agent_scope("agent-1", {"read"})

        action = _action(action_type="read", target="/data")
        context = _ctx(agent_id="agent-1", trust=0.8)
        verdict = runtime.evaluate(action, context)

        entry = runtime._behavior_ledger.get_latest("agent-1")
        self.assertIsNotNone(entry)

        if entry.verdict == "ALLOW":
            self.assertIsNotNone(entry.action_to_pass)
            self.assertEqual(entry.action_to_pass.current_verdict, "ALLOW")
            self.assertGreater(entry.action_to_pass.margin_to_deny, 0)

    def test_causal_link_to_previous(self) -> None:
        runtime = self._runtime()
        scope_dim = runtime.registry.get("scope_compliance")
        if scope_dim:
            scope_dim.configure_agent_scope("agent-1", {"read"})

        # First evaluation
        action1 = _action(action_type="read", target="/data")
        context1 = _ctx(agent_id="agent-1", trust=0.7)
        runtime.evaluate(action1, context1)

        # Second evaluation
        action2 = _action(action_type="read", target="/data2")
        context2 = _ctx(agent_id="agent-1", trust=0.7)
        runtime.evaluate(action2, context2)

        entry = runtime._behavior_ledger.get_latest("agent-1")
        self.assertIsNotNone(entry)
        self.assertEqual(entry.sequence_number, 1)
        self.assertGreater(len(entry.causal_links), 0)
        self.assertEqual(entry.causal_links[0].influence_type, "trust_change")

    def test_contract_snapshot_embedded(self) -> None:
        runtime = self._runtime()
        scope_dim = runtime.registry.get("scope_compliance")
        if scope_dim:
            scope_dim.configure_agent_scope("agent-1", {"read"})

        # Set a contract
        contract = BehavioralContract(
            contract_id="c-test-1",
            version=1,
            agent_id="agent-1",
            created_at=time.time(),
            archetype="executor",
            drift_thresholds={"action": 0.2},
        )
        runtime._contract_store.store(contract)

        action = _action(action_type="read", target="/data")
        context = _ctx(agent_id="agent-1", trust=0.7)
        runtime.evaluate(action, context)

        entry = runtime._behavior_ledger.get_latest("agent-1")
        self.assertIsNotNone(entry)
        self.assertIsNotNone(entry.contract)
        self.assertEqual(entry.contract.contract_id, "c-test-1")
        self.assertEqual(entry.contract.version, 1)

    def test_ledger_disabled_no_overhead(self) -> None:
        runtime = GovernanceRuntime(RuntimeConfig(
            enable_behavior_ledger=False,
            enable_fingerprints=True,
            enable_audit=False,
            enable_contextual_modifier=False,
            enable_workflow_governor=False,
            enable_equity_analysis=False,
            enable_bias_detection=False,
        ))
        scope_dim = runtime.registry.get("scope_compliance")
        if scope_dim:
            scope_dim.configure_agent_scope("agent-1", {"read"})

        action = _action(action_type="read", target="/data")
        context = _ctx(agent_id="agent-1", trust=0.7)
        verdict = runtime.evaluate(action, context)

        # No ledger store at all
        self.assertIsNone(runtime._behavior_ledger)
        # Verdict should still work
        self.assertIsNotNone(verdict)


# ── CLI Integration ─────────────────────────────────────────────────


class TestCLIIntegration(TestCase):
    """Tests for CLI argument parsing for ledger commands."""

    def test_ledger_show_parses(self) -> None:
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["ledger", "show", "--agent", "test-agent"])
        self.assertEqual(args.command, "ledger")
        self.assertEqual(args.ledger_command, "show")
        self.assertEqual(args.agent, "test-agent")

    def test_ledger_trace_parses(self) -> None:
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args(
            ["ledger", "trace", "--agent", "test-agent", "--sequence", "5", "--depth", "3"]
        )
        self.assertEqual(args.command, "ledger")
        self.assertEqual(args.ledger_command, "trace")
        self.assertEqual(args.agent, "test-agent")
        self.assertEqual(args.sequence, 5)
        self.assertEqual(args.depth, 3)

    def test_ledger_verify_parses(self) -> None:
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["ledger", "verify", "--agent", "test-agent"])
        self.assertEqual(args.command, "ledger")
        self.assertEqual(args.ledger_command, "verify")
        self.assertEqual(args.agent, "test-agent")
