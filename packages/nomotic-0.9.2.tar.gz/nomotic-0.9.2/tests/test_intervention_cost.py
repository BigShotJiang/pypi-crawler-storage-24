"""Tests for the Intervention Cost Model."""

from __future__ import annotations

import statistics

from nomotic.cost_profile import CostProfile
from nomotic.intervention_cost import (
    CostModelConfig,
    InterventionCost,
    InterventionCostModel,
)


class TestBaseCosts:
    """Each intervention type has expected base cost."""

    def test_base_costs(self) -> None:
        model = InterventionCostModel()
        expected = {
            "advisory": 0.01,
            "throttle": 0.08,
            "escalate": 0.15,
            "tighten": 0.12,
            "quarantine": 0.25,
        }
        for itype, expected_cost in expected.items():
            cost = model.compute_cost(itype, "agent-1")
            assert cost.mean == expected_cost, f"{itype}: {cost.mean} != {expected_cost}"
            assert cost.fatigue_multiplier == 1.0


class TestFatigue:
    """Fatigue increases cost for repeated interventions."""

    def test_fatigue_increases_cost(self) -> None:
        model = InterventionCostModel()
        # Record 3 advisories
        for i in range(3):
            model.record_intervention("agent-1", "advisory", timestamp=float(i))

        cost = model.compute_cost("advisory", "agent-1")
        # fatigue_multiplier should be 1.5^3 = 3.375
        assert cost.fatigue_multiplier > 1.0
        assert cost.effective > cost.mean

    def test_fatigue_exponential(self) -> None:
        model = InterventionCostModel()
        costs = []
        for i in range(5):
            cost = model.compute_cost("throttle", "agent-1")
            costs.append(cost.effective)
            model.record_intervention("agent-1", "throttle", timestamp=float(i))

        # Each successive cost should be higher than the last
        for j in range(1, len(costs)):
            assert costs[j] > costs[j - 1], f"Cost did not increase at step {j}"

    def test_no_fatigue_for_fresh_agent(self) -> None:
        model = InterventionCostModel()
        cost = model.compute_cost("advisory", "fresh-agent")
        assert cost.fatigue_multiplier == 1.0
        assert cost.effective == cost.mean


class TestCostDistribution:
    """InterventionCost.sample() returns values around mean ± variance."""

    def test_cost_distribution_sampling(self) -> None:
        cost = InterventionCost(mean=0.10, variance=0.01, fatigue_multiplier=1.0)
        samples = [cost.sample() for _ in range(2000)]
        sample_mean = statistics.mean(samples)
        # Mean should be close to 0.10
        assert abs(sample_mean - 0.10) < 0.02, f"Sample mean {sample_mean} too far from 0.10"
        # All samples should be >= 0
        assert all(s >= 0 for s in samples)

    def test_zero_variance_returns_effective(self) -> None:
        cost = InterventionCost(mean=0.05, variance=0.0, fatigue_multiplier=2.0)
        assert cost.sample() == cost.effective == 0.10


class TestCostProfileEscalationOverride:
    """CostProfile with high escalation costs overrides escalate cost."""

    def test_cost_profile_escalation_override(self) -> None:
        profile = CostProfile(
            escalation_latency_cost=0.5,
            escalation_interruption_cost=0.3,
        )
        model = InterventionCostModel()
        cost = model.compute_cost("escalate", "agent-1", cost_profile=profile)
        # Should use profile costs: 0.5 + 0.3 = 0.8 instead of base 0.15
        assert cost.mean == 0.8

    def test_non_escalate_ignores_profile(self) -> None:
        profile = CostProfile(
            escalation_latency_cost=0.5,
            escalation_interruption_cost=0.3,
        )
        model = InterventionCostModel()
        cost = model.compute_cost("advisory", "agent-1", cost_profile=profile)
        assert cost.mean == 0.01  # base cost, not profile


class TestStrategyFailure:
    """Strategy failure detection for repeated same-type interventions."""

    def test_strategy_failure_detection(self) -> None:
        model = InterventionCostModel()
        for i in range(3):
            model.record_intervention("agent-1", "throttle", timestamp=float(i))

        assert model.detect_strategy_failure("agent-1", "throttle") is True

    def test_strategy_failure_below_threshold(self) -> None:
        model = InterventionCostModel()
        for i in range(2):
            model.record_intervention("agent-1", "throttle", timestamp=float(i))

        assert model.detect_strategy_failure("agent-1", "throttle") is False

    def test_different_types_no_cross_fatigue(self) -> None:
        model = InterventionCostModel()
        # Record 5 advisories
        for i in range(5):
            model.record_intervention("agent-1", "advisory", timestamp=float(i))

        # Throttle fatigue should be unaffected
        throttle_cost = model.compute_cost("throttle", "agent-1")
        assert throttle_cost.fatigue_multiplier == 1.0

        # Strategy failure for throttle should be False
        assert model.detect_strategy_failure("agent-1", "throttle") is False
