"""Tests for the Signal Model & Prior System."""

from __future__ import annotations

import json
import os
import tempfile
import time

import pytest

from nomotic.signals import (
    BUILTIN_SIGNALS,
    FileSignalFeed,
    PriorSystem,
    Signal,
    SignalBundle,
    SignalCatalogue,
    SignalFormat,
    SignalSpec,
    build_default_catalogue,
)


# ── SignalCatalogue ─────────────────────────────────────────────────────


class TestSignalCatalogue:
    def test_register_and_get(self) -> None:
        cat = SignalCatalogue()
        spec = SignalSpec(
            name="test_signal",
            description="A test signal.",
            format=SignalFormat.FLOAT_01,
            agent_types=[],
            prior=0.5,
        )
        cat.register(spec)
        assert cat.get_spec("test_signal") is spec
        assert "test_signal" in cat
        assert len(cat) == 1

    def test_get_unknown_returns_none(self) -> None:
        cat = SignalCatalogue()
        assert cat.get_spec("nonexistent") is None

    def test_get_for_agent_type(self) -> None:
        cat = build_default_catalogue()
        ce_specs = cat.get_for_agent_type("customer_experience")
        names = {s.name for s in ce_specs}
        # loyalty and fraud_risk target customer_experience; consent_status and
        # relationship_tenure have empty agent_types (apply to all)
        assert "loyalty" in names
        assert "fraud_risk" in names
        assert "consent_status" in names
        assert "relationship_tenure" in names
        # fraud_risk_elevated targets only financial_analyst
        assert "fraud_risk_elevated" not in names

    def test_get_for_agent_type_financial(self) -> None:
        cat = build_default_catalogue()
        fa_specs = cat.get_for_agent_type("financial_analyst")
        names = {s.name for s in fa_specs}
        assert "fraud_risk" in names
        assert "fraud_risk_elevated" in names
        assert "loyalty" not in names

    def test_builtin_catalogue_has_all_signals(self) -> None:
        cat = build_default_catalogue()
        assert len(cat) == len(BUILTIN_SIGNALS)
        for spec in BUILTIN_SIGNALS:
            assert cat.get_spec(spec.name) is not None


# ── PriorSystem ─────────────────────────────────────────────────────────


class TestPriorSystem:
    def test_get_prior(self) -> None:
        cat = build_default_catalogue()
        ps = PriorSystem(cat)
        assert ps.get_prior("loyalty") == 0.5
        assert ps.get_prior("fraud_risk") == 0.3
        assert ps.get_prior("consent_status") == "unknown"
        assert ps.get_prior("relationship_tenure") == 0
        assert ps.get_prior("fraud_risk_elevated") is False

    def test_get_prior_unknown_raises(self) -> None:
        cat = SignalCatalogue()
        ps = PriorSystem(cat)
        with pytest.raises(KeyError, match="Unknown signal"):
            ps.get_prior("nonexistent")

    def test_resolve_with_value(self) -> None:
        cat = build_default_catalogue()
        ps = PriorSystem(cat)
        signals = {
            "loyalty": Signal(
                name="loyalty", value=0.9, source="crm", computed_at=time.time()
            )
        }
        assert ps.resolve(signals, "loyalty") == 0.9

    def test_resolve_without_value_falls_back_to_prior(self) -> None:
        cat = build_default_catalogue()
        ps = PriorSystem(cat)
        signals: dict[str, Signal] = {}
        assert ps.resolve(signals, "loyalty") == 0.5

    def test_resolve_mixed(self) -> None:
        cat = build_default_catalogue()
        ps = PriorSystem(cat)
        signals = {
            "fraud_risk": Signal(
                name="fraud_risk", value=0.8, source="model", computed_at=time.time()
            )
        }
        # present → actual value
        assert ps.resolve(signals, "fraud_risk") == 0.8
        # absent → prior
        assert ps.resolve(signals, "loyalty") == 0.5


# ── SignalBundle ────────────────────────────────────────────────────────


class TestSignalBundle:
    def test_get_returns_value_when_present(self) -> None:
        cat = build_default_catalogue()
        ps = PriorSystem(cat)
        bundle = SignalBundle(
            signals={
                "loyalty": Signal(
                    name="loyalty", value=0.7, source="test", computed_at=time.time()
                )
            }
        )
        assert bundle.get("loyalty", ps) == 0.7

    def test_get_returns_prior_when_absent(self) -> None:
        cat = build_default_catalogue()
        ps = PriorSystem(cat)
        bundle = SignalBundle()
        assert bundle.get("loyalty", ps) == 0.5

    def test_missing_lists_absent_signals(self) -> None:
        cat = build_default_catalogue()
        bundle = SignalBundle(
            signals={
                "loyalty": Signal(
                    name="loyalty", value=0.7, source="test", computed_at=time.time()
                )
            },
            agent_type="customer_experience",
        )
        missing = bundle.missing(cat)
        assert "loyalty" not in missing
        assert "fraud_risk" in missing
        assert "consent_status" in missing
        assert "relationship_tenure" in missing
        # fraud_risk_elevated is not relevant for customer_experience
        assert "fraud_risk_elevated" not in missing

    def test_missing_without_agent_type(self) -> None:
        cat = build_default_catalogue()
        bundle = SignalBundle(
            signals={
                "loyalty": Signal(
                    name="loyalty", value=0.7, source="test", computed_at=time.time()
                )
            },
        )
        missing = bundle.missing(cat)
        # All signals except loyalty
        assert "loyalty" not in missing
        assert len(missing) == len(BUILTIN_SIGNALS) - 1


# ── FileSignalFeed ──────────────────────────────────────────────────────


class TestFileSignalFeedCSV:
    def test_csv_feed(self, tmp_path: object) -> None:
        cat = build_default_catalogue()
        csv_path = os.path.join(str(tmp_path), "signals.csv")
        with open(csv_path, "w", newline="") as f:
            f.write("entity_id,loyalty,fraud_risk,consent_status\n")
            f.write("user_001,0.8,0.1,granted\n")
            f.write("user_002,0.3,0.9,denied\n")

        feed = FileSignalFeed(csv_path, cat, refresh_seconds=3600)
        feed.reload()

        bundle = feed.get_bundle("user_001")
        ps = PriorSystem(cat)
        assert bundle.get("loyalty", ps) == pytest.approx(0.8)
        assert bundle.get("fraud_risk", ps) == pytest.approx(0.1)
        assert bundle.get("consent_status", ps) == "granted"

        bundle2 = feed.get_bundle("user_002")
        assert bundle2.get("loyalty", ps) == pytest.approx(0.3)
        assert bundle2.get("fraud_risk", ps) == pytest.approx(0.9)
        assert bundle2.get("consent_status", ps) == "denied"

    def test_csv_feed_missing_entity(self, tmp_path: object) -> None:
        cat = build_default_catalogue()
        csv_path = os.path.join(str(tmp_path), "signals.csv")
        with open(csv_path, "w", newline="") as f:
            f.write("entity_id,loyalty\n")
            f.write("user_001,0.5\n")

        feed = FileSignalFeed(csv_path, cat, refresh_seconds=3600)
        feed.reload()
        bundle = feed.get_bundle("nonexistent")
        assert bundle.signals == {}


class TestFileSignalFeedJSON:
    def test_json_feed(self, tmp_path: object) -> None:
        cat = build_default_catalogue()
        json_path = os.path.join(str(tmp_path), "signals.json")
        data = [
            {
                "entity_id": "agent_a",
                "loyalty": 0.6,
                "fraud_risk_elevated": True,
                "relationship_tenure": 365,
            },
        ]
        with open(json_path, "w") as f:
            json.dump(data, f)

        feed = FileSignalFeed(json_path, cat, refresh_seconds=3600)
        feed.reload()

        ps = PriorSystem(cat)
        bundle = feed.get_bundle("agent_a")
        assert bundle.get("loyalty", ps) == pytest.approx(0.6)
        assert bundle.get("fraud_risk_elevated", ps) is True
        assert bundle.get("relationship_tenure", ps) == 365

    def test_json_feed_ignores_unknown_columns(self, tmp_path: object) -> None:
        cat = build_default_catalogue()
        json_path = os.path.join(str(tmp_path), "signals.json")
        data = [{"entity_id": "x", "unknown_col": 99, "loyalty": 0.4}]
        with open(json_path, "w") as f:
            json.dump(data, f)

        feed = FileSignalFeed(json_path, cat, refresh_seconds=3600)
        feed.reload()
        bundle = feed.get_bundle("x")
        assert "unknown_col" not in bundle.signals
        assert "loyalty" in bundle.signals

    def test_unsupported_extension_raises(self, tmp_path: object) -> None:
        cat = build_default_catalogue()
        bad_path = os.path.join(str(tmp_path), "signals.xml")
        with open(bad_path, "w") as f:
            f.write("<data/>")
        feed = FileSignalFeed(bad_path, cat)
        with pytest.raises(ValueError, match="Unsupported signal feed file type"):
            feed.reload()


# ── AgentContext integration ────────────────────────────────────────────


class TestAgentContextSignalBundle:
    def test_signal_bundle_field_exists(self) -> None:
        from nomotic.types import AgentContext, TrustProfile

        ctx = AgentContext(
            agent_id="test",
            trust_profile=TrustProfile(
                agent_id="test",
                overall_trust=0.8,
                dimension_trust={},
            ),
        )
        assert ctx.signal_bundle is None

    def test_signal_bundle_with_bundle(self) -> None:
        from nomotic.types import AgentContext, TrustProfile

        cat = build_default_catalogue()
        ps = PriorSystem(cat)
        bundle = SignalBundle(
            signals={
                "loyalty": Signal(
                    name="loyalty", value=0.9, source="test", computed_at=time.time()
                )
            },
            agent_type="customer_experience",
        )
        ctx = AgentContext(
            agent_id="test",
            trust_profile=TrustProfile(agent_id="test", overall_trust=0.8, dimension_trust={}),
            signal_bundle=bundle,
        )
        assert ctx.signal_bundle is not None
        assert ctx.signal_bundle.get("loyalty", ps) == 0.9
        assert ctx.signal_bundle.get("fraud_risk", ps) == 0.3  # prior


# ── RuntimeConfig integration ──────────────────────────────────────────


class TestRuntimeConfigSignals:
    def test_default_runtime_has_signal_catalogue(self) -> None:
        from nomotic.runtime import GovernanceRuntime

        rt = GovernanceRuntime()
        assert rt.signal_catalogue is not None
        assert len(rt.signal_catalogue) == len(BUILTIN_SIGNALS)
        assert rt.prior_system is not None

    def test_custom_catalogue(self) -> None:
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        cat = SignalCatalogue()
        cat.register(
            SignalSpec(
                name="custom",
                description="Custom signal.",
                format=SignalFormat.FLOAT_01,
                agent_types=[],
                prior=0.42,
            )
        )
        config = RuntimeConfig(signal_catalogue=cat)
        rt = GovernanceRuntime(config=config)
        assert rt.signal_catalogue is cat
        assert rt.prior_system.get_prior("custom") == pytest.approx(0.42)

    def test_signal_feeds_wired(self, tmp_path: object) -> None:
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        cat = build_default_catalogue()
        csv_path = os.path.join(str(tmp_path), "feed.csv")
        with open(csv_path, "w", newline="") as f:
            f.write("entity_id,loyalty\n")
            f.write("u1,0.99\n")
        feed = FileSignalFeed(csv_path, cat, refresh_seconds=3600)
        feed.reload()

        config = RuntimeConfig(signal_catalogue=cat, signal_feeds=[feed])
        rt = GovernanceRuntime(config=config)
        assert len(rt._signal_feeds) == 1
        bundle = rt._signal_feeds[0].get_bundle("u1")
        assert bundle.get("loyalty", rt.prior_system) == pytest.approx(0.99)
