"""Tests for CostProfile — asymmetric error cost specifications."""

from __future__ import annotations

import time
import uuid
from unittest import TestCase

from nomotic.cost_profile import (
    BALANCED,
    CONSERVATIVE,
    COST_LEVELS,
    CostProfile,
    PERMISSIVE,
)
from nomotic.contract import BehavioralContract, ContractStore, generate_contract
from nomotic.priors import PriorRegistry
from nomotic.provenance import ProvenanceLog, ProvenanceRecord


class TestCategoricalCreation(TestCase):
    """CostProfile.from_categorical with categorical labels."""

    def test_critical_low(self) -> None:
        cp = CostProfile.from_categorical("CRITICAL", "LOW")
        self.assertAlmostEqual(cp.false_allow_cost, COST_LEVELS["CRITICAL"])
        self.assertAlmostEqual(cp.false_deny_cost, COST_LEVELS["LOW"])
        self.assertEqual(cp.false_allow_label, "CRITICAL")
        self.assertEqual(cp.false_deny_label, "LOW")

    def test_all_levels_map_correctly(self) -> None:
        for label, expected in COST_LEVELS.items():
            cp = CostProfile.from_categorical(label, label)
            self.assertAlmostEqual(cp.false_allow_cost, expected)
            self.assertAlmostEqual(cp.false_deny_cost, expected)

    def test_kwargs_passthrough(self) -> None:
        cp = CostProfile.from_categorical("HIGH", "LOW", zone_multiplier=2.0)
        self.assertAlmostEqual(cp.zone_multiplier, 2.0)
        self.assertAlmostEqual(cp.false_allow_cost, COST_LEVELS["HIGH"])


class TestNumericCreation(TestCase):
    """Direct numeric CostProfile creation and round-trip serialization."""

    def test_round_trip_to_dict_from_dict(self) -> None:
        cp = CostProfile(
            false_allow_cost=0.42,
            false_deny_cost=0.18,
            false_allow_label="CUSTOM_HIGH",
            false_deny_label="CUSTOM_LOW",
            escalation_latency_cost=0.05,
            escalation_interruption_cost=0.15,
            zone_multiplier=1.5,
        )
        d = cp.to_dict()
        restored = CostProfile.from_dict(d)
        self.assertAlmostEqual(restored.false_allow_cost, 0.42)
        self.assertAlmostEqual(restored.false_deny_cost, 0.18)
        self.assertEqual(restored.false_allow_label, "CUSTOM_HIGH")
        self.assertEqual(restored.false_deny_label, "CUSTOM_LOW")
        self.assertAlmostEqual(restored.escalation_latency_cost, 0.05)
        self.assertAlmostEqual(restored.escalation_interruption_cost, 0.15)
        self.assertAlmostEqual(restored.zone_multiplier, 1.5)

    def test_from_dict_empty_returns_defaults(self) -> None:
        cp = CostProfile.from_dict({})
        self.assertAlmostEqual(cp.false_allow_cost, 0.3)
        self.assertAlmostEqual(cp.false_deny_cost, 0.3)

    def test_predefined_conservative(self) -> None:
        self.assertAlmostEqual(CONSERVATIVE.false_allow_cost, 1.0)
        self.assertAlmostEqual(CONSERVATIVE.false_deny_cost, 0.1)

    def test_predefined_balanced(self) -> None:
        self.assertAlmostEqual(BALANCED.false_allow_cost, 0.3)
        self.assertAlmostEqual(BALANCED.false_deny_cost, 0.3)

    def test_predefined_permissive(self) -> None:
        self.assertAlmostEqual(PERMISSIVE.false_allow_cost, 0.1)
        self.assertAlmostEqual(PERMISSIVE.false_deny_cost, 0.6)


class TestHybridOverrides(TestCase):
    """Categorical base with invariant_overrides (hybrid mode)."""

    def test_effective_false_allow_with_override(self) -> None:
        cp = CostProfile.from_categorical(
            "MODERATE", "MODERATE",
            invariant_overrides={
                "inv-pii": {"false_allow": 0.9, "false_deny": 0.05},
            },
        )
        # With invariant override
        self.assertAlmostEqual(cp.effective_false_allow("inv-pii"), 0.9)
        self.assertAlmostEqual(cp.effective_false_deny("inv-pii"), 0.05)
        # Without invariant override — falls back to base
        self.assertAlmostEqual(cp.effective_false_allow(None), 0.3)
        self.assertAlmostEqual(cp.effective_false_deny(None), 0.3)

    def test_unknown_invariant_falls_back(self) -> None:
        cp = CostProfile.from_categorical(
            "HIGH", "LOW",
            invariant_overrides={"inv-x": {"false_allow": 0.5}},
        )
        # Unknown invariant uses base
        self.assertAlmostEqual(cp.effective_false_allow("inv-unknown"), COST_LEVELS["HIGH"])

    def test_partial_override_uses_base_for_missing_key(self) -> None:
        cp = CostProfile(
            false_allow_cost=0.4,
            false_deny_cost=0.2,
            invariant_overrides={"inv-a": {"false_allow": 0.8}},
        )
        # false_deny not in override — uses base
        self.assertAlmostEqual(cp.effective_false_deny("inv-a"), 0.2)
        self.assertAlmostEqual(cp.effective_false_allow("inv-a"), 0.8)


class TestOptimalThresholds(TestCase):
    """Threshold derivation from cost profile."""

    def test_conservative_low_allow_threshold(self) -> None:
        # CONSERVATIVE: false_allow=1.0 (CRITICAL), false_deny=0.1 (LOW)
        # theta = 0.1 / (0.1 + 1.0) = 0.0909 -> clamped to 0.15
        allow_t = CONSERVATIVE.optimal_allow_threshold()
        self.assertAlmostEqual(allow_t, 0.15, places=2)

    def test_permissive_high_allow_threshold(self) -> None:
        # PERMISSIVE: false_allow=0.1 (LOW), false_deny=0.6 (HIGH)
        # theta = 0.6 / (0.6 + 0.1) = 0.857
        allow_t = PERMISSIVE.optimal_allow_threshold()
        self.assertGreater(allow_t, 0.8)

    def test_balanced_around_half(self) -> None:
        # BALANCED: equal costs -> theta = 0.5
        allow_t = BALANCED.optimal_allow_threshold()
        self.assertAlmostEqual(allow_t, 0.5, places=2)

    def test_zero_costs_return_half(self) -> None:
        cp = CostProfile(false_allow_cost=0.0, false_deny_cost=0.0)
        self.assertAlmostEqual(cp.optimal_allow_threshold(), 0.5)

    def test_deny_threshold_below_allow_threshold(self) -> None:
        for profile in (CONSERVATIVE, BALANCED, PERMISSIVE):
            deny_t = profile.optimal_deny_threshold()
            allow_t = profile.optimal_allow_threshold()
            self.assertLess(deny_t, allow_t,
                            f"deny_t ({deny_t}) should be < allow_t ({allow_t})")


class TestThresholdClamping(TestCase):
    """Extreme cost ratios don't produce out-of-range thresholds."""

    def test_allow_threshold_clamped_low(self) -> None:
        cp = CostProfile(false_allow_cost=1000.0, false_deny_cost=0.001)
        self.assertGreaterEqual(cp.optimal_allow_threshold(), 0.15)

    def test_allow_threshold_clamped_high(self) -> None:
        cp = CostProfile(false_allow_cost=0.001, false_deny_cost=1000.0)
        self.assertLessEqual(cp.optimal_allow_threshold(), 0.95)

    def test_deny_threshold_clamped_low(self) -> None:
        cp = CostProfile(false_allow_cost=1000.0, false_deny_cost=0.001)
        self.assertGreaterEqual(cp.optimal_deny_threshold(), 0.05)

    def test_deny_threshold_clamped_high(self) -> None:
        cp = CostProfile(false_allow_cost=0.001, false_deny_cost=1000.0)
        self.assertLessEqual(cp.optimal_deny_threshold(), 0.85)


class TestZoneMultiplier(TestCase):
    """Zone multiplier scales effective costs."""

    def test_multiplier_doubles_effective_costs(self) -> None:
        cp = CostProfile(
            false_allow_cost=0.3,
            false_deny_cost=0.2,
            zone_multiplier=2.0,
        )
        self.assertAlmostEqual(cp.effective_false_allow(), 0.6)
        self.assertAlmostEqual(cp.effective_false_deny(), 0.4)

    def test_multiplier_applies_to_overrides(self) -> None:
        cp = CostProfile(
            false_allow_cost=0.3,
            false_deny_cost=0.2,
            zone_multiplier=3.0,
            invariant_overrides={"inv-x": {"false_allow": 0.5, "false_deny": 0.1}},
        )
        self.assertAlmostEqual(cp.effective_false_allow("inv-x"), 1.5)
        self.assertAlmostEqual(cp.effective_false_deny("inv-x"), 0.3)

    def test_default_multiplier_is_one(self) -> None:
        cp = CostProfile()
        self.assertAlmostEqual(cp.zone_multiplier, 1.0)


class TestAmbiguityZoneWidth(TestCase):
    """High-stakes profiles have narrower ambiguity zones."""

    def test_high_stakes_narrow_zone(self) -> None:
        high_stakes = CostProfile(false_allow_cost=0.9, false_deny_cost=0.9)
        low_stakes = CostProfile(false_allow_cost=0.1, false_deny_cost=0.1)

        high_zone = high_stakes.optimal_allow_threshold() - high_stakes.optimal_deny_threshold()
        low_zone = low_stakes.optimal_allow_threshold() - low_stakes.optimal_deny_threshold()

        self.assertLess(high_zone, low_zone,
                        "High-stakes ambiguity zone should be narrower")

    def test_ambiguity_zone_is_positive(self) -> None:
        for profile in (CONSERVATIVE, BALANCED, PERMISSIVE):
            zone = profile.optimal_allow_threshold() - profile.optimal_deny_threshold()
            self.assertGreater(zone, 0.0, "Ambiguity zone must be positive")


class TestContractIntegration(TestCase):
    """CostProfile integration with BehavioralContract and generate_contract."""

    def test_generate_contract_with_cost_profile(self) -> None:
        registry = PriorRegistry.with_defaults()
        cp_dict = CONSERVATIVE.to_dict()
        contract = generate_contract(
            agent_id="agent-1",
            archetype="customer-experience",
            prior_registry=registry,
            cost_profile=cp_dict,
        )
        self.assertEqual(contract.cost_profile, cp_dict)
        # Verify it appears in to_dict()
        d = contract.to_dict()
        self.assertIn("cost_profile", d)
        self.assertEqual(d["cost_profile"]["false_allow_cost"], 1.0)

    def test_generate_contract_pulls_archetype_default(self) -> None:
        registry = PriorRegistry.with_defaults()
        contract = generate_contract(
            agent_id="agent-2",
            archetype="security-monitor",
            prior_registry=registry,
        )
        # security-monitor has CONSERVATIVE default
        self.assertTrue(len(contract.cost_profile) > 0)
        self.assertAlmostEqual(contract.cost_profile["false_allow_cost"], 1.0)

    def test_explicit_cost_profile_overrides_archetype(self) -> None:
        registry = PriorRegistry.with_defaults()
        custom = PERMISSIVE.to_dict()
        contract = generate_contract(
            agent_id="agent-3",
            archetype="security-monitor",  # default is CONSERVATIVE
            prior_registry=registry,
            cost_profile=custom,
        )
        # Should use explicit, not archetype default
        self.assertAlmostEqual(contract.cost_profile["false_allow_cost"], 0.1)

    def test_contract_from_dict_round_trip(self) -> None:
        registry = PriorRegistry.with_defaults()
        contract = generate_contract(
            agent_id="agent-4",
            archetype="financial-analyst",
            prior_registry=registry,
            cost_profile=BALANCED.to_dict(),
        )
        d = contract.to_dict()
        restored = BehavioralContract.from_dict(d)
        self.assertEqual(restored.cost_profile, contract.cost_profile)

    def test_cost_profile_in_content_hash(self) -> None:
        """Changing cost_profile must change the content hash."""
        registry = PriorRegistry.with_defaults()
        c1 = generate_contract(
            agent_id="agent-5",
            archetype="customer-experience",
            prior_registry=registry,
            cost_profile=BALANCED.to_dict(),
        )
        c2 = generate_contract(
            agent_id="agent-5",
            archetype="customer-experience",
            prior_registry=registry,
            cost_profile=CONSERVATIVE.to_dict(),
        )
        self.assertNotEqual(c1.content_hash(), c2.content_hash())


class TestContractDiffCostProfile(TestCase):
    """diff() shows cost_profile changes between contract versions."""

    def test_diff_shows_cost_profile_change(self) -> None:
        now = time.time()
        c1 = BehavioralContract(
            contract_id="c-1",
            version=1,
            agent_id="agent-diff",
            created_at=now,
            cost_profile=BALANCED.to_dict(),
        )
        c2 = BehavioralContract(
            contract_id="c-2",
            version=2,
            agent_id="agent-diff",
            created_at=now + 1,
            cost_profile=CONSERVATIVE.to_dict(),
        )
        diff = c1.diff(c2)
        self.assertIn("cost_profile", diff["changes"])
        # The cost_profile is a dict, so diff shows per-key changes
        cp_changes = diff["changes"]["cost_profile"]
        self.assertIn("false_allow_cost", cp_changes)
        self.assertAlmostEqual(cp_changes["false_allow_cost"]["from"], 0.3)
        self.assertAlmostEqual(cp_changes["false_allow_cost"]["to"], 1.0)

    def test_no_diff_when_cost_profiles_identical(self) -> None:
        now = time.time()
        cp = BALANCED.to_dict()
        c1 = BehavioralContract(
            contract_id="c-1", version=1, agent_id="agent-same",
            created_at=now, cost_profile=cp,
        )
        c2 = BehavioralContract(
            contract_id="c-2", version=2, agent_id="agent-same",
            created_at=now + 1, cost_profile=cp,
        )
        diff = c1.diff(c2)
        self.assertNotIn("cost_profile", diff["changes"])


class TestArchetypeDefaults(TestCase):
    """Each of the 10 archetypes has a non-empty default_cost_profile."""

    def test_all_archetypes_have_cost_profiles(self) -> None:
        registry = PriorRegistry.with_defaults()
        expected_archetypes = [
            "customer-experience",
            "operations-coordinator",
            "data-processor",
            "security-monitor",
            "content-creator",
            "research-analyst",
            "financial-analyst",
            "sales-agent",
            "healthcare-agent",
            "executive-assistant",
        ]
        for name in expected_archetypes:
            prior = registry.get(name)
            self.assertIsNotNone(prior, f"No prior for {name}")
            self.assertTrue(
                len(prior.default_cost_profile) > 0,
                f"Empty default_cost_profile for {name}",
            )
            # Verify it has the expected keys
            self.assertIn("false_allow_cost", prior.default_cost_profile)
            self.assertIn("false_deny_cost", prior.default_cost_profile)

    def test_security_monitor_is_conservative(self) -> None:
        registry = PriorRegistry.with_defaults()
        prior = registry.get("security-monitor")
        self.assertAlmostEqual(prior.default_cost_profile["false_allow_cost"], 1.0)
        self.assertAlmostEqual(prior.default_cost_profile["false_deny_cost"], 0.1)

    def test_content_creator_is_permissive(self) -> None:
        registry = PriorRegistry.with_defaults()
        prior = registry.get("content-creator")
        self.assertAlmostEqual(prior.default_cost_profile["false_allow_cost"], 0.1)
        self.assertAlmostEqual(prior.default_cost_profile["false_deny_cost"], 0.6)


class TestProvenanceRecording(TestCase):
    """Changing CostProfile on a contract records a ProvenanceRecord."""

    def test_provenance_record_on_cost_profile_change(self) -> None:
        log = ProvenanceLog()

        old_cp = BALANCED.to_dict()
        new_cp = CONSERVATIVE.to_dict()

        rec = log.record(
            actor="admin@example.com",
            target_type="cost_profile",
            target_id="agent-prov-1",
            change_type="modify",
            previous_value=old_cp,
            new_value=new_cp,
            reason="Tightening governance for production deployment",
        )

        self.assertEqual(rec.target_type, "cost_profile")
        self.assertEqual(rec.change_type, "modify")
        self.assertEqual(rec.actor, "admin@example.com")
        self.assertEqual(rec.previous_value, old_cp)
        self.assertEqual(rec.new_value, new_cp)

        # Query it back
        records = log.query(target_type="cost_profile")
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0].target_id, "agent-prov-1")

    def test_provenance_history_for_agent(self) -> None:
        log = ProvenanceLog()
        agent_id = "agent-prov-2"

        # Initial set
        log.record(
            actor="system",
            actor_type="system",
            target_type="cost_profile",
            target_id=agent_id,
            change_type="add",
            new_value=BALANCED.to_dict(),
        )
        # Update
        log.record(
            actor="ops@example.com",
            target_type="cost_profile",
            target_id=agent_id,
            change_type="modify",
            previous_value=BALANCED.to_dict(),
            new_value=CONSERVATIVE.to_dict(),
            reason="Regulatory requirement",
        )

        history = log.history("cost_profile", agent_id)
        self.assertEqual(len(history), 2)
        self.assertEqual(history[0].change_type, "add")
        self.assertEqual(history[1].change_type, "modify")
