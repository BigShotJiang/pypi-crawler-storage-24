"""Tests for the Monte Carlo policy optimizer."""

from __future__ import annotations

import time

import pytest

from nomotic.cost_profile import BALANCED, CONSERVATIVE, CostProfile
from nomotic.drift_dynamics import DriftDynamicsModel
from nomotic.intervention_cost import InterventionCostModel
from nomotic.policy_optimizer import (
    InterventionPolicy,
    OptimizerConfig,
    PolicyOptimizer,
    STRATEGIES,
)


@pytest.fixture()
def optimizer() -> PolicyOptimizer:
    """Default optimizer with small rollout count for speed."""
    config = OptimizerConfig(n_rollouts=50, timeout_seconds=10.0, horizon=50)
    return PolicyOptimizer(config=config)


@pytest.fixture()
def fast_optimizer() -> PolicyOptimizer:
    """Very fast optimizer for timeout/stability tests."""
    config = OptimizerConfig(n_rollouts=20, timeout_seconds=10.0, horizon=30)
    return PolicyOptimizer(config=config)


class TestNoDriftSelectsNoOp:
    """Current drift ~0. Optimizer selects 'no_op' (cheapest)."""

    def test_no_drift_selects_no_op(self, optimizer: PolicyOptimizer) -> None:
        policy = optimizer.optimize(
            agent_id="agent-0",
            current_drift=0.01,
            velocity=0.0,
            archetype="customer-experience",
            cost_profile=BALANCED,
        )
        assert policy.strategy_name == "no_op"
        assert policy.expected_total_cost >= 0.0


class TestHighDriftSelectsAggressive:
    """Current drift 0.5. Optimizer selects an aggressive strategy."""

    def test_high_drift_selects_aggressive(self, optimizer: PolicyOptimizer) -> None:
        policy = optimizer.optimize(
            agent_id="agent-high",
            current_drift=0.5,
            velocity=0.02,
            archetype="financial-analyst",
            cost_profile=CONSERVATIVE,
        )
        # At high drift, no_op and early_advisory are pruned.
        # Should select one of the remaining strategies.
        assert policy.strategy_name in (
            "wait_and_throttle", "immediate_escalate", "graduated",
        )


class TestModerateDriftSelectsAdvisory:
    """Current drift 0.15. early_advisory likely optimal."""

    def test_moderate_drift_selects_advisory(self, optimizer: PolicyOptimizer) -> None:
        policy = optimizer.optimize(
            agent_id="agent-moderate",
            current_drift=0.15,
            velocity=0.005,
            archetype="customer-experience",
            cost_profile=BALANCED,
        )
        # At moderate drift, all strategies are considered.
        # early_advisory or graduated is typically best.
        assert policy.strategy_name in STRATEGIES


class TestStrategyPruning:
    """Low drift -> only no_op/advisory. High drift -> passive pruned."""

    def test_low_drift_pruning(self, optimizer: PolicyOptimizer) -> None:
        candidates = optimizer._prune_strategies(0.05)
        assert "no_op" in candidates
        assert "early_advisory" in candidates
        assert "immediate_escalate" not in candidates
        assert "graduated" not in candidates

    def test_high_drift_pruning(self, optimizer: PolicyOptimizer) -> None:
        candidates = optimizer._prune_strategies(0.50)
        assert "no_op" not in candidates
        assert "early_advisory" not in candidates
        assert "immediate_escalate" in candidates
        assert "graduated" in candidates

    def test_moderate_drift_all_considered(self, optimizer: PolicyOptimizer) -> None:
        candidates = optimizer._prune_strategies(0.25)
        assert len(candidates) == len(STRATEGIES)


class TestPolicyStability:
    """Policy does NOT change when re-optimized with similar drift."""

    def test_policy_stability(self, fast_optimizer: PolicyOptimizer) -> None:
        # First optimization
        policy1 = fast_optimizer.optimize(
            agent_id="agent-stable",
            current_drift=0.20,
            velocity=0.005,
            archetype="operations-coordinator",
            cost_profile=BALANCED,
        )

        # Re-optimize with nearly identical drift
        policy2 = fast_optimizer.optimize(
            agent_id="agent-stable",
            current_drift=0.21,
            velocity=0.005,
            archetype="operations-coordinator",
            cost_profile=BALANCED,
        )

        # Should keep the same policy (< 10% improvement)
        assert policy2.strategy_name == policy1.strategy_name


class TestPolicySwitch:
    """Policy switches with significantly different drift."""

    def test_policy_switch(self, fast_optimizer: PolicyOptimizer) -> None:
        # Start with low drift -> selects no_op
        policy1 = fast_optimizer.optimize(
            agent_id="agent-switch",
            current_drift=0.02,
            velocity=0.0,
            archetype="customer-experience",
            cost_profile=BALANCED,
        )
        assert policy1.strategy_name == "no_op"

        # Force clear cached policy so the switch is not blocked by stability
        fast_optimizer._current_policies.pop("agent-switch", None)

        # Now with high drift -> should switch to something aggressive
        policy2 = fast_optimizer.optimize(
            agent_id="agent-switch",
            current_drift=0.50,
            velocity=0.03,
            archetype="customer-experience",
            cost_profile=CONSERVATIVE,
        )
        assert policy2.strategy_name != "no_op"


class TestCostVsNaive:
    """Optimized policy has lower expected cost than naive."""

    def test_cost_vs_naive(self, optimizer: PolicyOptimizer) -> None:
        policy = optimizer.optimize(
            agent_id="agent-cost",
            current_drift=0.25,
            velocity=0.01,
            archetype="sales-agent",
            cost_profile=BALANCED,
        )
        # cost_vs_naive >= 0 (optimizer should find something at least as good)
        assert policy.cost_vs_naive >= 0.0


class TestReadableOutput:
    """InterventionPolicy.to_readable() produces expected format."""

    def test_readable_output_graduated(self) -> None:
        policy = InterventionPolicy(
            strategy_name="graduated",
            expected_total_cost=0.12,
            intervention_schedule=(("advisory", 0), ("throttle", 25), ("escalate", 50)),
            conditions={
                "stand_down_if": "drift < 0.15 within 25 actions",
                "escalate_if": "drift > 0.25",
            },
            confidence=0.85,
            cost_vs_naive=0.37,
        )
        readable = policy.to_readable()
        assert "Policy: graduated" in readable
        assert "Step 0: Issue advisory" in readable
        assert "Step 25: Throttle if drift persists" in readable
        assert "Step 50: Escalate" in readable
        assert "Stand down if" in readable
        assert "drift < 0.15 within 25 actions" in readable
        assert "Expected cost: 0.12" in readable
        assert "37% savings vs naive" in readable

    def test_readable_output_no_op(self) -> None:
        policy = InterventionPolicy(
            strategy_name="no_op",
            expected_total_cost=0.0,
        )
        readable = policy.to_readable()
        assert "Policy: no_op" in readable
        assert "Expected cost: 0.00" in readable

    def test_to_dict(self) -> None:
        policy = InterventionPolicy(
            strategy_name="early_advisory",
            expected_total_cost=0.05,
            intervention_schedule=(("advisory", 0),),
            conditions={"stand_down_if": "drift < 0.15 within 25 actions"},
            confidence=0.9,
            cost_vs_naive=0.15,
        )
        d = policy.to_dict()
        assert d["strategy_name"] == "early_advisory"
        assert d["intervention_schedule"] == [{"type": "advisory", "trigger_step": 0}]
        assert d["confidence"] == 0.9
        assert isinstance(d["conditions"], dict)


class TestTimeoutRespected:
    """With low timeout, optimizer still returns a valid result."""

    def test_timeout_respected(self) -> None:
        config = OptimizerConfig(
            n_rollouts=10000,  # Very high, should be cut short by timeout
            timeout_seconds=0.5,
            horizon=100,
        )
        optimizer = PolicyOptimizer(config=config)

        start = time.time()
        policy = optimizer.optimize(
            agent_id="agent-timeout",
            current_drift=0.20,
            velocity=0.01,
            archetype="data-processor",
            cost_profile=BALANCED,
        )
        elapsed = time.time() - start

        # Should return valid result within reasonable time
        assert policy is not None
        assert policy.strategy_name in STRATEGIES
        # Allow some slack for overhead, but should be roughly within timeout
        assert elapsed < 5.0


class TestConfidenceFromVariance:
    """Low rollout variance -> high confidence. High variance -> low confidence."""

    def test_high_confidence_low_drift(self, optimizer: PolicyOptimizer) -> None:
        """Near-zero drift should produce high-confidence no_op policy."""
        policy = optimizer.optimize(
            agent_id="agent-conf-high",
            current_drift=0.01,
            velocity=0.0,
            archetype="customer-experience",
            cost_profile=BALANCED,
        )
        # With near-zero drift, no_op should have near-zero cost and high confidence
        assert policy.confidence >= 0.5

    def test_confidence_is_bounded(self, optimizer: PolicyOptimizer) -> None:
        """Confidence should always be in [0, 1]."""
        policy = optimizer.optimize(
            agent_id="agent-conf-bound",
            current_drift=0.30,
            velocity=0.02,
            archetype="financial-analyst",
            cost_profile=CONSERVATIVE,
        )
        assert 0.0 <= policy.confidence <= 1.0


class TestOptimizerGetPolicy:
    """get_policy returns stored policies."""

    def test_get_policy_after_optimize(self, fast_optimizer: PolicyOptimizer) -> None:
        fast_optimizer.optimize(
            agent_id="agent-get",
            current_drift=0.20,
            velocity=0.01,
            archetype="sales-agent",
            cost_profile=BALANCED,
        )
        policy = fast_optimizer.get_policy("agent-get")
        assert policy is not None
        assert isinstance(policy, InterventionPolicy)

    def test_get_policy_unknown_agent(self, fast_optimizer: PolicyOptimizer) -> None:
        assert fast_optimizer.get_policy("unknown-agent") is None


class TestOptimizerConfig:
    """OptimizerConfig defaults and custom strategies."""

    def test_default_config(self) -> None:
        config = OptimizerConfig()
        assert config.n_rollouts == 200
        assert config.timeout_seconds == 5.0
        assert config.horizon == 100
        assert config.policy_switch_threshold == 0.10
        assert config.strategies is None

    def test_custom_strategies(self) -> None:
        custom = {"do_nothing": [], "nuke": [("escalate", 0), ("tighten", 5)]}
        config = OptimizerConfig(strategies=custom)
        optimizer = PolicyOptimizer(config=config)
        # Pruning should use custom strategies
        candidates = optimizer._prune_strategies(0.25)
        assert "do_nothing" in candidates
        assert "nuke" in candidates


class TestTrajectoryEngineIntegration:
    """TrajectoryProjection can carry an InterventionPolicy."""

    def test_projection_with_policy(self) -> None:
        from nomotic.trajectory_engine import TrajectoryProjection

        policy = InterventionPolicy(
            strategy_name="graduated",
            expected_total_cost=0.10,
            confidence=0.8,
        )
        proj = TrajectoryProjection(
            agent_id="test-agent",
            projection_horizon=100,
            timestamp=time.time(),
            intervention_policy=policy,
        )
        d = proj.to_dict()
        assert "intervention_policy" in d
        assert d["intervention_policy"]["strategy_name"] == "graduated"

    def test_projection_without_policy(self) -> None:
        from nomotic.trajectory_engine import TrajectoryProjection

        proj = TrajectoryProjection(
            agent_id="test-agent",
            projection_horizon=100,
            timestamp=time.time(),
        )
        d = proj.to_dict()
        assert "intervention_policy" not in d
