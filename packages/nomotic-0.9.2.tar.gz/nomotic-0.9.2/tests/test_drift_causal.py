"""Tests for drift causal analysis — explaining why drift happened.

Tests cover:
- Agent drift with provenance events
- Agent drift without provenance events
- Correlated drift analysis
- Coordinated drift analysis
- Fleet drift: concentrated movement
- Fleet drift: distributed movement
- Auto-dispatch routing
- Report serialization (to_dict and summary)
"""

from __future__ import annotations

import time
import uuid
from unittest import TestCase
from unittest.mock import MagicMock

from nomotic.drift import DriftScore
from nomotic.drift_causal import (
    CausalHypothesis,
    DriftCausalAnalyzer,
    DriftCausalReport,
)
from nomotic.fleet_monitor import FleetDriftAlert
from nomotic.monitor import DriftAlert
from nomotic.provenance import ProvenanceLog, ProvenanceRecord


# ── Helpers ────────────────────────────────────────────────────────────


def _make_drift(
    overall: float = 0.0,
    action: float = 0.0,
    target: float = 0.0,
    temporal: float = 0.0,
    outcome: float = 0.0,
    semantic: float = 0.0,
    detail: str = "",
) -> DriftScore:
    return DriftScore(
        overall=overall,
        action_drift=action,
        target_drift=target,
        temporal_drift=temporal,
        outcome_drift=outcome,
        semantic_drift=semantic,
        confidence=0.9,
        window_size=100,
        baseline_size=500,
        detail=detail,
    )


def _make_agent_alert(
    agent_id: str = "agent-1",
    drift: DriftScore | None = None,
    ts: float | None = None,
) -> DriftAlert:
    if drift is None:
        drift = _make_drift(overall=0.45, action=0.3, semantic=0.2)
    return DriftAlert(
        agent_id=agent_id,
        severity="high",
        drift_score=drift,
        timestamp=ts or time.time(),
    )


def _make_fleet_alert(
    scope: str = "fleet",
    affected: list[str] | None = None,
    chain: list[str] | None = None,
    amp: list[float] | None = None,
    shared_direction: dict[str, float] | None = None,
    ts: float | None = None,
) -> FleetDriftAlert:
    return FleetDriftAlert(
        alert_id=f"fleet-{uuid.uuid4().hex[:8]}",
        scope=scope,
        severity="high",
        timestamp=ts or time.time(),
        fleet_drift_score=0.35,
        fleet_distributions_shifted=["action", "semantic"],
        affected_agents=affected or [],
        shared_drift_direction=shared_direction or {},
        propagation_chain=chain or [],
        amplification_factors=amp or [],
    )


# ── Agent Drift with Provenance ───────────────────────────────────────


class TestAgentDriftWithProvenance(TestCase):
    """When provenance events exist near the drift alert, the analyzer
    should identify a config_change hypothesis with high confidence."""

    def test_agent_drift_with_provenance(self) -> None:
        prov = ProvenanceLog()
        # Record a config change before drift
        prov.record(
            actor="admin@example.com",
            target_type="scope",
            target_id="agent-1",
            change_type="modify",
            actor_type="human",
            previous_value="read",
            new_value="read,write",
            reason="Expanded agent scope",
        )
        # Alert fires shortly after the config change
        now = time.time() + 0.1

        analyzer = DriftCausalAnalyzer(provenance_log=prov)
        drift = _make_drift(overall=0.45, action=0.3, semantic=0.2)
        report = analyzer.analyze_agent_drift("agent-1", drift, now)

        self.assertEqual(report.scope, "agent")
        self.assertEqual(report.agent_id, "agent-1")
        self.assertIn("action", report.distributions_involved)
        self.assertIn("semantic", report.distributions_involved)

        # Primary hypothesis should be config_change with high confidence
        self.assertIsNotNone(report.primary_hypothesis)
        self.assertEqual(report.primary_hypothesis.cause_type, "config_change")
        self.assertGreaterEqual(report.primary_hypothesis.confidence, 0.7)
        self.assertIn("scope", report.primary_hypothesis.description)

        # Should have evidence
        self.assertTrue(len(report.primary_hypothesis.evidence) > 0)

        # Should have remediation
        self.assertTrue(len(report.remediation) > 0)


# ── Agent Drift without Provenance ────────────────────────────────────


class TestAgentDriftNoProvenance(TestCase):
    """Without provenance events, the analyzer should fall back to
    workload_shift or unknown with lower confidence."""

    def test_agent_drift_no_provenance(self) -> None:
        analyzer = DriftCausalAnalyzer()  # No provenance log
        drift = _make_drift(overall=0.3, action=0.25, target=0.2)
        report = analyzer.analyze_agent_drift("agent-2", drift, time.time())

        self.assertEqual(report.scope, "agent")
        self.assertIsNotNone(report.primary_hypothesis)
        # Should be workload_shift or unknown
        self.assertIn(
            report.primary_hypothesis.cause_type,
            ("workload_shift", "unknown"),
        )
        self.assertLess(report.primary_hypothesis.confidence, 0.6)

    def test_semantic_reframing_hypothesis(self) -> None:
        """When semantic drift is primary with no provenance, expect
        semantic_reframing hypothesis."""
        analyzer = DriftCausalAnalyzer()
        drift = _make_drift(
            overall=0.4, semantic=0.35, action=0.1,
            detail="term 'assess' shifted",
        )
        report = analyzer.analyze_agent_drift("agent-3", drift, time.time())

        # Should include semantic_reframing hypothesis
        all_types = [report.primary_hypothesis.cause_type] + [
            h.cause_type for h in report.alternative_hypotheses
        ]
        self.assertIn("semantic_reframing", all_types)

        # Find the semantic reframing hypothesis
        sem_hyps = [
            h for h in [report.primary_hypothesis] + list(report.alternative_hypotheses)
            if h.cause_type == "semantic_reframing"
        ]
        self.assertTrue(len(sem_hyps) > 0)
        self.assertGreaterEqual(sem_hyps[0].confidence, 0.5)


# ── Correlated Drift Analysis ────────────────────────────────────────


class TestCorrelatedAnalysis(TestCase):
    """Correlated drift across multiple agents — should identify shared
    upstream cause."""

    def test_correlated_with_shared_upstream(self) -> None:
        prov = ProvenanceLog()
        prov.record(
            actor="system",
            target_type="model",
            target_id="gpt-endpoint-v3",
            change_type="modify",
            actor_type="system",
            previous_value="v3.1",
            new_value="v3.2",
            reason="Model version update",
        )
        # Alert fires shortly after the model update
        now = time.time() + 0.1

        affected = [f"finance-agent-{i}" for i in range(5)]
        analyzer = DriftCausalAnalyzer(provenance_log=prov)
        alert = _make_fleet_alert(
            scope="correlated",
            affected=affected,
            shared_direction={"semantic": 0.3, "action": 0.2},
            ts=now,
        )

        report = analyzer.analyze_correlated_drift(alert)

        self.assertEqual(report.scope, "correlated")
        self.assertEqual(len(report.affected_agents), 5)
        self.assertTrue(report.shared_upstream_input)  # Should identify model
        self.assertIsNotNone(report.primary_hypothesis)
        # Should be model_update with high confidence
        self.assertIn(
            report.primary_hypothesis.cause_type,
            ("model_update", "config_change"),
        )
        self.assertGreaterEqual(report.primary_hypothesis.confidence, 0.7)
        self.assertIn("semantic", report.distributions_involved)

    def test_correlated_no_provenance(self) -> None:
        analyzer = DriftCausalAnalyzer()
        affected = ["agent-a", "agent-b", "agent-c"]
        alert = _make_fleet_alert(
            scope="correlated",
            affected=affected,
            shared_direction={"semantic": 0.25, "action": 0.1},
        )
        report = analyzer.analyze_correlated_drift(alert)
        self.assertEqual(report.scope, "correlated")
        self.assertEqual(len(report.affected_agents), 3)
        self.assertIsNotNone(report.primary_hypothesis)


# ── Coordinated Drift Analysis ────────────────────────────────────────


class TestCoordinatedAnalysis(TestCase):
    """Coordinated drift through a 3-hop interaction chain."""

    def test_coordinated_with_chain(self) -> None:
        chain = ["root-agent", "hop-1", "hop-2"]
        amp = [0.3, 0.35, 0.42]  # Amplifying

        observer = MagicMock()
        observer.get_drift.return_value = _make_drift(
            overall=0.3, action=0.25, semantic=0.2,
        )

        analyzer = DriftCausalAnalyzer(fingerprint_observer=observer)
        alert = _make_fleet_alert(
            scope="coordinated",
            chain=chain,
            amp=amp,
        )

        report = analyzer.analyze_coordinated_drift(alert)

        self.assertEqual(report.scope, "coordinated")
        self.assertEqual(report.agent_id, "root-agent")
        self.assertEqual(list(report.propagation_chain), chain)
        self.assertTrue(len(report.amplification_profile) > 0)

        # Root cause agent should be the intervention point (amplifying)
        self.assertEqual(report.recommended_intervention, "root-agent")

        self.assertIsNotNone(report.primary_hypothesis)
        # Should have upstream_propagation hypothesis
        all_types = [report.primary_hypothesis.cause_type] + [
            h.cause_type for h in report.alternative_hypotheses
        ]
        self.assertIn("upstream_propagation", all_types)

    def test_coordinated_attenuating_chain(self) -> None:
        """When drift is attenuating, intervention point should be middle."""
        chain = ["root-agent", "hop-1", "hop-2"]
        amp = [0.5, 0.3, 0.2]  # Attenuating

        observer = MagicMock()
        observer.get_drift.return_value = _make_drift(overall=0.5, action=0.4)

        analyzer = DriftCausalAnalyzer(fingerprint_observer=observer)
        alert = _make_fleet_alert(scope="coordinated", chain=chain, amp=amp)

        report = analyzer.analyze_coordinated_drift(alert)
        # Should recommend intervention at middle of chain
        self.assertEqual(report.recommended_intervention, "hop-1")


# ── Fleet Drift: Concentrated ─────────────────────────────────────────


class TestFleetConcentrated(TestCase):
    """Most drift from a few agents → concentrated movement type."""

    def test_fleet_concentrated(self) -> None:
        observer = MagicMock()
        # 10 agents: 1 very high-drift, 9 just above threshold
        # Drifting set has 10 agents. Top 20% = 2 agents.
        # Agent-0: 0.9, Agent-1: 0.5, others: 0.16
        # Top 2 drift = 0.9 + 0.5 = 1.4
        # Total drift = 1.4 + 8*0.16 = 2.68
        # Ratio = 1.4/2.68 = 0.52 → still distributed.
        #
        # Need: top 20% accounts for > 80% of total.
        # 5 agents: agent-0 = 0.9, agent-1..4 = 0.16
        # top 20% = 1 agent. Top drift = 0.9
        # Total = 0.9 + 4*0.16 = 1.54
        # 0.9/1.54 = 0.58 → distributed.
        #
        # Use extreme scenario: 1 drifter + rest below threshold.
        # Only 1 agent above threshold → top_20_count = max(1, 0) = 1
        # top_20_drift / total = 1.0 → concentrated.
        fps = {f"agent-{i}": MagicMock() for i in range(10)}
        observer.all_fingerprints.return_value = fps

        def get_drift(aid: str) -> DriftScore:
            if aid == "agent-0":
                return _make_drift(overall=0.8, action=0.7)
            return _make_drift(overall=0.05, action=0.02)

        observer.get_drift.side_effect = get_drift

        analyzer = DriftCausalAnalyzer(fingerprint_observer=observer)
        alert = _make_fleet_alert(scope="fleet")

        report = analyzer.analyze_fleet_drift(alert)

        self.assertEqual(report.scope, "fleet")
        self.assertEqual(report.fleet_movement_type, "concentrated")
        self.assertTrue(len(report.remediation) > 0)


# ── Fleet Drift: Distributed ─────────────────────────────────────────


class TestFleetDistributed(TestCase):
    """Drift spread across many agents → distributed movement type."""

    def test_fleet_distributed(self) -> None:
        observer = MagicMock()
        fps = {f"agent-{i}": MagicMock() for i in range(10)}
        observer.all_fingerprints.return_value = fps

        # All agents with similar moderate drift
        observer.get_drift.side_effect = lambda aid: _make_drift(
            overall=0.3, action=0.25,
        )

        analyzer = DriftCausalAnalyzer(fingerprint_observer=observer)
        alert = _make_fleet_alert(scope="fleet")

        report = analyzer.analyze_fleet_drift(alert)

        self.assertEqual(report.scope, "fleet")
        self.assertEqual(report.fleet_movement_type, "distributed")


# ── Auto-dispatch ─────────────────────────────────────────────────────


class TestAutoDispatch(TestCase):
    """analyze() should route correctly based on alert type."""

    def test_dispatch_agent_drift(self) -> None:
        analyzer = DriftCausalAnalyzer()
        alert = _make_agent_alert("test-agent")

        report = analyzer.analyze(alert)

        self.assertEqual(report.scope, "agent")
        self.assertEqual(report.agent_id, "test-agent")

    def test_dispatch_fleet_drift(self) -> None:
        observer = MagicMock()
        observer.all_fingerprints.return_value = {}
        observer.get_drift.return_value = None
        analyzer = DriftCausalAnalyzer(fingerprint_observer=observer)
        alert = _make_fleet_alert(scope="fleet")

        report = analyzer.analyze(alert)

        self.assertEqual(report.scope, "fleet")

    def test_dispatch_correlated_drift(self) -> None:
        analyzer = DriftCausalAnalyzer()
        alert = _make_fleet_alert(
            scope="correlated",
            affected=["a", "b"],
        )

        report = analyzer.analyze(alert)

        self.assertEqual(report.scope, "correlated")

    def test_dispatch_coordinated_drift(self) -> None:
        observer = MagicMock()
        observer.get_drift.return_value = _make_drift(overall=0.3)
        analyzer = DriftCausalAnalyzer(fingerprint_observer=observer)
        alert = _make_fleet_alert(
            scope="coordinated",
            chain=["a", "b", "c"],
            amp=[0.3, 0.35, 0.4],
        )

        report = analyzer.analyze(alert)

        self.assertEqual(report.scope, "coordinated")


# ── Report Serialization ──────────────────────────────────────────────


class TestReportSerialization(TestCase):
    """to_dict() and summary() should produce valid output."""

    def test_hypothesis_to_dict(self) -> None:
        h = CausalHypothesis(
            cause_type="config_change",
            confidence=0.85,
            description="Config changed at 14:22 UTC",
            evidence=("Record #1", "Record #2"),
            timestamp=1700000000.0,
        )
        d = h.to_dict()
        self.assertEqual(d["cause_type"], "config_change")
        self.assertEqual(d["confidence"], 0.85)
        self.assertEqual(len(d["evidence"]), 2)
        self.assertEqual(d["timestamp"], 1700000000.0)

    def test_report_to_dict(self) -> None:
        analyzer = DriftCausalAnalyzer()
        drift = _make_drift(overall=0.4, action=0.3, semantic=0.2)
        report = analyzer.analyze_agent_drift("test-agent", drift, time.time())

        d = report.to_dict()
        self.assertIn("alert_id", d)
        self.assertEqual(d["agent_id"], "test-agent")
        self.assertEqual(d["scope"], "agent")
        self.assertIn("primary_hypothesis", d)
        self.assertIsInstance(d["distributions_involved"], list)
        self.assertIsInstance(d["remediation"], list)
        self.assertIsInstance(d["alternative_hypotheses"], list)

    def test_report_summary(self) -> None:
        analyzer = DriftCausalAnalyzer()
        drift = _make_drift(overall=0.4, action=0.3, semantic=0.2)
        report = analyzer.analyze_agent_drift("test-agent", drift, time.time())

        summary = report.summary()
        self.assertIsInstance(summary, str)
        self.assertIn("Agent drift", summary)
        self.assertIn("test-agent", summary)
        self.assertIn("Hypothesis", summary)

    def test_correlated_summary(self) -> None:
        analyzer = DriftCausalAnalyzer()
        alert = _make_fleet_alert(
            scope="correlated",
            affected=["a", "b", "c"],
            shared_direction={"semantic": 0.3},
        )
        report = analyzer.analyze(alert)
        summary = report.summary()
        self.assertIn("Correlated", summary)
        self.assertIn("3 agents", summary)

    def test_coordinated_summary(self) -> None:
        observer = MagicMock()
        observer.get_drift.return_value = _make_drift(overall=0.3, action=0.2)
        analyzer = DriftCausalAnalyzer(fingerprint_observer=observer)
        alert = _make_fleet_alert(
            scope="coordinated",
            chain=["a", "b", "c"],
            amp=[0.3, 0.35, 0.4],
        )
        report = analyzer.analyze(alert)
        summary = report.summary()
        self.assertIn("Coordinated", summary)
        self.assertIn("3-hop", summary)

    def test_fleet_summary(self) -> None:
        observer = MagicMock()
        observer.all_fingerprints.return_value = {}
        observer.get_drift.return_value = None
        analyzer = DriftCausalAnalyzer(fingerprint_observer=observer)
        alert = _make_fleet_alert(scope="fleet")
        report = analyzer.analyze(alert)
        summary = report.summary()
        self.assertIn("Fleet", summary)

    def test_empty_report_summary(self) -> None:
        """A minimal report should still produce a valid summary."""
        report = DriftCausalReport(
            alert_id="test",
            agent_id="agent-1",
            scope="agent",
        )
        summary = report.summary()
        self.assertIsInstance(summary, str)
        self.assertIn("agent-1", summary)
