"""Tests for product tiering — dimension activation by subscription tier."""

from __future__ import annotations

import logging

import pytest

from nomotic.dimensions import DimensionRegistry
from nomotic.license import ActivatedTier
from nomotic.tiering import TIER_DIMENSIONS, ProductTier, TieringConfig


class TestTierDimensions:
    """Verify that each tier activates the correct number of dimensions."""

    def test_base_tier_has_8_dimensions(self):
        assert len(TIER_DIMENSIONS[ProductTier.BASE]) == 8

    def test_professional_tier_has_17_dimensions(self):
        assert len(TIER_DIMENSIONS[ProductTier.PROFESSIONAL]) == 17

    def test_enterprise_tier_has_20_dimensions(self):
        assert len(TIER_DIMENSIONS[ProductTier.ENTERPRISE]) == 20

    def test_base_dimensions_are_subset_of_professional(self):
        base = set(TIER_DIMENSIONS[ProductTier.BASE])
        pro = set(TIER_DIMENSIONS[ProductTier.PROFESSIONAL])
        assert base.issubset(pro)

    def test_professional_dimensions_are_subset_of_enterprise(self):
        pro = set(TIER_DIMENSIONS[ProductTier.PROFESSIONAL])
        ent = set(TIER_DIMENSIONS[ProductTier.ENTERPRISE])
        assert pro.issubset(ent)

    def test_base_includes_expected_dimensions(self):
        names = set(TIER_DIMENSIONS[ProductTier.BASE])
        expected = {
            "scope_compliance",
            "authority_verification",
            "resource_boundaries",
            "isolation_integrity",
            "temporal_compliance",
            "human_override",
            "reversibility",
            "data_sensitivity_classification",
        }
        assert names == expected

    def test_enterprise_tier_covers_core_dimensions(self):
        """Enterprise tier config includes all core dimension names."""
        from nomotic.dimensions import CORE_DIMENSION_NAMES
        enterprise_names = set(TIER_DIMENSIONS[ProductTier.ENTERPRISE])
        assert CORE_DIMENSION_NAMES.issubset(enterprise_names)

    def test_default_registry_has_14_core_dimensions(self):
        """Default registry (OPEN) has exactly the 14 core dimensions."""
        registry = DimensionRegistry.create_default()
        assert len(registry.dimensions) == 14


class TestTieringConfig:
    """TieringConfig resolves active dimension names correctly."""

    def test_default_tier_is_professional(self):
        cfg = TieringConfig()
        assert cfg.tier == ProductTier.PROFESSIONAL

    def test_active_names_matches_tier(self):
        cfg = TieringConfig(tier=ProductTier.BASE)
        assert set(cfg.active_dimension_names()) == set(TIER_DIMENSIONS[ProductTier.BASE])

    def test_custom_enabled_adds_dimension(self):
        cfg = TieringConfig(
            tier=ProductTier.BASE,
            custom_enabled=["transparency"],
        )
        names = cfg.active_dimension_names()
        assert "transparency" in names
        assert len(names) == 9  # 8 base + 1 custom

    def test_custom_disabled_removes_dimension(self):
        cfg = TieringConfig(
            tier=ProductTier.BASE,
            custom_disabled=["reversibility"],
        )
        names = cfg.active_dimension_names()
        assert "reversibility" not in names
        assert len(names) == 7

    def test_custom_enable_and_disable_together(self):
        cfg = TieringConfig(
            tier=ProductTier.BASE,
            custom_enabled=["transparency"],
            custom_disabled=["human_override"],
        )
        names = cfg.active_dimension_names()
        assert "transparency" in names
        assert "human_override" not in names
        assert len(names) == 8  # 8 - 1 + 1

    def test_disabling_already_absent_dimension_is_noop(self):
        cfg = TieringConfig(
            tier=ProductTier.BASE,
            custom_disabled=["transparency"],  # not in base
        )
        assert len(cfg.active_dimension_names()) == 8


class TestDimensionRegistryActiveDimensions:
    """DimensionRegistry.active_dimensions() returns filtered dimensions."""

    def test_base_returns_core_only(self):
        """BASE tier with no plugins returns only the core dimensions in that tier."""
        registry = DimensionRegistry.create_default()
        dims = registry.active_dimensions(ProductTier.BASE)
        # BASE lists 8 dimensions but 2 are plugin (D15, D17), so 6 core remain
        assert len(dims) == 6

    def test_professional_returns_core_only(self):
        """PROFESSIONAL tier with no plugins returns only available core dimensions."""
        registry = DimensionRegistry.create_default()
        dims = registry.active_dimensions(ProductTier.PROFESSIONAL)
        # PROFESSIONAL lists 17 but 5 are plugin dims, so 12 core remain
        assert len(dims) == 12

    def test_enterprise_returns_core_only(self):
        """ENTERPRISE tier with no plugins returns only available core dimensions."""
        registry = DimensionRegistry.create_default()
        dims = registry.active_dimensions(ProductTier.ENTERPRISE)
        # ENTERPRISE lists 20 but 6 are plugin dims, so 14 core remain
        assert len(dims) == 14

    def test_custom_enabled_works_through_registry(self):
        registry = DimensionRegistry.create_default()
        dims = registry.active_dimensions(
            ProductTier.BASE,
            custom_enabled=["transparency"],
        )
        names = {d.name for d in dims}
        assert "transparency" in names
        assert len(dims) == 7

    def test_custom_disabled_works_through_registry(self):
        registry = DimensionRegistry.create_default()
        dims = registry.active_dimensions(
            ProductTier.BASE,
            custom_disabled=["scope_compliance"],
        )
        names = {d.name for d in dims}
        assert "scope_compliance" not in names
        assert len(dims) == 5

    def test_returns_actual_dimension_instances(self):
        from nomotic.dimensions import GovernanceDimension
        registry = DimensionRegistry.create_default()
        dims = registry.active_dimensions(ProductTier.BASE)
        for d in dims:
            assert isinstance(d, GovernanceDimension)


class TestUCSNormalizesAcrossActiveOnly:
    """UCS engine normalizes across active dimensions only."""

    def test_ucs_computed_from_active_dimensions_only(self):
        from nomotic.ucs import UCSEngine
        from nomotic.types import DimensionScore, TrustProfile

        engine = UCSEngine(trust_influence=0.0)

        # 3 scores all at 0.8 — UCS should be 0.8
        scores = [
            DimensionScore(dimension_name="a", score=0.8, confidence=1.0, weight=1.0),
            DimensionScore(dimension_name="b", score=0.8, confidence=1.0, weight=1.0),
            DimensionScore(dimension_name="c", score=0.8, confidence=1.0, weight=1.0),
        ]
        trust = TrustProfile(agent_id="test", overall_trust=0.5)
        ucs = engine.compute(scores, trust)
        assert abs(ucs - 0.8) < 0.01

    def test_fewer_active_dimensions_still_normalizes(self):
        """With fewer dimensions (base tier), UCS still normalizes correctly."""
        from nomotic.ucs import UCSEngine
        from nomotic.types import DimensionScore, TrustProfile

        engine = UCSEngine(trust_influence=0.0)

        # Simulate base tier: only 8 dimension scores, all at 0.9
        scores = [
            DimensionScore(
                dimension_name=f"dim_{i}", score=0.9, confidence=1.0, weight=1.0
            )
            for i in range(8)
        ]
        trust = TrustProfile(agent_id="test", overall_trust=0.5)
        ucs = engine.compute(scores, trust)
        assert abs(ucs - 0.9) < 0.01

    def test_ucs_normalizes_14_vs_20_active_dimensions(self):
        """UCS normalizes correctly regardless of whether 14 or 20 dims active."""
        from nomotic.ucs import UCSEngine
        from nomotic.types import DimensionScore, TrustProfile

        engine = UCSEngine(trust_influence=0.0)

        # 14 dimensions (D1–D14, core only, no plugins) all at 0.75
        scores_14 = [
            DimensionScore(
                dimension_name=f"dim_{i}", score=0.75, confidence=1.0, weight=1.0
            )
            for i in range(14)
        ]
        # 20 dimensions (core + plugins) all at 0.75
        scores_20 = [
            DimensionScore(
                dimension_name=f"dim_{i}", score=0.75, confidence=1.0, weight=1.0
            )
            for i in range(20)
        ]
        trust = TrustProfile(agent_id="test", overall_trust=0.5)
        ucs_14 = engine.compute(scores_14, trust)
        ucs_20 = engine.compute(scores_20, trust)
        # Both should normalize to the same score
        assert abs(ucs_14 - 0.75) < 0.01
        assert abs(ucs_20 - 0.75) < 0.01


class TestRuntimeTieringIntegration:
    """RuntimeConfig.tiering filters dimensions in the runtime pipeline."""

    def test_runtime_accepts_tiering_config(self):
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        cfg = RuntimeConfig(tiering=TieringConfig(tier=ProductTier.BASE))
        runtime = GovernanceRuntime(config=cfg)
        assert runtime.config.tiering is not None
        assert runtime.config.tiering.tier == ProductTier.BASE

    def test_runtime_without_tiering_uses_all_dimensions(self):
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        runtime = GovernanceRuntime(config=RuntimeConfig())
        # Without tiering (OPEN by default), all 14 core dimensions (D1–D14) are available
        assert len(runtime.registry.dimensions) == 14

    def test_runtime_activated_tier_property(self):
        """GovernanceRuntime exposes activated_tier as a property."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        runtime = GovernanceRuntime(config=RuntimeConfig())
        assert runtime.activated_tier == ActivatedTier.OPEN

    def test_pro_tier_without_plugins_logs_warning(self, caplog):
        """Pro license with no plugin package installed logs specific warning."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        from nomotic.license import LicenseConfig

        # Create a runtime that resolves to PRO tier.
        # Without nomotic-pro installed, plugin count will be 0.
        # We mock the license gate to return PRO tier.
        from unittest.mock import patch, MagicMock

        mock_info = MagicMock()
        mock_info.tier = ActivatedTier.PRO
        mock_info.validation_error = None

        with patch("nomotic.runtime.LicenseGate") as mock_gate_cls:
            mock_gate = MagicMock()
            mock_gate.resolve.return_value = mock_info
            mock_gate.warn_if_expired_soon.return_value = None
            mock_gate_cls.return_value = mock_gate

            with caplog.at_level(logging.WARNING, logger="nomotic.license"):
                runtime = GovernanceRuntime(config=RuntimeConfig())

        assert runtime.activated_tier == ActivatedTier.PRO
        # Should have 14 core dimensions (no plugins available)
        assert len(runtime.registry.dimensions) == 14
        assert runtime.registry.available_count()["plugin"] == 0
        # Warning should mention nomotic-pro installation
        assert any("nomotic-pro" in record.message for record in caplog.records)
        assert any("D15" in record.message for record in caplog.records)

    def test_pro_tier_without_plugins_still_returns_14_dimensions(self, caplog):
        """Pro tier without plugins gracefully falls back to 14 core dimensions."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        from unittest.mock import patch, MagicMock

        mock_info = MagicMock()
        mock_info.tier = ActivatedTier.PRO
        mock_info.validation_error = None

        with patch("nomotic.runtime.LicenseGate") as mock_gate_cls:
            mock_gate = MagicMock()
            mock_gate.resolve.return_value = mock_info
            mock_gate.warn_if_expired_soon.return_value = None
            mock_gate_cls.return_value = mock_gate

            with caplog.at_level(logging.WARNING, logger="nomotic.license"):
                runtime = GovernanceRuntime(config=RuntimeConfig())

        # All 14 core dims available, governance works fine
        assert len(runtime.registry.dimensions) == 14
        dim_names = {d.name for d in runtime.registry.dimensions}
        assert "scope_compliance" in dim_names
        assert "ethical_alignment" in dim_names

    def test_free_tier_returns_14_dimensions(self):
        """Free tier (OPEN) returns all 14 core dimensions (D1–D14), no warning."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        runtime = GovernanceRuntime(config=RuntimeConfig())
        assert runtime.activated_tier == ActivatedTier.OPEN
        assert len(runtime.registry.dimensions) == 14

    def test_custom_disabled_removes_dimension_from_active_set(self):
        """custom_disabled correctly removes a dimension from the active set."""
        registry = DimensionRegistry.create_default()
        dims = registry.active_dimensions(
            ProductTier.ENTERPRISE,
            custom_disabled=["transparency", "ethical_alignment"],
        )
        names = {d.name for d in dims}
        assert "transparency" not in names
        assert "ethical_alignment" not in names
        assert len(dims) == 12  # 14 core - 2 disabled
