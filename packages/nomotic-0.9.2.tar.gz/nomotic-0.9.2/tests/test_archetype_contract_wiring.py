"""Tests for archetype contract → governance dimension wiring.

Covers the full wire-up: RuntimeConfig.archetype → GovernanceRuntime.__init__
→ ScopeCompliance / TemporalCompliance / HumanOverride / EthicalAlignment.
"""

from __future__ import annotations

import pytest

from nomotic.archetype_contracts import ARCHETYPE_CONTRACTS, get_contract
from nomotic.dimensions import (
    EthicalAlignment,
    HumanOverride,
    ScopeCompliance,
    TemporalCompliance,
)
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import Action, AgentContext, TrustProfile


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ctx(agent_id: str = "test-agent", trust: float = 0.72) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


# ---------------------------------------------------------------------------
# RuntimeConfig
# ---------------------------------------------------------------------------


class TestRuntimeConfigArchetype:
    def test_runtime_config_accepts_archetype_field(self):
        cfg = RuntimeConfig(archetype="scheduling")
        assert cfg.archetype == "scheduling"

    def test_runtime_config_default_archetype_is_none(self):
        cfg = RuntimeConfig()
        assert cfg.archetype is None


# ---------------------------------------------------------------------------
# GovernanceRuntime auto-loading
# ---------------------------------------------------------------------------


class TestGovernanceRuntimeLoadsContract:
    def test_governance_runtime_loads_contract_on_init(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="scheduling"))
        scope = runtime.registry.get("scope_compliance")
        assert hasattr(scope, "_deny_categories")
        assert len(scope._deny_categories) > 0

    def test_unknown_archetype_no_crash(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="nonexistent-xyz"))
        scope = runtime.registry.get("scope_compliance")
        # Should not have loaded anything
        assert not getattr(scope, "_deny_categories", set())


# ---------------------------------------------------------------------------
# ScopeCompliance
# ---------------------------------------------------------------------------


class TestScopeComplianceDenyCategory:
    def test_scope_compliance_deny_category_vetoes(self):
        scope = ScopeCompliance()
        contract = get_contract("scheduling")
        scope.load_archetype_contract(contract)

        action = Action(action_type="creative_content", target="user", parameters={})
        score = scope.evaluate(action, _ctx())
        assert score.veto is True
        assert score.score == 0.0
        assert "outside authorized scope" in score.reasoning

    def test_scope_compliance_authorized_category_passes(self):
        scope = ScopeCompliance()
        contract = get_contract("scheduling")
        scope.load_archetype_contract(contract)

        action = Action(action_type="book_meeting", target="calendar", parameters={})
        score = scope.evaluate(action, _ctx())
        assert score.score == 1.0
        assert "explicitly authorized" in score.reasoning

    def test_scope_compliance_escalate_category(self):
        scope = ScopeCompliance()
        contract = get_contract("scheduling")
        scope.load_archetype_contract(contract)

        action = Action(action_type="book_on_behalf", target="calendar", parameters={})
        score = scope.evaluate(action, _ctx())
        assert score.score == 0.3
        assert "escalation" in score.reasoning


# ---------------------------------------------------------------------------
# TemporalCompliance
# ---------------------------------------------------------------------------


class TestTemporalComplianceDays:
    def test_temporal_compliance_blocks_saturday(self):
        temporal = TemporalCompliance()
        contract = get_contract("scheduling")
        temporal.load_archetype_contract(contract)

        action = Action(
            action_type="book_meeting",
            target="calendar",
            parameters={"day_of_week": "saturday", "hour": 10},
        )
        score = temporal.evaluate(action, _ctx())
        assert score.veto is True
        assert score.score == 0.0
        assert "Saturday" in score.reasoning

    def test_temporal_compliance_blocks_sunday(self):
        temporal = TemporalCompliance()
        contract = get_contract("scheduling")
        temporal.load_archetype_contract(contract)

        action = Action(
            action_type="book_meeting",
            target="calendar",
            parameters={"day_of_week": "sunday", "hour": 10},
        )
        score = temporal.evaluate(action, _ctx())
        assert score.veto is True
        assert score.score == 0.0

    def test_temporal_compliance_allows_tuesday(self):
        temporal = TemporalCompliance()
        contract = get_contract("scheduling")
        temporal.load_archetype_contract(contract)

        action = Action(
            action_type="book_meeting",
            target="calendar",
            parameters={"day_of_week": "tuesday", "hour": 10},
        )
        score = temporal.evaluate(action, _ctx())
        assert score.score == 1.0


class TestTemporalComplianceHours:
    def test_temporal_compliance_blocks_after_hours(self):
        temporal = TemporalCompliance()
        contract = get_contract("scheduling")
        temporal.load_archetype_contract(contract)

        action = Action(
            action_type="book_meeting",
            target="calendar",
            parameters={"day_of_week": "wednesday", "hour": 20},
        )
        score = temporal.evaluate(action, _ctx())
        assert score.veto is True
        assert score.score == 0.0
        assert "outside authorized hours" in score.reasoning

    def test_temporal_compliance_allows_business_hours(self):
        temporal = TemporalCompliance()
        contract = get_contract("scheduling")
        temporal.load_archetype_contract(contract)

        action = Action(
            action_type="book_meeting",
            target="calendar",
            parameters={"day_of_week": "wednesday", "hour": 14},
        )
        score = temporal.evaluate(action, _ctx())
        assert score.score == 1.0

    def test_temporal_compliance_blocks_long_meeting(self):
        temporal = TemporalCompliance()
        contract = get_contract("scheduling")
        temporal.load_archetype_contract(contract)

        action = Action(
            action_type="book_meeting",
            target="calendar",
            parameters={"day_of_week": "monday", "hour": 10, "duration_hrs": 6},
        )
        score = temporal.evaluate(action, _ctx())
        assert score.veto is True
        assert "exceeds maximum" in score.reasoning


# ---------------------------------------------------------------------------
# HumanOverride
# ---------------------------------------------------------------------------


class TestHumanOverrideContract:
    def test_human_override_loads_override_actions(self):
        ho = HumanOverride()
        contract = get_contract("scheduling")
        ho.load_archetype_contract(contract)

        assert "book_on_behalf_executive" in ho._require_human
        assert "block_calendar_extended" in ho._require_human

    def test_human_override_escalate_categories_require_human(self):
        ho = HumanOverride()
        contract = get_contract("scheduling")
        ho.load_archetype_contract(contract)

        # "book_on_behalf" has authorized_action_categories == "escalate"
        assert "book_on_behalf" in ho._require_human


# ---------------------------------------------------------------------------
# EthicalAlignment
# ---------------------------------------------------------------------------


class TestEthicsConstraints:
    def test_ethics_blocks_quantity_anomaly(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="order-processing"))
        ethics = runtime.registry.get("ethical_alignment")
        assert ethics is not None

        action = Action(
            action_type="place_order",
            target="inventory",
            parameters={"quantity": 200, "baseline_quantity": 10},
        )
        score = ethics.evaluate(action, _ctx())
        assert score.score == 0.0
        assert score.veto is True

    def test_ethics_blocks_hotel_rate_above_cap(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="travel-booking"))
        ethics = runtime.registry.get("ethical_alignment")

        action = Action(
            action_type="book_hotel",
            target="hotel-system",
            parameters={"rate_usd": 400},
        )
        score = ethics.evaluate(action, _ctx())
        assert score.score == 0.0

    def test_ethics_blocks_first_class_flight(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="travel-booking"))
        ethics = runtime.registry.get("ethical_alignment")

        action = Action(
            action_type="book_flight",
            target="airline-api",
            parameters={"flight_class": "first"},
        )
        score = ethics.evaluate(action, _ctx())
        assert score.score == 0.0

    def test_ethics_allows_economy_flight(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="travel-booking"))
        ethics = runtime.registry.get("ethical_alignment")

        action = Action(
            action_type="book_flight",
            target="airline-api",
            parameters={"flight_class": "economy"},
        )
        score = ethics.evaluate(action, _ctx())
        # Economy should pass all rules
        assert score.score > 0.0


# ---------------------------------------------------------------------------
# Full integration: scheduling agent
# ---------------------------------------------------------------------------


class TestFullSchedulingAgent:
    def test_full_scheduling_agent_saturday_deny(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="scheduling"))
        action = Action(
            action_type="book_meeting",
            target="calendar",
            parameters={"day_of_week": "saturday", "hour": 10, "duration_hrs": 1},
        )
        context = _ctx()
        verdict = runtime.evaluate(action, context)
        assert verdict.verdict.name == "DENY"
        assert any(
            ds.veto
            for ds in verdict.dimension_scores
            if ds.dimension_name == "temporal_compliance"
        )

    def test_full_scheduling_agent_tuesday_allow(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="scheduling"))
        action = Action(
            action_type="book_meeting",
            target="calendar",
            parameters={"day_of_week": "tuesday", "hour": 14, "duration_hrs": 1},
        )
        context = _ctx()
        verdict = runtime.evaluate(action, context)
        assert verdict.verdict.name == "ALLOW"

    def test_full_scheduling_agent_after_hours_deny(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="scheduling"))
        action = Action(
            action_type="book_meeting",
            target="calendar",
            parameters={"day_of_week": "monday", "hour": 22, "duration_hrs": 1},
        )
        context = _ctx()
        verdict = runtime.evaluate(action, context)
        assert verdict.verdict.name == "DENY"


# ---------------------------------------------------------------------------
# Full integration: travel agent
# ---------------------------------------------------------------------------


class TestFullTravelAgent:
    def test_full_travel_agent_first_class_deny(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="travel-booking"))
        action = Action(
            action_type="book_flight",
            target="airline-api",
            parameters={"flight_class": "first", "day_of_week": "tuesday", "hour": 10},
        )
        verdict = runtime.evaluate(action, _ctx())
        assert verdict.verdict.name == "DENY"

    def test_full_travel_agent_economy_allow(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="travel-booking"))
        action = Action(
            action_type="book_flight",
            target="airline-api",
            parameters={
                "flight_class": "economy",
                "day_of_week": "wednesday",
                "hour": 10,
            },
        )
        verdict = runtime.evaluate(action, _ctx())
        assert verdict.verdict.name == "ALLOW"

    def test_full_travel_agent_hotel_over_cap_escalate(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="travel-booking"))
        action = Action(
            action_type="book_hotel",
            target="hotel-system",
            parameters={"rate_usd": 400, "day_of_week": "tuesday", "hour": 10},
        )
        verdict = runtime.evaluate(action, _ctx())
        # Hotel over cap triggers ethics veto → DENY
        assert verdict.verdict.name == "DENY"


# ---------------------------------------------------------------------------
# Full integration: order processing agent
# ---------------------------------------------------------------------------


class TestFullOrderAgent:
    def test_full_order_agent_quantity_anomaly_escalate(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="order-processing"))
        action = Action(
            action_type="place_order",
            target="inventory",
            parameters={"quantity": 500, "baseline_quantity": 10},
        )
        verdict = runtime.evaluate(action, _ctx())
        assert verdict.verdict.name == "DENY"

    def test_full_order_agent_normal_quantity_allow(self):
        runtime = GovernanceRuntime(config=RuntimeConfig(archetype="order-processing"))
        action = Action(
            action_type="place_order",
            target="inventory",
            parameters={"quantity": 5, "baseline_quantity": 10},
        )
        verdict = runtime.evaluate(action, _ctx())
        assert verdict.verdict.name == "ALLOW"
