"""Smoke and workflow tests for the Policy Evolution Dashboard UI.

Tests:
1. Smoke test: panel loads without JS errors against a runtime with populated audit data
2. Approval workflow: approve a recommendation via the UI and confirm the ChangeRecord
   appears in Change History
"""

import json
import threading
import time
import uuid
from pathlib import Path
from types import SimpleNamespace

import pytest

from nomotic.api import NomoticAPIServer
from nomotic.audit import (
    AccountabilityRecord,
    AuditRecord,
    AuditTrail,
    ChangeRecord,
    OutcomeRecord,
)
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.store import MemoryCertificateStore


# ── Helpers ──────────────────────────────────────────────────────────────


def _make_runtime_with_data():
    """Build a minimal runtime-like object with a populated audit trail."""
    trail = AuditTrail(max_records=1000)

    # Seed decisions and accountability records for exception cluster detection
    now = time.time()
    for i in range(12):
        aid = f"action-override-{i}"
        trail.append(AuditRecord(
            record_id=uuid.uuid4().hex[:12],
            timestamp=now - (i * 3600),
            context_code="GOVERNANCE.DENY",
            severity="info",
            agent_id="agent-1",
            owner_id="owner@example.com",
            user_id="user@example.com",
            action_id=aid,
            action_type="data_export",
            action_target="/data/sensitive",
            verdict="DENY",
            ucs=0.35,
            tier=2,
            dimension_scores=[],
        ))
        trail.append_accountability(AccountabilityRecord(
            record_id=uuid.uuid4().hex[:12],
            action_id=aid,
            human_id="admin@example.com",
            human_action="override_approved",
            original_verdict="DENY",
            resulting_verdict="ALLOW",
            stated_rationale="Business-critical export approved by data owner",
            timestamp=now - (i * 3600) + 60,
        ))

    # Seed outcome records for outcome correlation
    for i in range(10):
        trail.append_outcome(OutcomeRecord(
            record_id=uuid.uuid4().hex[:12],
            action_id=f"action-outcome-{i}",
            agent_id="agent-1",
            decision_verdict="ALLOW",
            outcome_signals={"status": "completed"},
            outcome_at=now - (i * 86400),
            outcome_validated=True,
            override_occurred=(i < 3),  # 30% override rate
            override_reason="Manual correction" if i < 3 else None,
            timestamp=now - (i * 86400),
        ))

    # Build a minimal runtime-like object
    runtime = SimpleNamespace(
        audit_trail=trail,
        provenance_log=None,
    )
    return runtime


def _setup_server(runtime=None):
    """Create a running API server with the given runtime."""
    import tempfile

    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=store)
    base_dir = Path(tempfile.mkdtemp())

    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        runtime=runtime,
        host="127.0.0.1",
        port=0,
        base_dir=base_dir,
        ui_enabled=True,
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]
    return httpd, port


def _get(port, path):
    """GET request helper."""
    import urllib.request
    import urllib.error
    url = f"http://127.0.0.1:{port}{path}"
    try:
        with urllib.request.urlopen(url) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read()


def _get_json(port, path):
    """GET request that parses JSON."""
    status, body = _get(port, path)
    return status, json.loads(body.decode("utf-8"))


def _post_json(port, path, data=None):
    """POST request helper."""
    import urllib.request
    import urllib.error
    url = f"http://127.0.0.1:{port}{path}"
    body = json.dumps(data or {}).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


# ── Tests ────────────────────────────────────────────────────────────────


class TestPolicyEvolutionUISmoke:
    """Smoke test: panel loads without errors."""

    def test_panel_html_loads(self):
        """The policy-evolution HTML page is served successfully."""
        runtime = _make_runtime_with_data()
        httpd, port = _setup_server(runtime)
        try:
            status, body = _get(port, "/ui/policy-evolution")
            assert status == 200
            html = body.decode("utf-8")
            assert "Policy Evolution" in html
            assert "Pattern View" in html
            assert "Recommendation Queue" in html
            assert "Exception Review" in html
            assert "Outcome Correlation" in html
            assert "Change History" in html
        finally:
            httpd.shutdown()

    def test_patterns_api_returns_data(self):
        """Patterns endpoint returns data with populated audit trail."""
        runtime = _make_runtime_with_data()
        httpd, port = _setup_server(runtime)
        try:
            status, data = _get_json(port, "/v1/policy-evolution/patterns")
            assert status == 200
            assert "patterns" in data
            assert "total" in data
            # With 7 overrides on data_export, we should detect at least one pattern
            assert data["total"] >= 1
        finally:
            httpd.shutdown()

    def test_recommendations_api_returns(self):
        """Recommendations endpoint returns without error."""
        runtime = _make_runtime_with_data()
        httpd, port = _setup_server(runtime)
        try:
            status, data = _get_json(port, "/v1/policy-evolution/recommendations")
            assert status == 200
            assert "recommendations" in data
        finally:
            httpd.shutdown()

    def test_accountability_api_returns(self):
        """Accountability endpoint (used by Exception Review) returns data."""
        runtime = _make_runtime_with_data()
        httpd, port = _setup_server(runtime)
        try:
            status, data = _get_json(port, "/v1/audit/accountability?limit=100")
            assert status == 200
            assert "records" in data
            assert data["total"] >= 12
        finally:
            httpd.shutdown()

    def test_outcomes_api_returns(self):
        """Outcomes endpoint (used by Outcome Correlation) returns data."""
        runtime = _make_runtime_with_data()
        httpd, port = _setup_server(runtime)
        try:
            status, data = _get_json(port, "/v1/audit/outcomes?limit=500")
            assert status == 200
            assert "records" in data
            assert data["total"] >= 10
        finally:
            httpd.shutdown()

    def test_changes_api_returns(self):
        """Changes endpoint (used by Change History) returns without error."""
        runtime = _make_runtime_with_data()
        httpd, port = _setup_server(runtime)
        try:
            status, data = _get_json(
                port, "/v1/audit/changes?change_type=policy_evolution&limit=100"
            )
            assert status == 200
            assert "records" in data
        finally:
            httpd.shutdown()

    def test_nav_link_present_in_dashboard(self):
        """The dashboard index includes a link to the policy evolution panel."""
        runtime = _make_runtime_with_data()
        httpd, port = _setup_server(runtime)
        try:
            status, body = _get(port, "/ui/")
            assert status == 200
            html = body.decode("utf-8")
            assert "/ui/policy-evolution" in html
            assert "Policy Evolution" in html
        finally:
            httpd.shutdown()


class TestPolicyEvolutionApprovalWorkflow:
    """Approval workflow: approve → apply → confirm ChangeRecord."""

    def test_approve_and_apply_creates_change_record(self):
        """Full workflow: get recommendations, approve one, apply it, check change history."""
        runtime = _make_runtime_with_data()
        httpd, port = _setup_server(runtime)
        try:
            # 1. Trigger pattern analysis to generate recommendations
            status, patterns = _get_json(port, "/v1/policy-evolution/patterns")
            assert status == 200
            assert patterns["total"] >= 1

            # 2. Get pending recommendations
            status, recs = _get_json(port, "/v1/policy-evolution/recommendations")
            assert status == 200
            assert recs["total"] >= 1, "Expected at least one recommendation"
            rec = recs["recommendations"][0]
            rec_id = rec["recommendation_id"]
            assert rec["status"] == "pending"

            # 3. Approve the recommendation
            status, result = _post_json(
                port,
                f"/v1/policy-evolution/recommendations/{rec_id}/approve",
                {"approved_by": "test-reviewer", "note": "Looks good"},
            )
            assert status == 200
            assert result["status"] == "approved"

            # 4. Apply the approved recommendation
            status, result = _post_json(
                port,
                f"/v1/policy-evolution/recommendations/{rec_id}/apply",
                {},
            )
            assert status == 200
            assert result["status"] == "applied"
            change_record = result["change_record"]
            assert change_record["change_type"] == "policy_evolution"
            assert change_record["component"] == "governance_config"
            assert f"policy_evolution:{rec_id}" == change_record["source"]

            # 5. Verify the ChangeRecord appears in change history
            status, changes = _get_json(
                port, "/v1/audit/changes?change_type=policy_evolution&limit=100"
            )
            assert status == 200
            assert changes["total"] >= 1
            change_ids = [c["record_id"] for c in changes["records"]]
            assert change_record["record_id"] in change_ids

        finally:
            httpd.shutdown()

    def test_reject_requires_note_semantics(self):
        """Rejecting a recommendation records the rejection."""
        runtime = _make_runtime_with_data()
        httpd, port = _setup_server(runtime)
        try:
            # Trigger analysis
            _get_json(port, "/v1/policy-evolution/patterns")
            status, recs = _get_json(port, "/v1/policy-evolution/recommendations")
            assert status == 200
            if recs["total"] == 0:
                pytest.skip("No recommendations generated")
            rec_id = recs["recommendations"][0]["recommendation_id"]

            # Reject with a note
            status, result = _post_json(
                port,
                f"/v1/policy-evolution/recommendations/{rec_id}/reject",
                {"rejected_by": "test-reviewer", "note": "Not applicable"},
            )
            assert status == 200
            assert result["status"] == "rejected"

            # Verify it's no longer in pending recommendations
            status, recs2 = _get_json(port, "/v1/policy-evolution/recommendations")
            assert status == 200
            pending_ids = [
                r["recommendation_id"]
                for r in recs2["recommendations"]
                if r["status"] == "pending"
            ]
            assert rec_id not in pending_ids

        finally:
            httpd.shutdown()

    def test_apply_without_approve_fails(self):
        """Applying a recommendation that hasn't been approved returns 400."""
        runtime = _make_runtime_with_data()
        httpd, port = _setup_server(runtime)
        try:
            _get_json(port, "/v1/policy-evolution/patterns")
            status, recs = _get_json(port, "/v1/policy-evolution/recommendations")
            if recs["total"] == 0:
                pytest.skip("No recommendations generated")
            rec_id = recs["recommendations"][0]["recommendation_id"]

            # Try to apply without approving first
            status, result = _post_json(
                port,
                f"/v1/policy-evolution/recommendations/{rec_id}/apply",
                {},
            )
            assert status == 400

        finally:
            httpd.shutdown()
