"""Tests for Trajectory & Policy API endpoints (Ticket 12).

Tests cover:
- GET /v1/trajectory/{agent_id} returns projection and policy.
- GET /v1/trajectory/{agent_id}/history returns historical data.
- GET /v1/trajectory/fleet returns fleet summary.
- POST /v1/trajectory/simulate returns simulated trajectory.
- Graceful degradation with optimizer disabled (v0.7.0 projection only).
"""

from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request
from typing import Any
from unittest.mock import MagicMock

import pytest

from nomotic.api import NomoticAPIServer
from nomotic.authority import CertificateAuthority
from nomotic.contract import BehavioralContract, ContractStore
from nomotic.drift import DriftScore
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.store import MemoryCertificateStore
from nomotic.trajectory_engine import (
    BehavioralTrajectoryEngine,
    InterventionAction,
    TrajectoryConfig,
    TrajectoryProjection,
)


# ── Helpers ──────────────────────────────────────────────────────────────


def _find_free_port() -> int:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class APITestClient:
    """Minimal HTTP client for testing the API."""

    def __init__(self, base_url: str) -> None:
        self.base_url = base_url

    def get(self, path: str) -> tuple[int, dict[str, Any]]:
        url = f"{self.base_url}{path}"
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req) as resp:
                body = json.loads(resp.read())
                return resp.status, body
        except urllib.error.HTTPError as e:
            body = json.loads(e.read())
            return e.code, body

    def post(self, path: str, data: dict[str, Any] | None = None) -> tuple[int, dict[str, Any]]:
        url = f"{self.base_url}{path}"
        payload = json.dumps(data or {}).encode("utf-8")
        try:
            req = urllib.request.Request(
                url, data=payload, method="POST",
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req) as resp:
                body = json.loads(resp.read())
                return resp.status, body
        except urllib.error.HTTPError as e:
            body = json.loads(e.read())
            return e.code, body


def _make_drift(
    overall: float = 0.0,
    action: float = 0.0,
    target: float = 0.0,
    temporal: float = 0.0,
    outcome: float = 0.0,
    semantic: float = 0.0,
) -> DriftScore:
    return DriftScore(
        overall=overall,
        action_drift=action,
        target_drift=target,
        temporal_drift=temporal,
        outcome_drift=outcome,
        semantic_drift=semantic,
        confidence=0.9,
        window_size=100,
        baseline_size=500,
    )


def _make_contract(agent_id: str = "agent-1") -> BehavioralContract:
    return BehavioralContract(
        contract_id="contract-1",
        version=1,
        agent_id=agent_id,
        created_at=time.time(),
        drift_thresholds={
            "action": 0.40,
            "target": 0.40,
            "temporal": 0.40,
            "outcome": 0.40,
            "semantic": 0.40,
        },
        invariants=[],
    )


def _build_runtime_with_trajectory(
    enable_optimizer: bool = False,
) -> Any:
    """Build a mock runtime with a real trajectory engine."""
    from nomotic.observer import FingerprintObserver

    observer = MagicMock(spec=FingerprintObserver)
    drift = _make_drift(overall=0.15, action=0.10, target=0.12)
    observer.get_drift.return_value = drift
    observer.get_fingerprint.return_value = None
    observer.get_semantic_drift.return_value = None

    contract_store = ContractStore()
    contract = _make_contract("agent-1")
    contract_store.store(contract)

    policy_optimizer = None
    if enable_optimizer:
        from nomotic.policy_optimizer import OptimizerConfig, PolicyOptimizer
        policy_optimizer = PolicyOptimizer(
            config=OptimizerConfig(n_rollouts=10, timeout_seconds=2.0, horizon=50),
        )

    engine = BehavioralTrajectoryEngine(
        config=TrajectoryConfig(
            projection_horizon=100,
            check_interval=1,
            enable_auto_intervention=True,
        ),
        fingerprint_observer=observer,
        contract_store=contract_store,
        policy_optimizer=policy_optimizer,
    )

    # Record some drift observations and trigger a projection
    for i in range(3):
        d = _make_drift(
            overall=0.10 + i * 0.02,
            action=0.08 + i * 0.01,
            target=0.09 + i * 0.015,
        )
        engine.on_observation("agent-1", d)

    runtime = MagicMock()
    runtime._trajectory_engine = engine
    runtime.get_trajectory_projection.side_effect = lambda aid: (
        engine.get_projection(aid).to_dict() if engine.get_projection(aid) else None
    )
    runtime.get_trajectory_interventions.side_effect = lambda aid=None: [
        i.to_dict() for i in engine.get_interventions(aid)
    ]

    return runtime


# ── Fixtures ─────────────────────────────────────────────────────────────


@pytest.fixture(scope="module")
def trajectory_server() -> tuple[APITestClient, Any]:
    """Start a test API server with trajectory engine enabled."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    runtime = _build_runtime_with_trajectory(enable_optimizer=False)

    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        runtime=runtime,
        host="127.0.0.1",
        port=port,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.3)

    client = APITestClient(f"http://127.0.0.1:{port}")
    yield client, runtime
    server.shutdown()


@pytest.fixture(scope="module")
def trajectory_server_with_optimizer() -> tuple[APITestClient, Any]:
    """Start a test API server with trajectory engine AND optimizer enabled."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    runtime = _build_runtime_with_trajectory(enable_optimizer=True)

    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        runtime=runtime,
        host="127.0.0.1",
        port=port,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.3)

    client = APITestClient(f"http://127.0.0.1:{port}")
    yield client, runtime
    server.shutdown()


@pytest.fixture(scope="module")
def no_runtime_server() -> APITestClient:
    """Start a test API server with no runtime (no trajectory engine)."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        host="127.0.0.1",
        port=port,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.3)

    client = APITestClient(f"http://127.0.0.1:{port}")
    yield client
    server.shutdown()


# ═══════════════════════════════════════════════════════════════════════
# GET /v1/trajectory/{agent_id}
# ═══════════════════════════════════════════════════════════════════════


class TestTrajectoryProjection:
    def test_returns_projection_for_known_agent(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server
        status, body = client.get("/v1/trajectory/agent-1")
        assert status == 200
        assert body["agent_id"] == "agent-1"
        assert "projection" in body
        proj = body["projection"]
        assert "risk_level" in proj
        assert "recommended_intervention" in proj
        assert "projected_drift" in proj
        assert "invariant_projections" in proj

    def test_returns_404_for_unknown_agent(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server
        status, body = client.get("/v1/trajectory/nonexistent-agent")
        assert status == 404
        assert body["error"] == "not_found"

    def test_returns_503_without_runtime(
        self, no_runtime_server: APITestClient,
    ) -> None:
        client = no_runtime_server
        status, body = client.get("/v1/trajectory/agent-1")
        assert status == 503


# ═══════════════════════════════════════════════════════════════════════
# GET /v1/trajectory/{agent_id}/history
# ═══════════════════════════════════════════════════════════════════════


class TestTrajectoryHistory:
    def test_returns_history_for_known_agent(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server
        status, body = client.get("/v1/trajectory/agent-1/history")
        assert status == 200
        assert body["agent_id"] == "agent-1"
        assert "current_projection" in body
        assert "interventions" in body
        assert "drift_history" in body
        # We recorded 3 drift observations
        assert len(body["drift_history"]) >= 1

    def test_returns_empty_for_unknown_agent(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server
        status, body = client.get("/v1/trajectory/unknown-agent/history")
        assert status == 200
        assert body["agent_id"] == "unknown-agent"
        assert body["current_projection"] is None
        assert body["drift_history"] == []


# ═══════════════════════════════════════════════════════════════════════
# GET /v1/trajectory/fleet
# ═══════════════════════════════════════════════════════════════════════


class TestTrajectoryFleet:
    def test_returns_fleet_summary(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server
        status, body = client.get("/v1/trajectory/fleet")
        assert status == 200
        assert "total_agents" in body
        assert body["total_agents"] >= 1
        assert "agents_by_risk" in body
        assert "agent_summaries" in body
        # Verify risk level buckets exist
        risk = body["agents_by_risk"]
        assert "low" in risk
        assert "moderate" in risk
        assert "high" in risk
        assert "critical" in risk

    def test_fleet_summaries_contain_agent_info(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server
        status, body = client.get("/v1/trajectory/fleet")
        assert status == 200
        summaries = body["agent_summaries"]
        assert len(summaries) >= 1
        agent_summary = summaries[0]
        assert "agent_id" in agent_summary
        assert "risk_level" in agent_summary
        assert "recommended_intervention" in agent_summary

    def test_fleet_returns_503_without_runtime(
        self, no_runtime_server: APITestClient,
    ) -> None:
        client = no_runtime_server
        status, body = client.get("/v1/trajectory/fleet")
        assert status == 503


# ═══════════════════════════════════════════════════════════════════════
# POST /v1/trajectory/simulate
# ═══════════════════════════════════════════════════════════════════════


class TestTrajectorySimulate:
    def test_simulate_returns_projected_trajectory(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server
        status, body = client.post("/v1/trajectory/simulate", {
            "agent_id": "agent-1",
            "strategy_name": "no_op",
            "horizon": 50,
        })
        assert status == 200
        assert body["agent_id"] == "agent-1"
        assert body["strategy_name"] == "no_op"
        assert body["horizon"] == 50
        assert "projected_drift" in body
        assert len(body["projected_drift"]) == 50
        assert "current_drift" in body
        assert "velocity" in body

    def test_simulate_graduated_strategy(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server
        status, body = client.post("/v1/trajectory/simulate", {
            "agent_id": "agent-1",
            "strategy_name": "graduated",
            "horizon": 100,
        })
        assert status == 200
        assert body["strategy_name"] == "graduated"
        assert "intervention_points" in body
        assert len(body["intervention_points"]) > 0

    def test_simulate_invalid_strategy_returns_400(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server
        status, body = client.post("/v1/trajectory/simulate", {
            "agent_id": "agent-1",
            "strategy_name": "nonexistent_strategy",
        })
        assert status == 400
        assert body["error"] == "invalid_strategy"
        assert "available_strategies" in body

    def test_simulate_missing_agent_id_returns_400(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server
        status, body = client.post("/v1/trajectory/simulate", {
            "strategy_name": "no_op",
        })
        assert status == 400
        assert body["error"] == "missing_field"

    def test_simulate_missing_strategy_returns_400(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server
        status, body = client.post("/v1/trajectory/simulate", {
            "agent_id": "agent-1",
        })
        assert status == 400
        assert body["error"] == "missing_field"


# ═══════════════════════════════════════════════════════════════════════
# Graceful degradation: optimizer disabled
# ═══════════════════════════════════════════════════════════════════════


class TestGracefulDegradation:
    def test_projection_without_optimizer_has_no_policy(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        """Without optimizer, projection should have no intervention_policy."""
        client, _rt = trajectory_server
        status, body = client.get("/v1/trajectory/agent-1")
        assert status == 200
        proj = body["projection"]
        # Without optimizer, intervention_policy should be absent
        assert "intervention_policy" not in proj or proj.get("intervention_policy") is None

    def test_fleet_without_optimizer_has_no_active_policy(
        self, trajectory_server: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server
        status, body = client.get("/v1/trajectory/fleet")
        assert status == 200
        for s in body["agent_summaries"]:
            # Without optimizer, no active_policy key
            assert "active_policy" not in s


# ═══════════════════════════════════════════════════════════════════════
# With optimizer enabled
# ═══════════════════════════════════════════════════════════════════════


class TestWithOptimizer:
    def test_projection_includes_policy(
        self, trajectory_server_with_optimizer: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server_with_optimizer
        status, body = client.get("/v1/trajectory/agent-1")
        assert status == 200
        proj = body["projection"]
        # With optimizer enabled, policy may or may not be attached depending
        # on drift levels and check intervals. Just verify the endpoint works.
        assert "risk_level" in proj

    def test_simulate_returns_estimated_cost(
        self, trajectory_server_with_optimizer: tuple[APITestClient, Any],
    ) -> None:
        client, _rt = trajectory_server_with_optimizer
        status, body = client.post("/v1/trajectory/simulate", {
            "agent_id": "agent-1",
            "strategy_name": "graduated",
            "horizon": 50,
        })
        assert status == 200
        # With optimizer, estimated_cost should be computed
        assert body["estimated_cost"] is not None
        assert isinstance(body["estimated_cost"], (int, float))
