"""Tests for the BehavioralTrajectoryEngine — predictive governance.

Tests cover:
- Trajectory projection with no drift (low risk)
- Trajectory projection approaching threshold (violation probability > 0)
- Graduated intervention escalation (advisory -> throttle -> escalate)
- Tighten requires approval constraint
- Drift velocity computation (increasing, stable)
- No contract returns None
- Check interval enforcement
- Auto-intervention disabled mode
"""

from __future__ import annotations

import time
from unittest import TestCase
from unittest.mock import MagicMock

from nomotic.contract import BehavioralContract, ContractStore
from nomotic.drift import DriftScore
from nomotic.fingerprint import BehavioralFingerprint
from nomotic.invariants import InvariantResult
from nomotic.observer import FingerprintObserver
from nomotic.trajectory_engine import (
    BehavioralTrajectoryEngine,
    InterventionAction,
    TrajectoryConfig,
    TrajectoryProjection,
)


# ── Helpers ────────────────────────────────────────────────────────────


def _make_drift(
    overall: float = 0.0,
    action: float = 0.0,
    target: float = 0.0,
    temporal: float = 0.0,
    outcome: float = 0.0,
    semantic: float = 0.0,
) -> DriftScore:
    return DriftScore(
        overall=overall,
        action_drift=action,
        target_drift=target,
        temporal_drift=temporal,
        outcome_drift=outcome,
        semantic_drift=semantic,
        confidence=0.9,
        window_size=100,
        baseline_size=500,
    )


def _make_contract(
    agent_id: str = "agent-1",
    drift_thresholds: dict | None = None,
    invariants: list | None = None,
) -> BehavioralContract:
    return BehavioralContract(
        contract_id="contract-1",
        version=1,
        agent_id=agent_id,
        created_at=time.time(),
        drift_thresholds=drift_thresholds or {
            "action": 0.40,
            "target": 0.40,
            "temporal": 0.40,
            "outcome": 0.40,
            "semantic": 0.40,
        },
        invariants=invariants or [],
    )


def _setup_engine(
    config: TrajectoryConfig | None = None,
    agent_id: str = "agent-1",
    contract: BehavioralContract | None = None,
    drift: DriftScore | None = None,
) -> tuple[BehavioralTrajectoryEngine, MagicMock, ContractStore]:
    """Create an engine with mocked observer and real contract store."""
    store = ContractStore()
    if contract is None:
        contract = _make_contract(agent_id=agent_id)
    store.store(contract)

    observer = MagicMock(spec=FingerprintObserver)
    observer.get_drift.return_value = drift
    observer.get_fingerprint.return_value = BehavioralFingerprint(agent_id=agent_id)
    observer.get_semantic_drift.return_value = None

    cfg = config or TrajectoryConfig()
    engine = BehavioralTrajectoryEngine(
        config=cfg,
        fingerprint_observer=observer,
        contract_store=store,
    )
    return engine, observer, store


# ── Tests ──────────────────────────────────────────────────────────────


class TestTrajectoryProjection(TestCase):

    def test_project_no_drift(self):
        """Agent with zero drift -> low risk, no intervention."""
        drift = _make_drift()
        engine, observer, _ = _setup_engine(drift=drift)

        proj = engine.project("agent-1")
        self.assertIsNotNone(proj)
        self.assertEqual(proj.risk_level, "low")
        self.assertEqual(proj.recommended_intervention, "none")
        self.assertEqual(proj.agent_id, "agent-1")

    def test_project_approaching_threshold(self):
        """Steady drift velocity approaching contract threshold."""
        config = TrajectoryConfig(projection_horizon=100)
        drift = _make_drift(action=0.10)
        engine, observer, _ = _setup_engine(config=config, drift=drift)

        # Feed increasing drift observations to build velocity
        for i in range(5):
            d = _make_drift(action=0.05 + i * 0.05)
            engine.record_drift("agent-1", d)
            # Small sleep to create time delta
            time.sleep(0.01)

        proj = engine.project("agent-1")
        self.assertIsNotNone(proj)
        # With increasing action drift, some invariant should have prob > 0
        action_proj = [
            ip for ip in proj.invariant_projections
            if ip["invariant_id"] == "drift_threshold_action"
        ]
        if action_proj:
            self.assertGreater(action_proj[0]["violation_probability"], 0.0)

    def test_graduated_interventions(self):
        """Increasing velocity escalates interventions from advisory to throttle to escalate."""
        config = TrajectoryConfig(
            projection_horizon=100,
            check_interval=1,
            advisory_threshold=0.3,
            throttle_threshold=0.5,
            escalate_threshold=0.7,
            enable_auto_intervention=True,
        )
        contract = _make_contract(drift_thresholds={
            "action": 0.30,
            "target": 0.40,
            "temporal": 0.40,
            "outcome": 0.40,
            "semantic": 0.40,
        })
        engine, observer, _ = _setup_engine(config=config, contract=contract)

        # Feed drift observations with steadily increasing action drift
        # to build positive velocity
        base_time = time.time()
        for i in range(6):
            d = _make_drift(action=0.05 + i * 0.05)
            engine._drift_history.setdefault("agent-1", []).append(
                (base_time + i * 1.0, d),
            )

        # Now on_observation with current drift close to threshold
        drift_high = _make_drift(action=0.28)
        observer.get_drift.return_value = drift_high
        intervention = engine.on_observation("agent-1", drift_high)

        # Should trigger some intervention (advisory, throttle, or escalate)
        # depending on projected probability
        if intervention is not None:
            self.assertIn(
                intervention.action_type,
                ("advisory", "throttle", "escalate"),
            )

    def test_tighten_requires_approval(self):
        """Even at very high probability, tighten_requires_approval caps at escalate."""
        config = TrajectoryConfig(
            projection_horizon=10,
            tighten_threshold=0.9,
            tighten_requires_approval=True,
        )
        engine, _, _ = _setup_engine(config=config)

        risk, intervention = engine._classify_risk(0.95)
        self.assertEqual(risk, "critical")
        self.assertEqual(intervention, "escalate")

    def test_tighten_without_approval(self):
        """When tighten_requires_approval=False, high prob triggers tighten."""
        config = TrajectoryConfig(
            tighten_threshold=0.9,
            tighten_requires_approval=False,
        )
        engine, _, _ = _setup_engine(config=config)

        risk, intervention = engine._classify_risk(0.95)
        self.assertEqual(risk, "critical")
        self.assertEqual(intervention, "tighten")


class TestDriftVelocity(TestCase):

    def test_velocity_computation(self):
        """Feed 5 drift observations with increasing action_drift -> positive velocity."""
        engine, _, _ = _setup_engine()

        base_time = time.time()
        for i in range(5):
            d = _make_drift(action=0.10 + i * 0.05)
            engine._drift_history.setdefault("agent-1", []).append(
                (base_time + i * 1.0, d),
            )

        velocity = engine._compute_drift_velocity("agent-1")
        self.assertGreater(velocity["action"], 0.0)

    def test_velocity_stable(self):
        """Feed 5 identical drift observations -> velocity = 0."""
        engine, _, _ = _setup_engine()

        base_time = time.time()
        for i in range(5):
            d = _make_drift(action=0.15)
            engine._drift_history.setdefault("agent-1", []).append(
                (base_time + i * 1.0, d),
            )

        velocity = engine._compute_drift_velocity("agent-1")
        self.assertAlmostEqual(velocity["action"], 0.0, places=5)


class TestProjectionEdgeCases(TestCase):

    def test_no_contract_returns_none(self):
        """Agent without a contract -> project() returns None."""
        observer = MagicMock(spec=FingerprintObserver)
        observer.get_drift.return_value = _make_drift()
        store = ContractStore()  # empty store

        engine = BehavioralTrajectoryEngine(
            fingerprint_observer=observer,
            contract_store=store,
        )
        result = engine.project("agent-no-contract")
        self.assertIsNone(result)

    def test_no_drift_returns_none(self):
        """Agent with no drift data -> project() returns None."""
        observer = MagicMock(spec=FingerprintObserver)
        observer.get_drift.return_value = None
        store = ContractStore()
        store.store(_make_contract())

        engine = BehavioralTrajectoryEngine(
            fingerprint_observer=observer,
            contract_store=store,
        )
        result = engine.project("agent-1")
        self.assertIsNone(result)


class TestObservationFlow(TestCase):

    def test_check_interval_respected(self):
        """on_observation only projects every check_interval calls."""
        config = TrajectoryConfig(
            check_interval=5,
            enable_auto_intervention=True,
        )
        engine, observer, _ = _setup_engine(config=config, drift=_make_drift())

        results = []
        for i in range(12):
            result = engine.on_observation("agent-1", _make_drift())
            results.append(result)

        # Should only project at observations 5 and 10
        # (indices 4 and 9 — when count % 5 == 0)
        # Most results should be None (no intervention for zero drift)
        non_none_count = sum(1 for r in results if r is not None)
        # At most 2 projections happened — but since drift is zero, interventions = None
        self.assertEqual(non_none_count, 0)

    def test_auto_intervention_off(self):
        """enable_auto_intervention=False -> on_observation returns None even with high risk."""
        config = TrajectoryConfig(
            check_interval=1,
            enable_auto_intervention=False,
        )
        contract = _make_contract(drift_thresholds={"action": 0.20})
        engine, observer, _ = _setup_engine(config=config, contract=contract)

        # Feed velocity showing rapidly increasing action drift
        base_time = time.time()
        for i in range(5):
            d = _make_drift(action=0.10 + i * 0.05)
            engine._drift_history.setdefault("agent-1", []).append(
                (base_time + i * 1.0, d),
            )

        # Even with projected violation, auto_intervention is off
        drift = _make_drift(action=0.18)
        observer.get_drift.return_value = drift
        result = engine.on_observation("agent-1", drift)
        self.assertIsNone(result)


class TestProjectionSerialization(TestCase):

    def test_to_dict(self):
        """TrajectoryProjection serializes correctly."""
        proj = TrajectoryProjection(
            agent_id="agent-1",
            projection_horizon=100,
            timestamp=1000.0,
            risk_level="moderate",
            recommended_intervention="advisory",
            intervention_reason="test reason",
            projected_drift={"action": 0.3},
        )
        d = proj.to_dict()
        self.assertEqual(d["agent_id"], "agent-1")
        self.assertEqual(d["risk_level"], "moderate")
        self.assertEqual(d["recommended_intervention"], "advisory")

    def test_intervention_to_dict(self):
        """InterventionAction serializes correctly."""
        action = InterventionAction(
            action_type="throttle",
            agent_id="agent-1",
            reason="approaching violation",
            timestamp=1000.0,
        )
        d = action.to_dict()
        self.assertEqual(d["action_type"], "throttle")
        self.assertEqual(d["agent_id"], "agent-1")
        self.assertIsNone(d["projection"])


class TestViolationProbability(TestCase):

    def test_negative_velocity_returns_zero(self):
        """Negative velocity (moving away) -> probability 0."""
        prob, step = BehavioralTrajectoryEngine._project_violation_probability(
            current_value=0.3, threshold=0.4, velocity=-0.01, horizon=100,
        )
        self.assertEqual(prob, 0.0)
        self.assertEqual(step, -1)

    def test_zero_velocity_returns_zero(self):
        """Zero velocity -> probability 0."""
        prob, step = BehavioralTrajectoryEngine._project_violation_probability(
            current_value=0.3, threshold=0.4, velocity=0.0, horizon=100,
        )
        self.assertEqual(prob, 0.0)
        self.assertEqual(step, -1)

    def test_will_cross_threshold(self):
        """Positive velocity that crosses threshold within horizon."""
        prob, step = BehavioralTrajectoryEngine._project_violation_probability(
            current_value=0.3, threshold=0.4, velocity=0.01, horizon=100,
        )
        self.assertGreater(prob, 0.0)
        self.assertGreaterEqual(step, 0)
        self.assertEqual(step, 10)  # (0.4 - 0.3) / 0.01 = 10

    def test_wont_cross_threshold(self):
        """Positive velocity but won't reach threshold in horizon."""
        prob, step = BehavioralTrajectoryEngine._project_violation_probability(
            current_value=0.1, threshold=0.8, velocity=0.001, horizon=100,
        )
        # projected = 0.1 + 0.001 * 100 = 0.2, threshold = 0.8
        # prob = 0.2 / 0.8 = 0.25
        self.assertAlmostEqual(prob, 0.25, places=2)
        self.assertEqual(step, -1)


class TestGetAccessors(TestCase):

    def test_get_projection(self):
        """get_projection returns stored projection."""
        engine, _, _ = _setup_engine(drift=_make_drift())
        proj = engine.project("agent-1")
        self.assertIsNotNone(proj)
        retrieved = engine.get_projection("agent-1")
        self.assertEqual(retrieved, proj)

    def test_get_projection_unknown_agent(self):
        """get_projection returns None for unknown agent."""
        engine, _, _ = _setup_engine(drift=_make_drift())
        self.assertIsNone(engine.get_projection("unknown"))

    def test_get_interventions_empty(self):
        """get_interventions returns empty list when none recorded."""
        engine, _, _ = _setup_engine(drift=_make_drift())
        self.assertEqual(engine.get_interventions(), [])

    def test_get_interventions_filtered(self):
        """get_interventions filters by agent_id."""
        engine, _, _ = _setup_engine(drift=_make_drift())
        action1 = InterventionAction(
            action_type="advisory", agent_id="agent-1",
            reason="test", timestamp=time.time(),
        )
        action2 = InterventionAction(
            action_type="throttle", agent_id="agent-2",
            reason="test", timestamp=time.time(),
        )
        engine._interventions = [action1, action2]
        self.assertEqual(len(engine.get_interventions("agent-1")), 1)
        self.assertEqual(len(engine.get_interventions("agent-2")), 1)
        self.assertEqual(len(engine.get_interventions()), 2)
