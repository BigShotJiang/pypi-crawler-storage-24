"""Tests for API key authentication on write endpoints."""

from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request
from typing import Any

import pytest

from nomotic.api import NomoticAPIServer
from nomotic.api_auth import check_api_key
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.store import MemoryCertificateStore


# ── Unit tests for check_api_key ─────────────────────────────────────


class TestCheckApiKey:
    def test_auth_disabled_passes(self) -> None:
        assert check_api_key(None, None) is True
        assert check_api_key(None, "anything") is True

    def test_correct_key_passes(self) -> None:
        assert check_api_key("secret", "secret") is True

    def test_wrong_key_fails(self) -> None:
        assert check_api_key("secret", "wrong") is False

    def test_missing_key_fails(self) -> None:
        assert check_api_key("secret", None) is False


# ── Integration tests against live server ────────────────────────────


def _find_free_port() -> int:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _request(
    base_url: str,
    method: str,
    path: str,
    data: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
) -> tuple[int, dict[str, Any] | str]:
    url = f"{base_url}{path}"
    payload = json.dumps(data or {}).encode("utf-8") if method != "GET" else None
    req = urllib.request.Request(url, data=payload, method=method)
    req.add_header("Content-Type", "application/json")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read()
            try:
                return resp.status, json.loads(raw)
            except json.JSONDecodeError:
                return resp.status, raw.decode()
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw)
        except json.JSONDecodeError:
            return e.code, raw.decode()


def _make_server(api_key: str | None = None) -> tuple[str, NomoticAPIServer]:
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)
    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        host="127.0.0.1",
        port=port,
        api_key=api_key,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.3)
    return f"http://127.0.0.1:{port}", server


# ── Auth disabled (no api_key) ───────────────────────────────────────


@pytest.fixture(scope="module")
def noauth_server() -> tuple[str, NomoticAPIServer]:
    base, srv = _make_server(api_key=None)
    yield base, srv
    srv.shutdown()


def test_noauth_get_health(noauth_server: tuple[str, NomoticAPIServer]) -> None:
    base, _ = noauth_server
    status, body = _request(base, "GET", "/v1/health")
    assert status == 200


def test_noauth_post_no_key_passes(noauth_server: tuple[str, NomoticAPIServer]) -> None:
    """Without auth configured, POST requests succeed without any key."""
    base, _ = noauth_server
    # Use an endpoint that exists but will return a domain error (not 401).
    status, body = _request(base, "POST", "/v1/certificates", data={})
    # Any status other than 401 means auth didn't block it.
    assert status != 401


# ── Auth enabled ─────────────────────────────────────────────────────


API_KEY = "test-secret-key-12345"


@pytest.fixture(scope="module")
def auth_server() -> tuple[str, NomoticAPIServer]:
    base, srv = _make_server(api_key=API_KEY)
    yield base, srv
    srv.shutdown()


def test_auth_get_unaffected(auth_server: tuple[str, NomoticAPIServer]) -> None:
    """GET endpoints should NOT require the API key."""
    base, _ = auth_server
    status, body = _request(base, "GET", "/v1/health")
    assert status == 200


def test_auth_post_missing_key_rejected(auth_server: tuple[str, NomoticAPIServer]) -> None:
    """POST without X-Nomotic-API-Key returns 401."""
    base, _ = auth_server
    status, body = _request(base, "POST", "/v1/certificates", data={})
    assert status == 401


def test_auth_post_wrong_key_rejected(auth_server: tuple[str, NomoticAPIServer]) -> None:
    """POST with incorrect key returns 401."""
    base, _ = auth_server
    status, body = _request(
        base, "POST", "/v1/certificates", data={},
        headers={"X-Nomotic-API-Key": "wrong-key"},
    )
    assert status == 401


def test_auth_post_correct_key_passes(auth_server: tuple[str, NomoticAPIServer]) -> None:
    """POST with the correct key is allowed (not 401)."""
    base, _ = auth_server
    status, body = _request(
        base, "POST", "/v1/certificates", data={},
        headers={"X-Nomotic-API-Key": API_KEY},
    )
    # Should not be 401 — may be a domain error like 400/422 but auth passed.
    assert status != 401


def test_auth_patch_missing_key_rejected(auth_server: tuple[str, NomoticAPIServer]) -> None:
    """PATCH without key returns 401."""
    base, _ = auth_server
    status, body = _request(base, "PATCH", "/v1/certificates/fake-id/suspend", data={})
    assert status == 401


def test_auth_delete_missing_key_rejected(auth_server: tuple[str, NomoticAPIServer]) -> None:
    """DELETE without key returns 401."""
    base, _ = auth_server
    status, body = _request(base, "DELETE", "/v1/contracts/fake-id", data={})
    assert status == 401
