"""Tests for web framework adapters: FastAPI/Starlette (ASGI) and Flask.

Neither starlette nor flask is a mandatory dependency, so we inject minimal
mocks into sys.modules before importing the adapters.  The mocks faithfully
replicate the subset of each API that the adapters actually use, letting us
test the adapter routing logic in full without installing the frameworks.
"""

from __future__ import annotations

import asyncio
import sys
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ── Starlette mock ──────────────────────────────────────────────────────────
#
# NomoticMiddleware imports from starlette at module level:
#   from starlette.responses import JSONResponse
#   from starlette.types import ASGIApp, Receive, Scope, Send
#
# ASGIApp / Receive / Scope / Send are pure type aliases — the adapter never
# calls them at runtime, so MagicMock() placeholders suffice.
# JSONResponse IS called at runtime, so we provide a real stub.


class _MockJSONResponse:
    """Minimal stand-in for starlette.responses.JSONResponse.

    Behaves as an ASGI app: records the status_code and content it was
    constructed with, and sends minimal http.response.* messages on call.
    """

    def __init__(self, content: Any, status_code: int = 200) -> None:
        self.content = content
        self.status_code = status_code

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
        await send({"type": "http.response.start", "status": self.status_code, "headers": []})
        await send({"type": "http.response.body", "body": b""})


_starlette_responses_mock = MagicMock()
_starlette_responses_mock.JSONResponse = _MockJSONResponse
_starlette_types_mock = MagicMock()
_INJECTED_MODULES: set[str] = set()

if "starlette" not in sys.modules:
    sys.modules["starlette"] = MagicMock()
    _INJECTED_MODULES.add("starlette")
    sys.modules["starlette.responses"] = _starlette_responses_mock
    _INJECTED_MODULES.add("starlette.responses")
    sys.modules["starlette.types"] = _starlette_types_mock
    _INJECTED_MODULES.add("starlette.types")

# ── Flask mock ──────────────────────────────────────────────────────────────
#
# The flask adapter imports at module level:
#   from flask import g, jsonify, request as flask_request
#
# We inject a flask module mock that provides these three names.
# Tests that need specific request state patch flask_adapter.flask_request
# directly (since the adapter captured the reference at import time).


class _MockFlaskG:
    """Stand-in for flask.g (per-request attribute storage)."""
    nomotic = None  # Flask adapter sets g.nomotic; pre-initialize so getattr works


_flask_mock = MagicMock()
_flask_mock.g = _MockFlaskG()
_flask_mock.jsonify = MagicMock(side_effect=lambda d: d)  # passthrough for tests
_flask_mock.request = MagicMock()

if "flask" not in sys.modules:
    sys.modules["flask"] = _flask_mock
    _INJECTED_MODULES.add("flask")

# ── Import adapters (after mocks are in place) ──────────────────────────────

from nomotic.adapters.fastapi_adapter import NomoticMiddleware  # noqa: E402
from nomotic.adapters.flask_adapter import (  # noqa: E402
    nomotic_before_request,
    nomotic_required,
)
from nomotic.middleware import (  # noqa: E402
    GatewayResult,
    REASON_ALLOWED,
    REASON_NO_CERTIFICATE,
    REASON_TRUST_BELOW_THRESHOLD,
)

# Remove temporary framework stubs to avoid leaking fake modules into
# unrelated tests.  Keep the adapter modules themselves so that
# ``unittest.mock.patch("nomotic.adapters.flask_adapter.…")`` resolves
# against the *same* module object that holds the imported functions.
for _name in _INJECTED_MODULES:
    sys.modules.pop(_name, None)


# ── ASGI helpers ────────────────────────────────────────────────────────────


def _make_http_scope(headers: dict[str, str] | None = None) -> dict[str, Any]:
    """Build a minimal ASGI http scope."""
    raw_headers = [
        (k.encode("latin-1"), v.encode("latin-1"))
        for k, v in (headers or {}).items()
    ]
    return {"type": "http", "headers": raw_headers, "state": {}}


def _make_receive(body: bytes = b"") -> Any:
    """Return an async receive callable that yields a single http.request message."""
    async def receive() -> dict[str, Any]:
        return {"type": "http.request", "body": body}
    return receive


def _make_gateway(
    allowed: bool = True,
    reason: str = REASON_ALLOWED,
) -> tuple[MagicMock, GatewayResult]:
    """Return (mock_gateway, GatewayResult) with controlled check() output."""
    result = GatewayResult(allowed=allowed, reason=reason)
    gateway = MagicMock()
    gateway.check.return_value = result
    return gateway, result


# ── NomoticMiddleware (ASGI / FastAPI) ──────────────────────────────────────


class TestNomoticMiddleware:
    def test_non_http_scope_passes_through_without_check(self) -> None:
        """Non-http scopes (websocket, lifespan, etc.) bypass gateway entirely."""
        gateway, _ = _make_gateway()
        app = AsyncMock()
        mw = NomoticMiddleware(app, gateway)

        scope: dict[str, Any] = {"type": "websocket"}
        receive = AsyncMock()
        send = AsyncMock()

        asyncio.run(mw(scope, receive, send))

        app.assert_awaited_once_with(scope, receive, send)
        gateway.check.assert_not_called()

    def test_denied_no_certificate_returns_401(self) -> None:
        """Missing certificate → 401 Unauthorized."""
        gateway, _ = _make_gateway(allowed=False, reason=REASON_NO_CERTIFICATE)
        app = AsyncMock()
        mw = NomoticMiddleware(app, gateway)

        sent: list[dict] = []

        async def send(msg: dict) -> None:
            sent.append(msg)

        asyncio.run(mw(_make_http_scope(), _make_receive(), send))

        app.assert_not_awaited()
        assert any(m.get("status") == 401 for m in sent)

    def test_denied_with_cert_returns_403(self) -> None:
        """Valid cert but below trust threshold → 403 Forbidden."""
        gateway, _ = _make_gateway(allowed=False, reason=REASON_TRUST_BELOW_THRESHOLD)
        app = AsyncMock()
        mw = NomoticMiddleware(app, gateway)

        sent: list[dict] = []

        async def send(msg: dict) -> None:
            sent.append(msg)

        asyncio.run(mw(_make_http_scope(), _make_receive(), send))

        app.assert_not_awaited()
        assert any(m.get("status") == 403 for m in sent)

    def test_allowed_request_calls_downstream_app(self) -> None:
        """Allowed request is forwarded to the downstream ASGI app."""
        gateway, _ = _make_gateway(allowed=True)
        app = AsyncMock()
        mw = NomoticMiddleware(app, gateway)

        scope = _make_http_scope()
        asyncio.run(mw(scope, _make_receive(), AsyncMock()))

        app.assert_awaited_once()

    def test_allowed_injects_result_into_scope_state(self) -> None:
        """GatewayResult is stored in scope['state']['nomotic'] for downstream use."""
        gateway, result = _make_gateway(allowed=True)
        app = AsyncMock()
        mw = NomoticMiddleware(app, gateway)

        scope = _make_http_scope()
        asyncio.run(mw(scope, _make_receive(), AsyncMock()))

        assert scope["state"]["nomotic"] is result

    def test_allowed_replays_body_to_downstream(self) -> None:
        """The request body consumed during check is replayed to the downstream app."""
        gateway, _ = _make_gateway(allowed=True)
        bodies_seen: list[bytes] = []

        async def downstream(scope: Any, receive: Any, send: Any) -> None:
            msg = await receive()
            bodies_seen.append(msg.get("body", b""))

        mw = NomoticMiddleware(downstream, gateway)
        asyncio.run(mw(_make_http_scope(), _make_receive(body=b"hello body"), AsyncMock()))

        assert bodies_seen == [b"hello body"]

    def test_replay_receive_falls_back_to_original_after_first_call(self) -> None:
        """After replaying the buffered body, subsequent receive() calls go to original.

        The middleware calls original_receive() once to buffer the body for
        gateway.check(), then again when the downstream app requests a second
        message — so original_receive ends up called twice total.
        """
        gateway, _ = _make_gateway(allowed=True)
        call_count = 0

        async def original_receive() -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            return {"type": "http.disconnect"}

        bodies: list[dict] = []

        async def downstream(scope: Any, receive: Any, send: Any) -> None:
            bodies.append(await receive())   # gets buffered body (replay)
            bodies.append(await receive())   # falls back to original_receive

        mw = NomoticMiddleware(downstream, gateway)
        asyncio.run(mw(_make_http_scope(), original_receive, AsyncMock()))

        assert bodies[0]["type"] == "http.request"   # replayed buffer
        assert bodies[1]["type"] == "http.disconnect"  # from original
        # original_receive called once by middleware to buffer, once by downstream
        assert call_count == 2

    def test_headers_extracted_and_passed_to_gateway(self) -> None:
        """Request headers are decoded and forwarded to gateway.check()."""
        gateway, _ = _make_gateway(allowed=True)
        app = AsyncMock()
        mw = NomoticMiddleware(app, gateway)

        headers = {"x-nomotic-cert-id": "cert-abc", "content-type": "application/json"}
        asyncio.run(mw(_make_http_scope(headers=headers), _make_receive(), AsyncMock()))

        checked_headers, _ = gateway.check.call_args[0]
        assert checked_headers["x-nomotic-cert-id"] == "cert-abc"
        assert checked_headers["content-type"] == "application/json"

    def test_body_passed_to_gateway_check(self) -> None:
        """Request body is forwarded to gateway.check() for validation."""
        gateway, _ = _make_gateway(allowed=True)
        app = AsyncMock()
        mw = NomoticMiddleware(app, gateway)

        asyncio.run(mw(_make_http_scope(), _make_receive(body=b'{"action":"read"}'), AsyncMock()))

        _, checked_body = gateway.check.call_args[0]
        assert checked_body == b'{"action":"read"}'

    def test_scope_state_initialised_if_missing(self) -> None:
        """Middleware creates scope['state'] dict if the scope doesn't have one."""
        gateway, _ = _make_gateway(allowed=True)
        app = AsyncMock()
        mw = NomoticMiddleware(app, gateway)

        scope: dict[str, Any] = {"type": "http", "headers": []}  # no 'state' key
        asyncio.run(mw(scope, _make_receive(), AsyncMock()))

        assert "nomotic" in scope["state"]


# ── Flask: nomotic_required decorator ───────────────────────────────────────


class TestNomoticRequired:
    """Tests for the @nomotic_required(gateway) route decorator."""

    def _request(
        self, headers: dict | None = None, data: bytes = b""
    ) -> MagicMock:
        req = MagicMock()
        req.headers = headers or {}
        req.get_data.return_value = data
        return req

    def test_allowed_calls_decorated_function(self) -> None:
        """Decorated route function is called when gateway allows."""
        gateway, result = _make_gateway(allowed=True)
        mock_g = _MockFlaskG()

        @nomotic_required(gateway)
        def my_route() -> str:
            return "route ok"

        with patch("nomotic.adapters.flask_adapter.flask_request", self._request()), \
             patch("nomotic.adapters.flask_adapter.g", mock_g):
            resp = my_route()

        assert resp == "route ok"
        assert mock_g.nomotic is result

    def test_no_cert_returns_401(self) -> None:
        """Missing certificate → (response, 401)."""
        gateway, _ = _make_gateway(allowed=False, reason=REASON_NO_CERTIFICATE)

        @nomotic_required(gateway)
        def my_route() -> str:
            return "should not reach"

        mock_jsonify = MagicMock(side_effect=lambda d: d)
        with patch("nomotic.adapters.flask_adapter.flask_request", self._request()), \
             patch("nomotic.adapters.flask_adapter.g", _MockFlaskG()), \
             patch("nomotic.adapters.flask_adapter.jsonify", mock_jsonify):
            resp, status = my_route()

        assert status == 401
        mock_jsonify.assert_called_once()

    def test_denied_with_cert_returns_403(self) -> None:
        """Denied but cert present → (response, 403)."""
        gateway, _ = _make_gateway(allowed=False, reason=REASON_TRUST_BELOW_THRESHOLD)

        @nomotic_required(gateway)
        def my_route() -> str:
            return "should not reach"

        mock_jsonify = MagicMock(side_effect=lambda d: d)
        with patch("nomotic.adapters.flask_adapter.flask_request", self._request()), \
             patch("nomotic.adapters.flask_adapter.g", _MockFlaskG()), \
             patch("nomotic.adapters.flask_adapter.jsonify", mock_jsonify):
            resp, status = my_route()

        assert status == 403

    def test_gateway_receives_headers_and_body(self) -> None:
        """Headers and body from the request are forwarded to gateway.check()."""
        gateway, _ = _make_gateway(allowed=True)

        @nomotic_required(gateway)
        def my_route() -> str:
            return "ok"

        req = self._request(headers={"x-nomotic-cert-id": "c-1"}, data=b"payload")
        with patch("nomotic.adapters.flask_adapter.flask_request", req), \
             patch("nomotic.adapters.flask_adapter.g", _MockFlaskG()):
            my_route()

        checked_headers, checked_body = gateway.check.call_args[0]
        assert checked_headers["x-nomotic-cert-id"] == "c-1"
        assert checked_body == b"payload"

    def test_wraps_preserves_function_name(self) -> None:
        """@functools.wraps preserves the original function name."""
        gateway, _ = _make_gateway(allowed=True)

        @nomotic_required(gateway)
        def my_unique_route() -> str:
            return "ok"

        assert my_unique_route.__name__ == "my_unique_route"

    def test_allowed_passes_kwargs_to_route(self) -> None:
        """Route function kwargs (e.g. URL parameters) are forwarded."""
        gateway, _ = _make_gateway(allowed=True)

        @nomotic_required(gateway)
        def my_route(item_id: int) -> str:
            return f"item-{item_id}"

        with patch("nomotic.adapters.flask_adapter.flask_request", self._request()), \
             patch("nomotic.adapters.flask_adapter.g", _MockFlaskG()):
            resp = my_route(item_id=42)

        assert resp == "item-42"


# ── Flask: nomotic_before_request app-wide handler ──────────────────────────


class TestNomoticBeforeRequest:
    """Tests for nomotic_before_request(gateway) app-wide handler."""

    def _request(
        self, headers: dict | None = None, data: bytes = b""
    ) -> MagicMock:
        req = MagicMock()
        req.headers = headers or {}
        req.get_data.return_value = data
        return req

    def test_allowed_returns_none(self) -> None:
        """Returning None from a before_request handler lets the request proceed."""
        gateway, result = _make_gateway(allowed=True)
        mock_g = _MockFlaskG()
        handler = nomotic_before_request(gateway)

        with patch("nomotic.adapters.flask_adapter.flask_request", self._request()), \
             patch("nomotic.adapters.flask_adapter.g", mock_g):
            resp = handler()

        assert resp is None
        assert mock_g.nomotic is result

    def test_no_cert_returns_401_response(self) -> None:
        """Missing cert → handler returns (response, 401) to abort the request."""
        gateway, _ = _make_gateway(allowed=False, reason=REASON_NO_CERTIFICATE)
        handler = nomotic_before_request(gateway)

        mock_jsonify = MagicMock(side_effect=lambda d: d)
        with patch("nomotic.adapters.flask_adapter.flask_request", self._request()), \
             patch("nomotic.adapters.flask_adapter.g", _MockFlaskG()), \
             patch("nomotic.adapters.flask_adapter.jsonify", mock_jsonify):
            resp, status = handler()

        assert status == 401

    def test_denied_with_cert_returns_403_response(self) -> None:
        """Cert present but denied → handler returns (response, 403)."""
        gateway, _ = _make_gateway(allowed=False, reason=REASON_TRUST_BELOW_THRESHOLD)
        handler = nomotic_before_request(gateway)

        mock_jsonify = MagicMock(side_effect=lambda d: d)
        with patch("nomotic.adapters.flask_adapter.flask_request", self._request()), \
             patch("nomotic.adapters.flask_adapter.g", _MockFlaskG()), \
             patch("nomotic.adapters.flask_adapter.jsonify", mock_jsonify):
            resp, status = handler()

        assert status == 403

    def test_gateway_receives_headers_and_body(self) -> None:
        """Headers and body from the request are forwarded to gateway.check()."""
        gateway, _ = _make_gateway(allowed=True)
        handler = nomotic_before_request(gateway)

        req = self._request(headers={"x-nomotic-cert-id": "cert-xyz"}, data=b"data")
        with patch("nomotic.adapters.flask_adapter.flask_request", req), \
             patch("nomotic.adapters.flask_adapter.g", _MockFlaskG()):
            handler()

        checked_headers, checked_body = gateway.check.call_args[0]
        assert checked_headers["x-nomotic-cert-id"] == "cert-xyz"
        assert checked_body == b"data"

    def test_allowed_sets_g_nomotic(self) -> None:
        """g.nomotic is set to the GatewayResult on a successful check."""
        gateway, result = _make_gateway(allowed=True)
        mock_g = _MockFlaskG()
        handler = nomotic_before_request(gateway)

        with patch("nomotic.adapters.flask_adapter.flask_request", self._request()), \
             patch("nomotic.adapters.flask_adapter.g", mock_g):
            handler()

        assert mock_g.nomotic is result
