"""Tests for audit trail — structured governance event logging."""

import json
import threading
import time

import pytest

from nomotic.audit import (
    AccountabilityRecord,
    AuditRecord,
    AuditTrail,
    ChangeRecord,
    JustificationRecord,
    OutcomeRecord,
    UnwrittenPolicyAdjustmentRecord,
    build_justification,
    verify_typed_chain,
)
from nomotic.context import CODES
from nomotic.types import (
    Action,
    AgentContext,
    DimensionScore,
    GovernanceVerdict,
    TrustProfile,
    Verdict,
)


def _make_record(
    *,
    agent_id: str = "agent-1",
    context_code: str = "GOVERNANCE.ALLOW",
    severity: str = "info",
    verdict: str = "ALLOW",
    ucs: float = 0.8,
    tier: int = 2,
    trust_score: float = 0.7,
    timestamp: float | None = None,
    user_id: str = "",
    owner_id: str = "",
    action_type: str = "read",
    action_target: str = "/api/data",
) -> AuditRecord:
    return AuditRecord(
        record_id=f"rec-{time.time_ns() % 100000:05d}",
        timestamp=timestamp or time.time(),
        context_code=context_code,
        severity=severity,
        agent_id=agent_id,
        owner_id=owner_id,
        user_id=user_id,
        action_id=f"act-{time.time_ns() % 100000:05d}",
        action_type=action_type,
        action_target=action_target,
        verdict=verdict,
        ucs=ucs,
        tier=tier,
        trust_score=trust_score,
        trust_trend="stable",
    )


class TestAuditRecord:
    """AuditRecord serialization tests."""

    def test_to_dict(self):
        record = _make_record()
        d = record.to_dict()
        assert d["agent_id"] == "agent-1"
        assert d["context_code"] == "GOVERNANCE.ALLOW"
        assert d["verdict"] == "ALLOW"
        assert isinstance(d["ucs"], float)

    def test_from_dict_roundtrip(self):
        record = _make_record(
            agent_id="agent-x",
            verdict="DENY",
            ucs=0.15,
            tier=1,
            context_code="GOVERNANCE.VETO",
            severity="alert",
        )
        record.drift_overall = 0.45
        record.drift_severity = "high"
        d = record.to_dict()
        restored = AuditRecord.from_dict(d)
        assert restored.agent_id == "agent-x"
        assert restored.verdict == "DENY"
        assert restored.ucs == pytest.approx(0.15, abs=0.001)
        assert restored.drift_severity == "high"
        assert restored.drift_overall == pytest.approx(0.45, abs=0.001)

    def test_metadata_in_dict(self):
        record = _make_record()
        record.metadata = {"session_id": "sess-123"}
        d = record.to_dict()
        assert d["metadata"]["session_id"] == "sess-123"


class TestAuditTrail:
    """AuditTrail append, query, summary tests."""

    def test_append_and_query(self):
        trail = AuditTrail()
        record = _make_record()
        trail.append(record)
        results = trail.query()
        assert len(results) == 1
        assert results[0].agent_id == "agent-1"

    def test_query_no_filters_returns_all(self):
        trail = AuditTrail()
        for i in range(5):
            trail.append(_make_record(agent_id=f"agent-{i}"))
        results = trail.query()
        assert len(results) == 5

    def test_query_filter_agent_id(self):
        trail = AuditTrail()
        trail.append(_make_record(agent_id="agent-a"))
        trail.append(_make_record(agent_id="agent-b"))
        trail.append(_make_record(agent_id="agent-a"))
        results = trail.query(agent_id="agent-a")
        assert len(results) == 2
        assert all(r.agent_id == "agent-a" for r in results)

    def test_query_filter_context_code(self):
        trail = AuditTrail()
        trail.append(_make_record(context_code="GOVERNANCE.ALLOW", severity="info"))
        trail.append(_make_record(context_code="GOVERNANCE.DENY", severity="warning"))
        results = trail.query(context_code="GOVERNANCE.DENY")
        assert len(results) == 1

    def test_query_filter_category(self):
        trail = AuditTrail()
        trail.append(_make_record(context_code="GOVERNANCE.ALLOW", severity="info"))
        trail.append(_make_record(context_code="SECURITY.INJECTION_ATTEMPT", severity="critical"))
        results = trail.query(category="SECURITY")
        assert len(results) == 1

    def test_query_filter_severity(self):
        trail = AuditTrail()
        trail.append(_make_record(severity="info"))
        trail.append(_make_record(severity="warning"))
        trail.append(_make_record(severity="critical"))
        results = trail.query(severity="critical")
        assert len(results) == 1

    def test_query_filter_verdict(self):
        trail = AuditTrail()
        trail.append(_make_record(verdict="ALLOW"))
        trail.append(_make_record(verdict="DENY"))
        results = trail.query(verdict="DENY")
        assert len(results) == 1

    def test_query_filter_time_range(self):
        trail = AuditTrail()
        t1 = time.time() - 100
        t2 = time.time() - 50
        t3 = time.time()
        trail.append(_make_record(timestamp=t1))
        trail.append(_make_record(timestamp=t2))
        trail.append(_make_record(timestamp=t3))
        results = trail.query(since=t2 - 1, until=t2 + 1)
        assert len(results) == 1

    def test_query_combined_filters(self):
        trail = AuditTrail()
        trail.append(_make_record(agent_id="a", verdict="ALLOW"))
        trail.append(_make_record(agent_id="a", verdict="DENY"))
        trail.append(_make_record(agent_id="b", verdict="DENY"))
        results = trail.query(agent_id="a", verdict="DENY")
        assert len(results) == 1

    def test_query_newest_first(self):
        trail = AuditTrail()
        t1 = time.time() - 2
        t2 = time.time() - 1
        t3 = time.time()
        trail.append(_make_record(timestamp=t1))
        trail.append(_make_record(timestamp=t2))
        trail.append(_make_record(timestamp=t3))
        results = trail.query()
        assert results[0].timestamp >= results[1].timestamp
        assert results[1].timestamp >= results[2].timestamp

    def test_query_limit(self):
        trail = AuditTrail()
        for _ in range(10):
            trail.append(_make_record())
        results = trail.query(limit=3)
        assert len(results) == 3

    def test_max_records_cap(self):
        trail = AuditTrail(max_records=5)
        for i in range(10):
            trail.append(_make_record(agent_id=f"agent-{i}"))
        assert len(trail.records) == 5

    def test_count(self):
        trail = AuditTrail()
        trail.append(_make_record(verdict="ALLOW"))
        trail.append(_make_record(verdict="DENY"))
        trail.append(_make_record(verdict="ALLOW"))
        assert trail.count(verdict="ALLOW") == 2
        assert trail.count(verdict="DENY") == 1

    def test_summary(self):
        trail = AuditTrail()
        trail.append(_make_record(verdict="ALLOW", severity="info", context_code="GOVERNANCE.ALLOW"))
        trail.append(_make_record(verdict="DENY", severity="warning", context_code="GOVERNANCE.DENY"))
        trail.append(_make_record(verdict="DENY", severity="alert", context_code="GOVERNANCE.VETO"))
        summary = trail.summary()
        assert summary["total_records"] == 3
        assert summary["by_verdict"]["ALLOW"] == 1
        assert summary["by_verdict"]["DENY"] == 2
        assert summary["by_severity"]["info"] == 1
        assert "GOVERNANCE" in summary["by_category"]
        assert len(summary["recent_alerts"]) == 1

    def test_summary_with_agent_filter(self):
        trail = AuditTrail()
        trail.append(_make_record(agent_id="a"))
        trail.append(_make_record(agent_id="b"))
        summary = trail.summary(agent_id="a")
        assert summary["total_records"] == 1

    def test_export_json(self):
        trail = AuditTrail()
        trail.append(_make_record())
        exported = trail.export("json")
        assert isinstance(exported, str)
        parsed = json.loads(exported)
        assert len(parsed) == 1

    def test_export_dicts(self):
        trail = AuditTrail()
        trail.append(_make_record())
        exported = trail.export("dicts")
        assert isinstance(exported, list)
        assert len(exported) == 1
        assert isinstance(exported[0], dict)

    def test_clear(self):
        trail = AuditTrail()
        trail.append(_make_record())
        trail.clear()
        assert len(trail.records) == 0

    def test_records_property_newest_first(self):
        trail = AuditTrail()
        trail.append(_make_record(timestamp=1.0))
        trail.append(_make_record(timestamp=2.0))
        records = trail.records
        assert records[0].timestamp == 2.0

    def test_thread_safety(self):
        trail = AuditTrail()
        errors = []

        def append_records(n):
            try:
                for _ in range(n):
                    trail.append(_make_record())
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=append_records, args=(50,)) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert len(trail.records) == 200


class TestBuildJustification:
    """build_justification tests."""

    def test_allow_verdict(self):
        verdict = GovernanceVerdict(
            action_id="act-1",
            verdict=Verdict.ALLOW,
            ucs=0.82,
            tier=2,
            dimension_scores=[
                DimensionScore("scope_compliance", 1.0, 1.5, reasoning="Within scope"),
                DimensionScore("behavioral_consistency", 0.95, 1.0, reasoning="Consistent"),
            ],
        )
        action = Action(agent_id="agent-1", action_type="read", target="/api/data")
        context = AgentContext(agent_id="agent-1", trust_profile=TrustProfile(agent_id="agent-1", overall_trust=0.78))
        result = build_justification(verdict, action, context)
        assert "ALLOW" in result
        assert "0.82" in result
        assert "Tier 2" in result
        assert "read" in result

    def test_deny_verdict_with_veto(self):
        verdict = GovernanceVerdict(
            action_id="act-1",
            verdict=Verdict.DENY,
            ucs=0.15,
            tier=1,
            vetoed_by=["scope_compliance"],
            dimension_scores=[
                DimensionScore("scope_compliance", 0.0, 1.5, veto=True, reasoning="Out of scope"),
            ],
        )
        action = Action(agent_id="agent-1", action_type="delete", target="/api/data")
        context = AgentContext(agent_id="agent-1", trust_profile=TrustProfile(agent_id="agent-1", overall_trust=0.42))
        result = build_justification(verdict, action, context)
        assert "DENY" in result
        assert "veto" in result
        assert "VETOED" in result
        assert "scope_compliance" in result

    def test_includes_drift_info(self):
        verdict = GovernanceVerdict(
            action_id="act-1",
            verdict=Verdict.DENY,
            ucs=0.2,
            tier=2,
            dimension_scores=[],
        )
        action = Action(agent_id="agent-1", action_type="read", target="/api/data")
        context = AgentContext(agent_id="agent-1", trust_profile=TrustProfile(agent_id="agent-1"))

        class FakeDrift:
            overall = 0.45
            severity = "high"

        result = build_justification(verdict, action, context, FakeDrift())
        assert "HIGH" in result or "high" in result.lower()

    def test_no_drift(self):
        verdict = GovernanceVerdict(
            action_id="act-1",
            verdict=Verdict.ALLOW,
            ucs=0.9,
            tier=2,
            dimension_scores=[],
        )
        action = Action(agent_id="agent-1", action_type="read", target="/api/data")
        context = AgentContext(agent_id="agent-1", trust_profile=TrustProfile(agent_id="agent-1"))
        result = build_justification(verdict, action, context, None)
        assert "ALLOW" in result

    def test_handles_missing_optional_data(self):
        verdict = GovernanceVerdict(
            action_id="act-1",
            verdict=Verdict.ALLOW,
            ucs=0.9,
            tier=2,
            dimension_scores=[],
        )
        action = Action(agent_id="", action_type="", target="")
        context = AgentContext(agent_id="", trust_profile=TrustProfile(agent_id=""))
        result = build_justification(verdict, action, context)
        assert isinstance(result, str)
        assert len(result) > 0


# ── Typed Record Tests ────────────────────────────────────────────────────


def _make_justification(
    *,
    agent_id: str = "agent-1",
    action_id: str = "act-1",
    verdict: str = "ALLOW",
    timestamp: float | None = None,
) -> JustificationRecord:
    return JustificationRecord(
        record_id=f"jr-{time.time_ns() % 100000:05d}",
        action_id=action_id,
        agent_id=agent_id,
        verdict=verdict,
        determinative_factors=["scope_compliance"],
        counterfactual="Would have denied if scope was restricted",
        dimension_results={
            "scope_compliance": {"score": 1.0, "weight": 1.5, "veto": False},
        },
        coherence_score=0.92,
        timestamp=timestamp or time.time(),
    )


def _make_outcome(
    *,
    agent_id: str = "agent-1",
    action_id: str = "act-1",
    timestamp: float | None = None,
) -> OutcomeRecord:
    return OutcomeRecord(
        record_id=f"or-{time.time_ns() % 100000:05d}",
        action_id=action_id,
        agent_id=agent_id,
        decision_verdict="ALLOW",
        outcome_signals={"latency_ms": 42},
        outcome_at=time.time(),
        outcome_validated=True,
        override_occurred=False,
        override_reason=None,
        timestamp=timestamp or time.time(),
    )


def _make_policy_adjustment(
    *,
    timestamp: float | None = None,
) -> UnwrittenPolicyAdjustmentRecord:
    return UnwrittenPolicyAdjustmentRecord(
        record_id=f"pa-{time.time_ns() % 100000:05d}",
        pattern_description="Repeated allow for read on /api/data",
        evidence_action_ids=["act-1", "act-2", "act-3"],
        observation_count=15,
        positive_outcome_rate=0.93,
        proposed_policy_change="Auto-allow read on /api/data for trusted agents",
        approved_by="admin@example.com",
        approved_at=time.time(),
        policy_change_applied="Added policy rule: auto-allow read /api/data",
        timestamp=timestamp or time.time(),
    )


def _make_accountability(
    *,
    action_id: str = "act-1",
    human_id: str = "human-1",
    timestamp: float | None = None,
) -> AccountabilityRecord:
    return AccountabilityRecord(
        record_id=f"ar-{time.time_ns() % 100000:05d}",
        action_id=action_id,
        human_id=human_id,
        human_action="override",
        original_verdict="DENY",
        resulting_verdict="ALLOW",
        stated_rationale="Emergency access needed",
        timestamp=timestamp or time.time(),
    )


def _make_change(
    *,
    changed_by: str = "admin",
    change_type: str = "dimension_weight",
    component: str = "scope_compliance",
    timestamp: float | None = None,
) -> ChangeRecord:
    return ChangeRecord(
        record_id=f"cr-{time.time_ns() % 100000:05d}",
        changed_by=changed_by,
        change_type=change_type,
        component=component,
        before_state={"weight": 1.0},
        after_state={"weight": 1.5},
        source="operator_action",
        timestamp=timestamp or time.time(),
    )


class TestJustificationRecord:
    """JustificationRecord append, query, hash chain."""

    def test_append_and_query(self):
        trail = AuditTrail()
        trail.append_justification(_make_justification())
        results = trail.query_justifications()
        assert len(results) == 1
        assert results[0].agent_id == "agent-1"

    def test_query_by_agent(self):
        trail = AuditTrail()
        trail.append_justification(_make_justification(agent_id="a"))
        trail.append_justification(_make_justification(agent_id="b"))
        results = trail.query_justifications(agent_id="a")
        assert len(results) == 1

    def test_query_by_action_id(self):
        trail = AuditTrail()
        trail.append_justification(_make_justification(action_id="act-x"))
        trail.append_justification(_make_justification(action_id="act-y"))
        results = trail.query_justifications(action_id="act-x")
        assert len(results) == 1

    def test_to_dict_roundtrip(self):
        rec = _make_justification()
        rec.prev_hash = "abc"
        rec.record_hash = rec.compute_hash()
        d = rec.to_dict()
        assert d["agent_id"] == "agent-1"
        assert d["record_hash"] == rec.record_hash
        assert d["coherence_score"] == pytest.approx(0.92, abs=0.001)

    def test_hash_chain_integrity(self):
        trail = AuditTrail()
        for _ in range(5):
            trail.append_justification(_make_justification())
        records = trail.justification_records
        valid, msg = verify_typed_chain(records)
        assert valid, msg

    def test_tamper_detected(self):
        trail = AuditTrail()
        trail.append_justification(_make_justification())
        trail.append_justification(_make_justification())
        records = trail.justification_records
        # Tamper with a record
        records[1].verdict = "TAMPERED"
        valid, msg = verify_typed_chain(records)
        assert not valid
        assert "Hash mismatch" in msg


class TestOutcomeRecord:
    """OutcomeRecord append, query, hash chain."""

    def test_append_and_query(self):
        trail = AuditTrail()
        trail.append_outcome(_make_outcome())
        results = trail.query_outcomes()
        assert len(results) == 1

    def test_query_by_agent(self):
        trail = AuditTrail()
        trail.append_outcome(_make_outcome(agent_id="a"))
        trail.append_outcome(_make_outcome(agent_id="b"))
        assert len(trail.query_outcomes(agent_id="a")) == 1

    def test_hash_chain_integrity(self):
        trail = AuditTrail()
        for _ in range(3):
            trail.append_outcome(_make_outcome())
        valid, msg = verify_typed_chain(trail.outcome_records)
        assert valid, msg

    def test_tamper_detected(self):
        trail = AuditTrail()
        trail.append_outcome(_make_outcome())
        trail.append_outcome(_make_outcome())
        records = trail.outcome_records
        records[0].decision_verdict = "TAMPERED"
        valid, _ = verify_typed_chain(records)
        assert not valid


class TestUnwrittenPolicyAdjustmentRecord:
    """UnwrittenPolicyAdjustmentRecord append, query, hash chain."""

    def test_append_and_query(self):
        trail = AuditTrail()
        trail.append_policy_adjustment(_make_policy_adjustment())
        results = trail.query_policy_adjustments()
        assert len(results) == 1
        assert results[0].observation_count == 15

    def test_hash_chain_integrity(self):
        trail = AuditTrail()
        for _ in range(3):
            trail.append_policy_adjustment(_make_policy_adjustment())
        valid, msg = verify_typed_chain(trail.policy_adjustment_records)
        assert valid, msg

    def test_tamper_detected(self):
        trail = AuditTrail()
        trail.append_policy_adjustment(_make_policy_adjustment())
        trail.append_policy_adjustment(_make_policy_adjustment())
        records = trail.policy_adjustment_records
        records[1].approved_by = "tampered"
        valid, _ = verify_typed_chain(records)
        assert not valid


class TestAccountabilityRecord:
    """AccountabilityRecord append, query, hash chain."""

    def test_append_and_query(self):
        trail = AuditTrail()
        trail.append_accountability(_make_accountability())
        results = trail.query_accountability()
        assert len(results) == 1
        assert results[0].human_action == "override"

    def test_query_by_human_id(self):
        trail = AuditTrail()
        trail.append_accountability(_make_accountability(human_id="h1"))
        trail.append_accountability(_make_accountability(human_id="h2"))
        assert len(trail.query_accountability(human_id="h1")) == 1

    def test_hash_chain_integrity(self):
        trail = AuditTrail()
        for _ in range(4):
            trail.append_accountability(_make_accountability())
        valid, msg = verify_typed_chain(trail.accountability_records)
        assert valid, msg

    def test_tamper_detected(self):
        trail = AuditTrail()
        trail.append_accountability(_make_accountability())
        trail.append_accountability(_make_accountability())
        records = trail.accountability_records
        records[0].stated_rationale = "tampered"
        valid, _ = verify_typed_chain(records)
        assert not valid


class TestChangeRecord:
    """ChangeRecord append, query, hash chain."""

    def test_append_and_query(self):
        trail = AuditTrail()
        trail.append_change(_make_change())
        results = trail.query_changes()
        assert len(results) == 1
        assert results[0].change_type == "dimension_weight"

    def test_query_by_changed_by(self):
        trail = AuditTrail()
        trail.append_change(_make_change(changed_by="admin"))
        trail.append_change(_make_change(changed_by="operator"))
        assert len(trail.query_changes(changed_by="admin")) == 1

    def test_query_by_change_type(self):
        trail = AuditTrail()
        trail.append_change(_make_change(change_type="dimension_weight"))
        trail.append_change(_make_change(change_type="threshold_change"))
        assert len(trail.query_changes(change_type="threshold_change")) == 1

    def test_hash_chain_integrity(self):
        trail = AuditTrail()
        for _ in range(3):
            trail.append_change(_make_change())
        valid, msg = verify_typed_chain(trail.change_records)
        assert valid, msg

    def test_tamper_detected(self):
        trail = AuditTrail()
        trail.append_change(_make_change())
        trail.append_change(_make_change())
        records = trail.change_records
        records[1].source = "tampered"
        valid, _ = verify_typed_chain(records)
        assert not valid


class TestIndependentChains:
    """Six record types maintain independent hash chains."""

    def test_chains_are_independent(self):
        """Appending to one chain does not affect another's hashes."""
        trail = AuditTrail()

        # Append to decision (AuditRecord) chain
        trail.append(_make_record())
        decision_hash = trail._last_hash

        # Append to justification chain
        trail.append_justification(_make_justification())
        justification_hash = trail._justification_last_hash

        # Decision chain hash should not have changed
        assert trail._last_hash == decision_hash
        # Justification chain hash should not equal decision chain hash
        assert justification_hash != decision_hash

    def test_all_six_chains_independent(self):
        """All six chains can grow independently without interference."""
        trail = AuditTrail()

        trail.append(_make_record())
        trail.append_justification(_make_justification())
        trail.append_outcome(_make_outcome())
        trail.append_policy_adjustment(_make_policy_adjustment())
        trail.append_accountability(_make_accountability())
        trail.append_change(_make_change())

        # Each chain has exactly one record
        assert len(trail.records) == 1
        assert len(trail.justification_records) == 1
        assert len(trail.outcome_records) == 1
        assert len(trail.policy_adjustment_records) == 1
        assert len(trail.accountability_records) == 1
        assert len(trail.change_records) == 1

        # All chains are independently valid
        from nomotic.audit import verify_chain
        valid, msg = verify_chain(list(reversed(trail.records)))
        assert valid, msg
        valid, msg = verify_typed_chain(trail.justification_records)
        assert valid, msg
        valid, msg = verify_typed_chain(trail.outcome_records)
        assert valid, msg
        valid, msg = verify_typed_chain(trail.policy_adjustment_records)
        assert valid, msg
        valid, msg = verify_typed_chain(trail.accountability_records)
        assert valid, msg
        valid, msg = verify_typed_chain(trail.change_records)
        assert valid, msg

    def test_clear_resets_all_chains(self):
        trail = AuditTrail()
        trail.append(_make_record())
        trail.append_justification(_make_justification())
        trail.append_change(_make_change())
        trail.clear()
        assert len(trail.records) == 0
        assert len(trail.justification_records) == 0
        assert len(trail.change_records) == 0


class TestJustificationFromRuntime:
    """JustificationRecord is emitted from GovernanceRuntime on every verdict."""

    def test_justification_emitted_on_allow(self):
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        from nomotic.monitor import DriftConfig

        config = RuntimeConfig(
            enable_audit=True,
            enable_fingerprints=True,
            drift_config=DriftConfig(window_size=50, check_interval=10, min_observations=10),
        )
        runtime = GovernanceRuntime(config=config)
        action = Action(agent_id="agent-1", action_type="read", target="/api/data")
        context = AgentContext(
            agent_id="agent-1",
            trust_profile=TrustProfile(agent_id="agent-1"),
        )
        verdict = runtime.evaluate(action, context)
        assert verdict.verdict == Verdict.ALLOW

        justifications = runtime.audit_trail.query_justifications(agent_id="agent-1")
        assert len(justifications) >= 1
        jr = justifications[0]
        assert jr.agent_id == "agent-1"
        assert jr.verdict == "ALLOW"
        assert isinstance(jr.determinative_factors, list)
        assert isinstance(jr.dimension_results, dict)
        assert jr.record_hash != ""

    def test_justification_emitted_on_deny(self):
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        from nomotic.monitor import DriftConfig

        config = RuntimeConfig(
            enable_audit=True,
            enable_fingerprints=True,
            drift_config=DriftConfig(window_size=50, check_interval=10, min_observations=10),
        )
        runtime = GovernanceRuntime(config=config)
        # Restrict scope so "delete" is denied
        scope = runtime.registry.get("scope_compliance")
        scope.configure_agent_scope("agent-1", {"read"})
        action = Action(agent_id="agent-1", action_type="delete", target="/api/data")
        context = AgentContext(
            agent_id="agent-1",
            trust_profile=TrustProfile(agent_id="agent-1"),
        )
        verdict = runtime.evaluate(action, context)
        assert verdict.verdict == Verdict.DENY

        justifications = runtime.audit_trail.query_justifications(agent_id="agent-1")
        assert len(justifications) >= 1
        jr = justifications[0]
        assert jr.verdict == "DENY"
        assert len(jr.determinative_factors) > 0

    def test_justification_chain_integrity_after_multiple_evaluations(self):
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        from nomotic.monitor import DriftConfig

        config = RuntimeConfig(
            enable_audit=True,
            enable_fingerprints=True,
            drift_config=DriftConfig(window_size=50, check_interval=10, min_observations=10),
        )
        runtime = GovernanceRuntime(config=config)
        for i in range(5):
            action = Action(agent_id="agent-1", action_type="read", target=f"/api/{i}")
            context = AgentContext(
                agent_id="agent-1",
                trust_profile=TrustProfile(agent_id="agent-1"),
            )
            runtime.evaluate(action, context)

        records = runtime.audit_trail.justification_records
        assert len(records) >= 5
        valid, msg = verify_typed_chain(records)
        assert valid, msg


class TestChangeRecordFromRuntime:
    """ChangeRecord is emitted when RuntimeConfig is modified."""

    def test_change_record_on_weight_change(self):
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        from nomotic.monitor import DriftConfig

        config = RuntimeConfig(
            enable_audit=True,
            enable_fingerprints=True,
            drift_config=DriftConfig(window_size=50, check_interval=10, min_observations=10),
        )
        runtime = GovernanceRuntime(config=config)
        runtime.set_dimension_weight("scope_compliance", 2.0, actor="admin")

        changes = runtime.audit_trail.query_changes()
        assert len(changes) >= 1
        cr = changes[0]
        assert cr.changed_by == "admin"
        assert cr.change_type == "dimension_weight"
        assert cr.component == "scope_compliance"
        assert cr.before_state["weight"] != cr.after_state["weight"]
        assert cr.after_state["weight"] == 2.0
