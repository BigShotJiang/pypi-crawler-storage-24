"""Tests for the Behavioral Command & Control interface."""

from __future__ import annotations

import time
from unittest import TestCase

from nomotic.control_plane import (
    BehavioralDirective,
    ControlPlane,
    DIRECTIVE_TYPES,
    DirectiveResult,
)
from nomotic.provenance import ProvenanceLog
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import Action, AgentContext, TrustProfile, Verdict


def _make_action(agent_id: str = "agent-1", action_type: str = "read") -> Action:
    return Action(
        id=f"act-{agent_id}-{action_type}",
        agent_id=agent_id,
        action_type=action_type,
        target="resource-1",
        parameters={},
    )


def _make_context(agent_id: str = "agent-1") -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=0.8),
    )


def _make_runtime(**overrides) -> GovernanceRuntime:
    """Build a runtime with control plane enabled."""
    defaults = dict(
        enable_fingerprints=True,
        enable_audit=True,
        enable_contextual_modifier=False,
        enable_workflow_governor=False,
        enable_equity_analysis=False,
        enable_bias_detection=False,
        enable_cross_dimensional=False,
        enable_contracts=True,
        enable_control_plane=True,
    )
    defaults.update(overrides)
    return GovernanceRuntime(RuntimeConfig(**defaults))


def _seed_agent(runtime: GovernanceRuntime, agent_id: str = "agent-1") -> None:
    """Seed the fingerprint observer with an agent by running a few evals."""
    for i in range(5):
        action = Action(
            id=f"seed-{agent_id}-{i}",
            agent_id=agent_id,
            action_type="read",
            target="resource",
            parameters={},
        )
        ctx = _make_context(agent_id)
        runtime.evaluate(action, ctx)


class TestBehavioralDirective(TestCase):
    """Tests for the BehavioralDirective dataclass."""

    def test_create_sets_id_and_timestamp(self) -> None:
        d = BehavioralDirective.create("quarantine", "operator@example.com")
        self.assertTrue(d.directive_id)
        self.assertGreater(d.issued_at, 0)
        self.assertEqual(d.directive_type, "quarantine")
        self.assertEqual(d.issued_by, "operator@example.com")

    def test_create_computes_expires_at(self) -> None:
        d = BehavioralDirective.create(
            "enforce", "ops", duration_seconds=3600,
        )
        self.assertIsNotNone(d.expires_at)
        self.assertAlmostEqual(
            d.expires_at, d.issued_at + 3600, delta=1.0,  # type: ignore[arg-type]
        )

    def test_create_no_duration_no_expiry(self) -> None:
        d = BehavioralDirective.create("release", "ops")
        self.assertIsNone(d.expires_at)

    def test_create_invalid_type_raises(self) -> None:
        with self.assertRaises(ValueError):
            BehavioralDirective.create("invalid_type", "ops")

    def test_to_dict_roundtrip(self) -> None:
        d = BehavioralDirective.create(
            "enforce", "ops",
            target_agents=["a1", "a2"],
            invariant_spec={"metric": "write-to-read", "operator": "lt", "threshold": 0.25},
            duration_seconds=7200,
            reason="testing",
        )
        data = d.to_dict()
        d2 = BehavioralDirective.from_dict(data)
        self.assertEqual(d.directive_id, d2.directive_id)
        self.assertEqual(d.directive_type, d2.directive_type)
        self.assertEqual(d.target_agents, d2.target_agents)
        self.assertEqual(d.invariant_spec, d2.invariant_spec)
        self.assertEqual(d.reason, d2.reason)

    def test_target_agents_converted_to_tuple(self) -> None:
        d = BehavioralDirective.create(
            "quarantine", "ops",
            target_agents=["a1", "a2"],
        )
        self.assertIsInstance(d.target_agents, tuple)
        self.assertEqual(d.target_agents, ("a1", "a2"))


class TestQuarantineForceEscalate(TestCase):
    """Test that quarantined agents get ESCALATE from runtime.evaluate()."""

    def test_quarantine_forces_escalate(self) -> None:
        runtime = _make_runtime()
        _seed_agent(runtime, "agent-1")

        # Issue quarantine directive
        directive = BehavioralDirective.create(
            "quarantine", "ops",
            target_agents=["agent-1"],
            reason="coordinated drift",
        )
        result = runtime.issue_directive(directive)
        self.assertTrue(result.success)
        self.assertIn("agent-1", result.agents_affected)

        # Now evaluate — should force ESCALATE
        action = _make_action("agent-1")
        ctx = _make_context("agent-1")
        verdict = runtime.evaluate(action, ctx)
        self.assertEqual(verdict.verdict, Verdict.ESCALATE)
        self.assertIn("quarantined", verdict.reasoning.lower())

    def test_release_restores_normal(self) -> None:
        runtime = _make_runtime()
        _seed_agent(runtime, "agent-1")

        # Quarantine
        q = BehavioralDirective.create(
            "quarantine", "ops", target_agents=["agent-1"],
        )
        runtime.issue_directive(q)

        # Verify quarantined
        action = _make_action("agent-1")
        ctx = _make_context("agent-1")
        v1 = runtime.evaluate(action, ctx)
        self.assertEqual(v1.verdict, Verdict.ESCALATE)

        # Release
        r = BehavioralDirective.create(
            "release", "ops", target_agents=["agent-1"],
        )
        result = runtime.issue_directive(r)
        self.assertTrue(result.success)

        # Should no longer be quarantined
        action2 = _make_action("agent-1", "read")
        ctx2 = _make_context("agent-1")
        v2 = runtime.evaluate(action2, ctx2)
        self.assertNotEqual(v2.verdict, Verdict.ESCALATE)


class TestEnforceInvariant(TestCase):
    """Test enforce directive adds invariants to agents."""

    def test_enforce_adds_invariant(self) -> None:
        runtime = _make_runtime()
        _seed_agent(runtime, "agent-1")

        spec = {"metric": "write-to-read", "operator": "lt", "threshold": 0.25}
        directive = BehavioralDirective.create(
            "enforce", "ops",
            target_agents=["agent-1"],
            invariant_spec=spec,
        )
        result = runtime.issue_directive(directive)
        self.assertTrue(result.success)

        cp = runtime._control_plane
        invariants = cp.get_enforced_invariants("agent-1")
        self.assertEqual(len(invariants), 1)
        self.assertEqual(invariants[0]["spec"], spec)


class TestTightenRelax(TestCase):
    """Test tighten and relax directives."""

    def test_tighten_reduces_thresholds(self) -> None:
        runtime = _make_runtime()
        _seed_agent(runtime, "agent-1")

        directive = BehavioralDirective.create(
            "tighten", "ops",
            target_agents=["agent-1"],
            tighten_factor=0.5,
        )
        result = runtime.issue_directive(directive)
        self.assertTrue(result.success)

        cp = runtime._control_plane
        self.assertAlmostEqual(cp.get_tighten_factor("agent-1"), 0.5)

    def test_relax_removes_tightening(self) -> None:
        runtime = _make_runtime()
        _seed_agent(runtime, "agent-1")

        # Tighten first
        t = BehavioralDirective.create(
            "tighten", "ops",
            target_agents=["agent-1"],
            tighten_factor=0.5,
        )
        runtime.issue_directive(t)
        cp = runtime._control_plane
        self.assertAlmostEqual(cp.get_tighten_factor("agent-1"), 0.5)

        # Now relax
        r = BehavioralDirective.create(
            "relax", "ops",
            target_agents=["agent-1"],
        )
        result = runtime.issue_directive(r)
        self.assertTrue(result.success)
        self.assertAlmostEqual(cp.get_tighten_factor("agent-1"), 1.0)


class TestReAnchor(TestCase):
    """Test re_anchor directive updates semantic observer."""

    def test_re_anchor_updates_semantic(self) -> None:
        runtime = _make_runtime()
        _seed_agent(runtime, "agent-1")

        # Set initial anchors
        from nomotic.semantic import SemanticAnchor
        observer = runtime._fingerprint_observer
        self.assertIsNotNone(observer)
        observer.set_semantic_anchors("agent-1", [
            SemanticAnchor(
                term="research",
                expected_action_distribution={"read": 0.8, "write": 0.2},
                expected_target_distribution={"kb": 1.0},
                tolerance=0.2,
            ),
        ])

        # Issue re-anchor directive
        directive = BehavioralDirective.create(
            "re_anchor", "ops",
            target_agents=["agent-1"],
            semantic_term="research",
        )
        result = runtime.issue_directive(directive)
        self.assertTrue(result.success)
        self.assertIn("agent-1", result.agents_affected)

        # Verify anchors were reset
        anchors = observer.semantic_observer.get_anchors("agent-1")
        research_anchors = [a for a in anchors if a.term == "research"]
        self.assertEqual(len(research_anchors), 1)
        # The reset anchor should have empty distributions
        self.assertEqual(research_anchors[0].expected_action_distribution, {})


class TestDirectiveExpiration(TestCase):
    """Test that directives expire and undo their effects."""

    def test_directive_expiration(self) -> None:
        runtime = _make_runtime()
        _seed_agent(runtime, "agent-1")

        # Quarantine with 1-second duration
        directive = BehavioralDirective.create(
            "quarantine", "ops",
            target_agents=["agent-1"],
            duration_seconds=1.0,
        )
        runtime.issue_directive(directive)

        cp = runtime._control_plane
        self.assertTrue(cp.is_quarantined("agent-1"))

        # Wait for expiration
        time.sleep(2.0)
        expired = cp.expire_directives()
        self.assertGreaterEqual(expired, 1)
        self.assertFalse(cp.is_quarantined("agent-1"))


class TestTargetResolution(TestCase):
    """Test target resolution logic."""

    def test_target_resolution_by_agent(self) -> None:
        runtime = _make_runtime()
        _seed_agent(runtime, "agent-1")
        _seed_agent(runtime, "agent-2")

        directive = BehavioralDirective.create(
            "quarantine", "ops",
            target_agents=["agent-1"],
        )
        result = runtime.issue_directive(directive)
        self.assertTrue(result.success)
        self.assertEqual(result.agents_affected, ["agent-1"])

        # agent-2 should not be quarantined
        cp = runtime._control_plane
        self.assertTrue(cp.is_quarantined("agent-1"))
        self.assertFalse(cp.is_quarantined("agent-2"))

    def test_target_resolution_by_drift_status(self) -> None:
        runtime = _make_runtime()
        # Seed agents — they won't actually be drifting without enough data,
        # so a directive targeting drifting agents should affect none
        _seed_agent(runtime, "agent-1")

        directive = BehavioralDirective.create(
            "tighten", "ops",
            target_drift_status="critical",
            tighten_factor=0.3,
        )
        result = runtime.issue_directive(directive)
        # With fresh agents, no one should be critically drifting
        self.assertFalse(result.success)
        self.assertEqual(result.detail, "No matching agents")

    def test_no_targets_returns_failure(self) -> None:
        runtime = _make_runtime()
        # Don't seed any agents — empty fleet
        directive = BehavioralDirective.create(
            "quarantine", "ops",
            target_archetype="nonexistent-archetype",
        )
        result = runtime.issue_directive(directive)
        self.assertFalse(result.success)
        self.assertEqual(result.detail, "No matching agents")


class TestProvenanceRecorded(TestCase):
    """Test that directives are recorded in provenance."""

    def test_provenance_recorded(self) -> None:
        runtime = _make_runtime()
        _seed_agent(runtime, "agent-1")

        directive = BehavioralDirective.create(
            "quarantine", "ops",
            target_agents=["agent-1"],
            reason="test quarantine",
        )
        runtime.issue_directive(directive)

        # Check provenance log
        plog = runtime._provenance_log
        self.assertIsNotNone(plog)
        records = plog.query(target_type="directive")
        self.assertGreaterEqual(len(records), 1)
        latest = records[0]
        self.assertEqual(latest.actor, "ops")
        self.assertEqual(latest.actor_type, "operator")
        self.assertEqual(latest.target_type, "directive")
        self.assertEqual(latest.change_type, "add")
        self.assertEqual(latest.reason, "test quarantine")
        self.assertEqual(latest.context_code, "CONTROL.DIRECTIVE_ISSUED")


class TestControlPlaneDisabled(TestCase):
    """Test that runtime gracefully handles control plane when disabled."""

    def test_issue_directive_when_disabled(self) -> None:
        runtime = GovernanceRuntime(RuntimeConfig(
            enable_control_plane=False,
            enable_contextual_modifier=False,
            enable_workflow_governor=False,
            enable_equity_analysis=False,
            enable_bias_detection=False,
            enable_cross_dimensional=False,
        ))
        directive = BehavioralDirective.create(
            "quarantine", "ops", target_agents=["agent-1"],
        )
        result = runtime.issue_directive(directive)
        self.assertFalse(result.success)
        self.assertIn("not enabled", result.detail)

    def test_get_directives_when_disabled(self) -> None:
        runtime = GovernanceRuntime(RuntimeConfig(
            enable_control_plane=False,
            enable_contextual_modifier=False,
            enable_workflow_governor=False,
            enable_equity_analysis=False,
            enable_bias_detection=False,
            enable_cross_dimensional=False,
        ))
        self.assertEqual(runtime.get_control_directives(), [])


class TestBroadcastReminder(TestCase):
    """Test broadcast_reminder directive."""

    def test_broadcast_reminder(self) -> None:
        runtime = _make_runtime()
        _seed_agent(runtime, "agent-1")

        directive = BehavioralDirective.create(
            "broadcast_reminder", "ops",
            target_agents=["agent-1"],
            contract_version="v2.3",
            reason="compliance re-assertion",
        )
        result = runtime.issue_directive(directive)
        self.assertTrue(result.success)
        self.assertIn("agent-1", result.agents_affected)


class TestDirectiveTypes(TestCase):
    """Test directive type constants."""

    def test_all_types_present(self) -> None:
        expected = {
            "enforce", "quarantine", "release",
            "broadcast_reminder", "tighten", "relax", "re_anchor",
        }
        self.assertEqual(DIRECTIVE_TYPES, expected)
