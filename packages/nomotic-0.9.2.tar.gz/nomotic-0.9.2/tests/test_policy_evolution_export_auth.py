"""Tests for Policy Evolution export visibility and auth on write endpoints.

Verifies:
1. PolicyEvolutionEngine is importable via direct path
2. PolicyEvolutionEngine is NOT in nomotic.__all__
3. Policy evolution write endpoints (approve/reject/apply) require API key auth
"""

from __future__ import annotations

import json
import threading
import time
import uuid
import urllib.error
import urllib.request
from types import SimpleNamespace
from typing import Any

import pytest

from nomotic.api import NomoticAPIServer
from nomotic.audit import (
    AccountabilityRecord,
    AuditRecord,
    AuditTrail,
)
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.store import MemoryCertificateStore


# ── Import visibility tests ──────────────────────────────────────────


class TestPolicyEvolutionExportVisibility:
    """PolicyEvolutionEngine is importable but not in top-level __all__."""

    def test_import_by_path_succeeds(self) -> None:
        from nomotic.policy_evolution import PolicyEvolutionEngine

        assert PolicyEvolutionEngine is not None

    def test_not_in_nomotic_all(self) -> None:
        import nomotic

        assert "PolicyEvolutionEngine" not in nomotic.__all__


# ── Auth integration tests ───────────────────────────────────────────


API_KEY = "test-pe-auth-key-99"


def _make_runtime_with_data() -> SimpleNamespace:
    """Build a minimal runtime-like object with enough data for pattern detection."""
    trail = AuditTrail(max_records=1000)
    now = time.time()
    for i in range(12):
        aid = f"action-auth-{i}"
        trail.append(AuditRecord(
            record_id=uuid.uuid4().hex[:12],
            timestamp=now - (i * 3600),
            context_code="GOVERNANCE.DENY",
            severity="info",
            agent_id="agent-1",
            owner_id="owner@example.com",
            user_id="user@example.com",
            action_id=aid,
            action_type="data_export",
            action_target="/data/sensitive",
            verdict="DENY",
            ucs=0.35,
            tier=2,
            dimension_scores=[],
        ))
        trail.append_accountability(AccountabilityRecord(
            record_id=uuid.uuid4().hex[:12],
            action_id=aid,
            human_id="admin@example.com",
            human_action="override_approved",
            original_verdict="DENY",
            resulting_verdict="ALLOW",
            stated_rationale="Business-critical",
            timestamp=now - (i * 3600) + 60,
        ))
    return SimpleNamespace(audit_trail=trail, provenance_log=None)


def _find_free_port() -> int:
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _request(
    base_url: str,
    method: str,
    path: str,
    data: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
) -> tuple[int, dict[str, Any] | str]:
    url = f"{base_url}{path}"
    payload = json.dumps(data or {}).encode("utf-8") if method != "GET" else None
    req = urllib.request.Request(url, data=payload, method=method)
    req.add_header("Content-Type", "application/json")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read()
            try:
                return resp.status, json.loads(raw)
            except json.JSONDecodeError:
                return resp.status, raw.decode()
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw)
        except json.JSONDecodeError:
            return e.code, raw.decode()


@pytest.fixture(scope="module")
def auth_server() -> tuple[str, NomoticAPIServer]:
    """Server with API key auth enabled and populated audit data."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=store)
    runtime = _make_runtime_with_data()
    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        runtime=runtime,
        host="127.0.0.1",
        port=port,
        api_key=API_KEY,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.3)
    base = f"http://127.0.0.1:{port}"
    yield base, server
    server.shutdown()


def _get_rec_id(base: str) -> str:
    """Trigger analysis and return the first recommendation ID."""
    _request(base, "GET", "/v1/policy-evolution/patterns")
    status, data = _request(base, "GET", "/v1/policy-evolution/recommendations")
    assert status == 200
    assert data["total"] >= 1, "Expected recommendations from seeded data"
    return data["recommendations"][0]["recommendation_id"]


class TestPolicyEvolutionWriteAuth:
    """Write endpoints require API key when auth is enabled."""

    def test_get_patterns_no_key_allowed(self, auth_server: tuple[str, NomoticAPIServer]) -> None:
        """GET endpoints do not require auth."""
        base, _ = auth_server
        status, _ = _request(base, "GET", "/v1/policy-evolution/patterns")
        assert status != 401

    def test_get_recommendations_no_key_allowed(self, auth_server: tuple[str, NomoticAPIServer]) -> None:
        """GET endpoints do not require auth."""
        base, _ = auth_server
        status, _ = _request(base, "GET", "/v1/policy-evolution/recommendations")
        assert status != 401

    def test_approve_without_key_rejected(self, auth_server: tuple[str, NomoticAPIServer]) -> None:
        """POST approve without API key returns 401."""
        base, _ = auth_server
        rec_id = _get_rec_id(base)
        status, body = _request(
            base, "POST",
            f"/v1/policy-evolution/recommendations/{rec_id}/approve",
            data={"approved_by": "test"},
        )
        assert status == 401

    def test_reject_without_key_rejected(self, auth_server: tuple[str, NomoticAPIServer]) -> None:
        """POST reject without API key returns 401."""
        base, _ = auth_server
        rec_id = _get_rec_id(base)
        status, body = _request(
            base, "POST",
            f"/v1/policy-evolution/recommendations/{rec_id}/reject",
            data={"rejected_by": "test"},
        )
        assert status == 401

    def test_apply_without_key_rejected(self, auth_server: tuple[str, NomoticAPIServer]) -> None:
        """POST apply without API key returns 401."""
        base, _ = auth_server
        status, body = _request(
            base, "POST",
            "/v1/policy-evolution/recommendations/any-id/apply",
            data={},
        )
        assert status == 401

    def test_approve_with_wrong_key_rejected(self, auth_server: tuple[str, NomoticAPIServer]) -> None:
        """POST approve with wrong API key returns 401."""
        base, _ = auth_server
        rec_id = _get_rec_id(base)
        status, body = _request(
            base, "POST",
            f"/v1/policy-evolution/recommendations/{rec_id}/approve",
            data={"approved_by": "test"},
            headers={"X-Nomotic-API-Key": "wrong-key"},
        )
        assert status == 401

    def test_approve_with_correct_key_passes(self, auth_server: tuple[str, NomoticAPIServer]) -> None:
        """POST approve with correct API key succeeds (not 401)."""
        base, _ = auth_server
        rec_id = _get_rec_id(base)
        status, body = _request(
            base, "POST",
            f"/v1/policy-evolution/recommendations/{rec_id}/approve",
            data={"approved_by": "admin@co.com", "note": "OK"},
            headers={"X-Nomotic-API-Key": API_KEY},
        )
        assert status != 401

    def test_reject_with_correct_key_passes(self, auth_server: tuple[str, NomoticAPIServer]) -> None:
        """POST reject with correct API key succeeds (not 401)."""
        base, _ = auth_server
        rec_id = _get_rec_id(base)
        status, body = _request(
            base, "POST",
            f"/v1/policy-evolution/recommendations/{rec_id}/reject",
            data={"rejected_by": "admin@co.com", "note": "Nope"},
            headers={"X-Nomotic-API-Key": API_KEY},
        )
        assert status != 401
