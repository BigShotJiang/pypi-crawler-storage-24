"""Tests for LLMConfig and its integration with LicenseConfig."""

from nomotic.llm import LLMConfig, NOMOTIC_CLOUD_LLM
from nomotic.license import LicenseConfig


class TestLLMConfigDefaults:
    """LLMConfig constructs with sensible defaults."""

    def test_default_endpoint(self):
        cfg = LLMConfig()
        assert cfg.endpoint == "https://api.nomotic.ai/v1/llm"

    def test_default_model(self):
        cfg = LLMConfig()
        assert cfg.model == "nomotic-governance-v1"

    def test_default_api_key_is_none(self):
        cfg = LLMConfig()
        assert cfg.api_key is None

    def test_default_timeout_ms(self):
        cfg = LLMConfig()
        assert cfg.timeout_ms == 2000

    def test_default_fallback_to_heuristic(self):
        cfg = LLMConfig()
        assert cfg.fallback_to_heuristic is True

    def test_default_max_retries(self):
        cfg = LLMConfig()
        assert cfg.max_retries == 1


class TestLLMConfigOverrides:
    """All fields can be overridden."""

    def test_all_fields(self):
        cfg = LLMConfig(
            endpoint="http://localhost:11434",
            model="llama3.1:70b",
            api_key="sk-test",
            timeout_ms=5000,
            fallback_to_heuristic=False,
            max_retries=3,
        )
        assert cfg.endpoint == "http://localhost:11434"
        assert cfg.model == "llama3.1:70b"
        assert cfg.api_key == "sk-test"
        assert cfg.timeout_ms == 5000
        assert cfg.fallback_to_heuristic is False
        assert cfg.max_retries == 3


class TestNomoticCloudLLMConstant:
    """NOMOTIC_CLOUD_LLM is pre-configured for Nomotic Cloud."""

    def test_endpoint(self):
        assert NOMOTIC_CLOUD_LLM.endpoint == "https://api.nomotic.ai/v1/llm"

    def test_model(self):
        assert NOMOTIC_CLOUD_LLM.model == "nomotic-governance-v1"

    def test_is_llmconfig_instance(self):
        assert isinstance(NOMOTIC_CLOUD_LLM, LLMConfig)


class TestLicenseConfigAcceptsLLMConfig:
    """LicenseConfig.llm_config accepts an LLMConfig instance."""

    def test_default_is_none(self):
        lc = LicenseConfig()
        assert lc.llm_config is None

    def test_accepts_llmconfig(self):
        llm = LLMConfig(endpoint="http://localhost:11434", model="test")
        lc = LicenseConfig(llm_config=llm)
        assert lc.llm_config is llm
        assert lc.llm_config.endpoint == "http://localhost:11434"

    def test_accepts_nomotic_cloud_constant(self):
        lc = LicenseConfig(llm_config=NOMOTIC_CLOUD_LLM)
        assert lc.llm_config.endpoint == "https://api.nomotic.ai/v1/llm"


class TestTopLevelExports:
    """LLMConfig and NOMOTIC_CLOUD_LLM are importable from nomotic."""

    def test_import_llmconfig(self):
        from nomotic import LLMConfig as LC
        assert LC is LLMConfig

    def test_import_nomotic_cloud_llm(self):
        from nomotic import NOMOTIC_CLOUD_LLM as cloud
        assert cloud is NOMOTIC_CLOUD_LLM
