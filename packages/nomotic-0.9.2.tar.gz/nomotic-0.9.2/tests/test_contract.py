"""Tests for the Behavioral Contract system."""

from __future__ import annotations

import dataclasses
import threading
import time
from unittest import TestCase

from nomotic.certificate import AgentCertificate, CertStatus
from nomotic.contract import BehavioralContract, ContractStore, generate_contract
from nomotic.keys import SigningKey
from nomotic.priors import PriorRegistry
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import Action, AgentContext, TrustProfile, Verdict


def _make_contract(
    agent_id: str = "agent-1",
    version: int = 1,
    **kwargs,
) -> BehavioralContract:
    defaults = dict(
        contract_id=f"test-contract-{version}",
        version=version,
        agent_id=agent_id,
        created_at=time.time(),
        archetype="customer-experience",
        expected_action_distribution={"read": 0.6, "query": 0.3, "write": 0.1},
        expected_target_distribution={"crm": 0.5, "kb": 0.3, "email": 0.2},
        expected_outcome_distribution={"allow": 0.85, "deny": 0.10, "escalate": 0.05},
        drift_thresholds={"action": 0.15, "target": 0.20},
    )
    defaults.update(kwargs)
    return BehavioralContract(**defaults)


class TestBehavioralContract(TestCase):
    """Tests for BehavioralContract dataclass."""

    def test_creation(self) -> None:
        c = _make_contract()
        self.assertEqual(c.agent_id, "agent-1")
        self.assertEqual(c.version, 1)
        self.assertEqual(c.archetype, "customer-experience")
        self.assertIn("read", c.expected_action_distribution)
        self.assertEqual(c.drift_thresholds["action"], 0.15)

    def test_content_hash_deterministic(self) -> None:
        c = _make_contract()
        h1 = c.content_hash()
        h2 = c.content_hash()
        self.assertEqual(h1, h2)

    def test_content_hash_excludes_signature(self) -> None:
        c = _make_contract()
        sk, vk = SigningKey.generate()
        sealed = c.seal(sk)
        self.assertEqual(c.content_hash(), sealed.content_hash())

    def test_content_hash_changes_on_field_change(self) -> None:
        c1 = _make_contract()
        c2 = dataclasses.replace(c1, archetype="security-monitor")
        self.assertNotEqual(c1.content_hash(), c2.content_hash())

    def test_to_dict_roundtrip(self) -> None:
        c = _make_contract()
        d = c.to_dict()
        c2 = BehavioralContract.from_dict(d)
        self.assertEqual(c.contract_id, c2.contract_id)
        self.assertEqual(c.agent_id, c2.agent_id)
        self.assertEqual(c.version, c2.version)
        self.assertEqual(c.expected_action_distribution, c2.expected_action_distribution)
        self.assertEqual(c.drift_thresholds, c2.drift_thresholds)

    def test_to_dict_includes_all_fields(self) -> None:
        c = _make_contract()
        d = c.to_dict()
        for f in dataclasses.fields(c):
            self.assertIn(f.name, d)

    def test_seal_and_verify(self) -> None:
        c = _make_contract()
        sk, vk = SigningKey.generate()
        sealed = c.seal(sk, signer_id="operator-1")
        self.assertTrue(sealed.signature)
        self.assertEqual(sealed.signed_by, "operator-1")
        self.assertTrue(sealed.verify(vk))

    def test_verify_fails_with_wrong_key(self) -> None:
        c = _make_contract()
        sk_a, vk_a = SigningKey.generate()
        sk_b, vk_b = SigningKey.generate()
        sealed = c.seal(sk_a)
        self.assertFalse(sealed.verify(vk_b))

    def test_verify_fails_on_tampered_contract(self) -> None:
        c = _make_contract()
        sk, vk = SigningKey.generate()
        sealed = c.seal(sk)
        tampered = dataclasses.replace(
            sealed,
            archetype="malicious-agent",
        )
        # tampered has same signature but different content
        self.assertFalse(tampered.verify(vk))

    def test_diff_detects_distribution_change(self) -> None:
        c1 = _make_contract(version=1)
        c2 = dataclasses.replace(
            c1,
            contract_id="test-contract-2",
            version=2,
            expected_action_distribution={"read": 0.4, "query": 0.4, "write": 0.2},
        )
        diff = c1.diff(c2)
        self.assertEqual(diff["version_from"], 1)
        self.assertEqual(diff["version_to"], 2)
        self.assertIn("expected_action_distribution", diff["changes"])

    def test_diff_detects_threshold_change(self) -> None:
        c1 = _make_contract(version=1)
        c2 = dataclasses.replace(
            c1,
            contract_id="test-contract-2",
            version=2,
            drift_thresholds={"action": 0.25, "target": 0.20},
        )
        diff = c1.diff(c2)
        self.assertIn("drift_thresholds", diff["changes"])
        self.assertIn("action", diff["changes"]["drift_thresholds"])

    def test_diff_no_changes(self) -> None:
        c1 = _make_contract(version=1)
        c2 = dataclasses.replace(c1, version=2)
        diff = c1.diff(c2)
        # Only version changed, which is expected
        changes = diff["changes"]
        # version itself is not in skip list, so it will appear
        self.assertNotIn("expected_action_distribution", changes)
        self.assertNotIn("drift_thresholds", changes)

    def test_diff_wrong_agent_raises(self) -> None:
        c1 = _make_contract(agent_id="agent-1", version=1)
        c2 = _make_contract(agent_id="agent-2", version=2)
        with self.assertRaises(ValueError):
            c1.diff(c2)

    def test_frozen_immutable(self) -> None:
        c = _make_contract()
        with self.assertRaises(dataclasses.FrozenInstanceError):
            c.agent_id = "other"  # type: ignore[misc]


class TestContractStore(TestCase):
    """Tests for ContractStore."""

    def test_store_and_retrieve(self) -> None:
        store = ContractStore()
        c = _make_contract()
        store.store(c)
        result = store.get_active("agent-1")
        self.assertIsNotNone(result)
        self.assertEqual(result.contract_id, c.contract_id)

    def test_store_multiple_versions(self) -> None:
        store = ContractStore()
        c1 = _make_contract(version=1)
        c2 = dataclasses.replace(c1, contract_id="v2", version=2)
        store.store(c1)
        store.store(c2)
        active = store.get_active("agent-1")
        self.assertEqual(active.version, 2)
        v1 = store.get_version("agent-1", 1)
        self.assertEqual(v1.version, 1)

    def test_store_version_must_increase(self) -> None:
        store = ContractStore()
        c1 = _make_contract(version=1)
        c1_dup = dataclasses.replace(c1, contract_id="other")
        store.store(c1)
        with self.assertRaises(ValueError):
            store.store(c1_dup)

    def test_store_lower_version_raises(self) -> None:
        store = ContractStore()
        c2 = _make_contract(version=2)
        c1 = _make_contract(version=1)
        store.store(c2)
        with self.assertRaises(ValueError):
            store.store(c1)

    def test_get_active_nonexistent(self) -> None:
        store = ContractStore()
        self.assertIsNone(store.get_active("nobody"))

    def test_get_history(self) -> None:
        store = ContractStore()
        c1 = _make_contract(version=1)
        c2 = dataclasses.replace(c1, contract_id="v2", version=2)
        c3 = dataclasses.replace(c1, contract_id="v3", version=3)
        store.store(c1)
        store.store(c2)
        store.store(c3)
        history = store.get_history("agent-1")
        self.assertEqual(len(history), 3)
        self.assertEqual([c.version for c in history], [1, 2, 3])

    def test_revoke(self) -> None:
        store = ContractStore()
        c = _make_contract()
        store.store(c)
        self.assertTrue(store.revoke("agent-1"))
        self.assertIsNone(store.get_active("agent-1"))
        # History preserved
        self.assertEqual(len(store.get_history("agent-1")), 1)

    def test_revoke_nonexistent(self) -> None:
        store = ContractStore()
        self.assertFalse(store.revoke("nobody"))

    def test_all_active(self) -> None:
        store = ContractStore()
        c1 = _make_contract(agent_id="agent-1", version=1)
        c2 = _make_contract(agent_id="agent-2", version=1)
        store.store(c1)
        store.store(c2)
        active = store.all_active()
        self.assertEqual(len(active), 2)
        self.assertIn("agent-1", active)
        self.assertIn("agent-2", active)

    def test_thread_safety(self) -> None:
        store = ContractStore()
        errors: list[Exception] = []

        def store_contracts(agent_prefix: str) -> None:
            try:
                for i in range(1, 11):
                    c = _make_contract(
                        agent_id=f"{agent_prefix}-{i}",
                        version=1,
                    )
                    store.store(c)
                    store.get_active(f"{agent_prefix}-{i}")
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=store_contracts, args=(f"batch-{n}",))
            for n in range(5)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(len(errors), 0)
        self.assertEqual(len(store.all_active()), 50)


class TestGenerateContract(TestCase):
    """Tests for generate_contract."""

    def test_from_known_archetype(self) -> None:
        registry = PriorRegistry.with_defaults()
        c = generate_contract("agent-1", "customer-experience", registry)
        self.assertEqual(c.agent_id, "agent-1")
        self.assertEqual(c.archetype, "customer-experience")
        self.assertTrue(len(c.expected_action_distribution) > 0)
        self.assertTrue(len(c.expected_target_distribution) > 0)
        self.assertTrue(len(c.expected_outcome_distribution) > 0)

    def test_from_unknown_archetype(self) -> None:
        registry = PriorRegistry.with_defaults()
        c = generate_contract("agent-1", "nonexistent-archetype", registry)
        self.assertEqual(c.archetype, "nonexistent-archetype")
        self.assertEqual(c.expected_action_distribution, {})
        self.assertEqual(c.expected_target_distribution, {})
        self.assertEqual(c.expected_outcome_distribution, {})

    def test_with_certificate(self) -> None:
        from datetime import datetime, timezone
        registry = PriorRegistry.with_defaults()
        cert = AgentCertificate(
            certificate_id="nmc-test-123",
            agent_id="agent-1",
            owner="test-owner",
            archetype="customer-experience",
            organization="test-org",
            zone_path="/us/test",
            issued_at=datetime.now(timezone.utc),
            trust_score=0.5,
            behavioral_age=0,
            status=CertStatus.ACTIVE,
            public_key=b"\x00" * 32,
            fingerprint="SHA256:test",
            governance_hash="abc",
            lineage=None,
            issuer_signature=b"\x00" * 32,
        )
        c = generate_contract(
            "agent-1", "customer-experience", registry, certificate=cert,
        )
        self.assertEqual(c.certificate_id, "nmc-test-123")

    def test_with_scope_override(self) -> None:
        registry = PriorRegistry.with_defaults()
        custom_scope = {"action_types": ["read", "write"], "targets": ["/data/*"]}
        c = generate_contract(
            "agent-1", "customer-experience", registry, scope=custom_scope,
        )
        self.assertEqual(c.authorized_scope, custom_scope)

    def test_with_invariants(self) -> None:
        registry = PriorRegistry.with_defaults()
        invariants = [{"type": "rate_limit", "max_per_hour": 100}]
        c = generate_contract(
            "agent-1", "customer-experience", registry, invariants=invariants,
        )
        self.assertEqual(c.invariants, invariants)

    def test_with_drift_thresholds(self) -> None:
        registry = PriorRegistry.with_defaults()
        thresholds = {"action": 0.10, "target": 0.15}
        c = generate_contract(
            "agent-1", "customer-experience", registry, drift_thresholds=thresholds,
        )
        self.assertEqual(c.drift_thresholds, thresholds)


class TestContractRuntimeIntegration(TestCase):
    """Tests for contract integration with GovernanceRuntime."""

    def test_runtime_creates_contract_store(self) -> None:
        runtime = GovernanceRuntime(RuntimeConfig(enable_contracts=True))
        self.assertIsNotNone(runtime._contract_store)

    def test_runtime_set_get_contract(self) -> None:
        runtime = GovernanceRuntime(RuntimeConfig(enable_contracts=True))
        c = _make_contract()
        runtime.set_contract(c)
        result = runtime.get_contract("agent-1")
        self.assertIsNotNone(result)
        self.assertEqual(result.contract_id, c.contract_id)

    def test_contract_drift_thresholds_checked(self) -> None:
        """Create contract with tight drift threshold, run diverse actions,
        and verify threshold violations appear in verdict metadata."""
        config = RuntimeConfig(
            enable_contracts=True,
            enable_fingerprints=True,
            enable_audit=False,
            enable_contextual_modifier=False,
            enable_workflow_governor=False,
            enable_equity_analysis=False,
            enable_bias_detection=False,
            enable_cross_dimensional=False,
        )
        runtime = GovernanceRuntime(config)

        # Set contract with very tight action drift threshold
        contract = _make_contract(
            drift_thresholds={"action": 0.01},
        )
        runtime.set_contract(contract)

        context = AgentContext(
            agent_id="agent-1",
            trust_profile=TrustProfile(agent_id="agent-1", overall_trust=0.5),
        )

        # Run many evaluations with varied action types to build fingerprint
        # First, establish baseline with "read" actions
        for _ in range(30):
            action = Action(agent_id="agent-1", action_type="read", target="/data")
            runtime.evaluate(action, context)

        # Now shift dramatically to "delete" actions to create drift
        for _ in range(30):
            action = Action(agent_id="agent-1", action_type="delete", target="/data")
            verdict = runtime.evaluate(action, context)

        # Check if drift exceeded the threshold — the last verdict should
        # have metadata about threshold violations if drift was detected.
        # Note: drift detection requires enough observations in the sliding window.
        # We check the last verdict's metadata.
        if verdict.metadata and "contract_threshold_violations" in verdict.metadata:
            violations = verdict.metadata["contract_threshold_violations"]
            self.assertIn("action", violations)
            self.assertGreater(violations["action"]["current"], 0.01)
