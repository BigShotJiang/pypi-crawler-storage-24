"""Shared test fixtures for the Nomotic test suite."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from nomotic.license import ActivatedTier, LicenseConfig, LicenseGate, LicenseInfo


class MockProValidator:
    """A mock license validator that returns PRO tier for 'valid-pro-key'."""

    def validate(self, key: str, config: LicenseConfig) -> LicenseInfo:
        if key == "valid-pro-key":
            return LicenseInfo(tier=ActivatedTier.PRO, org_id="test-org")
        raise ValueError("Invalid key")


class MockEnterpriseValidator:
    """A mock license validator that returns ENTERPRISE tier."""

    def validate(self, key: str, config: LicenseConfig) -> LicenseInfo:
        if key == "valid-enterprise-key":
            return LicenseInfo(
                tier=ActivatedTier.ENTERPRISE,
                org_id="test-org",
                features=["dimensions_pro", "behavioral_engine"],
            )
        raise ValueError("Invalid key")


def _make_mock_entry_point(validator_class):
    """Create a mock entry point that loads the given validator class."""
    return type(
        "MockEP",
        (),
        {
            "name": "validator",
            "value": "mock:MockValidator",
            "load": staticmethod(lambda cls=validator_class: cls),
        },
    )()


@pytest.fixture()
def mock_pro_validator():
    """Installs a mock license validator that returns PRO tier.

    Use with LicenseConfig(key="valid-pro-key") to get PRO tier.
    """
    mock_ep = _make_mock_entry_point(MockProValidator)
    with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
        yield


@pytest.fixture()
def pro_license_key(mock_pro_validator):
    """Return a license key that activates PRO tier via mock validator."""
    return "valid-pro-key"
