"""Tests for behavioral invariants — declarative rules for the Behavioral Control Plane."""

from __future__ import annotations

import time
import uuid
from unittest import TestCase

from nomotic.contract import BehavioralContract
from nomotic.drift import DriftScore
from nomotic.fingerprint import BehavioralFingerprint
from nomotic.invariants import (
    VALID_OPERATORS,
    VALID_TYPES,
    CompiledInvariants,
    InvariantBuilder,
    InvariantResult,
    InvariantSpec,
)
from nomotic.semantic import SemanticDriftScore
from nomotic.types import Action


def _fingerprint(action_dist=None, target_dist=None):
    """Create a BehavioralFingerprint with known distributions."""
    fp = BehavioralFingerprint(agent_id="test-agent")
    fp.action_distribution = action_dist or {"read": 0.7, "write": 0.2, "query": 0.1}
    fp.target_distribution = target_dist or {
        "/data/reports": 0.6,
        "/data/users": 0.3,
        "/data/logs": 0.1,
    }
    fp.total_observations = 100
    return fp


def _drift_score(
    action=0.0, target=0.0, temporal=0.0, outcome=0.0, semantic=0.0, overall=0.0
):
    """Create a DriftScore with specified values."""
    return DriftScore(
        overall=overall,
        action_drift=action,
        target_drift=target,
        temporal_drift=temporal,
        outcome_drift=outcome,
        semantic_drift=semantic,
        confidence=0.8,
        window_size=50,
        baseline_size=100,
        detail="test drift",
    )


def _semantic_drift(per_term=None, overall=0.0):
    """Create a SemanticDriftScore."""
    pt = per_term or {}
    most_drifted = max(pt, key=pt.get) if pt else ""
    return SemanticDriftScore(
        overall=overall,
        per_term=pt,
        most_drifted_term=most_drifted,
        detail="test semantic drift",
    )


class TestInvariantSpec(TestCase):
    def test_creation(self):
        spec = InvariantSpec(
            invariant_id="inv-test001",
            type="ratio",
            description="Write-to-read ratio must stay below 30%",
            metric="write_to_read",
            operator="lt",
            threshold=0.3,
        )
        self.assertEqual(spec.invariant_id, "inv-test001")
        self.assertEqual(spec.type, "ratio")
        self.assertEqual(spec.metric, "write_to_read")
        self.assertEqual(spec.operator, "lt")
        self.assertEqual(spec.threshold, 0.3)
        self.assertIsNone(spec.threshold_upper)
        self.assertIsNone(spec.window)

    def test_to_dict_roundtrip(self):
        spec = InvariantSpec(
            invariant_id="inv-rt",
            type="count",
            description="Max 5 targets",
            metric="distinct_targets",
            operator="lt",
            threshold=5.0,
            window=50,
        )
        d = spec.to_dict()
        restored = InvariantSpec.from_dict(d)
        self.assertEqual(restored.invariant_id, spec.invariant_id)
        self.assertEqual(restored.type, spec.type)
        self.assertEqual(restored.metric, spec.metric)
        self.assertEqual(restored.threshold, spec.threshold)
        self.assertEqual(restored.window, spec.window)

    def test_validate_valid_spec(self):
        spec = InvariantBuilder.ratio("write_to_read", "lt", 0.3)
        errors = spec.validate()
        self.assertEqual(errors, [])

    def test_validate_invalid_type(self):
        spec = InvariantSpec(
            invariant_id="inv-bad",
            type="foobar",
            description="bad",
            metric="x",
            operator="lt",
            threshold=1.0,
        )
        errors = spec.validate()
        self.assertTrue(any("Invalid type" in e for e in errors))

    def test_validate_invalid_operator(self):
        spec = InvariantSpec(
            invariant_id="inv-bad",
            type="ratio",
            description="bad",
            metric="x",
            operator="like",
            threshold=1.0,
        )
        errors = spec.validate()
        self.assertTrue(any("Invalid operator" in e for e in errors))

    def test_validate_between_needs_upper(self):
        spec = InvariantSpec(
            invariant_id="inv-btwn",
            type="ratio",
            description="between test",
            metric="write_to_read",
            operator="between",
            threshold=0.1,
        )
        errors = spec.validate()
        self.assertTrue(any("threshold_upper" in e for e in errors))

    def test_validate_rate_needs_window(self):
        spec = InvariantSpec(
            invariant_id="inv-rate",
            type="rate",
            description="rate without window",
            metric="action_frequency",
            operator="lt",
            threshold=2.0,
        )
        errors = spec.validate()
        self.assertTrue(any("window" in e for e in errors))


class TestInvariantEvaluation(TestCase):
    def test_ratio_pass(self):
        # write=0.2, read=0.7 -> ratio = 0.2/0.7 = 0.286 < 0.3
        spec = InvariantBuilder.ratio("write_to_read", "lt", 0.3)
        compiled = CompiledInvariants.compile([spec])
        fp = _fingerprint()
        results = compiled.evaluate(fingerprint=fp)
        self.assertEqual(len(results), 1)
        self.assertTrue(results[0].satisfied)
        self.assertAlmostEqual(results[0].current_value, 0.2 / 0.7, places=2)

    def test_ratio_fail(self):
        # write=0.4, read=0.3 -> ratio = 0.4/0.3 = 1.33 > 0.3
        spec = InvariantBuilder.ratio("write_to_read", "lt", 0.3)
        compiled = CompiledInvariants.compile([spec])
        fp = _fingerprint(action_dist={"read": 0.3, "write": 0.4, "query": 0.3})
        results = compiled.evaluate(fingerprint=fp)
        self.assertFalse(results[0].satisfied)
        self.assertEqual(results[0].status, "violated")

    def test_ratio_approaching(self):
        # Make ratio close to threshold: e.g. write=0.28, read=1.0 -> 0.28
        # threshold 0.3, margin = (0.3-0.28)/0.3 = 0.067 < 0.20 -> approaching
        spec = InvariantBuilder.ratio("write_to_read", "lt", 0.3)
        compiled = CompiledInvariants.compile([spec])
        fp = _fingerprint(action_dist={"read": 1.0, "write": 0.28})
        results = compiled.evaluate(fingerprint=fp)
        self.assertTrue(results[0].satisfied)
        self.assertEqual(results[0].status, "approaching")

    def test_distribution_max_pass(self):
        spec = InvariantBuilder.distribution("target_max", "lt", 0.6)
        compiled = CompiledInvariants.compile([spec])
        fp = _fingerprint(target_dist={"/a": 0.5, "/b": 0.3, "/c": 0.2})
        results = compiled.evaluate(fingerprint=fp)
        self.assertTrue(results[0].satisfied)

    def test_distribution_max_fail(self):
        spec = InvariantBuilder.distribution("target_max", "lt", 0.6)
        compiled = CompiledInvariants.compile([spec])
        fp = _fingerprint(target_dist={"/a": 0.8, "/b": 0.1, "/c": 0.1})
        results = compiled.evaluate(fingerprint=fp)
        self.assertFalse(results[0].satisfied)
        self.assertEqual(results[0].status, "violated")

    def test_drift_pass(self):
        spec = InvariantBuilder.drift("action", "lt", 0.20)
        compiled = CompiledInvariants.compile([spec])
        drift = _drift_score(action=0.10)
        results = compiled.evaluate(drift_score=drift)
        self.assertTrue(results[0].satisfied)

    def test_drift_fail(self):
        spec = InvariantBuilder.drift("action", "lt", 0.20)
        compiled = CompiledInvariants.compile([spec])
        drift = _drift_score(action=0.30)
        results = compiled.evaluate(drift_score=drift)
        self.assertFalse(results[0].satisfied)
        self.assertEqual(results[0].status, "violated")

    def test_semantic_pass(self):
        # per_term={"research": 0.05}, fidelity = 1.0-0.05 = 0.95 > 0.85
        spec = InvariantBuilder.semantic("research", "gt", 0.85)
        compiled = CompiledInvariants.compile([spec])
        sem = _semantic_drift(per_term={"research": 0.05}, overall=0.05)
        results = compiled.evaluate(semantic_drift=sem)
        self.assertTrue(results[0].satisfied)
        self.assertAlmostEqual(results[0].current_value, 0.95, places=2)

    def test_semantic_fail(self):
        # per_term={"research": 0.30}, fidelity = 0.70 < 0.85
        spec = InvariantBuilder.semantic("research", "gt", 0.85)
        compiled = CompiledInvariants.compile([spec])
        sem = _semantic_drift(per_term={"research": 0.30}, overall=0.30)
        results = compiled.evaluate(semantic_drift=sem)
        self.assertFalse(results[0].satisfied)
        self.assertEqual(results[0].status, "violated")

    def test_count_distinct_targets(self):
        spec = InvariantBuilder.count("distinct_targets", "lt", 5.0, window=100)
        compiled = CompiledInvariants.compile([spec])
        now = time.time()
        actions = [
            Action(agent_id="a", action_type="read", target=f"/t{i}", timestamp=now + i)
            for i in range(3)
        ]
        results = compiled.evaluate(action_window=actions)
        self.assertTrue(results[0].satisfied)
        self.assertEqual(results[0].current_value, 3.0)

    def test_count_distinct_targets_fail(self):
        spec = InvariantBuilder.count("distinct_targets", "lt", 5.0, window=100)
        compiled = CompiledInvariants.compile([spec])
        now = time.time()
        actions = [
            Action(agent_id="a", action_type="read", target=f"/t{i}", timestamp=now + i)
            for i in range(7)
        ]
        results = compiled.evaluate(action_window=actions)
        self.assertFalse(results[0].satisfied)
        self.assertEqual(results[0].status, "violated")

    def test_no_fingerprint_graceful(self):
        spec = InvariantBuilder.ratio("write_to_read", "lt", 0.3)
        compiled = CompiledInvariants.compile([spec])
        results = compiled.evaluate(fingerprint=None)
        # With no fingerprint, value should be 0.0, which is < 0.3 -> satisfied
        self.assertTrue(results[0].satisfied)
        self.assertEqual(results[0].current_value, 0.0)


class TestCompiledInvariants(TestCase):
    def test_compile_valid(self):
        specs = [
            InvariantBuilder.ratio("write_to_read", "lt", 0.3),
            InvariantBuilder.drift("action", "lt", 0.20),
        ]
        compiled = CompiledInvariants.compile(specs)
        self.assertEqual(len(compiled.specs), 2)

    def test_compile_invalid_raises(self):
        bad_spec = InvariantSpec(
            invariant_id="bad",
            type="foobar",
            description="bad",
            metric="x",
            operator="like",
            threshold=1.0,
        )
        with self.assertRaises(ValueError) as ctx:
            CompiledInvariants.compile([bad_spec])
        self.assertIn("validation failed", str(ctx.exception))

    def test_summary_counts(self):
        # 1 satisfied (ratio pass), 1 violated (drift fail), 1 approaching
        specs = [
            InvariantBuilder.ratio("write_to_read", "lt", 0.3),
            InvariantBuilder.drift("action", "lt", 0.20),
            InvariantBuilder.ratio("write_to_read", "lt", 0.31),  # will be approaching
        ]
        compiled = CompiledInvariants.compile(specs)
        fp = _fingerprint()  # write=0.2, read=0.7 -> ratio=0.286
        drift = _drift_score(action=0.30)
        compiled.evaluate(fingerprint=fp, drift_score=drift)
        summary = compiled.summary()
        # ratio 0.286 < 0.3: margin=(0.3-0.286)/0.3=0.047 < 0.20 -> approaching
        # drift 0.30 >= 0.20: violated
        # ratio 0.286 < 0.31: margin=(0.31-0.286)/0.31=0.077 < 0.20 -> approaching
        self.assertEqual(summary["violated"], 1)
        self.assertEqual(summary["approaching"], 2)

    def test_evaluate_multiple_types(self):
        specs = [
            InvariantBuilder.ratio("write_to_read", "lt", 0.5),
            InvariantBuilder.drift("action", "lt", 0.20),
            InvariantBuilder.semantic("research", "gt", 0.85),
        ]
        compiled = CompiledInvariants.compile(specs)
        fp = _fingerprint()
        drift = _drift_score(action=0.10)
        sem = _semantic_drift(per_term={"research": 0.05})
        results = compiled.evaluate(fingerprint=fp, drift_score=drift, semantic_drift=sem)
        self.assertEqual(len(results), 3)
        self.assertTrue(all(r.satisfied for r in results))


class TestInvariantBuilder(TestCase):
    def test_ratio(self):
        spec = InvariantBuilder.ratio("write_to_read", "lt", 0.3)
        self.assertEqual(spec.type, "ratio")
        self.assertEqual(spec.metric, "write_to_read")
        self.assertEqual(spec.operator, "lt")
        self.assertEqual(spec.threshold, 0.3)

    def test_drift(self):
        spec = InvariantBuilder.drift("action", "lt", 0.20)
        self.assertEqual(spec.type, "drift")
        self.assertEqual(spec.metric, "action")

    def test_semantic(self):
        spec = InvariantBuilder.semantic("research", "gt", 0.85)
        self.assertEqual(spec.type, "semantic")
        self.assertEqual(spec.metric, "research")

    def test_rate(self):
        spec = InvariantBuilder.rate("action_frequency", "lt", 2.0, window=100)
        self.assertEqual(spec.type, "rate")
        self.assertEqual(spec.window, 100)

    def test_count(self):
        spec = InvariantBuilder.count("distinct_targets", "lt", 5.0, window=50)
        self.assertEqual(spec.type, "count")
        self.assertEqual(spec.window, 50)

    def test_auto_generated_ids(self):
        s1 = InvariantBuilder.ratio("a", "lt", 1.0)
        s2 = InvariantBuilder.ratio("a", "lt", 1.0)
        self.assertNotEqual(s1.invariant_id, s2.invariant_id)


class TestContractInvariantIntegration(TestCase):
    def test_contract_compile_invariants(self):
        contract = BehavioralContract(
            contract_id="c-1",
            version=1,
            agent_id="agent-1",
            created_at=time.time(),
            invariants=[
                {
                    "type": "ratio",
                    "metric": "write_to_read",
                    "operator": "lt",
                    "threshold": 0.3,
                    "description": "Write-to-read ratio < 30%",
                },
                {
                    "type": "drift",
                    "metric": "action",
                    "operator": "lt",
                    "threshold": 0.20,
                    "description": "Action drift < 20%",
                },
            ],
        )
        compiled = contract.compile_invariants()
        self.assertIsInstance(compiled, CompiledInvariants)
        self.assertEqual(len(compiled.specs), 2)

    def test_contract_compile_empty(self):
        contract = BehavioralContract(
            contract_id="c-2",
            version=1,
            agent_id="agent-2",
            created_at=time.time(),
            invariants=[],
        )
        compiled = contract.compile_invariants()
        self.assertIsInstance(compiled, CompiledInvariants)
        self.assertEqual(len(compiled.specs), 0)


class TestInvariantResult(TestCase):
    def test_to_dict(self):
        result = InvariantResult(
            invariant_id="inv-test",
            satisfied=True,
            current_value=0.25,
            threshold=0.30,
            margin=0.167,
            status="approaching",
            detail="test detail",
        )
        d = result.to_dict()
        self.assertEqual(d["invariant_id"], "inv-test")
        self.assertTrue(d["satisfied"])
        self.assertEqual(d["status"], "approaching")
