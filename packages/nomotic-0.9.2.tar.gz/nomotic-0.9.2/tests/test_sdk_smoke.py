"""End-to-end smoke tests: the SDK works out of the box with no license.

These tests verify the complete public surface of the ``nomotic`` package —
import paths, free-tier governance, license handling, wheel contents, and
internal-module isolation.
"""

from __future__ import annotations

from pathlib import Path

import pytest


# ── Free-tier governance ────────────────────────────────────────────────


def test_free_tier_governance():
    """D1–D14 governance works with zero configuration."""
    from nomotic import (
        Action,
        AgentContext,
        GovernanceRuntime,
        RuntimeConfig,
        TrustProfile,
        Verdict,
    )

    runtime = GovernanceRuntime(RuntimeConfig())

    action = Action(
        agent_id="test-agent",
        action_type="read",
        target="customer_records",
    )
    context = AgentContext(
        agent_id="test-agent",
        trust_profile=TrustProfile(agent_id="test-agent"),
    )

    verdict = runtime.evaluate(action, context)
    assert verdict.verdict in (Verdict.ALLOW, Verdict.DENY, Verdict.ESCALATE)
    assert 0.0 <= verdict.ucs <= 1.0
    assert len(verdict.dimension_scores) >= 6  # at minimum D1–D6


def test_activated_tier_is_open_without_license():
    from nomotic import ActivatedTier, GovernanceRuntime, RuntimeConfig

    runtime = GovernanceRuntime(RuntimeConfig())
    assert runtime.activated_tier == ActivatedTier.OPEN


def test_invalid_license_degrades_gracefully():
    from nomotic import ActivatedTier, GovernanceRuntime, LicenseConfig, RuntimeConfig

    config = RuntimeConfig(license_config=LicenseConfig(key="not-a-valid-jwt"))
    runtime = GovernanceRuntime(config)
    assert runtime.activated_tier == ActivatedTier.OPEN  # not an exception


def test_no_internal_modules_importable():
    """Verify internal modules are not accessible from the installed package."""
    with pytest.raises(ModuleNotFoundError):
        import nomotic.sandbox  # noqa: F401

    with pytest.raises(ModuleNotFoundError):
        import nomotic.scenarios  # noqa: F401


# ── License key smoke test ──────────────────────────────────────────────


def test_pro_tier_activates_with_valid_key(pro_license_key):
    """Pro tier activates when a valid license key is provided."""
    from nomotic import ActivatedTier, GovernanceRuntime, LicenseConfig, RuntimeConfig

    config = RuntimeConfig(license_config=LicenseConfig(key=pro_license_key))
    runtime = GovernanceRuntime(config)
    assert runtime.activated_tier == ActivatedTier.PRO

