"""Tests for the HTTP governance proxy."""

from __future__ import annotations

import json
import os
import signal
import stat
import threading
import time
import urllib.error
import urllib.request
from http.server import HTTPServer
from pathlib import Path
from unittest.mock import MagicMock, patch

from nomotic.certificate import CertStatus
from nomotic.proxy import (
    METHOD_ACTION_MAP,
    GovernanceProxyHandler,
    start_proxy,
    verify_certificate_status,
)
from nomotic.server import _load_or_create_issuer, main


class TestMethodActionMapping:
    def test_get_maps_to_read(self):
        assert METHOD_ACTION_MAP["GET"] == "read"

    def test_post_maps_to_write(self):
        assert METHOD_ACTION_MAP["POST"] == "write"

    def test_put_maps_to_write(self):
        assert METHOD_ACTION_MAP["PUT"] == "write"

    def test_patch_maps_to_write(self):
        assert METHOD_ACTION_MAP["PATCH"] == "write"

    def test_delete_maps_to_delete(self):
        assert METHOD_ACTION_MAP["DELETE"] == "delete"

    def test_head_maps_to_read(self):
        assert METHOD_ACTION_MAP["HEAD"] == "read"

    def test_options_maps_to_read(self):
        assert METHOD_ACTION_MAP["OPTIONS"] == "read"

    def test_all_standard_methods_covered(self):
        expected = {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}
        assert set(METHOD_ACTION_MAP.keys()) == expected


class TestGovernanceProxyHandler:
    def test_handler_class_attributes_exist(self):
        assert hasattr(GovernanceProxyHandler, "executor")
        assert hasattr(GovernanceProxyHandler, "upstream_url")

    def test_handler_has_method_handlers(self):
        assert hasattr(GovernanceProxyHandler, "do_GET")
        assert hasattr(GovernanceProxyHandler, "do_POST")
        assert hasattr(GovernanceProxyHandler, "do_PUT")
        assert hasattr(GovernanceProxyHandler, "do_PATCH")
        assert hasattr(GovernanceProxyHandler, "do_DELETE")


class TestDockerBuild:
    def test_dockerfile_exists(self):
        assert Path("Dockerfile").exists()

    def test_docker_compose_exists(self):
        assert Path("docker-compose.yml").exists()

    def test_deploy_prometheus_config_exists(self):
        assert Path("deploy/prometheus.yml").exists()

    def test_deploy_grafana_datasource_exists(self):
        assert Path("deploy/grafana/grafana-datasource.yml").exists()

    def test_deploy_grafana_dashboard_provider_exists(self):
        assert Path("deploy/grafana/grafana-dashboard-provider.yml").exists()


class TestHelmChart:
    def test_chart_yaml_exists(self):
        assert Path("deploy/helm/Chart.yaml").exists()

    def test_values_yaml_exists(self):
        assert Path("deploy/helm/values.yaml").exists()

    def test_deployment_template_exists(self):
        assert Path("deploy/helm/templates/deployment.yaml").exists()

    def test_service_template_exists(self):
        assert Path("deploy/helm/templates/service.yaml").exists()

    def test_pvc_template_exists(self):
        assert Path("deploy/helm/templates/pvc.yaml").exists()

    def test_ingress_template_exists(self):
        assert Path("deploy/helm/templates/ingress.yaml").exists()

    def test_serviceaccount_template_exists(self):
        assert Path("deploy/helm/templates/serviceaccount.yaml").exists()

    def test_helpers_template_exists(self):
        assert Path("deploy/helm/templates/_helpers.tpl").exists()

    def test_configmap_template_exists(self):
        assert Path("deploy/helm/templates/configmap.yaml").exists()


class TestServerModule:
    def test_server_module_importable(self):
        import nomotic.server  # should not crash
        assert hasattr(nomotic.server, "main")

    def test_server_load_or_create_issuer(self):
        from nomotic.server import _load_or_create_issuer
        assert callable(_load_or_create_issuer)

    def test_proxy_module_importable(self):
        import nomotic.proxy  # should not crash
        assert hasattr(nomotic.proxy, "start_proxy")
        assert hasattr(nomotic.proxy, "GovernanceProxyHandler")
        assert hasattr(nomotic.proxy, "METHOD_ACTION_MAP")


_SERVER_ENV_BASE = {
    "NOMOTIC_PORT": "8420",
    "NOMOTIC_HOST": "127.0.0.1",
    "NOMOTIC_METRICS": "false",
    "NOMOTIC_LOG_LEVEL": "warning",
}


class TestLoadOrCreateIssuer:
    def test_creates_files_on_first_run(self, tmp_path: Path) -> None:
        sk, issuer_id = _load_or_create_issuer(tmp_path)

        issuer_dir = tmp_path / "issuer"
        assert issuer_id.startswith("nomotic-server-")
        assert (issuer_dir / "issuer.key").exists()
        assert (issuer_dir / "issuer.pub").exists()
        meta = json.loads((issuer_dir / "issuer.json").read_text())
        assert meta["issuer_id"] == issuer_id
        assert "fingerprint" in meta

    def test_loads_same_key_and_id_on_second_run(self, tmp_path: Path) -> None:
        sk_first, issuer_id_first = _load_or_create_issuer(tmp_path)
        sk_second, issuer_id_second = _load_or_create_issuer(tmp_path)

        assert issuer_id_first == issuer_id_second
        assert sk_first.to_bytes() == sk_second.to_bytes()

    def test_key_file_has_restricted_permissions(self, tmp_path: Path) -> None:
        _load_or_create_issuer(tmp_path)
        key_path = tmp_path / "issuer" / "issuer.key"
        file_mode = stat.S_IMODE(os.stat(key_path).st_mode)
        import sys
        if sys.platform != "win32":
            assert file_mode == 0o600, (
                f"Key file should have mode 0o600 (got {oct(file_mode)})"
            )

    def test_issuer_id_format(self, tmp_path: Path) -> None:
        # issuer_id is built from vk.fingerprint()[:16].
        # fingerprint() returns "SHA256:<hex>", so the 16-char slice is
        # "SHA256:" + the first 9 hex chars of the digest.
        _, issuer_id = _load_or_create_issuer(tmp_path)
        prefix = "nomotic-server-"
        assert issuer_id.startswith(prefix)
        suffix = issuer_id[len(prefix):]
        assert len(suffix) == 16
        assert suffix.startswith("SHA256:")


class TestServerMain:
    def _run_main(self, tmp_path: Path, extra_env: dict | None = None) -> MagicMock:
        """Run main() with a mocked NomoticAPIServer that stops on serve_forever."""
        env = {**_SERVER_ENV_BASE, "NOMOTIC_DATA_DIR": str(tmp_path), **(extra_env or {})}
        mock_server = MagicMock()
        mock_server.serve_forever.side_effect = KeyboardInterrupt
        with patch.dict(os.environ, env, clear=False), \
             patch("nomotic.server.NomoticAPIServer", return_value=mock_server):
            main()
        return mock_server

    def test_serve_forever_and_shutdown_called(self, tmp_path: Path) -> None:
        mock_server = self._run_main(tmp_path)
        mock_server.serve_forever.assert_called_once()
        mock_server.shutdown.assert_called_once()

    def test_metrics_enabled_instantiates_prometheus(self, tmp_path: Path) -> None:
        env = {**_SERVER_ENV_BASE, "NOMOTIC_DATA_DIR": str(tmp_path), "NOMOTIC_METRICS": "true"}
        mock_server = MagicMock()
        mock_server.serve_forever.side_effect = KeyboardInterrupt
        mock_prometheus_cls = MagicMock()
        mock_prometheus_instance = mock_prometheus_cls.return_value

        with patch.dict(os.environ, env, clear=False), \
             patch("nomotic.server.NomoticAPIServer", return_value=mock_server) as mock_api_cls, \
             patch("nomotic.otel_exporter.PrometheusMetrics", mock_prometheus_cls):
            main()

        mock_prometheus_cls.assert_called_once()
        # Verify the prometheus instance was forwarded to NomoticAPIServer
        _, kwargs = mock_api_cls.call_args
        assert kwargs.get("prometheus") is mock_prometheus_instance

    def test_metrics_disabled_does_not_instantiate_prometheus(self, tmp_path: Path) -> None:
        mock_prometheus_cls = MagicMock()
        with patch("nomotic.otel_exporter.PrometheusMetrics", mock_prometheus_cls):
            self._run_main(tmp_path, extra_env={"NOMOTIC_METRICS": "false"})
        mock_prometheus_cls.assert_not_called()

    def test_creates_required_data_subdirectories(self, tmp_path: Path) -> None:
        self._run_main(tmp_path)
        for subdir in ("certs", "revoked", "audit", "testlog", "agents", "revocations", "issuer", "orgs"):
            assert (tmp_path / subdir).is_dir(), f"Missing subdir: {subdir}"

    def test_metrics_flag_accepts_truthy_values(self, tmp_path: Path) -> None:
        for truthy in ("true", "1", "yes"):
            mock_prometheus_cls = MagicMock()
            env = {
                **_SERVER_ENV_BASE,
                "NOMOTIC_DATA_DIR": str(tmp_path),
                "NOMOTIC_METRICS": truthy,
            }
            mock_server = MagicMock()
            mock_server.serve_forever.side_effect = KeyboardInterrupt
            with patch.dict(os.environ, env, clear=False), \
                 patch("nomotic.server.NomoticAPIServer", return_value=mock_server), \
                 patch("nomotic.otel_exporter.PrometheusMetrics", mock_prometheus_cls):
                main()
            mock_prometheus_cls.assert_called_once(), f"PrometheusMetrics not called for NOMOTIC_METRICS={truthy!r}"


# ── verify_certificate_status ─────────────────────────────────────────────


class TestVerifyCertificateStatus:
    def _cert(self, agent_id: str, status: CertStatus) -> MagicMock:
        c = MagicMock()
        c.agent_id = agent_id
        c.status = status
        return c

    def test_none_store_returns_config_error(self) -> None:
        assert verify_certificate_status(None, "agent-1") == "Certificate store not configured"

    def test_cert_not_found_returns_no_certificate_error(self) -> None:
        store = MagicMock()
        store.get.return_value = None
        store.list.return_value = []
        result = verify_certificate_status(store, "agent-1")
        assert result is not None
        assert "NO_VALID_CERTIFICATE" in result
        assert "agent-1" in result

    def test_active_cert_via_direct_get_returns_none(self) -> None:
        store = MagicMock()
        store.get.return_value = self._cert("agent-1", CertStatus.ACTIVE)
        assert verify_certificate_status(store, "agent-1") is None

    def test_active_cert_found_via_scan_returns_none(self) -> None:
        store = MagicMock()
        store.get.return_value = None
        store.list.return_value = [self._cert("agent-1", CertStatus.ACTIVE)]
        assert verify_certificate_status(store, "agent-1") is None

    def test_scan_skips_certs_for_other_agents(self) -> None:
        store = MagicMock()
        store.get.return_value = None
        store.list.return_value = [
            self._cert("other-agent", CertStatus.ACTIVE),
            self._cert("agent-1", CertStatus.ACTIVE),
        ]
        assert verify_certificate_status(store, "agent-1") is None

    def test_suspended_cert_returns_error(self) -> None:
        store = MagicMock()
        store.get.return_value = self._cert("agent-1", CertStatus.SUSPENDED)
        result = verify_certificate_status(store, "agent-1")
        assert result is not None
        assert "CERTIFICATE_SUSPENDED" in result
        assert "agent-1" in result

    def test_revoked_cert_returns_error(self) -> None:
        store = MagicMock()
        store.get.return_value = self._cert("agent-1", CertStatus.REVOKED)
        result = verify_certificate_status(store, "agent-1")
        assert result is not None
        assert "CERTIFICATE_REVOKED" in result

    def test_expired_cert_returns_error(self) -> None:
        store = MagicMock()
        store.get.return_value = self._cert("agent-1", CertStatus.EXPIRED)
        result = verify_certificate_status(store, "agent-1")
        assert result is not None
        assert "CERTIFICATE_EXPIRED" in result

    def test_unknown_status_returns_invalid_error(self) -> None:
        unknown_status = MagicMock()
        unknown_status.name = "PENDING"
        # Make equality checks against CertStatus values return False
        unknown_status.__eq__ = lambda self, other: False
        store = MagicMock()
        store.get.return_value = self._cert("agent-1", unknown_status)
        result = verify_certificate_status(store, "agent-1")
        assert result is not None
        assert "CERTIFICATE_INVALID" in result


# ── GovernanceProxyHandler integration ───────────────────────────────────


_HANDLER_ATTRS = (
    "executor", "upstream_url", "require_certificate", "cert_store",
    "agent_id_map", "metrics", "start_time", "request_count",
    "denial_count", "agent_id",
)


class TestGovernanceProxyHandlerIntegration:
    def setup_method(self) -> None:
        self._saved = {attr: getattr(GovernanceProxyHandler, attr) for attr in _HANDLER_ATTRS}

        mock_result = MagicMock()
        mock_result.allowed = True
        mock_result.reason = "allowed"
        mock_result.verdict = "ALLOW"
        mock_result.trust_after = 0.9
        mock_result.action_id = "test-token"
        self._mock_result = mock_result

        self._mock_executor = MagicMock()
        self._mock_executor.agent_id = "test-agent"
        self._mock_executor.trust = 1.0
        self._mock_executor.check.return_value = mock_result

        GovernanceProxyHandler.executor = self._mock_executor
        GovernanceProxyHandler.upstream_url = "http://127.0.0.1:19999"
        GovernanceProxyHandler.require_certificate = False
        GovernanceProxyHandler.cert_store = None
        GovernanceProxyHandler.agent_id_map = {}
        GovernanceProxyHandler.metrics = None
        GovernanceProxyHandler.start_time = time.time()
        GovernanceProxyHandler.request_count = 0
        GovernanceProxyHandler.denial_count = 0
        GovernanceProxyHandler.agent_id = "test-agent"

        self._server = HTTPServer(("127.0.0.1", 0), GovernanceProxyHandler)
        self._port = self._server.server_address[1]
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def teardown_method(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        self._thread.join(timeout=5)
        for attr, val in self._saved.items():
            setattr(GovernanceProxyHandler, attr, val)

    def _url(self, path: str = "/") -> str:
        return f"http://127.0.0.1:{self._port}{path}"

    def _get(self, path: str) -> tuple[int, bytes]:
        """Make a GET request to the proxy using http.client (unaffected by urlopen patches)."""
        import http.client
        conn = http.client.HTTPConnection("127.0.0.1", self._port, timeout=5)
        conn.request("GET", path)
        resp = conn.getresponse()
        body = resp.read()
        status = resp.status
        conn.close()
        return status, body

    def test_health_reports_ok_when_upstream_reachable(self) -> None:
        mock_resp = MagicMock()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        with patch("nomotic.proxy.urllib.request.urlopen", return_value=mock_resp):
            status, body_bytes = self._get("/health")
        body = json.loads(body_bytes)
        assert status == 200
        assert body["status"] == "ok"
        assert body["agent_id"] == "test-agent"
        assert body["upstream_url"] == "http://127.0.0.1:19999"

    def test_health_reports_degraded_when_upstream_unreachable(self) -> None:
        # No mock — upstream at port 19999 has no server, so connection fails naturally
        status, body_bytes = self._get("/health")
        body = json.loads(body_bytes)
        assert status == 503
        assert body["status"] == "degraded"
        assert body["upstream_status"] == "unreachable"

    def test_metrics_returns_503_when_not_configured(self) -> None:
        GovernanceProxyHandler.metrics = None
        try:
            urllib.request.urlopen(self._url("/metrics"))
            assert False, "Expected 503"
        except urllib.error.HTTPError as e:
            assert e.code == 503

    def test_metrics_returns_200_with_prometheus_text(self) -> None:
        mock_metrics = MagicMock()
        mock_metrics.format_prometheus.return_value = "# HELP test\ntest 1\n"
        GovernanceProxyHandler.metrics = mock_metrics
        resp = urllib.request.urlopen(self._url("/metrics"))
        assert resp.status == 200
        assert b"test 1" in resp.read()

    def test_governance_denied_returns_403(self) -> None:
        self._mock_result.allowed = False
        self._mock_result.reason = "policy violation"
        self._mock_result.verdict = "DENY"
        try:
            urllib.request.urlopen(self._url("/data/items"))
            assert False, "Expected 403"
        except urllib.error.HTTPError as e:
            assert e.code == 403
            body = json.loads(e.read())
            assert body["error"] == "governance_denied"
            assert body["reason"] == "policy violation"

    def test_governance_denied_response_includes_verdict_header(self) -> None:
        self._mock_result.allowed = False
        self._mock_result.reason = "denied"
        self._mock_result.verdict = "DENY"
        try:
            urllib.request.urlopen(self._url("/data"))
        except urllib.error.HTTPError as e:
            assert e.headers.get("X-Nomotic-Verdict") == "DENY"

    def test_get_request_sends_read_action_to_governance(self) -> None:
        self._mock_result.allowed = False
        self._mock_result.reason = "denied"
        try:
            urllib.request.urlopen(self._url("/items"))
        except urllib.error.HTTPError:
            pass
        call = self._mock_executor.check.call_args
        assert call is not None
        assert call.kwargs["action"] == "read"
        assert call.kwargs["target"] == "items"

    def test_post_request_sends_write_action_to_governance(self) -> None:
        self._mock_result.allowed = False
        self._mock_result.reason = "denied"
        req = urllib.request.Request(self._url("/records"), data=b"{}", method="POST")
        try:
            urllib.request.urlopen(req)
        except urllib.error.HTTPError:
            pass
        call = self._mock_executor.check.call_args
        assert call is not None
        assert call.kwargs["action"] == "write"
        assert call.kwargs["target"] == "records"

    def test_certificate_required_no_identity_returns_403(self) -> None:
        GovernanceProxyHandler.require_certificate = True
        GovernanceProxyHandler.agent_id_map = {}
        GovernanceProxyHandler.cert_store = MagicMock()
        try:
            urllib.request.urlopen(self._url("/data"))
        except urllib.error.HTTPError as e:
            assert e.code == 403
            body = json.loads(e.read())
            assert body["error"] == "certificate_required"

    def test_certificate_required_with_agent_header_passes_to_governance(self) -> None:
        GovernanceProxyHandler.require_certificate = True
        mock_cert = MagicMock()
        mock_cert.status = CertStatus.ACTIVE
        mock_store = MagicMock()
        mock_store.get.return_value = mock_cert
        GovernanceProxyHandler.cert_store = mock_store
        self._mock_result.allowed = False
        self._mock_result.reason = "governance denied"
        req = urllib.request.Request(self._url("/data"))
        req.add_header("X-Nomotic-Agent-Id", "verified-agent")
        try:
            urllib.request.urlopen(req)
        except urllib.error.HTTPError as e:
            body = json.loads(e.read())
            # Reached governance (not certificate error)
            assert body["error"] == "governance_denied"

    def test_ip_map_resolves_agent_identity(self) -> None:
        GovernanceProxyHandler.require_certificate = True
        GovernanceProxyHandler.agent_id_map = {"127.0.0.1": "ip-mapped-agent"}
        # Cert store: ip-mapped-agent has active cert
        mock_cert = MagicMock()
        mock_cert.agent_id = "ip-mapped-agent"
        mock_cert.status = CertStatus.ACTIVE
        mock_store = MagicMock()
        mock_store.get.return_value = None
        mock_store.list.return_value = [mock_cert]
        GovernanceProxyHandler.cert_store = mock_store
        self._mock_result.allowed = False
        self._mock_result.reason = "governance denied"
        # Use http.client to avoid any header side-effects from urllib
        status, body_bytes = self._get("/data")
        body = json.loads(body_bytes)
        assert body["error"] == "governance_denied"

    def test_put_request_passes_through_governance(self) -> None:
        import http.client
        self._mock_result.allowed = False
        self._mock_result.reason = "denied"
        conn = http.client.HTTPConnection("127.0.0.1", self._port, timeout=5)
        conn.request("PUT", "/resource/1", body=b"{}", headers={"Content-Length": "2"})
        resp = conn.getresponse()
        body = json.loads(resp.read())
        conn.close()
        assert resp.status == 403
        assert body["error"] == "governance_denied"
        assert self._mock_executor.check.call_args.kwargs["action"] == "write"

    def test_patch_request_passes_through_governance(self) -> None:
        import http.client
        self._mock_result.allowed = False
        self._mock_result.reason = "denied"
        conn = http.client.HTTPConnection("127.0.0.1", self._port, timeout=5)
        conn.request("PATCH", "/resource/1", body=b"{}", headers={"Content-Length": "2"})
        resp = conn.getresponse()
        resp.read()
        conn.close()
        assert resp.status == 403
        assert self._mock_executor.check.call_args.kwargs["action"] == "write"

    def test_delete_request_passes_through_governance(self) -> None:
        import http.client
        self._mock_result.allowed = False
        self._mock_result.reason = "denied"
        conn = http.client.HTTPConnection("127.0.0.1", self._port, timeout=5)
        conn.request("DELETE", "/resource/1")
        resp = conn.getresponse()
        resp.read()
        conn.close()
        assert resp.status == 403
        assert self._mock_executor.check.call_args.kwargs["action"] == "delete"

    def test_governance_allowed_forwards_to_upstream(self) -> None:
        # result.allowed = True (default) — proxy should forward to upstream
        upstream_resp = MagicMock()
        upstream_resp.__enter__ = MagicMock(return_value=upstream_resp)
        upstream_resp.__exit__ = MagicMock(return_value=False)
        upstream_resp.status = 200
        upstream_resp.read.return_value = b'{"upstream": "ok"}'
        upstream_resp.headers.items.return_value = [("Content-Type", "application/json")]
        with patch("nomotic.proxy.urllib.request.urlopen", return_value=upstream_resp):
            status, body_bytes = self._get("/items")
        assert status == 200
        assert json.loads(body_bytes) == {"upstream": "ok"}

    def test_invalid_cert_denies_with_certificate_error(self) -> None:
        GovernanceProxyHandler.require_certificate = True
        revoked_cert = MagicMock()
        revoked_cert.status = CertStatus.REVOKED
        mock_store = MagicMock()
        mock_store.get.return_value = revoked_cert
        GovernanceProxyHandler.cert_store = mock_store
        req = urllib.request.Request(self._url("/data"))
        req.add_header("X-Nomotic-Agent-Id", "revoked-agent")
        try:
            urllib.request.urlopen(req)
        except urllib.error.HTTPError as e:
            body = json.loads(e.read())
            assert body["error"] == "certificate_required"
            assert "CERTIFICATE_REVOKED" in body["reason"]

    def test_upstream_http_error_forwarded_to_client(self) -> None:
        import urllib.error
        http_err = urllib.error.HTTPError(
            url="http://127.0.0.1:19999/items",
            code=404,
            msg="Not Found",
            hdrs=MagicMock(items=lambda: [("Content-Type", "application/json")]),
            fp=None,
        )
        http_err.read = lambda: b'{"error": "not found"}'
        with patch("nomotic.proxy.urllib.request.urlopen", side_effect=http_err):
            status, body_bytes = self._get("/items")
        assert status == 404


# ── _resolve_agent_identity direct unit tests ─────────────────────────────


class TestResolveAgentIdentity:
    """Direct unit tests for GovernanceProxyHandler._resolve_agent_identity."""

    def _make_handler(self, headers: dict, client_ip: str = "127.0.0.1") -> GovernanceProxyHandler:
        handler = GovernanceProxyHandler.__new__(GovernanceProxyHandler)
        handler.headers = headers
        handler.client_address = (client_ip, 12345)
        return handler

    def test_agent_id_header_returned(self) -> None:
        GovernanceProxyHandler.agent_id_map = {}
        handler = self._make_handler({"X-Nomotic-Agent-Id": "my-agent"})
        assert handler._resolve_agent_identity() == "my-agent"

    def test_certificate_id_header_returned_when_no_agent_id(self) -> None:
        GovernanceProxyHandler.agent_id_map = {}
        handler = self._make_handler({"X-Nomotic-Certificate-Id": "cert-abc"})
        assert handler._resolve_agent_identity() == "cert-abc"

    def test_agent_id_header_takes_priority_over_cert_id(self) -> None:
        GovernanceProxyHandler.agent_id_map = {}
        handler = self._make_handler({
            "X-Nomotic-Agent-Id": "agent-id",
            "X-Nomotic-Certificate-Id": "cert-id",
        })
        assert handler._resolve_agent_identity() == "agent-id"

    def test_ip_map_used_when_no_headers(self) -> None:
        GovernanceProxyHandler.agent_id_map = {"10.0.0.5": "mapped-agent"}
        handler = self._make_handler({}, client_ip="10.0.0.5")
        assert handler._resolve_agent_identity() == "mapped-agent"

    def test_returns_none_when_no_headers_and_no_ip_match(self) -> None:
        GovernanceProxyHandler.agent_id_map = {"10.0.0.5": "other-agent"}
        handler = self._make_handler({}, client_ip="192.168.1.1")
        assert handler._resolve_agent_identity() is None


# ── start_proxy ───────────────────────────────────────────────────────────


class TestStartProxy:
    def test_configures_handler_class_vars_and_calls_serve_forever(self) -> None:
        mock_executor = MagicMock()
        mock_executor.agent_id = "proxy-agent"
        mock_executor.trust = 1.0
        mock_server_inst = MagicMock()
        mock_server_inst.serve_forever.side_effect = KeyboardInterrupt

        with patch("nomotic.proxy.GovernedToolExecutor.connect", return_value=mock_executor), \
             patch("nomotic.proxy.HTTPServer", return_value=mock_server_inst), \
             patch("nomotic.proxy.signal.signal"):
            try:
                start_proxy(
                    agent_id="proxy-agent",
                    listen="127.0.0.1:9999",
                    upstream="http://api.example.com",
                    test_mode=True,
                )
            except KeyboardInterrupt:
                pass

        mock_server_inst.serve_forever.assert_called_once()
        assert GovernanceProxyHandler.upstream_url == "http://api.example.com"
        assert GovernanceProxyHandler.agent_id == "proxy-agent"
        assert GovernanceProxyHandler.executor is mock_executor

    def test_cert_store_set_when_require_certificate_true(self, tmp_path: Path) -> None:
        mock_executor = MagicMock()
        mock_executor.agent_id = "proxy-agent"
        mock_executor.trust = 1.0
        mock_server_inst = MagicMock()
        mock_server_inst.serve_forever.side_effect = KeyboardInterrupt
        mock_cert_store = MagicMock()

        with patch("nomotic.proxy.GovernedToolExecutor.connect", return_value=mock_executor), \
             patch("nomotic.proxy.HTTPServer", return_value=mock_server_inst), \
             patch("nomotic.proxy.signal.signal"), \
             patch("nomotic.store.FileCertificateStore", return_value=mock_cert_store):
            try:
                start_proxy(
                    agent_id="proxy-agent",
                    listen="127.0.0.1:9999",
                    upstream="http://api.example.com",
                    require_certificate=True,
                    base_dir=str(tmp_path),
                    test_mode=True,
                )
            except KeyboardInterrupt:
                pass

        assert GovernanceProxyHandler.cert_store is mock_cert_store
        assert GovernanceProxyHandler.require_certificate is True

    def test_cert_store_none_when_require_certificate_false(self) -> None:
        mock_executor = MagicMock()
        mock_executor.agent_id = "proxy-agent"
        mock_executor.trust = 1.0
        mock_server_inst = MagicMock()
        mock_server_inst.serve_forever.side_effect = KeyboardInterrupt

        with patch("nomotic.proxy.GovernedToolExecutor.connect", return_value=mock_executor), \
             patch("nomotic.proxy.HTTPServer", return_value=mock_server_inst), \
             patch("nomotic.proxy.signal.signal"):
            try:
                start_proxy(
                    agent_id="proxy-agent",
                    listen="127.0.0.1:9999",
                    upstream="http://api.example.com",
                    require_certificate=False,
                    test_mode=True,
                )
            except KeyboardInterrupt:
                pass

        assert GovernanceProxyHandler.cert_store is None
        assert GovernanceProxyHandler.require_certificate is False

    def test_shutdown_signal_handler_logs_and_starts_timer(self, capsys) -> None:
        mock_executor = MagicMock()
        mock_executor.agent_id = "proxy-agent"
        mock_executor.trust = 1.0
        mock_server_inst = MagicMock()
        mock_server_inst.serve_forever.side_effect = KeyboardInterrupt
        registered_handlers: dict[int, object] = {}
        mock_timer = MagicMock()

        def _capture_handler(sig, handler):
            registered_handlers[sig] = handler

        with patch("nomotic.proxy.GovernedToolExecutor.connect", return_value=mock_executor), \
             patch("nomotic.proxy.HTTPServer", return_value=mock_server_inst), \
             patch("nomotic.proxy.signal.signal", side_effect=_capture_handler), \
             patch("nomotic.proxy.threading.Timer", return_value=mock_timer) as mock_timer_cls:
            try:
                start_proxy(
                    agent_id="proxy-agent",
                    listen="127.0.0.1:9999",
                    upstream="http://api.example.com",
                    require_certificate=False,
                    test_mode=True,
                )
            except KeyboardInterrupt:
                pass

            # Exercise the nested shutdown handler to cover signal path.
            assert signal.SIGTERM in registered_handlers
            registered_handlers[signal.SIGTERM](signal.SIGTERM, None)

        stderr = capsys.readouterr().err
        assert "Shutdown initiated" in stderr
        mock_timer_cls.assert_called_once_with(5.0, mock_server_inst.shutdown)
        mock_timer.start.assert_called_once()
