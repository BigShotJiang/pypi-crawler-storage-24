"""Tests for the drift dynamics model."""

from __future__ import annotations

import random

import pytest

from nomotic.drift_dynamics import (
    ArchetypeDynamics,
    DriftDynamicsModel,
    DriftTransitionParams,
    InterventionEffect,
)

# ── Built-in archetypes ──────────────────────────────────────────────────

_TEN_ARCHETYPES = [
    "customer-experience",
    "operations-coordinator",
    "financial-analyst",
    "data-processor",
    "content-creator",
    "security-monitor",
    "research-analyst",
    "sales-agent",
    "executive-assistant",
    "healthcare-agent",
]


class TestDefaultModels:
    """All 10 archetypes should have pre-seeded dynamics."""

    def test_default_models_exist(self) -> None:
        model = DriftDynamicsModel()
        for name in _TEN_ARCHETYPES:
            dyn = model.get_dynamics(name)
            assert dyn.archetype_name == name
            assert isinstance(dyn.natural_transition, DriftTransitionParams)
            assert len(dyn.intervention_effects) == 4
            assert "advisory" in dyn.intervention_effects
            assert "throttle" in dyn.intervention_effects
            assert "escalate" in dyn.intervention_effects
            assert "tighten" in dyn.intervention_effects
            assert len(dyn.causal_modifiers) >= 4

    def test_unknown_archetype_returns_default(self) -> None:
        model = DriftDynamicsModel()
        dyn = model.get_dynamics("unknown-archetype")
        assert dyn.archetype_name == "unknown-archetype"
        assert dyn.natural_transition.continuation_rate == 1.0


class TestProjectNoIntervention:
    """Linear drift with continuation_rate=1.0 should increase linearly."""

    def test_linear_drift(self) -> None:
        model = DriftDynamicsModel()
        # Use a deterministic RNG with high seed to avoid self-correction
        rng = random.Random(42)

        # Use an archetype with 0 self-correction for deterministic test
        dyn = model.get_dynamics("test-linear")
        dyn.natural_transition = DriftTransitionParams(
            continuation_rate=1.0,
            acceleration_factor=0.0,
            self_correction_probability=0.0,
            self_correction_magnitude=0.0,
        )
        dyn.causal_modifiers.clear()

        projected = model.project_drift(
            current_drift=0.1,
            velocity=0.02,
            horizon=5,
            archetype="test-linear",
            _rng=rng,
        )

        assert len(projected) == 5
        # Each step: drift += 0.02 * 1.0 + 0.0 * step
        expected = [0.12, 0.14, 0.16, 0.18, 0.20]
        for got, exp in zip(projected, expected):
            assert abs(got - exp) < 1e-9, f"got {got}, expected {exp}"

    def test_acceleration(self) -> None:
        model = DriftDynamicsModel()
        rng = random.Random(99)

        dyn = model.get_dynamics("test-accel")
        dyn.natural_transition = DriftTransitionParams(
            continuation_rate=1.0,
            acceleration_factor=0.01,
            self_correction_probability=0.0,
        )
        dyn.causal_modifiers.clear()

        projected = model.project_drift(
            current_drift=0.1,
            velocity=0.02,
            horizon=3,
            archetype="test-accel",
            _rng=rng,
        )

        # step 1: 0.1 + 0.02*1.0 + 0.01*1 = 0.13
        # step 2: 0.13 + 0.02*1.0 + 0.01*2 = 0.17
        # step 3: 0.17 + 0.02*1.0 + 0.01*3 = 0.22
        expected = [0.13, 0.17, 0.22]
        for got, exp in zip(projected, expected):
            assert abs(got - exp) < 1e-9, f"got {got}, expected {exp}"


class TestProjectWithIntervention:
    """Interventions should cause exponential decay."""

    def test_project_with_advisory(self) -> None:
        model = DriftDynamicsModel()
        # Force intervention to be effective
        rng = random.Random(0)

        dyn = model.get_dynamics("test-advisory")
        dyn.intervention_effects["advisory"] = InterventionEffect(
            intervention_type="advisory",
            decay_half_life=5.0,
            effectiveness=1.0,  # Always effective for this test
            rebound_rate=0.0,
        )

        projected = model.project_drift(
            current_drift=0.8,
            velocity=0.02,
            horizon=10,
            archetype="test-advisory",
            intervention="advisory",
            _rng=rng,
        )

        assert len(projected) == 10
        # Drift should decrease (exponential decay)
        assert projected[0] < 0.8
        assert projected[4] < projected[0]
        # At step 5 (= half_life), drift should be ~half of initial
        assert abs(projected[4] - 0.4) < 0.05

    def test_project_with_tighten_faster_than_advisory(self) -> None:
        """For financial-analyst, tighten should decay faster than advisory."""
        model = DriftDynamicsModel()

        # Both interventions always effective
        rng_adv = random.Random(0)
        rng_tgt = random.Random(0)

        dyn = model.get_dynamics("financial-analyst")
        # Override effectiveness to 1.0 for deterministic comparison
        dyn.intervention_effects["advisory"].effectiveness = 1.0
        dyn.intervention_effects["tighten"].effectiveness = 1.0

        proj_advisory = model.project_drift(
            current_drift=0.6, velocity=0.02, horizon=10,
            archetype="financial-analyst", intervention="advisory",
            _rng=rng_adv,
        )
        proj_tighten = model.project_drift(
            current_drift=0.6, velocity=0.02, horizon=10,
            archetype="financial-analyst", intervention="tighten",
            _rng=rng_tgt,
        )

        # Tighten has a shorter half-life, so drift should be lower at each step
        for step in range(5):
            assert proj_tighten[step] <= proj_advisory[step], (
                f"step {step}: tighten {proj_tighten[step]} > advisory {proj_advisory[step]}"
            )


class TestSelfCorrection:
    """Archetypes with self-correction probability should sometimes self-correct."""

    def test_self_correction_occurs(self) -> None:
        model = DriftDynamicsModel()

        dyn = model.get_dynamics("test-sc")
        dyn.natural_transition = DriftTransitionParams(
            continuation_rate=1.0,
            acceleration_factor=0.0,
            self_correction_probability=0.3,
            self_correction_magnitude=0.5,
        )

        # Run many projections and check that some show self-correction
        corrections_seen = 0
        trials = 200
        for seed in range(trials):
            rng = random.Random(seed)
            projected = model.project_drift(
                current_drift=0.5,
                velocity=0.02,
                horizon=20,
                archetype="test-sc",
                _rng=rng,
            )
            # If any step shows a decrease, self-correction occurred
            for i in range(1, len(projected)):
                if projected[i] < projected[i - 1]:
                    corrections_seen += 1
                    break

        # With p=0.3 per step over 20 steps, nearly all trajectories
        # should see at least one correction
        assert corrections_seen > trials * 0.5


class TestCausalModifier:
    """model_update cause should use different params than organic."""

    def test_causal_modifier_differs(self) -> None:
        model = DriftDynamicsModel()

        dyn = model.get_dynamics("financial-analyst")

        # Organic and model_update should have different continuation rates
        organic = dyn.causal_modifiers.get("organic")
        model_update = dyn.causal_modifiers.get("model_update")
        assert organic is not None
        assert model_update is not None
        assert organic.continuation_rate != model_update.continuation_rate

    def test_causal_modifier_affects_projection(self) -> None:
        model = DriftDynamicsModel()

        dyn = model.get_dynamics("test-causal")
        dyn.natural_transition = DriftTransitionParams(
            continuation_rate=1.0, self_correction_probability=0.0,
        )
        dyn.causal_modifiers["model_update"] = DriftTransitionParams(
            continuation_rate=2.0, self_correction_probability=0.0,
        )

        rng1 = random.Random(42)
        rng2 = random.Random(42)

        proj_organic = model.project_drift(
            current_drift=0.2, velocity=0.01, horizon=5,
            archetype="test-causal", cause_type="organic", _rng=rng1,
        )
        proj_update = model.project_drift(
            current_drift=0.2, velocity=0.01, horizon=5,
            archetype="test-causal", cause_type="model_update", _rng=rng2,
        )

        # model_update has 2x continuation rate, so drift grows faster
        for i in range(len(proj_organic)):
            assert proj_update[i] >= proj_organic[i]


class TestInterventionEffectiveness:
    """With effectiveness=0.5, roughly half of projections should show decay."""

    def test_half_effective(self) -> None:
        model = DriftDynamicsModel()

        dyn = model.get_dynamics("test-eff")
        dyn.natural_transition = DriftTransitionParams(
            continuation_rate=1.0, self_correction_probability=0.0,
        )
        dyn.causal_modifiers.clear()
        dyn.intervention_effects["advisory"] = InterventionEffect(
            intervention_type="advisory",
            decay_half_life=5.0,
            effectiveness=0.5,
            rebound_rate=0.0,
        )

        decay_count = 0
        trials = 500
        for seed in range(trials):
            rng = random.Random(seed)
            projected = model.project_drift(
                current_drift=0.5,
                velocity=0.02,
                horizon=5,
                archetype="test-eff",
                intervention="advisory",
                _rng=rng,
            )
            # If drift at step 3 is lower than initial, intervention worked
            if projected[2] < 0.5:
                decay_count += 1

        ratio = decay_count / trials
        # Should be roughly 0.5 ± tolerance
        assert 0.35 < ratio < 0.65, f"decay ratio {ratio} not near 0.5"


class TestReboundAfterIntervention:
    """After decay_half_life * 3 steps, drift should rebound."""

    def test_rebound(self) -> None:
        model = DriftDynamicsModel()

        dyn = model.get_dynamics("test-rebound")
        dyn.intervention_effects["throttle"] = InterventionEffect(
            intervention_type="throttle",
            decay_half_life=5.0,
            effectiveness=1.0,
            rebound_rate=0.5,
        )

        rng = random.Random(42)
        projected = model.project_drift(
            current_drift=0.8,
            velocity=0.02,
            horizon=25,
            archetype="test-rebound",
            intervention="throttle",
            _rng=rng,
        )

        # Rebound starts at step 15 (= 5 * 3)
        # After rebound, drift should increase
        min_before_rebound = min(projected[:15])
        max_after_rebound = max(projected[15:])
        assert max_after_rebound > min_before_rebound, (
            f"no rebound: min_before={min_before_rebound}, max_after={max_after_rebound}"
        )


class TestMaturityLevels:
    """Maturity should progress through default → blended → observed."""

    def test_maturity_progression(self) -> None:
        model = DriftDynamicsModel()
        archetype = "financial-analyst"

        assert model.maturity(archetype) == "default"

        # Record 50 episodes
        for _ in range(50):
            model.record_episode(
                archetype,
                drift_trajectory=[0.1, 0.15, 0.2, 0.25, 0.3],
            )
        assert model.maturity(archetype) == "blended"

        # Record up to 200
        for _ in range(150):
            model.record_episode(
                archetype,
                drift_trajectory=[0.1, 0.15, 0.2, 0.25, 0.3],
            )
        assert model.maturity(archetype) == "observed"

    def test_unknown_archetype_is_default(self) -> None:
        model = DriftDynamicsModel()
        assert model.maturity("never-seen") == "default"


class TestProjectClamping:
    """Extreme drift velocity should not exceed [0.0, 1.0]."""

    def test_clamp_upper(self) -> None:
        model = DriftDynamicsModel()

        dyn = model.get_dynamics("test-clamp")
        dyn.natural_transition = DriftTransitionParams(
            continuation_rate=1.0, self_correction_probability=0.0,
        )

        rng = random.Random(0)
        projected = model.project_drift(
            current_drift=0.9,
            velocity=0.5,
            horizon=10,
            archetype="test-clamp",
            _rng=rng,
        )

        for val in projected:
            assert 0.0 <= val <= 1.0, f"drift {val} out of bounds"

    def test_clamp_lower(self) -> None:
        model = DriftDynamicsModel()

        dyn = model.get_dynamics("test-clamp-low")
        dyn.natural_transition = DriftTransitionParams(
            continuation_rate=1.0, self_correction_probability=0.0,
        )

        rng = random.Random(0)
        projected = model.project_drift(
            current_drift=0.1,
            velocity=-0.5,
            horizon=10,
            archetype="test-clamp-low",
            _rng=rng,
        )

        for val in projected:
            assert 0.0 <= val <= 1.0, f"drift {val} out of bounds"


class TestSerialization:
    """ArchetypeDynamics round-trips through to_dict / from_dict."""

    def test_round_trip(self) -> None:
        model = DriftDynamicsModel()
        dyn = model.get_dynamics("financial-analyst")

        data = dyn.to_dict()
        restored = ArchetypeDynamics.from_dict(data)

        assert restored.archetype_name == dyn.archetype_name
        assert (
            restored.natural_transition.continuation_rate
            == dyn.natural_transition.continuation_rate
        )
        assert set(restored.intervention_effects) == set(dyn.intervention_effects)
        assert set(restored.causal_modifiers) == set(dyn.causal_modifiers)


class TestRecordEpisodeRefinement:
    """After enough episodes, model parameters should be refined."""

    def test_refinement_changes_params(self) -> None:
        model = DriftDynamicsModel()
        archetype = "financial-analyst"

        original_cr = model.get_dynamics(archetype).natural_transition.continuation_rate

        # Record 60 episodes with a specific trajectory pattern
        for _ in range(60):
            model.record_episode(
                archetype,
                drift_trajectory=[0.1, 0.12, 0.14, 0.16, 0.18, 0.20],
                cause_type="organic",
            )

        # With blended mode, parameters may have shifted
        new_cr = model.get_dynamics(archetype).causal_modifiers["organic"].continuation_rate
        # The organic modifier should have been updated since we have 60 episodes
        # We just verify the recording didn't crash and maturity changed
        assert model.maturity(archetype) == "blended"
