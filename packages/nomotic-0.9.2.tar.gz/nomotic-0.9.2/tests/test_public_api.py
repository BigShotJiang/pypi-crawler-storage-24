"""Tests for the curated public API surface of nomotic."""

from __future__ import annotations

import importlib

import pytest

import nomotic


class TestAllSymbolsAccessible:
    """Every symbol in __all__ must be importable from the top-level package."""

    @pytest.mark.parametrize("symbol", nomotic.__all__)
    def test_symbol_in_all_is_accessible(self, symbol: str):
        value = getattr(nomotic, symbol)
        assert value is not None or symbol == "__version__"


class TestNomoticAlias:
    """The Nomotic alias must resolve to GovernanceRuntime."""

    def test_nomotic_is_governance_runtime(self):
        from nomotic.runtime import GovernanceRuntime

        assert nomotic.Nomotic is GovernanceRuntime

    def test_import_nomotic_alias(self):
        from nomotic import Nomotic
        from nomotic.runtime import GovernanceRuntime

        assert Nomotic is GovernanceRuntime


class TestCoreExports:
    """Spot-check that key public symbols resolve to the correct classes."""

    def test_action(self):
        from nomotic import Action
        from nomotic.types import Action as DirectAction

        assert Action is DirectAction

    def test_governance_runtime(self):
        from nomotic import GovernanceRuntime
        from nomotic.runtime import GovernanceRuntime as DirectRuntime

        assert GovernanceRuntime is DirectRuntime

    def test_governed_agent(self):
        from nomotic import GovernedAgent
        from nomotic.sdk import GovernedAgent as DirectAgent

        assert GovernedAgent is DirectAgent

    def test_governed_tool_executor(self):
        from nomotic import GovernedToolExecutor
        from nomotic.executor import GovernedToolExecutor as DirectExecutor

        assert GovernedToolExecutor is DirectExecutor

    def test_async_executor(self):
        from nomotic import AsyncGovernedToolExecutor
        from nomotic.async_executor import (
            AsyncGovernedToolExecutor as DirectAsync,
        )

        assert AsyncGovernedToolExecutor is DirectAsync

    def test_audit_trail(self):
        from nomotic import AuditTrail
        from nomotic.audit import AuditTrail as DirectTrail

        assert AuditTrail is DirectTrail


class TestInternalModulesNotExported:
    """Modules moved to internal/ must not be importable as nomotic.<name>."""

    def test_adversarial_not_importable_from_top_level(self):
        with pytest.raises(ImportError):
            importlib.import_module("nomotic.adversarial")

    def test_sandbox_not_importable_from_top_level(self):
        with pytest.raises(ImportError):
            importlib.import_module("nomotic.sandbox")

    def test_scenarios_not_importable_from_top_level(self):
        with pytest.raises(ImportError):
            importlib.import_module("nomotic.scenarios")

    def test_adversarial_importable_from_internal(self):
        mod = importlib.import_module("nomotic.internal.adversarial")
        assert hasattr(mod, "RuntimeAdversarialEvaluators")

    def test_sandbox_importable_from_internal(self):
        mod = importlib.import_module("nomotic.internal.sandbox")
        assert hasattr(mod, "AgentConfig")

    def test_scenarios_importable_from_internal(self):
        mod = importlib.import_module("nomotic.internal.scenarios")
        assert hasattr(mod, "BUILTIN_SCENARIOS")


class TestRemovedTopLevelExports:
    """Symbols that were previously exported but are now import-by-path only."""

    @pytest.mark.parametrize(
        "attr",
        [
            "EquityAnalyzer",
            "BiasDetector",
            "CrossDimensionalDetector",
            "ContextualModifier",
            "WorkflowGovernor",
            "HumanDriftMonitor",
            "ContextProfile",
            "GovernanceToken",
            "ProvenanceRecord",
        ],
    )
    def test_removed_from_top_level(self, attr: str):
        with pytest.raises(AttributeError):
            getattr(nomotic, attr)

    def test_equity_still_importable_by_path(self):
        from nomotic.equity import EquityAnalyzer

        assert EquityAnalyzer is not None

    def test_bias_still_importable_by_path(self):
        from nomotic.bias import BiasDetector

        assert BiasDetector is not None

    def test_protocol_still_importable_by_path(self):
        from nomotic.protocol import GovernanceResponseData

        assert GovernanceResponseData is not None


class TestAllIsComplete:
    """__all__ should exactly match the lazy-loadable public symbols."""

    def test_all_matches_lazy_registry(self):
        lazy_attrs = set()
        for attrs in nomotic._LAZY_MODULE_ATTRS.values():
            lazy_attrs.update(attrs)
        # Add special attrs and Nomotic alias
        lazy_attrs.update(nomotic._SPECIAL_ATTRS.keys())
        lazy_attrs.add("Nomotic")
        lazy_attrs.add("__version__")

        all_set = set(nomotic.__all__)
        assert all_set == lazy_attrs, (
            f"Mismatch — in __all__ but not lazy: {all_set - lazy_attrs}, "
            f"in lazy but not __all__: {lazy_attrs - all_set}"
        )
