"""Tests for Escalation Analytics API endpoints."""

from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request
from typing import Any

import pytest

from nomotic.api import NomoticAPIServer
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.store import MemoryCertificateStore


# ── Test fixtures ───────────────────────────────────────────────────────


def _find_free_port() -> int:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class APITestClient:
    """Minimal HTTP client for testing the API."""

    def __init__(self, base_url: str) -> None:
        self.base_url = base_url

    def get(self, path: str) -> tuple[int, dict[str, Any]]:
        url = f"{self.base_url}{path}"
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req) as resp:
                body = json.loads(resp.read())
                return resp.status, body
        except urllib.error.HTTPError as e:
            body = json.loads(e.read())
            return e.code, body

    def post(self, path: str, data: dict[str, Any] | None = None) -> tuple[int, dict[str, Any]]:
        url = f"{self.base_url}{path}"
        payload = json.dumps(data or {}).encode("utf-8")
        try:
            req = urllib.request.Request(
                url, data=payload, method="POST",
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req) as resp:
                body = json.loads(resp.read())
                return resp.status, body
        except urllib.error.HTTPError as e:
            body = json.loads(e.read())
            return e.code, body


@pytest.fixture(scope="module")
def api_server() -> tuple[APITestClient, CertificateAuthority]:
    """Start a test API server and return a client + the CA."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)
    arch_reg = ArchetypeRegistry.with_defaults()
    zone_val = ZoneValidator()
    org_reg = OrganizationRegistry()

    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        archetype_registry=arch_reg,
        zone_validator=zone_val,
        org_registry=org_reg,
        host="127.0.0.1",
        port=port,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.3)

    client = APITestClient(f"http://127.0.0.1:{port}")
    yield client, ca
    server.shutdown()


# ═══════════════════════════════════════════════════════════════════════
# GET /v1/escalation/analytics
# ═══════════════════════════════════════════════════════════════════════


class TestEscalationAnalytics:
    def test_analytics_returns_correct_structure(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.get("/v1/escalation/analytics")
        assert status == 200
        assert "escalation_volume" in body
        assert "voi_distribution" in body
        assert "escalation_roi" in body
        assert "reviewer_utilization" in body
        assert "timestamp" in body

    def test_analytics_roi_structure(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.get("/v1/escalation/analytics")
        assert status == 200
        roi = body["escalation_roi"]
        assert "total_escalations" in roi
        assert "verdict_changed" in roi
        assert "verdict_unchanged" in roi
        assert "change_rate" in roi

    def test_analytics_empty_data(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        """With no runtime, should return empty but valid structure."""
        client, _ca = api_server
        status, body = client.get("/v1/escalation/analytics")
        assert status == 200
        assert body["escalation_roi"]["total_escalations"] == 0
        assert body["voi_distribution"] == []
        assert body["reviewer_utilization"] == {}

    def test_analytics_escalation_volume_is_list(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.get("/v1/escalation/analytics")
        assert status == 200
        assert isinstance(body["escalation_volume"], list)


# ═══════════════════════════════════════════════════════════════════════
# GET /v1/escalation/analytics/{agent_id}
# ═══════════════════════════════════════════════════════════════════════


class TestEscalationAnalyticsAgent:
    def test_agent_analytics_returns_correct_structure(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.get("/v1/escalation/analytics/agent-test-001")
        assert status == 200
        assert body["agent_id"] == "agent-test-001"
        assert "escalations" in body
        assert "total" in body
        assert "timestamp" in body

    def test_agent_analytics_empty_data(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        """Agent with no escalations should return empty list."""
        client, _ca = api_server
        status, body = client.get("/v1/escalation/analytics/nonexistent-agent")
        assert status == 200
        assert body["escalations"] == []
        assert body["total"] == 0

    def test_agent_analytics_escalations_is_list(
        self, api_server: tuple[APITestClient, CertificateAuthority],
    ) -> None:
        client, _ca = api_server
        status, body = client.get("/v1/escalation/analytics/agent-xyz")
        assert status == 200
        assert isinstance(body["escalations"], list)
