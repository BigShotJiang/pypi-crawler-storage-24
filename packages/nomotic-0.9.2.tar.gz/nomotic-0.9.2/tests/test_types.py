"""Tests for core types."""

from nomotic.types import (
    Action,
    ActionRecord,
    ActionState,
    AgentContext,
    BlastRadius,
    DataSensitivity,
    DimensionResult,
    DimensionScore,
    Environment,
    EvaluatedRule,
    GovernanceVerdict,
    InterruptRequest,
    ReversibilityDeclaration,
    Severity,
    TrustProfile,
    Verdict,
)


def test_action_has_unique_id():
    a1 = Action()
    a2 = Action()
    assert a1.id != a2.id


def test_action_frozen():
    a = Action(agent_id="test", action_type="read", target="db")
    assert a.agent_id == "test"
    assert a.action_type == "read"
    assert a.target == "db"


def test_trust_profile_violation_rate():
    p = TrustProfile(agent_id="a")
    assert p.violation_rate == 0.0

    p.violation_count = 2
    p.successful_actions = 8
    assert p.violation_rate == 0.2


def test_trust_profile_defaults():
    p = TrustProfile(agent_id="a")
    assert p.overall_trust == 0.5
    assert p.violation_count == 0
    assert p.successful_actions == 0


def test_verdict_enum():
    assert Verdict.ALLOW != Verdict.DENY
    assert Verdict.ESCALATE != Verdict.MODIFY


def test_governance_verdict_structure():
    v = GovernanceVerdict(
        action_id="abc",
        verdict=Verdict.ALLOW,
        ucs=0.85,
        tier=2,
    )
    assert v.action_id == "abc"
    assert v.ucs == 0.85
    assert v.tier == 2
    assert v.vetoed_by == []


def test_dimension_score_defaults():
    s = DimensionScore(dimension_name="test", score=0.7)
    assert s.weight == 1.0
    assert s.confidence == 1.0
    assert s.veto is False


def test_action_state_lifecycle():
    states = [
        ActionState.PENDING,
        ActionState.EVALUATING,
        ActionState.APPROVED,
        ActionState.EXECUTING,
        ActionState.COMPLETED,
    ]
    assert len(set(states)) == 5


def test_interrupt_request():
    r = InterruptRequest(
        action_id="a1",
        reason="policy violation",
        source="scope_compliance",
        severity=Severity.CRITICAL,
    )
    assert r.scope == "action"


# ── Schema field tests ────────────────────────────────────────────────


def test_action_schema_fields_default_none():
    """New schema fields default to None/empty without breaking existing usage."""
    a = Action(agent_id="test", action_type="read", target="db")
    assert a.blast_radius is None
    assert a.reversibility is None
    assert a.reversible_components == ()
    assert a.data_sensitivity is None
    assert a.declared_jurisdiction is None
    assert a.declared_goal is None
    assert a.goal_type is None
    assert a.downstream_dependencies == 0
    assert a.downstream_systems == ()
    assert a.indirect_stakeholder_reach == 0
    assert a.environment is None
    assert a.delegating_agent_id is None
    assert a.workflow_step is None
    assert a.workflow_total_steps is None


def test_action_with_all_schema_fields():
    """Action constructs correctly with all schema fields populated."""
    a = Action(
        agent_id="agent-1",
        action_type="delete",
        target="user_records",
        blast_radius=BlastRadius.SUBSET,
        reversibility=ReversibilityDeclaration.PARTIAL,
        reversible_components=("soft_delete", "audit_log"),
        data_sensitivity=DataSensitivity.PII,
        declared_jurisdiction="EU",
        declared_goal="Remove inactive accounts per GDPR request",
        goal_type="modification",
        downstream_dependencies=3,
        downstream_systems=("billing", "analytics", "email"),
        indirect_stakeholder_reach=50000,
        environment=Environment.PRODUCTION,
        delegating_agent_id="orchestrator-1",
        workflow_step=2,
        workflow_total_steps=5,
    )
    assert a.blast_radius is BlastRadius.SUBSET
    assert a.reversibility is ReversibilityDeclaration.PARTIAL
    assert a.reversible_components == ("soft_delete", "audit_log")
    assert a.data_sensitivity is DataSensitivity.PII
    assert a.declared_jurisdiction == "EU"
    assert a.declared_goal == "Remove inactive accounts per GDPR request"
    assert a.goal_type == "modification"
    assert a.downstream_dependencies == 3
    assert a.downstream_systems == ("billing", "analytics", "email")
    assert a.indirect_stakeholder_reach == 50000
    assert a.environment is Environment.PRODUCTION
    assert a.delegating_agent_id == "orchestrator-1"
    assert a.workflow_step == 2
    assert a.workflow_total_steps == 5


def test_blast_radius_enum_values():
    assert BlastRadius.SINGLE_RECORD.value == "single_record"
    assert BlastRadius.SUBSET.value == "subset"
    assert BlastRadius.SYSTEM_WIDE.value == "system_wide"


def test_reversibility_declaration_enum_values():
    assert ReversibilityDeclaration.REVERSIBLE.value == "reversible"
    assert ReversibilityDeclaration.APPEND_ONLY.value == "append_only"
    assert ReversibilityDeclaration.IRREVERSIBLE.value == "irreversible"
    assert ReversibilityDeclaration.PARTIAL.value == "partial"


def test_data_sensitivity_enum_values():
    assert DataSensitivity.PUBLIC.value == "public"
    assert DataSensitivity.INTERNAL.value == "internal"
    assert DataSensitivity.CONFIDENTIAL.value == "confidential"
    assert DataSensitivity.PII.value == "pii"
    assert DataSensitivity.PHI.value == "phi"
    assert DataSensitivity.FINANCIAL.value == "financial"
    assert DataSensitivity.CLASSIFIED.value == "classified"


def test_environment_enum_values():
    assert Environment.DEVELOPMENT.value == "development"
    assert Environment.STAGING.value == "staging"
    assert Environment.PRODUCTION.value == "production"
    assert Environment.TEST.value == "test"


def test_enum_serialize_deserialize():
    """Enums round-trip through their string values."""
    for enum_cls in (BlastRadius, ReversibilityDeclaration, DataSensitivity, Environment):
        for member in enum_cls:
            assert enum_cls(member.value) is member


def test_action_frozen_with_schema_fields():
    """Schema fields on frozen Action cannot be mutated."""
    a = Action(
        blast_radius=BlastRadius.SINGLE_RECORD,
        environment=Environment.TEST,
    )
    try:
        a.blast_radius = BlastRadius.SYSTEM_WIDE  # type: ignore[misc]
        assert False, "Should have raised FrozenInstanceError"
    except AttributeError:
        pass


# ── DimensionResult tests ────────────────────────────────────────────


def test_evaluated_rule_construction():
    rule = EvaluatedRule(
        rule_id="scope-001",
        rule_description="Action must be within declared scope",
        triggered=True,
        value_evaluated="delete_all",
        threshold_used=None,
        outcome="fail",
    )
    assert rule.rule_id == "scope-001"
    assert rule.triggered is True
    assert rule.outcome == "fail"


def test_dimension_result_defaults():
    """DimensionResult constructs with minimal args and sensible defaults."""
    result = DimensionResult(dimension_name="scope_compliance", score=0.8)
    assert result.dimension_name == "scope_compliance"
    assert result.score == 0.8
    assert result.confidence == 1.0
    assert result.veto is False
    assert result.rules_evaluated == []
    assert result.primary_signal == ""
    assert result.counterfactual == ""
    assert result.escalation_required is False
    assert result.schema_fields_used == []
    assert result.signals_used == []
    assert result.context_missing == []
    assert result.evaluation_time_ms == 0.0
    assert result.dimension_version == "1.0"


def test_dimension_result_full_construction():
    """DimensionResult constructs with all fields populated."""
    rules = [
        EvaluatedRule(
            rule_id="blast-001",
            rule_description="Blast radius check",
            triggered=True,
            value_evaluated="system_wide",
            threshold_used="subset",
            outcome="fail",
        ),
        EvaluatedRule(
            rule_id="blast-002",
            rule_description="Environment check",
            triggered=False,
            value_evaluated="staging",
            threshold_used=None,
            outcome="pass",
        ),
    ]
    result = DimensionResult(
        dimension_name="blast_radius",
        score=0.3,
        confidence=0.9,
        veto=True,
        rules_evaluated=rules,
        primary_signal="system_wide blast radius in production",
        counterfactual="would have scored 0.8 if blast_radius had been subset",
        escalation_required=True,
        schema_fields_used=["blast_radius", "environment"],
        signals_used=["deployment_target"],
        context_missing=["rollback_plan"],
        evaluation_time_ms=1.5,
        dimension_version="2.0",
    )
    assert result.veto is True
    assert result.escalation_required is True
    assert len(result.rules_evaluated) == 2
    assert result.rules_evaluated[0].outcome == "fail"
    assert result.schema_fields_used == ["blast_radius", "environment"]
    assert result.context_missing == ["rollback_plan"]
    assert result.dimension_version == "2.0"


def test_dimension_result_to_reasoning_string_minimal():
    """to_reasoning_string works with minimal data."""
    result = DimensionResult(dimension_name="test_dim", score=0.75)
    s = result.to_reasoning_string()
    assert "test_dim" in s
    assert "0.75" in s


def test_dimension_result_to_reasoning_string_full():
    """to_reasoning_string includes all structured data."""
    result = DimensionResult(
        dimension_name="scope",
        score=0.4,
        confidence=0.85,
        veto=True,
        rules_evaluated=[
            EvaluatedRule(
                rule_id="r1",
                rule_description="scope check",
                triggered=True,
                value_evaluated="x",
                threshold_used="y",
                outcome="fail",
            ),
        ],
        primary_signal="out of scope action",
        counterfactual="would have scored 0.9 if action was in scope",
        escalation_required=True,
        context_missing=["agent_role"],
    )
    s = result.to_reasoning_string()
    assert "VETO" in s
    assert "Primary signal: out of scope action" in s
    assert "[FAIL] r1: scope check" in s
    assert "Counterfactual:" in s
    assert "Escalation required" in s
    assert "Missing context: agent_role" in s


def test_dimension_score_result_field():
    """DimensionScore has optional result field, backward compatible."""
    # Without result — backward compatible
    score = DimensionScore(dimension_name="test", score=0.7)
    assert score.result is None

    # With result
    result = DimensionResult(dimension_name="test", score=0.7)
    score_with = DimensionScore(dimension_name="test", score=0.7, result=result)
    assert score_with.result is result
    assert score_with.result.dimension_name == "test"


def test_governance_verdict_justification_record():
    """GovernanceVerdict carries justification_record and escalation_required_by."""
    r1 = DimensionResult(dimension_name="scope", score=0.4, escalation_required=True)
    r2 = DimensionResult(dimension_name="trust", score=0.8)

    v = GovernanceVerdict(
        action_id="abc",
        verdict=Verdict.ESCALATE,
        ucs=0.5,
        justification_record={"scope": r1, "trust": r2},
        escalation_required_by=["scope"],
    )
    assert "scope" in v.justification_record
    assert v.justification_record["scope"].escalation_required is True
    assert v.escalation_required_by == ["scope"]


def test_governance_verdict_justification_defaults():
    """New GovernanceVerdict fields default to empty."""
    v = GovernanceVerdict(action_id="x", verdict=Verdict.ALLOW, ucs=0.9)
    assert v.justification_record == {}
    assert v.escalation_required_by == []
