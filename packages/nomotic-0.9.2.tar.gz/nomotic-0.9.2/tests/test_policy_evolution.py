"""Tests for the Policy Evolution Dashboard backend."""

import time
import uuid

import pytest

from nomotic.audit import (
    AccountabilityRecord,
    AuditRecord,
    AuditTrail,
    ChangeRecord,
    OutcomeRecord,
    UnwrittenPolicyAdjustmentRecord,
)
from nomotic.policy_evolution import (
    GovernancePattern,
    PatternAnalyzer,
    PatternType,
    PolicyEvolutionConfig,
    PolicyEvolutionEngine,
    PolicyRecommendation,
    RecommendationEngine,
)


# ── Helpers ────────────────────────────────────────────────────────────


def _make_decision(
    action_id: str = "",
    action_type: str = "data_access",
    verdict: str = "ALLOW",
    dimension_scores: list | None = None,
    timestamp: float | None = None,
) -> AuditRecord:
    return AuditRecord(
        record_id=uuid.uuid4().hex[:12],
        timestamp=timestamp or time.time(),
        context_code="GOVERNANCE.ALLOW",
        severity="info",
        agent_id="agent-1",
        owner_id="owner@example.com",
        user_id="user@example.com",
        action_id=action_id or uuid.uuid4().hex[:12],
        action_type=action_type,
        action_target="/data/resource",
        verdict=verdict,
        ucs=0.85,
        tier=1,
        dimension_scores=dimension_scores or [],
    )


def _make_accountability(
    action_id: str,
    human_action: str = "override_approved",
    human_id: str = "admin@example.com",
    timestamp: float | None = None,
) -> AccountabilityRecord:
    return AccountabilityRecord(
        record_id=uuid.uuid4().hex[:12],
        action_id=action_id,
        human_id=human_id,
        human_action=human_action,
        original_verdict="DENY",
        resulting_verdict="ALLOW",
        stated_rationale="Override justified",
        timestamp=timestamp or time.time(),
    )


def _make_outcome(
    action_id: str,
    override_occurred: bool = False,
    timestamp: float | None = None,
) -> OutcomeRecord:
    return OutcomeRecord(
        record_id=uuid.uuid4().hex[:12],
        action_id=action_id,
        agent_id="agent-1",
        decision_verdict="ALLOW",
        outcome_signals={"status": "completed"},
        outcome_at=time.time(),
        outcome_validated=True,
        override_occurred=override_occurred,
        override_reason="Manual correction" if override_occurred else None,
        timestamp=timestamp or time.time(),
    )


# ── PatternAnalyzer tests ─────────────────────────────────────────────


class TestExceptionClusterDetection:
    """Exception cluster detection from mock audit data."""

    def test_detects_override_cluster(self):
        analyzer = PatternAnalyzer()
        decisions = []
        accountability = []
        for i in range(7):
            aid = f"action-{i}"
            decisions.append(_make_decision(action_id=aid, action_type="data_export"))
            accountability.append(_make_accountability(action_id=aid))

        patterns = analyzer.analyze_exception_clusters(
            decisions, accountability, window_days=90, min_observations=5
        )

        assert len(patterns) == 1
        p = patterns[0]
        assert p.pattern_type == PatternType.EXCEPTION_CLUSTER
        assert p.observation_count == 7
        assert "data_export" in p.description
        assert len(p.supporting_evidence) == 7

    def test_ignores_small_clusters(self):
        analyzer = PatternAnalyzer()
        decisions = [_make_decision(action_id=f"a-{i}") for i in range(3)]
        accountability = [_make_accountability(action_id=f"a-{i}") for i in range(3)]

        patterns = analyzer.analyze_exception_clusters(
            decisions, accountability, window_days=90, min_observations=5
        )
        assert len(patterns) == 0

    def test_ignores_old_records(self):
        analyzer = PatternAnalyzer()
        old = time.time() - 200 * 86400
        decisions = [
            _make_decision(action_id=f"a-{i}", action_type="old_op", timestamp=old)
            for i in range(10)
        ]
        accountability = [
            _make_accountability(action_id=f"a-{i}", timestamp=old)
            for i in range(10)
        ]

        patterns = analyzer.analyze_exception_clusters(
            decisions, accountability, window_days=90, min_observations=5
        )
        assert len(patterns) == 0


class TestOutcomeCorrelations:
    """Outcome correlation detection."""

    def test_detects_contradicted_verdicts(self):
        analyzer = PatternAnalyzer()
        decisions = []
        outcomes = []
        for i in range(10):
            aid = f"action-{i}"
            decisions.append(_make_decision(action_id=aid, verdict="DENY"))
            outcomes.append(_make_outcome(action_id=aid, override_occurred=(i < 5)))

        patterns = analyzer.analyze_outcome_correlations(
            decisions, outcomes, window_days=90
        )
        assert len(patterns) == 1
        p = patterns[0]
        assert p.pattern_type == PatternType.OUTCOME_CORRELATION
        assert p.observation_count == 5

    def test_no_pattern_when_contradiction_rate_low(self):
        analyzer = PatternAnalyzer()
        decisions = []
        outcomes = []
        for i in range(20):
            aid = f"action-{i}"
            decisions.append(_make_decision(action_id=aid, verdict="ALLOW"))
            outcomes.append(_make_outcome(action_id=aid, override_occurred=(i < 2)))

        patterns = analyzer.analyze_outcome_correlations(
            decisions, outcomes, window_days=90
        )
        assert len(patterns) == 0


class TestDimensionDrift:
    """Dimension drift detection."""

    def test_detects_dimension_mismatch(self):
        analyzer = PatternAnalyzer()
        decisions = []
        outcomes = []
        for i in range(10):
            aid = f"action-{i}"
            decisions.append(
                _make_decision(
                    action_id=aid,
                    dimension_scores=[
                        {"name": "scope_compliance", "score": 0.9, "weight": 1.5}
                    ],
                )
            )
            outcomes.append(_make_outcome(action_id=aid, override_occurred=True))

        patterns = analyzer.analyze_dimension_drift(
            decisions, outcomes, window_days=90
        )
        assert len(patterns) == 1
        p = patterns[0]
        assert p.pattern_type == PatternType.DIMENSION_DRIFT
        assert "scope_compliance" in p.description


# ── RecommendationEngine tests ────────────────────────────────────────


class TestRecommendationGeneration:
    """Recommendation generation from patterns."""

    def test_generates_for_exception_cluster(self):
        engine = RecommendationEngine()
        pattern = GovernancePattern(
            pattern_id="p1",
            pattern_type=PatternType.EXCEPTION_CLUSTER,
            description="Override cluster on data_export",
            supporting_evidence=["a1", "a2"],
            observation_count=5,
            significance_score=0.7,
            first_observed=time.time() - 1000,
            last_observed=time.time(),
        )
        rec = engine.generate(pattern, {})
        assert rec is not None
        assert rec.pattern_id == "p1"
        assert rec.status == "pending"
        assert "override" in rec.recommendation_text.lower()

    def test_generates_for_outcome_correlation(self):
        engine = RecommendationEngine()
        pattern = GovernancePattern(
            pattern_id="p2",
            pattern_type=PatternType.OUTCOME_CORRELATION,
            description="Verdict contradicted 60%",
            supporting_evidence=["a1"],
            observation_count=6,
            significance_score=0.6,
            first_observed=time.time() - 500,
            last_observed=time.time(),
        )
        rec = engine.generate(pattern, {})
        assert rec is not None
        assert "recalibrate" in rec.recommendation_text.lower()

    def test_generates_for_dimension_drift(self):
        engine = RecommendationEngine()
        pattern = GovernancePattern(
            pattern_id="p3",
            pattern_type=PatternType.DIMENSION_DRIFT,
            description="scope_compliance mismatch",
            supporting_evidence=["a1"],
            observation_count=4,
            significance_score=0.5,
            first_observed=time.time() - 300,
            last_observed=time.time(),
        )
        rec = engine.generate(pattern, {})
        assert rec is not None
        assert "dimension" in rec.recommendation_text.lower()

    def test_returns_none_for_unknown_type(self):
        engine = RecommendationEngine()
        pattern = GovernancePattern(
            pattern_id="p4",
            pattern_type=PatternType.CONFIG_STALENESS,
            description="stale config",
            supporting_evidence=[],
            observation_count=1,
            significance_score=0.3,
            first_observed=time.time(),
            last_observed=time.time(),
        )
        rec = engine.generate(pattern, {})
        assert rec is None


# ── PolicyEvolutionEngine tests ────────────────────────────────────────


class TestApprovalWorkflow:
    """Approval workflow emits correct record types."""

    def _build_engine_with_data(self) -> PolicyEvolutionEngine:
        trail = AuditTrail()
        # Populate with enough data to trigger an exception cluster.
        for i in range(7):
            aid = f"action-{i}"
            dec = _make_decision(action_id=aid, action_type="data_export")
            trail.append(dec)
            acc = _make_accountability(action_id=aid)
            trail.append_accountability(acc)

        config = PolicyEvolutionConfig(
            window_days=90,
            min_cluster_size=5,
            significance_threshold=0.3,
        )
        engine = PolicyEvolutionEngine(trail, config)
        engine.run_analysis()
        return engine

    def test_run_analysis_detects_patterns(self):
        engine = self._build_engine_with_data()
        assert len(engine.patterns) >= 1
        assert engine.patterns[0].pattern_type == PatternType.EXCEPTION_CLUSTER

    def test_pending_recommendations_generated(self):
        engine = self._build_engine_with_data()
        recs = engine.pending_recommendations()
        assert len(recs) >= 1
        assert recs[0].status == "pending"

    def test_approve_recommendation(self):
        engine = self._build_engine_with_data()
        recs = engine.pending_recommendations()
        rec_id = recs[0].recommendation_id
        engine.approve_recommendation(rec_id, approved_by="admin@co.com", note="Looks good")
        rec = engine.get_recommendation(rec_id)
        assert rec is not None
        assert rec.status == "approved"
        assert rec.reviewed_by == "admin@co.com"
        assert rec.reviewer_note == "Looks good"

    def test_apply_approved_emits_records(self):
        engine = self._build_engine_with_data()
        recs = engine.pending_recommendations()
        rec_id = recs[0].recommendation_id

        engine.approve_recommendation(rec_id, approved_by="admin@co.com")
        change = engine.apply_approved_recommendation(rec_id)

        assert isinstance(change, ChangeRecord)
        assert change.change_type == "policy_evolution"
        assert change.changed_by == "admin@co.com"

        # Verify records were emitted to the audit trail.
        trail = engine._audit_trail
        adjustments = trail.policy_adjustment_records
        assert len(adjustments) >= 1
        assert adjustments[-1].approved_by == "admin@co.com"

        changes = trail.change_records
        assert len(changes) >= 1
        assert changes[-1].source.startswith("policy_evolution:")

    def test_apply_unapproved_raises(self):
        engine = self._build_engine_with_data()
        recs = engine.pending_recommendations()
        rec_id = recs[0].recommendation_id
        with pytest.raises(ValueError, match="not approved"):
            engine.apply_approved_recommendation(rec_id)

    def test_apply_nonexistent_raises(self):
        engine = self._build_engine_with_data()
        with pytest.raises(KeyError):
            engine.apply_approved_recommendation("nonexistent-id")


class TestRejectionWorkflow:
    """Rejection captured in accountability record."""

    def test_reject_recommendation_emits_accountability(self):
        trail = AuditTrail()
        for i in range(7):
            aid = f"action-{i}"
            trail.append(_make_decision(action_id=aid, action_type="data_export"))
            trail.append_accountability(_make_accountability(action_id=aid))

        config = PolicyEvolutionConfig(
            min_cluster_size=5, significance_threshold=0.3
        )
        engine = PolicyEvolutionEngine(trail, config)
        engine.run_analysis()

        recs = engine.pending_recommendations()
        assert len(recs) >= 1
        rec_id = recs[0].recommendation_id

        engine.reject_recommendation(
            rec_id, rejected_by="reviewer@co.com", note="Not yet"
        )

        rec = engine.get_recommendation(rec_id)
        assert rec is not None
        assert rec.status == "rejected"
        assert rec.reviewed_by == "reviewer@co.com"

        # Verify accountability record was emitted.
        acc_records = trail.accountability_records
        rejection_records = [
            r for r in acc_records if r.human_action == "recommendation_rejected"
        ]
        assert len(rejection_records) >= 1
        rr = rejection_records[-1]
        assert rr.human_id == "reviewer@co.com"
        assert rr.original_verdict == "pending"
        assert rr.resulting_verdict == "rejected"
        assert rr.stated_rationale == "Not yet"


# ── Serialization tests ───────────────────────────────────────────────


class TestSerialization:
    """to_dict round-trips."""

    def test_pattern_to_dict(self):
        p = GovernancePattern(
            pattern_id="p1",
            pattern_type=PatternType.EXCEPTION_CLUSTER,
            description="test",
            supporting_evidence=["a1"],
            observation_count=5,
            significance_score=0.75,
            first_observed=1000.0,
            last_observed=2000.0,
        )
        d = p.to_dict()
        assert d["pattern_type"] == "exception_cluster"
        assert d["significance_score"] == 0.75

    def test_recommendation_to_dict(self):
        r = PolicyRecommendation(
            recommendation_id="r1",
            pattern_id="p1",
            recommendation_text="Do something",
            proposed_change={"key": "value"},
            projected_impact="Good things",
        )
        d = r.to_dict()
        assert d["status"] == "pending"
        assert "reviewed_by" not in d  # None fields excluded

    def test_config_to_dict(self):
        c = PolicyEvolutionConfig()
        d = c.to_dict()
        assert d["window_days"] == 90
        assert d["min_cluster_size"] == 5
