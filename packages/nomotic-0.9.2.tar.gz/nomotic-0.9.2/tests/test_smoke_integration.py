"""End-to-end smoke test validating that the full Nomotic system works
as documented. Exercises the real runtime with realistic scenarios.

Run: pytest tests/test_smoke_integration.py -v
"""

import time
from unittest import TestCase

from nomotic import (
    Nomotic,
    GovernedToolExecutor,
    GovernanceRuntime,
    Action,
    AgentContext,
    TrustProfile,
)
from nomotic.contract import BehavioralContract, ContractStore, generate_contract
from nomotic.fingerprint import BehavioralFingerprint
from nomotic.drift import DriftCalculator, DriftScore
from nomotic.observer import FingerprintObserver
from nomotic.monitor import DriftMonitor
from nomotic.priors import ArchetypePrior, PriorRegistry
from nomotic.semantic import SemanticAnchor, SemanticActionMap, SemanticObserver
from nomotic.invariants import InvariantSpec, InvariantBuilder, CompiledInvariants
from nomotic.fleet_monitor import FleetBehavioralMonitor, FleetDriftConfig
from nomotic.drift_causal import DriftCausalAnalyzer
from nomotic.trajectory_engine import BehavioralTrajectoryEngine, TrajectoryConfig
from nomotic.control_plane import ControlPlane
from nomotic.replay import BehavioralReplayEngine, ReplayConfig
from nomotic.behavioral_provenance import BehavioralProvenance
from nomotic.runtime import RuntimeConfig


class TestNomoticAlias(TestCase):
    """Verify the branded Nomotic alias works."""

    def test_nomotic_is_governance_runtime(self):
        assert Nomotic is GovernanceRuntime

    def test_governed_tool_executor_connect(self):
        agent = GovernedToolExecutor.connect("smoke-test-agent", test_mode=True)
        assert isinstance(agent, GovernedToolExecutor)


class TestFullGovernancePipeline(TestCase):
    """Validate the core governance pipeline end-to-end."""

    def setUp(self):
        self.runtime = GovernanceRuntime(config=RuntimeConfig(
            enable_fingerprints=True,
            enable_contracts=True,
            enable_audit=True,
        ))
        self.runtime.configure_scope(
            agent_id="smoke-agent",
            scope={"read", "write", "query"},
        )
        self.runtime.configure_boundaries(
            agent_id="smoke-agent",
            allowed_targets={"customer", "order"},
        )

    def test_allow_in_scope(self):
        action = Action(agent_id="smoke-agent", action_type="read", target="customer")
        context = AgentContext(agent_id="smoke-agent", trust_profile=TrustProfile(agent_id="smoke-agent"))
        verdict = self.runtime.evaluate(action, context)
        self.assertEqual(verdict.verdict.name, "ALLOW")
        self.assertGreater(verdict.ucs, 0.5)

    def test_deny_out_of_scope(self):
        action = Action(agent_id="smoke-agent", action_type="delete", target="production")
        context = AgentContext(agent_id="smoke-agent", trust_profile=TrustProfile(agent_id="smoke-agent"))
        verdict = self.runtime.evaluate(action, context)
        self.assertIn(verdict.verdict.name, ("DENY", "ESCALATE"))

    def test_trust_changes_after_verdict(self):
        context = AgentContext(agent_id="smoke-agent", trust_profile=TrustProfile(agent_id="smoke-agent"))
        trust_before = context.trust_profile.overall_trust
        action = Action(agent_id="smoke-agent", action_type="read", target="customer")
        self.runtime.evaluate(action, context)
        trust_after = self.runtime.trust_calibrator.get_profile("smoke-agent").overall_trust
        # Trust should have changed (even slightly)
        self.assertNotEqual(trust_before, trust_after)

    def test_behavioral_provenance_attached(self):
        action = Action(agent_id="smoke-agent", action_type="read", target="customer")
        context = AgentContext(agent_id="smoke-agent", trust_profile=TrustProfile(agent_id="smoke-agent"))
        verdict = self.runtime.evaluate(action, context)
        # Behavioral provenance should be attached to every verdict
        self.assertIsNotNone(verdict.behavioral_provenance)

    def test_fingerprint_forms_from_observations(self):
        context = AgentContext(agent_id="smoke-agent", trust_profile=TrustProfile(agent_id="smoke-agent"))
        for i in range(20):
            action = Action(agent_id="smoke-agent", action_type="read", target="customer")
            self.runtime.evaluate(action, context)
        fp = self.runtime.get_fingerprint("smoke-agent")
        self.assertIsNotNone(fp)
        self.assertGreater(fp.total_observations, 0)
        self.assertIn("read", fp.action_distribution)


class TestBehavioralContracts(TestCase):
    """Validate contracts generate, seal, verify, and integrate with runtime."""

    def test_generate_from_archetype(self):
        contract = generate_contract(
            agent_id="contract-test",
            archetype="customer-experience",
            prior_registry=PriorRegistry.with_defaults(),
        )
        self.assertEqual(contract.agent_id, "contract-test")
        self.assertEqual(contract.archetype, "customer-experience")
        self.assertGreater(len(contract.expected_action_distribution), 0)

    def test_contract_store_lifecycle(self):
        store = ContractStore()
        contract = generate_contract(
            agent_id="store-test",
            archetype="data-processor",
            prior_registry=PriorRegistry.with_defaults(),
        )
        store.store(contract)
        active = store.get_active("store-test")
        self.assertIsNotNone(active)
        self.assertEqual(active.version, contract.version)

    def test_contract_serialization_roundtrip(self):
        contract = generate_contract(
            agent_id="serial-test",
            archetype="financial-analyst",
            prior_registry=PriorRegistry.with_defaults(),
        )
        data = contract.to_dict()
        restored = BehavioralContract.from_dict(data)
        self.assertEqual(restored.agent_id, contract.agent_id)
        self.assertEqual(restored.archetype, contract.archetype)


class TestSemanticDrift(TestCase):
    """Validate semantic drift detection works end-to-end."""

    def test_semantic_anchor_creation(self):
        anchor = SemanticAnchor(
            term="research",
            expected_action_distribution={"read": 0.9, "query": 0.1},
            expected_target_distribution={"search_api": 0.7, "database": 0.3},
        )
        self.assertEqual(anchor.term, "research")
        data = anchor.to_dict()
        restored = SemanticAnchor.from_dict(data)
        self.assertEqual(restored.term, "research")

    def test_semantic_observer_tracks_observations(self):
        observer = SemanticObserver()
        observer.set_anchors("agent-1", [
            SemanticAnchor(
                term="research",
                expected_action_distribution={"read": 0.9, "query": 0.1},
                expected_target_distribution={"api": 1.0},
            )
        ])
        for _ in range(20):
            action = Action(
                agent_id="agent-1",
                action_type="read",
                target="api",
                parameters={"instruction_context": "research market data"},
            )
            observer.observe("agent-1", action)
        drift = observer.get_semantic_drift("agent-1")
        # With matching behavior, drift should be low
        self.assertIsNotNone(drift)
        self.assertLess(drift.overall, 0.3)

    def test_drift_score_includes_semantic(self):
        score = DriftScore(
            overall=0.2, action_drift=0.1, target_drift=0.1,
            temporal_drift=0.1, outcome_drift=0.1, semantic_drift=0.15,
            confidence=0.9, window_size=100, baseline_size=500,
        )
        d = score.to_dict()
        self.assertIn("semantic_drift", d)
        self.assertAlmostEqual(d["semantic_drift"], 0.15, places=2)


class TestBehavioralInvariants(TestCase):
    """Validate invariant specification, compilation, and evaluation."""

    def test_builder_creates_valid_specs(self):
        specs = [
            InvariantBuilder.ratio("write_to_read", "lt", 0.3, "Write ratio under 30%"),
            InvariantBuilder.drift("action", "lt", 0.20, "Action drift under 20%"),
        ]
        for spec in specs:
            self.assertIsInstance(spec, InvariantSpec)
            data = spec.to_dict()
            restored = InvariantSpec.from_dict(data)
            self.assertEqual(restored.invariant_id, spec.invariant_id)

    def test_compiled_invariants_evaluate(self):
        specs = [InvariantBuilder.drift("action", "lt", 0.5, "Action drift check")]
        compiled = CompiledInvariants.compile(specs)
        drift = DriftScore(
            overall=0.2, action_drift=0.3, target_drift=0.1,
            temporal_drift=0.1, outcome_drift=0.1,
            confidence=0.9, window_size=100, baseline_size=500,
        )
        results = compiled.evaluate(drift_score=drift)
        self.assertEqual(len(results), 1)
        self.assertTrue(results[0].satisfied)  # 0.3 < 0.5


class TestFleetMonitor(TestCase):
    """Validate fleet-level drift detection."""

    def test_fleet_monitor_creation(self):
        monitor = FleetBehavioralMonitor(config=FleetDriftConfig())
        self.assertIsNotNone(monitor)

    def test_interaction_map_registration(self):
        monitor = FleetBehavioralMonitor()
        monitor.register_interaction("agent-a", "agent-b")
        monitor.register_interaction("agent-b", "agent-c")
        # Interaction map should have 2 entries
        health = monitor.get_fleet_health()
        self.assertIsNotNone(health)


class TestDriftCausalAnalysis(TestCase):
    """Validate drift causal analyzer produces reports."""

    def test_agent_drift_analysis(self):
        analyzer = DriftCausalAnalyzer()
        drift = DriftScore(
            overall=0.4, action_drift=0.35, target_drift=0.2,
            temporal_drift=0.1, outcome_drift=0.1,
            confidence=0.9, window_size=100, baseline_size=500,
        )
        report = analyzer.analyze_agent_drift("test-agent", drift, time.time())
        self.assertIsNotNone(report)
        self.assertIsNotNone(report.primary_hypothesis)
        self.assertEqual(report.agent_id, "test-agent")


class TestTrajectoryEngine(TestCase):
    """Validate trajectory projection."""

    def test_engine_creation(self):
        engine = BehavioralTrajectoryEngine(config=TrajectoryConfig())
        self.assertIsNotNone(engine)

    def test_record_drift_no_crash(self):
        engine = BehavioralTrajectoryEngine(config=TrajectoryConfig())
        drift = DriftScore(
            overall=0.1, action_drift=0.1, target_drift=0.05,
            temporal_drift=0.05, outcome_drift=0.05,
            confidence=0.8, window_size=50, baseline_size=200,
        )
        engine.record_drift("test-agent", drift)
        # Should not crash, just record


class TestControlPlane(TestCase):
    """Validate command and control directive system."""

    def test_control_plane_creation(self):
        runtime = GovernanceRuntime()
        plane = ControlPlane(runtime=runtime)
        self.assertIsNotNone(plane)
        self.assertEqual(len(plane.get_active_directives()), 0)

    def test_quarantine_check(self):
        runtime = GovernanceRuntime()
        plane = ControlPlane(runtime=runtime)
        self.assertFalse(plane.is_quarantined("any-agent"))


class TestReplayEngine(TestCase):
    """Validate counterfactual replay."""

    def test_engine_creation(self):
        engine = BehavioralReplayEngine()
        self.assertIsNotNone(engine)

    def test_replay_config_serialization(self):
        config = ReplayConfig(
            allow_threshold=0.8,
            deny_threshold=0.2,
            description="Stricter thresholds",
        )
        data = config.to_dict()
        self.assertEqual(data["allow_threshold"], 0.8)


class TestArchetypePriors(TestCase):
    """Validate all 10 archetypes have complete priors with semantic weights."""

    def test_all_archetypes_have_semantic_drift_weight(self):
        registry = PriorRegistry.with_defaults()
        archetypes = [
            "customer-experience", "operations-coordinator", "financial-analyst",
            "data-processor", "content-creator", "security-monitor",
            "research-analyst", "sales-agent", "executive-assistant",
            "healthcare-agent",
        ]
        for name in archetypes:
            prior = registry.get_for_agent(name)
            self.assertIsNotNone(prior, f"Missing prior for {name}")
            self.assertIn("semantic", prior.drift_weights, f"Missing semantic weight for {name}")

    def test_all_priors_have_valid_distributions(self):
        registry = PriorRegistry.with_defaults()
        for name, prior in registry._priors.items():
            if prior is None:
                continue
            total = sum(prior.action_distribution.values())
            self.assertAlmostEqual(total, 1.0, places=1, msg=f"Action distribution for {name} doesn't sum to 1.0")


class TestCLIImports(TestCase):
    """Validate CLI module loads without errors."""

    def test_cli_imports(self):
        from nomotic.cli import build_parser
        parser = build_parser()
        self.assertIsNotNone(parser)

    def test_cli_has_key_subcommands(self):
        from nomotic.cli import build_parser
        parser = build_parser()
        # Parse a known subcommand to verify it's registered
        args = parser.parse_args(["taxonomy"])
        self.assertEqual(args.command, "taxonomy")
