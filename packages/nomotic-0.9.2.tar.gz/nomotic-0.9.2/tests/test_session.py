"""Tests for session context accumulation.

Covers signal accumulation across evaluations, contradiction detection,
risk elevation calculation, session promotion, and thread-safe concurrent
session access.
"""

from __future__ import annotations

import threading
import time
from unittest.mock import MagicMock

import pytest

from nomotic.session import (
    SessionContext,
    SessionContradiction,
    SessionRegistry,
    SessionSignalUpdate,
)
from nomotic.types import (
    Action,
    AgentContext,
    BlastRadius,
    DataSensitivity,
    ReversibilityDeclaration,
    TrustProfile,
    Verdict,
)


# ── Helpers ────────────────────────────────────────────────────────────


def _make_action(**kwargs) -> Action:
    """Create an Action with sensible defaults."""
    defaults = {
        "agent_id": "agent-1",
        "action_type": "read",
        "target": "data",
    }
    defaults.update(kwargs)
    return Action(**defaults)


def _make_context(agent_id: str = "agent-1", session_id: str = "sess-1") -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id),
        session_id=session_id,
    )


# ── Signal Accumulation ───────────────────────────────────────────────


class TestSignalAccumulation:
    def test_apply_update_records_signal(self):
        ctx = SessionContext("sess-1", "agent-1")
        update = SessionSignalUpdate(
            signal_name="fraud_risk",
            value=0.8,
            confidence=0.9,
            source="behavior_inferred",
        )
        ctx.apply_update(update)

        assert len(ctx.signal_updates) == 1
        assert ctx.signal_updates[0].signal_name == "fraud_risk"

    def test_current_signals_returns_latest_value(self):
        ctx = SessionContext("sess-1", "agent-1")
        ctx.apply_update(SessionSignalUpdate(
            signal_name="loyalty", value=0.3, confidence=0.8, source="agent_declared",
        ))
        ctx.apply_update(SessionSignalUpdate(
            signal_name="loyalty", value=0.7, confidence=0.9, source="behavior_inferred",
        ))

        signals = ctx.current_signals()
        # Latest update wins
        assert signals["loyalty"] == 0.7

    def test_current_signals_includes_escalation_count(self):
        ctx = SessionContext("sess-1", "agent-1")
        ctx.escalation_count = 3

        signals = ctx.current_signals()
        assert signals["session_escalation_count"] == 3
        assert signals["session_contradiction_count"] == 0

    def test_current_signals_includes_contradiction_count(self):
        ctx = SessionContext("sess-1", "agent-1")
        prior = _make_action(declared_goal="help user", goal_type="assistance")
        current = _make_action(declared_goal="delete everything", goal_type="destruction")
        ctx.detect_contradiction(prior, current)

        signals = ctx.current_signals()
        assert signals["session_contradiction_count"] == 1

    def test_multiple_signals_accumulated(self):
        ctx = SessionContext("sess-1", "agent-1")
        for i in range(5):
            ctx.apply_update(SessionSignalUpdate(
                signal_name=f"signal_{i}",
                value=i * 0.1,
                confidence=0.8,
                source="agent_declared",
            ))

        signals = ctx.current_signals()
        for i in range(5):
            assert f"signal_{i}" in signals


# ── Contradiction Detection ────────────────────────────────────────────


class TestContradictionDetection:
    def test_goal_change_detected(self):
        ctx = SessionContext("sess-1", "agent-1")
        prior = _make_action(declared_goal="help user", goal_type="assistance")
        current = _make_action(declared_goal="delete data", goal_type="destruction")

        contradiction = ctx.detect_contradiction(prior, current)

        assert contradiction is not None
        assert contradiction.contradiction_type == "goal_change"
        assert contradiction.confidence > 0.0
        assert len(ctx.contradictions) == 1

    def test_goal_change_same_type_lower_confidence(self):
        ctx = SessionContext("sess-1", "agent-1")
        prior = _make_action(declared_goal="read file A", goal_type="retrieval")
        current = _make_action(declared_goal="read file B", goal_type="retrieval")

        contradiction = ctx.detect_contradiction(prior, current)

        assert contradiction is not None
        assert contradiction.contradiction_type == "goal_change"
        # Same goal_type -> lower confidence
        assert contradiction.confidence == 0.6

    def test_scope_expansion_blast_radius(self):
        ctx = SessionContext("sess-1", "agent-1")
        prior = _make_action(blast_radius=BlastRadius.SINGLE_RECORD)
        current = _make_action(blast_radius=BlastRadius.SYSTEM_WIDE)

        contradiction = ctx.detect_contradiction(prior, current)

        assert contradiction is not None
        assert contradiction.contradiction_type == "scope_expansion"
        assert contradiction.confidence > 0.5

    def test_scope_expansion_data_sensitivity(self):
        ctx = SessionContext("sess-1", "agent-1")
        prior = _make_action(data_sensitivity=DataSensitivity.PUBLIC)
        current = _make_action(data_sensitivity=DataSensitivity.PII)

        contradiction = ctx.detect_contradiction(prior, current)

        assert contradiction is not None
        assert contradiction.contradiction_type == "scope_expansion"

    def test_trust_reversal_detected(self):
        ctx = SessionContext("sess-1", "agent-1")
        prior = _make_action(reversibility=ReversibilityDeclaration.REVERSIBLE)
        current = _make_action(reversibility=ReversibilityDeclaration.IRREVERSIBLE)

        contradiction = ctx.detect_contradiction(prior, current)

        assert contradiction is not None
        assert contradiction.contradiction_type == "trust_reversal"
        assert contradiction.confidence > 0.5

    def test_no_contradiction_when_consistent(self):
        ctx = SessionContext("sess-1", "agent-1")
        prior = _make_action(declared_goal="read data", goal_type="retrieval")
        current = _make_action(declared_goal="read data", goal_type="retrieval")

        contradiction = ctx.detect_contradiction(prior, current)

        assert contradiction is None
        assert len(ctx.contradictions) == 0

    def test_contradiction_adds_signal_update(self):
        ctx = SessionContext("sess-1", "agent-1")
        prior = _make_action(declared_goal="help", goal_type="assist")
        current = _make_action(declared_goal="harm", goal_type="attack")

        ctx.detect_contradiction(prior, current)

        # Should have added a contradiction signal
        signal_names = [u.signal_name for u in ctx.signal_updates]
        assert any("contradiction_" in name for name in signal_names)

    def test_detect_contradictions_for_action(self):
        ctx = SessionContext("sess-1", "agent-1")
        action1 = _make_action(declared_goal="read", goal_type="retrieval")
        action2 = _make_action(declared_goal="read", goal_type="retrieval")
        action3 = _make_action(declared_goal="delete all", goal_type="destruction")

        # First two consistent
        ctx.detect_contradictions_for_action(action1)
        found = ctx.detect_contradictions_for_action(action2)
        # goal changed (different declared_goal) but same type
        # action2 "read" != action1 "read" — actually they are the same goal text
        # No contradiction expected

        # Third contradicts both prior actions
        found = ctx.detect_contradictions_for_action(action3)
        assert len(found) >= 1

    def test_highest_confidence_contradiction_returned(self):
        """When multiple contradiction types fire, the highest confidence wins."""
        ctx = SessionContext("sess-1", "agent-1")
        # Action that triggers both scope_expansion and goal_change
        prior = _make_action(
            declared_goal="read public data",
            goal_type="retrieval",
            blast_radius=BlastRadius.SINGLE_RECORD,
            data_sensitivity=DataSensitivity.PUBLIC,
        )
        current = _make_action(
            declared_goal="delete classified records",
            goal_type="destruction",
            blast_radius=BlastRadius.SYSTEM_WIDE,
            data_sensitivity=DataSensitivity.CLASSIFIED,
        )

        contradiction = ctx.detect_contradiction(prior, current)
        assert contradiction is not None
        # Should return whichever has higher confidence


# ── Risk Elevation ─────────────────────────────────────────────────────


class TestRiskElevation:
    def test_neutral_when_no_signals(self):
        ctx = SessionContext("sess-1", "agent-1")
        assert ctx.risk_elevation() == 0.0

    def test_escalation_increases_risk(self):
        ctx = SessionContext("sess-1", "agent-1")
        ctx.escalation_count = 3
        risk = ctx.risk_elevation()
        assert risk > 0.0
        assert risk <= 1.0

    def test_contradiction_increases_risk(self):
        ctx = SessionContext("sess-1", "agent-1")
        prior = _make_action(declared_goal="help", goal_type="assist")
        current = _make_action(declared_goal="harm", goal_type="attack")
        ctx.detect_contradiction(prior, current)

        risk = ctx.risk_elevation()
        assert risk > 0.0

    def test_behavior_inferred_signals_increase_risk(self):
        ctx = SessionContext("sess-1", "agent-1")
        for _ in range(5):
            ctx.apply_update(SessionSignalUpdate(
                signal_name="suspicious_pattern",
                value=True,
                confidence=0.9,
                source="behavior_inferred",
            ))

        risk = ctx.risk_elevation()
        assert risk > 0.0

    def test_risk_capped_at_1(self):
        ctx = SessionContext("sess-1", "agent-1")
        ctx.escalation_count = 100
        # Add many contradictions
        for i in range(20):
            ctx.contradictions.append(SessionContradiction(
                prior_action_id=f"a{i}",
                current_action_id=f"b{i}",
                contradiction_type="goal_change",
                confidence=0.9,
            ))
        for _ in range(50):
            ctx.apply_update(SessionSignalUpdate(
                signal_name="x",
                value=True,
                confidence=0.9,
                source="behavior_inferred",
            ))

        assert ctx.risk_elevation() <= 1.0

    def test_risk_combines_all_factors(self):
        ctx = SessionContext("sess-1", "agent-1")
        ctx.escalation_count = 2
        ctx.contradictions.append(SessionContradiction(
            prior_action_id="a1",
            current_action_id="a2",
            contradiction_type="goal_change",
            confidence=0.8,
        ))
        ctx.apply_update(SessionSignalUpdate(
            signal_name="pattern",
            value=True,
            confidence=0.9,
            source="behavior_inferred",
        ))

        risk = ctx.risk_elevation()
        # Should be a combination of all three factors
        assert risk > 0.2


# ── Session Promotion ──────────────────────────────────────────────────


class TestSessionPromotion:
    def test_promotable_signals_filters_by_confidence(self):
        ctx = SessionContext("sess-1", "agent-1")
        ctx.apply_update(SessionSignalUpdate(
            signal_name="high_conf", value=True, confidence=0.9, source="behavior_inferred",
        ))
        ctx.apply_update(SessionSignalUpdate(
            signal_name="low_conf", value=True, confidence=0.3, source="behavior_inferred",
        ))

        promotable = ctx.promotable_signals(confidence_threshold=0.7)
        assert len(promotable) == 1
        assert promotable[0].signal_name == "high_conf"

    def test_registry_close_with_promotion(self):
        registry = SessionRegistry()
        callback = MagicMock()
        registry.set_promotion_callback(callback)

        session = registry.get_or_create("sess-1", "agent-1")
        session.apply_update(SessionSignalUpdate(
            signal_name="important", value=True, confidence=0.9, source="behavior_inferred",
        ))

        registry.close("sess-1", promote_to_history=True)

        callback.assert_called_once()
        agent_id, signals = callback.call_args[0]
        assert agent_id == "agent-1"
        assert len(signals) == 1
        assert signals[0].signal_name == "important"

    def test_registry_close_without_promotion(self):
        registry = SessionRegistry()
        callback = MagicMock()
        registry.set_promotion_callback(callback)

        registry.get_or_create("sess-1", "agent-1")
        registry.close("sess-1", promote_to_history=False)

        callback.assert_not_called()

    def test_registry_close_no_callback(self):
        registry = SessionRegistry()
        session = registry.get_or_create("sess-1", "agent-1")
        session.apply_update(SessionSignalUpdate(
            signal_name="x", value=1, confidence=0.9, source="agent_declared",
        ))
        # Should not raise even with promote_to_history=True
        registry.close("sess-1", promote_to_history=True)

    def test_close_removes_session(self):
        registry = SessionRegistry()
        registry.get_or_create("sess-1", "agent-1")
        assert registry.active_count() == 1
        registry.close("sess-1")
        assert registry.active_count() == 0
        assert registry.get("sess-1") is None

    def test_close_nonexistent_session(self):
        registry = SessionRegistry()
        # Should not raise
        registry.close("nonexistent")


# ── SessionRegistry ────────────────────────────────────────────────────


class TestSessionRegistry:
    def test_get_or_create_returns_same_session(self):
        registry = SessionRegistry()
        s1 = registry.get_or_create("sess-1", "agent-1")
        s2 = registry.get_or_create("sess-1", "agent-1")
        assert s1 is s2

    def test_get_returns_none_for_unknown(self):
        registry = SessionRegistry()
        assert registry.get("nonexistent") is None

    def test_different_sessions_are_independent(self):
        registry = SessionRegistry()
        s1 = registry.get_or_create("sess-1", "agent-1")
        s2 = registry.get_or_create("sess-2", "agent-2")

        s1.escalation_count = 5
        assert s2.escalation_count == 0

    def test_active_session_ids(self):
        registry = SessionRegistry()
        registry.get_or_create("a", "agent-1")
        registry.get_or_create("b", "agent-2")

        ids = registry.active_session_ids()
        assert set(ids) == {"a", "b"}

    def test_active_count(self):
        registry = SessionRegistry()
        assert registry.active_count() == 0
        registry.get_or_create("s1", "a1")
        assert registry.active_count() == 1
        registry.get_or_create("s2", "a2")
        assert registry.active_count() == 2
        registry.close("s1")
        assert registry.active_count() == 1


# ── Thread Safety ──────────────────────────────────────────────────────


class TestThreadSafety:
    def test_concurrent_session_creation(self):
        registry = SessionRegistry()
        results: list[SessionContext] = []
        errors: list[Exception] = []

        def create_session(session_id: str, agent_id: str):
            try:
                s = registry.get_or_create(session_id, agent_id)
                results.append(s)
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=create_session, args=(f"sess-{i}", f"agent-{i}"))
            for i in range(50)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0
        assert registry.active_count() == 50

    def test_concurrent_signal_updates(self):
        ctx = SessionContext("sess-1", "agent-1")
        errors: list[Exception] = []

        def add_updates(thread_id: int):
            try:
                for i in range(100):
                    ctx.apply_update(SessionSignalUpdate(
                        signal_name=f"signal_{thread_id}_{i}",
                        value=i,
                        confidence=0.5,
                        source="behavior_inferred",
                    ))
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=add_updates, args=(t,))
            for t in range(10)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0
        assert len(ctx.signal_updates) == 1000

    def test_concurrent_get_or_create_same_session(self):
        """Multiple threads creating the same session get the same object."""
        registry = SessionRegistry()
        results: list[SessionContext] = []

        def get_session():
            s = registry.get_or_create("shared-sess", "agent-1")
            results.append(s)

        threads = [threading.Thread(target=get_session) for _ in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All threads should get the same session object
        assert all(r is results[0] for r in results)

    def test_concurrent_close_and_create(self):
        """Concurrent close and create operations don't crash."""
        registry = SessionRegistry()
        errors: list[Exception] = []

        def worker(i: int):
            try:
                sid = f"sess-{i % 10}"
                registry.get_or_create(sid, f"agent-{i}")
                if i % 3 == 0:
                    registry.close(sid)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(100)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0


# ── Runtime Integration (smoke) ────────────────────────────────────────


class TestRuntimeIntegration:
    def test_runtime_has_session_registry(self):
        from nomotic.runtime import GovernanceRuntime
        runtime = GovernanceRuntime()
        assert hasattr(runtime, "session_registry")
        assert isinstance(runtime.session_registry, SessionRegistry)

    def test_evaluate_populates_session_context(self):
        from nomotic.runtime import GovernanceRuntime
        runtime = GovernanceRuntime()

        # Configure scope for agent
        scope_dim = runtime.registry.get("scope_compliance")
        scope_dim.configure_agent_scope("agent-1", {"read"})

        action = _make_action(action_type="read", target="safe")
        context = _make_context()

        runtime.evaluate(action, context)

        # Session context should be populated
        assert context.session_context is not None
        assert isinstance(context.session_context, SessionContext)

    def test_deny_increments_escalation_count(self):
        from nomotic.runtime import GovernanceRuntime
        runtime = GovernanceRuntime()

        # Do not configure scope -> should deny "forbidden" action type
        action = _make_action(action_type="forbidden_action", target="secret")
        context = _make_context()

        verdict = runtime.evaluate(action, context)

        if verdict.verdict in (Verdict.DENY, Verdict.ESCALATE):
            session = runtime.session_registry.get(context.session_id)
            assert session is not None
            assert session.escalation_count >= 1

    def test_session_signals_across_evaluations(self):
        from nomotic.runtime import GovernanceRuntime
        runtime = GovernanceRuntime()

        scope_dim = runtime.registry.get("scope_compliance")
        scope_dim.configure_agent_scope("agent-1", {"read", "write"})

        context = _make_context()

        # First evaluation
        action1 = _make_action(action_type="read", target="data")
        runtime.evaluate(action1, context)

        # Manually add a session signal
        session = runtime.session_registry.get(context.session_id)
        assert session is not None
        session.apply_update(SessionSignalUpdate(
            signal_name="user_intent",
            value="suspicious",
            confidence=0.8,
            source="behavior_inferred",
        ))

        # Second evaluation - session signals should be present
        action2 = _make_action(action_type="read", target="data2")
        runtime.evaluate(action2, context)

        signals = session.current_signals()
        assert signals["user_intent"] == "suspicious"
