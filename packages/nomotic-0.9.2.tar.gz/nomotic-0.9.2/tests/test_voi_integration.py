"""Tests for VOI integration into Tier 3 deliberation flow."""

from nomotic.cost_profile import CONSERVATIVE, PERMISSIVE, CostProfile
from nomotic.human_drift import HumanDriftResult, HumanInteractionProfile
from nomotic.tiers import TierThreeDeliberator
from nomotic.types import Action, AgentContext, DimensionScore, TrustProfile, Verdict
from nomotic.voi import VOIConfig, VOIEngine


def _action() -> Action:
    return Action(agent_id="a", action_type="test")


def _ctx(trust: float = 0.5, observations: int = 100) -> AgentContext:
    return AgentContext(
        agent_id="a",
        trust_profile=TrustProfile(
            agent_id="a",
            overall_trust=trust,
            successful_actions=observations,
            violation_count=0,
        ),
    )


def _uniform_scores(value: float, n: int = 6) -> list[DimensionScore]:
    """All dimensions agree at the same value."""
    names = [
        "scope_compliance", "authority_verification",
        "behavioral_consistency", "ethical_alignment",
        "resource_management", "transparency",
    ]
    return [DimensionScore(dimension_name=names[i % len(names)], score=value) for i in range(n)]


def _polarized_scores() -> list[DimensionScore]:
    """Half dimensions high, half low — maximum disagreement."""
    return [
        DimensionScore(dimension_name="scope_compliance", score=0.9),
        DimensionScore(dimension_name="authority_verification", score=0.9),
        DimensionScore(dimension_name="behavioral_consistency", score=0.9),
        DimensionScore(dimension_name="ethical_alignment", score=0.1),
        DimensionScore(dimension_name="resource_management", score=0.1),
        DimensionScore(dimension_name="transparency", score=0.1),
    ]


def _fatigued_drift_result() -> HumanDriftResult:
    """A HumanDriftResult indicating reviewer fatigue (high approval rate)."""
    baseline = HumanInteractionProfile(reviewer_id="reviewer-1", approval_rate=0.7)
    recent = HumanInteractionProfile(reviewer_id="reviewer-1", approval_rate=0.95)
    return HumanDriftResult(
        reviewer_id="reviewer-1",
        overall_drift=0.6,
        drift_category="severe",
        timing_drift=0.3,
        decision_drift=0.5,
        engagement_drift=0.4,
        throughput_drift=0.2,
        risk_timing_drift=0.3,
        fatigue_score=0.8,
        alerts=["High approval rate suggests fatigue"],
        baseline_profile=baseline,
        recent_profile=recent,
    )


class TestVOIDisabledUnchanged:
    """When enable_voi_escalation=False, Tier 3 behavior is identical to existing logic."""

    def test_low_trust_escalates_without_voi(self):
        tier3 = TierThreeDeliberator()  # No VOI engine
        scores = [DimensionScore(dimension_name="d1", score=0.5)]
        result = tier3.evaluate(_action(), _ctx(trust=0.2), scores, ucs=0.5)
        assert result.decided
        assert result.verdict.verdict == Verdict.ESCALATE
        assert "Low trust" in result.verdict.reasoning

    def test_high_trust_allows_without_voi(self):
        tier3 = TierThreeDeliberator()
        scores = [DimensionScore(dimension_name="d1", score=0.6)]
        result = tier3.evaluate(_action(), _ctx(trust=0.8), scores, ucs=0.55)
        assert result.decided
        assert result.verdict.verdict == Verdict.ALLOW
        assert "High trust" in result.verdict.reasoning


class TestVOILowEntropyNoEscalation:
    """All dimensions agree → low VOI → no escalation."""

    def test_uniform_scores_allow(self):
        engine = VOIEngine()
        tier3 = TierThreeDeliberator(voi_engine=engine)
        # All scores at ~0.5, low entropy
        scores = _uniform_scores(0.5)
        result = tier3.evaluate(_action(), _ctx(trust=0.5), scores, ucs=0.55)
        assert result.decided
        assert result.verdict.verdict == Verdict.ALLOW
        assert "VOI-informed allow" in result.verdict.reasoning
        assert "VOI too low" in result.verdict.reasoning

    def test_uniform_scores_deny_with_conservative_profile(self):
        # Use high trust (low trust_uncertainty) so VOI stays below escalation threshold
        # despite CONSERVATIVE's high cost_sensitivity
        engine = VOIEngine()
        tier3 = TierThreeDeliberator(
            voi_engine=engine,
            cost_profile_accessor=lambda _: CONSERVATIVE,
        )
        scores = _uniform_scores(0.5)
        # High trust (0.85) → trust_uncertainty ~0.15, VOI = 0.40*0 + 0.25*0.15 + 0.35*1.0 = 0.3875
        # But escalation cost with CONSERVATIVE = 0.05 + 0.10 + 0.1 + 0.1 = 0.35
        # VOI 0.3875 > max(0.35, 0.3) → still escalates
        # Need even higher trust or different config
        config = VOIConfig(min_voi_to_escalate=0.5)  # Raise min threshold
        engine = VOIEngine(config=config)
        tier3 = TierThreeDeliberator(
            voi_engine=engine,
            cost_profile_accessor=lambda _: CONSERVATIVE,
        )
        result = tier3.evaluate(_action(), _ctx(trust=0.85), scores, ucs=0.45)
        assert result.decided
        # CONSERVATIVE has false_allow_cost = 1.0 (>= 0.6), UCS 0.45 < 0.5 → DENY
        assert result.verdict.verdict == Verdict.DENY
        assert "high false-allow cost" in result.verdict.reasoning


class TestVOIHighEntropyEscalation:
    """Dimensions disagree → high VOI → escalation."""

    def test_polarized_scores_escalate(self):
        engine = VOIEngine()
        tier3 = TierThreeDeliberator(
            voi_engine=engine,
            cost_profile_accessor=lambda _: CONSERVATIVE,
        )
        scores = _polarized_scores()
        result = tier3.evaluate(_action(), _ctx(trust=0.5), scores, ucs=0.5)
        assert result.decided
        assert result.verdict.verdict == Verdict.ESCALATE
        assert "VOI escalation" in result.verdict.reasoning
        assert "Shift probability" in result.verdict.reasoning
        assert "Disagreement" in result.verdict.reasoning


class TestTrustFloorAlwaysEscalates:
    """Trust below safety floor always escalates regardless of VOI."""

    def test_trust_floor_escalation(self):
        engine = VOIEngine()  # trust_floor defaults to 0.2
        tier3 = TierThreeDeliberator(voi_engine=engine)
        # Low entropy scores — VOI would normally NOT escalate
        scores = _uniform_scores(0.5)
        result = tier3.evaluate(_action(), _ctx(trust=0.15), scores, ucs=0.55)
        assert result.decided
        assert result.verdict.verdict == Verdict.ESCALATE
        assert "below safety floor" in result.verdict.reasoning
        assert "VOI=" in result.verdict.reasoning


class TestHighStakesDenyWhenVOILow:
    """CONSERVATIVE CostProfile, UCS < 0.5, low VOI → DENY."""

    def test_conservative_deny(self):
        # Raise min_voi_to_escalate so VOI doesn't exceed threshold
        config = VOIConfig(min_voi_to_escalate=0.5)
        engine = VOIEngine(config=config)
        tier3 = TierThreeDeliberator(
            voi_engine=engine,
            cost_profile_accessor=lambda _: CONSERVATIVE,
        )
        scores = _uniform_scores(0.5)
        result = tier3.evaluate(_action(), _ctx(trust=0.85), scores, ucs=0.45)
        assert result.decided
        assert result.verdict.verdict == Verdict.DENY
        assert "high false-allow cost" in result.verdict.reasoning
        assert "CRITICAL" in result.verdict.reasoning


class TestLowStakesAllowWhenVOILow:
    """PERMISSIVE CostProfile, UCS < 0.5, low VOI → ALLOW."""

    def test_permissive_allow(self):
        engine = VOIEngine()
        tier3 = TierThreeDeliberator(
            voi_engine=engine,
            cost_profile_accessor=lambda _: PERMISSIVE,
        )
        scores = _uniform_scores(0.5)
        result = tier3.evaluate(_action(), _ctx(trust=0.5), scores, ucs=0.45)
        assert result.decided
        assert result.verdict.verdict == Verdict.ALLOW
        assert "low stakes" in result.verdict.reasoning


class TestVerdictMetadataIncludesVOI:
    """Check verdict.metadata['voi_result'] is present and populated."""

    def test_metadata_present(self):
        engine = VOIEngine()
        tier3 = TierThreeDeliberator(voi_engine=engine)
        scores = _uniform_scores(0.5)
        result = tier3.evaluate(_action(), _ctx(trust=0.5), scores, ucs=0.55)
        assert result.verdict.metadata is not None
        assert "voi_result" in result.verdict.metadata
        voi_data = result.verdict.metadata["voi_result"]
        assert "voi_score" in voi_data
        assert "escalation_cost" in voi_data
        assert "should_escalate" in voi_data
        assert "dimension_entropy" in voi_data
        assert "trust_uncertainty" in voi_data
        assert "cost_sensitivity" in voi_data
        assert "expected_verdict_shift_probability" in voi_data
        assert "dominant_disagreement" in voi_data
        assert "recommended_path" in voi_data

    def test_metadata_absent_without_voi(self):
        tier3 = TierThreeDeliberator()  # No VOI
        scores = [DimensionScore(dimension_name="d1", score=0.5)]
        result = tier3.evaluate(_action(), _ctx(trust=0.8), scores, ucs=0.55)
        assert result.verdict.metadata is None or "voi_result" not in (result.verdict.metadata or {})


class TestReviewerFatigueSuppressesEscalation:
    """Fatigued reviewer inflates escalation cost, suppressing borderline escalation."""

    def test_fatigue_suppresses_borderline(self):
        # Use a config that makes VOI barely exceed cost without fatigue
        # but not with fatigue
        config = VOIConfig(
            min_voi_to_escalate=0.2,
            base_latency_cost=0.05,
            base_attention_cost=0.10,
            reviewer_fatigue_multiplier=2.0,
            reviewer_fatigue_threshold=0.85,
        )
        engine = VOIEngine(config=config)

        # Moderately polarized scores to create moderate entropy
        scores = [
            DimensionScore(dimension_name="scope_compliance", score=0.7),
            DimensionScore(dimension_name="authority_verification", score=0.7),
            DimensionScore(dimension_name="ethical_alignment", score=0.3),
            DimensionScore(dimension_name="resource_management", score=0.3),
        ]

        # First, verify without fatigue → could escalate
        tier3_no_fatigue = TierThreeDeliberator(voi_engine=engine)
        result_no_fatigue = tier3_no_fatigue.evaluate(
            _action(), _ctx(trust=0.5), scores, ucs=0.5,
        )
        # Compute the VOI result directly to understand the boundary
        voi_direct = engine.compute(
            scores=scores,
            trust_profile=_ctx(trust=0.5).trust_profile,
            ucs=0.5,
        )

        # With fatigue — escalation cost doubles
        fatigued = _fatigued_drift_result()
        tier3_fatigued = TierThreeDeliberator(
            voi_engine=engine,
            reviewer_drift_accessor=lambda: fatigued,
        )
        result_fatigued = tier3_fatigued.evaluate(
            _action(), _ctx(trust=0.5), scores, ucs=0.5,
        )

        # The fatigued result should be at least as permissive
        # (either ALLOW/DENY instead of ESCALATE, or same)
        voi_with_fatigue = engine.compute(
            scores=scores,
            trust_profile=_ctx(trust=0.5).trust_profile,
            reviewer_drift=fatigued,
            ucs=0.5,
        )

        # Fatigue should inflate escalation cost
        assert voi_with_fatigue.escalation_cost > voi_direct.escalation_cost

        # If without fatigue it escalated, with fatigue it might not
        if voi_direct.should_escalate and not voi_with_fatigue.should_escalate:
            assert result_fatigued.verdict.verdict != Verdict.ESCALATE


class TestFullRuntimeVOIFlow:
    """End-to-end: create runtime with enable_voi_escalation=True."""

    def test_runtime_voi_flow(self):
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        config = RuntimeConfig(
            enable_voi_escalation=True,
            enable_contracts=True,
            enable_cost_sensitive=True,
            enable_fingerprints=False,
            enable_audit=False,
            enable_contextual_modifier=False,
            enable_workflow_governor=False,
            enable_equity_analysis=False,
            enable_bias_detection=False,
            enable_cross_dimensional=False,
            enable_ethical_reasoning=False,
        )
        runtime = GovernanceRuntime(config=config)

        # Verify the tier_three has VOI engine
        assert runtime.tier_three._voi_engine is not None

        # Register an agent and set up a CONSERVATIVE contract
        from nomotic.contract import generate_contract
        from nomotic.priors import PriorRegistry
        contract = generate_contract(
            agent_id="test-agent",
            archetype="assistant",
            prior_registry=PriorRegistry.with_defaults(),
            cost_profile=CONSERVATIVE.to_dict(),
        )
        runtime.set_contract(contract)

        # Create an action in the ambiguity zone
        action = Action(agent_id="test-agent", action_type="write")
        context = AgentContext(
            agent_id="test-agent",
            trust_profile=TrustProfile(
                agent_id="test-agent",
                overall_trust=0.5,
                successful_actions=50,
            ),
        )

        # Evaluate — should go through VOI-driven Tier 3
        verdict = runtime.evaluate(action, context)
        assert verdict is not None
        assert verdict.tier in (2, 3)  # May be decided at tier 2 or 3 depending on thresholds

    def test_runtime_voi_disabled_backward_compatible(self):
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        config = RuntimeConfig(
            enable_voi_escalation=False,
            enable_fingerprints=False,
            enable_audit=False,
            enable_contextual_modifier=False,
            enable_workflow_governor=False,
            enable_equity_analysis=False,
            enable_bias_detection=False,
            enable_cross_dimensional=False,
            enable_ethical_reasoning=False,
        )
        runtime = GovernanceRuntime(config=config)

        # Verify no VOI engine
        assert runtime.tier_three._voi_engine is None
