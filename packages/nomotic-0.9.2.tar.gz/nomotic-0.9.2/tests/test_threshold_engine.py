"""Tests for dynamic threshold derivation (Ticket 2)."""

from nomotic.cost_profile import CONSERVATIVE, PERMISSIVE, CostProfile
from nomotic.threshold_engine import DerivedThresholds, ThresholdEngine
from nomotic.tiers import TierTwoEvaluator
from nomotic.types import Action, AgentContext, DimensionScore, TrustProfile, Verdict


def _ctx(agent_id: str = "a", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


def _action(agent_id: str = "a") -> Action:
    return Action(agent_id=agent_id, action_type="test")


class TestStaticFallback:
    def test_no_cost_profile_returns_defaults(self):
        engine = ThresholdEngine(default_allow=0.7, default_deny=0.3)
        result = engine.derive("agent-1", cost_profile=None)
        assert result.allow_threshold == 0.7
        assert result.deny_threshold == 0.3
        assert result.source == "static_default"
        assert result.cost_profile_summary == {}
        assert abs(result.ambiguity_zone_width - 0.4) < 1e-10


class TestConservativeProfile:
    def test_conservative_profile_lowers_allow_threshold(self):
        engine = ThresholdEngine()
        result = engine.derive("agent-1", CONSERVATIVE)
        # CONSERVATIVE: false_allow=1.0 (CRITICAL), false_deny=0.1 (LOW)
        # theta = 0.1 / (0.1 + 1.0) = 0.0909 -> clamped to 0.15
        assert result.allow_threshold < 0.7
        assert result.source == "cost_profile"
        assert result.cost_profile_summary["false_allow"] == 1.0
        assert result.cost_profile_summary["false_deny"] == 0.1


class TestPermissiveProfile:
    def test_permissive_profile_raises_allow_threshold(self):
        engine = ThresholdEngine()
        result = engine.derive("agent-1", PERMISSIVE)
        # PERMISSIVE: false_allow=0.1 (LOW), false_deny=0.6 (HIGH)
        # theta = 0.6 / (0.6 + 0.1) = 0.857
        assert result.allow_threshold > 0.5
        assert result.source == "cost_profile"


class TestSmoothing:
    def test_smoothing_clamps_large_shift(self):
        engine = ThresholdEngine(max_shift_per_cycle=0.10)
        # Seed with a first derivation at 0.7
        engine.derive("agent-1", CostProfile(false_allow_cost=0.3, false_deny_cost=0.3))
        prev = engine.get_previous("agent-1")
        assert prev is not None
        prev_allow = prev.allow_threshold

        # Now derive with CONSERVATIVE which wants allow ~0.15
        result = engine.derive("agent-1", CONSERVATIVE)
        # Should be clamped: prev_allow - 0.10
        assert result.allow_threshold >= prev_allow - 0.10 - 0.001
        assert result.source == "smoothed"

    def test_smoothing_convergence(self):
        engine = ThresholdEngine(max_shift_per_cycle=0.10)
        # Start from balanced
        engine.derive("agent-1", CostProfile(false_allow_cost=0.3, false_deny_cost=0.3))

        # Target: CONSERVATIVE (allow ~0.15)
        target_allow = CONSERVATIVE.optimal_allow_threshold()
        for _ in range(20):
            result = engine.derive("agent-1", CONSERVATIVE)

        # After enough iterations, should converge close to target
        assert abs(result.allow_threshold - target_allow) < 0.02


class TestZoneMultiplierEffect:
    def test_zone_multiplier_changes_thresholds(self):
        engine = ThresholdEngine()
        base = CostProfile(false_allow_cost=0.5, false_deny_cost=0.5, zone_multiplier=1.0)
        doubled = CostProfile(false_allow_cost=0.5, false_deny_cost=0.5, zone_multiplier=2.0)

        result_base = engine.derive("agent-base", base)
        result_doubled = engine.derive("agent-doubled", doubled)

        # zone_multiplier affects effective costs, which can change deny threshold
        # (allow threshold may remain the same if the ratio stays equal)
        assert result_base.cost_profile_summary["zone_multiplier"] == 1.0
        assert result_doubled.cost_profile_summary["zone_multiplier"] == 2.0
        # With equal base costs, ratio stays same but zone width changes
        # because max_cost changes (0.5 vs 1.0), affecting deny threshold
        assert result_base.deny_threshold != result_doubled.deny_threshold


class TestAmbiguityZoneWidth:
    def test_critical_costs_narrow_zone(self):
        engine = ThresholdEngine()
        critical = CostProfile(false_allow_cost=1.0, false_deny_cost=1.0)
        low = CostProfile(false_allow_cost=0.1, false_deny_cost=0.1)

        result_critical = engine.derive("agent-critical", critical)
        result_low = engine.derive("agent-low", low)

        assert result_critical.ambiguity_zone_width < result_low.ambiguity_zone_width


class TestTierTwoDynamicThresholds:
    def test_dynamic_allow_changes_verdict(self):
        tier2 = TierTwoEvaluator(allow_threshold=0.7, deny_threshold=0.3)
        scores = [DimensionScore(dimension_name="d1", score=0.5)]
        # With static threshold 0.7, UCS=0.5 would be ambiguous
        result_static = tier2.evaluate(_action(), _ctx(), scores, ucs=0.5)
        assert not result_static.decided

        # With dynamic_allow=0.4, UCS=0.5 should ALLOW
        result_dynamic = tier2.evaluate(
            _action(), _ctx(), scores, ucs=0.5,
            dynamic_allow=0.4, dynamic_deny=0.1,
        )
        assert result_dynamic.decided
        assert result_dynamic.verdict.verdict == Verdict.ALLOW
        assert "cost-derived" in result_dynamic.verdict.reasoning


class TestTierTwoBackwardCompatible:
    def test_no_dynamic_thresholds_unchanged(self):
        tier2 = TierTwoEvaluator(allow_threshold=0.7, deny_threshold=0.3)
        scores = [DimensionScore(dimension_name="d1", score=0.9)]

        # ALLOW case
        result = tier2.evaluate(_action(), _ctx(), scores, ucs=0.85)
        assert result.decided
        assert result.verdict.verdict == Verdict.ALLOW
        assert "static" in result.verdict.reasoning

        # DENY case
        result = tier2.evaluate(_action(), _ctx(), scores, ucs=0.2)
        assert result.decided
        assert result.verdict.verdict == Verdict.DENY
        assert "static" in result.verdict.reasoning

        # Ambiguous case
        result = tier2.evaluate(_action(), _ctx(), scores, ucs=0.5)
        assert not result.decided


class TestRuntimeIntegration:
    def test_cost_sensitive_changes_threshold(self):
        from nomotic.contract import BehavioralContract, ContractStore
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        store = ContractStore()
        contract = BehavioralContract(
            contract_id="c1",
            version=1,
            agent_id="agent-1",
            created_at=0.0,
            cost_profile=CONSERVATIVE.to_dict(),
        )
        store.store(contract)

        config = RuntimeConfig(
            enable_cost_sensitive=True,
            enable_contracts=True,
            contract_store=store,
            enable_fingerprints=False,
            enable_audit=False,
            enable_contextual_modifier=False,
            enable_workflow_governor=False,
            enable_equity_analysis=False,
            enable_bias_detection=False,
            enable_ethical_reasoning=False,
            enable_cross_dimensional=False,
        )
        runtime = GovernanceRuntime(config=config)
        assert runtime._threshold_engine is not None

    def test_runtime_without_cost_sensitive(self):
        from nomotic.contract import BehavioralContract, ContractStore
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        store = ContractStore()
        contract = BehavioralContract(
            contract_id="c1",
            version=1,
            agent_id="agent-1",
            created_at=0.0,
            cost_profile=CONSERVATIVE.to_dict(),
        )
        store.store(contract)

        config = RuntimeConfig(
            enable_cost_sensitive=False,
            enable_contracts=True,
            contract_store=store,
            enable_fingerprints=False,
            enable_audit=False,
            enable_contextual_modifier=False,
            enable_workflow_governor=False,
            enable_equity_analysis=False,
            enable_bias_detection=False,
            enable_ethical_reasoning=False,
            enable_cross_dimensional=False,
        )
        runtime = GovernanceRuntime(config=config)
        assert runtime._threshold_engine is None


class TestDerivedThresholdsToDict:
    def test_to_dict(self):
        dt = DerivedThresholds(
            allow_threshold=0.5,
            deny_threshold=0.2,
            ambiguity_zone_width=0.3,
            source="cost_profile",
            cost_profile_summary={"false_allow": 1.0, "false_deny": 0.1, "zone_multiplier": 1.0},
        )
        d = dt.to_dict()
        assert d["allow_threshold"] == 0.5
        assert d["source"] == "cost_profile"
        assert d["cost_profile_summary"]["false_allow"] == 1.0


class TestThresholdEngineReset:
    def test_reset_clears_previous(self):
        engine = ThresholdEngine()
        engine.derive("agent-1", CONSERVATIVE)
        assert engine.get_previous("agent-1") is not None
        engine.reset("agent-1")
        assert engine.get_previous("agent-1") is None

    def test_reset_nonexistent_is_noop(self):
        engine = ThresholdEngine()
        engine.reset("no-such-agent")  # should not raise
