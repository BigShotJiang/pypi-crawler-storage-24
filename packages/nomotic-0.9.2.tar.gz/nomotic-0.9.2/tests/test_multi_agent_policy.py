"""Tests for multi-agent policy coordination."""

from __future__ import annotations

import pytest

from nomotic.cost_profile import BALANCED, CONSERVATIVE, CostProfile
from nomotic.fleet_monitor import FleetBehavioralMonitor, FleetDriftAlert
from nomotic.policy_optimizer import (
    InterventionPolicy,
    OptimizerConfig,
    PolicyOptimizer,
)


@pytest.fixture()
def optimizer() -> PolicyOptimizer:
    """Optimizer with small rollout count for speed."""
    config = OptimizerConfig(n_rollouts=30, timeout_seconds=10.0, horizon=40)
    return PolicyOptimizer(config=config)


# ── Shared helpers ────────────────────────────────────────────────────


def _make_chain_data(
    agents: list[str],
    drifts: list[float],
    velocities: list[float] | None = None,
    archetype: str = "operations-coordinator",
) -> tuple[dict[str, float], dict[str, float], dict[str, str], dict[str, CostProfile]]:
    """Build per-agent dicts from parallel lists."""
    n = len(agents)
    vels = velocities or [0.01] * n
    return (
        dict(zip(agents, drifts)),
        dict(zip(agents, vels)),
        {a: archetype for a in agents},
        {a: BALANCED for a in agents},
    )


# ── Tests ─────────────────────────────────────────────────────────────


class TestChainRootIntervention:
    """3-agent chain where root intervention is cheaper than all three."""

    def test_chain_root_intervention(self, optimizer: PolicyOptimizer) -> None:
        chain = ["agent-A", "agent-B", "agent-C"]
        drifts, vels, archetypes, profiles = _make_chain_data(
            chain,
            drifts=[0.45, 0.35, 0.25],
            velocities=[0.02, 0.015, 0.01],
        )

        result = optimizer.optimize_chain(
            chain=chain,
            current_drifts=drifts,
            velocities=vels,
            archetypes=archetypes,
            cost_profiles=profiles,
        )

        assert set(result.keys()) == set(chain)

        # Root should have a real intervention (not no_op)
        root_policy = result["agent-A"]
        assert isinstance(root_policy, InterventionPolicy)
        assert root_policy.expected_total_cost >= 0.0

        # Downstream agents should either have no_op (coordinated) or
        # their own policy (independent). Either way, all are covered.
        for agent in chain:
            assert agent in result
            assert isinstance(result[agent], InterventionPolicy)


class TestChainIndependentCheaper:
    """Chain where root intervention is expensive; independent wins."""

    def test_chain_independent_cheaper(self, optimizer: PolicyOptimizer) -> None:
        chain = ["agent-X", "agent-Y", "agent-Z"]
        # Low drift everywhere — individual no_ops will be very cheap
        drifts, vels, archetypes, profiles = _make_chain_data(
            chain,
            drifts=[0.02, 0.02, 0.02],
            velocities=[0.0, 0.0, 0.0],
        )

        result = optimizer.optimize_chain(
            chain=chain,
            current_drifts=drifts,
            velocities=vels,
            archetypes=archetypes,
            cost_profiles=profiles,
        )

        assert set(result.keys()) == set(chain)
        # With very low drift, independent policies (likely no_op) should win
        for agent in chain:
            assert isinstance(result[agent], InterventionPolicy)


class TestCorrelatedUpstreamFix:
    """5 agents with correlated drift; upstream fix is cheaper."""

    def test_correlated_upstream_fix(self, optimizer: PolicyOptimizer) -> None:
        agents = [f"corr-{i}" for i in range(5)]
        drifts = {a: 0.40 for a in agents}
        vels = {a: 0.02 for a in agents}
        archetypes = {a: "financial-analyst" for a in agents}
        profiles = {a: CONSERVATIVE for a in agents}

        # Set upstream_fix_cost to be small relative to 5 individual interventions
        result = optimizer.optimize_correlated(
            agents=agents,
            current_drifts=drifts,
            velocities=vels,
            archetypes=archetypes,
            cost_profiles=profiles,
            upstream_fix_cost=0.05,
        )

        assert set(result.keys()) == set(agents)
        # With a very cheap upstream fix, all agents should get upstream_fix
        for agent in agents:
            assert result[agent].strategy_name == "upstream_fix"
            assert "upstream" in result[agent].conditions.get("action", "").lower()

    def test_correlated_independent_when_upstream_expensive(
        self, optimizer: PolicyOptimizer,
    ) -> None:
        agents = [f"corr-{i}" for i in range(5)]
        drifts = {a: 0.05 for a in agents}
        vels = {a: 0.0 for a in agents}
        archetypes = {a: "customer-experience" for a in agents}
        profiles = {a: BALANCED for a in agents}

        # Set upstream fix cost extremely high
        result = optimizer.optimize_correlated(
            agents=agents,
            current_drifts=drifts,
            velocities=vels,
            archetypes=archetypes,
            cost_profiles=profiles,
            upstream_fix_cost=100.0,
        )

        assert set(result.keys()) == set(agents)
        # With expensive upstream fix, independent policies should win
        for agent in agents:
            assert result[agent].strategy_name != "upstream_fix"


class TestFlagGating:
    """Without coordinated drift detection, coordination doesn't activate."""

    def test_flag_gating(self, optimizer: PolicyOptimizer) -> None:
        monitor = FleetBehavioralMonitor()

        # Create a fleet-scope alert (not coordinated or correlated)
        alert = FleetDriftAlert(
            alert_id="test-fleet-1",
            scope="fleet",
            severity="moderate",
            timestamp=1000.0,
            fleet_drift_score=0.25,
        )

        result = monitor.on_alert_with_policy_coordination(
            alert=alert,
            optimizer=optimizer,
            current_drifts={"a": 0.3},
            velocities={"a": 0.01},
            archetypes={"a": "operations-coordinator"},
            cost_profiles={"a": BALANCED},
        )

        # Fleet-scope alerts should NOT trigger coordination
        assert result is None

    def test_coordinated_alert_triggers_chain(
        self, optimizer: PolicyOptimizer,
    ) -> None:
        monitor = FleetBehavioralMonitor()

        alert = FleetDriftAlert(
            alert_id="test-coord-1",
            scope="coordinated",
            severity="high",
            timestamp=1000.0,
            propagation_chain=["root", "mid", "leaf"],
        )

        agents = ["root", "mid", "leaf"]
        drifts = {a: 0.35 for a in agents}
        vels = {a: 0.01 for a in agents}
        archetypes = {a: "operations-coordinator" for a in agents}
        profiles = {a: BALANCED for a in agents}

        result = monitor.on_alert_with_policy_coordination(
            alert=alert,
            optimizer=optimizer,
            current_drifts=drifts,
            velocities=vels,
            archetypes=archetypes,
            cost_profiles=profiles,
        )

        assert result is not None
        assert set(result.keys()) == set(agents)

    def test_correlated_alert_triggers_optimization(
        self, optimizer: PolicyOptimizer,
    ) -> None:
        monitor = FleetBehavioralMonitor()

        alert = FleetDriftAlert(
            alert_id="test-corr-1",
            scope="correlated",
            severity="moderate",
            timestamp=1000.0,
            affected_agents=["a1", "a2", "a3"],
        )

        agents = ["a1", "a2", "a3"]
        drifts = {a: 0.30 for a in agents}
        vels = {a: 0.01 for a in agents}
        archetypes = {a: "customer-experience" for a in agents}
        profiles = {a: BALANCED for a in agents}

        result = monitor.on_alert_with_policy_coordination(
            alert=alert,
            optimizer=optimizer,
            current_drifts=drifts,
            velocities=vels,
            archetypes=archetypes,
            cost_profiles=profiles,
        )

        assert result is not None
        assert set(result.keys()) == set(agents)


class TestSingleAgentFallback:
    """Chain of length 1 falls back to single-agent optimize()."""

    def test_single_agent_fallback(self, optimizer: PolicyOptimizer) -> None:
        chain = ["solo-agent"]
        drifts = {"solo-agent": 0.25}
        vels = {"solo-agent": 0.01}
        archetypes = {"solo-agent": "sales-agent"}
        profiles = {"solo-agent": BALANCED}

        result = optimizer.optimize_chain(
            chain=chain,
            current_drifts=drifts,
            velocities=vels,
            archetypes=archetypes,
            cost_profiles=profiles,
        )

        assert set(result.keys()) == {"solo-agent"}
        policy = result["solo-agent"]
        assert isinstance(policy, InterventionPolicy)
        # Should behave like a normal single-agent optimization
        assert policy.expected_total_cost >= 0.0
