"""Tests for framework integrations — CrewAI, LangGraph/LangChain, and AutoGen adapters."""

import sys
from unittest.mock import MagicMock, patch

import pytest

from nomotic.authority import CertificateAuthority
from nomotic.integrations.autogen_adapter import GovernedAutoGenAgent
from nomotic.keys import SigningKey
from nomotic.internal.sandbox import AgentConfig, save_agent_config
from nomotic.store import FileCertificateStore


def _setup_agent(
    tmp_path,
    agent_id: str = "TestBot",
    actions: list[str] | None = None,
    boundaries: list[str] | None = None,
) -> str:
    """Create a certificate and config for an agent in tmp_path.

    Returns the certificate ID.
    """
    sk, _vk = SigningKey.generate()
    store = FileCertificateStore(tmp_path)
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    cert, _agent_sk = ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization="test-org",
        zone_path="global",
        owner="test-owner",
    )

    if actions is None:
        actions = ["read", "write", "query"]
    config = AgentConfig(
        agent_id=agent_id,
        actions=actions,
        boundaries=boundaries or [],
    )
    save_agent_config(tmp_path, config)

    return cert.certificate_id


# ── Mock tool classes ────────────────────────────────────────────────


class MockCrewAITool:
    """Minimal mock of a CrewAI Tool with _run method."""

    def __init__(self, name: str, return_value: str = "ok"):
        self.name = name
        self._return_value = return_value

    def _run(self, *args, **kwargs):
        return self._return_value


class MockCrewAIToolWithRun:
    """Mock CrewAI tool that uses .run instead of ._run."""

    def __init__(self, name: str, return_value: str = "ok"):
        self.name = name
        self._return_value = return_value

    def run(self, *args, **kwargs):
        return self._return_value


class MockLangChainTool:
    """Minimal mock of a LangChain BaseTool."""

    def __init__(self, name: str, return_value: str = "ok"):
        self.name = name
        self._return_value = return_value

    def _run(self, query: str, **kwargs) -> str:
        return self._return_value


# ── CrewAI Adapter Tests ─────────────────────────────────────────────


class TestCrewAIAdapter:
    def test_govern_tools_returns_same_count(self, tmp_path):
        """Wrapping tools preserves the number of tools."""
        _setup_agent(tmp_path, "TestBot", actions=["web_search", "read_file"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAITool("web_search"), MockCrewAITool("read_file")]
        governed = govern_crewai_tools("TestBot", tools, base_dir=str(tmp_path))
        assert len(governed) == 2

    def test_allowed_tool_executes(self, tmp_path):
        """Tool function runs when governance approves."""
        _setup_agent(tmp_path, "TestBot", actions=["web_search"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAITool("web_search", return_value="search results")]
        governed = govern_crewai_tools("TestBot", tools, base_dir=str(tmp_path))

        result = governed[0]._run("test query")
        assert result == "search results"

    def test_denied_tool_returns_message(self, tmp_path):
        """Denied tool returns a governance denial message."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAITool("delete_everything", return_value="destroyed")]
        governed = govern_crewai_tools("TestBot", tools, base_dir=str(tmp_path))

        result = governed[0]._run("all-data")
        assert "[GOVERNANCE DENIED]" in result

    def test_wraps_run_method_fallback(self, tmp_path):
        """Falls back to .run when ._run is not available."""
        _setup_agent(tmp_path, "TestBot", actions=["web_search"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAIToolWithRun("web_search", return_value="results")]
        governed = govern_crewai_tools("TestBot", tools, base_dir=str(tmp_path))

        result = governed[0].run("query")
        assert result == "results"

    def test_target_from_kwargs(self, tmp_path):
        """Target is extracted from keyword arguments."""
        _setup_agent(tmp_path, "TestBot", actions=["web_search"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAITool("web_search", return_value="found it")]
        governed = govern_crewai_tools("TestBot", tools, base_dir=str(tmp_path))

        # The "query" kwarg should be picked up as the governance target
        result = governed[0]._run(query="nomotic governance")
        assert result == "found it"

    def test_preserves_tool_name(self, tmp_path):
        """Tool name attribute is preserved after wrapping."""
        _setup_agent(tmp_path, "TestBot", actions=["my_tool"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAITool("my_tool")]
        governed = govern_crewai_tools("TestBot", tools, base_dir=str(tmp_path))

        assert governed[0].name == "my_tool"

    def test_test_mode(self, tmp_path):
        """test_mode parameter is passed through to executor."""
        _setup_agent(tmp_path, "TestBot", actions=["web_search"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAITool("web_search", return_value="ok")]
        # Should not raise — test_mode uses simulated trust
        governed = govern_crewai_tools(
            "TestBot", tools, base_dir=str(tmp_path), test_mode=True
        )
        result = governed[0]._run("test")
        assert isinstance(result, str)


# ── LangGraph Adapter Tests ──────────────────────────────────────────


class TestLangGraphAdapter:
    def test_governance_node_returns_state(self, tmp_path):
        """Governance node returns state with governance_result key."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        from nomotic.integrations.langgraph_adapter import governance_node

        node_fn = governance_node("TestBot", base_dir=str(tmp_path))
        state = {"pending_action": "read", "pending_target": "test_db"}
        result = node_fn(state)

        assert "governance_result" in result
        gov = result["governance_result"]
        assert "allowed" in gov
        assert "verdict" in gov
        assert "reason" in gov
        assert "ucs" in gov
        assert "trust" in gov

    def test_governance_node_allowed(self, tmp_path):
        """Governance node allows actions within scope."""
        _setup_agent(tmp_path, "TestBot", actions=["read_file"])
        from nomotic.integrations.langgraph_adapter import governance_node

        node_fn = governance_node("TestBot", base_dir=str(tmp_path))
        state = {"pending_action": "read_file", "pending_target": "report.csv"}
        result = node_fn(state)

        assert result["governance_result"]["allowed"] is True
        assert result["governance_result"]["verdict"] == "ALLOW"

    def test_governance_node_denied(self, tmp_path):
        """Governance node denies actions outside scope."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        from nomotic.integrations.langgraph_adapter import governance_node

        node_fn = governance_node("TestBot", base_dir=str(tmp_path))
        state = {"pending_action": "delete_database", "pending_target": "production"}
        result = node_fn(state)

        assert result["governance_result"]["allowed"] is False

    def test_governance_node_custom_keys(self, tmp_path):
        """Custom state keys are used when specified."""
        _setup_agent(tmp_path, "TestBot", actions=["query"])
        from nomotic.integrations.langgraph_adapter import governance_node

        node_fn = governance_node(
            "TestBot",
            base_dir=str(tmp_path),
            action_key="my_action",
            target_key="my_target",
            result_key="my_result",
        )
        state = {"my_action": "query", "my_target": "customers"}
        result = node_fn(state)

        assert "my_result" in result

    def test_route_on_governance_allow(self):
        """route_on_governance returns 'execute' when allowed."""
        from nomotic.integrations.langgraph_adapter import route_on_governance

        state = {"governance_result": {"allowed": True}}
        assert route_on_governance(state) == "execute"

    def test_route_on_governance_deny(self):
        """route_on_governance returns 'denied' when not allowed."""
        from nomotic.integrations.langgraph_adapter import route_on_governance

        state = {"governance_result": {"allowed": False}}
        assert route_on_governance(state) == "denied"

    def test_route_on_governance_missing_result(self):
        """route_on_governance defaults to 'denied' when result is missing."""
        from nomotic.integrations.langgraph_adapter import route_on_governance

        state = {}
        assert route_on_governance(state) == "denied"

    def test_route_on_governance_custom_key(self):
        """route_on_governance uses custom result key."""
        from nomotic.integrations.langgraph_adapter import route_on_governance

        state = {"my_gov": {"allowed": True}}
        assert route_on_governance(state, result_key="my_gov") == "execute"


# ── LangChain Tool Wrapping Tests ────────────────────────────────────


class TestLangChainAdapter:
    def test_govern_tools_returns_same_count(self, tmp_path):
        """Wrapping tools preserves the number of tools."""
        _setup_agent(tmp_path, "TestBot", actions=["search", "lookup"])
        from nomotic.integrations.langgraph_adapter import govern_langchain_tools

        tools = [MockLangChainTool("search"), MockLangChainTool("lookup")]
        governed = govern_langchain_tools("TestBot", tools, base_dir=str(tmp_path))
        assert len(governed) == 2

    def test_allowed_tool_executes(self, tmp_path):
        """LangChain tool runs when governance approves."""
        _setup_agent(tmp_path, "TestBot", actions=["search"])
        from nomotic.integrations.langgraph_adapter import govern_langchain_tools

        tools = [MockLangChainTool("search", return_value="found results")]
        governed = govern_langchain_tools("TestBot", tools, base_dir=str(tmp_path))

        result = governed[0]._run("test query")
        assert result == "found results"

    def test_denied_tool_returns_message(self, tmp_path):
        """Denied LangChain tool returns governance message."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        from nomotic.integrations.langgraph_adapter import govern_langchain_tools

        tools = [MockLangChainTool("nuke_server", return_value="boom")]
        governed = govern_langchain_tools("TestBot", tools, base_dir=str(tmp_path))

        result = governed[0]._run("production")
        assert "[GOVERNANCE DENIED]" in result

    def test_preserves_tool_name(self, tmp_path):
        """Tool name is preserved after wrapping."""
        _setup_agent(tmp_path, "TestBot", actions=["search"])
        from nomotic.integrations.langgraph_adapter import govern_langchain_tools

        tools = [MockLangChainTool("search")]
        governed = govern_langchain_tools("TestBot", tools, base_dir=str(tmp_path))

        assert governed[0].name == "search"


# ── AutoGen Adapter Tests ────────────────────────────────────────────


def _make_autogen_mock(
    function_map: dict | None = None,
) -> tuple[MagicMock, MagicMock]:
    """Return (mock_autogen_module, mock_agent_instance) with a fake AssistantAgent."""
    mock_agent = MagicMock()
    mock_agent.function_map = dict(function_map) if function_map else {}

    mock_autogen = MagicMock()
    mock_autogen.AssistantAgent.return_value = mock_agent
    return mock_autogen, mock_agent


class TestAutoGenAdapter:
    def test_import_without_autogen(self):
        """Module imports successfully even without AutoGen installed."""
        assert GovernedAutoGenAgent is not None

    def test_init_raises_without_autogen(self, tmp_path):
        """GovernedAutoGenAgent raises ImportError if autogen not installed."""
        _setup_agent(tmp_path, "TestBot")

        with pytest.raises(ImportError, match="AutoGen is required"):
            GovernedAutoGenAgent(
                name="test",
                nomotic_agent_id="TestBot",
                base_dir=str(tmp_path),
            )

    def test_construction_with_mocked_autogen(self, tmp_path):
        """GovernedAutoGenAgent constructs successfully when autogen is mocked."""
        _setup_agent(tmp_path, "TestBot", actions=["search"])
        mock_autogen, mock_agent = _make_autogen_mock()

        with patch.dict(sys.modules, {"autogen": mock_autogen}):
            agent = GovernedAutoGenAgent(
                name="test-agent",
                nomotic_agent_id="TestBot",
                base_dir=str(tmp_path),
            )

        mock_autogen.AssistantAgent.assert_called_once_with(name="test-agent")
        assert agent.agent is mock_agent

    def test_agent_property_returns_underlying_agent(self, tmp_path):
        """The .agent property exposes the underlying AutoGen agent."""
        _setup_agent(tmp_path, "TestBot", actions=["search"])
        mock_autogen, mock_agent = _make_autogen_mock()

        with patch.dict(sys.modules, {"autogen": mock_autogen}):
            gov_agent = GovernedAutoGenAgent(
                name="test-agent",
                nomotic_agent_id="TestBot",
                base_dir=str(tmp_path),
            )

        assert gov_agent.agent is mock_agent

    def test_govern_function_allowed_returns_result_data(self, tmp_path):
        """Governed function returns the tool's return value when governance allows."""
        _setup_agent(tmp_path, "TestBot", actions=["search"])
        original_fn = MagicMock(return_value="search results")
        mock_autogen, _ = _make_autogen_mock(function_map={"search": original_fn})

        with patch.dict(sys.modules, {"autogen": mock_autogen}):
            gov_agent = GovernedAutoGenAgent(
                name="test-agent",
                nomotic_agent_id="TestBot",
                base_dir=str(tmp_path),
            )

        governed_fn = gov_agent.agent.function_map["search"]
        result = governed_fn("query-target")

        assert result == "search results"
        original_fn.assert_called_once_with("query-target")

    def test_govern_function_denied_returns_denial_message(self, tmp_path):
        """Governed function returns a denial message and does not call the tool."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])  # "delete_all" not in scope
        original_fn = MagicMock(return_value="deleted everything")
        mock_autogen, _ = _make_autogen_mock(function_map={"delete_all": original_fn})

        with patch.dict(sys.modules, {"autogen": mock_autogen}):
            gov_agent = GovernedAutoGenAgent(
                name="test-agent",
                nomotic_agent_id="TestBot",
                base_dir=str(tmp_path),
            )

        governed_fn = gov_agent.agent.function_map["delete_all"]
        result = governed_fn("database")

        assert "[GOVERNANCE DENIED]" in result
        original_fn.assert_not_called()

    def test_wrap_function_map_preserves_all_keys(self, tmp_path):
        """All functions in the original function_map are wrapped."""
        _setup_agent(tmp_path, "TestBot", actions=["fn_a", "fn_b", "fn_c"])
        mock_autogen, _ = _make_autogen_mock(function_map={
            "fn_a": MagicMock(return_value="a"),
            "fn_b": MagicMock(return_value="b"),
            "fn_c": MagicMock(return_value="c"),
        })

        with patch.dict(sys.modules, {"autogen": mock_autogen}):
            gov_agent = GovernedAutoGenAgent(
                name="test-agent",
                nomotic_agent_id="TestBot",
                base_dir=str(tmp_path),
            )

        assert set(gov_agent.agent.function_map.keys()) == {"fn_a", "fn_b", "fn_c"}

    def test_govern_function_target_from_kwargs(self, tmp_path):
        """Target falls back to empty string when no positional args are given."""
        _setup_agent(tmp_path, "TestBot", actions=["search"])
        original_fn = MagicMock(return_value="results")
        mock_autogen, _ = _make_autogen_mock(function_map={"search": original_fn})

        with patch.dict(sys.modules, {"autogen": mock_autogen}):
            gov_agent = GovernedAutoGenAgent(
                name="test-agent",
                nomotic_agent_id="TestBot",
                base_dir=str(tmp_path),
            )

        governed_fn = gov_agent.agent.function_map["search"]
        result = governed_fn(query="keyword")

        assert result == "results"
        original_fn.assert_called_once_with(query="keyword")

    def test_empty_function_map_wraps_cleanly(self, tmp_path):
        """Agent with no tools wraps cleanly — function_map remains empty."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        mock_autogen, _ = _make_autogen_mock(function_map={})

        with patch.dict(sys.modules, {"autogen": mock_autogen}):
            gov_agent = GovernedAutoGenAgent(
                name="test-agent",
                nomotic_agent_id="TestBot",
                base_dir=str(tmp_path),
            )

        assert gov_agent.agent.function_map == {}


# ── Integration Import Tests ─────────────────────────────────────────


class TestIntegrationImports:
    def test_import_crewai_adapter(self):
        """CrewAI adapter public functions are importable."""
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        assert govern_crewai_tools is not None

    def test_import_langgraph_adapter(self):
        """LangGraph adapter public functions are importable."""
        from nomotic.integrations.langgraph_adapter import (
            governance_node,
            govern_langchain_tools,
            route_on_governance,
        )

        assert governance_node is not None
        assert route_on_governance is not None
        assert govern_langchain_tools is not None

    def test_import_autogen_adapter(self):
        """AutoGen adapter public class is importable."""
        assert GovernedAutoGenAgent is not None

    def test_integrations_init_imports(self):
        """Integrations package __init__ is importable."""
        import nomotic.integrations

        assert nomotic.integrations is not None
