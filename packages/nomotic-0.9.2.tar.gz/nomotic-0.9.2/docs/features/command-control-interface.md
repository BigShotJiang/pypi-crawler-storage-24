---
sidebar_label: Command & Control Interface
title: Behavioral Command & Control Interface
---

# Behavioral Command & Control Interface

The Behavioral Command & Control Interface adds active steering to Nomotic's governance model. Through v0.6.0, operators configure governance rules, deploy agents, and observe outcomes. The Control Plane adds the missing third mode: **operators push behavioral state changes into the fleet in real time**.

This is the feature that transforms Nomotic from "evaluator" into the active steering wheel for agent behavior at runtime. The control plane metaphor becomes literal.

## Why Active Steering

Configuration and observation are necessary but insufficient for production fleet management. When a team of agents begins drifting in a coordinated pattern, operators need to respond immediately rather than updating configuration files and waiting for the next evaluation cycle. When a compliance incident requires isolating a subset of agents, operators need a quarantine mechanism that takes effect on the next evaluation, not the next deployment.

The Command & Control Interface provides this capability through **declarative behavioral directives** that target agents by ID, archetype, team, drift status, or any combination.

## Directive Types

| Directive | Purpose | Effect |
|---|---|---|
| `enforce` | Push a temporary invariant | Adds invariant constraints to targeted agents |
| `quarantine` | Isolate agents for review | Forces ESCALATE on all evaluations |
| `release` | Remove quarantine | Restores normal evaluation |
| `tighten` | Reduce drift thresholds | Multiplies thresholds by a factor (< 1.0 = stricter) |
| `relax` | Remove tightening | Restores original thresholds |
| `re_anchor` | Reset semantic grounding | Re-anchors a specific instruction term |
| `broadcast_reminder` | Re-assert contract compliance | Advisory signal to drifting agents |

## How It Works

### Issuing Directives

Every directive follows the same lifecycle:

1. **Create** the directive with a type, operator identity, and targeting criteria
2. **Resolve** targets to specific agent IDs
3. **Apply** the behavioral state change
4. **Record** the directive in provenance with full attribution
5. **Expire** automatically when duration elapses (if set)

### Targeting

Directives can target agents through flexible criteria, applied as intersection filters:

- **By agent ID**: Target specific agents directly
- **By archetype**: Target all agents of a given archetype (e.g., `finance-agent`)
- **By team**: Target agents belonging to a team (from contract scope metadata)
- **By drift status**: Target agents currently drifting (`drifting` = moderate or above, `critical` = critical only)
- **Combined**: Multiple criteria are AND-combined to narrow the target set

### Quarantine

The most powerful directive. When an agent is quarantined, the runtime's `evaluate()` method returns `ESCALATE` immediately, before any dimension evaluation occurs. This is a hard stop that routes all actions through human review.

```python
from nomotic.control_plane import BehavioralDirective

directive = BehavioralDirective.create(
    "quarantine",
    issued_by="ops@acme.com",
    target_agents=["agent-finance-1", "agent-finance-2"],
    reason="Coordinated drift detected in finance team",
    duration_seconds=14400,  # 4 hours
)
result = runtime.issue_directive(directive)
```

### Duration and Expiration

Directives can have an optional duration. When the duration expires, the control plane automatically undoes the directive's effects:

- Quarantined agents are released
- Enforced invariants are removed
- Tightened thresholds are restored

Expiration is checked periodically (every 100 evaluations) and can also be triggered manually.

## CLI Commands

```bash
# Quarantine agents
nomotic control quarantine --agent agent-1 --reason "policy violation" --duration 3600

# Quarantine by team
nomotic control quarantine --scope team:customer-support --reason "coordinated drift"

# Release from quarantine
nomotic control release --agent agent-1

# Enforce temporary invariant
nomotic control enforce --agent agent-1 \
  --invariant '{"metric": "write-to-read", "operator": "lt", "threshold": 0.25}' \
  --duration 14400

# Tighten drift thresholds
nomotic control tighten --archetype finance-agent --factor 0.5 --duration 7200

# Relax tightening
nomotic control relax --archetype finance-agent

# Re-anchor semantic term
nomotic control re-anchor --agent agent-1 --term "research"

# Broadcast compliance reminder
nomotic control broadcast-reminder --drift-status drifting --contract v2.3

# List active directives
nomotic control list
```

## API Endpoints

### POST /v1/control/directives

Issue a new behavioral directive.

**Request body:**
```json
{
  "directive_type": "quarantine",
  "issued_by": "ops@acme.com",
  "target_agents": ["agent-1"],
  "reason": "coordinated drift",
  "duration_seconds": 3600
}
```

**Response:**
```json
{
  "directive_id": "abc-123",
  "agents_affected": ["agent-1"],
  "success": true,
  "detail": "Quarantined 1 agent(s): coordinated drift"
}
```

### GET /v1/control/directives

List all active directives.

**Response:**
```json
{
  "directives": [...],
  "count": 3
}
```

### DELETE /v1/control/directives/\{directive_id\}

Expire a specific directive and undo its effects.

## Provenance and Accountability

Every control action is recorded as a provenance event with:

- **Actor**: The operator who issued the directive
- **Actor type**: `operator`
- **Target**: The directive ID
- **Context code**: `CONTROL.DIRECTIVE_ISSUED`
- **Reason**: Operator-provided justification

The control surface is subject to the same behavioral accountability it imposes. You can query directive history through the provenance API.

## Runtime Integration

The control plane integrates with the governance runtime at the earliest stage of evaluation. The quarantine check occurs before any dimension evaluation, constitutional rules, or policy checks. This ensures quarantined agents cannot bypass isolation through any other mechanism.

Enable the control plane in your runtime configuration:

```python
from nomotic.runtime import GovernanceRuntime, RuntimeConfig

runtime = GovernanceRuntime(RuntimeConfig(
    enable_control_plane=True,
))
```

## Configuration

The control plane is enabled via `RuntimeConfig.enable_control_plane = True`. When disabled, `issue_directive()` returns a failure result and `get_control_directives()` returns an empty list. No overhead is added to the evaluation pipeline when the control plane is disabled.
