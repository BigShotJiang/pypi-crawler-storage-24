---
sidebar_position: 13
title: Fleet Drift Scopes
---

# Fleet Drift Scopes

> `FleetBehavioralMonitor` is included in **Nomotic Open** (free tier).
> It provides fleet-level drift detection across all deployment topologies.

Fleet drift scopes detect behavioral patterns across multiple agents that no single-agent monitor can see. Where individual agent drift tracks whether one agent's behavior has changed, fleet drift scopes reveal fleet-wide behavioral intelligence: systemic shifts, correlated changes, and causal propagation chains.

```mermaid
flowchart TB
    subgraph Individual
        A1[Agent 1 Drift] --> FM
        A2[Agent 2 Drift] --> FM
        A3[Agent 3 Drift] --> FM
        AN[Agent N Drift] --> FM
    end

    FM[Fleet Behavioral Monitor] --> FD[Fleet Drift]
    FM --> CD[Correlated Drift]
    FM --> CO[Coordinated Drift]

    FD --> ALERT[Fleet Drift Alerts]
    CD --> ALERT
    CO --> ALERT
```

Three multi-agent drift scopes from the Nomotic Drift Taxonomy:

| Scope | What it detects | Signal to operator |
|---|---|---|
| **Fleet Drift** | Aggregate fleet behavior shifts | Something changed fleet-wide |
| **Correlated Drift** | Multiple agents drift in the same direction | Shared upstream cause (model update, data shift) |
| **Coordinated Drift** | Drift propagates through agent interaction chains | Causal chain with potential amplification |

All three scopes operate across all five drift distributions (action, target, temporal, outcome, and semantic).

## Fleet Drift

Fleet drift measures whether the fleet's aggregate behavioral fingerprint has shifted from its baseline — even when no individual agent crosses its own drift threshold.

### Why It Matters

Consider a fleet of 50 agents, each with a drift threshold of 0.20. If 40 agents each drift by 0.15 (below their individual thresholds), no single-agent alert fires. But the fleet's aggregate distribution has shifted significantly. Fleet drift catches this.

### How It Works

The `FleetBehavioralMonitor` periodically computes an aggregate fleet fingerprint by averaging all agent distributions:

```python
from nomotic.fleet_monitor import FleetBehavioralMonitor, FleetDriftConfig

config = FleetDriftConfig(
    fleet_check_interval=50,      # Recompute every 50 fleet observations
    fleet_drift_threshold=0.15,   # Alert when aggregate drift exceeds this
)

monitor = FleetBehavioralMonitor(config=config, fingerprint_observer=observer)
```

The aggregate fingerprint is compared against a fleet baseline using the same JSD metric that powers individual agent drift. The baseline updates slowly (90% old + 10% new) to track intentional fleet evolution while catching unexpected shifts.

### Fleet Drift Alerts

```python
alert = FleetDriftAlert(
    scope="fleet",
    severity="high",
    fleet_drift_score=0.28,
    fleet_distributions_shifted=["action", "semantic"],
    detail="Fleet aggregate drift 0.280 exceeds threshold 0.150. ..."
)
```

## Correlated Drift

Correlated drift detects when multiple agents drift in the same direction at the same time — suggesting a shared upstream cause rather than independent behavioral change.

### Why It Matters

A model update that subtly shifts how all agents interpret "analyze" from "evaluate" to "execute" would appear as correlated semantic drift across the fleet while every structural distribution stays clean. The signal: something upstream changed, because these agents are independently responding to the same environmental shift.

Investigation should focus on:
- Shared model versions
- Data source changes
- Prompt template updates
- Infrastructure changes

### How It Works

For each agent with recent drift, the monitor computes a 5-element drift vector:

```
[action_drift, target_drift, temporal_drift, outcome_drift, semantic_drift]
```

Pairwise cosine similarity between all agent drift vectors identifies clusters of agents drifting in the same direction. When a cluster exceeds the minimum agent count and similarity threshold, a correlated drift alert fires.

```python
config = FleetDriftConfig(
    correlation_time_window=300.0,        # 5-minute window
    correlation_min_agents=3,             # At least 3 agents
    correlation_similarity_threshold=0.7, # Cosine similarity >= 0.7
)
```

### Correlated Drift Alerts

```python
alert = FleetDriftAlert(
    scope="correlated",
    severity="high",
    affected_agents=["agent-1", "agent-2", "agent-3", "agent-4"],
    shared_drift_direction={
        "action": 0.05,
        "target": 0.02,
        "temporal": 0.01,
        "outcome": 0.03,
        "semantic": 0.28,   # Dominant semantic drift
    },
    correlation_strength=0.92,
    detail="4 agents drifting in similar direction (correlation 0.920). ..."
)
```

### Correlated Semantic Drift

Correlated semantic drift is a particularly important detection target. When all agents' semantic distributions shift together while structural distributions stay clean, it indicates a meaning-level change propagating through the fleet — often from a shared model update or prompt template change.

## Coordinated Drift

Coordinated drift traces causal propagation chains through agent interaction graphs. When Agent A's output feeds Agent B, and B's output feeds Agent C, behavioral drift can propagate and compound through the chain.

### Why It Matters

A drift that doubles at each hop is far more dangerous than one that attenuates. Coordinated drift measures:
- **Propagation path**: Which agents are in the chain
- **Amplification profile**: How drift magnitude changes at each hop
- **Recommended intervention point**: Where to stop the chain (the source)

### Setting Up the Interaction Map

The monitor needs to know which agents consume which other agents' outputs:

```python
from nomotic.runtime import GovernanceRuntime, RuntimeConfig

# At initialization
config = RuntimeConfig(
    enable_fleet_monitor=True,
    interaction_map={
        "data-collector": {"analyzer", "summarizer"},
        "analyzer": {"report-generator"},
        "summarizer": {"report-generator"},
    },
)

# Or at runtime
runtime.register_interaction("data-collector", "analyzer")
runtime.register_interaction("analyzer", "report-generator")
```

### How It Works

When drift is detected in an agent that has downstream consumers:

1. Check if downstream agents also drifted
2. Verify temporal ordering: downstream drift started **after** source drift
3. Verify temporal proximity: within `propagation_max_lag` seconds
4. Extend the chain: check if downstream's downstream also drifted

```python
config = FleetDriftConfig(
    propagation_max_lag=60.0,  # Max 60 seconds between cause and effect
)
```

### Coordinated Drift Alerts

```python
alert = FleetDriftAlert(
    scope="coordinated",
    severity="critical",
    propagation_chain=["data-collector", "analyzer", "report-generator"],
    amplification_factors=[0.10, 0.22, 0.45],  # Drift doubles at each hop
    recommended_intervention_point="data-collector",
    detail="Drift propagation chain detected: data-collector -> analyzer -> ..."
)
```

### Coordinated Semantic Drift

Coordinated semantic drift — where one agent's semantic reframing propagates and amplifies through a chain — is the highest-risk variant. It can produce fleet-wide meaning shifts from a single point of origin while structural metrics remain normal.

## Runtime Integration

Enable the fleet behavioral monitor in `RuntimeConfig`:

```python
from nomotic.fleet_monitor import FleetDriftConfig
from nomotic.runtime import GovernanceRuntime, RuntimeConfig

config = RuntimeConfig(
    enable_fleet_monitor=True,
    fleet_config=FleetDriftConfig(
        fleet_check_interval=50,
        correlation_min_agents=3,
        propagation_max_lag=60.0,
    ),
    interaction_map={
        "agent-a": {"agent-b"},
        "agent-b": {"agent-c"},
    },
)

runtime = GovernanceRuntime(config=config)

# Query fleet health
health = runtime.get_fleet_health()

# Query fleet alerts
alerts = runtime.get_fleet_alerts(scope="correlated")

# Register interactions dynamically
runtime.register_interaction("new-source", "new-target")
```

## CLI

```bash
# Fleet behavioral drift health
nomotic fleet drift-health

# Fleet drift alerts (all scopes)
nomotic fleet drift-alerts

# Fleet drift alerts (specific scope)
nomotic fleet drift-alerts --scope=correlated

# Register agent interaction
nomotic fleet interaction --source=agent-a --target=agent-b
```

## API

```bash
# Fleet drift health
GET /v1/fleet/drift-health

# Fleet drift alerts
GET /v1/fleet/drift-alerts
GET /v1/fleet/drift-alerts?scope=coordinated

# Register interaction
POST /v1/fleet/interactions
{"source": "agent-a", "target": "agent-b"}
```

## Configuration Reference

| Parameter | Default | Description |
|---|---|---|
| `fleet_check_interval` | 50 | Recompute fleet drift every N observations |
| `correlation_time_window` | 300.0 | Seconds — drift events within this window are candidates |
| `correlation_min_agents` | 3 | Minimum agents to trigger correlated alert |
| `correlation_similarity_threshold` | 0.7 | Cosine similarity threshold for drift vectors |
| `propagation_max_lag` | 60.0 | Max seconds between cause and effect |
| `fleet_drift_threshold` | 0.15 | Fleet aggregate drift alert threshold |
| `max_recent_events` | 500 | Max drift events retained for analysis |
