---
sidebar_position: 5
title: Drift Detection
---

# Bidirectional Drift Detection

Nomotic detects behavioral drift in two directions: agent drift (changes in agent behavior) and human reviewer drift (changes in human oversight patterns). Both matter for governance integrity.

```mermaid
flowchart LR
    subgraph Agent Side
        A[Agent Actions] --> AD[Agent Drift\nDetection]
    end

    subgraph Human Side
        H[Human Reviews] --> HD[Human Drift\nDetection]
    end

    AD --> G[Governance\nHealth Score]
    HD --> G
    G --> ALT[Alert /\nEscalate]
```

Standard drift detection monitors agents. Bidirectional drift detection monitors both agents *and* the humans overseeing them — because human-in-the-loop governance fails when humans stop paying attention.

## Agent Behavioral Drift

### How It Works

The `DriftMonitor` maintains a behavioral fingerprint for each agent, built from:

- **Action distribution** — the frequency of each action type (read, write, delete, etc.)
- **Target distribution** — which resources the agent accesses
- **Temporal patterns** — when the agent is active (business hours, overnight, etc.)
- **Outcome distribution** — the ratio of ALLOW/DENY/ESCALATE verdicts

When current behavior diverges from the established fingerprint, drift is detected. Nomotic compares two behavioral fingerprints using Jensen-Shannon Divergence (JSD):

```mermaid
flowchart LR
    BF[Baseline Fingerprint\nestablished behavior] --> JSD
    RF[Recent Window\nlast N actions] --> JSD
    JSD[Jensen-Shannon\nDivergence] --> DS[Drift Score\n0.0 – 1.0]
    DS --> SEV{Severity}
    SEV -->|0.0–0.2| LOW[Low\nLog only]
    SEV -->|0.2–0.4| MED[Medium\nIncrease scrutiny]
    SEV -->|0.4–0.6| HIGH[High\nAlert + reduce trust]
    SEV -->|0.6–1.0| CRIT[Critical\nSuspend agent]
```

### Drift Scores

```python
drift = runtime.calculate_drift("my-agent")

print(f"Drift score: {drift.drift_score:.3f}")        # 0.0–1.0
print(f"Severity: {drift.severity}")                   # low, medium, high, critical
print(f"Drifting dimensions: {drift.drifting_dimensions}")
```

### Thresholds and Severity

| Score Range | Severity | Default Action |
|---|---|---|
| 0.0 – 0.2 | Low | Log only |
| 0.2 – 0.4 | Medium | Increase scrutiny |
| 0.4 – 0.6 | High | Alert + reduce trust |
| 0.6 – 1.0 | Critical | Suspend agent |

Thresholds are configurable per preset and per agent.

### Archetype Priors

Before an agent has enough history, its fingerprint is seeded from the archetype's behavioral prior. For example, a `customer-experience` agent's prior expects:
- 55% read, 20% write, 12% send, 8% query, 5% escalate
- Peak hours: 10:00–14:00
- Active during business hours only
- 92% ALLOW, 4% MODIFY, 3% ESCALATE, 1% DENY

As real observations accumulate (weighted by `prior_weight`, default 50 synthetic observations), the actual behavior gradually replaces the prior.

### Drift Weights

Not all drift is equally concerning. Each archetype defines `drift_weights` that amplify or dampen drift signals:

```python
# Financial analyst: action and target drift matter more
drift_weights = {
    "action": 1.5,   # Changed action mix is very concerning
    "target": 1.5,   # Accessing new resource types is very concerning
    "temporal": 1.2,  # Off-hours activity is moderately concerning
    "outcome": 1.3,  # Changing denial rates is concerning
}
```

### Continuous Monitoring

```python
from nomotic.monitor import DriftMonitor

monitor = DriftMonitor(runtime, check_interval=60)  # Check every 60s
monitor.on_drift(lambda agent_id, drift: alert_team(agent_id, drift))
monitor.start()
```

## Human Reviewer Drift

### Why It Matters

Human oversight is only effective if humans are actually overseeing. Reviewer drift detects when oversight quality degrades:

- A reviewer who normally handles 50 escalations/week drops to 5
- Approval rate jumps from 70% to 99% (rubber-stamping)
- Response times increase from minutes to days
- A reviewer stops reviewing certain agent types entirely

### Oversight Metrics

| Metric | Description |
|---|---|
| Approval rate | What percentage of escalations does the reviewer approve? |
| Review time | How long does the reviewer spend on each decision? |
| Consistency | Are similar cases getting similar decisions? |
| Engagement | Is the reviewer actively reviewing or rubber-stamping? |

### HumanDriftMonitor

The `HumanDriftMonitor` tracks reviewer engagement patterns:

- **Review frequency** — how often the reviewer handles escalations
- **Approval rate** — percentage of escalations approved vs. denied
- **Response time** — latency from escalation to resolution
- **Coverage** — which agent types and archetypes the reviewer handles

Drift in any of these patterns triggers alerts visible in the dashboard and via the API.

### Detecting Rubber-Stamping

:::warning
A reviewer approving 95%+ of escalations with declining review times is likely rubber-stamping. Nomotic flags this and can escalate to a secondary reviewer.
:::

```python
oversight = runtime.get_oversight_health(reviewer_id="alice@company.com")

print(f"Approval rate: {oversight.approval_rate:.1%}")
print(f"Avg review time: {oversight.avg_review_time_s:.1f}s")
print(f"Rubber-stamp risk: {oversight.rubber_stamp_risk}")
```

### Configuring Thresholds

```yaml
human_oversight:
  rubber_stamp_threshold: 0.90    # Flag if approval rate exceeds this
  min_review_time_s: 30           # Flag if avg review time drops below this
  window_days: 7                  # Rolling window for calculations
```

## API

```
GET /v1/drift/{agent_id}                               # Agent drift report
GET /v1/ui/drift-alerts                                # All drift alerts
POST /v1/ui/drift-alerts/{id}/dismiss                   # Dismiss an alert
GET /v1/human-engagement/{reviewer_id}/drift             # Reviewer drift
GET /v1/human-engagement/alerts                         # Human engagement alerts
```

## CLI

```bash
# Agent drift
nomotic drift <agent-id>              # Check current drift
nomotic drift <agent-id> --history    # View drift history

# Drift alerts
nomotic alerts                        # List all drift alerts
nomotic alerts --unacknowledged       # Unacknowledged only

# Human oversight
nomotic oversight --team                          # Oversight health for your team
nomotic oversight --reviewer alice@company.com    # Specific reviewer
```
