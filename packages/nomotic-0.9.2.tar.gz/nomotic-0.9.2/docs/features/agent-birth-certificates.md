---
sidebar_position: 1
title: Agent Identity & Birth Certificates
---

# Agent Identity & Birth Certificates

An Agent Birth Certificate is a cryptographically signed identity document issued to an agent at creation time. It establishes the agent's identity, ownership, authorized scope, and governance parameters before the agent takes any action. Authority is issued, never assumed.

Anonymous agents are ungovernable. Without verified identity, there is no way to trace decisions back to a responsible human, enforce scope boundaries, or maintain a meaningful audit trail. Birth Certificates solve this by binding every agent to a human owner and a defined governance context from the moment it is created.

## Creating a Certificate

**CLI:**

```bash
nomotic birth --name my-agent
```

**Python API:**

```python
from nomotic import GovernanceRuntime, RuntimeConfig

config = RuntimeConfig.from_preset("strict")
runtime = GovernanceRuntime(config)

cert = runtime.birth_certificate(
    agent_id="my-agent",
    owner="team@company.com",
    archetype="assistant",
    governance_zone="production",
    scope={"read", "write", "query"},
)
```

## Certificate Contents

| Field | Description |
|---|---|
| `agent_id` | Unique identifier for the agent |
| `owner` | Human or team responsible for this agent |
| `archetype` | Behavioral category (assistant, analyst, executor, etc.) |
| `governance_zone` | Environment context (development, staging, production) |
| `scope` | Authorized action types |
| `issued_at` | Timestamp of issuance |
| `certificate_hash` | Cryptographic fingerprint |
| `signature` | Signed with the org's governance key |

## Agent Archetypes

| Archetype | Description |
|---|---|
| `assistant` | Conversational agent, read-heavy |
| `analyst` | Data analysis, read and aggregate |
| `executor` | Takes real-world actions, write-heavy |
| `orchestrator` | Manages other agents |
| `monitor` | Observational only |

## Certificate Lifecycle

```mermaid
stateDiagram-v2
    [*] --> Active: nomotic birth
    Active --> Suspended: Trust violation / SUSPEND verdict
    Suspended --> Active: Human reinstatement
    Active --> Revoked: nomotic revoke
    Suspended --> Revoked: nomotic revoke
    Revoked --> [*]
```

:::warning
Revoking a certificate is immediate and permanent. The agent cannot take any further actions. Revocation is recorded in the audit trail with timestamp and reason.
:::

## Inspecting a Certificate

```bash
nomotic inspect my-agent
nomotic inspect my-agent --brief    # Quick summary
nomotic inspect my-agent --raw      # Full JSON
```

## Verifying a Certificate

```python
is_valid = runtime.verify_certificate("my-agent")
cert = runtime.get_certificate("my-agent")
print(cert.certificate_hash)
```

---

## Governance Tokens

Governance tokens are the runtime companion to birth certificates. While a birth certificate establishes static identity at creation, a governance token is a signed, time-limited JWT artifact that encodes a specific governance decision. Tokens allow the result of an evaluation to travel with a request — useful in distributed systems where the governance runtime and execution layer are not in the same process.

### What a Token Contains

- Agent ID and action details
- The governance verdict (ALLOW, DENY, etc.)
- UCS score and dimension scores
- Issuer (the governance runtime)
- Issued-at and expiry timestamps
- Cryptographic signature

### Creating a Token

```python
verdict = runtime.evaluate(action, context)

if verdict.verdict == Verdict.ALLOW:
    token = runtime.issue_token(verdict, ttl_seconds=30)
    executor.execute(action, governance_token=token)
```

### Validating a Token

```python
is_valid = runtime.validate_token(token)
if not is_valid:
    raise GovernanceError("Invalid or expired governance token")
```

### Token Introspection

```python
payload = runtime.introspect_token(token)
print(payload.agent_id)
print(payload.verdict)
print(payload.ucs)
print(payload.expires_at)
```

### Revoking Tokens

```python
runtime.revoke_token(token_id, reason="Conditions changed")
```

:::warning
Tokens have a short TTL by default (30 seconds). Do not store governance tokens for reuse — each action requires a fresh evaluation.
:::

### CLI

```bash
nomotic token validate <token>
nomotic token introspect <token>
```
