---
sidebar_position: 4
title: Behavioral Fingerprints
---

# Behavioral Fingerprints

A behavioral fingerprint is a statistical profile of an agent's action patterns built from its history. Nomotic uses fingerprints to understand what "normal" looks like for a given agent and to detect when behavior deviates from that baseline.

Fingerprints form automatically from governance telemetry. No configuration is required beyond picking an archetype. They start from an archetype prior and are refined as real observations accumulate.

## What a Fingerprint Captures

| Distribution | What It Tracks |
|---|---|
| **Action type** | Proportion of read, write, query, delete, and other action types |
| **Target** | Which systems and data the agent typically accesses |
| **Temporal** | Time-of-day patterns, action frequency, burst behavior |
| **Outcome** | Distribution of governance verdicts (allow, deny, escalate rates) |

## Building a Fingerprint

Fingerprints build automatically from agent activity. A baseline is established after a configurable warm-up period (default: 100 actions). Before the fingerprint reaches confidence, the Behavioral Consistency dimension applies reduced weight.

```python
fingerprint = runtime.get_fingerprint("my-agent")

print(fingerprint.action_distribution)   # {"read": 0.72, "write": 0.21, "query": 0.07}
print(fingerprint.most_common_targets)   # ["customer_records", "product_catalog"]
print(fingerprint.total_observations)    # 847
print(fingerprint.confidence)            # 0.91
```

## Fingerprints in Governance

The Behavioral Consistency dimension (Dimension 4) uses the fingerprint to score each action. Actions that match established patterns score high. Unusual actions score lower — even if they would be routine for another agent.

```python
verdict = runtime.evaluate(action, context)
consistency_score = next(
    s for s in verdict.dimension_scores
    if s.dimension_name == "behavioral_consistency"
)
print(f"Consistency: {consistency_score.score:.3f}")
```

## Jensen-Shannon Divergence

Nomotic measures behavioral similarity using Jensen-Shannon Divergence (JSD) — a symmetric, bounded metric between 0.0 and 1.0 that compares two probability distributions.

| JSD Value | Interpretation |
|---|---|
| 0.0 – 0.2 | Behavior closely matches baseline |
| 0.2 – 0.4 | Moderate deviation, worth monitoring |
| 0.4 – 0.6 | Significant drift |
| 0.6 – 1.0 | Severe divergence from baseline |

:::note
JSD is computed using only Python's standard library `math` module — no external dependencies required.
:::

---

## Behavioral Memory

Behavioral memory is the integration of an agent's full action history into live governance decisions. It is not logging — logs are a record. Behavioral memory is an active input to every governance evaluation.

Without behavioral memory, governance is stateless. Each action is evaluated in isolation, with no knowledge of what the agent did five minutes ago or whether its behavior has been gradually shifting over time. Stateless governance can be gamed. Behavioral memory closes this window.

### Three Layers of History

Nomotic maintains three distinct layers of behavioral history per agent:

| Layer | What It Stores | Used By |
|---|---|---|
| **Audit trail** | Every governance decision, verdict, and outcome | Precedent Alignment (D10), compliance reporting |
| **Behavioral fingerprint** | Statistical profile of action/target/timing distributions | Behavioral Consistency (D4), drift detection |
| **Trust trajectory** | Time-series of trust score changes | Tier 3 (Unwritten Policy) deliberation, trust calibration |

These layers are independent but connected. The audit trail feeds the fingerprint. The fingerprint feeds the drift score. The drift score feeds the trust trajectory. The trust trajectory feeds governance decisions.

### How History Enters Governance

```mermaid
flowchart TD
    A([Incoming Action]) --> DIM[14 Dimensions]

    BF[Behavioral Fingerprint] -->|D4: Behavioral Consistency| DIM
    AT[Audit Trail] -->|D10: Precedent Alignment| DIM
    TS[Trust Score] -->|Modulates UCS weight| UCS

    DIM --> UCS[Unified Confidence Score]
    UCS --> T2{Tier 2 — Contextual Policy}
    T2 -->|Ambiguous| T3[Tier 3 — Unwritten Policy]
    TT[Trust Trajectory] -->|Tiebreaker| T3
    T3 --> V([Verdict])
```

**Dimension 4 — Behavioral Consistency** scores the current action against the agent's fingerprint. An action that matches established patterns scores high. An action that is unusual for this agent scores lower.

**Dimension 10 — Precedent Alignment** checks whether similar actions by this agent have been allowed or denied before. An action that governance has previously denied multiple times scores lower than one that has consistently been allowed.

**Trust score** modulates how the UCS is interpreted. A high-trust agent in the ambiguous zone gets the benefit of the doubt.

**Trust trajectory** is used in Tier 3 as the tiebreaker for cases that cannot be resolved by UCS alone. A declining trajectory tips the decision toward ESCALATE.

### Behavioral Memory and Drift

When recent behavior diverges from the fingerprint baseline, drift detection fires. Drift feeds back into governance through two channels: the Behavioral Consistency dimension score drops, and if drift exceeds threshold, trust is adjusted downward.

```python
drift = runtime.calculate_drift("my-agent")

print(f"Drift score: {drift.drift_score:.3f}")
print(f"Severity: {drift.severity}")
print(f"Drifting dimensions: {drift.drifting_dimensions}")
```

This means a drifting agent faces tighter governance automatically — without any human reconfiguration.

### Per-Agent Isolation

Every agent has its own behavioral history. An agent pool of ten identical agents each builds its own independent fingerprint, trust score, and audit trail. Shared behavioral profiles are not supported — governance is identity-bound.

:::note
Behavioral memory begins accumulating from the first action after an agent's Birth Certificate is issued. There is no minimum action count before memory starts — it just becomes statistically reliable over time.
:::

### Accessing Behavioral History

```bash
nomotic audit my-agent                    # Full governance history
nomotic audit my-agent --filter denied    # Denied actions only
nomotic trust my-agent                    # Trust score history
nomotic drift my-agent                    # Current drift state
```

```python
records = runtime.get_audit_trail("my-agent", limit=100)
profile = runtime.get_trust_profile("my-agent")
report = runtime.get_trust_report("my-agent")

print(report["current_trust"])
print(report["trajectory"])
print(report["drift"])
```
