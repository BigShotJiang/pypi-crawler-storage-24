---
sidebar_position: 14
title: Drift Causal Analysis
---

# Drift Causal Analysis

Detection without explanation is half the job. When the Behavioral Control Plane flags drift, the first question an operator asks is "why?" The Drift Causal Analyzer is a post-detection enrichment layer that provides causal hypotheses with evidence for every drift event, across all five distributions and all five scopes in the Nomotic Drift Taxonomy.

```mermaid
flowchart LR
    DA[Drift Alert] --> DCA[DriftCausalAnalyzer]
    DCA --> CR[DriftCausalReport]
    CR --> HYP[Hypotheses]
    CR --> EV[Evidence]
    CR --> REM[Remediation]
```

Every drift event becomes a diagnostic narrative — not just a metric.

## How It Works

When any drift alert fires (individual agent, fleet, correlated, or coordinated), the `DriftCausalAnalyzer` runs a causal investigation and attaches a `DriftCausalReport` to the alert. The report includes:

- **Primary hypothesis** with confidence score (0.0–1.0)
- **Supporting evidence** (temporal correlations, provenance records, propagation traces)
- **Alternative hypotheses** the system considered
- **Recommended remediation** specific to the drift scope, distributions involved, and cause

## Cause Types

| Cause Type | Description | Typical Confidence |
|---|---|---|
| `config_change` | Configuration change correlated with drift timing | 0.80 |
| `model_update` | Shared model endpoint or version change | 0.85 |
| `semantic_reframing` | Gradual shift in instruction-to-action meaning | 0.60 |
| `workload_shift` | Change in input patterns or workload | 0.40 |
| `upstream_propagation` | Drift propagated through interaction chain | 0.70 |
| `contract_change` | Behavioral contract modification | 0.75 |
| `unknown` | No specific cause identified | 0.20 |

## Analysis by Scope

### Agent Drift

For individual agent drift, the analyzer:

1. Identifies which distributions are above moderate threshold (> 0.15)
2. Queries the provenance log for configuration changes within 1 hour before the alert
3. Correlates timing of behavioral change with provenance events
4. Generates remediation based on affected distributions

```python
from nomotic import GovernanceRuntime, RuntimeConfig

runtime = GovernanceRuntime(config=RuntimeConfig(
    enable_fingerprints=True,
    enable_audit=True,
))

# After drift is detected, get the causal report
report = runtime.get_drift_causal_report("agent-1")
if report:
    print(f"Cause: {report['primary_hypothesis']['description']}")
    print(f"Confidence: {report['primary_hypothesis']['confidence']}")
    for action in report['remediation']:
        print(f"  - {action}")
```

### Fleet Drift

For fleet-level aggregate drift, the analyzer:

1. Groups agents by archetype
2. Classifies movement type:
   - **Concentrated**: top 20% of agents account for > 80% of total drift
   - **Distributed**: drift spread broadly across many agents
3. Queries provenance for global policy changes
4. Recommends investigation strategy based on movement type

### Correlated Drift

For correlated drift across multiple agents, the analyzer:

1. Identifies the shared upstream input from provenance records
2. Determines which distributions are dominant across affected agents
3. Maps the shared change to all affected agents

**Example output:**

> Correlated semantic drift detected across 7 finance-agent instances. Hypothesis (confidence: 0.85): shared model endpoint updated from v3.1 to v3.2 at 14:22 UTC. Semantic analysis: the term 'assess' shifted from mapping to read-type actions to mapping to write-type actions. Recommendation: review model v3.2 semantic impact on financial terminology, consider staged rollout with semantic monitoring.

### Coordinated Drift

For coordinated drift through interaction chains, the analyzer:

1. Reconstructs the full propagation chain
2. Computes amplification profile (growing, stable, or attenuating at each hop)
3. Identifies the root cause agent and analyzes its drift
4. Recommends intervention point:
   - If amplifying: break the chain at the root agent
   - If stable: inject governance checkpoint at the middle of the chain

## CLI

```bash
# Explain drift for a specific agent
nomotic drift explain --agent=agent-1

# Explain a fleet drift alert by alert ID
nomotic drift explain --alert=fleet-abc123
```

## API

```bash
# Agent drift causal analysis
GET /v1/drift/explain/{agent_id}

# Fleet drift alert causal analysis
GET /v1/drift/explain/alert/{alert_id}
```

### Response Format

```json
{
  "agent_id": "agent-1",
  "causal_report": {
    "alert_id": "agent-agent-1-a1b2c3d4",
    "agent_id": "agent-1",
    "scope": "agent",
    "distributions_involved": ["action", "semantic"],
    "primary_hypothesis": {
      "cause_type": "config_change",
      "confidence": 0.80,
      "description": "Config change at 1700000000: modify on scope",
      "evidence": [
        "Provenance: admin@example.com (human) changed scope/agent-1",
        "Change occurred 600s before drift alert"
      ]
    },
    "alternative_hypotheses": [
      {
        "cause_type": "unknown",
        "confidence": 0.20,
        "description": "No specific cause identified",
        "evidence": []
      }
    ],
    "remediation": [
      "Review agent scope and action type permissions",
      "Review instruction anchors in behavioral contract"
    ]
  }
}
```

## Integration with Existing Systems

The causal analyzer integrates automatically with the governance runtime:

- **DriftAlert**: Now includes a `causal_report` field populated when drift is detected
- **FleetDriftAlert**: The existing `causal_report` field is populated with full analysis
- **Dashboard**: Causal analysis is available inline with each drift alert
- **Provenance Log**: Configuration changes are correlated with drift timing

## Programmatic Usage

```python
from nomotic.drift_causal import DriftCausalAnalyzer, DriftCausalReport
from nomotic.provenance import ProvenanceLog

# Create analyzer with provenance log for temporal correlation
prov = ProvenanceLog()
analyzer = DriftCausalAnalyzer(provenance_log=prov)

# Analyze any alert
report = analyzer.analyze(alert)
print(report.summary())
print(report.to_dict())
```
