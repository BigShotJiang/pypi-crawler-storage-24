---
sidebar_position: 6
title: Interrupt Authority
---

# Interrupt Authority

Interrupt Authority is the mechanical capability to halt an agent action while it is in progress. Not after it completes. Not before it starts. During execution.

Most governance operates at the boundary — approving or denying actions before they run. Interrupt Authority extends governance into execution itself. If conditions change, if new information arrives, or if the action is taking an unexpected path, governance can pull the plug.

## How It Works

```mermaid
sequenceDiagram
    participant A as Agent
    participant E as Executor
    participant G as Governance
    participant T as Tool

    A->>E: execute(action)
    E->>G: evaluate(action)
    G-->>E: ALLOW + handle
    E->>T: begin execution
    E-->>A: ExecutionHandle

    Note over G,T: Governance monitors execution

    G->>E: interrupt(handle, reason)
    E->>T: halt + rollback
    E-->>A: InterruptedException
```

When the executor begins an action, it creates an `ExecutionHandle` — a live reference to the running action. The governance layer holds the handle and can call `interrupt()` at any time.

```python
handle = runtime.begin_execution(action, context, rollback=my_rollback_fn)

# If something goes wrong during execution:
runtime.interrupt(handle, reason="Unexpected target access detected")
```

## Interrupt Scopes

| Scope | Effect |
|---|---|
| `ACTION` | Stop this specific action only |
| `AGENT` | Stop all actions by this agent |
| `WORKFLOW` | Stop this workflow and all child actions |
| `GLOBAL` | Emergency stop — halt everything |

```python
from nomotic.interrupt import InterruptScope

runtime.interrupt(handle, scope=InterruptScope.AGENT, reason="Trust threshold breached")
```

## Rollback

Interrupting without recovery creates problems it doesn't solve. Register a rollback function when beginning execution. If the action is interrupted, rollback runs automatically.

```python
def rollback_fn():
    database.rollback_transaction()
    cache.clear_pending()

handle = runtime.begin_execution(action, context, rollback=rollback_fn)
```

## Checking Interrupt Status During Execution

For long-running actions, check interrupt status cooperatively:

```python
handle = runtime.begin_execution(action, context)

while action_is_running:
    if handle.is_interrupted():
        handle.rollback()
        break
    do_next_step()
```

## Interrupt Records

Every interrupt is recorded in the audit trail with the source, reason, scope, and severity.

```bash
nomotic audit my-agent --filter interrupted
```

---

## Workflow Governance

Interrupt Authority governs individual actions during execution. Workflow Governance extends this to multi-step workflows, detecting risks that only emerge when actions are considered as a sequence.

### The Problem With Action-by-Action Governance

Individual actions may each pass governance while the sequence they form is unauthorized.

:::note
Example: `read customer record` → `query payment history` → `export data`. Each step is individually reasonable. Together they constitute an unauthorized data extraction. Workflow Governance evaluates the sequence, not just each step.
:::

### What Workflow Governance Detects

- **Compounding authority** — steps that each request small permissions but together achieve unauthorized access
- **Cross-step drift** — behavioral shift across the workflow indicating the agent changed strategy mid-execution
- **Cascading risk** — early steps that enable later steps in risky ways
- **Dependency violations** — steps executed out of order or without required predecessors

### Using Workflow Governance

```python
from nomotic import WorkflowGovernor

governor = WorkflowGovernor(runtime)
workflow_id = governor.start_workflow("data-export-workflow")

for step in workflow_steps:
    assessment = governor.assess_step(workflow_id, step, context)

    if assessment.recommendation == "halt":
        governor.halt_workflow(workflow_id)
        break
```

### Workflow Risk Assessment

```python
assessment = governor.get_workflow_assessment(workflow_id)

print(f"Cumulative risk: {assessment.cumulative_risk_score:.3f}")
print(f"Risk trajectory: {assessment.risk_trajectory}")
print(f"Recommendation: {assessment.recommendation}")
```

### Risk Trajectory

| Trajectory | Meaning |
|---|---|
| `stable` | Risk is not accumulating across steps |
| `increasing` | Each step adds more risk than the last |
| `accelerating` | Risk accumulation is speeding up |
| `decreasing` | Workflow is becoming safer as it progresses |

### Projecting Forward

```python
projection = governor.get_projection(workflow_id)
print(f"Projected risk at completion: {projection.projected_final_risk:.3f}")
print(f"High-risk steps ahead: {projection.high_risk_steps}")
```
