---
sidebar_position: 20
title: Policy Evolution
---

# Policy Evolution

Policy Evolution is a governance operations feature that analyzes audit trail data to detect patterns in governance decisions and recommend policy adjustments. It surfaces recurring overrides, verdict contradictions, dimension misalignments, and configuration staleness — then guides operators through a structured approval workflow before any change is applied.

## Access

`PolicyEvolutionEngine` is part of the stable API surface and is accessible via direct import:

```python
from nomotic.policy_evolution import PolicyEvolutionEngine
```

It is intentionally **not** exported at the top-level `nomotic` namespace (`nomotic.__all__`) to keep the public API focused on core governance primitives. This is a deliberate design decision — the engine is fully supported but requires an explicit import path.

> **Natural gating:** Policy Evolution requires a populated `AuditTrail` to produce any meaningful output. Without audit data, the engine runs but finds no patterns.

## Enabling Policy Evolution

Wire a `PolicyEvolutionEngine` into your `GovernanceRuntime`:

```python
from nomotic import GovernanceRuntime, RuntimeConfig
from nomotic.policy_evolution import PolicyEvolutionEngine, PolicyEvolutionConfig

runtime = GovernanceRuntime(RuntimeConfig(enable_audit=True))

# After the runtime has accumulated audit data:
engine = PolicyEvolutionEngine(
    runtime.audit_trail,
    PolicyEvolutionConfig(
        window_days=90,
        min_cluster_size=5,
        significance_threshold=0.5,
        drift_threshold=0.3,
    ),
)
engine.run_analysis()
```

## Pattern Types

The engine detects four categories of governance pattern:

| Pattern Type | What It Detects | Example |
|---|---|---|
| **Exception Cluster** | Humans repeatedly override the system for a specific action type | 12 manual overrides on `data_export` actions in the last month |
| **Outcome Correlation** | Verdicts that are frequently contradicted by real-world outcomes | 60% of `DENY` verdicts on `api_query` were later overridden |
| **Dimension Drift** | Dimension scores that no longer align with observed outcomes | `scope_compliance` scores high but actions still get overridden |
| **Config Staleness** | Configuration that hasn't been reviewed relative to activity volume | Governance config unchanged for 6 months despite 10k decisions |

Each detected pattern includes:
- A significance score (0–1) indicating confidence
- Supporting evidence (action IDs from the audit trail)
- Observation window (first and last observed timestamps)

## Recommendation Approval Workflow

When the engine detects a significant pattern, it generates a `PolicyRecommendation` with a proposed change and projected impact. Recommendations follow a strict approval workflow:

```
pending → approved → applied
                  ↘ rejected
```

1. **Pending** — The engine generates a recommendation. It is visible but not yet actionable.
2. **Approved** — An operator reviews and approves the recommendation, recording their identity and an optional note.
3. **Applied** — The approved recommendation is applied. An `UnwrittenPolicyAdjustmentRecord` and a `ChangeRecord` are emitted to the audit trail.
4. **Rejected** — The operator rejects the recommendation. An `AccountabilityRecord` is emitted to the audit trail capturing the decision.

```python
# Review pending recommendations
for rec in engine.pending_recommendations():
    print(rec.recommendation_text)
    print(rec.proposed_change)
    print(rec.projected_impact)

# Approve and apply
engine.approve_recommendation(rec.recommendation_id, approved_by="admin@co.com", note="Reviewed")
change = engine.apply_approved_recommendation(rec.recommendation_id)

# Or reject
engine.reject_recommendation(rec.recommendation_id, rejected_by="admin@co.com", note="Not yet")
```

## Dashboard UI

The Policy Evolution Dashboard provides a visual interface for browsing patterns and managing recommendations. It is served by the Nomotic API server at `/ui/policy-evolution`.

### API Endpoints

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| `GET` | `/v1/policy-evolution/patterns` | None | List detected patterns |
| `GET` | `/v1/policy-evolution/recommendations` | None | List pending recommendations |
| `POST` | `/v1/policy-evolution/recommendations/{id}/approve` | API key | Approve a recommendation |
| `POST` | `/v1/policy-evolution/recommendations/{id}/reject` | API key | Reject a recommendation |
| `POST` | `/v1/policy-evolution/recommendations/{id}/apply` | API key | Apply an approved recommendation |

Write endpoints (`POST`) require the `X-Nomotic-API-Key` header when the server is configured with an API key. Read endpoints are unauthenticated.
