# License Gate

The license gate controls which governance tier is active at runtime. The open source SDK reads the license key and delegates validation to an installed plugin (such as `nomotic-pro`). No cryptographic validation happens in the SDK itself.

## How it works

1. At `GovernanceRuntime` startup, the `LicenseGate` reads the license key from config, environment variable, or key file.
2. It discovers any installed license validator via the `nomotic.license` entry point group.
3. If a validator is found, it delegates key validation to the plugin.
4. The result is cached. There is no per-evaluation overhead.
5. The activated tier constrains which dimensions the `DimensionOrchestrator` evaluates.
6. If no license is present, the runtime runs in **free tier (OPEN)** — this is the expected default, not an error state.

## Tiers

| Tier | Dimensions | Requires |
|------|-----------|----------|
| **OPEN** | D1-D14 (Base) | Nothing — free tier |
| **PRO** | D1-D20 (Professional) | Valid Pro license key + `nomotic-pro` plugin |
| **ENTERPRISE** | D1-D20 + behavioral engine | Valid Enterprise license key |

## Key reading priority

The SDK reads the license key from the first available source:

1. `LicenseConfig.key` — explicit key string in config
2. `NOMOTIC_LICENSE_KEY` — environment variable
3. Key file — `LicenseConfig.key_file` or default `~/.nomotic/license.key`

## Usage

### Basic setup (free tier)

No configuration needed. The runtime defaults to OPEN:

```python
from nomotic import GovernanceRuntime

runtime = GovernanceRuntime()
# Logs: "Nomotic running in free tier (D1-D14). Add a license key to unlock Pro."
```

### With a license key

```python
from nomotic import GovernanceRuntime, RuntimeConfig, LicenseConfig

config = RuntimeConfig(
    license_config=LicenseConfig(key="your-license-key")
)
runtime = GovernanceRuntime(config=config)
# Logs: "Nomotic running in pro tier."
```

### Via environment variable

```bash
export NOMOTIC_LICENSE_KEY="your-license-key"
```

```python
from nomotic import GovernanceRuntime

# Key is read from NOMOTIC_LICENSE_KEY automatically
runtime = GovernanceRuntime()
```

### Via key file

```bash
echo "your-license-key" > ~/.nomotic/license.key
```

```python
from nomotic import GovernanceRuntime

# Key is read from ~/.nomotic/license.key automatically
runtime = GovernanceRuntime()
```

### Checking the activated tier

```python
from nomotic import LicenseGate, LicenseConfig

gate = LicenseGate(LicenseConfig(key=my_key))
info = gate.resolve()

print(info.tier)          # ActivatedTier.PRO
print(info.org_id)        # "org_acme_123"
print(info.expires_at)    # 1735689600.0
print(info.features)      # ["dimensions_pro"]
print(info.deployment)    # "on_prem"

# Convenience checks
gate.is_pro_or_above()    # True
gate.is_enterprise()      # False
```

## Graceful degradation

The license gate never causes a hard failure. Every error path degrades to OPEN tier with a `validation_error` message:

| Scenario | Activated tier | `validation_error` |
|----------|---------------|-------------------|
| No license key | OPEN | `None` |
| Valid Pro key | PRO | `None` |
| Valid Enterprise key | ENTERPRISE | `None` |
| Key present, no validator installed | OPEN | `"No license validator installed..."` |
| Validator raises error | OPEN | Error message from validator |

## Expiry warnings

The gate can warn when a license is about to expire:

```python
gate = LicenseGate(LicenseConfig(key=my_key))
gate.resolve()

warning = gate.warn_if_expired_soon(warning_days=14)
if warning:
    print(warning)
    # "Nomotic license expires in 7 days. Renew at nomotic.ai/license."
```

The `GovernanceRuntime` checks this automatically at startup and logs a warning if the license is within 14 days of expiry.

## Interaction with product tiering

The license gate works alongside the existing `TieringConfig` system. When both are configured:

1. `TieringConfig` determines which dimensions the **product tier** enables.
2. `ActivatedTier` (from the license) determines the **maximum allowed** dimensions.
3. The active set is the **intersection** — you cannot activate dimensions beyond what the license allows.

```python
from nomotic import RuntimeConfig, LicenseConfig
from nomotic.tiering import TieringConfig, ProductTier

config = RuntimeConfig(
    license_config=LicenseConfig(key=pro_key),
    tiering=TieringConfig(
        tier=ProductTier.ENTERPRISE,  # requests all 20 dimensions (14 open source + 6 nomotic-pro)
        custom_enabled=["transparency"],
    ),
)
# The license is PRO, so only Professional-tier dimensions (17) are active.
# The Enterprise-only dimensions (transparency, jurisdictional_compliance,
# minimum_necessary_privilege) are filtered out despite the TieringConfig.
```

## Plugin-based validation

The SDK delegates all license validation to plugins discovered via the `nomotic.license` entry point group:

```toml
# In nomotic-pro's pyproject.toml:
[project.entry_points."nomotic.license"]
validator = "nomotic_pro.license:ProLicenseValidator"
```

The validator plugin receives the raw key and `LicenseConfig`, and returns a `LicenseInfo` with the resolved tier. This keeps all cryptographic validation, key format details, and trust logic out of the open source SDK.

## Architecture

```
LicenseConfig (user input)
        |
        v
   LicenseGate._read_key()
        |
        +-- config.key → env var → key file
        |
        v
   Key found?
        |
        +-- No key → OPEN
        |
        +-- Key found → _discover_validator()
                |
                +-- No validator installed → OPEN + validation_error
                |
                +-- Validator found → validator.validate(key, config)
                        |
                        +-- Success → PRO or ENTERPRISE
                        +-- Exception → OPEN + validation_error
        |
        v
   LicenseInfo (cached)
        |
        v
   GovernanceRuntime._activated_tier
        |
        v
   DimensionOrchestrator (filtered dimension set)
```

## API reference

### `ActivatedTier`

Enum with values: `OPEN`, `PRO`, `ENTERPRISE`.

### `LicenseConfig`

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `key` | `str \| None` | `None` | License key string |
| `key_file` | `Path \| None` | `None` | Path to license key file (default: `~/.nomotic/license.key`) |
| `server_url` | `str \| None` | `None` | Nomotic Cloud URL for revocation checks |
| `llm_config` | `Any \| None` | `None` | LLM configuration for LLM-dependent dimensions |

### `LicenseInfo`

| Field | Type | Description |
|-------|------|-------------|
| `tier` | `ActivatedTier` | Resolved tier |
| `org_id` | `str \| None` | Organization identifier |
| `expires_at` | `float \| None` | Expiration timestamp |
| `features` | `list[str]` | Feature flags |
| `deployment` | `str` | Deployment type (default `"local"`) |
| `validation_error` | `str \| None` | Error message if key was present but invalid |

### `LicenseGate`

| Method | Returns | Description |
|--------|---------|-------------|
| `resolve()` | `LicenseInfo` | Resolve and cache the license info |
| `tier` | `ActivatedTier` | Property — the activated tier |
| `is_pro_or_above()` | `bool` | True if PRO or ENTERPRISE |
| `is_enterprise()` | `bool` | True if ENTERPRISE |
| `warn_if_expired_soon(warning_days=14)` | `str \| None` | Warning message or None |
