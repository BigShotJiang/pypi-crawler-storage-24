---
sidebar_label: Behavioral Trajectory Engine
title: Behavioral Trajectory Engine
---

# Behavioral Trajectory Engine

The Behavioral Trajectory Engine transforms Nomotic from a reactive governance system into a **proactive behavioral control plane**. Instead of detecting drift after it happens, the engine projects behavioral drift forward, computes violation probabilities against the active contract, and triggers graduated interventions before violations actually occur.

## Why Predictive Governance

Every existing governance system in the market is reactive. Drift is detected after it happens. Violations are caught when they occur. The Behavioral Trajectory Engine changes this fundamentally by extending drift detection into **forward simulation** across all five distributions (action, target, temporal, outcome, semantic).

For any agent, the engine continuously projects the behavioral trajectory against the active contract over the next N actions. Using the agent's current behavioral fingerprint, its drift velocity and direction across all five distributions, and its contract invariants, the engine forecasts the probability that each invariant will be violated within the projection window.

## How It Works

### Drift Velocity Computation

The engine maintains a sliding window of the last 10 drift observations per agent. From these observations, it computes the **drift velocity** — the rate of change per distribution over time:

```
velocity[distribution] = (latest_value - earliest_value) / (latest_time - earliest_time)
```

A positive velocity means the agent's behavior is diverging from baseline in that distribution. A negative velocity means it's converging back.

### Forward Projection

Using the current drift values and computed velocities, the engine projects where each distribution will be at the projection horizon:

```
projected_drift[distribution] = current_drift + velocity * horizon
```

For each distribution with a contract threshold, it computes the **violation probability** — the likelihood that the threshold will be crossed within the projection window.

### Violation Probability

The violation probability calculation considers:

- **Current distance from threshold**: How much margin remains
- **Velocity toward threshold**: How fast the agent is approaching
- **Time to crossing**: When the threshold would be crossed at current velocity
- **Proximity weighting**: Earlier crossings produce higher probabilities

### Risk Classification

Based on the highest violation probability across all distributions and invariants:

| Probability Range | Risk Level | Intervention |
|---|---|---|
| < 0.3 | Low | None |
| 0.3 - 0.5 | Moderate | Advisory |
| 0.5 - 0.7 | High | Throttle |
| 0.7 - 0.9 | High | Escalate |
| > 0.9 | Critical | Tighten (or Escalate if approval required) |

## Graduated Intervention Chain

The graduated intervention chain is the core capability: the system detects behavioral trajectory toward contract violation and applies proportional, escalating corrective measures.

### Advisory

At the lowest level, the engine injects advisory signals into the verdict metadata that the agent framework can use to self-correct:

```python
verdict.metadata["trajectory_advisory"] = "Distribution 'action' projected violation probability 0.35"
```

### Throttle

At the next level, the engine throttles the agent's action rate by temporarily denying actions for a configurable period (default 5 minutes). This slows the trajectory and gives the system time to observe whether the agent self-corrects.

### Escalate

The engine forces human escalation by routing all subsequent evaluations through Tier 3 — Unwritten Policy (full targeted verification), ensuring a human reviewer examines the agent's behavior.

### Tighten

At the highest level (with operator permission), the engine can dynamically tighten contract parameters to prevent the violation. This level requires explicit approval by default (`tighten_requires_approval=True`).

## Configuration

```python
from nomotic import GovernanceRuntime
from nomotic.trajectory_engine import TrajectoryConfig

config = RuntimeConfig(
    enable_trajectory=True,
    trajectory_config=TrajectoryConfig(
        projection_horizon=100,       # Project 100 actions forward
        check_interval=25,            # Re-project every 25 observations
        advisory_threshold=0.3,       # Probability above this -> advisory
        throttle_threshold=0.5,       # -> throttle
        escalate_threshold=0.7,       # -> human escalation
        tighten_threshold=0.9,        # -> dynamic contract tightening
        enable_auto_intervention=True, # Enable automatic interventions
        tighten_requires_approval=True, # Require approval for tighten
    ),
)

runtime = GovernanceRuntime(config=config)
```

## API

### Get Trajectory Projection

```
GET /v1/trajectory/{agent_id}
```

Returns the latest trajectory projection for an agent, including per-distribution violation probabilities, risk level, and recommended intervention.

**Response:**

```json
{
  "agent_id": "agent-1",
  "projection": {
    "agent_id": "agent-1",
    "projection_horizon": 100,
    "timestamp": 1709654321.0,
    "risk_level": "moderate",
    "recommended_intervention": "advisory",
    "intervention_reason": "Distribution 'action' projected violation probability 0.42",
    "invariant_projections": [
      {
        "invariant_id": "drift_threshold_action",
        "violation_probability": 0.42,
        "projected_violation_at": 58,
        "current_margin": 0.65
      }
    ],
    "projected_drift": {
      "action": 0.32,
      "target": 0.05,
      "temporal": 0.02,
      "outcome": 0.01,
      "semantic": 0.0
    }
  }
}
```

### List Interventions

```
GET /v1/trajectory/interventions?agent_id={agent_id}
```

Returns the intervention history, optionally filtered by agent.

**Response:**

```json
{
  "interventions": [
    {
      "action_type": "advisory",
      "agent_id": "agent-1",
      "reason": "Distribution 'action' projected violation probability 0.35",
      "timestamp": 1709654321.0,
      "applied": false
    }
  ],
  "count": 1
}
```

## CLI

### Show Trajectory Projection

```bash
nomotic trajectory show --agent=agent-1
```

### List Interventions

```bash
nomotic trajectory interventions
nomotic trajectory interventions --agent=agent-1
```

## Python API

```python
from nomotic.trajectory_engine import (
    BehavioralTrajectoryEngine,
    TrajectoryConfig,
)

engine = BehavioralTrajectoryEngine(
    config=TrajectoryConfig(projection_horizon=50),
    fingerprint_observer=observer,
    contract_store=contract_store,
)

# Record drift observations (typically called automatically by runtime)
engine.record_drift("agent-1", drift_score)

# Project trajectory
projection = engine.project("agent-1")
print(projection.risk_level)
print(projection.recommended_intervention)

# Check for interventions on observation
intervention = engine.on_observation("agent-1", drift_score)
if intervention:
    print(f"Intervention: {intervention.action_type} - {intervention.reason}")
```

## Integration with Runtime

When `enable_trajectory=True`, the runtime automatically:

1. Creates a `BehavioralTrajectoryEngine` with the configured `TrajectoryConfig`
2. Feeds drift observations to the engine after each verdict
3. Applies interventions automatically when `enable_auto_intervention=True`:
   - **Advisory**: Adds `trajectory_advisory` to verdict metadata
   - **Throttle**: Temporarily denies all actions from the agent (5 minutes)
   - **Escalate**: Forces Tier 3 (Unwritten Policy) targeted verification for the agent
4. Exposes projections and interventions via `get_trajectory_projection()` and `get_trajectory_interventions()`
