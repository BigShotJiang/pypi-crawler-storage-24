---
sidebar_position: 9
title: nomotic-pro Plugin
---

# nomotic-pro

`nomotic-pro` is a separate installable package that adds the 6 inferential dimensions (D15–D20) to the Nomotic governance runtime. It requires a Pro or Enterprise license.

> **LLM note:** Three of the six inferential dimensions (D16, D19, D20) call an LLM
> for scoring. Without an LLM configured, these dimensions run in heuristic fallback
> mode — they still score, but with reduced accuracy. See "Configuring the LLM
> endpoint" below.

## What nomotic-pro is

- A Python package that registers D15–D20 into the Nomotic SDK via Python entry points in the `nomotic.dimensions` group
- It contains **only dimension implementations** — no runtime logic, no orchestrator, no UCS engine
- Installing it alongside `nomotic` automatically activates the 6 inferential dimensions when a Pro or Enterprise license is present
- Runtime bug fixes always go in `nomotic` — `nomotic-pro` only contains dimension scoring logic

The dimensions in `nomotic-pro` are schema-driven and context-aware. Three of them (D16 Minimum Necessary Privilege, D19 Goal-Action Alignment, D20 Adversarial Signal Detection) can optionally use an LLM endpoint for deeper evaluation when `llm_config` is provided in the `LicenseConfig`.

## Installation

```bash
pip install nomotic-pro
```

With a license key already configured, the runtime automatically discovers and registers D15–D20 on next startup. No configuration changes required — the entry point mechanism handles registration.

## Verifying installation

```python
from nomotic import GovernanceRuntime, RuntimeConfig
from nomotic.license import LicenseConfig

runtime = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(key="your-license-key")
))

counts = runtime.registry.available_count()
print(counts)
# {"core": 14, "plugin": 6, "total": 20}
```

If the output shows `"plugin": 0`, either:
- `nomotic-pro` is not installed in the current Python environment
- The license key is missing, invalid, or expired (tier resolved to OPEN)

## The "Pro licensed but plugin not installed" warning

If a Pro or Enterprise license is detected but `nomotic-pro` is not installed (no plugin dimensions are registered), the runtime logs:

```
WARNING: Nomotic Pro license detected but no plugin dimensions are registered.
Install nomotic-pro to activate D15–D20: pip install nomotic-pro
Governance will continue with D1–D14 only.
```

This is intentional — governance does not fail when the plugin is absent. The 14 built-in dimensions continue to provide full governance coverage. The warning appears once at startup to help operators notice the gap.

## The 6 inferential dimensions

All 6 dimensions are schema-driven and context-aware. They consume structured fields from the action and context objects to produce governance scores. See [Dimensions Reference](/features/dimensions) for full documentation of each.

| # | Dimension | What It Checks | Veto |
|---|-----------|----------------|:----:|
| D15 | Reversibility | Can this action be undone if needed? | Opt-in |
| D16 | Minimum Necessary Privilege | Is the agent using only what the goal requires? | No |
| D17 | Data Sensitivity Classification | What is the sensitivity class of the data involved? | No |
| D18 | Delegation Chain Integrity | Is the authority delegation chain legitimate? | Opt-in |
| D19 | Goal-Action Alignment | Is this action coherent with the declared goal? | No |
| D20 | Adversarial Signal Detection | Does this action match known attack patterns? | Opt-in |

### Veto behavior

Three inferential dimensions have configurable veto capability (opt-in, disabled by default):

- **Reversibility (D15)** — vetoes when all four conditions are met: IRREVERSIBLE + no rollback + PRODUCTION + blast radius HIGH or CRITICAL
- **Delegation Chain Integrity (D18)** — vetoes on expired delegation or when chain depth exceeds the configured maximum
- **Adversarial Signal Detection (D20)** — vetoes when multi-category co-occurrence confidence exceeds the configured `veto_threshold` (default: 0.85)

## Configuring the LLM endpoint

Three inferential dimensions — D16 (Minimum Necessary Privilege), D19 (Goal-Action Alignment), and D20 (Adversarial Signal Detection) — can use an LLM endpoint for deeper evaluation. When no `LLMConfig` is set, these dimensions run in **heuristic fallback mode**, producing conservative scores without any LLM calls.

### No LLMConfig (heuristic fallback)

When `llm_config` is not set on `LicenseConfig`, D16/D19/D20 use rule-based heuristics. This is the default and requires no additional configuration:

```python
from nomotic import GovernanceRuntime, RuntimeConfig, LicenseConfig

runtime = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(key="your-license-key")
))
# D16, D19, D20 use heuristic scoring — no LLM calls made
```

### Nomotic Cloud LLM (Pro/Enterprise license)

With a Pro or Enterprise license, the default endpoint (`https://api.nomotic.ai/v1/llm`) is automatic. Just set the LLM config — no API key or model configuration needed:

```python
from nomotic import GovernanceRuntime, RuntimeConfig, LicenseConfig, NOMOTIC_CLOUD_LLM

runtime = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(
        key="your-license-key",
        llm_config=NOMOTIC_CLOUD_LLM,
    )
))
```

### Bring your own LLM (BYOL)

Configure `LLMConfig` with your endpoint, model, and API key:

```python
from nomotic import GovernanceRuntime, RuntimeConfig, LicenseConfig, LLMConfig

# Azure OpenAI
runtime = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(
        key="your-license-key",
        llm_config=LLMConfig(
            endpoint="https://my-resource.openai.azure.com",
            model="gpt-4o",
            api_key="my-azure-key",
        ),
    )
))

# AWS Bedrock
runtime = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(
        key="your-license-key",
        llm_config=LLMConfig(
            endpoint="https://bedrock-runtime.us-east-1.amazonaws.com",
            model="anthropic.claude-3-sonnet",
        ),
    )
))
```

### Air-gap (local LLM)

Point `LLMConfig` at an Ollama or vLLM instance on your network:

```python
from nomotic import GovernanceRuntime, RuntimeConfig, LicenseConfig, LLMConfig

runtime = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(
        key="your-license-key",
        llm_config=LLMConfig(
            endpoint="http://localhost:11434",
            model="llama3.1:70b",
            timeout_ms=5000,
        ),
    )
))
```

No data leaves the network. The LLM runs entirely within your infrastructure.

## Private cloud and on-prem deployment

For Docker and Kubernetes deployments, bake `nomotic-pro` into the container image at build time:

```dockerfile
FROM python:3.12-slim
RUN pip install nomotic nomotic-pro
```

No separate pip step at runtime. The entry point registration happens at image build time. The runtime discovers the dimensions when it starts up inside the container.

For air-gap environments, pre-download both packages and install from a local index or wheel files:

```bash
pip download nomotic nomotic-pro -d /packages/
# Transfer /packages/ to air-gapped environment
pip install --no-index --find-links /packages/ nomotic nomotic-pro
```

## How plugin discovery works

`nomotic-pro` registers its dimensions via Python entry points in `pyproject.toml`:

```toml
[project.entry-points."nomotic.dimensions"]
reversibility = "nomotic_pro.dimensions.reversibility:ReversibilityDimension"
minimum_necessary_privilege = "nomotic_pro.dimensions.privilege:MinimumNecessaryPrivilege"
data_sensitivity_classification = "nomotic_pro.dimensions.sensitivity:DataSensitivityClassification"
delegation_chain_integrity = "nomotic_pro.dimensions.delegation:DelegationChainIntegrity"
goal_action_alignment = "nomotic_pro.dimensions.alignment:GoalActionAlignment"
adversarial_signal_detection = "nomotic_pro.dimensions.adversarial:AdversarialSignalDetection"
```

At startup, `DimensionRegistry.__init__()` calls `importlib.metadata.entry_points(group="nomotic.dimensions")` when the activated tier is PRO or ENTERPRISE. Each discovered entry point is loaded, instantiated, and registered alongside the 14 core dimensions.

If a plugin dimension fails to load (import error, missing dependency), the runtime logs a warning and continues with the remaining dimensions. A single broken plugin dimension does not prevent governance from running.

## Building custom dimension plugins

Any Python package can register governance dimensions by using the `nomotic.dimensions` entry point group. Custom dimensions follow the same interface as the built-in ones:

1. Subclass `nomotic.dimensions.GovernanceDimension`
2. Implement the `evaluate()` method returning a `DimensionScore`
3. Register via entry points in `pyproject.toml`

See [Plugin Dimensions](/plugin-dimensions) for the full interface specification, required class attributes, and a working example.
