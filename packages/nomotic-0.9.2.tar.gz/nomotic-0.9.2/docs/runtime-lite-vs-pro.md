---
sidebar_position: 11
title: Runtime Open vs Pro
---

# Runtime Open vs Pro

Nomotic's governance capability is split into two packages: the open source `nomotic` runtime (always free) and the optional `nomotic-pro` plugin (requires a license). This page explains what each includes and how they work together.

## Runtime Open (built into `pip install nomotic`)

Everything you need for production-grade AI agent governance. No license required.

### What's included

**14 dimensions (D1–D14), fully functional:**

| Category | Dimensions | Count |
|----------|-----------|-------|
| Deterministic — Published Policy (Tier 1) | Scope Compliance, Authority Verification, Resource Boundaries, Isolation Integrity, Temporal Compliance, Human Override | 6 |
| Probabilistic — Contextual Policy (Tier 2) | Behavioral Consistency, Cascading Impact, Stakeholder Impact, Ethical Alignment, Transparency, Precedent Alignment, Incident Detection, Jurisdictional Compliance | 8 |

**Full governance infrastructure:**

- DimensionOrchestrator with relevance filtering, priority ordering, and early exit
- Unified Confidence Score (UCS) engine with weighted aggregation, trust modulation, and floor drag
- Three-tier evaluation cascade (Published Policy → Contextual Policy → Unwritten Policy)
- Trust calibration with 5:1 asymmetric cost (violations penalized 5x more than good behavior)
- Behavioral fingerprinting and drift detection
- Fleet drift monitoring (`FleetBehavioralMonitor`) — fleet, correlated, and coordinated drift scopes
- Signal model with session context and prior system
- Hash-chained, tamper-evident JSONL audit trail
- All 14 compliance presets (SOC2, HIPAA, PCI-DSS, ISO 27001, severity tiers)
- `nomotic birth` CLI for agent certificate issuance
- HTTP server (`nomotic serve`) with governance API and dashboard
- Policy evolution backend for exception clustering and configuration recommendations

### What's not included

These require `nomotic-pro` + a Pro or Enterprise license:

- D15–D20 inferential dimensions
- LLM-dependent evaluation for Minimum Necessary Privilege (D16), Goal-Action Alignment (D19), and Adversarial Signal Detection (D20)

## Runtime Pro (Runtime Open + `nomotic-pro` plugin)

Adds the 6 inferential dimensions to everything in Open. Same runtime, same orchestrator, same UCS engine — just more dimensions feeding into the score.

### What it adds

| # | Dimension | Category | LLM-dependent |
|---|-----------|----------|:---:|
| D15 | Reversibility | Inferential | No |
| D16 | Minimum Necessary Privilege | Inferential | Optional |
| D17 | Data Sensitivity Classification | Inferential | No |
| D18 | Delegation Chain Integrity | Inferential | No |
| D19 | Goal-Action Alignment | Inferential | Optional |
| D20 | Adversarial Signal Detection | Inferential | Optional |

Three dimensions (D16, D19, D20) can optionally use an LLM endpoint for deeper contextual evaluation. Without an LLM configured, they use rule-based scoring.

### Installation

```bash
pip install nomotic-pro
```

With a license key configured, the runtime discovers and registers D15–D20 automatically on next startup.

## Checking what's active

```python
from nomotic import GovernanceRuntime, RuntimeConfig
from nomotic.license import LicenseConfig

# Open (no license)
runtime_open = GovernanceRuntime(RuntimeConfig())
print(runtime_open.activated_tier)
# ActivatedTier.OPEN

counts = runtime_open.registry.available_count()
print(counts)
# {"core": 14, "plugin": 0, "total": 14}

# Pro (with license + nomotic-pro installed)
runtime_pro = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(key="your-license-key")
))
print(runtime_pro.activated_tier)
# ActivatedTier.PRO

counts = runtime_pro.registry.available_count()
print(counts)
# {"core": 14, "plugin": 6, "total": 20}
```

### Checking active dimension names

```python
# List all registered dimensions
for dim in runtime.registry.dimensions:
    print(f"{dim.name}: weight={dim.weight}, can_veto={dim.can_veto}")
```

## What governance looks like with 14 vs 20 dimensions

### Example: agent writes to a production database

**With 14 dimensions (Open):**

```
Verdict: ALLOW | UCS: 0.712 | Tier: 2

Dimension scores:
  scope_compliance:          1.0  (in scope)
  authority_verification:    1.0  (authorized)
  resource_boundaries:       0.9  (within limits)
  behavioral_consistency:    0.8  (seen this action type before)
  cascading_impact:          0.6  (write action, medium impact)
  stakeholder_impact:        0.4  (production target, external keywords)
  incident_detection:        1.0  (no patterns matched)
  isolation_integrity:       1.0  (within boundaries)
  temporal_compliance:       1.0  (within window)
  precedent_alignment:       0.9  (consistent with history)
  transparency:              1.0  (all fields present)
  human_override:            1.0  (not required)
  ethical_alignment:         1.0  (no rules violated)
  jurisdictional_compliance: 0.8  (no jurisdictional context)

UCS: 0.712 → ALLOW (above 0.7 threshold)
```

The 14 dimensions provide a clear governance decision. The agent is authorized, the action is in scope, and no vetoes fire.

**With 20 dimensions (14 open source + 6 nomotic-pro):**

```
Verdict: ESCALATE | UCS: 0.584 | Tier: 3 → ESCALATE

Dimension scores (14 core — same as above):
  scope_compliance:          1.0
  authority_verification:    1.0
  ... (same scores) ...
  jurisdictional_compliance: 0.8

Additional dimension scores (6 inferential):
  reversibility:                  0.3  (IRREVERSIBLE, PRODUCTION, no rollback)
  minimum_necessary_privilege:    0.7  (write aligns, target broader than needed)
  data_sensitivity_classification: 0.3  (RESTRICTED data, PII category)
  delegation_chain_integrity:     0.9  (direct authority, no delegation)
  goal_action_alignment:          1.0  (action matches declared goal)
  adversarial_signal_detection:   1.0  (no adversarial signals)

UCS: 0.584 → ambiguity zone (between 0.3 and 0.7) → Tier 3 → ESCALATE
```

The 6 additional dimensions surfaced two signals the core set missed:
1. **Reversibility scored 0.3** — this is an irreversible write to production with no rollback mechanism
2. **Data sensitivity scored 0.3** — the target contains RESTRICTED PII data

These low scores dragged the UCS from 0.712 (ALLOW) down to 0.584 (ambiguity zone), triggering Tier 3 (Unwritten Policy) and an ESCALATE verdict. A human reviewer now sees exactly why: the action is technically authorized but involves irreversible changes to sensitive data.

This is the value of the inferential dimensions: they add depth to governance decisions without changing the core evaluation. The same orchestrator, the same UCS math, the same three-tier cascade — just more signals feeding in.

### What changes in the justification record

With 20 dimensions, the `GovernanceVerdict.dimension_scores` dictionary contains 20 entries instead of 14. The audit trail records all active dimension scores, so the justification record becomes richer:

- 6 additional scores in the dimension breakdown
- New reasoning entries explaining inferential dimension assessments
- Potentially different verdict (as shown above) when inferential signals shift the UCS

The audit trail format is identical — just more data per record.

## When to upgrade

**Stay on Open when:**
- Your agents operate in well-defined scopes with clear authority boundaries
- Actions are generally reversible or low-stakes
- You don't need LLM-dependent governance analysis
- You want zero external dependencies

**Consider Pro when:**
- Agents perform irreversible actions in production (database writes, deployments, financial transactions)
- You need to track delegation chains across multi-agent systems
- Data sensitivity classification is a governance requirement
- You want adversarial signal detection for agents exposed to untrusted input
- Goal-action alignment matters because agents have complex, multi-step objectives
