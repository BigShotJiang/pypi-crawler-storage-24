---
slug: /
sidebar_position: 1
title: What is Nomotic?
---

# What is Nomotic?

AI agents act in milliseconds. Humans review in hours. The gap between those timescales is where risk lives.

Traditional governance tools govern **requests** — binary allow/deny decisions at the API boundary. Nomotic governs **agents** — behavioral trajectory, trust evolution, drift detection, and multidimensional scoring across the full agent lifecycle.

Nomotic is the Behavioral Control Plane™ for AI agents. It evaluates every agent action at runtime across 14 dimensions (D1–D14) simultaneously, delivering sub-millisecond governance decisions with interrupt authority and dynamic trust calibration.

## Core Features

- **[14-Dimensional Evaluation](/features/dimensions)** — scope, authority, resources, behavior, impact, stakeholders, incidents, isolation, timing, precedent, transparency, human oversight, ethics, and jurisdiction evaluated simultaneously
- **[Agent Identity & Birth Certificates](/features/agent-birth-certificates)** — cryptographic identity with governance hash binding
- **[Dynamic Trust](/features/dynamic-trust)** — trust scores evolve with every action (+0.01 per success, -0.05 per violation)
- **[Behavioral Fingerprints](/features/behavioral-fingerprints)** — operational signatures that define what "normal" looks like for each agent
- **[Bidirectional Drift Detection](/features/bidirectional-drift-detection)** — detects both agent behavioral drift AND human reviewer drift
- **[Interrupt Authority](/features/interrupt-authority)** — halt agent actions mid-execution with cooperative rollback and workflow governance
- **[Hash-Chained Audit Trail](/features/hash-chained-audit-trail)** — tamper-evident, cryptographically linked evaluation records
- **[Reasoning Artifacts](/features/reasoning-artifacts)** — structured externalization of agent deliberation for governance evaluation

## Key Concepts

**Behavioral Control Plane™** — The product category. Where networking has a control plane that governs packet routing, Nomotic provides a control plane that governs agent behavior. Every action is evaluated, every decision is recorded, every drift is detected.

**Runtime AI Governance™** — Describes when governance happens. Not after the fact in a compliance review. Not at deployment in a static policy check. At runtime, before every action, throughout the full agent lifecycle.

**The Should Layer™** — The philosophy. Traditional systems govern what agents *can* do (permissions, access control). Nomotic governs what agents *should* do — behavioral expectations, ethical constraints, stakeholder impact, and organizational values.

## Get Started

```bash
pip install nomotic
```

Then follow the [Quickstart guide](/getting-started/quickstart) to create your first governed agent in under 5 minutes.

## Learn More

- **[Principles](/principles/verifiable-trust)** — the philosophy behind Nomotic's approach to trust, governance integration, and conflict resolution
- **[Architecture](/architecture/overview)** — how the runtime evaluation engine works under the hood
- **[Dashboard](/dashboard/overview)** — real-time agent monitoring, approval queues, drift alerts, and compliance scorecards
- **[Reference](/reference/configuration)** — configuration, CLI, API, and schema documentation
