---
title: Cost Profile Panel
---

# Cost Profile Panel

The Cost Profile panel provides visibility into asymmetric error cost configurations across your agent fleet. It exposes how the Behavioral Control Plane derives dynamic decision boundaries from cost profiles rather than relying on static thresholds.

## What the Panel Shows

### Per-Agent Cost Profile Display

Enter an agent ID to view its active cost profile, including:

- **Categorical labels**: LOW, MODERATE, HIGH, CRITICAL for both false-allow and false-deny costs
- **Numeric values**: Precise float values for `false_allow_cost` and `false_deny_cost`
- **Zone multiplier**: Environment scaling factor (production > staging > development)
- **Escalation costs**: Latency and interruption costs used by the VOI engine

### Derived vs Static Thresholds

A visual comparison showing:

- **Derived thresholds**: Computed from the agent's cost profile using signal detection theory (`theta = C_FP / (C_FP + C_FN)`)
- **Static defaults**: The baseline allow (0.7) and deny (0.3) thresholds
- **Ambiguity zone width**: The escalation zone between deny and allow thresholds
- **Threshold source**: Whether the threshold is from `cost_profile`, `smoothed`, or `static_default`

The threshold bar visualization uses color-coded zones:
- Red: Deny zone (UCS below deny threshold)
- Yellow: Ambiguity zone (UCS between deny and allow — triggers escalation)
- Green: Allow zone (UCS above allow threshold)

## Threshold Simulator

The simulator lets operators preview how threshold changes would affect governance decisions **without applying them**.

### Usage

1. Adjust the **False Allow Cost** slider (0.0 - 1.0) — higher values make the system more conservative
2. Adjust the **False Deny Cost** slider (0.0 - 1.0) — higher values make the system more permissive
3. Adjust the **Zone Multiplier** (0.5 - 2.0) — scales both costs for environment sensitivity
4. Click **Simulate** to see the resulting thresholds

### Interpreting Results

- **Conservative profile** (high false-allow, low false-deny): Lower allow threshold, narrower ambiguity zone. The system denies more actions.
- **Permissive profile** (low false-allow, high false-deny): Higher allow threshold, wider ambiguity zone. The system allows more actions.
- **Balanced profile** (equal costs): Thresholds near 0.5, moderate ambiguity zone.

The simulator uses a fresh ThresholdEngine instance, so results are independent of any smoothing history.

## Fleet Cost Distribution

Shows a fleet-wide summary of how many agents are configured at each cost level:

- **LOW** (0.1): Minimal governance sensitivity
- **MODERATE** (0.3): General-purpose governance
- **HIGH** (0.6): Elevated governance requirements
- **CRITICAL** (1.0): Maximum governance sensitivity

Bar charts show the distribution, making it easy to identify fleet-wide governance posture.

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/v1/cost-profiles/{agent_id}` | GET | Active cost profile, derived thresholds, history |
| `/v1/cost-profiles/summary` | GET | Fleet-wide cost level distribution |
| `/v1/cost-profiles/simulate` | POST | Simulate thresholds without applying |

## Screenshots

*[Dashboard screenshots to be added]*
