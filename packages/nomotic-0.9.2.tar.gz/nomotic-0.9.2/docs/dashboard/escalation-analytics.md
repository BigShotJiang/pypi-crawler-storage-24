---
title: Escalation Analytics
---

# Escalation Analytics Panel

The Escalation Analytics panel provides insight into how the Value of Information (VOI) engine is performing — whether escalations to human review are producing meaningful governance improvements.

## Escalation Volume Trends

The summary strip shows key escalation metrics at a glance:

- **Total Escalations**: Count of all escalation events
- **Verdict Changed**: Escalations where the human reviewer changed the automated verdict
- **Verdict Unchanged**: Escalations where the human agreed with the automated decision
- **Change Rate**: Percentage of escalations that resulted in a different outcome

A rising change rate suggests the VOI engine is correctly identifying uncertain decisions. A consistently low change rate may indicate the escalation threshold is too aggressive — the system is escalating decisions it could handle autonomously.

## VOI Distribution

A histogram showing the distribution of VOI scores across all escalations:

- **Low VOI (0.0-0.3)**: High confidence decisions that were near the escalation boundary
- **Medium VOI (0.3-0.6)**: Moderate uncertainty — standard escalation territory
- **High VOI (0.7-1.0)**: High uncertainty — dimensions disagree, trust is low, or stakes are high

### Interpreting the Distribution

- **Left-skewed** (most scores < 0.3): VOI threshold may be too low — many escalations are unnecessary
- **Right-skewed** (most scores > 0.7): VOI threshold may be too high — only extreme cases escalate
- **Bimodal**: Two distinct escalation patterns — investigate whether different agent archetypes or risk levels drive each peak

## Escalation ROI

A pie chart showing the proportion of escalations where human review changed the verdict vs. confirmed the automated decision.

- **Verdict Changed** (yellow): The escalation was valuable — human oversight corrected a governance error
- **Verdict Unchanged** (green): The escalation was unnecessary — the system would have made the same decision

Target: 20-40% change rate indicates well-calibrated escalation. Below 10% suggests over-escalation; above 60% suggests the system's automated decisions need improvement.

## Reviewer Utilization

A table showing per-reviewer metrics from the HumanDriftMonitor:

| Metric | Description |
|--------|-------------|
| Total Interactions | Number of reviews performed |
| Approval Rate | Percentage of reviews resulting in approval |
| Mean Review Duration | Average time spent per review |
| Reviews/Hour | Review throughput |

High approval rates (>95%) combined with fast review times may indicate rubber-stamping. The HumanDriftMonitor tracks these patterns — see the drift detection documentation for more detail.

## Agent Escalation History

Enter an agent ID to see its specific escalation history, including:

- **Timestamp**: When the escalation occurred
- **Reviewer**: Who reviewed the escalation
- **Decision**: What the reviewer decided (approved, denied, modified, deferred)
- **Risk Level**: The risk level of the action that triggered escalation
- **Review Duration**: How long the reviewer spent on the decision
- **Rationale**: The reviewer's explanation (if provided)

## How to Use Insights to Tune VOI Config

### If change rate is too low (< 10%)

The system is escalating too many decisions that don't need human review:

1. **Increase `min_voi_to_escalate`** in VOIConfig (default: 0.3)
2. **Lower `entropy_weight`** if dimension disagreement is driving unnecessary escalations
3. **Raise `trust_floor`** only if low-trust forced escalations dominate

### If change rate is too high (> 60%)

The system's automated decisions are frequently wrong:

1. **Review dimension weights** — some governance dimensions may need recalibration
2. **Check trust calibration** — agents may have inflated trust scores
3. **Decrease `min_voi_to_escalate`** to catch more uncertain decisions

### If reviewer fatigue is detected

1. **Rotate reviewers** using RoutingRecommendation suggestions
2. **Reduce review volume** by raising the escalation threshold for low-risk actions
3. **Add secondary reviewers** for high-risk escalations

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/v1/escalation/analytics` | GET | Fleet-wide escalation metrics |
| `/v1/escalation/analytics/{agent_id}` | GET | Per-agent escalation history |

## Screenshots

*[Dashboard screenshots to be added]*
