---
title: Trajectory & Policy Panel
---

# Trajectory & Policy Panel

The Trajectory & Policy panel provides real-time visibility into behavioral drift projections and intervention policies across your agent fleet. It exposes how the Behavioral Trajectory Engine predicts drift forward and how the Monte Carlo Policy Optimizer selects intervention strategies.

## What the Panel Shows

### Trajectory Chart

The per-agent behavioral trajectory chart displays:

- **Observed drift** (solid line): Historical drift scores recorded by the trajectory engine.
- **Projected drift** (dashed line): Forward projection of drift based on current velocity, computed per distribution (action, target, temporal, outcome, semantic).
- **Intervention markers**: Points where interventions were triggered or are planned.

The chart updates when you load an agent and shows the relationship between past behavior and projected future trajectory.

### Policy Overlay

When the Policy Optimizer is enabled, planned intervention points from the active `InterventionPolicy` are overlaid on the trajectory chart:

- **Advisory markers**: Early warnings issued to the agent.
- **Throttle markers**: Rate-limiting interventions.
- **Escalate markers**: Tier-3 escalation triggers.

Each marker shows the step number and intervention type, making the intervention schedule visually inspectable.

### Comparison View

Side-by-side comparison of the optimized policy vs naive threshold intervention:

- **Optimized cost**: Expected total cost under the selected strategy (intervention cost + violation cost).
- **Naive cost**: Expected cost under immediate escalation (the baseline).
- **Savings percentage**: How much cost the optimized policy saves compared to naive intervention.

This view is only available when the Policy Optimizer is enabled. Without it, the panel shows a graceful fallback message.

### Policy Details

Human-readable decision tree from `InterventionPolicy.to_readable()`, showing:

- Strategy name (e.g., "graduated", "early_advisory")
- Step-by-step intervention schedule
- Conditional clauses (e.g., "Stand down if drift < 0.15 within 25 actions")
- Expected cost and confidence score

### Policy Simulator

The simulator lets operators test different intervention strategies without applying them:

1. Select a **strategy** from the dropdown (no_op, early_advisory, wait_and_throttle, immediate_escalate, graduated).
2. Set the **horizon** (number of steps to simulate forward).
3. Click **Simulate** to see the projected drift trajectory under that strategy.

The simulation result shows:
- Projected drift curve with intervention markers
- Estimated total cost (when optimizer is available)
- Current drift and velocity values

This uses `POST /v1/trajectory/simulate` which runs the drift dynamics model with the selected strategy.

### Fleet Policy Summary

A table of all agents with current trajectory projections, showing:

| Column | Description |
|--------|-------------|
| Agent | Agent identifier (clickable to load details) |
| Risk Level | Color-coded badge: low, moderate, high, critical |
| Active Policy | Strategy name from the optimizer (if enabled) |
| Expected Cost | Projected intervention + violation cost |

Summary stat cards show total agents, low-risk count, high-risk count, and critical count. The fleet view auto-refreshes every 30 seconds.

### Historical Policy Effectiveness

The history panel shows past interventions for a selected agent:

- Intervention type and reason
- Whether the intervention was applied
- Timestamp

This helps operators assess whether past optimized interventions successfully reduced drift and cost compared to what would have happened without intervention.

## How to Read Policy Recommendations

1. **Low risk / no intervention**: The agent's drift is well within contract thresholds. No action needed.
2. **Moderate risk / advisory**: Drift is approaching thresholds. The system has issued an advisory. Monitor the agent.
3. **High risk / throttle**: Drift velocity suggests threshold violations are likely. The system recommends rate-limiting the agent.
4. **Critical risk / escalate**: Violation is projected with high confidence. Escalation to human review is recommended.

When the optimizer is enabled, the recommended intervention is the first step of the lowest-cost strategy, not just a simple threshold mapping. The confidence score indicates how reliable the recommendation is based on Monte Carlo simulation variance.

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/v1/trajectory/{agent_id}` | Current projection and policy for an agent |
| GET | `/v1/trajectory/{agent_id}/history` | Historical projections, drift, and interventions |
| GET | `/v1/trajectory/fleet` | Fleet-level summary by risk level |
| POST | `/v1/trajectory/simulate` | Simulate a strategy and get projected trajectory |

### Simulate Request Body

```json
{
  "agent_id": "agent-001",
  "strategy_name": "graduated",
  "horizon": 100
}
```

Available strategies: `no_op`, `early_advisory`, `wait_and_throttle`, `immediate_escalate`, `graduated`.
