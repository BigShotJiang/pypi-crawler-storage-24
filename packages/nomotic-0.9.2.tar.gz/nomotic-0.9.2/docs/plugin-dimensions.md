# Building Plugin Dimensions for Nomotic

The `nomotic-pro` package and any third-party dimension packages integrate
with the Nomotic SDK via Python entry points.

## Entry Point Group

Register dimensions under the `nomotic.dimensions` entry point group in
your package's `pyproject.toml`:

```toml
[project.entry-points."nomotic.dimensions"]
my_dimension = "my_package.dimensions:MyDimension"
```

## Required Interface

Your dimension class must subclass `nomotic.dimensions.GovernanceDimension`
and implement `evaluate()` returning a `DimensionScore` with a populated
`DimensionResult` in the `result` field.

Required class attributes:

    name: str           — unique dimension identifier (snake_case)
    weight: float       — default scoring weight (1.0 = neutral)
    can_veto: bool      — whether this dimension can halt evaluation
    priority: int       — orchestration priority (lower = runs earlier)
    relevant_schema_fields: list[str]  — Action fields that trigger relevance
    is_foundation: bool — True if this runs in pre-evaluation pass

## Activation

Plugin dimensions only load when:

1. The Nomotic runtime has a valid Pro or Enterprise license
2. Your package is installed in the same Python environment

The runtime logs which plugin dimensions loaded at startup.

## Adversarial Signal Detection (D20)

D20 (`AdversarialSignalDetection`) implementations should define their own
evaluator class rather than importing from `nomotic.internal`. The
`AdversarialCategoryEvaluator` dataclass in `nomotic.internal.adversarial`
serves as the interface shape:

```python
@dataclass
class AdversarialCategoryEvaluator:
    category: str
    min_history_depth: int
    detector: Callable[[Action, AgentContext], float | None]
```

`nomotic-pro` owns the production implementation. Third-party plugins should
follow this interface when building custom adversarial evaluators.
