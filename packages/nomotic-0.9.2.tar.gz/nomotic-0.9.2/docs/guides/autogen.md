## AutoGen Integration

Nomotic integrates with AutoGen to govern tool calls in AutoGen multi-agent conversations.

### Installation

```bash
pip install "nomotic[integrations]"
```

### Basic Integration

```python
from nomotic import GovernanceRuntime, RuntimeConfig
from nomotic.integrations.autogen import NomoticAutoGenAdapter

runtime = GovernanceRuntime(RuntimeConfig.from_preset("strict"))
adapter = NomoticAutoGenAdapter(runtime)

governed_tools = adapter.wrap_tools(tools, agent_id="autogen-agent")

assistant = AssistantAgent(
    name="assistant",
    llm_config={"tools": governed_tools},
)
```

## Related

- [Nomotic (GovernedToolExecutor)](GovernedToolExecutor)
- [LangGraph](LangGraph)
- [CrewAI](CrewAI)