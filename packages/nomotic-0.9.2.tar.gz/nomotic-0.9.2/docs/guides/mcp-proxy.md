## MCP Proxy

The MCP Proxy is a governance-aware proxy for Model Context Protocol (MCP) servers. It intercepts tool calls made through MCP and evaluates them through the Nomotic governance pipeline before forwarding to the upstream server.

### How It Works

```mermaid
flowchart LR
    A[Agent] -->|MCP request| P[MCP Proxy]
    P --> G[Governance\nEvaluation]
    G -->|ALLOW| U[Upstream\nMCP Server]
    G -->|DENY| R[Blocked\nResponse]
    U --> P
    P --> A
```

The proxy is transparent — the agent communicates with it exactly as it would with a real MCP server.

### Starting the MCP Proxy

```bash
nomotic serve --mcp --upstream http://localhost:8080 --port 9090
```

### Python API

```python
from nomotic.mcp_proxy import MCPProxy

proxy = MCPProxy(
    runtime=runtime,
    upstream_url="http://localhost:8080",
    port=9090,
)
proxy.start()
```

### Certificate-Required Mode

```yaml
mcp_proxy:
  require_birth_certificate: true
  governance_zone: production
```

> [!warning]
>
> In certificate-required mode, any agent without a valid Birth Certificate will be rejected at the proxy before any tool calls are evaluated.

## Related

- [HTTP-Proxy](HTTP-Proxy)
- [Nomotic (GovernedToolExecutor)](GovernedToolExecutor)
- [Agent Birth Certificates](Birth-Certificates)