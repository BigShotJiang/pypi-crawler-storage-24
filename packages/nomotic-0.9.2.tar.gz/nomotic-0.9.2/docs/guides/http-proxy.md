## HTTP Proxy

The HTTP Proxy is a governance-aware reverse proxy for HTTP-based AI services. It sits in front of any HTTP API and governs requests based on agent identity, action type, and configured policies.

### Starting the HTTP Proxy

```bash
nomotic serve --proxy --upstream http://your-api-server --port 8080
```

### Python API

```python
from nomotic.proxy import GovernanceProxy

proxy = GovernanceProxy(
    runtime=runtime,
    upstream_url="http://your-api-server",
    port=8080,
)
proxy.start()
```

### How Requests Are Governed

The proxy extracts agent identity from request headers and constructs an `Action` from the HTTP method and path. The action is evaluated before forwarding.

### Request Headers

| Header | Description |
|--------|-------------|
| `X-Agent-ID` | Agent identifier |
| `X-Governance-Token` | Optional pre-issued governance token |
| `X-Governance-Zone` | Override governance zone for this request |

> [!tip]
>
> Use `X-Governance-Token` to pass a pre-evaluated token from the governance runtime, avoiding double-evaluation for requests that were already authorized upstream.

## Related

- [MCP-Proxy](MCP-Proxy)
- [Governance-Tokens](Governance-Tokens)
- [Agent Birth Certificates](Birth-Certificates)