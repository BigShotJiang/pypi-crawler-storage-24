## OpenTelemetry Integration

Nomotic exports governance metrics and traces to any OpenTelemetry-compatible backend — Prometheus, Grafana, Jaeger, Datadog, and others.

### Installation

```bash
pip install "nomotic[otel]"
```

### Setup

```python
from nomotic.otel_exporter import OTelExporter

exporter = OTelExporter(
    runtime=runtime,
    endpoint="http://localhost:4317",  # OTLP gRPC endpoint
    service_name="my-agent-service",
)
exporter.start()
```

### Exported Metrics

| Metric | Type | Description |
|--------|------|-------------|
| `nomotic.evaluations.total` | Counter | Total governance evaluations |
| `nomotic.evaluations.denied` | Counter | Total denials |
| `nomotic.evaluations.latency` | Histogram | Evaluation latency |
| `nomotic.trust.score` | Gauge | Current trust score per agent |
| `nomotic.drift.score` | Gauge | Current drift score per agent |
| `nomotic.interrupts.total` | Counter | Total interruptions |

### Prometheus

```bash
nomotic serve --api --port 8080
# Metrics available at http://localhost:8080/metrics
```

> [!note]
>
> A Grafana dashboard configuration is included in the repository at `monitoring/grafana-governance.json`. Import it directly into Grafana after connecting your Prometheus data source.

### Traces

Governance evaluations are exported as OpenTelemetry spans, allowing you to trace the full governance pipeline — Tier 1 (Published Policy), Tier 2 (Contextual Policy), Tier 3 (Unwritten Policy) — as part of your existing distributed trace.

## Related

- [Audit Trail](Audit-Trail)
- [Configuration Overview](Configuration-Overview)