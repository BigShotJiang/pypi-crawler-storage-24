## Nomotic (GovernedToolExecutor)

`Nomotic` (also available as `GovernedToolExecutor` for backward compatibility) wraps any callable tool with governance evaluation. Every tool call goes through the full governance pipeline before executing. It is the primary integration point for adding Nomotic governance to existing agent tool pipelines.

### Basic Usage

```python
from nomotic import Nomotic

agent = Nomotic.connect("my-agent")

# Execute — governance runs automatically
result = agent.execute("write_record", target="customer_db", data=payload)
```

> [!note]
> `GovernedToolExecutor` is still available as a backward-compatible alias:
> `from nomotic import GovernedToolExecutor`

### How It Works

```mermaid
flowchart TD
    C[executor.execute call] --> AC[Construct Action]
    AC --> GE[Governance Evaluation]
    GE --> V{Verdict}
    V -->|ALLOW| TF[Call Tool Function]
    V -->|DENY| BR[Return blocked result]
    V -->|MODIFY| MT[Call tool with\nmodified params]
    V -->|ESCALATE| HW[Wait for human\napproval]
    TF --> AR[Audit Record]
    BR --> AR
    MT --> AR
```

### Async Executor

```python
from nomotic.async_executor import AsyncGovernedToolExecutor

executor = AsyncGovernedToolExecutor(runtime, agent_id="my-agent")
executor.register_tool("search", async_search_function)

result = await executor.execute("search", query="customer data")
```

### Execution Results

```python
result = agent.execute("write_record", target="customer_db", data=payload)

print(result.success)         # True/False
print(result.verdict)         # The governance verdict
print(result.output)          # Tool output (if allowed)
print(result.blocked_reason)  # Reason if denied
```

### Tool Metadata

```python
agent.register_tool(
    "delete_record",
    delete_function,
    action_type="delete",
    reversibility="irreversible",
    risk_level="high"
)
```

> [!tip]
>
> Providing `reversibility` and `risk_level` metadata gives the Cascading Impact and Stakeholder Impact dimensions better signals for more accurate governance decisions.

## Related

- [LangGraph](LangGraph)
- [CrewAI](CrewAI)
- [AutoGen](AutoGen)
- [Verdicts](Verdicts)