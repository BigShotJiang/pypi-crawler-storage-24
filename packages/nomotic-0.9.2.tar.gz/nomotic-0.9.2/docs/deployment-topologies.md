---
sidebar_position: 10
title: Deployment Topologies
---

# Deployment Topologies

Nomotic supports four deployment topologies. Each provides the same governance guarantees — the same dimensions, the same UCS computation, the same audit trail integrity. The difference is where the components run and what crosses network boundaries.

## Local install

Everything runs on the developer's machine. No infrastructure required.

### Components

- `pip install nomotic` — full runtime, 14 dimensions (D1–D14), orchestrator, UCS engine, trust calibration, audit trail
- `pip install nomotic-pro` (optional) — adds D15–D20 with a Pro or Enterprise license key

### Data flow

```
Agent → GovernanceRuntime.evaluate() → GovernanceVerdict
                  ↓
         ~/.nomotic/audit/{agent_id}.jsonl
```

All evaluation happens in-process. No network calls. No external services.

### License configuration

- No license key: OPEN tier, D1–D14 active
- Pro key in `~/.nomotic/license.key`, environment variable, or via `LicenseConfig(key="...")`: D15–D20 active if `nomotic-pro` installed
- Key validated by installed plugin (e.g., `nomotic-pro`)

### LLM configuration

Bring your own LLM (BYOL). Configure via `llm_config` in `LicenseConfig` when using LLM-dependent inferential dimensions (D16, D19, D20). Supported endpoints include Azure OpenAI, Amazon Bedrock, and local models via Ollama. The LLM endpoint is called only by dimensions that require it — D1–D14 never make LLM calls.

```python
from nomotic import GovernanceRuntime, RuntimeConfig, LicenseConfig, LLMConfig

# Local Ollama instance
runtime = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(
        key="your-license-key",
        llm_config=LLMConfig(
            endpoint="http://localhost:11434",
            model="llama3.1:70b",
        ),
    )
))
```

### What leaves the network

Nothing. Fully air-gap capable. Optional anonymous telemetry can be disabled in `~/.nomotic/config.json`.

### Audit storage

Append-only, hash-chained JSONL files in `~/.nomotic/audit/`. One file per agent. Each record contains a SHA-256 hash of the previous record, creating a tamper-evident chain.

---

## Private cloud (Docker / Kubernetes)

Runtime deployed as a service in the customer's infrastructure via `nomotic serve`.

### Components

- Container image with `nomotic` and `nomotic-pro` baked in at build time
- `nomotic serve` exposes the HTTP governance API on port 8420
- Optional: `--ui` flag enables the governance dashboard
- Optional: `--metrics` flag enables Prometheus metrics endpoint

```dockerfile
FROM python:3.12-slim
RUN pip install nomotic nomotic-pro
CMD ["nomotic", "serve", "--host", "0.0.0.0", "--port", "8420", "--ui"]
```

### Data flow

```
Agent Pod → HTTP POST /v1/evaluate → Nomotic Service → GovernanceVerdict
                                          ↓
                                   Audit Store (JSONL)
```

### License configuration

License key stored in a Kubernetes Secret and passed as an environment variable:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: nomotic-license
type: Opaque
stringData:
  license-key: "eyJ..."
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nomotic
spec:
  template:
    spec:
      containers:
        - name: nomotic
          image: your-registry/nomotic:latest
          ports:
            - containerPort: 8420
          env:
            - name: NOMOTIC_LICENSE_KEY
              valueFrom:
                secretKeyRef:
                  name: nomotic-license
                  key: license-key
```

Read the key in your entrypoint:

```python
import os
from nomotic import GovernanceRuntime, RuntimeConfig
from nomotic.license import LicenseConfig

runtime = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(key=os.environ.get("NOMOTIC_LICENSE_KEY"))
))
```

### LLM configuration

Customer-provided LLM endpoint, stays inside the VPC. Configure the endpoint URL in `llm_config`. No governance data leaves the customer's network.

```python
import os
from nomotic import GovernanceRuntime, RuntimeConfig, LicenseConfig, LLMConfig

runtime = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(
        key=os.environ.get("NOMOTIC_LICENSE_KEY"),
        llm_config=LLMConfig(
            endpoint="http://llm-service.internal:8080",
            model="gpt-4o",
        ),
    )
))
```

### What leaves the network

Nothing. No Nomotic Cloud contact required. The embedded public key in the SDK handles license validation offline.

### Audit storage

Hash-chained JSONL files stored on a persistent volume. Mount a PVC to the container's audit directory for durable storage.

---

## Nomotic Cloud

Agent ships a thin SDK client. Full evaluation runs on Nomotic-hosted infrastructure.

### Components

- Agent environment: `pip install nomotic` — SDK client
- Nomotic Cloud: hosted evaluation service at `api.nomotic.ai`
- D1–D6 (deterministic dimensions) run locally in the SDK — always active, no cloud call needed
- Full dimensional evaluation (D1–D20) sent to Nomotic Cloud via HTTPS

### Data flow

```
Agent → SDK (D1–D6 local) → HTTPS → api.nomotic.ai → Full evaluation
                                          ↓
                              Hosted audit store + dashboard
```

### License configuration

API key controls the tier — no JWT key file needed:

| API key tier | Dimensions active |
|---|---|
| FREE | D1–D6 (local only) |
| PRO | D1–D20 (14 open source + 6 nomotic-pro, evaluated on Nomotic Cloud) |
| ENTERPRISE | D1–D20 + Tier 3 (Unwritten Policy) behavioral model + hosted dashboard |

### LLM configuration

Nomotic Cloud hosts the LLM endpoint for D15–D20 evaluation and Tier 3 (Unwritten Policy) deliberation. No customer LLM configuration required.

### What leaves the network

Action metadata and governance context are sent to `api.nomotic.ai` via HTTPS for evaluation. Per-org isolation ensures no cross-organization data sharing. Dashboard, audit store, and Policy Evolution Dashboard are hosted by Nomotic.

---

## Sidecar / hybrid

Runtime runs as a sidecar container co-located with agent pods in Kubernetes. All governance calls are intra-cluster.

### Components

- Sidecar container: `nomotic serve` running alongside each agent pod
- Shared LLM service: deployed as a cluster-internal service for LLM-dependent dimensions
- Same license and plugin model as private cloud

### Data flow

```
Agent Container → localhost:8420 → Nomotic Sidecar → GovernanceVerdict
                                        ↓
                                  Audit Store (PVC)
                                        ↓
                              LLM Service (cluster-internal)
```

### Why sidecar

- **Zero-latency governance**: evaluation calls stay on localhost, no network hop
- **Pod-level isolation**: each agent gets its own governance runtime instance
- **No shared state between agents**: trust profiles, behavioral fingerprints, and audit trails are per-pod
- **Kubernetes-native**: lifecycle managed by Kubernetes, scales with the agent fleet

### License configuration

Same as private cloud — key in K8s Secret, mounted to sidecar container.

### LLM configuration

Point `LLMConfig` at the shared cluster-internal LLM service:

```python
import os
from nomotic import GovernanceRuntime, RuntimeConfig, LicenseConfig, LLMConfig

runtime = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(
        key=os.environ.get("NOMOTIC_LICENSE_KEY"),
        llm_config=LLMConfig(
            endpoint="http://llm-service.default.svc.cluster.local:8080",
            model="llama3.1:70b",
        ),
    )
))
```

### What leaves the network

Nothing leaves the cluster. LLM calls go to the shared cluster-internal service. All governance evaluation is intra-cluster.

---

## Topology selection guide

| Need | Recommended topology |
|---|---|
| Air-gap required, government/defense | Local or private cloud |
| Data sovereignty, cloud but no Nomotic | Private cloud |
| Fastest to start, no infra | Nomotic Cloud |
| Kubernetes-native, zero-latency governance | Sidecar |
| Multi-language agent fleet | Nomotic Cloud or private cloud with `nomotic serve` |
| Development and testing | Local |
| Single-agent prototype | Local |
| Multi-agent production fleet | Private cloud or sidecar |

## Fleet monitoring vs fleet coherence

> **Fleet monitoring vs fleet coherence**: Basic fleet drift monitoring
> (`FleetBehavioralMonitor`) is included in Nomotic Open — it detects when
> multiple agents drift together and alerts on correlated behavioral changes.
> The "Fleet coherence" listed in Enterprise refers to the v0.10.0 behavioral
> model's multi-agent reasoning capability, which evaluates agent interaction
> patterns, authority chains, and collective governance decisions using the
> full Bayesian + LSTM + GBM architecture. That is future work.

## Common across all topologies

Regardless of deployment topology:

- The same 14 built-in dimensions (D1–D14) are always available
- The same `nomotic-pro` plugin adds D15–D20 when licensed
- The same UCS computation produces identical scores for identical inputs
- The same hash-chained audit trail provides tamper-evident governance records
- License validation is always offline (embedded public key) — no license server dependency
- Governance never fails due to infrastructure issues — it degrades gracefully to the available dimension set
