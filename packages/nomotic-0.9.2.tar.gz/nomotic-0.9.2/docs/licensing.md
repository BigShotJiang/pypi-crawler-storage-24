---
sidebar_position: 8
title: Licensing
---

# Licensing

Nomotic uses a tiered licensing model. The open source `nomotic` package includes 14 governance dimensions (D1–D14), the full orchestrator, UCS engine, trust calibration, audit trail, and all compliance presets — no license required. A Pro or Enterprise license unlocks the 6 inferential dimensions (D15–D20) provided by the `nomotic-pro` plugin.

## How licensing works

### Plugin-based validation

The open source SDK does not validate license keys itself. It reads a key from configuration, environment variable, or file, and delegates validation to an installed plugin (such as `nomotic-pro`) discovered via the `nomotic.license` entry point group. This means:

- The SDK never needs to change when keys rotate or validation logic evolves
- Air-gap deployments work without modification
- No license server availability dependency
- No per-evaluation overhead — the key is validated once at startup and the result is cached

### Key reading priority

The SDK reads the license key from the first available source, in this order:

1. `LicenseConfig.key` — explicit key string passed in config
2. `NOMOTIC_LICENSE_KEY` — environment variable
3. Key file — `LicenseConfig.key_file` or default `~/.nomotic/license.key`

### Tier resolution at startup

When `GovernanceRuntime` initializes, it calls `LicenseGate.resolve()` exactly once. The resolved `ActivatedTier` determines which dimensions are available for the lifetime of that runtime instance.

Three outcomes are possible:

| Condition | Resolved tier | Behavior |
|-----------|---------------|----------|
| No license key provided | `OPEN` | D1–D14 active. This is the free tier, not an error. |
| Valid Pro key | `PRO` | D1–D14 always active. D15–D20 active if `nomotic-pro` is installed. |
| Valid Enterprise key | `ENTERPRISE` | D1–D20 active (with `nomotic-pro`), plus behavioral engine access. |

### What happens with no license key

No license key is the default and expected state for most users. The runtime starts in `OPEN` tier with all 14 built-in dimensions fully functional. There is no warning, no degraded state, no nag message. Governance runs at full capability on D1–D14.

### What happens with an invalid or expired key

If a license key is present but fails validation (by the installed plugin), the runtime **degrades gracefully to OPEN**:

- Governance continues with D1–D14 — it never fails hard
- The `LicenseInfo.validation_error` field contains the reason
- The runtime logs a warning with the validation error

This design ensures that a license issue never breaks production governance.

### What happens with no validator installed

If a license key is present but no validator plugin (e.g., `nomotic-pro`) is installed, the runtime runs in `OPEN` tier and logs an informational message suggesting you install `nomotic-pro` to activate Pro features.

## LicenseConfig reference

```python
from nomotic.license import LicenseConfig

config = LicenseConfig(
    key="your-license-key",              # License key string (default: None)
    key_file=Path("~/.nomotic/license.key"),  # Path to key file (default: ~/.nomotic/license.key)
    server_url="https://...",            # Nomotic Cloud URL for revocation checks (default: None)
    llm_config=None,                     # LLM endpoint config for D15–D20 when using nomotic-pro
)
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `key` | `str \| None` | `None` | License key string. `None` = free tier (OPEN). |
| `key_file` | `Path \| None` | `None` | Path to license key file. Defaults to `~/.nomotic/license.key`. |
| `server_url` | `str \| None` | `None` | Nomotic Cloud URL for revocation checks (optional). |
| `llm_config` | `Any \| None` | `None` | LLM endpoint configuration used by LLM-dependent inferential dimensions (D16, D19, D20). |

Pass `LicenseConfig` to `RuntimeConfig`:

```python
from nomotic import GovernanceRuntime, RuntimeConfig
from nomotic.license import LicenseConfig

runtime = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(key="your-license-key")
))
```

## ActivatedTier reference

```python
from nomotic.license import ActivatedTier
```

| Value | String | What it activates |
|-------|--------|-------------------|
| `ActivatedTier.OPEN` | `"open"` | D1–D14 (all built-in dimensions). Free, no license required. |
| `ActivatedTier.PRO` | `"pro"` | D1–D14 always. D15–D20 when `nomotic-pro` is installed. |
| `ActivatedTier.ENTERPRISE` | `"enterprise"` | D1–D20 (with `nomotic-pro`) plus behavioral engine access. |

### Checking the current tier

```python
runtime = GovernanceRuntime(RuntimeConfig(
    license_config=LicenseConfig(key="your-license-key")
))

# Check activated tier
print(runtime.activated_tier)  # ActivatedTier.PRO

# Check dimension availability
counts = runtime.registry.available_count()
print(counts)  # {"core": 14, "plugin": 6, "total": 20}
```

### LicenseGate convenience methods

```python
from nomotic.license import LicenseGate, LicenseConfig

gate = LicenseGate(LicenseConfig(key="your-key"))
gate.resolve()

gate.is_pro_or_above()   # True if PRO or ENTERPRISE
gate.is_enterprise()     # True if ENTERPRISE only
gate.tier                # ActivatedTier enum value
```

## License key acquisition

Obtain a license key at [nomotic.ai/license](https://nomotic.ai/license).

### License expiry and renewal

License keys have an expiration date. The `LicenseGate` provides early warning:

```python
gate = LicenseGate(LicenseConfig(key="your-key"))
warning = gate.warn_if_expired_soon(warning_days=14)
if warning:
    print(warning)  # "Nomotic license expires in 7 days. Renew at nomotic.ai/license."
```

The `warn_if_expired_soon()` method checks whether the license expires within the specified window (default: 14 days) and returns a warning string if so, or `None` otherwise. The `GovernanceRuntime` calls this at startup and logs the warning automatically.

When a key expires, the runtime degrades to OPEN on next startup — governance continues with D1–D14.

## Deployment-specific notes

### Local development

Store the key in `~/.nomotic/license.key`:

```
your-license-key-here
```

Or pass it programmatically via `LicenseConfig(key="...")`.

### Docker / Kubernetes

Pass the key as an environment variable or mount it from a Kubernetes Secret:

```yaml
# k8s-secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: nomotic-license
type: Opaque
stringData:
  license-key: "your-license-key"
```

```yaml
# deployment.yaml
env:
  - name: NOMOTIC_LICENSE_KEY
    valueFrom:
      secretKeyRef:
        name: nomotic-license
        key: license-key
```

The SDK reads `NOMOTIC_LICENSE_KEY` from the environment automatically — no additional configuration needed.

### Private cloud

Same as Kubernetes. The license key is validated by the installed plugin — no contact with Nomotic infrastructure is required for offline validation.

### Nomotic Cloud

When using Nomotic Cloud (`server_url` configured), the API key replaces the license key. The tier is derived from the API key at the server side.
