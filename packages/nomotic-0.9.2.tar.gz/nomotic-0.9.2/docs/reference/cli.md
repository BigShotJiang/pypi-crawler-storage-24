---
sidebar_position: 1
title: CLI Reference
---

# CLI Reference

:::info Auto-generated
This page is auto-generated from source. Run `python scripts/generate_cli_docs.py` to update.
:::

## Global help

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic setup

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic birth

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic init

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic hello

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic tutorial

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic serve

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic validate

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic doctor

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic diagnose

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic scorecard

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic export

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic override

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic archetype

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic archetype browse

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic archetype pull

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic archetype info

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic config

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic config set

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic config get

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic roles

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic roles list

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic roles assign

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic roles revoke

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic inspect

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic constitution

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic simulate

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic simulate fleet

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic simulate batch

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic simulate stop

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic simulate status

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic simulate report

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic new

```
/usr/local/bin/python: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```
