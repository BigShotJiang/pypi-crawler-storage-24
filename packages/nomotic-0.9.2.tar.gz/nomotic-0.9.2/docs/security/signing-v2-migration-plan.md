# Signing V2 Migration Plan (HMAC-SHA256 -> Ed25519)

## Context
Current signing paths include HMAC-SHA256 usage and key handling that limits external verification.
This plan defines a phased migration to Ed25519 while preserving compatibility where required.

## Goals
- Enable asymmetric verification for external consumers.
- Minimize disruption to existing certificates and rule artifacts.
- Keep migration explicit, auditable, and reversible during rollout.

## Constraints
- Core project favors zero mandatory runtime dependencies.
- Ed25519 support may require optional dependency packaging.
- Existing signed artifacts are currently based on v1 assumptions.

## Proposed Model
- V1: HMAC-SHA256 (existing behavior)
- V2: Ed25519 (optional, recommended for external verification)
- Dual-verify window during migration where feasible.

## Phased Rollout
### Phase 0: Inventory and policy
- Inventory all signing/verification call sites.
- Document trust boundaries and external verifier requirements.
- Define key version metadata fields.

### Phase 1: Abstraction completion
- Ensure all sign/verify operations flow through unified key abstraction.
- Remove direct `hmac` call-site bypasses in critical modules.

### Phase 2: V2 implementation behind option
- Implement Ed25519 keypair generation/sign/verify in the key abstraction layer.
- Package under optional extra (for example, `nomotic[signing]`).
- Keep V1 as fallback where optional dependency is absent.

### Phase 3: Dual verification and issuance controls
- Permit verification of both v1 and v2 artifacts.
- Introduce explicit issuer/key version tagging in signed payloads.
- Add operator controls for preferred issuance version.

### Phase 4: Reissue and cutover support
- Provide reissue tooling/workflow for existing artifacts.
- Publish migration runbook with rollback guidance.
- Track migration completeness and remove legacy issuance defaults when safe.

## Testing Requirements
- Unit tests for v1/v2 key operations and error paths.
- Compatibility tests for mixed-version verification.
- Regression tests for certificate/ruleset workflows.
- Negative tests for tampering and wrong-key verification.

## Security and Operational Criteria
- Key version is explicit in all signed artifacts.
- Verification failures are observable in logs/metrics.
- Migration decisions are traceable and documented.
- Rollback path remains available until migration completion.
