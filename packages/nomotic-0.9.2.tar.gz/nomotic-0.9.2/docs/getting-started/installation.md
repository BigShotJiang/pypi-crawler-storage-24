---
sidebar_position: 3
title: Installation
---

# Installation

## Requirements

- Python 3.11 or later
- pip (included with Python)

## Standard Install

```bash
pip install nomotic
```

## Optional Extras

```bash
# Slack integration for the approval queue
pip install nomotic[slack]

# Development tools (testing, linting, docs generation)
pip install nomotic[dev]
```

## Platform Support

Nomotic runs on Linux, macOS, and Windows. The governance runtime is pure Python with zero required external dependencies.

## Verify Installation

```bash
# Check version
nomotic --version

# Run health checks on your governance infrastructure
nomotic doctor
```

`nomotic doctor` verifies your issuer keys, certificate store, audit trail integrity, and configuration files. Use `--fix` to auto-repair common issues.

## Development Install

To install from source for development:

```bash
git clone https://github.com/nomoticai/nomotic.git
cd nomotic
pip install -e ".[dev]"
```

## Docker

The governance runtime runs in containers. The API server can be started with:

```bash
nomotic serve --host 0.0.0.0 --port 8420
```

Environment variables for container configuration:

| Variable | Default | Description |
|---|---|---|
| `NOMOTIC_HOST` | `127.0.0.1` | Bind address |
| `NOMOTIC_PORT` | `8420` | Server port |
| `NOMOTIC_DATA_DIR` | `~/.nomotic` | Data directory |
| `NOMOTIC_METRICS` | `false` | Enable Prometheus metrics |
| `NOMOTIC_LOG_LEVEL` | `INFO` | Log level |

## Securing nomotic serve

By default, `nomotic serve` runs without authentication — suitable for
local development and single-machine deployments.

For any network-accessible deployment, enable API key authentication:

```bash
nomotic serve --api-key your-secret-key
```

Clients include the key in requests via the `X-Nomotic-API-Key` header:

```
X-Nomotic-API-Key: your-secret-key
```

Authentication is enforced on **write endpoints** (POST, PATCH, DELETE) only.
Read endpoints (GET) remain open so audit and monitoring data stays queryable.

For production deployments, place `nomotic serve` behind a reverse proxy
(nginx, Caddy, AWS ALB) that handles TLS termination and network-level access
control. The API key provides application-level auth; network boundaries
provide transport security.

## Telemetry

Nomotic includes opt-in anonymous telemetry that is **disabled by default**. No data is collected unless you explicitly enable it. See [Telemetry](/tools/telemetry) for details on what is collected and how to opt in.
