# Quickstart

Get up and running with Nomotic in under 5 minutes.

## 1. Install

```bash
pip install nomotic
```

## 2. Set Up Your Organization

Run the interactive setup once per machine:

```bash
nomotic setup
```

This creates `~/.nomotic/config.json` with your organization ID, owner info, default zone, and compliance preset. It also generates your issuer key pair for signing agent certificates.

## 3. Create Your First Governed Agent

```bash
nomotic init --name my-agent --archetype customer-experience
```

This scaffolds a governed agent project with a `nomotic.yaml` governance configuration, a working `hello_nomotic.py` example script, and a `.gitignore` for local runtime data.

Run without `--archetype` to get an interactive selection menu with all 22 built-in archetypes.

## 4. Run Governance

```bash
python hello_nomotic.py
```

Sample output:

```
[nomotic] Evaluating: read → customer_records
  Verdict: ALLOW | UCS: 0.847 | Tier: 1

[nomotic] Evaluating: delete → production_database
  Verdict: DENY | UCS: 0.182 | Tier: 1 (veto: scope_compliance)
```

Every action gets a verdict (`ALLOW`, `DENY`, `ESCALATE`, `MODIFY`, or `SUSPEND`) with a Unified Confidence Score (UCS) between 0.0 and 1.0.

## 5. Open the Governance Dashboard

```bash
nomotic serve --ui
```

Open [http://localhost:8420/ui](http://localhost:8420/ui) in your browser. The dashboard shows real-time governance decisions, agent trust scores, behavioral drift alerts, and a filterable, chain-verified audit trail.

## 6. Python API

Three lines of code. Full governance.

```python
from nomotic import Nomotic

agent = Nomotic.connect("my-agent")
result = agent.execute(action="query", target="customer_records")
```

```python
print(result.verdict)    # ALLOW, DENY, ESCALATE, MODIFY, or SUSPEND
print(result.ucs)        # 0.847
print(result.allowed)    # True
```

`Nomotic.connect()` handles everything behind the scenes: it loads your agent's certificate and archetype from the `nomotic.yaml` created in step 3, creates the governance runtime, and configures the audit trail. Every call to `execute()` evaluates all 14 dimensions (D1–D14), updates trust, and writes to the audit log.

### Execute a Tool With Governance

To evaluate governance and execute a tool only when approved:

```python
from nomotic import Nomotic

agent = Nomotic.connect("my-agent")
result = agent.execute(
    action="query",
    target="customer_records",
    tool_fn=lambda: db.execute("SELECT * FROM customers"),
)

if result.allowed:
    print(result.data)    # tool output
else:
    print(result.reason)  # denial explanation
```

If governance approves, the tool runs and `result.data` contains its return value. If denied, the tool never executes and `result.reason` explains why.

### Governance-Only Check

To check governance without executing anything:

```python
result = agent.check(action="delete", target="production_database")
print(result.verdict)  # DENY
print(result.reason)   # "Scope violation: target not in authorized boundaries"
```

### Reading the Result

Every `ExecutionResult` includes:

```python
result.allowed           # bool — did governance approve?
result.verdict           # "ALLOW", "DENY", "ESCALATE", "MODIFY", or "SUSPEND"
result.ucs               # float — Unified Confidence Score (0.0–1.0)
result.tier              # int — which evaluation tier decided (1=Published Policy, 2=Contextual Policy, 3=Unwritten Policy)
result.trust_before      # float — trust score before this action
result.trust_after       # float — trust score after this action
result.trust_delta       # float — change in trust
result.dimension_scores  # dict — per-dimension scores
result.vetoed_by         # list — dimensions that vetoed (empty if allowed)
result.reason            # str — human-readable explanation
result.data              # any — tool return value (None if denied or no tool_fn)
result.duration_ms       # float — evaluation time in milliseconds
```

## What dimensions are active

A fresh `pip install nomotic` runs with **14 built-in dimensions** (D1–D14):
6 deterministic (Tier 1) and 8 probabilistic (Tier 2). These cover the full
Published Policy and Contextual Policy layers and are available at no cost.

To activate the 6 inferential dimensions (D15–D20) and unlock Pro features:

1. Obtain a license key at nomotic.ai/license
2. `pip install nomotic-pro`
3. Add your key to `~/.nomotic/config.json` or pass it at runtime:

   ```python
   from nomotic import GovernanceRuntime, RuntimeConfig, LicenseConfig

   runtime = GovernanceRuntime(RuntimeConfig(
       license_config=LicenseConfig(key="your-license-key")
   ))
   print(runtime.activated_tier)  # ActivatedTier.PRO
   ```

The runtime logs which dimensions are active at startup. Without a license,
governance runs at full capability on D1–D14 — you see exactly which dimensions
are inactive and what they would have evaluated.

### What's included vs what requires nomotic-pro

Governance works and is useful with 14 dimensions. The open source `nomotic`
package includes the full orchestrator, UCS engine, trust calibration, audit
trail, behavioral fingerprinting, drift detection, and all 14 compliance
presets. `nomotic-pro` adds depth — reversibility awareness, data sensitivity
classification, delegation chain validation, goal-action alignment, and
adversarial signal detection — for scenarios that need it.

See [Runtime Open vs Pro](/runtime-lite-vs-pro) for a detailed comparison,
including a concrete example showing how the UCS changes with 14 vs 20
dimensions on the same action.

## 7. Advanced: GovernanceRuntime API

For fine-grained control over the governance pipeline, use the runtime directly:

```python
from nomotic import GovernanceRuntime, Action, AgentContext, TrustProfile

runtime = GovernanceRuntime()

runtime.configure_scope(
    agent_id="my-agent",
    scope={"read", "write", "query"},
    boundaries={"customer/*", "order/*"},
)

action = Action(
    agent_id="my-agent",
    action_type="write",
    target="customer/profile",
    parameters={"field": "email"},
)

context = AgentContext(
    agent_id="my-agent",
    trust_profile=TrustProfile(agent_id="my-agent"),
)

result = runtime.evaluate(action, context)
print(f"Verdict: {result.verdict}")
print(f"UCS: {result.ucs:.3f}")
print(f"Tier: {result.tier}")
```

The `GovernanceRuntime` gives you direct access to dimension configuration, trust calibration, behavioral fingerprints, drift monitoring, and the full evaluation pipeline. Most integrations should start with `Nomotic.connect()` and move to the runtime API only when they need this level of control.

## Next Steps

- [Integration Guides](/guides/) — LangGraph, CrewAI, OpenAI, and Claude framework integrations
- [Architecture](/architecture/overview) — how the 14 dimensions (D1–D14), three-tier evaluation, and trust model work
- [Behavioral Control Plane](/architecture/behavioral-control-plane) — the drift taxonomy, behavioral contracts, and semantic anchoring
- [CLI Reference](/reference/cli) — all 50+ CLI commands
- [API Reference](/reference/api) — REST API endpoints
