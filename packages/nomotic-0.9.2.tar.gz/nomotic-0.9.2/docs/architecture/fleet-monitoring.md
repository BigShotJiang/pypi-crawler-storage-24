# Fleet Behavioral Monitoring

The `FleetBehavioralMonitor` detects multi-agent drift patterns that no single-agent monitor can see. It sits above individual agent monitoring and detects three drift scopes:

- **Fleet drift**: The fleet's aggregate behavioral distribution shifts even when no individual agent triggers an alert.
- **Correlated drift**: Multiple agents drift in the same direction within the same time window, suggesting a shared upstream cause.
- **Coordinated drift**: Drift propagates through an agent interaction chain, with potential amplification at each hop.

For full details on drift scopes, detection algorithms, and configuration, see the [Fleet Drift Scopes](../features/fleet-drift-scopes.md) feature documentation.

## Policy Coordination

When the fleet monitor detects coordinated or correlated drift and the policy optimizer is enabled, the system automatically evaluates cross-agent intervention strategies via `FleetBehavioralMonitor.on_alert_with_policy_coordination()`.

- **Coordinated drift alerts** trigger `PolicyOptimizer.optimize_chain()`, which evaluates intervening at the root of a propagation chain rather than on each agent independently.
- **Correlated drift alerts** trigger `PolicyOptimizer.optimize_correlated()`, which compares fixing the shared upstream cause against independent per-agent intervention.

Fleet-scope alerts (aggregate distribution shift) do not trigger policy coordination.

For the optimization algorithms, cost modeling, and worked examples, see [Sequential Optimization — Multi-Agent Policy Coordination](sequential-optimization.md#multi-agent-policy-coordination).
