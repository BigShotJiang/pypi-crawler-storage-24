# Runtime Decomposition Roadmap

## Context
`src/nomotic/runtime.py` currently concentrates many responsibilities in `GovernanceRuntime`.
This document defines an incremental decomposition plan that preserves behavior and testability.

## Goals
- Reduce coupling and cognitive load in `GovernanceRuntime`.
- Preserve existing external behavior and configuration surfaces.
- Keep changes mergeable in small, test-backed slices.

## Non-Goals
- Immediate full rewrite.
- Public API breakage in a single release.

## Decomposition Targets
1. `CertificateManager`
- Responsibility: issue/revoke/renew/validate certificate lifecycle orchestration.
- Candidate methods: certificate issuance, revocation, validation helpers.

2. `OverrideCoordinator`
- Responsibility: multi-sig override request lifecycle and approval state.
- Candidate methods: submit/approve/reject override flows.

3. `DelegationManager`
- Responsibility: delegation rules, inheritance, and delegated capability checks.
- Candidate methods: delegation grant/revoke/evaluate.

4. `LifecycleHookDispatcher`
- Responsibility: pre/post action hook registration and dispatch.
- Candidate methods: hook registration and call orchestration.

5. `FleetMonitor`
- Responsibility: fleet-level aggregates and monitoring summaries.
- Candidate methods: rollup and reporting helpers.

## Migration Strategy
Use behavior-preserving slices with characterization tests before extraction.

### Slice 1: Lifecycle hooks
- Add characterization tests around current hook behavior.
- Extract hook methods into `LifecycleHookDispatcher`.
- Inject dispatcher into runtime and keep old entry points delegating.

### Slice 2: Certificate lifecycle
- Add tests around certificate issuance/revocation edge cases.
- Extract to `CertificateManager` and delegate from runtime.

### Slice 3: Overrides and delegations
- Split override and delegation concerns into dedicated managers.
- Preserve data contracts and event formats.

### Slice 4: Fleet monitoring
- Move aggregate/reporting methods to `FleetMonitor`.
- Keep runtime as orchestrator only.

## Guardrails
- No public API changes without explicit deprecation notes.
- One responsibility per PR when possible.
- Each extraction PR must include:
  - before/after behavior tests,
  - touched-surface coverage report,
  - migration notes in PR body.

## Success Criteria
- `GovernanceRuntime` orchestrates rather than owns implementation details.
- Extracted managers have focused unit tests.
- No behavior regressions in existing integration/adversarial suites.
