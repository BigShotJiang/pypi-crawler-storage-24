---
title: Intervention Costs
---

# Intervention Cost Model

The Intervention Cost Model quantifies the cost of each governance intervention type, incorporating fatigue effects and strategy failure detection.

## Base Costs per Intervention Type

| Intervention | Base Cost | Base Variance | Description |
|---|---|---|---|
| advisory | 0.01 | 0.005 | Low-cost informational nudge |
| throttle | 0.08 | 0.03 | Rate-limiting agent actions |
| tighten | 0.12 | 0.04 | Tightening contract thresholds |
| escalate | 0.15 | 0.05 | Escalation to human review |
| quarantine | 0.25 | 0.08 | Full agent quarantine |

Costs are modeled as distributions (mean + variance) to support Monte Carlo uncertainty propagation in the optimization pipeline.

## Fatigue Effects

Repeated interventions of the same type on the same agent incur exponentially increasing costs to model operator/system fatigue:

```
fatigue_multiplier = fatigue_base ^ recent_same_type_count
```

- **fatigue_base**: 1.5 (configurable)
- **fatigue_window**: last 10 interventions considered

For example, if an agent has received 3 recent advisories, the next advisory costs `1.5^3 = 3.375x` the base cost. This incentivizes the optimizer to try different intervention strategies rather than repeating the same one.

## Strategy Failure Detection

When the same intervention type is applied repeatedly (>= `strategy_failure_threshold`, default 3) without drift reduction, the model flags a strategy failure. This signal can be used to:

- Switch to a different intervention type
- Escalate to a higher-authority intervention
- Alert operators that the current governance strategy is ineffective

## Integration with Monte Carlo Optimization

The `InterventionCost.sample()` method draws from a normal distribution (clamped to >= 0) around the fatigue-adjusted mean. This enables Monte Carlo simulations to propagate cost uncertainty through the decision pipeline:

1. Sample intervention costs for each candidate action
2. Combine with projected drift reduction benefit
3. Select the action that maximizes expected net benefit

## Cost Profile Override

When a `CostProfile` is available and the intervention type is `"escalate"`, the model uses the profile's `escalation_latency_cost` and `escalation_interruption_cost` instead of the base escalation cost. This allows per-agent or per-context escalation cost tuning.

## Configuration

All parameters are configurable via `CostModelConfig`:

- `base_costs`: Per-type base cost mapping
- `base_variances`: Per-type variance mapping
- `fatigue_base`: Exponential base for fatigue growth
- `fatigue_window`: Number of recent interventions to consider
- `strategy_failure_threshold`: Count of same-type interventions that triggers failure detection
