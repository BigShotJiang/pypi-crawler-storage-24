# Tiered Escalation Paths

## The Problem: Not Every Escalation Needs a Human

Traditional governance systems treat escalation as binary: either the system
decides autonomously or it routes to a human reviewer. This wastes human
attention on cases that cheaper automated steps could resolve.

Tiered escalation inserts lower-cost resolution steps between "ambiguous
decision" and "full human review." Each step has a cost and an expected
resolution rate. The system walks through steps cheapest-first, stopping as
soon as one resolves the ambiguity. VOI governs each step: if the remaining
VOI doesn't justify the next step's cost, the system skips to a fallback
verdict instead.

## Default 3-Step Path

| Step | Type | Cost | Expected Resolution Rate | Description |
|------|------|------|--------------------------|-------------|
| 1 | `request_context` | 0.02 | 30% | Request additional context from the agent |
| 2 | `secondary_check` | 0.08 | 40% | Re-evaluate with adjusted thresholds (+-5%) |
| 3 | `human_review` | 0.20 | 90% | Route to a human reviewer |

Steps are ordered by cost. The system never tries an expensive step when a
cheaper one would suffice.

## How VOI Governs Each Step

Before attempting each step, the system checks:

```
if voi_result.voi_score < step.cost:
    skip to fallback verdict
```

This means a low-VOI escalation (e.g., VOI = 0.05) will attempt
`request_context` (cost 0.02) but skip `secondary_check` (cost 0.08) and
`human_review` (cost 0.20). The system falls back to an autonomous decision
rather than spending more than the information is worth.

## Step Resolution Logic

### request_context

Checks whether the action's `parameters["additional_context"]` contains
information that resolves the ambiguity. Additional context provides a
confidence bump to the UCS. If the adjusted UCS moves outside the ambiguity
zone (above 0.65 or below 0.35), the step resolves.

### secondary_check

Re-evaluates the UCS against slightly relaxed thresholds (+-5% of the
ambiguity zone boundaries). If the UCS is within 5% of a clear verdict,
the secondary check resolves it. This catches borderline cases that are
"almost clear" but fell into the ambiguity zone by a small margin.

### human_review

Always "resolves" by deferring to a human reviewer. The `EscalationResult`
marks this as `resolved_at_step="human_review"` with verdict `ESCALATE`.
The human's decision is the final word.

## Fallback Verdicts by Cost Profile

When the escalation path exhausts without resolution (or VOI is too low to
justify any step), the system uses a fallback verdict derived from the
`CostProfile`:

| Cost Profile | false_allow_cost | Fallback Verdict | Rationale |
|-------------|-----------------|------------------|-----------|
| CONSERVATIVE | >= 0.6 (HIGH/CRITICAL) | DENY | High stakes — fail safe |
| PERMISSIVE | < 0.6 (LOW/MODERATE) | ALLOW | Low stakes — fail open |

If no `CostProfile` is provided, the `EscalationPath.fallback_verdict`
field is used directly (default: `DENY`).

## Configuring Custom Paths in Behavioral Contracts

Contracts can carry custom escalation paths via the `escalation_path` field:

```python
from nomotic.contract import BehavioralContract
from nomotic.escalation import EscalationPath, EscalationStep

custom_path = EscalationPath(
    steps=[
        EscalationStep("secondary_check", cost=0.05, expected_resolution_rate=0.5),
        EscalationStep("human_review", cost=0.15, expected_resolution_rate=0.9),
    ],
    fallback_verdict="ALLOW",
)

contract = BehavioralContract(
    contract_id="c-1",
    version=1,
    agent_id="agent-1",
    created_at=0.0,
    escalation_path=custom_path.to_dict(),
)
```

The `TierThreeDeliberator` retrieves the contract's escalation path via
its `escalation_path_accessor` and passes it to the `EscalationManager`.

## Worked Example

An agent requests to update a customer record. The UCS lands at 0.52 —
inside the ambiguity zone. VOI computes 0.35 (moderate).

1. **request_context** (cost 0.02): VOI 0.35 >= 0.02, so attempt it.
   The action has no `additional_context` in parameters. Not resolved.

2. **secondary_check** (cost 0.08): VOI 0.35 >= 0.08, so attempt it.
   UCS 0.52 is not within 5% of the upper boundary (0.65 - 0.05 = 0.60).
   Not resolved.

3. **human_review** (cost 0.20): VOI 0.35 >= 0.20, so attempt it.
   Resolves by deferring to human. Verdict: ESCALATE.

If the UCS had been 0.61 instead, step 2 (secondary_check) would have
resolved it as ALLOW, and the human reviewer would never be bothered.

## Integration with Tier 3 (Unwritten Policy)

The `EscalationManager` is plugged into `TierThreeDeliberator` via
the `escalation_manager` constructor parameter. When VOI says
`should_escalate=True`, the deliberator delegates to the escalation
manager before falling back to a direct ESCALATE verdict. If no
escalation manager is configured, behavior is unchanged from before.
