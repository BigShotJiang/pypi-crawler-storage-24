---
title: Unified Confidence Score (UCS)
---
## Unified Confidence Score (UCS)

The Unified Confidence Score is a single numeric value between 0.0 and 1.0 representing Nomotic's overall confidence that an agent action should be permitted. Every governance decision produces a UCS. It is the primary signal used to determine verdict.

### How It's Calculated

UCS is a weighted average of scores across all active governance dimensions — 14 dimensions open source, 20 with nomotic-pro installed. Each dimension scores independently from 0.0 to 1.0.

```
UCS = Σ (dimension_score × dimension_weight) / Σ weights
```

Dimensions with higher weights have more influence on the final score. Weights are set by the active preset and can be overridden per-agent in `nomotic.yaml`.

```mermaid
flowchart LR
    D1[Scope Compliance] --> UCS
    D2[Authority Verification] --> UCS
    D3[Resource Boundaries] --> UCS
    D4[...10 more dimensions] --> UCS
    UCS --> V{Verdict}
    V -->|≥ allow threshold| ALLOW
    V -->|≤ deny threshold| DENY
    V -->|ambiguous zone| T3[Tier 3 Review]
```

### Thresholds and Verdicts

| UCS Range | Typical Verdict |
|-----------|-----------------|
| 0.80 – 1.0 | ALLOW |
| 0.60 – 0.79 | ALLOW or MODIFY |
| 0.40 – 0.59 | ESCALATE |
| 0.0 – 0.39 | DENY |

Thresholds are configurable per preset. The `ultra_strict` preset uses a higher allow threshold than `standard`.

### Veto Overrides

> [!warning]
>
> A veto dimension scoring 0.0 results in immediate DENY regardless of UCS. A high UCS does not protect against a veto.

### Reading UCS in Output

```bash
nomotic test my-agent --action write
```

```
Verdict:  ALLOW
UCS:      0.847
Tier:     1 (fast gate)
```

### Programmatic Access

```python
verdict = runtime.evaluate(action, context)
print(f"UCS: {verdict.ucs:.3f}")
print(f"Verdict: {verdict.verdict}")

# Individual dimension scores
for score in verdict.dimension_scores:
    print(f"  {score.dimension_name}: {score.score:.3f}")
```

## Related

- [14 Dimensions](14-Dimensions)
- [Three-Tier Evaluation](Three-Tier-Evaluation)
- [Compliance Presets](Compliance-Presets)
- [Verdicts](Verdicts)