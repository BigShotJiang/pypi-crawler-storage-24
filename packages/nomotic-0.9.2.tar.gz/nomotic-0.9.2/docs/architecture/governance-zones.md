## Governance Zones

Governance zones define the operational environment for an agent. They allow different governance strictness for development, staging, and production contexts without maintaining separate configs.

### Built-In Zones

| Zone | Description |
|------|-------------|
| `development` | Relaxed governance for local development and testing |
| `staging` | Moderate governance mirroring production behavior |
| `production` | Full governance enforcement |
| `sandbox` | Isolated environment with maximum restrictions |

### Configuring a Zone

```yaml
agents:
  my-agent:
    governance_zone: production
```

### Zone Overrides

```yaml
governance_zones:
  development:
    allow_threshold: 0.5
    audit_level: minimal
  production:
    allow_threshold: 0.75
    audit_level: full
    require_birth_certificate: true
```

> [!warning]
>
> Agents operating outside their declared governance zone can be flagged by the Isolation Integrity dimension. Always ensure `governance_zone` in the config matches the actual deployment environment.

### Zone in Birth Certificates

The governance zone is recorded in the agent's Birth Certificate at creation time and becomes part of its cryptographic identity.

## Related

- [Agent Birth Certificates](Birth-Certificates)
- [Configuration Overview](Configuration-Overview)
- [Organization Governance](Organization-Governance)

---

# Page: Verdicts

## Verdicts

Every governance evaluation produces one of five verdicts.

| Verdict | Meaning |
|---------|---------|
| `ALLOW` | Action is permitted. Proceed. |
| `DENY` | Action is not permitted. Do not proceed. |
| `MODIFY` | Action is permitted with modifications. Proceed with reduced scope or additional constraints. |
| `ESCALATE` | Action requires human review before proceeding. |
| `SUSPEND` | Agent is suspended. No further actions permitted until reviewed. |

### ALLOW

The action passed governance. UCS exceeded the allow threshold and no vetoes fired.

```python
if verdict.verdict == Verdict.ALLOW:
    result = tool.execute(action)
```

### DENY

The action failed governance. Either a veto dimension fired (Tier 1 — Published Policy) or UCS fell below the deny threshold (Tier 2 — Contextual Policy).

```python
if verdict.verdict == Verdict.DENY:
    print(f"Denied: {verdict.reasoning}")
    print(f"Vetoed by: {verdict.vetoed_by}")
```

### MODIFY

The action is permitted but with constraints. The verdict includes a `modifications` dict describing what must change.

```python
if verdict.verdict == Verdict.MODIFY:
    modifications = verdict.modifications
    # e.g. {"reduce_scope": True, "require_confirmation": True}
```

### ESCALATE

The action requires human review. Returned when the Human Override dimension vetoes, when trust is too low for Tier 3 (Unwritten Policy) to decide, or when configured escalation rules trigger.

### SUSPEND

The agent has been suspended. Returned when multiple serious violations occur in sequence or when configured suspension thresholds are exceeded.

> [!warning]
>
> A SUSPEND verdict means the agent cannot take any further actions until a human reviews and reinstates it via `nomotic inspect <agent-id>`.

### Accessing Verdict Details

```python
verdict = runtime.evaluate(action, context)

print(verdict.verdict)            # The verdict enum
print(verdict.ucs)                # 0.0–1.0
print(verdict.tier)               # Which tier decided (1, 2, or 3)
print(verdict.reasoning)          # Human-readable explanation
print(verdict.vetoed_by)          # List of dimensions that vetoed
print(verdict.dimension_scores)   # All active dimension scores (14 open source, up to 20 with nomotic-pro)
```

## Related

- [UCS](UCS)
- [Three-Tier Evaluation](Three-Tier-Evaluation)
- [Interrupt Authority](Interrupt-Authority)