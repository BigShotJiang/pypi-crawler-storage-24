---
sidebar_position: 2
title: Trust Model
---

# Trust Model

Trust in Nomotic is dynamic — it evolves with every action an agent takes. Trust scores directly influence governance decisions: high-trust agents get faster evaluations, while low-trust agents face escalation.

## Trust Zones

| Zone | Trust Score | Behavior |
|---|---|---|
| High trust | > 0.65 | Fast-path evaluation. Tier 3 (Unwritten Policy) resolves ambiguous cases as ALLOW. |
| Deliberation | 0.35 – 0.65 | Full evaluation. Ambiguous cases go to Tier 3 (Unwritten Policy). |
| Low trust | < 0.35 | Strict evaluation. Tier 3 (Unwritten Policy) escalates ambiguous cases. Interrupt authority active. |

## TrustProfile

Each agent has a `TrustProfile` that tracks:

- **`overall_trust`** — the aggregate trust score (0.0–1.0)
- **Per-dimension trust** — trust broken down by governance dimension
- **Trust trajectory** — historical trust scores for trend analysis

## Trust Calibration

Trust updates after every governance evaluation and action completion:

| Event | Trust Delta | Rationale |
|---|---|---|
| Action completed successfully | +0.01 | Trust is earned incrementally |
| Governance denial (DENY) | -0.05 | Violations are costly |
| Escalation resolved (approved) | +0.005 | Partial credit for escalated-then-approved |
| Time decay | -0.001/day | Trust erodes without activity |

### Asymmetric Design

The 5:1 penalty-to-reward ratio is intentional. A single violation costs as much trust as five successful completions earn. This reflects the asymmetric risk profile of autonomous agents: one bad action can cause disproportionate harm.

## Trust and UCS

Trust modulates the UCS score:
- Higher trust → UCS scores are slightly elevated (trust bonus)
- Lower trust → UCS scores face additional drag

This creates a virtuous/vicious cycle: well-behaved agents earn higher trust, which makes borderline actions more likely to pass, which further builds trust. Misbehaving agents lose trust, making even routine actions face stricter scrutiny.

## Cost-Sensitive Trust Interactions

CostProfiles affect the trust-UCS-verdict feedback loop by changing the decision boundaries that determine governance outcomes:

- **Trust influences UCS** — higher trust gives a slight UCS bonus, lower trust adds drag.
- **CostProfile sets the thresholds** — the optimal allow/deny thresholds are derived from the cost profile rather than static configuration. A CONSERVATIVE profile (high false-allow cost) produces a low allow threshold, meaning the system requires less confidence to allow but has a very narrow ambiguity zone.
- **Verdicts update trust** — DENY verdicts reduce trust (asymmetric 5:1 penalty), ALLOW verdicts build trust incrementally.

This creates a coupled system: an agent's trust score modulates its UCS, which is then evaluated against cost-derived thresholds. A high-trust agent with a CONSERVATIVE profile may still face strict scrutiny because the cost profile keeps the ambiguity zone narrow — even though trust gives a UCS bonus, the cost-derived boundaries ensure appropriate caution.

Zone multipliers in the CostProfile (e.g., `zone_multiplier=2.0` for production) amplify the effective costs, which narrows the ambiguity zone further. This means production environments require more decisive signals — actions are either clearly allowed or clearly denied, with fewer cases falling into deliberation.

See [Cost-Sensitive Governance](./cost-sensitive-governance.md) for full details on CostProfile fields, threshold derivation, and configuration.

## Interrupt Threshold

When trust drops below the interrupt threshold (default: 0.2), the interrupt authority becomes active. This means the runtime can halt the agent mid-execution if behavioral monitoring detects anomalies during action execution.

```
governance.interrupt_threshold: 0.2  # in nomotic.yaml
```
