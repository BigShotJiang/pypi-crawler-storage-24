#!/usr/bin/env python3
import subprocess
import sys
from pathlib import Path
from mcmicroprep.microscopes.base import MicroscopeHandler


class OlympusHandler(MicroscopeHandler):
    name = "olympus"

    def validate_dataset(self, image_root: Path) -> None:
        missing = []
        for slide in image_root.iterdir():
            if not slide.is_dir() or slide.name in [
                "dataset",
                "templates",
                "microscopes",
            ]:
                continue
            has_frames = any(
                path.is_dir() and path.name.endswith("_frames")
                for path in slide.rglob("*_frames")
            )
            if not has_frames:
                missing.append(slide)

        if missing:
            missing_str = "\n".join(f"- {p}" for p in missing)
            raise ValueError(
                "Olympus dataset validation failed. No '*_frames' folders found in:\n"
                f"{missing_str}"
            )

    def restructure_raw(self, image_root: Path):
        for slide in image_root.iterdir():
            if not slide.is_dir() or slide.name in [
                "dataset",
                "templates",
                "microscopes",
            ]:
                continue
            raw = slide / "raw"
            misc = slide / "misc_files"
            raw.mkdir(exist_ok=True)
            misc.mkdir(exist_ok=True)

            frames_dirs = [
                p
                for p in slide.rglob("*_frames")
                if p.is_dir() and raw not in p.parents and p != raw
            ]
            for frames_dir in frames_dirs:
                dest = raw / frames_dir.name
                if frames_dir == dest:
                    continue
                if dest.exists():
                    raise ValueError(
                        "Olympus restructure failed due to conflicting frames directory "
                        f"names: '{frames_dir}' and '{dest}'"
                    )
                dest.parent.mkdir(exist_ok=True)
                frames_dir.rename(dest)

            for item in list(slide.iterdir()):
                if item.is_dir() and item.name.endswith("_frames"):
                    item.rename(raw / item.name)
                elif item.name not in ["raw", "misc_files"]:
                    item.rename(misc / item.name)

            # Only run companion script if missing the OME file
            for frame in raw.iterdir():
                ome = frame / "image.companion.ome"
                if not ome.exists():
                    # Invoke installed module, not script in cwd
                    subprocess.run(
                        [
                            sys.executable,
                            "-m",
                            "mcmicroprep.companion_script",
                            str(frame),
                        ],
                        check=True,
                    )

    def params_template(self) -> dict:
        # Not used when file-based params selection is preferred
        return {}
