"""Shared constants for MCP handlers."""

# Maximum content length per field — prevents memory exhaustion.
MAX_CONTENT_LENGTH = 100_000

# Maximum token budget for recall/context assembly.
MAX_TOKEN_BUDGET = 100_000

# Batch remember limits.
MAX_BATCH_SIZE = 20
MAX_BATCH_TOTAL_CHARS = 500_000
