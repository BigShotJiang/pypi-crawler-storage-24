# HITL Microservice — Implementation Plan

## Context

AI developers lack a frictionless way to collect human preference data during model iteration. Existing tools are either cloud-heavy (LangSmith, Humanloop), enterprise-scale (Labelbox, Scale AI), or platform-y (Argilla). This project fills the gap: a local-first, pip-installable tool that lets a solo developer go from "bad model output" to "DPO training example" in under a minute.

**Positioning:** "The SQLite of human feedback" — zero config, instant value.

---

## Distribution Strategy

**Both pip package + open-source GitHub repo.** pip for frictionless install, GitHub for trust and contributions.

- Package name: `feedloop` (appears available on PyPI — register early)
- Import name: `feedloop` regardless of pip name
- License: MIT
- Versioning: SemVer, start at `0.1.0`

---

## Architecture

```
Developer's Python script
       │
       │  feedloop.start()       → spawns FastAPI in a daemon thread
       │  feedloop.compare(...)  → inserts row into SQLite, returns immediately
       │  feedloop.export(...)   → reads SQLite, writes JSONL
       │
  ┌────▼──────────────────────────────────┐
  │  FastAPI Server (background thread)    │
  │                                        │
  │  GET  /api/pending   → next comparison │
  │  POST /api/feedback  → record choice   │
  │  GET  /api/stats     → progress        │
  │  GET  /api/export    → download JSONL  │
  │  GET  /*             → React static    │
  │                                        │
  │  SQLite (~/.feedloop/feedloop.db, WAL mode)    │
  └────┬──────────────────────────────────┘
       │
  ┌────▼──────────────────────────────────┐
  │  React UI (static files)               │
  │  Polls /api/pending every 1s           │
  │  Side-by-side comparison + shortcuts   │
  └────────────────────────────────────────┘
```

**Key design decisions:**
- Background daemon thread (not subprocess) — shares SQLite, dies when script exits
- SQLite WAL mode for concurrent reads across threads
- `atexit` handler for graceful shutdown
- Position randomization (shuffle A/B) to reduce bias — stored per row for correct export

---

## Project Structure

```
feedloop/
├── pyproject.toml
├── LICENSE (MIT)
├── README.md
├── Makefile
├── src/
│   └── feedloop/
│       ├── __init__.py        # Public API: start(), compare(), export(), wait(), stop(), status()
│       ├── __main__.py        # python -m feedloop CLI entry
│       ├── _server.py         # FastAPI app + uvicorn background thread
│       ├── _db.py             # SQLite schema, CRUD, WAL mode
│       ├── _models.py         # Pydantic models
│       ├── _routes.py         # API endpoints
│       ├── _export.py         # SQLite → JSONL
│       ├── _config.py         # Defaults (port, db path)
│       ├── _static/           # React build output (bundled in wheel)
│       └── py.typed
├── frontend/
│   ├── package.json
│   ├── vite.config.ts         # outputs to ../src/feedloop/_static/
│   ├── tsconfig.json
│   ├── index.html
│   └── src/
│       ├── main.tsx
│       ├── App.tsx
│       ├── api.ts
│       ├── components/
│       │   ├── ComparisonView.tsx
│       │   ├── ResponseCard.tsx
│       │   ├── PromptHeader.tsx
│       │   ├── FeedbackBar.tsx
│       │   ├── ProgressBar.tsx
│       │   ├── ExportPanel.tsx
│       │   └── EmptyState.tsx
│       └── hooks/
│           └── useComparison.ts
└── tests/
    ├── test_db.py
    ├── test_routes.py
    ├── test_sdk.py
    └── test_export.py
```

---

## SDK API Design

```python
import feedloop

# Launch server + open browser
feedloop.start(port=7856, db_path=None, open_browser=True)

# Submit comparisons (non-blocking)
cid = feedloop.compare(
    prompt="Explain quantum computing",
    outputs=["Response A text", "Response B text"],
    metadata={"model_a": "gpt-4", "model_b": "claude-3"}
)

# Optionally block until rated
result = feedloop.wait(cid, timeout=60)

# Check progress
feedloop.status()  # {"pending": 5, "completed": 10, "total": 15}

# Export DPO-formatted data
feedloop.export("preferences.jsonl", session_id=None, format="dpo")

# Cleanup
feedloop.stop()
```

**Example end-to-end usage:**
```python
import feedloop

feedloop.start()

for prompt in test_prompts:
    a = model_a.generate(prompt)
    b = model_b.generate(prompt)
    feedloop.compare(prompt=prompt, outputs=[a, b])

input("Rate all comparisons in the browser, then press Enter...")
feedloop.export("my_preferences.jsonl")
```

---

## Data Model (SQLite)

```sql
CREATE TABLE comparisons (
    id            TEXT PRIMARY KEY,       -- UUID
    session_id    TEXT NOT NULL,
    prompt        TEXT NOT NULL,
    output_a      TEXT NOT NULL,
    output_b      TEXT NOT NULL,
    display_order TEXT NOT NULL,          -- 'ab' or 'ba' (position randomization)
    status        TEXT NOT NULL DEFAULT 'pending',  -- pending | completed | skipped
    chosen        TEXT,                  -- 'a' | 'b' | NULL
    created_at    TEXT NOT NULL,
    completed_at  TEXT,
    metadata      TEXT                   -- JSON blob
);
```

**DPO export format:**
```json
{"prompt": "...", "chosen": "...", "rejected": "..."}
```

---

## Frontend Design

Three states:
1. **Empty** — "Waiting for comparisons... Run `feedloop.compare()` in your script." (polls every 1s)
2. **Comparison** — Side-by-side A/B with keyboard shortcuts (`1` = A, `2` = B, `S` = skip), progress bar, markdown rendering
3. **Done** — Summary stats + download JSONL button

Tech: Vite + React + TypeScript, minimal CSS (no Tailwind), `react-markdown` for output rendering.

---

## Build & Packaging

- **Build backend:** Hatchling (handles `src/` layout, includes `_static/` in wheel)
- **Frontend build:** `cd frontend && npm run build` → outputs to `src/feedloop/_static/`
- **Python build:** `python -m build` → wheel includes static files
- **Dependencies:** `fastapi>=0.100`, `uvicorn[standard]>=0.20`, `pydantic>=2.0`
- **Python target:** `>=3.10` (for `X | Y` union syntax)

---

## Phased Build Order

### Phase 1: Foundation
- [x] `pyproject.toml` + directory structure
- [x] `_db.py` — SQLite schema, WAL mode, CRUD functions
- [x] `_models.py` — Pydantic models
- [x] `tests/test_db.py`

### Phase 2: Backend API
- [x] `_routes.py` — API endpoints
- [x] `_server.py` — FastAPI app, CORS, static mount
- [x] `_export.py` — JSONL export
- [x] `tests/test_routes.py`

### Phase 3: SDK
- [x] `__init__.py` — public API (start, compare, export, wait, stop, status)
- [x] Background thread server launch
- [x] `__main__.py` — CLI entry
- [ ] `tests/test_sdk.py`

### Phase 4: Frontend
- [x] Scaffold Vite + React + TS, configure output path
- [x] `api.ts` + `useComparison` polling hook
- [x] ComparisonView, ResponseCard, FeedbackBar components
- [x] ProgressBar, EmptyState, ExportPanel
- [x] Keyboard shortcuts + transitions
- [x] Styling

### Phase 5: Integration & Polish
- [x] Build frontend into `_static/`, verify in wheel
- [x] End-to-end test: start → compare → rate → export
- [x] Position randomization (A/B shuffle)
- [x] README with quickstart

### Phase 6: Distribution
- [ ] TestPyPI upload + fresh venv validation
- [ ] GitHub repo + MIT license + CI
- [ ] PyPI publish

---

## Future Roadmap

### v1.1 — Uncertainty-based triggering
- SDK accepts an `uncertainty` score per comparison
- Only surfaces comparisons to the human when score exceeds a threshold
- Aligns with active learning / cost-efficient RLHF

### v1.5 — Training loop helpers
- "Generate training script" button in UI
- "Re-run prompts with new model" helper
- Light guidance toward DPO fine-tuning without owning compute

### v2.0 — Extended formats
- Support for >2 outputs (ranking, not just pairwise)
- Single-output Likert-scale rating (reward model data)
- Export formats: `anthropic`, `openai`, `trl`
- WebSocket for real-time updates (replace polling)

---

## Verification

1. `pip install -e .` in a fresh venv
2. Run `python demo.py` — browser opens, comparisons appear
3. Rate all comparisons via keyboard shortcuts (`1`, `2`, `S`)
4. Press Enter — exports to `preferences.jsonl` in DPO format
5. `python -m build` — verify wheel contains `_static/index.html`
6. `pip install dist/feedloop-0.1.0-py3-none-any.whl` in clean venv — verify it works
