"""Demo script — run this to try feedloop."""

import feedloop

feedloop.start()

# Add some sample comparisons
feedloop.compare(
    prompt="Explain quantum computing to a 5-year-old",
    outputs=[
        "Quantum computing uses qubits that can be in superposition, meaning they can represent both 0 and 1 simultaneously. This allows quantum computers to process many possibilities at once, making them powerful for certain types of calculations.",
        "Imagine you have a magic coin. A normal coin is either heads or tails. But a magic coin can be both at the same time! A quantum computer uses millions of these magic coins to solve really hard puzzles super fast.",
    ],
    metadata={"model_a": "gpt-4", "model_b": "claude-3"},
)

feedloop.compare(
    prompt="Write a haiku about programming",
    outputs=[
        "Lines of code cascade\nSilicon dreams come alive\nBugs hide in the night",
        "Semicolons lost\nThe compiler screams in pain\nStack overflow saves",
    ],
)

feedloop.compare(
    prompt="What is the meaning of life?",
    outputs=[
        "The meaning of life is a deeply philosophical question that has been debated for centuries. Different traditions offer different answers — from religious purpose to existentialist self-creation.",
        "42. But seriously, the meaning of life is whatever you decide to make it. Find what brings you joy, help others when you can, and try to leave things better than you found them.",
    ],
)

print("\n3 comparisons ready. Rate them in the browser!")
print("When done, press Enter to export.\n")

input()

count = feedloop.export("preferences.jsonl")
print(f"\nExported {count} preferences to preferences.jsonl")
feedloop.stop()
