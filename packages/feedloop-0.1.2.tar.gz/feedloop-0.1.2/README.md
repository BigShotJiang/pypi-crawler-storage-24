# feedloop

The fastest way to collect human preference data for LLMs.

```python
import feedloop

feedloop.start()

feedloop.compare(
    prompt="Explain quantum computing",
    outputs=["Response A", "Response B"],
)

# Rate in the browser, then export
feedloop.export("preferences.jsonl")
```
