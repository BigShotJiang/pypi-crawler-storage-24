export default function EmptyState() {
  return (
    <div className="empty-state">
      <div className="pulse-dot" />
      <h2>Waiting for comparisons...</h2>
      <p>
        Run <code>feedloop.compare()</code> in your Python script to send
        comparisons here.
      </p>
      <pre>{`import feedloop

feedloop.start()
feedloop.compare(
    prompt="Your prompt",
    outputs=["Response A", "Response B"],
)`}</pre>
    </div>
  );
}
