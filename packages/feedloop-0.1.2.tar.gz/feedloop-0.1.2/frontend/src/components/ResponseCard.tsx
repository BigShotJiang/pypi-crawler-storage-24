import Markdown from "react-markdown";

interface Props {
  label: string;
  content: string;
}

export default function ResponseCard({ label, content }: Props) {
  return (
    <div className="response-card">
      <div className="response-label">{label}</div>
      <div className="response-content">
        <Markdown>{content}</Markdown>
      </div>
    </div>
  );
}
