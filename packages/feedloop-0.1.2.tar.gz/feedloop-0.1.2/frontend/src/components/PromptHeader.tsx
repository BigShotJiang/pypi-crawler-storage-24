interface Props {
  prompt: string;
}

export default function PromptHeader({ prompt }: Props) {
  return (
    <div className="prompt-header">
      <span className="prompt-label">Prompt</span>
      <p className="prompt-text">{prompt}</p>
    </div>
  );
}
