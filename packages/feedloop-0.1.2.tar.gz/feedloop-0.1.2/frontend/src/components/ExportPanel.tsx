import { useState, useEffect } from "react";
import { fetchStats, getExportUrl, type Stats } from "../api";

interface ExportPanelProps {
  sessionId: string | null;
}

export default function ExportPanel({ sessionId }: ExportPanelProps) {
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    fetchStats(sessionId).then(setStats).catch(() => {});
    const interval = setInterval(() => {
      fetchStats(sessionId).then(setStats).catch(() => {});
    }, 2000);
    return () => clearInterval(interval);
  }, [sessionId]);

  return (
    <div className="export-panel">
      <h2>All done!</h2>
      {stats && (
        <div className="stats-summary">
          <p>{stats.completed} rated, {stats.skipped} skipped</p>
        </div>
      )}
      <a
        className="btn btn-export"
        href={getExportUrl(sessionId)}
        download="preferences.jsonl"
      >
        Download JSONL
      </a>
      <p className="export-hint">
        Or use <code>feedloop.export("preferences.jsonl")</code> in your script.
      </p>
    </div>
  );
}
