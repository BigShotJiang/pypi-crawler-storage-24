interface Props {
  onChoose: (side: "left" | "right" | "skip") => void;
  disabled: boolean;
}

export default function FeedbackBar({ onChoose, disabled }: Props) {
  return (
    <div className="feedback-bar">
      <button
        className="btn btn-prefer"
        onClick={() => onChoose("left")}
        disabled={disabled}
      >
        ← Prefer A <kbd>1</kbd>
      </button>
      <button
        className="btn btn-skip"
        onClick={() => onChoose("skip")}
        disabled={disabled}
      >
        Skip <kbd>S</kbd>
      </button>
      <button
        className="btn btn-prefer"
        onClick={() => onChoose("right")}
        disabled={disabled}
      >
        Prefer B → <kbd>2</kbd>
      </button>
    </div>
  );
}
