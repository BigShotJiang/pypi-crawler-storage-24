import { useCallback, useEffect, useState } from "react";
import { submitFeedback, type Comparison } from "../api";
import PromptHeader from "./PromptHeader";
import ResponseCard from "./ResponseCard";
import FeedbackBar from "./FeedbackBar";
import ProgressBar from "./ProgressBar";

interface Props {
  comparison: Comparison;
  onComplete: () => void;
}

export default function ComparisonView({ comparison, onComplete }: Props) {
  const [submitting, setSubmitting] = useState(false);

  const handleChoose = useCallback(
    async (side: "left" | "right" | "skip") => {
      setSubmitting(true);
      try {
        await submitFeedback(comparison.id, side);
        onComplete();
      } catch (err) {
        console.error("Failed to submit feedback:", err);
      } finally {
        setSubmitting(false);
      }
    },
    [comparison.id, onComplete]
  );

  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      if (submitting) return;
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      if (e.key === "1") handleChoose("left");
      else if (e.key === "2") handleChoose("right");
      else if (e.key === "s" || e.key === "S") handleChoose("skip");
    }

    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [handleChoose, submitting]);

  return (
    <div className="comparison-view">
      <PromptHeader prompt={comparison.prompt} />

      <div className="responses-grid">
        <ResponseCard label="Response A" content={comparison.output_left} />
        <ResponseCard label="Response B" content={comparison.output_right} />
      </div>

      <FeedbackBar onChoose={handleChoose} disabled={submitting} />

      <ProgressBar
        completed={comparison.progress_completed}
        total={comparison.progress_total}
      />
    </div>
  );
}
