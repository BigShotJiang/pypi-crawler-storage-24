export interface Comparison {
  id: string;
  prompt: string;
  output_left: string;
  output_right: string;
  progress_completed: number;
  progress_total: number;
}

export interface Stats {
  pending: number;
  completed: number;
  skipped: number;
  total: number;
}

const BASE = "/api";

export async function fetchSession(): Promise<string | null> {
  const res = await fetch(`${BASE}/session`);
  if (!res.ok) return null;
  const data = await res.json();
  return data.session_id ?? null;
}

export async function fetchPending(sessionId: string | null): Promise<Comparison | null> {
  const url = sessionId
    ? `${BASE}/pending?session_id=${sessionId}`
    : `${BASE}/pending`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch pending: ${res.status}`);
  const data = await res.json();
  return data;
}

export async function submitFeedback(
  comparisonId: string,
  chosenSide: "left" | "right" | "skip"
): Promise<void> {
  const res = await fetch(`${BASE}/feedback`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      comparison_id: comparisonId,
      chosen_side: chosenSide,
    }),
  });
  if (!res.ok) throw new Error(`Failed to submit feedback: ${res.status}`);
}

export async function fetchStats(sessionId: string | null): Promise<Stats> {
  const url = sessionId
    ? `${BASE}/stats?session_id=${sessionId}`
    : `${BASE}/stats`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch stats: ${res.status}`);
  return res.json();
}

export function getExportUrl(sessionId: string | null): string {
  return sessionId ? `${BASE}/export?session_id=${sessionId}` : `${BASE}/export`;
}
