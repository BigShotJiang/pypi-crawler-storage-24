import { useState, useEffect } from "react";
import { fetchSession, fetchStats } from "./api";
import { useComparison } from "./hooks/useComparison";
import ComparisonView from "./components/ComparisonView";
import EmptyState from "./components/EmptyState";
import ExportPanel from "./components/ExportPanel";

export default function App() {
  const [sessionId, setSessionId] = useState<string | null>(null);

  useEffect(() => {
    fetchSession().then(setSessionId).catch(() => {});
  }, []);

  const { comparison, loading, refresh } = useComparison(sessionId);
  const doneState = useCheckDone(comparison, loading, sessionId);

  return (
    <div className="app">
      <header className="app-header">
        <h1>feedloop</h1>
        <span className="tagline">human-in-the-loop feedback</span>
      </header>

      <main className="app-main">
        {loading ? (
          <div className="loading">Loading...</div>
        ) : comparison ? (
          <ComparisonView comparison={comparison} onComplete={refresh} />
        ) : doneState === "done" ? (
          <ExportPanel sessionId={sessionId} />
        ) : (
          <EmptyState />
        )}
      </main>
    </div>
  );
}

function useCheckDone(
  comparison: ReturnType<typeof useComparison>["comparison"],
  loading: boolean,
  sessionId: string | null
): "done" | "empty" | "loading" {
  const [state, setState] = useState<"done" | "empty" | "loading">("loading");

  useEffect(() => {
    if (loading || comparison) return;

    fetchStats(sessionId)
      .then((stats) => {
        if (stats.total > 0 && stats.pending === 0) {
          setState("done");
        } else {
          setState("empty");
        }
      })
      .catch(() => setState("empty"));
  }, [comparison, loading, sessionId]);

  return state;
}
