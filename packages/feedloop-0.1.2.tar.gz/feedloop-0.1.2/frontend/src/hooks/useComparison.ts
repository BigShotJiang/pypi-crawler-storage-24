import { useEffect, useState, useCallback } from "react";
import { fetchPending, type Comparison } from "../api";

export function useComparison(sessionId: string | null) {
  const [comparison, setComparison] = useState<Comparison | null>(null);
  const [loading, setLoading] = useState(true);

  const poll = useCallback(async () => {
    try {
      const data = await fetchPending(sessionId);
      setComparison(data);
    } catch {
      // server may not be ready yet
    } finally {
      setLoading(false);
    }
  }, [sessionId]);

  useEffect(() => {
    poll();
    const interval = setInterval(poll, 1000);
    return () => clearInterval(interval);
  }, [poll]);

  const refresh = useCallback(() => {
    setLoading(true);
    poll();
  }, [poll]);

  return { comparison, loading, refresh };
}
