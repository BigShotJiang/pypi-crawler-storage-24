import json

import pytest

from feedloop._db import Database
from feedloop._export import export_dpo


@pytest.fixture
def db(tmp_path):
    d = Database(db_path=tmp_path / "test.db")
    yield d
    d.close()


def test_export_empty(db, tmp_path):
    out = tmp_path / "out.jsonl"
    count = export_dpo(db, out)
    assert count == 0
    assert out.read_text() == ""


def test_export_single(db, tmp_path):
    cid = db.insert_comparison("s1", "What is AI?", "Good", "Bad")
    db.record_feedback(cid, "left")

    out = tmp_path / "out.jsonl"
    count = export_dpo(db, out)
    assert count == 1

    lines = out.read_text().strip().split("\n")
    assert len(lines) == 1

    row = json.loads(lines[0])
    assert row["prompt"] == "What is AI?"
    # chosen/rejected depends on display_order + which side was "left"
    assert "chosen" in row
    assert "rejected" in row
    assert row["chosen"] != row["rejected"]


def test_export_multiple(db, tmp_path):
    cid1 = db.insert_comparison("s1", "P1", "A1", "B1")
    cid2 = db.insert_comparison("s1", "P2", "A2", "B2")
    cid3 = db.insert_comparison("s1", "P3", "A3", "B3")  # not rated

    db.record_feedback(cid1, "left")
    db.record_feedback(cid2, "right")

    out = tmp_path / "out.jsonl"
    count = export_dpo(db, out)
    assert count == 2  # only completed ones


def test_export_session_filter(db, tmp_path):
    cid1 = db.insert_comparison("s1", "P1", "A1", "B1")
    cid2 = db.insert_comparison("s2", "P2", "A2", "B2")

    db.record_feedback(cid1, "left")
    db.record_feedback(cid2, "left")

    out = tmp_path / "out.jsonl"
    count = export_dpo(db, out, session_id="s1")
    assert count == 1
