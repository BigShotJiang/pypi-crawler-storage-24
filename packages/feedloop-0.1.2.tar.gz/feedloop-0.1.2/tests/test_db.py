import os
import tempfile
from pathlib import Path

import pytest

from feedloop._db import Database


@pytest.fixture
def db(tmp_path):
    db_path = tmp_path / "test.db"
    d = Database(db_path=db_path)
    yield d
    d.close()


def test_insert_and_retrieve(db):
    cid = db.insert_comparison(
        session_id="s1",
        prompt="What is AI?",
        output_a="Answer A",
        output_b="Answer B",
    )
    row = db.get_comparison(cid)
    assert row is not None
    assert row["prompt"] == "What is AI?"
    assert row["output_a"] == "Answer A"
    assert row["output_b"] == "Answer B"
    assert row["status"] == "pending"
    assert row["display_order"] in ("ab", "ba")


def test_get_next_pending(db):
    cid1 = db.insert_comparison("s1", "P1", "A1", "B1")
    cid2 = db.insert_comparison("s1", "P2", "A2", "B2")

    row = db.get_next_pending()
    assert row["id"] == cid1  # oldest first


def test_record_feedback(db):
    cid = db.insert_comparison("s1", "P1", "A1", "B1")
    row = db.get_comparison(cid)
    display_order = row["display_order"]

    db.record_feedback(cid, "left")
    row = db.get_comparison(cid)
    assert row["status"] == "completed"

    # "left" maps to the first char of display_order
    expected_chosen = display_order[0]
    assert row["chosen"] == expected_chosen


def test_skip_comparison(db):
    cid = db.insert_comparison("s1", "P1", "A1", "B1")
    db.skip_comparison(cid)
    row = db.get_comparison(cid)
    assert row["status"] == "skipped"


def test_stats(db):
    db.insert_comparison("s1", "P1", "A1", "B1")
    cid2 = db.insert_comparison("s1", "P2", "A2", "B2")
    db.insert_comparison("s1", "P3", "A3", "B3")

    db.record_feedback(cid2, "right")

    stats = db.get_stats()
    assert stats["pending"] == 2
    assert stats["completed"] == 1
    assert stats["total"] == 3


def test_get_completed(db):
    cid1 = db.insert_comparison("s1", "P1", "A1", "B1")
    db.insert_comparison("s1", "P2", "A2", "B2")
    db.record_feedback(cid1, "left")

    completed = db.get_completed()
    assert len(completed) == 1
    assert completed[0]["id"] == cid1


def test_session_filter(db):
    db.insert_comparison("s1", "P1", "A1", "B1")
    db.insert_comparison("s2", "P2", "A2", "B2")

    stats = db.get_stats(session_id="s1")
    assert stats["total"] == 1

    row = db.get_next_pending(session_id="s2")
    assert row["prompt"] == "P2"


def test_metadata(db):
    import json

    cid = db.insert_comparison(
        "s1", "P1", "A1", "B1", metadata={"model": "gpt-4", "temp": 0.7}
    )
    row = db.get_comparison(cid)
    meta = json.loads(row["metadata"])
    assert meta["model"] == "gpt-4"
    assert meta["temp"] == 0.7
