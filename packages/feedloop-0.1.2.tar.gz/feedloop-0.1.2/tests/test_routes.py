import pytest
from fastapi.testclient import TestClient

from feedloop._db import Database
from feedloop._routes import router, set_db
from fastapi import FastAPI


@pytest.fixture
def client(tmp_path):
    db = Database(db_path=tmp_path / "test.db")
    app = FastAPI()
    set_db(db)
    app.include_router(router)
    with TestClient(app) as c:
        yield c, db
    db.close()


def test_pending_empty(client):
    c, db = client
    resp = c.get("/api/pending")
    assert resp.status_code == 200
    assert resp.json() is None


def test_pending_returns_comparison(client):
    c, db = client
    cid = db.insert_comparison("s1", "Hello?", "Hi!", "Hey!")
    resp = c.get("/api/pending")
    assert resp.status_code == 200
    data = resp.json()
    assert data["id"] == cid
    assert data["prompt"] == "Hello?"
    assert set(data.keys()) == {
        "id", "prompt", "output_left", "output_right",
        "progress_completed", "progress_total",
    }


def test_feedback_flow(client):
    c, db = client
    cid = db.insert_comparison("s1", "P1", "A", "B")

    resp = c.post("/api/feedback", json={
        "comparison_id": cid,
        "chosen_side": "left",
    })
    assert resp.status_code == 200
    assert resp.json()["ok"] is True

    # Should be no more pending
    resp = c.get("/api/pending")
    assert resp.json() is None


def test_feedback_skip(client):
    c, db = client
    cid = db.insert_comparison("s1", "P1", "A", "B")

    resp = c.post("/api/feedback", json={
        "comparison_id": cid,
        "chosen_side": "skip",
    })
    assert resp.status_code == 200

    row = db.get_comparison(cid)
    assert row["status"] == "skipped"


def test_stats(client):
    c, db = client
    db.insert_comparison("s1", "P1", "A", "B")
    cid2 = db.insert_comparison("s1", "P2", "C", "D")
    db.record_feedback(cid2, "right")

    resp = c.get("/api/stats")
    assert resp.status_code == 200
    data = resp.json()
    assert data["pending"] == 1
    assert data["completed"] == 1
    assert data["total"] == 2


def test_export_jsonl(client):
    c, db = client
    cid = db.insert_comparison("s1", "P1", "Good answer", "Bad answer")
    db.record_feedback(cid, "left")

    resp = c.get("/api/export")
    assert resp.status_code == 200
    assert "application/x-ndjson" in resp.headers["content-type"]

    import json
    lines = resp.text.strip().split("\n")
    assert len(lines) == 1
    row = json.loads(lines[0])
    assert row["prompt"] == "P1"
    assert "chosen" in row
    assert "rejected" in row


def test_feedback_invalid_side(client):
    c, db = client
    cid = db.insert_comparison("s1", "P1", "A", "B")

    resp = c.post("/api/feedback", json={
        "comparison_id": cid,
        "chosen_side": "invalid",
    })
    assert resp.status_code == 400
