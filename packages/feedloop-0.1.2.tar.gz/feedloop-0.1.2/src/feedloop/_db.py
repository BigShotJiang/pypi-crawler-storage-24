from __future__ import annotations

import json
import random
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

from ._config import DEFAULT_DB_DIR, DEFAULT_DB_PATH

_SCHEMA = """\
CREATE TABLE IF NOT EXISTS comparisons (
    id            TEXT PRIMARY KEY,
    session_id    TEXT NOT NULL,
    prompt        TEXT NOT NULL,
    output_a      TEXT NOT NULL,
    output_b      TEXT NOT NULL,
    display_order TEXT NOT NULL,
    status        TEXT NOT NULL DEFAULT 'pending',
    chosen        TEXT,
    created_at    TEXT NOT NULL,
    completed_at  TEXT,
    metadata      TEXT
);
CREATE INDEX IF NOT EXISTS idx_comparisons_status ON comparisons(status);
CREATE INDEX IF NOT EXISTS idx_comparisons_session ON comparisons(session_id);
"""


class Database:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self._path = Path(db_path) if db_path else DEFAULT_DB_PATH
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self._path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(_SCHEMA)

    # ── writes ──────────────────────────────────────────────

    def insert_comparison(
        self,
        session_id: str,
        prompt: str,
        output_a: str,
        output_b: str,
        metadata: dict | None = None,
    ) -> str:
        cid = uuid.uuid4().hex
        display_order = random.choice(["ab", "ba"])
        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            self._conn.execute(
                """INSERT INTO comparisons
                   (id, session_id, prompt, output_a, output_b,
                    display_order, status, created_at, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?)""",
                (
                    cid,
                    session_id,
                    prompt,
                    output_a,
                    output_b,
                    display_order,
                    now,
                    json.dumps(metadata) if metadata else None,
                ),
            )
            self._conn.commit()
        return cid

    def record_feedback(self, comparison_id: str, chosen_side: str) -> None:
        """Record a preference. chosen_side is 'left' or 'right'."""
        row = self.get_comparison(comparison_id)
        if row is None:
            raise ValueError(f"Comparison {comparison_id} not found")

        # Map display side to original output
        display_order = row["display_order"]
        if chosen_side == "left":
            chosen = display_order[0]  # 'a' or 'b'
        else:
            chosen = display_order[1]

        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            self._conn.execute(
                """UPDATE comparisons
                   SET chosen = ?, status = 'completed', completed_at = ?
                   WHERE id = ?""",
                (chosen, now, comparison_id),
            )
            self._conn.commit()

    def skip_comparison(self, comparison_id: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            self._conn.execute(
                """UPDATE comparisons
                   SET status = 'skipped', completed_at = ?
                   WHERE id = ?""",
                (now, comparison_id),
            )
            self._conn.commit()

    # ── reads ───────────────────────────────────────────────

    def get_comparison(self, comparison_id: str) -> sqlite3.Row | None:
        cur = self._conn.execute(
            "SELECT * FROM comparisons WHERE id = ?", (comparison_id,)
        )
        return cur.fetchone()

    def get_next_pending(self, session_id: str | None = None) -> sqlite3.Row | None:
        if session_id:
            cur = self._conn.execute(
                """SELECT * FROM comparisons
                   WHERE status = 'pending' AND session_id = ?
                   ORDER BY created_at ASC LIMIT 1""",
                (session_id,),
            )
        else:
            cur = self._conn.execute(
                """SELECT * FROM comparisons
                   WHERE status = 'pending'
                   ORDER BY created_at ASC LIMIT 1"""
            )
        return cur.fetchone()

    def get_stats(self, session_id: str | None = None) -> dict:
        where = "WHERE session_id = ?" if session_id else ""
        params: tuple = (session_id,) if session_id else ()
        cur = self._conn.execute(
            f"""SELECT
                   SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                   SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                   SUM(CASE WHEN status = 'skipped' THEN 1 ELSE 0 END) as skipped,
                   COUNT(*) as total
               FROM comparisons {where}""",
            params,
        )
        row = cur.fetchone()
        return {
            "pending": row["pending"] or 0,
            "completed": row["completed"] or 0,
            "skipped": row["skipped"] or 0,
            "total": row["total"] or 0,
        }

    def get_completed(self, session_id: str | None = None) -> list[sqlite3.Row]:
        if session_id:
            cur = self._conn.execute(
                """SELECT * FROM comparisons
                   WHERE status = 'completed' AND session_id = ?
                   ORDER BY completed_at ASC""",
                (session_id,),
            )
        else:
            cur = self._conn.execute(
                """SELECT * FROM comparisons
                   WHERE status = 'completed'
                   ORDER BY completed_at ASC"""
            )
        return cur.fetchall()

    # ── lifecycle ───────────────────────────────────────────

    def close(self) -> None:
        self._conn.close()
