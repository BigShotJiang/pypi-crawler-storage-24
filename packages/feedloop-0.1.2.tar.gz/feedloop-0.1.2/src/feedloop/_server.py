from __future__ import annotations

import socket
import threading
from pathlib import Path

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from ._config import DEFAULT_PORT, PORT_SCAN_RANGE
from ._db import Database
from ._routes import router, set_db, set_session_id

STATIC_DIR = Path(__file__).parent / "_static"


def _create_app(db: Database, session_id: str) -> FastAPI:
    app = FastAPI(title="feedloop", docs_url=None, redoc_url=None)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    set_db(db)
    set_session_id(session_id)
    app.include_router(router)

    # Serve React static files (only if built)
    index = STATIC_DIR / "index.html"
    if index.exists():
        app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")

    return app


def _find_open_port(start: int) -> int:
    for port in range(start, start + PORT_SCAN_RANGE):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError(
        f"No open port found in range {start}-{start + PORT_SCAN_RANGE - 1}"
    )


class BackgroundServer:
    def __init__(self, db: Database, session_id: str, port: int = DEFAULT_PORT) -> None:
        self.db = db
        self.port = _find_open_port(port)
        self.app = _create_app(db, session_id)
        self._thread: threading.Thread | None = None
        self._server: uvicorn.Server | None = None

    @property
    def url(self) -> str:
        return f"http://localhost:{self.port}"

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return  # already running

        config = uvicorn.Config(
            self.app,
            host="127.0.0.1",
            port=self.port,
            log_level="warning",
        )
        self._server = uvicorn.Server(config)

        self._thread = threading.Thread(target=self._server.run, daemon=True)
        self._thread.start()

        # Wait for server to be ready
        self._server.started = True  # type: ignore[assignment]
        import time

        for _ in range(50):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                try:
                    s.connect(("127.0.0.1", self.port))
                    return
                except ConnectionRefusedError:
                    time.sleep(0.1)

    def stop(self) -> None:
        if self._server:
            self._server.should_exit = True
        if self._thread:
            self._thread.join(timeout=3)
            self._thread = None
