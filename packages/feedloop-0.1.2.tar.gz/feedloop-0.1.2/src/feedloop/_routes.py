from __future__ import annotations

import io
import json

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from ._db import Database
from ._models import ComparisonOut, FeedbackRequest, StatsResponse

router = APIRouter(prefix="/api")

# The database and session_id are set by _server.py at startup.
_db: Database | None = None
_session_id: str | None = None


def set_db(db: Database) -> None:
    global _db
    _db = db


def set_session_id(session_id: str) -> None:
    global _session_id
    _session_id = session_id


def _get_db() -> Database:
    if _db is None:
        raise RuntimeError("Database not initialised")
    return _db


@router.get("/session")
def get_session() -> dict:
    return {"session_id": _session_id}


@router.get("/pending")
def get_pending(session_id: str | None = None) -> ComparisonOut | None:
    db = _get_db()
    row = db.get_next_pending(session_id=session_id)
    if row is None:
        return None

    stats = db.get_stats(session_id=session_id)

    # Apply display_order to decide what the UI sees as left/right
    if row["display_order"] == "ab":
        left, right = row["output_a"], row["output_b"]
    else:
        left, right = row["output_b"], row["output_a"]

    return ComparisonOut(
        id=row["id"],
        prompt=row["prompt"],
        output_left=left,
        output_right=right,
        progress_completed=stats["completed"],
        progress_total=stats["total"],
    )


@router.post("/feedback")
def post_feedback(req: FeedbackRequest) -> dict:
    db = _get_db()
    if req.chosen_side not in ("left", "right", "skip"):
        raise HTTPException(400, "chosen_side must be 'left', 'right', or 'skip'")

    if req.chosen_side == "skip":
        db.skip_comparison(req.comparison_id)
    else:
        db.record_feedback(req.comparison_id, req.chosen_side)

    return {"ok": True}


@router.get("/stats")
def get_stats(session_id: str | None = None) -> StatsResponse:
    db = _get_db()
    s = db.get_stats(session_id=session_id)
    return StatsResponse(**s)


@router.get("/export")
def export_jsonl(session_id: str | None = None) -> StreamingResponse:
    db = _get_db()
    rows = db.get_completed(session_id=session_id)

    lines: list[str] = []
    for row in rows:
        if row["chosen"] == "a":
            chosen_text, rejected_text = row["output_a"], row["output_b"]
        else:
            chosen_text, rejected_text = row["output_b"], row["output_a"]

        record = {
            "prompt": row["prompt"],
            "chosen": chosen_text,
            "rejected": rejected_text,
        }
        lines.append(json.dumps(record, ensure_ascii=False))

    content = "\n".join(lines) + "\n" if lines else ""
    return StreamingResponse(
        io.BytesIO(content.encode("utf-8")),
        media_type="application/x-ndjson",
        headers={"Content-Disposition": "attachment; filename=preferences.jsonl"},
    )
