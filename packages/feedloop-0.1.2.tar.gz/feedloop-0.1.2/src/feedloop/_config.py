from pathlib import Path

DEFAULT_PORT = 7856
DEFAULT_DB_DIR = Path.home() / ".feedloop"
DEFAULT_DB_PATH = DEFAULT_DB_DIR / "feedloop.db"
PORT_SCAN_RANGE = 10  # try ports 7856-7866 if default is busy
