"""CLI entry point: python -m feedloop"""

from __future__ import annotations

import argparse
import signal
import sys

from . import start, stop
from ._config import DEFAULT_PORT


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="feedloop",
        description="The fastest way to collect human preference data for LLMs",
    )
    parser.add_argument(
        "--port", type=int, default=DEFAULT_PORT, help="Port to listen on"
    )
    parser.add_argument("--db", type=str, default=None, help="Path to SQLite database")
    parser.add_argument(
        "--no-browser", action="store_true", help="Don't open browser automatically"
    )
    args = parser.parse_args()

    start(port=args.port, db_path=args.db, open_browser=not args.no_browser)

    print("feedloop: Press Ctrl+C to stop")

    def _handle_signal(sig: int, frame: object) -> None:
        print("\nfeedloop: shutting down")
        stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, _handle_signal)
    signal.signal(signal.SIGTERM, _handle_signal)

    # Block forever (server runs in daemon thread)
    signal.pause()


if __name__ == "__main__":
    main()
