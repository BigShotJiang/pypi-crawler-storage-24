from __future__ import annotations

from pydantic import BaseModel


class ComparisonOut(BaseModel):
    id: str
    prompt: str
    output_left: str
    output_right: str
    progress_completed: int
    progress_total: int


class FeedbackRequest(BaseModel):
    comparison_id: str
    chosen_side: str  # "left" | "right"


class StatsResponse(BaseModel):
    pending: int
    completed: int
    skipped: int
    total: int


class ExportRow(BaseModel):
    prompt: str
    chosen: str
    rejected: str
