from __future__ import annotations

import json
from pathlib import Path

from ._db import Database


def export_dpo(db: Database, path: str | Path, session_id: str | None = None) -> int:
    """Export completed comparisons as DPO-formatted JSONL. Returns row count."""
    rows = db.get_completed(session_id=session_id)
    path = Path(path)

    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            if row["chosen"] == "a":
                chosen_text = row["output_a"]
                rejected_text = row["output_b"]
            else:
                chosen_text = row["output_b"]
                rejected_text = row["output_a"]

            record = {
                "prompt": row["prompt"],
                "chosen": chosen_text,
                "rejected": rejected_text,
            }
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    return len(rows)
