"""feedloop — The fastest way to collect human preference data for LLMs."""

from __future__ import annotations

import atexit
import time
import uuid
import webbrowser

from ._config import DEFAULT_PORT
from ._db import Database
from ._export import export_dpo
from ._server import BackgroundServer

__version__ = "0.1.2"

# ── module-level state ──────────────────────────────────────

_server: BackgroundServer | None = None
_db: Database | None = None
_session_id: str | None = None


def _ensure_started() -> tuple[BackgroundServer, Database, str]:
    if _server is None or _db is None or _session_id is None:
        raise RuntimeError("Call feedloop.start() first")
    return _server, _db, _session_id


# ── public API ──────────────────────────────────────────────


def start(
    port: int = DEFAULT_PORT,
    db_path: str | None = None,
    open_browser: bool = True,
) -> None:
    """Launch the HITL feedback server in a background thread.

    Idempotent — calling start() twice reuses the running server.
    """
    global _server, _db, _session_id

    if _server is not None:
        return

    _session_id = uuid.uuid4().hex
    _db = Database(db_path=db_path)
    _server = BackgroundServer(_db, session_id=_session_id, port=port)
    _server.start()

    print(f"feedloop: server running at {_server.url}")

    if open_browser:
        webbrowser.open(_server.url)

    atexit.register(stop)


def compare(
    prompt: str,
    outputs: list[str],
    *,
    metadata: dict | None = None,
) -> str:
    """Submit a comparison for human review. Returns comparison_id.

    Non-blocking — returns immediately. The comparison appears
    in the web UI for the human to evaluate.
    """
    _, db, session_id = _ensure_started()

    if len(outputs) != 2:
        raise ValueError("outputs must contain exactly 2 items")

    return db.insert_comparison(
        session_id=session_id,
        prompt=prompt,
        output_a=outputs[0],
        output_b=outputs[1],
        metadata=metadata,
    )


def wait(
    comparison_id: str | None = None,
    timeout: float | None = None,
) -> dict | None:
    """Block until a specific comparison (or all pending) is rated.

    Returns the result dict or None on timeout.
    """
    _, db, session_id = _ensure_started()
    deadline = time.monotonic() + timeout if timeout else None

    while True:
        if comparison_id:
            row = db.get_comparison(comparison_id)
            if row and row["status"] != "pending":
                if row["chosen"] == "a":
                    chosen, rejected = row["output_a"], row["output_b"]
                else:
                    chosen, rejected = row["output_b"], row["output_a"]
                return {
                    "prompt": row["prompt"],
                    "chosen": chosen,
                    "rejected": rejected,
                }
        else:
            stats = db.get_stats(session_id=session_id)
            if stats["pending"] == 0 and stats["total"] > 0:
                return {"completed": stats["completed"], "total": stats["total"]}

        if deadline and time.monotonic() >= deadline:
            return None

        time.sleep(0.3)


def status() -> dict:
    """Return {"pending": N, "completed": M, "skipped": S, "total": T}."""
    _, db, session_id = _ensure_started()
    return db.get_stats(session_id=session_id)


def export(
    path: str = "preferences.jsonl",
    *,
    session_id: str | None = None,
    format: str = "dpo",
) -> int:
    """Export completed comparisons to JSONL. Returns count exported."""
    _, db, current_session = _ensure_started()

    if format != "dpo":
        raise ValueError(f"Unsupported format: {format!r}. Only 'dpo' is supported.")

    sid = session_id if session_id is not None else current_session
    count = export_dpo(db, path, session_id=sid)
    print(f"feedloop: exported {count} preferences to {path}")
    return count


def stop() -> None:
    """Shut down the background server."""
    global _server, _db, _session_id

    if _server:
        _server.stop()
    if _db:
        _db.close()

    _server = None
    _db = None
    _session_id = None
