/*
 * AdderNet-HDC — Multivariate classification using Hyperdimensional Computing
 * ============================================================================
 *   Combines AdderNet encoding (discretization via lookup) with HDC
 *   (binding=XOR, bundling=majority vote, search=Hamming distance).
 *
 *   Zero floating-point multiplication at inference.
 */

#ifndef ADDERNET_HDC_H
#define ADDERNET_HDC_H

#include "hdc_core.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Multivariate HDC model.
 *
 *   position_hvs[v]   — fixed random hypervector for variable v (role vector)
 *   codebook[c]        — bundled prototype for class c
 *
 * Value vectors are generated on-the-fly via hv_from_seed (zero storage).
 *
 * Inference flow (position-value encoding):
 *   H_val = hv_from_seed(var=v, bin=idx)                    "value X"
 *   pair_v = bind(position_hvs[v], H_val)                   "var v has value X"
 *   H_query = bundle(pair_0, pair_1, ..., pair_{n-1})
 *   class = argmin_c  hamming(H_query, codebook[c])
 */
typedef struct {
    int     n_vars;
    int     n_classes;
    int     table_size;         /* encoding resolution (power of 2) */
    int     table_mask;         /* table_size - 1 */
    int    *bias;               /* bias[v] per variable */
    hv_t  *position_hvs;       /* [n_vars] role vectors (one per variable) */
    hv_t  *codebook;            /* [n_classes] class prototypes */
    char  **class_names;        /* [n_classes] or NULL */
} an_hdc_model;

/*
 * an_hdc_create — Allocate a model.
 *
 *   n_vars:     number of input variables
 *   n_classes:  number of output classes
 *   table_size: encoding table size per variable (must be power of 2, e.g. 256)
 *   bias:       array of n_vars bias values (or NULL for auto: table_size/2)
 *
 *   Allocates random hypervectors for the encoding table.
 *   Returns: pointer to new model, or NULL on failure.
 */
an_hdc_model *an_hdc_create(int n_vars, int n_classes, int table_size,
                            const int *bias);

/*
 * an_hdc_free — Free a model.
 */
void an_hdc_free(an_hdc_model *m);

/*
 * an_hdc_train — Train the codebook from labeled data.
 *
 *   X:          n_samples × n_vars matrix (row-major doubles)
 *   y:          n_samples class labels (int, 0-indexed)
 *   n_samples:  number of training samples
 *
 *   For each class, encodes all its samples into hypervectors,
 *   then bundles them into the class prototype.
 */
void an_hdc_train(an_hdc_model *m, const double *X, const int *y, int n_samples);

/*
 * an_hdc_predict — Classify one sample. Zero multiplication.
 *
 *   x: array of n_vars input values
 *   Returns: predicted class label (0-indexed), or -1 on error.
 */
int an_hdc_predict(const an_hdc_model *m, const double *x);

/*
 * an_hdc_predict_batch — Classify n samples.
 *
 *   X:       n × n_vars matrix (row-major doubles)
 *   outputs: array of n ints (pre-allocated by caller)
 *   Returns: 0 on success, -1 on error.
 */
int an_hdc_predict_batch(const an_hdc_model *m, const double *X,
                         int *outputs, int n);

/*
 * an_hdc_save — Serialize model to binary file.
 * Returns: 0 on success, -1 on error.
 */
int an_hdc_save(const an_hdc_model *m, const char *path);

/*
 * an_hdc_load — Deserialize model from binary file.
 * Returns: pointer to new model, or NULL on failure.
 */
an_hdc_model *an_hdc_load(const char *path);

/*
 * an_hdc_predict_batch_cuda — Batch prediction on GPU.
 * N predictions in parallel. Falls back to CPU if CUDA unavailable.
 * Returns: 0 on success, -1 on error.
 */
int an_hdc_predict_batch_cuda(an_hdc_model *m, const double *X,
                               int *y_pred, int N);

#ifdef __cplusplus
}
#endif

#endif /* ADDERNET_HDC_H */
