/*
 * HDC Core — Hyperdimensional Computing primitives
 * ===================================================
 *   Binary hypervectors of D=10000 bits (157 x uint64_t).
 *   Zero floating-point arithmetic.
 *
 *   Operations:
 *     bind   = XOR bit a bit
 *     bundle = majority vote bit a bit
 *     hamming distance = popcount(XOR)
 *
 *   Compile: included by addernet_hdc.c, or standalone test.
 */

#ifndef HDC_CORE_H
#define HDC_CORE_H

#include <stdint.h>
#include <stdalign.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef HDC_DIM
#define HDC_DIM     10000
#endif
#ifndef HDC_WORDS
#define HDC_WORDS   157          /* ceil(10000/64) */
#endif
#define HDC_BYTES   (HDC_WORDS * sizeof(uint64_t))

typedef uint64_t hv_t[HDC_WORDS];

/* Generate a random hypervector (approximately 50% bits set) */
void hv_random(hv_t out);

/* Seed the internal RNG (for reproducibility) */
void hv_seed(unsigned int seed);

/* Get/set the raw RNG state (for save/restore around deterministic encoding) */
uint64_t hv_seed_state(void);
void hv_seed_set(uint64_t state);

/* out = a XOR b */
void hv_bind(hv_t out, const hv_t a, const hv_t b);

/* out = majority vote of n vectors (bundling) */
void hv_bundle(hv_t out, const hv_t *vecs, int n);

/* Hamming distance: number of differing bits */
int  hv_hamming(const hv_t a, const hv_t b);

/* Similarity: 1.0 - hamming/D */
float hv_similarity(const hv_t a, const hv_t b);

/* dst = src */
void hv_copy(hv_t dst, const hv_t src);

/* dst = all zeros */
void hv_zero(hv_t dst);

/* dst = all ones (complement of zero) */
void hv_one(hv_t dst);

/* Random integer in [0, max) */
int  hv_randint(int max);

/* Deterministic hypervector from seed (on-the-fly generation, zero storage) */
void hv_from_seed(hv_t out, uint64_t seed);

/* Flip bits with given probability (temperature). 0.0 = copy, 1.0 = total noise. */
void hv_add_noise(hv_t out, const hv_t src, float temperature);

/* GPU hv_bundle via CUDA (inline PTX, no nvcc required) */
void hv_bundle_cuda(hv_t out, const hv_t *vecs, int n);
void hv_cuda_shutdown(void);

#ifdef __cplusplus
}
#endif

#endif /* HDC_CORE_H */
