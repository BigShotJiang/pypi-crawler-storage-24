/*
 * AdderNet-HDC — Implementation
 * ===============================
 *   Multivariate classification using Hyperdimensional Computing.
 *   Zero floating-point multiplication at inference.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "addernet_hdc.h"

/* ---- Internal helpers ---- */

/* Encode a single input value to its hypervector for a given variable.
 * Uses deterministic hv_from_seed — zero storage, computed on the fly. */
static inline void an_hdc_encode(const an_hdc_model *m, int var, double val, hv_t out) {
    int bin = ((int)val + m->bias[var]) & m->table_mask;
    uint64_t seed = (uint64_t)var * 100003ULL + (uint64_t)bin;
    hv_from_seed(out, seed);
}

/* ---- Public API ---- */

an_hdc_model *an_hdc_create(int n_vars, int n_classes, int table_size,
                            const int *bias)
{
    if (n_vars <= 0 || n_classes <= 0 || table_size <= 0)
        return NULL;
    if ((table_size & (table_size - 1)) != 0)
        return NULL;  /* must be power of 2 */

    an_hdc_model *m = (an_hdc_model *)calloc(1, sizeof(an_hdc_model));
    if (!m) return NULL;

    m->n_vars     = n_vars;
    m->n_classes  = n_classes;
    m->table_size = table_size;
    m->table_mask = table_size - 1;

    /* Bias per variable */
    m->bias = (int *)malloc(n_vars * sizeof(int));
    if (!m->bias) goto fail;
    if (bias) {
        memcpy(m->bias, bias, n_vars * sizeof(int));
    } else {
        for (int v = 0; v < n_vars; v++)
            m->bias[v] = table_size / 2;
    }

    /* Position hypervectors: one random HV per variable (role vector). */
    m->position_hvs = (hv_t *)aligned_alloc(64, n_vars * sizeof(hv_t));
    if (!m->position_hvs) goto fail;
    for (int v = 0; v < n_vars; v++)
        hv_random(m->position_hvs[v]);

    /* Codebook: n_classes prototypes (zeroed, trained later) */
    m->codebook = (hv_t *)aligned_alloc(64, n_classes * sizeof(hv_t));
    if (!m->codebook) goto fail;
    for (int c = 0; c < n_classes; c++)
        hv_zero(m->codebook[c]);

    /* Class names */
    m->class_names = (char **)calloc(n_classes, sizeof(char *));

    return m;

fail:
    an_hdc_free(m);
    return NULL;
}

void an_hdc_free(an_hdc_model *m) {
    if (!m) return;
    free(m->bias);
    free(m->position_hvs);
    free(m->codebook);
    if (m->class_names) {
        for (int c = 0; c < m->n_classes; c++)
            free(m->class_names[c]);
        free(m->class_names);
    }
    free(m);
}

void an_hdc_train(an_hdc_model *m, const double *X, const int *y, int n_samples) {
    if (!m || !X || !y || n_samples <= 0) return;

    /* Allocate temp storage per class */
    hv_t **class_hvs = (hv_t **)malloc(m->n_classes * sizeof(hv_t *));
    int   *class_cnt = (int *)calloc(m->n_classes, sizeof(int));
    if (!class_hvs || !class_cnt) { free(class_hvs); free(class_cnt); return; }

    /* Count samples per class first */
    int *counts = (int *)calloc(m->n_classes, sizeof(int));
    for (int i = 0; i < n_samples; i++) {
        int c = y[i];
        if (c >= 0 && c < m->n_classes) counts[c]++;
    }

    /* Allocate per-class arrays */
    for (int c = 0; c < m->n_classes; c++) {
        class_hvs[c] = (counts[c] > 0)
            ? (hv_t *)aligned_alloc(64, counts[c] * sizeof(hv_t))
            : NULL;
    }
    free(counts);

    /* Encode all samples: bind(position, value) for each var, then bundle all pairs */
    hv_t *pairs = (hv_t *)aligned_alloc(64,
        (m->n_vars > 0 ? m->n_vars : 1) * sizeof(hv_t));
    hv_t sample_hv;
    for (int i = 0; i < n_samples; i++) {
        int c = y[i];
        if (c < 0 || c >= m->n_classes) continue;

        /* For each variable: pair[i] = bind(position[i], value[i]) */
        for (int v = 0; v < m->n_vars; v++) {
            hv_t val_hv;
            an_hdc_encode(m, v, X[i * m->n_vars + v], val_hv);
            hv_bind(pairs[v], m->position_hvs[v], val_hv);
        }

        /* Bundle all pairs into one sample hypervector */
        hv_bundle(sample_hv, pairs, m->n_vars);

        /* Store in class array */
        if (class_hvs[c]) {
            hv_copy(class_hvs[c][class_cnt[c]], sample_hv);
            class_cnt[c]++;
        }
    }
    free(pairs);

    /* Bundle per class → codebook */
    for (int c = 0; c < m->n_classes; c++) {
        if (class_cnt[c] > 0 && class_hvs[c]) {
            hv_bundle(m->codebook[c], class_hvs[c], class_cnt[c]);
            free(class_hvs[c]);
        }
    }

    free(class_hvs);
    free(class_cnt);
}

int an_hdc_predict(const an_hdc_model *m, const double *x) {
    if (!m || !x) return -1;

    /*
     * Inline encoding: for each variable, generate value HV via hv_from_seed,
     * bind with position HV, and accumulate into counters directly.
     * This avoids allocating and bundling 196 separate hv_t arrays.
     *
     * Instead of: bind(196 pairs) → bundle(196 pairs) → hamming(10)
     * We do:      for each var, bind into pairs[v], then bundle via counters,
     *             then hamming search — all in one pass.
     */
    uint16_t counts[HDC_DIM] = {0};

    /* Encode each variable: bind(pos, value) and accumulate bit counts */
    for (int v = 0; v < m->n_vars; v++) {
        int bin = ((int)x[v] + m->bias[v]) & m->table_mask;
        uint64_t seed = (uint64_t)v * 100003ULL + (uint64_t)bin;
        hv_t val_hv;
        hv_from_seed(val_hv, seed);

        /* bind(position, value) into a temp pair */
        for (int w = 0; w < HDC_WORDS; w++) {
            uint64_t word = m->position_hvs[v][w] ^ val_hv[w];
            /* Accumulate bit counts for bundling (majority vote) */
            int base = w * 64;
            while (word) {
                int bit = __builtin_ctzll(word);
                counts[base + bit]++;
                word &= word - 1;
            }
        }
    }

    /* Build query HV from counters (majority vote threshold) */
    int threshold = m->n_vars / 2;
    hv_t query;
    memset(query, 0, sizeof(hv_t));
    for (int i = 0; i < HDC_DIM; i++) {
        if (counts[i] > threshold)
            query[i / 64] |= (1ULL << (i % 64));
    }

    /* Find closest class by Hamming distance */
    int best_c = 0;
    int best_d = hv_hamming(query, m->codebook[0]);
    for (int c = 1; c < m->n_classes; c++) {
        int d = hv_hamming(query, m->codebook[c]);
        if (d < best_d) {
            best_d = d;
            best_c = c;
        }
    }
    return best_c;
}

int an_hdc_predict_batch(const an_hdc_model *m, const double *X,
                         int *outputs, int n)
{
    if (!m || !X || !outputs || n <= 0) return -1;
    for (int i = 0; i < n; i++)
        outputs[i] = an_hdc_predict(m, &X[i * m->n_vars]);
    return 0;
}

/* ---- Save / Load ---- */

int an_hdc_save(const an_hdc_model *m, const char *path) {
    if (!m || !path) return -1;

    FILE *f = fopen(path, "wb");
    if (!f) return -1;

    /* Header */
    fwrite(&m->n_vars,     sizeof(int), 1, f);
    fwrite(&m->n_classes,  sizeof(int), 1, f);
    fwrite(&m->table_size, sizeof(int), 1, f);

    /* Bias */
    fwrite(m->bias, sizeof(int), m->n_vars, f);

    /* Position hypervectors */
    fwrite(m->position_hvs, sizeof(hv_t), m->n_vars, f);

    /* Codebook */
    fwrite(m->codebook, sizeof(hv_t), m->n_classes, f);

    fclose(f);
    return 0;
}

an_hdc_model *an_hdc_load(const char *path) {
    if (!path) return NULL;

    FILE *f = fopen(path, "rb");
    if (!f) return NULL;

    int n_vars, n_classes, table_size;
    if (fread(&n_vars,     sizeof(int), 1, f) != 1) goto fail;
    if (fread(&n_classes,  sizeof(int), 1, f) != 1) goto fail;
    if (fread(&table_size, sizeof(int), 1, f) != 1) goto fail;

    an_hdc_model *m = an_hdc_create(n_vars, n_classes, table_size, NULL);
    if (!m) goto fail;

    /* Re-read bias (overwrite auto-generated) */
    if (fread(m->bias, sizeof(int), n_vars, f) != (size_t)n_vars) {
        an_hdc_free(m); goto fail;
    }

    /* Read position hypervectors */
    if (fread(m->position_hvs, sizeof(hv_t), n_vars, f) != (size_t)n_vars) {
        an_hdc_free(m); goto fail;
    }

    /* Read codebook */
    if (fread(m->codebook, sizeof(hv_t), n_classes, f) != (size_t)n_classes) {
        an_hdc_free(m); goto fail;
    }

    fclose(f);
    return m;

fail:
    fclose(f);
    return NULL;
}
