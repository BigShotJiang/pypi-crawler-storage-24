/*
 * HDC Core — Implementation
 * ===========================
 *   Binary hypervectors: D=10000 bits (157 x uint64_t).
 *   All operations use integer bitwise ops. Zero floating-point.
 */

#include <string.h>
#include <stdlib.h>
#include "hdc_core.h"

/* ---- Internal RNG (xorshift64) ---- */

static uint64_t rng_state = 0xDEADBEEFCAFEBABEULL;

void hv_seed(unsigned int seed) {
    rng_state = (uint64_t)seed * 6364136223846793005ULL + 1442695040888963407ULL;
    if (rng_state == 0) rng_state = 1;
}

uint64_t hv_seed_state(void) { return rng_state; }
void hv_seed_set(uint64_t state) { rng_state = state ? state : 1; }

static inline uint64_t xorshift64(void) {
    uint64_t x = rng_state;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    rng_state = x;
    return x;
}

/* ---- Public API ---- */

void hv_random(hv_t out) {
    for (int i = 0; i < HDC_WORDS; i++)
        out[i] = xorshift64();
    /* Mask off excess bits in last word */
    out[HDC_WORDS - 1] &= (1ULL << (HDC_DIM - (HDC_WORDS - 1) * 64)) - 1;
}

void hv_bind(hv_t out, const hv_t a, const hv_t b) {
    for (int i = 0; i < HDC_WORDS; i++)
        out[i] = a[i] ^ b[i];
    /* Mask off excess bits in last word */
    out[HDC_WORDS - 1] &= (1ULL << (HDC_DIM - (HDC_WORDS - 1) * 64)) - 1;
}

void hv_bundle(hv_t out, const hv_t *vecs, int n) {
    if (n <= 0) { hv_zero(out); return; }
    if (n == 1) { hv_copy(out, vecs[0]); return; }

    /*
     * Fast majority vote using __builtin_ctzll (sparse iteration).
     * Only iterates over SET bits, not all 64 bits per word.
     * For 50% density: ~32 iterations per word instead of 64.
     * Uses uint16_t counters (20KB on stack for D=10000).
     */
    uint16_t counts[HDC_DIM] = {0};
    int threshold = n / 2;  /* tie → bit stays 0 */

    for (int v = 0; v < n; v++) {
        for (int w = 0; w < HDC_WORDS; w++) {
            uint64_t word = vecs[v][w];
            int base = w * 64;
            while (word) {
                int bit = __builtin_ctzll(word);
                counts[base + bit]++;
                word &= word - 1;
            }
        }
    }

    memset(out, 0, sizeof(hv_t));
    for (int i = 0; i < HDC_DIM; i++) {
        if (counts[i] > threshold)
            out[i / 64] |= (1ULL << (i % 64));
    }
}

int hv_hamming(const hv_t a, const hv_t b) {
    int dist = 0;
    for (int i = 0; i < HDC_WORDS; i++)
        dist += __builtin_popcountll(a[i] ^ b[i]);
    return dist;
}

float hv_similarity(const hv_t a, const hv_t b) {
    return 1.0f - (float)hv_hamming(a, b) / (float)HDC_DIM;
}

void hv_copy(hv_t dst, const hv_t src) {
    memcpy(dst, src, HDC_BYTES);
}

void hv_zero(hv_t dst) {
    memset(dst, 0, HDC_BYTES);
}

void hv_one(hv_t dst) {
    memset(dst, 0xFF, HDC_BYTES);
}

int hv_randint(int max) {
    if (max <= 0) return 0;
    return (int)(xorshift64() % (uint64_t)max);
}

void hv_from_seed(hv_t out, uint64_t seed) {
    uint64_t s = seed;
    for (int i = 0; i < HDC_WORDS; i++) {
        s ^= s << 13;
        s ^= s >> 7;
        s ^= s << 17;
        out[i] = s;
    }
    /* Mask off excess bits in last word */
    int valid_bits = HDC_DIM - (HDC_WORDS - 1) * 64;
    if (valid_bits < 64)
        out[HDC_WORDS - 1] &= (1ULL << valid_bits) - 1;
}

void hv_add_noise(hv_t out, const hv_t src, float temperature) {
    if (temperature <= 0.0f) { hv_copy(out, src); return; }
    if (temperature >= 1.0f) { hv_random(out); return; }

    /* For each bit, flip with probability = temperature.
     * Uses xorshift for speed instead of rand(). */
    for (int i = 0; i < HDC_WORDS; i++) {
        uint64_t mask = 0;
        uint64_t r = xorshift64();
        for (int b = 0; b < 64; b++) {
            /* Compare 8-bit threshold: faster than float rand */
            if ((r & 0xFF) < (uint64_t)(temperature * 256))
                mask |= (1ULL << b);
            r >>= 8;
            if (b % 8 == 7 && b < 63) r = xorshift64();
        }
        out[i] = src[i] ^ mask;
    }
    /* Mask last word */
    int valid_bits = HDC_DIM - (HDC_WORDS - 1) * 64;
    if (valid_bits < 64)
        out[HDC_WORDS - 1] &= (1ULL << valid_bits) - 1;
}
