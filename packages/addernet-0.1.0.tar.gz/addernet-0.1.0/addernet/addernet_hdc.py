#!/usr/bin/env python3
"""
AdderNet-HDC Python Bindings — ctypes interface to libaddernet_hdc.so
======================================================================

Usage:
    from addernet_hdc import AdderNetHDC

    model = AdderNetHDC(n_vars=4, n_classes=3, table_size=256)
    model.train(X, y)
    pred = model.predict(x)
"""

import os
import ctypes
import numpy as np

# ---- Locate shared library ----

_HERE = os.path.dirname(os.path.abspath(__file__))
_LIB_NAMES = [
    os.path.join(_HERE, "libaddernet_hdc.so"),
    os.path.join(_HERE, "libaddernet_hdc.dylib"),
    "libaddernet_hdc.so",
]

_lib = None
for _name in _LIB_NAMES:
    try:
        _lib = ctypes.CDLL(_name)
        break
    except OSError:
        continue

if _lib is None:
    raise OSError(
        "Cannot find libaddernet_hdc.so. "
        "Build it first: cd addernet_lib && make hdc"
    )

# ---- Opaque pointer type ----

_AnHdcPtr = ctypes.c_void_p

# ---- Function signatures ----

_lib.an_hdc_create.restype = _AnHdcPtr
_lib.an_hdc_create.argtypes = [
    ctypes.c_int, ctypes.c_int, ctypes.c_int,
    ctypes.POINTER(ctypes.c_int),
]

_lib.an_hdc_free.restype = None
_lib.an_hdc_free.argtypes = [_AnHdcPtr]

_lib.an_hdc_train.restype = None
_lib.an_hdc_train.argtypes = [
    _AnHdcPtr,
    ctypes.POINTER(ctypes.c_double),
    ctypes.POINTER(ctypes.c_int),
    ctypes.c_int,
]

_lib.an_hdc_predict.restype = ctypes.c_int
_lib.an_hdc_predict.argtypes = [_AnHdcPtr, ctypes.POINTER(ctypes.c_double)]

_lib.an_hdc_predict_batch.restype = ctypes.c_int
_lib.an_hdc_predict_batch.argtypes = [
    _AnHdcPtr,
    ctypes.POINTER(ctypes.c_double),
    ctypes.POINTER(ctypes.c_int),
    ctypes.c_int,
]

_lib.an_hdc_save.restype = ctypes.c_int
_lib.an_hdc_save.argtypes = [_AnHdcPtr, ctypes.c_char_p]

_lib.an_hdc_load.restype = _AnHdcPtr
_lib.an_hdc_load.argtypes = [ctypes.c_char_p]

_lib.hv_seed.restype = None
_lib.hv_seed.argtypes = [ctypes.c_uint]

# HDC primitive bindings (for direct hypervector manipulation)

_HV_WORDS = 157  # HDC_WORDS = ceil(10000/64)
_HV_t = ctypes.c_uint64 * _HV_WORDS

_lib.hv_bind.restype = None
_lib.hv_bind.argtypes = [_HV_t, _HV_t, _HV_t]

_lib.hv_bundle.restype = None
_lib.hv_bundle.argtypes = [_HV_t, ctypes.POINTER(_HV_t), ctypes.c_int]

_lib.hv_hamming.restype = ctypes.c_int
_lib.hv_hamming.argtypes = [_HV_t, _HV_t]

_lib.hv_similarity.restype = ctypes.c_float
_lib.hv_similarity.argtypes = [_HV_t, _HV_t]

_lib.hv_random.restype = None
_lib.hv_random.argtypes = [_HV_t]

_lib.hv_copy.restype = None
_lib.hv_copy.argtypes = [_HV_t, _HV_t]

_lib.hv_add_noise.restype = None
_lib.hv_add_noise.argtypes = [_HV_t, _HV_t, ctypes.c_float]


# ---- Python wrapper ----

class AdderNetHDC:
    """
    Multivariate classifier using AdderNet encoding + Hyperdimensional Computing.
    Zero floating-point multiplication at inference.
    """

    def __init__(self, n_vars=1, n_classes=2, table_size=256, bias=None,
                 seed=42, _ptr=None):
        """
        Create a new model.

        Args:
            n_vars:     number of input variables
            n_classes:  number of output classes
            table_size: encoding table size per variable (power of 2)
            bias:       list of bias values per variable (default: table_size//2)
            seed:       random seed for reproducibility
        """
        if _ptr is not None:
            self._ptr = _ptr
            self._n_vars = n_vars
            self._n_classes = n_classes
            self._table_size = table_size
            return

        _lib.hv_seed(seed)

        bias_arr = None
        if bias is not None:
            bias_arr = (ctypes.c_int * n_vars)(*bias)

        self._ptr = _lib.an_hdc_create(n_vars, n_classes, table_size, bias_arr)
        if not self._ptr:
            raise MemoryError("an_hdc_create failed")
        self._n_vars = n_vars
        self._n_classes = n_classes
        self._table_size = table_size

    def __del__(self):
        if hasattr(self, "_ptr") and self._ptr:
            _lib.an_hdc_free(self._ptr)
            self._ptr = None

    def train(self, X, y):
        """
        Train the codebook from labeled data.

        Args:
            X: n_samples × n_vars array (list of lists or numpy array)
            y: n_samples class labels (int, 0-indexed)
        """
        X = np.ascontiguousarray(X, dtype=np.float64)
        y = np.ascontiguousarray(y, dtype=np.int32)

        if X.ndim == 1:
            X = X.reshape(-1, self._n_vars)

        n = X.shape[0]
        if len(y) != n:
            raise ValueError(f"X has {n} samples but y has {len(y)}")

        _lib.an_hdc_train(
            self._ptr,
            X.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
            y.ctypes.data_as(ctypes.POINTER(ctypes.c_int)),
            n,
        )

    def predict(self, x):
        """
        Classify one sample.

        Args:
            x: list or array of n_vars input values
        Returns:
            predicted class label (int)
        """
        x = np.ascontiguousarray(x, dtype=np.float64)
        return _lib.an_hdc_predict(
            self._ptr,
            x.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
        )

    def predict_batch(self, X):
        """
        Classify multiple samples.

        Args:
            X: n_samples × n_vars array
        Returns:
            numpy array of predicted class labels
        """
        X = np.ascontiguousarray(X, dtype=np.float64)
        if X.ndim == 1:
            X = X.reshape(-1, self._n_vars)
        n = X.shape[0]
        outputs = np.empty(n, dtype=np.int32)
        _lib.an_hdc_predict_batch(
            self._ptr,
            X.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
            outputs.ctypes.data_as(ctypes.POINTER(ctypes.c_int)),
            n,
        )
        return outputs

    def save(self, path):
        """Save model to binary file."""
        ret = _lib.an_hdc_save(self._ptr, path.encode("utf-8"))
        if ret != 0:
            raise IOError(f"an_hdc_save failed: {path}")

    @classmethod
    def load(cls, path):
        """Load model from binary file."""
        ptr = _lib.an_hdc_load(path.encode("utf-8"))
        if not ptr:
            raise IOError(f"an_hdc_load failed: {path}")
        return cls(_ptr=ptr)

    @property
    def n_vars(self):
        return self._n_vars

    @property
    def n_classes(self):
        return self._n_classes

    @property
    def table_size(self):
        return self._table_size

    @property
    def codebook(self):
        """
        Return the trained codebook as a list of numpy uint64 arrays.
        Each array has 157 words (10000 bits).

        Requires the model to be trained first.
        """
        _HDC_WORDS = 157

        # Read the codebook pointer from the an_hdc_model struct.
        # On x86_64, the codebook hv_t* field is at byte offset 32
        # (after n_vars, n_classes, table_size, table_mask, bias*, enc_table*).
        buf = ctypes.string_at(self._ptr, 48)  # read first 48 bytes of struct
        cb_addr = int.from_bytes(buf[32:40], byteorder='little')
        if cb_addr == 0:
            raise RuntimeError("Model not trained yet (codebook is NULL)")

        # Cast the address to a flat uint64 array
        cb = ctypes.cast(
            ctypes.c_void_p(cb_addr),
            ctypes.POINTER(ctypes.c_uint64 * (_HDC_WORDS * self._n_classes))
        )

        result = []
        flat = cb.contents  # the full (HDC_WORDS * n_classes) uint64 array
        for c in range(self._n_classes):
            offset = c * _HDC_WORDS
            hv = np.array([flat[offset + i] for i in range(_HDC_WORDS)],
                          dtype=np.uint64)
            result.append(hv)
        return result

    def __repr__(self):
        return (f"AdderNetHDC(n_vars={self._n_vars}, "
                f"n_classes={self._n_classes}, "
                f"table_size={self._table_size})")
