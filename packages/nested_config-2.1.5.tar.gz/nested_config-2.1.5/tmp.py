import nested_config

class Dimensions:
    length: int
    width: int
    height: int


class House:
    name: str
    dimensions: Dimensions


class HouseMaybeDim:
    name: str
    dimensions: Dimensions | None


class HouseListDim:
    name: str
    dimensions: list[Dimensions]


class HouseDictDim:
    name: str
    dimensions: dict[str, Dimensions]


class Garage:
    name: str
    dimensions: Dimensions


class HouseWithGarage(House):
    garage: Garage | None


class Neighborhood:
    name: str
    houses: list[HouseWithGarage]


house_path = "tests/toml_files/house.toml"
nested_config.expand_config(house_path, House)
