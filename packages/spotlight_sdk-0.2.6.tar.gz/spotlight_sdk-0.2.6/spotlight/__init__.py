"""
Spotlight software development kit.
"""
