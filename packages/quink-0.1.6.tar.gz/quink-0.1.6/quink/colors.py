from .config import QUINK_COLORS
import colorsys
import random


def gen_colors(
    base_hex: str = QUINK_COLORS["dark_green"],
    n: int = 10,
    step: float = 0.03
) -> list[str]:
    """
    Generate spaced dark-style variants from a base color.

    Parameters
    ----------
    base_hex : str
        Base color in hex format (e.g. "#2E5F73").
        Defines the reference hue around which variants are generated.

    n : int, default=10
        Number of colors to generate.

    step : float, default=0.03
        Increment applied to hue at each step.
        Controls how much colors spread along the hue axis:
        - small (~0.01-0.03) -> very similar colors (tight palette)
        - medium (~0.03-0.07) -> balanced variation
        - large (>0.08) -> wider variation, less coherence

    """
    h, _, _ = colorsys.rgb_to_hls(*[
        int(base_hex[i:i+2], 16) / 255 for i in (1, 3, 5)
    ])

    colors = []

    for i in range(n):
        h_i = (h + i * step + random.uniform(-0.01, 0.01)) % 1
        l_i = random.uniform(0.25, 0.55)
        s_i = random.uniform(0.25, 0.55)

        r, g, b = colorsys.hls_to_rgb(h_i, l_i, s_i)
        colors.append(f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}")

    return colors
