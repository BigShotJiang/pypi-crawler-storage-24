from __future__ import annotations

import json
import re
import sys
from argparse import ArgumentParser
from pathlib import Path

from dump_things_service.audit.gitaudit import GitAuditBackend


parser = ArgumentParser(
    prog='Report audit information for a PID',
    description='Report the audit information that was stored for a specific '
                'PID. For every change to a record the tool will report: '
                'time stamp, user ID, diff, and the resulting record.',
)
parser.add_argument(
    'audit_store',
    help='The path to the gitaudit store',
)
parser.add_argument(
    'pid',
    help='Regex pattern that identifies PIDs of the record for which audit '
         'information should be reported '
         '(to see all audit log entries, specify ".*").',
)


def main():
    arguments = parser.parse_args()

    try:
        re.compile(arguments.pid)
    except re.error as e:
        print('Error in PID pattern:', e, file=sys.stderr, flush=True)
        return 1

    audit_backend = GitAuditBackend(Path(arguments.audit_store))
    all_changes = audit_backend.get_audit_logs(arguments.pid)
    for record_id, report_changes in all_changes.items():
        for time_stamp, change in report_changes.items():
            report = {
                'time-stamp': time_stamp,
                'record-id': record_id,
                'committer-id': change[0],
                'author-id': change[1],
                'diff': change[2],
                'resulting-record': change[3],
            }
            print(json.dumps(report, ensure_ascii=False), flush=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())
