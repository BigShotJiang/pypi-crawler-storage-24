from __future__ import annotations

import sys
from argparse import ArgumentParser
from pathlib import Path

from dump_things_service.audit.gitaudit import GitAuditBackend


parser = ArgumentParser(
    prog='Rebuild the index of a `gitaudit`-database',
    description='This command rebuilds the index of a `gitaudit`-database.'
)
parser.add_argument(
    'audit_store',
    help='The directory in which the `gitaudit`-database is located.'
)


def main():
    arguments = parser.parse_args()

    audit_backend = GitAuditBackend(Path(arguments.audit_store))
    audit_backend._rebuild_index()
    return 0


if __name__ == '__main__':
    sys.exit(main())
