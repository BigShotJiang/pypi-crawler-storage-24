from abc import (
    ABCMeta,
    abstractmethod,
)


class AuditBackend(metaclass=ABCMeta):
    @abstractmethod
    def add_record(
            self,
            record: dict,
            committer_id: str,
            author_id: str | None = None,
    ) -> None:
        """Add information about a new record version to the audit log

        :param record: the content of the new record. The record must contain
               a `pid`-key which is associated with the ID of the record (the
               record will be stored in YAML format).
        :param committer_id: the ID of the user who adds the record.
        :param author_id: the ID of the user who modified the record, defaults
               to `committer_id` if not given.
        :return: A dictionary where the keys are time stamps of the changes,
                 the values are tuples containing the elements:
                 (user_id, diff, resulting_record), where user_id is the
                 `user_id` that was used in `add_record`, `resulting_record` is
                 the YAML-representation of `record` that was given to
                 `add_record`, and diff is path the transfers the previous
                 version of the record to the version provided in `record` (in
                 git-diff format).
        """
        raise NotImplementedError

    @abstractmethod
    def flush(self):
        """Ensure that all audit-log entries are persisted on disk

        After `flush()` is external tools should be able to pick up all
        log-entries from the persisted data.
        """
        raise NotImplementedError

    @abstractmethod
    def get_audit_log(
            self,
            record_id: str,
    ) -> dict:
        """Get the content of the audit log

        All diffs and content are communicated in YAML format.

        :param record_id: the ID of the record (as given in the parameter
               `record_id` in the call to `add_record`).
        :return: A dictionary where the keys are time stamps of the changes,
                 the values are tuples containing the elements:
                 (user_id, diff, resulting_record), where user_id is the
                 `user_id` that was used in `add_record`, `resulting_record` is
                 the YAML-representation of `record` that was given to
                 `add_record`, and diff is path the transfers the previous
                 version of the record to the version provided in `record` (in
                 git-diff format).
        """
        raise NotImplementedError
