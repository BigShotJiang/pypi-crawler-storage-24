# Project sdks

- You can install our sdks via our internal cli tools.

# Installation.
```
pip install cashfin-business-sdk
```

# Development
- When it comes to setting up the project, we use UV.
 