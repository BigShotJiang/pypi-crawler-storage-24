""" Business Class """

from . import BaseBizCashfin

class CashfinBusiness(BaseBizCashfin):
    """ CB SDK"""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        
    @property
    def payment(self):
        """Payments"""
        from .payments.payments import Payments
        return Payments(self.base_url, api_key=self.api_key)