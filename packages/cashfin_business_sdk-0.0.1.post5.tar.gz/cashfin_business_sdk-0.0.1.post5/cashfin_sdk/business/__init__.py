
import requests

class BaseBizCashfin:
    app_namespace = "business"
    resource_namespace = ""

    def __init__(self, base_url, api_key) -> None:
        self.base_url = base_url
        self.api_key = api_key
        self.biz_url = self.url_join(base_url, self.app_namespace)


    def url_join(self, base, *paths):
        """Join URL paths correctly, ensuring proper slash handling"""
        url = base.rstrip('/')
        for path in paths:
            url = f"{url}/{path.strip('/')}"
        return url
    
    @property
    def request(self):
        return requests

    @property
    def base_headers(self):
        return {
            "Authorization": self.api_key,
            "Content-Type": "application/json"
        }
        