from cashfin_sdk.business import BaseBizCashfin

class Payments(BaseBizCashfin):
    """Payments functionality"""
    resource_namespace = "payments"

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.base_payment_url = self.url_join(self.biz_url, self.resource_namespace)

    def _format_phone_number(self, phone_number: str):
        """ Format phone number"""
        if phone_number.startswith("+"):
            phone_number = phone_number.split("+")[1]
        return phone_number

    def request_stk_push(self, phone_number, ref_id, amount, channel="mpesa"):
        """ Request STK push"""
        request_url = self.url_join(self.base_payment_url, 'mobile/request')
        response = self.request.post(
            request_url,
            json={
                "amount": amount,
                "phone": self._format_phone_number(phone_number),
                "referenceid": ref_id
            },
            headers=self.base_headers,
        )
        result = response.json()
        return result
        