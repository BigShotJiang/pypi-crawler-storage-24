""" Entry point to the rest of the API endpoints."""

from cashfin_sdk.env_wrap import CashfinEnviron
from cashfin_sdk.business.business import CashfinBusiness


class CashfinSDK():
    """ Cashfin sdk
    This class is the entry point to accessing the api endpoints for cashfin business.
    This class should enable you to:
    - Access and perform operations on the shop and products (API)
    - Access and perform operations on the order (API)
    - Access and perform operations on the payments and invoicing (API)
    - Access and perform operations on the subscriptions (API)
    - Access and perform operations on the crm and customers (API)
    """

    def __init__(self) -> None:
        """ Class initialization function."""
        self.configs = CashfinEnviron()

    @property
    def api_key(self):
        """ Authenticate with Cashfin
            - Authenticate and Retry mechanism
            - Cache and invalidate based on certain error types
        - This is not scalable. Having just the key. 
        (TO:DO)
        - Should have public endpoints to return back:
            - Call to return a new api_key (should authenticate)
            - Call to refresh and get a new Key
        """
        api_key = self.configs.cashfin_client_secret  #type: ignore
        return api_key

    @property
    def base_url(self):
        """Base URL"""
        return self.configs.cashfin_base_url  #type: ignore

    @property
    def business(self):
        """_summary_
        """
        return CashfinBusiness(self.base_url, api_key=self.api_key)






