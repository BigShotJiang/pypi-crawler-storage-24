""" It houses all the settings necessary for this app """

import os


class CashfinEnviron():
    """ Grab or get app settings or environ.
    - Environment values
    - Yaml configurations
    """
    def __init__(self) -> None:
        """initialization class process"""
        self._add_env_from_environment()

    def _add_env_from_environment(self):
        """Set environment values as class properties
        - Should work for Flask
        """
        for key in os.environ.keys():
            if key.startswith("CASHFIN"):
                setattr(self, key.lower(), os.environ.get(key))
       