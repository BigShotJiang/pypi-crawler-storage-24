# -*- coding: utf-8 -*-

"""
@Time    : 2026/3/9 21:20
@File    : coco.py
@Author  : zj
@Description: COCO format visualizer using label handler
"""

import os
from typing import List, Dict, Any, Optional

from .generic import GenericVisualizer
from ..label.coco import CocoHandler
from ..config import Config


class CocoVisualizer(GenericVisualizer):
    """Visualizer for COCO format annotations using CocoHandler."""

    def __init__(self, verbose: bool = None, segmentation: bool = False):
        """Initialize COCO visualizer.

        Args:
            verbose: Whether to print progress information.
                If None, uses Config.VERBOSE.
            segmentation: Whether to force segmentation mode (strict validation).
                If True, annotations must contain valid segmentation data.
        """
        super().__init__(verbose, segmentation)
        self.label_handler = CocoHandler(verbose=verbose)

    def visualize(self,
                  image_dir: str,
                  annotation_json: str,
                  save_dir: Optional[str] = None) -> Dict[str, Any]:
        """
        Visualize COCO annotations on images.

        Args:
            image_dir (str): Directory containing image files
            annotation_json (str): Path to COCO JSON annotation file
            save_dir (Optional[str]): Directory to save visualized images.
                If None, images are only displayed.

        Returns:
            Dict with visualization results:
                - images_processed: Number of images processed
                - images_with_annotations: Number of images with annotations
                - annotations_processed: Total number of annotations drawn
                - categories_found: List of category IDs found in annotations
                - saved_images: Number of images saved (if save_dir provided)
                - save_dir: Path where images were saved (if save_dir provided)
        """
        # Validate inputs
        if not self.validate_input_path(image_dir, is_dir=True):
            raise ValueError(f"Invalid image directory: {image_dir}")
        if not self.validate_input_path(annotation_json, is_dir=False):
            raise ValueError(f"Invalid annotation file: {annotation_json}")
        if save_dir and not self.validate_output_path(save_dir, is_dir=True, create=True):
            raise ValueError(f"Invalid save directory: {save_dir}")

        # Load COCO annotations using CocoHandler
        try:
            coco_data = self.label_handler.read(annotation_json)
        except Exception as e:
            raise ValueError(f"Failed to read COCO annotations: {e}")

        # Convert to unified format
        try:
            annotations_list = self.label_handler.convert_to_unified_format(
                coco_data=coco_data,
                image_dir=image_dir,
                require_segmentation=self.segmentation
            )
        except Exception as e:
            raise ValueError(f"Failed to convert COCO annotations: {e}")

        if not annotations_list:
            self.logger.warning(f"No annotations found in {annotation_json}")
            # Return empty results
            return self._create_results_template(
                annotation_json=annotation_json,
                image_dir=image_dir,
                save_dir=save_dir,
                total_images=len(coco_data.get("images", []))
            )

        # Create results template
        results = self._create_results_template(
            annotation_json=annotation_json,
            image_dir=image_dir,
            save_dir=save_dir,
            total_images=len(annotations_list)
        )

        self.logger.info("Starting visualization...")
        if save_dir:
            self.logger.info(f"Images will be saved to: {save_dir}")

        # Get category map for class names
        category_map = self.label_handler.get_category_map(coco_data)
        categories = list(category_map.values())

        # Process each image
        for i, image_data in enumerate(annotations_list):
            image_result = self._process_image_annotations(
                image_data=image_data,
                classes=categories,
                save_dir=save_dir
            )

            # Update aggregated results
            self._update_results_from_image(
                results=results,
                image_result=image_result,
                annotations=image_data.get("annotations", [])
            )

            # Check if visualization was stopped by user
            if image_result.get("stopped"):
                results["stopped_by_user"] = True
                break

            self._print_progress(i + 1, len(annotations_list), "Visualization ")

        # Close windows if they were opened and visualization wasn't saved
        if not save_dir and not results.get("stopped_by_user"):
            self.close_windows()

        # Convert set to list for JSON serialization
        results["categories_found"] = list(results["classes_found"])
        del results["classes_found"]  # Rename to categories_found for COCO

        self.logger.info("Visualization completed")
        self.logger.info(f"Processed {results['images_processed']} images")
        self.logger.info(f"Found {results['annotations_processed']} annotations")
        self.logger.info(f"Categories found: {results['categories_found']}")
        if save_dir:
            self.logger.info(f"Saved {results['saved_images']} images to {save_dir}")

        return results

    def batch_visualize(self,
                        image_dirs: List[str],
                        annotation_jsons: List[str],
                        save_dirs: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """
        Visualize multiple COCO datasets.

        Args:
            image_dirs (List[str]): List of image directories
            annotation_jsons (List[str]): List of annotation JSON files
            save_dirs (Optional[List[str]]): List of save directories

        Returns:
            List of visualization results
        """
        if len(image_dirs) != len(annotation_jsons):
            raise ValueError("image_dirs and annotation_jsons must have the same length")

        if save_dirs is not None and len(save_dirs) != len(image_dirs):
            raise ValueError("save_dirs must have same length as image_dirs")

        results = []
        for i, (image_dir, annotation_json) in enumerate(zip(image_dirs, annotation_jsons)):
            save_dir = save_dirs[i] if save_dirs else None
            self.logger.info(f"Processing dataset {i+1}/{len(image_dirs)}")

            try:
                result = self.visualize(image_dir, annotation_json, save_dir)
                results.append(result)
            except Exception as e:
                self.logger.error(f"Failed to visualize dataset {i+1}: {e}")
                if Config.OVERWRITE_EXISTING:
                    raise
                else:
                    results.append(None)

        return results