#!/usr/bin/env python
"""Template: Base table enrichment — trade events + order book at create_ts + univ.

Pipeline:
  scan_trade → parse_time → cumulative fills
  scan_quote → parse_time
  merge_forward(create_ts, h=0, [bid_size0, ask_size0]) → book at order time
  join univ → avg_touch_size
  write base/{date}.parquet

The base table contains one row per trade event (ORDACK, FILL, CANCEL)
with the order book snapshot at ORDER CREATION TIME (not fill time).
This is critical for queue position analysis of JOIN orders.

Key columns added beyond raw trade log:
  bid_size0_at_order   — bid L1 depth when order was placed
  ask_size0_at_order   — ask L1 depth when order was placed
  avg_touch_size       — historical average L1 depth for this ukey (from univ)

CLI:
  python base_enrichment_by_date.py --date 20251103
  python base_enrichment_by_date.py --date 20251103 --force

Requires: pip install vizflow
"""
from __future__ import annotations

import argparse
from pathlib import Path

import polars as pl
import vizflow as vf


# ═══════════════════════════════════════════════════════════════
# CONFIG — edit for your environment
# ═══════════════════════════════════════════════════════════════
TRADE_DIR = Path("/cpfs/user2/ylu/data/oic_live/concat_sort")
TRADE_PATTERN = "{date}.parquet"
TRADE_SCHEMA = "oic_live"

QUOTE_DIR = Path("/gpfs/nvmefs/marketdata/cn/stock/all/tob5")
QUOTE_PATTERN = "{date}.feather"
QUOTE_SCHEMA = "stock_sorted_t5ob"

UNIV_DIR = Path("/cpfs/shared/public/ylu/univ")

OUTPUT_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched")
MARKET = "CN"

# Time columns
TRADE_TIME_COL = "update_exchange_ts"
CREATE_TIME_COL = "create_exchange_ts"
QUOTE_TIME_COL = "ticktime"

# Quote columns for order book at create_ts
BOOK_REF_COLS = ["bid_size0", "ask_size0"]


# ═══════════════════════════════════════════════════════════════
# CORE
# ═══════════════════════════════════════════════════════════════
def process_date(date: str) -> pl.DataFrame:
    """Build base table for one date.

    Args:
        date: Date string in YYYYMMDD format.

    Returns:
        DataFrame with one row per trade event, enriched with book_at_order + univ.
    """
    elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
    elapsed_create = f"elapsed_{CREATE_TIME_COL}"
    elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"

    # --- Load trade (lazy) ---
    lf_trade = (
        vf.scan_trade(date)
        .pipe(vf.parse_time, TRADE_TIME_COL)
        .pipe(vf.parse_time, CREATE_TIME_COL)
        .sort(["ukey", elapsed_trade])
        .with_columns(
            pl.col("fill_qty")
            .cum_sum()
            .over(["data_date", "ukey", "order_id"])
            .alias("cum_fill_qty"),
        )
        .with_columns(
            (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
            (pl.col(elapsed_trade) - pl.col(elapsed_create)).alias("duration"),
        )
    )

    # --- Load quote (lazy) ---
    lf_quote = (
        vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + BOOK_REF_COLS)
        .pipe(vf.parse_time, QUOTE_TIME_COL)
    )

    # --- Book at order time: backward asof on create_ts, h=0 ---
    df_base = vf.merge_forward(
        lf_trade, lf_quote,
        ref_cols=BOOK_REF_COLS,
        horizons=[0],
        trade_time_col=elapsed_create,
        ref_time_col=elapsed_quote,
        strategy="backward",
    )

    # Rename h=0 columns to _at_order
    df_base = df_base.rename({
        f"{col}_0s": f"{col}_at_order" for col in BOOK_REF_COLS
    })

    # --- Join univ for avg_touch_size ---
    univ_path = UNIV_DIR / f"{date}.csv"
    if univ_path.exists():
        df_univ = pl.read_csv(str(univ_path)).select(
            "ukey",
            pl.col("avg_touch_size_mean").alias("avg_touch_size"),
        )
        df_base = df_base.join(df_univ, on="ukey", how="left")

    return df_base


# ═══════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True, help="Date in YYYYMMDD format")
    parser.add_argument("--force", action="store_true", help="Overwrite existing files")
    args = parser.parse_args()

    vf.set_config(vf.Config(
        trade_dir=TRADE_DIR,
        trade_pattern=TRADE_PATTERN,
        trade_schema=TRADE_SCHEMA,
        quote_dir=QUOTE_DIR,
        quote_pattern=QUOTE_PATTERN,
        quote_schema=QUOTE_SCHEMA,
        market=MARKET,
    ))

    out_dir = OUTPUT_DIR / "base"
    out_file = out_dir / f"{args.date}.parquet"

    if out_file.exists() and not args.force:
        print(f"  skip {args.date} (exists)")
        return

    print(f"Processing {args.date}...")
    df = process_date(args.date)
    print(f"  {len(df)} events, {len(df.columns)} columns")

    out_dir.mkdir(parents=True, exist_ok=True)
    df.write_parquet(str(out_file))
    print(f"  -> {out_file}")


if __name__ == "__main__":
    main()
