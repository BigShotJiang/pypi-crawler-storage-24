#!/usr/bin/env python
"""Template: Forward enrichment on update_ts — quote snapshots at each horizon after fill.

Pipeline:
  scan_trade → parse_time → cumulative fills
  scan_quote → parse_time
  merge_forward(update_ts, all horizons, [bid/ask_px0, bid/ask_size0])
  wide → semi-wide (one row per seq × horizon)
  derived columns: mid, spread, touch, markout, return, sided_*
  write forward/{date}.parquet

The forward table uses update_exchange_ts (fill/event time) as the anchor.
For each trade event at time T, it records the quote book at T+h for each horizon h.

This answers: "After this fill, how did the market move?"

Companion script: forward_on_create_by_date.py uses create_exchange_ts instead,
answering: "After this order was placed, how did the market move?"

CLI:
  python forward_on_update_by_date.py --date 20251103
  python forward_on_update_by_date.py --date 20251103 --force

Requires: pip install vizflow
"""
from __future__ import annotations

import argparse
from pathlib import Path

import polars as pl
import vizflow as vf


# ═══════════════════════════════════════════════════════════════
# CONFIG — edit for your environment
# ═══════════════════════════════════════════════════════════════
TRADE_DIR = Path("/cpfs/user2/ylu/data/oic_live/concat_sort")
TRADE_PATTERN = "{date}.parquet"
TRADE_SCHEMA = "oic_live"

QUOTE_DIR = Path("/gpfs/nvmefs/marketdata/cn/stock/all/tob5")
QUOTE_PATTERN = "{date}.feather"
QUOTE_SCHEMA = "stock_sorted_t5ob"

OUTPUT_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched")
MARKET = "CN"

# Time columns
TRADE_TIME_COL = "update_exchange_ts"
CREATE_TIME_COL = "create_exchange_ts"
QUOTE_TIME_COL = "ticktime"

# Forward merge config
HORIZONS = [int(h * 1000) for h in [
    -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
]]
RAW_REF_COLS = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]


# ═══════════════════════════════════════════════════════════════
# CORE
# ═══════════════════════════════════════════════════════════════
def process_date(date: str) -> pl.DataFrame:
    """Build forward table for one date, anchored on update_ts.

    Args:
        date: Date string in YYYYMMDD format.

    Returns:
        DataFrame in semi-wide format: one row per (seq × horizon),
        with raw ref cols + derived columns.
    """
    elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
    elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"

    # --- Load trade (lazy) ---
    lf_trade = (
        vf.scan_trade(date)
        .pipe(vf.parse_time, TRADE_TIME_COL)
        .pipe(vf.parse_time, CREATE_TIME_COL)
        .sort(["ukey", elapsed_trade])
        .with_columns(
            pl.col("fill_qty")
            .cum_sum()
            .over(["data_date", "ukey", "order_id"])
            .alias("cum_fill_qty"),
        )
        .with_columns(
            (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
        )
    )

    # --- Load quote (lazy) ---
    lf_quote = (
        vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + RAW_REF_COLS)
        .pipe(vf.parse_time, QUOTE_TIME_COL)
    )

    # --- Forward merge on update_ts ---
    df_merged = vf.merge_forward(
        lf_trade, lf_quote,
        ref_cols=RAW_REF_COLS,
        horizons=HORIZONS,
        trade_time_col=elapsed_trade,
        ref_time_col=elapsed_quote,
        strategy="backward",
    )

    # --- Wide → semi-wide (one row per seq × horizon) ---
    id_cols = ["seq", "data_date"]
    frames = []
    for h in HORIZONS:
        suffix = vf.horizon_suffix(h)
        rename_map = {f"{rc}_{suffix}": rc for rc in RAW_REF_COLS}
        frame = (
            df_merged.select(id_cols + list(rename_map.keys()))
            .rename(rename_map)
            .with_columns(pl.lit(h, dtype=pl.Int64).alias("horizon"))
        )
        frames.append(frame)
    df_forward = pl.concat(frames)

    # --- Derived columns ---
    # Join fill_price + order_side from trade (df_merged has them)
    df_fwd = df_forward.join(
        df_merged.select(["seq", "data_date", "fill_price", "order_side"]),
        on=["seq", "data_date"],
    )
    is_buy = pl.col("order_side") == "Buy"

    # Phase 1: mid, spread, touch
    df_fwd = df_fwd.with_columns([
        pl.mean_horizontal("bid_px0", "ask_px0").alias("mid"),
        (pl.col("ask_px0") - pl.col("bid_px0")).alias("spread"),
        pl.when(is_buy).then(pl.col("bid_px0")).otherwise(pl.col("ask_px0")).alias("near_touch_px"),
        pl.when(is_buy).then(pl.col("ask_px0")).otherwise(pl.col("bid_px0")).alias("far_touch_px"),
        pl.when(is_buy).then(pl.col("bid_size0")).otherwise(pl.col("ask_size0")).alias("near_touch_size"),
        pl.when(is_buy).then(pl.col("ask_size0")).otherwise(pl.col("bid_size0")).alias("far_touch_size"),
    ])
    df_fwd = df_fwd.with_columns(
        (pl.col("spread") / pl.col("mid") * 10000).alias("spread_bps"),
    )

    # Phase 2: markout, fill_to_near/far_touch
    df_fwd = df_fwd.with_columns([
        (pl.col("mid") / pl.col("fill_price") - 1).alias("markout"),
        (pl.col("near_touch_px") / pl.col("fill_price") - 1).alias("fill_to_near_touch"),
        (pl.col("far_touch_px") / pl.col("fill_price") - 1).alias("fill_to_far_touch"),
    ])

    # Phase 3: return (cross-horizon, needs mid_0)
    mid_0 = (
        df_fwd.filter(pl.col("horizon") == 0)
        .select(["seq", "data_date", pl.col("mid").alias("mid_0")])
    )
    df_fwd = df_fwd.join(mid_0, on=["seq", "data_date"])
    df_fwd = df_fwd.with_columns(
        ((pl.col("mid") - pl.col("mid_0")) / pl.col("mid_0")).alias("return")
    ).drop("mid_0")

    # Phase 4: sided (Sell → negate)
    sided_cols = ["return", "markout", "fill_to_near_touch", "fill_to_far_touch"]
    df_fwd = df_fwd.with_columns([
        pl.when(pl.col("order_side") == "Sell").then(-pl.col(c)).otherwise(pl.col(c)).alias(f"sided_{c}")
        for c in sided_cols
    ])

    # Drop temp join cols
    df_fwd = df_fwd.drop(["fill_price", "order_side"])

    return df_fwd


# ═══════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True, help="Date in YYYYMMDD format")
    parser.add_argument("--force", action="store_true", help="Overwrite existing files")
    args = parser.parse_args()

    vf.set_config(vf.Config(
        trade_dir=TRADE_DIR,
        trade_pattern=TRADE_PATTERN,
        trade_schema=TRADE_SCHEMA,
        quote_dir=QUOTE_DIR,
        quote_pattern=QUOTE_PATTERN,
        quote_schema=QUOTE_SCHEMA,
        market=MARKET,
    ))

    out_dir = OUTPUT_DIR / "fwd_update"
    out_file = out_dir / f"{args.date}.parquet"

    if out_file.exists() and not args.force:
        print(f"  skip {args.date} (exists)")
        return

    print(f"Processing {args.date}...")
    df = process_date(args.date)
    print(f"  {len(df)} rows ({len(HORIZONS)} horizons)")

    out_dir.mkdir(parents=True, exist_ok=True)
    df.write_parquet(str(out_file))
    print(f"  -> {out_file}")


if __name__ == "__main__":
    main()
