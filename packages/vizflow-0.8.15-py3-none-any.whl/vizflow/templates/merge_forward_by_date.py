#!/usr/bin/env python
"""Template: Forward-merge one date (quote ref) -> Delta Lake.

Pipeline:
  scan_trade -> parse_time                            (lazy -> collect)
  scan_quote -> parse_time                            (lazy -> collect)
  merge_forward(trade, quote, horizons)               (cross-join + asof)
  base/forward split -> Delta Lake

Uses tick-by-tick quote data as the reference source for merge_forward.
Cross-join approach: collect once, cross-join trade x horizons, single
sort, single asof join, then pivot to wide format.

Forward table format: semi-wide (one row per trade × horizon).
  Each ref_col is a separate column with its native type (no melt).
  Partition: [data_date, horizon]

Delta Lake write strategy:
  - Partition-level overwrite via predicate (concurrent-safe, idempotent)
  - Incremental: auto-detects missing horizons, only computes what's needed
  - Use --force to reprocess even if complete

To use this template:
  1. Copy: vf.templates.copy_template("merge_forward_by_date.py", "my_enrich.py")
  2. Edit CONFIG section with your data paths
  3. Edit FORWARD MERGE CONFIG with your horizons and ref_cols
  4. Run: python my_enrich.py --date 20240827

Adding new horizons: append to HORIZONS list, re-run — only new horizons
are computed. Adding new ref_cols: append to REF_COLS list, re-run with
--force (schema change requires full reprocess for affected dates).

Output: enriched/base/ and enriched/forward/ (Delta Lake)

Requires: pip install deltalake vizflow[fst]
"""
from __future__ import annotations

import argparse
from collections.abc import Sequence
from pathlib import Path

import polars as pl
import vizflow as vf

try:
    from deltalake import DeltaTable, write_deltalake
except ImportError:
    raise ImportError("deltalake required. Install: pip install deltalake")


# ═══════════════════════════════════════════════════════════════
# CONFIG — edit for your environment
# ═══════════════════════════════════════════════════════════════
TRADE_DIR = Path("/cpfs/user2/ylu/data/oic_live/concat_sort")
TRADE_PATTERN = "{date}.parquet"
TRADE_SCHEMA = "oic_live"

QUOTE_DIR = Path("/gpfs/nvmefs/marketdata/cn/stock/all/tob5")
QUOTE_PATTERN = "{date}.feather"
QUOTE_SCHEMA = "stock_sorted_t5ob"

OUTPUT_DIR = Path("/cpfs/user2/ylu/data/oic_live/merge_forward")
MARKET = "CN"


# ═══════════════════════════════════════════════════════════════
# FORWARD MERGE CONFIG — edit for your analysis
# ═══════════════════════════════════════════════════════════════
# Horizons in milliseconds
HORIZONS = [int(h * 1000) for h in [-10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600]]
RAW_REF_COLS = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]

TRADE_TIME_COL = "update_exchange_ts"
CREATE_TIME_COL = "create_exchange_ts"
QUOTE_TIME_COL = "ticktime"


# ═══════════════════════════════════════════════════════════════
# DELTA LAKE HELPERS
# ═══════════════════════════════════════════════════════════════
def _missing_horizons(
    forward_path: str,
    date_iso: str,
    horizons: Sequence[int],
) -> list[int]:
    """Return horizons not yet written for this date (metadata-only)."""
    try:
        dt = DeltaTable(forward_path)
    except Exception:
        return list(horizons)
    parts = dt.partitions()
    existing = {int(p["horizon"]) for p in parts if p["data_date"] == date_iso}
    return [h for h in horizons if h not in existing]


def _write_delta(
    df: pl.DataFrame,
    table_path: str,
    partition_by: list[str],
    predicate: str,
) -> None:
    """Write DataFrame to Delta Lake with partition-level overwrite."""
    if not DeltaTable.is_deltatable(table_path):
        write_deltalake(table_path, df.to_arrow(), partition_by=partition_by, mode="error")
    else:
        write_deltalake(table_path, df.to_arrow(), mode="overwrite", predicate=predicate)


# ═══════════════════════════════════════════════════════════════
# PROCESS ONE DATE
# ═══════════════════════════════════════════════════════════════
def process_date(date: str, horizons: Sequence[int]) -> tuple[pl.DataFrame, pl.DataFrame]:
    """Process one date: merge forward quote prices to each trade fill.

    Args:
        date: Date string in YYYYMMDD format.
        horizons: Horizons in ms to compute. May be a subset of HORIZONS
            when only missing horizons need to be filled in.

    Returns:
        (df_base, df_forward) tuple
    """
    elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
    elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"
    elapsed_create = f"elapsed_{CREATE_TIME_COL}"

    # Load trade (lazy) — all events, sorted for cum_sum correctness
    lf_trade = (
        vf.scan_trade(date)
        .pipe(vf.parse_time, TRADE_TIME_COL)
        .pipe(vf.parse_time, CREATE_TIME_COL)
        .sort(["ukey", elapsed_trade])
        .with_columns(
            pl.col("fill_qty").cum_sum().over(["data_date", "ukey", "order_id"]).alias("cum_fill_qty"),
        )
        .with_columns(
            (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
            (pl.col(elapsed_trade) - pl.col(elapsed_create)).alias("duration"),
        )
    )

    # Load quote (lazy) — t5ob schema: prices auto-scaled /10000
    lf_quote = (
        vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + RAW_REF_COLS)
        .pipe(vf.parse_time, QUOTE_TIME_COL)
    )

    # Forward merge: cross-join approach (collect once, single asof join)
    df_merged = vf.merge_forward(
        lf_trade, lf_quote,
        ref_cols=RAW_REF_COLS,
        horizons=list(horizons),
        trade_time_col=elapsed_trade,
        ref_time_col=elapsed_quote,
    )

    # Base table: trade-level columns (drop forward ref columns)
    forward_col_names = []
    for rc in RAW_REF_COLS:
        for h in horizons:
            forward_col_names.append(f"{rc}_{vf.horizon_suffix(h)}")
    base_cols = [c for c in df_merged.columns if c not in forward_col_names]
    df_base = df_merged.select(base_cols)

    # Forward table: semi-wide (one row per trade × horizon, ref_cols as columns)
    id_cols = ["seq", "data_date"]
    frames = []
    for h in horizons:
        suffix = vf.horizon_suffix(h)
        rename_map = {f"{rc}_{suffix}": rc for rc in RAW_REF_COLS}
        frame = (
            df_merged.select(id_cols + list(rename_map.keys()))
            .rename(rename_map)
            .with_columns(pl.lit(h, dtype=pl.Int64).alias("horizon"))
        )
        frames.append(frame)
    df_forward = pl.concat(frames)

    # ───────────────────────────────────────────────────────────
    # DERIVED COLUMNS on forward table
    # ───────────────────────────────────────────────────────────
    # Join with base cols needed for derivation
    df_fwd = df_forward.join(
        df_base.select(["seq", "data_date", "fill_price", "order_side"]),
        on=["seq", "data_date"],
    )
    is_buy = pl.col("order_side") == "Buy"

    # Phase 1: mid, spread, touch
    df_fwd = df_fwd.with_columns([
        pl.mean_horizontal("bid_px0", "ask_px0").alias("mid"),
        (pl.col("ask_px0") - pl.col("bid_px0")).alias("spread"),
        pl.when(is_buy).then(pl.col("bid_px0")).otherwise(pl.col("ask_px0")).alias("near_touch_px"),
        pl.when(is_buy).then(pl.col("ask_px0")).otherwise(pl.col("bid_px0")).alias("far_touch_px"),
        pl.when(is_buy).then(pl.col("bid_size0")).otherwise(pl.col("ask_size0")).alias("near_touch_size"),
        pl.when(is_buy).then(pl.col("ask_size0")).otherwise(pl.col("bid_size0")).alias("far_touch_size"),
    ])
    df_fwd = df_fwd.with_columns(
        (pl.col("spread") / pl.col("mid") * 10000).alias("spread_bps"),
    )

    # Phase 2: markout, fill_to_near_touch
    df_fwd = df_fwd.with_columns([
        (pl.col("mid") / pl.col("fill_price") - 1).alias("markout"),
        (pl.col("near_touch_px") / pl.col("fill_price") - 1).alias("fill_to_near_touch"),
        (pl.col("far_touch_px") / pl.col("fill_price") - 1).alias("fill_to_far_touch"),
    ])

    # Phase 3: return (cross-horizon, needs mid_0)
    mid_0 = (
        df_fwd.filter(pl.col("horizon") == 0)
        .select(["seq", "data_date", pl.col("mid").alias("mid_0")])
    )
    df_fwd = df_fwd.join(mid_0, on=["seq", "data_date"])
    df_fwd = df_fwd.with_columns(
        ((pl.col("mid") - pl.col("mid_0")) / pl.col("mid_0")).alias("return")
    ).drop("mid_0")

    # Phase 4: sided (creates sided_return, sided_markout, sided_fill_to_near_touch)
    sided_cols = ["return", "markout", "fill_to_near_touch", "fill_to_far_touch"]
    df_fwd = df_fwd.with_columns([
        pl.when(pl.col("order_side") == "Sell").then(-pl.col(c)).otherwise(pl.col(c)).alias(f"sided_{c}")
        for c in sided_cols
    ])

    # Drop temp join cols
    df_fwd = df_fwd.drop(["fill_price", "order_side"])

    return df_base, df_fwd


# ═══════════════════════════════════════════════════════════════
# CLI + MAIN
# ═══════════════════════════════════════════════════════════════
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True, help="Date in YYYYMMDD format")
    parser.add_argument("--force", action="store_true",
                        help="Force reprocess even if date is complete")
    args = parser.parse_args()

    vf.set_config(vf.Config(
        trade_dir=TRADE_DIR,
        trade_pattern=TRADE_PATTERN,
        trade_schema=TRADE_SCHEMA,
        quote_dir=QUOTE_DIR,
        quote_pattern=QUOTE_PATTERN,
        quote_schema=QUOTE_SCHEMA,
        market=MARKET,
    ))

    # YYYYMMDD -> YYYY-MM-DD (Delta Lake partition format for pl.Date)
    date_iso = f"{args.date[:4]}-{args.date[4:6]}-{args.date[6:8]}"
    base_path = str(OUTPUT_DIR / "base")
    forward_path = str(OUTPUT_DIR / "forward")

    # Determine which horizons need processing
    if args.force:
        missing = list(HORIZONS)
    else:
        missing = _missing_horizons(forward_path, date_iso, HORIZONS)

    if not missing:
        print(f"  skip {args.date} (complete)")
        return

    print(f"Processing {args.date}... ({len(missing)}/{len(HORIZONS)} horizons)")
    df_base, df_forward = process_date(args.date, horizons=missing)
    print(f"  {len(df_base)} fills, {len(df_base.columns)} base columns")
    print(f"  {len(df_forward)} forward rows ({len(missing)} horizons × {len(df_base)} trades)")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Base: idempotent overwrite for this date
    base_predicate = f"data_date = '{date_iso}'"
    _write_delta(df_base, base_path, ["data_date"], base_predicate)

    # Forward: per-horizon write (safe for incremental append)
    if len(df_forward) > 0:
        for h in missing:
            df_h = df_forward.filter(pl.col("horizon") == h)
            predicate = f"data_date = '{date_iso}' AND horizon = {h}"
            _write_delta(df_h, forward_path, ["data_date", "horizon"], predicate)

    print(f"  Saved to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()