"""
VizFlow Templates — Plan whiteboards and example scripts.

Usage (notebook — plan whiteboards):
    import vizflow as vf

    vf.templates.list()                          # see available plans
    vf.templates.show("daily_forward_stats")     # print notebook-ready code
    vf.templates.path("daily_forward_stats")     # Path to full template file

Usage (batch — copy full script):
    import vizflow.templates as templates

    templates.list_templates()                   # list .py files
    templates.copy_template("merge_forward_by_date.py", "my_enrich.py")
"""
from __future__ import annotations

import shutil
import textwrap
from pathlib import Path


TEMPLATES_DIR = Path(__file__).parent


# ═══════════════════════════════════════════════════════════════════
# PLAN WHITEBOARDS — notebook-ready code, copy-paste and modify
# ═══════════════════════════════════════════════════════════════════
_PLANS: dict[str, dict[str, str]] = {
    "daily_forward_stats": {
        "description": "enriched base+fwd → weighted agg (one row per horizon × group)",
        "file": "daily_forward_stats_by_date.py",
        "code": textwrap.dedent("""\
            import polars as pl

            # --- Config (edit these) ---
            base_path = "/path/to/enriched/base"         # Delta Lake table
            fwd_path  = "/path/to/enriched/forward"      # Delta Lake table
            date      = "20250112"
            date_iso  = f"{date[:4]}-{date[4:6]}-{date[6:8]}"

            horizons  = [1000, 5000, 10000, 30000, 60000]    # ms
            weights   = ["fill_notional"]
            values    = ["sided_markout", "sided_return",
                         "sided_fill_to_near_touch", "sided_fill_to_far_touch"]

            # --- Plan ---
            date_filter    = pl.col("data_date") == pl.lit(date_iso).str.to_date()
            horizon_filter = pl.col("horizon").is_in(horizons)

            lf_base = pl.scan_delta(base_path).filter(date_filter)
            lf_fwd  = pl.scan_delta(fwd_path).filter(date_filter).filter(horizon_filter)

            df = (
                lf_fwd.join(
                    lf_base
                    .filter(pl.col("fill_qty") > 0)
                    .filter(pl.col("create_exchange_ts") > 93100000)   # skip first 1min
                    .filter(pl.col("update_exchange_ts") < 143000000)  # skip last 30min
                    .filter(pl.col("order_price_type") != "UKWN")
                    .with_columns(fill_notional=pl.col("fill_price") * pl.col("fill_qty"))
                    .select("seq", "data_date", "fill_notional",
                            "order_price_type", "order_side"),
                    on=["seq", "data_date"],
                )
                .group_by(["horizon", "order_price_type", "order_side"])
                .agg(
                    [pl.col(w).sum().alias(f"sum_{w}") for w in weights]
                    + [
                        (pl.col(v) * pl.col(w)).sum().alias(f"sum_{w}_x_{v}")
                        for w in weights
                        for v in values
                    ]
                )
                .with_columns(data_date=pl.lit(date_iso).str.to_date())
                .collect()
            )
            df  # show result"""),
    },
    "execution_stats_1d": {
        "description": "1D bucketed stats: base × fwd_update → per-bucket agg with tod_bin (complete CLI script)",
        "file": "daily_forward_stats_by_date.py",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"1D bucketed execution stats (base × fwd_update).

            Computes weighted aggregations bucketed by one dimension at a time.
            All bucket definitions use base table columns only (no fwd_h0 join).
            \"\"\"
            from __future__ import annotations

            import argparse
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            # ═══════════════════════════════════════════════════════════════
            # CONFIG
            # ═══════════════════════════════════════════════════════════════
            BASE_DIR    = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            FORWARD_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/fwd_update")
            OUTPUT_DIR  = Path("/cpfs/user2/ylu/data/oic_live/execution_stats_1d")

            HORIZONS = [int(h * 1000) for h in [
                -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
            ]]
            GROUP_KEYS = ["horizon", "order_price_type", "order_side", "tod_bin"]
            WEIGHTS    = ["fill_notional"]
            VALUES     = ["sided_markout", "sided_return", "sided_fill_to_near_touch"]

            # --- Bucket dimensions (all source=base) ---
            is_buy = pl.col("order_side") == "Buy"
            near_at_order = pl.when(is_buy).then(pl.col("bid_size0_at_order")).otherwise(pl.col("ask_size0_at_order"))
            far_at_order  = pl.when(is_buy).then(pl.col("ask_size0_at_order")).otherwise(pl.col("bid_size0_at_order"))

            BUCKETS = {
                "tod_spread_improvement": {
                    "expr": (
                        (pl.col("half_spread_bps") * 2 - pl.col("tod_spread_bps"))
                        / (pl.col("half_spread_bps") * 2 + pl.col("tod_spread_bps"))
                    ),
                    "edges": [-1, -0.8, -0.5, -0.2, 0, 0.2, 0.5, 0.8, 1],
                },
                "near_touch_size_improvement": {
                    "expr": (near_at_order - pl.col("avg_touch_size")) / (near_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.2, 0, 0.2, 0.5],
                },
                "far_touch_size_improvement": {
                    "expr": (far_at_order - pl.col("avg_touch_size")) / (far_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.2, 0, 0.2, 0.5],
                },
                "sta_bps": {
                    "expr": pl.col("alp_st"),
                    "edges": [-20e-4, -10e-4, -5e-4, -2e-4, -1e-4, 0, 1e-4, 2e-4, 5e-4, 10e-4, 20e-4],
                },
                "lta_bps": {
                    "expr": pl.col("alp_lt"),
                    "edges": [-20e-4, -10e-4, -5e-4, -2e-4, -1e-4, 0, 1e-4, 2e-4, 5e-4, 10e-4, 20e-4],
                },
            }

            # ═══════════════════════════════════════════════════════════════
            # CORE
            # ═══════════════════════════════════════════════════════════════
            def compute(date: str) -> dict[str, pl.DataFrame]:
                date_iso = f"{date[:4]}-{date[4:6]}-{date[6:8]}"

                # 1. Read base (already has bid/ask_size0_at_order + avg_touch_size)
                lf_base = pl.scan_parquet(str(BASE_DIR / f"{date}.parquet"))

                # 2. Compute all bucket exprs
                lf_base = lf_base.with_columns([
                    spec["expr"].alias(bname) for bname, spec in BUCKETS.items()
                ])

                # 3. Filters + derived columns
                lf_base = (
                    lf_base
                    .filter(pl.col("create_exchange_ts") > 93100000)
                    .filter(pl.col("update_exchange_ts") < 143000000)
                    .filter(pl.col("order_price_type") != "UKWN")
                    .pipe(vf.add_tod, "create_exchange_ts")
                    .with_columns(
                        fill_notional=pl.col("fill_price") * pl.col("fill_qty"),
                        order_notional=pl.col("order_price") * pl.col("order_qty"),
                        tod_bin=pl.col("tod_create_exchange_ts").dt.truncate("5m"),
                    )
                )

                # 4. Read forward table
                lf_fwd = pl.scan_parquet(str(FORWARD_DIR / f"{date}.parquet")).filter(
                    pl.col("horizon").is_in(HORIZONS)
                )

                # 5. Per bucket: cut → join → group_by → agg
                results = {}
                for bname, spec in BUCKETS.items():
                    bucket_col = f"bucket_{bname}"
                    select_cols = [
                        "seq", "data_date", "fill_notional", "order_notional",
                        "event_type", "order_price_type", "order_side", "tod_bin", bucket_col,
                    ]

                    lf_bucketed = (
                        lf_base
                        .with_columns(pl.col(bname).cut(spec["edges"]).cast(pl.Utf8).alias(bucket_col))
                        .select(select_cols)
                    )

                    df = (
                        lf_fwd.join(lf_bucketed, on=["seq", "data_date"])
                        .group_by(GROUP_KEYS + [bucket_col])
                        .agg(
                            [pl.col(w).sum().alias(f"sum_{w}") for w in WEIGHTS]
                            + [
                                (pl.col(v) * pl.col(w)).sum().alias(f"sum_{w}_x_{v}")
                                for w in WEIGHTS for v in VALUES
                            ]
                            + [
                                pl.col("order_notional")
                                .filter(pl.col("event_type") == "ORDACK")
                                .sum().alias("sum_order_notional"),
                            ]
                        )
                        .with_columns(data_date=pl.lit(date_iso).str.to_date())
                        .collect()
                    )
                    results[bname] = df

                return results

            # ═══════════════════════════════════════════════════════════════
            # CLI
            # ═══════════════════════════════════════════════════════════════
            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                all_exist = all(
                    (OUTPUT_DIR / f"{b}_bucketing_stats" / f"{args.date}.parquet").exists()
                    for b in BUCKETS
                )
                if all_exist and not args.force:
                    print(f"  skip {args.date} (complete)")
                    return

                print(f"Processing {args.date}...")
                results = compute(args.date)

                for bname, df in results.items():
                    out_dir = OUTPUT_DIR / f"{bname}_bucketing_stats"
                    out_dir.mkdir(parents=True, exist_ok=True)
                    out_file = out_dir / f"{args.date}.parquet"
                    df.write_parquet(str(out_file))
                    print(f"  {bname}: {len(df)} rows -> {out_file}")

            if __name__ == "__main__":
                main()"""),
    },
    "execution_stats_2d": {
        "description": "2D bucketed stats: base × fwd_update → (bucket_a × bucket_b) agg, no tod_bin (complete CLI script)",
        "file": "daily_forward_stats_by_date.py",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"2D bucketed execution stats (base × fwd_update).

            Group by TWO bucket dimensions simultaneously.
            No tod_bin (controls data volume). Finer edges than 1D.
            \"\"\"
            from __future__ import annotations

            import argparse
            from itertools import combinations
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            # ═══════════════════════════════════════════════════════════════
            # CONFIG
            # ═══════════════════════════════════════════════════════════════
            BASE_DIR    = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            FORWARD_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/fwd_update")
            OUTPUT_DIR  = Path("/cpfs/user2/ylu/data/oic_live/execution_stats_2d")

            HORIZONS = [int(h * 1000) for h in [
                -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
            ]]
            GROUP_KEYS = ["horizon", "order_price_type", "order_side"]   # no tod_bin
            WEIGHTS    = ["fill_notional"]
            VALUES     = ["sided_markout", "sided_return", "sided_fill_to_near_touch"]

            # Finer edges for 2D analysis
            is_buy = pl.col("order_side") == "Buy"
            near_at_order = pl.when(is_buy).then(pl.col("bid_size0_at_order")).otherwise(pl.col("ask_size0_at_order"))
            far_at_order  = pl.when(is_buy).then(pl.col("ask_size0_at_order")).otherwise(pl.col("bid_size0_at_order"))

            BUCKETS = {
                "tod_spread_improvement": {
                    "expr": (
                        (pl.col("half_spread_bps") * 2 - pl.col("tod_spread_bps"))
                        / (pl.col("half_spread_bps") * 2 + pl.col("tod_spread_bps"))
                    ),
                    "edges": [-1, -0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8, 1],
                },
                "near_touch_size_improvement": {
                    "expr": (near_at_order - pl.col("avg_touch_size")) / (near_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.5],
                },
                "far_touch_size_improvement": {
                    "expr": (far_at_order - pl.col("avg_touch_size")) / (far_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.5],
                },
                "sta_bps": {
                    "expr": pl.col("alp_st"),
                    "edges": [-20e-4, -15e-4, -10e-4, -7e-4, -5e-4, -3e-4, -2e-4, -1e-4,
                              0, 1e-4, 2e-4, 3e-4, 5e-4, 7e-4, 10e-4, 15e-4, 20e-4],
                },
                "lta_bps": {
                    "expr": pl.col("alp_lt"),
                    "edges": [-20e-4, -15e-4, -10e-4, -7e-4, -5e-4, -3e-4, -2e-4, -1e-4,
                              0, 1e-4, 2e-4, 3e-4, 5e-4, 7e-4, 10e-4, 15e-4, 20e-4],
                },
            }

            # Which 2D pairs to compute (default: all pairs)
            PAIRS = list(combinations(BUCKETS.keys(), 2))

            # ═══════════════════════════════════════════════════════════════
            # CORE
            # ═══════════════════════════════════════════════════════════════
            def compute(date: str) -> dict[str, pl.DataFrame]:
                date_iso = f"{date[:4]}-{date[4:6]}-{date[6:8]}"

                lf_base = pl.scan_parquet(str(BASE_DIR / f"{date}.parquet"))

                # Compute all bucket exprs
                lf_base = lf_base.with_columns([
                    spec["expr"].alias(bname) for bname, spec in BUCKETS.items()
                ])

                # Filters + derived
                lf_base = (
                    lf_base
                    .filter(pl.col("create_exchange_ts") > 93100000)
                    .filter(pl.col("update_exchange_ts") < 143000000)
                    .filter(pl.col("order_price_type") != "UKWN")
                    .with_columns(
                        fill_notional=pl.col("fill_price") * pl.col("fill_qty"),
                        order_notional=pl.col("order_price") * pl.col("order_qty"),
                    )
                )

                lf_fwd = pl.scan_parquet(str(FORWARD_DIR / f"{date}.parquet")).filter(
                    pl.col("horizon").is_in(HORIZONS)
                )

                # Per pair: cut both → join → group_by → agg
                results = {}
                for bname_a, bname_b in PAIRS:
                    col_a = f"bucket_{bname_a}"
                    col_b = f"bucket_{bname_b}"

                    lf_bucketed = (
                        lf_base
                        .with_columns([
                            pl.col(bname_a).cut(BUCKETS[bname_a]["edges"]).cast(pl.Utf8).alias(col_a),
                            pl.col(bname_b).cut(BUCKETS[bname_b]["edges"]).cast(pl.Utf8).alias(col_b),
                        ])
                        .select([
                            "seq", "data_date", "fill_notional", "order_notional",
                            "event_type", "order_price_type", "order_side", col_a, col_b,
                        ])
                    )

                    df = (
                        lf_fwd.join(lf_bucketed, on=["seq", "data_date"])
                        .group_by(GROUP_KEYS + [col_a, col_b])
                        .agg(
                            [pl.col(w).sum().alias(f"sum_{w}") for w in WEIGHTS]
                            + [
                                (pl.col(v) * pl.col(w)).sum().alias(f"sum_{w}_x_{v}")
                                for w in WEIGHTS for v in VALUES
                            ]
                            + [
                                pl.col("order_notional")
                                .filter(pl.col("event_type") == "ORDACK")
                                .sum().alias("sum_order_notional"),
                            ]
                        )
                        .with_columns(data_date=pl.lit(date_iso).str.to_date())
                        .collect()
                    )
                    pair_name = f"{bname_a}_x_{bname_b}"
                    results[pair_name] = df

                return results

            # ═══════════════════════════════════════════════════════════════
            # CLI
            # ═══════════════════════════════════════════════════════════════
            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                print(f"Processing {args.date}... ({len(PAIRS)} pairs)")
                results = compute(args.date)

                for pair_name, df in results.items():
                    out_dir = OUTPUT_DIR / f"{pair_name}_2d_stats"
                    out_dir.mkdir(parents=True, exist_ok=True)
                    out_file = out_dir / f"{args.date}.parquet"
                    df.write_parquet(str(out_file))
                    print(f"  {pair_name}: {len(df)} rows -> {out_file}")

            if __name__ == "__main__":
                main()"""),
    },
    "sizing_stats_1d": {
        "description": "1D bucketed stats: base × fwd_create → signal/sizing analysis with tod_bin (complete CLI script)",
        "file": "daily_forward_stats_by_date.py",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"1D bucketed sizing stats (base × fwd_create).

            Same structure as execution_stats_1d but uses fwd_create (create_ts).
            Answers: "After order placement, how did the market move?"
            \"\"\"
            from __future__ import annotations

            import argparse
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            # ═══════════════════════════════════════════════════════════════
            # CONFIG — only FORWARD_DIR and OUTPUT_DIR differ from execution
            # ═══════════════════════════════════════════════════════════════
            BASE_DIR    = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            FORWARD_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/fwd_create")
            OUTPUT_DIR  = Path("/cpfs/user2/ylu/data/oic_live/sizing_stats_1d")

            HORIZONS = [int(h * 1000) for h in [
                -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
            ]]
            GROUP_KEYS = ["horizon", "order_price_type", "order_side", "tod_bin"]
            WEIGHTS    = ["fill_notional"]
            VALUES     = ["sided_markout", "sided_return", "sided_fill_to_near_touch"]

            is_buy = pl.col("order_side") == "Buy"
            near_at_order = pl.when(is_buy).then(pl.col("bid_size0_at_order")).otherwise(pl.col("ask_size0_at_order"))
            far_at_order  = pl.when(is_buy).then(pl.col("ask_size0_at_order")).otherwise(pl.col("bid_size0_at_order"))

            BUCKETS = {
                "tod_spread_improvement": {
                    "expr": (
                        (pl.col("half_spread_bps") * 2 - pl.col("tod_spread_bps"))
                        / (pl.col("half_spread_bps") * 2 + pl.col("tod_spread_bps"))
                    ),
                    "edges": [-1, -0.8, -0.5, -0.2, 0, 0.2, 0.5, 0.8, 1],
                },
                "near_touch_size_improvement": {
                    "expr": (near_at_order - pl.col("avg_touch_size")) / (near_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.2, 0, 0.2, 0.5],
                },
                "far_touch_size_improvement": {
                    "expr": (far_at_order - pl.col("avg_touch_size")) / (far_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.2, 0, 0.2, 0.5],
                },
                "sta_bps": {
                    "expr": pl.col("alp_st"),
                    "edges": [-20e-4, -10e-4, -5e-4, -2e-4, -1e-4, 0, 1e-4, 2e-4, 5e-4, 10e-4, 20e-4],
                },
                "lta_bps": {
                    "expr": pl.col("alp_lt"),
                    "edges": [-20e-4, -10e-4, -5e-4, -2e-4, -1e-4, 0, 1e-4, 2e-4, 5e-4, 10e-4, 20e-4],
                },
            }

            # ═══════════════════════════════════════════════════════════════
            # CORE (identical to execution_stats_1d)
            # ═══════════════════════════════════════════════════════════════
            def compute(date: str) -> dict[str, pl.DataFrame]:
                date_iso = f"{date[:4]}-{date[4:6]}-{date[6:8]}"

                lf_base = pl.scan_parquet(str(BASE_DIR / f"{date}.parquet"))
                lf_base = lf_base.with_columns([
                    spec["expr"].alias(bname) for bname, spec in BUCKETS.items()
                ])
                lf_base = (
                    lf_base
                    .filter(pl.col("create_exchange_ts") > 93100000)
                    .filter(pl.col("update_exchange_ts") < 143000000)
                    .filter(pl.col("order_price_type") != "UKWN")
                    .pipe(vf.add_tod, "create_exchange_ts")
                    .with_columns(
                        fill_notional=pl.col("fill_price") * pl.col("fill_qty"),
                        order_notional=pl.col("order_price") * pl.col("order_qty"),
                        tod_bin=pl.col("tod_create_exchange_ts").dt.truncate("5m"),
                    )
                )

                lf_fwd = pl.scan_parquet(str(FORWARD_DIR / f"{date}.parquet")).filter(
                    pl.col("horizon").is_in(HORIZONS)
                )

                results = {}
                for bname, spec in BUCKETS.items():
                    bucket_col = f"bucket_{bname}"
                    select_cols = [
                        "seq", "data_date", "fill_notional", "order_notional",
                        "event_type", "order_price_type", "order_side", "tod_bin", bucket_col,
                    ]
                    lf_bucketed = (
                        lf_base
                        .with_columns(pl.col(bname).cut(spec["edges"]).cast(pl.Utf8).alias(bucket_col))
                        .select(select_cols)
                    )
                    df = (
                        lf_fwd.join(lf_bucketed, on=["seq", "data_date"])
                        .group_by(GROUP_KEYS + [bucket_col])
                        .agg(
                            [pl.col(w).sum().alias(f"sum_{w}") for w in WEIGHTS]
                            + [
                                (pl.col(v) * pl.col(w)).sum().alias(f"sum_{w}_x_{v}")
                                for w in WEIGHTS for v in VALUES
                            ]
                            + [
                                pl.col("order_notional")
                                .filter(pl.col("event_type") == "ORDACK")
                                .sum().alias("sum_order_notional"),
                            ]
                        )
                        .with_columns(data_date=pl.lit(date_iso).str.to_date())
                        .collect()
                    )
                    results[bname] = df
                return results

            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                all_exist = all(
                    (OUTPUT_DIR / f"{b}_bucketing_stats" / f"{args.date}.parquet").exists()
                    for b in BUCKETS
                )
                if all_exist and not args.force:
                    print(f"  skip {args.date} (complete)")
                    return

                print(f"Processing {args.date}...")
                results = compute(args.date)
                for bname, df in results.items():
                    out_dir = OUTPUT_DIR / f"{bname}_bucketing_stats"
                    out_dir.mkdir(parents=True, exist_ok=True)
                    out_file = out_dir / f"{args.date}.parquet"
                    df.write_parquet(str(out_file))
                    print(f"  {bname}: {len(df)} rows -> {out_file}")

            if __name__ == "__main__":
                main()"""),
    },
    "sizing_stats_2d": {
        "description": "2D bucketed stats: base × fwd_create → signal/sizing 2D analysis (complete CLI script)",
        "file": "daily_forward_stats_by_date.py",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"2D bucketed sizing stats (base × fwd_create).

            Same structure as execution_stats_2d but uses fwd_create (create_ts).
            \"\"\"
            from __future__ import annotations

            import argparse
            from itertools import combinations
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            BASE_DIR    = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            FORWARD_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/fwd_create")
            OUTPUT_DIR  = Path("/cpfs/user2/ylu/data/oic_live/sizing_stats_2d")

            HORIZONS = [int(h * 1000) for h in [
                -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
            ]]
            GROUP_KEYS = ["horizon", "order_price_type", "order_side"]
            WEIGHTS    = ["fill_notional"]
            VALUES     = ["sided_markout", "sided_return", "sided_fill_to_near_touch"]

            is_buy = pl.col("order_side") == "Buy"
            near_at_order = pl.when(is_buy).then(pl.col("bid_size0_at_order")).otherwise(pl.col("ask_size0_at_order"))
            far_at_order  = pl.when(is_buy).then(pl.col("ask_size0_at_order")).otherwise(pl.col("bid_size0_at_order"))

            BUCKETS = {
                "tod_spread_improvement": {
                    "expr": (
                        (pl.col("half_spread_bps") * 2 - pl.col("tod_spread_bps"))
                        / (pl.col("half_spread_bps") * 2 + pl.col("tod_spread_bps"))
                    ),
                    "edges": [-1, -0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8, 1],
                },
                "near_touch_size_improvement": {
                    "expr": (near_at_order - pl.col("avg_touch_size")) / (near_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.5],
                },
                "far_touch_size_improvement": {
                    "expr": (far_at_order - pl.col("avg_touch_size")) / (far_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.5],
                },
                "sta_bps": {
                    "expr": pl.col("alp_st"),
                    "edges": [-20e-4, -15e-4, -10e-4, -7e-4, -5e-4, -3e-4, -2e-4, -1e-4,
                              0, 1e-4, 2e-4, 3e-4, 5e-4, 7e-4, 10e-4, 15e-4, 20e-4],
                },
                "lta_bps": {
                    "expr": pl.col("alp_lt"),
                    "edges": [-20e-4, -15e-4, -10e-4, -7e-4, -5e-4, -3e-4, -2e-4, -1e-4,
                              0, 1e-4, 2e-4, 3e-4, 5e-4, 7e-4, 10e-4, 15e-4, 20e-4],
                },
            }

            PAIRS = list(combinations(BUCKETS.keys(), 2))

            def compute(date: str) -> dict[str, pl.DataFrame]:
                date_iso = f"{date[:4]}-{date[4:6]}-{date[6:8]}"
                lf_base = pl.scan_parquet(str(BASE_DIR / f"{date}.parquet"))
                lf_base = lf_base.with_columns([
                    spec["expr"].alias(bname) for bname, spec in BUCKETS.items()
                ])
                lf_base = (
                    lf_base
                    .filter(pl.col("create_exchange_ts") > 93100000)
                    .filter(pl.col("update_exchange_ts") < 143000000)
                    .filter(pl.col("order_price_type") != "UKWN")
                    .with_columns(
                        fill_notional=pl.col("fill_price") * pl.col("fill_qty"),
                        order_notional=pl.col("order_price") * pl.col("order_qty"),
                    )
                )
                lf_fwd = pl.scan_parquet(str(FORWARD_DIR / f"{date}.parquet")).filter(
                    pl.col("horizon").is_in(HORIZONS)
                )

                results = {}
                for bname_a, bname_b in PAIRS:
                    col_a = f"bucket_{bname_a}"
                    col_b = f"bucket_{bname_b}"
                    lf_bucketed = (
                        lf_base
                        .with_columns([
                            pl.col(bname_a).cut(BUCKETS[bname_a]["edges"]).cast(pl.Utf8).alias(col_a),
                            pl.col(bname_b).cut(BUCKETS[bname_b]["edges"]).cast(pl.Utf8).alias(col_b),
                        ])
                        .select([
                            "seq", "data_date", "fill_notional", "order_notional",
                            "event_type", "order_price_type", "order_side", col_a, col_b,
                        ])
                    )
                    df = (
                        lf_fwd.join(lf_bucketed, on=["seq", "data_date"])
                        .group_by(GROUP_KEYS + [col_a, col_b])
                        .agg(
                            [pl.col(w).sum().alias(f"sum_{w}") for w in WEIGHTS]
                            + [
                                (pl.col(v) * pl.col(w)).sum().alias(f"sum_{w}_x_{v}")
                                for w in WEIGHTS for v in VALUES
                            ]
                            + [
                                pl.col("order_notional")
                                .filter(pl.col("event_type") == "ORDACK")
                                .sum().alias("sum_order_notional"),
                            ]
                        )
                        .with_columns(data_date=pl.lit(date_iso).str.to_date())
                        .collect()
                    )
                    results[f"{bname_a}_x_{bname_b}"] = df
                return results

            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                print(f"Processing {args.date}... ({len(PAIRS)} pairs)")
                results = compute(args.date)
                for pair_name, df in results.items():
                    out_dir = OUTPUT_DIR / f"{pair_name}_2d_stats"
                    out_dir.mkdir(parents=True, exist_ok=True)
                    out_file = out_dir / f"{args.date}.parquet"
                    df.write_parquet(str(out_file))
                    print(f"  {pair_name}: {len(df)} rows -> {out_file}")

            if __name__ == "__main__":
                main()"""),
    },
    "plot_bucketed_stats_1d": {
        "description": "1D bucketed stats → overview (2×2) + interday/TOD per value_col (notebook, seaborn)",
        "file": "daily_forward_stats_by_date.py",
        "code": textwrap.dedent("""\
            import datetime
            import polars as pl
            import matplotlib.pyplot as plt
            import matplotlib.dates as mdates
            import seaborn as sns
            from pathlib import Path
            from matplotlib.patches import Patch

            # --- Config ---
            OUTPUT_DIR = Path("/cpfs/user2/ylu/data/oic_live/")
            bucket_names = [
                "tod_spread_improvement",
                "near_touch_size_improvement",
                "far_touch_size_improvement",
                "sta_bps",
                "lta_bps",
            ]

            weight_col = "fill_notional"
            sum_w_col  = f"sum_{weight_col}"

            # Value columns + their horizon (ms) for interday/TOD figures
            VALUE_COLS = {
                "sided_markout": 60000,                # 60s
                "sided_fill_to_near_touch": 10000,     # 10s
            }
            CURVE_XLIM = (-10, 60)          # horizon (s) xlim for overview curves
            MIN_NOTIONAL_FRAC = 0.02        # drop buckets with < 2% of total fill notional

            ORDER_SIDES = ["Buy", "Sell"]   # always plot both sides
            ORDER_TYPES = ["JOIN"]          # add "LMT", "SQZ", "MKT" as needed

            # --- Read all bucket stats (only needed horizons) ---
            needed_horizons = (
                set(h * 1000 for h in range(CURVE_XLIM[0], CURVE_XLIM[1] + 1))
                | set(VALUE_COLS.values())
            )
            data = {}
            for bname in bucket_names:
                table_path = str(OUTPUT_DIR / f"{bname}_bucketing_stats")
                data[bname] = (
                    pl.scan_parquet(table_path + "/*.parquet")
                    .filter(pl.col("horizon").is_in(list(needed_horizons)))
                    .collect()
                )
                print(f"{bname}: {len(data[bname])} rows")


            # --- Helper: sort buckets by numeric left edge ---
            def _bucket_sort_key(label: str) -> float:
                \"\"\"Extract left edge from interval label like '(-0.8, -0.5]'.\"\"\"
                try:
                    left = label.split(",")[0].strip("([ ")
                    return float(left)
                except (ValueError, IndexError):
                    return float("inf")


            # --- Plot ---
            for bname in bucket_names:
                df = data[bname]
                bucket_col = f"bucket_{bname}"

                # Identify significant buckets (>= MIN_NOTIONAL_FRAC of total)
                df_h0_all = df.filter(pl.col("horizon") == 0).drop_nulls(bucket_col)
                total_notional = df_h0_all[sum_w_col].sum()
                keep_buckets = (
                    df_h0_all.group_by(bucket_col)
                    .agg(pl.col(sum_w_col).sum())
                    .filter(pl.col(sum_w_col) >= total_notional * MIN_NOTIONAL_FRAC)
                    [bucket_col].to_list()
                )

                # all_buckets = everything (for bar charts), curve_buckets = significant only
                all_buckets = sorted(
                    [b for b in df[bucket_col].unique().drop_nulls().to_list()],
                    key=_bucket_sort_key,
                )
                curve_buckets = sorted(
                    [b for b in keep_buckets if b is not None],
                    key=_bucket_sort_key,
                )
                n = len(all_buckets)
                if n == 0:
                    continue
                palette = dict(zip(all_buckets, sns.color_palette("coolwarm", n)))

                for opt in ORDER_TYPES:
                    for side in ORDER_SIDES:
                        df_sub = df.filter(
                            (pl.col("order_price_type") == opt)
                            & (pl.col("order_side") == side)
                        ).drop_nulls(bucket_col)
                        if len(df_sub) == 0:
                            continue

                        df_sub = df_sub.with_columns(
                            (pl.col("horizon") / 1000).alias("horizon_s")
                        )

                        # ═══════════════════════════════════════════════════
                        # Figure 1: Overview (2×2)
                        #   markout curve | fill-to-near-touch curve
                        #   fill notional | fill rate
                        # ═══════════════════════════════════════════════════
                        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
                        fig.suptitle(f"{bname} | {opt} | {side} — Overview",
                                     fontsize=14, fontweight="bold", y=0.98)

                        # (0,0) Sided Markout Curve — only significant buckets
                        ax = axes[0, 0]
                        sum_wv_col = f"sum_{weight_col}_x_sided_markout"
                        df_sig = df_sub.filter(pl.col(bucket_col).is_in(curve_buckets))
                        curve = (
                            df_sig.group_by(["horizon", "horizon_s", bucket_col])
                            .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_col).sum()])
                            .with_columns(bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4))
                            .to_pandas()
                        )
                        sns.lineplot(data=curve, x="horizon_s", y="bps", hue=bucket_col, palette=palette,
                                     hue_order=curve_buckets, ax=ax, marker="o", markersize=3, linewidth=1.2)
                        ax.set_title("Sided Markout (bps)")
                        ax.set_xlabel("horizon (s)"); ax.set_ylabel("bps")
                        ax.set_xlim(*CURVE_XLIM)
                        ax.axhline(0, color="grey", ls="--", lw=0.5)
                        ax.legend(fontsize=6, ncol=2, title=bname, title_fontsize=7)

                        # (0,1) Sided Fill-to-Near-Touch Curve — only significant buckets
                        ax = axes[0, 1]
                        sum_wv_touch = f"sum_{weight_col}_x_sided_fill_to_near_touch"
                        curve_t = (
                            df_sig.group_by(["horizon", "horizon_s", bucket_col])
                            .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_touch).sum()])
                            .with_columns(bps=(pl.col(sum_wv_touch) / pl.col(sum_w_col) * 1e4))
                            .to_pandas()
                        )
                        sns.lineplot(data=curve_t, x="horizon_s", y="bps", hue=bucket_col, palette=palette,
                                     hue_order=curve_buckets, ax=ax, marker="o", markersize=3, linewidth=1.2)
                        ax.set_title("Sided Fill-to-Near-Touch (bps)")
                        ax.set_xlabel("horizon (s)"); ax.set_ylabel("bps")
                        ax.set_xlim(*CURVE_XLIM)
                        ax.axhline(0, color="grey", ls="--", lw=0.5)
                        ax.legend(fontsize=6, ncol=2, title=bname, title_fontsize=7)

                        # (1,0) Fill Notional Distribution — aggregate across dates & tod_bin
                        ax = axes[1, 0]
                        dist = (
                            df_sub.filter(pl.col("horizon") == 0)
                            .group_by(bucket_col)
                            .agg([pl.col(sum_w_col).sum(), pl.col("sum_order_notional").sum()])
                        )
                        pdf_h0 = dist.to_pandas()
                        pdf_h0["_sort"] = pdf_h0[bucket_col].map(_bucket_sort_key)
                        pdf_h0 = pdf_h0.sort_values("_sort").drop(columns="_sort")
                        bar_colors = [palette.get(b, "grey") for b in pdf_h0[bucket_col]]
                        notional_vals = pdf_h0[sum_w_col].values
                        total = notional_vals.sum()
                        bars = ax.bar(range(len(pdf_h0)), notional_vals, color=bar_colors)
                        ax.set_xticks(range(len(pdf_h0)))
                        ax.set_xticklabels(pdf_h0[bucket_col].tolist(), rotation=45, ha="right", fontsize=7)
                        for bar, val in zip(bars, notional_vals):
                            pct = val / total * 100
                            ax.annotate(f"{pct:.1f}%", xy=(bar.get_x() + bar.get_width() / 2, bar.get_height()),
                                        ha="center", va="bottom", fontsize=8, color="#333")
                        ax.set_title("Fill Notional Distribution")
                        ax.set_ylabel("sum fill_notional")

                        # (1,1) Fill Rate Distribution — ylim 0-1, with percentage
                        ax = axes[1, 1]
                        fill_n = pdf_h0[sum_w_col].values
                        order_n = pdf_h0["sum_order_notional"].values
                        rates = [f / o if o > 0 else 0 for f, o in zip(fill_n, order_n)]
                        bars = ax.bar(range(len(pdf_h0)), rates, color=bar_colors)
                        ax.set_xticks(range(len(pdf_h0)))
                        ax.set_xticklabels(pdf_h0[bucket_col].tolist(), rotation=45, ha="right", fontsize=7)
                        ax.set_ylim(0, 1)
                        for bar, r in zip(bars, rates):
                            ax.annotate(f"{r:.1%}", xy=(bar.get_x() + bar.get_width() / 2, bar.get_height()),
                                        ha="center", va="bottom", fontsize=8, color="#333")
                        ax.set_title("Fill Rate")
                        ax.set_ylabel("fill_notional / order_notional")

                        plt.tight_layout()
                        plt.show()

                        # ═══════════════════════════════════════════════════
                        # Figure 2+: Interday + TOD per value_col
                        # ═══════════════════════════════════════════════════
                        for value_col, vcol_horizon in VALUE_COLS.items():
                            cumsum_h_s = vcol_horizon / 1000
                            sum_wv_col = f"sum_{weight_col}_x_{value_col}"

                            fig, (ax_inter, ax_tod) = plt.subplots(2, 1, figsize=(14, 8),
                                                                    height_ratios=[1, 1])
                            fig.suptitle(f"{bname} | {opt} | {side} — {value_col}",
                                         fontsize=14, fontweight="bold", y=0.98)

                            # Row 0: Interday Cumsum — significant buckets only
                            df_sig2 = df_sub.filter(pl.col(bucket_col).is_in(curve_buckets))
                            daily = (
                                df_sig2.filter(pl.col("horizon") == vcol_horizon)
                                .group_by(["data_date", bucket_col])
                                .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_col).sum()])
                                .sort("data_date")
                                .with_columns(
                                    daily_bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4),
                                )
                                .with_columns(
                                    cum_bps=pl.col("daily_bps").cum_sum().over(bucket_col),
                                )
                            )
                            pdf_daily = daily.to_pandas()
                            sns.lineplot(data=pdf_daily, x="data_date", y="cum_bps",
                                         hue=bucket_col, palette=palette, hue_order=curve_buckets,
                                         ax=ax_inter, linewidth=1.2)
                            ax_inter.axhline(0, color="red", ls="--", lw=0.8)
                            ax_inter.set(xlabel="date", ylabel=f"Cumulative {value_col} (bps)",
                                         title=f"Interday Cumsum — {value_col} @ horizon={cumsum_h_s:.0f}s")
                            ax_inter.legend(fontsize=6, ncol=4, title=bname, title_fontsize=7)

                            # Row 1: TOD — overlapping bars, significant buckets only
                            tod = (
                                df_sig2.filter(pl.col("horizon") == vcol_horizon)
                                .group_by(["tod_bin", bucket_col])
                                .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_col).sum()])
                                .with_columns(bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4))
                                .sort("tod_bin")
                            )
                            pdf_tod = tod.to_pandas()
                            bar_width = datetime.timedelta(minutes=5)

                            # Draw bars: tallest (abs) first → shortest last (foreground)
                            for bucket in sorted(curve_buckets, key=lambda b: abs(pdf_tod.loc[pdf_tod[bucket_col] == b, "bps"].mean() or 0), reverse=True):
                                bdf = pdf_tod[pdf_tod[bucket_col] == bucket].sort_values("tod_bin")
                                if len(bdf) == 0:
                                    continue
                                ax_tod.bar(bdf["tod_bin"], bdf["bps"],
                                           width=bar_width, align="edge", color=palette[bucket], alpha=0.7)

                            ax_tod.axhline(0, color="grey", ls="--", lw=0.5)
                            ax_tod.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
                            ax_tod.legend(handles=[Patch(facecolor=palette[b], alpha=0.7, label=b) for b in curve_buckets],
                                          fontsize=6, ncol=4, title=bname, title_fontsize=7)
                            ax_tod.set(xlabel="time of day", ylabel=f"{value_col} (bps)",
                                       title=f"TOD — {value_col} @ horizon={cumsum_h_s:.0f}s (multi-day avg)")

                            plt.tight_layout()
                            plt.show()"""),
    },
    "plot_bucketed_stats_2d": {
        "description": "2D bucketed stats → heatmap (notional/markout/fill_rate) + marginalized 1D curves (notebook)",
        "file": "daily_forward_stats_by_date.py",
        "code": textwrap.dedent("""\
            import polars as pl
            import matplotlib.pyplot as plt
            import matplotlib.colors as mcolors
            import numpy as np
            from pathlib import Path

            # --- Config ---
            STATS_DIR = Path("/cpfs/user2/ylu/data/oic_live/execution_stats_2d")
            # Which pair to plot (edit these)
            PAIR = "sta_bps_x_near_touch_size_improvement"
            BUCKET_A = "bucket_sta_bps"
            BUCKET_B = "bucket_near_touch_size_improvement"

            weight_col = "fill_notional"
            sum_w_col  = f"sum_{weight_col}"

            VALUE_COLS = {
                "sided_markout": 60000,
                "sided_fill_to_near_touch": 10000,
            }
            MIN_NOTIONAL = 1e6   # mask cells with less than this

            ORDER_SIDES = ["Buy", "Sell"]
            ORDER_TYPES = ["JOIN"]

            # --- Helper: sort buckets by numeric left edge ---
            def _bucket_sort_key(label: str) -> float:
                try:
                    return float(label.split(",")[0].strip("([ "))
                except (ValueError, IndexError):
                    return float("inf")

            # --- Read ---
            table_path = str(STATS_DIR / f"{PAIR}_2d_stats")
            df = pl.scan_parquet(table_path + "/*.parquet").collect()
            print(f"Read {len(df)} rows")

            # --- Sort bucket labels ---
            bins_a = sorted([b for b in df[BUCKET_A].unique().drop_nulls().to_list()], key=_bucket_sort_key)
            bins_b = sorted([b for b in df[BUCKET_B].unique().drop_nulls().to_list()], key=_bucket_sort_key)

            # --- Plot ---
            for opt in ORDER_TYPES:
                for side in ORDER_SIDES:
                    df_sub = df.filter(
                        (pl.col("order_price_type") == opt)
                        & (pl.col("order_side") == side)
                    ).drop_nulls([BUCKET_A, BUCKET_B])
                    if len(df_sub) == 0:
                        continue

                    for value_col, vcol_horizon in VALUE_COLS.items():
                        sum_wv_col = f"sum_{weight_col}_x_{value_col}"
                        h_s = vcol_horizon / 1000

                        # Aggregate across dates for fixed horizon
                        agg = (
                            df_sub.filter(pl.col("horizon") == vcol_horizon)
                            .group_by([BUCKET_A, BUCKET_B])
                            .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_col).sum(),
                                  pl.col("sum_order_notional").sum()])
                            .with_columns(
                                bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4),
                                fill_rate=pl.col(sum_w_col) / pl.col("sum_order_notional"),
                            )
                        ).to_pandas()

                        # Pivot to 2D arrays
                        na = len(bins_a)
                        nb = len(bins_b)
                        notional_2d = np.full((nb, na), np.nan)
                        markout_2d  = np.full((nb, na), np.nan)
                        fillrate_2d = np.full((nb, na), np.nan)

                        for _, row in agg.iterrows():
                            ia = bins_a.index(row[BUCKET_A]) if row[BUCKET_A] in bins_a else -1
                            ib = bins_b.index(row[BUCKET_B]) if row[BUCKET_B] in bins_b else -1
                            if ia >= 0 and ib >= 0:
                                notional_2d[ib, ia] = row[sum_w_col]
                                markout_2d[ib, ia]  = row["bps"]
                                fillrate_2d[ib, ia] = row["fill_rate"]

                        # Mask low notional
                        mask = notional_2d < MIN_NOTIONAL
                        markout_masked  = np.ma.array(markout_2d, mask=mask)
                        fillrate_masked = np.ma.array(fillrate_2d, mask=mask)

                        # === Figure: 3 heatmaps + 2 marginalized curves ===
                        fig, axes = plt.subplots(2, 3, figsize=(18, 10))
                        fig.suptitle(f"{PAIR} | {opt} | {side} — {value_col} @ h={h_s:.0f}s",
                                     fontsize=14, fontweight="bold")

                        # Row 0: Heatmaps
                        # Notional (log scale)
                        ax = axes[0, 0]
                        im = ax.pcolormesh(np.arange(na+1), np.arange(nb+1),
                                           np.log10(np.where(notional_2d > 0, notional_2d, np.nan)),
                                           cmap="Blues")
                        fig.colorbar(im, ax=ax, label="log10(fill_notional)")
                        ax.set_xticks(np.arange(na) + 0.5); ax.set_xticklabels(bins_a, rotation=45, ha="right", fontsize=6)
                        ax.set_yticks(np.arange(nb) + 0.5); ax.set_yticklabels(bins_b, fontsize=6)
                        ax.set_xlabel(BUCKET_A.replace("bucket_", "")); ax.set_ylabel(BUCKET_B.replace("bucket_", ""))
                        ax.set_title("Fill Notional (log)")

                        # Markout (diverging, center=0)
                        ax = axes[0, 1]
                        vmax = np.nanmax(np.abs(markout_masked))
                        im = ax.pcolormesh(np.arange(na+1), np.arange(nb+1), markout_masked,
                                           cmap="RdBu_r", vmin=-vmax, vmax=vmax)
                        fig.colorbar(im, ax=ax, label="bps")
                        ax.set_xticks(np.arange(na) + 0.5); ax.set_xticklabels(bins_a, rotation=45, ha="right", fontsize=6)
                        ax.set_yticks(np.arange(nb) + 0.5); ax.set_yticklabels(bins_b, fontsize=6)
                        ax.set_title(f"{value_col} (bps)")

                        # Fill rate
                        ax = axes[0, 2]
                        im = ax.pcolormesh(np.arange(na+1), np.arange(nb+1), fillrate_masked,
                                           cmap="YlOrRd", vmin=0, vmax=1)
                        fig.colorbar(im, ax=ax, label="fill rate")
                        ax.set_xticks(np.arange(na) + 0.5); ax.set_xticklabels(bins_a, rotation=45, ha="right", fontsize=6)
                        ax.set_yticks(np.arange(nb) + 0.5); ax.set_yticklabels(bins_b, fontsize=6)
                        ax.set_title("Fill Rate")

                        # Row 1: Marginalized 1D curves
                        # Marginalize over bucket_b → curve per bucket_a
                        ax = axes[1, 0]
                        margin_a = (
                            df_sub.group_by(["horizon", BUCKET_A])
                            .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_col).sum()])
                            .with_columns(
                                bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4),
                                horizon_s=(pl.col("horizon") / 1000),
                            ).to_pandas()
                        )
                        for b in bins_a:
                            bdf = margin_a[margin_a[BUCKET_A] == b].sort_values("horizon_s")
                            ax.plot(bdf["horizon_s"], bdf["bps"], label=b, linewidth=1)
                        ax.axhline(0, color="grey", ls="--", lw=0.5)
                        ax.set_xlim(-10, 60)
                        ax.set_xlabel("horizon (s)"); ax.set_ylabel("bps")
                        ax.set_title(f"Marginalized over {BUCKET_B.replace('bucket_', '')}")
                        ax.legend(fontsize=5, ncol=2)

                        # Marginalize over bucket_a → curve per bucket_b
                        ax = axes[1, 1]
                        margin_b = (
                            df_sub.group_by(["horizon", BUCKET_B])
                            .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_col).sum()])
                            .with_columns(
                                bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4),
                                horizon_s=(pl.col("horizon") / 1000),
                            ).to_pandas()
                        )
                        for b in bins_b:
                            bdf = margin_b[margin_b[BUCKET_B] == b].sort_values("horizon_s")
                            ax.plot(bdf["horizon_s"], bdf["bps"], label=b, linewidth=1)
                        ax.axhline(0, color="grey", ls="--", lw=0.5)
                        ax.set_xlim(-10, 60)
                        ax.set_xlabel("horizon (s)"); ax.set_ylabel("bps")
                        ax.set_title(f"Marginalized over {BUCKET_A.replace('bucket_', '')}")
                        ax.legend(fontsize=5, ncol=2)

                        # Hide unused subplot
                        axes[1, 2].axis("off")

                        plt.tight_layout()
                        plt.show()"""),
    },
    "plot_interday_cumsum": {
        "description": "daily stats → interday cumulative weighted-mean curve per horizon (notebook, seaborn)",
        "file": "daily_forward_stats_by_date.py",
        "code": textwrap.dedent("""\
            import polars as pl
            import matplotlib.pyplot as plt
            import seaborn as sns

            # --- Config ---
            # Path to daily_forward_stats (unbucketed) or {bname}_bucketing_stats (bucketed)
            stats_path = "/cpfs/user2/ylu/data/oic_live/merge_forward/daily_forward_stats"

            # Which value column to plot — pick ONE:
            #   "sided_markout", "sided_return", "sided_fill_to_near_touch"
            value_col = "sided_markout"

            # Weight column (matches WEIGHTS in compute script)
            weight_col = "fill_notional"

            # The aggregated column names follow the convention:
            #   sum_{weight}              → e.g. "sum_fill_notional"
            #   sum_{weight}_x_{value}    → e.g. "sum_fill_notional_x_sided_markout"
            sum_w_col  = f"sum_{weight_col}"
            sum_wv_col = f"sum_{weight_col}_x_{value_col}"

            # Filter (set to None to plot all)
            SIDE = "Buy"           # "Buy" | "Sell" | None
            TYPE = "JOIN"          # "LMT" | "JOIN" | None

            # Optional: for bucketed stats, set bucket_col and bucket_value
            # bucket_col   = "bucket_sta_bps"
            # bucket_value = "(-2, -1]"


            # --- Read ---
            daily = pl.scan_parquet(stats_path + "/*.parquet").collect()
            print(f"Read {len(daily)} rows, columns: {daily.columns}")

            # --- Filter ---
            mask = pl.lit(True)
            if SIDE is not None:
                mask = mask & (pl.col("order_side") == SIDE)
            if TYPE is not None:
                mask = mask & (pl.col("order_price_type") == TYPE)
            # Uncomment for bucketed:
            # mask = mask & (pl.col(bucket_col) == bucket_value)
            daily = daily.filter(mask)


            # --- Compute daily weighted mean (bps) + interday cumsum ---
            daily = (
                daily
                .with_columns(
                    daily_weighted_mean_bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4),
                    horizon_s=(pl.col("horizon") / 1000),
                )
                .sort("data_date")
                .with_columns(
                    cum_weighted_mean_bps=pl.col("daily_weighted_mean_bps")
                        .cum_sum()
                        .over("horizon"),
                )
            )


            # --- Plot ---
            pdf = daily.to_pandas()
            horizons_sorted = sorted(pdf["horizon_s"].unique())
            n = len(horizons_sorted)
            palette = dict(zip(horizons_sorted, sns.color_palette("coolwarm", n)))

            fig, ax = plt.subplots(figsize=(14, 6))
            sns.lineplot(
                data=pdf, x="data_date", y="cum_weighted_mean_bps",
                hue="horizon_s", palette=palette, hue_order=horizons_sorted,
                ax=ax, linewidth=1.0,
            )
            ax.axhline(0, color="red", ls="--", lw=0.8)
            ax.set(
                xlabel="date",
                ylabel=f"Cumulative {value_col} (bps)",
                title=f"Interday Cumsum: {SIDE} {TYPE} — {value_col}",
            )
            ax.legend(fontsize=6, ncol=4, title="horizon (s)", title_fontsize=7)
            plt.tight_layout()
            plt.show()"""),
    },
    "merge_forward": {
        "description": "trade + quote → forward enrichment (base + forward tables)",
        "file": "merge_forward_by_date.py",
        "code": textwrap.dedent("""\
            import polars as pl
            import vizflow as vf

            # --- Config (edit these) ---
            date = "20240827"

            vf.set_config(vf.Config(
                trade_dir="/path/to/trades",
                trade_pattern="{date}.parquet",
                trade_schema="oic_live",
                quote_dir="/path/to/quotes",
                quote_pattern="{date}.feather",
                quote_schema="stock_sorted_t5ob",
                market="CN",
            ))

            trade_time_col  = "update_exchange_ts"
            create_time_col = "create_exchange_ts"
            quote_time_col  = "ticktime"
            ref_cols   = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]
            horizons   = [int(h * 1000) for h in [-10, -5, -1, 0, 1, 5, 10, 30, 60,
                                                   120, 180, 300, 600, 1200, 1800, 3600]]

            # --- Plan ---
            elapsed_trade = f"elapsed_{trade_time_col}"
            elapsed_quote = f"elapsed_{quote_time_col}"

            lf_trade = (
                vf.scan_trade(date)
                .pipe(vf.parse_time, trade_time_col)
                .pipe(vf.parse_time, create_time_col)
                .sort(["ukey", elapsed_trade])
                .with_columns(
                    pl.col("fill_qty").cum_sum()
                      .over(["data_date", "ukey", "order_id"]).alias("cum_fill_qty"),
                )
                .with_columns(
                    (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
                    (pl.col(elapsed_trade) - pl.col(f"elapsed_{create_time_col}")).alias("duration"),
                )
            )

            lf_quote = (
                vf.scan_quote(date, columns=["ukey", quote_time_col] + ref_cols)
                .pipe(vf.parse_time, quote_time_col)
            )

            df_merged = vf.merge_forward(
                lf_trade, lf_quote,
                ref_cols=ref_cols,
                horizons=horizons,
                trade_time_col=elapsed_trade,
                ref_time_col=elapsed_quote,
            )
            df_merged  # show result"""),
    },
    "enrich_alpha": {
        "description": "alpha + quote → forward enrichment (wide format)",
        "file": "enrich_alpha_by_date.py",
        "code": textwrap.dedent("""\
            import polars as pl
            import vizflow as vf
            from datetime import timedelta

            # --- Config (edit these) ---
            date = "20240827"

            vf.set_config(vf.Config(
                alpha_dir="/path/to/alpha",
                alpha_pattern="alpha_{date}.feather",
                alpha_schema="jyao_v20251114",
                quote_dir="/path/to/quotes",
                quote_pattern="{date}.fst",
                quote_schema="stock_sorted_t5ob",
                market="CN",
            ))

            alpha_time_col = "ticktime"
            quote_time_col = "ticktime"
            ref_cols   = ["bid_px0", "ask_px0"]
            pred_cols  = ["x_10s", "x_60s", "x_3m", "x_30m"]
            horizons   = [timedelta(seconds=h) for h in [0, 10, 30, 60, 120, 180, 300]]
            event_cols = ["ukey", "data_date", alpha_time_col] + pred_cols

            # --- Plan ---
            elapsed_alpha = f"elapsed_{alpha_time_col}"
            elapsed_quote = f"elapsed_{quote_time_col}"

            lf_alpha = (
                vf.scan_alpha(date)
                .pipe(vf.parse_time, alpha_time_col)
                .select(event_cols + [elapsed_alpha])
            )
            lf_quote = (
                vf.scan_quote(date, columns=["ukey", quote_time_col] + ref_cols)
                .pipe(vf.parse_time, quote_time_col)
            )

            # Per-horizon merge → wide format
            partials = []
            for h in horizons:
                lf_h = vf.merge_forward(
                    lf_alpha, lf_quote,
                    ref_cols=ref_cols,
                    horizon=h,
                    trade_time_col=elapsed_alpha,
                    ref_time_col=elapsed_quote,
                )
                partials.append(lf_h)

            df = partials[0].collect()
            for lf_h in partials[1:]:
                df_h = lf_h.collect()
                new_cols = [c for c in df_h.columns if c not in df.columns]
                if new_cols:
                    df = df.hstack(df_h.select(new_cols))
            df  # show result"""),
    },
    "base_enrichment": {
        "description": "trade + quote(create_ts h=0) + univ → base table with book_at_order (complete CLI script)",
        "file": "base_enrichment_by_date.py",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"Base table enrichment: trade events + order book at create_ts + univ.\"\"\"
            from __future__ import annotations

            import argparse
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            # ═══════════════════════════════════════════════════════════════
            # CONFIG
            # ═══════════════════════════════════════════════════════════════
            TRADE_DIR = Path("/cpfs/user2/ylu/data/oic_live/concat_sort")
            TRADE_PATTERN = "{date}.parquet"
            TRADE_SCHEMA = "oic_live"

            QUOTE_DIR = Path("/gpfs/nvmefs/marketdata/cn/stock/all/tob5")
            QUOTE_PATTERN = "{date}.feather"
            QUOTE_SCHEMA = "stock_sorted_t5ob"

            UNIV_DIR = Path("/cpfs/shared/public/ylu/univ")
            OUTPUT_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched")
            MARKET = "CN"

            TRADE_TIME_COL = "update_exchange_ts"
            CREATE_TIME_COL = "create_exchange_ts"
            QUOTE_TIME_COL = "ticktime"
            BOOK_REF_COLS = ["bid_size0", "ask_size0"]


            # ═══════════════════════════════════════════════════════════════
            # CORE
            # ═══════════════════════════════════════════════════════════════
            def process_date(date: str) -> pl.DataFrame:
                elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
                elapsed_create = f"elapsed_{CREATE_TIME_COL}"
                elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"

                lf_trade = (
                    vf.scan_trade(date)
                    .pipe(vf.parse_time, TRADE_TIME_COL)
                    .pipe(vf.parse_time, CREATE_TIME_COL)
                    .sort(["ukey", elapsed_trade])
                    .with_columns(
                        pl.col("fill_qty").cum_sum()
                        .over(["data_date", "ukey", "order_id"]).alias("cum_fill_qty"),
                    )
                    .with_columns(
                        (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
                        (pl.col(elapsed_trade) - pl.col(elapsed_create)).alias("duration"),
                    )
                )

                lf_quote = (
                    vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + BOOK_REF_COLS)
                    .pipe(vf.parse_time, QUOTE_TIME_COL)
                )

                # Book at order time: backward asof on create_ts, h=0
                df_base = vf.merge_forward(
                    lf_trade, lf_quote,
                    ref_cols=BOOK_REF_COLS,
                    horizons=[0],
                    trade_time_col=elapsed_create,
                    ref_time_col=elapsed_quote,
                    strategy="backward",
                )
                df_base = df_base.rename({
                    f"{col}_0s": f"{col}_at_order" for col in BOOK_REF_COLS
                })

                # Join univ
                univ_path = UNIV_DIR / f"{date}.csv"
                if univ_path.exists():
                    df_univ = pl.read_csv(str(univ_path)).select(
                        "ukey", pl.col("avg_touch_size_mean").alias("avg_touch_size"),
                    )
                    df_base = df_base.join(df_univ, on="ukey", how="left")

                return df_base


            # ═══════════════════════════════════════════════════════════════
            # CLI
            # ═══════════════════════════════════════════════════════════════
            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                vf.set_config(vf.Config(
                    trade_dir=TRADE_DIR, trade_pattern=TRADE_PATTERN, trade_schema=TRADE_SCHEMA,
                    quote_dir=QUOTE_DIR, quote_pattern=QUOTE_PATTERN, quote_schema=QUOTE_SCHEMA,
                    market=MARKET,
                ))

                out_dir = OUTPUT_DIR / "base"
                out_file = out_dir / f"{args.date}.parquet"
                if out_file.exists() and not args.force:
                    print(f"  skip {args.date} (exists)")
                    return

                print(f"Processing {args.date}...")
                df = process_date(args.date)
                out_dir.mkdir(parents=True, exist_ok=True)
                df.write_parquet(str(out_file))
                print(f"  {len(df)} events -> {out_file}")


            if __name__ == "__main__":
                main()"""),
    },
    "forward_on_update": {
        "description": "trade + quote → forward table on update_ts (execution quality, complete CLI script)",
        "file": "forward_on_update_by_date.py",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"Forward enrichment on update_ts: quote snapshots at each horizon after fill.\"\"\"
            from __future__ import annotations

            import argparse
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            # ═══════════════════════════════════════════════════════════════
            # CONFIG
            # ═══════════════════════════════════════════════════════════════
            TRADE_DIR = Path("/cpfs/user2/ylu/data/oic_live/concat_sort")
            TRADE_PATTERN = "{date}.parquet"
            TRADE_SCHEMA = "oic_live"

            QUOTE_DIR = Path("/gpfs/nvmefs/marketdata/cn/stock/all/tob5")
            QUOTE_PATTERN = "{date}.feather"
            QUOTE_SCHEMA = "stock_sorted_t5ob"

            OUTPUT_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched")
            MARKET = "CN"

            TRADE_TIME_COL = "update_exchange_ts"
            CREATE_TIME_COL = "create_exchange_ts"
            QUOTE_TIME_COL = "ticktime"

            HORIZONS = [int(h * 1000) for h in [
                -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
            ]]
            RAW_REF_COLS = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]

            # ═══════════════════════════════════════════════════════════════
            # FORWARD MERGE + DERIVED
            # ═══════════════════════════════════════════════════════════════
            def process_date(date: str) -> pl.DataFrame:
                elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
                elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"

                lf_trade = (
                    vf.scan_trade(date)
                    .pipe(vf.parse_time, TRADE_TIME_COL)
                    .pipe(vf.parse_time, CREATE_TIME_COL)
                    .sort(["ukey", elapsed_trade])
                    .with_columns(
                        pl.col("fill_qty").cum_sum()
                        .over(["data_date", "ukey", "order_id"]).alias("cum_fill_qty"),
                    )
                    .with_columns(
                        (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
                    )
                )
                lf_quote = (
                    vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + RAW_REF_COLS)
                    .pipe(vf.parse_time, QUOTE_TIME_COL)
                )

                df_merged = vf.merge_forward(
                    lf_trade, lf_quote,
                    ref_cols=RAW_REF_COLS,
                    horizons=HORIZONS,
                    trade_time_col=elapsed_trade,
                    ref_time_col=elapsed_quote,
                    strategy="backward",
                )

                # Wide → semi-wide
                id_cols = ["seq", "data_date"]
                frames = []
                for h in HORIZONS:
                    suffix = vf.horizon_suffix(h)
                    rename_map = {f"{rc}_{suffix}": rc for rc in RAW_REF_COLS}
                    frames.append(
                        df_merged.select(id_cols + list(rename_map.keys()))
                        .rename(rename_map)
                        .with_columns(pl.lit(h, dtype=pl.Int64).alias("horizon"))
                    )
                df_fwd = pl.concat(frames)

                # Derived columns
                df_fwd = df_fwd.join(
                    df_merged.select(["seq", "data_date", "fill_price", "order_side"]),
                    on=["seq", "data_date"],
                )
                is_buy = pl.col("order_side") == "Buy"

                df_fwd = df_fwd.with_columns([
                    pl.mean_horizontal("bid_px0", "ask_px0").alias("mid"),
                    (pl.col("ask_px0") - pl.col("bid_px0")).alias("spread"),
                    pl.when(is_buy).then(pl.col("bid_px0")).otherwise(pl.col("ask_px0")).alias("near_touch_px"),
                    pl.when(is_buy).then(pl.col("ask_px0")).otherwise(pl.col("bid_px0")).alias("far_touch_px"),
                    pl.when(is_buy).then(pl.col("bid_size0")).otherwise(pl.col("ask_size0")).alias("near_touch_size"),
                    pl.when(is_buy).then(pl.col("ask_size0")).otherwise(pl.col("bid_size0")).alias("far_touch_size"),
                ])
                df_fwd = df_fwd.with_columns((pl.col("spread") / pl.col("mid") * 10000).alias("spread_bps"))

                df_fwd = df_fwd.with_columns([
                    (pl.col("mid") / pl.col("fill_price") - 1).alias("markout"),
                    (pl.col("near_touch_px") / pl.col("fill_price") - 1).alias("fill_to_near_touch"),
                    (pl.col("far_touch_px") / pl.col("fill_price") - 1).alias("fill_to_far_touch"),
                ])

                mid_0 = df_fwd.filter(pl.col("horizon") == 0).select(["seq", "data_date", pl.col("mid").alias("mid_0")])
                df_fwd = df_fwd.join(mid_0, on=["seq", "data_date"])
                df_fwd = df_fwd.with_columns(((pl.col("mid") - pl.col("mid_0")) / pl.col("mid_0")).alias("return")).drop("mid_0")

                sided_cols = ["return", "markout", "fill_to_near_touch", "fill_to_far_touch"]
                df_fwd = df_fwd.with_columns([
                    pl.when(pl.col("order_side") == "Sell").then(-pl.col(c)).otherwise(pl.col(c)).alias(f"sided_{c}")
                    for c in sided_cols
                ])
                return df_fwd.drop(["fill_price", "order_side"])

            # ═══════════════════════════════════════════════════════════════
            # CLI
            # ═══════════════════════════════════════════════════════════════
            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                vf.set_config(vf.Config(
                    trade_dir=TRADE_DIR, trade_pattern=TRADE_PATTERN, trade_schema=TRADE_SCHEMA,
                    quote_dir=QUOTE_DIR, quote_pattern=QUOTE_PATTERN, quote_schema=QUOTE_SCHEMA,
                    market=MARKET,
                ))

                out_dir = OUTPUT_DIR / "fwd_update"
                out_file = out_dir / f"{args.date}.parquet"
                if out_file.exists() and not args.force:
                    print(f"  skip {args.date} (exists)")
                    return

                print(f"Processing {args.date}...")
                df = process_date(args.date)
                out_dir.mkdir(parents=True, exist_ok=True)
                df.write_parquet(str(out_file))
                print(f"  {len(df)} rows -> {out_file}")

            if __name__ == "__main__":
                main()"""),
    },
    "forward_on_create": {
        "description": "trade + quote → forward table on create_ts (signal/sizing analysis, complete CLI script)",
        "file": "forward_on_create_by_date.py",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"Forward enrichment on create_ts: quote snapshots at each horizon after order placement.\"\"\"
            from __future__ import annotations

            import argparse
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            # ═══════════════════════════════════════════════════════════════
            # CONFIG
            # ═══════════════════════════════════════════════════════════════
            TRADE_DIR = Path("/cpfs/user2/ylu/data/oic_live/concat_sort")
            TRADE_PATTERN = "{date}.parquet"
            TRADE_SCHEMA = "oic_live"

            QUOTE_DIR = Path("/gpfs/nvmefs/marketdata/cn/stock/all/tob5")
            QUOTE_PATTERN = "{date}.feather"
            QUOTE_SCHEMA = "stock_sorted_t5ob"

            OUTPUT_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched")
            MARKET = "CN"

            TRADE_TIME_COL = "update_exchange_ts"
            CREATE_TIME_COL = "create_exchange_ts"
            QUOTE_TIME_COL = "ticktime"

            HORIZONS = [int(h * 1000) for h in [
                -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
            ]]
            RAW_REF_COLS = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]

            # ═══════════════════════════════════════════════════════════════
            # FORWARD MERGE + DERIVED
            # ═══════════════════════════════════════════════════════════════
            def process_date(date: str) -> pl.DataFrame:
                elapsed_create = f"elapsed_{CREATE_TIME_COL}"
                elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
                elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"

                lf_trade = (
                    vf.scan_trade(date)
                    .pipe(vf.parse_time, TRADE_TIME_COL)
                    .pipe(vf.parse_time, CREATE_TIME_COL)
                    .sort(["ukey", elapsed_trade])
                    .with_columns(
                        pl.col("fill_qty").cum_sum()
                        .over(["data_date", "ukey", "order_id"]).alias("cum_fill_qty"),
                    )
                    .with_columns(
                        (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
                    )
                )
                lf_quote = (
                    vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + RAW_REF_COLS)
                    .pipe(vf.parse_time, QUOTE_TIME_COL)
                )

                df_merged = vf.merge_forward(
                    lf_trade, lf_quote,
                    ref_cols=RAW_REF_COLS,
                    horizons=HORIZONS,
                    trade_time_col=elapsed_create,     # ← create_ts
                    ref_time_col=elapsed_quote,
                    strategy="backward",
                )

                # Wide → semi-wide
                id_cols = ["seq", "data_date"]
                frames = []
                for h in HORIZONS:
                    suffix = vf.horizon_suffix(h)
                    rename_map = {f"{rc}_{suffix}": rc for rc in RAW_REF_COLS}
                    frames.append(
                        df_merged.select(id_cols + list(rename_map.keys()))
                        .rename(rename_map)
                        .with_columns(pl.lit(h, dtype=pl.Int64).alias("horizon"))
                    )
                df_fwd = pl.concat(frames)

                # Derived columns (same pipeline as forward_on_update)
                df_fwd = df_fwd.join(
                    df_merged.select(["seq", "data_date", "fill_price", "order_side"]),
                    on=["seq", "data_date"],
                )
                is_buy = pl.col("order_side") == "Buy"

                df_fwd = df_fwd.with_columns([
                    pl.mean_horizontal("bid_px0", "ask_px0").alias("mid"),
                    (pl.col("ask_px0") - pl.col("bid_px0")).alias("spread"),
                    pl.when(is_buy).then(pl.col("bid_px0")).otherwise(pl.col("ask_px0")).alias("near_touch_px"),
                    pl.when(is_buy).then(pl.col("ask_px0")).otherwise(pl.col("bid_px0")).alias("far_touch_px"),
                    pl.when(is_buy).then(pl.col("bid_size0")).otherwise(pl.col("ask_size0")).alias("near_touch_size"),
                    pl.when(is_buy).then(pl.col("ask_size0")).otherwise(pl.col("bid_size0")).alias("far_touch_size"),
                ])
                df_fwd = df_fwd.with_columns((pl.col("spread") / pl.col("mid") * 10000).alias("spread_bps"))

                df_fwd = df_fwd.with_columns([
                    (pl.col("mid") / pl.col("fill_price") - 1).alias("markout"),
                    (pl.col("near_touch_px") / pl.col("fill_price") - 1).alias("fill_to_near_touch"),
                    (pl.col("far_touch_px") / pl.col("fill_price") - 1).alias("fill_to_far_touch"),
                ])

                mid_0 = df_fwd.filter(pl.col("horizon") == 0).select(["seq", "data_date", pl.col("mid").alias("mid_0")])
                df_fwd = df_fwd.join(mid_0, on=["seq", "data_date"])
                df_fwd = df_fwd.with_columns(((pl.col("mid") - pl.col("mid_0")) / pl.col("mid_0")).alias("return")).drop("mid_0")

                sided_cols = ["return", "markout", "fill_to_near_touch", "fill_to_far_touch"]
                df_fwd = df_fwd.with_columns([
                    pl.when(pl.col("order_side") == "Sell").then(-pl.col(c)).otherwise(pl.col(c)).alias(f"sided_{c}")
                    for c in sided_cols
                ])
                return df_fwd.drop(["fill_price", "order_side"])

            # ═══════════════════════════════════════════════════════════════
            # CLI
            # ═══════════════════════════════════════════════════════════════
            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                vf.set_config(vf.Config(
                    trade_dir=TRADE_DIR, trade_pattern=TRADE_PATTERN, trade_schema=TRADE_SCHEMA,
                    quote_dir=QUOTE_DIR, quote_pattern=QUOTE_PATTERN, quote_schema=QUOTE_SCHEMA,
                    market=MARKET,
                ))

                out_dir = OUTPUT_DIR / "fwd_create"
                out_file = out_dir / f"{args.date}.parquet"
                if out_file.exists() and not args.force:
                    print(f"  skip {args.date} (exists)")
                    return

                print(f"Processing {args.date}...")
                df = process_date(args.date)
                out_dir.mkdir(parents=True, exist_ok=True)
                df.write_parquet(str(out_file))
                print(f"  {len(df)} rows -> {out_file}")

            if __name__ == "__main__":
                main()"""),
    },
}


# ═══════════════════════════════════════════════════════════════════
# PLAN WHITEBOARD API — vf.templates.list() / .show() / .path()
# ═══════════════════════════════════════════════════════════════════
def list() -> None:
    """Print available plan whiteboards with descriptions."""
    # Find max name length for alignment
    max_name = max(len(name) for name in _PLANS)
    print(f"{'name':<{max_name}}  description")
    print(f"{'─' * max_name}  {'─' * 50}")
    for name, info in _PLANS.items():
        print(f"{name:<{max_name}}  {info['description']}")


def show(name: str) -> None:
    """Print notebook-ready plan code to stdout. Copy-paste into a notebook cell.

    Args:
        name: Plan name (see ``list()`` for available plans).
    """
    if name not in _PLANS:
        available = ", ".join(_PLANS)
        raise KeyError(f"Plan '{name}' not found. Available: {available}")

    code = _PLANS[name]["code"]

    # Try syntax highlighting with rich/pygments, fall back to plain print
    try:
        from rich.console import Console
        from rich.syntax import Syntax
        console = Console()
        syntax = Syntax(code, "python", theme="monokai", line_numbers=False, word_wrap=True)
        console.print(syntax)
    except ImportError:
        print(code)


def path(name: str) -> Path:
    """Return Path to the full template script file.

    Args:
        name: Plan name (see ``list()`` for available plans).
    """
    if name not in _PLANS:
        available = ", ".join(_PLANS)
        raise KeyError(f"Plan '{name}' not found. Available: {available}")
    return TEMPLATES_DIR / _PLANS[name]["file"]


# ═══════════════════════════════════════════════════════════════════
# LEGACY API — backward compatible
# ═══════════════════════════════════════════════════════════════════
def list_templates() -> list[str]:
    """List available template files."""
    return [f.name for f in TEMPLATES_DIR.glob("*.py") if f.name != "__init__.py"]


def get_template_path(name: str) -> Path:
    """Get the full path to a template file."""
    filepath = TEMPLATES_DIR / name
    if not filepath.exists():
        available = list_templates()
        raise FileNotFoundError(
            f"Template '{name}' not found. Available: {available}"
        )
    return filepath


def copy_template(name: str, dest: str | Path) -> Path:
    """Copy a template file to the destination path.

    Args:
        name: Template file name (e.g., "merge_forward_by_date.py")
        dest: Destination path (file path or directory)

    Returns:
        Path to the copied file
    """
    src = get_template_path(name)
    dest = Path(dest)

    if dest.is_dir():
        dest = dest / name

    shutil.copy2(src, dest)
    return dest
