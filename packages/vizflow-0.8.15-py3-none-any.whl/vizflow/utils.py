"""Utility functions for VizFlow."""

from __future__ import annotations

import polars as pl


def add_tod(
    df: pl.LazyFrame,
    timestamp_col: str = "ticktime",
) -> pl.LazyFrame:
    """Add time-of-day column for plotting.

    Converts HHMMSSMMM integer timestamp to pl.Datetime (epoch date)
    for direct matplotlib/seaborn compatibility.

    Note: Not supported by Delta Lake — use only for plotting.

    Args:
        df: Input LazyFrame with HHMMSSMMM timestamp column
        timestamp_col: Column with integer HHMMSSMMM format timestamps
            e.g., 93012145 = 09:30:12.145, 142058425 = 14:20:58.425

    Returns:
        LazyFrame with tod_{timestamp_col} (pl.Datetime) column added.
        Plots directly with matplotlib — X axis shows HH:MM.

    Example:
        >>> df = vf.add_tod(df, "ticktime")
        >>> pdf = df.collect().to_pandas()
        >>> ax.scatter(pdf["tod_ticktime"], pdf["bid_px0"])  # just works
    """
    _hour = pl.col(timestamp_col) // 10000000
    _minute = pl.col(timestamp_col) // 100000 % 100
    _second = pl.col(timestamp_col) // 1000 % 100
    _ms = pl.col(timestamp_col) % 1000

    tod_expr = pl.datetime(
        year=1970, month=1, day=1,
        hour=_hour,
        minute=_minute,
        second=_second,
        microsecond=_ms * 1000,
    )
    return df.with_columns(tod_expr.alias(f"tod_{timestamp_col}"))


class DurationFormatter:
    """Matplotlib axis formatter for duration values (in milliseconds).

    Displays tick labels as human-readable durations: "30s", "5m", "1h20m".

    Usage:
        ax.scatter(pdf["elapsed_ticktime"], pdf["y"])
        ax.xaxis.set_major_formatter(vf.DurationFormatter())

    Or with log scale:
        ax.set_xscale("log")
        ax.xaxis.set_major_formatter(vf.DurationFormatter())
    """

    def __call__(self, x: float, pos: int | None = None) -> str:
        return format_duration(x)

    def __repr__(self) -> str:
        return "DurationFormatter()"


def format_duration(ms: float) -> str:
    """Format milliseconds as human-readable duration string.

    Args:
        ms: Duration in milliseconds.

    Examples:
        500     -> "500ms"
        30000   -> "30s"
        90000   -> "1m30s"
        3600000 -> "1h"
        5400000 -> "1h30m"
    """
    if ms == 0:
        return "0s"

    neg = ms < 0
    ms_abs = abs(ms)

    if ms_abs < 1000:
        label = f"{round(ms_abs)}ms"
    elif ms_abs < 60000:
        s = ms_abs / 1000
        if s == int(s):
            label = f"{int(s)}s"
        else:
            label = f"{s:.1f}s"
    elif ms_abs < 3600000:
        m = int(ms_abs // 60000)
        rem_s = int((ms_abs % 60000) // 1000)
        label = f"{m}m{rem_s}s" if rem_s else f"{m}m"
    else:
        h = int(ms_abs // 3600000)
        rem_m = int((ms_abs % 3600000) // 60000)
        label = f"{h}h{rem_m}m" if rem_m else f"{h}h"

    return f"-{label}" if neg else label
