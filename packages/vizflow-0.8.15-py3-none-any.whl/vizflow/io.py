"""I/O functions for VizFlow with automatic schema evolution."""

from __future__ import annotations

import re
from pathlib import Path

import polars as pl

from .config import Config, get_config
from .schema_evolution import SchemaEvolution, get_schema


def _extract_date_from_path(path: Path, pattern: str) -> str | None:
    """Extract date from filename using pattern.

    Args:
        path: File path.
        pattern: Pattern with {date} placeholder, e.g., "{date}.meords"

    Returns:
        Extracted date string, or None if no match or no {date} in pattern.

    Example:
        >>> _extract_date_from_path(Path("data/11110101.meords"), "{date}.meords")
        "11110101"
    """
    # If pattern has no {date} placeholder, return None
    if "{date}" not in pattern:
        return None

    # Convert pattern to regex: "{date}" -> "(?P<date>.+)"
    # Escape other special chars first
    regex_pattern = re.escape(pattern).replace(r"\{date\}", r"(?P<date>[^/]+)")
    match = re.search(regex_pattern, path.name)
    if match:
        return match.group("date")
    return None


def _resolve_schema(
    schema_ref: str | SchemaEvolution | None,
) -> SchemaEvolution | None:
    """Resolve schema reference to SchemaEvolution instance.

    Args:
        schema_ref: Schema name string, SchemaEvolution instance, or None.

    Returns:
        SchemaEvolution instance or None.

    Raises:
        ValueError: If schema_ref is a string but not found in the registry.
    """
    if schema_ref is None:
        return None
    if isinstance(schema_ref, SchemaEvolution):
        return schema_ref
    schema = get_schema(schema_ref)
    if schema is None:
        from .schema_evolution import SCHEMAS

        raise ValueError(
            f"Unknown schema: {schema_ref!r}. "
            f"Available: {list(SCHEMAS.keys())}"
        )
    return schema


def _scan_file(
    path,
    schema: SchemaEvolution | None = None,
    columns: list[str] | None = None,
) -> pl.LazyFrame:
    """Scan a file based on its extension with optional schema.

    Args:
        path: Path to file.
        schema: Optional SchemaEvolution for CSV parsing options.
        columns: Optional list of columns to select (pre-rename names).
            For FST: passed to read_fst column_selection (read-time projection).
            For other formats: applied as .select() (optimized via projection pushdown).

    Returns:
        LazyFrame from the file.

    Supported formats:
        - .feather, .ipc, .arrow: IPC format (pl.scan_ipc)
        - .csv, .meords, .ords: CSV format (pl.scan_csv)
        - .parquet: Parquet format (pl.scan_parquet)
        - .fst: FST format (fst_helper.read_fst → pandas → polars)
    """
    suffix = str(path).lower().split(".")[-1]

    if suffix in ("feather", "ipc", "arrow"):
        lf = pl.scan_ipc(path)
    elif suffix in ("csv", "meords", "ords"):
        csv_kwargs = {}
        if schema:
            schema_overrides = schema.get_schema_overrides()
            if schema_overrides:
                csv_kwargs["schema_overrides"] = schema_overrides
            null_values = schema.get_null_values()
            if null_values:
                csv_kwargs["null_values"] = null_values
        lf = pl.scan_csv(path, **csv_kwargs)
    elif suffix == "parquet":
        lf = pl.scan_parquet(path)
    elif suffix == "fst":
        try:
            from fst_helper.read_fst import read_fst
        except ImportError as e:
            if "fst_helper" in str(e):
                raise ImportError(
                    "fst_helper required for .fst files. "
                    "Install: pip install vizflow[fst]"
                ) from e
            raise
        pdf = read_fst(str(path), column_selection=columns)
        return pl.from_pandas(pdf).lazy()
    else:
        raise ValueError(
            f"Unsupported file format: .{suffix}. "
            "Supported: .feather, .ipc, .arrow, .csv, .meords, .ords, .parquet, .fst"
        )

    # For non-FST formats, apply column selection via projection pushdown
    if columns:
        lf = lf.select(columns)
    return lf


def _apply_schema_evolution(
    df: pl.LazyFrame,
    schema: SchemaEvolution,
) -> pl.LazyFrame:
    """Apply full schema evolution: drop, rename, transform, cast.

    Args:
        df: LazyFrame to transform.
        schema: SchemaEvolution with transformation rules.

    Returns:
        Transformed LazyFrame.
    """
    existing = set(df.collect_schema().names())

    # Step 1: Drop excluded columns
    drop_cols = schema.get_drop_columns()
    to_drop = [c for c in drop_cols if c in existing]
    if to_drop:
        df = df.drop(to_drop)
        existing -= set(to_drop)

    # Step 2: Rename columns
    rename_map = schema.get_rename_map()
    to_rename = {k: v for k, v in rename_map.items() if k in existing}
    if to_rename:
        df = df.rename(to_rename)
        # Update existing names after rename
        for old, new in to_rename.items():
            existing.discard(old)
            existing.add(new)

    # Step 3: Transform columns (post-rename, pre-cast)
    transform_map = schema.get_transform_map()
    for col_name, fn in transform_map.items():
        if col_name in existing:
            df = df.with_columns(fn(pl.col(col_name)).alias(col_name))

    # Step 3.5: Zero-size → null price (post-rename, pre-cast)
    for size_col, price_col in schema.get_zero_size_nulls_price():
        if size_col in existing and price_col in existing:
            df = df.with_columns(
                pl.when(pl.col(size_col) == 0)
                .then(None)
                .otherwise(pl.col(price_col))
                .alias(price_col)
            )

    # Step 4: Cast columns (using FINAL names after rename)
    # Round before casting to integer types to handle float noise
    # (e.g., 125.00000001 → round → 125.0 → cast → 125)
    _INT_TYPES = (pl.Int8, pl.Int16, pl.Int32, pl.Int64,
                  pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64)
    cast_map = schema.get_cast_map()
    for col_name, dtype in cast_map.items():
        if col_name in existing:
            if dtype in _INT_TYPES:
                df = df.with_columns(pl.col(col_name).round(0).cast(dtype))
            else:
                df = df.with_columns(pl.col(col_name).cast(dtype))

    return df


def _scan_single_trade(
    path: Path,
    schema: "SchemaEvolution | None",
    date: str,
) -> pl.LazyFrame:
    """Scan a single trade file with schema evolution.

    Internal helper used by scan_trade and scan_trades.

    Args:
        path: Path to the trade file.
        schema: Optional SchemaEvolution instance.
        date: Date string for data_date column.

    Returns:
        LazyFrame with schema evolution, seq, and data_date applied.
    """
    df = _scan_file(path, schema=schema)
    if schema:
        df = _apply_schema_evolution(df, schema)

    # Ensure seq column exists (auto-generate if missing)
    if "seq" not in df.collect_schema().names():
        df = df.with_row_index("seq").cast({"seq": pl.Int64})

    df = df.with_columns(pl.lit(date).str.to_date("%Y%m%d").cast(pl.Date).alias("data_date"))

    return df


def scan_trade(date: str, config: Config | None = None) -> pl.LazyFrame:
    """Scan single date trade file with schema evolution.

    Supports IPC/feather, CSV (including .meords), and Parquet formats.
    When trade_dir is a dict (multi-source), scans all sources and adds
    a tag column (named by trade_tag) to distinguish them.

    Args:
        date: Date string, e.g. "20241001"
        config: Config to use, or get_config() if None

    Returns:
        LazyFrame with schema evolution applied

    Example:
        >>> config = vf.Config(
        ...     trade_dir=Path("/data/ylin/trade"),
        ...     trade_pattern="{date}.meords",
        ...     trade_schema="ylin_v20251204",
        ... )
        >>> vf.set_config(config)
        >>> df = vf.scan_trade("20241001")
    """
    config = config or get_config()
    path_or_paths = config.get_trade_path(date)
    schema = _resolve_schema(config.trade_schema)

    if isinstance(path_or_paths, dict):
        dfs = []
        for tag, path in path_or_paths.items():
            df = _scan_single_trade(path, schema, date)
            df = df.with_columns(pl.lit(tag).alias(config.trade_tag))
            dfs.append(df)
        return pl.concat(dfs)

    return _scan_single_trade(path_or_paths, schema, date)


def scan_trades(config: Config | None = None) -> pl.LazyFrame:
    """Scan all trade files with schema evolution and data_date column.

    Extracts date from each filename using the pattern and adds a "data_date" column.
    When trade_dir is a dict (multi-source), scans all sources and adds
    a tag column (named by trade_tag) to distinguish them.

    Args:
        config: Config to use, or get_config() if None

    Returns:
        LazyFrame with schema evolution applied and data_date column added

    Raises:
        ValueError: If trade_dir is not set or no files found

    Example:
        >>> config = vf.Config(
        ...     trade_dir=Path("/data/ylin/trade"),
        ...     trade_pattern="{date}.meords",
        ...     trade_schema="ylin_v20251204",
        ... )
        >>> vf.set_config(config)
        >>> df = vf.scan_trades()  # Has "data_date" column
    """
    config = config or get_config()
    if config.trade_dir is None:
        raise ValueError("trade_dir is not set in Config")

    schema = _resolve_schema(config.trade_schema)
    pattern = config.trade_pattern.replace("{date}", "*")

    if isinstance(config.trade_dir, dict):
        dfs = []
        for tag, dir_path in config.trade_dir.items():
            files = sorted(dir_path.glob(pattern))
            for f in files:
                date = _extract_date_from_path(f, config.trade_pattern)
                df = _scan_single_trade(f, schema, date or "00000000")
                df = df.with_columns(pl.lit(tag).alias(config.trade_tag))
                dfs.append(df)
        if not dfs:
            raise ValueError(
                f"No files found matching {pattern} in any source directory"
            )
        return pl.concat(dfs)

    # Single-dir path (unchanged)
    files = sorted(config.trade_dir.glob(pattern))
    if not files:
        raise ValueError(f"No files found matching {pattern} in {config.trade_dir}")

    dfs = []
    for f in files:
        date = _extract_date_from_path(f, config.trade_pattern)
        df = _scan_single_trade(f, schema, date or "00000000")
        dfs.append(df)

    return pl.concat(dfs)


def scan_alpha(date: str, config: Config | None = None) -> pl.LazyFrame:
    """Scan single date alpha file with schema evolution.

    Args:
        date: Date string, e.g. "20241001"
        config: Config to use, or get_config() if None

    Returns:
        LazyFrame with schema evolution applied

    Example:
        >>> config = vf.Config(
        ...     alpha_dir=Path("/data/jyao/alpha"),
        ...     alpha_pattern="alpha_{date}.feather",
        ...     alpha_schema="jyao_v20251114",
        ... )
        >>> vf.set_config(config)
        >>> df = vf.scan_alpha("20251114")
    """
    config = config or get_config()
    path = config.get_alpha_path(date)
    schema = _resolve_schema(config.alpha_schema)

    df = _scan_file(path, schema=schema)
    if schema:
        df = _apply_schema_evolution(df, schema)

    df = df.with_columns(pl.lit(date).str.to_date("%Y%m%d").cast(pl.Date).alias("data_date"))

    return df


def scan_alphas(config: Config | None = None) -> pl.LazyFrame:
    """Scan all alpha files with schema evolution.

    Args:
        config: Config to use, or get_config() if None

    Returns:
        LazyFrame with schema evolution applied

    Raises:
        ValueError: If alpha_dir is not set or no files found
    """
    config = config or get_config()
    if config.alpha_dir is None:
        raise ValueError("alpha_dir is not set in Config")

    pattern = config.alpha_pattern.replace("{date}", "*")
    files = sorted(config.alpha_dir.glob(pattern))
    if not files:
        raise ValueError(f"No files found matching {pattern} in {config.alpha_dir}")

    schema = _resolve_schema(config.alpha_schema)

    # Apply schema evolution per-file BEFORE concat to ensure matching schemas
    dfs = []
    for f in files:
        df = _scan_file(f, schema=schema)
        if schema:
            df = _apply_schema_evolution(df, schema)
        # Convert data_date: Int64 (20240827) -> Date
        df = df.with_columns(
            pl.col("data_date").cast(pl.String).str.to_date("%Y%m%d")
        )
        dfs.append(df)

    return pl.concat(dfs)


def scan_quote(
    date: str,
    columns: list[str] | None = None,
    config: Config | None = None,
) -> pl.LazyFrame:
    """Scan single date quote file with schema evolution.

    Supports all formats including FST (via fst_helper).
    For large FST files, pass columns to limit read-time projection.

    Args:
        date: Date string, e.g. "20241001"
        columns: Optional list of columns to select (VizFlow convention names,
            e.g. ["ukey", "ticktime", "bid_px0", "ask_px0"]).
            Reverse-mapped through schema for read-time projection.
        config: Config to use, or get_config() if None

    Returns:
        LazyFrame with schema evolution applied

    Example:
        >>> config = vf.Config(
        ...     quote_dir=Path("/data/stock_sorted_t5ob"),
        ...     quote_pattern="{date}.fst",
        ...     quote_schema="stock_sorted_t5ob",
        ... )
        >>> vf.set_config(config)
        >>> df = vf.scan_quote("20241001", columns=["ukey", "ticktime", "bid_px0", "ask_px0"])
    """
    config = config or get_config()
    path = config.get_quote_path(date)
    schema = _resolve_schema(config.quote_schema)

    # Reverse-map VizFlow column names → original file column names
    raw_columns = None
    if columns and schema:
        reverse_map = schema.get_reverse_rename_map()
        raw_columns = [reverse_map.get(c, c) for c in columns]
    elif columns:
        raw_columns = columns

    df = _scan_file(path, schema=schema, columns=raw_columns)
    if schema:
        df = _apply_schema_evolution(df, schema)

    df = df.with_columns(pl.lit(date).str.to_date("%Y%m%d").cast(pl.Date).alias("data_date"))

    return df


def scan_quotes(
    columns: list[str] | None = None,
    config: Config | None = None,
) -> pl.LazyFrame:
    """Scan all quote files with schema evolution and data_date column.

    Args:
        columns: Optional list of columns to select (VizFlow convention names).
        config: Config to use, or get_config() if None

    Returns:
        LazyFrame with schema evolution applied and data_date column added

    Raises:
        ValueError: If quote_dir is not set or no files found
    """
    config = config or get_config()
    if config.quote_dir is None:
        raise ValueError("quote_dir is not set in Config")

    pattern = config.quote_pattern.replace("{date}", "*")
    files = sorted(config.quote_dir.glob(pattern))
    if not files:
        raise ValueError(f"No files found matching {pattern} in {config.quote_dir}")

    schema = _resolve_schema(config.quote_schema)

    # Reverse-map VizFlow column names → original file column names
    raw_columns = None
    if columns and schema:
        reverse_map = schema.get_reverse_rename_map()
        raw_columns = [reverse_map.get(c, c) for c in columns]
    elif columns:
        raw_columns = columns

    # Apply schema evolution per-file BEFORE concat to ensure matching schemas
    dfs = []
    for f in files:
        df = _scan_file(f, schema=schema, columns=raw_columns)
        if schema:
            df = _apply_schema_evolution(df, schema)
        date = _extract_date_from_path(f, config.quote_pattern)
        if date:
            df = df.with_columns(pl.lit(date).str.to_date("%Y%m%d").cast(pl.Date).alias("data_date"))
        dfs.append(df)

    return pl.concat(dfs)


def scan_univ(date: str, config: Config | None = None) -> pl.LazyFrame:
    """Scan single date universe file with schema evolution.

    Args:
        date: Date string, e.g. "20241001"
        config: Config to use, or get_config() if None

    Returns:
        LazyFrame with schema evolution applied

    Example:
        >>> config = vf.Config(
        ...     univ_dir=Path("/data/jyao/univ"),
        ...     univ_pattern="{date}.csv",
        ... )
        >>> vf.set_config(config)
        >>> df = vf.scan_univ("20241001")
    """
    config = config or get_config()
    path = config.get_univ_path(date)
    schema = _resolve_schema(config.univ_schema)

    df = _scan_file(path, schema=schema)
    if schema:
        df = _apply_schema_evolution(df, schema)

    df = df.with_columns(pl.lit(date).str.to_date("%Y%m%d").cast(pl.Date).alias("data_date"))

    return df


def scan_univs(config: Config | None = None) -> pl.LazyFrame:
    """Scan all universe files with schema evolution and data_date column.

    Extracts date from each filename using the pattern and adds a "data_date" column.

    Args:
        config: Config to use, or get_config() if None

    Returns:
        LazyFrame with schema evolution applied and data_date column added

    Raises:
        ValueError: If univ_dir is not set or no files found
    """
    config = config or get_config()
    if config.univ_dir is None:
        raise ValueError("univ_dir is not set in Config")

    pattern = config.univ_pattern.replace("{date}", "*")
    files = sorted(config.univ_dir.glob(pattern))
    if not files:
        raise ValueError(f"No files found matching {pattern} in {config.univ_dir}")

    schema = _resolve_schema(config.univ_schema)

    # Scan each file, apply schema evolution, and add data_date column
    # Schema evolution must be applied per-file BEFORE concat to ensure matching schemas
    dfs = []
    for f in files:
        df = _scan_file(f, schema=schema)
        if schema:
            df = _apply_schema_evolution(df, schema)
        date = _extract_date_from_path(f, config.univ_pattern)
        if date:
            df = df.with_columns(pl.lit(date).str.to_date("%Y%m%d").cast(pl.Date).alias("data_date"))
        dfs.append(df)

    return pl.concat(dfs)


def load_calendar(config: Config | None = None) -> pl.DataFrame:
    """Load trading calendar.

    Args:
        config: Config to use, or get_config() if None

    Returns:
        DataFrame with date, prev_date, next_date columns

    Raises:
        ValueError: If calendar_path is not set in config

    Example:
        >>> config = vf.Config(
        ...     calendar_path=Path("/data/calendar.parquet")
        ... )
        >>> vf.set_config(config)
        >>> calendar = vf.load_calendar()
    """
    config = config or get_config()
    if config.calendar_path is None:
        raise ValueError("calendar_path is not set in Config")
    return pl.read_parquet(config.calendar_path)
