"""
VizFlow - TB-scale data analysis and visualization library.

Usage:
    import vizflow as vf
"""

__version__ = "0.8.15"

from .config import Config, get_config, set_config
from .io import (
    load_calendar,
    scan_alpha,
    scan_alphas,
    scan_quote,
    scan_quotes,
    scan_trade,
    scan_trades,
    scan_univ,
    scan_univs,
)
from .market import CN, CRYPTO, Market, Session
from .ops import (
    aggregate,
    bin,
    forward_return,
    horizon_cols,
    horizon_suffix,
    mark_to_close,
    melt_forward,
    merge_forward,
    parse_time,
    pivot_horizons,
    sign_by_side,
)
from .utils import DurationFormatter, add_tod, format_duration
from . import templates, viz
from .workspace import (
    ComputeNode,
    SourceNode,
    Workspace,
    connect,
    init_workspace,
    refresh_dot,
)
from .execute import execute
from .schema_evolution import (
    ERIC_V20260205,
    JYAO_V20251114,
    OIC_LIVE,
    SCHEMAS,
    STOCK_SORTED_T5OB,
    YLIN_V20251204,
    ColumnSpec,
    SchemaEvolution,
    get_schema,
)