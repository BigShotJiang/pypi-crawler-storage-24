"""cash4tokens CLI - share AI compute and earn USDC."""

from __future__ import annotations

import asyncio
import json
import logging
import platform
import subprocess
import sys
from pathlib import Path

import httpx
import typer

from .app_version import get_cash4tokens_version
from .update import (
    DEFAULT_SERVER_URL,
    UpdateManager,
    default_manifest_url,
    restart_current_process,
)

app = typer.Typer(
    name="cash4tokens",
    help="Run the cash4tokens provider daemon and manage your provider machine.",
    no_args_is_help=True,
)

CONFIG_DIR = Path.home() / ".cash4tokens"
CONFIG_FILE = CONFIG_DIR / "config.json"
PLIST_NAME = "com.cash4tokens.daemon"
PLIST_PATH = Path.home() / "Library" / "LaunchAgents" / f"{PLIST_NAME}.plist"

log = logging.getLogger("cash4tokens.cli")


def _load_optional_config() -> dict:
    """Load config from ~/.cash4tokens/config.json when it exists."""
    if not CONFIG_FILE.exists():
        return {}
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def _load_config() -> dict:
    """Load config from ~/.cash4tokens/config.json."""
    config = _load_optional_config()
    if not config:
        typer.echo("Not initialized. Run: cash4tokens init --wallet <addr>")
        raise typer.Exit(1)
    return config


def _save_config(config: dict) -> None:
    """Save config to ~/.cash4tokens/config.json."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2), encoding="utf-8")


def _unwrap_response(payload: dict) -> dict:
    """Unwrap the backend's standard {success, data} envelope."""
    if isinstance(payload, dict) and "data" in payload:
        data = payload["data"]
        if isinstance(data, dict):
            return data
        return {"items": data}
    return payload


def _extract_provider_earnings(payload: dict) -> dict:
    """Normalize seller stats from either the new or legacy backend shape."""
    if "earned_usdc" in payload or "recent_requests" in payload:
        return {
            "request_count": payload.get("request_count", 0),
            "earned_usdc": payload.get("earned_usdc", 0),
            "recent_requests": payload.get("recent_requests", []),
        }

    provided = payload.get("provided", {}) if isinstance(payload, dict) else {}
    recent = payload.get("recent_provided", []) if isinstance(payload, dict) else []
    return {
        "request_count": provided.get("request_count", 0),
        "earned_usdc": provided.get("earned_usdc", 0),
        "recent_requests": recent,
    }


def _api_headers(config: dict) -> dict[str, str]:
    """Build authenticated headers for user-facing API endpoints."""
    api_key = config.get("api_key")
    if not api_key:
        typer.echo(
            "This config is missing the user API key. Run 'cash4tokens init' again."
        )
        raise typer.Exit(1)
    return {"Authorization": f"Bearer {api_key}"}


def _is_valid_evm_address(value: str) -> bool:
    """Return True when the value looks like a Base/EVM wallet address."""
    if len(value) != 42 or not value.startswith("0x"):
        return False
    return all(char in "0123456789abcdefABCDEF" for char in value[2:])


def _collect_init_inputs(
    wallet: str | None,
    email: str | None,
    server: str,
    display_name: str,
) -> tuple[str, str | None]:
    """Collect missing init inputs interactively when the command runs in a TTY."""
    if wallet:
        if not _is_valid_evm_address(wallet):
            typer.echo(
                "Invalid wallet address. Expected a 42-character Base/EVM address such as "
                "0x1234...abcd."
            )
            raise typer.Exit(1)
        return wallet, email

    if not sys.stdin.isatty():
        typer.echo(
            "Missing wallet address. Pass --wallet when running non-interactively."
        )
        raise typer.Exit(1)

    typer.echo("cash4tokens provider setup")
    typer.echo(f"Machine: {display_name}")
    typer.echo(f"API: {server}")
    typer.echo("Your payout wallet is where cash4tokens will send earned USDC on Base.")

    entered_wallet = ""
    while not _is_valid_evm_address(entered_wallet):
        entered_wallet = typer.prompt(
            "Base wallet address for provider payouts",
            prompt_suffix=": ",
        ).strip()
        if not _is_valid_evm_address(entered_wallet):
            typer.echo("Enter a valid 0x-prefixed 42-character Base wallet address.")

    if email is None:
        entered_email = typer.prompt(
            "Notification email (optional, press Enter to skip)",
            default="",
            prompt_suffix=": ",
        ).strip()
        email = entered_email or None

    return entered_wallet, email


def _fetch_profile_from_api_key(server: str, api_key: str) -> dict:
    """Fetch the authenticated profile for an existing API key."""
    with httpx.Client(timeout=30) as client:
        response = client.get(
            f"{server}/api/v1/auth/me",
            headers={"Authorization": f"Bearer {api_key}"},
        )
    if response.status_code != 200:
        typer.echo(
            f"API key lookup failed: {response.status_code} {response.text[:300]}"
        )
        raise typer.Exit(1)
    return _unwrap_response(response.json())


def _register_provider_with_api_key(
    server: str,
    api_key: str,
    display_name: str,
    wallet: str,
) -> tuple[str, str]:
    """Register this machine as a provider for an existing cash4tokens account."""
    with httpx.Client(timeout=30) as client:
        response = client.post(
            f"{server}/api/v1/auth/register-provider",
            json={
                "machine_name": display_name,
                "base_wallet_address": wallet,
            },
            headers={"Authorization": f"Bearer {api_key}"},
        )
    if response.status_code != 200:
        typer.echo(
            f"Provider registration failed: {response.status_code} "
            f"{response.text[:300]}"
        )
        raise typer.Exit(1)

    payload = _unwrap_response(response.json())
    return payload["provider_id"], payload["daemon_token"]


def _build_update_manager(config: dict | None = None) -> UpdateManager:
    """Create the CLI update manager."""
    loaded_config = config if config is not None else _load_optional_config()
    save_config = _save_config if loaded_config else None
    return UpdateManager(loaded_config, save_config)


def _run_preflight_update(config: dict) -> None:
    """Apply a pending CLI update before long-lived commands start."""
    updater = _build_update_manager(config)
    result = updater.check_for_update(force=False)

    if result.status in {"not_due", "up_to_date"}:
        return

    if result.status == "check_failed":
        log.warning(result.message)
        return

    if result.status == "local_install":
        if result.required:
            typer.echo(result.message)
            raise typer.Exit(1)
        log.debug(result.message)
        return

    if result.status == "unknown_version":
        typer.echo(result.message)
        raise typer.Exit(1)

    if result.status != "update_available" or not result.manifest:
        return

    typer.echo(f"Updating cash4tokens CLI to {result.latest_version}...")
    install_result = updater.install_update(result.manifest)
    typer.echo(install_result.message)

    if install_result.applied:
        typer.echo("Restarting into the updated build...")
        restart_current_process()

    if install_result.required:
        raise typer.Exit(1)


@app.command()
def init(
    wallet: str | None = typer.Option(
        None,
        help="Base wallet address that should receive USDC provider payouts. If omitted, init will guide you.",
    ),
    email: str | None = typer.Option(
        None,
        help="Email address for provider notifications.",
    ),
    server: str = typer.Option(
        DEFAULT_SERVER_URL,
        help="cash4tokens API base URL.",
    ),
    api_key: str | None = typer.Option(
        None,
        help="Existing cash4tokens API key. Use this to attach a provider to an existing account.",
    ),
) -> None:
    """Register this machine as a compute provider."""
    server = server.rstrip("/")
    display_name = platform.node() or "provider"

    if api_key:
        typer.echo(f"Registering existing account with {server}...")
        profile = _fetch_profile_from_api_key(server, api_key)
        existing_wallet = str(profile.get("base_wallet_address") or "").strip() or None
        existing_email = str(profile.get("email") or "").strip() or None

        if email and existing_email and email.strip().lower() != existing_email.lower():
            typer.echo(
                f"Note: using existing account email {existing_email} from the API key."
            )
        email = existing_email or email

        wallet, email = _collect_init_inputs(
            wallet or existing_wallet,
            email,
            server,
            display_name,
        )
        user_id = profile["id"]
        provider_id, daemon_token = _register_provider_with_api_key(
            server,
            api_key,
            display_name,
            wallet,
        )
        typer.echo(f"Using existing account (user: {user_id[:8]}...)")
        typer.echo(f"Registered as provider (id: {provider_id[:8]}...)")
    else:
        wallet, email = _collect_init_inputs(wallet, email, server, display_name)
        typer.echo(f"Registering with {server}...")
        signup_payload: dict = {
            "display_name": display_name,
            "base_wallet_address": wallet,
        }
        if email:
            signup_payload["email"] = email

    try:
        if not api_key:
            with httpx.Client(timeout=30) as client:
                signup_response = client.post(
                    f"{server}/api/v1/auth/signup",
                    json=signup_payload,
                )
                if signup_response.status_code != 200:
                    detail = signup_response.text[:300]
                    if signup_response.status_code == 409 and email:
                        typer.echo(
                            "Signup failed: this email already has an account. "
                            "Run 'cash4tokens init --api-key <your_key>' to attach "
                            "this machine to the existing account."
                        )
                    else:
                        typer.echo(
                            f"Signup failed: {signup_response.status_code} {detail}"
                        )
                    raise typer.Exit(1)

                signup_data = _unwrap_response(signup_response.json())
                user_id = signup_data["user_id"]
                api_key = signup_data.get("api_key")
                typer.echo(f"Signed up as {display_name} (user: {user_id[:8]}...)")

                provider_id, daemon_token = _register_provider_with_api_key(
                    server,
                    api_key,
                    display_name,
                    wallet,
                )
                typer.echo(f"Registered as provider (id: {provider_id[:8]}...)")

    except httpx.ConnectError:
        typer.echo(f"Cannot connect to {server}. Is the cash4tokens API reachable?")
        raise typer.Exit(1)

    config = {
        "server_url": server,
        "manifest_url": default_manifest_url(server),
        "provider_id": provider_id,
        "daemon_token": daemon_token,
        "api_key": api_key,
        "user_id": user_id,
        "wallet_address": wallet,
    }
    _save_config(config)

    typer.echo(f"Config saved to {CONFIG_FILE}")
    typer.echo("Run 'cash4tokens start' to begin sharing compute.")


@app.command()
def start(
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Enable debug logging."
    ),
) -> None:
    """Start the provider daemon in the foreground."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )

    config = _load_config()
    _run_preflight_update(config)

    typer.echo(
        f"Starting cash4tokens daemon {get_cash4tokens_version()} "
        f"(server: {config['server_url']})"
    )

    from .daemon import Cash4TokensDaemon

    daemon = Cash4TokensDaemon(config, save_config=_save_config)
    try:
        asyncio.run(daemon.run())
    except KeyboardInterrupt:
        typer.echo("\nDaemon stopped.")


@app.command()
def status() -> None:
    """Show provider connectivity, earnings, and server health."""
    config = _load_config()
    server = config["server_url"]
    headers = _api_headers(config)

    try:
        with httpx.Client(timeout=15) as client:
            try:
                health_response = client.get(f"{server}/health")
                health_ok = health_response.status_code == 200
                health_data = health_response.json() if health_ok else {}
            except httpx.ConnectError:
                health_ok = False
                health_data = {}

            typer.echo(f"CLI version: {get_cash4tokens_version()}")
            typer.echo(f"Server: {server} ({'online' if health_ok else 'offline'})")
            if not health_ok:
                raise typer.Exit(1)

            provider_response = client.get(
                f"{server}/api/v1/admin/provider", headers=headers
            )
            provider_data = (
                _unwrap_response(provider_response.json())
                if provider_response.status_code == 200
                else {"items": []}
            )
            provider_list = provider_data.get("items", [])
            connected = any(
                item.get("provider_id") == config.get("provider_id")
                for item in provider_list
            )
            typer.echo(f"Daemon: {'connected' if connected else 'not connected'}")
            typer.echo(f"Providers online: {health_data.get('provider_count', 0)}")

            balance_response = client.get(
                f"{server}/api/v1/payment/balance", headers=headers
            )
            if balance_response.status_code == 200:
                balance_data = _unwrap_response(balance_response.json())
                typer.echo(
                    f"Current balance: ${float(balance_data.get('balance_usdc', 0)):.4f} USDC"
                )
            else:
                typer.echo("Current balance: unavailable")

            earnings_response = client.get(
                f"{server}/api/v1/admin/provider-earnings", headers=headers
            )
            if earnings_response.status_code == 200:
                earnings_data = _extract_provider_earnings(
                    _unwrap_response(earnings_response.json())
                )
                typer.echo(f"Requests served: {earnings_data.get('request_count', 0)}")
                typer.echo(
                    f"Total earned: ${float(earnings_data.get('earned_usdc', 0)):.4f} USDC"
                )
            else:
                usage_response = client.get(
                    f"{server}/api/v1/admin/usage", headers=headers
                )
                if usage_response.status_code == 200:
                    earnings_data = _extract_provider_earnings(
                        _unwrap_response(usage_response.json())
                    )
                    typer.echo(
                        f"Requests served: {earnings_data.get('request_count', 0)}"
                    )
                    typer.echo(
                        f"Total earned: ${float(earnings_data.get('earned_usdc', 0)):.4f} USDC"
                    )
                else:
                    typer.echo("Provider earnings: unavailable")

    except httpx.ConnectError:
        typer.echo(f"Cannot connect to {server}")
        raise typer.Exit(1)

    typer.echo(f"Wallet: {config.get('wallet_address', 'not set')}")
    typer.echo(f"Provider ID: {config.get('provider_id', 'unknown')}")


@app.command()
def dashboard() -> None:
    """Show provider earnings, recent requests, and your own usage."""
    config = _load_config()
    server = config["server_url"]
    headers = _api_headers(config)

    try:
        with httpx.Client(timeout=15) as client:
            earnings_response = client.get(
                f"{server}/api/v1/admin/provider-earnings", headers=headers
            )
            usage_response = client.get(f"{server}/api/v1/admin/usage", headers=headers)
            if earnings_response.status_code != 200 or usage_response.status_code != 200:
                if usage_response.status_code != 200:
                    typer.echo("Could not fetch usage data.")
                    raise typer.Exit(1)

            earnings_data = (
                _extract_provider_earnings(_unwrap_response(earnings_response.json()))
                if earnings_response.status_code == 200
                else _extract_provider_earnings(_unwrap_response(usage_response.json()))
            )
            usage_data = _unwrap_response(usage_response.json())
            consumed = usage_data.get("consumed", {})

            typer.echo("=== Provider Dashboard ===\n")
            typer.echo(
                f"Total earned:      ${float(earnings_data.get('earned_usdc', 0)):.4f} USDC"
            )
            typer.echo(f"Requests served:   {earnings_data.get('request_count', 0)}")

            balance_response = client.get(
                f"{server}/api/v1/payment/balance", headers=headers
            )
            if balance_response.status_code == 200:
                balance_data = _unwrap_response(balance_response.json())
                typer.echo(
                    f"Current balance:   ${float(balance_data.get('balance_usdc', 0)):.4f} USDC"
                )

            typer.echo(f"\nWallet: {config.get('wallet_address', 'not set')}")
            typer.echo("\n--- Recent Requests Served ---")

            recent = earnings_data.get("recent_requests", [])
            if not recent:
                typer.echo("  No requests served yet.")
            else:
                for request in recent[:15]:
                    model = request.get("model_requested", "?")
                    input_tokens = request.get("input_token") or 0
                    output_tokens = request.get("output_token") or 0
                    earned = float(
                        request.get("earned_usdc")
                        or request.get("seller_usdc")
                        or 0
                    )
                    timestamp = request.get("created_at", "")[:16]
                    typer.echo(
                        f"  {timestamp}  {model:25s}  "
                        f"in={input_tokens:>6,}  out={output_tokens:>6,}  "
                        f"${earned:.4f}"
                    )

            if consumed.get("request_count", 0) > 0:
                typer.echo("\n--- Your Consumption ---")
                typer.echo(f"  Requests:  {consumed.get('request_count', 0)}")
                typer.echo(
                    f"  Spent:     ${float(consumed.get('total_cost_usdc', 0)):.4f} USDC"
                )

    except httpx.ConnectError:
        typer.echo(f"Cannot connect to {server}")
        raise typer.Exit(1)


@app.command()
def version() -> None:
    """Show the installed CLI version and update endpoint."""
    config = _load_optional_config()
    updater = _build_update_manager(config)

    typer.echo(f"cash4tokens {get_cash4tokens_version()}")
    typer.echo(f"Manifest: {updater.manifest_url}")

    update_state = config.get("update", {})
    if update_state:
        latest_version = update_state.get("latest_version")
        if latest_version:
            typer.echo(
                f"Last release seen: {latest_version} ({update_state.get('last_status', 'unknown')})"
            )


@app.command("self-update")
def self_update() -> None:
    """Fetch the release manifest and install the latest packaged CLI."""
    updater = _build_update_manager()
    result = updater.check_for_update(force=True)

    if result.status in {"up_to_date", "not_due"}:
        typer.echo(result.message)
        return

    if result.status in {"check_failed", "unknown_version"}:
        typer.echo(result.message)
        raise typer.Exit(1)

    if result.status == "local_install":
        typer.echo(result.message)
        if result.required:
            raise typer.Exit(1)
        return

    if result.status != "update_available" or not result.manifest:
        typer.echo("No update action was taken.")
        return

    typer.echo(f"Installing cash4tokens CLI {result.latest_version}...")
    install_result = updater.install_update(result.manifest)
    typer.echo(install_result.message)
    if not install_result.applied:
        raise typer.Exit(1)


def _find_cash4tokens_bin() -> str:
    """Find the cash4tokens executable path."""
    result = subprocess.run(["which", "cash4tokens"], capture_output=True, text=True)
    if result.returncode == 0:
        return result.stdout.strip()
    return sys.executable


def _generate_plist(bin_path: str) -> str:
    """Generate a macOS LaunchAgent plist for the daemon."""
    log_dir = CONFIG_DIR / "log"
    log_dir.mkdir(parents=True, exist_ok=True)

    if bin_path.endswith("cash4tokens"):
        program_args = f"""    <array>
      <string>{bin_path}</string>
      <string>start</string>
    </array>"""
    else:
        program_args = f"""    <array>
      <string>{bin_path}</string>
      <string>-m</string>
      <string>cash4tokens_cli.main</string>
      <string>start</string>
    </array>"""

    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>{PLIST_NAME}</string>
  <key>ProgramArguments</key>
{program_args}
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <dict>
    <key>NetworkState</key>
    <true/>
  </dict>
  <key>StandardOutPath</key>
  <string>{log_dir}/daemon.log</string>
  <key>StandardErrorPath</key>
  <string>{log_dir}/daemon.err</string>
  <key>ThrottleInterval</key>
  <integer>30</integer>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key>
    <string>/usr/local/bin:/usr/bin:/bin:/opt/homebrew/bin</string>
  </dict>
</dict>
</plist>
"""


@app.command()
def install() -> None:
    """Install the daemon to auto-start on login (macOS LaunchAgent)."""
    if platform.system() != "Darwin":
        typer.echo(
            "Auto-start is currently macOS only. Use systemd or another supervisor on Linux."
        )
        raise typer.Exit(1)

    config = _load_config()
    _run_preflight_update(config)

    bin_path = _find_cash4tokens_bin()
    plist_content = _generate_plist(bin_path)

    if PLIST_PATH.exists():
        subprocess.run(["launchctl", "unload", str(PLIST_PATH)], capture_output=True)

    PLIST_PATH.parent.mkdir(parents=True, exist_ok=True)
    PLIST_PATH.write_text(plist_content, encoding="utf-8")

    result = subprocess.run(
        ["launchctl", "load", str(PLIST_PATH)],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        typer.echo(f"Failed to load LaunchAgent: {result.stderr.strip()}")
        raise typer.Exit(1)

    typer.echo("cash4tokens daemon installed and started.")
    typer.echo(f"  Plist: {PLIST_PATH}")
    typer.echo(f"  Logs:  {CONFIG_DIR / 'log' / 'daemon.log'}")
    typer.echo(
        "It will auto-start on login and pick up new CLI releases automatically."
    )
    typer.echo("To remove: cash4tokens uninstall")


@app.command()
def uninstall() -> None:
    """Remove the auto-start daemon (macOS LaunchAgent)."""
    if not PLIST_PATH.exists():
        typer.echo("Not installed. Nothing to remove.")
        return

    subprocess.run(["launchctl", "unload", str(PLIST_PATH)], capture_output=True)
    PLIST_PATH.unlink()
    typer.echo("cash4tokens daemon uninstalled. It will no longer auto-start.")


if __name__ == "__main__":
    app()
