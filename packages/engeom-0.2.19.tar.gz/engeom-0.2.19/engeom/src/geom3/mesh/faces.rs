//! Mesh face-connectivity structure
