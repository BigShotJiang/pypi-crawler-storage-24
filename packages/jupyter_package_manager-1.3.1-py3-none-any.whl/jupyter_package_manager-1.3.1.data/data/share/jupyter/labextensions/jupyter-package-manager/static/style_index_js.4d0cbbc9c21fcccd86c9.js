"use strict";
(self["webpackChunkjupyter_package_manager"] = self["webpackChunkjupyter_package_manager"] || []).push([["style_index_js"],{

/***/ "./node_modules/css-loader/dist/runtime/api.js"
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
(module) {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
module.exports = function (cssWithMappingToString) {
  var list = [];

  // return the list of modules as css string
  list.toString = function toString() {
    return this.map(function (item) {
      var content = "";
      var needLayer = typeof item[5] !== "undefined";
      if (item[4]) {
        content += "@supports (".concat(item[4], ") {");
      }
      if (item[2]) {
        content += "@media ".concat(item[2], " {");
      }
      if (needLayer) {
        content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
      }
      content += cssWithMappingToString(item);
      if (needLayer) {
        content += "}";
      }
      if (item[2]) {
        content += "}";
      }
      if (item[4]) {
        content += "}";
      }
      return content;
    }).join("");
  };

  // import a list of modules into the list
  list.i = function i(modules, media, dedupe, supports, layer) {
    if (typeof modules === "string") {
      modules = [[null, modules, undefined]];
    }
    var alreadyImportedModules = {};
    if (dedupe) {
      for (var k = 0; k < this.length; k++) {
        var id = this[k][0];
        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }
    for (var _k = 0; _k < modules.length; _k++) {
      var item = [].concat(modules[_k]);
      if (dedupe && alreadyImportedModules[item[0]]) {
        continue;
      }
      if (typeof layer !== "undefined") {
        if (typeof item[5] === "undefined") {
          item[5] = layer;
        } else {
          item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
          item[5] = layer;
        }
      }
      if (media) {
        if (!item[2]) {
          item[2] = media;
        } else {
          item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
          item[2] = media;
        }
      }
      if (supports) {
        if (!item[4]) {
          item[4] = "".concat(supports);
        } else {
          item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
          item[4] = supports;
        }
      }
      list.push(item);
    }
  };
  return list;
};

/***/ },

/***/ "./node_modules/css-loader/dist/runtime/sourceMaps.js"
/*!************************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/sourceMaps.js ***!
  \************************************************************/
(module) {



module.exports = function (item) {
  var content = item[1];
  var cssMapping = item[3];
  if (!cssMapping) {
    return content;
  }
  if (typeof btoa === "function") {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    return [content].concat([sourceMapping]).join("\n");
  }
  return [content].join("\n");
};

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js"
/*!****************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \****************************************************************************/
(module) {



var stylesInDOM = [];
function getIndexByIdentifier(identifier) {
  var result = -1;
  for (var i = 0; i < stylesInDOM.length; i++) {
    if (stylesInDOM[i].identifier === identifier) {
      result = i;
      break;
    }
  }
  return result;
}
function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var indexByIdentifier = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3],
      supports: item[4],
      layer: item[5]
    };
    if (indexByIdentifier !== -1) {
      stylesInDOM[indexByIdentifier].references++;
      stylesInDOM[indexByIdentifier].updater(obj);
    } else {
      var updater = addElementStyle(obj, options);
      options.byIndex = i;
      stylesInDOM.splice(i, 0, {
        identifier: identifier,
        updater: updater,
        references: 1
      });
    }
    identifiers.push(identifier);
  }
  return identifiers;
}
function addElementStyle(obj, options) {
  var api = options.domAPI(options);
  api.update(obj);
  var updater = function updater(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap && newObj.supports === obj.supports && newObj.layer === obj.layer) {
        return;
      }
      api.update(obj = newObj);
    } else {
      api.remove();
    }
  };
  return updater;
}
module.exports = function (list, options) {
  options = options || {};
  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];
    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDOM[index].references--;
    }
    var newLastIdentifiers = modulesToDom(newList, options);
    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];
      var _index = getIndexByIdentifier(_identifier);
      if (stylesInDOM[_index].references === 0) {
        stylesInDOM[_index].updater();
        stylesInDOM.splice(_index, 1);
      }
    }
    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/insertBySelector.js"
/*!********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertBySelector.js ***!
  \********************************************************************/
(module) {



var memo = {};

/* istanbul ignore next  */
function getTarget(target) {
  if (typeof memo[target] === "undefined") {
    var styleTarget = document.querySelector(target);

    // Special case to return head of iframe instead of iframe itself
    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
      try {
        // This will throw an exception if access to iframe is blocked
        // due to cross-origin restrictions
        styleTarget = styleTarget.contentDocument.head;
      } catch (e) {
        // istanbul ignore next
        styleTarget = null;
      }
    }
    memo[target] = styleTarget;
  }
  return memo[target];
}

/* istanbul ignore next  */
function insertBySelector(insert, style) {
  var target = getTarget(insert);
  if (!target) {
    throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
  }
  target.appendChild(style);
}
module.exports = insertBySelector;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/insertStyleElement.js"
/*!**********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertStyleElement.js ***!
  \**********************************************************************/
(module) {



/* istanbul ignore next  */
function insertStyleElement(options) {
  var element = document.createElement("style");
  options.setAttributes(element, options.attributes);
  options.insert(element, options.options);
  return element;
}
module.exports = insertStyleElement;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js"
/*!**********************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js ***!
  \**********************************************************************************/
(module, __unused_webpack_exports, __webpack_require__) {



/* istanbul ignore next  */
function setAttributesWithoutAttributes(styleElement) {
  var nonce =  true ? __webpack_require__.nc : 0;
  if (nonce) {
    styleElement.setAttribute("nonce", nonce);
  }
}
module.exports = setAttributesWithoutAttributes;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/styleDomAPI.js"
/*!***************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleDomAPI.js ***!
  \***************************************************************/
(module) {



/* istanbul ignore next  */
function apply(styleElement, options, obj) {
  var css = "";
  if (obj.supports) {
    css += "@supports (".concat(obj.supports, ") {");
  }
  if (obj.media) {
    css += "@media ".concat(obj.media, " {");
  }
  var needLayer = typeof obj.layer !== "undefined";
  if (needLayer) {
    css += "@layer".concat(obj.layer.length > 0 ? " ".concat(obj.layer) : "", " {");
  }
  css += obj.css;
  if (needLayer) {
    css += "}";
  }
  if (obj.media) {
    css += "}";
  }
  if (obj.supports) {
    css += "}";
  }
  var sourceMap = obj.sourceMap;
  if (sourceMap && typeof btoa !== "undefined") {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  }

  // For old IE
  /* istanbul ignore if  */
  options.styleTagTransform(css, styleElement, options.options);
}
function removeStyleElement(styleElement) {
  // istanbul ignore if
  if (styleElement.parentNode === null) {
    return false;
  }
  styleElement.parentNode.removeChild(styleElement);
}

/* istanbul ignore next  */
function domAPI(options) {
  if (typeof document === "undefined") {
    return {
      update: function update() {},
      remove: function remove() {}
    };
  }
  var styleElement = options.insertStyleElement(options);
  return {
    update: function update(obj) {
      apply(styleElement, options, obj);
    },
    remove: function remove() {
      removeStyleElement(styleElement);
    }
  };
}
module.exports = domAPI;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/styleTagTransform.js"
/*!*********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleTagTransform.js ***!
  \*********************************************************************/
(module) {



/* istanbul ignore next  */
function styleTagTransform(css, styleElement) {
  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css;
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild);
    }
    styleElement.appendChild(document.createTextNode(css));
  }
}
module.exports = styleTagTransform;

/***/ },

/***/ "./style/index.js"
/*!************************!*\
  !*** ./style/index.js ***!
  \************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _base_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base.css */ "./style/base.css");



/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css"
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.push([module.id, "@import url(https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&display=swap);"]);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `.mljar-packages-manager-sidebar-widget {
  --bg: #f5f7fa;
  --surface: #fff;
  --surface2: #f0f4f8;
  --border: #e2e8f0;
  --border2: #cbd5e1;
  --text: #0f172a;
  --muted: #64748b;
  --blue: #0284c7;
  --blue-dim: #e0f2fe;
  --blue-glow: rgb(2 132 199 / 15%);
  --green: #16a34a;
  --green-dim: #dcfce7;
  --rose: #e11d48;
  --rose-dim: #ffe4e6;
  --mono: 'JetBrains Mono', 'Consolas', 'Monaco', monospace;
  --sans: 'Geist', -apple-system, blinkmacsystemfont, 'Segoe UI', sans-serif;

  background: radial-gradient(circle at 8% 0%, #ecfeff 0%, var(--bg) 40%);
  color: var(--text);
  padding: 14px 10px;
  font-family: var(--sans);
}

.mljar-packages-manager-sidebar-container {
  height: 100%;
  overflow: hidden;
}

.mljar-packages-manager-sidebar-container::-webkit-scrollbar {
  display: none;
}

.mljar-packages-manager-container {
  display: flex;
  flex-direction: column;
  min-height: 0;
  height: calc(100vh - 28px);
}

.mljar-packages-manager-home {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-height: 0;
}

.mljar-packages-manager-header-container {
  display: flex;
  align-items: center;
  gap: 6px;
  position: sticky;
  top: 0;
  z-index: 20;
  margin-right: 8px;
  margin-bottom: 8px;
  padding: 0 0 12px;
  background: transparent;
}

.mljar-packages-manager-header {
  margin: 0;
  margin-right: auto;
  font-size: 14px;
  font-weight: 600;
  letter-spacing: -0.1px;
  color: var(--text);
}

.mljar-packages-manager-header-title-wrap {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  margin-right: auto;
}

.mljar-packages-manager-count-badge {
  padding: 2px 8px;
  border: 1px solid var(--border);
  border-radius: 999px;
  background: var(--surface2);
  color: var(--muted);
  font-family: var(--mono);
  font-size: 10px;
}

.mljar-packages-manager-search-bar-container {
  position: sticky;
  top: 44px;
  z-index: 11;
  margin-right: 8px;
  margin-bottom: 10px;
  background: transparent;
}

.mljar-packages-manager-install-input,
.mljar-packages-manager-search-bar-input,
.mljar-pypi-settings-input {
  width: 100%;
  height: 36px;
  box-sizing: border-box;
  padding: 0 12px;
  border: 1px solid var(--border, #dbe3ec);
  border-radius: 9px;
  background: var(--surface, #fff);
  color: var(--text, #0f172a);
  caret-color: var(--text, #0f172a);
  font-family: var(--mono);
  font-size: 12px;
  font-weight: 500;
}

.mljar-packages-manager-install-input::placeholder,
.mljar-packages-manager-search-bar-input::placeholder,
.mljar-pypi-settings-input::placeholder {
  color: var(--muted, #64748b);
}

.mljar-packages-manager-install-input:focus,
.mljar-packages-manager-search-bar-input:focus,
.mljar-pypi-settings-input:focus {
  outline: none;
  border-color: rgb(2 132 199 / 40%);
  box-shadow: 0 0 0 3px var(--blue-glow);
}

.mljar-packages-manager-install-input:disabled,
.mljar-pypi-settings-input:disabled {
  opacity: 1;
  color: #334155;
  -webkit-text-fill-color: #334155;
}

.mljar-packages-manager-install-button,
.mljar-packages-manager-refresh-button,
.mljar-packages-manager-settings-button {
  display: inline-grid;
  place-items: center;
  width: 16px;
  height: 16px;
  padding: 0;
  line-height: 1;
  border: none;
  border-radius: 0;
  background: transparent;
  color: var(--muted);
  cursor: pointer;
  transition: color 0.15s ease;
}

.mljar-packages-manager-back-button {
  display: inline-grid;
  place-items: center;
  grid-auto-flow: column;
  gap: 6px;
  width: auto;
  min-width: 62px;
  height: 28px;
  padding: 0 10px;
  line-height: 1;
  border: 1px solid var(--border);
  border-radius: 8px;
  background: var(--surface);
  color: var(--muted);
  cursor: pointer;
  transition: all 0.15s ease;
  font-family: var(--mono);
  font-size: 11px;
}

.mljar-packages-manager-refresh-button:disabled,
.mljar-packages-manager-settings-button:disabled,
.mljar-packages-manager-install-button:disabled,
.mljar-packages-manager-back-button:disabled {
  opacity: 0.55;
  cursor: not-allowed;
}

.mljar-packages-manager-back-button:hover:not(:disabled),
.mljar-packages-manager-refresh-button:hover:not(:disabled),
.mljar-packages-manager-settings-button:hover:not(:disabled),
.mljar-packages-manager-install-button:hover:not(:disabled) {
  color: var(--text);
}

.mljar-packages-manager-back-button:hover:not(:disabled) {
  border-color: var(--border2);
  background: var(--surface2);
}

.mljar-packages-manager-refresh-icon,
.mljar-packages-manager-install-icon,
.mljar-packages-manager-back-icon,
.mljar-packages-manager-settings-icon,
.mljar-packages-manager-error-icon {
  display: block;
  width: 14px;
  height: 14px;
}

.mljar-packages-manager-refresh-icon svg,
.mljar-packages-manager-install-icon svg,
.mljar-packages-manager-back-icon svg,
.mljar-packages-manager-settings-icon svg,
.mljar-packages-manager-error-icon svg {
  display: block;
  width: 14px;
  height: 14px;
}

.mljar-packages-manager-delete-icon {
  display: block;
  width: 14px;
  height: 14px;
}

.mljar-packages-manager-delete-icon svg {
  display: block;
  width: 14px;
  height: 14px;
}

.mljar-packages-manager-error-icon {
  color: var(--rose);
}

.mljar-packages-manager-list-container {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-height: 0;
  overflow: hidden;
  margin-right: 8px;
}

.mljar-packages-manager-list {
  flex: 1;
  min-height: 0;
  margin: 0;
  padding: 0;
  list-style: none;
  overflow-y: auto;
  scroll-padding-bottom: 16px;
  scrollbar-width: none;
  border: 1px solid var(--border);
  border-radius: 12px;
  background: var(--surface);
}

.mljar-packages-manager-list::after {
  content: '';
  display: block;
  height: 16px;
}

.mljar-packages-manager-list-header {
  display: grid;
  grid-template-columns: 1fr 1fr 2rem;
  align-items: center;
  column-gap: 12px;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
  background: var(--surface2);
  color: var(--muted);
  font-family: var(--mono);
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.8px;
  text-transform: uppercase;
}

.mljar-packages-manager-header-name,
.mljar-packages-manager-header-version {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.mljar-packages-manager-header-version {
  text-align: left;
}

.mljar-packages-manager-header-blank {
  display: block;
}

.mljar-packages-manager-list-item {
  display: grid;
  grid-template-columns: 1fr 1fr 2rem;
  position: relative;
  align-items: center;
  min-height: 42px;
  padding: 0 12px;
  column-gap: 12px;
  border-bottom: 1px solid var(--border);
  background: var(--surface);
  animation: fadein-row 0.22s ease both;
  cursor: pointer;
}

.mljar-packages-manager-list-item:last-child {
  border-bottom: none;
}

.mljar-packages-manager-list-item::before {
  content: '';
  position: absolute;
  top: 7px;
  bottom: 7px;
  left: 0;
  width: 2px;
  border-radius: 0 2px 2px 0;
  background: var(--blue);
  opacity: 0;
  transition: opacity 0.14s ease;
}

.mljar-packages-manager-list-item:hover {
  background: var(--surface2);
}

.mljar-packages-manager-list-item:hover::before {
  opacity: 1;
}

.mljar-packages-manager-list-item.active {
  background: var(--blue-dim);
  color: var(--blue);
}

.mljar-packages-manager-package-name,
.mljar-packages-manager-package-version {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-family: var(--mono);
  font-size: 12px;
}

.mljar-packages-manager-package-name {
  color: var(--text);
  font-weight: 500;
}

.mljar-packages-manager-package-version {
  color: var(--muted);
}

.mljar-packages-manager-delete-button {
  visibility: hidden;
  display: inline-grid;
  place-items: center;
  width: 16px;
  height: 16px;
  margin-left: auto;
  border: none;
  border-radius: 4px;
  background: transparent;
  color: var(--rose);
  cursor: pointer;
  transition: all 0.15s ease;
}

.mljar-packages-manager-delete-button:hover {
  color: #9f1239;
}

.mljar-packages-manager-list-item:hover .mljar-packages-manager-delete-button {
  visibility: visible;
}

.mljar-packages-manager-error-message,
.mljar-packages-manager-list-container > p {
  margin: 8px 0 0;
  padding: 12px;
  border: 1px dashed var(--border2);
  border-radius: 10px;
  background: rgb(255 255 255 / 60%);
  color: var(--muted);
  font-family: var(--mono);
  font-size: 12px;
}

.mljar-packages-manager-spinner-container {
  display: grid;
  place-items: center;
  padding: 16px 0;
}

.mljar-packages-manager-spinner {
  width: 12px;
  height: 12px;
  border: 3px solid rgb(2 132 199 / 25%);
  border-left-color: var(--blue);
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

.mljar-packages-manager-list::-webkit-scrollbar {
  width: 0;
}

.mljar-packages-manager-list:hover::-webkit-scrollbar {
  width: 8px;
}

.mljar-packages-manager-list::-webkit-scrollbar-track,
.mljar-packages-manager-install-logs::-webkit-scrollbar-track {
  background: transparent;
}

.mljar-packages-manager-list::-webkit-scrollbar-thumb,
.mljar-packages-manager-install-logs::-webkit-scrollbar-thumb {
  border-radius: 8px;
  background: #cbd5e1;
}

.mljar-packages-manager-list:hover {
  scrollbar-width: thin;
}

.mljar-packages-manager-install-logs::-webkit-scrollbar {
  width: 8px;
}

.mljar-package-manager-modal-overlay {
  --bg: #f5f7fa;
  --surface: #fff;
  --surface2: #f0f4f8;
  --border: #e2e8f0;
  --border2: #cbd5e1;
  --text: #0f172a;
  --muted: #64748b;
  --blue: #0284c7;
  --blue-dim: #e0f2fe;
  --blue-glow: rgb(2 132 199 / 15%);
  --green: #16a34a;
  --green-dim: #dcfce7;
  --rose: #e11d48;
  --rose-dim: #ffe4e6;
  --mono: 'JetBrains Mono', 'Consolas', 'Monaco', monospace;
  --sans: 'Geist', -apple-system, blinkmacsystemfont, 'Segoe UI', sans-serif;

  position: fixed;
  inset: 0;
  z-index: 9999;
  display: flex;
  justify-content: center;
  align-items: center;
  background: rgb(15 23 42 / 44%);
  backdrop-filter: blur(2px);
}

.mljar-package-manager-content {
  position: relative;
  width: calc(100vw - 32px);
  max-width: 640px;
  max-height: calc(100vh - 48px);
  overflow: auto;
  border: 1px solid var(--border);
  border-radius: 14px;
  background: radial-gradient(circle at 8% 0%, #ecfeff 0%, #f8fafc 42%);
  box-shadow: 0 20px 40px rgb(15 23 42 / 22%);
  padding: 16px;
}

.mljar-package-manager-content h3 {
  margin: 0 28px 12px 0;
  color: var(--text);
  font-size: 17px;
  font-weight: 600;
  letter-spacing: -0.2px;
}

.mljar-package-manager-modal-close {
  position: absolute;
  top: 10px;
  right: 10px;
  display: inline-grid;
  place-items: center;
  width: 24px;
  height: 24px;
  border: 1px solid var(--border);
  border-radius: 8px;
  background: var(--surface);
  color: var(--muted);
  font-size: 12px;
  cursor: pointer;
  transition: all 0.15s ease;
}

.mljar-package-manager-modal-close:hover {
  border-color: var(--border2);
  color: var(--text);
  background: var(--surface2);
}

.mljar-packages-manager-install-form {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.mljar-packages-manager-usage-box {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 8px 0;
  border: none;
  border-radius: 10px;
  background: transparent;
  color: #475569;
  font-size: 13px;
  line-height: 1.45;
}

.mljar-packages-manager-usage-title {
  color: var(--text);
  font-weight: 600;
  font-size: 14px;
  letter-spacing: -0.1px;
}

.mljar-packages-manager-usage-description {
  color: var(--muted);
  font-size: 12px;
}

.mljar-packages-manager-usage-examples {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.mljar-packages-manager-usage-example-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
}

.mljar-packages-manager-usage-example-label {
  color: #334155;
  font-size: 12px;
  font-weight: 500;
}

.mljar-packages-manager-usage-example-code {
  display: inline-flex;
  align-items: center;
  min-height: 24px;
  padding: 0 8px;
  border: 1px solid #d9e2ec;
  border-radius: 8px;
  background: linear-gradient(180deg, #fff 0%, #f8fafc 100%);
  color: #0369a1;
  font-family: var(--mono);
  font-size: 12px;
  font-weight: 600;
}

.mljar-packages-manager-install-logs {
  max-height: 230px;
  overflow-y: auto;
  border: 1px solid var(--border);
  border-radius: 10px;
  background: #0f172a;
  color: #d1fae5;
  padding: 10px;
  font-family: var(--mono);
  font-size: 11px;
  line-height: 1.45;
  white-space: pre-wrap;
}

.mljar-packages-manager-install-form-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.mljar-packages-manager-install-actions {
  position: sticky;
  bottom: 0;
  z-index: 2;
  padding-top: 10px;
  padding-bottom: 2px;
  background: linear-gradient(
    180deg,
    rgb(248 250 252 / 0%) 0%,
    rgb(248 250 252 / 96%) 34%
  );
}

.mljar-packages-manager-result-actions {
  padding-top: 2px;
}

.mljar-packages-manager-install-submit-button,
.mljar-packages-manager-install-close-button,
.mljar-packages-manager-stop-button,
.mljar-pypi-settings-edit,
.mljar-pypi-settings-save,
.mljar-pypi-settings-reset {
  height: 34px;
  padding: 0 14px;
  border: 1px solid #d9e2ec;
  border-radius: 12px;
  box-shadow: 0 2px 6px rgb(15 23 42 / 6%);
  font-family: var(--mono);
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.01em;
  cursor: pointer;
  transition:
    border-color 0.15s ease,
    color 0.15s ease,
    background 0.15s ease,
    transform 0.15s ease,
    box-shadow 0.15s ease;
}

.mljar-packages-manager-install-submit-button,
.mljar-pypi-settings-edit,
.mljar-pypi-settings-save {
  background: linear-gradient(180deg, #14b8ff 0%, #0284c7 100%);
  border-color: #0284c7;
  box-shadow: 0 6px 14px rgb(2 132 199 / 26%);
  color: #fff;
}

.mljar-packages-manager-install-submit-button:disabled {
  background: linear-gradient(180deg, #7dd3fc 0%, #38bdf8 100%);
  border-color: #38bdf8;
  box-shadow: none;
  opacity: 0.85;
  cursor: not-allowed;
}

.mljar-packages-manager-install-submit-button:hover:not(:disabled),
.mljar-pypi-settings-edit:hover,
.mljar-pypi-settings-save:hover {
  background: linear-gradient(180deg, #1ac5ff 0%, #0a7ab2 100%);
  border-color: #0a7ab2;
  box-shadow: 0 8px 16px rgb(2 132 199 / 32%);
  transform: translateY(-1px);
}

.mljar-packages-manager-install-close-button,
.mljar-packages-manager-stop-button,
.mljar-pypi-settings-reset {
  background: linear-gradient(180deg, #fff 0%, #f8fafc 100%);
  border-color: #d9e2ec;
  color: #334155;
}

.mljar-packages-manager-install-close-button:hover,
.mljar-pypi-settings-reset:hover {
  background: linear-gradient(180deg, #f7fdff 0%, #ebf8ff 100%);
  border-color: #7dd3fc;
  color: #0f172a;
  box-shadow: 0 6px 14px rgb(14 165 233 / 12%);
  transform: translateY(-1px);
}

.mljar-packages-manager-stop-button {
  background: linear-gradient(180deg, #fff1f2 0%, #ffe4e6 100%);
  border-color: #fda4af;
  color: #be123c;
  box-shadow: 0 2px 6px rgb(190 24 93 / 10%);
}

.mljar-packages-manager-stop-button:hover {
  background: linear-gradient(180deg, #ffe4e6 0%, #fecdd3 100%);
  border-color: #fb7185;
  color: #9f1239;
  box-shadow: 0 6px 14px rgb(190 24 93 / 14%);
  transform: translateY(-1px);
}

.mljar-packages-manager-result {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 10px;
}

.mljar-packages-manager-install-message {
  margin: 0;
  font-family: var(--mono);
  font-size: 12px;
  color: var(--green);
}

.mljar-packages-manager-install-message.error {
  color: var(--rose);
}

.mljar-pypi-settings {
  margin-right: 8px;
  padding: 12px;
  border: 1px solid var(--border);
  border-radius: 12px;
  background: var(--surface);
}

.mljar-pypi-settings-title {
  margin: 0 0 10px;
  color: var(--text);
  font-size: 13px;
  font-weight: 600;
}

.mljar-pypi-settings-row {
  display: grid;
  grid-template-columns: 40px minmax(0, 1fr) auto;
  align-items: center;
  gap: 10px;
}

.mljar-pypi-settings-label {
  color: var(--muted);
  font-family: var(--mono);
  font-size: 11px;
  font-weight: 500;
}

.mljar-pypi-settings-value {
  min-width: 0;
}

.mljar-pypi-settings-code {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  padding: 8px 10px;
  border: 1px solid var(--border);
  border-radius: 9px;
  background: var(--surface2);
  color: var(--text);
  font-family: var(--mono);
  font-size: 11px;
}

.mljar-pypi-settings-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  justify-content: flex-end;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

@keyframes fadein-row {
  from {
    opacity: 0;
    transform: translateX(-4px);
  }

  to {
    opacity: 1;
    transform: translateX(0);
  }
}
`, "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAEA;EACE,aAAa;EACb,eAAe;EACf,mBAAmB;EACnB,iBAAiB;EACjB,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,mBAAmB;EACnB,iCAAiC;EACjC,gBAAgB;EAChB,oBAAoB;EACpB,eAAe;EACf,mBAAmB;EACnB,yDAAyD;EACzD,0EAA0E;;EAE1E,uEAAuE;EACvE,kBAAkB;EAClB,kBAAkB;EAClB,wBAAwB;AAC1B;;AAEA;EACE,YAAY;EACZ,gBAAgB;AAClB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,aAAa;EACb,0BAA0B;AAC5B;;AAEA;EACE,aAAa;EACb,OAAO;EACP,sBAAsB;EACtB,aAAa;AACf;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,gBAAgB;EAChB,MAAM;EACN,WAAW;EACX,iBAAiB;EACjB,kBAAkB;EAClB,iBAAiB;EACjB,uBAAuB;AACzB;;AAEA;EACE,SAAS;EACT,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,sBAAsB;EACtB,kBAAkB;AACpB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,YAAY;EACZ,kBAAkB;AACpB;;AAEA;EACE,gBAAgB;EAChB,+BAA+B;EAC/B,oBAAoB;EACpB,2BAA2B;EAC3B,mBAAmB;EACnB,wBAAwB;EACxB,eAAe;AACjB;;AAEA;EACE,gBAAgB;EAChB,SAAS;EACT,WAAW;EACX,iBAAiB;EACjB,mBAAmB;EACnB,uBAAuB;AACzB;;AAEA;;;EAGE,WAAW;EACX,YAAY;EACZ,sBAAsB;EACtB,eAAe;EACf,wCAAwC;EACxC,kBAAkB;EAClB,gCAAgC;EAChC,2BAA2B;EAC3B,iCAAiC;EACjC,wBAAwB;EACxB,eAAe;EACf,gBAAgB;AAClB;;AAEA;;;EAGE,4BAA4B;AAC9B;;AAEA;;;EAGE,aAAa;EACb,kCAAkC;EAClC,sCAAsC;AACxC;;AAEA;;EAEE,UAAU;EACV,cAAc;EACd,gCAAgC;AAClC;;AAEA;;;EAGE,oBAAoB;EACpB,mBAAmB;EACnB,WAAW;EACX,YAAY;EACZ,UAAU;EACV,cAAc;EACd,YAAY;EACZ,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;EACnB,eAAe;EACf,4BAA4B;AAC9B;;AAEA;EACE,oBAAoB;EACpB,mBAAmB;EACnB,sBAAsB;EACtB,QAAQ;EACR,WAAW;EACX,eAAe;EACf,YAAY;EACZ,eAAe;EACf,cAAc;EACd,+BAA+B;EAC/B,kBAAkB;EAClB,0BAA0B;EAC1B,mBAAmB;EACnB,eAAe;EACf,0BAA0B;EAC1B,wBAAwB;EACxB,eAAe;AACjB;;AAEA;;;;EAIE,aAAa;EACb,mBAAmB;AACrB;;AAEA;;;;EAIE,kBAAkB;AACpB;;AAEA;EACE,4BAA4B;EAC5B,2BAA2B;AAC7B;;AAEA;;;;;EAKE,cAAc;EACd,WAAW;EACX,YAAY;AACd;;AAEA;;;;;EAKE,cAAc;EACd,WAAW;EACX,YAAY;AACd;;AAEA;EACE,cAAc;EACd,WAAW;EACX,YAAY;AACd;;AAEA;EACE,cAAc;EACd,WAAW;EACX,YAAY;AACd;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,aAAa;EACb,OAAO;EACP,sBAAsB;EACtB,aAAa;EACb,gBAAgB;EAChB,iBAAiB;AACnB;;AAEA;EACE,OAAO;EACP,aAAa;EACb,SAAS;EACT,UAAU;EACV,gBAAgB;EAChB,gBAAgB;EAChB,2BAA2B;EAC3B,qBAAqB;EACrB,+BAA+B;EAC/B,mBAAmB;EACnB,0BAA0B;AAC5B;;AAEA;EACE,WAAW;EACX,cAAc;EACd,YAAY;AACd;;AAEA;EACE,aAAa;EACb,mCAAmC;EACnC,mBAAmB;EACnB,gBAAgB;EAChB,kBAAkB;EAClB,sCAAsC;EACtC,2BAA2B;EAC3B,mBAAmB;EACnB,wBAAwB;EACxB,eAAe;EACf,gBAAgB;EAChB,qBAAqB;EACrB,yBAAyB;AAC3B;;AAEA;;EAEE,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,mCAAmC;EACnC,kBAAkB;EAClB,mBAAmB;EACnB,gBAAgB;EAChB,eAAe;EACf,gBAAgB;EAChB,sCAAsC;EACtC,0BAA0B;EAC1B,qCAAqC;EACrC,eAAe;AACjB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,WAAW;EACX,kBAAkB;EAClB,QAAQ;EACR,WAAW;EACX,OAAO;EACP,UAAU;EACV,0BAA0B;EAC1B,uBAAuB;EACvB,UAAU;EACV,8BAA8B;AAChC;;AAEA;EACE,2BAA2B;AAC7B;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,2BAA2B;EAC3B,kBAAkB;AACpB;;AAEA;;EAEE,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;EACnB,wBAAwB;EACxB,eAAe;AACjB;;AAEA;EACE,kBAAkB;EAClB,gBAAgB;AAClB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,kBAAkB;EAClB,oBAAoB;EACpB,mBAAmB;EACnB,WAAW;EACX,YAAY;EACZ,iBAAiB;EACjB,YAAY;EACZ,kBAAkB;EAClB,uBAAuB;EACvB,kBAAkB;EAClB,eAAe;EACf,0BAA0B;AAC5B;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;;EAEE,eAAe;EACf,aAAa;EACb,iCAAiC;EACjC,mBAAmB;EACnB,kCAAkC;EAClC,mBAAmB;EACnB,wBAAwB;EACxB,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,eAAe;AACjB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,sCAAsC;EACtC,8BAA8B;EAC9B,kBAAkB;EAClB,kCAAkC;AACpC;;AAEA;EACE,QAAQ;AACV;;AAEA;EACE,UAAU;AACZ;;AAEA;;EAEE,uBAAuB;AACzB;;AAEA;;EAEE,kBAAkB;EAClB,mBAAmB;AACrB;;AAEA;EACE,qBAAqB;AACvB;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,aAAa;EACb,eAAe;EACf,mBAAmB;EACnB,iBAAiB;EACjB,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,mBAAmB;EACnB,iCAAiC;EACjC,gBAAgB;EAChB,oBAAoB;EACpB,eAAe;EACf,mBAAmB;EACnB,yDAAyD;EACzD,0EAA0E;;EAE1E,eAAe;EACf,QAAQ;EACR,aAAa;EACb,aAAa;EACb,uBAAuB;EACvB,mBAAmB;EACnB,+BAA+B;EAC/B,0BAA0B;AAC5B;;AAEA;EACE,kBAAkB;EAClB,yBAAyB;EACzB,gBAAgB;EAChB,8BAA8B;EAC9B,cAAc;EACd,+BAA+B;EAC/B,mBAAmB;EACnB,qEAAqE;EACrE,2CAA2C;EAC3C,aAAa;AACf;;AAEA;EACE,qBAAqB;EACrB,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,sBAAsB;AACxB;;AAEA;EACE,kBAAkB;EAClB,SAAS;EACT,WAAW;EACX,oBAAoB;EACpB,mBAAmB;EACnB,WAAW;EACX,YAAY;EACZ,+BAA+B;EAC/B,kBAAkB;EAClB,0BAA0B;EAC1B,mBAAmB;EACnB,eAAe;EACf,eAAe;EACf,0BAA0B;AAC5B;;AAEA;EACE,4BAA4B;EAC5B,kBAAkB;EAClB,2BAA2B;AAC7B;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,SAAS;AACX;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,cAAc;EACd,YAAY;EACZ,mBAAmB;EACnB,uBAAuB;EACvB,cAAc;EACd,eAAe;EACf,iBAAiB;AACnB;;AAEA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,eAAe;EACf,sBAAsB;AACxB;;AAEA;EACE,mBAAmB;EACnB,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,eAAe;EACf,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,cAAc;EACd,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,oBAAoB;EACpB,mBAAmB;EACnB,gBAAgB;EAChB,cAAc;EACd,yBAAyB;EACzB,kBAAkB;EAClB,0DAA0D;EAC1D,cAAc;EACd,wBAAwB;EACxB,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,iBAAiB;EACjB,gBAAgB;EAChB,+BAA+B;EAC/B,mBAAmB;EACnB,mBAAmB;EACnB,cAAc;EACd,aAAa;EACb,wBAAwB;EACxB,eAAe;EACf,iBAAiB;EACjB,qBAAqB;AACvB;;AAEA;EACE,aAAa;EACb,eAAe;EACf,SAAS;AACX;;AAEA;EACE,gBAAgB;EAChB,SAAS;EACT,UAAU;EACV,iBAAiB;EACjB,mBAAmB;EACnB;;;;GAIC;AACH;;AAEA;EACE,gBAAgB;AAClB;;AAEA;;;;;;EAME,YAAY;EACZ,eAAe;EACf,yBAAyB;EACzB,mBAAmB;EACnB,wCAAwC;EACxC,wBAAwB;EACxB,eAAe;EACf,gBAAgB;EAChB,sBAAsB;EACtB,eAAe;EACf;;;;;yBAKuB;AACzB;;AAEA;;;EAGE,6DAA6D;EAC7D,qBAAqB;EACrB,2CAA2C;EAC3C,WAAW;AACb;;AAEA;EACE,6DAA6D;EAC7D,qBAAqB;EACrB,gBAAgB;EAChB,aAAa;EACb,mBAAmB;AACrB;;AAEA;;;EAGE,6DAA6D;EAC7D,qBAAqB;EACrB,2CAA2C;EAC3C,2BAA2B;AAC7B;;AAEA;;;EAGE,0DAA0D;EAC1D,qBAAqB;EACrB,cAAc;AAChB;;AAEA;;EAEE,6DAA6D;EAC7D,qBAAqB;EACrB,cAAc;EACd,4CAA4C;EAC5C,2BAA2B;AAC7B;;AAEA;EACE,6DAA6D;EAC7D,qBAAqB;EACrB,cAAc;EACd,0CAA0C;AAC5C;;AAEA;EACE,6DAA6D;EAC7D,qBAAqB;EACrB,cAAc;EACd,2CAA2C;EAC3C,2BAA2B;AAC7B;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,SAAS;AACX;;AAEA;EACE,SAAS;EACT,wBAAwB;EACxB,eAAe;EACf,mBAAmB;AACrB;;AAEA;EACE,kBAAkB;AACpB;;AAEA;EACE,iBAAiB;EACjB,aAAa;EACb,+BAA+B;EAC/B,mBAAmB;EACnB,0BAA0B;AAC5B;;AAEA;EACE,gBAAgB;EAChB,kBAAkB;EAClB,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,+CAA+C;EAC/C,mBAAmB;EACnB,SAAS;AACX;;AAEA;EACE,mBAAmB;EACnB,wBAAwB;EACxB,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,cAAc;EACd,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;EACnB,iBAAiB;EACjB,+BAA+B;EAC/B,kBAAkB;EAClB,2BAA2B;EAC3B,kBAAkB;EAClB,wBAAwB;EACxB,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,eAAe;EACf,QAAQ;EACR,yBAAyB;AAC3B;;AAEA;EACE;IACE,yBAAyB;EAC3B;AACF;;AAEA;EACE;IACE,UAAU;IACV,2BAA2B;EAC7B;;EAEA;IACE,UAAU;IACV,wBAAwB;EAC1B;AACF","sourcesContent":["@import url('https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&display=swap');\n\n.mljar-packages-manager-sidebar-widget {\n  --bg: #f5f7fa;\n  --surface: #fff;\n  --surface2: #f0f4f8;\n  --border: #e2e8f0;\n  --border2: #cbd5e1;\n  --text: #0f172a;\n  --muted: #64748b;\n  --blue: #0284c7;\n  --blue-dim: #e0f2fe;\n  --blue-glow: rgb(2 132 199 / 15%);\n  --green: #16a34a;\n  --green-dim: #dcfce7;\n  --rose: #e11d48;\n  --rose-dim: #ffe4e6;\n  --mono: 'JetBrains Mono', 'Consolas', 'Monaco', monospace;\n  --sans: 'Geist', -apple-system, blinkmacsystemfont, 'Segoe UI', sans-serif;\n\n  background: radial-gradient(circle at 8% 0%, #ecfeff 0%, var(--bg) 40%);\n  color: var(--text);\n  padding: 14px 10px;\n  font-family: var(--sans);\n}\n\n.mljar-packages-manager-sidebar-container {\n  height: 100%;\n  overflow: hidden;\n}\n\n.mljar-packages-manager-sidebar-container::-webkit-scrollbar {\n  display: none;\n}\n\n.mljar-packages-manager-container {\n  display: flex;\n  flex-direction: column;\n  min-height: 0;\n  height: calc(100vh - 28px);\n}\n\n.mljar-packages-manager-home {\n  display: flex;\n  flex: 1;\n  flex-direction: column;\n  min-height: 0;\n}\n\n.mljar-packages-manager-header-container {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  position: sticky;\n  top: 0;\n  z-index: 20;\n  margin-right: 8px;\n  margin-bottom: 8px;\n  padding: 0 0 12px;\n  background: transparent;\n}\n\n.mljar-packages-manager-header {\n  margin: 0;\n  margin-right: auto;\n  font-size: 14px;\n  font-weight: 600;\n  letter-spacing: -0.1px;\n  color: var(--text);\n}\n\n.mljar-packages-manager-header-title-wrap {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  min-width: 0;\n  margin-right: auto;\n}\n\n.mljar-packages-manager-count-badge {\n  padding: 2px 8px;\n  border: 1px solid var(--border);\n  border-radius: 999px;\n  background: var(--surface2);\n  color: var(--muted);\n  font-family: var(--mono);\n  font-size: 10px;\n}\n\n.mljar-packages-manager-search-bar-container {\n  position: sticky;\n  top: 44px;\n  z-index: 11;\n  margin-right: 8px;\n  margin-bottom: 10px;\n  background: transparent;\n}\n\n.mljar-packages-manager-install-input,\n.mljar-packages-manager-search-bar-input,\n.mljar-pypi-settings-input {\n  width: 100%;\n  height: 36px;\n  box-sizing: border-box;\n  padding: 0 12px;\n  border: 1px solid var(--border, #dbe3ec);\n  border-radius: 9px;\n  background: var(--surface, #fff);\n  color: var(--text, #0f172a);\n  caret-color: var(--text, #0f172a);\n  font-family: var(--mono);\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.mljar-packages-manager-install-input::placeholder,\n.mljar-packages-manager-search-bar-input::placeholder,\n.mljar-pypi-settings-input::placeholder {\n  color: var(--muted, #64748b);\n}\n\n.mljar-packages-manager-install-input:focus,\n.mljar-packages-manager-search-bar-input:focus,\n.mljar-pypi-settings-input:focus {\n  outline: none;\n  border-color: rgb(2 132 199 / 40%);\n  box-shadow: 0 0 0 3px var(--blue-glow);\n}\n\n.mljar-packages-manager-install-input:disabled,\n.mljar-pypi-settings-input:disabled {\n  opacity: 1;\n  color: #334155;\n  -webkit-text-fill-color: #334155;\n}\n\n.mljar-packages-manager-install-button,\n.mljar-packages-manager-refresh-button,\n.mljar-packages-manager-settings-button {\n  display: inline-grid;\n  place-items: center;\n  width: 16px;\n  height: 16px;\n  padding: 0;\n  line-height: 1;\n  border: none;\n  border-radius: 0;\n  background: transparent;\n  color: var(--muted);\n  cursor: pointer;\n  transition: color 0.15s ease;\n}\n\n.mljar-packages-manager-back-button {\n  display: inline-grid;\n  place-items: center;\n  grid-auto-flow: column;\n  gap: 6px;\n  width: auto;\n  min-width: 62px;\n  height: 28px;\n  padding: 0 10px;\n  line-height: 1;\n  border: 1px solid var(--border);\n  border-radius: 8px;\n  background: var(--surface);\n  color: var(--muted);\n  cursor: pointer;\n  transition: all 0.15s ease;\n  font-family: var(--mono);\n  font-size: 11px;\n}\n\n.mljar-packages-manager-refresh-button:disabled,\n.mljar-packages-manager-settings-button:disabled,\n.mljar-packages-manager-install-button:disabled,\n.mljar-packages-manager-back-button:disabled {\n  opacity: 0.55;\n  cursor: not-allowed;\n}\n\n.mljar-packages-manager-back-button:hover:not(:disabled),\n.mljar-packages-manager-refresh-button:hover:not(:disabled),\n.mljar-packages-manager-settings-button:hover:not(:disabled),\n.mljar-packages-manager-install-button:hover:not(:disabled) {\n  color: var(--text);\n}\n\n.mljar-packages-manager-back-button:hover:not(:disabled) {\n  border-color: var(--border2);\n  background: var(--surface2);\n}\n\n.mljar-packages-manager-refresh-icon,\n.mljar-packages-manager-install-icon,\n.mljar-packages-manager-back-icon,\n.mljar-packages-manager-settings-icon,\n.mljar-packages-manager-error-icon {\n  display: block;\n  width: 14px;\n  height: 14px;\n}\n\n.mljar-packages-manager-refresh-icon svg,\n.mljar-packages-manager-install-icon svg,\n.mljar-packages-manager-back-icon svg,\n.mljar-packages-manager-settings-icon svg,\n.mljar-packages-manager-error-icon svg {\n  display: block;\n  width: 14px;\n  height: 14px;\n}\n\n.mljar-packages-manager-delete-icon {\n  display: block;\n  width: 14px;\n  height: 14px;\n}\n\n.mljar-packages-manager-delete-icon svg {\n  display: block;\n  width: 14px;\n  height: 14px;\n}\n\n.mljar-packages-manager-error-icon {\n  color: var(--rose);\n}\n\n.mljar-packages-manager-list-container {\n  display: flex;\n  flex: 1;\n  flex-direction: column;\n  min-height: 0;\n  overflow: hidden;\n  margin-right: 8px;\n}\n\n.mljar-packages-manager-list {\n  flex: 1;\n  min-height: 0;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  overflow-y: auto;\n  scroll-padding-bottom: 16px;\n  scrollbar-width: none;\n  border: 1px solid var(--border);\n  border-radius: 12px;\n  background: var(--surface);\n}\n\n.mljar-packages-manager-list::after {\n  content: '';\n  display: block;\n  height: 16px;\n}\n\n.mljar-packages-manager-list-header {\n  display: grid;\n  grid-template-columns: 1fr 1fr 2rem;\n  align-items: center;\n  column-gap: 12px;\n  padding: 10px 12px;\n  border-bottom: 1px solid var(--border);\n  background: var(--surface2);\n  color: var(--muted);\n  font-family: var(--mono);\n  font-size: 10px;\n  font-weight: 600;\n  letter-spacing: 0.8px;\n  text-transform: uppercase;\n}\n\n.mljar-packages-manager-header-name,\n.mljar-packages-manager-header-version {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.mljar-packages-manager-header-version {\n  text-align: left;\n}\n\n.mljar-packages-manager-header-blank {\n  display: block;\n}\n\n.mljar-packages-manager-list-item {\n  display: grid;\n  grid-template-columns: 1fr 1fr 2rem;\n  position: relative;\n  align-items: center;\n  min-height: 42px;\n  padding: 0 12px;\n  column-gap: 12px;\n  border-bottom: 1px solid var(--border);\n  background: var(--surface);\n  animation: fadein-row 0.22s ease both;\n  cursor: pointer;\n}\n\n.mljar-packages-manager-list-item:last-child {\n  border-bottom: none;\n}\n\n.mljar-packages-manager-list-item::before {\n  content: '';\n  position: absolute;\n  top: 7px;\n  bottom: 7px;\n  left: 0;\n  width: 2px;\n  border-radius: 0 2px 2px 0;\n  background: var(--blue);\n  opacity: 0;\n  transition: opacity 0.14s ease;\n}\n\n.mljar-packages-manager-list-item:hover {\n  background: var(--surface2);\n}\n\n.mljar-packages-manager-list-item:hover::before {\n  opacity: 1;\n}\n\n.mljar-packages-manager-list-item.active {\n  background: var(--blue-dim);\n  color: var(--blue);\n}\n\n.mljar-packages-manager-package-name,\n.mljar-packages-manager-package-version {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-family: var(--mono);\n  font-size: 12px;\n}\n\n.mljar-packages-manager-package-name {\n  color: var(--text);\n  font-weight: 500;\n}\n\n.mljar-packages-manager-package-version {\n  color: var(--muted);\n}\n\n.mljar-packages-manager-delete-button {\n  visibility: hidden;\n  display: inline-grid;\n  place-items: center;\n  width: 16px;\n  height: 16px;\n  margin-left: auto;\n  border: none;\n  border-radius: 4px;\n  background: transparent;\n  color: var(--rose);\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n\n.mljar-packages-manager-delete-button:hover {\n  color: #9f1239;\n}\n\n.mljar-packages-manager-list-item:hover .mljar-packages-manager-delete-button {\n  visibility: visible;\n}\n\n.mljar-packages-manager-error-message,\n.mljar-packages-manager-list-container > p {\n  margin: 8px 0 0;\n  padding: 12px;\n  border: 1px dashed var(--border2);\n  border-radius: 10px;\n  background: rgb(255 255 255 / 60%);\n  color: var(--muted);\n  font-family: var(--mono);\n  font-size: 12px;\n}\n\n.mljar-packages-manager-spinner-container {\n  display: grid;\n  place-items: center;\n  padding: 16px 0;\n}\n\n.mljar-packages-manager-spinner {\n  width: 12px;\n  height: 12px;\n  border: 3px solid rgb(2 132 199 / 25%);\n  border-left-color: var(--blue);\n  border-radius: 50%;\n  animation: spin 1s linear infinite;\n}\n\n.mljar-packages-manager-list::-webkit-scrollbar {\n  width: 0;\n}\n\n.mljar-packages-manager-list:hover::-webkit-scrollbar {\n  width: 8px;\n}\n\n.mljar-packages-manager-list::-webkit-scrollbar-track,\n.mljar-packages-manager-install-logs::-webkit-scrollbar-track {\n  background: transparent;\n}\n\n.mljar-packages-manager-list::-webkit-scrollbar-thumb,\n.mljar-packages-manager-install-logs::-webkit-scrollbar-thumb {\n  border-radius: 8px;\n  background: #cbd5e1;\n}\n\n.mljar-packages-manager-list:hover {\n  scrollbar-width: thin;\n}\n\n.mljar-packages-manager-install-logs::-webkit-scrollbar {\n  width: 8px;\n}\n\n.mljar-package-manager-modal-overlay {\n  --bg: #f5f7fa;\n  --surface: #fff;\n  --surface2: #f0f4f8;\n  --border: #e2e8f0;\n  --border2: #cbd5e1;\n  --text: #0f172a;\n  --muted: #64748b;\n  --blue: #0284c7;\n  --blue-dim: #e0f2fe;\n  --blue-glow: rgb(2 132 199 / 15%);\n  --green: #16a34a;\n  --green-dim: #dcfce7;\n  --rose: #e11d48;\n  --rose-dim: #ffe4e6;\n  --mono: 'JetBrains Mono', 'Consolas', 'Monaco', monospace;\n  --sans: 'Geist', -apple-system, blinkmacsystemfont, 'Segoe UI', sans-serif;\n\n  position: fixed;\n  inset: 0;\n  z-index: 9999;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  background: rgb(15 23 42 / 44%);\n  backdrop-filter: blur(2px);\n}\n\n.mljar-package-manager-content {\n  position: relative;\n  width: calc(100vw - 32px);\n  max-width: 640px;\n  max-height: calc(100vh - 48px);\n  overflow: auto;\n  border: 1px solid var(--border);\n  border-radius: 14px;\n  background: radial-gradient(circle at 8% 0%, #ecfeff 0%, #f8fafc 42%);\n  box-shadow: 0 20px 40px rgb(15 23 42 / 22%);\n  padding: 16px;\n}\n\n.mljar-package-manager-content h3 {\n  margin: 0 28px 12px 0;\n  color: var(--text);\n  font-size: 17px;\n  font-weight: 600;\n  letter-spacing: -0.2px;\n}\n\n.mljar-package-manager-modal-close {\n  position: absolute;\n  top: 10px;\n  right: 10px;\n  display: inline-grid;\n  place-items: center;\n  width: 24px;\n  height: 24px;\n  border: 1px solid var(--border);\n  border-radius: 8px;\n  background: var(--surface);\n  color: var(--muted);\n  font-size: 12px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n\n.mljar-package-manager-modal-close:hover {\n  border-color: var(--border2);\n  color: var(--text);\n  background: var(--surface2);\n}\n\n.mljar-packages-manager-install-form {\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n\n.mljar-packages-manager-usage-box {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n  padding: 8px 0;\n  border: none;\n  border-radius: 10px;\n  background: transparent;\n  color: #475569;\n  font-size: 13px;\n  line-height: 1.45;\n}\n\n.mljar-packages-manager-usage-title {\n  color: var(--text);\n  font-weight: 600;\n  font-size: 14px;\n  letter-spacing: -0.1px;\n}\n\n.mljar-packages-manager-usage-description {\n  color: var(--muted);\n  font-size: 12px;\n}\n\n.mljar-packages-manager-usage-examples {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n\n.mljar-packages-manager-usage-example-row {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  gap: 6px;\n}\n\n.mljar-packages-manager-usage-example-label {\n  color: #334155;\n  font-size: 12px;\n  font-weight: 500;\n}\n\n.mljar-packages-manager-usage-example-code {\n  display: inline-flex;\n  align-items: center;\n  min-height: 24px;\n  padding: 0 8px;\n  border: 1px solid #d9e2ec;\n  border-radius: 8px;\n  background: linear-gradient(180deg, #fff 0%, #f8fafc 100%);\n  color: #0369a1;\n  font-family: var(--mono);\n  font-size: 12px;\n  font-weight: 600;\n}\n\n.mljar-packages-manager-install-logs {\n  max-height: 230px;\n  overflow-y: auto;\n  border: 1px solid var(--border);\n  border-radius: 10px;\n  background: #0f172a;\n  color: #d1fae5;\n  padding: 10px;\n  font-family: var(--mono);\n  font-size: 11px;\n  line-height: 1.45;\n  white-space: pre-wrap;\n}\n\n.mljar-packages-manager-install-form-buttons {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 10px;\n}\n\n.mljar-packages-manager-install-actions {\n  position: sticky;\n  bottom: 0;\n  z-index: 2;\n  padding-top: 10px;\n  padding-bottom: 2px;\n  background: linear-gradient(\n    180deg,\n    rgb(248 250 252 / 0%) 0%,\n    rgb(248 250 252 / 96%) 34%\n  );\n}\n\n.mljar-packages-manager-result-actions {\n  padding-top: 2px;\n}\n\n.mljar-packages-manager-install-submit-button,\n.mljar-packages-manager-install-close-button,\n.mljar-packages-manager-stop-button,\n.mljar-pypi-settings-edit,\n.mljar-pypi-settings-save,\n.mljar-pypi-settings-reset {\n  height: 34px;\n  padding: 0 14px;\n  border: 1px solid #d9e2ec;\n  border-radius: 12px;\n  box-shadow: 0 2px 6px rgb(15 23 42 / 6%);\n  font-family: var(--mono);\n  font-size: 11px;\n  font-weight: 600;\n  letter-spacing: 0.01em;\n  cursor: pointer;\n  transition:\n    border-color 0.15s ease,\n    color 0.15s ease,\n    background 0.15s ease,\n    transform 0.15s ease,\n    box-shadow 0.15s ease;\n}\n\n.mljar-packages-manager-install-submit-button,\n.mljar-pypi-settings-edit,\n.mljar-pypi-settings-save {\n  background: linear-gradient(180deg, #14b8ff 0%, #0284c7 100%);\n  border-color: #0284c7;\n  box-shadow: 0 6px 14px rgb(2 132 199 / 26%);\n  color: #fff;\n}\n\n.mljar-packages-manager-install-submit-button:disabled {\n  background: linear-gradient(180deg, #7dd3fc 0%, #38bdf8 100%);\n  border-color: #38bdf8;\n  box-shadow: none;\n  opacity: 0.85;\n  cursor: not-allowed;\n}\n\n.mljar-packages-manager-install-submit-button:hover:not(:disabled),\n.mljar-pypi-settings-edit:hover,\n.mljar-pypi-settings-save:hover {\n  background: linear-gradient(180deg, #1ac5ff 0%, #0a7ab2 100%);\n  border-color: #0a7ab2;\n  box-shadow: 0 8px 16px rgb(2 132 199 / 32%);\n  transform: translateY(-1px);\n}\n\n.mljar-packages-manager-install-close-button,\n.mljar-packages-manager-stop-button,\n.mljar-pypi-settings-reset {\n  background: linear-gradient(180deg, #fff 0%, #f8fafc 100%);\n  border-color: #d9e2ec;\n  color: #334155;\n}\n\n.mljar-packages-manager-install-close-button:hover,\n.mljar-pypi-settings-reset:hover {\n  background: linear-gradient(180deg, #f7fdff 0%, #ebf8ff 100%);\n  border-color: #7dd3fc;\n  color: #0f172a;\n  box-shadow: 0 6px 14px rgb(14 165 233 / 12%);\n  transform: translateY(-1px);\n}\n\n.mljar-packages-manager-stop-button {\n  background: linear-gradient(180deg, #fff1f2 0%, #ffe4e6 100%);\n  border-color: #fda4af;\n  color: #be123c;\n  box-shadow: 0 2px 6px rgb(190 24 93 / 10%);\n}\n\n.mljar-packages-manager-stop-button:hover {\n  background: linear-gradient(180deg, #ffe4e6 0%, #fecdd3 100%);\n  border-color: #fb7185;\n  color: #9f1239;\n  box-shadow: 0 6px 14px rgb(190 24 93 / 14%);\n  transform: translateY(-1px);\n}\n\n.mljar-packages-manager-result {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  gap: 10px;\n}\n\n.mljar-packages-manager-install-message {\n  margin: 0;\n  font-family: var(--mono);\n  font-size: 12px;\n  color: var(--green);\n}\n\n.mljar-packages-manager-install-message.error {\n  color: var(--rose);\n}\n\n.mljar-pypi-settings {\n  margin-right: 8px;\n  padding: 12px;\n  border: 1px solid var(--border);\n  border-radius: 12px;\n  background: var(--surface);\n}\n\n.mljar-pypi-settings-title {\n  margin: 0 0 10px;\n  color: var(--text);\n  font-size: 13px;\n  font-weight: 600;\n}\n\n.mljar-pypi-settings-row {\n  display: grid;\n  grid-template-columns: 40px minmax(0, 1fr) auto;\n  align-items: center;\n  gap: 10px;\n}\n\n.mljar-pypi-settings-label {\n  color: var(--muted);\n  font-family: var(--mono);\n  font-size: 11px;\n  font-weight: 500;\n}\n\n.mljar-pypi-settings-value {\n  min-width: 0;\n}\n\n.mljar-pypi-settings-code {\n  display: block;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  padding: 8px 10px;\n  border: 1px solid var(--border);\n  border-radius: 9px;\n  background: var(--surface2);\n  color: var(--text);\n  font-family: var(--mono);\n  font-size: 11px;\n}\n\n.mljar-pypi-settings-actions {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n  justify-content: flex-end;\n}\n\n@keyframes spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n\n@keyframes fadein-row {\n  from {\n    opacity: 0;\n    transform: translateX(-4px);\n  }\n\n  to {\n    opacity: 1;\n    transform: translateX(0);\n  }\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./style/base.css"
/*!************************!*\
  !*** ./style/base.css ***!
  \************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }

}]);
//# sourceMappingURL=style_index_js.4d0cbbc9c21fcccd86c9.js.map