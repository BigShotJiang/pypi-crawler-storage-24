//! Envelope-approximation Hamiltonian extraction driver.
//!
//! This driver orchestrates the complete pipeline for extracting EA Hamiltonian
//! ingredients at a given (R, k₀) point:
//!
//! 1. Build dielectric and (optionally) dielectric derivatives
//! 2. Construct ThetaOperator at k₀
//! 3. Solve the eigenproblem (LOBPCG)
//! 4. Extract EA ingredients (velocity, mass tensor, Born–Huang, etc.)
//!
//! # Example
//!
//! ```ignore
//! use blaze2d_core::drivers::ea_extraction::{run, EAJob};
//!
//! let job = EAJob {
//!     geom: geometry,
//!     grid: Grid2D::new(32, 32, 1.0, 1.0),
//!     pol: Polarization::TE,
//!     k0: [0.0, 0.0],
//!     registry: [0.0, 0.0],
//!     ea_config: EAExtractionConfig::default(),
//!     eigensolver: EigensolverConfig::default(),
//!     dielectric: DielectricOptions::default(),
//!     fd_step: 0.001,
//!     atom_index: 0,
//!     compute_dielectric_derivatives: true,
//! };
//! let result = run(backend, &job);
//! ```

use crate::backend::SpectralBackend;
use crate::dielectric::{Dielectric2D, DielectricDerivative, DielectricOptions};
use crate::ea_extraction::{EAExtractionConfig, EAExtractor, EAIngredients};
use crate::eigensolver::{Eigensolver, EigensolverConfig};
use crate::field::Field2D;
use crate::geometry::Geometry2D;
use crate::grid::Grid2D;
use crate::operators::maxwell::ThetaOperator;
use crate::polarization::Polarization;
use crate::preconditioners::OperatorPreconditioner;

// ============================================================================
// Job Configuration
// ============================================================================

/// Full job specification for EA Hamiltonian extraction at one (R, k₀) point.
#[derive(Debug, Clone)]
pub struct EAJob {
    /// The 2D photonic crystal geometry (with atoms at the registry position).
    pub geom: Geometry2D,
    /// Computational grid.
    pub grid: Grid2D,
    /// Polarization mode.
    pub pol: Polarization,
    /// Carrier momentum k₀ in Cartesian reciprocal-space units (2π/a).
    pub k0: [f64; 2],
    /// Registry point (fractional atom shift coordinates) — metadata only.
    /// The geometry should already have atoms at the correct positions.
    pub registry: [f64; 2],
    /// EA extraction configuration (n_retained, n_remote, what to compute).
    pub ea_config: EAExtractionConfig,
    /// Eigensolver configuration.
    pub eigensolver: EigensolverConfig,
    /// Dielectric construction options.
    pub dielectric: DielectricOptions,
    /// Finite-difference step for dielectric derivatives (fractional coords).
    pub fd_step: f64,
    /// Which atom to differentiate w.r.t. for R-derivatives.
    pub atom_index: usize,
    /// Whether to compute dielectric derivatives (needed for R-derivatives and Born–Huang).
    pub compute_dielectric_derivatives: bool,
}

impl EAJob {
    /// Total number of bands to solve for.
    pub fn n_total_bands(&self) -> usize {
        self.ea_config.n_retained + self.ea_config.n_remote
    }
}

// ============================================================================
// Result
// ============================================================================

/// Result of an EA extraction run.
#[derive(Debug, Clone)]
pub struct EAResult {
    /// The extracted EA Hamiltonian ingredients.
    pub ingredients: EAIngredients,
    /// Total wall-clock time for the eigensolver (seconds).
    pub solve_time_seconds: f64,
    /// Total wall-clock time for the extraction (seconds).
    pub extract_time_seconds: f64,
}

// ============================================================================
// Driver Functions
// ============================================================================

/// Run the full EA extraction pipeline at a single (R, k₀) point.
///
/// This is the main entry point. It:
/// 1. Builds the dielectric from geometry
/// 2. Optionally computes dielectric derivatives via FD
/// 3. Constructs ThetaOperator at k₀
/// 4. Solves for eigenvalues/eigenvectors
/// 5. Extracts all requested EA ingredients
pub fn run<B: SpectralBackend>(backend: B, job: &EAJob) -> EAResult {
    run_with_reference(backend, job, None)
}

/// Run the EA extraction with optional reference eigenvectors for overlap matrix.
///
/// The reference eigenvectors are from a neighboring R-point, used to build
/// the gauge-transport overlap matrix S_{mn} = ⟨uₘ(R)|uₙ(R')⟩.
pub fn run_with_reference<B: SpectralBackend>(
    backend: B,
    job: &EAJob,
    reference_eigvecs: Option<&[Field2D]>,
) -> EAResult {
    let n_total = job.n_total_bands();

    // 1. Build dielectric
    let dielectric = Dielectric2D::from_geometry(&job.geom, job.grid, &job.dielectric);

    // 2. Compute dielectric derivatives (if requested)
    let diel_derivs = if job.compute_dielectric_derivatives {
        Some([
            DielectricDerivative::from_finite_difference(
                &job.geom,
                job.grid,
                &job.dielectric,
                job.atom_index,
                0, // x-direction
                job.fd_step,
            ),
            DielectricDerivative::from_finite_difference(
                &job.geom,
                job.grid,
                &job.dielectric,
                job.atom_index,
                1, // y-direction
                job.fd_step,
            ),
        ])
    } else {
        None
    };

    // 3. Construct operator at k₀
    let mut theta = ThetaOperator::new(backend, dielectric, job.pol, job.k0);

    // 4. Build preconditioner and solve
    let mut preconditioner: Box<dyn OperatorPreconditioner<B>> =
        Box::new(theta.build_homogeneous_preconditioner_adaptive());

    let mut eigensolver_config = job.eigensolver.clone();
    // Ensure we solve for enough bands
    if eigensolver_config.n_bands < n_total {
        eigensolver_config.n_bands = n_total;
    }

    let solve_start = std::time::Instant::now();
    let mut solver = Eigensolver::new(
        &mut theta,
        eigensolver_config,
        Some(&mut *preconditioner as &mut dyn OperatorPreconditioner<B>),
        None,
    );
    let result = solver.solve();
    let eigenvectors = solver.all_eigenvectors();
    let solve_time = solve_start.elapsed().as_secs_f64();

    let n_iterations = result.iterations;
    let converged = result.converged;
    let eigenvalues = result.eigenvalues;

    // 5. Extract EA ingredients
    let extract_start = std::time::Instant::now();
    let mut extractor = EAExtractor::new(
        &mut theta,
        &eigenvectors,
        &eigenvalues,
        job.ea_config.clone(),
    );

    let ingredients = extractor.extract(
        job.k0,
        job.registry,
        diel_derivs.as_ref(),
        reference_eigvecs,
        n_iterations,
        converged,
    );
    let extract_time = extract_start.elapsed().as_secs_f64();

    EAResult {
        ingredients,
        solve_time_seconds: solve_time,
        extract_time_seconds: extract_time,
    }
}

/// Run EA extraction with warm-start from previous eigenvectors.
///
/// This is useful for R-point sweeps where adjacent R-points have similar
/// eigenpairs, enabling faster convergence.
pub fn run_with_warmstart<B: SpectralBackend>(
    backend: B,
    job: &EAJob,
    warmstart: &[Field2D],
    reference_eigvecs: Option<&[Field2D]>,
) -> EAResult {
    let n_total = job.n_total_bands();

    let dielectric = Dielectric2D::from_geometry(&job.geom, job.grid, &job.dielectric);

    let diel_derivs = if job.compute_dielectric_derivatives {
        Some([
            DielectricDerivative::from_finite_difference(
                &job.geom,
                job.grid,
                &job.dielectric,
                job.atom_index,
                0,
                job.fd_step,
            ),
            DielectricDerivative::from_finite_difference(
                &job.geom,
                job.grid,
                &job.dielectric,
                job.atom_index,
                1,
                job.fd_step,
            ),
        ])
    } else {
        None
    };

    let mut theta = ThetaOperator::new(backend, dielectric, job.pol, job.k0);

    let mut preconditioner: Box<dyn OperatorPreconditioner<B>> =
        Box::new(theta.build_homogeneous_preconditioner_adaptive());

    let mut eigensolver_config = job.eigensolver.clone();
    if eigensolver_config.n_bands < n_total {
        eigensolver_config.n_bands = n_total;
    }

    let solve_start = std::time::Instant::now();
    let mut solver = Eigensolver::new(
        &mut theta,
        eigensolver_config,
        Some(&mut *preconditioner as &mut dyn OperatorPreconditioner<B>),
        Some(warmstart),
    );
    let result = solver.solve();
    let eigenvectors = solver.all_eigenvectors();
    let solve_time = solve_start.elapsed().as_secs_f64();

    let n_iterations = result.iterations;
    let converged = result.converged;
    let eigenvalues = result.eigenvalues;

    let extract_start = std::time::Instant::now();
    let mut extractor = EAExtractor::new(
        &mut theta,
        &eigenvectors,
        &eigenvalues,
        job.ea_config.clone(),
    );

    let ingredients = extractor.extract(
        job.k0,
        job.registry,
        diel_derivs.as_ref(),
        reference_eigvecs,
        n_iterations,
        converged,
    );
    let extract_time = extract_start.elapsed().as_secs_f64();

    EAResult {
        ingredients,
        solve_time_seconds: solve_time,
        extract_time_seconds: extract_time,
    }
}

// ============================================================================
// k-Stencil Sweep
// ============================================================================

/// Result of a k-stencil sweep.
#[derive(Debug, Clone)]
pub struct KStencilResult {
    /// EA result at the center k₀.
    pub center: EAResult,
    /// Center eigenvectors (for downstream warm-starting, e.g., at neighboring R-points).
    pub center_eigenvectors: Vec<Field2D>,
    /// EA results at each stencil neighbor point.
    pub neighbors: Vec<EAResult>,
    /// Stencil k-points (absolute, not relative). Center is NOT included.
    pub neighbor_k_points: Vec<[f64; 2]>,
}

/// Run EA extraction on a k-stencil centered at k₀.
///
/// The stencil consists of `n_points` per axis (must be odd, ≥ 1), spaced evenly
/// within `[-delta_k, +delta_k]` along each axis. `n_points=1` means center only.
/// `n_points=3` → center + 8 neighbors (3×3 grid minus center), etc.
///
/// **Optimizations:**
/// - The dielectric (and its derivatives) are built once and reused.
/// - The center k₀ is solved first (cold start), then all stencil neighbors
///   are warm-started from the center eigenvectors.
///
/// # Arguments
///
/// * `backend` - Spectral backend (will be cloned for each k-point)
/// * `job` - Base EAJob. The `k0` field is used as the stencil center.
/// * `n_points` - Number of stencil points per axis (odd, ≥ 1). Total stencil
///   neighbors = n_points² − 1.
/// * `delta_k` - Maximum stencil displacement from center in each direction.
///   Units: same as k₀ (Cartesian reciprocal-space, 2π/a).
pub fn run_k_stencil<B: SpectralBackend + Clone>(
    backend: B,
    job: &EAJob,
    n_points: usize,
    delta_k: f64,
) -> KStencilResult {
    assert!(n_points >= 1 && n_points % 2 == 1, "n_points must be odd and >= 1");

    let n_total = job.n_total_bands();

    // -- 1. Build dielectric and derivatives ONCE --
    let dielectric = Dielectric2D::from_geometry(&job.geom, job.grid, &job.dielectric);

    let diel_derivs = if job.compute_dielectric_derivatives {
        Some([
            DielectricDerivative::from_finite_difference(
                &job.geom,
                job.grid,
                &job.dielectric,
                job.atom_index,
                0,
                job.fd_step,
            ),
            DielectricDerivative::from_finite_difference(
                &job.geom,
                job.grid,
                &job.dielectric,
                job.atom_index,
                1,
                job.fd_step,
            ),
        ])
    } else {
        None
    };

    // -- 2. Solve at center k₀ (cold start) --
    let (center_ea, center_eigvecs) = {
        let mut theta = ThetaOperator::new(backend.clone(), dielectric.clone(), job.pol, job.k0);
        let mut preconditioner: Box<dyn OperatorPreconditioner<B>> =
            Box::new(theta.build_homogeneous_preconditioner_adaptive());

        let mut eigensolver_config = job.eigensolver.clone();
        if eigensolver_config.n_bands < n_total {
            eigensolver_config.n_bands = n_total;
        }

        let solve_start = std::time::Instant::now();
        let mut solver = Eigensolver::new(
            &mut theta,
            eigensolver_config,
            Some(&mut *preconditioner as &mut dyn OperatorPreconditioner<B>),
            None,
        );
        let result = solver.solve();
        let eigenvectors = solver.all_eigenvectors();
        let solve_time = solve_start.elapsed().as_secs_f64();

        let extract_start = std::time::Instant::now();
        let mut extractor = EAExtractor::new(
            &mut theta,
            &eigenvectors,
            &result.eigenvalues,
            job.ea_config.clone(),
        );
        let ingredients = extractor.extract(
            job.k0,
            job.registry,
            diel_derivs.as_ref(),
            None,
            result.iterations,
            result.converged,
        );
        let extract_time = extract_start.elapsed().as_secs_f64();

        (EAResult {
            ingredients,
            solve_time_seconds: solve_time,
            extract_time_seconds: extract_time,
        }, eigenvectors)
    };

    // n_points=1 → no neighbors
    if n_points == 1 {
        return KStencilResult {
            center: center_ea,
            center_eigenvectors: center_eigvecs,
            neighbors: Vec::new(),
            neighbor_k_points: Vec::new(),
        };
    }

    // -- 3. Generate stencil k-points --
    let half = (n_points / 2) as isize;
    let step = delta_k / half as f64;

    let mut neighbor_k_points = Vec::new();
    for ix in -half..=half {
        for iy in -half..=half {
            if ix == 0 && iy == 0 {
                continue; // skip center
            }
            neighbor_k_points.push([
                job.k0[0] + ix as f64 * step,
                job.k0[1] + iy as f64 * step,
            ]);
        }
    }

    // -- 4. Solve at each neighbor with warm-start from center --
    let mut neighbors = Vec::with_capacity(neighbor_k_points.len());

    for &k_point in &neighbor_k_points {
        let mut theta = ThetaOperator::new(backend.clone(), dielectric.clone(), job.pol, k_point);
        let mut preconditioner: Box<dyn OperatorPreconditioner<B>> =
            Box::new(theta.build_homogeneous_preconditioner_adaptive());

        let mut eigensolver_config = job.eigensolver.clone();
        if eigensolver_config.n_bands < n_total {
            eigensolver_config.n_bands = n_total;
        }

        let solve_start = std::time::Instant::now();
        let mut solver = Eigensolver::new(
            &mut theta,
            eigensolver_config,
            Some(&mut *preconditioner as &mut dyn OperatorPreconditioner<B>),
            Some(&center_eigvecs), // warm-start from center
        );
        let result = solver.solve();
        let eigenvectors = solver.all_eigenvectors();
        let solve_time = solve_start.elapsed().as_secs_f64();

        let extract_start = std::time::Instant::now();
        let mut extractor = EAExtractor::new(
            &mut theta,
            &eigenvectors,
            &result.eigenvalues,
            job.ea_config.clone(),
        );
        let ingredients = extractor.extract(
            k_point,
            job.registry,
            diel_derivs.as_ref(),
            None,
            result.iterations,
            result.converged,
        );
        let extract_time = extract_start.elapsed().as_secs_f64();

        neighbors.push(EAResult {
            ingredients,
            solve_time_seconds: solve_time,
            extract_time_seconds: extract_time,
        });
    }

    KStencilResult {
        center: center_ea,
        center_eigenvectors: center_eigvecs,
        neighbors,
        neighbor_k_points,
    }
}
