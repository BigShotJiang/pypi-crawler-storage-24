"""Python API client for zipfyi.com."""

__version__ = "0.1.0"
