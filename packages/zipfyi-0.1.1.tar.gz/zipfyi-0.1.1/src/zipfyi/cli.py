"""Command-line interface for zipfyi."""

from __future__ import annotations

import json

import typer

from zipfyi.api import ZipFYI

app = typer.Typer(help="ZipFYI — ZIP and postal codes geocoding API client.")


@app.command()
def search(query: str) -> None:
    """Search zipfyi.com."""
    with ZipFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
