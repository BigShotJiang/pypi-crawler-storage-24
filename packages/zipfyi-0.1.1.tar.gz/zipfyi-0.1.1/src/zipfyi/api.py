"""HTTP API client for zipfyi.com REST endpoints.

Requires the ``api`` extra: ``pip install zipfyi[api]``

Usage::

    from zipfyi.api import ZipFYI

    with ZipFYI() as api:
        items = api.list_blog_posts()
        detail = api.get_blog_post("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class ZipFYI:
    """API client for the zipfyi.com REST API.

    Provides typed access to all zipfyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://zipfyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://zipfyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_blog_posts(self, **params: Any) -> dict[str, Any]:
        """List all blog posts."""
        return self._get("/api/v1/blog-posts/", **params)

    def get_blog_post(self, slug: str) -> dict[str, Any]:
        """Get blog post by slug."""
        return self._get(f"/api/v1/blog-posts/" + slug + "/")

    def list_blog_series(self, **params: Any) -> dict[str, Any]:
        """List all blog series."""
        return self._get("/api/v1/blog-series/", **params)

    def get_blog_sery(self, slug: str) -> dict[str, Any]:
        """Get blog sery by slug."""
        return self._get(f"/api/v1/blog-series/" + slug + "/")

    def list_cities(self, **params: Any) -> dict[str, Any]:
        """List all cities."""
        return self._get("/api/v1/cities/", **params)

    def get_city(self, slug: str) -> dict[str, Any]:
        """Get city by slug."""
        return self._get(f"/api/v1/cities/" + slug + "/")

    def list_countries(self, **params: Any) -> dict[str, Any]:
        """List all countries."""
        return self._get("/api/v1/countries/", **params)

    def get_country(self, slug: str) -> dict[str, Any]:
        """Get country by slug."""
        return self._get(f"/api/v1/countries/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/faqs/" + slug + "/")

    def list_glossary(self, **params: Any) -> dict[str, Any]:
        """List all glossary."""
        return self._get("/api/v1/glossary/", **params)

    def get_term(self, slug: str) -> dict[str, Any]:
        """Get term by slug."""
        return self._get(f"/api/v1/glossary/" + slug + "/")

    def list_postal_codes(self, **params: Any) -> dict[str, Any]:
        """List all postal codes."""
        return self._get("/api/v1/postal-codes/", **params)

    def get_postal_code(self, slug: str) -> dict[str, Any]:
        """Get postal code by slug."""
        return self._get(f"/api/v1/postal-codes/" + slug + "/")

    def list_states(self, **params: Any) -> dict[str, Any]:
        """List all states."""
        return self._get("/api/v1/states/", **params)

    def get_state(self, slug: str) -> dict[str, Any]:
        """Get state by slug."""
        return self._get(f"/api/v1/states/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> ZipFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
