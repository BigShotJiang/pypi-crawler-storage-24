"""MCP server for zipfyi — AI assistant tools for zipfyi.com.

Run: uvx --from "zipfyi[mcp]" python -m zipfyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("ZipFYI")


@mcp.tool()
def list_postal_codes(limit: int = 20, offset: int = 0) -> str:
    """List postal_codes from zipfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from zipfyi.api import ZipFYI

    with ZipFYI() as api:
        data = api.list_postal_codes(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No postal_codes found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_postal_code(slug: str) -> str:
    """Get detailed information about a specific postal_code.

    Args:
        slug: URL slug identifier for the postal_code.
    """
    from zipfyi.api import ZipFYI

    with ZipFYI() as api:
        data = api.get_postal_code(slug)
        return str(data)


@mcp.tool()
def list_states(limit: int = 20, offset: int = 0) -> str:
    """List states from zipfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from zipfyi.api import ZipFYI

    with ZipFYI() as api:
        data = api.list_states(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No states found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_zip(query: str) -> str:
    """Search zipfyi.com for ZIP/postal codes, cities, and geocoding.

    Args:
        query: Search query string.
    """
    from zipfyi.api import ZipFYI

    with ZipFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
