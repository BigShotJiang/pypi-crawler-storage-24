"""Tests for group E2E encryption functions."""
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

# Ensure termchat package is importable
sys.path.insert(0, str(Path(__file__).parent.parent))


def test_group_key_wrap_unwrap():
    """Test that a group key can be wrapped for a peer and unwrapped by them."""
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
    from cryptography.hazmat.primitives import serialization

    with tempfile.TemporaryDirectory() as tmpdir:
        keys_dir = Path(tmpdir)

        with patch("termchat.crypto.KEYS_DIR", keys_dir):
            from termchat.crypto import (
                generate_group_key,
                wrap_group_key,
                unwrap_group_key,
                encrypt_group_message,
                decrypt_group_message,
                cache_group_key,
                get_cached_group_key,
                clear_group_key_cache,
            )
            import termchat.crypto as crypto_mod
            orig_keys_dir = crypto_mod.KEYS_DIR
            crypto_mod.KEYS_DIR = keys_dir

            try:
                # Create keypairs for alice and bob
                alice_priv = X25519PrivateKey.generate()
                alice_pub = alice_priv.public_key()
                bob_priv = X25519PrivateKey.generate()
                bob_pub = bob_priv.public_key()

                # Save keys to temp dir
                (keys_dir / "alice.key").write_bytes(
                    alice_priv.private_bytes(
                        encoding=serialization.Encoding.Raw,
                        format=serialization.PrivateFormat.Raw,
                        encryption_algorithm=serialization.NoEncryption(),
                    )
                )
                (keys_dir / "bob.key").write_bytes(
                    bob_priv.private_bytes(
                        encoding=serialization.Encoding.Raw,
                        format=serialization.PrivateFormat.Raw,
                        encryption_algorithm=serialization.NoEncryption(),
                    )
                )

                import base64
                bob_pub_b64 = base64.b64encode(
                    bob_pub.public_bytes(
                        encoding=serialization.Encoding.Raw,
                        format=serialization.PublicFormat.Raw,
                    )
                ).decode()
                alice_pub_b64 = base64.b64encode(
                    alice_pub.public_bytes(
                        encoding=serialization.Encoding.Raw,
                        format=serialization.PublicFormat.Raw,
                    )
                ).decode()

                # Alice generates a group key
                group_key = generate_group_key()
                assert len(group_key) == 32

                # Alice wraps the group key for Bob
                wrapped = wrap_group_key(group_key, "alice", bob_pub_b64)
                assert wrapped is not None

                # Bob unwraps it (wrapper's pub key is embedded in the blob)
                unwrapped = unwrap_group_key(wrapped, "bob")
                assert unwrapped == group_key

                # Alice also wraps for herself
                wrapped_self = wrap_group_key(group_key, "alice", alice_pub_b64)
                unwrapped_self = unwrap_group_key(wrapped_self, "alice")
                assert unwrapped_self == group_key

                # Test message encryption/decryption with group key
                plaintext = "hello group!"
                encrypted = encrypt_group_message(plaintext, group_key)
                assert encrypted.startswith("ENC:")
                assert encrypted != plaintext
                decrypted = decrypt_group_message(encrypted, group_key)
                assert decrypted == plaintext

                # Both alice and bob can decrypt with the same group key
                decrypted_by_bob = decrypt_group_message(encrypted, group_key)
                assert decrypted_by_bob == plaintext

                # Wrong key fails gracefully
                wrong_key = os.urandom(32)
                failed = decrypt_group_message(encrypted, wrong_key)
                assert "cannot decrypt" in failed

                # Test cache
                clear_group_key_cache()
                assert get_cached_group_key("conv1") is None
                cache_group_key("conv1", group_key)
                assert get_cached_group_key("conv1") == group_key
                clear_group_key_cache()
                assert get_cached_group_key("conv1") is None

            finally:
                crypto_mod.KEYS_DIR = orig_keys_dir
