import os
from pathlib import Path

SERVER_URL = os.environ.get(
    "TERMCHAT_SERVER", "https://romantic-spirit-production-7063.up.railway.app"
)
API_URL = f"{SERVER_URL}/api"
WS_URL = (
    SERVER_URL.replace("https://", "wss://").replace("http://", "ws://") + "/api/ws"
)
CONFIG_DIR = Path.home() / ".termchat"
CREDENTIALS_FILE = CONFIG_DIR / "credentials.json"
