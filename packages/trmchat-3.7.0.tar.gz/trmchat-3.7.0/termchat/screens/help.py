from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Static


HELP_TEXT = """\
[bold $primary]TERMCHAT HELP[/]

[bold]COMMANDS[/]
  /code [lang] <code>     share code snippet
  /edit [text]            edit your last message
  /delete                 delete your last message
  /reply                  reply to last message
  /react <emoji>          react to last message
  /status available|away|dnd
  /profile [@user]        view profile
  /search <text>          search messages
  /rename <name>          rename group
  /add @user              add to group
  /kick @user             remove from group
  /block @user            block a user
  /unblock @user          unblock a user
  /file <path>            share a file (max 2MB)
  /download               list files in chat
  /download <name>        download file by name
  /notes                  open notes to self
  /logout                 log out
  /mute                   mute current chat
  /unmute                 unmute current chat
  /silent                 toggle all notification sounds
  /password               change password
  /info                   show chat info
  /online                 show online users
  /clear                  clear message view
  /help                   show this help

[bold]KEYBINDINGS[/]
  enter                   send message
  shift+enter             insert newline
  up / down               input history
  tab (on /cmd)           tab-complete commands
  pageup                  load older messages
  ctrl+n                  new direct message
  ctrl+g                  new group chat
  ctrl+f                  search messages
  ctrl+d                  delete/leave chat
  ctrl+o                  open settings
  ctrl+l                  logout
  ctrl+q                  quit
  tab / shift+tab         cycle panels
  escape                  deselect chat / cancel edit

[bold]VIM NAVIGATION[/] (when not typing)
  j / k                   scroll messages down/up
  g / G                   scroll to top/bottom
  i                       focus input (insert mode)
  /                       start search

[bold]MESSAGE FORMATTING[/]
  **bold**                bold text
  *italic*                italic text
  `code`                  inline code
  ```lang                 code block
  code here
  ```

[bold]CLI INTEGRATION[/]
  termchat send @user "msg"     send from scripts
  echo "text" | termchat send   pipe from stdin
  termchat pipe @user           stream stdin lines
  termchat status               show unread count
  termchat status --json        for tmux integration
  termchat status --unread      just the number

[bold]SSH ACCESS[/]
  ssh user@hopper.proxy.rlwy.net -p 20732
  uses your termchat username and password

[bold]E2E ENCRYPTION[/]
  DMs are encrypted with X25519 + AES-256-GCM
  keys stored locally in ~/.termchat/keys/
  "E2E" in chat header = both sides encrypted
  "E2E pending" = peer hasn't upgraded yet

[bold]SELF-HOSTING[/]
  TERMCHAT_SERVER=https://myserver.com termchat
  SSH_PORT=2222 to enable SSH on your server

[bold]TMUX INTEGRATION[/]
  set -g status-right "#(termchat status --unread) unread"

[dim]ctrl+o > About for more  \u2022  escape to close[/]\
"""


class HelpScreen(ModalScreen[None]):

    def compose(self) -> ComposeResult:
        with VerticalScroll(id="help-modal"):
            yield Static(HELP_TEXT, id="help-text")

    def on_key(self, event) -> None:
        if event.key == "escape":
            event.stop()
            event.prevent_default()
            self.dismiss(None)
