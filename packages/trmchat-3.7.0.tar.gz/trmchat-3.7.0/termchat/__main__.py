from termchat.app import main

main()
