"""Modules for communicating with specific Roborock devices over MQTT.

Uses a persistent MQTT subscription model: the channel subscribes to the
device's response topic once and maintains the subscription for its lifetime.
Per-command subscribe/unsubscribe only operates on an internal callback list,
avoiding unnecessary MQTT protocol-level SUBSCRIBE/UNSUBSCRIBE operations.
"""

import asyncio
import logging
from collections.abc import AsyncGenerator, Callable

from roborock_cli._vendor.roborock.callbacks import CallbackList, decoder_callback
from roborock_cli._vendor.roborock.data import HomeDataDevice, RRiot, UserData
from roborock_cli._vendor.roborock.exceptions import RoborockException
from roborock_cli._vendor.roborock.mqtt.health_manager import HealthManager
from roborock_cli._vendor.roborock.mqtt.session import MqttParams, MqttSession, MqttSessionException
from roborock_cli._vendor.roborock.protocol import create_mqtt_decoder, create_mqtt_encoder
from roborock_cli._vendor.roborock.roborock_message import RoborockMessage
from roborock_cli._vendor.roborock.util import RoborockLoggerAdapter

from .channel import Channel

_LOGGER = logging.getLogger(__name__)


class MqttChannel(Channel):
    """Channel for communicating with a device over MQTT.

    Uses a persistent subscription model: subscribes to the device's MQTT
    response topic once on first use, then routes messages internally via
    a CallbackList. Individual subscribe/unsubscribe calls only add/remove
    callbacks from the internal list without touching the MQTT subscription.
    """

    def __init__(self, mqtt_session: MqttSession, duid: str, local_key: str, rriot: RRiot, mqtt_params: MqttParams):
        self._mqtt_session = mqtt_session
        self._duid = duid
        self._logger = RoborockLoggerAdapter(duid=duid, logger=_LOGGER)
        self._local_key = local_key
        self._rriot = rriot
        self._mqtt_params = mqtt_params

        self._decoder = create_mqtt_decoder(local_key)
        self._encoder = create_mqtt_encoder(local_key)

        # Persistent subscription state
        self._mqtt_unsub: Callable[[], None] | None = None
        self._subscribers: CallbackList[RoborockMessage] = CallbackList(self._logger)

    @property
    def is_connected(self) -> bool:
        """Return true if the channel is connected.

        This passes through the underlying MQTT session's connected state.
        """
        return self._mqtt_session.connected

    @property
    def health_manager(self) -> HealthManager:
        """Return the health manager for the session."""
        return self._mqtt_session.health_manager

    @property
    def is_local_connected(self) -> bool:
        """Return true if the channel is connected locally."""
        return False

    @property
    def _publish_topic(self) -> str:
        """Topic to send commands to the device."""
        return f"rr/m/i/{self._rriot.u}/{self._mqtt_params.username}/{self._duid}"

    @property
    def _subscribe_topic(self) -> str:
        """Topic to receive responses from the device."""
        return f"rr/m/o/{self._rriot.u}/{self._mqtt_params.username}/{self._duid}"

    async def subscribe(self, callback: Callable[[RoborockMessage], None]) -> Callable[[], None]:
        """Subscribe to messages from the device.

        On first call, establishes a persistent MQTT subscription to the device's
        response topic. Subsequent calls only add the callback to an internal list.
        The returned unsubscribe callable removes the callback from the internal
        list without affecting the MQTT subscription.
        """
        await self._ensure_subscribed()
        return self._subscribers.add_callback(callback)

    async def _ensure_subscribed(self) -> None:
        """Ensure the persistent MQTT subscription is established."""
        if self._mqtt_unsub is not None:
            return
        dispatch = decoder_callback(self._decoder, self._subscribers, _LOGGER)
        self._mqtt_unsub = await self._mqtt_session.subscribe(self._subscribe_topic, dispatch)

    async def subscribe_stream(self) -> AsyncGenerator[RoborockMessage, None]:
        """Subscribe to the device's message stream.

        This is useful for processing all incoming messages in an async for loop,
        when they are not necessarily associated with a specific request.
        """
        message_queue: asyncio.Queue[RoborockMessage] = asyncio.Queue()
        unsub = await self.subscribe(message_queue.put_nowait)
        try:
            while True:
                message = await message_queue.get()
                yield message
        finally:
            unsub()

    async def publish(self, message: RoborockMessage) -> None:
        """Publish a command message.

        The caller is responsible for handling any responses and associating them
        with the incoming request.
        """
        try:
            encoded_msg = self._encoder(message)
        except Exception as e:
            self._logger.exception("Error encoding MQTT message: %s", e)
            raise RoborockException(f"Failed to encode MQTT message: {e}") from e
        try:
            return await self._mqtt_session.publish(self._publish_topic, encoded_msg)
        except MqttSessionException as e:
            self._logger.debug("Error publishing MQTT message: %s", e)
            raise RoborockException(f"Failed to publish MQTT message: {e}") from e

    def close(self) -> None:
        """Close the channel and unsubscribe from the MQTT topic."""
        if self._mqtt_unsub is not None:
            self._mqtt_unsub()
            self._mqtt_unsub = None

    async def restart(self) -> None:
        """Restart the underlying MQTT session."""
        await self._mqtt_session.restart()


def create_mqtt_channel(
    user_data: UserData, mqtt_params: MqttParams, mqtt_session: MqttSession, device: HomeDataDevice
) -> MqttChannel:
    """Create a MQTT channel for the given device."""
    return MqttChannel(mqtt_session, device.duid, device.local_key, user_data.rriot, mqtt_params)
