# standard
# third party
# custom

__all__ = ["app"]


def __getattr__(name: str):  # pragma: no cover
    if name == "app":
        from .commands import app

        return app
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
