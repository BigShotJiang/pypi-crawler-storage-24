# third party
import typer

# custom
from .code import code
from .models import list_models_cmd
from .sessions import list_sessions_cmd
from .set_model import set_model

app = typer.Typer(name="gen", help="Gen", invoke_without_command=True)
_models_app = typer.Typer(help="Model catalog.")
_sessions_app = typer.Typer(help="Session management.")
app.add_typer(_models_app, name="models")
app.add_typer(_sessions_app, name="sessions")


@app.callback(invoke_without_command=True)
def _default(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is None:
        code()


app.command("code")(code)
app.command("set-model")(set_model)
_models_app.command("list")(list_models_cmd)
_sessions_app.command("list")(list_sessions_cmd)
