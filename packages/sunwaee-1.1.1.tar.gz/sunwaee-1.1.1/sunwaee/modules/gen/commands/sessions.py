from __future__ import annotations

# third party
from rich.table import Table

# custom
from sunwaee.config import Caller, get_caller, get_default_workspace
from sunwaee.core.output import console, success
from ..session import list_sessions


def list_sessions_cmd() -> None:
    """List sessions for the current workspace."""

    workspace = get_default_workspace()
    sessions = list_sessions(workspace)

    if get_caller() != Caller.USER:
        success([s.to_meta() for s in sessions])
        return

    if not sessions:
        console.print("[dim]No sessions found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    for col in ("ID", "Title", "Created", "Updated"):
        table.add_column(col)

    for s in sessions:
        table.add_row(
            s.id[:8],
            s.title or "[dim](untitled)[/dim]",
            s.created_at[:19].replace("T", " "),
            s.updated_at[:19].replace("T", " "),
        )

    console.print(table)
