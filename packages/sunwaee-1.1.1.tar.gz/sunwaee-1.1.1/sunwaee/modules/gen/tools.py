# standard
# third party
# custom
from sunwaee.modules.notes.tools import TOOLS as _NOTES
from sunwaee.modules.shell.tools import TOOLS as _SHELL
from sunwaee.modules.tasks.tools import TOOLS as _TASKS
from sunwaee.modules.workspaces.tools import TOOLS as _WORKSPACES
from sunwaee.modules.gen.engine.types import Tool

TOOLS: list[Tool] = [
    *_WORKSPACES,
    *_TASKS,
    *_NOTES,
    *_SHELL,
]
