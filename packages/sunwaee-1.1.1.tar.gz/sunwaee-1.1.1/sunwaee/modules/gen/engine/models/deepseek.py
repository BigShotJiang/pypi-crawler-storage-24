from __future__ import annotations

# standard
# third party
# custom
from ..model import Model

MODELS: list[Model] = [
    Model(
        name="deepseek-v3.2",
        display_name="DeepSeek V3.2",
        provider="deepseek",
        context_window=128_000,
        max_output_tokens=64_000,
        input_price_per_mtok=0.28,
        output_price_per_mtok=0.42,
        cache_read_price_per_mtok=0.028,
        supports_tools=True,
        supports_thinking=True,
        supports_reasoning_tokens=True,
        release_date="2025-12-01",
    ),
]
