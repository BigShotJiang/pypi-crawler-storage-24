# Gen

The AI agent module. Start an interactive chat session with Sun, the SUNWÆE AI agent — powered by Claude, GPT, Gemini, DeepSeek, or any compatible model. Sun has full access to your notes, tasks, projects, workspaces, and shell.

## Storage

Sessions are stored per workspace:

```
~/sunwaee/workspaces/
└── personal/
    └── gen/
        └── sessions/
            └── <session-id>.jsonl   ← metadata + full message history
```

Each session file is a JSONL file: the first line is metadata, subsequent lines are messages (role, content, tool calls, reasoning).

## Commands

### `gen` (default)

Start an interactive chat session.

```
sunwaee gen
sunwaee gen --model claude-opus-4-6
sunwaee gen --session abc12345          # resume a previous session
```

### `gen models list`

List all available models with their capabilities and pricing.

```
sunwaee gen models list
```

### `gen sessions list`

List all saved sessions for the current workspace.

```
sunwaee gen sessions list
```

### `gen set-model`

Interactively select and save your default model (with Tab completion).

```
sunwaee gen set-model
```

## Inside the REPL

Once in a session, type your message and press Enter. Use vim-style commands for control:

| Command         | Description                             |
| --------------- | --------------------------------------- |
| `:help`         | Show available commands                 |
| `:session`      | Show current session metadata           |
| `:cost`         | Show accumulated cost and token usage   |
| `:model`        | Show the current model                  |
| `:model <name>` | Switch to a different model mid-session |
| `:clear`        | Clear the conversation history          |
| `:quit`         | Exit the REPL                           |

## Providers

| Provider  | Example models                                             |
| --------- | ---------------------------------------------------------- |
| Anthropic | `claude-opus-4-6`, `claude-sonnet-4-6`, `claude-haiku-4-5` |
| OpenAI    | `gpt-5.4-pro`, `gpt-4o`, `o1-preview`                      |
| Google    | `gemini-2.0-flash`, `gemini-1.5-pro`                       |
| DeepSeek  | `deepseek-chat`, `deepseek-reasoner`                       |
| xAI       | `grok-3`, `grok-3-mini`                                    |
| Moonshot  | `moonshot-v1-8k`                                           |

Set the API key via environment variable: `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `GOOGLE_API_KEY`, `DEEPSEEK_API_KEY`, `XAI_API_KEY`, `MOONSHOT_API_KEY`.

## What Sun can do

Sun runs a ReAct loop (reason → act → observe → repeat) and has access to:

- **Notes** — create, list, read, update, delete
- **Tasks** — create, list, read, update, delete
- **Projects** — create, list, read, update
- **Workspaces** — create, list, read, update
- **Shell** — run arbitrary shell commands

Tool calls are executed concurrently. Reasoning (on supported models) is shown in italic as Sun thinks through the problem.

## Reasoning models

Extended thinking is automatically enabled for models that support it — no configuration needed. Reasoning tokens appear in the REPL in real time before the final answer.
