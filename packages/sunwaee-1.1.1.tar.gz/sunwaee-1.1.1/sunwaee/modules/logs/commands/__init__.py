# third party
import typer

# custom
from .list import list_logs
from .read import read_log

app = typer.Typer(name="logs", help="View and search activity logs.", no_args_is_help=True)
app.command("list")(list_logs)
app.command("read")(read_log)
