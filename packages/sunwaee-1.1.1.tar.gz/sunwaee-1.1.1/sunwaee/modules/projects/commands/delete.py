# standard
import shutil
from typing import Optional

# third party
import typer

# custom
from sunwaee.config import get_default_workspace, get_project_dir
from sunwaee.core.audit import append_log
from sunwaee.core.logger import get_logger
from sunwaee.core.output import console, error, success

_log = get_logger("modules.projects")


def delete(
    name: str = typer.Argument(..., help="Project name"),
    workspace: Optional[str] = typer.Option(None, "--workspace", "-w"),
    confirm: bool = typer.Option(False, "--confirm", help="Confirm deletion"),
) -> None:
    """Delete a project and all its data."""
    if not confirm:
        error("Pass --confirm to delete a project", "CONFIRMATION_REQUIRED")

    ws = workspace or get_default_workspace()
    project_dir = get_project_dir(ws, name)

    if not project_dir.exists():
        error(f"Project not found: {name!r}", "NOT_FOUND")

    append_log(ws, "projects", "delete", item_title=name)
    shutil.rmtree(project_dir)
    _log.info("Deleted project %r from %s", name, project_dir)

    success(
        {"name": name, "workspace": ws},
        human_fn=lambda: console.print(
            f"[red]Deleted[/red] project '[bold]{name}[/bold]' and all its data"
        ),
    )
