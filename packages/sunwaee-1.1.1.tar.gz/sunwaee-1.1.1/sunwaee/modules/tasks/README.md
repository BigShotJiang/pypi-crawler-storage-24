# Tasks

Tasks are actionable items with a status, priority, and optional due date. They support subtasks (parent/child relationships), tags, and a markdown body for details.

## Storage

Tasks are stored as markdown files with YAML frontmatter:

```
~/sunwaee/workspaces/
└── personal/
    └── tasks/
        └── fix-the-login-bug.md    ← frontmatter (id, title, status, priority, …) + body
```

Each task is a single `.md` file. The filename is a slug of the title. Status, priority, due date, and parent relationship live in the frontmatter; details go in the body.

## Commands

### `tasks create`

Create a new task. Without `--body`, opens `$EDITOR`.

```
sunwaee tasks create --title "Fix login bug"
sunwaee tasks create --title "Write tests" --priority high --due 2026-03-20
sunwaee tasks create --title "Update footer" --body "Change copyright year" --tags "frontend"
sunwaee tasks create --title "Write unit tests" --parent "Fix login bug"
```

Priority: `low`, `medium` (default), `high`.

### `tasks list`

List tasks. Defaults to all workspaces. Supports filtering by status, priority, tags, and free-text search.

```
sunwaee tasks list
sunwaee tasks list --status todo
sunwaee tasks list --status in_progress --workspace work
sunwaee tasks list --priority high
sunwaee tasks list --query "login"
sunwaee tasks list --tags "frontend,bug"
```

### `tasks read <query>`

Show full detail of a task, including body. The query matches by id, slug, or title.

```
sunwaee tasks read "Fix login bug"
sunwaee tasks read fix-login-bug
sunwaee tasks read a1b2c3d4
```

### `tasks update <query>`

Update any field of a task. Without flags, opens `$EDITOR` for the body.

```
sunwaee tasks update "Fix login bug" --status done
sunwaee tasks update "Write tests" --priority high --due 2026-03-25
sunwaee tasks update "Write tests" --clear-due
sunwaee tasks update "Old task" --title "Renamed task"
sunwaee tasks update "Write tests" --body "Updated details"
```

### `tasks delete <query>`

Delete a task and all its subtasks permanently. No `--confirm` required.

```
sunwaee tasks delete "Old task"
sunwaee tasks delete "Fix login bug" --workspace work
```

## Statuses

| Status        | Meaning                   |
| ------------- | ------------------------- |
| `todo`        | Not started (default)     |
| `in_progress` | Currently being worked on |
| `done`        | Completed                 |

## Subtasks

Pass `--parent` on create to link a task to a parent. The parent is looked up the same way as any other task (id, slug, or title). Deleting a parent also deletes all its subtasks.
