# standard
from typing import Optional

# third party
import typer

# custom
from sunwaee.core.audit import append_log
from sunwaee.core.output import error, success
from ._helpers import _enrich, _find_in_all, _load


def read(
    query: str = typer.Argument(..., help="Task id, slug, or title"),
    workspace: Optional[str] = typer.Option(
        None, "--workspace", "-w", help="Workspace (default: search all)"
    ),
) -> None:
    """Print raw content of the task file."""
    found = _find_in_all(query, workspace)
    if found is None:
        error(f"Task not found: {query!r}", "NOT_FOUND")
        return  # pragma: no cover
    ws, _, path = found

    task = _load(path)
    append_log(ws, "tasks", "read", item_id=task.id, item_title=task.title)
    raw = path.read_text()

    success(_enrich(task, ws, path), human_fn=lambda: print(raw, end=""))
