# third party
import typer

# custom
from .create import create
from .delete import delete
from .list import list_tasks
from .read import read
from .update import update

app = typer.Typer(name="tasks", help="Manage tasks.", no_args_is_help=True)
app.command("create")(create)
app.command("list")(list_tasks)
app.command("read")(read)
app.command("update")(update)
app.command("delete")(delete)
