# third party
import typer

# custom
from .create import create
from .delete import delete
from .list import list_workspaces
from .read import read
from .update import update

app = typer.Typer(name="workspaces", help="Manage workspaces.", no_args_is_help=True)
app.command("create")(create)
app.command("list")(list_workspaces)
app.command("read")(read)
app.command("update")(update)
app.command("delete")(delete)
