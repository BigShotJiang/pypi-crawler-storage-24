# standard
import shutil

# third party
import typer

# custom
from sunwaee.config import get_workspaces_base_dir
from sunwaee.core.audit import append_log
from sunwaee.core.logger import get_logger
from sunwaee.core.output import console, error, success

_log = get_logger("modules.workspaces")


def delete(
    name: str = typer.Argument(..., help="Workspace name"),
    confirm: bool = typer.Option(False, "--confirm", help="Confirm deletion"),
) -> None:
    """Delete a workspace and all its data."""
    if not confirm:
        error("Pass --confirm to delete a workspace", "CONFIRMATION_REQUIRED")

    base = get_workspaces_base_dir()
    workspace_dir = base / name
    if not workspace_dir.exists():
        error(f"Workspace not found: {name!r}", "NOT_FOUND")

    append_log(name, "workspaces", "delete", item_title=name)
    shutil.rmtree(workspace_dir)
    _log.info("Deleted workspace %r from %s", name, workspace_dir)

    success(
        {"name": name},
        human_fn=lambda: console.print(
            f"[red]Deleted[/red] workspace '[bold]{name}[/bold]' and all its data"
        ),
    )
