# standard
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone

# third party
# custom


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _uuid() -> str:
    return str(uuid.uuid4())


@dataclass
class Workspace:
    name: str
    id: str = field(default_factory=_uuid)
    body: str = ""
    created_at: str = field(default_factory=_now)
    updated_at: str = field(default_factory=_now)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "body": self.body,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    def touch(self) -> None:
        self.updated_at = _now()

    def to_frontmatter_meta(self) -> dict:
        return {
            "id": self.id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, name: str, meta: dict, body: str = "") -> "Workspace":
        return cls(
            id=meta.get("id") or _uuid(),
            name=name,
            body=body,
            created_at=meta.get("created_at", _now()),
            updated_at=meta.get("updated_at", _now()),
        )
