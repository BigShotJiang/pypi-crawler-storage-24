# Notes

Notes are freeform markdown documents. Use them for anything that doesn't fit neatly into a task — meeting notes, research, ideas, reference material, documentation snippets.

## Storage

Notes are stored as markdown files with YAML frontmatter:

```
~/sunwaee/workspaces/
└── personal/
    └── notes/
        └── my-note-title.md    ← frontmatter (id, title, tags, dates) + body
```

Each note is a single `.md` file. The filename is a slug of the title. The id and metadata live in the frontmatter; the content is the file body.

## Commands

### `notes create`

Create a new note. Without `--body`, opens `$EDITOR`.

```
sunwaee notes create --title "Meeting notes"
sunwaee notes create --title "API design" --body "# Overview\n..."
sunwaee notes create --title "Ideas" --tags "brainstorm,product" --workspace work
```

### `notes list`

List all notes. Defaults to all workspaces. Supports filtering and search.

```
sunwaee notes list
sunwaee notes list --workspace personal
sunwaee notes list --query "api design"
sunwaee notes list --tags "brainstorm"
sunwaee notes list --sort title
```

Sort options: `updated` (default), `created`, `title`.

### `notes read <query>`

Read the full content of a note. The query matches by id, slug, or title.

```
sunwaee notes read "Meeting notes"
sunwaee notes read my-note-title
sunwaee notes read a1b2c3d4
```

### `notes update <query>`

Update a note's title, tags, or body. Without flags, opens `$EDITOR` for the body.

```
sunwaee notes update "Meeting notes" --title "Q1 Meeting notes"
sunwaee notes update "API design" --body "Updated content"
sunwaee notes update "Ideas" --tags "brainstorm,archived"
```

### `notes delete <query>`

Delete a note permanently. Requires `--confirm`.

```
sunwaee notes delete "Old note" --confirm
```

## Finding notes

All three lookup commands (`read`, `update`, `delete`) accept a note's **id** (or id prefix), **slug** (filename without `.md`), or **title** (case-insensitive). The shortest unambiguous form works.
