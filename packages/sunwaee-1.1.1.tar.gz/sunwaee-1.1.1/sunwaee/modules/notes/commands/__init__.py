# third party
import typer

# custom
from .create import create
from .delete import delete
from .list import list_notes
from .read import read_note
from .update import update

app = typer.Typer(name="notes", help="Manage notes.", no_args_is_help=True)
app.command("create")(create)
app.command("read")(read_note)
app.command("update")(update)
app.command("delete")(delete)
app.command("list")(list_notes)
