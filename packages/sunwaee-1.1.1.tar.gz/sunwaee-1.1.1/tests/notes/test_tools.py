# standard
import json

# third party
# custom
from sunwaee.modules.notes.tools import notes, TOOLS as NOTE_TOOLS

WS = "personal"


def test_notes_tool_create(ws):
    data = json.loads(notes(action="create", title="My note", workspace=WS))
    assert data["ok"] is True
    assert data["data"]["title"] == "My note"


def test_notes_tool_create_with_body_and_tags(ws):
    data = json.loads(notes(action="create", title="Tagged", body="content", tags=["a", "b"], workspace=WS))
    assert data["data"]["tags"] == ["a", "b"]
    assert data["data"]["body"] == "content"


def test_notes_tool_create_missing_title(ws):
    data = json.loads(notes(action="create", workspace=WS))
    assert data["ok"] is False
    assert "title" in data["error"]


def test_notes_tool_list_empty(ws):
    data = json.loads(notes(action="list", workspace=WS))
    assert data["ok"] is True
    assert data["data"] == []


def test_notes_tool_list(ws):
    notes(action="create", title="Note A", workspace=WS)
    notes(action="create", title="Note B", workspace=WS)
    data = json.loads(notes(action="list", workspace=WS))
    assert len(data["data"]) == 2


def test_notes_tool_list_filter_by_tags(ws):
    notes(action="create", title="Tagged", tags=["dev"], workspace=WS)
    notes(action="create", title="Other", tags=["other"], workspace=WS)
    data = json.loads(notes(action="list", tags=["dev"], workspace=WS))
    assert len(data["data"]) == 1
    assert data["data"][0]["title"] == "Tagged"


def test_notes_tool_list_filter_by_query(ws):
    notes(action="create", title="Find me", workspace=WS)
    notes(action="create", title="Skip", workspace=WS)
    data = json.loads(notes(action="list", query="Find", workspace=WS))
    assert any(n["title"] == "Find me" for n in data["data"])


def test_notes_tool_read(ws):
    notes(action="create", title="Show me", body="details", workspace=WS)
    data = json.loads(notes(action="read", query="Show me", workspace=WS))
    assert data["ok"] is True
    assert data["data"]["body"] == "details"


def test_notes_tool_read_not_found(ws):
    data = json.loads(notes(action="read", query="ghost", workspace=WS))
    assert data["ok"] is False


def test_notes_tool_read_missing_query(ws):
    data = json.loads(notes(action="read", workspace=WS))
    assert data["ok"] is False
    assert "query" in data["error"]


def test_notes_tool_update(ws):
    notes(action="create", title="Edit me", workspace=WS)
    data = json.loads(notes(action="update", query="Edit me", body="updated", workspace=WS))
    assert data["ok"] is True
    assert data["data"]["body"] == "updated"


def test_notes_tool_update_not_found(ws):
    data = json.loads(notes(action="update", query="ghost", title="X", workspace=WS))
    assert data["ok"] is False


def test_notes_tool_delete(ws):
    notes(action="create", title="Delete me", workspace=WS)
    data = json.loads(notes(action="delete", query="Delete me", workspace=WS))
    assert data["ok"] is True
    gone = json.loads(notes(action="read", query="Delete me", workspace=WS))
    assert gone["ok"] is False


def test_notes_tool_delete_not_found(ws):
    data = json.loads(notes(action="delete", query="ghost", workspace=WS))
    assert data["ok"] is False


def test_notes_tools_registry():
    assert len(NOTE_TOOLS) == 1
    assert NOTE_TOOLS[0].name == "notes"
    assert NOTE_TOOLS[0].fn is not None
    assert "create" in NOTE_TOOLS[0].parameters["properties"]["action"]["enum"]
    assert "read" in NOTE_TOOLS[0].parameters["properties"]["action"]["enum"]
    assert "update" in NOTE_TOOLS[0].parameters["properties"]["action"]["enum"]
