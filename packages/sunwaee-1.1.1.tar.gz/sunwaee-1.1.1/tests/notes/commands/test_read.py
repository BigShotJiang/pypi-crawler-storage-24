# standard
# third party
# custom
from ...conftest import ok, err
from sunwaee.cli import app

WS = "personal"
_BASE = ["--workspace", WS]


def _create(runner, title, **kwargs):
    args = ["notes", "create", "--title", title, *_BASE]
    for k, v in kwargs.items():
        args += [f"--{k}", v]
    return runner.invoke(app, args)


def test_read_note_by_title(runner, ws):
    _create(runner, "Show me", body="content")
    data = ok(runner.invoke(app, ["notes", "read", "Show me", *_BASE]))
    assert data["title"] == "Show me"
    assert data["body"] == "content"


def test_read_note_not_found(runner, ws):
    e = err(runner.invoke(app, ["notes", "read", "ghost", *_BASE]))
    assert e["code"] == "NOT_FOUND"


def test_read_note_includes_path(runner, ws):
    _create(runner, "Path note", body="x")
    data = ok(runner.invoke(app, ["notes", "read", "Path note", *_BASE]))
    assert "path" in data
    assert data["path"].endswith(".md")


def test_note_id_is_stable(runner, ws):
    data = ok(_create(runner, "Stable id", body="x"))
    note_id = data["id"]
    data2 = ok(runner.invoke(app, ["notes", "read", "Stable id", *_BASE]))
    assert data2["id"] == note_id
