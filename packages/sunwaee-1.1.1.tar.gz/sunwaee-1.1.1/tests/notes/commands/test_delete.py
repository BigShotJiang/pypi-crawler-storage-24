# standard
# third party
# custom
from ...conftest import ok, err
from sunwaee.cli import app

WS = "personal"
_BASE = ["--workspace", WS]


def _create(runner, title, **kwargs):
    args = ["notes", "create", "--title", title, *_BASE]
    for k, v in kwargs.items():
        args += [f"--{k}", v]
    return runner.invoke(app, args)


def test_delete_note_requires_confirm(runner, ws):
    _create(runner, "To delete")
    e = err(runner.invoke(app, ["notes", "delete", "To delete", *_BASE]))
    assert e["code"] == "CONFIRMATION_REQUIRED"


def test_delete_note(runner, ws):
    _create(runner, "Bye", body="x")
    data = ok(runner.invoke(app, ["notes", "delete", "Bye", "--confirm", *_BASE]))
    assert data["title"] == "Bye"
    assert "path" in data
    e = err(runner.invoke(app, ["notes", "read", "Bye", *_BASE]))
    assert e["code"] == "NOT_FOUND"


def test_delete_note_not_found(runner, ws):
    e = err(runner.invoke(app, ["notes", "delete", "ghost", "--confirm", *_BASE]))
    assert e["code"] == "NOT_FOUND"
