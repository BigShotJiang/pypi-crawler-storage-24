# standard
# third party
# custom
from ...conftest import ok
from sunwaee.cli import app

WS = "personal"
_BASE = ["--workspace", WS]


def test_create_note(runner, ws):
    data = ok(runner.invoke(app, ["notes", "create", "--title", "My Note", "--body", "Hello", *_BASE]))
    assert data["title"] == "My Note"
    assert data["body"] == "Hello"
    assert data["workspace"] == WS
    assert "path" in data


def test_create_note_with_tags(runner, ws):
    data = ok(runner.invoke(app, ["notes", "create", "--title", "Tagged", "--tags", "a,b", *_BASE]))
    assert data["tags"] == ["a", "b"]


def test_create_note_uses_default_workspace(runner, ws, monkeypatch):
    monkeypatch.setenv("SUNWAEE_WORKSPACE", WS)
    data = ok(runner.invoke(app, ["notes", "create", "--title", "Default ws note", "--body", "hi"]))
    assert data["workspace"] == WS


def test_create_note_creates_file(runner, ws, tmp_path):
    runner.invoke(app, ["notes", "create", "--title", "File check", "--body", "x", *_BASE])
    notes_dir = tmp_path / "workspaces" / WS / "notes"
    assert any(notes_dir.iterdir())
