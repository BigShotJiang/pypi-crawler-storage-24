# standard
import json

# third party
# custom
from sunwaee.modules.workspaces.tools import workspaces, TOOLS as WORKSPACE_TOOLS


def test_workspace_tool_list(env):
    data = json.loads(workspaces(action="list"))
    assert data["ok"] is True
    assert isinstance(data["data"], list)


def test_workspace_tool_list_has_metadata(env):
    workspaces(action="create", name="pro")
    data = json.loads(workspaces(action="list"))
    entry = data["data"][0]
    assert "id" in entry
    assert "body" in entry
    assert "default" in entry
    assert "path" in entry


def test_workspace_tool_create(env, tmp_path):
    data = json.loads(workspaces(action="create", name="pro"))
    assert data["ok"] is True
    assert data["data"]["name"] == "pro"
    assert "id" in data["data"]
    assert (tmp_path / "workspaces" / "pro").is_dir()


def test_workspace_tool_create_with_body(env):
    data = json.loads(workspaces(action="create", name="pro", body="My workspace"))
    assert data["ok"] is True
    assert data["data"]["body"] == "My workspace"


def test_workspace_tool_create_requires_name(env):
    data = json.loads(workspaces(action="create"))
    assert data["ok"] is False


def test_workspace_tool_create_duplicate_errors(env):
    workspaces(action="create", name="pro")
    data = json.loads(workspaces(action="create", name="pro"))
    assert data["ok"] is False


def test_workspace_tool_read(env):
    workspaces(action="create", name="pro", body="My workspace")
    data = json.loads(workspaces(action="read", name="pro"))
    assert data["ok"] is True
    assert data["data"]["name"] == "pro"
    assert data["data"]["body"] == "My workspace"
    assert "id" in data["data"]
    assert "default" in data["data"]
    assert "path" in data["data"]


def test_workspace_tool_read_requires_name(env):
    data = json.loads(workspaces(action="read"))
    assert data["ok"] is False


def test_workspace_tool_read_not_found_errors(env):
    data = json.loads(workspaces(action="read", name="ghost"))
    assert data["ok"] is False


def test_workspace_tool_update_body(env):
    workspaces(action="create", name="pro")
    data = json.loads(workspaces(action="update", name="pro", body="Updated"))
    assert data["ok"] is True
    assert data["data"]["body"] == "Updated"


def test_workspace_tool_update_set_default(env):
    workspaces(action="create", name="personal")
    workspaces(action="create", name="pro")
    data = json.loads(workspaces(action="update", name="pro", set_default=True))
    assert data["ok"] is True
    assert data["data"]["default"] is True


def test_workspace_tool_update_requires_name(env):
    data = json.loads(workspaces(action="update"))
    assert data["ok"] is False


def test_workspace_tool_update_no_changes_errors(env):
    workspaces(action="create", name="pro")
    data = json.loads(workspaces(action="update", name="pro"))
    assert data["ok"] is False


def test_workspace_tool_update_not_found_errors(env):
    data = json.loads(workspaces(action="update", name="ghost", body="x"))
    assert data["ok"] is False


def test_workspace_tools_registry():
    assert len(WORKSPACE_TOOLS) == 1
    assert WORKSPACE_TOOLS[0].name == "workspaces"
    assert WORKSPACE_TOOLS[0].fn is not None
