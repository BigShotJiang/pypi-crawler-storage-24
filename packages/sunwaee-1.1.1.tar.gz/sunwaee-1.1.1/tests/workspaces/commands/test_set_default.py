# removed: set-default command replaced by `workspaces update --set-default`
# tests moved to test_update.py
