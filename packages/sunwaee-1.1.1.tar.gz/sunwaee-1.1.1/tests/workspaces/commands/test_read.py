# standard
# third party
# custom
from ...conftest import ok, err
from sunwaee.cli import app


def test_read_workspace(runner, env):
    runner.invoke(app, ["workspaces", "create", "personal"])
    data = ok(runner.invoke(app, ["workspaces", "read", "personal"]))
    assert data["name"] == "personal"
    assert "id" in data
    assert "body" in data
    assert "path" in data
    assert "default" in data


def test_read_workspace_has_uuid(runner, env):
    runner.invoke(app, ["workspaces", "create", "personal"])
    data = ok(runner.invoke(app, ["workspaces", "read", "personal"]))
    assert len(data["id"]) == 36


def test_read_workspace_default_flag(runner, env):
    runner.invoke(app, ["workspaces", "create", "personal"])
    runner.invoke(app, ["workspaces", "create", "pro"])
    runner.invoke(app, ["workspaces", "update", "personal", "--set-default"])
    data = ok(runner.invoke(app, ["workspaces", "read", "personal"]))
    assert data["default"] is True
    data2 = ok(runner.invoke(app, ["workspaces", "read", "pro"]))
    assert data2["default"] is False


def test_read_workspace_with_body(runner, env):
    runner.invoke(app, ["workspaces", "create", "personal", "--body", "My workspace"])
    data = ok(runner.invoke(app, ["workspaces", "read", "personal"]))
    assert data["body"] == "My workspace"


def test_read_nonexistent_workspace_errors(runner, env):
    e = err(runner.invoke(app, ["workspaces", "read", "ghost"]))
    assert e["code"] == "NOT_FOUND"
