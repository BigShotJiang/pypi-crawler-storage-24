# standard
# third party
# custom
from ...conftest import ok, err
from sunwaee.cli import app


def test_delete_workspace_requires_confirm(runner, env):
    runner.invoke(app, ["workspaces", "create", "pro"])
    e = err(runner.invoke(app, ["workspaces", "delete", "pro"]))
    assert e["code"] == "CONFIRMATION_REQUIRED"


def test_delete_workspace(runner, env, tmp_path):
    runner.invoke(app, ["workspaces", "create", "pro"])
    ok(runner.invoke(app, ["workspaces", "delete", "pro", "--confirm"]))
    assert not (tmp_path / "workspaces" / "pro").exists()


def test_delete_workspace_cascades_data(runner, env, tmp_path):
    runner.invoke(app, ["workspaces", "create", "pro"])
    runner.invoke(
        app,
        ["note", "create", "--title", "A note", "--body", "hi", "--workspace", "pro"],
    )
    ok(runner.invoke(app, ["workspaces", "delete", "pro", "--confirm"]))
    assert not (tmp_path / "workspaces" / "pro").exists()


def test_delete_nonexistent_workspace_errors(runner, env):
    e = err(runner.invoke(app, ["workspaces", "delete", "ghost", "--confirm"]))
    assert e["code"] == "NOT_FOUND"
