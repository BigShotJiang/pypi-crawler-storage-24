# standard
# third party
# custom
from ...conftest import ok, err
from sunwaee.cli import app


def test_create_workspace(runner, env):
    data = ok(runner.invoke(app, ["workspaces", "create", "pro"]))
    assert data["name"] == "pro"
    assert "pro" in data["path"]
    assert "id" in data
    assert len(data["id"]) == 36


def test_create_workspace_creates_directory(runner, env, tmp_path):
    runner.invoke(app, ["workspaces", "create", "pro"])
    assert (tmp_path / "workspaces" / "pro").is_dir()


def test_create_workspace_writes_metadata(runner, env, tmp_path):
    runner.invoke(app, ["workspaces", "create", "pro"])
    assert (tmp_path / "workspaces" / "pro" / "metadata.md").exists()


def test_create_workspace_with_body(runner, env):
    data = ok(runner.invoke(app, ["workspaces", "create", "pro", "--body", "My workspace"]))
    assert data["body"] == "My workspace"


def test_create_duplicate_workspace_errors(runner, env):
    runner.invoke(app, ["workspaces", "create", "pro"])
    e = err(runner.invoke(app, ["workspaces", "create", "pro"]))
    assert e["code"] == "ALREADY_EXISTS"
