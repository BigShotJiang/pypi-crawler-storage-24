# standard
# third party
# custom
from ...conftest import ok
from sunwaee.cli import app


def test_list_workspaces_empty(runner, env):
    data = ok(runner.invoke(app, ["workspaces", "list"]))
    assert data == []


def test_list_workspaces(runner, env):
    runner.invoke(app, ["workspaces", "create", "personal"])
    runner.invoke(app, ["workspaces", "create", "pro"])
    data = ok(runner.invoke(app, ["workspaces", "list"]))
    names = [w["name"] for w in data]
    assert "personal" in names
    assert "pro" in names


def test_list_workspace_has_id(runner, env):
    runner.invoke(app, ["workspaces", "create", "personal"])
    data = ok(runner.invoke(app, ["workspaces", "list"]))
    assert all("id" in w for w in data)
    assert all(len(w["id"]) == 36 for w in data)


def test_list_workspace_has_body(runner, env):
    runner.invoke(app, ["workspaces", "create", "personal"])
    data = ok(runner.invoke(app, ["workspaces", "list"]))
    assert all("body" in w for w in data)


def test_list_shows_default(runner, env):
    runner.invoke(app, ["workspaces", "create", "personal"])
    runner.invoke(app, ["workspaces", "create", "pro"])
    data = ok(runner.invoke(app, ["workspaces", "list"]))
    defaults = [w for w in data if w["default"]]
    assert len(defaults) == 1
    assert defaults[0]["name"] == "personal"


def test_list_shows_default_after_update(runner, env):
    runner.invoke(app, ["workspaces", "create", "personal"])
    runner.invoke(app, ["workspaces", "create", "pro"])
    ok(runner.invoke(app, ["workspaces", "update", "pro", "--set-default"]))
    data = ok(runner.invoke(app, ["workspaces", "list"]))
    defaults = [w for w in data if w["default"]]
    assert defaults[0]["name"] == "pro"
