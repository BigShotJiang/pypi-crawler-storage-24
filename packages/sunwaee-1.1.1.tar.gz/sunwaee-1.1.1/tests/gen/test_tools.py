# standard
import json

# third party
# custom
from sunwaee.modules.gen.tools import TOOLS
from sunwaee.core.tools import ok, err, tool


def test_tools_contains_all_modules():
    names = {t.name for t in TOOLS}
    assert "workspaces" in names
    assert "tasks" in names
    assert "notes" in names


def test_tools_order():
    names = [t.name for t in TOOLS]
    assert names.index("workspaces") < names.index("tasks")
    assert names.index("tasks") < names.index("notes")


def test_all_tools_have_callable():
    for t in TOOLS:
        assert t.fn is not None, f"{t.name} has no callable"


def test_ok_returns_json_string():
    result = ok({"key": "value"})
    parsed = json.loads(result)
    assert parsed == {"ok": True, "data": {"key": "value"}}


def test_ok_with_list():
    result = ok([1, 2, 3])
    parsed = json.loads(result)
    assert parsed["ok"] is True
    assert parsed["data"] == [1, 2, 3]


def test_ok_with_none():
    result = ok(None)
    parsed = json.loads(result)
    assert parsed["data"] is None


def test_err_returns_json_string():
    result = err("Something went wrong")
    parsed = json.loads(result)
    assert parsed == {"ok": False, "error": "Something went wrong"}


def test_tool_unknown_type_falls_back_to_string():
    """An annotation that isn't a recognized type maps to {"type": "string"}."""

    class CustomType:
        pass

    @tool("Fallback type test.")
    def my_tool(x: CustomType) -> str:
        return ""

    assert my_tool._tool.parameters["properties"]["x"] == {"type": "string"}
