# standard
# third party
# custom
from ...conftest import ok, err
from sunwaee.cli import app

WS = "personal"
_BASE = ["--workspace", WS]


def _create(runner, title, **kwargs):
    args = ["tasks", "create", "--title", title, *_BASE]
    for k, v in kwargs.items():
        args += [f"--{k.replace('_', '-')}", str(v)]
    return runner.invoke(app, args)


def test_delete_basic(runner, ws):
    _create(runner, "Delete me")
    data = ok(runner.invoke(app, ["tasks", "delete", "Delete me", *_BASE]))
    assert any(d["title"] == "Delete me" for d in data["deleted"])
    e = err(runner.invoke(app, ["tasks", "read", "Delete me", *_BASE]))
    assert e["code"] == "NOT_FOUND"


def test_delete_not_found(runner, ws):
    e = err(runner.invoke(app, ["tasks", "delete", "ghost", *_BASE]))
    assert e["code"] == "NOT_FOUND"


def test_delete_cascades_subtasks(runner, ws):
    ok(_create(runner, "Parent Task"))
    runner.invoke(
        app,
        ["tasks", "create", "--title", "Child Task", "--parent", "Parent Task", *_BASE],
    )
    data = ok(runner.invoke(app, ["tasks", "delete", "Parent Task", *_BASE]))
    titles = [d["title"] for d in data["deleted"]]
    assert "Parent Task" in titles
    assert "Child Task" in titles


def test_delete_includes_path_in_result(runner, ws):
    _create(runner, "Path delete")
    data = ok(runner.invoke(app, ["tasks", "delete", "Path delete", *_BASE]))
    assert all("path" in d for d in data["deleted"])
