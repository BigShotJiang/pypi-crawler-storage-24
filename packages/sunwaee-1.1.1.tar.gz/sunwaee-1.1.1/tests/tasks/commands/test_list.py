# standard
# third party
# custom
from ...conftest import ok
from sunwaee.cli import app

WS = "personal"
_BASE = ["--workspace", WS]


def _create(runner, title, **kwargs):
    args = ["tasks", "create", "--title", title, *_BASE]
    for k, v in kwargs.items():
        args += [f"--{k.replace('_', '-')}", str(v)]
    return runner.invoke(app, args)


def test_list_empty(runner, ws):
    data = ok(runner.invoke(app, ["tasks", "list", *_BASE]))
    assert data == []


def test_list_returns_tasks(runner, ws):
    _create(runner, "Task A")
    _create(runner, "Task B")
    data = ok(runner.invoke(app, ["tasks", "list", *_BASE]))
    assert len(data) == 2


def test_list_all_workspaces(runner, ws):
    _create(runner, "In personal")
    data = ok(runner.invoke(app, ["tasks", "list"]))
    assert any(t["title"] == "In personal" for t in data)


def test_list_filter_status(runner, ws):
    _create(runner, "Todo Task")
    ok(
        runner.invoke(
            app, ["tasks", "update", "Todo Task", "--status", "in_progress", *_BASE]
        )
    )
    data = ok(runner.invoke(app, ["tasks", "list", "--status", "in_progress", *_BASE]))
    assert all(t["status"] == "in_progress" for t in data)


def test_list_filter_priority(runner, ws):
    _create(runner, "High", priority="high")
    _create(runner, "Low", priority="low")
    data = ok(runner.invoke(app, ["tasks", "list", "--priority", "high", *_BASE]))
    assert len(data) == 1
    assert data[0]["priority"] == "high"


def test_list_filter_tags(runner, ws):
    _create(runner, "Tagged", tags="dev")
    _create(runner, "Untagged")
    data = ok(runner.invoke(app, ["tasks", "list", "--tags", "dev", *_BASE]))
    assert len(data) == 1
    assert data[0]["title"] == "Tagged"


def test_list_filter_query(runner, ws):
    _create(runner, "Find me please")
    _create(runner, "Skip this")
    data = ok(runner.invoke(app, ["tasks", "list", "--query", "find", *_BASE]))
    assert len(data) == 1
    assert data[0]["title"] == "Find me please"


def test_list_filter_query_by_body(runner, ws):
    _create(runner, "A", body="searchable content")
    _create(runner, "B", body="nothing")
    data = ok(runner.invoke(app, ["tasks", "list", "--query", "searchable", *_BASE]))
    assert len(data) == 1


def test_list_filter_query_by_tag(runner, ws):
    _create(runner, "C", tags="rust")
    _create(runner, "D", tags="python")
    data = ok(runner.invoke(app, ["tasks", "list", "--query", "rust", *_BASE]))
    assert len(data) == 1


def test_list_includes_path(runner, ws):
    _create(runner, "Path task")
    data = ok(runner.invoke(app, ["tasks", "list", *_BASE]))
    assert all("path" in t for t in data)
