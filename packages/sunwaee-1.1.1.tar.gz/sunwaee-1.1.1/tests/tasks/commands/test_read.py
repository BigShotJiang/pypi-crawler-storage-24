# standard
# third party
# custom
from ...conftest import ok, err
from sunwaee.cli import app

WS = "personal"
_BASE = ["--workspace", WS]


def _create(runner, title, **kwargs):
    args = ["tasks", "create", "--title", title, *_BASE]
    for k, v in kwargs.items():
        args += [f"--{k.replace('_', '-')}", str(v)]
    return runner.invoke(app, args)


def test_read_by_title(runner, ws):
    _create(runner, "Read me", body="hello")
    data = ok(runner.invoke(app, ["tasks", "read", "Read me", *_BASE]))
    assert data["title"] == "Read me"
    assert data["body"] == "hello"
    assert "path" in data


def test_read_not_found(runner, ws):
    e = err(runner.invoke(app, ["tasks", "read", "ghost", *_BASE]))
    assert e["code"] == "NOT_FOUND"


def test_read_includes_workspace(runner, ws):
    _create(runner, "WS check")
    data = ok(runner.invoke(app, ["tasks", "read", "WS check", *_BASE]))
    assert data["workspace"] == WS
