# standard
import json as _json

# third party
# custom
from sunwaee.modules.tasks.tools import tasks as tasks_tool, TOOLS as TASK_TOOLS

WS = "personal"


def test_tool_create(env):
    data = _json.loads(tasks_tool(action="create", title="Tool Task", workspace=WS))
    assert data["ok"] is True
    assert data["data"]["title"] == "Tool Task"


def test_tool_create_missing_title(env):
    data = _json.loads(tasks_tool(action="create", workspace=WS))
    assert data["ok"] is False
    assert "title" in data["error"]


def test_tool_create_with_tags_and_body(env):
    data = _json.loads(
        tasks_tool(
            action="create",
            title="Rich",
            body="desc",
            tags=["a", "b"],
            priority="high",
            workspace=WS,
        )
    )
    assert data["data"]["tags"] == ["a", "b"]
    assert data["data"]["body"] == "desc"
    assert data["data"]["priority"] == "high"


def test_tool_create_with_parent(env):
    parent = _json.loads(tasks_tool(action="create", title="Parent", workspace=WS))
    child = _json.loads(
        tasks_tool(
            action="create",
            title="Child",
            parent_id=parent["data"]["id"],
            workspace=WS,
        )
    )
    assert child["data"]["parent_id"] == parent["data"]["id"]


def test_tool_list_empty(env):
    data = _json.loads(tasks_tool(action="list", workspace=WS))
    assert data["ok"] is True
    assert data["data"] == []


def test_tool_list(env):
    tasks_tool(action="create", title="T1", workspace=WS)
    tasks_tool(action="create", title="T2", workspace=WS)
    data = _json.loads(tasks_tool(action="list", workspace=WS))
    assert len(data["data"]) == 2


def test_tool_list_filter_status(env):
    tasks_tool(action="create", title="Todo", workspace=WS)
    tasks_tool(action="create", title="Done", workspace=WS)
    tasks_tool(action="update", query="Done", status="done", workspace=WS)
    data = _json.loads(tasks_tool(action="list", status="done", workspace=WS))
    assert all(t["status"] == "done" for t in data["data"])


def test_tool_list_filter_priority(env):
    tasks_tool(action="create", title="Hi", priority="high", workspace=WS)
    tasks_tool(action="create", title="Lo", priority="low", workspace=WS)
    data = _json.loads(tasks_tool(action="list", priority="high", workspace=WS))
    assert len(data["data"]) == 1
    assert data["data"][0]["priority"] == "high"


def test_tool_list_filter_query(env):
    tasks_tool(action="create", title="Find me", workspace=WS)
    tasks_tool(action="create", title="Skip", workspace=WS)
    data = _json.loads(tasks_tool(action="list", query="Find", workspace=WS))
    assert any(t["title"] == "Find me" for t in data["data"])


def test_tool_read(env):
    tasks_tool(action="create", title="Read Tool", body="content", workspace=WS)
    data = _json.loads(tasks_tool(action="read", query="Read Tool", workspace=WS))
    assert data["ok"] is True
    assert data["data"]["title"] == "Read Tool"
    assert data["data"]["body"] == "content"


def test_tool_read_not_found(env):
    data = _json.loads(tasks_tool(action="read", query="ghost", workspace=WS))
    assert data["ok"] is False


def test_tool_read_missing_query(env):
    data = _json.loads(tasks_tool(action="read", workspace=WS))
    assert data["ok"] is False
    assert "query" in data["error"]


def test_tool_update(env):
    tasks_tool(action="create", title="Update me", workspace=WS)
    data = _json.loads(
        tasks_tool(action="update", query="Update me", status="done", workspace=WS)
    )
    assert data["ok"] is True
    assert data["data"]["status"] == "done"


def test_tool_update_not_found(env):
    data = _json.loads(tasks_tool(action="update", query="ghost", workspace=WS))
    assert data["ok"] is False


def test_tool_update_missing_query(env):
    data = _json.loads(tasks_tool(action="update", workspace=WS))
    assert data["ok"] is False
    assert "query" in data["error"]


def test_tool_delete(env):
    tasks_tool(action="create", title="Delete me tool", workspace=WS)
    data = _json.loads(
        tasks_tool(action="delete", query="Delete me tool", workspace=WS)
    )
    assert data["ok"] is True
    gone = _json.loads(tasks_tool(action="read", query="Delete me tool", workspace=WS))
    assert gone["ok"] is False


def test_tool_delete_not_found(env):
    data = _json.loads(tasks_tool(action="delete", query="ghost", workspace=WS))
    assert data["ok"] is False


def test_tool_delete_missing_query(env):
    data = _json.loads(tasks_tool(action="delete", workspace=WS))
    assert data["ok"] is False
    assert "query" in data["error"]


def test_tool_delete_cascades_subtasks(env):
    parent = _json.loads(tasks_tool(action="create", title="Root", workspace=WS))
    _json.loads(
        tasks_tool(
            action="create",
            title="Sub",
            parent_id=parent["data"]["id"],
            workspace=WS,
        )
    )
    tasks_tool(action="delete", query="Root", workspace=WS)
    gone = _json.loads(tasks_tool(action="read", query="Sub", workspace=WS))
    assert gone["ok"] is False


def test_tools_registry():
    assert len(TASK_TOOLS) == 1
    assert TASK_TOOLS[0].name == "tasks"
    actions = TASK_TOOLS[0].parameters["properties"]["action"]["enum"]
    assert "create" in actions
    assert "list" in actions
    assert "read" in actions
    assert "update" in actions
    assert "delete" in actions
    assert "complete" not in actions
    assert "uncomplete" not in actions
