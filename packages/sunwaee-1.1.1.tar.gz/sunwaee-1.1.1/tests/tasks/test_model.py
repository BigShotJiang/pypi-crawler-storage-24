# standard
import time

# third party
# custom
from sunwaee.modules.tasks.model import Task, TaskStatus, TaskPriority


def test_model_defaults():
    t = Task(title="X")
    assert t.title == "X"
    assert t.status == TaskStatus.TODO
    assert t.priority == TaskPriority.MEDIUM
    assert t.body == ""
    assert t.tags == []
    assert t.due_date is None
    assert t.parent_id is None
    assert t.completed_at is None
    assert t.id
    assert t.created_at
    assert t.updated_at


def test_model_to_dict():
    t = Task(title="T", body="b", tags=["x"])
    d = t.to_dict()
    assert d["title"] == "T"
    assert d["body"] == "b"
    assert d["status"] == "todo"
    assert d["priority"] == "medium"
    assert d["tags"] == ["x"]


def test_model_to_frontmatter_meta():
    t = Task(title="T")
    m = t.to_frontmatter_meta()
    assert m["id"] == t.id
    assert m["title"] == "T"
    assert m["status"] == "todo"
    assert m["priority"] == "medium"


def test_model_from_dict():
    t = Task(title="T", body="b", tags=["a"])
    meta = t.to_frontmatter_meta()
    t2 = Task.from_dict(meta, "b")
    assert t2.id == t.id
    assert t2.title == "T"
    assert t2.body == "b"
    assert t2.tags == ["a"]


def test_model_from_dict_defaults():
    t = Task.from_dict({}, "")
    assert t.status == TaskStatus.TODO
    assert t.priority == TaskPriority.MEDIUM


def test_model_touch_updates_updated_at():
    t = Task(title="T")
    before = t.updated_at
    time.sleep(0.01)
    t.touch()
    assert t.updated_at > before
