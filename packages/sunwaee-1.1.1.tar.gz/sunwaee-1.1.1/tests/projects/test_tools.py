# standard
import json

# third party
# custom
from sunwaee.modules.projects.tools import projects, TOOLS as PROJECT_TOOLS

WS = "personal"


def test_project_tool_list_empty(ws):
    data = json.loads(projects(action="list", workspace=WS))
    assert data["ok"] is True
    assert data["data"] == []


def test_project_tool_list(ws):
    projects(action="create", name="alpha", workspace=WS)
    data = json.loads(projects(action="list", workspace=WS))
    assert data["ok"] is True
    assert any(p["name"] == "alpha" for p in data["data"])


def test_project_tool_list_has_metadata(ws):
    projects(action="create", name="alpha", workspace=WS)
    data = json.loads(projects(action="list", workspace=WS))
    entry = data["data"][0]
    assert "id" in entry
    assert "body" in entry
    assert "workspace" in entry
    assert "default" in entry


def test_project_tool_create(ws, tmp_path):
    data = json.loads(projects(action="create", name="myproject", workspace=WS))
    assert data["ok"] is True
    assert data["data"]["name"] == "myproject"
    assert data["data"]["workspace"] == WS
    assert "id" in data["data"]
    assert (tmp_path / "workspaces" / WS / "projects" / "myproject").is_dir()


def test_project_tool_create_with_body(ws):
    data = json.loads(projects(action="create", name="myproject", workspace=WS, body="Details"))
    assert data["ok"] is True
    assert data["data"]["body"] == "Details"


def test_project_tool_create_requires_name(ws):
    data = json.loads(projects(action="create", workspace=WS))
    assert data["ok"] is False


def test_project_tool_create_duplicate_errors(ws):
    projects(action="create", name="myproject", workspace=WS)
    data = json.loads(projects(action="create", name="myproject", workspace=WS))
    assert data["ok"] is False


def test_project_tool_read(ws):
    projects(action="create", name="myproject", workspace=WS, body="My project")
    data = json.loads(projects(action="read", name="myproject", workspace=WS))
    assert data["ok"] is True
    assert data["data"]["name"] == "myproject"
    assert data["data"]["body"] == "My project"
    assert data["data"]["workspace"] == WS
    assert "id" in data["data"]
    assert "default" in data["data"]


def test_project_tool_read_requires_name(ws):
    data = json.loads(projects(action="read", workspace=WS))
    assert data["ok"] is False


def test_project_tool_read_not_found_errors(ws):
    data = json.loads(projects(action="read", name="ghost", workspace=WS))
    assert data["ok"] is False


def test_project_tool_update_body(ws):
    projects(action="create", name="myproject", workspace=WS)
    data = json.loads(projects(action="update", name="myproject", workspace=WS, body="Updated"))
    assert data["ok"] is True
    assert data["data"]["body"] == "Updated"


def test_project_tool_update_set_default(ws):
    projects(action="create", name="alpha", workspace=WS)
    projects(action="create", name="beta", workspace=WS)
    data = json.loads(projects(action="update", name="alpha", workspace=WS, set_default=True))
    assert data["ok"] is True
    assert data["data"]["default"] is True


def test_project_tool_update_requires_name(ws):
    data = json.loads(projects(action="update", workspace=WS))
    assert data["ok"] is False


def test_project_tool_update_no_changes_errors(ws):
    projects(action="create", name="myproject", workspace=WS)
    data = json.loads(projects(action="update", name="myproject", workspace=WS))
    assert data["ok"] is False


def test_project_tool_update_not_found_errors(ws):
    data = json.loads(projects(action="update", name="ghost", workspace=WS, body="x"))
    assert data["ok"] is False


def test_project_tools_registry():
    assert len(PROJECT_TOOLS) == 1
    assert PROJECT_TOOLS[0].name == "projects"
    assert PROJECT_TOOLS[0].fn is not None
