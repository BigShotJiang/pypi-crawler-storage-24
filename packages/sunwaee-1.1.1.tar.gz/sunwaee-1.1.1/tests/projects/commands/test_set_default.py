# removed: set-default command replaced by `projects update --set-default`
# tests moved to test_update.py
