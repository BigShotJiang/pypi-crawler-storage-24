# standard
# third party
# custom
from ...conftest import ok, err
from sunwaee.cli import app

WS = "personal"
_BASE = ["--workspace", WS]


def test_create_project(runner, ws):
    data = ok(runner.invoke(app, ["projects", "create", "myproject", *_BASE]))
    assert data["name"] == "myproject"
    assert data["workspace"] == WS
    assert "myproject" in data["path"]
    assert "id" in data
    assert len(data["id"]) == 36


def test_create_project_creates_directory(runner, ws, tmp_path):
    runner.invoke(app, ["projects", "create", "myproject", *_BASE])
    assert (tmp_path / "workspaces" / WS / "projects" / "myproject").is_dir()


def test_create_project_writes_metadata(runner, ws, tmp_path):
    runner.invoke(app, ["projects", "create", "myproject", *_BASE])
    assert (tmp_path / "workspaces" / WS / "projects" / "myproject" / "metadata.md").exists()


def test_create_project_with_body(runner, ws):
    data = ok(runner.invoke(app, ["projects", "create", "myproject", "--body", "My project", *_BASE]))
    assert data["body"] == "My project"


def test_create_duplicate_project_errors(runner, ws):
    runner.invoke(app, ["projects", "create", "myproject", *_BASE])
    e = err(runner.invoke(app, ["projects", "create", "myproject", *_BASE]))
    assert e["code"] == "ALREADY_EXISTS"


def test_create_project_in_specific_workspace(runner, env):
    runner.invoke(app, ["workspaces", "create", "pro"])
    data = ok(runner.invoke(app, ["projects", "create", "alpha", "--workspace", "pro"]))
    assert data["workspace"] == "pro"
    assert data["name"] == "alpha"
