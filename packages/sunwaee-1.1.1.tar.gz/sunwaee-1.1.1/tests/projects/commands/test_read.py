# standard
# third party
# custom
from ...conftest import ok, err
from sunwaee.cli import app

WS = "personal"
_BASE = ["--workspace", WS]


def test_read_project(runner, ws):
    runner.invoke(app, ["projects", "create", "myproject", *_BASE])
    data = ok(runner.invoke(app, ["projects", "read", "myproject", *_BASE]))
    assert data["name"] == "myproject"
    assert data["workspace"] == WS
    assert "id" in data
    assert "body" in data
    assert "default" in data


def test_read_project_has_uuid(runner, ws):
    runner.invoke(app, ["projects", "create", "myproject", *_BASE])
    data = ok(runner.invoke(app, ["projects", "read", "myproject", *_BASE]))
    assert len(data["id"]) == 36


def test_read_project_default_flag(runner, ws):
    runner.invoke(app, ["projects", "create", "alpha", *_BASE])
    runner.invoke(app, ["projects", "create", "beta", *_BASE])
    runner.invoke(app, ["projects", "update", "alpha", "--set-default", *_BASE])
    data = ok(runner.invoke(app, ["projects", "read", "alpha", *_BASE]))
    assert data["default"] is True
    data2 = ok(runner.invoke(app, ["projects", "read", "beta", *_BASE]))
    assert data2["default"] is False


def test_read_project_with_body(runner, ws):
    runner.invoke(app, ["projects", "create", "myproject", "--body", "Details", *_BASE])
    data = ok(runner.invoke(app, ["projects", "read", "myproject", *_BASE]))
    assert data["body"] == "Details"


def test_read_nonexistent_project_errors(runner, ws):
    e = err(runner.invoke(app, ["projects", "read", "ghost", *_BASE]))
    assert e["code"] == "NOT_FOUND"
