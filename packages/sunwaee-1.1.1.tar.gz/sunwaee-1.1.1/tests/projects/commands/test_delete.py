# standard
# third party
# custom
from ...conftest import ok, err
from sunwaee.cli import app

WS = "personal"
_BASE = ["--workspace", WS]


def _create(runner, name):
    return runner.invoke(app, ["projects", "create", name, *_BASE])


def test_delete_requires_confirm(runner, ws):
    _create(runner, "myproject")
    e = err(runner.invoke(app, ["projects", "delete", "myproject", *_BASE]))
    assert e["code"] == "CONFIRMATION_REQUIRED"


def test_delete_project(runner, ws, tmp_path):
    _create(runner, "myproject")
    ok(runner.invoke(app, ["projects", "delete", "myproject", "--confirm", *_BASE]))
    assert not (tmp_path / "workspaces" / WS / "projects" / "myproject").exists()


def test_delete_returns_name_and_workspace(runner, ws):
    _create(runner, "myproject")
    data = ok(runner.invoke(app, ["projects", "delete", "myproject", "--confirm", *_BASE]))
    assert data["name"] == "myproject"
    assert data["workspace"] == WS


def test_delete_nonexistent_errors(runner, ws):
    e = err(runner.invoke(app, ["projects", "delete", "ghost", "--confirm", *_BASE]))
    assert e["code"] == "NOT_FOUND"


def test_delete_removes_project_contents(runner, ws, tmp_path):
    _create(runner, "myproject")
    project_dir = tmp_path / "workspaces" / WS / "projects" / "myproject"
    (project_dir / "notes").mkdir(parents=True)
    (project_dir / "notes" / "note.md").write_text("hello")
    ok(runner.invoke(app, ["projects", "delete", "myproject", "--confirm", *_BASE]))
    assert not project_dir.exists()
