# standard
# third party
# custom
from sunwaee.modules.logs.model import LogEntry


### LOG ENTRY


def test_log_entry_to_dict_full():
    e = LogEntry(
        id="11111111-0000-0000-0000-000000000000",
        timestamp="2026-03-02T10:00:00+00:00",
        caller="api",
        workspace="personal",
        module="notes",
        operation="create",
        ok=True,
        item_id="abc-123",
        item_title="My Note",
    )
    d = e.to_dict()
    assert d["id"] == "11111111-0000-0000-0000-000000000000"
    assert d["timestamp"] == "2026-03-02T10:00:00+00:00"
    assert d["caller"] == "api"
    assert d["workspace"] == "personal"
    assert d["module"] == "notes"
    assert d["operation"] == "create"
    assert d["ok"] is True
    assert d["item_id"] == "abc-123"
    assert d["item_title"] == "My Note"


def test_log_entry_to_dict_omits_none_optionals():
    e = LogEntry(
        timestamp="2026-03-02T10:00:00+00:00",
        caller="human",
        workspace="personal",
        module="tasks",
        operation="delete",
    )
    d = e.to_dict()
    assert "item_id" not in d
    assert "item_title" not in d


def test_log_entry_from_dict_roundtrip():
    original = LogEntry(
        id="aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
        timestamp="2026-03-02T10:00:00+00:00",
        caller="sun",
        workspace="work",
        module="tasks",
        operation="complete",
        ok=True,
        item_id="xyz-789",
        item_title="Finish docs",
    )
    restored = LogEntry.from_dict(original.to_dict())
    assert restored.id == original.id
    assert restored.timestamp == original.timestamp
    assert restored.caller == original.caller
    assert restored.workspace == original.workspace
    assert restored.module == original.module
    assert restored.operation == original.operation
    assert restored.ok == original.ok
    assert restored.item_id == original.item_id
    assert restored.item_title == original.item_title


def test_log_entry_from_dict_missing_fields_use_defaults():
    e = LogEntry.from_dict({})
    assert len(e.id) == 36  # auto-generated uuid when missing
    assert e.timestamp == ""
    assert e.caller == ""
    assert e.ok is True
    assert e.item_id is None
    assert e.item_title is None


def test_log_entry_id_in_dict():
    e = LogEntry(
        id="test-uuid",
        timestamp="ts",
        caller="api",
        workspace="personal",
        module="notes",
        operation="create",
    )
    assert e.to_dict()["id"] == "test-uuid"


def test_log_entry_id_is_auto_generated():
    e = LogEntry("ts", "api", "personal", "notes", "create")
    assert len(e.id) == 36
    assert e.id.count("-") == 4
    assert e.to_dict()["id"] == e.id


def test_log_entry_matches_id():
    e = LogEntry(
        id="abcd1234-ef00-0000-0000-000000000000",
        timestamp="ts",
        caller="api",
        workspace="personal",
        module="notes",
        operation="create",
    )
    assert e.matches("abcd1234")
    assert e.matches("ABCD1234")
    assert not e.matches("zzznomatch")


def test_log_entry_matches_item_title():
    e = LogEntry(
        "ts", "human", "personal", "notes", "create", item_title="My Important Note"
    )
    assert e.matches("important")
    assert e.matches("IMPORTANT")
    assert not e.matches("tasks")


def test_log_entry_matches_item_id():
    e = LogEntry("ts", "human", "personal", "notes", "create", item_id="abc-123-def")
    assert e.matches("abc-123")
    assert not e.matches("xyz")


def test_log_entry_matches_module():
    e = LogEntry("ts", "human", "personal", "tasks", "create")
    assert e.matches("tasks")
    assert not e.matches("notes")


def test_log_entry_matches_operation():
    e = LogEntry("ts", "human", "personal", "notes", "delete")
    assert e.matches("delete")
    assert not e.matches("create")


def test_log_entry_matches_caller():
    e = LogEntry("ts", "api", "personal", "notes", "create")
    assert e.matches("api")
    assert not e.matches("sun")


def test_log_entry_matches_workspace():
    e = LogEntry("ts", "human", "work", "notes", "create")
    assert e.matches("work")
    assert not e.matches("personal")


def test_log_entry_no_match():
    e = LogEntry("ts", "human", "personal", "notes", "create", item_title="My Note")
    assert not e.matches("zzznomatch")


def test_log_entry_args_in_dict():
    e = LogEntry(
        "ts", "api", "personal", "notes", "list", args={"results": 5, "query": "python"}
    )
    d = e.to_dict()
    assert d["args"] == {"results": 5, "query": "python"}


def test_log_entry_empty_args_omitted():
    e = LogEntry("ts", "api", "personal", "notes", "list", args={})
    assert "args" not in e.to_dict()


def test_log_entry_args_restored_from_dict():
    e = LogEntry.from_dict(
        {
            "timestamp": "ts",
            "caller": "api",
            "workspaces": "w",
            "module": "notes",
            "operation": "list",
            "args": {"results": 3},
        }
    )
    assert e.args == {"results": 3}
