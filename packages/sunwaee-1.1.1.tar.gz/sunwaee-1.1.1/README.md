# SUNWÆE CLI

The Almost Everything command-line interface for [SUNWÆE](https://sunwaee.com). Manage notes, tasks, projects, and workspaces from the terminal — and chat with Sun, the built-in AI agent.

---

## Installation

```bash
pip install sunwaee
```

Or for local development:

```bash
git clone https://github.com/sunwaee/cli
cd cli
pip install -e .
```

Run once after installation:

```bash
sunwaee init                # creates 'personal' workspace (default)
sunwaee init --workspace pro
```

---

## Modules

### Workspaces

Top-level containers. Everything lives inside a workspace.

```bash
sunwaee workspaces create personal
sunwaee workspaces create work --body "Client projects"
sunwaee workspaces list
sunwaee workspaces read personal
sunwaee workspaces update personal --body "Updated description"
sunwaee workspaces update work --set-default
sunwaee workspaces delete old-workspace --confirm
```

→ [sunwaee/modules/workspaces/README.md](sunwaee/modules/workspaces/README.md)

---

### Projects

Group notes and tasks within a workspace.

```bash
sunwaee projects create client-site --workspace work
sunwaee projects create client-site --body "ACME redesign, due Q3"
sunwaee projects list --workspace work
sunwaee projects read client-site --workspace work
sunwaee projects update client-site --body "Scope updated: includes mobile"
sunwaee projects update client-site --set-default
sunwaee projects delete old-project --confirm
```

→ [sunwaee/modules/projects/README.md](sunwaee/modules/projects/README.md)

---

### Notes

Markdown notes with tags, stored as files.

```bash
sunwaee notes create --title "Meeting notes" --body "Discussed roadmap." --tags "work,q1"
sunwaee notes list
sunwaee notes list --query "roadmap" --workspace work
sunwaee notes read "Meeting notes"
sunwaee notes update "Meeting notes" --body "Updated content."
sunwaee notes delete "Meeting notes" --confirm
```

→ [sunwaee/modules/notes/README.md](sunwaee/modules/notes/README.md)

---

### Tasks

Tasks with status, priority, due dates, and subtasks.

```bash
sunwaee tasks create --title "Fix login bug" --priority high --due 2026-03-01
sunwaee tasks list
sunwaee tasks list --status todo --priority high
sunwaee tasks read "Fix login bug"
sunwaee tasks update "Fix login bug" --status in_progress
sunwaee tasks delete "Fix login bug"
```

→ [sunwaee/modules/tasks/README.md](sunwaee/modules/tasks/README.md)

---

### Logs

Every operation is automatically logged. Browse the audit trail.

```bash
sunwaee logs list                              # today, all workspaces
sunwaee logs list --workspace personal         # single workspace
sunwaee logs list --date 2026-03-01            # specific day
sunwaee logs list --month 2026-03              # full month
sunwaee logs list --all                        # all time
sunwaee logs list --module notes --operation create
sunwaee logs list --query "meeting"
sunwaee logs read <id>                         # full detail on one entry
```

→ [sunwaee/modules/logs/README.md](sunwaee/modules/logs/README.md)

---

### Gen (AI agent)

Interactive AI chat with full access to your data and shell.

```bash
sunwaee gen                                    # start a session
sunwaee gen --model claude-opus-4-6
sunwaee gen --session abc12345                 # resume session
sunwaee gen models list                        # available models + pricing
sunwaee gen sessions list                      # saved sessions
sunwaee gen set-model                          # pick default model
```

Supports Anthropic, OpenAI, Google, DeepSeek, xAI, and Moonshot. Reasoning shown live for models that support it.

→ [sunwaee/modules/gen/README.md](sunwaee/modules/gen/README.md)

---

## Data storage

Everything is stored as Markdown files with YAML frontmatter — human-readable and Git-friendly. Each workspace folder is a git repository.

```
~/sunwaee/workspaces/
└── personal/
    ├── metadata.md
    ├── notes/
    ├── tasks/
    ├── projects/
    ├── gen/
    └── logs/
```

---

## Output modes

The `SUNWAEE_CALLER` env var controls output format:

| Value   | Output                       | Used by              |
| ------- | ---------------------------- | -------------------- |
| `human` | Rich colored terminal output | Default              |
| `api`   | JSON                         | SUNWÆE app / scripts |
| `sun`   | JSON                         | Sun AI agent         |

```json
{"ok": true, "data": {...}}
{"ok": false, "error": "Note not found", "code": "NOT_FOUND"}
```

Error codes: `NOT_FOUND`, `ALREADY_EXISTS`, `VALIDATION_ERROR`, `IO_ERROR`, `CONFIRMATION_REQUIRED`.

---

## Configuration

Config file at `~/.sunwaee/config.toml`. All values can be overridden with environment variables:

| Variable                 | Default                | Purpose                   |
| ------------------------ | ---------------------- | ------------------------- |
| `SUNWAEE_WORKSPACES_DIR` | `~/sunwaee/workspaces` | Data root                 |
| `SUNWAEE_CONFIG_DIR`     | `~/.sunwaee`           | Config root               |
| `SUNWAEE_WORKSPACE`      | `personal`             | Active workspace override |
| `SUNWAEE_CALLER`         | `human`                | Output mode               |
| `SUNWAEE_LOG_LEVEL`      | `warning`              | Log verbosity             |

---

## License

[MIT](LICENSE)
