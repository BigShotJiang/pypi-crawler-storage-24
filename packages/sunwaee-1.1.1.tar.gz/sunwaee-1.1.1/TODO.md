# TODO

- all list/read commands should have same output format (list: simple table with colors on certain columns, read: plain text/potentially markdown-parsed)
- for create, update, delete commands, show git diff
- all list commands should show id in first col, and entering a partial id in any other command should find the corresponding record intelligently
- make sunwaee init command output better
- all list commands should show path column with path from "~"

# DONE

## 2026-03-10

- changed: enhance git diff display (in core)
