import codecs
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("rot13")


@mcp.tool()
def rot13_encode(text: str) -> str:
    """对文本进行 ROT13 编码（字母旋转 13 位，再次编码即为解码）。"""
    return codecs.encode(text, "rot_13")


def main():
    mcp.run()


if __name__ == "__main__":
    main()
