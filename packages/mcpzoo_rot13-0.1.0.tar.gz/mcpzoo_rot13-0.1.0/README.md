# mcpzoo-rot13

> ROT13 编码 — 对英文文本进行 ROT13 旋转编码

## Installation

```bash
uvx mcpzoo-rot13
```

## uvx JSON

```json
{
  "mcpServers": {
    "rot13": {
      "args": ["mcpzoo-rot13"],
      "command": "uvx"
    }
  }
}
```
