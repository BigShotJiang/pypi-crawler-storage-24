#!/usr/bin/env python3
"""Confluence MCP Server - CLI entry point

Usage:
    confluence-mcp          # MCP 서버 실행
    confluence-mcp --setup  # Claude Code에 자동 등록 (인터랙티브)
"""

import os
import readline  # noqa: F401 — enables proper line editing (backspace, arrow keys) in input()
import shutil
import subprocess
import sys


def setup():
    """Claude Code에 Confluence MCP를 인터랙티브하게 등록"""
    print()
    print("=" * 50)
    print("  Confluence MCP - Claude Code 설정")
    print("=" * 50)
    print()

    # 1. Confluence URL
    print("[1/3] Confluence URL")
    print("  예: https://yourcompany.atlassian.net")
    url = input("  URL: ").strip().rstrip("/")
    if not url:
        print("  ❌ URL을 입력해주세요.")
        sys.exit(1)

    # 2. Email
    print()
    print("[2/3] Atlassian 계정 이메일")
    email = input("  이메일: ").strip()
    if not email:
        print("  ❌ 이메일을 입력해주세요.")
        sys.exit(1)

    # 3. API Token
    print()
    print("[3/3] API Token")
    print("  발급: https://id.atlassian.com/manage-profile/security/api-tokens")
    print("  → 'Create API token' 클릭 → 복사")
    token = input("  토큰: ").strip()
    if not token:
        print("  ❌ 토큰을 입력해주세요.")
        sys.exit(1)

    # claude CLI 찾기 (uvx 환경은 PATH가 제한적이므로 일반적인 위치도 탐색)
    claude_bin = shutil.which("claude")
    if not claude_bin:
        search_paths = [
            "/opt/homebrew/bin/claude",
            "/usr/local/bin/claude",
            os.path.expanduser("~/.npm-global/bin/claude"),
            os.path.expanduser("~/.local/bin/claude"),
        ]
        for p in search_paths:
            if os.path.isfile(p) and os.access(p, os.X_OK):
                claude_bin = p
                break

    if not claude_bin:
        _print_manual_instructions(url, email, token)
        return

    # claude mcp add 실행
    print()
    print("Claude Code에 등록 중...")

    env_cmd = [
        claude_bin, "mcp", "add", "confluence",
        "-s", "user",
        "-e", f"CONFLUENCE_URL={url}",
        "-e", f"CONFLUENCE_EMAIL={email}",
        "-e", f"CONFLUENCE_API_TOKEN={token}",
        "--",
        "uvx", "confluence-cloud-mcp",
    ]

    try:
        env = os.environ.copy()
        extra_paths = "/opt/homebrew/bin:/usr/local/bin"
        env["PATH"] = f"{extra_paths}:{env.get('PATH', '')}"

        # 기존 등록이 있으면 먼저 제거
        subprocess.run(
            [claude_bin, "mcp", "remove", "confluence", "-s", "user"],
            capture_output=True, text=True, env=env,
        )

        result = subprocess.run(env_cmd, capture_output=True, text=True, env=env)
        if result.returncode == 0:
            print()
            print("✅ 설치 완료!")
            print()
            print("Claude Code를 재시작하면 Confluence 도구를 사용할 수 있습니다.")
            print("테스트: Claude Code에서 'Confluence 공간 목록 보여줘' 입력")
        else:
            if result.stderr:
                print(f"  [debug] {result.stderr.strip()}")
            _print_manual_instructions(url, email, token)
    except Exception as e:
        print(f"  [debug] {e}")
        _print_manual_instructions(url, email, token)


def _print_manual_instructions(url: str, email: str, token: str):
    """자동 등록 실패 시 수동 설정 안내"""
    print()
    print("⚠️  자동 등록에 실패했습니다. 아래 명령어를 터미널에 직접 붙여넣으세요:")
    print()
    print(f'  claude mcp add confluence -s user \\')
    print(f'    -e "CONFLUENCE_URL={url}" \\')
    print(f'    -e "CONFLUENCE_EMAIL={email}" \\')
    print(f'    -e "CONFLUENCE_API_TOKEN={token}" \\')
    print(f'    -- uvx confluence-cloud-mcp')


def main():
    if "--setup" in sys.argv:
        setup()
    else:
        from confluence_mcp.server import mcp
        mcp.run()


if __name__ == "__main__":
    main()
