"""Confluence MCP Server - Claude Code용 Confluence 통합"""

__version__ = "0.1.4"
