# confluence-cloud-mcp

Confluence Cloud MCP server for [Claude Code](https://claude.ai/code).

The official Atlassian connector covers basic page read/write. This server adds **27 tools** including section-level editing, table CRUD, smart diff updates, attachments, and space export.

## Prerequisites

`uvx` is required (comes with [uv](https://docs.astral.sh/uv/)).

```bash
# uvx가 없다면 먼저 uv를 설치하세요
curl -LsSf https://astral.sh/uv/install.sh | sh
source ~/.zshrc  # 또는 터미널을 새로 열기
```

## Install (1 minute)

### Option A: Interactive setup

```bash
uvx confluence-cloud-mcp --setup
```

Asks for your Confluence URL, email, and API token, then auto-registers with Claude Code.

### Option B: One-liner

```bash
claude mcp add confluence -s user \
  -e "CONFLUENCE_URL=https://yourcompany.atlassian.net" \
  -e "CONFLUENCE_EMAIL=you@company.com" \
  -e "CONFLUENCE_API_TOKEN=your-token" \
  -- uvx confluence-cloud-mcp
```

### API Token

1. Go to https://id.atlassian.com/manage-profile/security/api-tokens
2. Click **Create API token**
3. Copy the token

## Tools (27)

### Page Management
| Tool | Description |
|------|-------------|
| `list_spaces` | List accessible spaces |
| `get_page` | Get page by ID or URL |
| `get_page_full` | Get full page content with formatting |
| `create_page` | Create new page |
| `update_page` | Update existing page |
| `append_to_page` | Append content to page |
| `search_pages` | Search pages by keyword |

### Section Editing
| Tool | Description |
|------|-------------|
| `list_page_sections` | List all headings in a page |
| `update_page_section` | Update a specific section by heading |
| `smart_update_page` | Diff-aware update (skip if unchanged) |

### Table Operations
| Tool | Description |
|------|-------------|
| `get_page_tables` | Extract tables from page |
| `update_page_table` | Modify table content |
| `add_table_row` | Add row to table |
| `delete_table_row` | Delete row from table |
| `update_table_cell` | Update specific cell |
| `create_page_with_table` | Create page with table |

### Attachments & Export
| Tool | Description |
|------|-------------|
| `upload_attachment` | Upload file to page |
| `upload_attachments` | Upload multiple files |
| `download_page_images` | Download all images |
| `download_page_attachments` | Download all attachments |
| `export_page` | Export page to Markdown |
| `export_space` | Export space to Markdown files |
| `sync_space` | Sync space to local filesystem |

### Database
| Tool | Description |
|------|-------------|
| `list_databases` | List Confluence databases |
| `get_database` | Get database metadata |
| `create_database` | Create database |
| `delete_database` | Delete database |

## Markdown Support

Write content in Markdown — it auto-converts to Confluence Storage Format.

Supported: headings, bold/italic, lists, tables, code blocks, links, images, horizontal rules.

## Requirements

- Python 3.10+
- Confluence Cloud (Atlassian hosted)
- API token with read/write access

## License

MIT
