"""OpenSoul MCP - Open Source Personality Profiling System."""

__version__ = "0.1.0"
