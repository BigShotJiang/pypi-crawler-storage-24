# submit — Homework submission tools

Small Python tools to prepare and submit homework assignments:

- **Online submission**: uploads a (optionally encrypted) bundle as a **private GitHub Gist** via the GitHub CLI (`gh`).
- **Offline submission**: creates a ZIP file you can upload manually.

Implementation:

- Online entrypoint: [`submit.submit:run`](src/submit/submit.py) (function: [`submit.submit.run`](src/submit/submit.py))
- Offline implementation: [`submit.submit_offline.main`](src/submit/submit_offline.py)

---

## Workspace files

- Configuration template/example: [submit.cfg](submit.cfg)
- Example payload files: [testdatei1.txt](testdatei1.txt), [testdatei2.txt](testdatei2.txt)
- Package metadata / entrypoints: [pyproject.toml](pyproject.toml)
- Included public key: [src/submit/gpg/htw.asc](src/submit/gpg/htw.asc) (defaults in [`submit.gpg.public_key_name`](src/submit/gpg/__init__.py) and [`submit.gpg.public_key_file`](src/submit/gpg/__init__.py))

---

## Requirements

- Python **>= 3.10** (see [.python-version](.python-version))
- Online submission:
  - `curl` installed
  - `gh` installed (the github cli)
  - authenticated (`gh auth login`) or run `submit --authorize` or provide a token from github via the environment variable `GH_TOKEN`
- Encryption:
  - `gpg` installed

The online tool checks required CLIs in [`submit.submit.check_tools`](src/submit/submit.py) and installs/verifies the default public key via [`submit.submit.check_default_gpg_key`](src/submit/submit.py).

---

## Installation

This project defines a console script entrypoint in [pyproject.toml](pyproject.toml):

- `submit` → [`submit.submit:run`](src/submit/submit.py)

Install into your environment using your preferred tool (pip/uv/etc.), then run `submit` from the directory that contains your assignment’s `submit.cfg`.

---

## Configuration (`submit.cfg`)

Place a `submit.cfg` in the directory you want to submit from.

Minimal example (same structure as [submit.cfg](submit.cfg)):

```ini
[Uebung]
aufgabe = 99

[Abgeben]
datei1 = testdatei1.txt
datei2 = testdatei2.txt
```

Notes:

- `[Uebung].aufgabe` must be an integer $0 \leq \text{aufgabe} \leq 99$.
- Under `[Abgeben]`, **all files must exist**, otherwise submission aborts (see [`submit.submit.check_local_config`](src/submit/submit.py) / [`submit.submit_offline.checklocalconfig`](src/submit/submit_offline.py)).

---

## Usage

### Online (default)

From the directory containing [submit.cfg](submit.cfg):

```sh
submit
```

This will:

1. copy the files listed in `[Abgeben]` to a temp directory (see [`submit.submit.copy_files`](src/submit/submit.py))
2. encrypt them by default (see [`submit.submit.encrypt`](src/submit/submit.py))
3. create a private gist upload (see [`submit.submit.submit`](src/submit/submit.py))

### Offline (create ZIP for manual upload)

This mode should only be used when promped by the lecture.

From the directory containing [submit.cfg](submit.cfg):

```sh
submit --offline
```

This will:

1. copy the files listed in `[Abgeben]` to a temp directory (see [`submit.submit_offline.copyfiles`](src/submit/submit_offline.py))
2. (by default) encrypt them (see [`submit.submit_offline.encrypt`](src/submit/submit_offline.py))
3. create a ZIP in your current directory (see [`submit.submit_offline.submit`](src/submit/submit_offline.py))

Disable encryption (offline only):

```sh
submit --offline --no-encryption
```
