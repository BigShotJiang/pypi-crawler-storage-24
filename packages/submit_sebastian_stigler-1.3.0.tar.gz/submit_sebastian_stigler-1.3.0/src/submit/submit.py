#!/usr/bin/python3
# vim: ft=python et ai ts=4

import configparser
import os
import subprocess
import argparse
import tempfile
import re
import sys
import shutil
import time
import logging

from importlib.metadata import version
from submit.gpg import public_key_name, public_key_file

GLOBAL_CONFIG = "~/.submitrc"
LOCAL_CONFIG = "submit.cfg"

__version__ = version("submit-sebastian-stigler")
logger = logging.getLogger(__name__)


def parse_cmd():
    parser = argparse.ArgumentParser(description="Homework submission script")
    parser.add_argument(
        "-a",
        "--authorize",
        dest="authorize",
        default=False,
        action="store_true",
        help="Authorize the 'gh' backend for upload to github.",
    )
    parser.add_argument(
        "-ne",
        "--no-encryption",
        dest="encrypt",
        default=True,
        action="store_false",
        help="Don't encrypt files before upload (default: encrypt files).",
    )
    parser.add_argument(
        "--offline",
        dest="offline",
        default=False,
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument("--version", action="version", version=f"submit {__version__}")
    parser.add_argument(
        "-v",
        "--verbose",
        dest="loglevel",
        help=argparse.SUPPRESS,
        action="store_const",
        const=logging.INFO,
    )
    parser.add_argument(
        "-vv",
        "--very-verbose",
        dest="loglevel",
        help=argparse.SUPPRESS,
        action="store_const",
        const=logging.DEBUG,
    )

    args = parser.parse_args()
    return args


def checkauth():
    """Check if gists is already authorized.
    return username or None (when not authorized)"""

    res = subprocess.run(
        "gh auth status > /dev/null",
        shell=True,
    )
    return res.returncode == 0


def authorize():
    chk = "n"
    token = ""
    while chk != "y":
        token = input("github token: ")
        chk = input(
            "Do you want to authorize with the token '%s' [y/N]? " % token
        ).lower()

    res = subprocess.Popen(
        "gh auth login --with-token",
        shell=True,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    res_stdout, res_stderr = res.communicate(token.encode())

    output = res_stdout.decode().strip().split("\n")
    output += res_stderr.decode().strip().split("\n")

    if len("".join(output)) > 0:
        print("Error in authorize() function:")
        print("\n".join(output), file=sys.stderr)
        exit(1)
    subprocess.Popen("gh auth status", shell=True).communicate(b"\n")
    return True


def check_global_config(global_config=GLOBAL_CONFIG):
    config = configparser.ConfigParser()
    if os.path.isfile(os.path.expanduser(global_config)):
        config.read(os.path.expanduser(global_config))
    if "encrypt" not in config or "user" not in config["encrypt"]:
        config["encrypt"] = {}
        config["encrypt"]["user"] = public_key_name
        with open(os.path.expanduser(global_config), "w") as cfg_file:
            config.write(cfg_file)
    return config


def check_local_config(local_config=LOCAL_CONFIG):
    config = configparser.ConfigParser()
    if not os.path.isfile(local_config):
        print(
            "Error: File '%s' not found." % local_config,
            "Make sure, that you call 'submit' in the",
            "directory which contains the '%s' file." % local_config,
            file=sys.stderr,
            sep="\n",
        )
        exit(1)
    config.read(local_config)
    if "Uebung" not in config or "Abgeben" not in config:
        print(
            "Error: The file '%s' has the wrong format." % local_config,
            "Make sure it is the file provided by your current homework.",
            "If the file was the one, provided by the zip file of",
            "your current homework, send a mail at:",
            "sebastian.stigler@hs-aalen.de",
            file=sys.stderr,
            sep="\n",
        )
    err = False
    for token in config["Abgeben"]:
        if not os.path.isfile(config["Abgeben"][token]):
            print(
                "Error: File '%s' should be submitted but is missing,"
                % (config["Abgeben"][token]),
                file=sys.stderr,
            )
            err = True
    if err:
        exit(1)
    return config


def encrypt(srcfile, dst_file, directory, user):
    sf = os.path.join(directory, srcfile)
    df = os.path.join(directory, dst_file)
    if not os.path.isdir(directory):
        print("Error: Directory '%s' does not exist." % directory, file=sys.stderr)
        exit(1)
    if not os.path.isfile(sf):
        print("Error: File '%s' does not exist." % sf, file=sys.stderr)
        exit(1)
    res = subprocess.Popen(
        'gpg --always-trust --output "%s" -a -e -r "%s" --batch --yes "%s"'
        % (df, user, sf),
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    res.wait()
    if res.returncode != 0:
        output = []
        for line in res.stdout.readlines():  # pyright: ignore[reportOptionalMemberAccess]
            output.append(line.decode("utf-8").strip())
        for line in res.stderr.readlines():  # pyright: ignore[reportOptionalMemberAccess]
            output.append(line.decode("utf-8").strip())
        print("Error in encrypt() function:")
        print("\n".join(output), file=sys.stderr)
        exit(1)


def submit(filenames, directory, description):
    if not os.path.isdir(directory):
        print("Error in submit() function:", file=sys.stderr)
        print("Error: Directory '%s' does not exist." % directory, file=sys.stderr)
        exit(1)
    for filename in filenames:
        sf = os.path.join(directory, filename)
        if not os.path.isfile(sf):
            print("Error in submit() function:", file=sys.stderr)
            print("Error: File '%s' does not exist." % sf, file=sys.stderr)
            exit(1)
    old_directory = os.getcwd()
    os.chdir(directory)
    try:
        command = 'gh gist create -p -d "%s" -f %s ' % (
            description,
            " ".join(filenames),
        )
        # print(command)
        # print(os.listdir())
        res = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        res.wait()
    finally:
        os.chdir(old_directory)

    output = []
    for line in res.stdout.readlines():  # pyright: ignore[reportOptionalMemberAccess]
        output.append(line.decode("utf-8").strip())
    for line in res.stderr.readlines():  # pyright: ignore[reportOptionalMemberAccess]
        output.append(line.decode("utf-8").strip())

    err = "^Traceback"
    r_err = re.compile(err)
    print("\n".join(output))

    if (
        len(output) < 3
        or not res.returncode == 0
        or (len(r_err.findall(output[0])) > 0)
    ):
        print(
            "",
            "Error in submission. Try again.",
            "If the error persist, send a mail at: ",
            "sebastian.stigler@hs-aalen.de",
            file=sys.stderr,
            sep="\n",
        )
        exit(1)
    else:
        print("\nSubmission successful.")


def check_internet():
    res = subprocess.Popen(
        "curl -I https://github.com -qSs",
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    res.wait()
    if res.returncode != 0:
        print(
            "Error: No connection to github.com.",
            "You need a active internet connection for submission!",
            file=sys.stderr,
            sep="\n",
        )
        exit(1)


def copy_files(filenames, directory):
    if not os.path.isdir(directory):
        print("Error in copy_files() function:", file=sys.stderr)
        print("Error: Directory '%s' does not exist." % directory, file=sys.stderr)
        exit(1)
    for filename in filenames:
        sf = os.path.join(os.getcwd(), filename)
        if not os.path.isfile(sf):
            print("Error in copy_files() function:", file=sys.stderr)
            print("Error: File '%s' does not exist." % sf, file=sys.stderr)
            exit(1)
    for filename in filenames:
        try:
            shutil.copy(os.path.join(os.getcwd(), filename), directory)
        except (IOError, os.error) as why:
            print(
                "Error in copy_files() function:", str(why), file=sys.stderr, sep="\n"
            )
            exit(1)


def main(cmd):
    gconfig = check_global_config()
    lconfig = check_local_config()

    check_internet()
    is_authorized = checkauth()
    if not is_authorized or cmd.authorize:
        is_authorized = authorize()
        if cmd.authorize:
            exit()

    with tempfile.TemporaryDirectory() as temp_dir:
        files = list(lconfig["Abgeben"].values())
        copy_files(files, temp_dir)
        if cmd.encrypt:
            files = []
            for file in lconfig["Abgeben"].values():
                encrypt(file, file + ".asc", temp_dir, gconfig["encrypt"]["user"])
                files.append(file + ".asc")
        lconfig["submit"] = {}
        lconfig["submit"]["encrypt"] = str(cmd.encrypt)
        lconfig["submit"]["time"] = str(int(time.time()))
        with open(os.path.join(temp_dir, LOCAL_CONFIG), "w") as configfile:
            lconfig.write(configfile)
        files.insert(0, LOCAL_CONFIG)
        files.insert(0, LOCAL_CONFIG)  # Workaround: gh omits the first file
        desc = "TuD Uebung %s, submit %s" % (
            lconfig["Uebung"]["aufgabe"],
            lconfig["submit"]["time"],
        )
        # print(files)
        submit(files, temp_dir, desc)


def check_default_gpg_key():
    logger.info(f"Check default gpg key for {public_key_name}.")
    res = subprocess.Popen(
        f"gpg --list-key {public_key_name}",
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    res.wait()
    if res.returncode != 0:
        logger.info("The default public gpg key not found. Trying to install it.")
        res2 = subprocess.Popen(
            f"gpg --import {public_key_file}",
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        res2.wait()
        if res2.returncode != 0:
            logger.info(
                f"Unable to install default public gpg key {public_key_file} for {public_key_name}."
            )
            print(
                f"Unable to install default public gpg key {public_key_file} for {public_key_name}."
            )
            exit(1)
        logger.info("The default public gpg key is now installed.")
        res = subprocess.Popen(
            f"gpg --list-key {public_key_name}",
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        res.wait()
        if res.returncode != 0:
            logger.info("The gpg key installation could not be verified")
            print(f"Default puplic gpg key for {public_key_name} not found.")
            exit(1)
        logger.info(
            f"Verified installation of the default public gpg key for {public_key_name}."
        )
    else:
        logger.info("Default gpg key is installed.")


def check_tools():
    logger.info("Check required cli tools")
    for tool in ["curl", "gh", "gpg"]:
        res = subprocess.Popen(
            f"{tool} --help",
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        res.wait()
        if res.returncode != 0:
            logger.info(f"  - {tool} not installed")
            print(f"The tool '{tool}' must be installed for submit to work.")
            exit(1)
        logger.info(f"  - {tool} installed")


def run():
    cmd = parse_cmd()
    logging.basicConfig(level=cmd.loglevel)
    check_tools()
    if cmd.encrypt:
        check_default_gpg_key()
    if cmd.offline:
        import submit.submit_offline as so

        so.main(cmd)
    else:
        main(cmd)


if __name__ == "__main__":
    run()
