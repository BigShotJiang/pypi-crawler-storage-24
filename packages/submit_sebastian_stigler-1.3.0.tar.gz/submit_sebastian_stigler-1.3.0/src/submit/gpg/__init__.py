import os.path

_current_dir = os.path.dirname(os.path.abspath(__file__))

public_key_name = "sebastian.stigler@htw-aalen.de"
public_key_file = os.path.join(_current_dir, "htw.asc")
