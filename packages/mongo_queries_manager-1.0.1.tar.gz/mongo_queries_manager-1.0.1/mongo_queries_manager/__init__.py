#!/usr/bin/env python3
# Copyright (c) Dangla Théo, 2026

"""MongoDBQueriesManager module."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any
from urllib import parse

from mongo_queries_manager.helpers import is_blacklisted_value, parse_query_operation
from mongo_queries_manager.mongodb_queries_manager import (
    CustomCasterFail,
    FilterError,
    LimitError,
    ListOperatorError,
    LogicalPopulationError,
    LogicalSubPopulationError,
    MongoDBQueriesManager,
    MongoDBQueriesManagerBaseError,
    ProjectionError,
    SkipError,
    TextOperatorError,
)

__version__ = "1.0.1"

__all__ = [
    "mqm",
    "MongoDBQueriesManagerBaseError",
    "SkipError",
    "LimitError",
    "ListOperatorError",
    "FilterError",
    "CustomCasterFail",
    "TextOperatorError",
    "ProjectionError",
    "LogicalPopulationError",
    "LogicalSubPopulationError",
]


def _sort_population(populate: str) -> int:
    """Used to sort population list by level (.) into populate value.

    Args:
        populate (str): Populate value.

    Returns:
        int: Return the number of . (level) into populate value.
    """
    return populate.count(".")


def mqm(
    string_query: str,
    blacklist: list[str] | None = None,
    casters: dict[str, Callable[[Any], Any]] | None = None,
    populate: bool = False,
) -> dict[str, Any]:
    """This method convert a string query into a MongoDB query dict.

    Args:
        string_query (str): A query string of the requested API URL.
        blacklist (Optional[List[str]]): Filter on all keys except the ones specified.
        populate (bool): Add population into returned query (Manual implementation).
        casters (Optional[Dict[str, Callable]]): Custom caster dict, used to define custom type.

    Returns:
        Dict[str, Any]: Return a mongodb query in dict format.
    """
    args: list[str] = list(parse.unquote(string_query).split("&"))
    mongodb_queries_mgr: MongoDBQueriesManager = MongoDBQueriesManager(casters=casters)
    mongodb_query: dict[str, Any] = {
        "filter": {},
        "sort": None,
        "skip": 0,
        "limit": 0,
        "projection": None,
    }

    if populate:
        mongodb_query["population"] = []

        populates_values = []
        for arg in args:
            if arg.startswith("populate=") and arg != "populate=":
                populates_values = (
                    arg.split("=")[1].split(",") if arg.split("=")[1].find(",") > 0 else [arg.split("=")[1]]
                )

        for populate_value in sorted(populates_values, key=_sort_population):
            mongodb_queries_mgr.format_populate_value(mongodb_query, population_value=populate_value)

    for arg in args:
        # Skip blacklisted value
        if blacklist and is_blacklisted_value(blacklist, arg):
            continue

        mongodb_query = parse_query_operation(
            mongodb_query=mongodb_query, arg=arg, mongodb_queries_mgr=mongodb_queries_mgr, populate=populate
        )

    return mongodb_query
