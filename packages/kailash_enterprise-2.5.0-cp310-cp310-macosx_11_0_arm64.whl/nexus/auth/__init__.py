"""Nexus auth subpackage.

Provides JWT configuration and auth utilities::

    from nexus.auth import JWTConfig
"""

import dataclasses
from typing import List, Optional


@dataclasses.dataclass
class JWTConfig:
    """JWT authentication configuration.

    Args:
        secret: Secret key for signing/verifying tokens (min 32 chars).
        algorithm: JWT algorithm (default: ``"HS256"``).
        exempt_paths: URL paths that bypass JWT validation.
        expiry_seconds: Token expiry in seconds (default: 3600).
    """

    secret: str = ""
    algorithm: str = "HS256"
    exempt_paths: Optional[List[str]] = None
    expiry_seconds: int = 3600

    def __post_init__(self):
        if self.exempt_paths is None:
            self.exempt_paths = []


__all__ = ["JWTConfig"]
