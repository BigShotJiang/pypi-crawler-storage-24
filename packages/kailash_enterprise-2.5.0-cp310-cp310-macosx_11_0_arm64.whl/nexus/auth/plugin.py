"""Nexus auth plugin."""

import dataclasses
from typing import Any, Dict, List, Optional

from nexus.auth import JWTConfig
from nexus.auth.audit.config import AuditConfig


@dataclasses.dataclass
class NexusAuthPlugin:
    """Authentication plugin for Nexus applications.

    Bundles JWT, RBAC, audit, and rate-limit configuration into a single
    plugin that can be added to a Nexus app via ``app.add_plugin()``.

    Args:
        jwt: JWT configuration.
        rbac: RBAC role definitions mapping role names to permission lists.
        rbac_default_role: Default role for unauthenticated users.
        audit: Audit logging configuration.
        rate_limit: Rate limiting configuration.
        tenant_header: HTTP header name for tenant identification.
    """

    jwt: Optional[JWTConfig] = None
    rbac: Optional[Dict[str, List[str]]] = None
    rbac_default_role: str = "viewer"
    audit: Optional[AuditConfig] = None
    rate_limit: Optional[Any] = None
    tenant_header: str = "X-Tenant-ID"


__all__ = ["NexusAuthPlugin"]
