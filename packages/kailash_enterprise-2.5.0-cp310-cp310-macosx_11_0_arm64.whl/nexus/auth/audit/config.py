"""Audit configuration for Nexus auth."""

import dataclasses
from typing import Optional


@dataclasses.dataclass
class AuditConfig:
    """Audit logging configuration.

    Args:
        backend: Audit backend type (``"logging"``, ``"database"``, ``"file"``).
        log_level: Log level for audit events (default: ``"INFO"``).
        include_request_body: Whether to log request bodies (default: False).
        include_response_body: Whether to log response bodies (default: False).
        retention_days: Number of days to retain audit logs (default: 90).
    """

    backend: str = "logging"
    log_level: str = "INFO"
    include_request_body: bool = False
    include_response_body: bool = False
    retention_days: int = 90
    database_url: Optional[str] = None
    file_path: Optional[str] = None


__all__ = ["AuditConfig"]
