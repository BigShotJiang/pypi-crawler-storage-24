"""Nexus -- multi-channel deployment platform (top-level package).

Provides the Nexus application class and auth utilities::

    from nexus import Nexus
    from nexus.auth import JWTConfig
    from nexus.auth.audit.config import AuditConfig
    from nexus.auth.plugin import NexusAuthPlugin

The ``Nexus`` class is a web application with ``@handler()`` decorator
support, middleware management, and ASGI compatibility.
"""

import inspect
import logging
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class Nexus:
    """Multi-channel deployment application.

    Provides a handler-registry pattern with ``@handler()`` decorator,
    middleware management, route registration, and plugin support.
    Compatible with ASGI servers (uvicorn) for production deployment.

    Args:
        auto_discovery: Enable auto-discovery of handlers (default: True).
        api_port: Port for the HTTP server (default: 8000).
        cors_origins: List of allowed CORS origins.
        cors_allow_credentials: Allow credentials in CORS (default: False).
        enable_durability: Enable durable execution (default: False).
        **kwargs: Additional configuration passed to the underlying server.
    """

    def __init__(
        self,
        auto_discovery: bool = True,
        api_port: int = 8000,
        cors_origins: Optional[List[str]] = None,
        cors_allow_credentials: bool = False,
        enable_durability: bool = False,
        **kwargs: Any,
    ) -> None:
        self.auto_discovery = auto_discovery
        self.api_port = api_port
        self.cors_origins = cors_origins or []
        self.cors_allow_credentials = cors_allow_credentials
        self.enable_durability = enable_durability
        self._extra_config = kwargs

        # Handler registry: {name: {"handler": func, "description": str, "params": list}}
        self._handler_registry: Dict[str, Dict[str, Any]] = {}
        # Middleware stack (LIFO order)
        self._middleware_classes: List[Any] = []
        # Plugins (keyed by type-derived name for backwards compat)
        self._plugins: Dict[str, Any] = {}
        # Routes
        self._routes: List[Dict[str, Any]] = []
        self._websocket_routes: List[Dict[str, Any]] = []
        # ASGI app (lazily created)
        self._asgi_app: Optional[Any] = None

    def handler(
        self,
        name: Optional[str] = None,
        description: str = "",
        params: Optional[List[Any]] = None,
    ) -> Callable:
        """Decorator to register a handler function.

        If *params* is not given, parameters are inferred from the
        function signature.

        Args:
            name: Handler name. Defaults to ``func.__name__``.
            description: Human-readable description.
            params: Explicit parameter list.

        Returns:
            The original function, unmodified.
        """

        def decorator(func: Callable) -> Callable:
            handler_name = name if name is not None else func.__name__
            handler_desc = description or (func.__doc__ or "").strip().split("\n")[0]
            handler_params = params or self._extract_params(func)
            self._handler_registry[handler_name] = {
                "handler": func,
                "description": handler_desc,
                "params": handler_params,
            }
            return func

        return decorator

    def register_handler(
        self,
        name: str,
        func: Callable,
        params: Optional[List[Any]] = None,
        description: str = "",
    ) -> None:
        """Register a handler function directly (non-decorator form).

        Args:
            name: Handler name.
            func: The handler callable.
            params: Explicit parameter list.
            description: Human-readable description.
        """
        handler_params = params or self._extract_params(func)
        self._handler_registry[name] = {
            "handler": func,
            "description": description,
            "params": handler_params,
        }

    def add_middleware(self, middleware_cls: Any, **kwargs: Any) -> None:
        """Add a middleware class to the application stack.

        Middleware is applied in LIFO order (last added = outermost).

        Args:
            middleware_cls: The middleware class.
            **kwargs: Additional keyword arguments for the middleware.
        """
        self._middleware_classes.append((middleware_cls, kwargs))

    def add_plugin(self, plugin: Any) -> None:
        """Add a plugin to the application.

        Plugins are stored by a derived name (e.g. ``NexusAuthPlugin`` ->
        ``"nexus_auth"``). This allows ``"nexus_auth" in app._plugins``
        lookups.

        Args:
            plugin: A plugin instance (e.g. NexusAuthPlugin).
        """
        # Derive a snake_case key from the class name
        cls_name = type(plugin).__name__
        # NexusAuthPlugin -> nexus_auth (remove "Plugin" suffix, convert to snake_case)
        key = cls_name
        if key.endswith("Plugin"):
            key = key[:-6]
        # Simple CamelCase to snake_case
        import re
        key = re.sub(r"(?<!^)(?=[A-Z])", "_", key).lower()
        self._plugins[key] = plugin

    def add_route(
        self,
        path: str,
        endpoint: Callable,
        methods: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Register an HTTP route.

        Args:
            path: URL path pattern (e.g. ``"/api/v1/users"``).
            endpoint: ASGI endpoint callable.
            methods: HTTP methods (e.g. ``["GET", "POST"]``).
        """
        self._routes.append({
            "path": path,
            "endpoint": endpoint,
            "methods": methods or ["GET"],
            **kwargs,
        })

    def add_websocket_route(
        self,
        path: str,
        endpoint: Callable,
        **kwargs: Any,
    ) -> None:
        """Register a WebSocket route.

        Args:
            path: URL path pattern (e.g. ``"/ws/sessions/{id}"``).
            endpoint: WebSocket handler callable.
        """
        self._websocket_routes.append({
            "path": path,
            "endpoint": endpoint,
            **kwargs,
        })

    @property
    def _gateway(self) -> "_GatewayCompat":
        """Backwards-compatible gateway accessor.

        The old Nexus SDK exposed ``app._gateway.app`` for ASGI testing.
        Returns a shim whose ``.app`` attribute is this Nexus instance itself.
        """
        return _GatewayCompat(self)

    def get_registered_handlers(self) -> List[Dict[str, Any]]:
        """Return metadata for all registered handlers."""
        return [
            {"name": name, "description": info["description"], "params": info["params"]}
            for name, info in self._handler_registry.items()
        ]

    @property
    def handler_count(self) -> int:
        """Number of registered handlers."""
        return len(self._handler_registry)

    async def __call__(self, scope: dict, receive: Callable, send: Callable) -> None:
        """ASGI application interface for uvicorn/daphne/hypercorn."""
        if self._asgi_app is None:
            self._asgi_app = self._build_asgi_app()
        await self._asgi_app(scope, receive, send)

    def _build_asgi_app(self) -> Any:
        """Build the ASGI application with Starlette.

        Auto-registers ``/workflows/{name}/execute`` POST routes for each
        handler in the registry (backwards-compatible gateway pattern).
        """
        try:
            from starlette.applications import Starlette
            from starlette.requests import Request
            from starlette.responses import JSONResponse
            from starlette.routing import Route, WebSocketRoute
        except ImportError:
            return self._fallback_asgi_app

        routes = []

        # Auto-register gateway-style routes for each handler
        for handler_name, handler_info in self._handler_registry.items():
            handler_fn = handler_info["handler"]

            def _make_endpoint(fn: Callable) -> Callable:
                async def endpoint(request: Request) -> JSONResponse:
                    import time
                    import uuid
                    start = time.monotonic()
                    body = await request.json() if await request.body() else {}
                    try:
                        if inspect.iscoroutinefunction(fn):
                            result = await fn(**body)
                        else:
                            result = fn(**body)
                        elapsed = time.monotonic() - start
                        return JSONResponse({
                            "outputs": {"handler": result},
                            "execution_time": round(elapsed, 4),
                            "run_id": str(uuid.uuid4()),
                        })
                    except (ValueError, LookupError, PermissionError, TypeError) as exc:
                        return JSONResponse(
                            {"error": str(exc)},
                            status_code=400,
                        )
                return endpoint

            routes.append(Route(
                f"/workflows/{handler_name}/execute",
                _make_endpoint(handler_fn),
                methods=["POST"],
            ))

        for r in self._routes:
            routes.append(Route(r["path"], r["endpoint"], methods=r.get("methods")))
        for ws in self._websocket_routes:
            routes.append(WebSocketRoute(ws["path"], ws["endpoint"]))

        app = Starlette(routes=routes)

        # Apply middleware in reverse order (LIFO)
        for middleware_cls, kwargs in reversed(self._middleware_classes):
            app.add_middleware(middleware_cls, **kwargs)

        return app

    async def _fallback_asgi_app(
        self, scope: dict, receive: Callable, send: Callable
    ) -> None:
        """Minimal ASGI fallback when Starlette is not available."""
        if scope["type"] == "http":
            body = b'{"error": "starlette not installed"}'
            await send({
                "type": "http.response.start",
                "status": 503,
                "headers": [[b"content-type", b"application/json"]],
            })
            await send({"type": "http.response.body", "body": body})

    @staticmethod
    def _extract_params(func: Callable) -> List[Dict[str, Any]]:
        """Extract parameter metadata from a function signature."""
        sig = inspect.signature(func)
        params = []
        type_map = {int: "integer", float: "number", bool: "boolean", str: "string"}
        for param_name, param in sig.parameters.items():
            if param_name in ("self", "cls"):
                continue
            param_type = "string"
            if param.annotation is not inspect.Parameter.empty:
                param_type = type_map.get(param.annotation, "string")
            required = param.default is inspect.Parameter.empty
            params.append({
                "name": param_name,
                "type": param_type,
                "required": required,
            })
        return params

    def __repr__(self) -> str:
        return f"Nexus(handlers={len(self._handler_registry)}, port={self.api_port})"


class _GatewayCompat:
    """Shim for ``app._gateway.app`` backwards compatibility."""

    def __init__(self, nexus: Nexus) -> None:
        self._nexus = nexus

    @property
    def app(self) -> Any:
        """Return the ASGI application (builds lazily on first access)."""
        if self._nexus._asgi_app is None:
            self._nexus._asgi_app = self._nexus._build_asgi_app()
        return self._nexus._asgi_app


__all__ = ["Nexus"]
