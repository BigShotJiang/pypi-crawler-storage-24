"""DataFlow tenancy subpackage."""

from dataflow.tenancy.interceptor import QueryInterceptor

__all__ = ["QueryInterceptor"]
