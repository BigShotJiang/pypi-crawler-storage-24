"""DataFlow QueryInterceptor with old-style keyword argument API.

Provides backwards-compatible constructor::

    from dataflow.tenancy.interceptor import QueryInterceptor

    interceptor = QueryInterceptor(
        tenant_id="acme-001",
        non_tenant_tables=["tenants"],
        tenant_column="tenant_id",
    )

Internally wraps the Rust-backed QueryInterceptor via TenantContext.
"""

from kailash._kailash import QueryInterceptor as _RustQueryInterceptor
from kailash._kailash import TenantContext


class QueryInterceptor:
    """Multi-tenant query interceptor with keyword-argument API.

    Wraps the Rust-backed QueryInterceptor, accepting the old-style
    keyword arguments for backwards compatibility with existing code.

    Args:
        tenant_id: The tenant identifier to filter queries by.
        non_tenant_tables: Table names exempt from tenant filtering.
        tenant_column: Column name for tenant ID (default: ``"tenant_id"``).
        admin_mode: If True, bypass tenant filtering entirely.
        tenant_tables: Explicit list of tables to filter (unused, for compat).
    """

    def __init__(
        self,
        tenant_id: str = "",
        *,
        tenant_tables: list | None = None,
        non_tenant_tables: list | None = None,
        tenant_column: str = "tenant_id",
        admin_mode: bool = False,
    ):
        self._tenant_id = tenant_id
        self._non_tenant_tables = set(non_tenant_tables or [])
        self._tenant_column = tenant_column
        self._admin_mode = admin_mode

        if admin_mode or not tenant_id:
            self._inner = None
        else:
            ctx = TenantContext(tenant_id, column_name=tenant_column)
            self._inner = _RustQueryInterceptor(ctx)

    def intercept_query(self, sql: str) -> str:
        """Intercept a SQL query to add tenant filtering.

        Args:
            sql: The original SQL query.

        Returns:
            The modified SQL with tenant WHERE clause, or the original
            if admin_mode is True, no tenant_id is set, or the table
            is in non_tenant_tables.
        """
        if self._inner is None:
            return sql
        # Check non-tenant tables
        sql_upper = sql.upper()
        for table in self._non_tenant_tables:
            if table.upper() in sql_upper:
                return sql
        return self._inner.intercept_query(sql)

    def intercept_select(self, sql: str) -> str:
        """Intercept a SELECT query specifically.

        Args:
            sql: The original SELECT query.

        Returns:
            The modified SQL with tenant WHERE clause.
        """
        if self._inner is None:
            return sql
        sql_upper = sql.upper()
        for table in self._non_tenant_tables:
            if table.upper() in sql_upper:
                return sql
        return self._inner.intercept_select(sql)

    @property
    def tenant_id(self) -> str:
        return self._tenant_id

    @property
    def tenant_column(self) -> str:
        return self._tenant_column

    @property
    def admin_mode(self) -> bool:
        return self._admin_mode
