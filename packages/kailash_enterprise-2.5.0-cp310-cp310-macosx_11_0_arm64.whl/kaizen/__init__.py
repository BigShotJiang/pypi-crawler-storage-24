"""Kaizen -- AI agent framework (top-level package).

Re-exports from ``kailash.kaizen`` for backwards compatibility::

    from kaizen.api import Agent
    from kaizen.api.result import AgentResult, ToolCallRecord
"""

from kailash.kaizen import (
    Agent as _RustAgent,
    AgentConfig,
    CostTracker,
    LlmClient,
    OrchestrationRuntime,
    ToolParam,
    ToolDef,
    ToolRegistry,
    SessionMemory,
    SharedMemory,
    AgentCheckpoint,
    InMemoryCheckpointStorage,
    FileCheckpointStorage,
    AgentCard,
    AgentRegistry,
    InMemoryMessageBus,
    A2AProtocol,
    TrustLevel,
    TrustPosture,
    BaseAgent,
    HookManager,
    InputField,
    OutputField,
    Signature,
    InterruptManager,
    ControlProtocol,
)

__all__ = [
    "AgentConfig",
    "CostTracker",
    "LlmClient",
    "OrchestrationRuntime",
    "ToolParam",
    "ToolDef",
    "ToolRegistry",
    "SessionMemory",
    "SharedMemory",
    "AgentCheckpoint",
    "InMemoryCheckpointStorage",
    "FileCheckpointStorage",
    "AgentCard",
    "AgentRegistry",
    "InMemoryMessageBus",
    "A2AProtocol",
    "TrustLevel",
    "TrustPosture",
    "BaseAgent",
    "HookManager",
    "InputField",
    "OutputField",
    "Signature",
    "InterruptManager",
    "ControlProtocol",
]
