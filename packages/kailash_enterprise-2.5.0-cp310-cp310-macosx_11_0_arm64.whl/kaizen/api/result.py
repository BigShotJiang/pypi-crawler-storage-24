"""Agent result types for Kaizen API.

Provides ``AgentResult`` and ``ToolCallRecord`` dataclasses::

    from kaizen.api.result import AgentResult, ToolCallRecord

    result = AgentResult(text="Hello!", run_id="abc-123")
    tool = ToolCallRecord(name="search", arguments={"query": "test"})
"""

import dataclasses
from typing import Any, Optional


@dataclasses.dataclass
class ToolCallRecord:
    """Record of a single tool call made by the agent.

    Attributes:
        name: Tool name.
        arguments: Arguments passed to the tool.
        result: Tool execution result (None if not executed yet).
        error: Error message if the tool call failed.
        duration_ms: Execution duration in milliseconds.
        timestamp: When the tool call was made (epoch seconds).
        cycle: TAOD loop iteration number.
    """

    name: str = ""
    arguments: Optional[dict[str, Any]] = None
    result: Optional[str] = None
    error: Optional[str] = None
    duration_ms: int = 0
    timestamp: float = 0.0
    cycle: int = 0


@dataclasses.dataclass
class AgentResult:
    """Result from an Agent.run() call.

    Attributes:
        text: The agent's text response.
        run_id: Unique identifier for this run.
        model_used: The LLM model that was used.
        duration_ms: Total execution time in milliseconds.
        input_tokens: Number of input/prompt tokens.
        output_tokens: Number of output/completion tokens.
        total_tokens: Total tokens used.
        cost: Estimated cost in USD.
        tool_calls: List of tool call records.
        iterations: Number of TAOD loop iterations.
    """

    text: str = ""
    run_id: str = ""
    model_used: str = ""
    duration_ms: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    cost: float = 0.0
    tool_calls: list[ToolCallRecord] = dataclasses.field(default_factory=list)
    iterations: int = 1


__all__ = ["AgentResult", "ToolCallRecord"]
