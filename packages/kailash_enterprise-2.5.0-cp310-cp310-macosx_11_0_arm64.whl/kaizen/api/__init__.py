"""Kaizen Agent API with old-style constructor kwargs.

Provides the ``Agent`` class used by aerith::

    from kaizen.api import Agent

    agent = Agent(
        model="gpt-4o",
        system_prompt="You are helpful.",
        execution_mode="autonomous",
        tool_access="constrained",
        tools=[{"name": "search", ...}],
    )
    result = await agent.run("Hello")
"""

import asyncio
from typing import Any, Optional

from kaizen.api.result import AgentResult, ToolCallRecord


class Agent:
    """AI agent with keyword-argument constructor and async ``run()`` method.

    Wraps the Rust-backed Kaizen Agent, providing the old-style constructor
    that accepts ``model``, ``system_prompt``, ``execution_mode``, etc.
    The Rust agent is lazily initialized on first ``run()`` call.

    Args:
        model: LLM model name (resolved from env if None).
        system_prompt: System prompt for the agent.
        execution_mode: ``"single"`` (one-shot) or ``"autonomous"`` (TAOD loop).
        tool_access: ``"none"`` or ``"constrained"``.
        tools: List of tool definition dicts.
        **kwargs: Additional configuration (ignored for compatibility).
    """

    def __init__(
        self,
        model: Optional[str] = None,
        system_prompt: Optional[str] = None,
        execution_mode: str = "single",
        tool_access: str = "none",
        tools: Optional[list[dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> None:
        self._model = model
        self._system_prompt = system_prompt
        self.execution_mode = execution_mode
        self.tool_access = tool_access
        self.tools = tools or []
        self._extra = kwargs
        self._rust_agent = None

    @property
    def model(self) -> Optional[str]:
        """The model name."""
        return self._model

    def _ensure_agent(self) -> Any:
        """Lazily create the Rust-backed Agent."""
        if self._rust_agent is not None:
            return self._rust_agent
        from kailash._kailash import AgentConfig
        from kailash._kailash import Agent as RustAgent

        config = AgentConfig(
            model=self._model,
            system_prompt=self._system_prompt,
        )
        self._rust_agent = RustAgent(config)
        return self._rust_agent

    async def run(self, content: str) -> AgentResult:
        """Run the agent with a prompt.

        Args:
            content: The user message to process.

        Returns:
            An ``AgentResult`` with the agent's response and metadata.
        """
        agent = self._ensure_agent()
        loop = asyncio.get_running_loop()
        result_dict = await loop.run_in_executor(None, agent.run, content)

        tool_calls = []
        if isinstance(result_dict, dict):
            text = result_dict.get("response", "")
            run_id = result_dict.get("session_id", "")
            duration_ms = result_dict.get("duration_ms", 0)
            input_tokens = result_dict.get("prompt_tokens", 0)
            output_tokens = result_dict.get("completion_tokens", 0)
            total_tokens = result_dict.get("total_tokens", 0)
        else:
            text = str(result_dict)
            run_id = ""
            duration_ms = 0
            input_tokens = 0
            output_tokens = 0
            total_tokens = 0

        return AgentResult(
            text=text,
            run_id=run_id,
            model_used=self._model or "",
            duration_ms=duration_ms,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
            tool_calls=tool_calls,
        )

    def __repr__(self) -> str:
        return f"Agent(model={self._model!r}, mode={self.execution_mode!r})"


__all__ = ["Agent"]
