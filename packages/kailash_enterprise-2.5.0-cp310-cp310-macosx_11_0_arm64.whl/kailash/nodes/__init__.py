"""Backward-compatible nodes subpackage.

Provides the v0.12 import path ``from kailash.nodes.base import NodeRegistry``.
"""

from kailash.nodes.base import NodeRegistry

__all__ = ["NodeRegistry"]
