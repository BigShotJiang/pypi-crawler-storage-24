"""Backward-compatible node base classes.

Provides the v0.12 import path ``from kailash.nodes.base import NodeRegistry``.
"""

from kailash._kailash import NodeRegistry

__all__ = ["NodeRegistry"]
