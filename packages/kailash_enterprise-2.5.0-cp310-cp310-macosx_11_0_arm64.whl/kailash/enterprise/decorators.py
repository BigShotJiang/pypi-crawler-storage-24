"""Enterprise decorators for permission enforcement, audit logging, and tenant scoping.

Provides three decorators that integrate with the enterprise context system:

- ``@requires_permission(resource, action)`` -- RBAC gate
- ``@audit_action(event_type, resource_type)`` -- audit trail
- ``@tenant_scoped`` -- injects ``tenant_id`` kwarg from context

Module-level evaluator and audit logger are configured via ``set_evaluator()``
and ``set_audit_logger()`` respectively.

Usage::

    from kailash.enterprise.decorators import requires_permission, set_evaluator
    from kailash.enterprise import RbacEvaluator, Role, Permission

    evaluator = RbacEvaluator([Role("admin").with_permission(Permission.global_wildcard())])
    set_evaluator(evaluator)

    @requires_permission("users", "read")
    def list_users():
        return [...]
"""

import functools
from typing import Any, Callable, Optional, TypeVar

from kailash._kailash import AuditLogger, RbacEvaluator

from kailash.enterprise.context import get_current_tenant, get_current_user

F = TypeVar("F", bound=Callable[..., Any])

_evaluator: Optional[RbacEvaluator] = None
_audit_logger: Optional[AuditLogger] = None


def set_evaluator(evaluator: RbacEvaluator) -> None:
    """Set the module-level RBAC evaluator used by ``@requires_permission``."""
    global _evaluator
    _evaluator = evaluator


def get_evaluator() -> Optional[RbacEvaluator]:
    """Return the current module-level RBAC evaluator, or ``None``."""
    return _evaluator


def set_audit_logger(logger: AuditLogger) -> None:
    """Set the module-level audit logger used by ``@audit_action``."""
    global _audit_logger
    _audit_logger = logger


def get_audit_logger() -> Optional[AuditLogger]:
    """Return the current module-level audit logger, or ``None``."""
    return _audit_logger


def requires_permission(resource: str, action: str) -> Callable[[F], F]:
    """Decorator that enforces RBAC permission before function execution.

    Retrieves the current user from the enterprise context and checks
    the module-level evaluator. Raises ``PermissionError`` if the user
    lacks the required permission, or if no evaluator/user is configured.

    Args:
        resource: The resource identifier (e.g. ``"users"``).
        action: The action identifier (e.g. ``"read"``).
    """

    def decorator(fn: F) -> F:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if _evaluator is None:
                raise PermissionError(
                    "No RBAC evaluator configured. Call set_evaluator() first."
                )
            user = get_current_user()
            if user is None:
                raise PermissionError(
                    "No current user set. Call set_current_user() first."
                )
            if not _evaluator.check(user, resource, action):
                raise PermissionError(
                    f"User {user.user_id!r} lacks permission "
                    f"{resource!r}:{action!r}"
                )
            return fn(*args, **kwargs)

        return wrapper  # type: ignore[return-value]

    return decorator


def audit_action(event_type: str, resource_type: str) -> Callable[[F], F]:
    """Decorator that logs function entry and outcome to the audit trail.

    Logs a ``data_access`` (or whatever *event_type* is) audit event before
    the decorated function runs. On success the event is logged with
    ``success=True``; if an exception propagates, it is logged as
    ``success=False`` and then re-raised.

    Args:
        event_type: Audit event type (e.g. ``"data_access"``).
        resource_type: The resource type being accessed (e.g. ``"users"``).
    """

    def decorator(fn: F) -> F:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if _audit_logger is None:
                return fn(*args, **kwargs)

            user = get_current_user()
            actor_id = user.user_id if user is not None else "anonymous"

            try:
                result = fn(*args, **kwargs)
            except Exception:
                _audit_logger.log_event(
                    event_type, "user", actor_id, resource_type, fn.__name__, False
                )
                raise
            else:
                _audit_logger.log_event(
                    event_type, "user", actor_id, resource_type, fn.__name__, True
                )
                return result

        return wrapper  # type: ignore[return-value]

    return decorator


def tenant_scoped(fn: F) -> F:
    """Decorator that injects the current tenant ID as a ``tenant_id`` kwarg.

    Reads the tenant from the enterprise context. If no tenant is set the
    function is called without the kwarg (the function should handle the
    absence or provide a default).
    """

    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        tenant = get_current_tenant()
        if tenant is not None:
            kwargs["tenant_id"] = tenant
        return fn(*args, **kwargs)

    return wrapper  # type: ignore[return-value]
