"""Combined RBAC + ABAC evaluator with configurable strategy.

Wraps the Rust-backed ``RbacEvaluator`` and ``AbacEvaluator`` to provide a
single entry point for access decisions with two strategies:

- **deny_override** (default): access is denied if *either* evaluator denies.
- **first_applicable**: uses the RBAC result; falls back to ABAC only when
  RBAC cannot determine the outcome (user has no matching role).

Usage::

    from kailash.enterprise import RbacEvaluator, AbacEvaluator, Role, Permission, AbacPolicy
    from kailash.enterprise.combined import CombinedEvaluator

    rbac = RbacEvaluator([Role("admin").with_permission(Permission("docs", "read"))])
    abac = AbacEvaluator([AbacPolicy("p1", "allow").with_action("read")])
    combined = CombinedEvaluator(rbac, abac, strategy="deny_override")
    result = combined.evaluate(user, "docs", "read")
"""

from typing import Any, Dict, Optional

from kailash._kailash import AbacEvaluator, RbacEvaluator, User


class CombinedEvaluator:
    """Unified RBAC + ABAC access evaluator.

    Args:
        rbac_evaluator: A configured ``RbacEvaluator`` instance.
        abac_evaluator: A configured ``AbacEvaluator`` instance.
        strategy: ``"deny_override"`` (default) or ``"first_applicable"``.

    Raises:
        ValueError: If *strategy* is not one of the two accepted values.
    """

    def __init__(
        self,
        rbac_evaluator: RbacEvaluator,
        abac_evaluator: AbacEvaluator,
        strategy: str = "deny_override",
    ) -> None:
        if strategy not in ("deny_override", "first_applicable"):
            raise ValueError(
                f"strategy must be 'deny_override' or 'first_applicable', got {strategy!r}"
            )
        self._rbac = rbac_evaluator
        self._abac = abac_evaluator
        self._strategy = strategy

    def evaluate(
        self,
        user: User,
        resource_type: str,
        action: str,
        environment: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Evaluate access for *user* against both RBAC and ABAC.

        Args:
            user: The user requesting access.
            resource_type: The resource being accessed.
            action: The action being performed.
            environment: Optional environment attributes for ABAC evaluation.

        Returns:
            A dict with keys ``allowed`` (bool), ``reason`` (str),
            ``rbac_result`` (bool), and ``abac_result`` (dict with
            ``allowed``, ``reason``, ``matched_policy_id``).
        """
        rbac_allowed = self._rbac.check(user, resource_type, action)

        subject_attrs: Dict[str, Any] = {}
        if environment:
            subject_attrs.update(environment)

        abac_result = self._abac.evaluate(
            subject_attrs,
            {"type": resource_type},
            action,
            environment or {},
        )

        if self._strategy == "deny_override":
            allowed = rbac_allowed and abac_result["allowed"]
            if not allowed:
                parts = []
                if not rbac_allowed:
                    parts.append("RBAC denied")
                if not abac_result["allowed"]:
                    parts.append(f"ABAC denied ({abac_result['reason']})")
                reason = "; ".join(parts)
            else:
                reason = "allowed by both RBAC and ABAC"
        else:
            # first_applicable: prefer RBAC, fall back to ABAC
            if rbac_allowed:
                allowed = True
                reason = "RBAC allowed"
            else:
                allowed = abac_result["allowed"]
                if allowed:
                    reason = f"ABAC allowed ({abac_result['reason']})"
                else:
                    reason = f"denied by RBAC; ABAC also denied ({abac_result['reason']})"

        return {
            "allowed": allowed,
            "reason": reason,
            "rbac_result": rbac_allowed,
            "abac_result": abac_result,
        }

    def __repr__(self) -> str:
        return f"CombinedEvaluator(strategy={self._strategy!r})"
