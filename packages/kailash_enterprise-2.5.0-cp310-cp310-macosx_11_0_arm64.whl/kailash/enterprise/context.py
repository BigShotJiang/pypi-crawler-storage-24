"""Thread-safe enterprise context using contextvars.

Provides per-task (or per-thread) isolation for the current user and tenant,
suitable for use in async frameworks, threaded web servers, and decorators.

Usage::

    from kailash.enterprise.context import set_current_user, get_current_user
    from kailash.enterprise import User

    set_current_user(User("alice").with_role("admin"))
    user = get_current_user()  # User("alice", roles=1)
"""

from contextvars import ContextVar
from typing import Optional

from kailash._kailash import User

_current_user: ContextVar[Optional[User]] = ContextVar(
    "kailash_current_user", default=None
)
_current_tenant: ContextVar[Optional[str]] = ContextVar(
    "kailash_current_tenant", default=None
)


def set_current_user(user: User) -> None:
    """Set the current user for the active context (task/thread)."""
    _current_user.set(user)


def get_current_user() -> Optional[User]:
    """Return the current user, or ``None`` if not set."""
    return _current_user.get()


def set_current_tenant(tenant_id: str) -> None:
    """Set the current tenant ID for the active context."""
    _current_tenant.set(tenant_id)


def get_current_tenant() -> Optional[str]:
    """Return the current tenant ID, or ``None`` if not set."""
    return _current_tenant.get()


def clear_context() -> None:
    """Reset both user and tenant to ``None`` in the active context."""
    _current_user.set(None)
    _current_tenant.set(None)
