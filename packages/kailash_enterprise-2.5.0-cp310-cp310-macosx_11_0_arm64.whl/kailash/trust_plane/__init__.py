"""Kailash Trust Plane — file-backed trust project management.

Re-exports Rust-backed trust types::

    from kailash.trust_plane import TrustProject, ConstraintEnvelope
    from kailash.trust_plane import DelegationManager, HoldManager
    from kailash.trust_plane import MirrorManager, TemplateRegistry
    from kailash.trust_plane import VerificationBundle, ConformanceReport
    from kailash.trust_plane import ShadowConfig, ShadowEnforcer, ShadowReport
    from kailash.trust_plane import run_conformance, migrate_project

All classes are backed by the ``trust-plane`` Rust crate via PyO3.

Example::

    from kailash.trust_plane import TrustProject

    project = TrustProject.create("/tmp/my-project", "Demo", "alice")
    anchor_id = project.record_decision(
        "Use Rust", "Performance", "architecture"
    )
    report = project.verify()
    assert report.is_valid
"""

from kailash._kailash import (
    # Core project
    TrustProject,
    ConstraintEnvelope,
    # Verification
    VerificationReport,
    VerificationIssue,
    RepairReport,
    # Delegation
    DelegationManager,
    Delegate,
    # Holds
    HoldManager,
    HoldRecord,
    # Mirror
    MirrorManager,
    # Templates
    TemplateRegistry,
    # Bundle
    VerificationBundle,
    # Conformance
    ConformanceReport,
    # Functions
    run_conformance,
    migrate_project,
)

# Shadow mode types may not be compiled into the current binary yet
try:
    from kailash._kailash import (
        ShadowConfig,
        ShadowRecord,
        ShadowReport,
        ShadowEnforcer,
    )
except ImportError:
    ShadowConfig = None  # type: ignore[assignment,misc]
    ShadowRecord = None  # type: ignore[assignment,misc]
    ShadowReport = None  # type: ignore[assignment,misc]
    ShadowEnforcer = None  # type: ignore[assignment,misc]

__all__ = [
    "TrustProject",
    "ConstraintEnvelope",
    "VerificationReport",
    "VerificationIssue",
    "RepairReport",
    "DelegationManager",
    "Delegate",
    "HoldManager",
    "HoldRecord",
    "MirrorManager",
    "TemplateRegistry",
    "VerificationBundle",
    "ConformanceReport",
    "ShadowConfig",
    "ShadowRecord",
    "ShadowReport",
    "ShadowEnforcer",
    "run_conformance",
    "migrate_project",
]
