"""Pythonic filter builder for DataFlow queries.

Provides the ``F`` class for constructing ``FilterCondition`` objects
using operator overloading::

    from kailash.dataflow import F

    f = F("name") == "Alice"       # FilterCondition.eq("name", "Alice")
    f = F("age") != 18             # FilterCondition.ne("age", 18)
    f = F("name").like("%test%")   # FilterCondition.like("name", "%test%")
    f = F("deleted").is_null()     # FilterCondition.is_null("deleted")
"""

from kailash._kailash import FilterCondition


class F:
    """Field reference for building filter conditions via operator overloading.

    Args:
        column: The database column name to filter on.
    """

    __slots__ = ("_column",)

    def __init__(self, column: str):
        self._column = column

    def __eq__(self, other):
        return FilterCondition.eq(self._column, other)

    def __ne__(self, other):
        return FilterCondition.ne(self._column, other)

    def __gt__(self, other):
        return FilterCondition.gt(self._column, other)

    def __ge__(self, other):
        return FilterCondition.gte(self._column, other)

    def __lt__(self, other):
        return FilterCondition.lt(self._column, other)

    def __le__(self, other):
        return FilterCondition.lte(self._column, other)

    def like(self, pattern: str) -> FilterCondition:
        """Create a LIKE filter condition.

        Args:
            pattern: SQL LIKE pattern (e.g., ``"%test%"``).
        """
        return FilterCondition.like(self._column, pattern)

    def is_null(self) -> FilterCondition:
        """Create an IS NULL filter condition."""
        return FilterCondition.is_null(self._column)

    def is_not_null(self) -> FilterCondition:
        """Create an IS NOT NULL filter condition."""
        return FilterCondition.is_not_null(self._column)

    def in_list(self, values: list) -> FilterCondition:
        """Create an IN filter condition.

        Args:
            values: List of values to match against.
        """
        return FilterCondition.in_list(self._column, values)

    def __repr__(self) -> str:
        return f"F({self._column!r})"
