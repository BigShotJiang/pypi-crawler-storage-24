"""Tenant context manager for DataFlow multi-tenancy.

Provides a ``with_tenant`` context manager that sets a tenant ID on a
``QueryInterceptor`` for the duration of the block::

    from kailash.dataflow import QueryInterceptor, TenantContext, with_tenant

    ctx = TenantContext("acme-001")
    interceptor = QueryInterceptor(ctx)

    with with_tenant(interceptor, "tenant-002"):
        result = interceptor.intercept_query("SELECT * FROM orders")
        # query is scoped to tenant-002
"""

from contextlib import contextmanager

from kailash._kailash import QueryInterceptor, TenantContext


@contextmanager
def with_tenant(interceptor: QueryInterceptor, tenant_id: str, column_name: str = "tenant_id"):
    """Context manager that temporarily replaces the interceptor's tenant context.

    On entry, creates a new ``QueryInterceptor`` with the given ``tenant_id``
    and swaps it in. On exit, restores the original interceptor state.

    Note: Because ``QueryInterceptor`` is a Rust-backed immutable object,
    this context manager yields a *new* interceptor scoped to the given tenant.
    Use the yielded value inside the ``with`` block.

    Args:
        interceptor: The base QueryInterceptor (used to read the column name).
        tenant_id: The tenant identifier to scope queries to.
        column_name: The database column for tenant filtering (default: "tenant_id").

    Yields:
        A new ``QueryInterceptor`` scoped to the given tenant.

    Example::

        base_ctx = TenantContext("default")
        base = QueryInterceptor(base_ctx)

        with with_tenant(base, "acme-001") as scoped:
            result = scoped.intercept_query("SELECT * FROM orders")
    """
    scoped_ctx = TenantContext(tenant_id, column_name=column_name)
    scoped = QueryInterceptor(scoped_ctx)
    try:
        yield scoped
    finally:
        pass  # No cleanup needed; the original interceptor is unmodified
