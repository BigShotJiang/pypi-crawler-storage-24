"""Pythonic model decorator for DataFlow.

Provides a ``@db.model`` decorator that inspects class ``__annotations__``
and builds a ``ModelDefinition`` backed by the Rust DataFlow engine::

    from kailash.dataflow import db

    @db.model
    class User:
        __table__ = "users"
        id: int
        name: str
        email: Optional[str]

    print(User._model_definition)  # ModelDefinition(name='User', table='users', ...)
"""

import datetime
import re
import types
import typing

from kailash._kailash import FieldType, ModelDefinition


def _camel_to_snake(name: str) -> str:
    """Convert CamelCase to snake_case (e.g. AgentDefinition -> agent_definition)."""
    s = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", name)
    s = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", "_", s)
    return s.lower()


def _pluralize(name: str) -> str:
    """Produce a reasonable English plural for a snake_case table name.

    Handles common suffix patterns:
    - ``access`` → ``accesses`` (ends in s, x, z, ch, sh)
    - ``delivery`` → ``deliveries`` (consonant + y)
    - ``team`` → ``teams`` (regular)
    """
    if name.endswith(("s", "x", "z")):
        return name + "es"
    if name.endswith(("ch", "sh")):
        return name + "es"
    if name.endswith("y") and len(name) > 1 and name[-2] not in "aeiou":
        return name[:-1] + "ies"
    return name + "s"


def _resolve_field_type(annotation):
    """Map a Python type annotation to a FieldType, returning (field_type, nullable).

    Supports: int, str, float, bool, datetime.datetime, and Optional[T] variants.
    """
    origin = getattr(annotation, "__origin__", None)

    # Handle Python 3.10+ X | Y syntax (types.UnionType)
    if isinstance(annotation, types.UnionType):
        args = annotation.__args__
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1 and type(None) in args:
            inner_type, _ = _resolve_field_type(non_none[0])
            return inner_type, True
        raise TypeError(
            f"unsupported Union type: {annotation}; only Optional[T] is supported"
        )

    # Handle Optional[T] which is Union[T, None]
    if origin is typing.Union:
        args = annotation.__args__
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1 and type(None) in args:
            inner_type, _ = _resolve_field_type(non_none[0])
            return inner_type, True
        raise TypeError(
            f"unsupported Union type: {annotation}; only Optional[T] is supported"
        )

    nullable = False

    if annotation is int:
        return FieldType.integer(), nullable
    if annotation is str:
        return FieldType.text(), nullable
    if annotation is float:
        return FieldType.real(), nullable
    if annotation is bool:
        return FieldType.boolean(), nullable
    if annotation is datetime.datetime:
        return FieldType.timestamp(), nullable

    raise TypeError(
        f"unsupported type annotation: {annotation!r}; "
        f"expected int, str, float, bool, datetime.datetime, or Optional[T]"
    )


class _DbNamespace:
    """Namespace object providing the ``@db.model`` decorator."""

    def model(self, cls):
        """Decorate a class to attach a ``_model_definition`` based on annotations.

        The class is NOT replaced -- it is returned unchanged with an extra
        ``_model_definition`` attribute holding a ``ModelDefinition`` instance.

        Class-level attributes read:
            __table__: str -- database table name (default: class name lowered + "s")
            __primary_key__: str -- primary key column name (default: "id")
            __auto_timestamps__: bool -- add created_at/updated_at (default: True)
        """
        table = getattr(cls, "__table__", _pluralize(_camel_to_snake(cls.__name__)))
        primary_key = getattr(cls, "__primary_key__", "id")
        auto_timestamps = getattr(cls, "__auto_timestamps__", True)

        model = ModelDefinition(cls.__name__, table)

        annotations = typing.get_type_hints(cls)

        # Collect fields that have default values on the class.
        _field_defaults = {}
        for name in annotations:
            if name.startswith("_"):
                continue
            if hasattr(cls, name) and not callable(getattr(cls, name, None)):
                _field_defaults[name] = getattr(cls, name)

        for field_name, annotation in annotations.items():
            if field_name.startswith("_"):
                continue

            field_type, nullable = _resolve_field_type(annotation)
            is_pk = field_name == primary_key
            has_default = field_name in _field_defaults

            default_val = _field_defaults.get(field_name)
            model.field(
                field_name,
                field_type,
                primary_key=is_pk,
                nullable=nullable,
                required=not nullable and not is_pk and not has_default,
                default_value=default_val,
            )

        # If user explicitly defined timestamp fields, disable auto_timestamps
        # to avoid double-column conflicts in build_insert()
        if auto_timestamps:
            has_explicit_created = "created_at" in annotations
            has_explicit_updated = "updated_at" in annotations
            if has_explicit_created or has_explicit_updated:
                auto_timestamps = False

        if auto_timestamps:
            model.auto_timestamps()

        cls._model_definition = model
        return cls


db = _DbNamespace()
