"""Type stubs for the kailash.mcp.server module."""

from typing import Callable, Dict, List, Optional

from kailash._kailash import McpServer, ToolParam

class McpApplication:
    """A Pythonic MCP application with @tool() decorator support.

    Wraps the Rust-backed ``McpServer`` and provides a Flask-like API for
    registering MCP tools, resources, and prompts using decorators.
    """

    def __init__(
        self,
        name: str,
        version: str = "1.0.0",
        transport: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
    ) -> None: ...

    @property
    def name(self) -> str: ...
    @property
    def version(self) -> str: ...
    @property
    def tool_count(self) -> int: ...
    @property
    def resource_count(self) -> int: ...
    @property
    def prompt_count(self) -> int: ...
    @property
    def server(self) -> McpServer: ...

    def tool(
        self,
        name: str,
        description: str,
        params: Optional[List[ToolParam]] = None,
    ) -> Callable:
        """Decorator for registering an MCP tool.

        The decorated function receives a dict of arguments from the MCP
        client and should return a JSON-serializable value.
        """
        ...

    def resource(
        self,
        uri: str,
        name: str,
        description: str = "",
        mime_type: str = "text/plain",
    ) -> Callable:
        """Decorator for registering a dynamic MCP resource.

        The decorated function receives the resource URI as a string and
        should return the resource content as a string.
        """
        ...

    def prompt(
        self,
        name: str,
        description: str = "",
        arguments: Optional[List[Dict]] = None,
    ) -> Callable:
        """Decorator for registering an MCP prompt handler.

        The decorated function receives a dict of arguments and should
        return a list of message dicts (each with ``"role"`` and
        ``"content"`` keys).
        """
        ...

    def require_auth(
        self,
        *,
        api_keys: Optional[List[str]] = None,
        jwt_secret: Optional[str] = None,
        jwt_issuer: Optional[str] = None,
    ) -> None:
        """Configure authentication on the underlying MCP server.

        At least one authentication method must be provided.

        Raises:
            ValueError: If no authentication method is specified.
        """
        ...

    def run(self, transport: str = "stdio") -> None:
        """Start the MCP server with the specified transport.

        Raises:
            RuntimeError: The standalone MCP server transport is not yet
                available in the Rust binding.
        """
        ...
    def __repr__(self) -> str: ...
