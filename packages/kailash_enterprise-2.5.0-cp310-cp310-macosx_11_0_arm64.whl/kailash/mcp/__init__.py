"""Kailash MCP -- standalone Model Context Protocol module.

Provides a first-class ``import kailash.mcp`` entry point for building MCP
servers with the Kailash platform. This module re-exports the Rust-backed
MCP and tool types, and adds Pythonic convenience wrappers.

**Rust-backed types** (re-exported from ``kailash._kailash``)::

    from kailash.mcp import McpServer, ToolDef, ToolParam, ToolRegistry

**Convenience helpers**::

    from kailash.mcp import create_server, create_tool, tool_param

**Decorator-based application**::

    from kailash.mcp import McpApplication

    app = McpApplication("my-app")

    @app.tool("greet", "Greet a user")
    def greet(params):
        return {"message": f"Hello {params['name']}"}

    print(app.tool_count)  # 1
"""

from typing import Callable, Dict, List, Optional

from kailash._kailash import (
    McpServer,
    ToolDef,
    ToolParam,
    ToolRegistry,
)

from kailash.mcp.server import McpApplication


def prompt_argument(
    name: str,
    description: Optional[str] = None,
    required: bool = True,
) -> Dict:
    """Create a prompt argument definition dict.

    Helper to build the argument dicts expected by
    ``McpServer.register_prompt()`` and ``McpApplication.prompt()``.

    Args:
        name: Argument name. Must not be empty.
        description: Optional human-readable description. When ``None``,
            the key is omitted from the returned dict.
        required: Whether the argument is required (default: ``True``).

    Returns:
        A dict with ``"name"``, ``"required"``, and optionally
        ``"description"`` keys.

    Example::

        arg = prompt_argument("language", description="The programming language")
    """
    result: Dict = {"name": name, "required": required}
    if description is not None:
        result["description"] = description
    return result


def create_tool(
    name: str,
    description: str,
    handler: Callable,
    params: Optional[List[ToolParam]] = None,
) -> ToolDef:
    """Create a ToolDef with the given name, description, and handler.

    This is a convenience shortcut for constructing a ``ToolDef`` without
    needing to import and instantiate each class separately.

    Args:
        name: Unique tool name. Must not be empty.
        description: Human-readable description. Must not be empty.
        handler: A Python callable that receives a dict of arguments and
            returns a value.
        params: Optional list of ``ToolParam`` definitions for the tool's
            input schema.

    Returns:
        A fully-constructed ``ToolDef`` instance.

    Raises:
        ValueError: If *name* or *description* is empty.
        TypeError: If *handler* is not callable.

    Example::

        tool = create_tool("echo", "Echo input back", lambda args: args)
    """
    if not name:
        raise ValueError("create_tool() requires a non-empty 'name'")
    if not description:
        raise ValueError("create_tool() requires a non-empty 'description'")
    if not callable(handler):
        raise TypeError(
            f"create_tool() requires a callable 'handler', got {type(handler).__name__}"
        )
    return ToolDef(name, description, handler, params)


def create_server(name: str, version: str = "1.0.0") -> McpServer:
    """Create an McpServer with the given name and version.

    This is a convenience shortcut for constructing an ``McpServer``.

    Args:
        name: Server name. Must not be empty.
        version: Server version string (default: ``"1.0.0"``).

    Returns:
        A new ``McpServer`` instance.

    Raises:
        ValueError: If *name* is empty.

    Example::

        server = create_server("my-app", version="2.0.0")
    """
    if not name:
        raise ValueError("create_server() requires a non-empty 'name'")
    return McpServer(name, version)


def tool_param(
    name: str,
    param_type: str,
    description: str,
    required: bool = True,
) -> ToolParam:
    """Create a ToolParam with the given attributes.

    This is a convenience shortcut for constructing a ``ToolParam``.

    Args:
        name: Parameter name. Must not be empty.
        param_type: Type string (``"string"``, ``"integer"``, ``"float"``,
            ``"bool"``, ``"object"``, ``"array"``).
        description: Parameter description. Must not be empty.
        required: Whether the parameter is required (default: ``True``).

    Returns:
        A new ``ToolParam`` instance.

    Raises:
        ValueError: If *name* or *description* is empty.

    Example::

        param = tool_param("query", "string", "Search query", required=True)
    """
    if not name:
        raise ValueError("tool_param() requires a non-empty 'name'")
    if not description:
        raise ValueError("tool_param() requires a non-empty 'description'")
    return ToolParam(name, param_type, description=description, required=required)


__all__ = [
    # Rust-backed types (re-exports)
    "McpServer",
    "ToolDef",
    "ToolParam",
    "ToolRegistry",
    # Python convenience wrapper
    "McpApplication",
    # Utility helpers
    "create_tool",
    "create_server",
    "tool_param",
    "prompt_argument",
]
