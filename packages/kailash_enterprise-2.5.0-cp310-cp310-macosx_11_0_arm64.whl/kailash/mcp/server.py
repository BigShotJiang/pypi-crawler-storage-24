"""McpApplication -- Flask/FastAPI-style decorator wrapper for MCP servers.

Provides a high-level decorator API on top of the Rust-backed ``McpServer``::

    from kailash.mcp import McpApplication

    app = McpApplication("calculator", version="1.0.0")

    @app.tool("add", "Add two numbers", params=[
        ToolParam("a", "float", description="First number"),
        ToolParam("b", "float", description="Second number"),
    ])
    def add(params):
        return {"result": params["a"] + params["b"]}

    # Use app.server to access the underlying McpServer
    print(app.server)  # McpServer(name="calculator", tools=1)
"""

from typing import Callable, Dict, List, Optional

from kailash._kailash import McpServer, ToolParam


class McpApplication:
    """A Pythonic MCP application with ``@tool()`` decorator support.

    Wraps the Rust-backed ``McpServer`` and provides a Flask-like API for
    registering MCP tools using decorators.

    Args:
        name: Application/server name. Must not be empty.
        version: Server version string (default: ``"1.0.0"``).

    Raises:
        ValueError: If *name* is empty.

    Example::

        app = McpApplication("my-app")

        @app.tool("greet", "Greet a user")
        def greet(params):
            return {"message": f"Hello {params['name']}"}

        print(app.tool_count)  # 1
    """

    def __init__(
        self,
        name: str,
        version: str = "1.0.0",
        transport: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
    ) -> None:
        if not name:
            raise ValueError("McpApplication requires a non-empty 'name'")
        if transport is not None:
            self._server = McpServer(name, version, transport=transport)
        else:
            self._server = McpServer(name, version)

        # Apply host/port configuration if provided
        if host is not None or port is not None:
            current_transport = self._server.transport()
            if current_transport == "sse":
                self._server.set_sse_config(
                    host if host is not None else "127.0.0.1",
                    port if port is not None else 3000,
                )
            elif current_transport == "http":
                self._server.set_http_config(
                    host if host is not None else "127.0.0.1",
                    port if port is not None else 8080,
                )

    # ------------------------------------------------------------------ #
    # Properties
    # ------------------------------------------------------------------ #

    @property
    def name(self) -> str:
        """The server name."""
        return self._server.name

    @property
    def version(self) -> str:
        """The server version."""
        return self._server.version

    @property
    def tool_count(self) -> int:
        """Number of registered tools."""
        return self._server.tool_count()

    @property
    def resource_count(self) -> int:
        """Number of registered resources."""
        return self._server.resource_count()

    @property
    def prompt_count(self) -> int:
        """Number of registered prompts."""
        return self._server.prompt_count()

    @property
    def server(self) -> McpServer:
        """The underlying Rust-backed McpServer instance."""
        return self._server

    # ------------------------------------------------------------------ #
    # Decorator API
    # ------------------------------------------------------------------ #

    def tool(
        self,
        name: str,
        description: str,
        params: Optional[List[ToolParam]] = None,
    ) -> Callable:
        """Decorator for registering an MCP tool.

        The decorated function receives a dict of arguments from the MCP
        client and should return a JSON-serializable value.

        Args:
            name: Unique tool name. Must not be empty.
            description: Human-readable description. Must not be empty.
            params: Optional list of ``ToolParam`` definitions. When
                provided, these define the tool's input JSON Schema.

        Returns:
            The original function (unmodified), so it can still be called
            directly.

        Raises:
            ValueError: If *name* or *description* is empty.

        Example::

            @app.tool("echo", "Echo input back")
            def echo(params):
                return params
        """
        if not name:
            raise ValueError("@app.tool() requires a non-empty 'name'")
        if not description:
            raise ValueError("@app.tool() requires a non-empty 'description'")

        # Build JSON Schema from ToolParam list if provided
        schema: Optional[Dict] = None
        if params:
            properties = {}
            required_list = []
            for p in params:
                prop: Dict = {"type": _tool_param_type_to_json_schema(p.param_type)}
                if p.description:
                    prop["description"] = p.description
                properties[p.name] = prop
                if p.required:
                    required_list.append(p.name)
            schema = {
                "type": "object",
                "properties": properties,
            }
            if required_list:
                schema["required"] = required_list

        def decorator(fn: Callable) -> Callable:
            self._server.register_tool(name, description, fn, schema)
            return fn

        return decorator

    def resource(
        self,
        uri: str,
        name: str,
        description: str = "",
        mime_type: str = "text/plain",
    ) -> Callable:
        """Decorator for registering a dynamic MCP resource.

        The decorated function receives the resource URI as a string and
        should return the resource content as a string.

        Args:
            uri: Unique resource URI (e.g. ``"file:///readme"``).
            name: Human-readable resource name.
            description: Optional description of the resource.
            mime_type: MIME type for the resource content
                (default: ``"text/plain"``).

        Returns:
            The original function (unmodified), so it can still be called
            directly.

        Example::

            @app.resource("file:///readme", "README", description="Project readme")
            def get_readme(uri: str) -> str:
                return "# My Project"
        """
        def decorator(fn: Callable) -> Callable:
            kwargs: Dict = {}
            if description:
                kwargs["description"] = description
            if mime_type:
                kwargs["mime_type"] = mime_type
            self._server.register_dynamic_resource(uri, name, fn, **kwargs)
            return fn

        return decorator

    def prompt(
        self,
        name: str,
        description: str = "",
        arguments: Optional[List] = None,
    ) -> Callable:
        """Decorator for registering an MCP prompt handler.

        The decorated function receives a dict of arguments and should
        return a list of message dicts (each with ``"role"`` and
        ``"content"`` keys).

        Args:
            name: Unique prompt name.
            description: Optional description of the prompt.
            arguments: Optional list of argument dicts, each with
                ``"name"``, ``"description"`` (optional), and
                ``"required"`` (bool) keys.

        Returns:
            The original function (unmodified), so it can still be called
            directly.

        Example::

            @app.prompt("code-review", description="Code review prompt",
                        arguments=[{"name": "language", "required": True}])
            def code_review(arguments: dict) -> list:
                return [{"role": "user",
                         "content": f"Review {arguments['language']} code."}]
        """
        def decorator(fn: Callable) -> Callable:
            kwargs: Dict = {}
            if description:
                kwargs["description"] = description
            if arguments is not None:
                kwargs["arguments"] = arguments
            self._server.register_prompt(name, fn, **kwargs)
            return fn

        return decorator

    # ------------------------------------------------------------------ #
    # Auth
    # ------------------------------------------------------------------ #

    def require_auth(
        self,
        *,
        api_keys: Optional[List[str]] = None,
        jwt_secret: Optional[str] = None,
        jwt_issuer: Optional[str] = None,
    ) -> None:
        """Configure authentication on the underlying MCP server.

        At least one authentication method must be provided.

        Args:
            api_keys: List of valid API keys for API-key authentication.
            jwt_secret: Shared secret for JWT (HS256) authentication.
            jwt_issuer: Optional expected JWT issuer claim.

        Raises:
            ValueError: If no authentication method is specified.

        Example::

            app.require_auth(api_keys=["my-secret-key"])
            app.require_auth(jwt_secret="my-jwt-secret")
        """
        methods: List[Dict] = []
        if api_keys:
            methods.append({"type": "api_key", "keys": api_keys})
        if jwt_secret:
            method: Dict = {"type": "jwt", "secret": jwt_secret}
            if jwt_issuer:
                method["issuer"] = jwt_issuer
            methods.append(method)

        if not methods:
            raise ValueError(
                "At least one auth method must be specified. "
                "Provide api_keys or jwt_secret."
            )

        self._server.with_auth({"enabled": True, "methods": methods})

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #

    def run(self, transport: str = "stdio") -> None:
        """Start the MCP server with the specified transport.

        Args:
            transport: Transport protocol to use (``"stdio"``).

        Raises:
            RuntimeError: The standalone MCP server transport is not yet
                available in the Rust binding. Use Nexus instead.
        """
        raise RuntimeError(
            f"McpApplication.run(transport={transport!r}) requires the "
            f"standalone MCP transport which is not yet exposed by the Rust "
            f"binding. To serve MCP tools today, use the Nexus multi-channel "
            f"platform which includes MCP support:\n"
            f"\n"
            f"    from kailash.nexus import NexusApp\n"
            f"    app = NexusApp()\n"
            f"    app.start()\n"
            f"\n"
            f"See P17-031 (MCP Transports) for standalone MCP server support."
        )

    # ------------------------------------------------------------------ #
    # Dunder methods
    # ------------------------------------------------------------------ #

    def __repr__(self) -> str:
        return (
            f"McpApplication(name={self.name!r}, "
            f"tools={self.tool_count})"
        )


def _tool_param_type_to_json_schema(param_type: str) -> str:
    """Map a ToolParam type string to a JSON Schema type string.

    Args:
        param_type: The ToolParam type (e.g. ``"integer"``, ``"float"``).

    Returns:
        The corresponding JSON Schema type string.
    """
    mapping = {
        "string": "string",
        "integer": "integer",
        "int": "integer",
        "float": "number",
        "number": "number",
        "bool": "boolean",
        "boolean": "boolean",
        "object": "object",
        "array": "array",
        "list": "array",
    }
    return mapping.get(param_type, "string")
