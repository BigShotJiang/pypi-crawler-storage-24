"""Type stubs for the kailash.mcp standalone MCP module."""

from typing import Callable, Dict, List, Optional

from kailash._kailash import McpServer as McpServer
from kailash._kailash import ToolDef as ToolDef
from kailash._kailash import ToolParam as ToolParam
from kailash._kailash import ToolRegistry as ToolRegistry

from kailash.mcp.server import McpApplication as McpApplication

def create_tool(
    name: str,
    description: str,
    handler: Callable,
    params: Optional[List[ToolParam]] = None,
) -> ToolDef: ...

def create_server(
    name: str,
    version: str = "1.0.0",
) -> McpServer: ...

def tool_param(
    name: str,
    param_type: str,
    description: str,
    required: bool = True,
) -> ToolParam: ...

def prompt_argument(
    name: str,
    description: Optional[str] = None,
    required: bool = True,
) -> Dict:
    """Create a prompt argument definition dict.

    Returns:
        A dict with ``"name"``, ``"required"``, and optionally
        ``"description"`` keys.
    """
    ...

__all__: List[str]
