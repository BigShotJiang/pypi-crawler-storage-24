"""Backward-compatible workflow subpackage.

Provides the v0.12 import path ``from kailash.workflow.builder import WorkflowBuilder``.
"""

from kailash.workflow.builder import WorkflowBuilder

__all__ = ["WorkflowBuilder"]
