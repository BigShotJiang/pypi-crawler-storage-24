"""Backward-compatible WorkflowBuilder.

Wraps the v2 ``kailash.WorkflowBuilder`` to support the v0.12 API where
``build()`` takes no arguments (registry is created internally).
"""

import re
import warnings
from typing import Any, Dict, List, Optional, Tuple

from kailash._kailash import (
    NodeRegistry as _NodeRegistry,
    WorkflowBuilder as _WorkflowBuilder,
    Workflow as _Workflow,
)

# ---------------------------------------------------------------------------
# Old-style -> Rust-style node name translation
# ---------------------------------------------------------------------------
# Old Python SDK: {Model}{Action}Node (e.g. WorkspaceCreateNode)
# Rust backend:   {Action}{Model}      (e.g. CreateWorkspace)

_CRUD_SUFFIXES = [
    "BulkCreateNode", "BulkDeleteNode", "BulkUpdateNode", "BulkUpsertNode",
    "CountNode", "CreateNode", "DeleteNode", "ListNode",
    "ReadNode", "UpdateNode", "UpsertNode",
]

# Sorted by length descending so "BulkCreateNode" matches before "CreateNode"
_CRUD_SUFFIXES.sort(key=len, reverse=True)


def _translate_node_name(name: str) -> Tuple[str, Optional[str]]:
    """Translate old-style node name to Rust-style if applicable.

    Returns (rust_name, crud_action) where crud_action is the action
    name (e.g. "Create", "Read", "List") or None if not a CRUD node.

    WorkspaceCreateNode -> ("CreateWorkspace", "Create")
    AgentDefinitionListNode -> ("ListAgentDefinition", "List")
    WorkspaceCountNode -> ("CountWorkspace", "Count")
    HTTPRequestNode -> ("HTTPRequestNode", None)
    """
    for suffix in _CRUD_SUFFIXES:
        if name.endswith(suffix):
            model = name[: -len(suffix)]
            action = suffix[: -len("Node")]  # Remove "Node" suffix
            return f"{action}{model}", action
    return name, None


def _auto_register_dataflow_nodes(registry: _NodeRegistry) -> None:
    """Register CRUD nodes from all active DataFlow instances into the registry."""
    try:
        from dataflow import _active_dataflow_instances
    except ImportError:
        return

    # Prune dead weakrefs before iterating
    _active_dataflow_instances[:] = [
        ref for ref in _active_dataflow_instances if ref() is not None
    ]

    for ref in _active_dataflow_instances:
        df_instance = ref()
        if df_instance is None:
            continue
        try:
            df_instance.register_nodes(registry)
        except Exception:
            pass


# Known input keys for the Rust ListNode / CountNode.
_LIST_NODE_KEYS = {"filter", "order_by", "order_dir", "limit", "offset"}


def _auto_wrap_filter(config: Dict[str, Any]) -> Dict[str, Any]:
    """Wrap flat filter params into a ``filter`` key for List/Count nodes.

    The old Python SDK accepted flat params like ``{"workspace_id": 1}``
    which were implicitly treated as filter criteria. The Rust ListNode
    expects them nested: ``{"filter": {"workspace_id": 1}}``.
    """
    if "filter" in config:
        return config  # Already has an explicit filter

    # Separate known ListNode keys from unknown (filter) keys
    known = {}
    filter_params = {}
    for k, v in config.items():
        if k in _LIST_NODE_KEYS:
            known[k] = v
        else:
            filter_params[k] = v

    if filter_params:
        known["filter"] = filter_params
    return known


class _CompatWorkflow:
    """Wrapper around Rust Workflow that carries CRUD metadata for output normalization."""

    def __init__(self, workflow: _Workflow, crud_actions: Dict[str, str]) -> None:
        self._workflow = workflow
        self._crud_actions = crud_actions

    def __getattr__(self, name: str) -> Any:
        return getattr(self._workflow, name)


class WorkflowBuilder:
    """Backward-compatible workflow builder.

    Supports both v0.12 and v2 calling conventions:

    - ``builder.build()`` -- v0.12 style, creates a default registry internally
    - ``builder.build(registry)`` -- v2 style, uses the provided registry

    All other methods (``add_node``, ``connect``, ``to_json``, ``from_json``)
    delegate directly to the Rust-backed builder.
    """

    def __init__(self) -> None:
        self._builder = _WorkflowBuilder()
        self._consumed = False
        # Maps node_id -> CRUD action for output format normalization
        self._crud_actions: Dict[str, str] = {}

    def add_node(
        self,
        type_name: str,
        node_id: str,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Add a node to the workflow.

        Supports old-style node names (e.g. ``WorkspaceCreateNode``) which
        are transparently translated to Rust-style (``CreateWorkspace``).

        For List/Count nodes, flat filter params (keys not in the known
        ListNode input set) are automatically wrapped into a ``filter`` dict
        for backwards compatibility with the v0.12 API.
        """
        translated, crud_action = _translate_node_name(type_name)
        if crud_action is not None:
            self._crud_actions[node_id] = crud_action

        # Auto-wrap flat filter params for List/Count nodes
        if config and crud_action in ("List", "Count"):
            config = _auto_wrap_filter(config)

        self._builder.add_node(translated, node_id, config)

    def connect(
        self,
        source: str,
        source_output: str,
        target: str,
        target_input: str,
    ) -> None:
        """Connect an output port of one node to an input port of another."""
        self._builder.connect(source, source_output, target, target_input)

    def add_connection(
        self,
        source: str,
        source_output: str,
        target: str,
        target_input: str,
    ) -> None:
        """Alias for ``connect()`` — v0.12 API compatibility.

        The original Python SDK used ``add_connection``; v2 uses ``connect``.
        Both are supported.
        """
        self._builder.connect(source, source_output, target, target_input)

    def build(self, registry: Optional[_NodeRegistry] = None) -> "_CompatWorkflow":
        """Build and validate the workflow.

        Args:
            registry: Optional ``NodeRegistry``. If not provided (v0.12 style),
                a default registry with all built-in nodes is created.

        Returns:
            A validated workflow wrapped for backwards-compatible output.
        """
        if registry is None:
            warnings.warn(
                "WorkflowBuilder.build() without a registry is deprecated "
                "since Kailash v2.0. Pass a NodeRegistry: "
                "builder.build(kailash.NodeRegistry())",
                DeprecationWarning,
                stacklevel=2,
            )
            registry = _NodeRegistry()

        # Auto-register DataFlow CRUD nodes from active DataFlow instances
        _auto_register_dataflow_nodes(registry)

        self._consumed = True
        workflow = self._builder.build(registry)
        return _CompatWorkflow(workflow, self._crud_actions)

    def to_json(self) -> str:
        """Serialize the workflow builder state to a JSON string."""
        return self._builder.to_json()

    @staticmethod
    def from_json(json_str: str) -> "WorkflowBuilder":
        """Create a ``WorkflowBuilder`` from a JSON string."""
        wb = WorkflowBuilder()
        wb._builder = _WorkflowBuilder.from_json(json_str)
        return wb

    def __repr__(self) -> str:
        if self._consumed:
            return "WorkflowBuilder(consumed)"
        return repr(self._builder)
