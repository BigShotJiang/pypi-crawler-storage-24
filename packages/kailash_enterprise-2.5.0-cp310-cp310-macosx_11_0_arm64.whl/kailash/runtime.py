"""Backward-compatible runtime classes for Kailash v0.12 API.

Provides ``LocalRuntime``, ``AsyncLocalRuntime``, and ``get_runtime`` that
match the original Python SDK signatures exactly. Existing code using these
classes works without modification.

Migration note:
    These classes wrap ``kailash.Runtime`` internally. For new code, prefer
    the v2 API directly::

        from kailash import Runtime, NodeRegistry
        rt = Runtime(NodeRegistry())
"""

import asyncio
import warnings
from typing import Any, Dict, Optional, Tuple

from kailash._kailash import (
    NodeRegistry as _NodeRegistry,
    Runtime as _Runtime,
    RuntimeConfig as _RuntimeConfig,
)


def _emit_deprecation(old: str, new: str) -> None:
    warnings.warn(
        f"{old} is deprecated since Kailash v2.0. Use {new} instead.",
        DeprecationWarning,
        stacklevel=3,
    )


def _normalize_crud_results(
    results: Dict[str, Any], crud_actions: Dict[str, str]
) -> Dict[str, Any]:
    """Normalize Rust DataFlow CRUD results to match old Python SDK format.

    Rust Create:  {"id": N, "record": {...}}      -> flat record + rows_affected=1
    Rust Read:    {"found": bool, "record": {...}} -> flat record
    Rust Update:  {"updated_count": N}             -> {"rows_affected": N}
    Rust Delete:  {"deleted_count": N, ...}        -> {"rows_affected": N}
    Rust List:    {"records": [...], ...}           -> unchanged (already matches)
    Rust Count:   {"count": N}                     -> unchanged (already matches)
    """
    normalized = {}
    for node_id, output in results.items():
        action = crud_actions.get(node_id)
        if action is None or not isinstance(output, dict):
            normalized[node_id] = output
            continue

        if action == "Create" or action == "BulkCreate":
            record = output.get("record") or {}
            flat = dict(record) if isinstance(record, dict) else {}
            flat["rows_affected"] = 1
            normalized[node_id] = flat
        elif action == "Read":
            record = output.get("record") or {}
            flat = dict(record) if isinstance(record, dict) else {}
            flat["found"] = output.get("found", bool(record))
            normalized[node_id] = flat
        elif action in ("Update", "BulkUpdate", "Upsert", "BulkUpsert"):
            flat = dict(output)
            count = output.get("updated_count", 0)
            flat["rows_affected"] = count
            flat["updated"] = count > 0
            normalized[node_id] = flat
        elif action in ("Delete", "BulkDelete"):
            flat = dict(output)
            count = output.get("deleted_count", 0)
            flat["rows_affected"] = count
            flat["deleted"] = count
            flat["success"] = count > 0
            normalized[node_id] = flat
        else:
            # List, Count, etc. -- pass through
            normalized[node_id] = output

    return normalized


class LocalRuntime:
    """Backward-compatible synchronous runtime.

    Matches the v0.12 ``LocalRuntime`` API: no registry required in the
    constructor, and ``execute()`` returns a ``(results, run_id)`` tuple.

    Args:
        debug: Enable debug logging.
        max_concurrent_nodes: Maximum parallel nodes (0 = auto).
        **kwargs: Additional v0.12 config parameters (accepted but ignored
            with a warning if not supported by the Rust backend).
    """

    def __init__(
        self,
        debug: bool = False,
        max_concurrent_nodes: int = 0,
        **kwargs: Any,
    ) -> None:
        _emit_deprecation("LocalRuntime", "kailash.Runtime")
        self._registry = _NodeRegistry()
        config = _RuntimeConfig(
            debug=debug,
            max_concurrent_nodes=max_concurrent_nodes,
        )
        self._runtime = _Runtime(self._registry, config)

        # Warn about v0.12 params that aren't exposed in the Rust backend
        _v2_params = {"debug", "max_concurrent_nodes"}
        unsupported = set(kwargs.keys()) - _v2_params
        if unsupported:
            warnings.warn(
                f"LocalRuntime config parameters {unsupported} are not "
                f"supported in Kailash v2.0 and will be ignored. "
                f"The Rust backend handles these internally.",
                DeprecationWarning,
                stacklevel=2,
            )

    # Context manager support (v0.12 compatibility)
    def __enter__(self) -> "LocalRuntime":
        return self

    def __exit__(self, *args: Any) -> None:
        pass

    @property
    def registry(self) -> _NodeRegistry:
        """Access the underlying NodeRegistry."""
        return self._registry

    def execute(
        self,
        workflow: Any,
        task_manager: Any = None,
        parameters: Optional[Dict[str, Any]] = None,
        inputs: Optional[Dict[str, Any]] = None,
    ) -> Tuple[Dict[str, Any], str]:
        """Execute a workflow synchronously.

        Supports the v0.12 calling convention::

            results, run_id = runtime.execute(workflow, parameters={"node_id": {...}})

        And the v2 calling convention::

            results, run_id = runtime.execute(workflow, inputs={"key": value})

        Args:
            workflow: The workflow to execute (v0.12 or v2 object).
            task_manager: Ignored (v0.12 compatibility; Rust manages tasks internally).
            parameters: Per-node parameter overrides ``{"node_id": {"param": val}}``.
                Merged into a flat inputs dict for the Rust runtime.
            inputs: Flat workflow-level inputs dict (v2 API).

        Returns:
            A ``(results, run_id)`` tuple matching the v0.12 API.
            ``results`` maps node IDs to their output dicts.
        """
        # v0.12 shorthand: execute(wf, {"key": val}) where the second positional
        # arg was a flat inputs dict. Detect this: plain dict, no parameters/inputs.
        if (
            task_manager is not None
            and isinstance(task_manager, dict)
            and parameters is None
            and inputs is None
        ):
            inputs = task_manager
            task_manager = None

        if task_manager is not None:
            warnings.warn(
                "task_manager is not supported in Kailash v2.0 and will be "
                "ignored. The Rust runtime manages execution internally.",
                DeprecationWarning,
                stacklevel=2,
            )

        # Merge v0.12 per-node parameters into flat inputs for Rust runtime.
        # In v0.12, parameters is {"node_id": {"param": val}}.
        # In Rust, inputs is a flat dict passed to the workflow entry point.
        # We merge all per-node values into a flat dict keyed by "node_id.param".
        effective_inputs: Optional[Dict[str, Any]] = inputs
        if parameters is not None:
            flat: Dict[str, Any] = dict(inputs) if inputs else {}
            for node_id, node_params in parameters.items():
                if isinstance(node_params, dict):
                    for k, v in node_params.items():
                        flat[f"{node_id}.{k}"] = v
            effective_inputs = flat if flat else None

        # Handle v0.12 Workflow objects (which wrap the real Workflow)
        crud_actions = getattr(workflow, "_crud_actions", {})
        wf = workflow._workflow if hasattr(workflow, "_workflow") else workflow
        result = self._runtime.execute(wf, effective_inputs)
        results = result["results"]

        # Normalize CRUD node output to match old Python SDK format
        if crud_actions:
            results = _normalize_crud_results(results, crud_actions)

        return (results, result["run_id"])


class AsyncLocalRuntime:
    """Backward-compatible asynchronous runtime.

    Matches the v0.12 ``AsyncLocalRuntime`` API: no registry required,
    and ``execute_workflow_async()`` returns a ``(results, run_id)`` tuple.

    Args:
        debug: Enable debug logging.
        max_concurrent_nodes: Maximum parallel nodes (0 = auto).
        **kwargs: Additional v0.12 config parameters (accepted but ignored).
    """

    def __init__(
        self,
        debug: bool = False,
        max_concurrent_nodes: int = 0,
        **kwargs: Any,
    ) -> None:
        _emit_deprecation("AsyncLocalRuntime", "kailash.Runtime")
        self._registry = _NodeRegistry()
        config = _RuntimeConfig(
            debug=debug,
            max_concurrent_nodes=max_concurrent_nodes,
        )
        self._runtime = _Runtime(self._registry, config)

        unsupported = set(kwargs.keys()) - {"debug", "max_concurrent_nodes"}
        if unsupported:
            warnings.warn(
                f"AsyncLocalRuntime config parameters {unsupported} are not "
                f"supported in Kailash v2.0 and will be ignored.",
                DeprecationWarning,
                stacklevel=2,
            )

    # Context manager support (v0.12 compatibility)
    async def __aenter__(self) -> "AsyncLocalRuntime":
        return self

    async def __aexit__(self, *args: Any) -> None:
        pass

    @property
    def registry(self) -> _NodeRegistry:
        """Access the underlying NodeRegistry."""
        return self._registry

    async def execute_workflow_async(
        self,
        workflow: Any,
        task_manager: Any = None,
        parameters: Optional[Dict[str, Any]] = None,
        inputs: Optional[Dict[str, Any]] = None,
    ) -> Tuple[Dict[str, Any], str]:
        """Execute a workflow asynchronously.

        Supports the v0.12 calling convention::

            results, run_id = await runtime.execute_workflow_async(workflow, parameters={...})

        Args:
            workflow: The workflow to execute.
            task_manager: Ignored (v0.12 compatibility).
            parameters: Per-node parameter overrides ``{"node_id": {"param": val}}``.
            inputs: Flat workflow-level inputs dict (v2 API).

        Returns:
            A ``(results, run_id)`` tuple matching the v0.12 API.
        """
        # v0.12 shorthand: execute_workflow_async(wf, {"key": val}) where the
        # second positional arg was a flat inputs dict.
        if (
            task_manager is not None
            and isinstance(task_manager, dict)
            and parameters is None
            and inputs is None
        ):
            inputs = task_manager
            task_manager = None

        if task_manager is not None:
            warnings.warn(
                "task_manager is not supported in Kailash v2.0 and will be ignored.",
                DeprecationWarning,
                stacklevel=2,
            )

        effective_inputs: Optional[Dict[str, Any]] = inputs
        if parameters is not None:
            flat: Dict[str, Any] = dict(inputs) if inputs else {}
            for node_id, node_params in parameters.items():
                if isinstance(node_params, dict):
                    for k, v in node_params.items():
                        flat[f"{node_id}.{k}"] = v
            effective_inputs = flat if flat else None

        crud_actions = getattr(workflow, "_crud_actions", {})
        wf = workflow._workflow if hasattr(workflow, "_workflow") else workflow
        result = await self._runtime.execute_async(wf, effective_inputs)
        results = result["results"]

        if crud_actions:
            results = _normalize_crud_results(results, crud_actions)

        return (results, result["run_id"])


def get_runtime(**kwargs: Any) -> "LocalRuntime | AsyncLocalRuntime":
    """Return an appropriate runtime based on whether an event loop is running.

    If called from within a running asyncio event loop, returns an
    ``AsyncLocalRuntime``. Otherwise returns a ``LocalRuntime``.

    This matches the v0.12 ``get_runtime()`` convenience function.
    """
    _emit_deprecation("get_runtime()", "kailash.Runtime")
    try:
        asyncio.get_running_loop()
        return AsyncLocalRuntime(**kwargs)
    except RuntimeError:
        return LocalRuntime(**kwargs)
