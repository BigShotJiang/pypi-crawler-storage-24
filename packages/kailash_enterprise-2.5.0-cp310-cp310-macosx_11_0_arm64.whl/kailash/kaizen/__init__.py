"""Kailash Kaizen — AI agent framework.

Re-exports Rust-backed AI agent types and Python compat helpers::

    # Rust-backed types
    from kailash.kaizen import Agent, AgentConfig, LlmClient
    from kailash.kaizen import CostTracker, OrchestrationRuntime
    from kailash.kaizen import ToolParam, ToolDef, ToolRegistry
    from kailash.kaizen import SessionMemory, SharedMemory
    from kailash.kaizen import AgentCheckpoint, InMemoryCheckpointStorage
    from kailash.kaizen import AgentCard, AgentRegistry, A2AProtocol
    from kailash.kaizen import TrustLevel, TrustPosture
    from kailash.kaizen import OutputSchema, RetryConfig, StructuredOutput

    # Python compat helpers
    from kailash.kaizen import BaseAgent, HookManager
    from kailash.kaizen import InputField, OutputField, Signature
    from kailash.kaizen import InterruptManager, ControlProtocol
    from kailash.kaizen.agents import SimpleQAAgent, ReActAgent, RAGAgent
    from kailash.kaizen.pipelines import SequentialPipeline, ParallelPipeline

All Rust classes are backed by the ``kailash-kaizen`` crate via PyO3.
Python compat helpers provide higher-level patterns on top.
"""

from kailash._kailash import (
    # Core agent types
    Agent,
    AgentConfig,
    CostTracker,
    LlmClient,
    OrchestrationRuntime,
    # Tool system
    ToolParam,
    ToolDef,
    ToolRegistry,
    # Memory system
    SessionMemory,
    SharedMemory,
    PersistentMemory,
    # Checkpoint system
    AgentCheckpoint,
    InMemoryCheckpointStorage,
    FileCheckpointStorage,
    # A2A protocol
    AgentCard,
    AgentRegistry,
    InMemoryMessageBus,
    A2AProtocol,
    # EATP Trust framework
    TrustLevel,
    TrustPosture,
)

# Structured output types (requires Rust binding rebuild after P17-016)
try:
    from kailash._kailash import (
        OutputSchema,
        RetryConfig,
        StructuredOutput,
    )
except ImportError:
    OutputSchema = None  # type: ignore[assignment,misc]
    RetryConfig = None  # type: ignore[assignment,misc]
    StructuredOutput = None  # type: ignore[assignment,misc]

# Streaming types (requires Rust binding rebuild after P17-017)
try:
    from kailash._kailash import (
        StreamHandler,
        StreamingAgent,
        StreamEvent,
        TokenCollector,
        ChannelStreamHandler,
    )
except ImportError:
    StreamHandler = None  # type: ignore[assignment,misc]
    StreamingAgent = None  # type: ignore[assignment,misc]
    StreamEvent = None  # type: ignore[assignment,misc]
    TokenCollector = None  # type: ignore[assignment,misc]
    ChannelStreamHandler = None  # type: ignore[assignment,misc]

# Observability stack (requires Rust binding rebuild after P17-016)
try:
    from kailash._kailash import (
        MetricsCollector,
        SpanContext,
        TracingManager,
        LogAggregator,
        ObservabilityManager,
    )
except ImportError:
    MetricsCollector = None  # type: ignore[assignment,misc]
    SpanContext = None  # type: ignore[assignment,misc]
    TracingManager = None  # type: ignore[assignment,misc]
    LogAggregator = None  # type: ignore[assignment,misc]
    ObservabilityManager = None  # type: ignore[assignment,misc]

# Multimodal processing (requires Rust binding rebuild after P17-017)
try:
    from kailash._kailash import (
        ImageInput,
        AudioInput,
        MultimodalInput,
        VisionProcessor,
        AudioProcessor,
        MultimodalOrchestrator,
    )
except ImportError:
    ImageInput = None  # type: ignore[assignment,misc]
    AudioInput = None  # type: ignore[assignment,misc]
    MultimodalInput = None  # type: ignore[assignment,misc]
    VisionProcessor = None  # type: ignore[assignment,misc]
    AudioProcessor = None  # type: ignore[assignment,misc]
    MultimodalOrchestrator = None  # type: ignore[assignment,misc]

# DX tools (requires Rust binding rebuild after P17-019)
try:
    from kailash._kailash import (
        JourneyOrchestrator,
        JourneyStep,
        JourneyResult,
        UXHelper,
        UnifiedMemory,
        AgentInterrupt,
    )
except ImportError:
    JourneyOrchestrator = None  # type: ignore[assignment,misc]
    JourneyStep = None  # type: ignore[assignment,misc]
    JourneyResult = None  # type: ignore[assignment,misc]
    UXHelper = None  # type: ignore[assignment,misc]
    UnifiedMemory = None  # type: ignore[assignment,misc]
    AgentInterrupt = None  # type: ignore[assignment,misc]

try:
    from kailash._kailash import DxTrustManager
except ImportError:
    DxTrustManager = None  # type: ignore[assignment,misc]

# Multi-agent orchestration (Python compat with Rust backend)
from kailash.kaizen.orchestration import (
    SupervisorAgent,
    WorkerAgent,
    MultiAgentOrchestrator,
    AgentExecutor,
    RetryPolicy,
)

# Python compat: BaseAgent and hooks
from kailash.kaizen.agent import BaseAgent
from kailash.kaizen.hooks import HookManager
from kailash.kaizen.signature import InputField, OutputField, Signature
from kailash.kaizen.control import ControlProtocol, InterruptManager

__all__ = [
    # Core agent types (Rust)
    "Agent",
    "AgentConfig",
    "LlmClient",
    "CostTracker",
    "OrchestrationRuntime",
    # Tool system (Rust)
    "ToolParam",
    "ToolDef",
    "ToolRegistry",
    # Memory system (Rust)
    "SessionMemory",
    "SharedMemory",
    "PersistentMemory",
    # Checkpoint system (Rust)
    "AgentCheckpoint",
    "InMemoryCheckpointStorage",
    "FileCheckpointStorage",
    # A2A protocol (Rust)
    "AgentCard",
    "AgentRegistry",
    "InMemoryMessageBus",
    "A2AProtocol",
    # EATP Trust framework (Rust)
    "TrustLevel",
    "TrustPosture",
    # Python compat: BaseAgent
    "BaseAgent",
    # Python compat: Hooks
    "HookManager",
    # Python compat: Signature
    "InputField",
    "OutputField",
    "Signature",
    # Python compat: Control
    "InterruptManager",
    "ControlProtocol",
    # Structured output (Rust)
    "OutputSchema",
    "RetryConfig",
    "StructuredOutput",
    # Streaming (Rust)
    "StreamHandler",
    "StreamingAgent",
    "StreamEvent",
    "TokenCollector",
    "ChannelStreamHandler",
    # Observability (Rust)
    "MetricsCollector",
    "SpanContext",
    "TracingManager",
    "LogAggregator",
    "ObservabilityManager",
    # Multimodal (Rust)
    "ImageInput",
    "AudioInput",
    "MultimodalInput",
    "VisionProcessor",
    "AudioProcessor",
    "MultimodalOrchestrator",
    # Multi-agent orchestration (Python compat)
    "SupervisorAgent",
    "WorkerAgent",
    "MultiAgentOrchestrator",
    "AgentExecutor",
    "RetryPolicy",
    # DX tools (Rust)
    "JourneyOrchestrator",
    "JourneyStep",
    "JourneyResult",
    "UXHelper",
    "DxTrustManager",
    "UnifiedMemory",
    "AgentInterrupt",
]
