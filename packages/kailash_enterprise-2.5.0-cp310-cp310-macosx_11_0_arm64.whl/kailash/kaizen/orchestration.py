"""Multi-agent orchestration: SupervisorAgent, WorkerAgent, MultiAgentOrchestrator, AgentExecutor.

Pythonic wrappers around the Rust-backed orchestration types::

    from kailash.kaizen.orchestration import (
        SupervisorAgent,
        WorkerAgent,
        MultiAgentOrchestrator,
        AgentExecutor,
        RetryPolicy,
    )

    # Create workers
    worker1 = WorkerAgent("coder", lambda x: f"coded: {x}", capabilities=["python"])
    worker2 = WorkerAgent("writer", lambda x: f"wrote: {x}", capabilities=["docs"])

    # Create supervisor
    supervisor = SupervisorAgent("boss")
    supervisor.add_worker(worker1)
    supervisor.add_worker(worker2)
    result = supervisor.run("Write Python code")

    # Multi-agent orchestration with dependencies
    orchestrator = MultiAgentOrchestrator()
    orchestrator.add_agent("researcher", lambda x: f"researched: {x}")
    orchestrator.add_agent("writer", lambda x: f"wrote: {x}")
    orchestrator.add_route("always", "researcher")
    orchestrator.add_route("always", "writer")
    orchestrator.add_dependency("writer", "researcher")
    result = orchestrator.orchestrate("Write about Rust")
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Union

try:
    from kailash._kailash import (
        WorkerAgent as _RustWorkerAgent,
        SupervisorAgent as _RustSupervisorAgent,
        MultiAgentOrchestrator as _RustMultiAgentOrchestrator,
        AgentExecutor as _RustAgentExecutor,
        RetryPolicy as _RustRetryPolicy,
    )
    _HAS_RUST_BINDINGS = True
except ImportError:
    _HAS_RUST_BINDINGS = False


class WorkerAgent:
    """A worker agent that receives tasks and reports results.

    Wraps a Python callable with capability declarations, status tracking,
    and progress reporting.

    Args:
        name: Human-readable name for this worker.
        callback: A callable ``(input: str) -> str`` that processes tasks.
        capabilities: Optional list of capability strings for routing.
        description: Optional description of the worker.

    Example::

        def code_fn(input_text):
            return f"coded: {input_text}"

        worker = WorkerAgent("coder", code_fn, capabilities=["python", "rust"])
        assert worker.accept_task("write python code")
        result = worker.run("fix the bug")
    """

    def __init__(
        self,
        name: str,
        callback: Callable[[str], str],
        capabilities: Optional[List[str]] = None,
        description: Optional[str] = None,
    ) -> None:
        self._name = name
        self._callback = callback
        self._capabilities = [c.lower() for c in (capabilities or [])]
        self._description = description or f"worker '{name}'"
        self._status = "idle"
        self._progress = 0.0

        if _HAS_RUST_BINDINGS:
            self._rust = _RustWorkerAgent(
                name=name,
                callback=callback,
                capabilities=capabilities,
                description=description,
            )
        else:
            self._rust = None

    @property
    def name(self) -> str:
        """The worker's name."""
        return self._name

    @property
    def capabilities(self) -> List[str]:
        """The worker's capabilities."""
        if self._rust is not None:
            return self._rust.capabilities
        return list(self._capabilities)

    @property
    def status(self) -> str:
        """Current status: 'idle', 'working', or 'failed'."""
        if self._rust is not None:
            return self._rust.status
        return self._status

    @property
    def progress(self) -> float:
        """Current progress as a float between 0.0 and 1.0."""
        if self._rust is not None:
            return self._rust.progress
        return self._progress

    def accept_task(self, task: str) -> bool:
        """Check whether this worker can handle the given task.

        Returns True if any capability keyword appears in the task text
        (case-insensitive), or if the worker has no capabilities declared.

        Args:
            task: The task description to check.
        """
        if self._rust is not None:
            return self._rust.accept_task(task)
        if not self._capabilities:
            return True
        task_lower = task.lower()
        return any(cap in task_lower for cap in self._capabilities)

    def report_progress(self, progress: float) -> None:
        """Report execution progress (0.0 to 1.0)."""
        self._progress = max(0.0, min(1.0, progress))
        if self._rust is not None:
            self._rust.report_progress(progress)

    def run(self, input_text: str) -> Dict[str, Any]:
        """Execute the worker with the given input.

        Args:
            input_text: The task input text.

        Returns:
            A dict with at least a ``response`` key.
        """
        if self._rust is not None:
            return self._rust.run(input_text)

        self._status = "working"
        self._progress = 0.0
        try:
            response = self._callback(input_text)
            self._progress = 1.0
            self._status = "idle"
            return {"response": response}
        except Exception as exc:
            self._status = "failed"
            raise RuntimeError(f"worker '{self._name}' failed: {exc}") from exc

    def __repr__(self) -> str:
        return (
            f"WorkerAgent(name={self._name!r}, "
            f"capabilities={self._capabilities}, "
            f"status={self.status!r})"
        )


class SupervisorAgent:
    """A supervisor agent that delegates tasks to worker agents.

    Routes tasks to workers based on a configurable routing strategy.

    Args:
        name: The supervisor's name.
        routing: Routing strategy. One of ``"round_robin"``, ``"capability"``
            (default), or ``"llm_decision"``.
        max_delegation_depth: Maximum delegation depth (default 3).

    Example::

        supervisor = SupervisorAgent("boss")
        supervisor.add_worker(worker1)
        supervisor.add_worker(worker2)
        result = supervisor.run("Write Python code")
    """

    def __init__(
        self,
        name: str,
        routing: str = "capability",
        max_delegation_depth: int = 3,
    ) -> None:
        self._name = name
        self._routing = routing
        self._max_delegation_depth = max_delegation_depth
        self._workers: List[WorkerAgent] = []

        if _HAS_RUST_BINDINGS:
            self._rust = _RustSupervisorAgent(
                name=name,
                routing=routing,
                max_delegation_depth=max_delegation_depth,
            )
        else:
            self._rust = None
        self._rr_index = 0

    @property
    def name(self) -> str:
        """The supervisor's name."""
        return self._name

    @property
    def worker_count(self) -> int:
        """Number of registered workers."""
        if self._rust is not None:
            return self._rust.worker_count
        return len(self._workers)

    @property
    def worker_names(self) -> List[str]:
        """Names of all registered workers."""
        if self._rust is not None:
            return self._rust.worker_names
        return [w.name for w in self._workers]

    def add_worker(self, worker: WorkerAgent) -> None:
        """Add a worker to this supervisor's pool.

        Args:
            worker: A WorkerAgent instance.
        """
        self._workers.append(worker)
        if self._rust is not None and worker._rust is not None:
            self._rust.add_worker(worker._rust)

    def worker_statuses(self) -> List[tuple[str, str]]:
        """Returns status of all workers as ``(name, status)`` pairs."""
        if self._rust is not None:
            return self._rust.worker_statuses()
        return [(w.name, w.status) for w in self._workers]

    def run(self, input_text: str) -> Dict[str, Any]:
        """Execute the supervisor, delegating to an appropriate worker.

        Args:
            input_text: The task input text.

        Returns:
            A dict with at least a ``response`` key.

        Raises:
            RuntimeError: If no workers are registered or routing fails.
        """
        if self._rust is not None:
            return self._rust.run(input_text)

        if not self._workers:
            raise RuntimeError(
                f"supervisor '{self._name}' has no workers registered"
            )

        worker = self._route_task(input_text)
        return worker.run(input_text)

    def _route_task(self, task: str) -> WorkerAgent:
        """Route a task to a worker based on the routing strategy."""
        if self._routing == "round_robin":
            worker = self._workers[self._rr_index % len(self._workers)]
            self._rr_index += 1
            return worker
        elif self._routing in ("capability", "llm_decision"):
            for w in self._workers:
                if w.accept_task(task):
                    return w
            return self._workers[0]
        else:
            raise ValueError(f"unknown routing strategy: {self._routing!r}")

    def __repr__(self) -> str:
        return (
            f"SupervisorAgent(name={self._name!r}, "
            f"workers={len(self._workers)}, "
            f"routing={self._routing!r})"
        )


class MultiAgentOrchestrator:
    """Multi-agent orchestrator with conditional routing and dependency tracking.

    Manages complex multi-agent workflows with dynamic agent selection,
    concurrent execution, and result aggregation.

    Example::

        orchestrator = MultiAgentOrchestrator()
        orchestrator.add_agent("researcher", lambda x: f"researched: {x}")
        orchestrator.add_agent("writer", lambda x: f"wrote: {x}")
        orchestrator.add_route("always", "researcher")
        orchestrator.add_route("always", "writer")
        orchestrator.add_dependency("writer", "researcher")
        result = orchestrator.orchestrate("Write about Rust")
    """

    def __init__(self) -> None:
        self._agents: Dict[str, Callable[[str], str]] = {}
        self._routes: List[tuple[str, str]] = []
        self._dependencies: Dict[str, List[str]] = {}
        self._concurrency_limit = 10

        if _HAS_RUST_BINDINGS:
            self._rust = _RustMultiAgentOrchestrator()
        else:
            self._rust = None

    @property
    def agent_count(self) -> int:
        """Number of registered agents."""
        if self._rust is not None:
            return self._rust.agent_count
        return len(self._agents)

    @property
    def agent_names(self) -> List[str]:
        """Names of all registered agents."""
        if self._rust is not None:
            return self._rust.agent_names
        return list(self._agents.keys())

    def add_agent(
        self,
        name: str,
        callback: Callable[[str], str],
        description: Optional[str] = None,
    ) -> None:
        """Register an agent by name.

        Args:
            name: Agent identifier.
            callback: A callable ``(input: str) -> str``.
            description: Optional agent description.
        """
        self._agents[name] = callback
        if self._rust is not None:
            self._rust.add_agent(name, callback, description)

    def add_route(self, condition: str, target_agent: str) -> None:
        """Add a routing rule.

        Args:
            condition: One of ``"always"``, ``"contains:<text>"``,
                or ``"regex:<pattern>"``.
            target_agent: The name of the agent to route to.

        Raises:
            ValueError: If the condition format is invalid.
        """
        self._routes.append((condition, target_agent))
        if self._rust is not None:
            self._rust.add_route(condition, target_agent)

    def add_custom_route(
        self,
        predicate: Callable[[str], bool],
        target_agent: str,
    ) -> None:
        """Add a routing rule with a custom predicate.

        Args:
            predicate: A callable ``(input: str) -> bool``.
            target_agent: The name of the agent to route to.
        """
        self._routes.append(("custom", target_agent))
        if self._rust is not None:
            self._rust.add_custom_route(predicate, target_agent)

    def add_dependency(self, dependent: str, dependency: str) -> None:
        """Declare that ``dependent`` must wait for ``dependency``.

        Args:
            dependent: The agent that must wait.
            dependency: The agent that must complete first.
        """
        self._dependencies.setdefault(dependent, []).append(dependency)
        if self._rust is not None:
            self._rust.add_dependency(dependent, dependency)

    def set_concurrency_limit(self, limit: int) -> None:
        """Set the maximum concurrency (default 10)."""
        self._concurrency_limit = max(1, limit)
        if self._rust is not None:
            self._rust.set_concurrency_limit(limit)

    def orchestrate(self, input_text: str) -> Dict[str, Any]:
        """Run the orchestration with the given input.

        Args:
            input_text: The task input text.

        Returns:
            A dict with ``final_output``, ``agent_results``, ``total_tokens``, etc.

        Raises:
            RuntimeError: If no agents, no matching routes, or circular dependency.
        """
        if self._rust is not None:
            return self._rust.orchestrate(input_text)

        # Pure Python fallback: simple sequential execution
        if not self._agents:
            raise RuntimeError("no agents registered in orchestrator")

        selected = self._select_agents(input_text)
        if not selected:
            raise RuntimeError("no routes matched the input")

        results: Dict[str, Any] = {}
        for agent_name in selected:
            callback = self._agents[agent_name]
            deps = self._dependencies.get(agent_name, [])
            if deps:
                dep_outputs = [
                    results[d]["response"] for d in deps if d in results
                ]
                agent_input = "\n\n".join(dep_outputs) if dep_outputs else input_text
            else:
                agent_input = input_text
            response = callback(agent_input)
            results[agent_name] = {"response": response, "total_tokens": 0}

        final_output = list(results.values())[-1]["response"] if results else ""

        return {
            "final_output": final_output,
            "agent_results": results,
            "total_iterations": len(results),
            "total_tokens": 0,
            "duration_ms": 0,
        }

    def _select_agents(self, input_text: str) -> List[str]:
        """Select agents whose routing conditions match the input."""
        selected = []
        seen = set()
        for condition, target in self._routes:
            if target not in self._agents:
                continue
            if target in seen:
                continue
            if self._matches_condition(condition, input_text):
                selected.append(target)
                seen.add(target)
        return selected

    def _matches_condition(self, condition: str, input_text: str) -> bool:
        """Check if a routing condition matches."""
        if condition == "always":
            return True
        if condition.startswith("contains:"):
            text = condition[len("contains:"):]
            return text.lower() in input_text.lower()
        if condition.startswith("regex:"):
            pattern = condition[len("regex:"):]
            return pattern.lower() in input_text.lower()
        if condition == "custom":
            return True  # Custom routes are handled in Rust
        return False

    def __repr__(self) -> str:
        return f"MultiAgentOrchestrator(agents={len(self._agents)})"


class RetryPolicy:
    """Retry policy configuration for the agent executor.

    Args:
        max_retries: Maximum number of retry attempts (default 3).
        backoff: Backoff strategy (``"fixed"`` or ``"exponential"``).
        base_delay_ms: Base delay in milliseconds (default 100).
        max_delay_ms: Maximum delay for exponential backoff (default 5000).

    Example::

        policy = RetryPolicy(max_retries=3, backoff="exponential")
    """

    def __init__(
        self,
        max_retries: int = 3,
        backoff: str = "exponential",
        base_delay_ms: int = 100,
        max_delay_ms: int = 5000,
    ) -> None:
        self._max_retries = max_retries
        self._backoff = backoff
        self._base_delay_ms = base_delay_ms
        self._max_delay_ms = max_delay_ms

        if _HAS_RUST_BINDINGS:
            self._rust = _RustRetryPolicy(
                max_retries=max_retries,
                backoff=backoff,
                base_delay_ms=base_delay_ms,
                max_delay_ms=max_delay_ms,
            )
        else:
            self._rust = None

    @property
    def max_retries(self) -> int:
        """Maximum retry attempts."""
        return self._max_retries

    def __repr__(self) -> str:
        return (
            f"RetryPolicy(max_retries={self._max_retries}, "
            f"backoff={self._backoff!r})"
        )


class AgentExecutor:
    """Unified execution engine with retry, timeout, and observability.

    Args:
        retry_policy: Optional RetryPolicy for automatic retries.
        agent_timeout_ms: Optional per-agent timeout in milliseconds.
        global_timeout_ms: Optional global timeout in milliseconds.

    Example::

        policy = RetryPolicy(max_retries=3)
        executor = AgentExecutor(retry_policy=policy, agent_timeout_ms=30000)
        result = executor.execute_single(worker, "hello")
    """

    def __init__(
        self,
        retry_policy: Optional[RetryPolicy] = None,
        agent_timeout_ms: Optional[int] = None,
        global_timeout_ms: Optional[int] = None,
    ) -> None:
        self._retry_policy = retry_policy
        self._agent_timeout_ms = agent_timeout_ms
        self._global_timeout_ms = global_timeout_ms

        if _HAS_RUST_BINDINGS:
            rust_policy = retry_policy._rust if retry_policy and retry_policy._rust else None
            self._rust = _RustAgentExecutor(
                retry_policy=rust_policy,
                agent_timeout_ms=agent_timeout_ms,
                global_timeout_ms=global_timeout_ms,
            )
        else:
            self._rust = None

    def execute_single(
        self,
        worker: WorkerAgent,
        input_text: str,
    ) -> Dict[str, Any]:
        """Execute a single worker agent with retry and timeout logic.

        Args:
            worker: A WorkerAgent instance.
            input_text: The task input text.

        Returns:
            A dict with ``response``, ``total_tokens``, etc.

        Raises:
            RuntimeError: On execution failure after all retries.
        """
        if self._rust is not None and worker._rust is not None:
            return self._rust.execute_single(worker._rust, input_text)

        # Pure Python fallback
        max_retries = self._retry_policy.max_retries if self._retry_policy else 0
        last_error = None

        for attempt in range(max_retries + 1):
            try:
                return worker.run(input_text)
            except Exception as exc:
                last_error = exc
                if attempt < max_retries:
                    import time
                    delay = (self._retry_policy._base_delay_ms / 1000.0
                             if self._retry_policy else 0.1)
                    time.sleep(delay)

        raise RuntimeError(
            f"execution failed after {max_retries + 1} attempts: {last_error}"
        ) from last_error

    def __repr__(self) -> str:
        return (
            f"AgentExecutor(retry={self._retry_policy}, "
            f"agent_timeout={self._agent_timeout_ms}ms, "
            f"global_timeout={self._global_timeout_ms}ms)"
        )
