"""Pythonic BaseAgent wrapping Rust Agent types.

Provides a subclass-friendly interface for building AI agents::

    class MyAgent(BaseAgent):
        name = "my-agent"
        system_prompt = "You are helpful."

        def execute(self, input_text: str) -> dict:
            return {"response": f"Echo: {input_text}"}

Structured output integration::

    from kailash.kaizen import BaseAgent, OutputSchema

    class StructuredAgent(BaseAgent):
        name = "structured-agent"
        output_schema = {"type": "object", "required": ["answer"]}

        def execute(self, input_text: str) -> dict:
            raw = '{"answer": "42"}'
            return self.apply_output_schema({"response": raw})
"""

from __future__ import annotations

import json
from typing import Any, Callable, Optional, Union

from kailash._kailash import (
    AgentConfig,
    OutputSchema,
    SessionMemory,
    SharedMemory,
    StructuredOutput,
    ToolDef,
    ToolParam,
    ToolRegistry,
)


class BaseAgent:
    """Subclass-friendly Python agent wrapping Rust Agent types.

    Class-level attributes can be overridden by subclasses or keyword arguments
    passed to ``__init__``.

    Attributes:
        name: Agent name.
        description: Agent description.
        system_prompt: System prompt for the agent.
        model: LLM model name (None = use default from env).
        max_iterations: Maximum TAOD loop iterations.
        temperature: Sampling temperature (None = provider default).
        max_tokens: Maximum response tokens (None = no limit).
        output_schema: Optional JSON schema dict or ``OutputSchema`` for
            structured output. When set, ``apply_output_schema()`` validates
            the response against this schema.
    """

    name: str = "BaseAgent"
    description: str = ""
    system_prompt: str = ""
    model: Optional[str] = None
    max_iterations: int = 10
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    output_schema: Optional[Union[dict, OutputSchema]] = None

    def __init__(self, **kwargs: Any) -> None:
        for key in ("name", "description", "system_prompt", "model",
                     "max_iterations", "temperature", "max_tokens",
                     "output_schema"):
            if key in kwargs:
                setattr(self, key, kwargs[key])

        self._config = AgentConfig(
            model=self.model,
            system_prompt=self.system_prompt or None,
            max_iterations=self.max_iterations,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )

        self._tool_registry = ToolRegistry()
        self._memory: Optional[Any] = None
        self._hooks: dict[str, list[Callable[..., Any]]] = {}

        # Initialize structured output if schema is provided
        self._structured_output: Optional[StructuredOutput] = None
        if self.output_schema is not None:
            if isinstance(self.output_schema, dict):
                self._structured_output = StructuredOutput(
                    schema=self.output_schema,
                )
            elif isinstance(self.output_schema, OutputSchema):
                self._structured_output = StructuredOutput(
                    schema=self.output_schema,
                )
            else:
                raise TypeError(
                    f"output_schema must be a dict or OutputSchema, "
                    f"got {type(self.output_schema).__name__}"
                )

    @property
    def config(self) -> AgentConfig:
        """The underlying Rust AgentConfig."""
        return self._config

    @property
    def tool_registry(self) -> ToolRegistry:
        """The tool registry for this agent."""
        return self._tool_registry

    @property
    def memory(self) -> Optional[Any]:
        """The attached memory instance (SessionMemory or SharedMemory)."""
        return self._memory

    @property
    def structured_output(self) -> Optional[StructuredOutput]:
        """The configured StructuredOutput instance, if any."""
        return self._structured_output

    def execute(self, input_text: str) -> dict:
        """Override point for subclasses.

        Args:
            input_text: The user input to process.

        Returns:
            A dict with at least a ``"response"`` key.

        Raises:
            NotImplementedError: If subclass does not implement this method.
        """
        raise NotImplementedError("Subclass must implement execute()")

    def run(self, input_text: str) -> dict:
        """Alias for execute().

        Args:
            input_text: The user input to process.

        Returns:
            The result dict from execute().
        """
        return self.execute(input_text)

    def apply_output_schema(self, result: dict) -> dict:
        """Apply structured output validation to a result dict.

        If ``output_schema`` is configured, parses the ``response`` field
        and replaces it with the validated and parsed data.

        Args:
            result: A result dict with a ``"response"`` key containing
                raw LLM text.

        Returns:
            The result dict, with ``"response"`` replaced by the parsed
            dict if structured output is configured. If no schema is
            configured, returns the result unchanged.

        Raises:
            ValueError: If the response cannot be parsed or validated
                against the schema.
        """
        if self._structured_output is None:
            return result

        raw_response = result.get("response")
        if raw_response is None:
            raise ValueError(
                "result dict must contain a 'response' key for "
                "structured output processing"
            )

        if not isinstance(raw_response, str):
            raise TypeError(
                f"result['response'] must be a string for structured "
                f"output parsing, got {type(raw_response).__name__}"
            )

        parsed = self._structured_output.parse(raw_response)
        result["response"] = parsed
        return result

    def extract_str(self, result: dict, key: str) -> str:
        """Extract a string value from a result dict.

        Supports dotted key paths like ``'output.text'``.

        Args:
            result: The dict to traverse.
            key: A dotted key path (e.g. ``"nested.text"``).

        Returns:
            The string value at the key path.

        Raises:
            TypeError: If an intermediate value is not a dict, or the
                final value is not a str.
            KeyError: If any key segment is missing.
        """
        value: Any = result
        for part in key.split('.'):
            if not isinstance(value, dict):
                raise TypeError(
                    f"Cannot traverse into {type(value).__name__} at key '{part}'"
                )
            if part not in value:
                raise KeyError(f"Key '{part}' not found in result")
            value = value[part]
        if not isinstance(value, str):
            raise TypeError(
                f"Expected str at '{key}', got {type(value).__name__}"
            )
        return value

    def extract_dict(self, result: dict, key: str) -> dict:
        """Extract a dict value from a result dict.

        Supports dotted key paths like ``'nested.data'``.

        Args:
            result: The dict to traverse.
            key: A dotted key path (e.g. ``"nested.data"``).

        Returns:
            The dict value at the key path.

        Raises:
            TypeError: If an intermediate value is not a dict, or the
                final value is not a dict.
            KeyError: If any key segment is missing.
        """
        value: Any = result
        for part in key.split('.'):
            if not isinstance(value, dict):
                raise TypeError(
                    f"Cannot traverse into {type(value).__name__} at key '{part}'"
                )
            if part not in value:
                raise KeyError(f"Key '{part}' not found in result")
            value = value[part]
        if not isinstance(value, dict):
            raise TypeError(
                f"Expected dict at '{key}', got {type(value).__name__}"
            )
        return value

    def write_to_memory(self, key: str, value: Any) -> None:
        """Store a value to agent memory.

        Auto-initializes a ``SessionMemory`` if none is currently set.

        Args:
            key: The memory key.
            value: The value to store.
        """
        if self._memory is None:
            self._memory = SessionMemory()
        self._memory.store(key, value)

    def register_tool(
        self,
        name: str,
        func: Callable[..., Any],
        description: str = "",
        params: Optional[list[dict[str, Any]]] = None,
    ) -> None:
        """Register a Python callable as a tool.

        Args:
            name: Unique tool name.
            func: Python callable that receives a dict of arguments.
            description: Description of the tool.
            params: Optional list of parameter dicts with keys:
                ``name``, ``param_type`` (default "string"),
                ``description``, ``required`` (default False).
        """
        tool_params = []
        if params:
            for p in params:
                tool_params.append(ToolParam(
                    name=p["name"],
                    param_type=p.get("param_type", "string"),
                    description=p.get("description"),
                    required=p.get("required", False),
                ))

        tool_def = ToolDef(name, description, func, tool_params or None)
        self._tool_registry.register(tool_def)

    def set_memory(self, memory: Any) -> None:
        """Attach a SessionMemory or SharedMemory instance.

        Args:
            memory: A SessionMemory or SharedMemory instance.

        Raises:
            TypeError: If the memory is not a supported type.
        """
        if not isinstance(memory, (SessionMemory, SharedMemory)):
            raise TypeError(
                f"Expected SessionMemory or SharedMemory, got {type(memory).__name__}"
            )
        self._memory = memory

    def __repr__(self) -> str:
        return f"{type(self).__name__}(name={self.name!r}, model={self.model!r})"
