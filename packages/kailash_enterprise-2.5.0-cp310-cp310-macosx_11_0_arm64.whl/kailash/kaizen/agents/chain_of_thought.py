"""Chain-of-thought reasoning agent."""

from __future__ import annotations

from kailash.kaizen.agent import BaseAgent


class ChainOfThoughtAgent(BaseAgent):
    """Step-by-step reasoning agent.

    Breaks problems down into logical steps before arriving at an answer.
    Suitable for math, logic puzzles, and multi-step reasoning tasks.

    Example::

        agent = ChainOfThoughtAgent()
        result = agent.execute("If a train travels 60mph for 2.5 hours, how far does it go?")
    """

    name: str = "ChainOfThoughtAgent"
    description: str = "Step-by-step reasoning agent"
    system_prompt: str = (
        "You are a reasoning assistant that thinks step by step. "
        "For every question, break down your reasoning into clear, "
        "numbered steps before giving your final answer. "
        "Format: Step 1: ..., Step 2: ..., Final Answer: ..."
    )
