"""Code generation agent."""

from __future__ import annotations

from kailash.kaizen.agent import BaseAgent


class CodeGenAgent(BaseAgent):
    """Code generation agent.

    Generates code based on natural language descriptions.
    Supports multiple programming languages.

    Example::

        agent = CodeGenAgent()
        result = agent.execute("Write a Python function to reverse a string")
    """

    name: str = "CodeGenAgent"
    description: str = "Code generation agent"
    system_prompt: str = (
        "You are an expert code generation assistant. "
        "Generate clean, well-documented code based on the user's description. "
        "Include type hints, docstrings, and handle edge cases. "
        "If the language is not specified, default to Python."
    )
