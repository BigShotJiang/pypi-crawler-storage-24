"""Agent with persistent memory."""

from __future__ import annotations

from typing import Any, Optional

from kailash._kailash import SessionMemory

from kailash.kaizen.agent import BaseAgent


class MemoryAgent(BaseAgent):
    """Agent with persistent session memory.

    Automatically stores and retrieves conversation history in the
    attached memory instance.

    Example::

        agent = MemoryAgent()
        result = agent.execute("Remember that my name is Alice")
        result = agent.execute("What is my name?")
    """

    name: str = "MemoryAgent"
    description: str = "Agent with persistent memory"
    system_prompt: str = (
        "You are an assistant with persistent memory. "
        "You can remember information from previous interactions. "
        "When storing information, confirm what you've remembered. "
        "When recalling, use your stored memory to answer."
    )

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        if self._memory is None:
            self._memory = SessionMemory()
        self._turn_count: int = 0

    def execute(self, input_text: str) -> dict:
        """Execute with memory context.

        Stores each interaction in memory and retrieves history
        for context.
        """
        self._turn_count += 1
        turn_key = f"turn_{self._turn_count}"

        if self._memory is not None:
            self._memory.store(turn_key, input_text)

        return {
            "response": f"Processed with memory (turn {self._turn_count}): {input_text}",
            "turn": self._turn_count,
            "memory_key": turn_key,
        }
