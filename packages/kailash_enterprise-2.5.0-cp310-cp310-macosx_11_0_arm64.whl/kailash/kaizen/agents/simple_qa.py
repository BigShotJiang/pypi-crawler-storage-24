"""Simple question-answering agent."""

from __future__ import annotations

from kailash.kaizen.agent import BaseAgent


class SimpleQAAgent(BaseAgent):
    """Direct question-answering agent.

    Provides straightforward answers without intermediate reasoning steps.
    Suitable for factual queries, lookups, and simple transformations.

    Example::

        agent = SimpleQAAgent()
        result = agent.execute("What is 2 + 2?")
    """

    name: str = "SimpleQAAgent"
    description: str = "Direct question-answering agent"
    system_prompt: str = (
        "You are a direct question-answering assistant. "
        "Answer questions concisely and accurately. "
        "If you don't know the answer, say so clearly."
    )
