"""ReAct (Reasoning + Acting) agent."""

from __future__ import annotations

from typing import Any

from kailash.kaizen.agent import BaseAgent


class ReActAgent(BaseAgent):
    """Reasoning + Acting pattern agent.

    Alternates between reasoning about the problem and taking actions
    (tool calls) to gather information, following the ReAct paradigm.

    Example::

        agent = ReActAgent()
        agent.register_tool("search", lambda args: {"results": []}, "Search the web")
        result = agent.execute("Find the current weather in Tokyo")
    """

    name: str = "ReActAgent"
    description: str = "Reasoning + Acting pattern agent"
    system_prompt: str = (
        "You are a ReAct agent that alternates between Thought, Action, "
        "and Observation steps. For each query:\n"
        "1. Thought: Reason about what you need to do\n"
        "2. Action: Choose and invoke a tool if needed\n"
        "3. Observation: Analyze the result\n"
        "Repeat until you have enough information to answer.\n"
        "If no tools are available, reason through the problem step by step."
    )
    max_iterations: int = 5

    def execute(self, input_text: str) -> dict:
        """Execute the ReAct loop.

        Without a live LLM connection, returns a structured response
        showing the ReAct format.
        """
        steps: list[dict[str, str]] = []
        tools = self._tool_registry.list_tools()

        steps.append({
            "type": "thought",
            "content": f"I need to process: {input_text}. "
                       f"Available tools: {tools if tools else 'none'}",
        })

        if tools:
            steps.append({
                "type": "action",
                "content": f"Would invoke tool from: {tools}",
            })
            steps.append({
                "type": "observation",
                "content": "Tool result would be processed here",
            })

        return {
            "response": f"ReAct processing for: {input_text}",
            "steps": steps,
            "iterations": len(steps),
        }
