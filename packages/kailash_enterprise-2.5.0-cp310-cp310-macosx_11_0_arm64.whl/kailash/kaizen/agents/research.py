"""Research agent with multi-step pipeline.

Executes a structured research workflow: query -> search -> analyze -> synthesize.

Example::

    agent = ResearchAgent(max_results=5, max_depth=3)
    agent.add_search_tool(lambda q: [{"text": "result"}])
    result = agent.execute("What are the latest advances in AI?")
    print(result["synthesis"])
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from kailash.kaizen.agent import BaseAgent


class ResearchAgent(BaseAgent):
    """Multi-step research agent with search, analysis, and synthesis.

    Executes a structured pipeline:
    1. Generate search queries from the input
    2. Execute searches using registered search tools
    3. Analyze results across multiple iterations
    4. Synthesize findings into a coherent response

    When no search tools are registered, falls back to direct reasoning.

    Args:
        model: LLM model name (None = use default from env).
        max_results: Maximum number of search results per query (default 5).
        max_depth: Maximum analysis iterations (default 3).
        **kwargs: Additional keyword arguments passed to ``BaseAgent``.

    Example::

        agent = ResearchAgent(max_results=5, max_depth=3)
        result = agent.execute("What is quantum computing?")
        print(result["sources"])
        print(result["findings"])
        print(result["synthesis"])
    """

    name: str = "ResearchAgent"
    description: str = "Multi-step research agent with search and synthesis"
    system_prompt: str = (
        "You are a research assistant. Analyze information thoroughly, "
        "cite sources when available, and provide well-structured findings."
    )

    def __init__(
        self,
        model: Optional[str] = None,
        max_results: int = 5,
        max_depth: int = 3,
        **kwargs: Any,
    ) -> None:
        super().__init__(model=model, **kwargs)
        self._max_results = max_results
        self._max_depth = max_depth
        self._search_tools: list[Callable[[str], list[dict[str, Any]]]] = []

    @property
    def max_results(self) -> int:
        """Maximum number of search results per query."""
        return self._max_results

    @property
    def max_depth(self) -> int:
        """Maximum analysis iterations (depth of research)."""
        return self._max_depth

    def add_search_tool(
        self, tool: Callable[[str], list[dict[str, Any]]]
    ) -> None:
        """Register a search tool for the research pipeline.

        The tool should accept a query string and return a list of dicts
        with at least a ``"text"`` key.

        Args:
            tool: A callable that takes a query and returns search results.
        """
        self._search_tools.append(tool)

    def execute(self, query: str) -> dict:
        """Execute the full research pipeline.

        Runs: query generation -> search -> analysis -> synthesis.

        Args:
            query: The research question.

        Returns:
            A dict with keys:
            - ``"response"``: The synthesized response text.
            - ``"sources"``: List of source references.
            - ``"findings"``: List of key findings.
            - ``"synthesis"``: The final synthesis string.
        """
        # Step 1: Execute searches
        sources: list[str] = []
        search_results: list[dict[str, Any]] = []

        for search_tool in self._search_tools:
            try:
                results = search_tool(query)
                for result in results[: self._max_results]:
                    text = result.get("text", str(result))
                    sources.append(text)
                    search_results.append(result)
            except Exception as exc:
                sources.append(f"Search error: {exc}")

        # Step 2: Analyze results (iterative)
        findings: list[str] = []
        context = (
            "; ".join(sources) if sources else "No external sources available"
        )

        for depth in range(self._max_depth):
            finding = (
                f"Finding {depth + 1}: Analysis of '{query}' "
                f"based on {len(sources)} sources"
            )
            if sources:
                finding += f" (includes: {sources[0][:50]}...)"
            findings.append(finding)

        # Step 3: Synthesize
        synthesis = (
            f"Research synthesis for '{query}': "
            f"{len(findings)} findings from {len(sources)} sources. "
        )
        if findings:
            synthesis += f"Key insight: {findings[0]}"

        response = synthesis

        return {
            "response": response,
            "sources": sources,
            "findings": findings,
            "synthesis": synthesis,
        }

    def __repr__(self) -> str:
        return (
            f"ResearchAgent(name={self.name!r}, model={self.model!r}, "
            f"max_results={self._max_results}, max_depth={self._max_depth})"
        )
