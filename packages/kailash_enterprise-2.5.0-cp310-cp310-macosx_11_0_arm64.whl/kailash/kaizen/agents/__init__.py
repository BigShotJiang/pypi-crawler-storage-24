"""Specialized agent subclasses.

Pre-built agent types for common AI patterns::

    from kailash.kaizen.agents import SimpleQAAgent, ReActAgent
    from kailash.kaizen.agents import ConversationalAgent, ResearchAgent, ToolCallingAgent

    agent = SimpleQAAgent(model="gpt-4o")
    result = agent.execute("What is the capital of France?")
"""

from kailash.kaizen.agents.chain_of_thought import ChainOfThoughtAgent
from kailash.kaizen.agents.code_gen import CodeGenAgent
from kailash.kaizen.agents.conversational import ConversationalAgent
from kailash.kaizen.agents.memory_agent import MemoryAgent
from kailash.kaizen.agents.planning import PlanningAgent
from kailash.kaizen.agents.rag import RAGAgent
from kailash.kaizen.agents.react import ReActAgent
from kailash.kaizen.agents.research import ResearchAgent
from kailash.kaizen.agents.simple_qa import SimpleQAAgent
from kailash.kaizen.agents.tool_calling import ToolCallingAgent

__all__ = [
    "SimpleQAAgent",
    "ChainOfThoughtAgent",
    "ReActAgent",
    "RAGAgent",
    "CodeGenAgent",
    "PlanningAgent",
    "MemoryAgent",
    "ConversationalAgent",
    "ResearchAgent",
    "ToolCallingAgent",
]
