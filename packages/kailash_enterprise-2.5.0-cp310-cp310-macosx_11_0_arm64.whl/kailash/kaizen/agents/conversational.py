"""Conversational agent with automatic history management.

Maintains conversation history across multiple ``execute()`` calls with
configurable FIFO truncation. The system prompt is always preserved.

Example::

    agent = ConversationalAgent(system_prompt="You are a chatbot.")
    r1 = agent.execute("Hello!")
    r2 = agent.execute("What did I just say?")
    print(agent.history)
"""

from __future__ import annotations

from typing import Any, Optional

from kailash.kaizen.agent import BaseAgent


class ConversationalAgent(BaseAgent):
    """Multi-turn conversational agent with automatic context management.

    Maintains a conversation history and automatically truncates it
    using FIFO when it exceeds ``max_history`` messages. System messages
    at the beginning of the history are preserved during truncation.

    Args:
        model: LLM model name (None = use default from env).
        system_prompt: System prompt for the agent.
        max_history: Maximum number of messages in history (default 50).
        **kwargs: Additional keyword arguments passed to ``BaseAgent``.

    Example::

        agent = ConversationalAgent(
            model="gpt-4o",
            system_prompt="You are a helpful chatbot.",
            max_history=50,
        )
        result = agent.execute("Hello!")
        result = agent.execute("What is your name?")
        print(agent.history)  # shows all messages
    """

    name: str = "ConversationalAgent"
    description: str = "Multi-turn conversational agent with history management"

    def __init__(
        self,
        model: Optional[str] = None,
        system_prompt: str = "",
        max_history: int = 50,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            model=model,
            system_prompt=system_prompt,
            **kwargs,
        )
        self._max_history = max_history
        self._history: list[dict[str, str]] = []

    @property
    def max_history(self) -> int:
        """Maximum number of messages in the history."""
        return self._max_history

    @property
    def history(self) -> list[dict[str, str]]:
        """The current conversation history.

        Returns a list of dicts with ``"role"`` and ``"content"`` keys.
        """
        return list(self._history)

    def add_message(self, role: str, content: str) -> None:
        """Add a message to the conversation history.

        Useful for injecting context (e.g., tool results, metadata)
        before the next ``execute()`` call.

        Args:
            role: Message role (``"user"``, ``"assistant"``, ``"system"``).
            content: Message text content.
        """
        self._history.append({"role": role, "content": content})
        self._truncate()

    def clear_history(self) -> None:
        """Clear the conversation history."""
        self._history.clear()

    def execute(self, input_text: str) -> dict:
        """Execute a conversational turn.

        Adds the user message to history, generates a response,
        and adds the assistant response to history.

        Args:
            input_text: The user's message.

        Returns:
            A dict with at least a ``"response"`` key.
        """
        self.add_message("user", input_text)

        # Build response using conversation context
        context_summary = "; ".join(
            f"{m['role']}: {m['content'][:50]}" for m in self._history[-5:]
        )
        response_text = (
            f"Conversational response for: {input_text} "
            f"(context: {len(self._history)} messages)"
        )

        self.add_message("assistant", response_text)

        return {
            "response": response_text,
            "history_length": len(self._history),
        }

    def _truncate(self) -> None:
        """Truncate history to max_history, preserving leading system messages."""
        if len(self._history) <= self._max_history:
            return

        # Count leading system messages
        system_count = 0
        for msg in self._history:
            if msg["role"] == "system":
                system_count += 1
            else:
                break

        non_system = self._history[system_count:]
        if len(non_system) <= self._max_history:
            return

        # Keep system messages + last max_history non-system messages
        keep_from = len(non_system) - self._max_history
        preserved_system = self._history[:system_count]
        kept_recent = non_system[keep_from:]

        self._history = preserved_system + kept_recent

    def __repr__(self) -> str:
        return (
            f"ConversationalAgent(name={self.name!r}, model={self.model!r}, "
            f"max_history={self._max_history}, history_len={len(self._history)})"
        )
