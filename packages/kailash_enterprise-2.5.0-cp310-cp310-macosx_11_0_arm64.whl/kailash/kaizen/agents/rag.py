"""Retrieval-Augmented Generation (RAG) agent."""

from __future__ import annotations

from typing import Any, Callable, Optional

from kailash.kaizen.agent import BaseAgent


class RAGAgent(BaseAgent):
    """Retrieval-Augmented Generation agent.

    Retrieves relevant context from a knowledge base before generating
    a response. Requires a retriever function to be set.

    Example::

        def my_retriever(query):
            return [{"text": "Paris is the capital of France", "score": 0.95}]

        agent = RAGAgent(retriever=my_retriever)
        result = agent.execute("What is the capital of France?")
    """

    name: str = "RAGAgent"
    description: str = "Retrieval-Augmented Generation agent"
    system_prompt: str = (
        "You are a RAG assistant. Use the provided context to answer "
        "questions accurately. If the context doesn't contain relevant "
        "information, say so. Always cite your sources when possible."
    )

    def __init__(
        self,
        retriever: Optional[Callable[[str], list[dict[str, Any]]]] = None,
        top_k: int = 5,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._retriever = retriever
        self._top_k = top_k

    def set_retriever(self, retriever: Callable[[str], list[dict[str, Any]]]) -> None:
        """Set the retrieval function.

        Args:
            retriever: A callable that takes a query string and returns
                      a list of dicts with at least a ``"text"`` key.
        """
        self._retriever = retriever

    def retrieve(self, query: str) -> list[dict[str, Any]]:
        """Retrieve relevant documents for a query.

        Args:
            query: The search query.

        Returns:
            A list of document dicts.

        Raises:
            RuntimeError: If no retriever has been set.
        """
        if self._retriever is None:
            raise RuntimeError("No retriever function set. Call set_retriever() first.")
        results = self._retriever(query)
        return results[: self._top_k]

    def execute(self, input_text: str) -> dict:
        """Execute RAG: retrieve context, then generate a response.

        Returns a dict with ``response``, ``context``, and ``sources``.
        """
        if self._retriever is None:
            return {
                "response": f"No retriever configured for query: {input_text}",
                "context": [],
                "sources": [],
            }

        context = self.retrieve(input_text)
        context_texts = [doc.get("text", "") for doc in context]

        return {
            "response": f"RAG response for: {input_text}",
            "context": context,
            "sources": context_texts,
        }
