"""Lifecycle hook management for agents.

Provides event-driven callbacks for agent lifecycle events::

    hooks = HookManager()

    @hooks.on("on_start")
    def log_start(agent_name):
        print(f"Agent {agent_name} starting")

    hooks.trigger("on_start", "my-agent")
"""

from __future__ import annotations

from typing import Any, Callable


class HookManager:
    """Lifecycle hook management for agents.

    Supports registration of callbacks for predefined lifecycle events.
    Multiple callbacks can be registered per event and are fired in
    registration order.

    Supported events:
        - ``on_start``: Agent begins execution.
        - ``on_think``: Agent enters the Think phase.
        - ``on_act``: Agent enters the Act phase.
        - ``on_observe``: Agent enters the Observe phase.
        - ``on_decide``: Agent enters the Decide phase.
        - ``on_error``: An error occurred during execution.
        - ``on_complete``: Agent finished execution.
        - ``on_interrupt``: Agent was interrupted.
        - ``on_checkpoint``: A checkpoint was created.
    """

    EVENTS = (
        "on_start",
        "on_think",
        "on_act",
        "on_observe",
        "on_decide",
        "on_error",
        "on_complete",
        "on_interrupt",
        "on_checkpoint",
    )

    def __init__(self) -> None:
        self._callbacks: dict[str, list[Callable[..., Any]]] = {
            event: [] for event in self.EVENTS
        }

    def on(self, event_name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Decorator to register a callback for a lifecycle event.

        Args:
            event_name: One of the supported event names.

        Returns:
            The original function, unmodified.

        Raises:
            ValueError: If the event name is not supported.

        Example::

            @hooks.on("on_start")
            def my_handler(agent_name):
                print(f"Started: {agent_name}")
        """
        if event_name not in self._callbacks:
            raise ValueError(
                f"Unknown event {event_name!r}. "
                f"Supported events: {', '.join(self.EVENTS)}"
            )

        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            self._callbacks[event_name].append(func)
            return func

        return decorator

    def register(self, event_name: str, callback: Callable[..., Any]) -> None:
        """Register a callback for a lifecycle event (non-decorator form).

        Args:
            event_name: One of the supported event names.
            callback: The callback function.

        Raises:
            ValueError: If the event name is not supported.
        """
        if event_name not in self._callbacks:
            raise ValueError(
                f"Unknown event {event_name!r}. "
                f"Supported events: {', '.join(self.EVENTS)}"
            )
        self._callbacks[event_name].append(callback)

    def trigger(self, event_name: str, *args: Any, **kwargs: Any) -> list[Any]:
        """Fire all registered callbacks for an event.

        Args:
            event_name: The event to trigger.
            *args: Positional arguments passed to each callback.
            **kwargs: Keyword arguments passed to each callback.

        Returns:
            A list of return values from all callbacks.

        Raises:
            ValueError: If the event name is not supported.
        """
        if event_name not in self._callbacks:
            raise ValueError(
                f"Unknown event {event_name!r}. "
                f"Supported events: {', '.join(self.EVENTS)}"
            )
        results = []
        for callback in self._callbacks[event_name]:
            results.append(callback(*args, **kwargs))
        return results

    def clear(self, event_name: str | None = None) -> None:
        """Remove all callbacks, or callbacks for a specific event.

        Args:
            event_name: If given, only clear callbacks for that event.
                       If None, clear all callbacks for all events.
        """
        if event_name is not None:
            if event_name not in self._callbacks:
                raise ValueError(f"Unknown event {event_name!r}")
            self._callbacks[event_name].clear()
        else:
            for event in self._callbacks:
                self._callbacks[event].clear()

    def callback_count(self, event_name: str | None = None) -> int:
        """Count registered callbacks.

        Args:
            event_name: If given, count for that event only.
                       If None, count across all events.
        """
        if event_name is not None:
            if event_name not in self._callbacks:
                raise ValueError(f"Unknown event {event_name!r}")
            return len(self._callbacks[event_name])
        return sum(len(cbs) for cbs in self._callbacks.values())

    def __repr__(self) -> str:
        total = self.callback_count()
        return f"HookManager(callbacks={total})"
