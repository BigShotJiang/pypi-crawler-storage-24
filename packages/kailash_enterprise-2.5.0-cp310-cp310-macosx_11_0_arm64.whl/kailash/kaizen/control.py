"""Control and interrupt management for agent loops.

Provides thread-safe interrupt signaling and human-in-the-loop control::

    interrupt = InterruptManager()
    interrupt.set_timeout_secs(30)
    if interrupt.is_interrupted():
        print("Agent was interrupted")
"""

from __future__ import annotations

import sys
import threading
import time
from typing import Optional


class InterruptManager:
    """Thread-safe interrupt signal for agent loops.

    Supports manual interrupts, timeout-based interrupts, and
    budget-based interrupts.
    """

    def __init__(self) -> None:
        self._interrupted = threading.Event()
        self._timeout_secs: Optional[float] = None
        self._budget_limit: Optional[float] = None
        self._start_time: float = time.monotonic()
        self._cost_accumulated: float = 0.0
        self._lock = threading.Lock()

    def request_interrupt(self) -> None:
        """Signal an interrupt request."""
        self._interrupted.set()

    def is_interrupted(self) -> bool:
        """Check whether an interrupt has been requested.

        Also checks timeout and budget limits if configured.
        """
        if self._interrupted.is_set():
            return True

        with self._lock:
            if self._timeout_secs is not None:
                elapsed = time.monotonic() - self._start_time
                if elapsed >= self._timeout_secs:
                    self._interrupted.set()
                    return True

            if self._budget_limit is not None:
                if self._cost_accumulated >= self._budget_limit:
                    self._interrupted.set()
                    return True

        return False

    def clear(self) -> None:
        """Clear the interrupt flag and reset the start time."""
        self._interrupted.clear()
        with self._lock:
            self._start_time = time.monotonic()

    def set_timeout_secs(self, secs: float) -> None:
        """Set a timeout in seconds after which the agent will be interrupted.

        Args:
            secs: Timeout duration in seconds.
        """
        with self._lock:
            self._timeout_secs = secs
            self._start_time = time.monotonic()

    def set_budget_limit(self, usd: float) -> None:
        """Set a budget limit in USD after which the agent will be interrupted.

        Args:
            usd: Budget limit in USD.
        """
        with self._lock:
            self._budget_limit = usd

    def record_cost(self, usd: float) -> None:
        """Record accumulated cost (called by agent during execution).

        Args:
            usd: Cost in USD to add.
        """
        with self._lock:
            self._cost_accumulated += usd

    @property
    def elapsed_secs(self) -> float:
        """Seconds elapsed since creation or last clear."""
        return time.monotonic() - self._start_time

    def __repr__(self) -> str:
        return (
            f"InterruptManager(interrupted={self._interrupted.is_set()}, "
            f"timeout={self._timeout_secs})"
        )


class ControlProtocol:
    """Human-in-the-loop control for agents.

    Provides mechanisms for agents to request human input during execution.
    """

    def __init__(
        self,
        input_func: Optional[object] = None,
        output_func: Optional[object] = None,
    ) -> None:
        """Initialize the control protocol.

        Args:
            input_func: Custom input function (default: builtin input()).
            output_func: Custom output function (default: print()).
        """
        self._input_func = input_func or input
        self._output_func = output_func or print
        self._history: list[dict[str, str]] = []

    def ask_user(self, prompt: str) -> str:
        """Ask the user a question and return their response.

        Args:
            prompt: The question to ask.

        Returns:
            The user's response string.
        """
        self._output_func(prompt)
        response = self._input_func()
        self._history.append({"prompt": prompt, "response": response})
        return response

    def request_approval(self, description: str) -> bool:
        """Request user approval for an action.

        Args:
            description: Description of the action requiring approval.

        Returns:
            True if approved, False otherwise.
        """
        self._output_func(f"Approval required: {description}")
        response = self._input_func()
        approved = response.strip().lower() in ("y", "yes", "approve", "ok")
        self._history.append({
            "prompt": f"Approval: {description}",
            "response": response,
            "approved": str(approved),
        })
        return approved

    @property
    def history(self) -> list[dict[str, str]]:
        """History of all user interactions."""
        return list(self._history)

    def __repr__(self) -> str:
        return f"ControlProtocol(interactions={len(self._history)})"
