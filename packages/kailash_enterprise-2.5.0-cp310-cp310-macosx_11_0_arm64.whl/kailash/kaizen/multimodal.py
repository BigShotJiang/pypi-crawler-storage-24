"""Kailash Kaizen Multimodal Processing.

Re-exports Rust-backed multimodal types for image analysis, audio
transcription, and multi-modality orchestration::

    from kailash.kaizen.multimodal import (
        ImageInput,
        AudioInput,
        MultimodalInput,
        VisionProcessor,
        AudioProcessor,
        MultimodalOrchestrator,
    )

All classes are backed by the ``kailash-kaizen`` multimodal crate via PyO3.
"""

from kailash._kailash import (
    ImageInput,
    AudioInput,
    MultimodalInput,
    VisionProcessor,
    AudioProcessor,
    MultimodalOrchestrator,
)

__all__ = [
    "ImageInput",
    "AudioInput",
    "MultimodalInput",
    "VisionProcessor",
    "AudioProcessor",
    "MultimodalOrchestrator",
]
