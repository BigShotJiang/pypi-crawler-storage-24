"""Pythonic StructuredOutput API wrapping Rust-backed types.

Provides a convenience class for parsing structured LLM responses
with JSON schema validation and automatic retry::

    from kailash.kaizen import StructuredOutput

    so = StructuredOutput(schema={"type": "object", "required": ["name"]})
    result = so.parse('{"name": "Alice"}')
    assert result == {"name": "Alice"}
"""

from __future__ import annotations

from typing import Any, Optional

from kailash._kailash import (
    OutputSchema as _OutputSchema,
    RetryConfig as _RetryConfig,
    StructuredOutput as _StructuredOutput,
)


# Re-export Rust types directly for users who want them
OutputSchema = _OutputSchema
RetryConfig = _RetryConfig
StructuredOutput = _StructuredOutput

__all__ = [
    "OutputSchema",
    "RetryConfig",
    "StructuredOutput",
]
