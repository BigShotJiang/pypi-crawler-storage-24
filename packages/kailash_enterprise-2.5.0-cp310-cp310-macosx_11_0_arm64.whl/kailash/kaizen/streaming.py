"""Kailash Kaizen streaming -- token-by-token LLM response streaming.

Provides stream handlers and a streaming agent wrapper for receiving
LLM responses token-by-token as they arrive.

Re-exports Rust-backed streaming types::

    from kailash.kaizen.streaming import StreamHandler, StreamingAgent
    from kailash.kaizen.streaming import TokenCollector, ChannelStreamHandler
    from kailash.kaizen.streaming import StreamEvent

All classes are backed by the ``kailash-kaizen`` crate via PyO3.
"""

from kailash._kailash import (
    StreamHandler,
    StreamingAgent,
    StreamEvent,
    TokenCollector,
    ChannelStreamHandler,
)

__all__ = [
    "StreamHandler",
    "StreamingAgent",
    "StreamEvent",
    "TokenCollector",
    "ChannelStreamHandler",
]
