"""Structured input/output contracts for agents.

Provides a signature system for declaring typed agent interfaces::

    class QuestionAnswer(Signature):
        question: InputField = InputField(description="The question to answer")
        answer: OutputField = OutputField(description="The answer")

    schema = QuestionAnswer.json_schema()
"""

from __future__ import annotations

from typing import Any, Optional


class InputField:
    """Declares an input parameter for a Signature.

    Args:
        description: Human-readable description of the field.
        default: Default value (None means required).
    """

    def __init__(self, description: str = "", default: Any = None) -> None:
        self.description = description
        self.default = default

    def __repr__(self) -> str:
        return f"InputField(description={self.description!r}, default={self.default!r})"


class OutputField:
    """Declares an output parameter for a Signature.

    Args:
        description: Human-readable description of the field.
    """

    def __init__(self, description: str = "") -> None:
        self.description = description

    def __repr__(self) -> str:
        return f"OutputField(description={self.description!r})"


class Signature:
    """Base class for structured input/output contracts.

    Subclass and annotate with :class:`InputField` and :class:`OutputField`
    class attributes to declare the agent's interface.

    Example::

        class Summarize(Signature):
            text: InputField = InputField(description="Text to summarize")
            max_length: InputField = InputField(description="Max words", default=100)
            summary: OutputField = OutputField(description="The summary")

        inputs = Summarize.input_fields()
        # {"text": InputField(...), "max_length": InputField(...)}
    """

    @classmethod
    def input_fields(cls) -> dict[str, InputField]:
        """Returns a dict of {name: InputField} for all declared input fields."""
        result: dict[str, InputField] = {}
        for name in dir(cls):
            if name.startswith("_"):
                continue
            val = getattr(cls, name, None)
            if isinstance(val, InputField):
                result[name] = val
        return result

    @classmethod
    def output_fields(cls) -> dict[str, OutputField]:
        """Returns a dict of {name: OutputField} for all declared output fields."""
        result: dict[str, OutputField] = {}
        for name in dir(cls):
            if name.startswith("_"):
                continue
            val = getattr(cls, name, None)
            if isinstance(val, OutputField):
                result[name] = val
        return result

    @classmethod
    def json_schema(cls) -> dict[str, Any]:
        """Generate a JSON Schema for the signature's input fields.

        Returns:
            A JSON Schema dict with ``type``, ``properties``, and ``required``.
        """
        properties: dict[str, Any] = {}
        required: list[str] = []

        for name, field in cls.input_fields().items():
            prop: dict[str, Any] = {"type": "string"}
            if field.description:
                prop["description"] = field.description
            if field.default is not None:
                prop["default"] = field.default
            else:
                required.append(name)
            properties[name] = prop

        schema: dict[str, Any] = {
            "type": "object",
            "properties": properties,
        }
        if required:
            schema["required"] = sorted(required)
        return schema

    @classmethod
    def validate_inputs(cls, inputs: dict[str, Any]) -> dict[str, Any]:
        """Validate and fill defaults for input values.

        Args:
            inputs: The input dict to validate.

        Returns:
            A new dict with defaults filled in.

        Raises:
            ValueError: If a required field is missing.
        """
        result: dict[str, Any] = {}
        for name, field in cls.input_fields().items():
            if name in inputs:
                result[name] = inputs[name]
            elif field.default is not None:
                result[name] = field.default
            else:
                raise ValueError(f"Missing required input field: {name!r}")
        return result

    def __repr__(self) -> str:
        return f"{type(self).__name__}(inputs={list(self.input_fields())}, outputs={list(self.output_fields())})"
