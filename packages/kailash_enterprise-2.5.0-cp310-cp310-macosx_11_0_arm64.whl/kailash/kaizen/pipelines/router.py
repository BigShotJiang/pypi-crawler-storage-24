"""Router pipeline: route input to a specific agent based on a routing function.

The routing function inspects the input and selects the appropriate agent::

    def route(input_text):
        if "code" in input_text.lower():
            return "CodeGenAgent"
        return "SimpleQAAgent"

    pipeline = RouterPipeline({"CodeGenAgent": coder, "SimpleQAAgent": qa}, route)
    result = pipeline.run("Write a function")
"""

from __future__ import annotations

from typing import Any, Callable, Dict

from kailash.kaizen.agent import BaseAgent


class RouterPipeline:
    """Route input to a selected agent based on a routing function.

    The routing function receives the input text and returns the name of
    the agent to use. If the name is not found, falls back to the first
    agent in the dict.

    Args:
        agents: A dict mapping agent names to agent instances.
        router_fn: A callable ``(input_text) -> agent_name``.
        name: Optional pipeline name.
    """

    def __init__(
        self,
        agents: Dict[str, BaseAgent],
        router_fn: Callable[[str], str],
        name: str = "RouterPipeline",
    ) -> None:
        if not agents:
            raise ValueError("RouterPipeline requires at least one agent")
        self._agents = dict(agents)
        self._router_fn = router_fn
        self._name = name

    def run(self, input_text: str) -> dict[str, Any]:
        """Route input to the selected agent and execute.

        Args:
            input_text: The input to process.

        Returns:
            A dict with ``response``, ``selected_agent``, and ``result``.
        """
        selected_name = self._router_fn(input_text)
        agent = self._agents.get(selected_name)

        if agent is None:
            fallback_name = next(iter(self._agents))
            agent = self._agents[fallback_name]
            selected_name = fallback_name

        result = agent.execute(input_text)

        return {
            "response": result.get("response", str(result)),
            "selected_agent": selected_name,
            "result": result,
        }

    @property
    def agents(self) -> Dict[str, BaseAgent]:
        """The agent registry for this router."""
        return dict(self._agents)

    def __repr__(self) -> str:
        return f"RouterPipeline(name={self._name!r}, agents={list(self._agents.keys())})"
