"""Chain pipeline: sequential steps with optional transform functions.

Each step runs an agent, optionally transforms its output, then passes
the result to the next step::

    from kailash.kaizen.pipelines import ChainPipeline
    from kailash.kaizen.pipelines.chain import ChainStep

    pipeline = ChainPipeline([
        ChainStep(summarizer, transform=lambda s: s.upper()),
        critic,  # bare agent, no transform
    ])
    result = pipeline.run("Analyze this...")
"""

from __future__ import annotations

from typing import Any, Callable, Optional, Union

from kailash.kaizen.agent import BaseAgent


class ChainStep:
    """A single step in a chain pipeline.

    Wraps an agent with an optional transform function and an explicit name.

    Args:
        agent: The agent to execute in this step.
        transform: Optional callable ``(str) -> str`` that transforms the
            agent's response before passing it to the next step.
        name: Optional step name for tracing. Defaults to the agent's name.

    Example::

        step = ChainStep(
            my_agent,
            transform=lambda s: s.upper(),
            name="uppercase-step",
        )
    """

    def __init__(
        self,
        agent: BaseAgent,
        transform: Optional[Callable[[str], str]] = None,
        name: Optional[str] = None,
    ) -> None:
        self.agent = agent
        self.transform = transform
        self.name = name if name is not None else agent.name

    def __repr__(self) -> str:
        has_transform = self.transform is not None
        return f"ChainStep(name={self.name!r}, has_transform={has_transform})"


class ChainPipeline:
    """Run agents sequentially with optional data transforms between steps.

    Each step receives the (optionally transformed) output of the previous
    step. All intermediate results are collected for inspection.

    Steps can be:
    - A bare :class:`BaseAgent` (no transform, agent name used as step name)
    - A :class:`ChainStep` (with optional transform and explicit name)

    Args:
        steps: Ordered list of steps. Each element is either a
            :class:`BaseAgent` or a :class:`ChainStep`.

    Raises:
        ValueError: If ``steps`` is empty.

    Example::

        pipeline = ChainPipeline([
            ChainStep(agent_a, transform=lambda s: s.upper()),
            agent_b,  # bare agent, pass-through
        ])
        result = pipeline.run("initial input")
        print(result["response"])       # final output
        print(result["step_results"])   # all intermediate results
    """

    def __init__(
        self,
        steps: list[Union[BaseAgent, ChainStep]],
    ) -> None:
        if not steps:
            raise ValueError("ChainPipeline requires at least one step")
        self._steps: list[ChainStep] = []
        for step in steps:
            if isinstance(step, ChainStep):
                self._steps.append(step)
            elif isinstance(step, BaseAgent):
                self._steps.append(ChainStep(step))
            else:
                raise TypeError(
                    f"Expected BaseAgent or ChainStep, got {type(step).__name__}"
                )

    @property
    def agents(self) -> list[BaseAgent]:
        """The agents from all steps in order."""
        return [step.agent for step in self._steps]

    def run(self, input_text: str) -> dict[str, Any]:
        """Execute the chain pipeline.

        Each step receives the (optionally transformed) output of the
        previous step. The first step receives ``input_text``.

        Args:
            input_text: The initial input text.

        Returns:
            A dict with:
            - ``response``: the final step's response text
            - ``step_results``: list of dicts with ``step``, ``input``,
              ``output`` for each step
            - ``step_count``: total number of steps

        Raises:
            RuntimeError: (or any exception) if an agent or transform
                function fails. The chain stops on the first error.
        """
        current_input = input_text
        step_results: list[dict[str, Any]] = []

        for step in self._steps:
            result = step.agent.execute(current_input)
            step_results.append({
                "step": step.name,
                "input": current_input,
                "output": result,
            })

            # Get the response text for the next step
            next_input = result.get("response", str(result))

            # Apply transform if present
            if step.transform is not None:
                next_input = step.transform(next_input)

            current_input = next_input

        final_response = step_results[-1]["output"].get(
            "response", str(step_results[-1]["output"])
        )

        return {
            "response": final_response,
            "step_results": step_results,
            "step_count": len(self._steps),
        }

    def __repr__(self) -> str:
        names = [s.name for s in self._steps]
        return f"ChainPipeline(steps={names})"
