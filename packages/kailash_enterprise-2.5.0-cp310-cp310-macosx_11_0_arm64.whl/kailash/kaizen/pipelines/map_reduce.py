"""Map-reduce pipeline: distribute input across agents, aggregate results.

Splits input (optionally via a split function), runs each agent on its
portion, then reduces the collected results via a reducer function::

    from kailash.kaizen.pipelines import MapReducePipeline

    pipeline = MapReducePipeline(
        agents=[agent_a, agent_b, agent_c],
        reducer=concat_reducer,
        split_fn=lambda text: text.split(". "),
    )
    result = pipeline.run("Sentence one. Sentence two. Sentence three.")

CRITICAL GIL SAFETY NOTE:
    When using real Rust-backed Agent objects, this pipeline runs them
    sequentially to avoid GIL deadlock. ThreadPoolExecutor is only safe
    for pure-Python BaseAgent subclasses with overridden execute().
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Optional

from kailash.kaizen.agent import BaseAgent
from kailash.kaizen.pipelines.parallel import _is_pure_python_agent


def concat_reducer(results: list[dict[str, Any]]) -> dict[str, Any]:
    """Concatenate all agent responses, separated by newlines.

    Skips entries with ``error=True``. If all results are errors,
    returns a combined error message.

    Args:
        results: List of per-agent result dicts from the map phase.

    Returns:
        A dict with ``response`` containing all responses joined by newlines.
    """
    responses = []
    for r in results:
        if not r.get("error"):
            responses.append(r.get("response", str(r)))
    if not responses:
        return {"response": "All agents failed", "error": True}
    return {"response": "\n".join(responses)}


def best_of_reducer(results: list[dict[str, Any]]) -> dict[str, Any]:
    """Pick the result with the longest response (proxy for best quality).

    Skips entries with ``error=True``.

    Args:
        results: List of per-agent result dicts from the map phase.

    Returns:
        The dict with the longest ``response`` value.
    """
    best: dict[str, Any] | None = None
    best_len = -1
    for r in results:
        if r.get("error"):
            continue
        resp = r.get("response", "")
        if len(resp) > best_len:
            best = r
            best_len = len(resp)
    if best is None:
        return {"response": "All agents failed", "error": True}
    return best


class MapReducePipeline:
    """Distribute input across agents (map) and aggregate results (reduce).

    Each agent in the map phase processes the input (or a portion of it
    when ``split_fn`` is provided). Results are collected and passed to
    the ``reducer`` function to produce the final output.

    Args:
        agents: List of agents for the map phase.
        reducer: A callable ``(list[dict]) -> dict`` that aggregates
            map results. Defaults to :func:`concat_reducer`.
        split_fn: Optional callable ``(str) -> list[str]`` that splits
            the input for each mapper. If ``None``, all agents receive
            the same input.
        parallel: Whether to run the map phase in parallel (default
            ``True``). Uses ``ThreadPoolExecutor`` for pure-Python agents,
            sequential execution for Rust-backed agents.

    Raises:
        ValueError: If ``agents`` is empty.

    Example::

        pipeline = MapReducePipeline(
            agents=[summarizer, analyst, critic],
            reducer=concat_reducer,
        )
        result = pipeline.run("Analyze this document...")
    """

    def __init__(
        self,
        agents: list[BaseAgent],
        reducer: Optional[Callable[[list[dict[str, Any]]], dict[str, Any]]] = None,
        split_fn: Optional[Callable[[str], list[str]]] = None,
        parallel: bool = True,
    ) -> None:
        if not agents:
            raise ValueError("MapReducePipeline requires at least one agent")
        self._agents = list(agents)
        self._reducer = reducer or concat_reducer
        self._split_fn = split_fn
        self._parallel = parallel

    @property
    def agents(self) -> list[BaseAgent]:
        """The list of agents in the map phase."""
        return list(self._agents)

    def run(self, input_text: str) -> dict[str, Any]:
        """Execute the map-reduce pipeline.

        Args:
            input_text: The input text to process.

        Returns:
            A dict with ``response`` (final aggregated output),
            ``map_results`` (list of per-agent results), and
            ``agent_count``.
        """
        inputs = self._prepare_inputs(input_text)
        map_results = self._run_map(inputs)
        reduced = self._reducer(map_results)

        return {
            "response": reduced.get("response", str(reduced)),
            "map_results": map_results,
            "agent_count": len(self._agents),
        }

    def _prepare_inputs(self, input_text: str) -> list[str]:
        """Prepare per-agent inputs using split_fn if configured."""
        if self._split_fn is not None:
            parts = list(self._split_fn(input_text))
            # Pad with empty strings if fewer parts than agents
            while len(parts) < len(self._agents):
                parts.append("")
            # Truncate if more parts than agents
            return parts[: len(self._agents)]
        return [input_text] * len(self._agents)

    def _run_map(self, inputs: list[str]) -> list[dict[str, Any]]:
        """Run the map phase: each agent processes its input."""
        all_pure_python = all(_is_pure_python_agent(a) for a in self._agents)

        if self._parallel and all_pure_python and len(self._agents) > 1:
            return self._run_parallel(inputs)
        return self._run_sequential(inputs)

    def _run_sequential(self, inputs: list[str]) -> list[dict[str, Any]]:
        """Run agents sequentially (safe for Rust-backed agents)."""
        results: list[dict[str, Any]] = []
        for agent, agent_input in zip(self._agents, inputs):
            try:
                result = agent.execute(agent_input)
                results.append(result)
            except Exception as exc:
                results.append({
                    "response": f"Error from {agent.name}: {exc}",
                    "error": True,
                })
        return results

    def _run_parallel(self, inputs: list[str]) -> list[dict[str, Any]]:
        """Run pure-Python agents in parallel using ThreadPoolExecutor."""
        results: list[dict[str, Any]] = [{}] * len(self._agents)

        def run_agent(
            idx_agent_input: tuple[int, BaseAgent, str],
        ) -> tuple[int, dict[str, Any]]:
            idx, agent, agent_input = idx_agent_input
            try:
                result = agent.execute(agent_input)
                return idx, result
            except Exception as exc:
                return idx, {
                    "response": f"Error from {agent.name}: {exc}",
                    "error": True,
                }

        workers = min(len(self._agents), 4)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for idx, entry in pool.map(
                run_agent,
                [(i, a, inp) for i, (a, inp) in enumerate(zip(self._agents, inputs))],
            ):
                results[idx] = entry

        return results

    def __repr__(self) -> str:
        names = [a.name for a in self._agents]
        return f"MapReducePipeline(agents={names}, parallel={self._parallel})"
