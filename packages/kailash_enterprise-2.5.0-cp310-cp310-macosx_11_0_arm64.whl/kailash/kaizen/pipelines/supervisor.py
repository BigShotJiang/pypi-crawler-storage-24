"""Supervisor pipeline: a supervisor agent delegates work to worker agents.

The supervisor decides which worker to invoke based on the task::

    supervisor = SupervisorPipeline(
        supervisor=planner,
        workers={"coder": code_agent, "researcher": rag_agent},
    )
    result = supervisor.run("Build a login page")
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from kailash.kaizen.agent import BaseAgent


class SupervisorPipeline:
    """Supervisor-worker pattern for multi-agent orchestration.

    A supervisor agent receives the input and decides which worker(s)
    to delegate to. A routing function maps the supervisor's output
    to a worker name.

    Args:
        supervisor: The supervisory agent that plans the work.
        workers: Dict mapping worker names to agent instances.
        router_fn: Optional function ``(supervisor_result, workers) -> worker_name``.
            Defaults to running all workers sequentially.
        max_rounds: Maximum delegation rounds before stopping.
        name: Optional pipeline name.
    """

    def __init__(
        self,
        supervisor: BaseAgent,
        workers: Dict[str, BaseAgent],
        router_fn: Optional[Callable[[dict[str, Any], Dict[str, BaseAgent]], str]] = None,
        max_rounds: int = 3,
        name: str = "SupervisorPipeline",
    ) -> None:
        if not workers:
            raise ValueError("SupervisorPipeline requires at least one worker")
        self._supervisor = supervisor
        self._workers = dict(workers)
        self._router_fn = router_fn
        self._max_rounds = max_rounds
        self._name = name

    def run(self, input_text: str) -> dict[str, Any]:
        """Execute the supervisor-worker loop.

        The supervisor processes the input, then workers are dispatched
        based on the routing function.

        Args:
            input_text: The task to process.

        Returns:
            A dict with ``response``, ``supervisor_result``, ``worker_results``,
            and ``rounds``.
        """
        supervisor_result = self._supervisor.execute(input_text)
        worker_results: list[dict[str, Any]] = []

        if self._router_fn is not None:
            for _ in range(self._max_rounds):
                worker_name = self._router_fn(supervisor_result, self._workers)
                if worker_name not in self._workers:
                    break
                worker = self._workers[worker_name]
                worker_input = supervisor_result.get("response", input_text)
                result = worker.execute(worker_input)
                worker_results.append({
                    "worker": worker_name,
                    "result": result,
                })
        else:
            for worker_name, worker in self._workers.items():
                result = worker.execute(
                    supervisor_result.get("response", input_text)
                )
                worker_results.append({
                    "worker": worker_name,
                    "result": result,
                })

        final_response = (
            worker_results[-1]["result"].get("response", "")
            if worker_results
            else supervisor_result.get("response", "")
        )

        return {
            "response": final_response,
            "supervisor_result": supervisor_result,
            "worker_results": worker_results,
            "rounds": len(worker_results),
        }

    @property
    def supervisor(self) -> BaseAgent:
        """The supervisor agent."""
        return self._supervisor

    @property
    def workers(self) -> Dict[str, BaseAgent]:
        """The worker agents."""
        return dict(self._workers)

    def __repr__(self) -> str:
        return (
            f"SupervisorPipeline(name={self._name!r}, "
            f"workers={list(self._workers.keys())})"
        )
