"""Parallel pipeline: run agents concurrently.

CRITICAL GIL SAFETY NOTE:
    When using real Rust-backed Agent objects, this pipeline runs them
    sequentially to avoid GIL deadlock. ThreadPoolExecutor is only safe
    for pure-Python BaseAgent subclasses with overridden execute().
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from typing import Any

from kailash.kaizen.agent import BaseAgent


def _is_pure_python_agent(agent: BaseAgent) -> bool:
    """Check if an agent is a pure-Python BaseAgent subclass.

    Returns True if the agent's execute method is overridden in Python
    (not the base NotImplementedError). This is used to determine if
    ThreadPoolExecutor is safe to use.
    """
    return type(agent).execute is not BaseAgent.execute


class ParallelPipeline:
    """Run agents in parallel on the same input.

    Each agent receives the same input independently. Results are
    collected from all agents.

    CRITICAL: Uses sequential execution for Rust-backed agents to avoid
    GIL deadlock. Only uses ThreadPoolExecutor for pure-Python agents.

    Example::

        pipeline = ParallelPipeline([agent1, agent2])
        result = pipeline.run("analyze this")
    """

    def __init__(self, agents: list[BaseAgent], max_workers: int | None = None) -> None:
        if not agents:
            raise ValueError("ParallelPipeline requires at least one agent")
        self._agents = list(agents)
        self._max_workers = max_workers

    @property
    def agents(self) -> list[BaseAgent]:
        """The list of agents in this pipeline."""
        return list(self._agents)

    def run(self, input_text: str) -> dict[str, Any]:
        """Execute all agents on the same input.

        Uses ThreadPoolExecutor for pure-Python agents, sequential
        execution for Rust-backed agents.

        Args:
            input_text: The input text for all agents.

        Returns:
            A dict with ``results`` (list of per-agent outputs),
            ``response`` (combined summary), and ``agent_count``.
        """
        all_pure_python = all(_is_pure_python_agent(a) for a in self._agents)

        if all_pure_python and len(self._agents) > 1:
            results = self._run_parallel(input_text)
        else:
            results = self._run_sequential(input_text)

        return {
            "response": f"Parallel results from {len(self._agents)} agents",
            "results": results,
            "agent_count": len(self._agents),
        }

    def _run_sequential(self, input_text: str) -> list[dict[str, Any]]:
        """Run agents sequentially (safe for Rust-backed agents)."""
        results = []
        for agent in self._agents:
            result = agent.execute(input_text)
            results.append({
                "agent": agent.name,
                "output": result,
            })
        return results

    def _run_parallel(self, input_text: str) -> list[dict[str, Any]]:
        """Run pure-Python agents in parallel using ThreadPoolExecutor."""
        results: list[dict[str, Any]] = [{}] * len(self._agents)

        def run_agent(idx_agent: tuple[int, BaseAgent]) -> tuple[int, dict[str, Any]]:
            idx, agent = idx_agent
            result = agent.execute(input_text)
            return idx, {"agent": agent.name, "output": result}

        workers = self._max_workers or min(len(self._agents), 4)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for idx, entry in pool.map(run_agent, enumerate(self._agents)):
                results[idx] = entry

        return results

    def __repr__(self) -> str:
        names = [a.name for a in self._agents]
        return f"ParallelPipeline(agents={names})"
