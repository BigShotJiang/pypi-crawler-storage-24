"""Ensemble pipeline: run multiple agents and aggregate results.

All agents process the same input, and an aggregator function combines
their outputs into a final response::

    pipeline = EnsemblePipeline(
        [agent1, agent2, agent3],
        aggregator=lambda results: max(results, key=lambda r: len(r.get("response", ""))),
    )
    result = pipeline.run("input")

CRITICAL GIL SAFETY NOTE:
    When using real Rust-backed Agent objects, this pipeline runs them
    sequentially to avoid GIL deadlock. ThreadPoolExecutor is only safe
    for pure-Python BaseAgent subclasses with overridden execute().
"""

from __future__ import annotations

import concurrent.futures
from typing import Any, Callable, List, Optional

from kailash.kaizen.agent import BaseAgent
from kailash.kaizen.pipelines.parallel import _is_pure_python_agent


def _default_aggregator(results: list[dict[str, Any]]) -> dict[str, Any]:
    """Default aggregator: pick the first successful result."""
    for r in results:
        if "response" in r:
            return r
    return results[0] if results else {"response": "No results"}


class EnsemblePipeline:
    """Run multiple agents and aggregate their results.

    All agents run in parallel on the same input. An aggregator function
    selects or combines the final output.

    Args:
        agents: List of agents to run.
        aggregator: Function ``(list[dict]) -> dict`` that combines results.
            Defaults to selecting the first successful result.
        name: Optional pipeline name.
    """

    def __init__(
        self,
        agents: List[BaseAgent],
        aggregator: Optional[Callable[[list[dict[str, Any]]], dict[str, Any]]] = None,
        name: str = "EnsemblePipeline",
    ) -> None:
        if not agents:
            raise ValueError("EnsemblePipeline requires at least one agent")
        self._agents = list(agents)
        self._aggregator = aggregator or _default_aggregator
        self._name = name

    def run(self, input_text: str) -> dict[str, Any]:
        """Execute all agents and aggregate results.

        Uses ThreadPoolExecutor for pure-Python agents, sequential
        execution for Rust-backed agents to avoid GIL deadlock.

        Args:
            input_text: Input for all agents.

        Returns:
            A dict with ``response`` (aggregated), ``individual_results``,
            and ``agent_count``.
        """
        individual: list[dict[str, Any]] = []
        all_pure_python = all(_is_pure_python_agent(a) for a in self._agents)

        if all_pure_python and len(self._agents) > 1:
            individual = self._run_parallel(input_text)
        else:
            individual = self._run_sequential(input_text)

        aggregated = self._aggregator(individual)

        return {
            "response": aggregated.get("response", str(aggregated)),
            "individual_results": individual,
            "agent_count": len(self._agents),
        }

    def _run_sequential(self, input_text: str) -> list[dict[str, Any]]:
        """Run agents sequentially (safe for Rust-backed agents)."""
        results: list[dict[str, Any]] = []
        for agent in self._agents:
            try:
                results.append(agent.execute(input_text))
            except Exception as exc:
                results.append({
                    "response": f"Error from {agent.name}: {exc}",
                    "error": True,
                })
        return results

    def _run_parallel(self, input_text: str) -> list[dict[str, Any]]:
        """Run pure-Python agents in parallel using ThreadPoolExecutor."""
        results: list[dict[str, Any]] = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(self._agents)) as pool:
            futures = {
                pool.submit(agent.execute, input_text): agent
                for agent in self._agents
            }
            for future in concurrent.futures.as_completed(futures):
                agent = futures[future]
                try:
                    results.append(future.result())
                except Exception as exc:
                    results.append({
                        "response": f"Error from {agent.name}: {exc}",
                        "error": True,
                    })
        return results

    @property
    def agents(self) -> List[BaseAgent]:
        """The agents in this ensemble."""
        return list(self._agents)

    def __repr__(self) -> str:
        return f"EnsemblePipeline(name={self._name!r}, agents={len(self._agents)})"
