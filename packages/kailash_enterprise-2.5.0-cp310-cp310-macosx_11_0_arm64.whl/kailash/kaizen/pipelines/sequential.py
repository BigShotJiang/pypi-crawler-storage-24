"""Sequential pipeline: run agents in order, passing output to next."""

from __future__ import annotations

from typing import Any

from kailash.kaizen.agent import BaseAgent


class SequentialPipeline:
    """Run agents sequentially, piping each agent's output to the next.

    The first agent receives the original input. Each subsequent agent
    receives the ``response`` field from the previous agent's output.

    Example::

        pipeline = SequentialPipeline([agent1, agent2, agent3])
        result = pipeline.run("initial input")
        # result contains the final agent's output plus trace
    """

    def __init__(self, agents: list[BaseAgent]) -> None:
        if not agents:
            raise ValueError("SequentialPipeline requires at least one agent")
        self._agents = list(agents)

    @property
    def agents(self) -> list[BaseAgent]:
        """The ordered list of agents in this pipeline."""
        return list(self._agents)

    def run(self, input_text: str) -> dict[str, Any]:
        """Execute the pipeline sequentially.

        Args:
            input_text: The initial input text.

        Returns:
            A dict with ``response`` (final output), ``trace`` (list of
            per-agent results), and ``agent_count``.
        """
        trace: list[dict[str, Any]] = []
        current_input = input_text

        for agent in self._agents:
            result = agent.execute(current_input)
            trace.append({
                "agent": agent.name,
                "input": current_input,
                "output": result,
            })
            current_input = result.get("response", str(result))

        return {
            "response": current_input,
            "trace": trace,
            "agent_count": len(self._agents),
        }

    def __repr__(self) -> str:
        names = [a.name for a in self._agents]
        return f"SequentialPipeline(agents={names})"
