"""HealthMonitor for continuous, background health monitoring of Nexus apps.

Provides configurable periodic health checks, status aggregation across
components, and a bounded health history for trend analysis.

Usage::

    from kailash.nexus import HealthMonitor, HealthMonitorConfig

    config = HealthMonitorConfig(check_interval_secs=10.0, history_size=50)
    monitor = HealthMonitor(config=config)

    # Register custom health checks (callables returning status dicts)
    monitor.add_check("database", lambda: {"status": "healthy", "details": "connected"})
    monitor.add_check("cache", lambda: {"status": "degraded", "details": "high latency"})

    # Run an immediate check
    report = monitor.check_now()
    print(report["overall"])  # "degraded"

    # Background monitoring
    monitor.start()
    # ... later ...
    monitor.stop()
"""

import threading
import time as _time
from collections import deque
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional


class HealthMonitorConfig:
    """Configuration for the HealthMonitor.

    Args:
        check_interval_secs: How often background checks run, in seconds (default: 30.0).
        history_size: Maximum number of reports to retain (default: 100).
        alert_on_degraded: Whether to flag degraded status transitions (default: True).
        alert_on_unhealthy: Whether to flag unhealthy status transitions (default: True).
    """

    def __init__(
        self,
        check_interval_secs: float = 30.0,
        history_size: int = 100,
        alert_on_degraded: bool = True,
        alert_on_unhealthy: bool = True,
    ) -> None:
        if check_interval_secs <= 0:
            raise ValueError(
                f"check_interval_secs must be positive, got {check_interval_secs}"
            )
        if history_size <= 0:
            raise ValueError(
                f"history_size must be positive, got {history_size}"
            )
        self.check_interval_secs = check_interval_secs
        self.history_size = history_size
        self.alert_on_degraded = alert_on_degraded
        self.alert_on_unhealthy = alert_on_unhealthy

    def __repr__(self) -> str:
        return (
            f"HealthMonitorConfig("
            f"check_interval_secs={self.check_interval_secs}, "
            f"history_size={self.history_size}, "
            f"alert_on_degraded={self.alert_on_degraded}, "
            f"alert_on_unhealthy={self.alert_on_unhealthy})"
        )


def _aggregate_status(current: str, new: str) -> str:
    """Aggregate two health statuses, returning the worst.

    Priority: unhealthy > degraded > healthy.
    """
    priority = {"unhealthy": 2, "degraded": 1, "healthy": 0}
    current_p = priority.get(current, 0)
    new_p = priority.get(new, 0)
    if new_p > current_p:
        return new
    return current


def _run_single_check(
    name: str, check_fn: Callable[[], Dict[str, Any]]
) -> Dict[str, Any]:
    """Run a single health check function and return a ComponentHealth dict.

    If the check function raises, the component is marked as unhealthy
    with the exception message in the details field.
    """
    start = _time.monotonic()
    try:
        result = check_fn()
        elapsed_ms = (_time.monotonic() - start) * 1000.0

        if not isinstance(result, dict):
            raise TypeError(
                f"Health check '{name}' must return a dict, got {type(result).__name__}"
            )
        if "status" not in result:
            raise KeyError(
                f"Health check '{name}' dict must contain 'status' key "
                f"(one of 'healthy', 'degraded', 'unhealthy'), got keys: {list(result.keys())}"
            )

        status = result["status"]
        valid_statuses = ("healthy", "degraded", "unhealthy")
        if status not in valid_statuses:
            raise ValueError(
                f"Health check '{name}' returned invalid status '{status}', "
                f"must be one of: {valid_statuses}"
            )

        return {
            "name": name,
            "status": status,
            "last_check": datetime.now(timezone.utc).isoformat(),
            "check_duration_ms": round(elapsed_ms, 3),
            "details": result.get("details"),
        }
    except Exception as exc:
        elapsed_ms = (_time.monotonic() - start) * 1000.0
        return {
            "name": name,
            "status": "unhealthy",
            "last_check": datetime.now(timezone.utc).isoformat(),
            "check_duration_ms": round(elapsed_ms, 3),
            "details": str(exc),
        }


class HealthMonitor:
    """Continuous health monitor with background check support.

    Maintains a registry of named health check functions, runs them on
    demand or periodically in a background thread, and stores results
    in a bounded history.

    Health checks are plain Python callables that return a dict with
    at least a ``"status"`` key set to one of ``"healthy"``,
    ``"degraded"``, or ``"unhealthy"``. An optional ``"details"``
    key provides human-readable context.

    Args:
        config: Optional ``HealthMonitorConfig``. Defaults to the
            standard configuration (30s interval, 100 history size).

    Example::

        monitor = HealthMonitor()
        monitor.add_check("db", lambda: {"status": "healthy"})
        report = monitor.check_now()
        assert report["overall"] == "healthy"
    """

    def __init__(self, config: Optional[HealthMonitorConfig] = None) -> None:
        self._config = config if config is not None else HealthMonitorConfig()
        self._checks: Dict[str, Callable[[], Dict[str, Any]]] = {}
        self._history: deque = deque(maxlen=self._config.history_size)
        self._lock = threading.Lock()
        self._running = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._created_at = _time.monotonic()

    def add_check(self, name: str, check_fn: Callable[[], Dict[str, Any]]) -> None:
        """Register a named health check function.

        Args:
            name: Unique name for this health check component.
            check_fn: Callable that returns a dict with at least
                ``{"status": "healthy"|"degraded"|"unhealthy"}``.
                May also include ``"details": str``.

        Raises:
            TypeError: If *check_fn* is not callable.
        """
        if not callable(check_fn):
            raise TypeError(
                f"check_fn for '{name}' must be callable, got {type(check_fn).__name__}"
            )
        with self._lock:
            self._checks[name] = check_fn

    def remove_check(self, name: str) -> None:
        """Remove a health check by name.

        If no check with the given name is registered, this is a no-op.

        Args:
            name: The name of the health check to remove.
        """
        with self._lock:
            self._checks.pop(name, None)

    def check_now(self) -> Dict[str, Any]:
        """Run all registered health checks immediately.

        Returns a health report dict with the following structure::

            {
                "overall": "healthy" | "degraded" | "unhealthy",
                "components": {
                    "component_name": {
                        "name": str,
                        "status": str,
                        "last_check": str,  # ISO 8601
                        "check_duration_ms": float,
                        "details": str | None,
                    },
                    ...
                },
                "timestamp": str,  # ISO 8601
                "uptime_secs": float,
            }

        The report is also appended to the internal history (bounded
        by ``HealthMonitorConfig.history_size``).

        Returns:
            A health report dict.
        """
        with self._lock:
            checks_snapshot = dict(self._checks)

        overall = "healthy"
        components: Dict[str, Any] = {}

        for name, check_fn in checks_snapshot.items():
            comp = _run_single_check(name, check_fn)
            overall = _aggregate_status(overall, comp["status"])
            components[name] = comp

        report = {
            "overall": overall,
            "components": components,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "uptime_secs": round(_time.monotonic() - self._created_at, 3),
        }

        with self._lock:
            self._history.append(report)

        return report

    def latest(self) -> Optional[Dict[str, Any]]:
        """Return the most recent health report, or None if none exists.

        Returns:
            The latest health report dict, or ``None``.
        """
        with self._lock:
            if self._history:
                return self._history[-1]
            return None

    def history(self) -> List[Dict[str, Any]]:
        """Return a copy of the health report history.

        Returns:
            A list of health report dicts, oldest first.
        """
        with self._lock:
            return list(self._history)

    def start(self) -> None:
        """Start background health monitoring.

        Spawns a daemon thread that calls :meth:`check_now` at the
        configured interval. If already running, this is a no-op.
        """
        if self._running.is_set():
            return
        self._running.set()
        self._thread = threading.Thread(
            target=self._background_loop,
            daemon=True,
            name="HealthMonitor-bg",
        )
        self._thread.start()

    def stop(self) -> None:
        """Stop background health monitoring.

        If not running, this is a no-op. Blocks briefly until the
        background thread terminates.
        """
        if not self._running.is_set():
            return
        self._running.clear()
        thread = self._thread
        self._thread = None
        if thread is not None and thread.is_alive():
            thread.join(timeout=self._config.check_interval_secs + 1.0)

    def _background_loop(self) -> None:
        """Internal loop for the background monitoring thread."""
        interval = self._config.check_interval_secs
        while self._running.is_set():
            self.check_now()
            # Sleep in small increments so stop() is responsive
            deadline = _time.monotonic() + interval
            while self._running.is_set() and _time.monotonic() < deadline:
                _time.sleep(min(0.05, deadline - _time.monotonic()))

    def __repr__(self) -> str:
        with self._lock:
            check_count = len(self._checks)
            history_count = len(self._history)
        return (
            f"HealthMonitor(checks={check_count}, "
            f"history={history_count}, "
            f"running={self._running.is_set()})"
        )
