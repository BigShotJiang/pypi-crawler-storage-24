"""Extended Nexus class with convenience registration methods.

Wraps the Rust-backed ``Nexus`` class to add ``register()``,
``register_handler()``, ``run()``, and ``serve()`` convenience methods.

When the Rust binding is rebuilt with native support for these methods,
this wrapper detects them automatically and delegates to the native
implementation.
"""

from typing import Any, Callable, Dict, List, Optional

from kailash._kailash import EventBus
from kailash._kailash import Nexus as _RustNexus
from kailash._kailash import HandlerParam as _HandlerParam
from kailash._kailash import NexusConfig as _NexusConfig
from kailash._kailash import Preset as _Preset


class Nexus:
    """Multi-channel deployment platform.

    Wraps the Rust-backed ``Nexus`` class and adds convenience methods:
    ``register()``, ``register_handler()``, ``run()``, ``serve()``.

    All other methods delegate directly to the underlying Rust instance.

    Example::

        app = Nexus()
        app.register("greet", lambda inputs: {"message": f"Hello {inputs['name']}"})
        app.start()
    """

    def __init__(
        self,
        config: Optional[_NexusConfig] = None,
        preset: Optional[_Preset] = None,
    ) -> None:
        self._inner = _RustNexus(config=config, preset=preset)

    def handler(
        self,
        name: str,
        func: Any,
        params: Optional[List[_HandlerParam]] = None,
        description: Optional[str] = None,
    ) -> None:
        """Register a Python handler (decorator-compatible).

        Args:
            name: Handler name (used as API route: ``POST /api/{name}``).
            func: Python callable with signature ``def fn(inputs: dict) -> Any``.
            params: Optional list of HandlerParam for parameter metadata.
            description: Optional handler description.
        """
        if params is None:
            params = []
        self._inner.handler(name, func, params, description)

    def register(
        self,
        name: str,
        func: Any,
        params: Optional[List[_HandlerParam]] = None,
        description: Optional[str] = None,
    ) -> None:
        """Imperatively register a handler (non-decorator pattern).

        Functionally identical to ``handler()`` but named for imperative use.
        Useful for dynamic registration from config, loops, or other modules.

        Args:
            name: Handler name (used as API route: ``POST /api/{name}``).
            func: Python callable with signature ``def fn(inputs: dict) -> Any``.
            params: Optional list of HandlerParam for parameter metadata.
            description: Optional handler description.
        """
        self.handler(name, func, params=params, description=description)

    def register_handler(
        self,
        name: str,
        func: Any,
        params: Optional[List[_HandlerParam]] = None,
        description: Optional[str] = None,
    ) -> None:
        """Alias for ``register()`` -- improves discoverability.

        Args:
            name: Handler name.
            func: Python callable.
            params: Optional parameter list.
            description: Optional description.
        """
        self.register(name, func, params=params, description=description)

    def preset(self, preset: _Preset) -> None:
        """Apply a middleware preset."""
        self._inner.preset(preset)

    def set_middleware(self, config: Any) -> None:
        """Set a custom middleware configuration."""
        self._inner.set_middleware(config)

    def get_registered_handlers(self) -> List[Dict[str, Any]]:
        """Return metadata for every registered handler."""
        return self._inner.get_registered_handlers()

    def health_check(self) -> Dict[str, Any]:
        """Return a health-check dict."""
        return self._inner.health_check()

    def handler_count(self) -> int:
        """Return the number of registered handlers."""
        return self._inner.handler_count()

    def start(self) -> None:
        """Start the HTTP server (blocking)."""
        self._inner.start()

    def run(self) -> None:
        """Start the HTTP server (alias for ``start()``).

        Matches the ``run()`` convention from Flask and similar frameworks.
        """
        self.start()

    def serve(self) -> None:
        """Start the HTTP server (alias for ``start()``).

        Matches the ``serve()`` convention from web frameworks.
        """
        self.start()

    def event_bus(self) -> EventBus:
        """Return the event bus for this Nexus instance.

        Use the event bus to subscribe to lifecycle events or publish
        custom events.

        Returns:
            An EventBus instance.

        Example::

            app = Nexus()
            bus = app.event_bus()
            bus.publish("my_event", {"key": "value"})
        """
        return self._inner.event_bus()

    def subscribe(self, callback: Callable) -> None:
        """Subscribe to all events on this Nexus instance.

        Convenience wrapper around ``event_bus().subscribe()``.

        Args:
            callback: Python callable ``def fn(event: dict) -> None``.

        Example::

            def on_event(event):
                print(f"Event: {event['type']}")
            app.subscribe(on_event)
        """
        self._inner.subscribe(callback)

    def on(self, event_type: str, callback: Callable) -> None:
        """Subscribe to events of a specific type on this Nexus instance.

        Convenience wrapper around ``event_bus().on()``.

        Args:
            event_type: The event type to filter for.
            callback: Python callable ``def fn(event: dict) -> None``.

        Example::

            app.on("handler_registered", lambda e: print(e["name"]))
        """
        self._inner.on(event_type, callback)

    @property
    def config(self) -> _NexusConfig:
        """The underlying server configuration."""
        return self._inner.config

    def __repr__(self) -> str:
        return repr(self._inner)
