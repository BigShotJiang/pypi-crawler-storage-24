"""Nexus middleware helper functions.

Convenience constructors for common middleware configurations::

    from kailash.nexus import cors, rate_limit, preset_to_middleware

    mw = cors(origins=["https://example.com"])
    mw = rate_limit(per_minute=200)
    mw = preset_to_middleware("standard")
"""

from typing import List, Optional

from kailash._kailash import MiddlewareConfig


def preset_to_middleware(preset_name: str) -> MiddlewareConfig:
    """Convert a preset name to a ``MiddlewareConfig``.

    Args:
        preset_name: One of ``"none"``, ``"lightweight"``, ``"standard"``,
            ``"saas"``, ``"enterprise"``.

    Returns:
        A ``MiddlewareConfig`` populated from the preset.

    Raises:
        ValueError: If the preset name is not recognised.
    """
    return MiddlewareConfig.from_preset(preset_name)


def cors(origins: Optional[List[str]] = None) -> MiddlewareConfig:
    """Create a CORS-only middleware config.

    Args:
        origins: Allowed origins. Defaults to ``["*"]`` (permissive).

    Returns:
        A ``MiddlewareConfig`` with CORS enabled.
    """
    if origins is None:
        origins = ["*"]
    return MiddlewareConfig().with_cors(origins)


def rate_limit(per_minute: int = 100) -> MiddlewareConfig:
    """Create a rate-limit-only middleware config.

    Args:
        per_minute: Maximum requests per minute.

    Returns:
        A ``MiddlewareConfig`` with rate limiting enabled.
    """
    return MiddlewareConfig().with_rate_limit(per_minute)
