"""Nexus authentication helpers.

Provides pure-Python auth utilities that complement the Rust-backed
``JwtConfig``, ``RbacConfig``, and ``AuthRateLimitConfig`` types::

    from kailash.nexus import NexusAuthPlugin, SessionStore, JwtConfig

    auth = NexusAuthPlugin(jwt=JwtConfig("secret-at-least-32-bytes-long!!"))
    sessions = SessionStore()
    sid = sessions.create("user-42", tenant_id="acme")
    info = sessions.get(sid)
"""

import dataclasses
import threading
import time
import uuid
from typing import Dict, Optional

from kailash._kailash import AuthRateLimitConfig, JwtConfig, RbacConfig


@dataclasses.dataclass
class NexusAuthPlugin:
    """Auth configuration bundle.

    Groups JWT, RBAC, and rate-limit configs together with a tenant header
    name for convenient wiring into a Nexus application.

    Args:
        jwt: Optional JWT configuration.
        rbac: Optional RBAC configuration.
        rate_limit: Optional per-user/per-tenant rate-limit configuration.
        tenant_header: HTTP header name for tenant identification.
    """

    jwt: Optional[JwtConfig] = None
    rbac: Optional[RbacConfig] = None
    rate_limit: Optional[AuthRateLimitConfig] = None
    tenant_header: str = "X-Tenant-ID"


@dataclasses.dataclass
class SessionInfo:
    """Metadata for an active session.

    Attributes:
        session_id: Unique session identifier (UUID4).
        user_id: The user who owns this session.
        tenant_id: Optional tenant scope.
        created_at: Epoch timestamp when the session was created.
        expires_at: Epoch timestamp when the session expires.
    """

    session_id: str
    user_id: str
    tenant_id: Optional[str] = None
    created_at: float = 0.0
    expires_at: float = 0.0


class SessionStore:
    """Thread-safe in-memory session storage.

    Provides create / get / revoke semantics with automatic expiry.

    Example::

        store = SessionStore()
        sid = store.create("user-1", expiry_secs=1800)
        info = store.get(sid)
        assert info.user_id == "user-1"
        store.revoke(sid)
        assert store.get(sid) is None
    """

    def __init__(self) -> None:
        self._sessions: Dict[str, SessionInfo] = {}
        self._lock = threading.Lock()

    def create(
        self,
        user_id: str,
        tenant_id: Optional[str] = None,
        expiry_secs: int = 3600,
    ) -> str:
        """Create a new session and return its ID (UUID4 hex string)."""
        now = time.time()
        session_id = uuid.uuid4().hex
        info = SessionInfo(
            session_id=session_id,
            user_id=user_id,
            tenant_id=tenant_id,
            created_at=now,
            expires_at=now + expiry_secs,
        )
        with self._lock:
            self._sessions[session_id] = info
        return session_id

    def get(self, session_id: str) -> Optional[SessionInfo]:
        """Return session info, or ``None`` if expired / not found."""
        with self._lock:
            info = self._sessions.get(session_id)
            if info is None:
                return None
            if time.time() > info.expires_at:
                del self._sessions[session_id]
                return None
            return info

    def revoke(self, session_id: str) -> bool:
        """Revoke a session. Returns ``True`` if the session existed."""
        with self._lock:
            return self._sessions.pop(session_id, None) is not None

    def active_count(self) -> int:
        """Number of non-expired sessions."""
        now = time.time()
        with self._lock:
            expired = [k for k, v in self._sessions.items() if now > v.expires_at]
            for k in expired:
                del self._sessions[k]
            return len(self._sessions)
