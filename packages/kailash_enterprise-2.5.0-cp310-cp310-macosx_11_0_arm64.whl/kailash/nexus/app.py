"""Flask-like NexusApp with @handler() decorator support.

Provides a high-level decorator API on top of the Rust-backed ``Nexus`` class::

    from kailash.nexus import NexusApp

    app = NexusApp(preset="standard")

    @app.handler()
    def greet(name: str, greeting: str = "Hello"):
        return {"message": f"{greeting}, {name}!"}

    app.start()
"""

import inspect
from typing import Any, Callable, Dict, List, Optional, Union

from kailash._kailash import (
    HandlerParam,
    MiddlewareConfig,
    Nexus,
    NexusConfig,
    Preset,
)


def _extract_params_from_signature(func: Callable) -> List[HandlerParam]:
    """Inspect function parameters and build a HandlerParam list.

    Type annotations are mapped to Nexus param_type strings:
      int -> "integer", float -> "number", bool -> "boolean", str -> "string".
    Parameters with defaults are marked as not required.
    ``self`` and ``cls`` are skipped.
    """
    sig = inspect.signature(func)
    params: List[HandlerParam] = []
    type_map = {int: "integer", float: "number", bool: "boolean", str: "string"}

    for param_name, param in sig.parameters.items():
        if param_name in ("self", "cls"):
            continue
        param_type = "string"
        if param.annotation is not inspect.Parameter.empty:
            param_type = type_map.get(param.annotation, "string")
        required = param.default is inspect.Parameter.empty
        params.append(HandlerParam(param_name, param_type, required=required))
    return params


class NexusApp:
    """Flask-like application with ``@handler()`` decorator support.

    Wraps the Rust-backed ``Nexus`` instance and adds Pythonic conveniences:
    auto-inspection of function signatures, CORS/rate-limit helpers, and
    health-check / handler-listing methods.

    Args:
        config: Optional ``NexusConfig`` for host/port/channel toggles.
        preset: Optional preset name (``"none"``, ``"lightweight"``,
            ``"standard"``, ``"saas"``, ``"enterprise"``) or ``Preset`` instance.
    """

    def __init__(
        self,
        config: Optional[NexusConfig] = None,
        preset: Optional[Union[str, Preset]] = None,
    ) -> None:
        preset_obj: Optional[Preset] = None
        if isinstance(preset, str):
            preset_obj = Preset(preset)
        elif isinstance(preset, Preset):
            preset_obj = preset

        self._nexus = Nexus(config=config, preset=preset_obj)

    # --------------------------------------------------------------------- #
    # Decorator API
    # --------------------------------------------------------------------- #

    def handler(
        self,
        name: Optional[str] = None,
        description: Optional[str] = None,
        params: Optional[List[HandlerParam]] = None,
    ) -> Callable:
        """Decorator to register a handler function.

        If *params* is not given the function signature is inspected
        automatically: each parameter becomes a ``HandlerParam`` with its
        type annotation mapped to the corresponding param_type string.

        Args:
            name: Handler name. Defaults to ``func.__name__``.
            description: Human-readable description. Defaults to the
                function's docstring (first line) or ``""``.
            params: Explicit list of ``HandlerParam``. When ``None`` the
                params are inferred from the function signature.

        Returns:
            The original function (unmodified), so it can still be called
            directly.
        """

        def decorator(func: Callable) -> Callable:
            handler_name = name if name is not None else func.__name__
            handler_desc = description if description is not None else (func.__doc__ or "").strip().split("\n")[0]
            handler_params = params if params is not None else _extract_params_from_signature(func)
            self._nexus.handler(handler_name, func, handler_params, handler_desc)
            return func

        return decorator

    # --------------------------------------------------------------------- #
    # Imperative Registration API
    # --------------------------------------------------------------------- #

    def register(
        self,
        name: str,
        func: Callable,
        params: Optional[List[HandlerParam]] = None,
        description: Optional[str] = None,
        auto_params: bool = False,
    ) -> None:
        """Imperatively register a handler function (non-decorator pattern).

        Useful for dynamic registration from config, loops, or other modules
        where decorators are inconvenient.

        Args:
            name: Handler name (used as API route: ``POST /api/{name}``).
            func: Python callable. Receives a dict of inputs and returns
                a value (dict, list, str, int, float, bool, or None).
            params: Explicit list of ``HandlerParam``. When provided,
                overrides auto-inspection regardless of *auto_params*.
            description: Optional human-readable description.
            auto_params: When ``True`` and *params* is ``None``, inspect
                the function signature to generate ``HandlerParam`` list
                automatically. Defaults to ``False``.
        """
        if params is not None:
            handler_params = params
        elif auto_params:
            handler_params = _extract_params_from_signature(func)
        else:
            handler_params = []
        self._nexus.handler(name, func, handler_params, description)

    def register_handler(
        self,
        name: str,
        func: Callable,
        params: Optional[List[HandlerParam]] = None,
        description: Optional[str] = None,
        auto_params: bool = False,
    ) -> None:
        """Alias for :meth:`register` -- improves discoverability.

        Args:
            name: Handler name.
            func: Python callable.
            params: Explicit parameter list.
            description: Optional description.
            auto_params: Auto-inspect function signature for params.
        """
        self.register(name, func, params=params, description=description, auto_params=auto_params)

    # --------------------------------------------------------------------- #
    # Middleware helpers
    # --------------------------------------------------------------------- #

    def add_cors(self, origins: Optional[List[str]] = None) -> None:
        """Add CORS middleware.

        Args:
            origins: Allowed origins. Defaults to ``["*"]`` (permissive).
        """
        if origins is None:
            origins = ["*"]
        mw = MiddlewareConfig().with_cors(origins)
        self._nexus.set_middleware(mw)

    def add_rate_limit(self, max_requests: int = 100, window_secs: int = 60) -> None:
        """Add rate-limiting middleware.

        Args:
            max_requests: Maximum requests within the window.
            window_secs: Window duration in seconds (currently maps to
                per-minute rate via Rust backend).
        """
        mw = MiddlewareConfig().with_rate_limit(max_requests)
        self._nexus.set_middleware(mw)

    # --------------------------------------------------------------------- #
    # Introspection
    # --------------------------------------------------------------------- #

    def health_check(self) -> Dict[str, Any]:
        """Return a health-check dict (``{"status": "ok", ...}``)."""
        return dict(self._nexus.health_check())

    def get_registered_handlers(self) -> List[Dict[str, Any]]:
        """Return metadata for every registered handler."""
        return [dict(h) for h in self._nexus.get_registered_handlers()]

    @property
    def handler_count(self) -> int:
        """Number of registered handlers."""
        return self._nexus.handler_count()

    @property
    def config(self) -> NexusConfig:
        """The underlying server configuration."""
        return self._nexus.config

    # --------------------------------------------------------------------- #
    # Lifecycle
    # --------------------------------------------------------------------- #

    def start(self) -> None:
        """Start the HTTP server (blocking)."""
        self._nexus.start()

    def run(self) -> None:
        """Start the HTTP server (alias for :meth:`start`).

        Matches the ``run()`` convention from Flask and similar frameworks.
        """
        self.start()

    def serve(self) -> None:
        """Start the HTTP server (alias for :meth:`start`).

        Matches the ``serve()`` convention from web frameworks.
        """
        self.start()

    def __repr__(self) -> str:
        return f"NexusApp(handlers={self._nexus.handler_count()}, bind={self._nexus.config.bind_address()})"
