"""Kailash Nexus MCP -- MCP server integration within the Nexus platform.

Provides transport constants, auth helpers, and re-exports for building
MCP servers that run under the Nexus multi-channel platform.

**Transport constants**::

    from kailash.nexus.mcp import STDIO, SSE, HTTP

**McpApplication with transport and auth**::

    from kailash.nexus.mcp import McpApplication

    app = McpApplication("my-app", version="1.0.0", transport="sse")
    app.require_auth(api_keys=["my-key"])

**Re-exports from kailash.mcp**::

    from kailash.nexus.mcp import McpServer, prompt_argument
"""

from kailash._kailash import McpServer
from kailash.mcp.server import McpApplication
from kailash.mcp import prompt_argument

# ---------------------------------------------------------------------------
# Transport constants
# ---------------------------------------------------------------------------

STDIO: str = "stdio"
"""Standard I/O transport (default)."""

SSE: str = "sse"
"""Server-Sent Events transport."""

HTTP: str = "http"
"""HTTP Streamable transport."""


__all__ = [
    # Rust-backed types
    "McpServer",
    # Python convenience wrapper
    "McpApplication",
    # Transport constants
    "STDIO",
    "SSE",
    "HTTP",
    # Helpers
    "prompt_argument",
]
