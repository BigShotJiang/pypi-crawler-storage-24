"""Shared test fixtures for MRP SDK tests."""

import pytest

from mrp.auth import Keypair


@pytest.fixture
def keypair():
    """Generate a fresh keypair for each test."""
    return Keypair.generate()


@pytest.fixture
def relay_url():
    """Default relay URL for tests."""
    return "http://localhost:8080"
