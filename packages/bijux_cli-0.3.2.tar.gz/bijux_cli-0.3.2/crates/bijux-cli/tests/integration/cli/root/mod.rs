#![forbid(unsafe_code)]
//! root integration suites.

mod bin_core_integration;
mod cli_command_matrix;
mod cross_surface_equivalence;
mod flag_normalization_matrix;
mod install_command;
mod parser_invalid_utf8_argv;
mod precedence_matrix;
mod python_command_port_parity;
mod root_command_matrix;
