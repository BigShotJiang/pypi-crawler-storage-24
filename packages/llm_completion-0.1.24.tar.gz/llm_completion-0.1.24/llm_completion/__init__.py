"""LLM Completion library using LiteLLM."""

from .base import CompletionProvider
from .completion import LiteLLMCompletion
from .router_completion import WeightedRouterCompletion
from .exceptions import (
    CompletionError,
    APIKeyError,
    RateLimitError,
    ModelNotAvailableError,
    InvalidRequestError,
    LLMTimeoutError,
)
from .tag_manager import TagManager

__all__ = [
    "CompletionProvider",
    "LiteLLMCompletion",
    "WeightedRouterCompletion",
    "CompletionError",
    "APIKeyError",
    "RateLimitError",
    "ModelNotAvailableError",
    "InvalidRequestError",
    "LLMTimeoutError",
    "TagManager",
]