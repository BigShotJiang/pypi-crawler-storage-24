"""Squad Up MCP Server - Event planning via natural language."""

__version__ = "0.1.0"
