"""
Calendar link generation - ported from frontend/src/lib/calendar.ts.

This is pure logic: given event data, we produce Google Calendar URL,
Outlook URL, and ICS file content. No API calls, no side effects.
"""

from urllib.parse import urlencode


def _to_ics_utc(iso: str) -> str:
    """Format ISO date for ICS (UTC): 20260224T180300Z"""
    from datetime import datetime

    dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
    return dt.strftime("%Y%m%dT%H%M%SZ")


def _ics_escape(text: str) -> str:
    """Escape text for ICS (replace commas, semicolons, backslashes)"""
    return text.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def generate_ics(
    title: str,
    start_iso: str,
    end_iso: str,
    location: str = "",
    description: str = "",
) -> str:
    """Generate ICS file content for a calendar event."""
    start = _to_ics_utc(start_iso)
    end = _to_ics_utc(end_iso) if end_iso else start
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//Squad Up//Event//EN",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        "BEGIN:VEVENT",
        f"DTSTART:{start}",
        f"DTEND:{end}",
        f"SUMMARY:{_ics_escape(title)}",
        f"LOCATION:{_ics_escape(location)}" if location else None,
        f"DESCRIPTION:{_ics_escape(description)}" if description else None,
        "END:VEVENT",
        "END:VCALENDAR",
    ]
    return "\r\n".join(line for line in lines if line is not None)


def google_calendar_url(
    title: str,
    start_iso: str,
    end_iso: str,
    location: str = "",
    description: str = "",
) -> str:
    """Build Google Calendar add-event URL."""
    end = end_iso or start_iso
    params = {
        "action": "TEMPLATE",
        "text": title,
        "dates": f"{_to_ics_utc(start_iso)}/{_to_ics_utc(end)}",
        "details": description or "",
        "location": location or "",
    }
    return f"https://calendar.google.com/calendar/render?{urlencode(params)}"


def outlook_url(
    title: str,
    start_iso: str,
    end_iso: str,
    location: str = "",
    description: str = "",
) -> str:
    """Build Outlook.com add-event URL."""
    end = end_iso or start_iso
    params = {
        "path": "/calendar/action/compose",
        "rru": "addevent",
        "subject": title,
        "startdt": start_iso,
        "enddt": end,
        "body": description or "",
        "location": location or "",
    }
    return f"https://outlook.office.com/calendar/0/action/compose?{urlencode(params)}"
