"""Entry point for running the MCP server: python -m squad_up_mcp"""

from .server import run

if __name__ == "__main__":
    run()
