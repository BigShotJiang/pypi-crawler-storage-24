"""
Squad Up MCP Server - Main server with tools.

Each @mcp.tool() function becomes a tool that Claude can call.
The docstring is the tool description Claude sees.
"""

import os
from urllib.parse import quote

import httpx
from mcp.server.fastmcp import FastMCP

from .calendar import generate_ics, google_calendar_url, outlook_url

# Base URL for Squad Up API - configurable via env
API_BASE = os.environ.get("SQUAD_UP_API_URL", "http://localhost:8000/api")


def _api(path: str, method: str = "GET", json: dict | None = None) -> dict | list:
    """Call Squad Up API. Raises on error with API response body when available."""
    url = f"{API_BASE.rstrip('/')}{path}"
    with httpx.Client(timeout=30.0) as client:
        resp = client.request(method, url, json=json)
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            detail = str(e)
            if resp.content:
                try:
                    body = resp.json()
                    if isinstance(body, dict) and "detail" in body:
                        detail = f"{e.response.status_code}: {body['detail']}"
                    else:
                        detail = f"{e.response.status_code}: {resp.text[:500]}"
                except Exception:
                    detail = f"{e.response.status_code}: {resp.text[:500]}"
            raise RuntimeError(detail) from e
        return resp.json() if resp.content else {}


mcp = FastMCP(
    "Squad Up",
    json_response=True,
)


@mcp.tool()
def create_event(
    host_email: str,
    host_name: str,
    title: str,
    tagline: str,
    date_time: str,
    location: str,
    date_time_end: str | None = None,
    timezone: str = "UTC",
    carpool_enabled: bool = False,
    potluck_enabled: bool = False,
    attendee_limit: int | None = None,
    frontend_base_url: str = "https://checkdin.online",
) -> dict:
    """
    Create a new event. Returns event_id, invite_token (use for update_event), host link, view link, and calendar links.

    IMPORTANT: You must convert the user's date/time to ISO 8601 format before calling.
    - date_time: ISO format "YYYY-MM-DDTHH:MM:SS" (e.g. "2026-03-15T15:00:00"). Convert "tomorrow at 3pm", "December 25", "next Saturday" etc. to this format. Use a future date.
    - date_time_end: Same ISO format, or null.
    - timezone: IANA timezone (e.g. "America/Los_Angeles" for PST, "America/New_York" for EST). Not "PST" or "EST".

    Args:
        host_email: Email of the host (ask the user for this).
        host_name: Name of the host.
        title: Event title.
        tagline: One line to hype it up (e.g. "Let's have some good food!", "Game night with friends").
        date_time: Start time in ISO 8601 format: "YYYY-MM-DDTHH:MM:SS".
        location: Event location/address.
        date_time_end: Optional end time in ISO format, or null.
        timezone: IANA timezone (e.g. "America/Los_Angeles"). Default "UTC".
        carpool_enabled: Enable carpool coordination.
        potluck_enabled: Enable potluck sign-up.
        attendee_limit: Max attendees (optional).
        frontend_base_url: Base URL for links (e.g. https://checkdin.online).
    """
    payload = {
        "title": title,
        "activity": tagline,
        "date_time": date_time,
        "date_time_end": date_time_end,
        "location": location,
        "host_email": host_email,
        "host_name": host_name,
        "timezone": timezone,
        "carpool_enabled": carpool_enabled,
        "potluck_enabled": potluck_enabled,
    }
    if attendee_limit is not None:
        payload["attendee_limit"] = attendee_limit
    ev = _api("/events", method="POST", json=payload)

    # Build full URLs (API returns paths like /e/slug/invite/token)
    host_link = ev.get("host_magic_link") or ""
    view_link = ev.get("event_view_link") or ""
    if host_link.startswith("/"):
        host_link = f"{frontend_base_url.rstrip('/')}{host_link}"
    if view_link.startswith("/"):
        view_link = f"{frontend_base_url.rstrip('/')}{view_link}"

    # Generate calendar links (host uses host link in description)
    desc = f"You are hosting this event. Access event here: {host_link}"
    cal_ev = {
        "title": ev.get("title", title),
        "start_iso": ev.get("date_time", date_time),
        "end_iso": ev.get("date_time_end") or ev.get("date_time", date_time_end or date_time),
        "location": ev.get("location", location),
        "description": desc,
    }
    google_url = google_calendar_url(**cal_ev)
    outlook_cal_url = outlook_url(**cal_ev)
    ics_content = generate_ics(**cal_ev)

    # Extract invite_token from host_magic_link (e.g. "/e/slug/invite/TOKEN") for update_event
    host_path = ev.get("host_magic_link") or ""
    invite_token = host_path.split("/invite/")[-1] if "/invite/" in host_path else None

    return {
        "event_id": ev.get("id"),
        "invite_token": invite_token,
        "title": ev.get("title"),
        "host_link": host_link,
        "view_link": view_link,
        "calendar": {
            "google_calendar_url": google_url,
            "outlook_url": outlook_cal_url,
            "ics_content": ics_content,
        },
    }


@mcp.tool()
def update_event(
    event_id: str,
    invite_token: str,
    title: str | None = None,
    tagline: str | None = None,
    date_time: str | None = None,
    date_time_end: str | None = None,
    location: str | None = None,
    timezone: str | None = None,
    carpool_enabled: bool | None = None,
    potluck_enabled: bool | None = None,
    dress_code: str | None = None,
    subcategory: str | None = None,
    additional_details: str | None = None,
    attendee_limit: int | None = None,
    allow_forwarding: bool | None = None,
) -> dict:
    """
    Update an event. Only include fields you want to change.

    Requires invite_token from create_event response (host link contains it).
    IMPORTANT: date_time and date_time_end must be ISO 8601 "YYYY-MM-DDTHH:MM:SS" if provided.

    Args:
        event_id: The event ID.
        invite_token: From create_event response (needed for host/cohost auth).
        title: New title (optional).
        tagline: New one-line hype / tagline (optional).
        date_time: New start time in ISO format (optional).
        date_time_end: New end time in ISO format (optional).
        location: New location (optional).
        timezone: New IANA timezone (optional).
        carpool_enabled: Enable/disable carpool (optional).
        potluck_enabled: Enable/disable potluck (optional).
        dress_code: Dress code text (optional).
        subcategory: Subcategory (optional).
        additional_details: Notes for guests (optional).
        attendee_limit: Max attendees (optional).
        allow_forwarding: Allow guests to forward invite (optional).
    """
    payload = {}
    if title is not None:
        payload["title"] = title
    if tagline is not None:
        payload["activity"] = tagline
    if date_time is not None:
        payload["date_time"] = date_time
    if date_time_end is not None:
        payload["date_time_end"] = date_time_end
    if location is not None:
        payload["location"] = location
    if timezone is not None:
        payload["timezone"] = timezone
    if carpool_enabled is not None:
        payload["carpool_enabled"] = carpool_enabled
    if potluck_enabled is not None:
        payload["potluck_enabled"] = potluck_enabled
    if dress_code is not None:
        payload["dress_code"] = dress_code
    if subcategory is not None:
        payload["subcategory"] = subcategory
    if additional_details is not None:
        payload["additional_details"] = additional_details
    if attendee_limit is not None:
        payload["attendee_limit"] = attendee_limit
    if allow_forwarding is not None:
        payload["allow_forwarding"] = allow_forwarding
    if not payload:
        return {"message": "No fields to update"}
    return _api(
        f"/events/{event_id}?invite_token={quote(invite_token, safe='')}",
        method="PATCH",
        json=payload,
    )


@mcp.tool()
def add_invitee(
    event_id: str,
    email: str,
    name: str,
    is_cohost: bool = False,
    frontend_base_url: str = "https://checkdin.online",
) -> dict:
    """
    Add an invitee to an event and get their personal magic link.

    Args:
        event_id: The event ID (from create_event).
        email: Guest's email.
        name: Guest's name.
        is_cohost: If true, they can manage the event like the host.
        frontend_base_url: Base URL for the magic link.
    """
    payload = {"email": email, "name": name, "is_cohost": is_cohost}
    inv = _api(f"/invites/{event_id}/invitees", method="POST", json=payload)
    magic_link = inv.get("magic_link") or ""
    if magic_link.startswith("/"):
        magic_link = f"{frontend_base_url.rstrip('/')}{magic_link}"
    return {
        "invitee_id": inv.get("id"),
        "email": email,
        "name": name,
        "magic_link": magic_link,
    }


@mcp.tool()
def add_potluck_item(event_id: str, item_name: str, item_type: str = "food", claimed_by: str = "Unclaimed") -> dict:
    """
    Add an item to the potluck list for an event.

    Args:
        event_id: The event ID.
        item_name: Name of the item (e.g. "Lasagna", "Chips").
        item_type: One of "food", "games", "other".
        claimed_by: Name of the person bringing it. Use "Unclaimed" if no one has signed up yet.
    """
    payload = {"item_name": item_name, "item_type": item_type, "claimed_by": claimed_by or "Unclaimed"}
    return _api(f"/events/{event_id}/potluck", method="POST", json=payload)


@mcp.tool()
def list_potluck_items(event_id: str) -> list:
    """List all potluck items for an event."""
    return _api(f"/events/{event_id}/potluck")


@mcp.tool()
def list_rsvps(event_id: str) -> list:
    """List all RSVPs for an event. Use this to find the host's RSVP id when offering a carpool."""
    return _api(f"/events/{event_id}/rsvps")


@mcp.tool()
def offer_carpool(
    event_id: str,
    driver_rsvp_id: str,
    capacity: int = 2,
    meet_time: str | None = None,
    meet_type: str = "carpool_spot",
    meet_address: str | None = None,
) -> dict:
    """
    Offer a carpool (host offers to drive). The driver must have RSVP'd to the event.

    To get driver_rsvp_id: call list_rsvps(event_id) and find the RSVP where email matches the host.

    Args:
        event_id: The event ID.
        driver_rsvp_id: The host's RSVP id (from list_rsvps).
        capacity: Number of seats available for riders.
        meet_time: When to meet (ISO format).
        meet_type: "carpool_spot" (meet at a location) or "pickup_from_rider" (pick up at their address).
        meet_address: Address for carpool_spot (required if meet_type is carpool_spot).
    """
    payload = {
        "driver_rsvp_id": driver_rsvp_id,
        "capacity": capacity,
        "meet_time": meet_time,
        "meet_type": meet_type,
        "meet_address": meet_address,
    }
    return _api(f"/events/{event_id}/carpools", method="POST", json=payload)


@mcp.tool()
def list_carpools(event_id: str, viewer_rsvp_id: str | None = None) -> list:
    """List all carpools for an event. Pass viewer_rsvp_id to see rider addresses when you're the driver."""
    path = f"/events/{event_id}/carpools"
    if viewer_rsvp_id:
        path += f"?viewer_rsvp_id={viewer_rsvp_id}"
    return _api(path)


@mcp.tool()
def update_carpool(
    event_id: str,
    carpool_id: str,
    driver_rsvp_id: str,
    capacity: int | None = None,
    meet_time: str | None = None,
    meet_type: str | None = None,
    meet_address: str | None = None,
) -> dict:
    """
    Update a carpool. Only the driver can update. Use list_carpools to get carpool_id; use list_rsvps to get driver_rsvp_id.

    Args:
        event_id: The event ID.
        carpool_id: The carpool ID (from list_carpools).
        driver_rsvp_id: The driver's RSVP id (required for auth).
        capacity: New seat count (optional). Cannot be less than seats already taken.
        meet_time: New meet time in ISO format (optional).
        meet_type: "carpool_spot" or "pickup_from_rider" (optional).
        meet_address: New meet address (optional).
    """
    payload: dict = {"driver_rsvp_id": driver_rsvp_id}
    if capacity is not None:
        payload["capacity"] = capacity
    if meet_time is not None:
        payload["meet_time"] = meet_time
    if meet_type is not None:
        payload["meet_type"] = meet_type
    if meet_address is not None:
        payload["meet_address"] = meet_address
    if len(payload) <= 1:
        return {"message": "No fields to update"}
    return _api(f"/events/{event_id}/carpools/{carpool_id}", method="PATCH", json=payload)


@mcp.tool()
def cancel_carpool(event_id: str, carpool_id: str, driver_rsvp_id: str) -> dict:
    """
    Cancel a carpool. Only the driver can cancel. Riders are notified via the event activity feed.

    Args:
        event_id: The event ID.
        carpool_id: The carpool ID (from list_carpools).
        driver_rsvp_id: The driver's RSVP id (required for auth).
    """
    path = f"/events/{event_id}/carpools/{carpool_id}?driver_rsvp_id={quote(driver_rsvp_id, safe='')}"
    return _api(path, method="DELETE")


@mcp.tool()
def add_schedule_stop(
    event_id: str,
    title: str,
    location: str,
    date_time: str,
    date_time_end: str | None = None,
) -> dict:
    """
    Add a stop to the event schedule (e.g. "Dinner at Joe's", "Coffee before the hike").
    Use list_schedule_stops first to see existing stops and avoid overlaps.

    IMPORTANT: Convert date/time to ISO 8601 before calling (same as create_event).
    - date_time: ISO format "YYYY-MM-DDTHH:MM:SS" (e.g. "2026-03-14T19:00:00"). Convert "March 14 at 7pm", "6pm" etc. to this format.
    - date_time_end: Same ISO format, or null.

    Args:
        event_id: The event ID (from create_event).
        title: What this stop is (e.g. "Dinner", "Coffee break").
        location: Where (e.g. "Joe's Pizza", "Main Street Cafe").
        date_time: When in ISO format "YYYY-MM-DDTHH:MM:SS".
        date_time_end: Optional end time in ISO format, or null.
    """
    payload = {
        "title": title.strip(),
        "location": location.strip(),
        "date_time": date_time,
        "date_time_end": date_time_end,
    }
    return _api(f"/events/{event_id}/subevents", method="POST", json=payload)


@mcp.tool()
def list_schedule_stops(event_id: str) -> list:
    """List all schedule stops (subevents) for an event. Use this before adding stops to see the current schedule."""
    return _api(f"/events/{event_id}/subevents")


@mcp.tool()
def broadcast_message(event_id: str, message: str, author_name: str | None = None) -> dict:
    """
    Broadcast a message to all guests for an event. The message appears in the event's activity feed.

    Args:
        event_id: The event ID.
        message: The message to send (e.g. "Dinner is moved to 8pm!", "Don't forget to bring a dish").
        author_name: Optional name to show as the sender (e.g. "Harpreet"). If omitted, may show as generic host.
    """
    payload = {"message": message.strip(), "author_name": author_name or ""}
    return _api(f"/events/{event_id}/activity", method="POST", json=payload)


@mcp.tool()
def cancel_event(event_id: str, message: str | None = None) -> dict:
    """
    Cancel an event. Guests will see the event as cancelled. Use this when the event is no longer happening.

    Args:
        event_id: The event ID.
        message: Optional message to show guests (e.g. "Sorry, we need to reschedule").
    """
    payload = {"message": message.strip()} if message and message.strip() else {}
    return _api(f"/events/{event_id}/cancel", method="PATCH", json=payload)


def run():
    """Run the MCP server. Uses stdio transport for Claude Desktop."""
    mcp.run(transport="stdio")
