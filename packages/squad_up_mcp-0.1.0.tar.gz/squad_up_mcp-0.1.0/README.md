# Squad Up MCP Server

<!-- mcp-name: io.github.hrandhawa02/squad_up -->

An MCP (Model Context Protocol) server that exposes Squad Up's event planning capabilities to AI assistants like Claude. Users can create events, add invitees, manage potlucks and carpools, and get calendar links—all through natural language.

## What is MCP?

**Model Context Protocol** is a standard way for AI assistants to connect to external tools. Think of it like this:

- **You (Squad Up)** build an MCP **server** that exposes "tools" (create_event, add_invitee, etc.)
- **Claude** is the MCP **client**—it discovers your tools and calls them when the user asks
- The user says "Create a potluck for Saturday" → Claude calls your `create_event` tool → your server talks to the Squad Up API → Claude tells the user the result

## Quick Start

```bash
cd mcp-server
uv sync
SQUAD_UP_API_URL=http://localhost:8000/api uv run python -m squad_up_mcp
```

## Configuration

| Env Var | Description | Default |
|---------|-------------|---------|
| `SQUAD_UP_API_URL` | Base URL of your Squad Up API (e.g. `http://localhost:8000/api` or `https://api.checkdin.online`) | `http://localhost:8000/api` |

## Testing Locally

1. Start your Squad Up backend: `cd backend && uv run uvicorn app.main:app --reload --port 8000`
2. Run the MCP server: `cd mcp-server && SQUAD_UP_API_URL=http://localhost:8000/api uv run python -m squad_up_mcp`
3. Add to Claude Desktop config (see MCP_SERVER_GUIDE.md)

## Publishing to MCP Registry

See MCP_SERVER_GUIDE.md for the full walkthrough.
