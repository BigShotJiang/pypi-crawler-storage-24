"""Testes unitários para a funcionalidade Xray (list_test_set_tests).

Cobre:
- JiraClient.list_test_set_tests (camada HTTP)
- _handle_xray_list_test_set_tests (camada tools/handler)
- Integração via call_tool
"""

import json
from unittest.mock import MagicMock, PropertyMock, patch

import pytest
import requests

from mcp_jira.jira_client import (
    JiraClient,
    JiraError,
    JiraValidationError,
)
from mcp_jira.tools import _handle_xray_list_test_set_tests


# --- Helpers ---


def _make_response(
    status_code: int = 200,
    json_data=None,
    text: str = "",
) -> MagicMock:
    """Cria mock de requests.Response com .ok funcional."""
    resp = MagicMock(spec=requests.Response)
    resp.status_code = status_code
    resp.text = text
    resp.json.return_value = json_data if json_data is not None else {}
    resp.headers = {"Content-Type": "application/json"}
    # .ok é property em requests.Response; precisamos mockar explicitamente
    type(resp).ok = PropertyMock(return_value=(status_code < 400))
    return resp


def _make_client() -> JiraClient:
    return JiraClient("https://jira.example.com", "dGVzdDoxMjM=")


# =====================================================================
# JiraClient.list_test_set_tests
# =====================================================================


class TestListTestSetTests:
    """Testes do método JiraClient.list_test_set_tests."""

    @patch("mcp_jira.jira_client.requests.request")
    def test_success_returns_key_summary_status(self, mock_request):
        """Cenário feliz: API retorna lista de test cases."""
        mock_request.return_value = _make_response(
            json_data=[
                {"key": "PKWT-3594", "summary": "Teste upload PDF", "status": "PASS"},
                {"key": "PKWT-3595", "summary": "Teste upload DOC", "status": "FAIL"},
            ]
        )
        client = _make_client()
        result = client.list_test_set_tests("PKWT-3593")

        assert len(result) == 2
        assert result[0] == {"key": "PKWT-3594", "summary": "Teste upload PDF", "status": "PASS"}
        assert result[1] == {"key": "PKWT-3595", "summary": "Teste upload DOC", "status": "FAIL"}

        # Verifica URL chamada
        call_args = mock_request.call_args
        assert "/rest/raven/1.0/api/testset/PKWT-3593/test" in call_args.args[1]

    @patch("mcp_jira.jira_client.requests.request")
    def test_empty_list(self, mock_request):
        """API retorna lista vazia (test set sem test cases)."""
        mock_request.return_value = _make_response(json_data=[])
        client = _make_client()
        result = client.list_test_set_tests("PKWT-0001")
        assert result == []

    @patch("mcp_jira.jira_client.requests.request")
    def test_missing_fields_default_to_empty_string(self, mock_request):
        """Test cases com campos ausentes devem retornar string vazia."""
        mock_request.return_value = _make_response(
            json_data=[
                {"key": "PKWT-100"},  # sem summary nem status
                {"summary": "Sem key", "status": "TODO"},  # sem key
            ]
        )
        client = _make_client()
        result = client.list_test_set_tests("PKWT-3593")

        assert result[0] == {"key": "PKWT-100", "summary": "", "status": ""}
        assert result[1] == {"key": "", "summary": "Sem key", "status": "TODO"}

    @patch("mcp_jira.jira_client.requests.request")
    def test_404_raises_jira_error(self, mock_request):
        """Test Set não encontrado deve levantar JiraError."""
        mock_request.return_value = _make_response(status_code=404, text="Not Found")
        client = _make_client()
        with pytest.raises(JiraError, match="não encontrado.*404"):
            client.list_test_set_tests("PKWT-9999")

    @patch("mcp_jira.jira_client.requests.request")
    def test_500_triggers_fallback(self, mock_request):
        """Erro 500 do Xray deve acionar fallback via campo customizado."""
        # 1ª chamada: Xray retorna 500
        xray_resp = _make_response(
            status_code=500,
            text='{"status-code":500,"stack-trace":"NullPointerException"}',
        )
        # 2ª chamada: get_issue (fallback)
        issue_resp = _make_response(json_data={
            "key": "PKWT-3593",
            "names": {"customfield_99999": "Tests association with a Test Set"},
            "fields": {
                "summary": "Test Set",
                "status": {"name": "Open"},
                "priority": {"name": "Trivial"},
                "issuetype": {"name": "Test Set"},
                "customfield_99999": "PKWT-3594, PKWT-3595",
            },
        })
        # 3ª chamada: search_issues (batch JQL)
        search_resp = _make_response(json_data={
            "issues": [
                {"key": "PKWT-3594", "fields": {"summary": "Upload PDF", "status": {"name": "PASS"}}},
                {"key": "PKWT-3595", "fields": {"summary": "Upload DOC", "status": {"name": "FAIL"}}},
            ],
            "total": 2,
        })
        mock_request.side_effect = [xray_resp, issue_resp, search_resp]
        client = _make_client()
        result = client.list_test_set_tests("PKWT-3593")

        assert len(result) == 2
        assert result[0]["key"] == "PKWT-3594"
        assert result[0]["summary"] == "Upload PDF"
        assert result[1]["key"] == "PKWT-3595"

    @patch("mcp_jira.jira_client.requests.request")
    def test_500_fallback_empty_association(self, mock_request):
        """Fallback com campo de associação vazio retorna lista vazia."""
        xray_resp = _make_response(status_code=500, text="error")
        issue_resp = _make_response(json_data={
            "key": "PKWT-0001",
            "names": {},
            "fields": {
                "summary": "Empty Set",
                "status": {"name": "Open"},
                "priority": {"name": "Trivial"},
                "issuetype": {"name": "Test Set"},
            },
        })
        mock_request.side_effect = [xray_resp, issue_resp]
        client = _make_client()
        result = client.list_test_set_tests("PKWT-0001")
        assert result == []

    def test_empty_key_raises_validation_error(self):
        """Chave vazia deve levantar JiraValidationError."""
        client = _make_client()
        with pytest.raises(JiraValidationError, match="obrigatório"):
            client.list_test_set_tests("")

    @patch("mcp_jira.jira_client.requests.request")
    def test_uses_get_method(self, mock_request):
        """Deve usar GET na chamada HTTP."""
        mock_request.return_value = _make_response(json_data=[])
        client = _make_client()
        client.list_test_set_tests("PKWT-3593")
        assert mock_request.call_args.args[0] == "GET"


# =====================================================================
# _handle_xray_list_test_set_tests (handler da tool)
# =====================================================================


class TestHandleXrayListTestSetTests:
    """Testes do handler em tools.py."""

    def test_success(self):
        client = MagicMock()
        client.list_test_set_tests.return_value = [
            {"key": "PKWT-3594", "summary": "Upload PDF", "status": "PASS"},
        ]
        result = _handle_xray_list_test_set_tests(client, {"testSetKey": "PKWT-3593"})
        data = json.loads(result[0].text)
        assert len(data) == 1
        assert data[0]["key"] == "PKWT-3594"
        client.list_test_set_tests.assert_called_once_with(test_set_key="PKWT-3593")

    def test_missing_key_raises_validation_error(self):
        client = MagicMock()
        with pytest.raises(JiraValidationError, match="testSetKey"):
            _handle_xray_list_test_set_tests(client, {})

    def test_empty_key_raises_validation_error(self):
        client = MagicMock()
        with pytest.raises(JiraValidationError, match="testSetKey"):
            _handle_xray_list_test_set_tests(client, {"testSetKey": ""})

    def test_propagates_jira_error(self):
        client = MagicMock()
        client.list_test_set_tests.side_effect = JiraError("Erro 500 do Xray")
        with pytest.raises(JiraError, match="500"):
            _handle_xray_list_test_set_tests(client, {"testSetKey": "PKWT-3593"})

    def test_empty_result(self):
        client = MagicMock()
        client.list_test_set_tests.return_value = []
        result = _handle_xray_list_test_set_tests(client, {"testSetKey": "PKWT-0001"})
        data = json.loads(result[0].text)
        assert data == []


# =====================================================================
# Integração via call_tool
# =====================================================================


class TestXrayCallToolIntegration:
    """Testa o fluxo completo via call_tool do MCP Server."""

    @pytest.fixture
    def app_and_client(self):
        from mcp.server import Server
        from mcp_jira.tools import register_tools

        app = Server("test-jira")
        client = MagicMock()
        register_tools(app, client)
        return app, client

    def _get_call_tool_handler(self, app):
        from mcp.types import CallToolRequest
        return app.request_handlers[CallToolRequest]

    def _make_request(self, name, arguments):
        from mcp.types import CallToolRequest, CallToolRequestParams
        return CallToolRequest(
            method="tools/call",
            params=CallToolRequestParams(name=name, arguments=arguments),
        )

    @pytest.mark.asyncio
    async def test_success_via_call_tool(self, app_and_client):
        app, client = app_and_client
        client.list_test_set_tests.return_value = [
            {"key": "PKWT-3594", "summary": "Test A", "status": "PASS"},
        ]
        handler = self._get_call_tool_handler(app)
        req = self._make_request("jira_xray_list_test_set_tests", {"testSetKey": "PKWT-3593"})
        result = await handler(req)
        assert result.root.isError is False
        data = json.loads(result.root.content[0].text)
        assert data[0]["key"] == "PKWT-3594"

    @pytest.mark.asyncio
    async def test_validation_error_via_call_tool(self, app_and_client):
        app, client = app_and_client
        handler = self._get_call_tool_handler(app)
        req = self._make_request("jira_xray_list_test_set_tests", {"testSetKey": ""})
        result = await handler(req)
        assert result.root.isError is True
        assert "testSetKey" in result.root.content[0].text

    @pytest.mark.asyncio
    async def test_server_error_via_call_tool(self, app_and_client):
        app, client = app_and_client
        client.list_test_set_tests.side_effect = JiraError(
            "Erro ao buscar test cases do Test Set PKWT-3593: 500 - NullPointerException"
        )
        handler = self._get_call_tool_handler(app)
        req = self._make_request("jira_xray_list_test_set_tests", {"testSetKey": "PKWT-3593"})
        result = await handler(req)
        assert result.root.isError is True
        assert "500" in result.root.content[0].text
