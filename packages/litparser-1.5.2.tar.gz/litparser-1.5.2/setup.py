from setuptools import setup, find_packages

setup(
    name="litparser",
    version="1.5.2",
    description="⚠️ Moved to GitHub. Install: pip install git+https://github.com/ironwung/litparser.git",
    long_description="""
# LitParser

## ⚠️ 이 패키지는 더 이상 PyPI에서 배포되지 않습니다.

최신 버전은 GitHub 저장소에서 직접 설치하세요:

```bash
pip uninstall litparser
pip install git+https://github.com/ironwung/litparser.git
```

## 설치 (Private 저장소)

GitHub Personal Access Token이 필요합니다:

```bash
pip install git+https://<YOUR_TOKEN>@github.com/ironwung/litparser.git
```

## 링크

- GitHub: [github.com/ironwung/litparser](https://github.com/ironwung/litparser)
- 문의: ironwung@gmail.com
""",
    long_description_content_type="text/markdown",
    author="ironwung",
    author_email="ironwung@gmail.com",
    url="https://github.com/ironwung/litparser",
    license="AGPL-3.0-or-later",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[],
    classifiers=[
        "Development Status :: 7 - Inactive",
        "License :: OSI Approved :: GNU Affero General Public License v3 or later (AGPLv3+)",
    ],
)
