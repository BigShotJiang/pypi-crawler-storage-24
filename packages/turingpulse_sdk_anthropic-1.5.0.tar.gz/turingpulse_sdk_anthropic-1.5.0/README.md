# turingpulse-sdk-anthropic

TuringPulse SDK integration for Anthropic — automatic tracing for Claude 3.5 and Claude 3 models.

## Installation

```bash
pip install turingpulse-sdk-anthropic
```

## Quick Start

```python
from anthropic import Anthropic
from turingpulse_sdk import init, TuringPulseConfig
from turingpulse_sdk_anthropic import patch_anthropic

init(TuringPulseConfig(api_key="sk_live_...", workflow_name="my-project"))
patch_anthropic(name="my-project")

client = Anthropic()
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Hello!"}]
)
```

## Documentation

Full documentation: [turingpulse.ai/docs/sdk/anthropic](https://turingpulse.ai/docs/sdk/anthropic)

## Requirements

- Python >= 3.11
- turingpulse-sdk >= 1.0.0
- anthropic >= 0.79.0
