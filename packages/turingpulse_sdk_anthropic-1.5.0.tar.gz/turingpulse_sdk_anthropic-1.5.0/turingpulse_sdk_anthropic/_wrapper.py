"""Anthropic monkey-patch instrumentation for TuringPulse."""

from __future__ import annotations

import logging
import os
from contextvars import ContextVar
from typing import Any, Optional

from turingpulse_sdk import instrument, GovernanceDirective
from turingpulse_sdk.config import MAX_FIELD_SIZE
from turingpulse_sdk.context import current_context
from turingpulse_sdk.exceptions import ConfigurationError

logger = logging.getLogger("turingpulse.sdk.anthropic")

_INSTRUMENTING: ContextVar[bool] = ContextVar("_tp_anthropic_instrumenting", default=False)

_ORIGINAL_CREATE: Any = None
_ORIGINAL_ACREATE: Any = None


def patch_anthropic(
    *,
    name: str | None = None,
    governance: Optional[GovernanceDirective] = None,
) -> None:
    """Monkey-patch ``anthropic.resources.messages.Messages.create``."""
    global _ORIGINAL_CREATE, _ORIGINAL_ACREATE

    effective_name = name or os.getenv("TP_WORKFLOW_NAME", "")
    if not effective_name:
        raise ConfigurationError(
            "patch_anthropic() requires name= or TP_WORKFLOW_NAME to be set."
        )

    try:
        from anthropic.resources.messages import Messages, AsyncMessages
    except ImportError as exc:
        raise ImportError("anthropic package is required: pip install anthropic>=0.79.0") from exc

    if _ORIGINAL_CREATE is not None:
        logger.warning("Anthropic is already patched — skipping")
        return

    _ORIGINAL_CREATE = Messages.create
    _ORIGINAL_ACREATE = AsyncMessages.create

    @instrument(name=effective_name, governance=governance)
    def _patched_create(self_messages, *args: Any, **kwargs: Any) -> Any:
        if _INSTRUMENTING.get(False):
            return _ORIGINAL_CREATE(self_messages, *args, **kwargs)
        token = _INSTRUMENTING.set(True)
        try:
            response = _ORIGINAL_CREATE(self_messages, *args, **kwargs)
            _record_anthropic_span(response, kwargs)
            return response
        finally:
            _INSTRUMENTING.reset(token)

    @instrument(name=effective_name, governance=governance)
    async def _patched_acreate(self_messages, *args: Any, **kwargs: Any) -> Any:
        if _INSTRUMENTING.get(False):
            return await _ORIGINAL_ACREATE(self_messages, *args, **kwargs)
        token = _INSTRUMENTING.set(True)
        try:
            response = await _ORIGINAL_ACREATE(self_messages, *args, **kwargs)
            _record_anthropic_span(response, kwargs)
            return response
        finally:
            _INSTRUMENTING.reset(token)

    Messages.create = _patched_create
    AsyncMessages.create = _patched_acreate
    logger.info("Anthropic patched for TuringPulse instrumentation")


def unpatch_anthropic() -> None:
    """Restore original Anthropic methods."""
    global _ORIGINAL_CREATE, _ORIGINAL_ACREATE
    if _ORIGINAL_CREATE is None:
        return
    try:
        from anthropic.resources.messages import Messages, AsyncMessages
        Messages.create = _ORIGINAL_CREATE
        AsyncMessages.create = _ORIGINAL_ACREATE
    except ImportError:
        pass
    _ORIGINAL_CREATE = None
    _ORIGINAL_ACREATE = None
    logger.info("Anthropic unpatched — original methods restored")


def _record_anthropic_span(response: Any, kwargs: dict) -> None:
    ctx = current_context()
    if not ctx:
        return
    ctx.framework = "anthropic"
    ctx.node_type = "llm"

    usage = getattr(response, "usage", None)
    if usage:
        ctx.set_tokens(
            getattr(usage, "input_tokens", 0) or 0,
            getattr(usage, "output_tokens", 0) or 0,
        )

    ctx.set_model(getattr(response, "model", kwargs.get("model", "unknown")), "anthropic")

    messages = kwargs.get("messages", [])
    if messages:
        last_user = next((m for m in reversed(messages) if m.get("role") == "user"), None)
        system = kwargs.get("system")
        if last_user:
            ctx.set_prompt(
                str(last_user.get("content", ""))[:MAX_FIELD_SIZE],
                system_prompt=str(system)[:MAX_FIELD_SIZE] if system else None,
            )

    tools_def = kwargs.get("tools")
    if tools_def:
        tool_names = []
        for t in tools_def:
            tname = t.get("name") if isinstance(t, dict) else getattr(t, "name", None)
            if tname:
                tool_names.append(tname)
        if tool_names:
            ctx.available_tools = tool_names

    content = getattr(response, "content", [])
    if content:
        texts = [getattr(b, "text", "") for b in content if getattr(b, "type", "") == "text"]
        if texts:
            ctx.set_io(output_data="\n".join(texts)[:MAX_FIELD_SIZE])

        for block in content:
            if getattr(block, "type", "") == "tool_use":
                ctx.add_tool_call(
                    tool_name=getattr(block, "name", "unknown"),
                    tool_args=getattr(block, "input", {}),
                    tool_id=getattr(block, "id", None),
                )
