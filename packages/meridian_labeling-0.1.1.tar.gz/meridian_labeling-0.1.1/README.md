# meridian-labeling

`meridian-labeling` is a minimal Python package scaffold for Meridian label-generation and labeling-runtime work.

## Current Scope

- publishes a namespaced package so downstream repos can depend on a stable artifact
- documents the placeholder authority boundary for future label rendering and formatting code
- provides local quality checks and CI so release and publish automation can run cleanly

## Package Surface

- import `meridian_labeling`
- inspect `meridian_labeling.__version__`
- call `meridian_labeling.package_summary()` for the current scaffold description

## Development

```bash
pip install -e ".[dev]"
pre-commit run --all-files
pytest
python -m build
```

This repo is intentionally small today. Replace the placeholder implementation when label layout, rendering, or print-runtime code lands here.

<!-- release-sweep: 2026-03-10 -->
