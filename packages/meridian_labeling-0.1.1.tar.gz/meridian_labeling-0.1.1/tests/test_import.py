from meridian_labeling import __version__, package_summary


def test_import_smoke() -> None:
    assert __version__ == "0.1.1"
    assert "labeling scaffold" in package_summary().lower()
