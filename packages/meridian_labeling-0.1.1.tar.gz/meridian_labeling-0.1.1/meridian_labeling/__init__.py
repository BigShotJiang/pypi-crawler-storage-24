"""Minimal Meridian labeling package scaffold."""

__version__ = "0.1.1"


def package_summary() -> str:
    """Return the current scope of the package."""
    return "Minimal Meridian labeling scaffold for future label-generation work."
