from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path
from datetime import datetime


def setup_logging(data_root: Path = Path("data")) -> None:
    """
    Configure logging for the entire synciflow system.
    Writes to:
        data/logs/synciflow.log          — current log (rotating)
        data/logs/errors.log             — errors only
        console                          — INFO and above
    """
    logs_dir = data_root / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    fmt = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)

    # ── Main rotating file — all levels ──────────────────────────────
    # Rotates at 10 MB, keeps last 5 files
    main_handler = logging.handlers.RotatingFileHandler(
        filename=logs_dir / "synciflow.log",
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    main_handler.setLevel(logging.DEBUG)
    main_handler.setFormatter(fmt)

    # ── Errors-only file ─────────────────────────────────────────────
    error_handler = logging.handlers.RotatingFileHandler(
        filename=logs_dir / "errors.log",
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(fmt)

    # ── Console — INFO and above ──────────────────────────────────────
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(fmt)

    root.addHandler(main_handler)
    root.addHandler(error_handler)
    root.addHandler(console_handler)

    # Silence noisy third-party loggers
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)

    logging.getLogger("synciflow").info(
        "Logging initialized — writing to %s", logs_dir.resolve()
    )