from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path



#---------------------------------------------------------------------------
# Track delete limits (to prevent abuse of the delete endpoint) 
#---------------------------------------------------------------------------

# Set to False to disable the track delete limit entirely (no limit).
ENFORCE_TRACK_DELETE_LIMIT: bool = True  # disable entirely

# Maximum number of track deletes allowed per user within a 24h period.    
USER_MAX_TRACK_DELETES: int = 10          # change the limit

#---------------------------------------------------------------------------
# Scheduler constants   
#---------------------------------------------------------------------------

# Master on/off switch for the scheduler (cleanup thread, etc.).
ENABLE_SCHEDULER: bool = True              # master on/off switch
# Interval in seconds for the scheduler to wake up and run tasks.
SCHEDULER_INTERVAL_SECONDS: int = 4*60*60 # wake up every 4 hours
# Expiry times for cleanup tasks (delete old users, tracks, etc.).
USER_EXPIRY_SECONDS: int = 24*60*60        # delete users older than 24h
# Expiry time for tracks (delete tracks older than 24h).
TRACK_EXPIRY_SECONDS: int = 3*60*60       # delete tracks older than 3h

# ---------------------------------------------------------------------------
# SpotAPI constants
# ---------------------------------------------------------------------------

# Maximum number of tracks to collect from a Spotify playlist.
# 0 = no limit (load the entire playlist).
SPOTAPI_MAX_LIMIT: int = 2


#---------------------------------------------------------------------------
# JWT & password hashing constants
ACCESS_TOKEN_EXPIRE_MINUTES_CONFIG: str = "60"
# Number of days until a refresh token expires.
REFRESH_TOKEN_EXPIRE_DAYS_CONFIG: str = "3"


# ---------------------------------------------------------------------------
# Per-user storage quota constants
# ---------------------------------------------------------------------------

# Set to False to disable the quota check entirely (no size enforcement).
# Set to True to enforce USER_STORAGE_LIMIT_BYTES per user.
ENFORCE_USER_STORAGE_LIMIT: bool = True

# Maximum total bytes allowed in a single user's tracks directory.
# Default: 15 MB
USER_STORAGE_LIMIT_BYTES: int = 15 * 1024 * 1024

#----------------------------------------------------------------------------
# ZIP download option
#----------------------------------------------------------------------------

# Set to False to disable all ZIP downloads (playlist export, etc.).
ENABLE_ZIP_DOWNLOAD: bool = False   # set False to disable all ZIP downloads

# ---------------------------------------------------------------------------
# App configuration
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class AppConfig:
    """
    App-wide configuration (paths + runtime options).

    Storage quota is controlled by the module-level constants above
    (ENFORCE_USER_STORAGE_LIMIT, USER_STORAGE_LIMIT_BYTES) so it can be
    toggled with a single line change without touching AppConfig instances.
    """

    storage_root: Path = Path("storage_data")
    data_root: Path = Path("data")

    @property
    def db_path(self) -> Path:
        return self.data_root / "synciflow.sqlite3"

    def user_storage_root(self, user_id: int) -> Path:
        """
        Return the storage root for a specific user.

        Layout:
            storage_data/users/<user_id>/tracks/
            storage_data/users/<user_id>/playlists/
            storage_data/users/<user_id>/tmp/
        """
        return self.storage_root / "users" / str(user_id)