from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy import UniqueConstraint
from sqlmodel import Field, SQLModel


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def utcnow() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# User
# ---------------------------------------------------------------------------

class User(SQLModel, table=True):
    """Registered user account."""

    id: Optional[int] = Field(default=None, primary_key=True)
    username: str = Field(index=True, unique=True, max_length=50)
    email: str = Field(index=True, unique=True, max_length=255)
    hashed_password: str
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=utcnow)

    # Lifetime count of tracks this user has deleted.
    # Incremented by TrackManager.delete_track() on each successful delete.
    # Checked against USER_MAX_TRACK_DELETES when ENFORCE_TRACK_DELETE_LIMIT=True.
    track_deletes: int = Field(default=0)
# ---------------------------------------------------------------------------
# Track
# ---------------------------------------------------------------------------

class Track(SQLModel, table=True):
    """
    A single audio track downloaded from Spotify/YouTube.

    Primary key is a surrogate auto-increment integer (`id`).
    The Spotify track ID (`track_id`) is only unique *per user* — two users
    can each own a copy of the same Spotify track.
    The composite unique constraint `(track_id, user_id)` enforces this.
    """

    __table_args__ = (
        UniqueConstraint("track_id", "user_id", name="uq_track_user"),
    )

    # Surrogate PK — never exposed to the client
    id: Optional[int] = Field(default=None, primary_key=True)

    # Spotify track identifier — NOT globally unique (two users can share one)
    track_id: str = Field(index=True)

    # Owner — nullable so pre-auth rows are not broken; always set in practice
    user_id: Optional[int] = Field(default=None, foreign_key="user.id", index=True)

    spotify_url: str = Field(default="")
    track_title: Optional[str] = Field(default=None)
    artist_title: Optional[str] = Field(default=None)
    track_image_url: Optional[str] = Field(default=None)
    duration_ms: Optional[int] = Field(default=None)
    duration_str: Optional[str] = Field(default=None)
    audio_path: Optional[str] = Field(default=None)
    downloaded_at: Optional[datetime] = Field(default=None)
    created_at: datetime = Field(default_factory=utcnow)


# ---------------------------------------------------------------------------
# Playlist
# ---------------------------------------------------------------------------

class Playlist(SQLModel, table=True):
    """
    A Spotify playlist (or the likes pseudo-playlist) stored locally.

    Same surrogate-PK pattern as Track.
    The composite unique constraint `(playlist_id, user_id)` lets two users
    each own a copy of the same Spotify playlist without collision.
    """

    __table_args__ = (
        UniqueConstraint("playlist_id", "user_id", name="uq_playlist_user"),
    )

    # Surrogate PK
    id: Optional[int] = Field(default=None, primary_key=True)

    # Spotify playlist identifier — NOT globally unique
    playlist_id: str = Field(index=True)

    # Owner
    user_id: Optional[int] = Field(default=None, foreign_key="user.id", index=True)

    playlist_url: str = Field(default="")
    title: Optional[str] = Field(default=None)
    playlist_image_url: Optional[str] = Field(default=None)
    last_synced_at: Optional[datetime] = Field(default=None)
    created_at: datetime = Field(default_factory=utcnow)


# ---------------------------------------------------------------------------
# PlaylistTrack  (join table)
# ---------------------------------------------------------------------------

class PlaylistTrack(SQLModel, table=True):
    """
    Ordered relation between a Playlist and a Track.

    Both FKs point to the surrogate integer PKs of their parent tables,
    NOT to the Spotify string IDs.  This is required because `playlist.id`
    and `track.id` are the actual primary keys after the surrogate-PK refactor.

    The composite unique constraint `(playlist_db_id, track_db_id)` prevents
    a track appearing twice in the same playlist.
    """

    __table_args__ = (
        UniqueConstraint("playlist_db_id", "track_db_id", name="uq_playlisttrack"),
    )

    # Surrogate PK
    id: Optional[int] = Field(default=None, primary_key=True)

    # FK → Playlist.id  (surrogate integer PK)
    playlist_db_id: int = Field(foreign_key="playlist.id", index=True)

    # FK → Track.id  (surrogate integer PK)
    track_db_id: int = Field(foreign_key="track.id", index=True)

    position: int = Field(default=0, nullable=False)


# ---------------------------------------------------------------------------
# Job
# ---------------------------------------------------------------------------

class Job(SQLModel, table=True):
    """Background job record for tracking async operations."""

    # Surrogate PK
    id: Optional[int] = Field(default=None, primary_key=True)

    # Public-facing job identifier (UUID string)
    job_id: str = Field(index=True, unique=True)

    # Owner — nullable so legacy rows are not broken
    user_id: Optional[int] = Field(default=None, foreign_key="user.id", index=True)

    job_type: str
    status: str = Field(default="pending")   # pending | running | completed | failed
    progress: float = Field(default=0.0)
    message: Optional[str] = Field(default=None)
    created_at: datetime = Field(default_factory=utcnow)
    updated_at: datetime = Field(default_factory=utcnow)