from __future__ import annotations

import time
import uuid

from sqlalchemy.exc import OperationalError, PendingRollbackError
from sqlmodel import Session, select

from synciflow.db.models import Job, utcnow


import logging
LOG = logging.getLogger("synciflow.core")

def _commit_with_retry(session: Session, attempts: int = 8, base_sleep_s: float = 0.05) -> None:
    """
    SQLite allows only one writer at a time. When background jobs update progress while
    other writes are happening, commits can fail with 'database is locked'.
    Retry with a small backoff instead of crashing the job runner.
    """
    for i in range(attempts):
        try:
            session.commit()
            return
        except PendingRollbackError:
            session.rollback()
        except OperationalError as e:
            msg = str(e).lower()
            if "database is locked" not in msg and "database locked" not in msg:
                raise
            session.rollback()
            time.sleep(base_sleep_s * (2**i))
    session.commit()


def create_job(session: Session, job_type: str, user_id: int) -> Job:
    """
    Create a new job with status 'pending', scoped to *user_id*.
    Returns the Job with job_id set.
    """
    job_id = str(uuid.uuid4())
    job = Job(
        job_id=job_id,
        job_type=job_type,
        status="pending",
        progress=0.0,
        message=None,
        user_id=user_id,          # ← user scope
    )
    session.add(job)
    _commit_with_retry(session)
    session.refresh(job)
    return job


def update_job_progress(
    session: Session,
    job_id: str,
    progress: float,
    message: str | None = None,
) -> None:
    """Update job progress and optional message. Sets status to 'running' if still pending."""
    job = session.exec(select(Job).where(Job.job_id == job_id)).first()
    if job is None:
        return
    job.progress = progress
    if message is not None:
        job.message = message
    if job.status == "pending":
        job.status = "running"
    job.updated_at = utcnow()
    session.add(job)
    _commit_with_retry(session)


def complete_job(session: Session, job_id: str) -> None:
    """Mark job as completed (status='completed', progress=1.0)."""
    job = session.exec(select(Job).where(Job.job_id == job_id)).first()
    if job is None:
        return
    job.status = "completed"
    job.progress = 1.0
    job.updated_at = utcnow()
    session.add(job)
    _commit_with_retry(session)


def fail_job(session: Session, job_id: str, message: str | None = None) -> None:
    """Mark job as failed. Optional message for error details."""
    job = session.exec(select(Job).where(Job.job_id == job_id)).first()
    if job is None:
        return
    job.status = "failed"
    if message is not None:
        job.message = message
    job.updated_at = utcnow()
    session.add(job)
    _commit_with_retry(session)


def get_job(session: Session, job_id: str, user_id: int | None = None) -> Job | None:
    """
    Fetch a job by job_id.
    If *user_id* is provided the query also filters by owner — prevents one user
    from polling another user's job.
    """
    stmt = select(Job).where(Job.job_id == job_id)
    if user_id is not None:
        stmt = stmt.where(Job.user_id == user_id)
    return session.exec(stmt).first()


def list_jobs(
    session: Session,
    user_id: int,
    status: str | None = None,
    limit: int = 50,
) -> list[Job]:
    """
    Return jobs for *user_id*, optionally filtered by *status*,
    ordered newest-first, capped at *limit*.
    """
    stmt = select(Job).where(Job.user_id == user_id).order_by(Job.created_at.desc()).limit(limit)
    if status:
        stmt = stmt.where(Job.status == status)
    return list(session.exec(stmt).all())