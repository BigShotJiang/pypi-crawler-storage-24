from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable
import logging
from sqlmodel import Session, select
from pathlib import Path
from sqlmodel import delete as sql_delete
from synciflow.config import ENFORCE_TRACK_DELETE_LIMIT, USER_MAX_TRACK_DELETES
from synciflow.db.models import PlaylistTrack, Track, User
from synciflow.schemas.track import TrackDetails
from synciflow.services import downloader as downloader_service
from synciflow.services import spotify_client
from synciflow.services.tagging import ensure_cover_art
from synciflow.storage.file_manager import FileManager, StorageQuotaExceeded  # noqa: F401 re-export

from .utils import extract_spotify_id

LOG = logging.getLogger("synciflow.core")


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------
 
class TrackDeleteLimitExceeded(Exception):
    """
    Raised when a user has used all their allowed track deletions.
 
    Attributes
    ----------
    used  : deletes already performed by this user
    limit : USER_MAX_TRACK_DELETES from config
    """
 
    def __init__(self, used: int, limit: int) -> None:
        self.used = used
        self.limit = limit
        super().__init__(
            f"Track delete limit reached: {used}/{limit} deletes used. "
            f"No more tracks can be deleted from this account."
        )
 
 # ---------------------------------------------------------------------------
# Manager
# ---------------------------------------------------------------------------
 

@dataclass(frozen=True)
class TrackManager:
    session: Session
    files: FileManager
    user_id: int

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_track(self, track_id: str) -> Track | None:
        return self.session.exec(
            select(Track)
            .where(Track.track_id == track_id)
            .where(Track.user_id == self.user_id)
        ).first()
    
    def _get_user(self) -> User | None:
        """Fetch the User row for the current user_id."""
        return self.session.exec(
            select(User).where(User.id == self.user_id)
        ).first()
 
    def _check_storage_quota(self) -> None:
        """Raise StorageQuotaExceeded if the user's tracks dir is full."""
        self.files.check_storage_quota()
    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def _check_delete_quota(self) -> None:
        """
        Raise TrackDeleteLimitExceeded if the user has reached
        USER_MAX_TRACK_DELETES.
 
        No-op when ENFORCE_TRACK_DELETE_LIMIT = False in config.
        """
        if not ENFORCE_TRACK_DELETE_LIMIT:
            return
        user = self._get_user()
        if user is None:
            return
        if user.track_deletes >= USER_MAX_TRACK_DELETES:
            raise TrackDeleteLimitExceeded(
                used=user.track_deletes,
                limit=USER_MAX_TRACK_DELETES,
            )
        
    def load_track(
        self,
        spotify_url: str,
        progress_callback: Callable[[str], None] | None = None,
    ) -> Track:
        """
        Load (and download if needed) a track from a Spotify URL.

        Quota logic
        -----------
        - If the audio file already exists on disk → return it immediately,
          no quota check (nothing new is written).
        - If the file needs to be downloaded → call
          ``self.files.check_storage_quota()`` first.  This reads the
          module-level constants ENFORCE_USER_STORAGE_LIMIT and
          USER_STORAGE_LIMIT_BYTES from config and raises
          ``StorageQuotaExceeded`` when the tracks dir is full.
        """
        track_id_from_url = extract_spotify_id(spotify_url, "track")

        existing: Track | None = None
        if track_id_from_url:
            existing = self._get_track(track_id_from_url)

        details: TrackDetails | None = None

        if existing is None:
            details = spotify_client.get_track_details(spotify_url)
            track_id = details.track_id or track_id_from_url
            if not track_id:
                raise ValueError("Could not determine track_id from Spotify URL/details.")
            existing = Track(
                track_id=track_id,
                spotify_url=details.spotify_url or spotify_url,
                track_title=details.track_title,
                artist_title=details.artist_title,
                track_image_url=details.track_image_url,
                duration_ms=details.duration_ms,
                duration_str=details.duration_str,
                user_id=self.user_id,
            )
            self.session.add(existing)
            self.session.commit()
            self.session.refresh(existing)
        else:
            track_id = existing.track_id

        # Audio already on disk — sync the DB path and return.
        # No quota check: we are not downloading anything new.
        if self.files.exists(track_id):
            audio_path_path = self.files.audio_path(track_id)
            audio_path_str = str(audio_path_path)
            if existing.audio_path != audio_path_str:
                existing.audio_path = audio_path_str
                if existing.downloaded_at is None:
                    existing.downloaded_at = datetime.now(timezone.utc)

            if not existing.track_image_url or not existing.track_title or not existing.artist_title:
                details = spotify_client.get_track_details(existing.spotify_url)
                if not existing.track_title and details.track_title:
                    existing.track_title = details.track_title
                if not existing.artist_title and details.artist_title:
                    existing.artist_title = details.artist_title
                if not existing.track_image_url and details.track_image_url:
                    existing.track_image_url = details.track_image_url

            self.session.add(existing)
            self.session.commit()
            self.session.refresh(existing)
            ensure_cover_art(audio_path_path, existing.track_image_url)
            return existing

        # ── Quota check — before any download ────────────────────────────
        # Raises StorageQuotaExceeded if the user's tracks dir is full.
        # No-op when ENFORCE_USER_STORAGE_LIMIT = False in config.
        self.files.check_storage_quota()

        if details is None:
            details = spotify_client.get_track_details(spotify_url)

        if not existing.track_title and details.track_title:
            existing.track_title = details.track_title
        if not existing.artist_title and details.artist_title:
            existing.artist_title = details.artist_title
        if not existing.track_image_url and details.track_image_url:
            existing.track_image_url = details.track_image_url

        if progress_callback is not None:
            progress_callback("started")

        result = downloader_service.download_track_to_tmp(details, self.files)
        final_path = self.files.atomic_move_to_library(track_id, result.tmp_mp3_path)

        existing.audio_path = str(final_path)
        existing.downloaded_at = datetime.now(timezone.utc)
        self.session.add(existing)
        self.session.commit()
        self.session.refresh(existing)

        ensure_cover_art(final_path, existing.track_image_url)
        if progress_callback is not None:
            progress_callback("completed")
        return existing

    def load_local(self, track_id: str) -> Track:
        """Local-first load — no download, no quota check."""
        audio_path = self.files.audio_path(track_id)
        if not audio_path.exists():
            raise ValueError(
                f"Local audio file not found for track_id={track_id} (user={self.user_id})"
            )

        track = self._get_track(track_id)
        if track is None:
            track = Track(
                track_id=track_id,
                spotify_url="",
                track_title="",
                artist_title="",
                track_image_url="",
                duration_ms=0,
                duration_str="",
                audio_path=str(audio_path),
                downloaded_at=datetime.now(timezone.utc),
                user_id=self.user_id,
            )
            self.session.add(track)
        else:
            updated = False
            if track.audio_path != str(audio_path):
                track.audio_path = str(audio_path)
                updated = True
            if track.downloaded_at is None:
                track.downloaded_at = datetime.now(timezone.utc)
                updated = True
            if updated:
                self.session.add(track)

        self.session.commit()
        self.session.refresh(track)
        ensure_cover_art(audio_path, track.track_image_url)
        return track

    def list_tracks(self) -> list[Track]:
        return list(
            self.session.exec(
                select(Track).where(Track.user_id == self.user_id)
            ).all()
        )

        
    def delete_track(self, track_id: str) -> dict:
        """
        Permanently delete a track owned by the current user.
 
        Delete limit logic
        ------------------
        When ENFORCE_TRACK_DELETE_LIMIT = True (config.py):
          - Checks User.track_deletes against USER_MAX_TRACK_DELETES BEFORE
            doing any work.  Raises TrackDeleteLimitExceeded if exhausted.
          - On success, increments User.track_deletes by 1.
 
        Steps
        -----
        1. Check delete quota (raises TrackDeleteLimitExceeded if over limit).
        2. Verify track exists and belongs to this user (raises ValueError if not).
        3. Remove all PlaylistTrack relations via surrogate track.id.
        4. Delete the audio file from disk.
        5. Delete the Track DB row.
        6. Increment User.track_deletes.
 
        Returns
        -------
        dict with track_id, audio_removed, deletes_used, deletes_remaining.
        """
        # 1. Delete quota check — before any work
        self._check_delete_quota()
 
        # 2. Verify ownership
        track = self._get_track(track_id)
        if track is None:
            raise ValueError(f"Track not found: {track_id} (user={self.user_id})")
 
        # 3. Remove PlaylistTrack relations
        self.session.exec(
            sql_delete(PlaylistTrack).where(PlaylistTrack.track_db_id == track.id)
        )
 
        # 4. Delete audio file from disk
        audio_removed = False
        if track.audio_path:
            audio_file = Path(track.audio_path)
            if audio_file.exists():
                try:
                    audio_file.unlink()
                    audio_removed = True
                    LOG.info("Deleted audio file: %s", audio_file)
                except OSError as exc:
                    LOG.warning("Could not delete audio file %s: %s", audio_file, exc)
 
        # 5. Delete Track row
        self.session.delete(track)
        self.session.commit()
 
        # 6. Increment User.track_deletes
        user = self._get_user()
        if user is not None:
            user.track_deletes += 1
            self.session.add(user)
            self.session.commit()
 
        used = user.track_deletes if user else 0
        remaining = (
            max(0, USER_MAX_TRACK_DELETES - used)
            if ENFORCE_TRACK_DELETE_LIMIT else None
        )
 
        LOG.info(
            "Deleted track %s for user %s — deletes used: %s/%s",
            track_id, self.user_id, used,
            USER_MAX_TRACK_DELETES if ENFORCE_TRACK_DELETE_LIMIT else "unlimited",
        )
 
        return {
            "track_id": track_id,
            "audio_removed": audio_removed,
            "message": "Track deleted successfully",
            "deletes_used": used,
            "deletes_remaining": remaining,
        }
 
    def list_tracks(self) -> list[Track]:
        """Return all tracks owned by the current user."""
        return list(
            self.session.exec(
                select(Track).where(Track.user_id == self.user_id)
            ).all()
        )