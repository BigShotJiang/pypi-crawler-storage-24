from __future__ import annotations

import uuid
import zipfile
from pathlib import Path
from typing import Iterable, Tuple

from .file_manager import FileManager
from .path_manager import ensure_parent_dir
from synciflow.config import ENABLE_ZIP_DOWNLOAD
import logging
LOG = logging.getLogger("synciflow.storage.zip_builder")

def build_playlist_zip(
    files: FileManager,
    playlist_id: str,
    track_files: Iterable[Tuple[int, str, str, Path]],
) -> Path:
    """
    Build a ZIP file for the given playlist_id containing the provided track files.

    track_files is an iterable of (position, track_id, display_name, audio_path).
    `display_name` should be a sanitized base filename without extension.
    The ZIP is written into a unique temp file and the final path is returned.

    When ENABLE_ZIP_DOWNLOAD is False (set in config.py), returns an empty ZIP
    named "Download disabled.zip" regardless of the track_files supplied.
    """
    zip_path = files.storage.tmp_dir / "zips" / f"{playlist_id}-{uuid.uuid4().hex}.zip"
    ensure_parent_dir(zip_path)

    if not ENABLE_ZIP_DOWNLOAD:
        # Create a clearly named empty ZIP so the caller still gets a valid file path.
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(
                "Download disabled.txt",
                "ZIP downloads are currently disabled by the server administrator.",
            )
        # Rename to a descriptive filename so it's obvious when opened.
        disabled_path = zip_path.parent / "Download disabled.zip"
        ensure_parent_dir(disabled_path)
        zip_path.replace(disabled_path)
        return disabled_path

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for position, track_id, display_name, audio_path in track_files:
            if not audio_path.exists():
                continue
            suffix = audio_path.suffix or ".mp3"
            arcname = f"{position:03d}-{display_name}{suffix}"
            zf.write(str(audio_path), arcname)

    return zip_path