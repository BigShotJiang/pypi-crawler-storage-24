from __future__ import annotations

import re
from typing import Any, Dict, List

from synciflow.config import SPOTAPI_MAX_LIMIT
from synciflow.schemas.playlist import PlaylistDetails
from synciflow.schemas.track import TrackDetails, _ms_to_duration_str

from spotapi.playlist import PublicPlaylist
from spotapi.song import Song
import logging
LOG = logging.getLogger("synciflow.services.spotify_client")
_SPOTIFY_TRACK_RE = re.compile(r"(?:spotify:track:|/track/)([A-Za-z0-9]+)")
_SPOTIFY_PLAYLIST_RE = re.compile(r"(?:spotify:playlist:|/playlist/)([A-Za-z0-9]+)")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _extract_spotify_id(url: str, kind: str) -> str:
    if not url:
        return ""
    m = (_SPOTIFY_TRACK_RE if kind == "track" else _SPOTIFY_PLAYLIST_RE).search(url)
    return m.group(1) if m else ""


def _make_spotify_track_url(track_id: str) -> str:
    return f"https://open.spotify.com/track/{track_id}" if track_id else ""


def _extract_track_artist(track: Dict[str, Any]) -> str:
    for key in ("firstArtist", "otherArtists"):
        obj = track.get(key) or {}
        if isinstance(obj, dict):
            items = obj.get("items") or []
            if items and isinstance(items[0], dict):
                name = (items[0].get("profile") or {}).get("name")
                if name:
                    return str(name)
    return ""


def _extract_track_image_url(track: Dict[str, Any]) -> str:
    # Prefer album cover art
    sources = (
        ((track.get("albumOfTrack") or {}).get("coverArt") or {}).get("sources") or []
    )
    if isinstance(sources, list) and sources:
        url = sources[0].get("url") if isinstance(sources[0], dict) else None
        if url:
            return str(url)
    # Fallback to visual identity
    sources = (
        ((track.get("visualIdentity") or {}).get("squareCoverImage") or {}).get("sources") or []
    )
    if isinstance(sources, list) and sources:
        url = sources[0].get("url") if isinstance(sources[0], dict) else None
        if url:
            return str(url)
    return ""


def _extract_playlist_image_url(playlist_data: Dict[str, Any]) -> str:
    if not isinstance(playlist_data, dict):
        return ""
    items = (playlist_data.get("images") or {}).get("items") or []
    if isinstance(items, list) and items and isinstance(items[0], dict):
        sources = items[0].get("sources") or []
        if isinstance(sources, list) and sources and isinstance(sources[0], dict):
            return str(sources[0].get("url") or "")
    return ""


# ---------------------------------------------------------------------------
# Track
# ---------------------------------------------------------------------------

def get_track_details(spotify_track_url: str) -> TrackDetails:
    track_id = _extract_spotify_id(spotify_track_url, "track")
    if not track_id:
        raise ValueError(f"Could not extract track id from '{spotify_track_url}'")

    try:
        resp = Song().get_track_info(track_id)
    except Exception as exc:
        raise RuntimeError(f"Failed to load Spotify track details: {exc}") from exc

    track = (resp.get("data", {}) or {}).get("trackUnion", {}) or {}
    spotify_url = (
        (track.get("sharingInfo") or {}).get("shareUrl")
        or _make_spotify_track_url(track.get("uri") or track.get("id") or track_id)
        or spotify_track_url
    )
    duration_ms = int((track.get("duration") or {}).get("totalMilliseconds") or 0)

    return TrackDetails(
        spotify_url=str(spotify_url or ""),
        track_id=str(track.get("id") or track_id or ""),
        track_title=str(track.get("name") or ""),
        artist_title=_extract_track_artist(track),
        track_image_url=_extract_track_image_url(track),
        duration_ms=duration_ms,
        duration_str=_ms_to_duration_str(duration_ms),
    )


# ---------------------------------------------------------------------------
# Playlist
# ---------------------------------------------------------------------------

def get_playlist_details(
    spotify_playlist_url: str,
    track_limit: int = SPOTAPI_MAX_LIMIT,
) -> PlaylistDetails:
    """
    Fetch Spotify playlist metadata and its track URLs via SpotAPI.

    Parameters
    ----------
    spotify_playlist_url:
        Full Spotify playlist URL.
    track_limit:
        Maximum number of tracks to collect.
        ``0`` means no limit — collect all tracks.
        Sourced from ``AppConfig.playlist_track_limit``.
    spotapi_page_size:
        How many tracks SpotAPI requests from Spotify per HTTP call.
        Sourced from ``AppConfig.spotapi_page_size``.
        Always capped at ``SPOTAPI_MAX_LIMIT`` (imported from config).

    How the two values interact
    ---------------------------
    ``spotapi_page_size`` controls the network page size.
    It is capped at ``SPOTAPI_MAX_LIMIT`` because Spotify's internal
    API refuses larger values.

    When ``track_limit`` is set we use
    ``min(track_limit, effective_page_size)`` as the initial page size
    so the very first SpotAPI call doesn't over-fetch (e.g. limit=10
    → first page requests 10, not 100).

    ``paginate_playlist()`` streams subsequent pages; we break out of
    the generator as soon as ``track_limit`` tracks have been collected.
    """
    playlist_id = _extract_spotify_id(spotify_playlist_url, "playlist")

    # Enforce the hard ceiling from the Spotify internal API
    #effective_page_size = min(spotapi_page_size, SPOTAPI_MAX_LIMIT)

    # Shrink the initial page when track_limit is smaller than a full page
    #initial_page = (
    #    min(track_limit, effective_page_size) if track_limit > 0 else effective_page_size
    #)

    try:
        playlist = PublicPlaylist(spotify_playlist_url)
        info = playlist.get_playlist_info(limit=track_limit)
    except Exception as exc:
        raise RuntimeError(f"Failed to load Spotify playlist details: {exc}") from exc

    playlist_data = (info.get("data", {}) or {}).get("playlistV2", {}) or {}
    title = str(playlist_data.get("name") or "")
    image_url = _extract_playlist_image_url(playlist_data)

    track_urls: List[str] = []
    try:
        for chunk in playlist.paginate_playlist():
            items = chunk.get("items") or []
            for item in items:
                track = (item.get("itemV2", {}) or {}).get("data", {}) or {}
                uri = track.get("uri") or track.get("id") or ""
                if not uri:
                    continue
                track_id = _extract_spotify_id(uri, "track")
                if not track_id and uri.startswith("spotify:track:"):
                    track_id = uri.split("spotify:track:")[-1]
                if not track_id:
                    continue

                track_urls.append(_make_spotify_track_url(track_id))

                # Stop collecting once track_limit is reached
                if track_limit > 0 and len(track_urls) >= track_limit:
                    break

            # Break the outer page loop too
            if track_limit > 0 and len(track_urls) >= track_limit:
                break

    except Exception:
        # Best-effort — continue with whatever was collected so far
        pass

    return PlaylistDetails(
        playlist_url=str(
            getattr(playlist, "playlist_link", spotify_playlist_url) or spotify_playlist_url
        ),
        playlist_id=str(playlist_id or ""),
        title=title,
        playlist_image_url=image_url,
        track_urls=track_urls,
    )


# ---------------------------------------------------------------------------
# Likes  (requires browser-based Spotify login via syncify)
# ---------------------------------------------------------------------------

def get_likes_details(
    login_timeout: int = 120,
    page_load_timeout: int = 30,
    scroll_pause: float = 2.0,
    track_limit: int = 0,
) -> PlaylistDetails:
    """
    Fetch the current user's Spotify Liked Songs.

    ``track_limit`` caps how many liked tracks are returned (0 = no limit).
    ``spotapi_page_size`` controls the per-request page limit (max SPOTAPI_MAX_LIMIT).
    """
    return PlaylistDetails(
        playlist_url="",
        playlist_id="",
        title="",
        playlist_image_url="",
        track_urls=[],
    )