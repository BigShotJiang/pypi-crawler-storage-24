from __future__ import annotations

from pathlib import Path
from typing import Optional
import mimetypes
import urllib.request

from mutagen.id3 import APIC, ID3NoHeaderError
from mutagen.mp3 import MP3
import logging
LOG = logging.getLogger("synciflow.services.tagging")

def _guess_mime_type_from_url(url: str) -> str:
    mime, _ = mimetypes.guess_type(url)
    return mime or "image/jpeg"


def ensure_cover_art(mp3_path: Path, image_url: Optional[str]) -> Path:
    """
    Ensure that the given MP3 file has embedded cover art.

    - If image_url is falsy, the file is returned unchanged.
    - If the file already has an APIC frame, it is returned unchanged.
    - Otherwise, the image is downloaded and embedded as an APIC frame.
    """
    if not image_url:
        return mp3_path

    if not mp3_path.exists():
        return mp3_path

    try:
        # Load the MP3 with ID3 support so we can inspect and modify tags.
        audio = MP3(mp3_path)
    except Exception:
        return mp3_path

    # If there are already APIC frames, leave as-is.
    try:
        tags = audio.tags
        if tags is not None and any(key.startswith("APIC") for key in tags.keys()):
            return mp3_path
    except ID3NoHeaderError:
        tags = None

    if tags is None:
        try:
            audio.add_tags()
        except Exception:
            # If tags still cannot be added, bail out.
            return mp3_path
        tags = audio.tags

    try:
        with urllib.request.urlopen(image_url) as resp:
            image_data = resp.read()
            mime = resp.headers.get_content_type() or _guess_mime_type_from_url(image_url)
    except Exception:
        return mp3_path

    try:
        tags.add(
            APIC(
                encoding=3,
                mime=mime,
                type=3,
                desc="Cover",
                data=image_data,
            )
        )
        # Save tags back to the file; v2.3 is widely supported.
        audio.save(v2_version=3)
    except Exception:
        return mp3_path

    return mp3_path

