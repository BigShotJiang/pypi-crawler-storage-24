"""
auth/dependencies.py
FastAPI dependency that validates the Bearer JWT and returns the current user.

Inject `current_user: User = Depends(get_current_user)` in any protected route.
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from sqlmodel import Session, select

from synciflow.auth.config import decode_token
from synciflow.db.database import get_session          # your existing session dep
from synciflow.db.models import User

bearer_scheme = HTTPBearer(auto_error=True)

import logging
LOG = logging.getLogger("synciflow.auth")

CREDENTIALS_EXCEPTION = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="Could not validate credentials",
    headers={"WWW-Authenticate": "Bearer"},
)


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    session: Session = Depends(get_session),
) -> User:
    """
    Extract the JWT from the Authorization header, validate it, and
    return the corresponding User row.  Raises 401 on any failure.
    """
    token = credentials.credentials
    try:
        payload = decode_token(token)
        if payload.get("type") != "access":
            raise CREDENTIALS_EXCEPTION
        username: str = payload.get("sub")
        if username is None:
            raise CREDENTIALS_EXCEPTION
    except JWTError:
        raise CREDENTIALS_EXCEPTION

    user = session.exec(select(User).where(User.username == username)).first()
    if user is None or not user.is_active:
        raise CREDENTIALS_EXCEPTION
    return user


def get_current_active_user(
    current_user: User = Depends(get_current_user),
) -> User:
    """Alias – convenience dep that also checks is_active (already done above)."""
    return current_user
