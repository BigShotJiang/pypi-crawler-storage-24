from typing import Any, Dict

import httpx

from ariadne_graphql_proxy.cache import (
    CacheBackend,
    CacheSerializer,
    JSONCacheSerializer,
)


class CloudflareCacheError(Exception):
    def __init__(self, response: httpx.Response) -> None:
        self.response = response
        msg = (
            "Namespace can't be accessed.\n"
            f"url: {response.url}\n"
            f"status: {response.status_code}\n"
            f"content: {response.content!r}"
        )
        super().__init__(msg)


class CloudflareCacheBackend(CacheBackend):
    def __init__(
        self,
        account_id: str,
        namespace_id: str,
        headers: Dict[str, str] | None = None,
        base_url: str = "https://api.cloudflare.com/client/v4",
        serializer: CacheSerializer | None = None,
    ) -> None:
        super().__init__(serializer or JSONCacheSerializer())

        self.base_url = base_url
        self.account_id = account_id
        self.namespace_id = namespace_id
        self.headers = headers or {}

        self._assert_namespace_can_be_accessed()

    def _assert_namespace_can_be_accessed(self):
        with httpx.Client(base_url=self.base_url, headers=self.headers) as client:
            response = client.get(
                f"accounts/{self.account_id}/"
                f"storage/kv/namespaces/{self.namespace_id}/keys"
            )

        if not response.is_success or not response.json().get("success", False):
            raise CloudflareCacheError(response)

    async def set(self, key: str, value: Any, ttl: int | None = None):
        async with httpx.AsyncClient(
            base_url=self.base_url, headers=self.headers
        ) as client:
            await client.put(
                f"accounts/{self.account_id}/"
                f"storage/kv/namespaces/{self.namespace_id}/"
                f"values/{key}",
                files={"value": self.serializer.serialize(value), "metadata": "{}"},
                params={"expiration_ttl": ttl} if ttl is not None else {},
            )

    async def get(self, key: str, default: Any = None) -> Any:
        async with httpx.AsyncClient(
            base_url=self.base_url, headers=self.headers
        ) as client:
            response = await client.get(
                f"accounts/{self.account_id}/"
                f"storage/kv/namespaces/{self.namespace_id}/"
                f"values/{key}",
            )

        if response.is_success:
            return self.serializer.deserialize(response.content.decode())

        return default

    async def clear_all(self):
        pass
