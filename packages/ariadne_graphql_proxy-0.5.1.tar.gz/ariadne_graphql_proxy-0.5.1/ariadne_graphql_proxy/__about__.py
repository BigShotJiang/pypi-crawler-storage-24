__version__ = "0.5.1"  # This is overwritten by Hatch in CI/CD, don't change it.
