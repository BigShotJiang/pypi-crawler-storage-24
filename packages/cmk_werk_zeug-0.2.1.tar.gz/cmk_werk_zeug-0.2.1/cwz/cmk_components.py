#!/usr/bin/env python3

"""Checkmk-code-owners CLI
* [Brainstorming document](https://docs.google.com/document/d/1Yul9GjAIkJBowWhvIzwRFFtK-GIZfdTKMSllEzF4Juw)
* [Component Matrix Owners File Implementation](https://jira.lan.tribe29.com/browse/CMK-24954)
* [Component Ownership at Checkmk](https://docs.google.com/document/d/11pbv5J6VjdbuwDTUqBLTP2SqWsd5C1AXjgdpfjZupCM)
* [code-owners / REST API](https://android-review.googlesource.com/plugins/code-owners/Documentation/rest-api.html)
"""

# Insights we want to get:
# - what components do exist?
# - who's in charge of a component
# - what files/directories belong to a component
# - how do the provided ownership infos reflect the 'reality' reported by 'git blame'?
# - what components am I owner for?
# - what files am I responsible for?
# - check OWNERS files with per-file only for `set noparent`
# - check for redundant (nested) information
# - consistency checks:
#   - components in OWNERS files match components in component_owners/
#   - safe names consistent with display names

# Fix this before next release:
# - consequent naming (owners, leads, members)
# - text, json or human suitable output

import asyncio
import json
import logging
import sys
import time
from argparse import ArgumentParser
from argparse import Namespace as Args
from collections.abc import Sequence
from contextlib import ExitStack, suppress
from itertools import count
from pathlib import Path
from typing import ClassVar, ParamSpec

import vcr  # type: ignore[import-untyped]
import yaml
from aiohttp import ClientResponseError
from rich import print as rich_print
from rich import traceback
from textual import on, work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.events import Click, Key
from textual.suggester import SuggestFromList
from textual.widgets import Header, Input, Label, Tree
from trickkiste.base_tui_app import TuiBaseApp
from trickkiste.logging_helper import apply_common_logging_cli_args, setup_logging
from trickkiste.misc import awatch_duration, process_output

from . import __version__
from .gerrit_utils.client import (
    CodeOwnersClient,
    Component,
    GerritClient,
    apply_code_owner_cli_args,
    with_gerrit_client,
)

ArgumentsP = ParamSpec("ArgumentsP")


def parse_arguments(args: Sequence[str]) -> Args:
    """parse command line arguments and return argument object"""

    parser = ArgumentParser(
        "cmk-components",
        description="Provides information about components and code owners",
    )

    apply_common_logging_cli_args(parser)
    # apply_common_gerrit_cli_args(parser)  # fixme(frans): either unify or consequent implementation
    apply_code_owner_cli_args(parser)

    parser.add_argument(
        "--cache-file",
        type=Path,
        help="Store retrieved information in a local cache file (YAML)",
    )

    parser.set_defaults(func=_fn_tui)

    subparsers = parser.add_subparsers(help="available commands", metavar="CMD")

    parser_tui = subparsers.add_parser("tui", help="Start a TUI (default)")
    parser_tui.set_defaults(func=_fn_tui)

    def add_common_args(parser: ArgumentParser) -> None:
        parser.add_argument("-v", "--verbose", action="store_true")
        parser.add_argument(
            "--mode",
            type=str,
            choices=["rich", "json", "script"],
            default="rich" if sys.stdout.isatty() else "script",
            help="Output mode",
        )

    # ls / list
    parser_list = subparsers.add_parser(
        "list",
        aliases=["ls"],
        help="List components",
    )
    parser_list.set_defaults(func=_fn_list)
    add_common_args(parser_list)

    # info
    parser_info = subparsers.add_parser(
        "info",
        help="retrieve all available information about components",
    )
    parser_info.set_defaults(func=_fn_info)
    parser_info.add_argument("entities", type=str, nargs="*", metavar="COMPONENT")
    add_common_args(parser_info)

    # members
    parser_component_owners_and_members = subparsers.add_parser(
        "members",
        help="[COMPONENT ..] Show members of COMPONENT*",
    )
    parser_component_owners_and_members.set_defaults(func=_fn_component_owners_and_members)
    parser_component_owners_and_members.add_argument(
        "entities", type=str, nargs="*", metavar="COMPONENT"
    )
    add_common_args(parser_component_owners_and_members)

    # paths
    parser_component_paths = subparsers.add_parser(
        "paths",
        help="[COMPONENT ..] Show code-location paths of COMPONENT*",
    )
    parser_component_paths.set_defaults(func=_fn_component_paths)
    parser_component_paths.add_argument("entities", type=str, nargs="+", metavar="COMPONENT")
    add_common_args(parser_component_paths)

    # owners
    parser_owners_for = subparsers.add_parser(
        "owners",
        aliases=[],
        help="[PATH ..] Show code owners for PATH*",
    )
    parser_owners_for.set_defaults(func=_fn_owners_for)
    parser_owners_for.add_argument("entities", type=str, nargs="+", metavar="PATH")
    add_common_args(parser_owners_for)

    # component
    parser_component_for_path = subparsers.add_parser(
        "component",
        aliases=[],
        help="[PATH ..] Show component for PATH*",
    )
    parser_component_for_path.set_defaults(func=_fn_component_for_path)
    parser_component_for_path.add_argument("entities", type=str, nargs="+", metavar="PATH")
    add_common_args(parser_component_for_path)

    # config-files
    parser_all_code_owners_config_files = subparsers.add_parser(
        "config-files",
        aliases=[],
        help="List all owners config files",
    )
    parser_all_code_owners_config_files.set_defaults(func=_fn_all_code_owners_config_files)
    add_common_args(parser_all_code_owners_config_files)

    parser_validate_config = subparsers.add_parser("validate-config")
    parser_validate_config.set_defaults(func=_fn_validate_config)

    # These have no help text -> don't show up in console help text (intentionally)

    parser_config = subparsers.add_parser("config")
    parser_config.set_defaults(func=_fn_config)
    add_common_args(parser_config)
    parser_config.add_argument("entities", type=str, nargs="*", metavar="PATH")

    # restricted access
    parser_check_config = subparsers.add_parser("check-config")
    parser_check_config.set_defaults(func=_fn_check_config)

    # reference and debug only (will vanish)
    parser_stuff = subparsers.add_parser("stuff")
    parser_stuff.set_defaults(func=_fn_stuff)

    return parser.parse_args(args)


class FatalError(RuntimeError):
    """Fatal error during execution"""


class GerritObjectsEncoder(json.JSONEncoder):
    def default(self, obj: object) -> object:
        if isinstance(obj, Component):
            return obj.model_dump()
        return super().default(obj)


@with_gerrit_client()
async def _fn_list(
    cli_args: Args,
    gerrit_client: GerritClient,  # noqa: ARG001 Unused function argument
    owners_client: CodeOwnersClient,
) -> None:
    """Do what a 'list' command is expected to do without further information.
    Currently: List all components known to the code-owners plugin
    """
    component_info = await owners_client.all_components_info()
    if cli_args.mode == "json":
        json.dump(list(component_info.keys()), sys.stdout, cls=GerritObjectsEncoder, indent=2)
    elif cli_args.mode == "script":
        sys.stdout.write("\n".join(component_info.keys()))
    else:  # rich
        for name, details in component_info.items():
            rich_print(  # fixme(frans): cleanup
                f"[default][bold cyan]{name}[/] / {(details.description or '').split('\n')[0].strip(' -')}[/]"
            )


@with_gerrit_client()
async def _fn_info(
    cli_args: Args,
    gerrit_client: GerritClient,  # noqa: ARG001 Unused function argument
    owners_client: CodeOwnersClient,
) -> None:
    """`info` command implementation"""
    all_component_info = await owners_client.all_components_info()
    if bad_keys := (set(cli_args.entities) - set(all_component_info)):
        raise FatalError(f"Unknown components: {', '.join(bad_keys)}")

    component_info = {
        component_id: component.model_dump()
        for component_id, component in all_component_info.items()
        if not cli_args.entities or component_id in cli_args.entities
    }
    if cli_args.mode == "json":
        json.dump(component_info, sys.stdout, cls=GerritObjectsEncoder, indent=2)
    elif cli_args.mode == "script":
        sys.stdout.write(yaml.dump(component_info))
    else:  # rich
        rich_print(yaml.dump(component_info))


@with_gerrit_client()
async def _fn_component_owners_and_members(
    cli_args: Args,
    gerrit_client: GerritClient,  # noqa: ARG001 Unused function argument
    owners_client: CodeOwnersClient,
) -> None:
    """`members` command implementation"""

    all_component_info = await owners_client.all_components_info()
    if bad_keys := (set(cli_args.entities) - set(all_component_info)):
        raise FatalError(f"Unknown components: {', '.join(bad_keys)}")

    component_info = {
        component_id: component
        for component_id, component in all_component_info.items()
        if not cli_args.entities or component_id in cli_args.entities
    }
    if cli_args.mode == "json":
        json.dump(component_info, sys.stdout, cls=GerritObjectsEncoder, indent=2)
    elif cli_args.mode == "script":
        sys.stdout.write(
            yaml.dump({name: component.model_dump() for name, component in component_info.items()})
        )
    else:  # rich
        for component in component_info.values():
            rich_print(component.dump_rich())
            for i, member in enumerate(
                (component.component_owner_email, *(component.code_owners_email or []))
            ):
                rich_print(f"  * [bold blue]{member}[/][italic]{' (Lead)' if i == 0 else ''}[/]")


@with_gerrit_client()
async def _fn_component_for_path(
    cli_args: Args,
    gerrit_client: GerritClient,  # noqa: ARG001 Unused function argument
    owners_client: CodeOwnersClient,
) -> None:
    # fixme(frans): this is a hacky way to test if the given paths actually exist
    try:
        _path_types = {path: await path_type(path, owners_client) for path in cli_args.entities}
    except FileNotFoundError as exc:
        raise FatalError(str(exc)) from exc

    component_for_path = {
        entity: await owners_client.component_for_path(entity) for entity in cli_args.entities
    }
    if cli_args.mode == "json":
        json.dump(component_for_path, sys.stdout, cls=GerritObjectsEncoder, indent=2)
    elif cli_args.mode == "script":
        yaml.dump(component_for_path, sys.stdout, indent=2)
    else:  # rich
        for entity in cli_args.entities:
            rich_print(f"[bold]{await owners_client.component_for_path(entity)}[/]")


@with_gerrit_client()
async def _fn_component_paths(
    cli_args: Args,
    gerrit_client: GerritClient,  # noqa: ARG001 Unused function argument
    owners_client: CodeOwnersClient,
) -> None:

    if bad_keys := (set(cli_args.entities) - set(await owners_client.all_components_info())):
        raise FatalError(f"Unknown components: {', '.join(bad_keys)}")

    code_locations = {
        component: await owners_client.code_locations(component) for component in cli_args.entities
    }

    if cli_args.mode == "json":
        json.dump(code_locations, sys.stdout, cls=GerritObjectsEncoder, indent=2)
    elif cli_args.mode == "script":
        yaml.dump(code_locations, sys.stdout, indent=2)
    else:  # rich
        for component, paths in code_locations.items():
            for path in paths or []:
                rich_print(f"{component} [bold]{path}[/]")


async def path_type(path: str, owners_client: CodeOwnersClient) -> str:
    """Determine the type of a given path."""
    try:
        await owners_client.gerrit_client.repo_file_content(
            path,
            owners_client._project,  # noqa: SLF001
            owners_client._branch,  # noqa: SLF001
        )
    except ClientResponseError:
        return "path"
    return "file"


@with_gerrit_client()
async def _fn_owners_for(
    cli_args: Args,
    gerrit_client: GerritClient,  # noqa: ARG001 Unused function argument
    owners_client: CodeOwnersClient,
) -> None:
    """Returns the owners for the given paths."""

    # fixme(frans): this is a hacky way to test if the given paths actually exist
    try:
        _path_types = {path: await path_type(path, owners_client) for path in cli_args.entities}
    except FileNotFoundError as exc:
        raise FatalError(str(exc)) from exc

    owners_dict = {
        path: {
            "entry": entry,
            # fixme(frans): currently we only support one components per path
            "component": next(iter(components)) or "",
            "owners": owners,
        }
        for path in cli_args.entities
        for entry, components, owners in (owners_client._query(path),)  # noqa: SLF001
    }

    if cli_args.mode == "json":
        json.dump(owners_dict, sys.stdout, cls=GerritObjectsEncoder, indent=2)
    elif cli_args.mode == "script":
        yaml.dump(owners_dict, sys.stdout, indent=2)
    else:  # rich
        for path in cli_args.entities:
            _entry, components, owners = owners_client._query(path)  # noqa: SLF001
            component_id = next(iter(components)) or ""
            display_name = (await owners_client.all_components_info())[component_id].dump_rich()
            rich_print(f"[bold]- {path}[/]: {display_name}")
            for i, owner in enumerate(owners):
                rich_print(f"  * [bold cyan]{owner}[/][italic]{' (Lead)' if i == 0 else ''}[/]")


@with_gerrit_client()
async def _fn_all_code_owners_config_files(
    cli_args: Args, gerrit_client: GerritClient, owners_client: CodeOwnersClient
) -> None:
    owners_files = await owners_client.all_code_owners_config_files()
    if cli_args.mode == "json":
        json.dump(owners_files, sys.stdout, cls=GerritObjectsEncoder, indent=2)
    elif cli_args.mode == "script":
        yaml.dump(owners_files, sys.stdout, indent=2)
    else:  # rich
        for owners_file in owners_files:
            owners_file_content = await gerrit_client.repo_file_content(
                owners_file, cli_args.project_name, cli_args.branch
            )
            rich_print(owners_file, len(owners_file_content))


@with_gerrit_client()
async def _fn_config(
    cli_args: Args,
    gerrit_client: GerritClient,  # noqa: ARG001 Unused function argument
    owners_client: CodeOwnersClient,
) -> None:
    """Display the project configuration related to code-owners"""
    if cli_args.entities:
        path_config = {path: await owners_client.config_for(path) for path in cli_args.entities}
        sys.stdout.write(yaml.dump(path_config))
    else:
        project_config = await owners_client.project_config()
        if cli_args.mode == "json":
            json.dump(project_config, sys.stdout, cls=GerritObjectsEncoder, indent=2)
        elif cli_args.mode == "script":
            sys.stdout.write(yaml.dump(project_config))
        else:  # rich
            rich_print(yaml.dump(project_config))


@with_gerrit_client()
async def _fn_validate_config(  # noqa: C901 - too complex
    cli_args: Args,  # noqa: ARG001 Unused function argument
    gerrit_client: GerritClient,  # noqa: ARG001 Unused function argument
    owners_client: CodeOwnersClient,
) -> None:
    """
    Not validated yet:
    # - per-file entries must be file
    # - per-file entries must exist or match
    # - only one component / file
    # - over-matching per-file entries must be avoided
    # - missing description
    # - emails must be valid
    """
    try:
        await owners_client.check_config()
    except ClientResponseError as exc:
        if not exc.status == 403:  # noqa: PLR2004 (magic value)
            raise
        print("Can't validate config via Gerrit API due to permission issues", file=sys.stderr)

    print("Load ownership and component data..")
    issues: list[str] = list(await owners_client.populate_ownership_data(cache_mode="never"))

    print("Check consistency..")
    for per_file_path, entries in owners_client._cached.entries.items():  # noqa: SLF001
        for pattern, entry in entries.items():
            if not entry.noparent:
                issues.append(f"Entry {per_file_path}:{pattern} should have noparent set by now")

    if issues:
        for issue in issues:
            print(issue, file=sys.stderr)
        raise SystemExit(1)

    print("Check whether local path query returns same results as Gerrit API..")
    all_file_paths = await owners_client.gerrit_client.list_files("check_mk", "master")
    validated = set()

    for i, file_path in enumerate(all_file_paths):
        for pi in range(len(split_path := file_path.split("/")), 0, -1):
            if (composite_path := "/".join(split_path[:pi])) in validated:
                continue
            validated.add(composite_path)

            if composite_path.startswith("/.werks/"):
                continue

            plugin_response = await owners_client.owners_for(composite_path or "/")
            plugin_mails = sorted({a["email"] for a in plugin_response})

            _entry, components, mails = owners_client._query(composite_path)  # noqa: SLF001

            log().info(
                f"{i}/{len(all_file_paths)}: {composite_path} {components} {len(list(mails))}"
            )

            if plugin_mails != sorted(mails):
                log().warning(composite_path)
                log().warning("  query:  %s", components)
                log().warning("  query:  %s", sorted(mails))
                log().warning("  plugin: %s", plugin_mails)
                log().warning("  plugin: %s", plugin_response)
                raise SystemExit(1)


@with_gerrit_client()
async def _fn_check_config(
    cli_args: Args,  # noqa: ARG001 Unused function argument
    gerrit_client: GerritClient,  # noqa: ARG001 Unused function argument
    owners_client: CodeOwnersClient,
) -> None:
    await owners_client.check_config()


@with_gerrit_client()
async def _fn_stuff(
    cli_args: Args, gerrit_client: GerritClient, owners_client: CodeOwnersClient
) -> None:
    log().debug("check configuration..")
    # await owners_client.check_config()
    log().debug("all_code_owners_config_files..")
    for owners_file in await owners_client.all_code_owners_config_files():
        owners_file_content = await gerrit_client.repo_file_content(
            owners_file, cli_args.project_name, cli_args.branch
        )
        rich_print(owners_file, len(owners_file_content))

    log().debug("all_components_info..")
    rich_print(await owners_client.all_components_info())
    rich_print(await owners_client.component_for_path("mixed_component/core_part"))
    rich_print(await owners_client.code_locations("core_component"))
    rich_print(await owners_client.owners_for("mixed_component/core_part"))


@with_gerrit_client(populate=False)
async def _fn_tui(  # noqa: C901 - too complex
    cli_args: Args, gerrit_client: GerritClient, owners_client: CodeOwnersClient
) -> None:
    class TabCompleteInput(Input):
        """Input widget that accepts suggestions on Tab instead of right arrow."""

        async def _on_key(self, event: Key) -> None:
            if event.key == "tab" and self._suggestion:
                self.value = self._suggestion
                self.cursor_position = len(self.value)
                event.prevent_default()
                event.stop()
            else:
                await super()._on_key(event)

    class CmkComponents(TuiBaseApp):
        CSS = """
          Header {text-style: bold;}
          Tree > .tree--guides {color: $success-darken-3;}
          Tree > .tree--guides-selected {
            text-style: none;
            color: $success-darken-1;
          }
          #app_log {height: 8;}
          #error-label {
            border: solid black;
            background: red;
            color: white;
            width: 100%;
          }
        """
        BINDINGS: ClassVar[list[Binding | tuple[str, str] | tuple[str, str, str]]] = [
            Binding("ctrl+x", "app.quit", "Quit", show=True),
            Binding("u", "populate_tree"),
        ]

        def __init__(
            self,
            gerrit_client: GerritClient,
            owners_client: CodeOwnersClient,
            branch: str,
        ) -> None:
            super().__init__(
                logger_show_funcname=False, logger_show_tid=True, logger_show_name=True
            )
            log_level = cli_args.log_level if cli_args.log_level != "WARNING" else "INFO"
            self.set_log_levels(log_level, ("trickkiste", log_level))
            self.title = "CMK Components"
            self.main_tree_widget: Tree[None] = Tree("CmkComponents")
            self.main_tree_widget.show_root = False
            self.result_tree_node = self.main_tree_widget.root.add(
                "search results", expand=True, allow_expand=False
            )
            self.component_tree_node = self.main_tree_widget.root.add(
                "[bold spring_green1]Components[/] [white](press 'u' to force update)[/]",
                expand=False,
                allow_expand=True,
            )
            self.my_components_tree_node = self.main_tree_widget.root.add(
                "[bold spring_green1]Components I'm member of[/] (coming)",
                expand=False,
                allow_expand=True,
            )
            self.my_files_tree_node = self.main_tree_widget.root.add(
                "[bold spring_green1]Files I'm (co-)responsible for[/] (coming)",
                expand=False,
                allow_expand=True,
            )
            self.gerrit_client = gerrit_client
            self.owners_client = owners_client
            self.branch = branch
            self.ongoing_tasks: set[str] = set()

        def compose(self) -> ComposeResult:
            """Set up the UI"""
            yield Header(show_clock=True, id="header")
            self.error_label = Label(id="error-label")
            self.error_label.display = False
            self.input = TabCompleteInput(placeholder="path or component", id="dictionary-search")
            yield self.error_label
            yield self.input
            yield self.main_tree_widget
            yield from super().compose()

        @awatch_duration
        async def initialize(self) -> None:
            try:
                self.lookup()
                self.maintain_statusbar()
                self.action_populate_tree()
                self.populate_auto_completion_dict()
            except Exception as exc:  # noqa: BLE001
                self.error_label.update(f"[black]Error during initialization: {exc}[/]")
                self.error_label.display = True

        @work(exit_on_error=True)
        @awatch_duration
        async def action_populate_tree(self) -> None:
            self.ongoing_tasks.add("query Gerrit components")
            try:
                log().info("query components to populate tree with")
                self.input.placeholder = "Initialize component and ownership data.."
                await owners_client.populate_ownership_data(cache_mode=cli_args.cache_mode)
                self.component_tree_node.remove_children()
                await asyncio.sleep(0.1)
                for component in await owners_client.all_components_info():
                    self.component_tree_node.add_leaf(f"[bold cyan]{component}[/]")
            finally:
                self.input.placeholder = "path or component"
                self.ongoing_tasks.remove("query Gerrit components")

        @work(exit_on_error=True)
        async def populate_auto_completion_dict(self) -> None:
            self.ongoing_tasks.add("init auto completion")
            await asyncio.sleep(0.1)
            log().info("initialize auto completion with files and components")
            all_paths = list(
                set(
                    filter(
                        bool,
                        (
                            c
                            for a in map(str.strip, process_output("git ls-files").split("\n"))
                            for b in (a, a.rsplit("/", maxsplit=1)[0])
                            for c in (b, f"/{b}")
                        ),
                    )
                )
            )

            # fixme(frans): store only once
            all_components = list(await owners_client.all_components_info())
            self.input.suggester = SuggestFromList(
                sorted(all_paths + all_components), case_sensitive=False
            )
            self.ongoing_tasks.remove("init auto completion")

        @on(Click, "#error-label")
        def handle_error_label_click(self, _event: Click) -> None:
            self.exit()

        @awatch_duration
        async def on_input_changed(self, message: Input.Changed) -> None:
            self.lookup(message.value)

        @work(group="search", exclusive=True)
        @awatch_duration
        async def lookup(self, phrase: str = "") -> None:
            self.result_tree_node.remove_children()
            if not phrase:
                self.result_tree_node.label = "[italic]no search phrase given[/]"
                return
            self.result_tree_node.label = "[italic]searching...[/]"
            if not (result := sorted(await owners_client.owners_for(phrase), key=str)):
                self.result_tree_node.label = f"no results for '{phrase}'"
                return
            self.result_tree_node.label = (
                f"[bold spring_green1]Search results for [/]'{phrase}'[white][/]:"
            )
            for element in result:
                self.result_tree_node.add_leaf(f"[cyan]{element.get('email')}[/]")

        @work(exit_on_error=True)
        async def maintain_statusbar(self) -> None:
            """Status bar stub (to avoid 'nonsense' status)"""
            for i in count():
                if (i % 10 == 0) or self.ongoing_tasks:
                    always = (
                        f"{len(asyncio.all_tasks())} async tasks │ CmkComponents v{__version__}"
                    )
                    progress = (f"{'⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'[i % 10]} [blue]{t}[/]" for t in self.ongoing_tasks)
                    self.update_status_bar(" │ ".join((always, *progress)))
                await asyncio.sleep(0.3)

    await CmkComponents(gerrit_client, owners_client, cli_args.branch).run_async()


def main(args: None | Sequence[str] = None) -> int:
    """See main docstring"""
    traceback.install()
    cli_args = parse_arguments(args or sys.argv[1:])

    t1 = time.time()

    with ExitStack() as context:
        if cli_args.cache_file:
            context.enter_context(vcr.use_cassette(cli_args.cache_file, record_mode="new_episodes"))

        if cli_args.func != _fn_tui:
            setup_logging(log(), level=cli_args.log_level, show_name=20, show_funcname=30)
            logging.getLogger("vcr.matchers").setLevel(logging.WARNING)

        with suppress(KeyboardInterrupt):
            log().debug("run %r", cli_args.func.__name__)
            try:
                asyncio.run(cli_args.func(cli_args))
            except FatalError as exc:
                rich_print(f"ERROR: {exc}", file=sys.stderr)
                return 1

    if cli_args.func != _fn_tui:
        log().debug("took %.2fms", (time.time() - t1) * 1000)
    return 0


def log() -> logging.Logger:
    """Convenience function retrieves 'our' logger"""
    return logging.getLogger("trickkiste.cmk-components")


if __name__ == "__main__":
    raise SystemExit(main())
