# Anitabi MCP Server

An MCP (Model Context Protocol) server for the Anitabi public API. This server provides tools to fetch anime pilgrimage landmark information, letting AI assistants access real-world locations associated with various anime based on their Bangumi subject IDs.

## Features

This server provides the following tools:

- `get_anime_lite_info(subject_id: int)`: Fetches lite information of an anime's pilgrimage landmarks based on its Bangumi subject ID. Includes basic info like Chinese and original titles, the main city of pilgrimage, cover image, and up to 10 iconic landmarks.
- `get_anime_detail_points(subject_id: int, have_image: bool = None)`: Fetches detailed landmark information for an anime based on its Bangumi subject ID. Can optionally filter to only return landmarks that have images.
- `get_map_url(subject_id: int)`: Generates the Anitabi interactive pilgrimage map URL for a specific anime based on its Bangumi subject ID.

## Installation and Setup

### Usage with Claude Desktop (or other MCP Clients)

To use this server, you can configure your MCP client to run it via `uvx`. Add the following to your MCP client's configuration file (e.g., `claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "anitabi_mcpserver": {
      "command": "uvx",
      "args": [
        "--refresh",
        "anitabi-mcpserver"
      ]
    }
  }
}
```

### Local Development

1. Ensure you have `uv` installed.
2. Clone the repository and navigate to the project root.
3. Build the package:
   ```bash
   uv build
   ```

## API Source

All data is provided by the [Anitabi](https://anitabi.cn/) public API.
