# API Features

This document outlines the planned tools for the Anitabi MCP Server, based on the Anitabi public API documentation.

## Tool 1: get_anime_lite_info
- **Functional Description:** Fetches the lite information of an anime's pilgrimage landmarks based on its Bangumi subject ID. This includes basic info like Chinese and original titles, the main city of pilgrimage, cover image, and the first 10 iconic landmarks.
- **Original API Method Name:** `GET /bangumi/{subjectID}/lite`
- **Input Fields:**
  - `subjectID` (int): Required. The Bangumi subject ID of the anime.
- **Output Fields:**
  - Returns a JSON object containing:
    - `id` (int): Bangumi subject ID
    - `cn` (str): Chinese title
    - `title` (str): Original title
    - `city` (str): Main city
    - `cover` (str): Cover image URL
    - `color` (str): Main color theme
    - `geo` (List[float]): Default GPS coordinates [lat, lng]
    - `zoom` (float): Default map zoom level
    - `modified` (int): Last update timestamp
    - `litePoints` (List[dict]): Up to 10 iconic landmarks (id, cn, name, image, ep, s, geo)
    - `pointsLength` (int): Total number of landmarks
    - `imagesLength` (int): Total number of landmarks with images

## Tool 2: get_anime_detail_points
- **Functional Description:** Fetches the detailed landmark information of an anime based on its Bangumi subject ID. Can optionally filter to only return landmarks that have images.
- **Original API Method Name:** `GET /bangumi/{subjectID}/points/detail`
- **Input Fields:**
  - `subjectID` (int): Required. The Bangumi subject ID of the anime.
  - `haveImage` (Optional[bool]): Optional. Filter to only include landmarks with an image (`haveImage=true`).
- **Output Fields:**
  - Returns a JSON array of objects, where each object represents a landmark:
    - `id` (str): Landmark ID
    - `name` (str): Landmark original name
    - `image` (str): Thumbnail image URL
    - `ep` (int): Episode number
    - `s` (int): Timestamp in seconds
    - `geo` (List[float]): GPS coordinates [lat, lng]
    - `origin` (str): Source of the information
    - `originURL` (str): URL to the source information

## Tool 3: get_map_url
- **Functional Description:** Generates the Anitabi pilgrimage map URL for a specific anime based on its Bangumi subject ID.
- **Original API Method Name:** N/A (Constructed URL `https://anitabi.cn/map?bangumiId={id}`)
- **Input Fields:**
  - `subjectID` (int): Required. The Bangumi subject ID of the anime.
- **Output Fields:**
  - Returns a string containing the direct URL to the interactive pilgrimage map.
