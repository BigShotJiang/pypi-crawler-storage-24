"""XML parser compatibility wrapper.

Single source of truth for tool-call parsing lives in `klynx.agent.tools.XMLParser`.
This module keeps backwards-compatible helper APIs.
"""

from __future__ import annotations

import re

from klynx.agent.tools import XMLParser as _ToolXMLParser


class XMLParser(_ToolXMLParser):
    """Compatibility wrapper over the canonical XML parser."""

    @staticmethod
    def extract_thinking(content: str) -> str:
        match = re.search(r"<thinking>(.*?)</thinking>", content or "", re.DOTALL)
        return match.group(1).strip() if match else ""

    @staticmethod
    def extract_attempt_completion(content: str) -> str:
        match = re.search(
            r"<attempt_completion>(.*?)</attempt_completion>",
            content or "",
            re.DOTALL,
        )
        return match.group(1).strip() if match else ""

    @staticmethod
    def has_thinking(content: str) -> bool:
        return "<thinking>" in (content or "")

    @staticmethod
    def clean_xml_tags(content: str) -> str:
        return re.sub(r"<[^>]+>", "", content or "").strip()

