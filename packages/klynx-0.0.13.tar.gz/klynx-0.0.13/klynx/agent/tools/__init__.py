"""Tool-layer package for agent registry and helper utilities."""
from .lsp import get_diagnostics, goto_definition, init_lsp, shutdown_lsp
from .registry import ToolRegistry, XMLParser, get_json_schemas

__all__ = [
    "ToolRegistry",
    "XMLParser",
    "get_json_schemas",
    "init_lsp",
    "shutdown_lsp",
    "get_diagnostics",
    "goto_definition",
]
