"""Routing policy for Klynx agent graph."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class RoutingDecision:
    """Single routing decision result."""

    route: str
    reason: str
    warning: str = ""


class RoutingPolicy:
    """Pure routing policy to keep graph transitions testable."""

    @staticmethod
    def decide(state: Dict[str, Any], max_iterations: Optional[int]) -> RoutingDecision:
        iteration = int(state.get("iteration_count", 0) or 0)

        if bool(state.get("task_completed", False)):
            return RoutingDecision(route="end_direct", reason="任务已完成")

        pending_tools = state.get("pending_tool_calls", []) or []
        if pending_tools:
            return RoutingDecision(
                route="tools",
                reason=f"存在待执行工具调用({len(pending_tools)})",
            )

        if bool(state.get("needs_user_confirmation", False)):
            return RoutingDecision(route="end_direct", reason="需要用户确认")

        if max_iterations is not None and iteration >= max_iterations:
            return RoutingDecision(
                route="end_direct",
                reason=f"达到用户设置的最大迭代次数({max_iterations})",
                warning="如需继续，请在下一轮提高 max_iterations 或不设置该参数。",
            )

        if bool(state.get("ended_without_tools", False)):
            return RoutingDecision(route="end_direct", reason="无工具调用，直接收敛")

        if str(state.get("last_action", "") or "").strip().lower() == "clarify":
            return RoutingDecision(route="end_direct", reason="需要用户澄清")

        return RoutingDecision(route="agent", reason="默认继续执行")
