# Yoro Maps

**[Documentation](https://altius-academy-snc.github.io/yoro-maps/)** | **[PyPI](https://pypi.org/project/yoro-maps/)** | **[GitHub](https://github.com/Altius-Academy-SNC/yoro-maps)**

Offline maps, routing, and POI for Africa — companion to [yoro](https://pypi.org/project/yoro/) geocoding.

## Install

```bash
pip install yoro-maps
pip install yoro-maps[django]    # Django integration
pip install yoro-maps[tiles]     # Tile downloading
```

## Build a map database

```bash
# Download OSM data and build road graph for Mali
yoromaps download ML --output mali.yoromaps

# With map tiles (slower, ~200+ MB)
yoromaps download ML --output mali.yoromaps --tiles --zoom-max 14
```

## Route between Yoro codes

```bash
yoromaps route mali.yoromaps ML-ABC ML-XYZ
```

```python
import yoromaps

conn = yoromaps.open_db("mali.yoromaps")
result = yoromaps.route(conn, start_lat=12.6, start_lon=-8.0, end_lat=14.5, end_lon=-4.0)
print(f"{result.distance_km} km, {result.duration_min} min")
```

## Django integration

```python
# settings.py
import yoromaps

DATABASES = {
    "default": { ... },
    "maps": yoromaps.db_config("/data/mali.yoromaps"),
}

DATABASE_ROUTERS = ["yoromaps.django.router.YoroMapsRouter"]

# urls.py
urlpatterns = [
    path("maps/", include("yoromaps.django.urls")),
]
```

## License

MIT — Paul Guindo / Altius Academy SNC.
