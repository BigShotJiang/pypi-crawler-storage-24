"""
Yoro Maps — Offline maps, routing, and POI for Africa.

Companion to the ``yoro`` geocoding package.

Usage::

    import yoromaps

    # Build a .yoromaps file for Mali
    yoromaps.build("ML", "mali.yoromaps")

    # Route between Yoro codes
    conn = yoromaps.open_db("mali.yoromaps")
    result = yoromaps.route(conn, start_lat=12.6, start_lon=-8.0, end_lat=14.5, end_lon=-4.0)
    print(f"{result.distance_km} km, {result.duration_min} min")

    # Route from Yoro codes
    legs = yoromaps.route_from_codes(conn, ["ML-ABC", "ML-XYZ"])
"""

from yoromaps.db import db_config, open_db
from yoromaps.download import build
from yoromaps.routing import RouteResult, route, route_from_codes

__version__ = "0.1.1"

__all__ = [
    "build",
    "open_db",
    "db_config",
    "route",
    "route_from_codes",
    "RouteResult",
    "__version__",
]
