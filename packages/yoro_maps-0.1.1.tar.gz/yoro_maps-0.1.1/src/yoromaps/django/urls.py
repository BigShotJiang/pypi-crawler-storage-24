from django.urls import path

from yoromaps.django import views

app_name = "yoromaps"

urlpatterns = [
    path("tiles/<int:z>/<int:x>/<int:y>.png", views.tile_view, name="tile"),
    path("route/", views.route_view, name="route"),
]
