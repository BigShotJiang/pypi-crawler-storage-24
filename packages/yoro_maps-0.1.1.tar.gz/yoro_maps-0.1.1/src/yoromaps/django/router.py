"""
Database router that sends tile/routing queries to the maps SQLite database.

Usage in settings.py::

    DATABASE_ROUTERS = ["yoromaps.django.router.YoroMapsRouter"]
"""


class YoroMapsRouter:
    """Route read queries for yoromaps models to the 'maps' database."""

    def db_for_read(self, model, **hints):
        if model._meta.app_label == "yoromaps":
            return "maps"
        return None

    def db_for_write(self, model, **hints):
        if model._meta.app_label == "yoromaps":
            return "maps"
        return None

    def allow_relation(self, obj1, obj2, **hints):
        return None

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        if app_label == "yoromaps":
            return db == "maps"
        if db == "maps":
            return False
        return None
