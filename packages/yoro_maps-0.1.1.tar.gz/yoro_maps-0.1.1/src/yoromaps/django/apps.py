from django.apps import AppConfig


class YoroMapsConfig(AppConfig):
    name = "yoromaps.django"
    label = "yoromaps"
    verbose_name = "Yoro Maps"
    default_auto_field = "django.db.models.BigAutoField"
