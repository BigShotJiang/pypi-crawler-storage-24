"""
A* routing engine on the .yoromaps road graph.

Pure Python, works on the SQLite graph without loading everything in memory.
Uses a spatial index (bounding box) to limit the search space.
"""

from __future__ import annotations

import heapq
import math
import sqlite3
from dataclasses import dataclass, field


def _haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6_371_000
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dlon / 2) ** 2)
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def _nearest_node(conn: sqlite3.Connection, lat: float, lon: float) -> int | None:
    """Find the nearest graph node to a GPS coordinate."""
    # Search in expanding boxes until we find a node
    for delta in (0.01, 0.05, 0.1, 0.5, 1.0):
        row = conn.execute("""
            SELECT id, lat, lon FROM nodes
            WHERE lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?
            ORDER BY ((lat - ?) * (lat - ?) + (lon - ?) * (lon - ?))
            LIMIT 1
        """, (lat - delta, lat + delta, lon - delta, lon + delta,
              lat, lat, lon, lon)).fetchone()
        if row:
            return row["id"]
    return None


@dataclass
class RouteResult:
    """Result of a routing query."""

    distance_km: float
    duration_min: float
    nodes: list[int]
    geometry: dict  # GeoJSON LineString
    steps: list[dict]
    found: bool = True


def _build_geometry(conn: sqlite3.Connection, node_ids: list[int]) -> dict:
    """Build a GeoJSON LineString from a list of node IDs."""
    coords = []
    for nid in node_ids:
        row = conn.execute("SELECT lat, lon FROM nodes WHERE id = ?", (nid,)).fetchone()
        if row:
            coords.append([row["lon"], row["lat"]])
    return {"type": "LineString", "coordinates": coords}


def _build_steps(conn: sqlite3.Connection, node_ids: list[int]) -> list[dict]:
    """Build turn-by-turn steps from the route nodes."""
    steps = []
    prev_name = ""
    seg_distance = 0.0
    seg_start = 0

    for i in range(len(node_ids) - 1):
        edge = conn.execute("""
            SELECT distance_m, name, road_type FROM edges
            WHERE from_node = ? AND to_node = ? LIMIT 1
        """, (node_ids[i], node_ids[i + 1])).fetchone()

        if not edge:
            continue

        name = edge["name"] or edge["road_type"]
        if name != prev_name and prev_name:
            steps.append({
                "instruction": f"Continue on {prev_name}",
                "distance_m": round(seg_distance),
                "name": prev_name,
            })
            seg_distance = 0.0

        seg_distance += edge["distance_m"]
        prev_name = name

    if prev_name:
        steps.append({
            "instruction": f"Arrive at destination via {prev_name}",
            "distance_m": round(seg_distance),
            "name": prev_name,
        })

    return steps


def route(
    conn: sqlite3.Connection,
    start_lat: float,
    start_lon: float,
    end_lat: float,
    end_lon: float,
) -> RouteResult:
    """Find the shortest route between two GPS coordinates.

    Uses A* with haversine heuristic on the SQLite road graph.
    """
    start_node = _nearest_node(conn, start_lat, start_lon)
    end_node = _nearest_node(conn, end_lat, end_lon)

    if not start_node or not end_node:
        return RouteResult(
            distance_km=0, duration_min=0, nodes=[], geometry={"type": "LineString", "coordinates": []},
            steps=[], found=False,
        )

    if start_node == end_node:
        return RouteResult(
            distance_km=0, duration_min=0, nodes=[start_node],
            geometry=_build_geometry(conn, [start_node]), steps=[], found=True,
        )

    # Get target coordinates for heuristic
    end_row = conn.execute("SELECT lat, lon FROM nodes WHERE id = ?", (end_node,)).fetchone()
    end_lat_n, end_lon_n = end_row["lat"], end_row["lon"]

    # A* algorithm
    # Priority queue: (f_score, node_id)
    open_set: list[tuple[float, int]] = [(0.0, start_node)]
    came_from: dict[int, int] = {}
    g_score: dict[int, float] = {start_node: 0.0}
    duration: dict[int, float] = {start_node: 0.0}

    # Cache node coordinates for heuristic
    node_cache: dict[int, tuple[float, float]] = {}

    def get_coords(nid: int) -> tuple[float, float]:
        if nid not in node_cache:
            r = conn.execute("SELECT lat, lon FROM nodes WHERE id = ?", (nid,)).fetchone()
            node_cache[nid] = (r["lat"], r["lon"]) if r else (0, 0)
        return node_cache[nid]

    visited: set[int] = set()
    max_iterations = 500_000

    for _ in range(max_iterations):
        if not open_set:
            break

        _, current = heapq.heappop(open_set)

        if current == end_node:
            # Reconstruct path
            path = [current]
            while current in came_from:
                current = came_from[current]
                path.append(current)
            path.reverse()

            total_dist = g_score[end_node]
            total_dur = duration[end_node]

            return RouteResult(
                distance_km=round(total_dist / 1000, 1),
                duration_min=round(total_dur / 60, 1),
                nodes=path,
                geometry=_build_geometry(conn, path),
                steps=_build_steps(conn, path),
                found=True,
            )

        if current in visited:
            continue
        visited.add(current)

        # Get neighbors
        for edge in conn.execute(
            "SELECT to_node, distance_m, duration_s FROM edges WHERE from_node = ?",
            (current,),
        ):
            neighbor = edge["to_node"]
            if neighbor in visited:
                continue

            tentative_g = g_score[current] + edge["distance_m"]
            if tentative_g < g_score.get(neighbor, float("inf")):
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g
                duration[neighbor] = duration[current] + edge["duration_s"]

                # Heuristic: straight-line distance to target
                nlat, nlon = get_coords(neighbor)
                h = _haversine(nlat, nlon, end_lat_n, end_lon_n)
                f = tentative_g + h

                heapq.heappush(open_set, (f, neighbor))

    # No route found
    return RouteResult(
        distance_km=0, duration_min=0, nodes=[], geometry={"type": "LineString", "coordinates": []},
        steps=[], found=False,
    )


def route_from_codes(conn: sqlite3.Connection, codes: list[str]) -> list[RouteResult]:
    """Route through multiple Yoro codes in order.

    Returns a list of RouteResult, one per leg (len = len(codes) - 1).
    """
    import yoro

    points = [(yoro.decode(c)["lat"], yoro.decode(c)["lon"]) for c in codes]
    legs = []
    for i in range(len(points) - 1):
        legs.append(route(conn, points[i][0], points[i][1], points[i + 1][0], points[i + 1][1]))
    return legs
