"""
Country registry — Geofabrik download URLs and metadata.

Focused on Africa, extensible to other regions.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Country:
    code: str
    name: str
    geofabrik_path: str
    bbox: tuple[float, float, float, float]  # lon_min, lat_min, lon_max, lat_max


COUNTRIES: dict[str, Country] = {
    # --- West Africa (priority) ---
    "ML": Country("ML", "Mali", "africa/mali", (-12.5, 10.0, 4.5, 25.0)),
    "NE": Country("NE", "Niger", "africa/niger", (0.0, 11.5, 16.0, 24.0)),
    "BF": Country("BF", "Burkina Faso", "africa/burkina-faso", (-5.5, 9.0, 2.5, 15.5)),
    "CI": Country("CI", "Cote d'Ivoire", "africa/ivory-coast", (-8.6, 4.36, -2.49, 10.74)),
    "GH": Country("GH", "Ghana", "africa/ghana", (-3.26, 4.74, 1.2, 11.17)),
    "SN": Country("SN", "Senegal", "africa/senegal-and-gambia", (-17.54, 12.31, -11.36, 16.69)),
    "GN": Country("GN", "Guinee", "africa/guinea", (-15.08, 7.19, -7.64, 12.68)),
    "TG": Country("TG", "Togo", "africa/togo", (-0.15, 6.1, 1.81, 11.14)),
    "BJ": Country("BJ", "Benin", "africa/benin", (0.77, 6.14, 3.85, 12.41)),
    "NG": Country("NG", "Nigeria", "africa/nigeria", (2.69, 4.27, 14.68, 13.89)),
    "CM": Country("CM", "Cameroun", "africa/cameroon", (8.49, 1.65, 16.19, 13.08)),
    "SL": Country("SL", "Sierra Leone", "africa/sierra-leone", (-13.3, 6.93, -10.27, 10.0)),
    "LR": Country("LR", "Liberia", "africa/liberia", (-11.49, 4.35, -7.37, 8.55)),
    "MR": Country("MR", "Mauritanie", "africa/mauritania", (-17.07, 14.72, -4.83, 27.3)),
    "GW": Country("GW", "Guinee-Bissau", "africa/guinea-bissau", (-16.71, 10.87, -13.64, 12.68)),
    # --- Central / East Africa ---
    "CD": Country("CD", "RD Congo", "africa/congo-democratic-republic", (12.18, -13.46, 31.31, 5.39)),
    "KE": Country("KE", "Kenya", "africa/kenya", (33.91, -4.68, 41.91, 5.03)),
    "TZ": Country("TZ", "Tanzanie", "africa/tanzania", (29.33, -11.75, 40.44, -0.99)),
    "UG": Country("UG", "Ouganda", "africa/uganda", (29.57, -1.48, 35.04, 4.23)),
    "ET": Country("ET", "Ethiopie", "africa/ethiopia", (32.99, 3.4, 47.99, 14.89)),
    "MG": Country("MG", "Madagascar", "africa/madagascar", (43.18, -25.61, 50.48, -11.95)),
}

GEOFABRIK_BASE = "https://download.geofabrik.de"


def geofabrik_url(country_code: str) -> str:
    """Return the Geofabrik PBF download URL for a country."""
    c = COUNTRIES.get(country_code.upper())
    if not c:
        raise ValueError(f"Unknown country: {country_code}. Available: {list(COUNTRIES.keys())}")
    return f"{GEOFABRIK_BASE}/{c.geofabrik_path}-latest.osm.pbf"
