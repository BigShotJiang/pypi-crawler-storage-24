# Download & Build

This guide covers how to download OSM data and build `.yoromaps` files.

## How it works

The build process:

1. **Download** — Fetches the latest `.osm.pbf` file from [Geofabrik](https://download.geofabrik.de/) for the chosen country.
2. **Extract** — Parses the PBF in two passes using pyosmium: first collecting highway ways and node references, then resolving node coordinates.
3. **Build graph** — Inserts nodes (intersections) and edges (road segments) into the SQLite database, with distance and estimated travel time.
4. **Tiles** (optional) — Downloads map tiles from OpenStreetMap tile servers and stores them in MBTiles format.

## CLI usage

### Basic build

```bash
yoromaps download ML --output mali.yoromaps
```

### With tiles

```bash
yoromaps download ML --output mali.yoromaps --tiles --zoom-max 14
```

### Custom zoom range

```bash
yoromaps download BF --output bf.yoromaps --tiles --zoom-min 8 --zoom-max 12
```

### Using an existing PBF file

If you already have a PBF file (e.g., downloaded manually from Geofabrik):

```bash
yoromaps download ML --output mali.yoromaps --pbf /data/mali-latest.osm.pbf
```

### List available countries

```bash
yoromaps countries
```

## Python API

### Basic build

```python
from yoromaps.download import build

build("ML", "mali.yoromaps")
```

### With tiles and progress

```python
from yoromaps.download import build

def on_progress(message, current, total):
    if total > 0:
        print(f"{message}: {current / total * 100:.0f}%")
    else:
        print(message)

build(
    "ML",
    "mali.yoromaps",
    include_tiles=True,
    zoom_min=6,
    zoom_max=14,
    progress=on_progress,
)
```

### Using an existing PBF

```python
from yoromaps.download import build

build("ML", "mali.yoromaps", pbf_path="/data/mali-latest.osm.pbf")
```

### Download PBF only

```python
from yoromaps.download import download_pbf

pbf_path = download_pbf("ML", "/tmp/downloads")
print(f"Downloaded to: {pbf_path}")
```

## Road types

The extractor recognizes these OSM highway types, with estimated speeds used for routing duration:

| Highway type     | Speed (km/h) |
|------------------|---------------|
| motorway         | 110           |
| motorway_link    | 60            |
| trunk            | 90            |
| trunk_link       | 50            |
| primary          | 70            |
| primary_link     | 40            |
| secondary        | 60            |
| secondary_link   | 35            |
| tertiary         | 50            |
| tertiary_link    | 30            |
| residential      | 30            |
| unclassified     | 40            |
| living_street    | 20            |
| service          | 20            |
| track            | 15            |
| path             | 5             |

One-way streets are respected: if an OSM way has `oneway=yes`, only a forward edge is created.

## File sizes

Typical `.yoromaps` file sizes (road graph only, no tiles):

| Country       | PBF size | .yoromaps size |
|---------------|----------|----------------|
| Mali          | ~100 MB  | ~50 MB         |
| Burkina Faso  | ~50 MB   | ~25 MB         |
| Senegal       | ~60 MB   | ~30 MB         |

Adding tiles at zoom 6-14 adds 200-500 MB depending on the country area.

!!! note
    File sizes depend on OSM data completeness, which varies by country. These are rough estimates.
