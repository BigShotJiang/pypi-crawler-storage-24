# Routing

Yoro Maps provides offline routing on an OSM road graph using the A* algorithm.

## How routing works

1. **Nearest node lookup** — Given start/end GPS coordinates, the router finds the closest graph node using an expanding bounding-box search.
2. **A* search** — The algorithm explores the graph using a priority queue, with the haversine straight-line distance as the heuristic.
3. **Path reconstruction** — Once the destination is reached, the path is traced back through the `came_from` map.
4. **Result building** — The router builds a GeoJSON LineString geometry and turn-by-turn navigation steps.

## Route between coordinates

```python
import yoromaps

conn = yoromaps.open_db("mali.yoromaps")
result = yoromaps.route(
    conn,
    start_lat=12.6392,
    start_lon=-8.0029,
    end_lat=14.4974,
    end_lon=-4.0077,
)

if result.found:
    print(f"Distance: {result.distance_km} km")
    print(f"Duration: {result.duration_min} min")
    print(f"Nodes:    {len(result.nodes)}")
else:
    print("No route found")
```

## Route between Yoro codes

Yoro codes are decoded to GPS coordinates using the [yoro](https://altius-academy-snc.github.io/yoro/) library, then routed:

```python
import yoromaps

conn = yoromaps.open_db("mali.yoromaps")
legs = yoromaps.route_from_codes(conn, ["ML-ABC", "ML-XYZ"])

for i, leg in enumerate(legs):
    print(f"Leg {i + 1}: {leg.distance_km} km, {leg.duration_min} min, found={leg.found}")
```

## Multi-leg routes

Pass more than 2 codes to get multiple legs:

```python
legs = yoromaps.route_from_codes(conn, ["ML-AAA", "ML-BBB", "ML-CCC", "ML-DDD"])
# Returns 3 legs: AAA->BBB, BBB->CCC, CCC->DDD

total_km = sum(leg.distance_km for leg in legs)
total_min = sum(leg.duration_min for leg in legs)
print(f"Total: {total_km} km, {total_min} min")
```

## CLI routing

```bash
# Two-point route
yoromaps route mali.yoromaps ML-ABC ML-XYZ

# Multi-leg route
yoromaps route mali.yoromaps ML-AAA ML-BBB ML-CCC
```

Output is JSON:

```json
{
  "total_distance_km": 642.3,
  "total_duration_min": 578.1,
  "legs": [
    {
      "distance_km": 642.3,
      "duration_min": 578.1,
      "found": true,
      "steps": [
        {"instruction": "Continue on Route Nationale 6", "distance_m": 12340, "name": "Route Nationale 6"},
        {"instruction": "Arrive at destination via RN1", "distance_m": 8500, "name": "RN1"}
      ]
    }
  ]
}
```

## RouteResult object

The `route()` function returns a `RouteResult` dataclass:

| Field          | Type          | Description                                    |
|----------------|---------------|------------------------------------------------|
| `distance_km`  | `float`       | Total distance in kilometers                   |
| `duration_min` | `float`       | Estimated travel time in minutes               |
| `nodes`        | `list[int]`   | List of graph node IDs along the route         |
| `geometry`     | `dict`        | GeoJSON LineString with the route coordinates  |
| `steps`        | `list[dict]`  | Turn-by-turn navigation instructions           |
| `found`        | `bool`        | Whether a route was found (default `True`)     |

## GeoJSON output

The `geometry` field is a standard GeoJSON LineString that can be displayed on any map:

```python
import json

result = yoromaps.route(conn, start_lat=12.6, start_lon=-8.0, end_lat=14.5, end_lon=-4.0)

# Save as GeoJSON Feature
feature = {
    "type": "Feature",
    "geometry": result.geometry,
    "properties": {
        "distance_km": result.distance_km,
        "duration_min": result.duration_min,
    },
}

with open("route.geojson", "w") as f:
    json.dump(feature, f)
```

This GeoJSON can be loaded directly in QGIS, geojson.io, or rendered on a Leaflet map.

## Performance notes

- The A* algorithm has a hard limit of 500,000 iterations to prevent runaway searches.
- Node coordinates are cached during the search to minimize database lookups.
- The nearest-node search uses expanding bounding boxes (0.01 to 1.0 degrees) for efficiency.
- For very long routes across a country, the search may hit the iteration limit. Consider splitting into intermediate waypoints.
