# Countries

Yoro Maps currently supports 21 African countries, with pre-configured [Geofabrik](https://download.geofabrik.de/) download URLs.

## Supported countries

### West Africa

| Code | Country        | Geofabrik path          |
|------|----------------|-------------------------|
| ML   | Mali           | `africa/mali`           |
| NE   | Niger          | `africa/niger`          |
| BF   | Burkina Faso   | `africa/burkina-faso`   |
| CI   | Cote d'Ivoire  | `africa/ivory-coast`    |
| GH   | Ghana          | `africa/ghana`          |
| SN   | Senegal        | `africa/senegal-and-gambia` |
| GN   | Guinee         | `africa/guinea`         |
| TG   | Togo           | `africa/togo`           |
| BJ   | Benin          | `africa/benin`          |
| NG   | Nigeria        | `africa/nigeria`        |
| CM   | Cameroun       | `africa/cameroon`       |
| SL   | Sierra Leone   | `africa/sierra-leone`   |
| LR   | Liberia        | `africa/liberia`        |
| MR   | Mauritanie     | `africa/mauritania`     |
| GW   | Guinee-Bissau  | `africa/guinea-bissau`  |

### Central & East Africa

| Code | Country        | Geofabrik path                   |
|------|----------------|----------------------------------|
| CD   | RD Congo       | `africa/congo-democratic-republic` |
| KE   | Kenya          | `africa/kenya`                   |
| TZ   | Tanzanie       | `africa/tanzania`                |
| UG   | Ouganda        | `africa/uganda`                  |
| ET   | Ethiopie       | `africa/ethiopia`                |
| MG   | Madagascar     | `africa/madagascar`              |

## List countries from the CLI

```bash
yoromaps countries
```

Output:

```
  BF  Burkina Faso
  BJ  Benin
  CD  RD Congo
  CI  Cote d'Ivoire
  CM  Cameroun
  ET  Ethiopie
  GH  Ghana
  GN  Guinee
  GW  Guinee-Bissau
  KE  Kenya
  LR  Liberia
  MG  Madagascar
  ML  Mali
  MR  Mauritanie
  NE  Niger
  NG  Nigeria
  SL  Sierra Leone
  SN  Senegal
  TG  Togo
  TZ  Tanzanie
  UG  Ouganda
```

## List countries from Python

```python
from yoromaps.countries import COUNTRIES

for code, country in sorted(COUNTRIES.items()):
    print(f"{code}: {country.name} — bbox={country.bbox}")
```

## Get Geofabrik URL

```python
from yoromaps.countries import geofabrik_url

url = geofabrik_url("ML")
print(url)
# https://download.geofabrik.de/africa/mali-latest.osm.pbf
```

## Country data structure

Each country is a `Country` dataclass with:

| Field           | Type                               | Description                              |
|-----------------|------------------------------------|------------------------------------------|
| `code`          | `str`                              | ISO 3166-1 alpha-2 country code          |
| `name`          | `str`                              | Country name                             |
| `geofabrik_path`| `str`                              | Path on Geofabrik (e.g., `africa/mali`)  |
| `bbox`          | `tuple[float, float, float, float]`| Bounding box: lon_min, lat_min, lon_max, lat_max |

## Geofabrik data source

All OSM data is downloaded from [Geofabrik](https://download.geofabrik.de/), which provides regularly updated extracts of OpenStreetMap data by region. The downloads use the `-latest.osm.pbf` suffix to always get the most recent data.
