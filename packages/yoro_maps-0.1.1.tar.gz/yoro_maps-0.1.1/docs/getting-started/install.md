# Installation

## Requirements

- Python 3.10 or later
- The [yoro](https://pypi.org/project/yoro/) package (installed automatically)

## Basic install

```bash
pip install yoro-maps
```

This installs the core library with routing and database support. The only runtime dependencies are `yoro` and `httpx`.

## Optional extras

Yoro Maps has several optional dependency groups for specific features:

### Django integration

```bash
pip install yoro-maps[django]
```

Adds Django 4.2+ for serving tiles and routes from a web application. See the [Django Integration guide](../guides/django.md).

### Tile downloading

```bash
pip install yoro-maps[tiles]
```

Adds [mercantile](https://pypi.org/project/mercantile/) for calculating tile coordinates and downloading map tiles into the `.yoromaps` database. See the [Tile Serving guide](../guides/tiles.md).

### OSM data extraction

```bash
pip install yoro-maps[extract]
```

Adds [pyosmium](https://pypi.org/project/pyosmium/) for parsing OSM PBF files and building the road graph. Required if you want to build `.yoromaps` files from scratch. See the [Download & Build guide](../guides/download.md).

### Everything

```bash
pip install yoro-maps[all]
```

Installs all optional extras: `django`, `tiles`, and `extract`.

## Development install

```bash
git clone https://github.com/Altius-Academy-SNC/yoro-maps.git
cd yoro-maps
pip install -e ".[all,dev]"
```

The `dev` extra includes `pytest`, `pytest-cov`, and `ruff` for testing and linting.

## Verify installation

```python
import yoromaps
print(yoromaps.__version__)
```

```bash
yoromaps countries
```

This should print the list of 21 supported countries.
