# Django API Reference

## yoromaps.django

Django integration package. Add `"yoromaps.django"` to `INSTALLED_APPS`.

::: yoromaps.django

## yoromaps.django.views

Django views for tile serving and routing.

::: yoromaps.django.views
    options:
      members:
        - tile_view
        - route_view

## yoromaps.django.router

Database router for directing yoromaps queries to the maps database.

::: yoromaps.django.router
    options:
      members:
        - YoroMapsRouter

## yoromaps.django.urls

URL configuration. Include with:

```python
path("maps/", include("yoromaps.django.urls"))
```

### Registered URL patterns

| Pattern                          | Name   | View         |
|----------------------------------|--------|--------------|
| `tiles/<int:z>/<int:x>/<int:y>.png` | `tile` | `tile_view`  |
| `route/`                         | `route`| `route_view` |

## yoromaps.django.apps

::: yoromaps.django.apps
    options:
      members:
        - YoroMapsConfig
