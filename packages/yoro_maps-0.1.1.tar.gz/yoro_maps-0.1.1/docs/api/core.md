# Core API Reference

## yoromaps

Top-level module with convenience imports.

::: yoromaps
    options:
      members:
        - build
        - open_db
        - db_config
        - route
        - route_from_codes
        - RouteResult

## yoromaps.routing

A* routing engine on the `.yoromaps` road graph.

::: yoromaps.routing
    options:
      members:
        - RouteResult
        - route
        - route_from_codes

## yoromaps.db

Database management for `.yoromaps` files.

::: yoromaps.db
    options:
      members:
        - open_db
        - db_config
        - set_metadata
        - get_metadata
        - SCHEMA_VERSION

## yoromaps.download

Download OSM data and build `.yoromaps` files.

::: yoromaps.download
    options:
      members:
        - build
        - download_pbf

## yoromaps.tiles

MBTiles management — download and serve map tiles.

::: yoromaps.tiles
    options:
      members:
        - get_tile
        - tile_count
        - download_tiles

## yoromaps.countries

Country registry with Geofabrik download URLs.

::: yoromaps.countries
    options:
      members:
        - Country
        - COUNTRIES
        - geofabrik_url
        - GEOFABRIK_BASE

## yoromaps.extract

OSM PBF extraction into the road graph.

::: yoromaps.extract
    options:
      members:
        - extract_graph
        - haversine
        - HIGHWAY_SPEEDS
