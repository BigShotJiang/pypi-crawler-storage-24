from django.conf import settings as django_settings
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin, UserPassesTestMixin
from django.shortcuts import redirect, render
from django.utils import timezone
from django.views import View
from netbox.object_actions import BulkDelete
from netbox.views import generic

from .catalog_service import CatalogService
from .filtersets import InstallationLogFilterSet
from .forms import InstallationLogFilterForm, InstallForm, PluginFilterForm
from .installer import PluginInstaller
from .models import InstallationLog


class SuperuserIfConfiguredMixin(UserPassesTestMixin):
    """Restrict access to superusers when superuser_only setting is True."""

    def test_func(self):
        config = django_settings.PLUGINS_CONFIG.get("netbox_catalog", {})
        if config.get("superuser_only", True):
            return self.request.user.is_superuser
        return True
from .tables import InstallationLogTable


class CatalogListView(SuperuserIfConfiguredMixin, PermissionRequiredMixin, View):
    """Browse available plugins."""

    permission_required = "netbox_catalog.view_installationlog"
    template_name = "netbox_catalog/catalog_list.html"

    def get(self, request):
        # Check if this is an HTMX request for the plugin grid
        is_htmx = request.headers.get("HX-Request") == "true"

        service = CatalogService()

        # Get show_uncurated setting
        show_uncurated = request.GET.get("show_uncurated", "true").lower() != "false"

        # Get all plugins
        plugins = service.get_all_plugins(include_uncurated=show_uncurated)

        # Apply filters
        category = request.GET.get("category")
        certification = request.GET.get("certification")
        status = request.GET.get("status")
        compatibility = request.GET.get("compatibility")
        search = request.GET.get("q")

        if category:
            plugins = [p for p in plugins if p.category == category]

        if certification:
            plugins = [p for p in plugins if p.certification == certification]

        if status == "installed":
            plugins = [p for p in plugins if p.installed_version]
        elif status == "not_installed":
            plugins = [p for p in plugins if not p.installed_version]
        elif status == "activated":
            plugins = [p for p in plugins if p.is_activated]
        elif status == "upgradable":
            plugins = [p for p in plugins if p.upgrade_available]

        if compatibility == "compatible":
            plugins = [p for p in plugins if p.is_compatible]
        elif compatibility == "incompatible":
            plugins = [p for p in plugins if not p.is_compatible]
        elif compatibility == "unknown":
            plugins = [p for p in plugins if p.compatibility_source == "unknown"]

        if search:
            search_lower = search.lower()
            plugins = [
                p
                for p in plugins
                if search_lower in (p.name or "").lower()
                or search_lower in (p.summary or "").lower()
                or search_lower in (p.author or "").lower()
            ]

        # Sort
        sort = request.GET.get("sort", "name")
        if sort == "downloads":
            plugins.sort(key=lambda p: (-p.downloads_last_month, p.name.lower()))
        elif sort == "version":
            # Recently updated: sort by PyPI upload time (newest first)
            plugins.sort(key=lambda p: (p.last_updated or ""), reverse=True)
        else:
            # Default: featured first, then alphabetical
            plugins.sort(key=lambda p: (not p.featured, p.name.lower()))

        # For HTMX requests, return just the plugin grid partial
        if is_htmx:
            return render(
                request,
                "netbox_catalog/_plugin_grid.html",
                {"plugins": plugins},
            )

        categories = service.get_categories()
        filter_form = PluginFilterForm(request.GET, categories=categories)

        return render(
            request,
            self.template_name,
            {
                "plugins": [],  # Don't include plugins in initial load
                "categories": categories,
                "certification_levels": service.get_certification_levels(),
                "filter_form": filter_form,
                "total_count": len(plugins),
            },
        )


class PluginDetailView(SuperuserIfConfiguredMixin, PermissionRequiredMixin, View):
    """View plugin details."""

    permission_required = "netbox_catalog.view_installationlog"
    template_name = "netbox_catalog/plugin_detail.html"

    def get(self, request, name):
        service = CatalogService()
        plugin = service.get_plugin(name)

        if not plugin:
            messages.error(request, f"Plugin '{name}' not found.")
            return redirect("plugins:netbox_catalog:catalog_list")

        # Get installation history for this plugin
        install_logs = InstallationLog.objects.filter(package_name=name).order_by(
            "-started"
        )[:10]

        return render(
            request,
            self.template_name,
            {
                "plugin": plugin,
                "object": plugin,  # For breadcrumbs
                "install_logs": install_logs,
                "certification_levels": service.get_certification_levels(),
            },
        )


class PluginInstallView(SuperuserIfConfiguredMixin, PermissionRequiredMixin, View):
    """Install a plugin."""

    permission_required = "netbox_catalog.add_installationlog"
    template_name = "netbox_catalog/plugin_install.html"

    def get(self, request, name):
        service = CatalogService()
        plugin = service.get_plugin(name)

        if not plugin:
            messages.error(request, f"Plugin '{name}' not found.")
            return redirect("plugins:netbox_catalog:catalog_list")

        installer = PluginInstaller()
        is_docker = installer.is_docker_environment()
        pip_available = installer.is_pip_available()
        requirements_writable = installer.is_requirements_file_writable()

        # Determine install method
        # Docker with writable requirements = use requirements file
        # Non-docker with pip = use pip
        # Otherwise = manual only
        can_install = pip_available or (is_docker and requirements_writable)
        install_method = (
            "requirements" if (is_docker and requirements_writable) else "pip"
        )

        return render(
            request,
            self.template_name,
            {
                "plugin": plugin,
                "object": plugin,
                "form": InstallForm(initial={"version": plugin.version}),
                "config_snippet": installer.generate_config_snippet(name),
                "is_docker": is_docker,
                "pip_available": pip_available,
                "requirements_writable": requirements_writable,
                "can_install": can_install,
                "install_method": install_method,
            },
        )

    def post(self, request, name):
        service = CatalogService()
        plugin = service.get_plugin(name)

        if not plugin:
            messages.error(request, f"Plugin '{name}' not found.")
            return redirect("plugins:netbox_catalog:catalog_list")

        form = InstallForm(request.POST)
        installer = PluginInstaller()
        is_docker = installer.is_docker_environment()
        requirements_writable = installer.is_requirements_file_writable()

        if not form.is_valid():
            return render(
                request,
                self.template_name,
                {
                    "plugin": plugin,
                    "object": plugin,
                    "form": form,
                    "config_snippet": installer.generate_config_snippet(name),
                },
            )

        version = form.cleaned_data.get("version") or None
        upgrade = bool(plugin.installed_version)

        # Create log entry
        log = InstallationLog.objects.create(
            package_name=name,
            version=version or plugin.version,
            action=(
                InstallationLog.Action.UPGRADE
                if upgrade
                else InstallationLog.Action.INSTALL
            ),
            status=InstallationLog.Status.IN_PROGRESS,
            user=request.user,
        )

        # Choose install method based on environment
        if is_docker and requirements_writable:
            # Docker: add to requirements file
            result = installer.add_to_requirements(name, version=version)
        else:
            # Non-Docker: use pip
            result = installer.install(name, version=version, upgrade=upgrade)

        # Update log
        log.status = (
            InstallationLog.Status.SUCCESS
            if result.success
            else InstallationLog.Status.FAILED
        )
        log.output = result.output
        log.error = result.error
        log.version = result.version or version or plugin.version
        log.completed = timezone.now()
        log.save()

        if result.success:
            if is_docker and requirements_writable:
                messages.success(
                    request,
                    f"Added {name} to requirements-extra.txt. "
                    "Restart the container to complete installation.",
                )
            else:
                messages.success(
                    request, f"Successfully installed {name} {result.version}"
                )
            return redirect("plugins:netbox_catalog:plugin_installed", name=name)
        else:
            messages.error(request, f"Failed to install {name}: {result.error}")
            return render(
                request,
                self.template_name,
                {
                    "plugin": plugin,
                    "object": plugin,
                    "form": form,
                    "error": result.error,
                    "output": result.output,
                    "config_snippet": installer.generate_config_snippet(name),
                },
            )


class PluginInstalledView(SuperuserIfConfiguredMixin, PermissionRequiredMixin, View):
    """Post-installation instructions."""

    permission_required = "netbox_catalog.view_installationlog"
    template_name = "netbox_catalog/plugin_installed.html"

    def get(self, request, name):
        service = CatalogService()
        plugin = service.get_plugin(name)
        installer = PluginInstaller()

        is_docker = installer.is_docker_environment()
        requirements_writable = installer.is_requirements_file_writable()
        install_method = (
            "requirements" if (is_docker and requirements_writable) else "pip"
        )

        commands = installer.generate_post_install_commands()

        return render(
            request,
            self.template_name,
            {
                "plugin": plugin,
                "object": plugin,
                "config_snippet": installer.generate_config_snippet(name),
                "commands": commands,
                "is_docker": is_docker,
                "install_method": install_method,
            },
        )


class InstallationLogListView(SuperuserIfConfiguredMixin, generic.ObjectListView):
    """View installation history."""

    queryset = InstallationLog.objects.all()
    table = InstallationLogTable
    filterset = InstallationLogFilterSet
    filterset_form = InstallationLogFilterForm
    template_name = "netbox_catalog/installationlog_list.html"
    actions = (BulkDelete,)

    def get_extra_context(self, request):
        external_plugins = _get_external_plugins()
        return {"external_plugins": external_plugins}


class InstallationLogView(SuperuserIfConfiguredMixin, generic.ObjectView):
    """View single installation log."""

    queryset = InstallationLog.objects.all()
    template_name = "netbox_catalog/installationlog.html"


class InstallationLogDeleteView(SuperuserIfConfiguredMixin, generic.ObjectDeleteView):
    """Delete installation log."""

    queryset = InstallationLog.objects.all()


class InstallationLogBulkDeleteView(SuperuserIfConfiguredMixin, generic.BulkDeleteView):
    """Bulk delete installation logs."""

    queryset = InstallationLog.objects.all()
    filterset = InstallationLogFilterSet
    table = InstallationLogTable


class BackfillExternalView(SuperuserIfConfiguredMixin, LoginRequiredMixin, PermissionRequiredMixin, View):
    """Record externally-installed plugins in the installation history."""

    permission_required = "netbox_catalog.add_installationlog"

    def post(self, request):
        external_plugins = _get_external_plugins()
        now = timezone.now()
        count = 0

        for pkg in external_plugins:
            InstallationLog.objects.create(
                package_name=pkg["name"],
                version=pkg["version"],
                action=InstallationLog.Action.MANUAL,
                status=InstallationLog.Status.SUCCESS,
                output="Detected in requirements-extra.txt",
                user=request.user,
                completed=now,
            )
            count += 1

        if count:
            messages.success(
                request,
                f"Recorded {count} externally-installed plugin(s) in history.",
            )
        else:
            messages.info(request, "No externally-installed plugins to record.")

        return redirect("plugins:netbox_catalog:installationlog_list")


class RefreshCacheView(SuperuserIfConfiguredMixin, PermissionRequiredMixin, View):
    """Refresh the catalog cache."""

    permission_required = "netbox_catalog.add_installationlog"

    def post(self, request):
        service = CatalogService()
        service.refresh_cache()
        messages.success(request, "Catalog cache refreshed.")
        return redirect("plugins:netbox_catalog:catalog_list")


def _get_external_plugins():
    """Find installed plugins that have no InstallationLog entry."""
    installer = PluginInstaller()
    requirements = installer.get_requirements_packages()
    service = CatalogService()
    installed = service._get_installed_packages()

    # Get all package names that already have a log entry
    logged_packages = set(
        InstallationLog.objects.values_list("package_name", flat=True).distinct()
    )

    external = []
    for pkg_name in requirements:
        # Skip non-netbox packages
        if not pkg_name.startswith("netbox-") and pkg_name != "netbox-plugin-catalog":
            continue
        # Skip if already logged
        if pkg_name in logged_packages:
            continue
        # Get installed version
        version = installed.get(pkg_name, "")
        external.append({"name": pkg_name, "version": version})

    external.sort(key=lambda p: p["name"])
    return external
