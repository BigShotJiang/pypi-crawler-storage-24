"""
The "SCHIZOPHRENIC AI" is a technique developed by Sapiens Technology®️ that combines various types of inference architectures with the goal of providing the best possible response to the user.
The algorithm receives the "Input" prompt, sends the received request to the code of the "ENTITY" that will process this information using the "MAIN MODEL".
This input information will be categorized into one or more possible classes available in the "Sub-models" of the "FRANKENSTEIN" structure, and based on this categorization,
"FRANKENSTEIN" will select only the "Sub-models" specialized in the categories proposed by the "ENTITY". "FRANKENSTEIN" then returns the inference of the "Sub-models" most suited to the user"s request to the "ENTITY"s algorithm,
which will in turn reprocess this information to send it as the final "Output" of the architectural model of the "SCHIZOPHRENIC AI".
Any alteration, copying, or sharing of this abstraction layer, the abstracted algorithm, or any other code authored by Sapiens Technology®️ is strictly prohibited,
as are public posts or comments about the company’s technologies, and failure to comply with these guidelines will be subject to legal action pursued by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
class SchizophrenicAI:
	def __init__(self, show_errors=True, display_error_point=False):
		try:
			self.__show_errors = bool(show_errors) if type(show_errors) in (bool, int, float) else True
			self.__display_error_point = bool(display_error_point) if type(display_error_point) in (bool, int, float) else False
			try:
				from warnings import simplefilter, filterwarnings
				from logging import getLogger, ERROR, disable, CRITICAL
				from os import environ
				from dotenv import load_dotenv
				simplefilter('ignore')
				filterwarnings('ignore')
				filterwarnings('ignore', category=UserWarning, module='torch.distributed')
				getLogger('torch.distributed.elastic.multiprocessing.redirects').setLevel(ERROR)
				environ['DISABLE_MODEL_SOURCE_CHECK'] = 'True'
				load_dotenv()
				disable(CRITICAL)
			except: pass
			from traceback import print_exc
			self.__print_exc = print_exc
			from sapiens_schizophrenic_ai import SapiensSchizophrenicAI
			self.__sapiens_schizophrenic_ai = SapiensSchizophrenicAI(show_errors=self.__show_errors, display_error_point=self.__display_error_point)
			self.__OUTPUT = {'answer': '', 'answer_for_files': '', 'files': [], 'sources': [], 'javascript_charts': [], 'artifacts': [], 'next_token': '', 'str_cost': '0.0000000000', 'tool_call': []}
		except Exception as error:
			try:
				if self.__show_errors or self.show_error:
					error_message = 'ERROR in SchizophrenicAI.__init__: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point or self.show_error_details else None
					except: pass
			except: pass
	def loadModel(self, model_path='', progress=True):
		try: return self.__sapiens_schizophrenic_ai.loadModel(model_path=model_path, progress=progress)
		except Exception as error:
			try:
				if self.__show_errors or self.show_error:
					error_message = 'ERROR in SchizophrenicAI.loadModel: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point or self.show_error_details else None
					except: pass
			except: pass
			return False
	def inference(self, messages=[], max_tokens=None, stream=True, task_names=[], language='', temperature=0.5, creativity=0.5, humor=0.5, formality=0.5, political_spectrum=0.5, reasoning=0.0, reflection=False, tools=[]):
		try: return self.__sapiens_schizophrenic_ai.inference(messages=messages, max_tokens=max_tokens, stream=stream, task_names=task_names, language=language, temperature=temperature, creativity=creativity, humor=humor, formality=formality, political_spectrum=political_spectrum, reasoning=reasoning, reflection=reflection, tools=tools)
		except Exception as error:
			try:
				if self.__show_errors or self.show_error:
					error_message = 'ERROR in SchizophrenicAI.inference: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point or self.show_error_details else None
					except: pass
			except: pass
			return self.__OUTPUT
	def printInference(self, messages=[], max_tokens=None, stream=True, task_names=[], language='', temperature=0.5, creativity=0.5, humor=0.5, formality=0.5, political_spectrum=0.5, reasoning=0.0, reflection=False, tools=[]):
		try: self.__sapiens_schizophrenic_ai.printInference(messages=messages, max_tokens=max_tokens, stream=stream, task_names=task_names, language=language, temperature=temperature, creativity=creativity, humor=humor, formality=formality, political_spectrum=political_spectrum, reasoning=reasoning, reflection=reflection, tools=tools)
		except Exception as error:
			try:
				if self.__show_errors or self.show_error:
					error_message = 'ERROR in SchizophrenicAI.printInference: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point or self.show_error_details else None
					except: pass
			except: pass
	def close(self):
		try: return self.__sapiens_schizophrenic_ai.close()
		except Exception as error:
			try:
				if self.__show_errors or self.show_error:
					error_message = 'ERROR in SchizophrenicAI.close: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point or self.show_error_details else None
					except: pass
			except: pass
			return False
"""
The "SCHIZOPHRENIC AI" is a technique developed by Sapiens Technology®️ that combines various types of inference architectures with the goal of providing the best possible response to the user.
The algorithm receives the "Input" prompt, sends the received request to the code of the "ENTITY" that will process this information using the "MAIN MODEL".
This input information will be categorized into one or more possible classes available in the "Sub-models" of the "FRANKENSTEIN" structure, and based on this categorization,
"FRANKENSTEIN" will select only the "Sub-models" specialized in the categories proposed by the "ENTITY". "FRANKENSTEIN" then returns the inference of the "Sub-models" most suited to the user"s request to the "ENTITY"s algorithm,
which will in turn reprocess this information to send it as the final "Output" of the architectural model of the "SCHIZOPHRENIC AI".
Any alteration, copying, or sharing of this abstraction layer, the abstracted algorithm, or any other code authored by Sapiens Technology®️ is strictly prohibited,
as are public posts or comments about the company’s technologies, and failure to comply with these guidelines will be subject to legal action pursued by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
