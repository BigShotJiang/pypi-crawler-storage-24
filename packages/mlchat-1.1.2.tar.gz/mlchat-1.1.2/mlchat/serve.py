try:
    from fastapi import FastAPI, Body
    from fastapi.middleware.cors import CORSMiddleware
    from loguru import logger
except:
    raise ImportError('pip install fastapi uvicorn loguru')
import asyncio
import uvicorn
from uvicorn.config import LOGGING_CONFIG
import os
import argparse
import re
import importlib
import sys


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 允许所有的来源
    allow_credentials=True,  # 允许携带凭证（如 cookies）
    allow_methods=["*"],  # 允许所有的 HTTP 方法
    allow_headers=["*"],  # 允许所有的 HTTP 头部
)
sem = None
handle_func = None

@app.post("/")
async def _(inputs:list = Body(..., embed=True)):
    async with sem:
        logger.info(f'inputs: {inputs}')
        result = await asyncio.to_thread(handle_func, inputs)
        return result

def main():
    global handle_func, sem
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--model", type=str, required=True, help="语法模块, 例如:'main'; main.py要包含handle函数, inputs:list输入, 能json化的数据输出")
    parser.add_argument("--device", type=str, default='', help='cpu or 0,1,2,3')
    parser.add_argument("--port", type=int, default=9002)
    parser.add_argument("--limit", type=int, default=20)
    args = parser.parse_args()
    if args.device=='cpu':
        os.environ['CUDA_VISIBLE_DEVICES'] = ''
    elif gpus:=re.findall(r'([0-9]+)', args.device):
        os.environ['CUDA_VISIBLE_DEVICES'] = ','.join(gpus)
    # 添加消息时间
    LOGGING_CONFIG["formatters"]["default"]["fmt"] = '%(asctime)s - %(levelprefix)s %(message)s'
    LOGGING_CONFIG["formatters"]["default"]["datefmt"] = "%Y-%m-%d %H:%M:%S"
    LOGGING_CONFIG["formatters"]["access"]["fmt"] = '%(asctime)s - %(levelprefix)s %(client_addr)s - "%(request_line)s" %(status_code)s'
    LOGGING_CONFIG["formatters"]["access"]["datefmt"] = "%Y-%m-%d %H:%M:%S"
    sys.path.append(os.getcwd())
    handle_func = importlib.import_module(args.model).handle
    logger.info(f'{args.model} 模型加载完成...')
    sem = asyncio.Semaphore(args.limit)
    uvicorn.run(app, 
                host="0.0.0.0",
                port=args.port,
                forwarded_allow_ips='*',
                )