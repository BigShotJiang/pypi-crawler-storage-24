# aicompliant

Official Python SDK for [AICompliant](https://aicompliant.ai) — enterprise AI compliance automation.
```python
from aicompliant import AICompliant

client = AICompliant("dk_live_...")
summary = client.dashboard.get_summary()
print(f"Compliance Score: {summary['compliance_score']}%")
```

See https://aicompliant.ai/docs for full documentation.
