class AICompliantError(Exception):
    def __init__(self, message, code="API_ERROR", status=0):
        super().__init__(message)
        self.code = code
        self.status = status

class AuthenticationError(AICompliantError):
    def __init__(self, message="Invalid API key"):
        super().__init__(message, code="AUTHENTICATION_ERROR", status=401)

class RateLimitError(AICompliantError):
    def __init__(self, message="Rate limit exceeded"):
        super().__init__(message, code="RATE_LIMIT_ERROR", status=429)

class NotFoundError(AICompliantError):
    def __init__(self, message="Resource not found"):
        super().__init__(message, code="NOT_FOUND", status=404)

class ValidationError(AICompliantError):
    def __init__(self, message="Validation error"):
        super().__init__(message, code="VALIDATION_ERROR", status=400)
