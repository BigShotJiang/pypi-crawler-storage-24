import time
import httpx
from aicompliant.errors import AICompliantError, AuthenticationError, NotFoundError, RateLimitError, ValidationError

class HttpClient:
    def __init__(self, api_key, base_url="https://api.aicompliant.ai/v1", timeout=30.0, max_retries=2):
        self._max_retries = max_retries
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json", "User-Agent": "aicompliant-python/1.0.0"},
            timeout=timeout,
        )
    def close(self):
        self._client.close()
    def request(self, method, path, json=None, params=None):
        if params:
            params = {k: v for k, v in params.items() if v is not None}
        for attempt in range(self._max_retries + 1):
            try:
                resp = self._client.request(method, f"/{path.lstrip('/')}", json=json, params=params or None)
                return self._handle(resp)
            except (httpx.ConnectError, httpx.ReadTimeout) as e:
                if attempt < self._max_retries:
                    time.sleep(min(1.0 * 2**attempt, 8.0)); continue
                raise AICompliantError(str(e), code="NETWORK_ERROR") from e
            except RateLimitError:
                if attempt < self._max_retries:
                    time.sleep(min(1.0 * 2**attempt, 8.0)); continue
                raise
            except AICompliantError as e:
                if e.status >= 500 and attempt < self._max_retries:
                    time.sleep(min(1.0 * 2**attempt, 8.0)); continue
                raise
    def get(self, path, **params):
        return self.request("GET", path, params=params if params else None)
    def post(self, path, **data):
        return self.request("POST", path, json=data if data else None)
    def patch(self, path, **data):
        return self.request("PATCH", path, json=data if data else None)
    def delete(self, path):
        return self.request("DELETE", path)
    @staticmethod
    def _handle(resp):
        if resp.status_code == 401:
            raise AuthenticationError(resp.json().get("error", {}).get("message", "Invalid API key") if resp.content else "Invalid API key")
        if resp.status_code == 404:
            raise NotFoundError(resp.json().get("error", {}).get("message", "Not found") if resp.content else "Not found")
        if resp.status_code == 429:
            raise RateLimitError(resp.json().get("error", {}).get("message", "Rate limited") if resp.content else "Rate limited")
        if resp.status_code == 400:
            raise ValidationError(resp.json().get("error", {}).get("message", "Validation error") if resp.content else "Validation error")
        if resp.status_code >= 400:
            body = resp.json() if resp.content else {}
            err = body.get("error", {})
            raise AICompliantError(err.get("message", f"HTTP {resp.status_code}"), code=err.get("code", "API_ERROR"), status=resp.status_code)
        body = resp.json()
        return body.get("data", body)
