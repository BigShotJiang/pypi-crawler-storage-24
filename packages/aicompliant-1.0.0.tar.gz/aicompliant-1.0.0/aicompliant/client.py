from aicompliant.http import HttpClient

class Dashboard:
    def __init__(self, http): self._http = http
    def get_summary(self): return self._http.get("dashboard/summary")
    def get_penalty_breakdown(self): return self._http.get("dashboard/penalty-breakdown")
    def get_compliance_path(self): return self._http.get("dashboard/compliance-path")

class Regulations:
    def __init__(self, http): self._http = http
    def list(self): return self._http.get("regulations")
    def get(self, id): return self._http.get(f"regulations/{id}")

class Systems:
    def __init__(self, http): self._http = http
    def list(self): return self._http.get("systems")
    def create(self, name, **kwargs):
        body = {"name": name, **{k: v for k, v in kwargs.items() if v is not None}}
        return self._http.post("systems", **body)

class Tasks:
    def __init__(self, http): self._http = http
    def list(self, **filters): return self._http.get("tasks", **filters)
    def update(self, task_id, **params): return self._http.patch(f"tasks/{task_id}", **params)

class Risk:
    def __init__(self, http): self._http = http
    def get_score(self): return self._http.get("risk/score")

class Autopilot:
    def __init__(self, http): self._http = http
    def get_status(self): return self._http.get("autopilot/status")
    def scan(self): return self._http.post("autopilot/scan")

class Usage:
    def __init__(self, http): self._http = http
    def get_summary(self): return self._http.get("usage/summary")
    def get_history(self, days=30): return self._http.get("usage/history", days=days)
    def get_llm_breakdown(self, days=30): return self._http.get("usage/llm/breakdown", days=days)
    def get_webhook_health(self): return self._http.get("usage/webhooks/health")
    def retry_webhook(self, id): return self._http.post(f"usage/webhooks/{id}/retry")
    def reactivate_webhook(self, id): return self._http.post(f"usage/webhooks/{id}/reactivate")

class Organization:
    def __init__(self, http): self._http = http
    def me(self): return self._http.get("me")
    def get_settings(self): return self._http.get("organization/settings")
    def add_state(self, code): return self._http.post("organization/states", stateCode=code)
    def remove_state(self, code): return self._http.delete(f"organization/states/{code}")
    def run_gap_analysis(self): return self._http.post("organization/gap-analysis")
    def get_gap_analysis_status(self): return self._http.get("organization/gap-analysis/status")

class Intelligence:
    def __init__(self, http): self._http = http
    def ask(self, question): return self._http.post("intelligence/ask", question=question)

class AICompliant:
    def __init__(self, api_key, *, base_url="https://api.aicompliant.ai/v1", timeout=30.0, max_retries=2):
        if not api_key: raise ValueError("api_key is required")
        if not api_key.startswith("dk_"): raise ValueError('api_key must start with "dk_"')
        self._http = HttpClient(api_key=api_key, base_url=base_url, timeout=timeout, max_retries=max_retries)
        self.dashboard = Dashboard(self._http)
        self.regulations = Regulations(self._http)
        self.systems = Systems(self._http)
        self.tasks = Tasks(self._http)
        self.risk = Risk(self._http)
        self.autopilot = Autopilot(self._http)
        self.usage = Usage(self._http)
        self.organization = Organization(self._http)
        self.intelligence = Intelligence(self._http)
    def close(self): self._http.close()
    def __enter__(self): return self
    def __exit__(self, *a): self.close()
