"""Custom exception hierarchy for sqlalchemy-relay-pagination errors.

All exceptions inherit from ``PaginationError`` so callers can catch the
entire family with a single ``except PaginationError`` clause, or handle
individual cases precisely.
"""


class PaginationError(Exception): ...


class InvalidCursorError(PaginationError): ...


class InvalidArgumentsError(PaginationError): ...


class NullOrderingColumnError(PaginationError): ...
