"""sqlalchemy-relay-pagination: Relay-style keyset cursor pagination for SQLAlchemy.

Quick start::

    from sqlalchemy import select
    from sqlalchemy_relay_pagination import paginate, Connection

    async def resolve_users(session, first=10, after=None):
        query = select(User)
        conn: Connection[User] = await paginate(
            session, query, order_by=User.id, first=first, after=after
        )
        return conn

For GraphQL / Ariadne integration import the optional submodule::

    from sqlalchemy_relay_pagination.graphql import extract_requested_fields
"""

from sqlalchemy_relay_pagination.codec import Base64JsonCodec, CursorCodec
from sqlalchemy_relay_pagination.config import PaginationConfig, configure, get_config
from sqlalchemy_relay_pagination.exceptions import (
    InvalidArgumentsError,
    InvalidCursorError,
    NullOrderingColumnError,
    PaginationError,
)
from sqlalchemy_relay_pagination.pagination import paginate
from sqlalchemy_relay_pagination.pagination_many import paginate_many
from sqlalchemy_relay_pagination.types import Connection, Edge, PageInfo, PaginationArgs, RequestedFields

__all__ = [
    "Base64JsonCodec",
    "Connection",
    "CursorCodec",
    "Edge",
    "InvalidArgumentsError",
    "InvalidCursorError",
    "NullOrderingColumnError",
    "PageInfo",
    "PaginationArgs",
    "PaginationConfig",
    "PaginationError",
    "RequestedFields",
    "configure",
    "get_config",
    "paginate",
    "paginate_many",
]
