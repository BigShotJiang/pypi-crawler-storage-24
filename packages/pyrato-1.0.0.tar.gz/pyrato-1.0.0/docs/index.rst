pyrato
======

.. include:: header.rst
