"""
SiHam: النموذج المتطور للذكاء الاصطناعي
===========================================
إصدار متكامل مع صيغة .siham المخصصة
"""

__version__ = "3.0.0"
__author__ = "SiHam"
__license__ = "MIT"

# استيراد المكونات الرئيسية
from .core import (
    SiHamX,
    ModelConfig,
    ModalityType,
    TaskType,
    create_siham_x,
    siham_x_small,
    siham_x_medium,
    siham_x_large,
    save_siham_model,
    load_siham_model,
    inspect_siham_file
)

from .multi_modal import (
    FusionTransformer,
    CrossModalEncoder,
    ModalAlignment
)

from .temporal import (
    TemporalConvNet,
    PhysicsLSTM,
    EventPredictor
)

from .uncertainty import (
    BayesianDense,
    UncertaintyEstimator,
    DeepEnsemble
)

from .optimization import (
    MetaLearner,
    CurriculumScheduler,
    DARTSLayer
)

from .explainability import (
    SaliencyMap,
    GradCAM,
    CounterfactualExplainer
)

# معلومات الحزمة
__all__ = [
    # Core
    'SiHamX',
    'ModelConfig',
    'ModalityType',
    'TaskType',
    'create_siham_x',
    'siham_x_small',
    'siham_x_medium',
    'siham_x_large',
    'save_siham_model',
    'load_siham_model',
    'inspect_siham_file',
    
    # Multi-modal
    'FusionTransformer',
    'CrossModalEncoder',
    'ModalAlignment',
    
    # Temporal
    'TemporalConvNet',
    'PhysicsLSTM',
    'EventPredictor',
    
    # Uncertainty
    'BayesianDense',
    'UncertaintyEstimator',
    'DeepEnsemble',
    
    # Optimization
    'MetaLearner',
    'CurriculumScheduler',
    'DARTSLayer',
    
    # Explainability
    'SaliencyMap',
    'GradCAM',
    'CounterfactualExplainer'
]