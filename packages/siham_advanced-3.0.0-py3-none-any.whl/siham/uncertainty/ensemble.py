"""
DeepEnsemble: Simple deep ensemble for uncertainty.
"""

import tensorflow as tf

class DeepEnsemble:
    def __init__(self, models, **kwargs):
        self.models = models

    def predict(self, x, num_samples=10):
        predictions = [model(x) for model in self.models for _ in range(num_samples // len(self.models))]
        mean = tf.reduce_mean(predictions, axis=0)
        std = tf.math.reduce_std(predictions, axis=0)
        return mean, std
