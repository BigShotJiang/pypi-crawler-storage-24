"""
BayesianDense: Bayesian neural network dense layer.
"""

import tensorflow as tf
from tensorflow.keras import layers, Layer
import tensorflow_probability as tfp

tfd = tfp.distributions

class BayesianDense(Layer):
    def __init__(self, units, **kwargs):
        super().__init__(**kwargs)
        self.units = units

    def build(self, input_shape):
        self.kernel_mu = self.add_weight(shape=(input_shape[-1], self.units))
        self.kernel_rho = self.add_weight(shape=(input_shape[-1], self.units))
        self.bias_mu = self.add_weight(shape=(self.units,))
        self.bias_rho = self.add_weight(shape=(self.units,))

    def call(self, inputs, training=None):
        kernel = tfd.Normal(self.kernel_mu, tf.math.softplus(self.kernel_rho)).sample()
        bias = tfd.Normal(self.bias_mu, tf.math.softplus(self.bias_rho)).sample()
        return tf.matmul(inputs, kernel) + bias
