"""
UncertaintyEstimator: Estimates epistemic and aleatoric uncertainty.
"""

import tensorflow as tf
from tensorflow.keras import layers, Model

class UncertaintyEstimator(Model):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.aleatoric = layers.Dense(1)
        self.epistemic = layers.Dense(1, activation='softplus')

    def call(self, inputs, training=None):
        aleatoric = self.aleatoric(inputs)
        epistemic = self.epistemic(inputs)
        return {'aleatoric': aleatoric, 'epistemic': epistemic}
