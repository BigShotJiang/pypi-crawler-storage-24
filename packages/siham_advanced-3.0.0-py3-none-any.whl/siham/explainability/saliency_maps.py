#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
===========================================================================
🗺️ Saliency Maps - خرائط الأهمية
===========================================================================
"""

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from typing import Optional, List, Tuple, Dict, Any


class SaliencyMap(layers.Layer):
    """
    خريطة الأهمية الأساسية
    """
    
    def __init__(self, model: keras.Model, **kwargs):
        super().__init__(**kwargs)
        self.model = model
        
    def call(self, inputs, target_class=None):
        inputs = tf.Variable(inputs)
        
        with tf.GradientTape() as tape:
            tape.watch(inputs)
            outputs = self.model(inputs)
            
            if target_class is None:
                target = tf.reduce_max(outputs, axis=-1)
            else:
                target = outputs[:, target_class]
        
        gradients = tape.gradient(target, inputs)
        saliency = tf.reduce_max(tf.abs(gradients), axis=-1)
        
        return saliency
    
    def get_config(self):
        config = super().get_config()
        return config


class GradCAM(layers.Layer):
    """
    Gradient-weighted Class Activation Mapping
    """
    
    def __init__(self,
                 model: keras.Model,
                 last_conv_layer: str,
                 **kwargs):
        super().__init__(**kwargs)
        self.model = model
        self.last_conv_layer = last_conv_layer
        
        self.grad_model = keras.Model(
            inputs=[model.inputs],
            outputs=[
                model.get_layer(last_conv_layer).output,
                model.output
            ]
        )
        
    def call(self, inputs, target_class=None):
        with tf.GradientTape() as tape:
            conv_outputs, predictions = self.grad_model(inputs)
            
            if target_class is None:
                target = tf.reduce_max(predictions, axis=-1)
            else:
                target = predictions[:, target_class]
        
        grads = tape.gradient(target, conv_outputs)
        pooled_grads = tf.reduce_mean(grads, axis=(1, 2))
        
        heatmap = tf.reduce_sum(
            conv_outputs * pooled_grads[:, tf.newaxis, tf.newaxis, :],
            axis=-1
        )
        
        heatmap = tf.nn.relu(heatmap)
        heatmap /= tf.reduce_max(heatmap, axis=(1, 2), keepdims=True) + 1e-8
        
        return heatmap
    
    def get_config(self):
        config = super().get_config()
        config.update({'last_conv_layer': self.last_conv_layer})
        return config


class IntegratedGradients(layers.Layer):
    """
    تدرجات متكاملة
    """
    
    def __init__(self,
                 model: keras.Model,
                 steps: int = 50,
                 **kwargs):
        super().__init__(**kwargs)
        self.model = model
        self.steps = steps
        
    def call(self, inputs, baseline=None, target_class=None):
        inputs = tf.convert_to_tensor(inputs)
        
        if baseline is None:
            baseline = tf.zeros_like(inputs)
        
        alphas = tf.linspace(0.0, 1.0, self.steps)
        
        integrated_grads = tf.zeros_like(inputs)
        
        for alpha in alphas:
            interpolated = baseline + alpha * (inputs - baseline)
            interpolated = tf.Variable(interpolated)
            
            with tf.GradientTape() as tape:
                tape.watch(interpolated)
                outputs = self.model(interpolated)
                
                if target_class is None:
                    target = tf.reduce_max(outputs, axis=-1)
                else:
                    target = outputs[:, target_class]
            
            grads = tape.gradient(target, interpolated)
            integrated_grads += grads
        
        integrated_grads = integrated_grads * (inputs - baseline) / self.steps
        
        return integrated_grads
    
    def get_config(self):
        config = super().get_config()
        config.update({'steps': self.steps})
        return config


class SmoothGrad(layers.Layer):
    """
    تدرجات ملساء - تقلل الضوضاء
    """
    
    def __init__(self,
                 model: keras.Model,
                 num_samples: int = 50,
                 noise_level: float = 0.1,
                 **kwargs):
        super().__init__(**kwargs)
        self.model = model
        self.num_samples = num_samples
        self.noise_level = noise_level
        
    def call(self, inputs, target_class=None):
        inputs = tf.convert_to_tensor(inputs)
        
        all_grads = []
        
        for _ in range(self.num_samples):
            noise = tf.random.normal(tf.shape(inputs)) * self.noise_level
            noisy_input = inputs + noise
            
            with tf.GradientTape() as tape:
                tape.watch(noisy_input)
                outputs = self.model(noisy_input)
                
                if target_class is None:
                    target = tf.reduce_max(outputs, axis=-1)
                else:
                    target = outputs[:, target_class]
            
            grads = tape.gradient(target, noisy_input)
            all_grads.append(grads)
        
        smooth_grads = tf.reduce_mean(tf.stack(all_grads), axis=0)
        
        return smooth_grads
    
    def get_config(self):
        config = super().get_config()
        config.update({
            'num_samples': self.num_samples,
            'noise_level': self.noise_level
        })
        return config


class GuidedBackprop(layers.Layer):
    """
    توجيه الانتشار الخلفي
    """
    
    def __init__(self, model: keras.Model, **kwargs):
        super().__init__(**kwargs)
        self.model = model
        
    def call(self, inputs, target_class=None):
        inputs = tf.convert_to_tensor(inputs)
        inputs = tf.Variable(inputs)
        
        with tf.GradientTape() as tape:
            tape.watch(inputs)
            outputs = self.model(inputs)
            
            if target_class is None:
                target = tf.reduce_max(outputs, axis=-1)
            else:
                target = outputs[:, target_class]
        
        grads = tape.gradient(target, inputs)
        
        return grads
    
    def get_config(self):
        config = super().get_config()
        return config


__all__ = [
    'SaliencyMap',
    'GradCAM',
    'IntegratedGradients',
    'SmoothGrad',
    'GuidedBackprop'
]