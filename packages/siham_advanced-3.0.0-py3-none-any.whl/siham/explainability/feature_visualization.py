#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
===========================================================================
🎨 Feature Visualization - تصور الميزات
===========================================================================
"""

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from typing import Optional, List, Tuple, Dict, Any, Callable


class ActivationMaximization(layers.Layer):
    """
    تعظيم التنشيط - يجد المدخلات التي تزيد تنشيط وحدة معينة
    """
    
    def __init__(self,
                 layer_name: str,
                 filter_index: int = 0,
                 **kwargs):
        super().__init__(**kwargs)
        self.layer_name = layer_name
        self.filter_index = filter_index
        self.model = None
        
    def build(self, input_shape):
        if self.model is None:
            self.model = self._get_layer_model()
        
    def call(self, inputs, steps=100, lr=1.0):
        image = tf.Variable(inputs)
        
        for step in range(steps):
            with tf.GradientTape() as tape:
                tape.watch(image)
                layer_output = self.model(image)
                loss = tf.reduce_mean(layer_output[..., self.filter_index])
            
            grads = tape.gradient(loss, image)
            grads = tf.math.l2_normalize(grads)
            
            image.assign_add(lr * grads)
            image.assign(tf.clip_by_value(image, 0, 1))
        
        return image
    
    def _get_layer_model(self):
        return keras.Sequential([layers.InputLayer(), layers.Conv2D(64, 3)])
    
    def get_config(self):
        config = super().get_config()
        config.update({
            'layer_name': self.layer_name,
            'filter_index': self.filter_index
        })
        return config


class FeatureInversion(layers.Layer):
    """
    عكس الميزات - يعيد بناء الصورة من الميزات
    """
    
    def __init__(self,
                 layer_name: str,
                 **kwargs):
        super().__init__(**kwargs)
        self.layer_name = layer_name
        self.model = None
        
    def build(self, input_shape):
        if self.model is None:
            self.model = self._get_layer_model()
        
    def call(self, inputs, target_features, steps=100, lr=0.1):
        image = tf.Variable(inputs)
        
        for step in range(steps):
            with tf.GradientTape() as tape:
                tape.watch(image)
                current_features = self.model(image)
                loss = tf.reduce_mean((current_features - target_features) ** 2)
            
            grads = tape.gradient(loss, image)
            image.assign_sub(lr * grads)
            image.assign(tf.clip_by_value(image, 0, 1))
        
        return image
    
    def _get_layer_model(self):
        return keras.Sequential([layers.InputLayer(), layers.Conv2D(64, 3)])
    
    def get_config(self):
        config = super().get_config()
        config.update({'layer_name': self.layer_name})
        return config


class DeepDream(layers.Layer):
    """
    DeepDream - يعزز الأنماط في الصورة
    """
    
    def __init__(self,
                 layer_names: List[str],
                 **kwargs):
        super().__init__(**kwargs)
        self.layer_names = layer_names
        self.models = []
        
    def build(self, input_shape):
        for name in self.layer_names:
            model = self._get_layer_model(name)
            self.models.append(model)
        
    def call(self, inputs, steps=100, lr=0.01, octave_scale=1.3, num_octaves=3):
        image = inputs
        
        for octave in range(num_octaves):
            if octave > 0:
                image = tf.image.resize(
                    image,
                    [int(image.shape[1] / octave_scale),
                     int(image.shape[2] / octave_scale)]
                )
            
            image = tf.Variable(image)
            
            for step in range(steps):
                with tf.GradientTape() as tape:
                    tape.watch(image)
                    total_loss = 0
                    
                    for model in self.models:
                        layer_output = model(image)
                        total_loss += tf.reduce_mean(layer_output ** 2)
                
                grads = tape.gradient(total_loss, image)
                grads = tf.math.l2_normalize(grads)
                
                image.assign_add(lr * grads)
                image.assign(tf.clip_by_value(image, 0, 1))
        
        return image
    
    def _get_layer_model(self, layer_name):
        return keras.Sequential([layers.InputLayer(), layers.Conv2D(64, 3)])
    
    def get_config(self):
        config = super().get_config()
        config.update({'layer_names': self.layer_names})
        return config


class FeatureVisualizer(keras.Model):
    """
    مفسر متكامل للميزات
    """
    
    def __init__(self, model: keras.Model, **kwargs):
        super().__init__(**kwargs)
        self.model = model
        self.activation_max = ActivationMaximization('conv2d')
        self.feature_inv = FeatureInversion('conv2d')
        self.deep_dream = DeepDream(['conv2d'])
        
    def visualize_filter(self, filter_index: int, input_shape=(1, 224, 224, 3)):
        input_image = tf.random.uniform(input_shape)
        dream_image = self.deep_dream(input_image)
        return dream_image
    
    def get_config(self):
        config = super().get_config()
        return config


__all__ = [
    'ActivationMaximization',
    'FeatureInversion',
    'DeepDream',
    'FeatureVisualizer'
]