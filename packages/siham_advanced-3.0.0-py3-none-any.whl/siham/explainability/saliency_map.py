import tensorflow as tf
from tensorflow.keras.layers import Layer

import tensorflow as tf
from tensorflow.keras.layers import Layer

"""
SaliencyMap: Generates saliency maps for model explanations.
"""

import tensorflow as tf
from tensorflow.keras import layers, Model

class SaliencyMap(Layer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def call(self, inputs, model):
        with tf.GradientTape() as tape:
            tape.watch(inputs)
            preds = model(inputs)
            class_idx = tf.argmax(preds[0])
            grad = tape.gradient(preds[0, class_idx], inputs)
        return tf.abs(grad)


