"""
CounterfactualExplainer: Generates counterfactual explanations.
"""

import tensorflow as tf

class CounterfactualExplainer:
    def __init__(self, model):
        self.model = model

    def explain(self, input_data):
        # Perturb input to flip prediction stub
        perturbed = input_data + tf.random.normal(input_data.shape, 0.1)
        return perturbed.numpy()
