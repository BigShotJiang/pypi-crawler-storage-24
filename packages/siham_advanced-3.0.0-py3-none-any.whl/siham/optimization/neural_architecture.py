"""
DARTSLayer: Differentiable Architecture Search layer.
"""

import tensorflow as tf
from tensorflow.keras import layers, Layer

class DARTSLayer(Layer):
    def __init__(self, out_dim, ops, **kwargs):
        super().__init__(**kwargs)
        self.ops = ops
        self.alpha = self.add_weight('alpha', shape=(len(ops), out_dim), initializer='zeros')
        self.out_dim = out_dim

    def call(self, inputs, training=None):
        weights = tf.nn.softmax(self.alpha)
        outputs = [op(inputs) for op in self.ops]
        weighted = tf.reduce_sum([w[:, None] * o for w, o in zip(weights, outputs)], 0)
        return weighted
