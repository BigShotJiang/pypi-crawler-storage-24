"""
CurriculumScheduler: Difficulty-based curriculum learning.
"""

import tensorflow as tf

class CurriculumScheduler(tf.keras.callbacks.Callback):
    def __init__(self, curriculum_stages):
        super().__init__()
        self.curriculum_stages = curriculum_stages
        self.stage = 0

    def on_epoch_end(self, epoch, logs=None):
        if epoch % 10 == 0:
            self.stage = min(self.stage + 1, len(self.curriculum_stages) - 1)
