#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
===========================================================================
📦 SiHam Format - صيغة SiHam المخصصة (.siham)
===========================================================================
صيغة حفظ مخصصة لنماذج SiHam مع metadata, config, weights
الإصدار: 3.0
المطور: SiHam
===========================================================================
"""

import json
import pickle
import tensorflow as tf
from typing import Dict, Any, Optional
from pathlib import Path
import zipfile
import os

class SiHamFormat:
    """صيغة SiHam المخصصة"""
    
    MAGIC = b'SIHAM30'
    VERSION = '3.0'
    
    def __init__(self, config: Dict, weights: bytes, metadata: Dict[str, Any]):
        self.config = config
        self.weights = weights
        self.metadata = metadata

class SiHamFileWriter:
    """كاتب ملفات SiHam"""
    
    @staticmethod
    def save_siham_model(model, filepath: str, metadata: Optional[Dict] = None):
        """حفظ النموذج بصيغة .siham"""
        if metadata is None:
            metadata = {}
        
        # Extract config
        config = getattr(model, 'config', {}).to_dict() if hasattr(model, 'config') else {}
        
        # Save weights
        weights_path = 'model.weights.h5'
        model.save_weights(weights_path, save_format='h5')
        
        # Create ZIP
        with zipfile.ZipFile(filepath, 'w', zipfile.ZIP_DEFLATED) as zf:
            # Magic header
            zf.writestr('HEADER', SiHamFormat.MAGIC + model.__class__.__name__.encode())
            
            # Config
            zf.writestr('config.json', json.dumps(config, indent=2))
            
            # Metadata
            full_meta = {'version': SiHamFormat.VERSION, **metadata}
            zf.writestr('metadata.json', json.dumps(full_meta, indent=2))
            
            # Weights
            zf.write(weights_path, 'model.weights.h5')
        
        # Cleanup
        os.remove(weights_path)
        print(f"✅ Model saved to {filepath}")
        return filepath

class SiHamFileReader:
    """قارئ ملفات SiHam"""
    
    @staticmethod
    def load_siham_model(filepath: str):
        """تحميل نموذج من .siham"""
        model = None  # Placeholder - implement based on config
        with zipfile.ZipFile(filepath, 'r') as zf:
            if zf.read('HEADER')[:7] != SiHamFormat.MAGIC:
                raise ValueError("Invalid SiHam file")
            
            config = json.loads(zf.read('config.json'))
            metadata = json.loads(zf.read('metadata.json'))
            
            # Temp extract weights
            zf.extract('model.weights.h5')
            model.load_weights('model.weights.h5')
            os.remove('model.weights.h5')
        
        print(f"✅ Model loaded from {filepath}")
        return model

class SiHamModelConverter:
    """محول نماذج"""
    
    @staticmethod
    def to_siham(model, filepath: str):
        writer = SiHamFileWriter()
        return writer.save_siham_model(model, filepath)

class SiHamVersionedFile:
    """ملف SiHam مع إصدارات"""
    
    def __init__(self, filepath: str):
        self.filepath = filepath
        self.versions = []

def save_siham_model(model, filepath: str, metadata=None):
    writer = SiHamFileWriter()
    return writer.save_siham_model(model, filepath, metadata)

def load_siham_model(filepath: str):
    reader = SiHamFileReader()
    return reader.load_siham_model(filepath)

def inspect_siham_file(filepath: str):
    """فحص ملف SiHam"""
    with zipfile.ZipFile(filepath, 'r') as zf:
        config = json.loads(zf.read('config.json'))
        metadata = json.loads(zf.read('metadata.json'))
    print("SiHam File Info:")
    print(f"  Version: {metadata['version']}")
    print(f"  Model: {config.get('model_type', 'Unknown')}")
    print(f"  Params: {config.get('params', 0)}")
    return {'config': config, 'metadata': metadata}

def export_to_siham(model, filepath: str):
    return save_siham_model(model, filepath)

def import_from_siham(filepath: str):
    return load_siham_model(filepath)

__all__ = [
    'SiHamFormat',
    'SiHamFileWriter',
    'SiHamFileReader',
    'SiHamModelConverter',
    'SiHamVersionedFile',
    'save_siham_model',
    'load_siham_model',
    'inspect_siham_file',
    'export_to_siham',
    'import_from_siham'
]

