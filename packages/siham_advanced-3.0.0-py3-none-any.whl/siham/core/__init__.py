﻿"""
SiHam-Advanced Core Package
===========================
المكونات الأساسية للنموذج المتقدم مع حفظ بصيغة .siham
"""

try:
    # Try relative imports (when imported as package)
    from .siham_x import SiHamX, ModelConfig, ModalityType, TaskType, create_siham_x, siham_x_small, siham_x_medium, siham_x_large
    from .quantum_attention import QuantumAttentionLayer, QuantumStateLayer, QuantumEntanglementLayer
    from .neural_physics import PhysicsInformedLayer, PDEConstraintLayer, NeuralODESolver
    from .memory_bank import LongTermMemory, AssociativeMemory, MemoryNetwork
    from .hypernetwork import HyperNetwork, DynamicAdapter, HyperLSTM
    from .siham_format import (
        SiHamFormat,
        SiHamFileWriter,
        SiHamFileReader,
        SiHamModelConverter,
        SiHamVersionedFile,
        save_siham_model,
        load_siham_model,
        inspect_siham_file,
        export_to_siham,
        import_from_siham
    )
except ImportError:
    # Fall back to absolute imports (when run directly)
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    
    from siham.core.siham_x import SiHamX, ModelConfig, ModalityType, TaskType, create_siham_x, siham_x_small, siham_x_medium, siham_x_large
    from siham.core.quantum_attention import QuantumAttentionLayer, QuantumStateLayer, QuantumEntanglementLayer
    from siham.core.neural_physics import PhysicsInformedLayer, PDEConstraintLayer, NeuralODESolver
    from siham.core.memory_bank import LongTermMemory, AssociativeMemory, MemoryNetwork
    from siham.core.hypernetwork import HyperNetwork, DynamicAdapter, HyperLSTM
    from siham.core.siham_format import (
        SiHamFormat,
        SiHamFileWriter,
        SiHamFileReader,
        SiHamModelConverter,
        SiHamVersionedFile,
        save_siham_model,
        load_siham_model,
        inspect_siham_file,
        export_to_siham,
        import_from_siham
    )

__all__ = [
    # Main
    'SiHamX',
    'ModelConfig',
    'ModalityType',
    'TaskType',
    'create_siham_x',
    'siham_x_small',
    'siham_x_medium',
    'siham_x_large',
    
    # Quantum
    'QuantumAttentionLayer',
    'QuantumStateLayer',
    'QuantumEntanglementLayer',
    
    # Physics
    'PhysicsInformedLayer',
    'PDEConstraintLayer',
    'NeuralODESolver',
    
    # Memory
    'LongTermMemory',
    'AssociativeMemory',
    'MemoryNetwork',
    
    # Hypernetwork
    'HyperNetwork',
    'DynamicAdapter',
    'HyperLSTM',
    
    # SiHam Format
    'SiHamFormat',
    'SiHamFileWriter',
    'SiHamFileReader',
    'SiHamModelConverter',
    'SiHamVersionedFile',
    'save_siham_model',
    'load_siham_model',
    'inspect_siham_file',
    'export_to_siham',
    'import_from_siham'
]

if __name__ == "__main__":
    print("SiHam Core Package")
    print("Available components:")
    for item in __all__:
        print(f"  - {item}")
