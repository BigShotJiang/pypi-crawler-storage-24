#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
HyperNetwork - Dynamic Adaptation Networks
Version: 3.0
Author: SiHam
"""

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from typing import List, Tuple, Optional, Dict, Any, Callable

class WeightGenerator(layers.Layer):
    def __init__(self, target_shape: Tuple[int, ...], hidden_dim: int = 256, activation: str = 'relu', **kwargs):
        super().__init__(**kwargs)
        self.target_shape = target_shape
        self.hidden_dim = hidden_dim
        self.activation = activation

    def build(self, input_shape):
        total_params = np.prod(self.target_shape)
        self.hyper_net = keras.Sequential([
            layers.Dense(self.hidden_dim, activation=self.activation),
            layers.Dropout(0.1),
            layers.Dense(self.hidden_dim, activation=self.activation),
            layers.Dense(total_params, activation='tanh')
        ], name='weight_generator')
        super().build(input_shape)

    def call(self, condition):
        raw_weights = self.hyper_net(condition)
        weights = tf.reshape(raw_weights, self.target_shape)
        return weights

    def get_config(self):
        config = super().get_config()
        config.update({
            'target_shape': self.target_shape,
            'hidden_dim': self.hidden_dim,
            'activation': self.activation
        })
        return config

class HyperNetwork(layers.Layer):
    def __init__(self, condition_dim: int, num_hyper_layers: int = 3, **kwargs):
        super().__init__(**kwargs)
        self.condition_dim = condition_dim
        self.num_hyper_layers = num_hyper_layers

    def build(self, input_shape):
        self.target_template = keras.Sequential([
            layers.Dense(128, activation='relu'),
            layers.Dense(64, activation='relu'),
            layers.Dense(32)
        ])
        self.hyper_generators = []
        for layer in self.target_template.layers:
            if hasattr(layer, 'kernel'):
                hg = WeightGenerator(target_shape=layer.kernel.shape, condition_dim=self.condition_dim)
                self.hyper_generators.append(hg)
        super().build(input_shape)

    def call(self, inputs, condition):
        x = inputs
        for i, hg in enumerate(self.hyper_generators):
            weights = hg(condition)
            dl = layers.Dense(units=max(64 - 32*i, 16), kernel_initializer=tf.constant_initializer(weights))
            x = dl(x)
        return x

class DynamicAdapter(layers.Layer):
    def __init__(self, base_dim: int, adapter_dim: int = 64, num_adapters: int = 8, **kwargs):
        super().__init__(**kwargs)
        self.base_dim = base_dim
        self.adapter_dim = adapter_dim
        self.num_adapters = num_adapters

    def build(self, input_shape):
        self.gate = layers.Dense(self.num_adapters, activation='softmax')
        self.adapters = []
        for i in range(self.num_adapters):
            adapter = keras.Sequential([
                layers.Dense(self.adapter_dim, activation='relu'),
                layers.Dense(self.base_dim)
            ])
            self.adapters.append(adapter)
        super().build(input_shape)

    def call(self, inputs, task_condition=None):
        if task_condition is None:
            bsz = tf.shape(inputs)[0]
            task_condition = tf.zeros((bsz, 10))
        gate_weights = self.gate(task_condition)
        adapted = 0
        for i, adapter in enumerate(self.adapters):
            adapted += gate_weights[:, i, tf.newaxis] * adapter(inputs)
        return inputs + adapted

class HyperLSTM(keras.layers.LSTM):
    def __init__(self, units, condition_dim=32, **kwargs):
        super().__init__(units, **kwargs)
        self.condition_dim = condition_dim

    def build(self, input_shape):
        super().build(input_shape)
        self.weight_gen = WeightGenerator(target_shape=(self.units * 4,), condition_dim=self.condition_dim)

    def call(self, inputs, condition, *args, **kwargs):
        weights = self.weight_gen(condition)
        # Simplified assignment for demo
        output = super().call(inputs, *args, **kwargs)
        return output

__all__ = [
    'WeightGenerator',
    'HyperNetwork',
    'DynamicAdapter',
    'HyperLSTM'
]

if __name__ == '__main__':
    print('SiHam HyperNetwork ready!')

