#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
===========================================================================
🔗 HyperNetwork - شبكات فوقية للتكيف الديناميكي
===========================================================================
HyperNetworks generate weights for target networks dynamically.
الإصدار: 3.0
المطور: SiHam
===========================================================================
"""

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from typing import List, Tuple, Optional, Dict, Any, Callable

class WeightGenerator(layers.Layer):
    """مول أوزان ديناميكي - Dynamic Weight Generator"""
    
    def __init__(
        self,
        target_shape: Tuple[int, ...],
        hidden_dim: int = 256,
        condition_dim: Optional[int] = None,
        activation: str = 'relu',
        **kwargs
    ):
        super().__init__(**kwargs)
        self.target_shape = target_shape
        self.hidden_dim = hidden_dim
        self.condition_dim = condition_dim
        self.activation = activation
        self.total_params = int(np.prod(target_shape))

    def build(self, input_shape):
        input_dim = input_shape[-1] if self.condition_dim is None else self.condition_dim
        
        self.hyper_net = keras.Sequential([
            layers.Dense(self.hidden_dim, activation=self.activation, name='hyper1'),
            layers.Dropout(0.1),
            layers.Dense(self.hidden_dim // 2, activation=self.activation, name='hyper2'),
            layers.Dense(self.total_params, activation='tanh', name='weights_out')
        ], name='weight_generator')
        super().build(input_shape)

    def call(self, condition):
        raw_weights = self.hyper_net(condition)
        weights = tf.reshape(raw_weights, self.target_shape)
        return weights

    def get_config(self):
        config = super().get_config()
        config.update({
            'target_shape': self.target_shape,
            'hidden_dim': self.hidden_dim,
            'condition_dim': self.condition_dim,
            'activation': self.activation
        })
        return config


class HyperNetwork(layers.Layer):
    """شبكة فوقية كاملة - Full HyperNetwork"""
    
    def __init__(
        self,
        target_net_fn: Callable,
        condition_dim: int,
        num_hyper_layers: int = 3,
        hidden_dim: int = 256,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.target_net_fn = target_net_fn
        self.condition_dim = condition_dim
        self.num_hyper_layers = num_hyper_layers
        self.hidden_dim = hidden_dim

    def build(self, input_shape):
        # Create target template
        self.target_template = self.target_net_fn()
        
        # HyperNets for each layer
        self.hyper_generators = []
        self.layer_names = []
        
        for layer in self.target_template.layers:
            if hasattr(layer, 'kernel') and isinstance(layer, layers.Dense):
                hg = WeightGenerator(
                    target_shape=layer.kernel.shape,
                    hidden_dim=self.hidden_dim,
                    condition_dim=self.condition_dim,
                    name=f'hg_{layer.name}'
                )
                self.hyper_generators.append(hg)
                self.layer_names.append(layer.name)
        
        super().build(input_shape)

    def call(self, inputs, condition=None):
        """Forward pass with optional condition"""
        if condition is None:
            batch_size = tf.shape(inputs)[0]
            condition = tf.zeros((batch_size, self.condition_dim))
        
        # Apply dynamic network
        x = inputs
        
        for i, (layer_name, hg) in enumerate(zip(self.layer_names, self.hyper_generators)):
            # Get original layer for reference
            original_layer = self.target_template.get_layer(layer_name)
            
            # Generate weights
            weights = hg(condition)
            
            # Create dynamic dense layer
            dynamic_layer = tf.keras.layers.Dense(
                units=original_layer.units,
                kernel_initializer=tf.constant_initializer(weights),
                use_bias=original_layer.use_bias,
                activation=original_layer.activation,
                name=f'dynamic_{layer_name}'
            )
            dynamic_layer.build(x.shape)
            
            # Apply layer
            x = dynamic_layer(x)
        
        return x

    def get_config(self):
        config = super().get_config()
        config.update({
            'condition_dim': self.condition_dim,
            'num_hyper_layers': self.num_hyper_layers,
            'hidden_dim': self.hidden_dim
        })
        return config


class DynamicAdapter(layers.Layer):
    """محول ديناميكي - Dynamic Adapter for task adaptation"""
    
    def __init__(
        self,
        base_dim: int,
        adapter_dim: int = 64,
        num_adapters: int = 8,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.base_dim = base_dim
        self.adapter_dim = adapter_dim
        self.num_adapters = num_adapters

    def build(self, input_shape):
        self.gate = layers.Dense(self.num_adapters, activation='softmax', name='adapter_gate')
        
        self.adapters = []
        for i in range(self.num_adapters):
            adapter = keras.Sequential([
                layers.Dense(self.adapter_dim, activation='relu'),
                layers.Dense(self.base_dim, activation='tanh')
            ], name=f'adapter_{i}')
            self.adapters.append(adapter)
        
        super().build(input_shape)

    def call(self, inputs, task_condition=None):
        if task_condition is None:
            batch_size = tf.shape(inputs)[0]
            task_condition = tf.zeros((batch_size, 10))
        
        gate_weights = self.gate(task_condition)
        adapted = tf.zeros_like(inputs)
        
        for i, adapter in enumerate(self.adapters):
            adapter_out = adapter(inputs)
            gate_weight = tf.expand_dims(gate_weights[:, i], axis=-1)
            adapted += gate_weight * adapter_out
        
        return inputs + adapted

    def get_config(self):
        config = super().get_config()
        config.update({
            'base_dim': self.base_dim,
            'adapter_dim': self.adapter_dim,
            'num_adapters': self.num_adapters
        })
        return config


class HyperLSTM(keras.layers.LSTM):
    """LSTM مع أوزان ديناميكية - Hyper Parameters LSTM"""
    
    def __init__(self, units, condition_dim=32, **kwargs):
        super().__init__(units, **kwargs)
        self.condition_dim = condition_dim
        self._hyper_generator = None

    def build(self, input_shape):
        super().build(input_shape)
        
        # Calculate total parameters
        input_dim = input_shape[-1]
        total_params = 4 * self.units * (input_dim + self.units)
        
        self._hyper_generator = WeightGenerator(
            target_shape=(total_params,),
            hidden_dim=256,
            condition_dim=self.condition_dim,
            name='hyper_lstm_generator'
        )
        self._hyper_generator.build(tf.TensorShape([None, self.condition_dim]))

    def call(self, inputs, condition=None, *args, **kwargs):
        if condition is None:
            batch_size = tf.shape(inputs)[0]
            condition = tf.zeros((batch_size, self.condition_dim))
        
        # Generate weights
        weights = self._hyper_generator(condition)
        
        # Split weights for kernel and recurrent kernel
        input_dim = inputs.shape[-1]
        kernel_size = self.units * input_dim * 4
        recurrent_kernel_size = self.units * self.units * 4
        
        kernel_weights = weights[:, :kernel_size]
        recurrent_weights = weights[:, kernel_size:kernel_size + recurrent_kernel_size]
        
        # Reshape for LSTM
        kernel_reshaped = tf.reshape(kernel_weights, [-1, input_dim, self.units * 4])
        recurrent_reshaped = tf.reshape(recurrent_weights, [-1, self.units, self.units * 4])
        
        # Process each sample in batch with its own weights
        outputs = []
        for i in range(tf.shape(inputs)[0]):
            # Create LSTM cell with generated weights
            lstm_cell = tf.keras.layers.LSTMCell(self.units)
            lstm_cell.build(inputs.shape)
            
            # Assign generated weights
            lstm_cell.kernel = kernel_reshaped[i]
            lstm_cell.recurrent_kernel = recurrent_reshaped[i]
            
            # Apply LSTM
            output, state = lstm_cell(inputs[i:i+1], states=None)
            outputs.append(output)
        
        return tf.concat(outputs, axis=0)

    def get_config(self):
        config = super().get_config()
        config.update({'condition_dim': self.condition_dim})
        return config


__all__ = [
    'WeightGenerator',
    'HyperNetwork',
    'DynamicAdapter',
    'HyperLSTM'
]

if __name__ == '__main__':
    print("🚀 SiHam HyperNetwork loaded successfully!")
    
    # Example usage
    print("\n" + "="*60)
    print("Testing HyperNetwork Components")
    print("="*60)
    
    # Test WeightGenerator
    print("\n📦 Testing WeightGenerator...")
    wg = WeightGenerator(target_shape=(64, 32), hidden_dim=128)
    dummy_cond = tf.random.normal((4, 10))
    weights = wg(dummy_cond)
    print(f"✓ Generated weights shape: {weights.shape}")
    
    # Test DynamicAdapter
    print("\n🔧 Testing DynamicAdapter...")
    adapter = DynamicAdapter(base_dim=128, adapter_dim=64, num_adapters=4)
    dummy_input = tf.random.normal((8, 128))
    dummy_task = tf.random.normal((8, 16))
    adapted = adapter(dummy_input, dummy_task)
    print(f"✓ Adapted output shape: {adapted.shape}")
    
    # Test HyperLSTM
    print("\n🔄 Testing HyperLSTM...")
    hyper_lstm = HyperLSTM(units=64, condition_dim=32)
    dummy_seq = tf.random.normal((4, 10, 128))
    dummy_cond = tf.random.normal((4, 32))
    lstm_out = hyper_lstm(dummy_seq, dummy_cond)
    print(f"✓ LSTM output shape: {lstm_out.shape}")
    
    print("\n✅ All tests passed!")