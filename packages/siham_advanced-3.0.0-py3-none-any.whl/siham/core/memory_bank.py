#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
===========================================================================
💾 Memory Bank - ذاكرة طويلة المدى قابلة للاسترجاع
===========================================================================
"""

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from typing import Optional, List, Tuple, Dict, Any


class MemoryCell(layers.Layer):
    """
    خلية ذاكرة فردية
    """
    
    def __init__(self, key_dim: int, value_dim: int, **kwargs):
        super().__init__(**kwargs)
        self.key_dim = key_dim
        self.value_dim = value_dim
        
    def build(self, input_shape):
        self.key = self.add_weight(
            name='key',
            shape=(self.key_dim,),
            initializer='random_normal',
            trainable=True
        )
        
        self.value = self.add_weight(
            name='value',
            shape=(self.value_dim,),
            initializer='zeros',
            trainable=True
        )
        
        self.age = self.add_weight(
            name='age',
            shape=(),
            initializer='zeros',
            trainable=False
        )
        
        self.access_count = self.add_weight(
            name='access_count',
            shape=(),
            initializer='zeros',
            trainable=False
        )
        
    def call(self, query):
        similarity = tf.reduce_sum(query * self.key) / tf.sqrt(float(self.key_dim))
        return similarity, self.value
    
    def update(self, key, value):
        self.key.assign(key)
        self.value.assign(value)
        self.age.assign(0.0)
        self.access_count.assign_add(1.0)
    
    def get_stats(self):
        return {
            'age': self.age.numpy(),
            'access_count': self.access_count.numpy()
        }
    
    def get_config(self):
        config = super().get_config()
        config.update({
            'key_dim': self.key_dim,
            'value_dim': self.value_dim
        })
        return config


class LongTermMemory(layers.Layer):
    """
    ذاكرة طويلة المدى متقدمة
    """
    
    def __init__(self,
                 memory_size: int = 10000,
                 key_dim: int = 256,
                 value_dim: int = 512,
                 num_heads: int = 4,
                 **kwargs):
        super().__init__(**kwargs)
        self.memory_size = memory_size
        self.key_dim = key_dim
        self.value_dim = value_dim
        self.num_heads = num_heads
        
    def build(self, input_shape):
        self.memory_keys = self.add_weight(
            name='memory_keys',
            shape=(self.memory_size, self.key_dim),
            initializer='random_normal',
            trainable=True
        )
        
        self.memory_values = self.add_weight(
            name='memory_values',
            shape=(self.memory_size, self.value_dim),
            initializer='zeros',
            trainable=True
        )
        
        self.memory_ages = self.add_weight(
            name='memory_ages',
            shape=(self.memory_size,),
            initializer='zeros',
            trainable=False
        )
        
        self.memory_access = self.add_weight(
            name='memory_access',
            shape=(self.memory_size,),
            initializer='zeros',
            trainable=False
        )
        
        self.query_proj = layers.Dense(self.key_dim, use_bias=False, name="query_proj")
        self.key_proj = layers.Dense(self.key_dim, use_bias=False, name="key_proj")
        self.value_proj = layers.Dense(self.value_dim, use_bias=False, name="value_proj")
        
        self.attention = layers.MultiHeadAttention(
            num_heads=self.num_heads,
            key_dim=self.key_dim // self.num_heads,
            name="memory_attention"
        )
        
        self.forget_gate = self.add_weight(
            name='forget_gate',
            shape=(self.memory_size,),
            initializer=tf.constant_initializer(0.1),
            trainable=True
        )
        
        self.step = 0
        
    def call(self, inputs, query=None, write=True, training=False):
        batch_size = tf.shape(inputs)[0]
        self.step += 1
        
        if query is None:
            query = inputs
        
        q = self.query_proj(query)
        if len(q.shape) == 2:
            q = tf.expand_dims(q, 1)
        
        k = self.key_proj(self.memory_keys)[tf.newaxis, :, :]
        v = self.value_proj(self.memory_values)[tf.newaxis, :, :]
        
        attention_output = self.attention(
            query=q,
            value=v,
            key=k,
            training=training
        )
        
        retrieved = tf.squeeze(attention_output, axis=1)
        
        attention_weights = self.attention._last_attention_weights
        if attention_weights is not None:
            access_increment = tf.reduce_sum(attention_weights, axis=[0, 1])
            self.memory_access.assign_add(access_increment[:self.memory_size])
        
        if write and self.step % 10 == 0:
            new_key = tf.reduce_mean(q, axis=1)
            new_value = tf.reduce_mean(tf.cast(q, tf.float32), axis=1)
            
            ages_with_noise = self.memory_ages + tf.random.uniform(tf.shape(self.memory_ages)) * 0.1
            oldest_idx = tf.argmax(ages_with_noise)
            
            self.memory_keys = tf.tensor_scatter_nd_update(
                self.memory_keys,
                indices=[[oldest_idx]],
                updates=[new_key[0]]
            )
            
            self.memory_values = tf.tensor_scatter_nd_update(
                self.memory_values,
                indices=[[oldest_idx]],
                updates=[new_value[0]]
            )
            
            self.memory_ages = tf.tensor_scatter_nd_update(
                self.memory_ages,
                indices=[[oldest_idx]],
                updates=[0.0]
            )
        
        self.memory_ages.assign_add(1.0)
        
        if self.step % 100 == 0:
            forget_strength = tf.nn.sigmoid(self.forget_gate)
            self.memory_values.assign(
                self.memory_values * (1 - 0.01 * forget_strength[:, tf.newaxis])
            )
        
        return retrieved, attention_weights
    
    def read(self, query):
        return self.call(query, write=False)
    
    def write(self, key, value):
        ages_with_noise = self.memory_ages + tf.random.uniform(tf.shape(self.memory_ages)) * 0.1
        oldest_idx = tf.argmax(ages_with_noise)
        
        self.memory_keys = tf.tensor_scatter_nd_update(
            self.memory_keys,
            indices=[[oldest_idx]],
            updates=[key]
        )
        
        self.memory_values = tf.tensor_scatter_nd_update(
            self.memory_values,
            indices=[[oldest_idx]],
            updates=[value]
        )
        
        self.memory_ages = tf.tensor_scatter_nd_update(
            self.memory_ages,
            indices=[[oldest_idx]],
            updates=[0.0]
        )
    
    def get_memory_stats(self):
        return {
            'size': self.memory_size,
            'used': tf.reduce_sum(tf.cast(self.memory_access > 0, tf.float32)).numpy(),
            'avg_age': tf.reduce_mean(self.memory_ages).numpy(),
            'avg_access': tf.reduce_mean(self.memory_access).numpy(),
            'memory_keys_norm': tf.linalg.norm(self.memory_keys).numpy(),
            'memory_values_norm': tf.linalg.norm(self.memory_values).numpy()
        }
    
    def clear_memory(self):
        self.memory_keys.assign(tf.random.normal(tf.shape(self.memory_keys)))
        self.memory_values.assign(tf.zeros_like(self.memory_values))
        self.memory_ages.assign(tf.zeros_like(self.memory_ages))
        self.memory_access.assign(tf.zeros_like(self.memory_access))
    
    def get_config(self):
        config = super().get_config()
        config.update({
            'memory_size': self.memory_size,
            'key_dim': self.key_dim,
            'value_dim': self.value_dim,
            'num_heads': self.num_heads
        })
        return config


class DifferentiableMemory(layers.Layer):
    """
    ذاكرة قابلة للتفاضل
    """
    
    def __init__(self,
                 memory_size: int,
                 vector_dim: int,
                 **kwargs):
        super().__init__(**kwargs)
        self.memory_size = memory_size
        self.vector_dim = vector_dim
        
    def build(self, input_shape):
        self.memory = self.add_weight(
            name='memory_matrix',
            shape=(self.memory_size, self.vector_dim),
            initializer='random_normal',
            trainable=True
        )
        
        self.write_matrix = self.add_weight(
            name='write_matrix',
            shape=(input_shape[-1], self.memory_size),
            initializer='glorot_uniform',
            trainable=True
        )
        
        self.read_matrix = self.add_weight(
            name='read_matrix',
            shape=(self.memory_size, input_shape[-1]),
            initializer='glorot_uniform',
            trainable=True
        )
        
    def call(self, inputs):
        write_weights = tf.nn.softmax(tf.matmul(inputs, self.write_matrix), axis=-1)
        write_update = tf.matmul(write_weights, self.memory, transpose_a=True)
        
        self.memory.assign(self.memory * 0.9 + 0.1 * write_update)
        
        read_weights = tf.nn.softmax(tf.matmul(inputs, self.write_matrix), axis=-1)
        read_output = tf.matmul(read_weights, self.memory)
        
        return read_output
    
    def get_config(self):
        config = super().get_config()
        config.update({
            'memory_size': self.memory_size,
            'vector_dim': self.vector_dim
        })
        return config


class MemoryNetwork(layers.Layer):
    """
    شبكة ذاكرة كاملة
    """
    
    def __init__(self,
                 units: int,
                 memory_size: int = 1000,
                 **kwargs):
        super().__init__(**kwargs)
        self.units = units
        self.memory_size = memory_size
        
    def build(self, input_shape):
        self.ltm = LongTermMemory(
            memory_size=self.memory_size,
            key_dim=self.units,
            value_dim=self.units,
            name="ltm"
        )
        
        self.lstm_cell = layers.LSTMCell(self.units, name="stm")
        self.fusion = layers.Dense(self.units, activation='tanh', name="fusion")
        
        self.stm_state = None
        
    def call(self, inputs, training=False):
        batch_size = tf.shape(inputs)[0]
        
        if self.stm_state is None:
            self.stm_state = [
                tf.zeros((batch_size, self.units)),
                tf.zeros((batch_size, self.units))
            ]
        
        stm_out, self.stm_state = self.lstm_cell(inputs, self.stm_state)
        
        ltm_out, _ = self.ltm(inputs, training=training)
        
        combined = tf.concat([stm_out, ltm_out], axis=-1)
        output = self.fusion(combined)
        
        return output
    
    def reset_states(self):
        self.stm_state = None
    
    def get_config(self):
        config = super().get_config()
        config.update({
            'units': self.units,
            'memory_size': self.memory_size
        })
        return config


class AssociativeMemory(layers.Layer):
    """
    ذاكرة ترابطية
    """
    
    def __init__(self,
                 key_dim: int,
                 value_dim: int,
                 num_slots: int = 100,
                 **kwargs):
        super().__init__(**kwargs)
        self.key_dim = key_dim
        self.value_dim = value_dim
        self.num_slots = num_slots
        
    def build(self, input_shape):
        self.keys = self.add_weight(
            name='keys',
            shape=(self.num_slots, self.key_dim),
            initializer='random_normal',
            trainable=True
        )
        
        self.values = self.add_weight(
            name='values',
            shape=(self.num_slots, self.value_dim),
            initializer='zeros',
            trainable=True
        )
        
        self.temperature = self.add_weight(
            name='temperature',
            shape=(),
            initializer=tf.constant_initializer(1.0),
            trainable=True
        )
        
    def call(self, query):
        similarities = tf.matmul(query, self.keys, transpose_b=True) / self.temperature
        attention_weights = tf.nn.softmax(similarities, axis=-1)
        retrieved = tf.matmul(attention_weights, self.values)
        
        return retrieved, attention_weights
    
    def associate(self, key, value):
        similarities = tf.matmul(key[tf.newaxis, :], self.keys, transpose_b=True)[0]
        least_used = tf.argmin(similarities)
        
        self.keys = tf.tensor_scatter_nd_update(
            self.keys,
            indices=[[least_used]],
            updates=[key]
        )
        
        self.values = tf.tensor_scatter_nd_update(
            self.values,
            indices=[[least_used]],
            updates=[value]
        )
        
        return least_used
    
    def get_config(self):
        config = super().get_config()
        config.update({
            'key_dim': self.key_dim,
            'value_dim': self.value_dim,
            'num_slots': self.num_slots
        })
        return config


__all__ = [
    'MemoryCell',
    'LongTermMemory',
    'DifferentiableMemory',
    'MemoryNetwork',
    'AssociativeMemory'
]