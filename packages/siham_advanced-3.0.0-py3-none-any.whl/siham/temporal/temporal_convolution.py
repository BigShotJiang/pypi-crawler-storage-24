"""
TemporalConvNet: Temporal convolution network for sequence modeling.
"""

import tensorflow as tf
from tensorflow.keras import layers, Model

class TemporalConvNet(Model):
    def __init__(self, num_channels=64, kernel_size=3, num_layers=8, **kwargs):
        super().__init__(**kwargs)
        self.conv_layers = [
            tf.keras.Sequential([
                layers.Conv1D(num_channels, kernel_size, padding='causal', activation='relu'),
                layers.Dropout(0.1)
            ]) for _ in range(num_layers)
        ]
        self.output_layer = layers.Dense(128)

    def call(self, inputs, training=None):
        x = inputs
        for conv in self.conv_layers:
            x = conv(x)
        return self.output_layer(x)
