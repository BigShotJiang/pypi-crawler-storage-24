"""
PhysicsLSTM: LSTM infused with physical priors.
"""

import tensorflow as tf
from tensorflow.keras import layers, Model

class PhysicsLSTM(Model):
    def __init__(self, units=256, **kwargs):
        super().__init__(**kwargs)
        self.lstm = layers.LSTM(units, return_sequences=True)
        self.physics_prior = layers.Dense(units // 2, activation='tanh')  # Physics embedding
        self.fusion = layers.Add()

    def call(self, inputs, training=None):
        seq = self.lstm(inputs)
        prior = self.physics_prior(inputs)
        prior = tf.expand_dims(prior, 1)
        return self.fusion([seq, prior])
