"""
CrossModalEncoder: Encodes different modalities into shared representation space.
"""

import tensorflow as tf
from tensorflow.keras import layers, Model

class CrossModalEncoder(Model):
    def __init__(self, embed_dim=512, **kwargs):
        super().__init__(**kwargs)
        self.embed_dim = embed_dim
        
        # Modality-specific encoders
        self.text_encoder = tf.keras.Sequential([
            layers.Dense(embed_dim, activation='relu'),
            layers.Dense(embed_dim)
        ])
        self.image_encoder = tf.keras.Sequential([
            layers.Conv2D(embed_dim//8, 3, activation='relu'),
            layers.GlobalAveragePooling2D(),
            layers.Dense(embed_dim)
        ])
        self.audio_encoder = tf.keras.Sequential([
            layers.Dense(embed_dim, activation='relu'),
            layers.Dense(embed_dim)
        ])
        
        # Cross-attention
        self.cross_attention = layers.MultiHeadAttention(num_heads=8, key_dim=embed_dim // 8)

    def call(self, inputs, training=None):
        text, image, audio = inputs
        
        text_enc = self.text_encoder(text)
        image_enc = self.image_encoder(image)
        audio_enc = self.audio_encoder(audio)
        
        # Cross attend
        query = layers.Concatenate()([text_enc[:, None], image_enc[:, None], audio_enc[:, None]])
        key_value = layers.Concatenate()([text_enc[:, None], image_enc[:, None], audio_enc[:, None]])
        attended = self.cross_attention(query, key_value)
        
        return layers.GlobalAveragePooling1D()(attended)
