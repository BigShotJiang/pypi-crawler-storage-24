"""
FusionTransformer: Multi-modal fusion using transformer architecture.
Combines features from text, image, audio modalities.
"""

import tensorflow as tf
from tensorflow.keras import layers, Model

class FusionTransformer(Model):
    def __init__(self, embed_dim=512, num_heads=8, num_layers=6, **kwargs):
        super().__init__(**kwargs)
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.num_layers = num_layers
        
        # Projection layers for different modalities
        self.text_proj = layers.Dense(embed_dim)
        self.image_proj = layers.Dense(embed_dim)
        self.audio_proj = layers.Dense(embed_dim)
        
        # Shared transformer layers
        self.transformer_layers = [
            layers.MultiHeadAttention(num_heads=num_heads, key_dim=embed_dim // num_heads)
            for _ in range(num_layers)
        ]
        self.layer_norms = [layers.LayerNormalization() for _ in range(num_layers)]
        self.ffn = tf.keras.Sequential([
            layers.Dense(embed_dim * 4, activation='gelu'),
            layers.Dense(embed_dim)
        ])
        self.final_norm = layers.LayerNormalization()
        self.fusion_output = layers.Dense(embed_dim)

    def call(self, inputs, training=None):
        text_features, image_features, audio_features = inputs
        
        # Project to common dimension
        text_emb = self.text_proj(text_features)
        image_emb = self.image_proj(image_features)
        audio_emb = self.audio_proj(audio_features)
        
        # Concatenate modalities
        fused = layers.Concatenate()([text_emb, image_emb, audio_emb])
        
        # Apply transformer layers
        x = fused
        for attention, norm in zip(self.transformer_layers, self.layer_norms):
            attn_out = attention(x, x)
            x = norm(x + attn_out)
            ffn_out = self.ffn(x)
            x = norm(x + ffn_out)
        
        x = self.final_norm(x)
        return self.fusion_output(x)
