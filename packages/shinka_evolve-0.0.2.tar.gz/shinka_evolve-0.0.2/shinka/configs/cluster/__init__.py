"""Cluster config group."""
