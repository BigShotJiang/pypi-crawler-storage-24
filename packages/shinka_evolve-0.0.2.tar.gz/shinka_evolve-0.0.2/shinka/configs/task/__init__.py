"""Task config group."""
