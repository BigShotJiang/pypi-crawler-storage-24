"""Poller for async operations (clone, import, finalize)."""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any

from modelstudio.exceptions import TimeoutError


class OperationPoller:
    """Polls an async operation endpoint until a terminal status is reached."""

    def __init__(
        self,
        transport: Any,
        poll_url: str,
        terminal_statuses: set[str] | None = None,
        interval: float = 2.0,
        max_wait: float = 300.0,
    ) -> None:
        self._transport = transport
        self._poll_url = poll_url
        self._terminal = terminal_statuses or {"COMPLETED", "FAILED", "ERROR", "DONE"}
        self._interval = interval
        self._max_wait = max_wait

    def poll_once(self) -> dict[str, Any]:
        """Single poll, returns the status response dict."""
        return self._transport.get(self._poll_url)  # type: ignore[no-any-return]

    def wait(self, callback: Callable[[dict[str, Any]], None] | None = None) -> dict[str, Any]:
        """Block until terminal status. Optional progress callback called on each poll."""
        elapsed = 0.0
        while elapsed < self._max_wait:
            result = self.poll_once()
            if callback:
                callback(result)

            status = self._extract_status(result)
            if status and status.upper() in self._terminal:
                return result

            time.sleep(self._interval)
            elapsed += self._interval

        raise TimeoutError(
            f"Operation at {self._poll_url} did not complete within {self._max_wait}s"
        )

    @staticmethod
    def _extract_status(data: dict[str, Any]) -> str | None:
        """Extract status from common response shapes."""
        for key in ("status", "clone_status", "finalize_status", "import_status"):
            val = data.get(key)
            if val is not None:
                return str(val)
        return None
