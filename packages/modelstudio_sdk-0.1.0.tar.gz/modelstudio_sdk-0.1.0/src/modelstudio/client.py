"""ModelStudioClient — main entry point for the SDK."""

from __future__ import annotations

import os
from uuid import UUID

from modelstudio._http import HttpTransport
from modelstudio.resources.dataset import Dataset, DatasetsCollection


class ModelStudioClient:
    """Client for the Model Studio REST API.

    Usage::

        # Auto-configured from environment variables
        client = ModelStudioClient.from_env()

        # Or explicit
        client = ModelStudioClient(
            base_url="http://localhost:8081",
            jwt_token="eyJhbG...",
        )

        # List datasets
        datasets = client.datasets.list()

        # Work with a specific dataset
        ds = client.dataset("uuid-here")
        overview = ds.overview()
    """

    def __init__(
        self,
        base_url: str,
        jwt_token: str | None = None,
        timeout: float = 30.0,
        org_name: str | None = None,
    ) -> None:
        self._transport = HttpTransport(
            base_url=base_url,
            jwt_token=jwt_token,
            timeout=timeout,
            org_name=org_name,
        )
        self._base_url = base_url.rstrip("/")

    @classmethod
    def from_env(cls) -> ModelStudioClient:
        """Create client from environment variables.

        Reads:
            MODEL_STUDIO_API_URL: API base URL (required)
            MODEL_STUDIO_JWT: JWT token (optional)
            MODEL_STUDIO_ORG: Organization name (optional)
        """
        base_url = os.environ.get("MODEL_STUDIO_API_URL")
        if not base_url:
            raise ValueError(
                "MODEL_STUDIO_API_URL environment variable is required. "
                "Set it to the Model Studio API base URL "
                "(e.g. http://model-studio-api-service.model-studio.svc.cluster.local)"
            )
        return cls(
            base_url=base_url,
            jwt_token=os.environ.get("MODEL_STUDIO_JWT"),
            org_name=os.environ.get("MODEL_STUDIO_ORG"),
        )

    @property
    def datasets(self) -> DatasetsCollection:
        """Access dataset collection methods (list, create, merge)."""
        return DatasetsCollection(self._transport)

    def dataset(self, dataset_id: str | UUID) -> Dataset:
        """Get a Dataset resource bound to a specific dataset ID."""
        return Dataset(self._transport, str(dataset_id))

    def full_image_url(
        self, dataset_id: str | UUID, image_id: str | UUID, ext: str = "png"
    ) -> str:
        """Build a full image URL for direct browser/download use."""
        return f"{self._base_url}/api/v1/media/images/{dataset_id}/{image_id}.{ext}"

    def thumbnail_url(
        self,
        dataset_id: str | UUID,
        image_id: str | UUID,
        size: int,
        hash: str,
        ext: str = "webp",
    ) -> str:
        """Build a thumbnail URL."""
        return (
            f"{self._base_url}/api/v1/media/thumbs"
            f"/{dataset_id}/{image_id}_{size}.{ext}?h={hash}"
        )

    def close(self) -> None:
        """Close the underlying HTTP connection."""
        self._transport.close()

    def __enter__(self) -> ModelStudioClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
