"""Typed exception hierarchy mapped to API error envelope."""

from __future__ import annotations


class ModelStudioError(Exception):
    """Base exception for all Model Studio SDK errors."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        error_code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.error_code = error_code

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"status_code={self.status_code}, "
            f"error_code={self.error_code!r}, "
            f"message={self.message!r})"
        )


class BadRequestError(ModelStudioError):
    """400 Bad Request — invalid input or validation failure."""

    def __init__(self, message: str, error_code: str = "BadRequest") -> None:
        super().__init__(message, status_code=400, error_code=error_code)


class AuthenticationError(ModelStudioError):
    """401 Unauthorized — missing or invalid JWT token."""

    def __init__(self, message: str = "Unauthorized", error_code: str = "Unauthorized") -> None:
        super().__init__(message, status_code=401, error_code=error_code)


class NotFoundError(ModelStudioError):
    """404 Not Found — resource does not exist."""

    def __init__(self, message: str, error_code: str = "NotFound") -> None:
        super().__init__(message, status_code=404, error_code=error_code)


class ConflictError(ModelStudioError):
    """409 Conflict — operation conflicts with current state."""

    def __init__(self, message: str, error_code: str = "Conflict") -> None:
        super().__init__(message, status_code=409, error_code=error_code)


class ServerError(ModelStudioError):
    """500 Internal Server Error — unexpected server failure."""

    def __init__(
        self, message: str = "Internal server error", error_code: str = "InternalServerError"
    ) -> None:
        super().__init__(message, status_code=500, error_code=error_code)


class TimeoutError(ModelStudioError):
    """Polling timeout — async operation did not complete in time."""

    def __init__(self, message: str = "Operation timed out") -> None:
        super().__init__(message, status_code=None, error_code="Timeout")


# Map HTTP status codes to exception classes
STATUS_CODE_MAP: dict[int, type[ModelStudioError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    404: NotFoundError,
    409: ConflictError,
    500: ServerError,
}
