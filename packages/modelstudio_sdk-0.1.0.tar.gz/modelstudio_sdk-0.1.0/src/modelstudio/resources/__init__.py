"""Resource objects that map to API endpoints."""
