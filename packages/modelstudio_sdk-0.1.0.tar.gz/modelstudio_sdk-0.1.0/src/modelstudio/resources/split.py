"""Split sub-resource with per-split operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from uuid import UUID

from modelstudio.models.annotations import AnnotationModel
from modelstudio.models.exports import ExportCocoModel, SegmentationExportModel
from modelstudio.models.images import DatasetImageModel
from modelstudio.models.imports import (
    ImportQueuedModel,
    PreImportValidationModel,
    ValidationStartedModel,
)

if TYPE_CHECKING:
    from modelstudio._http import HttpTransport


class Split:
    """Operations on a specific split within a dataset.

    Access via ``client.dataset("ds-id").split("split-id")``.
    """

    def __init__(self, transport: HttpTransport, dataset_id: str, split_id: str) -> None:
        self._t = transport
        self._ds = dataset_id
        self._sid = split_id
        self._base = f"/api/v1/datasets/{dataset_id}/splits/{split_id}"

    # ── CRUD ──────────────────────────────────────────────────────────

    def patch_tao_id(self, tao_id: str | UUID) -> None:
        """Update the TAO ID for this split."""
        self._t.patch(self._base, json={"tao_id": str(tao_id)})

    # ── Images ────────────────────────────────────────────────────────

    def add_images(self, image_ids: list[str | UUID]) -> list[DatasetImageModel]:
        """Add images to this split."""
        data = self._t.post(
            f"{self._base}/images",
            json={"images": [{"image_id": str(i)} for i in image_ids]},
        )
        return [DatasetImageModel.model_validate(item) for item in data]

    def remove_image(self, dataset_image_id: str | UUID) -> None:
        """Remove an image from this split."""
        self._t.delete(f"{self._base}/images/{dataset_image_id}")

    def move_image(self, image_id: str | UUID, new_split_id: str | UUID) -> None:
        """Move an image to another split."""
        self._t.patch(
            f"{self._base}/images/{image_id}/move",
            json={"new_split_id": str(new_split_id)},
        )

    def list_images(self) -> list[DatasetImageModel]:
        """List all images in this split."""
        data = self._t.get(f"{self._base}/images")
        return [DatasetImageModel.model_validate(item) for item in data]

    # ── Annotations ─────────────────────────────────────────────────────

    def list_annotations(self) -> list[AnnotationModel]:
        """List all annotations in this split."""
        data = self._t.get(f"{self._base}/annotations")
        return [AnnotationModel.model_validate(item) for item in data]

    # ── DataFrame helpers ───────────────────────────────────────────────

    def images_df(self) -> Any:
        """Return images as a pandas DataFrame."""
        from modelstudio._pandas import to_dataframe

        return to_dataframe(self.list_images())

    def annotations_df(self) -> Any:
        """Return annotations as a pandas DataFrame."""
        from modelstudio._pandas import to_dataframe

        return to_dataframe(self.list_annotations())

    # ── Import ────────────────────────────────────────────────────────

    def import_from_source(
        self, source: str, type: str, config: dict[str, Any]
    ) -> ImportQueuedModel:
        """Start an import from a data source adapter (s3, labelbox, etc).

        Args:
            source: The data source (e.g. "s3", "labelbox").
            type: The import type (e.g. "coco", "segmentation").
            config: Source-specific configuration.
        """
        data = self._t.post_accepted(f"{self._base}/import/{source}/{type}", json=config)
        return ImportQueuedModel.model_validate(data)

    def import_segmentation(self, config: dict[str, Any]) -> SegmentationExportModel:
        """Import segmentation masks from S3."""
        data = self._t.post(f"{self._base}/import/s3/segmentation", json=config)
        return SegmentationExportModel.model_validate(data)

    def validate_import(self, config: dict[str, Any]) -> ValidationStartedModel:
        """Start pre-import validation."""
        data = self._t.post_accepted(f"{self._base}/import/s3/validate", json=config)
        return ValidationStartedModel.model_validate(data)

    def validation_status(self, validation_id: str) -> PreImportValidationModel:
        """Check validation status."""
        data = self._t.get(f"{self._base}/import/validate/{validation_id}")
        return PreImportValidationModel.model_validate(data)

    # ── Export ─────────────────────────────────────────────────────────

    def export_coco(
        self,
        reindex_images: bool = True,
        reindex_annotations: bool = True,
        reindex_categories: bool = True,
        starting_id: int = 1,
    ) -> ExportCocoModel:
        """Export this split as COCO JSON."""
        data = self._t.post(
            f"{self._base}/export/coco",
            json={
                "reindex_images": reindex_images,
                "reindex_annotations": reindex_annotations,
                "reindex_categories": reindex_categories,
                "starting_id": starting_id,
            },
        )
        return ExportCocoModel.model_validate(data)

    def export_segmentation(self) -> SegmentationExportModel:
        """Export segmentation masks for this split."""
        data = self._t.post(f"{self._base}/export/segmentation")
        return SegmentationExportModel.model_validate(data)
