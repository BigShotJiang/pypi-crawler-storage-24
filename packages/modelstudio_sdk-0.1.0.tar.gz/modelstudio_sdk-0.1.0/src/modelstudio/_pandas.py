"""Optional pandas DataFrame helpers (guarded import)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, TypeVar

from pydantic import BaseModel

if TYPE_CHECKING:
    import pandas as pd

T = TypeVar("T", bound=BaseModel)


def _get_pandas() -> Any:
    try:
        import pandas

        return pandas
    except ImportError:
        raise ImportError(
            "pandas is required for DataFrame operations. "
            "Install it with: pip install 'modelstudio-sdk[pandas]'"
        ) from None


def to_dataframe(items: list[T]) -> pd.DataFrame:
    """Convert a list of Pydantic models to a pandas DataFrame."""
    pd = _get_pandas()
    if not items:
        return pd.DataFrame()
    rows = [item.model_dump() for item in items]
    return pd.DataFrame(rows)
