"""HTTP transport layer wrapping httpx with auth and error mapping."""

from __future__ import annotations

from typing import Any

import httpx

from modelstudio.exceptions import (
    STATUS_CODE_MAP,
    AuthenticationError,
    ModelStudioError,
    ServerError,
)


class HttpTransport:
    """Thin httpx wrapper that injects auth headers and maps errors to typed exceptions."""

    def __init__(
        self,
        base_url: str,
        jwt_token: str | None = None,
        timeout: float = 30.0,
        org_name: str | None = None,
    ) -> None:
        headers: dict[str, str] = {
            "X-Source": "modelstudio-sdk",
            "Accept": "application/json",
        }
        if jwt_token:
            headers["Authorization"] = f"Bearer {jwt_token}"
        if org_name:
            headers["X-Org-Name"] = org_name

        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers=headers,
            timeout=timeout,
        )

    def close(self) -> None:
        self._client.close()

    # --- HTTP methods ---

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        resp = self._client.get(path, params=params)
        return self._handle(resp)

    def post(self, path: str, json: Any = None) -> Any:
        resp = self._client.post(path, json=json)
        return self._handle(resp)

    def put(self, path: str, json: Any = None) -> Any:
        resp = self._client.put(path, json=json)
        return self._handle(resp)

    def patch(self, path: str, json: Any = None) -> Any:
        resp = self._client.patch(path, json=json)
        return self._handle(resp)

    def delete(self, path: str, json: Any = None, params: dict[str, Any] | None = None) -> Any:
        if json is not None:
            req = self._client.build_request("DELETE", path, json=json, params=params)
            resp = self._client.send(req)
        else:
            resp = self._client.delete(path, params=params)
        return self._handle(resp)

    def delete_with_body(self, path: str, json: Any = None) -> Any:
        """DELETE with a JSON request body (e.g. bulk annotation delete)."""
        req = self._client.build_request("DELETE", path, json=json)
        resp = self._client.send(req)
        return self._handle(resp)

    def post_accepted(self, path: str, json: Any = None) -> Any:
        """POST that expects 202 Accepted (async operations)."""
        resp = self._client.post(path, json=json)
        return self._handle(resp)

    # --- Response handling ---

    def _handle(self, resp: httpx.Response) -> Any:
        if resp.status_code == 204:
            return None

        if resp.is_success:
            if not resp.content:
                return None
            return resp.json()

        self._raise_for_status(resp)

    def _raise_for_status(self, resp: httpx.Response) -> None:
        error_code = "Unknown"
        message = f"HTTP {resp.status_code}"

        try:
            body = resp.json()
            error_code = body.get("error", error_code)
            message = body.get("message", message)
        except Exception:
            message = resp.text or message

        exc_class = STATUS_CODE_MAP.get(resp.status_code)
        if exc_class:
            raise exc_class(message=message, error_code=error_code)

        if resp.status_code == 401:
            raise AuthenticationError(message=message)
        if resp.status_code >= 500:
            raise ServerError(message=message)
        raise ModelStudioError(
            message=message, status_code=resp.status_code, error_code=error_code
        )
