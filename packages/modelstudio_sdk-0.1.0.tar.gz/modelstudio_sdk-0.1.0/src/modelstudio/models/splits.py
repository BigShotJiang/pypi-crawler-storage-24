"""Split-related models."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel


class SplitModel(BaseModel):
    """Represents a dataset split."""

    split_id: UUID
    split_type: str | None = None
    tao_id: UUID | None = None
    name: str | None = None
    description: str | None = None
    created_on: datetime | None = None
    locked: bool = False
    uploaded: bool = False
    import_status: str | None = None
    import_progress: int | None = None
    import_error: str | None = None
    import_started_at: datetime | None = None
    import_finished_at: datetime | None = None
    import_source: str | None = None


class CreateSplitsResponse(BaseModel):
    """Response from POST /datasets/{id}/splits/create."""

    success: bool
    message: str | None = None
    splits: list[SplitModel] = []
    summary: dict[str, Any] | None = None


class RedistributeResponse(BaseModel):
    """Response from POST /datasets/{id}/splits/redistribute."""

    previous_distribution: dict[str, Any] | None = None
    new_distribution: dict[str, Any] | None = None


class SmartRedistributeResponse(BaseModel):
    """Response from POST /datasets/{id}/splits/smart-redistribute."""

    previous_distribution: dict[str, Any] | None = None
    new_distribution: dict[str, Any] | None = None
    class_distribution_error: dict[str, Any] | None = None
    iterations_used: int | None = None
    converged: bool | None = None


class LeakageResponse(BaseModel):
    """Response from POST /datasets/{id}/splits/check-leakage."""

    has_leakage: bool = False
    leakage_count: int = 0
    method: str | None = None
    leakages: list[dict[str, Any]] = []
    summary: dict[str, Any] | None = None


# ── Class-aware redistribute (replaces smart-redistribute) ───────────────


class SplitStats(BaseModel):
    """Per-split statistics in a class-aware redistribute response."""

    image_count: int = 0
    annotation_count: int = 0
    ratio: float = 0.0


class ClassError(BaseModel):
    """Per-class distribution error."""

    category_name: str | None = None
    target_ratio: float = 0.0
    actual_ratio: float = 0.0
    error: float = 0.0


class DistributionError(BaseModel):
    """Per-split distribution error breakdown."""

    split_name: str | None = None
    mean_error: float = 0.0
    max_error: float = 0.0
    class_errors: list[ClassError] = []


class AlgorithmStats(BaseModel):
    """Algorithm statistics from class-aware redistribution."""

    iterations_used: int = 0
    converged: bool = False
    final_error: float = 0.0
    elapsed_ms: int | None = None


class ClassAwareRedistributeResponse(BaseModel):
    """Response from POST /datasets/{id}/splits/class-aware-redistribute."""

    previous_distribution: dict[str, Any] | None = None
    new_distribution: dict[str, Any] | None = None
    split_stats: dict[str, SplitStats] | None = None
    distribution_errors: list[DistributionError] = []
    algorithm_stats: AlgorithmStats | None = None
