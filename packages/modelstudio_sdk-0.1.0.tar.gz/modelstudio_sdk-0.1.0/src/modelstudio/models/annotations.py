"""Annotation-related models."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from pydantic import BaseModel


class AnnotationModel(BaseModel):
    """COCO annotation."""

    annotation_id: int
    image_id: UUID
    category_id: int
    segmentation: Any | None = None
    bbox: list[float] = []
    ignore: bool = False
    iscrowd: bool = False
    area: float = 0.0
    keypoints: Any | None = None
    num_keypoints: int | None = None


class CreateAnnotationRequest(BaseModel):
    """Request for creating an annotation."""

    annotation_id: int | None = None
    image_id: UUID
    category_id: int
    segmentation: Any | None = None
    bbox: list[float] = []
    ignore: bool = False
    iscrowd: bool = False
    area: float = 0.0
    keypoints: Any | None = None
    num_keypoints: int | None = None


class UpdateAnnotationRequest(BaseModel):
    """Request for updating an annotation."""

    category_id: int | None = None
    segmentation: Any | None = None
    bbox: list[float] | None = None
    area: float | None = None
    iscrowd: bool | None = None
    ignore: bool | None = None


class DeleteAnnotationsResponse(BaseModel):
    """Response from DELETE /datasets/{id}/annotations."""

    success: bool = False
    message: str | None = None
    annotations_deleted: int = 0
    images_deleted: int = 0
    categories_deleted: int = 0


class PaginatedAnnotationModel(BaseModel):
    """An annotation in the paginated dataset-level annotation listing."""

    annotation_id: int
    image_id: UUID
    category_id: int
    segmentation: Any | None = None
    bbox: list[float] = []
    ignore: bool = False
    iscrowd: bool = False
    area: float = 0.0
    keypoints: Any | None = None
    num_keypoints: int | None = None
    category_name: str | None = None
    segmentation_type: str | None = None
    tags: list[str] = []
    confidence_score: float | None = None
    annotator_id: str | None = None
    status: str | None = None
