"""Oversample models."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from pydantic import BaseModel


class OversampleRequest(BaseModel):
    """Request for POST /datasets/{id}/oversample."""

    target_ratio: float
    strategy: str = "PREFER_ANNOTATED"
    seed: int | None = None
    target_split_id: UUID | None = None


class OversampleAnalysisModel(BaseModel):
    """Response from POST /datasets/{id}/oversample/analyze."""

    current_real_images: int = 0
    current_synthetic_images: int = 0
    current_ratio: float = 0.0
    target_ratio: float = 0.0
    oversample_target: int | str | None = None
    images_to_duplicate: int = 0
    selected_images: list[dict[str, Any]] = []


class OversampleResponseModel(BaseModel):
    """Response from POST /datasets/{id}/oversample."""

    success: bool = False
    message: str | None = None
    images_duplicated: int = 0
    annotations_duplicated: int = 0
    new_real_count: int = 0
    new_synthetic_count: int = 0
    new_ratio: float = 0.0
