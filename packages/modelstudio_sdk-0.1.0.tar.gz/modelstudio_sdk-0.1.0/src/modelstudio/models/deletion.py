"""Deletion check models."""

from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel


class ExperimentRefModel(BaseModel):
    """An experiment referencing a dataset."""

    experiment_id: UUID | None = None
    experiment_name: str | None = None


class DatasetRefModel(BaseModel):
    """A child dataset reference."""

    dataset_id: UUID | None = None
    dataset_name: str | None = None


class DeletionCheckModel(BaseModel):
    """Response from GET /datasets/{id}/can-delete."""

    can_delete: bool = False
    referencing_experiments: list[ExperimentRefModel] = []
    child_datasets: list[DatasetRefModel] = []
