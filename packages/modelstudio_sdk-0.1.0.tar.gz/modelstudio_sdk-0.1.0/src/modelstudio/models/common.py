"""Common/shared model types."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class PagedResponse(BaseModel):
    """Generic paged response wrapper matching the API's paginated response."""

    content: list[dict[str, Any]] = []
    total_elements: int = 0
    total_pages: int = 0
    page: int = 0
    size: int = 0
    facets: dict[str, Any] | None = None
