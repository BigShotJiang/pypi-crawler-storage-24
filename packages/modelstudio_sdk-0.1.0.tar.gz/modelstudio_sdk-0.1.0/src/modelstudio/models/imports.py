"""Import-related models."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel


class ImportQueuedModel(BaseModel):
    """Response from POST /datasets/{id}/splits/{sid}/import/{source} (202)."""

    split_id: UUID | None = None
    status: str | None = None
    progress: int = 0
    source: str | None = None
    poll_url: str | None = None


class ImportStatusModel(BaseModel):
    """Response from GET /datasets/{id}/splits/{sid}/import/status."""

    split_id: UUID | None = None
    status: str | None = None
    progress: int = 0
    error: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None


class ValidationIssueModel(BaseModel):
    """A single validation issue from pre-import validation."""

    check: str | None = None
    severity: str | None = None
    message: str | None = None
    entity_type: str | None = None
    entity_id: str | None = None
    details: dict[str, Any] | None = None


class ImportConflictModel(BaseModel):
    """A conflict found during pre-import validation."""

    type: str | None = None
    severity: str | None = None
    message: str | None = None
    details: dict[str, Any] | None = None
    options: list[str] = []


class PreImportSummaryModel(BaseModel):
    """Summary statistics from pre-import validation."""

    total_images: int = 0
    total_annotations: int = 0
    total_categories: int = 0
    empty_images: int = 0
    small_annotations: int = 0
    orphan_annotations: int = 0
    duplicate_annotations: int = 0
    unused_categories: int = 0
    invalid_bbox_count: int = 0
    zero_area_bbox_count: int = 0
    fixes_to_apply: list[str] = []


class PreImportValidationModel(BaseModel):
    """Response from GET /datasets/{id}/splits/{sid}/import/validate/{vid}."""

    validation_id: str | None = None
    status: str | None = None
    progress: int = 0
    can_proceed: bool = False
    error_count: int = 0
    warning_count: int = 0
    conflict_count: int = 0
    issues: list[ValidationIssueModel] = []
    conflicts: list[ImportConflictModel] = []
    summary: PreImportSummaryModel | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    error_message: str | None = None


class ValidationStartedModel(BaseModel):
    """Response from POST /datasets/{id}/splits/{sid}/import/s3/validate (202)."""

    validation_id: str | None = None
    status: str | None = None
    progress: int = 0
    poll_url: str | None = None


# ── Dataset-level import job models ──────────────────────────────────────


class ImportLogEntryModel(BaseModel):
    """A single log entry from an import job."""

    ts: datetime | None = None
    level: str | None = None
    message: str | None = None


class ImportJobModel(BaseModel):
    """A dataset-level import job."""

    job_id: UUID | None = None
    dataset_id: UUID | None = None
    split_id: UUID | None = None
    source: str | None = None
    dataset_type: str | None = None
    status: str | None = None
    progress: int = 0
    error_summary: str | None = None
    import_log: list[ImportLogEntryModel] | None = None
    images_imported: int | None = None
    source_details: dict[str, Any] | None = None
    canceled: bool = False
    created_at: datetime | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None


class ImportJobListModel(BaseModel):
    """Response from GET /datasets/{id}/imports."""

    jobs: list[ImportJobModel] = []


class ImportJobQueuedModel(BaseModel):
    """Response from POST /datasets/{id}/imports/{jobId}/retry (202)."""

    job_id: UUID | None = None
    split_id: UUID | None = None
    status: str | None = None
    source: str | None = None
    poll_url: str | None = None
