"""Validation and QA models."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from pydantic import BaseModel


class DuplicateItem(BaseModel):
    """A single image in a duplicate group."""

    image_id: UUID | None = None
    file_name: str | None = None
    split_name: str | None = None
    hash: str | None = None
    uri: str | None = None


class DuplicateGroup(BaseModel):
    """A group of duplicate images."""

    group_id: int = 0
    duplicate_type: str | None = None
    similarity: float = 0.0
    items: list[DuplicateItem] = []


class DuplicateCheckModel(BaseModel):
    """Response from POST /datasets/{id}/validate/duplicates."""

    has_duplicates: bool = False
    duplicate_group_count: int = 0
    total_duplicate_images: int = 0
    check_type: str | None = None
    hash_threshold: float = 0.95
    duplicate_groups: list[DuplicateGroup] = []
    summary: dict[str, Any] = {}


class ConflictAnnotation(BaseModel):
    """Annotation in a temporal conflict cluster."""

    split_id: UUID | None = None
    annotation_id: int = 0
    image_id: UUID | None = None
    image_file_name: str | None = None
    category_name: str | None = None
    category_id: int = 0
    bbox: list[float] = []
    capture_timestamp: str | None = None
    is_outlier: bool = False


class ConflictCluster(BaseModel):
    """A temporal conflict cluster."""

    cluster_id: int = 0
    tile_id: str | None = None
    annotations: list[ConflictAnnotation] = []
    distinct_categories: int = 0
    suggested_category: str | None = None
    confidence: float = 0.0


class TemporalConflictModel(BaseModel):
    """Response from POST /datasets/{id}/qa/temporal-conflicts."""

    has_conflicts: bool = False
    clusters: list[ConflictCluster] = []


class ResolveTemporalConflictResponse(BaseModel):
    """Response from POST /datasets/{id}/qa/temporal-conflicts/resolve."""

    success: bool = False
    message: str | None = None
    dataset_id: str | None = None
    clusters_resolved: int = 0
    annotations_updated: int = 0


class ValidationResultsModel(BaseModel):
    """Generic validation results."""

    valid: bool = True
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
