"""Dataset merge models."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class MergeDatasetRequest(BaseModel):
    """Request for POST /datasets/merge."""

    source_dataset_ids: list[str]
    target_name: str
    target_description: str | None = None
    include_categories: list[str] | None = None
    keep_images_with_no_annotations: bool = True
    conflict_strategy: str | None = None
    category_mapping: dict[str, str] | None = None


class MergePreviewModel(BaseModel):
    """Response from POST /datasets/merge/preview."""

    total_images: int = 0
    total_annotations: int = 0
    total_categories: int = 0
    merged_categories: list[str] = []
    warnings: list[str] = []
    source_contributions: dict[str, Any] = {}


class MergeAnalysisModel(BaseModel):
    """Response from POST /datasets/merge/analyze."""

    all_categories: list[dict[str, Any]] = []
    conflicts: list[dict[str, Any]] = []
    suggested_mapping: dict[str, str] = {}
    has_conflicts: bool = False


class MergeResponseModel(BaseModel):
    """Response from POST /datasets/merge."""

    new_dataset_id: str | None = None
    new_dataset_name: str | None = None
    status: str | None = None
    images_created: int = 0
    annotations_created: int = 0
    categories_created: int = 0
    category_id_mapping: dict[str, int] = {}
