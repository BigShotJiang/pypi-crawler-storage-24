"""Category-related models."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class CategoryModel(BaseModel):
    """A dataset category."""

    category_id: int
    name: str
    supercategory: str | None = None
    annotation_count: int = 0
    image_count: int = 0
    pixel_count: int | None = None
    pixel_percentage: float | None = None
    area_m2: float | None = None


class CategoryListModel(BaseModel):
    """Response from GET /datasets/{id}/categories."""

    categories: list[CategoryModel] = []
    total_categories: int = 0
    total_annotations: int = 0


class MergeCategoriesResponse(BaseModel):
    """Response from POST /datasets/{id}/categories/merge."""

    merged: bool = False
    target_id: int | None = None
    target_name: str | None = None
    affected_annotations: int = 0
    deleted_categories: list[str] = []


class RenameCategoryResponse(BaseModel):
    """Response from PUT /datasets/{id}/categories/{cid}/rename."""

    old_name: str | None = None
    new_name: str | None = None
    category_id: int | None = None
    affected_annotations: int = 0


class RemoveCategoryResponse(BaseModel):
    """Response from DELETE /datasets/{id}/categories/{cid}."""

    removed: Any = None
    category_id: int | None = None
    annotations_affected: int = 0
    action_taken: str | None = None


class ConsolidateLabelsResponse(BaseModel):
    """Response from POST /datasets/{id}/categories/consolidate."""

    consolidated: Any = None
    mapping_applied: dict[str, Any] | None = None
    total_annotations_updated: int = 0


class MergeBySupercategoryResponse(BaseModel):
    """Response from POST /datasets/{id}/categories/merge-by-supercategory."""

    supercategory: str | None = None
    target_category_name: str | None = None
    target_category_id: int | None = None
    categories_merged: int = 0
    merged_categories: list[str] = []
    annotations_affected: int = 0


class SplitCategoryResponse(BaseModel):
    """Response from POST /datasets/{id}/categories/split."""

    operation_id: str | None = None
    source_category_name: str | None = None
    target_categories: list[str] = []
    annotations_to_assign: int = 0


class CancelSplitCategoryResponse(BaseModel):
    """Response from DELETE /datasets/{id}/categories/split/{opId}."""

    operation_id: str | None = None
    source_category_name: str | None = None
    target_categories_expected: int = 0
    target_categories_deleted: int = 0
    status: str | None = None


class MergeSourcesResponse(BaseModel):
    """Response from GET /datasets/{id}/categories/{cid}/merge-sources."""

    dataset_id: str | None = None
    category_id: int | None = None
    category_name: str | None = None
    has_merge_history: bool = False
    leaf_categories: list[dict[str, Any]] = []
    merge_chain: list[dict[str, Any]] = []
    suggested_split_request: dict[str, Any] | None = None
