"""History and undo/redo models."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class HistoryEntryModel(BaseModel):
    """A single change in the dataset history."""

    change_id: UUID | None = None
    sequence_number: int | None = None
    operation_type: str | None = None
    short_description: str | None = None
    detailed_description: str | None = None
    changed_on: datetime | None = None
    changed_by: str | None = None
    is_undone: bool = False
    is_reversible: bool = True


class HistoryModel(BaseModel):
    """Response from GET /datasets/{id}/history."""

    dataset_id: UUID | None = None
    current_position: int = 0
    total_changes: int = 0
    can_undo: bool = False
    can_redo: bool = False
    changes: list[HistoryEntryModel] = []


class PreviewModel(BaseModel):
    """Response from GET /datasets/{id}/history/preview-undo or preview-redo."""

    can_perform: bool = False
    description: str | None = None
    operation_type: str | None = None
    changed_on: datetime | None = None


class UndoRedoResponse(BaseModel):
    """Response from POST /datasets/{id}/history/undo or redo."""

    success: bool = False
    description: str | None = None
    new_position: int = 0


class RewindResponse(BaseModel):
    """Response from POST /datasets/{id}/history/rewind."""

    success: bool = False
    operations_applied: int = 0
    new_position: int = 0
