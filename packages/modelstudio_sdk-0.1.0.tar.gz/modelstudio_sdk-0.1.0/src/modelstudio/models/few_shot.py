"""Few-shot dataset creation models."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from pydantic import BaseModel


class FewShotRequest(BaseModel):
    """Request for POST /datasets/{id}/few-shot."""

    num_images: int
    method: str = "RANDOM"
    specific_image_ids: list[UUID] | None = None
    specific_file_names: list[str] | None = None
    new_dataset_name: str | None = None
    new_dataset_description: str | None = None
    seed: int | None = None


class FewShotPreviewModel(BaseModel):
    """Response from POST /datasets/{id}/few-shot/preview."""

    selected_image_count: int = 0
    total_annotations: int = 0
    selected_images: list[dict[str, Any]] = []
    class_coverage: dict[str, Any] = {}


class FewShotResponseModel(BaseModel):
    """Response from POST /datasets/{id}/few-shot."""

    success: bool = False
    message: str | None = None
    new_dataset_id: str | None = None
    new_dataset_name: str | None = None
    images_included: int = 0
    annotations_included: int = 0
    categories_included: int = 0
