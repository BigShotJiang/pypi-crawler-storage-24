"""Image-related models."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class ImageModel(BaseModel):
    """Core image metadata."""

    image_id: UUID
    file_name: str | None = None
    hash: str | None = None
    width: int = 0
    height: int = 0
    file_type: str | None = None
    source_info: str | None = None
    path: str | None = None
    uri: str | None = None
    created_on: datetime | None = None
    coco_id: int | None = None
    storage_connection_id: UUID | None = None
    full_tile_id: str | None = None
    tile_spec: str | None = None
    gsd_meters: float | None = None
    is_synthetic: bool | None = None
    mask_uri: str | None = None
    mask_format: str | None = None
    band_count: int | None = None
    band_names: str | None = None
    pixel_data_type: str | None = None
    preview_uri: str | None = None


class DatasetImageModel(BaseModel):
    """Image as part of a dataset split."""

    dataset_image_id: UUID | None = None
    split_id: UUID | None = None
    image: ImageModel | None = None
    added_on: datetime | None = None
    thumb_url: str | None = None


class SyntheticStatsModel(BaseModel):
    """Response from GET /datasets/{id}/images/synthetic/stats."""

    total_images: int = 0
    real_images: int = 0
    synthetic_images: int = 0
    synthetic_ratio: float = 0.0


class RemoveEmptyImagesResponse(BaseModel):
    """Response from DELETE /datasets/{id}/images/empty."""

    success: bool = False
    message: str | None = None
    images_removed: int = 0
    removed_images: list[dict[str, object]] = []


class MarkSyntheticResponse(BaseModel):
    """Response from PUT /datasets/{id}/images/synthetic."""

    success: bool = False
    message: str | None = None
    images_updated: int = 0


class PaginatedImageModel(BaseModel):
    """An image in the paginated dataset-level image listing."""

    dataset_image_id: UUID | None = None
    image: ImageModel | None = None
    added_on: datetime | None = None
    thumb_url: str | None = None
    mask_uri: str | None = None
    mask_format: str | None = None
    mask_version: int | None = None
    annotation_count: int = 0
    tags: list[str] = []
    file_size: int | None = None
    cloud_cover: float | None = None
    off_nadir_angle: float | None = None
    sensor_type: str | None = None
    provider: str | None = None
    constellation: str | None = None
