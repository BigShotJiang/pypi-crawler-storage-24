"""Media job models."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class MediaJobErrorModel(BaseModel):
    """A single error from a media processing job."""

    job_id: UUID | None = None
    image_id: UUID | None = None
    image_name: str | None = None
    error: str | None = None
    updated_at: datetime | None = None


class MediaJobStatusModel(BaseModel):
    """Aggregate status of media processing jobs for a dataset."""

    total: int = 0
    queued: int = 0
    processing: int = 0
    done: int = 0
    error: int = 0
    recent_errors: list[MediaJobErrorModel] = []


class MediaJobActionModel(BaseModel):
    """Response from a media job action (retry, cancel)."""

    action: str | None = None
    count: int = 0
    message: str | None = None
