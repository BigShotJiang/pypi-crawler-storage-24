"""Export-related models."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class ExportCocoModel(BaseModel):
    """Response from POST /datasets/{id}/export/coco."""

    coco_json: dict[str, Any] | None = None
    image_count: int = 0
    annotation_count: int = 0
    category_count: int = 0
    image_id_mapping: dict[str, int] | None = None
    annotation_id_mapping: dict[str, int] | None = None
    category_id_mapping: dict[str, int] | None = None
    reindexed: bool = False


class SegmentationExportModel(BaseModel):
    """Response from POST /datasets/{id}/splits/{sid}/export/segmentation."""

    split_id: str | None = None
    images_archive_uri: str | None = None
    masks_archive_uri: str | None = None
    categories_uri: str | None = None
    image_count: int = 0
    mask_count: int = 0
    images_without_masks: list[str] = []
