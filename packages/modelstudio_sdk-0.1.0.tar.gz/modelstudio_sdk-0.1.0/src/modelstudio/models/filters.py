"""Filter-related models."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class CategoryFilter(BaseModel):
    """Category filter options."""

    keep_categories: list[str] | None = None
    keep_category_ids: list[int] | None = None
    exclude_mode: bool = False


class BboxFilter(BaseModel):
    """Bounding box filter options."""

    min_width: float | None = None
    max_width: float | None = None
    min_height: float | None = None
    max_height: float | None = None
    min_area: float | None = None
    max_area: float | None = None
    min_aspect_ratio: float | None = None
    max_aspect_ratio: float | None = None
    min_width_meters: float | None = None
    max_width_meters: float | None = None
    min_height_meters: float | None = None
    max_height_meters: float | None = None
    min_area_m2: float | None = None
    max_area_m2: float | None = None


class AnnotationCountFilter(BaseModel):
    """Annotation count filter options."""

    min_annotations_per_image: int | None = None
    max_annotations_per_image: int | None = None
    count_only_categories: list[str] | None = None


class DatasetFilterRequest(BaseModel):
    """Request for POST /datasets/{id}/filter."""

    category_filter: CategoryFilter | None = None
    bbox_filter: BboxFilter | None = None
    annotation_count_filter: AnnotationCountFilter | None = None
    consolidate_labels: dict[str, str] | None = None
    output_mode: str | None = None
    new_dataset_name: str | None = None
    new_dataset_description: str | None = None
    dry_run: bool = False


class FilterStatisticsModel(BaseModel):
    """Filter operation statistics."""

    original_images: int = 0
    original_annotations: int = 0
    original_categories: int = 0
    filtered_images: int = 0
    filtered_annotations: int = 0
    filtered_categories: int = 0
    removed_by_filter: dict[str, int] = {}
    category_distribution: dict[str, Any] = {}


class DatasetFilterResponse(BaseModel):
    """Response from POST /datasets/{id}/filter."""

    success: bool = False
    message: str | None = None
    mode: str | None = None
    coco_json: dict[str, Any] | None = None
    new_dataset_id: str | None = None
    new_dataset_name: str | None = None
    statistics: FilterStatisticsModel | None = None
    dry_run: bool = False
