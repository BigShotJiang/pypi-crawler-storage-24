"""Dataset-related models."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel

from modelstudio.models.splits import SplitModel


class DatasetModel(BaseModel):
    """Represents a dataset from GET /api/v1/datasets."""

    id: UUID
    parent_dataset_id: UUID | None = None
    name: str
    dataset_type: str
    format: str
    description: str | None = None
    created_on: datetime | None = None
    locked: bool = False
    uploaded: bool = False
    splits: list[SplitModel] = []
    clone_status: str | None = None
    clone_progress: int = 0
    clone_error: str | None = None
    clone_started_at: datetime | None = None
    clone_finished_at: datetime | None = None
    finalize_status: str | None = None
    finalize_progress: int = 0
    finalize_message: str | None = None
    finalize_started_at: datetime | None = None
    finalize_finished_at: datetime | None = None


class CloneStatusModel(BaseModel):
    """Clone operation status."""

    clone_status: str | None = None
    clone_progress: int = 0
    clone_error: str | None = None
    clone_started_at: datetime | None = None
    clone_finished_at: datetime | None = None


class FinalizeStatusModel(BaseModel):
    """Finalize operation status."""

    finalize_status: str | None = None
    finalize_progress: int = 0
    finalize_message: str | None = None
    finalize_started_at: datetime | None = None
    finalize_finished_at: datetime | None = None
