"""Metrics and statistics models (OverviewDto + 11 nested types)."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class DescriptiveStats(BaseModel):
    """Reusable descriptive statistics for any numeric distribution."""

    count: int = 0
    min: float = 0.0
    max: float = 0.0
    mean: float = 0.0
    median: float = 0.0
    mode: float | None = None
    std_dev: float = 0.0
    variance: float = 0.0
    q1: float = 0.0
    q3: float = 0.0
    iqr: float = 0.0
    p5: float = 0.0
    p95: float = 0.0
    skewness: float | None = None
    outlier_count: int = 0


class AspectRatioDistribution(BaseModel):
    """Aspect ratio distribution for images."""

    portrait: int = 0
    landscape: int = 0
    square: int = 0
    min_ratio: float = 0.0
    max_ratio: float = 0.0
    avg_ratio: float = 0.0
    median_ratio: float = 0.0


class ImageDimensionStats(BaseModel):
    """Image dimension statistics."""

    min_width: int = 0
    max_width: int = 0
    avg_width: float = 0.0
    median_width: float = 0.0
    mode_width: int | None = None
    std_dev_width: float = 0.0
    q1_width: float = 0.0
    q3_width: float = 0.0
    p5_width: float = 0.0
    p95_width: float = 0.0
    outlier_count_width: int = 0
    min_height: int = 0
    max_height: int = 0
    avg_height: float = 0.0
    median_height: float = 0.0
    mode_height: int | None = None
    std_dev_height: float = 0.0
    q1_height: float = 0.0
    q3_height: float = 0.0
    p5_height: float = 0.0
    p95_height: float = 0.0
    outlier_count_height: int = 0
    aspect_ratio: AspectRatioDistribution | None = None


class SyntheticBreakdown(BaseModel):
    """Breakdown of real vs synthetic images."""

    real_images: int = 0
    synthetic_images: int = 0
    synthetic_ratio: float = 0.0


class AnnotationDistribution(BaseModel):
    """Annotation count distribution across images."""

    per_image_stats: DescriptiveStats | None = None
    buckets: dict[str, int] = {}


class CategoryStats(BaseModel):
    """Per-category statistics with bbox dimension statistics."""

    category_name: str | None = None
    annotation_count: int = 0
    bbox_width_stats: DescriptiveStats | None = None
    bbox_height_stats: DescriptiveStats | None = None
    bbox_area_stats: DescriptiveStats | None = None
    zero_area_count: int = 0
    out_of_bounds_count: int = 0
    crowd_count: int = 0
    ignored_count: int = 0
    avg_coverage_percent: float = 0.0


class SegmentationCategoryStats(BaseModel):
    """Per-category pixel coverage stats for segmentation datasets."""

    category_name: str | None = None
    image_count: int = 0
    total_pixel_count: int = 0
    pixel_percentage: float = 0.0
    avg_coverage_percent: float = 0.0
    pixel_count_stats: DescriptiveStats | None = None
    area_m2: float | None = None
    avg_area_m2_per_image: float | None = None


class DataQualityMetrics(BaseModel):
    """Data quality metrics for a split."""

    empty_image_count: int = 0
    empty_image_percent: float = 0.0
    crowd_annotation_count: int = 0
    crowd_annotation_percent: float = 0.0
    ignored_annotation_count: int = 0
    ignored_annotation_percent: float = 0.0
    annotations_with_segmentation: int = 0
    annotations_with_keypoints: int = 0


class ClassImbalance(BaseModel):
    """Class imbalance information for a split."""

    top_class_name: str | None = None
    top_class_count: int = 0
    top_class_share: float = 0.0
    imbalance_score: float = 0.0


class SplitStatistics(BaseModel):
    """Complete statistics for a single split."""

    image_count: int = 0
    annotation_count: int = 0
    category_count: int = 0
    image_dimensions: ImageDimensionStats | None = None
    images_by_format: dict[str, int] = {}
    synthetic_breakdown: SyntheticBreakdown | None = None
    annotation_distribution: AnnotationDistribution | None = None
    per_category_stats: dict[str, CategoryStats] = {}
    data_quality: DataQualityMetrics | None = None
    class_imbalance: ClassImbalance | None = None
    segmentation_category_stats: dict[str, SegmentationCategoryStats] | None = None


class DatasetSummary(BaseModel):
    """Dataset-level summary derived from per-split statistics."""

    total_images: int = 0
    total_annotations: int = 0
    total_categories: int = 0
    distinct_classes: int = 0


class OverviewModel(BaseModel):
    """Comprehensive dataset overview from GET /datasets/{id}/metrics/overview."""

    summary: DatasetSummary | None = None
    splits: dict[str, SplitStatistics] = {}
    category_co_occurrence: dict[str, dict[str, int]] = {}


class ClassDistributionModel(BaseModel):
    """Response from GET /datasets/{id}/metrics/class-distribution."""

    classes: list[dict[str, Any]] = []
    totals: dict[str, Any] = {}


class BinnedModel(BaseModel):
    """Response from GET /datasets/{id}/metrics/bbox-area."""

    bins: list[dict[str, Any]] = []
    bin_type: str | None = None
    image_area_norm: bool = False
