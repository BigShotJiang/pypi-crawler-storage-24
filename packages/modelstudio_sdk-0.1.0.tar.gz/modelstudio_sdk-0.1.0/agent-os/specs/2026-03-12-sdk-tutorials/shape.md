# SDK Tutorials — Shaping Notes

## Audience
Data scientists fluent in Python and pandas, working inside JupyterHub containers.

## Decisions
- **Live API calls with saved outputs**: Notebooks include saved cell outputs so they're readable without running.
- **One auth cell per notebook**: Each notebook is self-contained with `ModelStudioClient.from_env()` at the top.
- **Read-only vs mutation notebooks**: Notebooks 01, 02, 04 are read-only safe. Notebooks 03, 05, 06 mutate data and use undo to clean up.
- **Progressive complexity**: Start with connection/discovery, build up to advanced workflows.
- **Reference dataset**: "SDK - Read Only" matches integration test fixtures.

## Scope
- IN: All major SDK resource methods, DataFrame helpers, error handling patterns
- OUT: Finalization, lock, niche methods (rewind, merge_by_supercategory, assign_split_category, URL builders)

## Style
- Clear markdown headers separating sections
- Code cells with print() output (not just return values) for clarity
- Mutation cells always paired with undo
- Conceptual code blocks (shown but not executed) for destructive/setup operations
