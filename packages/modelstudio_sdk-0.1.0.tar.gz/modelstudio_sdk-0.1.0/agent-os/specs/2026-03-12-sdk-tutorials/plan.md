# SDK Tutorial Notebooks & README

## Goal
Create a structured set of 6 tutorial notebooks covering the full SDK surface, plus a README index.

## Notebooks
1. **01-getting-started.ipynb** — Connection, discovery, first look
2. **02-exploring-data.ipynb** — Images, annotations, metrics, DataFrame integration
3. **03-category-management.ipynb** — Category CRUD, merging, label consolidation
4. **04-import-export.ipynb** — Import jobs, media jobs, COCO export
5. **05-annotations.ipynb** — Annotation CRUD, bulk operations, ingestion
6. **06-advanced-workflows.ipynb** — Splits, redistribution, filtering, few-shot, cloning, history

## Other Files
- `tutorials/README.md` — Overview, prerequisites, auth setup, notebook index
- `agent-os/specs/2026-03-12-sdk-tutorials/` — This spec

## Coverage
~50 of ~73 public SDK methods demonstrated across 6 notebooks.

## Reference Dataset
"SDK - Read Only" for read-only notebooks, "SDK - Mutations" for mutation notebooks.
