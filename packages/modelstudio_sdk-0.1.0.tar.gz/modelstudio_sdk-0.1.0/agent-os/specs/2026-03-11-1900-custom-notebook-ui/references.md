# Custom Notebook UI — References

## SDK Repo — Source Files

| File | Purpose |
|------|---------|
| `docker/docker-compose.yml` | Add `jupyter-server` service (headless, CORS) |
| `develop.sh` | Add `--mode notebook-server` |
| `Makefile` | Add `notebook-server` / `notebook-server-down` targets |

## Frontend Repo — New Files

| File | Purpose |
|------|---------|
| `src/services/jupyter/types.ts` | Jupyter API type definitions |
| `src/services/jupyter/JupyterService.ts` | REST client (sessions, kernels, contents) |
| `src/services/jupyter/JupyterWebSocketManager.ts` | WebSocket kernel protocol handler |
| `src/services/jupyter/messageBuilder.ts` | Wire-protocol message builder |
| `src/store/notebook_store.ts` | MobX store for notebook state |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/NotebookPanel.tsx` | Main panel component |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/NotebookPanel.module.scss` | Panel styles |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/NotebookToolbar.tsx` | Run/restart/save toolbar |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/CellList.tsx` | Scrollable cell container |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/Cell.tsx` | Cell wrapper |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/CodeCell.tsx` | CodeMirror 6 editor |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/CellOutput.tsx` | Output dispatcher |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/CellControls.tsx` | Add/delete/move buttons |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/KernelStatusBadge.tsx` | Kernel state indicator |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/outputs/StreamOutput.tsx` | stdout/stderr |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/outputs/RichOutput.tsx` | Images, HTML |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/outputs/ErrorOutput.tsx` | Tracebacks with ANSI |

## Frontend Repo — Modified Files

| File | Change |
|------|--------|
| `src/pages/ModelStudio/Layout/AppBar/AppBar.tsx` | Add Notebook button + Drawer |
| `src/store/store.ts` | Register NotebookStore |
| `vite.config.ts` | Add `/jupyter` proxy |

## Other Repos

| Repo | File | Change |
|------|------|--------|
| `model-studio-notebooks` | (none) | No changes — JupyterHub/KubeSpawner unchanged |

## External Dependencies

| Dependency | Purpose |
|-----------|---------|
| `jupyter/scipy-notebook:python-3.10` | Docker base image |
| `@codemirror/*` | Code editor for cells |
| `ansi-to-react` | ANSI color rendering for tracebacks |

## Reference Implementations

| File | Pattern |
|------|---------|
| `frontend/src/pages/ModelStudio/Agent/AgentChatPanel/AgentChatPanel.tsx` | Drawer panel layout |
| `frontend/src/store/agent_chat_store.ts` | MobX store + streaming |
| `frontend/src/pages/ModelStudio/Layout/AppBar/AppBar.tsx` | Button + drawer mounting |
| `frontend/src/api/axiosWithAuth.ts` | Non-hook axios factory |
