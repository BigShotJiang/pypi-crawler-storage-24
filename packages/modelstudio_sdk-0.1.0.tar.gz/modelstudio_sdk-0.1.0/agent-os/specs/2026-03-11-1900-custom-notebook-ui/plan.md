# Custom Notebook UI — Implementation Plan

## Context

The SDK is complete with 77 passing integration tests and a working Docker-based JupyterLab environment. The next step is building a **custom notebook UI** integrated into the Model Studio frontend, replacing JupyterLab's interface with our own React-based notebook experience.

**Architecture (local dev):**
```
React Frontend (Model Studio)  →  Vite proxy  →  Jupyter Server (Docker)  →  Python Kernel
```

**Architecture (production):**
```
React Frontend  →  JupyterHub API (spawn/route)  →  per-user Jupyter Server (K8s pod)  →  Kernel
```

---

## Task 1: Jupyter Server Infrastructure (SDK Repo)

**Goal**: Headless Jupyter Server in Docker, accessible via Vite proxy from frontend.

### Files modified:
- `docker/docker-compose.yml` — add `jupyter-server` service (headless, CORS for localhost)
- `develop.sh` — add `--mode notebook-server`
- `Makefile` — add `notebook-server` / `notebook-server-down` targets

### Verification:
- `make notebook-server` starts Jupyter Server on :8888
- `fetch('/jupyter/api/kernelspecs')` returns kernel list from frontend dev server

---

## Task 2: Jupyter Service Layer (Frontend)

**Goal**: TypeScript service classes for Jupyter Server REST API and WebSocket kernel protocol.

### New files:
- `src/services/jupyter/types.ts` — Jupyter API type definitions
- `src/services/jupyter/JupyterService.ts` — REST API client (uses `axiosWithAuth`)
- `src/services/jupyter/JupyterWebSocketManager.ts` — WebSocket kernel protocol handler
- `src/services/jupyter/messageBuilder.ts` — Wire-protocol message builder

---

## Task 3: NotebookStore (MobX)

**Goal**: Observable state management for the notebook.

### New files:
- `src/stores/NotebookStore.ts` — MobX store with cell CRUD, execution, session management

### Modified files:
- `src/store/store.ts` — register `NotebookStore`

---

## Task 4: Notebook Panel UI (Frontend)

**Goal**: React components for the notebook drawer overlay.

### New files:
- `src/pages/ModelStudio/Notebooks/NotebookPanel/NotebookPanel.tsx`
- `src/pages/ModelStudio/Notebooks/NotebookPanel/NotebookPanel.module.scss`
- `src/pages/ModelStudio/Notebooks/NotebookPanel/NotebookToolbar.tsx`
- `src/pages/ModelStudio/Notebooks/NotebookPanel/CellList.tsx`
- `src/pages/ModelStudio/Notebooks/NotebookPanel/Cell.tsx`
- `src/pages/ModelStudio/Notebooks/NotebookPanel/CodeCell.tsx`
- `src/pages/ModelStudio/Notebooks/NotebookPanel/CellOutput.tsx`
- `src/pages/ModelStudio/Notebooks/NotebookPanel/CellControls.tsx`
- `src/pages/ModelStudio/Notebooks/NotebookPanel/KernelStatusBadge.tsx`
- `src/pages/ModelStudio/Notebooks/NotebookPanel/outputs/StreamOutput.tsx`
- `src/pages/ModelStudio/Notebooks/NotebookPanel/outputs/RichOutput.tsx`
- `src/pages/ModelStudio/Notebooks/NotebookPanel/outputs/ErrorOutput.tsx`

### Modified files:
- `src/pages/ModelStudio/Layout/AppBar/AppBar.tsx` — add Notebook button + Drawer

---

## Task 5: Vite Proxy Configuration

### Modified files:
- `vite.config.ts` — add `/jupyter` proxy to localhost:8888 with WebSocket support

---

## Task 6: End-to-End Integration + Polish

### Functionality:
- Panel opens → auto-starts Jupyter session + kernel
- Shift+Enter → execute cell, move to next
- Ctrl+Enter → execute cell, stay in place
- Outputs render inline: text, images, error tracebacks
- Save notebook to Jupyter contents API (.ipynb format)
- Restart/interrupt kernel
- Panel close → prompt to save if dirty, stop session
- Expand/collapse width with smooth transition

### Edge cases:
- WebSocket disconnect → show "Disconnected" badge, auto-reconnect
- Long outputs → scroll within cell output area
- Kernel restart while cells running → clear execution states
