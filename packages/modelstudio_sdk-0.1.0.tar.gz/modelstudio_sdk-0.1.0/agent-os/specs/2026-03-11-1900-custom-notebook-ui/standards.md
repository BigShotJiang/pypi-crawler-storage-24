# Custom Notebook UI — Standards

## Frontend

- **React 18** with functional components and hooks
- **MobX 6** for state management (`makeAutoObservable`, `runInAction` for async)
- **Mantine 8** for UI components (Box, Paper, Group, Stack, Drawer, Tooltip)
- **SCSS modules** for component-scoped styles with Mantine CSS variables
- **Dark/light mode** via `:global([data-mantine-color-scheme='light'])`
- **Tabler Icons** for all iconography
- **observer** HOC from `mobx-react-lite` for reactive components
- **axiosWithAuth** factory for authenticated HTTP calls (not hooks)
- **Path aliases**: `import { appStore } from 'store/store'` resolves to `src/store/store.ts`

## Jupyter Protocol

- **Jupyter Server REST API v2** for session/kernel/contents management
- **Jupyter Messaging Protocol 5.x** for WebSocket kernel communication
- **Wire format**: JSON messages with `header`, `parent_header`, `metadata`, `content`, `buffers`
- **Message types**: `execute_request`, `execute_reply`, `stream`, `display_data`, `execute_result`, `error`, `status`
- **Session/kernel lifecycle**: Create session → get kernel ID → connect WebSocket → execute

## Docker

- **Base image**: `jupyter/scipy-notebook:python-3.10` (same as existing notebook service)
- **Headless mode**: No JupyterLab UI served; `--ServerApp.default_url=/api`
- **Token-less auth**: `IdentityProvider.token=''` for local dev only
- **CORS**: `allow_origin='http://localhost:5173'`, `allow_credentials=true`
- **XSRF disabled**: `disable_check_xsrf=true` for local dev (production uses JupyterHub)

## NPM Dependencies (new)

- `@codemirror/view`, `@codemirror/state`, `@codemirror/commands`, `@codemirror/lang-python` — CodeMirror 6
- `ansi-to-react` — ANSI color rendering for error tracebacks

## Unchanged

- SDK Python package conventions (pydantic v2, httpx sync, from_env contract)
- JupyterHub / KubeSpawner production architecture (model-studio-notebooks repo)
- Frontend build tooling (Vite, TypeScript, ESLint, Prettier)
