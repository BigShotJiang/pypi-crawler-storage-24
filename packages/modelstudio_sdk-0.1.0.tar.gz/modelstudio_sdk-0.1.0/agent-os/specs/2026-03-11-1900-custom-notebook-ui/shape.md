# Custom Notebook UI — Shape

## Scope

**In:**
- Headless Jupyter Server Docker service (SDK repo)
- Vite proxy for `/jupyter` → localhost:8888
- TypeScript Jupyter REST + WebSocket service layer
- MobX NotebookStore for cell state and execution
- React notebook panel (drawer overlay, right side)
- CodeMirror 6 editor for code cells
- Output rendering (text, images, tracebacks)
- Keyboard shortcuts (Shift+Enter, Ctrl+Enter)
- Save/load .ipynb via Jupyter Contents API

**Out:**
- JupyterHub multi-user integration (stays in model-studio-notebooks repo)
- Markdown cell rendering (Phase 2)
- Cell drag-and-drop reordering (Phase 2)
- Variable inspector / debugger
- Terminal access
- File browser (beyond notebook open/save)
- Collaborative editing

## Key Decisions

- **Drawer overlay** (not full page): Same pattern as Agent panel — available from any Model Studio page without navigation. Opens from AppBar button, right side.
- **CodeMirror 6** (not Monaco): Lightweight, purpose-built for notebook cells. Monaco is too heavy for multiple editor instances per cell.
- **Headless Jupyter Server**: Disable JupyterLab UI in Docker service; frontend is the only UI. Saves container resources.
- **Token-less local dev**: `IdentityProvider.token=''` for local Docker. Production auth handled by JupyterHub.
- **CORS for localhost**: `ServerApp.allow_origin='http://localhost:5173'` enables Vite dev server access.
- **axiosWithAuth for REST**: Follows existing frontend API pattern. WebSocket auth handled separately via URL token parameter.
- **Separated service layer**: JupyterService (HTTP) + JupyterWebSocketManager (WS) + NotebookStore (state) — each owns one concern.
- **Panel width**: Default 480px (wider than Agent's 720px — needs more room for code), expandable to 60% viewport.
- **zIndex 3999**: Below Agent drawer (4000) so Agent can overlay notebook if both open.

## Risk Areas

- **WebSocket reliability**: Kernel connections can drop. Mitigated with exponential backoff reconnection.
- **Large outputs**: Cell outputs (e.g., large DataFrames, many images) can bloat DOM. Mitigated with max-height + overflow scroll per cell output.
- **CodeMirror instances**: Many cells = many editor instances. CodeMirror 6 is lightweight enough; lazy-mount editors only for visible cells if performance becomes an issue.
- **XSRF disabled locally**: `disable_check_xsrf=true` is dev-only. Production uses JupyterHub's auth layer.
