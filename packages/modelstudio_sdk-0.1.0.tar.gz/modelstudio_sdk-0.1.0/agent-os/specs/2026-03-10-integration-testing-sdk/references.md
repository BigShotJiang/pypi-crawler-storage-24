# References — Integration Testing & Validation

## Source Files

| File | Purpose |
|------|---------|
| `src/modelstudio/_http.py` | HTTP transport with auth + error mapping |
| `src/modelstudio/client.py` | Main entry point |
| `src/modelstudio/exceptions.py` | Exception hierarchy |
| `src/modelstudio/resources/dataset.py` | Dataset endpoints (~50 methods) |
| `src/modelstudio/resources/split.py` | Split endpoints (~20 methods) |
| `src/modelstudio/models/*.py` | Pydantic v2 response/request DTOs |
| `src/modelstudio/_polling.py` | OperationPoller for async ops |
| `src/modelstudio/_pandas.py` | Optional DataFrame helpers |

## Test Files

| File | Purpose |
|------|---------|
| `tests/integration/conftest.py` | Integration fixtures |
| `tests/integration/test_connectivity.py` | Auth validation (new) |
| `tests/integration/test_read_only.py` | Read-only tests (expanded) |
| `tests/integration/test_mutations.py` | Mutation tests (expanded) |
| `tests/integration/test_advanced_ops.py` | Advanced operations (new) |
| `tests/integration/test_async_ops.py` | Clone/finalize polling (new) |
| `tests/integration/test_merge.py` | Merge operations (new) |

## Scripts

| File | Purpose |
|------|---------|
| `scripts/get-token.sh` | Keycloak token acquisition |
| `scripts/smoke_test.py` | E2E validation script (new) |

## Config

| File | Purpose |
|------|---------|
| `pyproject.toml` | Project config, pytest markers |
| `Makefile` | Build/test targets |
