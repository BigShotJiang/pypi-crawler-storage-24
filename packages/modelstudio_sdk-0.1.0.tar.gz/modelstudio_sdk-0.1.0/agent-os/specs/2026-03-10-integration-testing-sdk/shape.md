# Shaping Notes — Integration Testing & Validation

## Scope

**In**:
- Fix `delete()` JSON body bug
- Connectivity tests (health, auth, invalid token)
- Expanded read-only tests (~10 new)
- Expanded mutation tests (~8 new)
- Advanced operation tests (categories, splits, filters, few-shot, oversample)
- Async operation tests (clone/finalize polling)
- Merge operation tests
- Smoke test script for quick E2E validation
- Model field fixes found during live API testing

**Out**:
- CI/CD pipeline integration
- Performance/load testing
- Async httpx support
- New SDK features

## Key Decisions

- **Rich test dataset**: Module-scoped fixture with splits, categories, and images for thorough testing
- **Failure triage buckets**: A (model mismatch), B (URL wrong), C (body wrong), D (auth), E (error envelope), F (test logic)
- **Smoke test**: Standalone Python script (not pytest) for quick validation without test framework overhead
- **Test isolation**: Mutation tests use throwaway datasets with cleanup; read-only tests use existing data

## Auth Pattern

Keycloak password grant -> JWT -> env vars -> `ModelStudioClient.from_env()`.
Token script: `source <(scripts/get-token.sh)`

## Risk Areas

- `AnnotationModel.image_id` typed as UUID — API may return integer COCO ID
- OIDC guard may return non-JSON 401 bodies
- Model fields may have been added/changed since SDK was scaffolded
