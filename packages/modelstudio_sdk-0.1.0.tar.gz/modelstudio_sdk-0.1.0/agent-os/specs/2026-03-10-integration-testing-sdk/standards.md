# Standards — Integration Testing & Validation

## SDK Conventions

- Pydantic v2 models with snake_case fields matching API JSON
- Typed exceptions mapped from API error envelope `{"error": "...", "message": "..."}`
- Guarded pandas import in `_pandas.py`
- `from_env()` reads `MODEL_STUDIO_API_URL`, `MODEL_STUDIO_JWT`, `MODEL_STUDIO_ORG`
- Sync httpx only — no async

## Testing Conventions

- pytest with `@pytest.mark.integration` marker
- Session-scoped `api_client` fixture from env vars
- Module-scoped `test_dataset` fixture with cleanup
- Graceful skip when env vars missing
- MockTransport for unit tests

## Error Mapping

| HTTP Status | Exception Class |
|-------------|----------------|
| 400 | BadRequestError |
| 401 | AuthenticationError |
| 404 | NotFoundError |
| 409 | ConflictError |
| 500 | ServerError |

## API Patterns

- Resource pattern: `client.datasets.list()`, `client.dataset("id").overview()`
- Sub-resource: `client.dataset("id").split("sid").list_images()`
- Async ops return immediately; use `.wait()` pollers to block
- Request bodies use `model_dump(exclude_none=True)` to avoid null fields
