# Integration Testing & Validation — model-studio-sdk

## Context

Phase 1 SDK implementation is complete (48 unit tests, 84% coverage). The SDK covers all 77 DatasetsController endpoints. Now we need to validate every endpoint against the live deployed API at `https://model-studio-api.model-studio.privateer-dev.com`, fix any mismatches (model fields, URL paths, error handling), and expand integration test coverage from ~20 methods to full coverage.

**Auth**: Keycloak OIDC at `keycloak.model-studio.privateer-dev.com`, realm `elements`, client `model-studio-frontend`. Token via `scripts/get-token.sh`.

---

## Tasks

1. **Save Spec Documentation** — This plan, shape.md, standards.md, references.md
2. **Fix Known SDK Bug** — `delete()` drops JSON body in `_http.py:64`
3. **Verify Connectivity & Run Existing Tests** — test_connectivity.py, triage failures
4. **Fix SDK Issues Found** — Model fields, URL paths, error handling
5. **Expand Integration Test Coverage** — ~30+ new tests across 5 files
6. **Create Smoke-Test Script** — `scripts/smoke_test.py` for quick E2E validation
7. **Full Regression & Cleanup** — lint, unit tests, integration tests, smoke test

## Verification

```bash
source <(scripts/get-token.sh)
make test-unit
make lint
make test-integration
python scripts/smoke_test.py
```
