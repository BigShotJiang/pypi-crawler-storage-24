# Key File References

## Source Files
- `src/modelstudio/_pandas.py` -- `to_dataframe()` and `_get_pandas()` helpers
- `src/modelstudio/resources/dataset.py:562-575` -- `categories_df()`, `class_distribution_df()`
- `src/modelstudio/resources/split.py:174-186` -- `images_df()`, `annotations_df()`
- `src/modelstudio/client.py` -- `ModelStudioClient`, `from_env()` constructor

## Test Files
- `tests/helpers.py` -- `MockTransport`, `FAKE_BASE`, `FAKE_JWT`, `FAKE_DS_ID`, `FAKE_SPLIT_ID`
- `tests/conftest.py` -- Root test fixtures (`mock_transport`, `client`)
- `tests/test_resources/test_dataset.py` -- Existing dataset unit tests (pattern reference)
- `tests/test_resources/test_split.py` -- Existing split unit tests (pattern reference)

## New Files (this phase)
- `tests/test_pandas.py` -- Pandas DataFrame unit tests
- `tests/integration/__init__.py` -- Integration test package
- `tests/integration/conftest.py` -- Integration test fixtures
- `tests/integration/test_read_only.py` -- Read-only integration tests
- `tests/integration/test_mutations.py` -- Mutation integration tests
- `scripts/get-token.sh` -- Keycloak token helper

## Config Files
- `pyproject.toml` -- pytest markers, dependencies
- `Makefile` -- test targets
