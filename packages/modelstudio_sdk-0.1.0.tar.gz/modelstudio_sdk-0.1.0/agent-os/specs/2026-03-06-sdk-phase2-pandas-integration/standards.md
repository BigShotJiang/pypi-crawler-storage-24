# Standards Applied

## SDK Conventions (from CLAUDE.md)
- All public methods have docstrings
- Guarded pandas import via `_pandas.py` module
- Pydantic v2 patterns for model validation
- Type hints everywhere (strict mypy)

## Testing Conventions
- Unit tests use `MockTransport` from `tests/helpers.py`
- Integration tests use `@pytest.mark.integration` marker
- Fixtures follow pytest scoping best practices
- Integration tests skip gracefully when env vars are missing

## Auth Pattern
- JWT token from Keycloak `password` grant
- Env vars: `MODEL_STUDIO_API_URL`, `MODEL_STUDIO_JWT`
- `ModelStudioClient.from_env()` reads these automatically

## Error Mapping
- 400 -> `BadRequestError`
- 401 -> `AuthenticationError`
- 404 -> `NotFoundError`
- 409 -> `ConflictError`
- 500 -> `ServerError`
