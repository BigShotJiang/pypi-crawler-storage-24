# SDK Phase 2: Pandas Tests + Integration Tests

## Context

The Model Studio Python SDK (Issue #1) has Phase 1 complete: 48 unit tests, 54 Dataset methods, 20 Split methods covering all 65+ DatasetsController endpoints. Two gaps remain per the acceptance criteria:

1. **Pandas DataFrame helpers have zero test coverage** (4 helpers exist but untested)
2. **No integration tests against a live API** (all tests use mocked transport)

The deployed API at `https://model-studio-api.model-studio.privateer-dev.com` uses Keycloak JWT auth (realm: `elements`). The API has a `ParseOnlyJwtDecoder` behind the oidc-guard -- it parses the JWT without signature validation since the upstream sidecar already validated it.

## Tasks

### Task 1: Spec Documentation
Create this spec directory with plan, shape, standards, and references.

### Task 2: Token Helper Script
`scripts/get-token.sh` -- Calls Keycloak token endpoint to fetch fresh JWT, exports as `MODEL_STUDIO_JWT`.

### Task 3: Pandas DataFrame Unit Tests
`tests/test_pandas.py` -- 7 tests covering `to_dataframe()`, `_get_pandas()`, and DataFrame helper methods on Dataset and Split.

### Task 4: Integration Test Infrastructure
- Register `integration` pytest marker in `pyproject.toml`
- Add `test-unit` and `test-integration` Makefile targets
- Create `tests/integration/conftest.py` with session-scoped fixtures

### Task 5: Read-Only Integration Tests
`tests/integration/test_read_only.py` -- ~18 tests against existing data (no mutations).

### Task 6: Mutation Integration Tests
`tests/integration/test_mutations.py` -- ~8 tests that create/modify/delete datasets.

## Verification

```bash
# Pandas tests (offline)
make test  # All 55+ tests pass

# Integration tests (requires token)
source <(scripts/get-token.sh)
make test-integration

# Full suite
make test  # integration tests auto-skip without env vars
```
