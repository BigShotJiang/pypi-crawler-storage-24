# Shape: SDK Phase 2 Scope Decisions

## What's In

- Unit tests for all 4 pandas DataFrame helpers (`to_dataframe`, `_get_pandas`, `images_df`, `annotations_df`, `categories_df`, `class_distribution_df`)
- Integration test infrastructure (markers, fixtures, Makefile targets)
- Read-only integration tests against live API (~18 tests)
- Mutation integration tests with cleanup (~8 tests)
- Token helper script for dev/test use

## What's Out

- No async/parallel test execution
- No CI integration (integration tests require credentials)
- No performance/load testing
- No coverage requirements for integration tests (they test the real API, not code paths)

## Key Decisions

### Auth Pattern
- Use Keycloak `password` grant (resource owner credentials) for simplicity
- Token fetched interactively via `scripts/get-token.sh`, never stored in files
- Integration tests skip automatically when `MODEL_STUDIO_JWT` is not set

### Test Data Strategy
- Read-only tests use `any_dataset` fixture -- picks first available dataset
- Mutation tests use `test_dataset` fixture -- creates fresh dataset, deletes on teardown
- Minimal COCO payload for ingestion (1 image, 1 annotation, 1 category)

### Fixture Scoping
- `api_client`: session-scoped (one HTTP connection for all tests)
- `any_dataset` / `any_split`: session-scoped (reuse existing data)
- `test_dataset`: module-scoped (fresh per test module, cleaned up after)
