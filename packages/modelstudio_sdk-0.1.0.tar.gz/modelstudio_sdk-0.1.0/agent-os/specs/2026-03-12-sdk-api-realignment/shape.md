# Shaping Notes

## Scope

- Align SDK with current DatasetsController.java API surface
- Move import/annotation/image operations from split-level to dataset-level
- Add media job management endpoints
- Rename smart-redistribute to class-aware-redistribute
- Remove obsolete split-level methods

## Key Decisions

- Deprecated models kept but marked with docstring deprecation notices
- `PagedResponse` updated to match API's generic paginated response shape
- New paginated models (`PaginatedImageModel`, `PaginatedAnnotationModel`) added
- `delete()` on transport gains `params` support for query parameters
- DataFrame helpers moved from Split to Dataset level
