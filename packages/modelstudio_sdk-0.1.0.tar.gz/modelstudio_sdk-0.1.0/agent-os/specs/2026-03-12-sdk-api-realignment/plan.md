# Plan: Refactor SDK to Match Updated DatasetsController API

## Context

The Model Studio API (`DatasetsController.java`) has evolved since the SDK was built. Key changes include: import management moved from split-level to dataset-level job management, new media job endpoints, paginated image/annotation listing at dataset level, annotation CRUD moved to dataset level, `smart-redistribute` renamed to `class-aware-redistribute`, and several split-level endpoints removed. The SDK and all tests need to be updated to match the current API contract.

## Tasks

1. Save spec documentation
2. Add new models (media, imports, images, annotations, common, splits)
3. Modify HTTP transport (params on delete)
4. Refactor Dataset resource (+15 methods, modify 6, remove 3)
5. Refactor Split resource (remove 10 methods, modify 1)
6. Update unit tests
7. Update integration tests
8. Lint and verify
