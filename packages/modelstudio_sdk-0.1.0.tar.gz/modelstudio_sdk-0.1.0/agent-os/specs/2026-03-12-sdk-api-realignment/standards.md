# Standards

- Pydantic v2 models with snake_case fields matching API JSON
- Typed exceptions mapped from API error envelope
- Sync httpx only (no async)
- `from_env()` contract: MODEL_STUDIO_API_URL, MODEL_STUDIO_JWT, MODEL_STUDIO_ORG
- Guarded pandas import via `_pandas.py`
- `model_dump(exclude_none=True)` for request bodies
