# References — SDK Deploy & Notebooks

## Source Files (this repo)

| File | Purpose |
|------|---------|
| `.gitlab-ci.yml` | CI/CD pipeline (rewritten) |
| `src/modelstudio/_version.py` | Version placeholder for CI injection |
| `docker/Dockerfile.dev` | Local dev JupyterLab image (new) |
| `docker/docker-compose.yml` | Docker compose orchestration (new) |
| `docker/requirements.txt` | ML packages for dev notebooks (new) |
| `docker/.env.example` | Environment variable template (new) |
| `notebooks/getting-started.ipynb` | SDK onboarding notebook (new) |
| `develop.sh` | Dev entry point (docker mode added) |
| `Makefile` | Build targets (docker targets added) |
| `.gitignore` | Ignore patterns (notebook checkpoints added) |

## Other Repos

| Repo | File | Change |
|------|------|--------|
| model-studio-notebooks | `ops/helm/model-studio-notebooks/values.yaml` | Keycloak realm + client + auth_state_hook |
| keycloak-config | `config/environments.json` | Redirect URI for notebooks |
| privateer-dev | `service-values/elements/model-studio-notebooks/values.yaml` | Remove client_secret |
| privateer-dev | `argocd-config/app-of-apps/elements.yaml` | Bump version hashes |

## External Dependencies

| Dependency | Purpose |
|------------|---------|
| `orbitalinsight/devops/oi_cicd` (v0.3) | Shared GitLab CI templates |
| `PYPI_TOKEN` CI variable | PyPI authentication for twine upload |
| `on_prem` + `cpu` runners | GitLab runner tags |
| `jupyter/scipy-notebook` Docker image | Base image for local dev |
| Keycloak `elements` realm | OIDC authentication |
| Keycloak `login-ui` client | Public OIDC client for JupyterHub |
