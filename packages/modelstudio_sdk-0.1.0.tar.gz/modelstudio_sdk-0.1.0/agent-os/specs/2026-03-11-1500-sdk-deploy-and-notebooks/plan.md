# SDK Deploy & Notebooks — Plan

## Context

The SDK (Phase 1) is complete with 77 passing integration tests. Notebooks repo has Dockerfile, Helm chart, and CI/CD pipeline scaffolded. Three workstreams remain before end-to-end notebook deployment is operational: SDK publishing to PyPI, notebook deployment with correct Keycloak config, and a Docker-based local dev environment for UI development.

---

## Tasks

### Task 1: Save Spec Documentation

Create `agent-os/specs/2026-03-11-1500-sdk-deploy-and-notebooks/` with plan, shape, standards, and references files capturing all shaping decisions.

### Task 2: SDK CI/CD + PyPI Publishing

Add GitLab CI pipeline and PyPI release workflow, modeled after elements-sdk.

**Files to modify:**
- `.gitlab-ci.yml` — Rewrite with 4 stages: sast, secret-detection, ci-build, pypi-release
- `src/modelstudio/_version.py` — Change to `"0.0.0.dev0"` (CI sed replaces on release)

**Pipeline design:**
```
sast            -> Security/SAST + Secret-Detection templates
ci-build        -> lint (ruff + mypy) + test (pytest -m "not integration")
pypi-release    -> manual trigger on release-* branches, builds wheel, uploads via twine
```

**Key details:**
- Include `orbitalinsight/devops/oi_cicd` templates (v0.3) for code quality
- Runner tags: `on_prem`, `cpu`
- Calendar versioning: branch `release-2026.03.11` -> version `2026.03.11`
- CI sed command: `sed -i 's/__version__ = .*/__version__ = "'"$PIP_VERSION"'"/' src/modelstudio/_version.py`
- Package name on PyPI: `modelstudio-sdk` (already in pyproject.toml)

**Prerequisites (manual):**
- Add `PYPI_TOKEN` as masked CI/CD variable in GitLab project settings
- Confirm runners tagged `on_prem` + `cpu` are available
- Confirm access to `orbitalinsight/devops/oi_cicd` project

### Task 3: Notebook Keycloak Configuration

Switch JupyterHub from non-existent `model-studio` realm to existing `elements` realm with `login-ui` client.

**Files to modify (other repos):**

| Repo | File | Change |
|------|------|--------|
| model-studio-notebooks | `ops/helm/.../values.yaml` | Switch to `login-ui` client, `elements` realm, add auth_state_hook |
| keycloak-config | `config/environments.json` | Add redirect URI for notebooks |
| privateer-dev | `service-values/.../values.yaml` | Remove `client_secret` override |
| privateer-dev | `argocd-config/.../elements.yaml` | Bump version hashes |

**Deployment sequence:**
1. keycloak-config first (redirect URI must exist before JupyterHub uses it)
2. model-studio-notebooks second
3. privateer-dev bumps both version hashes

### Task 4: Docker-Based Local Development

Single-command Docker dev environment in the SDK repo that runs JupyterLab with editable SDK.

**New files:**
| File | Purpose |
|------|---------|
| `docker/Dockerfile.dev` | jupyter/scipy-notebook + ML packages + editable SDK install |
| `docker/docker-compose.yml` | Ports, volume mounts, env vars |
| `docker/requirements.txt` | ML packages mirroring notebooks repo |
| `docker/.env.example` | Template for API URL + JWT |
| `notebooks/getting-started.ipynb` | Starter notebook |

**Modified files:**
| File | Change |
|------|--------|
| `develop.sh` | Add `--mode docker` |
| `Makefile` | Add `docker` and `docker-down` targets |
| `.gitignore` | Add notebook checkpoints |

---

## Verification

### SDK CI/CD:
- Push test branch -> confirm lint + test jobs pass in GitLab
- Create `release-2026.03.11` branch -> confirm pypi_release job appears as manual action
- Trigger release -> verify package appears on PyPI

### Keycloak + Notebooks:
- After keycloak-config deploy: verify redirect URI in Keycloak admin UI
- After notebooks deploy: navigate to notebooks URL -> should redirect to elements realm login
- After login: `ModelStudioClient.from_env()` should work without manual token setup

### Docker local dev:
- `./develop.sh --mode docker` -> JupyterLab opens at localhost:8888
- Edit SDK source on host -> change visible in notebook import
- Run getting-started notebook -> SDK calls succeed against dev API
