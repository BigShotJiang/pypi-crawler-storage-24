# Shaping Notes — SDK Deploy & Notebooks

## Scope

**In:**
- GitLab CI pipeline rewrite with SAST, secret-detection, lint/test, PyPI release
- Calendar versioning via release branch naming convention
- Dev version placeholder in `_version.py` (CI sed replaces on release)
- Docker-based local dev environment (Dockerfile.dev, docker-compose, .env)
- Getting-started notebook for SDK onboarding
- develop.sh `--mode docker` integration
- Makefile docker targets
- Keycloak configuration documentation (elements realm, login-ui client)

**Out:**
- Async httpx support
- New SDK features or endpoints
- Production notebook Dockerfile changes (lives in model-studio-notebooks repo)
- Keycloak realm creation (elements realm already exists)
- ArgoCD deployment automation

## Key Decisions

- **Calendar versioning**: `release-2026.03.11` branch name -> `2026.03.11` package version. Matches elements-sdk convention. CI extracts version from branch name via sed.
- **Dev version `0.0.0.dev0`**: Prevents accidental publication of unversioned builds. PEP 440 compliant dev marker.
- **Manual PyPI release trigger**: Release job requires manual click in GitLab UI, preventing accidental publishes. Only available on `release-*` branches.
- **`oi_cicd` templates**: Include Orbital's shared CI templates for consistent code quality scanning across projects.
- **Docker dev uses jupyter/scipy-notebook**: Matches production notebook image base, includes numpy/scipy/matplotlib out of the box.
- **Volume mounts for live editing**: `src/` mounted into container so SDK changes are immediately available without rebuild.
- **Token-less JupyterLab**: Local dev disables token/password for frictionless access. Not a security concern for localhost.
- **Keycloak `login-ui` client**: Public OIDC client (no client_secret needed), already configured in elements realm. JupyterHub auth_state_hook passes access_token as `MODEL_STUDIO_JWT` env var to notebook pods.

## Risk Areas

- **Runner availability**: Pipeline requires `on_prem` + `cpu` tagged runners. If unavailable, jobs will pend indefinitely.
- **PYPI_TOKEN**: Must be added as masked CI/CD variable before first release.
- **Docker volume performance on macOS**: `:cached` flag mitigates but large repos may still see latency.
- **JWT expiry in notebooks**: Keycloak tokens expire (default 5 min access, 30 min refresh). Long-running notebook sessions may need token refresh logic (future enhancement).
