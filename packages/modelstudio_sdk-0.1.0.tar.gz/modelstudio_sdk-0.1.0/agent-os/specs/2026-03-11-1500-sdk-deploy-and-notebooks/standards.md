# Standards — SDK Deploy & Notebooks

## CI/CD Conventions

- GitLab CI with `include` for security scanning templates
- Shared templates from `orbitalinsight/devops/oi_cicd` (v0.3)
- Runner tags: `on_prem`, `cpu` for all jobs
- Calendar versioning: `release-YYYY.MM.DD` branch -> `YYYY.MM.DD` version
- Version injection via sed in CI, not committed to repo
- Manual trigger for PyPI release (never auto-publish)
- Unit tests only in CI (`-m "not integration"`)

## Versioning

- `_version.py` holds `"0.0.0.dev0"` in source
- hatchling reads version dynamically from `_version.py`
- CI release job: extracts version from branch name, sed-replaces `_version.py`, builds wheel
- PEP 440 compliant: dev versions sort below any release

## Docker Conventions

- `docker/Dockerfile.dev` for local development only (not production)
- `docker/docker-compose.yml` for orchestration
- `.env` file for secrets (gitignored)
- `.env.example` for documentation (committed)
- Volume mounts for live code editing
- No authentication on local JupyterLab

## SDK Conventions (unchanged)

- Pydantic v2 models with snake_case fields matching API JSON
- Typed exceptions mapped from API error envelope
- Guarded pandas import in `_pandas.py`
- `from_env()` reads `MODEL_STUDIO_API_URL`, `MODEL_STUDIO_JWT`, `MODEL_STUDIO_ORG`
- Sync httpx only — no async

## Keycloak Integration

- Realm: `elements` (shared across Orbital apps)
- Client: `login-ui` (public OIDC client, no client_secret)
- JupyterHub uses GenericOAuthenticator with `enable_auth_state: true`
- auth_state_hook injects `access_token` as `MODEL_STUDIO_JWT` env var in spawned notebooks
- Redirect URIs must be pre-registered in keycloak-config before deployment
