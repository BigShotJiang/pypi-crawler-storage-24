#!/usr/bin/env bash
#
# develop.sh - Single-command dev setup for the Model Studio SDK.
# Creates/activates a conda env, installs deps, and runs the requested mode.
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Conda environment
CONDA_ENV="model-studio-sdk"
PYTHON_VERSION="3.10"

# Defaults
MODE=""
SKIP_AUTH=false

# ─── Argument parsing ────────────────────────────────────────────────
usage() {
    cat <<EOF
Usage: ./develop.sh --mode <MODE> [OPTIONS]

Set up the Model Studio SDK dev environment (conda + deps) and run a task.

Modes (required):
  setup              Create/activate conda env and install deps
  test               Run unit tests
  test-integration   Fetch Keycloak token and run integration tests
  lint               Run ruff + mypy
  docker             Build and start JupyterLab with editable SDK mount
  notebook-server    Start headless Jupyter Server for custom notebook UI

Options:
  --skip-auth        Skip Keycloak token fetch (use existing env vars)
  --help, -h         Show this help

Environment variables (optional):
  KEYCLOAK_USERNAME     Skip username prompt
  KEYCLOAK_PASSWORD     Skip password prompt
  MODEL_STUDIO_API_URL  Override API URL

Examples:
  ./develop.sh --mode setup                        # Create env + install deps
  ./develop.sh --mode test                         # Run unit tests
  ./develop.sh --mode test-integration             # Fetch token + run integration tests
  ./develop.sh --mode test-integration --skip-auth # Use existing JWT
  ./develop.sh --mode lint                         # Run linters
  ./develop.sh --mode docker                       # Start JupyterLab in Docker
  ./develop.sh --mode notebook-server              # Start headless Jupyter Server
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --mode)       MODE="$2"; shift 2 ;;
        --skip-auth)  SKIP_AUTH=true; shift ;;
        --help|-h)    usage; exit 0 ;;
        *)            echo "Unknown option: $1"; usage; exit 1 ;;
    esac
done

if [[ -z "$MODE" ]]; then
    echo "ERROR: --mode is required."
    echo ""
    usage
    exit 1
fi

# ─── Conda environment (skip for docker mode) ────────────────────────
if [[ "$MODE" != "docker" && "$MODE" != "notebook-server" ]]; then
    echo "Checking dependencies..."

    if ! command -v conda &>/dev/null; then
        echo "ERROR: conda not found. Install Miniconda or Anaconda first."
        exit 1
    fi

    echo "  conda $(conda --version 2>&1 | awk '{print $2}')"
    echo ""

    eval "$(conda shell.bash hook)"

    if conda env list | grep -q "^${CONDA_ENV} "; then
        echo "Activating conda env '${CONDA_ENV}'..."
        conda activate "$CONDA_ENV"
    else
        echo "Creating conda env '${CONDA_ENV}' (Python ${PYTHON_VERSION})..."
        conda create -y -n "$CONDA_ENV" python="$PYTHON_VERSION" --quiet
        conda activate "$CONDA_ENV"
    fi

    echo "  Python $(python --version 2>&1 | awk '{print $2}') (conda: ${CONDA_ENV})"
    echo ""

    # Ensure editable install with dev deps is up-to-date
    echo "Installing SDK in editable mode..."
    pip install -q -e ".[dev]"
    echo ""
fi

# ─── Keycloak auth (for integration tests) ───────────────────────────
if [[ ("$MODE" == "test-integration" || "$MODE" == "docker" || "$MODE" == "notebook-server") && "$SKIP_AUTH" == "false" ]]; then
    if [[ "$MODE" == "docker" || "$MODE" == "notebook-server" ]]; then
        # Always re-fetch for Docker modes — the existing env var is likely
        # a stale token from the previous container run.
        echo "Fetching Keycloak token..."
        eval "$(bash scripts/get-token.sh)"
    elif [[ -n "${MODEL_STUDIO_JWT:-}" ]]; then
        echo "Using existing MODEL_STUDIO_JWT from environment."
    else
        echo "Fetching Keycloak token..."
        eval "$(bash scripts/get-token.sh)"
    fi
    echo ""
fi

# ─── Run mode ────────────────────────────────────────────────────────
case "$MODE" in
    setup)
        echo "Environment ready."
        echo ""
        echo "  Conda env:  ${CONDA_ENV}"
        echo "  Python:     $(python --version 2>&1 | awk '{print $2}')"
        echo "  SDK:        $(pip show modelstudio-sdk 2>/dev/null | grep Version | awk '{print $2}' || echo 'editable')"
        echo ""
        echo "Activate manually with: conda activate ${CONDA_ENV}"
        ;;
    test)
        echo "Running unit tests..."
        python -m pytest tests/ -m "not integration" --cov=modelstudio --cov-report=term -v
        ;;
    test-integration)
        echo "Running integration tests..."
        python -m pytest tests/integration/ -m integration -v
        ;;
    lint)
        echo "Running linters..."
        python -m ruff check src/ tests/
        python -m mypy src/
        ;;
    docker)
        echo "Starting JupyterLab in Docker..."
        # Write .env file for docker compose
        cat > docker/.env <<ENVEOF
MODEL_STUDIO_API_URL=${MODEL_STUDIO_API_URL:-https://model-studio-api.model-studio.privateer-dev.com}
MODEL_STUDIO_JWT=${MODEL_STUDIO_JWT:-}
MODEL_STUDIO_ORG=${MODEL_STUDIO_ORG:-}
ENVEOF
        echo "  .env written to docker/.env"
        cd docker && docker compose up --build
        ;;
    notebook-server)
        echo "Starting headless Jupyter Server for custom notebook UI..."
        # Write .env file for docker compose
        cat > docker/.env <<ENVEOF
MODEL_STUDIO_API_URL=${MODEL_STUDIO_API_URL:-https://model-studio-api.model-studio.privateer-dev.com}
MODEL_STUDIO_JWT=${MODEL_STUDIO_JWT:-}
MODEL_STUDIO_ORG=${MODEL_STUDIO_ORG:-}
ENVEOF
        echo "  .env written to docker/.env"
        echo "  Jupyter Server will be available at http://localhost:8889"
        echo "  Frontend Vite proxy: /jupyter → http://localhost:8889"
        cd docker && docker compose up --build jupyter-server
        ;;
    *)
        echo "ERROR: Unknown mode '$MODE'"
        echo ""
        usage
        exit 1
        ;;
esac
