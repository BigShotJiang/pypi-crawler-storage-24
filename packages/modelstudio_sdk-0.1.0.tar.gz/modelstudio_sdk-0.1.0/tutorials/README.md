# Model Studio SDK Tutorials

Welcome! These notebooks walk you through the Model Studio Python SDK — from connecting to your first dataset all the way to advanced workflows like cloning, filtering, and few-shot selection.

Each notebook builds on concepts from the previous one, but they can also be used independently as a reference.

## Notebooks

| # | Notebook | What You'll Learn |
|---|----------|-------------------|
| 1 | [01-getting-started.ipynb](01-getting-started.ipynb) | Connect to Model Studio, list your datasets, and explore overview stats and splits |
| 2 | [02-exploring-data.ipynb](02-exploring-data.ipynb) | Browse images and annotations with pagination, view metrics, and work with DataFrames |
| 3 | [03-category-management.ipynb](03-category-management.ipynb) | Create, rename, merge, and delete categories — plus undo support |
| 4 | [04-import-export.ipynb](04-import-export.ipynb) | Import data into a dataset, monitor pipeline status, and export to COCO format |
| 5 | [05-annotations.ipynb](05-annotations.ipynb) | Add, update, and delete annotations individually or in bulk, and run validation checks |
| 6 | [06-advanced-workflows.ipynb](06-advanced-workflows.ipynb) | Manage splits, redistribute data, filter by criteria, select few-shot samples, clone datasets, and review history |

## Getting Started

Open any notebook and run the first cell — the SDK is pre-installed in your notebook environment and authentication is handled automatically. No extra setup is needed.

If you're new, start with **01-getting-started** to familiarize yourself with the SDK basics, then explore the other notebooks based on your needs.

## Quick Reference

```python
from modelstudio.client import ModelStudioClient

# Connect (auto-configured in the notebook environment)
client = ModelStudioClient.from_env()

# List all datasets
datasets = client.datasets.list()

# Work with a specific dataset
ds = client.dataset("dataset-id")
ds.overview()
ds.categories()
ds.splits()

# Work with a specific split
split = ds.split("split-id")
split.list_images()
split.list_annotations()
split.export_coco()
```

## Tips

- **Tab completion** — Use `Tab` to explore available methods on `client`, `ds`, and `split` objects.
- **Docstrings** — Run `ds.overview?` or `help(ds.overview)` in a cell to see documentation for any method.
- **DataFrames** — Many methods support a `as_df=True` parameter to return results as a pandas DataFrame for easier analysis.
