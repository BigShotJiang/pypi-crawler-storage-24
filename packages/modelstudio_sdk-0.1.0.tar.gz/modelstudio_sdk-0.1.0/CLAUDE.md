# Model Studio SDK - Claude Context

## Project Overview

**Model Studio SDK** is a Python package that wraps the Model Studio REST API, providing typed access to dataset management, annotation tooling, and ML workflow operations. This repo also hosts the **Jupyter Server Docker infrastructure** for the custom notebook UI.

**Tech Stack**: Python 3.10+, httpx (HTTP client), pydantic v2 (response models), pandas (optional DataFrame helpers)

**Primary Use Case**: Notebook-based dataset exploration and manipulation inside JupyterHub containers, also usable from CLI scripts and CI/CD pipelines.

### Related Repos
- **`frontend`** (`../frontend`) — React frontend with custom notebook UI (NotebookPanel, NotebookStore, JupyterService)
- **`model-studio-api`** (`../model-studio-api`) — Backend REST API the SDK wraps
- **`model-studio-notebooks`** (`../model-studio-notebooks`) — JupyterHub + KubeSpawner Helm chart (production multi-user)
- **`model-studio-agent`** (`../model-studio-agent`) — Agent chat backend
- **`keycloak-config`** (`../keycloak-config`) — Keycloak realm/client configuration

---

## Architecture

### Package Layout (`src/modelstudio/`)

```
client.py              # ModelStudioClient entry point (from_env, dataset, datasets)
_http.py               # HttpTransport - httpx wrapper with auth + error mapping
_polling.py            # OperationPoller - wait on async ops (clone, import, finalize)
_pandas.py             # Optional pandas helpers (guarded import)
exceptions.py          # Typed exception hierarchy (BadRequestError, NotFoundError, etc.)
models/                # Pydantic v2 response/request DTOs (match API snake_case)
resources/
  dataset.py           # DatasetsCollection + Dataset (~50 methods)
  split.py             # Split sub-resource (~20 methods)
```

### Resource Pattern

```python
client = ModelStudioClient.from_env()
client.datasets.list()                    # DatasetsCollection methods
client.dataset("uuid").overview()         # Dataset-bound methods
client.dataset("uuid").split("sid").list_images()  # Split sub-resource
```

---

## Code Conventions

- **Pydantic v2** models with snake_case fields (matches API JSON directly)
- **Typed exceptions** mapped from API error envelope `{"error": "...", "message": "..."}`
- **Guarded pandas import** in `_pandas.py` - raises helpful error if not installed
- **`from_env()` contract**: reads `MODEL_STUDIO_API_URL`, `MODEL_STUDIO_JWT`, `MODEL_STUDIO_ORG`
- **Sync httpx only** - no async (notebooks are synchronous)
- All public methods have docstrings

---

## Key Design Decisions

- Resource pattern over flat methods for discoverability
- Pollers return immediately; call `.wait()` to block
- Models use `| None` for optional fields with defaults
- `model_dump(exclude_none=True)` for request bodies to avoid sending null fields

---

## When Making Changes

- DO follow pydantic v2 patterns (BaseModel, model_validate, model_dump)
- DO keep httpx sync-only
- DO map new API error codes to exception classes
- DON'T break `from_env()` contract
- DON'T add async httpx
- DON'T import pandas at module level (always guard behind `_pandas.py`)

---

## Development Setup

- **`./develop.sh --mode <MODE>`** is the single-command dev entry point (conda env + deps + optional auth)
- Creates/activates `model-studio-sdk` conda env with Python 3.10
- Installs SDK in editable mode with dev deps on every run
- `./develop.sh --mode setup` — create env + install deps only
- `./develop.sh --mode test` — unit tests
- `./develop.sh --mode test-integration` — prompts for Keycloak creds, fetches JWT, runs integration tests
- `./develop.sh --mode lint` — ruff + mypy
- `./develop.sh --mode notebook-server` — start headless Jupyter Server (Docker) on port 8889 for custom notebook UI
- `./develop.sh --mode docker` — start full JupyterLab (Docker) on port 8888
- `scripts/get-token.sh` — standalone Keycloak token fetcher (used by develop.sh)
  - Usage: `eval "$(scripts/get-token.sh)"` to export `MODEL_STUDIO_JWT` into the current shell
  - Keycloak realm: `elements`, client: `login-direct`
  - Credentials are the same as your Model Studio login

### Custom Notebook UI (cross-repo)

The notebook UI spans this repo (Jupyter Server backend) and the `frontend` repo (React UI):

1. **This repo**: `docker/docker-compose.yml` defines `jupyter-server` service (headless, CORS for localhost:5173)
2. **Frontend**: `vite.config.ts` proxies `/jupyter/*` → `localhost:8889` (includes WebSocket)
3. **Frontend**: `src/services/jupyter/` — JupyterService (REST), JupyterWebSocketManager (WS), messageBuilder
4. **Frontend**: `src/store/notebook_store.ts` — MobX store for cell state + execution
5. **Frontend**: `src/pages/ModelStudio/Notebooks/NotebookPanel/` — React UI components

To run locally: `./develop.sh --mode notebook-server` (this repo) + `yarn start` (frontend repo)

## Testing

- **Framework**: pytest with pytest-httpx for HTTP mocking
- **conftest.py**: MockTransport fixture for unit tests
- **Pattern**: Set canned responses, call SDK method, assert model fields
- **Unit tests**: `./develop.sh --mode test` or `make test`
- **Integration tests**: `./develop.sh --mode test-integration` (requires Keycloak auth against dev environment)

---

## Important Files

| File | Purpose |
|------|---------|
| `src/modelstudio/client.py` | Main entry point |
| `src/modelstudio/_http.py` | HTTP transport with auth |
| `src/modelstudio/exceptions.py` | Exception hierarchy |
| `src/modelstudio/resources/dataset.py` | All dataset endpoints |
| `src/modelstudio/resources/split.py` | All split endpoints |
| `src/modelstudio/models/metrics.py` | OverviewDto with 11 nested types |
| `tests/conftest.py` | MockTransport fixture |
| `develop.sh` | Single-command dev setup (conda + deps + auth) |
| `scripts/get-token.sh` | Keycloak JWT token fetcher |
| `docker/docker-compose.yml` | Docker services (notebook + jupyter-server) |
| `docker/Dockerfile.dev` | Dev image (scipy-notebook + SDK + ML packages) |

### Frontend Files (in `../frontend`)

| File | Purpose |
|------|---------|
| `src/services/jupyter/JupyterService.ts` | REST client for Jupyter Server API |
| `src/services/jupyter/JupyterWebSocketManager.ts` | WebSocket kernel protocol handler |
| `src/services/jupyter/messageBuilder.ts` | Jupyter wire-protocol message builder |
| `src/services/jupyter/types.ts` | Jupyter API + kernel protocol type definitions |
| `src/store/notebook_store.ts` | MobX store for notebook state + execution |
| `src/pages/ModelStudio/Notebooks/NotebookPanel/` | All notebook UI components |
| `src/pages/ModelStudio/Layout/AppBar/AppBar.tsx` | AppBar with Notebook + Agent buttons |
| `vite.config.ts` | Vite proxy: `/jupyter/*` → localhost:8889 |

---

**API Reference**: See `model-studio-api/agent-os/standards/api/` for the API contract standards.
