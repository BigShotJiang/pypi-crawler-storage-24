"""Shared test helpers and fixtures."""

from __future__ import annotations

from typing import Any
from uuid import uuid4

FAKE_BASE = "http://testserver"
FAKE_JWT = "test-jwt-token"
FAKE_DS_ID = str(uuid4())
FAKE_SPLIT_ID = str(uuid4())


class MockTransport:
    """Minimal mock that records calls and returns canned responses."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, str, Any]] = []
        self._responses: dict[str, Any] = {}

    def set_response(self, method_path: str, data: Any) -> None:
        self._responses[method_path] = data

    def _record(self, method: str, path: str, json: Any = None) -> Any:
        self.calls.append((method, path, json))
        key = f"{method} {path}"
        if key in self._responses:
            return self._responses[key]
        if path in self._responses:
            return self._responses[path]
        return {}

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        return self._record("GET", path, params)

    def post(self, path: str, json: Any = None) -> Any:
        return self._record("POST", path, json)

    def put(self, path: str, json: Any = None) -> Any:
        return self._record("PUT", path, json)

    def patch(self, path: str, json: Any = None) -> Any:
        return self._record("PATCH", path, json)

    def delete(self, path: str, json: Any = None, params: dict[str, Any] | None = None) -> Any:
        return self._record("DELETE", path, json)

    def delete_with_body(self, path: str, json: Any = None) -> Any:
        return self._record("DELETE", path, json)

    def post_accepted(self, path: str, json: Any = None) -> Any:
        return self._record("POST", path, json)

    def close(self) -> None:
        pass
