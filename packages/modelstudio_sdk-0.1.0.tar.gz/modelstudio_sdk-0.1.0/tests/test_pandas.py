"""Tests for pandas DataFrame helpers."""

from __future__ import annotations

from unittest.mock import patch
from uuid import uuid4

import pandas as pd
import pytest

from modelstudio._pandas import _get_pandas, to_dataframe
from modelstudio.models.categories import CategoryModel
from modelstudio.resources.dataset import Dataset
from modelstudio.resources.split import Split
from tests.helpers import FAKE_DS_ID, FAKE_SPLIT_ID, MockTransport


class TestToDataframe:
    """Tests for the to_dataframe() helper."""

    def test_returns_dataframe(self) -> None:
        items = [
            CategoryModel(category_id=1, name="cat", annotation_count=10),
            CategoryModel(category_id=2, name="dog", annotation_count=5),
        ]
        df = to_dataframe(items)
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert "category_id" in df.columns
        assert "name" in df.columns

    def test_empty_list(self) -> None:
        df = to_dataframe([])
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 0

    def test_preserves_values(self) -> None:
        items = [
            CategoryModel(
                category_id=7, name="truck", supercategory="vehicle", annotation_count=42
            ),
        ]
        df = to_dataframe(items)
        assert df.iloc[0]["category_id"] == 7
        assert df.iloc[0]["name"] == "truck"
        assert df.iloc[0]["supercategory"] == "vehicle"
        assert df.iloc[0]["annotation_count"] == 42


class TestGetPandasMissing:
    """Test that _get_pandas raises a helpful error when pandas is not installed."""

    def test_import_error_message(self) -> None:
        import builtins

        real_import = builtins.__import__

        def mock_import(name: str, *args: object, **kwargs: object) -> object:
            if name == "pandas":
                raise ImportError("No module named 'pandas'")
            return real_import(name, *args, **kwargs)

        with (
            patch("builtins.__import__", side_effect=mock_import),
            pytest.raises(ImportError, match="pip install 'modelstudio-sdk\\[pandas\\]'"),
        ):
            _get_pandas()


class TestSplitDataFrameHelpers:
    """Tests for Split.images_df() and Split.annotations_df()."""

    def test_images_df(self) -> None:
        mock = MockTransport()
        image_id = str(uuid4())
        mock.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/splits/{FAKE_SPLIT_ID}/images",
            [
                {
                    "dataset_image_id": str(uuid4()),
                    "split_id": FAKE_SPLIT_ID,
                    "image": {
                        "image_id": image_id,
                        "file_name": "img001.png",
                        "width": 640,
                        "height": 480,
                    },
                },
            ],
        )
        s = Split(mock, FAKE_DS_ID, FAKE_SPLIT_ID)
        df = s.images_df()
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1

    def test_annotations_df(self) -> None:
        mock = MockTransport()
        mock.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/splits/{FAKE_SPLIT_ID}/annotations",
            [
                {
                    "annotation_id": 1,
                    "image_id": str(uuid4()),
                    "category_id": 1,
                    "bbox": [10.0, 20.0, 30.0, 40.0],
                    "area": 1200.0,
                },
            ],
        )
        s = Split(mock, FAKE_DS_ID, FAKE_SPLIT_ID)
        df = s.annotations_df()
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert "annotation_id" in df.columns


class TestDatasetDataFrameHelpers:
    """Tests for Dataset.categories_df()."""

    def test_categories_df(self) -> None:
        mock = MockTransport()
        mock.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/categories",
            {
                "categories": [
                    {"category_id": 1, "name": "cat", "annotation_count": 10},
                    {"category_id": 2, "name": "dog", "annotation_count": 5},
                ],
                "total_categories": 2,
                "total_annotations": 15,
            },
        )
        ds = Dataset(mock, FAKE_DS_ID)
        df = ds.categories_df()
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert list(df["name"]) == ["cat", "dog"]
