"""Tests for Dataset and DatasetsCollection resources."""

from __future__ import annotations

from uuid import uuid4

from modelstudio.models.annotations import CreateAnnotationRequest, UpdateAnnotationRequest
from modelstudio.models.common import PagedResponse
from modelstudio.models.datasets import DatasetModel
from modelstudio.models.few_shot import FewShotRequest
from modelstudio.models.filters import DatasetFilterRequest
from modelstudio.models.imports import ImportJobListModel, ImportJobModel, ImportJobQueuedModel
from modelstudio.models.media import MediaJobActionModel, MediaJobStatusModel
from modelstudio.models.merge import MergeDatasetRequest
from modelstudio.models.splits import ClassAwareRedistributeResponse
from modelstudio.resources.dataset import Dataset, DatasetsCollection
from tests.helpers import FAKE_DS_ID, MockTransport


def _ds_json(name: str = "test") -> dict:
    return {
        "id": str(uuid4()),
        "name": name,
        "dataset_type": "object_detection",
        "format": "coco",
        "splits": [],
    }


class TestDatasetsCollection:
    def test_list(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response("GET /api/v1/datasets", [_ds_json(), _ds_json()])
        coll = DatasetsCollection(mock_transport)
        result = coll.list()
        assert len(result) == 2
        assert all(isinstance(d, DatasetModel) for d in result)

    def test_create(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response("POST /api/v1/datasets", _ds_json("new"))
        coll = DatasetsCollection(mock_transport)
        result = coll.create(name="new")
        assert result.name == "new"

    def test_merge_analyze(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            "POST /api/v1/datasets/merge/analyze",
            {
                "all_categories": [], "conflicts": [],
                "suggested_mapping": {}, "has_conflicts": False,
            },
        )
        coll = DatasetsCollection(mock_transport)
        result = coll.merge_analyze([str(uuid4())])
        assert result.has_conflicts is False

    def test_merge(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            "POST /api/v1/datasets/merge",
            {"new_dataset_id": str(uuid4()), "status": "COMPLETED", "images_created": 10},
        )
        coll = DatasetsCollection(mock_transport)
        req = MergeDatasetRequest(source_dataset_ids=[str(uuid4())], target_name="merged")
        result = coll.merge(req)
        assert result.images_created == 10


class TestDataset:
    def _make(self, mock: MockTransport) -> Dataset:
        return Dataset(mock, FAKE_DS_ID)

    def test_can_delete(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/can-delete",
            {"can_delete": True, "referencing_experiments": [], "child_datasets": []},
        )
        ds = self._make(mock_transport)
        result = ds.can_delete()
        assert result.can_delete is True

    def test_delete(self, mock_transport: MockTransport) -> None:
        ds = self._make(mock_transport)
        ds.delete()
        assert ("DELETE", f"/api/v1/datasets/{FAKE_DS_ID}", None) in mock_transport.calls

    def test_clone(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/clone", _ds_json("clone")
        )
        ds = self._make(mock_transport)
        result = ds.clone(name="clone")
        assert result.name == "clone"

    def test_splits(self, mock_transport: MockTransport) -> None:
        sid = str(uuid4())
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/splits",
            [{"split_id": sid, "split_type": "train"}],
        )
        ds = self._make(mock_transport)
        result = ds.splits()
        assert len(result) == 1
        assert result[0].split_type == "train"

    def test_categories(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/categories",
            {
                "categories": [{"category_id": 1, "name": "car"}],
                "total_categories": 1, "total_annotations": 50,
            },
        )
        ds = self._make(mock_transport)
        result = ds.categories()
        assert result.total_categories == 1
        assert result.categories[0].name == "car"

    def test_categories_include_empty_false(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/categories",
            {"categories": [], "total_categories": 0, "total_annotations": 0},
        )
        ds = self._make(mock_transport)
        result = ds.categories(include_empty=False)
        # Verify the param was passed (recorded as json arg in mock)
        assert any(
            call[1] == f"/api/v1/datasets/{FAKE_DS_ID}/categories"
            for call in mock_transport.calls
        )
        assert result.total_categories == 0

    def test_overview(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/metrics/overview",
            {"summary": {"total_images": 100}, "splits": {}, "category_co_occurrence": {}},
        )
        ds = self._make(mock_transport)
        result = ds.overview()
        assert result.summary is not None
        assert result.summary.total_images == 100

    def test_validate(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/validate",
            {"valid": True, "errors": [], "warnings": []},
        )
        ds = self._make(mock_transport)
        result = ds.validate()
        assert result.valid is True

    def test_check_duplicates(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/validate/duplicates",
            {"has_duplicates": False, "duplicate_group_count": 0},
        )
        ds = self._make(mock_transport)
        result = ds.check_duplicates()
        assert result.has_duplicates is False

    def test_history(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/history",
            {"dataset_id": FAKE_DS_ID, "can_undo": True, "can_redo": False, "changes": []},
        )
        ds = self._make(mock_transport)
        result = ds.history()
        assert result.can_undo is True

    def test_undo(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/history/undo",
            {"success": True, "description": "Undid merge", "new_position": 5},
        )
        ds = self._make(mock_transport)
        result = ds.undo()
        assert result.success is True

    def test_few_shot_create(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/few-shot",
            {"success": True, "new_dataset_id": str(uuid4()), "images_included": 10},
        )
        ds = self._make(mock_transport)
        req = FewShotRequest(num_images=10, method="RANDOM")
        result = ds.few_shot_create(req)
        assert result.images_included == 10

    def test_filter(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/filter",
            {"success": True, "mode": "new_dataset"},
        )
        ds = self._make(mock_transport)
        req = DatasetFilterRequest()
        result = ds.filter(req)
        assert result.success is True

    def test_export_coco(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/export/coco",
            {"image_count": 50, "annotation_count": 200, "category_count": 5},
        )
        ds = self._make(mock_transport)
        result = ds.export_coco()
        assert result.image_count == 50

    # ── Class-Aware Redistribute ─────────────────────────────────────

    def test_class_aware_redistribute(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/splits/class-aware-redistribute",
            {
                "previous_distribution": {},
                "new_distribution": {},
                "algorithm_stats": {"converged": True, "iterations_used": 15, "final_error": 0.01},
            },
        )
        ds = self._make(mock_transport)
        result = ds.class_aware_redistribute(ratios={"train": 0.8, "val": 0.2})
        assert isinstance(result, ClassAwareRedistributeResponse)
        assert result.algorithm_stats is not None
        assert result.algorithm_stats.converged is True

    # ── Import Jobs ──────────────────────────────────────────────────

    def test_list_import_jobs(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/imports",
            {"jobs": [{"job_id": str(uuid4()), "status": "COMPLETED"}]},
        )
        ds = self._make(mock_transport)
        result = ds.list_import_jobs()
        assert isinstance(result, ImportJobListModel)
        assert len(result.jobs) == 1

    def test_get_import_job(self, mock_transport: MockTransport) -> None:
        job_id = str(uuid4())
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/imports/{job_id}",
            {"job_id": job_id, "status": "COMPLETED", "progress": 100},
        )
        ds = self._make(mock_transport)
        result = ds.get_import_job(job_id)
        assert isinstance(result, ImportJobModel)
        assert result.status == "COMPLETED"

    def test_cancel_import_job(self, mock_transport: MockTransport) -> None:
        job_id = str(uuid4())
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/imports/{job_id}/cancel",
            {"job_id": job_id, "status": "CANCELED"},
        )
        ds = self._make(mock_transport)
        result = ds.cancel_import_job(job_id)
        assert isinstance(result, ImportJobModel)
        assert result.status == "CANCELED"

    def test_retry_import_job(self, mock_transport: MockTransport) -> None:
        job_id = str(uuid4())
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/imports/{job_id}/retry",
            {"job_id": job_id, "status": "QUEUED"},
        )
        ds = self._make(mock_transport)
        result = ds.retry_import_job(job_id)
        assert isinstance(result, ImportJobQueuedModel)
        assert result.status == "QUEUED"

    # ── Media Jobs ───────────────────────────────────────────────────

    def test_media_status(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/media/status",
            {
                "total": 100, "queued": 0, "processing": 0,
                "done": 95, "error": 5, "recent_errors": [],
            },
        )
        ds = self._make(mock_transport)
        result = ds.media_status()
        assert isinstance(result, MediaJobStatusModel)
        assert result.total == 100
        assert result.error == 5

    def test_retry_media_job(self, mock_transport: MockTransport) -> None:
        job_id = str(uuid4())
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/media/jobs/{job_id}/retry",
            {"action": "retry", "count": 1, "message": "Retried"},
        )
        ds = self._make(mock_transport)
        result = ds.retry_media_job(job_id)
        assert isinstance(result, MediaJobActionModel)
        assert result.action == "retry"

    def test_cancel_media_job(self, mock_transport: MockTransport) -> None:
        job_id = str(uuid4())
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/media/jobs/{job_id}/cancel",
            {"action": "cancel", "count": 1},
        )
        ds = self._make(mock_transport)
        result = ds.cancel_media_job(job_id)
        assert isinstance(result, MediaJobActionModel)

    def test_retry_all_media_jobs(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/media/jobs/retry-all",
            {"action": "retry-all", "count": 5},
        )
        ds = self._make(mock_transport)
        result = ds.retry_all_media_jobs()
        assert isinstance(result, MediaJobActionModel)
        assert result.count == 5

    def test_cancel_queued_media_jobs(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/media/jobs/cancel-queued",
            {"action": "cancel-queued", "count": 3},
        )
        ds = self._make(mock_transport)
        result = ds.cancel_queued_media_jobs()
        assert isinstance(result, MediaJobActionModel)
        assert result.count == 3

    # ── Paginated Images ─────────────────────────────────────────────

    def test_list_images(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/images",
            {
                "content": [{"dataset_image_id": str(uuid4()), "annotation_count": 5}],
                "total_elements": 1, "total_pages": 1, "page": 0, "size": 50,
            },
        )
        ds = self._make(mock_transport)
        result = ds.list_images()
        assert isinstance(result, PagedResponse)
        assert result.total_elements == 1
        assert len(result.content) == 1

    # ── Paginated Annotations ────────────────────────────────────────

    def test_list_annotations(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/annotations",
            {
                "content": [{"annotation_id": 1, "image_id": str(uuid4()), "category_id": 1}],
                "total_elements": 1, "total_pages": 1, "page": 0, "size": 50,
            },
        )
        ds = self._make(mock_transport)
        result = ds.list_annotations()
        assert isinstance(result, PagedResponse)
        assert result.total_elements == 1

    # ── Annotation CRUD ──────────────────────────────────────────────

    def test_create_annotation(self, mock_transport: MockTransport) -> None:
        img_id = uuid4()
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/annotations",
            {
                "annotation_id": 99, "image_id": str(img_id),
                "category_id": 1, "bbox": [0, 0, 5, 5], "area": 25,
            },
        )
        ds = self._make(mock_transport)
        req = CreateAnnotationRequest(
            image_id=img_id, category_id=1, bbox=[0, 0, 5, 5], area=25,
        )
        result = ds.create_annotation(req)
        assert result.annotation_id == 99

    def test_update_annotation(self, mock_transport: MockTransport) -> None:
        img_id = uuid4()
        mock_transport.set_response(
            f"PUT /api/v1/datasets/{FAKE_DS_ID}/annotations/99",
            {
                "annotation_id": 99, "image_id": str(img_id),
                "category_id": 2, "bbox": [0, 0, 10, 10], "area": 100,
            },
        )
        ds = self._make(mock_transport)
        req = UpdateAnnotationRequest(category_id=2)
        result = ds.update_annotation(99, req)
        assert result.category_id == 2

    def test_delete_annotation(self, mock_transport: MockTransport) -> None:
        ds = self._make(mock_transport)
        ds.delete_annotation(99)
        path = f"/api/v1/datasets/{FAKE_DS_ID}/annotations/99"
        assert ("DELETE", path, None) in mock_transport.calls

    def test_ingest_annotations(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST /api/v1/datasets/{FAKE_DS_ID}/annotations/ingest",
            {"success": True},
        )
        ds = self._make(mock_transport)
        result = ds.ingest_annotations({"images": [], "annotations": [], "categories": []})
        assert result == {"success": True}

    # ── Modified params ──────────────────────────────────────────────

    def test_remove_category_with_action(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"DELETE /api/v1/datasets/{FAKE_DS_ID}/categories/1",
            {
                "removed": True, "category_id": 1,
                "annotations_affected": 5, "action_taken": "reassign",
            },
        )
        ds = self._make(mock_transport)
        result = ds.remove_category(1, action="reassign", reassign_to=2)
        assert result.removed is True
        assert result.action_taken == "reassign"

    def test_category_annotations_with_pagination(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/categories/1/annotations",
            [{"annotation_id": 1}],
        )
        ds = self._make(mock_transport)
        result = ds.category_annotations(1, limit=50, offset=10)
        assert isinstance(result, list)

    def test_bbox_area_with_bins(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"GET /api/v1/datasets/{FAKE_DS_ID}/metrics/bbox-area",
            {"bins": [], "counts": []},
        )
        ds = self._make(mock_transport)
        ds.bbox_area(bins=20)
        assert any(
            call[1] == f"/api/v1/datasets/{FAKE_DS_ID}/metrics/bbox-area"
            for call in mock_transport.calls
        )
