"""Fixtures for resource tests."""

from __future__ import annotations

import pytest

from tests.helpers import MockTransport


@pytest.fixture
def mock_transport() -> MockTransport:
    return MockTransport()
