"""Tests for Split sub-resource."""

from __future__ import annotations

from uuid import uuid4

from modelstudio.resources.split import Split
from tests.helpers import FAKE_DS_ID, FAKE_SPLIT_ID, MockTransport


class TestSplit:
    def _make(self, mock: MockTransport) -> Split:
        return Split(mock, FAKE_DS_ID, FAKE_SPLIT_ID)

    @property
    def _base(self) -> str:
        return f"/api/v1/datasets/{FAKE_DS_ID}/splits/{FAKE_SPLIT_ID}"

    def test_export_coco(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST {self._base}/export/coco",
            {"image_count": 20, "annotation_count": 100},
        )
        split = self._make(mock_transport)
        result = split.export_coco()
        assert result.image_count == 20

    def test_import_from_source(self, mock_transport: MockTransport) -> None:
        mock_transport.set_response(
            f"POST {self._base}/import/s3/coco",
            {"split_id": FAKE_SPLIT_ID, "status": "QUEUED", "progress": 0},
        )
        split = self._make(mock_transport)
        result = split.import_from_source("s3", "coco", {"bucket": "test", "prefix": "data/"})
        assert result.status == "QUEUED"

    def test_add_images(self, mock_transport: MockTransport) -> None:
        img_id = str(uuid4())
        mock_transport.set_response(
            f"POST {self._base}/images",
            [{"dataset_image_id": img_id, "image": {"image_id": img_id}}],
        )
        split = self._make(mock_transport)
        result = split.add_images([img_id])
        assert len(result) == 1

    def test_remove_image(self, mock_transport: MockTransport) -> None:
        img_id = str(uuid4())
        split = self._make(mock_transport)
        split.remove_image(img_id)
        assert ("DELETE", f"{self._base}/images/{img_id}", None) in mock_transport.calls

    def test_move_image(self, mock_transport: MockTransport) -> None:
        img_id = str(uuid4())
        new_split_id = str(uuid4())
        split = self._make(mock_transport)
        split.move_image(img_id, new_split_id)
        assert any(
            call[0] == "PATCH" and f"{self._base}/images/{img_id}/move" in call[1]
            for call in mock_transport.calls
        )

    def test_patch_tao_id(self, mock_transport: MockTransport) -> None:
        tao_id = str(uuid4())
        split = self._make(mock_transport)
        split.patch_tao_id(tao_id)
        assert any(
            call[0] == "PATCH" and call[1] == self._base
            for call in mock_transport.calls
        )
