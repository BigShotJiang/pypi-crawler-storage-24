"""Tests for ModelStudioClient."""

from __future__ import annotations

import pytest

from modelstudio.client import ModelStudioClient


class TestClientInit:
    def test_explicit_constructor(self) -> None:
        client = ModelStudioClient(base_url="http://localhost:8081", jwt_token="tok")
        assert client._base_url == "http://localhost:8081"

    def test_trailing_slash_stripped(self) -> None:
        client = ModelStudioClient(base_url="http://localhost:8081/")
        assert client._base_url == "http://localhost:8081"


class TestFromEnv:
    def test_from_env_success(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("MODEL_STUDIO_API_URL", "http://api:8081")
        monkeypatch.setenv("MODEL_STUDIO_JWT", "my-jwt")
        monkeypatch.setenv("MODEL_STUDIO_ORG", "test-org")
        client = ModelStudioClient.from_env()
        assert client._base_url == "http://api:8081"

    def test_from_env_missing_url(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("MODEL_STUDIO_API_URL", raising=False)
        with pytest.raises(ValueError, match="MODEL_STUDIO_API_URL"):
            ModelStudioClient.from_env()

    def test_from_env_optional_jwt(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("MODEL_STUDIO_API_URL", "http://api:8081")
        monkeypatch.delenv("MODEL_STUDIO_JWT", raising=False)
        client = ModelStudioClient.from_env()
        assert client._base_url == "http://api:8081"


class TestContextManager:
    def test_context_manager(self) -> None:
        with ModelStudioClient(base_url="http://localhost:8081") as client:
            assert client._base_url == "http://localhost:8081"


class TestURLHelpers:
    def test_full_image_url(self) -> None:
        client = ModelStudioClient(base_url="http://api:8081")
        url = client.full_image_url("ds-1", "img-1")
        assert url == "http://api:8081/api/v1/media/images/ds-1/img-1.png"

    def test_thumbnail_url(self) -> None:
        client = ModelStudioClient(base_url="http://api:8081")
        url = client.thumbnail_url("ds-1", "img-1", size=128, hash="abc")
        assert url == "http://api:8081/api/v1/media/thumbs/ds-1/img-1_128.webp?h=abc"
