"""Shared test fixtures."""

from __future__ import annotations

import pytest

from modelstudio.client import ModelStudioClient
from tests.helpers import FAKE_BASE, FAKE_JWT, MockTransport


@pytest.fixture
def mock_transport() -> MockTransport:
    return MockTransport()


@pytest.fixture
def client() -> ModelStudioClient:
    return ModelStudioClient(base_url=FAKE_BASE, jwt_token=FAKE_JWT)
