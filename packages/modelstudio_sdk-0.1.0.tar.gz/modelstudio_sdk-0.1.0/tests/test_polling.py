"""Tests for OperationPoller."""

from __future__ import annotations

from typing import Any

import pytest

from modelstudio._polling import OperationPoller
from modelstudio.exceptions import TimeoutError


class FakeTransport:
    """Returns a sequence of poll responses."""

    def __init__(self, responses: list[dict[str, Any]]) -> None:
        self._responses = responses
        self._index = 0

    def get(self, path: str, params: Any = None) -> dict[str, Any]:
        resp = self._responses[min(self._index, len(self._responses) - 1)]
        self._index += 1
        return resp


class TestPoller:
    def test_wait_completes(self) -> None:
        transport = FakeTransport([
            {"status": "RUNNING", "progress": 50},
            {"status": "COMPLETED", "progress": 100},
        ])
        poller = OperationPoller(
            transport=transport,
            poll_url="/status",
            interval=0.01,
            max_wait=5.0,
        )
        result = poller.wait()
        assert result["status"] == "COMPLETED"

    def test_wait_timeout(self) -> None:
        transport = FakeTransport([{"status": "RUNNING", "progress": 10}])
        poller = OperationPoller(
            transport=transport,
            poll_url="/status",
            interval=0.01,
            max_wait=0.05,
        )
        with pytest.raises(TimeoutError, match="did not complete"):
            poller.wait()

    def test_callback_invoked(self) -> None:
        transport = FakeTransport([
            {"status": "RUNNING", "progress": 50},
            {"status": "COMPLETED", "progress": 100},
        ])
        poller = OperationPoller(
            transport=transport,
            poll_url="/status",
            interval=0.01,
        )
        callbacks: list[dict[str, Any]] = []
        poller.wait(callback=callbacks.append)
        assert len(callbacks) == 2
        assert callbacks[-1]["status"] == "COMPLETED"

    def test_poll_once(self) -> None:
        transport = FakeTransport([{"status": "RUNNING"}])
        poller = OperationPoller(transport=transport, poll_url="/status")
        result = poller.poll_once()
        assert result["status"] == "RUNNING"

    def test_clone_status_field(self) -> None:
        transport = FakeTransport([{"clone_status": "COMPLETED"}])
        poller = OperationPoller(transport=transport, poll_url="/status", interval=0.01)
        result = poller.wait()
        assert result["clone_status"] == "COMPLETED"
