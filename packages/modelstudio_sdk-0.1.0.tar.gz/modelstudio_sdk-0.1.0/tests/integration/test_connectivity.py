"""Connectivity and authentication integration tests.

Validates basic API reachability, authentication, and error handling
against the live Model Studio API.
"""

from __future__ import annotations

import os

import httpx
import pytest

from modelstudio.client import ModelStudioClient
from modelstudio.exceptions import AuthenticationError

pytestmark = pytest.mark.integration


class TestConnectivity:
    """Basic connectivity and auth checks."""

    def test_health_unauthenticated(self) -> None:
        """Raw httpx GET to /actuator/health — no auth required."""
        base_url = os.environ.get("MODEL_STUDIO_API_URL", "")
        if not base_url:
            pytest.skip("MODEL_STUDIO_API_URL not set")

        resp = httpx.get(f"{base_url.rstrip('/')}/actuator/health", timeout=10.0)
        assert resp.status_code == 200
        body = resp.json()
        assert body.get("status") in ("UP", "up")

    def test_authenticated_list(self, api_client: ModelStudioClient) -> None:
        """Verify that a valid token can list datasets."""
        datasets = api_client.datasets.list()
        assert isinstance(datasets, list)

    def test_invalid_token_raises(self) -> None:
        """A garbage JWT should raise AuthenticationError."""
        base_url = os.environ.get("MODEL_STUDIO_API_URL", "")
        if not base_url:
            pytest.skip("MODEL_STUDIO_API_URL not set")

        client = ModelStudioClient(
            base_url=base_url,
            jwt_token="invalid.garbage.token",
        )
        with pytest.raises(AuthenticationError):
            client.datasets.list()
        client.close()
