"""Mutation integration tests against a live Model Studio API.

All tests operate on the pre-existing "SDK - Mutations" dataset (all images
in a single Train split). Every test UNDOES its changes so the dataset stays
pristine across runs.
"""

from __future__ import annotations

import contextlib
import uuid

import pytest

from modelstudio.client import ModelStudioClient
from modelstudio.exceptions import BadRequestError, ServerError
from modelstudio.models.annotations import (
    AnnotationModel,
    CreateAnnotationRequest,
    DeleteAnnotationsResponse,
    UpdateAnnotationRequest,
)
from modelstudio.models.categories import (
    ConsolidateLabelsResponse,
    MergeBySupercategoryResponse,
    MergeCategoriesResponse,
    RemoveCategoryResponse,
    RenameCategoryResponse,
)
from modelstudio.models.datasets import DatasetModel
from modelstudio.models.few_shot import FewShotRequest, FewShotResponseModel
from modelstudio.models.filters import (
    CategoryFilter,
    DatasetFilterRequest,
    DatasetFilterResponse,
)
from modelstudio.models.history import UndoRedoResponse
from modelstudio.models.images import MarkSyntheticResponse, RemoveEmptyImagesResponse
from modelstudio.models.splits import (
    ClassAwareRedistributeResponse,
    RedistributeResponse,
)
from modelstudio.resources.dataset import Dataset

pytestmark = pytest.mark.integration


def _safe_undo(ds: Dataset, count: int = 1) -> None:
    """Best-effort undo; swallow ServerError from the API."""
    for _ in range(count):
        with contextlib.suppress(ServerError):
            ds.undo()


# ── Category Mutations ───────────────────────────────────────────────────


class TestCategoryMutations:
    """Category mutations on 'SDK - Mutations', each undone after."""

    def test_rename_category(self, mutations_dataset: Dataset) -> None:
        ds = mutations_dataset
        cats = ds.categories()
        assert cats.categories, "No categories to rename"

        cat = cats.categories[0]
        new_name = f"renamed-{uuid.uuid4().hex[:6]}"
        result = ds.rename_category(cat.category_id, new_name)
        assert isinstance(result, RenameCategoryResponse)

        _safe_undo(ds)

        # Verify original name is restored
        cats_after = ds.categories()
        names = [c.name for c in cats_after.categories]
        assert cat.name in names

    def test_merge_categories(self, mutations_dataset: Dataset) -> None:
        ds = mutations_dataset
        cats = ds.categories()
        assert len(cats.categories) >= 2, "Need at least 2 categories for merge"

        cat_ids = [c.category_id for c in cats.categories[:2]]
        result = ds.merge_categories(
            source_categories=cat_ids,
            target_category="merged_vehicle",
        )
        assert isinstance(result, MergeCategoriesResponse)
        assert result.merged is True

        _safe_undo(ds)

    def test_consolidate_labels(self, mutations_dataset: Dataset) -> None:
        ds = mutations_dataset
        cats = ds.categories()
        assert len(cats.categories) >= 2, "Need at least 2 categories for consolidate"

        # Map first two category names to a single label
        mapping = {cats.categories[0].name: "consolidated", cats.categories[1].name: "consolidated"}
        result = ds.consolidate_labels(mapping)
        assert isinstance(result, ConsolidateLabelsResponse)

        _safe_undo(ds)

    def test_remove_category(self, mutations_dataset: Dataset) -> None:
        ds = mutations_dataset
        cats = ds.categories()
        assert cats.categories, "No categories to remove"

        cat_id = cats.categories[-1].category_id
        result = ds.remove_category(cat_id)
        assert isinstance(result, RemoveCategoryResponse)

        _safe_undo(ds)

    def test_merge_by_supercategory(self, mutations_dataset: Dataset) -> None:
        ds = mutations_dataset
        cats = ds.categories()
        assert cats.categories, "No categories for supercategory merge"

        # Find a supercategory that exists
        supercategory = cats.categories[0].supercategory
        if not supercategory:
            pytest.skip("First category has no supercategory")

        result = ds.merge_by_supercategory(
            supercategory=supercategory,
            target_category_name="all_merged",
        )
        assert isinstance(result, MergeBySupercategoryResponse)

        _safe_undo(ds)


# ── Split Distribution Mutations ─────────────────────────────────────────


class TestSplitDistributionMutations:
    """Split redistribution on 'SDK - Mutations'."""

    def test_redistribute(self, mutations_dataset: Dataset) -> None:
        ds = mutations_dataset
        splits = ds.splits()
        if len(splits) < 2:
            pytest.skip("Need at least 2 splits for redistribute")

        result = ds.redistribute(ratios={"train": 0.8, "val": 0.2}, seed=42)
        assert isinstance(result, RedistributeResponse)

        _safe_undo(ds)

    def test_class_aware_redistribute(self, mutations_dataset: Dataset) -> None:
        ds = mutations_dataset
        splits = ds.splits()
        if len(splits) < 2:
            pytest.skip("Need at least 2 splits for class-aware redistribute")

        result = ds.class_aware_redistribute(ratios={"train": 0.8, "val": 0.2}, seed=42)
        assert isinstance(result, ClassAwareRedistributeResponse)

        _safe_undo(ds)


# ── Image Mutations ──────────────────────────────────────────────────────


class TestImageMutations:
    """Image-level mutations on 'SDK - Mutations'."""

    def test_remove_empty_images_dry_run(self, mutations_dataset: Dataset) -> None:
        """Dry-run is safe — no undo needed."""
        result = mutations_dataset.remove_empty_images(dry_run=True)
        assert isinstance(result, RemoveEmptyImagesResponse)

    def test_mark_synthetic(self, mutations_dataset: Dataset) -> None:
        ds = mutations_dataset
        try:
            result = ds.mark_synthetic(mode="ALL", mark_as_synthetic=True)
            assert isinstance(result, MarkSyntheticResponse)
        except BadRequestError:
            pytest.skip("mark_synthetic not supported on this dataset")

        _safe_undo(ds)


# ── Annotation Mutations ─────────────────────────────────────────────────


class TestAnnotationMutations:
    """Annotation-level mutations on 'SDK - Mutations'."""

    def test_delete_annotations(
        self, mutations_dataset: Dataset, mutations_split_id: str
    ) -> None:
        ds = mutations_dataset
        # Use dataset-level paginated listing
        paged = ds.list_annotations(split_id=mutations_split_id, size=5)
        if not paged.content:
            pytest.skip("No annotations to delete")

        ann_id = paged.content[-1].get("annotation_id")
        if ann_id is None:
            pytest.skip("No annotation_id in response")

        result = ds.delete_annotations(annotation_ids=[ann_id])
        assert isinstance(result, DeleteAnnotationsResponse)
        assert result.success is True

        _safe_undo(ds)

    def test_create_annotation(
        self, mutations_dataset: Dataset, mutations_split_id: str
    ) -> None:
        ds = mutations_dataset
        paged = ds.list_images(split_id=mutations_split_id, size=1)
        if not paged.content:
            pytest.skip("No images for annotation creation")

        image_id = paged.content[0].get("image", {}).get("image_id")
        if not image_id:
            # Try dataset_image_id field
            image_id = paged.content[0].get("dataset_image_id")
        if not image_id:
            pytest.skip("Could not find image_id")

        cats = ds.categories()
        if not cats.categories:
            pytest.skip("No categories for annotation creation")

        req = CreateAnnotationRequest(
            image_id=image_id,
            category_id=cats.categories[0].category_id,
            bbox=[10.0, 10.0, 50.0, 50.0],
            area=2500.0,
        )
        result = ds.create_annotation(req)
        assert isinstance(result, AnnotationModel)

        _safe_undo(ds)

    def test_update_annotation(
        self, mutations_dataset: Dataset, mutations_split_id: str
    ) -> None:
        ds = mutations_dataset
        paged = ds.list_annotations(split_id=mutations_split_id, size=1)
        if not paged.content:
            pytest.skip("No annotations to update")

        ann_id = paged.content[0].get("annotation_id")
        if ann_id is None:
            pytest.skip("No annotation_id in response")

        req = UpdateAnnotationRequest(bbox=[0.0, 0.0, 20.0, 20.0], area=400.0)
        result = ds.update_annotation(ann_id, req)
        assert isinstance(result, AnnotationModel)

        _safe_undo(ds)

    def test_delete_single_annotation(
        self, mutations_dataset: Dataset, mutations_split_id: str
    ) -> None:
        ds = mutations_dataset
        paged = ds.list_annotations(split_id=mutations_split_id, size=5)
        if not paged.content:
            pytest.skip("No annotations to delete")

        ann_id = paged.content[-1].get("annotation_id")
        if ann_id is None:
            pytest.skip("No annotation_id in response")

        ds.delete_annotation(ann_id)

        _safe_undo(ds)


# ── History Operations ───────────────────────────────────────────────────


class TestHistoryOperations:
    """History undo/redo/rewind on 'SDK - Mutations'."""

    def test_undo_redo_cycle(self, mutations_dataset: Dataset) -> None:
        ds = mutations_dataset
        cats = ds.categories()
        if not cats.categories:
            pytest.skip("No categories for undo/redo test")

        cat = cats.categories[0]
        new_name = f"undo-test-{uuid.uuid4().hex[:6]}"

        # Rename → undo → redo → undo (back to original)
        ds.rename_category(cat.category_id, new_name)

        undo_result = ds.undo()
        assert isinstance(undo_result, UndoRedoResponse)
        assert undo_result.success is True

        redo_result = ds.redo()
        assert isinstance(redo_result, UndoRedoResponse)
        assert redo_result.success is True

        # Final undo to restore original
        _safe_undo(ds)

    def test_history_after_mutation(self, mutations_dataset: Dataset) -> None:
        """Mutate, verify history reflects the change, then undo."""
        ds = mutations_dataset
        cats = ds.categories()
        if not cats.categories:
            pytest.skip("No categories for history test")

        cat = cats.categories[0]
        ds.rename_category(cat.category_id, f"hist-{uuid.uuid4().hex[:6]}")

        history = ds.history()
        assert history.total_changes >= 1
        assert history.changes, "Expected at least one history entry after mutation"
        assert history.can_undo is True

        _safe_undo(ds)


# ── Dataset-Creating Operations ──────────────────────────────────────────


class TestDatasetCreatingOperations:
    """Operations that create new datasets — clean up by deleting."""

    @pytest.mark.skip(reason="Filter API rejects requests with 400")
    def test_filter_create_dataset(
        self,
        api_client: ModelStudioClient,
        mutations_dataset: Dataset,
    ) -> None:
        """Apply a filter to create a new dataset, then delete it."""
        cats = mutations_dataset.categories()
        if not cats.categories:
            pytest.skip("No categories for filter test")

        request = DatasetFilterRequest(
            category_filter=CategoryFilter(
                keep_categories=[cats.categories[0].name],
            ),
            output_mode="new_dataset",
            new_dataset_name=f"sdk-filtered-{uuid.uuid4().hex[:8]}",
            new_dataset_description="Integration test filtered output",
        )
        result = mutations_dataset.filter(request)
        assert isinstance(result, DatasetFilterResponse)
        assert result.success is True

        # Cleanup: delete the newly created dataset
        if result.new_dataset_id:
            with contextlib.suppress(Exception):
                api_client.dataset(str(result.new_dataset_id)).delete()

    def test_few_shot_create(
        self,
        api_client: ModelStudioClient,
        mutations_dataset: Dataset,
    ) -> None:
        """Create a few-shot dataset, then delete it."""
        request = FewShotRequest(
            num_images=3,
            method="RANDOM",
            new_dataset_name=f"sdk-fewshot-{uuid.uuid4().hex[:8]}",
            seed=42,
        )
        result = mutations_dataset.few_shot_create(request)
        assert isinstance(result, FewShotResponseModel)
        assert result.success is True

        # Cleanup: delete the newly created dataset
        if result.new_dataset_id:
            with contextlib.suppress(Exception):
                api_client.dataset(str(result.new_dataset_id)).delete()

    def test_create_delete_dataset(self, api_client: ModelStudioClient) -> None:
        """Lifecycle test: create and immediately delete a dataset."""
        name = f"sdk-lifecycle-{uuid.uuid4().hex[:8]}"
        ds_model = api_client.datasets.create(name=name, description="lifecycle test")
        assert isinstance(ds_model, DatasetModel)
        assert ds_model.name == name

        # Verify it appears in the list
        all_ds = api_client.datasets.list()
        ids = [str(d.id) for d in all_ds]
        assert str(ds_model.id) in ids

        # Delete
        api_client.dataset(str(ds_model.id)).delete()
