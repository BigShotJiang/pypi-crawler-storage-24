"""Read-only integration tests against a live Model Studio API.

These tests use the pre-existing "SDK - Read Only" dataset and do not
create, modify, or delete anything.
They require MODEL_STUDIO_API_URL and MODEL_STUDIO_JWT environment variables.
"""

from __future__ import annotations

import pytest

from modelstudio.client import ModelStudioClient
from modelstudio.exceptions import BadRequestError, ConflictError, NotFoundError
from modelstudio.models.categories import CategoryListModel, MergeSourcesResponse
from modelstudio.models.common import PagedResponse
from modelstudio.models.datasets import DatasetModel
from modelstudio.models.deletion import DeletionCheckModel
from modelstudio.models.exports import ExportCocoModel, SegmentationExportModel
from modelstudio.models.few_shot import FewShotPreviewModel, FewShotRequest
from modelstudio.models.history import HistoryModel, PreviewModel
from modelstudio.models.images import SyntheticStatsModel
from modelstudio.models.imports import ImportJobListModel
from modelstudio.models.media import MediaJobStatusModel
from modelstudio.models.merge import MergeAnalysisModel
from modelstudio.models.metrics import BinnedModel, ClassDistributionModel, OverviewModel
from modelstudio.models.oversample import OversampleAnalysisModel, OversampleRequest
from modelstudio.models.splits import LeakageResponse, SplitModel
from modelstudio.models.validation import (
    DuplicateCheckModel,
    TemporalConflictModel,
    ValidationResultsModel,
)
from modelstudio.resources.dataset import Dataset

pytestmark = pytest.mark.integration


# -- Dataset-level read-only tests ----------------------------------------


class TestDatasetReadOnly:
    """Read-only tests against the 'SDK - Read Only' dataset."""

    def test_list_datasets(self, api_client: ModelStudioClient) -> None:
        datasets = api_client.datasets.list()
        assert len(datasets) > 0
        assert isinstance(datasets[0], DatasetModel)

    def test_overview(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.overview()
        assert isinstance(result, OverviewModel)
        assert result.summary is not None

    def test_class_distribution(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.class_distribution()
        assert isinstance(result, ClassDistributionModel)

    def test_bbox_area(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.bbox_area()
        assert isinstance(result, BinnedModel)

    def test_bbox_area_with_bins(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.bbox_area(bins=20)
        assert isinstance(result, BinnedModel)

    def test_categories(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.categories()
        assert isinstance(result, CategoryListModel)

    def test_categories_include_empty(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.categories(include_empty=False)
        assert isinstance(result, CategoryListModel)

    def test_splits(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.splits()
        assert isinstance(result, list)
        if result:
            assert isinstance(result[0], SplitModel)

    def test_can_delete(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.can_delete()
        assert isinstance(result, DeletionCheckModel)

    def test_history(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.history()
        assert isinstance(result, HistoryModel)

    def test_synthetic_stats(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.synthetic_stats()
        assert isinstance(result, SyntheticStatsModel)

    def test_validate(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.validate()
        assert isinstance(result, ValidationResultsModel)

    def test_check_duplicates(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.check_duplicates()
        assert isinstance(result, DuplicateCheckModel)

    def test_export_coco_dataset(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.export_coco()
        assert isinstance(result, ExportCocoModel)

    def test_check_leakage(self, readonly_dataset: Dataset) -> None:
        result = readonly_dataset.check_leakage()
        assert isinstance(result, LeakageResponse)

    def test_merge_analyze(
        self,
        api_client: ModelStudioClient,
        readonly_dataset_id: str,
        mutations_dataset_id: str,
    ) -> None:
        try:
            result = api_client.datasets.merge_analyze([readonly_dataset_id, mutations_dataset_id])
            assert isinstance(result, MergeAnalysisModel)
        except BadRequestError:
            pass  # API may reject merge analysis for certain dataset combinations

    def test_clone_status(self, readonly_dataset: Dataset) -> None:
        """Clone status returns dict or raises NotFoundError if no clone active."""
        try:
            result = readonly_dataset.clone_status()
            assert isinstance(result, dict)
        except (NotFoundError, BadRequestError):
            pass  # Expected when no clone is active

    def test_finalize_status(self, readonly_dataset: Dataset) -> None:
        """Finalize status returns dict or raises NotFoundError."""
        try:
            result = readonly_dataset.finalize_status()
            assert isinstance(result, dict)
        except (NotFoundError, BadRequestError):
            pass  # Expected when no finalization is active

    def test_preview_undo(self, readonly_dataset: Dataset) -> None:
        """Preview undo returns a PreviewModel or ConflictError on pristine dataset."""
        try:
            result = readonly_dataset.preview_undo()
            assert isinstance(result, PreviewModel)
        except ConflictError:
            pass  # Expected: "Nothing to undo" on pristine dataset

    def test_preview_redo(self, readonly_dataset: Dataset) -> None:
        """Preview redo returns a PreviewModel or ConflictError on pristine dataset."""
        try:
            result = readonly_dataset.preview_redo()
            assert isinstance(result, PreviewModel)
        except ConflictError:
            pass  # Expected: "Nothing to redo" on pristine dataset

    def test_category_annotations(
        self, readonly_dataset: Dataset, readonly_category_id: int
    ) -> None:
        """Get annotations for a specific category."""
        result = readonly_dataset.category_annotations(readonly_category_id)
        assert isinstance(result, list)

    def test_category_annotations_with_pagination(
        self, readonly_dataset: Dataset, readonly_category_id: int
    ) -> None:
        """Get annotations for a category with limit and offset."""
        result = readonly_dataset.category_annotations(readonly_category_id, limit=10, offset=0)
        assert isinstance(result, list)

    def test_category_merge_sources(
        self, readonly_dataset: Dataset, readonly_category_id: int
    ) -> None:
        """Get merge history for a category."""
        result = readonly_dataset.category_merge_sources(readonly_category_id)
        assert isinstance(result, MergeSourcesResponse)

    def test_detect_temporal_conflicts(self, readonly_dataset: Dataset) -> None:
        """Detect temporal annotation conflicts."""
        try:
            result = readonly_dataset.detect_temporal_conflicts()
            assert isinstance(result, TemporalConflictModel)
        except BadRequestError:
            pass  # May not be supported on all datasets

    def test_few_shot_preview(self, readonly_dataset: Dataset) -> None:
        """Preview few-shot dataset creation."""
        request = FewShotRequest(num_images=3, method="RANDOM", seed=42)
        result = readonly_dataset.few_shot_preview(request)
        assert isinstance(result, FewShotPreviewModel)
        assert result.selected_image_count <= 3

    def test_oversample_analyze(self, readonly_dataset: Dataset) -> None:
        """Analyze oversampling potential."""
        request = OversampleRequest(target_ratio=0.5, strategy="PREFER_ANNOTATED")
        result = readonly_dataset.oversample_analyze(request)
        assert isinstance(result, OversampleAnalysisModel)

    def test_filter_preview(self, readonly_dataset: Dataset) -> None:
        """Preview a filter without applying."""
        from modelstudio.models.filters import DatasetFilterRequest, DatasetFilterResponse

        request = DatasetFilterRequest(dry_run=True)
        result = readonly_dataset.filter_preview(request)
        assert isinstance(result, DatasetFilterResponse)

    def test_categories_df(self, readonly_dataset: Dataset) -> None:
        """Return categories as a pandas DataFrame."""
        try:
            import pandas as pd

            result = readonly_dataset.categories_df()
            assert isinstance(result, pd.DataFrame)
        except ImportError:
            pytest.skip("pandas not installed")

    def test_class_distribution_df(self, readonly_dataset: Dataset) -> None:
        """Return class distribution as a pandas DataFrame."""
        try:
            import pandas as pd

            result = readonly_dataset.class_distribution_df()
            assert isinstance(result, pd.DataFrame)
        except ImportError:
            pytest.skip("pandas not installed")

    # ── New dataset-level endpoints ──────────────────────────────────

    def test_list_import_jobs(self, readonly_dataset: Dataset) -> None:
        """List import jobs for the dataset."""
        try:
            result = readonly_dataset.list_import_jobs()
            assert isinstance(result, ImportJobListModel)
        except (NotFoundError, BadRequestError):
            pass  # May not have any import jobs

    def test_media_status(self, readonly_dataset: Dataset) -> None:
        """Get media processing status."""
        try:
            result = readonly_dataset.media_status()
            assert isinstance(result, MediaJobStatusModel)
        except (NotFoundError, BadRequestError):
            pass  # May not have media jobs

    def test_list_images_paginated(self, readonly_dataset: Dataset) -> None:
        """List images with pagination at dataset level."""
        result = readonly_dataset.list_images(page=0, size=10)
        assert isinstance(result, PagedResponse)
        assert result.size <= 10

    def test_list_annotations_paginated(self, readonly_dataset: Dataset) -> None:
        """List annotations with pagination at dataset level."""
        result = readonly_dataset.list_annotations(page=0, size=10)
        assert isinstance(result, PagedResponse)

    def test_images_df(self, readonly_dataset: Dataset) -> None:
        """Return paginated images as a pandas DataFrame."""
        try:
            import pandas as pd

            result = readonly_dataset.images_df(size=10)
            assert isinstance(result, pd.DataFrame)
        except ImportError:
            pytest.skip("pandas not installed")

    def test_annotations_df(self, readonly_dataset: Dataset) -> None:
        """Return paginated annotations as a pandas DataFrame."""
        try:
            import pandas as pd

            result = readonly_dataset.annotations_df(size=10)
            assert isinstance(result, pd.DataFrame)
        except ImportError:
            pytest.skip("pandas not installed")


# -- Split-level read-only tests ------------------------------------------


class TestSplitReadOnly:
    """Read-only tests against a split in 'SDK - Read Only'."""

    def test_export_coco_split(self, readonly_dataset: Dataset, readonly_split_id: str) -> None:
        s = readonly_dataset.split(readonly_split_id)
        result = s.export_coco()
        assert isinstance(result, ExportCocoModel)

    def test_export_segmentation(
        self, readonly_dataset: Dataset, readonly_split_id: str
    ) -> None:
        """Export segmentation masks for a split."""
        s = readonly_dataset.split(readonly_split_id)
        try:
            result = s.export_segmentation()
            assert isinstance(result, SegmentationExportModel)
        except BadRequestError:
            pass  # May not be supported on all datasets
