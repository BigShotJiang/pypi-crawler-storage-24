"""Integration test fixtures.

These fixtures require a live Model Studio API and valid JWT token.
Tests are skipped automatically when environment variables are not set.

Two pre-existing datasets are expected:
  - "SDK - Read Only"  — has train/test/val splits, images, annotations, categories
  - "SDK - Mutations"  — all images in a single Train split
"""

from __future__ import annotations

import os

import pytest

from modelstudio.client import ModelStudioClient
from modelstudio.resources.dataset import Dataset


def _env_available() -> bool:
    return bool(os.environ.get("MODEL_STUDIO_API_URL") and os.environ.get("MODEL_STUDIO_JWT"))


pytestmark = pytest.mark.integration


def _find_dataset_by_name(client: ModelStudioClient, name: str) -> Dataset | None:
    """Iterate datasets.list() to find a dataset by exact name."""
    for ds in client.datasets.list():
        if ds.name == name:
            return client.dataset(str(ds.id))
    return None


# ── Core client ──────────────────────────────────────────────────────────


@pytest.fixture(scope="session")
def api_client() -> ModelStudioClient:
    """Session-scoped client from environment variables."""
    if not _env_available():
        pytest.skip("MODEL_STUDIO_API_URL and MODEL_STUDIO_JWT required for integration tests")
    return ModelStudioClient.from_env()


# ── Read-only dataset fixtures ───────────────────────────────────────────


@pytest.fixture(scope="session")
def readonly_dataset(api_client: ModelStudioClient) -> Dataset:
    """Find the 'SDK - Read Only' dataset, skip if missing."""
    ds = _find_dataset_by_name(api_client, "SDK - Read Only")
    if ds is None:
        pytest.skip("Dataset 'SDK - Read Only' not found on the live API")
    return ds


@pytest.fixture(scope="session")
def readonly_dataset_id(readonly_dataset: Dataset) -> str:
    return readonly_dataset._id


@pytest.fixture(scope="session")
def readonly_split_id(readonly_dataset: Dataset) -> str:
    """First split from the read-only dataset."""
    splits = readonly_dataset.splits()
    if not splits:
        pytest.skip("No splits in 'SDK - Read Only'")
    return str(splits[0].split_id)


@pytest.fixture(scope="session")
def readonly_category_id(readonly_dataset: Dataset) -> int:
    """First category ID from the read-only dataset."""
    cats = readonly_dataset.categories()
    if not cats.categories:
        pytest.skip("No categories in 'SDK - Read Only'")
    return cats.categories[0].category_id


@pytest.fixture(scope="session")
def readonly_image_id(readonly_dataset: Dataset, readonly_split_id: str) -> str:
    """First image ID from the read-only dataset using dataset-level paginated listing."""
    paged = readonly_dataset.list_images(split_id=readonly_split_id, size=1)
    if not paged.content:
        pytest.skip("No images in 'SDK - Read Only' first split")
    return str(paged.content[0].get("dataset_image_id", ""))


# ── Mutations dataset fixtures ───────────────────────────────────────────


@pytest.fixture(scope="session")
def mutations_dataset(api_client: ModelStudioClient) -> Dataset:
    """Find the 'SDK - Mutations' dataset, skip if missing."""
    ds = _find_dataset_by_name(api_client, "SDK - Mutations")
    if ds is None:
        pytest.skip("Dataset 'SDK - Mutations' not found on the live API")
    return ds


@pytest.fixture(scope="session")
def mutations_dataset_id(mutations_dataset: Dataset) -> str:
    return mutations_dataset._id


@pytest.fixture(scope="session")
def mutations_split_id(mutations_dataset: Dataset) -> str:
    """The single Train split from the mutations dataset."""
    splits = mutations_dataset.splits()
    if not splits:
        pytest.skip("No splits in 'SDK - Mutations'")
    return str(splits[0].split_id)
