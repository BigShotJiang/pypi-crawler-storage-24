"""Tests for HttpTransport error mapping and header injection."""

from __future__ import annotations

import pytest

from modelstudio._http import HttpTransport
from modelstudio.exceptions import (
    AuthenticationError,
    BadRequestError,
    ConflictError,
    NotFoundError,
    ServerError,
)


class TestErrorMapping:
    """Verify HTTP status codes map to the correct exception types."""

    def test_400_maps_to_bad_request(self, httpx_mock) -> None:  # type: ignore[no-untyped-def]
        httpx_mock.add_response(
            status_code=400,
            json={"error": "BadRequest", "message": "Invalid input"},
        )
        transport = HttpTransport(base_url="http://test", jwt_token="tok")
        with pytest.raises(BadRequestError, match="Invalid input"):
            transport.get("/test")

    def test_401_maps_to_auth_error(self, httpx_mock) -> None:  # type: ignore[no-untyped-def]
        httpx_mock.add_response(
            status_code=401,
            json={"error": "Unauthorized", "message": "Token expired"},
        )
        transport = HttpTransport(base_url="http://test", jwt_token="tok")
        with pytest.raises(AuthenticationError):
            transport.get("/test")

    def test_404_maps_to_not_found(self, httpx_mock) -> None:  # type: ignore[no-untyped-def]
        httpx_mock.add_response(
            status_code=404,
            json={"error": "NotFound", "message": "Dataset not found"},
        )
        transport = HttpTransport(base_url="http://test", jwt_token="tok")
        with pytest.raises(NotFoundError, match="Dataset not found"):
            transport.get("/test")

    def test_409_maps_to_conflict(self, httpx_mock) -> None:  # type: ignore[no-untyped-def]
        httpx_mock.add_response(
            status_code=409,
            json={"error": "Conflict", "message": "Dataset locked"},
        )
        transport = HttpTransport(base_url="http://test", jwt_token="tok")
        with pytest.raises(ConflictError, match="Dataset locked"):
            transport.post("/test")

    def test_500_maps_to_server_error(self, httpx_mock) -> None:  # type: ignore[no-untyped-def]
        httpx_mock.add_response(
            status_code=500,
            json={"error": "InternalServerError", "message": "Unexpected"},
        )
        transport = HttpTransport(base_url="http://test", jwt_token="tok")
        with pytest.raises(ServerError):
            transport.get("/test")


class TestHeaders:
    """Verify auth and source headers are injected."""

    def test_auth_header(self, httpx_mock) -> None:  # type: ignore[no-untyped-def]
        httpx_mock.add_response(json={"ok": True})
        transport = HttpTransport(base_url="http://test", jwt_token="my-jwt")
        transport.get("/test")

        request = httpx_mock.get_request()
        assert request.headers["Authorization"] == "Bearer my-jwt"

    def test_source_header(self, httpx_mock) -> None:  # type: ignore[no-untyped-def]
        httpx_mock.add_response(json={"ok": True})
        transport = HttpTransport(base_url="http://test")
        transport.get("/test")

        request = httpx_mock.get_request()
        assert request.headers["X-Source"] == "modelstudio-sdk"

    def test_org_header(self, httpx_mock) -> None:  # type: ignore[no-untyped-def]
        httpx_mock.add_response(json={"ok": True})
        transport = HttpTransport(base_url="http://test", org_name="my-org")
        transport.get("/test")

        request = httpx_mock.get_request()
        assert request.headers["X-Org-Name"] == "my-org"

    def test_204_returns_none(self, httpx_mock) -> None:  # type: ignore[no-untyped-def]
        httpx_mock.add_response(status_code=204)
        transport = HttpTransport(base_url="http://test")
        result = transport.delete("/test")
        assert result is None
