#!/usr/bin/env python3
"""Smoke test for Model Studio SDK — quick end-to-end validation.

Usage:
    source <(scripts/get-token.sh)
    python scripts/smoke_test.py

Requires MODEL_STUDIO_API_URL and MODEL_STUDIO_JWT environment variables.
"""

from __future__ import annotations

import contextlib
import sys
import uuid

from modelstudio.client import ModelStudioClient


class SmokeTestRunner:
    """Runs a series of smoke tests and reports results."""

    def __init__(self) -> None:
        self.passed: list[str] = []
        self.failed: list[tuple[str, str]] = []

    def run(self, name: str, func: object) -> None:
        """Run a single test, catching exceptions."""
        try:
            func()  # type: ignore[operator]
            self.passed.append(name)
            print(f"  PASS  {name}")
        except Exception as e:
            self.failed.append((name, str(e)))
            print(f"  FAIL  {name}: {e}")

    def summary(self) -> int:
        """Print summary and return exit code."""
        total = len(self.passed) + len(self.failed)
        print(f"\n{'=' * 60}")
        print(f"Smoke Test Results: {len(self.passed)}/{total} passed")
        if self.failed:
            print(f"\nFailed tests:")
            for name, err in self.failed:
                print(f"  - {name}: {err}")
        print(f"{'=' * 60}")
        return 0 if not self.failed else 1


def main() -> int:
    runner = SmokeTestRunner()

    # ── Connect ──────────────────────────────────────────────────────
    print("\n[1/7] Connecting...")
    client: ModelStudioClient | None = None

    def connect() -> None:
        nonlocal client
        client = ModelStudioClient.from_env()

    runner.run("connect_from_env", connect)
    if client is None:
        print("Cannot proceed without connection")
        return 1

    # ── List datasets ────────────────────────────────────────────────
    print("\n[2/7] Listing datasets...")
    datasets = None

    def list_datasets() -> None:
        nonlocal datasets
        datasets = client.datasets.list()
        if len(datasets) == 0:
            raise RuntimeError("No datasets found")

    runner.run("list_datasets", list_datasets)

    # ── Read-only operations on first dataset ────────────────────────
    print("\n[3/7] Read-only operations...")
    if datasets:
        ds = client.dataset(str(datasets[0].id))

        runner.run("overview", lambda: ds.overview())
        runner.run("categories", lambda: ds.categories())
        runner.run("splits", lambda: ds.splits())
        runner.run("class_distribution", lambda: ds.class_distribution())
        runner.run("bbox_area", lambda: ds.bbox_area())
        runner.run("history", lambda: ds.history())
        runner.run("can_delete", lambda: ds.can_delete())
        runner.run("synthetic_stats", lambda: ds.synthetic_stats())

        # ── Split-level operations ───────────────────────────────────
        print("\n[4/7] Split-level operations...")
        splits = ds.splits()
        if splits:
            s = ds.split(str(splits[0].split_id))
            runner.run("split_list_images", lambda: s.list_images())
            runner.run("split_list_annotations", lambda: s.list_annotations())
            runner.run("split_category_names", lambda: s.category_names())
            runner.run("split_export_coco", lambda: s.export_coco())
        else:
            print("  SKIP  No splits available")

        # ── Validation operations ────────────────────────────────────
        print("\n[5/7] Validation operations...")
        runner.run("validate", lambda: ds.validate())
        runner.run("check_duplicates", lambda: ds.check_duplicates())
        runner.run("check_leakage", lambda: ds.check_leakage())
    else:
        print("  SKIP  No datasets available for read-only tests")

    # ── Mutation flow ────────────────────────────────────────────────
    print("\n[6/7] Mutation flow...")
    test_ds = None
    clone_id = None
    test_ds_id = None

    try:
        # Create dataset
        def create_dataset() -> None:
            nonlocal test_ds, test_ds_id
            name = f"sdk-smoke-{uuid.uuid4().hex[:8]}"
            model = client.datasets.create(name=name, description="Smoke test")
            test_ds_id = str(model.id)
            test_ds = client.dataset(test_ds_id)

        runner.run("create_dataset", create_dataset)

        if test_ds:
            # Create split
            split_id = None

            def create_split() -> None:
                nonlocal split_id
                s = test_ds.create_split(split_type="train", name="smoke-train")
                split_id = str(s.split_id)

            runner.run("create_split", create_split)

            # Ingest COCO
            if split_id:
                coco = {
                    "images": [{"id": 1, "file_name": "smoke.png", "width": 100, "height": 100}],
                    "annotations": [
                        {
                            "id": 1,
                            "image_id": 1,
                            "category_id": 1,
                            "bbox": [10, 10, 50, 50],
                            "area": 2500,
                            "iscrowd": 0,
                        }
                    ],
                    "categories": [{"id": 1, "name": "test_obj", "supercategory": "test"}],
                }

                runner.run("ingest_coco", lambda: test_ds.split(split_id).ingest_annotations(coco))
                runner.run(
                    "list_annotations",
                    lambda: test_ds.split(split_id).list_annotations(),
                )

                # Rename category
                def rename_cat() -> None:
                    cats = test_ds.categories()
                    if cats.categories:
                        test_ds.rename_category(cats.categories[0].category_id, "renamed_obj")

                runner.run("rename_category", rename_cat)
                runner.run("undo", lambda: test_ds.undo())

                # Export
                runner.run("export_coco", lambda: test_ds.export_coco())

            # Clone
            def clone_dataset() -> None:
                nonlocal clone_id
                clone_name = f"sdk-smoke-clone-{uuid.uuid4().hex[:8]}"
                clone_model = test_ds.clone(name=clone_name)
                clone_id = str(clone_model.id)

            runner.run("clone_dataset", clone_dataset)

    finally:
        # ── Cleanup ──────────────────────────────────────────────────
        print("\n[7/7] Cleanup...")

        def delete_clone() -> None:
            if clone_id:
                client.dataset(clone_id).delete()

        def delete_test_ds() -> None:
            if test_ds:
                test_ds.delete()

        runner.run("delete_clone", delete_clone)
        runner.run("delete_test_dataset", delete_test_ds)

    client.close()
    return runner.summary()


if __name__ == "__main__":
    sys.exit(main())
