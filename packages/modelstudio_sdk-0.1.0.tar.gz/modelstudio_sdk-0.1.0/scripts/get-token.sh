#!/usr/bin/env bash
set -euo pipefail

# Usage: eval "$(scripts/get-token.sh)" && make test-integration
# Or set KEYCLOAK_USERNAME and KEYCLOAK_PASSWORD env vars to skip prompts.

# Keycloak token endpoint for the 'elements' realm
KEYCLOAK_URL="${KEYCLOAK_URL:-https://keycloak.model-studio.privateer-dev.com}"
REALM="${KEYCLOAK_REALM:-elements}"
CLIENT_ID="${KEYCLOAK_CLIENT_ID:-login-direct}"
TOKEN_URL="${KEYCLOAK_URL}/realms/${REALM}/protocol/openid-connect/token"

# Restore terminal echo and exit on Ctrl+C
cleanup() {
  stty echo 2>/dev/null || true
  echo >&2
  echo "Aborted." >&2
  exit 130
}
trap cleanup INT

# Prompt for credentials if not in env
if [[ -z "${KEYCLOAK_USERNAME:-}" ]]; then
  echo -n "Keycloak username: " >&2
  read -r KEYCLOAK_USERNAME
fi
if [[ -z "${KEYCLOAK_PASSWORD:-}" ]]; then
  echo -n "Keycloak password: " >&2
  stty -echo
  read -r KEYCLOAK_PASSWORD
  stty echo
  echo >&2
fi

# Fetch token
RESPONSE=$(curl -s -X POST "$TOKEN_URL" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=password" \
  -d "client_id=${CLIENT_ID}" \
  -d "username=${KEYCLOAK_USERNAME}" \
  -d "password=${KEYCLOAK_PASSWORD}" \
  -d "scope=openid")

TOKEN=$(echo "$RESPONSE" | jq -r '.access_token // empty')
if [[ -z "$TOKEN" ]]; then
  echo "Failed to get token:" >&2
  echo "$RESPONSE" | jq . >&2
  exit 1
fi

MODEL_STUDIO_API_URL="${MODEL_STUDIO_API_URL:-https://model-studio-api.model-studio.privateer-dev.com}"

# Print export statements to stdout so eval "$(...)" sets them in the parent shell
echo "export MODEL_STUDIO_JWT='${TOKEN}'"
echo "export MODEL_STUDIO_API_URL='${MODEL_STUDIO_API_URL}'"

echo "# Token acquired (expires in $(echo "$RESPONSE" | jq -r '.expires_in')s)" >&2
echo "# MODEL_STUDIO_API_URL=$MODEL_STUDIO_API_URL" >&2
