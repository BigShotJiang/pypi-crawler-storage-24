import numpy as np
from copy import deepcopy

WORKING_DISTANCE = 1.5  # meters

from ..gym_utils.utils import find_object_with_parent

# Infrastructure objects that must never be picked up.
# Picking up stairs or elevators would remove them from the scene
# and break the floor-switching mechanism.
_INFRASTRUCTURE_KEYWORDS = ("stair", "elevator")


def _is_infrastructure(object_id: str) -> bool:
    low = object_id.lower()
    return any(kw in low for kw in _INFRASTRUCTURE_KEYWORDS)


def step(env, *, objectId=None, **kwargs):
    """
    Picks up a specified object if it is within working distance.

    The skill retrieves the object’s metadata, computes the 3D Euclidean
    distance between the robot and the object, and fails if the object is
    farther than the allowed working range. If close enough, it attempts a
    `PickupObject` action. On success, the object’s JSON entry is stored in
    `env.held_object`, and its state is recorded for downstream use.

    Args:
        env: The simulation environment containing the controller, robot
            pose, and object state tracking.
        action (dict): Skill invocation containing:
            objectId (str): ID of the object to pick up.

    Returns:
        tuple: `(success, message)` where `success` indicates whether the
        pickup succeeded, and `message` provides a descriptive status.
    """

    print("\n=== PickupSkill ===")

    if _is_infrastructure(objectId or ""):
        return False, f"’{objectId}’ is scene infrastructure (stair/elevator) and cannot be picked up."

    obs= env.get_observation()
    obj_meta = next( (o for o in obs.metadata["objects"] if o["objectId"] == objectId), None)
    
    obj_pos = obj_meta["position"]
    
    # Euclidean distance in 3D between agent and object
    object_robot_distance = np.sqrt(
        (obj_pos["x"] - env.agent_pos["x"]) ** 2 +
        (obj_pos["y"] - env.agent_pos["y"]) ** 2 +
        (obj_pos["z"] - env.agent_pos["z"]) ** 2
    )

    if object_robot_distance >= WORKING_DISTANCE:
        return False, f"Object is too far ({object_robot_distance:.2f} m). Move closer before pickup."
    
    recepted_obj_states= []
    if obj_meta["receptacleObjectIds"]:
        
        for recept_obj_id in obj_meta["receptacleObjectIds"]:
                if "sliced" in recept_obj_id.lower() or "cracked" in recept_obj_id.lower():
                    recept_obj_id= "|".join(recept_obj_id.split("|")[:-1])
                    
                recept_obj= next( (o for o in obs.metadata["objects"] if o["objectId"] == recept_obj_id), None)
                recepted_obj_states.append(recept_obj)
    
    event = env.controller.step("PickupObject", objectId= objectId)
    
    
    unique_recepted_states = []
    seen_ids = set()
    for obj in recepted_obj_states:
        oid = obj.get("objectId")
        if oid in seen_ids:
            continue
        seen_ids.add(oid)
        unique_recepted_states.append(deepcopy(obj))

    recepted_obj_states = unique_recepted_states

    if event.metadata.get("lastActionSuccess", False):
        env.controller.step(action="MoveHeldObject", ahead=0.05, up=-0.4, forceVisible=False)
        parent_obj, json_info = find_object_with_parent(env.cur_json["objects"], objectId)
        if json_info is None:
            print(f"[PickupSkill] Warning: '{objectId}' not found in floor JSON (held_object will be None).")
        env.held_object = deepcopy(json_info)
        env.recepted_objs= recepted_obj_states
        return True, "PickupObject succeeded."
    else:
        return False, event.metadata.get("errorMessage", "PickupObject failed (not in reach or not visible).")