# mansion_gym/gym_utils/navigation_utils.py

import os
import networkx as nx
import matplotlib.pyplot as plt

from shapely.geometry import Polygon, LineString
from shapely.ops import unary_union

from .geometry_utils import (
    get_room_polygons,
    get_retracted_dilated_poly,
)


# --------- Landmark extraction ----------
def generate_landmarks(env, scene_json):
    """
    Compute robust landmark positions for every room in a ProcTHOR scene.
    Returns dict: {roomId: {'x': float, 'y': float, 'z': float}}
    """
    room_landmarks = {}

    if "rooms" not in scene_json:
        print("[MansionGym] No 'rooms' field found in scene JSON.")
        return room_landmarks

    for room in scene_json["rooms"]:
        room_type = room.get("id", f"Room_{room['id']}")
        polygon = [(p["x"], p["z"]) for p in room["floorPolygon"]]

        if len(polygon) < 3:
            print(f"[MansionGym] Skipping invalid room polygon: {room_type}")
            continue

        poly = Polygon(polygon)
        centroid = poly.centroid
        if not poly.contains(centroid):
            centroid = poly.representative_point()  # guaranteed inside

        room_landmarks[room_type] = {
            "x": centroid.x,
            "y": env.init_info["position"]["y"],
            "z": centroid.y,  # shapely uses y as z-axis here
        }

    return room_landmarks


# --------- Room graph ----------
def build_room_graph(env):
    """
    Create an undirected edge set between rooms.
    1. Checks for physical 'Door' objects.
    2. Checks for open spaces (overlapping dilated polygons with no walls).
    Returns (edges, edge_doors, open_space_edges)
    """
    edges = set()
    edge_doors = {}
    open_space_edges = set()

    room_polys = get_room_polygons(env.cur_json)
    if not room_polys:
        return edges, edge_doors, open_space_edges

    # ---- Part 1: Door-based connections ----
    event = env.controller.last_event
    if event:
        objects = event.metadata.get("objects", [])
        door_types = {"Door", "Doorway", "Doorframe"}

        for obj in objects:
            if obj.get("objectType") not in door_types:
                continue
            try:
                # objectId format: "door|{index}|{roomA}|{roomB}"
                parts = obj["objectId"].split("|")
                if len(parts) < 4:
                    continue
                room1, room2 = parts[2], parts[3]
            except Exception:
                continue

            if room1 in env.landmarks and room2 in env.landmarks:
                a, b = sorted([room1, room2])
                edges.add((a, b))
                edge_doors.setdefault((a, b), []).append(obj.get("objectId"))

    # ---- Part 2: open-space connections ----
    scene_walls = []
    if "walls" in env.cur_json:
        for w in env.cur_json["walls"]:
            if w.get("empty", False):
                continue
            p1 = w["polygon"][0]
            p2 = w["polygon"][1]
            scene_walls.append(LineString([(p1["x"], p1["z"]), (p2["x"], p2["z"])]))

    room_names = list(room_polys.keys())

    for i in range(len(room_names)):
        for j in range(i + 1, len(room_names)):
            r1 = room_names[i]
            r2 = room_names[j]
            key = tuple(sorted([r1, r2]))

            if key in edges:
                continue

            poly1 = room_polys[r1]
            poly2 = room_polys[r2]

            d1 = get_retracted_dilated_poly(poly1, dilation=0.2, retraction=0.11)
            d2 = get_retracted_dilated_poly(poly2, dilation=0.2, retraction=0.11)

            intersection = d1.intersection(d2)
            if not intersection.is_empty and intersection.area > 0.05:
                wall_blocking = False
                for wall_line in scene_walls:
                    if intersection.intersects(wall_line):
                        if intersection.intersection(wall_line).length > 0.05:
                            wall_blocking = True
                            break

                #debug_visualize_intersection(env, r1, poly1, r2, poly2, d1, d2, intersection, scene_walls, wall_blocking,)

                if not wall_blocking:
                    #print(f"[MansionGym] Found open space connection between {r1} and {r2}")
                    edges.add(key)
                    open_space_edges.add(key)

    return edges, edge_doors, open_space_edges


# --------- Edge state updates ----------
def update_edge_states(env):
    """
    Refresh the 'open' (0/1) attribute for each edge using current metadata.
    'open_space' edges are treated as always open.
    """
    event = env.controller.last_event
    if event is None or env.graph is None:
        return

    objects = event.metadata.get("objects", [])
    door_state = {}

    for obj in objects:
        if obj.get("objectType") in {"Door", "Doorway"}:
            door_state[obj.get("objectId")] = bool(obj.get("isOpen", False))
        if obj.get("objectType") == "Doorframe":
            door_state[obj.get("objectId")] = True

    for u, v in env.graph.edges():
        edge_key = tuple(sorted([u, v]))

        if edge_key in env.open_space_edges:
            env.graph[u][v]["open"] = 1
            env.graph[u][v]["type"] = "open_space"
        else:
            env.graph[u][v]["type"] = "door"
            eid = edge_key if edge_key in env.edge_doors else (v, u)
            door_ids = env.edge_doors.get(eid, [])
            is_open = 0
            for did in door_ids:
                if door_state.get(did, False):
                    is_open = 1
                    break
            env.graph[u][v]["open"] = is_open


# --------- Visualization (optional) ----------
def visualize_landmarks(env, filename="landmarks.png"):
    room_polys = []
    names = []
    for room in env.cur_json["rooms"]:
        polygon = [(p["x"], p["z"]) for p in room["floorPolygon"]]
        if len(polygon) >= 3:
            room_polys.append(Polygon(polygon))
            names.append(room.get("id", str(room["id"])))

    building_outline = unary_union(room_polys)

    for name, poly in zip(names, room_polys):
        x, z = poly.exterior.xy
        plt.plot(x, z, "k-")
        if name in env.landmarks:
            c = env.landmarks[name]
            plt.plot(c["x"], c["z"], "ro")
            plt.text(c["x"], c["z"], name)

    if not building_outline.is_empty:
        bx, bz = building_outline.exterior.xy
        plt.plot(bx, bz, "k-", linewidth=2)

    plt.axis("equal")
    plt.title("Room Landmarks (Closed Walls)")
    out_path = os.path.join(env.save_dir, filename)
    if not os.path.exists(env.save_dir):
        os.makedirs(env.save_dir)
    plt.savefig(out_path)
    plt.close()


def visualize_room_graph(env, filename="room_graph.png"):
    room_polys = []
    names = []
    for room in env.cur_json["rooms"]:
        polygon = [(p["x"], p["z"]) for p in room["floorPolygon"]]
        if len(polygon) >= 3:
            room_polys.append(Polygon(polygon))
            names.append(room.get("id", str(room["id"])))

    building_outline = unary_union(room_polys)

    plt.figure(figsize=(7, 5))
    for name, poly in zip(names, room_polys):
        x, z = poly.exterior.xy
        plt.plot(x, z, "k-")
        if name in env.landmarks:
            c = env.landmarks[name]
            plt.plot(c["x"], c["z"], "ro")
            plt.text(c["x"], c["z"], name)

    if not building_outline.is_empty:
        bx, bz = building_outline.exterior.xy
        plt.plot(bx, bz, "k-", linewidth=2)

    for a, b in env.graph.edges():
        if a in env.landmarks and b in env.landmarks:
            pa = env.landmarks[a]
            pb = env.landmarks[b]
            plt.plot([pa["x"], pb["x"]], [pa["z"], pb["z"]], "b--", linewidth=1.5)
            if env.graph[a][b].get("open", 0) == 1:
                plt.plot([pa["x"], pb["x"]], [pa["z"], pb["z"]], "g-", linewidth=2.5)

    plt.axis("equal")
    plt.title(f"Floor {env.current_floor} Room Door Graph")
    if not os.path.exists(env.save_dir):
        os.makedirs(env.save_dir)
    out_path = os.path.join(env.save_dir, filename)
    plt.savefig(out_path)
    plt.show()
    plt.close()


# --------- Current room ----------
def get_current_room(env):
    event = env.controller.last_event
    if event is None:
        print("[MansionGym] No active event; cannot get current room.")
        return None

    pos = event.metadata["agent"]["position"]
    x, z = pos["x"], pos["z"]

    room_polys = get_room_polygons(env.cur_json)
    point_poly = Polygon([(x, z), (x, z), (x, z)]).centroid

    for name, poly in room_polys.items():
        if poly.contains(point_poly):
            return name

    min_dist = float("inf")
    nearest_room = None
    for name, poly in room_polys.items():
        d = poly.distance(point_poly)
        if d < min_dist:
            min_dist = d
            nearest_room = name

    return nearest_room


# --------- Teleportation / routing ----------
def teleport_to_room(env, target_room, from_room=None, offset=1.0):
    """
    Refactor of env.teleport_to_room
    """
    if from_room is None:
        from_room = get_current_room(env)

    # open-door subgraph
    open_edges = [
        (u, v) for u, v, d in env.graph.edges(data=True) if d.get("open", 0) == 1
    ]
    open_graph = nx.Graph()
    open_graph.add_nodes_from(env.graph.nodes())
    open_graph.add_edges_from(open_edges)

    if not nx.has_path(env.graph, from_room, target_room):
        msg = f"No physical connection between {from_room} and {target_room}."
        print(msg)
        return False, msg

    full_path = nx.shortest_path(env.graph, from_room, target_room)
    print(f"Full room path: {' -> '.join(full_path)}")

    blocked_edge = None
    for i in range(len(full_path) - 1):
        a, b = full_path[i], full_path[i + 1]
        if env.graph[a][b].get("open", 0) != 1:
            blocked_edge = (a, b)
            break

    if blocked_edge is None:
        print("[MansionGym] All doors along the path are open. Proceeding.")
        return _teleport_through_open_path(env, full_path)

    # handle blocked
    a, b = blocked_edge
    door_key = (a, b) if (a, b) in env.edge_doors else (b, a)
    door_ids = env.edge_doors.get(door_key, [])
    if not door_ids:
        msg = f"Blocked connection {a}↔{b} but door not found."
        print(msg)
        return False, msg

    door_id = door_ids[0]
    event = env.controller.last_event
    objects = event.metadata.get("objects", [])
    door_obj = next((o for o in objects if o["objectId"] == door_id), None)
    if not door_obj:
        msg = f"Door {door_id} not found in metadata."
        print(msg)
        return False, msg

    poly_curr = get_room_polygons(env.cur_json).get(a)
    centroid = poly_curr.centroid
    x_center = door_obj["axisAlignedBoundingBox"]["center"]["x"]
    z_center = door_obj["axisAlignedBoundingBox"]["center"]["z"]

    stop_pos = {
        "x": round(x_center, 2),
        "y": round(env.init_info["position"]["y"], 2),
        "z": round(z_center, 2),
    }

    door_rotation = door_obj["rotation"]["y"]

    if door_rotation in [0, 180]:
        if z_center < centroid.y:
            yaw = 180
            stop_pos["z"] += offset
        else:
            yaw = 0
            stop_pos["z"] -= offset
    else:
        if x_center < centroid.x:
            yaw = 270
            stop_pos["x"] += offset
        else:
            yaw = 90
            stop_pos["x"] -= offset

    rotation = {"x": 0.0, "y": yaw, "z": 0.0}

    env.controller.step(action="Teleport", position=stop_pos, rotation=rotation)
    msg = f"Path blocked between {a} and {b}. Stopped inside {a}, facing closed door."
    print(msg)
    return False, msg


def _teleport_through_open_path(env, path):
    if len(path) == 1:
        curr_room = path[0]

    for i in range(len(path) - 1):
        curr_room, next_room = path[i], path[i + 1]
        edge_data = env.graph[curr_room][next_room]
        edge_type = edge_data.get("type", "door")

        # Open space
        if edge_type == "open_space":
            room_polys = get_room_polygons(env.cur_json)
            poly_target = room_polys.get(next_room)
            centroid = poly_target.centroid

            target_pos = {
                "x": round(centroid.x, 2),
                "y": round(env.init_info["position"]["y"], 2),
                "z": round(centroid.y, 2),
            }

            event = env.controller.step(
                action="Teleport",
                position=target_pos,
                rotation=env.init_info["rotation"],
                forceAction=True,
                raise_for_failure=True,
            )
            if not event.metadata.get("lastActionSuccess", True):
                msg = (
                    f"Teleport (Open Space) {curr_room} → {next_room} failed: "
                    f"{event.metadata.get('errorMessage', 'Unknown')}"
                )
                print(msg)
                return False, msg
            print(f"Teleported (Open Space) from {curr_room} → {next_room}")
            continue

        # Door connection
        door_key = (curr_room, next_room)
        if door_key not in env.edge_doors:
            door_key = (next_room, curr_room)
        door_ids = env.edge_doors.get(door_key, [])
        if not door_ids:
            msg = f"Missing door between {curr_room} and {next_room}."
            print(msg)
            return False, msg

        door_id = door_ids[0]
        event = env.controller.last_event
        objects = event.metadata.get("objects", [])
        door_obj = next((o for o in objects if o["objectId"] == door_id), None)
        if not door_obj:
            msg = f"Door {door_id} not found."
            print(msg)
            return False, msg

        x_center = door_obj["axisAlignedBoundingBox"]["center"]["x"]
        z_center = door_obj["axisAlignedBoundingBox"]["center"]["z"]
        door_rotation = door_obj["rotation"]["y"]

        room_polys = get_room_polygons(env.cur_json)
        poly_target = room_polys.get(next_room)
        centroid = poly_target.centroid

        if door_rotation in [0, 180]:
            yaw = 0 if z_center < centroid.y else 180
        else:
            yaw = 90 if x_center < centroid.x else 270

        rotation = {"x": 0.0, "y": yaw, "z": 0.0}
        event = env.controller.step(
            action="Teleport",
            position={
                "x": round(x_center, 2),
                "y": round(env.init_info["position"]["y"], 2),
                "z": round(z_center, 2),
            },
            rotation=rotation,
            forceAction=True,
            raise_for_failure=True,
        )
        if not event.metadata.get("lastActionSuccess", True):
            msg = (
                f"Teleport from {curr_room} → {next_room} failed: "
                f"{event.metadata.get('errorMessage', 'Unknown')}"
            )
            print(msg)
            return False, msg
        print(f"Teleported from {curr_room} → {next_room}")

    if "stair" in path[-1].lower() or "elevator" in path[-1].lower():
        env.controller.step(action="MoveBack", moveMagnitude=0.3)

    event = env.controller.last_event
    msg = (
        f"Reached target room {path[-1]} successfully. "
        f"Agent Position : {event.metadata['agent']['position']}"
    )
    print(msg)
    return True, msg
