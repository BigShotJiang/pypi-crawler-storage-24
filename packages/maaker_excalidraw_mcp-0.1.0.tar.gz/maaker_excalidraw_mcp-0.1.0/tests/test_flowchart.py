"""Test flowchart generation."""
import json
import os
import tempfile

from excalidraw_mcp.elements.text import create_labeled_shape, estimate_text_width
from excalidraw_mcp.elements.arrows import create_arrow
from excalidraw_mcp.elements.style import get_color
from excalidraw_mcp.layout.grid import grid_layout
from excalidraw_mcp.utils.file_io import save_excalidraw, load_excalidraw


def test_estimate_text_width_ascii():
    w = estimate_text_width("Hello", 20)
    assert 50 < w < 60  # ~55


def test_estimate_text_width_cjk():
    w = estimate_text_width("你好世界", 20)
    assert 80 < w < 100  # ~88


def test_estimate_text_width_mixed():
    w = estimate_text_width("API Server", 20)
    w_cjk = estimate_text_width("用户请求", 20)
    assert w > 0
    assert w_cjk > 0


def test_create_labeled_shape_text_centered():
    shape, text = create_labeled_shape(
        "rectangle", id="box1", label="测试文字",
        x=100, y=50, width=250, height=70,
    )
    # Text should be centered in the shape
    expected_x = 100 + (250 - text["width"]) / 2
    expected_y = 50 + (70 - text["height"]) / 2
    assert abs(text["x"] - expected_x) < 0.01
    assert abs(text["y"] - expected_y) < 0.01


def test_create_labeled_shape_auto_id():
    shape, text = create_labeled_shape(
        "rectangle", id=None, label="Auto ID",
        x=0, y=0,
    )
    assert shape["id"] is not None
    assert text["id"] == shape["id"] + "_text"
    assert text["containerId"] == shape["id"]


def test_create_labeled_shape_binding():
    shape, text = create_labeled_shape(
        "rectangle", id="s1", label="Test",
        x=0, y=0,
    )
    assert {"id": "s1_text", "type": "text"} in shape["boundElements"]
    assert text["containerId"] == "s1"


def test_arrow_fixedpoint_orbit():
    shape1, _ = create_labeled_shape("rectangle", id="a", label="A", x=0, y=0, width=200, height=70)
    shape2, _ = create_labeled_shape("rectangle", id="b", label="B", x=300, y=0, width=200, height=70)

    arrow = create_arrow("arr1", shape1, shape2)

    assert arrow["startBinding"]["mode"] == "orbit"
    assert arrow["endBinding"]["mode"] == "orbit"
    assert arrow["startBinding"]["fixedPoint"] == [1.0, 0.5001]  # right edge
    assert arrow["endBinding"]["fixedPoint"] == [0.0, 0.5001]    # left edge


def test_arrow_auto_id():
    shape1, _ = create_labeled_shape("rectangle", id="a", label="A", x=0, y=0, width=200, height=70)
    shape2, _ = create_labeled_shape("rectangle", id="b", label="B", x=300, y=0, width=200, height=70)

    arrow = create_arrow(None, shape1, shape2)
    assert arrow["id"] is not None
    assert arrow["id"].startswith("arrow_")


def test_arrow_coordinates():
    shape1, _ = create_labeled_shape("rectangle", id="a", label="A", x=0, y=0, width=200, height=70)
    shape2, _ = create_labeled_shape("rectangle", id="b", label="B", x=300, y=0, width=200, height=70)

    arrow = create_arrow("arr1", shape1, shape2)

    # Arrow starts at right edge of shape1
    assert arrow["x"] == 200  # shape1.x + shape1.width
    assert arrow["y"] == 35   # shape1.y + shape1.height / 2
    # Points relative to start
    assert arrow["points"][0] == [0, 0]
    assert arrow["points"][1] == [100, 0]  # dx to left edge of shape2


def test_arrow_vertical():
    shape1, _ = create_labeled_shape("rectangle", id="a", label="A", x=0, y=0, width=200, height=70)
    shape2, _ = create_labeled_shape("rectangle", id="b", label="B", x=0, y=200, width=200, height=70)

    arrow = create_arrow("arr1", shape1, shape2)
    assert arrow["startBinding"]["fixedPoint"] == [0.5001, 1.0]  # bottom
    assert arrow["endBinding"]["fixedPoint"] == [0.5001, 0.0]    # top


def test_grid_layout_horizontal():
    nodes = [
        {"label": "A"},
        {"label": "B"},
        {"label": "C"},
    ]
    result = grid_layout(nodes, direction="horizontal", columns=3)
    assert len(result) == 3
    # All on same row
    assert result[0]["y"] == result[1]["y"] == result[2]["y"]
    # Increasing x
    assert result[0]["x"] < result[1]["x"] < result[2]["x"]


def test_grid_layout_vertical():
    nodes = [
        {"label": "A"},
        {"label": "B"},
        {"label": "C"},
    ]
    result = grid_layout(nodes, direction="vertical", columns=1)
    assert len(result) == 3
    # All in same column
    assert result[0]["x"] == result[1]["x"] == result[2]["x"]
    # Increasing y
    assert result[0]["y"] < result[1]["y"] < result[2]["y"]


def test_save_and_load():
    shape, text = create_labeled_shape("rectangle", id="s1", label="Test", x=0, y=0)
    with tempfile.NamedTemporaryFile(suffix=".excalidraw", delete=False) as f:
        path = f.name

    try:
        save_excalidraw([shape, text], path)
        data = load_excalidraw(path)
        assert data["type"] == "excalidraw"
        assert data["source"] == "maaker-ai/excalidraw-mcp"
        assert len(data["elements"]) == 2
    finally:
        os.unlink(path)


def test_colors():
    for name in ["blue", "green", "purple", "yellow", "red", "gray", "orange", "pink"]:
        c = get_color(name)
        assert "bg" in c
        assert "stroke" in c

    # Unknown color falls back to blue
    assert get_color("nonexistent") == get_color("blue")


def test_full_flowchart():
    """End-to-end: create a flowchart with CJK text, save, reload, verify."""
    nodes = [
        {"label": "用户请求", "bg": "#a5d8ff", "stroke": "#1971c2"},
        {"label": "负载均衡", "bg": "#b2f2bb", "stroke": "#2f9e44"},
        {"label": "API Server", "bg": "#d0bfff", "stroke": "#7048e8"},
    ]

    laid_out = grid_layout(nodes, direction="horizontal", columns=3)
    all_elements = []
    shape_map = {}

    for item in laid_out:
        shape, text = create_labeled_shape(
            "rectangle", id=None, label=item["label"],
            x=item["x"], y=item["y"],
            width=item["width"], height=item["height"],
            background_color=item["bg"],
        )
        all_elements.extend([shape, text])
        shape_map[item["label"]] = shape

    # Add arrows
    for f, t in [("用户请求", "负载均衡"), ("负载均衡", "API Server")]:
        arrow = create_arrow(None, shape_map[f], shape_map[t])
        all_elements.append(arrow)

    with tempfile.NamedTemporaryFile(suffix=".excalidraw", delete=False) as f:
        path = f.name

    try:
        save_excalidraw(all_elements, path)
        data = load_excalidraw(path)

        elements = data["elements"]
        shapes = [e for e in elements if e["type"] == "rectangle"]
        texts = [e for e in elements if e["type"] == "text"]
        arrows = [e for e in elements if e["type"] == "arrow"]

        assert len(shapes) == 3
        assert len(texts) == 3
        assert len(arrows) == 2

        # Verify text centering
        for text_el in texts:
            container = next(e for e in shapes if e["id"] == text_el["containerId"])
            expected_x = container["x"] + (container["width"] - text_el["width"]) / 2
            assert abs(text_el["x"] - expected_x) < 0.01, f"Text '{text_el['text']}' not centered"

        # Verify arrow bindings use fixedPoint + orbit
        for arrow_el in arrows:
            assert arrow_el["startBinding"]["mode"] == "orbit"
            assert arrow_el["endBinding"]["mode"] == "orbit"
            assert "fixedPoint" in arrow_el["startBinding"]
            assert "fixedPoint" in arrow_el["endBinding"]
    finally:
        os.unlink(path)
