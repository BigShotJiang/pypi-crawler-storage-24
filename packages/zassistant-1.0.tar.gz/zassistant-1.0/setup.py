from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.develop import develop
import time
import sys
import os

# This reads your README.md so PyPI isn't blank and Twine stops complaining
long_description = ""
if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()

def run_animation():
    print("Checking python version...")
    time.sleep(1.5) # Increased from 0.8
    
    steps = [
        ("main.py", "Installing main.py..."),
        ("__init__.py", "Installing __init__.py..."),
        ("zassistant/", "Installing zassistant/...")
    ]

    for file_id, label in steps:
        for i in range(0, 101, 5): # Changed step from 10 to 5 for smoother/longer feel
            chars = ["|", "/", "-", "\\"]
            for char in chars:
                sys.stdout.write(f"\r{label} {char} {i}%")
                sys.stdout.flush()
                # SLOWER: Increased from 0.03 to 0.08
                time.sleep(0.08) 
        
        sys.stdout.write(f"\r{label} success                             \n")
        sys.stdout.flush()

    print("Checking all downloaded files...", end="", flush=True)
    time.sleep(2.0) # Increased from 1.0
    print(" checking success")
    print("\033[92mDownload success.\033[0m")

class CustomInstall(install):
    def run(self):
        run_animation()
        install.run(self)

class CustomDevelop(develop):
    def run(self):
        run_animation()
        develop.run(self)

setup(
    name="zassistant",
    version="1.0",
    packages=find_packages(),
    # Adding these lines fixes your Twine warnings:
    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=['google-genai'],
    entry_points={
        'console_scripts': [
            'start_zassistant=zassistant.main:main',
        ],
    },
    cmdclass={
        'install': CustomInstall,
        'develop': CustomDevelop,
    },
)