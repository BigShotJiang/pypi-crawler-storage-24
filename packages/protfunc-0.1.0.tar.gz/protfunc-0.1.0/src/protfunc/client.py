"""
protfunc — Python SDK for the POOL / GRASP-Func protein functional site prediction server.
"""

from __future__ import annotations

import io
import json
import os
import time
import zipfile
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Callable, List, Optional, Union

import requests


# ------------------------------------------------------------------
# Progress types
# ------------------------------------------------------------------

class Status(Enum):
    STARTED = "started"
    UPLOADING = "uploading"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class ProgressEvent:
    """Passed to the user's callback at each stage transition."""

    stage: str
    """Name of the current pipeline step, e.g. ``"pool"``, ``"preprocess"``."""

    status: Status
    """Current status of this step."""

    elapsed: float
    """Seconds elapsed since this step started."""

    message: str = ""
    """Optional human-readable detail."""

    step: int = 0
    """1-indexed step number within a multi-step pipeline (0 if standalone)."""

    total_steps: int = 0
    """Total steps in the pipeline (0 if standalone)."""


def _default_callback(event: ProgressEvent) -> None:
    """Built-in console progress reporter."""
    prefix = f"[{event.step}/{event.total_steps}]" if event.total_steps else "→"

    if event.status == Status.STARTED:
        print(f"{prefix} {event.stage}: starting...")
    elif event.status == Status.UPLOADING:
        print(f"{prefix} {event.stage}: uploading ({event.message})...")
    elif event.status == Status.RUNNING:
        print(f"{prefix} {event.stage}: running...")
    elif event.status == Status.COMPLETED:
        print(f"{prefix} {event.stage}: ✓ done ({event.elapsed:.1f}s)")
    elif event.status == Status.FAILED:
        print(f"{prefix} {event.stage}: ✗ failed ({event.message})")


# Sentinel to distinguish "not provided" from explicit None/False
_UNSET = object()


# ------------------------------------------------------------------
# Errors
# ------------------------------------------------------------------

class ProtFuncError(Exception):
    """Raised when the server returns an error."""

    def __init__(self, message: str, status_code: int | None = None):
        self.status_code = status_code
        super().__init__(message)


# ------------------------------------------------------------------
# Client
# ------------------------------------------------------------------

class Client:
    """Thin client that wraps the POOL / GRASP-Func server API.

    Parameters
    ----------
    base_url : str
        Root URL of the hosted server (no trailing slash).
    timeout : int
        Request timeout in seconds. Pipeline steps can be slow,
        so the default is generous (30 minutes).
    on_progress : callable, False, or None
        Default progress callback for all methods.
        ``None`` → built-in console output.
        ``False`` → silent.
        A callable → your custom handler receiving :class:`ProgressEvent`.
    """

    def __init__(
        self,
        base_url: str = "https://protfunc.lab.cos.northeastern.edu",
        timeout: int = 1800,
        on_progress: Union[Callable[[ProgressEvent], None], bool, None] = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._default_progress = on_progress
        self._session = requests.Session()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run_pool(
        self,
        input_path: Union[str, Path],
        *,
        output_dir: Optional[Union[str, Path]] = None,
        on_progress: Union[Callable, bool, None, object] = _UNSET,
    ) -> Path:
        """Run the POOL pipeline.

        Parameters
        ----------
        input_path : path
            Directory containing ``.pdb`` files **or** a pre-made ``.zip``.
        output_dir : path, optional
            Where to extract the results. Defaults to ``./pool_results/``.
        on_progress : callable, False, or None
            Override the client-level callback for this call.

        Returns
        -------
        Path
            Directory containing the POOL output files.
        """
        cb = self._resolve_callback(on_progress)
        return self._run_step(
            stage="pool",
            endpoint="/run-pool/",
            input_path=input_path,
            output_dir=output_dir or "./pool_results",
            zip_exts={".pdb"},
            callback=cb,
        )

    def preprocess(
        self,
        input_path: Union[str, Path],
        *,
        output_dir: Optional[Union[str, Path]] = None,
        on_progress: Union[Callable, bool, None, object] = _UNSET,
    ) -> Path:
        """Run GRASP-Func pre-processing.

        Parameters
        ----------
        input_path : path
            Directory with the ``input/family/g*`` structure, or a ``.zip``.
        output_dir : path, optional
            Defaults to ``./preprocessed/``.
        on_progress : callable, False, or None
            Override the client-level callback for this call.

        Returns
        -------
        Path
            Directory containing pre-processed files.
        """
        cb = self._resolve_callback(on_progress)
        return self._run_step(
            stage="preprocess",
            endpoint="/process-zip/",
            input_path=input_path,
            output_dir=output_dir or "./preprocessed",
            callback=cb,
        )

    def process(
        self,
        input_path: Union[str, Path],
        *,
        output_dir: Optional[Union[str, Path]] = None,
        on_progress: Union[Callable, bool, None, object] = _UNSET,
    ) -> Path:
        """Run GRASP-Func processing (graph matching).

        Parameters
        ----------
        input_path : path
            Pre-processed directory or ``.zip``.
        output_dir : path, optional
            Defaults to ``./processed/``.
        on_progress : callable, False, or None
            Override the client-level callback for this call.

        Returns
        -------
        Path
            Directory containing ``results_inter.txt`` and ``results_intra.txt``.
        """
        cb = self._resolve_callback(on_progress)
        return self._run_step(
            stage="process",
            endpoint="/run-processing/",
            input_path=input_path,
            output_dir=output_dir or "./processed",
            callback=cb,
        )

    def visualize(
        self,
        input_path: Union[str, Path],
        *,
        known_proteins: Optional[List[str]] = None,
        output_dir: Optional[Union[str, Path]] = None,
        on_progress: Union[Callable, bool, None, object] = _UNSET,
    ) -> Path:
        """Run GRASP-Func visualization / post-processing.

        Parameters
        ----------
        input_path : path
            Directory or ``.zip`` containing result files.
        known_proteins : list of str, optional
            Protein names to highlight in the output graph.
        output_dir : path, optional
            Defaults to ``./visualization/``.
        on_progress : callable, False, or None
            Override the client-level callback for this call.

        Returns
        -------
        Path
            Directory containing ``multipleAlignment.csv`` and ``graph_output.png``.
        """
        cb = self._resolve_callback(on_progress)
        extra_fields = {"known_proteins": json.dumps(known_proteins or [])}
        return self._run_step(
            stage="visualize",
            endpoint="/visualize/bundle/",
            input_path=input_path,
            output_dir=output_dir or "./visualization",
            extra_fields=extra_fields,
            callback=cb,
        )

    def extract_proteins(
        self,
        input_path: Union[str, Path],
    ) -> List[str]:
        """Extract the list of protein names from result files.

        Parameters
        ----------
        input_path : path
            Directory or ``.zip`` containing ``results_inter.txt`` /
            ``results_intra.txt``.

        Returns
        -------
        list of str
            Sorted protein names found in the results.
        """
        zip_bytes = self._prepare_zip(input_path)
        resp = self._session.post(
            f"{self.base_url}/extract-proteins/",
            files={"zip_file": ("input.zip", zip_bytes, "application/zip")},
            timeout=self.timeout,
        )
        self._check_response(resp)
        data = resp.json()
        if "error" in data:
            raise ProtFuncError(data["error"])
        return data.get("proteins", [])

    def run_graspfunc(
        self,
        input_path: Union[str, Path],
        *,
        known_proteins: Optional[List[str]] = None,
        output_dir: Optional[Union[str, Path]] = None,
        on_progress: Union[Callable, bool, None, object] = _UNSET,
    ) -> Path:
        """Run the full GRASP-Func pipeline (preprocess → process → visualize).

        Parameters
        ----------
        input_path : path
            Directory with the ``input/family/g*`` structure.
        known_proteins : list of str, optional
            Protein names to highlight.
        output_dir : path, optional
            Defaults to ``./graspfunc_results/``.
        on_progress : callable, False, or None
            Override the client-level callback for this call.

        Returns
        -------
        Path
            Directory containing the final visualization files.
        """
        cb = self._resolve_callback(on_progress)
        out = Path(output_dir or "./graspfunc_results")

        def pipeline_cb(event: ProgressEvent) -> None:
            if cb:
                cb(event)

        pre_dir = self._run_step(
            stage="preprocess",
            endpoint="/process-zip/",
            input_path=input_path,
            output_dir=out / "preprocessed",
            callback=pipeline_cb,
            step=1,
            total_steps=3,
        )

        proc_dir = self._run_step(
            stage="process",
            endpoint="/run-processing/",
            input_path=pre_dir,
            output_dir=out / "processed",
            callback=pipeline_cb,
            step=2,
            total_steps=3,
        )

        viz_dir = self._run_step(
            stage="visualize",
            endpoint="/visualize/bundle/",
            input_path=proc_dir,
            output_dir=out / "visualization",
            extra_fields={"known_proteins": json.dumps(known_proteins or [])},
            callback=pipeline_cb,
            step=3,
            total_steps=3,
        )

        return viz_dir

    # ------------------------------------------------------------------
    # Server health
    # ------------------------------------------------------------------

    def ping(self) -> bool:
        """Return ``True`` if the server is reachable."""
        try:
            resp = self._session.get(f"{self.base_url}/", timeout=10)
            return resp.status_code == 200
        except requests.ConnectionError:
            return False

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_callback(
        self, override: Union[Callable, bool, None, object]
    ) -> Optional[Callable[[ProgressEvent], None]]:
        """Determine which callback to use.

        Resolution order:
        1. Per-call ``on_progress`` if explicitly provided.
        2. Client-level ``self._default_progress``.
        3. Built-in console callback.

        ``False`` at any level → silent (returns None).
        """
        choice = override if override is not _UNSET else self._default_progress
        if choice is False:
            return None
        if choice is None:
            return _default_callback
        return choice

    def _emit(
        self,
        callback: Optional[Callable],
        stage: str,
        status: Status,
        elapsed: float,
        message: str = "",
        step: int = 0,
        total_steps: int = 0,
    ) -> None:
        if callback is None:
            return
        callback(ProgressEvent(
            stage=stage,
            status=status,
            elapsed=elapsed,
            message=message,
            step=step,
            total_steps=total_steps,
        ))

    def _run_step(
        self,
        *,
        stage: str,
        endpoint: str,
        input_path: Union[str, Path],
        output_dir: Union[str, Path],
        zip_exts: Optional[set[str]] = None,
        extra_fields: Optional[dict] = None,
        callback: Optional[Callable] = None,
        step: int = 0,
        total_steps: int = 0,
    ) -> Path:
        """Generalized single-step runner with progress events."""
        t0 = time.monotonic()
        emit = lambda status, msg="": self._emit(
            callback, stage, status, time.monotonic() - t0, msg, step, total_steps
        )

        # 1. Prepare ZIP
        emit(Status.STARTED)
        zip_bytes = self._prepare_zip(input_path, exts=zip_exts)
        zip_size_mb = len(zip_bytes) / (1024 * 1024)
        emit(Status.UPLOADING, f"{zip_size_mb:.1f} MB")

        # 2. POST to server
        try:
            emit(Status.RUNNING)
            response_bytes = self._post(
                endpoint, zip_bytes, f"{stage}_input.zip", extra_fields=extra_fields
            )
        except ProtFuncError as exc:
            emit(Status.FAILED, str(exc))
            raise

        # 3. Extract results
        result_dir = self._extract_response(response_bytes, output_dir)
        emit(Status.COMPLETED)
        return result_dir

    def _prepare_zip(
        self,
        path: Union[str, Path],
        exts: Optional[set[str]] = None,
    ) -> bytes:
        """Zip a directory or return raw bytes if already a .zip file."""
        path = Path(path)

        if path.is_file() and path.suffix == ".zip":
            return path.read_bytes()

        if path.is_dir():
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for root, _, files in os.walk(path):
                    for fname in files:
                        fpath = Path(root) / fname
                        if exts and fpath.suffix.lower() not in exts:
                            continue
                        arcname = fpath.relative_to(path)
                        zf.write(fpath, arcname)
            return buf.getvalue()

        raise FileNotFoundError(f"Input path does not exist: {path}")

    def _post(
        self,
        endpoint: str,
        zip_bytes: bytes,
        filename: str,
        extra_fields: Optional[dict] = None,
    ) -> bytes:
        """POST a zip file to the server and return the response body."""
        files = {"zip_file": (filename, zip_bytes, "application/zip")}
        data = extra_fields or {}

        resp = self._session.post(
            f"{self.base_url}{endpoint}",
            files=files,
            data=data,
            timeout=self.timeout,
        )
        self._check_response(resp)
        return resp.content

    def _check_response(self, resp: requests.Response) -> None:
        """Raise a clear error if the server returned a failure."""
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("error", resp.text)
            except Exception:
                detail = resp.text
            raise ProtFuncError(detail, status_code=resp.status_code)

    @staticmethod
    def _extract_response(
        zip_bytes: bytes,
        output_dir: Union[str, Path],
    ) -> Path:
        """Extract a ZIP response into *output_dir* and return the path."""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        buf = io.BytesIO(zip_bytes)
        with zipfile.ZipFile(buf, "r") as zf:
            zf.extractall(output_dir)

        return output_dir