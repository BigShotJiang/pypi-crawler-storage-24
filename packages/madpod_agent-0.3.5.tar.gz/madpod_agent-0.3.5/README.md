# madpod-nanobot

A fork of [HKUDS/nanobot](https://github.com/HKUDS/nanobot) customized for [Madpod](https://madpodai.com) — a task-centric AI agent hosting platform.

## What changed

- **Removed** all upstream messaging channels (Telegram, Discord, Slack, WhatsApp, Email, Feishu, DingTalk, QQ, Matrix)
- **Added** `MadpodChannel` — persistent WebSocket client connecting agents to the Madpod control plane
- **Added** hooks (`activity_logger`, `intervention_detector`) bundled in the package
- **Renamed** package to `madpod-nanobot`

## Install

```bash
uv add madpod-nanobot
```

## Usage

```bash
madpod-nanobot gateway --config /path/to/config.json --workspace /path/to/workspace
```

## Local testing with Madpod dev stack

1. Generate the workspace-root local dev launcher and sync the managed URLs:

```bash
cd api
uv run python -m src.scripts.sync_local_dev
cd ..
```

2. Start the local dependencies, apply DB migrations, and seed a dedicated local task/agent pair:

```bash
docker compose -f docker-compose.dev.yml up -d postgres temporal api temporal-worker
cd /Users/achraf/Desktop/madpod/api
uv run alembic upgrade head
uv run python -m src.scripts.bootstrap_local_nanobot
```

3. Start the local nanobot container with an OpenRouter key:

```bash
OPENROUTER_API_KEY=your-key-here docker compose -f docker-compose.dev.yml --profile nanobot up nanobot-dev
```

The bootstrap script resets and recreates a fixed local task and agent so the `nanobot-dev` service can authenticate against the FastAPI websocket and immediately receive a test assignment.

### Environment variables

| Variable | Description | Default |
|----------|-------------|---------|
| `MADPOD_AGENT_ID` | Agent identifier | (required) |
| `MADPOD_GATEWAY_TOKEN` | Bearer token for WS auth | (required) |
| `MADPOD_CONTROL_PLANE_WS_URL` | Control plane WebSocket URL | `wss://api.madpodai.com` |
| `MODEL` | Primary runtime model | `openrouter/minimax/minimax-m2.5` in Madpod runtime |
| `PLANNER_MODEL` | Optional planner override | unset |
| `EXECUTOR_MODEL` | Optional executor override | unset |
| `SUMMARIZER_MODEL` | Optional summarizer override | unset |
| `BROWSER_BACKEND` | Browser backend (`playwright` or `playwright_mcp`) | `playwright` |
| `BROWSER_HEADLESS` | Force headless browser mode | auto |

## License

MIT — see [LICENSE](LICENSE).
