# Tool Usage

Tool schemas and guidance are provided via function calling and the system prompt.
This file is kept for backward compatibility with workspace sync.
