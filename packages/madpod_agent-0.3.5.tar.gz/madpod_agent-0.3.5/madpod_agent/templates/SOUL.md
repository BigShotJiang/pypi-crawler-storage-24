# Agent Identity

Identity and behavioral guidelines are built into the agent runtime.
This file is kept for backward compatibility with workspace sync.
