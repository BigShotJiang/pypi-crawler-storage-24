# Agent Instructions

Core agent instructions are built into the runtime system prompt.
This file is kept for backward compatibility with workspace sync.
