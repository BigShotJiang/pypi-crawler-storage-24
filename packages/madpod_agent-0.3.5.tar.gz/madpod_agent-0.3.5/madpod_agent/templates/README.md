# Task Templates

Task templates teach agents how to perform specific workflows. They're automatically
matched to incoming tasks by keyword overlap with the task description.

## Formats

### Task Template YAML (recommended for new templates)

Place `.yaml` files in your workspace's `templates/` directory:

```yaml
name: linkedin-outreach
description: Send LinkedIn connection requests with personalized messages
inputs:
  - name: target_role
    description: Job title to search for
  - name: message_template
    description: Connection request message text
role_hint: browser_operator
tools_needed:
  - browser_navigate
  - browser_click
  - browser_type
steps:
  - Navigate to linkedin.com and verify login
  - Search for {{target_role}} professionals
  - For each result, send connection request with message {{message_template}}
  - Record results in workspace/output/outreach-log.csv
```

### SKILL.md (for complex workflows with scripts/references)

Place in `skills/<name>/SKILL.md` with YAML frontmatter:

```markdown
---
name: competitor-monitor
description: Monitor competitor websites for changes and report differences
role_hint: researcher
tools_needed: web_fetch, diff, write_file
inputs: competitor_url, check_frequency
---

## Steps
1. Fetch {{competitor_url}} and save snapshot
2. Compare with previous snapshot using diff
3. Report changes to workspace/output/changes.md
```

### Browser Skill YAML (for domain-specific browser procedures)

These are automatically loaded from `skills/browser_skills/` and provide
anti-detection configs and step-by-step browser procedures per domain.

## Variable Substitution

Use `{{variable_name}}` in your template content. Variables are filled from
the task configuration or prompted from the user at task creation time.
