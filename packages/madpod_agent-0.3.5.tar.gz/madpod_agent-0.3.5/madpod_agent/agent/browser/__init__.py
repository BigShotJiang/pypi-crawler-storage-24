"""Browser automation layer with enhanced DOM extraction."""
