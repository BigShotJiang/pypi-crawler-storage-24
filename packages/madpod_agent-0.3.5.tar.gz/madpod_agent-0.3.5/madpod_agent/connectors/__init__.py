"""MCP connector registry for curated integrations."""
