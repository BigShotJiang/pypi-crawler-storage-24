"""Helper to locate installed hook scripts."""

from pathlib import Path

HOOKS_DIR = Path(__file__).parent


def activity_logger() -> str:
    """Absolute path to the activity-logger hook script."""
    return str(HOOKS_DIR / "activity_logger.py")


def intervention_detector() -> str:
    """Absolute path to the intervention-detector hook script."""
    return str(HOOKS_DIR / "intervention_detector.py")
