"""CLI module for madpod-agent."""
