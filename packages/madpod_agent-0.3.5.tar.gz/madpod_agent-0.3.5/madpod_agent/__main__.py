"""
Entry point for running madpod-agent as a module: python -m madpod_agent
"""

from madpod_agent.cli.commands import app

if __name__ == "__main__":
    app()
