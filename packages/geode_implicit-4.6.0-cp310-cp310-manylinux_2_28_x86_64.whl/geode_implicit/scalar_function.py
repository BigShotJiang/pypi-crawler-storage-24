#
# Copyright (c) 2019 - 2026 Geode-solutions. All rights reserved.
#

import opengeode

from .lib64.geode_implicit_py_scalar_function import *
ImplicitScalarFunctionLibrary.initialize()
