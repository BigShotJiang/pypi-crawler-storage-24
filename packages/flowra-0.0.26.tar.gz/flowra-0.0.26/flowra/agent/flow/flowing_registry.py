"""FlowingRegistry — typed variables that flow with agent execution.

Variables can have ``on_enter``/``on_exit`` callbacks that fire when the value
changes — either via direct ``set()`` or during context switches (restore/apply). This keeps external ``ContextVar``-based
systems (MLflow, OpenTelemetry) in sync with the flowing context.

Usage::

    from flowra.agent.flow.flowing_registry import FlowingRegistry

    registry = FlowingRegistry()

    # Variable without callbacks
    counter = registry.create_var(default=0)

    # Variable with enter/exit — syncs to an external ContextVar
    span_var = registry.create_var(
        default=None,
        on_enter=lambda span: set_span_in_context(span),       # returns token
        on_exit=lambda token: detach_span_from_context(token),  # receives token
    )
"""

import contextvars
from collections.abc import Callable
from typing import Any

__all__ = ["FlowingRegistry", "FlowingVar"]

_SENTINEL: Any = object()

type FlowingSnapshot = dict[int, Any]


class _VarEntry:
    __slots__ = ("default", "key", "on_enter", "on_exit")

    def __init__(
        self,
        key: int,
        default: Any,
        on_enter: Callable[[Any], Any] | None,
        on_exit: Callable[[Any], None] | None,
    ) -> None:
        self.key = key
        self.default = default
        self.on_enter = on_enter
        self.on_exit = on_exit


class FlowingVar[T]:
    __slots__ = ("__default", "__entry", "__fire_single", "__store")

    def __init__(
        self,
        store: contextvars.ContextVar[FlowingSnapshot],
        entry: _VarEntry,
        default: T,
        fire_single: Callable[[_VarEntry, Any], None],
    ) -> None:
        self.__store = store
        self.__entry = entry
        self.__default = default
        self.__fire_single = fire_single

    def get(self) -> T:
        val = self.__store.get().get(self.__entry.key, self.__default)
        if val is _SENTINEL:
            raise LookupError("FlowingVar has no value and no default")
        return val

    def set(self, value: T) -> None:
        """Does not fire callbacks if the new value is the same object."""
        entry = self.__entry
        if entry.on_enter is not None:
            old_value = self.__store.get().get(entry.key, entry.default)
            self.__store.set({**self.__store.get(), entry.key: value})
            if value is not old_value:
                self.__fire_single(entry, value)
        else:
            self.__store.set({**self.__store.get(), entry.key: value})


class FlowingRegistry:
    """Registry of flowing context variables with optional enter/exit callbacks.

    Engine calls ``fork``/``restore``/``apply``/``snapshot`` during execution.
    Variables with callbacks get their ``on_exit``/``on_enter`` fired on every
    context switch, keeping external systems in sync.
    """

    __slots__ = ("__entries", "__store", "__tokens_store")

    def __init__(self) -> None:
        self.__store: contextvars.ContextVar[FlowingSnapshot] = contextvars.ContextVar("_flowra_registry", default={})
        self.__tokens_store: contextvars.ContextVar[dict[int, Any]] = contextvars.ContextVar(
            "_flowra_registry_tokens", default={}
        )
        self.__entries: list[_VarEntry] = []

    def create_var[T](
        self,
        *,
        default: T = _SENTINEL,
        on_enter: Callable[[T], Any] | None = None,
        on_exit: Callable[[Any], None] | None = None,
    ) -> FlowingVar[T]:
        """Create a new flowing variable.

        Args:
            default: Default value when not set.
            on_enter: Called with the new value when it becomes active.
                Returns an opaque token passed to ``on_exit``.
            on_exit: Called with the token from ``on_enter`` when the value
                is being deactivated (before a new value is entered).
                Requires ``on_enter`` to be set.
        """
        if on_exit is not None and on_enter is None:
            msg = "on_exit requires on_enter"
            raise ValueError(msg)
        if on_enter is not None and default is _SENTINEL:
            msg = "on_enter requires an explicit default value"
            raise ValueError(msg)
        key = len(self.__entries)
        entry = _VarEntry(key=key, default=default, on_enter=on_enter, on_exit=on_exit)
        self.__entries.append(entry)
        return FlowingVar(self.__store, entry, default, self.__fire_single)

    # -- Engine API --

    def fork(self) -> contextvars.Token[FlowingSnapshot]:
        """Create a new scope (copy of current state). Returns token for restore.

        Does NOT fire callbacks — the value hasn't changed, just copied.
        """
        return self.__store.set(dict(self.__store.get()))

    def restore(self, token: contextvars.Token[FlowingSnapshot]) -> None:
        """Restore to the state before the corresponding fork/apply.

        Fires on_exit/on_enter for variables whose value changed.
        """
        old_snapshot = self.__store.get()
        self.__store.reset(token)
        new_snapshot = self.__store.get()
        self.__fire_switch_callbacks(old_snapshot, new_snapshot)

    def snapshot(self) -> FlowingSnapshot:
        """Capture current state for later replay (e.g., before ensure_future)."""
        return self.__store.get()

    def apply(self, snapshot: FlowingSnapshot) -> contextvars.Token[FlowingSnapshot]:
        """Apply a previously captured snapshot. Returns token for restore.

        Fires on_exit/on_enter for variables whose value changed.
        """
        old_snapshot = self.__store.get()
        token = self.__store.set(snapshot)
        self.__fire_switch_callbacks(old_snapshot, snapshot)
        return token

    # -- Callback management --

    def __fire_switch_callbacks(self, old_snapshot: FlowingSnapshot, new_snapshot: FlowingSnapshot) -> None:
        tokens = dict(self.__tokens_store.get())
        changed = False
        for entry in self.__entries:
            if entry.on_enter is None:
                continue
            old_val = old_snapshot.get(entry.key, entry.default)
            new_val = new_snapshot.get(entry.key, entry.default)
            if old_val is not new_val:
                old_token = tokens.pop(entry.key, None)
                if old_token is not None and entry.on_exit is not None:
                    entry.on_exit(old_token)
                new_token = entry.on_enter(new_val)
                if new_token is not None:
                    tokens[entry.key] = new_token
                changed = True
        if changed:
            self.__tokens_store.set(tokens)

    def __fire_single(self, entry: _VarEntry, new_value: Any) -> None:
        tokens = dict(self.__tokens_store.get())
        old_token = tokens.pop(entry.key, None)
        if old_token is not None and entry.on_exit is not None:
            entry.on_exit(old_token)
        assert entry.on_enter is not None
        new_token = entry.on_enter(new_value)
        if new_token is not None:
            tokens[entry.key] = new_token
        self.__tokens_store.set(tokens)
