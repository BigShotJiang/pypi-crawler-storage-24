import copy
import dataclasses
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from .session_storage import ChangeSet, SessionStorage

__all__ = ["InMemorySessionSnapshot", "InMemorySessionStorage"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class InMemorySessionSnapshot:
    """Immutable deep-copy snapshot of all data inside an InMemorySessionStorage."""

    execution: dict[str, Any] | None
    node_states: dict[str, dict[str, Any]]


class InMemorySessionStorage(SessionStorage):
    __slots__ = ("__execution", "__node_states")

    def __init__(self, snapshot: InMemorySessionSnapshot | None = None) -> None:
        if snapshot is not None:
            self.__execution: dict[str, Any] | None = copy.deepcopy(snapshot.execution)
            self.__node_states: dict[str, dict[str, Any]] = copy.deepcopy(snapshot.node_states)
        else:
            self.__execution = None
            self.__node_states = {}

    def snapshot(self) -> InMemorySessionSnapshot:
        """Return a deep-copy snapshot of all stored data."""
        return InMemorySessionSnapshot(
            execution=copy.deepcopy(self.__execution),
            node_states=copy.deepcopy(self.__node_states),
        )

    @asynccontextmanager
    async def begin_transaction(self) -> AsyncIterator[None]:
        yield

    async def has_execution(self) -> bool:
        return self.__execution is not None

    async def save_execution(self, execution: dict[str, Any]) -> None:
        self.__execution = execution

    async def save_node_state(self, key: str, changes: ChangeSet) -> None:
        if key not in self.__node_states:
            self.__node_states[key] = {}
        state = self.__node_states[key]
        state.update(changes.scalars)
        for k, items in changes.appends.items():
            if k not in state:
                state[k] = []
            state[k].extend(items)

    async def load_execution(self) -> dict[str, Any] | None:
        return self.__execution

    async def load_node_state(self, key: str) -> dict[str, Any] | None:
        state = self.__node_states.get(key)
        if state is None:
            return None
        return dict(state)

    async def clear_execution(self) -> None:
        self.__execution = None
