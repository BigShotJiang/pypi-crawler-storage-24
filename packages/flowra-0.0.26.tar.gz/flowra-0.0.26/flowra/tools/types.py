import dataclasses
import enum
from typing import Any

__all__ = ["ToolDefinition", "ToolErrorKind", "ToolResult"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolDefinition:
    name: str
    description: str
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None


class ToolErrorKind(enum.StrEnum):
    UNKNOWN_TOOL = "unknown_tool"
    SCHEMA_VALIDATION = "schema_validation"
    EXECUTION = "execution"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolResult:
    content: str
    is_error: bool = False
    error_kind: ToolErrorKind | None = None
