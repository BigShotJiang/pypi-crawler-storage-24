"""Anthropic prompt caching hook bundles.

Composable hook bundles that set ``cache_control: {"type": "ephemeral"}``
on blocks and tools via the ``PrepareLLMRequestEvent`` hook.

Each bundle handles one caching slot (system, tools, or messages).
The ``NonTransient*`` bundles respect the ``transient`` hint on
blocks/messages/tools — transient content is not cached. The ``*All*``
bundles cache the last block regardless of ``transient``.
"""

import dataclasses

from ...agent import AgentRuntime, Event, HookSubscription
from ...llm import LLMData, LLMRequest, Message
from ..chat import SaveHistoryEvent
from ..tool_loop import PrepareLLMRequestEvent

type HookTarget = AgentRuntime | HookSubscription


def _resolve_hooks(target: HookTarget) -> HookSubscription:
    if isinstance(target, HookSubscription):
        return target
    return target.hooks


__all__ = [
    "AnthropicCacheAllMessages",
    "AnthropicCacheAllSystemMessages",
    "AnthropicCacheAllTools",
    "AnthropicCacheHistoryMessages",
    "AnthropicCacheNonTransientMessages",
    "AnthropicCacheNonTransientSystemMessages",
    "AnthropicCacheNonTransientTools",
]

_HISTORY_BREAKPOINT_KEY = "_anthropic_history_cache_breakpoint"


# -- Helpers --


def _set_cache[T: LLMData](obj: T) -> T:
    return dataclasses.replace(obj, extra={**obj.extra, "cache_control": {"type": "ephemeral"}})


def _clear_cache[T: LLMData](obj: T) -> T:
    if "cache_control" not in obj.extra:
        return obj
    new_extra = {k: v for k, v in obj.extra.items() if k != "cache_control"}
    return dataclasses.replace(obj, extra=new_extra)


def _clear_message_cache[T: Message](messages: list[T]) -> list[T]:
    result = list(messages)
    for i, m in enumerate(result):
        if any("cache_control" in b.extra for b in m.blocks):
            result[i] = dataclasses.replace(m, blocks=[_clear_cache(b) for b in m.blocks])
    return result


def _cache_last_block[T: Message](messages: list[T]) -> list[T]:
    if not messages:
        return messages
    result = _clear_message_cache(messages)
    last = result[-1]
    if last.blocks:
        new_blocks = list(last.blocks)
        new_blocks[-1] = _set_cache(new_blocks[-1])
        result[-1] = dataclasses.replace(last, blocks=new_blocks)
    return result


def _cache_last_non_transient_block[T: Message](messages: list[T]) -> list[T]:
    """Cache the last non-transient block in the non-transient prefix.

    Walk forward: accumulate non-transient messages until first transient is found,
    then cache the last accumulated message. Within that message, accumulate
    non-transient blocks until first transient block, cache the last accumulated block.
    """
    if not messages:
        return messages
    result = _clear_message_cache(messages)
    # Walk forward: accumulate non-transient messages until first transient
    target_idx = -1
    for i in range(len(result)):
        if result[i].transient:
            # Found transient - stop here, target_idx is set to last non-transient
            break
        target_idx = i
    if target_idx >= 0:
        msg = result[target_idx]
        if msg.blocks:
            new_blocks = list(msg.blocks)
            # Walk forward within blocks: accumulate non-transient until first transient
            block_idx = -1
            for j in range(len(new_blocks)):
                if new_blocks[j].transient:
                    # Found transient block - stop here
                    break
                block_idx = j
            if block_idx >= 0:
                new_blocks[block_idx] = _set_cache(new_blocks[block_idx])
                result[target_idx] = dataclasses.replace(msg, blocks=new_blocks)
    return result


# -- System message caching --


class AnthropicCacheAllSystemMessages:
    """Cache the last block of the last system message."""

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        _resolve_hooks(target).on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if request.system:
            event.data.request = dataclasses.replace(request, system=_cache_last_block(request.system))


class AnthropicCacheNonTransientSystemMessages:
    """Cache the last non-transient block in the non-transient prefix."""

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        _resolve_hooks(target).on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if request.system:
            event.data.request = dataclasses.replace(request, system=_cache_last_non_transient_block(request.system))


# -- Tool caching --


class AnthropicCacheAllTools:
    """Cache the last tool definition."""

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        _resolve_hooks(target).on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if not request.tools:
            return
        tools = [_clear_cache(t) for t in request.tools]
        tools[-1] = _set_cache(tools[-1])
        event.data.request = dataclasses.replace(request, tools=tools)


class AnthropicCacheNonTransientTools:
    """Cache the last non-transient tool in the non-transient prefix."""

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        _resolve_hooks(target).on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if not request.tools:
            return
        tools = [_clear_cache(t) for t in request.tools]
        # Walk forward: accumulate non-transient tools until first transient
        target_idx = -1
        for i in range(len(tools)):
            if tools[i].transient:
                # Found transient - stop here
                break
            target_idx = i
        if target_idx >= 0:
            tools[target_idx] = _set_cache(tools[target_idx])
        event.data.request = dataclasses.replace(request, tools=tools)


# -- Message caching --


class AnthropicCacheAllMessages:
    """Cache the last block of the last message."""

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        _resolve_hooks(target).on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if request.messages:
            event.data.request = dataclasses.replace(request, messages=_cache_last_block(request.messages))


class AnthropicCacheNonTransientMessages:
    """Cache the last non-transient block in the non-transient prefix."""

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        _resolve_hooks(target).on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if request.messages:
            event.data.request = dataclasses.replace(
                request, messages=_cache_last_non_transient_block(request.messages)
            )


class AnthropicCacheHistoryMessages:
    """Cache the last message that was in history before the current turn.

    Hooks into ``SaveHistoryEvent`` to mark the last message with a metadata
    breakpoint. In ``PrepareLLMRequestEvent``, finds that marker and sets
    ``cache_control`` on its last block. This avoids cache invalidation on
    every new user message — the cache breakpoint stays on the history boundary.

    Requires ``ChatAgent`` (which emits ``SaveHistoryEvent``).
    """

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        hooks = _resolve_hooks(target)
        hooks.on(SaveHistoryEvent, self.on_save_history)
        hooks.on(PrepareLLMRequestEvent, self.on_prepare)

    @staticmethod
    def on_save_history(event: Event[SaveHistoryEvent]) -> None:
        messages = event.data.messages
        if not messages:
            return
        last = messages[-1]
        if last.blocks:
            messages[-1] = dataclasses.replace(last, metadata={**last.metadata, _HISTORY_BREAKPOINT_KEY: True})

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if not request.messages:
            return

        messages = _clear_message_cache(request.messages)

        # Find last message with the breakpoint marker
        breakpoint_idx = -1
        for i, m in enumerate(messages):
            if m.metadata.get(_HISTORY_BREAKPOINT_KEY):
                breakpoint_idx = i

        if breakpoint_idx >= 0:
            msg = messages[breakpoint_idx]
            if msg.blocks:
                new_blocks = list(msg.blocks)
                new_blocks[-1] = _set_cache(new_blocks[-1])
                messages[breakpoint_idx] = dataclasses.replace(msg, blocks=new_blocks)

        event.data.request = dataclasses.replace(request, messages=messages)
