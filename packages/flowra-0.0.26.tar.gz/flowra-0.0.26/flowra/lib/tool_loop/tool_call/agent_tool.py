from collections.abc import Callable

import jsonschema
import marshmallow_recipe as mr

from ....agent.definition import AbstractAgent, AgentDefinition, AgentDefinitionRef, AgentRef
from ....tools import LocalTool, ToolDefinition, ToolExecutionContext, ToolResult
from .context import ToolCallAgentContext

__all__ = ["agent_tool", "get_agent_tool", "make_agent_tool"]

_AGENT_TOOL_ATTR = "__agent_tool__"


def make_agent_tool(
    agent: AgentDefinitionRef,
    *,
    name: str,
    description: str | None = None,
    agent_ref: AgentRef | None = None,
) -> LocalTool:
    """Build a LocalTool that delegates to an agent via call_agent().

    The tool's input_schema is derived from the agent's entry step spec type.
    When the LLM calls this tool, ToolCallAgent will spawn the agent and
    return its result as a ToolResultBlock.

    If ``description`` is not provided, it is taken from the agent class docstring.

    ``agent`` can be an agent class or an AgentDefinition.
    By default, call_agent uses the agent class directly. Pass ``agent_ref``
    to reference the agent by a string path instead (e.g. for agents
    registered elsewhere in the hierarchy, or when using AgentDefinition).
    """
    resolved_description = description
    if resolved_description is None:
        doc = getattr(agent, "__doc__", None)
        if not doc:
            raise ValueError(f"Agent tool '{name}' must have description or agent class docstring")
        resolved_description = doc.strip()
    agent_def = agent if isinstance(agent, AgentDefinition) else agent.__agent_definition__
    if len(agent_def.spec_types) != 1:
        raise TypeError(f"agent_tool requires exactly one spec type, got {len(agent_def.spec_types)}")
    spec_type = next(iter(agent_def.spec_types))
    input_schema = mr.json_schema(spec_type)

    if agent_ref is not None:
        ref: AgentRef = agent_ref
    elif isinstance(agent, type):
        ref = agent
    else:
        raise TypeError("agent_ref is required when agent is an AgentDefinition")

    async def handler(ctx: ToolExecutionContext) -> ToolResult:
        jsonschema.validate(ctx.input, input_schema)
        spec = mr.load(spec_type, ctx.input)
        tool_ctx = ctx.services.get(ToolCallAgentContext)
        if tool_ctx is None:
            raise RuntimeError(
                f"Agent tool '{name}' requires ToolCallAgentContext (only available within ToolCallAgent)"
            )
        tool_ctx.call_agent(ref, spec)
        return ToolResult(content="")

    return LocalTool(
        definition=ToolDefinition(
            name=name,
            description=resolved_description,
            input_schema=input_schema,
        ),
        handler=handler,
    )


def agent_tool[C: type[AbstractAgent]](
    *,
    name: str,
    description: str | None = None,
) -> Callable[[C], C]:
    """Decorator that marks an agent class as a tool.

    If ``description`` is not provided, it is taken from the class docstring.

    Usage::

        @agent_tool(name="greet")
        class GreetAgent(Agent[GreetSpec, GreetResult]):
            \"\"\"Greet someone.\"\"\"
            ...

    Then use ``get_agent_tool(GreetAgent)`` to extract the LocalTool.
    """

    def decorator(cls: C) -> C:
        local_tool = make_agent_tool(cls, name=name, description=description)
        setattr(cls, _AGENT_TOOL_ATTR, local_tool)
        return cls

    return decorator


def get_agent_tool(agent: type[AbstractAgent]) -> LocalTool:
    """Extract LocalTool from an @agent_tool decorated agent class."""
    local_tool = getattr(agent, _AGENT_TOOL_ATTR, None)
    if local_tool is None:
        raise ValueError(f"{agent.__name__} is not decorated with @agent_tool")
    return local_tool
