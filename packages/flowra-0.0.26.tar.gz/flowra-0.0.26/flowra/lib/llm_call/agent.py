import time

from ...agent import Agent, HookEmitter, InterruptToken, step, with_interrupt
from ...llm import ContentComplete, LLMProvider, LLMRequest, TextDelta, ThinkingDelta
from ..config_value import resolve_config_value
from ..llm_config import LLMConfig
from ..observability import LLMCallSpan, TextDeltaEvent, ThinkingDeltaEvent
from .spec import LLMCallResult, LLMCallSpec

__all__ = ["LLMCallAgent"]


class LLMCallAgent(Agent[LLMCallSpec, LLMCallResult]):
    __slots__ = ("__emitter", "__interrupt", "__llm_config", "__provider")

    def __init__(
        self,
        provider: LLMProvider,
        interrupt: InterruptToken,
        emitter: HookEmitter,
        llm_config: LLMConfig,
    ) -> None:
        self.__provider = provider
        self.__interrupt = interrupt
        self.__emitter = emitter
        self.__llm_config = llm_config

    @step(entry=True)
    async def call(self, spec: LLMCallSpec) -> LLMCallResult:
        self.__interrupt.check()

        llm_config = await resolve_config_value(self.__llm_config)

        request = LLMRequest(
            model=llm_config.model,
            system=list(spec.system),
            messages=list(spec.messages),
            temperature=llm_config.temperature,
            top_p=llm_config.top_p,
            max_tokens=llm_config.max_tokens,
            stop_sequences=llm_config.stop_sequences,
            additional_config=llm_config.additional_config,
        )

        t0 = time.monotonic()
        async with self.__emitter.span(LLMCallSpan(request=request)) as llm_span:
            if self.__emitter.has_handlers(TextDeltaEvent) or self.__emitter.has_handlers(ThinkingDeltaEvent):
                response = None
                async for event in with_interrupt(self.__provider.stream(request), self.__interrupt):
                    match event:
                        case TextDelta(text=text):
                            await self.__emitter.emit(TextDeltaEvent(text=text))
                        case ThinkingDelta(text=text):
                            await self.__emitter.emit(ThinkingDeltaEvent(text=text))
                        case ContentComplete(response=resp):
                            response = resp
                assert response is not None
            else:
                response = await self.__provider.call(request)
            llm_span.response = response
        elapsed = time.monotonic() - t0

        return LLMCallResult(message=response.message, usage=response.usage, elapsed=elapsed)
