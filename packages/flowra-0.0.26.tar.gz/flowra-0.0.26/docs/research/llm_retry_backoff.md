# Built-in LLM Retry with Backoff in Tool Loop — Research (March 2026)

Research date: 2026-03-24

## Problem

When LLM providers return transient errors (429 rate limit, 5xx server errors,
network timeouts), the tool loop has no retry logic. The exception propagates
through `ToolLoopAgent.call_llm()` → `Engine.advance()` → `AgentRuntime` and
kills the agent. The user gets an unrecoverable crash on a transient error.

This is a gap in tool loop as a "batteries included" building block. Users
should not need to write a wrapper agent or custom provider to handle the most
common LLM failure mode.

Reference: Strands SDK implements this as `ModelRetryStrategy` — a hook-based
plugin with exponential backoff on `ModelThrottledException`.

## Current state

### What happens on LLM error

```
ToolLoopAgent.call_llm()
  └─ self.__provider.call(request)  ← no try/except
      └─ raises e.g. anthropic.RateLimitError
          └─ propagates to Engine.advance()
              └─ Engine closes all spans with error, re-raises
                  └─ AgentRuntime.__run_loop_inner() sees exception, crashes
```

**No catch, no retry, no backoff.** The agent is dead.

### Provider exceptions

| Provider | Throttling exception | Other transient |
|---|---|---|
| Anthropic (`anthropic` SDK) | `anthropic.RateLimitError` (subclass of `APIStatusError`, status 429) | `APIConnectionError`, `APITimeoutError`, `InternalServerError` (5xx) |
| OpenAI (`openai` SDK) | `openai.RateLimitError` (status 429) | `APIConnectionError`, `APITimeoutError`, `InternalServerError` (5xx) |
| Google (`google.genai`) | `google.api_core.exceptions.ResourceExhausted` (429) | `ServiceUnavailable` (503), `DeadlineExceeded`, transient gRPC errors |

Note: both `anthropic` and `openai` SDKs have their own built-in retry logic
(2 retries by default), so by the time the exception reaches us, the SDK has
already retried. But SDK retries are short (seconds), while real throttling
can last minutes. And SDK retries don't help with extended outages.

### What exists

- **JSON schema validation retry** — in `AnthropicVertexProvider` only, for
  structured output. Not for API errors.
- **`max_consecutive_errors`** — in `ToolLoopConfig`, but for tool execution
  errors (wrong tool calls), not LLM API errors.
- **Crash recovery** — `SessionStorage` can resume after crash, but the user
  has to restart the agent manually. Not the same as automatic retry.

## Where to add retry

### Option A: Inside ToolLoopAgent.call_llm() (recommended)

Wrap the LLM call in a retry loop directly in the tool loop step:

```python
@step("call_llm")
async def call_llm(self) -> GotoStep | Spawn | ToolLoopResult:
    ...
    retry_config = self.__config.retry  # RetryConfig(max_attempts=5, initial_delay=4, max_delay=240)

    for attempt in range(retry_config.max_attempts):
        try:
            async with self.__emitter.span(LLMCallSpan(request=request)) as llm_span:
                response = await self.__provider.call(request)
                llm_span.response = response
            break
        except RETRYABLE_EXCEPTIONS as exc:
            if attempt == retry_config.max_attempts - 1:
                raise
            delay = min(retry_config.initial_delay * (2 ** attempt), retry_config.max_delay)
            # fire event for observability
            await self.__emitter.emit(LLMRetryEvent(attempt=attempt, delay=delay, error=exc))
            await asyncio.sleep(delay)
    ...
```

**Pros:**
- Simple, self-contained, no new abstractions
- Works for both `call()` and `stream()`
- Retry is per-LLM-call, not per-agent — exactly the right scope
- Composable with crash recovery (if all retries fail → crash → resume)
- The tool loop is THE building block; it should own this

**Cons:**
- Hardcoded in tool loop — not configurable via hooks
- But: this is infrastructure, not business logic. Like TCP retransmission.

### Option B: LLMProvider wrapper (decorator)

```python
class RetryProvider(LLMProvider):
    def __init__(self, inner: LLMProvider, config: RetryConfig): ...
    async def call(self, request): ...  # retry loop around inner.call()
```

**Pros:**
- Decoupled from tool loop — works outside agents too
- Provider-agnostic

**Cons:**
- User must wrap every provider manually
- Not "batteries included" — the opposite of what we want
- Streaming retry is tricky (partially consumed stream)
- Doesn't integrate with tool loop observability

### Option C: Hook-based (like Strands)

A hook subscribes to a new `AfterLLMCallEvent` with an `error` field and sets
`event.retry = True`.

**Pros:**
- Pluggable, configurable
- Follows our hook pattern

**Cons:**
- Requires mutable event + retry flag + loop in the tool loop
- Overengineered for what is essentially "sleep and retry on 429"
- Hook state management across retries is subtle
- The Strands approach stores mutable state on the strategy object —
  not great for parallel/concurrent agents sharing the same strategy

### Recommendation: Option A

Retry on transient LLM errors is infrastructure. It belongs in the tool loop
with a simple config, not in a pluggable hook system. The hook system is for
business logic (model fallback, guardrails, caching). Retrying a 429 is not
business logic — it's plumbing.

## Design details

### RetryConfig

```python
@dataclass(frozen=True)
class RetryConfig:
    max_attempts: int = 5           # total attempts (1 = no retry)
    initial_delay: float = 4.0      # seconds
    max_delay: float = 240.0        # seconds
    backoff_factor: float = 2.0     # exponential multiplier
    retryable: Callable[[BaseException], bool] | None = None  # custom predicate
```

Default in `ToolLoopConfig`:
```python
retry: RetryConfig = RetryConfig()
```

### What to retry

Default retryable predicate — check for known transient exceptions from all
three provider SDKs. The user can override with a custom predicate.

Key question: should we catch broad `Exception` and check status codes, or
import provider-specific exceptions? Importing provider SDKs creates unwanted
dependencies. Better approach: a generic check:

```python
def is_retryable(exc: BaseException) -> bool:
    # Check for status code attribute (anthropic, openai)
    status = getattr(exc, "status_code", None) or getattr(exc, "status", None)
    if status in (429, 500, 502, 503, 529):
        return True
    # Check for connection/timeout errors by name pattern
    type_name = type(exc).__name__
    if any(s in type_name for s in ("Timeout", "Connection", "Unavailable")):
        return True
    return False
```

No provider SDK imports needed. Works with any provider.

### Observability

Fire an event/span for each retry so the user can see what's happening:
- `LLMRetryEvent(attempt, delay, error)` — hook event
- Or simply log + emit through existing span hooks

The `LLMCallSpan` should capture the final successful call, not the failed
attempts. Failed attempts can be logged as sub-events or separate lightweight
spans.

### Streaming

For `stream()`, the retry wraps the entire stream creation. If the stream
fails mid-way (connection drop), that's harder — the response is partially
consumed. Options:

1. **Retry only on initial connection errors** — if `stream()` raises before
   yielding any events, retry. If it fails mid-stream, propagate the error.
   This covers 429 (rejected before streaming starts).

2. **Full stream retry** — buffer events and replay on retry. Complex, and
   the user may have already processed some deltas.

Start with (1). Mid-stream failures are rare and a different problem.

### Interrupt integration

The `asyncio.sleep(delay)` during retry backoff should respect the interrupt
token. If the agent is interrupted during a retry wait, it should stop
immediately:

```python
await with_interrupt(asyncio.sleep(delay), self.__interrupt)
```

This already exists in the codebase for stream interruption.

## Relation to other features

| Feature | Relationship |
|---|---|
| **Model fallback** (`model_fallback.md`) | Complementary. Retry handles transient errors (same model). Fallback handles persistent errors (switch model). Could chain: retry N times → fall back to stronger model. |
| **Crash recovery** | Retry is the first line of defense. If all retries fail, crash recovery kicks in. |
| **Hooks** | Retry emits events for observability but is not hook-driven. |
| **`max_consecutive_errors`** | Different scope — tool execution errors, not LLM API errors. |

## Open questions

1. **Should retry config be a `ConfigValue` (callable)?** Probably not — retry
   config rarely needs to change dynamically. Keep it simple.

2. **Jitter?** Exponential backoff with jitter is best practice to avoid
   thundering herd. Add random jitter (±25%) to the delay.

3. **Retry-After header?** Some providers return a `Retry-After` header with
   429 responses. Should we parse it? The SDKs might already handle this in
   their built-in retries, so by the time it reaches us, there's no header.
   Low priority.

4. **Per-provider retry?** Some providers are more aggressive with throttling
   (Google Vertex with short bursts). Should retry config be per-provider?
   Probably not — keep one config, the user can tune it.

5. **Default: on or off?** Should retry be enabled by default? Yes — the
   default `RetryConfig()` should retry with sensible defaults. Users who want
   fail-fast can set `max_attempts=1`.
