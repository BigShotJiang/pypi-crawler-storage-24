# Spawn Strategies: Composable Completion Trees

Research date: 2026-03-12
Implemented: 2026-03-12

## Status: Implemented

All phases implemented:
- Per-node `InterruptTokenSource` with `create_child()` — `flowra/agent/flow/interrupt.py`
- `WhenAll`, `WhenAny`, `WhenN` composable strategies — `flowra/agent/flow/spawn.py`
- `SpawnTreeNode` + tree satisfaction checks — `flowra/agent/runtime/spawn_tree.py`
- `spawn_tree` field on `ExecutionNode` — `flowra/agent/runtime/execution.py`

Design note: the `INTERRUPTED` status proposed below was NOT added. Interruption
is handled purely via tokens — interrupted nodes return `Interrupted()` result and
complete normally with `COMPLETED` status.

## Motivation

Currently `Spawn` takes a flat list of children and waits for **all** of them to complete
before invoking the join-step. This is limiting — many real-world patterns need partial
completion: "take the first result", "wait for 2 out of 3", "race against a timeout".

The goal is to make `Spawn` accept a **composable tree** of completion conditions
(`WhenAll`, `WhenAny`, `WhenN`) instead of a flat list. This requires a prerequisite:
per-node interrupt tokens, so that completed branches can cancel their siblings without
affecting the rest of the execution tree.


## Current architecture (as of 0.0.6)

### InterruptToken

- **One global instance** created in `AgentRuntime.__init__()` (`runtime.py:50`).
- Registered as a service: `{InterruptToken: self.__interrupt_source.token}` (`runtime.py:51`).
- Propagated to all nodes via DI — every agent gets the same token through `services` dict.
- `_InterruptTokenImpl` (`interrupt.py:8`) wraps an `asyncio.Event`. Methods: `set()`,
  `clear()`, `interrupted` property, `wait()`.
- `InterruptTokenSource` (`interrupt.py:31`) owns the impl; exposes `interrupt()` and `clear()`.
- `runtime.interrupt()` calls `self.__interrupt_source.interrupt()` — global kill switch.
- `self.__interrupt_source.clear()` called after each completed run (`runtime.py:151`).

### ExecutionNode

- Mutable dataclass (`execution.py:23`). Fields: `node_id`, `storage_key`, `agent_name`,
  `defn`, `instance`, `scope`, `status`, `pending_step`, `pending_spec`, `children`,
  `child_results`, `then_step`, `result`, `goto_counter`, `parent`.
- Forms a **tree**: `children: list[ExecutionNode] | None`, `parent: ExecutionNode | None`.
- Each node has its own `scope: RuntimeScope` — created in `__create_node()` (`engine.py:274`).
- Scope holds services, slots (Scalar/AppendOnlyList), flush callback.
- Agent instance is tied to scope via `ServiceLocator` — one instance per node.

### Spawn execution

- Step returns `Spawn(children=[...], then="join")` (`agent_def.py:170`).
- `__apply_result` (`engine.py:220`): sets parent to `WAITING_CHILDREN`, creates child
  `ExecutionNode`s via `__create_child_node()`.
- `__collect_actionable()` (`engine.py:130`): recursively collects all `PENDING_STEP` nodes
  across the tree.
- `__execute_nodes()` (`engine.py:143`): runs all actionable nodes in parallel via
  `asyncio.gather()`.
- `__propagate_completions()` (`engine.py:232`): recursively walks the tree; when
  `all(c.status == COMPLETED for c in root.children)`, collects `child_results`, sets parent
  to `PENDING_STEP` with `pending_step = then_step`.
- Join-step receives `list[ChildOutput]` — flat list, children with `result is None` are
  filtered out (`engine.py:242`).

### Persistence

- `__snapshot_tree()` (`runtime.py:186`): serializes entire tree to nested dicts. Children
  serialized as a plain list. No strategy metadata.
- `__restore_tree()` (`runtime.py:213`): reconstructs `ExecutionNode` tree from snapshot.
- `__save_post_advance()` (`runtime.py:156`): saves snapshot + dirty scopes after each
  `advance()` cycle.


## Proposed design

### Part 1: Per-node InterruptToken

**Key insight**: scope is already per-node, and agent instances are already tied to their
node through scope. InterruptToken should follow the same pattern — it's not a global
service, it's a connector to the interrupt state of the current execution node.

#### Changes

1. **`_InterruptTokenImpl` gets parent linkage** (`interrupt.py`):
   - New `__children: list[_InterruptTokenImpl]` field.
   - `set()` cascades: calls `set()` on all children.
   - `register_child()` / `unregister_child()` methods.
   - If parent is already interrupted when child registers, child is immediately interrupted.

2. **`InterruptTokenSource` gains `create_child()` method**:
   - Returns a new `InterruptTokenSource` whose token is linked to the parent token.
   - Child can be interrupted independently (by calling `child_source.interrupt()`).
   - Parent interrupt cascades to child, but not vice versa.

3. **`ExecutionNode` gets its own `InterruptTokenSource`**:
   - New field: `interrupt_source: InterruptTokenSource`.
   - Root node's source is created by `AgentRuntime` (replaces the current global source).
   - Child nodes get sources created via `parent.interrupt_source.create_child()`.

4. **Token injection via scope, not global services**:
   - Remove `InterruptToken` from `self.__services` in `AgentRuntime.__init__()`.
   - In `__create_node()` / `__create_child_node()`, add the node's own token to the
     `merged` services dict before creating the scope.
   - Agent receives its node's token through normal DI — no API change for the agent.

5. **`runtime.interrupt()` interrupts root node's source** — cascades down the tree.

6. **`clear()` semantics change**:
   - `clear()` on a per-node token should only clear that token, not cascade to children.
   - After a completed run, `runtime` clears the root token. On next `run()`, a fresh root
     source is created.
   - WhenAny-interrupted children's tokens remain interrupted — this is correct because those
     nodes are being torn down anyway.

#### Why this is natural

The execution tree already has per-node scopes, per-node instances, per-node storage keys.
InterruptToken is the only service that breaks this pattern by being global. Making it
per-node aligns it with everything else and unlocks subtree-scoped cancellation.


### Part 2: Composable spawn tree — `WhenAll` / `WhenAny` / `WhenN`

#### API

```python
from flowra.agent import CallAgent, CallStep, Spawn, WhenAll, WhenAny, WhenN

# All children must complete (current behavior)
Spawn(WhenAll(child1, child2, child3), then="join")

# First completed — interrupt the rest
Spawn(WhenAny(child1, child2, child3), then="join")

# 2 of 3 — interrupt the remaining one
Spawn(WhenN(child1, child2, child3, n=2), then="join")

# Composable: child1 required, plus any of child2/child3
Spawn(WhenAll(child1, WhenAny(child2, child3)), then="join")

# Race against timeout (Timeout is a trivial built-in agent)
Spawn(WhenAny(do_work, Timeout(minutes=5)), then="join")

# Parallel work with a deadline
Spawn(WhenAny(WhenAll(task1, task2, task3), Timeout(minutes=10)), then="join")

# 2 of 3 groups, each group is all-or-nothing
Spawn(WhenN(
    WhenAll(fetch_a, validate_a),
    WhenAll(fetch_b, validate_b),
    WhenAll(fetch_c, validate_c),
    n=2,
), then="merge")
```

`WhenAny` is `WhenN(n=1)`. `WhenAll` is `WhenN(n=len(children))`. They can be aliases
or separate classes for readability — TBD.

#### Type model

```python
# Recursive type: a spawn node is either a leaf (actual work) or a combinator
type SpawnChild = CallStep | CallAgent  # leaves — actual agent/step execution
type SpawnNode = SpawnChild | WhenAll | WhenAny | WhenN  # recursive

@dataclasses.dataclass(frozen=True, slots=True)
class WhenAll:
    nodes: tuple[SpawnNode, ...]
    def __init__(self, *nodes: SpawnNode): ...

@dataclasses.dataclass(frozen=True, slots=True)
class WhenAny:
    nodes: tuple[SpawnNode, ...]
    def __init__(self, *nodes: SpawnNode): ...

@dataclasses.dataclass(frozen=True, slots=True)
class WhenN:
    nodes: tuple[SpawnNode, ...]
    n: int
    def __init__(self, *nodes: SpawnNode, n: int): ...

class Spawn:
    root: SpawnNode  # was: children: list[SpawnChild]
    then: str
```

Validation at construction:
- `WhenN`: `1 <= n <= len(nodes)`.
- `WhenAny`: at least 1 node.
- `WhenAll`: at least 1 node.

#### Default ergonomics

The common case (wait for all) should not become more verbose. Options:

1. `Spawn` accepts `*args` and wraps in implicit `WhenAll`:
   `Spawn(child1, child2, then="join")` = `Spawn(WhenAll(child1, child2), then="join")`.
2. Keep explicit `WhenAll` always. More consistent but adds a wrapper to the 80% case.

Leaning toward option 1 — backward-compatible, reduces noise.


### Part 3: Engine changes

#### Execution node tree vs combinator tree

The combinator tree (`WhenAll`/`WhenAny`/`WhenN`) is a **logical overlay** on top of
the execution node tree. There are two approaches:

**Option A: Combinator nodes are NOT execution nodes.** Only leaves (`CallStep`/`CallAgent`)
become `ExecutionNode`s. The combinator tree is stored separately on the parent node
(new field: `spawn_tree: SpawnTree | None`). The engine evaluates the combinator tree
against leaf completion states to decide when to trigger the join-step.

**Option B: Combinator nodes ARE execution nodes.** Each `WhenAll`/`WhenAny`/`WhenN` gets
its own `ExecutionNode` with a synthetic agent that just waits for its children. This makes
the node tree and combinator tree identical.

Option A is simpler — combinators are pure logic, not agents. They don't need scopes,
instances, or storage. The engine just needs to evaluate a tree of predicates.

#### `spawn_tree` on ExecutionNode

New field on `ExecutionNode`:

```python
spawn_tree: SpawnTreeNode | None = None
```

Where `SpawnTreeNode` is a lightweight structure that maps combinator positions to child
indices:

```python
@dataclasses.dataclass(frozen=True, slots=True)
class SpawnTreeLeaf:
    child_index: int  # index into node.children

@dataclasses.dataclass(frozen=True, slots=True)
class SpawnTreeAll:
    nodes: tuple[SpawnTreeNode, ...]

@dataclasses.dataclass(frozen=True, slots=True)
class SpawnTreeAny:
    nodes: tuple[SpawnTreeNode, ...]

@dataclasses.dataclass(frozen=True, slots=True)
class SpawnTreeN:
    nodes: tuple[SpawnTreeNode, ...]
    n: int

type SpawnTreeNode = SpawnTreeLeaf | SpawnTreeAll | SpawnTreeAny | SpawnTreeN
```

When `Spawn` is processed in `__apply_result`, the engine:
1. Flattens the combinator tree to extract all leaves (`CallStep`/`CallAgent`).
2. Creates `ExecutionNode` children as today (flat list, indexed).
3. Builds a `SpawnTreeNode` that maps combinator structure to child indices.
4. Stores `spawn_tree` on the parent node.

#### `__propagate_completions` rewrite

Currently: `all(c.status == COMPLETED for c in root.children)`.

New logic — two-pass approach:

**Pass 1: Evaluate.** Recursively evaluate the `spawn_tree` against child statuses.
A `SpawnTreeLeaf` is satisfied when `children[index].status == COMPLETED`.
A `SpawnTreeAll` is satisfied when all sub-nodes are satisfied.
A `SpawnTreeN` is satisfied when `n` sub-nodes are satisfied.
This is a pure function — no side effects.

**Pass 2: Interrupt.** If the tree is satisfied, collect indices of children that are NOT
part of the satisfied set (i.e., they were not needed for the condition). Interrupt their
per-node tokens. Mark those children... (see "Interrupted status" below).

**Pass 3: Collect results.** Same as today, but only for completed (non-interrupted) children.
Transition parent to `PENDING_STEP`.

Important: the evaluate pass runs every `advance()` cycle. It must be idempotent — if
interrupts were already issued in a previous cycle, re-evaluating should not re-issue them.
This is naturally handled if interrupted children either complete (checking their token) or
are marked with a new status.

#### New ExecutionStatus: `INTERRUPTED`?

When WhenAny fires and siblings are interrupted, those siblings may be mid-step. They won't
stop immediately — interrupt is cooperative (polite request). Options:

1. **New status `INTERRUPTED`**: set by the engine when a sibling is no longer needed.
   `__collect_actionable` skips `INTERRUPTED` nodes. If the node was mid-step (in
   `asyncio.gather`), the gather still waits for it to return, but the result is discarded.
   This status is also persisted — on resume, interrupted nodes are skipped.

2. **Just interrupt the token, keep status as-is**: the agent checks its token and returns
   early. Node eventually reaches `COMPLETED`. The combinator tree evaluation distinguishes
   "needed completions" from "unneeded completions".

Option 1 is cleaner for persistence: after crash recovery, the engine knows immediately
which children to skip. Otherwise it would need to re-derive this from the combinator tree.

#### `asyncio.gather` and early exit

`__execute_nodes()` uses `asyncio.gather()` — all actionable nodes run in parallel, and
the gather waits for ALL to return. With WhenAny, once one child finishes we'd ideally
not wait for the others. But `asyncio.gather` doesn't support early exit.

**This is acceptable.** The interrupt is cooperative — agents check their token at yield
points (before LLM calls, during streaming, etc.). The latency between "WhenAny satisfied"
and "siblings actually stop" is bounded by the longest in-flight operation (typically an
LLM call). This is fine for a first implementation.

**Future optimization**: switch from `asyncio.gather` to `asyncio.TaskGroup` or
`asyncio.wait(FIRST_COMPLETED)` with manual task management. This would allow the engine
to process completions incrementally within a single `advance()` cycle.

But note: the current architecture processes completions **between** advance cycles
(`__propagate_completions` runs at the start of each cycle). For WhenAny to trigger
mid-cycle, the engine loop would need restructuring. This is a bigger change and can
be deferred.

#### Join-step result structure

Currently: `list[ChildOutput]` — flat, positional, `None` results filtered out.

For composable trees, the join-step needs to know:
- Which children completed and which were interrupted.
- The structure of the completion tree (which branch of WhenAny won).

Options:

1. **Keep flat list, add status**: `list[CollectedResult]` where `CollectedResult` gains a `status`
   field (`completed` / `interrupted`). Interrupted children have `result=None`.

2. **Tree-shaped result**: mirror the combinator tree structure. Complex, probably over-
   engineered for a first version.

3. **Flat list, only completed children**: same as today. The join-step doesn't see
   interrupted children at all. Simple, but loses information.

Leaning toward option 1 — flat list with status. The join-step can iterate and filter.
The positional indices match `children` list order (leaves in tree traversal order).

```python
class ChildStatus(enum.StrEnum):
    COMPLETED = "completed"
    INTERRUPTED = "interrupted"

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CollectedResult:
    agent_name: str
    result: Any | None  # None if interrupted
    status: ChildStatus
```

### Part 4: Persistence

#### Serializing the spawn tree

`__snapshot_tree()` must include `spawn_tree` for nodes in `WAITING_CHILDREN` status.
The `SpawnTreeNode` types are simple frozen dataclasses — serialize to JSON-like dicts:

```json
{
  "type": "any",
  "nodes": [
    {"type": "leaf", "child_index": 0},
    {"type": "all", "nodes": [
      {"type": "leaf", "child_index": 1},
      {"type": "leaf", "child_index": 2}
    ]}
  ]
}
```

`__restore_tree()` reconstructs the `SpawnTreeNode` from this data.

#### Crash recovery with partial completion

Scenario: `WhenAny(child1, child2)`. child1 completes, engine interrupts child2's token,
child2 is mid-step. Crash happens before child2 notices the interrupt.

On resume:
- child1: `COMPLETED` (persisted).
- child2: `PENDING_STEP` (last persisted state — it hadn't reached a checkpoint after
  being interrupted).
- spawn_tree: `{"type": "any", ...}` (persisted).

The engine runs `__propagate_completions()`:
1. Evaluates spawn_tree: child1 is completed → WhenAny is satisfied.
2. Re-interrupts child2's token (fresh token after restore, not interrupted yet).
3. If child2 is marked `INTERRUPTED` (and that status was persisted), it's skipped.
   If not (crash happened before status update), child2 runs one more step, checks its
   token, returns early, then the next cycle picks it up as completed/interrupted.

This works correctly — the key is that `__propagate_completions()` re-evaluates the
combinator tree on every cycle, including after restore. The worst case is one extra
advance cycle for an interrupted child to notice and stop.


### Part 5: Timeout primitive

`Timeout(minutes=5)` in `WhenAny(do_work, Timeout(minutes=5))` needs to be a child
in the spawn tree — something that runs and completes after a delay.

#### Option A: Timeout as a real agent

Register a built-in `_TimeoutAgent` that:
- Takes a spec with the duration.
- Has a single step that does `await asyncio.sleep(duration)` while checking
  `InterruptToken` (using `with_interrupt` or similar).
- Returns a `TimeoutResult` (or `None`).

Pros: uses existing infrastructure, no special cases in engine.
Cons: needs to be registered in `AgentRegistry`. Could be auto-registered by runtime.

#### Option B: Timeout as an engine primitive

The engine recognizes `Timeout` as a special `SpawnChild` type. Instead of creating an
`ExecutionNode`, it creates a lightweight timer that completes after the duration.

Pros: no agent registration needed, cleaner.
Cons: special case in the engine, persistence is tricky (how to serialize a timer?
need to persist the deadline and check on restore).

#### Option C: Timeout as a combinator-level concern

`WhenAny(..., timeout=300)` — the timeout is a parameter of the combinator, not a child.

Pros: no extra node, clean API for the common case.
Cons: only works at combinator level, not composable as a general child.

**Leaning toward Option A.** It's the most consistent with the "everything is an agent"
philosophy. The engine doesn't need special cases. `AgentRuntime` can auto-register
built-in agents (like `__timeout__`) without user involvement.

Persistence is straightforward: the timeout agent persists its deadline as a `Scalar`.
On resume, it checks `now >= deadline` and completes immediately if the deadline has
passed. This gives "timeout from first start" semantics by default.


## Implementation sketch

### Phase 1: Per-node InterruptToken

1. Add `__children` list and cascade logic to `_InterruptTokenImpl`.
2. Add `create_child()` to `InterruptTokenSource`.
3. Add `interrupt_source: InterruptTokenSource` field to `ExecutionNode`.
4. In `__create_node()` / `__create_child_node()`: create child sources, inject token
   into scope.
5. Remove `InterruptToken` from global `self.__services` in `AgentRuntime`.
6. Update `runtime.interrupt()` to use root node's source.
7. Update `__snapshot_tree()` / `__restore_tree()` — interrupt state is ephemeral,
   no persistence needed. On restore, tokens are re-created and `__propagate_completions`
   re-derives interrupt state.
8. Tests: verify cascade (parent interrupt → child interrupted), isolation (child interrupt
   → parent NOT interrupted), existing interrupt behavior unchanged.

### Phase 2: WhenAll / WhenAny / WhenN types + Spawn API

1. Define `WhenAll`, `WhenAny`, `WhenN` dataclasses and `SpawnNode` type.
2. Update `Spawn` to accept `SpawnNode` as first argument (with `*args` sugar for
   implicit `WhenAll`).
3. Define `SpawnTreeNode` types for engine-internal representation.
4. Validation: n bounds, non-empty nodes.
5. Tests: construction, validation, type checking.

### Phase 3: Engine integration

1. Update `__apply_result` for `Spawn`: flatten tree to leaves, create child nodes,
   build `SpawnTreeNode`, store on parent.
2. Add `spawn_tree` field to `ExecutionNode`.
3. Rewrite `__propagate_completions`: evaluate combinator tree, interrupt siblings,
   collect results.
4. Add `INTERRUPTED` status (or decide against — see design decisions).
5. Update `__collect_actionable` to handle interrupted nodes.
6. Update `CollectedResult` with status field.
7. Update `__snapshot_tree()` / `__restore_tree()` to include `spawn_tree`.
8. Tests: WhenAll (existing behavior), WhenAny, WhenN, nested combinators, crash recovery
   with partial completion.

### Phase 4: Timeout agent

1. Implement `_TimeoutAgent` with deadline-based sleep.
2. Auto-register in `AgentRuntime`.
3. `Timeout(seconds=..., minutes=...)` helper that returns a `CallAgent` pointing to
   the timeout agent.
4. Tests: timeout fires, timeout interrupted before firing, timeout + crash recovery.


## Open questions

1. **Default ergonomics**: should `Spawn(child1, child2, then="join")` implicitly wrap in
   `WhenAll`? This is convenient but hides the combinator. Alternatively, keep `children=`
   keyword for the flat case and require explicit `WhenAll`/`WhenAny` only for strategies.

2. **Error handling in WhenAny**: if a child raises an exception, does that count as
   "completed" for the purpose of WhenAny? Probably not — WhenAny should mean "first
   *successful* completion". But then we need a way to distinguish errors from results.
   Or: let exceptions propagate as today (fail the entire advance cycle) and leave
   error-tolerant semantics for a future `WhenAnySuccessful` combinator.

3. **`INTERRUPTED` as a status vs just token-based**: adding a new `ExecutionStatus` has
   ripple effects across the engine. Alternatively, keep only token-based interruption and
   handle "unneeded completions" in the combinator evaluation. Simpler initially but
   harder for persistence.

4. **Result structure**: flat list with status, or tree? Flat is simpler. Tree preserves
   the combinator structure for the join-step. Could start with flat and add tree later
   if needed.

5. **Timeout semantics on resume**: "time since first start" (persist deadline) or
   "time since last resume" (reset timer on resume)? Probably configurable, with
   "since first start" as default.
