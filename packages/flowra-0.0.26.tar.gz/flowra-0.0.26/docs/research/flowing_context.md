# Flowing Execution Context — Research (March 2026)

Research date: 2026-03-18
Implemented: 2026-03-22

## Status: Superseded

> **Update (2026-03-24):** The `FlowingContextVar` mechanism described in this
> document has been replaced by `FlowingRegistry`/`FlowingVar`. The new mechanism
> lives in `flowra/agent/flow/flowing_registry.py`. Key differences:
> - `FlowingRegistry` is a registry of flowing variables, passed as a service to `AgentRuntime`
> - `FlowingVar[T]` is created via `registry.create_var(default=..., on_enter=..., on_exit=...)`
> - Lifecycle managed via instance methods: `registry.fork()`, `registry.restore()`, `registry.snapshot()`, `registry.apply()`
> - `on_enter`/`on_exit` callbacks fire on context switches, keeping external `ContextVar`s in sync
> - Install functions now take `FlowingRegistry` as first argument: `install_mlflow_tracing(flowing, hooks, ...)`

Originally implemented as `FlowingContextVar` — a generic typed variable that flows with
agent execution. The engine manages the lifecycle (fork/restore around child
creation, snapshot/apply for task inheritance).

See `flowra/agent/flow/flowing_registry.py` for the current implementation.

## Original idea

Make contextual data available from any code during agent execution — not just
from hook handlers, but from any service, HTTP client, middleware, etc.

## What was built

Instead of a single `ExecutionContext` contextvar (as originally proposed), we
built a more general mechanism: `FlowingContextVar[T]`.

Any integration can create typed flowing variables:

```python
from flowra.agent import FlowingContextVar

my_var = FlowingContextVar[str | None]("my_ns.value", default=None)

# In a span handler:
parent_value = my_var.get()
my_var.set("new_value")
```

The engine ensures:
- **Sibling isolation**: fork before each child creation, restore after — siblings
  don't see each other's mutations.
- **Task inheritance**: snapshot after child creation, apply before `ensure_future` —
  each asyncio task inherits the correct flowing context.
- **Resume support**: fork/restore during `open_resumed_spans`.

Under the hood, all `FlowingContextVar` instances share a single
`ContextVar[dict]`. Fork copies the dict, restore resets the ContextVar.

## Key design point

Flowing context is separate from span-hooks. Both use the same switching points
(engine creating/executing nodes), but serve different purposes:
- **Flowing context**: typed value store that flows with execution
- **Span-hooks**: "wrap this operation for observability" — enter/exit callbacks

Span-hooks are *consumers* of the flowing context — they read/write flowing
vars to track their state (e.g., MLflow stores its current parent span).

## Use cases (implemented)

- **MLflow tracing**: `_mlflow_parent: FlowingContextVar[LiveSpan | None]` tracks
  the current MLflow span. Handlers read the parent, create a child, write it back.
  Engine fork/restore automatically handles sibling isolation.

## Use cases (future)

- **HTTP middleware**: inject `X-Request-Id`, `X-Agent-Path` headers
- **Logging**: structured log fields with agent identity
- **Metrics**: tag metrics with agent identity
- **ExecutionContext**: could be exposed as a `FlowingContextVar[ExecutionContext]`
  if needed
