# Hook System Redesign — Research

Research date: 2026-03-08
Implemented: 2026-03-08

## Status: Implemented

Implemented as `HookSubscription` + `HookEmitter` + `Event[T]` in `flowra/agent/flow/hooks.py`.
Span hooks (AgentSpan, StepSpan, LLMCallSpan, ToolCallSpan) in `flowra/agent/runtime/spans.py`
and `flowra/llm/observability.py`. The final naming diverged slightly from this research
(HookRegistry → HookSubscription/HookEmitter), but the architecture matches.

## Problem

Current hook system in `flowra/lib/tool_loop/hooks.py`:

1. **24 Protocol classes** (12 hooks × sync/async variants) — massive boilerplate
2. **12 executor functions** in `hook_executor.py` — nearly identical code
3. **5 result dataclasses** — separate types for hook results
4. **Single handler per hook** — no composition (can't have OTel + logging + guardrails)
5. No isolation — parent agents can't intercept/filter child agent events


## Design decisions

### Event[T] — generic envelope

Handler always receives `Event[T]` — one generic type, no signature inspection magic,
works naturally with lambdas:

```python
@dataclass
class Event[T]:
    data: T
    context: HookContext | None = None


@dataclass
class HookContext:
    agent: str                    # "ResearchAgent"
    agent_path: str               # "coordinator.research"
    execution_path: str | None    # "run_123.step_5.spawn_2"
```

HookRegistry stamps context automatically on emit. Emitting code doesn't know about context.


### Event data — plain dataclasses with mutable result fields

Each hook point is a dataclass. Contains input args and mutable fields for results.
No Protocol classes, no separate result types:

```python
@dataclass
class BeforeLLMCall:
    request: LLMRequest
    context: ToolLoopAgentContext

@dataclass
class BeforeToolCall:
    tool_use: ToolUseBlock
    context: ToolLoopAgentContext
    amended_tool_use: ToolUseBlock | None = None  # handler can set this

@dataclass
class UserMessageEvent:
    user_message: UserMessage
    replacement_messages: list[UserMessage] | None = None  # handler can set this

@dataclass
class TextDeltaEvent:
    text: str
    context: ToolLoopAgentContext
```


### HookRegistry — flat, no hierarchy

No parent/child relationship inside HookRegistry. No bubbling. No propagate flag.
Isolation is handled explicitly by creating separate registries and wiring them manually.

```python
class HookRegistry:
    def __init__(self, context: HookContext | None = None):
        self._context = context
        self._handlers: dict[type, list[Callable]] = {}

    def on[E](self, event_type: type[E], handler: Callable[[Event[E]], Any], *,
              prepend: bool = False) -> None:
        """Add handler. Append by default, prepend=True to go first."""
        handlers = self._handlers.setdefault(event_type, [])
        if prepend:
            handlers.insert(0, handler)
        else:
            handlers.append(handler)

    def has_handlers(self, event_type: type) -> bool:
        """Check if any handlers registered (used for streaming decision)."""
        return bool(self._handlers.get(event_type))

    def add(self, provider: HookProvider) -> None:
        """Register all hooks from a provider."""
        provider.register_hooks(self)

    async def emit[T](self, data: T) -> T:
        """Emit event: wrap in Event[T], call all handlers in order."""
        event = Event(data=data, context=self._context)
        for handler in self._handlers.get(type(data), []):
            result = handler(event)
            if inspect.isawaitable(result):
                await result
        return data

    def propagate_to(self, target: HookRegistry, *,
                     only: list[type] | None = None,
                     exclude: list[type] | None = None) -> None:
        """Subscribe to events and re-emit them to target registry."""
        event_types = only or ALL_EVENT_TYPES
        if exclude:
            event_types = [t for t in event_types if t not in exclude]
        for event_type in event_types:
            self.on(event_type, lambda e, _t=target: _t.emit(e.data))
```


### HookProvider — protocol for grouping related hooks

Distributable hook sets (OTel, logging, guardrails):

```python
class HookProvider(Protocol):
    def register_hooks(self, registry: HookRegistry) -> None: ...
```

```python
class OtelHooks(HookProvider):
    def __init__(self, tracer: Tracer):
        self._tracer = tracer

    def register_hooks(self, registry: HookRegistry) -> None:
        registry.on(BeforeLLMCall, self._start_span)
        registry.on(AfterLLMCall, self._end_span)

    async def _start_span(self, event: Event[BeforeLLMCall]) -> None:
        self._span = self._tracer.start("llm_call", model=event.data.request.model)

    async def _end_span(self, event: Event[AfterLLMCall]) -> None:
        if self._span:
            self._span.end(tokens=event.data.response.usage)
```


### Handler styles — all work

```python
# Lambda
hooks.on(BeforeLLMCall, lambda e: print(e.data.request.model))

# Function
def on_llm(e: Event[BeforeLLMCall]) -> None:
    print(f"{e.context.agent_path}: {e.data.request.model}")

# Async function
async def on_llm(e: Event[BeforeLLMCall]) -> None:
    await tracer.start_span(e.data.request.model)

# Method in HookProvider
class MyHooks(HookProvider):
    def register_hooks(self, registry: HookRegistry) -> None:
        registry.on(BeforeLLMCall, self._on_llm)
    def _on_llm(self, event: Event[BeforeLLMCall]) -> None: ...
```


### Ordering

- `on(EventType, handler)` — appends (default)
- `on(EventType, handler, prepend=True)` — inserts at beginning
- All events — same order (registration order). No reverse for "after" events.
- No wrapping semantics. Hooks are observers, not middleware.


### Child agent isolation — explicit, no magic

No hierarchy inside HookRegistry. Parent creates a separate registry for children
and wires it explicitly:

```python
def __init__(self, hooks: HookRegistry, services: ServiceLocator, ...):
    self._hooks = hooks

    # Children get a separate registry
    child_hooks = HookRegistry()

    # Subscribe to what I care about
    child_hooks.on(BeforeLLMCall, self._on_child_llm)

    # Propagate selected events to my registry
    child_hooks.propagate_to(hooks, exclude=[ThinkingDelta])

    # Provide to children via DI
    services.provide(HookRegistry, child_hooks)
```

Three modes:
- **No isolation**: provide same registry to children — they emit into it directly
- **Full isolation**: `HookRegistry()` without propagation — nothing escapes
- **Selective**: `propagate_to(hooks, exclude=[...])` — filter what goes up


### HookContext — stamped by registry, not by emitting code

HookRegistry is created with a HookContext. The runtime/execution engine sets it
when creating registries for agent execution nodes:

```python
hooks = HookRegistry(context=HookContext(
    agent="ResearchAgent",
    agent_path="coordinator.research",
    execution_path="run_42.step_3.spawn_1",
))
services.provide(HookRegistry, hooks)
```

Agent code just emits data:
```python
await self._hooks.emit(BeforeLLMCall(request=request))
```

Handler sees context:
```python
hooks.on(BeforeLLMCall, lambda e: print(f"[{e.context.agent_path}] LLM call"))
```

HookContext is orthogonal to hook routing — it's informational metadata for
observability, not a mechanism for controlling event flow.


### Error handling

Exceptions from handlers propagate as-is. No catching, no logging, no suppression.
If a handler raises — it's a bug, let it surface. Users can add their own try/except
in handlers if they want resilience.


### Agent usage — in ToolLoopAgent

```python
# Before (current):
await execute_before_llm_call_hook(self.__hooks.on_before_llm_call, request, self.__context)

# After (new):
await self.__hooks.emit(BeforeLLMCall(request=request, context=self.__context))

# Streaming decision (current):
if self.__hooks.on_text_delta is not None or self.__hooks.on_thinking_delta is not None:

# After (new):
if self.__hooks.has_handlers(TextDeltaEvent) or self.__hooks.has_handlers(ThinkingDeltaEvent):
```


## What gets eliminated

| Before | After |
|---|---|
| 24 Protocol classes (sync + async) | 0 |
| 12 executor functions | 1 generic `emit()` |
| 5 Result dataclasses | 0 — mutable fields on event data |
| `ToolLoopHooks` with 12 fields | `HookRegistry` with one dict |
| Single handler per hook | Multiple handlers, ordered |
| No composition | `HookProvider`, `propagate_to()` |
| No isolation | Separate registries, explicit wiring |


## Future ideas (not for initial implementation)

- **Filters on registration**: `hooks.on(BeforeLLMCall, handler, filter=lambda e: ...)`
  to skip handler based on event/context without running the handler.
- **Typed propagate_to**: auto-discover all event types instead of maintaining
  `ALL_EVENT_TYPES` list.
