# Package `flowra.llm`

Provider-agnostic abstraction for calling LLMs.

All public symbols are available from the package root:

```python
from flowra.llm import (
    # Messages
    SystemMessage, UserMessage, AssistantMessage, Message,
    # Content blocks
    TextBlock, ImageBlock, ToolUseBlock, ToolResultBlock, ThinkingBlock,
    # Block type aliases
    UserBlock, AssistantBlock,
    # Tool schema
    Tool,
    # Request / Response
    LLMRequest, LLMResponse, StopReason, Usage, CostBreakdown,
    # Provider interface
    LLMProvider,
    # Streaming
    TextDelta, ThinkingDelta, ContentComplete, StreamEvent,
)

# Observability types have moved to flowra.lib.observability:
from flowra.lib.observability import (
    TextDeltaEvent, ThinkingDeltaEvent,
    LLMCallSpan, ToolCallSpan,
)
```

Do NOT import from internal modules (`flowra.llm.blocks`,
`flowra.llm.messages`, etc.) — always import from `flowra.llm`.

Providers live in separate modules to avoid pulling in heavy SDK dependencies:

```python
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider
from flowra.llm.providers.openai import OpenAIProvider
from flowra.llm.providers.google_vertex import GoogleVertexProvider
```

## Quick start

Create a provider and make a call:

```python
from flowra.llm import LLMRequest, LLMResponse, TextBlock, UserMessage
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider

provider = AnthropicVertexProvider(
    project="my-gcp-project",
    location="us-east5",
    credentials="<base64-encoded service account JSON>",
)

request = LLMRequest(
    model="claude-sonnet-4-5@20250929",
    messages=[UserMessage(blocks=[TextBlock(text="Hello!")])],
    max_tokens=256,
)

response: LLMResponse = await provider.call(request)
print(response.message.blocks[0].text)
```

Same thing with streaming — text arrives token by token, `ContentComplete` at the end
carries the full `LLMResponse`:

```python
from flowra.llm import TextDelta, ContentComplete

async for event in provider.stream(request):
    match event:
        case TextDelta(text=text):
            print(text, end="", flush=True)
        case ContentComplete(response=response):
            print()
            # response.usage, response.stop_reason, etc.
```

---

## Content blocks

Blocks are atomic content units inside messages.

Every block inherits three common fields from the `LLMData` base class:

- **`metadata: dict[str, Any]`** (default `{}`) — arbitrary key-value pairs for application
  use. **Not sent to the LLM** — the provider strips metadata when building API requests.
  Useful for tracking internal state or filtering messages in storage.
- **`extra: dict[str, Any]`** (default `{}`) — provider-specific data passed through as-is.
  Unlike `metadata`, providers may read and write `extra`. For example, `GoogleVertexProvider`
  stores `thought_signature` here when thinking mode is enabled — this signature must be
  preserved across turns for correct reasoning continuity. `AnthropicVertexProvider` merges
  `extra` into the output dict (`**block.extra`), so you can pass `cache_control` and other
  Anthropic-specific fields directly.
- **`transient: bool`** (default `False`) — general-purpose hint that marks content as
  non-permanent. Two effects: (1) `NonTransient*` caching bundles skip transient blocks
  when placing cache breakpoints; (2) `ChatAgent` automatically strips transient messages
  from session history when saving.

### `TextBlock`

Text content. Valid in all message types.

```python
TextBlock(text="Hello, world!")
TextBlock(text="Injected context", transient=True)  # mark as non-permanent
```

| Field   | Type   | Default | Description         |
|---------|--------|---------|---------------------|
| `text`  | `str`  | —       | Text content        |

### `ImageBlock`

Binary image data. Valid in `UserMessage`.

```python
ImageBlock(data=image_bytes, media_type="image/png")
```

| Field        | Type    | Default | Description                               |
|--------------|---------|---------|-------------------------------------------|
| `data`       | `bytes` | —       | Binary image data                         |
| `media_type` | `str`   | —       | MIME type (`"image/png"`, `"image/jpeg"`) |

### `ToolUseBlock`

Tool call request from the LLM. Valid in `AssistantMessage`.
Usually not created manually — comes from `LLMResponse`.

```python
ToolUseBlock(id="toolu_123", name="calculate", input={"expression": "2+2"})
```

| Field   | Type             | Default | Description         |
|---------|------------------|---------|---------------------|
| `id`    | `str`            | —       | Unique call ID      |
| `name`  | `str`            | —       | Tool name           |
| `input` | `dict[str, Any]` | —       | Call parameters     |

### `ToolResultBlock`

Tool execution result. Valid in `UserMessage`. Sent back to the LLM after executing a tool.

```python
ToolResultBlock(tool_use_id="toolu_123", content="4")
ToolResultBlock(tool_use_id="toolu_123", content="Division by zero", is_error=True)
```

| Field         | Type   | Default | Description                          |
|---------------|--------|---------|--------------------------------------|
| `tool_use_id` | `str`  | —       | ID of the corresponding ToolUseBlock |
| `content`     | `str`  | —       | Result text                          |
| `is_error`    | `bool` | `False` | Whether the result is an error       |

### `ThinkingBlock`

Thinking/reasoning content from the LLM. Valid in `AssistantMessage`.
Produced by models with extended thinking enabled (e.g. Anthropic Claude with
`thinking_budget_tokens`, Google Gemini with thinking enabled). Usually not
created manually — comes from `LLMResponse`.

Both `AnthropicVertexProvider` and `GoogleVertexProvider` preserve thinking blocks
when sending history back. Anthropic stores the `signature` in `extra` (required
for validation). `OpenAIProvider` strips them (not supported in the API).

```python
ThinkingBlock(text="Let me reason about this...")
```

| Field   | Type   | Default | Description             |
|---------|--------|---------|-------------------------|
| `text`  | `str`  | —       | Thinking/reasoning text |

### Block type aliases

```python
type UserBlock = TextBlock | ImageBlock | ToolResultBlock
type AssistantBlock = TextBlock | ToolUseBlock | ThinkingBlock
```

These restrict which block types are valid in each message type.

---

## Messages

Three message types, each containing a list of typed blocks.
Like blocks, messages have `metadata`, `extra`, and `transient` fields (inherited from `LLMData`).

### `SystemMessage`

System prompt. Passed in `LLMRequest.system` (separate from conversation messages).
Multiple `SystemMessage` objects are allowed. Contains only `TextBlock` blocks.

```python
SystemMessage(blocks=[TextBlock(text="You are a helpful assistant.")])
```

| Field    | Type              | Description           |
|----------|-------------------|-----------------------|
| `blocks` | `list[TextBlock]` | System prompt content |

### `UserMessage`

User input. Can contain text, images, and tool results.

```python
# Text
UserMessage(blocks=[TextBlock(text="What's the weather in Paris?")])

# Text + image
UserMessage(blocks=[
    TextBlock(text="What's in this picture?"),
    ImageBlock(data=png_bytes, media_type="image/png"),
])

# Tool result
UserMessage(blocks=[
    ToolResultBlock(tool_use_id="toolu_123", content="15°C, cloudy"),
])
```

| Field    | Type              | Description                               |
|----------|-------------------|-------------------------------------------|
| `blocks` | `list[UserBlock]` | Content blocks (text, image, tool result) |

### `AssistantMessage`

LLM response. Contains text, tool calls, and/or thinking blocks.
Usually received from `LLMResponse`, not created manually.

```python
AssistantMessage(blocks=[TextBlock(text="The weather in Paris: 15°C")])
```

| Field    | Type                   | Description                               |
|----------|------------------------|-------------------------------------------|
| `blocks` | `list[AssistantBlock]` | Content blocks (text, tool use, thinking) |

### `Message`

Type alias: `SystemMessage | UserMessage | AssistantMessage`

---

## Tool

Tool definition passed to the LLM in `LLMRequest.tools`. Inherits from `LLMData`
(has `metadata`, `extra`, and `transient` fields). This is the low-level schema
that the provider sends to the LLM API. For defining tools from Python functions, see
the `flowra.tools` package.

```python
Tool(
    name="get_weather",
    description="Get current weather for a city.",
    input_schema={
        "type": "object",
        "properties": {
            "city": {"type": "string", "description": "City name"},
        },
        "required": ["city"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "temperature": {"type": "number"},
            "condition": {"type": "string"},
        },
    },
)
```

| Field           | Type                     | Default | Description                                  |
|-----------------|--------------------------|---------|----------------------------------------------|
| `name`          | `str`                    | —       | Tool name                                    |
| `description`   | `str`                    | —       | Description for the LLM                      |
| `input_schema`  | `dict[str, Any] \| None` | `None`  | JSON Schema for parameters                   |
| `output_schema` | `dict[str, Any] \| None` | `None`  | JSON Schema for return value (informational) |
| `metadata`      | `dict[str, Any]`         | `{}`    | Application metadata (not sent to LLM)       |
| `extra`         | `dict[str, Any]`         | `{}`    | Provider-specific data (passed through)      |
| `transient`     | `bool`                   | `False` | Non-permanent content hint                   |

No LLM API supports tool output schemas natively. Providers use `output_schema` to give
the LLM context about what to expect in `ToolResultBlock.content` — typically by formatting
it as human-readable text and appending to the tool's `description`.

---

## Request and response

### `LLMRequest`

Everything needed for an LLM call.

```python
LLMRequest(
    model="claude-sonnet-4-5@20250929",
    system=[SystemMessage(blocks=[TextBlock(text="You are a calculator.")])],
    messages=[UserMessage(blocks=[TextBlock(text="What is 2+2?")])],
    tools=[calculator_tool],       # optional
    json_schema=my_schema,         # optional — structured output
    temperature=0.0,               # optional
    max_tokens=1024,               # optional
    stop_sequences=["STOP"],       # optional
    max_schema_retries=3,          # optional
    additional_config={},          # optional — provider-specific
)
```

| Field                | Type                                    | Default | Description                          |
|----------------------|-----------------------------------------|---------|--------------------------------------|
| `model`              | `str`                                   | —       | Model identifier                     |
| `system`             | `list[SystemMessage]`                   | `[]`    | System messages                      |
| `messages`           | `list[UserMessage \| AssistantMessage]` | `[]`    | Conversation messages                |
| `tools`              | `list[Tool] \| None`                    | `None`  | Available tools                      |
| `json_schema`        | `dict[str, Any] \| None`                | `None`  | JSON Schema for structured output    |
| `temperature`        | `float \| None`                         | `None`  | Generation temperature               |
| `top_p`              | `float \| None`                         | `None`  | Nucleus sampling threshold           |
| `max_tokens`         | `int \| None`                           | `None`  | Maximum tokens in response           |
| `stop_sequences`     | `list[str] \| None`                     | `None`  | Stop sequences                       |
| `max_schema_retries` | `int`                                   | `3`     | Retries on schema validation failure |
| `additional_config`  | `dict[str, Any]`                        | `{}`    | Provider-specific configuration      |

### `LLMResponse`

Result of an LLM call.

```python
response = await provider.call(request)
response.message        # AssistantMessage
response.stop_reason    # StopReason
response.stop_sequence  # str | None
response.usage          # Usage | None
```

| Field           | Type               | Default | Description                                                |
|-----------------|--------------------|---------|------------------------------------------------------------|
| `message`       | `AssistantMessage` | —       | LLM response message                                       |
| `stop_reason`   | `StopReason`       | —       | Why the model stopped                                      |
| `stop_sequence` | `str \| None`      | `None`  | Which stop sequence triggered (if any)                     |
| `usage`         | `Usage \| None`    | `None`  | Token usage and cost                                       |
| `extra`         | `dict[str, Any]`   | `{}`    | Provider-specific data (e.g. `provider_stop_reason`, `id`) |

### `StopReason`

Why the model stopped generating.

```python
class StopReason(StrEnum):
    END_TURN                 = "end_turn"                  # model finished response
    MAX_TOKENS               = "max_tokens"                # token limit reached
    TOOL_USE                 = "tool_use"                  # model wants to call a tool
    STOP_SEQUENCE            = "stop_sequence"             # stop sequence triggered
    SCHEMA_VALIDATION_FAILED = "schema_validation_failed"  # json_schema validation failed
    OTHER                    = "other"                     # provider-specific or unknown
```

### `Usage`

Token usage metrics with cost estimation and cache breakdown.

**Token contract:** each token is counted in exactly one category.
`input_tokens` does **not** include cached tokens — those go into
`cache_read_input_tokens` and `cache_creation_input_tokens`.

| Field                         | Type                    | Default | Description                    |
|-------------------------------|-------------------------|---------|--------------------------------|
| `input_tokens`                | `int`                   | —       | Input tokens (excluding cache) |
| `output_tokens`               | `int`                   | —       | Output tokens                  |
| `cache_read_input_tokens`     | `int`                   | `0`     | Tokens read from cache         |
| `cache_creation_input_tokens` | `int`                   | `0`     | Tokens written to cache        |
| `cost_usd`                    | `float \| None`         | `None`  | Total estimated cost in USD    |
| `cost`                        | `CostBreakdown \| None` | `None`  | Per-category cost breakdown    |
| `extra`                       | `dict[str, Any]`        | `{}`    | Provider-specific fields       |

`cost_usd` and `cost` are estimated automatically by built-in providers. For unknown
models (not in the pricing table), both are `None`. `cost_usd` is the total cost;
`cost` is a `CostBreakdown` with per-category fields (`input`, `output`, `cache_read`,
`cache_creation`) and a `total` property.

`Usage` supports `+` for aggregation across multiple calls — all fields including
`cost_usd` and `cost` are summed (if either side is `None`, the non-`None` value is kept).
Note that `response.usage` can be `None` — always check before using:

```python
if response.usage is not None:
    total = total + response.usage
```

---

## Provider

### `LLMProvider`

Abstract base class for calling an LLM.

```python
class LLMProvider(abc.ABC):
    @abc.abstractmethod
    async def call(self, request: LLMRequest) -> LLMResponse: ...

    async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
        response = await self.call(request)
        yield ContentComplete(response=response)
```

- `call()` — single request/response (abstract, must implement)
- `stream()` — yields events incrementally (default: calls `call()` + yields `ContentComplete`)
- `aclose()` — close the provider and release resources (default: no-op)

`LLMProvider` is also an async context manager:

```python
async with OpenAIProvider(api_key="...") as provider:
    response = await provider.call(request)
```

The provider converts `LLMRequest` into the target API's format, calls the API, and
converts the response back to `LLMResponse`. If `json_schema` is set, the provider
handles validation and retries.

### Streaming

`stream()` returns an `AsyncIterator[StreamEvent]` with incremental events:

| Event             | Field                   | Description                 |
|-------------------|-------------------------|-----------------------------|
| `TextDelta`       | `text: str`             | Incremental text token      |
| `ThinkingDelta`   | `text: str`             | Incremental thinking token  |
| `ContentComplete` | `response: LLMResponse` | Always last — full response |

`ContentComplete` is always the final event and contains the same `LLMResponse`
you would get from `call()`.

```python
type StreamEvent = TextDelta | ThinkingDelta | ContentComplete
```

```python
async for event in provider.stream(request):
    match event:
        case TextDelta(text=text):
            print(text, end="", flush=True)
        case ThinkingDelta(text=text):
            print(f"[thinking] {text}", end="")
        case ContentComplete(response=response):
            print()
```

All three built-in providers implement real-time `TextDelta` streaming.
`ThinkingDelta` is emitted by `AnthropicVertexProvider` and `GoogleVertexProvider`
(when thinking mode is enabled) — `OpenAIProvider` does not emit thinking events.

---

## Providers

### `AnthropicVertexProvider`

Claude via Vertex AI.

```python
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider

provider = AnthropicVertexProvider(
    project="my-gcp-project",
    location="us-east5",
    credentials="<base64-encoded service account JSON>",
)

# Or with a pre-configured client:
from anthropic import AsyncAnthropicVertex
provider = AnthropicVertexProvider(client=my_anthropic_client)
```

**Constructor** — either `client` or all of `project`/`location`/`credentials`:

| Parameter     | Description                                                                          |
|---------------|--------------------------------------------------------------------------------------|
| `client`      | Pre-configured `AsyncAnthropicVertex`                                                |
| `project`     | GCP project ID                                                                       |
| `location`    | Region (e.g. `"us-east5"`)                                                           |
| `credentials` | Base64-encoded service account JSON                                                  |
| `owns_client` | Close `client` on `aclose()` (default `False`; `True` when created from credentials) |

**Defaults:** `max_tokens` defaults to 4096 when `None`.

**System messages:** Passed via `LLMRequest.system`. Multiple `SystemMessage`
objects are merged into a single system prompt. When any block has a non-empty
`extra` dict, block boundaries are preserved as separate content parts;
otherwise blocks are joined with `"\n\n"`.

**`extra` passthrough:** The provider merges `block.extra` into the output dict
(`**block.extra`). To enable prompt caching on a block, set
`extra={"cache_control": {"type": "ephemeral"}}`. Anthropic supports up to 4
cached elements per request. For automatic cache breakpoint placement, use the
composable hook bundles in `flowra.lib.anthropic` (see `docs/lib/anthropic.md`).

**Tool names:** Validated against `^[a-zA-Z0-9_-]{1,128}$`.

#### Structured output (JSON schema)

Claude does not support structured output natively. The provider implements it via
prompt injection and validation:

1. Includes the schema in the system prompt
2. Calls the LLM
3. Extracts JSON from the response (stripping markdown code fences)
4. Validates against the schema
5. On failure, retries up to `max_schema_retries` times (sends the error back to the LLM)
6. If all retries fail: `stop_reason=StopReason.SCHEMA_VALIDATION_FAILED`

Streaming falls back to non-streaming when `json_schema` is set.

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Three European capitals")])],
        json_schema={
            "type": "object",
            "properties": {"cities": {"type": "array", "items": {"type": "string"}}},
            "required": ["cities"],
        },
        max_tokens=256,
    )
)
if response.stop_reason == StopReason.SCHEMA_VALIDATION_FAILED:
    raw_text = response.message.blocks[0].text
    raise ValueError(f"Schema validation failed. Raw response: {raw_text}")
```

#### Extended thinking

Pass `thinking_budget_tokens` via `additional_config`:

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Solve this step by step...")])],
        max_tokens=8192,
        additional_config={"thinking_budget_tokens": 4000},
    )
)

for block in response.message.blocks:
    if isinstance(block, ThinkingBlock):
        print(f"[thinking] {block.text}")
    elif isinstance(block, TextBlock):
        print(block.text)
```

The provider forces `temperature=1` when thinking is enabled (Anthropic requirement).

### `OpenAIProvider`

OpenAI-compatible APIs (OpenAI, Inception AI, etc.).

```python
from flowra.llm.providers.openai import OpenAIProvider

provider = OpenAIProvider(api_key="sk-...")

# Custom base URL (e.g. Inception AI)
provider = OpenAIProvider(
    api_key="sk_...",
    base_url="https://api.inceptionlabs.ai/v1",
)

# Or with a pre-configured client:
from openai import AsyncOpenAI
provider = OpenAIProvider(client=my_openai_client)
```

**Constructor** — either `client` or `api_key`:

| Parameter      | Description                                                                        |
|----------------|------------------------------------------------------------------------------------|
| `client`       | Pre-configured `AsyncOpenAI`                                                       |
| `api_key`      | API key                                                                            |
| `base_url`     | Base URL for API requests (optional)                                               |
| `organization` | Organization ID (optional)                                                         |
| `owns_client`  | Close `client` on `aclose()` (default `False`; `True` when created from `api_key`) |

**Defaults:** `max_tokens` defaults to 4096 when `None`.

**Structured output:** Uses OpenAI's native `response_format` with `json_schema` type
and `strict: True`. The schema is automatically adapted to strict mode requirements
(all objects get `additionalProperties: false`, all properties become required, optional
fields use `anyOf` with null type).

### `GoogleVertexProvider`

Google Gemini via Vertex AI.

```python
from flowra.llm.providers.google_vertex import GoogleVertexProvider

provider = GoogleVertexProvider(
    project="my-gcp-project",
    location="us-east5",
    credentials="<base64-encoded service account JSON>",
)

# Or with a pre-configured client:
from google import genai
provider = GoogleVertexProvider(client=my_genai_client)
```

**Constructor** — either `client` or all of `project`/`location`/`credentials`:

| Parameter     | Description                                                                          |
|---------------|--------------------------------------------------------------------------------------|
| `client`      | Pre-configured `genai.Client`                                                        |
| `project`     | GCP project ID                                                                       |
| `location`    | Region (e.g. `"us-east5"`)                                                           |
| `credentials` | Base64-encoded service account JSON                                                  |
| `owns_client` | Close `client` on `aclose()` (default `False`; `True` when created from credentials) |

**Defaults:** `max_tokens` defaults to 4096 when `None`.

**System messages:** Passed via `LLMRequest.system`. Multiple `SystemMessage` objects
are joined with `"\n\n"` into a single system instruction.

**Structured output:** Uses Gemini's native `response_schema` with `response_mime_type:
"application/json"`. The schema is automatically adapted (flattens `$ref`/`$defs`,
removes `additionalProperties`, converts type arrays to `anyOf`).

#### Extended thinking

Pass `thinking_level` (Gemini 3) or `thinking_budget` (Gemini 2.5) via `additional_config`:

```python
# Gemini 3 — thinking level
response = await provider.call(
    LLMRequest(
        model="gemini-3-pro-preview",
        messages=[UserMessage(blocks=[TextBlock(text="Solve this step by step...")])],
        max_tokens=4096,
        additional_config={"thinking_level": "medium"},
    )
)

# Gemini 2.5 — thinking budget
response = await provider.call(
    LLMRequest(
        model="gemini-2.5-pro",
        messages=[UserMessage(blocks=[TextBlock(text="Solve this step by step...")])],
        max_tokens=4096,
        additional_config={"thinking_budget": 4096},
    )
)
```

### Adding a custom provider

Inherit from `LLMProvider` and implement `call()`:

```python
from flowra.llm import LLMProvider, LLMRequest, LLMResponse

class MyProvider(LLMProvider):
    async def call(self, request: LLMRequest) -> LLMResponse:
        # Convert request to your API format, call it, convert response back
        ...
```

Override `stream()` for real-time streaming support.

---

## Examples

### Simple call

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Capital of France?")])],
        max_tokens=64,
    )
)
print(response.message.blocks[0].text)  # "Paris"
```

### System prompt with caching

Manual approach — set `cache_control` via `extra`:

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        system=[SystemMessage(blocks=[
            TextBlock(
                text="Long instructions...",
                extra={"cache_control": {"type": "ephemeral"}},
            ),
        ])],
        messages=[UserMessage(blocks=[TextBlock(text="Question")])],
        max_tokens=1024,
    )
)
```

For automatic cache breakpoint placement, use `flowra.lib.anthropic` hook bundles
(see `docs/lib/anthropic.md`).

### Tool use (full cycle)

```python
weather_tool = Tool(
    name="get_weather",
    description="Current weather for a city.",
    input_schema={
        "type": "object",
        "properties": {"city": {"type": "string"}},
        "required": ["city"],
    },
)

# 1. Send request with tool
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Weather in Paris?")])],
        tools=[weather_tool],
        max_tokens=256,
    )
)
# response.stop_reason == StopReason.TOOL_USE

# 2. Extract tool call
tool_use = next(b for b in response.message.blocks if isinstance(b, ToolUseBlock))

# 3. Execute tool and return result
result = get_weather(tool_use.input["city"])  # your logic

response2 = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[
            UserMessage(blocks=[TextBlock(text="Weather in Paris?")]),
            response.message,  # AssistantMessage with ToolUseBlock
            UserMessage(blocks=[
                ToolResultBlock(tool_use_id=tool_use.id, content=result),
            ]),
        ],
        tools=[weather_tool],
        max_tokens=256,
    )
)
```

### Usage tracking

```python
response = await provider.call(request)
if response.usage is not None:
    u = response.usage
    print(f"Input: {u.input_tokens}")
    print(f"Output: {u.output_tokens}")
    print(f"Cache read: {u.cache_read_input_tokens}")
    print(f"Total cost: ${u.cost_usd}")
    if u.cost is not None:
        print(f"  Input cost:  ${u.cost.input:.6f}")
        print(f"  Output cost: ${u.cost.output:.6f}")
```

---

## Public API summary

| Symbol               | Kind       | Description                                                            |
|----------------------|------------|------------------------------------------------------------------------|
| `SystemMessage`      | dataclass  | System prompt message                                                  |
| `UserMessage`        | dataclass  | User input message                                                     |
| `AssistantMessage`   | dataclass  | LLM response message                                                   |
| `Message`            | type alias | Union of all message types                                             |
| `TextBlock`          | dataclass  | Text content                                                           |
| `ImageBlock`         | dataclass  | Binary image                                                           |
| `ToolUseBlock`       | dataclass  | Tool call from LLM                                                     |
| `ToolResultBlock`    | dataclass  | Tool result for LLM                                                    |
| `ThinkingBlock`      | dataclass  | Thinking/reasoning content                                             |
| `UserBlock`          | type alias | Valid blocks in UserMessage                                            |
| `AssistantBlock`     | type alias | Valid blocks in AssistantMessage                                       |
| `Tool`               | dataclass  | Tool definition for LLM                                                |
| `LLMRequest`         | dataclass  | Request to LLM                                                         |
| `LLMResponse`        | dataclass  | Response from LLM                                                      |
| `StopReason`         | enum       | Why the model stopped                                                  |
| `Usage`              | dataclass  | Token counts and cost                                                  |
| `CostBreakdown`      | dataclass  | Per-category cost breakdown                                            |
| `LLMProvider`        | ABC        | Abstract provider interface                                            |
| `TextDelta`          | dataclass  | Stream event: text token                                               |
| `ThinkingDelta`      | dataclass  | Stream event: thinking token                                           |
| `ContentComplete`    | dataclass  | Stream event: final response                                           |
| `StreamEvent`        | type alias | Union of stream events                                                 |
| `TextDeltaEvent`     | dataclass  | Hook event: streaming text token (moved to `flowra.lib.observability`) |
| `ThinkingDeltaEvent` | dataclass  | Hook event: streaming thinking (moved to `flowra.lib.observability`)   |
| `LLMCallSpan`        | dataclass  | Span type for LLM calls (moved to `flowra.lib.observability`)          |
| `ToolCallSpan`       | dataclass  | Span type for tool calls (moved to `flowra.lib.observability`)         |
