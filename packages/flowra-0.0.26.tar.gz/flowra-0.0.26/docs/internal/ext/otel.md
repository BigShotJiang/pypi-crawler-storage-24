# OpenTelemetry tracing (`flowra.ext.otel`)

Maps flowra span-hooks to OpenTelemetry spans with GenAI semantic conventions.
Works with any OTel backend — Jaeger, Grafana Tempo, Datadog, Honeycomb, etc.

**Install:** `pip install flowra[otel]`

```python
from flowra.agent import HookSubscription
from flowra.ext.otel import install_otel_tracing

hooks = HookSubscription()
install_otel_tracing(hooks)
# pass hooks to AgentRuntime via services={HookSubscription: hooks, ...}
```

Users configure their own `TracerProvider` and exporter — flowra just creates spans.

## What gets traced

| Span type      | OTel span name               | GenAI operation    | Default |
|----------------|------------------------------|--------------------|---------|
| `AgentSpan`    | `invoke_agent {name}`        | `invoke_agent`     | on      |
| `StepSpan`     | `{step_name}`                | —                  | on      |
| `LLMCallSpan`  | `chat {model}`               | `chat`             | on      |
| `ToolCallSpan` | `execute_tool {tool_name}`   | `execute_tool`     | on      |

LLM call spans include token usage, cost, model, provider, temperature, finish reasons.

## GenAI semantic conventions

Attributes follow the [OTel GenAI semantic conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/):

- `gen_ai.operation.name` — `invoke_agent`, `chat`, `execute_tool`
- `gen_ai.provider.name` — extracted from model string (e.g. `anthropic`)
- `gen_ai.request.model`, `gen_ai.request.temperature`, `gen_ai.request.max_tokens`
- `gen_ai.response.finish_reasons`
- `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`
- `gen_ai.usage.cache_read.input_tokens`, `gen_ai.usage.cache_creation.input_tokens`
- `gen_ai.usage.cost` — total cost in USD
- `gen_ai.agent.name` — agent path (e.g. `app/chat/tool_loop`)
- `gen_ai.tool.name`, `gen_ai.tool.call.id`
- `flowra.tool.error_kind` — error classification when tool call fails (`UNKNOWN_TOOL`, `SCHEMA_VALIDATION`, `EXECUTION`)
- `gen_ai.conversation.id` — session ID (if provided)

## Parameters

```python
install_otel_tracing(
    hooks,
    tracer_name="flowra",        # OTel tracer name
    trace_agents=True,           # AgentSpan
    trace_steps=True,            # StepSpan
    trace_llm_calls=True,        # LLMCallSpan
    trace_tool_calls=True,       # ToolCallSpan
    capture_content=False,       # capture tool arguments/results (off for privacy)
    session_id="my-session",     # gen_ai.conversation.id
)
```

## Setup examples

### Jaeger (local development)

```bash
# Start Jaeger
docker run -d --name jaeger -p 16686:16686 -p 4317:4317 jaegertracing/all-in-one

# Open http://localhost:16686, service "flowra"
```

```python
from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

provider = TracerProvider(resource=Resource.create({"service.name": "my-service"}))
provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint="http://localhost:4317")))
trace.set_tracer_provider(provider)
```

### Console (debugging)

```python
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor, ConsoleSpanExporter

provider = TracerProvider()
provider.add_span_processor(SimpleSpanProcessor(ConsoleSpanExporter()))
trace.set_tracer_provider(provider)
```

## External context integration

When no flowra parent exists (root of execution), `_start_span` checks for an
external OTel span via `trace.get_current_span()`. If a recording span is found,
flowra's root span becomes a child of the external span.

This allows flowra to nest inside existing OTel traces — e.g. when called
from a `tracer.start_as_current_span()` block:

```python
from opentelemetry import trace

app_tracer = trace.get_tracer("my_app")

with app_tracer.start_as_current_span("my_business_logic"):
    # flowra spans become children of "my_business_logic"
    result = await runtime.run(agent=MyAgent, spec=MySpec(...))
```

Priority: internal flowra context (`FlowingVar`) > external OTel context
(`trace.get_current_span()`). External context is only used at the root.
Non-recording spans (e.g. `INVALID_SPAN`) are ignored.

## Using with MLflow

Both integrations can run side by side — they use independent `FlowingVar`
instances and create separate span trees in their respective backends:

```python
from flowra.ext.mlflow import install_mlflow_tracing
from flowra.ext.otel import install_otel_tracing

hooks = HookSubscription()
install_mlflow_tracing(hooks, experiment_name="my-experiment")
install_otel_tracing(hooks)
```

Alternatively, MLflow can export to OTel backends via dual export
(`MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT=true`) — in that case you only need
the MLflow integration.

## Examples

```bash
make otel-demo              # basic OTel tracing (console)
make otel-nested-demo       # external OTel span wrapping flowra (console)
make otel-nested-visualize  # same, with tree visualization
make otel-jaeger-demo       # external OTel span, exported to Jaeger
```
