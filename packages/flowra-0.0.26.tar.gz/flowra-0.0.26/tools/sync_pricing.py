#!/usr/bin/env python3
"""Sync LLM pricing from litellm into ``flowra/llm/pricing/data/generated.json``.

Usage:
    python tools/sync_pricing.py           # show diff only
    python tools/sync_pricing.py --apply   # update generated.json
    python tools/sync_pricing.py --local path/to/file.json   # use local file instead of fetching

Fetches the latest pricing data from litellm's GitHub repository, filters to
chat models from supported providers, and writes a clean JSON file.
"""

import json
import sys
import urllib.request
from pathlib import Path
from typing import Any

LITELLM_URL = "https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json"

GENERATED_JSON = Path(__file__).parent.parent / "flowra" / "llm" / "pricing" / "data" / "generated.json"

# litellm provider → our provider key.  Unlisted providers are skipped.
PROVIDER_MAP: dict[str, str] = {
    "anthropic": "anthropic",
    "vertex_ai-anthropic_models": "anthropic",
    "openai": "openai",
    "vertex_ai": "google",
    "vertex_ai-language-models": "google",
    "gemini": "google",
}


def fetch_litellm(local_path: str | None = None) -> dict[str, Any]:
    if local_path:
        return json.loads(Path(local_path).read_text())
    with urllib.request.urlopen(LITELLM_URL) as resp:
        return json.loads(resp.read())


def _per_m(cost_per_token: float | None) -> float:
    """Convert per-token cost to $/1M tokens, rounded to 6 decimals."""
    if cost_per_token is None or cost_per_token == 0:
        return 0.0
    return round(cost_per_token * 1_000_000, 6)


def _normalize_model(litellm_key: str) -> str:
    """Strip provider prefixes from litellm keys.

    Examples:
        "vertex_ai/claude-sonnet-4-6"         → "claude-sonnet-4-6"
        "vertex_ai/claude-sonnet-4-6@default"  → "claude-sonnet-4-6"
        "gemini/gemini-2.5-flash"              → "gemini-2.5-flash"
        "claude-sonnet-4-6"                    → "claude-sonnet-4-6"
    """
    # Strip everything before (and including) the last "/"
    if "/" in litellm_key:
        litellm_key = litellm_key.rsplit("/", 1)[1]
    # Strip @version suffixes (e.g. "@default", "@20250514")
    if "@" in litellm_key:
        litellm_key = litellm_key.split("@", 1)[0]
    return litellm_key


def _extract_pricing(entry: dict[str, Any]) -> dict[str, float]:
    """Extract pricing fields from a litellm entry into our format."""
    result: dict[str, float] = {}

    # Base rates
    for our_field, litellm_field in [
        ("input", "input_cost_per_token"),
        ("output", "output_cost_per_token"),
        ("cache_read", "cache_read_input_token_cost"),
        ("cache_creation", "cache_creation_input_token_cost"),
        ("cache_creation_1h", "cache_creation_input_token_cost_above_1hr"),
    ]:
        val = _per_m(entry.get(litellm_field))
        if val > 0:
            result[our_field] = val

    # Reasoning output (may differ from regular output)
    reasoning = _per_m(entry.get("output_cost_per_reasoning_token"))
    if reasoning > 0:
        result["reasoning_output"] = reasoning

    # Above-200k context tier
    for our_field, litellm_field in [
        ("input_above_200k", "input_cost_per_token_above_200k_tokens"),
        ("output_above_200k", "output_cost_per_token_above_200k_tokens"),
        ("cache_read_above_200k", "cache_read_input_token_cost_above_200k_tokens"),
        ("cache_creation_above_200k", "cache_creation_input_token_cost_above_200k_tokens"),
        ("cache_creation_1h_above_200k", "cache_creation_input_token_cost_above_1hr_above_200k_tokens"),
    ]:
        val = _per_m(entry.get(litellm_field))
        if val > 0:
            result[our_field] = val

    return result


def generate(data: dict[str, Any]) -> dict[str, dict[str, dict[str, float]]]:
    """Convert litellm data into our provider→model→pricing structure."""
    result: dict[str, dict[str, dict[str, float]]] = {}

    for litellm_key, entry in data.items():
        if not isinstance(entry, dict):
            continue
        if entry.get("mode") != "chat":
            continue

        litellm_provider = entry.get("litellm_provider", "")
        our_provider = PROVIDER_MAP.get(litellm_provider)
        if our_provider is None:
            continue

        model = _normalize_model(litellm_key)
        pricing = _extract_pricing(entry)

        if not pricing.get("input") and not pricing.get("output"):
            continue  # skip entries without basic pricing

        provider_dict = result.setdefault(our_provider, {})

        # Keep the entry with more fields (richer data wins on duplicates).
        if model in provider_dict and len(provider_dict[model]) >= len(pricing):
            continue
        provider_dict[model] = pricing

    # Sort models within each provider by key for stable output.
    return {p: dict(sorted(models.items())) for p, models in sorted(result.items())}


def _fmt(val: float) -> str:
    return f"{val:g}"


def show_diff(current: dict[str, Any], fresh: dict[str, Any]) -> bool:
    """Print differences between current and fresh generated data. Returns True if any."""
    any_diff = False

    all_providers = sorted(set(list(current.keys()) + list(fresh.keys())))
    for provider in all_providers:
        cur_models = current.get(provider, {})
        new_models = fresh.get(provider, {})
        all_models = sorted(set(list(cur_models.keys()) + list(new_models.keys())))

        provider_diffs: list[str] = []
        for model in all_models:
            cur = cur_models.get(model)
            new = new_models.get(model)
            if cur is None and new is not None:
                provider_diffs.append(f"  + {model} (new)")
            elif cur is not None and new is None:
                provider_diffs.append(f"  - {model} (removed)")
            elif cur != new and cur is not None and new is not None:
                changes = []
                all_fields = sorted(set(list(cur.keys()) + list(new.keys())))
                for field in all_fields:
                    cv = cur.get(field, 0)
                    nv = new.get(field, 0)
                    if cv != nv:
                        changes.append(f"      {field}: ${_fmt(cv)} → ${_fmt(nv)}")
                if changes:
                    provider_diffs.append(f"  ~ {model}:")
                    provider_diffs.extend(changes)

        if provider_diffs:
            any_diff = True
            print(f"\n=== {provider} ===")
            for line in provider_diffs:
                print(line)

    return any_diff


def main() -> None:
    apply = "--apply" in sys.argv
    local_path = None
    if "--local" in sys.argv:
        idx = sys.argv.index("--local")
        if idx + 1 < len(sys.argv):
            local_path = sys.argv[idx + 1]

    if local_path:
        print(f"Loading litellm data from {local_path}...")
    else:
        print("Fetching litellm pricing data...")
    data = fetch_litellm(local_path)
    print(f"Loaded {len(data)} entries from litellm")

    fresh = generate(data)
    total_models = sum(len(m) for m in fresh.values())
    print(f"Generated pricing for {total_models} models across {len(fresh)} providers")

    # Load current generated.json for diff.
    current: dict[str, Any] = {}
    if GENERATED_JSON.exists():
        current = json.loads(GENERATED_JSON.read_text())

    any_diff = show_diff(current, fresh)

    if not any_diff:
        print("\nAll prices match. No changes needed.")
        return

    if not apply:
        print("\nRun with --apply to update generated.json.")
        return

    print("\nWriting generated.json...")
    GENERATED_JSON.write_text(json.dumps(fresh, indent=2) + "\n")
    print(f"  Updated {GENERATED_JSON}")
    print("Done. Run tests to verify: make test name=pricing")


if __name__ == "__main__":
    main()
