"""Tests showing FlowingRegistry keeps external ContextVars in sync.

FlowingRegistry fires on_enter/on_exit callbacks during fork/restore/apply,
so external ContextVar-based systems (MLflow, OpenTelemetry) stay consistent
with the flowing context.
"""

import contextvars

from flowra.agent.flow.flowing_registry import FlowingRegistry, FlowingVar

# Simulates MLflow's internal ContextVar (set_span_in_context / get_current_active_span)
_external_context: contextvars.ContextVar[str | None] = contextvars.ContextVar("external_context", default=None)


def _make_synced_registry() -> tuple[FlowingRegistry, FlowingVar[str | None]]:
    """Create a registry with a var that syncs to _external_context."""
    registry = FlowingRegistry()

    def on_enter(value: str | None) -> contextvars.Token[str | None]:
        return _external_context.set(value)

    def on_exit(token: contextvars.Token[str | None]) -> None:
        _external_context.reset(token)

    var: FlowingVar[str | None] = registry.create_var(default=None, on_enter=on_enter, on_exit=on_exit)
    return registry, var


def test_fork_restore_keeps_external_contextvar_in_sync() -> None:
    """FlowingRegistry restores both flowing var AND external ContextVar correctly.

    This simulates what happens when flowra's MLflow handler does:
    1. Reads _mlflow_parent from FlowingVar
    2. on_enter callback sets the external ContextVar
    3. Engine forks for sibling -> flowing state is forked
    4. Sibling sets a different value in both
    5. Engine restores -> both flowing var and external ContextVar are correct
    """
    registry, flowing_var = _make_synced_registry()

    # Step 1: Parent context sets var (on_enter fires, syncs external)
    flowing_var.set("parent_span")
    assert _external_context.get() == "parent_span"

    # Step 2: Fork for child A
    token = registry.fork()

    # Step 3: Child A sets its own values (on_enter fires, syncs external)
    flowing_var.set("child_a_span")
    assert _external_context.get() == "child_a_span"

    # Step 4: Restore parent context
    registry.restore(token)

    # Step 5: Both are restored correctly
    assert flowing_var.get() == "parent_span", "FlowingVar should restore to parent"
    assert _external_context.get() == "parent_span", "External ContextVar should also restore to parent"


def test_sibling_agents_see_correct_external_context() -> None:
    """Simulates two sibling agents created by Spawn.

    Child A and Child B are siblings. Engine creates them sequentially in the
    same asyncio task. After creating A, engine restores context and creates B.
    B should see parent's external context — and now it does.
    """
    registry, flowing_var = _make_synced_registry()

    # Parent sets up context
    flowing_var.set("parent_span")
    assert _external_context.get() == "parent_span"

    # --- Create Child A ---
    token_a = registry.fork()
    flowing_var.set("span_A")
    assert _external_context.get() == "span_A"
    registry.restore(token_a)

    # After restoring, parent context is back
    assert _external_context.get() == "parent_span"

    # --- Create Child B ---
    token_b = registry.fork()

    # Child B reads both — correct!
    assert flowing_var.get() == "parent_span"
    assert _external_context.get() == "parent_span", "Child B sees parent's external context correctly"

    flowing_var.set("span_B")
    assert _external_context.get() == "span_B"
    registry.restore(token_b)

    assert _external_context.get() == "parent_span"


def test_apply_snapshot_keeps_sync() -> None:
    """apply() (used before ensure_future) also keeps external ContextVar in sync."""
    registry, flowing_var = _make_synced_registry()

    # Set up initial context
    flowing_var.set("original")
    assert _external_context.get() == "original"

    # Save snapshot
    snapshot = registry.snapshot()

    # Modify both
    flowing_var.set("modified")
    assert _external_context.get() == "modified"

    # Apply snapshot (like engine does before ensure_future for child tasks)
    token = registry.apply(snapshot)

    # Both restored
    assert flowing_var.get() == "original"
    assert _external_context.get() == "original", "External ContextVar restored by apply()"

    registry.restore(token)
    assert _external_context.get() == "modified"
