"""Tests that FlowingRegistry callbacks work correctly with Spawn.

Verifies that on_enter/on_exit callbacks on FlowingVar fire correctly when
engine creates Spawn children with span handlers — the real MLflow pattern.
"""

import contextvars
import dataclasses
from typing import Any

from flowra.agent import (
    AgentRuntime,
    AgentSpan,
    CallAgent,
    FlowingRegistry,
    FlowingVar,
    GotoStep,
    HookSubscription,
    Spawn,
    StepSpan,
    WhenAll,
)
from flowra.agent.definition import AgentDefinition, AgentInstance, CallStepHandler, StepMeta
from flowra.agent.services import ServiceLocator

# -- External ContextVar simulating MLflow's set_span_in_context / detach --

_external_span: contextvars.ContextVar[str | None] = contextvars.ContextVar("_ext_span", default=None)


def _on_enter(value: str | None) -> contextvars.Token[str | None]:
    return _external_span.set(value)


def _on_exit(token: contextvars.Token[str | None]) -> None:
    _external_span.reset(token)


# -- Agent infrastructure --


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Result:
    value: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class StepData:
    name: str


def _make_defn(steps: dict[str, StepMeta], handler: CallStepHandler, *, entry_step: str = "start") -> AgentDefinition:
    def create(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
        return AgentInstance(call_step=handler)

    return AgentDefinition(
        steps=steps,
        entry_step=entry_step,
        create_instance=create,
        type_registry={},
    )


# -- Tests --


async def test_spawn_multi_step_children_with_flowing_callbacks() -> None:
    """Spawn + multi-step child agents + span handlers writing FlowingVar.

    Verifies that on_enter/on_exit callbacks work correctly when children
    do GotoStep (engine closes/opens step spans, writing to FlowingVar).
    All callbacks execute in the same task — no cross-context token issues.
    """
    flowing = FlowingRegistry()
    span_var: FlowingVar[str | None] = flowing.create_var(
        default=None,
        on_enter=_on_enter,
        on_exit=_on_exit,
    )

    span_log: list[str] = []

    # Span handlers that write to FlowingVar (like MLflow integration does)
    def on_agent_span(span: AgentSpan) -> Any:
        parent = span_var.get()
        name = f"agent:{span.agent_info.name}"
        span_var.set(name)
        span_log.append(f"agent_enter:{name}(parent={parent})")

        def on_close(error: BaseException | None = None) -> None:
            span_log.append(f"agent_close:{name}")

        return on_close

    def on_step_span(span: StepSpan) -> Any:
        parent = span_var.get()
        name = f"step:{span.agent_info.name}/{span.step}"
        span_var.set(name)
        span_log.append(f"step_enter:{name}(parent={parent})")

        def on_close(error: BaseException | None = None) -> None:
            span_log.append(f"step_close:{name}")

        return on_close

    hooks = HookSubscription()
    hooks.on_span(AgentSpan, on_agent_span)
    hooks.on_span(StepSpan, on_step_span)

    # Parent: spawns two multi-step children
    async def parent_handler(
        tag: str,
        spec: Any = None,
        child_outputs: list[Any] | None = None,
        agent_spec: Any = None,
    ) -> Any:
        if tag == "start":
            return Spawn(
                WhenAll(
                    CallAgent(agent="child", spec="A"),
                    CallAgent(agent="child", spec="B"),
                ),
                then="collect",
            )
        results = [o.result for o in child_outputs] if child_outputs else []
        return Result(value=",".join(r.value for r in results if isinstance(r, Result)))

    # Child: two steps (work → finish) — GotoStep triggers step span switch
    async def child_handler(
        tag: str,
        spec: Any = None,
        child_outputs: list[Any] | None = None,
        agent_spec: Any = None,
    ) -> Any:
        if tag == "work":
            name = spec if isinstance(spec, str) else "?"
            return GotoStep(step="finish", spec=StepData(name=name))
        # finish step
        assert isinstance(spec, StepData)
        return Result(value=spec.name)

    parent_defn = _make_defn({"start": StepMeta(), "collect": StepMeta()}, parent_handler)
    child_defn = _make_defn(
        {"work": StepMeta(), "finish": StepMeta()},
        child_handler,
        entry_step="work",
    )

    runtime = AgentRuntime(
        agents={"parent": parent_defn, "child": child_defn},
        services={FlowingRegistry: flowing, HookSubscription: hooks},
    )

    result = await runtime.run(agent="parent")

    assert isinstance(result, Result)
    values = set(result.value.split(","))
    assert values == {"A", "B"}
