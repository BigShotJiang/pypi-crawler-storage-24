"""Tests for FlowingRegistry — flowing variables with enter/exit callbacks."""

import contextvars

import pytest

from flowra.agent.flow.flowing_registry import FlowingRegistry, FlowingVar


class TestBasicGetSet:
    def test_default_value(self) -> None:
        reg = FlowingRegistry()
        var: FlowingVar[int] = reg.create_var(default=42)
        assert var.get() == 42

    def test_set_and_get(self) -> None:
        reg = FlowingRegistry()
        var: FlowingVar[str | None] = reg.create_var(default=None)
        var.set("hello")
        assert var.get() == "hello"

    def test_no_default_raises(self) -> None:
        reg = FlowingRegistry()
        var = reg.create_var()
        with pytest.raises(LookupError):
            var.get()

    def test_on_exit_without_on_enter_raises(self) -> None:
        reg = FlowingRegistry()
        with pytest.raises(ValueError, match="on_exit requires on_enter"):
            reg.create_var(default=None, on_exit=lambda t: None)

    def test_on_enter_without_default_raises(self) -> None:
        reg = FlowingRegistry()
        with pytest.raises(ValueError, match="on_enter requires an explicit default"):
            reg.create_var(on_enter=lambda v: v)

    def test_multiple_vars_independent(self) -> None:
        reg = FlowingRegistry()
        a: FlowingVar[int] = reg.create_var(default=0)
        b: FlowingVar[str] = reg.create_var(default="x")
        a.set(1)
        b.set("y")
        assert a.get() == 1
        assert b.get() == "y"


class TestForkRestore:
    def test_fork_and_restore(self) -> None:
        reg = FlowingRegistry()
        var: FlowingVar[str] = reg.create_var(default="init")
        var.set("parent")

        token = reg.fork()
        var.set("child")
        assert var.get() == "child"

        reg.restore(token)
        assert var.get() == "parent"

    def test_fork_isolates_siblings(self) -> None:
        reg = FlowingRegistry()
        var: FlowingVar[str] = reg.create_var(default="init")
        var.set("parent")

        # Child A
        token_a = reg.fork()
        var.set("A")
        reg.restore(token_a)

        # Child B — should see parent, not A
        token_b = reg.fork()
        assert var.get() == "parent"
        var.set("B")
        reg.restore(token_b)

        assert var.get() == "parent"


class TestSnapshotApply:
    def test_snapshot_and_apply(self) -> None:
        reg = FlowingRegistry()
        var: FlowingVar[str] = reg.create_var(default="init")
        var.set("original")
        snap = reg.snapshot()

        var.set("modified")
        token = reg.apply(snap)
        assert var.get() == "original"

        reg.restore(token)
        assert var.get() == "modified"


class TestEnterExitCallbacks:
    """Core feature: on_enter/on_exit fire on context switches."""

    def test_set_fires_callbacks(self) -> None:
        log: list[str] = []
        reg = FlowingRegistry()
        var: FlowingVar[str | None] = reg.create_var(
            default=None,
            on_enter=lambda v: (log.append(f"enter:{v}"), f"token:{v}")[1],
            on_exit=lambda t: log.append(f"exit:{t}"),
        )

        var.set("A")
        assert log == ["enter:A"]

        var.set("B")
        assert log == ["enter:A", "exit:token:A", "enter:B"]

    def test_restore_fires_callbacks(self) -> None:
        log: list[str] = []
        reg = FlowingRegistry()
        var: FlowingVar[str | None] = reg.create_var(
            default=None,
            on_enter=lambda v: (log.append(f"enter:{v}"), f"token:{v}")[1],
            on_exit=lambda t: log.append(f"exit:{t}"),
        )

        var.set("parent")
        log.clear()

        token = reg.fork()
        var.set("child")
        assert log == ["exit:token:parent", "enter:child"]

        log.clear()
        reg.restore(token)
        assert log == ["exit:token:child", "enter:parent"]

    def test_apply_fires_callbacks(self) -> None:
        log: list[str] = []
        reg = FlowingRegistry()
        var: FlowingVar[str | None] = reg.create_var(
            default=None,
            on_enter=lambda v: (log.append(f"enter:{v}"), f"token:{v}")[1],
            on_exit=lambda t: log.append(f"exit:{t}"),
        )

        var.set("original")
        snap = reg.snapshot()
        var.set("modified")
        log.clear()

        reg.apply(snap)
        assert log == ["exit:token:modified", "enter:original"]

    def test_fork_does_not_fire_callbacks(self) -> None:
        """Fork copies the dict — value doesn't change, no callbacks."""
        log: list[str] = []
        reg = FlowingRegistry()
        var: FlowingVar[str | None] = reg.create_var(
            default=None,
            on_enter=lambda v: (log.append(f"enter:{v}"), "tok")[1],
            on_exit=lambda t: log.append(f"exit:{t}"),
        )
        var.set("X")
        log.clear()

        token = reg.fork()
        assert log == [], "fork should not fire callbacks"

        reg.restore(token)
        assert log == [], "restore to same value should not fire callbacks"

    def test_no_callback_when_value_unchanged(self) -> None:
        log: list[str] = []
        reg = FlowingRegistry()
        var: FlowingVar[str | None] = reg.create_var(
            default=None,
            on_enter=lambda v: (log.append(f"enter:{v}"), "tok")[1],
            on_exit=lambda t: log.append(f"exit:{t}"),
        )

        var.set("X")
        snap = reg.snapshot()
        # Don't change the value
        log.clear()

        reg.apply(snap)
        assert log == [], "same value should not trigger callbacks"


class TestExternalContextVarSync:
    """The actual use case: syncing FlowingVar with a regular ContextVar."""

    def test_restore_syncs_external_contextvar(self) -> None:
        """This is the bug that FlowingRegistry fixes.

        Without FlowingRegistry: after restore, external ContextVar retains
        the child's value. With FlowingRegistry: external ContextVar is synced.
        """
        external: contextvars.ContextVar[str | None] = contextvars.ContextVar("ext", default=None)

        reg = FlowingRegistry()
        var: FlowingVar[str | None] = reg.create_var(
            default=None,
            on_enter=lambda v: (external.set(v), "tok")[1],
            on_exit=lambda t: (external.set(None), None)[1],
        )

        # Parent sets value
        var.set("parent_span")
        assert external.get() == "parent_span"

        # Fork for child A
        token = reg.fork()
        var.set("child_a_span")
        assert external.get() == "child_a_span"

        # Restore — both FlowingVar and external ContextVar restored
        reg.restore(token)
        assert var.get() == "parent_span"
        assert external.get() == "parent_span"  # THIS is the fix!

    def test_sibling_isolation_with_external_contextvar(self) -> None:
        """Two siblings don't see each other's external context."""
        external: contextvars.ContextVar[str | None] = contextvars.ContextVar("ext2", default=None)

        reg = FlowingRegistry()
        var: FlowingVar[str | None] = reg.create_var(
            default=None,
            on_enter=lambda v: (external.set(v), "tok")[1],
            on_exit=lambda t: (external.set(None), None)[1],
        )

        var.set("parent")
        assert external.get() == "parent"

        # Child A
        token_a = reg.fork()
        var.set("span_A")
        assert external.get() == "span_A"
        reg.restore(token_a)

        # Child B — should see parent, not A
        token_b = reg.fork()
        assert var.get() == "parent"
        assert external.get() == "parent"  # Fixed! Was "span_A" without registry
        var.set("span_B")
        assert external.get() == "span_B"
        reg.restore(token_b)

        assert external.get() == "parent"

    def test_var_without_callbacks_no_side_effects(self) -> None:
        """Variables without callbacks work fine — no overhead."""
        reg = FlowingRegistry()
        plain = reg.create_var(default=0)
        plain.set(42)

        token = reg.fork()
        plain.set(99)
        reg.restore(token)

        assert plain.get() == 42
