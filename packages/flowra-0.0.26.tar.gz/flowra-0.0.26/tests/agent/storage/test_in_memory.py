from flowra.agent.storage import ChangeSet, InMemorySessionSnapshot, InMemorySessionStorage
from tests.agent.storage import TrackingSessionStorage


class TestInMemorySessionStorage:
    async def test_empty_initial_state(self) -> None:
        storage = InMemorySessionStorage()
        assert await storage.has_execution() is False
        assert await storage.load_execution() is None
        assert await storage.load_node_state("x") is None

    async def test_save_and_load_execution(self) -> None:
        storage = InMemorySessionStorage()
        snapshot = {"node_id": "root", "status": "pending_step"}
        async with storage.begin_transaction():
            await storage.save_execution(snapshot)
        assert await storage.has_execution() is True
        assert await storage.load_execution() == snapshot

    async def test_clear_execution(self) -> None:
        storage = InMemorySessionStorage()
        async with storage.begin_transaction():
            await storage.save_execution({"node_id": "root"})
        await storage.clear_execution()
        assert await storage.has_execution() is False
        assert await storage.load_execution() is None

    async def test_save_node_state_scalars(self) -> None:
        storage = InMemorySessionStorage()
        changes = ChangeSet(scalars={"counter": 1}, appends={})
        async with storage.begin_transaction():
            await storage.save_node_state("main", changes)
        state = await storage.load_node_state("main")
        assert state == {"counter": 1}

    async def test_save_node_state_appends(self) -> None:
        storage = InMemorySessionStorage()
        changes = ChangeSet(scalars={}, appends={"log": ["a", "b"]})
        async with storage.begin_transaction():
            await storage.save_node_state("main", changes)
        state = await storage.load_node_state("main")
        assert state == {"log": ["a", "b"]}

    async def test_save_node_state_merges(self) -> None:
        storage = InMemorySessionStorage()
        async with storage.begin_transaction():
            await storage.save_node_state("k", ChangeSet(scalars={"x": 1}, appends={"log": ["a"]}))
        async with storage.begin_transaction():
            await storage.save_node_state("k", ChangeSet(scalars={"x": 2}, appends={"log": ["b"]}))
        state = await storage.load_node_state("k")
        assert state == {"x": 2, "log": ["a", "b"]}

    async def test_load_node_state_returns_copy(self) -> None:
        storage = InMemorySessionStorage()
        async with storage.begin_transaction():
            await storage.save_node_state("k", ChangeSet(scalars={"x": 1}, appends={}))
        state1 = await storage.load_node_state("k")
        state2 = await storage.load_node_state("k")
        assert state1 is not state2


class TestSnapshot:
    async def test_snapshot_empty_storage(self) -> None:
        storage = InMemorySessionStorage()
        snap = storage.snapshot()
        assert snap.execution is None
        assert snap.node_states == {}

    async def test_snapshot_captures_all_data(self) -> None:
        storage = InMemorySessionStorage()
        async with storage.begin_transaction():
            await storage.save_execution({"node_id": "root"})
            await storage.save_node_state("k", ChangeSet(scalars={"x": 1}, appends={"log": ["a"]}))
        snap = storage.snapshot()
        assert snap.execution == {"node_id": "root"}
        assert snap.node_states == {"k": {"x": 1, "log": ["a"]}}

    async def test_snapshot_is_deep_copy(self) -> None:
        storage = InMemorySessionStorage()
        async with storage.begin_transaction():
            await storage.save_execution({"items": [1, 2]})
            await storage.save_node_state("k", ChangeSet(scalars={"nested": {"a": 1}}, appends={}))
        snap = storage.snapshot()
        # Mutate original storage
        async with storage.begin_transaction():
            await storage.save_execution({"items": [99]})
            await storage.save_node_state("k", ChangeSet(scalars={"nested": {"a": 99}}, appends={}))
        # Snapshot should be unaffected
        assert snap.execution == {"items": [1, 2]}
        assert snap.node_states["k"]["nested"] == {"a": 1}

    async def test_construct_from_snapshot(self) -> None:
        snap = InMemorySessionSnapshot(
            execution={"node_id": "root"},
            node_states={"k": {"x": 1, "log": ["a", "b"]}},
        )
        storage = InMemorySessionStorage(snap)
        assert await storage.has_execution() is True
        assert await storage.load_execution() == {"node_id": "root"}
        assert await storage.load_node_state("k") == {"x": 1, "log": ["a", "b"]}

    async def test_construct_from_snapshot_is_deep_copy(self) -> None:
        original_data: dict[str, list[int]] = {"items": [1, 2]}
        snap = InMemorySessionSnapshot(
            execution=original_data,
            node_states={"k": {"nested": [3, 4]}},
        )
        storage = InMemorySessionStorage(snap)
        # Mutate snapshot source data
        original_data["items"].append(99)
        # Storage should be unaffected
        assert await storage.load_execution() == {"items": [1, 2]}

    async def test_clone_via_snapshot(self) -> None:
        storage1 = InMemorySessionStorage()
        async with storage1.begin_transaction():
            await storage1.save_execution({"node_id": "root"})
            await storage1.save_node_state("k", ChangeSet(scalars={"x": 1}, appends={"log": ["a"]}))
        # Clone
        storage2 = InMemorySessionStorage(storage1.snapshot())
        # Verify clone has same data
        assert await storage2.load_execution() == {"node_id": "root"}
        assert await storage2.load_node_state("k") == {"x": 1, "log": ["a"]}
        # Mutate original — clone is independent
        async with storage1.begin_transaction():
            await storage1.save_node_state("k", ChangeSet(scalars={"x": 99}, appends={}))
        state = await storage2.load_node_state("k")
        assert state is not None
        assert state["x"] == 1


class TestTrackingSessionStorage:
    async def test_tracks_calls(self) -> None:
        storage = TrackingSessionStorage()
        async with storage.begin_transaction():
            await storage.save_execution({"a": 1})
            await storage.save_node_state("k", ChangeSet(scalars={"x": 1}, appends={}))
        assert len(storage.save_execution_calls) == 1
        assert len(storage.save_node_state_calls) == 1
        assert storage.transaction_count == 1
