import json
from pathlib import Path

import pytest

from flowra.llm.pricing.registry import ModelPricing, PricingRegistry


def _registry(*providers: tuple[str, dict[str, ModelPricing]]) -> PricingRegistry:
    """Build a registry from (provider, {model: pricing}) pairs."""
    r = PricingRegistry()
    for provider, models in providers:
        for model, pricing in models.items():
            r.register(provider, model, pricing)
    return r


_ANTHROPIC = ModelPricing(
    input=3.0,
    output=15.0,
    cache_read=0.3,
    cache_creation=3.75,
    cache_creation_1h=6.0,
)

_OPENAI = ModelPricing(input=2.5, output=10.0, cache_read=1.25)

_GOOGLE = ModelPricing(input=1.25, output=10.0, cache_read=0.125)


class TestBasicCost:
    def test_anthropic_model(self) -> None:
        reg = _registry(("anthropic", {"claude-sonnet-4-5": _ANTHROPIC}))
        cost = reg.estimate_cost(
            "claude-sonnet-4-5",
            provider="anthropic",
            input_tokens=1_000_000,
            output_tokens=1_000_000,
        )
        assert cost is not None
        assert cost.input == pytest.approx(3.0)
        assert cost.output == pytest.approx(15.0)
        assert cost.total == pytest.approx(18.0)

    def test_openai_model(self) -> None:
        reg = _registry(("openai", {"gpt-4o": _OPENAI}))
        cost = reg.estimate_cost(
            "gpt-4o",
            provider="openai",
            input_tokens=1_000_000,
            output_tokens=1_000_000,
        )
        assert cost is not None
        assert cost.input == pytest.approx(2.5)
        assert cost.output == pytest.approx(10.0)

    def test_google_model(self) -> None:
        reg = _registry(("google", {"gemini-2.5-pro": _GOOGLE}))
        cost = reg.estimate_cost(
            "gemini-2.5-pro",
            provider="google",
            input_tokens=1_000_000,
            output_tokens=1_000_000,
        )
        assert cost is not None
        assert cost.input == pytest.approx(1.25)
        assert cost.output == pytest.approx(10.0)


class TestUnknownModel:
    def test_unknown_model_returns_none(self) -> None:
        reg = _registry(("openai", {"gpt-4o": _OPENAI}))
        assert (
            reg.estimate_cost(
                "unknown-model",
                provider="openai",
                input_tokens=100,
                output_tokens=100,
            )
            is None
        )

    def test_unknown_provider_returns_none(self) -> None:
        reg = _registry(("openai", {"gpt-4o": _OPENAI}))
        assert (
            reg.estimate_cost(
                "gpt-4o",
                provider="bedrock",
                input_tokens=100,
                output_tokens=100,
            )
            is None
        )


class TestSubstringMatch:
    def test_match_with_suffix(self) -> None:
        reg = _registry(("anthropic", {"claude-opus-4-6": ModelPricing(input=5.0, output=25.0)}))
        cost = reg.estimate_cost(
            "some-prefix-claude-opus-4-6-suffix",
            provider="anthropic",
            input_tokens=1_000_000,
            output_tokens=0,
        )
        assert cost is not None
        assert cost.input == pytest.approx(5.0)

    def test_longest_match_wins(self) -> None:
        reg = _registry(
            (
                "openai",
                {
                    "gpt-4o": ModelPricing(input=2.5, output=10.0),
                    "gpt-4o-mini": ModelPricing(input=0.15, output=0.6),
                },
            )
        )
        cost = reg.estimate_cost(
            "gpt-4o-mini",
            provider="openai",
            input_tokens=1_000_000,
            output_tokens=1_000_000,
        )
        assert cost is not None
        assert cost.input == pytest.approx(0.15)
        assert cost.output == pytest.approx(0.6)


class TestZeroTokens:
    def test_all_zeros(self) -> None:
        reg = _registry(("anthropic", {"claude-sonnet-4-5": _ANTHROPIC}))
        cost = reg.estimate_cost(
            "claude-sonnet-4-5",
            provider="anthropic",
            input_tokens=0,
            output_tokens=0,
        )
        assert cost is not None
        assert cost.total == pytest.approx(0.0)


class TestCacheCreation:
    def test_5m_and_1h(self) -> None:
        reg = _registry(("anthropic", {"claude-sonnet-4-5": _ANTHROPIC}))
        cost = reg.estimate_cost(
            "claude-sonnet-4-5",
            provider="anthropic",
            input_tokens=0,
            output_tokens=0,
            cache_read_tokens=1_000_000,
            cache_creation_tokens=1_000_000,
            cache_creation_1h_tokens=1_000_000,
        )
        assert cost is not None
        assert cost.cache_read == pytest.approx(0.3)
        assert cost.cache_creation == pytest.approx(3.75 + 6.0)
        assert cost.total == pytest.approx(0.3 + 3.75 + 6.0)


class TestAbove200k:
    _TIERED = ModelPricing(
        input=3.0,
        output=15.0,
        cache_read=0.3,
        cache_creation=3.75,
        cache_creation_1h=6.0,
        input_above_200k=6.0,
        output_above_200k=22.5,
        cache_read_above_200k=0.6,
        cache_creation_above_200k=7.5,
    )

    def test_below_threshold_uses_base_rates(self) -> None:
        reg = _registry(("anthropic", {"claude-sonnet-4-6": self._TIERED}))
        cost = reg.estimate_cost(
            "claude-sonnet-4-6",
            provider="anthropic",
            input_tokens=150_000,
            output_tokens=50_000,
            cache_read_tokens=50_000,
        )
        assert cost is not None
        # Total input side = 200k, exactly at threshold — base rates.
        assert cost.input == pytest.approx(150_000 * 3.0 / 1e6)
        assert cost.output == pytest.approx(50_000 * 15.0 / 1e6)
        assert cost.cache_read == pytest.approx(50_000 * 0.3 / 1e6)

    def test_above_threshold_proportional_split(self) -> None:
        reg = _registry(("anthropic", {"claude-sonnet-4-6": self._TIERED}))
        # 300k total input: 200k input + 100k cache_read
        cost = reg.estimate_cost(
            "claude-sonnet-4-6",
            provider="anthropic",
            input_tokens=200_000,
            output_tokens=100_000,
            cache_read_tokens=100_000,
        )
        assert cost is not None
        # total_input_side = 300k
        # below_ratio = 200k/300k = 2/3, above_ratio = 1/3
        below = 2 / 3
        above = 1 / 3
        expected_input = 200_000 * (below * 3.0 + above * 6.0) / 1e6
        expected_output = 100_000 * (below * 15.0 + above * 22.5) / 1e6
        expected_cache_read = 100_000 * (below * 0.3 + above * 0.6) / 1e6
        assert cost.input == pytest.approx(expected_input)
        assert cost.output == pytest.approx(expected_output)
        assert cost.cache_read == pytest.approx(expected_cache_read)

    def test_no_tier_defined_uses_base(self) -> None:
        """Model without above_200k rates uses base for all tokens."""
        no_tier = ModelPricing(input=3.0, output=15.0, cache_read=0.3)
        reg = _registry(("anthropic", {"claude-sonnet-3-7": no_tier}))
        cost = reg.estimate_cost(
            "claude-sonnet-3-7",
            provider="anthropic",
            input_tokens=300_000,
            output_tokens=100_000,
        )
        assert cost is not None
        assert cost.input == pytest.approx(300_000 * 3.0 / 1e6)
        assert cost.output == pytest.approx(100_000 * 15.0 / 1e6)

    def test_cache_creation_above_200k(self) -> None:
        reg = _registry(("anthropic", {"claude-sonnet-4-6": self._TIERED}))
        # 300k total: 100k input + 100k cache_read + 100k cache_creation
        cost = reg.estimate_cost(
            "claude-sonnet-4-6",
            provider="anthropic",
            input_tokens=100_000,
            output_tokens=0,
            cache_read_tokens=100_000,
            cache_creation_tokens=100_000,
        )
        assert cost is not None
        below = 2 / 3
        above = 1 / 3
        expected_creation = 100_000 * (below * 3.75 + above * 7.5) / 1e6
        assert cost.cache_creation == pytest.approx(expected_creation)


class TestReasoningTokens:
    def test_with_reasoning_output_rate(self) -> None:
        pricing = ModelPricing(input=0.3, output=2.5, reasoning_output=2.5)
        reg = _registry(("google", {"gemini-2.5-flash": pricing}))
        cost = reg.estimate_cost(
            "gemini-2.5-flash",
            provider="google",
            input_tokens=100_000,
            output_tokens=50_000,
            reasoning_tokens=30_000,
        )
        assert cost is not None
        expected_output = 50_000 * 2.5 / 1e6 + 30_000 * 2.5 / 1e6
        assert cost.output == pytest.approx(expected_output)

    def test_reasoning_zero_rate_ignored(self) -> None:
        """When reasoning_output=0, reasoning_tokens don't add extra cost."""
        pricing = ModelPricing(input=2.0, output=8.0)
        reg = _registry(("openai", {"o3": pricing}))
        cost = reg.estimate_cost(
            "o3",
            provider="openai",
            input_tokens=100_000,
            output_tokens=50_000,
            reasoning_tokens=30_000,
        )
        assert cost is not None
        # reasoning_output=0, so reasoning_tokens contribute nothing extra
        assert cost.output == pytest.approx(50_000 * 8.0 / 1e6)


class TestJsonLoading:
    def test_load_and_override(self, tmp_path: Path) -> None:
        generated = {"openai": {"gpt-4o": {"input": 2.5, "output": 10.0, "cache_read": 1.25}}}
        custom = {"openai": {"gpt-4o": {"input": 3.0, "output": 12.0, "cache_read": 1.5}}}
        (tmp_path / "generated.json").write_text(json.dumps(generated))
        (tmp_path / "custom.json").write_text(json.dumps(custom))

        import flowra.llm.pricing.registry as reg_mod

        orig = reg_mod.DATA_DIR
        try:
            reg_mod.DATA_DIR = tmp_path
            registry = PricingRegistry.load_default()
        finally:
            reg_mod.DATA_DIR = orig

        cost = registry.estimate_cost(
            "gpt-4o",
            provider="openai",
            input_tokens=1_000_000,
            output_tokens=1_000_000,
        )
        assert cost is not None
        # Custom prices win.
        assert cost.input == pytest.approx(3.0)
        assert cost.output == pytest.approx(12.0)


class TestRuntimeRegister:
    def test_register_new_model(self) -> None:
        reg = PricingRegistry()
        reg.register("openai", "new-model", ModelPricing(input=1.0, output=5.0))
        cost = reg.estimate_cost(
            "new-model",
            provider="openai",
            input_tokens=1_000_000,
            output_tokens=1_000_000,
        )
        assert cost is not None
        assert cost.input == pytest.approx(1.0)

    def test_register_overrides(self) -> None:
        reg = _registry(("openai", {"gpt-4o": _OPENAI}))
        reg.register("openai", "gpt-4o", ModelPricing(input=99.0, output=99.0))
        cost = reg.estimate_cost(
            "gpt-4o",
            provider="openai",
            input_tokens=1_000_000,
            output_tokens=1_000_000,
        )
        assert cost is not None
        assert cost.input == pytest.approx(99.0)


class TestProviderIsolation:
    def test_same_model_different_providers(self) -> None:
        reg = _registry(
            ("anthropic", {"claude-sonnet-4-6": ModelPricing(input=3.0, output=15.0)}),
            ("bedrock/us", {"claude-sonnet-4-6": ModelPricing(input=3.3, output=16.5)}),
        )
        cost_direct = reg.estimate_cost(
            "claude-sonnet-4-6",
            provider="anthropic",
            input_tokens=1_000_000,
            output_tokens=0,
        )
        cost_bedrock = reg.estimate_cost(
            "claude-sonnet-4-6",
            provider="bedrock/us",
            input_tokens=1_000_000,
            output_tokens=0,
        )
        assert cost_direct is not None
        assert cost_bedrock is not None
        assert cost_direct.input == pytest.approx(3.0)
        assert cost_bedrock.input == pytest.approx(3.3)


class TestDefaultRegistrySmoke:
    """Smoke test: loading the actual bundled JSON files."""

    def test_loads_and_resolves_known_models(self) -> None:
        reg = PricingRegistry.load_default()
        assert (
            reg.estimate_cost(
                "claude-sonnet-4-6",
                provider="anthropic",
                input_tokens=1000,
                output_tokens=1000,
            )
            is not None
        )
        assert (
            reg.estimate_cost(
                "gpt-4o",
                provider="openai",
                input_tokens=1000,
                output_tokens=1000,
            )
            is not None
        )
        assert (
            reg.estimate_cost(
                "gemini-2.5-pro",
                provider="google",
                input_tokens=1000,
                output_tokens=1000,
            )
            is not None
        )
