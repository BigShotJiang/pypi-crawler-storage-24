"""Span-hooks crash + resume demo.

Usage:
    # First run — crashes during tool execution:
    uv run python examples/span_crash_demo.py

    # Second run — resumes from where it crashed:
    uv run python examples/span_crash_demo.py --resume
"""

import argparse
import asyncio
import pathlib
from typing import Any

from examples.app_agent import AppAgent, AppConfig
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate
from flowra.agent import AgentRuntime, AgentSpan, FileSessionStorage, StepSpan
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.lib.observability import LLMCallSpan, ToolCallSpan
from flowra.lib.tool_loop import AfterToolCallEvent
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry, get_local_tool

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()
_SESSION_DIR = ".span_crash_sessions"
_SESSION_ID = "crash-demo"

_INDENT = [0]
_CRASHED = [False]


def _log(prefix: str, name: str, detail: str = "") -> None:
    indent = "  " * _INDENT[0]
    suffix = f"  {detail}" if detail else ""
    print(f"{indent}{prefix} {name}{suffix}")


def _short(obj: Any, max_len: int = 60) -> str:
    s = str(obj)
    return s[:max_len] + "..." if len(s) > max_len else s


def _on_agent_span(span: AgentSpan) -> Any:
    _log("▶", f"agent:{span.agent_info.path}")
    _INDENT[0] += 1

    def on_end(error: BaseException | None = None) -> None:
        _INDENT[0] -= 1
        if error:
            _log("✘", f"agent:{span.agent_info.path}", f"ERROR: {error}")
        else:
            _log("◀", f"agent:{span.agent_info.path}", f"result={_short(span.result)}")

    return on_end


def _on_step_span(span: StepSpan) -> Any:
    _log("→", f"step:{span.step}")
    _INDENT[0] += 1

    def on_end(error: BaseException | None = None) -> None:
        _INDENT[0] -= 1
        if error:
            _log("✘", f"step:{span.step}", f"ERROR: {error}")
        else:
            _log("←", f"step:{span.step}")

    return on_end


def _on_llm_span(span: LLMCallSpan) -> Any:
    model = span.request.model.split("/")[-1]
    _log("🤖", f"llm_call ({model})")

    def on_end(error: BaseException | None = None) -> None:
        if span.response and span.response.usage:
            u = span.response.usage
            _log("  ", f"→ {span.response.stop_reason}  {u.input_tokens}in/{u.output_tokens}out")

    return on_end


def _on_tool_span(span: ToolCallSpan) -> Any:
    _log("🔧", f"tool:{span.tool_use.name}", f"input={_short(span.tool_use.input)}")

    def on_end(error: BaseException | None = None) -> None:
        if error:
            _log("  ", f"→ ERROR: {error}")
        elif span.result:
            _log("  ", f"→ {span.result.content[:80]}")

    return on_end


async def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()

    router = create_router()

    async with await ToolRegistry.create([get_local_tool(calculate)]) as registry:
        app_config = AppConfig(
            default_model=DEFAULT_MODEL,
            system=lambda: [
                SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)]),
            ],
        )

        storage = FileSessionStorage(base_dir=_SESSION_DIR, session_id=_SESSION_ID)
        runtime = AgentRuntime(
            agents={"app": AppAgent},
            storage=storage,
            services={
                ToolRegistry: registry,
                AppConfig: app_config,
                LLMProvider: router,
            },
        )
        runtime.hooks.on_span(AgentSpan, _on_agent_span)
        runtime.hooks.on_span(StepSpan, _on_step_span)
        runtime.hooks.on_span(LLMCallSpan, _on_llm_span)
        runtime.hooks.on_span(ToolCallSpan, _on_tool_span)

        if not args.resume:
            # Crash after tool returns result
            def crash_after_tool(_: Any) -> None:
                if not _CRASHED[0]:
                    _CRASHED[0] = True
                    print("\n  💥 SIMULATED CRASH!\n")
                    raise RuntimeError("Simulated crash after tool call")

            runtime.hooks.on(AfterToolCallEvent, crash_after_tool)

        if args.resume:
            print("=== RESUMING ===\n")
            result = await runtime.resume()
        else:
            print("=== FRESH RUN (will crash after first tool call) ===\n")
            try:
                result = await runtime.run(
                    agent=AppAgent,
                    spec=ChatSpec(user_message="What is 2+2? Use the calculator tool."),
                )
            except RuntimeError as e:
                print(f"\n{'=' * 60}")
                print(f"Crashed: {e}")
                print("Run with --resume to continue")
                return

        if isinstance(result, ChatResult):
            print(f"\n{'=' * 60}")
            print(f"Answer: {result.response}")


if __name__ == "__main__":
    asyncio.run(main())
