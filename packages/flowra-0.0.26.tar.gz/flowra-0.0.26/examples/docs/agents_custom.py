"""Agents: Custom agent with persistent state.

Corresponds to docs/agents.md "Persistent state" and "Crash recovery" sections.

Usage:
    make docs-example name=agents_custom
"""

import asyncio
from dataclasses import dataclass

from flowra.agent import Agent, AgentRuntime, AgentStore, FileSessionStorage, Scalar, step


@dataclass
class CounterSpec:
    increment: int = 1


@dataclass
class CounterResult:
    total: int


class CounterAgent(Agent[CounterSpec, CounterResult]):
    def __init__(self, store: AgentStore) -> None:
        self.count = store.slot(Scalar[int], "count")

    @step(entry=True)
    async def increment(self, spec: CounterSpec) -> CounterResult:
        current = self.count.get(0)
        self.count.set(current + spec.increment)
        return CounterResult(total=current + spec.increment)


async def main() -> None:
    storage = FileSessionStorage(base_dir=".docs_example_sessions", session_id="counter")
    runtime = AgentRuntime(
        agents={"counter": CounterAgent},
        storage=storage,
    )

    # Run three times — state persists between runs
    for i in range(3):
        result = await runtime.run(agent=CounterAgent, spec=CounterSpec(increment=1))
        print(f"Run {i + 1}: total = {result.total}")

    print("\nState is persisted in .docs_example_sessions/counter/")


if __name__ == "__main__":
    asyncio.run(main())
