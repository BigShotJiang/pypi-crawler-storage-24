"""Getting Started: A simple chatbot.

Corresponds to docs/getting-started.md "A simple chatbot" section.

Usage:
    uv run python examples/docs/getting_started_chat.py
"""

import asyncio

from examples.model_registry import DEFAULT_MODEL, create_router
from flowra.agent import AgentRuntime
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry


async def main() -> None:
    router = create_router()

    async with await ToolRegistry.create([]) as registry:
        config = ChatConfig(
            llm_config=LLMConfig(model=DEFAULT_MODEL),
            system=[SystemMessage(blocks=[TextBlock(text="You are a helpful assistant.")])],
        )

        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                LLMProvider: router,
                ToolRegistry: registry,
                ChatConfig: config,
            },
        )

        while True:
            user_input = input("You: ")
            if not user_input:
                break

            result = await runtime.run(agent=ChatAgent, spec=ChatSpec(user_message=user_input))

            if isinstance(result, ChatResult) and result.response:
                print(f"Assistant: {result.response}")


if __name__ == "__main__":
    asyncio.run(main())
