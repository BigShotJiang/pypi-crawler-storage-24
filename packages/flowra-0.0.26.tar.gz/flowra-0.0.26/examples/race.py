"""Race example — two LLMs answer the same question, first response wins.

Demonstrates WhenAny spawn strategy: two researcher agents run in parallel
on different models with live streaming. The first to respond wins; the second
is interrupted. ExecutionContext identifies which model is streaming — the handler
walks the execution stack to find the ResearchSpec with the model name.

Usage:
    uv run python examples/race.py
    uv run python examples/race.py --question "What is the Riemann hypothesis?"
    uv run python examples/race.py --model1 anthropic/haiku-4-5 --model2 google/gemini-2.5-flash
    uv run python examples/race.py --timeout 10
"""

import argparse
import asyncio
import dataclasses
import sys
import time
from typing import Annotated, ClassVar

from examples.llm_logging import setup_file_logging
from examples.model_registry import create_router
from flowra.agent import (
    Agent,
    AgentDefinitionRef,
    AgentRuntime,
    CallAgent,
    Event,
    Interrupted,
    ServiceLocator,
    Spawn,
    TimeoutExpired,
    WhenAny,
    step,
    step_arg,
    timeout,
)
from flowra.agent.flow import StepAction
from flowra.lib import LLMCallAgent, LLMConfig
from flowra.lib.llm_call import LLMCallResult, LLMCallSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock, UserMessage

setup_file_logging("race")

# -- Hook events --------------------------------------------------------------


@dataclasses.dataclass(slots=True, kw_only=True)
class ResearchDeltaEvent:
    """Emitted for each streamed text chunk from a researcher."""

    text: str


@dataclasses.dataclass(slots=True, kw_only=True)
class ResearchDoneEvent:
    """Emitted when a researcher finishes."""

    elapsed: float


# -- Display ------------------------------------------------------------------

_RESET = "\033[0m"
_DIM = "\033[2m"
_BOLD = "\033[1m"
_PALETTE = ["\033[32m", "\033[34m", "\033[33m"]  # green, blue, yellow
_COLORS: dict[str, str] = {}


def _assign_color(model: str) -> str:
    if model not in _COLORS:
        _COLORS[model] = _PALETTE[len(_COLORS) % len(_PALETTE)]
    return _COLORS[model]


def _short(model: str) -> str:
    return model.rsplit("/", 1)[-1]


_display_lock = asyncio.Lock()


async def _on_delta(event: Event[ResearchDeltaEvent]) -> None:
    spec = event.context.get_spec(ResearchSpec)
    model = spec.model
    color = _assign_color(model)
    label = _short(model)
    async with _display_lock:
        sys.stdout.write(f"  {color}{_DIM}[{label}]{_RESET} {color}{event.data.text}{_RESET}\n")
        sys.stdout.flush()


async def _on_done(event: Event[ResearchDoneEvent]) -> None:
    spec = event.context.get_spec(ResearchSpec)
    model = spec.model
    color = _assign_color(model)
    label = _short(model)
    async with _display_lock:
        sys.stdout.write(f"  {color}{_BOLD}[{label}] done ({event.data.elapsed:.1f}s){_RESET}\n")
        sys.stdout.flush()


# -- Specs & Results ----------------------------------------------------------

RESEARCHER_PROMPT = "Follow the user's instructions carefully. Write exactly what they ask for."


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ResearchSpec:
    question: str
    model: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ResearchResult:
    answer: str
    model: str
    elapsed: float


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class RaceSpec:
    question: str
    model1: str
    model2: str
    timeout_seconds: float | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class RaceResult:
    winner: str
    answer: str
    elapsed: float
    timed_out: bool = False


# -- Researcher agent ---------------------------------------------------------


class Researcher(Agent[ResearchSpec, ResearchResult]):
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
        "llm": LLMCallAgent,
    }

    __slots__ = ("__spec",)

    def __init__(self, spec: ResearchSpec, sl: ServiceLocator) -> None:
        self.__spec = spec
        sl.provide(LLMConfig(model=spec.model))

    @step(entry=True)
    async def research(self) -> StepAction:
        return Spawn(
            CallAgent(
                agent=LLMCallAgent,
                spec=LLMCallSpec(
                    system=[SystemMessage(blocks=[TextBlock(text=RESEARCHER_PROMPT)])],
                    messages=[UserMessage(blocks=[TextBlock(text=self.__spec.question)])],
                ),
            ),
            then=self.process_response,
        )

    @step
    def process_response(self, response: LLMCallResult) -> ResearchResult:
        text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
        return ResearchResult(answer=text, model=self.__spec.model, elapsed=response.elapsed)


# -- Race coordinator --------------------------------------------------------


class RaceCoordinator(Agent[RaceSpec, RaceResult]):
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
        "researcher": Researcher,
    }

    @step(entry=True)
    async def start(self, spec: RaceSpec) -> Spawn:
        nodes: list[CallAgent] = [
            CallAgent(agent=Researcher, spec=ResearchSpec(question=spec.question, model=spec.model1), tag="r1"),
            CallAgent(agent=Researcher, spec=ResearchSpec(question=spec.question, model=spec.model2), tag="r2"),
        ]
        if spec.timeout_seconds is not None:
            nodes.append(timeout(seconds=spec.timeout_seconds))
        return Spawn(WhenAny(*nodes), then=self.finish)

    @step
    async def finish(
        self,
        r1: Annotated[ResearchResult | None, step_arg.CHILD("r1")],
        r2: Annotated[ResearchResult | None, step_arg.CHILD("r2")],
        expired: TimeoutExpired | None,
    ) -> RaceResult:
        winner = r1 or r2
        if winner is not None:
            return RaceResult(winner=winner.model, answer=winner.answer, elapsed=winner.elapsed)
        assert expired is not None
        return RaceResult(
            winner="(none)",
            answer=f"Both models timed out after {expired.seconds:.0f}s",
            elapsed=expired.seconds,
            timed_out=True,
        )


# -- Main ---------------------------------------------------------------------

DEFAULT_MODEL1 = "anthropic/sonnet-4-5"
DEFAULT_MODEL2 = "google/gemini-2.5-flash"
DEFAULT_QUESTION = "Why is the sky blue? Explain for a 10-year-old."


async def main(question: str, model1: str, model2: str, timeout_seconds: float | None) -> None:
    router = create_router()
    _assign_color(model1)
    _assign_color(model2)

    runtime = AgentRuntime(
        agents={"race": RaceCoordinator},
        services={LLMProvider: router},
    )
    runtime.hooks.on(ResearchDeltaEvent, _on_delta)
    runtime.hooks.on(ResearchDoneEvent, _on_done)

    spec = RaceSpec(question=question, model1=model1, model2=model2, timeout_seconds=timeout_seconds)

    c1, c2 = _COLORS[model1], _COLORS[model2]
    print(f"\n{_BOLD}Question:{_RESET} {question}")
    print(f"{_BOLD}Racing:{_RESET} {c1}{_BOLD}{_short(model1)}{_RESET} vs {c2}{_BOLD}{_short(model2)}{_RESET}", end="")
    if timeout_seconds is not None:
        print(f" (timeout: {timeout_seconds}s)", end="")
    print("\n")

    t0 = time.monotonic()
    result = await runtime.run(agent=RaceCoordinator, spec=spec)
    total = time.monotonic() - t0

    print()
    if isinstance(result, Interrupted):
        print("Race was interrupted.")
        return

    assert isinstance(result, RaceResult)
    if result.timed_out:
        print(f"{_BOLD}Timed out!{_RESET} Neither model responded in {result.elapsed:.1f}s")
    else:
        winner_color = _COLORS.get(result.winner, "")
        print(f"{_BOLD}Winner: {winner_color}{result.winner}{_RESET} ({result.elapsed:.1f}s)")
    print(f"Total: {total:.1f}s")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Race two LLMs on the same question")
    parser.add_argument("--question", default=DEFAULT_QUESTION)
    parser.add_argument("--model1", default=DEFAULT_MODEL1)
    parser.add_argument("--model2", default=DEFAULT_MODEL2)
    parser.add_argument("--timeout", type=float, default=None, dest="timeout_seconds")
    args = parser.parse_args()

    asyncio.run(
        main(question=args.question, model1=args.model1, model2=args.model2, timeout_seconds=args.timeout_seconds)
    )
