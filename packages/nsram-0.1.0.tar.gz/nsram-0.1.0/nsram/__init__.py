"""nsram — Neuro-Synaptic RAM Simulator

First open-source Python library for NS-RAM floating-body transistor
neuron simulation with charge-trapping synaptic plasticity.

Based on: Pazos et al., "Synaptic and neural behaviours in a standard
silicon transistor", Nature 640, 69-76 (2025).

Quick start:
    >>> from nsram import NSRAMReservoir, rc_benchmark
    >>> res = NSRAMReservoir(128, stp='heterogeneous')
    >>> results = rc_benchmark(res)

Three fidelity levels:
    Level 1: NSRAMNeuron — single cell, full physics ODE (scipy)
    Level 2: NSRAMNetwork — vectorized, compact model (numpy/torch)
    Level 3: NSRAMReservoir — high-level RC API with benchmarks

Backends: NumPy (CPU), PyTorch (NVIDIA CUDA / AMD ROCm / Apple MPS)
"""

__version__ = "0.1.0"

from nsram.neuron import NSRAMNeuron
from nsram.network import NSRAMNetwork
from nsram.reservoir import NSRAMReservoir
from nsram.benchmarks import rc_benchmark
from nsram.physics import (
    DeviceParams, DimensionlessParams, PRESETS,
    breakdown_voltage, avalanche_current,
    charge_capture_rate, srh_trapping_ode,
    vcb_self_oscillation, thermal_voltage,
)
