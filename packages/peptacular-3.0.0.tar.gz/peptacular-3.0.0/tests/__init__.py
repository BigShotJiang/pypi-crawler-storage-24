"""Tests for peptacular package"""
