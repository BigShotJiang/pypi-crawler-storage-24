# KiwisIoT 

Official Python SDK for **Kiwistron IoT Platform**

Supports:
- Raspberry Pi 
- Linux systems
- Python IDLE
- MQTT-based real-time communication

---

##  Features

- Auto MQTT reconnect
- JSON communication
- Callback-based receive
- Lightweight & fast
- Works with ESP32 / ESP8266 devices

---

## Installation

```bash
pip install kiwisiot