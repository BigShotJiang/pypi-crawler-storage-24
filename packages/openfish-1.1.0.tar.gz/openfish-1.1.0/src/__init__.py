"""OpenFish assistant package."""
