# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["PlayerPausePlaybackParams"]


class PlayerPausePlaybackParams(TypedDict, total=False):
    device_id: str
    """The id of the device this command is targeting.

    If not supplied, the user's currently active device is the target.
    """
