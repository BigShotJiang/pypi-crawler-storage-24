"""Tests for server routes with InternalApiRunStore.

Verifies the full run lifecycle (POST /runs -> poll GET /runs/{id} -> success)
works when the store is backed by HTTP calls to the Rails Internal API,
with all Rails responses mocked via httpx_mock.
"""

from __future__ import annotations

import time
from typing import Any

import pytest
from fastapi.testclient import TestClient
from pydantic import Field

from airops import ToolOutputs
from airops.inputs import ShortText, ToolInputs
from airops.server.app import create_app
from airops.server.store import InternalApiRunStore


class EchoInputs(ToolInputs):
    message: ShortText = Field(..., description="Message to echo")


class EchoOutputs(ToolOutputs):
    echo: str


def _build_app(store: InternalApiRunStore) -> TestClient:
    async def handler(inputs: EchoInputs) -> EchoOutputs:
        return EchoOutputs(echo=inputs.message)

    app = create_app(
        tool_name="echo_tool",
        tool_description="Echo",
        handler=handler,
        input_model=EchoInputs,
        output_model=EchoOutputs,
        store=store,
        ui=False,
    )
    return TestClient(app)


def _mock_rails_run_store(httpx_mock: Any, base_url: str) -> dict[str, dict]:
    """Mock all Rails Internal API run store endpoints.

    Maintains an in-memory dict keyed by run_id to simulate the Rails+Redis
    backend, so the test exercises the real SDK code path end-to-end.
    """
    import json
    from datetime import UTC, datetime

    import httpx

    runs: dict[str, dict] = {}

    def handle_request(request: httpx.Request) -> httpx.Response:
        path = request.url.path

        # POST /internal_api/tools/runs (create)
        if path == "/internal_api/tools/runs" and request.method == "POST":
            body = json.loads(request.content)
            now = datetime.now(UTC).isoformat()
            run = {
                "run_id": body["run_id"],
                "status": "queued",
                "created_at": now,
                "updated_at": now,
                "inputs": body["inputs"],
                "outputs": None,
                "error": None,
            }
            runs[body["run_id"]] = run
            return httpx.Response(201, json=run)

        # GET /internal_api/tools/runs/{run_id} (show)
        if request.method == "GET" and "/internal_api/tools/runs/" in path:
            run_id = path.rsplit("/", 1)[-1]
            run = runs.get(run_id)
            if run is None:
                return httpx.Response(404, json={"error": "Not found"})
            return httpx.Response(200, json=run)

        # POST /internal_api/tools/runs/{run_id}/running
        if request.method == "POST" and path.endswith("/running"):
            run_id = path.split("/")[-2]
            run = runs.get(run_id)
            if run is None:
                return httpx.Response(409, json={"error": "Not found"})
            run["status"] = "running"
            run["updated_at"] = datetime.now(UTC).isoformat()
            return httpx.Response(200, json=run)

        # POST /internal_api/tools/runs/{run_id}/success
        if request.method == "POST" and path.endswith("/success"):
            run_id = path.split("/")[-2]
            body = json.loads(request.content)
            run = runs.get(run_id)
            if run is None:
                return httpx.Response(409, json={"error": "Not found"})
            run["status"] = "success"
            run["outputs"] = body["outputs"]
            run["updated_at"] = datetime.now(UTC).isoformat()
            return httpx.Response(200, json=run)

        # POST /internal_api/tools/runs/{run_id}/error
        if request.method == "POST" and path.endswith("/error"):
            run_id = path.split("/")[-2]
            body = json.loads(request.content)
            run = runs.get(run_id)
            if run is None:
                return httpx.Response(409, json={"error": "Not found"})
            run["status"] = "error"
            run["error"] = body["error"]
            run["updated_at"] = datetime.now(UTC).isoformat()
            return httpx.Response(200, json=run)

        return httpx.Response(404, json={"error": "Unknown route"})

    httpx_mock.add_callback(handle_request, is_reusable=True)
    return runs


BASE_URL = "http://rails.test"


@pytest.fixture
def store() -> InternalApiRunStore:
    return InternalApiRunStore(base_url=BASE_URL)


def test_full_run_lifecycle_with_internal_api_store(store: InternalApiRunStore, httpx_mock) -> None:
    """POST /runs -> poll GET /runs/{id} -> success, with InternalApiRunStore."""
    _mock_rails_run_store(httpx_mock, BASE_URL)
    client = _build_app(store)

    # Start run
    start_response = client.post(
        "/runs",
        json={"inputs": {"message": "hello from internal api"}},
        headers={"Authorization": "Bearer test-token"},
    )
    assert start_response.status_code == 202
    run_id = start_response.json()["run_id"]

    # Poll until complete
    deadline = time.time() + 5
    while time.time() < deadline:
        poll_response = client.get(
            f"/runs/{run_id}",
            headers={"Authorization": "Bearer test-token"},
        )
        assert poll_response.status_code == 200

        data = poll_response.json()
        if data["status"] == "success":
            assert data["outputs"] == {"echo": "hello from internal api"}
            return

        time.sleep(0.1)

    pytest.fail("Run did not complete in time")


def test_error_lifecycle_with_internal_api_store(httpx_mock) -> None:
    """Handler failure is stored via InternalApiRunStore and returned on poll."""

    class FailInputs(ToolInputs):
        value: ShortText = Field(..., description="A value")

    class FailOutputs(ToolOutputs):
        result: str

    async def failing_handler(inputs: FailInputs) -> FailOutputs:
        raise RuntimeError("intentional failure")

    internal_store = InternalApiRunStore(base_url=BASE_URL)
    _mock_rails_run_store(httpx_mock, BASE_URL)

    app = create_app(
        tool_name="failing_tool",
        tool_description="Fails on purpose",
        handler=failing_handler,
        input_model=FailInputs,
        output_model=FailOutputs,
        store=internal_store,
        ui=False,
    )
    client = TestClient(app)

    start_response = client.post(
        "/runs",
        json={"inputs": {"value": "test"}},
        headers={"Authorization": "Bearer test-token"},
    )
    assert start_response.status_code == 202
    run_id = start_response.json()["run_id"]

    deadline = time.time() + 5
    while time.time() < deadline:
        poll_response = client.get(
            f"/runs/{run_id}",
            headers={"Authorization": "Bearer test-token"},
        )
        data = poll_response.json()
        if data["status"] == "error":
            assert data["error"]["code"] == "EXECUTION_ERROR"
            assert "intentional failure" in data["error"]["message"]
            assert data["error"]["traceback"] is not None
            return

        time.sleep(0.1)

    pytest.fail("Run did not reach error state in time")


def test_bearer_token_forwarded_to_internal_api(store: InternalApiRunStore, httpx_mock) -> None:
    """The bearer token from the caller is forwarded to all Internal API calls."""
    captured_tokens: list[str | None] = []

    import httpx as httpx_lib

    def capture_token(request: httpx_lib.Request) -> httpx_lib.Response:
        captured_tokens.append(request.headers.get("authorization"))

        import json
        from datetime import UTC, datetime

        path = request.url.path
        now = datetime.now(UTC).isoformat()

        if request.method == "POST" and path == "/internal_api/tools/runs":
            body = json.loads(request.content)
            return httpx_lib.Response(201, json={
                "run_id": body["run_id"], "status": "queued",
                "created_at": now, "updated_at": now,
                "inputs": body["inputs"], "outputs": None, "error": None,
            })
        if request.method == "GET":
            return httpx_lib.Response(200, json={
                "run_id": "x", "status": "success",
                "created_at": now, "updated_at": now,
                "inputs": {}, "outputs": {"echo": "ok"}, "error": None,
            })
        return httpx_lib.Response(200, json={"status": "ok"})

    httpx_mock.add_callback(capture_token, is_reusable=True)
    client = _build_app(store)

    # POST /runs with bearer token
    client.post(
        "/runs",
        json={"inputs": {"message": "hi"}},
        headers={"Authorization": "Bearer my-secret-token"},
    )

    # GET /runs/{id} with bearer token
    client.get(
        "/runs/some-id",
        headers={"Authorization": "Bearer my-secret-token"},
    )

    assert all(token == "Bearer my-secret-token" for token in captured_tokens)
    assert len(captured_tokens) >= 2
