"""Tests for InternalApiRunStore."""

from __future__ import annotations

import os
from unittest.mock import patch

import httpx
import pytest

from airops.auth_context import request_auth_token
from airops.server.store import InternalApiRunStore, RunError, RunStatus


@pytest.fixture
def base_url() -> str:
    return "http://rails.test"


@pytest.fixture
def store(base_url: str) -> InternalApiRunStore:
    return InternalApiRunStore(base_url=base_url)


@pytest.fixture
def store_with_ttl(base_url: str) -> InternalApiRunStore:
    return InternalApiRunStore(base_url=base_url, ttl_seconds=3600)


class TestInit:
    def test_defaults_to_airops_api_base_url(self) -> None:
        store = InternalApiRunStore()
        assert store._base_url == "https://api.airops.com"

    def test_reads_base_url_from_env(self) -> None:
        with patch.dict(os.environ, {"AIROPS_API_BASE_URL": "http://from-env.test"}):
            store = InternalApiRunStore()
            assert store._base_url == "http://from-env.test"

    def test_explicit_base_url_overrides_env(self) -> None:
        with patch.dict(os.environ, {"AIROPS_API_BASE_URL": "http://from-env.test"}):
            store = InternalApiRunStore(base_url="http://explicit.test")
            assert store._base_url == "http://explicit.test"

    def test_strips_trailing_slash(self) -> None:
        store = InternalApiRunStore(base_url="http://example.com/")
        assert store._base_url == "http://example.com"

    def test_reads_ttl_from_env(self) -> None:
        with patch.dict(os.environ, {"AIROPS_RUN_TTL_SECONDS": "1800"}):
            store = InternalApiRunStore()
            assert store._ttl_seconds == 1800

    def test_zero_ttl_treated_as_none(self) -> None:
        store = InternalApiRunStore(base_url="http://test.com", ttl_seconds=0)
        assert store._ttl_seconds is None


class TestCreate:
    @pytest.mark.asyncio
    async def test_posts_to_internal_api(self, store: InternalApiRunStore, httpx_mock) -> None:
        httpx_mock.add_response(
            method="POST",
            url="http://rails.test/internal_api/tools/runs",
            json={"status": "created"},
            status_code=201,
        )

        run = await store.create({"query": "hello"})

        assert run.status == RunStatus.QUEUED
        assert run.inputs == {"query": "hello"}
        assert run.run_id is not None

        request = httpx_mock.get_request()
        assert request is not None
        assert request.url.path == "/internal_api/tools/runs"

    @pytest.mark.asyncio
    async def test_sends_run_id_in_body(self, store: InternalApiRunStore, httpx_mock) -> None:
        httpx_mock.add_response(
            method="POST",
            url="http://rails.test/internal_api/tools/runs",
            json={},
            status_code=201,
        )

        run = await store.create({"key": "val"})

        request = httpx_mock.get_request()
        import json

        body = json.loads(request.content)
        assert body["run_id"] == run.run_id
        assert body["inputs"] == {"key": "val"}

    @pytest.mark.asyncio
    async def test_forwards_bearer_token(self, store: InternalApiRunStore, httpx_mock) -> None:
        httpx_mock.add_response(
            method="POST",
            url="http://rails.test/internal_api/tools/runs",
            json={},
            status_code=201,
        )

        token_reset = request_auth_token.set("my-token-123")
        try:
            await store.create({"x": 1})
        finally:
            request_auth_token.reset(token_reset)

        request = httpx_mock.get_request()
        assert request.headers["authorization"] == "Bearer my-token-123"

    @pytest.mark.asyncio
    async def test_sends_ttl_header(self, store_with_ttl: InternalApiRunStore, httpx_mock) -> None:
        httpx_mock.add_response(
            method="POST",
            url="http://rails.test/internal_api/tools/runs",
            json={},
            status_code=201,
        )

        await store_with_ttl.create({"x": 1})

        request = httpx_mock.get_request()
        assert request.headers["x-run-ttl-seconds"] == "3600"

    @pytest.mark.asyncio
    async def test_raises_on_error_status(self, store: InternalApiRunStore, httpx_mock) -> None:
        httpx_mock.add_response(
            method="POST",
            url="http://rails.test/internal_api/tools/runs",
            status_code=500,
            text="Internal Server Error",
        )

        with pytest.raises(httpx.HTTPStatusError):
            await store.create({"x": 1})


class TestGet:
    @pytest.mark.asyncio
    async def test_returns_deserialized_run(self, store: InternalApiRunStore, httpx_mock) -> None:
        httpx_mock.add_response(
            method="GET",
            url="http://rails.test/internal_api/tools/runs/run-123",
            json={
                "run_id": "run-123",
                "status": "running",
                "created_at": "2026-01-15T10:00:00+00:00",
                "updated_at": "2026-01-15T10:01:00+00:00",
                "inputs": {"query": "test"},
                "outputs": None,
                "error": None,
            },
        )

        run = await store.get("run-123")

        assert run is not None
        assert run.run_id == "run-123"
        assert run.status == RunStatus.RUNNING
        assert run.inputs == {"query": "test"}

    @pytest.mark.asyncio
    async def test_returns_none_on_404(self, store: InternalApiRunStore, httpx_mock) -> None:
        httpx_mock.add_response(
            method="GET",
            url="http://rails.test/internal_api/tools/runs/missing",
            status_code=404,
            json={"error": "Run not found"},
        )

        run = await store.get("missing")
        assert run is None

    @pytest.mark.asyncio
    async def test_deserializes_error_field(self, store: InternalApiRunStore, httpx_mock) -> None:
        httpx_mock.add_response(
            method="GET",
            url="http://rails.test/internal_api/tools/runs/err-run",
            json={
                "run_id": "err-run",
                "status": "error",
                "created_at": "2026-01-15T10:00:00+00:00",
                "updated_at": "2026-01-15T10:02:00+00:00",
                "inputs": {},
                "outputs": None,
                "error": {
                    "code": "EXECUTION_ERROR",
                    "message": "something broke",
                    "details": {"type": "ValueError"},
                    "traceback": "Traceback ...",
                },
            },
        )

        run = await store.get("err-run")

        assert run is not None
        assert run.error is not None
        assert run.error.code == "EXECUTION_ERROR"
        assert run.error.message == "something broke"
        assert run.error.traceback == "Traceback ..."

    @pytest.mark.asyncio
    async def test_deserializes_success_outputs(
        self, store: InternalApiRunStore, httpx_mock
    ) -> None:
        httpx_mock.add_response(
            method="GET",
            url="http://rails.test/internal_api/tools/runs/ok-run",
            json={
                "run_id": "ok-run",
                "status": "success",
                "created_at": "2026-01-15T10:00:00+00:00",
                "updated_at": "2026-01-15T10:02:00+00:00",
                "inputs": {"q": "hi"},
                "outputs": {"result": "done"},
                "error": None,
            },
        )

        run = await store.get("ok-run")

        assert run is not None
        assert run.outputs == {"result": "done"}


class TestSetRunning:
    @pytest.mark.asyncio
    async def test_posts_to_running_endpoint(self, store: InternalApiRunStore, httpx_mock) -> None:
        httpx_mock.add_response(
            method="POST",
            url="http://rails.test/internal_api/tools/runs/run-1/running",
            json={"status": "running"},
        )

        await store.set_running("run-1")

        request = httpx_mock.get_request()
        assert request.url.path == "/internal_api/tools/runs/run-1/running"


class TestSetSuccess:
    @pytest.mark.asyncio
    async def test_posts_outputs_to_success_endpoint(
        self, store: InternalApiRunStore, httpx_mock
    ) -> None:
        httpx_mock.add_response(
            method="POST",
            url="http://rails.test/internal_api/tools/runs/run-1/success",
            json={"status": "success"},
        )

        await store.set_success("run-1", {"result": "ok"})

        request = httpx_mock.get_request()
        import json

        body = json.loads(request.content)
        assert body["outputs"] == {"result": "ok"}


class TestSetError:
    @pytest.mark.asyncio
    async def test_posts_error_to_error_endpoint(
        self, store: InternalApiRunStore, httpx_mock
    ) -> None:
        httpx_mock.add_response(
            method="POST",
            url="http://rails.test/internal_api/tools/runs/run-1/error",
            json={"status": "error"},
        )

        error = RunError(
            code="EXECUTION_ERROR",
            message="boom",
            details={"type": "RuntimeError"},
            traceback="Traceback line 1",
        )
        await store.set_error("run-1", error)

        request = httpx_mock.get_request()
        import json

        body = json.loads(request.content)
        assert body["error"]["code"] == "EXECUTION_ERROR"
        assert body["error"]["message"] == "boom"
        assert body["error"]["traceback"] == "Traceback line 1"


class TestClear:
    @pytest.mark.asyncio
    async def test_posts_to_clear_endpoint(self, store: InternalApiRunStore, httpx_mock) -> None:
        httpx_mock.add_response(
            method="POST",
            url="http://rails.test/internal_api/tools/runs/clear",
            status_code=204,
        )

        await store.clear()

        request = httpx_mock.get_request()
        assert request.url.path == "/internal_api/tools/runs/clear"


class TestNoAuthToken:
    @pytest.mark.asyncio
    async def test_omits_auth_header_when_no_token(
        self, store: InternalApiRunStore, httpx_mock
    ) -> None:
        httpx_mock.add_response(
            method="GET",
            url="http://rails.test/internal_api/tools/runs/run-1",
            json={
                "run_id": "run-1",
                "status": "queued",
                "created_at": "2026-01-15T10:00:00+00:00",
                "updated_at": "2026-01-15T10:00:00+00:00",
                "inputs": {},
                "outputs": None,
                "error": None,
            },
        )

        await store.get("run-1")

        request = httpx_mock.get_request()
        assert "authorization" not in request.headers
