"""Tests for the run store factory."""

from __future__ import annotations

import os
from unittest.mock import patch

from airops.server.store import (
    InternalApiRunStore,
    MemoryRunStore,
    get_store,
    reset_store,
)


class TestGetStore:
    def setup_method(self) -> None:
        reset_store()

    def teardown_method(self) -> None:
        reset_store()

    def test_defaults_to_memory_store(self) -> None:
        store = get_store()
        assert isinstance(store, MemoryRunStore)

    def test_memory_store_when_explicit(self) -> None:
        with patch.dict(os.environ, {"AIROPS_RUN_STORE": "memory"}):
            store = get_store()
            assert isinstance(store, MemoryRunStore)

    def test_internal_api_store_when_configured(self) -> None:
        with patch.dict(os.environ, {"AIROPS_RUN_STORE": "internal_api"}):
            store = get_store()
            assert isinstance(store, InternalApiRunStore)

    def test_case_insensitive(self) -> None:
        with patch.dict(os.environ, {"AIROPS_RUN_STORE": "INTERNAL_API"}):
            store = get_store()
            assert isinstance(store, InternalApiRunStore)

    def test_returns_same_instance_on_subsequent_calls(self) -> None:
        first = get_store()
        second = get_store()
        assert first is second


class TestResetStore:
    def test_reset_clears_singleton(self) -> None:
        first = get_store()
        reset_store()
        second = get_store()
        assert first is not second
