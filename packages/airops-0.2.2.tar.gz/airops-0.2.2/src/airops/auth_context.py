"""Per-request auth token propagation via contextvars."""

from contextvars import ContextVar

# Bearer token extracted from the incoming request's Authorization header.
# When set, BaseClient uses this token instead of the config-level token.
request_auth_token: ContextVar[str | None] = ContextVar("request_auth_token", default=None)
