"""Global store instance management with env-var-based selection."""

from __future__ import annotations

import os

from airops.server.store.base import RunStore
from airops.server.store.memory import MemoryRunStore

_store: RunStore | None = None


def get_store() -> RunStore:
    """Get or create the global run store.

    Selection via AIROPS_RUN_STORE env var:
      - "memory" (default): MemoryRunStore (in-process dict)
      - "internal_api": InternalApiRunStore (calls Rails Internal API)
    """
    global _store
    if _store is None:
        backend = os.environ.get("AIROPS_RUN_STORE", "memory").lower()
        if backend == "internal_api":
            from airops.server.store.internal_api import InternalApiRunStore

            _store = InternalApiRunStore()
        else:
            _store = MemoryRunStore()
    return _store


def reset_store() -> None:
    """Reset the global store (useful for testing)."""
    global _store
    _store = None
