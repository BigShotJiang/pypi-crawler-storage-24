"""Run store package for tracking tool execution state.

Provides a pluggable RunStore protocol with two implementations:
- MemoryRunStore: in-memory dict for local development (default)
- InternalApiRunStore: HTTP-backed store via Rails Internal API (production)

All existing imports from airops.server.store continue to work.
"""

from airops.server.store.base import Run, RunError, RunStatus, RunStore
from airops.server.store.factory import get_store, reset_store
from airops.server.store.internal_api import InternalApiRunStore
from airops.server.store.memory import MemoryRunStore

__all__ = [
    "InternalApiRunStore",
    "MemoryRunStore",
    "Run",
    "RunError",
    "RunStatus",
    "RunStore",
    "get_store",
    "reset_store",
]
