"""Internal API-backed run store (calls Rails backend)."""

from __future__ import annotations

import os
import uuid
from datetime import UTC, datetime
from typing import Any

import httpx

from airops.auth_context import request_auth_token
from airops.config import DEFAULT_API_BASE_URL
from airops.server.store.base import Run, RunError, RunStatus


class InternalApiRunStore:
    """Run store backed by the AirOps Rails Internal API.

    All state is persisted in Redis via Rails. This store uses
    httpx.AsyncClient for non-blocking HTTP calls.

    Uses the same AIROPS_API_BASE_URL as the rest of the SDK
    (defaults to https://api.airops.com).

    Optional env vars:
      AIROPS_RUN_TTL_SECONDS: TTL hint sent to Rails (default: none)
    """

    def __init__(
        self,
        base_url: str | None = None,
        ttl_seconds: int | None = None,
    ) -> None:
        self._base_url = (
            base_url
            or os.environ.get("AIROPS_API_BASE_URL", DEFAULT_API_BASE_URL)
        ).rstrip("/")
        raw_ttl = ttl_seconds or int(os.environ.get("AIROPS_RUN_TTL_SECONDS", "0"))
        self._ttl_seconds = raw_ttl if raw_ttl > 0 else None
        self._client = httpx.AsyncClient(base_url=self._base_url, timeout=10.0)

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        token = request_auth_token.get()
        if token:
            headers["Authorization"] = f"Bearer {token}"
        if self._ttl_seconds:
            headers["X-Run-TTL-Seconds"] = str(self._ttl_seconds)
        return headers

    async def create(self, inputs: dict[str, Any]) -> Run:
        """Create a new run via Internal API."""
        run_id = str(uuid.uuid4())
        now = datetime.now(UTC)
        response = await self._client.post(
            "/internal_api/tools/runs",
            json={"run_id": run_id, "inputs": inputs},
            headers=self._headers(),
        )
        response.raise_for_status()
        return Run(
            run_id=run_id,
            status=RunStatus.QUEUED,
            created_at=now,
            updated_at=now,
            inputs=inputs,
        )

    async def get(self, run_id: str) -> Run | None:
        """Get a run by ID via Internal API."""
        response = await self._client.get(
            f"/internal_api/tools/runs/{run_id}",
            headers=self._headers(),
        )
        if response.status_code == 404:
            return None
        response.raise_for_status()
        return self._deserialize(response.json())

    async def set_running(self, run_id: str) -> None:
        """Mark a run as running via Internal API."""
        response = await self._client.post(
            f"/internal_api/tools/runs/{run_id}/running",
            headers=self._headers(),
        )
        response.raise_for_status()

    async def set_success(self, run_id: str, outputs: dict[str, Any]) -> None:
        """Mark a run as successful via Internal API."""
        response = await self._client.post(
            f"/internal_api/tools/runs/{run_id}/success",
            json={"outputs": outputs},
            headers=self._headers(),
        )
        response.raise_for_status()

    async def set_error(self, run_id: str, error: RunError) -> None:
        """Mark a run as failed via Internal API."""
        response = await self._client.post(
            f"/internal_api/tools/runs/{run_id}/error",
            json={
                "error": {
                    "code": error.code,
                    "message": error.message,
                    "details": error.details,
                    "traceback": error.traceback,
                }
            },
            headers=self._headers(),
        )
        response.raise_for_status()

    async def clear(self) -> None:
        """Clear all runs via Internal API (testing only)."""
        response = await self._client.post(
            "/internal_api/tools/runs/clear",
            headers=self._headers(),
        )
        response.raise_for_status()

    @staticmethod
    def _deserialize(data: dict[str, Any]) -> Run:
        error = None
        if data.get("error"):
            error_data = data["error"]
            error = RunError(
                code=error_data["code"],
                message=error_data["message"],
                details=error_data.get("details"),
                traceback=error_data.get("traceback"),
            )
        return Run(
            run_id=data["run_id"],
            status=RunStatus(data["status"]),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
            inputs=data["inputs"],
            outputs=data.get("outputs"),
            error=error,
        )
