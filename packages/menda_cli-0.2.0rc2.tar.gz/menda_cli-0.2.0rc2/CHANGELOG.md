# Changelog

All notable changes to this project will be documented in this file.

## [0.2.0rc2] - 2026-03-27

### Features

- Add auth missing tests (#3) ([b68b38a](https://github.com/mendaml/menda-cli/commit/b68b38aa4729f58ab0429e8826e5ebca7fdf0170))

## [0.2.0rc1] - 2026-03-27

### Features

- Initial project from cookiecutter template ([99339db](https://github.com/mendaml/menda-cli/commit/99339db6171cefc46fa63890b9c07eeabb75ac5e))
- *(deps)* Update dependencies lock and add missing workflows from template ([e705513](https://github.com/mendaml/menda-cli/commit/e70551395e214d5e12c2f94e97bde3ec12de0047))
- Add example test so that actions don't fail on first template ([2835ca8](https://github.com/mendaml/menda-cli/commit/2835ca8e03e9b1c9866d3aa40bc31341fa6de3db))
- Add auth command subgroup (#1) ([cd20706](https://github.com/mendaml/menda-cli/commit/cd207062631d7a2c2039847f763b061101db0e7c))

