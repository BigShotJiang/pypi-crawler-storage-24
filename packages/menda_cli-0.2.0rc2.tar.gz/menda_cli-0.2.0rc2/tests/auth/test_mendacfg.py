"""Tests for MendaConfigManagementService."""

from pathlib import Path

import pytest

from menda.auth.exceptions import ConfigFileNotFoundError, ProfileNotFoundError
from menda.auth.mendacfg import MendaConfigManagementService


@pytest.fixture
def mendacfg_path(tmp_path: Path) -> str:
    """Return a temporary mendacfg file path."""
    return str(tmp_path / "mendacfg")


def test_existing_profiles_empty_when_no_file(mendacfg_path: str) -> None:
    """Test existing_profiles returns empty list when file doesn't exist."""
    svc = MendaConfigManagementService(mendacfg_path)
    assert svc.existing_profiles == []


def test_add_and_read_profile(mendacfg_path: str) -> None:
    """Test adding and reading back a profile."""
    svc = MendaConfigManagementService(mendacfg_path)
    svc.create_empty_mendacfg_file()
    svc.add_profile("dev", {"host": "https://dev.menda.io", "auth_type": "u2m"})

    profile = svc.read_profile("dev")
    assert profile.host == "https://dev.menda.io"
    assert profile.auth_type == "u2m"


def test_read_profile_not_found(mendacfg_path: str) -> None:
    """Test read_profile raises ProfileNotFoundError for missing profile."""
    svc = MendaConfigManagementService(mendacfg_path)
    svc.create_empty_mendacfg_file()
    with pytest.raises(ProfileNotFoundError):
        svc.read_profile("nonexistent")


def test_read_profile_no_config_file(mendacfg_path: str) -> None:
    """Test read_profile raises ConfigFileNotFoundError when no file exists."""
    svc = MendaConfigManagementService(mendacfg_path)
    with pytest.raises(ConfigFileNotFoundError):
        svc.read_profile("dev")


def test_overwrite_profile(mendacfg_path: str) -> None:
    """Test overwriting an existing profile."""
    svc = MendaConfigManagementService(mendacfg_path)
    svc.create_empty_mendacfg_file()
    svc.add_profile("dev", {"host": "https://old.menda.io", "auth_type": "u2m"})
    svc.overwrite_profile("dev", {"host": "https://new.menda.io", "auth_type": "u2m"})

    profile = svc.read_profile("dev")
    assert profile.host == "https://new.menda.io"


def test_check_if_profile_exists(mendacfg_path: str) -> None:
    """Test check_if_profile_exists returns correct bool."""
    svc = MendaConfigManagementService(mendacfg_path)
    svc.create_empty_mendacfg_file()
    svc.add_profile("dev", {"host": "https://dev.menda.io", "auth_type": "u2m"})
    assert svc.check_if_profile_exists("dev") is True
    assert svc.check_if_profile_exists("prod") is False


def test_check_if_profile_exists_no_file(tmp_path: Path) -> None:
    """Test check_if_profile_exists returns False when file doesn't exist."""
    svc = MendaConfigManagementService(str(tmp_path / "nonexistent"))
    assert svc.check_if_profile_exists("any") is False


def test_add_profile_duplicate_raises(mendacfg_path: str) -> None:
    """Test add_profile raises ValueError for duplicate profile."""
    svc = MendaConfigManagementService(mendacfg_path)
    svc.create_empty_mendacfg_file()
    svc.add_profile("dev", {"host": "https://dev.menda.io", "auth_type": "u2m"})
    with pytest.raises(ValueError, match="already exists"):
        svc.add_profile("dev", {"host": "https://other.menda.io", "auth_type": "u2m"})


def test_read_profile_invalid_data(tmp_path: Path) -> None:
    """Test read_profile raises ProfileInvalidError for invalid config."""
    from menda.auth.exceptions import ProfileInvalidError

    cfg = tmp_path / "mendacfg"
    cfg.write_text("[invalid]\nsomething = else\n")
    svc = MendaConfigManagementService(str(cfg))
    with pytest.raises(ProfileInvalidError) as exc_info:
        svc.read_profile("invalid")
    assert exc_info.value.profile_id == "invalid"
