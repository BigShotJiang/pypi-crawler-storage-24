"""Tests for PKCE utilities."""

import pytest

from menda.auth.pkce import generate_code_verifier, generate_pkce_pair, get_code_challenge


def test_generate_code_verifier_default_length() -> None:
    """Test code verifier default length is within PKCE bounds."""
    v = generate_code_verifier()
    assert 43 <= len(v) <= 128


def test_generate_code_verifier_custom_length() -> None:
    """Test code verifier with custom length."""
    v = generate_code_verifier(48)
    assert len(v) == 48


def test_generate_code_verifier_invalid_length() -> None:
    """Test code verifier raises ValueError for invalid length."""
    with pytest.raises(ValueError):
        generate_code_verifier(10)


def test_generate_pkce_pair() -> None:
    """Test PKCE pair generation."""
    verifier, challenge = generate_pkce_pair(48)
    assert len(verifier) == 48
    assert len(challenge) > 0


def test_get_code_challenge_deterministic() -> None:
    """Test code challenge is deterministic for the same verifier."""
    c1 = get_code_challenge("a" * 43)
    c2 = get_code_challenge("a" * 43)
    assert c1 == c2
