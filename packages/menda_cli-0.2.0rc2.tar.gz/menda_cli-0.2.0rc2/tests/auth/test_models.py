"""Tests for auth Pydantic models."""

import pytest
from pydantic import ValidationError

from menda.auth.models import CredentialsModel, DeviceAuthResponseModel, MendaCloudProfileModel


def test_device_auth_response_model() -> None:
    """Test DeviceAuthResponseModel construction."""
    m = DeviceAuthResponseModel(
        device_code="abc",
        user_code="1234",
        verification_uri="/verify",
        verification_uri_complete="/verify?code=1234",
        expires_in=300,
        interval=5,
    )
    assert m.device_code == "abc"
    assert m.interval == 5


def test_profile_model_u2m() -> None:
    """Test MendaCloudProfileModel with u2m auth type."""
    m = MendaCloudProfileModel(host="https://cloud.menda.io", auth_type="u2m")
    assert m.client_id is None
    assert m.client_secret is None


def test_profile_model_m2m() -> None:
    """Test MendaCloudProfileModel with m2m auth type."""
    m = MendaCloudProfileModel(
        host="https://cloud.menda.io",
        auth_type="m2m",
        client_id="cid",
        client_secret="csec",  # noqa: S106
    )
    assert m.auth_type == "m2m"


def test_profile_model_rejects_invalid_auth_type() -> None:
    """Test MendaCloudProfileModel rejects invalid auth type."""
    with pytest.raises(ValidationError):
        MendaCloudProfileModel.model_validate({"host": "https://x.io", "auth_type": "bad"})


def test_credentials_model() -> None:
    """Test CredentialsModel construction with defaults."""
    m = CredentialsModel(access_token="tok", expires_in=3600, token_type="bearer")  # noqa: S106
    assert m.id_token == ""
    assert m.refresh_token == ""
    assert m.cached_at is None
