"""Tests for token caching utilities."""

import time
from pathlib import Path

import pytest

from menda.auth.exceptions import TokenNotFoundError
from menda.auth.models import CredentialsModel
from menda.auth.oauth2.token import cache_token, is_token_expired, load_token


def test_is_token_expired_no_cached_at() -> None:
    """Test is_token_expired returns True when cached_at is None."""
    creds = CredentialsModel(access_token="x", expires_in=3600, token_type="bearer", cached_at=None)  # noqa: S106
    assert is_token_expired(creds) is True


def test_is_token_expired_fresh() -> None:
    """Test is_token_expired returns False for a fresh token."""
    creds = CredentialsModel(access_token="x", expires_in=3600, token_type="bearer", cached_at=time.time())  # noqa: S106
    assert is_token_expired(creds) is False


def test_is_token_expired_old() -> None:
    """Test is_token_expired returns True for an old token."""
    creds = CredentialsModel(access_token="x", expires_in=3600, token_type="bearer", cached_at=time.time() - 4000)  # noqa: S106
    assert is_token_expired(creds) is True


def test_is_token_expired_within_buffer() -> None:
    """Test token is considered expired within the 60-second buffer."""
    # Cached 59m10s ago with 1h expiry → within 60s buffer → expired
    creds = CredentialsModel(access_token="x", expires_in=3600, token_type="bearer", cached_at=time.time() - 3550)  # noqa: S106
    assert is_token_expired(creds) is True


def test_is_token_expired_outside_buffer() -> None:
    """Test token is not expired when outside the 60-second buffer."""
    # Cached 55m ago with 1h expiry → 5m before buffer → not expired
    creds = CredentialsModel(access_token="x", expires_in=3600, token_type="bearer", cached_at=time.time() - 3300)  # noqa: S106
    assert is_token_expired(creds) is False


def test_is_token_expired_short_expiry() -> None:
    """Test token with short expiration (5 min) cached 6 min ago is expired."""
    creds = CredentialsModel(access_token="x", expires_in=300, token_type="bearer", cached_at=time.time() - 360)  # noqa: S106
    assert is_token_expired(creds) is True


def test_cache_and_load_token(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test caching and loading a token round-trip."""
    cache_path = str(tmp_path / "tokens" / "cache" / ".token")
    monkeypatch.setattr("menda.auth.oauth2.token.TOKENS_CACHE_PATH", cache_path)

    creds = CredentialsModel(access_token="tok123", expires_in=3600, token_type="bearer")  # noqa: S106
    cache_token(creds, "dev")

    loaded = load_token("dev")
    assert loaded.access_token == "tok123"  # noqa: S105
    assert loaded.cached_at is not None


def test_load_token_not_found(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test load_token raises TokenNotFoundError when cache doesn't exist."""
    cache_path = str(tmp_path / "nonexistent" / ".token")
    monkeypatch.setattr("menda.auth.oauth2.token.TOKENS_CACHE_PATH", cache_path)
    with pytest.raises(TokenNotFoundError):
        load_token("dev")
