import click
from click.testing import CliRunner

from menda.auth.env import get_auth_env
from menda.cli.params import dry_run, menda_profile_id, project_path

auth_env = get_auth_env().model_dump(mode="json")


def test_menda_profile_id_default_is_none():
    """menda_profile_id defaults to None when flag is not provided."""

    @click.command()
    @menda_profile_id
    def cmd(menda_profile_id):
        click.echo(f"profile={menda_profile_id}")

    runner = CliRunner(env=auth_env)
    result = runner.invoke(cmd)
    assert result.exit_code == 0
    assert "profile= in result.output"


def test_menda_profile_id_from_flag():
    """menda_profile_id accepts a string value from the flag."""

    @click.command()
    @menda_profile_id
    def cmd(menda_profile_id):
        click.echo(f"profile={menda_profile_id}")

    runner = CliRunner(env=auth_env)
    result = runner.invoke(cmd, ["--menda-profile-id", "dev"])
    assert result.exit_code == 0
    assert "profile=dev" in result.output


def test_dry_run_default_false():
    """dry_run defaults to False when flag is not provided."""

    @click.command()
    @dry_run
    def cmd(dry_run):
        click.echo(f"dry_run={dry_run}")

    runner = CliRunner(env=auth_env)
    result = runner.invoke(cmd)
    assert result.exit_code == 0
    assert "dry_run=False" in result.output


def test_dry_run_flag():
    """dry_run is True when --dry-run flag is passed."""

    @click.command()
    @dry_run
    def cmd(dry_run):
        click.echo(f"dry_run={dry_run}")

    runner = CliRunner(env=auth_env)
    result = runner.invoke(cmd, ["--dry-run"])
    assert result.exit_code == 0
    assert "dry_run=True" in result.output


def test_project_path_default_cwd():
    """project_path defaults to '.' when flag is not provided."""

    @click.command()
    @project_path
    def cmd(project_path):
        click.echo(f"path={project_path}")

    runner = CliRunner(env=auth_env)
    result = runner.invoke(cmd)
    assert result.exit_code == 0
    assert "path=." in result.output
