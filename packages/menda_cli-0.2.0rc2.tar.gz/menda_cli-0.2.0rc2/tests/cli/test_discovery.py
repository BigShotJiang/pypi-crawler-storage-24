from unittest.mock import MagicMock, patch

import click

from menda.cli.discovery import PackageInfo, discover_packages, get_discovered_packages


def test_package_info_loaded():
    """PackageInfo with loaded status stores name, status, and version correctly."""
    info = PackageInfo(name="core", status="loaded", version="1.0.0")
    assert info.name == "core"
    assert info.status == "loaded"
    assert info.version == "1.0.0"
    assert info.error is None


def test_package_info_failed():
    """PackageInfo with failed status stores error message."""
    info = PackageInfo(name="bad", status="failed", error="ImportError")
    assert info.status == "failed"
    assert info.error == "ImportError"


def test_discover_packages_no_packages():
    """discover_packages returns empty list when no entry points are registered."""
    cli = click.Group(name="menda")
    with patch("menda.cli.discovery.entry_points", return_value=[]):
        result = discover_packages(cli)
    assert result == []


def test_discover_packages_success():
    """discover_packages loads a package, registers its commands, and returns PackageInfo."""
    cli = click.Group(name="menda")

    mock_ep = MagicMock()
    mock_ep.name = "testpackage"
    mock_ep.dist.name = "menda-testpackage"
    mock_ep.load.return_value = lambda c: c.add_command(click.Command("hello", callback=lambda: None))

    with (
        patch("menda.cli.discovery.entry_points", return_value=[mock_ep]),
        patch("menda.cli.discovery.version", return_value="2.0.0"),
    ):
        result = discover_packages(cli)

    assert len(result) == 1
    assert result[0].name == "testpackage"
    assert result[0].status == "loaded"
    assert result[0].version == "2.0.0"
    assert "hello" in cli.commands


def test_discover_packages_failure_does_not_crash():
    """discover_packages catches load errors and records failed status without raising."""
    cli = click.Group(name="menda")

    mock_ep = MagicMock()
    mock_ep.name = "badpackage"
    mock_ep.load.side_effect = ImportError("no module")

    with patch("menda.cli.discovery.entry_points", return_value=[mock_ep]):
        result = discover_packages(cli)

    assert len(result) == 1
    assert result[0].status == "failed"
    err = result[0].error
    assert err is not None
    assert "no module" in err


def test_get_discovered_packages_returns_last_result():
    """get_discovered_packages returns the result of the most recent discover_packages call."""
    cli = click.Group(name="menda")
    with patch("menda.cli.discovery.entry_points", return_value=[]):
        discover_packages(cli)
    assert get_discovered_packages() == []
