"""Auth API routes for Menda Cloud."""

import requests

AUTHORIZATION_PATH = "/auth/device/authorize"
TOKEN_PATH = "/auth/device/token"  # noqa: S105
WHOAMI_PATH = "/auth/whoami"
OAUTH2_TOKEN_PATH = "/auth/oauth2/token"  # noqa: S105


class AuthRoutes:
    """HTTP routes for authentication endpoints."""

    @classmethod
    def authorize_device(
        cls,
        session: requests.Session,
        client_id: str,
        scope: list[str],
        code_challenge: str,
        code_challenge_method: str,
    ) -> requests.Response:
        """Request device authorization."""
        return session.post(
            url=AUTHORIZATION_PATH,
            params={
                "client_id": client_id,
                "scope": " ".join(scope),
                "code_challenge": code_challenge,
                "code_challenge_method": code_challenge_method,
            },
        )

    @classmethod
    def token(
        cls,
        session: requests.Session,
        client_id: str,
        redirect_uri: str,
        device_code: str,
        grant_type: str,
        code_verifier: str,
    ) -> requests.Response:
        """Exchange device code for token."""
        return session.post(
            url=TOKEN_PATH,
            json={
                "client_id": client_id,
                "redirect_uri": redirect_uri,
                "device_code": device_code,
                "grant_type": grant_type,
                "code_verifier": code_verifier,
            },
        )

    @classmethod
    def oauth2_token(
        cls,
        session: requests.Session,
        *,
        client_id: str,
        client_secret: str,
        grant_type: str,
        scope: str | None = None,
        code: str = "",
        redirect_uri: str = "",
        code_verifier: str | None = None,
    ) -> requests.Response:
        """OAuth2 token exchange (e.g., client-credentials)."""
        payload: dict[str, object] = {
            "client_id": client_id,
            "client_secret": client_secret,
            "grant_type": grant_type,
        }
        if scope:
            payload["scope"] = scope
        if code:
            payload["code"] = code
        if redirect_uri:
            payload["redirect_uri"] = redirect_uri
        if code_verifier:
            payload["code_verifier"] = code_verifier
        return session.post(url=OAUTH2_TOKEN_PATH, params=payload)

    @classmethod
    def whoami(cls, session: requests.Session, token: str) -> requests.Response:
        """Get current user info."""
        return session.get(
            headers={"authorizationToken": token},
            url=WHOAMI_PATH,
        )
