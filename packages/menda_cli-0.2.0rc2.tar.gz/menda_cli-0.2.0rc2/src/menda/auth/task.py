"""Auth business logic — configure, login, whoami."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal
from urllib.parse import urljoin

import structlog

from menda.auth import models
from menda.cli.console import Console

logger = structlog.get_logger()


@dataclass(frozen=True)
class AuthConfig:
    """Resolved authentication configuration with source tracking."""

    profile: models.MendaCloudProfileModel
    source: Literal["environment", "profile"]
    profile_id: str | None


def resolve_auth_config(profile_id: str) -> AuthConfig:
    """Resolve auth config from env vars or profile. Env vars take precedence."""
    from menda.auth.env import get_auth_env

    env = get_auth_env()
    env_vars = (env.MENDA_CLIENT_ID, env.MENDA_CLIENT_SECRET, env.MENDA_HOST)
    env_vars_set = [v for v in env_vars if v]

    if len(env_vars_set) == 3:
        profile = models.MendaCloudProfileModel(
            host=env.MENDA_HOST,
            auth_type="m2m",
            client_id=env.MENDA_CLIENT_ID,
            client_secret=env.MENDA_CLIENT_SECRET,
        )
        return AuthConfig(profile=profile, source="environment", profile_id=None)

    if env_vars_set:
        present = [
            name
            for name, val in [
                ("MENDA_CLIENT_ID", env.MENDA_CLIENT_ID),
                ("MENDA_CLIENT_SECRET", env.MENDA_CLIENT_SECRET),
                ("MENDA_HOST", env.MENDA_HOST),
            ]
            if val
        ]
        logger.warning(
            "Incomplete M2M environment variables. Falling back to profile.",
            present_vars=", ".join(present),
            fallback_profile=profile_id,
        )

    profile = load_profile_with_validation(profile_id)
    return AuthConfig(profile=profile, source="profile", profile_id=profile_id)


def load_profile_with_validation(profile_id: str) -> models.MendaCloudProfileModel:
    """Load and validate profile from mendacfg."""
    from menda.auth.env import get_auth_env
    from menda.auth.mendacfg import MendaConfigManagementService

    env = get_auth_env()
    svc = MendaConfigManagementService(mendacfg_path=env.MENDA_CONFIG_FILE)
    return svc.read_profile(profile_id=profile_id)


def load_token_with_validation(profile_id: str) -> models.CredentialsModel:
    """Load and validate cached token."""
    from menda.auth.exceptions import TokenExpiredError
    from menda.auth.oauth2 import token

    token_data = token.load_token(profile_id=profile_id)
    if token.is_token_expired(token_data):
        raise TokenExpiredError(profile_id)
    return token_data


def configure(console: Console) -> None:
    """Configure authentication profile."""
    from menda.auth.env import get_auth_env
    from menda.auth.inquirer import prompt_for_overwrite_profile, prompt_for_profile_name
    from menda.auth.mendacfg import MendaConfigManagementService

    env = get_auth_env()
    console.info("Configuring authentication profile")
    console.info(f"Configuration file: {env.MENDA_CONFIG_FILE}")

    mendacfg_svc = MendaConfigManagementService(mendacfg_path=env.MENDA_CONFIG_FILE)
    profile_name = prompt_for_profile_name()

    if mendacfg_svc.check_if_profile_exists(profile_name):
        overwrite = prompt_for_overwrite_profile(profile_name)
        if not overwrite:
            console.info("Configuration cancelled.")
            return
        profile_data = mendacfg_svc.construct_profile_data()
        mendacfg_svc.overwrite_profile(profile_name, profile_data)
        console.success(f"✓ Profile '{profile_name}' updated successfully")
    else:
        profile_data = mendacfg_svc.construct_profile_data()
        mendacfg_svc.add_profile(profile_name, profile_data)
        console.success(f"✓ Profile '{profile_name}' created successfully")


def login(console: Console, profile_id: str | None) -> None:
    """Login to Menda Cloud via device flow."""
    from menda.auth import pkce
    from menda.auth.env import get_auth_env
    from menda.auth.exceptions import AuthenticationError
    from menda.auth.http import requests_session
    from menda.auth.oauth2 import client, token

    env = get_auth_env()
    profile_id = profile_id if profile_id else env.MENDA_PROFILE_ID

    console.info("Authenticating to Menda Cloud")

    auth_config = resolve_auth_config(profile_id)

    if auth_config.source == "environment":
        raise AuthenticationError(
            detail="M2M credentials detected from environment variables. "
            "The `menda auth login` command is for interactive (U2M) authentication.",
        )

    console.info(f"Profile: {auth_config.profile_id}")

    profile_data = auth_config.profile
    if getattr(profile_data, "auth_type", "u2m") == "m2m":
        raise AuthenticationError(
            detail="M2M profiles use automatic token exchange.",
        )

    session = requests_session(base_url=profile_data.host)
    code_verifier, code_challenge = pkce.generate_pkce_pair(48)

    device_model = client.authorize_device(session=session, code_challenge=code_challenge)
    verification_url = urljoin(profile_data.host, device_model.verification_uri_complete)
    console.info(f"Opening browser for authentication: {verification_url}")
    client.open_browser(verification_url)

    credentials = client.login_with_device(
        session=session, device_model=device_model, host=profile_data.host, code_verifier=code_verifier
    )

    token.cache_token(credentials=credentials, profile_id=profile_id)
    console.success("✓ Authentication successful")


def whoami(console: Console, profile_id: str | None) -> None:
    """Show the current authenticated user."""
    from menda.auth.api import AuthRoutes
    from menda.auth.env import get_auth_env
    from menda.auth.exceptions import AuthenticationError
    from menda.auth.http import requests_session
    from menda.auth.oauth2 import client as oauth_client

    env = get_auth_env()
    profile_id = profile_id if profile_id else env.MENDA_PROFILE_ID

    console.info("Current User Information")

    auth_config = resolve_auth_config(profile_id)

    if auth_config.source == "environment":
        console.info("Authenticating via environment variables (M2M)")
    else:
        console.info(f"Profile: {auth_config.profile_id}")

    profile_data = auth_config.profile
    session = requests_session(base_url=profile_data.host)

    if getattr(profile_data, "auth_type", "u2m") == "m2m":
        if not profile_data.client_id or not profile_data.client_secret:
            raise AuthenticationError(detail="Client ID and client secret are required for M2M authentication")
        credentials = oauth_client.login_with_client_credentials(
            session=session, client_id=profile_data.client_id, client_secret=profile_data.client_secret
        )
        token_value = credentials.access_token
    else:
        token_data = load_token_with_validation(profile_id)
        token_value = token_data.id_token or token_data.access_token

    response = AuthRoutes.whoami(session=session, token=token_value)

    if response.status_code == 200:
        data = response.json()
        identity_type = data.get("identity_type", "unknown")
        label = "Service Principal" if identity_type == "service_principal" else "User"

        if console.output_mode.value == "json":
            console.json(data)
        else:
            console.success(f"{label} Details:")
            console.info(f"  Tenant:   {data.get('tenant_id', 'N/A')}")
            console.info(f"  Username: {data.get('username', 'N/A')}")
            console.info(f"  Email:    {data.get('email') or 'N/A'}")
            console.info(f"  Role:     {data.get('user_role', 'N/A')}")
            console.info(f"  Type:     {identity_type}")
    else:
        try:
            error_msg = response.json().get("detail", "Unknown error")
        except Exception:
            error_msg = response.text or f"HTTP {response.status_code}"
        raise AuthenticationError(detail=f"Failed to fetch user information: {error_msg}")
