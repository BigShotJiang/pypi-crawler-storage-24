from InquirerPy import inquirer
from InquirerPy.base.control import Choice
from prompt_toolkit.document import Document
from prompt_toolkit.validation import ValidationError, Validator


class HttpsValidator(Validator):
    def validate(self, document: Document) -> None:
        """Validate the input to ensure it starts with 'https://'."""
        if not document.text.startswith("https://"):
            raise ValidationError(
                message=f"Input must start with 'https://'. Current input: '{document.text}'",
                cursor_position=document.cursor_position,
            )


class NonEmptyValidator(Validator):
    def validate(self, document: Document) -> None:
        """Validate the input to ensure it is not empty."""
        if not document.text or not document.text.strip():
            raise ValidationError(
                message="Input must not be empty.",
                cursor_position=document.cursor_position,
            )


def prompt_for_profile_name() -> str:
    """Prompt the user for a profile name."""
    return inquirer.text(
        message="Enter a profile name:",
        default="default",
    ).execute()


def prompt_for_overwrite_profile(profile_name: str) -> bool:
    """Prompt the user for confirmation to overwrite a profile.

    :param str profile_name: Profile name
    :return bool: True if user wishes to overwrite, False otherwise
    """
    return inquirer.confirm(
        message=f"Profile '{profile_name.strip()}' already exists. Do you wish to overwrite?",
        default=False,
    ).execute()


def prompt_for_host() -> str:
    """Prompt the user for a menda hostname url."""
    host = inquirer.text(
        message="Enter your menda hostname url (https://):",
        validate=HttpsValidator(),
    ).execute()
    return host


def prompt_for_auth_type() -> str:
    """Prompt the user for the authentication type used for this profile."""
    return inquirer.select(
        message="Select authentication type:",
        choices=[
            Choice(value="u2m", name="u2m (user-to-machine)"),
            Choice(value="m2m", name="m2m (machine-to-machine)"),
        ],
        default="u2m",
    ).execute()


def prompt_for_client_id() -> str:
    """Prompt the user for the m2m OAuth2 client id."""
    return inquirer.text(
        message="Enter your m2m client_id:",
        validate=NonEmptyValidator(),
    ).execute()


def prompt_for_client_secret() -> str:
    """Prompt the user for the m2m OAuth2 client secret."""
    return inquirer.text(
        message="Enter your m2m client_secret:",
        validate=NonEmptyValidator(),
    ).execute()


def prompt_for_existing_profile_selection(existing_profiles: list[str]) -> str:
    """Prompt the user to select an existing profile or add a new profile.

    :param list[str] existing_profiles: List of existing profiles
    :return str: Selected profile name
    """
    return inquirer.select(
        message="Select from the existing profiles:",
        choices=[*existing_profiles, "default", Choice(value="add_profile", name="Add profile")],
        default=None,
    ).execute()
