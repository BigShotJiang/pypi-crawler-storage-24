"""OAuth2 client — device flow and M2M credentials."""

import time
import typing
import webbrowser
from urllib.parse import urljoin

import requests
import structlog

from menda.auth import exceptions, models
from menda.auth.api import AuthRoutes
from menda.auth.exceptions import AuthenticationError

logger = structlog.get_logger()

CLIENT_ID = "device"
SCOPE = ["openid"]
GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code"
CALLBACK_PATH = "/auth/device/callback"


def poll_for_token(interval: int, expires_in: int, api: typing.Callable[[], requests.Response]) -> requests.Response:
    """Poll an API endpoint at intervals until success or timeout."""
    deadline = time.time() + expires_in
    logger.debug("Starting device code polling", interval=interval, expires_in=expires_in)
    while True:
        time.sleep(interval)
        response: requests.Response = api()
        logger.debug("Poll response", status_code=response.status_code)
        if response.status_code == 200:
            return response
        detail = response.json().get("detail", "")
        if not is_device_code_in_valid_state(detail):
            return response
        if time.time() >= deadline:
            raise AuthenticationError(code=response.status_code, detail=f"Device code expired: {detail}.")


def is_device_code_in_valid_state(state: str) -> bool:
    """Check if device code state is valid (authorized or pending)."""
    return state in ["authorized", "pending"]


def authorize_device(session: requests.Session, code_challenge: str) -> models.DeviceAuthResponseModel:
    """Request device authorization."""
    response = AuthRoutes.authorize_device(
        session=session, client_id=CLIENT_ID, scope=SCOPE, code_challenge=code_challenge, code_challenge_method="S256"
    )
    if response and response.status_code == 200:
        return models.DeviceAuthResponseModel(**response.json())
    detail = response.json().get("detail")
    raise AuthenticationError(code=response.status_code, detail=detail)


def open_browser(url: str) -> None:
    """Open the browser to the verification URI."""
    webbrowser.open(url)


def login_with_device(
    session: requests.Session,
    device_model: models.DeviceAuthResponseModel,
    host: str,
    code_verifier: str,
) -> models.CredentialsModel:
    """Complete device flow login."""
    response = poll_for_token(
        interval=device_model.interval,
        expires_in=device_model.expires_in,
        api=lambda: AuthRoutes.token(
            session=session,
            client_id=CLIENT_ID,
            redirect_uri=urljoin(host, CALLBACK_PATH),
            device_code=device_model.device_code,
            grant_type=GRANT_TYPE,
            code_verifier=code_verifier,
        ),
    )
    if response and response.status_code == 200:
        return models.CredentialsModel(**response.json())
    detail = response.json().get("detail")
    raise exceptions.AuthenticationError(code=response.status_code, detail=detail)


def login_with_client_credentials(
    session: requests.Session, *, client_id: str, client_secret: str, scope: str = "api/all"
) -> models.CredentialsModel:
    """Login using OAuth2 client-credentials (M2M)."""
    response = AuthRoutes.oauth2_token(
        session=session, client_id=client_id, client_secret=client_secret, grant_type="client_credentials", scope=scope
    )
    if response and response.status_code == 200:
        return models.CredentialsModel(**response.json())
    detail = response.json().get("detail", "") if response is not None else ""
    raise exceptions.AuthenticationError(code=response.status_code if response is not None else None, detail=detail)
