"""Auth-specific exceptions inheriting from the CLI exception hierarchy."""

from menda.cli.exceptions import AuthError


class ConfigFileNotFoundError(AuthError):
    """Raised when mendacfg file doesn't exist."""

    def __init__(self, config_path: str) -> None:
        self.config_path = config_path
        super().__init__(
            message=f"Configuration file not found: {config_path}",
            context="auth:config",
            suggestion="Run 'menda auth configure' to create initial configuration",
        )


class ProfileNotFoundError(AuthError):
    """Raised when a profile doesn't exist."""

    def __init__(self, profile_id: str, available_profiles: list[str] | None = None) -> None:
        self.profile_id = profile_id
        self.available_profiles = available_profiles or []

        suggestion = "Run 'menda auth configure' to create a new profile"
        if available_profiles:
            suggestion += f"\n\nAvailable profiles: {', '.join(available_profiles)}"

        super().__init__(
            message=f"Profile '{profile_id}' not found in configuration",
            context=f"auth:profile:{profile_id}",
            suggestion=suggestion,
        )


class ProfileInvalidError(AuthError):
    """Raised when a profile has invalid configuration."""

    def __init__(self, profile_id: str, validation_error: str) -> None:
        self.profile_id = profile_id
        self.validation_error = validation_error
        super().__init__(
            message=f"Profile '{profile_id}' has invalid configuration\n  Details: {validation_error}",
            context=f"auth:profile:{profile_id}",
            suggestion="Run 'menda auth configure' to reconfigure this profile",
        )


class TokenNotFoundError(AuthError):
    """Raised when no token exists for a profile."""

    def __init__(self, profile_id: str) -> None:
        self.profile_id = profile_id
        super().__init__(
            message=f"No authentication token found for profile '{profile_id}'",
            context=f"auth:token:{profile_id}",
            suggestion=f"Run 'menda auth login --menda-profile-id {profile_id}' to authenticate",
        )


class TokenExpiredError(AuthError):
    """Raised when token has expired."""

    def __init__(self, profile_id: str) -> None:
        self.profile_id = profile_id
        super().__init__(
            message=f"Authentication token expired for profile '{profile_id}'",
            context=f"auth:token:{profile_id}",
            suggestion=f"Run 'menda auth login --menda-profile-id {profile_id}' to refresh",
        )


class DeviceCodeExpiredError(AuthError):
    """Raised when a device code has expired during authentication."""

    def __init__(self, message: str = "Device code has expired") -> None:
        super().__init__(
            message=message,
            context="auth:device_flow",
            suggestion="Authentication session timed out. Please run 'menda auth login' again.",
        )


class AuthenticationError(AuthError):
    """Raised when authentication fails for any reason."""

    def __init__(self, detail: str, code: int | str | None = None) -> None:
        self.detail = detail
        self.code = code

        suggestion = None
        if "device code" in detail.lower():
            suggestion = "The authentication session expired. Please run 'menda auth login' again."
        elif "network" in detail.lower() or "connection" in detail.lower():
            suggestion = "Check your network connection and Menda Cloud URL in profile configuration."

        super().__init__(
            message=detail,
            context=f"auth:cloud:{code}" if code else "auth:cloud",
            suggestion=suggestion,
        )
