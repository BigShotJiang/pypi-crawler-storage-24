"""HTTP session factory for auth API calls."""

import typing
from functools import partial

import requests

API_VERSION = "/api/v1"


class CustomRequestsSession(requests.Session):
    """Requests session with custom methods."""

    def delete_with_payload(self, **kwargs: typing.Any) -> requests.Response:  # noqa: ANN401
        """DELETE with request body support."""
        return self.request(method="DELETE", **kwargs)


def requests_session(base_url: str) -> CustomRequestsSession:
    """Create a requests session with a base URL prepended to all requests."""

    def new_request(
        base_url: str,
        f: typing.Callable,
        method: str,
        url: str,
        *args: typing.Any,  # noqa: ANN401
        **kwargs: typing.Any,  # noqa: ANN401
    ) -> requests.Response:
        return f(method, base_url + API_VERSION + url, *args, **kwargs)

    base_url = "" if base_url is None else base_url.rstrip("/")
    s = CustomRequestsSession()
    s.request = partial(new_request, base_url, s.request)  # ty:ignore[invalid-assignment]
    return s
