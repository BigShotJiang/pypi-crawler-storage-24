"""Standardized exception hierarchy for the menda CLI."""

from enum import StrEnum


class ErrorCategory(StrEnum):
    """Error categories with associated exit codes."""

    AUTH = "auth"
    CONFIG = "config"
    NETWORK = "network"
    VALIDATION = "validation"
    PLUGIN = "plugin"
    UNKNOWN = "unknown"


class MendaCLIError(Exception):
    """Base exception for all menda CLI errors.

    Provides structured error information with human-readable display
    and machine-readable dict output for JSON mode.
    """

    def __init__(
        self,
        message: str,
        context: str | None = None,
        suggestion: str | None = None,
        category: ErrorCategory = ErrorCategory.UNKNOWN,
        exit_code: int = 1,
    ) -> None:
        self.message = message
        self.context = context
        self.suggestion = suggestion
        self.category = category
        self.exit_code = exit_code
        super().__init__(message)

    def format_for_display(self) -> str:
        """Format error for human-readable CLI output."""
        lines = []
        prefix = f"[{self.category.value}] " if self.category != ErrorCategory.UNKNOWN else ""
        lines.append(f"{prefix}{self.message}")
        if self.context:
            lines.append(f"  Context: {self.context}")
        if self.suggestion:
            lines.append(f"  Suggestion: {self.suggestion}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        """Convert to dict for JSON output mode."""
        return {
            "message": self.message,
            "context": self.context,
            "suggestion": self.suggestion,
            "category": self.category.value,
            "exit_code": self.exit_code,
        }


class AuthError(MendaCLIError):
    """Base exception for authentication errors."""

    def __init__(
        self,
        message: str,
        context: str | None = None,
        suggestion: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            context=context,
            suggestion=suggestion,
            category=ErrorCategory.AUTH,
            exit_code=2,
        )


class ConfigError(MendaCLIError):
    """Base exception for configuration errors."""

    def __init__(
        self,
        message: str,
        context: str | None = None,
        suggestion: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            context=context,
            suggestion=suggestion,
            category=ErrorCategory.CONFIG,
            exit_code=3,
        )


class NetworkError(MendaCLIError):
    """Base exception for network errors."""

    def __init__(
        self,
        message: str,
        context: str | None = None,
        suggestion: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            context=context,
            suggestion=suggestion,
            category=ErrorCategory.NETWORK,
            exit_code=4,
        )


class ValidationError(MendaCLIError):
    """Base exception for validation errors."""

    def __init__(
        self,
        message: str,
        context: str | None = None,
        suggestion: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            context=context,
            suggestion=suggestion,
            category=ErrorCategory.VALIDATION,
            exit_code=5,
        )


class PluginError(MendaCLIError):
    """Base exception for plugin errors."""

    def __init__(
        self,
        message: str,
        context: str | None = None,
        suggestion: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            context=context,
            suggestion=suggestion,
            category=ErrorCategory.PLUGIN,
            exit_code=6,
        )
