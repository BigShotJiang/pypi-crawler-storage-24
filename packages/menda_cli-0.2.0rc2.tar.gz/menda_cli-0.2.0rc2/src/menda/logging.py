"""Structured logging configuration for menda packages.

This module lives at menda.logging (top-level namespace) so both
CLI and programmatic consumers can configure logging without importing
the CLI package.

- CLI path: safe_main() calls configure_logging() with --log-level
- Programmatic path: user calls configure_logging() directly
- If never called, structlog works with defaults (functional but unformatted)
"""

import structlog
from structlog.processors import ExceptionRenderer
from structlog.typing import Processor


def configure_logging(log_level: str, json_output: bool = False, show_locals: bool = False) -> None:
    """Configure structlog processors, output format, and level.

    Args:
        log_level: Minimum log level (debug, info, warning, error).
        json_output: If True, output logs as JSON.
        show_locals: If True, include local variables in exception tracebacks.

    """
    numeric_level = structlog.stdlib.NAME_TO_LEVEL.get(log_level.lower())
    if numeric_level is None:
        msg = f"Invalid log level: {log_level}"
        raise ValueError(msg)

    shared_processors: list[Processor] = [
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="%Y-%m-%d %H:%M:%S"),
        structlog.contextvars.merge_contextvars,
    ]

    if numeric_level < 20:  # debug level
        shared_processors.append(
            structlog.processors.CallsiteParameterAdder(
                [structlog.processors.CallsiteParameter.MODULE],
                additional_ignores=[__name__],
            ),
        )

    renderers: list[Processor]
    if json_output:
        renderers = [
            ExceptionRenderer(structlog.processors.ExceptionDictTransformer(show_locals=show_locals)),
            structlog.processors.JSONRenderer(),
        ]
    else:
        renderers = [
            structlog.dev.ConsoleRenderer(
                colors=True,
                level_styles={
                    "debug": "\033[36m",
                    "info": "\033[32m",
                    "warning": "\033[33m",
                    "error": "\033[31m",
                    "critical": "\033[41m",
                },
            ),
        ]

    structlog.configure(
        processors=[*shared_processors, *renderers],
        cache_logger_on_first_use=True,
        wrapper_class=structlog.make_filtering_bound_logger(min_level=numeric_level),
    )
