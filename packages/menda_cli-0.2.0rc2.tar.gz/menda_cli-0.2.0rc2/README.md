# menda-cli

A CLI for building, deploying and managing menda data products.

## Installation

```bash
uv add menda-cli
```

## Development

### Setup

```bash
# Clone the repository
git clone https://github.com/mendaml/menda-cli.git
cd menda-cli

# Install dependencies
uv sync
```

### Linting

```bash
# Run all linters (format, style, typing)
uv run poe lint-all

# Or run individually
uv run poe lint-format   # Format code
uv run poe lint-style    # Check style
uv run poe lint-typing   # Check types
```

### Testing

```bash
# Run tests
uv run poe test

# Run tests with coverage
uv run poe test-cov
```

---
*Generated from [menda-cookiecutter-python](https://github.com/mendaml/menda-cookiecutter-python).*
