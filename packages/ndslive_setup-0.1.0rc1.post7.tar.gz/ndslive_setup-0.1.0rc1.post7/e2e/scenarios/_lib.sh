#!/usr/bin/env bash
# Shared helpers for E2E scenarios.

set -euo pipefail

_PASS=0
_FAIL=0
_SCENARIO=""

scenario() {
    _SCENARIO="$1"
    echo ""
    echo "=== SCENARIO: ${_SCENARIO} ==="
    echo ""
}

step() {
    echo "--- $1"
}

pass_step() {
    _PASS=$((_PASS + 1))
    echo "  [PASS] $1"
}

fail_step() {
    _FAIL=$((_FAIL + 1))
    echo "  [FAIL] $1" >&2
}

summary() {
    echo ""
    echo "=== RESULTS: ${_SCENARIO} ==="
    echo "  Passed: ${_PASS}"
    echo "  Failed: ${_FAIL}"
    echo ""
    if [ "$_FAIL" -gt 0 ]; then
        exit 1
    fi
}

# --- Assertions ---

assert_exit_zero() {
    local desc="$1"
    shift
    if "$@" > /tmp/_assert_out 2>&1; then
        pass_step "${desc}"
    else
        fail_step "${desc} (exit $?)"
        cat /tmp/_assert_out >&2
    fi
}

assert_exit_nonzero() {
    local desc="$1"
    shift
    if "$@" > /tmp/_assert_out 2>&1; then
        fail_step "${desc} (expected failure, got exit 0)"
        cat /tmp/_assert_out >&2
    else
        pass_step "${desc}"
    fi
}

assert_output_contains() {
    local desc="$1"
    local pattern="$2"
    shift 2
    local output
    output=$("$@" 2>&1) || true
    if echo "${output}" | grep -qi "${pattern}"; then
        pass_step "${desc}"
    else
        fail_step "${desc} — pattern '${pattern}' not found in output"
        echo "  Output was: ${output}" >&2
    fi
}

assert_file_exists() {
    local desc="$1"
    local path="$2"
    if [ -f "${path}" ]; then
        pass_step "${desc}"
    else
        fail_step "${desc} — ${path} does not exist"
    fi
}

assert_file_not_exists() {
    local desc="$1"
    local path="$2"
    if [ ! -f "${path}" ]; then
        pass_step "${desc}"
    else
        fail_step "${desc} — ${path} still exists"
    fi
}

assert_file_contains() {
    local desc="$1"
    local path="$2"
    local pattern="$3"
    if grep -q "${pattern}" "${path}" 2>/dev/null; then
        pass_step "${desc}"
    else
        fail_step "${desc} — pattern '${pattern}' not found in ${path}"
    fi
}

assert_file_mode() {
    local desc="$1"
    local path="$2"
    local expected="$3"
    local actual
    actual=$(stat -c '%a' "${path}" 2>/dev/null || stat -f '%Lp' "${path}" 2>/dev/null)
    if [ "${actual}" = "${expected}" ]; then
        pass_step "${desc}"
    else
        fail_step "${desc} — expected mode ${expected}, got ${actual}"
    fi
}

assert_pip_package_installed() {
    local desc="$1"
    local package="$2"
    local pip_cmd="${3:-pip3}"
    if ${pip_cmd} list 2>/dev/null | grep -qi "^${package} "; then
        pass_step "${desc}"
    else
        fail_step "${desc} — ${package} not found in pip list"
    fi
}

assert_pip_package_accessible() {
    # Verify that a package is visible on the configured index (auth works)
    # without downloading the full package. Probes the Artifactory simple
    # index URL directly via HTTP — a 200 means auth + access are OK.
    # Uses NDS_ARTIFACTORY_USER/TOKEN env vars for auth to avoid URL-encoding
    # issues (usernames may contain @).
    local desc="$1"
    local package="$2"
    local probe_url="https://artifactory.nds-association.org/artifactory/api/pypi/tooling-pypi/simple/${package}/"
    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" \
        -u "${NDS_ARTIFACTORY_USER}:${NDS_ARTIFACTORY_TOKEN}" \
        "${probe_url}" 2>&1) || true
    if [ "${http_code}" = "200" ]; then
        pass_step "${desc}"
    else
        fail_step "${desc} — HTTP ${http_code} from index"
    fi
}

assert_pypi_package_accessible() {
    # Verify that a package is visible on public PyPI (no auth needed).
    local desc="$1"
    local package="$2"
    local probe_url="https://pypi.org/simple/${package}/"
    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" \
        "${probe_url}" 2>&1) || true
    if [ "${http_code}" = "200" ]; then
        pass_step "${desc}"
    else
        fail_step "${desc} — HTTP ${http_code} from PyPI"
    fi
}

assert_pip_download_starts() {
    # Start a real pip download, verify it begins, then abort early.
    # Passes if: download starts (output matches), times out (exit 124),
    # or completes (exit 0).
    local desc="$1"
    local package="$2"
    local tmpdir
    tmpdir=$(mktemp -d)
    local output rc
    output=$(timeout 15 pip download --no-deps --no-cache-dir -d "${tmpdir}" "${package}" 2>&1) && rc=$? || rc=$?
    rm -rf "${tmpdir}"
    if [ "${rc}" -eq 0 ] || [ "${rc}" -eq 124 ]; then
        pass_step "${desc}"
    elif echo "${output}" | grep -qiE "Downloading|Downloaded"; then
        pass_step "${desc}"
    else
        fail_step "${desc} (exit ${rc})"
        echo "  Output was: ${output}" >&2
    fi
}

assert_docker_pull_starts() {
    # Start a real docker pull, verify it begins, then abort early.
    # Passes if: pull starts (output matches), times out (exit 124),
    # or completes (exit 0).
    local desc="$1"
    local image="$2"
    local output rc
    output=$(timeout 15 docker pull "${image}" 2>&1) && rc=$? || rc=$?
    # Best-effort cleanup — ignore errors (image may not have fully pulled)
    docker rmi "${image}" > /dev/null 2>&1 || true
    if [ "${rc}" -eq 0 ] || [ "${rc}" -eq 124 ]; then
        pass_step "${desc}"
    elif echo "${output}" | grep -qiE "Pulling|Download|already exists"; then
        pass_step "${desc}"
    else
        fail_step "${desc} (exit ${rc})"
        echo "  Output was: ${output}" >&2
    fi
}

assert_docker_logged_in() {
    local desc="$1"
    local registry_fragment="$2"
    local docker_config="${HOME}/.docker/config.json"
    if [ -f "${docker_config}" ] && grep -q "${registry_fragment}" "${docker_config}"; then
        pass_step "${desc}"
    else
        fail_step "${desc} — ${registry_fragment} not found in ${docker_config}"
    fi
}

# --- Cleanup ---

clean_state() {
    rm -rf "${HOME}/.nds"
    rm -rf "${HOME}/.config/pip"
    rm -rf "${HOME}/.docker"
}
