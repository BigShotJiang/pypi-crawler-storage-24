#!/usr/bin/env bash
# Scenario 1: Fresh install without Docker CLI.
#
# Verifies that ndslive-setup works when Docker is not installed:
# - Auth succeeds with pre-created identity token
# - Docker-unavailable warning is shown
# - pip.conf is configured with correct permissions
# - NDS packages are accessible on the index (auth works)
# - doctor/status report correct state
# - reset --all cleans up properly
#
# Note: Keycloak SSO prevents API-based token generation. All auth flows
# require a pre-created identity token (via Artifactory web UI).
#
# Requires: NDS_ARTIFACTORY_USER, NDS_ARTIFACTORY_TOKEN env vars

source "$(dirname "$0")/_lib.sh"

scenario "Fresh install — no Docker"

if [ -z "${NDS_ARTIFACTORY_USER:-}" ] || [ -z "${NDS_ARTIFACTORY_TOKEN:-}" ]; then
    echo "ERROR: NDS_ARTIFACTORY_USER and NDS_ARTIFACTORY_TOKEN must be set" >&2
    exit 2
fi

# --- Setup ---
step "Clean slate"
clean_state

# --- Auth ---
step "Run auth (non-interactive)"
auth_output=$(ndslive-setup auth 2>&1) || true
echo "${auth_output}"

assert_output_contains \
    "Auth warns Docker not installed" \
    "docker not installed" \
    echo "${auth_output}"

assert_output_contains \
    "Auth reports credentials configured" \
    "credentials configured" \
    echo "${auth_output}"

# --- Verify pip.conf ---
step "Verify pip configuration"
pip_conf="${HOME}/.config/pip/pip.conf"

assert_file_exists "pip.conf created" "${pip_conf}"
assert_file_contains "pip.conf has NDS index" "${pip_conf}" "artifactory.nds-association.org"
assert_file_contains "pip.conf has extra-index-url" "${pip_conf}" "pypi.org/simple"
assert_file_mode "pip.conf permissions are 600" "${pip_conf}" "600"

# --- Verify setup.json ---
step "Verify setup state"
setup_json="${HOME}/.nds/setup.json"

assert_file_exists "setup.json created" "${setup_json}"
assert_file_contains "setup.json has username" "${setup_json}" "${NDS_ARTIFACTORY_USER}"
assert_file_contains "setup.json has pip_configured" "${setup_json}" "pip_configured.*true"

# --- Verify package access (lightweight — no full download) ---
step "Verify NDS package index access"
assert_pip_package_accessible "ndslive is accessible on private index" "ndslive"
assert_pypi_package_accessible "nds-mapviewer is accessible on PyPI" "nds-mapviewer"

# --- Doctor ---
step "Run doctor"
doctor_output=$(ndslive-setup doctor 2>&1) || true
echo "${doctor_output}"

assert_output_contains \
    "Doctor shows Python OK" \
    "python" \
    echo "${doctor_output}"

assert_output_contains \
    "Doctor shows pip configured" \
    "configured" \
    echo "${doctor_output}"

assert_output_contains \
    "Doctor reports Docker not installed" \
    "not installed" \
    echo "${doctor_output}"

# --- Status ---
step "Run status"
assert_exit_zero "status command succeeds" ndslive-setup status

# --- Pre-existing pip.conf preservation ---
step "Verify pre-existing pip.conf is preserved on re-auth"
# Reset, seed a custom pip.conf, then re-run auth
echo "y" | ndslive-setup reset --all
mkdir -p "${HOME}/.config/pip"
cat > "${pip_conf}" <<'PIPEOF'
[global]
index-url = https://corporate.example.com/simple
PIPEOF

auth_output2=$(ndslive-setup auth 2>&1) || true
assert_file_contains \
    "Pre-existing index-url preserved" \
    "${pip_conf}" "corporate.example.com"
assert_file_contains \
    "NDS added to extra-index-url" \
    "${pip_conf}" "artifactory.nds-association.org"
assert_file_contains \
    "PyPI added to extra-index-url" \
    "${pip_conf}" "pypi.org/simple"

# --- Reset ---
step "Reset all"
echo "y" | ndslive-setup reset --all

assert_file_not_exists "setup.json removed" "${setup_json}"
# pip.conf should be restored from backup or removed
if [ -f "${pip_conf}" ]; then
    # If restored from backup, NDS entries should be gone
    if grep -q "artifactory.nds-association.org" "${pip_conf}" 2>/dev/null; then
        fail_step "pip.conf still contains NDS entries after reset"
    else
        pass_step "pip.conf cleaned of NDS entries"
    fi
else
    pass_step "pip.conf removed after reset"
fi

summary
