#!/usr/bin/env bash
# Scenario 3: Fresh install with proxy (Squid) and Docker (DinD).
#
# Verifies the proxy flow:
# - Auth succeeds through the proxy with pre-created identity token
# - pip.conf includes proxy setting
# - setup.json stores proxy config
# - NDS packages are accessible through the proxy
# - doctor shows proxy section
#
# Note: Keycloak SSO prevents API-based token generation. All auth flows
# require a pre-created identity token (via Artifactory web UI).
#
# Requires: NDS_ARTIFACTORY_USER, NDS_ARTIFACTORY_TOKEN env vars,
#           DOCKER_HOST, squid at squid:3128

source "$(dirname "$0")/_lib.sh"

scenario "Fresh install — with proxy"

if [ -z "${NDS_ARTIFACTORY_USER:-}" ] || [ -z "${NDS_ARTIFACTORY_TOKEN:-}" ]; then
    echo "ERROR: NDS_ARTIFACTORY_USER and NDS_ARTIFACTORY_TOKEN must be set" >&2
    exit 2
fi

PROXY_URL="http://squid:3128"

# --- Verify proxy is reachable ---
step "Verify Squid proxy reachable"
assert_exit_zero "curl through proxy succeeds" \
    curl -s -o /dev/null -w "%{http_code}" --proxy "${PROXY_URL}" https://pypi.org/simple/

# --- Setup ---
step "Clean slate"
clean_state

# --- Auth with proxy ---
step "Run auth with --proxy (non-interactive)"
auth_output=$(ndslive-setup --proxy "${PROXY_URL}" auth 2>&1) || true
echo "${auth_output}"

assert_output_contains \
    "Auth reports credentials configured" \
    "credentials configured" \
    echo "${auth_output}"

# --- Verify pip.conf has proxy ---
step "Verify pip configuration includes proxy"
pip_conf="${HOME}/.config/pip/pip.conf"

assert_file_exists "pip.conf created" "${pip_conf}"
assert_file_contains "pip.conf has NDS index" "${pip_conf}" "artifactory.nds-association.org"
assert_file_contains "pip.conf has proxy" "${pip_conf}" "proxy.*squid:3128"
assert_file_mode "pip.conf permissions are 600" "${pip_conf}" "600"

# --- Verify setup.json has proxy ---
step "Verify proxy stored in config"
setup_json="${HOME}/.nds/setup.json"

assert_file_exists "setup.json created" "${setup_json}"
assert_file_contains "setup.json has proxy config" "${setup_json}" "squid:3128"

# --- Verify package access through proxy (lightweight) ---
step "Verify NDS package index access through proxy"
assert_pip_package_accessible "ndslive is accessible on private index" "ndslive"
assert_pypi_package_accessible "nds-mapviewer is accessible on PyPI" "nds-mapviewer"

# --- Doctor shows proxy ---
step "Run doctor"
doctor_output=$(ndslive-setup doctor 2>&1) || true
echo "${doctor_output}"

assert_output_contains \
    "Doctor shows proxy section" \
    "proxy" \
    echo "${doctor_output}"

assert_output_contains \
    "Doctor shows proxy URL" \
    "squid:3128" \
    echo "${doctor_output}"

# --- Reset ---
step "Reset all"
echo "y" | ndslive-setup reset --all

assert_file_not_exists "setup.json removed" "${setup_json}"

summary
