#!/usr/bin/env bash
# Scenario 2: Fresh install with Docker (via DinD locally, or host Docker in CI).
#
# Verifies the full setup flow:
# - Auth succeeds with pre-created identity token
# - Docker registry login succeeds
# - Edition is auto-detected
# - pip.conf is configured
# - NDS packages are accessible on the index (auth works)
# - doctor/status report everything green
# - reset --all cleans up Docker auth + pip.conf
#
# Note: Keycloak SSO prevents API-based token generation. All auth flows
# require a pre-created identity token (via Artifactory web UI).
#
# Requires: NDS_ARTIFACTORY_USER, NDS_ARTIFACTORY_TOKEN env vars, Docker available

source "$(dirname "$0")/_lib.sh"

scenario "Fresh install — with Docker"

if [ -z "${NDS_ARTIFACTORY_USER:-}" ] || [ -z "${NDS_ARTIFACTORY_TOKEN:-}" ]; then
    echo "ERROR: NDS_ARTIFACTORY_USER and NDS_ARTIFACTORY_TOKEN must be set" >&2
    exit 2
fi

# --- Verify Docker connectivity ---
step "Verify Docker daemon reachable"
assert_exit_zero "docker info succeeds" docker info

# --- Setup ---
step "Clean slate"
clean_state

# --- Auth ---
step "Run auth (non-interactive)"
auth_output=$(ndslive-setup auth 2>&1) || true
echo "${auth_output}"

assert_output_contains \
    "Auth reports Docker login" \
    "docker registry" \
    echo "${auth_output}"

assert_output_contains \
    "Auth reports edition detected" \
    "edition detected" \
    echo "${auth_output}"

assert_output_contains \
    "Auth reports credentials configured" \
    "credentials configured" \
    echo "${auth_output}"

# --- Verify Docker auth ---
step "Verify Docker registry login"
assert_docker_logged_in \
    "Docker config has NDS registry" \
    "artifactory.nds-association.org"

# --- Verify pip.conf ---
step "Verify pip configuration"
pip_conf="${HOME}/.config/pip/pip.conf"

assert_file_exists "pip.conf created" "${pip_conf}"
assert_file_contains "pip.conf has NDS index" "${pip_conf}" "artifactory.nds-association.org"
assert_file_mode "pip.conf permissions are 600" "${pip_conf}" "600"

# --- Verify setup.json ---
step "Verify setup state"
setup_json="${HOME}/.nds/setup.json"

assert_file_exists "setup.json created" "${setup_json}"
assert_file_contains "setup.json has docker_logged_in" "${setup_json}" "docker_logged_in.*true"

# --- Verify package access (lightweight — no full download) ---
step "Verify NDS package index access"
assert_pip_package_accessible "ndslive is accessible on private index" "ndslive"
assert_pypi_package_accessible "nds-mapviewer is accessible on PyPI" "nds-mapviewer"

# --- Teaser downloads (start, verify pulling works, abort early) ---
step "Teaser: verify artifact downloads start"
assert_pip_download_starts "pip download ndslive starts" "ndslive"
assert_docker_pull_starts "docker pull nds-mapviewer (community)" \
    "artifactory.nds-association.org/ndslive-dockerreg/nds-mapviewer:latest-amd64"
assert_docker_pull_starts "docker pull nds-mapviewer (tooling)" \
    "artifactory.nds-association.org/tooling-dockerreg/nds-mapviewer:latest-amd64"

# --- Doctor ---
step "Run doctor"
doctor_output=$(ndslive-setup doctor 2>&1) || true
echo "${doctor_output}"

assert_output_contains \
    "Doctor shows Docker OK" \
    "docker" \
    echo "${doctor_output}"

assert_output_contains \
    "Doctor shows Docker registry logged in" \
    "logged in" \
    echo "${doctor_output}"

# --- Status ---
step "Run status"
assert_exit_zero "status command succeeds" ndslive-setup status

# --- Reset ---
step "Reset all"
echo "y" | ndslive-setup reset --all

assert_file_not_exists "setup.json removed" "${setup_json}"

# Docker auth should be cleared
docker_config="${HOME}/.docker/config.json"
if [ -f "${docker_config}" ] && grep -q "artifactory.nds-association.org" "${docker_config}" 2>/dev/null; then
    fail_step "Docker config still has NDS registry after reset"
else
    pass_step "Docker registry auth cleared after reset"
fi

summary
