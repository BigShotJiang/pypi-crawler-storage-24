#!/usr/bin/env bash
# E2E test runner for ndslive-setup.
#
# Usage:
#   ./e2e/run.sh                  # Run all scenarios in Docker (local)
#   ./e2e/run.sh 01               # Run scenario 01 only
#   ./e2e/run.sh 01 02            # Run scenarios 01 and 02
#   ./e2e/run.sh --direct 01      # Run scenario 01 directly (no Docker, for CI)
#
# Credentials are read from env vars (NDS_ARTIFACTORY_USER, NDS_ARTIFACTORY_TOKEN)
# or from e2e/.env file.
#
# Note: Keycloak SSO prevents API-based token generation. The token must be
# a pre-created Artifactory identity token.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

# --- Parse flags ---
DIRECT=false
if [ "${1:-}" = "--direct" ]; then
    DIRECT=true
    shift
fi

# --- Load credentials ---
if [ -z "${NDS_ARTIFACTORY_USER:-}" ] && [ -f "${SCRIPT_DIR}/.env" ]; then
    set -a
    source "${SCRIPT_DIR}/.env"
    set +a
fi

if [ -z "${NDS_ARTIFACTORY_USER:-}" ] || [ -z "${NDS_ARTIFACTORY_TOKEN:-}" ]; then
    echo "ERROR: NDS_ARTIFACTORY_USER and NDS_ARTIFACTORY_TOKEN must be set."
    echo "Either export them or create e2e/.env (see e2e/.env.example)"
    exit 2
fi

export NDS_ARTIFACTORY_USER NDS_ARTIFACTORY_TOKEN

# --- Determine which scenarios to run ---
SCENARIOS=("$@")
if [ ${#SCENARIOS[@]} -eq 0 ]; then
    if [ "${DIRECT}" = "true" ]; then
        # In direct mode, skip proxy scenario (needs Squid container)
        SCENARIOS=(01 02)
    else
        SCENARIOS=(01 02 03)
    fi
fi

TOTAL_PASS=0
TOTAL_FAIL=0

run_scenario_direct() {
    local num="$1"
    local script
    script=$(ls "${SCRIPT_DIR}/scenarios/${num}"-*.sh 2>/dev/null | head -1)

    if [ -z "${script}" ]; then
        echo "ERROR: No scenario matching '${num}' found"
        return 1
    fi

    local name
    name=$(basename "${script}" .sh)
    echo ""
    echo "========================================"
    echo " Running (direct): ${name}"
    echo "========================================"

    local exit_code=0
    bash "${script}" || exit_code=$?

    if [ "${exit_code}" -eq 0 ]; then
        TOTAL_PASS=$((TOTAL_PASS + 1))
        echo "  >> ${name}: PASSED"
    else
        TOTAL_FAIL=$((TOTAL_FAIL + 1))
        echo "  >> ${name}: FAILED"
    fi

    return "${exit_code}"
}

run_scenario_docker() {
    local num="$1"
    local script
    script=$(ls "${SCRIPT_DIR}/scenarios/${num}"-*.sh 2>/dev/null | head -1)

    if [ -z "${script}" ]; then
        echo "ERROR: No scenario matching '${num}' found"
        return 1
    fi

    local name
    name=$(basename "${script}" .sh)
    echo ""
    echo "========================================"
    echo " Running (Docker): ${name}"
    echo "========================================"

    local profile service
    case "${num}" in
        01)
            profile="no-docker"
            service="test-no-docker"
            ;;
        02)
            profile="docker"
            service="test"
            ;;
        03)
            profile="proxy"
            service="test"
            ;;
        *)
            echo "ERROR: Unknown scenario number '${num}'"
            return 1
            ;;
    esac

    # Build and start the required services
    docker compose -f "${SCRIPT_DIR}/docker-compose.yml" \
        --profile "${profile}" \
        build "${service}"

    docker compose -f "${SCRIPT_DIR}/docker-compose.yml" \
        --profile "${profile}" \
        up -d --wait

    # Run the scenario inside the test container
    local exit_code=0
    docker compose -f "${SCRIPT_DIR}/docker-compose.yml" \
        --profile "${profile}" \
        exec -T "${service}" \
        bash "/opt/e2e/scenarios/$(basename "${script}")" \
        || exit_code=$?

    # Tear down
    docker compose -f "${SCRIPT_DIR}/docker-compose.yml" \
        --profile "${profile}" \
        down -v

    if [ "${exit_code}" -eq 0 ]; then
        TOTAL_PASS=$((TOTAL_PASS + 1))
        echo "  >> ${name}: PASSED"
    else
        TOTAL_FAIL=$((TOTAL_FAIL + 1))
        echo "  >> ${name}: FAILED"
    fi

    return "${exit_code}"
}

# --- Run scenarios ---
FAILED_SCENARIOS=()

for num in "${SCENARIOS[@]}"; do
    if [ "${DIRECT}" = "true" ]; then
        run_fn=run_scenario_direct
    else
        run_fn=run_scenario_docker
    fi
    if ! ${run_fn} "${num}"; then
        FAILED_SCENARIOS+=("${num}")
    fi
done

# --- Summary ---
echo ""
echo "========================================"
echo " E2E Summary"
echo "========================================"
echo "  Passed: ${TOTAL_PASS}"
echo "  Failed: ${TOTAL_FAIL}"

if [ ${#FAILED_SCENARIOS[@]} -gt 0 ]; then
    echo "  Failed scenarios: ${FAILED_SCENARIOS[*]}"
    exit 1
fi

echo ""
echo "All scenarios passed."
