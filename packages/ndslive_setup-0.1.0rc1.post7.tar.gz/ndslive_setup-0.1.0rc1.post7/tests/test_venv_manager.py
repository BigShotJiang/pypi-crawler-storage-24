"""Tests for venv manager module."""

import json
import subprocess

import pytest

from ndslive.setup.venv_manager import (
    create_venv,
    detect_active_venv,
    detect_existing_venv,
    get_pip_executable,
    install_package,
    list_installed_packages,
)


class TestDetectActiveVenv:
    def test_detects_active_venv(self, tmp_path, monkeypatch):
        venv_dir = tmp_path / "myvenv"
        venv_dir.mkdir()
        monkeypatch.setenv("VIRTUAL_ENV", str(venv_dir))
        result = detect_active_venv()
        assert result == venv_dir

    def test_returns_none_when_not_set(self, monkeypatch):
        monkeypatch.delenv("VIRTUAL_ENV", raising=False)
        assert detect_active_venv() is None

    def test_returns_none_when_dir_missing(self, monkeypatch):
        monkeypatch.setenv("VIRTUAL_ENV", "/nonexistent/path")
        assert detect_active_venv() is None


class TestDetectExistingVenv:
    def test_detects_existing(self, tmp_path):
        (tmp_path / "pyvenv.cfg").touch()
        assert detect_existing_venv(tmp_path) is True

    def test_returns_false_when_missing(self, tmp_path):
        assert detect_existing_venv(tmp_path) is False


class TestListInstalledPackages:
    def test_returns_packages(self, mocker):
        packages = [
            {"name": "ndslive", "version": "1.0.0"},
            {"name": "pip", "version": "24.0"},
        ]
        mocker.patch(
            "subprocess.run",
            return_value=mocker.MagicMock(
                returncode=0, stdout=json.dumps(packages),
            ),
        )
        result = list_installed_packages()
        assert result["ndslive"] == "1.0.0"
        assert result["pip"] == "24.0"

    def test_returns_empty_on_failure(self, mocker):
        mocker.patch(
            "subprocess.run",
            return_value=mocker.MagicMock(returncode=1, stdout=""),
        )
        assert list_installed_packages() == {}

    def test_returns_empty_on_timeout(self, mocker):
        mocker.patch(
            "subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="pip", timeout=30),
        )
        assert list_installed_packages() == {}

    def test_uses_venv_pip(self, tmp_path, mocker):
        pip_bin = tmp_path / "bin" / "pip"
        pip_bin.parent.mkdir()
        pip_bin.touch()
        mock_run = mocker.patch(
            "subprocess.run",
            return_value=mocker.MagicMock(returncode=0, stdout="[]"),
        )
        list_installed_packages(tmp_path)
        cmd = mock_run.call_args[0][0]
        assert str(pip_bin) in cmd


class TestCreateVenv:
    def test_success(self, tmp_path, mocker):
        mocker.patch("venv.create")
        venv_path = tmp_path / "test-venv"
        ok, msg = create_venv(venv_path)
        assert ok is True
        assert str(venv_path) in msg

    def test_failure(self, tmp_path, mocker):
        mocker.patch("venv.create", side_effect=OSError("disk full"))
        ok, msg = create_venv(tmp_path / "venv")
        assert ok is False
        assert "disk full" in msg


class TestGetPipExecutable:
    def test_finds_bin_pip(self, tmp_path):
        pip_bin = tmp_path / "bin" / "pip"
        pip_bin.parent.mkdir()
        pip_bin.touch()
        result = get_pip_executable(tmp_path)
        assert result == [str(pip_bin)]

    def test_finds_scripts_pip(self, tmp_path):
        pip_win = tmp_path / "Scripts" / "pip.exe"
        pip_win.parent.mkdir()
        pip_win.touch()
        result = get_pip_executable(tmp_path)
        assert result == [str(pip_win)]

    def test_falls_back_to_python_m_pip(self, tmp_path):
        python_bin = tmp_path / "bin" / "python"
        python_bin.parent.mkdir()
        python_bin.touch()
        result = get_pip_executable(tmp_path)
        assert result == [str(python_bin), "-m", "pip"]

    def test_falls_back_to_system_python(self, tmp_path):
        result = get_pip_executable(tmp_path)
        assert "-m" in result
        assert "pip" in result


class TestInstallPackage:
    def test_success(self, mocker):
        mocker.patch(
            "subprocess.run",
            return_value=mocker.MagicMock(returncode=0, stderr=""),
        )
        ok, msg = install_package("some-package")
        assert ok is True
        assert "some-package" in msg

    def test_failure(self, mocker):
        mocker.patch(
            "subprocess.run",
            return_value=mocker.MagicMock(
                returncode=1, stderr="No matching distribution",
            ),
        )
        ok, msg = install_package("nonexistent")
        assert ok is False
        assert "No matching" in msg

    def test_timeout(self, mocker):
        mocker.patch(
            "subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="pip", timeout=300),
        )
        ok, msg = install_package("slow-package")
        assert ok is False
        assert "timed out" in msg

    def test_uses_venv_pip(self, tmp_path, mocker):
        pip_bin = tmp_path / "bin" / "pip"
        pip_bin.parent.mkdir()
        pip_bin.touch()
        mock_run = mocker.patch(
            "subprocess.run",
            return_value=mocker.MagicMock(returncode=0, stderr=""),
        )
        install_package("pkg", venv_path=tmp_path)
        cmd = mock_run.call_args[0][0]
        assert str(pip_bin) in cmd
