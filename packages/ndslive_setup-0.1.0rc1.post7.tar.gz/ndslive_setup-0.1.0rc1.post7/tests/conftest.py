"""Shared test fixtures for ndslive-setup."""

import json
from pathlib import Path

import pytest


@pytest.fixture()
def mock_config_dir(tmp_path, monkeypatch):
    """Redirect CONFIG_DIR and CONFIG_FILE to tmp_path."""
    config_dir = tmp_path / ".nds"
    config_dir.mkdir()
    monkeypatch.setattr("ndslive.setup.constants.CONFIG_DIR", config_dir)
    monkeypatch.setattr("ndslive.setup.config.CONFIG_DIR", config_dir)
    monkeypatch.setattr("ndslive.setup.config.CONFIG_FILE", config_dir / "setup.json")
    monkeypatch.setattr("ndslive.setup.log.CONFIG_DIR", config_dir)
    monkeypatch.setattr("ndslive.setup.log.LOG_FILE", config_dir / "setup.log")
    return config_dir


@pytest.fixture()
def mock_pip_conf(tmp_path, monkeypatch):
    """Redirect pip.conf to a temp location."""
    pip_conf = tmp_path / "pip" / "pip.conf"
    monkeypatch.setattr(
        "ndslive.setup.python_index.get_pip_conf_path",
        lambda: pip_conf,
    )
    return pip_conf


@pytest.fixture()
def mock_docker_config(tmp_path, monkeypatch):
    """Provide a mock ~/.docker/config.json."""
    docker_dir = tmp_path / ".docker"
    docker_dir.mkdir()
    config_path = docker_dir / "config.json"

    def _write(data):
        config_path.write_text(json.dumps(data))

    monkeypatch.setattr(
        "ndslive.setup.docker_registry.Path.home",
        lambda: tmp_path,
    )
    return _write
