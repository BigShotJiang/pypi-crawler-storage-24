"""Tests for the logging module."""

import logging

from ndslive.setup.log import (
    SecretMaskingFilter,
    register_secret,
    setup_logging,
    get_logger,
    _secrets,
)


class TestSecretMaskingFilter:
    def setup_method(self):
        _secrets.clear()

    def teardown_method(self):
        _secrets.clear()

    def test_masks_registered_secret(self):
        register_secret("my-super-secret-token")
        f = SecretMaskingFilter()
        record = logging.LogRecord(
            "test", logging.INFO, "", 0,
            "Token is my-super-secret-token here", (), None,
        )
        f.filter(record)
        assert "my-super-secret-token" not in record.msg
        assert "***" in record.msg

    def test_masks_url_credentials(self):
        f = SecretMaskingFilter()
        record = logging.LogRecord(
            "test", logging.INFO, "", 0,
            "Connecting to https://user:pass@host.com/path", (), None,
        )
        f.filter(record)
        assert "user:pass" not in record.msg
        assert "***:***@" in record.msg

    def test_empty_secret_not_registered(self):
        register_secret("")
        assert "" not in _secrets

    def test_multiple_secrets_masked(self):
        register_secret("secret1")
        register_secret("secret2")
        f = SecretMaskingFilter()
        record = logging.LogRecord(
            "test", logging.INFO, "", 0,
            "Values: secret1 and secret2", (), None,
        )
        f.filter(record)
        assert "secret1" not in record.msg
        assert "secret2" not in record.msg


class TestSetupLogging:
    def test_returns_logger(self, mock_config_dir):
        # Clear any existing handlers first
        logger = logging.getLogger("ndslive.setup")
        logger.handlers.clear()
        result = setup_logging()
        assert result.name == "ndslive.setup"
        assert len(result.handlers) >= 1
        # Clean up
        result.handlers.clear()

    def test_verbose_adds_console_handler(self, mock_config_dir):
        logger = logging.getLogger("ndslive.setup")
        logger.handlers.clear()
        result = setup_logging(verbose=True)
        handler_types = [type(h).__name__ for h in result.handlers]
        assert "StreamHandler" in handler_types
        result.handlers.clear()


class TestGetLogger:
    def test_creates_child_logger(self):
        logger = get_logger("mymodule")
        assert logger.name == "ndslive.setup.mymodule"
