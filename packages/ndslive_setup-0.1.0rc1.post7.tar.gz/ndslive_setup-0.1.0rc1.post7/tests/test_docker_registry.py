"""Tests for Docker registry module."""

import json

import pytest

from ndslive.setup.docker_registry import (
    check_docker_proxy_config,
    get_registry,
    is_logged_in,
    login,
    logout,
)


class TestGetRegistry:
    def test_community(self):
        reg = get_registry("community")
        assert "ndslive-dockerreg" in reg

    def test_member(self):
        reg = get_registry("member")
        assert "tooling-dockerreg" in reg


class TestIsLoggedIn:
    def test_no_docker_config(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "ndslive.setup.docker_registry.Path.home", lambda: tmp_path,
        )
        assert is_logged_in("community") is False

    def test_logged_in_via_auths(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "ndslive.setup.docker_registry.Path.home", lambda: tmp_path,
        )
        docker_dir = tmp_path / ".docker"
        docker_dir.mkdir()
        host = "artifactory.nds-association.org"
        (docker_dir / "config.json").write_text(json.dumps({
            "auths": {
                host: {"auth": "base64encoded"},
            },
        }))
        assert is_logged_in("community") is True

    def test_logged_in_via_cred_helpers(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "ndslive.setup.docker_registry.Path.home", lambda: tmp_path,
        )
        docker_dir = tmp_path / ".docker"
        docker_dir.mkdir()
        host = "artifactory.nds-association.org"
        (docker_dir / "config.json").write_text(json.dumps({
            "credHelpers": {host: "osxkeychain"},
        }))
        assert is_logged_in("community") is True

    def test_logged_in_via_creds_store(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "ndslive.setup.docker_registry.Path.home", lambda: tmp_path,
        )
        docker_dir = tmp_path / ".docker"
        docker_dir.mkdir()
        (docker_dir / "config.json").write_text(json.dumps({
            "credsStore": "osxkeychain",
        }))
        assert is_logged_in("community") is True

    def test_not_logged_in_empty_auths(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "ndslive.setup.docker_registry.Path.home", lambda: tmp_path,
        )
        docker_dir = tmp_path / ".docker"
        docker_dir.mkdir()
        (docker_dir / "config.json").write_text(json.dumps({"auths": {}}))
        assert is_logged_in("community") is False

    def test_corrupt_config(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "ndslive.setup.docker_registry.Path.home", lambda: tmp_path,
        )
        docker_dir = tmp_path / ".docker"
        docker_dir.mkdir()
        (docker_dir / "config.json").write_text("not json")
        assert is_logged_in("community") is False


class TestLogin:
    def test_success(self, mocker):
        mocker.patch("subprocess.run", return_value=mocker.MagicMock(
            returncode=0, stdout="Login Succeeded\n", stderr="",
        ))
        ok, msg = login("community", "user", "token")
        assert ok is True
        assert "Succeeded" in msg

    def test_failure(self, mocker):
        mocker.patch("subprocess.run", return_value=mocker.MagicMock(
            returncode=1, stdout="", stderr="invalid credentials",
        ))
        ok, msg = login("community", "user", "bad")
        assert ok is False
        assert "invalid credentials" in msg

    def test_docker_not_installed(self, mocker):
        mocker.patch("subprocess.run", side_effect=FileNotFoundError)
        ok, msg = login("community", "user", "token")
        assert ok is False
        assert "not installed" in msg


class TestCheckDockerProxyConfig:
    def test_proxy_configured(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "ndslive.setup.docker_registry.Path.home", lambda: tmp_path,
        )
        docker_dir = tmp_path / ".docker"
        docker_dir.mkdir()
        (docker_dir / "config.json").write_text(json.dumps({
            "proxies": {"default": {"httpProxy": "http://proxy:8080"}},
        }))
        ok, msg = check_docker_proxy_config()
        assert ok is True

    def test_proxy_not_configured(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "ndslive.setup.docker_registry.Path.home", lambda: tmp_path,
        )
        docker_dir = tmp_path / ".docker"
        docker_dir.mkdir()
        (docker_dir / "config.json").write_text(json.dumps({"auths": {}}))
        ok, msg = check_docker_proxy_config()
        assert ok is False

    def test_no_docker_config(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "ndslive.setup.docker_registry.Path.home", lambda: tmp_path,
        )
        ok, msg = check_docker_proxy_config()
        assert ok is False


class TestLogout:
    def test_success(self, mocker):
        mocker.patch(
            "subprocess.run",
            return_value=mocker.MagicMock(returncode=0, stderr=""),
        )
        ok, msg = logout("community")
        assert ok is True

    def test_docker_not_installed(self, mocker):
        mocker.patch("subprocess.run", side_effect=FileNotFoundError())
        ok, msg = logout("community")
        assert ok is True
        assert "not installed" in msg
