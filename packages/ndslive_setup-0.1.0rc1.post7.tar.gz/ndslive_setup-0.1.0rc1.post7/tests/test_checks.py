"""Tests for prerequisite checks."""

import subprocess
import sys

import pytest

from ndslive.setup.checks import (
    CheckResult,
    check_python_version,
    check_pip_available,
    check_venv_available,
    check_docker,
    check_network,
    run_all_checks,
)


class TestCheckPythonVersion:
    def test_current_python_passes(self):
        result = check_python_version()
        assert result.passed is True
        assert result.name == "Python"

    def test_old_python_fails(self, monkeypatch):
        monkeypatch.setattr(sys, "version_info", (3, 9, 0))
        result = check_python_version()
        assert result.passed is False
        assert result.fix_hint is not None


class TestCheckPipAvailable:
    def test_pip_available(self):
        result = check_pip_available()
        assert result.passed is True
        assert result.name == "pip"

    def test_pip_missing(self, mocker):
        mocker.patch(
            "subprocess.run",
            side_effect=FileNotFoundError(),
        )
        result = check_pip_available()
        assert result.passed is False

    def test_pip_timeout(self, mocker):
        mocker.patch(
            "subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="pip", timeout=10),
        )
        result = check_pip_available()
        assert result.passed is False


class TestCheckVenvAvailable:
    def test_venv_available(self):
        result = check_venv_available()
        assert result.passed is True

    def test_venv_missing(self, mocker):
        mocker.patch.dict("sys.modules", {"venv": None})
        import importlib
        mocker.patch("builtins.__import__", side_effect=ImportError("no venv"))
        result = check_venv_available()
        assert result.passed is False
        assert result.warning is True


class TestCheckDocker:
    def test_docker_not_installed(self, mocker):
        mocker.patch("shutil.which", return_value=None)
        result = check_docker()
        assert result.passed is False
        assert result.warning is True
        assert "not installed" in result.message

    def test_docker_not_running(self, mocker):
        mocker.patch("shutil.which", return_value="/usr/bin/docker")
        mock_docker = mocker.MagicMock()
        mock_docker.from_env.return_value.ping.side_effect = Exception("not running")
        mocker.patch.dict("sys.modules", {"docker": mock_docker})
        result = check_docker()
        assert result.passed is False
        assert "not running" in result.message


class TestCheckNetwork:
    def test_network_reachable(self, mock_config_dir, mocker):
        mock_opener = mocker.MagicMock()
        mocker.patch(
            "ndslive.setup.proxy.get_proxy_opener", return_value=mock_opener,
        )
        mocker.patch(
            "ndslive.setup.proxy.get_proxy_config", return_value=None,
        )
        result = check_network()
        assert result.passed is True
        assert "direct" in result.message

    def test_network_reachable_via_proxy(self, mock_config_dir, mocker):
        mock_opener = mocker.MagicMock()
        mocker.patch(
            "ndslive.setup.proxy.get_proxy_opener", return_value=mock_opener,
        )
        mocker.patch(
            "ndslive.setup.proxy.get_proxy_config",
            return_value={"http": "http://p:8080", "https": "http://p:8080", "no_proxy": ""},
        )
        result = check_network()
        assert result.passed is True
        assert "proxy" in result.message

    def test_network_unreachable(self, mock_config_dir, mocker):
        mock_opener = mocker.MagicMock()
        mock_opener.open.side_effect = OSError("unreachable")
        mocker.patch(
            "ndslive.setup.proxy.get_proxy_opener", return_value=mock_opener,
        )
        mocker.patch(
            "ndslive.setup.proxy.get_proxy_config", return_value=None,
        )
        result = check_network()
        assert result.passed is False
        assert result.fix_hint is not None
        assert "--proxy" in result.fix_hint


class TestRunAllChecks:
    def test_returns_list(self, mocker):
        mocker.patch("socket.create_connection", side_effect=OSError())
        mocker.patch("shutil.which", return_value=None)
        results = run_all_checks()
        assert len(results) == 5
        assert all(isinstance(r, CheckResult) for r in results)
