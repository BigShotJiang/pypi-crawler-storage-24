"""Tests for Python index configuration."""

import configparser
import platform
import stat
import urllib.error

import pytest

from ndslive.setup.python_index import (
    configure_index,
    is_index_configured,
    reset_index,
    verify_index_access,
    get_pip_conf_path,
)


class TestConfigureIndex:
    def test_writes_pip_conf(self, mock_pip_conf):
        path = configure_index("user", "token")
        assert path == mock_pip_conf
        assert mock_pip_conf.exists()
        content = mock_pip_conf.read_text()
        assert "user:token@" in content
        assert "tooling-pypi/simple" in content

    def test_sets_extra_index_url(self, mock_pip_conf):
        configure_index("user", "token")
        config = configparser.ConfigParser()
        config.read(mock_pip_conf)
        assert "pypi.org" in config.get("global", "extra-index-url")

    def test_creates_backup(self, mock_pip_conf):
        mock_pip_conf.parent.mkdir(parents=True, exist_ok=True)
        mock_pip_conf.write_text("[global]\nindex-url = https://old\n")
        configure_index("user", "token")
        backup = mock_pip_conf.with_suffix(mock_pip_conf.suffix + ".bak")
        assert backup.exists()

    def test_no_duplicate_backup(self, mock_pip_conf):
        mock_pip_conf.parent.mkdir(parents=True, exist_ok=True)
        mock_pip_conf.write_text("[global]\nindex-url = https://old\n")
        backup = mock_pip_conf.with_suffix(mock_pip_conf.suffix + ".bak")
        backup.write_text("original backup")
        configure_index("user", "token")
        assert backup.read_text() == "original backup"

    @pytest.mark.skipif(
        platform.system() == "Windows", reason="Unix permissions only",
    )
    def test_sets_0600_permissions(self, mock_pip_conf):
        configure_index("user", "token")
        mode = mock_pip_conf.stat().st_mode
        assert mode & 0o777 == 0o600

    @pytest.mark.skipif(
        platform.system() == "Windows", reason="Unix permissions only",
    )
    def test_sets_0600_on_backup(self, mock_pip_conf):
        mock_pip_conf.parent.mkdir(parents=True, exist_ok=True)
        mock_pip_conf.write_text("[global]\n")
        configure_index("user", "token")
        backup = mock_pip_conf.with_suffix(mock_pip_conf.suffix + ".bak")
        if backup.exists():
            mode = backup.stat().st_mode
            assert mode & 0o777 == 0o600


class TestConfigureIndexPreservation:
    """Verify configure_index preserves pre-existing index-url."""

    def test_preserves_existing_index_url(self, mock_pip_conf):
        mock_pip_conf.parent.mkdir(parents=True, exist_ok=True)
        mock_pip_conf.write_text(
            "[global]\nindex-url = https://corporate.example.com/simple\n",
        )
        configure_index("user", "token")
        config = configparser.ConfigParser()
        config.read(mock_pip_conf)
        # Original index-url kept
        assert config.get("global", "index-url") == "https://corporate.example.com/simple"
        # NDS + PyPI in extra-index-url
        extra = config.get("global", "extra-index-url")
        assert "artifactory.nds-association.org" in extra
        assert "pypi.org/simple" in extra

    def test_fresh_install_sets_nds_as_index_url(self, mock_pip_conf):
        configure_index("user", "token")
        config = configparser.ConfigParser()
        config.read(mock_pip_conf)
        assert "artifactory.nds-association.org" in config.get("global", "index-url")
        assert "pypi.org" in config.get("global", "extra-index-url")

    def test_rerun_deduplicates_extra_index(self, mock_pip_conf):
        mock_pip_conf.parent.mkdir(parents=True, exist_ok=True)
        mock_pip_conf.write_text(
            "[global]\nindex-url = https://corporate.example.com/simple\n",
        )
        configure_index("user", "token-1")
        configure_index("user", "token-2")
        config = configparser.ConfigParser()
        config.read(mock_pip_conf)
        extra = config.get("global", "extra-index-url")
        # Only one NDS entry (with updated token) and one PyPI entry
        lines = [l.strip() for l in extra.splitlines() if l.strip()]
        nds_lines = [l for l in lines if "artifactory.nds-association.org" in l]
        pypi_lines = [l for l in lines if "pypi.org" in l]
        assert len(nds_lines) == 1
        assert len(pypi_lines) == 1
        assert "token-2" in nds_lines[0]

    def test_nds_index_url_gets_updated_in_place(self, mock_pip_conf):
        """When index-url is already NDS, update credentials, keep PyPI extra."""
        configure_index("user", "old-token")
        configure_index("user", "new-token")
        config = configparser.ConfigParser()
        config.read(mock_pip_conf)
        assert "new-token" in config.get("global", "index-url")
        assert "pypi.org" in config.get("global", "extra-index-url")


class TestIsIndexConfigured:
    def test_not_configured_when_no_file(self, mock_pip_conf):
        assert is_index_configured() is False

    def test_configured_when_index_url_has_host(self, mock_pip_conf):
        configure_index("user", "token")
        assert is_index_configured() is True

    def test_not_configured_with_unrelated_config(self, mock_pip_conf):
        mock_pip_conf.parent.mkdir(parents=True, exist_ok=True)
        mock_pip_conf.write_text("[global]\nindex-url = https://other.com/simple\n")
        assert is_index_configured() is False


class TestResetIndex:
    def test_no_file_returns_success(self, mock_pip_conf):
        ok, msg = reset_index()
        assert ok is True

    def test_restores_from_backup(self, mock_pip_conf):
        mock_pip_conf.parent.mkdir(parents=True, exist_ok=True)
        backup = mock_pip_conf.with_suffix(mock_pip_conf.suffix + ".bak")
        backup.write_text("[global]\nindex-url = https://original\n")
        mock_pip_conf.write_text("[global]\nindex-url = https://nds\n")
        ok, msg = reset_index()
        assert ok is True
        assert "backup" in msg.lower()
        assert mock_pip_conf.read_text() == "[global]\nindex-url = https://original\n"
        assert not backup.exists()

    def test_removes_nds_entries(self, mock_pip_conf):
        mock_pip_conf.parent.mkdir(parents=True, exist_ok=True)
        mock_pip_conf.write_text(
            "[global]\n"
            "index-url = https://user:tok@artifactory.nds-association.org/foo\n"
            "extra-index-url = https://pypi.org/simple\n"
            "[other]\nkey = val\n",
        )
        ok, msg = reset_index()
        assert ok is True
        # File should still exist because of [other] section
        assert mock_pip_conf.exists()
        content = mock_pip_conf.read_text()
        assert "nds-association" not in content
        assert "key = val" in content


    def test_reset_removes_nds_from_extra_preserving_others(self, mock_pip_conf):
        """When NDS is in extra-index-url alongside user entries, only NDS is removed."""
        mock_pip_conf.parent.mkdir(parents=True, exist_ok=True)
        mock_pip_conf.write_text(
            "[global]\n"
            "index-url = https://corporate.example.com/simple\n"
            "extra-index-url =\n"
            "\thttps://user:tok@artifactory.nds-association.org/artifactory/api/pypi/tooling-pypi/simple\n"
            "\thttps://pypi.org/simple\n"
            "\thttps://other-mirror.example.com/simple\n",
        )
        ok, msg = reset_index()
        assert ok is True
        config = configparser.ConfigParser()
        config.read(mock_pip_conf)
        # Corporate index-url untouched
        assert config.get("global", "index-url") == "https://corporate.example.com/simple"
        # Only other-mirror remains in extra-index-url
        extra = config.get("global", "extra-index-url")
        assert "other-mirror.example.com" in extra
        assert "nds-association" not in extra
        assert "pypi.org" not in extra


class TestVerifyIndexAccess:
    def test_success(self, mocker):
        mock_resp = mocker.MagicMock()
        mock_resp.status = 200
        mocker.patch("urllib.request.urlopen", return_value=mock_resp)
        ok, msg = verify_index_access("user", "token")
        assert ok is True
        assert "200" in msg

    def test_auth_failed(self, mocker):
        mocker.patch(
            "urllib.request.urlopen",
            side_effect=urllib.error.HTTPError(
                url="", code=401, msg="", hdrs=None, fp=None,
            ),
        )
        ok, msg = verify_index_access("user", "bad-token")
        assert ok is False
        assert "Authentication" in msg

    def test_access_denied(self, mocker):
        mocker.patch(
            "urllib.request.urlopen",
            side_effect=urllib.error.HTTPError(
                url="", code=403, msg="", hdrs=None, fp=None,
            ),
        )
        ok, msg = verify_index_access("user", "token")
        assert ok is False
        assert "denied" in msg

    def test_connection_error(self, mocker):
        mocker.patch(
            "urllib.request.urlopen",
            side_effect=urllib.error.URLError("DNS failed"),
        )
        ok, msg = verify_index_access("user", "token")
        assert ok is False
        assert "Connection" in msg
