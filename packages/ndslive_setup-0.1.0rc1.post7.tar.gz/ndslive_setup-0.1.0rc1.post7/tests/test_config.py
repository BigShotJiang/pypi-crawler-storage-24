"""Tests for config module."""

import json

import pytest

from ndslive.setup.config import (
    load_config,
    save_config,
    get_edition,
    set_edition,
    save_setup_state,
    ensure_config_dir,
)


class TestLoadConfig:
    def test_returns_empty_when_missing(self, mock_config_dir):
        assert load_config() == {}

    def test_loads_valid_json(self, mock_config_dir):
        config_file = mock_config_dir / "setup.json"
        config_file.write_text(json.dumps({"edition": "community"}))
        assert load_config() == {"edition": "community"}

    def test_returns_empty_on_corrupt_json(self, mock_config_dir):
        config_file = mock_config_dir / "setup.json"
        config_file.write_text("{not valid json")
        assert load_config() == {}


class TestSaveConfig:
    def test_creates_file(self, mock_config_dir):
        save_config({"edition": "member"})
        config_file = mock_config_dir / "setup.json"
        assert config_file.exists()
        data = json.loads(config_file.read_text())
        assert data["edition"] == "member"

    def test_round_trip(self, mock_config_dir):
        original = {"edition": "community", "username": "testuser"}
        save_config(original)
        loaded = load_config()
        assert loaded == original


class TestEdition:
    def test_get_edition_none_when_missing(self, mock_config_dir):
        assert get_edition() is None

    def test_set_and_get_edition(self, mock_config_dir):
        set_edition("member")
        assert get_edition() == "member"


class TestSaveSetupState:
    def test_persists_state(self, mock_config_dir):
        save_setup_state(
            edition="community",
            username="testuser",
            docker_logged_in=True,
            pip_configured=True,
        )
        config = load_config()
        assert config["edition"] == "community"
        assert config["username"] == "testuser"
        assert config["docker_logged_in"] is True
        assert config["pip_configured"] is True

    def test_merges_with_existing(self, mock_config_dir):
        save_config({"extra_key": "preserved"})
        save_setup_state(
            edition="community",
            username="user",
            docker_logged_in=False,
            pip_configured=False,
        )
        config = load_config()
        assert config["extra_key"] == "preserved"
        assert config["edition"] == "community"
