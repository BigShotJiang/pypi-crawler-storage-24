"""Tests for proxy module."""

import os
import json

import pytest

from ndslive.setup.proxy import (
    get_proxy_config,
    get_proxy_env,
    get_proxy_opener,
    register_proxy_secrets,
    save_proxy_config,
    save_mirror_config,
)
from ndslive.setup.log import _secrets


class TestGetProxyConfig:
    def test_returns_none_when_no_config(self, mock_config_dir, monkeypatch):
        monkeypatch.delenv("HTTP_PROXY", raising=False)
        monkeypatch.delenv("HTTPS_PROXY", raising=False)
        monkeypatch.delenv("http_proxy", raising=False)
        monkeypatch.delenv("https_proxy", raising=False)
        assert get_proxy_config() is None

    def test_reads_from_setup_json(self, mock_config_dir):
        config_file = mock_config_dir / "setup.json"
        config_file.write_text(json.dumps({
            "proxy": {
                "http": "http://proxy:8080",
                "https": "http://proxy:8080",
                "no_proxy": "localhost",
            },
        }))
        result = get_proxy_config()
        assert result["http"] == "http://proxy:8080"
        assert result["no_proxy"] == "localhost"

    def test_reads_from_env(self, mock_config_dir, monkeypatch):
        monkeypatch.setenv("HTTP_PROXY", "http://envproxy:3128")
        monkeypatch.setenv("HTTPS_PROXY", "http://envproxy:3128")
        result = get_proxy_config()
        assert result["http"] == "http://envproxy:3128"

    def test_setup_json_takes_precedence(self, mock_config_dir, monkeypatch):
        config_file = mock_config_dir / "setup.json"
        config_file.write_text(json.dumps({
            "proxy": {"http": "http://json:8080", "https": "", "no_proxy": ""},
        }))
        monkeypatch.setenv("HTTP_PROXY", "http://env:3128")
        result = get_proxy_config()
        assert result["http"] == "http://json:8080"


class TestGetProxyEnv:
    def test_returns_empty_when_no_proxy(self, mock_config_dir, monkeypatch):
        monkeypatch.delenv("HTTP_PROXY", raising=False)
        monkeypatch.delenv("HTTPS_PROXY", raising=False)
        monkeypatch.delenv("http_proxy", raising=False)
        monkeypatch.delenv("https_proxy", raising=False)
        assert get_proxy_env() == {}

    def test_returns_env_dict(self, mock_config_dir):
        config_file = mock_config_dir / "setup.json"
        config_file.write_text(json.dumps({
            "proxy": {
                "http": "http://p:8080",
                "https": "http://p:8080",
                "no_proxy": "local",
            },
        }))
        env = get_proxy_env()
        assert env["HTTP_PROXY"] == "http://p:8080"
        assert env["http_proxy"] == "http://p:8080"
        assert env["NO_PROXY"] == "local"


class TestGetProxyOpener:
    def test_returns_opener(self, mock_config_dir, monkeypatch):
        monkeypatch.delenv("HTTP_PROXY", raising=False)
        monkeypatch.delenv("HTTPS_PROXY", raising=False)
        monkeypatch.delenv("http_proxy", raising=False)
        monkeypatch.delenv("https_proxy", raising=False)
        import urllib.request
        opener = get_proxy_opener()
        assert isinstance(opener, urllib.request.OpenerDirector)


class TestSaveProxyConfig:
    def test_saves_to_setup_json(self, mock_config_dir):
        save_proxy_config(
            http="http://proxy:8080",
            https="http://proxy:8080",
            no_proxy="localhost",
        )
        config_file = mock_config_dir / "setup.json"
        data = json.loads(config_file.read_text())
        assert data["proxy"]["http"] == "http://proxy:8080"


class TestSaveMirrorConfig:
    def test_saves_mirror_host(self, mock_config_dir):
        save_mirror_config("mirror.corp.com")
        config_file = mock_config_dir / "setup.json"
        data = json.loads(config_file.read_text())
        assert data["mirror"]["artifactory_host"] == "mirror.corp.com"


class TestRegisterProxySecrets:
    def teardown_method(self):
        _secrets.clear()

    def test_registers_userinfo(self, mock_config_dir):
        config_file = mock_config_dir / "setup.json"
        config_file.write_text(json.dumps({
            "proxy": {
                "http": "http://user:s3cret@proxy:8080",
                "https": "",
                "no_proxy": "",
            },
        }))
        registered = set()
        register_proxy_secrets(registered.add)
        assert "user:s3cret" in registered
        assert "s3cret" in registered

    def test_no_secrets_for_unauthenticated(self, mock_config_dir):
        config_file = mock_config_dir / "setup.json"
        config_file.write_text(json.dumps({
            "proxy": {
                "http": "http://proxy:8080",
                "https": "",
                "no_proxy": "",
            },
        }))
        registered = set()
        register_proxy_secrets(registered.add)
        assert len(registered) == 0
