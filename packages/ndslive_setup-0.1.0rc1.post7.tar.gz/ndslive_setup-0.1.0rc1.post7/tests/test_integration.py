"""Integration tests for multi-step setup scenarios.

These tests exercise realistic end-to-end flows through multiple modules,
with only external I/O (network, Docker daemon) mocked. They verify that
the modules interact correctly and state propagates as expected.
"""

import configparser
import platform

import pytest

from ndslive.setup.config import load_config, save_config, save_setup_state
from ndslive.setup.python_index import (
    configure_index,
    is_index_configured,
    reset_index,
    verify_index_access,
)
from ndslive.setup.log import _secrets, register_secret


class TestFreshSetupFlow:
    """Simulate a fresh first-time setup: auth → pip.conf → state."""

    def test_configure_and_verify_pip_index(self, mock_config_dir, mock_pip_conf, mocker):
        """Full pip index flow: configure, verify configured, check file content."""
        # 1. Not configured yet
        assert is_index_configured() is False

        # 2. Configure index
        path = configure_index("alice", "my-token-123")
        assert path == mock_pip_conf
        assert mock_pip_conf.exists()

        # 3. Now detected as configured
        assert is_index_configured() is True

        # 4. File content has correct structure
        config = configparser.ConfigParser()
        config.read(mock_pip_conf)
        index_url = config.get("global", "index-url")
        assert "alice:my-token-123@" in index_url
        assert "tooling-pypi/simple" in index_url
        extra = config.get("global", "extra-index-url")
        assert "pypi.org" in extra

    @pytest.mark.skipif(
        platform.system() == "Windows", reason="Unix permissions only",
    )
    def test_permissions_set_on_pip_conf(self, mock_config_dir, mock_pip_conf):
        configure_index("user", "token")
        mode = mock_pip_conf.stat().st_mode & 0o777
        assert mode == 0o600

    def test_state_persistence_round_trip(self, mock_config_dir):
        """Wizard state survives save/load cycle."""
        save_setup_state(
            edition="member",
            username="bob",
            docker_logged_in=True,
            pip_configured=True,
        )
        config = load_config()
        assert config["edition"] == "member"
        assert config["username"] == "bob"
        assert config["docker_logged_in"] is True
        assert config["pip_configured"] is True


class TestResetFlow:
    """Simulate setup → reset --all: ensure clean removal."""

    def test_reset_restores_pip_backup(self, mock_config_dir, mock_pip_conf):
        """When pip.conf had a backup, reset restores it."""
        # Setup: create original pip.conf, then override with NDS config
        mock_pip_conf.parent.mkdir(parents=True, exist_ok=True)
        mock_pip_conf.write_text("[global]\nindex-url = https://original.com/simple\n")
        configure_index("user", "token")

        # Verify NDS config is in place
        assert is_index_configured() is True

        # Reset
        ok, msg = reset_index()
        assert ok is True

        # Original restored
        content = mock_pip_conf.read_text()
        assert "original.com" in content
        assert "nds-association" not in content

    def test_reset_removes_nds_entries_without_backup(self, mock_config_dir, mock_pip_conf):
        """When no backup exists, remove NDS entries preserving other config."""
        mock_pip_conf.parent.mkdir(parents=True, exist_ok=True)
        mock_pip_conf.write_text(
            "[global]\n"
            "index-url = https://user:tok@artifactory.nds-association.org/foo\n"
            "extra-index-url = https://pypi.org/simple\n"
            "[install]\nno-deps = true\n",
        )
        ok, msg = reset_index()
        assert ok is True
        content = mock_pip_conf.read_text()
        assert "nds-association" not in content
        assert "no-deps" in content

    def test_reset_preserves_mapviewer_configs(self, mock_config_dir):
        """reset --all should NOT touch configs/ directory."""
        configs_dir = mock_config_dir / "configs"
        configs_dir.mkdir()
        (configs_dir / "mapviewer.json").write_text("{}")

        # Simulate what _run_reset does for setup files
        setup_json = mock_config_dir / "setup.json"
        save_config({"edition": "community"})
        assert setup_json.exists()
        setup_json.unlink()

        # configs/ still present
        assert configs_dir.exists()
        assert (configs_dir / "mapviewer.json").exists()


class TestReconfigureFlow:
    """Simulate re-running setup with existing configuration."""

    def test_reconfigure_overwrites_pip_conf(self, mock_config_dir, mock_pip_conf):
        """Re-running configure updates pip.conf with new credentials."""
        configure_index("alice", "old-token")
        configure_index("alice", "new-token")

        config = configparser.ConfigParser()
        config.read(mock_pip_conf)
        index_url = config.get("global", "index-url")
        assert "new-token" in index_url
        assert "old-token" not in index_url

    def test_state_update_preserves_extra_keys(self, mock_config_dir):
        """Re-running setup preserves non-setup keys in config."""
        save_config({"custom_key": "keep_me", "edition": "community"})
        save_setup_state(
            edition="member",
            username="new-user",
            docker_logged_in=True,
            pip_configured=True,
        )
        config = load_config()
        assert config["custom_key"] == "keep_me"
        assert config["edition"] == "member"


class TestSecretMaskingIntegration:
    """Verify secrets are properly masked across modules."""

    def teardown_method(self):
        _secrets.clear()

    def test_register_secret_masks_token(self):
        """register_secret records identity tokens for log masking."""
        register_secret("my-identity-token")
        assert "my-identity-token" in _secrets


class TestEditionDetectionFlow:
    """Test edition detection via Docker registry probing."""

    def test_member_detected_when_both_succeed(self, mocker):
        """Member registry login succeeding → member edition."""
        mocker.patch("subprocess.run", return_value=mocker.MagicMock(
            returncode=0, stdout="Login Succeeded\n", stderr="",
        ))

        from ndslive.setup.docker_registry import login
        ok_member, _ = login("member", "user", "token")
        assert ok_member is True

    def test_community_fallback_when_member_fails(self, mocker):
        """Member login fails, community succeeds → community edition."""
        def side_effect(cmd, **kwargs):
            registry = cmd[-1]
            result = mocker.MagicMock()
            if "tooling-dockerreg" in registry:
                result.returncode = 1
                result.stdout = ""
                result.stderr = "unauthorized"
            else:
                result.returncode = 0
                result.stdout = "Login Succeeded\n"
                result.stderr = ""
            return result

        mocker.patch("subprocess.run", side_effect=side_effect)

        from ndslive.setup.docker_registry import login
        ok_member, _ = login("member", "user", "token")
        assert ok_member is False

        ok_community, _ = login("community", "user", "token")
        assert ok_community is True
