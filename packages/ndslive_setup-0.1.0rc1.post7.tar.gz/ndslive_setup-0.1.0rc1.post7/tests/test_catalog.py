"""Tests for catalog module."""

from ndslive.setup.catalog import TOOLS
from ndslive.setup.constants import EDITIONS


class TestCatalog:
    def test_tools_not_empty(self):
        assert len(TOOLS) > 0

    def test_tools_have_required_keys(self):
        for tid, tool in TOOLS.items():
            assert "package" in tool, f"{tid} missing 'package'"
            assert "description" in tool, f"{tid} missing 'description'"
            assert "editions" in tool, f"{tid} missing 'editions'"

    def test_editions_match_constants(self):
        valid_editions = set(EDITIONS.keys())
        for tid, tool in TOOLS.items():
            for edition in tool["editions"]:
                assert edition in valid_editions, (
                    f"{tid} has unknown edition '{edition}'"
                )

    def test_mapviewer_in_catalog(self):
        assert "mapviewer" in TOOLS
        assert TOOLS["mapviewer"]["package"] == "nds-mapviewer"

    def test_sdk_in_catalog(self):
        assert "sdk" in TOOLS
        assert TOOLS["sdk"]["package"] == "ndslive"
        assert "docker_image" not in TOOLS["sdk"]
