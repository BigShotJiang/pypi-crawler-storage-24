# ndslive-setup

Interactive setup wizard that configures your machine for working with
[NDS.Live](https://nds.live). It handles Artifactory authentication, Docker
registry access, Python package index configuration, and tool installation —
so you can go from a fresh system to a working NDS.Live environment in minutes.

## Installation

```bash
pip install ndslive-setup
```

Requires Python 3.10+.

> If your system Python blocks pip install (common on Debian/Ubuntu and Homebrew),
> create a virtual environment first:
> ```bash
> apt install python3-venv   # Debian/Ubuntu only
> python3 -m venv ~/.nds/venv
> source ~/.nds/venv/bin/activate
> pip install ndslive-setup
> ```
> Learn more about virtual environments: https://docs.python.org/3/library/venv.html

## Quick Start

```bash
ndslive-setup
```

This launches a terminal-based wizard that walks you through every step.

## Wizard Flow

The wizard guides you through six steps:

### 1. Welcome & Edition Selection

Choose your NDS.Live edition:

- **Community** — NDS.Live open tooling
- **Member** — NDS.Live + NDS.Classic tooling (requires NDS Association membership)

The edition determines which Docker registry and package catalog are available
to you.

### 2. Prerequisites

Automated checks verify that your system is ready:

- Python >= 3.10 with pip
- venv module available
- Docker installed and daemon running
- Network connectivity to Artifactory

Docker is optional — if it is not available the wizard skips Docker-related
steps and continues with Python package setup only.

### 3. Artifactory Access

A single Artifactory identity token authenticates both Docker and Python
package access. The wizard:

1. Verifies your credentials against the NDS Artifactory
2. Logs you into the Docker registry (`docker login`)
3. Writes an authenticated `pip.conf` with the NDS package index

If existing configuration is detected you can keep it or re-enter credentials
to reconfigure.

> **Note:** The wizard requires an Artifactory *identity token*, not your SSO
> password. You can generate one under your Artifactory profile at
> `artifactory.nds-association.org`.

### 4. Python Environment

Optionally create a dedicated virtual environment for NDS tools. This keeps NDS
packages isolated from your system Python. The default location is
`~/.nds/venv` but you can choose any path.

### 5. Install Tools

Select which NDS.Live tools to install:

- **Python packages** — installed via pip (into the venv if you created one)
- **Docker images** — pulled from the Artifactory Docker registry

Already-cached Docker images are detected and shown so you can skip
re-downloading them.

### 6. Summary

A recap of everything that was configured, plus next steps like activating your
virtual environment and running your first tool.

## CLI Commands

Beyond the wizard, `ndslive-setup` provides utility commands for day-to-day use:

```bash
ndslive-setup doctor       # Run diagnostics on your current setup
ndslive-setup status       # Show configuration at a glance
ndslive-setup reset        # Remove wizard state (keeps pip.conf and Docker auth)
ndslive-setup reset --all  # Remove all NDS.Live configuration
```

### Doctor

Re-runs all prerequisite checks and inspects your Docker and pip configuration.
Useful after system changes or when something stops working.

### Status

Quick table showing your current edition, Docker registry login state, and
Python index configuration.

## What Gets Configured

| Component | Location | Purpose |
|---|---|---|
| Wizard state | `~/.nds/setup.json` | Remembers edition and username |
| pip config | `~/.config/pip/pip.conf` | Authenticated NDS package index as primary, PyPI as fallback |
| Docker auth | `~/.docker/config.json` | Registry credentials (managed by Docker itself) |
| Virtual env | `~/.nds/venv` (default) | Isolated Python environment for NDS tools |

## Requirements

- Python >= 3.10
- Docker (optional, for container-based tools)
- Network access to `artifactory.nds-association.org`

## License

Apache-2.0
