"""Shared constants for NDS.Live setup."""

from pathlib import Path

ARTIFACTORY_HOST = "artifactory.nds-association.org"
ARTIFACTORY_URL = f"https://{ARTIFACTORY_HOST}"
ARTIFACTORY_PROFILE_URL = (
    f"{ARTIFACTORY_URL}/ui/admin/artifactory/user_profile"
)

DOCKER_REGISTRIES = {
    "community": f"{ARTIFACTORY_HOST}/ndslive-dockerreg",
    "member": f"{ARTIFACTORY_HOST}/tooling-dockerreg",
}

PYTHON_INDEX_URL = (
    f"https://{ARTIFACTORY_HOST}/artifactory/api/pypi/tooling-pypi/simple"
)
PUBLIC_PYPI_URL = "https://pypi.org/simple"

CONFIG_DIR = Path.home() / ".nds"

EDITIONS = {
    "community": {
        "label": "Community",
        "description": "NDS.Live only",
    },
    "member": {
        "label": "Member",
        "description": "NDS.Live + NDS.Classic tooling",
    },
}

MIN_PYTHON_VERSION = (3, 10)

DEVPORTAL_URL = "https://developer.nds.live"
PIP_AUTH_DOCS_URL = "https://pip.pypa.io/en/stable/topics/authentication/"
VENV_DOCS_URL = "https://docs.python.org/3/tutorial/venv.html"
