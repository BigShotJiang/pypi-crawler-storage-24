"""Docker image management for NDS tools."""

from __future__ import annotations

import platform

from .catalog import TOOLS
from .constants import DOCKER_REGISTRIES


def detect_architecture() -> str:
    """Detect system architecture for Docker image tags."""
    machine = platform.machine().lower()
    if machine in ("x86_64", "amd64"):
        return "amd64"
    if machine in ("arm64", "aarch64"):
        return "arm64"
    return machine


def get_image_tag(
    edition: str, image_name: str, version: str = "latest",
) -> str:
    """Get the full Docker image tag including registry and architecture."""
    registry = DOCKER_REGISTRIES[edition]
    arch = detect_architecture()
    return f"{registry}/{image_name}:{version}-{arch}"


def image_exists(
    edition: str, image_name: str, version: str = "latest",
) -> bool:
    """Check if a Docker image is cached locally."""
    tag = get_image_tag(edition, image_name, version)
    try:
        import docker
        client = docker.from_env()
        client.images.get(tag)
        return True
    except Exception:
        return False


def pull_image(
    edition: str,
    image_name: str,
    version: str = "latest",
    progress_callback: callable | None = None,
) -> tuple[bool, str]:
    """Pull a Docker image. Returns (success, message)."""
    tag = get_image_tag(edition, image_name, version)
    try:
        import docker
        client = docker.from_env()
        for chunk in client.api.pull(tag, stream=True, decode=True):
            if progress_callback and "status" in chunk:
                progress_callback(chunk)
        return True, f"Pulled {tag}"
    except Exception as e:
        msg = str(e)
        if hasattr(e, "explanation") and e.explanation:
            msg = e.explanation
        return False, f"Pull failed: {msg}"


def get_available_images(edition: str) -> list[dict]:
    """Get available images for the edition from the catalog."""
    images = []
    for tool_id, tool in TOOLS.items():
        if edition in tool.get("editions", []):
            docker_image = tool.get("docker_image")
            if docker_image:
                images.append({
                    "id": tool_id,
                    "name": tool["package"],
                    "image": docker_image,
                    "description": tool["description"],
                    "cached": image_exists(edition, docker_image),
                })
    return images
