"""Central proxy helper for all network operations."""

from __future__ import annotations

import os
import re
import urllib.request
from urllib.parse import urlparse

from .config import load_config, save_config
from .log import get_logger, register_secret

logger = get_logger("proxy")

_USERINFO_RE = re.compile(r"://([^@/]+)@")


def get_proxy_config() -> dict | None:
    """Get proxy configuration from setup.json or environment variables.

    Returns dict with 'http', 'https', 'no_proxy' keys, or None.
    """
    config = load_config()
    proxy = config.get("proxy")
    if proxy:
        return proxy

    http = os.environ.get("HTTP_PROXY") or os.environ.get("http_proxy")
    https = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
    if http or https:
        return {
            "http": http or "",
            "https": https or "",
            "no_proxy": (
                os.environ.get("NO_PROXY")
                or os.environ.get("no_proxy")
                or ""
            ),
        }

    return None


def get_proxy_opener() -> urllib.request.OpenerDirector:
    """Build an OpenerDirector with proxy support.

    Handles authenticated proxies via URL-embedded credentials.
    """
    proxy_config = get_proxy_config()
    if not proxy_config:
        return urllib.request.build_opener()

    proxies = {}
    if proxy_config.get("http"):
        proxies["http"] = proxy_config["http"]
    if proxy_config.get("https"):
        proxies["https"] = proxy_config["https"]

    handler = urllib.request.ProxyHandler(proxies)
    return urllib.request.build_opener(handler)


def get_proxy_env() -> dict[str, str]:
    """Return env dict for subprocess calls (pip, etc.)."""
    proxy_config = get_proxy_config()
    if not proxy_config:
        return {}

    env = {}
    if proxy_config.get("http"):
        env["HTTP_PROXY"] = proxy_config["http"]
        env["http_proxy"] = proxy_config["http"]
    if proxy_config.get("https"):
        env["HTTPS_PROXY"] = proxy_config["https"]
        env["https_proxy"] = proxy_config["https"]
    if proxy_config.get("no_proxy"):
        env["NO_PROXY"] = proxy_config["no_proxy"]
        env["no_proxy"] = proxy_config["no_proxy"]
    return env


def save_proxy_config(
    http: str = "",
    https: str = "",
    no_proxy: str = "",
) -> None:
    """Persist proxy config to setup.json."""
    config = load_config()
    config["proxy"] = {
        "http": http,
        "https": https,
        "no_proxy": no_proxy,
    }
    save_config(config)
    logger.info("Proxy configuration saved")
    register_proxy_secrets(register_secret)


def save_mirror_config(artifactory_host: str) -> None:
    """Persist mirror host to setup.json."""
    config = load_config()
    config["mirror"] = {"artifactory_host": artifactory_host}
    save_config(config)
    logger.info("Mirror host saved: %s", artifactory_host)


def register_proxy_secrets(register_fn) -> None:
    """Extract userinfo from proxy URLs and register as secrets."""
    proxy_config = get_proxy_config()
    if not proxy_config:
        return
    for key in ("http", "https"):
        url = proxy_config.get(key, "")
        if not url:
            continue
        match = _USERINFO_RE.search(url)
        if match:
            userinfo = match.group(1)
            register_fn(userinfo)
            # Also register just the password part
            if ":" in userinfo:
                register_fn(userinfo.split(":", 1)[1])
