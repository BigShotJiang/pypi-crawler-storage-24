"""Virtual environment management."""

import json
import os
import subprocess
import sys
from pathlib import Path

from .constants import CONFIG_DIR
from .log import get_logger

logger = get_logger("venv_manager")

DEFAULT_VENV_PATH = CONFIG_DIR / "venv"


def detect_active_venv() -> Path | None:
    """Check if a virtual environment is currently active via $VIRTUAL_ENV."""
    venv_env = os.environ.get("VIRTUAL_ENV")
    if venv_env:
        path = Path(venv_env)
        if path.is_dir():
            return path
    return None


def detect_existing_venv(path: Path) -> bool:
    """Check if a venv exists at the given path."""
    pyvenv_cfg = path / "pyvenv.cfg"
    return pyvenv_cfg.exists()


def list_installed_packages(venv_path: Path | None = None) -> dict[str, str]:
    """List installed packages. Returns {name: version}."""
    if venv_path:
        cmd = get_pip_executable(venv_path) + ["list", "--format", "json"]
    else:
        cmd = [sys.executable, "-m", "pip", "list", "--format", "json"]

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=30,
        )
        if result.returncode == 0:
            packages = json.loads(result.stdout)
            return {p["name"].lower(): p["version"] for p in packages}
    except (subprocess.TimeoutExpired, json.JSONDecodeError, KeyError):
        pass
    return {}


def create_venv(path: Path | None = None) -> tuple[bool, str]:
    """Create a virtual environment at the given path."""
    venv_path = path or DEFAULT_VENV_PATH
    logger.info("Creating virtual environment at %s", venv_path)
    try:
        import venv
        venv.create(str(venv_path), with_pip=True)
        logger.info("Virtual environment created at %s", venv_path)
        return True, str(venv_path)
    except Exception as e:
        logger.error("Failed to create venv: %s", e)
        return False, str(e)


def get_pip_executable(venv_path: Path) -> list[str]:
    """Get pip command for a venv."""
    pip_bin = venv_path / "bin" / "pip"
    pip_win = venv_path / "Scripts" / "pip.exe"
    if pip_bin.exists():
        return [str(pip_bin)]
    if pip_win.exists():
        return [str(pip_win)]
    python = venv_path / "bin" / "python"
    if python.exists():
        return [str(python), "-m", "pip"]
    return [sys.executable, "-m", "pip"]


def install_package(
    package: str,
    venv_path: Path | None = None,
) -> tuple[bool, str]:
    """Install a Python package via pip."""
    if venv_path:
        cmd = get_pip_executable(venv_path) + ["install", package]
    else:
        cmd = [sys.executable, "-m", "pip", "install", package]

    logger.info("Installing %s", package)
    logger.debug("Running: %s", " ".join(cmd))

    from .proxy import get_proxy_env
    env = {**os.environ, **get_proxy_env()}

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=300, env=env,
        )
        if result.returncode == 0:
            logger.info("Installed %s", package)
            return True, f"Installed {package}"
        logger.error(
            "pip install %s failed (exit %s): %s",
            package, result.returncode, result.stderr.strip(),
        )
        return False, result.stderr.strip()
    except subprocess.TimeoutExpired:
        logger.error("pip install %s timed out", package)
        return False, "Installation timed out"
    except Exception as e:
        logger.error("pip install %s error: %s", package, e)
        return False, str(e)


def upgrade_package(
    package: str,
    venv_path: Path | None = None,
) -> tuple[bool, str]:
    """Upgrade a Python package via pip. Returns (success, message)."""
    if venv_path:
        cmd = get_pip_executable(venv_path) + ["install", "--upgrade", package]
    else:
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade", package]

    logger.info("Upgrading %s", package)

    from .proxy import get_proxy_env
    env = {**os.environ, **get_proxy_env()}

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=300, env=env,
        )
        if result.returncode == 0:
            logger.info("Upgraded %s", package)
            return True, f"Upgraded {package}"
        logger.error(
            "pip upgrade %s failed (exit %s): %s",
            package, result.returncode, result.stderr.strip(),
        )
        return False, result.stderr.strip()
    except subprocess.TimeoutExpired:
        logger.error("pip upgrade %s timed out", package)
        return False, "Upgrade timed out"
    except Exception as e:
        logger.error("pip upgrade %s error: %s", package, e)
        return False, str(e)
