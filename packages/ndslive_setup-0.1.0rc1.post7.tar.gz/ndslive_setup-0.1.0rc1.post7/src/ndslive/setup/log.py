"""Centralized logging with sensitive data masking."""

from __future__ import annotations

import logging
import re
from logging.handlers import RotatingFileHandler
from pathlib import Path

from .constants import CONFIG_DIR

LOG_FILE = CONFIG_DIR / "setup.log"
LOG_FORMAT = "[%(asctime)s] %(levelname)s — %(message)s"
LOG_DATEFMT = "%H:%M:%S"
LOG_FORMAT_FILE = "[%(asctime)s] %(levelname)s %(name)s — %(message)s"
LOG_DATEFMT_FILE = "%Y-%m-%d %H:%M:%S"

_secrets: set[str] = set()
_tui_handler: TUILogHandler | None = None

# Pattern to match credentials embedded in URLs: ://user:pass@
_URL_CRED_RE = re.compile(r"://[^@/]+:[^@/]+@")


class SecretMaskingFilter(logging.Filter):
    """Replace registered secrets and URL-embedded credentials with ***."""

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        for secret in _secrets:
            if secret and secret in msg:
                msg = msg.replace(secret, "***")
        msg = _URL_CRED_RE.sub("://***:***@", msg)
        record.msg = msg
        record.args = ()
        return True


class TUILogHandler(logging.Handler):
    """Handler that emits log records to a Textual RichLog widget."""

    def __init__(self, widget, call_from_thread):
        super().__init__()
        self._widget = widget
        self._call_from_thread = call_from_thread

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            self._call_from_thread(self._write, msg, record.levelno)
        except Exception:
            self.handleError(record)

    def _write(self, msg: str, levelno: int) -> None:
        style = ""
        if levelno >= logging.ERROR:
            style = "bold red"
        elif levelno >= logging.WARNING:
            style = "yellow"
        elif levelno <= logging.DEBUG:
            style = "dim"
        if style:
            self._widget.write(f"[{style}]{msg}[/{style}]")
        else:
            self._widget.write(msg)


def register_secret(value: str) -> None:
    """Register a value to be masked in all log output."""
    if value:
        _secrets.add(value)


def setup_logging(*, verbose: bool = False) -> logging.Logger:
    """Configure root ndslive.setup logger with file handler.

    Returns the root logger for the package.
    """
    logger = logging.getLogger("ndslive.setup")
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)

    masking = SecretMaskingFilter()

    # File handler — rotating, keeps last 3
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    file_handler = RotatingFileHandler(
        LOG_FILE, maxBytes=0, backupCount=3,
    )
    # Rotate on each setup run
    if LOG_FILE.exists() and LOG_FILE.stat().st_size > 0:
        file_handler.doRollover()
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(
        logging.Formatter(LOG_FORMAT_FILE, datefmt=LOG_DATEFMT_FILE),
    )
    file_handler.addFilter(masking)
    logger.addHandler(file_handler)

    # Console handler for --verbose
    if verbose:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.DEBUG)
        console_handler.setFormatter(
            logging.Formatter(LOG_FORMAT, datefmt=LOG_DATEFMT),
        )
        console_handler.addFilter(masking)
        logger.addHandler(console_handler)

    return logger


def attach_tui_handler(widget, call_from_thread) -> None:
    """Attach a TUI log handler to the ndslive.setup logger."""
    global _tui_handler
    logger = logging.getLogger("ndslive.setup")

    if _tui_handler is not None:
        logger.removeHandler(_tui_handler)

    _tui_handler = TUILogHandler(widget, call_from_thread)
    _tui_handler.setLevel(logging.INFO)
    _tui_handler.setFormatter(
        logging.Formatter(LOG_FORMAT, datefmt=LOG_DATEFMT),
    )
    _tui_handler.addFilter(SecretMaskingFilter())
    logger.addHandler(_tui_handler)


def detach_tui_handler() -> None:
    """Remove TUI handler from the logger."""
    global _tui_handler
    if _tui_handler is not None:
        logger = logging.getLogger("ndslive.setup")
        logger.removeHandler(_tui_handler)
        _tui_handler = None


def get_logger(name: str) -> logging.Logger:
    """Get a child logger under ndslive.setup."""
    return logging.getLogger(f"ndslive.setup.{name}")
