"""Prerequisite checks for NDS.Live setup."""

from dataclasses import dataclass
import platform
import shutil
import socket
import subprocess
import sys

from .constants import ARTIFACTORY_HOST, MIN_PYTHON_VERSION
from .log import get_logger

logger = get_logger("checks")


@dataclass
class CheckResult:
    name: str
    passed: bool
    message: str
    fix_hint: str | None = None
    warning: bool = False


def check_python_version() -> CheckResult:
    version = sys.version_info[:2]
    required = f"{MIN_PYTHON_VERSION[0]}.{MIN_PYTHON_VERSION[1]}"
    current = f"{version[0]}.{version[1]}"
    if version >= MIN_PYTHON_VERSION:
        return CheckResult("Python", True, f"Python {current}")
    return CheckResult(
        "Python", False,
        f"Python {current} (requires >= {required})",
        fix_hint=f"Install Python {required}+ from python.org",
    )


def check_pip_available() -> CheckResult:
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            version = result.stdout.strip().split()[1]
            return CheckResult("pip", True, f"pip {version}")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return CheckResult(
        "pip", False, "not available",
        fix_hint="Install pip: python -m ensurepip --upgrade",
    )


def check_venv_available() -> CheckResult:
    try:
        import venv  # noqa: F401
        return CheckResult("venv module", True, "available")
    except ImportError:
        return CheckResult(
            "venv module", False, "not available",
            fix_hint=(
                "A virtual environment is required for pip install on some systems. "
                "Install venv: apt install python3-venv (Debian/Ubuntu). "
                "See https://docs.python.org/3/library/venv.html"
            ),
            warning=True,
        )


def check_docker() -> CheckResult:
    if shutil.which("docker") is None:
        system = platform.system()
        urls = {
            "Darwin": "https://docs.docker.com/desktop/install/mac-install/",
            "Windows": "https://docs.docker.com/desktop/install/windows-install/",
            "Linux": "https://docs.docker.com/engine/install/",
        }
        return CheckResult(
            "Docker", False, "not installed",
            fix_hint=f"Install Docker: {urls.get(system, urls['Linux'])}",
            warning=True,
        )
    try:
        import docker as docker_lib
        client = docker_lib.from_env()
        client.ping()
        version = client.version().get("Version", "unknown")
        return CheckResult("Docker", True, f"Docker {version}")
    except Exception as e:
        err_str = str(e).lower()
        if "permission" in err_str or "denied" in err_str:
            return CheckResult(
                "Docker", False, "permission denied",
                fix_hint="Add your user to the docker group: sudo usermod -aG docker $USER (then re-login)",
                warning=True,
            )
        system = platform.system()
        hint = (
            "Start Docker Desktop"
            if system in ("Darwin", "Windows")
            else "Start Docker: sudo systemctl start docker"
        )
        return CheckResult(
            "Docker", False, "installed but daemon not running",
            fix_hint=hint,
            warning=True,
        )


def check_network() -> CheckResult:
    from .config import get_effective_host
    from .proxy import get_proxy_config, get_proxy_opener
    host = get_effective_host()
    url = f"https://{host}"

    try:
        opener = get_proxy_opener()
        opener.open(url, timeout=10)
        proxy_config = get_proxy_config()
        if proxy_config and (proxy_config.get("http") or proxy_config.get("https")):
            proxy_url = proxy_config.get("https") or proxy_config.get("http")
            return CheckResult(
                "Network", True,
                f"can reach {host} (via proxy)",
            )
        return CheckResult("Network", True, f"can reach {host} (direct)")
    except Exception:
        proxy_config = get_proxy_config()
        hint = "Check internet connection and firewall settings"
        if not proxy_config:
            hint += ". If behind a proxy, use --proxy http://proxy:port"
        return CheckResult(
            "Network", False, f"cannot reach {host}",
            fix_hint=hint,
        )


def run_all_checks() -> list[CheckResult]:
    results = [
        check_python_version(),
        check_pip_available(),
        check_venv_available(),
        check_docker(),
        check_network(),
    ]
    for r in results:
        level = "info" if r.passed else ("warning" if r.warning else "error")
        getattr(logger, level)("%s: %s", r.name, r.message)
        if r.fix_hint and not r.passed:
            logger.debug("  Fix: %s", r.fix_hint)
    return results
