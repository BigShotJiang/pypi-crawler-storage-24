"""Local configuration management (~/.nds/)."""

import json
from pathlib import Path

from .constants import ARTIFACTORY_HOST, CONFIG_DIR, DOCKER_REGISTRIES

CONFIG_FILE = CONFIG_DIR / "setup.json"


def ensure_config_dir() -> Path:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    return CONFIG_DIR


def load_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(config: dict) -> None:
    try:
        ensure_config_dir()
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
            f.write("\n")
    except OSError as e:
        from .log import get_logger
        get_logger("config").error("Cannot write config: %s", e)
        raise RuntimeError(f"Cannot write to {CONFIG_FILE}: {e}") from e


def get_edition() -> str | None:
    return load_config().get("edition")


def set_edition(edition: str) -> None:
    config = load_config()
    config["edition"] = edition
    save_config(config)


def get_effective_host() -> str:
    """Return mirror host if configured, else default ARTIFACTORY_HOST."""
    config = load_config()
    mirror = config.get("mirror", {})
    return mirror.get("artifactory_host") or ARTIFACTORY_HOST


def get_effective_registry(edition: str) -> str:
    """Build registry URL from effective host."""
    host = get_effective_host()
    # Replace host portion of the registry URL
    default = DOCKER_REGISTRIES[edition]
    _, path = default.split("/", 1)
    return f"{host}/{path}"


def get_effective_index_url() -> str:
    """Build Python index URL from effective host."""
    host = get_effective_host()
    return f"https://{host}/artifactory/api/pypi/tooling-pypi/simple"


def save_setup_state(
    *,
    edition: str,
    username: str,
    docker_logged_in: bool,
    pip_configured: bool,
    installed_packages: list[str] | None = None,
    venv_path: str | None = None,
) -> None:
    """Persist wizard results for downstream tools."""
    config = load_config()
    config.update({
        "edition": edition,
        "username": username,
        "docker_logged_in": docker_logged_in,
        "pip_configured": pip_configured,
    })
    if installed_packages is not None:
        config["installed_packages"] = installed_packages
    if venv_path is not None:
        config["venv_path"] = venv_path
    save_config(config)
