"""Command-line interface for ndslive-setup."""

import argparse
import sys


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="ndslive-setup",
        description="Interactive setup wizard for NDS.Live development environment",
    )
    parser.add_argument(
        "--version", action="version",
        version=f"%(prog)s {_get_version()}",
    )

    parser.add_argument(
        "--dry-run", action="store_true",
        help="Run the wizard without making any changes",
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Show debug-level log output",
    )
    parser.add_argument(
        "--proxy", metavar="URL",
        help="HTTP proxy URL (e.g. http://user:pass@proxy:8080)",
    )
    parser.add_argument(
        "--no-proxy", metavar="HOSTS",
        help="Comma-separated hosts to bypass proxy",
    )
    parser.add_argument(
        "--mirror-host", metavar="HOST",
        help="Artifactory mirror hostname",
    )

    sub = parser.add_subparsers(dest="command")
    sub.add_parser("setup", help="Run the interactive setup wizard")
    sub.add_parser("doctor", help="Diagnose existing NDS.Live setup")
    sub.add_parser("status", help="Show current setup status")
    sub.add_parser("auth", help="Configure Artifactory credentials")
    sub.add_parser("install", help="Install NDS.Live tools")
    sub.add_parser("update", help="Update installed NDS.Live tools")
    reset_p = sub.add_parser("reset", help="Remove NDS.Live configuration")
    reset_p.add_argument(
        "--all", action="store_true", help="Remove all configuration",
    )

    args = parser.parse_args()

    # Persist proxy/mirror flags if provided
    if args.proxy:
        from .proxy import save_proxy_config
        save_proxy_config(
            http=args.proxy, https=args.proxy,
            no_proxy=getattr(args, "no_proxy", "") or "",
        )
    if args.mirror_host:
        from .proxy import save_mirror_config
        save_mirror_config(args.mirror_host)

    # Initialize logging for non-TUI commands (TUI sets up its own)
    if args.command and args.command != "setup":
        from .log import setup_logging
        setup_logging(verbose=args.verbose)

    # Register proxy secrets early
    from .proxy import get_proxy_config, register_proxy_secrets
    from .log import register_secret
    if get_proxy_config():
        register_proxy_secrets(register_secret)

    if args.command is None or args.command == "setup":
        _run_wizard(dry_run=args.dry_run)
    elif args.command == "doctor":
        _run_doctor()
    elif args.command == "status":
        _run_status()
    elif args.command == "auth":
        _run_auth()
    elif args.command == "install":
        _run_install()
    elif args.command == "update":
        _run_update()
    elif args.command == "reset":
        _run_reset(remove_all=args.all)


def _get_version() -> str:
    from . import __version__
    return __version__


def _run_wizard(dry_run: bool = False) -> None:
    from .app import SetupApp
    app = SetupApp(dry_run=dry_run)
    app.run()

    if app.state.venv_source == "created":
        from rich.console import Console
        from .app import _get_activate_command
        console = Console()
        activate = _get_activate_command(app.state.venv_path)
        console.print()
        console.print("[bold]Activate your virtual environment:[/bold]")
        console.print(f"  {activate}")
        console.print()
        console.print(
            "[dim]This ensures NDS tools run from the isolated environment.\n"
            "Run 'deactivate' to return to your system Python.\n"
            "Learn more: https://docs.python.org/3/library/venv.html[/dim]",
        )


def _run_doctor() -> None:
    import configparser
    from rich.console import Console
    from .checks import run_all_checks
    from .config import get_edition
    from .constants import ARTIFACTORY_HOST
    from .docker_registry import is_logged_in
    from .python_index import is_index_configured

    console = Console()
    console.print("\n[bold blue]NDS.Live Setup Doctor[/bold blue]\n")

    console.print("[bold]Prerequisites[/bold]")
    for r in run_all_checks():
        if r.passed:
            icon, color = "+", "green"
        elif r.warning:
            icon, color = "!", "yellow"
        else:
            icon, color = "x", "red"
        console.print(f"  [{color}]{icon}[/{color}] {r.name}: {r.message}")
        if r.fix_hint and not r.passed:
            console.print(f"    [dim]{r.fix_hint}[/dim]")

    console.print("\n[bold]Configuration[/bold]")
    edition = get_edition()
    if edition:
        console.print(f"  Edition: {edition}")
        logged_in = is_logged_in(edition)
        icon = "+" if logged_in else "x"
        color = "green" if logged_in else "red"
        label = "logged in" if logged_in else "not logged in"
        console.print(f"  [{color}]{icon}[/{color}] Docker registry: {label}")
    else:
        console.print("  [dim]No edition configured — run ndslive-setup[/dim]")

    pip_ok = is_index_configured()
    icon = "+" if pip_ok else "x"
    color = "green" if pip_ok else "red"
    label = "configured" if pip_ok else "not configured"
    console.print(f"  [{color}]{icon}[/{color}] Python index: {label}")

    # Installed tools
    from .catalog import TOOLS
    from .config import load_config
    from .venv_manager import list_installed_packages

    config = load_config()
    venv_path_str = config.get("venv_path")
    from pathlib import Path
    venv = Path(venv_path_str) if venv_path_str else None

    installed = list_installed_packages(venv)
    tool_packages = {t["package"].lower(): t for t in TOOLS.values()}
    has_tools = False
    for pkg_lower, tool in tool_packages.items():
        ver = installed.get(pkg_lower)
        if ver:
            if not has_tools:
                console.print("\n[bold]Installed Tools[/bold]")
                has_tools = True
            console.print(f"  [green]+[/green] {tool['package']} v{ver}")

    if not has_tools:
        console.print("\n[bold]Installed Tools[/bold]")
        console.print("  [dim]None detected[/dim]")

    # Token validity check — read token from pip.conf
    if pip_ok and edition:
        username = config.get("username")
        if username:
            from .python_index import get_pip_conf_path
            _pip_conf = get_pip_conf_path()
            _pip_cfg = configparser.ConfigParser()
            _pip_cfg.read(_pip_conf)
            _idx_url = _pip_cfg.get("global", "index-url", fallback="")
            _extra_url = _pip_cfg.get("global", "extra-index-url", fallback="")
            # Extract token from whichever URL contains the NDS host
            _nds_url = _idx_url if ARTIFACTORY_HOST in _idx_url else _extra_url
            _token = ""
            if f"{username}:" in _nds_url:
                _token = _nds_url.split(f"{username}:")[1].split("@")[0]
            if _token:
                from .python_index import verify_index_access
                ok, msg = verify_index_access(username, _token)
                if not ok and ("401" in msg.lower() or "auth" in msg.lower()):
                    console.print(
                        "\n  [yellow]! Token may be expired — "
                        "run ndslive-setup auth to refresh[/yellow]",
                    )

    # Proxy info
    from .proxy import get_proxy_config
    proxy_config = get_proxy_config()
    if proxy_config and (proxy_config.get("http") or proxy_config.get("https")):
        console.print("\n[bold]Proxy[/bold]")
        if proxy_config.get("https"):
            console.print(f"  HTTPS: {proxy_config['https']}")
        if proxy_config.get("http"):
            console.print(f"  HTTP: {proxy_config['http']}")
        if proxy_config.get("no_proxy"):
            console.print(f"  No proxy: {proxy_config['no_proxy']}")

        # Check Docker proxy
        if edition:
            from .docker_registry import check_docker_proxy_config
            docker_proxy_ok, _ = check_docker_proxy_config()
            if not docker_proxy_ok:
                console.print(
                    "\n  [yellow]! Docker proxy not configured. "
                    "Add to ~/.docker/config.json:[/yellow]"
                )
                console.print(
                    '  [dim]{"proxies": {"default": '
                    '{"httpProxy": "...", "httpsProxy": "..."}}}[/dim]',
                )

    from .log import LOG_FILE
    console.print(f"\n[dim]Log file: {LOG_FILE}[/dim]")
    console.print()


def _run_status() -> None:
    from rich.console import Console
    from rich.table import Table
    from .config import get_edition
    from .docker_registry import is_logged_in
    from .python_index import is_index_configured

    console = Console()
    table = Table(
        title="NDS.Live Setup Status",
        show_header=False, border_style="blue",
    )
    table.add_column("Key", style="bold")
    table.add_column("Value")

    edition = get_edition()
    table.add_row("Edition", edition or "[dim]not configured[/dim]")

    if edition:
        ok = is_logged_in(edition)
        table.add_row(
            "Docker Registry",
            "[green]+ logged in[/green]" if ok else "[red]x not logged in[/red]",
        )

    pip_ok = is_index_configured()
    table.add_row(
        "Python Index",
        "[green]+ configured[/green]" if pip_ok else "[red]x not configured[/red]",
    )

    console.print()
    console.print(table)
    console.print()


def _run_auth() -> None:
    import os
    import shutil

    from rich.console import Console
    from rich.prompt import Prompt
    from .config import get_edition, save_setup_state
    from .constants import ARTIFACTORY_HOST, ARTIFACTORY_PROFILE_URL, DOCKER_REGISTRIES
    from .docker_registry import login as docker_login
    from .log import register_secret
    from .python_index import configure_index

    console = Console()
    console.print("\n[bold blue]NDS.Live Auth Setup[/bold blue]\n")
    console.print(
        "[bold]You need an Artifactory identity token.[/bold]\n"
        "Generate one at: "
        f"[link={ARTIFACTORY_PROFILE_URL}]{ARTIFACTORY_PROFILE_URL}[/link]\n"
        "  1. Log in via SSO\n"
        "  2. Edit Profile > Identity Tokens > Generate\n"
        "  3. Copy the token and paste it below\n",
    )

    # Support non-interactive mode via env vars (CI / E2E tests)
    username = os.environ.get("NDS_ARTIFACTORY_USER") or Prompt.ask(
        "Artifactory username",
    )
    token = os.environ.get("NDS_ARTIFACTORY_TOKEN") or Prompt.ask(
        "Identity token", password=True,
    )
    register_secret(token)

    # Detect edition via Docker registries
    docker_ok = False
    edition = "community"
    docker_available = shutil.which("docker") is not None
    if not docker_available:
        console.print(
            "[yellow]! Docker not installed — skipping registry login[/yellow]",
        )
    else:
        for ed in ("member", "community"):
            ok, msg = docker_login(ed, username, token)
            if ok:
                edition = ed
                docker_ok = True
                break

    label = "Member" if edition == "member" else "Community"
    console.print(f"[green]+ Edition detected: {label}[/green]")
    if docker_ok:
        console.print("[green]+ Docker registry: logged in[/green]")
    elif docker_available:
        console.print("[yellow]! Docker registry: login failed[/yellow]")

    pip_path = configure_index(username, token)
    console.print(f"[green]+ Python index: {pip_path}[/green]")

    save_setup_state(
        edition=edition,
        username=username,
        docker_logged_in=docker_ok,
        pip_configured=True,
    )
    console.print("\n[bold green]Credentials configured![/bold green]\n")


def _run_install() -> None:
    from rich.console import Console
    from rich.prompt import Prompt
    from .catalog import TOOLS
    from .config import get_edition, load_config
    from .venv_manager import install_package, list_installed_packages

    console = Console()
    console.print("\n[bold blue]NDS.Live Install[/bold blue]\n")

    edition = get_edition()
    if not edition:
        console.print(
            "[red]No edition configured. Run ndslive-setup auth first.[/red]",
        )
        return

    config = load_config()
    venv_path = config.get("venv_path")

    from pathlib import Path
    venv = Path(venv_path) if venv_path else None
    installed = list_installed_packages(venv)

    available = []
    for tid, tool in TOOLS.items():
        if edition not in tool.get("editions", []):
            continue
        pkg = tool["package"]
        ver = installed.get(pkg.lower())
        status = f" (v{ver} installed)" if ver else ""
        available.append((tid, tool, ver))
        idx = len(available)
        console.print(f"  {idx}. {pkg} — {tool['description']}{status}")

    if not available:
        console.print("[dim]No tools available for your edition.[/dim]")
        return

    console.print()
    selection = Prompt.ask(
        "Enter numbers to install (comma-separated, or 'all')",
        default="all",
    )

    if selection.strip().lower() == "all":
        indices = list(range(len(available)))
    else:
        indices = []
        for part in selection.split(","):
            part = part.strip()
            if part.isdigit():
                idx = int(part) - 1
                if 0 <= idx < len(available):
                    indices.append(idx)

    for idx in indices:
        tid, tool, ver = available[idx]
        pkg = tool["package"]
        console.print(f"[dim]Installing {pkg}...[/dim]")
        ok, msg = install_package(pkg, venv)
        if ok:
            console.print(f"[green]+ {msg}[/green]")
        else:
            console.print(f"[red]x {pkg}: {msg}[/red]")

    console.print()


def _run_update() -> None:
    from pathlib import Path
    from rich.console import Console
    from .config import load_config
    from .venv_manager import (
        list_installed_packages,
        upgrade_package,
    )

    console = Console()
    console.print("\n[bold blue]NDS.Live Update[/bold blue]\n")

    config = load_config()
    tracked = config.get("installed_packages", [])
    if not tracked:
        console.print(
            "[dim]No installed packages tracked. "
            "Run ndslive-setup install first.[/dim]",
        )
        return

    venv_path_str = config.get("venv_path")
    venv = Path(venv_path_str) if venv_path_str else None

    # Get current versions
    installed = list_installed_packages(venv)

    for pkg in tracked:
        before = installed.get(pkg.lower(), "unknown")
        console.print(f"[dim]Upgrading {pkg} (current: v{before})...[/dim]")
        ok, msg = upgrade_package(pkg, venv)
        if ok:
            after_installed = list_installed_packages(venv)
            after = after_installed.get(pkg.lower(), "unknown")
            if before != after:
                console.print(
                    f"[green]+ {pkg}: v{before} -> v{after}[/green]",
                )
            else:
                console.print(f"[green]+ {pkg}: v{after} (already latest)[/green]")
        else:
            console.print(f"[red]x {pkg}: {msg}[/red]")

    console.print()


def _run_reset(remove_all: bool = False) -> None:
    import shutil
    from rich.console import Console
    from rich.prompt import Confirm
    from .config import CONFIG_DIR, CONFIG_FILE, load_config

    console = Console()

    if not CONFIG_DIR.exists():
        console.print("[dim]No NDS.Live configuration found.[/dim]")
        return

    if not remove_all:
        if CONFIG_FILE.exists():
            if not Confirm.ask("Remove setup configuration (setup.json)?"):
                return
            CONFIG_FILE.unlink()
            console.print("[green]Setup configuration reset.[/green]")
        else:
            console.print("[dim]No setup configuration found.[/dim]")
        return

    if not Confirm.ask(
        "Remove NDS.Live setup configuration, venv, "
        "pip index, and Docker registry login?",
    ):
        return

    config = load_config()
    results = []

    # 1. Remove setup.json
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
        results.append("  [green]+[/green] Removed setup.json")

    # 2. Remove setup-created venv
    venv_dir = CONFIG_DIR / "venv"
    if venv_dir.exists():
        shutil.rmtree(venv_dir)
        results.append("  [green]+[/green] Removed virtual environment")

    # 3. Restore pip.conf from backup or remove NDS entries
    from .python_index import reset_index
    ok, msg = reset_index()
    results.append(f"  [green]+[/green] {msg}" if ok else f"  [red]x[/red] {msg}")

    # 4. Docker logout from NDS registries
    from .docker_registry import logout as docker_logout
    edition = config.get("edition")
    if edition:
        ok, msg = docker_logout(edition)
        results.append(
            f"  [green]+[/green] {msg}" if ok else f"  [yellow]![/yellow] {msg}",
        )

    # 5. Remove setup log files
    for logfile in CONFIG_DIR.glob("setup.log*"):
        logfile.unlink()
        results.append(f"  [green]+[/green] Removed {logfile.name}")

    console.print("\n".join(results))
    console.print(
        "\n[dim]Preserved: ~/.nds/configs/ (mapviewer data)[/dim]",
    )
    console.print("[green]NDS.Live setup configuration removed.[/green]")
