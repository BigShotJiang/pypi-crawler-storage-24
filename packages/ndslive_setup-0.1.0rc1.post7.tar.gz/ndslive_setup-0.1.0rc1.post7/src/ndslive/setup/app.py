"""NDS.Live Setup — Textual TUI application."""

from __future__ import annotations

import platform
from dataclasses import dataclass, field
from pathlib import Path

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll, Container
from textual.widgets import (
    Header, Footer, Static, Button, RadioSet, RadioButton,
    Input, Rule, Checkbox, LoadingIndicator, RichLog, Collapsible,
)
from textual import work

from .constants import (
    ARTIFACTORY_HOST, ARTIFACTORY_PROFILE_URL,
    DEVPORTAL_URL, DOCKER_REGISTRIES, EDITIONS,
    PIP_AUTH_DOCS_URL, VENV_DOCS_URL,
)
from .venv_manager import DEFAULT_VENV_PATH


def _get_activate_command(venv_path: str | Path) -> str:
    if platform.system() == "Windows":
        return f"{venv_path}\\Scripts\\activate.bat"
    return f"source {venv_path}/bin/activate"


@dataclass
class SetupState:
    """Wizard state shared across steps."""

    edition: str = ""
    username: str = ""
    token: str = ""
    dry_run: bool = False
    venv_source: str = "system"  # "active" | "created" | "system"
    venv_path: Path = field(default_factory=lambda: DEFAULT_VENV_PATH)
    docker_available: bool = False
    docker_logged_in: bool = False
    pip_configured: bool = False
    installed_packages: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Sidebar indicator
# ---------------------------------------------------------------------------

class StepIndicator(Static):
    """Step progress indicator in the sidebar."""

    def __init__(self, label: str, index: int, **kwargs) -> None:
        super().__init__(f"[dim]  {label}[/dim]", **kwargs)
        self.step_label = label
        self.step_index = index

    def set_state(self, state: str) -> None:
        if state == "active":
            self.update(f"[bold]> {self.step_label}[/bold]")
        elif state == "completed":
            self.update(f"[green]+ {self.step_label}[/green]")
        else:
            self.update(f"[dim]  {self.step_label}[/dim]")


# ---------------------------------------------------------------------------
# Step 0 — Welcome
# ---------------------------------------------------------------------------

class WelcomeStep(Container):
    def __init__(self, state: SetupState) -> None:
        super().__init__()
        self.state = state

    def compose(self) -> ComposeResult:
        yield Static("[bold]Welcome to NDS.Live Setup[/bold]", classes="step-title")
        yield Static(
            "This wizard configures your development environment\n"
            "for NDS.Live tools and services.\n"
            "\n"
            "What you'll set up:\n"
            "  [bold]*[/bold] Docker registry access for NDS container images\n"
            "  [bold]*[/bold] Python package index for NDS Python packages\n"
            "  [bold]*[/bold] Optional: dedicated virtual environment\n"
            "  [bold]*[/bold] Optional: install NDS Python packages",
        )
        yield Static("")
        yield Static(
            "[bold]Editions[/bold]\n"
            "  [bold]Community[/bold]  -  NDS.Live only (public users)\n"
            "  [bold]Member[/bold]     -  NDS.Live + NDS.Classic (member orgs)\n"
            "\n"
            "[dim]Your edition will be auto-detected from your\n"
            "registry access in the next step.[/dim]",
        )
        yield Static(f"\n[dim]Learn more at {DEVPORTAL_URL}[/dim]")
        yield Static(
            "\n[dim]Tip: You can use the mouse to click buttons and select options.\n"
            "Use Tab to switch between controls and Enter to confirm.[/dim]",
        )
        if self.state.dry_run:
            yield Static("\n[yellow bold]DRY RUN[/yellow bold] — no changes will be made")
        with Horizontal(classes="step-buttons"):
            yield Button("Continue", variant="primary", id="next")


# ---------------------------------------------------------------------------
# Step 1 — Prerequisites
# ---------------------------------------------------------------------------

class PrerequisitesStep(Container):
    def __init__(self, state: SetupState) -> None:
        super().__init__()
        self.state = state

    def compose(self) -> ComposeResult:
        yield Static("[bold]Prerequisites[/bold]", classes="step-title")
        yield Static("Checking system requirements...\n")
        yield Vertical(id="check-list")
        yield Static("", id="check-summary")
        with Horizontal(classes="step-buttons"):
            yield Button("Re-check", id="recheck")
            yield Button("Back", id="back")
            yield Button("Continue", variant="primary", id="next", disabled=True)

    def on_mount(self) -> None:
        if self.state.dry_run:
            self._show_dry_run()
        else:
            self._run_checks()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "recheck":
            if self.state.dry_run:
                self._show_dry_run()
            else:
                self._run_checks()
            event.stop()

    def _show_dry_run(self) -> None:
        check_list = self.query_one("#check-list")
        check_list.remove_children()
        for name in ["Python", "pip", "venv", "Docker", "Network"]:
            check_list.mount(
                Static(f"  [green]+[/green] {name}: [dim]skipped (dry run)[/dim]"),
            )
        self.state.docker_available = True
        summary = self.query_one("#check-summary", Static)
        summary.update(
            "\n[yellow]Dry run — all checks assumed passed.[/yellow]",
        )
        self.query_one("#next", Button).disabled = False

    @work(thread=True)
    def _run_checks(self) -> None:
        from .checks import run_all_checks
        results = run_all_checks()
        self.app.call_from_thread(self._display_results, results)

    def _display_results(self, results: list) -> None:
        check_list = self.query_one("#check-list")
        check_list.remove_children()

        all_critical_ok = True
        docker_ok = False

        for r in results:
            if r.passed:
                line = f"  [green]+[/green] {r.name}: {r.message}"
            elif r.warning:
                line = f"  [yellow]![/yellow] {r.name}: {r.message}"
            else:
                line = f"  [red]x[/red] {r.name}: {r.message}"
            if r.fix_hint and not r.passed:
                line += f"\n    [dim]{r.fix_hint}[/dim]"
            check_list.mount(Static(line))

            if not r.passed and not r.warning:
                all_critical_ok = False
            if r.name == "Docker" and r.passed:
                docker_ok = True

        self.state.docker_available = docker_ok

        summary = self.query_one("#check-summary", Static)
        if all_critical_ok:
            note = ""
            if not docker_ok:
                note = (
                    "\n[yellow]Docker is not available. "
                    "Docker-related steps will be skipped.[/yellow]"
                )
            summary.update(f"\n[green]All critical checks passed.[/green]{note}")
        else:
            summary.update(
                "\n[red]Some critical checks failed. "
                "Fix the issues above and re-check.[/red]"
            )
        self.query_one("#next", Button).disabled = not all_critical_ok


# ---------------------------------------------------------------------------
# Step 2 — Artifactory Access
# ---------------------------------------------------------------------------

class ArtifactoryStep(Container):
    def __init__(self, state: SetupState) -> None:
        super().__init__()
        self.state = state

    def compose(self) -> ComposeResult:
        yield Static("[bold]Artifactory Access[/bold]", classes="step-title")
        yield Static(
            "Your Artifactory identity token grants access to both\n"
            "Docker images and Python packages.\n"
            "\n"
            "[bold]Generate a token:[/bold]\n"
            f"  1. Go to {ARTIFACTORY_PROFILE_URL}\n"
            "  2. Log in via SSO\n"
            "  3. Edit Profile > Identity Tokens > Generate\n"
            "  4. Copy the token and paste it below",
        )
        yield Static("")
        yield Button(
            "Open Artifactory in Browser", id="open-browser", variant="default",
        )
        yield Rule()
        yield Static("[bold]Credentials[/bold]")
        yield Input(placeholder="Username", id="username")
        yield Input(
            placeholder="Identity Token", password=True, id="token",
        )
        yield Static("", id="edition-area")
        yield Static("", id="status-area")
        with Horizontal(classes="step-buttons"):
            yield Button("Back", id="back")
            yield Button(
                "Verify & Setup", variant="primary", id="verify", disabled=True,
            )

    def on_mount(self) -> None:
        from .config import load_config
        config = load_config()
        if config.get("username"):
            self.query_one("#username", Input).value = config["username"]

        self._check_existing()

    def _check_existing(self) -> None:
        if self.state.dry_run:
            return

        from .docker_registry import is_logged_in
        from .python_index import is_index_configured

        already_docker = False
        for edition in DOCKER_REGISTRIES:
            if self.state.docker_available and is_logged_in(edition):
                already_docker = True
                self.state.edition = edition
        already_pip = is_index_configured()

        if already_docker or already_pip:
            lines = "[dim]Existing configuration detected:[/dim]"
            if already_docker:
                lines += "\n  [green]+[/green] Docker registry: logged in"
                self.state.docker_logged_in = True
            if already_pip:
                lines += "\n  [green]+[/green] Python index: configured"
                self.state.pip_configured = True
            lines += (
                "\n\n[dim]Enter credentials to reconfigure, "
                "or press Continue to keep existing setup.[/dim]"
            )
            self.query_one("#status-area", Static).update(lines)

        if (already_docker or not self.state.docker_available) and already_pip:
            btn = self.query_one("#verify", Button)
            btn.label = "Continue"
            btn.disabled = False
            btn.focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        username = self.query_one("#username", Input).value.strip()
        token = self.query_one("#token", Input).value.strip()
        btn = self.query_one("#verify", Button)
        if username and token:
            btn.disabled = False
            btn.label = "Verify & Setup"
        elif not (self.state.docker_logged_in and self.state.pip_configured):
            btn.disabled = True

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "open-browser":
            import webbrowser
            webbrowser.open(ARTIFACTORY_PROFILE_URL)
            event.stop()
        elif event.button.id == "verify":
            if str(event.button.label) == "Continue":
                return
            username = self.query_one("#username", Input).value.strip()
            token = self.query_one("#token", Input).value.strip()
            if username and token:
                if self.state.dry_run:
                    self._dry_run_setup(username)
                else:
                    self._run_setup(username, token)
                event.stop()

    def _dry_run_setup(self, username: str) -> None:
        self.state.username = username
        self.state.token = "dry-run-token"
        self.state.edition = "community"
        self.state.docker_logged_in = True
        self.state.pip_configured = True
        lines = (
            "[yellow]Dry run — skipping all side-effects[/yellow]\n"
            "[green]+ Edition detected: community (simulated)[/green]\n"
            "[green]+ Docker registry: would log in[/green]\n"
            "[green]+ Python index: would configure pip.conf[/green]\n"
            "\n[bold green]Access configured! (dry run)[/bold green]"
        )
        self._set_status(lines)
        btn = self.query_one("#verify", Button)
        btn.label = "Continue"

    @work(thread=True)
    def _run_setup(self, username: str, token: str) -> None:
        self.app.call_from_thread(
            self._set_status, "[dim]Verifying credentials...[/dim]",
        )

        from .python_index import verify_index_access
        from .proxy import get_proxy_opener
        ok, msg = verify_index_access(username, token, opener=get_proxy_opener())
        if not ok:
            self.app.call_from_thread(
                self._set_status, f"[red]x Verification failed: {msg}[/red]",
            )
            return

        self._configure_with_token(username, token)

    def _configure_with_token(self, username: str, token: str) -> None:
        """Common path: we have a valid token, configure everything."""
        self.state.username = username
        self.state.token = token
        results = ["[green]+ Credentials verified[/green]"]

        # Auto-detect edition by probing registries
        if self.state.docker_available:
            self.app.call_from_thread(
                self._set_status,
                "[green]+ Credentials verified[/green]\n"
                "[dim]Detecting edition from registry access...[/dim]",
            )
            detected = self._detect_edition(username, token)
            if detected:
                self.state.edition = detected
                label = EDITIONS[detected]["label"]
                results.append(f"[green]+ Edition detected: {label}[/green]")
            else:
                self.state.edition = "community"
                results.append(
                    "[yellow]! Could not probe registries, defaulting to Community[/yellow]",
                )
        else:
            self.state.edition = "community"
            results.append("[dim]Edition: Community (Docker unavailable)[/dim]")

        # Show edition with override option
        self.app.call_from_thread(self._show_edition_choice, self.state.edition)

        # Docker registry login
        if self.state.docker_available:
            self.app.call_from_thread(
                self._set_status,
                "\n".join(results) + "\n[dim]Logging into Docker registry...[/dim]",
            )
            from .docker_registry import login as docker_login
            ok, msg = docker_login(self.state.edition, username, token)
            self.state.docker_logged_in = ok
            if ok:
                results.append("[green]+ Docker registry: logged in[/green]")
            else:
                results.append(f"[yellow]! Docker registry: {msg}[/yellow]")

        # Configure pip
        self.app.call_from_thread(
            self._set_status,
            "\n".join(results) + "\n[dim]Configuring Python index...[/dim]",
        )
        from .python_index import configure_index
        try:
            pip_path = configure_index(username, token)
            self.state.pip_configured = True
            results.append(f"[green]+ Python index: {pip_path}[/green]")
            results.append(
                f"[dim]  Note: credentials stored in plaintext at {pip_path}[/dim]",
            )
        except Exception as e:
            results.append(f"[red]x Python index: {e}[/red]")

        # Persist config
        from .config import save_setup_state
        save_setup_state(
            edition=self.state.edition,
            username=username,
            docker_logged_in=self.state.docker_logged_in,
            pip_configured=self.state.pip_configured,
        )

        success = self.state.pip_configured and (
            self.state.docker_logged_in or not self.state.docker_available
        )
        final = "\n".join(results)
        if success:
            final += "\n\n[bold green]Access configured![/bold green]"

        self.app.call_from_thread(self._finish_setup, final, success)

    def _detect_edition(self, username: str, token: str) -> str | None:
        """Probe Docker registries to detect edition.

        Member registry accepts → member (superset).
        Only community accepts → community.
        """
        from .docker_registry import login as docker_login

        # Try member first (superset)
        ok, _ = docker_login("member", username, token)
        if ok:
            return "member"

        ok, _ = docker_login("community", username, token)
        if ok:
            return "community"

        return None

    def _show_edition_choice(self, detected: str) -> None:
        label = EDITIONS[detected]["label"]
        self.query_one("#edition-area", Static).update(
            f"[dim]Detected edition: [bold]{label}[/bold][/dim]",
        )

    def _set_status(self, text: str) -> None:
        self.query_one("#status-area", Static).update(text)

    def _finish_setup(self, text: str, success: bool) -> None:
        self._set_status(text)
        if success:
            btn = self.query_one("#verify", Button)
            btn.label = "Continue"
            btn.focus()


# ---------------------------------------------------------------------------
# Step 3 — Environment
# ---------------------------------------------------------------------------

class EnvironmentStep(Container):
    def __init__(self, state: SetupState) -> None:
        super().__init__()
        self.state = state
        self._active_venv: Path | None = None

    def compose(self) -> ComposeResult:
        yield Static("[bold]Python Environment[/bold]", classes="step-title")
        yield Static(
            "Choose where NDS packages will be installed.\n"
            f"\n[dim]Learn more: {VENV_DOCS_URL}[/dim]\n",
        )
        yield RadioSet(id="venv-choice")
        yield Static("")
        yield Static("Path:", classes="field-label")
        yield Input(
            placeholder=str(DEFAULT_VENV_PATH), value=str(DEFAULT_VENV_PATH),
            id="venv-path", disabled=True,
        )
        yield Static("", id="venv-status")
        with Horizontal(classes="step-buttons"):
            yield Button("Back", id="back")
            yield Button("Continue", variant="primary", id="next")

    def on_mount(self) -> None:
        from .venv_manager import detect_active_venv, detect_existing_venv
        self._active_venv = detect_active_venv()
        radio_set = self.query_one("#venv-choice", RadioSet)

        if self._active_venv:
            radio_set.mount(
                RadioButton(
                    f"Use active venv at {self._active_venv}",
                    value=True, id="opt-active",
                ),
            )
            self.state.venv_source = "active"
            self.state.venv_path = self._active_venv

        create_label = "Create a fresh virtual environment"
        if detect_existing_venv(DEFAULT_VENV_PATH):
            create_label += f"  [dim](exists at {DEFAULT_VENV_PATH})[/dim]"
        radio_set.mount(
            RadioButton(
                create_label,
                value=not bool(self._active_venv),
                id="opt-create",
            ),
        )
        if not self._active_venv:
            self.state.venv_source = "created"
            self.query_one("#venv-path", Input).disabled = False

        radio_set.mount(
            RadioButton(
                "Install to current Python  "
                "[yellow]Not recommended — may conflict with other projects[/yellow]",
                id="opt-system",
            ),
        )

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        selected_id = event.pressed.id if event.pressed else None
        path_input = self.query_one("#venv-path", Input)
        if selected_id == "opt-active":
            self.state.venv_source = "active"
            self.state.venv_path = self._active_venv
            path_input.disabled = True
        elif selected_id == "opt-create":
            self.state.venv_source = "created"
            path_input.disabled = False
        elif selected_id == "opt-system":
            self.state.venv_source = "system"
            path_input.disabled = True

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id != "next":
            return
        if self.state.venv_source == "created":
            path = self.query_one("#venv-path", Input).value.strip()
            if path:
                self.state.venv_path = Path(path)
            if self.state.dry_run:
                self._set_status(
                    f"[yellow]Dry run — would create venv at"
                    f" {self.state.venv_path}[/yellow]",
                )
            else:
                self._create_venv()
                event.stop()

    @work(thread=True)
    def _create_venv(self) -> None:
        self.app.call_from_thread(
            self._set_status, "[dim]Creating virtual environment...[/dim]",
        )
        from .venv_manager import create_venv
        ok, msg = create_venv(self.state.venv_path)
        if ok:
            self.app.call_from_thread(
                self._set_status,
                f"[green]+ Virtual environment created at {msg}[/green]",
            )
            self.app.call_from_thread(self._advance)
        else:
            self.app.call_from_thread(
                self._set_status, f"[red]x Failed: {msg}[/red]",
            )

    def _set_status(self, text: str) -> None:
        self.query_one("#venv-status", Static).update(text)

    def _advance(self) -> None:
        self.app.action_next_step()


# ---------------------------------------------------------------------------
# Step 4 — Install packages & pull images
# ---------------------------------------------------------------------------

class InstallStep(Container):
    def __init__(self, state: SetupState) -> None:
        super().__init__()
        self.state = state
        self._installed: dict[str, str] = {}

    def compose(self) -> ComposeResult:
        yield Static("[bold]Install Tools[/bold]", classes="step-title")
        yield Static(
            "Select which NDS.Live tools to install.\n",
        )

        yield Static("[bold]Python Packages[/bold]")
        yield Vertical(id="pkg-list")
        yield Static("", id="pkg-detect-status")

        if self.state.docker_available and self.state.docker_logged_in:
            yield Static("")
            yield Static(
                "[dim]Docker images are pulled automatically by each tool"
                " on first use.[/dim]",
            )

        yield LoadingIndicator(id="install-spinner")
        yield Static(
            "[dim]This may take a while for larger packages...[/dim]",
            id="install-hint",
        )
        yield Static("", id="install-status")
        with Horizontal(classes="step-buttons"):
            yield Button("Back", id="back")
            yield Button("Install Selected", variant="primary", id="install")
            yield Button("Skip", id="next")

    def on_mount(self) -> None:
        if self.state.dry_run:
            self._populate_packages({})
        else:
            self._detect_packages()

    @work(thread=True)
    def _detect_packages(self) -> None:
        self.app.call_from_thread(
            self._set_detect_status, "[dim]Detecting installed packages...[/dim]",
        )
        from .venv_manager import list_installed_packages
        venv = (
            self.state.venv_path
            if self.state.venv_source != "system" else None
        )
        installed = list_installed_packages(venv)
        self.app.call_from_thread(self._populate_packages, installed)

    def _set_detect_status(self, text: str) -> None:
        self.query_one("#pkg-detect-status", Static).update(text)

    def _populate_packages(self, installed: dict[str, str]) -> None:
        self._installed = installed
        self.query_one("#pkg-detect-status", Static).update("")
        pkg_list = self.query_one("#pkg-list", Vertical)
        pkg_list.remove_children()

        from .catalog import TOOLS
        for tid, tool in TOOLS.items():
            if self.state.edition not in tool.get("editions", []):
                continue
            pkg_name = tool["package"]
            label = f"{pkg_name}  -  {tool['description']}"
            version = installed.get(pkg_name.lower())
            if version:
                label += f"  [dim](v{version} installed)[/dim]"
            pkg_list.mount(
                Checkbox(label, value=not bool(version), id=f"pkg-{tid}"),
            )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "install":
            if self.state.dry_run:
                self._dry_run_install()
            else:
                self._run_install()
            event.stop()

    def _dry_run_install(self) -> None:
        from .catalog import TOOLS
        results = []
        for tid, tool in TOOLS.items():
            try:
                cb = self.query_one(f"#pkg-{tid}", Checkbox)
            except Exception:
                continue
            if cb.value:
                pkg = tool["package"]
                results.append(f"[yellow]~ {pkg}: would install (dry run)[/yellow]")
                self.state.installed_packages.append(pkg)
        final = "\n".join(results) if results else "[dim]Nothing selected.[/dim]"
        self._finish_install(final)

    @work(thread=True)
    def _run_install(self) -> None:
        from .catalog import TOOLS
        from .venv_manager import install_package
        self.app.call_from_thread(self._show_spinner, True)
        results = []

        for tid, tool in TOOLS.items():
            try:
                cb = self.query_one(f"#pkg-{tid}", Checkbox)
            except Exception:
                continue
            if not cb.value:
                continue

            pkg = tool["package"]
            self.app.call_from_thread(
                self._set_status,
                "\n".join(results) + f"\n[dim]Installing {pkg}...[/dim]",
            )
            venv = (
                self.state.venv_path
                if self.state.venv_source != "system" else None
            )
            ok, msg = install_package(pkg, venv)
            if ok:
                results.append(f"[green]+ {pkg} installed[/green]")
                self.state.installed_packages.append(pkg)
            else:
                results.append(f"[red]x {pkg}: {msg}[/red]")

        final = "\n".join(results) if results else "[dim]Nothing selected.[/dim]"
        self.app.call_from_thread(self._finish_install, final)

    def _set_status(self, text: str) -> None:
        self.query_one("#install-status", Static).update(text)

    def _show_spinner(self, visible: bool) -> None:
        display = "block" if visible else "none"
        self.query_one("#install-spinner").styles.display = display
        self.query_one("#install-hint").styles.display = display

    def _finish_install(self, text: str) -> None:
        self._show_spinner(False)
        self._set_status(text + "\n\n[bold]Done![/bold]")

        # Persist installed packages and venv path
        if self.state.installed_packages:
            from .config import save_setup_state
            venv = (
                str(self.state.venv_path)
                if self.state.venv_source != "system" else None
            )
            save_setup_state(
                edition=self.state.edition,
                username=self.state.username,
                docker_logged_in=self.state.docker_logged_in,
                pip_configured=self.state.pip_configured,
                installed_packages=self.state.installed_packages,
                venv_path=venv,
            )

        try:
            self.query_one("#install", Button).remove()
        except Exception:
            pass
        try:
            skip = self.query_one("#next", Button)
            skip.label = "Continue"
            skip.variant = "primary"
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Step 5 — Summary
# ---------------------------------------------------------------------------

class SummaryStep(Container):
    def __init__(self, state: SetupState) -> None:
        super().__init__()
        self.state = state

    def compose(self) -> ComposeResult:
        yield Static("[bold]Setup Complete[/bold]", classes="step-title")

        lines = []
        if self.state.dry_run:
            lines.append("[yellow bold]DRY RUN — no changes were made[/yellow bold]")
            lines.append("")

        edition_label = EDITIONS.get(self.state.edition, {}).get(
            "label", self.state.edition,
        )
        lines.append(f"  Edition:         {edition_label}")

        if self.state.docker_logged_in:
            reg = DOCKER_REGISTRIES.get(self.state.edition, "")
            lines.append(f"  Docker registry: [green]+[/green] {reg}")
        elif self.state.docker_available:
            lines.append("  Docker registry: [yellow]![/yellow] not configured")
        else:
            lines.append("  Docker registry: [dim]skipped (Docker not available)[/dim]")

        if self.state.pip_configured:
            lines.append("  Python index:    [green]+[/green] configured")
            lines.append(
                "  [dim]Credentials stored in plaintext in pip.conf."
                f" For alternatives see {PIP_AUTH_DOCS_URL}[/dim]",
            )
        else:
            lines.append("  Python index:    [red]x[/red] not configured")

        if self.state.venv_source == "created":
            lines.append(f"  Virtual env:     [green]+[/green] {self.state.venv_path}")
        elif self.state.venv_source == "active":
            lines.append(f"  Virtual env:     [green]+[/green] {self.state.venv_path} (active)")

        if self.state.installed_packages:
            pkgs = ", ".join(self.state.installed_packages)
            lines.append(f"  Packages:        {pkgs}")

        yield Static("\n".join(lines))
        yield Rule()
        yield Static("[bold]Next Steps[/bold]\n")

        next_steps = []
        if self.state.venv_source == "created":
            activate = _get_activate_command(self.state.venv_path)
            next_steps.append(
                f"  Activate your venv:\n    [bold]{activate}[/bold]\n"
                "  [dim]Mark and copy the command above, then paste it into your terminal.\n"
                "  This ensures NDS tools run from the isolated environment.\n"
                "  Run 'deactivate' to return to your system Python.[/dim]",
            )

        if "ndslive" in self.state.installed_packages:
            next_steps.append(
                "  Upgrade the SDK later:\n"
                "    [bold]pip install --upgrade ndslive[/bold]",
            )

        if "nds-mapviewer" in self.state.installed_packages:
            next_steps.append(
                "  Try the mapviewer:\n    [bold]mapviewer demo[/bold]\n"
                "  [dim]MapViewer pulls its Docker image on first run.[/dim]",
            )

        if self.state.docker_logged_in:
            next_steps.append(
                "  [dim]Docker images are pulled by each tool on first use.[/dim]",
            )

        if self.state.installed_packages:
            next_steps.append(
                "  Update installed tools:\n"
                "    [bold]ndslive-setup update[/bold]",
            )

        next_steps.append(
            "  Run diagnostics anytime:\n    [bold]ndslive-setup doctor[/bold]",
        )
        next_steps.append(
            f"  Documentation & resources:\n    [bold]{DEVPORTAL_URL}[/bold]",
        )

        yield Static("\n\n".join(next_steps))
        yield Static("")
        with Horizontal(classes="step-buttons"):
            yield Button("Finish", variant="primary", id="finish")


# ---------------------------------------------------------------------------
# Main application
# ---------------------------------------------------------------------------

STEP_CLASSES = [
    WelcomeStep,
    PrerequisitesStep,
    ArtifactoryStep,
    EnvironmentStep,
    InstallStep,
    SummaryStep,
]

STEP_LABELS = [
    "Welcome",
    "Prerequisites",
    "Artifactory",
    "Environment",
    "Install",
    "Summary",
]


class SetupApp(App):
    """NDS.Live interactive setup wizard."""

    TITLE = "NDS.Live Setup"
    SUB_TITLE = "developer.nds.live"

    CSS = """
    Screen {
        background: $surface;
    }

    #main {
        height: 1fr;
    }

    #sidebar {
        width: 24;
        background: $panel;
        padding: 1 1;
        border-right: thick $background;
    }

    #sidebar-title {
        text-style: bold;
        margin-bottom: 1;
    }

    #content {
        padding: 1 3;
    }

    .step-title {
        text-style: bold;
        margin-bottom: 1;
    }

    .step-buttons {
        dock: bottom;
        height: auto;
        align-horizontal: right;
        background: $surface;
        padding: 1 0 0 0;
    }

    .step-buttons Button {
        margin-left: 1;
    }

    .field-label {
        margin-top: 1;
    }

    #install-spinner, #install-hint {
        display: none;
    }

    #install-spinner {
        height: 3;
    }

    Input {
        margin: 0 0 1 0;
    }

    Checkbox {
        margin: 0 0;
        height: auto;
    }

    Rule {
        margin: 1 0;
    }

    #log-panel {
        height: auto;
        max-height: 12;
        dock: bottom;
    }

    #log-widget {
        height: auto;
        max-height: 10;
    }
    """

    BINDINGS = [
        Binding("escape", "quit", "Quit", show=True),
        Binding("ctrl+l", "toggle_log", "Log", show=True),
    ]

    def __init__(self, dry_run: bool = False) -> None:
        super().__init__()
        self.state = SetupState(dry_run=dry_run)
        self._current_step = 0

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="main"):
            with Vertical(id="sidebar"):
                yield Static("[bold]NDS.Live Setup[/bold]", id="sidebar-title")
                yield Rule()
                for i, label in enumerate(STEP_LABELS):
                    yield StepIndicator(label, i, id=f"step-ind-{i}")
            with Vertical():
                with VerticalScroll(id="content"):
                    pass
                with Collapsible(title="Log", collapsed=True, id="log-panel"):
                    yield RichLog(
                        highlight=True, markup=True, max_lines=500,
                        id="log-widget",
                    )
        yield Footer()

    def on_mount(self) -> None:
        from .log import setup_logging, attach_tui_handler
        setup_logging()
        log_widget = self.query_one("#log-widget", RichLog)
        attach_tui_handler(log_widget, self.app.call_from_thread)
        self._show_step(0)

    def action_toggle_log(self) -> None:
        panel = self.query_one("#log-panel", Collapsible)
        panel.collapsed = not panel.collapsed

    def _show_step(self, index: int) -> None:
        self._current_step = index
        content = self.query_one("#content", VerticalScroll)
        content.remove_children()

        step_cls = STEP_CLASSES[index]
        content.mount(step_cls(self.state))

        for i in range(len(STEP_LABELS)):
            ind = self.query_one(f"#step-ind-{i}", StepIndicator)
            if i < index:
                ind.set_state("completed")
            elif i == index:
                ind.set_state("active")
            else:
                ind.set_state("pending")

        content.scroll_home(animate=False)

    def action_next_step(self) -> None:
        if self._current_step < len(STEP_CLASSES) - 1:
            self._show_step(self._current_step + 1)

    def action_prev_step(self) -> None:
        if self._current_step > 0:
            self._show_step(self._current_step - 1)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "next":
            self.action_next_step()
        elif event.button.id == "back":
            self.action_prev_step()
        elif event.button.id == "finish":
            self.exit()
        elif event.button.id == "verify":
            # If verify button press bubbles here, treat as next
            # (happens when already configured and user clicks Continue)
            self.action_next_step()
