"""NDS.Live environment setup wizard."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("ndslive-setup")
except PackageNotFoundError:
    __version__ = "0.0.0.dev"
