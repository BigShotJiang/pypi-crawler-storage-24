"""Catalog of available NDS.Live tools and images."""

TOOLS = {
    "sdk": {
        "package": "ndslive",
        "description": "NDS.Live Python SDK",
        "editions": ["community", "member"],
    },
    "mapviewer": {
        "package": "nds-mapviewer",
        "description": "Interactive map viewer for NDS.Live data",
        "docker_image": "nds-mapviewer",
        "editions": ["community", "member"],
    },
}
