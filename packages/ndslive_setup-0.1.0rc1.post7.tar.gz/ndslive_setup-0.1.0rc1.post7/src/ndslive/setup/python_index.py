"""Python package index configuration for NDS Artifactory."""

import base64
import configparser
import platform
import stat
import urllib.error
import urllib.request
from pathlib import Path

from .constants import ARTIFACTORY_HOST, PUBLIC_PYPI_URL
from .log import get_logger

logger = get_logger("python_index")


def get_pip_conf_path() -> Path:
    """Get the platform-appropriate pip configuration file path."""
    if platform.system() == "Windows":
        return Path.home() / "pip" / "pip.ini"
    return Path.home() / ".config" / "pip" / "pip.conf"


def is_index_configured() -> bool:
    """Check if the NDS Python index is already in pip config."""
    pip_conf = get_pip_conf_path()
    if not pip_conf.exists():
        return False

    config = configparser.ConfigParser()
    config.read(pip_conf)

    index_url = config.get("global", "index-url", fallback="")
    extra_index = config.get("global", "extra-index-url", fallback="")

    return ARTIFACTORY_HOST in index_url or ARTIFACTORY_HOST in extra_index


def configure_index(username: str, token: str) -> Path:
    """Write pip.conf with NDS index. Returns path written."""
    from .config import get_effective_host
    from .proxy import get_proxy_config

    pip_conf = get_pip_conf_path()
    try:
        pip_conf.parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise RuntimeError(f"Cannot create directory {pip_conf.parent}: {e}") from e
    logger.info("Writing pip configuration to %s", pip_conf)

    # Back up existing config
    if pip_conf.exists():
        backup = pip_conf.with_suffix(pip_conf.suffix + ".bak")
        if not backup.exists():
            import shutil
            shutil.copy2(pip_conf, backup)
            logger.info("Backed up existing pip.conf to %s", backup)

    config = configparser.ConfigParser()
    # Preserve existing settings
    if pip_conf.exists():
        config.read(pip_conf)

    host = get_effective_host()
    authenticated_url = (
        f"https://{username}:{token}@{host}"
        f"/artifactory/api/pypi/tooling-pypi/simple"
    )

    if "global" not in config:
        config["global"] = {}

    existing_index = config.get("global", "index-url", fallback="")
    if not existing_index or ARTIFACTORY_HOST in existing_index:
        # Fresh install or already NDS — NDS as index-url, PyPI as extra
        config["global"]["index-url"] = authenticated_url
        config["global"]["extra-index-url"] = PUBLIC_PYPI_URL
    else:
        # Pre-existing index-url from user — keep it, add NDS + PyPI as extras
        extra_raw = config.get("global", "extra-index-url", fallback="")
        extras = [u.strip() for u in extra_raw.splitlines() if u.strip()]
        # Remove old NDS entry if present (re-run scenario)
        extras = [u for u in extras if ARTIFACTORY_HOST not in u]
        # Add NDS authenticated URL and PyPI (deduplicated)
        for url in [authenticated_url, PUBLIC_PYPI_URL]:
            if url not in extras:
                extras.append(url)
        config["global"]["extra-index-url"] = "\n".join(extras)

    # Write proxy into pip.conf so pip uses it outside the wizard
    proxy_config = get_proxy_config()
    if proxy_config:
        proxy_url = proxy_config.get("https") or proxy_config.get("http")
        if proxy_url:
            config["global"]["proxy"] = proxy_url

    with open(pip_conf, "w") as f:
        config.write(f)

    # Restrict permissions to owner-only on Unix (credentials in plaintext)
    if platform.system() != "Windows":
        pip_conf.chmod(stat.S_IRUSR | stat.S_IWUSR)
        logger.info("Permissions set to 0600 on %s", pip_conf)
        backup = pip_conf.with_suffix(pip_conf.suffix + ".bak")
        if backup.exists():
            backup.chmod(stat.S_IRUSR | stat.S_IWUSR)

    return pip_conf


def reset_index() -> tuple[bool, str]:
    """Remove NDS index configuration from pip.conf.

    Restores from backup if available, otherwise removes NDS-specific entries.
    Returns (success, message).
    """
    pip_conf = get_pip_conf_path()
    if not pip_conf.exists():
        return True, "No pip configuration to reset"

    backup = pip_conf.with_suffix(pip_conf.suffix + ".bak")
    if backup.exists():
        import shutil
        shutil.copy2(backup, pip_conf)
        backup.unlink()
        return True, f"Restored pip.conf from backup"

    # No backup — remove NDS-specific entries
    config = configparser.ConfigParser()
    config.read(pip_conf)

    changed = False
    index_url = config.get("global", "index-url", fallback="")
    if ARTIFACTORY_HOST in index_url:
        config.remove_option("global", "index-url")
        changed = True

    extra_raw = config.get("global", "extra-index-url", fallback="")
    if ARTIFACTORY_HOST in extra_raw:
        # Keep non-NDS entries, remove NDS + PyPI that we added
        extras = [u.strip() for u in extra_raw.splitlines() if u.strip()]
        remaining = [u for u in extras if ARTIFACTORY_HOST not in u
                     and u != PUBLIC_PYPI_URL]
        if remaining:
            config.set("global", "extra-index-url", "\n".join(remaining))
        else:
            config.remove_option("global", "extra-index-url")
        changed = True

    if changed:
        # Remove empty [global] section
        if config.has_section("global") and not config.options("global"):
            config.remove_section("global")
        if config.sections():
            with open(pip_conf, "w") as f:
                config.write(f)
        else:
            pip_conf.unlink()
        return True, "NDS index entries removed from pip.conf"

    return True, "No NDS entries found in pip.conf"


def verify_index_access(
    username: str,
    token: str,
    opener: urllib.request.OpenerDirector | None = None,
) -> tuple[bool, str]:
    """Verify credentials against the NDS Python index."""
    from .config import get_effective_host
    host = get_effective_host()
    url = (
        f"https://{host}"
        f"/artifactory/api/pypi/tooling-pypi/simple/ndslive/"
    )
    credentials = base64.b64encode(
        f"{username}:{token}".encode()
    ).decode()

    request = urllib.request.Request(url)
    request.add_header("Authorization", f"Basic {credentials}")

    logger.info("Verifying index access for %s", username)
    open_fn = opener.open if opener else urllib.request.urlopen
    try:
        response = open_fn(request, timeout=10)
        logger.info("Index access verified (HTTP %s)", response.status)
        return True, f"Access verified (HTTP {response.status})"
    except urllib.error.HTTPError as e:
        if e.code == 401:
            logger.error("Index authentication failed (HTTP 401)")
            return False, "Authentication failed — check credentials"
        if e.code == 403:
            logger.error("Index access denied (HTTP 403)")
            return False, "Access denied — account may lack permissions"
        logger.error("Index HTTP error: %s", e.code)
        return False, f"HTTP error: {e.code}"
    except urllib.error.URLError as e:
        logger.error("Index connection failed: %s", e.reason)
        return False, f"Connection failed: {e.reason}"
    except Exception as e:
        logger.error("Index verification error: %s", e)
        return False, str(e)
