"""Docker registry authentication for NDS Artifactory."""

import json
from pathlib import Path

from .constants import DOCKER_REGISTRIES
from .log import get_logger

logger = get_logger("docker_registry")


def get_registry(edition: str) -> str:
    return DOCKER_REGISTRIES[edition]


def _get_registry_host(edition: str) -> str:
    return get_registry(edition).split("/")[0]


def is_logged_in(edition: str) -> bool:
    """Check if logged into the Docker registry for the given edition."""
    registry = get_registry(edition)
    host = _get_registry_host(edition)

    config_path = Path.home() / ".docker" / "config.json"
    if not config_path.exists():
        return False

    try:
        with open(config_path) as f:
            config = json.load(f)
    except (json.JSONDecodeError, OSError):
        return False

    auths = config.get("auths", {})
    for key in [host, f"https://{host}", registry, f"https://{registry}"]:
        auth = auths.get(key, {})
        if auth.get("auth") or auth.get("identitytoken"):
            return True

    if host in config.get("credHelpers", {}):
        return True

    if config.get("credsStore"):
        return True

    return False


def logout(edition: str) -> tuple[bool, str]:
    """Logout from Docker registry. Returns (success, message)."""
    registry = get_registry(edition)
    try:
        import subprocess
        result = subprocess.run(
            ["docker", "logout", registry],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            return True, f"Logged out of {registry}"
        return False, result.stderr.strip()
    except FileNotFoundError:
        return True, "Docker not installed, nothing to logout"
    except Exception as e:
        return False, str(e)


def check_docker_proxy_config() -> tuple[bool, str]:
    """Check if Docker has proxy configured in ~/.docker/config.json."""
    config_path = Path.home() / ".docker" / "config.json"
    if not config_path.exists():
        return False, "Docker config not found"
    try:
        with open(config_path) as f:
            config = json.load(f)
        proxies = config.get("proxies", {}).get("default", {})
        if proxies.get("httpProxy") or proxies.get("httpsProxy"):
            return True, "Docker proxy configured"
        return False, "Docker proxy not configured"
    except (json.JSONDecodeError, OSError):
        return False, "Could not read Docker config"


def login(edition: str, username: str, token: str) -> tuple[bool, str]:
    """Login to Docker registry. Returns (success, message)."""
    registry = get_registry(edition)
    logger.info("Logging into Docker registry %s", registry)
    try:
        import subprocess
        result = subprocess.run(
            ["docker", "login", "-u", username, "--password-stdin", registry],
            input=token,
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode == 0:
            logger.info("Docker login successful for %s", registry)
            return True, result.stdout.strip() or "Login succeeded"
        msg = result.stderr.strip()
        logger.error("Docker login failed for %s: %s", registry, msg)
        return False, f"Login failed: {msg}"
    except FileNotFoundError:
        logger.error("Docker CLI not found")
        return False, "Login failed: docker not installed"
    except Exception as e:
        logger.error("Docker login failed for %s: %s", registry, e)
        return False, f"Login failed: {e}"
