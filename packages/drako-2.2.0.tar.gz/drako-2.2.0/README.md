# Drako SDK

**The Trust Layer for AI Agents** — Scan for governance gaps offline. Enforce policies in production via the Drako platform.

[![PyPI](https://img.shields.io/pypi/v/drako.svg)](https://pypi.org/project/drako/)
[![Python](https://img.shields.io/pypi/pyversions/drako.svg)](https://pypi.org/project/drako/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

---

## Quick Start

### 1. Install

```bash
pip install drako
```

With framework-specific extras:

```bash
pip install drako[crewai]      # CrewAI support
pip install drako[langgraph]   # LangGraph support
pip install drako[autogen]     # AutoGen support
pip install drako[all]         # All frameworks
```

### 2. Scan Your Project (free, offline, no account needed)

```bash
drako scan .
# → Governance Score: 35/100 | 8 findings | Agent BOM: 3 agents, 12 tools
# → Run `drako auth login` to enable runtime governance
```

### 3. Connect to Platform (optional, enables runtime governance)

```bash
drako init
```

This will:
- Validate your API key
- Generate `.drako.yaml` config
- Create a framework-specific middleware file
- Enable runtime policy enforcement

### 4. Integrate Runtime Middleware

#### CrewAI

```python
from drako import with_compliance
from my_crew import MyCrew

crew = with_compliance(MyCrew())
result = crew.kickoff()
```

#### LangGraph

```python
from drako import with_langgraph_compliance

graph = with_langgraph_compliance(my_graph.compile())
result = graph.invoke(input)
```

#### AutoGen

```python
from drako import with_autogen_compliance

chat = with_autogen_compliance(my_group_chat)
```

#### Direct Client

```python
from drako import DrakoClient

client = DrakoClient.from_env()
result = client.verify_agent_identity_sync("my-agent", "researcher")
```

---

## CLI Commands

| Command | Description | Requires Account |
|---|---|:---:|
| `drako scan .` | Scan project for governance gaps | No |
| `drako init` | Initialize runtime SDK in your project | Yes |
| `drako status` | Check connection and quota status | Yes |
| `drako verify` | Verify audit hash chain integrity | Yes |
| `drako serve` | Start a local MCP compliance server | Yes |

---

## Configuration

`.drako.yaml`:

```yaml
version: "1.0"
tenant_id: your_tenant_id
api_key_env: DRAKO_API_KEY
endpoint: https://api.getdrako.com
framework: crewai

tools:
  audit_log_action: true
  verify_agent_identity: true
  evaluate_policy: true

guardrails:
  prompt_injection_detection: true
  dlp_scanning: false

trust:
  enabled: true
  decay_half_life_hours: 168
  circuit_breaker_threshold: 3
```

---

## Capabilities

### Scan CLI (free, offline)

| Capability | Status | Details |
|---|---|---|
| Governance Score | ✅ Built-in | 25 rules, 4 categories, deterministic evaluation |
| Agent BOM | ✅ Built-in | AST-based discovery, 6 frameworks |
| EU AI Act Gap Detection | ✅ Built-in | Art. 9, 11, 12, 14 mapping with fix snippets |
| SARIF 2.1.0 | ✅ Built-in | GitHub Code Scanning compatible |
| SVG Badge | ✅ Built-in | Embeddable governance badge |

### Runtime Platform (requires account)

| Capability | Status | Details |
|---|---|---|
| Policy Enforcement | ✅ Production | Real-time evaluation on tool calls |
| DLP/PII Detection | ✅ Production | Presidio-based, 8+ entity types, anonymization |
| Circuit Breaker | ✅ Production | State machine + EigenTrust scoring |
| Audit Trail | ✅ Production | SHA-256/BLAKE3 hash chain + digital signatures |
| Trust Score | ✅ Production | 0-100 dynamic score per agent |
| OTEL Export | 🔜 Next Sprint | OpenTelemetry semantic conventions |

---

## Environment Variables

| Variable | Description | Required |
|---|---|---:|
| `DRAKO_API_KEY` | Your API key (for runtime features) | For platform |
| `DRAKO_ENDPOINT` | Custom backend URL | No |
| `DRAKO_TENANT_ID` | Override tenant ID | No |

---

## Development

```bash
git clone https://github.com/agentmesh/drako-python.git
cd drako-python
pip install -e ".[dev]"
pytest
```

---

## License

MIT
