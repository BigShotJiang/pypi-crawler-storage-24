# TexTOM

TexTOM is an end-to-end Python toolbox for texture tomography, covering:
- detector-frame integration (pyFAI),
- projection alignment (Mumott-based workflows),
- physical model generation (diffractlets + projectors),
- orientation-distribution optimization,
- post-analysis and visualization.

## Documentation

- Web docs: https://textom.readthedocs.io/en/stable/
- PDF docs: [Download latest](https://gitlab.fresnel.fr/textom/textom/-/raw/main/textom/documentation/textom_documentation.pdf?ref_type=heads&inline=false)
- Project changelog: `CHANGELOG.md`

## Installation

### Requirements

- Python `>=3.9,<3.14`
- Linux/macOS (scientific stack availability may vary by platform)

### Recommended (conda/micromamba environment + pip)

```bash
conda create --name textom python=3.11
conda activate textom
python -m pip install --upgrade pip
python -m pip install textom
```

### From source (development)

```bash
git clone https://gitlab.fresnel.fr/textom/textom.git
cd textom
python -m pip install -e ".[test,docs]"
```

## Command-line entry points

After installation:

- `textom`: launches an IPython session with TexTOM API preloaded.
- `textom_config`: opens `textom/config.py` for runtime defaults.
- `textom_documentation`: opens the legacy PDF manual.

## Quickstart

Inside a sample working directory:

```bash
textom
```

Then in the IPython session:

```python
set_path(".")
check_state()
integrate()
align_data()
make_model()
preprocess_data()
optimize()
```

Typical outputs are created under:
- `analysis/` (intermediate products, models, fits),
- `data_integrated/` and optionally `data_integrated_1d/`,
- `results/` (derived metrics and exported artifacts).

For a complete walkthrough, follow:
- `docs/tutorials/workflow.md`
- `docs/how_to_guides/setup.md`
- `docs/how_to_guides/remote.md`

## Configuration

Use:

```bash
textom_config
```

Key runtime parameters in `textom/config.py` include thread count, GPU usage, numerical dtype, and UI behavior. Keep project-specific configs versioned when running in teams or CI.

## Development

Run tests:

```bash
pytest textom/tests
```

Run style checks:

```bash
isort --profile black --check-only --diff textom
ruff check .
ruff format --check .
```

Build docs:

```bash
sphinx-build -b html docs public
```

## Citation

If you use TexTOM in published work, cite:

Frewein, M. P. K., Mason, J., Maier, B., Colfen, H., Medjahed, A., Burghammer, M., Allain, M. & Grunewald, T. A. (2024). IUCrJ, 11, 809-820. https://doi.org/10.1107/S2052252524006547

## License

MIT License. See `LICENSE`.
