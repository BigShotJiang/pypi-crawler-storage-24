from pathlib import Path

import h5py
import numpy as np

from textom.src.integration import integration_launcher as launcher
from textom.src.integration import pyfai_plugins as plugins


class _Attrs:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


def _integration_parameters(path_in, mode=3):
    return _Attrs(
        path_in=str(path_in),
        h5_proj_pattern="scan*",
        h5_data_path="detector/data",
        h5_rot_angle_path="meta/rot",
        h5_tilt_angle_path="meta/tilt",
        h5_ty_path="meta/ty",
        h5_tz_path="meta/tz",
        h5_nfast_path=None,
        h5_nslow_path=None,
        h5_ion_path=None,
        h5_data_transmission_path=None,
        mode=mode,
        npt_rad_1D=5,
        npt_rad=6,
        npt_azi=4,
        rad_range=(0.0, 1.0),
        azi_range=(-180.0, 180.0),
        rad_unit="q_nm^-1",
        int_method=("bbox", "csr", "cython"),
        solidangle_correction=False,
        darkcurrent_correction=None,
        polarisation_factor=0.95,
        mask_path="unused.edf",
        poni_path="unused.poni",
    )


def _write_input_h5(path, shape=(8, 8)):
    with h5py.File(path, "w") as f:
        for idx in (1, 2):
            grp = f.create_group(f"scan{idx}")
            grp.create_dataset(
                "detector/data",
                data=np.ones((2, shape[0], shape[1]), dtype=np.float32) * idx,
            )
            grp.create_dataset("meta/rot", data=np.array(1.5 * idx))
            grp.create_dataset("meta/tilt", data=np.array(0.5 * idx))
            grp.create_dataset("meta/ty", data=np.array(0.1 * idx))
            grp.create_dataset("meta/tz", data=np.array(0.2 * idx))
        f.create_group("noise")


def _write_integration_parameters(
    sample_dir,
    path_in,
    mask_path,
    poni_path,
    flatfield_correction=None,
    mode=3,
    n_tasks=2,
    average_frames=1,
):
    intpar_path = Path(sample_dir) / "integration_parameters.py"
    intpar_path.write_text(
        "\n".join(
            [
                f"path_in = {str(path_in)!r}",
                "h5_proj_pattern = 'scan*'",
                "h5_data_path = 'detector/data'",
                "h5_rot_angle_path = 'meta/rot'",
                "h5_tilt_angle_path = 'meta/tilt'",
                "h5_ty_path = 'meta/ty'",
                "h5_tz_path = 'meta/tz'",
                "h5_nfast_path = None",
                "h5_nslow_path = None",
                "h5_ion_path = None",
                "h5_data_transmission_path = None",
                f"mode = {mode}",
                "npt_rad_1D = 11",
                "npt_rad = 12",
                "npt_azi = 8",
                "rad_range = (0.0, 1.0)",
                "azi_range = (-180.0, 180.0)",
                "rad_unit = 'q_nm^-1'",
                "int_method = ('bbox', 'csr', 'cython')",
                "solidangle_correction = False",
                "darkcurrent_correction = None",
                "polarisation_factor = 0.95",
                f"flatfield_correction = {flatfield_correction!r}",
                f"mask_path = {str(mask_path)!r}",
                f"poni_path = {str(poni_path)!r}",
                f"average_frames = {average_frames}",
                f"n_tasks = {n_tasks}",
                "cores_per_task = 1",
            ]
        )
        + "\n"
    )
    return intpar_path


def _write_geometry_file(sample_dir):
    geo_path = Path(sample_dir) / "geometry.py"
    geo_path.write_text(
        "\n".join(
            [
                "flip_detector_lr = False",
                "flip_detector_ud = False",
                "detector_direction_origin = (0, -1, 0)",
                "detector_direction_positive_90 = (0, 0, -1)",
            ]
        )
        + "\n"
    )
    return geo_path


def test_update_filelist_skips_integrated_outputs(tmp_path):
    sample_dir = tmp_path
    input_h5 = sample_dir / "raw.h5"
    _write_input_h5(input_h5)
    par = _integration_parameters(input_h5, mode=1)
    (sample_dir / "data_integrated_1d").mkdir(parents=True)
    (sample_dir / "data_integrated_1d" / "scan1_integrate_1d.h5").touch()

    fid_in, datasets = plugins.update_filelist(str(sample_dir), par, ignore=[])
    try:
        assert datasets == ["scan2"]
    finally:
        fid_in.close()


def test_flexible_integrator_writes_1d_and_2d_outputs(tmp_path):
    pyfai = __import__("pyFAI")
    sample_dir = tmp_path
    shape = (16, 16)
    poni_path, mask_path, mask = _real_pyfai_files(sample_dir, shape=shape)
    input_h5 = sample_dir / "raw.h5"
    _write_input_h5(input_h5, shape=shape)
    par = _integration_parameters(input_h5, mode=3)
    par.npt_rad_1D = 9
    par.npt_rad = 10
    par.npt_azi = 7
    par.mask_path = mask_path
    par.poni_path = poni_path
    ai = pyfai.load(poni_path)

    with h5py.File(input_h5, "r") as fid_in:
        plugins.flexible_integrator(
            str(sample_dir),
            fid_in,
            "scan1",
            par,
            ai,
            flat=None,
            mask=mask,
            average_frames=1,
        )

    out_1d = sample_dir / "data_integrated_1d" / "scan1_integrate_1d.h5"
    out_2d = sample_dir / "data_integrated" / "scan1_integrate_2d.h5"
    assert out_1d.is_file()
    assert out_2d.is_file()

    with h5py.File(out_1d, "r") as f1:
        assert f1["cake_integ"].shape == (2, par.npt_rad_1D)
        assert f1["radial_units"].shape == (1, par.npt_rad_1D)
        assert np.asarray(f1["rot_angle"]).shape == ()

    with h5py.File(out_2d, "r") as f2:
        assert f2["cake_integ"].shape == (2, par.npt_azi, par.npt_rad)
        assert f2["azimuthal_units"].shape == (1, par.npt_azi)
        assert np.asarray(f2["ty"]).shape == ()


def _real_pyfai_files(sample_dir, shape=(32, 32)):
    from fabio.edfimage import EdfImage
    from pyFAI.detectors import Detector
    from pyFAI.integrator.azimuthal import AzimuthalIntegrator

    mask = np.zeros(shape, dtype=np.uint8)
    mask[:, :3] = 1
    mask_path = sample_dir / "mask.edf"
    EdfImage(data=mask).write(str(mask_path))

    detector = Detector(pixel1=1e-4, pixel2=1e-4, max_shape=shape)
    ai = AzimuthalIntegrator(
        dist=0.2,
        poni1=shape[0] * 1e-4 / 2.0,
        poni2=shape[1] * 1e-4 / 2.0,
        wavelength=1e-10,
        detector=detector,
    )
    poni_path = sample_dir / "geometry.poni"
    ai.save(str(poni_path))
    return str(poni_path), str(mask_path), mask


def test_generate_caked_detector_mask_matches_real_pyfai_reference(tmp_path):
    pyfai = __import__("pyFAI")
    sample_dir = tmp_path
    poni_path, mask_path, mask = _real_pyfai_files(sample_dir, shape=(16, 16))
    par = _integration_parameters(sample_dir / "unused.h5")
    par.npt_rad = 10
    par.npt_azi = 9
    par.mask_path = mask_path
    par.poni_path = poni_path

    plugins.generate_caked_detector_mask(str(sample_dir), par)
    with h5py.File(sample_dir / "analysis" / "mask_detector_cake.h5", "r") as f:
        observed = np.asarray(f["mask_cake"])

    ai = pyfai.load(poni_path)
    expected = ai.integrate2d(
        np.ones_like(mask, dtype=np.float32),
        par.npt_rad,
        par.npt_azi,
        radial_range=par.rad_range,
        azimuth_range=par.azi_range,
        unit=par.rad_unit,
        method=par.int_method,
        correctSolidAngle=par.solidangle_correction,
        mask=mask,
        safe=False,
    ).intensity
    np.testing.assert_allclose(observed, expected, rtol=1e-6, atol=1e-7)


def test_flexible_integrator_matches_real_pyfai_reference(tmp_path):
    pyfai = __import__("pyFAI")
    sample_dir = tmp_path
    shape = (20, 20)
    poni_path, mask_path, mask = _real_pyfai_files(sample_dir, shape=shape)
    input_h5 = sample_dir / "raw.h5"
    frames = np.stack(
        [
            np.linspace(0.0, 2.0, shape[0] * shape[1], dtype=np.float32).reshape(shape),
            np.linspace(2.0, 0.0, shape[0] * shape[1], dtype=np.float32).reshape(shape),
        ],
        axis=0,
    )
    with h5py.File(input_h5, "w") as f:
        grp = f.create_group("scan1")
        grp.create_dataset("detector/data", data=frames)
        grp.create_dataset("meta/rot", data=np.array(1.0))
        grp.create_dataset("meta/tilt", data=np.array(0.2))
        grp.create_dataset("meta/ty", data=np.array(0.3))
        grp.create_dataset("meta/tz", data=np.array(0.4))

    par = _integration_parameters(input_h5, mode=3)
    par.npt_rad_1D = 11
    par.npt_rad = 12
    par.npt_azi = 8
    par.mask_path = mask_path
    par.poni_path = poni_path
    ai = pyfai.load(poni_path)

    with h5py.File(input_h5, "r") as fid_in:
        plugins.flexible_integrator(
            str(sample_dir),
            fid_in,
            "scan1",
            par,
            ai,
            flat=None,
            mask=mask,
            average_frames=1,
        )

    expected_1d = []
    expected_2d = []
    expected_radial_1d = None
    expected_radial_2d = None
    expected_azimuthal = None
    for frame in frames:
        r1 = ai.integrate1d(
            frame,
            par.npt_rad_1D,
            radial_range=par.rad_range,
            unit=par.rad_unit,
            method=par.int_method,
            correctSolidAngle=par.solidangle_correction,
            dark=par.darkcurrent_correction,
            flat=None,
            mask=mask,
            polarization_factor=par.polarisation_factor,
            safe=False,
        )
        r2 = ai.integrate2d(
            frame,
            par.npt_rad,
            par.npt_azi,
            radial_range=par.rad_range,
            azimuth_range=par.azi_range,
            unit=par.rad_unit,
            method=par.int_method,
            correctSolidAngle=par.solidangle_correction,
            dark=par.darkcurrent_correction,
            flat=None,
            mask=mask,
            polarization_factor=par.polarisation_factor,
            safe=False,
        )
        expected_1d.append(r1.intensity)
        expected_2d.append(r2.intensity)
        expected_radial_1d = r1.radial
        expected_radial_2d = r2.radial
        expected_azimuthal = r2.azimuthal

    with h5py.File(
        sample_dir / "data_integrated_1d" / "scan1_integrate_1d.h5", "r"
    ) as f1:
        observed_1d = np.asarray(f1["cake_integ"])
        observed_radial_1d = np.asarray(f1["radial_units"])[0]
    with h5py.File(sample_dir / "data_integrated" / "scan1_integrate_2d.h5", "r") as f2:
        observed_2d = np.asarray(f2["cake_integ"])
        observed_radial_2d = np.asarray(f2["radial_units"])[0]
        observed_azimuthal = np.asarray(f2["azimuthal_units"])[0]

    np.testing.assert_allclose(
        observed_1d, np.asarray(expected_1d), rtol=1e-6, atol=1e-7
    )
    np.testing.assert_allclose(
        observed_2d, np.asarray(expected_2d), rtol=1e-6, atol=1e-7
    )
    np.testing.assert_allclose(
        observed_radial_1d, expected_radial_1d, rtol=1e-7, atol=1e-8
    )
    np.testing.assert_allclose(
        observed_radial_2d, expected_radial_2d, rtol=1e-7, atol=1e-8
    )
    np.testing.assert_allclose(
        observed_azimuthal, expected_azimuthal, rtol=1e-7, atol=1e-8
    )


def test_start_integration_online_uses_real_pyfai(tmp_path):
    from fabio.edfimage import EdfImage

    sample_dir = tmp_path
    shape = (18, 18)
    poni_path, mask_path, _ = _real_pyfai_files(sample_dir, shape=shape)
    flat_path = sample_dir / "flat.edf"
    EdfImage(data=np.ones(shape, dtype=np.float32)).write(str(flat_path))
    input_h5 = sample_dir / "raw.h5"
    _write_input_h5(input_h5, shape=shape)
    _write_integration_parameters(
        sample_dir,
        path_in=input_h5,
        mask_path=mask_path,
        poni_path=poni_path,
        flatfield_correction=str(flat_path),
        mode=3,
        n_tasks=1,
        average_frames=2,
    )

    plugins.start_integration_online(
        str(sample_dir), wait=0.0, confirm=False, ignore=[], parallel=False
    )

    out_1d = sample_dir / "data_integrated_1d"
    out_2d = sample_dir / "data_integrated"
    assert (out_1d / "scan1_integrate_1d.h5").is_file()
    assert (out_1d / "scan2_integrate_1d.h5").is_file()
    assert (out_2d / "scan1_integrate_2d.h5").is_file()
    assert (out_2d / "scan2_integrate_2d.h5").is_file()


def test_start_integration_online_raises_for_missing_poni(tmp_path):
    sample_dir = tmp_path
    shape = (8, 8)
    _poni_path, mask_path, _ = _real_pyfai_files(sample_dir, shape=shape)
    input_h5 = sample_dir / "raw.h5"
    _write_input_h5(input_h5, shape=shape)
    _write_integration_parameters(
        sample_dir,
        path_in=input_h5,
        mask_path=mask_path,
        poni_path=sample_dir / "missing.poni",
        flatfield_correction=None,
        mode=3,
        n_tasks=1,
    )
    try:
        plugins.start_integration_online(
            str(sample_dir), wait=0.0, confirm=False, ignore=[], parallel=False
        )
        assert False, "Expected FileNotFoundError"
    except FileNotFoundError:
        pass


def test_start_test_integration_uses_real_pyfai_and_renames_outputs(tmp_path):
    sample_dir = tmp_path
    shape = (16, 16)
    poni_path, mask_path, _ = _real_pyfai_files(sample_dir, shape=shape)
    input_h5 = sample_dir / "raw.h5"
    _write_input_h5(input_h5, shape=shape)
    _write_integration_parameters(
        sample_dir,
        path_in=input_h5,
        mask_path=mask_path,
        poni_path=poni_path,
        flatfield_correction=None,
        mode=3,
        n_tasks=1,
    )

    outputs = plugins.start_test_integration(str(sample_dir), dset_no=0, confirm=False)
    assert len(outputs) == 2
    assert all(path.endswith("_test.h5") for path in outputs)
    for out in outputs:
        assert Path(out).is_file()


def test_check_detector_geometry_runs_real_pyfai_integration(tmp_path):
    sample_dir = tmp_path
    shape = (14, 14)
    poni_path, mask_path, _ = _real_pyfai_files(sample_dir, shape=shape)
    testfile = sample_dir / "raw.h5"
    with h5py.File(testfile, "w") as f:
        grp = f.create_group("scan1")
        grp.create_dataset(
            "detector/data",
            data=np.ones((1, shape[0], shape[1]), dtype=np.float32),
        )
    intpar_path = _write_integration_parameters(
        sample_dir,
        path_in=testfile,
        mask_path=mask_path,
        poni_path=poni_path,
        flatfield_correction=None,
        mode=3,
        n_tasks=1,
    )
    geo_path = _write_geometry_file(sample_dir)
    plugins.plt.switch_backend("Agg")

    plugins.check_detector_geometry(
        intpar_path=str(intpar_path),
        testfile=str(testfile),
        testfile_dataset="scan1",
        frame_no=0,
        geo_path=str(geo_path),
    )


def test_parallel_launcher_loads_real_pyfai_and_dispatches_work(tmp_path):
    sample_dir = tmp_path
    shape = (12, 12)
    poni_path, mask_path, _ = _real_pyfai_files(sample_dir, shape=shape)
    input_h5 = sample_dir / "raw.h5"
    _write_input_h5(input_h5, shape=shape)
    _write_integration_parameters(
        sample_dir,
        path_in=input_h5,
        mask_path=mask_path,
        poni_path=poni_path,
        flatfield_correction=None,
        mode=3,
        n_tasks=2,
    )

    launcher.parallel_launcher(k_task=1, sample_dir=str(sample_dir))
    assert not (sample_dir / "data_integrated" / "scan1_integrate_2d.h5").exists()
    assert (sample_dir / "data_integrated" / "scan2_integrate_2d.h5").is_file()
    assert not (sample_dir / "data_integrated" / "scan3_integrate_2d.h5").exists()
