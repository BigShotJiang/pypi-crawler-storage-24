import os

import h5py
import numpy as np

import textom.src.creator as create
import textom.src.misc as msc
import textom.src.model.model_crystal as cry
import textom.src.model.model_textom as model_textom
import textom.src.model.rotation as rot

sample_dir = "/Users/moritz/Documents/papers/benchmark/gen_sample/"

crt_pars = create.setup_generated_sample(sample_dir)
mod = model_textom(
    sample_dir, q_det=crt_pars.q_det, chi_det=crt_pars.chi_det, classic=False
)
# crt.plot_basefunction_texture(crt_pars.grid_resolution, mod, (0,0,0))

cr = msc.import_module_from_path(
    "crystal", os.path.join(sample_dir, "analysis", "crystal.py")
)
geo = msc.import_module_from_path(
    "geometry", os.path.join(sample_dir, "analysis", "geometry.py")
)
# cry.plot_powder_pattern(cr.cifPath, cutoff_structure_factor=1e-2, max_hkl=4, q_max=crt_pars.q_det.max())
# cry.plot_single_crystal_pattern(cr, axis=2)

sample_rotations = rot.QfromOTP(mod.Gc)

Qq_det, Chi_det, hkl, difflets = cry.get_diffractlets(
    cr,
    crt_pars.chi_det * np.pi / 180,
    geo,
    sample_rotations,
    grid_resolution=60,
    cutoff_structure_factor=1e-2,
    odf_mode="grid",
)
# cry.plot_diffractlet(Qq_det, Chi_det, hkl, difflets[0], q_bins=np.linspace(*cr.q_range),
#                      cmap='plasma', sym_cmap=False, logscale=True
#                      )
# cry.plot_diffractlet(Qq_det, Chi_det, hkl, difflets[1], q_bins=np.linspace(*cr.q_range),
#                      cmap='plasma', sym_cmap=False, logscale=True
#                      )
with h5py.File(os.path.join(sample_dir, "analysis", "difflets_grid.h5"), "w") as hf:
    hf.create_dataset("q_values", data=Qq_det)
    hf.create_dataset("chi_values", data=Chi_det)
    hf.create_dataset("sample_rotations", data=sample_rotations)
    hf.create_dataset("difflets", data=difflets)

## tbc
