# imports for Isc
import os  # data handling
import sys
from time import time

import h5py
import matplotlib.pyplot as plt  # plotting
import numpy as np  # maths

# for external functions that have been modified (define_angles and generators)
import orix.quaternion.symmetry as osym
import rotation as rot
from ase.io import read  # for reading .cif files

# for 3, Miller strufact
from cctbx import crystal, miller, sgtbx, uctbx

# for 2, integrate diffractlets
from generators import (
    generators,  # !!my generators version has g1 = [2pi,2pi,2pi] instead of [0,0,0]!!
)
from iotbx import cif
from numba import njit, prange  # parallelization
from scipy.sparse import csc_array  # ,csr_array, bsr_array could possibly be faster
from scipy.spatial.transform import Rotation as R  # numba isn't happy
from scipy.special import i0

# from rotation import define_angles #!!my define angles doesn't have try except!!
import textom.src.handle as hdl
import textom.src.model.model_crystal as cry
import textom.src.model.symmetries as sym

data_type = np.float64


# modified external functions (explanation why, next to function)
def generators(proper_point_group):  # had dividing by zero error in fisherSO3
    """Provides the symmetry generators for the given point group
    by 3 angles for axis-angle parametrization [omega, theta, phi]

    Parameters
    ----------
    proper_point_group : str
        name of the crystal symmetry, taken from a provided table

    Return values
    ------------
    gen : 2D ndarray, float
        2 symmetry generators in OTP representation
        [[ome1,tta1,phi1], [ome2,tta2,phi2]]
    """
    # change notes: changed g1, to not encounter 0s
    g1 = [
        2 * np.pi,
        2 * np.pi,
        2 * np.pi,
    ]  # modified from 0,0,0 # no rotation, any mirror, glide or rotation-inversion

    g2z = [np.pi, 0.0, 0.0]  # 2nd order rotation around [001]: 2, 2/m
    g2p = [np.pi, np.pi / 2, 0.0]  # 2nd order rotation around [100]: _2, _2/m
    g2d = [np.pi, np.pi / 2, np.pi / 4]  # 2nd order rotation around [110]

    g3z = [2 * np.pi / 3, 0.0, 0.0]  # 3rd order rotation around [001]: 3, 3/m
    g3d = [
        2 * np.pi / 3,
        np.arctan(np.sqrt(2)),
        np.pi / 4,
    ]  # 3rd order rotation around [111]: _3

    g4z = [np.pi / 2, 0.0, 0.0]  # 4th order rotation around [001]: 4, 4/m
    g4p = [np.pi / 2, np.pi / 2, 0.0]  # 4th order rotation around [100]: 4, 4/m

    g6z = [np.pi / 3, 0.0, 0.0]  # 3rd order rotation around [001]: 6, 6/m

    match proper_point_group:
        case "1" | "C1":  # 1, m // C1
            gen = np.array((g1, g1), data_type)
        case "2" | "C2":  # 2, 2/m, mm2, -4 // C2
            gen = np.array((g2z, g1), data_type)
        case "222" | "D2":  # 222, mmm, -42m // D2
            gen = np.array((g2z, g2p), data_type)
        case "4" | "C4":  # 4, 4/m // C4
            gen = np.array((g4z, g1), data_type)
        case "422" | "D4":  # 422, 4/mmm // D4
            gen = np.array((g4z, g2p), data_type)
        case "3" | "C3":  # 3, 3m1, 31m, -3, -6 // C3
            gen = np.array((g3z, g1), data_type)
        case "32" | "D3":  # 321, 312, -31m, -3m1, -6m2 // D3
            gen = np.array((g3z, g2p), data_type)
        case "6" | "C6":  # 6, 6/m, 6mm // C6
            gen = np.array((g6z, g1), data_type)
        case "622" | "D6":  # 622, 6/mmm // D6
            gen = np.array((g6z, g2p), data_type)
        case "23" | "T":  # 23, -43m,  m-3 // T
            gen = np.array((g2z, g3d), data_type)
        case "432" | "O":  # 432, m-3m // O
            gen = np.array((g4z, g3d), data_type)
        case _:
            print("Point group not recognized")
            sys.exit(1)
    return gen


def define_angles(
    dchi=2 * np.pi / 120, sampling="cubochoric", symmetry="222"
):  # always skipped into except, so I couldn't obtain cubochoric sampling
    """Defines the grid of angles for crystallite rotation

    Parameters
    ----------
    dchi : _type_, optional
        _description_, by default 2*np.pi/120
    sampling : str, optional
        _description_, by default 'cubochoric'
    symmetry : str, optional
        _description_, by default '222'

    Returns
    -------
    Gc : 2D ndarray, float
        register of axis-angle rotations
        dim: 0: rotation index, 1: [omega, theta, phi]
    dV : 1D ndarray, float
        volume element for integrating over the odf
        dim: 0: rotation index
    V_fz : float
        volume of the fundamental zone
    """
    # Changes: deleted try-except statement, as it sometimes skipped cubochoric sampling (for no apparent reason)
    if sampling == "cubochoric":
        pg = getattr(osym, sym.get_SFnotation(symmetry))
        rot_orix = rot.get_sample_fundamental(
            dchi * 180 / np.pi, point_group=pg, method=sampling
        )

        Gc = rot.OTPfromQ(rot_orix.data)

        # cubochoric is equal volume mapped
        # Sing and De Graef, 2016
        dV = dchi**3 * np.ones(Gc.shape[0], data_type)

    if sampling == "simple":
        ## set up angles used to rotate the single crystal patterns
        ome = np.linspace(dchi / 2, np.pi - dchi / 2, int(np.pi / dchi), endpoint=True)
        tta = np.linspace(dchi / 2, np.pi - dchi / 2, int(np.pi / dchi), endpoint=True)
        phi = np.linspace(0, 2 * np.pi, int(2 * np.pi / dchi), endpoint=False)
        TTA, PHI, OME = np.meshgrid(tta, phi, ome)
        Ome, Tta, Phi = OME.flatten(), TTA.flatten(), PHI.flatten()
        Gc = np.column_stack((Ome, Tta, Phi))

        ## apply the crystal symmetry conditions on Tta, Phi, Ome, so in the following
        # only these are calculated by only choosing rotations in the fundamental zone
        # of the proper point group
        fz = sym.zone(symmetry, Gc)
        Tta, Phi, Ome = (
            Tta[fz],
            Phi[fz],
            Ome[fz],
        )  # these are the angles that effectively will be used
        Gc = Gc[fz]  # cut away the redundand ones from the rotation array

        # volume element for integrating over the odf
        # see Mason/Patala, arXiv (2019), appendix C
        # omitted factor 1/2 here, since we use omega only from 0 to pi
        dV = np.sin(Ome / 2) ** 2 * np.sin(Tta) * dchi**3

    # import matplotlib.pyplot as plt
    # fig = plt.figure(figsize=(15, 10))
    # scatter_kwargs = dict(
    #     projection="rodrigues",
    #     figure=fig,
    #     wireframe_kwargs=dict(color="k", linewidth=1, alpha=0.1),
    #     s=5,
    # )
    # ori_plain = Orientation(Rotation([rot.QfromOTP( Gc)]), symmetry=pg).get_random_sample(10000)
    # ori_orix = Orientation(rot_orix, symmetry=pg).get_random_sample(10000)
    # ori_orix.scatter(position=231, c="C0", **scatter_kwargs)
    # ori_plain.scatter(position=232, c="C1", **scatter_kwargs)
    # # ori_quat2.scatter(position=233, c="C2", **scatter_kwargs)

    # ori_orix.scatter(position=234, c="C0", **scatter_kwargs)
    # ori_plain.scatter(position=235, c="C1", **scatter_kwargs)
    # # ori_quat2.scatter(position=236, c="C2", **scatter_kwargs)

    # titles = ["cubochoric", "plain"]#, "quaternion"]
    # for i, title in zip([0, 1], titles):
    #     fig.axes[i].view_init(elev=90, azim=0)
    #     fig.axes[i].set_title(titles[i])
    # for i in [2, 3]:
    #     fig.axes[i].view_init(elev=0, azim=0)

    # volume of the fundamental zone [rad^3]
    V_fz = dV.sum()
    return Gc, dV, V_fz


# 1 single crystal diffraction patterns (diffractlets_cajetan)
def calculate_single_crystal(crystal_dims, cifpath, E_keV, q, n_chi, sampling, h5path):
    """Calculates single crystal diffraction patterns and powder pattern.
        Stores those in an .h5 File, along with parameters.
    Parameters
    -----------
    crystal_dims: tuple, float
        crystal sizes in x,y,z directions in nm
    cif_path: string
        path to cif file at the basis of the simulation
    E_keV: float
        xray energy in keV
    q: 1D ndarray, float
        linspace with absolute values of sampled qs
    n_chi: int
        number of azimuthal bins
    sampling: string
        'cubochoric' or 'simple'
    h5path: string
        desired path and name of created h5 file
    Attributes created
    ------------
    Qq_det, Chi_det : 1D ndarray, float
        flattened meshgrids of detector point polar coordinates
        dim: 0: detector point index
    detShape : tuple, int
        number of detector points (n_q, n_chi)
    Natom : int
        number of atoms in the simulated crystal
    Isc : 2D ndarray, float
        flattened meshgrids of detector point polar coordinates
        dim: 0: rotation index, dim 1: detector point index
    difflets : 2D ndarray, float
        powder pattern/zero order diffractlet (others to be added)
        dim: 0: sHSH index, 1: detector point index
    """
    start = time()
    # initialize chi and dchi from n_chi
    chi = np.linspace(0, 2 * np.pi, n_chi, endpoint=False) + 2 * np.pi / n_chi / 2
    dchi = 2 * np.pi / n_chi  # could also be passed down

    ## calculate Ewald's sphere for each rotation given by the HSHs
    # calculate the incoming wavevector
    h = 4.135667696e-18  # keV*s
    c = 299792458  # m/s
    kXray = 2 * np.pi * E_keV / (h * c * 1e9)  # wavevector in 1/nm

    # coordinates on detector
    Qq_det, Chi_det, detShape = rot.qchi(q, chi)
    # azimutal angle with respect to the beam for the points of Ewald's sphere
    Tta_ew = np.pi - np.arctan(np.sqrt(kXray**2 - Qq_det**2 / 4) * 2 / Qq_det)
    # coordinates of Ewald's sphere in reciprocal space
    QX_ew = Qq_det * np.cos(Tta_ew)
    QY_ew = -Qq_det * np.sin(Tta_ew) * np.sin(Chi_det)
    QZ_ew = Qq_det * np.sin(Tta_ew) * np.cos(Chi_det)
    Q_ew = np.column_stack([QX_ew, QY_ew, QZ_ew])
    # number of points on detector
    Ndet = Tta_ew.shape[0]

    # textom.crystal does not return the same unit cell as ase
    unit = read(cifpath)  # Read the CIF file via ase
    uc_pos = unit.positions / 10  # coordinates of all atoms converted to nm
    uc_chem = np.array(unit.get_chemical_symbols())
    lattice_vectors = unit.cell.array / 10  # nm not thoroughly tested

    # old version used textom for the cif parsing. If buggy consider reactivating.
    # make the real space crystal
    crystal_data = cry.parse_cif(cifpath)
    # uc_pos  = crystal_data['cartesian_positions']/10 # coordinates of all atoms in the unit cell converted to nm
    # uc_chem  = crystal_data['atom_list'] # chemical symbols of all atoms in the unit cell
    # lattice_vectors = crystal_data['lattice_vectors']/10 #nm

    elements = np.unique(uc_chem)  # all used elements
    Nel = elements.size  # number of elements

    symmetry = sym.get_diffraction_laue_group(crystal_data["space_group"])

    Gc, dV, V_fz = define_angles(dchi, sampling, symmetry)
    print("\n\t Number of Orientations:", Gc.shape[0])

    ##This part, the calculation of the crystal size, can be made better but is in no case essential
    # lengths of lattice vectors in their "main" direction
    a = lattice_vectors[0][0]
    b = lattice_vectors[1][1]
    c = lattice_vectors[2][2]
    x, y, z = crystal_dims

    # crystalsize in powers of two along the lattice direction, close to the desired input
    crystalsize = 2 ** np.round(np.log2([x / a, y / b, z / c]))
    crystalsize = crystalsize.astype(int)

    ##Override option if we want certain amounts of UCs e.g. for debugging
    # crystalsize=np.array([8,8,8])  #for chosen dimensions
    # crystalsize=np.array(crystal_dims) #so input is already in crystal vectors

    print(
        "\t Size of simulated crystal:",
        crystalsize,
        "\n \t Which equals:",
        crystalsize * np.array([a, b, c]),
        "nm",
    )
    print("\t Number of lattice points: %u" % np.prod(crystalsize))
    print("\t Unit cell size:", uc_pos.shape[0])
    # Get atomic form factor coefficients from lookup table parametrized trough a, b, c
    ff_path = hdl.get_file_path(
        "textom", os.path.join("ressources", "atomic_formfactors.txt")
    )
    ffcoeff = np.genfromtxt(ff_path, dtype="|U8", skip_header=2)
    ffcoeff_used = np.array(
        [ffcoeff[np.where(el == ffcoeff)[0][0], 1:] for el in elements]
    ).astype(data_type)
    a = ffcoeff_used[:, 0:-1:2]
    b = ffcoeff_used[:, 1:-1:2]
    c = ffcoeff_used[:, -1]

    FF_el = np.empty(
        (Nel, Ndet), data_type
    )  # atomic form factors for all used elements
    for k in range(Nel):
        A, Qf = np.meshgrid(a[k], q / 10)  # using angstroems^-1 here for simplicity
        B, _ = np.meshgrid(b[k], q)
        C = c[k]
        # Calculate form factor http://lampx.tugraz.at/~hadley/ss1/crystaldiffraction/atomicformfactors/formfactors.php
        F = (A * np.exp(-B * (Qf / (4 * np.pi)) ** 2)).sum(axis=1) + C
        _, FF = np.meshgrid(Chi_det.reshape(detShape)[0], F)
        FF_el[k, :] = FF.flatten()

    # rotate the crystal in all chosen orientations
    uc_pos_rot = rot.stack_mrot(uc_pos.astype(data_type), Gc)
    lattice_vectors_rot = rot.stack_mrot(lattice_vectors.astype(data_type), Gc)

    # bool mask for the unit cell
    bool_pos_el = np.empty((Nel, uc_chem.shape[0]), bool)
    for k in range(Nel):
        # determinate the positions of element k
        bool_pos_el[k, :] = uc_chem == elements[k]

    # calculate structure factors
    print(
        "\t recursively calculating single crystal diffraction patterns \n(long calculation time possible, do not close terminal)"
    )
    t0 = time()
    Isc = single_crystal_images(
        Q_ew, uc_pos_rot, bool_pos_el, FF_el, crystalsize, lattice_vectors_rot
    )
    print("\t\t took %.2f seconds" % (time() - t0))

    # Calculate powder pattern/zero order diffractlet
    # t1 = time()
    powder = (
        ((1 / V_fz * dV) @ Isc).reshape(detShape).sum(axis=1)
    )  # integrate over all rotations

    # print(f"\t\tPowder integral took {(time()-t1):.2f} seconds")
    difflet0_2D = ((1 / V_fz * dV) @ Isc).reshape(
        detShape
    )  # integrate over all rotations
    for iq in range(detShape[0]):
        difflet0_2D[iq, :] = np.mean(difflet0_2D[iq, :])  # flatten it over the angles
    difflets = difflet0_2D.flatten().reshape([1, difflet0_2D.size])
    duration = time() - start
    # difflets = np.array([diffi]])
    print("Creating h5 file asdf")
    # save the diffraction patterns
    with h5py.File(h5path, "w") as hf:
        hf.create_dataset("Isc", data=Isc, compression="lzf")
        hf.create_dataset("powder", data=powder, compression="lzf")
        hf.create_dataset("difflets", data=difflets)
        hf.create_dataset("simulation_time", data=duration)
        hf.create_dataset("cif_file", data=cifpath)
        hf.create_dataset("Energy_keV", data=E_keV)
        hf.create_dataset("Ang_resolution", data=dchi * 180 / np.pi)
        hf.create_dataset("sampling", data=sampling)
        hf.create_dataset("q", data=q)
        hf.create_dataset("crystal_size", data=crystal_dims)
        hf.create_dataset(
            "symmetry", data=sym.get_diffraction_laue_group(crystal_data["space_group"])
        )
        hf.create_dataset("Gc", data=Gc)
        hf.create_dataset("dV", data=dV)
        hf.create_dataset("V_fz", data=V_fz)
        hf.create_dataset("detShape", data=detShape)
        hf.create_dataset("Chi_det", data=Chi_det)
        hf.create_dataset("Qq_det", data=Qq_det)
        hf.create_dataset("lattice_vectors", data=lattice_vectors)

    return  # Isc, powder


@njit(parallel=True)
def single_crystal_images(
    Q, uc_pos_rot, bool_pos_el, F_el, crystalsize, lattice_vectors_rot
):
    """
    Calculation of the scattering intensities of a single crystal

    parameters
    ----------
    Q: 2D ndarray, float
        momentum exchange vector
        dim0: reciprocal lattice points, 1: [qx,qy,qz]
    uc_pos_rot: 3D ndarray, float
        atom position in the unit cell for all crystal rotations
        dim0: rotation, 1: real space positions, 2: [x,y,z]
    bool_pos_el : 2D ndarray, string
        mask for uc_pos to find elements
        dim0: element dim1: mask for positions in uc
    F_el : 2D ndarray, float
        atomic form factor
        dim 0: elements, 1: reciprocal lattice points
    crystalsize: 1D ndarray len=3
        dim: size along the three crystal axes
    lattice_vectors_rot: 3D ndarray, float
        dim0: rotations, 1:three lattice directions, 2: lattice vector in current orientation
    Return values
    ------------
    Isc : 2D ndarray, float
        refraction intensities in Q-spaces for all orientations
        dim 0: orientations, 1: for wave vector
    """
    Ndet = Q.shape[0]  # number of detector bins
    Nrot = uc_pos_rot.shape[0]  # number of rotations
    Isc = np.empty((Nrot, Ndet), data_type)  # single crystal diffraction patterns
    for g in prange(Nrot):  # for each orientation
        uc_pos = uc_pos_rot[g]  # get the positions of the atoms in the unit cell
        # calculate structure factors of lattice and the unit cell
        SF_lat_complex = strufact_lattice(
            Q, lattice_vectors=lattice_vectors_rot[g], crystal_size=crystalsize.copy()
        )
        SF_uc_complex = strufact_unit_cell(Q, F_el, uc_pos, bool_pos_el)

        S_complex = (
            SF_uc_complex * SF_lat_complex
        )  # Multiply SF of lattice with SF of the unit cell
        # S_complex=SF_uc_complex #Multiply SF of lattice with SF of the unit cell
        # print(np.max(np.imag(SF_lat_complex)), "should be near 0")
        Isc[g, :] = np.real(
            S_complex * S_complex.conjugate()
        )  # put together for the respective orientation
        # in theory   complex part should be 0 here (z*z.conjugate=|z|^2), so ignore warning

    return Isc


@njit
def strufact_lattice(Q, lattice_vectors, crystal_size):
    """
    Q: 2D ndarray, float
        sampling points in reciprocal space
        dim 0: reciprocal lattice points, 1: [qx,qy,qz]
    lattice_vectors: 2D ndarray
        dim0: three lattice directions, 1: lattice vector in current orientation
        a:[x, y, z]
        b:[x, y, z]
        c:[x, y, z]
    crystal_size: 1D ndarray len=3
        dim: size along the three crystal axes

    Return value:
    --------------
    sf_complex: 1D ndarray, complex128
        structure factor of the lattice, function of Q
        dim0: complex structure factor
    """
    # algorithm does the following:
    # 1: find largest dimension of the crystal (equality->lowest dim)
    # 2: store 1 lattice point p which is the n/2th one along this axis, which is the n/2th along the acquired dimension
    # 3: calculate the structure factor of this "lattice": 1+exp(i*p*Q)
    # 4: multiply this sf with the one of its "sublattice", which will be recursively called using this function
    # 5: break the recursion when the shape of the crystal is 1,1,1 and calculate the sf of that last "cell" by hand - it's just e^0
    longest_axis_value = np.max(crystal_size)  # the length of the longest axis
    longest_axis_number = np.where(crystal_size == longest_axis_value)[-1][
        0
    ]  # the axis in question (in the lowest dim)
    # We could try to save time by not picking out the longest axis but rather go from 0-2 and just keep dividing until the length=2
    ###It should be alright to leave it like this. If large errors occur, it may come from numerical issues that
    ##may arise with the deeper recursion.
    ##Change commented code with first part of if statement
    """
        if np.all(crystal_size == 2):
        #calculate the remaining 8 (7) lattice positions: a, b,c a+b, a+c, b+c, a+b+c
        positions=np.zeros((7, 3), data_type)
        positions[:3]=lattice_vectors       
        positions[3]=lattice_vectors[0]+lattice_vectors[1]
        positions[4]=lattice_vectors[0]+lattice_vectors[2]
        positions[5]=lattice_vectors[1]+lattice_vectors[2]
        positions[6]=positions[3]+lattice_vectors[2] #a+b+c      

        SFL_complex=np.ones(Q.shape[0],np.complex128) #accounting for the lattice point at 0
        for r in positions:
            #qr = r[0]*Q[:,0] + r[1]*Q[:,1] + r[2]*Q[:,2] #calculate scalar product
            qr = np.dot(Q, r)
            SFL_complex += np.exp(qr*1j) 
        return SFL_complex
    """
    if np.all(crystal_size == 1):
        SFL_complex = np.ones(
            Q.shape[0], np.complex128
        )  # the remaining lattice point at 0,0,0
        return SFL_complex
    else:
        # determine second lattice point (first one being [0,0,0])
        p = (longest_axis_value // 2) * lattice_vectors[longest_axis_number]
        # evaluate 1+exp(ipq)
        # qp=p[0]*Q[:,0] + p[1]*Q[:,1] + p[2]*Q[:,2] #scalar product
        qp = np.dot(Q, p)
        # dot product will only run parallely with both as same datatype

        sf_complex = 1 + np.exp(qp * 1j)
        # multiply by SF of sublattice, that is repeated at 0 and p
        crystal_size[longest_axis_number] = longest_axis_value // 2
        sf_complex = sf_complex * strufact_lattice(Q, lattice_vectors, crystal_size)
        return sf_complex
    ##possibly add cases for one dimension being 1 or odd


@njit
def strufact_unit_cell(Q, FF, unit_cell_pos, bool_pos_el):
    """
    Q: 2D ndarray, float
        momentum exchange vectors
        dim 0: reciprocal lattice points, 1: [qx,qy,qz]
    FF : 2D ndarray, float
        atomic form factors for different elements
        dim0: different elements
        dim1: different Qs
    unit_cell_pos: 2D ndarray, float
        real space atomic positions
    bool_pos_el : 2D ndarray, string
        mask for uc_pos to find elements
        dim0: element dim1: mask for positions in uc

    Return values
    -------------
    SU_complex: 1D ndarray, complex128
        structure factor of the unit cell, function of Q
        dim0: complex structure factor
    """
    SU_complex = np.zeros_like(Q[:, 0], np.complex128)
    nEl = bool_pos_el.shape[0]

    for i in range(nEl):  # for all elements
        f = FF[i]  # get atomic form factor (for all Qs)
        sComplex = np.zeros_like(SU_complex)
        for r in unit_cell_pos[bool_pos_el[i, :]]:  # all atom positions of that element
            # qr = r[0]*Q[:,0] + r[1]*Q[:,1] + r[2]*Q[:,2] #calculate scalar product
            qr = np.dot(Q, r)
            sComplex += np.exp(qr * 1j)
        SU_complex += f * sComplex
    return SU_complex


# 2 calculate diffractlets from Isc (integrate_diffractlets)
# 2.1 ODFs


# Note: both ODF functions take same input, so that it can be easily passed down
# @njit #Does not seem to run parallely
def gaussian_3d(g, mu, kappa, std, gen, dV=1):
    """
    Gauss bell on FZ
    Parameters
    --------
    g : 2d ndarray, float
        points in orientation space in axis-angle
        dim0: points, dim1: OTP of orientation
    mu: 2d ndarray, float (must be (1,3) or just repeated vectors (n,3))
        mean orientation of ODF
        dim0: one mean orientation dim1: axis angle representation OTP
    (kappa): float, not used
        concentration parameter for von Mises-Fisher
    std: float
        standard deviation - sigma
    gen: 2d ndarray, float
        OTP of the two generators for the point group symmetries
        dim0: generators, dim1: OTP
    (dV): 1d ndarray, float
        "Volume" Element for each orientation in g
        important for non-cubochoric sampling
        deactivated for use in difflets_from_Miller

    Returns:
    ------------
    odf: 1d ndarray, float
        non-normalized probability (mass) for each of the orientations g
    """
    # make quaternion from mu
    q_mu = rot.QfromOTP(mu)[0]

    # make quaternions from angles
    Q_points = rot.QfromOTP(g)
    # for omega_mu = 0, then dg is omega
    dg = rot.ang_distance(Q_points, np.tile(q_mu, (Q_points.shape[0], 1)), gen)
    odf = np.exp(-(dg**2) / (2 * std**2))
    return odf  # /( odf @ dV ) Does not return a valid pmf at the moment


@njit
def fisher_SO3(g, mu, kappa, sig, gen, dV=1):
    """
    von Mises-Fisher distribution on FZ
    Parameters
    --------
    g : 2d ndarray, float
        points in orientation space in axis-angle
        dim0: points, dim1: OTP of orientation
    mu: 2d ndarray, float (must be (1,3) or just repeated vectors (n,3))
        mean orientation of ODF
        dim0: one mean orientation dim1: axis angle representation OTP
    kappa: float
        concentration parameter for von Mises-Fisher distribution (~1/sigma^2)
    (std0: float, not used
        standard deviation - sigma
    gen: 2d ndarray, float
        OTP of the two generators for the point group symmetries
        dim0: generators, dim1: OTP
    (dV): 1d ndarray, float
        "Volume" Element for each orientation in g
        important for non-cubochoric sampling
        deactivated for use in difflets_from_Miller

    Returns:
    ------------
    odf: 1d ndarray, float
        non-normalized probabilty (mass) for each of the orientations g
    """
    # We put multiple (mises-fisher) bell functions on the unit quaternion sphere
    # One on every symmetry equivalent mu
    # Evaluate the sum of these on orientations g
    q_mu = rot.QfromOTP(mu)[0]
    # make quaternions from angles
    Q_points = rot.QfromOTP(g)  # unit quaternions
    Q_gen = rot.QfromOTP(gen)

    n1 = int(2 * np.pi / gen[0, 0])  # n1-fold symmetry from 1st generator
    n2 = int(2 * np.pi / gen[1, 0])  # n2-fold symmetry from 2nd generator

    symmus = np.empty((n1 * n2, 4), dtype=data_type)  # symmetrically equivalent mus

    qc = q_mu.copy()
    x = 0
    for _ in range(n1):
        qc_0 = qc.copy()
        for _ in range(n2):
            symmus[x] = qc
            qc = rot.q_mult(qc, Q_gen[1])  # rotate point by 2st generator
            x += 1
        qc = rot.q_mult(qc_0, Q_gen[0])  # rotate point by 1st generator
    ##The rotation can make the angle omega go beyond 180 degrees, which is no more in the FZ.
    # ->cos(omega)<1 (Double cover)
    ##We need to project those back to the right place with q[:,0]>0
    symmus[symmus[:, 0] < 0] = -symmus[symmus[:, 0] < 0]

    # This should be right mathematically, but is apparently unstable
    # mux = symmus @ Q_points.transpose() #maybe include in the loop, but should work
    # ODF = np.exp(mux * kappa)

    odf = np.zeros((symmus.shape[0], g.shape[0]), dtype=data_type)
    for i in range(symmus.shape[0]):  # sum up
        mux = np.atleast_2d(symmus[i] @ Q_points.transpose())
        odf[i] = np.exp(mux * kappa)
    odf = np.sum(odf, axis=0)
    return odf  # /( odf @ dV ) !!!!


# 2.2 integration
def integrate_diffractlets(
    input_File,
    nMu=5,
    accuracy_Isc=1e-4,
    accuracy_ODF=1e-6,
    orientation_distribution=fisher_SO3,
):
    """
    Parameters:
    ------------
    input_File: string
        path to cif-File containing single crystal diffraction patterns (Isc) and some parameters
    nMu: int
        related to avg. angular distance between the peaks of ODF basis functions
        the higher the more basis functions (bells)
    accuracy_Isc: float
        threshold, below which the normalized (0 to 1) Isc is rounded to 0 #between 1e-4 and 1e-2 I think
    accuracy_ODF: float
        threshold, below which the normalized ODF is rounded to 0 #should be around 5e-3 to 5e-2
    orientation_distribution: function
        fisher_SO3 or gaussian_3d

    Returns:
    ----------
    DIffractlets: 2d ndarray, float
        Diffractlets for the different basis functions
        (dimensions might be the other way around)
        dim0: basis function, dim1: intensity values


    This script calculates the diffractlets created by a set of base ODFs.
    The ODFs can basically be chosen freely.
    To speed up the calculation we make use of the sparsity of:
    -The Isc matrix (just isolated diffraction peaks)
    -The ODF matrix that contains more or less sparse distribution functions (Needs work and tests)

    The idea is that the integral can be rewritten with vectors/matrices

    Works only with cubochoric sampling at the moment
    !!!I wrote this down but can't remember why :(.
    Probably because the ODF functions are a little altered
    """
    # Notes:
    # the normalization of the ODF is done in this function at the moment
    # but could be done in the ODF functions themselves
    # might want to input kappa and sigma (or coefficients)
    # might want to store the diffractlets in a h5 File
    # could return (or not) the Mu for each of the diffractlets
    with h5py.File(input_File, "r") as hf:
        Isc = hf["Isc"][()]
        d_chi = int(hf["Ang_resolution"][()])  # in degrees!
        symmetry = hf["symmetry"][()].decode("utf-8")
        cif_file = hf["cif_file"][()].decode("utf-8")
        Gc = hf["Gc"][()]
        dV = hf["dV"][()]
        V_fz = hf["V_fz"][()]
        detShape = hf["detShape"][()]

        sampling = hf["sampling"][()].decode("utf-8")

    print("Finished reading .h5 file.")
    print(
        f"\t Angular resolution: {d_chi:.2f} degrees = {d_chi / 180 * np.pi:.2f} radians."
    )
    print(f"\t Volume FZ: {V_fz:.2f}")
    start = time()
    n_orientations = Isc.shape[0]
    gen = generators(symmetry)
    # dchi = d_chi/180 *np.pi #in rad

    dMu = 2 * np.pi / nMu  # related to sigma and kappa

    # ODF params
    sig = dMu * 0.01  # higher ->wider Gaussians, 'flatter' distribution
    kappa = 300  # maybe 10/sig**2 #higher -> more concentrated
    # sample support points for the means and for the sampled orientations
    Mus, dV_mu, V_fz_mu = define_angles(dMu, sampling, symmetry)  # sample the Mus
    N = Mus.shape[0]

    # fill Matrix with N basis ODFs
    ODF = np.zeros((N, n_orientations), data_type)
    for i in prange(N):
        ODF[i] = orientation_distribution(
            Gc, np.atleast_2d(Mus[i]), kappa, sig, gen, dV
        )
        ODF[i] = ODF[i] / (ODF[i] @ dV)  # as it's not done in the ODF function
        ODF[i] = ODF[i] / np.sum(ODF[i])  # normalize ODF
    # normalize
    Isc = Isc / Isc.max()

    # sparsify it
    ODF[ODF < accuracy_ODF] = 0  # small values = zero
    ODF_sparse = csc_array(ODF)  # make ODF sparse
    density_ODF = ODF_sparse.nnz / np.prod(ODF_sparse.shape)

    Isc[Isc < accuracy_Isc] = 0  # round small values to zero
    Isc_sparse = csc_array(Isc)  # make Isc a 2D compressed sparse column array
    density_Isc = Isc_sparse.nnz / np.prod(Isc_sparse.shape)

    print(
        f"Sparsity stats: \n\tdensity of ODF: {density_ODF:.5f}\n",
        f"\tdensity of Isc: {density_Isc:.5f}",
    )

    # integrate all diffractlets at once:
    # split up and parallelize??
    DIffractlets = ((ODF_sparse * dV) @ Isc_sparse).reshape(np.hstack((N, detShape)))
    duration = time() - start
    print(f"\n\tTook {duration:.2f}s to calculate {DIffractlets.shape[0]} difflets")
    # sparse_powder = (Isc_sparse.sum(axis=0) ).reshape(detShape) #if we want to compare the powder pattern
    return DIffractlets.todense()


# 3 get diffractlets from Miller indices (Miller_strufact)
# 3.1 some needed functions
def numerical_integral(axis, mu_quat, kappa, n_integ=100000):
    ome = np.linspace(-np.pi, np.pi, num=n_integ, endpoint=False)
    quat = np.column_stack(
        [
            np.cos(ome / 2),
            np.sin(ome / 2) * axis[0],
            np.sin(ome / 2) * axis[1],
            np.sin(ome / 2) * axis[2],
        ]
    )
    return np.sum([np.exp(kappa * q @ mu_quat) for q in quat]) * 2 * np.pi / n_integ


def analytical_integral(a, b):
    # analytical solution for the integral exp( a*cos(w/2) + b*sin(w/2) ) dw from -pi to pi
    # using the modified Bessel function i0
    R = np.sqrt(a**2 + b**2)
    return 4 * np.pi * i0(R)


def rotation_from_hkl_to_q(hkl, q):
    """
    Parameters:
    ---------
    hkl: 1d ndarray, float
        starting orientation in OTP
    q: 1d ndarray, float
        end orientation in OTP
    Retunrs:
    _----------
    Rotation object

    Compute the exact rotation (as quaternion and matrix) that maps the hkl vector
    to the q-vector using axis-angle geometry.
    """
    hkl = hkl / np.linalg.norm(hkl)
    q = q / np.linalg.norm(q)

    dot = np.clip(np.dot(hkl, q), -1.0, 1.0)

    axis = np.cross(hkl, q)
    axis /= np.linalg.norm(axis)
    angle = np.arccos(dot)
    return R.from_rotvec(angle * axis)


def smarter_get_probability(peak, q, mu, kappa):  # not working like this
    """
    Uses analytical integral
    returns the probabilty that peak appears at q (given some parameters for the underlying distribution),
    by summing the probability of all rotations that rotate the crystal accordingly
    """
    # Doesn't work yet, but I wanted to try it out
    # I don't think the integral is that simple, because the rotations along which we integrate are not just
    # the rotation around this one axis, but these multiplied with the rotations that result from rotation_from_hkl_to_q
    #
    sampling = 1000  # No idea, the bigger the better
    # overwriting mu
    # mu = rot.OTPfromQ(np.atleast_2d(np.hstack((np.atleast_1d(0),q))))
    if np.linalg.norm(q) - np.linalg.norm(peak) > 1e-10:
        print("Can't rotate peak into desired q - check input")
        return
    # 2: Find axis that points from O to q (which is +-q itself duh)
    axis = q / np.linalg.norm(q)  # i,j,k parts of Rot2

    q_mu = rot.QfromOTP(mu).reshape((4))  # mu as quat

    proba = analytical_integral(kappa * mu[0], kappa * axis @ q_mu[1:])
    return proba[0]  # I get a 1x3 output with similar elements (?)


def get_probability(peak, q, gen, orientation_distribution, mu, sigma, kappa):
    """
    Parameters:
    --------
    peak: 1d ndarray, float
        peak location in reciprocal space (in base orientation)
    q: 1d ndarray, float
        desired peak location after rotation
    orientation_distribution: function
        fisher or gaussian,...
    mu: 2d ndarray, float (actually 1D)
        mean for the ODF
    sigma, kappa: float
        std/concentration parameter for the ODF
    Returns:
    -------------
    proba: float
        probability that peak gets turned into q, given the ODF(mu,sig/kap)

    returns the probabilty that peak appears at q (given some parameters for the underlying distribution),
    by summing the probability of all rotations that rotate the crystal accordingly
    """
    sampling = 1000  # No idea, the bigger the better
    # overwriting mu
    # mu = rot.OTPfromQ(np.atleast_2d(np.hstack((np.atleast_1d(0),q))))
    if np.linalg.norm(q) - np.linalg.norm(peak) > 1e-10:
        print("Can't rotate peak into desired q - check input")
        return
    # 1: Find a rotation (quaternion), that rotates the crystal in the right orientation
    # rot1 , _ = R.align_vectors(q, peak) #old version
    rot1 = rotation_from_hkl_to_q(peak, q)  # see comment in function
    rot1 = rot1.as_quat(scalar_first=True)
    # 2: Find axis that points from O to q (which is unsigned q itself duh)
    axis = q / np.linalg.norm(q)  # i,j,k parts of Rot2
    # 3: Sample quaternions to rotate around this axis
    d_rot = np.linspace(
        0, np.pi, sampling
    )  # rotation increments (0 to pi covers all rotations)
    w = np.cos(d_rot)
    ijk = np.zeros((sampling, 3))  # "sampling" samples of the axis
    for i in range(3):
        ijk[:, i] = np.sin(d_rot) * axis[i]
    Rot2 = np.hstack((np.atleast_2d(w).transpose(), ijk))

    Rot2[Rot2[:, 0] < 0] = -Rot2[Rot2[:, 0] < 0]  # maybe, to have them all in the FZ

    # 3.5: Multiply the two, to get full rotations
    Rotations = np.zeros_like(Rot2)
    for i in range(sampling):
        Rotations[i] = rot.q_mult(Rot2[i], rot1)
    # 4: Find (relative) probabilities for these orientations
    Rots_OTP = rot.OTPfromQ(Rotations)  # should not transform and retransform in future
    Probabilities = orientation_distribution(Rots_OTP, mu, kappa, sigma, gen)
    # 5: "Integrate"/sum over all the rotations
    proba = np.sum(Probabilities)
    return proba


def get_unit_cell_from_cif(cif_file):  # use could probably be avoided
    """
    Input:
    cif file path

    Returns:
    ----------
    unit_cell: uctbx.unit_cell object
        information about the UC
    space_group_symbol: string(?)
        space group symbol in Herrman-Mauguin (I think)
    determine unit cell and space group symbol from cif_file
    ####cif_file format needs to match up####
    """

    cif_object = cif.reader(file_path=cif_file)
    cif_model = cif_object.model()
    block = list(cif_model.values())[0]  # Assuming first block contains the data

    # extract space group
    space_group_symbol = block.get("_space_group_name_H-M_alt", None)
    # get unit cell parameters, direct lattice vectors (in A)
    a = float(block.get("_cell_length_a", None))
    b = float(block.get("_cell_length_b", None))
    c = float(block.get("_cell_length_c", None))
    # angles (degrees)
    alpha = float(block.get("_cell_angle_alpha", None))
    beta = float(block.get("_cell_angle_beta", None))
    gamma = float(block.get("_cell_angle_gamma", None))

    # create and return uctbx.unit_cell object
    unit_cell = uctbx.unit_cell((a, b, c, alpha, beta, gamma))

    return unit_cell, space_group_symbol


def get_multiplicity(
    miller_indices, cif_path, space_group_symbol
):  # Can and should be rewritten with generators (no cctbx)
    """
    Parameters:
    ----------
    miller_indices: 2d ndarray, float (or int?)
        dim0: all allowed Miller indices of lattice plane families that need to be looked at
        dim1: hkl
    space_group_symbol:
        see get_unit_cell_from_cif

    Returns:
    --------
    Multiplicities: 1d ndarray, int
        Multiplicities for every plane family


    Takes all (hkl), applies symmetry operations, counts uniques for each family
    Parameters:
        miller_indices: list of (h, k, l) tuples
        space_group_symbol: e.g., 'P 21 21 21', 'Fm-3m', 'P1'


    """
    # Get space group object from Hermann??Mauguin symbol
    space_group_info = sgtbx.space_group_info(space_group_symbol)
    space_group = space_group_info.group()

    # # Extract only the rotational parts (as these affect Miller indices)
    rotational_ops = space_group.build_derived_point_group().make_tidy().all_ops()
    # Extract symmetry operations
    # rotational_ops = cry.parse_cif(cif_path)['symmetry_operations'] #as strings

    multiplicities = np.zeros_like(miller_indices[:, 0])

    for hkl, i in zip(miller_indices, range(miller_indices.shape[0])):
        equiv_set = set()

        for op in rotational_ops:
            op = op.r().as_xyz()
            sym_hkl = cry.apply_symmetry_operation(op, hkl)
            sym_hkl = tuple(sym_hkl.tolist()[0])  # do we need that
            equiv_set.add(sym_hkl)

        multiplicities[i] = len(equiv_set)

    return multiplicities


def difflets_from_Miller(
    cif_path,
    E_keV,
    q_max,
    n_chi,
    mu=np.atleast_2d(np.array([0, 0, 0])),
    sigma=np.pi / 10,
    kappa=100,
    orientation_distribution=fisher_SO3,
):
    """
    Parameters
    -------
    cif_path: string
    E_keV: float
        Xray energy
    q_max: float
        maximum q (abs value)
    n_chi: int
        number of azimuthal bins
    mu: 2D ndarray, float, 1x3
        mean orientation in axis-angle
    sigma, kappa: float
        std or concentration parameter for base ODF
    orientation distribution: function
        fisher_SO3 or gaussian_3d
        can be extended to others, input arguments need to be considered
    returns
    ---------
    I_diff: 2d ndarray, float
        diffractlets
    q_norm: 1d ndarray, float
        absolute values |q| of each peak, radial bins
    chi: (not necessary, calculatable from nchi) 1d ndarray, float
        azimuthal bins
    """
    # Notes on the code:
    # I am not entirely happy with the diffractlets
    # I believe they should be perfectly symmetrical for mu=(0,0,0), which they're not
    # Might be because we only introduce the symmetry through the ODFs (or rather the SO3)
    # Multiplicities are wrong with hap.cif (probably sym-ops don't work properly)
    # Generally a lot looks wrong with hap
    # cctbx is still used for: Calculation of the multiplicities, for the hkl array
    # The powder pattern that results from |F|^2*Mult matches (approximately) with the values from VESTA
    # VESTA (and other powPats) however displays a different powder pattern -> There is something else playing into it
    # The 'old' powder pattern matches better with VESTA

    h = 4.135667696e-18  # keV*s
    c = 299792458  # m/s
    kXray = 2 * np.pi * E_keV / (h * c * 1e9)  # wavevector in 1/nm
    d_chi = 2 * np.pi / n_chi
    chi = np.linspace(0, 2 * np.pi, n_chi, endpoint=False) + 2 * np.pi / n_chi / 2
    # Get the uc strufact:
    # construct the unit cell with ase
    unit = read(cif_path)  # Read the CIF file via ase
    uc_pos = unit.positions / 10  # coordinates of all atoms converted to nm
    uc_chem = np.array(unit.get_chemical_symbols())
    elements = np.unique(uc_chem)  # all used elements
    Nel = elements.size  # number of elements
    space_group_number = unit.info["spacegroup"].no
    symmetry = sym.get_diffraction_laue_group(space_group_number)
    gen = generators(symmetry)
    uc_lattice = unit.cell.array / 10  # nm #without cctbx

    # Did this with cctbx before for some reason
    unit_cell, space_group = get_unit_cell_from_cif(
        cif_path
    )  # needed later for the hklarray
    # lattice
    # uc_lattice = np.reshape(unit_cell.orthogonalization_matrix(), (3,3)).transpose()#Angstrom #real space lattice vectors
    # uc_lattice = uc_lattice/10 #nm
    ##See p.155 Elements of modern X-ray physics
    uc_Volume = uc_lattice[0] @ np.cross(uc_lattice[1], uc_lattice[2])  # nm3
    reciprocal_lattice = np.zeros((3, 3), data_type)  # nm-1
    for i in range(3):
        reciprocal_lattice[i] = (
            2
            * np.pi
            / uc_Volume
            * np.cross(uc_lattice[(i + 1) % 3], uc_lattice[(i + 2) % 3])
        )  # fancy

    # Test correctness
    dot = np.zeros((3, 3))
    for i in range(3):
        for j in range(3):
            dot[i, j] = uc_lattice[i] @ reciprocal_lattice[j]

    # Just to make sure
    if (np.round(dot - 2 * np.pi * np.eye(3), 10) != 0).any():
        print("\n\nWarning: Lattice vectors went wrong.", dot, "\n\n")

    # Find the Miller indices with cctbx:
    symmetry = crystal.symmetry(unit_cell=unit_cell, space_group_symbol=space_group)
    hkl_array = np.array(
        miller.build_set(
            symmetry, anomalous_flag=False, d_min=20 * np.pi / q_max
        ).indices()
    )

    q_peaks = (
        hkl_array @ reciprocal_lattice.transpose()
    )  # hkls converted to vectors in q-space
    q_norm = np.round(
        np.linalg.norm(q_peaks, axis=1), 10
    )  # distance from origin of reciprocal lattice
    sorted_indices = np.argsort(q_norm)
    # Apply sorting
    q_norm = q_norm[sorted_indices]  # all in nm-1
    hkl_array = hkl_array[sorted_indices]
    q_peaks = q_peaks[sorted_indices]

    N_peaks = q_peaks.shape[0]  # Nr of peaks
    # Multiplicities for PowPat
    Multiplicities = get_multiplicity(hkl_array, cif_path, space_group)
    """
    We now know:
    1. everything we need to know about the unit cell
    2. the allowed miller indices up to a certain maximal q
    3. their cartesian positions in reciprocal space
    Next up: 
    1. get the form factors
    2. calculate the diffraction intensities for each q peak of just the unit cell in base orientation [0,0,0]
    3. for every circel, for every point on it: Find the probability that the crystal is turned in a way that the q_peak appears on this point
    """
    # get the form factors
    ff_path = hdl.get_file_path(
        "textom", os.path.join("ressources", "atomic_formfactors.txt")
    )
    ffcoeff = np.genfromtxt(ff_path, dtype="|U8", skip_header=2)
    ffcoeff_used = np.array(
        [ffcoeff[np.where(el == ffcoeff)[0][0], 1:] for el in elements]
    ).astype(data_type)
    a = ffcoeff_used[:, 0:-1:2]
    b = ffcoeff_used[:, 1:-1:2]
    c = ffcoeff_used[:, -1]
    FF_el = np.empty(
        (Nel, N_peaks), data_type
    )  # atomic form factors for all used elements
    for k in range(Nel):
        A, Qf = np.meshgrid(
            a[k], q_norm / 10
        )  # using angstroems^-1 here for simplicity
        B, _ = np.meshgrid(b[k], q_norm)
        C = c[k]
        # Calculate form factor http://lampx.tugraz.at/~hadley/ss1/crystaldiffraction/atomicformfactors/formfactors.php
        FF_el[k] = (A * np.exp(-B * (Qf / (4 * np.pi)) ** 2)).sum(axis=1) + C

    # bool mask for the unit cell
    bool_pos_el = np.empty((Nel, uc_chem.shape[0]), bool)
    for k in range(Nel):
        # determinate the positions of element k
        bool_pos_el[k, :] = uc_chem == elements[k]

    # 1D ndarray with relative intensity for every peak (hkl)
    uc_strufact = strufact_unit_cell(
        q_peaks, FF_el, uc_pos, bool_pos_el
    )  # qs need to be in nm-1!!

    # choose one of these to calculate |F|^2
    # uc_intensities = np.abs(uc_strufact)**2
    uc_intensities = np.real(
        uc_strufact * uc_strufact.conjugate()
    )  # should be all real

    powder = (
        uc_intensities * Multiplicities
    )  # integrated intensity in a powder pattern for each peak
    ##Give each peak it's probability, given a specific base ODF
    DEtector_probas = np.zeros((N_peaks, n_chi))

    # suggest prange here (Should be looking at ~50 repetitions)
    for peakNr in range(N_peaks):  # 7: for all of the peaks/all circles
        # hkl = hkl_array[peakNr]
        mag_q = q_norm[peakNr]
        q_hkl = q_peaks[peakNr]
        # generate qs on the same circle (mag_q) on the detector

        # coordinates on detector
        Qq_det, Chi_det, detShape = rot.qchi(mag_q, chi)
        # azimutal angle with respect to the beam for the points of Ewald's sphere
        Tta_ew = np.pi - np.arctan(np.sqrt(kXray**2 - Qq_det**2 / 4) * 2 / Qq_det)
        # coordinates of Ewald's sphere in reciprocal space
        QX_ew = Qq_det * np.cos(Tta_ew)
        QY_ew = -Qq_det * np.sin(Tta_ew) * np.sin(Chi_det)
        QZ_ew = Qq_det * np.sin(Tta_ew) * np.cos(Chi_det)
        Q_ew = np.column_stack([QX_ew, QY_ew, QZ_ew])
        # number of points on detector
        Ndet = Tta_ew.shape[0]
        if Ndet != n_chi:
            print("Something isn't right with the detector calc")

        # 6: For all points on the circle
        for q, i in zip(Q_ew, range(Ndet)):  # also maybe parallel
            DEtector_probas[peakNr, i] = get_probability(
                q_hkl, q, gen, gaussian_3d, mu, sigma, kappa
            )
        print(f"\n\tFinished peak Nr.{peakNr + 1}/{N_peaks}")

    I_diff = np.zeros_like(DEtector_probas)  # Intensity for every point on detector
    for n in range(
        Ndet
    ):  # multiply intensities and the probability for every ray with same chi
        I_diff[:, n] = uc_intensities * DEtector_probas[:, n]
    return I_diff, q_norm, chi, powder


# 4 get a powder pattern from Miller indices
# included in above function. Could be extracted if fast PowPat is necessary

# 5 example call for each major function (of which there are three)
# x-ray energy in keV
E_keV = 17.0
# q range for fitting
q = np.linspace(5, 45, num=200)
# azimutal range for fitting
n_chi = 120
# chi = np.linspace( 0, 2*np.pi, n_chi, endpoint=False) + 2*np.pi/n_chi/2
# path to crystal cif file
cifpath = "CIF-Files/hap.cif"
# # angular sampling
sampling = "cubochoric"  # or 'simple'
# angular sampling resolution
# dchi = 2*np.pi/n_chi
h5_name = "data/hap-ls3479-17keV"
crystal_dims = (5, 5, 50)  # in nm or in case of override in 2^n of unit cells

##First function
calculate_single_crystal(crystal_dims, cifpath, E_keV, q, n_chi, sampling, h5_name)

# #Second function
# #I don't know how to assign a function to a variable, so it's directly in the function call
# nMu = 8 #higher -> more and skinnier basis functions #measure for how many basis functions are calculated
# accuracy_Isc = 1e-4 #lower -> fewer 0s, lower sparsity
# accuracy_ODF = 1e-6 #ebenda
# DIffractlets = integrate_diffractlets(h5_name,  nMu, accuracy_Isc,
#                                     accuracy_ODF, orientation_distribution = fisher_SO3)
# # #we could output sigma and kappa
# #get some info for the plot
# with h5py.File(h5_name, 'r') as hf:
#     detShape = hf['detShape'][()]
#     Chi_det = hf['Chi_det'][()]
#     Qq_det = hf['Qq_det'][()]
#     q= hf['q'][()]

# #plot the diffractlet
# CHi, QQ = Chi_det.reshape(detShape), Qq_det.reshape(detShape)
# X1 = -QQ * np.sin(CHi)
# X2 = QQ * np.cos(CHi)
# number = 100 #arbitrary, select orientation
# image = np.sum(DIffractlets[:number], axis=0)
# fig, axs = plt.subplots(1, 1, figsize=(6, 5))  # Only one subplot needed
# pcm = axs.pcolormesh(X1, X2, image, cmap='plasma', vmin=0, vmax=image.max())
# axs.set_title(f"Sparse Calculation")
# axs.set_aspect('equal')
# fig.colorbar(pcm, ax=axs)
# plt.tight_layout()
# plt.show(block = True)

# ## third & fourth function
# q_max = 35 #nm-1
# mu = np.atleast_2d(np.array([0,0,0]))
# #play with these
# sigma = np.pi/10
# kappa = 300 #10/sigma**2
# n_chi = 120

# #Only calculates one difflet at the moment. Would have to be repeated for every basis function, with different Mus
# I_diff, q_norm, chi, powder = difflets_from_Miller(cifpath,
#     E_keV, q_max, n_chi, mu, sigma, kappa, orientation_distribution = gaussian_3d)
# #Show the powder pattern
# # plt.figure()
# # plt.stem( q_norm, powder/powder.max(), label='simulated')
# # plt.ylabel('relative Intensity')
# # plt.xlabel('q in nm-1')
# # plt.title('Powder pattern (|F|*M)')
# # plt.legend()
# # plt.show(block = True)

# #Show the diffractlet
# Qq_det, Chi_det, detShape = rot.qchi(q_norm, chi) #one circle for every peak
# CHi, QQ = Chi_det.reshape(detShape), Qq_det.reshape(detShape)
# X1 = -QQ*np.sin(CHi)
# X2 = QQ*np.cos(CHi)
# m=plt.pcolormesh(X1, X2, I_diff, cmap='plasma', vmin=0, vmax=I_diff.max())
# plt.axis('equal')
# plt.title("One diffractlet")
# plt.show(block=True)
