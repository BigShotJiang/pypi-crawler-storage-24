import glob
import os
import shutil
import sys

os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
# matplotlib.use('tkagg')
from importlib import reload  # this is to reload
from time import time
from typing import Optional, Union

import h5py
import hdf5plugin
import imageio.v3 as iio
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import orix.quaternion.symmetry as osym
from numba import njit, prange

import textom.src.analysis.orix_plugins as orx
import textom.src.model.rotation as rot
import textom.src.model.symmetries as sym
import textom.src.odf.gridbased as grd
import textom.src.plotting as plot
from textom.config import data_type
from textom.src.model.model_textom import model_textom, rotate_difflets_stack

sample_dir = "/Users/moritz/Documents/papers/biomorphs/helix_s7_textom/"
mod = model_textom(sample_dir)  # , single=True )
mod.set_orders(4)
mod._init_odf()

##### plot sHSHs and rotations
dlet_idx = 2
c = np.zeros(mod.difflets.shape[0], data_type)
c[0] = 1
c[dlet_idx] = 1

# # zero
# orx.odf_cloud_general(mod.Gc,
#     mod.odfFromC(c, clip=True),
#     mod.symmetry,num_samples=1000)
# # 90 deg
# orx.odf_cloud_general(mod.Gc,
#     mod.odfFromC(mod.Rs[20] @ c, clip=True),
#     mod.symmetry,num_samples=1000)
# # 180 deg
# orx.odf_cloud_general(mod.Gc,
#     mod.odfFromC(mod.Rs[40] @ c, clip=True),
#     mod.symmetry,num_samples=1000)
# #####

# ##### plot sHSH diffractlets
# difflets_rot_hsh = rotate_difflets_stack(mod.Rs,mod.difflets)
# _,QY_ew,QZ_ew, Ndet = mod.get_reciprocal_space_coordinates()

# plot.array3D_slider(difflets_rot_hsh[:,dlet_idx].reshape((difflets_rot_hsh.shape[0],*mod.detShape)),
#                     coordinates=(QY_ew.reshape(mod.detShape),QZ_ew.reshape(mod.detShape)),
#                     invert_x=True,xlabel='y',ylabel='z',cmap='viridis',minmax=[0,8.6*1e16]
#                     )
# ######

###### fisher distribution
Qc = rot.QfromOTP(mod.Gc)
q_mean_hsh = rot.mean_orientation(Qc, mod.odfFromC_old(c, clip=True))
mu = np.array([5.0, np.pi / 4, np.pi / 3], data_type)
q_mu = rot.QfromOTP(np.atleast_2d(mu))[0]
q_mu = q_mean_hsh
std = 20 * np.pi / 180
gen = sym.generators(mod.symmetry)
Q_gen = rot.QfromOTP(gen)

# odf = grd.fisher_SO3(Qc,q_mu,5/std**2,Q_gen,1)
# orx.plot_points_in_fz(q_mu,mod.symmetry)
# plt.title('mean')
# # orx.odf_cloud_general(mod.Gc,
# #     gaussian_3d(Qc,q_mu,std,gen,1),
# #     mod.symmetry,num_samples=1000)
# # plt.title('gauss')
# orx.odf_cloud_general(mod.Gc,
#     odf,
#     mod.symmetry,num_samples=1000)
# plt.title('fisher')
# ######

#### plot gridbased diffractlets
Qs = rot.QfromOTP(mod.Gs)
Qs[:, 1:] *= -1  # inverse rotations because we rotate the beam instead the sample

# _,QY_ew,QZ_ew, Ndet = mod.get_reciprocal_space_coordinates()
# difflets_rot = []
# for qs in Qs[:41]:
#     q_mu_g = rot.q_mult( qs , q_mu )
#     odf = grd.fisher_SO3(Qc,q_mu_g,5/std**2,Q_gen,1)
#     # sparse calculate the projections (only points in odf that are high)
#     diff_pattern = np.zeros(mod.Isc.shape[1], data_type)
#     idcs_odf = np.nonzero(odf> 0.01 * odf.max())[0]
#     for h in idcs_odf:
#         diff_pattern += mod.Isc[h] * odf[h]
#     difflets_rot.append( diff_pattern )
# difflets_rot = np.array(difflets_rot)

# plot.array3D_slider(difflets_rot.reshape((difflets_rot.shape[0],*mod.detShape)),
#                     coordinates=(QY_ew.reshape(mod.detShape),QZ_ew.reshape(mod.detShape)),
#                     invert_x=True,xlabel='y',ylabel='z',cmap='viridis',
#                     )

# #####

Q_group = rot.generate_group(Q_gen)
### compare rotated odfs
gs = 0
q_mu_rot = rot.quaternion_multiply(Qs[gs], q_mu)
q_mu_rot_fz = rot.map_to_fz(q_mu_rot, Q_group)
orx.plot_odf(
    mod.Gc, mod.odfFromC_old(c @ mod.Rs[gs], clip=True), mod.symmetry, num_samples=1000
)
plt.title(f"hsh, gs = {gs}")
orx.plot_points_in_fz(q_mu_rot, mod.symmetry)
plt.title(f"mean - unwrapped, gs = {gs}")
orx.plot_points_in_fz(q_mu_rot_fz, mod.symmetry)
plt.title(f"mean - wrapped, gs = {gs}")
orx.plot_odf(
    mod.Gc,
    grd.fisher_SO3(Qc, q_mu_rot_fz, 5 / std**2, Q_group),
    mod.symmetry,
    num_samples=1000,
)
plt.title(f"fisher, gs = {gs}")

# # check sampling of FZ
grid_resolution = 25  # degree
pg = getattr(osym, sym.get_SFnotation(mod.symmetry))
Q_odf = rot.get_sample_fundamental(
    grid_resolution, point_group=pg, method="cubochoric"
).data.astype(data_type)
n_basis_functions = Q_odf.shape[0]
orx.plot_points_in_fz(Q_odf, mod.symmetry)
#
plot_resolution = 2  # degree
pg = getattr(osym, sym.get_SFnotation(mod.symmetry))
Q_plot = rot.get_sample_fundamental(
    plot_resolution, point_group=pg, method="cubochoric"
).data.astype(data_type)
orx.plot_points_in_fz(Q_plot, mod.symmetry)
#
kappa = 200
orx.plot_odf(
    rot.OTPfromQ(Q_plot),
    grd.fisher_SO3(Q_plot, Q_odf[0], kappa, Q_group),
    mod.symmetry,
    num_samples=1000,
)
orx.plot_odf(
    rot.OTPfromQ(Q_plot),
    grd.fisher_SO3(Q_plot, Q_odf[1], kappa, Q_group),
    mod.symmetry,
    num_samples=1000,
)
#
odf0 = grd.fisher_SO3(Q_plot, Q_odf[0], kappa, Q_group)
odf1 = grd.fisher_SO3(Q_plot, Q_odf[1], kappa, Q_group)
plt.figure()
plt.plot(odf0)
plt.plot(odf1)
# #########

## check if sHSHs are invariant to the generators (they are not!)
R_group = mod.get_Rs_stack(rot.OTPfromQ(Q_group))
for k in range(R_group.shape[0]):
    orx.plot_odf(
        mod.Gc,
        mod.odfFromC_old(c @ R_group[k], clip=True),
        mod.symmetry,
        num_samples=1000,
    )
########################################

plt.show(block=True)
stop = 1
