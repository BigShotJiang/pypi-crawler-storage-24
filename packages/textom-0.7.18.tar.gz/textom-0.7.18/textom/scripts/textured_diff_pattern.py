import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from scipy.spatial.transform import Rotation as R


def reciprocal_lattice(a, b, c, alpha=90, beta=90, gamma=90, h_max=3, k_max=3, l_max=3):
    """
    Calculate reciprocal lattice points for an orthorhombic crystal system.
    """
    # Convert angles to radians
    alpha, beta, gamma = np.radians([alpha, beta, gamma])

    # Direct lattice vectors (for orthorhombic, they are along the axes)
    a1 = np.array([a, 0, 0])
    a2 = np.array([0, b, 0])
    a3 = np.array([0, 0, c])

    # Reciprocal lattice vectors
    V = np.dot(a1, np.cross(a2, a3))  # Unit cell volume
    b1 = 2 * np.pi * np.cross(a2, a3) / V
    b2 = 2 * np.pi * np.cross(a3, a1) / V
    b3 = 2 * np.pi * np.cross(a1, a2) / V

    # Generate reciprocal lattice points
    h_vals = np.arange(-h_max, h_max + 1)
    k_vals = np.arange(-k_max, k_max + 1)
    l_vals = np.arange(-l_max, l_max + 1)

    reciprocal_points = []
    for h in h_vals:
        for k in k_vals:
            for l in l_vals:
                G = h * b1 + k * b2 + l * b3
                reciprocal_points.append(G)

    return np.array(reciprocal_points)


def sample_orientations(num_samples, mean_orientation=[0, 0, 0], std_dev=10):
    """Sample orientations from a 3D Gaussian in SO(3)."""
    mean_rotation = R.from_euler("xyz", mean_orientation, degrees=True)
    samples = mean_rotation * R.from_rotvec(
        std_dev * np.random.randn(num_samples, 3) * np.pi / 180
    )
    return samples


def rotate_reciprocal_lattice(reciprocal_points, orientations):
    """Rotate reciprocal lattice points using sampled orientations."""
    rotated_points = []
    for rot in orientations:
        rotated_points.append(rot.apply(reciprocal_points))
    return np.vstack(rotated_points)


def filter_ewald_sphere(points, energy_keV, tolerance=0.05):
    """Filter reciprocal lattice points that satisfy the Ewald sphere condition."""
    wavelength = 12.398 / energy_keV  # Convert energy to wavelength (Å)
    k_mag = 2 * np.pi / wavelength  # Magnitude of incident wavevector (1/Å)
    k_vec = np.array([0, 0, k_mag])  # Incident wavevector along z

    distances = np.linalg.norm(
        points + k_vec, axis=1
    )  # Distance from Ewald sphere center
    mask = np.abs(distances - k_mag) < tolerance  # Select points near the Ewald sphere
    return points[mask]


def plot_diffraction_pattern(points):
    """Project filtered points onto a 2D detector plane."""
    plt.figure(figsize=(8, 8))
    plt.scatter(points[:, 0], points[:, 1], c="r", marker="o", alpha=0.5)
    plt.xlabel("Detector X (1/Å)")
    plt.ylabel("Detector Y (1/Å)")
    plt.title("Simulated Diffraction Pattern")
    plt.grid(True)
    plt.show()


# Lattice parameters for Pmcn (orthorhombic)
a, b, c = 5.31, 8.9, 6.43
reciprocal_points = reciprocal_lattice(a, b, c)

# Sample grain orientations from a Gaussian ODF
num_grains = 500  # Number of grains
mean_orientation = [0, 0, 0]  # Mean orientation in Euler angles (degrees)
std_dev = 10  # Spread in degrees
orientations = sample_orientations(num_grains, mean_orientation, std_dev)

# Rotate reciprocal lattice points
polycrystalline_reciprocal_points = rotate_reciprocal_lattice(
    reciprocal_points, orientations
)

# Apply Ewald sphere filtering
energy_keV = 15  # X-ray energy
filtered_points = filter_ewald_sphere(polycrystalline_reciprocal_points, energy_keV)

print("Filtered reciprocal lattice points:")
print(filtered_points)

# Plot diffraction pattern
plot_diffraction_pattern(filtered_points)
