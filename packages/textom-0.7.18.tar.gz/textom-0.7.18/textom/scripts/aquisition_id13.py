print("version ttomo test sc5408 - 9")
import time
import traceback

import bliss
import gevent


class Bailout(Exception):
    pass


# index,kappa,omega,absorption
ORI_INSTRUCT = """
1,0,0,0
2,0,4.3,0
3,0,8.6,0
4,0,12.9,0
"""


def make_instruct_list(s):
    ll = s.split("\n")
    instll = []
    for l in ll:
        l = l.strip()
        if l.startswith("#"):
            print(l)
        elif not l:
            pass
        else:
            (ext_idx, kap, ome, absorb) = l.split(",")
            ko = (int(ext_idx), int(kap), float(ome), int(absorb))
            instll.append(ko)
    instll = list(enumerate(instll))
    return instll


class TTomo(object):
    def __init__(
        self,
        asyfn,
        zkap,
        instll,
        scanparams,
        stepwidth=3,
        logfn="ttomo.log",
        resume=-1,
        start_key="zzzz",
    ):
        self.start_key = start_key
        self.resume = resume
        self.asyfn = asyfn
        self.logfn = logfn
        self.zkap = zkap
        self.instll = instll
        self.scanparams = scanparams
        self.stepwidth = stepwidth
        self._id = 0
        self.log(
            "\n\n\n\n\n################################################################\n\n                          NEW TTomo starting ...\n\n"
        )

    def read_async_inp(self):
        instruct = []
        with open(self.asyfn, "r") as f:
            s = f.read()
        ll = s.split("\n")
        ll = [l.strip() for l in ll]
        for l in ll:
            print(f"[{l}]")
            if "=" in l:
                a, v = l.split("=", 1)
                (action, value) = a.strip(), v.strip()
                instruct.append((action, value))
        self.log(s)
        return instruct

    def doo_projection(self, instll_item):
        self.log(instll_item)
        (i, (ext_idx, kap, ome, absorb)) = instll_item
        if ext_idx < self.resume:
            self.log(f"resume - clause: skipping item {instll_item}")
            return
        print("========================>>> doo_projection", instll_item)
        print(absorb, type(absorb))
        if not absorb:
            print("diff!")
        else:
            print("absorb!")

        # raise RuntimeError('test')
        str_ome = f"{ome:08.2f}"
        str_ome = str_ome.replace(".", "p")
        str_ome = str_ome.replace("-", "m")
        str_kap = f"{kap:1d}"
        str_kap = str_kap.replace("-", "m")
        self.log("... dummy ko trajectory")
        self.zkap.trajectory_goto(ome, kap, stp=6)
        newdataset_base = (
            f"tt_{self.start_key}_{i:03d}_{ext_idx:03d}_{str_kap}_{str_ome}"
        )
        if absorb:
            # no absorption sacns
            self.log("no absorption scans")
            # dsname = newdataset_base + '_absorb'
            # newdataset(dsname)
            # sc5408_fltube_to_fltdiode()
            # self.perform_scan()
        else:
            dsname = newdataset_base + "_diff"
            newdataset(dsname)
            # sc5408_fltube_to_fltwin()
            self.perform_scan()

    def perform_scan(self):
        sp = self.scanparams
        sp_t = (lly, uly, nitvy, llz, ulz, nitvz, expt, retveloc) = (
            sp["lly"],
            sp["uly"],
            sp["nitvy"],
            sp["llz"],
            sp["ulz"],
            sp["nitvz"],
            sp["expt"],
            sp["retveloc"],
        )
        lly *= 0.001
        uly *= 0.001
        llz *= 0.001
        ulz *= 0.001
        cmd = (
            f"dk..({lly},{uly},{nitvy},{llz},{ulz},{nitvz},{expt}, retveloc={retveloc})"
        )
        self.log(cmd)
        t0 = time.time()
        with gevent.Timeout(seconds=180):
            try:
                # put the nano scan ...
                # dkmapyz_2(lly,uly,nitvy,llz,ulz,nitvz,expt, retveloc=retveloc)
                self.log("scan successful")
            except bliss.common.greenlet_utils.killmask.BlissTimeout:
                msg = f"caught hanging scan after {time.time() - t0} seconds timeout"
                print(msg)
                self.log(msg)

        # time.sleep(5)

    def oo_correct(self, c_corrx, c_corry, c_corrz):
        self.zkap.c_corrx = c_corrx
        self.zkap.c_corry = c_corry
        self.zkap.c_corrz = c_corrz

    def fov_correct(self, lly, uly, llz, ulz):
        sp = self.scanparams
        sp["lly"] = lly
        sp["uly"] = uly
        sp["llz"] = llz
        sp["ulz"] = ulz

    def to_grid(self, lx):
        lx = int(lx)
        (n, f) = divmod(lx, self.stepwidth)

    def mainloop(self, inst_idx=0):
        instll = list(self.instll)
        instll.reverse()
        while True:
            instruct = self.read_async_inp()
            self.process_instructions(instruct)
            instll_item = instll.pop()
            self.doo_projection(instll_item)

    def log(self, s):
        s = str(s)
        with open(self.logfn, "a") as f:
            msg = f"\nCOM ID: {self._id} | TIME: {time.time()} | DATE: {time.asctime()} | ===============================\n"
            print(msg)
            f.write(msg)
            print(s)
            f.write(s)

    def process_instructions(self, instruct):
        a, v = instruct[0]
        if "id" == a:
            theid = int(v)
            if theid > self._id:
                self._id = theid
                msg = f"new instruction set found - processing id= {theid} ..."
                self.log(msg)
            else:
                self.log("only old instruction set found - continuing ...")
                return
        else:
            self.log("missing instruction set id - continuing ...")
            return

        for a, v in instruct:
            if "end" == a:
                return
            elif "stop" == a:
                print("bailing out ...")
                raise Bailout()

            elif "tweak" == a:
                try:
                    self.log(f"dummy tweak: found {v}")
                    w = v.split()
                    mode = w[0]
                    if "fov" == mode:
                        fov_t = (lly, uly, llz, ulz) = tuple(map(int, w[1:]))
                        self.adapt_fov_scanparams(fov_t)
                    elif "cor" == mode:
                        c_corr_t = (c_corrx, c_corry, c_corrz) = tuple(
                            map(float, w[1:])
                        )
                        print("adapting translational corr table:", c_corr_t)
                        self.adapt_c_corr(c_corr_t)
                    else:
                        raise ValueError(v)
                except:
                    self.log(f"error processing: {v}\n{traceback.format_exc()}")

            else:
                print(f"WARNING: instruction {a} ignored")

    def adapt_c_corr(self, c_corr_t):
        (c_corrx, c_corry, c_corrz) = c_corr_t
        self.zkap.c_corrx = c_corrx
        self.zkap.c_corry = c_corry
        self.zkap.c_corrz = c_corrz

    def adapt_fov_scanparams(self, fov_t):
        (lly, uly, llz, ulz) = fov_t
        lly = 3 * (lly // 3)
        uly = 3 * (uly // 3)
        llz = 3 * (llz // 3)
        ulz = 3 * (ulz // 3)

        dy = uly - lly
        dz = ulz - llz

        nitvy = dy // 3
        nitvz = dz // 3

        sp = self.scanparams
        sp["lly"] = lly
        sp["uly"] = uly
        sp["llz"] = llz
        sp["ulz"] = ulz
        sp["nitvy"] = nitvy
        sp["nitvz"] = nitvz


def sc5408_test_main(zkap, start_key, resume=-1):
    print("Hi IH-MI_1531!")

    # verify zkap
    print(zkap)

    # read table
    instll = make_instruct_list(ORI_INSTRUCT)
    print(instll)

    # setup params
    scanparams = dict(
        lly=-75,
        uly=75,
        nitvy=75,
        llz=-110,
        ulz=110,
        nitvz=110,
        expt=0.005,
        retveloc=5.0,
    )
    # resume = -1 >>> does all the list
    # resume=n .... starts item from nth external index (PSI matlab script)
    ttm = TTomo("asy.com", zkap, instll, scanparams, resume=resume, start_key=start_key)

    # loop over projections
    ttm.mainloop()
