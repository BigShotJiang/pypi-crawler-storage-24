import os

import h5py
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Slider
from mpl_toolkits.mplot3d import Axes3D


def quaternion_rotate_vector(q, v, inverse=False):
    """
    Rotate a 3D vector `v` by quaternion `q`.

    Parameters:
    - q: array-like, shape (4,), unit quaternion in [w, x, y, z] format.
    - v: array-like, shape (3,), the vector to rotate.
    - inverse: bool, if True, apply the inverse (conjugate) rotation.

    Returns:
    - Rotated vector of shape (3,).
    """
    q = q / np.linalg.norm(q)
    if inverse:
        q = q * np.array([1, -1, -1, -1])  # quaternion conjugate

    w, x, y, z = q
    # Rotation matrix from quaternion
    R = np.array(
        [
            [w * w + x * x - y * y - z * z, 2 * (x * y - w * z), 2 * (x * z + w * y)],
            [2 * (x * y + w * z), w * w - x * x + y * y - z * z, 2 * (y * z - w * x)],
            [2 * (x * z - w * y), 2 * (y * z + w * x), w * w - x * x - y * y + z * z],
        ]
    )
    return R @ v


def matrix_rotate_vector(M, v, inverse=False):
    if inverse:
        return v @ M
    else:
        return M @ v


def plot_rotations(rotations, fun):
    fig = plt.figure(figsize=(12, 6))
    ax1 = fig.add_subplot(121, projection="3d")
    ax2 = fig.add_subplot(122, projection="3d")
    plt.subplots_adjust(bottom=0.25)

    basis = np.eye(3)
    colors = ["r", "g", "b"]
    labels = ["x", "y", "z"]

    def setup_axis(ax, title):
        ax.set_xlim([-1, 1])
        ax.set_ylim([-1, 1])
        ax.set_zlim([-1, 1])
        ax.set_box_aspect([1, 1, 1])
        ax.set_xlabel("X")
        ax.set_ylabel("Y")
        ax.set_zlabel("Z")
        ax.set_title(title)
        ax.set_xticks([-1, 1])
        ax.set_yticks([-1, 1])
        ax.set_zticks([-1, 1])

    setup_axis(ax1, "Normal Rotation")
    setup_axis(ax2, "Inverse Rotation")

    # Placeholders for lines
    lines1 = [
        ax1.plot([0, 0], [0, 0], [0, 0], color=colors[i], label=labels[i])[0]
        for i in range(3)
    ]
    lines2 = [
        ax2.plot([0, 0], [0, 0], [0, 0], color=colors[i], label=labels[i])[0]
        for i in range(3)
    ]

    ax1.legend()
    ax2.legend()

    ax_slider = plt.axes([0.2, 0.1, 0.6, 0.03])
    slider = Slider(ax_slider, "Index", 0, len(rotations) - 1, valinit=0, valstep=1)

    def update(val):
        idx = int(slider.val)
        q = rotations[idx]

        for i in range(3):
            # Normal rotation
            v1 = fun(q, basis[i])
            lines1[i].set_data([0, v1[0]], [0, v1[1]])
            lines1[i].set_3d_properties([0, v1[2]])

            # Inverse rotation
            v2 = fun(q, basis[i], inverse=True)
            lines2[i].set_data([0, v2[0]], [0, v2[1]])
            lines2[i].set_3d_properties([0, v2[2]])

        fig.canvas.draw_idle()

    slider.on_changed(update)
    update(0)
    plt.show()


# def plot_rotations(rotations, fun ):
#     """Plot coordinate axes rotated by quaternions with a slider."""
#     fig = plt.figure(figsize=(8, 6))
#     ax = fig.add_subplot(121, projection='3d')
#     plt.subplots_adjust(bottom=0.25)

#     # Initial basis vectors
#     basis = np.eye(3)

#     # Plot placeholders
#     lines = []
#     colors = ['r', 'g', 'b']
#     labels = ['x','y','z']
#     for i in range(3):
#         line, = ax.plot([0, basis[i, 0]], [0, basis[i, 1]], [0, basis[i, 2]], color=colors[i], lw=2, label=labels[i])
#         lines.append(line)

#     ax.set_xlim([-1, 1])
#     ax.set_ylim([-1, 1])
#     ax.set_zlim([-1, 1])
#     ax.set_box_aspect([1,1,1])
#     ax.set_xlabel('X')
#     ax.set_ylabel('Y')
#     ax.set_zlabel('Z')

#     ax.set_title('Rotated Coordinate Axes')
#     ax.legend()

#     # Slider
#     ax_slider = plt.axes([0.2, 0.1, 0.65, 0.03])
#     slider = Slider(ax_slider, 'Index', 0, len(rotations) - 1, valinit=0, valstep=1)

#     def update(val):
#         idx = int(slider.val)
#         q = rotations[idx]
#         for i in range(3):
#             vec0 = fun(q, basis[i], inverse=inverse)
#             lines[i].set_data([0, vec0[0]], [0, vec0[1]])
#             lines[i].set_3d_properties([0, vec0[2]])
#         fig.canvas.draw_idle()

#     slider.on_changed(update)
#     update(0)  # initial plot

#     #

from textom.src.model import rotation as rot

sample_dir = "/Users/moritz/Documents/papers/biomorphs/helix_s7_textom/"
with h5py.File(os.path.join(sample_dir, "analysis", "projectors.h5"), "r") as hf:
    Gs = hf["Gs"][()]
    Ome = hf["Omega"][()]
    Kap = hf["Kappa"][()]

print("Index\tInner\tOuter")
for g in range(Ome.size):
    print(
        f"{g}\t{np.round(Ome[g] * 180 / np.pi, 1)}\t{np.round(Kap[g] * 180 / np.pi, 1)}"
    )

Qs = rot.QfromOTP(Gs)
Ms = np.array([rot.MatrixfromOTP(g[0], g[1], g[2]) for g in Gs])

vec = np.array([0, 0, 1])
for k in range(Qs.shape[0]):
    vrot_q = quaternion_rotate_vector(Qs[k], vec, inverse=False)
    vrot_m = matrix_rotate_vector(Ms[k], vec, inverse=False)
    if not np.isclose(np.dot(vrot_m, vrot_q), 1):
        print(np.round(vrot_q, 5))
        print(np.round(vrot_m, 5))

plot_rotations(Qs, quaternion_rotate_vector)
# plot_rotations(Ms, matrix_rotate_vector )
# plt.show(block=True)


stop = 1
