import os

import h5py
import matplotlib.pyplot as plt
import numpy as np

from textom.src import handle as hdl
from textom.src.analysis import orix_plugins as orx
from textom.src.model import rotation as rot
from textom.src.odf import hsh

############### input ##################
sample_dir = "/dataSATA/data_synchrotron/esrf_id13_2025_07_tooth/PROCESSED_DATA/integ/S_MUR_A_IE_19/"
path_optimization = os.path.join(
    sample_dir, "analysis/fits/opt_S_MUR_A_IE_19_magic_nmax12_2025_07_16_10h29.h5"
)
path_voxelmask = os.path.join(sample_dir, "analysis/voxelmask.txt")
sample_shape = (250, 250, 250)
path_output = os.path.join(sample_dir, "full_sample_textures.h5")
symmetry = "6"
n_max = 12
odf_resolution = 6  # degree
center_odfs = False
save_textures = False

plot_individual_texture = True
pole_figure_hkl = [0, 0, 1]
index = 7703090  # put here the index from the file
#######################################

opt = hdl.load_h5_to_dict(path_optimization)
C = opt["c"]
Gc, dV, V_fz = rot.sample_fundamental_zone(
    dchi=odf_resolution * np.pi / 180, sampling="cubochoric", symmetry=symmetry
)
Q_grid = rot.QfromOTP(Gc)
mask_voxels = np.genfromtxt(path_voxelmask, np.int32)

if plot_individual_texture:
    odf = hsh.get_odf(C[index], Gc, symmetry, n_max)
    orx.plot_odf(Q_grid, odf, symmetry)
    orx.plot_pole_figure(Gc, odf, symmetry, pole_figure_hkl)
    plt.show(block=True)

if save_textures:
    odfs = hsh.get_odf_batch(C[mask_voxels], Gc, symmetry, n_max)
    if center_odfs:
        ig = np.argmax(odfs, axis=1)  # index of the maximum of the odf
        G_max = Gc[ig]
        odfs_centered = hsh.get_odf_centered_batch(
            C[mask_voxels], Gc, G_max, symmetry, n_max
        )

    x, y, z = (
        np.arange(sample_shape[0]),
        np.arange(sample_shape[1]),
        np.arange(sample_shape[2]),
    )
    X, Y, Z = np.meshgrid(x, y, z)
    coords = np.column_stack((X.flatten(), Y.flatten(), Z.flatten()))[mask_voxels]

    with h5py.File(path_output, "w") as hf:
        hf.create_dataset("voxel_coordinates", data=coords)
        hf.create_dataset("orientations_axisangle", data=Gc)
        hf.create_dataset("orientations_quaternions", data=Q_grid)
        hf.create_dataset("weights", data=C[:, 0])

        hf.create_dataset("odfs", data=odfs)
        if center_odfs:
            hf.create_dataset("odfs_centered", data=odfs_centered)
