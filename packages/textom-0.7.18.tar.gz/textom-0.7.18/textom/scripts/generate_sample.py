import glob
import os
import shutil
import sys

os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
from importlib import reload  # this is to reload
from time import time
from typing import Optional, Union

import h5py
import hdf5plugin
import imageio.v3 as iio
import matplotlib.pyplot as plt
import numpy as np
import orix.quaternion.symmetry as osym
from numba import njit, prange

import textom.src.analysis.orix_plugins as orx
import textom.src.model.rotation as rot
import textom.src.model.symmetries as sym
from textom.config import data_type
from textom.src.model.model_textom import model_textom
from textom.src.numba_plugins import integrate_c
from textom.src.odf.gridbased import fisher_SO3, gaussian_3d

sample_dir = "/Users/moritz/Documents/papers/benchmark/gen_sample/"
os.makedirs(os.path.join(sample_dir, "analysis"), exist_ok=True)
os.makedirs(os.path.join(sample_dir, "data_integrated"), exist_ok=True)

sample_outline_size = (4, 5, 6)
omega, kappa = rot.samplerotations_eq3D(d_rot=30, tilts=(0, 30, 60))
sample_mask = np.zeros(sample_outline_size, bool)
sample_mask[1:-1, 1:-1, 1:-1] = 1

# save alignment file for projectors
tomogram = sample_mask.astype(data_type)
with h5py.File(os.path.join(sample_dir, "analysis", "alignment_result.h5"), "w") as hf:
    hf.create_dataset("kappa", data=kappa)
    hf.create_dataset("omega", data=omega)
    hf.create_dataset("shifts", data=np.zeros((kappa.size, 2)))
    hf.create_dataset("tomogram", data=tomogram)
    hf.create_dataset("sinogram", data=[])

with open(os.path.join(sample_dir, "analysis", "voxelmask.txt"), "w") as fid:
    for iv in np.where(sample_mask.flatten())[0]:
        fid.write(f"{iv}\n")

# # for recalculating projectors
# if os.path.isfile(os.path.join(sample_dir,'analysis','projectors.h5')):
#     os.remove(os.path.join(sample_dir,'analysis','projectors.h5'))

mod = model_textom(sample_dir)

# ODF parameters  ######### shouldn't this be the same as the sampling of Isc? doesn't really matter in this case..
resolution = 25  # degree
pg = getattr(osym, sym.get_SFnotation(mod.symmetry))
q_odf = rot.get_sample_fundamental(
    resolution, point_group=pg, method="cubochoric"
).data.astype(data_type)
n_basis_functions = q_odf.shape[0]
# kappa = 5* 1/(resolution*np.pi/180)**2
gen = sym.generators(mod.symmetry)
# show sampling
orx.plot_points_in_fz(q_odf, mod.symmetry)

# set up sample coefficients
sample_bf_coefficients = np.zeros(
    (np.prod(sample_outline_size), n_basis_functions), data_type
)
flatmask = np.where(sample_mask.flatten())[0]
for v in flatmask:
    i_dir = np.random.randint(n_basis_functions)
    sample_bf_coefficients[v, i_dir] = 1


# @njit(parallel=True)
def projection(Gc, Isc, Beams, iBeams, detShape, dV):
    diff_patterns_g = np.empty((Beams.shape[1], detShape[0], detShape[1]), data_type)
    for t in prange(Beams.shape[1]):
        # project the coefficients
        iend = np.searchsorted(iBeams[g, t, :], 2**32 - 1)  # for sparsearray
        c_proj = integrate_c(
            Beams[g, t, :iend], iBeams[g, t, :iend], sample_bf_coefficients
        )
        # get the resulting odf from rotated mu
        odf_proj = np.zeros(Gc.shape[0], data_type)
        idcs_basis = np.nonzero(c_proj > 0.01 * c_proj.max())[0]
        for c in idcs_basis:
            q_mu = rot.quaternion_multiply(q_odf[c], Qs[g])
            odf_proj += c_proj[c] * gaussian_3d(
                Qc, q_mu, resolution * np.pi / 180, gen, dV
            )
        # sparse calculate the projections (only points in odf that are high)
        diff_pattern = np.zeros(Isc.shape[1], data_type)
        idcs_odf = np.nonzero(odf_proj > 0.01 * odf_proj.max())[0]
        for h in idcs_odf:
            diff_pattern += Isc[h] * odf_proj[h]
        diff_patterns_g[t] = diff_pattern.reshape((detShape[0], detShape[1]))
    return diff_patterns_g


Qs = rot.QfromOTP(mod.Gs)
Qc = rot.QfromOTP(mod.Gc)

# show the center of the distribution
orx.plot_points_in_fz(q_odf[11], mod.symmetry)
plt.title("mean")
# plot gaussian distribution
orx.plot_odf(
    mod.Gc,
    gaussian_3d(Qc, q_odf[11], resolution * np.pi / 180, gen, 1),
    mod.symmetry,
    num_samples=1000,
)
plt.title("gauss")
# plot fisher distribution
orx.plot_odf(
    mod.Gc,
    fisher_SO3(Qc, q_odf[11], 10 / (resolution * np.pi / 180) ** 2, gen, 1),
    mod.symmetry,
    num_samples=1000,
)
plt.title("fisher")
# plot a polefigure
odf = gaussian_3d(Qc, q_odf[11], resolution * np.pi / 180, gen, 1)
orx.plot_pole_figure_from_odf(mod.Gc, odf, mod.symmetry, hkl=(1, 0, 0))
orx.plot_pole_figure_from_odf(mod.Gc, odf, mod.symmetry, hkl=(0, 1, 0))
orx.plot_pole_figure_from_odf(mod.Gc, odf, mod.symmetry, hkl=(0, 0, 1))

for g in range(mod.Beams.shape[0]):
    diff_patterns_g = projection(
        mod.Gc, mod.Isc, mod.Beams, mod.iBeams, mod.detShape, mod.dV
    )

    with h5py.File(
        os.path.join(sample_dir, "data_integrated", f"gen_sample_proj{g:03d}.h5"), "w"
    ) as hf:
        hf.create_dataset("cake_integ", data=diff_patterns_g)
        hf.create_dataset("fov", data=mod.fov)
        hf.create_dataset("radial_units", data=mod.Qq_det.reshape(mod.detShape)[0])
        hf.create_dataset(
            "azimuthal_units", data=mod.Chi_det.reshape(mod.detShape)[:, 0]
        )
