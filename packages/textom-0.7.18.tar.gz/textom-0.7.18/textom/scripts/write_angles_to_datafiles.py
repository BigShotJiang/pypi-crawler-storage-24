import glob
import os

import h5py
import numpy as np

filelist = glob.glob(os.path.join("data_integrated_1d", "*h5"))
for file in filelist:
    # find out angles from name:
    splnm = file.split("_")
    i_diff = next(i for i, s in enumerate(splnm) if "diff" in s)  # find where is 'diff'
    kappa = float(splnm[i_diff - 2].replace("m", "-"))
    omega = float(splnm[i_diff - 1].replace("p", "."))
    with h5py.File(file, "r+") as hf:
        hf.create_dataset("rot_angle", data=omega)
        hf.create_dataset("tilt_angle", data=kappa)
