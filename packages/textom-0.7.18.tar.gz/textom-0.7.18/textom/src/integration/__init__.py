"""Integration subpackage for textom."""

from . import pyfai_plugins

__all__ = ["pyfai_plugins"]
