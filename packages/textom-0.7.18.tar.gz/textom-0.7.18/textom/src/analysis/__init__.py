"""Analysis subpackage for textom."""
