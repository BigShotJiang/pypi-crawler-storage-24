# textom/__init__.py
import os
import sys

import psutil
from threadpoolctl import threadpool_limits

from .config import n_threads
from .src.misc import get_affinity_info

# Set package metadata
__author__ = "Moritz Frewein, Moritz Stammer, Marc Allain, Tilman Gruenewald"
__email__ = "textom@fresnel.fr"

# parallelisation settings
aff_info = (
    get_affinity_info()
)  # this is to avoid conflicts with parallelisation via taskset
if not aff_info["restricted"]:
    # set everything to single threaded
    threadpool_limits(limits=1)
    os.environ["MKL_NUM_THREADS"] = "1"
    os.environ["NUMEXPR_NUM_THREADS"] = "1"
    os.environ["OMP_NUM_THREADS"] = "1"
    os.environ["OPENBLAS_NUM_THREADS"] = "1"
    from numba import set_num_threads

    n_threads = min(
        psutil.cpu_count(), n_threads
    )  # make sure the number of threads doesn't exceed the possible ones
    set_num_threads(n_threads)

sys.stdout.reconfigure(encoding="utf-8")
