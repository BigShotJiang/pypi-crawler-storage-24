from typing import Any, Self

from google.oauth2.credentials import Credentials

class InstalledAppFlow:
    @classmethod
    def from_client_config(
        cls,
        client_config: dict[str, Any],
        scopes: list[str],
    ) -> Self: ...
    def run_local_server(
        self,
        *,
        port: int = ...,
        include_granted_scopes: str | None = ...,
    ) -> Credentials: ...
