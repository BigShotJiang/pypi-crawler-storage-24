from typing import Any

from google.oauth2.credentials import Credentials

class Resource:
    def __getattr__(self, name: str) -> Any: ...

def build(
    serviceName: str,
    version: str,
    *,
    credentials: Credentials | None = ...,
    cache_discovery: bool = ...,
) -> Resource: ...
