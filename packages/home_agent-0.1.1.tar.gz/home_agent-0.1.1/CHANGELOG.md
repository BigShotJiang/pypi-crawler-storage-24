# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.1] - 2026-03-21

### Changed

- Backfill changelog with retroactive versions 0.0.1–0.0.4

## [0.1.0] - 2026-03-21

### Added

- ClaudeSDKRunner using claude-agent-sdk alongside CLI subprocess runner
- `--version` flag via importlib.metadata
- Release pipeline: changelog, release script, GitHub Actions workflows
- `ty` as tertiary type checker in pre-commit

### Changed

- Demote mypy to secondary role; basedpyright is now primary checker
- Add ANN (annotation) rules to ruff linting
- Add explicit type annotations on instance attributes across 21 files
- Collapse multi-line f-strings into single lines

## [0.0.4] - 2026-03-18

### Added

- basedpyright type checker with strict "all" mode
- Pre-commit hooks for automated linting/type checking
- Type stubs for msal, sqlite_vec, google_auth_oauthlib, googleapiclient
- Google API service Protocols replacing type ignores
- TokenStore Protocol for auth abstraction

### Changed

- Expand ruff rules for stricter code quality
- Replace DesktopNotifierBackend Protocol with real DesktopNotifierSync types
- Cast structlog.get_logger return instead of type: ignore
- Type _diagnose_plugin as ProviderPlugin instead of object

### Removed

- Qdrant vector backend and Voyage API embedding provider
- SqliteRetriever (consolidated into sqlite-vec backend)
- 691 lines of unused retrieval code

### Fixed

- ruff EM101/EM102, PT013, G004, B905, SIM108, UP040, F821 violations
- mypy/basedpyright type errors across auth, CLI, logging, and tests

## [0.0.3] - 2026-03-03

### Added

- Structured runtime and subprocess logging to `.data/logs/home-agent.jsonl`
- CLI flags: `--debug`, `--raw-shell-io`, `--log-dir`
- Configurable subprocess timeout (default 120s) for LLM commands
- Stale Google auth scope detection with reset instructions

### Changed

- Migrate notifications from custom PowerShell toasts to desktop-notifier library
- Harden Windows toast notification payloads with XML builder and base64 encoding
- Use `--json-schema` for Claude CLI classification (structured output)

### Fixed

- Claude CLI classification parsing failures from markdown-wrapped JSON
- Preserve granted scopes on Google re-auth (`include_granted_scopes`)
- LLM subprocess timeout handling — distinguish timeouts from other failures

## [0.0.2] - 2026-03-02

### Added

- Typed embedding interfaces and SQLite schema for vector storage
- Embedding generation pipeline with provider abstraction
- Retrieval service with retrieval event persistence
- Retrieval context injection into Claude classification prompts
- `embeddings backfill` CLI command with batch processing
- Vector backend abstraction with swappable backends (sqlite-vec, Qdrant)
- Sentence-transformers and Voyage embedding providers
- Provider diagnostics in `run` and `doctor` commands
- Auth reset command (`--reset`)
- Google smoke test command (`test` subcommand)
- Support for Google client secrets JSON files
- Retrieval architecture documentation

### Changed

- Combine Google auth scopes in single auth flow instead of per-plugin
- Clean up mypy config: remove redundant flags, add error codes and pretty output

### Fixed

- sqlite-vec null labels and backend-aware backfill
- mypy list variance errors with Sequence
- Embedding backfill and retrieval error reporting hardened
- Auth init setup errors now handled gracefully

## [0.0.1] - 2026-02-27

### Added

- Project scaffold: uv project, pyproject.toml, typed core contracts and protocols
- Pluggable orchestrator with tracer, plugin registry, and budget guard
- CLI runtime with `run`, `auth`, `digest`, `doctor`, `bootstrap` subcommands
- SQLite storage engine with encrypted token persistence
- Scoped memory engine with candidate review CLI (list, approve, reject)
- Gmail, Graph Mail, and Google Calendar provider adapters
- Google and Microsoft OAuth authentication flows
- Claude headless and Codex exec LLM runners with usage accounting
- Desktop toast notifications (Windows)
- Comprehensive test suite: orchestrator, plugins, memory flow, budget guard
