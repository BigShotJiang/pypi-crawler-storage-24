from pathlib import Path

from home_agent.contracts.types import MemoryRuleCandidate
from home_agent.storage.sqlite_store import SqliteStore


def test_memory_candidate_rejection(tmp_path: Path) -> None:
    store = SqliteStore(tmp_path / "test.db")
    store.save_memory_candidates(
        [
            MemoryRuleCandidate(
                rule_key="subject_token:newsletter",
                description="Newsletter messages are important",
                evidence_count=2,
                confidence=0.7,
            )
        ]
    )

    store.reject_memory_candidate("subject_token:newsletter", reason="too noisy")

    rejected = store.list_memory_candidates(status="rejected")
    assert len(rejected) == 1
    assert rejected[0].rule_key == "subject_token:newsletter"
    assert rejected[0].rejected_reason == "too noisy"
