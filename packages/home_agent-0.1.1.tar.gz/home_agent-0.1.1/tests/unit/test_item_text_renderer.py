from datetime import UTC, datetime

from home_agent.contracts.types import Item, ItemKind
from home_agent.retrieval.text_renderer import DefaultItemTextRenderer


def test_render_email_item_includes_subject_sender_and_snippet() -> None:
    renderer = DefaultItemTextRenderer()
    item = Item(
        provider="gmail",
        external_id="msg-1",
        kind=ItemKind.EMAIL,
        received_at=datetime.now(tz=UTC),
        subject="Assignment deadline tomorrow",
        sender="lecturer@example.edu",
        metadata={"snippet": "Please submit before 5pm", "importance": "high"},
    )

    rendered = renderer.render(item)

    assert rendered.provider == "gmail"
    assert rendered.external_id == "msg-1"
    assert "subject=Assignment deadline tomorrow" in rendered.embedding_text
    assert "sender=lecturer@example.edu" in rendered.embedding_text
    assert "snippet=Please submit before 5pm" in rendered.embedding_text
    assert "Assignment deadline tomorrow" in rendered.summary_text


def test_render_calendar_item_includes_title_owner_and_start_time() -> None:
    renderer = DefaultItemTextRenderer()
    item = Item(
        provider="google_calendar",
        external_id="evt-1",
        kind=ItemKind.CALENDAR_EVENT,
        received_at=datetime.now(tz=UTC),
        subject="FIT3171 exam review",
        sender="calendar@example.com",
        metadata={"start_at": "2026-03-02T10:00:00+00:00", "status": "confirmed"},
    )

    rendered = renderer.render(item)

    assert "title=FIT3171 exam review" in rendered.embedding_text
    assert "owner=calendar@example.com" in rendered.embedding_text
    assert "start_at=2026-03-02T10:00:00+00:00" in rendered.embedding_text
    assert "FIT3171 exam review" in rendered.summary_text
