from datetime import UTC, datetime

from home_agent.contracts.types import Item, ItemKind
from home_agent.memory.engine import ScopedMemoryEngine


def test_extract_candidates_requires_repetition() -> None:
    engine = ScopedMemoryEngine()
    items = [
        Item(
            provider="gmail",
            external_id="1",
            kind=ItemKind.EMAIL,
            received_at=datetime.now(tz=UTC),
            subject="University assignment deadline",
            sender="a@u.edu",
            metadata={},
        ),
        Item(
            provider="gmail",
            external_id="2",
            kind=ItemKind.EMAIL,
            received_at=datetime.now(tz=UTC),
            subject="University exam reminder",
            sender="b@u.edu",
            metadata={},
        ),
    ]

    candidates = engine.extract_candidates(items)
    keys = {candidate.rule_key for candidate in candidates}
    assert "subject_token:university" in keys
