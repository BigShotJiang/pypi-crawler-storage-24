from datetime import UTC, datetime
from pathlib import Path

from home_agent.contracts.types import (
    EmbeddingRecord,
    ItemKind,
    RenderedItemText,
    RetrievalDecisionTrace,
)
from home_agent.storage.sqlite_store import SqliteStore


def test_store_round_trips_rendered_item_text(tmp_path: Path) -> None:
    store = SqliteStore(tmp_path / "agent.db")
    rendered = RenderedItemText(
        provider="gmail",
        external_id="abc",
        kind=ItemKind.EMAIL,
        embedding_text="kind=email\nsubject=Deadline",
        summary_text="Deadline | from dean@example.edu",
    )

    store.save_item_text(rendered)

    loaded = store.get_item_text("gmail", "abc")

    assert loaded == rendered


def test_store_accepts_embedding_and_retrieval_trace(tmp_path: Path) -> None:
    store = SqliteStore(tmp_path / "agent.db")
    store.save_item_embedding(
        EmbeddingRecord(
            provider="gmail",
            external_id="abc",
            embedding_provider="local",
            embedding_model="hash",
            vector=[0.1, 0.2, 0.3],
            dimension=3,
            created_at=datetime.now(tz=UTC),
        )
    )

    store.save_retrieval_event(
        RetrievalDecisionTrace(
            run_id=1,
            source_provider="gmail",
            source_external_id="abc",
            matched_provider="gmail",
            matched_external_id="xyz",
            similarity=0.88,
            stage="retrieved",
            included_in_prompt=False,
            created_at=datetime.now(tz=UTC),
        )
    )
