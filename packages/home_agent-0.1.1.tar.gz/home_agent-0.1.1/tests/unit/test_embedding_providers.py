import pytest

from home_agent.retrieval.embedding_providers import (
    SentenceTransformerEmbeddingProvider,
)


def test_sentence_transformer_provider_returns_one_vector_per_input(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeEncoded:
        def __init__(self, values: list[list[float]]) -> None:
            self._values: list[list[float]] = values

        def tolist(self) -> list[list[float]]:
            return self._values

    class FakeModel:
        def __init__(self, model_name: str) -> None:
            self.model_name: str = model_name

        def encode(self, texts: list[str], normalize_embeddings: bool = True) -> FakeEncoded:
            _ = normalize_embeddings
            return FakeEncoded(
                [[float(index), float(index) + 0.5] for index, _ in enumerate(texts)]
            )

    monkeypatch.setattr(
        "home_agent.retrieval.embedding_providers._load_sentence_transformer",
        lambda model_name: FakeModel(model_name),
    )
    provider = SentenceTransformerEmbeddingProvider(model_name="all-MiniLM-L6-v2")

    vectors = provider.embed_texts(["one", "two"])

    assert provider.provider_name == "local_sentence_transformers"
    assert vectors == [[0.0, 0.5], [1.0, 1.5]]
