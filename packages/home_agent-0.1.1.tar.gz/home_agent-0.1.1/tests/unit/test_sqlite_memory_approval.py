from pathlib import Path

from home_agent.contracts.types import MemoryRuleCandidate
from home_agent.storage.sqlite_store import SqliteStore


def test_memory_candidate_approval(tmp_path: Path) -> None:
    store = SqliteStore(tmp_path / "test.db")
    store.save_memory_candidates(
        [
            MemoryRuleCandidate(
                rule_key="subject_token:university",
                description="University emails are important",
                evidence_count=3,
                confidence=0.8,
            )
        ]
    )

    store.approve_memory_candidate("subject_token:university")
    active = store.list_active_memory_rules()
    assert len(active) == 1
    assert active[0].rule_key == "subject_token:university"

    candidates = store.list_memory_candidates(status="approved")
    assert any(candidate.rule_key == "subject_token:university" for candidate in candidates)
