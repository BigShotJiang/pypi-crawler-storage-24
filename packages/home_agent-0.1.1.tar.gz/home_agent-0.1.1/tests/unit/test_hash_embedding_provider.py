from home_agent.retrieval.embeddings import HashEmbeddingProvider


def test_hash_embedding_provider_is_deterministic() -> None:
    provider = HashEmbeddingProvider()

    first = provider.embed_texts(["assignment deadline tomorrow"])[0]
    second = provider.embed_texts(["assignment deadline tomorrow"])[0]

    assert first == second
    assert len(first) == 64
    assert any(value != 0.0 for value in first)
