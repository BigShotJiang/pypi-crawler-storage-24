from home_agent.llm.runner import BudgetGuard


def test_budget_guard_blocks_when_cap_reached() -> None:
    guard = BudgetGuard(month_spend_usd=10.0, month_cap_usd=10.0)
    assert not guard.allows_call()
