from pathlib import Path

from home_agent.cli.main import _build_parser
from home_agent.core.config import load_config


def test_parser_accepts_run_logging_flags(tmp_path: Path) -> None:
    parser = _build_parser()

    args = parser.parse_args(
        [
            "--config",
            str(tmp_path / "home-agent.toml"),
            "run",
            "--debug",
            "--log-level",
            "debug",
            "--log-dir",
            str(tmp_path / "logs"),
            "--raw-shell-io",
        ]
    )

    assert args.command == "run"
    assert args.debug is True
    assert args.log_level == "debug"
    assert args.log_dir == tmp_path / "logs"
    assert args.raw_shell_io is True


def test_load_config_reads_logging_section(tmp_path: Path) -> None:
    config_path = tmp_path / "home-agent.toml"
    config_path.write_text(
        """
[logging]
directory = "custom-logs"
file_name = "agent.log.jsonl"
console_level = "DEBUG"
file_level = "DEBUG"
enable_console = true
capture_raw_payloads = true
subprocess_preview_chars = 1234
max_bytes = 2222
backup_count = 7
""".strip(),
        encoding="utf-8",
    )

    config = load_config(config_path)

    assert config.logging.directory == Path("custom-logs")
    assert config.logging.file_name == "agent.log.jsonl"
    assert config.logging.console_level == "DEBUG"
    assert config.logging.file_level == "DEBUG"
    assert config.logging.enable_console is True
    assert config.logging.capture_raw_payloads is True
    assert config.logging.subprocess_preview_chars == 1234
    assert config.logging.max_bytes == 2222
    assert config.logging.backup_count == 7
