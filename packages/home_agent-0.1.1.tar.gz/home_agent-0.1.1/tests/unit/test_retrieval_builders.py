from pathlib import Path

from home_agent.cli.main import (
    _build_embedding_provider,
    _build_vector_backend,
)
from home_agent.core.config import (
    AlertsConfig,
    AppConfig,
    BudgetConfig,
    EmbeddingsConfig,
    LLMConfig,
    MemoryConfig,
    PollConfig,
    RetentionConfig,
    RetrievalConfig,
    SqliteVecConfig,
)
from home_agent.storage.sqlite_store import SqliteStore


def _config(db_path: Path) -> AppConfig:
    return AppConfig(
        poll=PollConfig(),
        budget=BudgetConfig(),
        retention=RetentionConfig(),
        alerts=AlertsConfig(),
        llm=LLMConfig(),
        memory=MemoryConfig(),
        enabled_providers=[],
        sqlite_path=db_path,
        daily_digest_enabled=True,
        embeddings=EmbeddingsConfig(
            enabled=True,
            provider="local_sentence_transformers",
            model="demo-model",
            batch_size=8,
        ),
        retrieval=RetrievalConfig(enabled=True),
        sqlite_vec=SqliteVecConfig(),
    )


def test_build_embedding_provider_returns_sentence_transformer_provider(
    tmp_path: Path,
) -> None:
    config = _config(tmp_path / "agent.db")

    provider = _build_embedding_provider(config)

    assert provider is not None
    assert provider.provider_name == "local_sentence_transformers"


def test_build_vector_backend_returns_sqlite_vec(tmp_path: Path) -> None:
    config = _config(tmp_path / "agent.db")
    store = SqliteStore(config.sqlite_path)

    backend = _build_vector_backend(config, store)

    assert backend is not None
    assert backend.backend_name == "sqlite_vec"
