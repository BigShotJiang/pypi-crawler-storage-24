from pathlib import Path

from home_agent.cli.main import _write_bootstrap_script


def test_write_bootstrap_script(tmp_path: Path) -> None:
    script = tmp_path / "bootstrap.ps1"
    _write_bootstrap_script(script, "PT15M")
    content = script.read_text(encoding="utf-8")
    assert "Register-ScheduledTask" in content
    assert "PT15M" in content
