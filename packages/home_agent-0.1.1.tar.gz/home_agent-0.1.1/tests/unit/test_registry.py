from dataclasses import dataclass

import pytest

from home_agent.plugins_builtin.registry import load_plugins


class DummyPlugin:
    id: str = "dummy"
    version: str = "1.0"

    def get_mail_reader(self) -> None:
        return None

    def get_calendar_reader(self) -> None:
        return None


@dataclass(frozen=True)
class DummyEntryPoint:
    group: str = "home_agent.providers"

    def load(self) -> type[DummyPlugin]:
        return DummyPlugin


def test_load_plugins_with_enabled_filter(monkeypatch: pytest.MonkeyPatch) -> None:
    entry = DummyEntryPoint()
    monkeypatch.setattr(
        "home_agent.plugins_builtin.registry.entry_points",
        lambda group: [entry] if group == "home_agent.providers" else [],
    )

    plugins = load_plugins(enabled={"dummy"})
    assert len(plugins) == 1
    assert plugins[0].id == "dummy"
