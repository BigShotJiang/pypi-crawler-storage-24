from pathlib import Path

from home_agent.core.config import load_config


def test_load_config_parses_retrieval_settings(tmp_path: Path) -> None:
    config_path = tmp_path / "home-agent.toml"
    config_path.write_text(
        """
[embeddings]
enabled = true
provider = "local_sentence_transformers"
model = "all-MiniLM-L6-v2"
batch_size = 16

[retrieval]
enabled = true
top_k = 7
min_similarity = 0.66
max_prompt_examples = 2
prioritize_labels = ["high"]
include_item_kinds = ["email"]

[sqlite_vec]
enabled = true
distance_metric = "cosine"
table_name = "vec_items"

[llm]
timeout_seconds = 120
""",
        encoding="utf-8",
    )

    config = load_config(config_path)

    assert config.embeddings.provider == "local_sentence_transformers"
    assert config.embeddings.model == "all-MiniLM-L6-v2"
    assert config.llm.timeout_seconds == 120
    assert config.retrieval.top_k == 7
    assert config.sqlite_vec.table_name == "vec_items"
