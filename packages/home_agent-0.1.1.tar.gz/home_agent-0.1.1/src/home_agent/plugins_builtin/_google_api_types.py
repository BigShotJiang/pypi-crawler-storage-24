"""Typed Protocols for Google API service resources.

Parameter names match the Google API (camelCase) so they can't follow PEP 8.
"""

from typing import Any, Protocol


class GoogleApiRequest(Protocol):
    def execute(self) -> dict[str, Any]: ...


class GmailMessagesResource(Protocol):
    def list(
        self, *, userId: str, maxResults: int = ..., q: str = ...  # noqa: N803
    ) -> GoogleApiRequest: ...

    def get(
        self, *, userId: str, id: str, format: str = ...  # noqa: A002, N803
    ) -> GoogleApiRequest: ...


class GmailUsersResource(Protocol):
    def messages(self) -> GmailMessagesResource: ...


class GmailService(Protocol):
    def users(self) -> GmailUsersResource: ...


class CalendarEventsResource(Protocol):
    def list(
        self,
        *,
        calendarId: str,  # noqa: N803
        timeMin: str = ...,  # noqa: N803
        maxResults: int = ...,  # noqa: N803
        singleEvents: bool = ...,  # noqa: N803
        orderBy: str = ...,  # noqa: N803
    ) -> GoogleApiRequest: ...

    def get(self, *, calendarId: str, eventId: str) -> GoogleApiRequest: ...  # noqa: N803


class CalendarService(Protocol):
    def events(self) -> CalendarEventsResource: ...
