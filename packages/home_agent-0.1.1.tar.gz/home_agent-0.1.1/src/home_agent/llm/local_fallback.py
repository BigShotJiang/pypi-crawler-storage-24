from home_agent.contracts.types import (
    Item,
    LLMResult,
    LLMUsage,
    RetrievedMatch,
    UrgencyDecision,
    UrgencyLabel,
)


class DeterministicFallbackRunner:
    def classify(
        self, item: Item, retrieved_matches: list[RetrievedMatch] | None = None
    ) -> LLMResult:
        _ = retrieved_matches
        lowered = item.subject.lower()
        if "urgent" in lowered or "deadline" in lowered:
            decision = UrgencyDecision(
                score=0.9,
                label=UrgencyLabel.CRITICAL,
                reasons=["fallback-keyword"],
                used_llm=False,
            )
        else:
            decision = UrgencyDecision(
                score=0.5,
                label=UrgencyLabel.MEDIUM,
                reasons=["fallback-default"],
                used_llm=False,
            )

        usage = LLMUsage(
            provider="fallback",
            model=None,
            total_cost_usd=None,
            input_tokens=None,
            output_tokens=None,
            raw={},
        )
        return LLMResult(decision=decision, usage=usage, raw_response={})
