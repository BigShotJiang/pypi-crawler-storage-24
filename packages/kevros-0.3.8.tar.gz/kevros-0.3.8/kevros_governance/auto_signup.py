"""
Auto-signup for Kevros Agentic Identity Trust.

Zero-friction: if no API key is provided, signs up automatically and
caches the key in ~/.kevros/api_key. The agent gets a verifiable identity
without any human in the loop.

Used by: GovernanceClient, LangChain tools, CrewAI tools, OpenAI functions, MCP server.
"""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, Optional

import httpx

logger = logging.getLogger("kevros.auto_signup")

DEFAULT_GATEWAY_URL = "https://governance.taskhawktech.com"
_KEY_DIR = Path.home() / ".kevros"
_KEY_FILE = _KEY_DIR / "api_key"
_TIMEOUT = 15.0

# API keys are expected to match this pattern: kvrs_ followed by 16-128
# alphanumeric/underscore/hyphen characters.
_API_KEY_RE = re.compile(r"^kvrs_[a-zA-Z0-9_-]{16,128}$")


def _validate_api_key_format(key: str) -> bool:
    """Check whether a string looks like a valid Kevros API key."""
    return bool(_API_KEY_RE.match(key))


def _read_cached_key() -> Optional[str]:
    """Read cached API key from ~/.kevros/api_key."""
    try:
        if _KEY_FILE.exists():
            key = _KEY_FILE.read_text().strip()
            if _validate_api_key_format(key):
                return key
            elif key.startswith("kvrs_"):
                # Accept older/shorter keys that start with kvrs_ even if
                # they don't match the strict regex, for backwards compat.
                return key
    except OSError:
        pass
    return None


def _secure_dir(path: Path) -> None:
    """Create directory with 0o700 permissions (owner-only access)."""
    path.mkdir(parents=True, exist_ok=True)
    try:
        path.chmod(0o700)
    except OSError:
        pass


def _secure_write(path: Path, content: str) -> None:
    """Write a file with 0o600 permissions (owner read/write only)."""
    path.write_text(content)
    try:
        path.chmod(0o600)
    except OSError:
        pass


def _write_cached_key(api_key: str, meta: Dict[str, Any]) -> None:
    """Cache API key and signup metadata to ~/.kevros/."""
    _secure_dir(_KEY_DIR)
    _secure_write(_KEY_FILE, api_key)
    # Write metadata alongside, also with restricted permissions.
    meta_file = _KEY_DIR / "signup.json"
    _secure_write(meta_file, json.dumps(meta, indent=2))


def get_or_create_api_key(
    agent_id: str,
    gateway_url: str = DEFAULT_GATEWAY_URL,
    operator_email: str = "",
    operator_name: str = "",
) -> str:
    """
    Get an existing API key or auto-signup for a free one.

    Resolution order:
    1. KEVROS_API_KEY environment variable
    2. ~/.kevros/api_key file
    3. Auto-signup via POST /signup (creates key, caches it)

    Args:
        agent_id: Your agent's identifier (required for signup).
        gateway_url: Gateway URL (default: production).
        operator_email: Optional email for account recovery.
        operator_name: Optional legal entity name.

    Returns:
        API key string (starts with kvrs_).

    Raises:
        RuntimeError: If signup fails.
    """
    # 1. Environment variable (explicit override)
    env_key = os.environ.get("KEVROS_API_KEY", "").strip()
    if env_key and env_key.startswith("kvrs_"):
        return env_key

    # 2. Cached key file
    cached = _read_cached_key()
    if cached:
        return cached

    # 3. Auto-signup
    logger.info("No Kevros API key found -- signing up for free tier (agent_id=%s)", agent_id)
    try:
        resp = httpx.post(
            f"{gateway_url.rstrip('/')}/signup",
            json={
                "agent_id": agent_id,
                "operator_email": operator_email,
                "operator_name": operator_name,
            },
            timeout=_TIMEOUT,
        )
        if resp.status_code == 200:
            try:
                data = resp.json()
            except Exception:
                raise RuntimeError("Kevros signup returned invalid JSON")
            if not isinstance(data, dict):
                raise RuntimeError("Kevros signup returned unexpected response format")
            api_key = data.get("api_key", "")
            if not isinstance(api_key, str) or not api_key.startswith("kvrs_"):
                raise RuntimeError("Kevros signup returned invalid API key format")
            _write_cached_key(api_key, {
                "agent_id": agent_id,
                "tier": data.get("tier", "free"),
                "monthly_limit": data.get("monthly_limit", 100),
                "rate_limit_per_minute": data.get("rate_limit_per_minute", 10),
                "gateway_url": gateway_url,
                "upgrade_url": data.get("upgrade_url", ""),
            })
            logger.info(
                "Kevros free tier activated: %d calls/mo, %d req/min. "
                "Key cached at %s",
                data.get("monthly_limit", 100),
                data.get("rate_limit_per_minute", 10),
                _KEY_FILE,
            )
            return api_key
        else:
            raise RuntimeError(f"Kevros signup failed (HTTP {resp.status_code})")
    except httpx.HTTPError as e:
        raise RuntimeError("Kevros signup failed (network error)") from e
