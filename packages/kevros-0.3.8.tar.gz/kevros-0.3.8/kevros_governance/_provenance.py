"""
Build provenance record — auto-generated, do not edit.

This file is embedded by the CI/CD pipeline at build time.
It provides hash verification and optional cryptographic
signature verification for this package distribution.
"""

PROVENANCE = {
    'schema_version': '1.0',
    'artifact_hash': 'sha512:628da913c8cc5394e963c6b33b120c2b26fc1c4caf5b8fa4e0bcc1d3ff4ccbc793e73de6c1a7ea2683c75ea85ba7e45f7bd78201c857485f8cc6112d59dcc643',
    'version': '0.3.8',
    'registry': 'pypi',
    'package_name': 'kevros',
    'build_timestamp': '2026-03-08T19:57:59Z',
    'build_host_hash': 'sha256:a67e39d1e616c143fa8cde43e1a76acf3012068b1109911b3fc4aa780cb69ef4',
    'git_commit': '9e4d6808ad6b638dc9f6e4b933f6be90a0bc3790',
    'git_branch': 'sdk-v0.3.8',
    'signer': 'github-actions-oidc',
    'signature_algorithm': '',
    'signature': '',
    'public_key': '',
    'dependencies_hash': 'sha256:7dc57f39dfc9d40b0ab8f602d3c43ad8b9eed4e10be2b3203c4d173df70c7ada',
}


def get_provenance() -> dict:
    """Return a copy of the build provenance record."""
    return dict(PROVENANCE)
