__all__ = ['mapl', 'filterl', 'mapc', 'filterc']


def mapl(f, it):
    return list(map(f, it))


def filterl(f, it):
    return list(filter(f, it))


def mapc(collect, f, it):
    return collect(map(f, it))


def filterc(collect, f, it):
    return collect(filter(f, it))
