"""Tests for the Prism proxy server — cache, health, learning, validation."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from prism.proxy import server


# ---------------------------------------------------------------------------
# Fixtures and helpers
# ---------------------------------------------------------------------------

@dataclass
class FakeCompletionResult:
    """Minimal stand-in for CompletionResult."""

    content: str = "Hello!"
    model: str = "gpt-4o-mini"
    provider: str = "openai"
    input_tokens: int = 10
    output_tokens: int = 5
    cost: float = 0.001
    finish_reason: str = "stop"
    tool_calls: list[dict[str, Any]] | None = None


@dataclass
class FakeCacheEntry:
    """Minimal stand-in for CacheEntry."""

    cache_key: str = "abc123"
    model: str = "gpt-4o-mini"
    provider: str = "openai"
    content: str = "cached response"
    input_tokens: int = 10
    output_tokens: int = 5
    cached_tokens: int = 0
    cost_usd: float = 0.001
    finish_reason: str = "stop"
    tool_calls_json: str | None = None
    created_at: float = 0.0
    expires_at: float = 9999999999.0
    file_hashes: str = ""


@pytest.fixture(autouse=True)
def _reset_server_globals():
    """Reset all server globals before each test."""
    server._completion_engine = None
    server._cost_tracker = None
    server._provider_registry = None
    server._auth_manager = None
    server._settings = None
    server._router_classifier = None
    server._router_selector = None
    server._response_cache = None
    server._adaptive_learner = None
    server._health_checker = None
    server._response_validator = None
    server._multi_agent_enabled = False
    # Clear caches
    server._classification_cache.clear()
    server._lru_cache.clear()
    server._fallback_chains.clear()
    server._fallback_chains_built = False
    server._latency_samples.clear()
    server._inflight.clear()
    yield
    # Reset again after test
    server._completion_engine = None
    server._cost_tracker = None
    server._provider_registry = None
    server._auth_manager = None
    server._settings = None
    server._router_classifier = None
    server._router_selector = None
    server._response_cache = None
    server._adaptive_learner = None
    server._health_checker = None
    server._response_validator = None
    server._multi_agent_enabled = False
    server._classification_cache.clear()
    server._lru_cache.clear()
    server._fallback_chains.clear()
    server._fallback_chains_built = False
    server._latency_samples.clear()
    server._inflight.clear()


# ---------------------------------------------------------------------------
# _make_cache_key
# ---------------------------------------------------------------------------


class TestMakeCacheKey:
    """Tests for cache key generation."""

    def test_returns_string(self) -> None:
        key = server._make_cache_key("gpt-4o", "system", [{"role": "user", "content": "hi"}])
        assert isinstance(key, str)
        assert len(key) > 0

    def test_same_inputs_same_key(self) -> None:
        msgs = [{"role": "user", "content": "hello"}]
        k1 = server._make_cache_key("gpt-4o", "sys", msgs)
        k2 = server._make_cache_key("gpt-4o", "sys", msgs)
        assert k1 == k2

    def test_different_model_different_key(self) -> None:
        msgs = [{"role": "user", "content": "hello"}]
        k1 = server._make_cache_key("gpt-4o", "sys", msgs)
        k2 = server._make_cache_key("gpt-4o-mini", "sys", msgs)
        assert k1 != k2

    def test_different_prompt_different_key(self) -> None:
        k1 = server._make_cache_key("m", "", [{"role": "user", "content": "a"}])
        k2 = server._make_cache_key("m", "", [{"role": "user", "content": "b"}])
        assert k1 != k2

    def test_system_as_list(self) -> None:
        system = [{"type": "text", "text": "Be helpful"}]
        key = server._make_cache_key("m", system, [{"role": "user", "content": "hi"}])
        assert isinstance(key, str)

    def test_empty_messages(self) -> None:
        key = server._make_cache_key("m", "", [])
        assert isinstance(key, str)


# ---------------------------------------------------------------------------
# _is_provider_healthy
# ---------------------------------------------------------------------------


class TestIsProviderHealthy:
    """Tests for provider health checking."""

    def test_no_health_checker_returns_true(self) -> None:
        assert server._is_provider_healthy("gpt-4o") is True

    def test_healthy_provider(self) -> None:
        hc = MagicMock()
        hc.get_unavailable_providers.return_value = ["anthropic"]
        server._health_checker = hc

        assert server._is_provider_healthy("gpt-4o") is True

    def test_unhealthy_provider(self) -> None:
        hc = MagicMock()
        hc.get_unavailable_providers.return_value = ["openai"]
        server._health_checker = hc

        assert server._is_provider_healthy("gpt-4o") is False

    def test_provider_with_prefix(self) -> None:
        hc = MagicMock()
        hc.get_unavailable_providers.return_value = ["groq"]
        server._health_checker = hc

        assert server._is_provider_healthy("groq/llama-3-70b") is False

    def test_error_returns_true(self) -> None:
        hc = MagicMock()
        hc.get_unavailable_providers.side_effect = RuntimeError("fail")
        server._health_checker = hc

        assert server._is_provider_healthy("gpt-4o") is True


# ---------------------------------------------------------------------------
# _infer_provider
# ---------------------------------------------------------------------------


class TestInferProvider:
    """Tests for provider name inference from model ID."""

    def test_claude_model(self) -> None:
        assert server._infer_provider("claude-3-opus") == "anthropic"

    def test_gpt_model(self) -> None:
        assert server._infer_provider("gpt-4o") == "openai"

    def test_o1_model(self) -> None:
        assert server._infer_provider("o1-preview") == "openai"

    def test_gemini_model(self) -> None:
        assert server._infer_provider("gemini-pro") == "google"

    def test_deepseek_model(self) -> None:
        assert server._infer_provider("deepseek-coder") == "deepseek"

    def test_llama_model(self) -> None:
        assert server._infer_provider("llama-3-70b") == "groq"

    def test_unknown_model(self) -> None:
        assert server._infer_provider("custom-model-xyz") == "unknown"


# ---------------------------------------------------------------------------
# _record_learning_outcome
# ---------------------------------------------------------------------------


class TestRecordLearningOutcome:
    """Tests for adaptive learning outcome recording."""

    def test_no_learner_does_nothing(self) -> None:
        # Should not raise
        server._record_learning_outcome("gpt-4o", "accepted", None)

    def test_records_with_learner(self) -> None:
        learner = MagicMock()
        server._adaptive_learner = learner

        # Need a classifier to determine tier
        classifier = MagicMock()
        server._router_classifier = classifier

        result = FakeCompletionResult(cost=0.005)
        server._record_learning_outcome("gpt-4o", "accepted", result)

        # Should have called record_outcome
        if learner.record_outcome.called:
            call_args = learner.record_outcome.call_args
            assert call_args.kwargs["model"] == "gpt-4o"
            assert call_args.kwargs["outcome"] == "accepted"

    def test_error_does_not_propagate(self) -> None:
        learner = MagicMock()
        learner.record_outcome.side_effect = RuntimeError("boom")
        server._adaptive_learner = learner
        server._router_classifier = MagicMock()

        # Should not raise
        server._record_learning_outcome("gpt-4o", "accepted", None)


# ---------------------------------------------------------------------------
# _route_model with health + learning
# ---------------------------------------------------------------------------


class TestRouteModelEnhanced:
    """Tests for model routing with health and adaptive learning."""

    def test_explicit_model_bypasses_routing(self) -> None:
        result = server._route_model("gpt-4o", [])
        assert result == "gpt-4o"

    def test_explicit_model_warns_unhealthy(self) -> None:
        hc = MagicMock()
        hc.get_unavailable_providers.return_value = ["openai"]
        server._health_checker = hc

        result = server._route_model("gpt-4o", [])
        # Still returns the model even if unhealthy (user explicitly asked)
        assert result == "gpt-4o"

    def test_fallback_to_healthy_model(self) -> None:
        reg = MagicMock()
        model_a = SimpleNamespace(id="openai/gpt-4o", provider="openai", tier=SimpleNamespace(value="simple"))
        model_b = SimpleNamespace(id="groq/llama-3", provider="groq", tier=SimpleNamespace(value="medium"))
        reg.get_available_models.return_value = [model_a, model_b]
        server._provider_registry = reg

        hc = MagicMock()
        hc.get_unavailable_providers.return_value = ["openai"]
        server._health_checker = hc

        result = server._route_model("auto", [{"role": "user", "content": "test"}])
        assert result == "groq/llama-3"

    def test_auto_falls_back_when_all_unhealthy(self) -> None:
        reg = MagicMock()
        model_a = SimpleNamespace(id="openai/gpt-4o", provider="openai", tier=SimpleNamespace(value="simple"))
        reg.get_available_models.return_value = [model_a]
        server._provider_registry = reg

        hc = MagicMock()
        hc.get_unavailable_providers.return_value = ["openai"]
        server._health_checker = hc

        # Should still return something (first model even if unhealthy)
        result = server._route_model("auto", [{"role": "user", "content": "test"}])
        assert result == "openai/gpt-4o"


# ---------------------------------------------------------------------------
# _build_fallback_chain_dynamic with health filtering
# ---------------------------------------------------------------------------


class TestFallbackChainHealthy:
    """Tests for fallback chain with health filtering."""

    def test_no_registry_returns_primary(self) -> None:
        chain = server._build_fallback_chain_dynamic("gpt-4o")
        assert chain == ["gpt-4o"]

    def test_filters_unhealthy_in_simple_fallback(self) -> None:
        reg = MagicMock()
        model_a = SimpleNamespace(id="openai/gpt-4o", provider="openai")
        model_b = SimpleNamespace(id="groq/llama-3", provider="groq")
        model_c = SimpleNamespace(id="anthropic/claude-3", provider="anthropic")
        reg.get_available_models.return_value = [model_a, model_b, model_c]
        reg.get_model_info.side_effect = Exception("no info")
        server._provider_registry = reg

        hc = MagicMock()
        hc.get_unavailable_providers.return_value = ["groq"]
        server._health_checker = hc

        chain = server._build_fallback_chain_dynamic("primary-model")
        assert "groq/llama-3" not in chain
        assert "primary-model" in chain


# ---------------------------------------------------------------------------
# handle_status with new features
# ---------------------------------------------------------------------------


class TestHandleStatusEnhanced:
    """Tests for the /prism/status endpoint with new features."""

    @pytest.mark.asyncio
    async def test_status_includes_new_features(self) -> None:
        from aiohttp.test_utils import make_mocked_request

        server._response_cache = MagicMock()
        server._adaptive_learner = MagicMock()
        server._health_checker = MagicMock()
        server._response_validator = MagicMock()

        request = make_mocked_request("GET", "/prism/status")
        resp = await server.handle_status(request)
        data = json.loads(resp.body)

        assert data["features"]["response_cache"] is True
        assert data["features"]["adaptive_learning"] is True
        assert data["features"]["health_checker"] is True
        assert data["features"]["response_validation"] is True

    @pytest.mark.asyncio
    async def test_status_missing_features_show_false(self) -> None:
        from aiohttp.test_utils import make_mocked_request

        request = make_mocked_request("GET", "/prism/status")
        resp = await server.handle_status(request)
        data = json.loads(resp.body)

        assert data["features"]["response_cache"] is False
        assert data["features"]["adaptive_learning"] is False
        assert data["features"]["health_checker"] is False
        assert data["features"]["response_validation"] is False


# ---------------------------------------------------------------------------
# handle_provider_health
# ---------------------------------------------------------------------------


class TestHandleProviderHealth:
    """Tests for the /prism/health endpoint."""

    @pytest.mark.asyncio
    async def test_no_health_checker(self) -> None:
        from aiohttp.test_utils import make_mocked_request

        request = make_mocked_request("GET", "/prism/health")
        resp = await server.handle_provider_health(request)
        data = json.loads(resp.body)

        assert data["service"] == "prism-proxy"
        assert data["message"] == "Health checker not configured"

    @pytest.mark.asyncio
    async def test_with_health_checker(self) -> None:
        from aiohttp.test_utils import make_mocked_request

        hc = MagicMock()
        hc.get_results.return_value = {
            "openai": SimpleNamespace(
                available=True,
                latency_ms=150.0,
                error=None,
                checked_at=datetime.now(),
            ),
        }
        hc.get_available_providers.return_value = ["openai"]
        hc.get_unavailable_providers.return_value = []
        server._health_checker = hc

        request = make_mocked_request("GET", "/prism/health")
        resp = await server.handle_provider_health(request)
        data = json.loads(resp.body)

        assert "openai" in data["providers"]
        assert data["providers"]["openai"]["available"] is True
        assert data["healthy"] == ["openai"]
        assert data["unhealthy"] == []

    @pytest.mark.asyncio
    async def test_includes_cache_stats(self) -> None:
        from aiohttp.test_utils import make_mocked_request

        cache = MagicMock()
        cache.get_stats.return_value = SimpleNamespace(
            total_entries=42,
            hit_rate=0.73,
            tokens_saved=15000,
            cost_saved=0.05,
        )
        server._response_cache = cache

        request = make_mocked_request("GET", "/prism/health")
        resp = await server.handle_provider_health(request)
        data = json.loads(resp.body)

        assert data["cache"]["entries"] == 42
        assert data["cache"]["hit_rate"] == 0.73
        assert data["cache"]["tokens_saved"] == 15000

    @pytest.mark.asyncio
    async def test_includes_learning_stats(self) -> None:
        from aiohttp.test_utils import make_mocked_request

        learner = MagicMock()
        learner.is_active = True
        learner.total_interactions = 250
        server._adaptive_learner = learner

        request = make_mocked_request("GET", "/prism/health")
        resp = await server.handle_provider_health(request)
        data = json.loads(resp.body)

        assert data["adaptive_learning"]["active"] is True
        assert data["adaptive_learning"]["total_interactions"] == 250


# ---------------------------------------------------------------------------
# create_app with new components
# ---------------------------------------------------------------------------


class TestCreateAppEnhanced:
    """Tests for app creation with new components."""

    def test_creates_app_with_all_components(self) -> None:
        engine = MagicMock()
        cache = MagicMock()
        learner = MagicMock()
        hc = MagicMock()
        hc.start_background_checks = MagicMock()
        validator = MagicMock()

        app = server.create_app(
            completion_engine=engine,
            response_cache=cache,
            adaptive_learner=learner,
            health_checker=hc,
            response_validator=validator,
        )

        assert server._response_cache is cache
        assert server._adaptive_learner is learner
        assert server._health_checker is hc
        assert server._response_validator is validator

        # Health checks should have been started
        hc.start_background_checks.assert_called_once()

    def test_health_endpoint_registered(self) -> None:
        engine = MagicMock()
        app = server.create_app(completion_engine=engine)

        route_paths = [r.resource.canonical for r in app.router.routes()
                       if hasattr(r.resource, "canonical")]
        assert "/prism/health" in route_paths

    def test_cleanup_registered(self) -> None:
        engine = MagicMock()
        app = server.create_app(completion_engine=engine)
        assert server._cleanup_on_shutdown in app.on_cleanup


# ---------------------------------------------------------------------------
# _cached_classify (replaces _classify_complexity)
# ---------------------------------------------------------------------------


class TestCachedClassify:
    """Tests for cached classification."""

    def test_no_classifier_returns_none(self) -> None:
        assert server._cached_classify("Hello") is None

    def test_empty_text_returns_none(self) -> None:
        assert server._cached_classify("") is None

    def test_with_classifier(self) -> None:
        classifier = MagicMock()
        result_obj = SimpleNamespace(tier=SimpleNamespace(value="complex"))
        classifier.classify.return_value = result_obj
        server._router_classifier = classifier

        result = server._cached_classify("Refactor the entire authentication module")
        assert result is not None
        assert result.tier.value == "complex"

    def test_caches_result(self) -> None:
        classifier = MagicMock()
        result_obj = SimpleNamespace(tier=SimpleNamespace(value="medium"))
        classifier.classify.return_value = result_obj
        server._router_classifier = classifier

        # First call should invoke classify
        server._cached_classify("test prompt")
        assert classifier.classify.call_count == 1

        # Second call with same prefix should use cache
        server._cached_classify("test prompt")
        assert classifier.classify.call_count == 1


# ---------------------------------------------------------------------------
# Multi-agent gate (_multi_agent_enabled)
# ---------------------------------------------------------------------------


class TestMultiAgentGate:
    """Tests for multi-agent being disabled by default."""

    def test_multi_agent_disabled_by_default(self) -> None:
        assert server._multi_agent_enabled is False

    def test_multi_agent_gate_blocks_cascade(self) -> None:
        # With multi-agent disabled (default), complex requests should NOT
        # trigger multi-agent even with a classifier present
        classifier = MagicMock()
        classifier.classify.return_value = SimpleNamespace(
            tier=SimpleNamespace(value="complex"),
        )
        server._router_classifier = classifier

        # The gate should prevent multi-agent from firing
        assert server._multi_agent_enabled is False


# ---------------------------------------------------------------------------
# _translate_tools
# ---------------------------------------------------------------------------


class TestTranslateTools:
    """Tests for Anthropic → OpenAI tool format translation."""

    def test_basic_tool(self) -> None:
        tools = [{
            "name": "read_file",
            "description": "Read a file",
            "input_schema": {"type": "object", "properties": {"path": {"type": "string"}}},
        }]
        result = server._translate_tools(tools)
        assert len(result) == 1
        assert result[0]["type"] == "function"
        assert result[0]["function"]["name"] == "read_file"
        assert result[0]["function"]["description"] == "Read a file"
        assert result[0]["function"]["parameters"]["type"] == "object"

    def test_multiple_tools(self) -> None:
        tools = [
            {"name": "a", "description": "d1", "input_schema": {}},
            {"name": "b", "description": "d2", "input_schema": {}},
        ]
        result = server._translate_tools(tools)
        assert len(result) == 2

    def test_missing_fields(self) -> None:
        tools = [{"name": "test"}]
        result = server._translate_tools(tools)
        assert result[0]["function"]["name"] == "test"
        assert result[0]["function"]["description"] == ""
        assert result[0]["function"]["parameters"] == {}


# ---------------------------------------------------------------------------
# _merge_tool_call_delta
# ---------------------------------------------------------------------------


class TestMergeToolCallDelta:
    """Tests for streaming tool call delta merging."""

    def test_first_delta_creates_entry(self) -> None:
        collected: list[dict] = []
        delta = SimpleNamespace(
            index=0,
            id="call_123",
            function=SimpleNamespace(name="read_file", arguments='{"path":'),
        )
        server._merge_tool_call_delta(collected, delta)

        assert len(collected) == 1
        assert collected[0]["id"] == "call_123"
        assert collected[0]["function"]["name"] == "read_file"

    def test_subsequent_delta_merges_arguments(self) -> None:
        collected = [{"id": "call_123", "type": "function", "function": {"name": "read_file", "arguments": '{"path":'}}]
        delta = SimpleNamespace(
            index=0,
            id=None,
            function=SimpleNamespace(name=None, arguments=' "main.py"}'),
        )
        server._merge_tool_call_delta(collected, delta)

        assert collected[0]["function"]["arguments"] == '{"path": "main.py"}'

    def test_dict_delta(self) -> None:
        collected: list[dict] = []
        delta = {"index": 0, "id": "call_456", "function": {"name": "test", "arguments": "{}"}}
        server._merge_tool_call_delta(collected, delta)

        assert collected[0]["id"] == "call_456"
        assert collected[0]["function"]["name"] == "test"
