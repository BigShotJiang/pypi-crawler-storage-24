"""Prism — Multi-API Intelligent Router CLI."""

__version__ = "0.3.1"
__app_name__ = "prism"
