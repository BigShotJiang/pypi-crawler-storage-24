# Changelog

All notable changes to agenticraft-llm will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-03-07

Initial release of the production-grade LLM provider abstraction layer.

### Added

- **14 LLM providers**: OpenAI, Anthropic, Google, Azure OpenAI, AWS Bedrock, Cohere, Ollama, Fireworks, Cerebras, DeepSeek, xAI, OpenRouter, Perplexity, Nebius
- **SDK exception mapping**: Provider SDK errors mapped to typed `LLMError` hierarchy
- **Cost-aware routing**: Thompson sampling with Bayesian explore-exploit, budget constraints, quality thresholds
- **Key pool management**: 5 rotation strategies (round-robin, least-used, random, weighted, adaptive), rate limit tracking, automatic cooldown
- **Typed responses**: `LLMResponse` and `StreamChunk` dataclasses with `TokenUsage`
- **Streaming**: Full streaming support with tool call deltas across all providers
- **Retry with backoff**: Exponential backoff with per-request key rotation on retry
- **Pre/post hooks**: Extensible request/response hook system
- **Response caching**: Bounded in-memory cache with TTL
- **Embeddings**: `embed()` support for OpenAI, Azure, Cohere providers
- **Circuit breaker**: Per-provider circuit breaker with state machine (CLOSED/OPEN/HALF_OPEN)
- **Rate limiter**: Token bucket rate limiter with provider presets
- **OpenAI-compatible gateway**: FastAPI server with `/v1/chat/completions`, `/v1/models`, SSE streaming
- **Provider metrics**: Request counts, latency, cost tracking, quality scores
- BSL 1.1 license (converts to Apache 2.0 after 4 years)
- `py.typed` marker for PEP 561 compliance
- Python 3.10+ support, tested on 3.10-3.13

[Unreleased]: https://github.com/agenticraft/agenticraft-llm/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/agenticraft/agenticraft-llm/releases/tag/v0.1.0
