"""Tests for provider registry."""

from __future__ import annotations

import pytest

from agenticraft_llm import registry


class TestRegistry:
    @pytest.fixture(autouse=True)
    def reset_registry(self):
        """Reset registry state between tests."""
        registry._registry.clear()
        registry._discovered = False
        yield
        registry._registry.clear()
        registry._discovered = False

    def test_register_and_get(self):
        from agenticraft_llm.providers.openai import OpenAIProvider

        registry.register("test_openai", OpenAIProvider)
        cls = registry.get_provider_class("test_openai")
        assert cls is OpenAIProvider

    def test_get_unknown_returns_none_before_discover(self):
        # After auto-discover, known providers will be found
        cls = registry.get_provider_class("nonexistent_xyz")
        assert cls is None

    def test_auto_discover(self):
        providers = registry.list_providers()
        assert "openai" in providers
        assert "anthropic" in providers
        assert len(providers) >= 14

    def test_auto_discover_idempotent(self):
        registry.list_providers()
        registry.list_providers()
        assert registry._discovered is True

    def test_get_provider_creates_instance(self):
        provider = registry.get_provider("openai", api_key="test", model="gpt-4o")
        assert provider.name == "openai"

    def test_get_provider_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown provider"):
            registry.get_provider("nonexistent_xyz")

    def test_list_providers_sorted(self):
        providers = registry.list_providers()
        assert providers == sorted(providers)

    def test_get_provider_class_auto_discovers(self):
        cls = registry.get_provider_class("openai")
        assert cls is not None
        from agenticraft_llm.providers.openai import OpenAIProvider

        assert cls is OpenAIProvider
