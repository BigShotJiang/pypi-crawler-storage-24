"""Tests for circuit breaker."""

from __future__ import annotations

import time

import pytest

from agenticraft_llm.resilience.circuit_breaker import (
    PROVIDER_DEFAULTS,
    CircuitBreaker,
    CircuitBreakerConfig,
    CircuitBreakerState,
    CircuitOpenError,
    FailureType,
)


class TestCircuitBreakerStates:
    def test_initial_state_is_closed(self):
        cb = CircuitBreaker(name="test")
        assert cb.state == CircuitBreakerState.CLOSED
        assert cb.is_closed
        assert not cb.is_open
        assert not cb.is_half_open

    def test_opens_after_threshold(self):
        cb = CircuitBreaker(config=CircuitBreakerConfig(failure_threshold=3))
        for _ in range(3):
            cb.record_failure()
        assert cb.is_open

    def test_does_not_open_before_threshold(self):
        cb = CircuitBreaker(config=CircuitBreakerConfig(failure_threshold=5))
        for _ in range(4):
            cb.record_failure()
        assert cb.is_closed

    def test_transitions_to_half_open_after_timeout(self):
        cb = CircuitBreaker(config=CircuitBreakerConfig(failure_threshold=2, recovery_timeout=0.05))
        cb.record_failure()
        cb.record_failure()
        assert cb.is_open
        time.sleep(0.06)
        assert cb.is_half_open

    def test_closes_after_success_threshold_in_half_open(self):
        cb = CircuitBreaker(
            config=CircuitBreakerConfig(
                failure_threshold=2, recovery_timeout=0.01, success_threshold=2
            )
        )
        cb.record_failure()
        cb.record_failure()
        time.sleep(0.02)
        assert cb.is_half_open
        cb.record_success()
        assert cb.is_half_open
        cb.record_success()
        assert cb.is_closed

    def test_reopens_on_failure_in_half_open(self):
        cb = CircuitBreaker(config=CircuitBreakerConfig(failure_threshold=2, recovery_timeout=0.01))
        cb.record_failure()
        cb.record_failure()
        time.sleep(0.02)
        assert cb.is_half_open
        cb.record_failure()
        assert cb.is_open

    def test_success_resets_failure_count_in_closed(self):
        cb = CircuitBreaker(config=CircuitBreakerConfig(failure_threshold=3))
        cb.record_failure()
        cb.record_failure()
        cb.record_success()
        cb.record_failure()
        cb.record_failure()
        assert cb.is_closed  # Reset, so only 2 failures


class TestCircuitBreakerReset:
    def test_reset_from_open(self):
        cb = CircuitBreaker(config=CircuitBreakerConfig(failure_threshold=2))
        cb.record_failure()
        cb.record_failure()
        assert cb.is_open
        cb.reset()
        assert cb.is_closed

    def test_reset_clears_counts(self):
        cb = CircuitBreaker()
        cb.record_failure()
        cb.reset()
        state = cb.get_state()
        assert state["failure_count"] == 0
        assert state["success_count"] == 0


class TestCircuitBreakerCall:
    @pytest.mark.asyncio
    async def test_call_succeeds_when_closed(self):
        cb = CircuitBreaker()

        async def ok():
            return "ok"

        result = await cb.call(ok)
        assert result == "ok"

    @pytest.mark.asyncio
    async def test_call_raises_when_open(self):
        cb = CircuitBreaker(config=CircuitBreakerConfig(failure_threshold=1))
        cb.record_failure()

        async def ok():
            return "ok"

        with pytest.raises(CircuitOpenError):
            await cb.call(ok)

    @pytest.mark.asyncio
    async def test_call_records_failure_on_exception(self):
        cb = CircuitBreaker()

        async def failing():
            raise ValueError("boom")

        with pytest.raises(ValueError):
            await cb.call(failing)
        assert cb._total_failures == 1

    @pytest.mark.asyncio
    async def test_call_records_success(self):
        cb = CircuitBreaker()

        async def success():
            return 42

        result = await cb.call(success)
        assert result == 42
        assert cb._total_successes == 1


class TestCircuitBreakerMetrics:
    def test_get_state(self):
        cb = CircuitBreaker(name="test-cb")
        state = cb.get_state()
        assert state["name"] == "test-cb"
        assert state["state"] == "closed"
        assert state["total_calls"] == 0

    def test_metrics_track_calls(self):
        cb = CircuitBreaker()
        cb.record_success()
        cb.record_failure()
        state = cb.get_state()
        assert state["total_calls"] == 2
        assert state["total_successes"] == 1
        assert state["total_failures"] == 1


class TestErrorClassification:
    def test_connection_error(self):
        assert CircuitBreaker.classify_error(ConnectionError()) == FailureType.CONNECTION

    def test_timeout_error(self):
        assert CircuitBreaker.classify_error(TimeoutError()) == FailureType.TIMEOUT

    def test_rate_limit_from_string(self):
        assert (
            CircuitBreaker.classify_error(Exception("rate limit exceeded"))
            == FailureType.RATE_LIMIT
        )

    def test_auth_from_string(self):
        assert CircuitBreaker.classify_error(Exception("invalid api key")) == FailureType.AUTH

    def test_generic_error(self):
        assert (
            CircuitBreaker.classify_error(Exception("something weird")) == FailureType.SERVICE_ERROR
        )


class TestProviderDefaults:
    def test_has_all_providers(self):
        expected = [
            "openai",
            "anthropic",
            "google",
            "azure_openai",
            "groq",
            "fireworks",
            "cerebras",
            "ollama",
            "deepseek",
            "cohere",
            "bedrock",
            "xai",
            "openrouter",
            "perplexity",
            "nebius",
        ]
        for p in expected:
            assert p in PROVIDER_DEFAULTS

    def test_groq_has_lower_threshold(self):
        assert PROVIDER_DEFAULTS["groq"].failure_threshold == 3

    def test_ollama_has_lowest_threshold(self):
        assert PROVIDER_DEFAULTS["ollama"].failure_threshold == 2
