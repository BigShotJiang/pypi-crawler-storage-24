"""Tests for rate limiter."""

from __future__ import annotations

import asyncio

import pytest

from agenticraft_llm.resilience.rate_limiter import (
    PROVIDER_RATE_LIMITS,
    RateLimitConfig,
    TokenBucketRateLimiter,
)


class TestTokenBucketRateLimiter:
    @pytest.mark.asyncio
    async def test_acquire_succeeds(self):
        limiter = TokenBucketRateLimiter(RateLimitConfig(max_calls=10, time_window=1.0))
        assert await limiter.acquire()

    @pytest.mark.asyncio
    async def test_acquire_fails_when_exhausted(self):
        limiter = TokenBucketRateLimiter(
            RateLimitConfig(max_calls=2, time_window=60.0, burst_size=2)
        )
        assert await limiter.acquire()
        assert await limiter.acquire()
        assert not await limiter.acquire()  # No more tokens

    @pytest.mark.asyncio
    async def test_acquire_multiple_tokens(self):
        limiter = TokenBucketRateLimiter(
            RateLimitConfig(max_calls=5, time_window=60.0, burst_size=5)
        )
        assert await limiter.acquire(tokens=3)
        assert await limiter.acquire(tokens=2)
        assert not await limiter.acquire(tokens=1)

    @pytest.mark.asyncio
    async def test_tokens_refill(self):
        limiter = TokenBucketRateLimiter(
            RateLimitConfig(max_calls=100, time_window=0.1, burst_size=1)
        )
        assert await limiter.acquire()
        assert not await limiter.acquire()
        await asyncio.sleep(0.02)
        assert await limiter.acquire()

    @pytest.mark.asyncio
    async def test_acquire_with_timeout(self):
        limiter = TokenBucketRateLimiter(
            RateLimitConfig(max_calls=100, time_window=0.1, burst_size=1)
        )
        await limiter.acquire()
        result = await limiter.acquire(timeout=0.05)
        assert result is True  # Should get token after refill

    @pytest.mark.asyncio
    async def test_acquire_timeout_expires(self):
        limiter = TokenBucketRateLimiter(
            RateLimitConfig(max_calls=1, time_window=60.0, burst_size=1)
        )
        await limiter.acquire()
        result = await limiter.acquire(timeout=0.02)
        assert result is False

    def test_get_available_tokens(self):
        limiter = TokenBucketRateLimiter(
            RateLimitConfig(max_calls=10, time_window=1.0, burst_size=10)
        )
        assert limiter.get_available_tokens() >= 9.9

    def test_get_metrics(self):
        limiter = TokenBucketRateLimiter(RateLimitConfig(max_calls=100, time_window=60.0))
        metrics = limiter.get_metrics()
        assert metrics["max_calls"] == 100
        assert metrics["time_window"] == 60.0
        assert metrics["total_acquired"] == 0
        assert metrics["total_rejected"] == 0

    @pytest.mark.asyncio
    async def test_metrics_track_acquisitions(self):
        limiter = TokenBucketRateLimiter(
            RateLimitConfig(max_calls=2, time_window=60.0, burst_size=2)
        )
        await limiter.acquire()
        await limiter.acquire()
        await limiter.acquire()  # This one fails
        metrics = limiter.get_metrics()
        assert metrics["total_acquired"] == 2
        assert metrics["total_rejected"] == 1


class TestRateLimitConfig:
    def test_burst_defaults_to_max_calls(self):
        config = RateLimitConfig(max_calls=50, time_window=60.0)
        assert config.burst_size == 50

    def test_explicit_burst_size(self):
        config = RateLimitConfig(max_calls=50, time_window=60.0, burst_size=10)
        assert config.burst_size == 10


class TestProviderRateLimits:
    def test_has_all_providers(self):
        expected = [
            "openai",
            "anthropic",
            "google",
            "azure_openai",
            "groq",
            "fireworks",
            "cerebras",
            "ollama",
            "deepseek",
            "cohere",
            "bedrock",
            "xai",
            "openrouter",
            "perplexity",
            "nebius",
        ]
        for p in expected:
            assert p in PROVIDER_RATE_LIMITS

    def test_groq_has_low_limit(self):
        assert PROVIDER_RATE_LIMITS["groq"].max_calls == 30

    def test_anthropic_has_high_limit(self):
        assert PROVIDER_RATE_LIMITS["anthropic"].max_calls == 1000
