"""Tests for types module."""

import pytest

from agenticraft_llm.types import (
    HealthStatus,
    KeyStatus,
    LLMCapabilityType,
    LLMRequest,
    LLMResponse,
    ModelTier,
    ProviderMetrics,
    ProviderType,
    RotationStrategy,
    RoutingStrategy,
    StreamChunk,
    TokenUsage,
)


class TestEnums:
    def test_provider_type_values(self):
        assert ProviderType.OPENAI.value == "openai"
        assert ProviderType.ANTHROPIC.value == "anthropic"
        assert ProviderType.GOOGLE.value == "google"
        assert len(ProviderType) == 14

    def test_capability_type_values(self):
        assert LLMCapabilityType.COMPLETION.value == "completion"
        assert LLMCapabilityType.STREAMING.value == "streaming"
        assert LLMCapabilityType.TOOL_USE.value == "tool_use"

    def test_model_tier(self):
        assert ModelTier.BASIC.value == "basic"
        assert ModelTier.PREMIUM.value == "premium"

    def test_routing_strategy(self):
        assert RoutingStrategy.COST.value == "cost"
        assert RoutingStrategy.QUALITY.value == "quality"

    def test_key_status(self):
        assert KeyStatus.ACTIVE.value == "active"
        assert KeyStatus.RATE_LIMITED.value == "rate_limited"

    def test_rotation_strategy(self):
        assert RotationStrategy.ADAPTIVE.value == "adaptive"
        assert RotationStrategy.ROUND_ROBIN.value == "round_robin"


class TestTokenUsage:
    def test_creation(self):
        usage = TokenUsage(prompt_tokens=10, completion_tokens=20, total_tokens=30)
        assert usage.prompt_tokens == 10
        assert usage.completion_tokens == 20
        assert usage.total_tokens == 30
        assert usage.cost_usd is None

    def test_from_dict(self):
        data = {"prompt_tokens": 100, "completion_tokens": 200, "total_tokens": 300}
        usage = TokenUsage.from_dict(data)
        assert usage.prompt_tokens == 100
        assert usage.total_tokens == 300

    def test_from_dict_defaults(self):
        usage = TokenUsage.from_dict({})
        assert usage.prompt_tokens == 0
        assert usage.total_tokens == 0

    def test_frozen(self):
        usage = TokenUsage(prompt_tokens=10, completion_tokens=20, total_tokens=30)
        with pytest.raises(AttributeError):
            usage.prompt_tokens = 100  # type: ignore


class TestLLMRequest:
    def test_creation(self):
        req = LLMRequest(prompt="Hello")
        assert req.prompt == "Hello"
        assert req.temperature == 0.7
        assert req.stream is False

    def test_with_all_fields(self):
        req = LLMRequest(
            prompt="Hello",
            model="gpt-4",
            provider="openai",
            temperature=0.5,
            max_tokens=100,
            stream=True,
        )
        assert req.model == "gpt-4"
        assert req.stream is True


class TestLLMResponse:
    def test_creation(self):
        resp = LLMResponse(content="Hi", model="gpt-4", provider="openai")
        assert resp.content == "Hi"
        assert resp.has_tool_calls is False

    def test_with_tool_calls(self):
        resp = LLMResponse(
            content="",
            model="gpt-4",
            provider="openai",
            tool_calls=[{"name": "search", "arguments": {}}],
        )
        assert resp.has_tool_calls is True


class TestStreamChunk:
    def test_creation(self):
        chunk = StreamChunk(content="Hello", model="gpt-4", provider="openai")
        assert chunk.content == "Hello"
        assert chunk.is_final is False


class TestProviderMetrics:
    def test_initial_state(self):
        m = ProviderMetrics()
        assert m.total_requests == 0
        assert m.success_rate == 0.0
        assert m.average_latency_ms == 0.0

    def test_record_success(self):
        m = ProviderMetrics()
        m.record_request(success=True, latency_ms=100.0, tokens=50, cost_usd=0.01)
        assert m.total_requests == 1
        assert m.successful_requests == 1
        assert m.success_rate == 1.0
        assert m.average_latency_ms == 100.0

    def test_record_failure(self):
        m = ProviderMetrics()
        m.record_request(success=False, latency_ms=50.0, error_type="TimeoutError")
        assert m.failed_requests == 1
        assert m.error_counts["TimeoutError"] == 1


class TestHealthStatus:
    def test_healthy(self):
        status = HealthStatus(healthy=True, message="OK")
        assert status.healthy is True

    def test_unhealthy(self):
        status = HealthStatus(healthy=False, message="Down")
        assert status.healthy is False
