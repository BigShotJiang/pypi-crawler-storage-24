"""Property-based tests for router and key pool using Hypothesis."""

from __future__ import annotations

import pytest

try:
    from hypothesis import given, settings
    from hypothesis import strategies as st

    HAS_HYPOTHESIS = True
except ImportError:
    HAS_HYPOTHESIS = False

from agenticraft_llm.resilience.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerConfig,
    CircuitBreakerState,
)
from agenticraft_llm.resilience.rate_limiter import RateLimitConfig, TokenBucketRateLimiter
from agenticraft_llm.router import CostAwareRouter, CostRouterConfig

pytestmark = pytest.mark.skipif(not HAS_HYPOTHESIS, reason="hypothesis not installed")


class TestRouterProperties:
    @given(
        cost_weight=st.floats(min_value=0.0, max_value=1.0),
        quality_weight=st.floats(min_value=0.0, max_value=1.0),
    )
    @settings(max_examples=50)
    @pytest.mark.asyncio
    async def test_always_selects_a_provider(self, cost_weight, quality_weight):
        """Router should always return a provider when candidates exist."""
        config = CostRouterConfig(
            cost_weight=cost_weight,
            quality_weight=quality_weight,
            latency_weight=max(0, 1.0 - cost_weight - quality_weight),
        )
        router = CostAwareRouter(config=config)
        await router.initialize()
        result = await router.select_provider(
            providers=["openai", "anthropic", "google"],
            estimated_tokens=1000,
        )
        assert result in ["openai", "anthropic", "google"]

    @pytest.mark.asyncio
    async def test_strict_budget_blocks_expensive(self):
        """With strict_budget, expensive providers should be blocked."""
        config = CostRouterConfig(strict_budget=True)
        router = CostAwareRouter(config=config)
        await router.initialize()
        result = await router.select_provider(
            providers=["openai", "anthropic"],
            estimated_tokens=1000,
            max_cost=0.0000001,  # Impossibly low
        )
        assert result is None

    @given(quality=st.floats(min_value=0.0, max_value=1.0))
    @settings(max_examples=30)
    @pytest.mark.asyncio
    async def test_quality_threshold_monotonic(self, quality):
        """Higher quality thresholds should never include more providers."""
        router = CostAwareRouter()
        await router.initialize()

        # Low threshold
        result_low = await router.select_with_constraints(
            providers=["openai", "anthropic", "google", "ollama"],
            input_tokens=500,
            output_tokens=500,
            quality_threshold=0.0,
        )
        # High threshold
        result_high = await router.select_with_constraints(
            providers=["openai", "anthropic", "google", "ollama"],
            input_tokens=500,
            output_tokens=500,
            quality_threshold=quality,
        )

        assert result_low is not None
        if result_high is not None:
            # High threshold candidates are a subset
            assert (
                result_high.quality_score >= quality
                or "constraints relaxed" in result_high.constraints_applied
            )

    @pytest.mark.asyncio
    async def test_posterior_updates_affect_selection(self):
        """Updating posteriors should eventually change selection."""
        config = CostRouterConfig(explore_mode=True)
        router = CostAwareRouter(config=config)
        await router.initialize()

        # Penalize openai heavily
        for _ in range(100):
            router.update_posterior("openai", success=False)

        # Reward google heavily
        for _ in range(100):
            router.update_posterior("google", success=True, quality_score=0.99)

        selections = set()
        for _ in range(20):
            p = await router.select_provider(
                providers=["openai", "google"],
                estimated_tokens=100,
            )
            selections.add(p)

        # Google should be selected most of the time
        assert "google" in selections


class TestKeyPoolProperties:
    @pytest.mark.asyncio
    async def test_round_robin_uses_all_keys(self):
        """Round-robin should use every key before repeating."""
        from agenticraft_llm.key_pool import KeyPoolManager
        from agenticraft_llm.types import RotationStrategy

        pool = KeyPoolManager(
            provider="test",
            keys=["key1", "key2", "key3"],
            strategy=RotationStrategy.ROUND_ROBIN,
        )

        seen = set()
        for _ in range(3):
            key = await pool.acquire()
            seen.add(key)

        assert len(seen) == 3


class TestCircuitBreakerProperties:
    @given(threshold=st.integers(min_value=1, max_value=20))
    @settings(max_examples=30)
    def test_opens_after_exactly_threshold(self, threshold):
        """Circuit breaker opens after exactly failure_threshold failures."""
        cb = CircuitBreaker(config=CircuitBreakerConfig(failure_threshold=threshold))

        for i in range(threshold - 1):
            cb.record_failure()
            assert cb._state == CircuitBreakerState.CLOSED, f"Opened too early at {i + 1}"

        cb.record_failure()
        assert cb._state == CircuitBreakerState.OPEN

    @given(threshold=st.integers(min_value=1, max_value=10))
    @settings(max_examples=20)
    def test_never_allows_calls_when_open(self, threshold):
        """Circuit breaker should never be in CLOSED state right after opening."""
        cb = CircuitBreaker(
            config=CircuitBreakerConfig(failure_threshold=threshold, recovery_timeout=3600.0)
        )
        for _ in range(threshold):
            cb.record_failure()
        # Should be open now, and stay open (long recovery timeout)
        assert cb._state == CircuitBreakerState.OPEN
        assert cb.is_open


class TestRateLimiterProperties:
    @given(max_calls=st.integers(min_value=1, max_value=100))
    @settings(max_examples=20)
    @pytest.mark.asyncio
    async def test_never_exceeds_burst(self, max_calls):
        """Should never acquire more tokens than burst_size."""
        limiter = TokenBucketRateLimiter(
            RateLimitConfig(max_calls=max_calls, time_window=60.0, burst_size=max_calls)
        )

        acquired = 0
        for _ in range(max_calls + 5):
            if await limiter.acquire():
                acquired += 1

        assert acquired <= max_calls
