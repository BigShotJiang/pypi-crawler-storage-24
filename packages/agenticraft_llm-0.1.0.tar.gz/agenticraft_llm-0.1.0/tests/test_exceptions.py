"""Tests for exceptions module."""

from agenticraft_llm.exceptions import (
    LLMAuthenticationError,
    LLMConfigError,
    LLMError,
    LLMModelNotFoundError,
    LLMNoProvidersAvailableError,
    LLMOrchestrationError,
    LLMProviderError,
    LLMQuotaExceededError,
    LLMRateLimitError,
    LLMRequestError,
    LLMTimeoutError,
)


class TestLLMError:
    def test_base_error(self):
        err = LLMError("Something failed", provider="openai", model="gpt-4")
        assert "Something failed" in str(err)
        assert "openai" in str(err)
        assert err.provider == "openai"
        assert err.model == "gpt-4"

    def test_base_error_no_provider(self):
        err = LLMError("Failed")
        assert str(err) == "Failed"
        assert err.provider is None


class TestProviderErrors:
    def test_provider_error(self):
        err = LLMProviderError("API error", status_code=500)
        assert err.status_code == 500

    def test_auth_error(self):
        err = LLMAuthenticationError("Invalid key", provider="openai")
        assert isinstance(err, LLMProviderError)
        assert isinstance(err, LLMError)

    def test_rate_limit_error(self):
        err = LLMRateLimitError("Rate limited", retry_after=30.0)
        assert err.retry_after == 30.0

    def test_timeout_error(self):
        err = LLMTimeoutError("Timed out", timeout_seconds=60.0)
        assert err.timeout_seconds == 60.0

    def test_model_not_found(self):
        err = LLMModelNotFoundError(
            "Model not found",
            model="gpt-5-ultra",
            available_models=["gpt-4", "gpt-4o"],
        )
        assert err.available_models == ["gpt-4", "gpt-4o"]


class TestOtherErrors:
    def test_request_error(self):
        err = LLMRequestError("Bad request")
        assert isinstance(err, LLMError)

    def test_config_error(self):
        err = LLMConfigError("Invalid config", field="api_key", value="")
        assert err.field == "api_key"

    def test_quota_error(self):
        err = LLMQuotaExceededError("Quota exceeded", tenant_id="t1", limit=1000, current=1001)
        assert err.limit == 1000

    def test_orchestration_error(self):
        err = LLMOrchestrationError(
            "All failed", strategy="fallback", providers_tried=["openai", "anthropic"]
        )
        assert err.providers_tried == ["openai", "anthropic"]

    def test_no_providers_error(self):
        err = LLMNoProvidersAvailableError("No providers")
        assert isinstance(err, LLMOrchestrationError)


class TestErrorHierarchy:
    def test_hierarchy(self):
        assert issubclass(LLMProviderError, LLMError)
        assert issubclass(LLMAuthenticationError, LLMProviderError)
        assert issubclass(LLMRateLimitError, LLMProviderError)
        assert issubclass(LLMTimeoutError, LLMProviderError)
        assert issubclass(LLMModelNotFoundError, LLMProviderError)
        assert issubclass(LLMRequestError, LLMError)
        assert issubclass(LLMConfigError, LLMError)
        assert issubclass(LLMQuotaExceededError, LLMError)
        assert issubclass(LLMOrchestrationError, LLMError)
        assert issubclass(LLMNoProvidersAvailableError, LLMOrchestrationError)
