"""Tests for base provider."""

from collections.abc import AsyncIterator
from typing import Any

import pytest

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType, LLMResponse, StreamChunk


class MockProvider(BaseLLMProvider):
    """Test provider implementation."""

    SUPPORTED_MODELS = {"mock-model", "mock-model-v2"}
    CAPABILITIES = {LLMCapabilityType.COMPLETION, LLMCapabilityType.STREAMING}
    MODEL_ALIASES = {"mock": "mock-model"}

    provider_name = "mock"

    @property
    def name(self) -> str:
        return "mock"

    @property
    def default_model(self) -> str:
        return "mock-model"

    async def _make_request(
        self, messages: list[dict[str, Any]], model: str, **kwargs: Any
    ) -> dict[str, Any]:
        return {
            "content": "Hello from mock!",
            "model": model,
            "provider": "mock",
            "usage": {"prompt_tokens": 10, "completion_tokens": 20, "total_tokens": 30},
            "finish_reason": "stop",
        }

    async def _stream_request(
        self, messages: list[dict[str, Any]], model: str, **kwargs: Any
    ) -> AsyncIterator[dict[str, Any]]:
        yield {"content": "Hello", "model": model, "provider": "mock", "done": False}
        yield {"content": " world", "model": model, "provider": "mock", "done": True}


class TestBaseLLMProvider:
    @pytest.fixture
    def provider(self):
        return MockProvider(config={"api_key": "test-key", "model": "mock-model"})

    def test_name(self, provider):
        assert provider.name == "mock"

    def test_version(self, provider):
        assert provider.version == "0.1.0"

    def test_default_model(self, provider):
        assert provider.default_model == "mock-model"

    def test_supported_models(self, provider):
        models = provider.get_supported_models()
        assert "mock-model" in models
        assert "mock-model-v2" in models

    def test_capabilities(self, provider):
        caps = provider.get_capabilities()
        assert "completion" in caps
        assert "streaming" in caps

    def test_has_capability_enum(self, provider):
        assert provider.has_capability(LLMCapabilityType.COMPLETION) is True
        assert provider.has_capability(LLMCapabilityType.VISION) is False

    def test_has_capability_string(self, provider):
        assert provider.has_capability("completion") is True
        assert provider.has_capability("vision") is False

    def test_supports_model(self, provider):
        assert provider.supports_model("mock-model") is True
        assert provider.supports_model("gpt-4") is False

    def test_supports_model_alias(self, provider):
        assert provider.supports_model("mock") is True

    def test_resolve_alias(self, provider):
        assert provider.resolve_model_alias("mock") == "mock-model"
        assert provider.resolve_model_alias("unknown") == "unknown"

    @pytest.mark.asyncio
    async def test_complete(self, provider):
        response = await provider.complete([{"role": "user", "content": "Hi"}])
        assert response.content == "Hello from mock!"
        assert response.provider == "mock"
        assert isinstance(response, LLMResponse)

    @pytest.mark.asyncio
    async def test_stream(self, provider):
        chunks = []
        async for chunk in provider.stream([{"role": "user", "content": "Hi"}]):
            chunks.append(chunk)
        assert len(chunks) == 2
        assert chunks[0].content == "Hello"
        assert chunks[1].is_final is True
        assert isinstance(chunks[0], StreamChunk)

    @pytest.mark.asyncio
    async def test_metrics_recorded(self, provider):
        await provider.complete([{"role": "user", "content": "Hi"}])
        assert provider.metrics.total_requests == 1
        assert provider.metrics.successful_requests == 1

    @pytest.mark.asyncio
    async def test_initialize(self, provider):
        await provider.initialize()
        assert provider._initialized is True

    @pytest.mark.asyncio
    async def test_shutdown(self, provider):
        await provider.initialize()
        await provider.shutdown()
        assert provider._initialized is False

    @pytest.mark.asyncio
    async def test_health_check(self, provider):
        status = await provider.health_check()
        assert isinstance(status, HealthStatus)

    def test_normalize_config_dict(self, provider):
        config = provider._normalize_config({"key": "value"})
        assert config == {"key": "value"}

    def test_normalize_config_none(self, provider):
        config = provider._normalize_config(None)
        assert config == {}

    def test_get_api_key_from_config(self):
        provider = MockProvider(config={"api_key": "from-config"})
        key = provider._get_api_key()
        assert key == "from-config"

    def test_get_api_key_from_env(self, monkeypatch):
        monkeypatch.setenv("MOCK_API_KEY", "from-env")
        provider = MockProvider()
        key = provider._get_api_key()
        assert key == "from-env"


class TestCaching:
    @pytest.mark.asyncio
    async def test_caching_enabled(self):
        provider = MockProvider(
            config={"api_key": "test", "model": "mock-model"},
            enable_caching=True,
        )

        # First call — cache miss
        r1 = await provider.complete([{"role": "user", "content": "Hi"}])
        assert provider.metrics.cache_misses == 1

        # Second call — cache hit
        r2 = await provider.complete([{"role": "user", "content": "Hi"}])
        assert provider.metrics.cache_hits == 1
        assert r1.content == r2.content

    @pytest.mark.asyncio
    async def test_caching_disabled_by_default(self):
        provider = MockProvider(config={"api_key": "test", "model": "mock-model"})
        await provider.complete([{"role": "user", "content": "Hi"}])
        assert provider.metrics.cache_hits == 0
        assert provider.metrics.cache_misses == 0


class TestKeyPool:
    @pytest.mark.asyncio
    async def test_key_pool_integration(self):
        provider = MockProvider(
            config={"model": "mock-model"},
            api_keys=["key1", "key2", "key3"],
            key_rotation_strategy="round_robin",
        )
        assert provider._key_pool is not None
        assert len(provider._key_pool) == 3

    @pytest.mark.asyncio
    async def test_get_key_pool_status(self):
        provider = MockProvider(
            config={"model": "mock-model"},
            api_keys=["key1", "key2"],
        )
        status = await provider.get_key_pool_status()
        assert status is not None
        assert status["total_keys"] == 2

    @pytest.mark.asyncio
    async def test_no_key_pool(self):
        provider = MockProvider(config={"api_key": "single-key"})
        status = await provider.get_key_pool_status()
        assert status is None


class TestCircuitBreakerIntegration:
    @pytest.mark.asyncio
    async def test_circuit_breaker_enabled(self):
        provider = MockProvider(
            config={"api_key": "test", "model": "mock-model"},
            enable_circuit_breaker=True,
        )
        assert provider._circuit_breaker is not None

    @pytest.mark.asyncio
    async def test_circuit_breaker_records_success(self):
        provider = MockProvider(
            config={"api_key": "test", "model": "mock-model"},
            enable_circuit_breaker=True,
        )
        await provider.complete([{"role": "user", "content": "Hi"}])
        state = provider._circuit_breaker.get_state()
        assert state["total_successes"] >= 1

    @pytest.mark.asyncio
    async def test_circuit_breaker_blocks_when_open(self):
        from agenticraft_llm.resilience.circuit_breaker import (
            CircuitBreakerConfig,
            CircuitBreakerState,
        )

        provider = MockProvider(
            config={"api_key": "test", "model": "mock-model"},
            enable_circuit_breaker=True,
            circuit_breaker_config=CircuitBreakerConfig(failure_threshold=1),
        )
        # Force the circuit breaker open
        provider._circuit_breaker._state = CircuitBreakerState.OPEN
        provider._circuit_breaker._last_failure_time = __import__("time").monotonic()

        from agenticraft_llm.resilience.circuit_breaker import CircuitOpenError

        with pytest.raises(CircuitOpenError):
            await provider.complete([{"role": "user", "content": "Hi"}])

    @pytest.mark.asyncio
    async def test_circuit_breaker_with_custom_config(self):
        from agenticraft_llm.resilience.circuit_breaker import CircuitBreakerConfig

        config = CircuitBreakerConfig(failure_threshold=10, recovery_timeout=120.0)
        provider = MockProvider(
            config={"api_key": "test", "model": "mock-model"},
            enable_circuit_breaker=True,
            circuit_breaker_config=config,
        )
        assert provider._circuit_breaker.config.failure_threshold == 10


class TestRateLimiterIntegration:
    @pytest.mark.asyncio
    async def test_rate_limiter_enabled(self):
        provider = MockProvider(
            config={"api_key": "test", "model": "mock-model"},
            enable_rate_limiter=True,
        )
        assert provider._rate_limiter is not None

    @pytest.mark.asyncio
    async def test_rate_limiter_allows_requests(self):
        provider = MockProvider(
            config={"api_key": "test", "model": "mock-model"},
            enable_rate_limiter=True,
        )
        result = await provider.complete([{"role": "user", "content": "Hi"}])
        assert result.content == "Hello from mock!"

    @pytest.mark.asyncio
    async def test_rate_limiter_blocks_when_exhausted(self):
        from agenticraft_llm.resilience.rate_limiter import RateLimitConfig

        config = RateLimitConfig(max_calls=1, time_window=60.0, burst_size=1)
        provider = MockProvider(
            config={"api_key": "test", "model": "mock-model"},
            enable_rate_limiter=True,
            rate_limiter_config=config,
        )
        # Exhaust the bucket
        await provider.complete([{"role": "user", "content": "Hi"}])

        from agenticraft_llm.exceptions import LLMRateLimitError

        with pytest.raises(LLMRateLimitError):
            await provider.complete([{"role": "user", "content": "Hi again"}])


class FailingProvider(MockProvider):
    """Provider that fails on request."""

    fail_count = 0
    max_failures = 2

    async def _make_request(
        self, messages: list[dict[str, Any]], model: str, **kwargs: Any
    ) -> dict[str, Any]:
        self.fail_count += 1
        if self.fail_count <= self.max_failures:
            from agenticraft_llm.exceptions import LLMRateLimitError

            raise LLMRateLimitError("Rate limited", provider="mock", model=model)
        return await super()._make_request(messages, model, **kwargs)


class TestRetryBehavior:
    @pytest.mark.asyncio
    async def test_retries_on_rate_limit(self):
        provider = FailingProvider(config={"api_key": "test", "model": "mock-model"})
        provider.fail_count = 0
        provider.max_failures = 1
        result = await provider.complete([{"role": "user", "content": "Hi"}], max_retries=3)
        assert result.content == "Hello from mock!"
        assert provider.fail_count == 2  # 1 failure + 1 success

    @pytest.mark.asyncio
    async def test_exhausts_retries(self):
        provider = FailingProvider(config={"api_key": "test", "model": "mock-model"})
        provider.fail_count = 0
        provider.max_failures = 10

        from agenticraft_llm.exceptions import LLMRateLimitError

        with pytest.raises(LLMRateLimitError):
            await provider.complete([{"role": "user", "content": "Hi"}], max_retries=1)


class TestStreamErrorHandling:
    @pytest.mark.asyncio
    async def test_stream_error_records_metrics(self):
        class ErrorStreamProvider(MockProvider):
            async def _stream_request(self, messages, model, **kwargs):
                yield {"content": "Start", "model": model, "provider": "mock", "done": False}
                raise RuntimeError("Stream failed")

        provider = ErrorStreamProvider(config={"api_key": "test", "model": "mock-model"})

        with pytest.raises(RuntimeError):
            async for _ in provider.stream([{"role": "user", "content": "Hi"}]):
                pass

        assert provider.metrics.failed_requests >= 1


class TestHooks:
    @pytest.mark.asyncio
    async def test_pre_request_hook(self):
        class HookProvider(MockProvider):
            async def pre_request_hook(self, messages, model, **kwargs):
                messages = [{"role": "user", "content": "Modified!"}]
                return messages, model, kwargs

        provider = HookProvider(config={"api_key": "test", "model": "mock-model"})
        result = await provider.complete([{"role": "user", "content": "Original"}])
        assert result.content == "Hello from mock!"

    @pytest.mark.asyncio
    async def test_post_response_hook(self):
        class HookProvider(MockProvider):
            async def post_response_hook(self, response):
                return LLMResponse(
                    content="Modified response",
                    model=response.model,
                    provider=response.provider,
                    usage=response.usage,
                )

        provider = HookProvider(config={"api_key": "test", "model": "mock-model"})
        result = await provider.complete([{"role": "user", "content": "Hi"}])
        assert result.content == "Modified response"


class TestNormalizeConfig:
    def test_normalize_config_with_model_dump(self):
        class FakeConfig:
            def model_dump(self):
                return {"key": "value"}

        provider = MockProvider()
        result = provider._normalize_config(FakeConfig())
        assert result == {"key": "value"}

    def test_normalize_config_with_dict_attr(self):
        class FakeConfig:
            def __init__(self):
                self.key = "value"
                self._private = "hidden"

        provider = MockProvider()
        result = provider._normalize_config(FakeConfig())
        assert result == {"key": "value"}
