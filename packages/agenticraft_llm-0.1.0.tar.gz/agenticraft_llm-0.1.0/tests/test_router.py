"""Tests for cost-aware router."""

import pytest

from agenticraft_llm.router import (
    CostAwareRouter,
    CostRouterConfig,
    CostRoutingDecision,
    ProviderCostProfile,
    reset_router,
)


@pytest.fixture(autouse=True)
def cleanup_router():
    """Reset singleton router between tests."""
    reset_router()
    yield
    reset_router()


class TestProviderCostProfile:
    def test_avg_cost(self):
        p = ProviderCostProfile(provider="openai", input_cost_per_1k=0.01, output_cost_per_1k=0.03)
        assert p.avg_cost_per_1k == 0.02

    def test_estimate_cost(self):
        p = ProviderCostProfile(provider="openai", input_cost_per_1k=0.01, output_cost_per_1k=0.03)
        cost = p.estimate_cost(input_tokens=1000, output_tokens=500)
        assert cost == pytest.approx(0.01 + 0.015)


class TestCostAwareRouter:
    @pytest.fixture
    def profiles(self):
        return {
            "cheap": ProviderCostProfile(
                provider="cheap",
                input_cost_per_1k=0.001,
                output_cost_per_1k=0.002,
                quality_score=0.7,
                latency_ms_p50=200,
            ),
            "quality": ProviderCostProfile(
                provider="quality",
                input_cost_per_1k=0.01,
                output_cost_per_1k=0.03,
                quality_score=0.95,
                latency_ms_p50=500,
            ),
            "balanced": ProviderCostProfile(
                provider="balanced",
                input_cost_per_1k=0.005,
                output_cost_per_1k=0.015,
                quality_score=0.85,
                latency_ms_p50=300,
            ),
        }

    @pytest.fixture
    def router(self, profiles):
        return CostAwareRouter(profiles=profiles)

    @pytest.mark.asyncio
    async def test_select_provider(self, router):
        await router.initialize()
        result = await router.select_provider(
            providers=["cheap", "quality", "balanced"],
            estimated_tokens=1000,
        )
        assert result in ["cheap", "quality", "balanced"]

    @pytest.mark.asyncio
    async def test_select_with_quality_threshold(self, router):
        await router.initialize()
        result = await router.select_provider(
            providers=["cheap", "quality", "balanced"],
            estimated_tokens=1000,
            quality_threshold=0.9,
        )
        # Only "quality" meets 0.9 threshold
        assert result == "quality"

    @pytest.mark.asyncio
    async def test_select_with_cost_constraint(self, router):
        await router.initialize()
        decision = await router.select_with_constraints(
            providers=["cheap", "quality", "balanced"],
            input_tokens=500,
            output_tokens=500,
            max_cost=0.005,
        )
        assert decision is not None
        assert decision.selected_provider == "cheap"
        assert decision.estimated_cost <= 0.005

    @pytest.mark.asyncio
    async def test_select_empty_providers(self, router):
        await router.initialize()
        result = await router.select_provider(providers=[])
        assert result is None

    @pytest.mark.asyncio
    async def test_select_unknown_provider(self, router):
        await router.initialize()
        result = await router.select_provider(providers=["unknown"])
        assert result is None

    @pytest.mark.asyncio
    async def test_strict_budget_blocks(self, profiles):
        config = CostRouterConfig(strict_budget=True)
        router = CostAwareRouter(config=config, profiles=profiles)
        await router.initialize()

        decision = await router.select_with_constraints(
            providers=["cheap", "quality"],
            input_tokens=1000,
            output_tokens=1000,
            max_cost=0.0001,  # Impossibly low
        )
        assert decision is None

    @pytest.mark.asyncio
    async def test_fallback_provider(self, profiles):
        config = CostRouterConfig(fallback_provider="cheap")
        router = CostAwareRouter(config=config, profiles=profiles)
        await router.initialize()

        decision = await router.select_with_constraints(
            providers=["quality"],
            input_tokens=1000,
            output_tokens=1000,
            max_cost=0.0001,
            quality_threshold=0.99,
        )
        assert decision is not None
        assert decision.selected_provider == "cheap"

    @pytest.mark.asyncio
    async def test_constraints_relaxed(self, router):
        await router.initialize()
        decision = await router.select_with_constraints(
            providers=["cheap", "quality"],
            input_tokens=1000,
            output_tokens=1000,
            max_cost=0.0001,
            quality_threshold=0.99,
        )
        assert decision is not None
        assert "constraints relaxed" in decision.constraints_applied

    def test_update_posterior_success(self, router):
        router.update_posterior("cheap", success=True, quality_score=0.9)
        profile = router._profiles["cheap"]
        assert profile.beta_alpha > 1.0

    def test_update_posterior_failure(self, router):
        router.update_posterior("cheap", success=False)
        profile = router._profiles["cheap"]
        assert profile.beta_beta > 1.0

    def test_update_profile(self, router):
        new_profile = ProviderCostProfile(
            provider="new", input_cost_per_1k=0.1, output_cost_per_1k=0.2
        )
        router.update_profile("new", new_profile)
        assert "new" in router.get_all_profiles()

    def test_get_stats(self, router):
        stats = router.get_stats()
        assert stats["selections"] == 0
        assert stats["provider_count"] == 3

    @pytest.mark.asyncio
    async def test_thompson_sampling(self, profiles):
        config = CostRouterConfig(explore_mode=True)
        router = CostAwareRouter(config=config, profiles=profiles)
        await router.initialize()

        # Run multiple selections — Thompson sampling adds randomness
        selections = set()
        for _ in range(20):
            result = await router.select_provider(
                providers=["cheap", "quality", "balanced"],
                estimated_tokens=1000,
            )
            if result:
                selections.add(result)

        # With Thompson sampling, we should see some exploration
        assert len(selections) >= 1


class TestCostRoutingDecision:
    def test_creation(self):
        decision = CostRoutingDecision(
            selected_provider="openai",
            estimated_cost=0.05,
            quality_score=0.9,
            reason="Best score",
        )
        assert decision.selected_provider == "openai"
        assert decision.estimated_cost == 0.05
        assert decision.alternatives == []
