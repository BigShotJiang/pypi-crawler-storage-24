"""Tests for config module."""

from agenticraft_llm.config import LLMProviderConfig


class TestLLMProviderConfig:
    def test_defaults(self):
        config = LLMProviderConfig()
        assert config.name == ""
        assert config.api_key is None
        assert config.temperature == 0.7
        assert config.timeout == 30
        assert config.max_retries == 3

    def test_custom_values(self):
        config = LLMProviderConfig(
            name="test",
            api_key="sk-test",
            model="gpt-4",
            temperature=0.5,
        )
        assert config.name == "test"
        assert config.api_key == "sk-test"
        assert config.model == "gpt-4"

    def test_extra_allowed(self):
        config = LLMProviderConfig(custom_field="custom_value")
        assert config.custom_field == "custom_value"  # type: ignore
