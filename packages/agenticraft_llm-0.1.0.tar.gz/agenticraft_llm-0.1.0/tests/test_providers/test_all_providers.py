"""Parameterized tests for all provider implementations."""

from __future__ import annotations

import pytest

PROVIDER_SPECS = [
    {
        "module": "bedrock",
        "class": "BedrockProvider",
        "name": "bedrock",
        "init_kwargs": {"model": "claude-3-haiku"},
        "expected_model": "anthropic.claude-3-haiku-20240307-v1:0",
        "expected_models": ["claude-3-haiku", "nova-pro"],
        "expected_caps": ["completion", "streaming"],
    },
    {
        "module": "cohere",
        "class": "CohereProvider",
        "name": "cohere",
        "init_kwargs": {"api_key": "test", "model": "command-r"},
        "expected_model": "command-r",
        "expected_models": ["command-r", "command-r-plus"],
        "expected_caps": ["completion", "streaming", "embeddings"],
    },
    {
        "module": "ollama",
        "class": "OllamaProvider",
        "name": "ollama",
        "init_kwargs": {"model": "llama2"},
        "expected_model": "llama2",
        "expected_models": ["llama2", "mistral"],
        "expected_caps": ["completion", "streaming"],
    },
    {
        "module": "fireworks",
        "class": "FireworksProvider",
        "name": "fireworks",
        "init_kwargs": {"api_key": "test", "model": "deepseek-v3"},
        "expected_model": "accounts/fireworks/models/deepseek-v3",
        "expected_models": ["deepseek-v3", "llama-3.3-70b"],
        "expected_caps": ["completion", "streaming"],
    },
    {
        "module": "cerebras",
        "class": "CerebrasProvider",
        "name": "cerebras",
        "init_kwargs": {"api_key": "test", "model": "llama-3.3-70b"},
        "expected_model": "llama3.3-70b",
        "expected_models": ["llama-3.3-70b"],
        "expected_caps": ["completion", "streaming"],
    },
    {
        "module": "deepseek",
        "class": "DeepSeekProvider",
        "name": "deepseek",
        "init_kwargs": {"api_key": "test", "model": "deepseek-chat"},
        "expected_model": "deepseek-chat",
        "expected_models": ["deepseek-chat", "deepseek-reasoner"],
        "expected_caps": ["completion", "streaming", "reasoning"],
    },
    {
        "module": "xai",
        "class": "XAIProvider",
        "name": "xai",
        "init_kwargs": {"api_key": "test", "model": "grok-4"},
        "expected_model": "grok-4",
        "expected_models": ["grok-4"],
        "expected_caps": ["completion", "streaming"],
    },
    {
        "module": "openrouter",
        "class": "OpenRouterProvider",
        "name": "openrouter",
        "init_kwargs": {"api_key": "test", "model": "meta-llama/llama-3.1-70b-instruct"},
        "expected_model": "meta-llama/llama-3.1-70b-instruct",
        "expected_models": ["meta-llama/llama-3.1-70b-instruct", "openai/gpt-4o"],
        "expected_caps": ["completion", "streaming"],
    },
    {
        "module": "perplexity",
        "class": "PerplexityProvider",
        "name": "perplexity",
        "init_kwargs": {"api_key": "test", "model": "sonar"},
        "expected_model": "sonar",
        "expected_models": ["sonar", "sonar-pro"],
        "expected_caps": ["completion", "streaming"],
    },
    {
        "module": "nebius",
        "class": "NebiusProvider",
        "name": "nebius",
        "init_kwargs": {"api_key": "test", "model": "meta-llama/Meta-Llama-3.1-70B-Instruct"},
        "expected_model": "meta-llama/Meta-Llama-3.1-70B-Instruct",
        "expected_models": ["meta-llama/Meta-Llama-3.1-70B-Instruct"],
        "expected_caps": ["completion", "streaming"],
    },
]


def _get_provider(spec):
    """Dynamically import and instantiate a provider."""
    import importlib

    mod = importlib.import_module(f"agenticraft_llm.providers.{spec['module']}")
    cls = getattr(mod, spec["class"])
    return cls(**spec["init_kwargs"])


@pytest.mark.parametrize("spec", PROVIDER_SPECS, ids=[s["name"] for s in PROVIDER_SPECS])
class TestProviderBasics:
    def test_name(self, spec):
        provider = _get_provider(spec)
        assert provider.name == spec["name"]

    def test_default_model(self, spec):
        provider = _get_provider(spec)
        assert provider.default_model == spec["expected_model"]

    def test_supported_models_contains_expected(self, spec):
        provider = _get_provider(spec)
        models = provider.get_supported_models()
        for model in spec["expected_models"]:
            assert model in models, f"{spec['name']} missing model {model}"

    def test_capabilities_contains_expected(self, spec):
        provider = _get_provider(spec)
        caps = provider.get_capabilities()
        for cap in spec["expected_caps"]:
            assert cap in caps, f"{spec['name']} missing capability {cap}"

    def test_has_pricing(self, spec):
        provider = _get_provider(spec)
        if spec["name"] != "ollama":
            assert hasattr(provider, "PRICING")
            assert len(provider.PRICING) > 0

    def test_calculate_cost(self, spec):
        provider = _get_provider(spec)
        cost = provider._calculate_cost(
            spec["expected_model"],
            {"prompt_tokens": 1000, "completion_tokens": 500},
        )
        if spec["name"] == "ollama":
            assert cost == 0.0  # Free local model
        else:
            assert cost >= 0

    def test_supports_model(self, spec):
        provider = _get_provider(spec)
        assert provider.supports_model(spec["expected_model"])
        assert not provider.supports_model("nonexistent-model-xyz")

    def test_import_from_package(self, spec):
        import agenticraft_llm

        assert hasattr(agenticraft_llm, spec["class"])
