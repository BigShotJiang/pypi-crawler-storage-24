"""Tests for Anthropic provider."""

from unittest.mock import AsyncMock, MagicMock

import pytest


class TestAnthropicProvider:
    @pytest.fixture
    def provider(self):
        from agenticraft_llm.providers.anthropic import AnthropicProvider

        return AnthropicProvider(api_key="sk-ant-test", model="claude-sonnet-4-20250514")

    def test_name(self, provider):
        assert provider.name == "anthropic"

    def test_default_model(self, provider):
        assert provider.default_model == "claude-sonnet-4-20250514"

    def test_supported_models(self, provider):
        models = provider.get_supported_models()
        assert "claude-sonnet-4-20250514" in models
        assert "claude-opus-4-20250514" in models

    def test_capabilities(self, provider):
        caps = provider.get_capabilities()
        assert "completion" in caps
        assert "streaming" in caps
        assert "vision" in caps
        assert "tool_use" in caps

    def test_pricing(self, provider):
        assert hasattr(provider, "PRICING")
        assert "claude-sonnet-4-20250514" in provider.PRICING

    def test_calculate_cost(self, provider):
        cost = provider._calculate_cost(
            "claude-sonnet-4-20250514",
            {"prompt_tokens": 1000, "completion_tokens": 500},
        )
        assert cost > 0

    @pytest.mark.asyncio
    async def test_complete_with_mock(self, provider):
        mock_response = MagicMock()
        mock_response.content = [MagicMock()]
        mock_response.content[0].text = "Hello from Claude!"
        mock_response.content[0].type = "text"
        mock_response.stop_reason = "end_turn"
        mock_response.usage = MagicMock()
        mock_response.usage.input_tokens = 10
        mock_response.usage.output_tokens = 5
        mock_response.model = "claude-sonnet-4-20250514"

        mock_client = AsyncMock()
        mock_client.messages.create = AsyncMock(return_value=mock_response)

        provider._async_client = mock_client
        provider._initialized = True
        provider._api_key = "sk-ant-test"

        response = await provider.complete([{"role": "user", "content": "Hi"}])
        assert response.content == "Hello from Claude!"
        assert response.provider == "anthropic"


class TestAnthropicImport:
    def test_import_from_package(self):
        from agenticraft_llm import AnthropicProvider

        assert AnthropicProvider is not None
