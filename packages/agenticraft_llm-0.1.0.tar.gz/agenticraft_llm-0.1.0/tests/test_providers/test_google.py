"""Tests for Google provider."""

import pytest


class TestGoogleProvider:
    @pytest.fixture
    def provider(self):
        from agenticraft_llm.providers.google import GoogleProvider

        return GoogleProvider(api_key="test-key", model="gemini-pro")

    def test_name(self, provider):
        assert provider.name == "google"

    def test_default_model(self, provider):
        assert provider.default_model == "gemini-pro"

    def test_supported_models(self, provider):
        models = provider.get_supported_models()
        assert "gemini-pro" in models
        assert "gemini-2.5-pro" in models
        assert "gemini-2.0-flash" in models

    def test_capabilities(self, provider):
        caps = provider.get_capabilities()
        assert "completion" in caps
        assert "streaming" in caps
        assert "vision" in caps

    def test_pricing(self, provider):
        assert hasattr(provider, "PRICING")
        assert "gemini-pro" in provider.PRICING

    def test_calculate_cost(self, provider):
        cost = provider._calculate_cost(
            "gemini-pro",
            {"prompt_tokens": 1000, "completion_tokens": 500},
        )
        assert cost > 0


class TestGoogleImport:
    def test_import_from_package(self):
        from agenticraft_llm import GoogleProvider

        assert GoogleProvider is not None
