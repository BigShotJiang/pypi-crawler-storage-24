"""Tests for OpenAI provider."""

from unittest.mock import AsyncMock, MagicMock

import pytest


class TestOpenAIProvider:
    @pytest.fixture
    def provider(self):
        from agenticraft_llm.providers.openai import OpenAIProvider

        return OpenAIProvider(api_key="sk-test", model="gpt-4o-mini")

    def test_name(self, provider):
        assert provider.name == "openai"

    def test_default_model(self, provider):
        assert provider.default_model == "gpt-4o-mini"

    def test_supported_models(self, provider):
        models = provider.get_supported_models()
        assert "gpt-4o" in models
        assert "gpt-4o-mini" in models
        assert "o1" in models

    def test_capabilities(self, provider):
        caps = provider.get_capabilities()
        assert "completion" in caps
        assert "streaming" in caps
        assert "function_calling" in caps
        assert "vision" in caps

    def test_pricing(self, provider):
        assert "gpt-4o" in provider.PRICING
        assert "gpt-4o-mini" in provider.PRICING

    def test_calculate_cost(self, provider):
        cost = provider._calculate_cost(
            "gpt-4o-mini",
            {"prompt_tokens": 1000, "completion_tokens": 500},
        )
        assert cost > 0

    def test_calculate_cost_unknown_model(self, provider):
        # Falls back to gpt-3.5-turbo pricing
        cost = provider._calculate_cost(
            "unknown-model",
            {"prompt_tokens": 1000, "completion_tokens": 500},
        )
        assert cost > 0

    def test_format_tools_dict(self, provider):
        tools = [{"type": "function", "function": {"name": "test"}}]
        formatted = provider._format_tools(tools)
        assert formatted == tools

    def test_format_tools_object(self, provider):
        tool = MagicMock()
        tool.to_openai_schema.return_value = {"type": "function", "function": {"name": "test"}}
        formatted = provider._format_tools([tool])
        assert formatted[0]["type"] == "function"

    def test_get_stats(self, provider):
        stats = provider.get_stats()
        assert stats["provider"] == "openai"
        assert stats["total_requests"] == 0
        assert stats["total_cost"] == 0

    @pytest.mark.asyncio
    async def test_complete_with_mock(self, provider):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "Hello!"
        mock_response.choices[0].message.tool_calls = None
        mock_response.choices[0].finish_reason = "stop"
        mock_response.usage = MagicMock()
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 5
        mock_response.usage.total_tokens = 15

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_response)

        provider._async_client = mock_client
        provider._initialized = True
        provider._api_key = "sk-test"

        response = await provider.complete([{"role": "user", "content": "Hi"}])
        assert response.content == "Hello!"
        assert response.provider == "openai"
        assert response.usage.total_tokens == 15

    def test_env_key(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-from-env")
        from agenticraft_llm.providers.openai import OpenAIProvider

        provider = OpenAIProvider()
        assert provider._config.get("api_key") == "sk-from-env"

    def test_multi_key(self):
        from agenticraft_llm.providers.openai import OpenAIProvider

        provider = OpenAIProvider(api_keys=["sk-1", "sk-2", "sk-3"])
        assert provider._key_pool is not None
        assert len(provider._key_pool) == 3


class TestOpenAIImport:
    def test_import_from_package(self):
        from agenticraft_llm import OpenAIProvider

        assert OpenAIProvider is not None

    def test_import_from_providers(self):
        from agenticraft_llm.providers import OpenAIProvider

        assert OpenAIProvider is not None
