"""Tests for Azure OpenAI provider."""

import pytest


class TestAzureOpenAIProvider:
    @pytest.fixture
    def provider(self):
        from agenticraft_llm.providers.azure_openai import AzureOpenAIProvider

        return AzureOpenAIProvider(api_key="test-key", model="gpt-4o")

    def test_name(self, provider):
        assert provider.name == "azure_openai"

    def test_default_model(self, provider):
        assert provider.default_model == "gpt-4o"

    def test_supported_models(self, provider):
        models = provider.get_supported_models()
        assert "gpt-4o" in models
        assert "gpt-4o-mini" in models

    def test_capabilities(self, provider):
        caps = provider.get_capabilities()
        assert "completion" in caps
        assert "streaming" in caps
        assert "embeddings" in caps

    def test_pricing(self, provider):
        assert hasattr(provider, "PRICING")
        assert "gpt-4o" in provider.PRICING

    def test_calculate_cost(self, provider):
        cost = provider._calculate_cost(
            "gpt-4o",
            {"prompt_tokens": 1000, "completion_tokens": 500},
        )
        assert cost > 0


class TestAzureOpenAIImport:
    def test_import_from_package(self):
        from agenticraft_llm import AzureOpenAIProvider

        assert AzureOpenAIProvider is not None
