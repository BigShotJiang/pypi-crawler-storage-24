"""Mock completion tests for all provider implementations.

Tests _make_request directly to achieve coverage of provider-specific
SDK interaction code without requiring actual SDK installations.
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from agenticraft_llm.types import LLMCapabilityType

# ---------------------------------------------------------------------------
# Helpers for OpenAI-compatible mock responses
# ---------------------------------------------------------------------------


def _openai_mock_response(
    content: str = "Hello!",
    model: str = "test-model",
    prompt_tokens: int = 10,
    completion_tokens: int = 5,
    finish_reason: str = "stop",
    tool_calls: list | None = None,
) -> MagicMock:
    """Create a mock OpenAI-style response object."""
    resp = MagicMock()
    resp.model = model
    # Prevent MagicMock auto-generating attributes that cause comparison errors
    resp.time_info = None  # Cerebras-specific

    choice = MagicMock()
    choice.message.content = content
    choice.message.tool_calls = tool_calls
    choice.finish_reason = finish_reason
    resp.choices = [choice]

    resp.usage = MagicMock()
    resp.usage.prompt_tokens = prompt_tokens
    resp.usage.completion_tokens = completion_tokens
    resp.usage.total_tokens = prompt_tokens + completion_tokens
    return resp


def _openai_mock_tool_call(
    tc_id: str = "call_1",
    name: str = "search",
    arguments: dict | None = None,
) -> MagicMock:
    tc = MagicMock()
    tc.id = tc_id
    tc.function.name = name
    tc.function.arguments = json.dumps(arguments or {"q": "test"})
    return tc


MESSAGES = [{"role": "user", "content": "Hi"}]


# ===================================================================
# OpenAI-compatible providers (skip those needing SDK for error handling)
# Only test providers that use openai SDK and whose _make_request
# works cleanly with a mocked AsyncOpenAI client.
# ===================================================================

OPENAI_COMPAT_SPECS = [
    {
        "module": "deepseek",
        "class": "DeepSeekProvider",
        "init_kwargs": {"api_key": "test", "model": "deepseek-chat"},
        "model": "deepseek-chat",
        "provider_name": "deepseek",
    },
    {
        "module": "xai",
        "class": "XAIProvider",
        "init_kwargs": {"api_key": "test", "model": "grok-4"},
        "model": "grok-4",
        "provider_name": "xai",
    },
    {
        "module": "cerebras",
        "class": "CerebrasProvider",
        "init_kwargs": {"api_key": "test", "model": "llama-3.3-70b"},
        "model": "llama3.3-70b",
        "provider_name": "cerebras",
    },
    {
        "module": "fireworks",
        "class": "FireworksProvider",
        "init_kwargs": {"api_key": "test", "model": "deepseek-v3"},
        "model": "accounts/fireworks/models/deepseek-v3",
        "provider_name": "fireworks",
    },
    {
        "module": "openrouter",
        "class": "OpenRouterProvider",
        "init_kwargs": {"api_key": "test", "model": "meta-llama/llama-3.1-70b-instruct"},
        "model": "meta-llama/llama-3.1-70b-instruct",
        "provider_name": "openrouter",
    },
    {
        "module": "perplexity",
        "class": "PerplexityProvider",
        "init_kwargs": {"api_key": "test", "model": "sonar"},
        "model": "sonar",
        "provider_name": "perplexity",
    },
    {
        "module": "nebius",
        "class": "NebiusProvider",
        "init_kwargs": {"api_key": "test", "model": "meta-llama/Meta-Llama-3.1-70B-Instruct"},
        "model": "meta-llama/Meta-Llama-3.1-70B-Instruct",
        "provider_name": "nebius",
    },
]


def _get_provider_class(spec: dict) -> type:
    import importlib

    mod = importlib.import_module(f"agenticraft_llm.providers.{spec['module']}")
    return getattr(mod, spec["class"])


def _get_provider(spec: dict) -> Any:
    cls = _get_provider_class(spec)
    return cls(**spec["init_kwargs"])


@pytest.mark.parametrize(
    "spec",
    OPENAI_COMPAT_SPECS,
    ids=[s["provider_name"] for s in OPENAI_COMPAT_SPECS],
)
class TestOpenAICompatCompletion:
    """Test _make_request for all OpenAI-compatible providers."""

    @pytest.mark.asyncio
    async def test_basic_completion(self, spec):
        provider = _get_provider(spec)
        mock_resp = _openai_mock_response(content="Test response", model=spec["model"])

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_resp)

        provider._async_client = mock_client
        provider._initialized = True
        provider._api_key = "test"

        result = await provider._make_request(MESSAGES, spec["model"])

        assert result["content"] == "Test response"
        assert result["provider"] == spec["provider_name"]
        assert result["usage"]["prompt_tokens"] == 10
        assert result["usage"]["completion_tokens"] == 5
        mock_client.chat.completions.create.assert_called_once()

    @pytest.mark.asyncio
    async def test_completion_with_tools(self, spec):
        provider_cls = _get_provider_class(spec)
        tool_caps = {LLMCapabilityType.FUNCTION_CALLING, LLMCapabilityType.TOOL_USE}
        if not (provider_cls.CAPABILITIES & tool_caps):
            pytest.skip(f"{spec['provider_name']} declares no tool capability")

        tc = _openai_mock_tool_call()
        mock_resp = _openai_mock_response(content="", model=spec["model"], tool_calls=[tc])

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_resp)

        provider = _get_provider(spec)
        provider._async_client = mock_client
        provider._initialized = True
        provider._api_key = "test"

        result = await provider._make_request(
            MESSAGES,
            spec["model"],
            tools=[{"type": "function", "function": {"name": "search", "parameters": {}}}],
        )

        assert result.get("tool_calls") is not None
        assert len(result["tool_calls"]) == 1
        assert result["tool_calls"][0]["name"] == "search"

    @pytest.mark.asyncio
    async def test_completion_with_params(self, spec):
        mock_resp = _openai_mock_response(model=spec["model"])
        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_resp)

        provider = _get_provider(spec)
        provider._async_client = mock_client
        provider._initialized = True
        provider._api_key = "test"

        result = await provider._make_request(
            MESSAGES,
            spec["model"],
            temperature=0.5,
            max_tokens=100,
        )

        assert result["content"] == "Hello!"


# ===================================================================
# Azure OpenAI provider (separate due to different init signature)
# ===================================================================


class TestAzureOpenAICompletion:
    @pytest.fixture
    def provider(self):
        from agenticraft_llm.providers.azure_openai import AzureOpenAIProvider

        return AzureOpenAIProvider(
            config={
                "api_key": "test",
                "model": "gpt-4o",
                "azure_endpoint": "https://test.openai.azure.com",
                "api_version": "2024-02-15-preview",
            }
        )

    @pytest.mark.asyncio
    async def test_basic_completion(self, provider):
        mock_resp = _openai_mock_response(content="Azure response", model="gpt-4o")
        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_resp)

        provider._async_client = mock_client
        provider._initialized = True
        provider._api_key = "test"

        result = await provider._make_request(MESSAGES, "gpt-4o")

        assert result["content"] == "Azure response"
        assert result["provider"] == "azure_openai"

    @pytest.mark.asyncio
    async def test_with_tools(self, provider):
        tc = _openai_mock_tool_call()
        mock_resp = _openai_mock_response(content="", model="gpt-4o", tool_calls=[tc])
        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_resp)

        provider._async_client = mock_client
        provider._initialized = True
        provider._api_key = "test"

        result = await provider._make_request(
            MESSAGES,
            "gpt-4o",
            tools=[{"type": "function", "function": {"name": "search", "parameters": {}}}],
        )

        assert result.get("tool_calls") is not None
        assert result["tool_calls"][0]["name"] == "search"


# ===================================================================
# Cohere provider
# ===================================================================


class TestCohereCompletion:
    @pytest.fixture
    def provider(self):
        from agenticraft_llm.providers.cohere import CohereProvider

        return CohereProvider(api_key="test", model="command-r")

    @pytest.mark.asyncio
    async def test_basic_completion(self, provider):
        mock_resp = MagicMock()
        mock_resp.text = "Hello from Cohere!"
        mock_resp.citations = None
        mock_resp.tool_calls = None
        mock_resp.meta = MagicMock()
        mock_resp.meta.tokens = MagicMock()
        mock_resp.meta.tokens.input_tokens = 10
        mock_resp.meta.tokens.output_tokens = 5

        mock_client = AsyncMock()
        mock_client.chat = AsyncMock(return_value=mock_resp)

        provider._client = mock_client
        provider._initialized = True
        provider._api_key = "test"

        result = await provider._make_request(MESSAGES, "command-r")

        assert result["content"] == "Hello from Cohere!"
        assert result["provider"] == "cohere"
        assert result["usage"]["prompt_tokens"] == 10

    @pytest.mark.asyncio
    async def test_with_system_message(self, provider):
        mock_resp = MagicMock()
        mock_resp.text = "Response"
        mock_resp.citations = None
        mock_resp.tool_calls = None
        mock_resp.meta = MagicMock()
        mock_resp.meta.tokens = MagicMock()
        mock_resp.meta.tokens.input_tokens = 15
        mock_resp.meta.tokens.output_tokens = 8

        mock_client = AsyncMock()
        mock_client.chat = AsyncMock(return_value=mock_resp)

        provider._client = mock_client
        provider._initialized = True
        provider._api_key = "test"

        messages = [
            {"role": "system", "content": "You are helpful"},
            {"role": "user", "content": "Hi"},
        ]
        await provider._make_request(messages, "command-r")

        call_kwargs = mock_client.chat.call_args[1]
        assert call_kwargs.get("preamble") == "You are helpful"

    @pytest.mark.asyncio
    async def test_with_citations(self, provider):
        citation = MagicMock()
        citation.start = 0
        citation.end = 5
        citation.text = "Hello"
        citation.document_ids = ["doc1"]

        mock_resp = MagicMock()
        mock_resp.text = "Hello from docs"
        mock_resp.citations = [citation]
        mock_resp.tool_calls = None
        mock_resp.meta = MagicMock()
        mock_resp.meta.tokens = MagicMock()
        mock_resp.meta.tokens.input_tokens = 10
        mock_resp.meta.tokens.output_tokens = 5

        mock_client = AsyncMock()
        mock_client.chat = AsyncMock(return_value=mock_resp)

        provider._client = mock_client
        provider._initialized = True
        provider._api_key = "test"

        result = await provider._make_request(
            MESSAGES, "command-r", documents=[{"text": "doc content"}]
        )

        assert result["citations"] is not None
        assert len(result["citations"]) == 1

    @pytest.mark.asyncio
    async def test_with_multi_turn(self, provider):
        mock_resp = MagicMock()
        mock_resp.text = "Followup response"
        mock_resp.citations = None
        mock_resp.tool_calls = None
        mock_resp.meta = MagicMock()
        mock_resp.meta.tokens = MagicMock()
        mock_resp.meta.tokens.input_tokens = 20
        mock_resp.meta.tokens.output_tokens = 10

        mock_client = AsyncMock()
        mock_client.chat = AsyncMock(return_value=mock_resp)

        provider._client = mock_client
        provider._initialized = True
        provider._api_key = "test"

        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
            {"role": "user", "content": "How are you?"},
        ]
        await provider._make_request(messages, "command-r")

        call_kwargs = mock_client.chat.call_args[1]
        assert call_kwargs.get("chat_history") is not None
        assert len(call_kwargs["chat_history"]) == 2


# ===================================================================
# Ollama provider
# ===================================================================


class TestOllamaCompletion:
    @pytest.fixture
    def provider(self):
        from agenticraft_llm.providers.ollama import OllamaProvider

        return OllamaProvider(model="llama2")

    @pytest.mark.asyncio
    async def test_basic_completion(self, provider):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "message": {"content": "Hello from Ollama!", "role": "assistant"},
            "prompt_eval_count": 10,
            "eval_count": 5,
            "done": True,
            "done_reason": "stop",
        }
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)

        provider._http_client = mock_client
        provider._initialized = True

        result = await provider._make_request(MESSAGES, "llama2")

        assert result["content"] == "Hello from Ollama!"
        assert result["provider"] == "ollama"
        assert result["cost"] == 0.0

    @pytest.mark.asyncio
    async def test_strips_ollama_prefix(self, provider):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "message": {"content": "Response", "role": "assistant"},
            "prompt_eval_count": 5,
            "eval_count": 3,
            "done": True,
        }
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)

        provider._http_client = mock_client
        provider._initialized = True

        result = await provider._make_request(MESSAGES, "ollama/llama2")
        assert result["model"] == "llama2"

    @pytest.mark.asyncio
    async def test_with_duration_tracking(self, provider):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "message": {"content": "OK", "role": "assistant"},
            "prompt_eval_count": 5,
            "eval_count": 3,
            "done": True,
            "total_duration": 1_500_000_000,  # 1.5 seconds in nanoseconds
        }
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)

        provider._http_client = mock_client
        provider._initialized = True

        await provider._make_request(MESSAGES, "llama2")
        assert provider._total_duration_ms > 0

    @pytest.mark.asyncio
    async def test_404_raises_model_not_found(self, provider):
        import httpx

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 404
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "Not found", request=MagicMock(), response=mock_response
        )

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)

        provider._http_client = mock_client
        provider._initialized = True

        from agenticraft_llm.exceptions import LLMModelNotFoundError

        with pytest.raises(LLMModelNotFoundError):
            await provider._make_request(MESSAGES, "nonexistent")

    @pytest.mark.asyncio
    async def test_429_raises_rate_limit(self, provider):
        import httpx

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 429
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "Rate limited", request=MagicMock(), response=mock_response
        )

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)

        provider._http_client = mock_client
        provider._initialized = True

        from agenticraft_llm.exceptions import LLMRateLimitError

        with pytest.raises(LLMRateLimitError):
            await provider._make_request(MESSAGES, "llama2")

    @pytest.mark.asyncio
    async def test_other_http_error(self, provider):
        import httpx

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 500
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "Server error", request=MagicMock(), response=mock_response
        )

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)

        provider._http_client = mock_client
        provider._initialized = True

        from agenticraft_llm.exceptions import LLMProviderError

        with pytest.raises(LLMProviderError):
            await provider._make_request(MESSAGES, "llama2")

    @pytest.mark.asyncio
    async def test_timeout_error(self, provider):
        import httpx

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(side_effect=httpx.TimeoutException("Timeout"))

        provider._http_client = mock_client
        provider._initialized = True

        from agenticraft_llm.exceptions import LLMTimeoutError

        with pytest.raises(LLMTimeoutError):
            await provider._make_request(MESSAGES, "llama2")


# ===================================================================
# Google provider
# ===================================================================


class TestGoogleCompletion:
    @pytest.fixture
    def provider(self):
        from agenticraft_llm.providers.google import GoogleProvider

        return GoogleProvider(api_key="test", model="gemini-pro")

    @pytest.mark.asyncio
    async def test_basic_completion(self, provider):
        mock_part = MagicMock()
        mock_part.text = "Hello from Gemini!"

        mock_response = MagicMock()
        mock_response.parts = [mock_part]
        mock_response.usage_metadata = MagicMock()
        mock_response.usage_metadata.prompt_token_count = 10
        mock_response.usage_metadata.candidates_token_count = 5
        mock_response.usage_metadata.total_token_count = 15

        mock_model = MagicMock()

        provider._model_cache = {"gemini-pro": mock_model}
        provider._genai = MagicMock()
        provider._initialized = True
        provider._api_key = "test"

        # Patch asyncio.to_thread to call the function synchronously
        async def fake_to_thread(fn, *args, **kwargs):
            return mock_response

        with patch("asyncio.to_thread", side_effect=fake_to_thread):
            result = await provider._make_request(MESSAGES, "gemini-pro")

        assert result["content"] == "Hello from Gemini!"
        assert result["provider"] == "google"

    @pytest.mark.asyncio
    async def test_auth_error(self, provider):
        mock_model = MagicMock()

        provider._model_cache = {"gemini-pro": mock_model}
        provider._genai = MagicMock()
        provider._initialized = True
        provider._api_key = "test"

        from agenticraft_llm.exceptions import LLMAuthenticationError

        async def fake_to_thread(fn, *args, **kwargs):
            raise Exception("API key not valid")

        with patch("asyncio.to_thread", side_effect=fake_to_thread):
            with pytest.raises(LLMAuthenticationError):
                await provider._make_request(MESSAGES, "gemini-pro")

    @pytest.mark.asyncio
    async def test_rate_limit_error(self, provider):
        provider._model_cache = {"gemini-pro": MagicMock()}
        provider._genai = MagicMock()
        provider._initialized = True
        provider._api_key = "test"

        from agenticraft_llm.exceptions import LLMRateLimitError

        async def fake_to_thread(fn, *args, **kwargs):
            raise Exception("Rate limit exceeded")

        with patch("asyncio.to_thread", side_effect=fake_to_thread):
            with pytest.raises(LLMRateLimitError):
                await provider._make_request(MESSAGES, "gemini-pro")

    @pytest.mark.asyncio
    async def test_model_not_found_error(self, provider):
        provider._model_cache = {"gemini-pro": MagicMock()}
        provider._genai = MagicMock()
        provider._initialized = True
        provider._api_key = "test"

        from agenticraft_llm.exceptions import LLMModelNotFoundError

        async def fake_to_thread(fn, *args, **kwargs):
            raise Exception("Model does not exist")

        with patch("asyncio.to_thread", side_effect=fake_to_thread):
            with pytest.raises(LLMModelNotFoundError):
                await provider._make_request(MESSAGES, "gemini-pro")

    @pytest.mark.asyncio
    async def test_timeout_error(self, provider):
        provider._model_cache = {"gemini-pro": MagicMock()}
        provider._genai = MagicMock()
        provider._initialized = True
        provider._api_key = "test"

        from agenticraft_llm.exceptions import LLMTimeoutError

        async def fake_to_thread(fn, *args, **kwargs):
            raise Exception("Request timed out")

        with patch("asyncio.to_thread", side_effect=fake_to_thread):
            with pytest.raises(LLMTimeoutError):
                await provider._make_request(MESSAGES, "gemini-pro")

    @pytest.mark.asyncio
    async def test_quota_error(self, provider):
        provider._model_cache = {"gemini-pro": MagicMock()}
        provider._genai = MagicMock()
        provider._initialized = True
        provider._api_key = "test"

        from agenticraft_llm.exceptions import LLMRateLimitError

        async def fake_to_thread(fn, *args, **kwargs):
            raise Exception("Quota exceeded for project")

        with patch("asyncio.to_thread", side_effect=fake_to_thread):
            with pytest.raises(LLMRateLimitError):
                await provider._make_request(MESSAGES, "gemini-pro")


# ===================================================================
# Bedrock provider
# ===================================================================


class TestBedrockCompletion:
    @pytest.fixture
    def provider(self):
        from agenticraft_llm.providers.bedrock import BedrockProvider

        return BedrockProvider(model="claude-3-haiku")

    @pytest.mark.asyncio
    async def test_basic_completion(self, provider):
        mock_response = {
            "output": {
                "message": {
                    "content": [{"text": "Hello from Bedrock!"}],
                    "role": "assistant",
                }
            },
            "usage": {
                "inputTokens": 10,
                "outputTokens": 5,
            },
            "stopReason": "end_turn",
        }

        mock_client = MagicMock()
        provider._bedrock_runtime = mock_client
        provider._initialized = True

        async def fake_to_thread(fn, **kwargs):
            return mock_response

        with patch("asyncio.to_thread", side_effect=fake_to_thread):
            result = await provider._make_request(MESSAGES, "claude-3-haiku")

        assert result["content"] == "Hello from Bedrock!"
        assert result["provider"] == "bedrock"
        assert result["usage"]["prompt_tokens"] == 10

    @pytest.mark.asyncio
    async def test_with_system_message(self, provider):
        mock_response = {
            "output": {
                "message": {
                    "content": [{"text": "Response"}],
                    "role": "assistant",
                }
            },
            "usage": {"inputTokens": 15, "outputTokens": 8},
            "stopReason": "end_turn",
        }

        mock_client = MagicMock()
        provider._bedrock_runtime = mock_client
        provider._initialized = True

        messages = [
            {"role": "system", "content": "You are helpful"},
            {"role": "user", "content": "Hi"},
        ]

        async def fake_to_thread(fn, **kwargs):
            return mock_response

        with patch("asyncio.to_thread", side_effect=fake_to_thread):
            result = await provider._make_request(messages, "claude-3-haiku")

        assert result["content"] == "Response"
