"""Tests for gateway routes."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

import pytest

try:
    from httpx import ASGITransport, AsyncClient

    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

try:
    import fastapi  # noqa: F401

    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import LLMCapabilityType

pytestmark = pytest.mark.skipif(
    not (HAS_HTTPX and HAS_FASTAPI), reason="httpx and fastapi required"
)


class MockGatewayProvider(BaseLLMProvider):
    """Mock provider for gateway tests."""

    SUPPORTED_MODELS = {"test-model", "test-model-v2"}
    CAPABILITIES = {LLMCapabilityType.COMPLETION, LLMCapabilityType.STREAMING}

    provider_name = "test"

    @property
    def name(self) -> str:
        return "test"

    @property
    def default_model(self) -> str:
        return "test-model"

    async def _make_request(
        self, messages: list[dict[str, Any]], model: str, **kwargs: Any
    ) -> dict[str, Any]:
        return {
            "content": "Hello from gateway!",
            "model": model,
            "provider": "test",
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
            "finish_reason": "stop",
        }

    async def _stream_request(
        self, messages: list[dict[str, Any]], model: str, **kwargs: Any
    ) -> AsyncIterator[dict[str, Any]]:
        yield {"content": "Hello", "model": model, "provider": "test", "done": False}
        yield {
            "content": " world",
            "model": model,
            "provider": "test",
            "done": True,
            "finish_reason": "stop",
        }


@pytest.fixture
def mock_provider():
    provider = MockGatewayProvider(config={"api_key": "test", "model": "test-model"})
    provider._initialized = True
    return provider


@pytest.fixture
def app(mock_provider):
    from agenticraft_llm.gateway import create_gateway_app

    return create_gateway_app(providers={"test": mock_provider})


@pytest.fixture
def authed_app(mock_provider):
    from agenticraft_llm.gateway import create_gateway_app

    return create_gateway_app(providers={"test": mock_provider}, api_key="secret-key")


class TestHealthEndpoint:
    @pytest.mark.asyncio
    async def test_health(self, app):
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            resp = await client.get("/health")
            assert resp.status_code == 200
            assert resp.json()["status"] == "ok"


class TestModelListing:
    @pytest.mark.asyncio
    async def test_list_models(self, app):
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            resp = await client.get("/v1/models")
            assert resp.status_code == 200
            data = resp.json()
            assert data["object"] == "list"
            assert len(data["data"]) >= 2
            model_ids = {m["id"] for m in data["data"]}
            assert "test-model" in model_ids


class TestChatCompletions:
    @pytest.mark.asyncio
    async def test_non_streaming(self, app):
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            resp = await client.post(
                "/v1/chat/completions",
                json={
                    "model": "test-model",
                    "messages": [{"role": "user", "content": "Hello"}],
                },
            )
            assert resp.status_code == 200
            data = resp.json()
            assert data["object"] == "chat.completion"
            assert data["choices"][0]["message"]["content"] == "Hello from gateway!"
            assert data["usage"]["total_tokens"] == 15

    @pytest.mark.asyncio
    async def test_streaming(self, app):
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            resp = await client.post(
                "/v1/chat/completions",
                json={
                    "model": "test-model",
                    "messages": [{"role": "user", "content": "Hello"}],
                    "stream": True,
                },
            )
            assert resp.status_code == 200
            assert "text/event-stream" in resp.headers["content-type"]
            # Check that we got SSE data
            text = resp.text
            assert "data:" in text
            assert "[DONE]" in text

    @pytest.mark.asyncio
    async def test_model_not_found(self, app):
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            resp = await client.post(
                "/v1/chat/completions",
                json={
                    "model": "nonexistent-model",
                    "messages": [{"role": "user", "content": "Hello"}],
                },
            )
            assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_auto_model(self, app):
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            resp = await client.post(
                "/v1/chat/completions",
                json={
                    "model": "auto",
                    "messages": [{"role": "user", "content": "Hello"}],
                },
            )
            assert resp.status_code == 200


class TestAuthMiddleware:
    @pytest.mark.asyncio
    async def test_no_auth_required(self, app):
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            resp = await client.get("/v1/models")
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_auth_required_no_header(self, authed_app):
        async with AsyncClient(
            transport=ASGITransport(app=authed_app), base_url="http://test"
        ) as client:
            resp = await client.get("/v1/models")
            assert resp.status_code == 401

    @pytest.mark.asyncio
    async def test_auth_required_wrong_key(self, authed_app):
        async with AsyncClient(
            transport=ASGITransport(app=authed_app), base_url="http://test"
        ) as client:
            resp = await client.get("/v1/models", headers={"Authorization": "Bearer wrong-key"})
            assert resp.status_code == 401

    @pytest.mark.asyncio
    async def test_auth_correct_key(self, authed_app):
        async with AsyncClient(
            transport=ASGITransport(app=authed_app), base_url="http://test"
        ) as client:
            resp = await client.get("/v1/models", headers={"Authorization": "Bearer secret-key"})
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_health_bypasses_auth(self, authed_app):
        async with AsyncClient(
            transport=ASGITransport(app=authed_app), base_url="http://test"
        ) as client:
            resp = await client.get("/health")
            assert resp.status_code == 200


class TestRoutingStats:
    @pytest.mark.asyncio
    async def test_routing_stats(self, app):
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            resp = await client.get("/v1/routing/stats")
            assert resp.status_code == 200
            data = resp.json()
            assert "test" in data["providers"]
