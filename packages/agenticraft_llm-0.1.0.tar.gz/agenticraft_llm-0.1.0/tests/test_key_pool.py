"""Tests for key pool module."""

import pytest

from agenticraft_llm.key_pool import KeyMetrics, KeyPoolManager, KeyState
from agenticraft_llm.types import KeyStatus, RotationStrategy


class TestKeyMetrics:
    def test_initial_state(self):
        m = KeyMetrics()
        assert m.total_requests == 0
        assert m.success_rate == 1.0  # New key = assume good
        assert m.health_score > 0.0

    def test_record_success(self):
        m = KeyMetrics()
        m.record_request(success=True, latency_ms=100.0, tokens=50, cost_usd=0.01)
        assert m.successful_requests == 1
        assert m.consecutive_successes == 1
        assert m.consecutive_errors == 0

    def test_record_failure(self):
        m = KeyMetrics()
        m.record_request(success=False)
        assert m.failed_requests == 1
        assert m.consecutive_errors == 1

    def test_record_rate_limit(self):
        m = KeyMetrics()
        m.record_rate_limit()
        assert m.rate_limit_hits == 1

    def test_health_score_degrades(self):
        m = KeyMetrics()
        initial = m.health_score
        for _ in range(5):
            m.record_request(success=False)
        assert m.health_score < initial

    def test_to_dict(self):
        m = KeyMetrics()
        d = m.to_dict()
        assert "total_requests" in d
        assert "health_score" in d


class TestKeyState:
    def test_initial_available(self):
        state = KeyState(key="sk-test1234", key_id="...1234")
        assert state.is_available() is True

    def test_disabled_unavailable(self):
        state = KeyState(key="sk-test1234", key_id="...1234", status=KeyStatus.DISABLED)
        assert state.is_available() is False

    def test_rate_limited(self):
        state = KeyState(key="sk-test1234", key_id="...1234")
        state.set_rate_limited(retry_after=60.0)
        assert state.status == KeyStatus.RATE_LIMITED
        assert state.is_available() is False

    def test_cooldown(self):
        state = KeyState(key="sk-test1234", key_id="...1234")
        state.set_cooldown(duration=30.0)
        assert state.status == KeyStatus.COOLING_DOWN
        assert state.is_available() is False


class TestKeyPoolManager:
    def test_create_empty(self):
        pool = KeyPoolManager(provider="openai")
        assert len(pool) == 0
        assert bool(pool) is False

    def test_add_keys(self):
        pool = KeyPoolManager(provider="openai", keys=["key1", "key2", "key3"])
        assert len(pool) == 3
        assert bool(pool) is True

    def test_add_duplicate(self):
        pool = KeyPoolManager(provider="openai", keys=["key1", "key1"])
        assert len(pool) == 1

    def test_remove_key(self):
        pool = KeyPoolManager(provider="openai", keys=["key1", "key2"])
        assert pool.remove_key("key1") is True
        assert len(pool) == 1
        assert pool.remove_key("nonexistent") is False

    @pytest.mark.asyncio
    async def test_acquire(self):
        pool = KeyPoolManager(provider="openai", keys=["key1", "key2"])
        key = await pool.acquire()
        assert key in ["key1", "key2"]

    @pytest.mark.asyncio
    async def test_acquire_empty_raises(self):
        pool = KeyPoolManager(provider="openai")
        with pytest.raises(RuntimeError, match="No available API keys"):
            await pool.acquire()

    @pytest.mark.asyncio
    async def test_record_success(self):
        pool = KeyPoolManager(provider="openai", keys=["key1"])
        key = await pool.acquire()
        await pool.record_success(key, latency_ms=100, tokens=50)
        status = pool.get_status()
        assert status["total_requests"] == 1
        key_info = list(status["keys"].values())[0]
        assert key_info["metrics"]["successful_requests"] == 1

    @pytest.mark.asyncio
    async def test_record_error_cooldown(self):
        pool = KeyPoolManager(
            provider="openai",
            keys=["key1", "key2"],
            max_consecutive_errors=2,
        )
        key = await pool.acquire()
        await pool.record_error(key, "Error 1")
        await pool.record_error(key, "Error 2")
        # After 2 consecutive errors, key should be in cooldown
        status = pool.get_status()
        assert status["cooling_down_keys"] == 1

    @pytest.mark.asyncio
    async def test_record_rate_limit(self):
        pool = KeyPoolManager(provider="openai", keys=["key1", "key2"])
        await pool.record_rate_limit("key1", retry_after=60.0)
        status = pool.get_status()
        assert status["rate_limited_keys"] == 1

    @pytest.mark.asyncio
    async def test_round_robin(self):
        pool = KeyPoolManager(
            provider="openai",
            keys=["key1", "key2", "key3"],
            strategy=RotationStrategy.ROUND_ROBIN,
        )
        keys = [await pool.acquire() for _ in range(6)]
        # Should cycle through keys
        assert len(set(keys)) > 1

    @pytest.mark.asyncio
    async def test_least_used(self):
        pool = KeyPoolManager(
            provider="openai",
            keys=["key1", "key2"],
            strategy=RotationStrategy.LEAST_USED,
        )
        # First acquire should pick key1 or key2 (both 0 requests)
        key = await pool.acquire()
        assert key in ["key1", "key2"]

    def test_get_status(self):
        pool = KeyPoolManager(provider="openai", keys=["key1", "key2"])
        status = pool.get_status()
        assert status["provider"] == "openai"
        assert status["total_keys"] == 2
        assert status["active_keys"] == 2

    def test_get_available_count(self):
        pool = KeyPoolManager(provider="openai", keys=["key1", "key2"])
        assert pool.get_available_count() == 2

    @pytest.mark.asyncio
    async def test_from_env(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEYS", "key1,key2,key3")
        pool = KeyPoolManager.from_env("openai")
        assert len(pool) == 3

    @pytest.mark.asyncio
    async def test_from_env_single(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "single-key")
        pool = KeyPoolManager.from_env("openai")
        assert len(pool) == 1

    @pytest.mark.asyncio
    async def test_from_env_none(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEYS", raising=False)
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        pool = KeyPoolManager.from_env("openai")
        assert len(pool) == 0
