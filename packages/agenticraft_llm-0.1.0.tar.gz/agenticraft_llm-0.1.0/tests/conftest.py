"""Pytest configuration for agenticraft-llm tests."""

import pytest


@pytest.fixture(autouse=True)
def _reset_registry():
    """Reset provider registry between tests."""
    from agenticraft_llm.registry import _registry

    original = _registry.copy()
    yield
    _registry.clear()
    _registry.update(original)
