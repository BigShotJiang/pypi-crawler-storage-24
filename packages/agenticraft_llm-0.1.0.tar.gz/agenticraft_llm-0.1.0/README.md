<div align="center">

[![CI](https://img.shields.io/github/actions/workflow/status/agenticraft/agenticraft-llm/ci.yml?style=flat-square&label=CI)](https://github.com/agenticraft/agenticraft-llm/actions/workflows/ci.yml)
[![coverage](https://img.shields.io/codecov/c/github/agenticraft/agenticraft-llm/main?style=flat-square)](https://codecov.io/gh/agenticraft/agenticraft-llm)
[![python](https://img.shields.io/badge/python-3.10%2B-blue?style=flat-square)](https://www.python.org/downloads/)
[![license](https://img.shields.io/badge/license-BSL%201.1-blue?style=flat-square)](LICENSE)

**Production-grade LLM provider abstraction with intelligent routing, resilience, and cost optimization.**

The LLM engine behind [AgentiCraft](https://agenticraft.ai) -- an enterprise-grade platform for building production-ready AI agents and multi-agent systems.

14 providers &middot; Key rotation &middot; Circuit breakers &middot; Thompson sampling routing &middot; OpenAI-compatible gateway &middot; One interface

</div>

---

## Install

With [uv](https://docs.astral.sh/uv/) (recommended):

```bash
uv add agenticraft-llm                # Core (no provider SDKs)
uv add agenticraft-llm[openai]        # OpenAI
uv add agenticraft-llm[anthropic]     # Anthropic
uv add agenticraft-llm[all]           # All providers
uv add agenticraft-llm[gateway]       # OpenAI-compatible API server
```

Or with pip:

```bash
pip install agenticraft-llm[all]
```

## Quick Start

```python
from agenticraft_llm import OpenAIProvider

provider = OpenAIProvider(api_key="sk-...")
response = await provider.complete([{"role": "user", "content": "Hello!"}])
print(response.content)       # "Hello! How can I help?"
print(response.usage)         # TokenUsage(prompt_tokens=8, completion_tokens=12, ...)
print(response.cost)          # 0.00042
```

### Multi-Provider Routing

```python
from agenticraft_llm import CostAwareRouter, OpenAIProvider, AnthropicProvider

router = CostAwareRouter()
provider_name = await router.select_provider(
    providers=["openai", "anthropic"],
    estimated_tokens=1000,
    quality_threshold=0.8,
)
# Thompson sampling explores providers, converges to best cost/quality
```

### Streaming

```python
async for chunk in provider.stream([{"role": "user", "content": "Tell me a story"}]):
    print(chunk.content, end="", flush=True)
    if chunk.is_final:
        print(f"\n[{chunk.finish_reason}]")
```

### Key Rotation

```python
provider = OpenAIProvider(
    api_keys=["sk-key1", "sk-key2", "sk-key3"],
    key_rotation_strategy="adaptive",  # round_robin, least_used, random, weighted
)
# Automatic per-request rotation with health tracking
```

### Circuit Breaker

```python
provider = OpenAIProvider(
    api_key="sk-...",
    enable_circuit_breaker=True,   # Auto-trips after failures
    enable_rate_limiter=True,      # Token bucket rate limiting
)
```

### OpenAI-Compatible Gateway

```python
from agenticraft_llm.gateway import create_gateway_app

app = create_gateway_app(
    providers={"openai": openai_provider, "anthropic": anthropic_provider},
    api_key="your-gateway-key",
)
# Serves /v1/chat/completions, /v1/models -- drop-in replacement
```

```bash
# Use with any OpenAI-compatible client
curl http://localhost:8000/v1/chat/completions \
  -H "Authorization: Bearer your-gateway-key" \
  -d '{"model": "auto", "messages": [{"role": "user", "content": "Hello"}]}'
```

## Architecture

```mermaid
graph TB
    subgraph providers["Provider SDKs"]
        openai["OpenAI"]
        anthropic["Anthropic"]
        google["Google Gemini"]
        azure["Azure OpenAI"]
        more["+ 10 more"]
    end

    subgraph core["Core"]
        base["BaseLLMProvider<br/><i>abstract interface</i>"]
        types["LLMResponse / StreamChunk<br/><i>typed responses</i>"]
        exceptions["Exception Hierarchy<br/><i>SDK error mapping</i>"]
    end

    subgraph resilience["Resilience"]
        cb["Circuit Breaker<br/><i>per-provider fault tolerance</i>"]
        rl["Rate Limiter<br/><i>token bucket</i>"]
        retry["Retry<br/><i>exponential backoff + jitter</i>"]
    end

    subgraph routing["Routing"]
        router["CostAwareRouter<br/><i>Thompson sampling</i>"]
        keypool["KeyPool<br/><i>5 rotation strategies</i>"]
    end

    subgraph gateway["Gateway"]
        gw["OpenAI-Compatible API<br/><i>FastAPI + SSE</i>"]
    end

    openai & anthropic & google & azure & more --> base
    base --> types
    base --> exceptions
    base --> cb & rl & retry
    router --> base
    keypool --> base
    gw --> router

    style providers fill:#0d94881a,stroke:#0D9488
    style core fill:#0d94881a,stroke:#0D9488
    style resilience fill:#0d94881a,stroke:#0D9488
    style routing fill:#0d94881a,stroke:#0D9488
    style gateway fill:#0d94881a,stroke:#0D9488
```

## Providers

| Provider | SDK | Extra | Capabilities |
|----------|-----|-------|-------------|
| OpenAI | openai | `[openai]` | completion, streaming, vision, tool_use, json_mode |
| Anthropic | anthropic | `[anthropic]` | completion, streaming, vision, tool_use |
| Google Gemini | google-generativeai | `[google]` | completion, streaming, vision |
| Azure OpenAI | openai | `[azure]` | completion, streaming, vision, tool_use |
| AWS Bedrock | boto3 | `[bedrock]` | completion, streaming |
| Cohere | cohere | `[cohere]` | completion, streaming, embeddings |
| Ollama | httpx (built-in) | - | completion, streaming |
| Fireworks | openai | `[fireworks]` | completion, streaming |
| Cerebras | openai | `[cerebras]` | completion, streaming |
| DeepSeek | openai | `[deepseek]` | completion, streaming, reasoning |
| xAI (Grok) | openai | `[xai]` | completion, streaming |
| OpenRouter | openai | `[openrouter]` | completion, streaming |
| Perplexity | openai | `[perplexity]` | completion, streaming |
| Nebius | openai | `[nebius]` | completion, streaming |

## Features

| Feature | Description |
|---------|-------------|
| **Typed Responses** | `LLMResponse` and `StreamChunk` with usage, cost, latency |
| **Key Rotation** | 5 strategies (adaptive, round_robin, least_used, random, weighted) with health tracking |
| **Cost-Aware Routing** | Thompson sampling with Bayesian exploration, quality thresholds, budget constraints |
| **Circuit Breaker** | Per-provider fault tolerance with configurable thresholds and recovery |
| **Rate Limiter** | Token bucket with per-provider presets and burst capacity |
| **Retry with Backoff** | Exponential backoff with jitter for transient failures |
| **Pre/Post Hooks** | Customize request/response processing per provider |
| **Caching** | Bounded in-memory cache with TTL |
| **Gateway** | OpenAI-compatible FastAPI server with SSE streaming |
| **Exception Hierarchy** | SDK exceptions mapped to typed LLM errors |

## Configuration

```python
# All providers accept these common kwargs:
provider = AnyProvider(
    api_key="...",                    # API key
    model="...",                      # Default model
    api_keys=["k1", "k2"],          # Multi-key rotation
    key_rotation_strategy="adaptive", # Rotation strategy
    enable_caching=True,             # Response caching
    cache_ttl=300,                   # Cache TTL seconds
    enable_circuit_breaker=True,     # Circuit breaker
    enable_rate_limiter=True,        # Rate limiting
)
```

## Development

```bash
# Install dev dependencies
uv sync --group dev

# Run tests
uv run pytest tests/ -v -m "not e2e"

# Run with coverage
uv run pytest tests/ --cov=agenticraft_llm --cov-report=html

# Lint
uv run ruff check src/ tests/

# Format
uv run ruff format src/ tests/

# Type check
uv run pyright src/

# Pre-commit hooks
uv run pre-commit install
```

See [CONTRIBUTING.md](CONTRIBUTING.md) for full guidelines.

## License

BSL 1.1 (converts to Apache 2.0 after 4 years)

Part of the [AgentiCraft](https://agenticraft.ai) platform.
