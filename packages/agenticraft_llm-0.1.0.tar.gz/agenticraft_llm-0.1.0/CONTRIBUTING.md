# Contributing to agenticraft-llm

## Quick Start

```bash
git clone https://github.com/agenticraft/agenticraft-llm.git
cd agenticraft-llm
uv sync --group dev
uv run pytest tests/ -v
```

## Code Style

- **Formatter/linter**: [Ruff](https://docs.astral.sh/ruff/) (line-length 100, target `py310`)
- **Type checker**: pyright in basic mode
- **Docstrings**: Google style
- **Imports**: Always use `from __future__ import annotations` at the top of every module

Standard import order:

```python
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from some_module import SomeType
```

## Testing

- **Framework**: pytest with pytest-asyncio
- **Coverage minimum**: 80%
- **Test naming**: `test_<module>_<function>_<scenario>`
- **Markers**:
    - `@pytest.mark.e2e` -- end-to-end tests requiring API keys
    - `@pytest.mark.integration` -- integration tests
    - `@pytest.mark.benchmark` -- performance benchmarks

```bash
# Full test suite (excluding e2e)
uv run pytest tests/ -v -m "not e2e"

# With coverage report
uv run pytest tests/ --cov=agenticraft_llm --cov-report=html

# E2E tests (requires API keys)
uv run pytest tests/ -v -m e2e
```

## Linting

```bash
# Check for lint errors
uv run ruff check src/ tests/

# Auto-format
uv run ruff format src/ tests/

# Type check
uv run pyright src/
```

## Pre-Commit Hooks

Install pre-commit to run checks automatically before each commit:

```bash
uv run pre-commit install
```

## Adding a New Provider

1. Create `src/agenticraft_llm/providers/<name>.py`
2. Inherit from `BaseLLMProvider`
3. Set `SUPPORTED_MODELS`, `CAPABILITIES`, `PRICING` class attributes
4. Implement `_make_request()`, `_stream_request()`, `name` property
5. Add SDK exception mapping in `_make_request()`
6. Register in `providers/__init__.py` lazy-load dict
7. Add optional dependency in `pyproject.toml`
8. Write tests in `tests/test_providers/test_<name>.py`

## PR Process

### Branch Naming

- `feat/<name>` -- new features
- `fix/<name>` -- bug fixes
- `docs/<name>` -- documentation changes

### Commit Messages

Use conventional commit format:

```
feat(providers): add new LLM provider
fix(router): correct cost calculation
docs(readme): update quickstart example
test(providers): add mock tests for Anthropic
```

### Checklist

Before submitting a PR:

- [ ] All tests pass (`uv run pytest tests/ -v -m "not e2e"`)
- [ ] Linter is clean (`uv run ruff check src/ tests/`)
- [ ] Code is formatted (`uv run ruff format --check src/ tests/`)
- [ ] Type checker passes (`uv run pyright src/`)
- [ ] Security check passes (`uvx bandit -r src/agenticraft_llm/ -ll`)
- [ ] New functionality has tests
- [ ] Coverage >= 60%

## Module Structure

```
src/agenticraft_llm/
    base.py        # BaseLLMProvider abstract class
    config.py      # Provider and routing configuration
    exceptions.py  # LLM-specific exception hierarchy
    gateway/       # OpenAI-compatible FastAPI gateway
    key_pool.py    # Multi-key rotation with health tracking
    providers/     # 14 provider implementations
    registry.py    # Provider registry and lazy loading
    resilience/    # Circuit breaker, rate limiter, retry
    router.py      # Cost-aware routing with Thompson sampling
    types.py       # Response types (LLMResponse, StreamChunk)
```
