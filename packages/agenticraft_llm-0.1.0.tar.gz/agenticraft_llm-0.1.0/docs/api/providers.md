# Providers API

## BaseLLMProvider

Abstract base class for all providers.

### Methods

- `complete(messages, model=None, **kwargs) -> LLMResponse` — Generate completion
- `stream(messages, model=None, **kwargs) -> AsyncIterator[StreamChunk]` — Stream completion
- `initialize() -> None` — Initialize provider
- `shutdown() -> None` — Clean up resources
- `health_check() -> HealthStatus` — Check provider health
- `has_capability(cap) -> bool` — Check if capability is supported
- `supports_model(model) -> bool` — Check if model is supported
- `get_supported_models() -> set[str]` — List supported models
- `get_capabilities() -> set[str]` — List capabilities
- `get_key_pool_status() -> dict | None` — Key pool health info

### Constructor kwargs

All providers accept:

| Param | Type | Default | Description |
|-------|------|---------|-------------|
| `config` | `dict` | `{}` | Configuration dict |
| `api_key` | `str` | env var | API key |
| `model` | `str` | provider default | Default model |
| `api_keys` | `list[str]` | `None` | Keys for rotation |
| `key_rotation_strategy` | `str` | `"adaptive"` | Rotation strategy |
| `enable_caching` | `bool` | `False` | Response caching |
| `cache_ttl` | `int` | `300` | Cache TTL seconds |
| `enable_circuit_breaker` | `bool` | `False` | Circuit breaker |
| `circuit_breaker_config` | `CircuitBreakerConfig` | provider preset | CB config |
| `enable_rate_limiter` | `bool` | `False` | Rate limiter |
| `rate_limiter_config` | `RateLimitConfig` | provider preset | RL config |
