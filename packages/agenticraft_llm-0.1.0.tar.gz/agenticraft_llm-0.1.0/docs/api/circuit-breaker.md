# Circuit Breaker API

## CircuitBreaker

| Method | Description |
|--------|-------------|
| `record_success()` | Record successful call |
| `record_failure(error)` | Record failed call |
| `call(func, *args, **kwargs)` | Execute with protection |
| `reset()` | Reset to closed state |
| `get_state() -> dict` | Current state and metrics |
| `is_open -> bool` | Whether breaker is open |
| `is_closed -> bool` | Whether breaker is closed |

## CircuitBreakerConfig

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `failure_threshold` | `int` | `5` | Failures before opening |
| `recovery_timeout` | `float` | `60.0` | Seconds before half-open |
| `success_threshold` | `int` | `2` | Successes to close |

## TokenBucketRateLimiter

| Method | Description |
|--------|-------------|
| `acquire(tokens=1, timeout=None) -> bool` | Acquire tokens |
| `get_available_tokens() -> float` | Current bucket level |
| `get_metrics() -> dict` | Usage metrics |

## RateLimitConfig

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `max_calls` | `int` | `100` | Calls per window |
| `time_window` | `float` | `60.0` | Window in seconds |
| `burst_size` | `int` | `max_calls` | Burst capacity |
