# Router API

## CostAwareRouter

Thompson sampling router with cost and quality constraints.

### Methods

- `select_provider(providers, estimated_tokens, quality_threshold, max_cost_per_1k_tokens, strict_budget) -> CostRoutingDecision`
- `update_posterior(provider, success, latency_ms, cost)` — Update Beta posterior
- `update_profile(provider, profile)` — Set cost profile
- `get_stats() -> dict` — Get routing statistics

## CostRoutingDecision

| Field | Type | Description |
|-------|------|-------------|
| `provider` | `str` | Selected provider name |
| `score` | `float` | Thompson sample score |
| `estimated_cost` | `float` | Estimated cost |
| `reason` | `str` | Selection reason |

## ProviderCostProfile

| Field | Type | Description |
|-------|------|-------------|
| `provider_name` | `str` | Provider identifier |
| `cost_per_1k_input` | `float` | Input token cost |
| `cost_per_1k_output` | `float` | Output token cost |

## CostRouterConfig

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `explore_mode` | `bool` | `True` | Enable Thompson sampling |
| `strict_budget` | `bool` | `False` | Hard budget enforcement |
| `default_quality` | `float` | `0.5` | Quality prior |
