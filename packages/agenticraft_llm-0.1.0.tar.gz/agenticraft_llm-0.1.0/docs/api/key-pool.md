# Key Pool API

## KeyPoolManager

| Method | Description |
|--------|-------------|
| `acquire() -> str` | Get next available key |
| `record_success(key, latency_ms, tokens, cost)` | Record success |
| `record_error(key, error)` | Record error with cooldown |
| `record_rate_limit(key, retry_after)` | Record rate limit |
| `add_key(key)` | Add key to pool |
| `remove_key(key)` | Remove key |
| `get_status() -> dict` | Pool health status |
| `get_available_count() -> int` | Available key count |
| `from_env(provider, env_var) -> KeyPoolManager` | Create from env var |

## Rotation Strategies

| Strategy | Enum Value | Description |
|----------|-----------|-------------|
| Adaptive | `adaptive` | Favors healthiest keys |
| Round Robin | `round_robin` | Sequential cycling |
| Least Used | `least_used` | Fewest recent calls |
| Random | `random` | Random selection |
| Weighted | `weighted` | Health-weighted random |
