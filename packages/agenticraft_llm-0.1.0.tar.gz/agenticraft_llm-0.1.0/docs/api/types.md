# Types API

## LLMResponse

| Field | Type | Description |
|-------|------|-------------|
| `content` | `str` | Response text |
| `model` | `str` | Model used |
| `provider` | `str` | Provider name |
| `usage` | `TokenUsage` | Token usage |
| `latency_ms` | `float` | Request latency |
| `cost` | `float` | Estimated cost USD |
| `finish_reason` | `str` | Stop reason |
| `tool_calls` | `list[dict] \| None` | Tool call results |

## StreamChunk

| Field | Type | Description |
|-------|------|-------------|
| `content` | `str` | Text delta |
| `model` | `str` | Model name |
| `provider` | `str` | Provider name |
| `chunk_index` | `int` | Sequential index |
| `is_final` | `bool` | Last chunk flag |
| `finish_reason` | `str \| None` | Stop reason |
| `tool_call_delta` | `dict \| None` | Tool call delta |

## TokenUsage

| Field | Type | Description |
|-------|------|-------------|
| `prompt_tokens` | `int` | Input tokens |
| `completion_tokens` | `int` | Output tokens |
| `total_tokens` | `int` | Total tokens |

## Exceptions

| Exception | Parent | Description |
|-----------|--------|-------------|
| `LLMError` | `Exception` | Base error |
| `LLMProviderError` | `LLMError` | Provider-specific error |
| `LLMAuthenticationError` | `LLMProviderError` | Auth failure |
| `LLMRateLimitError` | `LLMProviderError` | Rate limited |
| `LLMTimeoutError` | `LLMProviderError` | Request timeout |
| `LLMModelNotFoundError` | `LLMProviderError` | Invalid model |
| `LLMConfigError` | `LLMError` | Configuration error |
| `LLMQuotaExceededError` | `LLMError` | Quota exceeded |
| `LLMOrchestrationError` | `LLMError` | Orchestration error |
| `LLMNoProvidersError` | `LLMOrchestrationError` | No providers available |
