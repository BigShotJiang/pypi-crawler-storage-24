# Cost-Aware Routing

The `CostAwareRouter` uses Thompson sampling to balance cost, quality, and exploration across multiple providers.

## How It Works

1. Each provider has a Beta posterior (alpha, beta) tracking success/failure
2. On each request, Thompson sampling draws from each posterior
3. The provider with the best score (considering cost and quality) is selected
4. Results update the posterior, so the router converges to the best provider

## Basic Usage

```python
from agenticraft_llm import CostAwareRouter

router = CostAwareRouter()

# Select provider
decision = await router.select_provider(
    providers=["openai", "anthropic", "google"],
    estimated_tokens=1000,
    quality_threshold=0.8,        # Minimum quality score
    max_cost_per_1k_tokens=0.01,  # Budget constraint
)

print(decision.provider)  # "openai"
print(decision.score)     # 0.85

# Update with results
router.update_posterior(
    "openai",
    success=True,
    latency_ms=250,
    cost=0.005,
)
```

## Configuration

```python
from agenticraft_llm import CostRouterConfig

config = CostRouterConfig(
    explore_mode=True,      # Enable Thompson sampling exploration
    strict_budget=False,    # Soft vs hard budget constraints
    default_quality=0.5,    # Quality prior for unknown providers
)
router = CostAwareRouter(config=config)
```

## Provider Cost Profiles

```python
from agenticraft_llm import ProviderCostProfile

router.update_profile(
    "openai",
    ProviderCostProfile(
        provider_name="openai",
        cost_per_1k_input=0.0025,
        cost_per_1k_output=0.01,
    ),
)
```
