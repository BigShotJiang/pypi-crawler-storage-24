# Gateway

OpenAI-compatible HTTP API server that proxies to any configured provider.

## Setup

```python
from agenticraft_llm import OpenAIProvider, AnthropicProvider
from agenticraft_llm.gateway import create_gateway_app

app = create_gateway_app(
    providers={
        "openai": OpenAIProvider(api_key="sk-..."),
        "anthropic": AnthropicProvider(api_key="sk-ant-..."),
    },
    api_key="my-gateway-key",  # Optional authentication
)
```

## Running

```bash
pip install agenticraft-llm[openai,gateway]
uvicorn my_gateway:app --host 0.0.0.0 --port 8000
```

## Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check |
| `/v1/models` | GET | List available models |
| `/v1/chat/completions` | POST | Chat completion (streaming + non-streaming) |
| `/v1/routing/stats` | GET | Router statistics |

## Usage

Works with any OpenAI-compatible client:

```bash
curl http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer my-gateway-key" \
  -d '{
    "model": "gpt-4o",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

### Auto Model Selection

Use `model: "auto"` to let the gateway choose the best provider:

```bash
curl http://localhost:8000/v1/chat/completions \
  -d '{"model": "auto", "messages": [{"role": "user", "content": "Hello"}]}'
```

### Streaming

```bash
curl http://localhost:8000/v1/chat/completions \
  -d '{"model": "gpt-4o", "messages": [...], "stream": true}'
```

Returns SSE events matching OpenAI's format, ending with `data: [DONE]`.
