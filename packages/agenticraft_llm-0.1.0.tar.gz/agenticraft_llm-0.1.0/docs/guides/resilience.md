# Resilience

agenticraft-llm includes circuit breaker and rate limiter components for production reliability.

## Circuit Breaker

Prevents cascading failures by stopping requests to unhealthy providers.

```python
from agenticraft_llm import OpenAIProvider
from agenticraft_llm.resilience import CircuitBreakerConfig

provider = OpenAIProvider(
    api_key="sk-...",
    enable_circuit_breaker=True,
    circuit_breaker_config=CircuitBreakerConfig(
        failure_threshold=5,      # Open after 5 failures
        recovery_timeout=60.0,    # Try recovery after 60s
        success_threshold=2,      # Close after 2 successes
    ),
)
```

### State Machine

```
CLOSED --[failures >= threshold]--> OPEN --[timeout elapsed]--> HALF_OPEN
  ^                                                                |
  +---[successes >= threshold]--------------------------------------+
  |                                                                |
  +---[failure in half-open]----> OPEN <---------------------------+
```

### Provider Presets

Each provider has default thresholds based on typical reliability:

```python
from agenticraft_llm.resilience import PROVIDER_DEFAULTS
# openai: failure_threshold=5, recovery_timeout=60
# groq:   failure_threshold=3, recovery_timeout=45
# ollama: failure_threshold=2, recovery_timeout=30
```

## Rate Limiter

Token bucket rate limiting with per-provider presets.

```python
from agenticraft_llm.resilience import RateLimitConfig

provider = OpenAIProvider(
    api_key="sk-...",
    enable_rate_limiter=True,
    rate_limiter_config=RateLimitConfig(
        max_calls=100,       # 100 calls per window
        time_window=60.0,    # 60-second window
        burst_size=20,       # Allow bursts of 20
    ),
)
```

## Standalone Usage

Both components can be used independently:

```python
from agenticraft_llm.resilience import CircuitBreaker, TokenBucketRateLimiter

breaker = CircuitBreaker(name="my-service")
result = await breaker.call(my_async_function, arg1, arg2)

limiter = TokenBucketRateLimiter()
if await limiter.acquire():
    # proceed with request
    pass
```
