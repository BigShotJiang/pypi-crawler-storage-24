# Key Management

Multi-key rotation with health tracking and 5 rotation strategies.

## Quick Setup

```python
provider = OpenAIProvider(
    api_keys=["sk-key1", "sk-key2", "sk-key3"],
    key_rotation_strategy="adaptive",
)
# Keys rotate automatically on each request
```

## Rotation Strategies

| Strategy | Description |
|----------|-------------|
| `adaptive` | Favors healthiest keys based on success rate (default) |
| `round_robin` | Cycles through keys in order |
| `least_used` | Uses the key with fewest recent calls |
| `random` | Random selection |
| `weighted` | Weighted by health score |

## Standalone Key Pool

```python
from agenticraft_llm import KeyPoolManager

pool = KeyPoolManager(
    provider="openai",
    keys=["sk-key1", "sk-key2", "sk-key3"],
    strategy="round_robin",
)

key = await pool.acquire()
await pool.record_success(key, latency_ms=200, tokens=1500)
# or
await pool.record_error(key, error="rate_limit")
```

## Health Monitoring

```python
status = await provider.get_key_pool_status()
# {
#     "total_keys": 3,
#     "available_keys": 2,
#     "keys": [
#         {"key": "sk-k***1", "health_score": 0.95, "status": "available"},
#         {"key": "sk-k***2", "health_score": 0.60, "status": "cooldown"},
#         {"key": "sk-k***3", "health_score": 0.90, "status": "available"},
#     ]
# }
```
