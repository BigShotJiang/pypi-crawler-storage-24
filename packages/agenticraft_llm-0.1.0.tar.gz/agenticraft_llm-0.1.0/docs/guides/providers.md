# Providers

agenticraft-llm supports 14 LLM providers through a unified interface.

## Provider Table

| Provider | Class | SDK | Capabilities |
|----------|-------|-----|-------------|
| OpenAI | `OpenAIProvider` | openai | completion, streaming, vision, tool_use, json_mode |
| Anthropic | `AnthropicProvider` | anthropic | completion, streaming, vision, tool_use |
| Google | `GoogleProvider` | google-generativeai | completion, streaming, vision |
| Azure OpenAI | `AzureOpenAIProvider` | openai | completion, streaming, vision, tool_use |
| AWS Bedrock | `BedrockProvider` | boto3 | completion, streaming |
| Cohere | `CohereProvider` | cohere | completion, streaming, embeddings |
| Ollama | `OllamaProvider` | httpx | completion, streaming |
| Fireworks | `FireworksProvider` | openai | completion, streaming |
| Cerebras | `CerebrasProvider` | openai | completion, streaming |
| DeepSeek | `DeepSeekProvider` | openai | completion, streaming, reasoning |
| xAI | `XAIProvider` | openai | completion, streaming |
| OpenRouter | `OpenRouterProvider` | openai | completion, streaming |
| Perplexity | `PerplexityProvider` | openai | completion, streaming |
| Nebius | `NebiusProvider` | openai | completion, streaming |

## Usage Pattern

All providers follow the same interface:

```python
from agenticraft_llm import OpenAIProvider  # or any provider

provider = OpenAIProvider(api_key="...", model="gpt-4o")

# Completion
response = await provider.complete(messages)

# Streaming
async for chunk in provider.stream(messages):
    print(chunk.content, end="")

# Check capabilities
provider.has_capability("vision")      # True/False
provider.supports_model("gpt-4o")     # True/False
provider.get_supported_models()        # {"gpt-4o", "gpt-4o-mini", ...}
```

## Environment Variables

Each provider checks for its API key in environment variables:

| Provider | Environment Variable |
|----------|---------------------|
| OpenAI | `OPENAI_API_KEY` |
| Anthropic | `ANTHROPIC_API_KEY` |
| Google | `GOOGLE_API_KEY` |
| Azure | `AZURE_OPENAI_API_KEY` |
| Cohere | `COHERE_API_KEY` |
| DeepSeek | `DEEPSEEK_API_KEY` |
| xAI | `XAI_API_KEY` |
| Fireworks | `FIREWORKS_API_KEY` |
| Cerebras | `CEREBRAS_API_KEY` |
| OpenRouter | `OPENROUTER_API_KEY` |
| Perplexity | `PERPLEXITY_API_KEY` |
| Nebius | `NEBIUS_API_KEY` |
