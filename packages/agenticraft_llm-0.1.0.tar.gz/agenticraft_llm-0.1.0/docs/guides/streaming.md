# Streaming

All providers support async streaming via `provider.stream()`.

## Basic Streaming

```python
async for chunk in provider.stream(
    [{"role": "user", "content": "Tell me a story"}]
):
    print(chunk.content, end="", flush=True)
    if chunk.is_final:
        print(f"\n[{chunk.finish_reason}]")
```

## StreamChunk

Each chunk contains:

| Field | Type | Description |
|-------|------|-------------|
| `content` | `str` | Text delta |
| `model` | `str` | Model name |
| `provider` | `str` | Provider name |
| `chunk_index` | `int` | Sequential index |
| `is_final` | `bool` | Last chunk flag |
| `finish_reason` | `str \| None` | Why generation stopped |
| `tool_call_delta` | `dict \| None` | Incremental tool call data |

## Collecting Full Response

```python
full_text = ""
async for chunk in provider.stream(messages):
    full_text += chunk.content
print(full_text)
```

## With Tool Calls

Some providers stream tool call deltas:

```python
async for chunk in provider.stream(messages, tools=my_tools):
    if chunk.tool_call_delta:
        print(f"Tool: {chunk.tool_call_delta}")
    else:
        print(chunk.content, end="")
```
