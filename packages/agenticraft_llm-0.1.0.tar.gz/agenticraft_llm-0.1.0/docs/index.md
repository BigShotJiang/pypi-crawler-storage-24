# agenticraft-llm

Production-grade LLM provider abstraction with intelligent routing, resilience, and cost optimization.

## Why agenticraft-llm?

- **14 providers, one interface** — OpenAI, Anthropic, Google, Azure, Bedrock, and 9 more
- **Cost-aware routing** — Thompson sampling finds the best cost/quality trade-off
- **Built-in resilience** — Circuit breakers, rate limiters, exponential backoff
- **Key rotation** — 5 strategies with automatic health tracking
- **OpenAI-compatible gateway** — Drop-in API server with SSE streaming
- **Typed responses** — `LLMResponse` with usage, cost, and latency

## Quick Install

```bash
pip install agenticraft-llm[openai]
```

## Quick Example

```python
from agenticraft_llm import OpenAIProvider

provider = OpenAIProvider(api_key="sk-...")
response = await provider.complete([{"role": "user", "content": "Hello!"}])
print(response.content)
```

See the [Quick Start](getting-started/quickstart.md) guide for more.
