# Installation

## Core Package

```bash
pip install agenticraft-llm
```

## Provider Extras

Install only the providers you need:

```bash
pip install agenticraft-llm[openai]        # OpenAI
pip install agenticraft-llm[anthropic]     # Anthropic
pip install agenticraft-llm[google]        # Google Gemini
pip install agenticraft-llm[azure]         # Azure OpenAI
pip install agenticraft-llm[bedrock]       # AWS Bedrock
pip install agenticraft-llm[cohere]        # Cohere
pip install agenticraft-llm[all]           # All providers
```

Ollama requires no extra — it uses `httpx` which is included in core.

## Gateway

For the OpenAI-compatible API server:

```bash
pip install agenticraft-llm[gateway]
```

## Development

```bash
git clone https://github.com/agenticraft/agenticraft-llm.git
cd agenticraft-llm
uv sync --group dev --extra gateway
```

## Requirements

- Python >= 3.10
- No required dependencies beyond the standard library (provider SDKs are optional extras)
