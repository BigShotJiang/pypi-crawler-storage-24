# Quick Start

## Basic Completion

```python
import asyncio
from agenticraft_llm import OpenAIProvider

async def main():
    provider = OpenAIProvider(api_key="sk-...")
    response = await provider.complete(
        [{"role": "user", "content": "What is the capital of France?"}]
    )
    print(response.content)       # "Paris"
    print(response.usage)         # TokenUsage(prompt_tokens=14, ...)
    print(f"${response.cost:.6f}")  # "$0.000042"

asyncio.run(main())
```

## Streaming

```python
async for chunk in provider.stream(
    [{"role": "user", "content": "Tell me a story"}]
):
    print(chunk.content, end="", flush=True)
```

## Multi-Provider

```python
from agenticraft_llm import AnthropicProvider, GoogleProvider

anthropic = AnthropicProvider(api_key="sk-ant-...")
google = GoogleProvider(api_key="AIza...")

# Same interface for all providers
for p in [anthropic, google]:
    r = await p.complete([{"role": "user", "content": "Hello"}])
    print(f"{p.name}: {r.content}")
```

## With Resilience

```python
provider = OpenAIProvider(
    api_key="sk-...",
    enable_circuit_breaker=True,
    enable_rate_limiter=True,
)
# Automatic fault tolerance and rate limiting
response = await provider.complete(messages)
```

## Next Steps

- [Providers](../guides/providers.md) — All 14 providers and their capabilities
- [Routing](../guides/routing.md) — Cost-aware Thompson sampling
- [Resilience](../guides/resilience.md) — Circuit breakers and rate limiters
- [Gateway](../guides/gateway.md) — OpenAI-compatible API server
