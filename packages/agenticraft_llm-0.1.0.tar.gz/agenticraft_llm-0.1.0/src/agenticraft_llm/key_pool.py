"""
API Key Pool Manager

Manages multiple API keys per provider with intelligent rotation, rate limit
tracking, health monitoring, and automatic failover.

Example:
    pool = KeyPoolManager(
        provider="openai",
        keys=["sk-key1", "sk-key2", "sk-key3"],
        strategy=RotationStrategy.ADAPTIVE,
    )

    key = await pool.acquire()
    try:
        await pool.record_success(key, tokens=1500)
    except RateLimitError:
        await pool.record_rate_limit(key, retry_after=60)
"""

from __future__ import annotations

import asyncio
import logging
import os
import random
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

from .types import KeyStatus, RotationStrategy

logger = logging.getLogger(__name__)


@dataclass
class KeyMetrics:
    """Metrics for a single API key."""

    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    rate_limit_hits: int = 0
    total_tokens: int = 0
    total_cost_usd: float = 0.0
    last_used_at: datetime | None = None
    last_success_at: datetime | None = None
    last_error_at: datetime | None = None
    last_rate_limit_at: datetime | None = None
    consecutive_errors: int = 0
    consecutive_successes: int = 0
    avg_latency_ms: float = 0.0
    _latency_samples: list[float] = field(default_factory=list)

    def record_request(
        self,
        success: bool,
        latency_ms: float = 0.0,
        tokens: int = 0,
        cost_usd: float = 0.0,
    ) -> None:
        self.total_requests += 1
        self.last_used_at = datetime.now(timezone.utc)

        if success:
            self.successful_requests += 1
            self.last_success_at = datetime.now(timezone.utc)
            self.consecutive_successes += 1
            self.consecutive_errors = 0
            self.total_tokens += tokens
            self.total_cost_usd += cost_usd
        else:
            self.failed_requests += 1
            self.last_error_at = datetime.now(timezone.utc)
            self.consecutive_errors += 1
            self.consecutive_successes = 0

        if latency_ms > 0:
            self._latency_samples.append(latency_ms)
            if len(self._latency_samples) > 100:
                self._latency_samples = self._latency_samples[-100:]
            self.avg_latency_ms = sum(self._latency_samples) / len(self._latency_samples)

    def record_rate_limit(self) -> None:
        self.rate_limit_hits += 1
        self.last_rate_limit_at = datetime.now(timezone.utc)
        self.consecutive_errors += 1
        self.consecutive_successes = 0

    @property
    def success_rate(self) -> float:
        if self.total_requests == 0:
            return 1.0
        return self.successful_requests / self.total_requests

    @property
    def health_score(self) -> float:
        score = 0.0
        score += self.success_rate * 0.4

        error_penalty = min(1.0, self.consecutive_errors * 0.2)
        score += (1.0 - error_penalty) * 0.3

        if self.last_rate_limit_at:
            since_limit = (datetime.now(timezone.utc) - self.last_rate_limit_at).total_seconds()
            if since_limit < 60:
                score += 0.0
            elif since_limit < 300:
                score += 0.1
            else:
                score += 0.2
        else:
            score += 0.2

        if self.avg_latency_ms > 0:
            latency_score = max(0, 1.0 - (self.avg_latency_ms - 1000) / 4000)
            score += latency_score * 0.1
        else:
            score += 0.1

        return min(1.0, max(0.0, score))

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_requests": self.total_requests,
            "successful_requests": self.successful_requests,
            "failed_requests": self.failed_requests,
            "rate_limit_hits": self.rate_limit_hits,
            "total_tokens": self.total_tokens,
            "total_cost_usd": self.total_cost_usd,
            "success_rate": self.success_rate,
            "health_score": self.health_score,
            "avg_latency_ms": self.avg_latency_ms,
            "consecutive_errors": self.consecutive_errors,
            "last_used_at": self.last_used_at.isoformat() if self.last_used_at else None,
        }


@dataclass
class KeyState:
    """Complete state for a single API key."""

    key: str
    key_id: str
    status: KeyStatus = KeyStatus.ACTIVE
    metrics: KeyMetrics = field(default_factory=KeyMetrics)
    weight: float = 1.0
    cooldown_until: datetime | None = None
    rate_limit_until: datetime | None = None
    daily_limit: int | None = None
    daily_requests: int = 0
    daily_reset_date: str = ""
    tags: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.key_id:
            self.key_id = f"...{self.key[-4:]}" if len(self.key) > 4 else self.key

    def is_available(self) -> bool:
        if self.status in (KeyStatus.DISABLED, KeyStatus.EXHAUSTED):
            return False

        now = datetime.now(timezone.utc)

        if self.cooldown_until and now < self.cooldown_until:
            return False
        if self.rate_limit_until and now < self.rate_limit_until:
            return False

        if self.daily_limit:
            today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
            if self.daily_reset_date != today:
                self.daily_requests = 0
                self.daily_reset_date = today
            if self.daily_requests >= self.daily_limit:
                return False

        return True

    def set_rate_limited(self, retry_after: float = 60.0) -> None:
        self.status = KeyStatus.RATE_LIMITED
        self.rate_limit_until = datetime.now(timezone.utc) + timedelta(seconds=retry_after)
        self.metrics.record_rate_limit()
        logger.warning(f"Key {self.key_id} rate limited for {retry_after}s")

    def set_cooldown(self, duration: float = 30.0) -> None:
        self.status = KeyStatus.COOLING_DOWN
        self.cooldown_until = datetime.now(timezone.utc) + timedelta(seconds=duration)
        logger.info(f"Key {self.key_id} in cooldown for {duration}s")

    def clear_cooldown(self) -> None:
        now = datetime.now(timezone.utc)
        if self.cooldown_until and now >= self.cooldown_until:
            self.cooldown_until = None
        if self.rate_limit_until and now >= self.rate_limit_until:
            self.rate_limit_until = None
        if self.status in (KeyStatus.COOLING_DOWN, KeyStatus.RATE_LIMITED):
            self.status = KeyStatus.ACTIVE


class KeyPoolManager:
    """
    Manages a pool of API keys with intelligent rotation.

    Example:
        pool = KeyPoolManager(
            provider="openai",
            keys=["sk-key1", "sk-key2"],
            strategy=RotationStrategy.ADAPTIVE,
        )
        key = await pool.acquire()
        await pool.record_success(key, tokens=1500)
    """

    def __init__(
        self,
        provider: str,
        keys: list[str] | None = None,
        strategy: RotationStrategy = RotationStrategy.ADAPTIVE,
        cooldown_duration: float = 30.0,
        max_consecutive_errors: int = 3,
    ) -> None:
        self.provider = provider
        self.strategy = strategy
        self.cooldown_duration = cooldown_duration
        self.max_consecutive_errors = max_consecutive_errors

        self._keys: dict[str, KeyState] = {}
        self._key_order: list[str] = []
        self._current_index = 0
        self._lock = asyncio.Lock()

        if keys:
            for key in keys:
                self.add_key(key)

    @classmethod
    def from_env(
        cls,
        provider: str,
        strategy: RotationStrategy = RotationStrategy.ADAPTIVE,
        **kwargs: Any,
    ) -> KeyPoolManager:
        """Create pool from environment variable."""
        env_prefix = provider.upper()

        keys_env = os.environ.get(f"{env_prefix}_API_KEYS")
        if keys_env:
            keys = [k.strip() for k in keys_env.split(",") if k.strip()]
            return cls(provider=provider, keys=keys, strategy=strategy, **kwargs)

        single_key = os.environ.get(f"{env_prefix}_API_KEY")
        if single_key:
            return cls(provider=provider, keys=[single_key], strategy=strategy, **kwargs)

        return cls(provider=provider, keys=[], strategy=strategy, **kwargs)

    def add_key(
        self,
        key: str,
        weight: float = 1.0,
        daily_limit: int | None = None,
        tags: list[str] | None = None,
    ) -> None:
        if key in self._keys:
            return

        state = KeyState(
            key=key,
            key_id=f"...{key[-4:]}" if len(key) > 4 else key,
            weight=weight,
            daily_limit=daily_limit,
            tags=tags or [],
        )
        self._keys[key] = state
        self._key_order.append(key)

    def remove_key(self, key: str) -> bool:
        if key in self._keys:
            del self._keys[key]
            self._key_order.remove(key)
            return True
        return False

    async def acquire(self, tags: list[str] | None = None) -> str:
        """Acquire an available key from the pool."""
        async with self._lock:
            self._clear_expired_cooldowns()

            available = self._get_available_keys(tags)
            if not available:
                raise RuntimeError(
                    f"No available API keys for {self.provider}. "
                    f"Total keys: {len(self._keys)}, all in cooldown or rate limited."
                )

            key = self._select_key(available)
            self._keys[key].daily_requests += 1
            return key

    async def record_success(
        self, key: str, latency_ms: float = 0.0, tokens: int = 0, cost_usd: float = 0.0
    ) -> None:
        async with self._lock:
            if key not in self._keys:
                return
            state = self._keys[key]
            state.metrics.record_request(
                success=True, latency_ms=latency_ms, tokens=tokens, cost_usd=cost_usd
            )
            state.clear_cooldown()

    async def record_error(self, key: str, error: str = "") -> None:
        async with self._lock:
            if key not in self._keys:
                return
            state = self._keys[key]
            state.metrics.record_request(success=False)
            if state.metrics.consecutive_errors >= self.max_consecutive_errors:
                state.set_cooldown(self.cooldown_duration)

    async def record_rate_limit(self, key: str, retry_after: float = 60.0) -> None:
        async with self._lock:
            if key not in self._keys:
                return
            self._keys[key].set_rate_limited(retry_after)

    async def record_quota_exhausted(self, key: str) -> None:
        async with self._lock:
            if key not in self._keys:
                return
            self._keys[key].status = KeyStatus.EXHAUSTED

    def _get_available_keys(self, tags: list[str] | None = None) -> list[str]:
        available = []
        for key, state in self._keys.items():
            if not state.is_available():
                continue
            if tags and not any(t in state.tags for t in tags):
                continue
            available.append(key)
        return available

    def _select_key(self, available: list[str]) -> str:
        if len(available) == 1:
            return available[0]

        if self.strategy == RotationStrategy.ROUND_ROBIN:
            return self._select_round_robin(available)
        elif self.strategy == RotationStrategy.LEAST_USED:
            return self._select_least_used(available)
        elif self.strategy == RotationStrategy.RANDOM:
            return random.choice(available)
        elif self.strategy == RotationStrategy.WEIGHTED:
            return self._select_weighted(available)
        elif self.strategy == RotationStrategy.ADAPTIVE:
            return self._select_adaptive(available)
        return available[0]

    def _select_round_robin(self, available: list[str]) -> str:
        for _ in range(len(self._key_order)):
            self._current_index = (self._current_index + 1) % len(self._key_order)
            key = self._key_order[self._current_index]
            if key in available:
                return key
        return available[0]

    def _select_least_used(self, available: list[str]) -> str:
        return min(available, key=lambda k: self._keys[k].metrics.total_requests)

    def _select_weighted(self, available: list[str]) -> str:
        weights = [self._keys[k].weight for k in available]
        total = sum(weights)
        if total == 0:
            return random.choice(available)

        r = random.random() * total
        cumulative = 0.0
        for key, weight in zip(available, weights, strict=False):
            cumulative += weight
            if r <= cumulative:
                return key
        return available[-1]

    def _select_adaptive(self, available: list[str]) -> str:
        now = datetime.now(timezone.utc)
        scores: list[tuple[str, float]] = []

        for key in available:
            state = self._keys[key]
            score = state.metrics.health_score * state.weight

            if state.metrics.last_used_at:
                since_used = (now - state.metrics.last_used_at).total_seconds()
                score += min(0.2, since_used / 300)

            usage_ratio = state.metrics.total_requests / max(1, self._get_total_requests())
            if usage_ratio > 0.5:
                score *= 0.8

            scores.append((key, score))

        total_score = sum(s for _, s in scores)
        if total_score == 0:
            return random.choice(available)

        r = random.random() * total_score
        cumulative = 0.0
        for key, score in scores:
            cumulative += score
            if r <= cumulative:
                return key
        return available[-1]

    def _clear_expired_cooldowns(self) -> None:
        for state in self._keys.values():
            state.clear_cooldown()

    def _get_total_requests(self) -> int:
        return sum(s.metrics.total_requests for s in self._keys.values())

    def get_status(self) -> dict[str, Any]:
        active = sum(1 for s in self._keys.values() if s.status == KeyStatus.ACTIVE)
        rate_limited = sum(1 for s in self._keys.values() if s.status == KeyStatus.RATE_LIMITED)
        cooling = sum(1 for s in self._keys.values() if s.status == KeyStatus.COOLING_DOWN)
        disabled = sum(1 for s in self._keys.values() if s.status == KeyStatus.DISABLED)

        return {
            "provider": self.provider,
            "strategy": self.strategy.value,
            "total_keys": len(self._keys),
            "active_keys": active,
            "rate_limited_keys": rate_limited,
            "cooling_down_keys": cooling,
            "disabled_keys": disabled,
            "total_requests": self._get_total_requests(),
            "total_tokens": sum(s.metrics.total_tokens for s in self._keys.values()),
            "total_cost_usd": sum(s.metrics.total_cost_usd for s in self._keys.values()),
            "average_health_score": (
                sum(s.metrics.health_score for s in self._keys.values()) / len(self._keys)
                if self._keys
                else 0
            ),
            "keys": {
                state.key_id: {
                    "status": state.status.value,
                    "weight": state.weight,
                    "metrics": state.metrics.to_dict(),
                    "available": state.is_available(),
                }
                for state in self._keys.values()
            },
        }

    def get_available_count(self) -> int:
        self._clear_expired_cooldowns()
        return len(self._get_available_keys())

    def __len__(self) -> int:
        return len(self._keys)

    def __bool__(self) -> bool:
        return len(self._keys) > 0


__all__ = [
    "KeyPoolManager",
    "KeyState",
    "KeyMetrics",
]
