"""
LLM Types

Request/Response models, enumerations, and value objects.
Pure data structures with no external dependencies.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

# ============================================================================
# Enumerations
# ============================================================================


class ProviderType(Enum):
    """Supported LLM provider types."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    AZURE = "azure_openai"
    BEDROCK = "bedrock"
    FIREWORKS = "fireworks"
    CEREBRAS = "cerebras"
    COHERE = "cohere"
    DEEPSEEK = "deepseek"
    XAI = "xai"
    OLLAMA = "ollama"
    OPENROUTER = "openrouter"
    PERPLEXITY = "perplexity"
    NEBIUS = "nebius"


class LLMCapabilityType(Enum):
    """Standard capability types for LLM providers."""

    # Core capabilities
    COMPLETION = "completion"
    STREAMING = "streaming"
    FUNCTION_CALLING = "function_calling"
    VISION = "vision"
    EMBEDDINGS = "embeddings"
    JSON_MODE = "json_mode"
    JSON_SCHEMA = "json_schema"
    SYSTEM_PROMPT = "system_prompt"
    MULTI_TURN = "multi_turn"
    TOOL_USE = "tool_use"
    CODE_GENERATION = "code_generation"

    # Reasoning capabilities
    REASONING = "reasoning"
    EXTENDED_THINKING = "extended_thinking"

    # Cost optimization capabilities
    PROMPT_CACHING = "prompt_caching"
    CONTEXT_CACHING = "context_caching"
    BATCH_API = "batch_api"

    # Specialized capabilities
    CODE_EXECUTION = "code_execution"
    COMPUTER_USE = "computer_use"
    RAG_CITATIONS = "rag_citations"
    RERANKING = "reranking"
    GUARDRAILS = "guardrails"
    SEARCH_GROUNDING = "search_grounding"


class ModelTier(Enum):
    """Model capability tiers for routing decisions."""

    BASIC = "basic"
    STANDARD = "standard"
    ADVANCED = "advanced"
    PREMIUM = "premium"


class RoutingStrategy(Enum):
    """Provider routing/selection strategies."""

    COST = "cost"
    LATENCY = "latency"
    RELIABILITY = "reliability"
    QUALITY = "quality"
    ROUND_ROBIN = "round_robin"
    RANDOM = "random"


class KeyStatus(Enum):
    """Status of an individual API key."""

    ACTIVE = "active"
    RATE_LIMITED = "rate_limited"
    COOLING_DOWN = "cooling_down"
    DISABLED = "disabled"
    EXHAUSTED = "exhausted"


class RotationStrategy(Enum):
    """Key rotation strategies."""

    ROUND_ROBIN = "round_robin"
    LEAST_USED = "least_used"
    RANDOM = "random"
    WEIGHTED = "weighted"
    ADAPTIVE = "adaptive"


# ============================================================================
# Value Objects
# ============================================================================


@dataclass(frozen=True)
class TokenUsage:
    """Token usage statistics for a request."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost_usd: float | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TokenUsage:
        return cls(
            prompt_tokens=data.get("prompt_tokens", 0),
            completion_tokens=data.get("completion_tokens", 0),
            total_tokens=data.get("total_tokens", 0),
            cost_usd=data.get("cost_usd"),
        )


# ============================================================================
# Request/Response Models
# ============================================================================


@dataclass
class LLMRequest:
    """Canonical LLM request model."""

    prompt: str
    model: str | None = None
    provider: str | None = None
    temperature: float = 0.7
    max_tokens: int | None = None
    top_p: float | None = None
    stop: list[str] | None = None
    stream: bool = False
    tenant_id: str | None = None
    tools: list[dict[str, Any]] | None = None
    tool_choice: str | dict[str, Any] | None = None
    system_prompt: str | None = None
    messages: list[dict[str, Any]] | None = None
    request_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMResponse:
    """Canonical LLM response model."""

    content: str
    model: str
    provider: str
    usage: TokenUsage | None = None
    finish_reason: str | None = None
    request_id: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    latency_ms: float | None = None
    tool_calls: list[dict[str, Any]] | None = None
    raw_response: dict[str, Any] | None = None

    @property
    def has_tool_calls(self) -> bool:
        return bool(self.tool_calls)


@dataclass
class StreamChunk:
    """Streaming response chunk."""

    content: str
    model: str
    provider: str
    chunk_index: int = 0
    is_final: bool = False
    finish_reason: str | None = None
    tool_call_delta: dict[str, Any] | None = None


# ============================================================================
# Metrics Models
# ============================================================================


@dataclass
class ProviderMetrics:
    """Provider performance metrics."""

    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    total_latency_ms: float = 0.0
    last_request_time: datetime | None = None
    total_tokens: int = 0
    total_cost_usd: float = 0.0
    error_counts: dict[str, int] = field(default_factory=dict)
    quality_scores: list[float] = field(default_factory=list)

    @property
    def success_rate(self) -> float:
        if self.total_requests == 0:
            return 0.0
        return self.successful_requests / self.total_requests

    @property
    def average_latency_ms(self) -> float:
        if self.successful_requests == 0:
            return 0.0
        return self.total_latency_ms / self.successful_requests

    @property
    def average_quality(self) -> float:
        if not self.quality_scores:
            return 0.0
        return sum(self.quality_scores) / len(self.quality_scores)

    @property
    def cost_per_request(self) -> float:
        if self.successful_requests == 0:
            return 0.0
        return self.total_cost_usd / self.successful_requests

    def record_request(
        self,
        success: bool,
        latency_ms: float,
        tokens: int = 0,
        cost_usd: float = 0.0,
        error_type: str | None = None,
    ) -> None:
        self.total_requests += 1
        self.last_request_time = datetime.now(timezone.utc)

        if success:
            self.successful_requests += 1
            self.total_latency_ms += latency_ms
            self.total_tokens += tokens
            self.total_cost_usd += cost_usd
        else:
            self.failed_requests += 1
            if error_type:
                self.error_counts[error_type] = self.error_counts.get(error_type, 0) + 1

    def record_quality(self, score: float) -> None:
        self.quality_scores.append(score)
        if len(self.quality_scores) > 100:
            self.quality_scores = self.quality_scores[-100:]


@dataclass
class HealthStatus:
    """Provider health status."""

    healthy: bool = True
    message: str = ""


# ============================================================================
# Cross-package Re-exports (when agenticraft-types is installed)
# ============================================================================

try:
    from agenticraft_types import (  # noqa: F401
        CircuitBreakerLike,
        CircuitBreakerState,
        CompletionRequest,
        CompletionResponse,
        FailureType,
        KeyPoolLike,
        Message,
        MessageRole,
        Provider,
        ProviderConfig,
        ProviderName,
        RetryConfig,
        Router,
        StreamingProvider,
        Usage,
    )

    _HAS_SHARED_TYPES = True
except ImportError:
    _HAS_SHARED_TYPES = False

__all__ = [
    "ProviderType",
    "LLMCapabilityType",
    "ModelTier",
    "RoutingStrategy",
    "KeyStatus",
    "RotationStrategy",
    "TokenUsage",
    "LLMRequest",
    "LLMResponse",
    "StreamChunk",
    "ProviderMetrics",
    "HealthStatus",
]

# Extend exports when agenticraft-types is available
if _HAS_SHARED_TYPES:
    __all__ += [
        # Shared enums
        "ProviderName",
        "FailureType",
        "MessageRole",
        "CircuitBreakerState",
        # Shared models
        "CompletionRequest",
        "CompletionResponse",
        "Message",
        "Usage",
        "ProviderConfig",
        # Shared protocols
        "Provider",
        "StreamingProvider",
        "Router",
        "CircuitBreakerLike",
        "KeyPoolLike",
        # Shared config
        "RetryConfig",
    ]
