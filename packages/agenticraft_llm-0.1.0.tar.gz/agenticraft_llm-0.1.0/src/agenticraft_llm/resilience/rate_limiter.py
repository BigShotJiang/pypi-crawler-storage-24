"""
Token Bucket Rate Limiter for LLM Providers

Standalone rate limiter with provider-specific presets.
No mesh dependencies.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass


@dataclass
class RateLimitConfig:
    """Configuration for a rate limiter."""

    max_calls: int
    time_window: float
    burst_size: int | None = None

    def __post_init__(self):
        if self.burst_size is None:
            self.burst_size = self.max_calls


class TokenBucketRateLimiter:
    """
    Token bucket rate limiter for LLM provider operations.

    Allows up to `max_calls` operations per `time_window` seconds,
    with optional burst capacity for handling traffic spikes.

    Thread-safe using asyncio.Lock.

    Example:
        limiter = TokenBucketRateLimiter(RateLimitConfig(max_calls=100, time_window=60.0))
        if await limiter.acquire():
            await provider.complete(messages, model)
    """

    def __init__(self, config: RateLimitConfig):
        self.config = config
        self.tokens = float(config.burst_size)  # type: ignore[arg-type]
        self.max_tokens = float(config.burst_size)  # type: ignore[arg-type]
        self.refill_rate = config.max_calls / config.time_window
        self.last_refill = time.monotonic()
        self._lock = asyncio.Lock()

        # Metrics
        self._total_acquired = 0
        self._total_rejected = 0

    async def acquire(self, tokens: int = 1, timeout: float | None = None) -> bool:
        """
        Acquire tokens from the bucket.

        Args:
            tokens: Number of tokens to acquire (default: 1)
            timeout: Maximum time to wait for tokens (None = fail immediately)

        Returns:
            True if tokens acquired, False if rate limited
        """
        start_time = time.monotonic()

        while True:
            async with self._lock:
                now = time.monotonic()
                elapsed = now - self.last_refill

                new_tokens = elapsed * self.refill_rate
                self.tokens = min(self.max_tokens, self.tokens + new_tokens)
                self.last_refill = now

                if self.tokens >= tokens:
                    self.tokens -= tokens
                    self._total_acquired += 1
                    return True

                if timeout is None:
                    self._total_rejected += 1
                    return False

                elapsed_wait = time.monotonic() - start_time
                if elapsed_wait >= timeout:
                    self._total_rejected += 1
                    return False

            await asyncio.sleep(0.01)

    def get_available_tokens(self) -> float:
        """Get current available tokens (non-blocking)."""
        now = time.monotonic()
        elapsed = now - self.last_refill
        new_tokens = elapsed * self.refill_rate
        return min(self.max_tokens, self.tokens + new_tokens)

    def get_metrics(self) -> dict:
        """Get rate limiter metrics."""
        return {
            "max_tokens": self.max_tokens,
            "available_tokens": self.get_available_tokens(),
            "refill_rate": self.refill_rate,
            "time_window": self.config.time_window,
            "max_calls": self.config.max_calls,
            "total_acquired": self._total_acquired,
            "total_rejected": self._total_rejected,
        }


# Provider-specific presets
PROVIDER_RATE_LIMITS: dict[str, RateLimitConfig] = {
    "openai": RateLimitConfig(max_calls=500, time_window=60.0),
    "anthropic": RateLimitConfig(max_calls=1000, time_window=60.0),
    "google": RateLimitConfig(max_calls=360, time_window=60.0),
    "azure_openai": RateLimitConfig(max_calls=300, time_window=60.0),
    "groq": RateLimitConfig(max_calls=30, time_window=60.0),
    "fireworks": RateLimitConfig(max_calls=600, time_window=60.0),
    "cerebras": RateLimitConfig(max_calls=30, time_window=60.0),
    "ollama": RateLimitConfig(max_calls=100, time_window=60.0),
    "deepseek": RateLimitConfig(max_calls=60, time_window=60.0),
    "cohere": RateLimitConfig(max_calls=100, time_window=60.0),
    "bedrock": RateLimitConfig(max_calls=100, time_window=60.0),
    "xai": RateLimitConfig(max_calls=60, time_window=60.0),
    "openrouter": RateLimitConfig(max_calls=200, time_window=60.0),
    "perplexity": RateLimitConfig(max_calls=50, time_window=60.0),
    "nebius": RateLimitConfig(max_calls=100, time_window=60.0),
}


__all__ = [
    "TokenBucketRateLimiter",
    "RateLimitConfig",
    "PROVIDER_RATE_LIMITS",
]
