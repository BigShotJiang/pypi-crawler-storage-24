"""
Circuit Breaker for LLM Providers

Standalone circuit breaker with state machine (CLOSED/OPEN/HALF_OPEN),
failure type classification, and provider-specific presets.
No mesh dependencies.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class CircuitBreakerState(Enum):
    """Circuit breaker states."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class FailureType(Enum):
    """Classification of failure types."""

    RATE_LIMIT = "rate_limit"
    AUTH = "auth"
    TIMEOUT = "timeout"
    CONNECTION = "connection"
    SERVICE_ERROR = "service_error"
    UNKNOWN = "unknown"


@dataclass
class CircuitBreakerConfig:
    """Configuration for a circuit breaker."""

    failure_threshold: int = 5
    recovery_timeout: float = 60.0
    success_threshold: int = 2
    monitoring_window: float = 60.0


class CircuitBreaker:
    """
    Circuit breaker for LLM provider fault tolerance.

    State machine: CLOSED -> OPEN (after threshold) -> HALF_OPEN (after timeout) -> CLOSED

    Example:
        breaker = CircuitBreaker(name="openai")

        # Option 1: Using call()
        result = await breaker.call(provider.complete, messages, model)

        # Option 2: Manual tracking
        if not breaker.is_open:
            try:
                result = await provider.complete(messages, model)
                breaker.record_success()
            except Exception:
                breaker.record_failure()
    """

    def __init__(
        self,
        name: str = "default",
        config: CircuitBreakerConfig | None = None,
    ):
        self.name = name
        self.config = config or CircuitBreakerConfig()

        self._state = CircuitBreakerState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time: float = 0.0
        self._lock = asyncio.Lock()

        # Metrics
        self._total_calls = 0
        self._total_successes = 0
        self._total_failures = 0
        self._state_changes: list[tuple[str, str, float]] = []

    @property
    def state(self) -> CircuitBreakerState:
        """Current circuit breaker state, with automatic OPEN -> HALF_OPEN transition."""
        if self._state == CircuitBreakerState.OPEN:
            if time.monotonic() - self._last_failure_time >= self.config.recovery_timeout:
                self._transition(CircuitBreakerState.HALF_OPEN)
        return self._state

    @property
    def is_open(self) -> bool:
        return self.state == CircuitBreakerState.OPEN

    @property
    def is_closed(self) -> bool:
        return self.state == CircuitBreakerState.CLOSED

    @property
    def is_half_open(self) -> bool:
        return self.state == CircuitBreakerState.HALF_OPEN

    def record_success(self) -> None:
        """Record a successful call."""
        self._total_calls += 1
        self._total_successes += 1

        if self._state == CircuitBreakerState.HALF_OPEN:
            self._success_count += 1
            if self._success_count >= self.config.success_threshold:
                self._transition(CircuitBreakerState.CLOSED)
                self._failure_count = 0
        elif self._state == CircuitBreakerState.CLOSED:
            self._failure_count = 0

    def record_failure(self, error: Exception | None = None) -> None:
        """Record a failed call."""
        self._total_calls += 1
        self._total_failures += 1
        self._failure_count += 1
        self._last_failure_time = time.monotonic()

        if self._state == CircuitBreakerState.HALF_OPEN:
            self._transition(CircuitBreakerState.OPEN)
        elif self._state == CircuitBreakerState.CLOSED:
            if self._failure_count >= self.config.failure_threshold:
                self._transition(CircuitBreakerState.OPEN)

    async def call(self, func, *args, **kwargs):
        """Execute function with circuit breaker protection."""
        async with self._lock:
            current_state = self.state
            if current_state == CircuitBreakerState.OPEN:
                raise CircuitOpenError(f"Circuit breaker '{self.name}' is OPEN", provider=self.name)

        try:
            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)
            self.record_success()
            return result
        except Exception as e:
            self.record_failure(e)
            raise

    def reset(self) -> None:
        """Reset circuit breaker to closed state."""
        self._transition(CircuitBreakerState.CLOSED)
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time = 0.0

    def get_state(self) -> dict:
        """Get current circuit breaker state with metrics."""
        return {
            "name": self.name,
            "state": self.state.value,
            "failure_count": self._failure_count,
            "success_count": self._success_count,
            "total_calls": self._total_calls,
            "total_successes": self._total_successes,
            "total_failures": self._total_failures,
            "last_failure_time": self._last_failure_time,
            "config": {
                "failure_threshold": self.config.failure_threshold,
                "recovery_timeout": self.config.recovery_timeout,
                "success_threshold": self.config.success_threshold,
            },
        }

    def _transition(self, new_state: CircuitBreakerState) -> None:
        """Transition to a new state."""
        old_state = self._state
        if old_state == new_state:
            return
        self._state = new_state
        self._success_count = 0
        self._state_changes.append((old_state.value, new_state.value, time.monotonic()))
        logger.info(f"Circuit breaker '{self.name}': {old_state.value} -> {new_state.value}")

    @classmethod
    def classify_error(cls, error: Exception) -> FailureType:
        """Classify an error into a failure type."""
        if isinstance(error, ConnectionError):
            return FailureType.CONNECTION
        if isinstance(error, TimeoutError):
            return FailureType.TIMEOUT
        error_str = str(error).lower()
        if "rate" in error_str and "limit" in error_str:
            return FailureType.RATE_LIMIT
        if "auth" in error_str or "api key" in error_str:
            return FailureType.AUTH
        if hasattr(error, "status_code") and error.status_code == 429:
            return FailureType.RATE_LIMIT
        return FailureType.SERVICE_ERROR


class CircuitOpenError(Exception):
    """Raised when circuit breaker is open."""

    def __init__(self, message: str, *, provider: str | None = None):
        super().__init__(message)
        self.provider = provider


# Provider-specific presets
PROVIDER_DEFAULTS: dict[str, CircuitBreakerConfig] = {
    "openai": CircuitBreakerConfig(failure_threshold=5, recovery_timeout=60.0),
    "anthropic": CircuitBreakerConfig(failure_threshold=5, recovery_timeout=60.0),
    "google": CircuitBreakerConfig(failure_threshold=5, recovery_timeout=60.0),
    "azure_openai": CircuitBreakerConfig(failure_threshold=5, recovery_timeout=60.0),
    "groq": CircuitBreakerConfig(failure_threshold=3, recovery_timeout=45.0),
    "fireworks": CircuitBreakerConfig(failure_threshold=4, recovery_timeout=45.0),
    "cerebras": CircuitBreakerConfig(failure_threshold=3, recovery_timeout=30.0),
    "ollama": CircuitBreakerConfig(failure_threshold=2, recovery_timeout=30.0),
    "deepseek": CircuitBreakerConfig(failure_threshold=4, recovery_timeout=45.0),
    "cohere": CircuitBreakerConfig(failure_threshold=4, recovery_timeout=45.0),
    "bedrock": CircuitBreakerConfig(failure_threshold=5, recovery_timeout=60.0),
    "xai": CircuitBreakerConfig(failure_threshold=4, recovery_timeout=45.0),
    "openrouter": CircuitBreakerConfig(failure_threshold=4, recovery_timeout=45.0),
    "perplexity": CircuitBreakerConfig(failure_threshold=4, recovery_timeout=45.0),
    "nebius": CircuitBreakerConfig(failure_threshold=4, recovery_timeout=45.0),
}


__all__ = [
    "CircuitBreaker",
    "CircuitBreakerConfig",
    "CircuitBreakerState",
    "CircuitOpenError",
    "FailureType",
    "PROVIDER_DEFAULTS",
]
