"""
agenticraft-llm: Production-grade LLM provider abstraction

14 providers, key rotation, cost-aware routing — zero platform dependencies.

Example:
    from agenticraft_llm import OpenAIProvider

    provider = OpenAIProvider(api_key="sk-...")
    await provider.initialize()
    response = await provider.complete([{"role": "user", "content": "Hello"}])
    print(response["content"])

    # Cost-aware routing
    from agenticraft_llm import CostAwareRouter

    router = CostAwareRouter()
    await router.initialize()
    best = await router.select_provider(
        providers=["openai", "anthropic", "google"],
        estimated_tokens=1000,
        quality_threshold=0.8,
    )

    # Key rotation
    from agenticraft_llm import KeyPoolManager

    pool = KeyPoolManager(provider="openai", keys=["sk-1", "sk-2", "sk-3"])
    key = await pool.acquire()
"""

from __future__ import annotations

from ._version import __version__

# Core
from .base import BaseLLMProvider
from .config import LLMProviderConfig
from .exceptions import (
    LLMAuthenticationError,
    LLMConfigError,
    LLMError,
    LLMModelNotFoundError,
    LLMNoProvidersAvailableError,
    LLMOrchestrationError,
    LLMProviderError,
    LLMQuotaExceededError,
    LLMRateLimitError,
    LLMRequestError,
    LLMTimeoutError,
)
from .key_pool import KeyPoolManager

# Lazy provider imports — access via providers subpackage or registry
from .providers import (
    AnthropicProvider,
    AzureOpenAIProvider,
    BedrockProvider,
    CerebrasProvider,
    CohereProvider,
    DeepSeekProvider,
    FireworksProvider,
    GoogleProvider,
    NebiusProvider,
    OllamaProvider,
    OpenAIProvider,
    OpenRouterProvider,
    PerplexityProvider,
    XAIProvider,
)
from .registry import get_provider, list_providers, register
from .resilience import (
    CircuitBreaker,
    CircuitBreakerConfig,
    TokenBucketRateLimiter,
)
from .resilience import CircuitBreakerState as CBState  # noqa: F401
from .resilience import RateLimitConfig as RLConfig  # noqa: F401
from .router import (
    CostAwareRouter,
    CostRouterConfig,
    CostRoutingDecision,
    ProviderCostProfile,
    get_cost_aware_router,
    reset_router,
)
from .types import (
    HealthStatus,
    KeyStatus,
    LLMCapabilityType,
    LLMRequest,
    LLMResponse,
    ModelTier,
    ProviderMetrics,
    ProviderType,
    RotationStrategy,
    RoutingStrategy,
    StreamChunk,
    TokenUsage,
)

__all__ = [
    # Version
    "__version__",
    # Base
    "BaseLLMProvider",
    "LLMProviderConfig",
    # Key pool
    "KeyPoolManager",
    # Router
    "CostAwareRouter",
    "CostRouterConfig",
    "CostRoutingDecision",
    "ProviderCostProfile",
    "get_cost_aware_router",
    "reset_router",
    # Registry
    "get_provider",
    "list_providers",
    "register",
    # Types
    "HealthStatus",
    "KeyStatus",
    "LLMCapabilityType",
    "LLMRequest",
    "LLMResponse",
    "ModelTier",
    "ProviderMetrics",
    "ProviderType",
    "RotationStrategy",
    "RoutingStrategy",
    "StreamChunk",
    "TokenUsage",
    # Exceptions
    "LLMError",
    "LLMProviderError",
    "LLMAuthenticationError",
    "LLMRateLimitError",
    "LLMTimeoutError",
    "LLMModelNotFoundError",
    "LLMRequestError",
    "LLMConfigError",
    "LLMQuotaExceededError",
    "LLMOrchestrationError",
    "LLMNoProvidersAvailableError",
    # Resilience
    "CircuitBreaker",
    "CircuitBreakerConfig",
    "TokenBucketRateLimiter",
    # Providers
    "OpenAIProvider",
    "AnthropicProvider",
    "GoogleProvider",
    "AzureOpenAIProvider",
    "BedrockProvider",
    "FireworksProvider",
    "CerebrasProvider",
    "CohereProvider",
    "DeepSeekProvider",
    "XAIProvider",
    "OllamaProvider",
    "OpenRouterProvider",
    "PerplexityProvider",
    "NebiusProvider",
]
