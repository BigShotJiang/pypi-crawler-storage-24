"""
LLM Exception Hierarchy

Custom exceptions for the LLM service with clear categorization.
When agenticraft-types is installed, LLMError subclasses AgentiCraftError
for cross-package exception handling.
"""

from typing import Any

# Conditionally subclass AgentiCraftError when agenticraft-types is available
try:
    from agenticraft_types import AgentiCraftError as _BaseError
except ImportError:
    _BaseError = Exception  # type: ignore[assignment, misc]


class LLMError(_BaseError):
    """Base exception for all LLM errors."""

    def __init__(
        self,
        message: str,
        *,
        provider: str | None = None,
        model: str | None = None,
        details: dict[str, Any] | None = None,
    ):
        if _BaseError is Exception:
            super().__init__(message)
            self.message = message
            self.details = details or {}
        else:
            super().__init__(message, details=details)
        self.provider = provider
        self.model = model

    def __str__(self) -> str:
        parts = [self.message]
        if self.provider:
            parts.append(f"provider={self.provider}")
        if self.model:
            parts.append(f"model={self.model}")
        return " | ".join(parts)


class LLMProviderError(LLMError):
    """Error from an LLM provider."""

    def __init__(
        self,
        message: str,
        *,
        provider: str | None = None,
        model: str | None = None,
        status_code: int | None = None,
        details: dict[str, Any] | None = None,
    ):
        super().__init__(message, provider=provider, model=model, details=details)
        self.status_code = status_code


class LLMAuthenticationError(LLMProviderError):
    """Authentication error — API key invalid, expired, or missing."""

    pass


class LLMRateLimitError(LLMProviderError):
    """Rate limit exceeded."""

    def __init__(
        self,
        message: str,
        *,
        provider: str | None = None,
        model: str | None = None,
        retry_after: float | None = None,
        details: dict[str, Any] | None = None,
    ):
        super().__init__(message, provider=provider, model=model, details=details)
        self.retry_after = retry_after


class LLMTimeoutError(LLMProviderError):
    """Request timeout."""

    def __init__(
        self,
        message: str,
        *,
        provider: str | None = None,
        model: str | None = None,
        timeout_seconds: float | None = None,
        details: dict[str, Any] | None = None,
    ):
        super().__init__(message, provider=provider, model=model, details=details)
        self.timeout_seconds = timeout_seconds


class LLMModelNotFoundError(LLMProviderError):
    """Model not found or unavailable."""

    def __init__(
        self,
        message: str,
        *,
        provider: str | None = None,
        model: str | None = None,
        available_models: list[str] | None = None,
        details: dict[str, Any] | None = None,
    ):
        super().__init__(message, provider=provider, model=model, details=details)
        self.available_models = available_models or []


class LLMRequestError(LLMError):
    """General request error."""

    pass


class LLMConfigError(LLMError):
    """Configuration error."""

    def __init__(
        self,
        message: str,
        *,
        field: str | None = None,
        value: Any = None,
        details: dict[str, Any] | None = None,
    ):
        super().__init__(message, details=details)
        self.field = field
        self.value = value


class LLMQuotaExceededError(LLMError):
    """Quota exceeded."""

    def __init__(
        self,
        message: str,
        *,
        tenant_id: str | None = None,
        resource: str | None = None,
        limit: int | None = None,
        current: int | None = None,
        details: dict[str, Any] | None = None,
    ):
        super().__init__(message, details=details)
        self.tenant_id = tenant_id
        self.resource = resource
        self.limit = limit
        self.current = current


class LLMOrchestrationError(LLMError):
    """Orchestration error — all providers failed."""

    def __init__(
        self,
        message: str,
        *,
        strategy: str | None = None,
        providers_tried: list[str] | None = None,
        errors: list[Exception] | None = None,
        details: dict[str, Any] | None = None,
    ):
        super().__init__(message, details=details)
        self.strategy = strategy
        self.providers_tried = providers_tried or []
        self.errors = errors or []


class LLMNoProvidersAvailableError(LLMOrchestrationError):
    """No providers available for the request."""

    pass


__all__ = [
    "LLMError",
    "LLMProviderError",
    "LLMAuthenticationError",
    "LLMRateLimitError",
    "LLMTimeoutError",
    "LLMModelNotFoundError",
    "LLMRequestError",
    "LLMConfigError",
    "LLMQuotaExceededError",
    "LLMOrchestrationError",
    "LLMNoProvidersAvailableError",
]
