"""
Cost-Aware Router for LLM Providers

Intelligent routing that selects the optimal LLM provider based on
cost, quality, latency, and budget constraints. Supports Thompson
sampling for explore-exploit optimization.

Example:
    router = CostAwareRouter()
    await router.initialize()

    provider = await router.select_provider(
        providers=["openai", "anthropic", "google"],
        estimated_tokens=1000,
        max_cost=0.10,
        quality_threshold=0.8,
    )
"""

from __future__ import annotations

import asyncio
import logging
import random
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ProviderCostProfile:
    """Cost and quality profile for a provider."""

    provider: str
    input_cost_per_1k: float
    output_cost_per_1k: float
    quality_score: float = 0.85
    latency_ms_p50: float = 500.0
    success_rate: float = 0.99
    last_updated: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    # Beta posterior parameters for Thompson sampling
    beta_alpha: float = 1.0
    beta_beta: float = 1.0

    @property
    def avg_cost_per_1k(self) -> float:
        return (self.input_cost_per_1k + self.output_cost_per_1k) / 2

    def estimate_cost(self, input_tokens: int, output_tokens: int) -> float:
        input_cost = (input_tokens / 1000) * self.input_cost_per_1k
        output_cost = (output_tokens / 1000) * self.output_cost_per_1k
        return input_cost + output_cost


@dataclass
class CostRoutingDecision:
    """Result of cost-aware routing decision."""

    selected_provider: str
    estimated_cost: float
    quality_score: float
    reason: str
    alternatives: list[dict[str, Any]] = field(default_factory=list)
    constraints_applied: list[str] = field(default_factory=list)


@dataclass
class CostRouterConfig:
    """Configuration for cost-aware router."""

    default_max_cost: float | None = None
    default_quality_threshold: float = 0.7
    default_latency_threshold_ms: float = 5000.0

    cost_weight: float = 0.5
    quality_weight: float = 0.35
    latency_weight: float = 0.15

    profile_cache_ttl_seconds: int = 300

    # Thompson sampling (Bayesian explore-exploit)
    explore_mode: bool = False

    fallback_provider: str | None = None
    strict_budget: bool = False


DEFAULT_PROVIDER_PROFILES: dict[str, ProviderCostProfile] = {
    "openai": ProviderCostProfile(
        provider="openai",
        input_cost_per_1k=0.005,
        output_cost_per_1k=0.015,
        quality_score=0.92,
        latency_ms_p50=450,
    ),
    "anthropic": ProviderCostProfile(
        provider="anthropic",
        input_cost_per_1k=0.003,
        output_cost_per_1k=0.015,
        quality_score=0.94,
        latency_ms_p50=500,
    ),
    "google": ProviderCostProfile(
        provider="google",
        input_cost_per_1k=0.00025,
        output_cost_per_1k=0.001,
        quality_score=0.88,
        latency_ms_p50=400,
    ),
    "groq": ProviderCostProfile(
        provider="groq",
        input_cost_per_1k=0.00005,
        output_cost_per_1k=0.00010,
        quality_score=0.82,
        latency_ms_p50=100,
    ),
    "together": ProviderCostProfile(
        provider="together",
        input_cost_per_1k=0.0002,
        output_cost_per_1k=0.0006,
        quality_score=0.80,
        latency_ms_p50=300,
    ),
    "fireworks": ProviderCostProfile(
        provider="fireworks",
        input_cost_per_1k=0.0002,
        output_cost_per_1k=0.0008,
        quality_score=0.81,
        latency_ms_p50=200,
    ),
    "deepseek": ProviderCostProfile(
        provider="deepseek",
        input_cost_per_1k=0.00014,
        output_cost_per_1k=0.00028,
        quality_score=0.85,
        latency_ms_p50=350,
    ),
    "cerebras": ProviderCostProfile(
        provider="cerebras",
        input_cost_per_1k=0.0001,
        output_cost_per_1k=0.0002,
        quality_score=0.78,
        latency_ms_p50=80,
    ),
    "ollama": ProviderCostProfile(
        provider="ollama",
        input_cost_per_1k=0.0,
        output_cost_per_1k=0.0,
        quality_score=0.75,
        latency_ms_p50=600,
    ),
    "mistral": ProviderCostProfile(
        provider="mistral",
        input_cost_per_1k=0.0002,
        output_cost_per_1k=0.0006,
        quality_score=0.83,
        latency_ms_p50=350,
    ),
    "cohere": ProviderCostProfile(
        provider="cohere",
        input_cost_per_1k=0.0003,
        output_cost_per_1k=0.0015,
        quality_score=0.84,
        latency_ms_p50=400,
    ),
}


class CostAwareRouter:
    """
    Intelligent cost-aware router for LLM providers.

    Selects the optimal provider based on cost, quality, and constraints.
    Supports Thompson sampling for explore-exploit optimization.
    """

    def __init__(
        self,
        config: CostRouterConfig | None = None,
        profiles: dict[str, ProviderCostProfile] | None = None,
    ):
        self.config = config or CostRouterConfig()
        self._profiles = profiles or DEFAULT_PROVIDER_PROFILES.copy()
        self._profile_cache: dict[str, tuple[ProviderCostProfile, datetime]] = {}
        self._lock = asyncio.Lock()
        self._initialized = False
        self._stats: dict[str, Any] = {
            "selections": 0,
            "cost_savings_total": 0.0,
            "budget_blocks": 0,
            "quality_upgrades": 0,
        }

    async def initialize(self) -> None:
        if self._initialized:
            return
        self._initialized = True
        logger.info(f"Cost-aware router initialized with {len(self._profiles)} providers")

    async def shutdown(self) -> None:
        self._initialized = False

    async def select_provider(
        self,
        providers: list[str],
        estimated_tokens: int = 1000,
        max_cost: float | None = None,
        quality_threshold: float | None = None,
        latency_threshold_ms: float | None = None,
    ) -> str | None:
        """Select optimal provider based on cost and quality."""
        decision = await self.select_with_constraints(
            providers=providers,
            input_tokens=estimated_tokens // 2,
            output_tokens=estimated_tokens // 2,
            max_cost=max_cost,
            quality_threshold=quality_threshold,
            latency_threshold_ms=latency_threshold_ms,
        )
        return decision.selected_provider if decision else None

    async def select_with_constraints(
        self,
        providers: list[str],
        input_tokens: int,
        output_tokens: int,
        max_cost: float | None = None,
        quality_threshold: float | None = None,
        latency_threshold_ms: float | None = None,
    ) -> CostRoutingDecision | None:
        """Select provider with detailed constraints and return full decision."""
        if not providers:
            return None

        max_cost = max_cost or self.config.default_max_cost
        quality_threshold = quality_threshold or self.config.default_quality_threshold
        latency_threshold_ms = latency_threshold_ms or self.config.default_latency_threshold_ms

        candidates = []
        for provider_name in providers:
            profile = self._get_provider_profile(provider_name)
            if profile:
                estimated_cost = profile.estimate_cost(input_tokens, output_tokens)
                candidates.append(
                    {
                        "provider": provider_name,
                        "profile": profile,
                        "estimated_cost": estimated_cost,
                    }
                )

        if not candidates:
            return None

        constraints_applied: list[str] = []
        filtered = candidates.copy()

        if quality_threshold is not None:
            before = len(filtered)
            filtered = [c for c in filtered if c["profile"].quality_score >= quality_threshold]
            if len(filtered) < before:
                constraints_applied.append(f"quality >= {quality_threshold}")

        if latency_threshold_ms is not None:
            before = len(filtered)
            filtered = [c for c in filtered if c["profile"].latency_ms_p50 <= latency_threshold_ms]
            if len(filtered) < before:
                constraints_applied.append(f"latency <= {latency_threshold_ms}ms")

        if max_cost is not None:
            before = len(filtered)
            filtered = [c for c in filtered if c["estimated_cost"] <= max_cost]
            if len(filtered) < before:
                constraints_applied.append(f"cost <= ${max_cost:.4f}")

        if not filtered:
            if self.config.strict_budget:
                self._stats["budget_blocks"] += 1
                return None
            elif self.config.fallback_provider:
                fb_profile = self._get_provider_profile(self.config.fallback_provider)
                if fb_profile:
                    return CostRoutingDecision(
                        selected_provider=self.config.fallback_provider,
                        estimated_cost=fb_profile.estimate_cost(input_tokens, output_tokens),
                        quality_score=fb_profile.quality_score,
                        reason="Fallback: no providers met constraints",
                        constraints_applied=constraints_applied,
                    )
            filtered = candidates
            constraints_applied.append("constraints relaxed")

        scored = []
        max_candidate_cost = max(p["estimated_cost"] for p in candidates)
        for c in filtered:
            score = self._calculate_score(c["profile"], c["estimated_cost"], max_candidate_cost)
            scored.append({**c, "score": score})

        scored.sort(key=lambda x: x["score"], reverse=True)

        best = scored[0]
        self._stats["selections"] += 1

        max_cost_option = max(c["estimated_cost"] for c in candidates)
        savings = max_cost_option - best["estimated_cost"]
        if savings > 0:
            self._stats["cost_savings_total"] += savings

        alternatives = [
            {
                "provider": c["provider"],
                "estimated_cost": c["estimated_cost"],
                "quality_score": c["profile"].quality_score,
                "score": c["score"],
            }
            for c in scored[1:4]
        ]

        return CostRoutingDecision(
            selected_provider=best["provider"],
            estimated_cost=best["estimated_cost"],
            quality_score=best["profile"].quality_score,
            reason=f"Optimal cost/quality score: {best['score']:.3f}",
            alternatives=alternatives,
            constraints_applied=constraints_applied,
        )

    def _calculate_score(
        self, profile: ProviderCostProfile, estimated_cost: float, max_cost: float
    ) -> float:
        cost_score = 1 - (estimated_cost / max_cost) if max_cost > 0 else 1.0

        if self.config.explore_mode:
            quality_score = self._sample_thompson(profile)
        else:
            quality_score = profile.quality_score

        latency_score = max(0, 1 - (profile.latency_ms_p50 / 1000))

        return (
            self.config.cost_weight * cost_score
            + self.config.quality_weight * quality_score
            + self.config.latency_weight * latency_score
        )

    def _sample_thompson(self, profile: ProviderCostProfile) -> float:
        return random.betavariate(profile.beta_alpha, profile.beta_beta)

    def update_posterior(
        self, provider: str, success: bool, quality_score: float | None = None
    ) -> None:
        """Update Beta posterior for a provider after observing an outcome."""
        profile = self._profiles.get(provider)
        if not profile:
            return

        if success:
            reward = quality_score if quality_score is not None else 1.0
            profile.beta_alpha += reward
            profile.beta_beta += 1.0 - reward
        else:
            profile.beta_beta += 1.0

        n = profile.beta_alpha + profile.beta_beta - 2
        if n > 0:
            profile.quality_score = (profile.beta_alpha - 1) / n

        profile.last_updated = datetime.now(timezone.utc)

        if provider in self._profile_cache:
            del self._profile_cache[provider]

    def _get_provider_profile(self, provider: str) -> ProviderCostProfile | None:
        if provider in self._profile_cache:
            profile, cached_at = self._profile_cache[provider]
            age = (datetime.now(timezone.utc) - cached_at).total_seconds()
            if age < self.config.profile_cache_ttl_seconds:
                return profile

        profile = self._profiles.get(provider)
        if profile:
            self._profile_cache[provider] = (profile, datetime.now(timezone.utc))
        return profile

    def update_profile(self, provider: str, profile: ProviderCostProfile) -> None:
        self._profiles[provider] = profile
        if provider in self._profile_cache:
            del self._profile_cache[provider]

    def get_all_profiles(self) -> dict[str, ProviderCostProfile]:
        return self._profiles.copy()

    def get_stats(self) -> dict[str, Any]:
        return {
            **self._stats,
            "provider_count": len(self._profiles),
            "initialized": self._initialized,
        }


_router_instance: CostAwareRouter | None = None


async def get_cost_aware_router(
    config: CostRouterConfig | None = None,
) -> CostAwareRouter:
    """Get or create the singleton cost-aware router."""
    global _router_instance
    if _router_instance is None:
        _router_instance = CostAwareRouter(config)
        await _router_instance.initialize()
    return _router_instance


def reset_router() -> None:
    """Reset router instance (for testing)."""
    global _router_instance
    _router_instance = None


__all__ = [
    "CostAwareRouter",
    "CostRouterConfig",
    "ProviderCostProfile",
    "CostRoutingDecision",
    "DEFAULT_PROVIDER_PROFILES",
    "get_cost_aware_router",
    "reset_router",
]
