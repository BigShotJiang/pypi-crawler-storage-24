"""
Base LLM Provider

Standalone base class for all LLM provider implementations.
No mesh dependencies — works independently.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from .exceptions import (
    LLMAuthenticationError,
    LLMConfigError,
    LLMModelNotFoundError,
    LLMRateLimitError,
    LLMTimeoutError,
)
from .types import (
    HealthStatus,
    LLMCapabilityType,
    LLMResponse,
    ProviderMetrics,
    StreamChunk,
    TokenUsage,
)

if TYPE_CHECKING:
    from .key_pool import KeyPoolManager

logger = logging.getLogger(__name__)


class BaseLLMProvider(ABC):
    """
    Base class for LLM provider implementations.

    Features:
    - ProviderMetrics with composite scoring
    - Optional KeyPoolManager composition
    - Token counting, model listing, health check
    - Response caching (simple in-memory)
    - Pre/post request hooks

    Example:
        class MyProvider(BaseLLMProvider):
            SUPPORTED_MODELS = {"my-model-v1"}
            CAPABILITIES = {LLMCapabilityType.COMPLETION, LLMCapabilityType.STREAMING}

            @property
            def name(self) -> str:
                return "my_provider"

            async def _make_request(self, messages, model, **kwargs) -> dict:
                ...

            async def _stream_request(self, messages, model, **kwargs):
                ...
    """

    SUPPORTED_MODELS: set[str] = set()
    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
    }
    MODEL_ALIASES: dict[str, str] = {}

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_keys: list[str] | None = None,
        key_rotation_strategy: str | None = None,
        enable_caching: bool = False,
        cache_ttl: int = 3600,
        max_cache_size: int = 1000,
        enable_circuit_breaker: bool = False,
        circuit_breaker_config: Any | None = None,
        enable_rate_limiter: bool = False,
        rate_limiter_config: Any | None = None,
    ):
        self._config = self._normalize_config(config)
        self._api_key: str | None = None
        self._current_key: str | None = None

        # Key pool (composed, not inherited)
        self._key_pool: KeyPoolManager | None = None
        if api_keys or self._config.get("api_keys"):
            from .key_pool import KeyPoolManager
            from .types import RotationStrategy

            keys = api_keys or self._config.get("api_keys", [])
            strategy_str = key_rotation_strategy or self._config.get(
                "key_rotation_strategy", "adaptive"
            )
            strategy = RotationStrategy(strategy_str)
            self._key_pool = KeyPoolManager(
                provider=getattr(self, "provider_name", self.__class__.__name__.lower()),
                keys=keys,
                strategy=strategy,
            )
            logger.info(f"Key pool initialized with {len(keys)} keys using {strategy_str} strategy")

        # Circuit breaker (composed, not inherited)
        self._circuit_breaker = None
        if enable_circuit_breaker:
            from .resilience.circuit_breaker import (
                PROVIDER_DEFAULTS,
                CircuitBreaker,
                CircuitBreakerConfig,
            )

            provider_name = getattr(self, "provider_name", self.__class__.__name__.lower())
            if circuit_breaker_config is None:
                cb_config = PROVIDER_DEFAULTS.get(provider_name, CircuitBreakerConfig())
            elif isinstance(circuit_breaker_config, CircuitBreakerConfig):
                cb_config = circuit_breaker_config
            else:
                cb_config = CircuitBreakerConfig()
            self._circuit_breaker = CircuitBreaker(name=provider_name, config=cb_config)

        # Rate limiter (composed, not inherited)
        self._rate_limiter = None
        if enable_rate_limiter:
            from .resilience.rate_limiter import (
                PROVIDER_RATE_LIMITS,
                RateLimitConfig,
                TokenBucketRateLimiter,
            )

            provider_name = getattr(self, "provider_name", self.__class__.__name__.lower())
            if rate_limiter_config is None:
                rl_config = PROVIDER_RATE_LIMITS.get(
                    provider_name, RateLimitConfig(max_calls=100, time_window=60.0)
                )
            elif isinstance(rate_limiter_config, RateLimitConfig):
                rl_config = rate_limiter_config
            else:
                rl_config = RateLimitConfig(max_calls=100, time_window=60.0)
            self._rate_limiter = TokenBucketRateLimiter(config=rl_config)

        # Cache settings
        self._enable_caching = enable_caching
        self._cache_ttl = cache_ttl
        self._max_cache_size = max_cache_size
        self._cache: dict[str, tuple[dict[str, Any], float]] = {}
        self._cache_prefix = f"llm_{getattr(self, 'provider_name', 'unknown')}"

        # Metrics
        self._metrics = ProviderMetrics()

        # State
        self._initialized = False
        self._client: Any = None

    def _normalize_config(self, config: Any) -> dict[str, Any]:
        if config is None:
            return {}
        if isinstance(config, dict):
            return config
        if hasattr(config, "model_dump"):
            return config.model_dump()
        if hasattr(config, "__dict__"):
            return {k: v for k, v in config.__dict__.items() if not k.startswith("_")}
        return {}

    # ========================================================================
    # Abstract Interface
    # ========================================================================

    @property
    @abstractmethod
    def name(self) -> str:
        """Provider name (e.g., 'openai', 'anthropic')."""
        ...

    @property
    def version(self) -> str:
        return "0.1.0"

    @abstractmethod
    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Make the actual API request. Subclasses must implement."""
        ...

    @abstractmethod
    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """Make streaming API request. Subclasses must implement."""
        ...

    # ========================================================================
    # Public Interface
    # ========================================================================

    async def complete(
        self,
        messages: list[dict[str, Any]],
        model: str | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion."""
        await self._ensure_initialized()

        model = model or self._config.get("model") or self.default_model
        if not model:
            raise LLMConfigError("No model specified", field="model")

        # Pre-request hook
        messages, model, kwargs = await self.pre_request_hook(messages, model, **kwargs)

        # Check cache
        cache_key = None
        if self._enable_caching:
            cache_key = self._generate_cache_key(messages, model, kwargs)
            cached = self._get_cached_response(cache_key)
            if cached:
                self._metrics.cache_hits += 1
                return self._wrap_response(cached, model)
            self._metrics.cache_misses += 1

        # Rate limiter check
        if self._rate_limiter:
            acquired = await self._rate_limiter.acquire()
            if not acquired:
                raise LLMRateLimitError(
                    f"Rate limit exceeded for {self.name}",
                    provider=self.name,
                    model=model,
                )

        max_retries = kwargs.pop("max_retries", self._config.get("max_retries", 3))
        last_error: Exception | None = None

        for attempt in range(max_retries + 1):
            start_time = datetime.now(timezone.utc)

            # Per-request key rotation on retry
            if self._key_pool and attempt > 0:
                try:
                    self._current_key = await self._key_pool.acquire()
                    self._api_key = self._current_key
                    self._reset_client()
                except RuntimeError:
                    pass  # No keys available, try with current key

            # Circuit breaker check
            if self._circuit_breaker and self._circuit_breaker.is_open:
                from .resilience.circuit_breaker import CircuitOpenError

                raise CircuitOpenError(f"Circuit breaker open for {self.name}", provider=self.name)

            try:
                raw = await self._make_request(messages, model, **kwargs)

                latency = (datetime.now(timezone.utc) - start_time).total_seconds() * 1000
                tokens = raw.get("usage", {}).get("total_tokens", 0)
                cost = self._calculate_cost(model, raw.get("usage", {}))

                self._metrics.record_request(
                    success=True, latency_ms=latency, tokens=tokens, cost_usd=cost
                )
                await self._record_key_success(latency, tokens, cost)
                if self._circuit_breaker:
                    self._circuit_breaker.record_success()

                # Cache response
                if self._enable_caching and cache_key:
                    self._cache_response(cache_key, raw)

                response = self._wrap_response(raw, model)

                # Post-response hook
                response = await self.post_response_hook(response)
                return response

            except (LLMRateLimitError, LLMTimeoutError) as e:
                last_error = e
                latency = (datetime.now(timezone.utc) - start_time).total_seconds() * 1000
                self._metrics.record_request(
                    success=False, latency_ms=latency, error_type=type(e).__name__
                )
                if self._circuit_breaker:
                    self._circuit_breaker.record_failure(e)
                retry_after = getattr(e, "retry_after", 60.0) or 60.0
                await self._record_key_rate_limit(retry_after)
                if attempt < max_retries:
                    await asyncio.sleep(min(2**attempt, 30))
                    continue
                raise

            except (LLMAuthenticationError, LLMModelNotFoundError, LLMConfigError):
                raise  # Non-retryable

            except Exception as e:
                last_error = e
                latency = (datetime.now(timezone.utc) - start_time).total_seconds() * 1000
                self._metrics.record_request(
                    success=False, latency_ms=latency, error_type=type(e).__name__
                )
                if self._circuit_breaker:
                    self._circuit_breaker.record_failure(e)

                error_str = str(e).lower()
                if "rate" in error_str and "limit" in error_str:
                    await self._record_key_rate_limit(60.0)
                else:
                    await self._record_key_error(str(e))
                raise

        raise last_error  # type: ignore[misc]

    async def stream(
        self,
        messages: list[dict[str, Any]],
        model: str | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        """Stream a completion."""
        await self._ensure_initialized()

        model = model or self._config.get("model") or self.default_model
        if not model:
            raise LLMConfigError("No model specified", field="model")

        # Pre-request hook
        messages, model, kwargs = await self.pre_request_hook(messages, model, **kwargs)

        start_time = datetime.now(timezone.utc)
        chunk_index = 0

        try:
            async for chunk in self._stream_request(messages, model, **kwargs):
                yield StreamChunk(
                    content=chunk.get("content", ""),
                    model=chunk.get("model", model),
                    provider=chunk.get("provider", self.name),
                    chunk_index=chunk_index,
                    is_final=chunk.get("done", False),
                    finish_reason=chunk.get("finish_reason"),
                    tool_call_delta=chunk.get("tool_call_delta"),
                )
                chunk_index += 1

            latency = (datetime.now(timezone.utc) - start_time).total_seconds() * 1000
            self._metrics.record_request(success=True, latency_ms=latency)

        except Exception as e:
            latency = (datetime.now(timezone.utc) - start_time).total_seconds() * 1000
            self._metrics.record_request(
                success=False, latency_ms=latency, error_type=type(e).__name__
            )
            raise

    async def health_check(self) -> HealthStatus:
        """Check if provider is healthy."""
        try:
            await self._ensure_initialized()
            return HealthStatus(healthy=self._client is not None, message="OK")
        except Exception as e:
            return HealthStatus(healthy=False, message=str(e))

    def get_supported_models(self) -> set[str]:
        return self.SUPPORTED_MODELS

    def get_available_models(self) -> list[str]:
        if self.SUPPORTED_MODELS:
            return list(self.SUPPORTED_MODELS)
        return self._config.get("available_models", [self.default_model])

    def get_capabilities(self) -> set[str]:
        return {cap.value for cap in self.CAPABILITIES}

    def has_capability(self, capability: LLMCapabilityType | str) -> bool:
        if isinstance(capability, str):
            return capability in self.get_capabilities()
        return capability in self.CAPABILITIES

    def supports_model(self, model: str) -> bool:
        return model in self.SUPPORTED_MODELS or model in self.MODEL_ALIASES

    def resolve_model_alias(self, model: str) -> str:
        return self.MODEL_ALIASES.get(model, model)

    # ========================================================================
    # Properties
    # ========================================================================

    @property
    def default_model(self) -> str:
        return self._config.get("model", "")

    @property
    def metrics(self) -> ProviderMetrics:
        return self._metrics

    # ========================================================================
    # Initialization
    # ========================================================================

    async def _ensure_initialized(self) -> None:
        if not self._initialized:
            await self.initialize()

    async def initialize(self) -> None:
        if self._initialized:
            return
        self._api_key = self._get_api_key()
        await self._init_client()
        self._initialized = True
        logger.debug(f"Provider {self.name} initialized")

    async def _init_client(self) -> None:
        """Initialize the client. Override in subclasses."""
        pass

    async def shutdown(self) -> None:
        self._initialized = False
        self._client = None
        logger.debug(f"Provider {self.name} shutdown")

    # ========================================================================
    # API Key Management
    # ========================================================================

    def _get_api_key(self) -> str | None:
        """Get API key from key pool, config, or environment."""
        # Key pool handled at request time via acquire()
        if self._config.get("api_key"):
            self._current_key = self._config["api_key"]
            return self._config["api_key"]

        env_key = f"{self.name.upper()}_API_KEY"
        key = os.environ.get(env_key)
        if key:
            self._current_key = key
        return key

    async def _record_key_success(
        self, latency_ms: float = 0.0, tokens: int = 0, cost_usd: float = 0.0
    ) -> None:
        if self._key_pool and self._current_key:
            await self._key_pool.record_success(self._current_key, latency_ms, tokens, cost_usd)

    async def _record_key_error(self, error: str = "") -> None:
        if self._key_pool and self._current_key:
            await self._key_pool.record_error(self._current_key, error)

    async def _record_key_rate_limit(self, retry_after: float = 60.0) -> None:
        if self._key_pool and self._current_key:
            await self._key_pool.record_rate_limit(self._current_key, retry_after)

    async def get_key_pool_status(self) -> dict[str, Any] | None:
        if self._key_pool:
            return self._key_pool.get_status()
        return None

    # ========================================================================
    # Caching (simple in-memory)
    # ========================================================================

    def _generate_cache_key(
        self, messages: list[dict[str, Any]], model: str, kwargs: dict[str, Any]
    ) -> str:
        content = json.dumps(
            {
                "messages": messages,
                "model": model,
                "kwargs": {k: v for k, v in kwargs.items() if k != "stream"},
            },
            sort_keys=True,
        )
        hash_value = hashlib.sha256(content.encode()).hexdigest()[:16]
        return f"{self._cache_prefix}:{model}:{hash_value}"

    def _get_cached_response(self, cache_key: str) -> dict[str, Any] | None:
        if cache_key in self._cache:
            response, cached_at = self._cache[cache_key]
            if (datetime.now(timezone.utc).timestamp() - cached_at) < self._cache_ttl:
                return response
            del self._cache[cache_key]
        return None

    def _cache_response(self, cache_key: str, response: dict[str, Any]) -> None:
        if len(self._cache) >= self._max_cache_size:
            oldest_key = min(self._cache, key=lambda k: self._cache[k][1])
            del self._cache[oldest_key]
        self._cache[cache_key] = (response, datetime.now(timezone.utc).timestamp())

    # ========================================================================
    # Cost Calculation
    # ========================================================================

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        """Override in subclasses with provider-specific pricing."""
        return 0.0

    # ========================================================================
    # Response Wrapping
    # ========================================================================

    def _wrap_response(self, raw: dict[str, Any], model: str) -> LLMResponse:
        """Wrap raw provider dict into typed LLMResponse."""
        usage_data = raw.get("usage")
        usage = TokenUsage.from_dict(usage_data) if usage_data else TokenUsage()
        return LLMResponse(
            content=raw.get("content", ""),
            model=raw.get("model", model),
            provider=raw.get("provider", self.name),
            usage=usage,
            finish_reason=raw.get("finish_reason"),
            tool_calls=raw.get("tool_calls"),
            raw_response=raw,
        )

    def _reset_client(self) -> None:
        """Reset client so it picks up new API key. Override if needed."""
        pass

    # ========================================================================
    # Embeddings
    # ========================================================================

    async def embed(
        self, texts: list[str], model: str | None = None, **kwargs: Any
    ) -> list[list[float]]:
        """Generate embeddings. Override in providers that support embeddings."""
        raise NotImplementedError(f"{self.name} does not support embeddings")

    # ========================================================================
    # Extension Hooks
    # ========================================================================

    async def pre_request_hook(
        self, messages: list[dict[str, Any]], model: str, **kwargs: Any
    ) -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
        return messages, model, kwargs

    async def post_response_hook(self, response: LLMResponse) -> LLMResponse:
        return response


__all__ = ["BaseLLMProvider"]
