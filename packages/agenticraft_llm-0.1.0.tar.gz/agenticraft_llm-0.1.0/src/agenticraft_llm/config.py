"""
LLM Provider Configuration

Unified provider configuration models.
"""

from typing import Any

from pydantic import BaseModel, ConfigDict


class LLMProviderConfig(BaseModel):
    """Unified LLM provider configuration."""

    model_config = ConfigDict(extra="allow")

    # Core
    name: str = ""
    api_key: str | None = None
    api_base: str | None = None

    # Model
    model: str | None = None
    temperature: float = 0.7
    max_tokens: int | None = None

    # Request
    timeout: int = 30
    max_retries: int = 3
    retry_delay: float = 1.0

    # Features
    streaming: bool = False
    caching_enabled: bool = True

    # Resilience
    retry_enabled: bool = True
    circuit_breaker_enabled: bool = True
    rate_limit_enabled: bool = True

    # Monitoring
    metrics_enabled: bool = True
    health_check_interval: int = 60

    # Extra
    extra: dict[str, Any] = {}
    metadata: dict[str, Any] = {}
    capabilities: dict[str, Any] = {}


__all__ = [
    "LLMProviderConfig",
]
