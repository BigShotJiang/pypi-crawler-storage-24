"""
LLM Providers

14 provider implementations with lazy loading.
Each provider's SDK is an optional dependency.
"""

from __future__ import annotations


def __getattr__(name: str):
    """Lazy-load providers on first access."""
    _providers = {
        "OpenAIProvider": ".openai",
        "AnthropicProvider": ".anthropic",
        "GoogleProvider": ".google",
        "AzureOpenAIProvider": ".azure_openai",
        "BedrockProvider": ".bedrock",
        "FireworksProvider": ".fireworks",
        "CerebrasProvider": ".cerebras",
        "CohereProvider": ".cohere",
        "DeepSeekProvider": ".deepseek",
        "XAIProvider": ".xai",
        "OllamaProvider": ".ollama",
        "OpenRouterProvider": ".openrouter",
        "PerplexityProvider": ".perplexity",
        "NebiusProvider": ".nebius",
    }

    if name in _providers:
        import importlib

        module = importlib.import_module(_providers[name], package=__name__)
        return getattr(module, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "OpenAIProvider",
    "AnthropicProvider",
    "GoogleProvider",
    "AzureOpenAIProvider",
    "BedrockProvider",
    "FireworksProvider",
    "CerebrasProvider",
    "CohereProvider",
    "DeepSeekProvider",
    "XAIProvider",
    "OllamaProvider",
    "OpenRouterProvider",
    "PerplexityProvider",
    "NebiusProvider",
]
