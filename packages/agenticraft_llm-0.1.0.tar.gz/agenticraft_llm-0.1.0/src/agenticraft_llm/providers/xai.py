"""
xAI (Grok) Provider Implementation

Advanced AI from xAI with reasoning, vision, and massive context windows.
Grok models support up to 2M context with parallel tool calling.

Version: 0.1.0
Date: 2025-12-12

Features:
- Reasoning models with visible chain-of-thought
- Vision capabilities (image understanding)
- 2M context window (Grok 4.1)
- Parallel tool calling
- Structured outputs (JSON schema)
- OpenAI-compatible API

Note: Requires XAI_API_KEY environment variable
"""

import json
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class XAIProvider(BaseLLMProvider):
    """
    xAI (Grok) LLM provider with reasoning and vision.

    xAI's Grok models provide advanced reasoning, vision capabilities,
    and massive context windows up to 2M tokens. Fully OpenAI-compatible.

    Supports:
    - grok-4 (256K context, advanced reasoning)
    - grok-4-1-fast-reasoning (2M context, reasoning)
    - grok-4-1-fast-non-reasoning (2M context, fast)
    - grok-code-fast-1 (256K context, code-optimized)

    Example:
        ```python
        provider = XAIProvider(api_key="xai-...")
        await provider.initialize()

        # Text completion
        response = await provider.complete(
            [{"role": "user", "content": "Hello"}],
            model="grok-4-1-fast-non-reasoning"
        )

        # Vision (image understanding)
        response = await provider.complete(
            [{
                "role": "user",
                "content": [
                    {"type": "text", "text": "What's in this image?"},
                    {"type": "image_url", "image_url": {"url": "..."}}
                ]
            }],
            model="grok-4"
        )
        ```
    """

    provider_name = "xai"

    # Pricing per 1M tokens (2025)
    PRICING = {
        "grok-4": {"input": 3.00, "output": 15.00},
        "grok-4-1-fast-reasoning": {"input": 0.20, "output": 0.50},
        "grok-4-1-fast-non-reasoning": {"input": 0.20, "output": 0.50},
        "grok-code-fast-1": {"input": 0.20, "output": 0.50},
    }

    SUPPORTED_MODELS: set[str] = set(PRICING.keys())

    # Models with reasoning capabilities
    REASONING_MODELS: set[str] = {
        "grok-4",
        "grok-4-1-fast-reasoning",
    }

    # Models with vision capabilities
    VISION_MODELS: set[str] = {
        "grok-4",
        "grok-4-1-fast-reasoning",
        "grok-4-1-fast-non-reasoning",
    }

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.FUNCTION_CALLING,
        LLMCapabilityType.VISION,
        LLMCapabilityType.JSON_MODE,
        LLMCapabilityType.JSON_SCHEMA,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.TOOL_USE,
        LLMCapabilityType.REASONING,
        LLMCapabilityType.CODE_GENERATION,
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_key: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
    ):
        """
        Initialize xAI provider.

        Args:
            config: Configuration dict with optional keys:
                - api_key: xAI API key
                - model: Default model (default: grok-4-1-fast-non-reasoning)
                - base_url: API base URL
                - timeout: Request timeout
                - max_retries: Max retry attempts
            api_key: xAI API key (kwargs override)
            model: Default model
            timeout: Request timeout in seconds
            max_retries: Max retry attempts
        """
        if config is None:
            config = {}

        if api_key is not None:
            config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if timeout is not None:
            config["timeout"] = timeout
        if max_retries is not None:
            config["max_retries"] = max_retries

        config.setdefault("name", "xai")
        config.setdefault("model", "grok-4-1-fast-non-reasoning")
        config.setdefault("base_url", "https://api.x.ai/v1")
        config.setdefault("timeout", 120)
        config.setdefault("max_retries", 3)

        if "api_key" not in config:
            env_key = os.environ.get("XAI_API_KEY")
            if env_key:
                config["api_key"] = env_key

        super().__init__(config)

        self._total_cost = 0.0
        self._request_count = 0
        self._async_client: Any = None

    @property
    def name(self) -> str:
        return "xai"

    @property
    def default_model(self) -> str:
        return self._config.get("model", "grok-4-1-fast-non-reasoning")

    def _get_client(self) -> Any:
        """Get or create async OpenAI-compatible client."""
        if self._async_client is None:
            try:
                from openai import AsyncOpenAI

                self._async_client = AsyncOpenAI(
                    api_key=self._api_key,
                    base_url=self._config.get("base_url", "https://api.x.ai/v1"),
                    timeout=self._config.get("timeout", 120),
                    max_retries=0,
                )
            except ImportError:
                raise ImportError(
                    "xAI provider requires 'openai' package. "
                    "Install with: pip install agenticraft-llm[xai]"
                )
        return self._async_client

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._async_client = None

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Make completion request to xAI.

        Args:
            messages: List of message dicts
            model: Model name
            **kwargs: Additional parameters

        Returns:
            Response dict with content, model, provider, usage
        """
        client = self._get_client()

        # Build request params
        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
        }

        # Add optional parameters
        for key in ["temperature", "max_tokens", "top_p", "stop", "n", "seed"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Handle JSON schema enforcement (xAI supports structured outputs)
        if kwargs.get("json_schema"):
            request_params["response_format"] = {
                "type": "json_schema",
                "json_schema": kwargs["json_schema"],
            }
            if kwargs.get("strict_json", True):
                request_params["response_format"]["strict"] = True
        elif kwargs.get("json_mode"):
            request_params["response_format"] = {"type": "json_object"}

        # Handle tools (parallel tool calling supported)
        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")
            # xAI supports parallel tool calls by default
            if kwargs.get("parallel_tool_calls") is not None:
                request_params["parallel_tool_calls"] = kwargs["parallel_tool_calls"]

        try:
            response = await client.chat.completions.create(**request_params)

            choice = response.choices[0]

            # Extract usage
            usage = {}
            if response.usage:
                usage = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }

            # Calculate cost
            cost = self._calculate_cost(model, usage)
            self._total_cost += cost
            self._request_count += 1

            # Extract tool calls
            tool_calls = None
            if hasattr(choice.message, "tool_calls") and choice.message.tool_calls:
                tool_calls = []
                for tc in choice.message.tool_calls:
                    try:
                        args = tc.function.arguments
                        if isinstance(args, str):
                            args = json.loads(args)
                        tool_calls.append(
                            {
                                "id": tc.id,
                                "name": tc.function.name,
                                "arguments": args,
                            }
                        )
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse tool arguments for {tc.function.name}")

            result = {
                "content": choice.message.content or "",
                "model": model,
                "provider": "xai",
                "usage": usage,
                "finish_reason": choice.finish_reason,
                "cost": cost,
            }

            if tool_calls:
                result["tool_calls"] = tool_calls

            return result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"xAI request failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="xai", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="xai", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="xai", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="xai", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e), provider="xai", model=model, status_code=getattr(e, "status_code", None)
                ) from e
            logger.error(f"xAI request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream completion from xAI.

        Args:
            messages: List of message dicts
            model: Model name
            **kwargs: Additional parameters

        Yields:
            Response chunks
        """
        client = self._get_client()

        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": True,
        }

        for key in ["temperature", "max_tokens", "top_p"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            stream = await client.chat.completions.create(**request_params)

            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta

                    result: dict[str, Any] = {
                        "model": model,
                        "provider": "xai",
                        "done": False,
                    }

                    if delta.content:
                        result["content"] = delta.content

                    if hasattr(delta, "tool_calls") and delta.tool_calls:
                        result["tool_call_delta"] = [
                            {
                                "index": tc.index,
                                "id": tc.id,
                                "name": tc.function.name if tc.function else None,
                                "arguments": tc.function.arguments if tc.function else None,
                            }
                            for tc in delta.tool_calls
                        ]

                    if chunk.choices[0].finish_reason:
                        result["done"] = True
                        result["finish_reason"] = chunk.choices[0].finish_reason

                    yield result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"xAI stream failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="xai", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="xai", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="xai", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="xai", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e), provider="xai", model=model, status_code=getattr(e, "status_code", None)
                ) from e
            logger.error(f"xAI stream failed: {e}")
            raise

    async def _initialize_internal(self) -> None:
        """Initialize xAI provider internals."""
        if not self._api_key:
            logger.warning("xAI provider initialized without API key")

    async def _shutdown_internal(self) -> None:
        """Shutdown xAI provider internals."""
        if self._async_client:
            await self._async_client.close()
            self._async_client = None

    async def health_check(self) -> HealthStatus:
        """Check provider health."""
        if not self._api_key:
            return HealthStatus(healthy=False, message="No API key configured")

        try:
            client = self._get_client()
            await client.chat.completions.create(
                model="grok-4-1-fast-non-reasoning",
                max_tokens=1,
                messages=[{"role": "user", "content": "Hi"}],
            )
            return HealthStatus(healthy=True, message="xAI API is accessible")
        except Exception as e:
            return HealthStatus(healthy=False, message=f"xAI API error: {e}")

    def _format_tools(self, tools: list[Any]) -> list[dict[str, Any]]:
        """Format tools for xAI API (OpenAI-compatible)."""
        formatted = []
        for tool in tools:
            if hasattr(tool, "to_openai_schema"):
                formatted.append(tool.to_openai_schema())
            elif isinstance(tool, dict):
                formatted.append(tool)
            else:
                formatted.append(
                    {
                        "type": "function",
                        "function": {
                            "name": getattr(tool, "name", "unknown"),
                            "description": getattr(tool, "description", ""),
                            "parameters": getattr(tool, "parameters", {}),
                        },
                    }
                )
        return formatted

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        """Calculate request cost (per 1M tokens)."""
        pricing = self.PRICING.get(model)
        if not pricing:
            pricing = self.PRICING["grok-4-1-fast-non-reasoning"]

        input_cost = (usage.get("prompt_tokens", 0) / 1_000_000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1_000_000) * pricing["output"]
        return input_cost + output_cost

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics."""
        return {
            "provider": "xai",
            "total_requests": self._request_count,
            "total_cost": round(self._total_cost, 6),
            "average_cost": round(self._total_cost / max(1, self._request_count), 6),
        }

    def supports_model(self, model: str) -> bool:
        """Check if model is supported."""
        return model in self.SUPPORTED_MODELS

    def is_reasoning_model(self, model: str) -> bool:
        """Check if model supports reasoning."""
        return model in self.REASONING_MODELS

    def is_vision_model(self, model: str) -> bool:
        """Check if model supports vision."""
        return model in self.VISION_MODELS


__all__ = ["XAIProvider"]
