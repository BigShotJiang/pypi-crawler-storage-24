"""
Fireworks AI Provider Implementation

Ultra-fast inference with FireAttention kernel (4x vLLM speed).
HIPAA/SOC2 compliant. Used by Cursor and Sourcegraph Cody.

Version: 0.1.0
Date: 2025-12-12

Features:
- Ultra-fast inference (FireAttention kernel)
- OpenAI-compatible API
- Streaming support
- Function calling
- JSON mode
- Models: DeepSeek, Llama, Mixtral, Qwen

Note: Requires FIREWORKS_API_KEY environment variable
"""

import json
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class FireworksProvider(BaseLLMProvider):
    """
    Fireworks AI LLM provider with ultra-fast inference.

    Fireworks uses custom FireAttention kernel for extremely fast
    inference (4x vLLM speed), making it ideal for latency-sensitive
    applications. HIPAA and SOC2 compliant.

    Supports:
    - DeepSeek V3/R1 (reasoning, coding)
    - Llama 3.3/3.2/3.1 (general purpose)
    - Mixtral 8x22B (32K context)
    - Qwen 2.5 (coding, multilingual)
    - Phi-3 (efficient)

    Example:
        ```python
        provider = FireworksProvider(api_key="fw_...")
        await provider.initialize()
        response = await provider.complete([{"role": "user", "content": "Hello"}])
        ```
    """

    provider_name = "fireworks"

    # Full model IDs for Fireworks API
    MODEL_MAPPINGS = {
        # DeepSeek models (reasoning + coding)
        "deepseek-v3": "accounts/fireworks/models/deepseek-v3",
        "deepseek-r1": "accounts/fireworks/models/deepseek-r1",
        # Llama 3.3
        "llama-3.3-70b": "accounts/fireworks/models/llama-v3p3-70b-instruct",
        # Llama 3.2
        "llama-3.2-90b-vision": "accounts/fireworks/models/llama-v3p2-90b-vision-instruct",
        "llama-3.2-11b-vision": "accounts/fireworks/models/llama-v3p2-11b-vision-instruct",
        "llama-3.2-3b": "accounts/fireworks/models/llama-v3p2-3b-instruct",
        # Llama 3.1
        "llama-3.1-405b": "accounts/fireworks/models/llama-v3p1-405b-instruct",
        "llama-3.1-70b": "accounts/fireworks/models/llama-v3p1-70b-instruct",
        "llama-3.1-8b": "accounts/fireworks/models/llama-v3p1-8b-instruct",
        # Mixtral
        "mixtral-8x22b": "accounts/fireworks/models/mixtral-8x22b-instruct",
        "mixtral-8x7b": "accounts/fireworks/models/mixtral-8x7b-instruct",
        # Qwen 2.5
        "qwen-2.5-72b": "accounts/fireworks/models/qwen2p5-72b-instruct",
        "qwen-2.5-coder-32b": "accounts/fireworks/models/qwen2p5-coder-32b-instruct",
        # Phi-3
        "phi-3-medium": "accounts/fireworks/models/phi-3-medium-128k-instruct",
    }

    # Pricing per 1M tokens (2025)
    PRICING = {
        # DeepSeek (best value for reasoning)
        "accounts/fireworks/models/deepseek-v3": {"input": 0.28, "output": 1.14},
        "accounts/fireworks/models/deepseek-r1": {"input": 0.55, "output": 2.19},
        # Llama 3.3
        "accounts/fireworks/models/llama-v3p3-70b-instruct": {"input": 0.90, "output": 0.90},
        # Llama 3.2 Vision
        "accounts/fireworks/models/llama-v3p2-90b-vision-instruct": {"input": 0.90, "output": 0.90},
        "accounts/fireworks/models/llama-v3p2-11b-vision-instruct": {"input": 0.20, "output": 0.20},
        "accounts/fireworks/models/llama-v3p2-3b-instruct": {"input": 0.10, "output": 0.10},
        # Llama 3.1
        "accounts/fireworks/models/llama-v3p1-405b-instruct": {"input": 3.00, "output": 3.00},
        "accounts/fireworks/models/llama-v3p1-70b-instruct": {"input": 0.90, "output": 0.90},
        "accounts/fireworks/models/llama-v3p1-8b-instruct": {"input": 0.20, "output": 0.20},
        # Mixtral
        "accounts/fireworks/models/mixtral-8x22b-instruct": {"input": 0.90, "output": 0.90},
        "accounts/fireworks/models/mixtral-8x7b-instruct": {"input": 0.50, "output": 0.50},
        # Qwen 2.5
        "accounts/fireworks/models/qwen2p5-72b-instruct": {"input": 0.90, "output": 0.90},
        "accounts/fireworks/models/qwen2p5-coder-32b-instruct": {"input": 0.90, "output": 0.90},
        # Phi-3
        "accounts/fireworks/models/phi-3-medium-128k-instruct": {"input": 0.20, "output": 0.20},
    }

    SUPPORTED_MODELS: set[str] = set(MODEL_MAPPINGS.keys()) | set(PRICING.keys())

    # Models with reasoning capabilities
    REASONING_MODELS: set[str] = {
        "deepseek-r1",
        "accounts/fireworks/models/deepseek-r1",
    }

    # Models with vision capabilities
    VISION_MODELS: set[str] = {
        "llama-3.2-90b-vision",
        "llama-3.2-11b-vision",
        "accounts/fireworks/models/llama-v3p2-90b-vision-instruct",
        "accounts/fireworks/models/llama-v3p2-11b-vision-instruct",
    }

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.FUNCTION_CALLING,
        LLMCapabilityType.VISION,
        LLMCapabilityType.JSON_MODE,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.TOOL_USE,
        LLMCapabilityType.CODE_GENERATION,
        LLMCapabilityType.REASONING,
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_key: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
    ):
        """
        Initialize Fireworks AI provider.

        Args:
            config: Configuration dict with optional keys:
                - api_key: Fireworks API key
                - model: Default model (default: deepseek-v3)
                - base_url: API base URL
                - timeout: Request timeout
                - max_retries: Max retry attempts
            api_key: Fireworks API key (kwargs override)
            model: Default model
            timeout: Request timeout in seconds
            max_retries: Max retry attempts
        """
        if config is None:
            config = {}

        if api_key is not None:
            config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if timeout is not None:
            config["timeout"] = timeout
        if max_retries is not None:
            config["max_retries"] = max_retries

        config.setdefault("name", "fireworks")
        config.setdefault("model", "deepseek-v3")
        config.setdefault("base_url", "https://api.fireworks.ai/inference/v1")
        config.setdefault("timeout", 60)
        config.setdefault("max_retries", 3)

        if "api_key" not in config:
            env_key = os.environ.get("FIREWORKS_API_KEY")
            if env_key:
                config["api_key"] = env_key

        super().__init__(config)

        self._total_cost = 0.0
        self._request_count = 0
        self._async_client: Any = None

    @property
    def name(self) -> str:
        return "fireworks"

    @property
    def default_model(self) -> str:
        model = self._config.get("model", "deepseek-v3")
        return self.MODEL_MAPPINGS.get(model, model)

    def _get_client(self) -> Any:
        """Get or create async OpenAI-compatible client."""
        if self._async_client is None:
            try:
                from openai import AsyncOpenAI

                self._async_client = AsyncOpenAI(
                    api_key=self._api_key,
                    base_url=self._config.get("base_url", "https://api.fireworks.ai/inference/v1"),
                    timeout=self._config.get("timeout", 60),
                    max_retries=0,
                )
            except ImportError:
                raise ImportError(
                    "Fireworks provider requires 'openai' package. "
                    "Install with: pip install agenticraft-llm[fireworks]"
                )
        return self._async_client

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._async_client = None

    def _resolve_model(self, model: str) -> str:
        """Resolve model alias to full model ID."""
        return self.MODEL_MAPPINGS.get(model, model)

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Make completion request to Fireworks AI.

        Args:
            messages: List of message dicts
            model: Model name or alias
            **kwargs: Additional parameters

        Returns:
            Response dict with content, model, provider, usage
        """
        client = self._get_client()
        model = self._resolve_model(model)

        # Build request params (OpenAI-compatible)
        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
        }

        # Add optional parameters
        for key in [
            "temperature",
            "max_tokens",
            "top_p",
            "frequency_penalty",
            "presence_penalty",
            "stop",
            "n",
        ]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Handle JSON mode
        if kwargs.get("json_mode"):
            request_params["response_format"] = {"type": "json_object"}
        elif "response_format" in kwargs and kwargs["response_format"] is not None:
            request_params["response_format"] = kwargs["response_format"]

        # Handle tools
        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            response = await client.chat.completions.create(**request_params)

            choice = response.choices[0]

            # Extract usage
            usage = {}
            if response.usage:
                usage = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }

            # Calculate cost (per 1M tokens)
            cost = self._calculate_cost(model, usage)
            self._total_cost += cost
            self._request_count += 1

            # Extract tool calls
            tool_calls = None
            if hasattr(choice.message, "tool_calls") and choice.message.tool_calls:
                tool_calls = []
                for tc in choice.message.tool_calls:
                    try:
                        args = tc.function.arguments
                        if isinstance(args, str):
                            args = json.loads(args)
                        tool_calls.append(
                            {
                                "id": tc.id,
                                "name": tc.function.name,
                                "arguments": args,
                            }
                        )
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse tool arguments for {tc.function.name}")

            result = {
                "content": choice.message.content or "",
                "model": model,
                "provider": "fireworks",
                "usage": usage,
                "finish_reason": choice.finish_reason,
                "cost": cost,
            }

            if tool_calls:
                result["tool_calls"] = tool_calls

            return result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"Fireworks request failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="fireworks", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="fireworks", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="fireworks", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="fireworks", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="fireworks",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"Fireworks request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream completion from Fireworks AI.

        Args:
            messages: List of message dicts
            model: Model name or alias
            **kwargs: Additional parameters

        Yields:
            Response chunks
        """
        client = self._get_client()
        model = self._resolve_model(model)

        # Build request params
        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": True,
        }

        for key in ["temperature", "max_tokens", "top_p"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Handle tools
        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            stream = await client.chat.completions.create(**request_params)

            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta

                    result: dict[str, Any] = {
                        "model": model,
                        "provider": "fireworks",
                        "done": False,
                    }

                    if delta.content:
                        result["content"] = delta.content

                    if hasattr(delta, "tool_calls") and delta.tool_calls:
                        result["tool_call_delta"] = [
                            {
                                "index": tc.index,
                                "id": tc.id,
                                "name": tc.function.name if tc.function else None,
                                "arguments": tc.function.arguments if tc.function else None,
                            }
                            for tc in delta.tool_calls
                        ]

                    if chunk.choices[0].finish_reason:
                        result["done"] = True
                        result["finish_reason"] = chunk.choices[0].finish_reason

                    yield result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"Fireworks stream failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="fireworks", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="fireworks", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="fireworks", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="fireworks", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="fireworks",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"Fireworks stream failed: {e}")
            raise

    async def _initialize_internal(self) -> None:
        """Initialize Fireworks provider internals."""
        if not self._api_key:
            logger.warning("Fireworks provider initialized without API key")

    async def _shutdown_internal(self) -> None:
        """Shutdown Fireworks provider internals."""
        if self._async_client:
            await self._async_client.close()
            self._async_client = None

    async def health_check(self) -> HealthStatus:
        """Check provider health."""
        if not self._api_key:
            return HealthStatus(healthy=False, message="No API key configured")

        try:
            client = self._get_client()
            # Minimal test request
            await client.chat.completions.create(
                model="accounts/fireworks/models/llama-v3p2-3b-instruct",
                max_tokens=1,
                messages=[{"role": "user", "content": "Hi"}],
            )
            return HealthStatus(healthy=True, message="Fireworks API is accessible")
        except Exception as e:
            return HealthStatus(healthy=False, message=f"Fireworks API error: {e}")

    def _format_tools(self, tools: list[Any]) -> list[dict[str, Any]]:
        """Format tools for Fireworks API (OpenAI-compatible)."""
        formatted = []
        for tool in tools:
            if hasattr(tool, "to_openai_schema"):
                formatted.append(tool.to_openai_schema())
            elif isinstance(tool, dict):
                formatted.append(tool)
            else:
                formatted.append(
                    {
                        "type": "function",
                        "function": {
                            "name": getattr(tool, "name", "unknown"),
                            "description": getattr(tool, "description", ""),
                            "parameters": getattr(tool, "parameters", {}),
                        },
                    }
                )
        return formatted

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        """Calculate request cost (per 1M tokens)."""
        pricing = self.PRICING.get(model)
        if not pricing:
            # Try prefix match
            for prefix, price in self.PRICING.items():
                if model.startswith(prefix) or prefix in model:
                    pricing = price
                    break

        if not pricing:
            # Default to DeepSeek V3 pricing
            pricing = self.PRICING["accounts/fireworks/models/deepseek-v3"]

        input_cost = (usage.get("prompt_tokens", 0) / 1_000_000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1_000_000) * pricing["output"]
        return input_cost + output_cost

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics."""
        return {
            "provider": "fireworks",
            "total_requests": self._request_count,
            "total_cost": round(self._total_cost, 6),
            "average_cost": round(self._total_cost / max(1, self._request_count), 6),
        }

    def supports_model(self, model: str) -> bool:
        """Check if model is supported."""
        return model in self.SUPPORTED_MODELS or model in self.MODEL_MAPPINGS


__all__ = ["FireworksProvider"]
