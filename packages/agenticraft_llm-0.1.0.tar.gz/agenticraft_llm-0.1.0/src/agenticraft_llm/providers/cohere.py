"""
Cohere Provider Implementation

RAG-optimized LLM provider with native citation generation,
reranking, and embeddings.

Version: 0.1.0
Date: 2025-12-12

Features:
- RAG-optimized generation with citations
- Document reranking
- High-quality embeddings
- Connector integration
- Multi-step tool use

Note: Requires COHERE_API_KEY environment variable
"""

import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class CohereProvider(BaseLLMProvider):
    """
    Cohere LLM provider with RAG optimization.

    Cohere specializes in enterprise RAG workflows with native
    citation generation, document reranking, and high-quality
    embeddings.

    Supports:
    - Command A (111B, RAG optimized)
    - Command R+ (multi-step tool use)
    - Command R (cost-effective RAG)
    - Embed v4 (multimodal embeddings)
    - Rerank v3.5 (search reranking)

    Example:
        ```python
        provider = CohereProvider(api_key="...")
        await provider.initialize()

        # RAG with citations
        response = await provider.complete(
            [{"role": "user", "content": "What is X?"}],
            documents=[{"text": "X is defined as..."}]
        )
        # response includes citations

        # Reranking
        results = await provider.rerank(
            query="search query",
            documents=["doc1", "doc2", "doc3"],
            top_n=2
        )
        ```

    Requires the `cohere` package:
        pip install agenticraft-llm[cohere]
    """

    provider_name = "cohere"

    # Pricing per 1M tokens (2025)
    PRICING = {
        # Command models
        "command-a-03-2025": {"input": 2.50, "output": 10.00},
        "command-r-plus": {"input": 2.50, "output": 10.00},
        "command-r": {"input": 0.50, "output": 1.50},
        "command-r-08-2024": {"input": 0.50, "output": 1.50},
        "command-light": {"input": 0.30, "output": 0.60},
        # Embed models (per 1M tokens)
        "embed-v4.0": {"input": 0.10, "output": 0},
        "embed-english-v3.0": {"input": 0.10, "output": 0},
        "embed-multilingual-v3.0": {"input": 0.10, "output": 0},
        # Rerank (per 1K searches)
        "rerank-v3.5": {"input": 2.00, "output": 0},
        "rerank-english-v3.0": {"input": 2.00, "output": 0},
        "rerank-multilingual-v3.0": {"input": 2.00, "output": 0},
    }

    SUPPORTED_MODELS: set[str] = set(PRICING.keys())

    # Embed models
    EMBED_MODELS: set[str] = {
        "embed-v4.0",
        "embed-english-v3.0",
        "embed-multilingual-v3.0",
    }

    # Rerank models
    RERANK_MODELS: set[str] = {
        "rerank-v3.5",
        "rerank-english-v3.0",
        "rerank-multilingual-v3.0",
    }

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.FUNCTION_CALLING,
        LLMCapabilityType.EMBEDDINGS,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.TOOL_USE,
        LLMCapabilityType.CODE_GENERATION,
        LLMCapabilityType.RAG_CITATIONS,  # Cohere-specific
        LLMCapabilityType.RERANKING,  # Cohere-specific
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_key: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
    ):
        """
        Initialize Cohere provider.

        Args:
            config: Configuration dict with optional keys:
                - api_key: Cohere API key
                - model: Default model (default: command-r)
                - timeout: Request timeout
            api_key: Cohere API key (keyword-only)
            model: Default model (keyword-only)
            timeout: Request timeout (keyword-only)
        """
        if config is None:
            config = {}

        if api_key is not None:
            config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if timeout is not None:
            config["timeout"] = timeout

        config.setdefault("name", "cohere")
        config.setdefault("model", "command-r")
        config.setdefault("timeout", 60)

        if "api_key" not in config:
            env_key = os.environ.get("COHERE_API_KEY") or os.environ.get("CO_API_KEY")
            if env_key:
                config["api_key"] = env_key

        super().__init__(config)

        self._total_cost = 0.0
        self._request_count = 0
        self._client: Any = None

    @property
    def name(self) -> str:
        return "cohere"

    @property
    def default_model(self) -> str:
        return self._config.get("model", "command-r")

    def _get_client(self) -> Any:
        """Get or create Cohere client."""
        if self._client is None:
            try:
                import cohere

                self._client = cohere.AsyncClient(
                    api_key=self._api_key,
                    timeout=self._config.get("timeout", 60),
                )
            except ImportError:
                raise ImportError(
                    "Cohere provider requires 'cohere' package. "
                    "Install with: pip install agenticraft-llm[cohere]"
                )
        return self._client

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._client = None

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Make completion request to Cohere.

        Args:
            messages: List of message dicts
            model: Model name
            **kwargs: Additional parameters including:
                - documents: List of documents for RAG
                - connectors: List of connector IDs
                - citation_quality: Citation quality level

        Returns:
            Response dict with content, citations, model, provider, usage
        """
        client = self._get_client()

        # Format messages for Cohere chat
        chat_history = []
        message = ""
        preamble = None

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                preamble = content
            elif role == "user":
                if message:  # Previous message exists, add to history
                    chat_history.append(
                        {
                            "role": "USER",
                            "message": message,
                        }
                    )
                message = content
            elif role == "assistant":
                chat_history.append(
                    {
                        "role": "CHATBOT",
                        "message": content,
                    }
                )

        # Build request params
        request_params: dict[str, Any] = {
            "model": model,
            "message": message,
        }

        if chat_history:
            request_params["chat_history"] = chat_history

        if preamble:
            request_params["preamble"] = preamble

        # Add optional parameters
        if "temperature" in kwargs:
            request_params["temperature"] = kwargs["temperature"]
        if "max_tokens" in kwargs:
            request_params["max_tokens"] = kwargs["max_tokens"]

        # RAG-specific parameters
        if "documents" in kwargs:
            request_params["documents"] = kwargs["documents"]
        if "connectors" in kwargs:
            request_params["connectors"] = kwargs["connectors"]
        if "citation_quality" in kwargs:
            request_params["citation_quality"] = kwargs["citation_quality"]

        # Tool use
        if "tools" in kwargs:
            request_params["tools"] = self._format_tools(kwargs["tools"])

        try:
            response = await client.chat(**request_params)

            # Extract content
            content = response.text or ""

            # Extract citations if available
            citations = None
            if hasattr(response, "citations") and response.citations:
                citations = [
                    {
                        "start": c.start,
                        "end": c.end,
                        "text": c.text,
                        "document_ids": c.document_ids,
                    }
                    for c in response.citations
                ]

            # Extract usage
            usage = {}
            if hasattr(response, "meta") and response.meta:
                tokens = response.meta.tokens
                if tokens:
                    usage = {
                        "prompt_tokens": getattr(tokens, "input_tokens", 0),
                        "completion_tokens": getattr(tokens, "output_tokens", 0),
                        "total_tokens": (
                            getattr(tokens, "input_tokens", 0) + getattr(tokens, "output_tokens", 0)
                        ),
                    }

            # Calculate cost
            cost = self._calculate_cost(model, usage)
            self._total_cost += cost
            self._request_count += 1

            # Extract tool calls
            tool_calls = None
            if hasattr(response, "tool_calls") and response.tool_calls:
                tool_calls = [
                    {
                        "name": tc.name,
                        "parameters": tc.parameters,
                    }
                    for tc in response.tool_calls
                ]

            result = {
                "content": content,
                "model": model,
                "provider": "cohere",
                "usage": usage,
                "finish_reason": response.finish_reason or "COMPLETE",
                "cost": cost,
            }

            if citations:
                result["citations"] = citations

            if tool_calls:
                result["tool_calls"] = tool_calls

            return result

        except Exception as e:
            error_str = str(e).lower()
            if "rate" in error_str and "limit" in error_str:
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="cohere", model=model) from e
            if (
                "unauthorized" in error_str
                or "invalid api" in error_str
                or "authentication" in error_str
            ):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="cohere", model=model) from e
            if "not found" in error_str:
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="cohere", model=model) from e
            if "timeout" in error_str:
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="cohere", model=model) from e
            logger.error(f"Cohere request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream completion from Cohere.

        Args:
            messages: List of message dicts
            model: Model name
            **kwargs: Additional parameters

        Yields:
            Response chunks
        """
        client = self._get_client()

        # Format messages
        chat_history = []
        message = ""
        preamble = None

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                preamble = content
            elif role == "user":
                if message:
                    chat_history.append({"role": "USER", "message": message})
                message = content
            elif role == "assistant":
                chat_history.append({"role": "CHATBOT", "message": content})

        request_params: dict[str, Any] = {
            "model": model,
            "message": message,
        }

        if chat_history:
            request_params["chat_history"] = chat_history
        if preamble:
            request_params["preamble"] = preamble
        if "temperature" in kwargs:
            request_params["temperature"] = kwargs["temperature"]
        if "max_tokens" in kwargs:
            request_params["max_tokens"] = kwargs["max_tokens"]
        if "documents" in kwargs:
            request_params["documents"] = kwargs["documents"]

        try:
            stream = client.chat_stream(**request_params)

            async for event in stream:
                result: dict[str, Any] = {
                    "model": model,
                    "provider": "cohere",
                    "done": False,
                }

                if event.event_type == "text-generation":
                    result["content"] = event.text

                if event.event_type == "stream-end":
                    result["done"] = True
                    result["finish_reason"] = event.finish_reason

                    # Include citations at end
                    if hasattr(event, "response") and event.response:
                        if event.response.citations:
                            result["citations"] = [
                                {
                                    "start": c.start,
                                    "end": c.end,
                                    "text": c.text,
                                    "document_ids": c.document_ids,
                                }
                                for c in event.response.citations
                            ]

                yield result

        except Exception as e:
            error_str = str(e).lower()
            if "rate" in error_str and "limit" in error_str:
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="cohere", model=model) from e
            if (
                "unauthorized" in error_str
                or "invalid api" in error_str
                or "authentication" in error_str
            ):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="cohere", model=model) from e
            if "not found" in error_str:
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="cohere", model=model) from e
            if "timeout" in error_str:
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="cohere", model=model) from e
            logger.error(f"Cohere stream failed: {e}")
            raise

    async def rerank(
        self,
        query: str,
        documents: list[str | dict[str, Any]],
        model: str = "rerank-v3.5",
        top_n: int | None = None,
        return_documents: bool = True,
    ) -> list[dict[str, Any]]:
        """
        Rerank documents by relevance to query.

        Cohere's reranking models are optimized for search result
        reordering and retrieval augmentation.

        Args:
            query: Search query
            documents: List of documents (strings or dicts with 'text')
            model: Rerank model (default: rerank-v3.5)
            top_n: Number of results to return
            return_documents: Whether to return document text

        Returns:
            List of reranked results with index and relevance_score
        """
        client = self._get_client()

        try:
            response = await client.rerank(
                query=query,
                documents=documents,
                model=model,
                top_n=top_n,
                return_documents=return_documents,
            )

            results = []
            for r in response.results:
                result = {
                    "index": r.index,
                    "relevance_score": r.relevance_score,
                }
                if return_documents and hasattr(r, "document"):
                    result["document"] = r.document
                results.append(result)

            return results

        except Exception as e:
            logger.error(f"Cohere rerank failed: {e}")
            raise

    async def embed(
        self,
        texts: list[str],
        model: str = "embed-v4.0",
        input_type: str = "search_document",
        truncate: str = "END",
    ) -> list[list[float]]:
        """
        Generate embeddings for texts.

        Args:
            texts: List of texts to embed
            model: Embed model (default: embed-v4.0)
            input_type: Type of input (search_document, search_query, etc.)
            truncate: Truncation strategy (END, START, NONE)

        Returns:
            List of embedding vectors
        """
        client = self._get_client()

        try:
            response = await client.embed(
                texts=texts,
                model=model,
                input_type=input_type,
                truncate=truncate,
            )

            return response.embeddings

        except Exception as e:
            logger.error(f"Cohere embed failed: {e}")
            raise

    async def _initialize_internal(self) -> None:
        """Initialize Cohere provider internals."""
        if not self._api_key:
            logger.warning("Cohere provider initialized without API key")

    async def _shutdown_internal(self) -> None:
        """Shutdown Cohere provider internals."""
        if self._client:
            await self._client.close()
            self._client = None

    async def health_check(self) -> HealthStatus:
        """Check provider health."""
        if not self._api_key:
            return HealthStatus(healthy=False, message="No API key configured")

        try:
            client = self._get_client()
            # Simple chat as health check
            await client.chat(
                model="command-light",
                message="Hi",
            )
            return HealthStatus(healthy=True, message="Cohere API is accessible")
        except Exception as e:
            return HealthStatus(healthy=False, message=f"Cohere API error: {e}")

    def _format_tools(self, tools: list[Any]) -> list[dict[str, Any]]:
        """Format tools for Cohere API."""
        formatted = []
        for tool in tools:
            if isinstance(tool, dict):
                formatted.append(tool)
            else:
                formatted.append(
                    {
                        "name": getattr(tool, "name", "unknown"),
                        "description": getattr(tool, "description", ""),
                        "parameter_definitions": getattr(tool, "parameters", {}),
                    }
                )
        return formatted

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        """Calculate request cost (per 1M tokens)."""
        pricing = self.PRICING.get(model)
        if not pricing:
            # Default to command-r pricing
            pricing = self.PRICING["command-r"]

        input_cost = (usage.get("prompt_tokens", 0) / 1_000_000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1_000_000) * pricing["output"]
        return input_cost + output_cost

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics."""
        return {
            "provider": "cohere",
            "total_requests": self._request_count,
            "total_cost": round(self._total_cost, 6),
            "average_cost": round(self._total_cost / max(1, self._request_count), 6),
        }

    def supports_model(self, model: str) -> bool:
        """Check if model is supported."""
        return model in self.SUPPORTED_MODELS


__all__ = ["CohereProvider"]
