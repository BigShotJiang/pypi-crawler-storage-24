"""
Ollama Provider Implementation

Local model inference through Ollama.

Version: 0.1.0
Date: 2025-11-28
"""

import json
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

import httpx

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class OllamaProvider(BaseLLMProvider):
    """
    Ollama LLM provider for local model inference.

    Supports all Ollama models including Llama 2, Mistral, Mixtral, etc.

    Features:
    - Local inference (no API costs)
    - Streaming support
    - Model management (pull, list)
    - Embeddings support
    - Vision support (LLaVA)

    Example:
        ```python
        provider = OllamaProvider(config={"model": "llama2"})
        await provider.initialize()
        response = await provider.complete([{"role": "user", "content": "Hello"}])
        ```

    Requires the `httpx` package:
        pip install agenticraft-llm[ollama]
    """

    provider_name = "ollama"

    MODEL_INFO = {
        "llama2": {"size": "7B"},
        "llama2:13b": {"size": "13B"},
        "llama2:70b": {"size": "70B"},
        "llama3": {"size": "8B"},
        "llama3:70b": {"size": "70B"},
        "mistral": {"size": "7B"},
        "mixtral": {"size": "8x7B"},
        "phi": {"size": "2.7B"},
        "phi3": {"size": "3.8B"},
        "codellama": {"size": "7B"},
        "deepseek-coder": {"size": "7B"},
        "gemma": {"size": "7B"},
        "gemma2": {"size": "9B"},
        "qwen": {"size": "7B"},
        "qwen2": {"size": "7B"},
        "llava": {"size": "7B"},
        "nomic-embed-text": {"size": "137M"},
    }

    SUPPORTED_MODELS: set[str] = set(MODEL_INFO.keys())

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.VISION,
        LLMCapabilityType.EMBEDDINGS,
        LLMCapabilityType.CODE_GENERATION,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        model: str | None = None,
        base_url: str | None = None,
        timeout: int | None = None,
    ):
        """Initialize Ollama provider."""
        if config is None:
            config = {}

        if model is not None:
            config["model"] = model
        if base_url is not None:
            config["base_url"] = base_url
        if timeout is not None:
            config["timeout"] = timeout

        # Set base URL
        base_url = config.get("base_url")
        if not base_url:
            base_url = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
            if not base_url.startswith("http"):
                base_url = f"http://{base_url}"
        config["base_url"] = base_url

        config.setdefault("name", "ollama")
        config.setdefault("model", "llama2")
        config.setdefault("timeout", 300)  # Ollama can be slow
        config.setdefault("api_key", "ollama")  # Dummy key, not needed

        # Handle ollama/ prefix
        if config.get("model", "").startswith("ollama/"):
            config["model"] = config["model"][7:]

        super().__init__(config)

        self._request_count = 0
        self._total_duration_ms = 0.0
        self._http_client: httpx.AsyncClient | None = None

    @property
    def name(self) -> str:
        return "ollama"

    @property
    def default_model(self) -> str:
        model = self._config.get("model", "llama2")
        if model.startswith("ollama/"):
            model = model[7:]
        return model

    def _get_client(self) -> httpx.AsyncClient:
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(
                base_url=self._config.get("base_url", "http://localhost:11434"),
                timeout=httpx.Timeout(self._config.get("timeout", 300)),
            )
        return self._http_client

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._http_client = None

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Make completion request to Ollama."""
        if model.startswith("ollama/"):
            model = model[7:]

        client = self._get_client()

        # Format messages
        formatted_messages = self._format_messages(messages)

        # Build request
        request_body: dict[str, Any] = {
            "model": model,
            "messages": formatted_messages,
            "stream": False,
            "options": {
                "temperature": kwargs.get("temperature", 0.7),
            },
        }

        if "max_tokens" in kwargs:
            request_body["options"]["num_predict"] = kwargs["max_tokens"]
        if "top_p" in kwargs:
            request_body["options"]["top_p"] = kwargs["top_p"]
        if "top_k" in kwargs:
            request_body["options"]["top_k"] = kwargs["top_k"]

        try:
            response = await client.post("/api/chat", json=request_body)
            response.raise_for_status()
            data = response.json()

            message = data.get("message", {})
            content = message.get("content", "")

            prompt_tokens = data.get("prompt_eval_count", 0)
            completion_tokens = data.get("eval_count", 0)

            usage = {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens,
            }

            self._request_count += 1
            if data.get("total_duration"):
                self._total_duration_ms += data["total_duration"] / 1_000_000

            return {
                "content": content,
                "model": model,
                "provider": "ollama",
                "usage": usage,
                "finish_reason": data.get("done_reason", "stop"),
                "cost": 0.0,  # Ollama is free
            }

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(
                    f"Model '{model}' not found. Try: ollama pull {model}",
                    provider="ollama",
                    model=model,
                ) from e
            if e.response.status_code == 429:
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="ollama", model=model) from e
            from agenticraft_llm.exceptions import LLMProviderError

            raise LLMProviderError(
                str(e), provider="ollama", model=model, status_code=e.response.status_code
            ) from e
        except httpx.TimeoutException as e:
            from agenticraft_llm.exceptions import LLMTimeoutError

            raise LLMTimeoutError(str(e), provider="ollama", model=model) from e
        except httpx.ConnectError as e:
            from agenticraft_llm.exceptions import LLMProviderError

            raise LLMProviderError(
                f"Cannot connect to Ollama at {self._config.get('base_url')}. "
                "Is Ollama running? Start with: ollama serve",
                provider="ollama",
                model=model,
            ) from e
        except Exception as e:
            logger.error(f"Ollama request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """Stream completion from Ollama."""
        if model.startswith("ollama/"):
            model = model[7:]

        client = self._get_client()

        formatted_messages = self._format_messages(messages)

        request_body: dict[str, Any] = {
            "model": model,
            "messages": formatted_messages,
            "stream": True,
            "options": {
                "temperature": kwargs.get("temperature", 0.7),
            },
        }

        if "max_tokens" in kwargs:
            request_body["options"]["num_predict"] = kwargs["max_tokens"]

        try:
            async with client.stream("POST", "/api/chat", json=request_body) as response:
                response.raise_for_status()

                async for line in response.aiter_lines():
                    if line:
                        try:
                            chunk_data = json.loads(line)

                            result: dict[str, Any] = {
                                "model": model,
                                "provider": "ollama",
                                "done": False,
                            }

                            if "message" in chunk_data:
                                content = chunk_data["message"].get("content", "")
                                if content:
                                    result["content"] = content

                            if chunk_data.get("done", False):
                                result["done"] = True
                                result["finish_reason"] = chunk_data.get("done_reason", "stop")

                            yield result

                        except json.JSONDecodeError:
                            continue

        except httpx.TimeoutException as e:
            from agenticraft_llm.exceptions import LLMTimeoutError

            raise LLMTimeoutError(str(e), provider="ollama", model=model) from e
        except httpx.ConnectError as e:
            from agenticraft_llm.exceptions import LLMProviderError

            raise LLMProviderError(
                f"Cannot connect to Ollama at {self._config.get('base_url')}",
                provider="ollama",
                model=model,
            ) from e
        except Exception as e:
            logger.error(f"Ollama stream failed: {e}")
            raise

    async def _initialize_internal(self) -> None:
        """Initialize Ollama provider."""
        pass  # No special initialization needed

    async def _shutdown_internal(self) -> None:
        """Shutdown Ollama provider."""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None

    async def health_check(self) -> HealthStatus:
        """Check if Ollama is running."""
        try:
            client = self._get_client()
            response = await client.get("/api/tags")
            response.raise_for_status()
            return HealthStatus(healthy=True, message="Ollama is running")
        except httpx.ConnectError:
            return HealthStatus(
                healthy=False,
                message=f"Cannot connect to Ollama at {self._config.get('base_url')}",
            )
        except Exception as e:
            return HealthStatus(healthy=False, message=f"Ollama error: {e}")

    def _format_messages(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Format messages for Ollama API."""
        formatted = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            formatted.append({"role": role, "content": content})
        return formatted

    async def list_models(self) -> list[dict[str, Any]]:
        """List available models in Ollama."""
        try:
            client = self._get_client()
            response = await client.get("/api/tags")
            response.raise_for_status()
            data = response.json()
            return data.get("models", [])
        except Exception as e:
            logger.error(f"Failed to list Ollama models: {e}")
            return []

    def get_stats(self) -> dict[str, Any]:
        avg_duration = 0.0
        if self._request_count > 0:
            avg_duration = self._total_duration_ms / self._request_count

        return {
            "provider": "ollama",
            "total_requests": self._request_count,
            "average_latency_ms": round(avg_duration, 2),
            "total_cost": 0.0,
            "base_url": self._config.get("base_url"),
        }


__all__ = ["OllamaProvider"]
