"""
Azure OpenAI Provider Implementation

Enterprise-grade OpenAI access with Azure compliance and security.
HIPAA, GDPR, SOC2 compliant with regional data residency.

Version: 0.1.0
Date: 2025-12-12

Features:
- Enterprise compliance (HIPAA, GDPR, SOC2)
- Regional data residency
- Azure AD authentication
- Private endpoints support
- Content filtering
- Managed identity support

Note: Requires Azure OpenAI deployment and endpoint configuration
"""

import json
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class AzureOpenAIProvider(BaseLLMProvider):
    """
    Azure OpenAI provider for enterprise deployments.

    Azure OpenAI provides enterprise-grade access to OpenAI models
    with Azure's compliance certifications, regional data residency,
    and security features.

    Supports:
    - GPT-4o, GPT-4 Turbo, GPT-4
    - GPT-3.5 Turbo
    - o1, o1-mini (reasoning models)
    - Embeddings (text-embedding-ada-002, text-embedding-3-*)
    - DALL-E 3

    Authentication:
    - API Key (default)
    - Azure AD / Managed Identity
    - Service Principal

    Example:
        ```python
        # API Key authentication
        provider = AzureOpenAIProvider(
            api_key="...",
            azure_endpoint="https://your-resource.openai.azure.com",
            api_version="2024-10-21",
            deployment_name="gpt-4o-deployment"
        )
        await provider.initialize()
        response = await provider.complete([{"role": "user", "content": "Hello"}])

        # Azure AD authentication
        provider = AzureOpenAIProvider(
            azure_endpoint="https://your-resource.openai.azure.com",
            use_azure_ad=True,
        )
        ```

    Requires the `openai` package:
        pip install agenticraft-llm[azure_openai]
    """

    provider_name = "azure_openai"

    # Deployment name to model mapping (user configures deployments)
    # Azure uses deployment names, not model names directly
    DEFAULT_MODELS = {
        "gpt-4o",
        "gpt-4o-mini",
        "gpt-4-turbo",
        "gpt-4",
        "gpt-35-turbo",  # Azure naming
        "gpt-35-turbo-16k",
        "o1",
        "o1-mini",
        "text-embedding-ada-002",
        "text-embedding-3-small",
        "text-embedding-3-large",
    }

    # Pricing matches OpenAI but may vary by region
    # Azure pricing is typically similar to OpenAI (per 1M tokens)
    PRICING = {
        "gpt-4o": {"input": 2.50, "output": 10.00},
        "gpt-4o-mini": {"input": 0.15, "output": 0.60},
        "gpt-4-turbo": {"input": 10.00, "output": 30.00},
        "gpt-4": {"input": 30.00, "output": 60.00},
        "gpt-35-turbo": {"input": 0.50, "output": 1.50},
        "gpt-35-turbo-16k": {"input": 1.00, "output": 2.00},
        "o1": {"input": 15.00, "output": 60.00},
        "o1-mini": {"input": 3.00, "output": 12.00},
        "text-embedding-ada-002": {"input": 0.10, "output": 0},
        "text-embedding-3-small": {"input": 0.02, "output": 0},
        "text-embedding-3-large": {"input": 0.13, "output": 0},
    }

    SUPPORTED_MODELS: set[str] = DEFAULT_MODELS | set(PRICING.keys())

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.FUNCTION_CALLING,
        LLMCapabilityType.VISION,
        LLMCapabilityType.EMBEDDINGS,
        LLMCapabilityType.JSON_MODE,
        LLMCapabilityType.JSON_SCHEMA,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.TOOL_USE,
        LLMCapabilityType.REASONING,
        LLMCapabilityType.CODE_GENERATION,
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_key: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
    ):
        """
        Initialize Azure OpenAI provider.

        Args:
            config: Configuration dict with keys:
                - api_key: Azure OpenAI API key (or use AZURE_OPENAI_API_KEY env)
                - azure_endpoint: Azure OpenAI endpoint URL
                - api_version: API version (default: 2024-10-21)
                - deployment_name: Default deployment name
                - use_azure_ad: Use Azure AD authentication
                - timeout: Request timeout
                - max_retries: Max retry attempts
            api_key: Azure OpenAI API key (kwargs override)
            model: Default model/deployment name
            timeout: Request timeout in seconds
            max_retries: Max retry attempts
        """
        if config is None:
            config = {}

        if api_key is not None:
            config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if timeout is not None:
            config["timeout"] = timeout
        if max_retries is not None:
            config["max_retries"] = max_retries

        config.setdefault("name", "azure_openai")
        config.setdefault("api_version", "2024-10-21")
        config.setdefault("timeout", 60)
        config.setdefault("max_retries", 3)

        # Azure endpoint
        if "azure_endpoint" not in config:
            config["azure_endpoint"] = os.environ.get("AZURE_OPENAI_ENDPOINT") or os.environ.get(
                "AZURE_OPENAI_BASE_URL"
            )

        # API key
        if "api_key" not in config:
            config["api_key"] = os.environ.get("AZURE_OPENAI_API_KEY")

        # Deployment name
        if "deployment_name" not in config:
            config["deployment_name"] = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")

        super().__init__(config)

        self._total_cost = 0.0
        self._request_count = 0
        self._async_client: Any = None
        self._azure_credential: Any = None

    @property
    def name(self) -> str:
        return "azure_openai"

    @property
    def default_model(self) -> str:
        return self._config.get("deployment_name", "gpt-4o")

    def _get_client(self) -> Any:
        """Get or create async Azure OpenAI client."""
        if self._async_client is None:
            try:
                from openai import AsyncAzureOpenAI
            except ImportError:
                raise ImportError(
                    "Azure OpenAI provider requires 'openai' package. "
                    "Install with: pip install agenticraft-llm[azure_openai]"
                )

            # Check for Azure AD authentication
            if self._config.get("use_azure_ad"):
                try:
                    from azure.identity import DefaultAzureCredential

                    self._azure_credential = DefaultAzureCredential()

                    # Get token for Azure OpenAI
                    token = self._azure_credential.get_token(
                        "https://cognitiveservices.azure.com/.default"
                    )

                    self._async_client = AsyncAzureOpenAI(
                        azure_endpoint=self._config["azure_endpoint"],
                        api_version=self._config["api_version"],
                        azure_ad_token=token.token,
                        timeout=self._config.get("timeout", 60),
                        max_retries=0,
                    )
                except ImportError:
                    raise ImportError(
                        "Azure AD authentication requires 'azure-identity' package. "
                        "Install with: pip install azure-identity"
                    )
            else:
                # API key authentication
                self._async_client = AsyncAzureOpenAI(
                    api_key=self._api_key,
                    azure_endpoint=self._config["azure_endpoint"],
                    api_version=self._config["api_version"],
                    timeout=self._config.get("timeout", 60),
                    max_retries=0,
                )

        return self._async_client

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._async_client = None
        self._azure_credential = None

    def _resolve_deployment(self, model: str) -> str:
        """
        Resolve model name to deployment name.

        In Azure OpenAI, you deploy models under custom deployment names.
        This method maps model names to deployment names if configured.
        """
        deployments = self._config.get("deployments", {})
        return deployments.get(model, model)

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Make completion request to Azure OpenAI.

        Args:
            messages: List of message dicts
            model: Model/deployment name
            **kwargs: Additional parameters

        Returns:
            Response dict with content, model, provider, usage
        """
        client = self._get_client()
        deployment = self._resolve_deployment(model)

        # Build request params
        request_params: dict[str, Any] = {
            "model": deployment,
            "messages": messages,
        }

        # Add optional parameters
        for key in ["temperature", "max_tokens", "top_p", "stop", "n", "seed"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Handle JSON schema enforcement (Azure supports this)
        if kwargs.get("json_schema"):
            request_params["response_format"] = {
                "type": "json_schema",
                "json_schema": kwargs["json_schema"],
            }
            if kwargs.get("strict_json", True):
                request_params["response_format"]["strict"] = True
        elif kwargs.get("json_mode"):
            request_params["response_format"] = {"type": "json_object"}

        # Handle tools
        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        # Reasoning effort for o1 models
        if model.startswith("o1") and kwargs.get("reasoning_effort"):
            request_params["reasoning_effort"] = kwargs["reasoning_effort"]

        try:
            response = await client.chat.completions.create(**request_params)

            choice = response.choices[0]

            # Extract usage
            usage = {}
            if response.usage:
                usage = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }

            # Calculate cost
            cost = self._calculate_cost(model, usage)
            self._total_cost += cost
            self._request_count += 1

            # Extract tool calls
            tool_calls = None
            if hasattr(choice.message, "tool_calls") and choice.message.tool_calls:
                tool_calls = []
                for tc in choice.message.tool_calls:
                    try:
                        args = tc.function.arguments
                        if isinstance(args, str):
                            args = json.loads(args)
                        tool_calls.append(
                            {
                                "id": tc.id,
                                "name": tc.function.name,
                                "arguments": args,
                            }
                        )
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse tool arguments for {tc.function.name}")

            result = {
                "content": choice.message.content or "",
                "model": model,
                "provider": "azure_openai",
                "usage": usage,
                "finish_reason": choice.finish_reason,
                "cost": cost,
            }

            if tool_calls:
                result["tool_calls"] = tool_calls

            # Include content filter results if available
            if hasattr(response, "prompt_filter_results"):
                result["content_filter"] = {
                    "prompt": response.prompt_filter_results,
                    "completion": getattr(choice, "content_filter_results", None),
                }

            return result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"Azure OpenAI request failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="azure_openai", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="azure_openai", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="azure_openai", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="azure_openai", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="azure_openai",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"Azure OpenAI request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream completion from Azure OpenAI.

        Args:
            messages: List of message dicts
            model: Model/deployment name
            **kwargs: Additional parameters

        Yields:
            Response chunks
        """
        client = self._get_client()
        deployment = self._resolve_deployment(model)

        request_params: dict[str, Any] = {
            "model": deployment,
            "messages": messages,
            "stream": True,
        }

        for key in ["temperature", "max_tokens", "top_p"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            stream = await client.chat.completions.create(**request_params)

            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta

                    result: dict[str, Any] = {
                        "model": model,
                        "provider": "azure_openai",
                        "done": False,
                    }

                    if delta.content:
                        result["content"] = delta.content

                    if hasattr(delta, "tool_calls") and delta.tool_calls:
                        result["tool_call_delta"] = [
                            {
                                "index": tc.index,
                                "id": tc.id,
                                "name": tc.function.name if tc.function else None,
                                "arguments": tc.function.arguments if tc.function else None,
                            }
                            for tc in delta.tool_calls
                        ]

                    if chunk.choices[0].finish_reason:
                        result["done"] = True
                        result["finish_reason"] = chunk.choices[0].finish_reason

                    yield result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"Azure OpenAI stream failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="azure_openai", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="azure_openai", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="azure_openai", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="azure_openai", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="azure_openai",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"Azure OpenAI stream failed: {e}")
            raise

    async def embed(
        self,
        texts: list[str],
        model: str = "text-embedding-3-small",
    ) -> list[list[float]]:
        """
        Generate embeddings for texts.

        Args:
            texts: List of texts to embed
            model: Embedding model/deployment name

        Returns:
            List of embedding vectors
        """
        client = self._get_client()
        deployment = self._resolve_deployment(model)

        try:
            response = await client.embeddings.create(
                model=deployment,
                input=texts,
            )

            return [item.embedding for item in response.data]

        except Exception as e:
            logger.error(f"Azure OpenAI embed failed: {e}")
            raise

    async def _initialize_internal(self) -> None:
        """Initialize Azure OpenAI provider internals."""
        if not self._api_key and not self._config.get("use_azure_ad"):
            logger.warning("Azure OpenAI provider initialized without API key or Azure AD")

        if not self._config.get("azure_endpoint"):
            logger.warning("Azure OpenAI provider initialized without endpoint")

    async def _shutdown_internal(self) -> None:
        """Shutdown Azure OpenAI provider internals."""
        if self._async_client:
            await self._async_client.close()
            self._async_client = None

    async def health_check(self) -> HealthStatus:
        """Check provider health."""
        if not self._config.get("azure_endpoint"):
            return HealthStatus(healthy=False, message="No Azure endpoint configured")

        if not self._api_key and not self._config.get("use_azure_ad"):
            return HealthStatus(healthy=False, message="No authentication configured")

        try:
            client = self._get_client()
            deployment = self.default_model

            await client.chat.completions.create(
                model=deployment,
                max_tokens=1,
                messages=[{"role": "user", "content": "Hi"}],
            )
            return HealthStatus(healthy=True, message="Azure OpenAI API is accessible")
        except Exception as e:
            return HealthStatus(healthy=False, message=f"Azure OpenAI API error: {e}")

    def _format_tools(self, tools: list[Any]) -> list[dict[str, Any]]:
        """Format tools for Azure OpenAI API."""
        formatted = []
        for tool in tools:
            if hasattr(tool, "to_openai_schema"):
                formatted.append(tool.to_openai_schema())
            elif isinstance(tool, dict):
                formatted.append(tool)
            else:
                formatted.append(
                    {
                        "type": "function",
                        "function": {
                            "name": getattr(tool, "name", "unknown"),
                            "description": getattr(tool, "description", ""),
                            "parameters": getattr(tool, "parameters", {}),
                        },
                    }
                )
        return formatted

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        """Calculate request cost (per 1M tokens)."""
        # Normalize Azure model names
        normalized = model.replace("-", "").lower()
        pricing = None

        for price_model, prices in self.PRICING.items():
            if price_model.replace("-", "").lower() == normalized:
                pricing = prices
                break

        if not pricing:
            # Default to gpt-4o pricing
            pricing = self.PRICING["gpt-4o"]

        input_cost = (usage.get("prompt_tokens", 0) / 1_000_000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1_000_000) * pricing["output"]
        return input_cost + output_cost

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics."""
        return {
            "provider": "azure_openai",
            "total_requests": self._request_count,
            "total_cost": round(self._total_cost, 6),
            "average_cost": round(self._total_cost / max(1, self._request_count), 6),
            "endpoint": self._config.get("azure_endpoint", "not configured"),
            "api_version": self._config.get("api_version"),
        }

    def supports_model(self, model: str) -> bool:
        """Check if model is supported."""
        return model in self.SUPPORTED_MODELS

    def get_available_deployments(self) -> dict[str, str]:
        """Get configured deployment mappings."""
        return self._config.get("deployments", {})


__all__ = ["AzureOpenAIProvider"]
