"""
Google AI (Gemini) Provider Implementation

Full-featured Google Gemini provider.

Version: 0.1.0
Date: 2025-11-28
"""

import asyncio
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class GoogleProvider(BaseLLMProvider):
    """
    Google Gemini LLM provider.

    Supports Gemini Pro, Pro Vision, and Ultra models.

    Features:
    - Streaming support
    - Vision capabilities (Gemini Pro Vision)
    - Multi-turn conversations
    - Safety settings customization
    - Cost tracking

    Example:
        ```python
        provider = GoogleProvider(config={"api_key": "AIza..."})
        await provider.initialize()
        response = await provider.complete([{"role": "user", "content": "Hello"}])
        ```

    Requires the `google-generativeai` package:
        pip install agenticraft-llm[google]
    """

    provider_name = "google"

    MODEL_MAPPINGS = {
        # Gemini 1.x
        "gemini-pro": "gemini-pro",
        "gemini-pro-vision": "gemini-pro-vision",
        "gemini-ultra": "gemini-ultra",
        "gemini": "gemini-pro",
        "gemini-1.5-pro": "gemini-1.5-pro",
        "gemini-1.5-flash": "gemini-1.5-flash",
        # Gemini 2.x
        "gemini-2.0-flash": "gemini-2.0-flash",
        "gemini-2.0-flash-lite": "gemini-2.0-flash-lite",
        "gemini-2.5-pro": "gemini-2.5-pro",
        "gemini-2.5-flash": "gemini-2.5-flash",
    }

    # Pricing per 1K tokens (2025 - updated December 2024)
    PRICING = {
        # Gemini 1.x
        "gemini-pro": {"input": 0.00025, "output": 0.0005},
        "gemini-pro-vision": {"input": 0.00025, "output": 0.0005},
        "gemini-ultra": {"input": 0.007, "output": 0.021},
        "gemini-1.5-pro": {"input": 0.00125, "output": 0.005},
        "gemini-1.5-flash": {"input": 0.000075, "output": 0.0003},
        # Gemini 2.x (NEW - best cost/performance)
        "gemini-2.0-flash": {"input": 0.0001, "output": 0.0004},
        "gemini-2.0-flash-lite": {"input": 0.0001, "output": 0.0004},
        "gemini-2.5-pro": {"input": 0.00125, "output": 0.01},
        "gemini-2.5-flash": {"input": 0.0003, "output": 0.0025},
    }

    # Context caching pricing (90% discount on cached tokens)
    CACHE_PRICING = {
        "storage_per_hour": 1.0,  # Per million tokens stored
        "read_discount": 0.9,  # 90% discount for cached input
    }

    SUPPORTED_MODELS: set[str] = {
        # Gemini 1.x
        "gemini-pro",
        "gemini-pro-vision",
        "gemini-ultra",
        "gemini-1.5-pro",
        "gemini-1.5-flash",
        # Gemini 2.x
        "gemini-2.0-flash",
        "gemini-2.0-flash-lite",
        "gemini-2.5-pro",
        "gemini-2.5-flash",
    }

    # Models that support context caching
    CACHE_SUPPORTED_MODELS: set[str] = {
        "gemini-1.5-pro",
        "gemini-1.5-flash",
        "gemini-2.0-flash",
        "gemini-2.5-pro",
        "gemini-2.5-flash",
    }

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.VISION,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.FUNCTION_CALLING,
        LLMCapabilityType.JSON_MODE,
        LLMCapabilityType.CODE_GENERATION,
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_key: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
    ):
        """Initialize Google provider."""
        if config is None:
            config = {}

        if api_key is not None:
            config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if timeout is not None:
            config["timeout"] = timeout
        if max_retries is not None:
            config["max_retries"] = max_retries

        config.setdefault("name", "google")
        config.setdefault("model", "gemini-pro")
        config.setdefault("timeout", 60)

        if "api_key" not in config:
            env_key = os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY")
            if env_key:
                config["api_key"] = env_key

        super().__init__(config)

        self._total_cost = 0.0
        self._request_count = 0
        self._genai: Any = None
        self._model_cache: dict[str, Any] = {}

    @property
    def name(self) -> str:
        return "google"

    @property
    def default_model(self) -> str:
        model = self._config.get("model", "gemini-pro")
        return self.MODEL_MAPPINGS.get(model, model)

    def _get_genai(self) -> Any:
        if self._genai is None:
            try:
                import google.generativeai as genai

                genai.configure(api_key=self._api_key)
                self._genai = genai
            except ImportError:
                raise ImportError(
                    "Google provider requires 'google-generativeai' package. "
                    "Install with: pip install agenticraft-llm[google]"
                )
        return self._genai

    def _get_model(self, model_name: str) -> Any:
        if model_name not in self._model_cache:
            genai = self._get_genai()
            self._model_cache[model_name] = genai.GenerativeModel(model_name)
        return self._model_cache[model_name]

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._genai = None
        self._model_cache.clear()

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Make completion request to Google Gemini."""
        model = self.MODEL_MAPPINGS.get(model, model)
        model_instance = self._get_model(model)

        # Format messages for Gemini
        prompt = self._format_messages(messages)

        # Build generation config
        generation_config = {"temperature": kwargs.get("temperature", 0.7)}

        if "max_tokens" in kwargs:
            generation_config["max_output_tokens"] = kwargs["max_tokens"]
        if "top_p" in kwargs:
            generation_config["top_p"] = kwargs["top_p"]
        if "top_k" in kwargs:
            generation_config["top_k"] = kwargs["top_k"]

        try:
            response = await asyncio.to_thread(
                model_instance.generate_content,
                prompt,
                generation_config=generation_config,
            )

            # Extract content
            content = ""
            if response.parts:
                content = "".join(part.text for part in response.parts if hasattr(part, "text"))

            # Extract usage
            usage = {}
            if hasattr(response, "usage_metadata"):
                meta = response.usage_metadata
                usage = {
                    "prompt_tokens": getattr(meta, "prompt_token_count", 0),
                    "completion_tokens": getattr(meta, "candidates_token_count", 0),
                    "total_tokens": getattr(meta, "total_token_count", 0),
                }

            cost = self._calculate_cost(model, usage)
            self._total_cost += cost
            self._request_count += 1

            return {
                "content": content,
                "model": model,
                "provider": "google",
                "usage": usage,
                "finish_reason": "stop",
                "cost": cost,
            }

        except Exception as e:
            error_str = str(e).lower()
            if "api key" in error_str or "authentication" in error_str or "permission" in error_str:
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="google", model=model) from e
            if "not found" in error_str or "does not exist" in error_str:
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="google", model=model) from e
            if "timeout" in error_str or "timed out" in error_str:
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="google", model=model) from e
            if "rate" in error_str and "limit" in error_str:
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="google", model=model) from e
            if "quota" in error_str:
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="google", model=model) from e
            logger.error(f"Google request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """Stream completion from Google Gemini."""
        model = self.MODEL_MAPPINGS.get(model, model)
        model_instance = self._get_model(model)

        prompt = self._format_messages(messages)

        generation_config = {
            "temperature": kwargs.get("temperature", 0.7),
        }
        if "max_tokens" in kwargs:
            generation_config["max_output_tokens"] = kwargs["max_tokens"]

        try:
            stream_response = await asyncio.to_thread(
                model_instance.generate_content,
                prompt,
                generation_config=generation_config,
                stream=True,
            )

            for chunk in stream_response:
                result: dict[str, Any] = {
                    "model": model,
                    "provider": "google",
                    "done": False,
                }

                if chunk.parts:
                    for part in chunk.parts:
                        if hasattr(part, "text") and part.text:
                            result["content"] = part.text

                yield result

            # Final chunk
            yield {
                "model": model,
                "provider": "google",
                "done": True,
                "finish_reason": "stop",
            }

        except Exception as e:
            error_str = str(e).lower()
            if "api key" in error_str or "authentication" in error_str or "permission" in error_str:
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="google", model=model) from e
            if "not found" in error_str or "does not exist" in error_str:
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="google", model=model) from e
            if "timeout" in error_str or "timed out" in error_str:
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="google", model=model) from e
            if "rate" in error_str and "limit" in error_str:
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="google", model=model) from e
            if "quota" in error_str:
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="google", model=model) from e
            logger.error(f"Google stream failed: {e}")
            raise

    async def _initialize_internal(self) -> None:
        if not self._api_key:
            logger.warning("Google provider initialized without API key")

    async def _shutdown_internal(self) -> None:
        self._model_cache.clear()
        self._genai = None

    async def health_check(self) -> HealthStatus:
        if not self._api_key:
            return HealthStatus(healthy=False, message="No API key configured")

        try:
            genai = self._get_genai()
            # List models as health check
            list(genai.list_models())
            return HealthStatus(healthy=True, message="Google API is accessible")
        except Exception as e:
            return HealthStatus(healthy=False, message=f"Google API error: {e}")

    def _format_messages(self, messages: list[dict[str, Any]]) -> str:
        """Format messages for Gemini (expects single text prompt)."""
        prompt_parts = []

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                prompt_parts.append(f"Instructions: {content}")
            elif role == "user":
                prompt_parts.append(f"User: {content}")
            elif role == "assistant":
                prompt_parts.append(f"Assistant: {content}")
            else:
                prompt_parts.append(f"{role.title()}: {content}")

        prompt_parts.append("Assistant:")
        return "\n\n".join(prompt_parts)

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        pricing = self.PRICING.get(model, self.PRICING["gemini-pro"])
        input_cost = (usage.get("prompt_tokens", 0) / 1000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1000) * pricing["output"]
        return input_cost + output_cost

    def get_stats(self) -> dict[str, Any]:
        return {
            "provider": "google",
            "total_requests": self._request_count,
            "total_cost": round(self._total_cost, 4),
            "average_cost": round(self._total_cost / max(1, self._request_count), 4),
        }


__all__ = ["GoogleProvider"]
