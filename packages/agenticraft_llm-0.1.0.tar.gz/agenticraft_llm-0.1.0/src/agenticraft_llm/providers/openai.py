"""
OpenAI Provider Implementation

Full-featured OpenAI provider with GPT-4, GPT-5, embeddings, and tool support.
"""

import json
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class OpenAIProvider(BaseLLMProvider):
    """
    OpenAI LLM provider.

    Supports all OpenAI models including GPT-5, GPT-4o, o-series, and embeddings.

    Example:
        provider = OpenAIProvider(api_key="sk-...")
        await provider.initialize()
        response = await provider.complete([{"role": "user", "content": "Hello"}])
    """

    provider_name = "openai"

    PRICING = {
        "gpt-5": {"input": 0.00125, "output": 0.01},
        "gpt-5.1": {"input": 0.00125, "output": 0.01},
        "gpt-5.2": {"input": 0.00175, "output": 0.014},
        "gpt-5-mini": {"input": 0.00025, "output": 0.002},
        "gpt-5-nano": {"input": 0.00005, "output": 0.0004},
        "gpt-4o": {"input": 0.0025, "output": 0.01},
        "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
        "gpt-4o-2024-08-06": {"input": 0.0025, "output": 0.01},
        "gpt-4.1": {"input": 0.002, "output": 0.008},
        "o1": {"input": 0.015, "output": 0.06},
        "o1-mini": {"input": 0.003, "output": 0.012},
        "o1-preview": {"input": 0.015, "output": 0.06},
        "o3": {"input": 0.015, "output": 0.06},
        "o3-mini": {"input": 0.0011, "output": 0.0044},
        "gpt-4-turbo": {"input": 0.01, "output": 0.03},
        "gpt-4-turbo-preview": {"input": 0.01, "output": 0.03},
        "gpt-4": {"input": 0.03, "output": 0.06},
        "gpt-4-32k": {"input": 0.06, "output": 0.12},
        "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
        "gpt-3.5-turbo-16k": {"input": 0.003, "output": 0.004},
        "text-embedding-ada-002": {"input": 0.0001, "output": 0},
        "text-embedding-3-small": {"input": 0.00002, "output": 0},
        "text-embedding-3-large": {"input": 0.00013, "output": 0},
    }

    SUPPORTED_MODELS: set[str] = {
        "gpt-5",
        "gpt-5.1",
        "gpt-5.2",
        "gpt-5-mini",
        "gpt-5-nano",
        "gpt-4o",
        "gpt-4o-mini",
        "gpt-4o-2024-08-06",
        "gpt-4.1",
        "o1",
        "o1-mini",
        "o1-preview",
        "o3",
        "o3-mini",
        "gpt-4-turbo",
        "gpt-4-turbo-preview",
        "gpt-4",
        "gpt-4-32k",
        "gpt-3.5-turbo",
        "gpt-3.5-turbo-16k",
        "text-embedding-ada-002",
        "text-embedding-3-small",
        "text-embedding-3-large",
    }

    REASONING_MODELS: set[str] = {"o1", "o1-mini", "o1-preview", "o3", "o3-mini"}

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.FUNCTION_CALLING,
        LLMCapabilityType.VISION,
        LLMCapabilityType.EMBEDDINGS,
        LLMCapabilityType.JSON_MODE,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.TOOL_USE,
        LLMCapabilityType.CODE_GENERATION,
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_key: str | None = None,
        api_keys: list[str] | None = None,
        key_rotation_strategy: str = "adaptive",
        model: str | None = None,
        base_url: str | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
    ):
        if config is None:
            config = {}

        if api_key is not None:
            config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if base_url is not None:
            config["base_url"] = base_url
        if timeout is not None:
            config["timeout"] = timeout
        if max_retries is not None:
            config["max_retries"] = max_retries

        config.setdefault("name", "openai")
        config.setdefault("model", "gpt-4-turbo")
        config.setdefault("timeout", 60)
        config.setdefault("max_retries", 3)

        # Handle multiple API keys
        keys_to_use: list[str] | None = None
        if api_keys:
            keys_to_use = api_keys
        elif config.get("api_keys"):
            keys_to_use = config["api_keys"]
        else:
            env_keys = os.environ.get("OPENAI_API_KEYS")
            if env_keys:
                keys_to_use = [k.strip() for k in env_keys.split(",") if k.strip()]

        if not keys_to_use and "api_key" not in config:
            env_key = os.environ.get("OPENAI_API_KEY")
            if env_key:
                config["api_key"] = env_key

        super().__init__(config, api_keys=keys_to_use, key_rotation_strategy=key_rotation_strategy)

        self._total_cost = 0.0
        self._request_count = 0
        self._async_client: Any = None

    @property
    def name(self) -> str:
        return "openai"

    @property
    def default_model(self) -> str:
        return self._config.get("model", "gpt-4-turbo")

    def _get_client(self) -> Any:
        if self._async_client is None:
            try:
                from openai import AsyncOpenAI

                self._async_client = AsyncOpenAI(
                    api_key=self._api_key,
                    base_url=self._config.get("base_url"),
                    timeout=self._config.get("timeout", 60),
                    max_retries=0,
                )
            except ImportError:
                raise ImportError(
                    "OpenAI provider requires 'openai' package. "
                    "Install with: pip install agenticraft-llm[openai]"
                )
        return self._async_client

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._async_client = None

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        client = self._get_client()

        request_params: dict[str, Any] = {"model": model, "messages": messages}

        for key in [
            "temperature",
            "max_tokens",
            "top_p",
            "frequency_penalty",
            "presence_penalty",
            "seed",
            "stop",
            "n",
        ]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        if kwargs.get("json_schema"):
            request_params["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": kwargs.get("schema_name", "response"),
                    "schema": kwargs["json_schema"],
                    "strict": kwargs.get("strict_json", True),
                },
            }
        elif kwargs.get("json_mode"):
            request_params["response_format"] = {"type": "json_object"}
        elif "response_format" in kwargs and kwargs["response_format"] is not None:
            request_params["response_format"] = kwargs["response_format"]

        if model in self.REASONING_MODELS and kwargs.get("reasoning_effort"):
            request_params["reasoning_effort"] = kwargs["reasoning_effort"]

        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            response = await client.chat.completions.create(**request_params)
            choice = response.choices[0]

            usage = {}
            if response.usage:
                usage = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }

            cost = self._calculate_cost(model, usage)
            self._total_cost += cost
            self._request_count += 1

            tool_calls = None
            if hasattr(choice.message, "tool_calls") and choice.message.tool_calls:
                tool_calls = []
                for tc in choice.message.tool_calls:
                    try:
                        args = tc.function.arguments
                        if isinstance(args, str):
                            args = json.loads(args)
                        tool_calls.append(
                            {
                                "id": tc.id,
                                "name": tc.function.name,
                                "arguments": args,
                            }
                        )
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse tool arguments for {tc.function.name}")

            result = {
                "content": choice.message.content or "",
                "model": model,
                "provider": "openai",
                "usage": usage,
                "finish_reason": choice.finish_reason,
                "cost": cost,
            }

            if tool_calls:
                result["tool_calls"] = tool_calls

            return result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"OpenAI request failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="openai", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="openai", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="openai", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="openai", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="openai",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"OpenAI request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        client = self._get_client()

        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": True,
        }

        for key in ["temperature", "max_tokens", "top_p"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            stream = await client.chat.completions.create(**request_params)
            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta
                    result: dict[str, Any] = {
                        "model": model,
                        "provider": "openai",
                        "done": False,
                    }
                    if delta.content:
                        result["content"] = delta.content
                    if hasattr(delta, "tool_calls") and delta.tool_calls:
                        result["tool_call_delta"] = [
                            {
                                "index": tc.index,
                                "id": tc.id,
                                "name": tc.function.name if tc.function else None,
                                "arguments": tc.function.arguments if tc.function else None,
                            }
                            for tc in delta.tool_calls
                        ]
                    if chunk.choices[0].finish_reason:
                        result["done"] = True
                        result["finish_reason"] = chunk.choices[0].finish_reason
                    yield result
        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"OpenAI stream failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="openai", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="openai", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="openai", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="openai", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="openai",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"OpenAI stream failed: {e}")
            raise

    async def _init_client(self) -> None:
        if not self._api_key:
            logger.warning("OpenAI provider initialized without API key")

    async def health_check(self) -> HealthStatus:
        if not self._api_key:
            return HealthStatus(healthy=False, message="No API key configured")
        try:
            client = self._get_client()
            await client.models.list()
            return HealthStatus(healthy=True, message="OpenAI API is accessible")
        except Exception as e:
            return HealthStatus(healthy=False, message=f"OpenAI API error: {e}")

    async def embed(
        self, texts: list[str], model: str | None = None, **kwargs: Any
    ) -> list[list[float]]:
        """Generate embeddings."""
        client = self._get_client()
        embed_model = model or "text-embedding-3-small"
        try:
            response = await client.embeddings.create(model=embed_model, input=texts)
            return [item.embedding for item in response.data]
        except Exception as e:
            try:
                from openai import APIError, APITimeoutError, AuthenticationError, RateLimitError
            except ImportError:
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="openai", model=embed_model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="openai", model=embed_model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="openai", model=embed_model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="openai",
                    model=embed_model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            raise

    def _format_tools(self, tools: list[Any]) -> list[dict[str, Any]]:
        formatted = []
        for tool in tools:
            if hasattr(tool, "to_openai_schema"):
                formatted.append(tool.to_openai_schema())
            elif isinstance(tool, dict):
                formatted.append(tool)
            else:
                formatted.append(
                    {
                        "type": "function",
                        "function": {
                            "name": getattr(tool, "name", "unknown"),
                            "description": getattr(tool, "description", ""),
                            "parameters": getattr(tool, "parameters", {}),
                        },
                    }
                )
        return formatted

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        pricing = self.PRICING.get(model)
        if not pricing:
            for prefix, price in self.PRICING.items():
                if model.startswith(prefix):
                    pricing = price
                    break
        if not pricing:
            logger.warning(f"Unknown model '{model}' for cost calculation, using default pricing")
            pricing = self.PRICING["gpt-3.5-turbo"]

        input_cost = (usage.get("prompt_tokens", 0) / 1000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1000) * pricing["output"]
        return input_cost + output_cost

    def get_stats(self) -> dict[str, Any]:
        return {
            "provider": "openai",
            "total_requests": self._request_count,
            "total_cost": round(self._total_cost, 4),
            "average_cost": round(self._total_cost / max(1, self._request_count), 4),
        }


__all__ = ["OpenAIProvider"]
