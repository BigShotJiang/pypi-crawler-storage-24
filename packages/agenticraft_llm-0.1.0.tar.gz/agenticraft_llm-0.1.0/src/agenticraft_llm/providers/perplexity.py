"""
Perplexity Provider Implementation

Search-augmented LLM provider with real-time web grounding.
Returns answers with citations from live web search.

Version: 0.1.0
Date: 2025-12-12

Features:
- Real-time web search integration
- Citation generation with source URLs
- Search recency filtering (day, week, month, year)
- Domain filtering (include/exclude)
- Multiple search depth modes
- OpenAI-compatible API

Note: Requires PERPLEXITY_API_KEY environment variable
"""

import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class PerplexityProvider(BaseLLMProvider):
    """
    Perplexity LLM provider with search augmentation.

    Perplexity provides search-augmented generation with real-time
    web search, returning answers grounded in current information
    with citations to sources.

    Supports:
    - sonar (lightweight, fast Q&A)
    - sonar-pro (advanced, multi-step queries)
    - sonar-reasoning (advanced reasoning)
    - sonar-reasoning-pro (high-performance reasoning)
    - sonar-deep-research (complex research tasks)

    Example:
        ```python
        provider = PerplexityProvider(api_key="pplx-...")
        await provider.initialize()

        # Basic search-augmented query
        response = await provider.complete(
            [{"role": "user", "content": "What happened today?"}],
            model="sonar"
        )
        # response includes citations

        # With search filters
        response = await provider.complete(
            [{"role": "user", "content": "Latest AI news"}],
            model="sonar-pro",
            search_recency_filter="week",
            return_citations=True
        )
        ```
    """

    provider_name = "perplexity"

    # Pricing per 1M tokens (2025) + $5/1K searches
    PRICING = {
        "sonar": {"input": 1.00, "output": 1.00},
        "sonar-pro": {"input": 3.00, "output": 15.00},
        "sonar-reasoning": {"input": 1.00, "output": 5.00},
        "sonar-reasoning-pro": {"input": 2.00, "output": 8.00},
        "sonar-deep-research": {"input": 2.00, "output": 8.00},
    }

    # Search fee per 1K searches
    SEARCH_FEE_PER_1K = 5.00

    SUPPORTED_MODELS: set[str] = set(PRICING.keys())

    # Models with reasoning capabilities
    REASONING_MODELS: set[str] = {
        "sonar-reasoning",
        "sonar-reasoning-pro",
        "sonar-deep-research",
    }

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.SEARCH_GROUNDING,
        LLMCapabilityType.REASONING,
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_key: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
    ):
        """
        Initialize Perplexity provider.

        Args:
            config: Configuration dict with optional keys:
                - api_key: Perplexity API key
                - model: Default model (default: sonar)
                - base_url: API base URL
                - timeout: Request timeout
                - max_retries: Max retry attempts
                - return_citations: Default citation behavior
                - search_recency_filter: Default recency filter
            api_key: Perplexity API key (kwargs override)
            model: Default model
            timeout: Request timeout in seconds
            max_retries: Max retry attempts
        """
        if config is None:
            config = {}

        if api_key is not None:
            config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if timeout is not None:
            config["timeout"] = timeout
        if max_retries is not None:
            config["max_retries"] = max_retries

        config.setdefault("name", "perplexity")
        config.setdefault("model", "sonar")
        config.setdefault("base_url", "https://api.perplexity.ai")
        config.setdefault("timeout", 60)
        config.setdefault("max_retries", 3)
        config.setdefault("return_citations", True)

        if "api_key" not in config:
            env_key = os.environ.get("PERPLEXITY_API_KEY")
            if env_key:
                config["api_key"] = env_key

        super().__init__(config)

        self._total_cost = 0.0
        self._search_count = 0
        self._request_count = 0
        self._async_client: Any = None

    @property
    def name(self) -> str:
        return "perplexity"

    @property
    def default_model(self) -> str:
        return self._config.get("model", "sonar")

    def _get_client(self) -> Any:
        """Get or create async OpenAI-compatible client."""
        if self._async_client is None:
            try:
                from openai import AsyncOpenAI

                self._async_client = AsyncOpenAI(
                    api_key=self._api_key,
                    base_url=self._config.get("base_url", "https://api.perplexity.ai"),
                    timeout=self._config.get("timeout", 60),
                    max_retries=0,
                )
            except ImportError:
                raise ImportError(
                    "Perplexity provider requires 'openai' package. "
                    "Install with: pip install agenticraft-llm[perplexity]"
                )
        return self._async_client

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._async_client = None

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Make completion request to Perplexity.

        Args:
            messages: List of message dicts
            model: Model name
            **kwargs: Additional parameters including:
                - search_recency_filter: "day", "week", "month", "year"
                - return_citations: Whether to return source citations
                - search_domain_filter: List of domains to include/exclude

        Returns:
            Response dict with content, citations, model, provider, usage
        """
        client = self._get_client()

        # Build request params
        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
        }

        # Add optional parameters
        for key in ["temperature", "max_tokens", "top_p"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Perplexity-specific parameters
        # Search recency filter
        search_recency = kwargs.get(
            "search_recency_filter", self._config.get("search_recency_filter")
        )
        if search_recency:
            request_params["search_recency_filter"] = search_recency

        # Return citations (default True for Perplexity)
        return_citations = kwargs.get(
            "return_citations", self._config.get("return_citations", True)
        )
        if return_citations is not None:
            request_params["return_citations"] = return_citations

        # Domain filtering
        if "search_domain_filter" in kwargs:
            request_params["search_domain_filter"] = kwargs["search_domain_filter"]

        try:
            response = await client.chat.completions.create(**request_params)

            choice = response.choices[0]

            # Extract usage
            usage = {}
            if response.usage:
                usage = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }

            # Calculate cost (tokens + search fee)
            cost = self._calculate_cost(model, usage)
            self._total_cost += cost
            self._request_count += 1
            self._search_count += 1  # Each request is a search

            result = {
                "content": choice.message.content or "",
                "model": model,
                "provider": "perplexity",
                "usage": usage,
                "finish_reason": choice.finish_reason,
                "cost": cost,
            }

            # Extract citations if available
            if hasattr(response, "citations") and response.citations:
                result["citations"] = response.citations

            # Alternative: citations might be in the response object directly
            if hasattr(choice.message, "citations"):
                result["citations"] = choice.message.citations

            return result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"Perplexity request failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="perplexity", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="perplexity", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="perplexity", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="perplexity", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="perplexity",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"Perplexity request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream completion from Perplexity.

        Args:
            messages: List of message dicts
            model: Model name
            **kwargs: Additional parameters

        Yields:
            Response chunks
        """
        client = self._get_client()

        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": True,
        }

        for key in ["temperature", "max_tokens", "top_p"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Perplexity-specific parameters
        if kwargs.get("search_recency_filter"):
            request_params["search_recency_filter"] = kwargs["search_recency_filter"]

        if kwargs.get("return_citations") is not None:
            request_params["return_citations"] = kwargs["return_citations"]

        if "search_domain_filter" in kwargs:
            request_params["search_domain_filter"] = kwargs["search_domain_filter"]

        try:
            stream = await client.chat.completions.create(**request_params)

            citations_collected = []

            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta

                    result: dict[str, Any] = {
                        "model": model,
                        "provider": "perplexity",
                        "done": False,
                    }

                    if delta.content:
                        result["content"] = delta.content

                    if hasattr(delta, "tool_calls") and delta.tool_calls:
                        result["tool_call_delta"] = [
                            {
                                "index": tc.index,
                                "id": tc.id,
                                "name": tc.function.name if tc.function else None,
                                "arguments": tc.function.arguments if tc.function else None,
                            }
                            for tc in delta.tool_calls
                        ]

                    # Collect citations from stream if available
                    if hasattr(chunk, "citations") and chunk.citations:
                        citations_collected.extend(chunk.citations)

                    if chunk.choices[0].finish_reason:
                        result["done"] = True
                        result["finish_reason"] = chunk.choices[0].finish_reason

                        # Include all collected citations at the end
                        if citations_collected:
                            result["citations"] = citations_collected

                    yield result

            self._search_count += 1

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"Perplexity stream failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="perplexity", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="perplexity", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="perplexity", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="perplexity", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="perplexity",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"Perplexity stream failed: {e}")
            raise

    async def search(
        self,
        query: str,
        model: str = "sonar",
        recency: str | None = None,
        domains: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Convenience method for search-augmented queries.

        Args:
            query: Search query
            model: Model to use
            recency: Recency filter ("day", "week", "month", "year")
            domains: Domain filter list

        Returns:
            Response with content and citations
        """
        kwargs: dict[str, Any] = {"return_citations": True}

        if recency:
            kwargs["search_recency_filter"] = recency
        if domains:
            kwargs["search_domain_filter"] = domains

        return await self.complete(
            messages=[{"role": "user", "content": query}], model=model, **kwargs
        )

    async def _initialize_internal(self) -> None:
        """Initialize Perplexity provider internals."""
        if not self._api_key:
            logger.warning("Perplexity provider initialized without API key")

    async def _shutdown_internal(self) -> None:
        """Shutdown Perplexity provider internals."""
        if self._async_client:
            await self._async_client.close()
            self._async_client = None

    async def health_check(self) -> HealthStatus:
        """Check provider health."""
        if not self._api_key:
            return HealthStatus(healthy=False, message="No API key configured")

        try:
            client = self._get_client()
            await client.chat.completions.create(
                model="sonar",
                max_tokens=10,
                messages=[{"role": "user", "content": "Hi"}],
            )
            return HealthStatus(healthy=True, message="Perplexity API is accessible")
        except Exception as e:
            return HealthStatus(healthy=False, message=f"Perplexity API error: {e}")

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        """Calculate request cost (tokens + search fee)."""
        pricing = self.PRICING.get(model)
        if not pricing:
            pricing = self.PRICING["sonar"]

        # Token costs (per 1M tokens)
        input_cost = (usage.get("prompt_tokens", 0) / 1_000_000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1_000_000) * pricing["output"]

        # Search fee (per request, $5/1K = $0.005 per request)
        search_cost = self.SEARCH_FEE_PER_1K / 1000

        return input_cost + output_cost + search_cost

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics including search count."""
        return {
            "provider": "perplexity",
            "total_requests": self._request_count,
            "total_searches": self._search_count,
            "total_cost": round(self._total_cost, 6),
            "average_cost": round(self._total_cost / max(1, self._request_count), 6),
        }

    def supports_model(self, model: str) -> bool:
        """Check if model is supported."""
        return model in self.SUPPORTED_MODELS

    def is_reasoning_model(self, model: str) -> bool:
        """Check if model supports reasoning."""
        return model in self.REASONING_MODELS


__all__ = ["PerplexityProvider"]
