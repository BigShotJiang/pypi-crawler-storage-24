"""
DeepSeek Provider Implementation

Ultra-low cost LLM provider with advanced reasoning capabilities.
DeepSeek-R1 provides visible chain-of-thought reasoning comparable to o1.

Version: 0.1.0
Date: 2025-12-12

Features:
- Ultra-low cost ($0.27/1M input tokens)
- Advanced reasoning with visible chain-of-thought
- 128K context (chat), 64K context (reasoner)
- Up to 64K output tokens for reasoner
- OpenAI-compatible API

Note: Requires DEEPSEEK_API_KEY environment variable
"""

import json
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class DeepSeekProvider(BaseLLMProvider):
    """
    DeepSeek LLM provider with ultra-low cost and reasoning.

    DeepSeek offers extremely cost-effective LLM access with
    advanced reasoning capabilities. DeepSeek-R1 provides
    visible chain-of-thought reasoning comparable to OpenAI o1.

    Supports:
    - deepseek-chat (671B params, 37B active, 128K context)
    - deepseek-reasoner (R1 model, 64K context, visible CoT)

    Example:
        ```python
        provider = DeepSeekProvider(api_key="sk-...")
        await provider.initialize()

        # Standard chat
        response = await provider.complete(
            [{"role": "user", "content": "Hello"}],
            model="deepseek-chat"
        )

        # Reasoning with visible chain-of-thought
        response = await provider.complete(
            [{"role": "user", "content": "Solve this math problem..."}],
            model="deepseek-reasoner"
        )
        # response may include reasoning_content
        ```
    """

    provider_name = "deepseek"

    # Pricing per 1M tokens (2025)
    PRICING = {
        "deepseek-chat": {"input": 0.27, "output": 1.10},
        "deepseek-reasoner": {"input": 0.55, "output": 2.19},
    }

    SUPPORTED_MODELS: set[str] = {
        "deepseek-chat",
        "deepseek-reasoner",
    }

    # Models with reasoning capabilities
    REASONING_MODELS: set[str] = {"deepseek-reasoner"}

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.FUNCTION_CALLING,
        LLMCapabilityType.JSON_MODE,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.TOOL_USE,
        LLMCapabilityType.REASONING,
        LLMCapabilityType.EXTENDED_THINKING,
        LLMCapabilityType.CODE_GENERATION,
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_key: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
    ):
        """
        Initialize DeepSeek provider.

        Args:
            config: Configuration dict with optional keys:
                - api_key: DeepSeek API key
                - model: Default model (default: deepseek-chat)
                - base_url: API base URL
                - timeout: Request timeout
                - max_retries: Max retry attempts
            api_key: DeepSeek API key (kwargs override)
            model: Default model
            timeout: Request timeout in seconds
            max_retries: Max retry attempts
        """
        if config is None:
            config = {}

        if api_key is not None:
            config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if timeout is not None:
            config["timeout"] = timeout
        if max_retries is not None:
            config["max_retries"] = max_retries

        config.setdefault("name", "deepseek")
        config.setdefault("model", "deepseek-chat")
        config.setdefault("base_url", "https://api.deepseek.com/v1")
        config.setdefault("timeout", 120)  # Longer for reasoning
        config.setdefault("max_retries", 3)

        if "api_key" not in config:
            env_key = os.environ.get("DEEPSEEK_API_KEY")
            if env_key:
                config["api_key"] = env_key

        super().__init__(config)

        self._total_cost = 0.0
        self._request_count = 0
        self._async_client: Any = None

    @property
    def name(self) -> str:
        return "deepseek"

    @property
    def default_model(self) -> str:
        return self._config.get("model", "deepseek-chat")

    def _get_client(self) -> Any:
        """Get or create async OpenAI-compatible client."""
        if self._async_client is None:
            try:
                from openai import AsyncOpenAI

                self._async_client = AsyncOpenAI(
                    api_key=self._api_key,
                    base_url=self._config.get("base_url", "https://api.deepseek.com/v1"),
                    timeout=self._config.get("timeout", 120),
                    max_retries=0,
                )
            except ImportError:
                raise ImportError(
                    "DeepSeek provider requires 'openai' package. "
                    "Install with: pip install agenticraft-llm[deepseek]"
                )
        return self._async_client

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._async_client = None

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Make completion request to DeepSeek.

        Args:
            messages: List of message dicts
            model: Model name
            **kwargs: Additional parameters

        Returns:
            Response dict with content, model, provider, usage
        """
        client = self._get_client()

        # Build request params
        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
        }

        # Add optional parameters
        for key in ["temperature", "max_tokens", "top_p", "stop", "n", "seed"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Handle JSON mode
        if kwargs.get("json_mode"):
            request_params["response_format"] = {"type": "json_object"}

        # Handle tools
        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            response = await client.chat.completions.create(**request_params)

            choice = response.choices[0]

            # Extract usage
            usage = {}
            if response.usage:
                usage = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }

            # Calculate cost
            cost = self._calculate_cost(model, usage)
            self._total_cost += cost
            self._request_count += 1

            # Extract tool calls
            tool_calls = None
            if hasattr(choice.message, "tool_calls") and choice.message.tool_calls:
                tool_calls = []
                for tc in choice.message.tool_calls:
                    try:
                        args = tc.function.arguments
                        if isinstance(args, str):
                            args = json.loads(args)
                        tool_calls.append(
                            {
                                "id": tc.id,
                                "name": tc.function.name,
                                "arguments": args,
                            }
                        )
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse tool arguments for {tc.function.name}")

            result = {
                "content": choice.message.content or "",
                "model": model,
                "provider": "deepseek",
                "usage": usage,
                "finish_reason": choice.finish_reason,
                "cost": cost,
            }

            if tool_calls:
                result["tool_calls"] = tool_calls

            # Extract reasoning content if available (for deepseek-reasoner)
            if hasattr(choice.message, "reasoning_content"):
                result["reasoning_content"] = choice.message.reasoning_content

            return result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"DeepSeek request failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="deepseek", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="deepseek", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="deepseek", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="deepseek", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="deepseek",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"DeepSeek request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream completion from DeepSeek.

        Args:
            messages: List of message dicts
            model: Model name
            **kwargs: Additional parameters

        Yields:
            Response chunks
        """
        client = self._get_client()

        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": True,
        }

        for key in ["temperature", "max_tokens", "top_p"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            stream = await client.chat.completions.create(**request_params)

            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta

                    result: dict[str, Any] = {
                        "model": model,
                        "provider": "deepseek",
                        "done": False,
                    }

                    if delta.content:
                        result["content"] = delta.content

                    if hasattr(delta, "tool_calls") and delta.tool_calls:
                        result["tool_call_delta"] = [
                            {
                                "index": tc.index,
                                "id": tc.id,
                                "name": tc.function.name if tc.function else None,
                                "arguments": tc.function.arguments if tc.function else None,
                            }
                            for tc in delta.tool_calls
                        ]

                    # Stream reasoning content if available
                    if hasattr(delta, "reasoning_content") and delta.reasoning_content:
                        result["reasoning_content"] = delta.reasoning_content

                    if chunk.choices[0].finish_reason:
                        result["done"] = True
                        result["finish_reason"] = chunk.choices[0].finish_reason

                    yield result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"DeepSeek stream failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="deepseek", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="deepseek", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="deepseek", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="deepseek", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="deepseek",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"DeepSeek stream failed: {e}")
            raise

    async def _initialize_internal(self) -> None:
        """Initialize DeepSeek provider internals."""
        if not self._api_key:
            logger.warning("DeepSeek provider initialized without API key")

    async def _shutdown_internal(self) -> None:
        """Shutdown DeepSeek provider internals."""
        if self._async_client:
            await self._async_client.close()
            self._async_client = None

    async def health_check(self) -> HealthStatus:
        """Check provider health."""
        if not self._api_key:
            return HealthStatus(healthy=False, message="No API key configured")

        try:
            client = self._get_client()
            await client.chat.completions.create(
                model="deepseek-chat",
                max_tokens=1,
                messages=[{"role": "user", "content": "Hi"}],
            )
            return HealthStatus(healthy=True, message="DeepSeek API is accessible")
        except Exception as e:
            return HealthStatus(healthy=False, message=f"DeepSeek API error: {e}")

    def _format_tools(self, tools: list[Any]) -> list[dict[str, Any]]:
        """Format tools for DeepSeek API (OpenAI-compatible)."""
        formatted = []
        for tool in tools:
            if hasattr(tool, "to_openai_schema"):
                formatted.append(tool.to_openai_schema())
            elif isinstance(tool, dict):
                formatted.append(tool)
            else:
                formatted.append(
                    {
                        "type": "function",
                        "function": {
                            "name": getattr(tool, "name", "unknown"),
                            "description": getattr(tool, "description", ""),
                            "parameters": getattr(tool, "parameters", {}),
                        },
                    }
                )
        return formatted

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        """Calculate request cost (per 1M tokens)."""
        pricing = self.PRICING.get(model)
        if not pricing:
            pricing = self.PRICING["deepseek-chat"]

        input_cost = (usage.get("prompt_tokens", 0) / 1_000_000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1_000_000) * pricing["output"]
        return input_cost + output_cost

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics."""
        return {
            "provider": "deepseek",
            "total_requests": self._request_count,
            "total_cost": round(self._total_cost, 6),
            "average_cost": round(self._total_cost / max(1, self._request_count), 6),
        }

    def supports_model(self, model: str) -> bool:
        """Check if model is supported."""
        return model in self.SUPPORTED_MODELS

    def is_reasoning_model(self, model: str) -> bool:
        """Check if model supports reasoning/chain-of-thought."""
        return model in self.REASONING_MODELS


__all__ = ["DeepSeekProvider"]
