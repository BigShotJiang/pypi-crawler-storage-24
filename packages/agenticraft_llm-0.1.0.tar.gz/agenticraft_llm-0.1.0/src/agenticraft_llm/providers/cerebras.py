"""
Cerebras Provider Implementation

Ultra-fast inference using Cerebras Wafer-Scale Engine.
Fastest inference platform with 2,600+ tokens/second.

Version: 0.1.0
Date: 2025-12-12

Features:
- Ultra-fast inference (2,600+ tok/s)
- OpenAI-compatible API
- Streaming support
- Function calling
- Llama models optimized for speed

Note: Requires CEREBRAS_API_KEY environment variable
"""

import json
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class CerebrasProvider(BaseLLMProvider):
    """
    Cerebras LLM provider with ultra-fast inference.

    Cerebras uses their Wafer-Scale Engine for the fastest inference
    available (2,600+ tokens/second), making it ideal for latency-critical
    and high-throughput applications.

    Supports:
    - Llama 3.3 70B (optimized for speed)
    - Llama 3.1 70B/8B
    - Llama 3 70B/8B

    Example:
        ```python
        provider = CerebrasProvider(api_key="csk-...")
        await provider.initialize()
        response = await provider.complete([{"role": "user", "content": "Hello"}])
        ```
    """

    provider_name = "cerebras"

    # Model mappings
    MODEL_MAPPINGS = {
        # Llama 3.3
        "llama-3.3-70b": "llama3.3-70b",
        # Llama 3.1
        "llama-3.1-70b": "llama3.1-70b",
        "llama-3.1-8b": "llama3.1-8b",
        # Llama 3
        "llama-3-70b": "llama3-70b",
        "llama-3-8b": "llama3-8b",
    }

    # Pricing per 1M tokens (2025 - Cerebras is competitive)
    PRICING = {
        "llama3.3-70b": {"input": 0.85, "output": 1.20},
        "llama3.1-70b": {"input": 0.85, "output": 1.20},
        "llama3.1-8b": {"input": 0.10, "output": 0.10},
        "llama3-70b": {"input": 0.85, "output": 1.20},
        "llama3-8b": {"input": 0.10, "output": 0.10},
    }

    SUPPORTED_MODELS: set[str] = set(MODEL_MAPPINGS.keys()) | set(PRICING.keys())

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.FUNCTION_CALLING,
        LLMCapabilityType.JSON_MODE,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.TOOL_USE,
        LLMCapabilityType.CODE_GENERATION,
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_key: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
    ):
        """
        Initialize Cerebras provider.

        Args:
            config: Configuration dict with optional keys:
                - api_key: Cerebras API key
                - model: Default model (default: llama3.3-70b)
                - base_url: API base URL
                - timeout: Request timeout
                - max_retries: Max retry attempts
            api_key: Cerebras API key (kwargs override)
            model: Default model
            timeout: Request timeout in seconds
            max_retries: Max retry attempts
        """
        if config is None:
            config = {}

        if api_key is not None:
            config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if timeout is not None:
            config["timeout"] = timeout
        if max_retries is not None:
            config["max_retries"] = max_retries

        config.setdefault("name", "cerebras")
        config.setdefault("model", "llama3.3-70b")
        config.setdefault("base_url", "https://api.cerebras.ai/v1")
        config.setdefault("timeout", 30)  # Cerebras is fast
        config.setdefault("max_retries", 3)

        if "api_key" not in config:
            env_key = os.environ.get("CEREBRAS_API_KEY")
            if env_key:
                config["api_key"] = env_key

        super().__init__(config)

        self._total_cost = 0.0
        self._request_count = 0
        self._total_tokens_per_second = 0.0
        self._async_client: Any = None

    @property
    def name(self) -> str:
        return "cerebras"

    @property
    def default_model(self) -> str:
        model = self._config.get("model", "llama3.3-70b")
        return self.MODEL_MAPPINGS.get(model, model)

    def _get_client(self) -> Any:
        """Get or create async OpenAI-compatible client."""
        if self._async_client is None:
            try:
                from openai import AsyncOpenAI

                self._async_client = AsyncOpenAI(
                    api_key=self._api_key,
                    base_url=self._config.get("base_url", "https://api.cerebras.ai/v1"),
                    timeout=self._config.get("timeout", 30),
                    max_retries=0,
                )
            except ImportError:
                raise ImportError(
                    "Cerebras provider requires 'openai' package. "
                    "Install with: pip install agenticraft-llm[cerebras]"
                )
        return self._async_client

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._async_client = None

    def _resolve_model(self, model: str) -> str:
        """Resolve model alias to Cerebras model ID."""
        return self.MODEL_MAPPINGS.get(model, model)

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Make completion request to Cerebras.

        Args:
            messages: List of message dicts
            model: Model name or alias
            **kwargs: Additional parameters

        Returns:
            Response dict with content, model, provider, usage
        """
        client = self._get_client()
        model = self._resolve_model(model)

        # Build request params (OpenAI-compatible)
        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
        }

        # Add optional parameters
        for key in ["temperature", "max_tokens", "top_p", "stop", "n"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Handle JSON mode
        if kwargs.get("json_mode"):
            request_params["response_format"] = {"type": "json_object"}

        # Handle tools
        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            response = await client.chat.completions.create(**request_params)

            choice = response.choices[0]

            # Extract usage
            usage = {}
            if response.usage:
                usage = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }

            # Calculate cost (per 1M tokens)
            cost = self._calculate_cost(model, usage)
            self._total_cost += cost
            self._request_count += 1

            # Track tokens per second if available in response
            time_info = getattr(response, "time_info", None)
            if time_info and hasattr(time_info, "total_time"):
                total_time = time_info.total_time
                if total_time > 0:
                    tps = usage.get("completion_tokens", 0) / total_time
                    self._total_tokens_per_second += tps

            # Extract tool calls
            tool_calls = None
            if hasattr(choice.message, "tool_calls") and choice.message.tool_calls:
                tool_calls = []
                for tc in choice.message.tool_calls:
                    try:
                        args = tc.function.arguments
                        if isinstance(args, str):
                            args = json.loads(args)
                        tool_calls.append(
                            {
                                "id": tc.id,
                                "name": tc.function.name,
                                "arguments": args,
                            }
                        )
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse tool arguments for {tc.function.name}")

            result = {
                "content": choice.message.content or "",
                "model": model,
                "provider": "cerebras",
                "usage": usage,
                "finish_reason": choice.finish_reason,
                "cost": cost,
            }

            if tool_calls:
                result["tool_calls"] = tool_calls

            return result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"Cerebras request failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="cerebras", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="cerebras", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="cerebras", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="cerebras", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="cerebras",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"Cerebras request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream completion from Cerebras.

        Cerebras streaming is extremely fast due to Wafer-Scale Engine.

        Args:
            messages: List of message dicts
            model: Model name or alias
            **kwargs: Additional parameters

        Yields:
            Response chunks
        """
        client = self._get_client()
        model = self._resolve_model(model)

        # Build request params
        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": True,
        }

        for key in ["temperature", "max_tokens", "top_p"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Handle tools
        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            stream = await client.chat.completions.create(**request_params)

            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta

                    result: dict[str, Any] = {
                        "model": model,
                        "provider": "cerebras",
                        "done": False,
                    }

                    if delta.content:
                        result["content"] = delta.content

                    if hasattr(delta, "tool_calls") and delta.tool_calls:
                        result["tool_call_delta"] = [
                            {
                                "index": tc.index,
                                "id": tc.id,
                                "name": tc.function.name if tc.function else None,
                                "arguments": tc.function.arguments if tc.function else None,
                            }
                            for tc in delta.tool_calls
                        ]

                    if chunk.choices[0].finish_reason:
                        result["done"] = True
                        result["finish_reason"] = chunk.choices[0].finish_reason

                    yield result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"Cerebras stream failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="cerebras", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="cerebras", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="cerebras", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="cerebras", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="cerebras",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"Cerebras stream failed: {e}")
            raise

    async def _initialize_internal(self) -> None:
        """Initialize Cerebras provider internals."""
        if not self._api_key:
            logger.warning("Cerebras provider initialized without API key")

    async def _shutdown_internal(self) -> None:
        """Shutdown Cerebras provider internals."""
        if self._async_client:
            await self._async_client.close()
            self._async_client = None

    async def health_check(self) -> HealthStatus:
        """Check provider health."""
        if not self._api_key:
            return HealthStatus(healthy=False, message="No API key configured")

        try:
            client = self._get_client()
            # Minimal test request
            await client.chat.completions.create(
                model="llama3.1-8b",
                max_tokens=1,
                messages=[{"role": "user", "content": "Hi"}],
            )
            return HealthStatus(healthy=True, message="Cerebras API is accessible")
        except Exception as e:
            return HealthStatus(healthy=False, message=f"Cerebras API error: {e}")

    def _format_tools(self, tools: list[Any]) -> list[dict[str, Any]]:
        """Format tools for Cerebras API (OpenAI-compatible)."""
        formatted = []
        for tool in tools:
            if hasattr(tool, "to_openai_schema"):
                formatted.append(tool.to_openai_schema())
            elif isinstance(tool, dict):
                formatted.append(tool)
            else:
                formatted.append(
                    {
                        "type": "function",
                        "function": {
                            "name": getattr(tool, "name", "unknown"),
                            "description": getattr(tool, "description", ""),
                            "parameters": getattr(tool, "parameters", {}),
                        },
                    }
                )
        return formatted

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        """Calculate request cost (per 1M tokens)."""
        pricing = self.PRICING.get(model)
        if not pricing:
            # Default to 70B pricing
            pricing = self.PRICING["llama3.3-70b"]

        input_cost = (usage.get("prompt_tokens", 0) / 1_000_000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1_000_000) * pricing["output"]
        return input_cost + output_cost

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics including speed metrics."""
        avg_tps = 0.0
        if self._request_count > 0:
            avg_tps = self._total_tokens_per_second / self._request_count

        return {
            "provider": "cerebras",
            "total_requests": self._request_count,
            "total_cost": round(self._total_cost, 6),
            "average_cost": round(self._total_cost / max(1, self._request_count), 6),
            "average_tokens_per_second": round(avg_tps, 2),
        }

    def supports_model(self, model: str) -> bool:
        """Check if model is supported."""
        return model in self.SUPPORTED_MODELS or model in self.MODEL_MAPPINGS


__all__ = ["CerebrasProvider"]
