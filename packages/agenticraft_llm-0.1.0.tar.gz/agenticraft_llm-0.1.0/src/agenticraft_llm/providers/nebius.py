"""
Nebius AI Studio Provider Implementation

OpenAI-compatible API for Nebius AI Studio inference service.
Supports Llama, Mixtral, Qwen and other open-source models.

Version: 0.1.0
Date: 2025-12-11
"""

import json
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class NebiusProvider(BaseLLMProvider):
    """
    Nebius AI Studio LLM provider.

    Cloud inference service providing access to open-source models including:
    - Meta Llama 3.1 (8B, 70B)
    - Mistral/Mixtral
    - Qwen 2.5
    - And more

    Features:
    - OpenAI-compatible API
    - Streaming support
    - Function/tool calling
    - Production SLAs
    - Cost tracking

    Example:
        ```python
        provider = NebiusProvider(config={"api_key": "..."})
        await provider.initialize()
        response = await provider.complete(
            [{"role": "user", "content": "Hello"}],
            model="meta-llama/Meta-Llama-3.1-70B-Instruct"
        )
        ```
    """

    # Provider name for mesh registration
    provider_name = "nebius"

    # Pricing per 1M tokens (approximate, 2025)
    PRICING = {
        "meta-llama/Meta-Llama-3.1-70B-Instruct": {"input": 0.9, "output": 0.9},
        "meta-llama/Meta-Llama-3.1-8B-Instruct": {"input": 0.2, "output": 0.2},
        "mistralai/Mixtral-8x22B-Instruct-v0.1": {"input": 1.2, "output": 1.2},
        "mistralai/Mixtral-8x7B-Instruct-v0.1": {"input": 0.5, "output": 0.5},
        "Qwen/Qwen2.5-72B-Instruct": {"input": 1.0, "output": 1.0},
        "Qwen/Qwen2.5-Coder-32B-Instruct": {"input": 0.8, "output": 0.8},
    }

    # Supported models
    SUPPORTED_MODELS: set[str] = {
        # Meta Llama
        "meta-llama/Meta-Llama-3.1-70B-Instruct",
        "meta-llama/Meta-Llama-3.1-8B-Instruct",
        "meta-llama/Llama-3.2-90B-Vision-Instruct",
        "meta-llama/Llama-3.2-11B-Vision-Instruct",
        # Mistral
        "mistralai/Mixtral-8x22B-Instruct-v0.1",
        "mistralai/Mixtral-8x7B-Instruct-v0.1",
        "mistralai/Mistral-7B-Instruct-v0.3",
        # Qwen
        "Qwen/Qwen2.5-72B-Instruct",
        "Qwen/Qwen2.5-32B-Instruct",
        "Qwen/Qwen2.5-Coder-32B-Instruct",
        "Qwen/Qwen2.5-Coder-7B-Instruct",
        # DeepSeek
        "deepseek-ai/DeepSeek-Coder-V2-Lite-Instruct",
    }

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.FUNCTION_CALLING,
        LLMCapabilityType.JSON_MODE,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.TOOL_USE,
        LLMCapabilityType.CODE_GENERATION,
    }

    # Model aliases for convenience
    MODEL_ALIASES: dict[str, str] = {
        "llama-3.1-70b": "meta-llama/Meta-Llama-3.1-70B-Instruct",
        "llama-3.1-8b": "meta-llama/Meta-Llama-3.1-8B-Instruct",
        "mixtral-8x22b": "mistralai/Mixtral-8x22B-Instruct-v0.1",
        "qwen-72b": "Qwen/Qwen2.5-72B-Instruct",
        "qwen-coder": "Qwen/Qwen2.5-Coder-32B-Instruct",
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_key: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
    ):
        """
        Initialize Nebius provider.

        Args:
            config: Configuration dict (alternative to kwargs)
            api_key: Nebius API key (or set NEBIUS_API_KEY env var)
            model: Default model (default: meta-llama/Meta-Llama-3.1-70B-Instruct)
            timeout: Request timeout in seconds
            max_retries: Max retry attempts
        """
        if config is None:
            config = {}

        # Merge direct kwargs into config (kwargs take precedence)
        if api_key is not None:
            config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if timeout is not None:
            config["timeout"] = timeout
        if max_retries is not None:
            config["max_retries"] = max_retries

        # Set defaults
        config.setdefault("name", "nebius")
        config.setdefault("model", "meta-llama/Meta-Llama-3.1-70B-Instruct")
        config.setdefault("timeout", 120)
        config.setdefault("max_retries", 3)
        config.setdefault("base_url", "https://api.studio.nebius.com/v1/")

        # Check for API key in config or environment
        if "api_key" not in config:
            env_key = os.environ.get("NEBIUS_API_KEY")
            if env_key:
                config["api_key"] = env_key

        super().__init__(config)

        # Track costs
        self._total_cost = 0.0
        self._request_count = 0
        self._async_client: Any = None

    # ========================================================================
    # Abstract Property: name
    # ========================================================================

    @property
    def name(self) -> str:
        """Provider name."""
        return "nebius"

    @property
    def default_model(self) -> str:
        """Default model."""
        return self._config.get("model", "meta-llama/Meta-Llama-3.1-70B-Instruct")

    # ========================================================================
    # Client Management
    # ========================================================================

    def _get_client(self) -> Any:
        """Get or create async OpenAI client configured for Nebius."""
        if self._async_client is None:
            try:
                from openai import AsyncOpenAI

                self._async_client = AsyncOpenAI(
                    api_key=self._api_key,
                    base_url=self._config.get("base_url", "https://api.studio.nebius.com/v1/"),
                    timeout=self._config.get("timeout", 120),
                    max_retries=0,
                )
            except ImportError:
                raise ImportError(
                    "Nebius provider requires 'openai' package. "
                    "Install with: pip install agenticraft-llm[nebius]"
                )
        return self._async_client

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._async_client = None

    # ========================================================================
    # Abstract Methods: BaseLLMProvider
    # ========================================================================

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Make completion request to Nebius AI Studio.

        Args:
            messages: List of message dicts.
            model: Model name (e.g., 'meta-llama/Meta-Llama-3.1-70B-Instruct').
            **kwargs: Additional parameters (temperature, max_tokens, etc).

        Returns:
            Response dict with content, model, provider, usage.
        """
        client = self._get_client()

        # Resolve model alias
        model = self.resolve_model_alias(model)

        # Build request params
        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
        }

        # Add optional parameters
        for key in [
            "temperature",
            "max_tokens",
            "top_p",
            "frequency_penalty",
            "presence_penalty",
            "response_format",
            "seed",
            "stop",
            "n",
        ]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Handle tools
        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            response = await client.chat.completions.create(**request_params)

            choice = response.choices[0]

            # Extract usage
            usage = {}
            if response.usage:
                usage = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }

            # Calculate cost
            cost = self._calculate_cost(model, usage)
            self._total_cost += cost
            self._request_count += 1

            # Extract tool calls
            tool_calls = None
            if hasattr(choice.message, "tool_calls") and choice.message.tool_calls:
                tool_calls = []
                for tc in choice.message.tool_calls:
                    try:
                        args = tc.function.arguments
                        if isinstance(args, str):
                            args = json.loads(args)
                        tool_calls.append(
                            {
                                "id": tc.id,
                                "name": tc.function.name,
                                "arguments": args,
                            }
                        )
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse tool arguments for {tc.function.name}")

            result = {
                "content": choice.message.content or "",
                "model": model,
                "provider": "nebius",
                "usage": usage,
                "finish_reason": choice.finish_reason,
                "cost": cost,
            }

            if tool_calls:
                result["tool_calls"] = tool_calls

            return result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"Nebius request failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="nebius", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="nebius", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="nebius", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="nebius", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="nebius",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"Nebius request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream completion from Nebius AI Studio.

        Args:
            messages: List of message dicts.
            model: Model name.
            **kwargs: Additional parameters.

        Yields:
            Response chunks.
        """
        client = self._get_client()

        # Resolve model alias
        model = self.resolve_model_alias(model)

        # Build request params
        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": True,
        }

        # Add optional parameters
        for key in ["temperature", "max_tokens", "top_p"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Handle tools
        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            stream = await client.chat.completions.create(**request_params)

            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta

                    result: dict[str, Any] = {
                        "model": model,
                        "provider": "nebius",
                        "done": False,
                    }

                    if delta.content:
                        result["content"] = delta.content

                    if hasattr(delta, "tool_calls") and delta.tool_calls:
                        result["tool_call_delta"] = [
                            {
                                "index": tc.index,
                                "id": tc.id,
                                "name": tc.function.name if tc.function else None,
                                "arguments": tc.function.arguments if tc.function else None,
                            }
                            for tc in delta.tool_calls
                        ]

                    if chunk.choices[0].finish_reason:
                        result["done"] = True
                        result["finish_reason"] = chunk.choices[0].finish_reason

                    yield result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"Nebius stream failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="nebius", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="nebius", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="nebius", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="nebius", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="nebius",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"Nebius stream failed: {e}")
            raise

    # ========================================================================
    # Abstract Methods: BaseMeshService
    # ========================================================================

    async def _initialize_internal(self) -> None:
        """Initialize Nebius provider internals."""
        # Validate we have an API key
        if not self._api_key:
            logger.warning("Nebius provider initialized without API key")

    async def _shutdown_internal(self) -> None:
        """Shutdown Nebius provider internals."""
        if self._async_client:
            await self._async_client.close()
            self._async_client = None

    async def health_check(self) -> HealthStatus:
        """Check provider health."""
        if not self._api_key:
            return HealthStatus(
                healthy=False,
                message="No API key configured",
            )

        try:
            # Try to list models as a health check
            client = self._get_client()
            await client.models.list()
            return HealthStatus(
                healthy=True,
                message="Nebius AI Studio API is accessible",
            )
        except Exception as e:
            return HealthStatus(
                healthy=False,
                message=f"Nebius API error: {e}",
            )

    # ========================================================================
    # Helper Methods
    # ========================================================================

    def _format_tools(self, tools: list[Any]) -> list[dict[str, Any]]:
        """Format tools for OpenAI-compatible API."""
        formatted = []
        for tool in tools:
            if hasattr(tool, "to_openai_schema"):
                formatted.append(tool.to_openai_schema())
            elif isinstance(tool, dict):
                formatted.append(tool)
            else:
                formatted.append(
                    {
                        "type": "function",
                        "function": {
                            "name": getattr(tool, "name", "unknown"),
                            "description": getattr(tool, "description", ""),
                            "parameters": getattr(tool, "parameters", {}),
                        },
                    }
                )
        return formatted

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        """Calculate request cost based on Nebius pricing."""
        pricing = self.PRICING.get(model)
        if not pricing:
            # Try prefix match
            for prefix, price in self.PRICING.items():
                if model.startswith(prefix.split("/")[0]):
                    pricing = price
                    break

        if not pricing:
            # Default to Llama 3.1 70B pricing
            pricing = self.PRICING["meta-llama/Meta-Llama-3.1-70B-Instruct"]

        # Nebius pricing is per 1M tokens
        input_cost = (usage.get("prompt_tokens", 0) / 1_000_000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1_000_000) * pricing["output"]
        return input_cost + output_cost

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics."""
        return {
            "provider": "nebius",
            "total_requests": self._request_count,
            "total_cost": round(self._total_cost, 6),
            "average_cost": round(self._total_cost / max(1, self._request_count), 6),
        }


__all__ = ["NebiusProvider"]
