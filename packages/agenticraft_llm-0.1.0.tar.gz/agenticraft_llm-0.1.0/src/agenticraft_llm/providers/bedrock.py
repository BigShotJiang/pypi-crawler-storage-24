"""
AWS Bedrock Provider Implementation

Unified multi-provider access with AWS billing, compliance, and enterprise features.

Version: 0.1.0
Date: 2025-12-12

Features:
- Unified access to Claude, Llama, Amazon Nova, Mistral, Cohere
- AWS IAM authentication
- Regional deployment options
- Guardrails integration
- Knowledge Bases support
- HIPAA/SOC2/GDPR compliance through AWS

Note: Requires AWS credentials (boto3 configuration)
"""

import asyncio
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class BedrockProvider(BaseLLMProvider):
    """
    AWS Bedrock LLM provider with unified model access.

    Bedrock provides unified access to multiple foundation models
    through AWS with enterprise-grade security, compliance, and billing.

    Supports:
    - Anthropic Claude (3.5 Sonnet, 3 Opus/Sonnet/Haiku)
    - Amazon Nova (Pro, Lite, Micro)
    - Meta Llama (3.2, 3.1, 3)
    - Mistral (Large, Small)
    - Cohere (Command R+, Command R)
    - AI21 (Jamba)

    Example:
        ```python
        provider = BedrockProvider(region="us-east-1")
        await provider.initialize()
        response = await provider.complete(
            [{"role": "user", "content": "Hello"}],
            model="claude-3-sonnet"
        )
        ```

    Requires the `boto3` package:
        pip install agenticraft-llm[bedrock]
    """

    provider_name = "bedrock"

    # Model ID mappings (alias -> Bedrock model ID)
    MODEL_MAPPINGS = {
        # Claude models
        "claude-3-5-sonnet": "anthropic.claude-3-5-sonnet-20241022-v2:0",
        "claude-3-opus": "anthropic.claude-3-opus-20240229-v1:0",
        "claude-3-sonnet": "anthropic.claude-3-sonnet-20240229-v1:0",
        "claude-3-haiku": "anthropic.claude-3-haiku-20240307-v1:0",
        # Amazon Nova
        "nova-pro": "amazon.nova-pro-v1:0",
        "nova-lite": "amazon.nova-lite-v1:0",
        "nova-micro": "amazon.nova-micro-v1:0",
        # Llama models
        "llama-3.2-90b": "meta.llama3-2-90b-instruct-v1:0",
        "llama-3.2-11b": "meta.llama3-2-11b-instruct-v1:0",
        "llama-3.2-3b": "meta.llama3-2-3b-instruct-v1:0",
        "llama-3.2-1b": "meta.llama3-2-1b-instruct-v1:0",
        "llama-3.1-70b": "meta.llama3-1-70b-instruct-v1:0",
        "llama-3.1-8b": "meta.llama3-1-8b-instruct-v1:0",
        # Mistral
        "mistral-large": "mistral.mistral-large-2407-v1:0",
        "mistral-small": "mistral.mistral-small-2402-v1:0",
        # Cohere
        "command-r-plus": "cohere.command-r-plus-v1:0",
        "command-r": "cohere.command-r-v1:0",
        # AI21
        "jamba-instruct": "ai21.jamba-instruct-v1:0",
    }

    # Pricing per 1K tokens (on-demand, us-east-1)
    PRICING = {
        # Claude
        "anthropic.claude-3-5-sonnet-20241022-v2:0": {"input": 0.003, "output": 0.015},
        "anthropic.claude-3-opus-20240229-v1:0": {"input": 0.015, "output": 0.075},
        "anthropic.claude-3-sonnet-20240229-v1:0": {"input": 0.003, "output": 0.015},
        "anthropic.claude-3-haiku-20240307-v1:0": {"input": 0.00025, "output": 0.00125},
        # Amazon Nova
        "amazon.nova-pro-v1:0": {"input": 0.0008, "output": 0.0032},
        "amazon.nova-lite-v1:0": {"input": 0.00006, "output": 0.00024},
        "amazon.nova-micro-v1:0": {"input": 0.000035, "output": 0.00014},
        # Llama
        "meta.llama3-2-90b-instruct-v1:0": {"input": 0.002, "output": 0.002},
        "meta.llama3-2-11b-instruct-v1:0": {"input": 0.00016, "output": 0.00016},
        "meta.llama3-2-3b-instruct-v1:0": {"input": 0.00015, "output": 0.00015},
        "meta.llama3-2-1b-instruct-v1:0": {"input": 0.0001, "output": 0.0001},
        "meta.llama3-1-70b-instruct-v1:0": {"input": 0.00099, "output": 0.00099},
        "meta.llama3-1-8b-instruct-v1:0": {"input": 0.0003, "output": 0.0003},
        # Mistral
        "mistral.mistral-large-2407-v1:0": {"input": 0.004, "output": 0.012},
        "mistral.mistral-small-2402-v1:0": {"input": 0.001, "output": 0.003},
        # Cohere
        "cohere.command-r-plus-v1:0": {"input": 0.003, "output": 0.015},
        "cohere.command-r-v1:0": {"input": 0.0005, "output": 0.0015},
        # AI21
        "ai21.jamba-instruct-v1:0": {"input": 0.0005, "output": 0.0007},
    }

    SUPPORTED_MODELS: set[str] = set(MODEL_MAPPINGS.keys()) | set(PRICING.keys())

    # Models with vision capabilities
    VISION_MODELS: set[str] = {
        "claude-3-5-sonnet",
        "claude-3-opus",
        "claude-3-sonnet",
        "claude-3-haiku",
        "nova-pro",
        "nova-lite",
        "llama-3.2-90b",
        "llama-3.2-11b",
    }

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.FUNCTION_CALLING,
        LLMCapabilityType.VISION,
        LLMCapabilityType.JSON_MODE,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.TOOL_USE,
        LLMCapabilityType.CODE_GENERATION,
        LLMCapabilityType.GUARDRAILS,  # Bedrock-specific
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        model: str | None = None,
        region: str | None = None,
        timeout: int | None = None,
    ):
        """
        Initialize AWS Bedrock provider.

        Args:
            config: Configuration dict with optional keys:
                - region: AWS region (default: us-east-1)
                - model: Default model alias
                - profile: AWS profile name
                - guardrail_id: Optional guardrail ID
                - guardrail_version: Guardrail version
            model: Default model alias (keyword-only)
            region: AWS region (keyword-only)
            timeout: Request timeout (keyword-only)
        """
        if config is None:
            config = {}

        if model is not None:
            config["model"] = model
        if region is not None:
            config["region"] = region
        if timeout is not None:
            config["timeout"] = timeout

        config.setdefault("name", "bedrock")
        config.setdefault("model", "claude-3-haiku")
        config.setdefault("region", os.environ.get("AWS_REGION", "us-east-1"))
        config.setdefault("timeout", 60)

        super().__init__(config)

        self._total_cost = 0.0
        self._request_count = 0
        self._bedrock_client: Any = None
        self._bedrock_runtime: Any = None

    @property
    def name(self) -> str:
        return "bedrock"

    @property
    def default_model(self) -> str:
        model = self._config.get("model", "claude-3-haiku")
        return self.MODEL_MAPPINGS.get(model, model)

    def _get_client(self) -> Any:
        """Get or create Bedrock runtime client."""
        if self._bedrock_runtime is None:
            try:
                import boto3

                session_kwargs = {}
                if self._config.get("profile"):
                    session_kwargs["profile_name"] = self._config["profile"]

                session = boto3.Session(**session_kwargs)
                self._bedrock_runtime = session.client(
                    "bedrock-runtime",
                    region_name=self._config.get("region", "us-east-1"),
                )
            except ImportError:
                raise ImportError(
                    "AWS Bedrock provider requires 'boto3' package. "
                    "Install with: pip install agenticraft-llm[bedrock]"
                )
        return self._bedrock_runtime

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._bedrock_runtime = None
        self._bedrock_client = None

    def _resolve_model(self, model: str) -> str:
        """Resolve model alias to Bedrock model ID."""
        return self.MODEL_MAPPINGS.get(model, model)

    def _is_claude_model(self, model_id: str) -> bool:
        """Check if model is Anthropic Claude."""
        return "anthropic.claude" in model_id

    def _is_nova_model(self, model_id: str) -> bool:
        """Check if model is Amazon Nova."""
        return "amazon.nova" in model_id

    def _is_llama_model(self, model_id: str) -> bool:
        """Check if model is Meta Llama."""
        return "meta.llama" in model_id

    def _format_request_body(
        self,
        messages: list[dict[str, Any]],
        model_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Format request body based on model type."""
        if self._is_claude_model(model_id):
            return self._format_claude_body(messages, **kwargs)
        elif self._is_nova_model(model_id):
            return self._format_nova_body(messages, **kwargs)
        elif self._is_llama_model(model_id):
            return self._format_llama_body(messages, **kwargs)
        else:
            # Default to Converse API format
            return self._format_converse_body(messages, **kwargs)

    def _format_claude_body(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Format request for Claude models."""
        # Extract system message
        system_prompt = None
        chat_messages = []

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                system_prompt = content
            else:
                chat_messages.append(
                    {
                        "role": role if role in ["user", "assistant"] else "user",
                        "content": content,
                    }
                )

        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "messages": chat_messages,
            "max_tokens": kwargs.get("max_tokens", 4096),
        }

        if system_prompt:
            body["system"] = system_prompt

        if "temperature" in kwargs:
            body["temperature"] = kwargs["temperature"]
        if "top_p" in kwargs:
            body["top_p"] = kwargs["top_p"]

        return body

    def _format_nova_body(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Format request for Amazon Nova models."""
        # Nova uses a similar format to Claude
        return self._format_claude_body(messages, **kwargs)

    def _format_llama_body(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Format request for Llama models."""
        # Build prompt from messages
        prompt_parts = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                prompt_parts.append(
                    f"<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n{content}<|eot_id|>"
                )
            elif role == "user":
                prompt_parts.append(
                    f"<|start_header_id|>user<|end_header_id|>\n{content}<|eot_id|>"
                )
            elif role == "assistant":
                prompt_parts.append(
                    f"<|start_header_id|>assistant<|end_header_id|>\n{content}<|eot_id|>"
                )

        prompt_parts.append("<|start_header_id|>assistant<|end_header_id|>")
        prompt = "\n".join(prompt_parts)

        body = {
            "prompt": prompt,
            "max_gen_len": kwargs.get("max_tokens", 2048),
        }

        if "temperature" in kwargs:
            body["temperature"] = kwargs["temperature"]
        if "top_p" in kwargs:
            body["top_p"] = kwargs["top_p"]

        return body

    def _format_converse_body(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Format request using Bedrock Converse API format."""
        formatted_messages = []
        system_content = []

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                system_content.append({"text": content})
            else:
                formatted_messages.append(
                    {
                        "role": role if role in ["user", "assistant"] else "user",
                        "content": [{"text": content}],
                    }
                )

        body = {
            "messages": formatted_messages,
            "inferenceConfig": {
                "maxTokens": kwargs.get("max_tokens", 4096),
            },
        }

        if system_content:
            body["system"] = system_content

        if "temperature" in kwargs:
            body["inferenceConfig"]["temperature"] = kwargs["temperature"]
        if "top_p" in kwargs:
            body["inferenceConfig"]["topP"] = kwargs["top_p"]

        return body

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Make completion request to AWS Bedrock.

        Args:
            messages: List of message dicts
            model: Model name or alias
            **kwargs: Additional parameters

        Returns:
            Response dict with content, model, provider, usage
        """
        client = self._get_client()
        model_id = self._resolve_model(model)

        # Use Converse API for unified interface
        try:
            # Format messages for Converse API
            formatted_messages = []
            system_content = []

            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")

                if role == "system":
                    system_content.append({"text": content})
                else:
                    formatted_messages.append(
                        {
                            "role": role if role in ["user", "assistant"] else "user",
                            "content": [{"text": content}],
                        }
                    )

            converse_params = {
                "modelId": model_id,
                "messages": formatted_messages,
                "inferenceConfig": {
                    "maxTokens": kwargs.get("max_tokens", 4096),
                },
            }

            if system_content:
                converse_params["system"] = system_content

            if "temperature" in kwargs:
                converse_params["inferenceConfig"]["temperature"] = kwargs["temperature"]

            # Add guardrails if configured
            if self._config.get("guardrail_id"):
                converse_params["guardrailConfig"] = {
                    "guardrailIdentifier": self._config["guardrail_id"],
                    "guardrailVersion": self._config.get("guardrail_version", "DRAFT"),
                }

            # Execute in thread pool (boto3 is sync)
            response = await asyncio.to_thread(
                client.converse,
                **converse_params,
            )

            # Extract content
            content = ""
            output = response.get("output", {})
            message = output.get("message", {})
            content_blocks = message.get("content", [])
            for block in content_blocks:
                if "text" in block:
                    content += block["text"]

            # Extract usage
            usage_info = response.get("usage", {})
            usage = {
                "prompt_tokens": usage_info.get("inputTokens", 0),
                "completion_tokens": usage_info.get("outputTokens", 0),
                "total_tokens": (
                    usage_info.get("inputTokens", 0) + usage_info.get("outputTokens", 0)
                ),
            }

            # Calculate cost
            cost = self._calculate_cost(model_id, usage)
            self._total_cost += cost
            self._request_count += 1

            return {
                "content": content,
                "model": model_id,
                "provider": "bedrock",
                "usage": usage,
                "finish_reason": response.get("stopReason", "end_turn"),
                "cost": cost,
            }

        except Exception as e:
            try:
                from botocore.exceptions import ClientError
            except ImportError:
                logger.error(f"Bedrock request failed: {e}")
                raise
            if isinstance(e, ClientError):
                error_code = e.response.get("Error", {}).get("Code", "")
                error_msg = str(e)
                if error_code == "ThrottlingException" or "throttl" in error_msg.lower():
                    from agenticraft_llm.exceptions import LLMRateLimitError

                    raise LLMRateLimitError(str(e), provider="bedrock", model=model) from e
                if error_code == "AccessDeniedException" or "access denied" in error_msg.lower():
                    from agenticraft_llm.exceptions import LLMAuthenticationError

                    raise LLMAuthenticationError(str(e), provider="bedrock", model=model) from e
                if error_code == "ResourceNotFoundException" or "not found" in error_msg.lower():
                    from agenticraft_llm.exceptions import LLMModelNotFoundError

                    raise LLMModelNotFoundError(str(e), provider="bedrock", model=model) from e
                if error_code == "ModelTimeoutException":
                    from agenticraft_llm.exceptions import LLMTimeoutError

                    raise LLMTimeoutError(str(e), provider="bedrock", model=model) from e
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(str(e), provider="bedrock", model=model) from e
            logger.error(f"Bedrock request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream completion from AWS Bedrock.

        Args:
            messages: List of message dicts
            model: Model name or alias
            **kwargs: Additional parameters

        Yields:
            Response chunks
        """
        client = self._get_client()
        model_id = self._resolve_model(model)

        try:
            # Format messages for Converse API
            formatted_messages = []
            system_content = []

            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")

                if role == "system":
                    system_content.append({"text": content})
                else:
                    formatted_messages.append(
                        {
                            "role": role if role in ["user", "assistant"] else "user",
                            "content": [{"text": content}],
                        }
                    )

            converse_params = {
                "modelId": model_id,
                "messages": formatted_messages,
                "inferenceConfig": {
                    "maxTokens": kwargs.get("max_tokens", 4096),
                },
            }

            if system_content:
                converse_params["system"] = system_content

            # Start streaming
            response = await asyncio.to_thread(
                client.converse_stream,
                **converse_params,
            )

            stream = response.get("stream", [])

            # Process stream events
            for event in stream:
                result: dict[str, Any] = {
                    "model": model_id,
                    "provider": "bedrock",
                    "done": False,
                }

                if "contentBlockDelta" in event:
                    delta = event["contentBlockDelta"].get("delta", {})
                    if "text" in delta:
                        result["content"] = delta["text"]

                if "messageStop" in event:
                    result["done"] = True
                    result["finish_reason"] = event["messageStop"].get("stopReason", "end_turn")

                yield result

        except Exception as e:
            try:
                from botocore.exceptions import ClientError
            except ImportError:
                logger.error(f"Bedrock request failed: {e}")
                raise
            if isinstance(e, ClientError):
                error_code = e.response.get("Error", {}).get("Code", "")
                error_msg = str(e)
                if error_code == "ThrottlingException" or "throttl" in error_msg.lower():
                    from agenticraft_llm.exceptions import LLMRateLimitError

                    raise LLMRateLimitError(str(e), provider="bedrock", model=model) from e
                if error_code == "AccessDeniedException" or "access denied" in error_msg.lower():
                    from agenticraft_llm.exceptions import LLMAuthenticationError

                    raise LLMAuthenticationError(str(e), provider="bedrock", model=model) from e
                if error_code == "ResourceNotFoundException" or "not found" in error_msg.lower():
                    from agenticraft_llm.exceptions import LLMModelNotFoundError

                    raise LLMModelNotFoundError(str(e), provider="bedrock", model=model) from e
                if error_code == "ModelTimeoutException":
                    from agenticraft_llm.exceptions import LLMTimeoutError

                    raise LLMTimeoutError(str(e), provider="bedrock", model=model) from e
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(str(e), provider="bedrock", model=model) from e
            logger.error(f"Bedrock stream failed: {e}")
            raise

    async def _initialize_internal(self) -> None:
        """Initialize Bedrock provider internals."""
        # Validate AWS credentials are available
        try:
            self._get_client()
            logger.info(f"Bedrock provider initialized (region: {self._config.get('region')})")
        except Exception as e:
            logger.warning(f"Bedrock initialization warning: {e}")

    async def _shutdown_internal(self) -> None:
        """Shutdown Bedrock provider internals."""
        self._bedrock_runtime = None
        self._bedrock_client = None

    async def health_check(self) -> HealthStatus:
        """Check provider health."""
        try:
            client = self._get_client()
            # List foundation models as health check
            await asyncio.to_thread(
                client.list_foundation_models
                if hasattr(client, "list_foundation_models")
                else lambda: None
            )
            return HealthStatus(healthy=True, message="Bedrock API is accessible")
        except Exception as e:
            return HealthStatus(healthy=False, message=f"Bedrock API error: {e}")

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        """Calculate request cost (per 1K tokens)."""
        pricing = self.PRICING.get(model)
        if not pricing:
            # Default to Claude Haiku pricing
            pricing = self.PRICING["anthropic.claude-3-haiku-20240307-v1:0"]

        input_cost = (usage.get("prompt_tokens", 0) / 1000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1000) * pricing["output"]
        return input_cost + output_cost

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics."""
        return {
            "provider": "bedrock",
            "region": self._config.get("region"),
            "total_requests": self._request_count,
            "total_cost": round(self._total_cost, 6),
            "average_cost": round(self._total_cost / max(1, self._request_count), 6),
        }

    def supports_model(self, model: str) -> bool:
        """Check if model is supported."""
        return model in self.SUPPORTED_MODELS or model in self.MODEL_MAPPINGS


__all__ = ["BedrockProvider"]
