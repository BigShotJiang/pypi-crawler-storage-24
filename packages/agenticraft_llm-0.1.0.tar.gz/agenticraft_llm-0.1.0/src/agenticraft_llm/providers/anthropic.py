"""
Anthropic Provider Implementation

Full-featured Anthropic Claude provider with Claude 4 support.
"""

import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class AnthropicProvider(BaseLLMProvider):
    """
    Anthropic Claude LLM provider.

    Supports all Claude models including Claude 3.5, Claude 3, and legacy.

    Example:
        provider = AnthropicProvider(config={"api_key": "sk-ant-..."})
        await provider.initialize()
        response = await provider.complete([{"role": "user", "content": "Hello"}])
    """

    provider_name = "anthropic"

    PRICING = {
        "claude-3-5-sonnet-20241022": {"input": 0.003, "output": 0.015},
        "claude-3-5-haiku-20241022": {"input": 0.0008, "output": 0.004},
        "claude-3-opus-20240229": {"input": 0.015, "output": 0.075},
        "claude-3-sonnet-20240229": {"input": 0.003, "output": 0.015},
        "claude-2.1": {"input": 0.008, "output": 0.024},
        "claude-2.0": {"input": 0.008, "output": 0.024},
        "claude-instant-1.2": {"input": 0.0008, "output": 0.0024},
        "claude-sonnet-4-20250514": {"input": 0.003, "output": 0.015},
        "claude-opus-4-20250514": {"input": 0.015, "output": 0.075},
        "claude-haiku-4-5-20251001": {"input": 0.0008, "output": 0.004},
    }

    CACHE_PRICING = {"write": 1.25, "read": 0.1}

    SUPPORTED_MODELS: set[str] = {
        "claude-3-5-sonnet-20241022",
        "claude-3-5-haiku-20241022",
        "claude-3-opus-20240229",
        "claude-3-sonnet-20240229",
        "claude-2.1",
        "claude-2.0",
        "claude-instant-1.2",
        "claude-sonnet-4-20250514",
        "claude-opus-4-20250514",
        "claude-haiku-4-5-20251001",
    }

    THINKING_MODELS: set[str] = {
        "claude-3-5-sonnet-20241022",
        "claude-3-5-haiku-20241022",
        "claude-3-opus-20240229",
        "claude-sonnet-4-20250514",
        "claude-opus-4-20250514",
    }

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.VISION,
        LLMCapabilityType.TOOL_USE,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.CODE_GENERATION,
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_key: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
    ):
        if config is None:
            config = {}

        if api_key is not None:
            config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if timeout is not None:
            config["timeout"] = timeout
        if max_retries is not None:
            config["max_retries"] = max_retries

        config.setdefault("name", "anthropic")
        config.setdefault("model", "claude-sonnet-4-20250514")
        config.setdefault("timeout", 60)
        config.setdefault("max_retries", 3)

        if "api_key" not in config:
            env_key = os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("CLAUDE_API_KEY")
            if env_key:
                config["api_key"] = env_key

        super().__init__(config)

        self._total_cost = 0.0
        self._request_count = 0
        self._async_client: Any = None

    @property
    def name(self) -> str:
        return "anthropic"

    @property
    def default_model(self) -> str:
        return self._config.get("model", "claude-sonnet-4-20250514")

    def _get_client(self) -> Any:
        if self._async_client is None:
            try:
                from anthropic import AsyncAnthropic

                self._async_client = AsyncAnthropic(
                    api_key=self._api_key,
                    timeout=self._config.get("timeout", 60),
                    max_retries=0,
                )
            except ImportError:
                raise ImportError(
                    "Anthropic provider requires 'anthropic' package. "
                    "Install with: pip install agenticraft-llm[anthropic]"
                )
        return self._async_client

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._async_client = None

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        client = self._get_client()

        system_prompt, chat_messages = self._extract_system_message(messages)
        formatted_messages = self._format_messages(chat_messages)

        max_tokens_raw = kwargs.get("max_tokens")
        max_tokens = int(max_tokens_raw) if max_tokens_raw is not None else 4096

        request_params: dict[str, Any] = {
            "model": model,
            "messages": formatted_messages,
            "max_tokens": max_tokens,
        }

        if system_prompt:
            request_params["system"] = system_prompt

        for key in ["temperature", "top_p", "top_k", "stop_sequences"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        if kwargs.get("cache_control"):
            cache_indices = kwargs["cache_control"]
            if isinstance(cache_indices, list):
                for i in cache_indices:
                    if i < len(formatted_messages):
                        if isinstance(formatted_messages[i].get("content"), str):
                            formatted_messages[i]["content"] = [
                                {
                                    "type": "text",
                                    "text": formatted_messages[i]["content"],
                                    "cache_control": {"type": "ephemeral"},
                                }
                            ]
                        elif isinstance(formatted_messages[i].get("content"), list):
                            formatted_messages[i]["content"][-1]["cache_control"] = {
                                "type": "ephemeral"
                            }

        if kwargs.get("extended_thinking") and model in self.THINKING_MODELS:
            request_params["metadata"] = request_params.get("metadata", {})
            request_params["metadata"]["thinking"] = {
                "type": "enabled",
                "budget_tokens": kwargs.get("thinking_budget", 10000),
            }

        try:
            response = await client.messages.create(**request_params)

            content = ""
            tool_calls = []

            for block in response.content:
                if hasattr(block, "text"):
                    content += block.text
                elif hasattr(block, "type") and block.type == "tool_use":
                    tool_calls.append(
                        {
                            "id": block.id,
                            "name": block.name,
                            "arguments": block.input,
                        }
                    )

            usage = {}
            if hasattr(response, "usage"):
                usage = {
                    "prompt_tokens": response.usage.input_tokens,
                    "completion_tokens": response.usage.output_tokens,
                    "total_tokens": response.usage.input_tokens + response.usage.output_tokens,
                }

            cost = self._calculate_cost(model, usage)
            self._total_cost += cost
            self._request_count += 1

            finish_reason = response.stop_reason
            if finish_reason == "end_turn":
                finish_reason = "stop"
            elif finish_reason == "max_tokens":
                finish_reason = "length"

            result = {
                "content": content,
                "model": model,
                "provider": "anthropic",
                "usage": usage,
                "finish_reason": finish_reason,
                "cost": cost,
            }

            if tool_calls:
                result["tool_calls"] = tool_calls

            return result

        except Exception as e:
            try:
                from anthropic import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"Anthropic request failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="anthropic", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="anthropic", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="anthropic", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="anthropic", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="anthropic",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"Anthropic request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        client = self._get_client()

        system_prompt, chat_messages = self._extract_system_message(messages)
        formatted_messages = self._format_messages(chat_messages)

        max_tokens_raw = kwargs.get("max_tokens")
        max_tokens = int(max_tokens_raw) if max_tokens_raw is not None else 4096

        request_params: dict[str, Any] = {
            "model": model,
            "messages": formatted_messages,
            "max_tokens": max_tokens,
            "stream": True,
        }

        if system_prompt:
            request_params["system"] = system_prompt

        for key in ["temperature", "top_p", "top_k"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        try:
            stream = await client.messages.create(**request_params)

            async for event in stream:
                result: dict[str, Any] = {
                    "model": model,
                    "provider": "anthropic",
                    "done": False,
                }

                if event.type == "content_block_start":
                    if (
                        hasattr(event.content_block, "type")
                        and event.content_block.type == "tool_use"
                    ):
                        result["tool_call_delta"] = {
                            "index": event.index,
                            "id": event.content_block.id,
                            "name": event.content_block.name,
                        }

                if event.type == "content_block_delta":
                    if hasattr(event.delta, "text"):
                        result["content"] = event.delta.text
                    elif hasattr(event.delta, "partial_json"):
                        result["tool_call_delta"] = {
                            "arguments": event.delta.partial_json,
                        }

                if event.type == "message_stop":
                    result["done"] = True
                    result["finish_reason"] = "stop"

                if event.type == "message_delta":
                    if hasattr(event.delta, "stop_reason"):
                        result["done"] = True
                        result["finish_reason"] = event.delta.stop_reason

                yield result

        except Exception as e:
            try:
                from anthropic import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"Anthropic request failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="anthropic", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="anthropic", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="anthropic", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="anthropic", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="anthropic",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"Anthropic request failed: {e}")
            raise

    async def _init_client(self) -> None:
        if not self._api_key:
            logger.warning("Anthropic provider initialized without API key")

    async def health_check(self) -> HealthStatus:
        if not self._api_key:
            return HealthStatus(healthy=False, message="No API key configured")
        try:
            client = self._get_client()
            await client.messages.create(
                model="claude-3-haiku-20240307",
                max_tokens=1,
                messages=[{"role": "user", "content": "Hi"}],
            )
            return HealthStatus(healthy=True, message="Anthropic API is accessible")
        except Exception as e:
            return HealthStatus(healthy=False, message=f"Anthropic API error: {e}")

    def _extract_system_message(
        self, messages: list[dict[str, Any]]
    ) -> tuple[str | None, list[dict[str, Any]]]:
        system_prompt = None
        chat_messages = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "system":
                system_prompt = f"{system_prompt}\n\n{content}" if system_prompt else content
            else:
                chat_messages.append(msg)
        return system_prompt, chat_messages

    def _format_messages(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        formatted = []
        for msg in messages:
            role = msg.get("role", "user")
            if role not in ["user", "assistant"]:
                role = "user"
            formatted.append({"role": role, "content": msg.get("content", "")})
        return formatted

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        pricing = self.PRICING.get(model)
        if not pricing:
            for prefix, price in self.PRICING.items():
                if model.startswith(prefix.rsplit("-", 1)[0]):
                    pricing = price
                    break
        if not pricing:
            logger.warning(f"Unknown model '{model}' for cost calculation, using default pricing")
            pricing = self.PRICING["claude-instant-1.2"]

        input_cost = (usage.get("prompt_tokens", 0) / 1000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1000) * pricing["output"]
        return input_cost + output_cost

    def get_stats(self) -> dict[str, Any]:
        return {
            "provider": "anthropic",
            "total_requests": self._request_count,
            "total_cost": round(self._total_cost, 4),
            "average_cost": round(self._total_cost / max(1, self._request_count), 4),
        }


__all__ = ["AnthropicProvider"]
