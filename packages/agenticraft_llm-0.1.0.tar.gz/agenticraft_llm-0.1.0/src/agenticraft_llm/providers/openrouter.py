"""
OpenRouter Provider Implementation

Unified API for multiple LLM providers including OpenAI, Anthropic, Google, Meta, and more.
Uses OpenAI-compatible API format.

Version: 0.1.0
Date: 2025-12-11
"""

import json
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from agenticraft_llm.base import BaseLLMProvider
from agenticraft_llm.types import HealthStatus, LLMCapabilityType

logger = logging.getLogger(__name__)


class OpenRouterProvider(BaseLLMProvider):
    """
    OpenRouter LLM provider.

    Unified API gateway providing access to multiple LLM providers including:
    - OpenAI (GPT-4, GPT-3.5)
    - Anthropic (Claude 3, Claude 3.5)
    - Google (Gemini)
    - Meta (Llama 3.1)
    - Mistral
    - And many more

    Features:
    - OpenAI-compatible API
    - Streaming support
    - Function/tool calling
    - Vision capabilities
    - Automatic fallbacks
    - Cost tracking

    Example:
        ```python
        provider = OpenRouterProvider(config={"api_key": "sk-or-..."})
        await provider.initialize()
        response = await provider.complete(
            [{"role": "user", "content": "Hello"}],
            model="meta-llama/llama-3.1-70b-instruct"
        )
        ```

    Requires the `openai` package:
        pip install agenticraft-llm[openrouter]
    """

    # Provider name for mesh registration
    provider_name = "openrouter"

    # Pricing per 1M tokens (2025) - varies by model
    PRICING = {
        # Meta Llama
        "meta-llama/llama-3.1-405b-instruct": {"input": 2.7, "output": 2.7},
        "meta-llama/llama-3.1-70b-instruct": {"input": 0.52, "output": 0.75},
        "meta-llama/llama-3.1-8b-instruct": {"input": 0.055, "output": 0.055},
        # OpenAI via routing
        "openai/gpt-4o": {"input": 2.5, "output": 10.0},
        "openai/gpt-4o-mini": {"input": 0.15, "output": 0.6},
        "openai/gpt-4-turbo": {"input": 10.0, "output": 30.0},
        # Anthropic via routing
        "anthropic/claude-3.5-sonnet": {"input": 3.0, "output": 15.0},
        "anthropic/claude-3-opus": {"input": 15.0, "output": 75.0},
        "anthropic/claude-3-haiku": {"input": 0.25, "output": 1.25},
        # Google via routing
        "google/gemini-pro-1.5": {"input": 1.25, "output": 5.0},
        "google/gemini-flash-1.5": {"input": 0.075, "output": 0.3},
        # Mistral
        "mistralai/mistral-large": {"input": 2.0, "output": 6.0},
        "mistralai/mixtral-8x7b-instruct": {"input": 0.24, "output": 0.24},
    }

    # Supported models (popular ones - OpenRouter supports many more)
    SUPPORTED_MODELS: set[str] = {
        # Meta Llama
        "meta-llama/llama-3.1-405b-instruct",
        "meta-llama/llama-3.1-70b-instruct",
        "meta-llama/llama-3.1-8b-instruct",
        "meta-llama/llama-3.2-90b-vision-instruct",
        "meta-llama/llama-3.2-11b-vision-instruct",
        # OpenAI via routing
        "openai/gpt-4o",
        "openai/gpt-4o-mini",
        "openai/gpt-4-turbo",
        "openai/gpt-4",
        "openai/gpt-3.5-turbo",
        # Anthropic via routing
        "anthropic/claude-3.5-sonnet",
        "anthropic/claude-3.5-sonnet:beta",
        "anthropic/claude-3-opus",
        "anthropic/claude-3-haiku",
        # Google via routing
        "google/gemini-pro-1.5",
        "google/gemini-flash-1.5",
        "google/gemini-2.0-flash-exp",
        # Mistral
        "mistralai/mistral-large",
        "mistralai/mistral-medium",
        "mistralai/mixtral-8x7b-instruct",
        "mistralai/mistral-7b-instruct",
        # DeepSeek
        "deepseek/deepseek-chat",
        "deepseek/deepseek-coder",
        # Qwen
        "qwen/qwen-2.5-72b-instruct",
        "qwen/qwen-2.5-coder-32b-instruct",
    }

    CAPABILITIES: set[LLMCapabilityType] = {
        LLMCapabilityType.COMPLETION,
        LLMCapabilityType.STREAMING,
        LLMCapabilityType.FUNCTION_CALLING,
        LLMCapabilityType.VISION,
        LLMCapabilityType.JSON_MODE,
        LLMCapabilityType.SYSTEM_PROMPT,
        LLMCapabilityType.MULTI_TURN,
        LLMCapabilityType.TOOL_USE,
    }

    # Model aliases for convenience
    MODEL_ALIASES: dict[str, str] = {
        "llama-3.1-70b": "meta-llama/llama-3.1-70b-instruct",
        "llama-3.1-405b": "meta-llama/llama-3.1-405b-instruct",
        "gpt-4o": "openai/gpt-4o",
        "claude-3.5-sonnet": "anthropic/claude-3.5-sonnet",
        "gemini-pro": "google/gemini-pro-1.5",
    }

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        api_key: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
        http_referer: str | None = None,
        x_title: str | None = None,
    ):
        """
        Initialize OpenRouter provider.

        Args:
            config: Configuration dict (alternative to kwargs)
            api_key: OpenRouter API key (or set OPENROUTER_API_KEY env var)
            model: Default model (default: meta-llama/llama-3.1-70b-instruct)
            timeout: Request timeout in seconds
            max_retries: Max retry attempts
            http_referer: HTTP-Referer header for app identification on openrouter.ai
            x_title: X-Title header for app name on rankings
        """
        if config is None:
            config = {}

        # Merge direct kwargs into config (kwargs take precedence)
        if api_key is not None:
            config["api_key"] = api_key
        if model is not None:
            config["model"] = model
        if timeout is not None:
            config["timeout"] = timeout
        if max_retries is not None:
            config["max_retries"] = max_retries
        if http_referer is not None:
            config["http_referer"] = http_referer
        if x_title is not None:
            config["x_title"] = x_title

        # Set defaults
        config.setdefault("name", "openrouter")
        config.setdefault("model", "meta-llama/llama-3.1-70b-instruct")
        config.setdefault("timeout", 120)  # Longer timeout for large models
        config.setdefault("max_retries", 3)
        config.setdefault("base_url", "https://openrouter.ai/api/v1")

        # Check for API key in config or environment
        if "api_key" not in config:
            env_key = os.environ.get("OPENROUTER_API_KEY")
            if env_key:
                config["api_key"] = env_key

        super().__init__(config)

        # OpenRouter-specific headers
        self._http_referer = config.get("http_referer")
        self._x_title = config.get("x_title")

        # Track costs
        self._total_cost = 0.0
        self._request_count = 0
        self._async_client: Any = None

    # ========================================================================
    # Abstract Property: name
    # ========================================================================

    @property
    def name(self) -> str:
        """Provider name."""
        return "openrouter"

    @property
    def default_model(self) -> str:
        """Default model."""
        return self._config.get("model", "meta-llama/llama-3.1-70b-instruct")

    # ========================================================================
    # Client Management
    # ========================================================================

    def _get_client(self) -> Any:
        """Get or create async OpenAI client configured for OpenRouter."""
        if self._async_client is None:
            try:
                from openai import AsyncOpenAI

                # Build default headers for OpenRouter
                default_headers = {}
                if self._http_referer:
                    default_headers["HTTP-Referer"] = self._http_referer
                if self._x_title:
                    default_headers["X-Title"] = self._x_title

                self._async_client = AsyncOpenAI(
                    api_key=self._api_key,
                    base_url=self._config.get("base_url", "https://openrouter.ai/api/v1"),
                    timeout=self._config.get("timeout", 120),
                    max_retries=0,
                    default_headers=default_headers if default_headers else None,
                )
            except ImportError:
                raise ImportError(
                    "OpenRouter provider requires 'openai' package. "
                    "Install with: pip install agenticraft-llm[openrouter]"
                )
        return self._async_client

    def _reset_client(self) -> None:
        """Reset client for key rotation."""
        self._async_client = None

    # ========================================================================
    # Abstract Methods: BaseLLMProvider
    # ========================================================================

    async def _make_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Make completion request to OpenRouter.

        Args:
            messages: List of message dicts.
            model: Model name (e.g., 'meta-llama/llama-3.1-70b-instruct').
            **kwargs: Additional parameters (temperature, max_tokens, etc).

        Returns:
            Response dict with content, model, provider, usage.
        """
        client = self._get_client()

        # Resolve model alias
        model = self.resolve_model_alias(model)

        # Build request params
        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
        }

        # Add optional parameters
        for key in [
            "temperature",
            "max_tokens",
            "top_p",
            "frequency_penalty",
            "presence_penalty",
            "response_format",
            "seed",
            "stop",
            "n",
        ]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Handle tools
        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            response = await client.chat.completions.create(**request_params)

            choice = response.choices[0]

            # Extract usage
            usage = {}
            if response.usage:
                usage = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }

            # Calculate cost
            cost = self._calculate_cost(model, usage)
            self._total_cost += cost
            self._request_count += 1

            # Extract tool calls
            tool_calls = None
            if hasattr(choice.message, "tool_calls") and choice.message.tool_calls:
                tool_calls = []
                for tc in choice.message.tool_calls:
                    try:
                        args = tc.function.arguments
                        if isinstance(args, str):
                            args = json.loads(args)
                        tool_calls.append(
                            {
                                "id": tc.id,
                                "name": tc.function.name,
                                "arguments": args,
                            }
                        )
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse tool arguments for {tc.function.name}")

            result = {
                "content": choice.message.content or "",
                "model": model,
                "provider": "openrouter",
                "usage": usage,
                "finish_reason": choice.finish_reason,
                "cost": cost,
            }

            if tool_calls:
                result["tool_calls"] = tool_calls

            return result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"OpenRouter request failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="openrouter", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="openrouter", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="openrouter", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="openrouter", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="openrouter",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"OpenRouter request failed: {e}")
            raise

    async def _stream_request(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream completion from OpenRouter.

        Args:
            messages: List of message dicts.
            model: Model name.
            **kwargs: Additional parameters.

        Yields:
            Response chunks.
        """
        client = self._get_client()

        # Resolve model alias
        model = self.resolve_model_alias(model)

        # Build request params
        request_params: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": True,
        }

        # Add optional parameters
        for key in ["temperature", "max_tokens", "top_p"]:
            if key in kwargs and kwargs[key] is not None:
                request_params[key] = kwargs[key]

        # Handle tools
        if "tools" in kwargs and kwargs["tools"]:
            request_params["tools"] = self._format_tools(kwargs["tools"])
            request_params["tool_choice"] = kwargs.get("tool_choice", "auto")

        try:
            stream = await client.chat.completions.create(**request_params)

            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta

                    result: dict[str, Any] = {
                        "model": model,
                        "provider": "openrouter",
                        "done": False,
                    }

                    if delta.content:
                        result["content"] = delta.content

                    if hasattr(delta, "tool_calls") and delta.tool_calls:
                        result["tool_call_delta"] = [
                            {
                                "index": tc.index,
                                "id": tc.id,
                                "name": tc.function.name if tc.function else None,
                                "arguments": tc.function.arguments if tc.function else None,
                            }
                            for tc in delta.tool_calls
                        ]

                    if chunk.choices[0].finish_reason:
                        result["done"] = True
                        result["finish_reason"] = chunk.choices[0].finish_reason

                    yield result

        except Exception as e:
            # Map OpenAI SDK exceptions to our hierarchy
            try:
                from openai import (
                    APIError,
                    APITimeoutError,
                    AuthenticationError,
                    NotFoundError,
                    RateLimitError,
                )
            except ImportError:
                logger.error(f"OpenRouter stream failed: {e}")
                raise
            if isinstance(e, RateLimitError):
                from agenticraft_llm.exceptions import LLMRateLimitError

                raise LLMRateLimitError(str(e), provider="openrouter", model=model) from e
            if isinstance(e, AuthenticationError):
                from agenticraft_llm.exceptions import LLMAuthenticationError

                raise LLMAuthenticationError(str(e), provider="openrouter", model=model) from e
            if isinstance(e, APITimeoutError):
                from agenticraft_llm.exceptions import LLMTimeoutError

                raise LLMTimeoutError(str(e), provider="openrouter", model=model) from e
            if isinstance(e, NotFoundError):
                from agenticraft_llm.exceptions import LLMModelNotFoundError

                raise LLMModelNotFoundError(str(e), provider="openrouter", model=model) from e
            if isinstance(e, APIError):
                from agenticraft_llm.exceptions import LLMProviderError

                raise LLMProviderError(
                    str(e),
                    provider="openrouter",
                    model=model,
                    status_code=getattr(e, "status_code", None),
                ) from e
            logger.error(f"OpenRouter stream failed: {e}")
            raise

    # ========================================================================
    # Abstract Methods: BaseMeshService
    # ========================================================================

    async def _initialize_internal(self) -> None:
        """Initialize OpenRouter provider internals."""
        # Validate we have an API key
        if not self._api_key:
            logger.warning("OpenRouter provider initialized without API key")

    async def _shutdown_internal(self) -> None:
        """Shutdown OpenRouter provider internals."""
        if self._async_client:
            await self._async_client.close()
            self._async_client = None

    async def health_check(self) -> HealthStatus:
        """Check provider health."""
        if not self._api_key:
            return HealthStatus(
                healthy=False,
                message="No API key configured",
            )

        try:
            # Try to list models as a health check
            client = self._get_client()
            await client.models.list()
            return HealthStatus(
                healthy=True,
                message="OpenRouter API is accessible",
            )
        except Exception as e:
            return HealthStatus(
                healthy=False,
                message=f"OpenRouter API error: {e}",
            )

    # ========================================================================
    # Helper Methods
    # ========================================================================

    def _format_tools(self, tools: list[Any]) -> list[dict[str, Any]]:
        """Format tools for OpenAI-compatible API."""
        formatted = []
        for tool in tools:
            if hasattr(tool, "to_openai_schema"):
                formatted.append(tool.to_openai_schema())
            elif isinstance(tool, dict):
                formatted.append(tool)
            else:
                formatted.append(
                    {
                        "type": "function",
                        "function": {
                            "name": getattr(tool, "name", "unknown"),
                            "description": getattr(tool, "description", ""),
                            "parameters": getattr(tool, "parameters", {}),
                        },
                    }
                )
        return formatted

    def _calculate_cost(self, model: str, usage: dict[str, int]) -> float:
        """Calculate request cost based on OpenRouter pricing."""
        pricing = self.PRICING.get(model)
        if not pricing:
            # Try prefix match
            for prefix, price in self.PRICING.items():
                if model.startswith(prefix.split("/")[0]):
                    pricing = price
                    break

        if not pricing:
            # Default to Llama 3.1 70B pricing
            pricing = self.PRICING["meta-llama/llama-3.1-70b-instruct"]

        # OpenRouter pricing is per 1M tokens
        input_cost = (usage.get("prompt_tokens", 0) / 1_000_000) * pricing["input"]
        output_cost = (usage.get("completion_tokens", 0) / 1_000_000) * pricing["output"]
        return input_cost + output_cost

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics."""
        return {
            "provider": "openrouter",
            "total_requests": self._request_count,
            "total_cost": round(self._total_cost, 6),
            "average_cost": round(self._total_cost / max(1, self._request_count), 6),
        }


__all__ = ["OpenRouterProvider"]
