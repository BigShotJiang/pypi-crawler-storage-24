"""FastAPI application factory for the OpenAI-compatible gateway."""

from __future__ import annotations

try:
    from fastapi import FastAPI
except ImportError as _err:
    raise ImportError(
        "Gateway requires FastAPI. Install with: pip install agenticraft-llm[gateway]"
    ) from _err

from ..base import BaseLLMProvider


def create_gateway_app(
    providers: dict[str, BaseLLMProvider] | None = None,
    router_strategy: str | None = None,
    api_key: str | None = None,
) -> FastAPI:
    """
    Create an OpenAI-compatible gateway application.

    Args:
        providers: Map of provider name to provider instance
        router_strategy: Optional routing strategy for auto-selection
        api_key: Optional API key for gateway authentication

    Returns:
        FastAPI application
    """
    app = FastAPI(
        title="agenticraft-llm Gateway",
        description="OpenAI-compatible LLM gateway with multi-provider routing",
        version="0.1.0",
    )

    app.state.providers = providers or {}
    app.state.api_key = api_key

    from .middleware import setup_middleware
    from .routes import create_router

    setup_middleware(app)
    app.include_router(create_router())

    return app
