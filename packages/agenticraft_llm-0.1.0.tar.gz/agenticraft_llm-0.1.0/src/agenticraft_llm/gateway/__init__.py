"""
OpenAI-Compatible Gateway

FastAPI server that exposes LLM providers through an OpenAI-compatible API.

Example:
    from agenticraft_llm.gateway import create_gateway_app

    app = create_gateway_app(
        providers={"openai": provider},
        api_key="my-gateway-key",
    )
"""

from __future__ import annotations


def __getattr__(name: str):
    if name == "create_gateway_app":
        from .app import create_gateway_app

        return create_gateway_app
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["create_gateway_app"]
