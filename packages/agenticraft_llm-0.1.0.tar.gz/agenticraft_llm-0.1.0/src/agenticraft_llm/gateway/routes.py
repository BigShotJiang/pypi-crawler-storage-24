"""Gateway route definitions — OpenAI-compatible API."""

from __future__ import annotations

import json
import time
import uuid
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

# ============================================================================
# Request/Response schemas (OpenAI-compatible)
# ============================================================================


class ChatMessage(BaseModel):
    role: str
    content: str | None = None
    name: str | None = None
    tool_calls: list[dict[str, Any]] | None = None
    tool_call_id: str | None = None


class ChatCompletionRequest(BaseModel):
    model: str
    messages: list[ChatMessage]
    temperature: float | None = None
    max_tokens: int | None = None
    top_p: float | None = None
    stream: bool = False
    stop: list[str] | str | None = None
    tools: list[dict[str, Any]] | None = None
    tool_choice: str | dict[str, Any] | None = None
    n: int | None = None
    seed: int | None = None


class UsageResponse(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ChoiceMessage(BaseModel):
    role: str = "assistant"
    content: str | None = None
    tool_calls: list[dict[str, Any]] | None = None


class Choice(BaseModel):
    index: int = 0
    message: ChoiceMessage
    finish_reason: str | None = "stop"


class ChatCompletionResponse(BaseModel):
    id: str = Field(default_factory=lambda: f"chatcmpl-{uuid.uuid4().hex[:12]}")
    object: str = "chat.completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str = ""
    choices: list[Choice] = Field(default_factory=list)
    usage: UsageResponse = Field(default_factory=UsageResponse)


class ModelObject(BaseModel):
    id: str
    object: str = "model"
    created: int = Field(default_factory=lambda: int(time.time()))
    owned_by: str = "agenticraft"


class ModelListResponse(BaseModel):
    object: str = "list"
    data: list[ModelObject] = Field(default_factory=list)


# ============================================================================
# Routes
# ============================================================================


def create_router() -> APIRouter:
    router = APIRouter()

    @router.get("/health")
    async def health():
        return {"status": "ok"}

    @router.get("/v1/models")
    async def list_models(request: Request):
        providers: dict = request.app.state.providers
        models = []
        for provider_name, provider in providers.items():
            for model in provider.get_available_models():
                models.append(ModelObject(id=model, owned_by=provider_name))
        return ModelListResponse(data=models)

    @router.post("/v1/chat/completions")
    async def chat_completions(body: ChatCompletionRequest, request: Request):
        providers: dict = request.app.state.providers

        # Find provider for requested model
        provider = None
        if body.model == "auto":
            # Use first available provider
            if providers:
                provider = next(iter(providers.values()))
        else:
            for p in providers.values():
                if p.supports_model(body.model):
                    provider = p
                    break

        if provider is None:
            return JSONResponse(
                status_code=404,
                content={
                    "error": {
                        "message": f"Model '{body.model}' not found",
                        "type": "invalid_request_error",
                    }
                },
            )

        messages = [m.model_dump(exclude_none=True) for m in body.messages]
        kwargs: dict[str, Any] = {}
        if body.temperature is not None:
            kwargs["temperature"] = body.temperature
        if body.max_tokens is not None:
            kwargs["max_tokens"] = body.max_tokens
        if body.top_p is not None:
            kwargs["top_p"] = body.top_p
        if body.stop is not None:
            kwargs["stop"] = body.stop
        if body.tools is not None:
            kwargs["tools"] = body.tools
        if body.tool_choice is not None:
            kwargs["tool_choice"] = body.tool_choice

        if body.stream:
            return StreamingResponse(
                _stream_response(provider, messages, body.model, kwargs),
                media_type="text/event-stream",
            )

        try:
            response = await provider.complete(messages, body.model, **kwargs)

            usage = UsageResponse()
            if response.usage:
                usage = UsageResponse(
                    prompt_tokens=response.usage.prompt_tokens,
                    completion_tokens=response.usage.completion_tokens,
                    total_tokens=response.usage.total_tokens,
                )

            tool_calls = None
            if response.tool_calls:
                tool_calls = response.tool_calls

            return ChatCompletionResponse(
                model=response.model,
                choices=[
                    Choice(
                        message=ChoiceMessage(
                            content=response.content,
                            tool_calls=tool_calls,
                        ),
                        finish_reason=response.finish_reason or "stop",
                    )
                ],
                usage=usage,
            )

        except Exception as e:
            return JSONResponse(
                status_code=500,
                content={
                    "error": {
                        "message": str(e),
                        "type": "server_error",
                    }
                },
            )

    @router.get("/v1/routing/stats")
    async def routing_stats(request: Request):
        providers: dict = request.app.state.providers
        stats = {}
        for name, provider in providers.items():
            stats[name] = {
                "models": provider.get_available_models(),
                "capabilities": list(provider.get_capabilities()),
                "metrics": {
                    "total_requests": provider.metrics.total_requests,
                    "success_rate": provider.metrics.success_rate,
                    "average_latency_ms": provider.metrics.average_latency_ms,
                },
            }
        return {"providers": stats}

    return router


async def _stream_response(provider, messages, model, kwargs):
    """Generate SSE stream matching OpenAI format."""
    response_id = f"chatcmpl-{uuid.uuid4().hex[:12]}"
    created = int(time.time())

    try:
        async for chunk in provider.stream(messages, model, **kwargs):
            data = {
                "id": response_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": chunk.model,
                "choices": [
                    {
                        "index": 0,
                        "delta": {},
                        "finish_reason": None,
                    }
                ],
            }

            if chunk.content:
                data["choices"][0]["delta"]["content"] = chunk.content

            if chunk.tool_call_delta:
                data["choices"][0]["delta"]["tool_calls"] = [chunk.tool_call_delta]

            if chunk.is_final:
                data["choices"][0]["finish_reason"] = chunk.finish_reason or "stop"

            yield f"data: {json.dumps(data)}\n\n"

    except Exception as e:
        error_data = {"error": {"message": str(e), "type": "server_error"}}
        yield f"data: {json.dumps(error_data)}\n\n"

    yield "data: [DONE]\n\n"
