"""Gateway middleware for authentication and request logging."""

from __future__ import annotations

import logging
import time

from fastapi import FastAPI, Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)


class AuthMiddleware(BaseHTTPMiddleware):
    """API key authentication middleware."""

    async def dispatch(self, request: Request, call_next):
        api_key = request.app.state.api_key

        # Skip auth for health and docs endpoints
        if request.url.path in ("/health", "/docs", "/openapi.json"):
            return await call_next(request)

        if api_key:
            auth_header = request.headers.get("Authorization", "")
            if not auth_header.startswith("Bearer "):
                return Response(
                    content='{"error": {"message": "Missing Authorization header"'
                    ', "type": "invalid_request_error"}}',
                    status_code=401,
                    media_type="application/json",
                )
            token = auth_header[7:]
            if token != api_key:
                return Response(
                    content='{"error": {"message": "Invalid API key"'
                    ', "type": "invalid_request_error"}}',
                    status_code=401,
                    media_type="application/json",
                )

        return await call_next(request)


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Request timing and logging middleware."""

    async def dispatch(self, request: Request, call_next):
        start = time.monotonic()
        response = await call_next(request)
        duration = (time.monotonic() - start) * 1000
        logger.info(
            f"{request.method} {request.url.path} -> {response.status_code} ({duration:.1f}ms)"
        )
        response.headers["X-Response-Time-Ms"] = f"{duration:.1f}"
        return response


def setup_middleware(app: FastAPI) -> None:
    """Add middleware to the gateway app."""
    app.add_middleware(RequestLoggingMiddleware)
    app.add_middleware(AuthMiddleware)
