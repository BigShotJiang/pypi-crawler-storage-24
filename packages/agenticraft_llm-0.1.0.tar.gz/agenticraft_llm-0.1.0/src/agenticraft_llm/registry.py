"""
Provider Registry

Simple registry for discovering and instantiating LLM providers.
"""

from __future__ import annotations

import logging
from typing import Any

from .base import BaseLLMProvider

logger = logging.getLogger(__name__)

_registry: dict[str, type[BaseLLMProvider]] = {}


def register(name: str, provider_cls: type[BaseLLMProvider]) -> None:
    """Register a provider class."""
    _registry[name] = provider_cls


def get_provider_class(name: str) -> type[BaseLLMProvider] | None:
    """Get a registered provider class by name."""
    # Check registry first
    if name in _registry:
        return _registry[name]

    # Auto-discover from providers module
    _auto_discover()
    return _registry.get(name)


def get_provider(name: str, **kwargs: Any) -> BaseLLMProvider:
    """Create a provider instance by name."""
    cls = get_provider_class(name)
    if cls is None:
        available = list_providers()
        raise ValueError(f"Unknown provider '{name}'. Available: {available}")
    return cls(**kwargs)


def list_providers() -> list[str]:
    """List all registered provider names."""
    _auto_discover()
    return sorted(_registry.keys())


_discovered = False


def _auto_discover() -> None:
    """Auto-discover providers from the providers subpackage."""
    global _discovered
    if _discovered:
        return
    _discovered = True

    provider_map = {
        "openai": (".providers.openai", "OpenAIProvider"),
        "anthropic": (".providers.anthropic", "AnthropicProvider"),
        "google": (".providers.google", "GoogleProvider"),
        "azure_openai": (".providers.azure_openai", "AzureOpenAIProvider"),
        "bedrock": (".providers.bedrock", "BedrockProvider"),
        "fireworks": (".providers.fireworks", "FireworksProvider"),
        "cerebras": (".providers.cerebras", "CerebrasProvider"),
        "cohere": (".providers.cohere", "CohereProvider"),
        "deepseek": (".providers.deepseek", "DeepSeekProvider"),
        "xai": (".providers.xai", "XAIProvider"),
        "ollama": (".providers.ollama", "OllamaProvider"),
        "openrouter": (".providers.openrouter", "OpenRouterProvider"),
        "perplexity": (".providers.perplexity", "PerplexityProvider"),
        "nebius": (".providers.nebius", "NebiusProvider"),
    }

    for name, (module_path, class_name) in provider_map.items():
        if name in _registry:
            continue
        try:
            import importlib

            module = importlib.import_module(module_path, package="agenticraft_llm")
            cls = getattr(module, class_name)
            _registry[name] = cls
        except (ImportError, AttributeError) as e:
            logger.debug(f"Provider '{name}' not available: {e}")


__all__ = [
    "register",
    "get_provider_class",
    "get_provider",
    "list_providers",
]
