"""Multi-provider routing with Thompson sampling."""

import asyncio

from agenticraft_llm import (
    AnthropicProvider,
    CostAwareRouter,
    OpenAIProvider,
    ProviderCostProfile,
)


async def main():
    # Set up providers
    openai = OpenAIProvider(api_key="sk-...")
    anthropic = AnthropicProvider(api_key="sk-ant-...")

    # Create cost-aware router
    router = CostAwareRouter()

    # Register provider cost profiles
    router.update_profile(
        "openai",
        ProviderCostProfile(
            provider_name="openai",
            cost_per_1k_input=0.0025,
            cost_per_1k_output=0.01,
        ),
    )
    router.update_profile(
        "anthropic",
        ProviderCostProfile(
            provider_name="anthropic",
            cost_per_1k_input=0.003,
            cost_per_1k_output=0.015,
        ),
    )

    # Select best provider based on cost/quality trade-off
    providers = {"openai": openai, "anthropic": anthropic}

    for i in range(5):
        decision = await router.select_provider(
            providers=list(providers.keys()),
            estimated_tokens=500,
            quality_threshold=0.7,
        )
        print(f"Request {i + 1}: Selected {decision.provider} (score: {decision.score:.3f})")

        # Use the selected provider
        provider = providers[decision.provider]
        response = await provider.complete(
            [{"role": "user", "content": "What is 2+2?"}]
        )

        # Update router with results
        router.update_posterior(
            decision.provider,
            success=True,
            latency_ms=response.latency_ms,
            cost=response.cost,
        )

    # Print routing stats
    stats = router.get_stats()
    for name, s in stats.items():
        print(f"{name}: alpha={s['alpha']:.1f}, beta={s['beta']:.1f}")


if __name__ == "__main__":
    asyncio.run(main())
