"""Async streaming example."""

import asyncio

from agenticraft_llm import OpenAIProvider


async def main():
    provider = OpenAIProvider(api_key="sk-...")

    print("Streaming response:")
    async for chunk in provider.stream(
        [{"role": "user", "content": "Tell me a short story about a robot."}],
        temperature=0.8,
    ):
        print(chunk.content, end="", flush=True)
        if chunk.is_final:
            print(f"\n\n[Done: {chunk.finish_reason}]")

    await provider.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
