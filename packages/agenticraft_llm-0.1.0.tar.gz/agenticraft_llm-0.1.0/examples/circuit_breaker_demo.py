"""Circuit breaker and rate limiter demo."""

import asyncio

from agenticraft_llm import OpenAIProvider
from agenticraft_llm.resilience import CircuitBreakerConfig, RateLimitConfig


async def main():
    # Provider with resilience features enabled
    provider = OpenAIProvider(
        api_key="sk-...",
        model="gpt-4o-mini",
        enable_circuit_breaker=True,
        circuit_breaker_config=CircuitBreakerConfig(
            failure_threshold=3,       # Open after 3 consecutive failures
            recovery_timeout=30.0,     # Try again after 30 seconds
            success_threshold=2,       # Close after 2 successes in half-open
        ),
        enable_rate_limiter=True,
        rate_limiter_config=RateLimitConfig(
            max_calls=10,              # 10 calls per window
            time_window=60.0,          # 60-second window
            burst_size=5,              # Allow bursts of 5
        ),
    )

    # Make requests with automatic protection
    for i in range(5):
        try:
            response = await provider.complete(
                [{"role": "user", "content": f"Request {i + 1}"}]
            )
            print(f"Request {i + 1}: OK ({response.latency_ms:.0f}ms)")
        except Exception as e:
            print(f"Request {i + 1}: {type(e).__name__}: {e}")

    await provider.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
