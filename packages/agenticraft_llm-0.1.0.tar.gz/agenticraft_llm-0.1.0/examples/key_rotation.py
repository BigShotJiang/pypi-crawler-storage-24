"""Multi-key rotation example."""

import asyncio

from agenticraft_llm import OpenAIProvider


async def main():
    # Provider with multiple API keys and automatic rotation
    provider = OpenAIProvider(
        api_keys=["sk-key1", "sk-key2", "sk-key3"],
        key_rotation_strategy="adaptive",  # Favors healthiest keys
        model="gpt-4o-mini",
    )

    # Each request automatically rotates keys
    for i in range(6):
        response = await provider.complete(
            [{"role": "user", "content": f"Request {i + 1}: What is {i}+{i}?"}]
        )
        print(f"Request {i + 1}: {response.content[:50]}...")

    # Check key pool health
    status = await provider.get_key_pool_status()
    if status:
        print(f"\nKey pool: {status['available_keys']}/{status['total_keys']} available")

    await provider.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
