"""OpenAI-compatible gateway server example.

Run with:
    pip install agenticraft-llm[openai,gateway]
    python examples/gateway_server.py

Then use any OpenAI-compatible client:
    curl http://localhost:8000/v1/chat/completions \
      -H "Authorization: Bearer my-gateway-key" \
      -d '{"model": "auto", "messages": [{"role": "user", "content": "Hello"}]}'
"""

import uvicorn

from agenticraft_llm import OpenAIProvider
from agenticraft_llm.gateway import create_gateway_app

# Set up providers
openai_provider = OpenAIProvider(api_key="sk-...")

# Create gateway app
app = create_gateway_app(
    providers={"openai": openai_provider},
    api_key="my-gateway-key",  # Optional: require auth
)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
