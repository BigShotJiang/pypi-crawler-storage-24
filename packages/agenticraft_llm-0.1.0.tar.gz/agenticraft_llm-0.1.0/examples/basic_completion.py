"""Basic completion example."""

import asyncio

from agenticraft_llm import OpenAIProvider


async def main():
    provider = OpenAIProvider(api_key="sk-...")

    response = await provider.complete(
        [{"role": "user", "content": "What is the capital of France?"}]
    )

    print(f"Content: {response.content}")
    print(f"Model: {response.model}")
    print(f"Tokens: {response.usage}")
    print(f"Cost: ${response.cost:.6f}")
    print(f"Latency: {response.latency_ms:.0f}ms")

    await provider.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
