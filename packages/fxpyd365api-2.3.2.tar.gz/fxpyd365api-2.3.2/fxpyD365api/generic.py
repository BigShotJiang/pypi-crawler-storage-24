"""
Legacy GenericWrapper for backward compatibility.

DEPRECATED: Use get_wrapper() from factory.py instead.

This module maintains backward compatibility with code using the old
GenericWrapper class. New code should use the factory functions.
"""

import warnings
from typing import Any

from .factory import get_wrapper


class GenericWrapper:
    """
    Legacy wrapper factory class.

    DEPRECATED: Use get_wrapper() instead.

    This class is maintained for backward compatibility. For new code,
    use get_wrapper() from the factory module instead.

    Example (deprecated):
        api = GenericWrapper(entity_type='accounts', ...)

    Example (modern):
        api = get_wrapper('accounts', ...)
    """

    def __new__(
        cls,
        entity_type: str,
        async_mode: bool = False,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """Create a wrapper instance."""
        warnings.warn(
            "GenericWrapper is deprecated. Use get_wrapper() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return get_wrapper(entity_type, async_mode=async_mode, **kwargs)
