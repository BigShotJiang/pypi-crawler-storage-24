"""
fxpyD365api - Python wrapper for Microsoft Dynamics 365 Web API.

Provides both synchronous and asynchronous interfaces for CRUD operations,
authentication, and advanced querying.
"""

from .config import Config
from .exceptions import D365ApiError, D365ApiWrapperError
from .sync import SyncBaseApiWrapper
from .async_ import AsyncBaseApiWrapper
from .factory import get_wrapper, create_async_wrapper, create_sync_wrapper
from .query_builder import QueryBuilder
from .generic import GenericWrapper  # legacy support

__version__ = "2.3.2"

__all__ = [
    # Primary exports
    "get_wrapper",
    "create_async_wrapper",
    "create_sync_wrapper",
    "GenericWrapper",  # legacy

    # Configuration
    "Config",

    # Query building
    "QueryBuilder",

    # Exceptions
    "D365ApiError",
    "D365ApiWrapperError",

    # Core classes
    "SyncBaseApiWrapper",
    "AsyncBaseApiWrapper",
]