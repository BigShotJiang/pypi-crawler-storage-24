"""
Configuration management for D365 API wrapper.

Provides centralized configuration handling with environment variable fallbacks,
validation, and sensible defaults.
"""

import os
from dataclasses import dataclass
from typing import Optional


@dataclass
class Config:
    """
    Configuration for D365 API wrapper.

    All parameters can be provided directly or via environment variables.
    Environment variables take precedence only if parameter is None.

    Attributes:
        org_url: D365 organization URL (env: D365_ORG_URL)
        tenant: Azure AD tenant ID (env: D365_TENANT)
        client_id: OAuth client ID (env: D365_CLIENT_ID)
        client_secret: OAuth client secret (env: D365_CLIENT_SECRET)
        api_url_prefix: API URL prefix (default: '/api/data/v9.0' for CE)
                        Use '/data' for Finance & Operations (FO)
        timeout: Request timeout in seconds (default: 20)
        page_size: Default page size for queries (default: 100)
        token_refresh_buffer: Minutes before expiry to refresh token (default: 5)
        impersonate_user: MSCRMCallerID for impersonation (optional)
    """

    org_url: Optional[str] = None
    tenant: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    api_url_prefix: str = "/api/data/v9.0"  # CE default; use "/data" for FO
    timeout: int = 20
    page_size: int = 100
    token_refresh_buffer: int = 5
    impersonate_user: Optional[str] = None

    def __post_init__(self) -> None:
        """Validate configuration and apply environment variable fallbacks."""
        self.org_url = self.org_url or os.getenv('D365_ORG_URL')
        self.tenant = self.tenant or os.getenv('D365_TENANT')
        self.client_id = self.client_id or os.getenv('D365_CLIENT_ID')
        self.client_secret = self.client_secret or os.getenv('D365_CLIENT_SECRET')

        self._validate()

    def _validate(self) -> None:
        """Validate that all required fields are present."""
        if not self.org_url:
            raise ValueError(
                'Missing org_url. Provide directly or set D365_ORG_URL environment variable.'
            )
        if not self.tenant:
            raise ValueError(
                'Missing tenant. Provide directly or set D365_TENANT environment variable.'
            )
        if not self.client_id:
            raise ValueError(
                'Missing client_id. Provide directly or set D365_CLIENT_ID environment variable.'
            )
        if not self.client_secret:
            raise ValueError(
                'Missing client_secret. Provide directly or set D365_CLIENT_SECRET environment variable.'
            )

    @property
    def full_api_url_prefix(self) -> str:
        """
        Get the full API URL prefix including organization URL.

        Returns:
            Full prefix for API calls (e.g., https://org.crm4.dynamics.com/api/data/v9.0)
        """
        return f"{self.org_url}{self.api_url_prefix}"

