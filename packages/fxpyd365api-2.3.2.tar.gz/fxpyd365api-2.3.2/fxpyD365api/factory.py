"""
Factory functions for creating D365 API wrapper instances.

Provides convenient factory functions for both synchronous and asynchronous
wrappers with unified interface.
"""

from typing import Any, Optional, Union

from .config import Config
from .sync import SyncBaseApiWrapper
from .async_ import AsyncBaseApiWrapper


def get_wrapper(
    entity_type: str,
    async_mode: bool = False,
    config: Optional[Config] = None,
    **kwargs: Any,
) -> Union[SyncBaseApiWrapper, AsyncBaseApiWrapper]:
    """
    Create a D365 API wrapper instance.

    Args:
        entity_type: D365 entity type (e.g., 'accounts', 'contacts')
        async_mode: If True, return async wrapper; otherwise sync wrapper
        config: Config object (takes precedence over kwargs)
        **kwargs: Additional configuration parameters
                  (org_url, tenant, client_id, client_secret, timeout, etc.)

    Returns:
        SyncBaseApiWrapper or AsyncBaseApiWrapper instance

    Example:
        # Synchronous
        api = get_wrapper('accounts', org_url='https://org.crm4.dynamics.com', ...)
        accounts = api.get_top(qty=10)

        # Asynchronous with context manager
        async with get_wrapper('contacts', async_mode=True, ...) as api:
            contacts = await api.get_top(qty=10)
    """
    wrapper_class = AsyncBaseApiWrapper if async_mode else SyncBaseApiWrapper
    instance = wrapper_class(entity_type=entity_type, config=config, **kwargs)
    return instance


def create_async_wrapper(
    entity_type: str,
    config: Optional[Config] = None,
    **kwargs: Any,
) -> AsyncBaseApiWrapper:
    """
    Create an asynchronous D365 API wrapper instance.

    Convenience function for async wrapper creation.

    Args:
        entity_type: D365 entity type
        config: Config object
        **kwargs: Additional configuration parameters

    Returns:
        AsyncBaseApiWrapper instance

    Example:
        async with create_async_wrapper('accounts', ...) as api:
            results = await api.get_top(qty=5)
    """
    return get_wrapper(entity_type, async_mode=True, config=config, **kwargs)


def create_sync_wrapper(
    entity_type: str,
    config: Optional[Config] = None,
    **kwargs: Any,
) -> SyncBaseApiWrapper:
    """
    Create a synchronous D365 API wrapper instance.

    Convenience function for sync wrapper creation.

    Args:
        entity_type: D365 entity type
        config: Config object
        **kwargs: Additional configuration parameters

    Returns:
        SyncBaseApiWrapper instance

    Example:
        api = create_sync_wrapper('accounts', ...)
        results = api.get_top(qty=5)
        api.close()
    """
    return get_wrapper(entity_type, async_mode=False, config=config, **kwargs)
