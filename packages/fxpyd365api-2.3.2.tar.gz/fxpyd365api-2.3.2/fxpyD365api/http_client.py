"""
HTTP client protocols and implementations for D365 API wrapper.

Provides abstract interfaces and concrete implementations for synchronous
and asynchronous HTTP requests.
"""

from typing import Any, Dict, Optional, Protocol, Union


class HttpResponse(Protocol):
    """Protocol for HTTP responses."""

    status_code: int
    text: str

    def json(self) -> Dict[str, Any]:
        """Parse response as JSON."""
        ...


class HttpClient(Protocol):
    """Protocol for HTTP clients."""

    def request(
        self,
        method: str,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> HttpResponse:
        """
        Make an HTTP request.

        Args:
            method: HTTP method (GET, POST, PATCH, DELETE)
            url: Request URL
            params: Query parameters
            headers: Request headers
            json: JSON request body
            timeout: Request timeout

        Returns:
            HttpResponse object
        """
        ...

    def close(self) -> None:
        """Close the HTTP client and clean up resources."""
        ...


class AsyncHttpClient(Protocol):
    """Protocol for async HTTP clients."""

    async def request(
        self,
        method: str,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> HttpResponse:
        """
        Make an async HTTP request.

        Args:
            method: HTTP method (GET, POST, PATCH, DELETE)
            url: Request URL
            params: Query parameters
            headers: Request headers
            json: JSON request body
            timeout: Request timeout

        Returns:
            HttpResponse object
        """
        ...

    async def close(self) -> None:
        """Close the HTTP client and clean up resources."""
        ...


class ResponseValidator:
    """Validates HTTP responses and handles errors."""

    @staticmethod
    def validate_get_response(response: HttpResponse, url: str, method: str = "GET") -> Dict[str, Any]:
        """
        Validate a GET response and return JSON.

        Args:
            response: HTTP response
            url: Request URL (for error context)
            method: HTTP method (for error context)

        Returns:
            Parsed JSON response

        Raises:
            D365ApiError: If response indicates an error
        """
        from .exceptions import D365ApiError

        if response.status_code == 200:
            return response.json()

        raise D365ApiError(
            f"API request failed",
            status_code=response.status_code,
            details={"response": response.text[:500]},
            url=url,
            method=method,
        )

    @staticmethod
    def validate_mutation_response(
        response: HttpResponse, url: str, method: str
    ) -> Union[Dict[str, Any], int]:
        """
        Validate a mutation response (POST, PATCH, DELETE).

        Args:
            response: HTTP response
            url: Request URL
            method: HTTP method

        Returns:
            Parsed JSON for POST/PATCH, status code for DELETE

        Raises:
            D365ApiError: If response indicates an error
        """
        from .exceptions import D365ApiError

        if method.upper() == "DELETE":
            if response.status_code in (200, 204):
                return response.status_code
            raise D365ApiError(
                f"Delete operation failed",
                status_code=response.status_code,
                details={"response": response.text[:500]},
                url=url,
                method=method,
            )

        # POST and PATCH - try to return JSON if available
        if response.status_code in (200, 201):
            try:
                return response.json()
            except Exception:
                # If response is not JSON, return as-is
                return {"status": response.status_code, "text": response.text}

        raise D365ApiError(
            f"API request failed",
            status_code=response.status_code,
            details={"response": response.text[:500]},
            url=url,
            method=method,
        )

