"""
Exception classes for D365 API wrapper.

Provides structured error handling with context, error codes, and suggestions
for debugging and error recovery.
"""

from typing import Any, Dict, Optional


class D365ApiError(Exception):
    """
    Raised when the D365 API returns an error or the request fails.

    Attributes:
        status_code: HTTP status code (if applicable)
        error_message: Error message from API or internal description
        details: Additional error details (response body, etc.)
        url: Request URL that caused the error
        method: HTTP method that was used
    """

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        details: Optional[Dict[str, Any]] = None,
        url: Optional[str] = None,
        method: Optional[str] = None,
    ):
        self.error_message = message
        self.status_code = status_code
        self.details = details or {}
        self.url = url
        self.method = method

        formatted_message = self._format_message()
        super().__init__(formatted_message)

    def _format_message(self) -> str:
        """Format a user-friendly error message."""
        parts = [self.error_message]

        if self.status_code:
            parts.append(f"[HTTP {self.status_code}]")

        if self.method and self.url:
            parts.append(f"{self.method} {self.url}")

        message = " ".join(parts)

        if self.details:
            details_str = str(self.details)
            if len(details_str) > 200:
                details_str = details_str[:200] + "..."
            message += f"\nDetails: {details_str}"

        return message


class D365ApiWrapperError(Exception):
    """
    Raised when the wrapper encounters an internal error.

    This typically indicates incorrect usage of the wrapper API or
    an internal state that shouldn't occur.
    """

    def __init__(self, message: str, context: Optional[Dict[str, Any]] = None):
        self.message = message
        self.context = context or {}

        if self.context:
            context_str = ", ".join(f"{k}={v}" for k, v in self.context.items())
            formatted_message = f"{message} [{context_str}]"
        else:
            formatted_message = message

        super().__init__(formatted_message)
