"""
OData query builder for constructing D365 API queries.

Provides a fluent interface for building OData query parameters
and managing Prefer headers.
"""

from typing import Any, Dict, List, Optional, Tuple


class QueryBuilder:
    """
    Builds OData query parameters for D365 API requests.

    Supports filtering, selection, ordering, pagination, and annotations
    through a composable interface.

    Example:
        query = QueryBuilder(page_size=100)
        query.select(['name', 'accountid'])
        query.filter('statecode eq 0')
        query.order_by('name')
        params, headers = query.build_for_list(page=1)
    """

    def __init__(self, page_size: int = 100) -> None:
        """
        Initialize the query builder.

        Args:
            page_size: Default page size for pagination
        """
        self.page_size = page_size
        self._select: Optional[str] = None
        self._filter: Optional[str] = None
        self._order_by: Optional[str] = None
        self._annotations: Optional[str] = None
        self._extra_params: Dict[str, Any] = {}
        self._prefer_options: Dict[str, str] = {}

    def select(self, columns: List[str]) -> "QueryBuilder":
        """
        Add column selection.

        Args:
            columns: List of column names to select

        Returns:
            Self for chaining
        """
        self._select = ','.join(columns)
        return self

    def filter(self, filter_expr: str) -> "QueryBuilder":
        """
        Add OData filter expression.

        Args:
            filter_expr: OData filter expression (e.g., 'statecode eq 0')

        Returns:
            Self for chaining
        """
        self._filter = filter_expr
        return self

    def order_by(self, order_expr: str) -> "QueryBuilder":
        """
        Add OData order by expression.

        Args:
            order_expr: OData orderby expression (e.g., 'name asc')

        Returns:
            Self for chaining
        """
        self._order_by = order_expr
        return self

    def annotations(self, annotation_type: str) -> "QueryBuilder":
        """
        Add annotation preference.

        Args:
            annotation_type: Annotation type (e.g., 'odata.metadata=full')

        Returns:
            Self for chaining
        """
        self._annotations = annotation_type
        return self

    def add_param(self, key: str, value: Any) -> "QueryBuilder":
        """
        Add custom query parameter.

        Args:
            key: Parameter key
            value: Parameter value

        Returns:
            Self for chaining
        """
        self._extra_params[key] = value
        return self

    def reset(self) -> "QueryBuilder":
        """Reset all query parameters."""
        self._select = None
        self._filter = None
        self._order_by = None
        self._annotations = None
        self._extra_params = {}
        self._prefer_options = {}
        return self

    def build_for_list(
        self, page: int = 1, api_url_prefix: str = "/api/data/v9.0"
    ) -> Tuple[Dict[str, Any], Dict[str, str]]:
        """
        Build parameters for listing entities (with paging).

        Args:
            page: Page number (1-indexed)
            api_url_prefix: API URL prefix (determines paging strategy).
                           Use '/api/data/v9.0' for CE, '/data' for FO

        Returns:
            Tuple of (params dict, headers dict)
        """
        params = self._build_base_params()
        headers = self._build_headers()

        # Add paging
        # CE uses skiptoken paging, FO uses top/skip pagination
        params['$count'] = 'true'
        if '/api/data' in api_url_prefix:
            # Customer Engagement - uses skiptoken
            params['$skiptoken'] = f'<cookie pagenumber="{page}" istracking="False" />'
        elif page > 1:
            # Finance & Operations - uses top/skip
            params['$top'] = self.page_size
            params['$skip'] = self.page_size * (page - 1)

        return params, headers

    def build_for_top(self, qty: int) -> Tuple[Dict[str, Any], Dict[str, str]]:
        """
        Build parameters for fetching top N records.

        Args:
            qty: Number of records to fetch

        Returns:
            Tuple of (params dict, headers dict)
        """
        params = self._build_base_params()
        params['$top'] = qty
        headers = self._build_headers()
        return params, headers

    def build_for_retrieve(
        self, query_dict: Optional[Dict[str, Any]] = None
    ) -> Tuple[Dict[str, Any], Dict[str, str]]:
        """
        Build parameters for retrieving a single entity.

        Args:
            query_dict: Additional query parameters

        Returns:
            Tuple of (params dict, headers dict)
        """
        params = self._build_base_params(include_count=False)
        if query_dict:
            params.update(query_dict)
        headers = self._build_headers()
        return params, headers

    def _build_base_params(self, include_count: bool = True) -> Dict[str, Any]:
        """Build base query parameters."""
        params = {}

        if self._select:
            params['$select'] = self._select
        if self._filter:
            params['$filter'] = self._filter
        if self._order_by:
            params['$orderby'] = self._order_by
        if include_count:
            params['$count'] = 'true'

        params.update(self._extra_params)
        return params

    def _build_headers(self) -> Dict[str, str]:
        """Build preference headers."""
        headers = {}

        if self._annotations:
            self._prefer_options['odata.include-annotations'] = f'"{self._annotations}"'

        if self._prefer_options:
            headers['Prefer'] = ','.join(
                f'{k}={v}' for k, v in self._prefer_options.items()
            )

        return headers





