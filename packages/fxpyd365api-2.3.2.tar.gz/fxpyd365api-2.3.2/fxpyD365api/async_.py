"""
Asynchronous D365 API wrapper implementation.

Provides async operations for retrieving, creating, updating, and deleting
entities in Dynamics 365.
"""

import asyncio
import logging
from typing import Any, Dict, Optional, Union

import aiohttp

from .base import BaseApiWrapperMixin
from .exceptions import D365ApiError, D365ApiWrapperError
from .http_client import ResponseValidator
from .query_builder import QueryBuilder

logger = logging.getLogger(__name__)


class AsyncBaseApiWrapper(BaseApiWrapperMixin):
    """Asynchronous wrapper for D365 API."""

    DEFAULT_TIMEOUT = 20

    def __init__(self, *args: Any, timeout: Optional[int] = None, **kwargs: Any):
        """
        Initialize asynchronous API wrapper.

        Args:
            timeout: Request timeout in seconds
            *args, **kwargs: Arguments passed to BaseApiWrapperMixin
        """
        super().__init__(*args, **kwargs)
        self.timeout = timeout or self.DEFAULT_TIMEOUT
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        """
        Get or create the aiohttp session.

        Returns:
            aiohttp ClientSession
        """
        if self._session is None:
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session

    async def close(self) -> None:
        """Close the session and clean up resources."""
        if self._session:
            await self._session.close()
            self._session = None

    async def __aenter__(self) -> "AsyncBaseApiWrapper":
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
        await self.close()

    async def _request(
        self,
        method: str,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
    ) -> aiohttp.ClientResponse:
        """
        Execute an async HTTP request.

        Args:
            method: HTTP method
            url: Request URL
            params: Query parameters
            headers: Request headers
            json: JSON request body

        Returns:
            aiohttp ClientResponse

        Raises:
            D365ApiError: On request failure
        """
        session = await self._get_session()

        try:
            logger.debug(f"{method} {url}")
            async with session.request(
                method,
                url,
                params=params,
                headers=headers,
                json=json,
            ) as response:
                # Read response body before returning to ensure it's available
                text = await response.text()

                # Create a wrapper object with the data we need
                class ResponseWrapper:
                    def __init__(self, status: int, text_data: str, json_data: Any = None):
                        self.status_code = status
                        self.text = text_data
                        self._json_data = json_data

                    def json(self) -> Dict[str, Any]:
                        if self._json_data is not None:
                            return self._json_data
                        import json as json_module
                        return json_module.loads(self.text)

                # Try to parse JSON
                json_data = None
                try:
                    import json as json_module
                    json_data = json_module.loads(text)
                except Exception:
                    pass

                return ResponseWrapper(response.status, text, json_data)

        except asyncio.TimeoutError as e:
            logger.error(f"Request timeout: {e}")
            raise D365ApiError(
                "Request timed out",
                status_code=504,
                method=method,
                url=url,
            )
        except Exception as e:
            logger.error(f"Request failed: {e}")
            raise D365ApiError(
                f"Request failed: {str(e)}",
                method=method,
                url=url,
            )

    async def get_page(
        self,
        page: int = 1,
        select: Optional[str] = None,
        request_filter: Optional[str] = None,
        order_by: Optional[str] = None,
        annotations: Optional[str] = None,
        query_dict: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Get a page of entities.

        Args:
            page: Page number (1-indexed)
            select: Comma-separated columns to select
            request_filter: OData filter expression
            order_by: OData orderby expression
            annotations: Annotation preference
            query_dict: Additional query parameters

        Returns:
            API response with entities
        """
        query = QueryBuilder(self.config.page_size)
        if select:
            query.select(select.split(','))
        if request_filter:
            query.filter(request_filter)
        if order_by:
            query.order_by(order_by)
        if annotations:
            query.annotations(annotations)

        params, extra_headers = query.build_for_list(page, self.config.api_url_prefix)
        if query_dict:
            params.update(query_dict)

        headers = self.headers.copy()
        headers.update(extra_headers)
        headers['Prefer'] = f'odata.maxpagesize={self.config.page_size}'

        response = await self._request('GET', self.api_url, params=params, headers=headers)
        self.current_page = page

        return ResponseValidator.validate_get_response(response, self.api_url)

    async def get_next_page(self) -> Dict[str, Any]:
        """
        Get next page of results.

        Returns:
            API response with entities

        Raises:
            D365ApiWrapperError: If no current page is set
        """
        if not self.current_page:
            raise D365ApiWrapperError('Call get_page() first to set current page.')
        return await self.get_page(page=self.current_page + 1)

    async def get_previous_page(self) -> Dict[str, Any]:
        """
        Get previous page of results.

        Returns:
            API response with entities

        Raises:
            D365ApiWrapperError: If already at first page
        """
        if not self.current_page or self.current_page == 1:
            raise D365ApiWrapperError('No previous page. Already at the first page.')
        return await self.get_page(page=self.current_page - 1)

    async def get_top(
        self,
        qty: int,
        select: Optional[str] = None,
        request_filter: Optional[str] = None,
        order_by: Optional[str] = None,
        annotations: Optional[str] = None,
        query_dict: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Get top N entities.

        Args:
            qty: Number of entities to retrieve
            select: Comma-separated columns to select
            request_filter: OData filter expression
            order_by: OData orderby expression
            annotations: Annotation preference
            query_dict: Additional query parameters

        Returns:
            API response with entities
        """
        query = QueryBuilder(self.config.page_size)
        if select:
            query.select(select.split(','))
        if request_filter:
            query.filter(request_filter)
        if order_by:
            query.order_by(order_by)
        if annotations:
            query.annotations(annotations)

        params, extra_headers = query.build_for_top(qty)
        if query_dict:
            params.update(query_dict)

        headers = self.headers.copy()
        headers.update(extra_headers)

        response = await self._request('GET', self.api_url, params=params, headers=headers)
        return ResponseValidator.validate_get_response(response, self.api_url)

    async def create(
        self,
        data: Dict[str, Any],
        annotations: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create a new entity.

        Args:
            data: Entity data
            annotations: Annotation preference

        Returns:
            Created entity data
        """
        headers = self.headers.copy()
        headers['Prefer'] = 'return=representation'

        if annotations:
            headers['Prefer'] += f', odata.include-annotations="{annotations}"'

        response = await self._request('POST', self.api_url, headers=headers, json=data)
        return ResponseValidator.validate_mutation_response(response, self.api_url, 'POST')

    async def retrieve(
        self,
        entity_id: str,
        select: Optional[str] = None,
        annotations: Optional[str] = None,
        query_dict: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Retrieve a single entity by ID.

        Args:
            entity_id: Entity ID
            select: Comma-separated columns to select
            annotations: Annotation preference
            query_dict: Additional query parameters

        Returns:
            Entity data
        """
        query = QueryBuilder(self.config.page_size)
        if select:
            query.select(select.split(','))
        if annotations:
            query.annotations(annotations)

        params, extra_headers = query.build_for_retrieve(query_dict)
        headers = self.headers.copy()
        headers.update(extra_headers)

        url = f'{self.api_url}({entity_id})'
        response = await self._request('GET', url, params=params, headers=headers)
        return ResponseValidator.validate_get_response(response, url)

    async def update(
        self,
        entity_id: str,
        data: Dict[str, Any],
        select: Optional[str] = None,
        annotations: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Update an entity.

        Args:
            entity_id: Entity ID
            data: Updated entity data
            select: Comma-separated columns to select in response
            annotations: Annotation preference

        Returns:
            Updated entity data
        """
        query = QueryBuilder(self.config.page_size)
        if select:
            query.select(select.split(','))
        if annotations:
            query.annotations(annotations)

        params, extra_headers = query.build_for_retrieve()
        headers = self.headers.copy()
        headers.update(extra_headers)
        headers['Prefer'] = 'return=representation'
        if annotations:
            headers['Prefer'] += f', odata.include-annotations="{annotations}"'

        url = f'{self.api_url}({entity_id})'
        response = await self._request('PATCH', url, params=params, headers=headers, json=data)
        return ResponseValidator.validate_mutation_response(response, url, 'PATCH')

    async def delete(self, entity_id: str) -> int:
        """
        Delete an entity.

        Args:
            entity_id: Entity ID

        Returns:
            HTTP status code
        """
        url = f'{self.api_url}({entity_id})'
        response = await self._request('DELETE', url, headers=self.headers)
        return ResponseValidator.validate_mutation_response(response, url, 'DELETE')
