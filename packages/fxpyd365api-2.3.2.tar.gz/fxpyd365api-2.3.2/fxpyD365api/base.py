"""
Base wrapper mixin providing shared D365 API functionality.

Handles authentication, token management, and common request headers.
"""

import datetime
import logging
from typing import Any, Dict, Optional

import msal
import pytz

from .config import Config
from .exceptions import D365ApiError

logger = logging.getLogger(__name__)


class BaseApiWrapperMixin:
    """
    Mixin that provides shared logic for both sync and async API wrappers.

    Handles authentication, token caching, header management, and configuration.
    """

    entity_type: Optional[str] = None

    _BASE_HEADERS = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }

    def __init__(
        self,
        entity_type: Optional[str] = None,
        org_url: Optional[str] = None,
        tenant: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        token: Optional[Dict[str, Any]] = None,
        extra_headers: Optional[Dict[str, str]] = None,
        config: Optional[Config] = None,
        **kwargs: Any,
    ):
        """
        Initialize the API wrapper.

        Args:
            entity_type: D365 entity type (e.g., 'accounts', 'contacts')
            org_url: D365 organization URL
            tenant: Azure AD tenant ID
            client_id: OAuth client ID
            client_secret: OAuth client secret
            token: Pre-obtained OAuth token dict
            extra_headers: Additional HTTP headers
            config: Config object (takes precedence over individual parameters)
            **kwargs: Additional config parameters:
                - api_url_prefix: API URL prefix (default: '/api/data/v9.0' for CE, '/data' for FO)
                - timeout: Request timeout in seconds (default: 20)
                - page_size: Default page size (default: 100)
                - token_refresh_buffer: Token refresh buffer in minutes (default: 5)
                - impersonate: User ID to impersonate
        """
        if entity_type:
            self.entity_type = entity_type

        # Build config from parameters or use provided config
        if config:
            self.config = config
        else:
            self.config = Config(
                org_url=org_url,
                tenant=tenant,
                client_id=client_id,
                client_secret=client_secret,
                api_url_prefix=kwargs.get('api_url_prefix', '/api/data/v9.0'),
                timeout=kwargs.get('timeout', 20),
                page_size=kwargs.get('page_size', 100),
                token_refresh_buffer=kwargs.get('token_refresh_buffer', 5),
                impersonate_user=kwargs.get('impersonate', None),
            )

        self.extra_headers = extra_headers or {}
        self._token = token
        self.token_expires_at: Optional[datetime.datetime] = None
        self.current_page: Optional[int] = None

        # Initialize token if not provided
        if token:
            try:
                self.token_expires_at = datetime.datetime.fromisoformat(token['expires_on'])
            except (KeyError, ValueError):
                self._refresh_token()
        else:
            self._refresh_token()

    def _refresh_token(self) -> None:
        """Refresh the OAuth token."""
        logger.debug("Refreshing D365 OAuth token")

        app = msal.ConfidentialClientApplication(
            authority=f'https://login.microsoftonline.com/{self.config.tenant}',
            client_id=self.config.client_id,
            client_credential=self.config.client_secret,
        )

        scope = f'{self.config.org_url}/.default'
        token_response = app.acquire_token_for_client(scopes=[scope])

        if 'access_token' not in token_response:
            raise D365ApiError(
                "Failed to acquire authentication token",
                details={
                    "error": token_response.get('error'),
                    "error_description": token_response.get('error_description'),
                },
            )

        self._token = token_response
        expires_in = token_response.get('expires_in', 3600)
        self.token_expires_at = datetime.datetime.now(pytz.utc) + datetime.timedelta(seconds=expires_in)
        logger.debug(f"Token refreshed, expires at {self.token_expires_at}")

    @property
    def token(self) -> str:
        """
        Get the current access token, refreshing if necessary.

        Returns:
            Access token string
        """
        if self._token is None or self.token_expires_at is None:
            self._refresh_token()

        # Refresh if within buffer time
        buffer_time = datetime.timedelta(minutes=self.config.token_refresh_buffer)
        if datetime.datetime.now(pytz.utc) + buffer_time > self.token_expires_at:
            logger.debug("Token approaching expiry, refreshing")
            self._refresh_token()

        return self._token['access_token']

    @property
    def headers(self) -> Dict[str, str]:
        """
        Get request headers with authentication and impersonation.

        Returns:
            Dictionary of headers
        """
        headers = self._BASE_HEADERS.copy()
        headers['Authorization'] = f'Bearer {self.token}'

        if self.config.impersonate_user:
            headers['MSCRMCallerID'] = self.config.impersonate_user

        headers.update(self.extra_headers)
        return headers

    @property
    def api_url(self) -> str:
        """
        Get the full API URL for the current entity.

        Returns:
            Full API URL

        Raises:
            ValueError: If entity_type is not set
        """
        if not self.entity_type:
            raise ValueError('entity_type must be set before making requests')

        return f"{self.config.full_api_url_prefix}/{self.entity_type}"
