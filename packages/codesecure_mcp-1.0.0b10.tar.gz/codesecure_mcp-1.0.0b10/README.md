# CodeSecure MCP Server (`codesecure-mcp`)

The `codesecure-mcp` package bridges the programmatic `codesecure-core` engine to standard IDE environments (e.g., VS Code, Claude Desktop, Cursor) through the **Model Context Protocol (MCP)**.

## 🎯 Module Purpose

As a core implementation of the FastMCP specification, this module operates purely via JSON-RPC over the `stdio` transport. It allows external applications to seamlessly call CodeSecure tools dynamically (e.g., initiating scans, polling jobs, or retrieving findings) without installing custom integrations or importing the underlying Python SDK directly.

## 📦 Local Installation

Just like the CLI, the MCP Server is a "Thin Wrapper" around `codesecure-core` but exposes endpoints suitable for FastMCP protocol buffers.

```bash
cd packages/mcp-server

# Standard installation inside a venv mapping back to workspace core.
cd ../../
pip install -e ./packages/mcp-server
```

## 🔌 Exported API & Tool Capabilities

Because this is an MCP server, functions are exported as `@server.tool()` attributes that clients can invoke dynamically.

| MCP Tool Name | Description | Status Mapping |
| --- | --- | --- |
| `run_scan_local` | Spawns an async job via `JobManager` against local directories | Returns `job_id` |
| `get_scan_status` | Returns a progress tracker % bounded to `JobManager` | Polling endpoint |
| `get_scan_result` | Unpacks JSON finding models from the finished scanner queue | Returns raw Findings list |
| `list_scanners` | Fetches active core scanner mappings | Core `BaseScanner` interface wrap |

## 🛠️ Integration Example

Here is how you would configure an external IDE (like Claude Desktop) to initialize the CodeSecure MCP server and natively surface the AI findings:

### Example: `claude_desktop_config.json`

```json
{
  "mcpServers": {
    "codesecure": {
      "command": "python",
      "args": [
        "-m",
        "codesecure_mcp.scanner.server"
      ],
      "env": {
        "CODESECURE_PROVIDER": "google",
        "PYTHONPATH": "/absolute/path/to/codesecure/packages/core/src;/absolute/path/to/codesecure/packages/mcp-server/src"
      }
    }
  }
}
```

*Invoking the server allows Claude Desktop to intrinsically understand when a path is vulnerable, or auto-fetch finding data to assist prompt responses natively.*
