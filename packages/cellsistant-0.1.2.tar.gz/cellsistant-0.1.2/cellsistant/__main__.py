"""
Main entry point for cellsistant Jupyter server extension.
"""

from cellsistant import _load_jupyter_server_extension


# Alias for Jupyter Server extension loader
load_jupyter_server_extension = _load_jupyter_server_extension
