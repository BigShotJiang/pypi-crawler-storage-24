"""
Tool definitions for AI Agent.

This module contains all tool definitions in OpenAI function calling format.
"""

TOOL_CATEGORIES = {
    "create_cell": "notebook",
    "execute_cell": "notebook",
    "get_cell_output": "notebook",
    "update_cell": "notebook",
    "delete_cell": "notebook",
    "get_cell_content": "notebook",
    "get_notebook_content": "notebook",
    "find_in_notebook": "notebook",
    "replace_in_cell": "notebook",
    "analyze_image": "notebook",
    "read_file": "files",
    "write_file": "files",
    "list_directory": "files",
    "create_notebook": "files",
    "delete_file": "files",
    "rename_file": "files",
    "run_shell": "shell",
    "install_package": "packages",
    "list_packages": "packages",
}

TOOL_SAFETY_LEVELS = {
    "create_cell": "write",
    "execute_cell": "execute",
    "get_cell_output": "read",
    "update_cell": "write",
    "delete_cell": "system",
    "get_cell_content": "read",
    "get_notebook_content": "read",
    "find_in_notebook": "read",
    "replace_in_cell": "write",
    "analyze_image": "read",
    "read_file": "read",
    "write_file": "write",
    "list_directory": "read",
    "create_notebook": "write",
    "delete_file": "system",
    "rename_file": "write",
    "run_shell": "system",
    "install_package": "system",
    "list_packages": "read",
    "remember": "write",
    "recall": "read",
    "forget": "write",
    "list_memories": "read",
}


def get_tool_category(tool_name: str) -> str:
    """Get category for a tool."""
    return TOOL_CATEGORIES.get(tool_name, "unknown")


def get_tool_safety_level(tool_name: str) -> str:
    """Get safety level for a tool."""
    return TOOL_SAFETY_LEVELS.get(tool_name, "read")


def get_enabled_tool_definitions(
    enabled_categories: dict | None = None,
    read_only: bool = False,
    image_analysis_enabled: bool = True,
) -> list:
    """
    Get tool definitions filtered by enabled categories and read-only mode.

    Args:
        enabled_categories: Dict of category -> enabled (bool). If None, all enabled.
        read_only: If True, only return read-only tools (safety_level = 'read')
        image_analysis_enabled: If False, exclude analyze_image tool

    Returns:
        List of tool definitions for OpenAI function calling format
    """
    if enabled_categories is None:
        enabled_categories = {
            "notebook": True,
            "files": True,
            "shell": True,
            "packages": True,
            "search": True,
        }

    filtered = []
    for tool_def in TOOL_DEFINITIONS:
        tool_name = tool_def["function"]["name"]

        if tool_name == "analyze_image" and not image_analysis_enabled:
            continue

        category = get_tool_category(tool_name)
        safety_level = get_tool_safety_level(tool_name)

        if read_only and safety_level != "read":
            continue

        if category != "unknown" and not enabled_categories.get(category, True):
            continue

        filtered.append(tool_def)

    return filtered


TOOL_DEFINITIONS = [
    {
        "type": "function",
        "function": {
            "name": "create_cell",
            "description": "Create a new cell in the active Jupyter notebook. Use this to write code or markdown.",
            "parameters": {
                "type": "object",
                "properties": {
                    "cell_type": {
                        "type": "string",
                        "enum": ["code", "markdown"],
                        "description": "Type of cell to create",
                    },
                    "source": {
                        "type": "string",
                        "description": "Content/source code of the cell",
                    },
                },
                "required": ["cell_type", "source"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "execute_cell",
            "description": "Execute a code cell by its index. The cell must be a code cell. After execution, use get_cell_output to see the result.",
            "parameters": {
                "type": "object",
                "properties": {
                    "index": {
                        "type": "integer",
                        "description": "Cell number (0-based, first cell is 0)",
                    }
                },
                "required": ["index"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_cell_output",
            "description": "Get the output/result of an executed code cell. Returns text, errors, images (base64 by default), and HTML (DataFrames). Images included by default.",
            "parameters": {
                "type": "object",
                "properties": {
                    "index": {"type": "integer", "description": "Cell number (0-based, first cell is 0)"},
                    "include_images": {
                        "type": "boolean",
                        "description": "Include base64 image data (default: true). Set false to save tokens.",
                    },
                },
                "required": ["index"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "analyze_image",
            "description": "Analyze an image from a cell output using AI vision. Returns detailed insights about the visualization. Use when user asks to analyze, explain, or describe an image in the cell output.",
            "parameters": {
                "type": "object",
                "properties": {
                    "cell_index": {
                        "type": "integer",
                        "description": "Index of the cell containing the image to analyze (0-based)",
                    },
                    "context": {
                        "type": "string",
                        "description": "Optional context or specific question about the image (e.g., 'What patterns do you see?', 'Is there a trend?')",
                    },
                },
                "required": ["cell_index"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "update_cell",
            "description": "Update/replace the content of an existing cell",
            "parameters": {
                "type": "object",
                "properties": {
                    "index": {
                        "type": "integer",
                        "description": "Cell number (0-based, first cell is 0)",
                    },
                    "source": {
                        "type": "string",
                        "description": "New content for the cell",
                    },
                },
                "required": ["index", "source"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "delete_cell",
            "description": "Delete a cell from the notebook",
            "parameters": {
                "type": "object",
                "properties": {
                    "index": {
                        "type": "integer",
                        "description": "Cell number (0-based, first cell is 0)",
                    }
                },
                "required": ["index"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_cell_content",
            "description": "Get the source content of a specific cell",
            "parameters": {
                "type": "object",
                "properties": {
                    "index": {"type": "integer", "description": "Cell number (0-based, first cell is 0)"}
                },
                "required": ["index"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_notebook_content",
            "description": "Get all cells in the active notebook with their types and content. Use this to understand the current state of the notebook.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "find_in_notebook",
            "description": "Search for text or pattern across all cells in the active notebook. Returns cell indices, line numbers, and matching lines. Useful for finding where a variable, function, or pattern is used.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Text to search for, or a regex pattern if regex=true",
                    },
                    "case_sensitive": {
                        "type": "boolean",
                        "description": "Whether search is case-sensitive (default: false)",
                    },
                    "regex": {
                        "type": "boolean",
                        "description": "Treat query as a regular expression (default: false)",
                    },
                    "cell_type": {
                        "type": "string",
                        "enum": ["code", "markdown"],
                        "description": "Search only in cells of this type (default: all)",
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "replace_in_cell",
            "description": "Replace text in a specific cell without rewriting the entire cell. Supports literal text and regex replacements. Useful for renaming variables, fixing typos, or modifying specific parts of code.",
            "parameters": {
                "type": "object",
                "properties": {
                    "index": {"type": "integer", "description": "Cell number (0-based, first cell is 0)"},
                    "search": {
                        "type": "string",
                        "description": "Text to find (literal or regex if regex=true)",
                    },
                    "replace": {
                        "type": "string",
                        "description": "Replacement text. For regex, supports $1, $2 backreferences.",
                    },
                    "case_sensitive": {
                        "type": "boolean",
                        "description": "Case-sensitive search (default: false)",
                    },
                    "regex": {
                        "type": "boolean",
                        "description": "Use regex for search (default: false)",
                    },
                    "replace_all": {
                        "type": "boolean",
                        "description": "Replace all occurrences or only first (default: true = all)",
                    },
                },
                "required": ["index", "search", "replace"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read the contents of a text file. Supports .py, .js, .json, .csv, .md, .txt, .yaml, etc. Max 500KB.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to file relative to Jupyter working directory",
                    },
                    "max_lines": {
                        "type": "integer",
                        "description": "Maximum number of lines to return (default: all)",
                    },
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Create or overwrite a text file. Parent directories are created automatically.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path for the file"},
                    "content": {"type": "string", "description": "Content to write"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_directory",
            "description": "List files and subdirectories in a directory.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Directory path (empty string for root)",
                        "default": "",
                    }
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_notebook",
            "description": "Create a new empty Jupyter notebook",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Notebook name (with or without .ipynb)",
                    },
                    "path": {
                        "type": "string",
                        "description": "Directory (default: root)",
                        "default": "",
                    },
                },
                "required": ["name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "delete_file",
            "description": "Delete a file or empty directory. Cannot be undone.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to delete"}
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "rename_file",
            "description": "Rename or move a file/directory",
            "parameters": {
                "type": "object",
                "properties": {
                    "old_path": {"type": "string", "description": "Current path"},
                    "new_path": {"type": "string", "description": "New path"},
                },
                "required": ["old_path", "new_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_shell",
            "description": "Execute a shell command on the server. 60s timeout. Dangerous commands (rm -rf /, shutdown, etc.) are blocked.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "Shell command to execute",
                    },
                    "timeout": {
                        "type": "integer",
                        "description": "Timeout in seconds (default: 60)",
                    },
                },
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "install_package",
            "description": "Install a Python package using pip or conda. Use when code fails with ModuleNotFoundError or ImportError.",
            "parameters": {
                "type": "object",
                "properties": {
                    "package_name": {
                        "type": "string",
                        "description": "Package name, optionally with version: 'pandas', 'numpy>=1.24'",
                    },
                    "manager": {
                        "type": "string",
                        "enum": ["pip", "conda"],
                        "description": "Package manager (default: pip)",
                    },
                    "extra_args": {
                        "type": "string",
                        "description": "Extra args like '--upgrade'",
                    },
                },
                "required": ["package_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_packages",
            "description": "List installed Python packages",
            "parameters": {
                "type": "object",
                "properties": {
                    "filter": {
                        "type": "string",
                        "description": "Filter by name substring",
                    }
                },
            },
        },
    },
]
