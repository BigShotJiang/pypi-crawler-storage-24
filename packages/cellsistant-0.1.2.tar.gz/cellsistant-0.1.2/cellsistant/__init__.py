"""
JupyterLab AI Agent Server Extension

Server-side extension for AI Agent chat functionality.
Supports tool calling for JupyterLab operations.
"""

import json
import os
import resource
import subprocess
import time

import tornado.web
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join

from cellsistant.history import (
    HistoryExportHandler,
    HistoryItemHandler,
    HistoryListHandler,
    HistorySaveHandler,
)
from cellsistant.rate_limiter import chat_limiter, shell_limiter
from cellsistant.retry import (
    OpenRouterError,
    RetryConfig,
    call_openrouter_with_retry,
)
from cellsistant.settings import (
    SettingsGetHandler,
    SettingsTestHandler,
    SettingsUpdateHandler,
    get_active_profile,
    get_profile_by_id,
)


# ═══════════════════════════════════════════════════════
# Shell commands: security constants
# ═══════════════════════════════════════════════════════

# Commands that are BLOCKED (even in normal mode)
BLOCKED_COMMANDS = {
    # Destructive commands
    "rm -rf /",
    "rm -rf ~",
    "rm -rf /*",
    "mkfs",
    "dd if=",
    ":(){",
    "fork bomb",
    # System commands
    "shutdown",
    "reboot",
    "halt",
    "poweroff",
    "init 0",
    # Permissions
    "chmod -R 777 /",
    "chown -R",
    # Network (reverse shells)
    "nc -l",
    "ncat",
    "socat",
    # Crypto mining
    "xmrig",
    "minerd",
    "cpuminer",
}

MAX_EXECUTION_TIME = 60  # seconds
MAX_OUTPUT_SIZE = 100 * 1024  # 100KB

# Resource limits for child processes
RESOURCE_LIMITS = {
    "max_memory_mb": 512,
    "max_file_size_mb": 100,
    "max_processes": 50,
}


def set_resource_limits():
    """Set resource limits for child process (Unix only)."""
    try:
        max_mem = RESOURCE_LIMITS["max_memory_mb"] * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_AS, (max_mem, max_mem))

        max_file = RESOURCE_LIMITS["max_file_size_mb"] * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_FSIZE, (max_file, max_file))

        max_procs = RESOURCE_LIMITS["max_processes"]
        resource.setrlimit(resource.RLIMIT_NPROC, (max_procs, max_procs))
    except (ValueError, OSError, AttributeError):
        pass


class ShellHandler(APIHandler):
    """Handler for executing shell commands with timeout and output limits."""

    def check_xsrf_cookie(self):
        """Disable XSRF check for API requests."""
        pass

    @tornado.web.authenticated
    async def post(self):
        try:
            # Rate limiting (stricter for shell)
            allowed, error_msg = shell_limiter.check()
            if not allowed:
                self.set_status(429)
                self.finish({"error": error_msg, "retry_after": 60})
                return

            shell_limiter.record()

            # Get request data
            data = self.get_json_body()
            command = data.get("command", "")
            timeout = min(data.get("timeout", MAX_EXECUTION_TIME), MAX_EXECUTION_TIME)
            working_dir = data.get("working_dir", None)

            if not command:
                self.set_status(400)
                self.finish({"error": "Command is required"})
                return

            # Check for dangerous commands
            command_lower = command.lower().strip()
            for blocked in BLOCKED_COMMANDS:
                if blocked in command_lower:
                    self.set_status(403)
                    self.finish(
                        {"error": f"Command blocked for safety: contains '{blocked}'"}
                    )
                    return

            # Determine working directory
            cwd = working_dir or os.getcwd()

            # Execute command asynchronously
            start_time = time.time()

            try:
                process = await tornado.ioloop.IOLoop.current().run_in_executor(
                    None,
                    lambda: subprocess.run(
                        command,
                        shell=True,
                        capture_output=True,
                        text=True,
                        timeout=timeout,
                        cwd=cwd,
                        preexec_fn=set_resource_limits,
                        env={
                            **os.environ,
                            "PYTHONIOENCODING": "utf-8",
                            "DEBIAN_FRONTEND": "noninteractive",
                        },
                    ),
                )

                elapsed = time.time() - start_time

                stdout = process.stdout or ""
                stderr = process.stderr or ""

                # Limit output size
                stdout_truncated = False
                stderr_truncated = False

                if len(stdout) > MAX_OUTPUT_SIZE:
                    stdout = stdout[:MAX_OUTPUT_SIZE]
                    stdout_truncated = True

                if len(stderr) > MAX_OUTPUT_SIZE:
                    stderr = stderr[:MAX_OUTPUT_SIZE]
                    stderr_truncated = True

                self.finish(
                    {
                        "success": process.returncode == 0,
                        "return_code": process.returncode,
                        "stdout": stdout,
                        "stderr": stderr,
                        "stdout_truncated": stdout_truncated,
                        "stderr_truncated": stderr_truncated,
                        "elapsed_seconds": round(elapsed, 2),
                    }
                )

            except subprocess.TimeoutExpired:
                self.finish(
                    {
                        "success": False,
                        "return_code": -1,
                        "stdout": "",
                        "stderr": f"Command timed out after {timeout} seconds",
                        "elapsed_seconds": timeout,
                    }
                )

        except Exception as e:
            self.set_status(500)
            self.finish({"error": f"Shell execution error: {e!s}"})


class ImageAnalysisHandler(APIHandler):
    """
    Handler for analyzing cell output images using LLM with vision capabilities.
    """

    def check_xsrf_cookie(self):
        pass

    @tornado.web.authenticated
    async def post(self):
        try:
            import aiohttp

            data = self.get_json_body()
            image_data = data.get("image_data", "")
            mime_type = data.get("mime_type", "image/png")
            cell_index = data.get("cell_index", None)
            additional_context = data.get("context", "")

            if not image_data:
                self.set_status(400)
                self.finish({"error": "image_data is required"})
                return

            from cellsistant.settings import load_settings

            settings = load_settings()

            # Get image analysis settings
            img_settings = settings.get("image_analysis", {})
            use_active_profile = img_settings.get("use_active_profile", True)

            if use_active_profile:
                profile = get_active_profile(settings)
            else:
                profile_id = img_settings.get("profile_id")
                if profile_id:
                    profile = get_profile_by_id(settings, profile_id)
                else:
                    profile = get_active_profile(settings)

            img_base_url = profile.get("base_url", "https://openrouter.ai/api/v1").rstrip("/")
            img_api_key = profile.get("api_key", "")
            model = profile.get("model", "openrouter/healer-alpha")

            custom_prompt = img_settings.get("custom_prompt", "")

            if not img_api_key:
                self.set_status(400)
                self.finish({"error": "API key not configured"})
                return

            headers = {
                "Authorization": f"Bearer {img_api_key}",
                "Content-Type": "application/json",
            }

            cell_info = f"Cell index: {cell_index}" if cell_index is not None else ""
            system_prompt = """You are an expert at analyzing Jupyter notebook cell outputs (images, plots, charts, graphs).
Analyze the provided image thoroughly and provide insights about:
1. What type of visualization/data is shown
2. Key patterns, trends, or findings visible
3. Any notable observations or anomalies
4. Technical details about the visualization (if applicable)

Be concise but informative. Format your response in a clear, structured way."""

            if custom_prompt:
                system_prompt += f"\n\nCustom instructions:\n{custom_prompt}"
            if additional_context:
                system_prompt += f"\n\nAdditional context:\n{additional_context}"
            if cell_info:
                system_prompt += f"\n\n{cell_info}"

            user_content = [
                {"type": "text", "text": "Describe this image in detail."},
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:{mime_type};base64,{image_data}"
                    }
                }
            ]

            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_content}
                ],
                "max_tokens": 2000,
                "temperature": 0.3,
            }

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{img_base_url}/chat/completions",
                    json=payload,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=60)
                ) as resp:
                    if resp.status != 200:
                        error_body = await resp.text()
                        self.set_status(resp.status)
                        self.finish({"error": f"API error: {error_body}"})
                        return

                    result = await resp.json()
                    analysis = result.get("choices", [{}])[0].get("message", {}).get("content", "")

                    self.finish({
                        "success": True,
                        "analysis": analysis,
                        "model_used": model,
                    })

        except aiohttp.ClientError as e:
            self.set_status(500)
            self.finish({"error": f"Connection error: {e!s}"})
        except Exception as e:
            self.set_status(500)
            self.finish({"error": f"Analysis error: {e!s}"})


class ChatStreamHandler(APIHandler):
    """SSE handler: proxies streaming from OpenAI-compatible API to browser."""

    def check_xsrf_cookie(self):
        """Disable XSRF check for API requests."""
        pass

    @tornado.web.authenticated
    async def post(self):
        try:
            data = self.get_json_body()
            messages = data.get("messages", [])

            if not messages:
                self.set_status(400)
                self.finish(json.dumps({"error": "Messages array is required"}))
                return

            # Load from settings.json
            from cellsistant.settings import load_settings

            settings = load_settings()

            # Get active profile
            profile = get_active_profile(settings)

            base_url = profile.get("base_url", "https://openrouter.ai/api/v1").rstrip("/")
            api_key = profile.get("api_key", "")
            model = profile.get("model", "google/gemini-2.0-flash:free")
            temperature = profile.get("temperature", 0.3)
            max_tokens = profile.get("max_tokens", 0)

            # Custom system prompt + Ask mode
            custom_prompt = settings.get("custom_system_prompt", "")
            ask_mode = data.get("ask_mode", False)
            image_analysis_enabled = data.get("image_analysis_enabled", True)

            enabled_categories = settings.get("enabled_tool_categories", {
                "notebook": True,
                "files": True,
                "shell": True,
                "packages": True,
                "search": True,
            })

            from cellsistant.prompts import (
                build_ask_system_prompt,
                build_system_prompt,
            )
            if ask_mode:
                system = build_ask_system_prompt(
                    custom_prompt, enabled_categories
                )
            else:
                system = build_system_prompt(
                    custom_prompt, enabled_categories, image_analysis_enabled
                )

            all_messages = [system] + messages

            from cellsistant.tools_definitions import (
                get_enabled_tool_definitions,
            )
            tools = get_enabled_tool_definitions(
                enabled_categories,
                read_only=ask_mode,
                image_analysis_enabled=image_analysis_enabled
            )

            # Configure SSE headers
            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")
            self.set_header("X-Accel-Buffering", "no")

            payload = {
                "model": model,
                "messages": all_messages,
                "tools": tools,
                "tool_choice": "auto",
                "stream": True,
                "temperature": temperature,
            }

            if max_tokens > 0:
                payload["max_tokens"] = max_tokens

            # Use aiohttp for async streaming
            import aiohttp

            headers = {
                "Content-Type": "application/json",
            }
            if api_key:
                headers["Authorization"] = f"Bearer {api_key}"

            url = f"{base_url}/chat/completions"

            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, headers=headers) as resp:
                    if resp.status != 200:
                        error_body = await resp.text()
                        # Send error as SSE event
                        self.write(
                            f"event: error\ndata: {json.dumps({'error': error_body})}\n\n"
                        )
                        await self.flush()
                        self.finish()
                        return

                    # Read stream line by line
                    async for line in resp.content:
                        line = line.decode("utf-8").strip()

                        if not line:
                            continue

                        if line.startswith("data: "):
                            data_str = line[6:]

                            if data_str == "[DONE]":
                                self.write("event: done\ndata: [DONE]\n\n")
                                await self.flush()
                                break

                            # Forward chunk to client as-is
                            self.write(f"data: {data_str}\n\n")
                            await self.flush()

                    self.finish()

        except Exception as e:
            # If stream already started, send error via SSE
            try:
                self.write(f"event: error\ndata: {json.dumps({'error': str(e)})}\n\n")
                await self.flush()
            except Exception:
                pass
            self.finish()


class ChatHandler(APIHandler):
    """Simple handler: accepts messages array, proxies to OpenAI-compatible API."""

    def check_xsrf_cookie(self):
        """Disable XSRF check for API requests."""
        pass

    @tornado.web.authenticated
    async def post(self):
        """Handle chat message."""
        try:
            # Rate limiting
            allowed, error_msg = chat_limiter.check()
            if not allowed:
                self.set_status(429)
                self.finish({"error": error_msg, "retry_after": 60})
                return

            chat_limiter.record()

            data = self.get_json_body()
            messages = data.get("messages", [])

            if not messages:
                self.set_status(400)
                self.finish({"error": "Messages array is required"})
                return

            # Load from settings.json
            from cellsistant.settings import load_settings

            settings = load_settings()

            # Get active profile
            profile = get_active_profile(settings)

            base_url = profile.get("base_url", "https://openrouter.ai/api/v1").rstrip("/")
            api_key = profile.get("api_key", "")
            model = profile.get("model", "google/gemini-2.0-flash:free")
            temperature = profile.get("temperature", 0.3)
            max_tokens = profile.get("max_tokens", 0)

            url = f"{base_url}/chat/completions"

            # Custom system prompt + Ask mode
            custom_prompt = settings.get("custom_system_prompt", "")
            ask_mode = data.get("ask_mode", False)
            image_analysis_enabled = data.get("image_analysis_enabled", True)

            enabled_categories = settings.get("enabled_tool_categories", {
                "notebook": True,
                "files": True,
                "shell": True,
                "packages": True,
                "search": True,
            })

            from cellsistant.prompts import (
                build_ask_system_prompt,
                build_system_prompt,
            )
            if ask_mode:
                system = build_ask_system_prompt(
                    custom_prompt, enabled_categories
                )
            else:
                system = build_system_prompt(
                    custom_prompt, enabled_categories, image_analysis_enabled
                )

            all_messages = [system] + messages

            from cellsistant.tools_definitions import (
                get_enabled_tool_definitions,
            )
            tools = get_enabled_tool_definitions(
                enabled_categories,
                read_only=ask_mode,
                image_analysis_enabled=image_analysis_enabled
            )

            headers = {
                "Content-Type": "application/json",
            }
            if api_key:
                headers["Authorization"] = f"Bearer {api_key}"

            payload = {
                "model": model,
                "messages": all_messages,
                "tools": tools,
                "tool_choice": "auto",
                "temperature": temperature,
            }

            if max_tokens > 0:
                payload["max_tokens"] = max_tokens

            # Call with retry
            result = await call_openrouter_with_retry(
                url=url,
                headers=headers,
                payload=payload,
                config=RetryConfig(max_retries=3, base_delay=1.0),
            )

            # Extract response
            if "choices" in result and len(result["choices"]) > 0:
                message = result["choices"][0].get("message", {})

                # Return full message - frontend will handle it
                self.finish({"message": message})
            else:
                self.set_status(500)
                self.finish({"error": "No response from AI", "raw": result})

        except OpenRouterError as e:
            self.set_status(e.status or 500)
            self.finish(
                {
                    "error": e.message,
                    "retryable": e.retryable,
                }
            )
        except json.JSONDecodeError:
            self.set_status(400)
            self.finish({"error": "Invalid JSON"})
        except Exception as e:
            self.set_status(500)
            self.finish({"error": f"Internal error: {e!s}"})


def setup_webserver(web_app):
    """Configure web server for extension."""
    host_pattern = ".*$"
    base_url = web_app.settings["base_url"]

    # Existing endpoint (kept for backwards compatibility)
    route_chat = url_path_join(base_url, "ai-agent", "chat")
    # New streaming endpoint
    route_stream = url_path_join(base_url, "ai-agent", "chat", "stream")
    # Shell endpoint
    route_shell = url_path_join(base_url, "ai-agent", "shell")
    # History endpoints
    # Note: export route must be before item route due to more specific pattern
    route_history_list = url_path_join(base_url, "ai-agent", "history")
    route_history_save = url_path_join(base_url, "ai-agent", "history", "save")
    route_history_export = url_path_join(
        base_url, "ai-agent", "history", "(.*)", "export"
    )
    route_history_item = url_path_join(base_url, "ai-agent", "history", "(.*)")

    # Settings endpoints
    route_settings_get = url_path_join(base_url, "ai-agent", "settings")
    route_settings_update = url_path_join(base_url, "ai-agent", "settings", "update")
    route_settings_test = url_path_join(base_url, "ai-agent", "settings", "test")

    # Image analysis endpoint
    route_analyze_image = url_path_join(base_url, "ai-agent", "analyze-image")

    web_app.add_handlers(
        host_pattern,
        [
            (route_chat, ChatHandler),
            (route_stream, ChatStreamHandler),
            (route_shell, ShellHandler),
            (route_history_list, HistoryListHandler),
            (route_history_save, HistorySaveHandler),
            (route_history_export, HistoryExportHandler),
            (route_history_item, HistoryItemHandler),
            (route_settings_get, SettingsGetHandler),
            (route_settings_update, SettingsUpdateHandler),
            (route_settings_test, SettingsTestHandler),
            (route_analyze_image, ImageAnalysisHandler),
        ],
    )


def _jupyter_server_extension_points():
    """Entry points for Jupyter Server extension."""
    return [{"module": "cellsistant"}]


def _load_jupyter_server_extension(server_app):
    """Load server extension."""
    setup_webserver(server_app.web_app)
    server_app.log.info("AI Agent extension loaded")


# Compatibility with different Jupyter versions
load_jupyter_server_extension = _load_jupyter_server_extension
