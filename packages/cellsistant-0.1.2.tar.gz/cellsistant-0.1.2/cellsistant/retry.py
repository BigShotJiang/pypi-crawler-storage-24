"""HTTP request retry utilities."""

import asyncio
import logging
from typing import Optional


logger = logging.getLogger(__name__)

RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


class RetryConfig:
    """Retry configuration."""

    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 30.0,
        exponential_base: float = 2.0,
    ):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base

    def get_delay(self, attempt: int, retry_after: Optional[float] = None) -> float:
        """Calculate delay before next attempt (considers Retry-After header)."""
        if retry_after is not None:
            return min(retry_after, self.max_delay)

        delay = self.base_delay * (self.exponential_base**attempt)
        return min(delay, self.max_delay)


def parse_retry_after(headers: dict) -> Optional[float]:
    """Extract Retry-After value from response headers."""
    retry_after = headers.get("Retry-After") or headers.get("retry-after")
    if retry_after is None:
        return None

    try:
        return float(retry_after)
    except ValueError:
        return None


async def call_openrouter_with_retry(
    url: str,
    headers: dict,
    payload: dict,
    config: RetryConfig = RetryConfig(),
) -> dict:
    """Send request to OpenRouter with retry logic. Returns dict or raises exception."""

    import aiohttp

    last_error = None

    for attempt in range(config.max_retries + 1):
        try:
            async with (
                aiohttp.ClientSession() as session,
                session.post(
                    url,
                    json=payload,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=120),
                ) as response,
            ):
                if response.status == 200:
                    return await response.json()

                # Read error body
                error_body = await response.text()

                # Check if error is retryable
                if response.status in RETRYABLE_STATUS_CODES:
                    retry_after = parse_retry_after(dict(response.headers))
                    delay = config.get_delay(attempt, retry_after)

                    logger.warning(
                        f"OpenRouter returned {response.status}, "
                        f"retry {attempt + 1}/{config.max_retries} "
                        f"after {delay:.1f}s"
                    )

                    if attempt < config.max_retries:
                        await asyncio.sleep(delay)
                        continue

                # Non-retryable or retries exhausted
                raise OpenRouterError(
                    status=response.status,
                    message=error_body,
                    retryable=response.status in RETRYABLE_STATUS_CODES,
                )

        except aiohttp.ClientError as e:
            last_error = e
            if attempt < config.max_retries:
                delay = config.get_delay(attempt)
                logger.warning(
                    f"Network error: {e}, "
                    f"retry {attempt + 1}/{config.max_retries} "
                    f"after {delay:.1f}s"
                )
                await asyncio.sleep(delay)
                continue
            raise OpenRouterError(
                status=0,
                message=f"Network error after {config.max_retries} retries: {e}",
                retryable=True,
            )

    raise OpenRouterError(
        status=0,
        message=f"Max retries ({config.max_retries}) exceeded. Last error: {last_error}",
        retryable=False,
    )


class OpenRouterError(Exception):
    """OpenRouter API error."""

    def __init__(self, status: int, message: str, retryable: bool = False):
        self.status = status
        self.message = message
        self.retryable = retryable
        super().__init__(f"[{status}] {message}")
