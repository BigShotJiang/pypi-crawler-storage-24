"""
Tests for History handlers
"""

import json
import time
from unittest.mock import MagicMock, patch

import pytest

from cellsistant.history import (
    MAX_CHAT_SIZE,
    MAX_CHATS,
    HistoryExportHandler,
    HistoryItemHandler,
    HistoryListHandler,
    HistorySaveHandler,
    cleanup_old_chats,
    ensure_history_dir,
    extract_title,
    generate_chat_id,
)


@pytest.fixture
def mock_history_dir(tmp_path):
    """Fixture to mock history directory location"""
    with patch("cellsistant.history.HISTORY_DIR", tmp_path / "history"):
        yield tmp_path / "history"


@pytest.fixture
def sample_chat_data():
    """Fixture with sample chat data"""
    return {
        "id": "test_chat",
        "title": "Test Chat",
        "created_at": "2024-01-01T00:00:00",
        "updated_at": "2024-01-01T00:00:00",
        "messages": [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
        ],
    }


class TestHistoryConstants:
    """Tests for history constants"""

    def test_max_chats(self):
        """Test max chats constant"""
        assert MAX_CHATS == 100

    def test_max_chat_size(self):
        """Test max chat size constant"""
        assert MAX_CHAT_SIZE == 5 * 1024 * 1024  # 5MB


class TestEnsureHistoryDir:
    """Tests for ensure_history_dir function"""

    def test_creates_directory(self, mock_history_dir):
        """Test that ensure_history_dir creates directory"""
        assert not mock_history_dir.exists()

        ensure_history_dir()

        assert mock_history_dir.exists()

    def test_does_not_fail_if_exists(self, mock_history_dir):
        """Test that calling twice doesn't fail"""
        ensure_history_dir()
        ensure_history_dir()  # Should not raise

        assert mock_history_dir.exists()


class TestGenerateChatId:
    """Tests for generate_chat_id function"""

    def test_generates_unique_ids(self):
        """Test that generated IDs are unique"""
        ids = [generate_chat_id() for _ in range(100)]
        assert len(set(ids)) == 100

    def test_id_format(self):
        """Test ID format contains timestamp and hex"""
        chat_id = generate_chat_id()

        # Should contain underscore separator
        assert "_" in chat_id

        # Parts should be timestamp and hex
        parts = chat_id.split("_")
        assert len(parts) == 2
        assert parts[0].isdigit()  # timestamp
        assert len(parts[1]) == 8  # hex prefix


class TestExtractTitle:
    """Tests for extract_title function"""

    def test_extracts_from_first_user_message(self):
        """Test title extraction from first user message"""
        messages = [
            {"role": "user", "content": "How to create a function?"},
            {"role": "assistant", "content": "Here's how..."},
        ]

        title = extract_title(messages)
        assert title == "How to create a function?"

    def test_truncates_long_titles(self):
        """Test that long titles are truncated"""
        long_content = "x" * 100
        messages = [{"role": "user", "content": long_content}]

        title = extract_title(messages)
        assert len(title) == 80
        assert title.endswith("...")

    def test_takes_first_line_only(self):
        """Test that only first line is taken"""
        messages = [{"role": "user", "content": "First line\nSecond line\nThird line"}]

        title = extract_title(messages)
        assert title == "First line"

    def test_returns_untitled_for_no_user_messages(self):
        """Test fallback for no user messages"""
        messages = [{"role": "assistant", "content": "Hi!"}]

        title = extract_title(messages)
        assert title == "Untitled chat"

    def test_returns_untitled_for_empty_content(self):
        """Test fallback for empty content"""
        messages = [{"role": "user", "content": ""}]

        title = extract_title(messages)
        assert title == "Untitled chat"

    def test_strips_whitespace(self):
        """Test that whitespace is stripped"""
        messages = [{"role": "user", "content": "  Hello World  "}]

        title = extract_title(messages)
        assert title == "Hello World"


class TestHistoryListHandler:
    """Tests for HistoryListHandler"""

    def test_list_empty_history(self, mock_history_dir):
        """Test GET /ai-agent/history - empty"""
        ensure_history_dir()

        handler = MagicMock(spec=HistoryListHandler)
        handler.finish = MagicMock()

        # Simulate handler logic
        ensure_history_dir()
        chats = []

        handler.finish({"chats": chats})

        call_args = handler.finish.call_args[0][0]
        assert call_args["chats"] == []

    def test_list_chats(self, mock_history_dir, sample_chat_data):
        """Test GET /ai-agent/history - with chats"""
        ensure_history_dir()

        # Save a chat file
        file_path = mock_history_dir / f"{sample_chat_data['id']}.json"
        with open(file_path, "w") as f:
            json.dump(sample_chat_data, f)

        handler = MagicMock(spec=HistoryListHandler)
        handler.finish = MagicMock()

        # Simulate handler logic
        ensure_history_dir()
        chats = []

        for file_path in sorted(mock_history_dir.glob("*.json"), reverse=True):
            with open(file_path) as f:
                data = json.load(f)
            chats.append(
                {
                    "id": file_path.stem,
                    "title": data.get("title", "Untitled"),
                    "created_at": data.get("created_at", ""),
                    "updated_at": data.get("updated_at", ""),
                    "message_count": len(data.get("messages", [])),
                }
            )

        handler.finish({"chats": chats})

        call_args = handler.finish.call_args[0][0]
        assert len(call_args["chats"]) == 1
        assert call_args["chats"][0]["id"] == "test_chat"
        assert call_args["chats"][0]["title"] == "Test Chat"
        assert call_args["chats"][0]["message_count"] == 2

    def test_list_limits_max_chats(self, mock_history_dir):
        """Test that list is limited to MAX_CHATS"""
        ensure_history_dir()

        # Create some chat files (under limit for simple test)
        num_chats = 10
        for i in range(num_chats):
            chat_data = {"id": f"chat_{i}", "title": f"Chat {i}", "messages": []}
            file_path = mock_history_dir / f"chat_{i}.json"
            with open(file_path, "w") as f:
                json.dump(chat_data, f)

        chats = []
        for file_path in sorted(mock_history_dir.glob("*.json"), reverse=True):
            with open(file_path) as f:
                data = json.load(f)
            chats.append({"id": file_path.stem, "title": data.get("title", "Untitled")})

        # Should return all chats (under limit)
        assert len(chats) == num_chats


class TestHistorySaveHandler:
    """Tests for HistorySaveHandler"""

    def test_save_new_chat(self, mock_history_dir):
        """Test POST /ai-agent/history/save - new chat"""
        ensure_history_dir()

        handler = MagicMock(spec=HistorySaveHandler)
        handler.get_json_body = MagicMock(
            return_value={
                "messages": [
                    {"role": "user", "content": "Hello"},
                    {"role": "assistant", "content": "Hi!"},
                ]
            }
        )
        handler.finish = MagicMock()

        # Simulate save logic
        data = handler.get_json_body()
        messages = data.get("messages", [])

        chat_id = generate_chat_id()
        now = time.strftime("%Y-%m-%dT%H:%M:%S")

        chat_data = {
            "id": chat_id,
            "title": extract_title(messages),
            "created_at": now,
            "updated_at": now,
            "messages": messages,
        }

        file_path = mock_history_dir / f"{chat_id}.json"
        with open(file_path, "w") as f:
            json.dump(chat_data, f)

        handler.finish(
            {"id": chat_id, "title": chat_data["title"], "message": "Chat saved"}
        )

        # Verify file was created
        assert file_path.exists()

    def test_save_with_custom_title(self, mock_history_dir):
        """Test POST /ai-agent/history/save - with custom title"""
        ensure_history_dir()

        handler = MagicMock(spec=HistorySaveHandler)
        handler.get_json_body = MagicMock(
            return_value={
                "messages": [{"role": "user", "content": "Hello"}],
                "title": "Custom Title",
            }
        )
        handler.finish = MagicMock()

        data = handler.get_json_body()
        title = data.get("title") or extract_title(data.get("messages", []))

        assert title == "Custom Title"

    def test_save_without_messages_fails(self, mock_history_dir):
        """Test POST /ai-agent/history/save - without messages"""
        handler = MagicMock(spec=HistorySaveHandler)
        handler.get_json_body = MagicMock(return_value={})
        handler.set_status = MagicMock()
        handler.finish = MagicMock()

        data = handler.get_json_body()
        if not data.get("messages"):
            handler.set_status(400)
            handler.finish({"error": "Messages array is required"})

        handler.set_status.assert_called_with(400)

    def test_save_too_large_chat(self, mock_history_dir):
        """Test POST /ai-agent/history/save - chat too large"""
        handler = MagicMock(spec=HistorySaveHandler)
        handler.get_json_body = MagicMock(
            return_value={
                "messages": [{"role": "user", "content": "x" * (MAX_CHAT_SIZE + 1)}]
            }
        )
        handler.set_status = MagicMock()
        handler.finish = MagicMock()

        data = handler.get_json_body()
        chat_data = {"messages": data.get("messages", [])}
        serialized = json.dumps(chat_data, ensure_ascii=False)

        if len(serialized) > MAX_CHAT_SIZE:
            handler.set_status(413)
            handler.finish(
                {
                    "error": f"Chat too large: {len(serialized)} bytes (max {MAX_CHAT_SIZE})"
                }
            )

        handler.set_status.assert_called_with(413)


class TestHistoryItemHandler:
    """Tests for HistoryItemHandler"""

    def test_load_chat(self, mock_history_dir, sample_chat_data):
        """Test GET /ai-agent/history/{id}"""
        ensure_history_dir()

        # Save chat file
        file_path = mock_history_dir / f"{sample_chat_data['id']}.json"
        with open(file_path, "w") as f:
            json.dump(sample_chat_data, f)

        handler = MagicMock(spec=HistoryItemHandler)
        handler.finish = MagicMock()

        # Simulate load logic
        file_path = mock_history_dir / "test_chat.json"
        if file_path.exists():
            with open(file_path) as f:
                data = json.load(f)
            handler.finish(data)

        call_args = handler.finish.call_args[0][0]
        assert call_args["id"] == "test_chat"
        assert len(call_args["messages"]) == 2

    def test_load_nonexistent_chat(self, mock_history_dir):
        """Test GET /ai-agent/history/{id} - not found"""
        ensure_history_dir()

        handler = MagicMock(spec=HistoryItemHandler)
        handler.set_status = MagicMock()
        handler.finish = MagicMock()

        file_path = mock_history_dir / "nonexistent.json"
        if not file_path.exists():
            handler.set_status(404)
            handler.finish({"error": "Chat not found: nonexistent"})

        handler.set_status.assert_called_with(404)

    def test_delete_chat(self, mock_history_dir, sample_chat_data):
        """Test DELETE /ai-agent/history/{id}"""
        ensure_history_dir()

        # Save chat file
        file_path = mock_history_dir / f"{sample_chat_data['id']}.json"
        with open(file_path, "w") as f:
            json.dump(sample_chat_data, f)

        handler = MagicMock(spec=HistoryItemHandler)
        handler.finish = MagicMock()

        # Simulate delete logic
        chat_id = "test_chat"
        file_path = mock_history_dir / f"{chat_id}.json"

        if file_path.exists():
            file_path.unlink()
            handler.finish({"message": f"Chat {chat_id} deleted"})

        handler.finish.assert_called()
        assert not file_path.exists()

    def test_delete_nonexistent_chat(self, mock_history_dir):
        """Test DELETE /ai-agent/history/{id} - not found"""
        ensure_history_dir()

        handler = MagicMock(spec=HistoryItemHandler)
        handler.set_status = MagicMock()
        handler.finish = MagicMock()

        chat_id = "nonexistent"
        file_path = mock_history_dir / f"{chat_id}.json"

        if not file_path.exists():
            handler.set_status(404)
            handler.finish({"error": f"Chat not found: {chat_id}"})

        handler.set_status.assert_called_with(404)


class TestHistoryExportHandler:
    """Tests for HistoryExportHandler"""

    def test_export_chat_to_markdown(self, mock_history_dir, sample_chat_data):
        """Test GET /ai-agent/history/{id}/export"""
        ensure_history_dir()

        # Save chat file
        file_path = mock_history_dir / f"{sample_chat_data['id']}.json"
        with open(file_path, "w") as f:
            json.dump(sample_chat_data, f)

        handler = MagicMock(spec=HistoryExportHandler)
        handler.finish = MagicMock()
        handler.set_header = MagicMock()

        # Simulate export logic
        file_path = mock_history_dir / "test_chat.json"
        if file_path.exists():
            with open(file_path) as f:
                data = json.load(f)

            # Generate Markdown
            md_lines = [
                f"# {data.get('title', 'Untitled Chat')}",
                "",
                f"**Created:** {data.get('created_at', 'Unknown')}",
                f"**Updated:** {data.get('updated_at', 'Unknown')}",
                "",
            ]

            for msg in data.get("messages", []):
                role = msg.get("role", "unknown")
                content = msg.get("content", "")

                if role == "user":
                    md_lines.append("## 👤 User")
                elif role == "assistant":
                    md_lines.append("## 🤖 Assistant")

                md_lines.append("")
                if content:
                    md_lines.append(content)

            markdown_content = "\n".join(md_lines)

            handler.set_header("Content-Type", "text/markdown; charset=utf-8")
            handler.set_header(
                "Content-Disposition", "attachment; filename=chat-test_chat.md"
            )
            handler.finish(markdown_content)

        handler.set_header.assert_called()
        handler.finish.assert_called()

    def test_export_nonexistent_chat(self, mock_history_dir):
        """Test GET /ai-agent/history/{id}/export - not found"""
        ensure_history_dir()

        handler = MagicMock(spec=HistoryExportHandler)
        handler.set_status = MagicMock()
        handler.finish = MagicMock()

        file_path = mock_history_dir / "nonexistent.json"
        if not file_path.exists():
            handler.set_status(404)
            handler.finish({"error": "Chat not found: nonexistent"})

        handler.set_status.assert_called_with(404)


class TestCleanupOldChats:
    """Tests for cleanup_old_chats function"""

    def test_cleanup_removes_oldest(self, mock_history_dir):
        """Test that cleanup removes oldest chats"""
        ensure_history_dir()

        # Create MAX_CHATS + 5 files with different timestamps
        for i in range(MAX_CHATS + 5):
            chat_data = {
                "id": f"chat_{i}",
                "title": f"Chat {i}",
                "created_at": f"2024-01-{i + 1:02d}T00:00:00",
                "messages": [],
            }
            file_path = mock_history_dir / f"chat_{i}.json"
            with open(file_path, "w") as f:
                json.dump(chat_data, f)

        cleanup_old_chats()

        # Count remaining files
        remaining = list(mock_history_dir.glob("*.json"))
        assert len(remaining) <= MAX_CHATS

    def test_cleanup_does_not_remove_under_limit(self, mock_history_dir):
        """Test that cleanup doesn't remove chats under limit"""
        ensure_history_dir()

        # Create 10 files (under limit)
        for i in range(10):
            chat_data = {"id": f"chat_{i}", "title": f"Chat {i}", "messages": []}
            file_path = mock_history_dir / f"chat_{i}.json"
            with open(file_path, "w") as f:
                json.dump(chat_data, f)

        cleanup_old_chats()

        remaining = list(mock_history_dir.glob("*.json"))
        assert len(remaining) == 10
