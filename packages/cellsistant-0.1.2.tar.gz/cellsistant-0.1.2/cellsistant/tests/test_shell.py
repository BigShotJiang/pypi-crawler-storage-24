"""Tests for ShellHandler security logic"""

import os
import sys


# Добавляем путь к модулю
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from cellsistant import BLOCKED_COMMANDS, MAX_EXECUTION_TIME, MAX_OUTPUT_SIZE


class TestBlockedCommands:
    """Tests for blocked commands list"""

    def test_blocked_commands_set_not_empty(self):
        """Test that blocked commands set is not empty"""
        assert len(BLOCKED_COMMANDS) > 0

    def test_contains_destructive_patterns(self):
        """Test contains destructive command patterns"""
        assert "rm -rf /" in BLOCKED_COMMANDS
        assert "rm -fr" in BLOCKED_COMMANDS or "rm -rf" in str(BLOCKED_COMMANDS)

    def test_contains_system_patterns(self):
        """Test contains system command patterns"""
        assert "shutdown" in BLOCKED_COMMANDS
        assert "reboot" in BLOCKED_COMMANDS
        assert "mkfs" in BLOCKED_COMMANDS

    def test_contains_fork_bomb(self):
        """Test contains fork bomb pattern"""
        assert ":(){" in BLOCKED_COMMANDS  # Partial match for fork bomb

    def test_contains_network_patterns(self):
        """Test contains network attack patterns"""
        assert "socat" in BLOCKED_COMMANDS
        assert "ncat" in BLOCKED_COMMANDS or "nc -l" in BLOCKED_COMMANDS

    def test_contains_mining_patterns(self):
        """Test contains crypto mining patterns"""
        assert "minerd" in BLOCKED_COMMANDS
        assert "xmrig" in BLOCKED_COMMANDS
        assert "cpuminer" in BLOCKED_COMMANDS


class TestResourceLimits:
    """Tests for resource limit constants"""

    def test_max_execution_time(self):
        """Test max execution time constant"""
        assert MAX_EXECUTION_TIME == 60  # 60 seconds

    def test_max_output_size(self):
        """Test max output size constant"""
        assert MAX_OUTPUT_SIZE == 100 * 1024  # 100KB

    def test_memory_limit(self):
        """Test memory limit constant"""
        from cellsistant import RESOURCE_LIMITS

        assert RESOURCE_LIMITS["max_memory_mb"] == 512

    def test_file_size_limit(self):
        """Test file size limit constant"""
        from cellsistant import RESOURCE_LIMITS

        assert RESOURCE_LIMITS["max_file_size_mb"] == 100

    def test_process_limit(self):
        """Test process limit constant"""
        from cellsistant import RESOURCE_LIMITS

        assert RESOURCE_LIMITS["max_processes"] == 50


class TestShellHandlerSecurity:
    """Tests for ShellHandler security checks"""

    def test_rejects_empty_command(self):
        """Test that empty command is rejected"""
        # This tests the logic in ShellHandler.post()
        # Empty command should return 400 status
        command = ""
        assert not command.strip()

    def test_blocks_rm_rf_root(self):
        """Test that 'rm -rf /' is blocked"""
        command = "rm -rf /"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert is_blocked

    def test_blocks_rm_rf_home(self):
        """Test that 'rm -rf ~' is blocked"""
        command = "rm -rf ~"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert is_blocked

    def test_blocks_shutdown(self):
        """Test that shutdown command is blocked"""
        command = "sudo shutdown now"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert is_blocked

    def test_blocks_reboot(self):
        """Test that reboot command is blocked"""
        command = "reboot"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert is_blocked

    def test_blocks_mkfs(self):
        """Test that mkfs command is blocked"""
        command = "mkfs.ext4 /dev/sda"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert is_blocked

    def test_blocks_dd(self):
        """Test that dd command is blocked"""
        command = "dd if=/dev/zero of=/dev/sda"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert is_blocked

    def test_blocks_fork_bomb(self):
        """Test that fork bomb is blocked"""
        command = ":(){ :|:& };:"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert is_blocked

    def test_allows_safe_command(self):
        """Test that safe commands are allowed"""
        command = "echo 'Hello World'"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert not is_blocked

    def test_allows_python_command(self):
        """Test that Python commands are allowed"""
        command = "python3 -c 'print(1+1)'"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert not is_blocked

    def test_allows_ls_command(self):
        """Test that ls command is allowed"""
        command = "ls -la"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert not is_blocked

    def test_allows_echo_command(self):
        """Test that echo command is allowed"""
        command = "echo $PATH"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert not is_blocked

    def test_blocks_command_in_middle(self):
        """Test that blocked command in middle is detected"""
        command = "echo test && rm -rf / && echo done"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert is_blocked

    def test_case_insensitive_blocking(self):
        """Test that blocking is case insensitive"""
        command = "RM -RF /"
        command_lower = command.lower().strip()

        is_blocked = any(blocked in command_lower for blocked in BLOCKED_COMMANDS)
        assert is_blocked


class TestShellOutputTruncation:
    """Tests for shell output truncation logic"""

    def test_truncates_large_stdout(self):
        """Test that large stdout is truncated"""
        large_output = "x" * (MAX_OUTPUT_SIZE + 1000)
        truncated = large_output[:MAX_OUTPUT_SIZE]

        assert len(truncated) == MAX_OUTPUT_SIZE
        assert len(truncated) < len(large_output)

    def test_truncates_large_stderr(self):
        """Test that large stderr is truncated"""
        large_output = "y" * (MAX_OUTPUT_SIZE * 2)
        truncated = large_output[:MAX_OUTPUT_SIZE]

        assert len(truncated) == MAX_OUTPUT_SIZE

    def test_does_not_truncate_small_output(self):
        """Test that small output is not truncated"""
        small_output = "small output"

        assert len(small_output) < MAX_OUTPUT_SIZE
        # No truncation needed

    def test_exact_max_size_not_truncated(self):
        """Test that output at exact max size is not truncated"""
        exact_output = "z" * MAX_OUTPUT_SIZE

        assert len(exact_output) == MAX_OUTPUT_SIZE


class TestShellTimeout:
    """Tests for shell timeout logic"""

    def test_timeout_capped_at_max(self):
        """Test that timeout is capped at max"""
        requested_timeout = 1000  # 1000 seconds
        capped_timeout = min(requested_timeout, MAX_EXECUTION_TIME)

        assert capped_timeout == MAX_EXECUTION_TIME

    def test_timeout_under_max_accepted(self):
        """Test that timeout under max is accepted"""
        requested_timeout = 30  # 30 seconds
        capped_timeout = min(requested_timeout, MAX_EXECUTION_TIME)

        assert capped_timeout == requested_timeout

    def test_default_timeout(self):
        """Test default timeout value"""
        # Default should be MAX_EXECUTION_TIME
        assert MAX_EXECUTION_TIME == 60


class TestShellResponseFormat:
    """Tests for shell response format"""

    def test_success_response_format(self):
        """Test success response has all fields"""
        response = {
            "success": True,
            "return_code": 0,
            "stdout": "output",
            "stderr": "",
            "stdout_truncated": False,
            "stderr_truncated": False,
            "elapsed_seconds": 0.5,
        }

        assert "success" in response
        assert "return_code" in response
        assert "stdout" in response
        assert "stderr" in response
        assert "elapsed_seconds" in response

    def test_error_response_format(self):
        """Test error response has all fields"""
        response = {
            "success": False,
            "return_code": 1,
            "stdout": "",
            "stderr": "error message",
            "stdout_truncated": False,
            "stderr_truncated": False,
            "elapsed_seconds": 0.1,
        }

        assert response["success"] is False
        assert response["return_code"] != 0
        assert response["stderr"] != ""

    def test_timeout_response_format(self):
        """Test timeout error response"""
        # TimeoutExpired should produce error response
        error_response = {"error": "Command timed out after 60s"}

        assert "error" in error_response
