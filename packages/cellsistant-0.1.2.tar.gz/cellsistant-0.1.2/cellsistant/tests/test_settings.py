"""
Tests for Settings handlers

Updated for unified OpenAI-compatible API settings:
- base_url: API endpoint URL
- api_key: API key (optional)
- model: model identifier
"""

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from cellsistant.settings import (
    SettingsGetHandler,
    SettingsTestHandler,
    SettingsUpdateHandler,
    load_settings,
    save_settings,
)


@pytest.fixture
def mock_config_dir(tmp_path):
    """Fixture to mock config directory location"""
    with patch("cellsistant.settings.CONFIG_DIR", tmp_path / "config"):
        with patch(
            "cellsistant.settings.SETTINGS_FILE",
            tmp_path / "config" / "settings.json",
        ):
            yield tmp_path / "config"


class TestUnifiedSettings:
    """Tests for unified OpenAI-compatible API settings"""

    def test_default_base_url(self, mock_config_dir):
        """Test default base URL is OpenRouter"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({})

        settings = load_settings()

        base_url = settings.get("base_url", "https://openrouter.ai/api/v1")
        assert base_url == "https://openrouter.ai/api/v1"

    def test_custom_base_url(self, mock_config_dir):
        """Test custom base URL"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({"base_url": "https://api.openai.com/v1"})

        settings = load_settings()
        assert settings["base_url"] == "https://api.openai.com/v1"

    def test_api_key_optional(self, mock_config_dir):
        """Test that API key is optional (for local APIs)"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({"base_url": "http://localhost:11434/v1", "api_key": ""})

        settings = load_settings()
        assert settings.get("api_key", "") == ""

    def test_api_key_stored(self, mock_config_dir):
        """Test API key is stored in settings"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({"api_key": "sk-test-key-1234"})

        settings = load_settings()
        assert settings["api_key"] == "sk-test-key-1234"

    def test_model_identifier(self, mock_config_dir):
        """Test model identifier storage"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({"model": "google/gemini-2.0-flash:free"})

        settings = load_settings()
        assert settings["model"] == "google/gemini-2.0-flash:free"


class TestLoadAndSaveSettings:
    """Tests for load_settings and save_settings functions"""

    def test_load_settings_nonexistent(self, mock_config_dir):
        """Test loading when settings.json doesn't exist"""
        settings = load_settings()
        assert settings == {}

    def test_load_settings_with_data(self, mock_config_dir):
        """Test loading settings with data"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        with open(mock_config_dir / "settings.json", "w") as f:
            json.dump({"base_url": "https://api.openai.com/v1", "model": "gpt-4o"}, f)

        settings = load_settings()
        assert settings["base_url"] == "https://api.openai.com/v1"
        assert settings["model"] == "gpt-4o"

    def test_save_and_load_settings(self, mock_config_dir):
        """Test saving and loading settings"""
        save_settings({"model": "gpt-4", "temperature": 0.5})

        settings = load_settings()
        assert settings["model"] == "gpt-4"
        assert settings["temperature"] == 0.5

    def test_save_settings_creates_directory(self, mock_config_dir):
        """Test that save_settings creates directory"""
        save_settings({"key": "value"})

        assert (mock_config_dir / "settings.json").exists()


class TestSettingsGetHandler:
    """Tests for SettingsGetHandler"""

    def test_get_settings_defaults(self, mock_config_dir):
        """Test GET /ai-agent/settings - defaults"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({})

        handler = MagicMock(spec=SettingsGetHandler)
        handler.finish = MagicMock()

        # Simulate handler logic
        settings = load_settings()

        result = {
            "base_url": settings.get("base_url", "https://openrouter.ai/api/v1"),
            "api_key": settings.get("api_key"),
            "model": settings.get("model", "google/gemini-2.0-flash:free"),
            "temperature": settings.get("temperature", 0.3),
            "max_tokens": settings.get("max_tokens", 0),
        }

        handler.finish(result)

        call_args = handler.finish.call_args[0][0]
        assert call_args["base_url"] == "https://openrouter.ai/api/v1"
        assert call_args["model"] == "google/gemini-2.0-flash:free"
        assert call_args["temperature"] == 0.3

    def test_get_settings_custom_values(self, mock_config_dir):
        """Test GET /ai-agent/settings - custom values"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({
            "base_url": "https://api.openai.com/v1",
            "model": "gpt-4-turbo",
            "temperature": 0.7,
            "max_tokens": 1000
        })

        handler = MagicMock(spec=SettingsGetHandler)
        handler.finish = MagicMock()

        settings = load_settings()

        result = {
            "base_url": settings.get("base_url", "https://openrouter.ai/api/v1"),
            "api_key": settings.get("api_key"),
            "model": settings.get("model", "google/gemini-2.0-flash:free"),
            "temperature": settings.get("temperature", 0.3),
            "max_tokens": settings.get("max_tokens", 0),
        }

        handler.finish(result)

        call_args = handler.finish.call_args[0][0]
        assert call_args["base_url"] == "https://api.openai.com/v1"
        assert call_args["model"] == "gpt-4-turbo"
        assert call_args["temperature"] == 0.7
        assert call_args["max_tokens"] == 1000

    def test_get_settings_masked_key(self, mock_config_dir):
        """Test that API key is masked"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({"api_key": "sk-very-long-key-1234"})

        settings = load_settings()
        api_key = settings.get("api_key", "")

        # Masking logic
        masked = None
        if api_key:
            if len(api_key) > 8:
                masked = f"{'*' * (len(api_key) - 4)}{api_key[-4:]}"
            else:
                masked = "****"

        assert masked.endswith("1234")
        assert "*" in masked


class TestSettingsUpdateHandler:
    """Tests for SettingsUpdateHandler"""

    def test_update_base_url(self, mock_config_dir):
        """Test POST /ai-agent/settings - update base_url"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({})

        handler = MagicMock(spec=SettingsUpdateHandler)
        handler.get_json_body = MagicMock(return_value={"base_url": "https://api.openai.com/v1"})
        handler.finish = MagicMock()

        # Simulate update logic
        data = handler.get_json_body()
        settings = load_settings()

        if "base_url" in data:
            settings["base_url"] = data["base_url"].rstrip("/")

        save_settings(settings)

        updated = load_settings()
        assert updated["base_url"] == "https://api.openai.com/v1"

    def test_update_base_url_trailing_slash(self, mock_config_dir):
        """Test that trailing slash is removed from base_url"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({})

        handler = MagicMock(spec=SettingsUpdateHandler)
        handler.get_json_body = MagicMock(return_value={"base_url": "https://api.openai.com/v1/"})
        handler.finish = MagicMock()

        data = handler.get_json_body()
        settings = load_settings()

        if "base_url" in data:
            settings["base_url"] = data["base_url"].rstrip("/")

        save_settings(settings)

        updated = load_settings()
        assert updated["base_url"] == "https://api.openai.com/v1"

    def test_update_api_key(self, mock_config_dir):
        """Test POST /ai-agent/settings - update api_key"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({})

        handler = MagicMock(spec=SettingsUpdateHandler)
        handler.get_json_body = MagicMock(return_value={"api_key": "sk-new-key"})
        handler.finish = MagicMock()

        data = handler.get_json_body()
        settings = load_settings()

        if "api_key" in data:
            api_key = str(data["api_key"])
            if api_key:
                settings["api_key"] = api_key
            else:
                settings.pop("api_key", None)

        save_settings(settings)

        assert load_settings()["api_key"] == "sk-new-key"

    def test_update_remove_api_key(self, mock_config_dir):
        """Test POST /ai-agent/settings - remove api_key"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({"api_key": "old-key"})

        handler = MagicMock(spec=SettingsUpdateHandler)
        handler.get_json_body = MagicMock(return_value={"api_key": ""})
        handler.finish = MagicMock()

        data = handler.get_json_body()
        settings = load_settings()

        if "api_key" in data:
            api_key = str(data["api_key"])
            if api_key:
                settings["api_key"] = api_key
            else:
                settings.pop("api_key", None)

        save_settings(settings)

        assert "api_key" not in load_settings()

    def test_update_model(self, mock_config_dir):
        """Test POST /ai-agent/settings - update model"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({})

        handler = MagicMock(spec=SettingsUpdateHandler)
        handler.get_json_body = MagicMock(return_value={"model": "gpt-4-turbo"})
        handler.finish = MagicMock()

        data = handler.get_json_body()
        settings = load_settings()

        if "model" in data:
            settings["model"] = str(data["model"])

        save_settings(settings)

        assert load_settings()["model"] == "gpt-4-turbo"

    def test_update_temperature_valid(self, mock_config_dir):
        """Test POST /ai-agent/settings - valid temperature"""
        handler = MagicMock(spec=SettingsUpdateHandler)
        handler.get_json_body = MagicMock(return_value={"temperature": 0.8})
        handler.finish = MagicMock()

        data = handler.get_json_body()
        temp = float(data.get("temperature", 0.3))

        if not (0 <= temp <= 2):
            handler.set_status(400)
            handler.finish({"error": "Temperature must be between 0 and 2"})
        else:
            handler.finish({"message": "Settings updated"})

        handler.set_status.assert_not_called()

    def test_update_temperature_invalid(self, mock_config_dir):
        """Test POST /ai-agent/settings - invalid temperature"""
        handler = MagicMock(spec=SettingsUpdateHandler)
        handler.get_json_body = MagicMock(return_value={"temperature": 3.0})
        handler.set_status = MagicMock()
        handler.finish = MagicMock()

        data = handler.get_json_body()
        temp = float(data.get("temperature", 0.3))

        if not (0 <= temp <= 2):
            handler.set_status(400)
            handler.finish({"error": "Temperature must be between 0 and 2"})

        handler.set_status.assert_called_with(400)

    def test_update_max_tokens(self, mock_config_dir):
        """Test POST /ai-agent/settings - update max_tokens"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)
        save_settings({})

        handler = MagicMock(spec=SettingsUpdateHandler)
        handler.get_json_body = MagicMock(return_value={"max_tokens": 2048})
        handler.finish = MagicMock()

        data = handler.get_json_body()
        settings = load_settings()

        if "max_tokens" in data:
            settings["max_tokens"] = int(data["max_tokens"])

        save_settings(settings)

        assert load_settings()["max_tokens"] == 2048


class TestSettingsTestHandler:
    """Tests for SettingsTestHandler"""

    def test_test_connection_success(self):
        """Test POST /ai-agent/settings/test - success"""
        handler = MagicMock(spec=SettingsTestHandler)
        handler.get_json_body = MagicMock(
            return_value={"base_url": "https://api.openai.com/v1", "api_key": "test-key", "model": "gpt-3.5-turbo"}
        )
        handler.finish = MagicMock()

        # Mock aiohttp response
        mock_response = AsyncMock()
        mock_response.status = 200
        mock_response.json = AsyncMock(
            return_value={
                "choices": [{"message": {"content": "ok"}}],
                "model": "gpt-3.5-turbo",
            }
        )

        mock_context = AsyncMock()
        mock_context.__aenter__ = AsyncMock(return_value=mock_response)
        mock_context.__aexit__ = AsyncMock(return_value=None)

        with patch("aiohttp.ClientSession") as mock_session_class:
            mock_session = AsyncMock()
            mock_session.post = MagicMock(return_value=mock_context)
            mock_session_class.return_value = mock_session

            # Simulate test logic
            data = handler.get_json_body()
            api_key = data.get("api_key")

            if api_key:
                handler.finish({"success": True, "response": "ok", "latency_ms": 100})

        handler.finish.assert_called()
        call_args = handler.finish.call_args[0][0]
        assert call_args["success"] is True

    def test_test_connection_no_api_key(self):
        """Test POST /ai-agent/settings/test - no API key (local API)"""
        handler = MagicMock(spec=SettingsTestHandler)
        handler.get_json_body = MagicMock(
            return_value={"base_url": "http://localhost:11434/v1", "model": "llama3.1"}
        )
        handler.finish = MagicMock()

        # For local APIs, no key is required - should still work
        data = handler.get_json_body()
        api_key = data.get("api_key", "")

        # Empty key is OK for local APIs
        assert api_key == ""

    def test_test_connection_http_error(self):
        """Test POST /ai-agent/settings/test - HTTP error"""
        handler = MagicMock(spec=SettingsTestHandler)
        handler.get_json_body = MagicMock(
            return_value={"base_url": "https://api.openai.com/v1", "api_key": "invalid-key"}
        )
        handler.finish = MagicMock()

        # Mock error response
        mock_response = AsyncMock()
        mock_response.status = 401
        mock_response.text = AsyncMock(return_value="Unauthorized")

        mock_context = AsyncMock()
        mock_context.__aenter__ = AsyncMock(return_value=mock_response)
        mock_context.__aexit__ = AsyncMock(return_value=None)

        with patch("aiohttp.ClientSession") as mock_session_class:
            mock_session = AsyncMock()
            mock_session.post = MagicMock(return_value=mock_context)
            mock_session_class.return_value = mock_session

            # Simulate error handling
            handler.finish({"success": False, "error": "HTTP 401: Unauthorized"})

        call_args = handler.finish.call_args[0][0]
        assert call_args["success"] is False
        assert "401" in call_args["error"]

    def test_test_connection_custom_endpoint(self):
        """Test POST /ai-agent/settings/test - custom endpoint"""
        handler = MagicMock(spec=SettingsTestHandler)
        handler.get_json_body = MagicMock(
            return_value={
                "base_url": "http://localhost:11434/v1",
                "model": "llama3.1",
            }
        )

        data = handler.get_json_body()
        base_url = data.get("base_url", "").rstrip("/")

        assert base_url == "http://localhost:11434/v1"


class TestSettingsIntegration:
    """Integration tests for settings"""

    def test_full_settings_workflow(self, mock_config_dir):
        """Test complete settings workflow"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)

        # 1. Save settings with unified API config
        save_settings(
            {
                "base_url": "https://api.openai.com/v1",
                "api_key": "sk-test-key",
                "model": "gpt-4o",
                "temperature": 0.5,
                "max_tokens": 1000,
            }
        )

        # 2. Load and verify
        settings = load_settings()

        assert settings["base_url"] == "https://api.openai.com/v1"
        assert settings["api_key"] == "sk-test-key"
        assert settings["model"] == "gpt-4o"
        assert settings["temperature"] == 0.5
        assert settings["max_tokens"] == 1000

        # 3. Update settings
        settings["temperature"] = 0.8
        settings["base_url"] = "https://openrouter.ai/api/v1"
        save_settings(settings)

        # 4. Verify update
        updated = load_settings()
        assert updated["temperature"] == 0.8
        assert updated["base_url"] == "https://openrouter.ai/api/v1"

    def test_settings_multiple_providers(self, mock_config_dir):
        """Test switching between different API providers"""
        mock_config_dir.mkdir(parents=True, exist_ok=True)

        # OpenAI
        save_settings({
            "base_url": "https://api.openai.com/v1",
            "api_key": "sk-openai-key",
            "model": "gpt-4o"
        })
        settings = load_settings()
        assert settings["base_url"] == "https://api.openai.com/v1"

        # OpenRouter
        save_settings({
            "base_url": "https://openrouter.ai/api/v1",
            "api_key": "sk-or-key",
            "model": "google/gemini-2.0-flash:free"
        })
        settings = load_settings()
        assert settings["base_url"] == "https://openrouter.ai/api/v1"

        # Local (Ollama)
        save_settings({
            "base_url": "http://localhost:11434/v1",
            "api_key": "",
            "model": "llama3.1"
        })
        settings = load_settings()
        assert settings["base_url"] == "http://localhost:11434/v1"
        assert settings["api_key"] == ""
