"""Tests for retry logic"""

from cellsistant.retry import (
    RETRYABLE_STATUS_CODES,
    OpenRouterError,
    RetryConfig,
    parse_retry_after,
)


class TestRetryConfig:
    """Tests for RetryConfig class"""

    def test_init_default_values(self):
        """Test default initialization"""
        config = RetryConfig()

        assert config.max_retries == 3
        assert config.base_delay == 1.0
        assert config.max_delay == 30.0
        assert config.exponential_base == 2.0

    def test_init_custom_values(self):
        """Test custom initialization"""
        config = RetryConfig(
            max_retries=5, base_delay=2.0, max_delay=60.0, exponential_base=3.0
        )

        assert config.max_retries == 5
        assert config.base_delay == 2.0
        assert config.max_delay == 60.0
        assert config.exponential_base == 3.0

    def test_get_delay_exponential(self):
        """Test exponential backoff"""
        config = RetryConfig(base_delay=1.0, exponential_base=2.0, max_delay=60.0)

        assert config.get_delay(0) == 1.0  # 1 * 2^0 = 1
        assert config.get_delay(1) == 2.0  # 1 * 2^1 = 2
        assert config.get_delay(2) == 4.0  # 1 * 2^2 = 4
        assert config.get_delay(3) == 8.0  # 1 * 2^3 = 8

    def test_get_delay_with_retry_after(self):
        """Test delay with Retry-After header"""
        config = RetryConfig(base_delay=1.0)

        delay = config.get_delay(0, retry_after=10.0)
        assert delay == 10.0

    def test_get_delay_capped_at_max(self):
        """Test delay is capped at max"""
        config = RetryConfig(base_delay=1.0, exponential_base=2.0, max_delay=10.0)

        # 1 * 2^10 = 1024, but should be capped at 10
        delay = config.get_delay(10)
        assert delay == 10.0


class TestParseRetryAfter:
    """Tests for parse_retry_after function"""

    def test_parse_float_value(self):
        """Test parsing float value"""
        headers = {"Retry-After": "10.5"}
        assert parse_retry_after(headers) == 10.5

    def test_parse_int_value(self):
        """Test parsing int value"""
        headers = {"Retry-After": "30"}
        assert parse_retry_after(headers) == 30.0

    def test_lowercase_header(self):
        """Test lowercase header"""
        headers = {"retry-after": "15"}
        assert parse_retry_after(headers) == 15.0

    def test_missing_header(self):
        """Test missing header"""
        headers = {}
        assert parse_retry_after(headers) is None

    def test_invalid_value(self):
        """Test invalid value"""
        headers = {"Retry-After": "invalid"}
        assert parse_retry_after(headers) is None

    def test_none_value(self):
        """Test None value"""
        headers = {"Retry-After": None}
        assert parse_retry_after(headers) is None


class TestOpenRouterError:
    """Tests for OpenRouterError exception"""

    def test_init_with_retryable(self):
        """Test initialization with retryable flag"""
        error = OpenRouterError(500, "Test error", retryable=True)

        assert error.status == 500
        assert error.message == "Test error"
        assert error.retryable is True

    def test_init_default_retryable(self):
        """Test default retryable value"""
        error = OpenRouterError(400, "Test error")

        assert error.status == 400
        assert error.message == "Test error"
        assert error.retryable is False

    def test_string_representation(self):
        """Test string representation"""
        error = OpenRouterError(503, "Connection failed")

        assert str(error) == "[503] Connection failed"


class TestRetryableStatusCodes:
    """Tests for RETRYABLE_STATUS_CODES set"""

    def test_contains_expected_codes(self):
        """Test set contains expected codes"""
        assert 429 in RETRYABLE_STATUS_CODES
        assert 500 in RETRYABLE_STATUS_CODES
        assert 502 in RETRYABLE_STATUS_CODES
        assert 503 in RETRYABLE_STATUS_CODES
        assert 504 in RETRYABLE_STATUS_CODES

    def test_does_not_contain_non_retryable(self):
        """Test set does not contain non-retryable codes"""
        assert 400 not in RETRYABLE_STATUS_CODES
        assert 401 not in RETRYABLE_STATUS_CODES
        assert 404 not in RETRYABLE_STATUS_CODES
