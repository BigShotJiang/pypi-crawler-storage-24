"""Tests for RateLimiter"""

import time

from cellsistant.rate_limiter import RateLimiter


class TestRateLimiter:
    """Tests for RateLimiter class"""

    def test_init_default_values(self):
        """Test default initialization"""
        limiter = RateLimiter()

        assert limiter.max_per_minute == 30
        assert limiter.max_per_hour == 500
        assert len(limiter.minute_window) == 0
        assert len(limiter.hour_window) == 0

    def test_init_custom_values(self):
        """Test custom initialization"""
        limiter = RateLimiter(max_requests_per_minute=10, max_requests_per_hour=100)

        assert limiter.max_per_minute == 10
        assert limiter.max_per_hour == 100

    def test_check_allows_under_limit(self):
        """Test check allows requests under limit"""
        limiter = RateLimiter(max_requests_per_minute=10)

        allowed, error = limiter.check()

        assert allowed is True
        assert error is None

    def test_check_blocks_over_minute_limit(self):
        """Test check blocks when minute limit exceeded"""
        limiter = RateLimiter(max_requests_per_minute=2)

        # First two requests should pass and be recorded
        assert limiter.check()[0] is True
        limiter.record()
        assert limiter.check()[0] is True
        limiter.record()

        # Third should be blocked
        allowed, error = limiter.check()
        assert allowed is False
        assert "min exceeded" in error or "Rate limit" in error

    def test_check_blocks_over_hour_limit(self):
        """Test check blocks when hour limit exceeded"""
        limiter = RateLimiter(max_requests_per_minute=100, max_requests_per_hour=2)

        # First two requests should pass and be recorded
        assert limiter.check()[0] is True
        limiter.record()
        assert limiter.check()[0] is True
        limiter.record()

        # Third should be blocked
        allowed, error = limiter.check()
        assert allowed is False
        assert "hour exceeded" in error or "Rate limit" in error

    def test_check_expires_old_requests(self):
        """Test that old requests expire from window"""
        limiter = RateLimiter(max_requests_per_minute=2)

        # Use up the limit
        assert limiter.check()[0] is True
        limiter.record()
        assert limiter.check()[0] is True
        limiter.record()

        # Should be blocked
        assert limiter.check()[0] is False

        # Manually expire the window by clearing and adding old timestamp
        old_time = time.time() - 61
        limiter.minute_window.clear()
        limiter.minute_window.append(old_time)

        # Should be allowed now since old request expired
        allowed, error = limiter.check()
        # After check passes, we can record
        assert allowed is True

    def test_default_limiters(self):
        """Test default limiter instances"""
        from cellsistant import chat_limiter, shell_limiter

        assert chat_limiter.max_per_minute == 30
        assert shell_limiter.max_per_minute == 10


class TestChatLimiter:
    """Tests for chat limiter"""

    def test_chat_limiter_configuration(self):
        """Test chat limiter is configured correctly"""
        from cellsistant import chat_limiter

        assert chat_limiter.max_per_minute == 30
        assert chat_limiter.max_per_hour == 500


class TestShellLimiter:
    """Tests for shell limiter"""

    def test_shell_limiter_configuration(self):
        """Test shell limiter is configured correctly"""
        from cellsistant import shell_limiter

        assert shell_limiter.max_per_minute == 10
        assert shell_limiter.max_per_hour == 100
