"""
Chat utilities for AI Agent.

This module contains shared logic for chat handlers.
"""

from typing import Any

import aiohttp

from cellsistant.prompts import build_system_prompt
from cellsistant.retry import RetryConfig, call_openrouter_with_retry
from cellsistant.settings import load_settings
from cellsistant.tools_definitions import TOOL_DEFINITIONS


def get_api_settings() -> dict:
    """Load and return API settings."""
    settings = load_settings()
    return {
        "base_url": settings.get("base_url", "https://openrouter.ai/api/v1").rstrip("/"),
        "api_key": settings.get("api_key", ""),
        "model": settings.get("model", "google/gemini-2.0-flash:free"),
        "temperature": settings.get("temperature", 0.3),
        "max_tokens": settings.get("max_tokens", 0),
        "custom_prompt": settings.get("custom_system_prompt", ""),
        "enabled_categories": settings.get("enabled_tool_categories", {
            "notebook": True,
            "files": True,
            "shell": True,
            "packages": True,
            "search": True,
        }),
    }


def build_messages(
    messages: list[dict[str, Any]],
    custom_prompt: str,
    enabled_categories: dict | None = None,
) -> list[dict[str, Any]]:
    """Build full message list with dynamic system prompt based on enabled categories."""
    system = build_system_prompt(custom_prompt=custom_prompt, enabled_categories=enabled_categories)
    return [system] + messages


def build_payload(
    model: str,
    messages: list[dict[str, Any]],
    temperature: float,
    max_tokens: int,
    stream: bool = False,
) -> dict[str, Any]:
    """Build API payload."""
    payload = {
        "model": model,
        "messages": messages,
        "tools": TOOL_DEFINITIONS,
        "tool_choice": "auto",
        "temperature": temperature,
    }
    if max_tokens > 0:
        payload["max_tokens"] = max_tokens
    if stream:
        payload["stream"] = True
    return payload


async def call_api(
    url: str,
    headers: dict[str, str],
    payload: dict[str, Any],
    use_stream: bool = False,
    use_retry: bool = True,
) -> dict[str, Any] | None:
    """Call OpenRouter API with or without streaming."""
    if use_stream:
        return None
    elif use_retry:
        return await call_openrouter_with_retry(
            url=url,
            headers=headers,
            payload=payload,
            config=RetryConfig(max_retries=3, base_delay=1.0),
        )
    else:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, headers=headers) as resp:
                if resp.status != 200:
                    error_body = await resp.text()
                    raise Exception(f"API error {resp.status}: {error_body}")
                return await resp.json()
