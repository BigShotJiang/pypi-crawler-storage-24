"""
Модуль управления настройками AI Agent.

Профили моделей:
- profiles: список профилей с base_url, api_key, model, temperature
- active_profile_id: ID активного профиля

Настройки хранятся в ~/.jupyterlab-ai-agent/settings.json
"""

import json
import time
import uuid
from pathlib import Path
from typing import Any, Dict

import aiohttp
import tornado.web
from jupyter_server.base.handlers import APIHandler


CONFIG_DIR = Path.home() / ".jupyterlab-ai-agent"
SETTINGS_FILE = CONFIG_DIR / "settings.json"

DEFAULT_PROFILE = {
    "id": "default",
    "name": "Default",
    "base_url": "https://openrouter.ai/api/v1",
    "model": "google/gemini-2.0-flash:free",
    "temperature": 0.3,
    "max_tokens": 0,
}


def load_settings() -> Dict[str, Any]:
    """Загрузить settings.json"""
    if SETTINGS_FILE.exists():
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_settings(settings: Dict[str, Any]):
    """Сохранить settings.json"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, ensure_ascii=False, indent=2)


def ensure_profiles(settings: Dict[str, Any]) -> Dict[str, Any]:
    """Ensure profiles exist, create default if missing."""
    if "profiles" not in settings or not settings["profiles"]:
        settings["profiles"] = [DEFAULT_PROFILE.copy()]
        settings["active_profile_id"] = "default"
    return settings


def get_active_profile(settings: Dict[str, Any]) -> Dict[str, Any]:
    """Return active profile settings."""
    settings = ensure_profiles(settings)
    active_id = settings.get("active_profile_id", "default")
    for p in settings.get("profiles", []):
        if p.get("id") == active_id:
            return p
    return settings["profiles"][0] if settings["profiles"] else DEFAULT_PROFILE.copy()


def get_profile_by_id(settings: Dict[str, Any], profile_id: str) -> Dict[str, Any]:
    """Return profile by ID or active profile if not found."""
    for p in settings.get("profiles", []):
        if p.get("id") == profile_id:
            return p
    return get_active_profile(settings)


def mask_api_key(api_key: str) -> str | None:
    """Mask API key, showing only last 4 characters."""
    if not api_key:
        return None
    if len(api_key) > 8:
        return f"{'*' * (len(api_key) - 4)}{api_key[-4:]}"
    return "****"


class SettingsGetHandler(APIHandler):
    """GET /ai-agent/settings — получить текущие настройки"""

    @tornado.web.authenticated
    async def get(self):
        try:
            settings = load_settings()
            settings = ensure_profiles(settings)

            # Маскируем API ключи в профилях
            profiles = []
            for p in settings.get("profiles", []):
                profile_copy = p.copy()
                profile_copy["api_key"] = mask_api_key(p.get("api_key", ""))
                profiles.append(profile_copy)

            # Image analysis defaults
            img_analysis = settings.get("image_analysis", {})
            default_img = {
                "enabled": True,
                "auto_suggest": True,
                "use_active_profile": True,
                "profile_id": None,
                "custom_prompt": "",
            }
            for key, value in default_img.items():
                if key not in img_analysis:
                    img_analysis[key] = value

            self.finish(
                {
                    "profiles": profiles,
                    "active_profile_id": settings.get("active_profile_id", "default"),
                    "auto_execute_tools": settings.get("auto_execute_tools", True),
                    "include_variables": settings.get("include_variables", True),
                    "include_cell_outline": settings.get("include_cell_outline", True),
                    "max_agent_iterations": settings.get("max_agent_iterations", 15),
                    "enabled_tool_categories": settings.get(
                        "enabled_tool_categories",
                        {
                            "notebook": True,
                            "files": True,
                            "shell": True,
                            "packages": True,
                            "search": True,
                        }
                    ),
                    "custom_system_prompt": settings.get("custom_system_prompt", ""),
                    "image_analysis": img_analysis,
                }
            )

        except Exception as e:
            self.set_status(500)
            self.finish({"error": str(e)})


class SettingsUpdateHandler(APIHandler):
    """POST /ai-agent/settings — обновить настройки"""

    @tornado.web.authenticated
    async def post(self):
        try:
            data = self.get_json_body()
            settings = load_settings()
            settings = ensure_profiles(settings)

            # Обновляем profiles
            if "profiles" in data:
                profiles_data = data["profiles"]
                if not isinstance(profiles_data, list):
                    self.set_status(400)
                    self.finish({"error": "profiles must be an array"})
                    return

                validated_profiles = []
                existing_ids = set()
                for p in profiles_data:
                    if not isinstance(p, dict):
                        continue
                    profile_id = p.get("id")
                    if not profile_id:
                        profile_id = str(uuid.uuid4())

                    # Validate temperature
                    temp = float(p.get("temperature", 0.3))
                    if not (0 <= temp <= 2):
                        self.set_status(400)
                        self.finish({"error": f"Temperature must be between 0 and 2 in profile {profile_id}"})
                        return

                    validated_profile = {
                        "id": profile_id,
                        "name": str(p.get("name", "Unnamed")),
                        "base_url": str(p.get("base_url", "https://openrouter.ai/api/v1")).rstrip("/"),
                        "model": str(p.get("model", "google/gemini-2.0-flash:free")),
                        "temperature": temp,
                        "max_tokens": int(p.get("max_tokens", 0)),
                    }

                    # API key: only update if provided and not masked
                    api_key = p.get("api_key")
                    if api_key and not api_key.startswith("*"):
                        validated_profile["api_key"] = str(api_key)
                    elif profile_id in [ep.get("id") for ep in settings.get("profiles", [])]:
                        for ep in settings.get("profiles", []):
                            if ep.get("id") == profile_id and "api_key" in ep:
                                validated_profile["api_key"] = ep["api_key"]
                                break

                    validated_profiles.append(validated_profile)
                    existing_ids.add(profile_id)

                settings["profiles"] = validated_profiles

            # Обновляем active_profile_id
            if "active_profile_id" in data:
                active_id = str(data["active_profile_id"])
                profile_ids = [p.get("id") for p in settings.get("profiles", [])]
                if active_id in profile_ids:
                    settings["active_profile_id"] = active_id
                else:
                    self.set_status(400)
                    self.finish({"error": f"Profile {active_id} not found"})
                    return

            # Обновляем auto_execute_tools
            if "auto_execute_tools" in data:
                settings["auto_execute_tools"] = bool(data["auto_execute_tools"])

            # Обновляем include_variables
            if "include_variables" in data:
                settings["include_variables"] = bool(data["include_variables"])

            # Обновляем include_cell_outline
            if "include_cell_outline" in data:
                settings["include_cell_outline"] = bool(data["include_cell_outline"])

            # Обновляем max_agent_iterations
            if "max_agent_iterations" in data:
                iterations = int(data["max_agent_iterations"])
                if not (1 <= iterations <= 50):
                    self.set_status(400)
                    self.finish({"error": "max_agent_iterations must be between 1 and 50"})
                    return
                settings["max_agent_iterations"] = iterations

            # Обновляем enabled_tool_categories
            if "enabled_tool_categories" in data:
                valid_categories = ["notebook", "files", "shell", "packages", "search"]
                cats = data["enabled_tool_categories"]
                if not isinstance(cats, dict):
                    self.set_status(400)
                    self.finish({"error": "enabled_tool_categories must be an object"})
                    return
                validated_cats = {}
                for cat in valid_categories:
                    validated_cats[cat] = bool(cats.get(cat, True))
                settings["enabled_tool_categories"] = validated_cats

            # Обновляем custom_system_prompt
            if "custom_system_prompt" in data:
                settings["custom_system_prompt"] = str(data["custom_system_prompt"])

            # Обновляем image_analysis
            if "image_analysis" in data:
                img_settings = data["image_analysis"]
                if not isinstance(img_settings, dict):
                    self.set_status(400)
                    self.finish({"error": "image_analysis must be an object"})
                    return

                validated_img = {
                    "enabled": bool(img_settings.get("enabled", True)),
                    "auto_suggest": bool(img_settings.get("auto_suggest", True)),
                    "use_active_profile": bool(img_settings.get("use_active_profile", True)),
                    "profile_id": img_settings.get("profile_id"),
                    "custom_prompt": str(img_settings.get("custom_prompt", "")),
                }
                settings["image_analysis"] = validated_img

            # Сохраняем
            save_settings(settings)
            self.finish({"message": "Settings updated", "restart_required": False})

        except Exception as e:
            self.set_status(500)
            self.finish({"error": str(e)})


class SettingsTestHandler(APIHandler):
    """POST /ai-agent/settings/test — проверить подключение к API"""

    @tornado.web.authenticated
    async def post(self):
        try:
            data = self.get_json_body()
            settings = load_settings()

            # Get profile for testing
            profile_id = data.get("profile_id")
            if profile_id:
                profile = get_profile_by_id(settings, profile_id)
            else:
                # Use parameters directly if provided
                profile = {
                    "base_url": data.get("base_url", "").rstrip("/") or None,
                    "model": data.get("model"),
                    "api_key": data.get("api_key"),
                }
                # Fall back to active profile if params not provided
                if not profile.get("base_url"):
                    active = get_active_profile(settings)
                    profile = active.copy()
                    # Override with provided params
                    if data.get("base_url"):
                        profile["base_url"] = str(data["base_url"]).rstrip("/")
                    if data.get("model"):
                        profile["model"] = str(data["model"])
                    if data.get("api_key"):
                        profile["api_key"] = str(data["api_key"])

            base_url = profile.get("base_url", "https://openrouter.ai/api/v1")
            model = profile.get("model", "google/gemini-2.0-flash:free")
            api_key = profile.get("api_key", "")

            # Тестовый запрос
            url = f"{base_url}/chat/completions"
            headers = {
                "Content-Type": "application/json",
            }

            if api_key:
                headers["Authorization"] = f"Bearer {api_key}"

            payload = {
                "model": model,
                "messages": [{"role": "user", "content": "Say 'ok'"}],
                "max_tokens": 5,
            }

            start_time = time.time()

            async with (
                aiohttp.ClientSession() as session,
                session.post(
                    url,
                    json=payload,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp,
            ):
                elapsed = time.time() - start_time

                if resp.status == 200:
                    result = await resp.json()
                    response_text = (
                        result.get("choices", [{}])[0]
                        .get("message", {})
                        .get("content", "")
                    )
                    self.finish(
                        {
                            "success": True,
                            "response": response_text,
                            "latency_ms": round(elapsed * 1000),
                            "model_used": result.get("model", model),
                        }
                    )
                else:
                    error_body = await resp.text()
                    self.finish(
                        {
                            "success": False,
                            "error": f"HTTP {resp.status}: {error_body[:500]}",
                            "latency_ms": round(elapsed * 1000),
                        }
                    )

        except Exception as e:
            self.finish({"success": False, "error": str(e)})
