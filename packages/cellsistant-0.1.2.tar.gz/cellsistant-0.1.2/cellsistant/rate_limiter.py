"""
Простой rate limiter для защиты от чрезмерного использования API.
Использует алгоритм token bucket (скользящее окно).
"""

import time
from collections import deque
from typing import Optional, Tuple


class RateLimiter:
    """
    Rate limiter на основе скользящего окна.
    Поддерживает два лимита: в минуту и в час.
    """

    def __init__(
        self,
        max_requests_per_minute: int = 30,
        max_requests_per_hour: int = 500,
    ):
        """
        Инициализировать rate limiter.

        Args:
            max_requests_per_minute: Максимум запросов в минуту
            max_requests_per_hour: Максимум запросов в час
        """
        self.max_per_minute = max_requests_per_minute
        self.max_per_hour = max_requests_per_hour
        self.minute_window: deque = deque()
        self.hour_window: deque = deque()

    def check(self) -> Tuple[bool, Optional[str]]:
        """
        Проверить, разрешён ли запрос.

        Returns:
            (allowed, error_message): True если запрос разрешён,
                                      False с сообщением об ошибке если превышен лимит
        """
        now = time.time()

        # Очищаем старые записи за пределами окна
        while self.minute_window and self.minute_window[0] < now - 60:
            self.minute_window.popleft()

        while self.hour_window and self.hour_window[0] < now - 3600:
            self.hour_window.popleft()

        # Проверяем лимиты
        if len(self.minute_window) >= self.max_per_minute:
            wait = 60 - (now - self.minute_window[0])
            return (
                False,
                f"Rate limit: {self.max_per_minute}/min exceeded. Wait {wait:.0f}s.",
            )

        if len(self.hour_window) >= self.max_per_hour:
            wait = 3600 - (now - self.hour_window[0])
            return (
                False,
                f"Rate limit: {self.max_per_hour}/hour exceeded. Wait {wait / 60:.0f}min.",
            )

        return True, None

    def record(self):
        """Записать использование (вызывать после успешного check())"""
        now = time.time()
        self.minute_window.append(now)
        self.hour_window.append(now)

    def get_usage(self) -> dict:
        """
        Получить текущее использование.

        Returns:
            dict с информацией об использовании
        """
        now = time.time()

        # Очищаем старые записи
        while self.minute_window and self.minute_window[0] < now - 60:
            self.minute_window.popleft()
        while self.hour_window and self.hour_window[0] < now - 3600:
            self.hour_window.popleft()

        return {
            "minute": {"used": len(self.minute_window), "limit": self.max_per_minute},
            "hour": {"used": len(self.hour_window), "limit": self.max_per_hour},
        }

    def reset(self):
        """Сбросить счётчики (для тестов)"""
        self.minute_window.clear()
        self.hour_window.clear()


# Глобальные лимитеры для разных типов запросов
# Chat — более мягкие лимиты (пользовательский интерфейс)
chat_limiter = RateLimiter(max_requests_per_minute=30, max_requests_per_hour=500)

# Shell — более строгие лимиты (потенциально опасные операции)
shell_limiter = RateLimiter(max_requests_per_minute=10, max_requests_per_hour=100)
