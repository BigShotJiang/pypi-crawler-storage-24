# AGENTS.md

Coding agent instructions for the cellsistant repository.

## Project Overview

Cellsistant is a JupyterLab extension providing an AI Agent sidebar panel. It's a hybrid Python/TypeScript project:

- **Python backend**: Jupyter server extension (`cellsistant/`) handling AI chat, shell execution, file operations
- **TypeScript frontend**: JupyterLab extension (`src/`) with React-based UI

## Build Commands

### TypeScript/Frontend

```bash
npm run build           # Development build with source maps
npm run build:prod      # Production build
npm run clean           # Clean build artifacts
npm run watch           # Watch mode for development
```

### Python/Backend

```bash
pip install -e .        # Install in editable mode
pip install build       # Build package
python -m build         # Create distribution
```

### Full Extension Installation

```bash
pip install -e .        # Install Python package (triggers npm build)
jupyter labextension develop --overwrite .  # Develop mode
```

## Test Commands

### Python Tests (pytest)

```bash
pytest                                      # Run all Python tests
pytest cellsistant/tests/                   # Run all tests in directory
pytest cellsistant/tests/test_rate_limiter.py   # Run single test file
pytest cellsistant/tests/test_rate_limiter.py::TestRateLimiter::test_init_default_values  # Single test
pytest -v --tb=short                        # Verbose with short traceback
pytest -k "rate"                            # Run tests matching pattern
pytest --coverage                           # With coverage (via jest for TS)
```

### TypeScript Tests (Jest)

```bash
npm test                                    # Run all TypeScript tests
npm test -- --testPathPattern=file-tools    # Run specific test file
npm test -- --testNamePattern="read_file"   # Run tests matching name
npx jest src/__tests__/file-tools.spec.ts   # Run single test file
npx jest --coverage                         # With coverage report
```

## Lint Commands

### Python (Ruff)

```bash
npm run lint:python        # Check Python lint (ruff check)
npm run lint:python:fix    # Auto-fix Python lint issues
npm run format:python      # Format Python code (ruff format)
ruff check cellsistant/    # Direct ruff check
ruff check --fix cellsistant/  # Direct ruff fix
ruff format cellsistant/   # Direct ruff format
```

### TypeScript/JavaScript

```bash
npm run lint               # Run all linting (stylelint + prettier + eslint) with fixes
npm run lint:check         # Check linting without fixing
npm run eslint             # ESLint with auto-fix
npm run eslint:check       # ESLint check only
npm run prettier           # Format with Prettier
npm run prettier:check     # Check Prettier formatting
npm run stylelint          # Lint CSS with fixes
npm run stylelint:check    # Check CSS lint
```

### All-in-One

```bash
npm run lint:all           # Lint Python + TypeScript with fixes
npm run lint:all:check     # Check all linting without fixes
```

## Code Style Guidelines

### Python Style

**Formatting (Ruff):**

- Line length: 88 characters
- Use double quotes for strings
- Indent with 4 spaces
- Unix line endings (LF)

**Imports:**

- Standard library imports first
- Third-party imports second
- Local imports last (from cellsistant...)
- 2 blank lines after imports
- Use absolute imports: `from cellsistant.module import Class`

**Naming:**

- Functions/variables: `snake_case`
- Classes: `PascalCase`
- Constants: `UPPER_SNAKE_CASE`
- Private: `_leading_underscore`
- Test classes: `TestClass`, test methods: `test_function_name`

**Type Hints:**

- Use Python 3.9+ syntax: `list[dict]` not `List[Dict]`
- Use `Any` sparingly, prefer specific types
- Return types: `-> dict[str, Any]` or `-> None`

**Error Handling:**

- Use specific exception types
- Include context in error messages: `f"Error: {e!s}"`
- Re-raise with `raise ... from e` when appropriate

**Docstrings:**

- Triple double quotes: `"""Docstring."""`
- First line: brief summary
- Use for modules, classes, public functions

### TypeScript Style

**Formatting (Prettier):**

- Single quotes for strings
- No trailing commas
- Arrow parens: avoid for single param
- 2-space indentation
- End of line: auto

**Imports:**

- External imports first (`@jupyterlab/...`)
- Internal imports second (`../module`)
- One import per module, sorted alphabetically
- Use named imports: `import { Foo, Bar } from 'module'`

**Naming:**

- Variables/functions: `camelCase`
- Classes/interfaces: `PascalCase`
- Interfaces: `IFoo` (I prefix required by ESLint)
- Constants: `UPPER_SNAKE_CASE` or `camelCase`
- Private members: `_leadingUnderscore`

**Types:**

- Prefer interfaces over type aliases for objects
- Use `unknown` over `any` when possible
- Avoid `any` - use `unknown` with type guards
- Return types: explicit for public functions

**Error Handling:**

- Return `{ success: false, error: 'message' }` pattern
- Use try-catch with specific error handling
- Log errors with `console.error()` or `console.warn()`

**Comments:**

- Use JSDoc for public APIs: `/** Description */`
- Use Cyrillic comments acceptable in this codebase
- Section headers: `// ═════════════════════════════════`

## Project Structure

```
cellsistant/
├── __init__.py          # Main server extension, handlers
├── _version.py          # Auto-generated version
├── chat_utils.py        # Shared chat utilities
├── history.py           # Chat history management
├── prompts.py           # System prompt builders
├── rate_limiter.py      # API rate limiting
├── retry.py             # API retry logic
├── settings.py          # Settings management
├── tools_definitions.py # Tool definitions for AI
└── tests/               # Python tests
    ├── test_history.py
    ├── test_rate_limiter.py
    ├── test_retry.py
    ├── test_settings.py
    └── test_shell.py

src/
├── index.ts             # Extension entry point
├── chat-panel.ts        # Main chat panel widget
├── chat-ui.ts           # Chat UI components
├── api.ts               # API client
├── tools.ts             # Tool interfaces
├── tool-registry.ts     # Tool registry
├── tool-validator.ts    # Tool validation
├── jupyter-service.ts   # JupyterLab service layer
├── settings-api.ts      # Settings API client
├── history-api.ts       # History API client
├── token-counter.ts     # Token counting
├── permission-manager.ts # Tool permission handling
├── context-collector.ts # Context gathering
├── variable-inspector.ts # Variable inspection
└── tools/
    ├── notebook-tools.ts
    ├── file-tools.ts
    ├── search-tools.ts
    ├── shell-tools.ts
    └── package-tools.ts
```

## Key Patterns

### Tool Definition Pattern (TypeScript)

```typescript
const tool: ITool = {
  name: 'tool_name',
  safetyLevel: ToolSafetyLevel.READ,
  category: 'files',
  description: 'Description for AI',
  parameters: {
    type: 'object',
    properties: {
      path: { type: 'string', description: 'File path' }
    },
    required: ['path']
  },
  async execute(args: Record<string, unknown>): Promise<IToolResult> {
    // Implementation
    return { success: true, result: data };
  }
};
```

### Handler Pattern (Python)

```python
class MyHandler(APIHandler):
    def check_xsrf_cookie(self):
        pass

    @tornado.web.authenticated
    async def post(self):
        try:
            data = self.get_json_body()
            # Process
            self.finish({"success": True, "data": result})
        except Exception as e:
            self.set_status(500)
            self.finish({"error": f"Error: {e!s}"})
```

### Result Pattern

Both Python and TypeScript use consistent result objects:

```typescript
{ success: true, result: data }
{ success: false, error: "error message" }
```

## Testing Conventions

### Python Tests

- Use pytest with class-based organization
- Test class names: `TestClassUnderTest`
- Test method names: `test_specific_behavior`
- Use docstrings for test descriptions
- One assertion concept per test

### TypeScript Tests

- Jest with `*.spec.ts` files in `src/__tests__/`
- Describe blocks: `describe('ClassName', () => {})`
- Test names: `it('should do something', () => {})`
- Use `expect()` assertions

## Important Notes

- Always run `npm run lint:all:check` before committing
- Always run `pytest` and `npm test` before committing
- Never commit to `cellsistant/_version.py` (auto-generated)
- Never commit API keys or secrets
- Use `workdir` parameter for Bash commands, not `cd`
- The codebase contains Cyrillic comments - these are intentional
