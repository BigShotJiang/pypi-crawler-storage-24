# API Reference

Technical reference for Cellsistant settings and configuration.

## Settings

### API Configuration

| Setting    | Description      | Default                     |
| ---------- | ---------------- | --------------------------- |
| `api_key`  | Your API key     | Required                    |
| `base_url` | API endpoint URL | `https://api.openai.com/v1` |
| `model`    | Model to use     | `gpt-4o-mini`               |

### Model Options

For OpenAI-compatible APIs, you can configure:

- **Model name**: Any model supported by your provider
- **Temperature**: Response creativity (0.0-2.0)
- **Max tokens**: Maximum response length

### Safety Settings

| Setting                  | Description                            |
| ------------------------ | -------------------------------------- |
| Block dangerous commands | Prevents system-destructive operations |
| Confirm before execution | Review AI actions before running       |
| Ask mode by default      | Start in read-only mode                |

## Environment Variables

```bash
OPENAI_API_KEY=your-api-key
OPENAI_BASE_URL=https://api.openai.com/v1  # Optional
CELLSISTANT_MODEL=gpt-4o-mini  # Optional
```

## API Endpoints (Backend)

### Chat

```
POST /cellsistant/chat
```

Send a message to the AI and receive a response.

**Request:**

```json
{
  "message": "string",
  "mode": "agent" | "ask",
  "context": {}
}
```

**Response:**

```json
{
  "success": true,
  "response": "string",
  "actions": []
}
```

### Tools

```
POST /cellsistant/tools/execute
```

Execute a tool action (read file, run code, etc.).

```
GET /cellsistant/tools/definitions
```

Get available tool definitions.

### Settings

```
GET /cellsistant/settings
POST /cellsistant/settings
```

Get or update extension settings.

### History

```
GET /cellsistant/history
POST /cellsistant/history/clear
```

Manage chat history.

## Rate Limits

Rate limiting is applied per API key to prevent overuse. Limits vary by provider.

---

For implementation details, see the source code in `cellsistant/`.
