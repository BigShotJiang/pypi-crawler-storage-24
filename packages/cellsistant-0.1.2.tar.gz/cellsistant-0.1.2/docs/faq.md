# FAQ

Frequently asked questions about Cellsistant.

## General

### What is Cellsistant?

Cellsistant is an AI assistant that integrates directly into JupyterLab, helping you write code, analyze data, and manage files through a natural chat interface.

### Is Cellsistant free to use?

Cellsistant is free to install and use. However, you need an API key for the AI model. Most providers (OpenAI, Anthropic, etc.) have their own pricing.

### What AI models does Cellsistant support?

Cellsistant works with any OpenAI-compatible API, including OpenAI, Anthropic, Azure OpenAI, Ollama, and LM Studio.

## Installation

### Why isn't the extension appearing?

1. Restart JupyterLab completely
2. Clear your browser cache
3. Ensure you have JupyterLab 4.x
4. Check the JupyterLab console for errors

### Can I use Cellsistant with Jupyter Notebook (not Lab)?

Currently, Cellsistant is designed for JupyterLab. Classic Notebook support is not available.

### How do I update Cellsistant?

```bash
pip install --upgrade cellsistant
```

## Usage

### What's the difference between Agent and Ask mode?

- **Agent Mode**: AI can read, write, execute code, and run commands
- **Ask Mode**: AI can only read and analyze — no modifications

Use Agent mode for automation, Ask mode for learning and exploration.

### Can the AI access my files?

Yes, in Agent mode. The AI can read and write files in your workspace. Always review requests before approving.

### Can I undo actions?

Currently, Cellsistant doesn't have an undo feature. Use version control (git) for important changes.

## Safety

### Is it safe to let the AI run commands?

Cellsistant blocks dangerous commands automatically:

- `rm -rf /`, `rm -rf *`
- `shutdown`, `halt`, `reboot`
- Network attack tools

Review each action before approving. When in doubt, use Ask mode.

### Does Cellsistant send my code anywhere?

Cellsistant only sends data to the AI API you configure. Your code is processed by your chosen AI provider.

## Troubleshooting

### API errors

1. Verify your API key is correct
2. Check your API key has sufficient credits
3. Ensure the base URL is correct for your provider

### Slow responses

AI response times depend on:

- Model complexity
- Server load
- Your internet connection

### Installation fails

```bash
pip install --upgrade pip setuptools wheel
pip install cellsistant
```

## Still Have Questions?

Open an issue on [GitHub](https://github.com/p4ulbr4dl3y/cellsistant/issues).
