# Changelog

All notable changes to Cellsistant are documented here.

## [Unreleased]

### Added

- Cellsistant AI assistant extension for JupyterLab
- Notebook tools: create, execute, update, delete cells
- File tools: read, write, list, create, delete files
- Search tools: find and replace across cells
- Python package management: install via pip/conda
- Shell command execution with safety checks
- AI Vision for image and chart analysis
- Agent and Ask modes

## Version History

### v0.1.0 (Initial Release)

- Basic chat interface
- Notebook cell operations
- File read/write operations
- Shell command execution
- OpenAI API integration

---

For full release notes, visit the [GitHub Releases](https://github.com/p4ulbr4dl3y/cellsistant/releases) page.
