# Getting Started

Welcome to Cellsistant! This guide will help you get started with your new AI assistant in JupyterLab.

## Opening Cellsistant

1. Look for the Cellsistant icon in the JupyterLab sidebar
2. Click it to open the chat panel
3. If you don't see it, go to **View → Left Sidebar** and enable Cellsistant

## Your First Conversation

1. **Type your question** in the chat input
2. Press **Enter** or click **Send**
3. The AI will respond and can execute actions

### Example Prompts

```
"Create a new code cell that imports pandas"
"Analyze this dataset and create a visualization"
"Read the file data.csv and show me its structure"
"Run git status to check my repository"
```

## Modes

Cellsistant has two operating modes:

### Agent Mode

In Agent mode, the AI can:

- Read files and notebooks
- Write and modify code
- Execute Python code
- Run shell commands
- Create and delete files

**Best for:** Complex tasks, code generation, automation

### Ask Mode

In Ask mode, the AI can:

- Read files and notebooks
- Analyze code and data
- Answer questions
- Explain concepts

**Best for:** Learning, debugging, understanding code

**Switch modes** using the toggle in the chat header.

## Working with the Notebook

The AI can interact with your Jupyter notebook:

| Action       | Example                                   |
| ------------ | ----------------------------------------- |
| Create cell  | "Add a markdown cell explaining the data" |
| Execute code | "Run this cell to load the data"          |
| Get output   | "Show me the plot from the last cell"     |
| Update cell  | "Modify cell 5 to use groupby instead"    |

## Safety Features

Cellsistant blocks dangerous commands to protect your system:

- `rm -rf /`, `rm -rf *` — blocked
- `shutdown`, `halt`, `reboot` — blocked
- Network attacks (`nc`, `ncat`) — blocked

You can always review what the AI is about to do before it executes.

## Next Steps

- Learn about [Features](./features.md)
- Try [Notebook Workflow Tutorial](./tutorials/notebook-workflow.md)
- Check the [FAQ](./faq.md) for common questions
