# Installation Guide

## Requirements

- **Python**: 3.9 or higher
- **JupyterLab**: 4.x
- **OpenAI-compatible API**: OpenAI, Anthropic, local models, etc.

## Quick Install

### Step 1: Install the Extension

```bash
pip install cellsistant
```

### Step 2: Configure API Key

1. Open JupyterLab
2. Navigate to **Settings → Cellsistant**
3. Enter your API key and base URL

Alternatively, set environment variables:

```bash
export OPENAI_API_KEY="your-api-key"
export OPENAI_BASE_URL="https://api.openai.com/v1"  # Optional, for custom endpoints
```

### Step 3: Restart JupyterLab

```bash
jupyter lab
```

The Cellsistant sidebar panel will appear in JupyterLab.

## Installation from Source

For development or latest features:

```bash
git clone https://github.com/p4ulbr4dl3y/cellsistant.git
cd cellsistant
pip install -e .
jupyter labextension develop --overwrite .
```

## Supported API Providers

Cellsistant works with any OpenAI-compatible API:

| Provider       | Base URL                                   |
| -------------- | ------------------------------------------ |
| OpenAI         | `https://api.openai.com/v1`                |
| Azure OpenAI   | `https://{your-resource}.openai.azure.com` |
| Anthropic      | `https://api.anthropic.com`                |
| Local (Ollama) | `http://localhost:11434/v1`                |
| LM Studio      | `http://localhost:1234/v1`                 |

## Troubleshooting

### Extension Not Appearing

1. Restart JupyterLab completely
2. Clear browser cache
3. Check JupyterLab console for errors

### API Errors

- Verify your API key is correct
- Check your API key has sufficient credits
- Ensure the base URL matches your provider

### Installation Fails

```bash
pip install --upgrade pip
pip install cellsistant
```

For more help, report issues at [GitHub Issues](https://github.com/p4ulbr4dl3y/cellsistant/issues).
