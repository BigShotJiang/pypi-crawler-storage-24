# Features

Cellsistant provides a comprehensive set of tools for working with Jupyter notebooks, files, and your development environment.

## Notebook Tools

| Feature       | Description                          |
| ------------- | ------------------------------------ |
| Create cells  | Add code or Markdown cells           |
| Execute cells | Run code and display results         |
| Get output    | Retrieve text, plots, HTML output    |
| Update cells  | Modify existing cell content         |
| Delete cells  | Remove cells from notebook           |
| AI Vision     | Analyze images and charts            |
| Search cells  | Find text across all cells           |
| Replace text  | Find and replace with backreferences |

## File Tools

| Feature          | Description                             |
| ---------------- | --------------------------------------- |
| Read files       | `.py`, `.json`, `.csv`, `.md`, and more |
| Write files      | Create or overwrite files               |
| List directories | View folder contents                    |
| Create notebooks | New `.ipynb` files                      |
| Rename files     | Rename files and folders                |
| Delete files     | Remove files safely                     |

## Search Tools

| Feature                     | Description                         |
| --------------------------- | ----------------------------------- |
| Search patterns             | Find text across notebook cells     |
| Replace with backreferences | Use captured groups in replacements |

## Python Packages

| Feature          | Description                 |
| ---------------- | --------------------------- |
| Install packages | Via `pip` or `conda`        |
| List installed   | View all installed packages |

## Shell Commands

Execute shell commands directly from the chat:

```bash
git status
ls -la
grep -r "pattern" .
```

> **Safety:** Dangerous commands are automatically blocked.
