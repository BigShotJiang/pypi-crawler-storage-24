# Cellsistant Documentation

Welcome to the Cellsistant documentation!

## Getting Started

- [Installation Guide](./installation.md) — Install and configure Cellsistant
- [Getting Started](./getting-started.md) — Your first steps with Cellsistant

## Features

- [Features Overview](./features.md) — Complete feature list

## Tutorials

- [Notebook Workflow](./tutorials/notebook-workflow.md) — Working with notebooks
- [File Management](./tutorials/file-management.md) — Managing files
- [Code Analysis](./tutorials/code-analysis.md) — Analyzing code

## Reference

- [FAQ](./faq.md) — Common questions
- [Changelog](./changelog.md) — Version history
- [API Reference](./api.md) — Technical reference

---

## Quick Links

- [GitHub Repository](https://github.com/p4ulbr4dl3y/cellsistant)
- [Issue Tracker](https://github.com/p4ulbr4dl3y/cellsistant/issues)
- [PyPI Package](https://pypi.org/project/cellsistant/)
