#!/bin/bash
#
# Скрипт для запуска всех тестов проекта jupyterlab-ai-agent
#

set -e

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Переход в директорию проекта
cd "$(dirname "$0")"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Запуск тестов jupyterlab-ai-agent${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Счётчики
TS_PASSED=0
TS_FAILED=0
PY_PASSED=0
PY_FAILED=0

# 1. TypeScript тесты
echo -e "${YELLOW}[1/2] Запуск TypeScript тестов...${NC}"
if npm run test 2>&1 | tee /tmp/ts-test-output.txt | grep -q "Test Suites:.*passed"; then
    TS_RESULT=$(grep "Test Suites:" /tmp/ts-test-output.txt | tail -1)
    TS_TESTS=$(grep "Tests:" /tmp/ts-test-output.txt | tail -1)
    echo -e "${GREEN}✓ TypeScript тесты завершены${NC}"
    echo -e "  $TS_RESULT"
    echo -e "  $TS_TESTS"
    TS_PASSED=1
else
    echo -e "${RED}✗ TypeScript тесты провалились${NC}"
    TS_FAILED=1
fi
echo ""

# 2. Python тесты
echo -e "${YELLOW}[2/2] Запуск Python тестов...${NC}"
if [ -d "venv" ]; then
    source venv/bin/activate
elif command -v python3 &> /dev/null; then
    python3 -m venv venv 2>/dev/null || true
    if [ -d "venv" ]; then
        source venv/bin/activate
    fi
fi

if command -v python &> /dev/null && [ -f "pyproject.toml" ]; then
    if python -m pytest cellsistant/tests/ -v --tb=short 2>&1 | tee /tmp/py-test-output.txt | grep -q "passed"; then
        PY_RESULT=$(grep "passed" /tmp/py-test-output.txt | tail -1)
        echo -e "${GREEN}✓ Python тесты завершены${NC}"
        echo -e "  $PY_RESULT"
        PY_PASSED=1
    else
        echo -e "${RED}✗ Python тесты провалились${NC}"
        PY_FAILED=1
    fi
else
    echo -e "${YELLOW}⚠ Python окружение не найдено, пропускаем${NC}"
fi
echo ""

# Итоги
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Итоги${NC}"
echo -e "${BLUE}========================================${NC}"

if [ $TS_PASSED -eq 1 ] && [ $PY_PASSED -eq 1 ]; then
    echo -e "${GREEN}✓ Все тесты прошли успешно!${NC}"
    exit 0
elif [ $TS_PASSED -eq 1 ] || [ $PY_PASSED -eq 1 ]; then
    echo -e "${YELLOW}⚠ Часть тестов провалилась${NC}"
    exit 1
else
    echo -e "${RED}✗ Все тесты провалились${NC}"
    exit 2
fi
