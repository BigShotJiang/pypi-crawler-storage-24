#!/bin/bash
set -e

VERSION=${1:-}

if [ -z "$VERSION" ]; then
    echo "Usage: ./scripts/release.sh <version>"
    echo "Example: ./scripts/release.sh 0.2.0"
    exit 1
fi

echo "=== Releasing cellsistant v${VERSION} ==="

echo "[1/5] Updating version in package.json..."
sed -i "s/\"version\": \"[0-9.]*\"/\"version\": \"${VERSION}\"/" package.json

echo "[2/5] Cleaning previous builds..."
rm -rf dist/ lib/ tsconfig.tsbuildinfo cellsistant/labextension/static/*.js

echo "[3/5] Building TypeScript..."
npm run build:lib:prod

echo "[4/5] Building labextension..."
source venv/bin/activate && python -m jupyter labextension build .

echo "[5/5] Building Python package..."
source venv/bin/activate && python -m build

echo ""
echo "=== Uploading to PyPI ==="
source venv/bin/activate && https_proxy=http://127.0.0.1:2080 http_proxy=http://127.0.0.1:2080 twine upload dist/* --config-file ~/.pypirc

echo ""
echo "=== Done! ==="
echo "Version ${VERSION} uploaded to PyPI"
echo "Don\'t forget to commit and push: git add -A && git commit -m 'Release v${VERSION}'"
