#!/bin/bash
#
# Скрипт для запуска тестов проекта jupyterlab-ai-agent
#
# Использование:
#   ./test.sh              # Запустить все тесты
#   ./test.sh ts           # Только TypeScript тесты
#   ./test.sh py           # Только Python тесты
#   ./test.sh watch        # TypeScript тесты в режиме watch
#   ./test.sh coverage     # TypeScript тесты с покрытием
#

set -e

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Переход в директорию проекта
cd "$(dirname "$0")"

show_help() {
    echo "Использование: $0 [опция]"
    echo ""
    echo "Опции:"
    echo "  (пусто)     Запустить все тесты (TypeScript + Python)"
    echo "  ts          Только TypeScript тесты"
    echo "  py          Только Python тесты"
    echo "  watch       TypeScript тесты в режиме watch (авто-перезапуск)"
    echo "  coverage    TypeScript тесты с отчётом о покрытии"
    echo "  help        Показать эту справку"
    echo ""
}

run_ts_tests() {
    echo -e "${YELLOW}[TypeScript] Запуск тестов...${NC}"
    npm run test
}

run_ts_watch() {
    echo -e "${YELLOW}[TypeScript] Запуск в режиме watch...${NC}"
    npm run watch:test 2>/dev/null || npm run test -- --watch
}

run_ts_coverage() {
    echo -e "${YELLOW}[TypeScript] Запуск с покрытием...${NC}"
    npm run test -- --coverage
}

run_py_tests() {
    echo -e "${YELLOW}[Python] Запуск тестов...${NC}"
    
    if [ -d "venv" ]; then
        source venv/bin/activate
    elif command -v python3 &> /dev/null; then
        echo -e "${BLUE}Активирую виртуальное окружение...${NC}"
    fi
    
    python -m pytest cellsistant/tests/ -v --tb=short
}

# Обработка аргументов
case "${1:-}" in
    ts)
        run_ts_tests
        ;;
    py)
        run_py_tests
        ;;
    watch)
        run_ts_watch
        ;;
    coverage)
        run_ts_coverage
        ;;
    help|-h|--help)
        show_help
        exit 0
        ;;
    "")
        # Запуск всех тестов
        echo -e "${BLUE}========================================${NC}"
        echo -e "${BLUE}  Запуск всех тестов${NC}"
        echo -e "${BLUE}========================================${NC}"
        echo ""
        
        echo -e "${YELLOW}[1/2] TypeScript тесты...${NC}"
        if npm run test --silent 2>&1 | grep -q "Test Suites:.*passed"; then
            echo -e "${GREEN}✓ TypeScript: OK${NC}"
        else
            echo -e "${RED}✗ TypeScript: FAILED${NC}"
            exit 1
        fi
        echo ""
        
        echo -e "${YELLOW}[2/2] Python тесты...${NC}"
        if [ -d "venv" ]; then
            source venv/bin/activate
        fi
        if python -m pytest cellsistant/tests/ -q 2>&1 | grep -q "passed"; then
            echo -e "${GREEN}✓ Python: OK${NC}"
        else
            echo -e "${RED}✗ Python: FAILED${NC}"
            exit 1
        fi
        echo ""
        echo -e "${GREEN}========================================${NC}"
        echo -e "${GREEN}  ✓ Все тесты прошли успешно!${NC}"
        echo -e "${GREEN}========================================${NC}"
        ;;
    *)
        echo -e "${RED}Неизвестная опция: $1${NC}"
        show_help
        exit 1
        ;;
esac
