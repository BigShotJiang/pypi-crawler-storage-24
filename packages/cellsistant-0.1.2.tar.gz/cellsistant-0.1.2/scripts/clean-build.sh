#!/bin/bash
set -e

echo "=== Остановка процессов Jupyter ==="
pkill -f jupyter || true
pkill -f ipykernel || true
sleep 1

echo "=== Очистка npm ==="
npm run clean:all

echo "=== Очистка кэша labextension ==="
rm -rf ~/.local/share/jupyter/labextensions/cellsistant
rm -rf ~/.local/share/jupyter/labextensions/@jupyterlab-examples/ai-agent
rm -rf venv/share/jupyter/labextensions/cellsistant
rm -rf venv/share/jupyter/labextensions/@jupyterlab-examples/ai-agent

echo "=== Очистка Python кэша ==="
find . -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null || true
find . -type f -name "*.pyc" -delete 2>/dev/null || true
rm -rf build dist *.egg-info 2>/dev/null || true

echo "=== Сборка ==="
source venv/bin/activate
npm run build

echo "=== Установка пакета ==="
pip install -e . --force-reinstall --no-deps

echo "=== Включение server extension ==="
jupyter server extension enable cellsistant

echo "=== Проверка установки ==="
jupyter labextension list
jupyter server extension list

echo ""
echo "=== Готово! ==="
echo "Запуск: source venv/bin/activate && jupyter lab"
