import { ITool } from './tools';

/**
 * Результат валидации
 */
export interface IValidationResult {
  valid: boolean;
  errors: string[];
  sanitizedArgs: Record<string, unknown>;
}

/**
 * Опасные shell-паттерны для проверки
 */
const DANGEROUS_SHELL_PATTERNS = [
  'rm -rf /',
  'rm -rf ~',
  'mkfs',
  'dd if=',
  ':()',
  'shutdown',
  'reboot',
  'halt',
  'poweroff'
];

/**
 * Валидатор аргументов инструментов
 */
export class ToolValidator {
  /**
   * Валидировать и санитизировать аргументы инструмента
   */
  static validate(
    tool: ITool,
    args: Record<string, unknown>
  ): IValidationResult {
    const errors: string[] = [];
    const sanitized: Record<string, unknown> = { ...args };
    const params = tool.parameters;

    // Проверяем обязательные параметры
    if (params.required) {
      for (const required of params.required) {
        if (
          !(required in args) ||
          args[required] === undefined ||
          args[required] === null
        ) {
          errors.push(`Missing required parameter: ${required}`);
        }
      }
    }

    // Валидируем типы и значения каждого параметра
    for (const [key, value] of Object.entries(args)) {
      const schema = params.properties[key];
      if (!schema) {
        // Неизвестный параметр — удаляем
        delete sanitized[key];
        continue;
      }

      // Проверяем и приводим типы
      if (schema.type === 'string' && typeof value !== 'string') {
        sanitized[key] = String(value);
      }

      if (schema.type === 'integer') {
        if (typeof value !== 'number') {
          const num = parseInt(String(value), 10);
          if (isNaN(num)) {
            errors.push(`Parameter "${key}" must be an integer`);
          } else {
            sanitized[key] = num;
          }
        } else {
          sanitized[key] = Math.floor(value);
        }
      }

      if (schema.type === 'number' && typeof value !== 'number') {
        const num = parseFloat(String(value));
        if (isNaN(num)) {
          errors.push(`Parameter "${key}" must be a number`);
        } else {
          sanitized[key] = num;
        }
      }

      if (schema.type === 'boolean' && typeof value !== 'boolean') {
        sanitized[key] = value === 'true' || value === true;
      }

      // Проверяем enum
      if (schema.enum && !schema.enum.includes(value as string)) {
        errors.push(
          `Parameter "${key}" must be one of: ${schema.enum.join(', ')}`
        );
      }

      // Специальные проверки по имени параметра
      if (key === 'path' && typeof value === 'string') {
        // Проверяем path traversal
        if (value.includes('..') || value.startsWith('/')) {
          errors.push(
            `Path "${value}" is not allowed (no .. or absolute paths)`
          );
        }
      }

      if (key === 'index' && typeof value === 'number') {
        if (value < 0) {
          errors.push('Index must be non-negative');
        }
        if (!Number.isInteger(value)) {
          errors.push('Index must be an integer');
        }
      }

      if (key === 'source' && typeof value === 'string') {
        // Ограничиваем размер source
        if (value.length > 100000) {
          errors.push(`Source too large: ${value.length} chars (max 100000)`);
        }
      }

      if (key === 'command' && typeof value === 'string') {
        // Проверяем опасные shell-паттерны
        const commandLower = value.toLowerCase();
        for (const pattern of DANGEROUS_SHELL_PATTERNS) {
          if (commandLower.includes(pattern)) {
            errors.push(`Command contains blocked pattern: "${pattern}"`);
          }
        }
      }

      if (key === 'timeout' && typeof value === 'number') {
        if (value < 0 || value > 600) {
          errors.push('Timeout must be between 0 and 600 seconds');
        }
      }
    }

    return {
      valid: errors.length === 0,
      errors,
      sanitizedArgs: sanitized
    };
  }
}
