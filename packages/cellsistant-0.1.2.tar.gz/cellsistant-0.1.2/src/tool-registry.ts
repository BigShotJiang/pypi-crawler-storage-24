import {
  ITool,
  IToolResult,
  toolParametersToFunctionDefinition
} from './tools';
import { PermissionManager } from './permission-manager';
import { ToolValidator } from './tool-validator';

/**
 * Реестр инструментов AI Agent
 */
export class ToolRegistry {
  private tools: Map<string, ITool> = new Map();
  public permissions: PermissionManager;

  constructor() {
    this.permissions = new PermissionManager();
  }

  /**
   * Зарегистрировать инструмент
   */
  register(tool: ITool): void {
    if (this.tools.has(tool.name)) {
      throw new Error(`Tool "${tool.name}" is already registered`);
    }
    this.tools.set(tool.name, tool);
  }

  /**
   * Получить инструмент по названию
   */
  get(name: string): ITool | undefined {
    return this.tools.get(name);
  }

  /**
   * Получить все зарегистрированные инструменты
   */
  getAll(): ITool[] {
    return Array.from(this.tools.values());
  }

  /**
   * Получить определения функций для OpenRouter API — только для разрешённых инструментов
   */
  getFunctionDefinitions(): unknown[] {
    return this.permissions
      .filterTools(this.getAll())
      .map(tool => toolParametersToFunctionDefinition(tool));
  }

  /**
   * Выполнить инструмент по названию с проверкой разрешений и валидацией аргументов
   */
  async execute(
    name: string,
    args: Record<string, unknown>
  ): Promise<IToolResult> {
    const tool = this.get(name);
    if (!tool) {
      return {
        success: false,
        error: `Unknown tool: ${name}`
      };
    }

    // Проверяем разрешение
    if (!this.permissions.isAllowed(tool)) {
      return {
        success: false,
        error: `Tool "${name}" is disabled. Enable category "${tool.category}" in settings.`
      };
    }

    // ★ Валидация аргументов
    const validation = ToolValidator.validate(tool, args);
    if (!validation.valid) {
      return {
        success: false,
        error: `Invalid arguments: ${validation.errors.join('; ')}`
      };
    }

    try {
      return await tool.execute(validation.sanitizedArgs);
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Включить категорию инструментов
   */
  enableCategory(category: string): void {
    this.permissions.setCategoryEnabled(category as any, true);
  }

  /**
   * Выключить категорию инструментов
   */
  disableCategory(category: string): void {
    this.permissions.setCategoryEnabled(category as any, false);
  }
}

/**
 * Глобальный экземпляр реестра
 */
export const toolRegistry = new ToolRegistry();
