import { ITool, ToolSafetyLevel, ToolCategory } from './tools';

/**
 * Конфигурация разрешений
 */
export interface IPermissionConfig {
  /** Включённые категории инструментов */
  enabledCategories: Record<ToolCategory, boolean>;
  /** Уровни, требующие подтверждения (в non-auto mode все, в auto — только эти) */
  confirmLevels: Set<ToolSafetyLevel>;
  /** Конкретные инструменты, которые ВСЕГДА запрещены */
  blockedTools: Set<string>;
  /** Конкретные инструменты, которые ВСЕГДА требуют подтверждения */
  alwaysConfirmTools: Set<string>;
}

const DEFAULT_PERMISSIONS: IPermissionConfig = {
  enabledCategories: {
    notebook: true,
    files: true,
    shell: true,
    packages: true,
    search: true
  },
  confirmLevels: new Set([ToolSafetyLevel.SYSTEM]),
  blockedTools: new Set(),
  alwaysConfirmTools: new Set(['delete_file', 'run_shell', 'delete_cell'])
};

/**
 * Менеджер разрешений для инструментов
 */
export class PermissionManager {
  private config: IPermissionConfig;

  constructor(config?: Partial<IPermissionConfig>) {
    this.config = {
      ...DEFAULT_PERMISSIONS,
      ...config,
      enabledCategories: {
        ...DEFAULT_PERMISSIONS.enabledCategories,
        ...config?.enabledCategories
      },
      confirmLevels:
        config?.confirmLevels ?? new Set(DEFAULT_PERMISSIONS.confirmLevels),
      blockedTools:
        config?.blockedTools ?? new Set(DEFAULT_PERMISSIONS.blockedTools),
      alwaysConfirmTools:
        config?.alwaysConfirmTools ??
        new Set(DEFAULT_PERMISSIONS.alwaysConfirmTools)
    };
  }

  /**
   * Обновить конфигурацию
   */
  updateConfig(updates: Partial<IPermissionConfig>): void {
    if (updates.enabledCategories) {
      this.config.enabledCategories = {
        ...this.config.enabledCategories,
        ...updates.enabledCategories
      };
    }
    if (updates.confirmLevels) {
      this.config.confirmLevels = updates.confirmLevels;
    }
    if (updates.blockedTools) {
      this.config.blockedTools = updates.blockedTools;
    }
    if (updates.alwaysConfirmTools) {
      this.config.alwaysConfirmTools = updates.alwaysConfirmTools;
    }
  }

  /**
   * Проверить, разрешён ли инструмент
   */
  isAllowed(tool: ITool): boolean {
    // Проверяем блокировку по имени
    if (this.config.blockedTools.has(tool.name)) {
      return false;
    }

    // Проверяем категорию
    if (!this.config.enabledCategories[tool.category]) {
      return false;
    }

    return true;
  }

  /**
   * Проверить, требуется ли подтверждение
   * @param autoMode — включён ли авто-режим
   */
  requiresConfirmation(tool: ITool, autoMode: boolean): boolean {
    // Если auto-mode выключен — подтверждение для всех
    if (!autoMode) {
      return true;
    }

    // alwaysConfirm на уровне инструмента
    if (tool.alwaysConfirm) {
      return true;
    }

    // alwaysConfirm в конфигурации
    if (this.config.alwaysConfirmTools.has(tool.name)) {
      return true;
    }

    // Проверяем уровень безопасности
    if (this.config.confirmLevels.has(tool.safetyLevel)) {
      return true;
    }

    return false;
  }

  /**
   * Фильтровать список инструментов — оставить только разрешённые
   */
  filterTools(tools: ITool[]): ITool[] {
    return tools.filter(tool => this.isAllowed(tool));
  }

  /**
   * Get safety level description
   */
  static getSafetyDescription(level: ToolSafetyLevel): {
    label: string;
    icon: string;
    color: string;
  } {
    switch (level) {
      case ToolSafetyLevel.READ:
        return { label: 'Read-only', icon: '👁', color: '#4caf50' };
      case ToolSafetyLevel.WRITE:
        return { label: 'Write', icon: '✏️', color: '#ff9800' };
      case ToolSafetyLevel.EXECUTE:
        return { label: 'Execute', icon: '▶️', color: '#f57c00' };
      case ToolSafetyLevel.SYSTEM:
        return { label: 'System', icon: '⚠️', color: '#f44336' };
    }
  }

  /**
   * Get confirmation CSS class by safety level
   */
  static getConfirmationClass(level: ToolSafetyLevel): string {
    switch (level) {
      case ToolSafetyLevel.READ:
        return 'confirm-read';
      case ToolSafetyLevel.WRITE:
        return 'confirm-write';
      case ToolSafetyLevel.EXECUTE:
        return 'confirm-execute';
      case ToolSafetyLevel.SYSTEM:
        return 'confirm-system';
    }
  }

  /**
   * Получить текущую конфигурацию
   */
  getConfig(): IPermissionConfig {
    return { ...this.config };
  }

  /**
   * Включить/выключить категорию инструментов
   */
  setCategoryEnabled(category: ToolCategory, enabled: boolean): void {
    this.updateConfig({
      enabledCategories: {
        ...this.config.enabledCategories,
        [category]: enabled
      }
    });
  }

  /**
   * Добавить инструмент в заблокированные
   */
  blockTool(toolName: string): void {
    const blocked = new Set(this.config.blockedTools);
    blocked.add(toolName);
    this.updateConfig({ blockedTools: blocked });
  }

  /**
   * Разблокировать инструмент
   */
  unblockTool(toolName: string): void {
    const blocked = new Set(this.config.blockedTools);
    blocked.delete(toolName);
    this.updateConfig({ blockedTools: blocked });
  }

  /**
   * Проверить, включена ли категория
   */
  isCategoryEnabled(category: ToolCategory): boolean {
    return this.config.enabledCategories[category];
  }
}
