import { ToolRegistry } from '../tool-registry';
import { ITool, IToolParameters, ToolSafetyLevel } from '../tools';

/**
 * Helper для создания тестового инструмента
 */
function createMockTool(overrides?: Partial<ITool>): ITool {
  const mockParams: IToolParameters = {
    type: 'object',
    properties: {
      arg: { type: 'string', description: 'Test argument' }
    },
    required: ['arg']
  };

  return {
    name: 'test_tool',
    description: 'Test tool',
    parameters: mockParams,
    execute: async (args: Record<string, unknown>) => ({
      success: true,
      result: args
    }),
    safetyLevel: ToolSafetyLevel.READ,
    category: 'notebook',
    ...overrides
  };
}

describe('ToolRegistry', () => {
  let registry: ToolRegistry;

  beforeEach(() => {
    registry = new ToolRegistry();
  });

  describe('register', () => {
    it('должен регистрировать новый инструмент', () => {
      const tool = createMockTool({ name: 'my_tool' });

      expect(() => registry.register(tool)).not.toThrow();
      expect(registry.get('my_tool')).toBe(tool);
    });

    it('должен выбрасывать ошибку при регистрации дубликата', () => {
      const tool = createMockTool({ name: 'duplicate_tool' });

      registry.register(tool);

      expect(() => registry.register(tool)).toThrow(
        'Tool "duplicate_tool" is already registered'
      );
    });

    it('должен регистрировать несколько инструментов', () => {
      const tool1 = createMockTool({ name: 'tool1' });
      const tool2 = createMockTool({ name: 'tool2' });
      const tool3 = createMockTool({ name: 'tool3' });

      registry.register(tool1);
      registry.register(tool2);
      registry.register(tool3);

      expect(registry.get('tool1')).toBe(tool1);
      expect(registry.get('tool2')).toBe(tool2);
      expect(registry.get('tool3')).toBe(tool3);
    });
  });

  describe('get', () => {
    it('должен возвращать зарегистрированный инструмент', () => {
      const tool = createMockTool({ name: 'retrievable_tool' });
      registry.register(tool);

      expect(registry.get('retrievable_tool')).toBe(tool);
    });

    it('должен возвращать undefined для незарегистрированного инструмента', () => {
      expect(registry.get('nonexistent_tool')).toBeUndefined();
    });
  });

  describe('getAll', () => {
    it('должен возвращать пустой массив когда нет инструментов', () => {
      expect(registry.getAll()).toEqual([]);
    });

    it('должен возвращать все зарегистрированные инструменты', () => {
      const tool1 = createMockTool({ name: 'tool1' });
      const tool2 = createMockTool({ name: 'tool2' });

      registry.register(tool1);
      registry.register(tool2);

      const all = registry.getAll();
      expect(all.length).toBe(2);
      expect(all).toContain(tool1);
      expect(all).toContain(tool2);
    });
  });

  describe('getFunctionDefinitions', () => {
    it('должен возвращать пустой массив когда нет инструментов', () => {
      expect(registry.getFunctionDefinitions()).toEqual([]);
    });

    it('должен возвращать определения функций для разрешённых инструментов', () => {
      const tool = createMockTool({
        name: 'function_tool',
        description: 'Tool for function test',
        parameters: {
          type: 'object',
          properties: {
            param1: { type: 'string', description: 'Test param' }
          },
          required: ['param1']
        }
      });
      registry.register(tool);

      const definitions = registry.getFunctionDefinitions();

      expect(definitions.length).toBe(1);
      expect(definitions[0]).toEqual({
        type: 'function',
        function: {
          name: 'function_tool',
          description: 'Tool for function test',
          parameters: {
            type: 'object',
            properties: {
              param1: { type: 'string', description: 'Test param' }
            },
            required: ['param1']
          }
        }
      });
    });

    it('должен фильтровать инструменты из отключённых категорий', () => {
      const enabledTool = createMockTool({
        name: 'enabled',
        category: 'notebook'
      });
      const disabledTool = createMockTool({
        name: 'disabled',
        category: 'shell'
      });

      registry.register(enabledTool);
      registry.register(disabledTool);

      registry.permissions.setCategoryEnabled('shell', false);

      const definitions = registry.getFunctionDefinitions() as any[];

      expect(definitions.length).toBe(1);
      expect(definitions[0].function.name).toBe('enabled');
    });
  });

  describe('execute', () => {
    it('должен выполнять зарегистрированный инструмент', async () => {
      const tool = createMockTool({
        name: 'executable_tool',
        execute: async args => ({
          success: true,
          result: `executed with ${JSON.stringify(args)}`
        })
      });
      registry.register(tool);

      const result = await registry.execute('executable_tool', { arg: 'test' });

      expect(result.success).toBe(true);
      expect(result.result).toBe('executed with {"arg":"test"}');
    });

    it('должен возвращать ошибку для неизвестного инструмента', async () => {
      const result = await registry.execute('nonexistent_tool', {
        arg: 'test'
      });

      expect(result.success).toBe(false);
      expect(result.error).toBe('Unknown tool: nonexistent_tool');
    });

    it('должен возвращать ошибку для инструмента из отключённой категории', async () => {
      const tool = createMockTool({ name: 'disabled_tool', category: 'shell' });
      registry.register(tool);
      registry.permissions.setCategoryEnabled('shell', false);

      const result = await registry.execute('disabled_tool', { arg: 'test' });

      expect(result.success).toBe(false);
      expect(result.error).toContain('Tool "disabled_tool" is disabled');
    });

    it('должен валидировать аргументы перед выполнением', async () => {
      const tool = createMockTool({
        name: 'validation_tool',
        parameters: {
          type: 'object',
          properties: {
            index: { type: 'integer' }
          },
          required: ['index']
        },
        execute: async () => ({ success: true, result: 'done' })
      });
      registry.register(tool);

      // Передаём отрицательный index - должен fail валидацию
      const result = await registry.execute('validation_tool', { index: -1 });

      expect(result.success).toBe(false);
      expect(result.error).toContain('Invalid arguments');
      expect(result.error).toContain('Index must be non-negative');
    });

    it('должен обрабатывать ошибки выполнения инструмента', async () => {
      const tool = createMockTool({
        name: 'failing_tool',
        execute: async () => {
          throw new Error('Tool execution failed');
        }
      });
      registry.register(tool);

      const result = await registry.execute('failing_tool', { arg: 'test' });

      expect(result.success).toBe(false);
      expect(result.error).toBe('Tool execution failed');
    });

    it('должен обрабатывать не-Error исключения', async () => {
      const tool = createMockTool({
        name: 'string_error_tool',
        execute: async () => {
          throw 'String error';
        }
      });
      registry.register(tool);

      const result = await registry.execute('string_error_tool', {
        arg: 'test'
      });

      expect(result.success).toBe(false);
      expect(result.error).toBe('Unknown error');
    });

    it('должен передавать sanitized аргументы в инструмент', async () => {
      let capturedArgs: Record<string, unknown> = {};

      const tool = createMockTool({
        name: 'capture_tool',
        parameters: {
          type: 'object',
          properties: {
            count: { type: 'integer' }
          },
          required: ['count']
        },
        execute: async args => {
          capturedArgs = args;
          return { success: true, result: 'ok' };
        }
      });
      registry.register(tool);

      await registry.execute('capture_tool', { count: '42' as any });

      expect(capturedArgs.count).toBe(42); // string конвертирован в integer
    });
  });

  describe('permissions integration', () => {
    it('должен предоставлять доступ к PermissionManager', () => {
      expect(registry.permissions).toBeDefined();
    });

    it('должен использовать permissions для фильтрации в getFunctionDefinitions', () => {
      const tool1 = createMockTool({ name: 'allowed', category: 'notebook' });
      const tool2 = createMockTool({ name: 'blocked', category: 'files' });

      registry.register(tool1);
      registry.register(tool2);

      registry.permissions.setCategoryEnabled('files', false);

      const definitions = registry.getFunctionDefinitions() as any[];
      expect(definitions.length).toBe(1);
      expect(definitions[0].function.name).toBe('allowed');
    });

    it('должен проверять permissions при выполнении', async () => {
      const tool = createMockTool({
        name: 'permission_test',
        category: 'shell'
      });
      registry.register(tool);

      registry.permissions.setCategoryEnabled('shell', false);

      const result = await registry.execute('permission_test', { arg: 'test' });
      expect(result.success).toBe(false);
      expect(result.error).toContain('disabled');
    });
  });

  describe('edge cases', () => {
    it('должен обрабатывать инструмент без required параметров', async () => {
      const tool = createMockTool({
        name: 'optional_tool',
        parameters: {
          type: 'object',
          properties: {
            optional: { type: 'string' }
          }
        }
      });
      registry.register(tool);

      const result = await registry.execute('optional_tool', {});
      expect(result.success).toBe(true);
    });

    it('должен обрабатывать инструмент с пустыми свойствами', async () => {
      const tool = createMockTool({
        name: 'empty_props_tool',
        parameters: {
          type: 'object',
          properties: {}
        }
      });
      registry.register(tool);

      const result = await registry.execute('empty_props_tool', {
        anything: 'value'
      });
      expect(result.success).toBe(true);
    });
  });

  describe('tool result types', () => {
    it('должен возвращать result с различными типами данных', async () => {
      const tool = createMockTool({
        name: 'result_type_tool',
        execute: async () => ({
          success: true,
          result: { nested: { data: [1, 2, 3] } }
        })
      });
      registry.register(tool);

      const result = await registry.execute('result_type_tool', {
        arg: 'test'
      });

      expect(result.success).toBe(true);
      expect(result.result).toEqual({ nested: { data: [1, 2, 3] } });
    });

    it('должен возвращать result с null', async () => {
      const tool = createMockTool({
        name: 'null_result_tool',
        execute: async () => ({ success: true, result: null })
      });
      registry.register(tool);

      const result = await registry.execute('null_result_tool', {
        arg: 'test'
      });

      expect(result.success).toBe(true);
      expect(result.result).toBeNull();
    });
  });
});
