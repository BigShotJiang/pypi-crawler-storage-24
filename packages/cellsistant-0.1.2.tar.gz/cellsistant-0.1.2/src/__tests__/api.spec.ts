/**
 * @jest-environment jsdom
 */

import {
  sendToLLM,
  sendToLLMWithRetry,
  streamFromLLM,
  executeShell,
  ILLMMessage,
  ILLMResponse,
  IStreamCallbacks,
  IRetryConfig
} from '../api';

// Mock document.cookie for XSRF token
Object.defineProperty(document, 'cookie', {
  writable: true,
  value: '_xsrf=cookie-xsrf-token'
});

// Mock URLExt
jest.mock('@jupyterlab/coreutils', () => ({
  URLExt: {
    join: jest.fn((base, ...parts) => base + parts.join('/'))
  }
}));

// Mock ServerConnection
jest.mock('@jupyterlab/services', () => ({
  ServerConnection: {
    makeSettings: jest.fn(() => ({
      baseUrl: 'http://localhost:8888/',
      init: {
        headers: {
          Authorization: 'Bearer test-token'
        }
      }
    }))
  }
}));

describe('API', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (globalThis.fetch as jest.Mock) = jest.fn();
  });

  describe('executeShell', () => {
    it('должен успешно выполнять shell команду', async () => {
      const mockResponse = {
        success: true,
        return_code: 0,
        stdout: 'output',
        stderr: '',
        stdout_truncated: false,
        stderr_truncated: false,
        elapsed_seconds: 0.5
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => mockResponse,
        text: async () => JSON.stringify(mockResponse)
      });

      const result = await executeShell('pip list');

      expect(result).toEqual(mockResponse);
      expect(globalThis.fetch).toHaveBeenCalledWith(
        'http://localhost:8888/ai-agent/shell',
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
            'X-XSRFToken': 'cookie-xsrf-token'
          }),
          body: JSON.stringify({ command: 'pip list' }),
          credentials: 'same-origin'
        })
      );
    });

    it('должен отправлять timeout и working_dir если указаны', async () => {
      const mockResponse = {
        success: true,
        return_code: 0,
        stdout: 'output',
        stderr: '',
        stdout_truncated: false,
        stderr_truncated: false,
        elapsed_seconds: 0.5
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => mockResponse,
        text: async () => JSON.stringify(mockResponse)
      });

      await executeShell('ls', 30, '/home/user');

      expect(globalThis.fetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          body: JSON.stringify({
            command: 'ls',
            timeout: 30,
            working_dir: '/home/user'
          })
        })
      );
    });

    it('должен выбрасывать ошибку при 403 (blocked command)', async () => {
      const errorBody = { error: 'Command blocked for security reasons' };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 403,
        text: async () => JSON.stringify(errorBody)
      });

      await expect(executeShell('rm -rf /')).rejects.toThrow(
        'Blocked: {"error":"Command blocked for security reasons"}'
      );
    });

    it('должен выбрасывать ошибку при 500', async () => {
      const errorBody = { error: 'Internal server error' };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 500,
        text: async () => JSON.stringify(errorBody)
      });

      await expect(executeShell('test')).rejects.toThrow(
        'Internal server error'
      );
    });

    it('должен обрабатывать не-JSON ответ при ошибке', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 500,
        text: async () => 'Plain text error'
      });

      await expect(executeShell('test')).rejects.toThrow(
        'Shell error 500: Plain text error'
      );
    });
  });

  describe('sendToLLM', () => {
    it('должен отправлять сообщения и получать ответ', async () => {
      const mockResponse: ILLMResponse = {
        message: {
          role: 'assistant',
          content: 'Hello! How can I help?'
        }
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => mockResponse
      });

      const messages: ILLMMessage[] = [{ role: 'user', content: 'Hello' }];

      const result = await sendToLLM(messages);

      expect(result).toEqual(mockResponse);
      expect(globalThis.fetch).toHaveBeenCalledWith(
        'http://localhost:8888/ai-agent/chat',
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
            'X-XSRFToken': 'cookie-xsrf-token'
          }),
          body: JSON.stringify({ messages }),
          credentials: 'same-origin'
        })
      );
    });

    it('должен выбрасывать ошибку при не 200 статусе', async () => {
      const errorBody = { error: 'API error' };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 500,
        json: async () => errorBody
      });

      await expect(
        sendToLLM([{ role: 'user', content: 'test' }])
      ).rejects.toThrow('API error');
    });

    it('должен поддерживать AbortSignal', async () => {
      const abortController = new AbortController();

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => ({ message: { role: 'assistant', content: 'ok' } })
      });

      await sendToLLM(
        [{ role: 'user', content: 'test' }],
        abortController.signal
      );

      expect(globalThis.fetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          signal: abortController.signal
        })
      );
    });
  });

  describe('sendToLLMWithRetry', () => {
    it('должен возвращать ответ при первом успешном запросе', async () => {
      const mockResponse: ILLMResponse = {
        message: {
          role: 'assistant',
          content: 'Success'
        }
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => mockResponse
      });

      const config: IRetryConfig = {
        maxRetries: 3,
        baseDelay: 1,
        maxDelay: 10
      };

      const result = await sendToLLMWithRetry(
        [{ role: 'user', content: 'test' }],
        undefined,
        config
      );

      expect(result).toEqual(mockResponse);
      expect(globalThis.fetch).toHaveBeenCalledTimes(1);
    });

    it('должен НЕ retry при 400 ошибке', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 400,
        json: async () => ({ error: 'Bad request' })
      });

      const config: IRetryConfig = {
        maxRetries: 3,
        baseDelay: 1,
        maxDelay: 10
      };

      await expect(
        sendToLLMWithRetry(
          [{ role: 'user', content: 'test' }],
          undefined,
          config
        )
      ).rejects.toThrow('Bad request');

      expect(globalThis.fetch).toHaveBeenCalledTimes(1);
    });
  });

  describe('streamFromLLM', () => {
    it('должен обрабатывать SSE стрим с текстовым контентом', async () => {
      const encoder = new TextEncoder();
      const chunks = [
        encoder.encode(
          'data: {"choices": [{"delta": {"content": "Hello"}}]}\n\n'
        ),
        encoder.encode(
          'data: {"choices": [{"delta": {"content": " World"}}]}\n\n'
        ),
        encoder.encode('event: done\n\n')
      ];

      let chunkIndex = 0;
      const mockReader = {
        read: jest.fn().mockImplementation(async () => {
          if (chunkIndex < chunks.length) {
            return { done: false, value: chunks[chunkIndex++] };
          }
          return { done: true, value: undefined };
        }),
        releaseLock: jest.fn()
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        body: {
          getReader: () => mockReader
        }
      });

      const callbacks: IStreamCallbacks = {
        onToken: jest.fn(),
        onToolCalls: jest.fn(),
        onDone: jest.fn(),
        onError: jest.fn()
      };

      await streamFromLLM([{ role: 'user', content: 'test' }], callbacks);

      expect(callbacks.onToken).toHaveBeenCalledWith('Hello');
      expect(callbacks.onToken).toHaveBeenCalledWith(' World');
      expect(callbacks.onDone).toHaveBeenCalledWith(
        expect.objectContaining({
          role: 'assistant',
          content: 'Hello World'
        })
      );
    });

    it('должен обрабатывать tool_calls в стриме', async () => {
      const encoder = new TextEncoder();
      const chunks = [
        encoder.encode(
          'data: {"choices": [{"delta": {"tool_calls": [{"index": 0, "id": "call_1", "function": {"name": "create_cell", "arguments": "{}"}}]}, "finish_reason": "tool_calls"}]}\n\n'
        ),
        encoder.encode('event: done\n\n')
      ];

      let chunkIndex = 0;
      const mockReader = {
        read: jest.fn().mockImplementation(async () => {
          if (chunkIndex < chunks.length) {
            return { done: false, value: chunks[chunkIndex++] };
          }
          return { done: true, value: undefined };
        }),
        releaseLock: jest.fn()
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        body: {
          getReader: () => mockReader
        }
      });

      const callbacks: IStreamCallbacks = {
        onToken: jest.fn(),
        onToolCalls: jest.fn(),
        onDone: jest.fn(),
        onError: jest.fn()
      };

      await streamFromLLM([{ role: 'user', content: 'test' }], callbacks);

      expect(callbacks.onDone).toHaveBeenCalledWith(
        expect.objectContaining({
          role: 'assistant',
          tool_calls: expect.arrayContaining([
            expect.objectContaining({
              id: 'call_1',
              function: expect.objectContaining({
                name: 'create_cell',
                arguments: '{}'
              })
            })
          ])
        })
      );
    });

    it('должен обрабатывать ошибку в стриме', async () => {
      const encoder = new TextEncoder();
      const chunks = [encoder.encode('data: {"error": "API error"}\n\n')];

      let chunkIndex = 0;
      const mockReader = {
        read: jest.fn().mockImplementation(async () => {
          if (chunkIndex < chunks.length) {
            return { done: false, value: chunks[chunkIndex++] };
          }
          return { done: true, value: undefined };
        }),
        releaseLock: jest.fn()
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        body: {
          getReader: () => mockReader
        }
      });

      const callbacks: IStreamCallbacks = {
        onToken: jest.fn(),
        onToolCalls: jest.fn(),
        onDone: jest.fn(),
        onError: jest.fn()
      };

      await streamFromLLM([{ role: 'user', content: 'test' }], callbacks);

      expect(callbacks.onError).toHaveBeenCalledWith('API error');
    });

    it('должен обрабатывать не-ok ответ', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 500,
        text: async () => 'Server error'
      });

      const callbacks: IStreamCallbacks = {
        onToken: jest.fn(),
        onToolCalls: jest.fn(),
        onDone: jest.fn(),
        onError: jest.fn()
      };

      await streamFromLLM([{ role: 'user', content: 'test' }], callbacks);

      expect(callbacks.onError).toHaveBeenCalledWith(
        'Server error 500: Server error'
      );
    });

    it('должен обрабатывать отсутствие response body', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        body: null
      });

      const callbacks: IStreamCallbacks = {
        onToken: jest.fn(),
        onToolCalls: jest.fn(),
        onDone: jest.fn(),
        onError: jest.fn()
      };

      await streamFromLLM([{ role: 'user', content: 'test' }], callbacks);

      expect(callbacks.onError).toHaveBeenCalledWith('No response body');
    });

    it('должен обрабатывать AbortError', async () => {
      const mockReader = {
        read: jest.fn().mockImplementation(async () => {
          throw { name: 'AbortError' };
        }),
        releaseLock: jest.fn()
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        body: {
          getReader: () => mockReader
        }
      });

      const callbacks: IStreamCallbacks = {
        onToken: jest.fn(),
        onToolCalls: jest.fn(),
        onDone: jest.fn(),
        onError: jest.fn()
      };

      await streamFromLLM([{ role: 'user', content: 'test' }], callbacks);

      expect(callbacks.onError).toHaveBeenCalledWith('Request cancelled');
    });

    it('должен пропускать невалидный JSON', async () => {
      const encoder = new TextEncoder();
      const chunks = [
        encoder.encode('data: {invalid json}\n\n'),
        encoder.encode(
          'data: {"choices": [{"delta": {"content": "Valid"}}]}\n\n'
        ),
        encoder.encode('event: done\n\n')
      ];

      let chunkIndex = 0;
      const mockReader = {
        read: jest.fn().mockImplementation(async () => {
          if (chunkIndex < chunks.length) {
            return { done: false, value: chunks[chunkIndex++] };
          }
          return { done: true, value: undefined };
        }),
        releaseLock: jest.fn()
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        body: {
          getReader: () => mockReader
        }
      });

      const callbacks: IStreamCallbacks = {
        onToken: jest.fn(),
        onToolCalls: jest.fn(),
        onDone: jest.fn(),
        onError: jest.fn()
      };

      await streamFromLLM([{ role: 'user', content: 'test' }], callbacks);

      expect(callbacks.onToken).toHaveBeenCalledWith('Valid');
      expect(callbacks.onError).not.toHaveBeenCalled();
    });
  });

  describe('getXsrfToken', () => {
    it('должен использовать токен из cookie', async () => {
      Object.defineProperty(document, 'cookie', {
        writable: true,
        value: '_xsrf=cookie-xsrf-token'
      });

      const mockResponse = {
        success: true,
        return_code: 0,
        stdout: 'output',
        stderr: '',
        stdout_truncated: false,
        stderr_truncated: false,
        elapsed_seconds: 0.5
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => mockResponse,
        text: async () => JSON.stringify(mockResponse)
      });

      await executeShell('test');

      expect(globalThis.fetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          headers: expect.objectContaining({
            'X-XSRFToken': 'cookie-xsrf-token'
          })
        })
      );
    });

    it('должен использовать пустой токен если cookie отсутствует', async () => {
      Object.defineProperty(document, 'cookie', {
        writable: true,
        value: ''
      });

      const mockResponse = {
        success: true,
        return_code: 0,
        stdout: 'output',
        stderr: '',
        stdout_truncated: false,
        stderr_truncated: false,
        elapsed_seconds: 0.5
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => mockResponse,
        text: async () => JSON.stringify(mockResponse)
      });

      await executeShell('test');

      expect(globalThis.fetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          headers: expect.not.objectContaining({
            'X-XSRFToken': expect.any(String)
          })
        })
      );
    });
  });
});
