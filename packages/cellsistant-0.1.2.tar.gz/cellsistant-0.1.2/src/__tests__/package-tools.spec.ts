/**
 * @jest-environment jsdom
 */

import { createPackageTools } from '../tools/package-tools';
import { ToolSafetyLevel } from '../tools';

Object.defineProperty(document, 'cookie', {
  writable: true,
  value: '_xsrf=cookie-xsrf-token'
});

jest.mock('@jupyterlab/coreutils', () => ({
  URLExt: {
    join: jest.fn((base: string, ...parts: string[]) => base + parts.join('/'))
  }
}));

jest.mock('@jupyterlab/services', () => ({
  ServerConnection: {
    makeSettings: jest.fn(() => ({
      baseUrl: 'http://localhost:8888/',
      init: {
        headers: {
          Authorization: 'Bearer test-token'
        }
      }
    }))
  }
}));

const mockFetch = jest.fn();
(globalThis.fetch as jest.Mock) = mockFetch;

describe('Package Tools', () => {
  let tools: ReturnType<typeof createPackageTools>;

  beforeEach(() => {
    jest.clearAllMocks();
    tools = createPackageTools();
  });

  describe('Tool Definitions', () => {
    it('should create 2 tools', () => {
      expect(tools).toHaveLength(2);
    });

    it('should have correct tool names', () => {
      const toolNames = tools.map(t => t.name);
      expect(toolNames).toContain('install_package');
      expect(toolNames).toContain('list_packages');
    });
  });

  describe('install_package', () => {
    let installPackageTool: any;

    beforeEach(() => {
      installPackageTool = tools.find(t => t.name === 'install_package')!;
      mockFetch.mockReset();
    });

    const mockShellSuccess = (stdout: string) => {
      mockFetch.mockResolvedValue({
        status: 200,
        json: async () => ({
          success: true,
          return_code: 0,
          stdout,
          stderr: '',
          stdout_truncated: false,
          stderr_truncated: false,
          elapsed_seconds: 1.0
        }),
        text: async () =>
          JSON.stringify({
            success: true,
            return_code: 0,
            stdout,
            stderr: '',
            stdout_truncated: false,
            stderr_truncated: false,
            elapsed_seconds: 1.0
          })
      });
    };

    const mockShellError = (stderr: string) => {
      mockFetch.mockResolvedValue({
        status: 200,
        json: async () => ({
          success: false,
          return_code: 1,
          stdout: '',
          stderr,
          stdout_truncated: false,
          stderr_truncated: false,
          elapsed_seconds: 1.0
        }),
        text: async () =>
          JSON.stringify({
            success: false,
            return_code: 1,
            stdout: '',
            stderr,
            stdout_truncated: false,
            stderr_truncated: false,
            elapsed_seconds: 1.0
          })
      });
    };

    it('should install package via pip', async () => {
      mockShellSuccess('Successfully installed requests-2.28.0');

      const result = await installPackageTool.execute({
        package_name: 'requests'
      });

      expect(result.success).toBe(true);
      expect((result.result as any).package).toBe('requests');
      expect((result.result as any).manager).toBe('pip');
    });

    it('should install package via conda', async () => {
      mockShellSuccess('Solving environment: done');

      const result = await installPackageTool.execute({
        package_name: 'numpy',
        manager: 'conda'
      });

      expect(result.success).toBe(true);
      expect((result.result as any).manager).toBe('conda');
    });

    it('should install package with version', async () => {
      mockShellSuccess('Successfully installed numpy-1.24.0');

      const result = await installPackageTool.execute({
        package_name: 'numpy>=1.24'
      });

      expect(result.success).toBe(true);
    });

    it('should install with extra_args (--upgrade)', async () => {
      mockShellSuccess('Successfully installed requests-2.28.0');

      const result = await installPackageTool.execute({
        package_name: 'requests',
        extra_args: '--upgrade'
      });

      expect(result.success).toBe(true);
    });

    it('should reject invalid package name', async () => {
      const result = await installPackageTool.execute({
        package_name: 'package; rm -rf /'
      });

      expect(result.success).toBe(false);
      expect(result.error).toContain('Invalid package name');
    });

    it('should handle pip error', async () => {
      mockShellError('ERROR: No matching distribution');

      const result = await installPackageTool.execute({
        package_name: 'nonexistent'
      });

      expect(result.success).toBe(false);
    });

    it('should handle permission denied error', async () => {
      mockShellError('permission denied');

      const result = await installPackageTool.execute({
        package_name: 'somepackage'
      });

      expect(result.success).toBe(false);
      expect(result.error).toContain('Permission denied');
    });

    it('should handle version conflict', async () => {
      mockShellError('conflict');

      const result = await installPackageTool.execute({
        package_name: 'numpy'
      });

      expect(result.success).toBe(false);
      expect(result.error).toContain('conflict');
    });

    it('should require confirmation (SYSTEM safety)', () => {
      expect(installPackageTool.safetyLevel).toBe(ToolSafetyLevel.SYSTEM);
    });

    it('should require package_name parameter', () => {
      expect(installPackageTool.parameters.required).toContain('package_name');
    });

    it('should have manager enum [pip, conda]', () => {
      expect(installPackageTool.parameters.properties.manager.enum).toEqual([
        'pip',
        'conda'
      ]);
    });
  });

  describe('list_packages', () => {
    let listPackagesTool: any;

    beforeEach(() => {
      listPackagesTool = tools.find(t => t.name === 'list_packages')!;
      mockFetch.mockReset();
    });

    it('should list all packages', async () => {
      mockFetch.mockResolvedValue({
        status: 200,
        json: async () => ({
          success: true,
          return_code: 0,
          stdout: JSON.stringify([
            { name: 'pip', version: '23.0.1' },
            { name: 'numpy', version: '1.24.0' },
            { name: 'pandas', version: '2.0.0' }
          ]),
          stderr: '',
          stdout_truncated: false,
          stderr_truncated: false,
          elapsed_seconds: 0.5
        }),
        text: async () =>
          JSON.stringify({
            success: true,
            return_code: 0,
            stdout: JSON.stringify([
              { name: 'pip', version: '23.0.1' },
              { name: 'numpy', version: '1.24.0' },
              { name: 'pandas', version: '2.0.0' }
            ]),
            stderr: '',
            stdout_truncated: false,
            stderr_truncated: false,
            elapsed_seconds: 0.5
          })
      });

      const result = await listPackagesTool.execute({});

      expect(result.success).toBe(true);
      expect((result.result as any).count).toBe(3);
      expect((result.result as any).packages).toHaveLength(3);
    });

    it('should filter packages by name', async () => {
      mockFetch.mockResolvedValue({
        status: 200,
        json: async () => ({
          success: true,
          return_code: 0,
          stdout: JSON.stringify([{ name: 'pandas', version: '2.0.0' }]),
          stderr: '',
          stdout_truncated: false,
          stderr_truncated: false,
          elapsed_seconds: 0.5
        }),
        text: async () =>
          JSON.stringify({
            success: true,
            return_code: 0,
            stdout: JSON.stringify([{ name: 'pandas', version: '2.0.0' }]),
            stderr: '',
            stdout_truncated: false,
            stderr_truncated: false,
            elapsed_seconds: 0.5
          })
      });

      const result = await listPackagesTool.execute({ filter: 'pandas' });

      expect(result.success).toBe(true);
      expect((result.result as any).count).toBe(1);
    });

    it('should return error on shell failure', async () => {
      mockFetch.mockResolvedValue({
        status: 200,
        json: async () => ({
          success: false,
          return_code: 1,
          stdout: '',
          stderr: 'pip not found',
          stdout_truncated: false,
          stderr_truncated: false,
          elapsed_seconds: 0.5
        }),
        text: async () =>
          JSON.stringify({
            success: false,
            return_code: 1,
            stdout: '',
            stderr: 'pip not found',
            stdout_truncated: false,
            stderr_truncated: false,
            elapsed_seconds: 0.5
          })
      });

      const result = await listPackagesTool.execute({});

      expect(result.success).toBe(false);
      expect(result.error).toContain('Failed to list packages');
    });

    it('should truncate results to 100 packages', async () => {
      const manyPackages = Array.from({ length: 150 }, (_, i) => ({
        name: `package${i}`,
        version: '1.0.0'
      }));

      mockFetch.mockResolvedValue({
        status: 200,
        json: async () => ({
          success: true,
          return_code: 0,
          stdout: JSON.stringify(manyPackages),
          stderr: '',
          stdout_truncated: false,
          stderr_truncated: false,
          elapsed_seconds: 0.5
        }),
        text: async () =>
          JSON.stringify({
            success: true,
            return_code: 0,
            stdout: JSON.stringify(manyPackages),
            stderr: '',
            stdout_truncated: false,
            stderr_truncated: false,
            elapsed_seconds: 0.5
          })
      });

      const result = await listPackagesTool.execute({});

      expect(result.success).toBe(true);
      expect((result.result as any).packages).toHaveLength(100);
      expect(result.result).toHaveProperty('truncated', true);
    });

    it('should have READ safety level', () => {
      expect(listPackagesTool.safetyLevel).toBe(ToolSafetyLevel.READ);
    });
  });

  describe('Safety Levels', () => {
    it('should have correct safety levels', () => {
      const installPackageTool = tools.find(t => t.name === 'install_package')!;
      const listPackagesTool = tools.find(t => t.name === 'list_packages')!;

      expect(installPackageTool.safetyLevel).toBe(ToolSafetyLevel.SYSTEM);
      expect(listPackagesTool.safetyLevel).toBe(ToolSafetyLevel.READ);
    });
  });
});
