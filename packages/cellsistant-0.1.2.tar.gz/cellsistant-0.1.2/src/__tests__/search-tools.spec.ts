/**
 * @jest-environment jsdom
 */

import { createSearchTools } from '../tools/search-tools';
import { ToolSafetyLevel } from '../tools';

const mockFindInNotebook = jest.fn();
const mockReplaceInCell = jest.fn();

const mockJupyterService = {
  findInNotebook: mockFindInNotebook,
  replaceInCell: mockReplaceInCell
} as any;

jest.mock('../jupyter-service', () => ({
  JupyterService: jest.fn().mockImplementation(() => mockJupyterService)
}));

describe('Search Tools', () => {
  let tools: ReturnType<typeof createSearchTools>;

  beforeEach(() => {
    jest.clearAllMocks();
    tools = createSearchTools(mockJupyterService);
  });

  describe('Tool Definitions', () => {
    it('should create 2 tools', () => {
      expect(tools).toHaveLength(2);
    });

    it('should have correct tool names', () => {
      const toolNames = tools.map(t => t.name);
      expect(toolNames).toContain('find_in_notebook');
      expect(toolNames).toContain('replace_in_cell');
    });
  });

  describe('find_in_notebook (T-SE-001, T-SE-002, T-SE-003, T-SE-004, T-SE-005, T-SE-006, T-SE-007)', () => {
    let findInNotebookTool: any;

    beforeEach(() => {
      findInNotebookTool = tools.find(t => t.name === 'find_in_notebook')!;
    });

    it('should find matches in code cells', async () => {
      mockFindInNotebook.mockReturnValue({
        success: true,
        matches: [
          { cellIndex: 0, lineNumber: 3, line: 'x = 10', matchedText: 'x' },
          { cellIndex: 1, lineNumber: 1, line: 'print(x)', matchedText: 'x' }
        ]
      });

      const result = await findInNotebookTool.execute({ query: 'x' });

      expect(result.success).toBe(true);
      expect(result.result).toHaveProperty('found', true);
      expect(result.result).toHaveProperty('total_matches', 2);
      expect(result.result).toHaveProperty('cells_with_matches', 2);
      expect(mockFindInNotebook).toHaveBeenCalledWith('x', {
        caseSensitive: undefined,
        regex: undefined,
        cellType: undefined
      });
    });

    it('should find matches in markdown cells', async () => {
      mockFindInNotebook.mockReturnValue({
        success: true,
        matches: [
          { cellIndex: 0, lineNumber: 1, line: '# Title', matchedText: 'Title' }
        ]
      });

      const result = await findInNotebookTool.execute({
        query: 'Title',
        cell_type: 'markdown'
      });

      expect(result.success).toBe(true);
      expect(mockFindInNotebook).toHaveBeenCalledWith('Title', {
        caseSensitive: undefined,
        regex: undefined,
        cellType: 'markdown'
      });
    });

    it('should perform case-sensitive search', async () => {
      mockFindInNotebook.mockReturnValue({
        success: true,
        matches: [
          {
            cellIndex: 0,
            lineNumber: 1,
            line: 'MyClass',
            matchedText: 'MyClass'
          }
        ]
      });

      const result = await findInNotebookTool.execute({
        query: 'MyClass',
        case_sensitive: true
      });

      expect(result.success).toBe(true);
      expect(mockFindInNotebook).toHaveBeenCalledWith('MyClass', {
        caseSensitive: true,
        regex: undefined,
        cellType: undefined
      });
    });

    it('should perform regex search', async () => {
      mockFindInNotebook.mockReturnValue({
        success: true,
        matches: [
          { cellIndex: 0, lineNumber: 1, line: 'item_1', matchedText: 'item_' },
          { cellIndex: 0, lineNumber: 2, line: 'item_2', matchedText: 'item_' }
        ]
      });

      const result = await findInNotebookTool.execute({
        query: 'item_\\d+',
        regex: true
      });

      expect(result.success).toBe(true);
      expect(mockFindInNotebook).toHaveBeenCalledWith('item_\\d+', {
        caseSensitive: undefined,
        regex: true,
        cellType: undefined
      });
    });

    it('should return no matches result', async () => {
      mockFindInNotebook.mockReturnValue({
        success: true,
        matches: []
      });

      const result = await findInNotebookTool.execute({ query: 'nonexistent' });

      expect(result.success).toBe(true);
      expect(result.result).toHaveProperty('found', false);
      expect(result.result).toHaveProperty('total_matches', 0);
      expect(result.result).toHaveProperty(
        'message',
        'No matches found for "nonexistent"'
      );
    });

    it('should return error when no active notebook', async () => {
      mockFindInNotebook.mockReturnValue({
        success: false,
        error: 'No active notebook'
      });

      const result = await findInNotebookTool.execute({ query: 'test' });

      expect(result.success).toBe(false);
      expect(result.error).toBe('No active notebook');
    });

    it('should generate formatted summary', async () => {
      mockFindInNotebook.mockReturnValue({
        success: true,
        matches: [
          { cellIndex: 0, lineNumber: 3, line: 'x = 10', matchedText: 'x' },
          { cellIndex: 0, lineNumber: 5, line: 'y = x * 2', matchedText: 'x' },
          { cellIndex: 1, lineNumber: 1, line: 'print(x)', matchedText: 'x' }
        ]
      });

      const result = await findInNotebookTool.execute({ query: 'x' });

      expect(result.success).toBe(true);
      expect(result.result).toHaveProperty('summary');
      expect((result.result as any).summary).toContain('Cell [0]');
      expect((result.result as any).summary).toContain('Cell [1]');
    });

    it('should truncate matches to 50', async () => {
      const manyMatches = Array.from({ length: 100 }, (_, i) => ({
        cellIndex: 0,
        lineNumber: i + 1,
        line: `line ${i}`,
        matchedText: 'match'
      }));

      mockFindInNotebook.mockReturnValue({
        success: true,
        matches: manyMatches
      });

      const result = await findInNotebookTool.execute({ query: 'match' });

      expect(result.success).toBe(true);
      expect(result.result).toHaveProperty('total_matches', 100);
      expect((result.result as any).matches).toHaveLength(50);
    });

    it('should have READ safety level', () => {
      expect(findInNotebookTool.safetyLevel).toBe(ToolSafetyLevel.READ);
    });

    it('should require query parameter', () => {
      expect(findInNotebookTool.parameters.required).toContain('query');
    });
  });

  describe('replace_in_cell (T-SE-008, T-SE-009, T-SE-010, T-SE-011, T-SE-012, T-SE-013, T-SE-014)', () => {
    let replaceInCellTool: any;

    beforeEach(() => {
      replaceInCellTool = tools.find(t => t.name === 'replace_in_cell')!;
    });

    it('should replace text in cell', async () => {
      mockReplaceInCell.mockReturnValue({
        success: true,
        replacements: 1
      });

      const result = await replaceInCellTool.execute({
        index: 1,
        search: 'old',
        replace: 'new'
      });

      expect(result.success).toBe(true);
      expect(result.result).toHaveProperty('replacements', 1);
      expect(result.result).toHaveProperty(
        'message',
        'Replaced 1 occurrence(s) of "old" with "new" in cell [1]'
      );
      expect(mockReplaceInCell).toHaveBeenCalledWith(1, 'old', 'new', {
        caseSensitive: undefined,
        regex: undefined,
        replaceAll: undefined
      });
    });

    it('should replace all occurrences when replace_all is true', async () => {
      mockReplaceInCell.mockReturnValue({
        success: true,
        replacements: 3
      });

      const result = await replaceInCellTool.execute({
        index: 1,
        search: 'x',
        replace: 'y',
        replace_all: true
      });

      expect(result.success).toBe(true);
      expect(result.result).toHaveProperty('replacements', 3);
    });

    it('should replace only first occurrence when replace_all is false', async () => {
      mockReplaceInCell.mockReturnValue({
        success: true,
        replacements: 1
      });

      const result = await replaceInCellTool.execute({
        index: 1,
        search: 'x',
        replace: 'y',
        replace_all: false
      });

      expect(result.success).toBe(true);
      expect(mockReplaceInCell).toHaveBeenCalledWith(1, 'x', 'y', {
        caseSensitive: undefined,
        regex: undefined,
        replaceAll: false
      });
    });

    it('should perform case-sensitive replacement', async () => {
      mockReplaceInCell.mockReturnValue({
        success: true,
        replacements: 1
      });

      const result = await replaceInCellTool.execute({
        index: 1,
        search: 'X',
        replace: 'Y',
        case_sensitive: true
      });

      expect(result.success).toBe(true);
      expect(mockReplaceInCell).toHaveBeenCalledWith(1, 'X', 'Y', {
        caseSensitive: true,
        regex: undefined,
        replaceAll: undefined
      });
    });

    it('should perform regex replacement', async () => {
      mockReplaceInCell.mockReturnValue({
        success: true,
        replacements: 2
      });

      const result = await replaceInCellTool.execute({
        index: 1,
        search: 'item_\\d+',
        replace: 'element_$1',
        regex: true
      });

      expect(result.success).toBe(true);
      expect(mockReplaceInCell).toHaveBeenCalledWith(
        1,
        'item_\\d+',
        'element_$1',
        {
          caseSensitive: undefined,
          regex: true,
          replaceAll: undefined
        }
      );
    });

    it('should return error for invalid cell index', async () => {
      mockReplaceInCell.mockReturnValue({
        success: false,
        error: 'Invalid cell index: 99'
      });

      const result = await replaceInCellTool.execute({
        index: 99,
        search: 'old',
        replace: 'new'
      });

      expect(result.success).toBe(false);
      expect(result.error).toBe('Invalid cell index: 99');
    });

    it('should return error when no active notebook', async () => {
      mockReplaceInCell.mockReturnValue({
        success: false,
        error: 'No active notebook'
      });

      const result = await replaceInCellTool.execute({
        index: 1,
        search: 'old',
        replace: 'new'
      });

      expect(result.success).toBe(false);
      expect(result.error).toBe('No active notebook');
    });

    it('should have WRITE safety level', () => {
      expect(replaceInCellTool.safetyLevel).toBe(ToolSafetyLevel.WRITE);
    });

    it('should require index, search, and replace parameters', () => {
      expect(replaceInCellTool.parameters.required).toContain('index');
      expect(replaceInCellTool.parameters.required).toContain('search');
      expect(replaceInCellTool.parameters.required).toContain('replace');
    });
  });

  describe('Safety Levels', () => {
    it('should have correct safety levels', () => {
      const findInNotebookTool = tools.find(
        t => t.name === 'find_in_notebook'
      )!;
      const replaceInCellTool = tools.find(t => t.name === 'replace_in_cell')!;

      expect(findInNotebookTool.safetyLevel).toBe(ToolSafetyLevel.READ);
      expect(replaceInCellTool.safetyLevel).toBe(ToolSafetyLevel.WRITE);
    });
  });

  describe('Categories', () => {
    it('should have search category', () => {
      tools.forEach(tool => {
        expect(tool.category).toBe('search');
      });
    });
  });
});
