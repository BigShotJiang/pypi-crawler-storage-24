import {
  estimateTokens,
  estimateMessageTokens,
  estimateMessagesTokens,
  formatTokenCount
} from '../token-counter';
import { ILLMMessage } from '../api';

describe('TokenCounter', () => {
  describe('estimateTokens', () => {
    it('должен возвращать 0 для пустой строки', () => {
      expect(estimateTokens('')).toBe(0);
      expect(estimateTokens(null as any)).toBe(0);
      expect(estimateTokens(undefined as any)).toBe(0);
    });

    it('должен подсчитывать токены для английского текста (~4 символа = 1 токен)', () => {
      // "Hello World" = 11 символов, примерно 3 токена
      const tokens = estimateTokens('Hello World');
      expect(tokens).toBeGreaterThan(0);
      expect(tokens).toBeLessThan(10);
    });

    it('должен подсчитывать больше токенов для кода со спецсимволами', () => {
      const code = 'function test() { return a + b; }';
      const tokens = estimateTokens(code);
      expect(tokens).toBeGreaterThan(0);
    });

    it('должен подсчитывать токены для русского текста (~2 символа = 1 токен)', () => {
      const russian = 'Привет мир';
      const tokens = estimateTokens(russian);
      expect(tokens).toBeGreaterThan(0);
      // Русский текст должен давать больше токенов на символ чем английский
    });

    it('должен подсчитывать токены для смешанного текста', () => {
      const mixed = 'Hello Привет 世界';
      const tokens = estimateTokens(mixed);
      expect(tokens).toBeGreaterThan(0);
    });

    it('должен подсчитывать токены для JSON', () => {
      const json = '{"name": "test", "value": 123}';
      const tokens = estimateTokens(json);
      expect(tokens).toBeGreaterThan(0);
    });

    it('должен возвращать одинаковые токены для одинакового текста', () => {
      const text = 'consistent text';
      const tokens1 = estimateTokens(text);
      const tokens2 = estimateTokens(text);
      expect(tokens1).toBe(tokens2);
    });

    it('должен округлять результат вверх', () => {
      // Маленький текст должен давать хотя бы 1 токен
      const tokens = estimateTokens('a');
      expect(tokens).toBeGreaterThanOrEqual(1);
    });
  });

  describe('estimateMessageTokens', () => {
    it('должен подсчитывать токены для простого сообщения', () => {
      const msg: ILLMMessage = {
        role: 'user',
        content: 'Hello, world!'
      };

      const tokens = estimateMessageTokens(msg);
      expect(tokens).toBeGreaterThan(4); // 4 служебных токена + контент
    });

    it('должен подсчитывать токены для сообщения с null content', () => {
      const msg: ILLMMessage = {
        role: 'assistant',
        content: null
      };

      const tokens = estimateMessageTokens(msg);
      expect(tokens).toBe(4); // только служебные токены
    });

    it('должен подсчитывать токены для сообщения с tool_calls', () => {
      const msg: ILLMMessage = {
        role: 'assistant',
        content: 'Let me check',
        tool_calls: [
          {
            id: 'call_123',
            type: 'function',
            function: {
              name: 'create_cell',
              arguments: '{"cell_type": "code", "source": "print(1)"}'
            }
          }
        ]
      };

      const tokens = estimateMessageTokens(msg);
      expect(tokens).toBeGreaterThan(10);
    });

    it('должен подсчитывать токены для tool сообщения', () => {
      const msg: ILLMMessage = {
        role: 'tool',
        content: '{"success": true}',
        tool_call_id: 'call_123'
      };

      const tokens = estimateMessageTokens(msg);
      expect(tokens).toBeGreaterThan(5);
    });

    it('должен обрабатывать сообщение с несколькими tool_calls', () => {
      const msg: ILLMMessage = {
        role: 'assistant',
        content: null,
        tool_calls: [
          {
            id: 'call_1',
            type: 'function',
            function: {
              name: 'tool1',
              arguments: '{"arg": "value1"}'
            }
          },
          {
            id: 'call_2',
            type: 'function',
            function: {
              name: 'tool2',
              arguments: '{"arg": "value2"}'
            }
          }
        ]
      };

      const tokens = estimateMessageTokens(msg);
      expect(tokens).toBeGreaterThan(20);
    });

    it('должен обрабатывать tool_call без id', () => {
      const msg: ILLMMessage = {
        role: 'assistant',
        content: null,
        tool_calls: [
          {
            id: undefined as any,
            type: 'function',
            function: {
              name: 'tool1',
              arguments: '{}'
            }
          }
        ]
      };

      const tokens = estimateMessageTokens(msg);
      expect(tokens).toBeGreaterThan(0);
    });
  });

  describe('estimateMessagesTokens', () => {
    it('должен возвращать 0 для пустого массива', () => {
      expect(estimateMessagesTokens([])).toBe(0);
    });

    it('должен суммировать токены всех сообщений', () => {
      const messages: ILLMMessage[] = [
        { role: 'user', content: 'Hello' },
        { role: 'assistant', content: 'Hi there' }
      ];

      const tokens = estimateMessagesTokens(messages);
      expect(tokens).toBeGreaterThan(8);
    });

    it('должен обрабатывать длинные цепочки сообщений', () => {
      const messages: ILLMMessage[] = Array(10).fill({
        role: 'user',
        content: 'Message'
      });

      const tokens = estimateMessagesTokens(messages);
      expect(tokens).toBeGreaterThan(40);
    });
  });

  describe('formatTokenCount', () => {
    it('должен форматировать маленькие числа без изменений', () => {
      expect(formatTokenCount(0)).toBe('0');
      expect(formatTokenCount(50)).toBe('50');
      expect(formatTokenCount(999)).toBe('999');
    });

    it('должен форматировать числа >= 1000 с "K"', () => {
      expect(formatTokenCount(1000)).toBe('1.0K');
      expect(formatTokenCount(1500)).toBe('1.5K');
      expect(formatTokenCount(9999)).toBe('10.0K');
    });

    it('должен форматировать числа >= 10K округлённо', () => {
      expect(formatTokenCount(10000)).toBe('10K');
      expect(formatTokenCount(15500)).toBe('16K');
      expect(formatTokenCount(100000)).toBe('100K');
    });

    it('должен форматировать миллионы с "M"', () => {
      expect(formatTokenCount(1000000)).toBe('1.0M');
      expect(formatTokenCount(1500000)).toBe('1.5M');
      expect(formatTokenCount(2100000)).toBe('2.1M');
    });
  });

  describe('edge cases', () => {
    it('должен обрабатывать очень длинные строки', () => {
      const longText = 'a'.repeat(10000);
      const tokens = estimateTokens(longText);
      expect(tokens).toBeGreaterThan(0);
      expect(tokens).toBeLessThan(10000);
    });

    it('должен обрабатывать эмодзи', () => {
      const emoji = 'Hello 👋 World 🌍';
      const tokens = estimateTokens(emoji);
      expect(tokens).toBeGreaterThan(0);
    });

    it('должен обрабатывать специальные символы', () => {
      const special = 'Test\n\t\r\n\\n\\t';
      const tokens = estimateTokens(special);
      expect(tokens).toBeGreaterThan(0);
    });

    it('должен обрабатывать Unicode символы', () => {
      const unicode = '日本語テスト中文测试한국어 테스트';
      const tokens = estimateTokens(unicode);
      expect(tokens).toBeGreaterThan(0);
    });
  });

  describe('token estimation accuracy', () => {
    it('должен давать разумную оценку для типичного пользовательского сообщения', () => {
      const message = 'How do I create a function in Python that sorts a list?';
      const tokens = estimateTokens(message);
      // ~60 символов, должно быть примерно 15-25 токенов
      expect(tokens).toBeGreaterThanOrEqual(10);
      expect(tokens).toBeLessThanOrEqual(40);
    });

    it('должен давать разумную оценку для кода', () => {
      const code = `
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

print(fibonacci(10))
      `.trim();
      const tokens = estimateTokens(code);
      expect(tokens).toBeGreaterThanOrEqual(20);
      expect(tokens).toBeLessThanOrEqual(100);
    });
  });
});
