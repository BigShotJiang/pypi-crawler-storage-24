import { PermissionManager } from '../permission-manager';
import {
  ITool,
  IToolParameters,
  ToolSafetyLevel,
  ToolCategory
} from '../tools';

/**
 * Helper для создания тестового инструмента
 */
function createMockTool(overrides?: Partial<ITool>): ITool {
  const mockParams: IToolParameters = {
    type: 'object',
    properties: {
      arg: { type: 'string', description: 'Test argument' }
    },
    required: ['arg']
  };

  return {
    name: 'test_tool',
    description: 'Test tool',
    parameters: mockParams,
    execute: async () => ({ success: true, result: 'ok' }),
    safetyLevel: ToolSafetyLevel.READ,
    category: 'notebook',
    alwaysConfirm: false,
    ...overrides
  };
}

describe('PermissionManager', () => {
  let permissionManager: PermissionManager;

  beforeEach(() => {
    permissionManager = new PermissionManager();
  });

  describe('constructor', () => {
    it('должен создавать менеджер с настройками по умолчанию', () => {
      const config = permissionManager.getConfig();

      expect(config.enabledCategories.notebook).toBe(true);
      expect(config.enabledCategories.files).toBe(true);
      expect(config.enabledCategories.shell).toBe(true);
      expect(config.enabledCategories.packages).toBe(true);
      expect(config.enabledCategories.search).toBe(true);
      expect(config.blockedTools.size).toBe(0);
    });

    it('должен принимать кастомную конфигурацию', () => {
      const customManager = new PermissionManager({
        enabledCategories: { notebook: false, shell: true } as Record<
          ToolCategory,
          boolean
        >,
        blockedTools: new Set(['dangerous_tool'])
      });

      expect(customManager.isCategoryEnabled('notebook')).toBe(false);
      expect(customManager.isCategoryEnabled('shell')).toBe(true);
    });
  });

  describe('isAllowed', () => {
    it('должен разрешать инструменты из включённых категорий', () => {
      const tool = createMockTool({ category: 'notebook' });
      expect(permissionManager.isAllowed(tool)).toBe(true);
    });

    it('должен запрещать инструменты из отключённых категорий', () => {
      permissionManager.setCategoryEnabled('shell', false);
      const tool = createMockTool({ category: 'shell' });
      expect(permissionManager.isAllowed(tool)).toBe(false);
    });

    it('должен запрещать заблокированные инструменты', () => {
      permissionManager.blockTool('test_tool');
      const tool = createMockTool({ name: 'test_tool' });
      expect(permissionManager.isAllowed(tool)).toBe(false);
    });

    it('должен разрешать инструмент после разблокировки', () => {
      permissionManager.blockTool('test_tool');
      permissionManager.unblockTool('test_tool');
      const tool = createMockTool({ name: 'test_tool' });
      expect(permissionManager.isAllowed(tool)).toBe(true);
    });
  });

  describe('requiresConfirmation', () => {
    it('должен требовать подтверждение когда autoMode = false', () => {
      const tool = createMockTool();
      expect(permissionManager.requiresConfirmation(tool, false)).toBe(true);
    });

    it('не должен требовать подтверждение для READ инструментов в autoMode', () => {
      const tool = createMockTool({ safetyLevel: ToolSafetyLevel.READ });
      expect(permissionManager.requiresConfirmation(tool, true)).toBe(false);
    });

    it('должен требовать подтверждение для SYSTEM инструментов в autoMode', () => {
      const tool = createMockTool({ safetyLevel: ToolSafetyLevel.SYSTEM });
      expect(permissionManager.requiresConfirmation(tool, true)).toBe(true);
    });

    it('должен требовать подтверждение для alwaysConfirm инструментов', () => {
      const tool = createMockTool({
        safetyLevel: ToolSafetyLevel.READ,
        alwaysConfirm: true
      });
      expect(permissionManager.requiresConfirmation(tool, true)).toBe(true);
    });

    it('должен требовать подтверждение для инструментов из alwaysConfirmTools', () => {
      const customManager = new PermissionManager({
        alwaysConfirmTools: new Set(['test_tool'])
      });
      const tool = createMockTool({ name: 'test_tool' });
      expect(customManager.requiresConfirmation(tool, true)).toBe(true);
    });

    it('не должен требовать подтверждение для WRITE инструментов в autoMode', () => {
      const tool = createMockTool({ safetyLevel: ToolSafetyLevel.WRITE });
      expect(permissionManager.requiresConfirmation(tool, true)).toBe(false);
    });

    it('не должен требовать подтверждение для EXECUTE инструментов в autoMode', () => {
      const tool = createMockTool({ safetyLevel: ToolSafetyLevel.EXECUTE });
      expect(permissionManager.requiresConfirmation(tool, true)).toBe(false);
    });
  });

  describe('filterTools', () => {
    it('должен фильтровать инструменты по категориям', () => {
      const tools: ITool[] = [
        createMockTool({ name: 'notebook_tool', category: 'notebook' }),
        createMockTool({ name: 'shell_tool', category: 'shell' }),
        createMockTool({ name: 'file_tool', category: 'files' })
      ];

      permissionManager.setCategoryEnabled('shell', false);
      const filtered = permissionManager.filterTools(tools);

      expect(filtered.length).toBe(2);
      expect(filtered.map(t => t.name)).toContain('notebook_tool');
      expect(filtered.map(t => t.name)).toContain('file_tool');
      expect(filtered.map(t => t.name)).not.toContain('shell_tool');
    });

    it('должен фильтровать заблокированные инструменты', () => {
      const tools: ITool[] = [
        createMockTool({ name: 'safe_tool' }),
        createMockTool({ name: 'blocked_tool' })
      ];

      permissionManager.blockTool('blocked_tool');
      const filtered = permissionManager.filterTools(tools);

      expect(filtered.length).toBe(1);
      expect(filtered[0].name).toBe('safe_tool');
    });
  });

  describe('updateConfig', () => {
    it('должен обновлять enabledCategories', () => {
      const currentConfig = permissionManager.getConfig();
      const newCategories = {
        ...currentConfig.enabledCategories,
        notebook: false
      };
      permissionManager.updateConfig({
        enabledCategories: newCategories
      });
      expect(permissionManager.isCategoryEnabled('notebook')).toBe(false);
      expect(permissionManager.isCategoryEnabled('shell')).toBe(true);
    });

    it('должен обновлять confirmLevels', () => {
      const newLevels = new Set([
        ToolSafetyLevel.SYSTEM,
        ToolSafetyLevel.EXECUTE
      ]);
      permissionManager.updateConfig({ confirmLevels: newLevels });

      const config = permissionManager.getConfig();
      expect(config.confirmLevels.has(ToolSafetyLevel.EXECUTE)).toBe(true);
    });

    it('должен обновлять blockedTools', () => {
      permissionManager.updateConfig({
        blockedTools: new Set(['tool1', 'tool2'])
      });

      const config = permissionManager.getConfig();
      expect(config.blockedTools.has('tool1')).toBe(true);
      expect(config.blockedTools.has('tool2')).toBe(true);
    });

    it('должен обновлять alwaysConfirmTools', () => {
      permissionManager.updateConfig({
        alwaysConfirmTools: new Set(['confirm_tool'])
      });

      const config = permissionManager.getConfig();
      expect(config.alwaysConfirmTools.has('confirm_tool')).toBe(true);
    });
  });

  describe('setCategoryEnabled', () => {
    it('должен включать категорию', () => {
      permissionManager.setCategoryEnabled('shell', false);
      expect(permissionManager.isCategoryEnabled('shell')).toBe(false);

      permissionManager.setCategoryEnabled('shell', true);
      expect(permissionManager.isCategoryEnabled('shell')).toBe(true);
    });
  });

  describe('blockTool / unblockTool', () => {
    it('должен блокировать и разблокировать инструмент', () => {
      permissionManager.blockTool('test_tool');
      expect(permissionManager.getConfig().blockedTools.has('test_tool')).toBe(
        true
      );

      permissionManager.unblockTool('test_tool');
      expect(permissionManager.getConfig().blockedTools.has('test_tool')).toBe(
        false
      );
    });
  });

  describe('getSafetyDescription', () => {
    it('should return correct description for READ', () => {
      const desc = PermissionManager.getSafetyDescription(ToolSafetyLevel.READ);
      expect(desc.label).toBe('Read-only');
      expect(desc.icon).toBe('👁');
      expect(desc.color).toBe('#4caf50');
    });

    it('should return correct description for WRITE', () => {
      const desc = PermissionManager.getSafetyDescription(
        ToolSafetyLevel.WRITE
      );
      expect(desc.label).toBe('Write');
      expect(desc.icon).toBe('✏️');
      expect(desc.color).toBe('#ff9800');
    });

    it('should return correct description for EXECUTE', () => {
      const desc = PermissionManager.getSafetyDescription(
        ToolSafetyLevel.EXECUTE
      );
      expect(desc.label).toBe('Execute');
      expect(desc.icon).toBe('▶️');
      expect(desc.color).toBe('#f57c00');
    });

    it('should return correct description for SYSTEM', () => {
      const desc = PermissionManager.getSafetyDescription(
        ToolSafetyLevel.SYSTEM
      );
      expect(desc.label).toBe('System');
      expect(desc.icon).toBe('⚠️');
      expect(desc.color).toBe('#f44336');
    });
  });

  describe('getConfig', () => {
    it('должен возвращать копию конфигурации', () => {
      const config1 = permissionManager.getConfig();
      const originalNotebook = config1.enabledCategories.notebook;

      // Модифицируем первую копию
      config1.enabledCategories = {
        ...config1.enabledCategories,
        notebook: !originalNotebook
      };

      // Вторая копия должна остаться неизменной
      const config2 = permissionManager.getConfig();
      expect(config2.enabledCategories.notebook).toBe(originalNotebook);
    });
  });
});
