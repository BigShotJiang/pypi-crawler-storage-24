/**
 * @jest-environment jsdom
 */

import { createNotebookTools } from '../tools/notebook-tools';
import { ToolSafetyLevel } from '../tools';

const mockCreateCell = jest.fn();
const mockUpdateCell = jest.fn();
const mockDeleteCell = jest.fn();
const mockGetCellContent = jest.fn();
const mockGetCellMetadata = jest.fn();
const mockExecuteCell = jest.fn();
const mockGetCellOutput = jest.fn();
const mockGetNotebookContent = jest.fn();

const mockJupyterService = {
  createCell: mockCreateCell,
  updateCell: mockUpdateCell,
  deleteCell: mockDeleteCell,
  getCellContent: mockGetCellContent,
  getCellMetadata: mockGetCellMetadata,
  executeCell: mockExecuteCell,
  getCellOutput: mockGetCellOutput,
  getNotebookContent: mockGetNotebookContent
} as any;

jest.mock('../jupyter-service', () => ({
  JupyterService: jest.fn().mockImplementation(() => mockJupyterService)
}));

jest.mock('../api', () => ({
  analyzeImage: jest.fn().mockResolvedValue({
    success: true,
    analysis: 'Test image analysis'
  })
}));

describe('Notebook Tools', () => {
  let tools: ReturnType<typeof createNotebookTools>;

  beforeEach(() => {
    jest.clearAllMocks();
    tools = createNotebookTools(mockJupyterService);
  });

  describe('Tool Definitions', () => {
    it('should create 8 tools', () => {
      expect(tools).toHaveLength(8);
    });

    it('should have correct tool names', () => {
      const toolNames = tools.map(t => t.name);
      expect(toolNames).toContain('create_cell');
      expect(toolNames).toContain('update_cell');
      expect(toolNames).toContain('delete_cell');
      expect(toolNames).toContain('get_cell_content');
      expect(toolNames).toContain('get_notebook_content');
      expect(toolNames).toContain('execute_cell');
      expect(toolNames).toContain('get_cell_output');
      expect(toolNames).toContain('analyze_image');
    });
  });

  describe('create_cell', () => {
    it('should create a code cell successfully', async () => {
      mockCreateCell.mockResolvedValue({ success: true, index: 1 });

      const createCellTool = tools.find(t => t.name === 'create_cell')!;
      const result = await createCellTool.execute({
        cell_type: 'code',
        source: 'print("Hello")'
      });

      expect(result.success).toBe(true);
      expect((result.result as any).index).toBe(1);
      expect(mockCreateCell).toHaveBeenCalledWith('code', 'print("Hello")');
    });

    it('should create a markdown cell successfully', async () => {
      mockCreateCell.mockResolvedValue({ success: true, index: 2 });

      const createCellTool = tools.find(t => t.name === 'create_cell')!;
      const result = await createCellTool.execute({
        cell_type: 'markdown',
        source: '# Header'
      });

      expect(result.success).toBe(true);
      expect(mockCreateCell).toHaveBeenCalledWith('markdown', '# Header');
    });

    it('should return error when no active notebook', async () => {
      mockCreateCell.mockResolvedValue({
        success: false,
        error: 'No active notebook'
      });

      const createCellTool = tools.find(t => t.name === 'create_cell')!;
      const result = await createCellTool.execute({
        cell_type: 'code',
        source: 'test'
      });

      expect(result.success).toBe(false);
      expect(result.error).toBe('No active notebook');
    });
  });

  describe('update_cell', () => {
    it('should update cell content successfully', async () => {
      mockUpdateCell.mockReturnValue({ success: true });

      const updateCellTool = tools.find(t => t.name === 'update_cell')!;
      const result = await updateCellTool.execute({
        index: 1,
        source: 'new content'
      });

      expect(result.success).toBe(true);
      expect(mockUpdateCell).toHaveBeenCalledWith(1, 'new content');
    });

    it('should return error for invalid index', async () => {
      mockUpdateCell.mockReturnValue({
        success: false,
        error: 'Invalid cell index: 99'
      });

      const updateCellTool = tools.find(t => t.name === 'update_cell')!;
      const result = await updateCellTool.execute({
        index: 99,
        source: 'test'
      });

      expect(result.success).toBe(false);
      expect(result.error).toBe('Invalid cell index: 99');
    });
  });

  describe('delete_cell', () => {
    it('should delete cell successfully', async () => {
      mockDeleteCell.mockReturnValue({ success: true });

      const deleteCellTool = tools.find(t => t.name === 'delete_cell')!;
      const result = await deleteCellTool.execute({ index: 1 });

      expect(result.success).toBe(true);
      expect(mockDeleteCell).toHaveBeenCalledWith(1);
    });

    it('should require confirmation (WRITE safety)', () => {
      const deleteCellTool = tools.find(t => t.name === 'delete_cell')!;
      expect(deleteCellTool.safetyLevel).toBe(ToolSafetyLevel.WRITE);
      expect(deleteCellTool.alwaysConfirm).toBe(true);
    });

    it('should return error for invalid index', async () => {
      mockDeleteCell.mockReturnValue({
        success: false,
        error: 'Invalid cell index: -1'
      });

      const deleteCellTool = tools.find(t => t.name === 'delete_cell')!;
      const result = await deleteCellTool.execute({ index: -1 });

      expect(result.success).toBe(false);
      expect(result.error).toBe('Invalid cell index: -1');
    });
  });

  describe('get_cell_content', () => {
    it('should get code cell content', async () => {
      mockGetCellContent.mockReturnValue({
        success: true,
        cellType: 'code',
        source: 'print("test")'
      });

      const getCellContentTool = tools.find(
        t => t.name === 'get_cell_content'
      )!;
      const result = await getCellContentTool.execute({ index: 1 });

      expect(result.success).toBe(true);
      expect((result.result as any).cell_type).toBe('code');
      expect((result.result as any).source).toBe('print("test")');
    });

    it('should get markdown cell content', async () => {
      mockGetCellContent.mockReturnValue({
        success: true,
        cellType: 'markdown',
        source: '# Title'
      });

      const getCellContentTool = tools.find(
        t => t.name === 'get_cell_content'
      )!;
      const result = await getCellContentTool.execute({ index: 2 });

      expect(result.success).toBe(true);
      expect((result.result as any).cell_type).toBe('markdown');
    });

    it('should return error for invalid index', async () => {
      mockGetCellContent.mockReturnValue({
        success: false,
        error: 'Invalid cell index: 99'
      });

      const getCellContentTool = tools.find(
        t => t.name === 'get_cell_content'
      )!;
      const result = await getCellContentTool.execute({ index: 99 });

      expect(result.success).toBe(false);
    });

    it('should have READ safety level', () => {
      const getCellContentTool = tools.find(
        t => t.name === 'get_cell_content'
      )!;
      expect(getCellContentTool.safetyLevel).toBe(ToolSafetyLevel.READ);
    });
  });

  describe('get_notebook_content', () => {
    it('should get empty notebook content', async () => {
      mockGetNotebookContent.mockReturnValue({
        success: true,
        cells: []
      });

      const getNotebookContentTool = tools.find(
        t => t.name === 'get_notebook_content'
      )!;
      const result = await getNotebookContentTool.execute({});

      expect(result.success).toBe(true);
      expect((result.result as any).cells).toEqual([]);
    });

    it('should get notebook with cells', async () => {
      mockGetNotebookContent.mockReturnValue({
        success: true,
        cells: [
          {
            type: 'code',
            source: 'x = 1',
            execution_count: 1,
            outputs_count: 0,
            has_error: false
          },
          { type: 'markdown', source: '# Title' }
        ]
      });

      const getNotebookContentTool = tools.find(
        t => t.name === 'get_notebook_content'
      )!;
      const result = await getNotebookContentTool.execute({});

      expect(result.success).toBe(true);
      expect((result.result as any).cells).toHaveLength(2);
    });

    it('should return error when no active notebook', async () => {
      mockGetNotebookContent.mockReturnValue({
        success: false,
        error: 'No active notebook'
      });

      const getNotebookContentTool = tools.find(
        t => t.name === 'get_notebook_content'
      )!;
      const result = await getNotebookContentTool.execute({});

      expect(result.success).toBe(false);
    });

    it('should have READ safety level', () => {
      const getNotebookContentTool = tools.find(
        t => t.name === 'get_notebook_content'
      )!;
      expect(getNotebookContentTool.safetyLevel).toBe(ToolSafetyLevel.READ);
    });
  });

  describe('execute_cell', () => {
    it('should execute cell successfully', async () => {
      mockExecuteCell.mockResolvedValue({ success: true });

      const executeCellTool = tools.find(t => t.name === 'execute_cell')!;
      const result = await executeCellTool.execute({ index: 1 });

      expect(result.success).toBe(true);
      expect(mockExecuteCell).toHaveBeenCalledWith(1);
    });

    it('should render markdown cell successfully', async () => {
      mockExecuteCell.mockResolvedValue({ success: true });

      const executeCellTool = tools.find(t => t.name === 'execute_cell')!;
      const result = await executeCellTool.execute({ index: 2 });

      expect(result.success).toBe(true);
      expect(mockExecuteCell).toHaveBeenCalledWith(2);
    });

    it('should return error for invalid index', async () => {
      mockExecuteCell.mockResolvedValue({
        success: false,
        error: 'Invalid cell index: 99'
      });

      const executeCellTool = tools.find(t => t.name === 'execute_cell')!;
      const result = await executeCellTool.execute({ index: 99 });

      expect(result.success).toBe(false);
      expect(result.error).toBe('Invalid cell index: 99');
    });

    it('should have EXECUTE safety level', () => {
      const executeCellTool = tools.find(t => t.name === 'execute_cell')!;
      expect(executeCellTool.safetyLevel).toBe(ToolSafetyLevel.EXECUTE);
    });

    it('should have updated description mentioning markdown', () => {
      const executeCellTool = tools.find(t => t.name === 'execute_cell')!;
      expect(executeCellTool.description).toContain('markdown');
      expect(executeCellTool.description).toContain('render');
    });
  });

  describe('get_cell_output', () => {
    it('should get text output', async () => {
      mockGetCellMetadata.mockReturnValue({
        success: true,
        execution_count: 1,
        outputs_count: 1,
        has_error: false
      });
      mockGetCellOutput.mockReturnValue({
        success: true,
        outputs: [{ type: 'text', text: 'Hello World' }]
      });

      const getCellOutputTool = tools.find(t => t.name === 'get_cell_output')!;
      const result = await getCellOutputTool.execute({ index: 1 });

      expect(result.success).toBe(true);
      expect((result.result as any).output_count).toBe(1);
      expect((result.result as any).has_errors).toBe(false);
    });

    it('should get output with image', async () => {
      mockGetCellMetadata.mockReturnValue({
        success: true,
        execution_count: 2,
        outputs_count: 1,
        has_error: false
      });
      mockGetCellOutput.mockReturnValue({
        success: true,
        outputs: [{ type: 'image', data: 'base64data', mimeType: 'image/png' }]
      });

      const getCellOutputTool = tools.find(t => t.name === 'get_cell_output')!;
      const result = await getCellOutputTool.execute({ index: 2 });

      expect(result.success).toBe(true);
      expect((result.result as any).has_images).toBe(true);
    });

    it('should get error output', async () => {
      mockGetCellMetadata.mockReturnValue({
        success: true,
        execution_count: 3,
        outputs_count: 1,
        has_error: true
      });
      mockGetCellOutput.mockReturnValue({
        success: true,
        outputs: [{ type: 'error', text: 'NameError' }]
      });

      const getCellOutputTool = tools.find(t => t.name === 'get_cell_output')!;
      const result = await getCellOutputTool.execute({ index: 3 });

      expect(result.success).toBe(true);
      expect((result.result as any).has_errors).toBe(true);
    });

    it('should return error for non-code cell', async () => {
      mockGetCellOutput.mockReturnValue({
        success: false,
        error: 'Cell is not a code cell'
      });

      const getCellOutputTool = tools.find(t => t.name === 'get_cell_output')!;
      const result = await getCellOutputTool.execute({ index: 1 });

      expect(result.success).toBe(false);
      expect(result.error).toBe('Cell is not a code cell');
    });

    it('should have READ safety level', () => {
      const getCellOutputTool = tools.find(t => t.name === 'get_cell_output')!;
      expect(getCellOutputTool.safetyLevel).toBe(ToolSafetyLevel.READ);
    });
  });

  describe('analyze_image', () => {
    it('should analyze image successfully', async () => {
      mockGetCellOutput.mockReturnValue({
        success: true,
        outputs: [{ type: 'image', data: 'base64data', mimeType: 'image/png' }]
      });

      const analyzeImageTool = tools.find(t => t.name === 'analyze_image')!;
      const result = await analyzeImageTool.execute({
        cell_index: 1,
        context: 'What is shown?'
      });

      expect(result.success).toBe(true);
      expect(result.result).toHaveProperty('analysis');
    });

    it('should analyze without context', async () => {
      mockGetCellOutput.mockReturnValue({
        success: true,
        outputs: [{ type: 'image', data: 'base64data', mimeType: 'image/png' }]
      });

      const analyzeImageTool = tools.find(t => t.name === 'analyze_image')!;
      const result = await analyzeImageTool.execute({ cell_index: 1 });

      expect(result.success).toBe(true);
    });

    it('should return error when no image in cell', async () => {
      mockGetCellOutput.mockReturnValue({
        success: true,
        outputs: []
      });

      const analyzeImageTool = tools.find(t => t.name === 'analyze_image')!;
      const result = await analyzeImageTool.execute({ cell_index: 1 });

      expect(result.success).toBe(false);
      expect(result.error).toContain('No image found');
    });

    it('should have READ safety level', () => {
      const analyzeImageTool = tools.find(t => t.name === 'analyze_image')!;
      expect(analyzeImageTool.safetyLevel).toBe(ToolSafetyLevel.READ);
    });
  });

  describe('Safety Levels', () => {
    it('should have correct safety levels for all tools', () => {
      const toolSafetyMap: Record<string, ToolSafetyLevel> = {
        create_cell: ToolSafetyLevel.WRITE,
        update_cell: ToolSafetyLevel.WRITE,
        delete_cell: ToolSafetyLevel.WRITE,
        get_cell_content: ToolSafetyLevel.READ,
        get_notebook_content: ToolSafetyLevel.READ,
        execute_cell: ToolSafetyLevel.EXECUTE,
        get_cell_output: ToolSafetyLevel.READ,
        analyze_image: ToolSafetyLevel.READ
      };

      tools.forEach((tool: any) => {
        expect(tool.safetyLevel).toBe(toolSafetyMap[tool.name]);
      });
    });

    it('should have correct categories for all tools', () => {
      tools.forEach((tool: any) => {
        expect(tool.category).toBe('notebook');
      });
    });
  });

  describe('Parameter Validation', () => {
    it('create_cell should require cell_type and source', () => {
      const createCellTool = tools.find(t => t.name === 'create_cell')!;
      expect(createCellTool.parameters.required).toContain('cell_type');
      expect(createCellTool.parameters.required).toContain('source');
    });

    it('update_cell should require index and source', () => {
      const updateCellTool = tools.find(t => t.name === 'update_cell')!;
      expect(updateCellTool.parameters.required).toContain('index');
      expect(updateCellTool.parameters.required).toContain('source');
    });

    it('delete_cell should require index', () => {
      const deleteCellTool = tools.find(t => t.name === 'delete_cell')!;
      expect(deleteCellTool.parameters.required).toContain('index');
    });

    it('execute_cell should require index', () => {
      const executeCellTool = tools.find(t => t.name === 'execute_cell')!;
      expect(executeCellTool.parameters.required).toContain('index');
    });

    it('get_cell_output should require index', () => {
      const getCellOutputTool = tools.find(t => t.name === 'get_cell_output')!;
      expect(getCellOutputTool.parameters.required).toContain('index');
    });

    it('analyze_image should require cell_index', () => {
      const analyzeImageTool = tools.find(t => t.name === 'analyze_image')!;
      expect(analyzeImageTool.parameters.required).toContain('cell_index');
    });
  });
});
