import { ToolValidator } from '../tool-validator';
import { ITool, IToolParameters, ToolSafetyLevel } from '../tools';

/**
 * Helper для создания тестового инструмента с параметрами
 */
function createToolWithParams(params: IToolParameters): ITool {
  return {
    name: 'test_tool',
    description: 'Test tool',
    parameters: params,
    execute: async () => ({ success: true, result: 'ok' }),
    safetyLevel: ToolSafetyLevel.READ,
    category: 'notebook'
  };
}

describe('ToolValidator', () => {
  describe('validate - required parameters', () => {
    it('должен проходить валидацию с всеми required параметрами', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          name: { type: 'string' },
          value: { type: 'integer' }
        },
        required: ['name', 'value']
      });

      const result = ToolValidator.validate(tool, {
        name: 'test',
        value: 42
      });

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('должен failing валидацию без required параметра', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          name: { type: 'string' },
          value: { type: 'integer' }
        },
        required: ['name', 'value']
      });

      const result = ToolValidator.validate(tool, { name: 'test' });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Missing required parameter: value');
    });

    it('должен failing валидацию с undefined required параметром', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          name: { type: 'string' }
        },
        required: ['name']
      });

      const result = ToolValidator.validate(tool, { name: undefined });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Missing required parameter: name');
    });

    it('должен passing валидацию без required параметров', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          name: { type: 'string' }
        }
      });

      const result = ToolValidator.validate(tool, {});

      expect(result.valid).toBe(true);
    });
  });

  describe('validate - type conversion', () => {
    it('должен конвертировать number в string', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          value: { type: 'string' }
        },
        required: ['value']
      });

      const result = ToolValidator.validate(tool, { value: 123 as any });

      expect(result.valid).toBe(true);
      expect(result.sanitizedArgs.value).toBe('123');
    });

    it('должен конвертировать string в integer', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          value: { type: 'integer' }
        },
        required: ['value']
      });

      const result = ToolValidator.validate(tool, { value: '42' as any });

      expect(result.valid).toBe(true);
      expect(result.sanitizedArgs.value).toBe(42);
    });

    it('должен failing конвертацию нечисловой строки в integer', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          value: { type: 'integer' }
        },
        required: ['value']
      });

      const result = ToolValidator.validate(tool, { value: 'abc' as any });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Parameter "value" must be an integer');
    });

    it('должен округлять float до integer', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          value: { type: 'integer' }
        },
        required: ['value']
      });

      const result = ToolValidator.validate(tool, { value: 3.7 });

      expect(result.valid).toBe(true);
      expect(result.sanitizedArgs.value).toBe(3);
    });

    it('должен конвертировать string в boolean', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          flag: { type: 'boolean' }
        }
      });

      const result = ToolValidator.validate(tool, { flag: 'true' as any });

      expect(result.valid).toBe(true);
      expect(result.sanitizedArgs.flag).toBe(true);
    });

    it('должен конвертировать string "false" в boolean', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          flag: { type: 'boolean' }
        }
      });

      const result = ToolValidator.validate(tool, { flag: 'false' as any });

      expect(result.valid).toBe(true);
      expect(result.sanitizedArgs.flag).toBe(false);
    });
  });

  describe('validate - enum validation', () => {
    it('должен passing валидацию с допустимым enum значением', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          cell_type: { type: 'string', enum: ['code', 'markdown'] }
        },
        required: ['cell_type']
      });

      const result = ToolValidator.validate(tool, { cell_type: 'code' });

      expect(result.valid).toBe(true);
    });

    it('должен failing валидацию с недопустимым enum значением', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          cell_type: { type: 'string', enum: ['code', 'markdown'] }
        },
        required: ['cell_type']
      });

      const result = ToolValidator.validate(tool, { cell_type: 'raw' });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Parameter "cell_type" must be one of: code, markdown'
      );
    });
  });

  describe('validate - unknown parameters', () => {
    it('должен удалять неизвестные параметры', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          name: { type: 'string' }
        },
        required: ['name']
      });

      const result = ToolValidator.validate(tool, {
        name: 'test',
        unknown_param: 'should be removed'
      });

      expect(result.valid).toBe(true);
      expect(result.sanitizedArgs.unknown_param).toBeUndefined();
    });
  });

  describe('validate - path validation', () => {
    it('должен passing валидацию с относительным путём', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          path: { type: 'string' }
        },
        required: ['path']
      });

      const result = ToolValidator.validate(tool, { path: 'folder/file.txt' });

      expect(result.valid).toBe(true);
    });

    it('должен failing валидацию с path traversal (..)', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          path: { type: 'string' }
        },
        required: ['path']
      });

      const result = ToolValidator.validate(tool, { path: '../secret.txt' });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Path "../secret.txt" is not allowed (no .. or absolute paths)'
      );
    });

    it('должен failing валидацию с абсолютным путём', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          path: { type: 'string' }
        },
        required: ['path']
      });

      const result = ToolValidator.validate(tool, { path: '/etc/passwd' });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Path "/etc/passwd" is not allowed (no .. or absolute paths)'
      );
    });
  });

  describe('validate - index validation', () => {
    it('должен passing валидацию с неотрицательным integer index', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          index: { type: 'integer' }
        },
        required: ['index']
      });

      const result = ToolValidator.validate(tool, { index: 5 });

      expect(result.valid).toBe(true);
      expect(result.sanitizedArgs.index).toBe(5);
    });

    it('должен failing валидацию с отрицательным index', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          index: { type: 'integer' }
        },
        required: ['index']
      });

      const result = ToolValidator.validate(tool, { index: -1 });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Index must be non-negative');
    });

    it('должен failing валидацию с float index', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          index: { type: 'integer' }
        },
        required: ['index']
      });

      const result = ToolValidator.validate(tool, { index: 3.5 });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Index must be an integer');
    });
  });

  describe('validate - source size limit', () => {
    it('должен passing валидацию с source нормального размера', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          source: { type: 'string' }
        },
        required: ['source']
      });

      const result = ToolValidator.validate(tool, { source: 'x'.repeat(1000) });

      expect(result.valid).toBe(true);
    });

    it('должен failing валидацию с слишком большим source', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          source: { type: 'string' }
        },
        required: ['source']
      });

      const result = ToolValidator.validate(tool, {
        source: 'x'.repeat(100001)
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Source too large: 100001 chars (max 100000)'
      );
    });
  });

  describe('validate - shell command security', () => {
    it('должен passing валидацию с безопасной командой', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          command: { type: 'string' }
        },
        required: ['command']
      });

      const result = ToolValidator.validate(tool, { command: 'pip list' });

      expect(result.valid).toBe(true);
    });

    it('должен failing валидацию с "rm -rf /"', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          command: { type: 'string' }
        },
        required: ['command']
      });

      const result = ToolValidator.validate(tool, { command: 'rm -rf /' });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Command contains blocked pattern: "rm -rf /"'
      );
    });

    it('должен failing валидацию с "rm -rf ~"', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          command: { type: 'string' }
        },
        required: ['command']
      });

      const result = ToolValidator.validate(tool, { command: 'rm -rf ~' });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Command contains blocked pattern: "rm -rf ~"'
      );
    });

    it('должен failing валидацию с "mkfs"', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          command: { type: 'string' }
        },
        required: ['command']
      });

      const result = ToolValidator.validate(tool, {
        command: 'mkfs.ext4 /dev/sda'
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Command contains blocked pattern: "mkfs"'
      );
    });

    it('должен failing валидацию с "dd if="', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          command: { type: 'string' }
        },
        required: ['command']
      });

      const result = ToolValidator.validate(tool, {
        command: 'dd if=/dev/zero'
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Command contains blocked pattern: "dd if="'
      );
    });

    it('должен failing валидацию с fork bomb ":()"', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          command: { type: 'string' }
        },
        required: ['command']
      });

      const result = ToolValidator.validate(tool, { command: ':(){ :|:& };:' });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Command contains blocked pattern: ":()"'
      );
    });

    it('должен failing валидацию с "shutdown"', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          command: { type: 'string' }
        },
        required: ['command']
      });

      const result = ToolValidator.validate(tool, { command: 'shutdown now' });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Command contains blocked pattern: "shutdown"'
      );
    });

    it('должен failing валидацию с "reboot"', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          command: { type: 'string' }
        },
        required: ['command']
      });

      const result = ToolValidator.validate(tool, { command: 'reboot' });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Command contains blocked pattern: "reboot"'
      );
    });

    it('должен failing валидацию с "halt"', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          command: { type: 'string' }
        },
        required: ['command']
      });

      const result = ToolValidator.validate(tool, { command: 'halt' });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Command contains blocked pattern: "halt"'
      );
    });

    it('должен failing валидацию с "poweroff"', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          command: { type: 'string' }
        },
        required: ['command']
      });

      const result = ToolValidator.validate(tool, { command: 'poweroff' });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Command contains blocked pattern: "poweroff"'
      );
    });

    it('должен failing валидацию с командой содержащей опасный паттерн в середине', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          command: { type: 'string' }
        },
        required: ['command']
      });

      const result = ToolValidator.validate(tool, {
        command: 'echo test && shutdown && echo done'
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Command contains blocked pattern: "shutdown"'
      );
    });
  });

  describe('validate - timeout validation', () => {
    it('должен passing валидацию с timeout в допустимом диапазоне', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          timeout: { type: 'number' }
        }
      });

      const result = ToolValidator.validate(tool, { timeout: 60 });

      expect(result.valid).toBe(true);
    });

    it('должен passing валидацию с timeout = 0', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          timeout: { type: 'number' }
        }
      });

      const result = ToolValidator.validate(tool, { timeout: 0 });

      expect(result.valid).toBe(true);
    });

    it('должен passing валидацию с timeout = 600', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          timeout: { type: 'number' }
        }
      });

      const result = ToolValidator.validate(tool, { timeout: 600 });

      expect(result.valid).toBe(true);
    });

    it('должен failing валидацию с timeout < 0', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          timeout: { type: 'number' }
        }
      });

      const result = ToolValidator.validate(tool, { timeout: -1 });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Timeout must be between 0 and 600 seconds'
      );
    });

    it('должен failing валидацию с timeout > 600', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          timeout: { type: 'number' }
        }
      });

      const result = ToolValidator.validate(tool, { timeout: 601 });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        'Timeout must be between 0 and 600 seconds'
      );
    });
  });

  describe('validate - sanitized args', () => {
    it('должен возвращать sanitizedArgs с конвертированными значениями', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          name: { type: 'string' },
          count: { type: 'integer' },
          enabled: { type: 'boolean' }
        },
        required: ['name']
      });

      const result = ToolValidator.validate(tool, {
        name: 'test',
        count: '10' as any,
        enabled: 'true' as any
      });

      expect(result.valid).toBe(true);
      expect(result.sanitizedArgs.name).toBe('test');
      expect(result.sanitizedArgs.count).toBe(10);
      expect(result.sanitizedArgs.enabled).toBe(true);
    });

    it('должен сохранять известные параметры без изменений', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          value: { type: 'string' }
        }
      });

      const result = ToolValidator.validate(tool, { value: 'unchanged' });

      expect(result.sanitizedArgs.value).toBe('unchanged');
    });
  });

  describe('validate - edge cases', () => {
    it('должен обрабатывать null в required параметре', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {
          value: { type: 'string' }
        },
        required: ['value']
      });

      const result = ToolValidator.validate(tool, { value: null as any });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Missing required parameter: value');
    });

    it('должен обрабатывать пустые свойства', () => {
      const tool = createToolWithParams({
        type: 'object',
        properties: {}
      });

      const result = ToolValidator.validate(tool, { unknown: 'value' });

      expect(result.valid).toBe(true);
      expect(result.sanitizedArgs.unknown).toBeUndefined();
    });
  });
});
