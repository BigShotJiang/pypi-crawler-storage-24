/**
 * @jest-environment jsdom
 */

import { createFileTools } from '../tools/file-tools';
import { ToolSafetyLevel } from '../tools';

const mockReadFile = jest.fn();
const mockWriteFile = jest.fn();
const mockListDirectory = jest.fn();
const mockCreateNotebook = jest.fn();
const mockDeleteFile = jest.fn();
const mockRenameFile = jest.fn();

const mockJupyterService = {
  readFile: mockReadFile,
  writeFile: mockWriteFile,
  listDirectory: mockListDirectory,
  createNotebook: mockCreateNotebook,
  deleteFile: mockDeleteFile,
  renameFile: mockRenameFile
} as any;

jest.mock('../jupyter-service', () => ({
  JupyterService: jest.fn().mockImplementation(() => mockJupyterService)
}));

describe('File Tools', () => {
  let tools: ReturnType<typeof createFileTools>;

  beforeEach(() => {
    jest.clearAllMocks();
    tools = createFileTools(mockJupyterService);
  });

  describe('Tool Definitions', () => {
    it('should create 6 tools', () => {
      expect(tools).toHaveLength(6);
    });

    it('should have correct tool names', () => {
      const toolNames = tools.map(t => t.name);
      expect(toolNames).toContain('read_file');
      expect(toolNames).toContain('write_file');
      expect(toolNames).toContain('list_directory');
      expect(toolNames).toContain('create_notebook');
      expect(toolNames).toContain('delete_file');
      expect(toolNames).toContain('rename_file');
    });
  });

  describe('read_file', () => {
    let readFileTool: any;

    beforeEach(() => {
      readFileTool = tools.find(t => t.name === 'read_file')!;
    });

    it('should read .py file successfully', async () => {
      mockReadFile.mockResolvedValue({
        success: true,
        content: 'def hello():\n    print("world")',
        size: 31
      });

      const result = await readFileTool.execute({ path: 'test.py' });

      expect(result.success).toBe(true);
      expect((result.result as any).content).toContain('def hello()');
    });

    it('should read .json file successfully', async () => {
      mockReadFile.mockResolvedValue({
        success: true,
        content: '{"key": "value"}',
        size: 17
      });

      const result = await readFileTool.execute({ path: 'config.json' });

      expect(result.success).toBe(true);
    });

    it('should read .csv file successfully', async () => {
      mockReadFile.mockResolvedValue({
        success: true,
        content: 'name,age\nJohn,30\nJane,25',
        size: 29
      });

      const result = await readFileTool.execute({ path: 'data.csv' });

      expect(result.success).toBe(true);
      expect((result.result as any).lines).toBe(3);
    });

    it('should limit lines with max_lines parameter', async () => {
      mockReadFile.mockResolvedValue({
        success: true,
        content: 'line1\nline2\nline3\nline4\nline5',
        size: 35
      });

      const result = await readFileTool.execute({
        path: 'large.txt',
        max_lines: 2
      });

      expect(result.success).toBe(true);
      expect((result.result as any).content).toBe('line1\nline2');
      expect((result.result as any).truncated).toBe(true);
    });

    it('should return error for non-existent file', async () => {
      mockReadFile.mockResolvedValue({
        success: false,
        error: 'File not found: missing.py'
      });

      const result = await readFileTool.execute({ path: 'missing.py' });

      expect(result.success).toBe(false);
      expect(result.error).toBe('File not found: missing.py');
    });

    it('should truncate files over 500KB', async () => {
      const largeContent = 'x'.repeat(600 * 1024);
      mockReadFile.mockResolvedValue({
        success: true,
        content: largeContent,
        size: 600 * 1024
      });

      const result = await readFileTool.execute({ path: 'large.txt' });

      expect(result.success).toBe(true);
      expect((result.result as any).truncated).toBe(true);
      expect((result.result as any).content.length).toBe(500 * 1024);
    });

    it('should reject binary files', async () => {
      mockReadFile.mockResolvedValue({
        success: true,
        content: '\x00\x01\x02',
        size: 3
      });

      const result = await readFileTool.execute({ path: 'image.png' });

      expect(result.success).toBe(false);
      expect(result.error).toContain('appears to be binary');
    });

    it('should have READ safety level', () => {
      expect(readFileTool.safetyLevel).toBe(ToolSafetyLevel.READ);
    });

    it('should require path parameter', () => {
      expect(readFileTool.parameters.required).toContain('path');
    });
  });

  describe('write_file', () => {
    let writeFileTool: any;

    beforeEach(() => {
      writeFileTool = tools.find(t => t.name === 'write_file')!;
    });

    it('should create new file successfully', async () => {
      mockWriteFile.mockResolvedValue({ success: true, created: true });

      const result = await writeFileTool.execute({
        path: 'new_file.py',
        content: 'print("hello")'
      });

      expect(result.success).toBe(true);
      expect((result.result as any).path).toBe('new_file.py');
      expect((result.result as any).created).toBe(true);
    });

    it('should overwrite existing file', async () => {
      mockWriteFile.mockResolvedValue({ success: true, created: false });

      const result = await writeFileTool.execute({
        path: 'existing.py',
        content: 'updated content'
      });

      expect(result.success).toBe(true);
      expect((result.result as any).created).toBe(false);
    });

    it('should create nested directories', async () => {
      mockWriteFile.mockResolvedValue({ success: true, created: true });

      const result = await writeFileTool.execute({
        path: 'nested/dir/file.txt',
        content: 'content'
      });

      expect(result.success).toBe(true);
      expect(mockWriteFile).toHaveBeenCalledWith(
        'nested/dir/file.txt',
        'content'
      );
    });

    it('should reject .ipynb files', async () => {
      const result = await writeFileTool.execute({
        path: 'notebook.ipynb',
        content: '{}'
      });

      expect(result.success).toBe(false);
      expect(result.error).toContain('Cannot write .ipynb files directly');
    });

    it('should return error on failure', async () => {
      mockWriteFile.mockResolvedValue({
        success: false,
        error: 'Permission denied'
      });

      const result = await writeFileTool.execute({
        path: 'protected.txt',
        content: 'data'
      });

      expect(result.success).toBe(false);
      expect(result.error).toBe('Permission denied');
    });

    it('should have WRITE safety level', () => {
      expect(writeFileTool.safetyLevel).toBe(ToolSafetyLevel.WRITE);
    });

    it('should require path and content parameters', () => {
      expect(writeFileTool.parameters.required).toContain('path');
      expect(writeFileTool.parameters.required).toContain('content');
    });
  });

  describe('list_directory', () => {
    let listDirectoryTool: any;

    beforeEach(() => {
      listDirectoryTool = tools.find(t => t.name === 'list_directory')!;
    });

    it('should list root directory', async () => {
      mockListDirectory.mockResolvedValue({
        success: true,
        items: [
          { name: 'file1.py', type: 'file', size: 100 },
          { name: 'subdir', type: 'directory' }
        ]
      });

      const result = await listDirectoryTool.execute({ path: '' });

      expect(result.success).toBe(true);
      expect((result.result as any).path).toBe('.');
      expect((result.result as any).count).toBe(2);
    });

    it('should list nested directory', async () => {
      mockListDirectory.mockResolvedValue({
        success: true,
        items: [{ name: 'nested.py', type: 'file', size: 50 }]
      });

      const result = await listDirectoryTool.execute({ path: 'src/utils' });

      expect(result.success).toBe(true);
      expect((result.result as any).path).toBe('src/utils');
    });

    it('should return error for non-existent directory', async () => {
      mockListDirectory.mockResolvedValue({
        success: false,
        error: 'Directory not found: missing'
      });

      const result = await listDirectoryTool.execute({ path: 'missing' });

      expect(result.success).toBe(false);
      expect(result.error).toBe('Directory not found: missing');
    });

    it('should format file sizes correctly', async () => {
      mockListDirectory.mockResolvedValue({
        success: true,
        items: [
          { name: 'small.py', type: 'file', size: 500 },
          { name: 'medium.txt', type: 'file', size: 2500 },
          { name: 'large.bin', type: 'file', size: 1500000 }
        ]
      });

      const result = await listDirectoryTool.execute({ path: '' });

      expect(result.success).toBe(true);
      expect((result.result as any).summary).toContain('500 B');
      expect((result.result as any).summary).toContain('2.4 KB');
      expect((result.result as any).summary).toContain('1.4 MB');
    });

    it('should show correct icons for different types', async () => {
      mockListDirectory.mockResolvedValue({
        success: true,
        items: [
          { name: 'folder', type: 'directory' },
          { name: 'notebook.ipynb', type: 'notebook' },
          { name: 'script.py', type: 'file' }
        ]
      });

      const result = await listDirectoryTool.execute({ path: '' });

      expect(result.success).toBe(true);
      expect((result.result as any).summary).toContain('📁 folder');
      expect((result.result as any).summary).toContain('📓 notebook.ipynb');
      expect((result.result as any).summary).toContain('📄 script.py');
    });

    it('should have READ safety level', () => {
      expect(listDirectoryTool.safetyLevel).toBe(ToolSafetyLevel.READ);
    });
  });

  describe('create_notebook', () => {
    let createNotebookTool: any;

    beforeEach(() => {
      createNotebookTool = tools.find(t => t.name === 'create_notebook')!;
    });

    it('should create notebook with extension', async () => {
      mockCreateNotebook.mockResolvedValue({
        success: true,
        path: 'new_notebook.ipynb'
      });

      const result = await createNotebookTool.execute({
        name: 'new_notebook.ipynb'
      });

      expect(result.success).toBe(true);
      expect((result.result as any).path).toBe('new_notebook.ipynb');
    });

    it('should create notebook without extension', async () => {
      mockCreateNotebook.mockResolvedValue({
        success: true,
        path: 'my_notebook.ipynb'
      });

      const result = await createNotebookTool.execute({ name: 'my_notebook' });

      expect(result.success).toBe(true);
      expect((result.result as any).path).toBe('my_notebook.ipynb');
    });

    it('should create notebook in specified directory', async () => {
      mockCreateNotebook.mockResolvedValue({
        success: true,
        path: 'workspace/my_notebook.ipynb'
      });

      const result = await createNotebookTool.execute({
        name: 'my_notebook.ipynb',
        path: 'workspace'
      });

      expect(result.success).toBe(true);
      expect(mockCreateNotebook).toHaveBeenCalledWith(
        'my_notebook.ipynb',
        'workspace'
      );
    });

    it('should return error when name is taken', async () => {
      mockCreateNotebook.mockResolvedValue({
        success: false,
        error: 'File already exists: existing.ipynb'
      });

      const result = await createNotebookTool.execute({
        name: 'existing.ipynb'
      });

      expect(result.success).toBe(false);
      expect(result.error).toBe('File already exists: existing.ipynb');
    });

    it('should have WRITE safety level', () => {
      expect(createNotebookTool.safetyLevel).toBe(ToolSafetyLevel.WRITE);
    });

    it('should require name parameter', () => {
      expect(createNotebookTool.parameters.required).toContain('name');
    });
  });

  describe('delete_file', () => {
    let deleteFileTool: any;

    beforeEach(() => {
      deleteFileTool = tools.find(t => t.name === 'delete_file')!;
    });

    it('should delete file successfully', async () => {
      mockDeleteFile.mockResolvedValue({ success: true });

      const result = await deleteFileTool.execute({
        path: 'file_to_delete.txt'
      });

      expect(result.success).toBe(true);
      expect((result.result as any).message).toContain('Deleted');
      expect(mockDeleteFile).toHaveBeenCalledWith('file_to_delete.txt');
    });

    it('should require confirmation (SYSTEM safety)', () => {
      expect(deleteFileTool.safetyLevel).toBe(ToolSafetyLevel.SYSTEM);
      expect(deleteFileTool.alwaysConfirm).toBe(true);
    });

    it('should return error for non-existent file', async () => {
      mockDeleteFile.mockResolvedValue({
        success: false,
        error: 'File not found: missing.txt'
      });

      const result = await deleteFileTool.execute({ path: 'missing.txt' });

      expect(result.success).toBe(false);
      expect(result.error).toBe('File not found: missing.txt');
    });

    it('should require path parameter', () => {
      expect(deleteFileTool.parameters.required).toContain('path');
    });
  });

  describe('rename_file', () => {
    let renameFileTool: any;

    beforeEach(() => {
      renameFileTool = tools.find(t => t.name === 'rename_file')!;
    });

    it('should rename file successfully', async () => {
      mockRenameFile.mockResolvedValue({ success: true });

      const result = await renameFileTool.execute({
        old_path: 'old_name.txt',
        new_path: 'new_name.txt'
      });

      expect(result.success).toBe(true);
      expect((result.result as any).message).toContain('old_name.txt');
      expect(mockRenameFile).toHaveBeenCalledWith(
        'old_name.txt',
        'new_name.txt'
      );
    });

    it('should move file to different directory', async () => {
      mockRenameFile.mockResolvedValue({ success: true });

      const result = await renameFileTool.execute({
        old_path: 'file.txt',
        new_path: 'subdir/file.txt'
      });

      expect(result.success).toBe(true);
      expect(mockRenameFile).toHaveBeenCalledWith(
        'file.txt',
        'subdir/file.txt'
      );
    });

    it('should return error when new name is taken', async () => {
      mockRenameFile.mockResolvedValue({
        success: false,
        error: 'File already exists: target.txt'
      });

      const result = await renameFileTool.execute({
        old_path: 'source.txt',
        new_path: 'target.txt'
      });

      expect(result.success).toBe(false);
      expect(result.error).toBe('File already exists: target.txt');
    });

    it('should return error for non-existent file', async () => {
      mockRenameFile.mockResolvedValue({
        success: false,
        error: 'File not found: missing.txt'
      });

      const result = await renameFileTool.execute({
        old_path: 'missing.txt',
        new_path: 'new.txt'
      });

      expect(result.success).toBe(false);
      expect(result.error).toBe('File not found: missing.txt');
    });

    it('should have WRITE safety level', () => {
      expect(renameFileTool.safetyLevel).toBe(ToolSafetyLevel.WRITE);
    });

    it('should require old_path and new_path parameters', () => {
      expect(renameFileTool.parameters.required).toContain('old_path');
      expect(renameFileTool.parameters.required).toContain('new_path');
    });
  });

  describe('Safety Levels', () => {
    it('should have correct safety levels for all tools', () => {
      const toolSafetyMap: Record<string, ToolSafetyLevel> = {
        read_file: ToolSafetyLevel.READ,
        write_file: ToolSafetyLevel.WRITE,
        list_directory: ToolSafetyLevel.READ,
        create_notebook: ToolSafetyLevel.WRITE,
        delete_file: ToolSafetyLevel.SYSTEM,
        rename_file: ToolSafetyLevel.WRITE
      };

      tools.forEach((tool: any) => {
        expect(tool.safetyLevel).toBe(toolSafetyMap[tool.name]);
      });
    });
  });
});
