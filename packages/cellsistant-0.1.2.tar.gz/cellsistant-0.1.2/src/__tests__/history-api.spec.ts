/**
 * @jest-environment jsdom
 */

import {
  listChats,
  saveChat,
  loadChat,
  deleteChat,
  exportChat,
  exportChatAsJson,
  IChatInfo,
  IChatData
} from '../history-api';
import { ILLMMessage } from '../api';

// Mock ServerConnection
jest.mock('@jupyterlab/services', () => ({
  ServerConnection: {
    makeSettings: jest.fn(() => ({
      baseUrl: 'http://localhost:8888/',
      init: {
        headers: {
          Authorization: 'Bearer test-token'
        }
      }
    })),
    makeRequest: jest.fn()
  }
}));

// Mock PageConfig
jest.mock('@jupyterlab/coreutils', () => ({
  PageConfig: {
    getToken: jest.fn(() => 'xsrf-token-123')
  },
  URLExt: {
    join: jest.fn((base, ...parts) => base + parts.join('/'))
  }
}));

describe('History API', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    globalThis.fetch = jest.fn();

    // Mock document.cookie
    Object.defineProperty(document, 'cookie', {
      writable: true,
      value: '_xsrf=xsrf-token-123'
    });
  });

  describe('listChats', () => {
    it('должен возвращать список чатов', async () => {
      const mockChats: IChatInfo[] = [
        {
          id: 'chat-1',
          title: 'First Chat',
          created_at: '2024-01-01T00:00:00Z',
          updated_at: '2024-01-01T00:00:00Z',
          message_count: 5
        },
        {
          id: 'chat-2',
          title: 'Second Chat',
          created_at: '2024-01-02T00:00:00Z',
          updated_at: '2024-01-02T00:00:00Z',
          message_count: 10
        }
      ];

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => ({ chats: mockChats })
      });

      const chats = await listChats();

      expect(chats).toEqual(mockChats);
      expect(globalThis.fetch).toHaveBeenCalledWith(
        'http://localhost:8888/ai-agent/history',
        expect.objectContaining({
          method: 'GET',
          credentials: 'same-origin'
        })
      );
    });

    it('должен возвращать пустой массив когда нет чатов', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => ({ chats: [] })
      });

      const chats = await listChats();
      expect(chats).toEqual([]);
    });

    it('должен выбрасывать ошибку при не 200 статусе', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 500,
        text: async () => JSON.stringify({ error: 'Server error' })
      });

      await expect(listChats()).rejects.toThrow('Server error');
    });

    it('должен обрабатывать не-JSON ответ', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 500,
        text: async () => 'Plain text error'
      });

      await expect(listChats()).rejects.toThrow(
        'Server error 500: Plain text error'
      );
    });
  });

  describe('saveChat', () => {
    it('должен сохранять чат с сообщениями', async () => {
      const messages: ILLMMessage[] = [
        { role: 'user', content: 'Hello' },
        { role: 'assistant', content: 'Hi there!' }
      ];

      const mockResult = {
        id: 'chat-123',
        title: 'New Chat',
        message: 'Chat saved successfully'
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => mockResult
      });

      const result = await saveChat(messages);

      expect(result).toEqual(mockResult);
      expect(globalThis.fetch).toHaveBeenCalledWith(
        'http://localhost:8888/ai-agent/history/save',
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
            'X-XSRFToken': 'xsrf-token-123'
          }),
          body: JSON.stringify({ messages }),
          credentials: 'same-origin'
        })
      );
    });

    it('должен сохранять чат с указанным ID', async () => {
      const messages: ILLMMessage[] = [{ role: 'user', content: 'Hello' }];

      const mockResult = {
        id: 'existing-chat',
        title: 'Updated Chat',
        message: 'Chat updated successfully'
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => mockResult
      });

      await saveChat(messages, 'existing-chat');

      expect(globalThis.fetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          body: JSON.stringify({ messages, id: 'existing-chat' })
        })
      );
    });

    it('должен сохранять чат с указанным заголовком', async () => {
      const messages: ILLMMessage[] = [{ role: 'user', content: 'Hello' }];

      const mockResult = {
        id: 'chat-123',
        title: 'Custom Title',
        message: 'Chat saved successfully'
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => mockResult
      });

      await saveChat(messages, undefined, 'Custom Title');

      expect(globalThis.fetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          body: JSON.stringify({ messages, title: 'Custom Title' })
        })
      );
    });

    it('должен выбрасывать ошибку при не 200 статусе', async () => {
      const messages: ILLMMessage[] = [{ role: 'user', content: 'Hello' }];

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 500,
        text: async () => JSON.stringify({ error: 'Save failed' })
      });

      await expect(saveChat(messages)).rejects.toThrow('Save failed');
    });
  });

  describe('loadChat', () => {
    it('должен загружать чат по ID', async () => {
      const mockChat: IChatData = {
        id: 'chat-123',
        title: 'Loaded Chat',
        created_at: '2024-01-01T00:00:00Z',
        updated_at: '2024-01-01T00:00:00Z',
        message_count: 5,
        messages: [
          { role: 'user', content: 'Hello' },
          { role: 'assistant', content: 'Hi!' }
        ]
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => mockChat
      });

      const chat = await loadChat('chat-123');

      expect(chat).toEqual(mockChat);
      expect(globalThis.fetch).toHaveBeenCalledWith(
        'http://localhost:8888/ai-agent/history/chat-123',
        expect.objectContaining({
          method: 'GET',
          credentials: 'same-origin'
        })
      );
    });

    it('должен выбрасывать ошибку когда чат не найден (404)', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 404,
        text: async () => 'Not found'
      });

      await expect(loadChat('nonexistent')).rejects.toThrow(
        'Chat not found: nonexistent'
      );
    });

    it('должен выбрасывать ошибку при не 200 статусе', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 500,
        text: async () => JSON.stringify({ error: 'Load failed' })
      });

      await expect(loadChat('chat-123')).rejects.toThrow('Load failed');
    });
  });

  describe('deleteChat', () => {
    it('должен удалять чат по ID', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        text: async () => JSON.stringify({ message: 'Deleted' })
      });

      await deleteChat('chat-123');

      expect(globalThis.fetch).toHaveBeenCalledWith(
        'http://localhost:8888/ai-agent/history/chat-123',
        expect.objectContaining({
          method: 'DELETE',
          headers: expect.objectContaining({
            'X-XSRFToken': 'xsrf-token-123'
          }),
          credentials: 'same-origin'
        })
      );
    });

    it('должен выбрасывать ошибку когда чат не найден (404)', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 404,
        text: async () => 'Not found'
      });

      await expect(deleteChat('nonexistent')).rejects.toThrow(
        'Chat not found: nonexistent'
      );
    });

    it('должен выбрасывать ошибку при не 200 статусе', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 500,
        text: async () => JSON.stringify({ error: 'Delete failed' })
      });

      await expect(deleteChat('chat-123')).rejects.toThrow('Delete failed');
    });
  });

  describe('exportChat', () => {
    it('должен скачивать чат как Markdown файл', async () => {
      const mockBlob = new Blob(['# Chat Export'], { type: 'text/markdown' });

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        headers: new Headers({
          'Content-Disposition': 'attachment; filename="chat-export.md"'
        }),
        blob: async () => mockBlob
      });

      // Mock URL.createObjectURL
      const mockUrl = 'blob:http://localhost/test-url';
      URL.createObjectURL = jest.fn(() => mockUrl);

      const clickSpy = jest.fn();
      const removeSpy = jest.fn();
      const revokeSpy = jest.fn();
      const appendChildSpy = jest.fn();

      document.createElement = jest.fn(
        () =>
          ({
            href: '',
            download: '',
            click: clickSpy
          }) as any
      );

      document.body.appendChild = appendChildSpy;
      document.body.removeChild = removeSpy;

      URL.revokeObjectURL = revokeSpy;

      await exportChat('chat-123');

      expect(globalThis.fetch).toHaveBeenCalledWith(
        'http://localhost:8888/ai-agent/history/chat-123/export',
        expect.objectContaining({
          method: 'GET',
          credentials: 'same-origin'
        })
      );
      expect(clickSpy).toHaveBeenCalled();
    });

    it('должен выбрасывать ошибку когда чат не найден (404)', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 404,
        text: async () => 'Not found'
      });

      await expect(exportChat('nonexistent')).rejects.toThrow(
        'Chat not found: nonexistent'
      );
    });

    it('должен выбрасывать ошибку при не 200 статусе', async () => {
      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 500,
        text: async () => JSON.stringify({ error: 'Export failed' })
      });

      await expect(exportChat('chat-123')).rejects.toThrow('Export failed');
    });
  });

  describe('exportChatAsJson', () => {
    beforeEach(() => {
      jest.useFakeTimers();
      jest.setSystemTime(new Date('2024-01-15T10:00:00Z'));
    });

    afterEach(() => {
      jest.useRealTimers();
    });

    it('должен экспортировать чат как JSON с timestamp', () => {
      const messages: ILLMMessage[] = [
        { role: 'user', content: 'Hello' },
        { role: 'assistant', content: 'Hi!' }
      ];

      let capturedJson: string | null = null;

      // Mock Blob - захватываем JSON
      jest.spyOn(globalThis, 'Blob').mockImplementation((data: any) => {
        capturedJson = data[0];
        return { type: 'application/json', size: 100 } as any;
      });

      // Mock URL.createObjectURL
      const mockUrl = 'blob:http://localhost/test-url';
      URL.createObjectURL = jest.fn(() => mockUrl);

      const clickSpy = jest.fn();

      const mockAnchor = {
        href: '',
        download: '',
        click: clickSpy
      } as any;

      document.createElement = jest.fn(() => mockAnchor);
      document.body.appendChild = jest.fn();
      document.body.removeChild = jest.fn();

      URL.revokeObjectURL = jest.fn();

      exportChatAsJson(messages, 'chat-123');

      // Проверяем что JSON валидный и содержит нужные поля
      const parsed = JSON.parse(capturedJson!);
      expect(parsed.exported_at).toBeDefined();
      expect(mockAnchor.download).toBe('chat-chat-123.json');
      expect(clickSpy).toHaveBeenCalled();
    });

    it('должен использовать timestamp в имени файла если нет chatId', () => {
      const messages: ILLMMessage[] = [{ role: 'user', content: 'Hello' }];

      jest.spyOn(globalThis, 'Blob').mockImplementation(
        () =>
          ({
            type: 'application/json',
            size: 100
          }) as any
      );

      URL.createObjectURL = jest.fn(() => 'blob:url');

      const mockAnchor = {
        href: '',
        download: '',
        click: jest.fn()
      } as any;

      document.createElement = jest.fn(() => mockAnchor);
      document.body.appendChild = jest.fn();
      document.body.removeChild = jest.fn();

      URL.revokeObjectURL = jest.fn();

      exportChatAsJson(messages);

      expect(mockAnchor.download).toMatch(/chat-\d+\.json/);
    });

    it('должен включать сообщения в JSON', () => {
      const messages: ILLMMessage[] = [
        { role: 'user', content: 'Hello' },
        { role: 'assistant', content: 'Hi!' }
      ];

      let capturedJson = '';

      jest.spyOn(globalThis, 'Blob').mockImplementation((data: any) => {
        capturedJson = data[0];
        return { type: 'application/json', size: 100 } as any;
      });

      URL.createObjectURL = jest.fn(() => 'blob:url');

      const mockAnchor = {
        href: '',
        download: '',
        click: jest.fn()
      } as any;

      document.createElement = jest.fn(() => mockAnchor);
      document.body.appendChild = jest.fn();
      document.body.removeChild = jest.fn();

      URL.revokeObjectURL = jest.fn();

      exportChatAsJson(messages);

      const parsed = JSON.parse(capturedJson);
      expect(parsed.messages).toEqual(messages);
      expect(parsed.exported_at).toBeDefined();
    });
  });

  describe('edge cases', () => {
    it('должен обрабатывать пустые сообщения при сохранении', async () => {
      const mockResult = {
        id: 'chat-123',
        title: 'Empty Chat',
        message: 'Chat saved successfully'
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => mockResult
      });

      await saveChat([]);

      expect(globalThis.fetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          body: JSON.stringify({ messages: [] })
        })
      );
    });

    it('должен обрабатывать сообщения с tool_calls', async () => {
      const messages: ILLMMessage[] = [
        {
          role: 'assistant',
          content: null,
          tool_calls: [
            {
              id: 'call_1',
              type: 'function',
              function: {
                name: 'create_cell',
                arguments: '{"cell_type": "code"}'
              }
            }
          ]
        }
      ];

      const mockResult = {
        id: 'chat-123',
        title: 'Tool Chat',
        message: 'Chat saved successfully'
      };

      (globalThis.fetch as jest.Mock).mockResolvedValue({
        status: 200,
        json: async () => mockResult
      });

      await saveChat(messages);

      expect(globalThis.fetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          body: JSON.stringify({ messages })
        })
      );
    });
  });
});
