/**
 * Уровни безопасности инструментов
 */
export enum ToolSafetyLevel {
  /** Только чтение — полностью безопасен */
  READ = 'read',
  /** Запись — модифицирует данные, но не выполняет код */
  WRITE = 'write',
  /** Выполнение — выполняет код или команды */
  EXECUTE = 'execute',
  /** Системный — доступ к ОС, файловой системе, деструктивные операции */
  SYSTEM = 'system'
}

/**
 * Категория инструмента
 */
export type ToolCategory =
  | 'notebook'
  | 'files'
  | 'shell'
  | 'packages'
  | 'search';

/**
 * Интерфейс инструмента (tool) для AI Agent
 */
export interface ITool {
  /** Название инструмента (уникальное) */
  name: string;

  /** Описание того, что делает инструмент */
  description: string;

  /** JSON Schema для параметров инструмента */
  parameters: IToolParameters;

  /** Функция выполнения инструмента */
  execute: (args: Record<string, unknown>) => Promise<IToolResult>;

  /** Уровень безопасности */
  safetyLevel: ToolSafetyLevel;

  /** Категория */
  category: ToolCategory;

  /** Требует подтверждения даже в auto-mode */
  alwaysConfirm?: boolean;
}

/**
 * JSON Schema для параметров инструмента
 */
export interface IToolParameters {
  type: 'object';
  properties: Record<string, IParameterProperty>;
  required?: string[];
}

/**
 * Свойство параметра в JSON Schema
 */
export interface IParameterProperty {
  type: string;
  description?: string;
  enum?: string[];
  default?: unknown;
}

/**
 * Результат выполнения инструмента
 */
export interface IToolResult {
  /** Успешно ли выполнился инструмент */
  success: boolean;

  /** Результат выполнения (любой сериализуемый тип) */
  result?: unknown;

  /** Сообщение об ошибке (если success = false) */
  error?: string;
}

/**
 * Вызов инструмента (для отправки в API)
 */
export interface IToolCall {
  /** Название инструмента */
  name: string;

  /** Аргументы инструмента */
  arguments: Record<string, unknown>;
}

/**
 * Сообщение о вызове инструмента (для UI)
 */
export interface IToolCallMessage {
  /** Название инструмента */
  name: string;

  /** Аргументы */
  arguments: Record<string, unknown>;

  /** Результат (после выполнения) */
  result?: IToolResult;

  /** Статус выполнения */
  status: 'pending' | 'completed' | 'error';
}

/**
 * Преобразовать ToolParameters в формат для OpenRouter API
 */
export function toolParametersToFunctionDefinition(tool: ITool): {
  type: string;
  function: {
    name: string;
    description: string;
    parameters: IToolParameters;
  };
} {
  return {
    type: 'function',
    function: {
      name: tool.name,
      description: tool.description,
      parameters: tool.parameters
    }
  };
}
