import { URLExt, PageConfig } from '@jupyterlab/coreutils';
import { ServerConnection } from '@jupyterlab/services';
import { ILLMMessage } from './api';

/**
 * Информация о сохранённом чате
 */
export interface IChatInfo {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
  message_count: number;
}

/**
 * Полный данные чата (при загрузке)
 */
export interface IChatData extends IChatInfo {
  messages: ILLMMessage[];
}

/**
 * Результат сохранения чата
 */
export interface ISaveResult {
  id: string;
  title: string;
  message: string;
}

/**
 * Получить XSRF токен из настроек сервера или cookie
 */
function getXsrfToken(): string {
  // JupyterLab хранит токен в PageConfig
  const token = PageConfig.getToken();
  if (token) {
    return token;
  }

  // Пробуем из cookie
  const match = document.cookie.match(new RegExp('(^|; )_xsrf=([^;]+)'));
  return match ? match[2] : '';
}

/**
 * Получить список всех сохранённых чатов
 */
export async function listChats(): Promise<IChatInfo[]> {
  const settings = ServerConnection.makeSettings();
  const endpoint = URLExt.join(settings.baseUrl, 'ai-agent', 'history');

  const response = await fetch(endpoint, {
    method: 'GET',
    credentials: 'same-origin'
  });

  if (response.status !== 200) {
    const text = await response.text();
    try {
      const data = JSON.parse(text);
      throw new Error(data.error || `Server error: ${response.status}`);
    } catch {
      throw new Error(
        `Server error ${response.status}: ${text.substring(0, 200)}`
      );
    }
  }

  const data = await response.json();
  return data.chats || [];
}

/**
 * Сохранить текущий чат
 */
export async function saveChat(
  messages: ILLMMessage[],
  chatId?: string,
  title?: string
): Promise<ISaveResult> {
  const settings = ServerConnection.makeSettings();
  const endpoint = URLExt.join(settings.baseUrl, 'ai-agent', 'history', 'save');

  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };

  if (settings.init?.headers) {
    const initHeaders = settings.init.headers as Record<string, string>;
    Object.assign(headers, initHeaders);
  }

  const xsrfToken = getXsrfToken();
  if (xsrfToken) {
    headers['X-XSRFToken'] = xsrfToken;
  }

  const body: Record<string, unknown> = { messages };
  if (chatId) {
    body.id = chatId;
  }
  if (title) {
    body.title = title;
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
    credentials: 'same-origin'
  });

  if (response.status !== 200) {
    const text = await response.text();
    try {
      const data = JSON.parse(text);
      throw new Error(data.error || `Server error: ${response.status}`);
    } catch {
      throw new Error(
        `Server error ${response.status}: ${text.substring(0, 200)}`
      );
    }
  }

  return await response.json();
}

/**
 * Загрузить чат по ID
 */
export async function loadChat(chatId: string): Promise<IChatData> {
  const settings = ServerConnection.makeSettings();
  const endpoint = URLExt.join(settings.baseUrl, 'ai-agent', 'history', chatId);

  const response = await fetch(endpoint, {
    method: 'GET',
    credentials: 'same-origin'
  });

  if (response.status === 404) {
    throw new Error(`Chat not found: ${chatId}`);
  }

  if (response.status !== 200) {
    const text = await response.text();
    try {
      const data = JSON.parse(text);
      throw new Error(data.error || `Server error: ${response.status}`);
    } catch {
      throw new Error(
        `Server error ${response.status}: ${text.substring(0, 200)}`
      );
    }
  }

  return await response.json();
}

/**
 * Удалить чат по ID
 */
export async function deleteChat(chatId: string): Promise<void> {
  const settings = ServerConnection.makeSettings();
  const endpoint = URLExt.join(settings.baseUrl, 'ai-agent', 'history', chatId);

  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };

  if (settings.init?.headers) {
    const initHeaders = settings.init.headers as Record<string, string>;
    Object.assign(headers, initHeaders);
  }

  const xsrfToken = getXsrfToken();
  if (xsrfToken) {
    headers['X-XSRFToken'] = xsrfToken;
  }

  const response = await fetch(endpoint, {
    method: 'DELETE',
    headers,
    credentials: 'same-origin'
  });

  if (response.status === 404) {
    throw new Error(`Chat not found: ${chatId}`);
  }

  if (response.status !== 200) {
    const text = await response.text();
    try {
      const data = JSON.parse(text);
      throw new Error(data.error || `Server error: ${response.status}`);
    } catch {
      throw new Error(
        `Server error ${response.status}: ${text.substring(0, 200)}`
      );
    }
  }
}

/**
 * Экспортировать чат в Markdown (скачать файл)
 */
export async function exportChat(chatId: string): Promise<void> {
  const settings = ServerConnection.makeSettings();
  const endpoint = URLExt.join(
    settings.baseUrl,
    'ai-agent',
    'history',
    chatId,
    'export'
  );

  const response = await fetch(endpoint, {
    method: 'GET',
    credentials: 'same-origin'
  });

  if (response.status === 404) {
    throw new Error(`Chat not found: ${chatId}`);
  }

  if (response.status !== 200) {
    const text = await response.text();
    try {
      const data = JSON.parse(text);
      throw new Error(data.error || `Server error: ${response.status}`);
    } catch {
      throw new Error(
        `Server error ${response.status}: ${text.substring(0, 200)}`
      );
    }
  }

  // Получаем заголовок Content-Disposition для имени файла
  const contentDisposition = response.headers.get('Content-Disposition');
  let filename = 'chat.md';
  if (contentDisposition) {
    const match = contentDisposition.match(/filename="?(.+)"?/);
    if (match) {
      filename = match[1];
    }
  }

  // Скачиваем файл
  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
}

/**
 * Экспортировать текущий чат в JSON (скачать файл)
 */
export function exportChatAsJson(
  messages: ILLMMessage[],
  chatId?: string
): void {
  const data = {
    exported_at: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'),
    messages
  };

  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = chatId ? `chat-${chatId}.json` : `chat-${Date.now()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
}
