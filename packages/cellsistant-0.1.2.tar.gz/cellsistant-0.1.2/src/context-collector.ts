import { JupyterFrontEnd } from '@jupyterlab/application';
import { INotebookTracker, NotebookPanel } from '@jupyterlab/notebook';
import { CodeCellModel } from '@jupyterlab/cells';

/**
 * Структура автоматического контекста
 */
export interface IAutoContext {
  /** Имя файла ноутбука */
  notebookName: string | null;
  /** Путь к ноутбуку */
  notebookPath: string | null;
  /** Тип и версия ядра */
  kernelInfo: {
    name: string;
    displayName: string;
    language: string;
    status: string;
  } | null;
  /** Информация о ячейках */
  cellsSummary: {
    total: number;
    code: number;
    markdown: number;
    raw: number;
    activeCellIndex: number;
    activeCellType: string;
    activeCellPreview: string;
  } | null;
  /** Информация о последних ошибках */
  recentErrors: Array<{
    cellIndex: number;
    errorType: string;
    errorMessage: string;
  }>;
  /** Рабочая директория */
  workingDirectory: string;
  /** Краткая сводка содержимого ячеек */
  cellOutline: string[];
  /** Индексы пустых ячеек */
  emptyCells: number[];
}

/**
 * Собирает динамический контекст из текущего состояния JupyterLab
 */
export class ContextCollector {
  private notebookTracker: INotebookTracker;

  constructor(_app: JupyterFrontEnd, notebookTracker: INotebookTracker) {
    this.notebookTracker = notebookTracker;
  }

  /**
   * Собрать полный контекст
   */
  collect(): IAutoContext {
    const notebook = this.notebookTracker.currentWidget;

    return {
      notebookName: this.getNotebookName(notebook),
      notebookPath: this.getNotebookPath(notebook),
      kernelInfo: this.getKernelInfo(notebook),
      cellsSummary: this.getCellsSummary(notebook),
      recentErrors: this.getRecentErrors(notebook),
      workingDirectory: this.getWorkingDirectory(notebook),
      cellOutline: this.getCellOutline(notebook),
      emptyCells: this.getEmptyCells(notebook)
    };
  }

  /**
   * Преобразовать контекст в текст для системного промпта
   * @param includeCellOutline - Включать outline ячеек (по умолчанию true)
   */
  formatAsSystemMessage(includeCellOutline: boolean = true): string {
    const ctx = this.collect();
    const lines: string[] = [];

    lines.push('=== CURRENT ENVIRONMENT ===');

    // Ноутбук
    if (ctx.notebookName) {
      lines.push(`Notebook: ${ctx.notebookName} (${ctx.notebookPath})`);
    } else {
      lines.push('Notebook: No notebook is open');
    }

    // Ядро
    if (ctx.kernelInfo) {
      lines.push(
        `Kernel: ${ctx.kernelInfo.displayName} ` +
          `(${ctx.kernelInfo.language}, status: ${ctx.kernelInfo.status})`
      );
    } else {
      lines.push('Kernel: Not connected');
    }

    // Ячейки
    if (ctx.cellsSummary) {
      const cs = ctx.cellsSummary;
      lines.push(
        `Cells: ${cs.total} total ` +
          `(${cs.code} code, ${cs.markdown} markdown` +
          `${cs.raw > 0 ? `, ${cs.raw} raw` : ''})`
      );
      lines.push(`Active cell: [${cs.activeCellIndex}] ${cs.activeCellType}`);

      if (cs.activeCellPreview) {
        lines.push(`Active cell preview: ${cs.activeCellPreview}`);
      }
    }

    // Outline ячеек (только если включено)
    if (includeCellOutline && ctx.cellOutline.length > 0) {
      lines.push('');
      lines.push('Cell outline:');
      for (const outline of ctx.cellOutline) {
        lines.push(`  ${outline}`);
      }
    }

    // Ошибки
    if (ctx.recentErrors.length > 0) {
      lines.push('');
      lines.push('Recent errors:');
      for (const err of ctx.recentErrors) {
        lines.push(
          `  Cell [${err.cellIndex}]: ${err.errorType}: ${err.errorMessage}`
        );
      }
    }

    // Рабочая директория
    lines.push('');
    lines.push(`Working directory: ${ctx.workingDirectory}`);

    // Пустые ячейки
    if (ctx.emptyCells && ctx.emptyCells.length > 0) {
      lines.push('');
      lines.push(`Empty cells (can be reused): [${ctx.emptyCells.join(', ')}]`);
    }

    lines.push('=== END ENVIRONMENT ===');

    return lines.join('\n');
  }

  // ═══════════════════════════════════════════
  // Методы сбора данных
  // ═══════════════════════════════════════════

  private getNotebookName(notebook: NotebookPanel | null): string | null {
    if (!notebook) {
      return null;
    }
    return notebook.title.label || null;
  }

  private getNotebookPath(notebook: NotebookPanel | null): string | null {
    if (!notebook) {
      return null;
    }
    return notebook.context?.path || null;
  }

  private getKernelInfo(
    notebook: NotebookPanel | null
  ): IAutoContext['kernelInfo'] {
    if (!notebook) {
      return null;
    }

    const session = notebook.sessionContext;
    const kernel = session?.session?.kernel;

    if (!kernel) {
      return null;
    }

    // kernelspec info
    const spec = session.kernelPreference;
    const kernelInfo = kernel.info;

    return {
      name: session.session?.kernel?.name || 'unknown',
      displayName:
        (session as any).kernelDisplayName || kernel.name || 'Unknown',
      language:
        (kernelInfo as any)?.language_info?.name ||
        (spec as any)?.language ||
        'unknown',
      status: kernel.status
    };
  }

  private getCellsSummary(
    notebook: NotebookPanel | null
  ): IAutoContext['cellsSummary'] {
    if (!notebook) {
      return null;
    }

    const model = notebook.content.model;
    if (!model) {
      return null;
    }

    let code = 0;
    let markdown = 0;
    let raw = 0;

    for (let i = 0; i < model.cells.length; i++) {
      const cell = model.cells.get(i);
      switch (cell.type) {
        case 'code':
          code++;
          break;
        case 'markdown':
          markdown++;
          break;
        case 'raw':
          raw++;
          break;
      }
    }

    const activeCellIndex = notebook.content.activeCellIndex;
    const activeCell = model.cells.get(activeCellIndex);

    let activeCellPreview = '';
    if (activeCell) {
      const source = this.getCellSource(activeCell);
      // Первые 100 символов
      activeCellPreview = source.substring(0, 100);
      if (source.length > 100) {
        activeCellPreview += '...';
      }
    }

    return {
      total: model.cells.length,
      code,
      markdown,
      raw,
      activeCellIndex: activeCellIndex,
      activeCellType: activeCell?.type || 'unknown',
      activeCellPreview
    };
  }

  /**
   * Краткий outline: для каждой ячейки — тип + первая строка
   */
  private getCellOutline(notebook: NotebookPanel | null): string[] {
    if (!notebook) {
      return [];
    }

    const model = notebook.content.model;
    if (!model) {
      return [];
    }

    const outline: string[] = [];
    const maxCells = 20; // Ограничиваем, чтобы не раздувать контекст

    for (let i = 0; i < Math.min(model.cells.length, maxCells); i++) {
      const cell = model.cells.get(i);
      const source = this.getCellSource(cell);
      const firstLine = source.split('\n')[0].trim();

      const typeIcon = cell.type === 'code' ? '▸' : '▪';
      const preview = firstLine.substring(0, 60);
      const suffix = firstLine.length > 60 ? '...' : '';

      // Для code-ячеек показываем, есть ли output/ошибка
      let statusMark = '';
      if (cell.type === 'code') {
        const codeCell = cell as CodeCellModel;
        if (codeCell.outputs && codeCell.outputs.length > 0) {
          const hasError = this.cellOutputHasError(codeCell);
          statusMark = hasError ? ' ❌' : ' ✓';
        }
      }

      outline.push(`[${i}] ${typeIcon} ${preview}${suffix}${statusMark}`);
    }

    if (model.cells.length > maxCells) {
      outline.push(`... and ${model.cells.length - maxCells} more cells`);
    }

    return outline;
  }

  /**
   * Получить последние ошибки из ячеек
   */
  private getRecentErrors(
    notebook: NotebookPanel | null
  ): IAutoContext['recentErrors'] {
    if (!notebook) {
      return [];
    }

    const model = notebook.content.model;
    if (!model) {
      return [];
    }

    const errors: IAutoContext['recentErrors'] = [];

    for (let i = 0; i < model.cells.length; i++) {
      const cell = model.cells.get(i);
      if (cell.type !== 'code') {
        continue;
      }

      const codeCell = cell as CodeCellModel;
      if (!codeCell.outputs) {
        continue;
      }

      for (let j = 0; j < codeCell.outputs.length; j++) {
        const output = codeCell.outputs.get(j);
        const raw = (output as any)?._raw;

        if (raw?.output_type === 'error') {
          errors.push({
            cellIndex: i,
            errorType: raw.ename || 'Error',
            errorMessage: raw.evalue || 'Unknown error'
          });
        }
      }
    }

    // Возвращаем только последние 5 ошибок
    return errors.slice(-5);
  }

  private getWorkingDirectory(notebook: NotebookPanel | null): string {
    if (!notebook) {
      return '(unknown)';
    }
    const path = notebook.context?.path || '';
    const parts = path.split('/');
    parts.pop(); // убираем имя файла
    return parts.join('/') || '.';
  }

  private getCellSource(cell: any): string {
    if (cell.sharedModel) {
      return cell.sharedModel.getSource();
    }
    if (cell.value) {
      return cell.value.text;
    }
    return '';
  }

  private cellOutputHasError(codeCell: CodeCellModel): boolean {
    for (let i = 0; i < codeCell.outputs.length; i++) {
      const output = codeCell.outputs.get(i);
      const raw = (output as any)?._raw;
      if (raw?.output_type === 'error') {
        return true;
      }
    }
    return false;
  }

  /**
   * Получить индексы пустых ячеек (с пустым source)
   */
  private getEmptyCells(notebook: NotebookPanel | null): number[] {
    if (!notebook) {
      return [];
    }

    const model = notebook.content.model;
    if (!model) {
      return [];
    }

    const emptyCells: number[] = [];

    for (let i = 0; i < model.cells.length; i++) {
      const cell = model.cells.get(i);
      const source = this.getCellSource(cell);
      if (!source || source.trim() === '') {
        emptyCells.push(i);
      }
    }

    return emptyCells;
  }
}
