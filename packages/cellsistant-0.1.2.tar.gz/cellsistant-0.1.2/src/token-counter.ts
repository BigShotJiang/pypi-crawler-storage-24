/**
 * Модуль для приблизительного подсчёта токенов.
 *
 * Правила большого пальца:
 * - Английский текст: ~4 символа = 1 токен
 * - Код: ~3.5 символа = 1 токен (больше спецсимволов)
 * - Русский/CJK: ~2 символа = 1 токен
 * - JSON: ~3 символа = 1 токен
 */

/**
 * Приблизительный подсчёт токенов для одного текста.
 * Использует взвешенный подсчёт на основе типа символов.
 */
export function estimateTokens(text: string): number {
  if (!text) {
    return 0;
  }

  // Считаем типы символов
  const nonAsciiCount = (text.match(/[^[:ascii:]]/g) || []).length;
  const codeChars = (text.match(/[{}()[\];:=<>+\-*/&|!@#$%^~`\\]/g) || [])
    .length;
  const asciiCount = text.length - nonAsciiCount;

  // Взвешенный подсчёт
  const asciiTokens = (asciiCount - codeChars) / 4;
  const codeTokens = codeChars / 3;
  const nonAsciiTokens = nonAsciiCount / 2;

  return Math.ceil(asciiTokens + codeTokens + nonAsciiTokens);
}

/**
 * Подсчитать токены для одного сообщения
 */
export function estimateMessageTokens(msg: {
  role: string;
  content?: string | null;
  tool_calls?: Array<{
    function: { name: string; arguments: string };
    id?: string;
  }>;
  tool_call_id?: string;
}): number {
  let tokens = 4; // служебные токены (role, separators)

  if (msg.content) {
    tokens += estimateTokens(msg.content);
  }

  if (msg.tool_calls) {
    for (const tc of msg.tool_calls) {
      tokens += estimateTokens(tc.function.name);
      tokens += estimateTokens(tc.function.arguments);
      tokens += 10; // служебные
      if (tc.id) {
        tokens += 5;
      }
    }
  }

  if (msg.tool_call_id) {
    tokens += 5;
  }

  return tokens;
}

/**
 * Подсчитать токены для массива сообщений
 */
export function estimateMessagesTokens(
  messages: Array<{
    role: string;
    content?: string | null;
    tool_calls?: any[];
  }>
): number {
  return messages.reduce((sum, msg) => sum + estimateMessageTokens(msg), 0);
}

/**
 * Форматировать количество токенов в читаемый вид
 */
export function formatTokenCount(count: number): string {
  if (count < 1000) {
    return `${count}`;
  }
  if (count < 10000) {
    return `${(count / 1000).toFixed(1)}K`;
  }
  if (count < 1000000) {
    return `${Math.round(count / 1000)}K`;
  }
  return `${(count / 1000000).toFixed(1)}M`;
}
