import { URLExt } from '@jupyterlab/coreutils';
import { ServerConnection } from '@jupyterlab/services';

export interface IEnabledToolCategories {
  notebook: boolean;
  files: boolean;
  shell: boolean;
  packages: boolean;
  search: boolean;
}

export interface IModelProfile {
  id: string;
  name: string;
  base_url: string;
  api_key?: string | null;
  model: string;
  temperature: number;
  max_tokens: number;
}

export interface IImageAnalysisSettings {
  enabled: boolean;
  auto_suggest: boolean;
  use_active_profile: boolean;
  profile_id?: string | null;
  custom_prompt: string;
}

export interface IAgentSettings {
  profiles: IModelProfile[];
  active_profile_id: string;
  auto_execute_tools: boolean;
  include_variables: boolean;
  include_cell_outline: boolean;
  max_agent_iterations: number;
  enabled_tool_categories: IEnabledToolCategories;
  custom_system_prompt: string;
  image_analysis: IImageAnalysisSettings;
}

export interface ITestResult {
  success: boolean;
  response?: string;
  error?: string;
  latency_ms?: number;
  model_used?: string;
}

const settingsEndpoint = (path: string = ''): string => {
  const settings = ServerConnection.makeSettings();
  return URLExt.join(settings.baseUrl, 'ai-agent', 'settings', path);
};

/**
 * Получить текущие настройки
 */
export async function getSettings(): Promise<IAgentSettings> {
  const settings = ServerConnection.makeSettings();
  const response = await ServerConnection.makeRequest(
    settingsEndpoint(),
    {},
    settings
  );
  if (response.status !== 200) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error || 'Failed to load settings');
  }
  return await response.json();
}

/**
 * Обновить настройки
 */
export async function updateSettings(
  updates: Record<string, unknown>
): Promise<void> {
  const settings = ServerConnection.makeSettings();
  const response = await ServerConnection.makeRequest(
    settingsEndpoint('update'),
    {
      method: 'POST',
      body: JSON.stringify(updates)
    },
    settings
  );
  if (response.status !== 200) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error || 'Failed to update settings');
  }
  return await response.json();
}

/**
 * Тестировать подключение к API
 */
export async function testConnection(params: {
  base_url?: string;
  model?: string;
  api_key?: string;
  profile_id?: string;
}): Promise<ITestResult> {
  const settings = ServerConnection.makeSettings();
  const response = await ServerConnection.makeRequest(
    settingsEndpoint('test'),
    {
      method: 'POST',
      body: JSON.stringify(params)
    },
    settings
  );
  return await response.json();
}
