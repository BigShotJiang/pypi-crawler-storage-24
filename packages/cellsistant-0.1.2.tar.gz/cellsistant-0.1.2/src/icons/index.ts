import { LabIcon } from '@jupyterlab/ui-components';

const addProfileSvgStr = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
  <path fill="#BDBDBD" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"/>
</svg>`;

const editProfileSvgStr = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
  <path fill="#BDBDBD" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
</svg>`;

const deleteProfileSvgStr = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
  <path fill="#BDBDBD" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
</svg>`;

export const addProfileIcon = new LabIcon({
  name: 'ai-agent:add-profile',
  svgstr: addProfileSvgStr
});

export const editProfileIcon = new LabIcon({
  name: 'ai-agent:edit-profile',
  svgstr: editProfileSvgStr
});

export const deleteProfileIcon = new LabIcon({
  name: 'ai-agent:delete-profile',
  svgstr: deleteProfileSvgStr
});
