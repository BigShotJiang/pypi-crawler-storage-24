import { INotebookTracker } from '@jupyterlab/notebook';

/**
 * Информация о переменной в ядре
 */
export interface IVariableInfo {
  name: string;
  type: string;
  /** Краткое описание: shape для массивов, длина для списков, и т.д. */
  summary: string;
}

/**
 * Код Python для интроспекции переменных
 * Выполняется в ядре, возвращает JSON
 */
const INSPECT_CODE = `
import json as _json
import sys as _sys

def _ai_agent_inspect_vars():
    """Собрать информацию о переменных в текущем пространстве имён"""
    _result = []
    _skip = {
        '_ai_agent_inspect_vars', '_result', '_skip',
        '_json', '_sys', '_name', '_val', '_info',
        'In', 'Out', 'get_ipython', 'exit', 'quit',
        '_ih', '_oh', '_dh', '__', '___', '_i', '_ii', '_iii',
    }

    _globals = {k: v for k, v in globals().items()
                if not k.startswith('_') or k == '_'}

    for _name, _val in _globals.items():
        if _name in _skip:
            continue
        if _name.startswith('__'):
            continue

        _info = {
            'name': _name,
            'type': type(_val).__name__,
            'summary': ''
        }

        try:
            # DataFrame
            if hasattr(_val, 'shape') and hasattr(_val, 'columns'):
                _shape = _val.shape
                _cols = list(_val.columns)[:10]
                _info['summary'] = f'shape={_shape}, columns={_cols}'
                if len(_val.columns) > 10:
                    _info['summary'] += f'... ({len(_val.columns)} total)'
            # NumPy array
            elif hasattr(_val, 'shape') and hasattr(_val, 'dtype'):
                _info['summary'] = f'shape={_val.shape}, dtype={_val.dtype}'
            # List/tuple
            elif isinstance(_val, (list, tuple)):
                _info['summary'] = f'len={len(_val)}'
                if len(_val) > 0:
                    _info['summary'] += f', first={type(_val[0]).__name__}'
            # Dict
            elif isinstance(_val, dict):
                _keys = list(_val.keys())[:5]
                _info['summary'] = f'len={len(_val)}, keys={_keys}'
                if len(_val) > 5:
                    _info['summary'] += '...'
            # String
            elif isinstance(_val, str):
                _info['summary'] = f'len={len(_val)}'
                if len(_val) <= 50:
                    _info['summary'] += f', value="{_val}"'
            # Number
            elif isinstance(_val, (int, float, complex, bool)):
                _info['summary'] = f'value={_val}'
            # Model-like objects
            elif hasattr(_val, 'get_params'):
                try:
                    _params = _val.get_params()
                    _info['summary'] = str({k: v for k, v in list(_params.items())[:5]})
                except:
                    _info['summary'] = repr(_val)[:100]
            # Callable
            elif callable(_val):
                _info['type'] = 'function'
                if hasattr(_val, '__doc__') and _val.__doc__:
                    _first_line = _val.__doc__.strip().split('\\n')[0]
                    _info['summary'] = _first_line[:80]
            else:
                _info['summary'] = repr(_val)[:100]
        except Exception as _e:
            _info['summary'] = f'(error: {_e})'

        _result.append(_info)

    # Сортируем: DataFrames и массивы сверху
    _priority = {'DataFrame': 0, 'ndarray': 1, 'Series': 2}
    _result.sort(key=lambda x: (_priority.get(x['type'], 10), x['name']))

    print(_json.dumps(_result[:50]))  # максимум 50 переменных

_ai_agent_inspect_vars()
del _ai_agent_inspect_vars
`;

/**
 * Инспектор переменных — выполняет код в ядре и парсит результат
 */
export class VariableInspector {
  private notebookTracker: INotebookTracker;
  private cache: IVariableInfo[] | null = null;
  private cacheTimestamp: number = 0;
  private cacheTTL: number = 5000; // 5 секунд

  constructor(notebookTracker: INotebookTracker) {
    this.notebookTracker = notebookTracker;
  }

  /**
   * Получить список переменных.
   * Использует кэш, чтобы не выполнять код в ядре слишком часто.
   */
  async getVariables(forceRefresh: boolean = false): Promise<IVariableInfo[]> {
    const now = Date.now();

    // Возвращаем из кэша, если свежий
    if (
      !forceRefresh &&
      this.cache &&
      now - this.cacheTimestamp < this.cacheTTL
    ) {
      return this.cache;
    }

    const notebook = this.notebookTracker.currentWidget;
    if (!notebook) {
      return [];
    }

    const kernel = notebook.sessionContext?.session?.kernel;
    if (!kernel) {
      return [];
    }

    // Проверяем, что ядро idle
    if (kernel.status !== 'idle') {
      // Возвращаем старый кэш или пустой массив
      return this.cache || [];
    }

    try {
      const result = await this.executeInKernel(kernel, INSPECT_CODE);

      if (result) {
        this.cache = JSON.parse(result);
        this.cacheTimestamp = now;
        return this.cache!;
      }
    } catch (e) {
      console.warn('Variable inspection failed:', e);
    }

    return this.cache || [];
  }

  /**
   * Форматировать переменные для промпта
   */
  async formatForPrompt(): Promise<string> {
    const vars = await this.getVariables();

    if (vars.length === 0) {
      return 'Variables: (none or kernel not ready)';
    }

    const lines = ['Variables in kernel:'];

    for (const v of vars) {
      if (v.summary) {
        lines.push(`  ${v.name} (${v.type}): ${v.summary}`);
      } else {
        lines.push(`  ${v.name} (${v.type})`);
      }
    }

    return lines.join('\n');
  }

  /**
   * Сбросить кэш (вызывать после execute_cell)
   */
  invalidateCache(): void {
    this.cache = null;
    this.cacheTimestamp = 0;
  }

  /**
   * Выполнить код в ядре и вернуть stdout
   */
  private async executeInKernel(
    kernel: any,
    code: string
  ): Promise<string | null> {
    return new Promise(resolve => {
      let output = '';
      let resolved = false;

      const future = kernel.requestExecute({
        code,
        silent: true, // Не увеличивает execution_count
        store_history: false // Не сохраняет в In[]
      });

      // Собираем stdout
      future.onIOPub = (msg: any) => {
        if (msg.header.msg_type === 'stream' && msg.content.name === 'stdout') {
          output += msg.content.text;
        }
      };

      // Ждём завершения
      future.done
        .then(() => {
          if (!resolved) {
            resolved = true;
            resolve(output.trim() || null);
          }
        })
        .catch(() => {
          if (!resolved) {
            resolved = true;
            resolve(null);
          }
        });

      // Таймаут 5 секунд
      setTimeout(() => {
        if (!resolved) {
          resolved = true;
          resolve(this.cache ? JSON.stringify(this.cache) : null);
        }
      }, 5000);
    });
  }
}
