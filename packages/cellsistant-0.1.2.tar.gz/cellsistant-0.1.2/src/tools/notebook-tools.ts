import { ITool, IToolResult, ToolSafetyLevel, ToolCategory } from '../tools';
import { JupyterService } from '../jupyter-service';
import { analyzeImage } from '../api';
import { IImageAnalysisSettings } from '../settings-api';

export interface INotebookToolsOptions {
  imageAnalysis?: IImageAnalysisSettings;
}

/** Create notebook manipulation tools */
export function createNotebookTools(
  jupyterService: JupyterService,
  options?: INotebookToolsOptions
): ITool[] {
  const tools: ITool[] = [
    {
      name: 'create_cell',
      safetyLevel: ToolSafetyLevel.WRITE,
      category: 'notebook' as ToolCategory,
      description: 'Create a new cell in the active notebook',
      parameters: {
        type: 'object',
        properties: {
          cell_type: {
            type: 'string',
            description: 'Type of cell: "code" or "markdown"',
            enum: ['code', 'markdown']
          },
          source: {
            type: 'string',
            description: 'Content of the cell'
          },
          index: {
            type: 'integer',
            description: 'Position to insert the cell (0-based, default: end of notebook)'
          }
        },
        required: ['cell_type', 'source']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const cellType = args.cell_type as 'code' | 'markdown';
        const source = args.source as string;

        const result = await jupyterService.createCell(cellType, source);

        if (result.success) {
          return {
            success: true,
            result: {
              index: result.index,
              message: `Cell created at index ${result.index}`
            }
          };
        } else {
          return {
            success: false,
            error: result.error
          };
        }
      }
    },

    {
      name: 'update_cell',
      safetyLevel: ToolSafetyLevel.WRITE,
      category: 'notebook' as ToolCategory,
      description: 'Update the content of an existing cell',
      parameters: {
        type: 'object',
        properties: {
          index: {
            type: 'integer',
            description: 'Index of the cell to update (0-based)'
          },
          source: {
            type: 'string',
            description: 'New content for the cell'
          }
        },
        required: ['index', 'source']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const index = args.index as number;
        const source = args.source as string;

        const result = jupyterService.updateCell(index, source);

        if (result.success) {
          return {
            success: true,
            result: { message: `Cell at index ${index} updated` }
          };
        } else {
          return {
            success: false,
            error: result.error
          };
        }
      }
    },

    {
      name: 'delete_cell',
      safetyLevel: ToolSafetyLevel.WRITE,
      category: 'notebook' as ToolCategory,
      alwaysConfirm: true,
      description: 'Delete a cell from the notebook',
      parameters: {
        type: 'object',
        properties: {
          index: {
            type: 'integer',
            description: 'Index of the cell to delete (0-based)'
          }
        },
        required: ['index']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const index = args.index as number;

        const result = jupyterService.deleteCell(index);

        if (result.success) {
          return {
            success: true,
            result: { message: `Cell at index ${index} deleted` }
          };
        } else {
          return {
            success: false,
            error: result.error
          };
        }
      }
    },

    {
      name: 'get_cell_content',
      safetyLevel: ToolSafetyLevel.READ,
      category: 'notebook' as ToolCategory,
      description: 'Get the content of a specific cell',
      parameters: {
        type: 'object',
        properties: {
          index: {
            type: 'integer',
            description: 'Index of the cell (0-based)'
          }
        },
        required: ['index']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const index = args.index as number;

        const result = jupyterService.getCellContent(index);

        if (result.success) {
          return {
            success: true,
            result: {
              cell_type: result.cellType,
              source: result.source
            }
          };
        } else {
          return {
            success: false,
            error: result.error
          };
        }
      }
    },

    {
      name: 'get_notebook_content',
      safetyLevel: ToolSafetyLevel.READ,
      category: 'notebook' as ToolCategory,
      description:
        'Get the content of all cells in the active notebook. For code cells, includes execution metadata: execution_count (null if not executed), outputs_count, has_error, and outputs_summary.',
      parameters: {
        type: 'object',
        properties: {}
      },
      async execute(): Promise<IToolResult> {
        const result = jupyterService.getNotebookContent();

        if (result.success) {
          return {
            success: true,
            result: { cells: result.cells }
          };
        } else {
          return {
            success: false,
            error: result.error
          };
        }
      }
    },

    {
      name: 'execute_cell',
      safetyLevel: ToolSafetyLevel.EXECUTE,
      category: 'notebook' as ToolCategory,
      description:
        'Execute a code cell or render a markdown cell. For code cells: runs the code and waits for completion. For markdown cells: renders the markdown as formatted text.',
      parameters: {
        type: 'object',
        properties: {
          index: {
            type: 'integer',
            description: 'Index of the cell to execute/render (0-based)'
          }
        },
        required: ['index']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const index = args.index as number;

        const result = await jupyterService.executeCell(index);

        if (result.success) {
          return {
            success: true,
            result: { message: `Cell at index ${index} executed` }
          };
        } else {
          return {
            success: false,
            error: result.error
          };
        }
      }
    },

    {
      name: 'get_cell_output',
      safetyLevel: ToolSafetyLevel.READ,
      category: 'notebook' as ToolCategory,
      description:
        'Get the output of an executed code cell. Returns text output, errors, images (as base64), and HTML (like DataFrames). Images are included by default for matplotlib plots.',
      parameters: {
        type: 'object',
        properties: {
          index: {
            type: 'integer',
            description: 'Index of the cell (0-based)'
          },
          include_images: {
            type: 'boolean',
            description:
              'Include base64 image data (default: true). Set to false to save tokens.'
          }
        },
        required: ['index']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const index = args.index as number;
        // Always include images by default for matplotlib plots
        const includeImages = args.include_images as boolean | undefined;
        const shouldIncludeImages = includeImages !== false;

        const result = jupyterService.getCellOutput(index);

        if (!result.success) {
          return { success: false, error: result.error };
        }

        const outputs = result.outputs || [];

        if (outputs.length === 0) {
          return {
            success: true,
            result: {
              outputs: [],
              message: 'Cell has no output (may still be executing)'
            }
          };
        }

        // Format outputs
        const formattedOutputs = outputs.map(output => {
          switch (output.type) {
            case 'text':
              return {
                type: 'text',
                content: output.text
              };

            case 'error':
              return {
                type: 'error',
                content: output.text
              };

            case 'image': {
              const imageInfo: Record<string, unknown> = {
                type: 'image',
                mime_type: output.mimeType,
                description: `Image output (${output.mimeType})`
              };

              // Add base64 by default (unless explicitly disabled)
              if (shouldIncludeImages && output.data) {
                imageInfo.base64 = output.data;
              } else {
                imageInfo.note =
                  'Image data available. Call with include_images=true to get base64 data.';
              }

              // Add text/plain description (matplotlib adds "Figure(...)")
              if (output.text) {
                imageInfo.alt_text = output.text;
              }

              return imageInfo;
            }

            case 'html':
              return {
                type: 'html',
                // For DataFrame - extract text version
                content: output.text || '(HTML output)',
                note: 'Rich HTML output (e.g. DataFrame). The text representation is provided.'
              };

            case 'json':
              return {
                type: 'json',
                content: output.text
              };

            default:
              return {
                type: 'unknown',
                content: output.text || '(unknown output type)'
              };
          }
        });

        return {
          success: true,
          result: {
            outputs: formattedOutputs,
            output_count: formattedOutputs.length,
            has_images: outputs.some(o => o.type === 'image'),
            has_errors: outputs.some(o => o.type === 'error')
          }
        };
      }
    }
  ];

  // Add analyze_image only if enabled in settings
  const imageAnalysisEnabled = options?.imageAnalysis?.enabled !== false;
  if (imageAnalysisEnabled) {
    tools.push({
      name: 'analyze_image',
      safetyLevel: ToolSafetyLevel.READ,
      category: 'notebook' as ToolCategory,
      description:
        'Analyze an image from a cell output using AI vision. Use when user asks to analyze, explain, or describe an image.',
      parameters: {
        type: 'object',
        properties: {
          cell_index: {
            type: 'integer',
            description: 'Index of the cell containing the image to analyze (0-based)'
          },
          context: {
            type: 'string',
            description: 'Optional context or specific question about the image'
          }
        },
        required: ['cell_index']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const cellIndex = args.cell_index as number;
        const context = args.context as string | undefined;

        const result = jupyterService.getCellOutput(cellIndex);

        if (!result.success) {
          return { success: false, error: result.error };
        }

        const outputs = result.outputs || [];
        const imageOutput = outputs.find((o: any) => o.type === 'image');

        if (!imageOutput || !imageOutput.data) {
          return {
            success: false,
            error: 'No image found in cell output'
          };
        }

        try {
          const analysisResult = await analyzeImage(
            imageOutput.data,
            imageOutput.mimeType || 'image/png',
            cellIndex,
            context
          );

          if (!analysisResult.success) {
            return {
              success: false,
              error: analysisResult.error || 'Image analysis failed'
            };
          }

          return {
            success: true,
            result: {
              analysis: analysisResult.analysis,
              model_used: analysisResult.model_used,
              cell_index: cellIndex,
              mime_type: imageOutput.mimeType
            }
          };
        } catch (error) {
          return {
            success: false,
            error: `Analysis error: ${(error as Error).message}`
          };
        }
      }
    });
  }

  return tools;
}
