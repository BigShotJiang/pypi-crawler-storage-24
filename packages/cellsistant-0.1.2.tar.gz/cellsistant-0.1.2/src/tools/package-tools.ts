import { ITool, IToolResult, ToolSafetyLevel, ToolCategory } from '../tools';
import { executeShell } from '../api';

/**
 * Валидация имени пакета
 * Допустимые символы: буквы, цифры, -, _, ., [, ], =, <, >, !, ~, ,
 */
function isValidPackageName(name: string): boolean {
  return /^[a-zA-Z0-9._[\]>=<!~,\s]+$/.test(name) && name.length < 200;
}

/**
 * Извлечь базовое имя пакета (без версий)
 */
function getBasePackageName(packageName: string): string {
  return packageName.split(/[>=<!~]/)[0].trim();
}

/**
 * Парсинг типичных ошибок установки
 */
function parseInstallError(output: string): {
  message: string;
  suggestion?: string;
} {
  const lower = output.toLowerCase();

  if (lower.includes('no matching distribution')) {
    return {
      message: 'Package not found in PyPI',
      suggestion: 'Check the package name spelling. Try searching on pypi.org.'
    };
  }

  if (lower.includes('permission denied') || lower.includes('errno 13')) {
    return {
      message: 'Permission denied during installation',
      suggestion: 'Try adding --user flag via extra_args parameter.'
    };
  }

  if (lower.includes('conflict')) {
    return {
      message: 'Package version conflict detected',
      suggestion:
        'Try specifying a compatible version or use --force-reinstall.'
    };
  }

  if (lower.includes('no space left')) {
    return {
      message: 'Disk full — no space left',
      suggestion: 'Free up disk space and try again.'
    };
  }

  if (
    lower.includes('could not build wheels') ||
    lower.includes('compilation')
  ) {
    return {
      message: 'Failed to build package from source',
      suggestion:
        'The package may require system-level build tools. Try conda instead of pip.'
    };
  }

  if (lower.includes('network') || lower.includes('connection')) {
    return {
      message: 'Network error during installation',
      suggestion: 'Check your internet connection and try again.'
    };
  }

  return {
    message: output
      .split('\n')
      .filter(l => l.trim())
      .slice(-3)
      .join('; '),
    suggestion: undefined
  };
}

export function createPackageTools(): ITool[] {
  return [
    // ─────────────────────────────────────────
    // install_package
    // ─────────────────────────────────────────
    {
      name: 'install_package',
      safetyLevel: ToolSafetyLevel.SYSTEM,
      category: 'packages' as ToolCategory,
      description:
        'Install a Python package using pip or conda. After installation, the package is available for import in notebook cells. Use this when code fails with ModuleNotFoundError or ImportError.',
      parameters: {
        type: 'object',
        properties: {
          package_name: {
            type: 'string',
            description:
              'Package name to install. Can include version: "pandas", "numpy>=1.24", "scikit-learn==1.3.0"'
          },
          manager: {
            type: 'string',
            enum: ['pip', 'conda'],
            description: 'Package manager to use (default: pip)',
            default: 'pip'
          },
          extra_args: {
            type: 'string',
            description:
              'Extra arguments, e.g. "--upgrade", "--no-deps", "-c conda-forge"'
          }
        },
        required: ['package_name']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const packageName = args.package_name as string;
        const manager = (args.manager as string) || 'pip';
        const extraArgs = (args.extra_args as string) || '';

        // Валидация имени пакета (защита от инъекций)
        if (!isValidPackageName(packageName)) {
          return {
            success: false,
            error: `Invalid package name: "${packageName}". Package name should contain only letters, numbers, hyphens, underscores, dots, and version specifiers.`
          };
        }

        // Формируем команду
        let command: string;

        if (manager === 'conda') {
          command = `conda install -y ${extraArgs} ${packageName}`;
        } else {
          // pip
          command = `pip install ${extraArgs} ${packageName}`;
        }

        try {
          // Выполняем установку (с увеличенным таймаутом)
          const result = await executeShell(command, 120);

          if (result.success) {
            // Проверяем, что пакет действительно установился
            const baseName = getBasePackageName(packageName);
            const importName = baseName.replace(/-/g, '_');

            const checkResult = await executeShell(
              `python -c "import ${importName}; print('OK')"`,
              10
            );

            const importable =
              checkResult.success && checkResult.stdout.includes('OK');

            return {
              success: true,
              result: {
                package: packageName,
                manager,
                message: `Package "${packageName}" installed successfully`,
                importable,
                import_name: importName,
                output: result.stdout.split('\n').slice(-3).join('\n')
              }
            };
          } else {
            // Парсим типичные ошибки pip/conda
            const errorInfo = parseInstallError(result.stderr || result.stdout);

            return {
              success: false,
              error: errorInfo.message,
              result: {
                suggestion: errorInfo.suggestion,
                full_output: (result.stderr || result.stdout).substring(0, 500)
              }
            };
          }
        } catch (error) {
          return {
            success: false,
            error: error instanceof Error ? error.message : String(error)
          };
        }
      }
    },

    // ─────────────────────────────────────────
    // list_packages
    // ─────────────────────────────────────────
    {
      name: 'list_packages',
      safetyLevel: ToolSafetyLevel.READ,
      category: 'packages' as ToolCategory,
      description:
        'List installed Python packages. Use to check what is already available.',
      parameters: {
        type: 'object',
        properties: {
          filter: {
            type: 'string',
            description: 'Filter packages by name substring (optional)'
          }
        }
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const filter = (args.filter as string) || '';

        try {
          const result = await executeShell('pip list --format=json', 30);

          if (!result.success) {
            return {
              success: false,
              error: `Failed to list packages: ${result.stderr}`
            };
          }

          let packages: Array<{ name: string; version: string }>;
          try {
            packages = JSON.parse(result.stdout);
          } catch {
            return {
              success: false,
              error: 'Failed to parse pip output'
            };
          }

          // Фильтруем
          if (filter) {
            const lowerFilter = filter.toLowerCase();
            packages = packages.filter(p =>
              p.name.toLowerCase().includes(lowerFilter)
            );
          }

          return {
            success: true,
            result: {
              count: packages.length,
              packages: packages.slice(0, 100), // максимум 100
              truncated: packages.length > 100
            }
          };
        } catch (error) {
          return {
            success: false,
            error: error instanceof Error ? error.message : String(error)
          };
        }
      }
    }
  ];
}
