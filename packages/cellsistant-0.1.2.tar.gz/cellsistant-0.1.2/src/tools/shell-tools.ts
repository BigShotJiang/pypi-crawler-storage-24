import { ITool, IToolResult, ToolSafetyLevel, ToolCategory } from '../tools';
import { executeShell } from '../api';

export function createShellTools(): ITool[] {
  return [
    {
      name: 'run_shell',
      safetyLevel: ToolSafetyLevel.SYSTEM,
      category: 'shell' as ToolCategory,
      alwaysConfirm: true,
      description:
        'Execute a shell command on the server. Use for: checking versions (python --version), listing processes, git operations, running scripts, system info. Commands are executed with a 60s timeout. Dangerous commands (rm -rf /, shutdown, etc.) are blocked. For Python code, prefer creating and executing notebook cells instead.',
      parameters: {
        type: 'object',
        properties: {
          command: {
            type: 'string',
            description:
              'Shell command to execute. Examples: "python --version", "pip list", "git status", "ls -la", "cat requirements.txt"'
          },
          timeout: {
            type: 'integer',
            description:
              'Maximum execution time in seconds (default: 60, max: 60)'
          }
        },
        required: ['command']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const command = args.command as string;
        const timeout = args.timeout as number | undefined;

        try {
          const result = await executeShell(command, timeout);

          // Format output
          let output = '';

          if (result.stdout) {
            output += result.stdout;
            if (result.stdout_truncated) {
              output += '\n... (output truncated)';
            }
          }

          if (result.stderr) {
            output += (output ? '\n' : '') + `STDERR: ${result.stderr}`;
            if (result.stderr_truncated) {
              output += '\n... (stderr truncated)';
            }
          }

          if (!output) {
            output = '(no output)';
          }

          return {
            success: result.success,
            result: {
              return_code: result.return_code,
              output: output,
              elapsed: `${result.elapsed_seconds}s`
            },
            error: result.success
              ? undefined
              : `Command failed with exit code ${result.return_code}`
          };
        } catch (error) {
          return {
            success: false,
            error: error instanceof Error ? error.message : String(error)
          };
        }
      }
    }
  ];
}
