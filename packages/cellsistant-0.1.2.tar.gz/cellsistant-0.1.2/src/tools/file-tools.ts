import { ITool, IToolResult, ToolSafetyLevel, ToolCategory } from '../tools';
import { JupyterService } from '../jupyter-service';

/** Maximum file size for reading (500KB) */
const MAX_FILE_SIZE = 500 * 1024;

/** File extensions considered text files */
const TEXT_EXTENSIONS = new Set([
  '.py',
  '.js',
  '.ts',
  '.tsx',
  '.jsx',
  '.json',
  '.yaml',
  '.yml',
  '.toml',
  '.cfg',
  '.ini',
  '.conf',
  '.txt',
  '.md',
  '.rst',
  '.csv',
  '.tsv',
  '.xml',
  '.html',
  '.css',
  '.scss',
  '.sql',
  '.sh',
  '.bash',
  '.zsh',
  '.r',
  '.R',
  '.jl',
  '.lua',
  '.c',
  '.cpp',
  '.h',
  '.hpp',
  '.java',
  '.go',
  '.rs',
  '.dockerfile',
  '.gitignore',
  '.env',
  '.ipynb',
  'Makefile',
  'Dockerfile',
  'README',
  'LICENSE'
]);

export function createFileTools(jupyterService: JupyterService): ITool[] {
  return [
    // ═══════════════════════════════════════════
    // read_file
    // ═══════════════════════════════════════════
    {
      name: 'read_file',
      safetyLevel: ToolSafetyLevel.READ,
      category: 'files' as ToolCategory,
      description: `Read the contents of a text file. Supports common text formats: .py, .js, .json, .csv, .md, .txt, .yaml, etc. Maximum file size: ${MAX_FILE_SIZE / 1024}KB. For binary files (images, PDFs), use other approaches.`,
      parameters: {
        type: 'object',
        properties: {
          path: {
            type: 'string',
            description:
              'Path to the file relative to Jupyter working directory. Examples: "data/input.csv", "utils/helper.py", "config.yaml"'
          },
          max_lines: {
            type: 'integer',
            description:
              'Maximum number of lines to return (default: all). Use this for large files to get just the beginning.'
          }
        },
        required: ['path']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const path = args.path as string;
        const maxLines = args.max_lines as number | undefined;

        const ext = '.' + path.split('.').pop()?.toLowerCase();
        const baseName = path.split('/').pop() || '';
        const isText =
          TEXT_EXTENSIONS.has(ext) ||
          TEXT_EXTENSIONS.has(baseName) ||
          !ext.includes('.');

        if (!isText) {
          return {
            success: false,
            error: `File "${path}" appears to be binary (extension: ${ext}). Only text files can be read.`
          };
        }

        const result = await jupyterService.readFile(path);

        if (!result.success) {
          return { success: false, error: result.error };
        }

        let content = result.content || '';

        if (content.length > MAX_FILE_SIZE) {
          content = content.substring(0, MAX_FILE_SIZE);
          return {
            success: true,
            result: {
              content,
              truncated: true,
              message: `File truncated to ${MAX_FILE_SIZE / 1024}KB. Use max_lines parameter for controlled reading.`,
              total_size: result.size
            }
          };
        }

        if (maxLines !== undefined && maxLines > 0) {
          const lines = content.split('\n');
          if (lines.length > maxLines) {
            content = lines.slice(0, maxLines).join('\n');
            return {
              success: true,
              result: {
                content,
                truncated: true,
                shown_lines: maxLines,
                total_lines: lines.length
              }
            };
          }
        }

        return {
          success: true,
          result: {
            content,
            lines: content.split('\n').length,
            size: content.length
          }
        };
      }
    },

    // ═══════════════════════════════════════════
    // write_file
    // ═══════════════════════════════════════════
    {
      name: 'write_file',
      safetyLevel: ToolSafetyLevel.WRITE,
      category: 'files' as ToolCategory,
      description:
        'Create a new file or overwrite an existing file with the given content. Parent directories will be created automatically if they do not exist.',
      parameters: {
        type: 'object',
        properties: {
          path: {
            type: 'string',
            description:
              'Path for the file relative to Jupyter working directory'
          },
          content: {
            type: 'string',
            description: 'Content to write to the file'
          }
        },
        required: ['path', 'content']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const path = args.path as string;
        const content = args.content as string;

        if (path.endsWith('.ipynb')) {
          return {
            success: false,
            error:
              'Cannot write .ipynb files directly. Use create_notebook tool or work with cells via create_cell/update_cell.'
          };
        }

        const result = await jupyterService.writeFile(path, content);

        if (!result.success) {
          return { success: false, error: result.error };
        }

        return {
          success: true,
          result: {
            path,
            created: result.created,
            message: result.created
              ? `File created: ${path}`
              : `File updated: ${path}`,
            size: content.length
          }
        };
      }
    },

    // ═══════════════════════════════════════════
    // list_directory
    // ═══════════════════════════════════════════
    {
      name: 'list_directory',
      safetyLevel: ToolSafetyLevel.READ,
      category: 'files' as ToolCategory,
      description:
        'List files and subdirectories in a given directory. Returns names, types (file/directory/notebook), and sizes.',
      parameters: {
        type: 'object',
        properties: {
          path: {
            type: 'string',
            description:
              'Path to directory relative to Jupyter working directory. Empty string or "." for root directory.',
            default: ''
          }
        }
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const path = (args.path as string) || '';

        const result = await jupyterService.listDirectory(path);

        if (!result.success) {
          return { success: false, error: result.error };
        }

        const items = result.items || [];

        const summary = items.map(item => {
          const icon =
            item.type === 'directory'
              ? '📁'
              : item.type === 'notebook'
                ? '📓'
                : '📄';
          const size = item.size ? ` (${formatFileSize(item.size)})` : '';
          return `${icon} ${item.name}${size}`;
        });

        return {
          success: true,
          result: {
            path: path || '.',
            count: items.length,
            items: items,
            summary: summary.join('\n')
          }
        };
      }
    },

    // ═══════════════════════════════════════════
    // create_notebook
    // ═══════════════════════════════════════════
    {
      name: 'create_notebook',
      safetyLevel: ToolSafetyLevel.WRITE,
      category: 'files' as ToolCategory,
      description: 'Create a new empty Jupyter notebook (.ipynb file)',
      parameters: {
        type: 'object',
        properties: {
          name: {
            type: 'string',
            description:
              'Name for the notebook (with or without .ipynb extension)'
          },
          path: {
            type: 'string',
            description:
              'Directory where to create the notebook (default: root)',
            default: ''
          }
        },
        required: ['name']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const name = args.name as string;
        const path = (args.path as string) || '';

        const result = await jupyterService.createNotebook(name, path);

        if (!result.success) {
          return { success: false, error: result.error };
        }

        return {
          success: true,
          result: {
            path: result.path,
            message: `Notebook created: ${result.path}`
          }
        };
      }
    },

    // ═══════════════════════════════════════════
    // delete_file
    // ═══════════════════════════════════════════
    {
      name: 'delete_file',
      safetyLevel: ToolSafetyLevel.SYSTEM,
      category: 'files' as ToolCategory,
      alwaysConfirm: true,
      description:
        'Delete a file or empty directory. Use with caution — this cannot be undone.',
      parameters: {
        type: 'object',
        properties: {
          path: {
            type: 'string',
            description: 'Path to the file or directory to delete'
          }
        },
        required: ['path']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const path = args.path as string;

        const result = await jupyterService.deleteFile(path);

        if (!result.success) {
          return { success: false, error: result.error };
        }

        return {
          success: true,
          result: { message: `Deleted: ${path}` }
        };
      }
    },

    // ═══════════════════════════════════════════
    // rename_file
    // ═══════════════════════════════════════════
    {
      name: 'rename_file',
      safetyLevel: ToolSafetyLevel.WRITE,
      category: 'files' as ToolCategory,
      description: 'Rename or move a file/directory',
      parameters: {
        type: 'object',
        properties: {
          old_path: {
            type: 'string',
            description: 'Current path of the file'
          },
          new_path: {
            type: 'string',
            description: 'New path for the file'
          }
        },
        required: ['old_path', 'new_path']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const oldPath = args.old_path as string;
        const newPath = args.new_path as string;

        const result = await jupyterService.renameFile(oldPath, newPath);

        if (!result.success) {
          return { success: false, error: result.error };
        }

        return {
          success: true,
          result: { message: `Renamed: ${oldPath} → ${newPath}` }
        };
      }
    }
  ];
}

/** Format file size for display */
function formatFileSize(bytes: number): string {
  if (bytes < 1024) {
    return `${bytes} B`;
  }
  if (bytes < 1024 * 1024) {
    return `${(bytes / 1024).toFixed(1)} KB`;
  }
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
