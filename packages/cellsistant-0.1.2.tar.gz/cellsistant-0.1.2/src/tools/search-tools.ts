import { ITool, IToolResult, ToolSafetyLevel, ToolCategory } from '../tools';
import { JupyterService } from '../jupyter-service';

export function createSearchTools(jupyterService: JupyterService): ITool[] {
  return [
    // ═══════════════════════════════════════════
    // find_in_notebook
    // ═══════════════════════════════════════════
    {
      name: 'find_in_notebook',
      safetyLevel: ToolSafetyLevel.READ,
      category: 'search' as ToolCategory,
      description:
        'Search for text or pattern across all cells in the active notebook. Returns cell indices, line numbers, and matching lines. Useful for finding where a variable, function, or pattern is used.',
      parameters: {
        type: 'object',
        properties: {
          query: {
            type: 'string',
            description: 'Text to search for, or a regex pattern if regex=true'
          },
          case_sensitive: {
            type: 'boolean',
            description: 'Whether search is case-sensitive (default: false)'
          },
          regex: {
            type: 'boolean',
            description: 'Treat query as a regular expression (default: false)'
          },
          cell_type: {
            type: 'string',
            enum: ['code', 'markdown'],
            description: 'Search only in cells of this type (default: all)'
          }
        },
        required: ['query']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const query = args.query as string;
        const caseSensitive = args.case_sensitive as boolean | undefined;
        const regex = args.regex as boolean | undefined;
        const cellType = args.cell_type as 'code' | 'markdown' | undefined;

        const result = jupyterService.findInNotebook(query, {
          caseSensitive,
          regex,
          cellType
        });

        if (!result.success) {
          return { success: false, error: result.error };
        }

        const matches = result.matches || [];

        if (matches.length === 0) {
          return {
            success: true,
            result: {
              found: false,
              message: `No matches found for "${query}"`,
              total_matches: 0
            }
          };
        }

        // Группируем по ячейкам для читабельности
        const byCell: Record<number, typeof matches> = {};
        for (const m of matches) {
          if (!byCell[m.cellIndex]) {
            byCell[m.cellIndex] = [];
          }
          byCell[m.cellIndex].push(m);
        }

        const summary = Object.entries(byCell)
          .map(([idx, cellMatches]) => {
            const cellType = cellMatches[0].cellType;
            const lines = cellMatches
              .map(m => `  Line ${m.lineNumber}: ${m.line.trim()}`)
              .join('\n');
            // cellIndex теперь 0-based (как и в jupyterService.findInNotebook)
            return `Cell [${parseInt(idx)}] (${cellType}):\n${lines}`;
          })
          .join('\n\n');

        return {
          success: true,
          result: {
            found: true,
            total_matches: matches.length,
            cells_with_matches: Object.keys(byCell).length,
            matches: matches.slice(0, 50), // максимум 50 совпадений
            summary
          }
        };
      }
    },

    // ═══════════════════════════════════════════
    // replace_in_cell
    // ═══════════════════════════════════════════
    {
      name: 'replace_in_cell',
      safetyLevel: ToolSafetyLevel.WRITE,
      category: 'search' as ToolCategory,
      description:
        'Replace text in a specific cell without rewriting the entire cell. Supports literal text and regex replacements. Useful for renaming variables, fixing typos, or modifying specific parts of code.',
      parameters: {
        type: 'object',
        properties: {
          index: {
            type: 'integer',
            description: 'Cell number (0-based, first cell is 0)'
          },
          search: {
            type: 'string',
            description: 'Text to find (literal or regex if regex=true)'
          },
          replace: {
            type: 'string',
            description:
              'Replacement text. For regex, supports $1, $2 backreferences.'
          },
          case_sensitive: {
            type: 'boolean',
            description: 'Case-sensitive search (default: false)'
          },
          regex: {
            type: 'boolean',
            description: 'Use regex for search (default: false)'
          },
          replace_all: {
            type: 'boolean',
            description:
              'Replace all occurrences or only first (default: true = all)'
          }
        },
        required: ['index', 'search', 'replace']
      },
      async execute(args: Record<string, unknown>): Promise<IToolResult> {
        const index = args.index as number;
        const search = args.search as string;
        const replace = args.replace as string;
        const caseSensitive = args.case_sensitive as boolean | undefined;
        const regex = args.regex as boolean | undefined;
        const replaceAll = args.replace_all as boolean | undefined;

        const result = jupyterService.replaceInCell(index, search, replace, {
          caseSensitive,
          regex,
          replaceAll
        });

        if (!result.success) {
          return { success: false, error: result.error };
        }

        return {
          success: true,
          result: {
            replacements: result.replacements,
            message: `Replaced ${result.replacements} occurrence(s) of "${search}" with "${replace}" in cell [${index}]`
          }
        };
      }
    }
  ];
}
