import { ILLMToolCall, ILLMResponse } from './api';
import { formatTokenCount } from './token-counter';
import hljs from 'highlight.js';

function parseInlineMarkdown(text: string): string {
  let result = text;
  result = result.replace(/`(.+?)`/g, '<code>$1</code>');
  result = result.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  result = result.replace(/__(.+?)__/g, '<strong>$1</strong>');
  result = result.replace(/\*(.+?)\*/g, '<em>$1</em>');
  result = result.replace(/_(.+?)_/g, '<em>$1</em>');
  result = result.replace(/~~(.+?)~~/g, '<del>$1</del>');
  result = result.replace(
    /\[(.+?)\]\((.+?)\)/g,
    '<a href="$2" target="_blank">$1</a>'
  );
  return result;
}

function parseMarkdown(text: string): string {
  let html = text;

  // Экранирование HTML
  html = html
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  // Сохраняем таблицы в placeholder (до форматирования текста)
  const tables: string[] = [];
  html = html.replace(
    /^\|(.+)\|\n\|[-:| ]+\|\n((?:\|.*\|\n?)+)/gm,
    (_match, headerRow, bodyRows) => {
      const headers = headerRow
        .split('|')
        .filter((h: string) => h.trim())
        .map((h: string) => `<th>${parseInlineMarkdown(h.trim())}</th>`)
        .join('');
      const rows = bodyRows
        .trim()
        .split('\n')
        .map((row: string) => {
          const cells = row
            .split('|')
            .filter((c: string) => c.trim())
            .map((c: string) => `<td>${parseInlineMarkdown(c.trim())}</td>`)
            .join('');
          return `<tr>${cells}</tr>`;
        })
        .join('');
      tables.push(
        `<table><thead><tr>${headers}</tr></thead><tbody>${rows}</tbody></table>`
      );
      return `<!--TABLE${tables.length - 1}-->`;
    }
  );

  // Сохраняем блоки кода в placeholder с подсветкой синтаксиса
  const codeBlocks: string[] = [];
  html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, (_match, lang, code) => {
    const idx = codeBlocks.length;
    const langClass = lang ? `language-${lang}` : '';
    const highlighted = hljs.highlightAuto(code).value;
    codeBlocks.push(
      `<pre class="code-block"><code class="${langClass}">${highlighted}</code></pre>`
    );
    return `<!--CODEBLOCK${idx}-->`;
  });

  // Инлайн код `code`
  html = html.replace(/`(.+?)`/g, '<code>$1</code>');

  // Жирный текст
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/__(.+?)__/g, '<strong>$1</strong>');

  // Курсив
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
  html = html.replace(/_(.+?)_/g, '<em>$1</em>');

  // Зачёркнутый
  html = html.replace(/~~(.+?)~~/g, '<del>$1</del>');

  // Ссылки
  html = html.replace(
    /\[(.+?)\]\((.+?)\)/g,
    '<a href="$2" target="_blank">$1</a>'
  );

  // Маркированные списки
  html = html.replace(/^[-*]\s+(.+)$/gm, '<li>$1</li>');
  html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>');

  // Нумерованные списки
  html = html.replace(/^\d+\.\s+(.+)$/gm, '<li>$1</li>');

  // Заголовки
  html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');

  // Переносы строк
  html = html.replace(/\n/g, '<br>');

  // Восстанавливаем таблицы
  tables.forEach((table, i) => {
    html = html.replace(`<!--TABLE${i}-->`, table);
  });

  // Восстанавливаем блоки кода
  codeBlocks.forEach((block, i) => {
    html = html.replace(`<!--CODEBLOCK${i}-->`, block);
  });

  return html;
}

export interface IStreamCallbacks {
  onToken: (token: string) => void;
  onToolCalls: (toolCalls: ILLMToolCall[]) => void;
  onDone: (fullMessage: ILLMResponse['message']) => void;
  onError: (error: string) => void;
}

export class ChatUI {
  private messagesArea: HTMLElement;
  private inputField: HTMLTextAreaElement;
  private sendButton: HTMLButtonElement;
  private stopButton: HTMLButtonElement;
  private tokenCounter: HTMLElement;

  constructor(container: HTMLElement) {
    this.messagesArea = container.querySelector(
      '.ai-agent-messages'
    ) as HTMLElement;
    this.inputField = container.querySelector(
      '.ai-agent-input'
    ) as HTMLTextAreaElement;
    this.sendButton = container.querySelector(
      '.ai-agent-send-button'
    ) as HTMLButtonElement;
    this.stopButton = container.querySelector(
      '.ai-agent-stop-button'
    ) as HTMLButtonElement;
    this.tokenCounter = container.querySelector(
      '.ai-agent-token-counter'
    ) as HTMLElement;
  }

  addBubble(role: 'user' | 'assistant', text: string): void {
    const messageDiv = document.createElement('div');
    messageDiv.className = `ai-agent-message ${role}`;

    const roleLabel = document.createElement('span');
    roleLabel.className = 'ai-agent-message-role';
    roleLabel.textContent = role === 'user' ? 'You:' : 'AI:';

    const textDiv = document.createElement('div');
    textDiv.className = 'ai-agent-message-text';
    textDiv.innerHTML = parseMarkdown(text);

    messageDiv.appendChild(roleLabel);
    messageDiv.appendChild(textDiv);
    this.messagesArea.appendChild(messageDiv);
    this.scrollToBottom();
  }

  addErrorBubbleWithRetry(errorText: string, onRetry: () => void): void {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'ai-agent-message assistant ai-agent-error-message';

    const roleLabel = document.createElement('span');
    roleLabel.className = 'ai-agent-message-role';
    roleLabel.textContent = 'AI:';

    const textDiv = document.createElement('div');
    textDiv.className = 'ai-agent-message-text';
    textDiv.innerHTML = parseMarkdown(errorText);

    const retryButton = document.createElement('button');
    retryButton.className = 'ai-agent-retry-button';
    retryButton.innerHTML = '&#8635; Retry';
    retryButton.title = 'Retry last request';

    messageDiv.appendChild(roleLabel);
    messageDiv.appendChild(textDiv);
    messageDiv.appendChild(retryButton);
    this.messagesArea.appendChild(messageDiv);
    this.scrollToBottom();

    retryButton.addEventListener('click', () => {
      messageDiv.remove();
      onRetry();
    });
  }

  addToolBubble(
    name: string,
    args: Record<string, unknown>,
    status: string
  ): HTMLElement {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'ai-agent-tool-call';

    const statusIcon =
      {
        pending: '&#9203;',
        completed: '&#10004;',
        error: '&#10060;'
      }[status] || '&#9203;';

    const headerDiv = document.createElement('div');
    headerDiv.className = 'ai-agent-tool-call-header';
    headerDiv.innerHTML = `
      <span class="tool-collapse-icon">▼</span>
      <span class="tool-status">${statusIcon}</span>
      <strong>${name}</strong>
    `;

    const bodyDiv = document.createElement('div');
    bodyDiv.className = 'ai-agent-tool-call-body';

    const argsDiv = document.createElement('div');
    argsDiv.className = 'ai-agent-tool-call-args';
    argsDiv.textContent = ChatUI.formatArgs(name, args);

    bodyDiv.appendChild(argsDiv);
    messageDiv.appendChild(headerDiv);
    messageDiv.appendChild(bodyDiv);

    headerDiv.addEventListener('click', () => {
      const isCollapsed = messageDiv.classList.toggle('collapsed');
      const icon = headerDiv.querySelector(
        '.tool-collapse-icon'
      ) as HTMLElement;
      if (icon) {
        icon.textContent = isCollapsed ? '▶' : '▼';
      }
    });

    this.messagesArea.appendChild(messageDiv);
    this.scrollToBottom();

    return messageDiv;
  }

  updateToolBubble(
    el: HTMLElement,
    status: 'completed' | 'error',
    result: string
  ): void {
    const icon = status === 'completed' ? '✅' : '❌';
    const statusEl = el.querySelector('.tool-status');
    if (statusEl) {
      statusEl.textContent = icon;
    }

    const bodyDiv = el.querySelector('.ai-agent-tool-call-body');
    if (!bodyDiv) {
      return;
    }

    const resultDiv = document.createElement('div');
    resultDiv.className = `ai-agent-tool-call-result ${status}`;

    try {
      const parsed = JSON.parse(result);
      if (parsed.outputs && Array.isArray(parsed.outputs)) {
        for (const output of parsed.outputs) {
          if (output.type === 'image' && output.base64) {
            const img = document.createElement('img');
            img.className = 'ai-agent-output-image';
            img.src = `data:${output.mime_type || 'image/png'};base64,${output.base64}`;
            img.alt = output.alt_text || 'Cell output';
            img.style.maxWidth = '100%';
            img.style.maxHeight = '400px';
            img.style.borderRadius = '4px';
            img.style.marginTop = '8px';
            resultDiv.appendChild(img);
          } else if (output.content) {
            const textNode = document.createElement('pre');
            textNode.className = 'ai-agent-output-text';
            textNode.textContent =
              typeof output.content === 'string'
                ? output.content
                : JSON.stringify(output.content, null, 2);
            resultDiv.appendChild(textNode);
          }
        }
      } else {
        resultDiv.textContent = result;
      }
    } catch {
      resultDiv.textContent = result;
    }

    if (result.length > 500) {
      resultDiv.textContent = result.substring(0, 500) + '...';

      const showMore = document.createElement('button');
      showMore.className = 'ai-agent-show-more';
      showMore.textContent = 'Show full result';
      showMore.addEventListener('click', () => {
        resultDiv.textContent = result;
        showMore.remove();
      });

      bodyDiv.appendChild(resultDiv);
      bodyDiv.appendChild(showMore);
    } else {
      bodyDiv.appendChild(resultDiv);
    }

    if (status === 'completed') {
      el.classList.add('collapsed');
      const collapseIcon = el.querySelector(
        '.tool-collapse-icon'
      ) as HTMLElement;
      if (collapseIcon) {
        collapseIcon.textContent = '▶';
      }
    }

    this.scrollToBottom();
  }

  addThinkingIndicator(): HTMLElement {
    const div = document.createElement('div');
    div.className = 'ai-agent-thinking';
    div.innerHTML = '<em>Agent is thinking...</em>';
    this.messagesArea.appendChild(div);
    this.scrollToBottom();
    return div;
  }

  createAssistantBubble(): { bubble: HTMLElement; textEl: HTMLElement } {
    const bubble = document.createElement('div');
    bubble.className = 'ai-agent-message assistant';

    const roleLabel = document.createElement('span');
    roleLabel.className = 'ai-agent-message-role';
    roleLabel.textContent = 'AI:';

    const textEl = document.createElement('div');
    textEl.className = 'ai-agent-message-text';
    textEl.textContent = '';

    bubble.appendChild(roleLabel);
    bubble.appendChild(textEl);
    this.messagesArea.appendChild(bubble);

    return { bubble, textEl };
  }

  scrollToBottom(): void {
    this.messagesArea.scrollTop = this.messagesArea.scrollHeight;
  }

  setLoading(loading: boolean): void {
    this.sendButton.disabled = loading;
    this.inputField.disabled = loading;

    if (loading) {
      this.sendButton.classList.add('ai-agent-hidden');
      this.stopButton.classList.remove('ai-agent-hidden');
    } else {
      this.sendButton.classList.remove('ai-agent-hidden');
      this.stopButton.classList.add('ai-agent-hidden');
    }
  }

  updateTokenCounter(tokens: number): void {
    this.tokenCounter.textContent = `~${formatTokenCount(tokens)} tokens`;
    this.tokenCounter.title = `Approximately ${tokens} tokens in context`;
  }

  static formatArgs(toolName: string, args: Record<string, unknown>): string {
    switch (toolName) {
      case 'create_cell':
        return `Create ${args.cell_type} cell:\n${((args.source as string) || '').substring(0, 200)}${((args.source as string) || '').length > 200 ? '...' : ''}`;
      case 'execute_cell':
        return `Execute cell [${args.index}]`;
      case 'get_cell_output':
        return `Get cell output [${args.index}]`;
      case 'update_cell':
        return `Update cell [${args.index}]`;
      case 'delete_cell':
        return `Delete cell [${args.index}]`;
      case 'get_notebook_content':
        return 'Read notebook content';
      case 'get_cell_content':
        return `Read cell [${args.index}]`;
      case 'find_in_notebook':
        return `Search in notebook: "${args.query}"${args.regex ? ' (regex)' : ''}${args.case_sensitive ? ' (case-sensitive)' : ''}`;
      case 'replace_in_cell':
        return `Replace in cell [${args.index}]: "${args.search}" -> "${args.replace}"${args.replace_all ? ' (all)' : ' (first)'}`;
      case 'read_file':
        return `Read file: ${args.path}${args.max_lines ? ` (first ${args.max_lines} lines)` : ''}`;
      case 'write_file':
        return `Write file: ${args.path} (${((args.content as string) || '').length} chars)`;
      case 'list_directory':
        return `List files: ${args.path || '.'}`;
      case 'create_notebook':
        return `Create notebook: ${args.path || ''}${args.name}`;
      case 'delete_file':
        return `Delete: ${args.path}`;
      case 'rename_file':
        return `Rename: ${args.old_path} -> ${args.new_path}`;
      case 'run_shell':
        return `Run command: ${args.command}`;
      case 'install_package':
        return `Install package: ${args.package_name} (${args.manager || 'pip'})${args.extra_args ? ` ${args.extra_args}` : ''}`;
      case 'list_packages':
        return `List packages${args.filter ? `: filter "${args.filter}"` : ''}`;

      default:
        return JSON.stringify(args, null, 2);
    }
  }

  static escapeHtml(text: string): string {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}
