import { JupyterFrontEnd } from '@jupyterlab/application';
import {
  INotebookTracker,
  NotebookPanel,
  NotebookActions
} from '@jupyterlab/notebook';
import { CodeCellModel } from '@jupyterlab/cells';
import { Contents } from '@jupyterlab/services';

/**
 * Структура вывода ячейки
 */
export interface ICellOutputItem {
  type: 'text' | 'image' | 'html' | 'error' | 'json';
  /** Текстовое содержимое (для text, error) */
  text?: string;
  /** Base64-данные (для image) */
  data?: string;
  /** MIME-тип (для image, html) */
  mimeType?: string;
  /** HTML-содержимое (для rich output вроде DataFrame) */
  html?: string;
}

/**
 * Сервис для работы с JupyterLab Notebook API
 */
export class JupyterService {
  private app: JupyterFrontEnd;
  private notebookTracker: INotebookTracker;

  constructor(app: JupyterFrontEnd, notebookTracker: INotebookTracker) {
    this.app = app;
    this.notebookTracker = notebookTracker;
  }

  /**
   * Доступ к ContentsManager через ServiceManager
   */
  private get contents(): Contents.IManager {
    return this.app.serviceManager.contents;
  }

  /**
   * Получить активный ноутбук
   */
  getActiveNotebook(): NotebookPanel | null {
    return this.notebookTracker.currentWidget || null;
  }

  /**
   * Создать новую ячейку
   */
  async createCell(
    cellType: 'code' | 'markdown',
    source: string
  ): Promise<{ success: boolean; index?: number; error?: string }> {
    const panel = this.getActiveNotebook();
    if (!panel) {
      return { success: false, error: 'No active notebook' };
    }

    const notebook = panel.content;
    const model = notebook.model;
    if (!model) {
      return { success: false, error: 'Notebook has no model' };
    }

    // Запоминаем индекс до создания
    const currentIndex = notebook.activeCellIndex;
    const insertIndex = currentIndex + 1;

    // Создаём ячейку через NotebookActions.insertBelow (всегда code)
    NotebookActions.insertBelow(notebook);

    // Ждём инициализации ячейки
    await new Promise(resolve => setTimeout(resolve, 50));

    // Если нужна markdown — меняем тип через команду
    if (cellType === 'markdown') {
      notebook.activeCellIndex = insertIndex;
      await this.app.commands.execute('notebook:change-cell-to-markdown');
      await new Promise(resolve => setTimeout(resolve, 50));
    }

    // Получаем созданную ячейку
    const targetCell = model.cells.get(insertIndex);

    if (!targetCell) {
      return { success: false, error: 'Failed to create cell' };
    }

    // Устанавливаем содержимое через sharedModel или value
    if ((targetCell as any).sharedModel) {
      (targetCell as any).sharedModel.setSource(source);
    } else if ((targetCell as any).value) {
      (targetCell as any).value.text = source;
    }

    // Делаем созданную ячейку активной
    notebook.activeCellIndex = insertIndex;

    return { success: true, index: insertIndex };
  }

  /**
   * Обновить содержимое ячейки
   */
  updateCell(
    index: number,
    source: string
  ): { success: boolean; error?: string } {
    const panel = this.getActiveNotebook();
    if (!panel) {
      return { success: false, error: 'No active notebook' };
    }

    const notebook = panel.content;
    const model = notebook.model;
    if (!model) {
      return { success: false, error: 'Notebook has no model' };
    }

    if (index < 0 || index >= model.cells.length) {
      return { success: false, error: `Invalid cell index: ${index}` };
    }

    const cell = model.cells.get(index);

    // Устанавливаем содержимое через sharedModel или value
    if ((cell as any).sharedModel) {
      (cell as any).sharedModel.setSource(source);
    } else if ((cell as any).value) {
      (cell as any).value.text = source;
    } else {
      return { success: false, error: 'Failed to set cell content' };
    }

    return { success: true };
  }

  /**
   * Удалить ячейку
   */
  deleteCell(index: number): { success: boolean; error?: string } {
    const panel = this.getActiveNotebook();
    if (!panel) {
      return { success: false, error: 'No active notebook' };
    }

    const notebook = panel.content;
    const model = notebook.model;
    if (!model) {
      return { success: false, error: 'Notebook has no model' };
    }

    if (index < 0 || index >= model.cells.length) {
      return { success: false, error: `Invalid cell index: ${index}` };
    }

    // Выделяем ячейку и удаляем через команду
    notebook.activeCellIndex = index;
    this.app.commands.execute('notebook:delete-cell');

    return { success: true };
  }

  /**
   * Получить содержимое ячейки
   */
  getCellContent(index: number): {
    success: boolean;
    cellType?: string;
    source?: string;
    error?: string;
  } {
    const panel = this.getActiveNotebook();
    if (!panel) {
      return { success: false, error: 'No active notebook' };
    }

    const notebook = panel.content;
    const model = notebook.model;
    if (!model) {
      return { success: false, error: 'Notebook has no model' };
    }

    if (index < 0 || index >= model.cells.length) {
      return { success: false, error: `Invalid cell index: ${index}` };
    }

    const cell = model.cells.get(index);
    let source = '';

    // Пробуем получить source через sharedModel или value
    if ((cell as any).sharedModel) {
      source = (cell as any).sharedModel.getSource();
    } else if ((cell as any).value) {
      source = (cell as any).value.text;
    }

    return {
      success: true,
      cellType: cell.type,
      source
    };
  }

  /**
   * Метаданные ячейки для tool result
   */
  getCellMetadata(index: number): {
    success: boolean;
    execution_count?: number | null;
    outputs_count?: number;
    has_error?: boolean;
    error?: string;
  } {
    const panel = this.getActiveNotebook();
    if (!panel) {
      return { success: false, error: 'No active notebook' };
    }

    const notebook = panel.content;
    const model = notebook.model;
    if (!model) {
      return { success: false, error: 'Notebook has no model' };
    }

    if (index < 0 || index >= model.cells.length) {
      return { success: false, error: `Invalid cell index: ${index}` };
    }

    const cell = model.cells.get(index);

    if (cell.type !== 'code') {
      return { success: false, error: 'Cell is not a code cell' };
    }

    const codeCell = cell as CodeCellModel;
    const outputs = codeCell.outputs;

    let hasError = false;
    for (let i = 0; i < outputs.length; i++) {
      const output = outputs.get(i);
      const raw = (output as any)?._raw;
      if (raw?.output_type === 'error') {
        hasError = true;
        break;
      }
    }

    return {
      success: true,
      execution_count: (codeCell as any).executionCount ?? null,
      outputs_count: outputs.length,
      has_error: hasError
    };
  }

  /**
   * Получить содержимое всего ноутбука
   */
  getNotebookContent(): {
    success: boolean;
    cells?: Array<{
      type: string;
      source: string;
      execution_count?: number | null;
      outputs_count?: number;
      has_error?: boolean;
      outputs_summary?: string;
    }>;
    error?: string;
  } {
    const panel = this.getActiveNotebook();
    if (!panel) {
      return { success: false, error: 'No active notebook' };
    }

    const notebook = panel.content;
    const model = notebook.model;
    if (!model) {
      return { success: false, error: 'Notebook has no model' };
    }

    const cells: Array<{
      type: string;
      source: string;
      execution_count?: number | null;
      outputs_count?: number;
      has_error?: boolean;
      outputs_summary?: string;
    }> = [];
    for (let i = 0; i < model.cells.length; i++) {
      const cell = model.cells.get(i);
      let source = '';

      if ((cell as any).sharedModel) {
        source = (cell as any).sharedModel.getSource();
      } else if ((cell as any).value) {
        source = (cell as any).value.text;
      }

      const cellData: {
        type: string;
        source: string;
        execution_count?: number | null;
        outputs_count?: number;
        has_error?: boolean;
        outputs_summary?: string;
      } = {
        type: cell.type,
        source
      };

      if (cell.type === 'code') {
        const codeCell = cell as CodeCellModel;
        const outputs = codeCell.outputs;
        const executionCount = (codeCell as any).executionCount ?? null;

        let hasError = false;
        let imageCount = 0;
        let textCount = 0;
        let htmlCount = 0;
        let jsonCount = 0;

        for (let j = 0; j < outputs.length; j++) {
          const output = outputs.get(j);
          const raw = (output as any)?._raw;

          if (raw?.output_type === 'error') {
            hasError = true;
          } else if (raw?.data) {
            const data = raw.data;
            if (
              data['image/png'] ||
              data['image/jpeg'] ||
              data['image/svg+xml']
            ) {
              imageCount++;
            } else if (data['text/html']) {
              htmlCount++;
            } else if (data['application/json']) {
              jsonCount++;
            } else if (data['text/plain']) {
              textCount++;
            }
          } else if (raw?.output_type === 'stream') {
            textCount++;
          }
        }

        cellData.execution_count = executionCount;
        cellData.outputs_count = outputs.length;
        cellData.has_error = hasError;

        const summaryParts: string[] = [];
        if (outputs.length === 0) {
          summaryParts.push('no output');
        } else {
          if (imageCount > 0) {
            summaryParts.push(
              `${imageCount} image${imageCount > 1 ? 's' : ''}`
            );
          }
          if (htmlCount > 0) {
            summaryParts.push(`${htmlCount} HTML`);
          }
          if (jsonCount > 0) {
            summaryParts.push(`${jsonCount} JSON`);
          }
          if (textCount > 0) {
            summaryParts.push(`${textCount} text`);
          }
        }
        if (hasError) {
          summaryParts.push('ERROR');
        }
        cellData.outputs_summary = summaryParts.join(', ');
      }

      cells.push(cellData);
    }

    return { success: true, cells };
  }

  /**
   * Выполнить ячейку (code) или отрендерить markdown ячейку
   * @param timeoutMs — максимальное время ожидания в мс (по умолчанию 120000 = 2 мин)
   */
  async executeCell(
    index: number,
    timeoutMs: number = 120000
  ): Promise<{
    success: boolean;
    error?: string;
  }> {
    const panel = this.getActiveNotebook();
    if (!panel) {
      return { success: false, error: 'No active notebook' };
    }

    const notebook = panel.content;
    const model = notebook.model;
    if (!model) {
      return { success: false, error: 'Notebook has no model' };
    }

    if (index < 0 || index >= model.cells.length) {
      return { success: false, error: `Invalid cell index: ${index}` };
    }

    const cell = model.cells.get(index);

    // Делаем ячейку активной
    notebook.activeCellIndex = index;

    // Для markdown ячеек — рендерим через команду
    if (cell.type === 'markdown') {
      await this.app.commands.execute('notebook:render-all-markdown');
      // Небольшая пауза для рендеринга
      await new Promise(resolve => setTimeout(resolve, 100));
      return { success: true };
    }

    // Для code ячеек — выполняем через ядро
    if (cell.type !== 'code') {
      return { success: false, error: `Unsupported cell type: ${cell.type}` };
    }

    // Проверяем подключение ядра
    const session = panel.sessionContext;
    if (!session.session?.kernel) {
      return { success: false, error: 'No kernel connected' };
    }

    // Выполняем через команду JupyterLab
    await this.app.commands.execute('notebook:run-cell', { activate: false });

    // Ждём завершения ядра с таймаутом
    const waitResult = await this.waitForKernelIdle(timeoutMs);

    if (!waitResult.success) {
      // ★ Прерываем ядро при таймауте
      if (waitResult.error?.includes('timeout')) {
        try {
          const kernel = panel.sessionContext.session?.kernel;
          if (kernel) {
            await kernel.interrupt();
          }
        } catch {
          // Игнорируем ошибки прерывания
        }
      }
      return { success: false, error: waitResult.error };
    }

    // Маленькая пауза для синхронизации output model
    await new Promise(resolve => setTimeout(resolve, 100));

    return { success: true };
  }

  /**
   * Получить вывод ячейки (обновлённый — с поддержкой изображений)
   */
  getCellOutput(index: number): {
    success: boolean;
    outputs?: ICellOutputItem[];
    error?: string;
  } {
    const panel = this.getActiveNotebook();
    if (!panel) {
      return { success: false, error: 'No active notebook' };
    }

    const notebook = panel.content;
    const model = notebook.model;
    if (!model) {
      return { success: false, error: 'Notebook has no model' };
    }

    if (index < 0 || index >= model.cells.length) {
      return { success: false, error: `Invalid cell index: ${index}` };
    }

    const cell = model.cells.get(index);

    if (cell.type !== 'code') {
      return { success: false, error: 'Cell is not a code cell' };
    }

    const codeCell = cell as CodeCellModel;
    const outputs: ICellOutputItem[] = [];

    for (let i = 0; i < codeCell.outputs.length; i++) {
      const output = codeCell.outputs.get(i);

      // В JupyterLab 4.3+ output це Y.Map, тому використовуємо toJSON() для отримання даних
      let outputData: any;
      let outputType: string;

      // Спосіб 1: через toJSON() — повертає звичайний об'єкт
      if (typeof (output as any).toJSON === 'function') {
        outputData = (output as any).toJSON();
        outputType = outputData?.output_type;
      }
      // Спосіб 2: через _raw
      else if ((output as any)._raw) {
        outputData = (output as any)._raw;
        outputType = outputData?.output_type;
      } else {
        outputData = output as any;
        outputType = outputData.get?.('output_type') || outputData.output_type;
      }

      let data: any = {};
      if (outputData?.data) {
        data = outputData.data;
      }

      switch (outputType) {
        case 'stream':
          outputs.push({
            type: 'text',
            text: outputData.text || outputData.get?.('text')
          });
          break;

        case 'execute_result':
        case 'display_data': {
          // Приоритет: image > html > json > text
          if (data['image/png']) {
            const pngData = data['image/png'];
            outputs.push({
              type: 'image',
              mimeType: 'image/png',
              data: pngData,
              text: data['text/plain'] || '(image)'
            });
          } else if (data['image/jpeg']) {
            const jpegData = data['image/jpeg'];
            outputs.push({
              type: 'image',
              mimeType: 'image/jpeg',
              data: jpegData,
              text: data['text/plain'] || '(image)'
            });
          } else if (data['image/svg+xml']) {
            const svgData = data['image/svg+xml'];
            outputs.push({
              type: 'image',
              mimeType: 'image/svg+xml',
              data: svgData,
              text: data['text/plain'] || '(SVG image)'
            });
          } else if (data['text/html']) {
            outputs.push({
              type: 'html',
              html: data['text/html'],
              text: data['text/plain'] || '(HTML output)'
            });
          } else if (data['application/json']) {
            outputs.push({
              type: 'json',
              text: JSON.stringify(data['application/json'], null, 2)
            });
          } else if (data['text/plain']) {
            outputs.push({
              type: 'text',
              text: data['text/plain']
            });
          }
          break;
        }

        case 'error':
          outputs.push({
            type: 'error',
            text: `${outputData.ename}: ${outputData.evalue}`
          });
          break;
      }
    }

    return { success: true, outputs };
  }

  /**
   * Дождаться завершения выполнения ядра (busy → idle)
   * @param timeoutMs — максимальное время ожидания (по умолчанию 120 секунд)
   * @returns true если ядро перешло в idle, false если таймаут
   */
  async waitForKernelIdle(timeoutMs: number = 120000): Promise<{
    success: boolean;
    error?: string;
  }> {
    const panel = this.getActiveNotebook();
    if (!panel) {
      return { success: false, error: 'No active notebook' };
    }

    const session = panel.sessionContext;
    const kernel = session.session?.kernel;
    if (!kernel) {
      return { success: false, error: 'No kernel connected' };
    }

    // Если ядро уже idle — сразу возвращаем
    if (kernel.status === 'idle') {
      return { success: true };
    }

    // Ждём перехода в idle
    return new Promise<{ success: boolean; error?: string }>(resolve => {
      let resolved = false;

      const onStatusChanged = (_kernel: unknown, status: string) => {
        if (resolved) {
          return;
        }

        if (status === 'idle') {
          resolved = true;
          kernel.statusChanged.disconnect(onStatusChanged);
          clearTimeout(timer);
          resolve({ success: true });
        } else if (status === 'dead' || status === 'restarting') {
          resolved = true;
          kernel.statusChanged.disconnect(onStatusChanged);
          clearTimeout(timer);
          resolve({
            success: false,
            error: `Kernel ${status} during execution`
          });
        }
      };

      // Таймаут
      const timer = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          kernel.statusChanged.disconnect(onStatusChanged);
          resolve({
            success: false,
            error: `Kernel timeout after ${timeoutMs / 1000}s`
          });
        }
      }, timeoutMs);

      // Подписываемся на изменение статуса
      kernel.statusChanged.connect(onStatusChanged);
    });
  }

  // ═══════════════════════════════════════════
  // Файловая система
  // ═══════════════════════════════════════════

  /**
   * Прочитать содержимое файла
   */
  async readFile(path: string): Promise<{
    success: boolean;
    content?: string;
    mimeType?: string;
    size?: number;
    error?: string;
  }> {
    try {
      const safePath = this.sanitizePath(path);

      const model = await this.contents.get(safePath, {
        content: true,
        type: 'file',
        format: 'text'
      });

      return {
        success: true,
        content: model.content as string,
        mimeType: model.mimetype || 'text/plain',
        size: (model.content as string)?.length || 0
      };
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);

      if (msg.includes('404') || msg.includes('not found')) {
        return { success: false, error: `File not found: ${path}` };
      }
      if (msg.includes('400') || msg.includes('is a directory')) {
        return {
          success: false,
          error: `Path is a directory, not a file: ${path}. Use list_directory instead.`
        };
      }

      return { success: false, error: `Failed to read file: ${msg}` };
    }
  }

  /**
   * Записать содержимое в файл (создать или перезаписать)
   */
  async writeFile(
    path: string,
    content: string
  ): Promise<{
    success: boolean;
    created?: boolean;
    error?: string;
  }> {
    try {
      const safePath = this.sanitizePath(path);

      let exists = true;
      try {
        await this.contents.get(safePath, { content: false });
      } catch {
        exists = false;
      }

      await this.ensureDirectory(safePath);

      await this.contents.save(safePath, {
        type: 'file',
        format: 'text',
        content: content
      });

      return {
        success: true,
        created: !exists
      };
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      return { success: false, error: `Failed to write file: ${msg}` };
    }
  }

  /**
   * Получить список файлов в директории
   */
  async listDirectory(path: string = ''): Promise<{
    success: boolean;
    items?: Array<{
      name: string;
      path: string;
      type: 'file' | 'directory' | 'notebook';
      size?: number;
      lastModified?: string;
    }>;
    error?: string;
  }> {
    try {
      const safePath = this.sanitizePath(path);

      const model = await this.contents.get(safePath, {
        content: true,
        type: 'directory'
      });

      if (model.type !== 'directory') {
        return { success: false, error: `Path is not a directory: ${path}` };
      }

      const items = (model.content as Contents.IModel[]).map(item => ({
        name: item.name,
        path: item.path,
        type: item.type as 'file' | 'directory' | 'notebook',
        size: item.size || undefined,
        lastModified: item.last_modified || undefined
      }));

      items.sort((a, b) => {
        if (a.type === 'directory' && b.type !== 'directory') {
          return -1;
        }
        if (a.type !== 'directory' && b.type === 'directory') {
          return 1;
        }
        return a.name.localeCompare(b.name);
      });

      return { success: true, items };
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      return { success: false, error: `Failed to list directory: ${msg}` };
    }
  }

  /**
   * Создать новый ноутбук
   */
  async createNotebook(
    name: string,
    path: string = ''
  ): Promise<{
    success: boolean;
    path?: string;
    error?: string;
  }> {
    try {
      if (!name.endsWith('.ipynb')) {
        name = name + '.ipynb';
      }

      const safePath = this.sanitizePath(path);
      const fullPath = safePath ? `${safePath}/${name}` : name;

      try {
        await this.contents.get(fullPath, { content: false });
        return {
          success: false,
          error: `Notebook already exists: ${fullPath}`
        };
      } catch {
        // Файл не существует
      }

      const notebookContent = {
        cells: [
          {
            cell_type: 'code',
            source: '',
            metadata: {},
            outputs: [],
            execution_count: null
          }
        ],
        metadata: {
          kernelspec: {
            display_name: 'Python 3',
            language: 'python',
            name: 'python3'
          },
          language_info: {
            name: 'python',
            version: '3.9.0'
          }
        },
        nbformat: 4,
        nbformat_minor: 5
      };

      await this.contents.save(fullPath, {
        type: 'notebook',
        format: 'json',
        content: notebookContent
      });

      return { success: true, path: fullPath };
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      return { success: false, error: `Failed to create notebook: ${msg}` };
    }
  }

  /**
   * Удалить файл или директорию
   */
  async deleteFile(path: string): Promise<{
    success: boolean;
    error?: string;
  }> {
    try {
      const safePath = this.sanitizePath(path);
      await this.contents.delete(safePath);
      return { success: true };
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      return { success: false, error: `Failed to delete: ${msg}` };
    }
  }

  /**
   * Переименовать/переместить файл
   */
  async renameFile(
    oldPath: string,
    newPath: string
  ): Promise<{
    success: boolean;
    error?: string;
  }> {
    try {
      const safeOld = this.sanitizePath(oldPath);
      const safeNew = this.sanitizePath(newPath);
      await this.contents.rename(safeOld, safeNew);
      return { success: true };
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      return { success: false, error: `Failed to rename: ${msg}` };
    }
  }

  // ═══════════════════════════════════════════
  // Вспомогательные методы
  // ═══════════════════════════════════════════

  /**
   * Санитизация пути — защита от path traversal
   */
  private sanitizePath(path: string): string {
    const safe = path.replace(/^\/+/, '');
    const parts = safe.split('/').filter(part => {
      return part !== '' && part !== '.' && part !== '..';
    });
    return parts.join('/');
  }

  /**
   * Создать промежуточные директории для файла
   */
  private async ensureDirectory(filePath: string): Promise<void> {
    const parts = filePath.split('/');
    parts.pop();

    if (parts.length === 0) {
      return;
    }

    let currentPath = '';
    for (const part of parts) {
      currentPath = currentPath ? `${currentPath}/${part}` : part;

      try {
        await this.contents.get(currentPath, { content: false });
      } catch {
        await this.contents.save(currentPath, {
          type: 'directory',
          format: 'json',
          content: null
        } as any);
      }
    }
  }

  /**
   * Найти текст во всех ячейках ноутбука
   */
  findInNotebook(
    query: string,
    options?: {
      caseSensitive?: boolean;
      regex?: boolean;
      cellType?: 'code' | 'markdown';
    }
  ): {
    success: boolean;
    matches?: Array<{
      cellIndex: number;
      cellType: string;
      lineNumber: number;
      line: string;
      matchStart: number;
      matchEnd: number;
    }>;
    error?: string;
  } {
    const panel = this.getActiveNotebook();
    if (!panel) {
      return { success: false, error: 'No active notebook' };
    }

    const model = panel.content.model;
    if (!model) {
      return { success: false, error: 'Notebook has no model' };
    }

    const caseSensitive = options?.caseSensitive ?? false;
    const useRegex = options?.regex ?? false;
    const filterType = options?.cellType;

    let searchRegex: RegExp;
    try {
      if (useRegex) {
        searchRegex = new RegExp(query, caseSensitive ? 'g' : 'gi');
      } else {
        const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        searchRegex = new RegExp(escaped, caseSensitive ? 'g' : 'gi');
      }
    } catch (e) {
      return { success: false, error: `Invalid regex: ${query}` };
    }

    const matches: Array<{
      cellIndex: number;
      cellType: string;
      lineNumber: number;
      line: string;
      matchStart: number;
      matchEnd: number;
    }> = [];

    for (let i = 0; i < model.cells.length; i++) {
      const cell = model.cells.get(i);

      if (filterType && cell.type !== filterType) {
        continue;
      }

      let source = '';
      if ((cell as any).sharedModel) {
        source = (cell as any).sharedModel.getSource();
      } else if ((cell as any).value) {
        source = (cell as any).value.text;
      }

      const lines = source.split('\n');

      for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
        const line = lines[lineIdx];
        let match: RegExpExecArray | null;

        searchRegex.lastIndex = 0;

        while ((match = searchRegex.exec(line)) !== null) {
          matches.push({
            cellIndex: i,
            cellType: cell.type,
            lineNumber: lineIdx + 1,
            line: line,
            matchStart: match.index,
            matchEnd: match.index + match[0].length
          });

          if (match[0].length === 0) {
            searchRegex.lastIndex++;
          }
        }
      }
    }

    return { success: true, matches };
  }

  /**
   * Заменить текст в конкретной ячейке
   */
  replaceInCell(
    index: number,
    searchText: string,
    replaceText: string,
    options?: {
      caseSensitive?: boolean;
      regex?: boolean;
      replaceAll?: boolean;
    }
  ): {
    success: boolean;
    replacements?: number;
    error?: string;
  } {
    const panel = this.getActiveNotebook();
    if (!panel) {
      return { success: false, error: 'No active notebook' };
    }

    const model = panel.content.model;
    if (!model) {
      return { success: false, error: 'Notebook has no model' };
    }

    if (index < 0 || index >= model.cells.length) {
      return { success: false, error: `Invalid cell index: ${index}` };
    }

    const cell = model.cells.get(index);
    let source = '';
    if ((cell as any).sharedModel) {
      source = (cell as any).sharedModel.getSource();
    } else if ((cell as any).value) {
      source = (cell as any).value.text;
    }

    const caseSensitive = options?.caseSensitive ?? false;
    const useRegex = options?.regex ?? false;
    const replaceAll = options?.replaceAll ?? true;

    let searchRegex: RegExp;
    try {
      let flags = caseSensitive ? '' : 'i';
      if (replaceAll) {
        flags += 'g';
      }

      if (useRegex) {
        searchRegex = new RegExp(searchText, flags);
      } else {
        const escaped = searchText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        searchRegex = new RegExp(escaped, flags);
      }
    } catch (e) {
      return { success: false, error: `Invalid search pattern: ${searchText}` };
    }

    const matchCount = (source.match(searchRegex) || []).length;

    if (matchCount === 0) {
      return {
        success: false,
        error: `Text "${searchText}" not found in cell ${index}`
      };
    }

    const newSource = source.replace(searchRegex, replaceText);

    if ((cell as any).sharedModel) {
      (cell as any).sharedModel.setSource(newSource);
    } else if ((cell as any).value) {
      (cell as any).value.text = newSource;
    }

    return { success: true, replacements: matchCount };
  }
}
