import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';
import { ICommandPalette, IThemeManager } from '@jupyterlab/apputils';
import { INotebookTracker } from '@jupyterlab/notebook';
import { ChatPanel } from './chat-panel';
import { toolRegistry } from './tool-registry';
import { createNotebookTools } from './tools/notebook-tools';
import { createSearchTools } from './tools/search-tools';
import { createFileTools } from './tools/file-tools';
import { createShellTools } from './tools/shell-tools';
import { createPackageTools } from './tools/package-tools';
import { JupyterService } from './jupyter-service';
import { getSettings } from './settings-api';

/**
 * Зарегистрировать инструменты ноутбука с настройками image analysis
 */
async function registerNotebookTools(
  jupyterService: JupyterService
): Promise<void> {
  try {
    const settings = await getSettings();
    const notebookTools = createNotebookTools(jupyterService, {
      imageAnalysis: settings.image_analysis
    });
    notebookTools.forEach(tool => toolRegistry.register(tool));
    console.log(
      'Notebook tools:',
      notebookTools.map(t => t.name)
    );
  } catch (e) {
    console.warn('Failed to load settings, using defaults:', e);
    const notebookTools = createNotebookTools(jupyterService);
    notebookTools.forEach(tool => toolRegistry.register(tool));
  }
}

/**
 * Команда для переключения видимости AI Agent панели
 */
const COMMAND_ID = 'cellsistant:toggle';

/**
 * Плагин для добавления AI Agent боковой панели
 */
const plugin: JupyterFrontEndPlugin<void> = {
  id: 'cellsistant:plugin',
  description: 'AI Agent sidebar panel for JupyterLab.',
  autoStart: true,
  requires: [ICommandPalette, INotebookTracker, IThemeManager],
  activate: async (
    app: JupyterFrontEnd,
    palette: ICommandPalette,
    notebookTracker: INotebookTracker,
    themeManager: IThemeManager
  ) => {
    console.log('JupyterLab AI Agent extension is activated!');

    // Создаём сервис для работы с JupyterLab
    const jupyterService = new JupyterService(app, notebookTracker);

    // Регистрируем инструменты ноутбука (с настройками image analysis)
    await registerNotebookTools(jupyterService);

    // Регистрируем инструменты поиска и замены
    const searchTools = createSearchTools(jupyterService);
    searchTools.forEach(tool => toolRegistry.register(tool));

    // Регистрируем файловые инструменты
    const fileTools = createFileTools(jupyterService);
    fileTools.forEach(tool => toolRegistry.register(tool));

    // Регистрируем shell инструменты
    const shellTools = createShellTools();
    shellTools.forEach(tool => toolRegistry.register(tool));

    // Регистрируем package инструменты
    const packageTools = createPackageTools();
    packageTools.forEach(tool => toolRegistry.register(tool));

    console.log('All tools registered');

    // Создаём панель чата с themeManager для синхронизации темы
    const panel = new ChatPanel(app, themeManager, notebookTracker);

    // Добавляем панель в правую панель в самый низ (rank=1000)
    app.shell.add(panel, 'right', { rank: 1000 });

    // Добавляем команду для переключения видимости панели
    app.commands.addCommand(COMMAND_ID, {
      label: 'Toggle AI Agent',
      execute: () => {
        if (!panel.isAttached) {
          app.shell.add(panel, 'right');
          app.shell.activateById(panel.id);
        } else {
          // Проверяем, активна ли панель
          if (app.shell.currentWidget === panel) {
            panel.close();
          } else {
            // Если панель не активна, активируем её
            app.shell.activateById(panel.id);
          }
        }
      }
    });

    // Добавляем команду в палитру
    palette.addItem({
      command: COMMAND_ID,
      category: 'AI Agent'
    });
  }
};

export default plugin;
