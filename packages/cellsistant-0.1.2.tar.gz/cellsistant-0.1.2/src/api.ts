import { URLExt } from '@jupyterlab/coreutils';
import { ServerConnection } from '@jupyterlab/services';

/** OpenAI/OpenRouter message format */
export interface ILLMMessage {
  role: 'user' | 'assistant' | 'tool';
  content: string | null;
  tool_calls?: ILLMToolCall[];
  tool_call_id?: string;
}

export interface ILLMToolCall {
  id: string;
  type: 'function';
  function: {
    name: string;
    arguments: string;
  };
}

export interface ILLMResponse {
  message: {
    role: 'assistant';
    content: string | null;
    tool_calls?: ILLMToolCall[];
  };
}

/** Extracts XSRF token from cookie */
function getXsrfToken(): string {
  const match = document.cookie.match(new RegExp('(^|; )_xsrf=([^;]+)'));
  return match ? match[2] : '';
}

/** Retry configuration */
export interface IRetryConfig {
  maxRetries: number;
  baseDelay: number;
  maxDelay: number;
}

const DEFAULT_RETRY_CONFIG: IRetryConfig = {
  maxRetries: 3,
  baseDelay: 1000,
  maxDelay: 30000
};

/** Shell command execution result */
export interface IShellResult {
  success: boolean;
  return_code: number;
  stdout: string;
  stderr: string;
  stdout_truncated: boolean;
  stderr_truncated: boolean;
  elapsed_seconds: number;
}

/** Get Jupyter server settings */
function getServerSettings(): ServerConnection.ISettings {
  return ServerConnection.makeSettings();
}

/** Build request headers with XSRF token */
function createRequestHeaders(): Record<string, string> {
  const settings = getServerSettings();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };

  if (settings.init?.headers) {
    const initHeaders = settings.init.headers as Record<string, string>;
    Object.assign(headers, initHeaders);
  }

  const xsrfToken = getXsrfToken();
  if (xsrfToken) {
    headers['X-XSRFToken'] = xsrfToken;
  }

  return headers;
}

/** Execute shell command via server endpoint */
export async function executeShell(
  command: string,
  timeout?: number,
  workingDir?: string
): Promise<IShellResult> {
  const settings = getServerSettings();
  const endpoint = URLExt.join(settings.baseUrl, 'ai-agent', 'shell');

  const body: Record<string, unknown> = { command };
  if (timeout) {
    body.timeout = timeout;
  }
  if (workingDir) {
    body.working_dir = workingDir;
  }

  const headers = createRequestHeaders();

  const response = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
    credentials: 'same-origin'
  });

  if (response.status === 403) {
    const text = await response.text();
    try {
      const data = JSON.parse(text);
      throw new Error(`Blocked: ${data.error || 'Access denied'}`);
    } catch {
      throw new Error(`Blocked: ${text.substring(0, 200)}`);
    }
  }

  if (response.status !== 200) {
    const text = await response.text();
    try {
      const data = JSON.parse(text);
      throw new Error(data.error || `Shell error: ${response.status}`);
    } catch {
      throw new Error(
        `Shell error ${response.status}: ${text.substring(0, 200)}`
      );
    }
  }

  return await response.json();
}

/** Image analysis result */
export interface IImageAnalysisResult {
  success: boolean;
  analysis?: string;
  model_used?: string;
  error?: string;
}

/** Analyze cell output image via Vision LLM */
export async function analyzeImage(
  imageData: string,
  mimeType: string = 'image/png',
  cellIndex?: number,
  context?: string
): Promise<IImageAnalysisResult> {
  const settings = getServerSettings();
  const endpoint = URLExt.join(settings.baseUrl, 'ai-agent', 'analyze-image');

  const headers = createRequestHeaders();

  const body: Record<string, unknown> = {
    image_data: imageData,
    mime_type: mimeType
  };

  if (cellIndex !== undefined) {
    body.cell_index = cellIndex;
  }

  if (context) {
    body.context = context;
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
    credentials: 'same-origin'
  });

  if (response.status !== 200) {
    const data = await response.json().catch(() => ({}));
    return {
      success: false,
      error: data.error || `Server error: ${response.status}`
    };
  }

  return await response.json();
}

/** Stream processing callbacks */
export interface IStreamCallbacks {
  /** Fires on each text token received */
  onToken: (token: string) => void;
  /** Fires when all tool_calls are assembled */
  onToolCalls: (toolCalls: ILLMToolCall[]) => void;
  /** Fires when stream completes */
  onDone: (fullMessage: ILLMResponse['message']) => void;
  /** Fires on error */
  onError: (error: string) => void;
}

/** Calculate exponential backoff delay */
function getRetryDelay(attempt: number, config: IRetryConfig): number {
  const delay = config.baseDelay * Math.pow(2, attempt);
  return Math.min(delay, config.maxDelay);
}

/** Send messages to LLM with automatic retry */
export async function sendToLLMWithRetry(
  messages: ILLMMessage[],
  abortSignal?: AbortSignal,
  config: IRetryConfig = DEFAULT_RETRY_CONFIG
): Promise<ILLMResponse> {
  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= config.maxRetries; attempt++) {
    try {
      const result = await sendToLLM(messages, abortSignal);
      return result;
    } catch (error) {
      lastError = error as Error;

      const isRetryable =
        (error as any).message?.includes('500') ||
        (error as any).message?.includes('502') ||
        (error as any).message?.includes('503') ||
        (error as any).message?.includes('504') ||
        (error as any).message?.includes('429') ||
        (error as any).retryable === true;

      if (!isRetryable || attempt >= config.maxRetries) {
        throw error;
      }

      const delay = getRetryDelay(attempt, config);
      console.log(
        `LLM request failed, retry ${attempt + 1}/${config.maxRetries} after ${delay}ms`
      );
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  throw lastError || new Error('Max retries exceeded');
}

/** Single API call: send messages, receive response */
export async function sendToLLM(
  messages: ILLMMessage[],
  abortSignal?: AbortSignal
): Promise<ILLMResponse> {
  const settings = getServerSettings();
  const endpoint = URLExt.join(settings.baseUrl, 'ai-agent', 'chat');

  const headers = createRequestHeaders();

  const response = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify({ messages }),
    signal: abortSignal,
    credentials: 'same-origin'
  });

  if (abortSignal?.aborted) {
    throw new Error('Request cancelled');
  }

  if (response.status !== 200) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error || `Server error: ${response.status}`);
  }

  return await response.json();
}

/** Stream LLM response via SSE */
export async function streamFromLLM(
  messages: ILLMMessage[],
  callbacks: IStreamCallbacks,
  abortSignal?: AbortSignal,
  askMode: boolean = false,
  imageAnalysisEnabled: boolean = true
): Promise<void> {
  const settings = getServerSettings();
  const endpoint = URLExt.join(settings.baseUrl, 'ai-agent', 'chat', 'stream');

  const headers = createRequestHeaders();

  const response = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      messages,
      ask_mode: askMode,
      image_analysis_enabled: imageAnalysisEnabled
    }),
    signal: abortSignal
  });

  if (!response.ok) {
    const errorText = await response.text();
    callbacks.onError(`Server error ${response.status}: ${errorText}`);
    return;
  }

  const reader = response.body?.getReader();
  if (!reader) {
    callbacks.onError('No response body');
    return;
  }

  const decoder = new TextDecoder();

  let fullContent = '';
  const toolCalls: Map<
    number,
    {
      id: string;
      type: 'function';
      function: { name: string; arguments: string };
    }
  > = new Map();
  let buffer = '';

  try {
    let done = false;
    while (!done) {
      const result = await reader.read();
      done = result.done;
      if (done) {
        break;
      }

      const value = result.value;

      buffer += decoder.decode(value, { stream: true });

      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        const trimmed = line.trim();

        if (trimmed === 'event: done' || trimmed === 'data: [DONE]') {
          const finalToolCalls =
            toolCalls.size > 0 ? Array.from(toolCalls.values()) : undefined;

          callbacks.onDone({
            role: 'assistant',
            content: fullContent || null,
            tool_calls: finalToolCalls
          });
          return;
        }

        if (trimmed.startsWith('event: error')) {
          continue;
        }

        if (!trimmed.startsWith('data: ')) {
          continue;
        }

        const jsonStr = trimmed.slice(6);

        try {
          const chunk = JSON.parse(jsonStr);

          if (chunk.error) {
            callbacks.onError(
              typeof chunk.error === 'string'
                ? chunk.error
                : chunk.error.message || JSON.stringify(chunk.error)
            );
            return;
          }

          const delta = chunk.choices?.[0]?.delta;
          if (!delta) {
            continue;
          }

          if (delta.content) {
            fullContent += delta.content;
            callbacks.onToken(delta.content);
          }

          if (delta.tool_calls) {
            for (const tc of delta.tool_calls) {
              const idx = tc.index ?? 0;

              if (!toolCalls.has(idx)) {
                toolCalls.set(idx, {
                  id: tc.id || '',
                  type: 'function',
                  function: {
                    name: tc.function?.name || '',
                    arguments: tc.function?.arguments || ''
                  }
                });
              } else {
                const existing = toolCalls.get(idx)!;
                if (tc.id) {
                  existing.id = tc.id;
                }
                if (tc.function?.name) {
                  existing.function.name += tc.function.name;
                }
                if (tc.function?.arguments) {
                  existing.function.arguments += tc.function.arguments;
                }
              }
            }
          }
        } catch {
          continue;
        }
      }
    }

    const finalToolCalls =
      toolCalls.size > 0 ? Array.from(toolCalls.values()) : undefined;

    callbacks.onDone({
      role: 'assistant',
      content: fullContent || null,
      tool_calls: finalToolCalls
    });
  } catch (error) {
    if ((error as Error).name === 'AbortError') {
      callbacks.onError('Request cancelled');
    } else {
      callbacks.onError((error as Error).message || 'Stream error');
    }
  } finally {
    reader.releaseLock();
  }
}
