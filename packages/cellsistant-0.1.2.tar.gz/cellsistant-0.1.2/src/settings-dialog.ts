import {
  getSettings,
  updateSettings,
  testConnection,
  IAgentSettings,
  IModelProfile
} from './settings-api';
import { addProfileIcon, editProfileIcon, deleteProfileIcon } from './icons';

function generateId(): string {
  return 'profile-' + Math.random().toString(36).substring(2, 11);
}

export async function showSettingsDialog(
  container: HTMLElement,
  onSettingsChanged?: () => void
): Promise<void> {
  const overlay = document.createElement('div');
  overlay.className = 'ai-agent-settings-overlay';

  const dialog = document.createElement('div');
  dialog.className = 'ai-agent-settings-dialog';

  dialog.innerHTML = `
<div class="ai-agent-settings-header">
<h3>AI Agent Settings</h3>
<button class="ai-agent-settings-close">⨯</button>
</div>
<div class="ai-agent-settings-body">
<div class="ai-agent-settings-loading">Loading settings...</div>
</div>
<div class="ai-agent-settings-footer">
<button class="ai-agent-settings-test">Test Connection</button>
<div class="ai-agent-settings-spacer"></div>
<button class="ai-agent-settings-cancel">Cancel</button>
<button class="ai-agent-settings-save">Save</button>
</div>
`;

  overlay.appendChild(dialog);
  container.appendChild(overlay);

  const close = () => overlay.remove();
  overlay.addEventListener('click', e => {
    if (e.target === overlay) {
      close();
    }
  });
  dialog
    .querySelector('.ai-agent-settings-close')
    ?.addEventListener('click', close);
  dialog
    .querySelector('.ai-agent-settings-cancel')
    ?.addEventListener('click', close);

  let currentSettings: IAgentSettings;

  try {
    currentSettings = await getSettings();
  } catch (e) {
    const body = dialog.querySelector('.ai-agent-settings-body')!;
    body.innerHTML = `<div class="ai-agent-settings-error">Load error: ${e}</div>`;
    return;
  }

  const body = dialog.querySelector('.ai-agent-settings-body')! as HTMLElement;
  renderSettingsForm(body, currentSettings, dialog, close, onSettingsChanged);
}

export async function renderSettingsPanelContent(
  panel: HTMLElement,
  onClose?: () => void,
  onSettingsChanged?: () => void
): Promise<void> {
  panel.innerHTML = '';

  const header = document.createElement('div');
  header.className = 'ai-agent-settings-header';
  header.innerHTML = `
<h3>AI Agent Settings</h3>
<button class="ai-agent-settings-close" title="Close">⨯</button>
`;
  header
    .querySelector('.ai-agent-settings-close')
    ?.addEventListener('click', () => {
      onClose?.();
    });
  panel.appendChild(header);

  const body = document.createElement('div');
  body.className = 'ai-agent-settings-body';
  panel.appendChild(body);

  const footer = document.createElement('div');
  footer.className = 'ai-agent-settings-footer';
  footer.innerHTML = `
<button class="ai-agent-settings-test">Test Connection</button>
<div class="ai-agent-settings-spacer"></div>
<button class="ai-agent-settings-save">Save</button>
`;
  panel.appendChild(footer);

  const currentSettings = await getSettings();

  renderSettingsForm(
    body,
    currentSettings,
    panel,
    onClose || (() => {}),
    onSettingsChanged
  );
}

function renderSettingsForm(
  body: HTMLElement,
  currentSettings: IAgentSettings,
  container: HTMLElement,
  close: () => void,
  onSettingsChanged?: () => void
): void {
  body.innerHTML = '';

  // Local state for profiles
  let profiles: IModelProfile[] = JSON.parse(
    JSON.stringify(currentSettings.profiles)
  );
  let activeProfileId = currentSettings.active_profile_id;
  const deletedProfileIds = new Set<string>();

  // Helper to get active profile
  const getActiveProfile = (): IModelProfile => {
    const profile = profiles.find(p => p.id === activeProfileId);
    return (
      profile ||
      profiles[0] || {
        id: 'default',
        name: 'Default',
        base_url: '',
        model: '',
        temperature: 0.3,
        max_tokens: 0
      }
    );
  };

  // ─── Profile Selector Section ───
  const profileSection = createSection('Profile');
  const profileRow = document.createElement('div');
  profileRow.className = 'ai-agent-settings-profile-row';

  const profileSelect = document.createElement('select');
  profileSelect.className = 'ai-agent-settings-select';
  profileSelect.id = 'settings-profile-select';

  profiles.forEach(p => {
    const option = document.createElement('option');
    option.value = p.id;
    option.textContent = p.name;
    option.selected = p.id === activeProfileId;
    profileSelect.appendChild(option);
  });

  // Add profile button
  const addBtn = document.createElement('button');
  addBtn.className = 'ai-agent-settings-profile-btn';
  addBtn.title = 'Add new profile';
  const addIcon = addProfileIcon.element();
  addIcon.style.width = '16px';
  addIcon.style.height = '16px';
  addBtn.appendChild(addIcon);
  addBtn.addEventListener('click', () => {
    const name = prompt('Enter profile name:', 'New Profile');
    if (name) {
      const newProfile: IModelProfile = {
        id: generateId(),
        name,
        base_url: '',
        model: '',
        temperature: 0.3,
        max_tokens: 0
      };
      profiles.push(newProfile);
      activeProfileId = newProfile.id;

      const option = document.createElement('option');
      option.value = newProfile.id;
      option.textContent = newProfile.name;
      option.selected = true;
      profileSelect.appendChild(option);

      updateFormForProfile(newProfile);
    }
  });

  // Edit profile name button
  const editBtn = document.createElement('button');
  editBtn.className = 'ai-agent-settings-profile-btn';
  editBtn.title = 'Edit profile name';
  const editIcon = editProfileIcon.element();
  editIcon.style.width = '16px';
  editIcon.style.height = '16px';
  editBtn.appendChild(editIcon);
  editBtn.addEventListener('click', () => {
    const profile = getActiveProfile();
    const newName = prompt('Enter new profile name:', profile.name);
    if (newName && newName !== profile.name) {
      profile.name = newName;
      const option = profileSelect.querySelector(
        `option[value="${profile.id}"]`
      ) as HTMLOptionElement;
      if (option) {
        option.textContent = newName;
      }
    }
  });

  // Delete profile button
  const deleteBtn = document.createElement('button');
  deleteBtn.className = 'ai-agent-settings-profile-btn';
  deleteBtn.title = 'Delete profile';
  const deleteIcon = deleteProfileIcon.element();
  deleteIcon.style.width = '16px';
  deleteIcon.style.height = '16px';
  deleteBtn.appendChild(deleteIcon);
  deleteBtn.disabled = profiles.length <= 1;
  deleteBtn.addEventListener('click', () => {
    if (profiles.length <= 1) {
      return;
    }
    const profile = getActiveProfile();
    if (confirm(`Delete profile "${profile.name}"?`)) {
      deletedProfileIds.add(profile.id);
      profiles = profiles.filter(p => p.id !== profile.id);
      const option = profileSelect.querySelector(
        `option[value="${profile.id}"]`
      );
      if (option) {
        option.remove();
      }
      activeProfileId = profiles[0].id;
      profileSelect.value = activeProfileId;
      updateFormForProfile(profiles[0]);
      deleteBtn.disabled = profiles.length <= 1;
    }
  });

  profileRow.appendChild(profileSelect);
  profileRow.appendChild(addBtn);
  profileRow.appendChild(editBtn);
  profileRow.appendChild(deleteBtn);
  profileSection.appendChild(profileRow);
  body.appendChild(profileSection);

  // ─── API Base URL ───
  const baseUrlSection = createSection('API Base URL');
  const baseUrlInput = document.createElement('input');
  baseUrlInput.type = 'text';
  baseUrlInput.className = 'ai-agent-settings-input';
  baseUrlInput.id = 'settings-base-url';
  baseUrlInput.placeholder = 'https://openrouter.ai/api/v1';
  baseUrlSection.appendChild(baseUrlInput);
  body.appendChild(baseUrlSection);

  // ─── API Key ───
  const apiKeySection = createSection('API Key');
  const apiKeyInput = document.createElement('input');
  apiKeyInput.type = 'password';
  apiKeyInput.className = 'ai-agent-settings-input';
  apiKeyInput.id = 'settings-api-key';
  apiKeyInput.placeholder = 'Enter API key...';

  const showKeyBtn = document.createElement('button');
  showKeyBtn.className = 'ai-agent-settings-toggle-key';
  showKeyBtn.textContent = 'Show';
  showKeyBtn.title = 'Show/hide key';
  showKeyBtn.addEventListener('click', () => {
    apiKeyInput.type = apiKeyInput.type === 'password' ? 'text' : 'password';
  });

  const keyRow = document.createElement('div');
  keyRow.className = 'ai-agent-settings-row';
  keyRow.appendChild(apiKeyInput);
  keyRow.appendChild(showKeyBtn);
  apiKeySection.appendChild(keyRow);
  body.appendChild(apiKeySection);

  // ─── Model ───
  const modelSection = createSection('Model');
  const modelInput = document.createElement('input');
  modelInput.type = 'text';
  modelInput.className = 'ai-agent-settings-input';
  modelInput.id = 'settings-model';
  modelInput.placeholder = 'e.g., google/gemini-2.0-flash:free';
  modelSection.appendChild(modelInput);
  body.appendChild(modelSection);

  // ─── Temperature ───
  const tempSection = createSection('Temperature');
  const tempSlider = document.createElement('input');
  tempSlider.type = 'range';
  tempSlider.className = 'ai-agent-settings-slider';
  tempSlider.id = 'settings-temperature';
  tempSlider.min = '0';
  tempSlider.max = '2';
  tempSlider.step = '0.1';

  const tempValue = document.createElement('span');
  tempValue.className = 'ai-agent-settings-slider-value';

  tempSlider.addEventListener('input', () => {
    tempValue.textContent = tempSlider.value;
  });

  const tempRow = document.createElement('div');
  tempRow.className = 'ai-agent-settings-row';
  tempRow.appendChild(tempSlider);
  tempRow.appendChild(tempValue);
  tempSection.appendChild(tempRow);
  body.appendChild(tempSection);

  // ─── Max Tokens ───
  const maxTokensSection = createSection('Max Response Tokens');
  const maxTokensInput = document.createElement('input');
  maxTokensInput.type = 'number';
  maxTokensInput.className = 'ai-agent-settings-input';
  maxTokensInput.id = 'settings-max-tokens';
  maxTokensInput.min = '0';
  maxTokensInput.max = '32768';
  maxTokensInput.placeholder = '0 = model default';
  maxTokensSection.appendChild(maxTokensInput);
  body.appendChild(maxTokensSection);

  // Function to update form for selected profile
  const updateFormForProfile = (profile: IModelProfile) => {
    baseUrlInput.value = profile.base_url || '';
    apiKeyInput.value = '';
    apiKeyInput.placeholder = profile.api_key
      ? 'Leave empty to keep current key'
      : 'Enter API key...';
    modelInput.value = profile.model || '';
    tempSlider.value = String(profile.temperature ?? 0.3);
    tempValue.textContent = tempSlider.value;
    maxTokensInput.value = String(profile.max_tokens ?? 0);
  };

  // Initial form population
  updateFormForProfile(getActiveProfile());

  // Handle profile selection change
  profileSelect.addEventListener('change', () => {
    activeProfileId = profileSelect.value;
    const profile = getActiveProfile();
    updateFormForProfile(profile);
  });

  // Update profile data when inputs change
  const updateCurrentProfileFromForm = () => {
    const profile = profiles.find(p => p.id === activeProfileId);
    if (profile) {
      profile.base_url = baseUrlInput.value;
      profile.model = modelInput.value;
      profile.temperature = parseFloat(tempSlider.value);
      profile.max_tokens = parseInt(maxTokensInput.value, 10);
      if (apiKeyInput.value) {
        profile.api_key = apiKeyInput.value;
      }
    }
  };

  baseUrlInput.addEventListener('change', updateCurrentProfileFromForm);
  modelInput.addEventListener('change', updateCurrentProfileFromForm);
  tempSlider.addEventListener('change', updateCurrentProfileFromForm);
  maxTokensInput.addEventListener('change', updateCurrentProfileFromForm);

  // ─── Auto Execute Tools ───
  const autoExecSection = createSection('Auto-execute Tools');
  const autoExecCheckbox = document.createElement('input');
  autoExecCheckbox.type = 'checkbox';
  autoExecCheckbox.className = 'ai-agent-settings-checkbox';
  autoExecCheckbox.id = 'settings-auto-execute';
  autoExecCheckbox.checked = currentSettings.auto_execute_tools ?? true;
  const autoExecLabel = document.createElement('label');
  autoExecLabel.className = 'ai-agent-settings-checkbox-label';
  autoExecLabel.htmlFor = 'settings-auto-execute';
  autoExecLabel.textContent =
    'Automatically execute tool calls without confirmation';
  const autoExecRow = document.createElement('div');
  autoExecRow.className = 'ai-agent-settings-row';
  autoExecRow.appendChild(autoExecCheckbox);
  autoExecRow.appendChild(autoExecLabel);
  autoExecSection.appendChild(autoExecRow);
  body.appendChild(autoExecSection);

  // ─── Include Variables ───
  const includeVarsSection = createSection('Include Variables in Context');
  const includeVarsCheckbox = document.createElement('input');
  includeVarsCheckbox.type = 'checkbox';
  includeVarsCheckbox.className = 'ai-agent-settings-checkbox';
  includeVarsCheckbox.id = 'settings-include-variables';
  includeVarsCheckbox.checked = currentSettings.include_variables ?? true;
  const includeVarsLabel = document.createElement('label');
  includeVarsLabel.className = 'ai-agent-settings-checkbox-label';
  includeVarsLabel.htmlFor = 'settings-include-variables';
  includeVarsLabel.textContent =
    'Automatically inspect kernel variables and include in context';
  const includeVarsRow = document.createElement('div');
  includeVarsRow.className = 'ai-agent-settings-row';
  includeVarsRow.appendChild(includeVarsCheckbox);
  includeVarsRow.appendChild(includeVarsLabel);
  includeVarsSection.appendChild(includeVarsRow);
  body.appendChild(includeVarsSection);

  // ─── Include Cell Outline ───
  const includeCellsSection = createSection('Include Cell Outline in Context');
  const includeCellsCheckbox = document.createElement('input');
  includeCellsCheckbox.type = 'checkbox';
  includeCellsCheckbox.className = 'ai-agent-settings-checkbox';
  includeCellsCheckbox.id = 'settings-include-cells';
  includeCellsCheckbox.checked = currentSettings.include_cell_outline ?? true;
  const includeCellsLabel = document.createElement('label');
  includeCellsLabel.className = 'ai-agent-settings-checkbox-label';
  includeCellsLabel.htmlFor = 'settings-include-cells';
  includeCellsLabel.textContent =
    'Include notebook cell outline in automatic context';
  const includeCellsRow = document.createElement('div');
  includeCellsRow.className = 'ai-agent-settings-row';
  includeCellsRow.appendChild(includeCellsCheckbox);
  includeCellsRow.appendChild(includeCellsLabel);
  includeCellsSection.appendChild(includeCellsRow);
  body.appendChild(includeCellsSection);

  // ─── Max Agent Iterations ───
  const maxIterSection = createSection('Max Agent Iterations');
  const maxIterInput = document.createElement('input');
  maxIterInput.type = 'number';
  maxIterInput.className = 'ai-agent-settings-input';
  maxIterInput.id = 'settings-max-iterations';
  maxIterInput.value = String(currentSettings.max_agent_iterations ?? 15);
  maxIterInput.min = '1';
  maxIterInput.max = '50';
  maxIterSection.appendChild(maxIterInput);
  body.appendChild(maxIterSection);

  // ─── Enabled Tool Categories ───
  const toolsSection = createSection('Enabled Tool Categories');
  const toolCategories = [
    { key: 'notebook', label: 'Notebook Tools' },
    { key: 'files', label: 'File Operations' },
    { key: 'shell', label: 'Shell Commands' },
    { key: 'packages', label: 'Package Management' },
    { key: 'search', label: 'Search & Replace' }
  ];
  for (const cat of toolCategories) {
    const catRow = document.createElement('div');
    catRow.className = 'ai-agent-settings-row';
    const catCheckbox = document.createElement('input');
    catCheckbox.type = 'checkbox';
    catCheckbox.className = 'ai-agent-settings-checkbox';
    catCheckbox.id = `settings-tool-${cat.key}`;
    catCheckbox.checked =
      currentSettings.enabled_tool_categories[
        cat.key as keyof typeof currentSettings.enabled_tool_categories
      ] ?? true;
    const catLabel = document.createElement('label');
    catLabel.className = 'ai-agent-settings-checkbox-label';
    catLabel.htmlFor = `settings-tool-${cat.key}`;
    catLabel.textContent = cat.label;
    catRow.appendChild(catCheckbox);
    catRow.appendChild(catLabel);
    toolsSection.appendChild(catRow);
  }
  body.appendChild(toolsSection);

  // ─── Custom System Prompt ───
  const promptSection = createSection('Custom System Prompt Addition');
  const promptTextarea = document.createElement('textarea');
  promptTextarea.className = 'ai-agent-settings-textarea';
  promptTextarea.id = 'settings-custom-prompt';
  promptTextarea.value = currentSettings.custom_system_prompt || '';
  promptTextarea.placeholder = 'Additional instructions...';
  promptTextarea.rows = 4;
  promptSection.appendChild(promptTextarea);
  body.appendChild(promptSection);

  // ─── Image Analysis Settings ───
  const imgSection = createSection('Image Analysis');
  const imgEnabledRow = document.createElement('div');
  imgEnabledRow.className = 'ai-agent-settings-row';
  const imgEnabledCheckbox = document.createElement('input');
  imgEnabledCheckbox.type = 'checkbox';
  imgEnabledCheckbox.className = 'ai-agent-settings-checkbox';
  imgEnabledCheckbox.id = 'settings-img-enabled';
  imgEnabledCheckbox.checked = currentSettings.image_analysis?.enabled ?? true;
  const imgEnabledLabel = document.createElement('label');
  imgEnabledLabel.className = 'ai-agent-settings-checkbox-label';
  imgEnabledLabel.htmlFor = 'settings-img-enabled';
  imgEnabledLabel.textContent = 'Enable image analysis';
  imgEnabledRow.appendChild(imgEnabledCheckbox);
  imgEnabledRow.appendChild(imgEnabledLabel);
  imgSection.appendChild(imgEnabledRow);

  // Container for image analysis options (shown only when enabled)
  const imgOptionsContainer = document.createElement('div');
  imgOptionsContainer.className = 'ai-agent-settings-img-options';
  imgOptionsContainer.style.display = imgEnabledCheckbox.checked
    ? 'flex'
    : 'none';
  imgOptionsContainer.style.flexDirection = 'column';
  imgOptionsContainer.style.gap = '12px';

  const imgAutoRow = document.createElement('div');
  imgAutoRow.className = 'ai-agent-settings-row';
  const imgAutoCheckbox = document.createElement('input');
  imgAutoCheckbox.type = 'checkbox';
  imgAutoCheckbox.className = 'ai-agent-settings-checkbox';
  imgAutoCheckbox.id = 'settings-img-auto-suggest';
  imgAutoCheckbox.checked =
    currentSettings.image_analysis?.auto_suggest ?? true;
  const imgAutoLabel = document.createElement('label');
  imgAutoLabel.className = 'ai-agent-settings-checkbox-label';
  imgAutoLabel.htmlFor = 'settings-img-auto-suggest';
  imgAutoLabel.textContent = 'Auto-suggest analysis when image detected';
  imgAutoRow.appendChild(imgAutoCheckbox);
  imgAutoRow.appendChild(imgAutoLabel);
  imgOptionsContainer.appendChild(imgAutoRow);

  const imgUseActiveRow = document.createElement('div');
  imgUseActiveRow.className = 'ai-agent-settings-row';
  const imgUseActiveCheckbox = document.createElement('input');
  imgUseActiveCheckbox.type = 'checkbox';
  imgUseActiveCheckbox.className = 'ai-agent-settings-checkbox';
  imgUseActiveCheckbox.id = 'settings-img-use-active';
  imgUseActiveCheckbox.checked =
    currentSettings.image_analysis?.use_active_profile !== false;
  const imgUseActiveLabel = document.createElement('label');
  imgUseActiveLabel.className = 'ai-agent-settings-checkbox-label';
  imgUseActiveLabel.htmlFor = 'settings-img-use-active';
  imgUseActiveLabel.textContent = 'Use active profile for vision';
  imgUseActiveRow.appendChild(imgUseActiveCheckbox);
  imgUseActiveRow.appendChild(imgUseActiveLabel);
  imgOptionsContainer.appendChild(imgUseActiveRow);

  // Vision profile selector (shown when use_active_profile is false)
  const imgProfileRow = document.createElement('div');
  imgProfileRow.className = 'ai-agent-settings-row';
  imgProfileRow.id = 'settings-img-profile-row';
  imgProfileRow.style.display = imgUseActiveCheckbox.checked ? 'none' : 'flex';

  const imgProfileSelect = document.createElement('select');
  imgProfileSelect.className = 'ai-agent-settings-select';
  imgProfileSelect.id = 'settings-img-profile';
  profiles.forEach(p => {
    const option = document.createElement('option');
    option.value = p.id;
    option.textContent = p.name;
    option.selected = p.id === currentSettings.image_analysis?.profile_id;
    imgProfileSelect.appendChild(option);
  });
  imgProfileRow.appendChild(imgProfileSelect);
  imgOptionsContainer.appendChild(imgProfileRow);

  imgUseActiveCheckbox.addEventListener('change', () => {
    imgProfileRow.style.display = imgUseActiveCheckbox.checked
      ? 'none'
      : 'flex';
  });

  const imgPromptTextarea = document.createElement('textarea');
  imgPromptTextarea.className = 'ai-agent-settings-textarea';
  imgPromptTextarea.id = 'settings-img-custom-prompt';
  imgPromptTextarea.value = currentSettings.image_analysis?.custom_prompt || '';
  imgPromptTextarea.placeholder =
    'Optional: custom instructions for image analysis...';
  imgPromptTextarea.rows = 2;
  imgOptionsContainer.appendChild(imgPromptTextarea);

  imgSection.appendChild(imgOptionsContainer);
  body.appendChild(imgSection);

  // Toggle image analysis options visibility
  imgEnabledCheckbox.addEventListener('change', () => {
    imgOptionsContainer.style.display = imgEnabledCheckbox.checked
      ? 'flex'
      : 'none';
  });

  // ─── Test Status ───
  const testStatus = document.createElement('div');
  testStatus.className = 'ai-agent-settings-test-status';
  body.appendChild(testStatus);

  // ─── Test Connection Button ───
  container
    .querySelector('.ai-agent-settings-test')
    ?.addEventListener('click', async () => {
      testStatus.innerHTML = 'Testing...';
      testStatus.className = 'ai-agent-settings-test-status testing';

      try {
        const profile = getActiveProfile();
        const result = await testConnection({
          base_url: baseUrlInput.value || undefined,
          model: modelInput.value || undefined,
          api_key: apiKeyInput.value || undefined,
          profile_id: profile.id
        });

        if (result.success) {
          testStatus.innerHTML = `✓ ${result.response} (${result.latency_ms}ms)`;
          testStatus.className = 'ai-agent-settings-test-status success';
        } else {
          testStatus.innerHTML = `✗ ${result.error}`;
          testStatus.className = 'ai-agent-settings-test-status error';
        }
      } catch (e) {
        testStatus.innerHTML = `✗ ${e}`;
        testStatus.className = 'ai-agent-settings-test-status error';
      }
    });

  // ─── Save Button ───
  container
    .querySelector('.ai-agent-settings-save')
    ?.addEventListener('click', async () => {
      // Update current profile from form
      updateCurrentProfileFromForm();

      const updates: Record<string, unknown> = {
        profiles: profiles,
        active_profile_id: activeProfileId,
        auto_execute_tools: autoExecCheckbox.checked,
        include_variables: includeVarsCheckbox.checked,
        include_cell_outline: includeCellsCheckbox.checked,
        max_agent_iterations: parseInt(maxIterInput.value, 10),
        custom_system_prompt: promptTextarea.value,
        enabled_tool_categories: {
          notebook: (
            document.getElementById(
              'settings-tool-notebook'
            ) as HTMLInputElement
          ).checked,
          files: (
            document.getElementById('settings-tool-files') as HTMLInputElement
          ).checked,
          shell: (
            document.getElementById('settings-tool-shell') as HTMLInputElement
          ).checked,
          packages: (
            document.getElementById(
              'settings-tool-packages'
            ) as HTMLInputElement
          ).checked,
          search: (
            document.getElementById('settings-tool-search') as HTMLInputElement
          ).checked
        },
        image_analysis: {
          enabled: (
            document.getElementById('settings-img-enabled') as HTMLInputElement
          ).checked,
          auto_suggest: (
            document.getElementById(
              'settings-img-auto-suggest'
            ) as HTMLInputElement
          ).checked,
          use_active_profile: (
            document.getElementById(
              'settings-img-use-active'
            ) as HTMLInputElement
          ).checked,
          profile_id: imgUseActiveCheckbox.checked
            ? null
            : imgProfileSelect.value,
          custom_prompt: (
            document.getElementById(
              'settings-img-custom-prompt'
            ) as HTMLTextAreaElement
          ).value
        }
      };

      try {
        await updateSettings(updates);
        if (onSettingsChanged) {
          onSettingsChanged();
        } else {
          close();
        }
      } catch (e) {
        testStatus.innerHTML = `Save error: ${e}`;
        testStatus.className = 'ai-agent-settings-test-status error';
      }
    });
}

function createSection(title: string): HTMLElement {
  const section = document.createElement('div');
  section.className = 'ai-agent-settings-section';

  const label = document.createElement('label');
  label.className = 'ai-agent-settings-label';
  label.textContent = title;
  section.appendChild(label);

  return section;
}
