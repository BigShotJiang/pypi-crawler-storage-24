# Cellsistant

AI Agent sidebar panel for JupyterLab.

## Requirements

- Python: 3.9+
- JupyterLab: 4.x

## Installation

```bash
pip install cellsistant
jupyter lab
```

## Development

### Build Commands

**Frontend (TypeScript):**

```bash
npm run build           # Development build
npm run build:prod       # Production build
npm run watch            # Watch mode
```

**Backend (Python):**

```bash
pip install -e .         # Install in editable mode
python -m build          # Create distribution
```

### Testing

**Python tests:**

```bash
pytest
pytest cellsistant/tests/
```

**TypeScript tests:**

```bash
npm test
```

### Linting

**Python:**

```bash
npm run lint:python       # Check and fix
npm run format:python     # Format
```

**TypeScript:**

```bash
npm run lint              # Check and fix
npm run lint:check        # Check only
```

**All:**

```bash
npm run lint:all          # Check and fix all
npm run lint:all:check    # Check all
```

## Project Structure

```
cellsistant/
├── __init__.py          # Server extension, API handlers
├── chat_utils.py        # Chat utilities
├── history.py           # Chat history
├── prompts.py           # System prompts
├── rate_limiter.py      # API rate limiting
├── retry.py             # API retry logic
├── settings.py          # Settings management
├── tools_definitions.py # Tool definitions
└── tests/               # Python tests

src/
├── index.ts             # Extension entry point
├── chat-panel.ts        # Chat panel widget
├── chat-ui.ts           # Chat UI components
├── api.ts               # API client
├── tools.ts             # Tool interfaces
├── tool-registry.ts     # Tool registry
├── permission-manager.ts # Tool permissions
└── tools/
    ├── notebook-tools.ts
    ├── file-tools.ts
    ├── search-tools.ts
    ├── shell-tools.ts
    └── package-tools.ts
```

## License

BSD-3-Clause. See [LICENSE](LICENSE).
