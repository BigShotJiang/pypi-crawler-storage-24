"""
snapparquet — small helpers for fast Parquet workflows: column pruning, optional
integer-column range filters with PyArrow dataset predicate pushdown when
statistics allow, and footer-only schema reads for discovery.

Typical entry points: :func:`read_tabular`, :func:`read_tabular_many`,
:func:`schema_column_names`.
"""

from snapparquet._version import __version__
from snapparquet.readers import (
    read_csv,
    read_parquet,
    read_parquet_many,
    read_tabular,
    read_tabular_many,
)
from snapparquet.schema import (
    column_is_integer_type,
    intersect_columns,
    norm_col,
    schema_column_names,
    schema_has_all,
    schema_matches_any_group,
)

__all__ = [
    "__version__",
    "column_is_integer_type",
    "intersect_columns",
    "norm_col",
    "read_csv",
    "read_parquet",
    "read_parquet_many",
    "read_tabular",
    "read_tabular_many",
    "schema_column_names",
    "schema_has_all",
    "schema_matches_any_group",
]
