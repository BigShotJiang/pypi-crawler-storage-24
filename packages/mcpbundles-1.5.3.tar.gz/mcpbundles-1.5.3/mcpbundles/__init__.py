"""MCPBundles CLI — connect AI to 500+ tools from the command line."""

__version__ = "1.2.1"

