"""Plugin registry for custom scenarios and analyzers."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol
import importlib.util
import json
import logging

logger = logging.getLogger(__name__)


class ScenarioPlugin(Protocol):
    """Interface for custom scenario plugins."""
    name: str
    description: str
    def generate_scenarios(self, graph, component_ids, components) -> list: ...


class AnalyzerPlugin(Protocol):
    """Interface for custom analyzer plugins."""
    name: str
    def analyze(self, graph, report) -> dict: ...


class PluginRegistry:
    """Central registry for scenario and analyzer plugins.

    Plugins can be registered programmatically or loaded from a directory
    of Python files.  Each file may expose a ``register(registry)`` function
    that will be called automatically during loading.
    """

    _scenario_plugins: list[ScenarioPlugin] = []
    _analyzer_plugins: list[AnalyzerPlugin] = []

    @classmethod
    def register_scenario(cls, plugin: ScenarioPlugin):
        cls._scenario_plugins.append(plugin)

    @classmethod
    def register_analyzer(cls, plugin: AnalyzerPlugin):
        cls._analyzer_plugins.append(plugin)

    @classmethod
    def load_plugins_from_dir(cls, plugin_dir: Path):
        """Load all .py files from a directory as plugins."""
        if not plugin_dir.exists():
            return
        for py_file in sorted(plugin_dir.glob("*.py")):
            if py_file.name.startswith("_"):
                continue
            try:
                spec = importlib.util.spec_from_file_location(py_file.stem, py_file)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    # Auto-register if module has register() function
                    if hasattr(module, "register"):
                        module.register(cls)
                    logger.debug("Loaded plugin: %s", py_file.name)
            except Exception:
                logger.warning("Failed to load plugin %s", py_file, exc_info=True)

    @classmethod
    def get_scenario_plugins(cls) -> list[ScenarioPlugin]:
        return list(cls._scenario_plugins)

    @classmethod
    def get_analyzer_plugins(cls) -> list[AnalyzerPlugin]:
        return list(cls._analyzer_plugins)

    @classmethod
    def clear(cls):
        cls._scenario_plugins.clear()
        cls._analyzer_plugins.clear()
