"""
MUMLA - Main Entry Point
"""

from mumla.cli.main import app

if __name__ == "__main__":
    app()
