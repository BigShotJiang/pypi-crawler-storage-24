"""
Moorcheh Client Singleton
"""

from moorcheh_sdk import MoorchehClient

from mumla.app.config import settings


class MoorchehClientSingleton:
    """Singleton pattern for Moorcheh client"""

    _instance = None
    _client = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def get_client(self) -> MoorchehClient:
        """Get or create Moorcheh client"""
        if self._client is None:
            self._client = MoorchehClient(api_key=settings.MOORCHEH_API_KEY)
        return self._client

    def reset_client(self):
        """Reset client (useful for testing)"""
        self._client = None


# Global client instance
moorcheh_client = MoorchehClientSingleton()


def get_moorcheh_client() -> MoorchehClient:
    """Dependency injection function"""
    return moorcheh_client.get_client()
