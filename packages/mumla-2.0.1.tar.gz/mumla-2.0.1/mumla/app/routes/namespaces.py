"""
Namespace Management Routes
"""

from fastapi import APIRouter, Depends, HTTPException
from moorcheh_sdk import MoorchehClient

from mumla.app.clients.moorcheh import get_moorcheh_client
from mumla.app.models import (
    NamespaceCreateRequest,
    NamespaceListResponse,
    NamespaceResponse,
)
from mumla.app.services.namespace_service import NamespaceService
from mumla.app.utils.errors import map_error_to_http_exception

router = APIRouter()


@router.post("/", response_model=NamespaceResponse)
async def create_namespace(
    request: NamespaceCreateRequest,
    client: MoorchehClient = Depends(get_moorcheh_client),
):
    """Create a new namespace"""
    try:
        service = NamespaceService(client)
        namespace = service.create_namespace(request.scope_type, request.scope_id)

        return NamespaceResponse(
            namespace=namespace,
            scope_type=request.scope_type,
            scope_id=request.scope_id,
            created=True,
        )

    except Exception as e:
        raise map_error_to_http_exception(e)


@router.get("/", response_model=NamespaceListResponse)
async def list_namespaces(client: MoorchehClient = Depends(get_moorcheh_client)):
    """List all MUMLA namespaces"""
    try:
        service = NamespaceService(client)
        namespaces = service.list_namespaces()

        return NamespaceListResponse(namespaces=namespaces, total=len(namespaces))

    except Exception as e:
        raise map_error_to_http_exception(e)


@router.delete("/{scope_type}/{scope_id}")
async def delete_namespace(
    scope_type: str,
    scope_id: str,
    client: MoorchehClient = Depends(get_moorcheh_client),
):
    """Delete a namespace"""
    try:
        service = NamespaceService(client)
        success = service.delete_namespace(scope_type, scope_id)

        if success:
            return {"message": "Namespace deleted successfully"}
        else:
            raise HTTPException(status_code=404, detail="Namespace not found")

    except Exception as e:
        raise map_error_to_http_exception(e)


@router.get("/{scope_type}/{scope_id}/exists")
async def check_namespace_exists(
    scope_type: str,
    scope_id: str,
    client: MoorchehClient = Depends(get_moorcheh_client),
):
    """Check if namespace exists"""
    try:
        service = NamespaceService(client)
        exists = service.namespace_exists(scope_type, scope_id)

        return {"exists": exists}

    except Exception as e:
        raise map_error_to_http_exception(e)
