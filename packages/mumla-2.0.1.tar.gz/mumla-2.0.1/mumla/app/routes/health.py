"""
Health Check Routes
"""

from fastapi import APIRouter, Depends
from moorcheh_sdk import MoorchehClient

from mumla.app import __version__
from mumla.app.clients.moorcheh import get_moorcheh_client
from mumla.app.models import HealthResponse

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
async def health_check(client: MoorchehClient = Depends(get_moorcheh_client)):
    """Health check endpoint"""

    # Test Moorcheh connection
    moorcheh_connected = False
    try:
        # Try to list namespaces as a connection test
        client.namespaces.list()
        moorcheh_connected = True
    except Exception:
        moorcheh_connected = False

    return HealthResponse(
        status="healthy" if moorcheh_connected else "degraded",
        service="MUMLA",
        version=__version__,
        moorcheh_connected=moorcheh_connected,
    )


@router.get("/ready")
async def readiness_check():
    """Readiness check for Kubernetes"""
    return {"status": "ready"}


@router.get("/live")
async def liveness_check():
    """Liveness check for Kubernetes"""
    return {"status": "alive"}
