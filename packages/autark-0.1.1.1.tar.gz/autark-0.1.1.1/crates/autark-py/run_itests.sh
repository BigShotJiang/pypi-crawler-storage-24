uv run python -m unittest discover -s itests -p "test_*.py" -v
