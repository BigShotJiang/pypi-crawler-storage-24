from __future__ import annotations

import sys

from autark import *


DEFAULT_DATASET = "https://d37ci6vzurychx.cloudfront.net/trip-data/yellow_tripdata_2025-01.parquet"


def main() -> None:
    dataset = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_DATASET

    frame = OnceFrame(ParquetReader(dataset))
    p = P()
    df = p.columns(None)

    df.columns("VendorID").reduce("count").alias("row_count")
    df.columns("tip_amount").reduce("mean").alias("tip_amount_mean")

    df.slice(0, 10).alias("head")
    df.order_by(df.columns("tip_amount")).slice(0, 10).alias("head_sorted")

    print(frame.realize(p))


if __name__ == "__main__":
    main()
