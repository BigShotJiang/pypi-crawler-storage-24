from autark import *


def main() -> None:
    left_rows = [
        {"ts": 1, "value": 10.0},
        {"ts": 3, "value": 20.0},
        {"ts": 6, "value": 30.0},
    ]
    right_rows = [
        {"ts": 2, "value": 100.0},
        {"ts": 5, "value": 500.0},
    ]

    frame = OnceFrame([JsonReader(left_rows), JsonReader(right_rows)])
    p = P()
    left = p.columns(None, index=0)
    right = p.columns(None, index=1)

    backward = left.join(
        right,
        left_on=left.columns("ts"),
        right_on=right.columns("ts"),
        kind="asof_backward",
    )
    forward = left.join(
        right,
        left_on=left.columns("ts"),
        right_on=right.columns("ts"),
        kind="asof_forward",
    )
    backward.alias("asof_backward_join")
    forward.alias("asof_forward_join")

    realized = frame.realize(p)
    print(realized["asof_backward_join"])
    print(realized["asof_forward_join"])


if __name__ == "__main__":
    main()
