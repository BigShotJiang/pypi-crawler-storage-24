from autark import *
from pathlib import Path

DATASET = Path(__file__).resolve().parents[3] / "propdata" / "evwa1.csv"

def main():
    frame = OnceFrame(CsvReader(str(DATASET)))

    print(frame)

    p = P()
    p.columns(None).slice(0, 10).alias("head", frame.schema())
    print(frame.realize(p))

if __name__ == "__main__":
    main()
