use arrow::array::RecordBatch;
use pyo3::prelude::*;
use pyo3::types::PyDict;

mod arrays;
mod binary;
mod timestamps;

pub(crate) fn record_batch_to_py_dict<'py>(
    py: Python<'py>,
    batch: &RecordBatch,
) -> PyResult<Bound<'py, PyDict>> {
    let out = PyDict::new(py);
    for i in 0..batch.num_columns() {
        let name = batch.schema().field(i).name().clone();
        let values = arrays::array_to_py_list(py, batch.column(i).as_ref())?;
        out.set_item(name, values)?;
    }
    Ok(out)
}
