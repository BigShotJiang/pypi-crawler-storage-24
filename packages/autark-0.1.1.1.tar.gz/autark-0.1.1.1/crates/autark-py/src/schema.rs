use autark::prelude::Schema;
use pyo3::prelude::*;

#[pyclass(name = "Schema", unsendable)]
#[derive(Clone)]
pub(crate) struct PySchema {
    pub(crate) inner: Schema,
}

impl PySchema {
    pub(crate) fn new(inner: Schema) -> PySchema {
        PySchema { inner }
    }
}

#[pymethods]
impl PySchema {
    fn fields(&self) -> Vec<String> {
        self.inner
            .clone()
            .into_arrow()
            .fields()
            .iter()
            .map(|x| x.name().to_string())
            .collect()
    }

    fn concat(&self, other: PyRef<'_, PySchema>) -> PySchema {
        PySchema::new(self.inner.clone().concat(other.inner.clone()))
    }

    fn column_f64(&self, name: &str) -> PySchema {
        PySchema::new(self.inner.clone().column_f64(name))
    }

    fn column_i64(&self, name: &str) -> PySchema {
        PySchema::new(self.inner.clone().column_i64(name))
    }

    fn column_u64(&self, name: &str) -> PySchema {
        PySchema::new(self.inner.clone().column_u64(name))
    }

    fn column_bool(&self, name: &str) -> PySchema {
        PySchema::new(self.inner.clone().column_bool(name))
    }

    fn column_utf8(&self, name: &str) -> PySchema {
        PySchema::new(self.inner.clone().column_utf8(name))
    }
}
