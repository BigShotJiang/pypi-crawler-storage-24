use pyo3::prelude::*;

mod arrow_py;
mod error;
mod inline_json;
mod kinds;
mod onceframe;
mod program;
mod reader;
mod schema;
mod uprogram;

use onceframe::{PyOnceFrame, PyRealizedOnceFrame};
use program::PyProgram;
use reader::{PyCsvReader, PyJsonReader, PyParquetReader, PyTranscendReader};
use schema::PySchema;

#[pymodule(name = "autark")]
fn autarkpy(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyCsvReader>()?;
    m.add_class::<PyParquetReader>()?;
    m.add_class::<PyJsonReader>()?;
    m.add_class::<PyTranscendReader>()?;
    m.add_class::<PyProgram>()?;
    let program = m.getattr("Program")?;
    m.add("P", program)?;
    m.add_class::<PyOnceFrame>()?;
    m.add_class::<PyRealizedOnceFrame>()?;
    m.add_class::<PySchema>()?;
    uprogram::register(m)?;
    Ok(())
}
