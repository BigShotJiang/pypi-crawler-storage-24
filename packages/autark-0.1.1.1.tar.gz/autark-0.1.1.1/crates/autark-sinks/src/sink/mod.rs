pub mod csv;
pub mod void;

use mpera::programoutput::ProgramOutput;

pub trait Sink {
    fn sink(&self, output: ProgramOutput) -> crate::Result<()>;
    fn finish(&mut self) -> crate::Result<()>;
}
