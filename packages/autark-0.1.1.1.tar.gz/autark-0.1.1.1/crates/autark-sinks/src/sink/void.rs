use crate::sink::Sink;

pub struct SinkVoid {}

impl Sink for SinkVoid {
    fn finish(&mut self) -> crate::Result<()> {
        Ok(())
    }

    fn sink(&self, _output: mpera::programoutput::ProgramOutput) -> crate::Result<()> {
        Ok(())
    }
}
