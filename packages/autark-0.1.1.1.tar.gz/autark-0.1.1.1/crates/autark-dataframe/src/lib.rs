#![deny(clippy::unwrap_used)]

pub(crate) mod arrow_interop;
pub(crate) mod dataframe;
pub(crate) mod error;

pub use dataframe::*;
pub use error::*;

pub type Result<T> = std::result::Result<T, Error>;
