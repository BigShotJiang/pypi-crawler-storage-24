// #[derive(Debug, thiserror::Error)]
// pub enum Error {
//     #[error("MPERA Error")]
//     MperaError(#[from] mpera::error::Error),

//     #[error("TensorError")]

//     #[error("ArrowError")]
//     Arrow(#[from] arrow::error::ArrowError),

//     #[error("sink error: {0}")]
//     Sink(String),
// }
//
pub use autark_error::Error;
