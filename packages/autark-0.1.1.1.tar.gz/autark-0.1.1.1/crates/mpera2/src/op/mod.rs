pub mod binary_op;
pub mod columns;
pub mod concat;
pub mod constant;
pub mod filter;
pub mod group_by;
pub mod group_common;
pub mod group_reduce;
pub mod join;
pub mod order_by;
pub mod reduce;
pub mod rolling;
pub mod slice;
pub mod unary_op;
pub mod where_op;

use arrow::array::RecordBatch;
use mpera_frontend::op::OpRef;

use crate::runtimedb::RuntimeDB;

pub type OpOut = crate::Result<Option<Vec<RecordBatch>>>;

pub trait StatefulBatchOp {
    fn opref(&self) -> OpRef;

    fn consume(&mut self, rtdb: &RuntimeDB) -> OpOut;

    fn finalize(&mut self) -> crate::Result<Vec<RecordBatch>> {
        Ok(Vec::new())
    }
}
