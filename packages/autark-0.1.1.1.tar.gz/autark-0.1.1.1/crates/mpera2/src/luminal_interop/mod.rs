mod arrays;
mod binary;
mod reduce;
mod unary;

pub use binary::binary_array;
pub use reduce::reduce_array;
pub use unary::unary_array;
