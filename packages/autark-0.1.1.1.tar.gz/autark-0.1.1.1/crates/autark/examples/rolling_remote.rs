// use autark_client::{OnceFrame, Result};
use autark::prelude::*;
use autark_reader::readers::csv::CsvReader;
use std::hash::{DefaultHasher, Hash, Hasher};

const REMOTE_CSV: &str = "https://raw.githubusercontent.com/Snowflake-Labs/demo-datasets/refs/heads/main/avalanche/csv/order-history.csv";

fn hash_of_t<T: Hash>(x: &T) -> Option<u64> {
    let mut hasher = DefaultHasher::new();
    x.hash(&mut hasher);

    Some(hasher.finish())
}

fn main() -> AutarkResult<()> {
    let reader = CsvReader::new(REMOTE_CSV)?;
    let mut frame = OnceFrame::new(reader);
    let p = Program::new();
    let schema = frame.schema(None)?.into_arrow();
    let first_field = schema
        .fields()
        .first()
        .expect("remote csv should have at least one column");
    let first_column = first_field.name();

    p.columns(None, ColumnSelector::All)?
        .columns(None, ColumnSelector::Names(vec![first_column.to_string()]))?
        .reduce(ReduceKind::Count)?
        .alias("row_count", None)?;

    let realized = frame.realize(p, None)?;
    assert!(hash_of_t(&realized).is_some());

    Ok(())
}
