pub mod onceframe {
    pub use autark_interface_onceframe::*;
}
pub mod prelude;
pub mod mpera {
    pub use mpera::op;
    pub use mpera::program;
    pub use mpera::programmetadata;
    pub use mpera::programoutput;
    pub use mpera::programsignature;

    pub mod uprogram {
        use mpera::{Result, op::*, program::Program};

        pub fn dist_normalized(program: Program) -> Result<Program> {
            let x = program.group_reduce(None, vec![ReduceKind::Count])?;
            let sum = x
                .columns(None, ColumnSelector::Indices(vec![1]))?
                .reduce(ReduceKind::Sum)?;
            x.columns(None, ColumnSelector::Indices(vec![0]))?
                .concat(&[x
                    .columns(None, ColumnSelector::Indices(vec![1]))?
                    .binaryop(sum, BinaryOpKind::Div)?])
        }

        pub fn zscore(program: Program) -> Result<Program> {
            let mu = program.reduce(ReduceKind::Mean)?;
            let sigma = program.reduce(ReduceKind::Stdev)?;
            let centered = program.binaryop(mu, BinaryOpKind::Sub)?;
            centered.binaryop(sigma, BinaryOpKind::Div)
        }
    }
}

// pub use autark_error::Error;
// pub use onceframe::OnceFrame;
// pub use onceframe::;
