pub fn resolve_batch_size(default_batch_size: usize) -> usize {
    std::env::var("BATCH")
        .ok()
        .and_then(|value| parse_batch_size(&value))
        .or_else(|| {
            std::env::var("AUTARK_BATCH_SIZE")
                .ok()
                .and_then(|value| parse_batch_size(&value))
        })
        .unwrap_or(default_batch_size)
}

fn parse_batch_size(value: &str) -> Option<usize> {
    value.trim().parse::<usize>().ok()
}
