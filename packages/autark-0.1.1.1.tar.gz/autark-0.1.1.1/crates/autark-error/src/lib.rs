use std::ffi::NulError;
use std::io;

#[derive(thiserror::Error, Debug)]
pub enum Error {
    #[error("Provided Empty Program")]
    ProvidedEmptyProgram,
    #[error("Problem initializing program. {0}")]
    ErrorInitializingProgram(Box<Error>),

    #[error("Problem interfacing with CPython: {0}.")]
    PyO3Error(#[from] pyo3::PyErr),

    #[error("Problem interfacing with Arrow: {0}.")]
    ArrowError(#[from] arrow::error::ArrowError),

    #[error("Poisoned lock.")]
    PoisonedLock,

    #[error("Reader is void.")]
    EmptyReader,

    #[error("Reader error: {0}")]
    Reader(String),

    #[error("I/O error: {0}.")]
    Io(#[from] io::Error),

    #[error("JSON error: {0}.")]
    Json(#[from] serde_json::Error),

    #[error("Invalid URI: {0}")]
    InvalidUri(String),

    #[error("Unsupported URI: {0}")]
    UnsupportedUri(String),

    #[error("Nul Error.")]
    NulError(#[from] NulError),

    #[error("Sink problem.")]
    Sink(String),

    #[error("Unsupported Arrow DataType.")]
    UnsupportedArrowDataType,
}
