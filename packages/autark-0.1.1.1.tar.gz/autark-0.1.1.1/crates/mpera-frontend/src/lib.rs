pub mod event;
pub mod frontend;
pub mod programoutput;

pub use autark_error::Error;
pub use frontend::op;
pub use frontend::program;
pub use frontend::programmetadata;
pub use frontend::programsignature;

pub type Result<T> = std::result::Result<T, Error>;
