use std::collections::BTreeMap;

use arrow::datatypes::Schema;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ProgramMetadata {
    pub schema_map: BTreeMap<String, Schema>,
}
