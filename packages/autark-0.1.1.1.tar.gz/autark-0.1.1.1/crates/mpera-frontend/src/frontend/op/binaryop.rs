use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum BinaryOpKind {
    // Arithmetic
    Add,
    Sub,
    Mul,
    Div,
    // Comparison
    LesserThan,
    GreaterThan,
    LesserEquals,
    GreaterEquals,
    Equals,
    NotEquals,
    And,
    Or,
}
