use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub struct OpRef(pub usize);

impl OpRef {
    pub fn new(index: usize) -> OpRef {
        OpRef(index)
    }
}
