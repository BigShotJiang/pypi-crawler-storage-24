pub mod binaryop;
pub mod op;
pub mod oppool;
pub mod opref;
use serde::{Deserialize, Serialize};

pub use binaryop::BinaryOpKind;
pub use op::*;
pub use oppool::OpPool;
pub use opref::OpRef;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ReduceKind {
    Sum,
    Product,
    Mean,
    Count,
    Stdev,
    Min,
    Max,
    Last,
    Percentile { x: f64 },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum UnaryOpKind {
    Neg,
    Cumsum,
    PctChange { n: usize },
    Diff { n: usize },
    Lead { n: usize },
    Lag { n: usize },
}

impl UnaryOpKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            UnaryOpKind::Neg => "neg",
            UnaryOpKind::Cumsum => "cumsum",
            UnaryOpKind::PctChange { .. } => "pct_change",
            UnaryOpKind::Diff { .. } => "diff",
            UnaryOpKind::Lead { .. } => "lead",
            UnaryOpKind::Lag { .. } => "lag",
        }
    }
}

impl ReduceKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            ReduceKind::Sum => "sum",
            ReduceKind::Product => "product",
            ReduceKind::Mean => "mean",
            ReduceKind::Count => "len",
            ReduceKind::Stdev => "std",
            ReduceKind::Min => "min",
            ReduceKind::Max => "max",
            ReduceKind::Last => "last",
            ReduceKind::Percentile { .. } => "percentile",
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum JoinKind {
    Inner,
    LeftOuter,
    AsOfBackward,
    AsOfForward,
}

impl JoinKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            JoinKind::Inner => "inner",
            JoinKind::LeftOuter => "left_outer",
            JoinKind::AsOfBackward => "asof_backward",
            JoinKind::AsOfForward => "asof_forward",
        }
    }
}
