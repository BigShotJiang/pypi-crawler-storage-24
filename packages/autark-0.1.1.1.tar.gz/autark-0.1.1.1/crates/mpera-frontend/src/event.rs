use arrow::array::RecordBatch;

#[derive(Debug, Clone)]
pub enum Event {
    Append(RecordBatch),
    Delete(RecordBatch),
}
