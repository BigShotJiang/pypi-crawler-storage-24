from .autark import *

if hasattr(Program, "ir_json") and not hasattr(Program, "ir"):
    Program.ir = Program.ir_json
if hasattr(Program, "columns") and not hasattr(Program, "cols"):
    Program.cols = Program.columns

__doc__ = autark.__doc__
if hasattr(autark, "__all__"):
    __all__ = autark.__all__
