"""Example: run a one-shot task with the AIR SDK.

Usage::

    export AIR_API_KEY="air_k1_..."
    python examples/test_one_shot.py

By default this connects to http://localhost:8000.  Override with::

    export AIR_BASE_URL="https://your-backend.example.com"
"""

import os
import sys
from dotenv import load_dotenv
import air

load_dotenv()

API_KEY = os.environ.get("AIR_API_KEY")
BASE_URL = os.environ.get("AIR_BASE_URL", "http://localhost:8000")
print(f"BASE_URL: {BASE_URL}")

if not API_KEY:
    sys.exit("Set AIR_API_KEY first:  export AIR_API_KEY='air_k1_...'")

client = air.AIR(api_key=API_KEY, base_url=BASE_URL)

enhanced = client.enhance(
    "My research with https://arxiv.org/abs/2301.12345",
    max_workers=2,
    max_depth=10,
)
print(enhanced)

client.close()
