#!/usr/bin/env python3
"""
Smoke test: extract keywords via the AIR SDK.

Usage:
    python examples/test_keywords.py
"""

import os
import sys
from dotenv import load_dotenv
import air

load_dotenv()

API_KEY = os.environ.get("AIR_API_KEY")
BASE_URL = os.environ.get("AIR_BASE_URL", "http://localhost:8000")

if not API_KEY:
    sys.exit("Set AIR_API_KEY first:  export AIR_API_KEY='air_k1_...'")

with air.AIR(api_key=API_KEY, base_url=BASE_URL) as client:
    print("Health:", client.health())

    text = "We study the cosmic microwave background anisotropies and large-scale structure of the universe using gravitational lensing."

    print("\n--- UNESCO keywords ---")
    kw = client.keywords(text, n=5, kw_type="unesco")
    for k in kw:
        print(f"  {k}")

    print("\n--- AAS keywords ---")
    kw = client.keywords(text, n=5, kw_type="aas")
    for k in kw:
        print(f"  {k}")

    print("\nDone.")
