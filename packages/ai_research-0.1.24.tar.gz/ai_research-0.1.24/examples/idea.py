#!/usr/bin/env python3
"""
Smoke test: create a project and run the idea step via the AIR SDK.

Usage:
    export AIR_API_KEY="air_k1_..."
    python examples/test_idea.py

    # or point at a remote server:
    AIR_BASE_URL="https://orion:8000" python examples/test_idea.py
"""

import os
import sys
from dotenv import load_dotenv
import air

load_dotenv()

API_KEY = os.environ.get("AIR_API_KEY")
BASE_URL = os.environ.get("AIR_BASE_URL", "http://localhost:8000")

if not API_KEY:
    sys.exit("Set AIR_API_KEY first:  export AIR_API_KEY='air_k1_...'")

PROJECT_NAME = "sdk-test-idea"
print(f"BASE_URL: {BASE_URL}")

with air.AIR(api_key=API_KEY, base_url=BASE_URL) as client:
    # 1. Health check
    print("Health:", client.health())

    # 2. Create project
    project = client.create_project(
        PROJECT_NAME,
        data_description="We study drug discovery pipelines.",
    )
    print(f"Project created: {project}")

    # 3. Run idea generation (AIR fast mode)
    print("Running idea generation (this may take a few minutes)...")
    idea = project.idea(mode="fast", timeout=900)
    print("\n--- Generated idea ---")
    print(idea)

    # 4. List files produced
    files = project.list_files()
    print(f"\nFiles in project ({len(files)}):")
    for f in files:
        print(f"  {f['relative_path']}  ({f['size']} bytes)")

