# Standalone tools

Complete runnable scripts from the
[`examples/`](https://github.com/Denario-private/air-sdk/tree/main/examples)
directory. Each one expects `AIR_API_KEY` (and optionally `AIR_BASE_URL`) to
be set in the environment or in a `.env` file.

## One-shot execution

Run a free-form task with local code execution via the AI agent loop.

```python
--8<-- "examples/one_shot.py"
```

## ArXiv download

Download papers from arXiv URLs found in text.

```python
--8<-- "examples/arxiv.py"
```

## Text enhancement

Enhance text with contextual information from arXiv papers.

```python
--8<-- "examples/text_enhancement.py"
```

## OCR

Download an arXiv paper and extract its text with OCR. Accepts an optional
arXiv URL as a command-line argument.

```python
--8<-- "examples/ocr.py"
```

## Keywords

Extract keywords from a text using different vocabularies (UNESCO and AAS).

```python
--8<-- "examples/keywords.py"
```
