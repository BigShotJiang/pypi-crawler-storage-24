# Jzip

<center>
Jzip stands fo Json zip

Developed using Python, but with full functionality.
</center>

<p align="center">
<a href="https://github.com/makk-r"><img src="https://img.shields.io/github/followers/makk-r?style=flat&logo=github" alt="Profile"></a>
<a href="https://github.com/makk-r/Jzip"><img src="https://img.shields.io/badge/github-JZIP-blue?logo=github" alt="Profile"></a>
</p>

## 📖 Table of Contents

* [Target](#-target)
* [Inspection record](#-inspection-record)

## 🎯 Target

```mermaid
flowchart LR
    JZ(JZIP)
    SD(speed)
    CT(convenient)
    OS(open source)
    UR(User)
    DEV(Development)

    JZ ---> SD
    JZ ---> CT
    JZ ---> OS

    SD ---> UR
    CT ---> UR
    OS ---> UR

    OS --->  DEV
```
This is a diagram of the project.

We strive to make everything as convenient as possible.

## 📜 Inspection record

Compress the enwik8 file.

| Name | Compress (s) | Extract (s) | Size (MB) |
| ----------- | ----------- | ----------- | ----------- |
| GZIP | ~3.5 - 4.0 | ~0.40 | 36.5 |
| ZIP | ~4.0 - 5.0 | ~0.50 | 36.5 |
| 7-Zip | ~25.0 - 40.0 | ~2.00 | 23.1 |
| XZ | ~30.0 - 50.0 | ~3.00 | ~20-25 |
| Jzip | 3.25 | 0.29 | 36.5 |
