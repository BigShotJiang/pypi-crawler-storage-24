from __future__ import annotations

import gzip
from pathlib import Path
from typing import BinaryIO
from unittest.mock import patch

import pytest

from dissect.hypervisor.disk.hdd import HDD
from tests._util import absolute_path

Path_open = Path.open


@pytest.fixture
def plain_hdd() -> Path:
    return absolute_path("_data/disk/hdd/plain.hdd")


@pytest.fixture
def expanding_hdd() -> Path:
    return absolute_path("_data/disk/hdd/expanding.hdd")


@pytest.fixture
def split_hdd() -> Path:
    return absolute_path("_data/disk/hdd/split.hdd")


def mock_open_gz(self: Path, *args, **kwargs) -> BinaryIO:
    if self.suffix.lower() != ".hds":
        return Path_open(self, *args, **kwargs)

    return gzip.open(self.with_suffix(self.suffix + ".gz"))


def test_plain_hdd(plain_hdd: Path) -> None:
    hdd = HDD(plain_hdd)
    storages = hdd.descriptor.storage_data.storages

    assert len(storages) == 1
    assert storages[0].start == 0
    assert storages[0].end == 204800
    assert len(storages[0].images) == 1
    assert storages[0].images[0].type == "Plain"

    with patch.object(Path, "open", mock_open_gz):
        stream = hdd.open()

        for i in range(100):
            assert stream.read(1024 * 1024).strip(bytes([i])) == b"", f"Mismatch at offset {i * 1024 * 1024:#x}"


def test_expanding_hdd(expanding_hdd: Path) -> None:
    hdd = HDD(expanding_hdd)
    storages = hdd.descriptor.storage_data.storages

    assert len(storages) == 1
    assert storages[0].start == 0
    assert storages[0].end == 204800
    assert len(storages[0].images) == 1
    assert storages[0].images[0].type == "Compressed"

    with patch.object(Path, "open", mock_open_gz):
        stream = hdd.open()

        for i in range(100):
            assert stream.read(1024 * 1024).strip(bytes([i])) == b"", f"Mismatch at offset {i * 1024 * 1024:#x}"


def test_split_hdd(split_hdd: Path) -> None:
    hdd = HDD(split_hdd)
    storages = hdd.descriptor.storage_data.storages

    assert len(storages) == 6

    split_sizes = [3989504, 3989504, 3989504, 3989504, 3989504, 1024000]

    start = 0

    for storage, split_size in zip(storages, split_sizes, strict=False):
        assert storage.start == start
        assert storage.end == start + split_size
        assert len(storage.images) == 1
        assert storage.images[0].type == "Compressed"

        start = storage.end

    with patch.object(Path, "open", mock_open_gz):
        stream = hdd.open()

        assert stream.read(1024 * 1024).strip(b"\x01") == b""

        offset = 0
        for i, split_size in enumerate(split_sizes):
            offset += split_size * 512
            stream.seek(offset - 512)

            buf = stream.read(1024)
            if i < 5:
                assert buf == bytes([i + 1] * 512) + bytes([i + 2] * 512)
            else:
                assert buf == bytes([i + 1] * 512)


def test_file_use_parent(plain_hdd: Path) -> None:
    hdd = HDD(plain_hdd.joinpath("plain.hdd"))
    storages = hdd.descriptor.storage_data.storages

    assert len(storages) == 1
