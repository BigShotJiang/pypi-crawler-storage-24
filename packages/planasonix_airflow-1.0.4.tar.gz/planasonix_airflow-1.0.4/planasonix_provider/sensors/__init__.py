"""Planalytix Airflow Sensors."""

from planasonix_provider.sensors.sync import PlanalytixSyncSensor

__all__ = ["PlanalytixSyncSensor"]
