"""
Planasonix Airflow Provider

Provides hooks, operators, and sensors for integrating Planasonix
with Apache Airflow workflows.
"""

__version__ = "1.0.3"


def get_provider_info():
    """Return provider metadata for Airflow."""
    return {
        "package-name": "planasonix-airflow",
        "name": "Planasonix",
        "description": "Apache Airflow provider for Planasonix data integration platform",
        "versions": [__version__],
        "connection-types": [
            {
                "connection-type": "planalytix",
                "hook-class-name": "planasonix_provider.hooks.planasonix.PlanalytixHook",
            }
        ],
        "hook-class-names": [
            "planasonix_provider.hooks.planasonix.PlanalytixHook",
        ],
        "extra-links": [
            "planasonix_provider.operators.sync.PlanalytixJobLink",
        ],
    }
