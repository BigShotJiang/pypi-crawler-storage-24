"""Veloscope — Lightweight AI agent observability SDK."""

from veloscope.core import init, trace, span, flush

__version__ = "0.1.0"
__all__ = ["init", "trace", "span", "flush"]
