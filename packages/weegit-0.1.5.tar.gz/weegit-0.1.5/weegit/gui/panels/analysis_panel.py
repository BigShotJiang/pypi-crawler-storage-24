from __future__ import annotations

from pathlib import Path
import inspect
from typing import Optional

from PyQt6.QtWidgets import (
    QApplication,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QCheckBox,
    QScrollArea,
    QSizePolicy,
)

from weegit import settings
from weegit.gui.dialogs.loading_dialog import LoadingDialog
from weegit.logger import weegit_logger


class AnalysisPanel(QWidget):
    """Add-ons control panel (view/transform/run)."""

    def __init__(self, session_manager, parent=None):
        super().__init__(parent)
        self._session_manager = session_manager
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        self.setFixedHeight(240)
        self._build_ui()
        self._connect_signals()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(5, 5, 5, 5)
        root.setSpacing(8)

        title = QLabel("Add-ons")
        root.addWidget(title)

        self._scroll = QScrollArea(self)
        self._scroll.setWidgetResizable(True)
        self._container = QWidget()
        self._container_layout = QVBoxLayout(self._container)
        self._container_layout.setContentsMargins(2, 2, 2, 2)
        self._container_layout.setSpacing(6)
        self._container_layout.addStretch(1)
        self._scroll.setWidget(self._container)
        root.addWidget(self._scroll, 1)

    def _connect_signals(self):
        self._session_manager.session_loaded.connect(self._rebuild_rows)
        self._session_manager.add_ons_changed.connect(self._rebuild_rows)

    def _clear_rows(self):
        while self._container_layout.count():
            item = self._container_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def _rebuild_rows(self, *_args):
        self._clear_rows()
        gui_setup = self._session_manager.gui_setup
        if gui_setup is None:
            self._container_layout.addStretch(1)
            return

        runtime_add_ons = self._session_manager.get_all_add_ons()
        for module_name in sorted(gui_setup.add_ons.keys()):
            setup = gui_setup.add_ons[module_name]
            add_on = runtime_add_ons.get(module_name)

            row_widget = QWidget()
            row_layout = QHBoxLayout(row_widget)
            row_layout.setContentsMargins(2, 2, 2, 2)
            row_layout.setSpacing(6)

            label = QLabel(module_name)
            row_layout.addWidget(label, 1)

            view_cb = QCheckBox("View")
            view_supported = bool(add_on and getattr(add_on, "VIEWABLE", False))
            view_cb.setChecked(bool(setup.view_enabled))
            view_cb.setEnabled(view_supported)
            view_cb.toggled.connect(lambda checked, m=module_name: self._session_manager.set_add_on_view_enabled(m, checked))
            row_layout.addWidget(view_cb)

            transform_cb = QCheckBox("Transform")
            transform_supported = bool(add_on and getattr(add_on, "TRANSFORMATION", False))
            transform_cb.setChecked(bool(setup.transform_enabled))
            transform_cb.setEnabled(transform_supported)
            transform_cb.toggled.connect(
                lambda checked, m=module_name: self._session_manager.set_add_on_transform_enabled(m, checked)
            )
            row_layout.addWidget(transform_cb)

            run_btn = QPushButton("Run")
            run_supported = bool(add_on and getattr(add_on, "RUNNABLE", False))
            run_btn.setEnabled(run_supported)
            run_btn.clicked.connect(lambda checked=False, m=module_name: self._run_add_on(m))
            row_layout.addWidget(run_btn)

            self._container_layout.addWidget(row_widget)

        self._container_layout.addStretch(1)

    def _parse_progress(self, yielded):
        if isinstance(yielded, str):
            return None, yielded
        if isinstance(yielded, (tuple, list)) and len(yielded) >= 2:
            return yielded[0], str(yielded[1])
        if isinstance(yielded, dict):
            return yielded.get("progress"), str(yielded.get("message", "Running add-on..."))
        return None, str(yielded)

    def _run_add_on(self, module_name: str):
        runtime_add_on = self._session_manager.get_runtime_add_on(module_name)
        if runtime_add_on is None:
            return
        add_ons_data_dir = (
            Path(self._session_manager.weegit_experiment_folder)
            / settings.ADD_ONS_SUBFOLDER
            / settings.ADD_ONS_DATA_SUBFOLDER
            / module_name
        )
        add_ons_data_dir.mkdir(parents=True, exist_ok=True)

        loading: Optional[LoadingDialog] = None
        try:            
            run_result = runtime_add_on.run(self._session_manager, add_ons_data_dir)
            if inspect.isgenerator(run_result):
                for yielded in run_result:
                    progress, message = self._parse_progress(yielded)
                    if loading is None:
                        loading = LoadingDialog("Running add-on...", self)
                        loading.show()
                        loading.raise_()
                        loading.activateWindow()
                    loading.set_message(message)
                    loading.set_progress(progress)
                    QApplication.processEvents()
            self._session_manager.notify_add_on_run(module_name)
        except Exception as e:
            weegit_logger().error(str(e))
        finally:
            if loading is not None:
                loading.close()
