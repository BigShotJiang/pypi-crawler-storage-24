# lnuElytra

[lnuElytra](https://github.com/mcitem/lnuElytra) 是适用于[岭南师范学院正方教务系统](http://jw.lingnan.edu.cn)的抢选课工具。

[使用文档](https://lnu-elytra.mcitem.net)

## 许可证

`AGPL-3.0`

## 免责声明

本工具仅供编程技术学习研究使用，不保证可用性、成功率，一切风险与后果由使用者自行承担。
