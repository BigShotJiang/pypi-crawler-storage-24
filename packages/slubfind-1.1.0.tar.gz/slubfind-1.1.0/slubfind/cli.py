"""
command-line interface of ``slubfind`` package
"""
import argparse
import json
import logging
import os
import sys

from . import __version__
from .client import SlubFind

logger = logging.getLogger(__name__)


def parse_facet(value):
    """Parse a KEY=VALUE facet argument into a (key, value) tuple."""
    if "=" not in value:
        raise argparse.ArgumentTypeError(
            f"facet must be in KEY=VALUE format, got: {value}")
    key, val = value.split("=", 1)
    if key not in SlubFind.FACETS:
        valid = ", ".join(SlubFind.FACETS)
        raise argparse.ArgumentTypeError(
            f"unknown facet key {key!r}, choose from: {valid}")
    return key, val


def merge_facets(facet_list):
    """Merge a list of (key, value) tuples into a single dict."""
    if not facet_list:
        return None
    return dict(facet_list)


def json_dumps(obj, compact=False):
    """Serialize object to JSON string."""
    if compact:
        return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    return json.dumps(obj, ensure_ascii=False, indent=2)


def build_parser():
    """Build and return the argument parser."""
    parser = argparse.ArgumentParser(
        prog="slubfind",
        description="Query data exports from the SLUB catalog.")

    parser.add_argument(
        "--version", action="version",
        version=f"%(prog)s {__version__}")
    parser.add_argument(
        "--url",
        default=os.environ.get(
            "SLUBFIND_URL", "https://katalog.slub-dresden.de"),
        help="base URL of the SLUB catalog"
             " (or set SLUBFIND_URL env var,"
             " default: https://katalog.slub-dresden.de)")
    parser.add_argument(
        "--export-format",
        default="app",
        help="export format (default: app)")
    parser.add_argument(
        "--export-page",
        type=int,
        default=1369315142,
        help="export page type number (default: 1369315142)")
    parser.add_argument(
        "--pretty",
        action="store_true",
        help="pretty-print JSON output (with indentation)")
    parser.add_argument(
        "--show-url",
        action="store_true",
        help="print the request URL instead of fetching the response")
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="enable debug logging to stderr")

    subparsers = parser.add_subparsers(dest="command")

    # query subcommand
    query_parser = subparsers.add_parser(
        "query", help="search in app format")
    query_parser.add_argument("query", help="search query string")
    query_parser.add_argument(
        "--type", default="default", choices=SlubFind.QUERY_TYPES,
        help="query type (default: default)")
    query_parser.add_argument(
        "--facet", action="append", type=parse_facet,
        help="facet filter as KEY=VALUE (repeatable)")
    query_parser.add_argument(
        "--page", type=int, default=0, help="page number")
    query_parser.add_argument(
        "--count", type=int, default=0, help="results per page")
    query_parser.add_argument(
        "--sort", default="", help="sort instruction")

    # document subcommand
    doc_parser = subparsers.add_parser(
        "document", help="fetch document in app format")
    doc_parser.add_argument("document_id", help="document identifier")

    # scroll subcommand
    scroll_parser = subparsers.add_parser(
        "scroll", help="fetch all paginated results")
    scroll_parser.add_argument("query", help="search query string")
    scroll_parser.add_argument(
        "--type", default="default", choices=SlubFind.QUERY_TYPES,
        help="query type (default: default)")
    scroll_parser.add_argument(
        "--facet", action="append", type=parse_facet,
        help="facet filter as KEY=VALUE (repeatable)")
    scroll_parser.add_argument(
        "--batch", type=int, default=20,
        help="results per batch (default: 20)")
    scroll_parser.add_argument(
        "--sort", default="", help="sort instruction")
    scroll_parser.add_argument(
        "--stream", action="store_true",
        help="output one JSON object per line (JSONL)")

    # settings subcommand
    subparsers.add_parser(
        "settings", help="show TYPO3-find settings")

    # solr-params subcommand
    solr_params_parser = subparsers.add_parser(
        "solr-params", help="show Solr parameters for a query")
    solr_params_parser.add_argument("query", help="search query string")
    solr_params_parser.add_argument(
        "--type", default="default", choices=SlubFind.QUERY_TYPES,
        help="query type (default: default)")
    solr_params_parser.add_argument(
        "--facet", action="append", type=parse_facet,
        help="facet filter as KEY=VALUE (repeatable)")
    solr_params_parser.add_argument(
        "--page", type=int, default=0, help="page number")
    solr_params_parser.add_argument(
        "--count", type=int, default=0, help="results per page")
    solr_params_parser.add_argument(
        "--sort", default="", help="sort instruction")

    # solr-request subcommand
    solr_request_parser = subparsers.add_parser(
        "solr-request", help="show Solr request URL for a query")
    solr_request_parser.add_argument("query", help="search query string")
    solr_request_parser.add_argument(
        "--type", default="default", choices=SlubFind.QUERY_TYPES,
        help="query type (default: default)")
    solr_request_parser.add_argument(
        "--facet", action="append", type=parse_facet,
        help="facet filter as KEY=VALUE (repeatable)")
    solr_request_parser.add_argument(
        "--page", type=int, default=0, help="page number")
    solr_request_parser.add_argument(
        "--count", type=int, default=0, help="results per page")
    solr_request_parser.add_argument(
        "--sort", default="", help="sort instruction")

    return parser


def make_find(args):
    """Create a SlubFind instance from parsed arguments."""
    return SlubFind(
        base_url=args.url,
        export_format=args.export_format,
        export_page=args.export_page)


def cmd_query(find, args):
    """Handle the query subcommand."""
    if args.show_url:
        print(find.url_query(
            args.query,
            qtype=args.type,
            facet=merge_facets(args.facet),
            page=args.page,
            count=args.count,
            sort=args.sort))
        return 0
    result = find.app_search(
        args.query,
        qtype=args.type,
        facet=merge_facets(args.facet),
        page=args.page,
        count=args.count,
        sort=args.sort)
    if result is None:
        print("error: no results", file=sys.stderr)
        return 1
    data = result.raw if hasattr(result, "raw") else result
    print(json_dumps(data, compact=not args.pretty))
    return 0


def cmd_document(find, args):
    """Handle the document subcommand."""
    if args.show_url:
        url = find.url_document(args.document_id)
        if url is None:
            print("error: could not build document URL", file=sys.stderr)
            return 1
        print(url)
        return 0
    result = find.app_document(args.document_id)
    if result is None:
        print("error: document not found", file=sys.stderr)
        return 1
    data = result.raw if hasattr(result, "raw") else result
    print(json_dumps(data, compact=not args.pretty))
    return 0


def cmd_scroll(find, args):
    """Handle the scroll subcommand."""
    if args.show_url:
        print(find.url_query(
            args.query,
            qtype=args.type,
            facet=merge_facets(args.facet),
            count=args.batch,
            sort=args.sort))
        return 0
    if args.stream:
        for doc in find.stream_get_query(
                args.query,
                qtype=args.type,
                facet=merge_facets(args.facet),
                batch=args.batch,
                sort=args.sort):
            print(json_dumps(doc, compact=not args.pretty))
        return 0

    results = find.scroll_get_query(
        args.query,
        qtype=args.type,
        facet=merge_facets(args.facet),
        batch=args.batch,
        sort=args.sort)
    if results is None:
        print("error: no results", file=sys.stderr)
        return 1
    print(json_dumps(results, compact=not args.pretty))
    return 0


def cmd_settings(find, args):
    """Handle the settings subcommand."""
    result = find.settings()
    if result is None:
        print("error: could not retrieve settings", file=sys.stderr)
        return 1
    print(json_dumps(result, compact=not args.pretty))
    return 0


def cmd_solr_params(find, args):
    """Handle the solr-params subcommand."""
    result = find.solr_params(
        args.query,
        qtype=args.type,
        facet=merge_facets(args.facet),
        page=args.page,
        count=args.count,
        sort=args.sort)
    if result is None:
        print("error: could not retrieve Solr parameters", file=sys.stderr)
        return 1
    print(json_dumps(result, compact=not args.pretty))
    return 0


def cmd_solr_request(find, args):
    """Handle the solr-request subcommand."""
    result = find.solr_request(
        args.query,
        qtype=args.type,
        facet=merge_facets(args.facet),
        page=args.page,
        count=args.count,
        sort=args.sort)
    if result is None:
        print("error: could not retrieve Solr request URL", file=sys.stderr)
        return 1
    print(result)
    return 0


def main(argv=None):
    """CLI entry point."""
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.verbose:
        logging.basicConfig(
            level=logging.DEBUG,
            stream=sys.stderr,
            format="%(levelname)s: %(name)s: %(message)s")

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    find = make_find(args)

    commands = {
        "query": cmd_query,
        "document": cmd_document,
        "scroll": cmd_scroll,
        "settings": cmd_settings,
        "solr-params": cmd_solr_params,
        "solr-request": cmd_solr_request,
    }
    sys.exit(commands[args.command](find, args))
