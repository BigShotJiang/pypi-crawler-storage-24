"""
CEAP domain package.
"""
