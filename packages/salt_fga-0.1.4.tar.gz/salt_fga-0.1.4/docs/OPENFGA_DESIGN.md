# OpenFGA 初始化功能说明

## 设计原则

OpenFGA 的初始化和权限管理功能**仅用于开发和测试环境**，不作为 `salt-fga` CLI 的一部分。

### 为什么这样设计？

1. **职责分离**：salt-fga CLI 专注于执行 Salt 命令和权限检查，不负责权限系统的初始化和管理
2. **生产环境安全**：生产环境的 OpenFGA 应由运维团队独立部署和管理，避免通过应用层工具进行敏感操作
3. **开发便利性**：开发和测试环境需要快速搭建，通过 Makefile 和脚本提供便捷的初始化方式

## 功能分布

### Makefile（开发/测试环境）

```bash
make openfga-up      # 启动 OpenFGA Docker 服务
make openfga-down    # 停止 OpenFGA Docker 服务
make openfga-init    # 初始化 store 和 model
```

### scripts/init_openfga.sh（开发/测试环境）

自动化脚本，执行以下操作：
1. 检查依赖（fga CLI, jq）
2. 检查 OpenFGA 服务状态
3. 创建 OpenFGA Store
4. 从 `src/openfga/authorization_model.fga` 创建 Authorization Model
5. 更新配置文件 `~/.config/salt/openfga.json`

### fga CLI（所有环境）

使用 OpenFGA 官方 CLI 进行权限管理：
- 添加/删除用户
- 授予/撤销权限
- 查询权限关系

### salt-fga CLI（所有环境）

只负责：
1. 读取 OpenFGA 配置（`~/.config/salt/openfga.json`）
2. 执行 Salt 命令前进行权限检查
3. 查看用户身份信息（`salt-fga user info`）

**不包含**：
- ❌ `salt-fga permission init`
- ❌ `salt-fga permission add_member`
- ❌ `salt-fga permission grant_access`
- ❌ 其他权限管理命令

## 使用流程

### 开发/测试环境

```bash
# 1. 启动服务
make openfga-up

# 2. 初始化
make openfga-init

# 3. 设置用户身份
export COPAW_USER_ID=alice
export COPAW_USERNAME=alice
export COPAW_SESSION_ID=web:alice
export COPAW_CHANNEL=web

# 4. 配置权限（使用 fga CLI）
STORE_ID=$(cat ~/.config/salt/openfga.json | jq -r '.store_id')
fga tuple write --store-id $STORE_ID \
  '[{"user":"user:alice","relation":"member","object":"cluster:prod"}]'

# 5. 测试
salt-fga user info
salt-fga -c prod ping
```

### 生产环境

```bash
# 1. 运维团队部署 OpenFGA 服务

# 2. 运维团队创建 store 和 model

# 3. 开发人员配置客户端
cat > ~/.config/salt/openfga.json <<EOF
{
  "api_url": "https://openfga.example.com",
  "store_id": "01XXXXXXXXXXXXXXXXXXXX",
  "authorization_model_id": "01YYYYYYYYYYYYYYYYYYYY"
}
EOF

# 4. 运维团队使用 fga CLI 或 API 配置权限

# 5. 开发人员使用 salt-fga 执行命令
export COPAW_USER_ID=alice
salt-fga -c prod ping
```

## 文件结构

```
salt/
├── docker-compose.yml              # OpenFGA Docker 配置（开发/测试）
├── Makefile                        # 开发命令（openfga-up/down/init）
├── scripts/
│   ├── init_openfga.sh            # 初始化脚本（开发/测试）
│   └── README.md                  # 脚本使用说明
├── docs/
│   └── QUICKSTART.md              # 快速开始指南（开发/测试）
├── src/
│   ├── openfga/
│   │   ├── authorization_model.fga # 权限模型定义
│   │   ├── config.py              # 配置管理
│   │   └── checker.py             # 权限检查器
│   └── salt/
│       ├── cli.py                 # CLI 入口（不包含 permission 命令）
│       └── commands/
│           └── user.py            # 用户信息命令
└── README.md                      # 项目文档

用户配置：
~/.config/salt/openfga.json        # OpenFGA 配置文件
```

## 总结

- ✅ 开发/测试环境：使用 Makefile 和脚本快速初始化
- ✅ 生产环境：运维团队独立管理 OpenFGA
- ✅ 权限管理：统一使用 fga CLI 或 API
- ✅ salt-fga CLI：专注于命令执行和权限检查
- ❌ salt-fga CLI：不包含权限管理功能
