# OpenFGA 快速开始指南（开发/测试环境）

本指南帮助你在开发和测试环境中快速设置 OpenFGA 权限系统。

> **注意：** 本指南仅适用于开发和测试环境。生产环境应由运维团队独立部署和管理 OpenFGA。

## 步骤 1: 启动 OpenFGA 服务

```bash
# 启动 Docker 容器
make openfga-up

# 或者直接使用 docker-compose
docker-compose up -d
```

等待几秒钟，确保服务启动完成：

```bash
curl http://localhost:8080/healthz
# 应该返回: {"status":"SERVING"}
```

## 步骤 2: 初始化 OpenFGA

运行初始化脚本，自动创建 store 和 authorization model：

```bash
make openfga-init

# 或者直接运行脚本
./scripts/init_openfga.sh
```

脚本会输出：
- Store ID
- Authorization Model ID
- 配置文件路径

配置文件会自动保存到 `~/.config/salt/openfga.json`。

## 步骤 3: 设置用户身份

设置环境变量来标识当前用户：

```bash
export COPAW_USER_ID=alice
export COPAW_USERNAME=alice
export COPAW_SESSION_ID=web:alice
export COPAW_CHANNEL=web
```

你可以将这些环境变量添加到 `~/.bashrc` 或 `~/.zshrc` 中，以便每次启动终端时自动设置。

## 步骤 4: 配置权限

使用 fga CLI 配置权限关系。

### 获取 Store ID

```bash
cat ~/.config/salt/openfga.json | grep store_id
```

### 添加用户到集群

```bash
# 将 alice 添加为 prod 集群的成员
fga tuple write --store-id <store_id> \
  '[{"user":"user:alice","relation":"member","object":"cluster:prod"}]'
```

### 授予权限（非限制模式）

授予用户对某个主机的所有命令权限：

```bash
# alice 可以在 prod 环境的 web-01 主机上执行所有命令
fga tuple write --store-id <store_id> \
  '[{"user":"user:alice","relation":"can_access","object":"target:prod/web-01"}]'

# alice 可以在 prod 环境的所有主机上执行所有命令
fga tuple write --store-id <store_id> \
  '[{"user":"user:alice","relation":"can_access","object":"target:prod/*"}]'
```

### 授予权限（限制模式）

授予用户对某个主机的特定命令权限：

```bash
# alice 只能在 test 环境的 db-01 主机上执行 ping 命令
fga tuple write --store-id <store_id> \
  '[{"user":"user:alice","relation":"can_execute","object":"target_cmd:test/db-01/ping"}]'

# alice 可以在 test 环境的所有主机上执行 cmd 命令
fga tuple write --store-id <store_id> \
  '[{"user":"user:alice","relation":"can_execute","object":"target_cmd:test/*/cmd"}]'
```

## 步骤 5: 验证权限

### 查看权限

```bash
# 查看 alice 的所有权限
fga tuple read --store-id <store_id> --user "user:alice"

# 查看 prod 集群的所有权限
fga tuple read --store-id <store_id> --object "cluster:prod"
```

### 测试命令执行

```bash
# 以 alice 的身份执行命令
export COPAW_USER_ID=alice
export COPAW_USERNAME=alice

# 查看用户信息
salt-fga user info

# 测试 ping 命令
salt-fga -c prod ping --tgt web-01

# 如果没有权限，会看到权限拒绝的错误
```

## 常用命令速查

### Makefile 命令

```bash
# 启动/停止服务
make openfga-up
make openfga-down

# 初始化 store 和 model
make openfga-init
```

### fga CLI 命令

```bash
# 添加用户到集群
fga tuple write --store-id <store_id> \
  '[{"user":"user:alice","relation":"member","object":"cluster:prod"}]'

# 授予主机访问权限（所有命令）
fga tuple write --store-id <store_id> \
  '[{"user":"user:alice","relation":"can_access","object":"target:prod/web-01"}]'

# 授予命令执行权限（特定命令）
fga tuple write --store-id <store_id> \
  '[{"user":"user:alice","relation":"can_execute","object":"target_cmd:prod/web-01/ping"}]'

# 查看权限
fga tuple read --store-id <store_id> --user "user:alice"

# 撤销权限
fga tuple delete --store-id <store_id> \
  '[{"user":"user:alice","relation":"can_access","object":"target:prod/web-01"}]'
```

### salt-fga 命令

```bash
# 查看用户信息
salt-fga user info

# 执行命令（会进行权限检查）
salt-fga -c prod 'web-01' test.ping
salt-fga -c prod 'web-01' cmd.run 'uptime'
```

## 故障排查

### OpenFGA 服务无法启动

```bash
# 查看日志
docker-compose logs openfga

# 重启服务
docker-compose restart
```

### 权限检查失败

1. 确认用户身份环境变量已设置：
   ```bash
   echo $COPAW_USER_ID
   ```

2. 确认 OpenFGA 配置文件存在：
   ```bash
   cat ~/.config/salt/openfga.json
   ```

3. 检查用户权限：
   ```bash
   fga tuple read --store-id <store_id> --user "user:alice"
   ```

## 重新初始化

如果需要完全重新开始：

```bash
# 1. 停止服务
make openfga-down

# 2. 删除配置文件
rm ~/.config/salt/openfga.json

# 3. 启动服务
make openfga-up

# 4. 重新初始化
make openfga-init

# 5. 重新配置权限
fga tuple write --store-id <store_id> \
  '[{"user":"user:alice","relation":"member","object":"cluster:prod"}]'
```

## 下一步

- 阅读 [CLAUDE.md](../CLAUDE.md) 了解详细的架构设计
- 查看 [scripts/README.md](scripts/README.md) 了解初始化脚本的详细说明
- 参考 OpenFGA 文档：https://openfga.dev/docs
