# OpenFGA 授权模型测试说明

## 测试文件

- **模型定义**: `src/openfga/authorization_model.fga`
- **测试文件**: `src/openfga/authorization_model.fga.yaml`

## 运行测试

```bash
# 使用 Makefile
make openfga-test

# 或直接使用 fga CLI
cd src/openfga
fga model test --tests authorization_model.fga.yaml
```

## 测试覆盖场景

### 1. 集群成员关系（4 个测试）

- ✅ **alice_is_prod_admin_and_member**: alice 是 prod 管理员，自动继承成员权限
- ✅ **bob_is_prod_member_not_admin**: bob 是 prod 普通成员，不是管理员
- ✅ **charlie_is_test_member**: charlie 是 test 环境成员
- ✅ **charlie_not_prod_member**: charlie 不是 prod 环境成员（权限隔离）

### 2. 主机访问权限 - 非限制模式（4 个测试）

非限制模式：用户有 `can_access` 权限，可以在主机上执行所有命令。

- ✅ **alice_can_access_all_prod_hosts**: alice 可以访问 prod 环境的所有主机（通配符 `*`）
- ✅ **bob_can_access_prod_web01**: bob 可以访问 prod 环境的 web-01 主机
- ✅ **bob_cannot_access_prod_web02**: bob 不能访问 prod 环境的 web-02 主机
- ✅ **charlie_cannot_access_prod_hosts**: charlie 不能访问 prod 环境的任何主机

### 3. 命令执行权限 - 限制模式（4 个测试）

限制模式：用户有 `can_execute` 权限，只能执行特定命令。

- ✅ **charlie_can_execute_ping_on_test_db01**: charlie 可以在 test/db-01 上执行 ping
- ✅ **charlie_cannot_execute_cmd_on_test_db01**: charlie 不能在 test/db-01 上执行 cmd
- ✅ **charlie_can_execute_cmd_on_all_test_hosts**: charlie 可以在 test 环境所有主机上执行 cmd（通配符）
- ✅ **charlie_cannot_execute_execute_on_test**: charlie 不能在 test 环境执行 execute 命令

### 4. 混合权限场景（1 个测试）

- ✅ **david_has_specific_command_permissions**: david 有多个特定命令权限，但不是所有命令

### 5. 跨集群权限隔离（1 个测试）

- ✅ **prod_and_test_isolation**: prod 和 test 环境的权限完全隔离

### 6. 权限模式区分（1 个测试）

- ✅ **access_vs_execute_permissions**: `can_access`（非限制）和 `can_execute`（限制）权限的区别

## 测试数据

### 用户和集群关系

| 用户    | 集群 | 角色   |
| ------- | ---- | ------ |
| alice   | prod | admin  |
| bob     | prod | member |
| charlie | test | member |
| david   | test | member |

### 主机访问权限（非限制模式）

| 用户  | 目标对象         | 权限       | 说明           |
| ----- | ---------------- | ---------- | -------------- |
| alice | target:prod/*    | can_access | 所有主机       |
| bob   | target:prod/web-01 | can_access | 特定主机       |

### 命令执行权限（限制模式）

| 用户    | 目标对象                    | 权限        | 说明                 |
| ------- | --------------------------- | ----------- | -------------------- |
| charlie | target_cmd:test/db-01/ping  | can_execute | 特定主机的特定命令   |
| charlie | target_cmd:test/*/cmd       | can_execute | 所有主机的特定命令   |
| david   | target_cmd:test/web-01/ping | can_execute | 特定主机的 ping 命令 |
| david   | target_cmd:test/web-01/execute | can_execute | 特定主机的 execute 命令 |

## 权限检查逻辑

### 非限制模式（can_access）

```
用户执行命令需要：
1. 是集群成员（member of cluster:xxx）
2. 有主机访问权限（can_access on target:xxx）
→ 可以执行该主机上的所有命令
```

### 限制模式（can_execute）

```
用户执行命令需要：
1. 是集群成员（member of cluster:xxx）
2. 有特定命令执行权限（can_execute on target_cmd:xxx）
→ 只能执行特定命令
```

### 优先级

- 如果用户有 `can_access` 权限，直接放行所有命令
- 如果用户没有 `can_access` 权限，检查 `can_execute` 权限
- 两者都没有，拒绝访问

## Object ID 格式

- **集群**: `cluster:<name>`
  - 示例: `cluster:prod`, `cluster:test`

- **主机**: `target:<cluster>/<hostname>`
  - 示例: `target:prod/web-01`, `target:prod/*`

- **命令**: `target_cmd:<cluster>/<hostname>/<command>`
  - 示例: `target_cmd:test/db-01/ping`, `target_cmd:test/*/cmd`

## 通配符支持

- `target:prod/*` - prod 环境的所有主机
- `target_cmd:test/*/ping` - test 环境所有主机的 ping 命令

**注意**: OpenFGA 不会自动推断通配符权限。例如，`target:prod/*` 的权限不会自动应用到 `target:prod/web-01`。应用层需要在权限检查时处理通配符逻辑。

## 测试结果

```
# Test Summary #
Tests 15/15 passing
Checks 27/27 passing
```

所有测试通过，模型定义正确！

## 持续集成

可以将测试添加到 CI/CD 流程中：

```yaml
# .github/workflows/test.yml
- name: Test OpenFGA Model
  run: make openfga-test
```

## 相关文档

- [OpenFGA 模型设计](./OPENFGA_DESIGN.md)
- [快速开始指南](./QUICKSTART.md)
- [OpenFGA 官方文档](https://openfga.dev/docs)
