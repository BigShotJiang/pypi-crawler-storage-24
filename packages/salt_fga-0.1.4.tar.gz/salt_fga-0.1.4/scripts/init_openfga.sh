#!/bin/bash

# OpenFGA 初始化脚本
# 功能：创建 store 和 authorization model，并更新配置文件

set -e  # 遇到错误立即退出

# 配置
OPENFGA_API_URL="${OPENFGA_API_URL:-http://localhost:8080}"
CONFIG_DIR="$HOME/.config/salt"
CONFIG_FILE="$CONFIG_DIR/openfga.json"
MODEL_FILE="$(dirname "$0")/../src/openfga/authorization_model.fga"

# 颜色输出
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

echo_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

echo_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查 fga CLI 是否安装
if ! command -v fga &> /dev/null; then
    echo_error "fga CLI 未安装"
    echo_info "请访问 https://github.com/openfga/cli 安装"
    echo_info "macOS: brew install fga"
    exit 1
fi

# 检查 jq 是否安装
if ! command -v jq &> /dev/null; then
    echo_error "jq 未安装"
    echo_info "macOS: brew install jq"
    exit 1
fi

# 检查 OpenFGA 服务是否运行
echo_info "检查 OpenFGA 服务状态..."
if ! curl -s -f "$OPENFGA_API_URL/healthz" > /dev/null; then
    echo_error "OpenFGA 服务未运行"
    echo_info "请先启动服务: docker-compose up -d"
    exit 1
fi
echo_info "OpenFGA 服务运行正常"

# 检查模型文件是否存在
if [ ! -f "$MODEL_FILE" ]; then
    echo_error "模型文件不存在: $MODEL_FILE"
    exit 1
fi

# 创建配置目录
mkdir -p "$CONFIG_DIR"

# 创建 Store
echo_info "创建 OpenFGA Store..."
STORE_RESPONSE=$(fga store create --name "salt-authorization" --api-url "$OPENFGA_API_URL")
STORE_ID=$(echo "$STORE_RESPONSE" | jq -r '.id // .store.id')

if [ -z "$STORE_ID" ] || [ "$STORE_ID" = "null" ]; then
    echo_error "创建 Store 失败"
    echo "$STORE_RESPONSE"
    exit 1
fi
echo_info "Store 创建成功: $STORE_ID"

# 创建 Authorization Model
echo_info "创建 Authorization Model..."
MODEL_RESPONSE=$(fga model write \
    --store-id "$STORE_ID" \
    --file "$MODEL_FILE" \
    --api-url "$OPENFGA_API_URL")

MODEL_ID=$(echo "$MODEL_RESPONSE" | jq -r '.authorization_model_id')

if [ -z "$MODEL_ID" ] || [ "$MODEL_ID" = "null" ]; then
    echo_error "创建 Authorization Model 失败"
    echo "$MODEL_RESPONSE"
    exit 1
fi
echo_info "Authorization Model 创建成功: $MODEL_ID"

# 更新配置文件
echo_info "更新配置文件: $CONFIG_FILE"
cat > "$CONFIG_FILE" <<EOF
{
  "api_url": "$OPENFGA_API_URL",
  "store_id": "$STORE_ID",
  "authorization_model_id": "$MODEL_ID"
}
EOF

echo_info "配置文件已更新"

# 显示配置信息
echo ""
echo_info "=========================================="
echo_info "OpenFGA 初始化完成！"
echo_info "=========================================="
echo_info "API URL: $OPENFGA_API_URL"
echo_info "Store ID: $STORE_ID"
echo_info "Model ID: $MODEL_ID"
echo_info "配置文件: $CONFIG_FILE"
echo ""
echo_info "下一步："
echo_info "1. 设置用户身份环境变量（COPAW_USER_ID, COPAW_USERNAME 等）"
echo_info "2. 使用 fga CLI 配置权限关系"
echo_info "   示例: fga tuple write --store-id $STORE_ID \\"
echo_info "         '[{\"user\":\"user:alice\",\"relation\":\"member\",\"object\":\"cluster:prod\"}]'"
echo ""
