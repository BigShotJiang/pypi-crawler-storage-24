# Scripts 目录

这个目录包含用于项目管理和初始化的脚本。

## init_openfga.sh

OpenFGA 初始化脚本，用于自动创建 store 和 authorization model。

### 功能

- 检查 OpenFGA 服务状态
- 创建 OpenFGA Store
- 从 `src/openfga/authorization_model.fga` 创建 Authorization Model
- 自动更新配置文件 `~/.config/salt/openfga.json`

### 前置条件

1. **安装 fga CLI**
   ```bash
   # macOS
   brew install fga

   # 其他平台
   # 参考: https://github.com/openfga/cli
   ```

2. **安装 jq**
   ```bash
   # macOS
   brew install jq
   ```

3. **启动 OpenFGA 服务**
   ```bash
   docker-compose up -d
   ```

### 使用方法

```bash
# 使用默认配置（http://localhost:8080）
./scripts/init_openfga.sh

# 使用自定义 API URL
OPENFGA_API_URL=http://custom-host:8080 ./scripts/init_openfga.sh
```

### 输出

脚本会输出以下信息：
- Store ID
- Authorization Model ID
- 配置文件路径

配置文件格式：
```json
{
  "api_url": "http://localhost:8080",
  "store_id": "01KKG8ZJTJ387C5X97RXEDEY2E",
  "authorization_model_id": "01KKG8ZJW7QFX5M40PJ0HK59E4"
}
```

### 下一步

初始化完成后，使用 fga CLI 配置权限关系：

```bash
# 设置用户身份环境变量
export COPAW_USER_ID=alice
export COPAW_USERNAME=alice
export COPAW_SESSION_ID=web:alice
export COPAW_CHANNEL=web

# 添加用户到集群
fga tuple write --store-id <store_id> \
  '[{"user":"user:alice","relation":"member","object":"cluster:prod"}]'

# 授予主机访问权限
fga tuple write --store-id <store_id> \
  '[{"user":"user:alice","relation":"can_access","object":"target:prod/web-01"}]'

# 查看用户信息
salt-fga user info

# 测试命令执行
salt-fga -c prod ping --tgt web-01
```

### 故障排查

**问题：fga CLI 未安装**
```bash
brew install fga
```

**问题：OpenFGA 服务未运行**
```bash
docker-compose up -d
# 等待服务启动
sleep 5
curl http://localhost:8080/healthz
```

**问题：模型文件不存在**
确保在项目根目录运行脚本，或者检查 `src/openfga/authorization_model.fga` 文件是否存在。

### 重新初始化

如果需要重新初始化（例如修改了模型定义）：

```bash
# 1. 删除旧配置
rm ~/.config/salt/openfga.json

# 2. 重新运行初始化脚本
./scripts/init_openfga.sh

# 3. 重新配置权限
fga tuple write --store-id <store_id> \
  '[{"user":"user:alice","relation":"member","object":"cluster:prod"}]'
```

注意：重新初始化会创建新的 store 和 model，之前的权限数据将丢失。
