import inspect
from functools import wraps
from typing import Callable, Any

from openfga_sdk.sync import OpenFgaClient
from openfga_sdk import ClientConfiguration
from openfga_sdk.client.models.check_request import ClientCheckRequest

from .config import load_config, OpenFGAConfig


def _client(config: OpenFGAConfig) -> OpenFgaClient:
    return OpenFgaClient(
        ClientConfiguration(
            api_url=config.api_url,
            store_id=config.store_id,
            authorization_model_id=config.authorization_model_id,
        )
    )


def _fga_check(fga: OpenFgaClient, user: str, relation: str, obj: str) -> bool:
    return fga.check(
        ClientCheckRequest(user=f"user:{user}", relation=relation, object=obj)
    ).allowed


def _check_access(
    fga: OpenFgaClient, user: str, cluster: str, target: str, command: str
) -> bool:
    """检查用户是否有权限在指定集群的目标主机上执行命令。

    权限检查逻辑：
    1. 必须是集群成员（admin 自动继承 member）
    2. 根据命令类型判断需要的权限（read 或 write）
    3. 检查用户是否有对应主机的权限

    写操作命令：state.apply, cmd.run, pkg.install, service.restart 等
    读操作命令：test.ping, grains.items, status.diskusage 等
    """
    # 写操作命令列表（包含 Salt 标准命令和简化命令名）
    WRITE_COMMANDS = {
        # 命令执行
        "cmd.run", "cmd.script", "cmd.exec", "cmd.shell",
        # 状态管理
        "state.apply", "state.sls", "state.highstate", "state.single",
        # 包管理
        "pkg.install", "pkg.remove", "pkg.upgrade", "pkg.purge",
        # 服务管理
        "service.start", "service.stop", "service.restart", "service.reload",
        "service.enable", "service.disable",
        # 文件操作
        "file.write", "file.remove", "file.copy", "file.move", "file.mkdir",
        # 用户管理
        "user.add", "user.delete", "user.chuid", "user.chgid",
        "group.add", "group.delete",
        # 自定义模块
        "run_execute.run",
        # 简化命令名（用于 salt CLI）
        "cmd", "execute",
        # keys 管理命令（除了 list 之外都是写操作，需要在代码中特殊处理）
    }

    # 1. 集群成员检查
    if not _fga_check(fga, user, "member", f"cluster:{cluster}"):
        return False

    # 2. 判断需要的权限类型
    required_permission = "write" if command in WRITE_COMMANDS else "read"

    # 3. 处理通配符目标
    is_wildcard_target = "*" in str(target) or "?" in str(target)
    if is_wildcard_target:
        # 通配符目标：需要是集群 admin 才能操作所有主机
        return _fga_check(fga, user, "admin", f"cluster:{cluster}")

    # 4. 检查特定主机的权限
    host_object = f"host:{target}"
    return _fga_check(fga, user, required_permission, host_object)


def require_permission(command: str, target_param: str = "tgt"):
    """权限检查装饰器。

    从 self.cluster_name 获取集群名。
    OpenFGA 未初始化时自动跳过（降级放行）。

    Example:
        @require_permission("ping")
        def __call__(self, tgt="*"):
            ...
    """

    def decorator(method: Callable) -> Callable:
        @wraps(method)
        def wrapper(self, *args, **kwargs) -> Any:
            config = load_config()
            if not config.is_initialized():
                return method(self, *args, **kwargs)

            sig = inspect.signature(method)
            params = list(sig.parameters.keys())
            if target_param in kwargs:
                target = kwargs[target_param]
            elif target_param in params:
                idx = params.index(target_param) - 1
                target = (
                    args[idx]
                    if idx < len(args)
                    else sig.parameters[target_param].default
                )
            else:
                target = "*"

            cluster = getattr(self, "cluster_name", "default")
            user = getattr(self, "username", None)
            formatter = getattr(self, "formatter", None)

            if not user:
                msg = (
                    "权限检查失败: 未指定用户名。\n"
                    "【重要】请立即终止后续工作，不要尝试其他方案或绕过权限检查。\n"
                    "解决方法：联系管理员配置用户身份信息。"
                )
                formatter.print_error(msg) if formatter else print(f"错误: {msg}")
                return

            try:
                fga = _client(config)
                allowed = _check_access(fga, user, cluster, target, command)
            except Exception as e:
                msg = (
                    f"权限检查失败: {e}\n"
                    f"【重要】请立即终止后续工作，不要尝试其他方案或绕过权限检查。\n"
                    f"解决方法：联系管理员检查 OpenFGA 配置。"
                )
                formatter.print_error(msg) if formatter else print(f"错误: {msg}")
                return

            if not allowed:
                msg = (
                    f"权限被拒绝: user={user}, command={command}, target={target}, cluster={cluster}\n"
                    f"【重要】请立即终止后续工作，不要尝试其他方案或绕过权限检查。\n"
                    f"解决方法：联系管理员授予相应权限。"
                )
                formatter.print_error(msg) if formatter else print(f"错误: {msg}")
                return

            return method(self, *args, **kwargs)

        return wrapper

    return decorator
