"""CLI 入口 - 原生 Salt 命令格式"""

import os
import sys
import argparse

from .auth import TokenManager
from .client import SaltAPIClient
from .config import ConfigManager
from .formatter import OutputFormatter
from .executor import CommandExecutor


def _resolve_user() -> str:
    """从环境变量获取当前用户 ID。

    Returns:
        user_id 字符串，未设置时返回 None。
    """
    return os.environ.get("COPAW_USER_ID")


class SaltCLI:
    """Salt CLI 主类 - 原生 Salt 命令格式"""

    def __init__(self, cluster: str = None, raw: bool = False):
        """初始化 CLI。

        Args:
            cluster: 环境名称（-c/--cluster）。
            raw: 是否使用原始输出（--raw）。
        """
        try:
            user = _resolve_user()
        except Exception as e:
            print(f"错误: 获取用户身份失败: {e}", file=sys.stderr)
            sys.exit(1)

        self.config_manager = ConfigManager()
        self.config_manager.ensure_config_dir()

        try:
            self.cluster_config = self.config_manager.get_cluster(cluster)
        except Exception as e:
            print(f"错误: {e}", file=sys.stderr)
            sys.exit(1)

        cluster_name = self.cluster_config.name

        self.token_manager = TokenManager(self.config_manager.config_dir)
        self.client = SaltAPIClient(self.cluster_config, self.token_manager)
        self.formatter = OutputFormatter(raw=raw)
        self.username = user

        # 创建统一的命令执行器
        self.executor = CommandExecutor(
            self.client, self.formatter, cluster_name, user
        )


def main():
    """CLI 入口函数"""
    try:
        # 创建参数解析器
        parser = argparse.ArgumentParser(
            prog="salt-fga",
            description="Salt CLI with OpenFGA authorization",
            epilog="示例: salt-fga 'minion-01' test.ping",
        )

        # 全局选项
        parser.add_argument(
            "-c", "--cluster", help="集群名称", default=None
        )
        parser.add_argument(
            "--raw", action="store_true", help="原始 JSON 输出"
        )

        # 位置参数（原生 Salt 格式）
        parser.add_argument("target", help="目标主机（支持通配符）")
        parser.add_argument("function", help="Salt 函数（如 test.ping, cmd.run）")
        parser.add_argument("args", nargs="*", help="函数参数")

        args = parser.parse_args()

        # 初始化 CLI
        cli = SaltCLI(args.cluster, args.raw)

        # 执行命令
        cli.executor.execute(args.target, args.function, args.args)

    except KeyboardInterrupt:
        print("\n操作已取消", file=sys.stderr)
        sys.exit(130)
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
