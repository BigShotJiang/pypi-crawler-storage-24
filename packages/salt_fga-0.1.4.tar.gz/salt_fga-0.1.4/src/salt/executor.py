"""统一的命令执行器 - 处理任意 Salt 函数"""

from openfga_sdk.sync import OpenFgaClient
from openfga_sdk import ClientConfiguration
from openfga_sdk.client.models.check_request import ClientCheckRequest

from openfga.config import load_config

from .client import SaltAPIClient
from .formatter import OutputFormatter


class CommandExecutor:
    """统一的命令执行器，支持任意 Salt 模块函数。

    Attributes:
        client: Salt API 客户端。
        formatter: 输出格式化器。
        cluster_name: 集群名称。
        username: 当前用户名。
    """

    def __init__(
        self,
        client: SaltAPIClient,
        formatter: OutputFormatter,
        cluster_name: str = "default",
        username: str = None,
    ):
        self.client = client
        self.formatter = formatter
        self.cluster_name = cluster_name
        self.username = username

    def execute(self, target: str, function: str, args: list = None):
        """执行任意 Salt 命令。

        Args:
            target: 目标主机（支持通配符）。
            function: Salt 函数名（如 test.ping, cmd.run）。
            args: 函数参数列表。

        Raises:
            Exception: API 调用失败时抛出。
        """
        # 权限检查
        if not self._check_permission(target, function):
            return

        # 执行命令
        try:
            result = self.client.execute(
                client="local", tgt=target, fun=function, arg=args if args else None
            )
            self.formatter.print_result(result)
        except Exception as e:
            self.formatter.print_error(str(e))
            raise

    def _check_permission(self, target: str, function: str) -> bool:
        """检查用户是否有权限执行指定命令。

        Args:
            target: 目标主机。
            function: Salt 函数名。

        Returns:
            是否有权限。
        """
        # 检查 OpenFGA 是否初始化
        config = load_config()
        if not config.is_initialized():
            return True

        # 检查用户名
        if not self.username:
            self.formatter.print_error(
                "权限检查失败: 未指定用户名。\n"
                "【重要】请立即终止后续工作，不要尝试其他方案或绕过权限检查。\n"
                "解决方法：联系管理员配置用户身份信息。"
            )
            return False

        try:
            # 创建 OpenFGA 客户端
            fga = OpenFgaClient(
                ClientConfiguration(
                    api_url=config.api_url,
                    store_id=config.store_id,
                    authorization_model_id=config.authorization_model_id,
                )
            )

            # 执行权限检查
            from openfga.checker import _check_access

            allowed = _check_access(
                fga, self.username, self.cluster_name, target, function
            )

            if not allowed:
                self.formatter.print_error(
                    f"权限被拒绝: user={self.username}, command={function}, "
                    f"target={target}, cluster={self.cluster_name}\n"
                    f"【重要】请立即终止后续工作，不要尝试其他方案或绕过权限检查。\n"
                    f"解决方法：联系管理员授予相应权限。"
                )
                return False

            return True

        except Exception as e:
            self.formatter.print_error(
                f"权限检查失败: {e}\n"
                f"【重要】请立即终止后续工作，不要尝试其他方案或绕过权限检查。\n"
                f"解决方法：联系管理员检查 OpenFGA 配置。"
            )
            return False
