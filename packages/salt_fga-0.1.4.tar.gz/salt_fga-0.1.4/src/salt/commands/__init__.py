"""Salt CLI 子命令模块"""
