def get_message_content(msg):
    """
    Extracts content from a message object, handling 'fragments' or 'content'.
    Returns list of content parts with formatting hints.
    """
    if not msg:
        return []

    content_parts = []
    
    # Process Fragments (DeepSeek specific)
    fragments = msg.get('fragments', [])
    if fragments:
        for frag in fragments:
            f_type = frag.get('type')
            f_content = frag.get('content', '')
            
            if not f_content and f_type != 'SEARCH': 
                continue

            if f_type == 'THINK':
                if f_content.strip():
                    content_parts.append({
                        'type': 'thinking',
                        'text': f_content
                    })
            elif f_type in ['RESPONSE', 'TEXT', 'REQUEST']:
                content_parts.append({
                    'type': 'text',
                    'text': f_content
                })
            elif f_type == 'SEARCH':
                # Optional: could include search results
                pass
                
    # Fallback to direct content key
    elif 'content' in msg:
        c = msg['content']
        if isinstance(c, str):
            content_parts.append({'type': 'text', 'text': c})
        elif isinstance(c, dict) and 'parts' in c:
            text = "".join([str(p) for p in c['parts']])
            content_parts.append({'type': 'text', 'text': text})
            
    return content_parts

def infer_role(msg, explicit_role="Unknown"):
    """
    Infers role based on fragments if explicit role is generic.
    """
    fragments = msg.get('fragments', [])
    for frag in fragments:
        f_type = frag.get('type')
        if f_type == 'REQUEST':
            return "User"
        if f_type in ['THINK', 'RESPONSE']:
            return "Model"
    
    return explicit_role

def traverse_mapping(mapping, root_id):
    """
    Traverses the conversation tree linearly, preferring the LAST child 
    (most recent/regenerated version).
    """
    messages = []
    
    # Start from root
    root_node = mapping.get(root_id)
    if not root_node:
        return messages
        
    # DeepSeek root usually has null message, jumping to first child(ren)
    children = root_node.get('children', [])
    if not children:
        return messages
        
    # FIX: Always take the last child to get the latest branch
    current_node_id = children[-1]
    
    while current_node_id:
        node = mapping.get(current_node_id)
        if not node:
            break
        
        msg_obj = node.get('message')
        if msg_obj:
            role = "Unknown"
            
            # 1. Determine Role
            if 'author' in msg_obj and 'role' in msg_obj['author']:
                 r = msg_obj['author']['role']
                 if r == 'user': role = "User"
                 elif r == 'assistant': role = "Model"
            
            if role == "Unknown":
                role = infer_role(msg_obj, role)
                
            # 2. Extract Content
            parts = get_message_content(msg_obj)
            
            if parts:
                messages.append({
                    'role': role,
                    'parts': parts
                })
        
        # Traverse to next node
        children = node.get('children', [])
        if children:
            # FIX: Always take the last child
            current_node_id = children[-1]
        else:
            current_node_id = None
            
    return messages
