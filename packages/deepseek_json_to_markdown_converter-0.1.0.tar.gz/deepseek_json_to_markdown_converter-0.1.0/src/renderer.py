import re


ALLOWED_TEMPLATE_VARS = {
    "title",
    "conversion_created_time",
    "conversion_export_time",
    "content",
}


def render_content(messages):
    """Render only conversation body content used by template placeholder {content}."""
    lines = []

    for msg in messages:
        role = msg['role']
        parts = msg['parts']

        if role == 'User':
            lines.append("## 👤 User")
        elif role == 'Model':
            lines.append("### 🐳 Deepseek")
        else:
            lines.append(f"## {role}")

        lines.append("")

        for part in parts:
            text = part['text'].strip()
            if not text:
                continue

            if part['type'] == 'thinking':
                lines.append("> Thinking:")
                for line in text.split('\n'):
                    lines.append(f"> {line}")
                lines.append("")
            else:
                lines.append(text)
                lines.append("")

        if role == 'Model':
            lines.append("---")
            lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def find_template_placeholders(template_text):
    """Find placeholders in format {name}."""
    return set(re.findall(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}", template_text))


def validate_template_placeholders(template_text):
    """Raise ValueError when template contains unsupported placeholders."""
    placeholders = find_template_placeholders(template_text)
    unknown = placeholders - ALLOWED_TEMPLATE_VARS
    if unknown:
        unknown_str = ", ".join(sorted(unknown))
        raise ValueError(f"Unknown template placeholders: {unknown_str}")


def render_with_template(template_text, variables):
    """Render final markdown using validated placeholders and provided variables."""
    validate_template_placeholders(template_text)

    rendered = template_text
    for key in ALLOWED_TEMPLATE_VARS:
        value = variables.get(key, "")
        rendered = rendered.replace(f"{{{key}}}", value)
    return rendered
