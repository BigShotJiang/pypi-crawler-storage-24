import re
from datetime import datetime

def format_timestamp(ts_str):
    """
    Parses ISO timestamp string to datetime object.
    Example: 2026-02-09T15:17:15.356000+08:00
    """
    try:
        if not ts_str:
            return None
        dt = datetime.fromisoformat(ts_str)
        return dt
    except Exception:
        return None


def to_template_datetime(dt_obj):
    """
    Format datetime for template placeholders.
    Output format: YYYY-MM-DDTHH:MM:SS
    """
    if not dt_obj:
        return ""
    return dt_obj.strftime('%Y-%m-%dT%H:%M:%S')

def sanitize_filename(filename, date_obj=None):
    """
    Sanitizes title to filesystem-safe filename.
    Prepends YYYYMMDD- if date_obj provided.
    """
    if not filename:
        filename = "Untitled"
        
    # Remove illegal characters
    clean_name = re.sub(r'[\/\\\:\*\?\"\<\>\|\n\r]', '_', filename)
    clean_name = clean_name.strip()
    
    # Compress multiple underscores
    clean_name = re.sub(r'_+', '_', clean_name)
    
    # Add date prefix if available
    if date_obj:
        date_prefix = date_obj.strftime('%Y%m%d')
        return f"~{date_prefix}-{clean_name}"
    
    return clean_name
