#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use test_support::helpers::*;
use test_support::*;

// ─────────────────────────────────────────────────────────────────────────────
//  084 — Triple cantilever 3D (three orthogonal beams)
//
//  N1(0,0,0) ── beam1(X) ── N2(1,0,0) ── beam2(Y) ── N3(1,1,0) ── beam3(Z) ── N4(1,1,1)
//                                                                                  ↑
//                                                                        F = −1000 N in Y
//
//  Support:   N1 fully fixed
//  Checks:    Force & moment equilibrium at fixed support
// ─────────────────────────────────────────────────────────────────────────────

fn test_084_case(strategy: RigidStrategy, lu: LengthUnit, fu: ForceUnit, pu: PressureUnit) {
    let ctx = make_ctx("084_3d_triple", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let arm_si = 1.0_f64;
    let force_si = 1000.0_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let fl = f * l;
    let arm = arm_si / l;
    let force_u = force_si / f;

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, arm, 0.0, 0.0, None);
    let n3 = make_node(3, arm, arm, 0.0, None);
    let n4 = make_node(4, arm, arm, arm, None);
    add_member_set(
        &mut model,
        1,
        vec![
            make_beam_member(1, &n1, &n2, sec),
            make_beam_member(2, &n2, &n3, sec),
            make_beam_member(3, &n3, &n4, sec),
        ],
    );

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 4, force_u, (0.0, -1.0, 0.0));

    model.normalize_units();
    model
        .solve_for_load_case(lc)
        .unwrap_or_else(|e| panic!("{ctx}: {e}"));
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx = r.reaction_nodes.get(&1).unwrap().nodal_forces;

    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    // Force equilibrium
    assert_close_ctx(&ctx, 0.0, rx.fx, tol_f, "Rx.fx");
    assert_close_ctx(&ctx, force_u, rx.fy, tol_f, "Rx.fy");
    assert_close_ctx(&ctx, 0.0, rx.fz, tol_f, "Rx.fz");

    // Moment equilibrium about origin
    // r × F = (1,1,1) × (0,−1000,0) = (1000, 0, −1000)
    // → reaction moments = (−1000, 0, 1000) N·m
    assert_close_ctx(&ctx, -1000.0 / fl, rx.mx, tol_m, "Rx.mx");
    assert_close_ctx(&ctx, 0.0, rx.my, tol_m, "Rx.my");
    assert_close_ctx(&ctx, 1000.0 / fl, rx.mz, tol_m, "Rx.mz");
}

#[test]
fn test_084_triple_cantilever_3d_equilibrium() {
    for s in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_084_case(s, lu, fu, pu);
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  084 — Second-order (Updated Lagrangian)
//
//  Same geometry but solved with P-Δ + UL T-updates.
//  Global force equilibrium must still hold; moment equilibrium is checked
//  against reference values from SkyCiv (~1347 N·m for Mx due to large rotation).
// ─────────────────────────────────────────────────────────────────────────────
#[test]
fn test_084_second_order_equilibrium() {
    let strategy = RigidStrategy::RigidMember;
    let lu = LengthUnit::M;
    let fu = ForceUnit::N;
    let pu = PressureUnit::Pa;
    let ctx = make_ctx("084_second_order", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 1.0, 0.0, 0.0, None);
    let n3 = make_node(3, 1.0, 1.0, 0.0, None);
    let n4 = make_node(4, 1.0, 1.0, 1.0, None);
    add_member_set(
        &mut model,
        1,
        vec![
            make_beam_member(1, &n1, &n2, sec),
            make_beam_member(2, &n2, &n3, sec),
            make_beam_member(3, &n3, &n4, sec),
        ],
    );

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 4, 1000.0, (0.0, -1.0, 0.0));

    model.normalize_units();
    model
        .solve_for_load_case_second_order(lc, 30)
        .unwrap_or_else(|e| panic!("{ctx}: {e}"));
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx = r.reaction_nodes.get(&1).unwrap().nodal_forces;

    // Print displacements for diagnostic purposes
    for nid in [2u32, 3, 4] {
        if let Some(nd) = r.displacement_nodes.get(&nid) {
            println!(
                "  N{nid}: dx={:.4} dy={:.4} dz={:.4}  rx={:.4} ry={:.4} rz={:.4}",
                nd.dx * 1e3, nd.dy * 1e3, nd.dz * 1e3,
                nd.rx * 1e3, nd.ry * 1e3, nd.rz * 1e3,
            );
        }
    }

    println!("=== 084 Second-Order Reactions at N1 ===");
    println!("  fx = {:.6}", rx.fx);
    println!("  fy = {:.6}", rx.fy);
    println!("  fz = {:.6}", rx.fz);
    println!("  mx = {:.6}", rx.mx);
    println!("  my = {:.6}", rx.my);
    println!("  mz = {:.6}", rx.mz);

    // Force equilibrium (K_elastic + T_def tolerance: tiny off-axis from deformed frame)
    let tol_f_so = tol_force_user(0.2, 1.0);
    assert_close_ctx(&ctx, 0.0, rx.fx, tol_f_so, "Rx.fx");
    assert_close_ctx(&ctx, 1000.0, rx.fy, tol_f_so, "Rx.fy");
    assert_close_ctx(&ctx, 0.0, rx.fz, tol_f_so, "Rx.fz");

    // Moment equilibrium: Mx = −1000 N·m, Mz = +1000 N·m (F×arm statics).
    // With stiff IPE-180 section and 1 m arms, deflection ≈ 1.6 mm,
    // so second-order shift is negligible and both moments ≈ first-order.
    let tol_m_so = tol_moment_user(50.0, 1.0, 1.0);
    assert_close_ctx(&ctx, -1000.0, rx.mx, tol_m_so, "Rx.mx");
    assert_close_ctx(&ctx, 1000.0, rx.mz, tol_m_so, "Rx.mz");
}
