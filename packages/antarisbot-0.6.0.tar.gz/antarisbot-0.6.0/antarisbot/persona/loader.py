from pathlib import Path
from typing import Optional

DEFAULT_CONFIG_DIR = Path.home() / ".antarisbot"

DEFAULT_SOUL = """You are Antaris — a personal AI assistant built to remember, protect, and adapt.

You have persistent memory. You remember past conversations.
You have safety built in. You can't be easily manipulated.
You improve over time. The more we talk, the better you get.

Be helpful, be direct, and have genuine personality. Skip the filler phrases.
You're not a customer service bot. You're a capable partner."""

DEFAULT_USER = """# About You

I'm learning about you. Tell me about yourself and I'll remember."""


class PersonaLoader:
    def __init__(self, config_dir: Optional[str] = None):
        self.config_dir = Path(config_dir or DEFAULT_CONFIG_DIR)
        self.soul_path = self.config_dir / "SOUL.md"
        self.user_path = self.config_dir / "USER.md"

    def load_soul(self) -> str:
        """Load SOUL.md or return default."""
        if self.soul_path.exists():
            return self.soul_path.read_text().strip()
        return DEFAULT_SOUL

    def load_user(self) -> Optional[str]:
        """Load USER.md if it exists and has content."""
        if not self.user_path.exists():
            return None
        content = self.user_path.read_text().strip()
        # Don't inject placeholder/empty USER.md
        if content == DEFAULT_USER.strip() or len(content) < 50:
            return None
        return content

    def build_system_prompt(self, memories: Optional[list] = None) -> str:
        """
        Build full system prompt from persona + memories.
        Order: SOUL.md → USER.md context → recalled memories
        """
        parts = [self.load_soul()]

        user_context = self.load_user()
        if user_context:
            parts.append(f"\n---\n## About the person I'm talking to:\n{user_context}")

        if memories and len(memories) > 0:
            memory_text = "\n".join(f"- {m}" for m in memories[:15])
            parts.append(f"\n---\n## Relevant memories from past conversations:\n{memory_text}")

        return "\n".join(parts)

    def update_user_context(self, new_info: str):
        """Append new user information to USER.md."""
        self.user_path.parent.mkdir(parents=True, exist_ok=True)
        current = self.user_path.read_text() if self.user_path.exists() else ""
        if new_info not in current:
            with open(self.user_path, "a") as f:
                f.write(f"\n{new_info}\n")

    def reload(self):
        """Force re-read persona files on next call (for hot-reload)."""
        # Files are read on each call already — hot reload is free
        pass
