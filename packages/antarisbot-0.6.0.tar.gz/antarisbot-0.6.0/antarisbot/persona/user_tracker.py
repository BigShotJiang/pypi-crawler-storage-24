"""
antarisbot/persona/user_tracker.py

Detects user facts in messages and updates USER.md silently.
The persona loader already reads USER.md into the system prompt,
so learned facts automatically become part of context.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_SECTION_HEADER = "## Learned Facts"


class UserTracker:
    """Detects user facts in messages and updates USER.md."""

    FACT_PATTERNS: list[tuple[str, str]] = [
        (r"my name is (\w+)", "Name: {0}"),
        (r"call me (\w+)", "Preferred name: {0}"),
        (r"i(?:'m| am) (\w+)(?:\s|$)", "Goes by: {0}"),
        (r"i(?:'m| am) a[n]? (.+?)(?:\.|,|$)", "Occupation/role: {0}"),
        (r"i work (?:at|for) (.+?)(?:\.|,|$)", "Works at/for: {0}"),
        (r"i live in (.+?)(?:\.|,|$)", "Lives in: {0}"),
        (r"i(?:'m| am) (\d+) years? old", "Age: {0}"),
        (r"my (?!name\b)(.+?) is (.+?)(?:\.|,|$)", "My {0}: {1}"),
        (r"i (?:like|love) (.+?)(?:\.|,|$)", "Likes/loves: {0}"),
        (r"i hate (.+?)(?:\.|,|$)", "Dislikes: {0}"),
        (r"i prefer (.+?)(?:\.|,|$)", "Prefers: {0}"),
        (r"i use (.+?)(?:\.|,|$)", "Uses: {0}"),
    ]

    _compiled: Optional[list[tuple[re.Pattern, str]]] = None

    def __init__(self, config_dir: str):
        self.user_md_path = Path(config_dir) / "USER.md"

    @classmethod
    def _get_compiled(cls) -> list[tuple[re.Pattern, str]]:
        if cls._compiled is None:
            cls._compiled = [
                (re.compile(p, re.IGNORECASE | re.MULTILINE), tmpl)
                for p, tmpl in cls.FACT_PATTERNS
            ]
        return cls._compiled

    @staticmethod
    def _format_fact(template: str, groups: tuple) -> str:
        try:
            clean_groups = [g.strip() if g else "" for g in groups]
            return template.format(*clean_groups)
        except (IndexError, KeyError):
            return ""

    def _read_existing(self) -> str:
        if self.user_md_path.exists():
            return self.user_md_path.read_text(encoding="utf-8")
        return ""

    def extract_facts(self, message: str) -> list[str]:
        """Return list of fact strings detected in message."""
        facts: list[str] = []
        for pattern, template in self._get_compiled():
            for match in pattern.finditer(message):
                groups = match.groups()
                fact = self._format_fact(template, groups)
                fact = fact.strip().rstrip(".,;")
                if fact and len(fact) > 3:
                    facts.append(fact)
        return facts

    def update_user_md(self, facts: list[str]) -> bool:
        """
        Append new facts to USER.md under '## Learned Facts'.

        Deduplicates, creates file if needed.
        Returns True if file was updated.
        """
        if not facts:
            return False

        existing_content = self._read_existing()
        new_facts = [f for f in facts if f not in existing_content]

        if not new_facts:
            return False

        self.user_md_path.parent.mkdir(parents=True, exist_ok=True)
        section_idx = existing_content.find(_SECTION_HEADER)

        if section_idx == -1:
            lines_to_add = f"\n\n{_SECTION_HEADER}\n" + "\n".join(
                f"- {f}" for f in new_facts
            ) + "\n"
            with open(self.user_md_path, "a", encoding="utf-8") as fh:
                fh.write(lines_to_add)
        else:
            after_section = existing_content[section_idx + len(_SECTION_HEADER):]
            next_heading = re.search(r"\n##\s", after_section)
            if next_heading:
                insert_pos = section_idx + len(_SECTION_HEADER) + next_heading.start()
                insert_text = "\n" + "\n".join(f"- {f}" for f in new_facts)
                new_content = (
                    existing_content[:insert_pos]
                    + insert_text
                    + existing_content[insert_pos:]
                )
            else:
                insert_text = "\n" + "\n".join(f"- {f}" for f in new_facts) + "\n"
                new_content = existing_content.rstrip() + insert_text
            self.user_md_path.write_text(new_content, encoding="utf-8")

        logger.debug("UserTracker: wrote %d fact(s) to %s", len(new_facts), self.user_md_path)
        return True

    def process_message(self, message: str) -> list[str]:
        """
        Convenience: extract_facts + update_user_md if any found.
        Returns list of facts written (empty if none or all duplicates).
        """
        facts = self.extract_facts(message)
        if not facts:
            return []
        updated = self.update_user_md(facts)
        return facts if updated else []
