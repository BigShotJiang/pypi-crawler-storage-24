"""Google Gemini provider — Phase 4 implementation."""
from .base import LLMProvider, Message, LLMResponse
from typing import Optional


class GoogleProvider(LLMProvider):
    """Google Gemini provider. Full implementation coming in Phase 4."""

    MODELS = ["gemini-1.5-pro", "gemini-1.5-flash", "gemini-2.0-flash"]

    async def complete(self, messages, system, model=None, max_tokens=4096, temperature=0.7):
        raise NotImplementedError("Google Gemini provider coming in Phase 4")

    def estimate_tokens(self, text):
        return max(1, len(text) // 4)
