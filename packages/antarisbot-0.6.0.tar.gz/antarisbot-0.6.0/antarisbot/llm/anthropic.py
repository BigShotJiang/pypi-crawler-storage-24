import httpx
import asyncio
from typing import Optional
from .base import LLMProvider, Message, LLMResponse

# Pricing per million tokens (approximate, for cost tracking)
MODEL_PRICING = {
    "claude-opus-4-6": {"input": 15.0, "output": 75.0},
    "claude-sonnet-4-6": {"input": 3.0, "output": 15.0},
    "claude-sonnet-4-20250514": {"input": 3.0, "output": 15.0},
    "claude-haiku-4-5-20251001": {"input": 0.80, "output": 4.0},
}


class AnthropicProvider(LLMProvider):
    BASE_URL = "https://api.anthropic.com/v1"
    API_VERSION = "2023-06-01"

    async def complete(
        self,
        messages: list[Message],
        system: str,
        model: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7
    ) -> LLMResponse:
        use_model = model or self.model

        payload = {
            "model": use_model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": system,
            "messages": [{"role": m.role, "content": m.content} for m in messages if m.role != "system"]
        }

        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": self.API_VERSION,
            "content-type": "application/json"
        }

        async with httpx.AsyncClient(timeout=60.0) as client:
            try:
                response = await client.post(
                    f"{self.BASE_URL}/messages",
                    json=payload,
                    headers=headers
                )
                response.raise_for_status()
                data = response.json()

                content = data["content"][0]["text"]
                usage = data.get("usage", {})
                input_tokens = usage.get("input_tokens", 0)
                output_tokens = usage.get("output_tokens", 0)

                # Calculate cost
                pricing = MODEL_PRICING.get(use_model, {"input": 3.0, "output": 15.0})
                cost = (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000

                return LLMResponse(
                    content=content,
                    model=use_model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    cost_usd=cost
                )

            except httpx.HTTPStatusError as e:
                if e.response.status_code == 401:
                    raise ValueError("Invalid Anthropic API key")
                elif e.response.status_code == 429:
                    raise RuntimeError("Anthropic rate limit exceeded")
                else:
                    raise RuntimeError(f"Anthropic API error {e.response.status_code}: {e.response.text}")
            except httpx.TimeoutException:
                raise RuntimeError("Anthropic API request timed out")

    def estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)
