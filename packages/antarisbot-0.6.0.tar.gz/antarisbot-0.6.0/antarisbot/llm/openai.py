"""OpenAI provider — Phase 4 (direct HTTP, no SDK)."""

import httpx
from typing import Optional
from .base import LLMProvider, Message, LLMResponse

# Pricing per million tokens (approximate, for cost tracking)
MODEL_PRICING = {
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "gpt-4-turbo": {"input": 10.00, "output": 30.00},
    "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
    "o1": {"input": 15.00, "output": 60.00},
    "o1-mini": {"input": 3.00, "output": 12.00},
    "o3-mini": {"input": 1.10, "output": 4.40},
}


class OpenAIProvider(LLMProvider):
    """OpenAI provider — direct HTTP to api.openai.com, no SDK."""

    BASE_URL = "https://api.openai.com/v1"

    async def complete(
        self,
        messages: list[Message],
        system: str,
        model: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7
    ) -> LLMResponse:
        use_model = model or self.model

        # Build messages array: system first, then conversation messages (skip any role=system)
        openai_messages = []
        if system:
            openai_messages.append({"role": "system", "content": system})
        openai_messages.extend(
            {"role": m.role, "content": m.content}
            for m in messages
            if m.role != "system"
        )

        payload = {
            "model": use_model,
            "messages": openai_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        async with httpx.AsyncClient(timeout=60.0) as client:
            try:
                response = await client.post(
                    f"{self.BASE_URL}/chat/completions",
                    json=payload,
                    headers=headers,
                )

                if response.status_code == 401:
                    raise ValueError("Invalid OpenAI API key")
                if response.status_code == 429:
                    raise RuntimeError("OpenAI rate limit exceeded")
                if response.status_code == 400:
                    body = response.text
                    if "model_not_found" in body:
                        raise ValueError(f"Model not found: {use_model}")
                    raise RuntimeError(f"OpenAI API error 400: {body}")

                response.raise_for_status()
                data = response.json()

                content = data["choices"][0]["message"]["content"]
                usage = data.get("usage", {})
                input_tokens = usage.get("prompt_tokens", 0)
                output_tokens = usage.get("completion_tokens", 0)

                # Calculate cost
                pricing = MODEL_PRICING.get(use_model, {"input": 2.50, "output": 10.00})
                cost = (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000

                return LLMResponse(
                    content=content,
                    model=use_model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    cost_usd=cost,
                )

            except (ValueError, RuntimeError):
                raise
            except httpx.TimeoutException:
                raise RuntimeError("OpenAI API request timed out")
            except httpx.HTTPStatusError as e:
                raise RuntimeError(f"OpenAI API error {e.response.status_code}: {e.response.text}")

    def estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)
