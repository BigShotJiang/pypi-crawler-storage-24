from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class MigrationResult:
    success: bool
    source: str
    items_migrated: dict = field(default_factory=dict)
    # items_migrated e.g. {"soul": True, "user": True, "memories": 1247, "config": True}
    warnings: list = field(default_factory=list)
    errors: list = field(default_factory=list)

    def summary(self) -> str:
        lines = [f"Migration from {self.source}:"]
        for key, val in self.items_migrated.items():
            if isinstance(val, bool):
                status = "✅" if val else "⚠️  skipped"
                lines.append(f"  {status} {key}")
            else:
                lines.append(f"  ✅ {key}: {val}")
        if self.warnings:
            for w in self.warnings:
                lines.append(f"  ⚠️  {w}")
        if self.errors:
            for e in self.errors:
                lines.append(f"  ❌ {e}")
        return "\n".join(lines)


class MigrationSource(ABC):
    def __init__(self, source_path: str, dest_path: str, dry_run: bool = False):
        self.source_path = Path(source_path)
        self.dest_path = Path(dest_path)
        self.dry_run = dry_run

    @abstractmethod
    def detect(self) -> bool:
        """Return True if this source exists and looks valid at source_path."""
        pass

    @abstractmethod
    def migrate(self) -> MigrationResult:
        """Perform the migration. Return result."""
        pass

    def _write(self, dest: Path, content: str):
        """Write to dest, respecting dry_run."""
        if self.dry_run:
            print(f"  [dry-run] would write: {dest}")
            return
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content)
