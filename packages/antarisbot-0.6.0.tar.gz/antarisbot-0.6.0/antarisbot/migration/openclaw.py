import json
import shutil
from pathlib import Path
from .base import MigrationSource, MigrationResult


class OpenClawMigration(MigrationSource):
    """
    Migrates from OpenClaw workspace to AntarisBot.

    Maps:
    - SOUL.md → ~/.antarisbot/SOUL.md (persona)
    - USER.md → ~/.antarisbot/USER.md (user context)
    - memory/ files → ~/.antarisbot/memory/ (memory store)
    - IDENTITY.md → appended to SOUL.md
    - Channel config (discord token from openclaw.json if accessible)
    """

    def detect(self) -> bool:
        return (self.source_path / "SOUL.md").exists() or \
               (self.source_path / "AGENTS.md").exists()

    def migrate(self) -> MigrationResult:
        result = MigrationResult(success=True, source="OpenClaw")
        dest = self.dest_path

        # 1. SOUL.md
        soul_src = self.source_path / "SOUL.md"
        if soul_src.exists():
            content = soul_src.read_text()
            # Append IDENTITY.md if it exists
            identity_src = self.source_path / "IDENTITY.md"
            if identity_src.exists():
                content += f"\n\n---\n## Identity\n{identity_src.read_text()}"
            self._write(dest / "SOUL.md", content)
            result.items_migrated["soul"] = True
        else:
            result.items_migrated["soul"] = False
            result.warnings.append("No SOUL.md found in source")

        # 2. USER.md
        user_src = self.source_path / "USER.md"
        if user_src.exists():
            self._write(dest / "USER.md", user_src.read_text())
            result.items_migrated["user"] = True
        else:
            result.items_migrated["user"] = False

        # 3. Memory files
        memory_src = self.source_path / "memory"
        memory_dest = dest / "memory" / "migrated-user"
        if memory_src.exists():
            count = self._migrate_memory(memory_src, memory_dest)
            result.items_migrated["memories"] = count
        else:
            result.items_migrated["memories"] = 0
            result.warnings.append("No memory/ directory found in source")

        # 4. Try to extract Discord token from openclaw config
        openclaw_config = self.source_path.parent / ".openclaw" / "openclaw.json"
        if not openclaw_config.exists():
            # try common locations
            for candidate in [
                Path.home() / ".openclaw" / "openclaw.json",
                self.source_path / ".." / "openclaw.json",
            ]:
                if candidate.exists():
                    openclaw_config = candidate
                    break

        discord_token = None
        if openclaw_config.exists():
            try:
                cfg = json.loads(openclaw_config.read_text())
                # Common paths in openclaw config
                discord_token = (
                    cfg.get("channels", {}).get("discord", {}).get("token") or
                    cfg.get("discord", {}).get("token")
                )
            except Exception:
                pass

        if discord_token:
            result.items_migrated["discord_token"] = "found (add to ~/.antarisbot/config.json manually)"
            result.warnings.append(
                f"Discord token found in openclaw config. Add it to your AntarisBot config:\n"
                f"  antaris config set discord-token <token>"
            )
        else:
            result.items_migrated["discord_token"] = False

        return result

    def _migrate_memory(self, src: Path, dest: Path) -> int:
        """Copy memory files. Returns count of files migrated."""
        if self.dry_run:
            files = list(src.glob("**/*"))
            count = len([f for f in files if f.is_file()])
            print(f"  [dry-run] would migrate {count} memory files")
            return count

        dest.mkdir(parents=True, exist_ok=True)
        count = 0
        for f in src.glob("**/*"):
            if f.is_file():
                rel = f.relative_to(src)
                target = dest / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(f, target)
                count += 1
        return count
