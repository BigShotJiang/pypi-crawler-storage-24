import json
from pathlib import Path
from .base import MigrationSource, MigrationResult


class CustomMigration(MigrationSource):
    """
    Import from a custom JSON export file.

    Expected format:
    {
        "soul": "# Bot name\\n...",
        "user": "# About user\\n...",
        "memories": ["memory 1", "memory 2", ...]
    }
    """

    def detect(self) -> bool:
        config_path = Path(self.source_path)
        if config_path.is_file():
            try:
                data = json.loads(config_path.read_text())
                return "memories" in data or "soul" in data
            except Exception:
                return False
        return False

    def migrate(self) -> MigrationResult:
        result = MigrationResult(success=True, source="custom")

        try:
            data = json.loads(Path(self.source_path).read_text())
        except Exception as e:
            result.success = False
            result.errors.append(f"Could not parse import file: {e}")
            return result

        dest = self.dest_path

        if "soul" in data:
            self._write(dest / "SOUL.md", data["soul"])
            result.items_migrated["soul"] = True

        if "user" in data:
            self._write(dest / "USER.md", data["user"])
            result.items_migrated["user"] = True

        if "memories" in data:
            memories = data["memories"]
            memory_file = dest / "memory" / "migrated-user" / "import.md"
            content = "\n\n".join(str(m) for m in memories)
            self._write(memory_file, content)
            result.items_migrated["memories"] = len(memories)

        return result
