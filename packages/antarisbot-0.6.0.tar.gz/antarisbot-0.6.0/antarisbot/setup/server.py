"""
AntarisBot Setup Server.

Browser-based setup wizard using only stdlib — zero external dependencies.
Runs on localhost:7474 and serves a single-page HTML wizard.
"""

import json
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

from antarisbot.core.config import Config, DEFAULT_CONFIG_PATH, DEFAULT_CONFIG_DIR

# ---------------------------------------------------------------------------
# Embedded HTML wizard (no separate file — keeps packaging simple)
# ---------------------------------------------------------------------------

WIZARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>AntarisBot Setup</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#fff;color:#111;min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:0 16px 48px}
  /* progress bar */
  #progress-wrap{width:100%;max-width:560px;padding:28px 0 20px}
  #progress-track{background:#e5e7eb;border-radius:99px;height:6px;overflow:hidden}
  #progress-fill{background:#6366f1;height:6px;border-radius:99px;transition:width 0.4s ease}
  /* card */
  .card{width:100%;max-width:560px;padding:36px 40px;animation:fadeIn 0.25s ease}
  @keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
  h1{font-size:1.75rem;font-weight:700;margin-bottom:10px;line-height:1.2}
  h2{font-size:1.3rem;font-weight:700;margin-bottom:8px}
  .subtitle{color:#6b7280;font-size:0.95rem;line-height:1.6;margin-bottom:28px}
  /* radio cards */
  .radio-group{display:flex;flex-direction:column;gap:12px;margin-bottom:24px}
  .radio-card{display:flex;align-items:flex-start;gap:14px;border:2px solid #e5e7eb;border-radius:12px;padding:16px 18px;cursor:pointer;transition:border-color 0.15s,background 0.15s}
  .radio-card:hover{border-color:#a5b4fc}
  .radio-card.selected{border-color:#6366f1;background:#f5f3ff}
  .radio-card input{margin-top:3px;accent-color:#6366f1;flex-shrink:0}
  .radio-label{font-weight:600;font-size:0.95rem}
  .radio-desc{font-size:0.82rem;color:#6b7280;margin-top:2px}
  .badge{display:inline-block;background:#fef3c7;color:#92400e;font-size:0.7rem;font-weight:700;padding:1px 6px;border-radius:99px;margin-left:6px;vertical-align:middle}
  .badge-rec{background:#ede9fe;color:#5b21b6}
  /* inputs */
  .field{margin-bottom:20px}
  .field label{display:block;font-weight:600;font-size:0.9rem;margin-bottom:7px;color:#374151}
  .field input[type=text],.field input[type=password]{width:100%;padding:10px 14px;border:2px solid #e5e7eb;border-radius:8px;font-size:0.95rem;outline:none;transition:border-color 0.15s}
  .field input:focus{border-color:#6366f1}
  /* verify row */
  .verify-row{display:flex;gap:10px;align-items:center;margin-top:8px}
  .verify-row input{flex:1}
  /* buttons */
  .btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:11px 26px;border-radius:9px;font-size:0.95rem;font-weight:600;cursor:pointer;border:none;transition:background 0.15s,opacity 0.15s}
  .btn-primary{background:#6366f1;color:#fff}
  .btn-primary:hover{background:#4f46e5}
  .btn-primary:disabled{opacity:0.55;cursor:not-allowed}
  .btn-secondary{background:#f3f4f6;color:#374151;border:1px solid #e5e7eb}
  .btn-secondary:hover{background:#e5e7eb}
  .btn-sm{padding:8px 16px;font-size:0.85rem}
  .btn-row{display:flex;gap:12px;flex-wrap:wrap;margin-top:8px}
  /* status inline */
  .token-status{font-size:0.85rem;min-width:60px;font-weight:500}
  .token-status.ok{color:#059669}
  .token-status.err{color:#dc2626}
  .token-status.checking{color:#6b7280}
  /* instructions */
  .instr{background:#f8f8ff;border-left:3px solid #6366f1;border-radius:0 8px 8px 0;padding:14px 18px;margin-bottom:20px;font-size:0.88rem;line-height:1.65;color:#374151}
  .instr strong{color:#111}
  /* success */
  .success-wrap{text-align:center;padding:20px 0}
  .success-icon{font-size:3.5rem;margin-bottom:18px}
  /* divider */
  .divider{height:1px;background:#e5e7eb;margin:20px 0}
  /* responsive */
  @media(max-width:480px){.card{padding:24px 18px}.btn{width:100%}.btn-row{flex-direction:column}}
</style>
</head>
<body>

<div id="progress-wrap">
  <div id="progress-track"><div id="progress-fill" style="width:16%"></div></div>
</div>

<div id="app" class="card"><!-- rendered by JS --></div>

<script>
const STEPS = 6;
let state = {
  step: 1,
  provider: 'anthropic',
  apiKey: '',
  apiKeyValid: null,
  channel: 'telegram',
  telegramToken: '',
  telegramValid: null,
  discordToken: '',
  discordValid: null,
  slackBotToken: '',
  slackAppToken: '',
  slackValid: null,
  botName: 'Altaris',
  launched: false,
};

function setProgress(step) {
  const pct = Math.round((step / STEPS) * 100);
  document.getElementById('progress-fill').style.width = pct + '%';
}

function render() {
  setProgress(state.step);
  const app = document.getElementById('app');
  switch(state.step) {
    case 1: app.innerHTML = stepWelcome(); break;
    case 2: app.innerHTML = stepProvider(); break;
    case 3: app.innerHTML = stepChannel(); break;
    case 4: app.innerHTML = stepChannelSetup(); break;
    case 5: app.innerHTML = stepBotName(); break;
    case 6: app.innerHTML = stepDone(); break;
  }
  bindEvents();
}

// ── Step 1: Welcome ──────────────────────────────────────────────────────

function stepWelcome() {
  return `
    <h1>Let's set up your<br>AI assistant</h1>
    <p class="subtitle">AntarisBot connects your favourite AI to Telegram, Discord, or your terminal.<br>
    This wizard takes about 3 minutes and requires no technical knowledge.</p>
    <div class="btn-row">
      <button class="btn btn-primary" id="btn-start">Get Started →</button>
    </div>`;
}

// ── Step 2: Choose AI provider ───────────────────────────────────────────

function stepProvider() {
  const anthropicSel = state.provider === 'anthropic' ? 'selected' : '';
  const openaiSel    = state.provider === 'openai'    ? 'selected' : '';
  const statusHtml = tokenStatusHtml(state.apiKeyValid);
  return `
    <h2>Choose your AI provider</h2>
    <p class="subtitle">This determines which AI model powers your bot.</p>
    <div class="radio-group" id="provider-group">
      <label class="radio-card ${anthropicSel}" data-val="anthropic">
        <input type="radio" name="provider" value="anthropic" ${state.provider==='anthropic'?'checked':''}/>
        <div>
          <div class="radio-label">Anthropic Claude <span class="badge badge-rec">Recommended</span></div>
          <div class="radio-desc">claude-sonnet — best reasoning &amp; personality</div>
        </div>
      </label>
      <label class="radio-card ${openaiSel}" data-val="openai">
        <input type="radio" name="provider" value="openai" ${state.provider==='openai'?'checked':''}/>
        <div>
          <div class="radio-label">OpenAI GPT</div>
          <div class="radio-desc">gpt-4o-mini — widely known, good for most tasks</div>
        </div>
      </label>
    </div>
    <div class="field">
      <label>${state.provider === 'anthropic' ? 'Anthropic' : 'OpenAI'} API Key</label>
      <div class="verify-row">
        <input type="password" id="api-key-input" value="${esc(state.apiKey)}" placeholder="sk-..." autocomplete="off"/>
        <button class="btn btn-secondary btn-sm" id="btn-verify-api">Verify</button>
        <span class="token-status ${statusClass(state.apiKeyValid)}" id="api-key-status">${statusHtml}</span>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="btn-back">← Back</button>
      <button class="btn btn-primary" id="btn-next-provider" ${state.apiKeyValid !== true ? 'disabled' : ''}>Next →</button>
    </div>`;
}

// ── Step 3: Choose channel ───────────────────────────────────────────────

function stepChannel() {
  const sel = state.channel;
  return `
    <h2>Choose your channel</h2>
    <p class="subtitle">Where do you want to chat with your bot?</p>
    <div class="radio-group" id="channel-group">
      <label class="radio-card ${sel==='telegram'?'selected':''}" data-val="telegram">
        <input type="radio" name="channel" value="telegram" ${sel==='telegram'?'checked':''}/>
        <div>
          <div class="radio-label">Telegram <span class="badge">★ Easiest</span></div>
          <div class="radio-desc">Create a bot in 2 minutes with @BotFather — no server needed</div>
        </div>
      </label>
      <label class="radio-card ${sel==='discord'?'selected':''}" data-val="discord">
        <input type="radio" name="channel" value="discord" ${sel==='discord'?'checked':''}/>
        <div>
          <div class="radio-label">Discord</div>
          <div class="radio-desc">Add your bot to any Discord server</div>
        </div>
      </label>
      <label class="radio-card ${sel==='both'?'selected':''}" data-val="both">
        <input type="radio" name="channel" value="both" ${sel==='both'?'checked':''}/>
        <div>
          <div class="radio-label">Both</div>
          <div class="radio-desc">Telegram and Discord simultaneously</div>
        </div>
      </label>
      <label class="radio-card ${sel==='slack'?'selected':''}" data-val="slack">
        <input type="radio" name="channel" value="slack" ${sel==='slack'?'checked':''}/>
        <div>
          <div class="radio-label">Slack</div>
          <div class="radio-desc">Socket Mode — no public URL required, works behind any firewall</div>
        </div>
      </label>
      <label class="radio-card ${sel==='terminal'?'selected':''}" data-val="terminal">
        <input type="radio" name="channel" value="terminal" ${sel==='terminal'?'checked':''}/>
        <div>
          <div class="radio-label">Terminal only</div>
          <div class="radio-desc">Dev mode — chat in your terminal, no tokens needed</div>
        </div>
      </label>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="btn-back">← Back</button>
      <button class="btn btn-primary" id="btn-next-channel">Next →</button>
    </div>`;
}

// ── Step 4: Channel setup ────────────────────────────────────────────────

function stepChannelSetup() {
  const ch = state.channel;
  if (ch === 'terminal') {
    // skip — go straight to step 5
    state.step = 5;
    return stepBotName();
  }

  let html = `<h2>Set up your channel${ch==='both'?' connections':''}</h2>
    <p class="subtitle">Paste the token(s) below — we'll verify them before continuing.</p>`;

  if (ch === 'telegram' || ch === 'both') {
    const st = tokenStatusHtml(state.telegramValid);
    html += `
      <div class="instr" id="tg-instr-STEP4">
        <strong>Telegram</strong><br>
        1. Open Telegram and search for <strong>@BotFather</strong><br>
        2. Send <code>/newbot</code> and follow the prompts<br>
        3. Copy the token BotFather gives you and paste it below
      </div>
      <div class="field">
        <label>Telegram Bot Token</label>
        <div class="verify-row">
          <input type="password" id="tg-token-input" value="${esc(state.telegramToken)}" placeholder="123456789:ABCdef..." autocomplete="off"/>
          <button class="btn btn-secondary btn-sm" id="btn-verify-tg">Verify</button>
          <span class="token-status ${statusClass(state.telegramValid)}" id="tg-status">${st}</span>
        </div>
      </div>`;
  }

  if (ch === 'both') {
    html += `<div class="divider"></div>`;
  }

  if (ch === 'discord' || ch === 'both') {
    const st = tokenStatusHtml(state.discordValid);
    html += `
      <div class="instr" id="dc-instr-STEP4">
        <strong>Discord</strong><br>
        1. Go to <strong>discord.com/developers</strong> → New Application<br>
        2. Open the <strong>Bot</strong> tab → Reset Token → Copy token<br>
        3. Under <em>Privileged Gateway Intents</em>, enable <strong>Message Content Intent</strong><br>
        4. Paste the token below, then use OAuth2 → URL Generator to invite it to your server
      </div>
      <div class="field">
        <label>Discord Bot Token</label>
        <div class="verify-row">
          <input type="password" id="dc-token-input" value="${esc(state.discordToken)}" placeholder="MTI3..." autocomplete="off"/>
          <button class="btn btn-secondary btn-sm" id="btn-verify-dc">Verify</button>
          <span class="token-status ${statusClass(state.discordValid)}" id="dc-status">${st}</span>
        </div>
      </div>`;
  }

  if (ch === 'slack') {
    const st = tokenStatusHtml(state.slackValid);
    html += `
      <div class="instr" id="slack-instr-STEP4">
        <strong>Slack (Socket Mode)</strong><br>
        1. Go to <strong>api.slack.com/apps</strong> → Create New App → From scratch<br>
        2. Under <em>OAuth &amp; Permissions</em> → Bot Token Scopes: add <code>chat:write</code>, <code>users:read</code><br>
        3. Install the app to your workspace → copy the <strong>Bot User OAuth Token</strong> (xoxb-...)<br>
        4. Under <em>Socket Mode</em>, enable it → generate an <strong>App-Level Token</strong> (xapp-...) with <code>connections:write</code><br>
        5. Under <em>Event Subscriptions</em> → Subscribe to bot events: <code>message.channels</code>, <code>message.im</code>, <code>app_mention</code>
      </div>
      <div class="field">
        <label>Slack Bot Token (xoxb-...)</label>
        <div class="verify-row">
          <input type="password" id="slack-bot-input" value="${esc(state.slackBotToken)}" placeholder="xoxb-..." autocomplete="off"/>
          <button class="btn btn-secondary btn-sm" id="btn-verify-slack">Verify</button>
          <span class="token-status ${statusClass(state.slackValid)}" id="slack-status">${st}</span>
        </div>
      </div>
      <div class="field">
        <label>Slack App Token (xapp-...)</label>
        <input type="password" id="slack-app-input" value="${esc(state.slackAppToken)}" placeholder="xapp-..." autocomplete="off"/>
      </div>`;
  }

  const canProceed = canProceedChannelSetup();
  html += `
    <div class="btn-row">
      <button class="btn btn-secondary" id="btn-back">← Back</button>
      <button class="btn btn-primary" id="btn-next-ch-setup" ${canProceed?'':'disabled'}>Next →</button>
    </div>`;
  return html;
}

function canProceedChannelSetup() {
  const ch = state.channel;
  if (ch === 'telegram') return state.telegramValid === true;
  if (ch === 'discord')  return state.discordValid  === true;
  if (ch === 'both')     return state.telegramValid === true && state.discordValid === true;
  if (ch === 'slack')    return state.slackValid === true;
  return true;
}

// ── Step 5: Name your bot ────────────────────────────────────────────────

function stepBotName() {
  return `
    <h2>Name your bot</h2>
    <p class="subtitle">Give your assistant a name. It will introduce itself and develop its personality in your first conversation — this is called <em>awakening</em>.</p>
    <div class="field">
      <label>Bot name</label>
      <input type="text" id="bot-name-input" value="${esc(state.botName)}" placeholder="Altaris" maxlength="40"/>
    </div>
    <p class="subtitle" style="font-size:0.85rem;margin-top:-8px">Your bot will introduce itself and find its personality in your first conversation.</p>
    <div class="btn-row" style="margin-top:24px">
      <button class="btn btn-secondary" id="btn-back">← Back</button>
      <button class="btn btn-primary" id="btn-next-name">Next →</button>
    </div>`;
}

// ── Step 6: Done ─────────────────────────────────────────────────────────

function stepDone() {
  const chLabel = {telegram:'Telegram',discord:'Discord',both:'Telegram &amp; Discord',slack:'Slack',terminal:'terminal'}[state.channel] || state.channel;
  if (state.launched) {
    return `
      <div class="success-wrap">
        <div class="success-icon">🎉</div>
        <h2>You're all set!</h2>
        <p class="subtitle" style="margin-top:10px">Configuration saved. You can now close this window and start chatting with <strong>${esc(state.botName)}</strong>.<br><br>
        Run <code>antaris start</code> in your terminal if the bot isn't running yet.</p>
      </div>`;
  }
  return `
    <div class="success-wrap">
      <div class="success-icon">🤖</div>
      <h2>Your bot is ready</h2>
      <p class="subtitle" style="margin-top:10px">
        <strong>${esc(state.botName)}</strong> will start talking to you on <strong>${chLabel}</strong>.<br>
        Click Launch to save your configuration and start the bot.
      </p>
      <div class="btn-row" style="justify-content:center;margin-top:24px">
        <button class="btn btn-secondary" id="btn-back">← Back</button>
        <button class="btn btn-primary" id="btn-launch">🚀 Launch Bot</button>
      </div>
    </div>`;
}

// ── Helpers ───────────────────────────────────────────────────────────────

function esc(s) {
  return (s||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function statusClass(v) {
  if (v === true)  return 'ok';
  if (v === false) return 'err';
  return '';
}
function tokenStatusHtml(v) {
  if (v === true)  return '✅';
  if (v === false) return '❌';
  return '';
}

// ── Event binding ─────────────────────────────────────────────────────────

function bindEvents() {
  // Welcome
  const btnStart = document.getElementById('btn-start');
  if (btnStart) btnStart.addEventListener('click', () => { state.step = 2; render(); });

  // Back
  const btnBack = document.getElementById('btn-back');
  if (btnBack) btnBack.addEventListener('click', () => {
    if (state.step === 4 && state.channel === 'terminal') { state.step = 3; }
    else { state.step = Math.max(1, state.step - 1); }
    render();
  });

  // Provider radio cards
  document.querySelectorAll('#provider-group .radio-card').forEach(card => {
    card.addEventListener('click', () => {
      state.provider = card.dataset.val;
      state.apiKeyValid = null;
      render();
    });
  });

  // Channel radio cards
  document.querySelectorAll('#channel-group .radio-card').forEach(card => {
    card.addEventListener('click', () => {
      state.channel = card.dataset.val;
      render();
    });
  });

  // Verify API key
  const btnVerifyApi = document.getElementById('btn-verify-api');
  if (btnVerifyApi) {
    const input = document.getElementById('api-key-input');
    if (input) input.addEventListener('input', () => {
      state.apiKey = input.value;
      state.apiKeyValid = null;
      document.getElementById('btn-next-provider').disabled = true;
      document.getElementById('api-key-status').textContent = '';
      document.getElementById('api-key-status').className = 'token-status';
    });
    btnVerifyApi.addEventListener('click', async () => {
      state.apiKey = document.getElementById('api-key-input').value;
      const statusEl = document.getElementById('api-key-status');
      statusEl.textContent = '⏳';
      statusEl.className = 'token-status checking';
      btnVerifyApi.disabled = true;
      try {
        const res = await fetch('/api/validate-token', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({provider: state.provider, token: state.apiKey})
        });
        const data = await res.json();
        state.apiKeyValid = data.valid;
        statusEl.textContent = data.valid ? '✅' : ('❌ ' + (data.error || 'Invalid'));
        statusEl.className = 'token-status ' + (data.valid ? 'ok' : 'err');
        document.getElementById('btn-next-provider').disabled = !data.valid;
      } catch(e) {
        state.apiKeyValid = false;
        statusEl.textContent = '❌ Network error';
        statusEl.className = 'token-status err';
      }
      btnVerifyApi.disabled = false;
    });
  }

  // Next: provider
  const btnNextProvider = document.getElementById('btn-next-provider');
  if (btnNextProvider) btnNextProvider.addEventListener('click', () => { state.step = 3; render(); });

  // Next: channel
  const btnNextChannel = document.getElementById('btn-next-channel');
  if (btnNextChannel) btnNextChannel.addEventListener('click', () => {
    state.step = (state.channel === 'terminal') ? 5 : 4;
    render();
  });

  // Verify Telegram
  const btnVerifyTg = document.getElementById('btn-verify-tg');
  if (btnVerifyTg) {
    const inp = document.getElementById('tg-token-input');
    if (inp) inp.addEventListener('input', () => {
      state.telegramToken = inp.value;
      state.telegramValid = null;
      document.getElementById('tg-status').textContent = '';
      document.getElementById('btn-next-ch-setup').disabled = !canProceedChannelSetup();
    });
    btnVerifyTg.addEventListener('click', async () => {
      state.telegramToken = document.getElementById('tg-token-input').value;
      const statusEl = document.getElementById('tg-status');
      statusEl.textContent = '⏳';
      statusEl.className = 'token-status checking';
      btnVerifyTg.disabled = true;
      try {
        const res = await fetch('/api/validate-token', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({provider:'telegram', token: state.telegramToken})
        });
        const data = await res.json();
        state.telegramValid = data.valid;
        statusEl.textContent = data.valid ? '✅' : ('❌ ' + (data.error || 'Invalid'));
        statusEl.className = 'token-status ' + (data.valid ? 'ok' : 'err');
        document.getElementById('btn-next-ch-setup').disabled = !canProceedChannelSetup();
      } catch(e) {
        state.telegramValid = false;
        statusEl.textContent = '❌ Network error';
        statusEl.className = 'token-status err';
      }
      btnVerifyTg.disabled = false;
    });
  }

  // Verify Discord
  const btnVerifyDc = document.getElementById('btn-verify-dc');
  if (btnVerifyDc) {
    const inp = document.getElementById('dc-token-input');
    if (inp) inp.addEventListener('input', () => {
      state.discordToken = inp.value;
      state.discordValid = null;
      document.getElementById('dc-status').textContent = '';
      document.getElementById('btn-next-ch-setup').disabled = !canProceedChannelSetup();
    });
    btnVerifyDc.addEventListener('click', async () => {
      state.discordToken = document.getElementById('dc-token-input').value;
      const statusEl = document.getElementById('dc-status');
      statusEl.textContent = '⏳';
      statusEl.className = 'token-status checking';
      btnVerifyDc.disabled = true;
      try {
        const res = await fetch('/api/validate-token', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({provider:'discord', token: state.discordToken})
        });
        const data = await res.json();
        state.discordValid = data.valid;
        statusEl.textContent = data.valid ? '✅' : ('❌ ' + (data.error || 'Invalid'));
        statusEl.className = 'token-status ' + (data.valid ? 'ok' : 'err');
        document.getElementById('btn-next-ch-setup').disabled = !canProceedChannelSetup();
      } catch(e) {
        state.discordValid = false;
        statusEl.textContent = '❌ Network error';
        statusEl.className = 'token-status err';
      }
      btnVerifyDc.disabled = false;
    });
  }

  // Verify Slack
  const btnVerifySlack = document.getElementById('btn-verify-slack');
  if (btnVerifySlack) {
    const inpBot = document.getElementById('slack-bot-input');
    const inpApp = document.getElementById('slack-app-input');
    if (inpBot) inpBot.addEventListener('input', () => {
      state.slackBotToken = inpBot.value;
      state.slackValid = null;
      document.getElementById('slack-status').textContent = '';
      document.getElementById('btn-next-ch-setup').disabled = !canProceedChannelSetup();
    });
    if (inpApp) inpApp.addEventListener('input', () => {
      state.slackAppToken = inpApp.value;
    });
    btnVerifySlack.addEventListener('click', async () => {
      state.slackBotToken = document.getElementById('slack-bot-input').value;
      state.slackAppToken = (document.getElementById('slack-app-input') || {value:''}).value;
      const statusEl = document.getElementById('slack-status');
      statusEl.textContent = '⏳';
      statusEl.className = 'token-status checking';
      btnVerifySlack.disabled = true;
      try {
        const res = await fetch('/api/validate-token', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({provider:'slack', token: state.slackBotToken})
        });
        const data = await res.json();
        state.slackValid = data.valid;
        statusEl.textContent = data.valid ? '✅' : ('❌ ' + (data.error || 'Invalid'));
        statusEl.className = 'token-status ' + (data.valid ? 'ok' : 'err');
        document.getElementById('btn-next-ch-setup').disabled = !canProceedChannelSetup();
      } catch(e) {
        state.slackValid = false;
        statusEl.textContent = '❌ Network error';
        statusEl.className = 'token-status err';
      }
      btnVerifySlack.disabled = false;
    });
  }

  // Next: channel setup
  const btnNextChSetup = document.getElementById('btn-next-ch-setup');
  if (btnNextChSetup) btnNextChSetup.addEventListener('click', () => { state.step = 5; render(); });

  // Bot name input
  const botNameInput = document.getElementById('bot-name-input');
  if (botNameInput) botNameInput.addEventListener('input', () => { state.botName = botNameInput.value; });

  // Next: bot name
  const btnNextName = document.getElementById('btn-next-name');
  if (btnNextName) btnNextName.addEventListener('click', () => {
    state.botName = (document.getElementById('bot-name-input').value || 'Altaris').trim();
    state.step = 6; render();
  });

  // Launch
  const btnLaunch = document.getElementById('btn-launch');
  if (btnLaunch) btnLaunch.addEventListener('click', async () => {
    btnLaunch.disabled = true;
    btnLaunch.textContent = 'Saving...';
    try {
      const payload = {
        bot_name: state.botName,
        provider: state.provider,
        api_key: state.apiKey,
        channel: state.channel,
        telegram_token: state.telegramToken,
        discord_token: state.discordToken,
        slack_bot_token: state.slackBotToken,
        slack_app_token: state.slackAppToken,
      };
      const res = await fetch('/api/setup', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.ok) {
        state.launched = true;
        render();
      } else {
        btnLaunch.disabled = false;
        btnLaunch.textContent = '🚀 Launch Bot';
        alert('Save failed: ' + (data.error || 'Unknown error'));
      }
    } catch(e) {
      btnLaunch.disabled = false;
      btnLaunch.textContent = '🚀 Launch Bot';
      alert('Network error: ' + e.message);
    }
  });
}

// Boot
render();
</script>
</body>
</html>
"""


# ---------------------------------------------------------------------------
# Request handler
# ---------------------------------------------------------------------------

class _WizardHandler(BaseHTTPRequestHandler):
    """HTTP request handler for the setup wizard."""

    # Injected by SetupServer
    server_ref: "SetupServer" = None  # type: ignore[assignment]

    def log_message(self, fmt, *args):  # silence default access log
        pass

    # ── GET ──────────────────────────────────────────────────────────────

    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self._send_html(WIZARD_HTML)
        elif self.path == "/api/status":
            self._handle_status()
        else:
            self._send_json({"error": "not found"}, status=404)

    # ── POST ─────────────────────────────────────────────────────────────

    def do_POST(self):
        if self.path == "/api/setup":
            self._handle_setup()
        elif self.path == "/api/validate-token":
            self._handle_validate_token()
        else:
            self._send_json({"error": "not found"}, status=404)

    # ── Handlers ──────────────────────────────────────────────────────────

    def _handle_status(self):
        cfg = Config.load()
        if cfg and cfg.api_key:
            channels = []
            if cfg.discord_enabled:
                channels.append("discord")
            if cfg.telegram_enabled:
                channels.append("telegram")
            self._send_json({"configured": True, "channels": channels})
        else:
            self._send_json({"configured": False, "channels": []})

    def _handle_setup(self):
        body = self._read_json_body()
        if body is None:
            self._send_json({"ok": False, "error": "invalid JSON"}, status=400)
            return

        cfg = Config.load() or Config()

        cfg.bot_name = body.get("bot_name", cfg.bot_name) or "Altaris"
        cfg.provider_name = body.get("provider", "anthropic")
        cfg.api_key = body.get("api_key", "")

        if cfg.provider_name == "openai":
            cfg.model = "gpt-4o-mini"
            cfg.fallback_model = "gpt-3.5-turbo"
        else:
            cfg.model = "claude-sonnet-4-20250514"
            cfg.fallback_model = "claude-haiku-4-5-20251001"

        channel = body.get("channel", "terminal")
        telegram_token = body.get("telegram_token", "")
        discord_token = body.get("discord_token", "")
        slack_bot_token = body.get("slack_bot_token", "")
        slack_app_token = body.get("slack_app_token", "")

        cfg.telegram_enabled = channel in ("telegram", "both") and bool(telegram_token)
        cfg.telegram_token = telegram_token if cfg.telegram_enabled else ""

        cfg.discord_enabled = channel in ("discord", "both") and bool(discord_token)
        cfg.discord_token = discord_token if cfg.discord_enabled else ""

        cfg.slack_enabled = channel == "slack" and bool(slack_bot_token) and bool(slack_app_token)
        cfg.slack_bot_token = slack_bot_token if cfg.slack_enabled else ""
        cfg.slack_app_token = slack_app_token if cfg.slack_enabled else ""

        try:
            cfg.save()
            # Signal wizard completion
            if self.server_ref:
                self.server_ref._setup_complete = True
                self.server_ref._config = cfg
            self._send_json({"ok": True})
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)}, status=500)

    def _handle_validate_token(self):
        body = self._read_json_body()
        if body is None:
            self._send_json({"valid": False, "error": "invalid JSON"}, status=400)
            return

        provider = body.get("provider", "")
        token = body.get("token", "").strip()

        if not token:
            self._send_json({"valid": False, "error": "token is empty"})
            return

        valid, error = _validate_token(provider, token)
        self._send_json({"valid": valid, "error": error or ""})

    # ── Utilities ─────────────────────────────────────────────────────────

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            return None

    def _send_html(self, html: str):
        encoded = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def _send_json(self, data: dict, status: int = 200):
        encoded = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)


# ---------------------------------------------------------------------------
# Token validation helpers
# ---------------------------------------------------------------------------

def _validate_token(provider: str, token: str) -> tuple[bool, Optional[str]]:
    """
    Validate a token against the provider's API.
    Returns (valid: bool, error: str | None).
    """
    try:
        if provider == "telegram":
            return _validate_telegram(token)
        elif provider == "discord":
            return _validate_discord(token)
        elif provider == "anthropic":
            return _validate_anthropic(token)
        elif provider == "openai":
            return _validate_openai(token)
        elif provider == "slack":
            return _validate_slack(token)
        else:
            return False, f"Unknown provider: {provider}"
    except Exception as exc:
        return False, str(exc)


def _validate_telegram(token: str) -> tuple[bool, Optional[str]]:
    url = f"https://api.telegram.org/bot{token}/getMe"
    try:
        with urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read())
            if data.get("ok"):
                return True, None
            return False, data.get("description", "Invalid token")
    except HTTPError as e:
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_discord(token: str) -> tuple[bool, Optional[str]]:
    url = "https://discord.com/api/v10/users/@me"
    req = Request(url, headers={"Authorization": f"Bot {token}"})
    try:
        with urlopen(req, timeout=10) as resp:
            return True, None
    except HTTPError as e:
        if e.code == 401:
            return False, "Unauthorized — check your token"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_anthropic(token: str) -> tuple[bool, Optional[str]]:
    url = "https://api.anthropic.com/v1/messages"
    payload = json.dumps({
        "model": "claude-haiku-4-5-20251001",
        "max_tokens": 1,
        "messages": [{"role": "user", "content": "hi"}]
    }).encode("utf-8")
    req = Request(
        url,
        data=payload,
        method="POST",
        headers={
            "x-api-key": token,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
    )
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 401:
            return False, "Unauthorized — check your API key"
        if e.code in (400, 529):
            # 400 = bad request but auth passed; 529 = overloaded (auth OK)
            return True, None
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_openai(token: str) -> tuple[bool, Optional[str]]:
    url = "https://api.openai.com/v1/models"
    req = Request(url, headers={"Authorization": f"Bearer {token}"})
    try:
        with urlopen(req, timeout=10):
            return True, None
    except HTTPError as e:
        if e.code == 401:
            return False, "Unauthorized — check your API key"
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


def _validate_slack(token: str) -> tuple[bool, Optional[str]]:
    """Validate a Slack bot token (xoxb-...) via auth.test."""
    url = "https://slack.com/api/auth.test"
    req = Request(url, headers={"Authorization": f"Bearer {token}"})
    try:
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            if data.get("ok"):
                return True, None
            return False, data.get("error", "Invalid token")
    except HTTPError as e:
        return False, f"HTTP {e.code}"
    except URLError as e:
        return False, str(e.reason)


# ---------------------------------------------------------------------------
# SetupServer
# ---------------------------------------------------------------------------

class SetupServer:
    """
    HTTP server for the browser-based setup wizard.

    Usage::

        server = SetupServer()
        server.start(open_browser=True)
        # ... wait for setup ...
        server.stop()
        cfg = server.config          # Config after setup, or None
        done = server.setup_complete # True once wizard POSTed /api/setup
    """

    HOST = "localhost"
    PORT = 7474

    def __init__(self):
        self._httpd: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._setup_complete: bool = False
        self._config: Optional[Config] = None

    # ── Public API ────────────────────────────────────────────────────────

    @property
    def setup_complete(self) -> bool:
        return self._setup_complete

    @property
    def config(self) -> Optional[Config]:
        return self._config

    def start(self, open_browser: bool = True) -> None:
        """Start the setup server in a background thread."""

        # Build handler class with a reference back to this server instance
        server_ref = self

        class BoundHandler(_WizardHandler):
            pass

        BoundHandler.server_ref = server_ref

        self._httpd = HTTPServer((self.HOST, self.PORT), BoundHandler)
        self._thread = threading.Thread(
            target=self._httpd.serve_forever,
            daemon=True,
            name="setup-wizard-server",
        )
        self._thread.start()

        if open_browser:
            webbrowser.open(f"http://{self.HOST}:{self.PORT}")

    def stop(self) -> None:
        """Shut down the server."""
        if self._httpd:
            self._httpd.shutdown()
            self._httpd = None
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None
