"""AntarisBot tool middleware — approval prompts and audit logging for locked mode."""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import logging.handlers
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional


class ToolMiddleware:
    """Wraps tool invocations with per-mode approval logic and audit logging.

    Modes:
        - ``open``:      No restrictions; tool runs immediately.
        - ``sandboxed``: Prints tool name to stdout; tool runs immediately.
        - ``locked``:    Interactive ``[y/N]`` prompt; approved calls are
                         logged (with SHA-256 of result) to a rotating audit
                         log file.

    Args:
        mode: Security mode — ``"open"``, ``"sandboxed"``, or ``"locked"``.
        audit_log_path: Path to the audit log file.  Required when
            ``mode="locked"``; ignored otherwise.
    """

    def __init__(self, mode: str, audit_log_path: Optional[str] = None) -> None:
        self.mode = mode
        self._audit_logger: Optional[logging.Logger] = None

        if mode == "locked" and audit_log_path:
            self._audit_logger = self._setup_audit_logger(audit_log_path)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def approve_and_run(
        self,
        tool_name: str,
        args: dict,
        fn: Optional[Callable],
        *fn_args: Any,
        **fn_kwargs: Any,
    ) -> Any:
        """Gate a tool call through mode-appropriate approval logic.

        Args:
            tool_name: Human-readable name of the tool (e.g. ``"read_file"``).
            args: Dict of arguments for display / audit purposes.
            fn: Async callable to invoke, or ``None`` (dry-run / capability check).
            *fn_args: Positional arguments forwarded to *fn*.
            **fn_kwargs: Keyword arguments forwarded to *fn*.

        Returns:
            The return value of *fn*, ``True`` (if fn is None in open mode),
            or ``None`` if the call was rejected in locked mode.
        """
        if self.mode == "open":
            if fn is not None:
                return await fn(*fn_args, **fn_kwargs)
            return True

        if self.mode == "sandboxed":
            print(f"   [tool] {tool_name}", flush=True)
            if fn is not None:
                return await fn(*fn_args, **fn_kwargs)
            return True

        # locked
        prompt = (
            f"\n🔐 [locked] Approve: {tool_name}"
            f"({self._fmt_args(args)})? [y/N] "
        )
        loop = asyncio.get_event_loop()
        answer: str = await loop.run_in_executor(None, input, prompt)

        if answer.strip().lower() != "y":
            self._log_audit(
                tool_name=tool_name,
                args=args,
                approved=False,
                response_hash=None,
                status="rejected",
            )
            return None

        # Approved — execute
        result = None
        if fn is not None:
            result = await fn(*fn_args, **fn_kwargs)
        response_hash = hashlib.sha256(str(result).encode("utf-8")).hexdigest()
        self._log_audit(
            tool_name=tool_name,
            args=args,
            approved=True,
            response_hash=response_hash,
            status="success",
        )
        return result

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _fmt_args(self, args: dict) -> str:
        """Return a truncated repr of *args* (max 80 chars)."""
        raw = repr(args)
        if len(raw) <= 80:
            return raw
        return raw[:77] + "..."

    def _log_audit(
        self,
        tool_name: str,
        args: dict,
        approved: bool,
        response_hash: Optional[str] = None,
        status: str = "success",
    ) -> None:
        """Write a JSON line to the audit logger (locked mode only)."""
        if self._audit_logger is None:
            return

        record = {
            "ts": datetime.now(tz=timezone.utc).isoformat(),
            "tool": tool_name,
            "args_repr": self._fmt_args(args),
            "approved": approved,
            "status": status,
            "response_sha256": response_hash,
        }
        self._audit_logger.info(json.dumps(record))

    # ------------------------------------------------------------------
    # Logger setup
    # ------------------------------------------------------------------

    @staticmethod
    def _setup_audit_logger(log_path: str) -> logging.Logger:
        """Create a dedicated logger writing JSON lines to a rotating file."""
        logger = logging.getLogger("antaris.audit")
        logger.setLevel(logging.INFO)
        logger.propagate = False  # don't bubble up to root logger

        # Only add the handler once (guard against double-init in tests)
        if not logger.handlers:
            handler = logging.handlers.TimedRotatingFileHandler(
                log_path,
                when="midnight",
                backupCount=30,
                encoding="utf-8",
            )
            # Plain formatter — the record body is already a JSON string
            handler.setFormatter(logging.Formatter("%(message)s"))
            logger.addHandler(handler)

        return logger
