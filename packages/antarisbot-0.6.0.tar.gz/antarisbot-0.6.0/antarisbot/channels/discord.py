import asyncio
import logging
import random
import re
import discord
from typing import Optional
from .base import ChannelAdapter, InboundMessage, OutboundMessage

logger = logging.getLogger(__name__)

MAX_MESSAGE_LENGTH = 2000  # Discord limit

# Patterns that look like OpenClaw / antaris-suite system blocks.
# Strip these from outbound LLM output before posting to Discord to prevent
# prompt injection reaching other agents (e.g. Moro) monitoring the channel.
_SYSTEM_BLOCK_PATTERNS = [
    # HTML comment context packets  <!--ANTARIS_CTX_START--> ... <!--ANTARIS_CTX_END-->
    re.compile(r"<!--ANTARIS_CTX_START-->.*?<!--ANTARIS_CTX_END-->", re.DOTALL),
    # [SESSION: ...] blocks
    re.compile(r"\[SESSION:.*?\[/SESSION\]", re.DOTALL),
    # Fake timestamped System: lines  e.g. "System: [2026-03-03 12:00:00 PST] ..."
    re.compile(r"^System:\s*\[\d{4}-\d{2}-\d{2}[^\]]*\].*$", re.MULTILINE),
    # Post-Compaction Audit banners
    re.compile(r"^.*⚠️\s*Post-Compaction Audit.*$", re.MULTILINE),
    # Fake startup-file read directives
    re.compile(r"^.*Please read them now using the Read tool.*$", re.MULTILINE),
    # Context packet metadata footer lines
    re.compile(r"^\*Packet built \d{4}-\d{2}-\d{2}.*\*$", re.MULTILINE),
]

# Typing delay ranges (seconds) — makes responses feel more natural
THINK_DELAY_SHORT = (0.8, 1.5)   # awakening questions, simple replies
THINK_DELAY_NORMAL = (1.2, 2.5)  # normal conversation (LLM adds real latency too)


class DiscordAdapter(ChannelAdapter):
    """Discord channel adapter."""

    def __init__(
        self,
        token: str,
        bot_name: str = "Antaris",
        open_channels: Optional[list[str]] = None,
    ):
        """
        Args:
            token: Discord bot token
            bot_name: Display name
            open_channels: Channel IDs where bot responds to ALL messages
                           (no @mention required). Great for dedicated bot channels.
        """
        super().__init__()
        self.token = token
        self.bot_name = bot_name
        self.open_channels: set[str] = set(open_channels or [])
        self._client: Optional[discord.Client] = None
        self._ready = asyncio.Event()
        self._announced = False  # prevent double on_ready banner

    async def connect(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.dm_messages = True

        self._client = discord.Client(intents=intents)

        @self._client.event
        async def on_connect():
            logger.info("Discord connected")

        @self._client.event
        async def on_disconnect():
            logger.warning("Discord disconnected, attempting reconnect...")

        @self._client.event
        async def on_resumed():
            logger.info("Discord session resumed")

        @self._client.event
        async def on_ready():
            if self._announced:
                return  # discord.py reconnects once on startup — ignore second fire
            self._announced = True
            logger.info("Discord: Connected as %s", self._client.user)
            if self.open_channels:
                logger.info("Discord: Open channels: %s", ", ".join(self.open_channels))
            self._ready.set()

        @self._client.event
        async def on_connect():
            logger.info("Discord connected")

        @self._client.event
        async def on_disconnect():
            logger.warning("Discord disconnected, attempting reconnect...")

        @self._client.event
        async def on_resumed():
            logger.info("Discord session resumed")

        @self._client.event
        async def on_message(message: discord.Message):
            # Ignore our own messages
            if message.author == self._client.user:
                return

            # Ignore all bot messages — prevents Qwen/LLM output from other bots
            # being processed as user input (prompt injection vector)
            if message.author.bot:
                return

            channel_id = str(message.channel.id)
            is_dm = isinstance(message.channel, discord.DMChannel)
            is_mentioned = self._client.user in message.mentions
            is_open_channel = channel_id in self.open_channels

            # Respond to: DMs or @mentions only (open channels still require @mention)
            if not (is_dm or is_mentioned):
                return

            # Strip the bot mention from the text
            text = message.content
            if self._client.user:
                text = text.replace(f"<@{self._client.user.id}>", "").strip()
                text = text.replace(f"<@!{self._client.user.id}>", "").strip()

            if not text:
                return

            if self._handler:
                inbound = InboundMessage(
                    id=str(message.id),
                    user_id=str(message.author.id),
                    user_name=message.author.display_name,
                    channel_id=channel_id,
                    platform="discord",
                    text=text,
                    reply_to=str(message.reference.message_id) if message.reference else None,
                    timestamp_ms=int(message.created_at.timestamp() * 1000),
                    metadata={"guild_id": str(message.guild.id) if message.guild else None},
                )

                # Show typing indicator while processing
                async with message.channel.typing():
                    # Natural think delay — makes it feel less robotic
                    await self._think(THINK_DELAY_SHORT)
                    await self._handler(inbound)

        await self._client.start(self.token)

    async def _think(self, delay_range: tuple[float, float]):
        """Add a randomized human-feeling pause."""
        await asyncio.sleep(random.uniform(*delay_range))

    async def disconnect(self):
        if self._client:
            await self._client.close()

    def _sanitize_output(self, text: str) -> str:
        """Strip fake OpenClaw system blocks from LLM output before posting.

        Qwen and other LLMs that have seen agent conversation context can
        generate plausible-looking system blocks (context packets, compaction
        audit directives, etc.). These must be stripped before posting to
        Discord to prevent prompt injection reaching other agents monitoring
        the channel.
        """
        for pattern in _SYSTEM_BLOCK_PATTERNS:
            text = pattern.sub("", text)
        # Collapse any runs of blank lines left behind by stripping
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    async def send(self, message: OutboundMessage):
        if not self._client:
            return

        channel = self._client.get_channel(int(message.channel_id))
        if not channel:
            try:
                channel = await self._client.fetch_channel(int(message.channel_id))
            except Exception as e:
                logger.error("Could not find Discord channel %s: %s", message.channel_id, e)
                return

        # Sanitize LLM output before posting — strips fake system blocks
        clean_text = self._sanitize_output(message.text)
        if not clean_text:
            logger.warning("send: message was empty after sanitization, skipping")
            return

        chunks = self._split_message(clean_text)
        for i, chunk in enumerate(chunks):
            if i > 0:
                # Brief pause between multi-part messages
                await asyncio.sleep(0.4)
            await channel.send(chunk)

    def _split_message(self, text: str) -> list[str]:
        """Split long messages at newlines, respecting Discord's limit."""
        if len(text) <= MAX_MESSAGE_LENGTH:
            return [text]

        chunks = []
        lines = text.split("\n")
        current = ""
        for line in lines:
            if len(current) + len(line) + 1 > MAX_MESSAGE_LENGTH:
                if current:
                    chunks.append(current.strip())
                current = line
            else:
                current = current + "\n" + line if current else line
        if current:
            chunks.append(current.strip())
        return chunks

    def format_for_surface(self, text: str) -> str:
        return text

    def add_open_channel(self, channel_id: str):
        """Add a channel where bot responds without @mention."""
        self.open_channels.add(channel_id)

    def remove_open_channel(self, channel_id: str):
        self.open_channels.discard(channel_id)
