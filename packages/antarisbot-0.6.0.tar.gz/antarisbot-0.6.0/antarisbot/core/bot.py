"""
AntarisBot — Main Bot class.

Wires all components together:
  Config → Memory → Guard → Persona → LLM → Pipeline → Channels
"""

import asyncio
import logging
import os
import signal
import sys
from pathlib import Path
from typing import Optional

from antarisbot.core.config import Config, DEFAULT_CONFIG_PATH
from antarisbot.core.logger import setup_logging
from antarisbot.core.memory import BotMemory
from antarisbot.core.guard import BotGuard
from antarisbot.core.updater import Updater
from antarisbot.core.pipeline import Pipeline
from antarisbot.persona.loader import PersonaLoader
from antarisbot.persona.awakening import Awakening
from antarisbot.llm.anthropic import AnthropicProvider
from antarisbot.channels.base import InboundMessage, OutboundMessage, ChannelAdapter
from antarisbot.channels.terminal import TerminalAdapter
from antarisbot.channels.discord import DiscordAdapter
from antarisbot.channels.telegram import TelegramAdapter
from antarisbot.channels.slack import SlackAdapter

logger = logging.getLogger(__name__)


class Bot:
    """
    Main AntarisBot class. Loads config, initializes all components, runs channels.

    Usage:
        Bot().start()                      # all configured channels
        Bot().start(terminal_only=True)    # terminal only
        Bot().chat()                       # alias for terminal mode
    """

    def __init__(self, config_path: Optional[str] = None):
        self.config = Config.load(config_path)
        if not self.config:
            logger.error("Bot not initialized. Run 'antarisbot init' first.")
            sys.exit(1)

        # ── Structured logging — set up before anything else ─────────────
        config_dir = str(Path(self.config.config_path).parent)
        setup_logging(config_dir)
        logger.info("Bot.__init__: config loaded from %s", self.config.config_path)

        errors = self.config.validate()
        if errors:
            logger.error("Configuration errors:")
            print("❌ Configuration errors:")
            for e in errors:
                logger.error("  - %s", e)
            sys.exit(1)

        # ── Components ────────────────────────────────────────────────────
        self._update_notification: Optional[str] = None
        self._first_message_sent: bool = False

        if getattr(self.config, "auto_update", False):
            logger.info("Auto-update enabled — checking for updates...")
        elif getattr(self.config, "notify_updates", True):
            notify_msg = Updater().check_and_notify()
            if notify_msg:
                logger.info("Update available: %s", notify_msg)

        # ── Initialize components ─────────────────────────────────────────
        # Guard: skip if config not yet loaded (setup wizard will run in start())
        self.memory = None
        self.guard = None
        self.persona = None
        self.awakening = None
        self.llm = None
        self.pipeline = None
        self.tool_middleware = None
        self._channels: list[ChannelAdapter] = []

        if not self.config:
            return  # start() will run setup wizard and call _init_components()

        self._init_components()

    def _init_components(self) -> None:
        """Initialise bot components from self.config. Called after config is confirmed loaded."""
        # ── Security setup (must run first — audit hook is irremovable once set) ──
        security_mode = getattr(self.config, "security_mode", "sandboxed")

        # 1. Register audit hook
        from antarisbot.core.guard import register_audit_hook
        register_audit_hook(
            security_mode=security_mode,
            workspace_path=self.config.memory_store,
        )

        # 2. Load encryption key for locked mode
        self._encryption_key: Optional[bytes] = None
        if security_mode == "locked":
            try:
                from antarisbot.security.encrypted_store import load_or_create_key
                self._encryption_key = load_or_create_key()
            except Exception as e:
                logger.warning("Could not load encryption key: %s — locked mode memory unencrypted", e)

        self.memory = BotMemory(
            store_path=self.config.memory_store,
            search_limit=self.config.memory_search_limit,
            min_relevance=self.config.memory_min_relevance,
            security_mode=security_mode,
            encryption_key=self._encryption_key,
        )
        self.guard = BotGuard(mode=self.config.guard_mode)

        # ── Tool middleware ────────────────────────────────────────────────
        from antarisbot.security.tool_middleware import ToolMiddleware
        _audit_log_path = str(Path.home() / ".antarisbot" / "audit.log")
        self.tool_middleware = ToolMiddleware(
            mode=security_mode,
            audit_log_path=_audit_log_path,
        )

        self.persona = PersonaLoader()
        self.awakening = Awakening(self.persona)

        if self.config.provider_name == "ollama":
            from antarisbot.llm.ollama import OllamaProvider
            base_url = getattr(self.config, "ollama_base_url", "http://localhost:11434/v1")
            self.llm = OllamaProvider(model=self.config.model, base_url=base_url)
        elif self.config.provider_name == "openai":
            from antarisbot.llm.openai import OpenAIProvider
            self.llm = OpenAIProvider(api_key=self.config.api_key, model=self.config.model)
        elif self.config.provider_name == "google":
            from antarisbot.llm.google import GoogleProvider
            self.llm = GoogleProvider(api_key=self.config.api_key, model=self.config.model)
        else:
            self.llm = AnthropicProvider(api_key=self.config.api_key, model=self.config.model)

        self.pipeline = Pipeline(
            config=self.config,
            memory=self.memory,
            guard=self.guard,
            persona=self.persona,
            llm=self.llm,
            awakening=self.awakening,
            tool_middleware=self.tool_middleware,
        )

        self._accepting_messages = True

    def start(self, terminal_only: bool = False):
        """Launch the bot. Blocks until stopped."""
        # Run setup wizard if the bot has not been configured yet
        from antarisbot.setup.wizard import SetupWizard
        if SetupWizard().is_needed():
            cfg = SetupWizard().run()
            if cfg:
                self.config = cfg
                self._init_components()
            else:
                logger.error("Setup was cancelled. Run 'antaris setup' to configure.")
                return

        if not self.config:
            logger.error("Bot not initialized. Run 'antaris setup' or 'antaris init' first.")
            sys.exit(1)

        signal.signal(signal.SIGINT, self._handle_shutdown)

        try:
            asyncio.run(self._run(terminal_only=terminal_only))
        except KeyboardInterrupt:
            logger.info("KeyboardInterrupt received, shutting down.")
            print("\n👋 Stopped.")

    def chat(self):
        """Alias for terminal-only mode."""
        self.start(terminal_only=True)

    # ── Graceful shutdown ─────────────────────────────────────────────────

    def _handle_shutdown(self, sig, frame):
        """Flush memory, disconnect channels, remove PID file, exit cleanly."""
        logger.info("Shutdown signal received (sig=%s), flushing memory...", sig)
        self._accepting_messages = False

        # Flush memory store (top-level)
        try:
            if self.memory and hasattr(self.memory, "save"):
                self.memory.save()
                logger.info("Memory saved.")
        except Exception as e:
            logger.warning("Memory save failed during shutdown: %s", e)

        # Also flush per-user stores if present
        if hasattr(self, '_memory') and self._memory:
            try:
                for user_id, store in self._memory._stores.items():
                    store.save()
                logger.info("Memory stores flushed.")
            except Exception as e:
                logger.warning("Error flushing memory stores: %s", e)

        # Disconnect channels (best-effort — we're in a signal handler)
        for adapter in self._channels:
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(adapter.disconnect())
                else:
                    loop.run_until_complete(adapter.disconnect())
            except Exception as e:
                logger.debug("Disconnect error during shutdown: %s", e)

        # Remove PID file
        pid_file = Path.home() / ".antarisbot" / "bot.pid"
        try:
            pid_file.unlink(missing_ok=True)
        except Exception:
            pass

        logger.info("Bot shut down cleanly.")

    # ── Internal ──────────────────────────────────────────────────────────

    def _setup_channels(self, terminal_only: bool):
        self._channels = []

        if terminal_only:
            self._channels.append(TerminalAdapter(bot_name=self.config.bot_name))
            return

        if self.config.discord_enabled and self.config.discord_token:
            self._channels.append(
                DiscordAdapter(
                    token=self.config.discord_token,
                    bot_name=self.config.bot_name,
                    open_channels=self.config.discord_open_channels or [],
                )
            )

        if self.config.telegram_enabled and self.config.telegram_token:
            self._channels.append(
                TelegramAdapter(
                    token=self.config.telegram_token,
                    bot_name=self.config.bot_name,
                    open_chats=getattr(self.config, "telegram_open_chats", None) or [],
                )
            )

        if (
            getattr(self.config, "slack_enabled", False)
            and getattr(self.config, "slack_bot_token", "")
            and getattr(self.config, "slack_app_token", "")
        ):
            self._channels.append(
                SlackAdapter(
                    bot_token=self.config.slack_bot_token,
                    app_token=self.config.slack_app_token,
                    open_channels=getattr(self.config, "slack_open_channels", None) or [],
                )
            )

        if not self._channels:
            logger.warning("No channels configured — falling back to terminal mode.")
            logger.info("Tip: Run 'antarisbot init' to add Discord or Telegram.")
            print("   ⚠️  No channels configured. Starting in terminal mode.")
            print("   Tip: Run 'antarisbot init' to add Discord or Telegram.")
            self._channels.append(TerminalAdapter(bot_name=self.config.bot_name))
    async def _run(self, terminal_only: bool = False):
        self._setup_channels(terminal_only=terminal_only)
        self._print_banner()
        for adapter in self._channels:
            adapter.on_message(self._make_handler(adapter))
        await asyncio.gather(*[adapter.connect() for adapter in self._channels])

    def _make_handler(self, adapter: ChannelAdapter):
        async def handle(inbound: InboundMessage):
            if not self._accepting_messages:
                logger.debug("Ignoring message during shutdown from user=%s", inbound.user_id)
                return
            if not self._first_message_sent and self._update_notification:
                self._first_message_sent = True
                try:
                    await adapter.send(
                        OutboundMessage(
                            channel_id=inbound.channel_id,
                            text=self._update_notification,
                            reply_to=None,
                        )
                    )
                except Exception as exc:
                    logger.warning("Could not send update notification: %s", exc)
            elif not self._first_message_sent:
                self._first_message_sent = True

            result = await self.pipeline.process(inbound, adapter)
            if result.response_text:
                await adapter.send(
                    OutboundMessage(
                        channel_id=inbound.channel_id,
                        text=result.response_text,
                        reply_to=inbound.id,
                    )
                )
            if result.error:
                logger.error("Pipeline error for user=%s: %s", inbound.user_id, result.error)
            if result.failed_stages:
                logger.debug("Failed stages for user=%s: %s", inbound.user_id, result.failed_stages)
        return handle

    def _print_banner(self):
        """Log startup info."""
        memory_count = self._memory_count()
        channel_names = [type(c).__name__.replace("Adapter", "") for c in self._channels]

        logger.info(
            "Starting %s | memory=%d | guard=%s | model=%s via %s | channels=%s",
            self.config.bot_name, memory_count, self.config.guard_mode,
            self.config.model, self.config.provider_name, ", ".join(channel_names),
        )

        security_mode = getattr(self.config, "security_mode", "sandboxed")
        print(f"\n🤖 {self.config.bot_name} starting...")
        print(f"   Memory: {memory_count} entries")
        print(f"   Security: {security_mode} mode")
        print(f"   Guard: {self.config.guard_mode} mode")
        print(f"   Model: {self.config.model} via {self.config.provider_name}")
        print(f"   Channels: {', '.join(channel_names)}")
        if self.awakening.is_needed():
            logger.info("Identity: Awakening needed")
        else:
            logger.info("Identity: SOUL.md loaded")

    def _memory_count(self) -> int:
        try:
            return self.memory.stats().get("total", 0)
        except Exception:
            return 0
