import json
import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

DEFAULT_CONFIG_DIR = Path.home() / ".antarisbot"
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.json"


@dataclass
class Config:
    bot_name: str = "Antaris"
    provider_name: str = "anthropic"
    api_key: str = ""
    model: str = "claude-sonnet-4-20250514"
    fallback_model: str = "claude-haiku-4-5-20251001"
    ollama_base_url: str = "http://localhost:11434/v1"
    discord_token: str = ""
    discord_enabled: bool = False
    discord_open_channels: list = field(default_factory=list)
    telegram_token: str = ""
    telegram_open_chats: list = field(default_factory=list)
    telegram_enabled: bool = False
    slack_bot_token: str = ""
    slack_app_token: str = ""
    slack_enabled: bool = False
    slack_open_channels: list = field(default_factory=list)
    memory_store: str = str(DEFAULT_CONFIG_DIR / "memory")
    memory_search_limit: int = 10
    memory_min_relevance: float = 0.3
    guard_mode: str = "monitor"  # monitor | warn | block
    security_mode: str = "sandboxed"  # open | sandboxed | locked
    context_max_tokens: int = 100000
    rate_limit_messages: int = 20
    rate_limit_window_seconds: int = 60
    auto_update: bool = False
    notify_updates: bool = True
    config_path: str = str(DEFAULT_CONFIG_PATH)

    @classmethod
    def load(cls, path: Optional[str] = None) -> Optional["Config"]:
        config_path = Path(path or DEFAULT_CONFIG_PATH)
        if not config_path.exists():
            return None
        with open(config_path) as f:
            data = json.load(f)
        cfg = cls()
        cfg.config_path = str(config_path)
        cfg.bot_name = data.get("bot", {}).get("name", "Antaris")
        provider = data.get("provider", {})
        cfg.provider_name = provider.get("name", "anthropic")
        cfg.api_key = provider.get("apiKey", "")
        cfg.model = provider.get("model", "claude-sonnet-4-20250514")
        cfg.fallback_model = provider.get("fallbackModel", "claude-haiku-4-5-20251001")
        cfg.ollama_base_url = provider.get("ollamaBaseUrl", "http://localhost:11434/v1")
        discord = data.get("channels", {}).get("discord", {})
        cfg.discord_enabled = discord.get("enabled", False)
        cfg.discord_token = discord.get("token", "")
        cfg.discord_open_channels = discord.get("openChannels", [])
        telegram = data.get("channels", {}).get("telegram", {})
        cfg.telegram_enabled = telegram.get("enabled", False)
        cfg.telegram_token = telegram.get("token", "")
        cfg.telegram_open_chats = telegram.get("openChats", [])
        slack = data.get("channels", {}).get("slack", {})
        cfg.slack_enabled = slack.get("enabled", False)
        cfg.slack_bot_token = slack.get("botToken", "")
        cfg.slack_app_token = slack.get("appToken", "")
        cfg.slack_open_channels = slack.get("openChannels", [])
        memory = data.get("memory", {})
        cfg.memory_store = memory.get("store", str(DEFAULT_CONFIG_DIR / "memory"))
        cfg.memory_search_limit = memory.get("searchLimit", 10)
        cfg.memory_min_relevance = memory.get("minRelevance", 0.3)
        guard = data.get("guard", {})
        cfg.guard_mode = guard.get("mode", "monitor")
        security = data.get("security", {})
        cfg.security_mode = security.get("mode", "sandboxed")
        # Derive guard_mode from security_mode (can be overridden by explicit guard config)
        _mode_to_guard = {"open": "disabled", "sandboxed": "monitor", "locked": "block"}
        cfg.guard_mode = _mode_to_guard.get(cfg.security_mode, cfg.guard_mode)
        # But still allow explicit guard override in config
        if "mode" in guard:
            cfg.guard_mode = guard.get("mode", cfg.guard_mode)
        rate_limit = data.get("rate_limit", {})
        cfg.rate_limit_messages = rate_limit.get("max_messages", 20)
        cfg.rate_limit_window_seconds = rate_limit.get("window_seconds", 60)
        updates = data.get("updates", {})
        cfg.auto_update = updates.get("autoUpdate", False)
        cfg.notify_updates = updates.get("notifyUpdates", True)
        return cfg

    def save(self, path: Optional[str] = None):
        config_path = Path(path or self.config_path)
        config_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "bot": {"name": self.bot_name},
            "provider": {
                "name": self.provider_name,
                "apiKey": self.api_key,
                "model": self.model,
                "fallbackModel": self.fallback_model,
                "ollamaBaseUrl": self.ollama_base_url,
            },
            "channels": {
                "discord": {
                    "enabled": self.discord_enabled,
                    "token": self.discord_token,
                    "openChannels": self.discord_open_channels or []
                },
                "telegram": {
                    "enabled": self.telegram_enabled,
                    "token": self.telegram_token,
                    "openChats": self.telegram_open_chats or []
                },
                "slack": {
                    "enabled": self.slack_enabled,
                    "botToken": self.slack_bot_token,
                    "appToken": self.slack_app_token,
                    "openChannels": self.slack_open_channels or []
                }
            },
            "memory": {
                "store": self.memory_store,
                "searchLimit": self.memory_search_limit,
                "minRelevance": self.memory_min_relevance,
                "autoIngest": True,
                "autoRecall": True
            },
            "guard": {"mode": self.guard_mode},
            "security": {"mode": self.security_mode},
            "context": {"maxTokens": self.context_max_tokens},
            "updates": {
                "autoUpdate": self.auto_update,
                "notifyUpdates": self.notify_updates
            }
        }
        with open(config_path, "w") as f:
            json.dump(data, f, indent=2)
        print(f"   Config saved to {config_path}")

    def validate(self) -> list[str]:
        errors = []
        if self.provider_name != "ollama" and not self.api_key:
            errors.append("API key is required")
        if self.discord_enabled and not self.discord_token:
            errors.append("Discord token required when Discord is enabled")
        if self.telegram_enabled and not self.telegram_token:
            errors.append("Telegram token required when Telegram is enabled")
        if self.slack_enabled and not self.slack_bot_token:
            errors.append("Slack bot token required when Slack is enabled")
        if self.slack_enabled and not self.slack_app_token:
            errors.append("Slack app token required when Slack is enabled")
        if self.security_mode not in ("open", "sandboxed", "locked"):
            errors.append(f"Invalid security_mode '{self.security_mode}'. Must be: open, sandboxed, locked")
        return errors


def run_init_wizard():
    """Interactive setup wizard."""
    print("🤖 Welcome to AntarisBot\n")

    config = Config()
    config_dir = DEFAULT_CONFIG_DIR
    config_dir.mkdir(parents=True, exist_ok=True)

    # Bot name
    name = input(f"Bot name [{config.bot_name}]: ").strip()
    if name:
        config.bot_name = name

    # Provider
    print("\nLLM Provider:")
    print("  [1] Anthropic (Claude) — recommended")
    print("  [2] OpenAI (GPT)")
    print("  [3] Ollama (local, fully offline, zero cost)")
    choice = input("Select [1]: ").strip() or "1"
    if choice == "2":
        config.provider_name = "openai"
        config.model = "gpt-4o-mini"
        config.fallback_model = "gpt-3.5-turbo"
    elif choice == "3":
        config.provider_name = "ollama"
        config.api_key = "ollama"
        print("\nOllama model (installed models: run `ollama list`):")
        print("  Recommended: qwen3.5:4b (best balance, ~2.5GB)")
        print("  Lightweight: qwen3.5:2b, qwen3.5:0.8b")
        print("  High quality: qwen3.5:9b, qwen3:8b")
        model = input("Model [qwen3.5:4b]: ").strip() or "qwen3.5:4b"
        config.model = model
        config.fallback_model = model
        base_url = input("Ollama base URL [http://localhost:11434/v1]: ").strip()
        if base_url:
            config.ollama_base_url = base_url

    # API Key (skip for ollama)
    if config.provider_name != "ollama":
        api_key = input(f"\n{config.provider_name.capitalize()} API Key: ").strip()
        config.api_key = api_key

    # Discord
    print("\nDiscord bot token (optional — press Enter to skip):")
    discord_token = input("Token: ").strip()
    if discord_token:
        config.discord_enabled = True
        config.discord_token = discord_token

    # Security mode
    print("\nSecurity mode:")
    print("  [1] sandboxed — recommended (filesystem restricted, subprocesses blocked)")
    print("  [2] open      — no restrictions (developers/power users)")
    print("  [3] locked    — maximum security (encrypted memory, tool approval, audit log)")
    sec_choice = input("Select [1]: ").strip() or "1"
    config.security_mode = {"1": "sandboxed", "2": "open", "3": "locked"}.get(sec_choice, "sandboxed")

    # Validate
    errors = config.validate()
    if errors:
        print("\n⚠️  Validation issues:")
        for e in errors:
            print(f"   - {e}")

    # Save
    config.save()

    # Create default SOUL.md if it doesn't exist
    soul_path = config_dir / "SOUL.md"
    if not soul_path.exists():
        import shutil
        from pathlib import Path as P
        template = P(__file__).parent.parent / "persona" / "templates" / "default_soul.md"
        if template.exists():
            shutil.copy(template, soul_path)
            print(f"   SOUL.md created at {soul_path}")

    # Create USER.md if it doesn't exist
    user_path = config_dir / "USER.md"
    if not user_path.exists():
        user_path.write_text("# About You\n\n*Antaris will learn about you over time.*\n")
        print(f"   USER.md created at {user_path}")

    # Create memory dir
    memory_dir = Path(config.memory_store)
    memory_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n✅ {config.bot_name} initialized at {config_dir}")
    print("   Run 'antarisbot start' to launch.")
    if not config.discord_enabled:
        print("   Tip: Run 'antarisbot chat' to test in terminal first.")
