"""
AntarisBot Message Pipeline — Step 10
"""
import asyncio
import logging
from dataclasses import dataclass, field
from typing import Optional

from antarisbot.channels.base import InboundMessage, OutboundMessage, ChannelAdapter
from antarisbot.core.config import Config
from antarisbot.core.memory import BotMemory
from antarisbot.core.guard import BotGuard
from antarisbot.core.rate_limiter import RateLimiter
from antarisbot.llm.base import LLMProvider, Message, LLMResponse
from antarisbot.persona.loader import PersonaLoader
from antarisbot.persona.user_tracker import UserTracker

logger = logging.getLogger(__name__)

MAX_HISTORY = 20


@dataclass
class PipelineResult:
    success: bool
    response_text: str
    blocked: bool = False
    block_reason: str = ""
    tokens_used: int = 0
    cost_usd: float = 0.0
    error: Optional[str] = None
    failed_stages: list = field(default_factory=list)
    metadata: dict = field(default_factory=dict)


class Pipeline:
    """
    10-stage message processing pipeline with error isolation.

    Stage 0:  Rate limit check (sliding window, before guard)
    Stage 1:  Input guard check (critical)
    Stage 2:  User identification
    Stage 3:  Memory recall (non-critical)
    Stage 4:  Persona load (non-critical)
    Stage 5:  Context assembly
    Stage 6:  LLM call (critical)
    Stage 7:  Output guard check (non-critical)
    Stage 8:  Memory ingest (non-critical)
    Stage 9:  Surface formatting (non-critical)
    Stage 10: Return result

    Non-critical failures are logged, defaults used, processing continues.
    Critical failures return a friendly error PipelineResult.
    """

    def __init__(
        self,
        config: Config,
        memory: BotMemory,
        guard: BotGuard,
        persona: PersonaLoader,
        llm: LLMProvider,
        awakening=None,
        tool_middleware=None,
    ):
        self.config = config
        self.memory = memory
        self.guard = guard
        self.persona = persona
        self.llm = llm
        self.awakening = awakening
        self.tool_middleware = tool_middleware

        self._history: dict[str, list[Message]] = {}
        self._last_message: dict[str, float] = {}
        self._cooldown_seconds: float = 1.0

        # Sliding-window rate limiter lives on Pipeline (not recreated per message)
        # Use isinstance guard: MagicMock attributes are not int and fall back to defaults
        _raw_max = getattr(config, "rate_limit_messages", 20)
        _raw_win = getattr(config, "rate_limit_window_seconds", 60)
        _max_msg = _raw_max if isinstance(_raw_max, int) else 20
        _window  = _raw_win if isinstance(_raw_win, int) else 60
        self._rate_limiter = RateLimiter(max_messages=_max_msg, window_seconds=_window)

        # UserTracker: silently learns facts about the user from their messages
        config_dir = str(getattr(persona, "config_dir", ""))
        self.user_tracker = UserTracker(config_dir) if config_dir else None

    async def process(self, inbound: InboundMessage, adapter: ChannelAdapter) -> PipelineResult:
        """Run a message through all stages. Returns a PipelineResult."""
        failed_stages: list[str] = []

        try:
            # ── Awakening check ────────────────────────────────────────────
            if self.awakening:
                if self.awakening.is_needed() and not self.awakening.is_active():
                    await asyncio.sleep(1.5)
                    response = self.awakening.start(inbound.user_id)
                    return PipelineResult(success=True, response_text=adapter.format_for_surface(response))
                if self.awakening.is_active():
                    await asyncio.sleep(1.2)
                    response = self.awakening.process(inbound.user_id, inbound.text)
                    return PipelineResult(success=True, response_text=adapter.format_for_surface(response))

            # ── Stage 0: Sliding-window rate limit check ──────────────────
            import math
            if not self._rate_limiter.is_allowed(inbound.user_id):
                wait = self._rate_limiter.get_wait_seconds(inbound.user_id)
                wait_int = math.ceil(wait)
                logger.warning("Rate limited user=%s (wait=%.1fs)", inbound.user_id, wait)
                return PipelineResult(
                    success=True,
                    response_text=(
                        f"You're sending messages too fast. "
                        f"Please wait {wait_int} second{'s' if wait_int != 1 else ''}."
                    ),
                    failed_stages=[],
                )

            # ── Basic cooldown ────────────────────────────────────────────
            import time
            now = time.time()
            last = self._last_message.get(inbound.user_id, 0)
            if now - last < self._cooldown_seconds:
                logger.debug("Cooldown hit for user=%s", inbound.user_id)
                return PipelineResult(success=True, response_text="")
            self._last_message[inbound.user_id] = now

            # ── Stage 1: Input guard (critical) ──────────────────────────
            try:
                allowed, reason = await self.guard.check_input(inbound.text, inbound.user_id)
                if not allowed:
                    logger.warning("Guard blocked user=%s reason=%s", inbound.user_id, reason)
                    return PipelineResult(
                        success=True, response_text="I can't respond to that.",
                        blocked=True, block_reason=reason, failed_stages=failed_stages,
                    )
            except Exception as e:
                logger.error("Stage 1 (input guard) failed: %s", e, exc_info=True)
                failed_stages.append("input_guard")
                return PipelineResult(
                    success=False,
                    response_text="Something went wrong checking your message. Please try again.",
                    error=str(e), failed_stages=failed_stages,
                )

            user_id = inbound.user_id

            # ── Stage 1.5: Tool approval gate (locked mode) ──────────────
            if self.tool_middleware and hasattr(self.tool_middleware, 'approve_and_run'):
                security_mode = getattr(self.tool_middleware, 'mode', 'sandboxed')
                if security_mode == "locked":
                    approved = await self.tool_middleware.approve_and_run(
                        tool_name="process_message",
                        args={"preview": inbound.text[:80]},
                        fn=None,
                    )
                    if approved is None:  # None means rejected
                        return PipelineResult(
                            success=True,
                            response_text="❌ Message processing cancelled.",
                            failed_stages=failed_stages,
                        )

            # ── Stage 3: Memory recall (non-critical) ─────────────────────
            memories: list[str] = []
            try:
                if self.tool_middleware:
                    await self.tool_middleware.approve_and_run(
                        tool_name="memory_recall",
                        args={"query": inbound.text[:60]},
                        fn=None,  # logging only in sandboxed, approval already done above in locked
                    )
                memories = await self.memory.recall(user_id, inbound.text)
                logger.debug("Recalled %d memories for user=%s", len(memories), user_id)
            except Exception as e:
                logger.warning("Stage 3 (memory recall) failed: %s", e)
                failed_stages.append("memory_recall")

            # ── Stage 4: Persona load (non-critical) ──────────────────────
            try:
                system_prompt = self.persona.build_system_prompt(memories)
            except Exception as e:
                logger.warning("Stage 4 (persona load) failed: %s", e)
                failed_stages.append("persona_load")
                system_prompt = "You are a helpful assistant."

            # ── Stage 5: Context assembly ─────────────────────────────────
            history = self._get_history(user_id)
            messages = history + [Message(role="user", content=inbound.text)]

            # ── Stage 6: LLM call (critical) ──────────────────────────────
            try:
                llm_response: LLMResponse = await self.llm.complete(
                    messages=messages, system=system_prompt, model=self.config.model,
                )
                raw_text = llm_response.content
            except Exception as e:
                logger.error("Stage 6 (LLM call) failed: %s", e, exc_info=True)
                failed_stages.append("llm_call")
                return PipelineResult(
                    success=False,
                    response_text="Something went wrong on my end. Please try again in a moment.",
                    error=str(e), failed_stages=failed_stages,
                )

            # ── Stage 7: Output guard (non-critical) ──────────────────────
            try:
                _ok, filtered_text = await self.guard.check_output(raw_text)
            except Exception as e:
                logger.warning("Stage 7 (output guard) failed: %s", e)
                failed_stages.append("output_guard")
                filtered_text = raw_text

            # ── Stage 8: Memory ingest (non-critical) ─────────────────────
            try:
                await self.memory.ingest(user_id, inbound.text, filtered_text)
            except Exception as e:
                logger.warning("Stage 8 (memory ingest) failed: %s", e)
                failed_stages.append("memory_ingest")

            # ── Stage 8b: USER.md update (non-critical) ──────────────────
            learned_facts: list[str] = []
            try:
                await self._maybe_update_user_context(inbound, filtered_text)
                if self.user_tracker is not None:
                    learned_facts = self.user_tracker.process_message(inbound.text)
                    if learned_facts:
                        logger.debug(
                            "UserTracker: learned %d fact(s) for user=%s",
                            len(learned_facts),
                            user_id,
                        )
            except Exception as e:
                logger.warning("USER.md update failed: %s", e)
                failed_stages.append("user_context_update")

            self._update_history(user_id, inbound.text, filtered_text)

            # ── Stage 9: Surface formatting (non-critical) ────────────────
            try:
                formatted = adapter.format_for_surface(filtered_text)
            except Exception as e:
                logger.warning("Stage 9 (formatting) failed: %s", e)
                failed_stages.append("surface_format")
                formatted = filtered_text

            result_metadata: dict = {}
            if learned_facts:
                result_metadata["learned_facts"] = learned_facts

            return PipelineResult(
                success=True,
                response_text=formatted,
                tokens_used=llm_response.input_tokens + llm_response.output_tokens,
                cost_usd=llm_response.cost_usd,
                failed_stages=failed_stages,
                metadata=result_metadata,
            )

        except Exception as e:
            logger.error("Pipeline unexpected error: %s", e, exc_info=True)
            return PipelineResult(
                success=False, response_text="Something went wrong on my end. Try again.",
                error=str(e), failed_stages=failed_stages,
            )

    def _get_history(self, user_id: str) -> list[Message]:
        return list(self._history.get(user_id, []))

    def _update_history(self, user_id: str, user_text: str, bot_text: str):
        if user_id not in self._history:
            self._history[user_id] = []
        hist = self._history[user_id]
        hist.append(Message(role="user", content=user_text))
        hist.append(Message(role="assistant", content=bot_text))
        if len(hist) > MAX_HISTORY:
            self._history[user_id] = hist[-MAX_HISTORY:]

    def clear_history(self, user_id: str):
        self._history.pop(user_id, None)

    def history_length(self, user_id: str) -> int:
        return len(self._history.get(user_id, []))

    async def _maybe_update_user_context(self, inbound: InboundMessage, bot_response: str):
        text = inbound.text.lower()
        personal_triggers = [
            "my name is", "i'm called", "call me",
            "i work", "i live", "i'm from", "i am from",
            "my job", "my role", "i like", "i love", "i hate",
            "i prefer", "i usually", "i always", "i never",
            "my favorite", "i'm a ", "i am a ",
        ]
        triggered = any(trigger in text for trigger in personal_triggers)
        if not triggered:
            return
        sentences = [s.strip() for s in inbound.text.split('.') if s.strip()]
        relevant = [s for s in sentences if any(t in s.lower() for t in personal_triggers)]
        if relevant:
            fact = '. '.join(relevant[:2])
            self.persona.update_user_context(f"- {fact}")
            logger.debug("Updated USER.md with: %s", fact[:80])
