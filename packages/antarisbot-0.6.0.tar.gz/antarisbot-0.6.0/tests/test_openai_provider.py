"""
Tests for AntarisBot OpenAI provider (Phase 4) and Google stub.
All HTTP calls are mocked — no live API calls.
"""
import asyncio
import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from antarisbot.llm.base import Message, LLMResponse
from antarisbot.llm.openai import OpenAIProvider, MODEL_PRICING
from antarisbot.llm.google import GoogleProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_openai_response(
    content="Hello from OpenAI!",
    prompt_tokens=50,
    completion_tokens=20,
    model="gpt-4o-mini",
    status_code=200,
):
    """Build a mock httpx response that looks like an OpenAI chat/completions reply."""
    mock_resp = MagicMock()
    mock_resp.status_code = status_code
    mock_resp.json.return_value = {
        "id": "chatcmpl-test123",
        "object": "chat.completion",
        "model": model,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        },
    }
    mock_resp.raise_for_status = MagicMock()
    mock_resp.text = json.dumps(mock_resp.json.return_value)
    return mock_resp


def patch_client(mock_response):
    """Context manager: patch httpx.AsyncClient to return mock_response on .post()."""
    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.post = AsyncMock(return_value=mock_response)

    patcher = patch("httpx.AsyncClient", return_value=mock_client)
    return patcher, mock_client


# ---------------------------------------------------------------------------
# Initialization tests
# ---------------------------------------------------------------------------

class TestOpenAIProviderInit:
    def test_stores_api_key(self):
        p = OpenAIProvider(api_key="sk-proj-abc", model="gpt-4o-mini")
        assert p.api_key == "sk-proj-abc"

    def test_stores_model(self):
        p = OpenAIProvider(api_key="sk-proj-abc", model="gpt-4o-mini")
        assert p.model == "gpt-4o-mini"

    def test_base_url(self):
        p = OpenAIProvider(api_key="key", model="gpt-4o")
        assert p.BASE_URL == "https://api.openai.com/v1"

    def test_model_pricing_keys(self):
        assert "gpt-4o" in MODEL_PRICING
        assert "gpt-4o-mini" in MODEL_PRICING
        assert "gpt-4-turbo" in MODEL_PRICING
        assert "gpt-3.5-turbo" in MODEL_PRICING
        assert "o1" in MODEL_PRICING
        assert "o1-mini" in MODEL_PRICING
        assert "o3-mini" in MODEL_PRICING


# ---------------------------------------------------------------------------
# estimate_tokens
# ---------------------------------------------------------------------------

class TestEstimateTokens:
    def setup_method(self):
        self.provider = OpenAIProvider(api_key="sk-test", model="gpt-4o-mini")

    def test_empty_string_returns_one(self):
        assert self.provider.estimate_tokens("") == 1

    def test_short_string(self):
        assert self.provider.estimate_tokens("hi") == 1  # 2 chars → max(1, 0) = 1

    def test_longer_string(self):
        text = "a" * 400  # 400 chars → 100 tokens
        assert self.provider.estimate_tokens(text) == 100

    def test_formula_chars_div_4(self):
        text = "x" * 80  # 80 chars → 20 tokens
        assert self.provider.estimate_tokens(text) == 20


# ---------------------------------------------------------------------------
# complete() — happy path
# ---------------------------------------------------------------------------

class TestOpenAIProviderComplete:
    def setup_method(self):
        self.provider = OpenAIProvider(api_key="sk-proj-fake", model="gpt-4o-mini")

    def _run(self, coro):
        return asyncio.run(coro)

    def test_complete_returns_llm_response(self):
        mock_resp = make_openai_response("Hello from OpenAI!", prompt_tokens=30, completion_tokens=10)
        patcher, _ = patch_client(mock_resp)

        with patcher:
            result = self._run(
                self.provider.complete(
                    messages=[Message(role="user", content="Hi")],
                    system="Be helpful",
                )
            )

        assert isinstance(result, LLMResponse)
        assert result.content == "Hello from OpenAI!"
        assert result.model == "gpt-4o-mini"
        assert result.input_tokens == 30
        assert result.output_tokens == 10

    def test_complete_with_model_override(self):
        mock_resp = make_openai_response("Turbo reply", model="gpt-4-turbo")
        captured = {}
        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        async def fake_post(url, json=None, headers=None):
            captured["payload"] = json
            return mock_resp

        mock_client.post = fake_post

        with patch("httpx.AsyncClient", return_value=mock_client):
            self._run(
                self.provider.complete(
                    messages=[Message(role="user", content="Hi")],
                    system="Be helpful",
                    model="gpt-4-turbo",
                )
            )

        assert captured["payload"]["model"] == "gpt-4-turbo"

    def test_system_message_appears_first(self):
        """System prompt must be the first message in the messages array."""
        mock_resp = make_openai_response()
        captured = {}
        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        async def fake_post(url, json=None, headers=None):
            captured["payload"] = json
            return mock_resp

        mock_client.post = fake_post

        messages = [
            Message(role="user", content="What is Python?"),
            Message(role="assistant", content="A programming language."),
            Message(role="user", content="Tell me more."),
        ]

        with patch("httpx.AsyncClient", return_value=mock_client):
            self._run(
                self.provider.complete(
                    messages=messages,
                    system="You are a helpful tutor.",
                )
            )

        sent = captured["payload"]["messages"]
        assert sent[0]["role"] == "system"
        assert sent[0]["content"] == "You are a helpful tutor."

    def test_system_role_messages_excluded_from_array(self):
        """Messages with role='system' should be dropped (not double-included)."""
        mock_resp = make_openai_response()
        captured = {}
        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        async def fake_post(url, json=None, headers=None):
            captured["payload"] = json
            return mock_resp

        mock_client.post = fake_post

        messages = [
            Message(role="system", content="Old stale system message"),
            Message(role="user", content="Hello"),
        ]

        with patch("httpx.AsyncClient", return_value=mock_client):
            self._run(
                self.provider.complete(
                    messages=messages,
                    system="Fresh system prompt.",
                )
            )

        sent = captured["payload"]["messages"]
        roles = [m["role"] for m in sent]
        # Only one system message (the fresh one), not two
        assert roles.count("system") == 1
        assert sent[0]["content"] == "Fresh system prompt."

    def test_auth_header_is_bearer(self):
        """Authorization header must be 'Bearer {api_key}'."""
        mock_resp = make_openai_response()
        captured = {}
        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        async def fake_post(url, json=None, headers=None):
            captured["headers"] = headers
            return mock_resp

        mock_client.post = fake_post

        with patch("httpx.AsyncClient", return_value=mock_client):
            self._run(
                self.provider.complete(
                    messages=[Message(role="user", content="Hi")],
                    system="Test",
                )
            )

        assert captured["headers"]["Authorization"] == "Bearer sk-proj-fake"

    def test_endpoint_url(self):
        """Must POST to /v1/chat/completions."""
        mock_resp = make_openai_response()
        captured = {}
        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        async def fake_post(url, json=None, headers=None):
            captured["url"] = url
            return mock_resp

        mock_client.post = fake_post

        with patch("httpx.AsyncClient", return_value=mock_client):
            self._run(
                self.provider.complete(
                    messages=[Message(role="user", content="Hi")],
                    system="Test",
                )
            )

        assert captured["url"] == "https://api.openai.com/v1/chat/completions"


# ---------------------------------------------------------------------------
# Cost calculation
# ---------------------------------------------------------------------------

class TestCostCalculation:
    def setup_method(self):
        self.provider = OpenAIProvider(api_key="sk-proj-fake", model="gpt-4o-mini")

    def _run(self, coro):
        return asyncio.run(coro)

    def test_cost_gpt4o_mini(self):
        """gpt-4o-mini: $0.15/M input, $0.60/M output
        1000 input + 500 output → (1000*0.15 + 500*0.60)/1e6 = (150+300)/1e6 = 0.00045
        """
        mock_resp = make_openai_response(prompt_tokens=1000, completion_tokens=500)
        patcher, _ = patch_client(mock_resp)

        with patcher:
            result = self._run(
                self.provider.complete(
                    messages=[Message(role="user", content="Test")],
                    system="Test",
                )
            )

        assert result.cost_usd == pytest.approx(0.00045)

    def test_cost_gpt4o(self):
        """gpt-4o: $2.50/M input, $10.00/M output
        100 input + 50 output → (100*2.50 + 50*10.00)/1e6 = (250+500)/1e6 = 0.00075
        """
        provider = OpenAIProvider(api_key="sk-proj-fake", model="gpt-4o")
        mock_resp = make_openai_response(prompt_tokens=100, completion_tokens=50, model="gpt-4o")
        patcher, _ = patch_client(mock_resp)

        with patcher:
            result = self._run(
                provider.complete(
                    messages=[Message(role="user", content="Test")],
                    system="Test",
                )
            )

        assert result.cost_usd == pytest.approx(0.00075)

    def test_cost_unknown_model_uses_gpt4o_defaults(self):
        """Unknown models fall back to gpt-4o pricing ($2.50/$10.00 per M)."""
        provider = OpenAIProvider(api_key="sk-proj-fake", model="gpt-99-future")
        mock_resp = make_openai_response(prompt_tokens=1_000_000, completion_tokens=0, model="gpt-99-future")
        patcher, _ = patch_client(mock_resp)

        with patcher:
            result = self._run(
                provider.complete(
                    messages=[Message(role="user", content="Test")],
                    system="Test",
                )
            )

        # 1M input tokens × $2.50/M = $2.50
        assert result.cost_usd == pytest.approx(2.50)


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestOpenAIErrorHandling:
    def setup_method(self):
        self.provider = OpenAIProvider(api_key="sk-proj-bad", model="gpt-4o-mini")

    def _run(self, coro):
        return asyncio.run(coro)

    def _mock_status(self, status_code, body=""):
        mock_resp = MagicMock()
        mock_resp.status_code = status_code
        mock_resp.text = body
        mock_resp.json.return_value = {}
        mock_resp.raise_for_status = MagicMock()
        return mock_resp

    def test_401_raises_value_error(self):
        mock_resp = self._mock_status(401, "Unauthorized")
        patcher, _ = patch_client(mock_resp)

        with patcher:
            with pytest.raises(ValueError, match="Invalid OpenAI API key"):
                self._run(
                    self.provider.complete(
                        messages=[Message(role="user", content="Hi")],
                        system="Test",
                    )
                )

    def test_429_raises_runtime_error(self):
        mock_resp = self._mock_status(429, "Rate limited")
        patcher, _ = patch_client(mock_resp)

        with patcher:
            with pytest.raises(RuntimeError, match="OpenAI rate limit exceeded"):
                self._run(
                    self.provider.complete(
                        messages=[Message(role="user", content="Hi")],
                        system="Test",
                    )
                )

    def test_400_model_not_found_raises_value_error(self):
        mock_resp = self._mock_status(
            400,
            '{"error": {"code": "model_not_found", "message": "The model does not exist."}}'
        )
        patcher, _ = patch_client(mock_resp)

        with patcher:
            with pytest.raises(ValueError, match="Model not found"):
                self._run(
                    self.provider.complete(
                        messages=[Message(role="user", content="Hi")],
                        system="Test",
                    )
                )

    def test_timeout_raises_runtime_error(self):
        import httpx

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.post = AsyncMock(side_effect=httpx.TimeoutException("timeout"))

        with patch("httpx.AsyncClient", return_value=mock_client):
            with pytest.raises(RuntimeError, match="timed out"):
                self._run(
                    self.provider.complete(
                        messages=[Message(role="user", content="Hi")],
                        system="Test",
                    )
                )

    def test_400_generic_raises_runtime_error(self):
        mock_resp = self._mock_status(400, '{"error": "some_other_error"}')
        patcher, _ = patch_client(mock_resp)

        with patcher:
            with pytest.raises(RuntimeError, match="OpenAI API error 400"):
                self._run(
                    self.provider.complete(
                        messages=[Message(role="user", content="Hi")],
                        system="Test",
                    )
                )


# ---------------------------------------------------------------------------
# GoogleProvider stub
# ---------------------------------------------------------------------------

class TestGoogleProviderStub:
    def test_raises_not_implemented_on_complete(self):
        provider = GoogleProvider(api_key="goog-fake-key", model="gemini-1.5-pro")

        async def run():
            await provider.complete(
                messages=[Message(role="user", content="Hi")],
                system="Be helpful",
            )

        with pytest.raises(NotImplementedError, match="Google Gemini"):
            asyncio.run(run())

    def test_estimate_tokens_works(self):
        provider = GoogleProvider(api_key="goog-fake-key", model="gemini-1.5-pro")
        assert provider.estimate_tokens("hello") == 1
        assert provider.estimate_tokens("a" * 400) == 100
        assert provider.estimate_tokens("") == 1

    def test_models_list(self):
        assert "gemini-1.5-pro" in GoogleProvider.MODELS
        assert "gemini-1.5-flash" in GoogleProvider.MODELS
        assert "gemini-2.0-flash" in GoogleProvider.MODELS

    def test_initializes(self):
        provider = GoogleProvider(api_key="goog-key", model="gemini-2.0-flash")
        assert provider.api_key == "goog-key"
        assert provider.model == "gemini-2.0-flash"
