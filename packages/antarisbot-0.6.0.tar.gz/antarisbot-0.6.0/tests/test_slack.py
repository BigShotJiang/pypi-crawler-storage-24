"""
Tests for the Slack channel adapter, config integration, CLI, and setup wizard.
All Slack API calls are mocked — no real network requests are made.
"""

import asyncio
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, Mock, patch, PropertyMock

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_event(
    user="U123",
    channel="C123",
    channel_type="channel",
    text="hello bot",
    subtype=None,
    bot_id=None,
    ts="1700000000.000001",
):
    event = {
        "user": user,
        "channel": channel,
        "channel_type": channel_type,
        "text": text,
        "ts": ts,
    }
    if subtype:
        event["subtype"] = subtype
    if bot_id:
        event["bot_id"] = bot_id
    return event


def _dm_event(**kwargs):
    return _make_event(channel_type="im", **kwargs)


def _run(coro):
    return asyncio.get_event_loop().run_until_complete(coro)


# ---------------------------------------------------------------------------
# 1. SlackAdapter — unit tests (no real Slack connection)
# ---------------------------------------------------------------------------

class TestSlackAdapterInit(unittest.TestCase):
    """Test SlackAdapter initialisation."""

    def test_init_stores_tokens(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")
        self.assertEqual(adapter.bot_token, "xoxb-test")
        self.assertEqual(adapter.app_token, "xapp-test")

    def test_init_empty_open_channels(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")
        self.assertEqual(adapter.open_channels, set())

    def test_init_with_open_channels(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(
            bot_token="xoxb-test",
            app_token="xapp-test",
            open_channels=["C001", "C002"],
        )
        self.assertIn("C001", adapter.open_channels)
        self.assertIn("C002", adapter.open_channels)

    def test_missing_bot_token_raises(self):
        from antarisbot.channels.slack import SlackAdapter
        with self.assertRaises(ValueError):
            SlackAdapter(bot_token="", app_token="xapp-test")

    def test_missing_app_token_raises(self):
        from antarisbot.channels.slack import SlackAdapter
        with self.assertRaises(ValueError):
            SlackAdapter(bot_token="xoxb-test", app_token="")

    def test_add_open_channel(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")
        adapter.add_open_channel("C999")
        self.assertIn("C999", adapter.open_channels)

    def test_remove_open_channel(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(
            bot_token="xoxb-test", app_token="xapp-test", open_channels=["C999"]
        )
        adapter.remove_open_channel("C999")
        self.assertNotIn("C999", adapter.open_channels)

    def test_remove_nonexistent_channel_is_safe(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")
        adapter.remove_open_channel("C_MISSING")  # should not raise


# ---------------------------------------------------------------------------
# 2. Message splitting
# ---------------------------------------------------------------------------

class TestMessageSplitting(unittest.TestCase):

    def setUp(self):
        from antarisbot.channels.slack import SlackAdapter
        self.adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")

    def test_short_message_not_split(self):
        result = self.adapter._split_message("Hello!")
        self.assertEqual(result, ["Hello!"])

    def test_exact_limit_not_split(self):
        text = "x" * 4000
        result = self.adapter._split_message(text)
        self.assertEqual(len(result), 1)

    def test_over_limit_splits(self):
        # Two lines of 2500 chars each → must split into two chunks
        line = "a" * 2500
        text = line + "\n" + line
        result = self.adapter._split_message(text)
        self.assertGreater(len(result), 1)

    def test_split_respects_newlines(self):
        # Split should happen at newline boundaries, not mid-word
        part = "word " * 500  # ~2500 chars
        text = part.strip() + "\n" + part.strip()
        result = self.adapter._split_message(text)
        for chunk in result:
            self.assertLessEqual(len(chunk), 4000)

    def test_custom_limit(self):
        text = "hello\nworld"
        result = self.adapter._split_message(text, limit=5)
        # "hello" is 5 chars — fits; "world" is next chunk
        self.assertEqual(len(result), 2)

    def test_empty_string(self):
        result = self.adapter._split_message("")
        self.assertEqual(result, [""])


# ---------------------------------------------------------------------------
# 3. Routing logic — _route_message
# ---------------------------------------------------------------------------

class TestMessageRouting(unittest.IsolatedAsyncioTestCase):
    """Test _route_message routing decisions."""

    async def asyncSetUp(self):
        from antarisbot.channels.slack import SlackAdapter
        self.adapter = SlackAdapter(
            bot_token="xoxb-test",
            app_token="xapp-test",
            open_channels=["C_OPEN"],
        )
        self.adapter._bot_user_id = "UBOT"

        # Record what _handler was called with
        self.received = []

        async def fake_handler(inbound):
            self.received.append(inbound)

        self.adapter.on_message(fake_handler)

        # Fake say/client
        self.say = AsyncMock()
        self.client = AsyncMock()
        self.client.users_info = AsyncMock(
            return_value={"user": {"profile": {"display_name": "testuser"}}}
        )

    async def test_dm_always_responds(self):
        event = _dm_event(text="hello")
        await self.adapter._route_message(event, self.say, self.client)
        self.assertEqual(len(self.received), 1)

    async def test_open_channel_responds(self):
        event = _make_event(channel="C_OPEN", text="hello")
        await self.adapter._route_message(event, self.say, self.client)
        self.assertEqual(len(self.received), 1)

    async def test_non_open_channel_ignored(self):
        event = _make_event(channel="C_CLOSED", text="hello")
        await self.adapter._route_message(event, self.say, self.client)
        self.assertEqual(len(self.received), 0)

    async def test_mention_in_non_open_channel_responds(self):
        event = _make_event(channel="C_CLOSED", text="<@UBOT> hello")
        await self.adapter._route_message(event, self.say, self.client)
        self.assertEqual(len(self.received), 1)

    async def test_mention_stripped_from_text(self):
        event = _make_event(channel="C_CLOSED", text="<@UBOT> hello there")
        await self.adapter._route_message(event, self.say, self.client)
        self.assertEqual(self.received[0].text, "hello there")

    async def test_is_mention_flag_set(self):
        event = _make_event(channel="C_CLOSED", text="<@UBOT> help")
        await self.adapter._route_message(event, self.say, self.client, is_mention=True)
        self.assertTrue(self.received[0].metadata["is_mention"])

    async def test_subtype_ignored(self):
        event = _make_event(subtype="message_changed", text="edit")
        await self.adapter._route_message(event, self.say, self.client)
        self.assertEqual(len(self.received), 0)

    async def test_bot_message_ignored(self):
        event = _make_event(bot_id="BOTHER", text="I am a bot")
        await self.adapter._route_message(event, self.say, self.client)
        self.assertEqual(len(self.received), 0)

    async def test_own_user_ignored(self):
        event = _make_event(user="UBOT", text="my own message")
        await self.adapter._route_message(event, self.say, self.client)
        self.assertEqual(len(self.received), 0)

    async def test_empty_text_after_strip_ignored(self):
        event = _make_event(channel="C_OPEN", text="  ")
        await self.adapter._route_message(event, self.say, self.client)
        self.assertEqual(len(self.received), 0)

    async def test_platform_is_slack(self):
        event = _dm_event(text="hi")
        await self.adapter._route_message(event, self.say, self.client)
        self.assertEqual(self.received[0].platform, "slack")

    async def test_no_open_channels_responds_everywhere(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")
        adapter._bot_user_id = "UBOT"

        received = []

        async def h(msg):
            received.append(msg)

        adapter.on_message(h)
        event = _make_event(channel="C_RANDOM", text="hey there")
        await adapter._route_message(event, self.say, self.client)
        self.assertEqual(len(received), 1)


# ---------------------------------------------------------------------------
# 4. send_message
# ---------------------------------------------------------------------------

class TestSendMessage(unittest.IsolatedAsyncioTestCase):

    async def test_send_message_calls_api(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")
        mock_app = MagicMock()
        mock_app.client.chat_postMessage = AsyncMock(return_value={"ok": True})
        adapter._app = mock_app

        await adapter.send_message("C123", "Hello!")
        mock_app.client.chat_postMessage.assert_called_once_with(
            channel="C123", text="Hello!"
        )

    async def test_send_message_splits_long_text(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")
        mock_app = MagicMock()
        mock_app.client.chat_postMessage = AsyncMock(return_value={"ok": True})
        adapter._app = mock_app

        long_text = ("line\n" * 1001)  # >4000 chars
        await adapter.send_message("C123", long_text)
        self.assertGreater(mock_app.client.chat_postMessage.call_count, 1)

    async def test_send_message_no_app_is_noop(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")
        # _app is None — should not raise
        await adapter.send_message("C123", "test")


# ---------------------------------------------------------------------------
# 5. Config round-trip
# ---------------------------------------------------------------------------

class TestConfigSlackFields(unittest.TestCase):

    def test_config_has_slack_fields(self):
        from antarisbot.core.config import Config
        cfg = Config()
        self.assertEqual(cfg.slack_bot_token, "")
        self.assertEqual(cfg.slack_app_token, "")
        self.assertFalse(cfg.slack_enabled)
        self.assertEqual(cfg.slack_open_channels, [])

    def test_config_save_load_roundtrip(self):
        from antarisbot.core.config import Config
        with tempfile.NamedTemporaryFile(
            suffix=".json", mode="w", delete=False
        ) as f:
            tmp_path = f.name

        try:
            cfg = Config()
            cfg.api_key = "test-key"
            cfg.slack_bot_token = "xoxb-roundtrip"
            cfg.slack_app_token = "xapp-roundtrip"
            cfg.slack_enabled = True
            cfg.slack_open_channels = ["C111", "C222"]
            cfg.save(tmp_path)

            loaded = Config.load(tmp_path)
            self.assertIsNotNone(loaded)
            self.assertEqual(loaded.slack_bot_token, "xoxb-roundtrip")
            self.assertEqual(loaded.slack_app_token, "xapp-roundtrip")
            self.assertTrue(loaded.slack_enabled)
            self.assertIn("C111", loaded.slack_open_channels)
            self.assertIn("C222", loaded.slack_open_channels)
        finally:
            os.unlink(tmp_path)

    def test_config_validate_slack_missing_bot_token(self):
        from antarisbot.core.config import Config
        cfg = Config()
        cfg.api_key = "key"
        cfg.slack_enabled = True
        cfg.slack_app_token = "xapp-test"
        errors = cfg.validate()
        self.assertTrue(any("bot token" in e.lower() for e in errors))

    def test_config_validate_slack_missing_app_token(self):
        from antarisbot.core.config import Config
        cfg = Config()
        cfg.api_key = "key"
        cfg.slack_enabled = True
        cfg.slack_bot_token = "xoxb-test"
        errors = cfg.validate()
        self.assertTrue(any("app token" in e.lower() for e in errors))

    def test_config_validate_slack_ok_when_disabled(self):
        from antarisbot.core.config import Config
        cfg = Config()
        cfg.api_key = "key"
        cfg.slack_enabled = False
        errors = cfg.validate()
        slack_errors = [e for e in errors if "slack" in e.lower()]
        self.assertEqual(slack_errors, [])


# ---------------------------------------------------------------------------
# 6. CLI — slack-token command
# ---------------------------------------------------------------------------

class TestCliSlackToken(unittest.TestCase):

    def _run_cli(self, argv, cfg):
        """Run the CLI config slack-token command with a temp config."""
        with tempfile.NamedTemporaryFile(
            suffix=".json", mode="w", delete=False
        ) as f:
            tmp_path = f.name

        try:
            cfg.api_key = "test-key"
            cfg.save(tmp_path)

            # Patch Config.load to return our test config from the temp path
            with patch("antarisbot.cli.Config") as mock_config_cls:
                mock_config_cls.load.return_value = cfg

                # Redirect save
                saved_cfg = {}

                def fake_save(path=None):
                    saved_cfg["bot_token"] = cfg.slack_bot_token
                    saved_cfg["app_token"] = cfg.slack_app_token
                    saved_cfg["enabled"] = cfg.slack_enabled

                cfg.save = fake_save

                import io
                from unittest.mock import patch as _patch
                with _patch("sys.argv", argv), _patch("sys.stdout", new_callable=io.StringIO) as mock_out:
                    try:
                        from antarisbot import cli
                        cli.main()
                    except SystemExit:
                        pass
                    output = mock_out.getvalue()

            return saved_cfg, output
        finally:
            os.unlink(tmp_path)

    def test_slack_token_sets_tokens(self):
        from antarisbot.core.config import Config
        cfg = Config()

        saved = {}
        enabled = {}

        # Config is imported inside the CLI function body, so patch it there
        with patch("antarisbot.core.config.Config") as mock_cls:
            mock_cls.load.return_value = cfg

            def fake_save(path=None):
                saved["bot"] = cfg.slack_bot_token
                saved["app"] = cfg.slack_app_token
                enabled["v"] = cfg.slack_enabled

            cfg.save = fake_save

            import io
            with patch("sys.argv", ["antaris", "config", "slack-token", "xoxb-test", "xapp-test"]):
                with patch("sys.stdout", new_callable=io.StringIO):
                    try:
                        from antarisbot import cli
                        cli.main()
                    except SystemExit:
                        pass

        self.assertEqual(saved.get("bot"), "xoxb-test")
        self.assertEqual(saved.get("app"), "xapp-test")
        self.assertTrue(enabled.get("v"))

    def test_slack_token_missing_args_prints_usage(self):
        from antarisbot.core.config import Config
        cfg = Config()
        cfg.api_key = "key"

        with patch("antarisbot.core.config.Config") as mock_cls:
            mock_cls.load.return_value = cfg

            import io
            with patch("sys.argv", ["antaris", "config", "slack-token"]):
                with patch("sys.stdout", new_callable=io.StringIO) as mock_out:
                    try:
                        from antarisbot import cli
                        cli.main()
                    except SystemExit:
                        pass
                    output = mock_out.getvalue()

        self.assertIn("Usage", output)

    def test_cli_version_is_050(self):
        from antarisbot.cli import VERSION
        self.assertEqual(VERSION, "0.5.0")


# ---------------------------------------------------------------------------
# 7. Token validation endpoint (_validate_slack)
# ---------------------------------------------------------------------------

class TestValidateSlack(unittest.TestCase):

    @patch("antarisbot.setup.server.urlopen")
    def test_valid_token_returns_true(self, mock_urlopen):
        from antarisbot.setup.server import _validate_slack
        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = json.dumps({"ok": True, "user": "testbot"}).encode()
        mock_urlopen.return_value = mock_resp

        valid, error = _validate_slack("xoxb-valid")
        self.assertTrue(valid)
        self.assertIsNone(error)

    @patch("antarisbot.setup.server.urlopen")
    def test_invalid_token_returns_false(self, mock_urlopen):
        from antarisbot.setup.server import _validate_slack
        mock_resp = MagicMock()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_resp.read.return_value = json.dumps({"ok": False, "error": "invalid_auth"}).encode()
        mock_urlopen.return_value = mock_resp

        valid, error = _validate_slack("xoxb-bad")
        self.assertFalse(valid)
        self.assertEqual(error, "invalid_auth")

    @patch("antarisbot.setup.server._validate_token")
    def test_validate_token_routes_slack(self, mock_validate):
        from antarisbot.setup.server import _validate_token
        mock_validate.return_value = (True, None)
        # Ensure the routing works (mock the whole function for simplicity)
        valid, err = mock_validate("slack", "xoxb-test")
        mock_validate.assert_called_once_with("slack", "xoxb-test")

    @patch("antarisbot.setup.server.urlopen")
    def test_http_error_returns_false(self, mock_urlopen):
        from antarisbot.setup.server import _validate_slack
        from urllib.error import HTTPError
        mock_urlopen.side_effect = HTTPError(
            url="https://slack.com/api/auth.test",
            code=403,
            msg="Forbidden",
            hdrs=None,
            fp=None,
        )
        valid, error = _validate_slack("xoxb-bad")
        self.assertFalse(valid)
        self.assertIn("403", error)


# ---------------------------------------------------------------------------
# 8. connect/disconnect lifecycle (mocked)
# ---------------------------------------------------------------------------

class TestConnectDisconnect(unittest.IsolatedAsyncioTestCase):

    async def test_disconnect_sets_stop_event(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")
        import asyncio
        adapter._stop_event = asyncio.Event()
        await adapter.disconnect()
        self.assertTrue(adapter._stop_event.is_set())

    async def test_stop_is_alias_for_disconnect(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")
        import asyncio
        adapter._stop_event = asyncio.Event()
        await adapter.stop()
        self.assertTrue(adapter._stop_event.is_set())

    async def test_disconnect_no_stop_event_is_safe(self):
        from antarisbot.channels.slack import SlackAdapter
        adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")
        # _stop_event is None — should not raise
        await adapter.disconnect()

    async def test_send_delegates_to_send_message(self):
        from antarisbot.channels.slack import SlackAdapter
        from antarisbot.channels.base import OutboundMessage
        adapter = SlackAdapter(bot_token="xoxb-test", app_token="xapp-test")
        mock_app = MagicMock()
        mock_app.client.chat_postMessage = AsyncMock(return_value={"ok": True})
        adapter._app = mock_app

        msg = OutboundMessage(channel_id="C_OUT", text="hi")
        await adapter.send(msg)
        mock_app.client.chat_postMessage.assert_called_once_with(channel="C_OUT", text="hi")


if __name__ == "__main__":
    unittest.main()
