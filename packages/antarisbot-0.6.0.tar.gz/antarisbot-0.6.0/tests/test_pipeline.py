"""Tests for the Pipeline and Bot classes."""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from antarisbot.core.pipeline import Pipeline, PipelineResult, MAX_HISTORY
from antarisbot.channels.base import InboundMessage, OutboundMessage
from antarisbot.llm.base import Message, LLMResponse


def make_inbound(text="Hello bot", user_id="user-123", channel_id="ch-1", platform="terminal"):
    return InboundMessage(
        id="msg-1",
        user_id=user_id,
        user_name="TestUser",
        channel_id=channel_id,
        platform=platform,
        text=text,
        timestamp_ms=0,
    )


def make_pipeline():
    """Build a Pipeline with mocked dependencies."""
    config = MagicMock()
    config.model = "claude-sonnet-4-20250514"
    config.rate_limit_messages = 20
    config.rate_limit_window_seconds = 60

    memory = MagicMock()
    memory.recall = AsyncMock(return_value=["User likes cats"])
    memory.ingest = AsyncMock()

    guard = MagicMock()
    guard.check_input = AsyncMock(return_value=(True, ""))
    guard.check_output = AsyncMock(return_value=(True, "Response text"))

    persona = MagicMock()
    persona.build_system_prompt = MagicMock(return_value="You are Antaris.")
    persona.config_dir = ""  # empty → no UserTracker created

    llm = MagicMock()
    llm.complete = AsyncMock(return_value=LLMResponse(
        content="Response text",
        model="claude-sonnet-4-20250514",
        input_tokens=100,
        output_tokens=50,
        cost_usd=0.001,
    ))

    adapter = MagicMock()
    adapter.format_for_surface = MagicMock(side_effect=lambda x: x)

    return Pipeline(config, memory, guard, persona, llm), adapter


# ── Pipeline tests ──────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_pipeline_success():
    pipeline, adapter = make_pipeline()
    result = await pipeline.process(make_inbound(), adapter)
    assert result.success is True
    assert result.response_text == "Response text"
    assert result.blocked is False
    assert result.tokens_used == 150
    assert result.cost_usd == pytest.approx(0.001)


@pytest.mark.asyncio
async def test_pipeline_calls_all_stages():
    pipeline, adapter = make_pipeline()
    inbound = make_inbound(text="I like dogs")
    await pipeline.process(inbound, adapter)

    pipeline.guard.check_input.assert_awaited_once()
    pipeline.memory.recall.assert_awaited_once()
    pipeline.persona.build_system_prompt.assert_called_once()
    pipeline.llm.complete.assert_awaited_once()
    pipeline.guard.check_output.assert_awaited_once()
    pipeline.memory.ingest.assert_awaited_once()
    adapter.format_for_surface.assert_called_once()


@pytest.mark.asyncio
async def test_pipeline_blocked_by_guard():
    pipeline, adapter = make_pipeline()
    pipeline.guard.check_input = AsyncMock(return_value=(False, "policy violation"))

    result = await pipeline.process(make_inbound(text="bad input"), adapter)

    assert result.blocked is True
    assert result.block_reason == "policy violation"
    assert "can't respond" in result.response_text.lower()
    # LLM should NOT have been called
    pipeline.llm.complete.assert_not_awaited()


@pytest.mark.asyncio
async def test_pipeline_memory_recall_failure_is_graceful():
    """Memory failure should not crash the pipeline."""
    pipeline, adapter = make_pipeline()
    pipeline.memory.recall = AsyncMock(side_effect=Exception("disk error"))

    result = await pipeline.process(make_inbound(), adapter)
    assert result.success is True  # still responds
    assert result.response_text == "Response text"


@pytest.mark.asyncio
async def test_pipeline_memory_ingest_failure_is_graceful():
    """Ingest failure should not crash the pipeline."""
    pipeline, adapter = make_pipeline()
    pipeline.memory.ingest = AsyncMock(side_effect=Exception("write error"))

    result = await pipeline.process(make_inbound(), adapter)
    assert result.success is True


@pytest.mark.asyncio
async def test_pipeline_llm_failure_returns_error_result():
    pipeline, adapter = make_pipeline()
    pipeline.llm.complete = AsyncMock(side_effect=RuntimeError("API down"))

    result = await pipeline.process(make_inbound(), adapter)
    assert result.success is False
    assert result.error == "API down"
    assert "trouble" in result.response_text.lower() or "something went wrong" in result.response_text.lower()


@pytest.mark.asyncio
async def test_pipeline_injects_recalled_memories_into_prompt():
    pipeline, adapter = make_pipeline()
    pipeline.memory.recall = AsyncMock(return_value=["user likes cats", "user is from NYC"])

    await pipeline.process(make_inbound(), adapter)

    call_args = pipeline.persona.build_system_prompt.call_args
    memories = call_args[0][0]  # positional arg
    assert "user likes cats" in memories
    assert "user is from NYC" in memories


@pytest.mark.asyncio
async def test_pipeline_passes_previous_history_to_llm():
    pipeline, adapter = make_pipeline()
    pipeline._cooldown_seconds = 0  # disable rate limiting for this test
    inbound1 = make_inbound(text="My name is Alice")
    inbound2 = make_inbound(text="What is my name?")

    await pipeline.process(inbound1, adapter)
    await pipeline.process(inbound2, adapter)

    # Second call should include history
    second_call_messages = pipeline.llm.complete.call_args_list[1][1]["messages"]
    texts = [m.content for m in second_call_messages]
    assert "My name is Alice" in texts


@pytest.mark.asyncio
async def test_pipeline_formats_for_surface():
    pipeline, adapter = make_pipeline()
    adapter.format_for_surface = MagicMock(return_value="formatted!")

    result = await pipeline.process(make_inbound(), adapter)
    assert result.response_text == "formatted!"


# ── History management tests ────────────────────────────────────────────────

def test_history_starts_empty():
    pipeline, _ = make_pipeline()
    assert pipeline.history_length("user-x") == 0


@pytest.mark.asyncio
async def test_history_grows_per_turn():
    pipeline, adapter = make_pipeline()
    await pipeline.process(make_inbound(user_id="u1"), adapter)
    assert pipeline.history_length("u1") == 2  # user + assistant


@pytest.mark.asyncio
async def test_history_trimmed_to_max():
    pipeline, adapter = make_pipeline()
    pipeline._cooldown_seconds = 0  # disable rate limiting so all turns are processed
    for _ in range(MAX_HISTORY + 5):
        await pipeline.process(make_inbound(user_id="u1"), adapter)
    assert pipeline.history_length("u1") <= MAX_HISTORY


@pytest.mark.asyncio
async def test_history_isolated_per_user():
    pipeline, adapter = make_pipeline()
    await pipeline.process(make_inbound(user_id="alice"), adapter)
    await pipeline.process(make_inbound(user_id="bob"), adapter)
    assert pipeline.history_length("alice") == 2
    assert pipeline.history_length("bob") == 2


def test_clear_history():
    pipeline, _ = make_pipeline()
    pipeline._history["u1"] = [Message(role="user", content="hi")]
    pipeline.clear_history("u1")
    assert pipeline.history_length("u1") == 0


def test_clear_history_nonexistent_user():
    pipeline, _ = make_pipeline()
    pipeline.clear_history("nobody")  # should not raise


# ── Rate limiting tests ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_rate_limiting_blocks_rapid_messages():
    pipeline, adapter = make_pipeline()
    pipeline._cooldown_seconds = 60  # very long cooldown for testing

    # First message goes through
    result1 = await pipeline.process(make_inbound(user_id="rapid-user"), adapter)
    assert result1.response_text != "" or result1.blocked

    # Second message within cooldown returns empty response
    result2 = await pipeline.process(make_inbound(user_id="rapid-user"), adapter)
    assert result2.response_text == ""


@pytest.mark.asyncio
async def test_rate_limiting_different_users_independent():
    pipeline, adapter = make_pipeline()
    pipeline._cooldown_seconds = 60

    result1 = await pipeline.process(make_inbound(user_id="user-a"), adapter)
    result2 = await pipeline.process(make_inbound(user_id="user-b"), adapter)

    # Different users don't interfere
    assert result2.response_text != ""


# ── Bot tests ───────────────────────────────────────────────────────────────

def test_bot_imports():
    from antarisbot.core.bot import Bot
    assert Bot is not None


def test_pipeline_result_defaults():
    r = PipelineResult(success=True, response_text="hi")
    assert r.blocked is False
    assert r.block_reason == ""
    assert r.tokens_used == 0
    assert r.cost_usd == 0.0
    assert r.error is None
