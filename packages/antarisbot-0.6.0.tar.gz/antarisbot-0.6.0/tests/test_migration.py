"""Tests for the AntarisBot migration framework."""
import json
import tempfile
import shutil
from pathlib import Path

import pytest

from antarisbot.migration.base import MigrationResult
from antarisbot.migration.openclaw import OpenClawMigration
from antarisbot.migration.custom import CustomMigration
from antarisbot.migration.mem0 import Mem0Migration
from antarisbot.migration import (
    MigrationSource,
    OpenClawMigration,
    Mem0Migration,
    CustomMigration,
)


# ── MigrationResult.summary() ─────────────────────────────────────────────────

class TestMigrationResultSummary:
    def test_success_booleans(self):
        result = MigrationResult(
            success=True,
            source="TestSource",
            items_migrated={"soul": True, "user": False},
        )
        summary = result.summary()
        assert "Migration from TestSource:" in summary
        assert "✅" in summary
        assert "soul" in summary
        assert "skipped" in summary
        assert "user" in summary

    def test_numeric_value(self):
        result = MigrationResult(
            success=True,
            source="TestSource",
            items_migrated={"memories": 42},
        )
        summary = result.summary()
        assert "memories: 42" in summary

    def test_warnings_appear(self):
        result = MigrationResult(
            success=True,
            source="TestSource",
            warnings=["Something was skipped"],
        )
        summary = result.summary()
        assert "Something was skipped" in summary
        assert "⚠️" in summary

    def test_errors_appear(self):
        result = MigrationResult(
            success=False,
            source="TestSource",
            errors=["Something blew up"],
        )
        summary = result.summary()
        assert "Something blew up" in summary
        assert "❌" in summary

    def test_empty_result(self):
        result = MigrationResult(success=True, source="Empty")
        summary = result.summary()
        assert "Migration from Empty:" in summary


# ── OpenClawMigration.detect() ─────────────────────────────────────────────────

class TestOpenClawDetect:
    def test_detect_true_with_soul_md(self, tmp_path):
        (tmp_path / "SOUL.md").write_text("# Bot persona")
        m = OpenClawMigration(str(tmp_path), str(tmp_path / "dest"))
        assert m.detect() is True

    def test_detect_true_with_agents_md(self, tmp_path):
        (tmp_path / "AGENTS.md").write_text("# Workspace")
        m = OpenClawMigration(str(tmp_path), str(tmp_path / "dest"))
        assert m.detect() is True

    def test_detect_false_when_nothing_found(self, tmp_path):
        m = OpenClawMigration(str(tmp_path), str(tmp_path / "dest"))
        assert m.detect() is False

    def test_detect_false_for_nonexistent_path(self, tmp_path):
        m = OpenClawMigration(str(tmp_path / "nonexistent"), str(tmp_path / "dest"))
        assert m.detect() is False


# ── OpenClawMigration.migrate() ────────────────────────────────────────────────

class TestOpenClawMigrate:
    def test_copies_soul_md(self, tmp_path):
        src = tmp_path / "src"
        dest = tmp_path / "dest"
        src.mkdir()
        (src / "SOUL.md").write_text("# My Bot\nPersona content here")

        m = OpenClawMigration(str(src), str(dest))
        result = m.migrate()

        assert result.success is True
        assert result.items_migrated["soul"] is True
        assert (dest / "SOUL.md").exists()
        assert "Persona content here" in (dest / "SOUL.md").read_text()

    def test_handles_missing_soul_md_gracefully(self, tmp_path):
        src = tmp_path / "src"
        dest = tmp_path / "dest"
        src.mkdir()
        # Provide AGENTS.md so detect() passes, but no SOUL.md
        (src / "AGENTS.md").write_text("# Workspace")

        m = OpenClawMigration(str(src), str(dest))
        result = m.migrate()

        assert result.success is True  # migration runs, just marks soul as False
        assert result.items_migrated["soul"] is False
        assert any("SOUL.md" in w for w in result.warnings)
        assert not (dest / "SOUL.md").exists()

    def test_merges_identity_md_into_soul(self, tmp_path):
        src = tmp_path / "src"
        dest = tmp_path / "dest"
        src.mkdir()
        (src / "SOUL.md").write_text("# Bot Persona\n")
        (src / "IDENTITY.md").write_text("## I am Shiro")

        m = OpenClawMigration(str(src), str(dest))
        result = m.migrate()

        soul_text = (dest / "SOUL.md").read_text()
        assert "Bot Persona" in soul_text
        assert "I am Shiro" in soul_text
        assert "## Identity" in soul_text

    def test_copies_user_md(self, tmp_path):
        src = tmp_path / "src"
        dest = tmp_path / "dest"
        src.mkdir()
        (src / "SOUL.md").write_text("# Bot")
        (src / "USER.md").write_text("# User info")

        m = OpenClawMigration(str(src), str(dest))
        result = m.migrate()

        assert result.items_migrated["user"] is True
        assert (dest / "USER.md").read_text() == "# User info"

    def test_missing_user_md_marks_false(self, tmp_path):
        src = tmp_path / "src"
        dest = tmp_path / "dest"
        src.mkdir()
        (src / "SOUL.md").write_text("# Bot")

        m = OpenClawMigration(str(src), str(dest))
        result = m.migrate()

        assert result.items_migrated["user"] is False

    def test_dry_run_does_not_write_files(self, tmp_path):
        src = tmp_path / "src"
        dest = tmp_path / "dest"
        src.mkdir()
        (src / "SOUL.md").write_text("# Persona")
        (src / "USER.md").write_text("# User")

        m = OpenClawMigration(str(src), str(dest), dry_run=True)
        result = m.migrate()

        assert not (dest / "SOUL.md").exists()
        assert not (dest / "USER.md").exists()

    def test_migrates_memory_files_and_returns_count(self, tmp_path):
        src = tmp_path / "src"
        dest = tmp_path / "dest"
        src.mkdir()
        (src / "SOUL.md").write_text("# Bot")

        memory_dir = src / "memory"
        memory_dir.mkdir()
        (memory_dir / "2026-01-01.md").write_text("Memory 1")
        (memory_dir / "2026-01-02.md").write_text("Memory 2")
        sub = memory_dir / "subdir"
        sub.mkdir()
        (sub / "deep.md").write_text("Deep memory")

        m = OpenClawMigration(str(src), str(dest))
        result = m.migrate()

        assert result.items_migrated["memories"] == 3
        migrated_dest = dest / "memory" / "migrated-user"
        assert (migrated_dest / "2026-01-01.md").exists()
        assert (migrated_dest / "2026-01-02.md").exists()
        assert (migrated_dest / "subdir" / "deep.md").exists()

    def test_dry_run_memory_count_no_write(self, tmp_path):
        src = tmp_path / "src"
        dest = tmp_path / "dest"
        src.mkdir()
        (src / "SOUL.md").write_text("# Bot")

        memory_dir = src / "memory"
        memory_dir.mkdir()
        (memory_dir / "a.md").write_text("A")
        (memory_dir / "b.md").write_text("B")

        m = OpenClawMigration(str(src), str(dest), dry_run=True)
        result = m.migrate()

        assert result.items_migrated["memories"] == 2
        assert not (dest / "memory").exists()

    def test_no_memory_dir_warns(self, tmp_path):
        src = tmp_path / "src"
        dest = tmp_path / "dest"
        src.mkdir()
        (src / "SOUL.md").write_text("# Bot")

        m = OpenClawMigration(str(src), str(dest))
        result = m.migrate()

        assert result.items_migrated["memories"] == 0
        assert any("memory" in w.lower() for w in result.warnings)


# ── CustomMigration.detect() ───────────────────────────────────────────────────

class TestCustomDetect:
    def test_detect_true_for_valid_json_with_memories(self, tmp_path):
        f = tmp_path / "import.json"
        f.write_text(json.dumps({"memories": ["mem1", "mem2"]}))
        m = CustomMigration(str(f), str(tmp_path / "dest"))
        assert m.detect() is True

    def test_detect_true_for_valid_json_with_soul(self, tmp_path):
        f = tmp_path / "import.json"
        f.write_text(json.dumps({"soul": "# Bot"}))
        m = CustomMigration(str(f), str(tmp_path / "dest"))
        assert m.detect() is True

    def test_detect_false_for_invalid_json(self, tmp_path):
        f = tmp_path / "import.json"
        f.write_text("not valid json {{")
        m = CustomMigration(str(f), str(tmp_path / "dest"))
        assert m.detect() is False

    def test_detect_false_for_json_without_known_keys(self, tmp_path):
        f = tmp_path / "import.json"
        f.write_text(json.dumps({"random": "data"}))
        m = CustomMigration(str(f), str(tmp_path / "dest"))
        assert m.detect() is False

    def test_detect_false_for_directory(self, tmp_path):
        m = CustomMigration(str(tmp_path), str(tmp_path / "dest"))
        assert m.detect() is False


# ── CustomMigration.migrate() ──────────────────────────────────────────────────

class TestCustomMigrate:
    def test_imports_soul_user_and_memories(self, tmp_path):
        src_file = tmp_path / "import.json"
        dest = tmp_path / "dest"
        data = {
            "soul": "# Custom Bot\nPersona text",
            "user": "# User\nUser context",
            "memories": ["I remember thing 1", "I remember thing 2", "I remember thing 3"],
        }
        src_file.write_text(json.dumps(data))

        m = CustomMigration(str(src_file), str(dest))
        result = m.migrate()

        assert result.success is True
        assert result.items_migrated["soul"] is True
        assert result.items_migrated["user"] is True
        assert result.items_migrated["memories"] == 3

        assert "Custom Bot" in (dest / "SOUL.md").read_text()
        assert "User context" in (dest / "USER.md").read_text()
        import_md = dest / "memory" / "migrated-user" / "import.md"
        assert import_md.exists()
        content = import_md.read_text()
        assert "I remember thing 1" in content
        assert "I remember thing 2" in content
        assert "I remember thing 3" in content

    def test_partial_import_soul_only(self, tmp_path):
        src_file = tmp_path / "import.json"
        dest = tmp_path / "dest"
        src_file.write_text(json.dumps({"soul": "# Just a soul"}))

        m = CustomMigration(str(src_file), str(dest))
        result = m.migrate()

        assert result.success is True
        assert result.items_migrated.get("soul") is True
        assert "user" not in result.items_migrated
        assert "memories" not in result.items_migrated

    def test_invalid_json_returns_error(self, tmp_path):
        src_file = tmp_path / "import.json"
        dest = tmp_path / "dest"
        src_file.write_text("{ broken json ")

        m = CustomMigration(str(src_file), str(dest))
        result = m.migrate()

        assert result.success is False
        assert len(result.errors) > 0
        assert "parse" in result.errors[0].lower() or "json" in result.errors[0].lower() or "import" in result.errors[0].lower()

    def test_dry_run_does_not_write(self, tmp_path):
        src_file = tmp_path / "import.json"
        dest = tmp_path / "dest"
        src_file.write_text(json.dumps({"soul": "# Bot", "user": "# User"}))

        m = CustomMigration(str(src_file), str(dest), dry_run=True)
        result = m.migrate()

        assert not (dest / "SOUL.md").exists()
        assert not (dest / "USER.md").exists()


# ── Mem0Migration stub ─────────────────────────────────────────────────────────

class TestMem0Migration:
    def test_migrate_returns_failure_with_message(self, tmp_path):
        m = Mem0Migration(str(tmp_path), str(tmp_path / "dest"))
        result = m.migrate()
        assert result.success is False
        assert len(result.errors) > 0

    def test_detect_false_for_empty_dir(self, tmp_path):
        m = Mem0Migration(str(tmp_path), str(tmp_path / "dest"))
        assert m.detect() is False

    def test_detect_true_with_mem0_data(self, tmp_path):
        (tmp_path / "mem0_data").mkdir()
        m = Mem0Migration(str(tmp_path), str(tmp_path / "dest"))
        assert m.detect() is True


# ── __init__ exports ───────────────────────────────────────────────────────────

class TestMigrationInit:
    def test_all_classes_importable(self):
        from antarisbot.migration import (
            MigrationSource, MigrationResult,
            OpenClawMigration, Mem0Migration, CustomMigration,
        )
        assert MigrationSource is not None
        assert MigrationResult is not None
        assert OpenClawMigration is not None
        assert Mem0Migration is not None
        assert CustomMigration is not None
