"""
Tests for AntarisBot LLM provider and persona loader.
Steps 4-5: Anthropic provider + PersonaLoader
"""
import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from pathlib import Path
import tempfile
import os

from antarisbot.llm.base import Message, LLMResponse, LLMProvider
from antarisbot.llm.anthropic import AnthropicProvider, MODEL_PRICING
from antarisbot.persona.loader import PersonaLoader, DEFAULT_SOUL, DEFAULT_USER


# ---------------------------------------------------------------------------
# LLMResponse dataclass
# ---------------------------------------------------------------------------

class TestLLMResponseDataclass:
    def test_creates_correctly(self):
        resp = LLMResponse(
            content="Hello world",
            model="claude-sonnet-4-6",
            input_tokens=10,
            output_tokens=5,
            cost_usd=0.000045
        )
        assert resp.content == "Hello world"
        assert resp.model == "claude-sonnet-4-6"
        assert resp.input_tokens == 10
        assert resp.output_tokens == 5
        assert resp.cost_usd == pytest.approx(0.000045)

    def test_message_dataclass(self):
        msg = Message(role="user", content="Hi there")
        assert msg.role == "user"
        assert msg.content == "Hi there"


# ---------------------------------------------------------------------------
# AnthropicProvider — init & estimate_tokens
# ---------------------------------------------------------------------------

class TestAnthropicProviderInit:
    def test_initializes_correctly(self):
        provider = AnthropicProvider(api_key="sk-ant-test-key", model="claude-sonnet-4-6")
        assert provider.api_key == "sk-ant-test-key"
        assert provider.model == "claude-sonnet-4-6"

    def test_base_url(self):
        provider = AnthropicProvider(api_key="key", model="model")
        assert provider.BASE_URL == "https://api.anthropic.com/v1"

    def test_api_version(self):
        provider = AnthropicProvider(api_key="key", model="model")
        assert provider.API_VERSION == "2023-06-01"

    def test_estimate_tokens_basic(self):
        provider = AnthropicProvider(api_key="key", model="model")
        # "hello" = 5 chars → 5//4 = 1, but max(1, 1) = 1
        assert provider.estimate_tokens("hello") == 1

    def test_estimate_tokens_longer(self):
        provider = AnthropicProvider(api_key="key", model="model")
        text = "a" * 400  # 400 chars → 400//4 = 100
        assert provider.estimate_tokens(text) == 100

    def test_estimate_tokens_empty_returns_one(self):
        provider = AnthropicProvider(api_key="key", model="model")
        # max(1, 0) = 1
        assert provider.estimate_tokens("") == 1

    def test_model_pricing_exists(self):
        assert "claude-sonnet-4-6" in MODEL_PRICING
        assert "claude-opus-4-6" in MODEL_PRICING
        assert "claude-haiku-4-5-20251001" in MODEL_PRICING


# ---------------------------------------------------------------------------
# AnthropicProvider.complete — mocked HTTP
# ---------------------------------------------------------------------------

class TestAnthropicProviderComplete:
    def _make_mock_response(self, content="Test reply", input_tokens=10, output_tokens=5):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "id": "msg_test123",
            "type": "message",
            "role": "assistant",
            "content": [{"type": "text", "text": content}],
            "model": "claude-sonnet-4-6",
            "usage": {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens
            }
        }
        mock_resp.raise_for_status = MagicMock()
        return mock_resp

    def test_complete_returns_llm_response(self):
        provider = AnthropicProvider(api_key="sk-ant-fake", model="claude-sonnet-4-6")
        messages = [Message(role="user", content="Hello")]
        mock_resp = self._make_mock_response("Hi there!", input_tokens=20, output_tokens=8)

        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_client = AsyncMock()
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)
                mock_client.post = AsyncMock(return_value=mock_resp)
                mock_client_cls.return_value = mock_client

                result = await provider.complete(messages=messages, system="Be helpful")
            return result

        result = asyncio.run(run())
        assert isinstance(result, LLMResponse)
        assert result.content == "Hi there!"
        assert result.model == "claude-sonnet-4-6"
        assert result.input_tokens == 20
        assert result.output_tokens == 8

    def test_complete_calculates_cost(self):
        provider = AnthropicProvider(api_key="sk-ant-fake", model="claude-sonnet-4-6")
        messages = [Message(role="user", content="Hello")]
        # claude-sonnet-4-6: input=$3/M, output=$15/M
        # 1000 input + 500 output → (1000*3 + 500*15)/1e6 = (3000+7500)/1e6 = 0.0105
        mock_resp = self._make_mock_response("Reply", input_tokens=1000, output_tokens=500)

        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_client = AsyncMock()
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)
                mock_client.post = AsyncMock(return_value=mock_resp)
                mock_client_cls.return_value = mock_client

                return await provider.complete(messages=messages, system="Be helpful")

        result = asyncio.run(run())
        assert result.cost_usd == pytest.approx(0.0105)

    def test_complete_uses_override_model(self):
        provider = AnthropicProvider(api_key="sk-ant-fake", model="claude-sonnet-4-6")
        messages = [Message(role="user", content="Hello")]
        mock_resp = self._make_mock_response()

        captured_payload = {}

        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_client = AsyncMock()
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)

                async def fake_post(url, json=None, headers=None):
                    captured_payload.update(json or {})
                    return mock_resp

                mock_client.post = fake_post
                mock_client_cls.return_value = mock_client

                return await provider.complete(
                    messages=messages,
                    system="Be helpful",
                    model="claude-opus-4-6"
                )

        asyncio.run(run())
        assert captured_payload.get("model") == "claude-opus-4-6"

    def test_complete_skips_system_messages_in_messages_list(self):
        """System role messages should be excluded from the messages array."""
        provider = AnthropicProvider(api_key="sk-ant-fake", model="claude-sonnet-4-6")
        messages = [
            Message(role="system", content="Old system"),
            Message(role="user", content="Hello"),
        ]
        mock_resp = self._make_mock_response()
        captured_payload = {}

        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_client = AsyncMock()
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)

                async def fake_post(url, json=None, headers=None):
                    captured_payload.update(json or {})
                    return mock_resp

                mock_client.post = fake_post
                mock_client_cls.return_value = mock_client

                return await provider.complete(messages=messages, system="Be helpful")

        asyncio.run(run())
        roles = [m["role"] for m in captured_payload.get("messages", [])]
        assert "system" not in roles
        assert "user" in roles

    def test_complete_raises_on_401(self):
        import httpx

        provider = AnthropicProvider(api_key="bad-key", model="claude-sonnet-4-6")
        messages = [Message(role="user", content="Hello")]

        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_client = AsyncMock()
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)

                mock_resp = MagicMock()
                mock_resp.status_code = 401
                mock_resp.text = "Unauthorized"

                def raise_401():
                    raise httpx.HTTPStatusError(
                        "401 Unauthorized",
                        request=MagicMock(),
                        response=mock_resp
                    )

                mock_resp.raise_for_status = raise_401
                mock_client.post = AsyncMock(return_value=mock_resp)
                mock_client_cls.return_value = mock_client

                await provider.complete(messages=messages, system="Be helpful")

        with pytest.raises(ValueError, match="Invalid Anthropic API key"):
            asyncio.run(run())

    def test_complete_raises_on_429(self):
        import httpx

        provider = AnthropicProvider(api_key="sk-ant-fake", model="claude-sonnet-4-6")
        messages = [Message(role="user", content="Hello")]

        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_client = AsyncMock()
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)

                mock_resp = MagicMock()
                mock_resp.status_code = 429
                mock_resp.text = "Rate limited"

                def raise_429():
                    raise httpx.HTTPStatusError(
                        "429 Too Many Requests",
                        request=MagicMock(),
                        response=mock_resp
                    )

                mock_resp.raise_for_status = raise_429
                mock_client.post = AsyncMock(return_value=mock_resp)
                mock_client_cls.return_value = mock_client

                await provider.complete(messages=messages, system="Be helpful")

        with pytest.raises(RuntimeError, match="rate limit"):
            asyncio.run(run())


# ---------------------------------------------------------------------------
# PersonaLoader
# ---------------------------------------------------------------------------

class TestPersonaLoader:
    def test_returns_default_soul_when_no_file(self, tmp_path):
        loader = PersonaLoader(config_dir=str(tmp_path))
        soul = loader.load_soul()
        assert soul == DEFAULT_SOUL

    def test_loads_soul_from_file(self, tmp_path):
        soul_file = tmp_path / "SOUL.md"
        soul_file.write_text("# Custom Soul\nBe awesome.")
        loader = PersonaLoader(config_dir=str(tmp_path))
        assert loader.load_soul() == "# Custom Soul\nBe awesome."

    def test_load_user_returns_none_when_no_file(self, tmp_path):
        loader = PersonaLoader(config_dir=str(tmp_path))
        assert loader.load_user() is None

    def test_load_user_returns_none_for_placeholder(self, tmp_path):
        user_file = tmp_path / "USER.md"
        user_file.write_text(DEFAULT_USER)
        loader = PersonaLoader(config_dir=str(tmp_path))
        assert loader.load_user() is None

    def test_load_user_returns_none_for_short_content(self, tmp_path):
        user_file = tmp_path / "USER.md"
        user_file.write_text("short")
        loader = PersonaLoader(config_dir=str(tmp_path))
        assert loader.load_user() is None

    def test_load_user_returns_content_when_sufficient(self, tmp_path):
        user_file = tmp_path / "USER.md"
        user_file.write_text("I am a software engineer who loves Python and building AI tools for personal use.")
        loader = PersonaLoader(config_dir=str(tmp_path))
        result = loader.load_user()
        assert result is not None
        assert "software engineer" in result

    def test_build_system_prompt_default(self, tmp_path):
        loader = PersonaLoader(config_dir=str(tmp_path))
        prompt = loader.build_system_prompt()
        assert DEFAULT_SOUL in prompt

    def test_build_system_prompt_with_memories(self, tmp_path):
        loader = PersonaLoader(config_dir=str(tmp_path))
        memories = ["User likes Python", "User prefers dark mode", "User works remotely"]
        prompt = loader.build_system_prompt(memories=memories)
        assert "User likes Python" in prompt
        assert "User prefers dark mode" in prompt
        assert "Relevant memories from past conversations" in prompt

    def test_build_system_prompt_limits_memories_to_15(self, tmp_path):
        loader = PersonaLoader(config_dir=str(tmp_path))
        memories = [f"Memory {i}" for i in range(25)]
        prompt = loader.build_system_prompt(memories=memories)
        # Only first 15 should appear
        assert "Memory 14" in prompt
        assert "Memory 15" not in prompt

    def test_build_system_prompt_includes_user_context(self, tmp_path):
        user_file = tmp_path / "USER.md"
        user_file.write_text("I am a software engineer who loves Python and building AI tools for personal use.")
        loader = PersonaLoader(config_dir=str(tmp_path))
        prompt = loader.build_system_prompt()
        assert "About the person I'm talking to" in prompt
        assert "software engineer" in prompt

    def test_build_system_prompt_no_user_section_when_empty(self, tmp_path):
        loader = PersonaLoader(config_dir=str(tmp_path))
        prompt = loader.build_system_prompt()
        assert "About the person I'm talking to" not in prompt

    def test_build_system_prompt_empty_memories_list(self, tmp_path):
        loader = PersonaLoader(config_dir=str(tmp_path))
        prompt = loader.build_system_prompt(memories=[])
        assert "Relevant memories" not in prompt

    def test_update_user_context_creates_file(self, tmp_path):
        loader = PersonaLoader(config_dir=str(tmp_path))
        loader.update_user_context("User prefers to be called Alex.")
        assert loader.user_path.exists()
        content = loader.user_path.read_text()
        assert "User prefers to be called Alex." in content

    def test_update_user_context_does_not_duplicate(self, tmp_path):
        loader = PersonaLoader(config_dir=str(tmp_path))
        loader.update_user_context("User prefers to be called Alex.")
        loader.update_user_context("User prefers to be called Alex.")
        content = loader.user_path.read_text()
        assert content.count("User prefers to be called Alex.") == 1

    def test_reload_is_noop(self, tmp_path):
        """reload() should not raise and hot-reload works via file reads."""
        loader = PersonaLoader(config_dir=str(tmp_path))
        loader.reload()  # Should not raise


# ---------------------------------------------------------------------------
# OpenAI provider — basic smoke (full tests in test_openai_provider.py)
# ---------------------------------------------------------------------------

class TestOpenAIProviderSmoke:
    def test_initializes(self):
        from antarisbot.llm.openai import OpenAIProvider
        provider = OpenAIProvider(api_key="sk-test", model="gpt-4o")
        assert provider.api_key == "sk-test"
        assert provider.model == "gpt-4o"
        assert provider.BASE_URL == "https://api.openai.com/v1"

    def test_estimate_tokens(self):
        from antarisbot.llm.openai import OpenAIProvider
        provider = OpenAIProvider(api_key="sk-test", model="gpt-4o")
        assert provider.estimate_tokens("hello") == 1  # 5 chars → max(1, 5//4=1)
        assert provider.estimate_tokens("a" * 400) == 100
        assert provider.estimate_tokens("") == 1
