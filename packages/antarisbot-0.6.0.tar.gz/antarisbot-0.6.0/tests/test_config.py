"""Tests for antarisbot.core.config"""

import json
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from antarisbot.core.config import Config, run_init_wizard, DEFAULT_CONFIG_DIR, DEFAULT_CONFIG_PATH


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

VALID_CONFIG_DATA = {
    "bot": {"name": "TestBot"},
    "provider": {
        "name": "anthropic",
        "apiKey": "sk-test-key-123",
        "model": "claude-sonnet-4-20250514",
        "fallbackModel": "claude-haiku-4-5-20251001"
    },
    "channels": {
        "discord": {"enabled": True, "token": "discord-token-abc"},
        "telegram": {"enabled": False, "token": ""}
    },
    "memory": {
        "store": "/tmp/test-memory",
        "searchLimit": 5,
        "minRelevance": 0.5,
        "autoIngest": True,
        "autoRecall": True
    },
    "guard": {"mode": "warn"},
    "context": {"maxTokens": 50000}
}


# ---------------------------------------------------------------------------
# Config.load()
# ---------------------------------------------------------------------------

class TestConfigLoad:
    def test_load_valid_data(self, tmp_path):
        """Config.load() should parse all fields correctly from valid JSON."""
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(VALID_CONFIG_DATA))

        cfg = Config.load(str(config_file))

        assert cfg is not None
        assert cfg.bot_name == "TestBot"
        assert cfg.provider_name == "anthropic"
        assert cfg.api_key == "sk-test-key-123"
        assert cfg.model == "claude-sonnet-4-20250514"
        assert cfg.fallback_model == "claude-haiku-4-5-20251001"
        assert cfg.discord_enabled is True
        assert cfg.discord_token == "discord-token-abc"
        assert cfg.telegram_enabled is False
        assert cfg.memory_store == "/tmp/test-memory"
        assert cfg.memory_search_limit == 5
        assert cfg.memory_min_relevance == 0.5
        assert cfg.guard_mode == "warn"
        assert cfg.config_path == str(config_file)

    def test_load_missing_file_returns_none(self, tmp_path):
        """Config.load() should return None when the config file doesn't exist."""
        missing = tmp_path / "nonexistent.json"
        result = Config.load(str(missing))
        assert result is None

    def test_load_uses_defaults_for_missing_keys(self, tmp_path):
        """Config.load() should fill in defaults when keys are absent."""
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({}))  # empty config

        cfg = Config.load(str(config_file))

        assert cfg is not None
        assert cfg.bot_name == "Antaris"
        assert cfg.provider_name == "anthropic"
        assert cfg.api_key == ""
        assert cfg.model == "claude-sonnet-4-20250514"
        assert cfg.guard_mode == "monitor"


# ---------------------------------------------------------------------------
# Config.validate()
# ---------------------------------------------------------------------------

class TestConfigValidate:
    def test_validate_catches_missing_api_key(self):
        """validate() should return an error when api_key is empty."""
        cfg = Config()
        cfg.api_key = ""
        errors = cfg.validate()
        assert any("API key" in e for e in errors)

    def test_validate_catches_discord_token_missing(self):
        """validate() should error when Discord is enabled but token is missing."""
        cfg = Config()
        cfg.api_key = "sk-valid"
        cfg.discord_enabled = True
        cfg.discord_token = ""
        errors = cfg.validate()
        assert any("Discord token" in e for e in errors)

    def test_validate_passes_when_all_good(self):
        """validate() should return no errors for a fully valid config."""
        cfg = Config()
        cfg.api_key = "sk-valid"
        cfg.discord_enabled = False
        errors = cfg.validate()
        assert errors == []

    def test_validate_passes_discord_with_token(self):
        """validate() should pass when Discord is enabled and token is provided."""
        cfg = Config()
        cfg.api_key = "sk-valid"
        cfg.discord_enabled = True
        cfg.discord_token = "discord-token-xyz"
        errors = cfg.validate()
        assert errors == []


# ---------------------------------------------------------------------------
# Config.save()
# ---------------------------------------------------------------------------

class TestConfigSave:
    def test_save_writes_correct_json(self, tmp_path):
        """save() should write a valid JSON file with all expected keys."""
        cfg = Config()
        cfg.bot_name = "SavedBot"
        cfg.api_key = "sk-save-test"
        cfg.provider_name = "openai"
        cfg.model = "gpt-4o"
        cfg.discord_enabled = True
        cfg.discord_token = "discord-save-token"
        cfg.guard_mode = "block"
        cfg.memory_store = str(tmp_path / "memory")
        cfg.context_max_tokens = 75000

        save_path = tmp_path / "config.json"
        cfg.save(str(save_path))

        assert save_path.exists()
        data = json.loads(save_path.read_text())

        assert data["bot"]["name"] == "SavedBot"
        assert data["provider"]["name"] == "openai"
        assert data["provider"]["apiKey"] == "sk-save-test"
        assert data["provider"]["model"] == "gpt-4o"
        assert data["channels"]["discord"]["enabled"] is True
        assert data["channels"]["discord"]["token"] == "discord-save-token"
        assert data["guard"]["mode"] == "block"
        assert data["context"]["maxTokens"] == 75000
        assert data["memory"]["autoIngest"] is True
        assert data["memory"]["autoRecall"] is True

    def test_save_creates_parent_dirs(self, tmp_path):
        """save() should create parent directories if they don't exist."""
        save_path = tmp_path / "deep" / "nested" / "config.json"
        cfg = Config()
        cfg.api_key = "sk-x"
        cfg.save(str(save_path))
        assert save_path.exists()

    def test_roundtrip(self, tmp_path):
        """Config saved and then loaded should produce the same values."""
        cfg = Config()
        cfg.bot_name = "RoundTrip"
        cfg.api_key = "sk-rt"
        cfg.model = "claude-sonnet-4-20250514"
        cfg.guard_mode = "warn"
        cfg.memory_search_limit = 7
        cfg.memory_store = str(tmp_path / "mem")

        save_path = tmp_path / "rt.json"
        cfg.save(str(save_path))

        loaded = Config.load(str(save_path))
        assert loaded is not None
        assert loaded.bot_name == cfg.bot_name
        assert loaded.api_key == cfg.api_key
        assert loaded.model == cfg.model
        assert loaded.guard_mode == cfg.guard_mode
        assert loaded.memory_search_limit == cfg.memory_search_limit


# ---------------------------------------------------------------------------
# run_init_wizard
# ---------------------------------------------------------------------------

class TestRunInitWizard:
    def test_wizard_exists_and_is_callable(self):
        """run_init_wizard should be importable and callable."""
        assert callable(run_init_wizard)

    def test_wizard_runs_with_mocked_input(self, tmp_path):
        """run_init_wizard should complete without error when input is mocked."""
        inputs = iter(["MyBot", "1", "sk-wizard-key", "", "1"])  # added "1" for security mode prompt

        with patch("builtins.input", side_effect=lambda prompt="": next(inputs)):
            with patch("antarisbot.core.config.DEFAULT_CONFIG_DIR", tmp_path):
                with patch("antarisbot.core.config.DEFAULT_CONFIG_PATH", tmp_path / "config.json"):
                    with patch.object(Config, "save") as mock_save:
                        run_init_wizard()
                        mock_save.assert_called_once()
