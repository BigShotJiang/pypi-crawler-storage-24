# AntarisBot

Personal AI assistant. Zero external dependencies. Ships with memory, safety, and a soul built in.

```bash
pip install antarisbot
antaris init
antaris start
```

---

## What's Built In

### 🧠 Persistent Memory
Remembers every conversation, forever. Built on antaris-memory — the same 11-layer search engine that powers antaris-suite. BM25 + semantic decay ranking. No vector DB. No cloud. Just files on your machine.

### 🔐 Three Security Modes
The only self-hosted agent with named, enforced security tiers — not just a disclaimer.

```bash
antaris start --security sandboxed   # recommended default
antaris start --security open        # developers / power users
antaris start --security locked      # maximum security
```

| Mode | What It Does | Idle RAM |
|------|-------------|----------|
| **open** | Full host access. Guard disabled. | ~50MB |
| **sandboxed** ★ | Filesystem restricted to workspace. Subprocesses blocked. Prompt injection detection active. | ~60MB |
| **locked** | Everything in sandboxed + AES-256-GCM encrypted memory. Tool approval prompts. JSON audit log. Network restricted to LLM APIs only. | ~75MB |

Security is enforced at the OS level via Python audit hooks (`sys.addaudithook`) — irremovable once set. Not a disclaimer. Not "experimental." Actually blocked.

### 🛡️ Guard Modes
- `open` → guard disabled
- `sandboxed` → monitor (logs violations, never blocks)
- `locked` → block (actively denies flagged input/output)

### 🎭 Persona System
Drop a `SOUL.md` in `~/.antarisbot/` to define personality, values, and behavior. The bot runs an awakening sequence on first start to discover its identity.

### 🤖 Multi-Channel
Discord, Telegram, Slack, Terminal — all from one config.

### 🔄 Migration
```bash
antaris migrate --from openclaw
```
Imports memories, persona, and config from OpenClaw in one command.

---

## Install

```bash
pip install antarisbot
```

Requires Python 3.10+. No other system dependencies.

---

## Setup

```bash
antaris init
```

Interactive wizard. Asks for:
- Bot name
- LLM provider (Anthropic / OpenAI / Ollama)
- API key
- Channel tokens (Discord, Telegram, Slack — all optional)
- Security mode

Or skip the wizard entirely:
```bash
antaris init --headless
```

---

## Commands

| Command | Description |
|---------|-------------|
| `antaris init` | Interactive setup wizard |
| `antaris start` | Launch the bot |
| `antaris start --security locked` | Launch in locked security mode |
| `antaris stop` | Stop the running bot |
| `antaris restart` | Restart the bot |
| `antaris chat` | Terminal conversation (no Discord needed) |
| `antaris status` | Show bot status |
| `antaris security status` | Show security configuration |
| `antaris update` | Pull latest updates |
| `antaris persona show` | View current SOUL.md |
| `antaris persona edit` | Edit persona in $EDITOR |
| `antaris persona reset` | Reset and trigger awakening |
| `antaris memory stats` | Memory usage per user |
| `antaris memory search <query>` | Search memories |
| `antaris memory export` | Export all memories to JSON |
| `antaris config show` | View current config |
| `antaris config set model <model>` | Change default model |
| `antaris migrate --from openclaw` | Import from OpenClaw |

---

## Supported LLM Providers

| Provider | Models |
|----------|--------|
| **Anthropic** | Claude Sonnet, Haiku, Opus |
| **OpenAI** | GPT-4o, GPT-4o-mini, o1 |
| **Ollama** | Any local model (Qwen, Llama, Mistral, etc.) |
| **Google** | Gemini 1.5 Pro, Flash |

---

## Security: How It Actually Works

Most self-hosted agents say "sandbox" and mean nothing. AntarisBot's sandboxed and locked modes use `sys.addaudithook()` — a Python 3.8+ mechanism that fires at the C level, before Python can intercept, and **cannot be removed once registered**.

In **sandboxed** mode:
- File access outside the workspace directory → `PermissionError`, blocked
- `subprocess.Popen()` → blocked
- Prompt injection → detected by antaris-guard, logged

In **locked** mode, everything above plus:
- Memory store encrypted with AES-256-GCM at rest
- Every tool call prompts for explicit `y/N` approval
- All tool calls logged to `~/.antarisbot/audit.log` (JSON lines, 30-day rotation)
- Network calls restricted to configured LLM API endpoints only
- Memory directory set `chmod 700` (owner-only)

---

## Powered By

[antaris-suite](https://pypi.org/project/antaris-suite/) — zero-dependency AI infrastructure.

- `antaris-memory` — 11-layer BM25 search + semantic decay
- `antaris-guard` — prompt injection detection + content filtering
- `antaris-context` — cross-session context management
- `antaris-router` — adaptive LLM routing
- `antaris-pipeline` — message orchestration

---

## Changelog

### v0.6.0
- **Security modes** — `open`, `sandboxed` (default), `locked`
- `sys.addaudithook()` filesystem + subprocess + network enforcement
- AES-256-GCM encrypted memory store (locked mode)
- Tool approval middleware with `y/N` prompts (locked mode)
- JSON audit log with 30-day rotation (locked mode)
- `antaris start --security <mode>` CLI flag
- `antaris security status` command
- `"disabled"` guard mode for open security
- 487 tests passing

### v0.5.0
- Multi-channel: Discord, Telegram, Slack, Terminal
- Persona system + awakening sequence
- Persistent memory with BM25 search
- Rate limiting, content filtering
- `antaris migrate --from openclaw`

---

## License

MIT
