
import os
import logging
from fastapi import HTTPException, Security, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

logger = logging.getLogger(__name__)

# Security scheme (Bearer token)
security = HTTPBearer()

def get_allowed_tokens() -> list[str]:
    """
    Retrieves allowed API tokens from the environment variable 'HALE_API_TOKENS'.
    Returns a list of tokens.
    """
    tokens_str = os.getenv("HALE_API_TOKENS", "").strip()
    if not tokens_str:
        return []
    return [t.strip() for t in tokens_str.split(",") if t.strip()]

async def verify_api_key(credentials: HTTPAuthorizationCredentials = Security(security)):
    """
    Verifies the Bearer token against configured tokens.
    If no tokens are configured, allows access with a warning log.
    """
    allowed_tokens = get_allowed_tokens()
    
    if not allowed_tokens:
        # No security configured!
        logger.warning("No API tokens configured (HALE_API_TOKENS env var missing or empty). Allowing all requests.")
        return credentials.credentials # Allow access if no tokens set (Dev Mode / Insecure Default)
        # Alternatively, raise HTTPException(status_code=500, detail="Server misconfigured: No API tokens set.")

    token = credentials.credentials
    if token not in allowed_tokens:
        logger.warning(f"Unauthorized access attempt with token: {token[:4]}***")
        raise HTTPException(
            status_code=401,
            detail="Invalid or missing authentication token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    return token
