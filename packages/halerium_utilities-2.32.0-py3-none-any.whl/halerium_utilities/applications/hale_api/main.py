
import logging
from fastapi import FastAPI
from .endpoints import router

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_app() -> FastAPI:
    app = FastAPI(
        title="Hal-E Responses API",
        description="OpenAI-compatible API for interacting with Hal-E sessions.",
        version="1.0.0"
    )

    app.include_router(router)
    
    @app.get("/health")
    async def health_check():
        return {"status": "ok"}
        
    return app

app = create_app()

if __name__ == "__main__":
    import uvicorn
    # This entry point is for testing/running directly
    uvicorn.run(app, host="0.0.0.0", port=8000)
