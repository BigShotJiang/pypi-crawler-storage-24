
import uuid
import asyncio
from typing import Tuple, Optional
from halerium_utilities.hal_es.hal_e_session import HalESession
from halerium_utilities.hal_es.hal_e import HalE
from halerium_utilities.hal_es.schemas import SessionData, get_session_data_from_response_data
from halerium_utilities.utils.api_config import get_api_headers, get_api_base_url
import httpx
import logging

logger = logging.getLogger(__name__)

# --- ID Encoding/Decoding ---

def encode_uuid(uuid_str: str) -> str:
    """Converts a UUID string (with dashes) to a 32-char hex string."""
    if not uuid_str:
        return ""
    return str(uuid.UUID(uuid_str).hex)

def decode_uuid(hex_str: str) -> str:
    """Converts a 32-char hex string back to a UUID string (with dashes)."""
    if len(hex_str) != 32:
        raise ValueError(f"Invalid hex UUID length: {len(hex_str)}")
    return str(uuid.UUID(hex_str))

def create_message_id(session_id: str, element_id: str) -> str:
    """Creates a combined 64-char ID from session and element UUIDs."""
    return encode_uuid(session_id) + encode_uuid(element_id)

def parse_message_id(message_id: str) -> Tuple[Optional[str], Optional[str]]:
    """
    Parses a message ID into (session_id, element_id).
    
    Format:
    - 64 chars: <session_hex><element_hex> -> specific element in session
    - 32 chars: <session_hex> -> last element in session (implicit)
    - Other/None: (None, None) -> New session request
    """
    if not message_id:
        return None, None
    
    try:
        if len(message_id) == 64:
            session_hex = message_id[:32]
            element_hex = message_id[32:]
            return decode_uuid(session_hex), decode_uuid(element_hex)
        elif len(message_id) == 32:
            return decode_uuid(message_id), None
        else:
            return None, None
    except ValueError:
        return None, None

# --- Session Management ---

async def get_or_create_session(
    model_name: str, 
    session_id: Optional[str] = None
) -> HalESession:
    """
    Retrieves an existing Hal-E session or creates a new one.
    
    Parameters
    ----------
    model_name : str
        The name of the Hal-E to use (acts as the 'model').
    session_id : str, optional
        The UUID of the session to retrieve.
        
    Returns
    -------
    HalESession
    """
    loop = asyncio.get_event_loop()
    
    if session_id:
        # Use HalE to list sessions and find the target one
        # This avoids direct API calls to endpoints that might not exist or work as expected
        def find_session():
            try:
                hale = HalE.from_name(model_name)
                sessions = hale.get_session_data()
                for sess in sessions:
                    if str(sess.session_id) == str(session_id):
                        return sess
                return None
            except Exception as e:
                logger.error(f"Error listing sessions: {e}")
                return None
                
        session_data = await loop.run_in_executor(None, find_session)
        
        if not session_data:
             raise ValueError(f"Session {session_id} not found for model {model_name}.")
             
        # Initialize session (synchronously inside async function wrapper not needed as no heavy I/O in __init__ if session_data provided)
        # But board loading is involved
        session = await loop.run_in_executor(None, lambda: HalESession(session_data=session_data))
        return session
        
    else:
        # Create new session
        # HalESession(hale=...) calls API to create session then reads board.
        def create_new_session():
            hale = HalE.from_name(model_name)
            return HalESession(hale=hale)
            
        session = await loop.run_in_executor(None, create_new_session)
        return session

async def resolve_target_element(session: HalESession, element_id: Optional[str]) -> str:
    """
    Determines the element ID to append the next user message to.
    
    Parameters
    ----------
    session : HalESession
    element_id : str, optional
        The UUID of the last message (element).
        
    Returns
    -------
    str
        The UUID of the new bot element to use for input.
    """
    target_id = None
    
    if element_id:
        try:
            # Check if element exists first? 
            # `append_bot_element_async` assumes valid ID.
            # If it's invalid, it might raise errors.
            # But we trust the ID for now as it came from us previously.
            target_id = await session.append_bot_element_async(element_id)
        except Exception as e:
            logger.warning(f"Failed to append to element {element_id}: {e}. Falling back to last bot element.")
            element_id = None 

    if not target_id:
        # Find last bot element
        elements = await session.get_elements_async(resolve=False)
        bot_elements = [e for e in elements if e.type == "bot"]
        
        if not bot_elements:
             # Try to find a start node or similar if empty?
             # Usually a fresh session has at least one bot node if the template has one.
             # If not, we might be in trouble.
             # Let's assume standard Hal-E templates have a bot node.
             raise ValueError("No bot elements found in Hal-E session.")
        
        last_bot = bot_elements[-1]
        
        # Check if last bot is fresh (unused)
        resolved_last_bot = await session.get_element_by_id_async(last_bot.id, resolve=True)
        ts = resolved_last_bot.type_specific
        
        # Reuse if prompt_input and prompt_output are empty
        if not ts.prompt_input and not ts.prompt_output:
            target_id = last_bot.id
        else:
            target_id = await session.append_bot_element_async(last_bot.id)
            
    return target_id
