
from fastapi import APIRouter, HTTPException, Request, Depends, Security
from fastapi.responses import StreamingResponse
import json
import logging
import time
import re
from .schemas import (
    ResponseRequest, ResponseObject, ResponseOutputItem, ResponseUsage, OutputTextContent, OutputTextContent,
    ResponseTextDeltaEvent, ResponseTextDoneEvent, ResponseDoneEvent
)
from .security import verify_api_key, HTTPAuthorizationCredentials
from .utils import (
    parse_message_id, 
    create_message_id, 
    get_or_create_session, 
    resolve_target_element,
    HalESession, HalE
)

router = APIRouter()
logger = logging.getLogger(__name__)

async def clean_stream_generator(input_generator):
    """
    Filters out internal Hal-E function tags from the stream.
    """
    buffer = ""
    # Regex for complete tag: ![Alt Text](function:...)
    tag_pattern = re.compile(r'!\[.*?\]\(function:.*?\)')
    
    async for chunk in input_generator:
        buffer += chunk
        
        while True:
            # 1. Search for complete tag
            match = tag_pattern.search(buffer)
            if match:
                # Yield text before tag
                if match.start() > 0:
                    yield buffer[:match.start()]
                
                # Discard tag
                buffer = buffer[match.end():]
                continue
            
            # 2. Check if buffer potentially contains start of a tag `![`
            start_idx = buffer.find('![')
            
            if start_idx == -1:
                # No `![` found.
                # Check if it ends with `!` (potential start of next chunk)
                if buffer.endswith('!'):
                    if len(buffer) > 1:
                        yield buffer[:-1]
                        buffer = '!'
                    else:
                        pass # buffer is just '!', keep it
                else:
                    yield buffer
                    buffer = ""
                break
            
            else:
                # `![` found at start_idx
                # Yield text before `![`
                if start_idx > 0:
                    yield buffer[:start_idx]
                    buffer = buffer[start_idx:]
                    start_idx = 0 # Buffer now starts with `![`
                
                # Now buffer starts with `![`
                # If buffer is getting very long (e.g. > 2000 chars), assume it's not a function tag and flush
                if len(buffer) > 2000:
                    yield buffer[0]
                    buffer = buffer[1:]
                    continue
                
                # Wait for more chunks to complete the tag
                break
        
    # Flush remaining buffer at end
    if buffer:
        match = tag_pattern.search(buffer)
        if match:
            if match.start() > 0:
                yield buffer[:match.start()]
            if match.end() < len(buffer):
                yield buffer[match.end():]
        else:
            yield buffer

async def stream_generator(session: HalESession, target_id: str, new_response_id: str):
    """
    Streams events compatible with OpenAI Responses API streaming format.
    """
    created_ts = int(time.time())
    full_text = ""
    
    # Internal generator to extract raw text chunks
    async def raw_text_stream():
        async for event in session.stream_prompt_async(target_id):
            chunk_content = None
            if event.event == 'chunk':
                if isinstance(event.data, dict):
                    chunk_content = event.data.get('chunk', '')
                elif isinstance(event.data, str):
                    try:
                        data_dict = json.loads(event.data)
                        chunk_content = data_dict.get('chunk', '')
                    except:
                        pass
            
            if chunk_content:
                yield chunk_content

    try:
        # Stream content through cleaner
        async for clean_chunk in clean_stream_generator(raw_text_stream()):
            full_text += clean_chunk
            
            # Yield response.output_text.delta event
            delta_event = ResponseTextDeltaEvent(
                type="response.output_text.delta",
                delta=clean_chunk,
                snapshot=full_text,
                response_id=new_response_id,
                output_index=0,
                content_index=0
            )
            yield f"event: response.output_text.delta\ndata: {json.dumps(delta_event.dict())}\n\n"

        # End of stream events
        
        # Yield response.output_text.done
        done_text_event = ResponseTextDoneEvent(
            type="response.output_text.done",
            text=full_text,
            response_id=new_response_id,
            output_index=0,
            content_index=0
        )
        yield f"event: response.output_text.done\ndata: {json.dumps(done_text_event.dict())}\n\n"
        
        # Yield response.done with full object
        final_response_object = ResponseObject(
            id=new_response_id,
            object="response",
            created_at=created_ts,
            model=session.hale.name,
            status="completed",
            output=[
                ResponseOutputItem(
                    type="message",
                    role="assistant",
                    content=[OutputTextContent(text=full_text)]
                )
            ],
            usage=ResponseUsage(
                prompt_tokens=-1,
                completion_tokens=-1,
                total_tokens=-1
            )
        )
        
        done_event = ResponseDoneEvent(
            type="response.done",
            response=final_response_object
        )
        yield f"event: response.done\ndata: {json.dumps(done_event.dict())}\n\n"
        
    except Exception as e:
        logger.error(f"Streaming error: {e}")
        error_payload = {
            "type": "error",
            "error": {
                "message": str(e),
                "type": "server_error"
            }
        }
        yield f"event: error\ndata: {json.dumps(error_payload)}\n\n"

@router.post("/v1/responses", dependencies=[Depends(verify_api_key)])
async def create_response(request: ResponseRequest):
    """
    Stateful Responses API for Hal-E sessions.
    Mimics OpenAI's /v1/responses structure.
    
    Accepts `previous_response_id` (64-char hex) to continue session.
    """
    
    # 1. Determine Session and Element
    message_id_str = request.previous_response_id
    session_id, element_id = parse_message_id(message_id_str)
    
    try:
        # Get or create session
        try:
            session = await get_or_create_session(request.model, session_id)
        except ValueError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except Exception as e:
            logger.error(f"Failed to create session: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to initialize session: {e}")
        
        # Determine target element for input
        try:
            target_id = await resolve_target_element(session, element_id)
        except ValueError as e:
             raise HTTPException(status_code=500, detail=str(e))
        
        # 2. Insert User Input
        if not request.input:
             raise HTTPException(status_code=400, detail="Input cannot be empty.")
        
        
        user_input = request.input
        if isinstance(user_input, list):
             try:
                 user_input = "\n".join([item.content for item in user_input if hasattr(item, 'content')])
             except:
                 user_input = str(user_input)
        
        if request.instructions:
             user_input = f"System Instructions: {request.instructions}\n\nUser Input: {user_input}"
        # Insert text into prompt_input
        await session.insert_text_async(target_id, user_input, "prompt_input")
        
        # 3. Prepare Response ID
        new_response_id = create_message_id(session.session_data.session_id, target_id)
        created_ts = int(time.time())
        
        if request.stream:
            return StreamingResponse(
                stream_generator(session, target_id, new_response_id),
                media_type="text/event-stream"
            )
        else:
            # Non-streaming: Wait for full response
            # We need to clean tags here too!
            # Use raw generator and consume it
            full_text = ""
            async for chunk in clean_stream_generator(stream_generator_helper(session, target_id)):
                full_text += chunk
            
            return ResponseObject(
                id=new_response_id,
                object="response",
                created_at=created_ts,
                model=session.hale.name,
                status="completed",
                output=[
                    ResponseOutputItem(
                    type="message",
                    role="assistant",
                    content=[OutputTextContent(text=full_text)]
                )
                ],
                usage=ResponseUsage(
                    prompt_tokens=-1,
                    completion_tokens=-1,
                    total_tokens=-1
                )
            )

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Error processing response")
        raise HTTPException(status_code=500, detail=str(e))

async def stream_generator_helper(session, target_id):
    """Helper to convert session stream to simple string chunks for non-streaming usage filtering"""
    async for event in session.stream_prompt_async(target_id):
        chunk_content = None
        if event.event == 'chunk':
            if isinstance(event.data, dict):
                chunk_content = event.data.get('chunk', '')
            elif isinstance(event.data, str):
                try:
                    data_dict = json.loads(event.data)
                    chunk_content = data_dict.get('chunk', '')
                except:
                    pass
        if chunk_content:
            yield chunk_content
