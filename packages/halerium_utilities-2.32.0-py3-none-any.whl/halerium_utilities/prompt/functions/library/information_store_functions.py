# --------------------------------------------------- #
#
# Ticket: https://erium.atlassian.net/browse/HAL-5157
#
# --------------------------------------------------- #

from halerium_utilities.stores.api import (
    get_workspace_information_stores_async,
    get_information_store_info_async,
    InformationStoreException,
)

from halerium_utilities.stores import (
    get_information_store_by_name_async,
    create_information_store_async,
    delete_information_store_async,
)

from halerium_utilities.stores.models import SearchParam


async def get_information_stores() -> list:
    """
    Get all information stores in the current workspace.

    Returns:
        List of information stores with their UUIDs and names.
    """
    try:
        stores = await get_workspace_information_stores_async()
        return [{"name": s["name"], "uuid": s["uuid"]} for s in stores.get("items", [])]
    except Exception as e:
        return [f"Error fetching stores: {str(e)}"]


async def create_information_store(name: str) -> str:
    """
    Create a new information store.

    Args:
        name: The name of the information store.

    Returns:
        A message indicating the result of the creation.
    """
    try:
        await create_information_store_async(name)
        return f"Information Store with name {name} created successfully."
    except InformationStoreException:
        return f"Information Store with name {name} already exists or could not be created."
    except Exception as e:
        return f"Error creating store: {str(e)}"


async def delete_information_store(name: str) -> str:
    """
    Delete an information store by name.

    Args:
        name: The name of the information store.

    Returns:
        A message indicating the result of the deletion.
    """
    try:
        # get infostore id from name
        info_store = await get_information_store_by_name_async(name)
        if not info_store:
            return f"Information Store '{name}' not found."

        await delete_information_store_async(info_store.store_id)
        return f"Information Store with name {name} deleted successfully."
    except InformationStoreException as e:
        return f"Error deleting store: {str(e)}"
    except Exception as e:
        return f"Unexpected error: {str(e)}"


async def add_file_to_store(store_name: str, file_path: str) -> str:
    """
    Add a file to an information store for processing (indexing).

    Args:
        store_name: The name of the information store.
        file_path: The workspace-relative path to the file (e.g., "my_folder/doc.pdf") or runner path.
                   This path is relative to the bot's working directory / runner environment.

    Returns:
        A status message.
    """
    try:
        store = await get_information_store_by_name_async(store_name)
        if not store:
            return f"Store '{store_name}' not found."
        
        await store.add_file_async(file_path)
        return f"File '{file_path}' added to store '{store_name}'. Check status for processing progress."
    except FileNotFoundError:
        return f"File '{file_path}' not found in workspace."
    except Exception as e:
        return f"Error adding file: {str(e)}"


async def delete_file_from_store(store_name: str, source_path: str) -> str:
    """
    Delete a file's content from the store by removing all chunks associated with it.

    Args:
        store_name: The name of the information store.
        source_path: The 'source' metadata value of the file to delete.
                     This usually corresponds to the workspace path (e.g., "/my_folder/doc.pdf").
                     Verify this path by inspecting chunk metadata if unsure.

    Returns:
        A status message indicating how many chunks were deleted.
    """
    try:
        store = await get_information_store_by_name_async(store_name)
        if not store:
            return f"Store '{store_name}' not found."

        # The source in metadata usually matches the path provided or the resolved path.
        # Typically it starts with a slash like /path/to/file.
        # We try to match exact first.
        
        search_filter = SearchParam(
            filter_type="exact_match",
            key="source",
            value=source_path,
            case_insensitive=False
        )
        
        # We need to find ALL chunks. pagination might be needed if many chunks.
        # But delete_chunks takes IDs.
        
        all_chunk_ids = []
        
        # Loop to get all chunks (basic pagination)
        page = 0
        batch_size = 1000
        while True:
            chunks = await store.get_chunks_async(start=page * batch_size, size=batch_size, filters=[search_filter])
            if not chunks:
                break
            ids = [c['id'] for c in chunks]
            all_chunk_ids.extend(ids)
            if len(chunks) < batch_size:
                break
            page += 1
            
        if not all_chunk_ids:
            # Try prepending / if missing
            if not source_path.startswith("/"):
                alt_path = "/" + source_path
                search_filter.value = alt_path
                # Retry search
                page = 0
                while True:
                    chunks = await store.get_chunks_async(start=page * batch_size, size=batch_size, filters=[search_filter])
                    if not chunks:
                        break
                    ids = [c['id'] for c in chunks]
                    all_chunk_ids.extend(ids)
                    if len(chunks) < batch_size:
                        break
                    page += 1

        if not all_chunk_ids:
            return f"No chunks found for source '{source_path}' in store '{store_name}'."

        await store.delete_chunks_async(all_chunk_ids)
        return f"Deleted {len(all_chunk_ids)} chunks for source '{source_path}' from store '{store_name}'."

    except Exception as e:
        return f"Error deleting file from store: {str(e)}"


async def get_store_status(store_name: str, limit: int = 5) -> dict | str:
    """
    Get the status of an information store, including recent process events (e.g., file indexing).

    Args:
        store_name: The name of the information store.
        limit: The number of recent events to return. Defaults to 5.

    Returns:
        A dictionary containing process events and general info.
    """
    try:
        store = await get_information_store_by_name_async(store_name)
        if not store:
            return f"Store '{store_name}' not found."

        # We need to fetch the raw info again to get 'process_events' and 'processes' 
        # because the InformationStore object might not expose them directly in properties.
        # Actually, store.update() updates self.name and self.memories.
        # We need to call the api directly to get the full item dict if attributes aren't exposed.
        
        info_json = await get_information_store_info_async(store._store_id)
        item = info_json.get('item', {})
        
        events = item.get("process_events", [])
        # Sort events by time if they have timestamps, but usually they are append-only list.
        # Assuming last is newest? Or first is newest?
        # Usually process logs are appended. So last is newest.
        # Let's slice from end.
        recent_events = events[-limit:] if limit > 0 else events
        
        return {
            "name": item.get("name"),
            "memory_count": len(item.get("memories", [])),
            "recent_events": recent_events,
            "active_processes": item.get("processes", [])
        }

    except Exception as e:
        return f"Error getting store status: {str(e)}"
