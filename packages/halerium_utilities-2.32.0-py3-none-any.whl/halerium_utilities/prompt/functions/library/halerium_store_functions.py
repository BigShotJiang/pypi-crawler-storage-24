# --------------------------------------------------- #
#
# Ticket: https://erium.atlassian.net/browse/HAL-5158
#
# --------------------------------------------------- #
import os
from typing import Optional, Dict, Any, List

from halerium_utilities.bundles.installation import (
    install_bundle_async,
    precheck_bundle_installation_async,
    # create_conflict_handling_from_check,
    StoreBundleError,
    BundleInstallationError,
)

from halerium_utilities.bundles.schemas import StoreBundle
from halerium_utilities.bundles.browsing import (
    get_published_bundles_async,
    get_published_bundle_async,
)


async def halerium_store_list_bundles(start_index: int = 0, max_results: int = 20) -> Dict[str, Any] | str:
    """
    Lists available bundles in the halerium store with pagination.

    Args:
        start_index (int, optional): The starting index for pagination. Defaults to 0.
        max_results (int, optional): The maximum number of results to return. Defaults to 20.

    Returns:
        dict: A dictionary containing the list of bundles, total count, and pagination info.
              Format: {"total_count": int, "start_index": int, "max_results": int, "bundles": List[StoreBundle]}
        str: Error message if the operation fails.
    """
    try:
        all_bundles = await get_published_bundles_async()
        total_count = len(all_bundles)
        
        # apply pagination
        end_index = start_index + max_results
        paginated_bundles = all_bundles[start_index:end_index]
        paginated_bundles = [p.dict() for p in paginated_bundles]
        
        return {
            "total_count": total_count,
            "start_index": start_index,
            "max_results": max_results,
            "bundles": paginated_bundles
        }
    except StoreBundleError as e:
        return str(e)


async def halerium_store_search(
        name: Optional[str] = None,
        description: Optional[str] = None,
        publisher_name: Optional[str] = None,
        access_scope: Optional[str] = None,
        has_hales: Optional[bool] = None,
        has_capabilities: Optional[bool] = None,
        has_infostores: Optional[bool] = None,
        has_files: Optional[bool] = None,
) -> list:
    """
    Enables searching the halerium store with various filter arguments.
    
    Use this function to find bundles that match specific criteria. For example, you can search for:
    - Bundles with 'CRM' in the name.
    - Bundles published by 'Erium'.
    - Bundles that contain specific content types like Hal-Es (chatbots), capability groups (tools), or information stores.

    Args:
        name (str, optional): name of the bundle (for "is in" match)
        description (str, optional): description of the bundle (for "is in" match)
        publisher_name (str, optional): name of the publisher (for "is in" match)
        access_scope (str, optional): scope of the bundle (for exact match).
            Allowed values are "public", "tenant", "user_and_usergroup"
        has_hales (bool, optional): whether the bundle has a hales
        has_capabilities (bool, optional): whether the bundle has a capability groups
        has_infostores (bool, optional): whether the bundle has information stores
        has_files (bool, optional): whether the bundle has files

    Returns:
        list: List of StoreBundle objects matching the search criteria
    """
    try:
        results = await get_published_bundles_async()
        if name:
            results = [bundle for bundle in results if name.lower() in bundle.name.lower()]
        if description:
            results = [bundle for bundle in results if description.lower() in bundle.description.lower()]
        if publisher_name:
            results = [bundle for bundle in results if publisher_name.lower() in bundle.publisher.name.lower()]
        if access_scope:
            results = [bundle for bundle in results if access_scope.lower() == bundle.access_scope.lower()]
        if has_hales is not None:
            results = [bundle for bundle in results if has_hales == bool(bundle.contents.hales)]
        if has_capabilities is not None:
            results = [bundle for bundle in results if has_capabilities == bool(bundle.contents.capabilities)]
        if has_infostores is not None:
            results = [bundle for bundle in results if has_infostores == bool(bundle.contents.infostores)]
        if has_files is not None:
            results = [bundle for bundle in results if has_files == bool(bundle.contents.files)]
        return results
    except StoreBundleError as e:
        return str(e)


async def install_bundle(bundle_id: str) -> str:
    """
    Installs the bundle at the given bundle id.
    
    If the installation encounters conflicts (e.g., existing files or assets), this function will NOT overwrite them.
    Instead, it will return a message with a link, instructing the user to resolve the conflicts manually.

    Args:
        bundle_id (str): bundle ID

    Returns:
        str: Result message indicating success or providing a manual resolution link if conflicts exist.
    """
    try:
        installation_precheck = await precheck_bundle_installation_async(bundle_id)
    except StoreBundleError as e:
        return str(e)

    # If there are conflicts, show them to the user
    if installation_precheck.conflicts:
        # generate sharing link for that bundle:
        bundle_sharing_link = await halerium_store_get_bundle_sharing_link(bundle_id)
        return f"Bundle with id {bundle_id} cannot be installed automatically due to conflicts: {installation_precheck.conflicts}. Please ask the user to resolve the conflicts manually by visiting: {bundle_sharing_link}"

    try:
        installation_check = await install_bundle_async(bundle_id=bundle_id)
        return (
            f"Bundle with id {bundle_id} installed successfully."
        )
    except (StoreBundleError, BundleInstallationError) as e:
        return str(e)


async def get_bundle_link(bundle_id: str) -> str:
    """
    Builds the sharing link for a halerium bundle

    Args:
        bundle_id (str): bundle ID

    Returns:
        str: Sharing link URL
    """
    # get the bundle
    tenant = os.getenv("HALERIUM_TENANT_KEY", "")
    bundle_info: StoreBundle = await get_published_bundle_async(bundle_id)
    scope = "public" if bundle_info.access_scope == "public" else tenant
    base_url = os.getenv("HALERIUM_BASE_URL", "https://pro.halerium.ai")

    return f"{base_url}/{scope}/store/{bundle_id}"

# Helper function
async def halerium_store_get_bundle_sharing_link(bundle_id: str) -> str:
    return await get_bundle_link(bundle_id)
