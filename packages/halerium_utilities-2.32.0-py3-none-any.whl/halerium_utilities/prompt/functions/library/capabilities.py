import json
import ast
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Literal, Optional, Any, Set
from traceback import format_exception_only

from halerium_utilities.prompt.capabilities import (
    get_capability_groups_async,
    get_capability_group_async,
    delete_capability_group_async, 
    create_capability_group_async,
    update_capability_group_async,
    add_function_to_capability_group_async,
    delete_function_from_capability_group_async,
    update_function_in_capability_group_async,
    write_capability_group_to_file_async,
    create_capability_group_from_file_async,
    update_capability_group_from_file_async,
)
from halerium_utilities.prompt.capabilities.capabilities import CapabilityGroupException


BACKUP_FOLDER = Path.home() / ".capability_editor"


async def _backup_capability(capability):
    BACKUP_FOLDER.mkdir(exist_ok=True)

    # Include microseconds to avoid collisions within the same second
    datestring = datetime.now().strftime("%Y-%m-%dT%H-%M-%S.%f")
    name = capability["name"]

    filename = f"{name}-{datestring}.capabilities"

    await write_capability_group_to_file_async(
        filepath=BACKUP_FOLDER / filename,
        capability=capability
    )

    _cleanup_backups(name)


def _find_backups(name: str = None):
    if not BACKUP_FOLDER.exists():
        return []

    backups = []
    for path in BACKUP_FOLDER.glob("*.capabilities"):
        if name and not path.name.startswith(f"{name}-"):
            continue
        try:
            with open(path, "r") as f:
                capa_group = json.load(f)
            capa_group = capa_group["capabilities"][0]
            _name = capa_group["name"]
            if name and _name != name:
                continue
            functions = [f["function"] for f in capa_group["functions"]]
            backups.append({
                "backup_file": path.name,
                "name": _name,
                "functions": functions,
            })
        except Exception as e:
            # If filtering by a specific name, skip files that can't be parsed
            if not name:
                backups.append({
                    "backup_file": path.name,
                    "error": str(e),
                })

    # Sort by modification time (oldest first)
    backups.sort(key=lambda el: (BACKUP_FOLDER / el["backup_file"]).stat().st_mtime)
    return backups


def _cleanup_backups(name):
    backups = _find_backups(name=name)

    # only keep last 10 iterations
    for backup in backups[:-10]:
        path = BACKUP_FOLDER / backup["backup_file"]
        try:
            path.unlink()
        except FileNotFoundError:
            pass


def _get_defined_functions(source_code: str) -> Set[str]:
    """
    Parses source code and returns a set of function names defined in it.
    """
    if not source_code:
        return set()
    try:
        tree = ast.parse(source_code)
        return {
            node.name 
            for node in ast.walk(tree) 
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
    except SyntaxError:
        # If syntax is invalid, we can't reliably count functions. 
        # But this might be caught elsewhere or allowed.
        # For our comparison purposes, we assume 0 identifiable functions.
        return set()


def _validate_full_source_code(new_code: str, old_code: Optional[str] = None):
    """
    Validates that the new source code is likely the full code and not a truncated snippet.
    """
    if not new_code:
        return

    # 1. Check for placeholder strings
    suspicious_patterns = [
        "# ...", "# previous code", "# existing code", 
        "# remaining code", "# rest of code", "# unchanged",
        "# code unchanged"
    ]
    for pattern in suspicious_patterns:
        if pattern.lower() in new_code.lower():
            raise ValueError(
                f"Source code contains placeholder '{pattern}'. "
                "Please provide the FULL source code, not just snippets. "
                "If you really intend to use placeholders or delete code, set 'force_update=True'."
            )

    # 2. Check for missing functions (if old code is available)
    if old_code:
        old_funcs = _get_defined_functions(old_code)
        new_funcs = _get_defined_functions(new_code)
        
        missing_funcs = old_funcs - new_funcs
        
        # If we are missing functions, it's suspicious.
        if missing_funcs:
            # We list up to 3 for brevity
            missing_list = list(missing_funcs)[:3]
            suffix = "..." if len(missing_funcs) > 3 else ""
            msg = f"Missing definitions for existing functions: {', '.join(missing_list)}{suffix}. "
            
            raise ValueError(
                f"The new source code appears to be missing functions that were previously defined. {msg}"
                "This often happens when providing partial code updates. "
                "Please provide the COMPLETE source code including all existing functions. "
                "If you intentionally deleted these functions, set 'force_update=True'."
            )


async def get_all_capability_groups() -> List[Dict]:
    try:
        return await get_capability_groups_async()
    except Exception as exc:
        return "".join(format_exception_only(exc))


async def get_capability_group(name: str) -> Dict:
    try:
        return await get_capability_group_async(name)
    except Exception as exc:
        return "".join(format_exception_only(exc))


async def delete_capability_group(name: str) -> Dict:
    try:
        return await delete_capability_group_async(name)
    except Exception as exc:
        return "".join(format_exception_only(exc))


async def create_capability_group(name: str,
                                  runner_type: Optional[str] = None,
                                  shared_runner: Optional[bool] = None,
                                  setup_commands: Optional[str] = None,
                                  source_code: Optional[str] = None,
                                  functions: Optional[str] = None,
                                  auto_functions: Optional[str] = None,
                                  global_system_message: Optional[str] = None,
                                  global_config_parameters: Optional[Dict[str, Any]] = None,
                                  global_secret_config_parameters: Optional[Dict[str, Any]] = None) -> Dict:
    if setup_commands is not None:
        setup_commands = json.loads(setup_commands)
    if functions is not None:
        functions = json.loads(functions)
    if auto_functions is not None:
        auto_functions = json.loads(auto_functions)

    try:
        result = await create_capability_group_async(
            name=name,
            runner_type=runner_type,
            shared_runner=shared_runner,
            setup_commands=setup_commands,
            source_code=source_code,
            functions=functions,
            auto_functions=auto_functions,
            global_system_message=global_system_message,
            global_config_parameters=global_config_parameters,
            global_secret_config_parameters=global_secret_config_parameters)
        await _backup_capability(result)
        return result
    except Exception as exc:
        return "".join(format_exception_only(exc))


async def update_capability_group(name: str,
                                  new_name: Optional[str] = None,
                                  runner_type: Optional[str] = None,
                                  shared_runner: Optional[bool] = None,
                                  setup_commands: Optional[str] = None,
                                  source_code: Optional[str] = None,
                                  functions: Optional[str] = None,
                                  auto_functions: Optional[str] = None,
                                  global_system_message: Optional[str] = None,
                                  global_config_parameters: Optional[Dict[str, Any]] = None,
                                  global_secret_config_parameters: Optional[Dict[str, Any]] = None,
                                  force_update: bool = False) -> Dict:
    if setup_commands is not None:
        setup_commands = json.loads(setup_commands)
    if functions is not None:
        functions = json.loads(functions)
    if auto_functions is not None:
        auto_functions = json.loads(auto_functions)

    try:
        # Validate Source Code if provided and not forced
        if source_code is not None and not force_update:
            # We need to fetch the existing group to compare
            try:
                existing_group = await get_capability_group_async(name)
                existing_source = existing_group.get("sourceCode")
                _validate_full_source_code(source_code, existing_source)
            except CapabilityGroupException:
                # If group doesn't exist or fetch fails, we can't compare, 
                # but we can still check for placeholders in new code.
                _validate_full_source_code(source_code, None)

        result = await update_capability_group_async(
            name=name, new_name=new_name,
            runner_type=runner_type,
            shared_runner=shared_runner,
            setup_commands=setup_commands,
            source_code=source_code,
            functions=functions,
            auto_functions=auto_functions,
            global_system_message=global_system_message,
            global_config_parameters=global_config_parameters,
            global_secret_config_parameters=global_secret_config_parameters)
        await _backup_capability(result)
        return result
    except Exception as exc:
        return "".join(format_exception_only(exc))


async def add_function_to_group(name: str,
                                source_code: Optional[str] = None,
                                function: Optional[str] = None) -> Dict:
    if function is not None:
        function = json.loads(function)
    
    try:
        result = await add_function_to_capability_group_async(name, source_code, function)
        await _backup_capability(result)
        return result
    except Exception as exc:
        return "".join(format_exception_only(exc))


async def delete_function_from_group(name: str, function: str) -> Dict:
    try:
        result = await delete_function_from_capability_group_async(name, function)
        await _backup_capability(result)
        return result
    except Exception as exc:
        return "".join(format_exception_only(exc))


async def update_function_in_group(name: str,
                                   old_function_name: str,
                                   source_code: Optional[str] = None,
                                   new_function: Optional[str] = None) -> Dict:
    if new_function is not None:
        new_function = json.loads(new_function)
    
    try:
        result = await update_function_in_capability_group_async(
            name, 
            old_function_name, 
            source_code, 
            new_function
        )
        await _backup_capability(result)
        return result
    except Exception as exc:
        return "".join(format_exception_only(exc))


async def restore_capability_group(action: Literal["view", "restore"],
                                   name: str = None,
                                   backup_file: str = None):

    if action == "view":
        return _find_backups(name)
    elif action == "restore":
        if not backup_file:
            return "Error: backup_file must be specified for action 'restore'."
        backup_file_path = BACKUP_FOLDER / backup_file
        if not backup_file_path.exists():
            return f"Error: backup_file '{backup_file}' was not found."
        if not name:
            return "Error: name must be specified for action 'restore'."

        use_create = False
        try:
            await get_capability_group_async(name)
        except CapabilityGroupException:
            use_create = True

        try:
            if use_create:
                result = await create_capability_group_from_file_async(
                    name=name,
                    filepath=backup_file_path
                )
            else:
                result = await update_capability_group_from_file_async(
                    name=name,
                    filepath=backup_file_path
                )
            return result
        except Exception as exc:
            return "".join(format_exception_only(exc))
