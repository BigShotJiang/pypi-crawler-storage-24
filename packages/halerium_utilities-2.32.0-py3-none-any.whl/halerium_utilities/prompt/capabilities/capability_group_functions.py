from typing import Dict, Optional, Set, List, Union
import os
import ast
import warnings

from halerium_utilities.logging.exceptions import CapabilityGroupException
from .schemas import ParametersModel, FunctionModel, AutoFunctionModel
from .capabilities import get_capability_group, update_capability_group, get_capability_group_async, update_capability_group_async
from .source_code_parser import SourceCodeTransformer


def _get_source_code(name: str) -> str:
    """
    Retrieves the source code for a given capability group.

    Parameters
    ----------
    name : str
        The name of the capability group.

    Returns
    -------
    str
        The source code of the capability group.
    """
    # Get the existing source code
    existing_source_path = os.path.join("/home/jovyan", ".functions", name, "source.py")
    
    if os.path.exists(existing_source_path):
        with open(existing_source_path, "r") as f:
            return f.read()
    
    warnings.warn(
        f"Source code file not found at {existing_source_path}. "
        "Using empty source code.",
        UserWarning
    )
    return ""


def add_function_to_capability_group(name: str, 
                                     source_code: Optional[str] = None,
                                     function: Optional[Dict] = None) -> Dict:
    """
    Adds a function (regular or auto) to an existing capability group.

    Parameters
    ----------
    name : str
        The name of the capability group.
    source_code : str, optional
        The source code of the function.
    function : Dict, optional
        Function metadata to add. If 'executeAt' is present, treated as AutoFunction.

    Returns
    -------
    dict
        The result (status, error, ...) of the update attempt.
    """
    # Get the existing capability group details
    capability_group = get_capability_group(name)

    # Prepare updated source code
    existing_source_code = _get_source_code(name)
    updated_source_code = existing_source_code

    if source_code:
        function_name = function["function"] if function else None
        if not function_name:
            raise CapabilityGroupException(
                "Function name must be provided when adding source code"
            )
        
        updated_source_code = SourceCodeTransformer.add_function_to_source(
            existing_source_code, 
            source_code, 
            function_name
        )

    # Determine if AutoFunction or Regular Function
    is_auto = "executeAt" in function if function else False
    
    # Get existing lists
    existing_functions = capability_group.get("functions", [])
    existing_auto_functions = capability_group.get("autoFunctions", []) or []

    # Check for name collision
    func_name = function["function"] if function else None
    if func_name:
        if any(f["function"] == func_name for f in existing_functions):
             raise CapabilityGroupException(f"Function '{func_name}' already exists in regular functions.")
        if any(f["function"] == func_name for f in existing_auto_functions):
             raise CapabilityGroupException(f"Function '{func_name}' already exists in auto functions.")

    updated_functions = None
    updated_auto_functions = None

    if function:
        if is_auto:
            # Add to Auto Functions
            new_auto_func = AutoFunctionModel(
                function=function["function"],
                pretty_name=function.get("pretty_name"),
                description=function["description"],
                config_parameters=function.get("config_parameters", {}),
                executeAt=function["executeAt"]
            )
            updated_auto_functions = existing_auto_functions + [new_auto_func.dict()]
        else:
            # Add to Regular Functions
            new_func = FunctionModel(
                function=function["function"],
                pretty_name=function.get("pretty_name"),
                description=function["description"],
                config_parameters=function.get("config_parameters", {}),
                parameters=ParametersModel(
                    properties=function["parameters"].get("properties", {}),
                    required=function["parameters"].get("required", [])
                )
            )
            updated_functions = existing_functions + [new_func.dict()]

    # Update capability group
    update_result = update_capability_group(
        name=name,
        source_code=updated_source_code,
        functions=updated_functions,
        auto_functions=updated_auto_functions
    )

    return update_result


async def add_function_to_capability_group_async(name: str, 
                                                 source_code: Optional[str] = None,
                                                 function: Optional[Dict] = None) -> Dict:
    """
    Asynchronously adds a function (regular or auto) to an existing capability group.
    """
    # Get the existing capability group details
    capability_group = await get_capability_group_async(name)

    # Prepare updated source code
    existing_source_code = _get_source_code(name)
    updated_source_code = existing_source_code

    if source_code:
        function_name = function["function"] if function else None
        if not function_name:
            raise CapabilityGroupException(
                "Function name must be provided when adding source code"
            )
        
        updated_source_code = SourceCodeTransformer.add_function_to_source(
            existing_source_code, 
            source_code, 
            function_name
        )

    # Determine if AutoFunction or Regular Function
    is_auto = "executeAt" in function if function else False
    
    # Get existing lists
    existing_functions = capability_group.get("functions", [])
    existing_auto_functions = capability_group.get("autoFunctions", []) or []

    # Check for name collision
    func_name = function["function"] if function else None
    if func_name:
        if any(f["function"] == func_name for f in existing_functions):
             raise CapabilityGroupException(f"Function '{func_name}' already exists in regular functions.")
        if any(f["function"] == func_name for f in existing_auto_functions):
             raise CapabilityGroupException(f"Function '{func_name}' already exists in auto functions.")

    updated_functions = None
    updated_auto_functions = None

    if function:
        if is_auto:
            new_auto_func = AutoFunctionModel(
                function=function["function"],
                pretty_name=function.get("pretty_name"),
                description=function["description"],
                config_parameters=function.get("config_parameters", {}),
                executeAt=function["executeAt"]
            )
            updated_auto_functions = existing_auto_functions + [new_auto_func.dict()]
        else:
            new_func = FunctionModel(
                function=function["function"],
                pretty_name=function.get("pretty_name"),
                description=function["description"],
                config_parameters=function.get("config_parameters", {}),
                parameters=ParametersModel(
                    properties=function["parameters"].get("properties", {}),
                    required=function["parameters"].get("required", [])
                )
            )
            updated_functions = existing_functions + [new_func.dict()]

    # Update capability group
    update_result = await update_capability_group_async(
        name=name,
        source_code=updated_source_code,
        functions=updated_functions,
        auto_functions=updated_auto_functions
    )

    return update_result


def delete_function_from_capability_group(name: str, function: str) -> Dict:
    """
    Deletes a function (regular or auto) from an existing capability group.
    """
    # Get the existing capability group details
    capability_group = get_capability_group(name)

    existing_functions = capability_group.get("functions", [])
    existing_auto_functions = capability_group.get("autoFunctions", []) or []

    found_in_regular = any(func["function"] == function for func in existing_functions)
    found_in_auto = any(func["function"] == function for func in existing_auto_functions)

    if not found_in_regular and not found_in_auto:
        raise CapabilityGroupException(f"Function {function} not found in capability group {name}.")

    # Remove source code
    existing_source_code = _get_source_code(name)
    updated_source_code = SourceCodeTransformer.remove_function_from_source(
        existing_source_code, 
        function
    )

    updated_functions = None
    updated_auto_functions = None

    if found_in_regular:
        updated_functions = [func for func in existing_functions if func["function"] != function]
    
    if found_in_auto:
        updated_auto_functions = [func for func in existing_auto_functions if func["function"] != function]

    # Update capability group
    update_result = update_capability_group(
        name=name,
        source_code=updated_source_code,
        functions=updated_functions,
        auto_functions=updated_auto_functions
    )

    return update_result


async def delete_function_from_capability_group_async(name: str, function: str) -> Dict:
    """
    Asynchronously deletes a function (regular or auto) from an existing capability group.
    """
    capability_group = await get_capability_group_async(name)

    existing_functions = capability_group.get("functions", [])
    existing_auto_functions = capability_group.get("autoFunctions", []) or []

    found_in_regular = any(func["function"] == function for func in existing_functions)
    found_in_auto = any(func["function"] == function for func in existing_auto_functions)

    if not found_in_regular and not found_in_auto:
        raise CapabilityGroupException(f"Function {function} not found in capability group {name}.")

    existing_source_code = _get_source_code(name)
    updated_source_code = SourceCodeTransformer.remove_function_from_source(
        existing_source_code, 
        function
    )

    updated_functions = None
    updated_auto_functions = None

    if found_in_regular:
        updated_functions = [func for func in existing_functions if func["function"] != function]
    
    if found_in_auto:
        updated_auto_functions = [func for func in existing_auto_functions if func["function"] != function]

    update_result = await update_capability_group_async(
        name=name,
        source_code=updated_source_code,
        functions=updated_functions,
        auto_functions=updated_auto_functions
    )

    return update_result


def update_function_in_capability_group(name: str, 
                                        old_function_name: str,
                                        source_code: Optional[str] = None,
                                        new_function: Optional[Dict] = None) -> Dict:
    """
    Updates a function (regular or auto) in an existing capability group atomically.
    """
    if source_code is None and new_function is None:
        raise CapabilityGroupException(
            "At least one of 'source_code' or 'new_function' must be provided to update. "
            f"To update function '{old_function_name}', provide new source code and/or metadata."
        )
    
    capability_group = get_capability_group(name)

    updated_source_code, updated_functions, updated_auto_functions = _update_function_in_capability_group_helper(
        name=name,
        capability_group=capability_group,
        old_function_name=old_function_name,
        new_function=new_function,
        source_code=source_code,
    )
    
    update_result = update_capability_group(
        name=name,
        source_code=updated_source_code,
        functions=updated_functions,
        auto_functions=updated_auto_functions
    )

    return update_result


async def update_function_in_capability_group_async(name: str,
                                                    old_function_name: str,
                                                    source_code: Optional[str] = None,
                                                    new_function: Optional[Dict] = None) -> Dict:
    """
    Asynchronously updates a function (regular or auto) in an existing capability group atomically.
    """
    if source_code is None and new_function is None:
        raise CapabilityGroupException(
            "At least one of 'source_code' or 'new_function' must be provided to update. "
            f"To update function '{old_function_name}', provide new source code and/or metadata."
        )
    
    capability_group = await get_capability_group_async(name)

    updated_source_code, updated_functions, updated_auto_functions = _update_function_in_capability_group_helper(
        name=name,
        capability_group=capability_group,
        old_function_name=old_function_name,
        new_function=new_function,
        source_code=source_code,
    )
    
    update_result = await update_capability_group_async(
        name=name,
        source_code=updated_source_code,
        functions=updated_functions,
        auto_functions=updated_auto_functions
    )

    return update_result


def _update_function_in_capability_group_helper(
        name: str,
        capability_group: Dict,
        old_function_name: str,
        new_function: Optional[Dict],
        source_code: Optional[str],
):
    existing_functions = capability_group.get("functions", [])
    existing_auto_functions = capability_group.get("autoFunctions", []) or []

    # Find the function
    func_regular = next((f for f in existing_functions if f["function"] == old_function_name), None)
    func_auto = next((f for f in existing_auto_functions if f["function"] == old_function_name), None)

    if not func_regular and not func_auto:
        raise CapabilityGroupException(
            f"Function '{old_function_name}' not found in capability group '{name}'."
        )
    
    # Identify type
    is_currently_auto = func_auto is not None
    function_to_update = func_auto if is_currently_auto else func_regular

    # Identify NEW type (if metadata provided)
    if new_function:
        will_be_auto = "executeAt" in new_function
    else:
        will_be_auto = is_currently_auto
    
    new_func_name = new_function["function"] if new_function else old_function_name

    # Handle Source Code Update (same for both types)
    existing_source_code = _get_source_code(name)
    updated_source_code = existing_source_code

    if source_code is not None:
        updated_source_code = SourceCodeTransformer.remove_function_from_source(
            updated_source_code,
            old_function_name
        )
        updated_source_code = SourceCodeTransformer.add_function_to_source(
            updated_source_code,
            source_code,
            new_func_name
        )
    else:
        # Rename logic if name changed but source not provided
        if new_func_name != old_function_name:
            # (Assuming AST rename logic is similar to before, simplified for brevity but robust enough)
            # Re-using the logic from previous implementation manually here for clarity
            try:
                old_tree = SourceCodeTransformer._parse_source(existing_source_code)
                old_func_node = None
                for node in old_tree.body:
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == old_function_name:
                        old_func_node = node
                        break

                if old_func_node:
                    lines = existing_source_code.splitlines()
                    func_start = old_func_node.lineno - 1
                    func_end = old_func_node.end_lineno - 1 if hasattr(old_func_node, 'end_lineno') else func_start
                    old_func_source = '\n'.join(lines[func_start:func_end + 1])

                    old_func_tree = ast.parse(old_func_source)
                    for node in old_func_tree.body:
                        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            node.name = new_func_name
                    
                    renamed_source = ast.unparse(old_func_tree)

                    updated_source_code = SourceCodeTransformer.remove_function_from_source(
                        updated_source_code,
                        old_function_name
                    )
                    updated_source_code = SourceCodeTransformer.add_function_to_source(
                        updated_source_code,
                        renamed_source,
                        new_func_name
                    )
                else:
                    warnings.warn(
                        f"Could not find function '{old_function_name}' in source code to rename.",
                        UserWarning
                    )
            except Exception as e:
                warnings.warn(f"Failed to auto-rename source code: {e}", UserWarning)

    # Prepare lists for update
    # 1. Remove old entry
    updated_functions_list = [f for f in existing_functions if f["function"] != old_function_name]
    updated_auto_functions_list = [f for f in existing_auto_functions if f["function"] != old_function_name]

    # 2. Add new entry (if new metadata provided, use it; else reuse old metadata with new name)
    final_metadata = None
    if new_function:
        final_metadata = new_function
    else:
        # Clone old metadata
        final_metadata = function_to_update.copy()
        final_metadata["function"] = new_func_name
        # Note: if it was auto, it stays auto because will_be_auto logic above handles it
        # But we must ensure the dict structure is correct if we switch types?
        # Actually, if new_function is None, will_be_auto == is_currently_auto, so no switch.

    if will_be_auto:
        # Create AutoFunctionModel
        # Ensure it has executeAt. If we switched from regular to auto (only possible if new_function provided), it must have it.
        # If we stayed auto, it has it.
        if "executeAt" not in final_metadata:
             # Should not happen if logic is correct, but safe fallback or error?
             # If switching Regular -> Auto without providing executeAt, validation will fail.
             pass

        new_model = AutoFunctionModel(
            function=final_metadata["function"],
            pretty_name=final_metadata.get("pretty_name"),
            description=final_metadata["description"],
            config_parameters=final_metadata.get("config_parameters", {}),
            executeAt=final_metadata["executeAt"]
        )
        updated_auto_functions_list.append(new_model.dict())
    else:
        # Create FunctionModel
        # If switching Auto -> Regular, remove executeAt (pydantic ignores extra fields usually, but clean is better)
        new_model = FunctionModel(
            function=final_metadata["function"],
            pretty_name=final_metadata.get("pretty_name"),
            description=final_metadata["description"],
            config_parameters=final_metadata.get("config_parameters", {}),
            parameters=ParametersModel(
                properties=final_metadata.get("parameters", {}).get("properties", {}),
                required=final_metadata.get("parameters", {}).get("required", [])
            )
        )
        updated_functions_list.append(new_model.dict())

    # Return None for lists that were not modified implies "no change"?
    # No, update_capability_group treats None as "no update", so we must pass the modified list.
    # But wait, we modified one list (removed old) and maybe added to another.
    # If we moved from Regular to Auto:
    #   updated_functions_list (regular) has item removed.
    #   updated_auto_functions_list (auto) has item added.
    # We must return BOTH lists.
    
    return updated_source_code, updated_functions_list, updated_auto_functions_list
