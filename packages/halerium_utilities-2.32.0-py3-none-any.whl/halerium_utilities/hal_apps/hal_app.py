import asyncio
import httpx
from typing import List, Optional
from urllib.parse import quote

from halerium_utilities.utils.api_config import get_api_headers, get_api_base_url
from halerium_utilities.hal_apps.schemas import HalAppConfig, CustomAppParams, HalAppPayload

def _get_endpoint():
    return f"{get_api_base_url()}/token-access/hal-apps"

class HalApp:
    """
    Represents a Halerium Application (Custom App) instance.
    """

    def __init__(self, data: dict):
        self.data = data
        self._set_params(data)

    def _set_params(self, data):
        """Extracts data from API response into object attributes."""
        if "appConfig" in data and isinstance(data["appConfig"], dict):
            config = data["appConfig"]
        else:
            config = data

        self.name = config.get("name")
        self.description = config.get("description", "")
        self.app_type = config.get("appType", "custom")
        self.access_type = config.get("accessType", "workspace")
        self.runner_type = config.get("defaultRunnerType", "nano")
        self.app_params = config.get("appParams", {})
        
        # Helper for custom app specific params
        self.start_commands = self.app_params.get("startCmd", [])
        self.working_directory = self.app_params.get("workingDirectory", "/")
        
        self.friendly_url = data.get("friendlyUrl")
        self.id = data.get("id")

    def __repr__(self):
        return f"HalApp(name='{self.name}', type='{self.app_type}')"

    def _get_app_endpoint(self):
        # API usually uses app name as identifier in URL for convenience methods
        return f"{_get_endpoint()}/{quote(self.name)}"

    def start(self) -> bool:
        """Starts the application."""
        endpoint = f"{self._get_app_endpoint()}/start"
        with httpx.Client() as client:
            response = client.post(endpoint, headers=get_api_headers())
            response.raise_for_status()
            result = response.json()
            # Standard response handling
            if isinstance(result, dict) and "data" in result:
                return result["data"]
            return result

    async def start_async(self) -> bool:
        """Starts the application asynchronously."""
        endpoint = f"{self._get_app_endpoint()}/start"
        async with httpx.AsyncClient() as client:
            response = await client.post(endpoint, headers=get_api_headers())
            response.raise_for_status()
            result = response.json()
            if isinstance(result, dict) and "data" in result:
                return result["data"]
            return result

    def stop(self) -> bool:
        """Stops the application."""
        endpoint = f"{self._get_app_endpoint()}/stop"
        with httpx.Client() as client:
            response = client.post(endpoint, headers=get_api_headers())
            response.raise_for_status()
            result = response.json()
            if isinstance(result, dict) and "data" in result:
                return result["data"]
            return result

    async def stop_async(self) -> bool:
        """Stops the application asynchronously."""
        endpoint = f"{self._get_app_endpoint()}/stop"
        async with httpx.AsyncClient() as client:
            response = await client.post(endpoint, headers=get_api_headers())
            response.raise_for_status()
            result = response.json()
            if isinstance(result, dict) and "data" in result:
                return result["data"]
            return result

    def delete(self) -> bool:
        """Deletes the application."""
        endpoint = self._get_app_endpoint()
        with httpx.Client() as client:
            response = client.delete(endpoint, headers=get_api_headers())
            response.raise_for_status()
            result = response.json()
            if isinstance(result, dict) and "data" in result:
                return result["data"]
            return result

    async def delete_async(self) -> bool:
        """Deletes the application asynchronously."""
        endpoint = self._get_app_endpoint()
        async with httpx.AsyncClient() as client:
            response = await client.delete(endpoint, headers=get_api_headers())
            response.raise_for_status()
            result = response.json()
            if isinstance(result, dict) and "data" in result:
                return result["data"]
            return result
            
    def update(self, 
               description: str = None, 
               start_commands: List[str] = None, 
               working_directory: str = None,
               access_type: str = None,
               runner_type: str = None) -> "HalApp":
        """
        Updates the application configuration.

        Parameters
        ----------
        description : str, optional
            A description of the application.
        start_commands : List[str], optional
            A list of sequential shell commands to start the application.
            Example: `['pip install -r requirements.txt', 'python app.py']`.
            Use '{{port}}' as a placeholder for the port number if needed.
        working_directory : str, optional
            The working directory for the application.
        access_type : str, optional
            Visibility level: "workspace", "company", "company-user-groups", "public".
        runner_type : str, optional
            The runner size.
            Recommended: 'nano' (default) or 'small'.
            Advanced: 'standard', 'performance', 'highend', 'gpu' (may require specific workspace privileges).
        """
        
        # Construct update payload based on existing state + new values
        current_config = HalAppConfig(
            name=self.name,
            description=description if description is not None else self.description,
            appType=self.app_type, # Should remain 'custom'
            accessType=access_type if access_type is not None else self.access_type,
            defaultRunnerType=runner_type if runner_type is not None else self.runner_type,
            appParams=CustomAppParams(
                # Map new name to schema field 'startCmd'
                startCmd=start_commands if start_commands is not None else self.start_commands,
                workingDirectory=working_directory if working_directory is not None else self.working_directory
            )
        )
        
        # Updated to use model_dump() for Pydantic V2
        payload = HalAppPayload(appConfig=current_config).model_dump()
        
        endpoint = self._get_app_endpoint()
        with httpx.Client() as client:
            response = client.put(endpoint, headers=get_api_headers(), json=payload)
            response.raise_for_status()
            data = response.json()
            if "data" in data:
                data = data["data"]
            self.data = data
            self._set_params(data)
            return self

    async def update_async(self, 
                           description: str = None, 
                           start_commands: List[str] = None, 
                           working_directory: str = None,
                           access_type: str = None,
                           runner_type: str = None) -> "HalApp":
        """
        Updates the application configuration asynchronously.
        
        See `update` for parameter details.
        """
        
        current_config = HalAppConfig(
            name=self.name,
            description=description if description is not None else self.description,
            appType=self.app_type,
            accessType=access_type if access_type is not None else self.access_type,
            defaultRunnerType=runner_type if runner_type is not None else self.runner_type,
            appParams=CustomAppParams(
                startCmd=start_commands if start_commands is not None else self.start_commands,
                workingDirectory=working_directory if working_directory is not None else self.working_directory
            )
        )
        
        # Updated to use model_dump() for Pydantic V2
        payload = HalAppPayload(appConfig=current_config).model_dump()

        endpoint = self._get_app_endpoint()
        async with httpx.AsyncClient() as client:
            response = await client.put(endpoint, headers=get_api_headers(), json=payload)
            response.raise_for_status()
            data = response.json()
            if "data" in data:
                data = data["data"]
            self.data = data
            self._set_params(data)
            return self


def get_apps() -> List[HalApp]:
    """Retrieves all Halerium Applications."""
    endpoint = _get_endpoint()
    with httpx.Client() as client:
        response = client.get(endpoint, headers=get_api_headers())
        response.raise_for_status()
        data = response.json()
        
    apps = []
    items = data.get("data", []) if isinstance(data, dict) else data
    for item in items:
        apps.append(HalApp(item))
    return apps


async def get_apps_async() -> List[HalApp]:
    """Retrieves all Halerium Applications asynchronously."""
    endpoint = _get_endpoint()
    async with httpx.AsyncClient() as client:
        response = await client.get(endpoint, headers=get_api_headers())
        response.raise_for_status()
        data = response.json()
        
    apps = []
    items = data.get("data", []) if isinstance(data, dict) else data
    for item in items:
        apps.append(HalApp(item))
    return apps


def get_app(name: str) -> HalApp:
    """Retrieves a specific Halerium Application by name."""
    endpoint = f"{_get_endpoint()}/{quote(name)}"
    
    with httpx.Client() as client:
        response = client.get(endpoint, headers=get_api_headers())
        response.raise_for_status()
        data = response.json()
        if "data" in data:
            data = data["data"]
        return HalApp(data)


async def get_app_async(name: str) -> HalApp:
    """Retrieves a specific Halerium Application by name asynchronously."""
    endpoint = f"{_get_endpoint()}/{quote(name)}"
    
    async with httpx.AsyncClient() as client:
        response = await client.get(endpoint, headers=get_api_headers())
        response.raise_for_status()
        data = response.json()
        if "data" in data:
            data = data["data"]
        return HalApp(data)


def create_app(name: str, 
               start_commands: List[str], 
               working_directory: str = "/",
               description: str = "",
               access_type: str = "workspace",
               runner_type: str = "nano") -> HalApp:
    """
    Creates a new Custom Halerium Application.

    Parameters
    ----------
    name : str
        The name of the application.
    start_commands : List[str]
        A list of sequential shell commands to start the application.
        Example: `['pip install -r requirements.txt', 'python app.py']`.
        If your application binds to a port, use '{{port}}' as a placeholder 
        (e.g., ["streamlit run app.py --server.port {{port}}"]).
    working_directory : str, optional
        The working directory for the application, by default "/".
    description : str, optional
        A description of the application.
    access_type : str, optional
        Visibility level: "workspace", "company", "company-user-groups", "public". Default is "workspace".
    runner_type : str, optional
        The runner size.
        Recommended: 'nano' (default) or 'small'.
        Advanced: 'standard', 'performance', 'highend', 'gpu' (may require specific workspace privileges).
    """
    
    config = HalAppConfig(
        name=name,
        description=description,
        appType="custom",
        accessType=access_type,
        defaultRunnerType=runner_type,
        appParams=CustomAppParams(
            # Map new name to schema field 'startCmd'
            startCmd=start_commands,
            workingDirectory=working_directory
        )
    )
    
    # Updated to use model_dump() for Pydantic V2
    payload = HalAppPayload(appConfig=config).model_dump()

    endpoint = _get_endpoint()
    with httpx.Client() as client:
        response = client.post(endpoint, headers=get_api_headers(), json=payload)
        response.raise_for_status()
        data = response.json()
        if "data" in data:
            data = data["data"]
        return HalApp(data)


async def create_app_async(name: str, 
                           start_commands: List[str], 
                           working_directory: str = "/",
                           description: str = "",
                           access_type: str = "workspace",
                           runner_type: str = "nano") -> HalApp:
    """
    Creates a new Custom Halerium Application asynchronously.
    
    See `create_app` for parameter details.
    """
    
    config = HalAppConfig(
        name=name,
        description=description,
        appType="custom",
        accessType=access_type,
        defaultRunnerType=runner_type,
        appParams=CustomAppParams(
            startCmd=start_commands,
            workingDirectory=working_directory
        )
    )
    
    # Updated to use model_dump() for Pydantic V2
    payload = HalAppPayload(appConfig=config).model_dump()

    endpoint = _get_endpoint()
    async with httpx.AsyncClient() as client:
        response = await client.post(endpoint, headers=get_api_headers(), json=payload)
        response.raise_for_status()
        data = response.json()
        if "data" in data:
            data = data["data"]
        return HalApp(data)
