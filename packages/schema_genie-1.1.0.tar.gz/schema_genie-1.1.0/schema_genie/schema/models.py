from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class ColumnDefinition:
    name: str
    semantic_type: str          # "measure" | "date" | "id" | "category" | "text" | "currency"
    sql_type: str               # Warehouse-specific SQL type string
    nullable: bool = True
    is_primary_key: bool = False
    is_surrogate_key: bool = False
    is_scd_candidate: bool = False


@dataclass
class ForeignKey:
    column: str
    references_table: str
    references_column: str


@dataclass
class TableDefinition:
    name: str
    columns: List[ColumnDefinition]
    table_role: str             # "fact" | "dimension"
    primary_key: Optional[str] = None
    foreign_keys: List[ForeignKey] = field(default_factory=list)

    @property
    def measure_columns(self):
        return [c for c in self.columns if c.semantic_type in ("measure", "currency")]

    @property
    def dimension_columns(self):
        return [c for c in self.columns if c.semantic_type == "category"]


@dataclass
class InferredSchema:
    recommended_type: str       # "star" | "snowflake"
    fact_table: TableDefinition
    dimension_tables: List[TableDefinition]
    relationships: list
    ddl: str = ""
    scd_candidates: List[str] = field(default_factory=list)
    confidence_score: float = 0.0

    def export_ddl(self, path: str) -> None:
        """Write the generated DDL to a .sql file."""
        if not self.ddl:
            raise ValueError("No DDL available. Run SchemaGenie.infer() first.")
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.ddl)

    def export_diagram(self, path: str, fmt: str = "png") -> None:
        """Export an ER diagram to PNG or SVG. Requires the diagram extra."""
        from ..diagram import export_diagram
        export_diagram(self, path, fmt=fmt)

    def summary(self) -> str:
        """Return a human-readable summary of the inferred schema."""
        lines = [
            f"Schema Type  : {self.recommended_type}",
            f"Fact Table   : {self.fact_table.name}",
            f"Dimensions   : {[t.name for t in self.dimension_tables]}",
            f"SCD Candidates: {self.scd_candidates}",
            f"Confidence   : {self.confidence_score:.2f}",
        ]
        return "\n".join(lines)
