"""SCD (Slowly Changing Dimension) Type 2 candidate detection."""
from typing import List, Optional

import pandas as pd

from .models import TableDefinition

# Columns that are NOT SCD candidates — they change too frequently or are flags
_EXCLUDED_NAMES = frozenset({
    "status", "type", "flag", "is_active", "is_deleted",
    "is_current", "active", "enabled",
})


def detect_scd_candidates(
    table: TableDefinition,
    df: Optional[pd.DataFrame] = None,
) -> List[str]:
    """
    Return a list of column names that are likely SCD Type 2 candidates.

    Heuristic: category columns on dimension tables that are not simple flag/status
    columns may represent slowly-changing attributes (e.g., customer segment, region).
    """
    if table.table_role != "dimension":
        return []

    candidates = []
    for col in table.columns:
        if col.semantic_type == "category" and col.name.lower() not in _EXCLUDED_NAMES:
            candidates.append(col.name)

    return candidates
