"""ER diagram export using Graphviz (optional dependency)."""
from .schema.models import InferredSchema


def export_diagram(schema: InferredSchema, path: str, fmt: str = "png") -> None:
    """
    Export an ER diagram of the inferred schema to a PNG or SVG file.

    Requires: pip install schema-genie[diagram]

    Parameters
    ----------
    schema:
        The InferredSchema returned by SchemaGenie.infer() or infer_multi().
    path:
        Output file path (without extension — graphviz appends it automatically).
    fmt:
        Output format: "png" | "svg" | "pdf"
    """
    try:
        import graphviz
    except ImportError:
        raise ImportError(
            "graphviz not installed. Run: pip install schema-genie[diagram]"
        )

    dot = graphviz.Digraph(
        name="ER Diagram",
        comment=f"schema-genie — {schema.recommended_type} schema",
        format=fmt,
    )
    dot.attr(rankdir="LR", fontname="Helvetica")
    dot.attr("node", shape="none", margin="0")

    def _table_html(table, header_color: str) -> str:
        rows = [
            f'<TR><TD BGCOLOR="{header_color}" ALIGN="CENTER">'
            f'<B>{table.name}</B>'
            f'</TD></TR>'
        ]
        for col in table.columns:
            pk_marker = " [PK]" if col.is_primary_key else ""
            rows.append(
                f'<TR><TD ALIGN="LEFT" PORT="{col.name}">'
                f'{col.name}: {col.semantic_type}{pk_marker}'
                f'</TD></TR>'
            )
        inner = "".join(rows)
        return (
            f'<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" '
            f'CELLPADDING="4">{inner}</TABLE>>'
        )

    # Fact table — blue header
    dot.node(
        schema.fact_table.name,
        label=_table_html(schema.fact_table, "#4A90D9"),
    )

    # Dimension tables — green header
    for dim in schema.dimension_tables:
        dot.node(dim.name, label=_table_html(dim, "#5DAE5D"))

    # Relationships as edges
    for rel in schema.relationships:
        from_t = rel.get("from_table", "")
        to_t   = rel.get("to_table",   "")
        from_c = rel.get("from_column", "")
        to_c   = rel.get("to_column",  "")
        score  = rel.get("score", "")
        label  = f'{from_c} → {to_c}\n(score: {score})'
        if from_t and to_t:
            dot.edge(from_t, to_t, label=label, fontsize="9")

    dot.render(path, cleanup=True)
