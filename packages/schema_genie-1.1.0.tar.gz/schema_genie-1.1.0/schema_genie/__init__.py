"""
schema-genie
============
Automatically infer optimal star and snowflake schemas from raw CSVs or
DataFrames, and generate production-ready DDL for Redshift, BigQuery,
Snowflake, and PostgreSQL.

Quick start
-----------
>>> import pandas as pd
>>> from schema_genie import SchemaGenie
>>>
>>> df = pd.read_csv("sales.csv")
>>> genie = SchemaGenie(target="snowflake")
>>> schema = genie.infer(df, table_name="sales")
>>> print(schema.recommended_type)
>>> print(schema.ddl)
>>> schema.export_ddl("schema.sql")
"""
from .genie import SchemaGenie
from .schema.models import ColumnDefinition, ForeignKey, InferredSchema, TableDefinition

__version__ = "1.0.0"
__all__ = [
    "SchemaGenie",
    "InferredSchema",
    "TableDefinition",
    "ColumnDefinition",
    "ForeignKey",
]
