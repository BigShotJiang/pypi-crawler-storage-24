"""Star vs. snowflake schema recommendation."""
from typing import List

from ..schema.models import TableDefinition


def recommend_schema_type(
    dim_tables: List[TableDefinition],
    category_threshold: float = 0.4,
) -> str:
    """
    Recommend "star" or "snowflake" based on dimension table characteristics.

    Decision rule:
    - If any dimension table has > category_threshold of its columns typed as
      "category", it likely has sub-dimensions worth normalising → "snowflake".
    - Otherwise the flat star schema is sufficient.

    Parameters
    ----------
    dim_tables:
        List of TableDefinition objects for all dimension tables.
    category_threshold:
        Fraction of category columns required to trigger a snowflake recommendation.

    Returns
    -------
    "star" | "snowflake"
    """
    for table in dim_tables:
        if not table.columns:
            continue
        category_count = sum(1 for c in table.columns if c.semantic_type == "category")
        category_ratio = category_count / len(table.columns)
        if category_ratio > category_threshold:
            return "snowflake"
    return "star"
