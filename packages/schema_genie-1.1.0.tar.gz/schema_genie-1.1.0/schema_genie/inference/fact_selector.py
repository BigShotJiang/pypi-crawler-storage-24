"""Fact table identification via scoring."""
import math
from typing import Dict

import pandas as pd


def score_table(df: pd.DataFrame, type_map: dict) -> float:
    """
    Score a table on how likely it is to be the fact table.

    fact_score = (n_measure_columns / n_total_columns)
               + (n_foreign_key_candidates * 0.2)
               + (log10(n_rows) / 10)

    Higher score → more likely to be the fact table.
    """
    n = len(df.columns)
    if n == 0:
        return 0.0

    measure_count = sum(1 for t in type_map.values() if t in ("measure", "currency"))
    id_count      = sum(1 for t in type_map.values() if t == "id")
    row_score     = math.log10(max(len(df), 1)) / 10

    return (measure_count / n) + (id_count * 0.2) + row_score


def select_fact_table(
    dataframes: Dict[str, pd.DataFrame],
    type_maps: Dict[str, dict],
) -> str:
    """
    Return the name of the table most likely to be the fact table.

    The table with the highest fact_score wins.
    """
    if not dataframes:
        raise ValueError("dataframes must not be empty")

    scores = {
        name: score_table(df, type_maps[name])
        for name, df in dataframes.items()
    }
    return max(scores, key=scores.get)
