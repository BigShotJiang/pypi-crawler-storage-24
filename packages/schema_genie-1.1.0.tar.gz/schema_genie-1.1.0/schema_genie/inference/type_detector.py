"""Semantic type detection for DataFrame columns."""
import re

import numpy as np
import pandas as pd

ID_PATTERNS       = re.compile(r'(^id$|_id$|_key$|^id_)', re.IGNORECASE)
DATE_PATTERNS     = re.compile(r'(date|time|created|updated|at$)', re.IGNORECASE)
CURRENCY_PATTERNS = re.compile(r'(price|revenue|amount|cost|fee|tax|salary|total|gross|net)', re.IGNORECASE)


def detect_type(col_name: str, series: pd.Series, normalize_threshold: float = 0.05) -> str:
    """
    Infer the semantic type for a single column.

    Returns one of: "id" | "date" | "currency" | "measure" | "category" | "text"

    Detection order (first match wins):
    1. Name heuristics for IDs
    2. Datetime dtype or date name patterns
    3. Numeric: currency name → "currency"; low cardinality → "category"; else → "measure"
    4. String: low cardinality → "category"; else → "text"
    """
    name = col_name.lower()

    # 1. ID check
    if ID_PATTERNS.search(name):
        return "id"

    # 2. Date check
    if pd.api.types.is_datetime64_any_dtype(series) or DATE_PATTERNS.search(name):
        return "date"

    n_rows = max(len(series), 1)
    cardinality_ratio = series.nunique() / n_rows
    null_ratio = series.isna().mean()

    # 3. Numeric columns
    if pd.api.types.is_numeric_dtype(series):
        if CURRENCY_PATTERNS.search(name):
            return "currency"
        if cardinality_ratio < normalize_threshold:
            return "category"   # e.g., numeric status codes with few distinct values
        return "measure"

    # 4. String / object columns
    if pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series):
        if cardinality_ratio < normalize_threshold:
            return "category"
        return "text"

    # Boolean columns
    if pd.api.types.is_bool_dtype(series):
        return "category"

    return "text"


def detect_all_types(df: pd.DataFrame, normalize_threshold: float = 0.05) -> dict:
    """Return a dict mapping column name → semantic type for every column in df."""
    return {
        col: detect_type(col, df[col], normalize_threshold)
        for col in df.columns
    }
