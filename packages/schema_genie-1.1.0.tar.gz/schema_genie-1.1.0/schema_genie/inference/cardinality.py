"""Cardinality analysis for DataFrame columns."""
from typing import Dict

import pandas as pd


def compute_cardinality(df: pd.DataFrame) -> Dict[str, float]:
    """
    Compute the unique-value ratio (cardinality ratio) for every column.

    Returns a dict: {column_name: n_unique / n_rows}
    A ratio close to 0 means low cardinality (dimension candidate).
    A ratio close to 1 means high cardinality (measure / ID candidate).
    """
    n = max(len(df), 1)
    return {col: df[col].nunique() / n for col in df.columns}


def categorize_cardinality(ratio: float, low_threshold: float = 0.05, high_threshold: float = 0.95) -> str:
    """
    Classify a cardinality ratio into a descriptive bucket.

    Returns: "low" | "medium" | "high"
    """
    if ratio <= low_threshold:
        return "low"
    if ratio >= high_threshold:
        return "high"
    return "medium"


def cardinality_report(df: pd.DataFrame, low_threshold: float = 0.05, high_threshold: float = 0.95) -> Dict[str, dict]:
    """
    Return a full cardinality report for every column.

    Each entry contains:
        ratio      — unique-value ratio
        n_unique   — number of distinct non-null values
        bucket     — "low" | "medium" | "high"
        null_pct   — percentage of null values
    """
    n = max(len(df), 1)
    report = {}
    for col in df.columns:
        n_unique = df[col].nunique()
        ratio = n_unique / n
        report[col] = {
            "ratio":    ratio,
            "n_unique": n_unique,
            "bucket":   categorize_cardinality(ratio, low_threshold, high_threshold),
            "null_pct": df[col].isna().mean() * 100,
        }
    return report
