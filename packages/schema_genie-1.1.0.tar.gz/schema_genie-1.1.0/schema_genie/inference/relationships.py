"""FK-like relationship detection via value-intersection scoring across tables."""
from typing import Dict, List

import pandas as pd


def _intersection_score(series_a: pd.Series, series_b: pd.Series) -> float:
    """
    Compute the fraction of the smaller set that overlaps with the larger set.

    Score = |A ∩ B| / min(|A|, |B|)
    A score >= threshold suggests a FK relationship.
    """
    vals_a = set(series_a.dropna().astype(str))
    vals_b = set(series_b.dropna().astype(str))
    smaller = min(len(vals_a), len(vals_b))
    if smaller == 0:
        return 0.0
    return len(vals_a & vals_b) / smaller


def _columns_are_related(col_a: str, col_b: str) -> bool:
    """
    Pre-filter: only compare columns that share a name stem to limit O(n^2) comparisons.
    e.g., "customer_id" vs "customer_id", or "product_id" vs "product_id".
    """
    a, b = col_a.lower(), col_b.lower()
    return a == b or a.rstrip("_id") == b.rstrip("_id") or a.rstrip("_key") == b.rstrip("_key")


def detect_relationships(
    dataframes: Dict[str, pd.DataFrame],
    threshold: float = 0.8,
) -> List[dict]:
    """
    Detect FK-like relationships between tables using value intersection scoring.

    For each pair of tables, compare columns that share a name stem.
    If the intersection score meets the threshold the pair is flagged as a relationship.

    Returns a list of dicts:
        {
            "from_table":  str,
            "from_column": str,
            "to_table":    str,
            "to_column":   str,
            "score":       float,
        }
    """
    relationships: List[dict] = []
    names = list(dataframes.keys())

    for i, name_a in enumerate(names):
        for name_b in names[i + 1:]:
            df_a = dataframes[name_a]
            df_b = dataframes[name_b]

            for col_a in df_a.columns:
                for col_b in df_b.columns:
                    if not _columns_are_related(col_a, col_b):
                        continue

                    score = _intersection_score(df_a[col_a], df_b[col_b])
                    if score >= threshold:
                        relationships.append({
                            "from_table":  name_a,
                            "from_column": col_a,
                            "to_table":    name_b,
                            "to_column":   col_b,
                            "score":       round(score, 4),
                        })

    return relationships
