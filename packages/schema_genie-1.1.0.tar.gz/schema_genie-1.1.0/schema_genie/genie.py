"""SchemaGenie — the main public class."""
import pandas as pd
from typing import Any, Dict, Optional, Union

from .inference.type_detector import detect_all_types
from .inference.fact_selector import select_fact_table
from .inference.relationships import detect_relationships
from .inference.schema_recommender import recommend_schema_type
from .schema.models import (
    ColumnDefinition,
    ForeignKey,
    InferredSchema,
    TableDefinition,
)
from .schema.scd import detect_scd_candidates
from .generators.snowflake import SnowflakeDDLGenerator
from .generators.redshift import RedshiftDDLGenerator
from .generators.bigquery import BigQueryDDLGenerator
from .generators.postgres import PostgresDDLGenerator

GENERATORS = {
    "snowflake": SnowflakeDDLGenerator,
    "redshift":  RedshiftDDLGenerator,
    "bigquery":  BigQueryDDLGenerator,
    "postgres":  PostgresDDLGenerator,
}


class SchemaGenie:
    """
    Automatically infer star or snowflake schemas from raw DataFrames or CSVs
    and generate production-ready DDL for major data warehouses.

    Parameters
    ----------
    target:
        Warehouse target for DDL generation.
        One of: "snowflake" | "redshift" | "bigquery" | "postgres"
    schema_type:
        Force a specific schema type or let the engine decide.
        "auto" | "star" | "snowflake"
    primary_key_strategy:
        How primary keys are generated.
        "surrogate" (default) — auto-increment surrogate keys.
        "natural"             — use the detected ID column as PK.
    detect_scd:
        Whether to flag slowly-changing dimension candidates.
    normalize_threshold:
        Cardinality ratio below which a column is treated as a category/dimension.
        Default: 0.05 (5%).
    """

    def __init__(
        self,
        target: str = "snowflake",
        schema_type: str = "auto",
        primary_key_strategy: str = "surrogate",
        detect_scd: bool = True,
        normalize_threshold: float = 0.05,
    ):
        self.target = target.lower()
        self.schema_type = schema_type
        self.primary_key_strategy = primary_key_strategy
        self.detect_scd = detect_scd
        self.normalize_threshold = normalize_threshold

        generator_cls = GENERATORS.get(self.target)
        if generator_cls is None:
            raise ValueError(
                f"Unsupported target '{target}'. Choose from: {list(GENERATORS)}"
            )
        self._generator = generator_cls()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def infer(self, df: pd.DataFrame, table_name: str = "main") -> InferredSchema:
        """Infer a schema from a single DataFrame."""
        return self.infer_multi({table_name: df})

    def infer_multi(self, dataframes: Dict[str, pd.DataFrame]) -> InferredSchema:
        """
        Infer a schema across multiple related DataFrames.

        This runs the full 6-stage pipeline:
          1. Type detection
          2. Cardinality analysis (embedded in type detection)
          3. Relationship detection
          4. Fact table selection
          5. Schema type recommendation
          6. DDL generation
        """
        if not dataframes:
            raise ValueError("dataframes must not be empty")

        # Stage 1 — Detect semantic types for every table
        type_maps = {
            name: detect_all_types(df, self.normalize_threshold)
            for name, df in dataframes.items()
        }

        # Stage 3 — Detect FK-like relationships between tables
        relationships = []
        if len(dataframes) > 1:
            relationships = detect_relationships(dataframes)

        # Stage 4 — Select fact table
        fact_name = select_fact_table(dataframes, type_maps)
        dim_names = [n for n in dataframes if n != fact_name]

        # Stage 4b — Build TableDefinition objects
        def _build_table(name: str, df: pd.DataFrame, role: str) -> TableDefinition:
            type_map = type_maps[name]
            columns = [
                ColumnDefinition(
                    name=col,
                    semantic_type=type_map[col],
                    sql_type=self._generator.col_type(type_map[col]),
                    nullable=bool(df[col].isna().any()),
                    is_primary_key=(type_map[col] == "id"),
                )
                for col in df.columns
            ]

            # Attach FK objects for relationships that reference this table
            foreign_keys = []
            for rel in relationships:
                if rel["from_table"] == name:
                    foreign_keys.append(
                        ForeignKey(
                            column=rel["from_column"],
                            references_table=rel["to_table"],
                            references_column=rel["to_column"],
                        )
                    )

            pk_col = next(
                (c.name for c in columns if c.is_primary_key), None
            )
            return TableDefinition(
                name=name,
                columns=columns,
                table_role=role,
                primary_key=pk_col,
                foreign_keys=foreign_keys,
            )

        fact_table = _build_table(fact_name, dataframes[fact_name], "fact")
        dim_tables = [_build_table(n, dataframes[n], "dimension") for n in dim_names]

        # Stage 5 — Recommend schema type
        if self.schema_type == "auto":
            rec_type = recommend_schema_type(dim_tables)
        else:
            rec_type = self.schema_type

        # SCD candidate detection
        scd_candidates: list = []
        if self.detect_scd:
            for table in dim_tables:
                scd_candidates.extend(
                    detect_scd_candidates(table, dataframes.get(table.name))
                )

        # Stage 6 — Build InferredSchema and generate DDL
        schema = InferredSchema(
            recommended_type=rec_type,
            fact_table=fact_table,
            dimension_tables=dim_tables,
            relationships=relationships,
            scd_candidates=scd_candidates,
            confidence_score=self._confidence(fact_table, dim_tables, relationships),
        )
        schema.ddl = self._generator.generate(schema)
        return schema

    def deploy(self, connection: Any = None, schema: Optional[InferredSchema] = None, **kwargs) -> None:
        """
        Execute the generated DDL against a live warehouse connection.

        Parameters
        ----------
        connection:
            An open DB connection (snowflake.connector, psycopg2, bigquery.Client).
            Pass None to open a new connection using kwargs.
        schema:
            The InferredSchema whose DDL should be deployed.
            If None, raises an error — call infer() first.
        **kwargs:
            Forwarded to the underlying connector if connection is None.
        """
        from .deploy import deploy_ddl
        if schema is None:
            raise ValueError("Pass the InferredSchema returned by infer() as schema=")
        deploy_ddl(self.target, schema.ddl, connection=connection, **kwargs)

    @classmethod
    def from_config(cls, path: str) -> "SchemaGenie":
        """Load SchemaGenie configuration from a YAML file."""
        import yaml
        with open(path, encoding="utf-8") as f:
            config = yaml.safe_load(f)
        return cls(**config)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _confidence(
        self,
        fact_table: TableDefinition,
        dim_tables: list,
        relationships: list,
    ) -> float:
        """
        Heuristic confidence score in [0, 1].

        Penalised when:
        - There are no dimension tables (isolated fact table)
        - No detected relationships
        - Fact table has very few measure columns
        """
        score = 1.0

        if not dim_tables:
            score -= 0.3

        if not relationships and dim_tables:
            score -= 0.2

        total_cols = len(fact_table.columns)
        measure_cols = len(fact_table.measure_columns)
        if total_cols > 0 and measure_cols / total_cols < 0.1:
            score -= 0.2

        return max(round(score, 2), 0.0)
