"""DDL generator for Google BigQuery."""
from .base import BaseDDLGenerator
from ..schema.models import InferredSchema, TableDefinition

TYPE_MAP = {
    "id":       "STRING",
    "measure":  "FLOAT64",
    "currency": "NUMERIC",
    "date":     "TIMESTAMP",
    "category": "STRING",
    "text":     "STRING",
}


class BigQueryDDLGenerator(BaseDDLGenerator):
    TYPE_MAP = TYPE_MAP

    def generate(self, schema: InferredSchema) -> str:
        parts = []
        for dim in schema.dimension_tables:
            parts.append(self._table_ddl(dim))
        parts.append(self._table_ddl(schema.fact_table))
        return "\n\n".join(parts)

    def _table_ddl(self, table: TableDefinition) -> str:
        # BigQuery uses CREATE TABLE IF NOT EXISTS; no FK constraints in DDL
        lines = [f"CREATE TABLE IF NOT EXISTS `{table.name}` ("]
        col_lines = []

        # Surrogate key (INT64 in BigQuery)
        col_lines.append(f"    {table.name}_key         INT64")

        for col in table.columns:
            sql_type = TYPE_MAP.get(col.semantic_type, "STRING")
            mode = "NULL" if col.nullable else "NOT NULL"
            col_lines.append(f"    {col.name:<30} {sql_type}  OPTIONS(description='{mode}')")

        if table.table_role == "dimension":
            col_lines.append("    _valid_from              TIMESTAMP")
            col_lines.append("    _valid_to                TIMESTAMP")
            col_lines.append("    _is_current              BOOL")

        col_lines.append("    _loaded_at               TIMESTAMP  OPTIONS(description='ETL load timestamp')")

        lines.append(",\n".join(col_lines))

        if table.table_role == "fact":
            # Partition on a date column if present
            date_cols = [c.name for c in table.columns if c.semantic_type == "date"]
            if date_cols:
                lines.append(f")")
                lines.append(f"PARTITION BY DATE({date_cols[0]});")
            else:
                lines.append(");")
        else:
            lines.append(");")

        return "\n".join(lines)
