"""DDL generator for Amazon Redshift."""
from .base import BaseDDLGenerator
from ..schema.models import InferredSchema, TableDefinition

TYPE_MAP = {
    "id":       "VARCHAR(64)",
    "measure":  "FLOAT8",
    "currency": "DECIMAL(18,2)",
    "date":     "TIMESTAMP",
    "category": "VARCHAR(128)",
    "text":     "VARCHAR(65535)",
}


class RedshiftDDLGenerator(BaseDDLGenerator):
    TYPE_MAP = TYPE_MAP

    def generate(self, schema: InferredSchema) -> str:
        parts = []
        for dim in schema.dimension_tables:
            parts.append(self._table_ddl(dim))
        parts.append(self._table_ddl(schema.fact_table))
        return "\n\n".join(parts)

    def _table_ddl(self, table: TableDefinition) -> str:
        lines = [f"CREATE TABLE {table.name} ("]
        col_lines = []

        # Redshift uses IDENTITY for surrogate keys
        col_lines.append(f"    {table.name}_key         INTEGER IDENTITY(1,1) PRIMARY KEY")

        for col in table.columns:
            sql_type = TYPE_MAP.get(col.semantic_type, "VARCHAR(255)")
            nullable = "" if col.nullable else " NOT NULL"
            col_lines.append(f"    {col.name:<30} {sql_type}{nullable}")

        if table.table_role == "dimension":
            col_lines.append("    _valid_from              TIMESTAMP      DEFAULT GETDATE()")
            col_lines.append("    _valid_to                TIMESTAMP")
            col_lines.append("    _is_current              BOOLEAN        DEFAULT TRUE")

        col_lines.append("    _loaded_at               TIMESTAMP      DEFAULT GETDATE()")

        for fk in table.foreign_keys:
            col_lines.append(
                f"    FOREIGN KEY ({fk.column}) REFERENCES {fk.references_table}({fk.references_column})"
            )

        # Redshift distribution / sort key hints
        lines.append(",\n".join(col_lines))
        lines.append(")")

        if table.table_role == "fact":
            # Distribute by first ID column if available
            id_cols = [c.name for c in table.columns if c.semantic_type == "id"]
            if id_cols:
                lines.append(f"DISTKEY({id_cols[0]})")
                lines.append(f"SORTKEY({id_cols[0]});")
            else:
                lines.append(";")
        else:
            lines.append(";")

        return "\n".join(lines)
