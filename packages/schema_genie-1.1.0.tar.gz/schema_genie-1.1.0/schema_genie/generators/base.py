"""Abstract base class for DDL generators."""
from abc import ABC, abstractmethod

from ..schema.models import InferredSchema, TableDefinition


class BaseDDLGenerator(ABC):
    """
    All warehouse-specific DDL generators inherit from this class.

    Subclasses must define:
        TYPE_MAP  — dict mapping semantic type → warehouse SQL type string
        generate  — accepts an InferredSchema and returns a DDL string
    """

    TYPE_MAP: dict = {}

    @abstractmethod
    def generate(self, schema: InferredSchema) -> str:
        """Generate and return the full DDL for the given inferred schema."""

    def col_type(self, semantic_type: str) -> str:
        """Resolve a semantic type to the warehouse-specific SQL type."""
        return self.TYPE_MAP.get(semantic_type, "VARCHAR(255)")

    def _format_col_line(self, name: str, sql_type: str, nullable: bool, width: int = 30) -> str:
        null_clause = "" if nullable else " NOT NULL"
        return f"    {name:<{width}} {sql_type}{null_clause}"
