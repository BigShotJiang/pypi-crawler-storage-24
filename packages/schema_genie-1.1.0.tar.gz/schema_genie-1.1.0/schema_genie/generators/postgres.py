"""DDL generator for PostgreSQL."""
from .base import BaseDDLGenerator
from ..schema.models import InferredSchema, TableDefinition

TYPE_MAP = {
    "id":       "VARCHAR(64)",
    "measure":  "DOUBLE PRECISION",
    "currency": "NUMERIC(18,2)",
    "date":     "TIMESTAMPTZ",
    "category": "VARCHAR(128)",
    "text":     "TEXT",
}


class PostgresDDLGenerator(BaseDDLGenerator):
    TYPE_MAP = TYPE_MAP

    def generate(self, schema: InferredSchema) -> str:
        parts = []
        for dim in schema.dimension_tables:
            parts.append(self._table_ddl(dim))
        parts.append(self._table_ddl(schema.fact_table))
        return "\n\n".join(parts)

    def _table_ddl(self, table: TableDefinition) -> str:
        lines = [f"CREATE TABLE IF NOT EXISTS {table.name} ("]
        col_lines = []

        # Postgres SERIAL as surrogate key
        col_lines.append(f"    {table.name}_key         SERIAL PRIMARY KEY")

        for col in table.columns:
            sql_type = TYPE_MAP.get(col.semantic_type, "TEXT")
            nullable = "" if col.nullable else " NOT NULL"
            col_lines.append(f"    {col.name:<30} {sql_type}{nullable}")

        if table.table_role == "dimension":
            col_lines.append("    _valid_from              TIMESTAMPTZ    DEFAULT NOW()")
            col_lines.append("    _valid_to                TIMESTAMPTZ")
            col_lines.append("    _is_current              BOOLEAN        DEFAULT TRUE")

        col_lines.append("    _loaded_at               TIMESTAMPTZ    DEFAULT NOW()")

        for fk in table.foreign_keys:
            col_lines.append(
                f"    FOREIGN KEY ({fk.column}) REFERENCES {fk.references_table}({fk.references_column})"
            )

        lines.append(",\n".join(col_lines))
        lines.append(");")

        # Create indexes on FK / ID columns for Postgres
        index_lines = []
        for col in table.columns:
            if col.semantic_type == "id":
                index_lines.append(
                    f"CREATE INDEX IF NOT EXISTS idx_{table.name}_{col.name} ON {table.name}({col.name});"
                )

        result = "\n".join(lines)
        if index_lines:
            result += "\n" + "\n".join(index_lines)
        return result
