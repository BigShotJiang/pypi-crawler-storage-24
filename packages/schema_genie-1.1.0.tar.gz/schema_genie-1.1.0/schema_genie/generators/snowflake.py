"""DDL generator for Snowflake."""
from .base import BaseDDLGenerator
from ..schema.models import InferredSchema, TableDefinition

TYPE_MAP = {
    "id":       "VARCHAR(64)",
    "measure":  "FLOAT",
    "currency": "NUMBER(18,2)",
    "date":     "TIMESTAMP_NTZ",
    "category": "VARCHAR(128)",
    "text":     "VARCHAR(4096)",
}


class SnowflakeDDLGenerator(BaseDDLGenerator):
    TYPE_MAP = TYPE_MAP

    def generate(self, schema: InferredSchema) -> str:
        parts = []
        for dim in schema.dimension_tables:
            parts.append(self._table_ddl(dim))
        parts.append(self._table_ddl(schema.fact_table))
        return "\n\n".join(parts)

    def _table_ddl(self, table: TableDefinition) -> str:
        lines = [f"CREATE OR REPLACE TABLE {table.name} ("]
        col_lines = []

        # Surrogate key
        col_lines.append(f"    {table.name}_key         INTEGER AUTOINCREMENT PRIMARY KEY")

        for col in table.columns:
            sql_type = TYPE_MAP.get(col.semantic_type, "VARCHAR(255)")
            nullable = "" if col.nullable else " NOT NULL"
            col_lines.append(f"    {col.name:<30} {sql_type}{nullable}")

        # SCD Type 2 audit columns for dimension tables
        if table.table_role == "dimension":
            col_lines.append("    _valid_from              TIMESTAMP_NTZ  DEFAULT CURRENT_TIMESTAMP()")
            col_lines.append("    _valid_to                TIMESTAMP_NTZ")
            col_lines.append("    _is_current              BOOLEAN        DEFAULT TRUE")

        # Universal audit column
        col_lines.append("    _loaded_at               TIMESTAMP_NTZ  DEFAULT CURRENT_TIMESTAMP()")

        # Foreign key constraints
        for fk in table.foreign_keys:
            col_lines.append(
                f"    FOREIGN KEY ({fk.column}) REFERENCES {fk.references_table}({fk.references_column})"
            )

        lines.append(",\n".join(col_lines))
        lines.append(");")
        return "\n".join(lines)
