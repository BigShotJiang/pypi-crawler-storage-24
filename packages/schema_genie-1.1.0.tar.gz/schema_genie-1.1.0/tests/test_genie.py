"""Integration tests for SchemaGenie (end-to-end pipeline)."""
import pandas as pd
import pytest

from schema_genie import SchemaGenie, InferredSchema


# ---------------------------------------------------------------------------
# Shared test data
# ---------------------------------------------------------------------------

@pytest.fixture
def orders():
    return pd.DataFrame({
        "order_id":    range(1000),
        "customer_id": [i % 100 for i in range(1000)],
        "product_id":  [i % 50 for i in range(1000)],
        "revenue":     [float(i * 9.99) for i in range(1000)],
        "quantity":    [i % 10 + 1 for i in range(1000)],
        "order_date":  pd.date_range("2024-01-01", periods=1000, freq="h"),
        "region":      [["APAC", "EMEA", "US"][i % 3] for i in range(1000)],
    })


@pytest.fixture
def customers():
    return pd.DataFrame({
        "customer_id":   range(100),
        "customer_name": [f"Customer {i}" for i in range(100)],
        "segment":       [["SMB", "Enterprise"][i % 2] for i in range(100)],
    })


@pytest.fixture
def products():
    return pd.DataFrame({
        "product_id":   range(50),
        "product_name": [f"Product {i}" for i in range(50)],
        "category":     [["Electronics", "Clothing", "Food"][i % 3] for i in range(50)],
    })


# ---------------------------------------------------------------------------
# infer() — single table
# ---------------------------------------------------------------------------

class TestInferSingleTable:
    def test_returns_inferred_schema(self, orders):
        genie = SchemaGenie(target="snowflake")
        schema = genie.infer(orders, "orders")
        assert isinstance(schema, InferredSchema)

    def test_ddl_generated(self, orders):
        genie = SchemaGenie(target="snowflake")
        schema = genie.infer(orders, "orders")
        assert "CREATE" in schema.ddl

    def test_recommended_type_is_star_or_snowflake(self, orders):
        genie = SchemaGenie(target="snowflake")
        schema = genie.infer(orders, "orders")
        assert schema.recommended_type in ("star", "snowflake")

    def test_confidence_score_in_range(self, orders):
        genie = SchemaGenie(target="snowflake")
        schema = genie.infer(orders, "orders")
        assert 0.0 <= schema.confidence_score <= 1.0

    def test_scd_candidates_is_list(self, orders):
        genie = SchemaGenie(target="snowflake", detect_scd=True)
        schema = genie.infer(orders, "orders")
        assert isinstance(schema.scd_candidates, list)


# ---------------------------------------------------------------------------
# infer_multi() — multi-table
# ---------------------------------------------------------------------------

class TestInferMultiTable:
    def test_fact_table_identified_as_orders(self, orders, customers, products):
        genie = SchemaGenie(target="snowflake")
        schema = genie.infer_multi({"orders": orders, "customers": customers, "products": products})
        assert schema.fact_table.name == "orders"

    def test_dimension_tables_returned(self, orders, customers, products):
        genie = SchemaGenie(target="snowflake")
        schema = genie.infer_multi({"orders": orders, "customers": customers, "products": products})
        dim_names = {t.name for t in schema.dimension_tables}
        assert "customers" in dim_names
        assert "products" in dim_names

    def test_relationships_detected(self, orders, customers):
        genie = SchemaGenie(target="snowflake")
        schema = genie.infer_multi({"orders": orders, "customers": customers})
        # orders.customer_id overlaps with customers.customer_id
        assert isinstance(schema.relationships, list)

    def test_scd_candidates_for_dimensions(self, orders, customers):
        genie = SchemaGenie(target="snowflake", detect_scd=True)
        schema = genie.infer_multi({"orders": orders, "customers": customers})
        assert isinstance(schema.scd_candidates, list)

    def test_empty_dataframes_raises(self):
        genie = SchemaGenie(target="snowflake")
        with pytest.raises(ValueError):
            genie.infer_multi({})


# ---------------------------------------------------------------------------
# Target-specific DDL
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("target,expected_token", [
    ("snowflake", "AUTOINCREMENT"),
    ("redshift",  "IDENTITY(1,1)"),
    ("bigquery",  "IF NOT EXISTS"),
    ("postgres",  "SERIAL"),
])
def test_target_ddl_token(orders, target, expected_token):
    genie = SchemaGenie(target=target)
    schema = genie.infer(orders, "orders")
    assert expected_token in schema.ddl


# ---------------------------------------------------------------------------
# schema_type override
# ---------------------------------------------------------------------------

def test_force_star_schema(orders, customers):
    genie = SchemaGenie(target="snowflake", schema_type="star")
    schema = genie.infer_multi({"orders": orders, "customers": customers})
    assert schema.recommended_type == "star"

def test_force_snowflake_schema(orders, customers):
    genie = SchemaGenie(target="snowflake", schema_type="snowflake")
    schema = genie.infer_multi({"orders": orders, "customers": customers})
    assert schema.recommended_type == "snowflake"


# ---------------------------------------------------------------------------
# detect_scd toggle
# ---------------------------------------------------------------------------

def test_detect_scd_false(orders, customers):
    genie = SchemaGenie(target="snowflake", detect_scd=False)
    schema = genie.infer_multi({"orders": orders, "customers": customers})
    assert schema.scd_candidates == []


# ---------------------------------------------------------------------------
# from_config
# ---------------------------------------------------------------------------

def test_from_config(tmp_path, orders):
    config = tmp_path / "genie_config.yaml"
    config.write_text("target: postgres\ndetect_scd: true\n")
    genie = SchemaGenie.from_config(str(config))
    assert genie.target == "postgres"
    schema = genie.infer(orders, "orders")
    assert "SERIAL" in schema.ddl


# ---------------------------------------------------------------------------
# export_ddl
# ---------------------------------------------------------------------------

def test_export_ddl(orders, tmp_path):
    genie = SchemaGenie(target="snowflake")
    schema = genie.infer(orders, "orders")
    out = tmp_path / "out.sql"
    schema.export_ddl(str(out))
    assert out.exists()
    content = out.read_text()
    assert "CREATE" in content


# ---------------------------------------------------------------------------
# summary()
# ---------------------------------------------------------------------------

def test_summary_contains_schema_type(orders):
    genie = SchemaGenie(target="snowflake")
    schema = genie.infer(orders, "orders")
    summary = schema.summary()
    assert "Schema Type" in summary
    assert schema.recommended_type in summary
