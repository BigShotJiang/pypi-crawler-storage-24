"""Tests for schema_genie.inference.type_detector"""
import pandas as pd
import pytest

from schema_genie.inference.type_detector import detect_type, detect_all_types


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_df():
    return pd.DataFrame({
        "order_id":    range(1000),
        "customer_id": [i % 100 for i in range(1000)],
        "revenue":     [float(i * 9.99) for i in range(1000)],
        "quantity":    [i % 10 + 1 for i in range(1000)],
        "order_date":  pd.date_range("2024-01-01", periods=1000, freq="h"),
        "region":      [["APAC", "EMEA", "US"][i % 3] for i in range(1000)],
        "description": [f"Order description for item {i}" for i in range(1000)],
        "unit_price":  [round(i * 1.5, 2) for i in range(1000)],
    })


# ---------------------------------------------------------------------------
# ID detection
# ---------------------------------------------------------------------------

def test_id_column_by_name():
    s = pd.Series(range(1000))
    assert detect_type("order_id", s) == "id"

def test_id_column_underscore_key():
    s = pd.Series(range(500))
    assert detect_type("product_key", s) == "id"

def test_id_prefix():
    s = pd.Series(range(200))
    assert detect_type("id_customer", s) == "id"

def test_bare_id():
    s = pd.Series(range(200))
    assert detect_type("id", s) == "id"


# ---------------------------------------------------------------------------
# Date detection
# ---------------------------------------------------------------------------

def test_datetime_dtype():
    s = pd.date_range("2024-01-01", periods=100, freq="D")
    assert detect_type("ts", pd.Series(s)) == "date"

def test_date_name_heuristic():
    s = pd.Series(["2024-01-01"] * 100)
    assert detect_type("created_at", s) == "date"

def test_updated_at_heuristic():
    s = pd.Series(["2024-01-01"] * 100)
    assert detect_type("updated_at", s) == "date"


# ---------------------------------------------------------------------------
# Currency detection
# ---------------------------------------------------------------------------

def test_revenue_is_currency():
    s = pd.Series([float(i * 9.99) for i in range(1000)])
    assert detect_type("revenue", s) == "currency"

def test_price_is_currency():
    s = pd.Series([1.99, 2.99, 3.99] * 100)
    assert detect_type("unit_price", s) == "currency"

def test_amount_is_currency():
    s = pd.Series([100.0, 200.0, 300.0] * 100)
    assert detect_type("amount", s) == "currency"


# ---------------------------------------------------------------------------
# Measure detection
# ---------------------------------------------------------------------------

def test_high_cardinality_numeric_is_measure():
    s = pd.Series(range(1000))
    assert detect_type("score", s) == "measure"

def test_quantity_is_measure():
    s = pd.Series(range(1000))
    assert detect_type("quantity", s) == "measure"


# ---------------------------------------------------------------------------
# Category detection
# ---------------------------------------------------------------------------

def test_low_cardinality_string_is_category():
    s = pd.Series(["APAC", "EMEA", "US"] * 334)
    assert detect_type("region", s) == "category"

def test_low_cardinality_numeric_is_category():
    s = pd.Series([1, 2, 3] * 100)
    assert detect_type("status_code", s) == "category"


# ---------------------------------------------------------------------------
# Text detection
# ---------------------------------------------------------------------------

def test_high_cardinality_string_is_text():
    s = pd.Series([f"unique text value {i}" for i in range(1000)])
    assert detect_type("description", s) == "text"


# ---------------------------------------------------------------------------
# detect_all_types
# ---------------------------------------------------------------------------

def test_detect_all_types_returns_dict(sample_df):
    result = detect_all_types(sample_df)
    assert isinstance(result, dict)
    assert set(result.keys()) == set(sample_df.columns)

def test_detect_all_types_known_columns(sample_df):
    result = detect_all_types(sample_df)
    assert result["order_id"]   == "id"
    assert result["customer_id"] == "id"
    assert result["revenue"]     == "currency"
    assert result["order_date"]  == "date"
    assert result["region"]      == "category"
    assert result["description"] == "text"
