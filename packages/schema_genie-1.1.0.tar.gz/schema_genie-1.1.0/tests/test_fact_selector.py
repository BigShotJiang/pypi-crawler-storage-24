"""Tests for schema_genie.inference.fact_selector"""
import pandas as pd
import pytest

from schema_genie.inference.fact_selector import score_table, select_fact_table
from schema_genie.inference.type_detector import detect_all_types


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def orders():
    return pd.DataFrame({
        "order_id":    range(1000),
        "customer_id": [i % 100 for i in range(1000)],
        "product_id":  [i % 50 for i in range(1000)],
        "revenue":     [float(i * 9.99) for i in range(1000)],
        "quantity":    [i % 10 + 1 for i in range(1000)],
        "order_date":  pd.date_range("2024-01-01", periods=1000, freq="h"),
        "region":      [["APAC", "EMEA", "US"][i % 3] for i in range(1000)],
    })


@pytest.fixture
def customers():
    return pd.DataFrame({
        "customer_id":   range(100),
        "customer_name": [f"Customer {i}" for i in range(100)],
        "segment":       [["SMB", "Enterprise"][i % 2] for i in range(100)],
    })


@pytest.fixture
def products():
    return pd.DataFrame({
        "product_id":   range(50),
        "product_name": [f"Product {i}" for i in range(50)],
        "category":     [["Electronics", "Clothing", "Food"][i % 3] for i in range(50)],
    })


# ---------------------------------------------------------------------------
# score_table
# ---------------------------------------------------------------------------

def test_score_table_returns_float(orders):
    type_map = detect_all_types(orders)
    score = score_table(orders, type_map)
    assert isinstance(score, float)
    assert score >= 0.0

def test_fact_table_scores_higher_than_dim(orders, customers):
    orders_types   = detect_all_types(orders)
    customer_types = detect_all_types(customers)
    assert score_table(orders, orders_types) > score_table(customers, customer_types)

def test_empty_df_scores_zero():
    df = pd.DataFrame()
    assert score_table(df, {}) == 0.0


# ---------------------------------------------------------------------------
# select_fact_table
# ---------------------------------------------------------------------------

def test_orders_selected_as_fact(orders, customers, products):
    dfs = {"orders": orders, "customers": customers, "products": products}
    type_maps = {name: detect_all_types(df) for name, df in dfs.items()}
    fact = select_fact_table(dfs, type_maps)
    assert fact == "orders"

def test_single_table_returns_itself(orders):
    dfs = {"orders": orders}
    type_maps = {"orders": detect_all_types(orders)}
    assert select_fact_table(dfs, type_maps) == "orders"

def test_empty_dataframes_raises():
    with pytest.raises(ValueError):
        select_fact_table({}, {})
