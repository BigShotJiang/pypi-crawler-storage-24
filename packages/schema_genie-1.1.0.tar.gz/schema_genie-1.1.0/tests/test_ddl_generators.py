"""Tests for all four DDL generators."""
import pytest

from schema_genie.schema.models import (
    ColumnDefinition,
    ForeignKey,
    InferredSchema,
    TableDefinition,
)
from schema_genie.generators.snowflake import SnowflakeDDLGenerator
from schema_genie.generators.redshift import RedshiftDDLGenerator
from schema_genie.generators.bigquery import BigQueryDDLGenerator
from schema_genie.generators.postgres import PostgresDDLGenerator


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def fact_table():
    return TableDefinition(
        name="fact_sales",
        table_role="fact",
        columns=[
            ColumnDefinition("order_id",    "id",       "VARCHAR(64)",   nullable=False, is_primary_key=True),
            ColumnDefinition("customer_id", "id",       "VARCHAR(64)",   nullable=False),
            ColumnDefinition("product_id",  "id",       "VARCHAR(64)",   nullable=False),
            ColumnDefinition("revenue",     "currency", "NUMBER(18,2)",  nullable=True),
            ColumnDefinition("quantity",    "measure",  "FLOAT",         nullable=True),
            ColumnDefinition("order_date",  "date",     "TIMESTAMP_NTZ", nullable=True),
        ],
        foreign_keys=[
            ForeignKey("customer_id", "dim_customers", "customer_id"),
            ForeignKey("product_id",  "dim_products",  "product_id"),
        ],
    )


@pytest.fixture
def dim_table():
    return TableDefinition(
        name="dim_customers",
        table_role="dimension",
        columns=[
            ColumnDefinition("customer_id",   "id",       "VARCHAR(64)",  nullable=False, is_primary_key=True),
            ColumnDefinition("customer_name", "text",     "VARCHAR(4096)", nullable=True),
            ColumnDefinition("segment",       "category", "VARCHAR(128)", nullable=True),
            ColumnDefinition("region",        "category", "VARCHAR(128)", nullable=True),
        ],
    )


@pytest.fixture
def inferred_schema(fact_table, dim_table):
    schema = InferredSchema(
        recommended_type="star",
        fact_table=fact_table,
        dimension_tables=[dim_table],
        relationships=[],
        confidence_score=0.9,
    )
    return schema


# ---------------------------------------------------------------------------
# Snowflake generator
# ---------------------------------------------------------------------------

class TestSnowflakeDDLGenerator:
    def test_generate_returns_string(self, inferred_schema):
        ddl = SnowflakeDDLGenerator().generate(inferred_schema)
        assert isinstance(ddl, str)
        assert len(ddl) > 0

    def test_create_table_present(self, inferred_schema):
        ddl = SnowflakeDDLGenerator().generate(inferred_schema)
        assert "CREATE OR REPLACE TABLE" in ddl

    def test_fact_and_dim_tables_present(self, inferred_schema):
        ddl = SnowflakeDDLGenerator().generate(inferred_schema)
        assert "fact_sales" in ddl
        assert "dim_customers" in ddl

    def test_scd_columns_on_dimension(self, inferred_schema):
        ddl = SnowflakeDDLGenerator().generate(inferred_schema)
        # SCD columns should appear in the dimension portion
        assert "_valid_from" in ddl
        assert "_is_current" in ddl

    def test_currency_type(self, inferred_schema):
        ddl = SnowflakeDDLGenerator().generate(inferred_schema)
        assert "NUMBER(18,2)" in ddl

    def test_autoincrement_surrogate_key(self, inferred_schema):
        ddl = SnowflakeDDLGenerator().generate(inferred_schema)
        assert "AUTOINCREMENT" in ddl

    def test_foreign_key_constraint(self, inferred_schema):
        ddl = SnowflakeDDLGenerator().generate(inferred_schema)
        assert "FOREIGN KEY" in ddl


# ---------------------------------------------------------------------------
# Redshift generator
# ---------------------------------------------------------------------------

class TestRedshiftDDLGenerator:
    def test_generate_returns_string(self, inferred_schema):
        ddl = RedshiftDDLGenerator().generate(inferred_schema)
        assert isinstance(ddl, str)

    def test_identity_surrogate_key(self, inferred_schema):
        ddl = RedshiftDDLGenerator().generate(inferred_schema)
        assert "IDENTITY(1,1)" in ddl

    def test_distkey_on_fact(self, inferred_schema):
        ddl = RedshiftDDLGenerator().generate(inferred_schema)
        assert "DISTKEY" in ddl

    def test_decimal_currency_type(self, inferred_schema):
        ddl = RedshiftDDLGenerator().generate(inferred_schema)
        assert "DECIMAL(18,2)" in ddl

    def test_both_tables_present(self, inferred_schema):
        ddl = RedshiftDDLGenerator().generate(inferred_schema)
        assert "fact_sales" in ddl
        assert "dim_customers" in ddl


# ---------------------------------------------------------------------------
# BigQuery generator
# ---------------------------------------------------------------------------

class TestBigQueryDDLGenerator:
    def test_generate_returns_string(self, inferred_schema):
        ddl = BigQueryDDLGenerator().generate(inferred_schema)
        assert isinstance(ddl, str)

    def test_create_if_not_exists(self, inferred_schema):
        ddl = BigQueryDDLGenerator().generate(inferred_schema)
        assert "CREATE TABLE IF NOT EXISTS" in ddl

    def test_float64_measure_type(self, inferred_schema):
        ddl = BigQueryDDLGenerator().generate(inferred_schema)
        assert "FLOAT64" in ddl

    def test_numeric_currency_type(self, inferred_schema):
        ddl = BigQueryDDLGenerator().generate(inferred_schema)
        assert "NUMERIC" in ddl

    def test_partition_on_fact_with_date(self, inferred_schema):
        ddl = BigQueryDDLGenerator().generate(inferred_schema)
        assert "PARTITION BY" in ddl


# ---------------------------------------------------------------------------
# Postgres generator
# ---------------------------------------------------------------------------

class TestPostgresDDLGenerator:
    def test_generate_returns_string(self, inferred_schema):
        ddl = PostgresDDLGenerator().generate(inferred_schema)
        assert isinstance(ddl, str)

    def test_serial_surrogate_key(self, inferred_schema):
        ddl = PostgresDDLGenerator().generate(inferred_schema)
        assert "SERIAL PRIMARY KEY" in ddl

    def test_double_precision_measure(self, inferred_schema):
        ddl = PostgresDDLGenerator().generate(inferred_schema)
        assert "DOUBLE PRECISION" in ddl

    def test_numeric_currency_type(self, inferred_schema):
        ddl = PostgresDDLGenerator().generate(inferred_schema)
        assert "NUMERIC(18,2)" in ddl

    def test_index_created_on_id_columns(self, inferred_schema):
        ddl = PostgresDDLGenerator().generate(inferred_schema)
        assert "CREATE INDEX" in ddl

    def test_timestamptz(self, inferred_schema):
        ddl = PostgresDDLGenerator().generate(inferred_schema)
        assert "TIMESTAMPTZ" in ddl


# ---------------------------------------------------------------------------
# export_ddl on InferredSchema
# ---------------------------------------------------------------------------

def test_export_ddl_writes_file(inferred_schema, tmp_path):
    inferred_schema.ddl = SnowflakeDDLGenerator().generate(inferred_schema)
    out = tmp_path / "schema.sql"
    inferred_schema.export_ddl(str(out))
    assert out.exists()
    assert "CREATE" in out.read_text()

def test_export_ddl_raises_without_ddl(inferred_schema):
    inferred_schema.ddl = ""
    with pytest.raises(ValueError):
        inferred_schema.export_ddl("/tmp/should_fail.sql")
