# geney/protein — Protein-level mutation analysis.
"""
Classifies mutations by their effect on the protein product and scores
functional impact via conservation-weighted alignment (Oncosplice).

This is a standalone pipeline that operates on the direct translation
of reference and variant mature mRNA — no splicing prediction required.
"""

from .analysis import analyze_protein_change, ProteinChangeResult

__all__ = ["analyze_protein_change", "ProteinChangeResult"]
