# geney/pipelines/__init__.py — Public re-exports.
#
# Every symbol that was importable from ``geney.pipelines`` (when it was a
# single module) is re-exported here so that all existing imports continue
# to work unchanged.

# Constants
from ._common import SPLICING_CONTEXT_BP, SPLICE_MAX_DISTANCE  # noqa: F401

# Internal helpers (used by concurrent.py, screen.py, transcript_tools.py, etc.)
from ._common import (  # noqa: F401
    _load_gene_with_timeout,
    _build_splice_site_index,
    _match_known_transcript,
    _get_conservation_vector,
    _extract_gained_alternatives,
    _splicing_base_report,
    _oncosplice_dataframe,
    _mrna_mutation_positions,
    _tis_completed_dict,
    _prepare_tis,
    _transcription_result_from_dict,
    _run_folding_single,
    _prepare_mutation,
)

# Splicing pipelines
from ._splicing import (  # noqa: F401
    oncosplice_pipeline,
    oncosplice_top_isoform,
    max_splicing_delta,
)

# TIS pipelines
from ._tis import tis_pipeline, tis_quick_check  # noqa: F401

# Unified mutation pipeline
from ._mutation import mutation_pipeline  # noqa: F401

# Batch mutation pipeline
from ._batch import mutation_pipeline_batch  # noqa: F401

# Result types (re-exported for backward compat — engine.py imports MutationResult from here)
from ..results import MutationResult  # noqa: F401

# Folding pipeline (re-export)
from ..folding.pipeline import folding_pipeline, folding_query_batch  # noqa: F401
