# geney/mirna — miRNA binding site disruption analysis.
"""
Predicts how mutations alter miRNA-mRNA interactions by scanning for
miRNA seed match changes (gained/lost/modified binding sites) and
scoring the predicted change in post-transcriptional repression.

Based on the miBSIM framework (Bader & Tuller, 2024) which integrates
thermodynamic, sequence, biochemical, and binding-site-interaction
features for predicting miRNA-mediated repression.
"""

from .seed import find_seed_matches, SeedMatch, SEED_TYPES
from .disruption import analyze_mirna_disruption, MiRNADisruptionResult
from .features import compute_site_features
from .reference import get_mirna_panel, load_mirna_fasta, list_tissues, BUNDLED_MIRNAS
from .expression import get_expressed_mirnas, filter_by_expression, list_available_tissues
from .mibsim import (
    predict_site_repression,
    compute_ds_correction,
    predict_transcript_repression,
    predict_occupancy,
    get_feature_names,
)

__all__ = [
    "find_seed_matches",
    "analyze_mirna_disruption",
    "compute_site_features",
    "get_mirna_panel",
    "load_mirna_fasta",
    "list_tissues",
    "BUNDLED_MIRNAS",
    "predict_site_repression",
    "compute_ds_correction",
    "predict_transcript_repression",
    "predict_occupancy",
    "get_feature_names",
    "SeedMatch",
    "MiRNADisruptionResult",
    "SEED_TYPES",
]
