"""Main sanitisation pipeline."""

import logging

from ..patterns import RTL_OVERRIDE_CHARS

logger = logging.getLogger(__name__)
from .detectors import (
    detect_base64_blocks,
    detect_hidden_html,
    detect_homoglyphs,
    detect_html_attributes,
    detect_injection_patterns,
    detect_invisible_chars,
    detect_markdown_injection,
    detect_repo_metadata_injection,
    detect_rtl_override,
)
from .scorer import calculate_risk_score, risk_level
from .transformers import strip_html_tags, strip_invisible_chars


def sanitise_content(content: str, format: str = 'text') -> dict:
    """
    Main sanitisation pipeline.

    Scans content for prompt injection patterns, hidden text, invisible
    characters, and other attack vectors. Returns clean text plus a
    structured threat report.

    Args:
        content: The text or HTML content to sanitise.
        format: 'text', 'html', or 'markdown'. HTML mode additionally checks for
                hidden elements, comments, and CSS-based hiding. Markdown mode
                checks for markdown-specific injection patterns.

    Returns:
        dict with keys:
            clean_text (str): Sanitised content with dangerous chars removed.
            threats (list): Detected threats with type, position, context.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.
    """
    logger.debug("sanitise_content: start format=%s len=%d", format, len(content))
    threats = []

    threats.extend(detect_invisible_chars(content))
    threats.extend(detect_injection_patterns(content))
    threats.extend(detect_base64_blocks(content))
    threats.extend(detect_rtl_override(content))
    threats.extend(detect_homoglyphs(content))
    threats.extend(detect_repo_metadata_injection(content))

    # Always check for markdown injection patterns
    threats.extend(detect_markdown_injection(content))

    if format == 'html':
        threats.extend(detect_hidden_html(content))
        threats.extend(detect_html_attributes(content))
        clean = strip_html_tags(content)
    else:
        clean = content

    clean = strip_invisible_chars(clean)
    for char in RTL_OVERRIDE_CHARS:
        clean = clean.replace(char, '')

    # Re-scan clean text for injection patterns that were hidden by
    # invisible characters or RTL overrides. Only add genuinely new
    # findings (compare matched text to avoid duplicates).
    existing_matches = {t['matched'] for t in threats if t.get('matched')}
    post_strip_threats = detect_injection_patterns(clean)
    for t in post_strip_threats:
        if t['matched'] not in existing_matches:
            t['type'] = 'post_strip_injection'
            threats.append(t)

    logger.debug("sanitise_content: end threats=%d", len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("sanitise_content: threats detected count=%d types=%s", len(threats), types)
    risk_score = calculate_risk_score(threats, content)

    return {
        'clean_text': clean,
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
    }


# Alias for convenience
sanitise = sanitise_content
