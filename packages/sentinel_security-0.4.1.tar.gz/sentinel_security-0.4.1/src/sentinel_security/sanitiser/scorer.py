"""Risk scoring for detected threats."""

import re

from sentinel_security.config import RISK_WEIGHTS

# Shell commands that indicate execution risk when combined with injection
_SHELL_CMD_RE = re.compile(
    r'\b(?:curl|wget|bash|sh|python|perl|ruby|nc|ncat|netcat)\b', re.IGNORECASE
)

# External URL (any http/https link)
_EXTERNAL_URL_RE = re.compile(r'https?://\S+', re.IGNORECASE)

# Credential urgency phrases (social engineering)
_CREDENTIAL_URGENCY_RE = re.compile(
    r'(?:api\s+key|password|token|credentials?|secret)\s+(?:has|have)\s+been\s+'
    r'(?:compromised|leaked|exposed|stolen|breached)',
    re.IGNORECASE,
)


def _compound_bonus(threats: list, content: str = '') -> int:
    """Extra score when multiple signals combine to indicate a serious attack."""
    bonus = 0
    threat_types = {t['type'] for t in threats}

    # Hidden HTML containing shell commands → critical (injection hidden from user)
    if 'hidden_html' in threat_types:
        for t in threats:
            if t['type'] == 'hidden_html':
                hidden = t.get('hidden_text', '')
                if _SHELL_CMD_RE.search(hidden):
                    bonus = max(bonus, 4)

    if 'injection_pattern' not in threat_types or not content:
        return bonus

    # Injection pattern + shell commands → execution attack
    if _SHELL_CMD_RE.search(content):
        bonus = max(bonus, 3)

    # Injection pattern + external URL → exfiltration risk
    if _EXTERNAL_URL_RE.search(content):
        bonus = max(bonus, 3)

    # Injection pattern + credential urgency → phishing
    if _CREDENTIAL_URGENCY_RE.search(content):
        bonus = max(bonus, 3)

    return bonus


def calculate_risk_score(threats: list, content: str = '') -> int:
    """Calculate overall risk score 0-10."""
    if not threats:
        return 0
    score = 0
    for t in threats:
        score += RISK_WEIGHTS.get(t['type'], 1)
    score += _compound_bonus(threats, content)
    return min(10, score)


def risk_level(score: int) -> str:
    """Map a 0-10 risk score to a human-readable severity level."""
    if score == 0:
        return 'CLEAN'
    if score <= 2:
        return 'LOW'
    if score <= 5:
        return 'MEDIUM'
    if score <= 8:
        return 'HIGH'
    return 'CRITICAL'
