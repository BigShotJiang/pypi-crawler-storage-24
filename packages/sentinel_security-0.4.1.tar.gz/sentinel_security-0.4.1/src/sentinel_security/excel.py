"""
Excel (.xlsx) scanner for hidden content and prompt injection.

Uses openpyxl to detect:
- Hidden sheets, rows, columns
- Colour-matched text (hidden text)
- Tiny fonts
- VBA macros
- Named ranges with injection patterns
- Data validation
- Comments with injection patterns
- Cell values matching injection patterns
"""

import logging
import re
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter, column_index_from_string

from .patterns import SHEET_INJECTION_PATTERNS

from .sanitiser.scorer import risk_level

def scan_excel(file_path: str) -> dict:
    """
    Scan an Excel (.xlsx) file for hidden content and prompt injection.

    Args:
        file_path: Path to the Excel file.

    Returns:
        dict with keys:
            info (dict): File metadata.
            threats (list): Detected threats with type, severity, detail.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.

    Raises:
        FileNotFoundError: If file doesn't exist.
        ValueError: If file is not a valid Excel file.
    """
    logger.debug("scan_excel: start file=%s", file_path)
    threats: List[Dict[str, Any]] = []
    
    try:
        wb = load_workbook(filename=file_path, data_only=True)
    except Exception as e:
        raise ValueError(f"Failed to load Excel file: {e}")
    
    # Basic info
    sheet_names = wb.sheetnames
    info = {
        'file_path': file_path,
        'sheet_count': len(sheet_names),
        'sheet_names': sheet_names,
    }
    
    # 1. Check for VBA macros (CRITICAL)
    if wb.vba_archive is not None:
        threats.append({
            'type': 'vba_macros',
            'severity': 'CRITICAL',
            'detail': 'Workbook contains VBA macros which can execute arbitrary code.',
            'sheet_name': None,
        })
    
    # 2. Check named ranges for injection patterns (LOW, CRITICAL if match)
    for name in wb.defined_names:
        defined_name = wb.defined_names[name]
        # Get the value/formula of the named range
        try:
            # This is a simplified check - in practice we'd need to evaluate the formula
            name_value = str(defined_name.value) if hasattr(defined_name, 'value') else str(defined_name)
            if name_value and isinstance(name_value, str):
                for pattern in SHEET_INJECTION_PATTERNS:
                    if re.search(pattern, name_value, re.IGNORECASE):
                        threats.append({
                            'type': 'injection_in_named_range',
                            'severity': 'CRITICAL',
                            'detail': f'Injection pattern found in named range "{name}".',
                            'sheet_name': None,
                            'named_range': name,
                            'value_preview': name_value[:100],
                        })
                        break
                else:
                    threats.append({
                        'type': 'named_range',
                        'severity': 'LOW',
                        'detail': f'Named range "{name}" found.',
                        'sheet_name': None,
                        'named_range': name,
                    })
        except Exception as e:
            logger.warning("Failed to scan Excel cell value: %s", e)
    
    # Scan each worksheet
    for ws in wb.worksheets:
        sheet_name = ws.title
        
        # 3. Check for hidden sheets (HIGH)
        if ws.sheet_state in ('hidden', 'veryHidden'):
            threats.append({
                'type': 'hidden_sheet',
                'severity': 'HIGH',
                'detail': f'Sheet "{sheet_name}" is hidden (state: {ws.sheet_state}).',
                'sheet_name': sheet_name,
            })
        
        # 4. Check for hidden rows (MEDIUM)
        hidden_rows = []
        for row_idx, row_dim in ws.row_dimensions.items():
            if row_dim.hidden:
                hidden_rows.append(row_idx)
        
        if hidden_rows:
            # Group consecutive rows
            groups = []
            current_group = [hidden_rows[0]]
            for i in range(1, len(hidden_rows)):
                if hidden_rows[i] == hidden_rows[i-1] + 1:
                    current_group.append(hidden_rows[i])
                else:
                    groups.append(current_group)
                    current_group = [hidden_rows[i]]
            groups.append(current_group)
            
            for group in groups:
                if len(group) == 1:
                    detail = f'Row {group[0]} in sheet "{sheet_name}" is hidden.'
                else:
                    detail = f'Rows {group[0]}-{group[-1]} in sheet "{sheet_name}" are hidden.'
                
                threats.append({
                    'type': 'hidden_row',
                    'severity': 'MEDIUM',
                    'detail': detail,
                    'sheet_name': sheet_name,
                    'rows': group,
                })
        
        # 5. Check for hidden columns (MEDIUM)
        hidden_cols = []
        for col_idx, col_dim in ws.column_dimensions.items():
            if col_dim.hidden:
                try:
                    # Keys are usually letters (e.g. "C") but can sometimes be ints.
                    if isinstance(col_idx, int):
                        hidden_cols.append(col_idx)
                    else:
                        hidden_cols.append(column_index_from_string(str(col_idx)))
                except Exception as e:
                    logger.warning("Failed to scan Excel defined name: %s", e)

        hidden_cols = sorted(set(hidden_cols))
        
        if hidden_cols:
            # Group consecutive columns
            groups = []
            current_group = [hidden_cols[0]]
            for i in range(1, len(hidden_cols)):
                if hidden_cols[i] == hidden_cols[i-1] + 1:
                    current_group.append(hidden_cols[i])
                else:
                    groups.append(current_group)
                    current_group = [hidden_cols[i]]
            groups.append(current_group)
            
            for group in groups:
                if len(group) == 1:
                    col_letter = get_column_letter(group[0])
                    detail = f'Column {col_letter} in sheet "{sheet_name}" is hidden.'
                else:
                    start = get_column_letter(group[0])
                    end = get_column_letter(group[-1])
                    detail = f'Columns {start}-{end} in sheet "{sheet_name}" are hidden.'
                
                threats.append({
                    'type': 'hidden_column',
                    'severity': 'MEDIUM',
                    'detail': detail,
                    'sheet_name': sheet_name,
                    'columns': [get_column_letter(c) for c in group],
                })
        
        # 6. Check data validation (LOW)
        if ws.data_validations.dataValidation:
            threats.append({
                'type': 'data_validation',
                'severity': 'LOW',
                'detail': f'Sheet "{sheet_name}" contains data validation rules.',
                'sheet_name': sheet_name,
                'count': len(ws.data_validations.dataValidation),
            })
        
        # Scan cells
        for row in ws.iter_rows():
            for cell in row:
                cell_value = cell.value
                cell_ref = cell.coordinate
                
                # Skip empty cells
                if cell_value is None or (isinstance(cell_value, str) and not cell_value.strip()):
                    continue
                
                # Convert to string for pattern matching
                cell_str = str(cell_value)
                
                # 7. Check for injection patterns in cell values (CRITICAL)
                for pattern in SHEET_INJECTION_PATTERNS:
                    if re.search(pattern, cell_str, re.IGNORECASE):
                        threats.append({
                            'type': 'injection_in_cell',
                            'severity': 'CRITICAL',
                            'detail': f'Injection pattern found in cell {cell_ref} of sheet "{sheet_name}".',
                            'sheet_name': sheet_name,
                            'cell': cell_ref,
                            'value_preview': cell_str[:100],
                        })
                        break
                
                # 8. Check for colour-matched text (HIGH)
                if cell.font and cell.fill:
                    font_color = cell.font.color
                    fill_color = cell.fill.fgColor
                    
                    if (font_color and fill_color and 
                        font_color.type == 'rgb' and fill_color.type == 'rgb' and
                        font_color.rgb and fill_color.rgb):
                        
                        # Compare RGB values (simplified - check if they're close)
                        if _colors_are_similar(font_color.rgb, fill_color.rgb):
                            threats.append({
                                'type': 'hidden_text_color',
                                'severity': 'HIGH',
                                'detail': f'Text colour matches background in cell {cell_ref} of sheet "{sheet_name}" (hidden text).',
                                'sheet_name': sheet_name,
                                'cell': cell_ref,
                                'font_color': font_color.rgb,
                                'fill_color': fill_color.rgb,
                            })
                
                # 9. Check for tiny fonts (HIGH)
                if cell.font and cell.font.size and cell.font.size < 2:
                    threats.append({
                        'type': 'tiny_font',
                        'severity': 'HIGH',
                        'detail': f'Extremely small font ({cell.font.size}pt) in cell {cell_ref} of sheet "{sheet_name}".',
                        'sheet_name': sheet_name,
                        'cell': cell_ref,
                        'font_size': cell.font.size,
                    })
                
                # 10. Check comments (LOW, CRITICAL if injection pattern)
                if cell.comment:
                    comment_text = cell.comment.text
                    if comment_text:
                        # Check for injection patterns
                        injection_found = False
                        for pattern in SHEET_INJECTION_PATTERNS:
                            if re.search(pattern, comment_text, re.IGNORECASE):
                                threats.append({
                                    'type': 'injection_in_comment',
                                    'severity': 'CRITICAL',
                                    'detail': f'Injection pattern found in comment of cell {cell_ref} in sheet "{sheet_name}".',
                                    'sheet_name': sheet_name,
                                    'cell': cell_ref,
                                    'comment_preview': comment_text[:100],
                                })
                                injection_found = True
                                break
                        
                        if not injection_found:
                            threats.append({
                                'type': 'comment',
                                'severity': 'LOW',
                                'detail': f'Cell {cell_ref} in sheet "{sheet_name}" has a comment.',
                                'sheet_name': sheet_name,
                                'cell': cell_ref,
                            })
    
    logger.debug("scan_excel: end file=%s threats=%d", file_path, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_excel: threats detected count=%d types=%s file=%s", len(threats), types, file_path)
    # Calculate risk score
    risk_score = _calculate_excel_risk(threats)
    
    return {
        'info': info,
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
    }


def _colors_are_similar(color1: str, color2: str, threshold: float = 0.1) -> bool:
    """
    Check if two RGB colors are similar.
    
    Args:
        color1: RGB color string (e.g., 'FF0000FF' for red)
        color2: RGB color string
        threshold: Maximum normalized difference (0-1)
    
    Returns:
        True if colors are similar.
    """
    # Parse ARGB hex strings (openpyxl uses ARGB format)
    def parse_color(c):
        if len(c) == 8:  # ARGB
            a = int(c[0:2], 16) / 255.0
            r = int(c[2:4], 16) / 255.0
            g = int(c[4:6], 16) / 255.0
            b = int(c[6:8], 16) / 255.0
        elif len(c) == 6:  # RGB
            r = int(c[0:2], 16) / 255.0
            g = int(c[2:4], 16) / 255.0
            b = int(c[4:6], 16) / 255.0
            a = 1.0
        else:
            return 0, 0, 0, 0
        return r, g, b, a
    
    r1, g1, b1, a1 = parse_color(color1)
    r2, g2, b2, a2 = parse_color(color2)
    
    # Calculate Euclidean distance in RGB space
    distance = ((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2) ** 0.5
    
    # Normalize (max distance in RGB cube is sqrt(3))
    normalized_distance = distance / (3 ** 0.5)
    
    return normalized_distance < threshold


def _calculate_excel_risk(threats: List[Dict[str, Any]]) -> int:
    """
    Calculate risk score for Excel scan.
    
    Args:
        threats: List of threat dictionaries.
    
    Returns:
        Risk score (0-10).
    """
    score = 0
    for threat in threats:
        severity = threat.get('severity', 'LOW')
        if severity == 'CRITICAL':
            score += 5
        elif severity == 'HIGH':
            score += 3
        elif severity == 'MEDIUM':
            score += 1
        # LOW severity doesn't add to score
    return min(10, score)
