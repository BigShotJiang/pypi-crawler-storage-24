"""
Patch generator for prompt audit results.

Port of the JavaScript patcher from prompt-auditor/patcher.js.
"""

import json
from pathlib import Path


def _load_fixes():
    """Load fixes from fixes.json file."""
    fixes_path = Path(__file__).parent / "fixes.json"
    with open(fixes_path, 'r', encoding='utf-8') as f:
        return json.load(f)


FIXES = _load_fixes()

# Severity sort order (critical first)
SEVERITY_ORDER = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}


def generate_patches(scan_results):
    """
    Generate patch suggestions for all FAIL or PARTIAL rules.

    Args:
        scan_results: Results from scanner.scan().

    Returns:
        List of patch suggestion objects, sorted by severity.
    """
    patches = []

    for result in scan_results:
        if result['status'] == 'pass':
            continue

        fix = FIXES.get(result['fix_template_id'])
        if not fix:
            continue

        patches.append({
            'rule_id': result['rule_id'],
            'severity': result['severity'],
            'current_status': result['status'],
            'suggested_text': fix['suggestedText'],
            'insertion_hint': fix['insertionHint'],
        })

    # Sort by severity (critical first)
    patches.sort(key=lambda x: SEVERITY_ORDER[x['severity']])

    return patches
