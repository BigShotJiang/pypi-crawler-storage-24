"""XML scanner -- detects prompt injection in XML text, attributes, comments, PIs, and CDATA."""

import logging
import os
import re
import xml.etree.ElementTree as ET
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

from ..sanitiser import calculate_risk_score, sanitise_content

from ..sanitiser.scorer import risk_level

def _scan_xml_comments(content: str) -> List[Dict[str, Any]]:
    """Scan XML comments for injection patterns."""
    threats = []
    comment_pattern = r'<!--(.*?)-->'
    for match in re.finditer(comment_pattern, content, re.DOTALL):
        comment_text = match.group(1).strip()
        if comment_text:
            result = sanitise_content(comment_text, format='text')
            if result['threat_count'] > 0:
                for threat in result['threats']:
                    threats.append({
                        'type': 'comment_injection',
                        'position': match.start(),
                        'value': comment_text[:100],
                        'injection_type': threat['type'],
                        'matched': threat.get('matched', ''),
                        'description': f'Injection detected in XML comment at position {match.start()}: {threat.get("type", "unknown")}'
                    })
    return threats


def _scan_xml_processing_instructions(content: str) -> List[Dict[str, Any]]:
    """Scan XML processing instructions for injection patterns."""
    threats = []
    pi_pattern = r'<\?(.*?)\?>'
    for match in re.finditer(pi_pattern, content, re.DOTALL):
        pi_text = match.group(1).strip()
        if pi_text:
            result = sanitise_content(pi_text, format='text')
            if result['threat_count'] > 0:
                for threat in result['threats']:
                    threats.append({
                        'type': 'processing_instruction_injection',
                        'position': match.start(),
                        'value': pi_text[:100],
                        'injection_type': threat['type'],
                        'matched': threat.get('matched', ''),
                        'description': f'Injection detected in XML processing instruction at position {match.start()}: {threat.get("type", "unknown")}'
                    })
    return threats


def _scan_xml_cdata(content: str) -> List[Dict[str, Any]]:
    """Scan XML CDATA sections for injection patterns."""
    threats = []
    cdata_pattern = r'<!\[CDATA\[(.*?)\]\]>'
    for match in re.finditer(cdata_pattern, content, re.DOTALL):
        cdata_text = match.group(1).strip()
        if cdata_text:
            result = sanitise_content(cdata_text, format='text')
            if result['threat_count'] > 0:
                for threat in result['threats']:
                    threats.append({
                        'type': 'cdata_injection',
                        'position': match.start(),
                        'value': cdata_text[:100],
                        'injection_type': threat['type'],
                        'matched': threat.get('matched', ''),
                        'description': f'Injection detected in XML CDATA section at position {match.start()}: {threat.get("type", "unknown")}'
                    })
    return threats


def scan_xml(file_path_or_text: str, is_file: bool = True) -> dict:
    """
    Scan XML content for prompt injection attacks.

    Args:
        file_path_or_text: Path to XML file or XML text content.
        is_file: True if first argument is a file path, False if it's XML text.

    Returns:
        dict with keys:
            file (str or None): File path if is_file=True, else None.
            format (str): "xml"
            threats (list): Detected threats with XPath-like location.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.
            strings_scanned (int): Total number of text nodes/attributes scanned.

    Raises:
        FileNotFoundError: If file doesn't exist (when is_file=True).
        ValueError: If content is not valid XML.
    """
    logger.debug("scan_xml: start is_file=%s", is_file)
    threats: List[Dict[str, Any]] = []
    strings_scanned = 0

    if is_file:
        if not os.path.exists(file_path_or_text):
            raise FileNotFoundError(f"File not found: {file_path_or_text}")

        with open(file_path_or_text, 'r', encoding='utf-8') as f:
            content = f.read()
        file_info = file_path_or_text
    else:
        content = file_path_or_text
        file_info = None

    comment_threats = _scan_xml_comments(content)
    threats.extend(comment_threats)

    pi_threats = _scan_xml_processing_instructions(content)
    threats.extend(pi_threats)

    cdata_threats = _scan_xml_cdata(content)
    threats.extend(cdata_threats)

    try:
        root = ET.fromstring(content)
    except ET.ParseError as e:
        raise ValueError(f"Invalid XML: {e}")

    def scan_element(element, path: str):
        nonlocal strings_scanned, threats

        if element.text and element.text.strip():
            strings_scanned += 1
            result = sanitise_content(element.text.strip(), format='text')
            if result['threat_count'] > 0:
                for threat in result['threats']:
                    threats.append({
                        'type': 'text_injection',
                        'path': f'{path}/text()',
                        'value': element.text.strip()[:100],
                        'injection_type': threat['type'],
                        'matched': threat.get('matched', ''),
                        'description': f'Text injection detected in element text at {path}: {threat.get("type", "unknown")}'
                    })

        for attr_name, attr_value in element.attrib.items():
            if attr_value:
                strings_scanned += 1
                result = sanitise_content(attr_value, format='text')
                if result['threat_count'] > 0:
                    for threat in result['threats']:
                        threats.append({
                            'type': 'attribute_injection',
                            'path': f'{path}/@{attr_name}',
                            'value': attr_value[:100],
                            'injection_type': threat['type'],
                            'matched': threat.get('matched', ''),
                            'description': f'Injection detected in attribute {attr_name} at {path}: {threat.get("type", "unknown")}'
                        })

        if element.tail and element.tail.strip():
            strings_scanned += 1
            result = sanitise_content(element.tail.strip(), format='text')
            if result['threat_count'] > 0:
                for threat in result['threats']:
                    threats.append({
                        'type': 'text_injection',
                        'path': f'{path}/tail()',
                        'value': element.tail.strip()[:100],
                        'injection_type': threat['type'],
                        'matched': threat.get('matched', ''),
                        'description': f'Text injection detected in tail text at {path}: {threat.get("type", "unknown")}'
                    })

        child_counts: Dict[str, int] = {}
        for child in element:
            tag = child.tag
            if '}' in tag:
                tag = tag.split('}', 1)[1]

            child_counts[tag] = child_counts.get(tag, 0) + 1
            count = child_counts[tag]

            child_path = f'{path}/{tag}[{count}]' if count > 1 else f'{path}/{tag}'
            scan_element(child, child_path)

    root_tag = root.tag
    if '}' in root_tag:
        root_tag = root_tag.split('}', 1)[1]

    scan_element(root, f'/{root_tag}')

    logger.debug("scan_xml: end threats=%d", len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_xml: threats detected count=%d types=%s", len(threats), types)
    risk_score = calculate_risk_score(threats)

    return {
        'file': file_info,
        'format': 'xml',
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
        'strings_scanned': strings_scanned
    }
