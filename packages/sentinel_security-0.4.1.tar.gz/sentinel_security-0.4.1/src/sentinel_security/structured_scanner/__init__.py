"""
Structured data scanner package.

Re-exports scan_json, scan_yaml, scan_xml so existing imports continue to work.
"""

from .json_scanner import scan_json
from .yaml_scanner import scan_yaml, _scan_yaml_comments
from .xml_scanner import scan_xml, _scan_xml_comments, _scan_xml_processing_instructions, _scan_xml_cdata

__all__ = [
    'scan_json',
    'scan_yaml',
    'scan_xml',
    '_scan_yaml_comments',
    '_scan_xml_comments',
    '_scan_xml_processing_instructions',
    '_scan_xml_cdata',
]
