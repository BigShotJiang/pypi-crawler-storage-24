"""YAML scanner -- detects prompt injection in YAML string values and comments."""

import logging
import os
import re
from typing import Any, Dict, List
from ..sanitiser.scorer import risk_level

logger = logging.getLogger(__name__)

try:
    import yaml  # type: ignore
except ImportError:  # pragma: no cover
    yaml = None

from ..sanitiser import calculate_risk_score, sanitise_content


def _scan_yaml_comments(content: str) -> List[Dict[str, Any]]:
    """Scan YAML comments for injection patterns."""
    threats = []
    lines = content.split('\n')
    for line_num, line in enumerate(lines):
        comment_match = re.search(r'(?:^|\s)#\s*(.*)$', line)
        if comment_match:
            comment_text = comment_match.group(1)
            result = sanitise_content(comment_text, format='text')
            if result['threat_count'] > 0:
                for threat in result['threats']:
                    threats.append({
                        'type': 'comment_injection',
                        'line': line_num + 1,
                        'value': comment_text[:100],
                        'injection_type': threat['type'],
                        'matched': threat.get('matched', ''),
                        'description': f'Injection detected in YAML comment at line {line_num + 1}: {threat.get("type", "unknown")}'
                    })
    return threats


def scan_yaml(file_path_or_text: str, is_file: bool = True) -> dict:
    """
    Scan YAML content for prompt injection attacks.

    Args:
        file_path_or_text: Path to YAML file or YAML text content.
        is_file: True if first argument is a file path, False if it's YAML text.

    Returns:
        dict with keys:
            file (str or None): File path if is_file=True, else None.
            format (str): "yaml"
            threats (list): Detected threats with YAML path/location.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.
            strings_scanned (int): Total number of string values scanned.

    Raises:
        FileNotFoundError: If file doesn't exist (when is_file=True).
        ValueError: If content is not valid YAML.
    """
    if yaml is None:
        raise ImportError(
            "PyYAML required for YAML scanning. "
            "Install with: pip install sentinel-security[yaml]"
        )

    logger.debug("scan_yaml: start is_file=%s", is_file)
    threats: List[Dict[str, Any]] = []
    strings_scanned = 0

    if is_file:
        if not os.path.exists(file_path_or_text):
            raise FileNotFoundError(f"File not found: {file_path_or_text}")

        with open(file_path_or_text, 'r', encoding='utf-8') as f:
            content = f.read()
        file_info = file_path_or_text
    else:
        content = file_path_or_text
        file_info = None

    try:
        data = yaml.safe_load(content)
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML: {e}")

    comment_threats = _scan_yaml_comments(content)
    threats.extend(comment_threats)

    def scan_value(value, path: str):
        nonlocal strings_scanned, threats

        if isinstance(value, str):
            strings_scanned += 1
            result = sanitise_content(value, format='text')
            if result['threat_count'] > 0:
                for threat in result['threats']:
                    threats.append({
                        'type': 'text_injection',
                        'path': path,
                        'value': value[:100],
                        'injection_type': threat['type'],
                        'matched': threat.get('matched', ''),
                        'description': f'Text injection detected at {path}: {threat.get("type", "unknown")}'
                    })
        elif isinstance(value, dict):
            for key, val in value.items():
                if not isinstance(key, str):
                    key = str(key)
                scan_value(val, f'{path}.{key}' if path else key)
        elif isinstance(value, list):
            for i, val in enumerate(value):
                scan_value(val, f'{path}[{i}]' if path else f'[{i}]')

    if data is not None:
        scan_value(data, '')

    logger.debug("scan_yaml: end strings=%d threats=%d", strings_scanned, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_yaml: threats detected count=%d types=%s", len(threats), types)
    risk_score = calculate_risk_score(threats)

    return {
        'file': file_info,
        'format': 'yaml',
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
        'strings_scanned': strings_scanned
    }
