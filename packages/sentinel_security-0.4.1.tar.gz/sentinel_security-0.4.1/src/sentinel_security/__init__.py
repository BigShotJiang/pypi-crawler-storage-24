"""
sentinel-security: Detect and neutralise prompt injection attacks.

Quick start:
    from sentinel_security import sanitise_content

    result = sanitise_content("some untrusted text")
    print(result['risk_level'])  # CLEAN / LOW / MEDIUM / HIGH / CRITICAL
    print(result['clean_text'])  # sanitised output

For file scanning:
    from sentinel_security import scan_file

    result = scan_file("document.xlsx")

For prompt auditing:
    from sentinel_security import audit_prompt, scan_prompt

    result = audit_prompt("your system prompt")
"""

from .csv_scanner import scan_csv
from .email_scanner import scan_eml
from .excel_online import scan_excel_online
from .gdocs import scan_google_doc
from .gdrive import scan_google_drive_file
from .gslides import scan_google_slides
from .ics_scanner import scan_ics
from .image_metadata import scan_image_metadata
from .ms_drive import scan_ms_drive_item
from .msg_scanner import scan_msg
from .pdf import scan_pdf
from .pptx_online import scan_pptx_online
from .sanitiser import sanitise, sanitise_content
from .scanner import scan_file
from .sheets import scan_sheets
from .structured_scanner import scan_json, scan_xml, scan_yaml
from .word_online import scan_word_online

# Auditor imports
from .auditor import audit as audit_prompt, scan as scan_prompt

try:
    from importlib.metadata import version as _get_version
    __version__ = _get_version("sentinel-security")
except Exception:
    __version__ = "0.3.0"  # fallback for editable installs
__all__ = [
    "sanitise_content", "sanitise",
    "scan_sheets", "scan_file",
    "scan_google_doc", "scan_google_slides", "scan_google_drive_file",
    "scan_excel_online", "scan_word_online", "scan_pptx_online",
    "scan_ms_drive_item",
    "scan_pdf", "scan_eml", "scan_msg", "scan_ics",
    "scan_csv", "scan_json", "scan_yaml", "scan_xml",
    "scan_image_metadata",
    "audit_prompt", "scan_prompt",
]
