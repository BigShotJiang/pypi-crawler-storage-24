"""
PowerPoint Online scanner via Microsoft Graph API (hybrid approach).

Downloads the .pptx file via Graph API, runs the local pptx_scanner.py,
then adds Graph-specific metadata checks (comments, file properties).

Requires: pip install sentinel-security[microsoft,office]
"""

import logging
import os
import re
import tempfile
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

from .config import GRAPH_BASE_URL as GRAPH_BASE
from .patterns import SHEET_INJECTION_PATTERNS

from .sanitiser.scorer import risk_level

def scan_pptx_online(
    item_id: str,
    drive_id: Optional[str] = None,
    auth=None,
) -> dict:
    """
    Scan a PowerPoint file stored in OneDrive/SharePoint.

    Hybrid approach: downloads the file, runs local scan_pptx(),
    then adds Graph API metadata and comment checks.

    Args:
        item_id: The OneDrive/SharePoint item ID.
        drive_id: Drive ID. If None, uses /me/drive.
        auth: Authenticated requests.Session from ms_auth.get_graph_client().

    Returns:
        dict with keys:
            info (dict): File metadata.
            threats (list): Detected threats.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.

    Raises:
        ValueError: If auth session is not provided.
    """
    logger.debug("scan_pptx_online: start item_id=%s", item_id)
    if auth is None:
        raise ValueError("auth (requests.Session) is required. Use ms_auth.get_graph_client().")

    base = _build_item_url(item_id, drive_id)
    threats: List[Dict[str, Any]] = []
    tmp_path = None

    try:
        # Download the file
        download_url = f"{base}/content"
        dl_resp = auth.get(download_url)
        dl_resp.raise_for_status()

        fd, tmp_path = tempfile.mkstemp(suffix='.pptx')
        os.close(fd)
        with open(tmp_path, 'wb') as f:
            f.write(dl_resp.content)

        # Run local scanner
        from .pptx_scanner import scan_pptx
        local_result = scan_pptx(tmp_path)
        threats.extend(local_result.get('threats', []))
        info = local_result.get('info', {})
        info['item_id'] = item_id
        info['source'] = 'graph_api'

    except Exception as e:
        info = {'item_id': item_id, 'source': 'graph_api', 'error': str(e)}
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)

    # Graph-specific: file metadata
    try:
        meta_resp = auth.get(base)
        meta_resp.raise_for_status()
        meta = meta_resp.json()
        desc = meta.get('description', '')
        if desc:
            for pattern in SHEET_INJECTION_PATTERNS:
                if re.search(pattern, desc, re.IGNORECASE):
                    threats.append({
                        'type': 'injection_in_description',
                        'severity': 'CRITICAL',
                        'detail': 'Injection pattern in file description.',
                        'value_preview': desc[:100],
                    })
                    break
    except Exception as e:
        logger.warning("Failed to scan PPTX Online element: %s", e)

    # Graph-specific: comments
    try:
        comments_url = f"{base}/comments"
        comments_resp = auth.get(comments_url)
        comments_resp.raise_for_status()
        for comment in comments_resp.json().get('value', []):
            content = comment.get('content', '')
            if content:
                for pattern in SHEET_INJECTION_PATTERNS:
                    if re.search(pattern, content, re.IGNORECASE):
                        threats.append({
                            'type': 'injection_in_graph_comment',
                            'severity': 'CRITICAL',
                            'detail': 'Injection pattern in Graph API comment.',
                            'value_preview': content[:100],
                        })
                        break
    except Exception as e:
        logger.warning("Failed to process PPTX Online content block: %s", e)

    logger.debug("scan_pptx_online: end item_id=%s threats=%d", item_id, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_pptx_online: threats detected count=%d types=%s", len(threats), types)
    risk_score = _calculate_risk(threats)
    return {
        'info': info,
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
    }


def _build_item_url(item_id: str, drive_id: Optional[str]) -> str:
    if drive_id:
        return f"{GRAPH_BASE}/drives/{drive_id}/items/{item_id}"
    return f"{GRAPH_BASE}/me/drive/items/{item_id}"


def _calculate_risk(threats):
    score = 0
    for t in threats:
        s = t.get('severity', 'LOW')
        if s == 'CRITICAL':
            score += 5
        elif s == 'HIGH':
            score += 3
        elif s == 'MEDIUM':
            score += 1
    return min(10, score)
